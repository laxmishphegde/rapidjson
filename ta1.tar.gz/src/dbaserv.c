/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DBASERV_C

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H

#include   "unidef.h"     /* Mandatory */
#include      "gen.h"
#include      "dba.h"
#include      "fin.h"
#include     "proc.h"
#include     "date.h"
#include      "cmp.h"
#include      "tls.h"
#include     "hier.h"
#include     "scpt.h"
#include   "scptyl.h"
#include      "ope.h"
#include     "serv.h"
#include   "finsrv.h"
#include     "conv.h"

#include  "dbaperf.h" /* REF9187 - LJE - 030527 */
#include "dbaperfa.h" /* REF9187 - LJE - 030527 */

#include "dbiconnection.h"
#include "fuscluster.h"
#include "fussync.h"

/************************************************************************
**      External entry points
**
** DBA_CurrencyModify()     Modifies the portfolio, instrument or system currency
** DBA_SelCheckStratData()  Select data for Check Strategy function
** DBA_SelStratLnkById()    Select all strategy links according to ptf and strat dim.
**
*************************************************************************/

/************************************************************************
**      Local functions
**
** DBA_InitDomStrat()                   Initialize dom_strat table according to strategy dimension
** DBA_InitStratLnk()                   Initialize dom_port and dom_strat (ptf and strat dimension)
** DBA_SortUniquePtfId()                Sort a portfolio list and suppress duplicate records.
** DBA_SortUniqueStratId()              Sort a list of strat id's by creating a new index ptr array.
** DBA_CmpSStratLnkPtfStrat()           Sort short strategy link by portfolio and strategy.
** DBA_CmpShStratLnkPtfId()             Sort S_StratLnk by portfolio and strategy identifier.
** DBA_CmpShStratLnkStratId()           Sort S_StratLnk by strategy identifier.
** DBA_CmpPtfSynthPtfDateGlobal         Sort an array of synthetics by ptfId, initial date, and global level
** DBA_DelDomPortAndDomStratTables()    Send a Delete table request.
** DBA_CreateDomPortAndDomStratTables() Send a Create table request.
** DBA_SelCheckStratDataInitStrat()     According to domain (A_Domain_ForceLnkFlg, Strat, Ptf), initialise #dom_strat
** DBA_CmpListById()
** DBA_CmpListCompoByLidOidDt()
**
*************************************************************************/

/************************************************************************
**      Static definitions & data
*************************************************************************/
/* STATIC RET_CODE DBA_InitStratLnk(DBA_DYNFLD_STP, int*, ID_T*, int); REF7395 - CSY - 020322: now EXTERN */
STATIC RET_CODE DBA_SelCheckStratDataInitStrat(DBA_DYNFLD_STP, ID_T**, int*, int*, DBA_DYNFLD_STP**, int*); /* REF7423 - RAK - 020404 */

/*STATIC RET_CODE DBA_CreateDomPortAndDomStratTables(int, FLAG_T);
STATIC RET_CODE DBA_DelDomPortAndDomStratTables(int, FLAG_T); REF7395 - CSY - 020322: EXTERN now */
STATIC RET_CODE DBA_InitDomStrat(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DbiConnection &);

STATIC RET_CODE DBA_GetMktSegtGridIdFromMultiSelect(DBA_DYNFLD_STP*, int, ID_T, ID_T*);


    #ifdef NOT_USED
    STATIC RET_CODE DBA_SortUniquePtfId(DBA_DYNFLD_STP**, int, DBA_DYNFLD_STP**, int*);
    #endif

/* REF7395 - CSY - 020322 : DBA_SortUniqueStratId now EXTERN */

STATIC int  DBA_CmpShStratLnkStratId(DBA_DYNFLD_STP*, DBA_DYNFLD_STP*),
    #ifdef NOT_USED
            DBA_CmpShStratLnkPtfId(DBA_DYNFLD_STP*, DBA_DYNFLD_STP*),
    #endif

        DBA_CmpPtfSynthPtfDateGlobal(DBA_DYNFLD_STP*, DBA_DYNFLD_STP*);   /* REF6912 - CSY - 010810: match with FIN_CmpPtfSynthPtfDateGlobal in finsrv05.c */

STATIC int DBA_ParentInList(ID_T, DBA_DYNFLD_STP *, int);
STATIC RET_CODE DBA_TradConstr2ExtStratLnk(DBA_DYNFLD_STP, DBA_DYNFLD_STP **, int *, DBA_DYNFLD_STP*, int *, int, int, int); /* PMSTA04614-CHU-071030 : add domain */ /* PMSTA08801 - DDV - 091126 */

/* REF9187 - LJE - 030605 */
STATIC int DBA_CmpListById(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *);
STATIC int DBA_CmpPtfById(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *);
STATIC int DBA_CmpListCompoByLidOidDt(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *);
STATIC int DBA_CmpStratLinkByOidDt(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *);
STATIC int DBA_CmpStratLinkByPtfDts(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *);
STATIC int DBA_CmpSLPriority(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *);
STATIC int DBA_CmpSLPriorityCurrent(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *);
STATIC int DBA_FilterMCEFromMC(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP); /* REF11435 - TEB - 051021 */
STATIC int DBA_FilterPtfMC(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);	/* REF11435 - TEB - 051021 */
STATIC RET_CODE FIN_CreateMCForHierConstr(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP); /*PMSTA-48867-Satya*/
extern bool DBA_Check_Hier_Lnk(ID_T, ID_T); /*WEALTH-5840-Satya*/

/************************************************************************
*
*   Function          : DBA_CmpShStratLnkPtfId()
*
*   Description       : Sort S_StratLnk by portfolio and strategy identifier
*
*   Arguments         : stp1    Pointer on first element to compare
*                       stp2    Pointer on second element to compare
*
*   Return            : a negative value if first element < second element
*                       a null value     if first element = second element
*                       a positive value if first element > second element
*
*   Creation date     : 22.11.95 - PEC
*   Last modification : 29.02.09 - PEC - Ref.: DVP016
*
*************************************************************************/
#ifdef NOT_USED
    STATIC int DBA_CmpShStratLnkPtfId(DBA_DYNFLD_STP *stp1, DBA_DYNFLD_STP *stp2)
    {

        if (IS_NULLFLD(stp1[0], S_StratLnk_PtfId) && IS_NULLFLD(stp2[0], S_StratLnk_PtfId))
            return(0);

        if (IS_NULLFLD(stp1[0], S_StratLnk_PtfId) == TRUE)
            return(-1);

        if (IS_NULLFLD(stp2[0], S_StratLnk_PtfId) == TRUE)
            return(1);

        /* If ptf Id's are equivalent */
        if (GET_ID(stp2[0], S_StratLnk_PtfId) == GET_ID(stp1[0], S_StratLnk_PtfId))
        {
            /************ BEGIN DVP016 ***********/
            if (GET_ID(stp1[0], S_StratLnk_StratId) < GET_ID(stp2[0], S_StratLnk_StratId))
                return(-1);

            if (GET_ID(stp1[0], S_StratLnk_StratId) > GET_ID(stp2[0], S_StratLnk_StratId))
                return(1);

            /************ END   DVP016 ***********/
            return(0);
        }

        /* If first pftId > second ptfId, return 1 */
        if (GET_ID(stp1[0], S_StratLnk_PtfId) > GET_ID(stp2[0], S_StratLnk_PtfId))
            return(1);

        return(-1);
    }
#endif

/************************************************************************
*
*   Function        :   DBA_IsReplOldESLByPtfId
*
*   Description     :   Check session content to find some SelectiveReplaceOld ESL for current portfolio
*
*   Arguments       :   ptfId : Id of portfolio to be checked
*
*   Return          :   TRUE if a SelectiveReplaceOld ESL records found in session
*
*   Creation date   :   PMSTA-29302 - CHU - 180112
*
*************************************************************************/
RET_CODE DBA_IsReplOldESLByPtfId(ID_T ptfId,
                                 ID_T domainFctResId,
                                 FLAG_T *retFlg,
                                 int dbOptions,
                                 int *connectNo)
{
    RET_CODE        ret = RET_SUCCEED;
    DBA_DYNFLD_STP  getArg = NULL;
    DBA_DYNFLD_STP  ioIdptr = NULL;

    *retFlg = FALSE;

    if (ptfId           <= (ID_T)0 ||
        domainFctResId  <= (ID_T)0)
    {
        ret = RET_MEM_ERR_ALLOC;
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "Get_Arg");
        return(ret);
    }

    if ((getArg = ALLOC_DYNST(Get_Arg)) == NULL)
    {
        ret = RET_MEM_ERR_ALLOC;
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "Get_Arg");
        return(ret);
    }
    if ((ioIdptr = ALLOC_DYNST(Io_Id)) == NULL)
    {
        FREE_DYNST(getArg, Get_Arg);
        ret = RET_MEM_ERR_ALLOC;
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "Io_Id");
        return(ret);
    }

    SET_ID(getArg, Get_Arg_Id,    domainFctResId);
    SET_ID(getArg, Get_Arg_PtfId, ptfId);

    /* call proc get_is_replold_esl_by_pid_fid */
    if ((ret = DBA_Get2(FctResult,
                        UNUSED,
                        Get_Arg, getArg,
                        Io_Id, &ioIdptr,
                        dbOptions, connectNo)) == RET_SUCCEED)
    {
        /* FALSE means SelectiveReplaceOld ESL records was found for this portfolio in current session */
        /* TRUE  means NO SelectiveReplaceOld ESE records was found for this portfolio in current session */
        *retFlg = (FLAG_T)GET_ID(ioIdptr, Io_Id_Id);
    }

    FREE_DYNST(getArg, Get_Arg);
    FREE_DYNST(ioIdptr, Io_Id);

    return(ret);
}

/************************************************************************
*
*   Function        :   DBA_FilterPtfForSelectiveReplaceOld
*
*   Description : Check session content to find some ESE for current portfolio
*
*   Arguments : ptfId : Id of portfolio to be checked
*
*   Return : TRUE if no ESE records found in session
*
*   Creation date : PMSTA - 29302 - CHU - 180112
*
*************************************************************************/
RET_CODE DBA_FilterPtfForSelectiveReplaceOld(DBA_DYNFLD_STP    domainPtr,
                                             int               *ptfIdNbr,
                                             ID_T              **ptfIdTab,
                                             int               *connectNo,
                                             int               dbOptions,
                                             DBA_DYNFLD_STP    **data,
                                             int               *dataRows,
                                             FLAG_T            updateHierFlg,
                                             DBA_HIER_HEAD_STP hierStp)
{
    RET_CODE ret = RET_SUCCEED;
    int i, j, localPtfIdNbr = 0, familyIdx = 0;
    ID_T *localPtfIdTab = NULL;
    ID_T hierPtfId = (ID_T)-1;
    FLAG_T SelectiveReplOldESLFlg = TRUE, partOfFamilyFlg = FALSE, foundFlg = FALSE;
    DBA_DYNFLD_STP *dataPtfTab = NULL;
    int dataPtfNbr = 0;

    if ((localPtfIdTab = (ID_T *)CALLOC(*ptfIdNbr, sizeof(ID_T))) == NULL)
    {
        ret = RET_MEM_ERR_ALLOC;
        MSG_SendMesg(ret, 1, FILEINFO, 1);
        return(ret);
    }

    for (i = 0; i < (*ptfIdNbr); i++)
    {
        /* PMSTA-23902 - CHU - 180112 : add check on 'SelectiveReplOld' ESL (calculated_e = 99) for selective list of portfolios */
        if (DBA_IsReplOldESLByPtfId(GET_ID((*data)[i], A_Ptf_Id), GET_ID(domainPtr, A_Domain_FctResultId), &SelectiveReplOldESLFlg, dbOptions, connectNo == NULL ? UNUSED : connectNo) == RET_SUCCEED &&
            SelectiveReplOldESLFlg == FALSE)
        {
            continue;
        }

        if (localPtfIdNbr == 0)
        {
            (localPtfIdTab)[localPtfIdNbr] = GET_ID((*data)[i], A_Ptf_Id);
        }
        else
        {
            foundFlg = FALSE;
            for (j = 0; j < localPtfIdNbr; j++)
            {
                if (CMP_ID(localPtfIdTab[j], GET_ID((*data)[i], A_Ptf_Id)) == 0)
                {
                    foundFlg = TRUE;
                    break;
                }

                if (foundFlg == FALSE)
                {
                    (localPtfIdTab)[localPtfIdNbr] = GET_ID((*data)[i], A_Ptf_Id);
                }
            }
        }
        localPtfIdNbr++;

        /* also check for hierarchical portfolios */
        if (IS_NULLFLD((*data)[i], A_Ptf_HierPortId) == FALSE)
        {
            hierPtfId = GET_ID((*data)[i], A_Ptf_HierPortId);
        }
        else
        {
            hierPtfId = GET_ID((*data)[i], A_Ptf_Id);
        }

        for (j = 0; j < *ptfIdNbr; j++)
        {
            if (CMP_ID(GET_ID((*data)[j], A_Ptf_HierPortId), hierPtfId) == 0 ||
                CMP_ID(GET_ID((*data)[j], A_Ptf_Id), hierPtfId) == 0)
            {
                partOfFamilyFlg = TRUE;
                familyIdx = j;
                break;
            }
        }

        if (partOfFamilyFlg == TRUE)
        {
            for (j = 0; j < localPtfIdNbr; j++)
            {
                if (CMP_ID(localPtfIdTab[j], GET_ID((*data)[familyIdx], A_Ptf_Id)) == 0)
                {
                    partOfFamilyFlg = FALSE; /* already there */
                    break;
                }
            }

            if (partOfFamilyFlg == TRUE) /* should be added */
            {
                localPtfIdTab[localPtfIdNbr++] = GET_ID((*data)[j], A_Ptf_Id);
            }
        }
    }

    if (localPtfIdNbr == 0) /* could happen ? */
    {
        *ptfIdNbr = 0;
        FREE(*ptfIdTab);
        *ptfIdTab = NULL;
    }
    else
    {
        if (localPtfIdNbr < *ptfIdNbr) /* reduce existing arrays */
        {
            if (((*ptfIdTab) = (ID_T *)REALLOC((*ptfIdTab), (localPtfIdNbr)* sizeof(ID_T))) == NULL)  /* PMSTA15705 - DDV - 121226 - Purify, use REALLOC to avoid memory leak when ptfIdTab has allready been allocated */
            {
                ret = RET_MEM_ERR_ALLOC;
                MSG_SendMesg(ret, 1, FILEINFO, 1);
                return(ret);
            }

            if ((dataPtfTab = (DBA_DYNFLD_STP *)CALLOC(localPtfIdNbr, sizeof(DBA_DYNFLD_STP))) == NULL)
            {
                ret = RET_MEM_ERR_ALLOC;
                MSG_SendMesg(ret, 1, FILEINFO, 1);
                return(ret);
            }

            for (i = 0; i < *ptfIdNbr; i++)
            {
                for (j = 0; j < localPtfIdNbr; j++)
                {
                    if (CMP_ID(GET_ID((*data)[i], A_Ptf_Id), localPtfIdTab[j]) == 0)
                    {
                        if ((dataPtfTab[dataPtfNbr] = ALLOC_DYNST(A_Ptf)) == NULL)
                        {
                            ret = RET_MEM_ERR_ALLOC;
                            MSG_SendMesg(ret, 1, FILEINFO, 1);
                            return(ret);
                        }

                        COPY_DYNST(dataPtfTab[dataPtfNbr++], (*data)[i], A_Ptf);

                        (*ptfIdTab)[i] = GET_ID((*data)[i], A_Ptf_Id);

                        MSG_LogSrvMesg(UNUSED, UNUSED, "Selective Pre-trade Check Strategy : Keeping Portfolio %1 from session %2",
                                       CodeType, GET_CODE((*data)[i], A_Ptf_Cd),
                                       CodeType, GET_CODE(domainPtr, A_Domain_FctResultCd));
                    }
                    else
                    {
                        MSG_LogSrvMesg(UNUSED, UNUSED, "Selective Pre-trade Check Strategy : Discarding Portfolio %1 from session %2",
                                       CodeType, GET_CODE((*data)[i], A_Ptf_Cd),
                                       CodeType, GET_CODE(domainPtr, A_Domain_FctResultCd));
                    }
                }
            }

            if (updateHierFlg == TRUE)
            {
                if ((ret = DBA_DelAndFreeHierElt(hierStp, A_Ptf)) != RET_SUCCEED)
                {
                    MSG_SendMesg(RET_DBA_ERR_HIER, 0, FILEINFO);
                    return(ret);
                }
                DBA_AddHierRecordList(hierStp, dataPtfTab, dataPtfNbr, A_Ptf, FALSE);
            }
            else
            {
                DBA_FreeDynStTab((*data), *ptfIdNbr, A_Ptf);
                if (((*data) = (DBA_DYNFLD_STP *)CALLOC(localPtfIdNbr, sizeof(DBA_DYNFLD_STP))) == NULL)
                {
                    ret = RET_MEM_ERR_ALLOC;
                    MSG_SendMesg(ret, 1, FILEINFO, 1);
                    return(ret);
                }
            }
            (*data) = dataPtfTab;
            *dataRows = dataPtfNbr;
            *ptfIdNbr = localPtfIdNbr;
        }
        FREE(localPtfIdTab);
    }
    return(ret);
}

/************************************************************************
*
*   Function          : DBA_CmpShStratLnkStratId()
*
*   Description       : Sort S_StratLnk by strategy identifier
*
*   Arguments         : stp1    Pointer on first element to compare
*                       stp2    Pointer on second element to compare
*
*   Return            : a negative value if first element < second element
*                       a null value     if first element = second element
*                       a positive value if first element > second element
*
*   Creation date     : 28.11.95 - DED
*   Last modification :
*
*************************************************************************/
STATIC int DBA_CmpShStratLnkStratId(DBA_DYNFLD_STP *stp1, DBA_DYNFLD_STP *stp2)
{

    if (IS_NULLFLD(stp1[0], S_StratLnk_StratId) && IS_NULLFLD(stp2[0], S_StratLnk_StratId))
        return(0);

    if (IS_NULLFLD(stp1[0], S_StratLnk_StratId) == TRUE)
        return(-1);

    if (IS_NULLFLD(stp2[0], S_StratLnk_StratId) == TRUE)
        return(1);

    /* If strategy Id's are equivalent */
    if (GET_ID(stp2[0], S_StratLnk_StratId) == GET_ID(stp1[0], S_StratLnk_StratId))
        return(0);

    /* If first pftId > second StratId, return 1 */
    if (GET_ID(stp1[0], S_StratLnk_StratId) > GET_ID(stp2[0], S_StratLnk_StratId))
        return(1);

    return(-1);
}

/************************************************************************
**
**  Function    :   DBA_CmpSLStrat()
**
**  Description :   Extended strategy link table is sort by startegy,
**
**  Arguments   :   ptr1   pointer on dynamic structure type ExtPos
**                  ptr2   pointer on dynamic structure type ExtPos
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation Date        : 021009 - DDV - REF7758
**  Last Modification    :
*************************************************************************/
STATIC int DBA_CmpSLStrat(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    int cmp;

    if ((cmp = CMP_DYNFLD(*ptr1, *ptr2, S_StratLnk_ToObjId, S_StratLnk_ToObjId, IdType)) != 0) /* REF10723 - LJE - 041027 */
        return(cmp);

    if ((cmp = CMP_DYNFLD(*ptr1, *ptr2, S_StratLnk_BegDate, S_StratLnk_BegDate, DateType)) != 0)
        return(cmp);

    return(CMP_DYNFLD(*ptr1, *ptr2, S_StratLnk_EndDate, S_StratLnk_EndDate, DateType));
}

/************************************************************************
*   Function             : DBA_CmpSStratLnkPtfStrat()
*
*   Description          : Sort short strategy link by portfolio and strategy
*
*   Arguments            : ptr1    first element pointer
*                          prt2    second element pointer
*
*   Return               : TLS_Sort() comparison function return
*
*   Creation             : BUG047 - RAK - 960701
*   Modification         : REF7395 - CSY - 020322: STATIC to EXTERN
*
*************************************************************************/
int DBA_CmpSStratLnkPtfStrat(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    if (GET_ID((*ptr1), S_StratLnk_PtfId) ==
        GET_ID((*ptr2), S_StratLnk_PtfId))
    {
        if (GET_ID((*ptr1), S_StratLnk_StratId) ==
        GET_ID((*ptr2), S_StratLnk_StratId))
        {
        return(0);
        }
        else
        {
        return(CMP_ID(GET_ID((*ptr1), S_StratLnk_StratId) ,
               GET_ID((*ptr2), S_StratLnk_StratId))); /* DLA - REF9089 - 030509 */
        }
    }
    else
    {
        return(CMP_ID(GET_ID((*ptr1), S_StratLnk_PtfId) ,
           GET_ID((*ptr2), S_StratLnk_PtfId))); /* DLA - REF9089 - 030509 */
    }
}

/************************************************************************
*   Function             : DBA_CurrencyModify
*
*   Description          : Modifies the portfolio, instrument or system currency
*
*   Arguments            : currMod  pointer on Curr_Modif record with all arguments
*              portfolio    pointer on portfolio record (if supplied)
*              instrument   pointer on instrument record (if supplied)
*              portPosSet   pointer on portfolio position set record (if supplied)
*
*   Arguments suppressed info is stored in currMod record - REF1190 - 980211 - XDI
*              oldCurrCd    old currency code
*              newCurrCd    new currency code
*
*   Return               : RET_CODE             if ok
*              RET_GEN_ERR_INVARG       invalid argument
*              RET_MEM_ERR_ALLOC        error in memory allocation
*              RET_DBA_ERR_NODATA       no data found
*              RET_DBA_ERR_CONNOTFOUND  no connection found
*              RET_DBA_ERR_HIER     error in hierarchy
*              RET_FIN_ERR_INVDATA      missing data
*
*   Creation date        : 950318  - DED
*   Last modification    : DVP009
*              DVP029  - 960507 - DED : add account 2 and account 3.
*              BUG075  - 960729 - DED : modify also BpCurrId if
*                           equals to portfolio or
*                           instrument currency.
*              BUG081  - 960807 - DED : Invest, Withdr, Transfert : Compute Hist-fields.
*              DVP183  - 960828 - DED : Add new operation nature 'locking'.
*              BUG185  - 961016 - DED : Supplementary tests on instrument id's.
*              DVP288  - 961206 - DED : No more test on 'Automatic Fusion'.
*              DVP166  - 970106 - DED : Add new argument to function OPE_CreateExtOpfromExtPos.
*                           Add arguments portfolio and instrument pointers.
*              DVP343  - 970220 - XMT : extract code which only change the
*                           port./instr. currency and the
*                           content of the corresponding extOp.
*                          REF347  - 971007 - DED : Error with reversal operations.
*              REF523  - 971021 - DED : Error with execution operations.
*              REF1190 - 980211 - XDI : Euro, modify sys amount and pps currency.
*              REF839  - 980220 - DED : Replace ExecNat_Executed by ExecNat_TotalExec and ExecNat_PartExec.
*              REF1077 - 980320 - DED : Call manual fusion request at end of function.
*                          REF1487 - 980327 - GRD : No cash positions for the cash portfolio if modifying currency.
*              REF1778 - 980427 - DED : No call manual fusion request
*              REF2956 - SSO - 981104 : Update optimisation for Get(Adm_Arg,S_Ptf)
*              REF6912 - CSY - 010810 : synthetics: update cumul amounts on some currency fields
*              REF11906- EFE - 060815 : modify currency : operation with cash ptf were not always
*                                       modified where treating the cash portfolio
*              PMSTA-3787 - 270907 - PMO : Modify Portfolio currency with cash portfolio resets some accounting
*              PMSTA-12309 - 190711 - PMO : Server crash when performing an instrument currency modification
*              PMSTA-13613 - 070212 - PMO : Decrease number of fusion request calls when modifying the currency of an instrument through function "Modify Curreny"
*              PMSTA-25163 - 041116 - Sridhara : Decrease number of fusion request calls when modifying the currency of a portfolio through function "Modify Curreny"
*
*************************************************************************/
int DBA_CurrencyModify(DBA_DYNFLD_STP currMod,
                       DBA_DYNFLD_STP portfolio,
                       DBA_DYNFLD_STP instrument,
                       DBA_DYNFLD_STP portPosSet,                      
                       DbiConnection & dbiConn,
                       DATETIME_T & beginTranDateTime,
                       DATE_T & fusionDate,
                       int & opUpdCount,
                       LockPortfolioHelper & lockPtfHelper)
{
    MemoryPool mp;
    DBA_DYNFLD_STP      domainArg = mp.allocDynst(FILEINFO,A_Domain),
        sEventSched = mp.allocDynst(FILEINFO,S_EventSched),
        sPtfPosSet = nullptr,
        sPtf = nullptr,
        sInstr = nullptr,
        memPtfPtr=NULL,
        memPtfPtr2=NULL,
        memPtfPosSetPtr=NULL,
        memInstrPtr=NULL,
        memInstrPtr2=NULL,
        ptfSt=NULL,
        admArgPps=nullptr,
        admArg=nullptr,
        instrSt=NULL;
    DBA_DYNFLD_STP      *extOpTab=NULL,
        *opTab=NULL,
    	*extOrderTab      = NULL,
        *ptfSynthTab=NULL,
        *memPtfPosSetTabPtr=NULL;
    DBA_HIER_HEAD_STP   hierHead=NULL;
    int j, extOpTabNbr=0,
		extOrderNbr       = 0,
        updExtOpNbr, ptfPosSetNbr=0,
        ptfPosSetIdx=0, ptfSynthNbr=0, opNbr=0, codeStrLen=0;
    RET_CODE        ret=RET_SUCCEED;
    OBJECT_ENUM     objectEn=NullEntity;
    DATETIME_T      today;
    char            *strPtr, *opCodeStr;
    FLAG_T          *scptFlagTab=NULL, recoverMode = FALSE, partialFlg=FALSE;
    DBA_ACCESS_STP      accessPtr = NULL;
    DICT_T                  ptfDict;
    ID_T                    sysCurrId, tmpCurrId, instrCurrId;
    PORTMODIF_ENUM          portModifEn;
    int i0 = 0, commitSz = 0;  /* REF6912 - CSY - 010810 */

    /* Check arguments */
    if (currMod == NULL)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_CurrencyModify", "currMod");
        return(RET_GEN_ERR_INVARG);
    }
    /* Check if new currency = old currency */
    /* REF2977 - 981125 - DDV - No more check
       if ((GET_ENUM(currMod, Curr_Modif_PortModifEn) == PortModif_RefCurr ||
       GET_ENUM(currMod, Curr_Modif_PortModifEn) == PortModif_RefSysCurr) &&
       GET_ID(currMod, Curr_Modif_OldCurrId) == GET_ID(currMod, Curr_Modif_NewCurrId))
       {
       MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_CurrencyModify", "New Currency Id");
       return(RET_GEN_ERR_INVARG);
       }*/

    if ((GET_ENUM(currMod, Curr_Modif_PortModifEn) == PortModif_SysCurr || GET_ENUM(currMod, Curr_Modif_PortModifEn) == PortModif_RefSysCurr) &&
        GET_ID(currMod, Curr_Modif_OldSysCurrId) == GET_ID(currMod, Curr_Modif_NewSysCurrId))
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_CurrencyModify", "New System Currency Id");
        return(RET_GEN_ERR_INVARG);
    }

    GEN_GetApplInfo(ApplCommitBlockSize, &commitSz);

    /* Get OBJECT_ENUM for entity dict Id */
    DBA_GetObjectEnum(GET_DICT(currMod, Curr_Modif_EntDictId), &objectEn);
    std::string msg;

    switch(GET_OBJECT_CST(objectEn)) /* REF8844 - LJE - 030416 */
    {
    case PtfPosSetCst:

        /* Memory allocation for input structure */
        sPtfPosSet = mp.allocDynst(FILEINFO,S_PtfPosSet);
        /* Fill key of structure Portfolio */
        COPY_DYNFLD(sPtfPosSet, S_PtfPosSet, S_PtfPosSet_Id, currMod, Curr_Modif, Curr_Modif_PortPosSetId);

        /* Retrieve portfolio position set record from local memory */
        ret = DBA_GetMemory(PtfPosSet, UNUSED, S_PtfPosSet, sPtfPosSet, A_PtfPosSet, NULL, &memPtfPosSetPtr, Opti_Local);
        if (ret != RET_SUCCEED || memPtfPosSetPtr == NULL)
        {
            MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, "Local Memory", GET_ID(currMod, Curr_Modif_PortPosSetId));
            return(RET_DBA_ERR_NODATA);
        }
        /* Memory allocation for input structure */
        admArgPps = mp.allocDynst(FILEINFO,Adm_Arg);
        /* Fill key of structure Portfolio */
        COPY_DYNFLD(admArgPps, Adm_Arg, Adm_Arg_Id, currMod, Curr_Modif, Curr_Modif_ObjId);

        /* Retrieve portfolio position set record from local memory */
        ret = DBA_SelectMemory(PtfPosSet, UNUSED, Adm_Arg, admArgPps, A_PtfPosSet, NULL, &memPtfPosSetTabPtr, &ptfPosSetNbr, Opti_Local);
        if (ret != RET_SUCCEED || memPtfPosSetTabPtr == NULL)
        {
            MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, "Local Memory",
                         GET_ID(currMod, Curr_Modif_PortPosSetId));
            return(RET_DBA_ERR_NODATA);
        }

        for (ptfPosSetIdx=0;
             ptfPosSetIdx < ptfPosSetNbr &&
                 CMP_DYNFLD(memPtfPosSetTabPtr[ptfPosSetIdx], currMod, A_PtfPosSet_Id, Curr_Modif_PortPosSetId, IdType) != 0;
             ptfPosSetIdx++);

        if (ptfPosSetIdx == ptfPosSetNbr)
        {
            MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, "Local Memory",
                         GET_ID(currMod, Curr_Modif_PortPosSetId));
            return(RET_DBA_ERR_NODATA);
        }

        /* Check if old currency is the actual one in the portfolio */
        if (GET_ID(currMod, Curr_Modif_OldCurrId) != GET_ID(portPosSet, A_PtfPosSet_CurrId))
        {
            /* REF2977 - DDV - 981116 - Error recovery method */
            if (GET_ID(currMod, Curr_Modif_NewCurrId) == GET_ID(portPosSet, A_PtfPosSet_CurrId))
            {
                recoverMode = TRUE;
            }
            else
            {
                MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_CurrencyModify", "Old Currency Id");
                return(RET_GEN_ERR_INVARG);
            }
        }
        /* Fill domain */
        DBA_GetDictId(Ptf, &ptfDict);
        SET_DICT(domainArg, A_Domain_DimPtfDictId, ptfDict);
        COPY_DYNFLD(domainArg, A_Domain, A_Domain_PtfObjId, currMod, Curr_Modif, Curr_Modif_ObjId);
        break;

    case PtfCst:
        /* Memory allocation for input structure */
        sPtf = mp.allocDynst(FILEINFO,S_Ptf);
        /* Fill key of structure Portfolio */
        COPY_DYNFLD(sPtf, S_Ptf, S_Ptf_Id, currMod, Curr_Modif, Curr_Modif_ObjId);
        /* Retrieve portfolio record from local memory */
        ret = DBA_GetMemory(Ptf, UNUSED, S_Ptf, sPtf, A_Ptf, NULL, &memPtfPtr, Opti_Local);

        if (ret != RET_SUCCEED || memPtfPtr == NULL)
        {
            MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, "Local Memory", GET_ID(currMod, Curr_Modif_ObjId));
            return(RET_DBA_ERR_NODATA);
        }
        /* REF2956 - SSO - 981104: fill the optimisation for get with Adm_Arg (used in DBA_InsExtOpById) */
        admArg = mp.allocDynst(FILEINFO,Adm_Arg);
        COPY_DYNFLD(admArg, Adm_Arg, Adm_Arg_Id,currMod, Curr_Modif, Curr_Modif_ObjId);
        SET_NULL_ID(admArg, Adm_Arg_CodifId);
        if ((memPtfPtr2 = ALLOC_DYNST(S_Ptf)) == NULL)
        {
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "S_Ptf");
            return(RET_MEM_ERR_ALLOC);
        }

        if (DBA_Get2(Ptf, UNUSED, Adm_Arg, admArg, S_Ptf, &memPtfPtr2, UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
        {
            MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, "database",
                         GET_ID(currMod, Curr_Modif_ObjId));
            FREE_DYNST(memPtfPtr2, S_Ptf);
            return(RET_DBA_ERR_NODATA);
        }
        FREE_DYNST(memPtfPtr2, S_Ptf);
        /* Retrieve ptf record from local memory (Get by Adm_Arg) */
        ret = DBA_GetMemory(Ptf, UNUSED, Adm_Arg, admArg, S_Ptf, NULL,
                            &memPtfPtr2, Opti_Local);
        if (ret != RET_SUCCEED || memPtfPtr2 == NULL)
        {
            MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, "database",
                         GET_ID(currMod, Curr_Modif_ObjId));
            return(RET_DBA_ERR_NODATA);
        }
        /* Check if old currency is the actual one in the portfolio */
        if (GET_ENUM(currMod, Curr_Modif_PortModifEn) == PortModif_RefCurr || GET_ENUM(currMod, Curr_Modif_PortModifEn) == PortModif_RefSysCurr)
        {
            if (GET_ID(currMod, Curr_Modif_OldCurrId) != GET_ID(portfolio, A_Ptf_CurrId))
            {
                /* REF2977 - DDV - 981116 - Error recovery method */
                if (GET_ID(currMod, Curr_Modif_NewCurrId) == GET_ID(portfolio, A_Ptf_CurrId))
                {
                    recoverMode = TRUE;
                }
                else
                {
                    MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_CurrencyModify", "Old Currency Id");
                    return(RET_GEN_ERR_INVARG);
                }
            }
        }
        /* Check if sys old currency is the actual one in the portfolio or appl_param */
        if (GET_ENUM(currMod, Curr_Modif_PortModifEn) == PortModif_SysCurr || GET_ENUM(currMod, Curr_Modif_PortModifEn) == PortModif_RefSysCurr)
        {
            if (IS_NULLFLD(portfolio, A_Ptf_SysCurrId) == FALSE &&
                GET_ID(currMod, Curr_Modif_OldSysCurrId) != GET_ID(portfolio, A_Ptf_SysCurrId))
            {
                MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_CurrencyModify","Old Sys Currency Id");
                return(RET_GEN_ERR_INVARG);
            }

            GEN_GetApplInfo(ApplSysCurrId, &sysCurrId);

            if (IS_NULLFLD(portfolio, A_Ptf_SysCurrId) == TRUE && GET_ID(currMod, Curr_Modif_OldSysCurrId) != sysCurrId)
            {
                MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_CurrencyModify","Old Sys Currency Id");
                return(RET_GEN_ERR_INVARG);
            }
        }
        /* Fill domain */
        COPY_DYNFLD(domainArg, A_Domain, A_Domain_DimPtfDictId,currMod, Curr_Modif, Curr_Modif_EntDictId);
        COPY_DYNFLD(domainArg, A_Domain, A_Domain_PtfObjId, currMod, Curr_Modif, Curr_Modif_ObjId);
        /* Check if Fusion is running on the portfolio */
		SET_DICT(sEventSched, S_EventSched_EntityDictId, GET_DICT(domainArg, A_Domain_DimPtfDictId));
		SET_ID(sEventSched, S_EventSched_ObjId, GET_ID(currMod, Curr_Modif_ObjId));
		if ((DBA_Check(EventSched, DBA_ROLE_CURRENCY_MODIF, S_EventSched, sEventSched, UNUSED, nullptr, nullptr) == RET_SUCCEED ) &&
			(GET_INT(sEventSched, S_EventSched_ReturnStatus) > 0)) /* PMSTA-46404 - DDV - 211004 */
		{
            msg = SYS_Stringer("Modify Currency (",GET_CODE(currMod, Curr_Modif_OldCurrCd)," -> ",GET_CODE(currMod, Curr_Modif_NewCurrCd)
                        ,") on portfolio [",GET_CODE(portfolio, A_Ptf_Cd),"] aborted as Fusion is pending or running on portfolio. Retry after fusion complete.");
			MSG_LogSrvMesg(UNUSED, UNUSED,msg.c_str());
            MSG_SendMesg(RET_GEN_ERR_PERSONAL,1,FILEINFO,msg.c_str());
			return(RET_FIN_ERR_FUSLOCK);
		}
        break;

    case InstrCst:
        /* Check if old currency is the actual one in the instrument */
        if (GET_ID(currMod, Curr_Modif_OldCurrId) != GET_ID(instrument, A_Instr_RefCurrId))
        {   /* REF2977 - DDV - 981116 - Error recovery method */
            if (GET_ID(currMod, Curr_Modif_NewCurrId) == GET_ID(instrument, A_Instr_RefCurrId))
            {
                recoverMode = TRUE;
            }
            else
            {
                MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_CurrencyModify","Old Currency Id");
                return(RET_GEN_ERR_INVARG);
            }
        }
        /* Fill domain */
        COPY_DYNFLD(domainArg, A_Domain, A_Domain_DimInstrDictId, currMod, Curr_Modif, Curr_Modif_EntDictId);
        COPY_DYNFLD(domainArg, A_Domain, A_Domain_InstrObjId, currMod, Curr_Modif, Curr_Modif_ObjId);
        /* Check if Fusion is pending/running on any operation/portfolio with the instrument */
        SET_DICT(sEventSched, S_EventSched_EntityDictId, GET_DICT(domainArg, A_Domain_DimInstrDictId));
		SET_ID(sEventSched, S_EventSched_ObjId, GET_ID(currMod, Curr_Modif_ObjId));
		if ((DBA_Check(EventSched, DBA_ROLE_CURRENCY_MODIF, S_EventSched, sEventSched, UNUSED, nullptr, nullptr) == RET_SUCCEED ) &&
			(GET_INT(sEventSched, S_EventSched_ReturnStatus) > 0)) /* PMSTA-46404 - DDV - 211004 */
		{
			msg = SYS_Stringer("Modify Currency (",GET_CODE(currMod, Curr_Modif_OldCurrCd)," -> ",GET_CODE(currMod, Curr_Modif_NewCurrCd)
                        ,") on instrument [",GET_CODE(instrument, A_Instr_Cd),"] aborted as Fusion is pending or running on portfolio. Retry after fusion complete.");
            MSG_LogSrvMesg(UNUSED, UNUSED,msg.c_str());
            MSG_SendMesg(RET_GEN_ERR_PERSONAL,1,FILEINFO,msg.c_str());
            return(RET_FIN_ERR_FUSLOCK);
		}
        break;

    default:

        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_CurrencyModify","Entity DictId");
        return(RET_GEN_ERR_INVARG);
    }

    /* Get current date and time*/
    DATE_CurrentDateTime(&today);
    today.time=0;

    /* Set other fields of 'domain' which are obligatory in DBA_LoadPos */
    SET_ENUM(domainArg, A_Domain_MinStatEn, 0);
    SET_ENUM(domainArg, A_Domain_MaxStatEn, 0);
    SET_FLAG(domainArg, A_Domain_ZeroQtyFlg, FALSE);
    SET_DATETIME(domainArg, A_Domain_InterpFromDate, today);
    SET_DICT(domainArg, A_Domain_FctDictId, DictFct_CurrencyModify);
    SET_ENUM(domainArg, A_Domain_FusDateRuleEn, FusDateRule_None);

#ifdef AAADEBUG
    DEBUG_PRINTMSG("    - Load extended positions (DBA_LoadPos) ...\n");
#endif

        
    /* PMSTA-54274 - JBC - 230831 lock portfolios */
    ID_T    lockServerId = ZERO_ID;
    INT_T   maxFusion = 0;
    SERV_GetServerInfo(A_ServConnect_Id, &lockServerId);
    SERV_GetServerInfo(A_ServConnect_MaxFusion, &maxFusion);
    INT_T           lockRank =  FUS_getMockSrvId(false,maxFusion);    
    DBA_DYNFLD_STP *ptfTab = nullptr;
    int             ptfNb = 0;

    /* Ptf and PPS can be locked before hier */
    if(GEN_IsDispatcher() == false)
    {                 
        switch (GET_OBJECT_CST(objectEn))
        {
            case PtfPosSetCst:
                if(lockPtfHelper.lockAllPtfs(lockServerId, lockRank, GET_ID(portPosSet, A_PtfPosSet_PtfId)) == false
                    || lockPtfHelper.lockAllPtfs(lockServerId, lockRank, GET_ID(portPosSet, A_PtfPosSet_ConsPtfId)) == false)
                {
                    msg = SYS_Stringer("Modify PPS [",GET_CODE(portfolio, A_Ptf_Cd),
                    "] currency aborted. Portfolio is locked by fusion process. Retry when fusion completed.");
                    MSG_LogSrvMesg(UNUSED,UNUSED,msg.c_str());
                    MSG_SendMesg(RET_GEN_ERR_PERSONAL,1,FILEINFO,msg.c_str());
			        return(RET_DBA_ERR_NODATA);
                }
                break;
            case PtfCst:
                if(lockPtfHelper.lockAllPtfs(lockServerId, lockRank, GET_ID(portfolio, A_Ptf_Id)) == false)
                {
                    msg = SYS_Stringer("Modify portfolio [",GET_CODE(portfolio, A_Ptf_Cd),
                    "] currency aborted. Portfolio is locked by fusion process. Retry when fusion completed.");
                    MSG_LogSrvMesg(UNUSED,UNUSED,msg.c_str());
                    MSG_SendMesg(RET_GEN_ERR_PERSONAL,1,FILEINFO,msg.c_str());
			        return(RET_DBA_ERR_NODATA);
                }
                break;

            default:
                break;
        }
    }

    /* Load extended positions + build hierarchy */     /* DVP460 */
    if (DBA_LoadPos(domainArg, &hierHead, NULL, 0, NULL, 0) != TRUE)
    {
        MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "Extended Positions");
        /* REF10390 - RAK - 041123 */
		if (hierHead != (DBA_HIER_HEAD_STP) NULL) { DBA_FreeHier(hierHead);}
        return(RET_DBA_ERR_NODATA);
    }

    /* PMSTA-54274 - JBC - 230831 */
    if(GEN_IsDispatcher() == false)
    {
        switch (GET_OBJECT_CST(objectEn))
        {
            case InstrCst:
                if(ret = DBA_ExtractHierEltRec(hierHead, A_Ptf, FALSE, NULL, NULL, &ptfNb, &ptfTab) != RET_SUCCEED)
                {
                    FREE(ptfTab);
                    MSG_SendMesg(RET_DBA_ERR_HIER, 1, FILEINFO, "DBA_CurrencyModify", ExtOp);
                    DBA_FreeHier(hierHead);
                    return(RET_DBA_ERR_HIER);
                }

                mp.ownerPtr(ptfTab);

                if(lockPtfHelper.lockAllPtfs(lockServerId, lockRank,ZERO_ID,ptfTab,ptfNb) == false)
                {
                    msg = SYS_Stringer("Modify instrument [",GET_CODE(instrument, A_Instr_Cd),
                    "] currency aborted. A linked portfolio is locked by fusion process. Retry when fusion completed.");
                    MSG_LogSrvMesg(UNUSED,UNUSED,msg.c_str());
                    MSG_SendMesg(RET_GEN_ERR_PERSONAL,1,FILEINFO,msg.c_str());
                    DBA_FreeHier(hierHead);
			        return(RET_DBA_ERR_NODATA);
                }

                /* Reload hier after lock in case fusion was running */
                DBA_FreeHier(hierHead);
                hierHead = nullptr;

                if (DBA_LoadPos(domainArg, &hierHead, NULL, 0, NULL, 0) != TRUE)
                {
                    MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "Extended Positions");
		            if (hierHead != (DBA_HIER_HEAD_STP) NULL) { DBA_FreeHier(hierHead);}
                    return(RET_DBA_ERR_NODATA);
                }
            break;

        default:
            break;
        }
    }

#ifdef AAADEBUG
    DEBUG_PRINTMSG("    - Create extended operations for each main position ...\n");
#endif
    /*
     * PMSTA-3787 - 270907 - PMO
     * This bloc of code create a link between an income operation with a cash portfolio and his cash account
     * because when the instrument position is equal to the cash position, there is one less position
     *
     * The code is implemented here in place of hierarchy to avoid regression.
     */
    {
        int                 extPosNbr;
        DBA_DYNFLD_STP *    extPosTab   = NULL;

        ret = DBA_ExtractHierEltRec(hierHead, ExtPos, FALSE, NULL, NULL, &extPosNbr, &extPosTab);

        if (ret != RET_SUCCEED)
        {
            DBA_FreeHier(hierHead);
            MSG_SendMesg(ret, 1, FILEINFO, "DBA_CurrencyModify", ExtPos);
            return(ret);
        }

        /* Search for income position with cash portfolio */
        for (int idxExtPos = 0; idxExtPos < extPosNbr; idxExtPos++)
        {
            OPNAT_ENUM          opNature;

            opNature = (OPNAT_ENUM) GET_ENUM(extPosTab[idxExtPos], ExtPos_OpenOpNatEn);

            if (  OpNat_Income       == opNature
               && TRUE               == GET_FLAG(extPosTab[idxExtPos], ExtPos_MainFlg)
               && PosNat_MainPos     == GET_ENUM(extPosTab[idxExtPos], ExtPos_PosNatEn)
               && NULL               == GET_EXTENSION_PTR(extPosTab[idxExtPos], ExtPos_Acct_ExtPos_Ext)
               && PosPrimary_Primary == GET_ENUM(extPosTab[idxExtPos], ExtPos_PrimaryEn)
               )
            {
                const ID_T extPosOpenOpId = GET_ID(extPosTab[idxExtPos], ExtPos_OpenOpId);
                const ID_T extPosPtfId    = GET_ID(extPosTab[idxExtPos], ExtPos_PtfId);
                OPNAT_ENUM opNature2;

                /* Search for the cash position */
                for (int idxExtPos2 = 0; idxExtPos2 < extPosNbr; idxExtPos2++)
                {
                    opNature2 = (OPNAT_ENUM) GET_ENUM(extPosTab[idxExtPos2], ExtPos_OpenOpNatEn);

                    if (  OpNat_Income       == opNature2
                       && 0 == CMP_ID(GET_ID(extPosTab[idxExtPos2], ExtPos_OpenOpId), extPosOpenOpId)
                       && 0 == CMP_ID(GET_ID(extPosTab[idxExtPos2], ExtPos_PtfId),    extPosPtfId)
                       && FALSE              == GET_FLAG(extPosTab[idxExtPos2], ExtPos_MainFlg)
                       && PosPrimary_Primary == GET_ENUM(extPosTab[idxExtPos2], ExtPos_PrimaryEn)
                       && PosNat_None        == GET_ENUM(extPosTab[idxExtPos2], ExtPos_PosNatEn)
                       )
                    { /* Found */
                        DBA_ForceLink(hierHead,
                                      ExtPos,
                                      ExtPos_Acct_ExtPos_Ext,
                                      extPosTab[idxExtPos],
                                      extPosTab[idxExtPos2]);
                        /* Don't search anymore */
                        break;
                    }
                }
            }
        }

        FREE(extPosTab);
    }

    /* From 'Extended Positions' create a number of 'Extended Operation' records */         /* REF347 - 971020 - DED */
    if ((ret = OPE_CreateExtOpfromExtPos(hierHead, &extOpTab, &extOpTabNbr, NULL, OPE_CmpCopyExtPos)) != RET_SUCCEED) /* REF7264 - LJE - 020131 */
    {
        if ((ret != RET_FIN_ERR_POSITIONS) ||                                                               /* REF4076 - 991111 - DED */
            (ret == RET_FIN_ERR_POSITIONS && extOpTabNbr != 0))
        {
            MSG_SendMesg(RET_DBA_ERR_NODATA, 0, FILEINFO);
            DBA_FreeDynStTab(extOpTab, extOpTabNbr, ExtOp);
            DBA_FreeHier(hierHead);
            return(RET_DBA_ERR_NODATA);
        }
    }

    /* REF7560 - DDV - expand extOpTab with all ext_order record */
    ret = DBA_ExtractHierEltRec(hierHead, ExtOp, TRUE, NULLFCT, NULLFCT, &extOrderNbr, &extOrderTab);

    if (ret != RET_SUCCEED)
    {
        MSG_SendMesg(RET_DBA_ERR_HIER, 1, FILEINFO, "DBA_CurrencyModify", ExtOp);
        DBA_FreeDynStTab(extOpTab, extOpTabNbr, ExtOp);
        DBA_FreeHier(hierHead);
        return(RET_DBA_ERR_HIER);
    }

    if (extOrderNbr > 0)
    {
        if (extOpTabNbr > 0)
        {
            if ((extOpTab = (DBA_DYNFLD_STP *) REALLOC(extOpTab, (extOpTabNbr+extOrderNbr) * sizeof(DBA_DYNFLD_STP))) == NULL)
            {
                MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, (extOpTabNbr+extOrderNbr)*sizeof(DBA_DYNFLD_STP));
            	DBA_FreeDynStTab(extOpTab, extOpTabNbr, ExtOp);
            	DBA_FreeDynStTab(extOrderTab, extOrderNbr, ExtOp);
            	DBA_FreeHier(hierHead);
                return(RET_MEM_ERR_ALLOC);
            }

            for (int i=0 ; i < extOrderNbr; i++)
			{
                extOpTab[extOpTabNbr+i]=extOrderTab[i];
				/* PMSTA-13786 - TGU - 120414 - These orders are being modified, so need to have updated LastModifDate */
				SET_NULL_DATETIME(extOpTab[extOpTabNbr+i], ExtOp_LastModifDate);
			}
            extOpTabNbr += extOrderNbr;
            FREE(extOrderTab);
        }
        else
        {

            extOpTab = extOrderTab;
            extOpTabNbr = extOrderNbr;
			/* PMSTA-13786 - TGU - 120414 - These orders are being modified, so need to have updated LastModifDate */
			for (int i=0 ; i < extOpTabNbr; i++)
			{
				SET_NULL_DATETIME(extOpTab[i], ExtOp_LastModifDate);
			}
        }
    }

#ifdef AAADEBUG
    DEBUG_PRINTMSG("    - Update portfolio/instrument/PPS/system currency in hierarchy/memory ...\n");
#endif

    /* REF2977 - DDV - 981116 - If recover mode update only if object is Ptf and sys currency change */
    if (recoverMode == FALSE ||
        (objectEn == Ptf &&
         (GET_ENUM(currMod, Curr_Modif_PortModifEn) == PortModif_SysCurr ||GET_ENUM(currMod, Curr_Modif_PortModifEn) == PortModif_RefSysCurr)))
    {
        /* Update portfolio/instrument/system currency */
        switch(GET_OBJECT_CST(objectEn)) /* REF8844 - LJE - 030416 */
        {
        case PtfPosSetCst:

            /* Load and initialise flag array for script */
            if ((scptFlagTab = (FLAG_T *)CALLOC(GET_FLD_NBR(A_PtfPosSet), sizeof(FLAG_T))) == NULL) /* REF7264 - LJE - 020131 */
            {
                MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ScriptFlag");
                DBA_FreeDynStTab(extOpTab, extOpTabNbr, ExtOp);
                DBA_FreeHier(hierHead);
                return(RET_MEM_ERR_ALLOC);
            }

            /* Force all flags to FALSE (=re-evalute all fields) */
            for (j=0; j<GET_FLD_NBR(A_PtfPosSet) ;j++)
            {
                scptFlagTab[j]=FALSE;
            }
            /* Force Currency Id to TRUE(=forced, will not be changed) */
            scptFlagTab[A_PtfPosSet_CurrId]=TRUE;

            /* Set currency to new value */
            /* Update local portfolio position set record */
            COPY_DYNFLD(portPosSet, A_PtfPosSet, A_PtfPosSet_CurrId, currMod, Curr_Modif, Curr_Modif_NewCurrId);
            if (SCPT_ComputeDV(PtfPosSet, scptFlagTab, portPosSet, FALSE, TRUE, NULL) != 0) /* REF4229 - SSO - 000919 */
            {
                MSG_SendMesg(RET_SCPT_ERR_SYNTAX, 0, FILEINFO);
                FREE(scptFlagTab);
                DBA_FreeDynStTab(extOpTab, extOpTabNbr, ExtOp);
                DBA_FreeHier(hierHead);
                return(RET_SCPT_ERR_SYNTAX);
            }

            /* Update local memory portfolio position set record */
            COPY_DYNFLD(memPtfPosSetPtr, A_PtfPosSet, A_PtfPosSet_CurrId, currMod, Curr_Modif, Curr_Modif_NewCurrId);
            if (SCPT_ComputeDV(PtfPosSet, scptFlagTab, memPtfPosSetPtr, FALSE, TRUE, NULL) != 0) /* REF4229 - SSO - 000919 */
            {
                MSG_SendMesg(RET_SCPT_ERR_SYNTAX, 0, FILEINFO);
                FREE(scptFlagTab);
                DBA_FreeDynStTab(extOpTab, extOpTabNbr, ExtOp);
                DBA_FreeHier(hierHead);
                return(RET_SCPT_ERR_SYNTAX);
            }

            COPY_DYNFLD(memPtfPosSetTabPtr[ptfPosSetIdx], A_PtfPosSet, A_PtfPosSet_CurrId, currMod, Curr_Modif, Curr_Modif_NewCurrId);
            if (SCPT_ComputeDV(PtfPosSet, scptFlagTab, memPtfPosSetTabPtr[ptfPosSetIdx], FALSE, TRUE, NULL) != 0)  /* REF4229 - SSO - 000919 */
            {
                MSG_SendMesg(RET_SCPT_ERR_SYNTAX, 0, FILEINFO);
                FREE(scptFlagTab);
                DBA_FreeDynStTab(extOpTab, extOpTabNbr, ExtOp);
                DBA_FreeHier(hierHead);
                return(RET_SCPT_ERR_SYNTAX);
            }

            /* Free memory allocation */
            FREE(scptFlagTab);
            break;

        case PtfCst:
            /* Load and initialise flag array for script */
            if ((scptFlagTab = (FLAG_T *)CALLOC(GET_FLD_NBR(A_Ptf), sizeof(FLAG_T))) == NULL) /* REF7264 - LJE - 020131 */
            {
                MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ScriptFlag");
                DBA_FreeDynStTab(extOpTab, extOpTabNbr, ExtOp);
                DBA_FreeHier(hierHead);
                return(RET_MEM_ERR_ALLOC);
            }

            /* Force all flags to FALSE (=re-evalute all fields) */
            for (j=0; j<GET_FLD_NBR(A_Ptf);j++)
                scptFlagTab[j]=FALSE;

            /* Update local portfolio record */
            if (GET_ENUM(currMod, Curr_Modif_PortModifEn) == PortModif_RefCurr || GET_ENUM(currMod, Curr_Modif_PortModifEn) == PortModif_RefSysCurr)
            {
                /* Force flags to TRUE(=forced, will not be changed) */
                scptFlagTab[A_Ptf_OldCurrId]=TRUE;
                scptFlagTab[A_Ptf_CurrId]=TRUE;
                scptFlagTab[A_Ptf_CurrConvDate]=TRUE;
                COPY_DYNFLD(portfolio, A_Ptf, A_Ptf_OldCurrId, portfolio, A_Ptf, A_Ptf_CurrId);
                COPY_DYNFLD(portfolio, A_Ptf, A_Ptf_CurrId, currMod, Curr_Modif, Curr_Modif_NewCurrId);
                SET_DATETIME(portfolio, A_Ptf_CurrConvDate, today);
            }

            if (GET_ENUM(currMod, Curr_Modif_PortModifEn) == PortModif_SysCurr || GET_ENUM(currMod, Curr_Modif_PortModifEn) == PortModif_RefSysCurr)
            {
                /* Force flags to TRUE(=forced, will not be changed) */
                scptFlagTab[A_Ptf_SysCurrId]=TRUE;
                COPY_DYNFLD(portfolio, A_Ptf, A_Ptf_SysCurrId, currMod, Curr_Modif, Curr_Modif_NewSysCurrId);
            }

            if (SCPT_ComputeDV(Ptf, scptFlagTab, portfolio, FALSE, TRUE, NULL) != 0) /* REF4229 - SSO - 000919 */
            {
                MSG_SendMesg(RET_SCPT_ERR_SYNTAX, 0, FILEINFO);
                FREE(scptFlagTab);
                DBA_FreeDynStTab(extOpTab, extOpTabNbr, ExtOp);
                DBA_FreeHier(hierHead);
                return(RET_SCPT_ERR_SYNTAX);
            }

            /* Update local memory portfolio record */
            if (GET_ENUM(currMod, Curr_Modif_PortModifEn) == PortModif_RefCurr || GET_ENUM(currMod, Curr_Modif_PortModifEn) == PortModif_RefSysCurr)
            {
                COPY_DYNFLD(memPtfPtr, A_Ptf, A_Ptf_OldCurrId, memPtfPtr, A_Ptf, A_Ptf_CurrId);
                COPY_DYNFLD(memPtfPtr, A_Ptf, A_Ptf_CurrId, currMod, Curr_Modif, Curr_Modif_NewCurrId);
                SET_DATETIME(memPtfPtr, A_Ptf_CurrConvDate, today);
                /* REF2956 - SSO - 981104 update also optimisation for get with Adm_Arg */
                COPY_DYNFLD(memPtfPtr2, S_Ptf, S_Ptf_CurrId, currMod, Curr_Modif, Curr_Modif_NewCurrId);
				SET_ENUM(memPtfPtr2, S_Ptf_ModifCurrEn, ModifCurr_Ptf); /* PMSTA-50533 */
            }

            if (GET_ENUM(currMod, Curr_Modif_PortModifEn) == PortModif_SysCurr || GET_ENUM(currMod, Curr_Modif_PortModifEn) == PortModif_RefSysCurr)
            {
                COPY_DYNFLD(memPtfPtr, A_Ptf, A_Ptf_SysCurrId, currMod, Curr_Modif, Curr_Modif_NewSysCurrId);
            }

            if (SCPT_ComputeDV(Ptf, scptFlagTab, memPtfPtr, FALSE, TRUE, NULL) != 0) /* REF4229 - SSO - 000919 */
            {
                MSG_SendMesg(RET_SCPT_ERR_SYNTAX, 0, FILEINFO);
                FREE(scptFlagTab);
                DBA_FreeDynStTab(extOpTab, extOpTabNbr, ExtOp);
                DBA_FreeHier(hierHead);
                return(RET_SCPT_ERR_SYNTAX);
            }

            /* Extract Portfolio from extended position hierarchy */
            ptfSt = DBA_SearchHierRecById(hierHead, A_Ptf, 0, GET_ID(currMod, Curr_Modif_ObjId));
            if (ptfSt == NULL && extOpTabNbr > 0)
            {
                MSG_SendMesg(RET_DBA_ERR_HIER, 1, FILEINFO, "DBA_CurrencyModify", A_Ptf);
                DBA_FreeDynStTab(extOpTab, extOpTabNbr, ExtOp);
                DBA_FreeHier(hierHead);
                return(RET_DBA_ERR_HIER);
            }

            /* Set currency to new value */
            /* Update hierarchy portfolio record if exist */
            if (ptfSt != NULL)
            {
                if (GET_ENUM(currMod, Curr_Modif_PortModifEn) == PortModif_RefCurr || GET_ENUM(currMod, Curr_Modif_PortModifEn) == PortModif_RefSysCurr)
                {
                    COPY_DYNFLD(ptfSt, A_Ptf, A_Ptf_OldCurrId, ptfSt, A_Ptf, A_Ptf_CurrId);
                    COPY_DYNFLD(ptfSt, A_Ptf, A_Ptf_CurrId, currMod, Curr_Modif, Curr_Modif_NewCurrId);
                    SET_DATETIME(ptfSt, A_Ptf_CurrConvDate, today);
                }

                if (GET_ENUM(currMod, Curr_Modif_PortModifEn) == PortModif_SysCurr || GET_ENUM(currMod, Curr_Modif_PortModifEn) == PortModif_RefSysCurr)
                {
                    COPY_DYNFLD(ptfSt, A_Ptf, A_Ptf_SysCurrId, currMod, Curr_Modif, Curr_Modif_NewSysCurrId);
                }

                if (SCPT_ComputeDV(Ptf, scptFlagTab, ptfSt, FALSE, TRUE, NULL) != 0) /* REF4229 - SSO - 000919 */
                {
                    MSG_SendMesg(RET_SCPT_ERR_SYNTAX, 0, FILEINFO);
                    FREE(scptFlagTab);
                    DBA_FreeDynStTab(extOpTab, extOpTabNbr, ExtOp);
                    DBA_FreeHier(hierHead);
                    return(RET_SCPT_ERR_SYNTAX);
                }
            }
            /* Free memory allocation */
            FREE(scptFlagTab);

            break;

        case InstrCst:
            /* Extract Instrument from extended position hierarchy */
            instrSt = DBA_SearchHierRecById(hierHead, A_Instr, 0, GET_ID(currMod, Curr_Modif_ObjId));
			/* REF9199 - RAK - 030630 */
			/* If instrument isn't loaded in hiearchy (because it isn't own in a ptf) do the update */
			/* without update this instrument in hierarchy becasue it isnt' in hierarchy            */
            /* if (instrSt == NULL)
            {
                MSG_SendMesg(RET_DBA_ERR_HIER, 1, FILEINFO, "DBA_CurrencyModify",
                             A_Instr);
                DBA_FreeDynStTab(extOpTab, extOpTabNbr, ExtOp);
                DBA_FreeHier(hierHead);
                return(RET_DBA_ERR_HIER);
            } */

            /* Load and initialise flag array for script */
            if ((scptFlagTab = (FLAG_T *)CALLOC(GET_FLD_NBR(A_Instr), sizeof(FLAG_T))) == NULL) /* REF7264 - LJE - 020131 */
            {
                MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ScriptFlag");
                DBA_FreeDynStTab(extOpTab, extOpTabNbr, ExtOp);
                DBA_FreeHier(hierHead);
                return(RET_MEM_ERR_ALLOC);
            }

            /* Force all flags to FALSE (=re-evalute all fields) */
            for (j=0; j<GET_FLD_NBR(A_Instr) ;j++)
            {
                scptFlagTab[j]=FALSE;
            }
            /* Force Currency Id to TRUE(=forced, will not be changed) */
            scptFlagTab[A_Instr_RefCurrId]=TRUE;

            /* Set currency to new value */
            /* Update hierarchy instrument record */

			/* REF9199 - RAK - 030630 */
			if (instrSt != NULL)
			{
                COPY_DYNFLD(instrSt, A_Instr, A_Instr_RefCurrId, currMod, Curr_Modif, Curr_Modif_NewCurrId);
                if (SCPT_ComputeDV(Instr, scptFlagTab, instrSt, FALSE, TRUE, NULL) != 0) /* REF4229 - SSO - 000919 */
			    {
                    MSG_SendMesg(RET_SCPT_ERR_SYNTAX, 0, FILEINFO);
                    FREE(scptFlagTab);
                    DBA_FreeDynStTab(extOpTab, extOpTabNbr, ExtOp);
                    DBA_FreeHier(hierHead);
                    return(RET_SCPT_ERR_SYNTAX);
                }
			}

            /* Update local instrument record */
            COPY_DYNFLD(instrument, A_Instr, A_Instr_RefCurrId, currMod, Curr_Modif, Curr_Modif_NewCurrId);
            if (SCPT_ComputeDV(Instr, scptFlagTab, instrument, FALSE, TRUE, NULL) != 0) /* REF4229 - SSO - 000919 */
            {
                MSG_SendMesg(RET_SCPT_ERR_SYNTAX, 0, FILEINFO);
                FREE(scptFlagTab);
                DBA_FreeDynStTab(extOpTab, extOpTabNbr, ExtOp);
                DBA_FreeHier(hierHead);
                return(RET_SCPT_ERR_SYNTAX);
            }
            /* Memory allocation for input structure */
            sInstr = mp.allocDynst(FILEINFO,S_Instr);
            /* Fill key of structure Instrument */
            COPY_DYNFLD(sInstr, S_Instr, S_Instr_Id,currMod, Curr_Modif, Curr_Modif_ObjId);
            /* Retrieve instrument record from local memory */
            ret = DBA_GetMemory(Instr, UNUSED, S_Instr, sInstr, A_Instr, NULL, &memInstrPtr, Opti_Local);
            if (ret != RET_SUCCEED || memInstrPtr == NULL)
            {   /* PMSTA10872 - DDV - 110124 - If record not found, get it from database to fill the optimisation cache */
                if ((memInstrPtr2 = ALLOC_DYNST(A_Instr)) == NULL)
                {
                    MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "A_Instr");
                    return(RET_MEM_ERR_ALLOC);
                }

                if (DBA_Get2(Instr, UNUSED, S_Instr, sInstr, A_Instr, &memInstrPtr2, UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
                {
                    MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, "database", GET_ID(currMod, Curr_Modif_ObjId));
                    FREE_DYNST(memInstrPtr2, A_Instr);
                    return(RET_DBA_ERR_NODATA);
                }
                FREE_DYNST(memInstrPtr2, A_Instr);
                /* Retrieve instrument record from local memory */
                ret = DBA_GetMemory(Instr, UNUSED, S_Instr, sInstr, A_Instr, NULL, &memInstrPtr, Opti_Local);
                /* PMSTA10872 - DDV - 110124 - If record is ever record not found, it is an error */
                if (ret != RET_SUCCEED || memInstrPtr == NULL)
                {   /* PMSTA10872 - DDV - 110124 - If record not foud, get it from database to fill the chache */
                    MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, "Local Memory", GET_ID(currMod, Curr_Modif_ObjId));
                    return(RET_DBA_ERR_NODATA);
                }
            }
            /*
             * PMSTA-12309 - 190711 - PMO
             * Insure that the pointer memInstrPtr point to the right place
             */
            /* Fill key of structure Instrument */
            COPY_DYNFLD(sInstr, S_Instr, S_Instr_Id, currMod, Curr_Modif, Curr_Modif_ObjId);

            /* Retrieve instrument record from local memory */
            ret = DBA_GetMemory(Instr, UNUSED, S_Instr, sInstr, A_Instr, NULL, &memInstrPtr, Opti_Local);
            if (ret != RET_SUCCEED || memInstrPtr == NULL)
            {
                MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, "Local Memory", GET_ID(currMod, Curr_Modif_ObjId));
                FREE(scptFlagTab);
                DBA_FreeDynStTab(extOpTab, extOpTabNbr, ExtOp);
                DBA_FreeHier(hierHead);
                return(RET_DBA_ERR_NODATA);
            }

            /* Update local memory instrument record */
            COPY_DYNFLD(memInstrPtr, A_Instr, A_Instr_RefCurrId,
                        currMod, Curr_Modif, Curr_Modif_NewCurrId);
            if (SCPT_ComputeDV(Instr, scptFlagTab, memInstrPtr, FALSE, TRUE, NULL) != 0)  /* REF4229 - SSO - 000919 */
            {
                MSG_SendMesg(RET_SCPT_ERR_SYNTAX, 0, FILEINFO);
                FREE(scptFlagTab);
                DBA_FreeDynStTab(extOpTab, extOpTabNbr, ExtOp);
                DBA_FreeHier(hierHead);
                return(RET_SCPT_ERR_SYNTAX);
            }
            /* REF2378 - DDV - 980706 - Modify optimisation for Get by Adm_Arg */
            /* Memory allocation for input structure */
            admArg = mp.allocDynst(FILEINFO,Adm_Arg);
            /* Fill key of structure Instrument */
            COPY_DYNFLD(admArg, Adm_Arg, Adm_Arg_Id, currMod, Curr_Modif, Curr_Modif_ObjId);
            /* Retrieve instrument record from local memory (Get by Adm_Arg) */
            ret = DBA_GetMemory(Instr, UNUSED, Adm_Arg, admArg, S_Instr, NULL, &memInstrPtr2, Opti_Local);
            if (ret != RET_SUCCEED || memInstrPtr == NULL)
            {
                /* PMSTA10872 - DDV - 110124 - If record not found, get it from database to fill the optimisation cache */
                /* fill optimisation */
                if ((memInstrPtr2 = ALLOC_DYNST(S_Instr)) == NULL)
                {
                    MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "S_Instr");
                    return(RET_MEM_ERR_ALLOC);
                }

                if (DBA_Get2(Instr, UNUSED, Adm_Arg, admArg, S_Instr, &memInstrPtr2, UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
                {
                    MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, "database",
                                 GET_ID(currMod, Curr_Modif_ObjId));
                    FREE_DYNST(memInstrPtr2, S_Instr);
                    return(RET_DBA_ERR_NODATA);
                }
                FREE_DYNST(memInstrPtr2, S_Instr);

                /* Retrieve instrument record from local memory (Get by Adm_Arg) */
                ret = DBA_GetMemory(Instr, UNUSED, Adm_Arg, admArg, S_Instr, NULL, &memInstrPtr2, Opti_Local);
                if (ret != RET_SUCCEED || memInstrPtr == NULL)
                {
                    MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, "Local Memory",
                                 GET_ID(currMod, Curr_Modif_ObjId));
                    return(RET_DBA_ERR_NODATA);
                }
            }
            /* REF2378 - DDV - 980706 - Update local memory instrument record (Get By Adm_Arg) */
            COPY_DYNFLD(memInstrPtr2, S_Instr, S_Instr_RefCurrId, currMod, Curr_Modif, Curr_Modif_NewCurrId);

            /* can't compute default value for short structure S_Instr */
            /* if (SCPT_ComputeDV(Instr, scptFlagTab, memInstrPtr2, FALSE, TRUE) != 0)
               {
               MSG_SendMesg(RET_SCPT_ERR_SYNTAX, 0, FILEINFO);
               FREE(scptFlagTab);
               DBA_FreeDynStTab(extOpTab, extOpTabNbr, ExtOp);
               DBA_FreeHier(hierHead);
               return(RET_SCPT_ERR_SYNTAX);
               }*/

            /* Free memory allocation */
            FREE(scptFlagTab);
            break;
        }
    }

    /********************************** Begin Connection *************************************/
    /* PMSTA-44508 - connection moved to caller */

#ifdef AAADEBUG
    DEBUG_PRINTMSG("    - Modify currency of all extended operations ...\n");
#endif

    /* Loop on all extended operation records */
    for (int i=0; i<extOpTabNbr; i++)
    {

        /* REF1190 - XDI - 980211 - If modify currency of PPS modify only currency of operation specific to pps
           (Transfert / BP Transfert / Portfolio Transfert / Book value Adjustment) */
        if (objectEn == PtfPosSet &&
            (IS_NULLFLD(extOpTab[i], ExtOp_PortPosSetId) == TRUE ||
             GET_ID(extOpTab[i], ExtOp_PortPosSetId) != GET_ID(currMod, Curr_Modif_PortPosSetId)))
        {
            continue;
        }

        /* REF1190 - XDI - 980211 - If modify currency on portfolio modify only currency of main operation */
        if (objectEn == Ptf &&
            IS_NULLFLD(extOpTab[i], ExtOp_PortPosSetId) == FALSE)
        {
            continue;
        }

        /* REF3076 - DDV - 981130 */
        partialFlg = TRUE;
        while (partialFlg == TRUE)
        {
            partialFlg = FALSE;

            portModifEn = (PORTMODIF_ENUM)GET_ENUM(currMod, Curr_Modif_PortModifEn);     /* REF7264 - LJE - 020131 */
            tmpCurrId = GET_ID(currMod, Curr_Modif_OldCurrId);
            /* REF2977 - DDV - 981116 - Change currency only if needed */
            switch(GET_OBJECT_CST(objectEn)) /* REF8844 - LJE - 030416 */
            {
            case InstrCst: /* REF3076 - DDV - 981126 */
                instrCurrId = (ID_T) 0;
                partialFlg = FALSE;

                /* Instrument */
                if (CMP_DYNFLD(currMod, extOpTab[i], Curr_Modif_ObjId, ExtOp_InstrId, GET_FLD_TYPE(Curr_Modif, Curr_Modif_ObjId)) == 0 &&
                    CMP_DYNFLD(extOpTab[i], currMod, ExtOp_InstrCurrId, Curr_Modif_NewCurrId, GET_FLD_TYPE(Curr_Modif, Curr_Modif_NewCurrId)) != 0)
                {
                    if (instrCurrId == (ID_T) 0)
                        instrCurrId = GET_ID(extOpTab[i], ExtOp_InstrCurrId);
                    else if(instrCurrId != GET_ID(extOpTab[i], ExtOp_InstrCurrId))
                        partialFlg = TRUE;
                }

                /* To Instrument */
                if (CMP_DYNFLD(currMod, extOpTab[i], Curr_Modif_ObjId, ExtOp_ToInstrId, GET_FLD_TYPE(Curr_Modif, Curr_Modif_ObjId)) == 0 &&
                    CMP_DYNFLD(extOpTab[i], currMod, ExtOp_ToInstrCurrId, Curr_Modif_NewCurrId, GET_FLD_TYPE(Curr_Modif, Curr_Modif_NewCurrId)) != 0)
                {
                    if (instrCurrId == (ID_T) 0)
                        instrCurrId = GET_ID(extOpTab[i], ExtOp_ToInstrCurrId);
                    else if(instrCurrId != GET_ID(extOpTab[i], ExtOp_ToInstrCurrId))
                        partialFlg = TRUE;
                }

                /* Adjust Instrument */
                if (CMP_DYNFLD(currMod, extOpTab[i], Curr_Modif_ObjId, ExtOp_AdjInstrId, GET_FLD_TYPE(Curr_Modif, Curr_Modif_ObjId)) == 0 &&
                    CMP_DYNFLD(extOpTab[i], currMod, ExtOp_AdjInstrCurrId, Curr_Modif_NewCurrId, GET_FLD_TYPE(Curr_Modif, Curr_Modif_NewCurrId)) != 0)
                {
                    if (instrCurrId == (ID_T) 0)
                        instrCurrId = GET_ID(extOpTab[i], ExtOp_AdjInstrCurrId);
                    else if(instrCurrId != GET_ID(extOpTab[i], ExtOp_AdjInstrCurrId))
                        partialFlg = TRUE;
                }

                /* Account */
                if (CMP_DYNFLD(currMod, extOpTab[i], Curr_Modif_ObjId, ExtOp_AcctId, GET_FLD_TYPE(Curr_Modif, Curr_Modif_ObjId)) == 0 &&
                    CMP_DYNFLD(extOpTab[i], currMod, ExtOp_AcctCurrId, Curr_Modif_NewCurrId, GET_FLD_TYPE(Curr_Modif, Curr_Modif_NewCurrId)) != 0)
                {
                    if (instrCurrId == (ID_T) 0)
                        instrCurrId = GET_ID(extOpTab[i], ExtOp_AcctCurrId);
                    else if(instrCurrId != GET_ID(extOpTab[i], ExtOp_AcctCurrId))
                        partialFlg = TRUE;
                }

                /* Account 2 */
                if (CMP_DYNFLD(currMod, extOpTab[i], Curr_Modif_ObjId, ExtOp_Acct2Id, GET_FLD_TYPE(Curr_Modif, Curr_Modif_ObjId)) == 0 &&
                    CMP_DYNFLD(extOpTab[i], currMod, ExtOp_Acct2CurrId, Curr_Modif_NewCurrId, GET_FLD_TYPE(Curr_Modif, Curr_Modif_NewCurrId)) != 0)
                {
                    if (instrCurrId == (ID_T) 0)
                        instrCurrId = GET_ID(extOpTab[i], ExtOp_Acct2CurrId);
                    else if(instrCurrId != GET_ID(extOpTab[i], ExtOp_Acct2CurrId))
                        partialFlg = TRUE;
                }

                /* Account 3 */
                if (CMP_DYNFLD(currMod, extOpTab[i], Curr_Modif_ObjId, ExtOp_Acct3Id, GET_FLD_TYPE(Curr_Modif, Curr_Modif_ObjId)) == 0 &&
                    CMP_DYNFLD(extOpTab[i], currMod, ExtOp_Acct3CurrId, Curr_Modif_NewCurrId, GET_FLD_TYPE(Curr_Modif, Curr_Modif_NewCurrId)) != 0)
                {
                    if (instrCurrId == (ID_T) 0)
                        instrCurrId = GET_ID(extOpTab[i], ExtOp_Acct3CurrId);
                    else if(instrCurrId != GET_ID(extOpTab[i], ExtOp_Acct3CurrId))
                        partialFlg = TRUE;
                }

                /* Lock Instrument */
                if (CMP_DYNFLD(currMod, extOpTab[i], Curr_Modif_ObjId, ExtOp_LockInstrId, GET_FLD_TYPE(Curr_Modif, Curr_Modif_ObjId)) == 0 &&
                    CMP_DYNFLD(extOpTab[i], currMod, ExtOp_LockFiCurrId, Curr_Modif_NewCurrId, GET_FLD_TYPE(Curr_Modif, Curr_Modif_NewCurrId)) != 0)
                {
                    if (instrCurrId == (ID_T) 0)
                        instrCurrId = GET_ID(extOpTab[i], ExtOp_LockFiCurrId);
                    else if(instrCurrId != GET_ID(extOpTab[i], ExtOp_LockFiCurrId))
                        partialFlg = TRUE;
                }

                if (instrCurrId != (ID_T) 0)
                {
                    SET_ID(currMod, Curr_Modif_OldCurrId, instrCurrId);
                }
                else
                {
                    continue;
                }
                break;
            case PtfPosSetCst:
            case PtfCst:
                if (CMP_DYNFLD(extOpTab[i], currMod, ExtOp_PtfCurrId, Curr_Modif_NewCurrId, GET_FLD_TYPE(ExtOp, ExtOp_PtfCurrId)) == 0)
                {
                    /*<REF11906-EFE-060815*/
                    if ( CMP_DYNFLD(extOpTab[i], currMod, ExtOp_PtfId, Curr_Modif_ObjId, GET_FLD_TYPE(ExtOp, ExtOp_PtfCurrId)) == 0   ||
                         CMP_DYNFLD(extOpTab[i], currMod, ExtOp_CashPtfCurrId, Curr_Modif_NewCurrId, GET_FLD_TYPE(ExtOp, ExtOp_CashPtfCurrId)) == 0
                        ) /*>REF11906-EFE-060815*/
                    {
                        if (GET_ENUM(currMod, Curr_Modif_PortModifEn) == PortModif_RefCurr)
                            continue;
                        else if (GET_ENUM(currMod, Curr_Modif_PortModifEn) == PortModif_RefSysCurr)
                        {
                            SET_ENUM(currMod, Curr_Modif_PortModifEn, PortModif_SysCurr);
                        }
                    }

                }
                else if (CMP_DYNFLD(extOpTab[i], currMod, ExtOp_PtfCurrId, Curr_Modif_OldCurrId, GET_FLD_TYPE(ExtOp, ExtOp_PtfCurrId)) != 0)
                {
                    COPY_DYNFLD(currMod, Curr_Modif, Curr_Modif_OldCurrId, extOpTab[i], ExtOp, ExtOp_PtfCurrId);
                }
                break;
            }

/* BEGIN DVP343 - 970220 - XMT, change portfolio or instrument currency. Code has been
   moved to function OPE_SetPtfInstrCurrency into file
*/
			if (recoverMode == FALSE) /* PMSTA-38641 - SUK - 240120 */
				ret = OPE_SetPtfInstrCurrency(extOpTab[i], currMod, dbiConn);

            /* REF2977 - DDV - 981116 - reset port modif enum */
            SET_ENUM(currMod, Curr_Modif_PortModifEn, portModifEn);
            SET_ID(currMod, Curr_Modif_OldCurrId, tmpCurrId);

            if (ret != RET_SUCCEED) /* REF3010 - SSO - 981113 : test ret code and exit if error! */
            {
                /* SSO 981105: since FREE_EXTENSION is done in FREE_DYNST, do not free extensions...
                   for (k=0; k<extOpTabNbr; k++)
                   {
                   if (IS_NULLFLD(extOpTab[k], ExtOp_ExtOp_Ext) == FALSE)
                   {
                   FREE_EXTENSION(extOpTab[k], ExtOp_ExtOp_Ext);
                   }
                   }
                   DBA_FreeDynStTab(tmpTab, tmpTabNbr, ExtOp);
                */
                DBA_FreeDynStTab(extOpTab, extOpTabNbr, ExtOp);
                DBA_FreeHier(hierHead);
                return(ret);
            }
        }
/* END DVP343 */
    }

    /* Free all Script for Default Values */
     SCPT_FreeScriptDV(NullEntity); /* PMSTA06772 - 080619 - DDV */

    /*************** REF1402 - DDV - 981022 - Update Synthetic Data *****************/
    /* REF1402 - DDV - 981022 - Add all PtfSynth record in multi access array */
    if ((objectEn == Ptf || objectEn == PtfPosSet) &&
        (GET_ENUM(currMod, Curr_Modif_PortModifEn) == PortModif_RefCurr ||
         GET_ENUM(currMod, Curr_Modif_PortModifEn) == PortModif_RefSysCurr))
    {
#ifdef AAADEBUG
        DEBUG_PRINTMSG("    - Load all synthetic data ...\n");
#endif

        /* Memory allocation for input structure */
        DBA_DYNFLD_STP sPtfSynth = mp.allocDynst(FILEINFO,S_PtfSynth);
        if (sPtfSynth == nullptr)
        {
            DBA_FreeDynStTab(extOpTab, extOpTabNbr, ExtOp);
            DBA_FreeHier(hierHead);
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "S_PtfSynth");
            return(RET_MEM_ERR_ALLOC);
        }

        switch (GET_OBJECT_CST(objectEn)) /* REF8844 - LJE - 030416 */
        {
        case PtfCst:
            COPY_DYNFLD(sPtfSynth, S_PtfSynth, S_PtfSynth_PtfId, currMod, Curr_Modif, Curr_Modif_ObjId);
            break;
        case PtfPosSetCst:
            COPY_DYNFLD(sPtfSynth, S_PtfSynth, S_PtfSynth_PtfId, memPtfPosSetPtr, A_PtfPosSet, A_PtfPosSet_PtfId);
            COPY_DYNFLD(sPtfSynth, S_PtfSynth, S_PtfSynth_PtfPosSetId, memPtfPosSetPtr, A_PtfPosSet, A_PtfPosSet_Id);
            break;
        }

        /* Load portfolio position set */
        if ((ret = DBA_Select2(PtfSynth, UNUSED, S_PtfSynth, sPtfSynth, A_PtfSynth, &ptfSynthTab,
                               UNUSED, UNUSED, &ptfSynthNbr, UNUSED, UNUSED)) != RET_SUCCEED)
        {
            /* SSO 981105: since FREE_EXTENSION is done in FREE_DYNST, do not free extensions...
               for (k=0; k<extOpTabNbr; k++)
               {
               if (IS_NULLFLD(extOpTab[k], ExtOp_ExtOp_Ext) == FALSE)
               {
               FREE_EXTENSION(extOpTab[k], ExtOp_ExtOp_Ext);
               }
               }
               DBA_FreeDynStTab(tmpTab, tmpTabNbr, ExtOp);
            */
            DBA_FreeDynStTab(extOpTab, extOpTabNbr, ExtOp);
            DBA_FreeHier(hierHead);
            return(RET_DBA_ERR_NODATA);
        }

#ifdef AAADEBUG
        DEBUG_PRINTMSG("    - Update all synthetic data ...\n");
#endif
        /* REF6912 - CSY - 010810: sort by ptf, initial_d, global level */
        if(ptfSynthNbr > 0) /* REF6983 - CSY - 011101: avoid message in log */
        {
            TLS_Sort((char*) ptfSynthTab, ptfSynthNbr, sizeof(DBA_DYNFLD_STP),
	                         (TLS_CMPFCT *)DBA_CmpPtfSynthPtfDateGlobal, NULL, SortRtnTp_None); /* REF7264 - LJE - 020131 */
        }

        for (int i=0; i<ptfSynthNbr && ret == RET_SUCCEED; i++)
        {
            /* REF2977 - DDV - 981116 - Update only if needed */
            if (CMP_DYNFLD(ptfSynthTab[i], currMod, A_PtfSynth_CurrId, Curr_Modif_NewCurrId, GET_FLD_TYPE(A_PtfSynth, A_PtfSynth_CurrId)) != 0)
            {
                /* REF6912 - CSY - 010809 */
                if(IS_NULLFLD(ptfSynthTab[i], A_PtfSynth_MktSegtId) == TRUE
                                        &&
                    IS_NULLFLD(ptfSynthTab[i], A_PtfSynth_InstrId) == TRUE)
                {
                    /* memorize position of the global line:
                    update cumuls of currency real/unreal P&L amounts */
                    i0 = i;
                }

                ret = FIN_ConvertPtfSynthCurr(ptfSynthTab[i], GET_ID(currMod, Curr_Modif_NewCurrId));

                if(IS_NULLFLD(ptfSynthTab[i], A_PtfSynth_MktSegtId) == FALSE   /* detail line */
                                            ||
                        IS_NULLFLD(ptfSynthTab[i], A_PtfSynth_InstrId) == FALSE)
                {
                    if (i == i0+1)  /* there must be at least one detail line to reset the cumul */
                    {
                        /* reset 4 currency counters of the global line to zero */
                        FIN_CumulPtfSynthCurrField(ptfSynthTab[i0], ptfSynthTab[i], TRUE);
                    }

                    if (i > i0) /* do not call this function if synthTab[i] is a global synth. (i==i0) */
                    {
                        /* cumul detail lines currency field amounts (i) in global line (i0) */
                        FIN_CumulPtfSynthCurrField(ptfSynthTab[i0], ptfSynthTab[i], FALSE);
                    }
                }
            }
        }

        if (ret != RET_SUCCEED)
        {
            /* SSO 981105: since FREE_EXTENSION is done in FREE_DYNST, do not free extensions...
               for (k=0; k<extOpTabNbr; k++)
               {
               if (IS_NULLFLD(extOpTab[k], ExtOp_ExtOp_Ext) == FALSE)
               {
               FREE_EXTENSION(extOpTab[k], ExtOp_ExtOp_Ext);
               }
               }
               DBA_FreeDynStTab(tmpTab, tmpTabNbr, ExtOp);
            */
            DBA_FreeDynStTab(extOpTab, extOpTabNbr, ExtOp);
            DBA_FreeDynStTab(ptfSynthTab, ptfSynthNbr, A_PtfSynth);
            DBA_FreeHier(hierHead);
            return(RET_DBA_ERR_NODATA);
        }
    }

#ifdef AAADEBUG
    DEBUG_PRINTMSG("    - Starting database transaction ...\n");
#endif

    if (extOpTabNbr > 0 || ptfSynthNbr > 0) /* XAJ 010997 */
    {
        if ((accessPtr = (DBA_ACCESS_STP)CALLOC(extOpTabNbr + ptfSynthNbr, sizeof(DBA_ACCESS_ST))) == NULL)
        {
            /* SSO 981105: since FREE_EXTENSION is done in FREE_DYNST, do not free extensions...
               for (k=0; k<extOpTabNbr; k++)
               {
               if (IS_NULLFLD(extOpTab[k], ExtOp_ExtOp_Ext) == FALSE)
               {
               FREE_EXTENSION(extOpTab[k], ExtOp_ExtOp_Ext);
               }
               }
               DBA_FreeDynStTab(tmpTab, tmpTabNbr, ExtOp);
            */
            DBA_FreeDynStTab(extOpTab, extOpTabNbr, ExtOp);
            DBA_FreeHier(hierHead);
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }
    }
    else
    {
        accessPtr = NULL;
    }

    /******************************** Begin Transaction **************************************/    
    dbiConn.setModifStat(1); /* PMSTA-28916 - LJE - 171214 */

#ifdef AAADEBUG
    DEBUG_PRINTMSG("    - Update portfolio/instrument/system currency in database ...\n");
#endif

    /* REF2977 - DDV - 981116 - always update portfolio to lock record in database */
    /* Update portfolio/instrument/system currency */
    switch(GET_OBJECT_CST(objectEn)) /* REF8844 - LJE - 030416 */
    {
    case PtfPosSetCst:
        /* Update portfolio position set record */
        ret = DBA_Update2(PtfPosSet, DBA_ROLE_CURRENCY_MODIF, A_PtfPosSet, portPosSet, DBA_SET_CONN|DBA_NO_CLOSE, dbiConn);
        break;
    case PtfCst:
        /* Update portfolio record */
        ret = DBA_Update2(Ptf, DBA_ROLE_CURRENCY_MODIF, A_Ptf, portfolio, DBA_SET_CONN|DBA_NO_CLOSE, dbiConn);

		dbiConn.getConnStructPtr()->disableEventSchedNotification = true;   /* PMSTA -25163 - 041116 - Sridhara*/
        break;
    case InstrCst:
               /* PMSTA-44508 JBC - 210405 */
        std::string instrBusEntityCd;
        if(GEN_IsMultiEntity())
        {
            instrBusEntityCd = GET_CODE(currMod,Curr_Modif_InstrBusEntityCd);
        }

        if(GEN_IsMultiEntity() == false || instrBusEntityCd == SYS_GetThreadCurrBusinessEntity())
        {   /* Update instrument record */    
            ret = DBA_Update2(Instr, DBA_ROLE_CURRENCY_MODIF, A_Instr, instrument, DBA_SET_CONN|DBA_NO_CLOSE, dbiConn);
        }
        dbiConn.getConnStructPtr()->disableEventSchedNotification = true;  /* PMSTA-13613 - 070212 - PMO */
        
        break;
    }

#ifdef AAADEBUG
    DEBUG_PRINTMSG("    - Update all operations in database ...\n");
#endif

    /* Reset counter */
    updExtOpNbr = -1;

    for (int i=0; i<extOpTabNbr; i++)
    {
        /* The ExtOp_CurrencyModifyFlg should always be set. */
        SET_FLAG(extOpTab[i], ExtOp_NoCheckImpactFlg, TRUE);    /* REF1487 */ /* REF3010 - SSO - 981110 : ExtOp_CurrencyModifyFlg renamed */
        SET_FLAG(extOpTab[i], ExtOp_NoCheckSynthAdminFlg, TRUE);
        if(GEN_UseDispatcher() == false)
        {   /* PMSTA-44508 use currmodif prio to hide from active fusion until complete */
            SET_ENUM(extOpTab[i], ExtOp_FusionPrioEn, EventSchedFusPrio_CurrModif);
        }

        if (DATE_Cmp(fusionDate, GET_DATE(extOpTab[i], ExtOp_BeginDate)) > 0) 
        {
			fusionDate = GET_DATE(extOpTab[i], ExtOp_BeginDate);
		}

        /* BUG335. 19970410. GRD */
        SET_ENUM(extOpTab[i], ExtOp_DbStatusEn, ExtOpDbStatus_ToUpdate);

        /* REF1190 - XDI - 980211 - If modify currency of PPS don't update operation from other pps */
        if (objectEn == PtfPosSet &&
            IS_NULLFLD(extOpTab[i], ExtOp_PortPosSetId) == FALSE &&
            GET_ID(extOpTab[i], ExtOp_PortPosSetId) != GET_ID(currMod, Curr_Modif_PortPosSetId))
        {
            continue;
        }

        /* REF1190 - XDI - 980211 - If modify currency of PPS don't update specific operation from main */
        if (objectEn == PtfPosSet &&
            IS_NULLFLD(extOpTab[i], ExtOp_PortPosSetId) == TRUE &&
            (GET_ENUM(extOpTab[i], ExtOp_NatureEn) == OpNat_Transf ||
             GET_ENUM(extOpTab[i], ExtOp_NatureEn) == OpNat_BpTransf ||
             GET_ENUM(extOpTab[i], ExtOp_NatureEn) == OpNat_PtfTransf ||
             GET_ENUM(extOpTab[i], ExtOp_NatureEn) == OpNat_BookAdjust))
        {
            continue;
        }

        /* REF1190 - XDI - 980211 - If modify currency on portfolio modify only currency of main operation */
        if (objectEn == Ptf &&
            IS_NULLFLD(extOpTab[i], ExtOp_PortPosSetId) == FALSE)
        {
            continue;
        }

        /* Set counter */
        updExtOpNbr++;

        /* Fill up records array */
        accessPtr[updExtOpNbr].action = Update;
        accessPtr[updExtOpNbr].role   = UNUSED;
        accessPtr[updExtOpNbr].object = EOp;
        accessPtr[updExtOpNbr].entity = ExtOp;
        accessPtr[updExtOpNbr].stamp  = 0;
        accessPtr[updExtOpNbr].data   = extOpTab[i];
    }

    /* REF1402 - DDV - 981022 - Add all PtfSynth record in multi access array */
    for (int i=0; i<ptfSynthNbr; i++)
    {
        /* Set counter */
        updExtOpNbr++;

        /* Fill up records array */
        accessPtr[updExtOpNbr].action = Update;
        accessPtr[updExtOpNbr].role   = UNUSED;
        accessPtr[updExtOpNbr].object = PtfSynth;
        accessPtr[updExtOpNbr].entity = A_PtfSynth;
        accessPtr[updExtOpNbr].stamp  = 0;
        accessPtr[updExtOpNbr].data   = ptfSynthTab[i];
    }

     if (updExtOpNbr+1)  /* XAJ 010997 */
     { 
		/*Addition Check before update to check if the Fusion is running on the portfolio*/
		if (GET_OBJECT_CST(objectEn) == PtfCst || GET_OBJECT_CST(objectEn) == InstrCst) 
        {

            SET_DICT(sEventSched, S_EventSched_EntityDictId, (GET_OBJECT_CST(objectEn) == PtfCst ? GET_DICT(domainArg, A_Domain_DimPtfDictId) : GET_DICT(domainArg, A_Domain_DimInstrDictId)));
			SET_ID(sEventSched, S_EventSched_ObjId, GET_ID(currMod, Curr_Modif_ObjId));
			if ((DBA_Check(EventSched, DBA_ROLE_CURRENCY_MODIF, S_EventSched, sEventSched, UNUSED, nullptr, nullptr) == RET_SUCCEED) &&
                (GET_INT(sEventSched, S_EventSched_ReturnStatus) > 0)) /* PMSTA-46404 - DDV - 211004 */
            {
				if (accessPtr)
				{
					FREE(accessPtr);
				}
				DBA_FreeHier(hierHead);
				DBA_FreeDynStTab(extOpTab, extOpTabNbr, ExtOp);
                msg = GET_OBJECT_CST(objectEn) == PtfCst
                        ? SYS_Stringer("Modify Currency (",GET_CODE(currMod, Curr_Modif_OldCurrCd)," -> ",GET_CODE(currMod, Curr_Modif_NewCurrCd),
                            ") on portfolio [",GET_CODE(portfolio, A_Ptf_Cd),"] aborted as Fusion is pending or running on portfolio. Retry after fusion complete.")
                        : SYS_Stringer("Modify Currency (",GET_CODE(currMod, Curr_Modif_OldCurrCd)," -> ",GET_CODE(currMod, Curr_Modif_NewCurrCd),
                            ") on instrument [",GET_CODE(instrument, A_Instr_Cd),"] aborted as Fusion is pending or running on portfolios with the instrument. Retry after fusion complete.");

                MSG_LogSrvMesg(UNUSED, UNUSED,msg.c_str());
                MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, msg.c_str());
				return(RET_FIN_ERR_FUSLOCK);
			}
		}
        
        ret = DBA_MultiAccess(accessPtr,
                            updExtOpNbr+1,
                            commitSz,
                            DBA_SET_CONN|DBA_NO_CLOSE|DBA_NO_ERROR,
                            dbiConn);
    }

    if (ret == RET_SUCCEED && dbiConn.emptyMsg())
    {
        /* REF2977 - DDV - Check if all operation are modified */

        /* Alloc select structure */
        DBA_DYNFLD_STP admArgSt = mp.allocDynst(FILEINFO,Adm_Arg);
        if (admArgSt != nullptr)
        {
            COPY_DYNFLD(admArgSt, Adm_Arg, Adm_Arg_Id, currMod, Curr_Modif, Curr_Modif_ObjId);
            COPY_DYNFLD(admArgSt, Adm_Arg, Adm_Arg_EntDictId, currMod, Curr_Modif, Curr_Modif_EntDictId);
            SET_DATETIME(admArgSt, Adm_Arg_Date, beginTranDateTime);

            /* select all unmodified operation */
            ret = DBA_Select2(Op, UNUSED, Adm_Arg, admArgSt, S_Op, &opTab, DBA_SET_CONN|DBA_NO_CLOSE, UNUSED, &opNbr, dbiConn, UNUSED);

            if (ret == RET_SUCCEED && opNbr > 0)
            {
#define CODENBR 10

                codeStrLen = CODENBR * (GET_MAXDATALEN(CodeType) + ENUM_T_LEN + NUMBER_T_LEN + 5) + 1 + 11; /* PMSTA-33077 - DLA - 181011 */

                if ((opCodeStr = (char *)CALLOC(1, codeStrLen)) == NULL) /* REF7264 - LJE - 020131 */
                {
                    MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "Adm_Arg");
                    ret=RET_MEM_ERR_ALLOC;
                }
                else
                {
                    memset(opCodeStr, 0, codeStrLen);
                    for (int i=0 ; i<opNbr && i<CODENBR; i++)
                    {
                        if (i>0)
                            strcat(opCodeStr, " / ");

                        strPtr= &opCodeStr[strlen(opCodeStr)];

                        sprintf(strPtr, "%s-%d-%d", GET_CODE(opTab[i], S_Op_Cd),
                                GET_ENUM(opTab[i], S_Op_StatEn),
                                (int)GET_NUMBER(opTab[i], S_Op_SequenceNo));
                    }

                    if (opNbr > CODENBR)
                    {
                        strcat(opCodeStr, " / . . . . ");
                    }

                    MSG_SendMesg(RET_FIN_ERR_MODIFCURR_UPDFAIL, 0,
                                 FILEINFO, opNbr, opCodeStr);

                    FREE(opCodeStr); /* DDV - 101119 - Memory leak */

                    ret=RET_FIN_ERR_MODIFCURR_UPDFAIL;
                }
            }
        }
        else
        {
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "Adm_Arg");
            ret=RET_MEM_ERR_ALLOC;
        }
    }

    if (ret == RET_SUCCEED && dbiConn.emptyMsg())
    {
        opUpdCount += extOpTabNbr;
    }
    else
    {
        dbiConn.sendAllMsgFromMA();
    }

    /******************************** End Transaction **************************************/
    dbiConn.setModifStat(0); /* PMSTA-28916 - LJE - 171214 */

#ifdef AAADEBUG
    DEBUG_PRINTMSG("    - Ending database transaction ...\n");
#endif

    /* Free memory allocations */
    if (accessPtr)  /* XAJ 010997 */
    {
        FREE(accessPtr);
    }

    /* Free array with extended operations */
    /* SSO 981105: since FREE_EXTENSION is done in FREE_DYNST, do not free extensions...
       for (k=0; k<tmpTabNbr; k++)
       {
       FREE_EXTENSION(tmpTab[k], ExtOp_ExtOp_Ext);
       }
       DBA_FreeDynStTab(tmpTab, tmpTabNbr, ExtOp);
    */
    DBA_FreeDynStTab(extOpTab, extOpTabNbr, ExtOp);
    DBA_FreeHier(hierHead);

    return(ret);
}


/************************************************************************
*   Function             : FIN_ReplaceChildPtfWithParent()
*
*   Description          :
*
*   Arguments            :
*
*   Return               :
*
*   Creation Date        :
*
*************************************************************************/
RET_CODE FIN_SetTopHierPtf(DBA_DYNFLD_STP	domainPtr,
					   DBA_DYNFLD_STP	*ptfList,
					   int				ptfNbr)
{
	int i;
	ID_T parPtfId = -1;
	RET_CODE ret = RET_GEN_ERR_INVARG;

	/* Find top Parent */
	for (i=0; i < ptfNbr; i++)
	{
		if (IS_NULLFLD(ptfList[i], A_Ptf_ParentPortId))
		{
			parPtfId = GET_ID(ptfList[i], A_Ptf_Id);
			ret = RET_SUCCEED;
			break;
		}
	}

	if (ret == RET_SUCCEED)
		SET_ID(domainPtr, A_Domain_PtfObjId, parPtfId);

	return (ret);
}

/************************************************************************
*   Function             : DBA_InitStratLnk()
*
*   Description          : Initialize dom_port and dom_strat tables according to
*                          ptf. and strat dimensions :
*
*                          - if ptf dimension is a constraint list,
*                            enumerate the list and fill dom_port
*
*                          - if strat dimension is a constraint list,
*                            enumerate the list and fill dom_strat
*
*   Arguments            : searchLnkSt : dyn. struct A_SearchLnk
*
*   Return               : RET_SUCCEED             : if ok
*                          RET_DBA_ERR_CONNOTFOUND : if no connection found
*                          RET_DBA_ERR_DBPROBLEM   : if conn/DB problem
*                          RET_GEN_ERR_INVARG      : if problem with input arg.
*
*   Creation Date        : 25.09.95 - PEC
*   Last Modif           : 12.11.96 - PEC - Ref.: DVP249
*              		   REF2755 - SSO - 990215
*   			   REF6168 - RAK - VST - 011009
*                  REF7395 - CSY - 020322:  now EXTERN
*
*************************************************************************/
RET_CODE DBA_InitStratLnk(DBA_DYNFLD_STP     searchLnkSt,
                          int               *connectNo,
                          ID_T              **ptfIdTab,
                          int               *ptfIdNbr,
                          DBA_DYNFLD_STP     domainPtrParam)
{
	DBA_DYNFLD_STP  admArg      = NULL;
        DBA_DYNFLD_STP  sList       = NULL;
        OBJECT_ENUM     dimObject = NullEntity;
        LISTNAT_ENUM    nature;
        int             statusDomPort=TRUE;
        int             statusDomStrat=TRUE;
        int             ptf;
        int             buffLen=0;
        char            sep;
        RET_CODE        retCode; /* REF5062 - SSO - 000824 */
        DBA_DYNFLD_STP  domainPtr=domainPtrParam;
		FLAG_T			launchLoadParentHierPtfFlg = FALSE;	/* PMSTA04637-CHU-080107 */
		DBA_DYNFLD_STP	*ptfsOutput=NULL;	/* PMSTA04637-CHU-080107 */
		int				ptfsRows=0;	/* PMSTA04637-CHU-080107 */
		int				selOptions = DBA_SET_CONN | DBA_NO_CLOSE;	/* PMSTA04637-CHU-080107 */
		MemoryPool      mp;             /* PMSTA-49169 - MSS - 22062022 Fix memory leaks */

        /* REF8778 - DDV - if no domain given in parameter, use the domain stored in thread */
        if (domainPtr == NULL)
           domainPtr = DBA_GetDomainPtr(-1);

        if (connectNo == NULL)
        {
            return(RET_GEN_ERR_INVARG);
        }

        /* Get a free connection in the connection list */
        /* REF8489 - DDV - 021119 - ONLY if no connection given */
        if ((*connectNo) == NO_VALUE)
        {
            if ((*connectNo = DBA_GetConnection(SqlServer)) == DBA_CONN_NOT_FOUND)
            {
                return(RET_DBA_ERR_CONNOTFOUND);
            }
        }
        DbiConnectionHelper dbiConnHelper(connectNo);

        /* DVP249 */
        /* REF3729 - RAK - 990615 - Create #dom_strat (and #dom_port) */
        /* REF5062 - SSO - 000824 ret test */
        if ((retCode = DBA_CreateDomPortAndDomStratTables(*connectNo, TRUE)) != RET_SUCCEED)
        {
            return(retCode);
        }

		if (domainPtr != NULL)
		{
			if (IS_NULLFLD(domainPtr, A_Domain_FullLoadHierProcessedFlg) == TRUE)
				SET_FLAG(domainPtr, A_Domain_FullLoadHierProcessedFlg, FALSE);

			if (GET_FLAG(domainPtr, A_Domain_FullLoadHierProcessedFlg) == FALSE)
			{
				/* PMSTA04637-CHU-080107 - Fill dom_port with Bottom-Top potfolio hierarchy */
				if ((GET_ENUM(domainPtr, A_Domain_LoadHierFlg) == LoadHierPtf_Full ||
					 GET_ENUM(searchLnkSt, A_SearchLnk_LoadHierFlg) == LoadHierPtf_Full)
					&&
					(GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_PreTradeCheckStrat ||
					 GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_ReconcStrat        ||
					 GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_CheckStrat      ||
                       GET_ENUM(domainPtr, A_Domain_HierHoldCheckFlg) ==  Hier_Yes
                        /* ||
					to set if we decide to extend this new load hier to this functionality */
					 /* GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_AllocateOrder   ||
					 not necessary OCS expands already the portfolio hierarchy
					 GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_CheckHoldingConstraints*/))
				{
					launchLoadParentHierPtfFlg = TRUE;
				}
			}
			else
			{
				/* Toggle flag for next time */
				SET_FLAG(domainPtr, A_Domain_FullLoadHierProcessedFlg, FALSE);
			}
		}

        /* HANDLE PORTFOLIO DIMENSION */
        if (ptfIdNbr == NULL || *ptfIdNbr == 0)
        {
            /* Retrieve Portfolio Dimension from SearchLnk */
            if (GET_DICT(searchLnkSt, A_SearchLnk_DimPortDictId) == 0)
            {
                dimObject = NullEntity;
            }
            else
            {
                DBA_GetObjectEnum(GET_DICT(searchLnkSt, A_SearchLnk_DimPortDictId), &dimObject);
            }

            /* If PORTFOLIO DIMENSION is a list */
            if (dimObject == List)
            {
                if ((admArg = ALLOC_DYNST(Adm_Arg)) == NULL)
                {
                    DBA_DelDomPortAndDomStratTables(*connectNo, TRUE);
                    return(RET_MEM_ERR_ALLOC);
                }

                if ((sList = ALLOC_DYNST(S_List)) == NULL)
                {
                    DBA_DelDomPortAndDomStratTables(*connectNo, TRUE);
                    FREE_DYNST(admArg, Adm_Arg);
                    return(RET_MEM_ERR_ALLOC);
                }

                COPY_DYNFLD(admArg, Adm_Arg, Adm_Arg_Id, searchLnkSt, A_SearchLnk, A_SearchLnk_PortObjId);
                /* Get the LIST record */
                if (DBA_Get2(List,
                             UNUSED,
                             Adm_Arg,
                             admArg,
                             S_List,
                             &sList,
                             UNUSED,
                             UNUSED,
                             UNUSED) != RET_SUCCEED)
                {
                    DBA_DelDomPortAndDomStratTables(*connectNo, TRUE);
                    FREE_DYNST(admArg, Adm_Arg);
                    FREE_DYNST(sList, S_List);
                    return(RET_DBA_ERR_NODATA);
                }

                /* If the Ptf list is a constraint list */
                if ((nature = (LISTNAT_ENUM) GET_ENUM(sList, S_List_NatEn)) == ListNat_Constr ||
                     nature == ListNat_Search ||
                     nature == ListNat_Hierarch)
                {
                    DICT_T      entDictId;

                    DBA_GetDictId(Ptf, &entDictId);

                    /* Insert portfolioes Id from the Constraint List into dom_port_strat */
                    SERV_ListMgm (ListMgmFct_LoadStratLnk,
                                  entDictId,
                                  GET_ID(sList, S_List_Id),
                                  NULL,
                                  *dbiConnHelper.getConnection(),
                                  searchLnkSt);

                    statusDomPort = FALSE;
                }

                FREE_DYNST(admArg, Adm_Arg);
                FREE_DYNST(sList, S_List);
            }
            else if (dimObject == QuickSearch) /* REF4611 - RAK - 000501 - Quick search in Domain */
            {
                DICT_T          entDictId;
                RET_CODE        ret=RET_SUCCEED;
				DBA_DYNFLD_STP  tascJobSt=NULL; /* PMSTA08246 - LJE - 090624 */
                DBA_GetDictId(Ptf, &entDictId);

                if (domainPtr != NULL)
                {
					/* PMSTA08246 - LJE - 090615 */
					if ((IS_NULLFLD(domainPtr, A_Domain_PtfListDef) == TRUE ||
						IS_NULLFLD(domainPtr, A_Domain_ChunkNumber) == FALSE) &&
						IS_NULLFLD(domainPtr, A_Domain_JobReference) == FALSE)
					{
						if ((tascJobSt = ALLOC_DYNST(A_TascJob)) != NULL  &&
							DBA_Get2(TascJob,
									 UNUSED,
									 A_Domain,
									 domainPtr,
		 							 A_TascJob,
									 &tascJobSt,
									 selOptions,
									 connectNo,
									 UNUSED) == RET_SUCCEED  &&
							tascJobSt != NULL                &&
							IS_NULLFLD(tascJobSt, A_TascJob_PortfoliosetTbName) == FALSE)
						{
                            DBA_DYNFLD_STP argument =  ALLOC_DYNST(Arg_Test);

                            if (argument != NULL)
                            {
                                SET_ID(argument, Arg_Test_Id, GET_ID(tascJobSt, A_TascJob_Id));
                                if (IS_NULLFLD(domainPtr, A_Domain_ChunkNumber) == FALSE)
                                    SET_INT(argument, Arg_Test_Int, GET_INT(domainPtr, A_Domain_ChunkNumber));

								SET_ENUM(argument, Arg_Test_Enum, TslJobPtfCompNat_Untreated); /* PMSTA13876 - DDV - 130905 */

				                if ((ret = DBA_Notif2(TascJob,
									                UNUSED,
									                Arg_Test,
									                argument,
									                selOptions,
									                connectNo,
									                UNUSED)) != RET_SUCCEED)
				                {
                                    FREE_DYNST(argument, Arg_Test);
								    FREE_DYNST(tascJobSt, A_TascJob);
								    DBA_DelDomPortAndDomStratTables(*connectNo, TRUE);
								    return(ret);
    							}

                    			FREE_DYNST(argument, Arg_Test);
                           }
						}

						FREE_DYNST(tascJobSt, A_TascJob);
					}
					else
					{
						/* Insert portfolioes Ids from the Quick Search List into #dom_port */
                        if ((ret = SERV_ListMgm(ListMgmFct_LoadStratLnk,
                                                entDictId,
                                                0,
                                                GET_STRING(domainPtr, A_Domain_PtfListDef),
                                                *dbiConnHelper.getConnection(),
                                                nullptr)) != RET_SUCCEED)
						{
							DBA_DelDomPortAndDomStratTables(*connectNo, TRUE);
							return(ret);
						}
					}
                }
                else
                {
                    DBA_DelDomPortAndDomStratTables(*connectNo, TRUE);
                    MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_InitStratLnk", "domain not found");
                    MSG_RETURN(RET_GEN_ERR_INVARG);
                }
            }
			else if (dimObject == Ptf && domainPtr != NULL && launchLoadParentHierPtfFlg==TRUE) /* PMSTA04637-CHU-080116 : needed to populate dom_port */
			{
				char *buff = (char *)CALLOC(1, 2048); /* REF7264 - LJE - 020131 */ /*REF10722-BRO-060925*/
				/* init #dom_port according to give ptf ids (NB: strategy dim is forced to ALL) */
				sprintf(buff, "insert into #dom_port (id,port_pos_set_id,hier_port_id,fusion_date_rule_e) select id, 0, null, 0 " /* PMSTA-20159 - TEB - 150624 */ /* MIGR R4.00 STEP6 - LJE - 020816 */ /*REF10722-BRO-060922*/
					  "from portfolio_vw where id in (%*" szFormatId")", ID_T_LEN, GET_ID(domainPtr, A_Domain_PtfObjId)); /* DLA - PMSTA08801 - 100209 */

				if ( DBA_SqlExec(buff, *connectNo, DBA_SET_CONN) != RET_SUCCEED)
				{
					FREE(buff);
					DBA_DelDomPortAndDomStratTables(*connectNo, TRUE);
					return(RET_GEN_ERR_NOACTION);
				}

				FREE(buff);

				statusDomPort = FALSE;
			}
			else if (dimObject == DomainPtfCompo && domainPtr != NULL) /* PMSTA-36175 - PM Profile Phase1 changes - Kramadevi - 02072019 */
			{
                RET_CODE  ret     = RET_SUCCEED;
				char	            buffer[1024];
                DBA_DYNFLD_STP      tascJobSt = NULL;

                if (IS_NULLFLD(domainPtr, A_Domain_JobReference) == FALSE)
                {
                    if ((tascJobSt = ALLOC_DYNST(A_TascJob)) != NULL &&
                        DBA_Get2(TascJob,
							     UNUSED,
                                 A_Domain,
                                 domainPtr,
                                 A_TascJob,
                                 &tascJobSt,
                                 selOptions,
                                 connectNo,
                                 UNUSED) == RET_SUCCEED &&
                        tascJobSt != NULL &&
                        IS_NULLFLD(tascJobSt, A_TascJob_PortfoliosetTbName) == FALSE)
                    {
                        DBA_DYNFLD_STP argument = ALLOC_DYNST(Arg_Test);

                        if (argument != NULL)
                        {
                            SET_ID(argument, Arg_Test_Id, GET_ID(tascJobSt, A_TascJob_Id));
                            if (IS_NULLFLD(domainPtr, A_Domain_ChunkNumber) == FALSE)
                                SET_INT(argument, Arg_Test_Int, GET_INT(domainPtr, A_Domain_ChunkNumber));
                            SET_ENUM(argument, Arg_Test_Enum, TslJobPtfCompNat_Untreated);

                            if ((ret = DBA_Notif2(TascJob,
                                                  UNUSED,
                                                  Arg_Test,
                                                  argument,
                                                  selOptions,
                                                  connectNo,
                                                  UNUSED)) != RET_SUCCEED)
                            {
                                FREE_DYNST(argument, Arg_Test);
                                FREE_DYNST(tascJobSt, A_TascJob);
                                DBA_DelDomPortAndDomStratTables(*connectNo, TRUE);
                                return(ret);
                            }
                            FREE_DYNST(argument, Arg_Test);
                        }
                    }
                    FREE_DYNST(tascJobSt, A_TascJob);
                }
                else
                {
                    sprintf(buffer,
                            "insert into #dom_port (id,port_pos_set_id,hier_port_id,fusion_date_rule_e) "
                            "select dpc.portfolio_id, 0, null, 0 "
                            "from %s dpc, %s p "
                            "where dpc.function_result_id=%" szFormatId" and p.id = dpc.portfolio_id ",
                            SCPT_GetViewName(DomainPtfCompo, false).c_str(),
                            SCPT_GetViewName(Ptf, false).c_str(),
                            GET_ID(domainPtr, A_Domain_FctResultId));

                    sprintf(buffer + strlen(buffer), " and #MAIN_DLM_CHECK(p, portfolio)");

                    if (DBA_SqlExec(buffer, *connectNo, DBA_SET_CONN) != RET_SUCCEED)
                    {
                        DBA_DelDomPortAndDomStratTables(*connectNo, TRUE);
                        return(RET_GEN_ERR_NOACTION);
                    }
                    statusDomPort = FALSE;
                }
			}
        }
		else
		{
			/* PMSTA-51847 - SRN - 31012023*/
			int MaxNoOfSqlInsert = 0, min_limit = 0,
			max_limit = (*ptfIdNbr >= MAX_NUMBER_EXP_IN_LIST) ? MAX_NUMBER_EXP_IN_LIST : *ptfIdNbr;	/* Maximum limit for portfolio. If ptfIdNbr is greater, then maxlimit will be 999 else maxlimit is ptfIdNbr. */
			MaxNoOfSqlInsert = *ptfIdNbr / MAX_NUMBER_EXP_IN_LIST;									/* Maximum number of iteration to execute a loop. */
			MaxNoOfSqlInsert = MaxNoOfSqlInsert + 1;												/* Default to iterate once, if the potrfolio count is less than 1000 or it exceeds 1000. */

			while (MaxNoOfSqlInsert > 0 && (*ptfIdNbr) > 0)
			{
				char *buff = (char *)CALLOC(1, 2048); /* REF7264 - LJE - 020131 */ /*REF10722-BRO-060925*/
				/* init #dom_port according to give ptf ids (NB: strategy dim is forced to ALL) */
				sprintf(buff, "insert into #dom_port (id,port_pos_set_id,hier_port_id,fusion_date_rule_e) select id, 0, null, 0 " /* PMSTA-20159 - TEB - 150624 */ /* MIGR R4.00 STEP6 - LJE - 020816 */ /*REF10722-BRO-060922*/
					"from portfolio_vw where id in (");

				buffLen = SYS_StrLen(buff);
				sep = ' ';

				buff = (char *)REALLOC(buff, (buffLen + (*ptfIdNbr)*(ID_T_LEN + 1) + 2) * sizeof(char)); /* REF7264 - LJE - 020131 */
				for (ptf = min_limit; ptf < max_limit; ptf++)	/* changed the initial value of for loop to min_limit and end value to max_limit */
				{
					sprintf(buff + buffLen, "%c%*" szFormatId, sep, ID_T_LEN, (*ptfIdTab)[ptf]); /* DLA - PMSTA08801 - 100209 */
					buffLen += ID_T_LEN + 1;
					sep = ',';
				}
				sprintf(buff + buffLen, ")");

				if (DBA_SqlExec(buff, *connectNo, DBA_SET_CONN) != RET_SUCCEED)
				{
					FREE(buff);
					DBA_DelDomPortAndDomStratTables(*connectNo, TRUE);
					return(RET_GEN_ERR_NOACTION);
				}

				/* PMSTA-51847 - SRN - 31012023*/
				MaxNoOfSqlInsert--;				/* Decrement this value to found next iteration. */
				if (MaxNoOfSqlInsert == 1)		/* If it was last iteration, */
				{
					min_limit = max_limit;	/* change the max limit to min. */
					max_limit = *ptfIdNbr;	/* ptfIdNbr to max. */
				}
				else
				{
					min_limit = max_limit;					/* If the MaxNoOfSqlInsert is greater than 1, change the max limit to min and */
					max_limit += MAX_NUMBER_EXP_IN_LIST;	/* max limit will be addition of 999, for every iteration. */
				}
				FREE(buff);
			}

            statusDomPort = FALSE;
        }

		/* PMSTA04637-CHU-080116 : needed to populate dom_port */
		if (launchLoadParentHierPtfFlg == TRUE && domainPtr != NULL)
		{
			/* portfolio lists : fill #dom_port and construct ptfIdTab */
			if (ptfIdNbr != NULL && *ptfIdNbr == 0 && dimObject != Ptf)
			{
				DBA_DYNFLD_STP *ptfTabPtr;
				int ptfNbrPtr;

				if ((DBA_Select2(Ptf, UNUSED, A_Domain, domainPtr,
								  A_Ptf, &ptfTabPtr,
								  DBA_SET_CONN|DBA_NO_CLOSE, UNUSED, &ptfNbrPtr, &*connectNo, UNUSED)) == RET_SUCCEED)
				{
					DBA_DelDomPortAndDomStratTables(*connectNo, TRUE);

					/* PMSTA-51847 - SRN - 31012023*/
					int MaxNoOfSqlInsert = 0, min_limit = 0,
						max_limit = (ptfNbrPtr >= MAX_NUMBER_EXP_IN_LIST) ? MAX_NUMBER_EXP_IN_LIST : ptfNbrPtr;	/* Maximum limit for portfolio. If ptfNbrPtr is greater, then maxlimit will be 999 else maxlimit is ptfNbrPtr. */
					MaxNoOfSqlInsert = ptfNbrPtr / MAX_NUMBER_EXP_IN_LIST;										/* Maximum number of iteration to execute a loop. */
					MaxNoOfSqlInsert = MaxNoOfSqlInsert + 1;													/* Default to iterate once, if the potrfolio count is less than 1000 or it exceeds 1000. */


					while (MaxNoOfSqlInsert > 0)
					{
						char *buff = (char *)CALLOC(1, 2048); /* REF7264 - LJE - 020131 */ /*REF10722-BRO-060925*/

						(*ptfIdTab) = (ID_T *)REALLOC((*ptfIdTab), (ptfNbrPtr + 1) * sizeof(ID_T));
						*ptfIdNbr = 0;

						/* init #dom_port according to give ptf ids (NB: strategy dim is forced to ALL) */
						sprintf(buff, "insert into #dom_port (id,port_pos_set_id,hier_port_id,fusion_date_rule_e) select id, 0, null, 0 " /* PMSTA-20159 - TEB - 150624 */ /* MIGR R4.00 STEP6 - LJE - 020816 */ /*REF10722-BRO-060922*/
							"from portfolio_vw where id in (");

						buffLen = SYS_StrLen(buff);
						sep = ' ';

						buff = (char *)REALLOC(buff, (buffLen + (ptfNbrPtr)*(ID_T_LEN + 1) + 2) * sizeof(char)); /* REF7264 - LJE - 020131 */
						for (*ptfIdNbr = min_limit; *ptfIdNbr < max_limit; (*ptfIdNbr)++)	/* changed the initial value of for loop to min_limit and end value to max_limit */
						{
							(*ptfIdTab)[*ptfIdNbr] = GET_ID(ptfTabPtr[*ptfIdNbr], A_Ptf_Id);
							sprintf(buff + buffLen, "%c%*" szFormatId, sep, ID_T_LEN, (*ptfIdTab)[*ptfIdNbr]); /* DLA - PMSTA08801 - 100209 */
							buffLen += ID_T_LEN + 1;
							sep = ',';
						}
						sprintf(buff + buffLen, ")");

						if (DBA_SqlExec(buff, *connectNo, DBA_SET_CONN) != RET_SUCCEED)
						{
							FREE(buff);
							DBA_DelDomPortAndDomStratTables(*connectNo, TRUE);
							return(RET_GEN_ERR_NOACTION);
						}

						/* PMSTA-51847 - SRN - 31012023*/
						MaxNoOfSqlInsert--;				/* Decrement this value to found next iteration. */
						if (MaxNoOfSqlInsert == 1)		/* If it was last iteration, */
						{
							min_limit = max_limit;	/* change the max limit to min. */
							max_limit = ptfNbrPtr;	/* ptfNbrPtr to max. */
						}
						else
						{
							min_limit = max_limit;					/* If the MaxNoOfSqlInsert is greater than 1, change the max limit to min and */
							max_limit += MAX_NUMBER_EXP_IN_LIST;	/* max limit will be addition of 999, for every iteration. */
						}
						FREE(buff);
					}

					mp.owner(ptfTabPtr, ptfNbrPtr);        /* PMSTA-49169 - MSS - 22062022 Fix memory leaks */

					statusDomPort = FALSE;

					SET_NULL_ID(searchLnkSt, A_SearchLnk_PortObjId);
					SET_FLAG(searchLnkSt, A_SearchLnk_LoadParentFlg, FALSE);
				}
			}

			/* Fill dom_port with Bottom-Top potfolio hierarchy */
			/* Send an Init request to populate dom_port with parent portfolios*/
			if (DBA_Notif(Ptf,
						  DBA_ROLE_TOPHIERPTF,
						  NullDynSt,
						  NULL,
						  &*connectNo,
						  DBA_SET_CONN | DBA_NO_CLOSE) != RET_SUCCEED)
			{
				DBA_DelDomPortAndDomStratTables(*connectNo, TRUE);
				return(RET_GEN_ERR_NOACTION);
			}

			/* Copy #dom_port to #vector_id */
			if (DBA_Notif(Ptf,
						  DBA_ROLE_LOAD_STRAT_LNK,
						  NullDynSt,
						  NULL,
						  &*connectNo,
						  DBA_SET_CONN | DBA_NO_CLOSE) != RET_SUCCEED)
			{
				DBA_DelDomPortAndDomStratTables(*connectNo, TRUE);
				return(RET_GEN_ERR_NOACTION);
			}

			/* Select portfolios */
			if (DBA_Select2(Ptf,
							DBA_ROLE_LOAD_STRAT_LNK,
							NullDynSt,
							NULL,
							A_Ptf,
							&ptfsOutput,
							selOptions,
							UNUSED,
							&ptfsRows,
							&*connectNo,
							UNUSED) != RET_SUCCEED)
			{
				DBA_DelDomPortAndDomStratTables(*connectNo, TRUE);
				return(RET_GEN_ERR_NOACTION);
			}

			mp.owner(ptfsOutput, ptfsRows);        /* PMSTA-49169 - MSS - 22062022 Fix memory leaks */

			/* dimObject == Ptf && domainPtr != NULL && launchLoadParentHierPtfFlg==TRUE */
			if (ptfIdNbr == NULL || *ptfIdNbr == 0) /* CheckStrat/Rebal */
			{
				if (dimObject == Ptf)
				{
					if (FIN_SetTopHierPtf(domainPtr, ptfsOutput, ptfsRows) == RET_SUCCEED)
					{
						SET_ID(searchLnkSt, A_SearchLnk_PortObjId, GET_ID(domainPtr, A_Domain_PtfObjId));
					}
				}
				DBA_DelDomPortAndDomStratTables(*connectNo, TRUE);
			}
			else /* PTCC - reconstruct ptfIdTab and #dom_port */
			{
				DBA_DelDomPortAndDomStratTables(*connectNo, TRUE);
				FREE((*ptfIdTab));
				(*ptfIdTab) = (ID_T *)CALLOC((ptfsRows+1), sizeof(ID_T));
				*ptfIdNbr = 0;

				/* PMSTA-51847 - SRN - 31012023*/
				int MaxNoOfSqlInsert = 0, min_limit = 0,
					max_limit = (ptfsRows >= MAX_NUMBER_EXP_IN_LIST) ? MAX_NUMBER_EXP_IN_LIST : ptfsRows;	/* Maximum limit for portfolio. If ptfsRows is greater, then maxlimit will be 999 else maxlimit is ptfsRows. */
				MaxNoOfSqlInsert = ptfsRows / MAX_NUMBER_EXP_IN_LIST;										/* Maximum number of iteration to execute a loop. */
				MaxNoOfSqlInsert = MaxNoOfSqlInsert + 1;													/* Default to iterate once, if the potrfolio count is less than 1000 or it exceeds 1000. */

				while (MaxNoOfSqlInsert > 0)
				{
					char *buff = (char *)CALLOC(1, 2048); /* REF7264 - LJE - 020131 */ /*REF10722-BRO-060925*/
					/* init #dom_port according to give ptf ids (NB: strategy dim is forced to ALL) */
					sprintf(buff, "insert into #dom_port (id,port_pos_set_id,hier_port_id,fusion_date_rule_e) select id, 0, null, 0 " /* PMSTA-20159 - TEB - 150624 */ /* MIGR R4.00 STEP6 - LJE - 020816 */ /*REF10722-BRO-060922*/
						"from portfolio_vw where id in (");

					buffLen = SYS_StrLen(buff);
					sep = ' ';

					buff = (char *)REALLOC(buff, (buffLen + ptfsRows * (ID_T_LEN + 1) + 2) * sizeof(char)); /* REF7264 - LJE - 020131 */

					if (ptfsRows == 1)
					{
						ID_T currentId = GET_ID(ptfsOutput[0], A_Ptf_Id);
						sprintf(buff + buffLen, "%c%*" szFormatId, sep, ID_T_LEN, currentId); /* DLA - PMSTA08801 - 100209 */
						buffLen += ID_T_LEN + 1;
						sep = ',';

						(*ptfIdTab)[*ptfIdNbr] = currentId;
						(*ptfIdNbr)++;
					}
					else
					{
						for (ptf = min_limit; ptf < max_limit; ptf++)	/* changed the initial value of for loop to min_limit and end value to max_limit */
						{
							ID_T currentId;
							if (IS_NULLFLD(ptfsOutput[ptf], A_Ptf_ParentPortId) == TRUE)
							{
								currentId = GET_ID(ptfsOutput[ptf], A_Ptf_Id);
								sprintf(buff + buffLen, "%c%*" szFormatId, sep, ID_T_LEN, currentId); /* DLA - PMSTA08801 - 100209 */
								buffLen += ID_T_LEN + 1;
								sep = ',';

								(*ptfIdTab)[*ptfIdNbr] = currentId;
								(*ptfIdNbr)++;
							}
						}
					}
					sprintf(buff + buffLen, ")");

					if (DBA_SqlExec(buff, *connectNo, DBA_SET_CONN) != RET_SUCCEED)
					{
						FREE(buff);
						DBA_DelDomPortAndDomStratTables(*connectNo, TRUE);
						return(RET_GEN_ERR_NOACTION);
					}

					/* PMSTA-51847 - SRN - 31012023*/
					MaxNoOfSqlInsert--;			/* Decrement this value to found next iteration. */
					if (MaxNoOfSqlInsert == 1)	/* If it was last iteration, */
					{
						min_limit = max_limit;	/* change the max limit to min. */
						max_limit = ptfsRows;	/* ptfsRows to max. */
					}
					else
					{
						min_limit = max_limit;					/* If the MaxNoOfSqlInsert is greater than 1, change the max limit to min and */
						max_limit += MAX_NUMBER_EXP_IN_LIST;	/* max limit will be addition of 999, for every iteration. */
					}
					FREE(buff);
				}
				if (ptfIdNbr != NULL &&
					IS_NULLFLD(domainPtr, A_Domain_PtfObjId) == FALSE &&
					IS_NULLFLD(domainPtr, A_Domain_FullLoadHierOldPtfId) == TRUE)/* replace ptfId in domain ! */
				{
					if ((*ptfIdNbr) == 1)
					{
						/* Save settings */
						SET_ID(domainPtr, A_Domain_FullLoadHierOldPtfId, GET_ID(domainPtr, A_Domain_PtfObjId));
						SET_DICT(domainPtr, A_Domain_FullLoadHierOldDimPtfDictId, GET_DICT(domainPtr, A_Domain_DimPtfDictId));

						/* change settings for domain */
						SET_ID(domainPtr, A_Domain_PtfObjId, (*ptfIdTab)[0]);
						SET_DICT(domainPtr, A_Domain_DimPtfDictId, PtfCst);
					}
					else if ((*ptfIdNbr) > 1)
					{
						/* Save settings */
						SET_ID(domainPtr, A_Domain_FullLoadHierOldPtfId, GET_ID(domainPtr, A_Domain_PtfObjId));
						SET_DICT(domainPtr, A_Domain_FullLoadHierOldDimPtfDictId, GET_DICT(domainPtr, A_Domain_DimPtfDictId));

						/* change settings for domain */
						SET_NULL_ID(domainPtr, A_Domain_PtfObjId);
						SET_DICT(domainPtr, A_Domain_DimPtfDictId, ListCst);
					}

					/* Update SearchLnk accordingly */
					SET_ID(searchLnkSt, A_SearchLnk_PortObjId, GET_ID(domainPtr, A_Domain_PtfObjId));
					SET_DICT(searchLnkSt, A_SearchLnk_DimPortDictId, GET_DICT(domainPtr, A_Domain_DimPtfDictId));
				}
				statusDomPort = FALSE;
			}
			SET_FLAG(domainPtr, A_Domain_FullLoadHierProcessedFlg, TRUE);
		}

        /* HANDLE STRATEGY DIMENSION */
        /* Retrieve Strategy Dimension from SearchLnk */
        if (GET_DICT(searchLnkSt, A_SearchLnk_DimStratDictId) == 0)
        {
            dimObject = NullEntity;
        }
        else
        {
            DBA_GetObjectEnum(GET_DICT(searchLnkSt, A_SearchLnk_DimStratDictId), &dimObject);
        }

        /* If STRATEGY DIMENSION is a list */
        if (dimObject == List)
        {
            if ((admArg = ALLOC_DYNST(Adm_Arg)) == NULL)
            {
                DBA_DelDomPortAndDomStratTables(*connectNo, TRUE);
                return(RET_MEM_ERR_ALLOC);
            }

            if ((sList = ALLOC_DYNST(S_List)) == NULL)
            {
                DBA_DelDomPortAndDomStratTables(*connectNo, TRUE);
                FREE_DYNST(admArg, Adm_Arg);
                return(RET_MEM_ERR_ALLOC);
            }

            COPY_DYNFLD(admArg, Adm_Arg, Adm_Arg_Id, searchLnkSt, A_SearchLnk, A_SearchLnk_StratObjId);
            /* Get the LIST record */
            if (DBA_Get2(List,
                         UNUSED,
                         Adm_Arg,
                         admArg,
                         S_List,
                         &sList,
                         UNUSED,
                         UNUSED,
                         UNUSED) != RET_SUCCEED)
            {
                DBA_DelDomPortAndDomStratTables(*connectNo, TRUE);
                FREE_DYNST(admArg, Adm_Arg);
                FREE_DYNST(sList, S_List);
                return(RET_DBA_ERR_NODATA);
            }

            /* If the Strat list is a constraint list */
            if ((nature = (LISTNAT_ENUM) GET_ENUM(sList, S_List_NatEn)) == ListNat_Constr ||
                 nature == ListNat_Search ||
                 nature == ListNat_Hierarch)
            {
                DICT_T      entDictId;

                DBA_GetDictId(Strat, &entDictId);

                /* Insert strategy Id from the Constraint List into dom_strat */
                SERV_ListMgm(ListMgmFct_LoadStratLnk,
                             entDictId,
                             GET_ID(sList, S_List_Id),
                             NULL,
                             *dbiConnHelper.getConnection(),
                             nullptr);

                statusDomStrat = FALSE;
            }

            FREE_DYNST(admArg, Adm_Arg);
            FREE_DYNST(sList, S_List);
        }
        else if (dimObject == QuickSearch) /* REF7758 - DDV - 021105 - Quick search in Domain */
        {
            DICT_T          entDictId;
            RET_CODE        ret=RET_SUCCEED;
            DBA_GetDictId(Strat, &entDictId);

            if (domainPtr != NULL)
            {
                /* Insert portfolioes Ids from the Quick Search List into #dom_port */
                if ((ret = SERV_ListMgm(ListMgmFct_LoadStratLnk,
                                        entDictId,
                                        0,
                                        GET_STRING(domainPtr, A_Domain_InstrListDef),
                                        *dbiConnHelper.getConnection(),
                                        nullptr)) != RET_SUCCEED)
                {
                    DBA_DelDomPortAndDomStratTables(*connectNo, TRUE);
                    return(ret);
                }
            }
            else
            {
                DBA_DelDomPortAndDomStratTables(*connectNo, TRUE);
                MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_InitStratLnk", "domain not found");
                MSG_RETURN(RET_GEN_ERR_INVARG);
            }
        }

        if (statusDomPort == TRUE || statusDomStrat == TRUE)
        {
            /* < PMSTA-29302 - CHU - 180220 : for PTCC select only portfolios for which at least one order was updated/inserted/deleted */
            if (domainPtr != nullptr &&
                IS_NULLFLD(domainPtr, A_Domain_FctResultId) == FALSE &&
                GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_PreTradeCheckStrat &&
                GET_ENUM(domainPtr, A_Domain_CompDataEn) == CompData_SelectiveReplOld)
            {
                SET_FLAG(searchLnkSt, A_SearchLnk_SelectiveReplOldFlg, TRUE);
                SET_ID(searchLnkSt, A_SearchLnk_FctResultId, GET_ID(domainPtr, A_Domain_FctResultId));
            }
            /* > PMSTA-29302 - CHU - 180220 */

            if (domainPtr != nullptr && (GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_ReconcStrat ||
                GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_CheckStrat))
            {
                SET_FLAG(searchLnkSt, A_SearchLnk_ForceLnkFlg, GET_FLAG(domainPtr, A_Domain_ForceLnkFlg)); /* PMSTA-52736 - ankita - 20230612 */
            }

            /* Send an Init request to fill dom_port_strat */
            /* and dom_strat table */
            if (DBA_Notif(StratLnk,
                          UNUSED,
                          A_SearchLnk,
                          searchLnkSt,
                          &*connectNo,
                          DBA_SET_CONN | DBA_NO_CLOSE) != RET_SUCCEED)
            {
                DBA_DelDomPortAndDomStratTables(*connectNo, TRUE);
                return(RET_GEN_ERR_NOACTION);
            }
        }

        return(RET_SUCCEED);
}

/* REF7422 */
/************************************************************************
*   Function             : DBA_BenchStorageData()
*
*   Description          : Select strategy(ies), instrument(s) according
*                          to strat and ptf dimension of the domain
*
*   Arguments            :
*
*   Return               : RET_SUCCEED or error code
*
*   Creation Date        : REF7422 - RAK - 020403
*
*************************************************************************/
RET_CODE DBA_BenchStorageData(DBA_DYNFLD_STP   domainPtr,
                              DBA_HIER_HEAD_STP *hierHeadPtr)
{
    RET_CODE            ret=RET_SUCCEED;
    int                 connectNo=-1;
    DBA_DYNFLD_STP      *stratLnkData=NULL, *stratTab=NULL, *selPspTab=NULL;
    int                 stratLnkRows=0, stratNbr=0, selPspNbr=0;

    /* Begin Connection in DBA_SelCheckStratDataInitStrat(), connectNo is initialised */
    /* According to domain (A_Domain_ForceLnkFlg, Strat, Ptf), initialise #dom_strat */
    ret = DBA_SelCheckStratDataInitStrat(domainPtr, (ID_T**)NULL, (int *)NULL,
                                         &connectNo, &stratLnkData, &stratLnkRows);

    if (ret == RET_SUCCEED)
    {
        /* Unused in this function */
        DBA_FreeDynStTab(stratLnkData, stratLnkRows, S_StratLnk);

        /* Select STRATEGY(IES) */
        if ((ret = DBA_Select2(Strat, UNUSED, A_Domain, domainPtr, A_Strat, &stratTab,
			              DBA_SET_CONN|DBA_NO_CLOSE, UNUSED, &stratNbr, &connectNo, UNUSED)) != RET_SUCCEED)

		{
            DBA_EndConnection(connectNo);

			return(ret);
		}

        /* REF9340 - DDV - 030925 - Don't load  PSP for Online, they will be added in hierarchy later */
        if ((COMPDATA_ENUM)GET_ENUM(domainPtr, A_Domain_CompDataEn) != CompData_OnLine)
        {
		    if ((ret= DBA_SelectPSP(domainPtr,
							       &connectNo,
							       &selPspTab,
							       &selPspNbr)) != RET_SUCCEED)
		    {
				DBA_FreeDynStTab(stratTab, stratNbr, Strat);
			    DBA_DelDomPortAndDomStratTables(connectNo, TRUE);
			    DBA_EndConnection(connectNo);

			    return(ret);
		    }
        }

        /* End Connection */
        DBA_DelDomPortAndDomStratTables(connectNo, TRUE);
        DBA_EndConnection(connectNo);


		/* Create a hierarchy and add loaded instruments */
		if (ret == RET_SUCCEED)
        {
            /* If necessary, create hierarchy */
	        if (*hierHeadPtr == (DBA_HIER_HEAD_STP) NULL)
            {
		        if ((*hierHeadPtr = DBA_CreateHier())==NULL)
		        {
                    MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO,
			                    "DBA_BenchStorageData: Cannot create hierarchy");
		            ret = RET_DBA_ERR_MD;
		        }

				/* REFX - RAK - 020829 - Add hierarchy pointer in thread ! */
				ret = DBA_SetHierOptiPtr(*hierHeadPtr);
			    if (ret != RET_SUCCEED)
                {
					DBA_FreeDynStTab(stratTab, stratNbr, Strat);
				    return(ret);
                }
            }


	        if ((ret = DBA_AddHierRecordList(*hierHeadPtr, stratTab, stratNbr, A_Strat, TRUE)) != RET_SUCCEED)
			{
				FREE(stratTab);
				return(ret);
            }
        }

        /* REF9340 - DDV - 030925 - no PSP loaded for Online, don't call filter function */
        if ((COMPDATA_ENUM)GET_ENUM(domainPtr, A_Domain_CompDataEn) != CompData_OnLine)
        {
			if ((ret = DBA_FilterPSP(domainPtr,
								     *hierHeadPtr,
								     stratTab,
									 stratNbr,
									 Strat,
					   				 selPspTab,
									 selPspNbr)) != RET_SUCCEED)
			{
				FREE(stratTab);
				return(ret);
            }
        }
    }
	FREE(stratTab);

    return(ret);
}


/************************************************************************
*   Function             : DBA_SelMCForPtfList()
*
*   Description          : Select modeling constraint and elements that
*                          are linked to ptf lists according to the domain
*
*   Arguments            :
*
*   Return               : RET_SUCCEED or error code
*
*   Creation Date        : REF11435 - TEB - 051021
*
*************************************************************************/
RET_CODE DBA_SelMCForPtfList(DBA_DYNFLD_STP    domainPtr,
                             DBA_HIER_HEAD_STP hierHeadPtr)
{
    RET_CODE            ret = RET_SUCCEED;
	OBJECT_ENUM			objectPtfEnum       = NullEntity;
    DBA_DYNFLD_STP      *listTab	= NULL,
						*allListTab = NULL,
						admArg		= NULL,
						*MCTab		= NULL;
    int                 listNb = 0,
						allListNb = 0,
						i = 0, j = 0,
						MCNb = 0;
	FLAG_T              isInListFlg = FALSE;
	DBA_DYNFLD_STP		*data[2]={NULL, NULL};
	const DBA_DYNST_ENUM *outputStLst[] = {&A_ModelConstr, &A_ModelConstrElt};
    int					rows[] = {0,0};

	/* Just check domain */
	if (domainPtr == NULL ||
		IS_NULLFLD(domainPtr, A_Domain_DimPtfDictId) == TRUE ||
        DBA_GetObjectEnum(GET_DICT(domainPtr, A_Domain_DimPtfDictId), &objectPtfEnum) != TRUE)
	{
		MSG_RETURN(RET_GEN_ERR_INVARG);
	}

	/* If dimension of the domain is only ptf */
	if (objectPtfEnum == Ptf)
	{
		/* Get all the lists that have MC */
        if ((ret = DBA_Select2(List, UNUSED, NullDynSt, NULL,
							   A_List, &allListTab,
                               UNUSED, UNUSED, &allListNb, UNUSED, UNUSED)) != RET_SUCCEED)
		{
			return(ret);
		}

		/* REF11435 - TEB - 051123 */
		if (allListNb>0)
		{
			/* Keep only the lists that have the ptf in the compo */
			if ((listTab = (DBA_DYNFLD_STP *)CALLOC(allListNb, sizeof(DBA_DYNFLD_STP))) == NULL)
			{
				MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, allListNb);
				return(RET_MEM_ERR_ALLOC);
			}

			listNb = 0;
			for (i=0; i<allListNb; i++)
			{
				isInListFlg = FALSE;
				if ((ret = FIN_IsInList(hierHeadPtr,
										GET_ID(domainPtr, A_Domain_PtfObjId),
										NULL,
										Ptf,
										GET_ID(allListTab[i], A_List_Id),
										&allListTab[i],
										NULL,
										FALSE,
										NULL,
										&isInListFlg)) == RET_SUCCEED)
				{
					if(isInListFlg == TRUE)
					{
						listTab[listNb] = allListTab[i];
						listNb++;
					}
					else
					{
						FREE_DYNST(allListTab[i], A_List);
					}
				}
			}
			FREE(allListTab);
			if (listNb == 0)
				FREE(listTab);
		}
	}

	/* If dimension of the domain is a list of ptf */
	if (objectPtfEnum == List)
	{
		DBA_DYNFLD_STP sList = NULL;

		/* Initialisation */
		listNb = 1;

		/* First suppress from hierarchy the MC & MCE of ptf dimension that have been loaded
		 * by sel_exd_strategy_by_domain, because we dont want them */
		if ((ret = DBA_ExtractHierEltRecWithFilterSt(hierHeadPtr,
													A_ModelConstr,
													FALSE,
													DBA_FilterPtfMC,
													NULL,
													NULLFCT,
													&MCNb,
													&MCTab)) != RET_SUCCEED)
		{
			return(ret);
		}

		for (j=0; j<MCNb; j++)
		{
			if ((ret = DBA_DelAndFreeHierEltRecWithFilter(hierHeadPtr,
														  A_ModelConstrElt,
														  DBA_FilterMCEFromMC,
														  MCTab[j],
														  NULL)) != RET_SUCCEED)
			{
				FREE(MCTab);
				return(ret);
			}

			DBA_DelAndFreeHierEltRec(hierHeadPtr, A_ModelConstr, MCTab[j]);
		}

		FREE(MCTab);

        /* Allocation memory of pointer array */
        if ((listTab = (DBA_DYNFLD_STP *)CALLOC(listNb, sizeof(DBA_DYNFLD_STP))) == NULL)
        {
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, listNb);
            return(RET_MEM_ERR_ALLOC);
        }

		if ((listTab[0] = ALLOC_DYNST(A_List)) == NULL)
		{
			return(RET_MEM_ERR_ALLOC);
		}

        /* Allocate memory */
        if ((sList = ALLOC_DYNST(S_List)) == NULL)
        {
			DBA_FreeDynStTab(listTab, listNb, A_List);
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "S_List");
            return(RET_MEM_ERR_ALLOC);
        }

        /* Fill with list id */
        COPY_DYNFLD(sList, S_List, S_List_Id, domainPtr, A_Domain, A_Domain_PtfObjId);

        /* Get the list record */
        if (DBA_Get2(List, UNUSED,
					 S_List, sList,
					 A_List, &(listTab[0]),
					 UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
        {
            MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, "List", GET_ID(admArg, Adm_Arg_Id));
            FREE_DYNST(sList, S_List);
			DBA_FreeDynStTab(listTab, listNb, A_List);
            return(RET_DBA_ERR_NODATA);
        }

        /* Free memory allocation */
        FREE_DYNST(sList, S_List);
	}

	/* Search and add in hier MC and MCE for the list(s) */
	if (listNb > 0)
	{
		if ((admArg = ALLOC_DYNST(Adm_Arg)) == NULL)
		{
			DBA_FreeDynStTab(listTab, listNb, A_List);
			MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "S_List");
			return(RET_MEM_ERR_ALLOC);
		}

		for (i=0; i<listNb ; i++)
		{
			COPY_DYNFLD(admArg,		Adm_Arg, Adm_Arg_Id,
						listTab[i], A_List,	 A_List_Id);

			if ((ret = DBA_MultiSelect2(ModelConstr,
										UNUSED,
										Adm_Arg,
										admArg,
										outputStLst,
										data,
										UNUSED,
										UNUSED,
										rows,
										UNUSED,
										UNUSED)) != RET_SUCCEED)
			{
				DBA_FreeDynStTab(listTab, listNb, A_List);
				FREE_DYNST(admArg, Adm_Arg);
				return(ret);
			}

			if ((ret = DBA_AddHierRecordList(hierHeadPtr,
											data[0],
											rows[0],
											A_ModelConstr,
											TRUE)) != RET_SUCCEED)
			{
				MSG_SendMesg(RET_DBA_ERR_HIER, 0 , FILEINFO);
				DBA_FreeDynStTab(listTab, listNb, A_List);
				FREE_DYNST(admArg, Adm_Arg);
				DBA_MultiFree(&(data[0]), &(outputStLst[0]), &(rows[0]), 2);
				return(ret);
			}

			if ((ret = DBA_AddHierRecordList(hierHeadPtr,
											data[1],
											rows[1],
											A_ModelConstrElt,
											TRUE)) != RET_SUCCEED)
			{
				MSG_SendMesg(RET_DBA_ERR_HIER, 0 , FILEINFO);
				DBA_FreeDynStTab(listTab, listNb, A_List);
				FREE_DYNST(admArg, Adm_Arg);
				FREE(data[0]);
				DBA_MultiFree(&(data[1]), &(outputStLst[1]), &(rows[1]), 1);
				return(ret);
			}
		}

		for (i=0; i<2; i++)
		{
			FREE(data[i]);
		}
		DBA_FreeDynStTab(listTab, listNb, A_List);
		FREE_DYNST(admArg, Adm_Arg);
	}

    return(ret);
}


/************************************************************************
*   Function             : FIN_SetAddDetailsinMC()
*
*   Description          : Set Additional details in Model constraint Records
*                          1) Set hier head portfolio Id
*                          2) Set number of child porfolios linked to the 
*                              Model Constraint Portfolio
*
*   Arguments            :
*
*   Return               : RET_SUCCEED or error code
*
*   Creation Date        : PMSTA-41153 - Vishnu - 15072020
*
*************************************************************************/
static RET_CODE FIN_SetAddDetailsinMC(DBA_DYNFLD_STP	  domainPtr,
                                      DBA_HIER_HEAD_STP   stratHierHead)
{
    RET_CODE ret = RET_SUCCEED;
    FLAG_T hierConstrUsed = 0;
    GEN_GetApplInfo(ApplHierConstraintUsed, &hierConstrUsed);
	/*LOADHIERPTF_ENUM Domain_LoadHierFlg = (LOADHIERPTF_ENUM)GET_ENUM(domainPtr, A_Domain_LoadHierFlg);*/

    /*use existing logic*/
    if (hierConstrUsed == 0)
        return ret;

    /*to add hier ptf id in MC records */
    MemoryPool  mp;
    
    DBA_DYNFLD_STP                  *MCTab = NULLDYNSTPTR, 
                                        *MCETab = NULLDYNSTPTR,
                                        *PTFTab = NULLDYNSTPTR,
                                        *TCTab = NULLDYNSTPTR;
    int MCNbr = 0, MCENbr = 0, TCNbr = 0,PTFNbr=0;

    if ((ret = DBA_ExtractHierEltRec((DBA_HIER_HEAD_STP)stratHierHead,
        A_ModelConstr,
        FALSE,
        NULLFCT,
        NULLFCT,
        &MCNbr,
        &MCTab)) != RET_SUCCEED)
    {
        MSG_LogMesg(ret, 1, FILEINFO, "FIN_SetAddDetailsinMC: Unable to extract A_ModelConstr Operation from hierarchy");
        return ret;
    }
    if (MCNbr > 0)
        mp.owner(static_cast<void *> (MCTab));

    if ((ret = DBA_ExtractHierEltRec((DBA_HIER_HEAD_STP)stratHierHead,
        A_Ptf,
        FALSE,
        NULLFCT,
        NULLFCT,
        &PTFNbr,
        &PTFTab)) != RET_SUCCEED)
    {
        MSG_LogMesg(ret, 1, FILEINFO, "FIN_SetAddDetailsinMC: Unable to extract A_Ptf Operation from hierarchy");
        return ret;
    }

    if (PTFNbr > 0)
        mp.owner(static_cast<void *> (PTFTab));

    if (MCNbr > 0)
    {
        if ((ret = DBA_ExtractHierEltRec((DBA_HIER_HEAD_STP)stratHierHead,
            A_ModelConstrElt,
            FALSE,
            NULLFCT,
            NULLFCT,
            &MCENbr,
            &MCETab)) != RET_SUCCEED)
        {
            MSG_LogMesg(ret, 1, FILEINFO, "FIN_SetAddDetailsinMC: Unable to extract A_ModelConstrElt Operation from hierarchy");
            return ret;
        }
    }

    if (MCENbr > 0)
        mp.owner(static_cast<void *> (MCETab));

    
    if ((ret = DBA_ExtractHierEltRec((DBA_HIER_HEAD_STP)stratHierHead,
        A_TradConstr,
        FALSE,
        NULLFCT,
        NULLFCT,
        &TCNbr,
        &TCTab)) != RET_SUCCEED)
    {
        MSG_LogMesg(ret, 1, FILEINFO, "FIN_SetAddDetailsinMC: Unable to extract A_TradConstr Operation from hierarchy");
        return ret;
    }

    if (TCNbr > 0)
        mp.owner(static_cast<void *> (TCTab));

    /*for get_ptf_childs*/
    DbiConnectionHelper connHelper;

    if (!connHelper.isValidAndInit())
    {
        MSG_SendMesg(FILEINFO, "FIN_SetAddDetailsinMC : connection not valid / init ");
        return RET_DBA_ERR_CONNOTFOUND;
    }

    for (int TCcnt = 0; TCcnt < TCNbr; TCcnt++)
    {
        if (IS_NULLFLD(TCTab[TCcnt], A_TradConstr_HierHeadPtf) == TRUE)
        {
            ID_T hierPtfId = ZERO_ID;
            if (DBA_GetHierHeadPTF(GET_ID(TCTab[TCcnt], A_TradConstr_PtfId), &hierPtfId) != RET_SUCCEED)
                return(RET_DBA_ERR_NODATA);

            SET_ID(TCTab[TCcnt], A_TradConstr_HierHeadPtf, hierPtfId);
        }

        /*set hier ptf for the each MC ptf id */
        for (int MCcnt = 0; MCcnt < MCNbr; MCcnt++)
        {
            if (CMP_DYNFLD(MCTab[MCcnt], TCTab[TCcnt], A_ModelConstr_PtfId, A_TradConstr_PortObjId, IdType) == 0)
            {
                SET_ID(MCTab[MCcnt], A_ModelConstr_HierHeadPtfId, GET_ID(TCTab[TCcnt], A_TradConstr_HierHeadPtf));
            }

        }
    }

    /*set hier ptf for the each MC ptf id */
    DBA_DYNFLD_STP ioId = mp.allocDynst(FILEINFO, Io_Id);
    DBA_DYNFLD_STP* sChildPtfTab = NULLDYNSTPTR;
    int sChildPtfNb = 0;
    ID_T ptfId = ZERO_ID;

    for (int MCcnt = 0; MCcnt < MCNbr; MCcnt++)
    {
        ID_T hierPtfId = ZERO_ID;
        ptfId = ZERO_ID;
        if (IS_NULLFLD(MCTab[MCcnt], A_ModelConstr_HierHeadPtfId) == TRUE)
        {
            if (DBA_GetHierHeadPTF(GET_ID(MCTab[MCcnt], A_ModelConstr_PtfId), &hierPtfId) != RET_SUCCEED)
                return(RET_DBA_ERR_NODATA);

            SET_ID(MCTab[MCcnt], A_ModelConstr_HierHeadPtfId, hierPtfId);
        }
        else
        {
            hierPtfId = GET_ID(MCTab[MCcnt], A_ModelConstr_HierHeadPtfId);
        }

        ptfId = GET_ID(MCTab[MCcnt], A_ModelConstr_PtfId);
        /*set hier ptf id in Model*/

        for (int MCECnt = 0; MCECnt < MCENbr; MCECnt++)
        {
            if (CMP_DYNFLD(MCTab[MCcnt], MCETab[MCECnt], A_ModelConstr_Id, A_ModelConstrElt_ModelConstrId, IdType) == 0)
            {
                SET_ID(MCETab[MCECnt], A_ModelConstrElt_HierHeadPtfId, hierPtfId);
                SET_ID(MCETab[MCECnt], A_ModelConstrElt_ptfId, ptfId);
            }
        }

        /*get child PTF number to check if standalone ptf or not*/
        SET_ID(ioId, Io_Id_Id, ptfId);
        /* sel_sh_portfolio_by_parent */
        sChildPtfTab = NULLDYNSTPTR;
		if ((ret = connHelper.dbaSelect(Ptf, UNUSED, ioId, S_Ptf, &sChildPtfTab, &sChildPtfNb)) != RET_SUCCEED)
		{
			MSG_SendMesg(FILEINFO, "FIN_OverlayLoadData : Select failed");
			DBA_FreeDynStTab(sChildPtfTab, sChildPtfNb, S_Ptf);
			return ret;
		}
		DBA_FreeDynStTab(sChildPtfTab, sChildPtfNb, S_Ptf);
        SET_INT(MCTab[MCcnt], A_ModelConstr_ChildPtfNos, sChildPtfNb);
    }
    return ret;
}



/************************************************************************
*
*   Function      : DBA_SelCheckStratData
*
*   Description   : Select data for Check Strategy function
*                   - extended strategy link
*                   - all strategy
*                   - all strategy history
*                   - all strategy element
*                   - all script definition
*                   - model constraint and derived strategy
*                   - trading constraint and script definition
*                   Uses worktable 'dom_strat'.
*
*   Arguments     : domainPtr       domain dynamic structure pointer
*                   strategyHierHead    strategy hierarchy header pointer
*
*   Return        : RET_SUCCEED         if ok
*                   RET_GEN_ERR_INVARG      errors in arguments
*                   RET_DBA_ERR_CONNOTFOUND error in finding free connection
*                   RET_DBA_ERR_NODATA      error in data retrieval
*                   RET_MEM_ERR_ALLOC       error in memory allocation
*                   RET_GEN_ERR_SORTSIZE    error in sorting function
*                   RET_DBA_ERR_MD      error in meta-dictionnary
*
*   Creation Date : 28.11.95 - DED
*   Last Modif    : 26.03.96 - DED (DVP023)
*                   20.05.96 - RAK (DVP060)
*                   07.10.96 - RAK (BUG165)
*                   12.11.96 - RAK (DVP249)
*                   27.01.97 - RAK (BUG266)
*                   17.03.97 - RAK (DVP339)
*                   01.07.97 - GRD (DVP529)
*                   REF2755 - SSO - 990215 : add case of given ptf ids
*                   REF3678 - RAK - 990813 : Add A_Grid et S_MktSegt in sel_exd_strategy_by_domain
*                   REF6082 - RAK - 010726 : Modelling constraint and some simplification
*   	            REF6168 - RAK - VST - 011009
*					REF11435 - TEB - 051012
*
*************************************************************************/
RET_CODE DBA_SelCheckStratData(DBA_DYNFLD_STP		 domainPtr,
                               DBA_HIER_HEAD_STP     strategyHierHead,
                               ID_T					 **ptfIdTab,
                               int					 *ptfIdNbr,  /* REF2755 - SSO - 990215 */
							   MODELCONSTRVALID_ENUM modelConstrValidEn) /* REF11435 - TEB - 051012 */
{
        RET_CODE        ret                 = RET_SUCCEED;
        int             connectNo;
        int             ptfIdx, stratIdx;
        int             k, ll;
        int             ioIdNbr             = 0;
        int             stratLnkRows        = 0;
        int             extStratLnkRows     = 0;
        int             groupScriptDefNbr   = 0;
        int             effExtStratLnkRows  = 0;
        int             aStratPos;
        char            found;
        DBA_DYNFLD_STP *ioIdTab             = NULL;
        DBA_DYNFLD_STP *stratLnkData        = NULL;
        DBA_DYNFLD_STP *extStratLnkData     = NULL;
        DBA_DYNFLD_STP *groupScriptDefTab   = NULL;
        DBA_DYNFLD_STP  inputPtr            = NULL;
        DBA_DYNFLD_STP  searchLnkPtr        = NULL;	/* REF11435 - TEB - 051012 */
        OBJECT_ENUM     objectEnum          = NullEntity;
        OBJECT_ENUM     objectPtfEnum       = NullEntity;
        DICT_T          ptfDictId;
        int             idx; /* PMSTA08801 - DDV - 091126 */
        FLAG_T          aStratFoundFlg      = FALSE;
        FLAG_T          intraMktSgtFlg      = FALSE;    /* REF4454 - 000329 - SKE */
        OBJECT_ENUM     compoObjectEn=NullEntity;       /* REF7420 - RAK - 020621 */
        FLAG_T          compoFoundFlg       = FALSE;    /* REF7420 - RAK - 020621 */
		FLAG_T			allPortfolios		= FALSE;	/* REF8055-10009 - CHU - 040324 */
		DBA_DYNFLD_STP *tmpModConstrTab     = NULL; /*  */
        DBA_DYNFLD_STP *tmpModConstrEltTab  = NULL;
		FLAG_T			applStratActivateNoLinkError = TRUE;	/* PMSTA10000-CHU-100603 */ /* PMSTA-27889 - CHU - 170719 : wrong spelling */
        DBA_DYNFLD_STP	  stratPtr = NULLDYNST;          /* WEALTH-6213 - Ravindra - 04072024 */
        FLAG_T            allocFlg = FALSE;
        DBA_DYNFLD_STP* childPtfTab = NULLDYNSTPTR;
        int             childPtfNb = 0;

        /* PMSTA-29302 - CHU - 180215 */
        bool            isSelectivePTCCFlg = (GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_PreTradeCheckStrat && 
                                              IS_NULLFLD(domainPtr, A_Domain_FctResultId) == FALSE &&
                                              GET_ENUM(domainPtr, A_Domain_CompDataEn) == CompData_SelectiveReplOld);

        /* REF7420 - RAK - 020529 - Add 3 new blocks StratCompo, MktSSubSet and MktStruct */
        int             stLstNbr            = 30;
        int             dataRows[]          = {0,0,0,0,
                                               0,0,0,0,
                                               0,0,0,0,
                                               0,0,0,0,
                                               0,0,0,0,
                                               0,0,0,0,
                                               0,0,0,0,
                                               0,0}; /* REF6082 - RAK - 010725 */ /*PMSTA-42402 Autocash Vishnu 23112020*/ /*PMSTA-47502-Lalby-04032022*/

        const DBA_DYNST_ENUM *outputStLst[]     = {&A_Strat,
                                                   &A_StratHist,
                                                   &A_StratElt,
                                                   &A_HoldingConstraintScript /* &A_ScriptDef */, /* PMSTA-28970 - CHU - 171227 */
                                                   &A_StratCompo,
                                                   &A_Instr,
                                                   &A_ListCompo,
                                                   &A_Grid,
                                                   &A_MktSSubSet,
                                                   &A_MktStruct,
                                                   &S_MktSegt,
					                               &A_TradConstr,
					                               &A_TradConstr,
                                                   &A_TradingConstraintScript /* &A_ScriptDef */, /* PMSTA-28970 - CHU - 171227 */
					                               &A_Ptf,
                                                   &A_ModelConstr,
                                                   &A_ModelConstrElt,
                                                   &A_DerivedStrat,
                                                   &A_DerivedStratElt,
                                                   &S_StratLnk, /*PMSTA-41153 Vishnu 05082020*/
                                                   &A_PlanDefinition , /*PMSTA-42402 Autocash Vishnu 23112020*/
                                                   &A_TacticalModel,   /*PMSTA-42402 Autocash Vishnu 23112020*/
                                                   &A_InstrCurrOverride,  /*PMSTA-46766 - Ravindra - 15032022*/
                                                   &A_SeverityRuleLink ,  /*PMSTA-47502-Lalby-04032022*/
                                                   &A_SeverityRule,
                                                   &A_SeverityRuleElement,
                                                   &A_InstrMktsegOverride,
                                                   &A_PortfolioProcessHistory, /*PMSTA-47502-Lalby-04032022*/
                                                   &A_CaseManagement,
                                                   &A_CaseLink };

        /* A_TradConstr must be in position 8 and 9 and A_ScriptDef and A_Ptf in 10 and 11 */
	    /* because of function DBA_TradConstr2ExtStratLnk() and loop for add records in hierarchy */
        /* REF7420 - RAK - 020604 - Create index */
        int             tradConstrIdx1=11;
        int             tradConstrIdx2=12;
        int             holdConstrscriptIdx=3;
        int             tradConstrscriptIdx=13;
        int             dataPtfIdx=14;
        int             dataStratIdx=0;
        int             dataInstrIdx=5;
        int             stratCompoIdx=4;
        int             sMktSegtIdx=10;
		int				modConstrIdx=15;
		int				modConstrEltIdx=16;
        int             stratLinkIdx = 19;

        DBA_DYNFLD_STP *data[]              = {NULL, NULL, NULL, NULL,
                                               NULL, NULL, NULL, NULL,
                                               NULL, NULL, NULL, NULL, /* REF6082 - RAK - 010725 */
                                               NULL, NULL, NULL, NULL,
                                               NULL, NULL, NULL, NULL,
                                               NULL, NULL, NULL, NULL,
                                               NULL, NULL, NULL, NULL,
                                               NULL, NULL }; /*PMSTA-42402 Autocash Vishnu 23112020*/
        MemoryPool      mp;

        /* Check arguments */
        if (domainPtr == NULL || strategyHierHead == NULL)
        {
            MSG_RETURN(RET_GEN_ERR_INVARG);
        }

		/* REF8055-10009 - CHU - 040324 */
		if (GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_PreTradeCheckStrat)
		{
			allPortfolios = (FLAG_T)((IS_NULLFLD(domainPtr, A_Domain_DimInstrDictId) == TRUE) &&
									 (IS_NULLFLD(domainPtr, A_Domain_PtfObjId) == TRUE) &&
									 (ptfIdNbr != NULL) &&
									 (*ptfIdNbr > 0));
		} /* PMSTA14913-CHU-121119 : allow All Portfolios if an instrument is set in the domain */
		else if ((GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_CheckStrat ||
				  GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_ReconcStrat) &&
				  IS_NULLFLD(domainPtr, A_Domain_DimInstrDictId) == FALSE)
		{
			allPortfolios = (FLAG_T)((IS_NULLFLD(domainPtr, A_Domain_DimPtfDictId) == TRUE) &&
									 (IS_NULLFLD(domainPtr, A_Domain_PtfObjId) == TRUE));
		}

        /* <REF4454 - 000329 - SKE : Intra Mkt Sgt Flag */
        if (IS_NULLFLD(domainPtr, A_Domain_DimInstrDictId) == FALSE)
        {
            DBA_GetObjectEnum(GET_DICT(domainPtr, A_Domain_DimInstrDictId), &objectEnum);
            if (objectEnum == MktSegt)
            {
                if (GET_FLAG(domainPtr, A_Domain_MktSgtRebalFlg) == TRUE)
                {
                    intraMktSgtFlg = TRUE;
                }
            }
        }
        /* REF4454 - 000329 - SKE> */

        /********************************** Begin Connection *************************************/

		GEN_GetApplInfo(ApplStratActivateNoLinkError, &applStratActivateNoLinkError); /* PMSTA10000-CHU-100603 */ /* PMSTA-27889 - CHU - 170719 : wrong spelling */

        /* REF7423 - RAK - 020404 - Create a sub-function.         */
        /* According to domain (A_Domain_ForceLnkFlg, Strat, Ptf), */
        /* initialise #dom_strat and return connection number      */
        if ((ret = DBA_SelCheckStratDataInitStrat(domainPtr, ptfIdTab, ptfIdNbr,
                                                  &connectNo, &stratLnkData, &stratLnkRows)) != RET_SUCCEED)
        {
            if(stratLnkRows>0)
                mp.owner(stratLnkData,stratLnkRows);
            return(ret);
        }
        /* PMSTA-49335 - n.sathish - 20220706: Memory leak handle */
        mp.owner(stratLnkData,stratLnkRows);

        /* < OCS-47724 - CHU - 160217 */
        if (GET_ENUM(domainPtr, A_Domain_OutputTpEn) == TSLDimPort &&           /*  FPL-PMSTA11939-110526   */
            GET_ENUM(domainPtr, A_Domain_LoadHierFlg) == LoadHierPtf_Full &&
            (GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_CheckStrat ||
             GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_ReconcStrat ||
             GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_AllocateOrder))
        {
            return(ret);
        }
        /* > OCS-47724 - CHU - 160217 */

        /* REF3314 - SSO - 990212: if allocate order or check strat, do not load recomm lists */
        if ((GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_AllocateOrder)
            || (GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_CheckStrat)
            /* REF3371 - RAK - 991221 */
            ||  (GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_PreTradeCheckStrat) ||
            (GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_OrderEntryAllocate))
        {
            char buffer[256];
            buffer[0]=END_OF_STRING;

			/* REF10778 - RAK - 041209 - Suppress new strategy nature 29 "composite" */
			/* which won't be treated in CheckStrat, Reconcilation, ... */
            /* REF10778 - DDV - 041210 - Replace numeric values by enum */
            sprintf(buffer,"delete from #dom_strat where nature_e in (%d, %d) ",StratNat_RecomList, StratNat_Composite); /* PMSTA-20159 - TEB - 150624 */
			DBA_SqlExec(buffer,	connectNo, DBA_SET_CONN);
        }
		else	/* REF10778 - RAK - 041209 - for all cases */
		{
            char buffer[256];
            buffer[0]=END_OF_STRING;

			/* REF10778 - RAK - 041209 - Suppress new strategy nature 29 "composite" */
			/* which won't be treated in CheckStrat, Reconcilation, ... */
            /* REF10778 - DDV - 041210 - Replace numeric values by enum */
            sprintf(buffer,"delete from #dom_strat where nature_e = %d ", StratNat_Composite);  /* PMSTA-20159 - TEB - 150624 */
			DBA_SqlExec(buffer,	connectNo, DBA_SET_CONN);
		}

        //if (static_cast<complianceMethodEn> GET_ENUM(domainPtr, A_Domain_ComplianceMethodEn) == complianceMethodEn::CashPlanCompliance)
        //{
        //    char buffer[256];
        //    buffer[0] = END_OF_STRING;

        //    sprintf(buffer, "delete from #dom_strat where nature_e != %d ", complianceMethodEn::CashPlanCompliance);  /* PMSTA-20159 - TEB - 150624 */
        //    //DBA_SqlExec(buffer, connectNo, DBA_SET_CONN);

        //}
        //else
        //{
        //    char buffer[256];
        //    buffer[0] = END_OF_STRING;

        //    sprintf(buffer, "delete from #dom_strat where nature_e = %d ", complianceMethodEn::CashPlanCompliance);  /* PMSTA-20159 - TEB - 150624 */
        //    //DBA_SqlExec(buffer, connectNo, DBA_SET_CONN);
        //}


        /* Using 'dom_strat', select several blocks of data :
            - all strategy
            - all strategy history
            - all strategy_element
            - ...
        */
		/* REF8055-10009 - CHU - 040324 : Use dynamically built ptf list if "All Portfolios" */
		if (allPortfolios == TRUE)
		{
            /* give ptf ids (force ptf dimension) */
            DICT_T      entDictId;

            DBA_GetDictId(List, &entDictId);
            SET_ID(domainPtr, A_Domain_DimPtfDictId, entDictId);
		}

		/* REF11435 - TEB - 051012 */
		/* Use SearchLnk instead of domain as input */
		if ((searchLnkPtr = ALLOC_DYNST(A_SearchLnk)) == NULL)
		{
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "A_SearchLnk");
            DBA_DelDomPortAndDomStratTables(connectNo, TRUE);
            DBA_EndConnection(connectNo);
            return(RET_MEM_ERR_ALLOC);
		}

		CONVERT_DYNST(searchLnkPtr, A_SearchLnk,
					  domainPtr,	A_Domain);

		SET_ENUM(searchLnkPtr, A_SearchLnk_ModelConstrValidEn, modelConstrValidEn);

        /*PMSTA-42402 Autocash Vishnu 23112020*/
        COPY_DYNFLD(searchLnkPtr, A_SearchLnk, A_SearchLnk_ComplianceMethodEn,
            domainPtr, A_Domain, A_Domain_ComplianceMethodEn);

        /*PMSTA-47502-Lalby-04032022 -Dynamic Severity */
        COPY_DYNFLD(searchLnkPtr, A_SearchLnk, A_SearchLnk_DynamicSeverityFlg,
            domainPtr, A_Domain, A_Domain_CheckSeverityRuleFlg);

        COPY_DYNFLD(searchLnkPtr, A_SearchLnk, A_SearchLnk_CaseDurationFlg,
            domainPtr, A_Domain, A_Domain_CaseManagementGenFlg);

        COPY_DYNFLD(searchLnkPtr, A_SearchLnk, A_SearchLnk_LoadHierFlg,
            domainPtr, A_Domain, A_Domain_LoadHierFlg);

        ret = DBA_MultiSelect2(Strat,
                               DBA_ROLE_STRAT_DOM,			/* REF11435 - TEB - 051013 */
                               A_SearchLnk,	/*A_Domain,*/	/* REF11435 - TEB - 051012 */
                               searchLnkPtr,/*domainPtr,*/	/* REF11435 - TEB - 051012 */
                               outputStLst,
                               data,
                               DBA_SET_CONN|DBA_NO_CLOSE,
                               UNUSED,
                               dataRows,
                               &connectNo,
                               UNUSED);
        if (ret != RET_SUCCEED)
        {
            MSG_SendMesg(RET_DBA_ERR_NODATA, 0, FILEINFO);
            DBA_DelDomPortAndDomStratTables(connectNo, TRUE);
            DBA_EndConnection(connectNo);
			FREE_DYNST(searchLnkPtr, A_SearchLnk);	/* REF11435 - TEB - 051012 */
            return(ret);
        }

		/* OCS37463-CHU-110413 */
		if (ptfIdNbr != NULL &&                     /* PMSTA14214-JPP-120621 */
            GET_FLAG(domainPtr, A_Domain_TSLPtfDimModifiedFlg) == TRUE &&
			(IS_NULLFLD(domainPtr, A_Domain_PtfListDef)   == TRUE	&&
			 (IS_NULLFLD(domainPtr, A_Domain_JobReference) == FALSE	&&
			  IS_NULLFLD(domainPtr, A_Domain_ChunkNumber) == FALSE)))
		{
			/* use ptfs from MultiSelect when loaded from TSL
			 */
			if (dataRows[dataPtfIdx] > 0)
			{
                int selReplOldPtfIdNbr = 0;             /* PMSTA-29302 - CHU - 180222 */
                FLAG_T SelectiveReplOldESLFlg = TRUE;   /* PMSTA-29302 - CHU - 180222 */

				*ptfIdNbr = dataRows[dataPtfIdx];
				if (((*ptfIdTab) = (ID_T *)REALLOC((*ptfIdTab), (*ptfIdNbr) * sizeof(ID_T))) == NULL)  /* PMSTA15705 - DDV - 121226 - Purify, use REALLOC to avoid memory leak when ptfIdTab has allready been allocated */
				{
					MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, 1);
					return(RET_MEM_ERR_ALLOC);
				}

				for (int i=0; i< (*ptfIdNbr); i++)
				{
                    if (isSelectivePTCCFlg == true &&
                        DBA_IsReplOldESLByPtfId(GET_ID(data[dataPtfIdx][i], A_Ptf_Id), GET_ID(domainPtr, A_Domain_FctResultId), &SelectiveReplOldESLFlg, UNUSED, UNUSED) == RET_SUCCEED &&
                        SelectiveReplOldESLFlg == FALSE)
				    {
                        continue;
                    }
					(*ptfIdTab)[i] = GET_ID(data[dataPtfIdx][i], A_Ptf_Id);
                    selReplOldPtfIdNbr++;
				}

                if (isSelectivePTCCFlg == true)
                {
                    /* PMSTA-29302 - CHU - 180222 : Reset *ptfIdNbr to filtered portfolio number for Selective Replace Old */
                    *ptfIdNbr = selReplOldPtfIdNbr;
                }

                /* < PMSTA-29302 - CHU - 180126 */
                /* In case of PTCC Replace Old mode (not selective), call del_session_data_for_ptf_chunk
                * to only delete session data related to the current chunk
                */
                if (GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_PreTradeCheckStrat &&
                    IS_NULLFLD(domainPtr, A_Domain_FctResultId) == FALSE &&
                    GET_ENUM(domainPtr, A_Domain_CompDataEn) == CompData_ReplOld)
                {
                    DBA_DYNFLD_STP argument = ALLOC_DYNST(Arg_Test);
                    RET_CODE ret2 = RET_SUCCEED;

                    if (argument != NULL)
                    {
                        SET_ID(argument, Arg_Test_Id, GET_ID(domainPtr, A_Domain_FctResultId));
                        MSG_LogSrvMesg(UNUSED, UNUSED, "Pre-Trade Compliance Check : Deleting %1 session content for chunk number %2            ",
                                                        CodeType, GET_CODE(domainPtr, A_Domain_FctResultCd),
                                                        IntType, GET_INT(domainPtr, A_Domain_ChunkNumber));
                        /* del_session_data_for_ptf_chunk */
                        /* ESL/ESE/RSE/RSEC/CM/LC */
                        ret2 = DBA_Delete2(FctResult,
                                          UNUSED,
                                          Arg_Test, argument,
                                          DBA_SET_CONN | DBA_NO_CLOSE, &connectNo, UNUSED);
                    }
                    FREE_DYNST(argument, Arg_Test);
                }
                /* > PMSTA-29302 - CHU - 180126 */
			}
		}

		FREE_DYNST(searchLnkPtr, A_SearchLnk);	/* REF11435 - TEB - 051012 */

		/* < PMSTA04637-CHU-080225 - Solution d'urgence : virer les doublons de MC et MCE */
		if (dataRows[modConstrIdx] > 1)
		{
			int mcNbr=0, mceNbr=0;
			FLAG_T foundFlg = FALSE;

			/* determine if duplicates exist */
			for (int i=0; i < dataRows[modConstrIdx]; i++)
			{
				ID_T mcId = GET_ID(data[modConstrIdx][i], A_ModelConstr_Id);

				for (int j=0; j < dataRows[modConstrIdx] && foundFlg == FALSE; j++)
				{
					if (j != i &&
						CMP_ID(mcId, GET_ID(data[modConstrIdx][j], A_ModelConstr_Id)) == 0)
					{
						foundFlg = TRUE;
						break;
					}
				}
			}

			if (foundFlg == TRUE)
			{
				MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_SelCheckStratData() : Removing duplicate Modelling Constraints");

				if ((tmpModConstrTab = (DBA_DYNFLD_STP *)CALLOC(dataRows[modConstrIdx], sizeof(DBA_DYNFLD_STP))) == NULL)
				{
					MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, dataRows[modConstrIdx]);
					DBA_MultiFree(data, outputStLst, dataRows, stLstNbr); /* REF6082 - RAK - 010725 */
					return(RET_MEM_ERR_ALLOC);
				}

				for (int i=0; i < dataRows[modConstrIdx]; i++)
				{
					foundFlg = FALSE;
					for (int j=0; j < mcNbr; j++)
					{
						if (CMP_ID(GET_ID(data[modConstrIdx][i], A_ModelConstr_Id),
								   GET_ID(tmpModConstrTab[j], A_ModelConstr_Id)) == 0)
							foundFlg = TRUE;
					}
					if (foundFlg == FALSE)
					{
						if ((tmpModConstrTab[mcNbr] = ALLOC_DYNST(A_ModelConstr)) == NULL)
						{
							MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "A_ModelConstr");
							DBA_MultiFree(data, outputStLst, dataRows, stLstNbr); /* REF6082 - RAK - 010725 */
							return(RET_MEM_ERR_ALLOC);
						}
						COPY_DYNST(tmpModConstrTab[mcNbr], data[modConstrIdx][i], A_ModelConstr);
						mcNbr++;
					}
				}

				if (mcNbr < dataRows[modConstrIdx]) /* if no elimination, no use to treat mce */
				{
					/* Now replace MC array */
					DBA_FreeDynStTab(data[modConstrIdx], dataRows[modConstrIdx], A_ModelConstr);
					data[modConstrIdx] = tmpModConstrTab;
					dataRows[modConstrIdx] = mcNbr;

					if (dataRows[modConstrEltIdx] > 1)
					{
						if ((tmpModConstrEltTab = (DBA_DYNFLD_STP *)CALLOC(dataRows[modConstrEltIdx], sizeof(DBA_DYNFLD_STP))) == NULL)
						{
							MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, dataRows[modConstrEltIdx]);
							DBA_MultiFree(data, outputStLst, dataRows, stLstNbr); /* REF6082 - RAK - 010725 */
							return(RET_MEM_ERR_ALLOC);
						}
					}
					for (int i=0; i < dataRows[modConstrEltIdx]; i++)
					{
						foundFlg = FALSE;
						for (int j=0; j < mceNbr; j++)
						{
							if (CMP_ID(GET_ID(data[modConstrEltIdx][i], A_ModelConstrElt_Id),
									   GET_ID(tmpModConstrEltTab[j], A_ModelConstrElt_Id)) == 0)
								foundFlg = TRUE;
						}
						if (foundFlg == FALSE)
						{
							if ((tmpModConstrEltTab[mceNbr] = ALLOC_DYNST(A_ModelConstrElt)) == NULL)
							{
								MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "A_ModelConstrElt");
								DBA_MultiFree(data, outputStLst, dataRows, stLstNbr); /* REF6082 - RAK - 010725 */
								return(RET_MEM_ERR_ALLOC);
							}
							COPY_DYNST(tmpModConstrEltTab[mceNbr], data[modConstrEltIdx][i], A_ModelConstrElt);
							mceNbr++;
						}
					}
					/* Now replace MCE array */
					if (mceNbr < dataRows[modConstrEltIdx])
					{
						DBA_FreeDynStTab(data[modConstrEltIdx], dataRows[modConstrEltIdx], A_ModelConstrElt);
						data[modConstrEltIdx] = tmpModConstrEltTab;
						dataRows[modConstrEltIdx] = mceNbr;
					}
				}
			}
		}
		/* > PMSTA04637-CHU-080225 - Solution d'urgence : virer les doublons de MC et MCE */


		/* REF8055-10009 - CHU - 040324 : restore "All Portfolios" */
		if (allPortfolios == TRUE)
		{
            SET_NULL_ID(domainPtr, A_Domain_DimPtfDictId);
		}

        DBA_DelDomPortAndDomStratTables(connectNo, TRUE);
        DBA_EndConnection(connectNo);
        /******************************** End Connection ***************************************/

		/* Test CheckTrading flag from domain and ignore trading constraints if FALSE */
		/* VST 020521 */
        if (IS_NULLFLD(domainPtr, A_Domain_CheckTradingFlg) == FALSE &&
            GET_FLAG(domainPtr, A_Domain_CheckTradingFlg) == FALSE)
        {
            if (dataRows[tradConstrIdx1] > 0)
            {
                DBA_FreeDynStTab(data[tradConstrIdx1], dataRows[tradConstrIdx1], (*outputStLst[tradConstrIdx1])); /* PMSTA-41612 - LJE - 201006 */
                data[tradConstrIdx1]     = nullptr;
                dataRows[tradConstrIdx1] = 0;
            }
            if (dataRows[tradConstrIdx2] > 0)
            {
                DBA_FreeDynStTab(data[tradConstrIdx2], dataRows[tradConstrIdx2], (*outputStLst[tradConstrIdx2])); /* PMSTA-41612 - LJE - 201006 */
                data[tradConstrIdx2]     = nullptr;
                dataRows[tradConstrIdx2] = 0;
            }
        }

        /* Test number of strategies found */
        if (dataRows[dataStratIdx] < 1)
        {
			/* REF7248B - CHU - 020314 */
			/* Don't stop process in case no StratLnk was found */
			FLAG_T continueProcess = (FLAG_T)(	(/* Allocate Order */
					 ((GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_AllocateOrder) ||
	   			  (GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_OrderAllocation)) &&
                 /*SRU REF7993 020927*/
					 (GET_ENUM(domainPtr, A_Domain_CheckStratEn) == (ENUM_T)CheckStrat_None)
					)
					||
					(/* Order Entry && Check TC*/
					 (GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_PreTradeCheckStrat) &&
                     ( (IS_NULLFLD(domainPtr, A_Domain_CheckTradingFlg) == FALSE ) &&
	                   (GET_FLAG(domainPtr, A_Domain_CheckTradingFlg) == TRUE ) ) ||
                      dataRows[dataPtfIdx] > 0 /* PMSTA-36828 - CHU - 190812 */
					) ||
               (
               GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_OrderEntryAllocate
               )
			   || /* REF11387 - CHU - 051114 : continue loading for VPO */
               (
               GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_ViewDerivedStrategyObjectives
               )
			   ||
			   ( IS_NULLFLD(domainPtr, A_Domain_FctDictId) == FALSE    &&             /* REF11686 - TEB - 060206 */
			     GET_DICT(domainPtr,   A_Domain_FctDictId) == DictFct_RpcEditConstr)  /* REF11686 - TEB - 060206 */
			   );

			if(!continueProcess)
			{
				/* PMSTA-12119 - KRA - in case of modelling constraint exist, continue process */
				/* but why so many difference in treatment, now we are able to treat portfolio(s) without strat so why not always continue process */
				/* anyway pas trop de changement � la fois */
				if (dataRows[modConstrIdx] == 0 &&
                    /* PMSTA-30076 - CHU - 180227 : also check presence of trading constraints, even without strategies */
                    (dataRows[tradConstrIdx1] == 0 &&
                     dataRows[tradConstrIdx2] == 0 &&
                     IS_NULLFLD(domainPtr, A_Domain_CheckTradingFlg) == FALSE &&
                     GET_FLAG(domainPtr, A_Domain_CheckTradingFlg) == TRUE))
				{
					MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "Strategy");
					DBA_MultiFree(data, outputStLst, dataRows, stLstNbr); /* REF6082 - RAK - 010725 */
					return(RET_DBA_ERR_NODATA);
				}
			}
        }

        DBA_GetDictId(Ptf, &ptfDictId);

        if ((GET_FLAG(domainPtr, A_Domain_ForceLnkFlg) == TRUE) && (stratLnkRows == 0))
        {
            /******************************************************/
            /***               FORCE LINK = 1 = TRUE            ***/
            /******************************************************/
			if (GET_ENUM(domainPtr, A_Domain_LoadHierFlg) == LoadHierPtf_Full &&
				IS_NULLFLD(domainPtr, A_Domain_PtfObjId) == TRUE &&
				ptfIdNbr != NULL &&
				*ptfIdNbr > 0)
			{
				/* PMSTA05762-CHU-080408 */
				/* use ptfIdTab if it was filled with Full load_hierarchy_f mode
				 */
				ioIdNbr = *ptfIdNbr;

				/* Store and return only the identifier */
				if ((ioIdTab = (DBA_DYNFLD_STP *)
							 CALLOC(ioIdNbr, sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR)
				{
					MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, 1);
					return(RET_MEM_ERR_ALLOC);
				}

				/* Copy portfolio infos into Io_Id structure */
				for (int i=0; i<ioIdNbr; i++)
				{
					/* Allocate memory */
					if ((ioIdTab[i] = ALLOC_DYNST(Io_Id)) == NULLDYNST)
					{
						DBA_FreeDynStTab(ioIdTab, i, Io_Id);
						MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "Io_Id");
						return(RET_MEM_ERR_ALLOC);
					}

					/* Set values in Id-structure */
					SET_ID(ioIdTab[i], Io_Id_Id, (*ptfIdTab)[i]);
				}
			}
			else
			{
				/* REF7248B - CHU - 020327 */
				/* This is the last remaining call to this old function that was replaced everywhere by DBA_SelPtfByDomain() */
				/* I didn't replaced it her because it would impact all Strategy reconciliation !! */
				/* This one does not split ptfs if Load Hierarchy Flag is TRUE in the domain */
				if ((ret = DBA_SelectPtfIdByDomain(domainPtr, &ioIdTab, &ioIdNbr)) != RET_SUCCEED)
				{
					DBA_MultiFree(data, outputStLst, dataRows, stLstNbr); /* REF6082 - RAK - 010725 */
					return(ret);
				}
			}

            /* Check number of portfolio's */
            if (ioIdNbr == 0)
            {
                MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "Portfolio");
                DBA_FreeDynStTab(ioIdTab, ioIdNbr, Io_Id);
                DBA_MultiFree(data, outputStLst, dataRows, stLstNbr); /* REF6082 - RAK - 010725 */
                return(RET_DBA_ERR_NODATA);
            }

            /* Calculate number of strategy link records */
            /* PMSTA-41153 - Vishnu - 250720 - need more memory to handel hirearcy constraints*/
            extStratLnkRows = dataRows[0] * ioIdNbr + dataRows[tradConstrIdx1] * dataRows[dataPtfIdx]  + dataRows[tradConstrIdx2] * dataRows[dataPtfIdx];

			/* REF7248B - CHU - 020320 : Re-check number of strategies (+TC) */
			if((extStratLnkRows == 0) &&
				(GET_DICT(domainPtr, A_Domain_FctDictId) != DictFct_OrderEntryAllocate)
				&& /* REF11387 - CHU - 051114 : continue loading for VPO */
				(GET_DICT(domainPtr, A_Domain_FctDictId) != DictFct_ViewDerivedStrategyObjectives))
			{
				/* This time, stop processing since no strategies are available */
				MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "Strategy");
				DBA_FreeDynStTab(ioIdTab, ioIdNbr, Io_Id);
		        DBA_MultiFree(data, outputStLst, dataRows, stLstNbr); /* REF6082 - RAK - 010725 */
				return(RET_DBA_ERR_NODATA);

			}
            /* Allocation memory of pointer array */
            if ((extStratLnkData = (DBA_DYNFLD_STP *)CALLOC(extStratLnkRows, sizeof(DBA_DYNFLD_STP))) == NULL)
            {
                MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, extStratLnkRows);
                DBA_FreeDynStTab(ioIdTab, ioIdNbr, Io_Id);
                DBA_MultiFree(data, outputStLst, dataRows, stLstNbr); /* REF6082 - RAK - 010725 */
                return(RET_MEM_ERR_ALLOC);
            }

            /* For each combination of portfolio and strategy, create a 'extended strategy link' record */
            for (ptfIdx=0, idx = 0 ; ptfIdx<ioIdNbr; ptfIdx++) /* PMSTA08801 - DDV - 091126 */
            {
                /*if load_hierarchy and stratgey linked to child portfolio and parent portfolio in list, skip strategy*/
                if((GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None) &&
                     ((GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_ReconcStrat) ||
                      (GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_CheckStrat) ||
                      (GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_AllocateOrder) ||
                      (GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_OrderEntry) ||
					  (GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_SessionsMonitoring) ||	/* PMSTA-30900 - RAK - 180514 */
                      (GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_PreTradeCheckStrat) ||
                      (GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_OrderAllocation) ||
					  (GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_CheckHoldingConstraints)) && /* REF10684 - CHU - 041007 */
                   (IS_NULLFLD(domainPtr, A_Domain_DimPtfDictId) == FALSE))
                {

                     if(DBA_GetObjectEnum(GET_DICT(domainPtr, A_Domain_DimPtfDictId), &objectPtfEnum) != TRUE)
                     {
                        MSG_SendMesg(RET_DBA_ERR_NODATA, 0, FILEINFO);
                        DBA_FreeDynStTab(ioIdTab, ioIdNbr, Io_Id);
                        DBA_MultiFree(data, outputStLst, dataRows, stLstNbr);
                        return(RET_DBA_ERR_NODATA);
                     }
                     if(objectPtfEnum == List)
                     {
                        for(ll=0; ll < dataRows[dataPtfIdx]; ll++)
                        {
                           if(GET_ID(data[dataPtfIdx][ll], A_Ptf_Id) == GET_ID(ioIdTab[ptfIdx], Io_Id_Id))
                              break;
                        }
                        if(ll == dataRows[dataPtfIdx])
                        {
                           MSG_SendMesg(RET_DBA_ERR_NODATA, 0, FILEINFO);
                           DBA_FreeDynStTab(ioIdTab, ioIdNbr, Io_Id);
                           DBA_MultiFree(data, outputStLst, dataRows, stLstNbr);
                           return(RET_DBA_ERR_NODATA);
                        }
                        if(DBA_ParentInList(GET_ID(data[dataPtfIdx][ll], A_Ptf_ParentPortId), ioIdTab, ioIdNbr))
                           continue;

                     }
                }
                for (stratIdx=0; stratIdx<dataRows[dataStratIdx] ; stratIdx++)
                {
                    /* REF7420 - Don't add ESL if Strat is issued of StratCompo */
                    for (k=0, compoFoundFlg=FALSE; k<dataRows[stratCompoIdx] && compoFoundFlg==FALSE; k++)
                    {
                        DBA_GetObjectEnum(GET_DICT(data[stratCompoIdx][k], A_StratCompo_EntDictId) , &compoObjectEn);

                        if (compoObjectEn == Strat &&
                            GET_ID(data[dataStratIdx][stratIdx], A_Strat_Id) ==
                            GET_ID(data[stratCompoIdx][k], A_StratCompo_ObjId))
                        {
                            compoFoundFlg = TRUE;
                        }
                    }

                    if (compoFoundFlg == TRUE)
                        continue;                   

                    if (TRUE == GET_FLAG(data[dataStratIdx][stratIdx], A_Strat_SubModelFlg) &&
                        dataRows[stratCompoIdx] > 0)
                    {
                        /*if compo is available  dont add submodel records.
                            model ESL/ESE will be added in the code later*/
                        continue;
                    }
                    /*
                        <REF4454 - 000329 - SKE : if Intra Mkt Sgt Flag is set, exclude all model
                        with sub nat as "Constant Weight"
                    */
                    if (intraMktSgtFlg)
                    {
                        if (GET_A_Strat_SubNatEn(data[dataStratIdx][stratIdx]) == StratSubNatEn::ConstantWeight)
                        {
                            MSG_SendMesg(RET_FIN_ERR_MP_EXCLUDED, 0, FILEINFO);
                            continue;
                        }
                    }
                    /* REF4454 - 000329 - SKE */

                    FLAG_T isStratPresentFlg = TRUE;
                    FLAG_T stratPtfLnkFlg = TRUE;

                    if (GET_ENUM(data[dataStratIdx][stratIdx], A_Strat_NatEn) == (ENUM_T)StratNatEn::ConstraintSet ||
                        GET_ENUM(data[dataStratIdx][stratIdx], A_Strat_NatEn) == (ENUM_T)StratNatEn::InvestmentProfile)
                    {
                        isStratPresentFlg = FALSE;
                        stratPtfLnkFlg = FALSE;
                        for (auto stratlnkIdx = 0; stratlnkIdx < dataRows[stratLinkIdx]; stratlnkIdx++)
                        {
                            if (GET_ID(data[dataStratIdx][stratIdx], A_Strat_Id) == GET_ID(data[stratLinkIdx][stratlnkIdx], S_StratLnk_StratId)
                                && GET_FLAG(data[stratLinkIdx][stratlnkIdx], S_StratLnk_MandatoryFlg) == TRUE)
                            {
                                isStratPresentFlg = TRUE;
                                if (IS_NULLFLD(data[stratLinkIdx][stratlnkIdx], S_StratLnk_PtfId) ||
                                    GET_ID(data[stratLinkIdx][stratlnkIdx], S_StratLnk_PtfId) == GET_ID(ioIdTab[ptfIdx], Io_Id_Id))
                                {
                                    stratPtfLnkFlg = TRUE;
                                        break;
                                }
                            }
                        }
                    }
                    
                    if (!(isStratPresentFlg == TRUE && stratPtfLnkFlg == TRUE) &&
                        !(isStratPresentFlg == FALSE && stratPtfLnkFlg == FALSE))
                    {
                        continue;
                    }
                    /* Allocate memory */
                    if ((extStratLnkData[idx] = ALLOC_DYNST(ExtStratLnk)) == NULL) /* PMSTA08801 - DDV - 091126 */
                    {
                        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtStratLnk");
                        DBA_FreeDynStTab(ioIdTab, ioIdNbr, Io_Id);
                        DBA_MultiFree(data, outputStLst, dataRows, stLstNbr); /* REF6082 - RAK - 010725 */
                        return(RET_MEM_ERR_ALLOC);
                    }

                    /* Set values in extended strategy link */
                    COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_StratId,      /* PMSTA08801 - DDV - 091126 */
                                data[dataStratIdx][stratIdx], A_Strat, A_Strat_Id);
                    SET_DICT(extStratLnkData[idx], ExtStratLnk_LnkObjDictId, ptfDictId);     /* PMSTA08801 - DDV - 091126 */
                    COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_ObjId,        /* PMSTA08801 - DDV - 091126 */
                                ioIdTab[ptfIdx], Io_Id, Io_Id_Id);
                    SET_ENUM(extStratLnkData[idx], ExtStratLnk_LnkNatEn, StratLnkNat_Strat); /* PMSTA08801 - DDV - 091126 */
                    COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_BegDate,      /* PMSTA08801 - DDV - 091126 */
                                domainPtr, A_Domain, A_Domain_InterpStratDate);
                    SET_NULL_DATETIME(extStratLnkData[idx], ExtStratLnk_EndDate);            /* PMSTA08801 - DDV - 091126 */
                    SET_NULL_TINYINT(extStratLnkData[idx], ExtStratLnk_Priority);            /* PMSTA08801 - DDV - 091126 */
                    COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_StratNatEn,   /* PMSTA08801 - DDV - 091126 */
                                data[dataStratIdx][stratIdx], A_Strat, A_Strat_NatEn);
                    SET_FLAG(extStratLnkData[idx], ExtStratLnk_DirectFlg, TRUE);             /* PMSTA08801 - DDV - 091126 */
                    /* SET_FLAG(extStratLnkData[idx], ExtStratLnk_EnumFlg, FALSE); REF6180 - DDV - 010717 */ /* PMSTA08801 - DDV - 091126 */
                    /* SET_FLAG(extStratLnkData[idx], ExtStratLnk_EnumFlg, FALSE); */        /* PMSTA08801 - DDV - 091126 */
                    COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_PtfId,        /* PMSTA08801 - DDV - 091126 */
                                ioIdTab[ptfIdx], Io_Id, Io_Id_Id);
                    SET_NULL_ID(extStratLnkData[idx], ExtStratLnk_ListId);                   /* PMSTA08801 - DDV - 091126 */
                    COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_ParStratId,   /* PMSTA08801 - DDV - 091126 */
                                data[dataStratIdx][stratIdx], A_Strat, A_Strat_ParentStratId);

					/* PMSTA07121 - RAK - 090424 */
					SET_ENUM(extStratLnkData[idx], ExtStratLnk_CriticalnessEn,               /* PMSTA08801 - DDV - 091126 */
						GET_ENUM(data[dataStratIdx][stratIdx], A_Strat_CriticalnessEn));

                    objectEnum = NullEntity;
                    if (IS_NULLFLD(data[dataStratIdx][stratIdx], A_Strat_DimGridDictId) == FALSE)
                    {
                        DBA_GetObjectEnum(GET_DICT(data[dataStratIdx][stratIdx], A_Strat_DimGridDictId), &objectEnum);
                    }
                    if (objectEnum == List)
                    {
                        COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_GridListId,    /* PMSTA08801 - DDV - 091126 */
                                    data[dataStratIdx][stratIdx], A_Strat, A_Strat_GridObjId);
                    }
                    else if (objectEnum == Grid)
                    {
                        COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_GridId,        /* PMSTA08801 - DDV - 091126 */
                                    data[dataStratIdx][stratIdx], A_Strat, A_Strat_GridObjId);
                    }
                    /* Parent Strategy Market Segment Id */
                    COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_ParStratMktSgtId,  /* PMSTA08801 - DDV - 091126 */
                                data[dataStratIdx][stratIdx], A_Strat, A_Strat_MktSegmentId);
                    /* END SKE */
                    /* REF4047 - 20000204 - SKE : Sub Nature management */
                    SET_ENUM(extStratLnkData[idx], ExtStratLnk_SubNatEn, GET_ENUM(data[dataStratIdx][stratIdx], A_Strat_SubNatEn)); /* PMSTA08801 - DDV - 091126 */

                    COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_MktSegId,          /* PMSTA08801 - DDV - 091126 */
                                data[dataStratIdx][stratIdx], A_Strat, A_Strat_MktSegmentId);

                    /*PMSTA-38428 -Vishnu 21022020 ModelOfModels*/
                    if (TRUE == GET_FLAG(data[dataStratIdx][stratIdx], A_Strat_SubModelFlg))
                    {
                        /*If strategy is a submodel set submodel flag */
                        SET_FLAG(extStratLnkData[idx], ExtStratLnk_SubModelFlg, TRUE);
                    }
                    if (IS_NULLFLD(data[dataStratIdx][stratIdx], A_Strat_MktSegmentId) != TRUE)
                    {
                        ID_T gridId=0;

                        if ((ret = DBA_GetMktSegtGridIdFromMultiSelect(data[sMktSegtIdx], dataRows[sMktSegtIdx],
                                                            GET_ID(data[dataStratIdx][stratIdx], A_Strat_MktSegmentId), &gridId)) != RET_SUCCEED)
                        {
                            DBA_FreeDynStTab(ioIdTab, ioIdNbr, Io_Id);
                            DBA_MultiFree(data, outputStLst, dataRows, stLstNbr); /* REF6082 - RAK - 010725 */
                            DBA_FreeDynStTab(extStratLnkData, extStratLnkRows, ExtStratLnk);
                            return(ret);
                        }

                        SET_ID(extStratLnkData[idx], ExtStratLnk_ParGridId, gridId); /* PMSTA08801 - DDV - 091126 */
                    }

                    /* Increment record number */
                    idx++; /* PMSTA08801 - DDV - 091126 */
                }
            }

            if ((ret = DBA_TradConstr2ExtStratLnk(domainPtr, data, dataRows, extStratLnkData, &idx, tradConstrIdx1, tradConstrIdx2, dataPtfIdx)) != RET_SUCCEED) /* PMSTA08801 - DDV - 091126 */
            {
               MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtStratLnk");
               DBA_FreeDynStTab(ioIdTab, ioIdNbr, Io_Id);
               DBA_MultiFree(data, outputStLst, dataRows, stLstNbr);
               return ret;
            }

            effExtStratLnkRows = idx; /* PMSTA08801 - DDV - 091126 */

            /* Free memory allocation */
            DBA_FreeDynStTab(ioIdTab, ioIdNbr, Io_Id);
        }
        else
        {
            /**************************************************************************/
            /***               FORCE LINK = 0 = FALSE           ***/
            /**************************************************************************/
           /*SRU - REF 7993 - 020926 - don't create ESLs for strategies even if strategies loaded
             if they don't have to be checked and only TCs must be checked*/
           if(((GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_AllocateOrder &&
				/* REF11049 - CHU - 050322 : Do not discard strategies for this allocation nature */
			   GET_ENUM(domainPtr, A_Domain_OrderAllocNatEn) != DomOrderAllocNat_InstrResultStratSgt) ||
	   			(GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_OrderAllocation)) &&
					(GET_ENUM(domainPtr, A_Domain_CheckStratEn) == (ENUM_T)CheckStrat_None))
               stratLnkRows = 0;
            /* Calculate number of strategy link records */

           /* PMSTA-41153 - Vishnu - 250720 - need more memory to handel hirearcy constraints*/
           extStratLnkRows = stratLnkRows + dataRows[tradConstrIdx1] * dataRows[dataPtfIdx] + dataRows[tradConstrIdx2] * dataRows[dataPtfIdx];

#if 0
			/* PMSTA-27889 - CHU - 170719 */
			/* < REF7248B - CHU - 020320 : Re-check global number of strategy links (+TC) */
			if((extStratLnkRows == 0) &&
				(GET_DICT(domainPtr, A_Domain_FctDictId) != DictFct_OrderEntryAllocate) &&
				/* REF11387 - CHU - 051114 : continue loading for VPO */
				(GET_DICT(domainPtr, A_Domain_FctDictId) != DictFct_ViewDerivedStrategyObjectives) &&
			    (GET_DICT(domainPtr, A_Domain_FctDictId) != DictFct_RpcEditConstr))  /* REF11686 - TEB - 060206 */
			{
                /* PMSTA07170 - DDV - If no link found for allocate order without check strat, continue */
                if ((GET_DICT(domainPtr, A_Domain_FctDictId) != DictFct_AllocateOrder &&
                     GET_DICT(domainPtr, A_Domain_FctDictId) != DictFct_OrderAllocation) || /* PMSTA-24542 - CHU - 170310 */
                   GET_ENUM(domainPtr, A_Domain_CheckStratEn) != CheckStrat_None)
                {
				    /* This time, stop processing since no strategy links are available */
				    MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "Strategy Link");
					if (applStratActivateNoLinkError == TRUE) /* PMSTA10000-CHU-100603 : The ultimate parameter! */
					{
						DBA_MultiFree(data, outputStLst, dataRows, stLstNbr); /* REF6082 - RAK - 010725 */
						DBA_FreeDynStTab(stratLnkData, stratLnkRows, S_StratLnk);
						/* REF4341 - SSO - 000320  return(ret); -> specific msg for gui */
						return(RET_FIN_ERR_NO_STRAT_LNK);
					}
                }
			}
#endif

            /* < REF7248B - CHU - 020320 : Re-check global number of strategy links (+TC) */
            if ((GET_DICT(domainPtr, A_Domain_FctDictId) != DictFct_OrderEntryAllocate) &&
                /* REF11387 - CHU - 051114 : continue loading for VPO */
                (GET_DICT(domainPtr, A_Domain_FctDictId) != DictFct_ViewDerivedStrategyObjectives) &&
                (GET_DICT(domainPtr, A_Domain_FctDictId) != DictFct_RpcEditConstr))  /* REF11686 - TEB - 060206 */
            {
                /* PMSTA07170 - DDV - If no link found for allocate order without check strat, continue */
                if ((GET_DICT(domainPtr, A_Domain_FctDictId) != DictFct_AllocateOrder &&
                    GET_DICT(domainPtr, A_Domain_FctDictId) != DictFct_OrderAllocation) || /* PMSTA-24542 - CHU - 170310 */
                    GET_ENUM(domainPtr, A_Domain_CheckStratEn) != CheckStrat_None)
                {
                    /* This time, stop processing since no strategy links are available */
                    /* < REF7248B - CHU - 020320 : Re-check global number of strategy links (+TC) */
                    if (extStratLnkRows == 0)
                    {
                        if (applStratActivateNoLinkError == TRUE) /* PMSTA10000-CHU-100603 : The ultimate parameter! */
                        {
							MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "Strategy Link");/* PMSTA-47097-231121-GRA:Error msg not needed when STRAT_ACTIVATE_NOLINK_ERROR = 0*/
                            DBA_MultiFree(data, outputStLst, dataRows, stLstNbr); /* REF6082 - RAK - 010725 */
                            /* REF4341 - SSO - 000320  return(ret); -> specific msg for gui */
                            return(RET_FIN_ERR_NO_STRAT_LNK);
                        }
                    }
                    else /* PMSTA-27889 - CHU - 170717 : subtract links not belonging to hierarchical portfolio itself */
                    {
                        if ((GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None) &&
                            IS_NULLFLD(domainPtr, A_Domain_DimPtfDictId) == FALSE &&
                            DBA_GetObjectEnum(GET_DICT(domainPtr, A_Domain_DimPtfDictId), &objectPtfEnum) == TRUE &&
                            objectPtfEnum == Ptf &&
                            applStratActivateNoLinkError == TRUE)
                        {
                            int stratLnkForParentNbr = stratLnkRows;

                            for (stratIdx = 0, idx = 0; stratIdx < stratLnkRows; stratIdx++) /* PMSTA08801 - DDV - 091126 */
                            {
                                for (ll = 0; ll < dataRows[dataPtfIdx]; ll++)
                                {
                                    if (CMP_ID(GET_ID(data[dataPtfIdx][ll], A_Ptf_Id), GET_ID(stratLnkData[stratIdx], S_StratLnk_PtfId)) == 0)
                                        break;
                                }
                                if (ll < dataRows[dataPtfIdx])
                                {
                                    if (DBA_ParentInList(GET_ID(data[dataPtfIdx][ll], A_Ptf_ParentPortId), data[dataPtfIdx], dataRows[dataPtfIdx]))
                                        stratLnkForParentNbr--;
                                }
                                else
                                {
                                    stratLnkForParentNbr--;
                                }
                            }

                            if (stratLnkForParentNbr == 0)
                            {
                                MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "Strategy Link");
                                DBA_MultiFree(data, outputStLst, dataRows, stLstNbr); /* REF6082 - RAK - 010725 */
                                /* REF4341 - SSO - 000320  return(ret); -> specific msg for gui */
                                return(RET_FIN_ERR_NO_STRAT_LNK);
                            }
                        }
                    }
                }
            }
			/* REF7248B - CHU - 020320 > */

            /* Allocation memory of pointer array */
			if (extStratLnkRows > 0) /* REF11387 - CHU - 051114 : May be zero */
			{
				if ((extStratLnkData = (DBA_DYNFLD_STP *)CALLOC(extStratLnkRows, sizeof(DBA_DYNFLD_STP))) == NULL)
				{
					MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, extStratLnkRows);
					DBA_MultiFree(data, outputStLst, dataRows, stLstNbr); /* REF6082 - RAK - 010725 */
					return(RET_MEM_ERR_ALLOC);
				}
			}

            /* --------------------------- */
            /* BEGIN DVP060 - RAK - 960522 */
            if (GET_DICT(domainPtr, A_Domain_DimStratDictId) != 0) /* All */
            {
                if (DBA_GetObjectEnum(GET_DICT(domainPtr, A_Domain_DimStratDictId), &objectEnum) != TRUE)
                {
                    MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "Strategy Link");
                    return(ret);
                }

                /* BUG - RAK - 960708 */
                if ((inputPtr = ALLOC_DYNST(Adm_Arg)) == NULL)
                {
                    MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "Adm_Arg");
                    return(ret);
                }

                if (objectEnum == List) /* strategy list */
                {
                    ret = DBA_SelectByListId(GET_ID(domainPtr, A_Domain_StratObjId),
                                             Strat,
                                             UNUSED,
                                             Adm_Arg,
                                             inputPtr,
                                             Io_Id,
                                             &ioIdTab,
                                             UNUSED,
                                             UNUSED,
                                             &ioIdNbr,
                                             NULL);
                }
                else              /* unique strategy */
                {
                    /* Allocation memory of pointer array */
                    if ((ioIdTab = (DBA_DYNFLD_STP *)CALLOC(1, sizeof(DBA_DYNFLD_STP))) == NULL)
                    {
                        MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, 1);
                        return(RET_MEM_ERR_ALLOC);
                    }

                    /* Allocate memory */
                    if ((ioIdTab[0] = ALLOC_DYNST(Io_Id)) == NULL)
                    {
                        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "Io_Id");
                        FREE(ioIdTab);
                        return(RET_MEM_ERR_ALLOC);
                    }

                    /* Set values in Id-structure */
                    COPY_DYNFLD(ioIdTab[0], Io_Id, Io_Id_Id, domainPtr, A_Domain, A_Domain_StratObjId);
                    ioIdNbr = 1;
                }

                /* BUG - RAK - 960708 */
                FREE_DYNST(inputPtr, Adm_Arg);
            }
            else
            {
                ioIdNbr = 0;
                ioIdTab = NULL;
            }
            /* END DVP060 - RAK - 960522 */
            /* ------------------------- */

            /* Build an array of 'Extended Strategy Link' from S_StratLnk */
            /*
                REF4047 - 000201 - SKE : I prefer build 'Extended Strategy Link' from
                S_StratLnk VIA A_Strat because A_Strat has more information than S_StratLnk.
            */
            for (stratIdx=0, idx=0 ; stratIdx<stratLnkRows ; stratIdx++) /* PMSTA08801 - DDV - 091126 */
            {
                /* Search A_Strat linked to current S_StratLnk */
                aStratFoundFlg = FALSE;
                for (aStratPos = 0 ; aStratPos < dataRows[dataStratIdx] && aStratFoundFlg == FALSE ; aStratPos++)
                {
                    if (GET_ID(data[dataStratIdx][aStratPos], A_Strat_Id) == GET_ID(stratLnkData[stratIdx], S_StratLnk_StratId))
                    {
                        aStratFoundFlg = TRUE;
                        break;
                    }
                }

                if (aStratFoundFlg == FALSE)
                {
					/* REF10778 - RAK - 050106 - In case of Composite, no error and continue ! */
					if (GET_ENUM(stratLnkData[stratIdx], S_StratLnk_StratNatEn) == StratNat_Composite)
						continue;

                    MSG_SendMesg(RET_DBA_ERR_NODATA, 0, FILEINFO);
                    DBA_MultiFree(data, outputStLst, dataRows, stLstNbr);
                    DBA_FreeDynStTab(extStratLnkData, extStratLnkRows, ExtStratLnk);
                    FREE(ioIdTab);
                    return(RET_DBA_ERR_NODATA);
                }
                /*
                    <REF4454 - 000329 - SKE : if Intra Mkt Sgt Flag is set, exclude all model
                    with sub nat as "Constant Weight"
                */
                if (intraMktSgtFlg)
                {
                    if (GET_A_Strat_SubNatEn(data[dataStratIdx][aStratPos]) == StratSubNatEn::ConstantWeight)
                    {
                        /* LOG MESSAGE : TODO TODO */
                        continue;
                    }
                }
                /* REF4454 - 000329 - SKE */

                /*if load_hierarchy and stratgey linked to child portfolio and parent portfolio in list, skip strategy*/
                if((GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None) &&
                   ((GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_ReconcStrat) ||
                    (GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_CheckStrat) ||
                    (GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_AllocateOrder) ||
                    (GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_OrderEntry) ||
					(GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_SessionsMonitoring) ||	/* PMSTA-30900 - RAK - 180514 */
                    (GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_PreTradeCheckStrat) ||
                    (GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_OrderAllocation) ||
					(GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_CheckHoldingConstraints)) && /* REF10684 - CHU - 041007 */
                   (IS_NULLFLD(domainPtr, A_Domain_DimPtfDictId) == FALSE))
                {

                     if(DBA_GetObjectEnum(GET_DICT(domainPtr, A_Domain_DimPtfDictId), &objectPtfEnum) != TRUE)
                     {
                        MSG_SendMesg(RET_DBA_ERR_NODATA, 0, FILEINFO);
                        DBA_MultiFree(data, outputStLst, dataRows, stLstNbr);
                        DBA_FreeDynStTab(extStratLnkData, extStratLnkRows, ExtStratLnk);
                        FREE(ioIdTab);
                        return(RET_DBA_ERR_NODATA);
                     }
					 /* REF10365 - CHU - 040802 */
                     if((objectPtfEnum == List) || (objectPtfEnum == QuickSearch))
                     {
                        for(ll=0; ll<dataRows[dataPtfIdx]; ll++)
                        {
                           if(GET_ID(data[dataPtfIdx][ll], A_Ptf_Id) ==
                              GET_ID(stratLnkData[stratIdx], S_StratLnk_PtfId))
                              break;
                        }
                        if(ll < dataRows[dataPtfIdx])
                        {
                           if(DBA_ParentInList(GET_ID(data[dataPtfIdx][ll], A_Ptf_ParentPortId), data[dataPtfIdx], dataRows[dataPtfIdx]))
                              continue;
                        }
                        else
                        {
                           MSG_SendMesg(RET_DBA_ERR_NODATA, 0, FILEINFO);
                           DBA_MultiFree(data, outputStLst, dataRows, stLstNbr);
                           DBA_FreeDynStTab(extStratLnkData, extStratLnkRows, ExtStratLnk);
                           FREE(ioIdTab);
                           return(RET_DBA_ERR_NODATA);
                        }
                     }
                }
                /* WEALTH-6213 - HierarchyConsolidated holding constraints are always loaded with load Hier FULL/From Parent */
                if (GET_ENUM(domainPtr, A_Domain_LoadHierFlg) == LoadHierPtf_None && 
                    GET_ENUM(stratLnkData[stratIdx], S_StratLnk_StratNatEn) == (ENUM_T)StratNatEn::ConstraintSet)
                {
                    bool skipHierConsConstr = false;
                    ID_T headPtfId = ZERO_ID;
                    ret = DBA_GetHierHeadPTF(GET_ID(stratLnkData[stratIdx], S_StratLnk_ObjId), &headPtfId);
                    /*for get_ptf_childs*/
                    DbiConnectionHelper connHelper;

                    if (!connHelper.isValidAndInit())
                    {
                        MSG_SendMesg(FILEINFO, "FIN_SetAddDetailsinMC : connection not valid / init ");
                        return RET_DBA_ERR_CONNOTFOUND;
                    }

                    /*get child PTF number to check if standalone ptf or not*/
                    DBA_DYNFLD_STP ioId = mp.allocDynst(FILEINFO, Io_Id);
                    SET_ID(ioId, Io_Id_Id, headPtfId);
                    /* sel_sh_portfolio_by_parent */
                    if ((ret = connHelper.dbaSelect(Ptf, UNUSED, ioId, S_Ptf, &childPtfTab, &childPtfNb)) != RET_SUCCEED)
                    {
                        MSG_SendMesg(FILEINFO, "FIN_OverlayLoadData : Select failed");
                        DBA_FreeDynStTab(childPtfTab, childPtfNb, S_Ptf);
                        return ret;
                    }
                    DBA_FreeDynStTab(childPtfTab, childPtfNb, S_Ptf);
                    if (ret = DBA_GetStratById(GET_ID(stratLnkData[stratIdx], S_StratLnk_StratId),
                        FALSE,
                        &allocFlg,
                        &stratPtr,
                        strategyHierHead,
                        UNUSED,
                        UNUSED) == RET_SUCCEED)
                    {
                        FLAG_T hierConstrUsed = 0;
                        GEN_GetApplInfo(ApplHierConstraintUsed, &hierConstrUsed);
                        for (ll = 0; ll < dataRows[dataPtfIdx]; ll++)
						{
                            // Load Hier Consolidated constraints for a  standalone pf 
							if (StratApplicationScopeEn::HierarchyConsolidated == static_cast<StratApplicationScopeEn>GET_ENUM(stratPtr, A_Strat_ApplicationScopeEn))
							{
                                if (hierConstrUsed == 0 || (IS_NULLFLD(data[dataPtfIdx][ll], A_Ptf_ParentPortId) == FALSE) ||
                                    (CMP_ID(GET_ID(data[dataPtfIdx][ll], A_Ptf_Id), headPtfId) == 0 &&
                                        childPtfNb))
                                {
                                    skipHierConsConstr = true;
                                    break;
                                }
							}
                        }
                        if (allocFlg == TRUE)
                        {
                            FREE_DYNST(stratPtr, A_Strat);
                        }
                    }
                    if (skipHierConsConstr)
                        continue;
                }
                if ((extStratLnkData[idx] = ALLOC_DYNST(ExtStratLnk)) == NULL) /* PMSTA08801 - DDV - 091126 */
                {
                    MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtStratLnk");
                    DBA_MultiFree(data, outputStLst, dataRows, stLstNbr); /* REF6082 - RAK - 010725 */
                    DBA_FreeDynStTab(extStratLnkData, extStratLnkRows, ExtStratLnk);
                    FREE(ioIdTab);
                    return(RET_MEM_ERR_ALLOC);
                }

                /* --------------------------- */
                /* BEGIN DVP060 - RAK - 960522 */
                if (GET_DICT(domainPtr, A_Domain_DimStratDictId) == 0) /* All */
                {
                    found = TRUE;
                }
                else
                {
                    int j;
                    for(j=0, found=FALSE; j<ioIdNbr && found==FALSE; j++)
                    {
                        if (GET_ID(stratLnkData[stratIdx], S_StratLnk_StratId) == GET_ID(ioIdTab[j], Io_Id_Id))
                        {
                            found = TRUE;
                        }
                    }
                }

                if (found == FALSE)
                {
                    SET_ENUM(extStratLnkData[idx], ExtStratLnk_CalcEn, (ENUM_T) StratCalc_Calc); /* PMSTA08801 - DDV - 091126 */
                }
                /* END DVP060 - RAK - 960522 */
                /* ------------------------- */

                /* Set values in extended strategy link */
                /* DVP460 : generate unique identifier */

                COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_StratId,      /* PMSTA08801 - DDV - 091126 */
                            stratLnkData[stratIdx], S_StratLnk, S_StratLnk_StratId);
                COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_LnkObjDictId, /* PMSTA08801 - DDV - 091126 */
                            stratLnkData[stratIdx], S_StratLnk, S_StratLnk_LnkObjDictId);
                COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_ObjId,        /* PMSTA08801 - DDV - 091126 */
                            stratLnkData[stratIdx], S_StratLnk, S_StratLnk_ObjId);
                COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_LnkNatEn,     /* PMSTA08801 - DDV - 091126 */
                            stratLnkData[stratIdx], S_StratLnk, S_StratLnk_LnkNatEn);
                COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_BegDate,      /* PMSTA08801 - DDV - 091126 */
                            stratLnkData[stratIdx], S_StratLnk, S_StratLnk_BegDate);
                COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_EndDate,      /* PMSTA08801 - DDV - 091126 */
                            stratLnkData[stratIdx], S_StratLnk, S_StratLnk_EndDate);
                COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_Priority,     /* PMSTA08801 - DDV - 091126 */
                            stratLnkData[stratIdx], S_StratLnk, S_StratLnk_Priority);
                /* WEALTH-7573-Ravindra-09052024 */
                if(GET_FLAG(stratLnkData[stratIdx], S_StratLnk_MandatoryFlg) == TRUE && 
                    GET_ENUM(stratLnkData[stratIdx], S_StratLnk_StratNatEn) == (ENUM_T)StratNatEn::ConstraintSet)
                {
                    SET_NULL_ENUM(extStratLnkData[idx], ExtStratLnk_CalcEn);
                }
                COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_StratNatEn,   /* PMSTA08801 - DDV - 091126 */
                            stratLnkData[stratIdx], S_StratLnk, S_StratLnk_StratNatEn);
                COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_DirectFlg,    /* PMSTA08801 - DDV - 091126 */
                            stratLnkData[stratIdx], S_StratLnk, S_StratLnk_DirectFlg);
                COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_PtfId,        /* PMSTA08801 - DDV - 091126 */
                            stratLnkData[stratIdx], S_StratLnk, S_StratLnk_PtfId);
                COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_ListId,       /* PMSTA08801 - DDV - 091126 */
                            stratLnkData[stratIdx], S_StratLnk, S_StratLnk_ListId);
                COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_ParStratId,   /* PMSTA08801 - DDV - 091126 */
                            stratLnkData[stratIdx], S_StratLnk, S_StratLnk_ParStratId);
                /* WEALTH-5953-Ravindra-25042024 */
                COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_OrigPortfolioId,
                    stratLnkData[stratIdx], S_StratLnk, S_StratLnk_PtfId);
                if (IS_NULLFLD(stratLnkData[stratIdx], S_StratLnk_DimGridDictId) == FALSE)
                {
                    DBA_GetObjectEnum(GET_DICT(stratLnkData[stratIdx], S_StratLnk_DimGridDictId), &objectEnum);
                }
                if (objectEnum == List)
                {
                    COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_GridListId, /* PMSTA08801 - DDV - 091126 */
                                stratLnkData[stratIdx], S_StratLnk, S_StratLnk_GridObjId);
                }
                else if (objectEnum == Grid)
                {
                    COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_GridId, /* PMSTA08801 - DDV - 091126 */
                                stratLnkData[stratIdx], S_StratLnk, S_StratLnk_GridObjId);
                }
                /* Parent Strategy Market Segment Id */
                COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_ParStratMktSgtId, /* PMSTA08801 - DDV - 091126 */
                            data[dataStratIdx][aStratPos], A_Strat, A_Strat_MktSegmentId);
                /* END SKE */

                /* REF4047 - 20000204 - SKE : Sub Nature management */
                SET_ENUM(extStratLnkData[idx], ExtStratLnk_SubNatEn, GET_ENUM(data[dataStratIdx][aStratPos], A_Strat_SubNatEn)); /* PMSTA08801 - DDV - 091126 */

				/* PMSTA07121 - RAK - 081030 */
				SET_ENUM(extStratLnkData[idx], ExtStratLnk_CriticalnessEn, GET_ENUM(data[dataStratIdx][aStratPos], A_Strat_CriticalnessEn)); /* PMSTA08801 - DDV - 091126 */

                /* RAK 960412 */
                COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_ParGridId, /* PMSTA08801 - DDV - 091126 */
                            stratLnkData[stratIdx], S_StratLnk, S_StratLnk_ParGridId);
                COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_MktSegId, /* PMSTA08801 - DDV - 091126 */
                            stratLnkData[stratIdx], S_StratLnk, S_StratLnk_MktSegId);
                idx++; /* PMSTA08801 - DDV - 091126 */
            }

            if((ret = DBA_TradConstr2ExtStratLnk(domainPtr, data, dataRows, extStratLnkData, &idx, tradConstrIdx1, tradConstrIdx2, dataPtfIdx)) != RET_SUCCEED) /* PMSTA08801 - DDV - 091126 */
            {
               MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtStratLnk");
              DBA_FreeDynStTab(ioIdTab, ioIdNbr, Io_Id);
               DBA_MultiFree(data, outputStLst, dataRows, stLstNbr);
               return ret;
            }

            effExtStratLnkRows = idx; /* PMSTA08801 - DDV - 091126 */

            /* Free memory allocation */

            /* --------------------------- */
            /* BEGIN DVP060 - RAK - 960522 */
            if (ioIdTab != NULL)
            {
                DBA_FreeDynStTab(ioIdTab, ioIdNbr, Io_Id);
            }
            /* END DVP060 - RAK - 960522 */
            /* ------------------------- */
        }

        /* Distribute 'Extended Strategy Link' */
        ret = DBA_AddHierRecordList(strategyHierHead,
                                    extStratLnkData,
                                    effExtStratLnkRows,
                                    ExtStratLnk,
                                    TRUE);
        if (ret != RET_SUCCEED)
        {
            MSG_SendMesg(RET_DBA_ERR_HIER, 0 , FILEINFO);
            DBA_FreeDynStTab(extStratLnkData, extStratLnkRows, ExtStratLnk);
            DBA_MultiFree(data, outputStLst, dataRows, stLstNbr); /* REF6082 - RAK - 010725 */
            return(ret);
        }

        /* Free of extended strategy link Array (not records !) */
        FREE(extStratLnkData);

        /* REF6082 - RAK - 010725 - Use loop and outputMatch         */
        /* i = 0,  Distribute 'all strategy'                         */
        /* i = 1,  Distribute 'all strategy history'                 */
        /* ...                                                       */

        for (int i=0; i<stLstNbr; i++)
        {
            if (i == holdConstrscriptIdx) /* holding constraint script */ /* PMSTA-28970 - CHU - 171228 */
            {
                if (dataRows[i] > 0)
                {
                    /* BUG454 - RAK - 970805 */
		            ret = DBA_GroupScriptDef(data[i],
                                             dataRows[i],
                                             FALSE,
                                             FALSE,
                                             &groupScriptDefTab,
                                             &groupScriptDefNbr);

                    if (ret == RET_GEN_INFO_NOACTION)
                    {
                        ret = DBA_AddHierRecordList(strategyHierHead,
                                                    data[i],
                                                    dataRows[i],
                                                    *(outputStLst[i]),
                                                    TRUE);
                    }
                    else if (ret == RET_SUCCEED)
                    {
                        ret = DBA_AddHierRecordList(strategyHierHead,
                                                    groupScriptDefTab,
                                                    groupScriptDefNbr,
                                                    *(outputStLst[i]),
                                                    TRUE);

                        /* free all record from data[3] (not insert in hierarchy) */
                        /* don't free array !!! XDI 13/08/97 */
                        for (int j=0; j<dataRows[i]; j++)
                        {
                            FREE_DYNST((data[i][j]), *(outputStLst[i])); /* REF8844 - LJE - 030423 */
                        }

                        /* PEN 97/08/12 */
                        FREE(groupScriptDefTab);
                    }
                }
            }
            else if (i == tradConstrscriptIdx) /* trading constraint script */ /* PMSTA-28970 - CHU - 171228 */
            {
                if (dataRows[i] > 0)
                {
                    /* BUG454 - RAK - 970805 */
		            ret = DBA_GroupScriptDef(data[i],
                                             dataRows[i],
                                             FALSE,
                                             FALSE,
                                             &groupScriptDefTab,
                                             &groupScriptDefNbr);

                    if (ret == RET_GEN_INFO_NOACTION)
                    {
                        ret = DBA_AddHierRecordList(strategyHierHead,
                                                    data[i],
                                                    dataRows[i],
                                                    *(outputStLst[i]),
                                                    TRUE);
                    }
                    else if (ret == RET_SUCCEED)
                    {
                        ret = DBA_AddHierRecordList(strategyHierHead,
                                                    groupScriptDefTab,
                                                    groupScriptDefNbr,
                                                    *(outputStLst[i]),
                                                    TRUE);

                        /* free all record from data[3] (not insert in hierarchy) */
                        /* don't free array !!! XDI 13/08/97 */
                        for (int j=0; j<dataRows[i]; j++)
                        {
                            FREE_DYNST((data[i][j]), *(outputStLst[i])); /* REF8844 - LJE - 030423 */
                        }

                        /* PEN 97/08/12 */
                        FREE(groupScriptDefTab);
                    }
                }
            }
            else
            {
		        ret = DBA_AddHierRecordList(strategyHierHead,
                                             data[i],
                                             dataRows[i],
                                             *(outputStLst[i]),
                                             TRUE);
	        }

            if (ret != RET_SUCCEED)
            {
                MSG_SendMesg(RET_DBA_ERR_HIER, 0 , FILEINFO);
                /* the precedent data are already in hierarchy, don't free them */
                DBA_MultiFree(&(data[i]), &(outputStLst[i]), &(dataRows[i]), stLstNbr-i);
                return(ret);
	        }
        }


		/* VST - ACM Notional Instruments LN7487 - 020708 */
		{
			ID_T * sslIdList = NULL;
			int nrSsl = 0;

			if( dataRows[dataInstrIdx] > 0 )
			{
				if((sslIdList = ( ID_T *)CALLOC(dataRows[dataInstrIdx], sizeof(ID_T)) ) == NULL)
				{
					MSG_SendMesg(RET_MEM_ERR_ALLOC, 0 , FILEINFO);
		            return RET_MEM_ERR_ALLOC;
				}

				for(int i=0; i<dataRows[dataInstrIdx]; i++)
				{
					if( GET_ENUM(data[dataInstrIdx][i], A_Instr_NatEn) == InstrNat_NotionalInstr )
						if( ! IS_NULLFLD(data[dataInstrIdx][i], A_Instr_SslStratId ) )
						{
                            int j;
							for(j=0; j<nrSsl; j++)
							{
								if(sslIdList[j] == GET_ID(data[dataInstrIdx][i], A_Instr_SslStratId))
									break;
							}
							if(j==nrSsl)
								sslIdList[nrSsl++] = GET_ID(data[dataInstrIdx][i], A_Instr_SslStratId);
						}
				}
				for(int i=0; i<nrSsl; i++)
					if((ret = DBA_SelOneSslData(sslIdList[i], strategyHierHead, domainPtr)) != RET_SUCCEED)
					{
						FREE(sslIdList);
						return ret;
					}
			}
            FREE(sslIdList); /* REF9954 - TEB - 040305 */
		}




        for (int i = 0; i < stLstNbr; i++)
        { FREE(data[i]);}

        /*****************************/
        /* Update links              */
        /*****************************/
		/*PMSTA-46766 - Adding overrride currency extension type in to instr table*/
		DBA_SetHierLnkUsed(strategyHierHead,
			A_Instr,
			A_Instr_OverrideCur_Ext);
		DBA_MakeSpecRecLinks(strategyHierHead,
			A_Instr,
			A_Instr_OverrideCur_Ext);

		/* PMSTA-46842-SENTHIL-10022022 */
		ENUM_T          applMarketstructEnum;
		GEN_GetApplInfo(ApplMarketStructureattribEnum, &applMarketstructEnum);
		
		if (applMarketstructEnum == 1)
		{
			DBA_SetHierLnkUsed(strategyHierHead,
				A_StratElt,
				A_StratElt_A_InstrMktsegOverride_Ext);
			DBA_MakeSpecRecLinks(strategyHierHead,
				A_StratElt,
				A_StratElt_A_InstrMktsegOverride_Ext);
		}

        /* REF4047 - 000114 - SKE  */
        if ((ret = DBA_SetHierLnkUsed(strategyHierHead, /* REF7264 - LJE - 020131 */
                                      A_ListCompo,
                                      A_ListCompo_A_Grid_Ext)) != RET_SUCCEED)
            return(ret);

        /* REF3678 - RAK - 990816 - New link between new hierarchy elements */
        if ((ret = DBA_SetHierLnkUsed(strategyHierHead, A_Grid, /* REF7264 - LJE - 020131 */
                                      A_Grid_S_MktSegt_Ext)) != RET_SUCCEED)
            return(ret);

        /* REF7420 - RAK - 020611 - New link between A_MktStruct and S_MktSegt */
        if ((ret = DBA_SetHierLnkUsed(strategyHierHead, A_MktStruct,
                                      A_MktStruct_S_MktSegt_Ext)) != RET_SUCCEED)
            return(ret);

        /* REF4047 - 000114 - SKE : the links are created in FIN_BuildLinkForMultiGrid() */
        /* ExtStratLnk_A_Grid_Ext, ExtStratLnk_S_MktSgt_Ext, ExtStratLnk_A_Strat_Ext,    */
        /* ExtStratLnk_A_StratHist_Ext, ExtStratLnk_ParStrat_ExtStratLnk_Ext,            */
        /* ExtStratLnk_ParGrid_ExtStratLnk_Ext                                           */

        if ((ret = DBA_SetHierLnkUsed(strategyHierHead,
                   A_Strat, A_Strat_A_StratHist_Ext)) != RET_SUCCEED)
        {
           MSG_SendMesg(RET_DBA_ERR_HIER, 0 , FILEINFO);
            return(ret);
        }

/* BSA - PMSTA00183 - 061212 */
#if 0
        if ((ret = DBA_SetHierLnkUsed((DBA_HIER_HEAD_STP)strategyHierHead,
                   A_StratElt, A_StratElt_MktSegt_A_StratElt_Ext)) != RET_SUCCEED)
        {
            MSG_SendMesg(RET_DBA_ERR_HIER, 0 , FILEINFO);
            return(ret);
        }
#endif

        if ((ret = DBA_SetHierLnkUsed(strategyHierHead,
                   ExtStratElt, ExtStratElt_Par_ExtStratElt_Ext)) != RET_SUCCEED)
        {
            MSG_SendMesg(RET_DBA_ERR_HIER, 0 , FILEINFO);
            return(ret);
        }

        if ((ret = DBA_SetHierLnkUsed(strategyHierHead,
                   A_StratHist, A_StratHist_A_StratElt_Ext)) != RET_SUCCEED)
        {
            MSG_SendMesg(RET_DBA_ERR_HIER, 0 , FILEINFO);
            return(ret);
        }

        /* PMSTA-28970 - CHU - 171227
        if ((ret = DBA_SetHierLnkUsed((DBA_HIER_HEAD_STP)strategyHierHead,
                   A_StratElt, A_StratElt_A_ScriptDef_Ext)) != RET_SUCCEED)
        {
            MSG_SendMesg(RET_DBA_ERR_HIER, 0 , FILEINFO);
            return(ret);
        }
        */

        /* PMSTA-28970 - CHU - 171227 */
        if ((ret = DBA_SetHierLnkUsed(strategyHierHead,
                   A_StratElt, A_StratElt_A_HoldConstrScript_Ext)) != RET_SUCCEED)
        {
            MSG_SendMesg(RET_DBA_ERR_HIER, 0 , FILEINFO);
            return(ret);
        }

        /* PMSTA-28970 - CHU - 171227 */
        if ((ret = DBA_SetHierLnkUsed(strategyHierHead,
                   A_StratElt, A_StratElt_A_TradConstrScript_Ext)) != RET_SUCCEED)
        {
            MSG_SendMesg(RET_DBA_ERR_HIER, 0 , FILEINFO);
            return(ret);
        }

        /* REF6082 - RAK - 010725 */
        if ((ret = DBA_SetHierLnkUsed(strategyHierHead,
                   A_DerivedStrat, A_DerivedStrat_A_DerivedStratElt_Ext)) != RET_SUCCEED)
        {
	        MSG_SendMesg(RET_DBA_ERR_HIER, 0 , FILEINFO);
            return(ret);
        }

        /* PMSTA-41153-Vishnu-150720*/
        if ((ret = FIN_SetAddDetailsinMC(domainPtr,
            strategyHierHead)) != RET_SUCCEED)
        {
            MSG_SendMesg(RET_DBA_ERR_HIER, 0, FILEINFO);
            return(ret);
        }

        if ((ret = FIN_CreateMCForHierConstr(domainPtr,
            strategyHierHead)) != RET_SUCCEED)
        {
            MSG_SendMesg(RET_DBA_ERR_HIER, 0, FILEINFO);
            return(ret);
        }

        /*PMSTA-48867-Satya*/
        if ((ret = DBA_SetHierLnkUsed((DBA_HIER_HEAD_STP)strategyHierHead,
            A_Ptf, A_Ptf_SubHierChildPtf_Ext)) != RET_SUCCEED)
        {
            MSG_SendMesg(RET_DBA_ERR_HIER, 0, FILEINFO);
            return(ret);
        }

        /* REF6082 - RAK - 010725 */
        if ((ret = DBA_SetHierLnkUsed(strategyHierHead,
                   A_ModelConstr, A_ModelConstr_A_ModelConstrElt_Ext)) != RET_SUCCEED)
        {
            MSG_SendMesg(RET_DBA_ERR_HIER, 0 , FILEINFO);
            return(ret);
        }

        /* PMSTA-41153-Vishnu-150720*/
        if ((ret = DBA_SetHierLnkUsed((DBA_HIER_HEAD_STP)strategyHierHead,
            A_ModelConstr, A_ModelConstr_ApplScopeModelConstrElt_Ext)) != RET_SUCCEED)
        {
            MSG_SendMesg(RET_DBA_ERR_HIER, 0, FILEINFO);
            return(ret);
        }

		/*PMSTA-48867-Satya*/
		if ((ret = DBA_SetHierLnkUsed((DBA_HIER_HEAD_STP)strategyHierHead,
			A_ModelConstr, A_ModelConstr_PostDerivCnstrElt_Ext)) != RET_SUCCEED)
		{
			MSG_SendMesg(RET_DBA_ERR_HIER, 0, FILEINFO);
			return(ret);
		}

        if (DBA_MakeLinks(strategyHierHead) != RET_SUCCEED)
        {
            MSG_SendMesg(RET_DBA_ERR_HIER, 0 , FILEINFO);
            return(ret);
        }

    return(RET_SUCCEED);
}

/************************************************************************
*
*   Function      : DBA_SelCheckStratDataInitStrat()
*
*   Description   : According to domain (A_Domain_ForceLnkFlg, Strat, Ptf), initialise #dom_strat
*
*   Arguments     : domainPtr           domain dynamic structure pointer
*                   ptfIdTab            array of portfolio(s) or NULL
*                   ptfIdNbr            nbr of portfolio(s) or 0
*                   connectNo           filled with connection which containt #dom_strat
*                   stratLnkDataPtr     filled with StratLnk array
*                   stratLnkRowsPtr     filled with StratLnk number
*
*   Return        : RET_SUCCEED or error code
*
*   Creation Date : REF7423 - RAK - 020404
*	Modifs		  :	REF11434 - CHU - 051007 : complete correct processing of ptfIdTab
*
*************************************************************************/
STATIC RET_CODE DBA_SelCheckStratDataInitStrat(DBA_DYNFLD_STP   domainPtr,
                                               ID_T             **ptfIdTab,
                                               int              *ptfIdNbr,
                                               int              *connectNo,
                                               DBA_DYNFLD_STP   **stratLnkDataPtr,
                                               int              *stratLnkRowsPtr)
{
    RET_CODE        ret=RET_SUCCEED;
    DBA_DYNFLD_STP  searchLnkSt=NULL;
    int             i=0, tmpStratLnkRows=0, ioIdNbr=0;
    DBA_DYNFLD_STP  *tmpStratLnkData=NULL;
    DBA_DYNFLD_STP  *ioIdTab=NULL;
    FLAG_T			continueProcess; /*SRU REF7993 020926*/
	DICT_T			listEntDictId; /* REF11434 - CHU - 051007 */
	FLAG_T			applUseLnkPrioritiesForAllocOrderFlag, UseLnkPrioritiesFlg=TRUE; /* PMSTA06103-CHU-080416 */
	FLAG_T			applStratActivateNoLinkError=TRUE;	/* PMSTA10000-CHU-100603 */
    MemoryPool      mp;

	DBA_GetDictId(List, &listEntDictId); /* REF11434 - CHU - 051007 */
    *stratLnkRowsPtr = 0;
    *stratLnkDataPtr = 0;

    if(SYS_IsStateShutdownRequested())
    {   /* PMSTA-54362 - JBC - 30112023 */
        return RET_SYS_ERR_SIGINT;
    }

	/* < PMSTA06103-CHU-080416 */
	GEN_GetApplInfo(ApplUseLnkPrioritiesForAllocOrder, &applUseLnkPrioritiesForAllocOrderFlag);
	if (GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_AllocateOrder &&
		(DOMORDERALLOCNAT_ENUM)GET_ENUM(domainPtr, A_Domain_OrderAllocNatEn) == DomOrderAllocNat_InstrResultStratSgt &&
		applUseLnkPrioritiesForAllocOrderFlag == FALSE)
	{
		UseLnkPrioritiesFlg = FALSE;
	}
	/* > PMSTA06103-CHU-080416 */

	GEN_GetApplInfo(ApplStratActivateNoLinkError, &applStratActivateNoLinkError); /* PMSTA10000-CHU-100603 */

	/* REF11250-CHU-050616 - force_link_f is ignored in Order Entry since ptfIdTab is not null...
    if (GET_FLAG(domainPtr, A_Domain_ForceLnkFlg) == FALSE || ptfIdTab != NULL)
	*/
	if (GET_FLAG(domainPtr, A_Domain_ForceLnkFlg) == FALSE)
    {
        /******************************************************/
        /***               FORCE LINK = 0 = FALSE           ***/
        /***    (use link between ptf(s) and strategy(ies)  ***/
        /******************************************************/

        /* Allocate a A_SearchLnk dynamic structure */
        searchLnkSt = mp.allocDynst(FILEINFO,A_SearchLnk);

        /* Fill Searchlink dynamic structure */
		/* Ptf Dimension */
		COPY_DYNFLD(searchLnkSt, A_SearchLnk, A_SearchLnk_DimPortDictId,
					domainPtr, A_Domain, A_Domain_DimPtfDictId);

		/* Ptf Obj Id */
		COPY_DYNFLD(searchLnkSt, A_SearchLnk, A_SearchLnk_PortObjId,
					domainPtr, A_Domain, A_Domain_PtfObjId);

        SET_NULL_DICT(searchLnkSt, A_SearchLnk_DimStratDictId);
        SET_NULL_ID(searchLnkSt,   A_SearchLnk_StratObjId);

        COPY_DYNFLD(searchLnkSt, A_SearchLnk, A_SearchLnk_LnkNatEn,
                    domainPtr, A_Domain, A_Domain_StratLnkNatEn);

        SET_FLAG(searchLnkSt, A_SearchLnk_AllHistFlg, FALSE);
        SET_FLAG(searchLnkSt, A_SearchLnk_CurrentFlg, TRUE);
        SET_FLAG(searchLnkSt, A_SearchLnk_PhysicalLnkFlg, FALSE);

        SET_ENUM(searchLnkSt, A_SearchLnk_ComplianceMethodEn, complianceMethodEn::Default);
        SET_FLAG(searchLnkSt, A_SearchLnk_DynamicSeverityFlg, FALSE);
        SET_FLAG(searchLnkSt, A_SearchLnk_LoadHierFlg, FALSE);
        SET_FLAG(searchLnkSt, A_SearchLnk_CaseDurationFlg, FALSE);

        COPY_DYNFLD(searchLnkSt, A_SearchLnk, A_SearchLnk_BeginDate,
                    domainPtr, A_Domain, A_Domain_InterpStratDate);

        SET_NULL_DATE(searchLnkSt, A_SearchLnk_EndDate);

        /* PMSTA10723 - DDV - 101119 - Copy data_profile_id in A_SearchLnk to handle security in proc */
		COPY_DYNFLD(searchLnkSt, A_SearchLnk, A_SearchLnk_DataProfId,
					domainPtr, A_Domain, A_Domain_DataProfId);

		if (UseLnkPrioritiesFlg == TRUE) /* PMSTA06103-CHU-080415 */
		{
			COPY_DYNFLD(searchLnkSt, A_SearchLnk, A_SearchLnk_MinLnkPriority,
						domainPtr, A_Domain, A_Domain_MinLnkPriority);
			COPY_DYNFLD(searchLnkSt, A_SearchLnk, A_SearchLnk_MaxLnkPriority,
						domainPtr, A_Domain, A_Domain_MaxLnkPriority);
		}

		/* PMSTA-12096 - RAK - 110526 */
		COPY_DYNFLD(searchLnkSt, A_SearchLnk, A_SearchLnk_OwnershipRuleEn,
					domainPtr, A_Domain, A_Domain_OwnershipRuleEn);
		COPY_DYNFLD(searchLnkSt, A_SearchLnk, A_SearchLnk_ThirdCompoEn,
					domainPtr, A_Domain, A_Domain_ThirdCompoEn);
		/* PMSTA-12639 - RAK - 110823 */
		COPY_DYNFLD(searchLnkSt, A_SearchLnk, A_SearchLnk_LoadHierFlg,
					domainPtr, A_Domain, A_Domain_LoadHierFlg);

        /*PMSTA-42402 Autocash Vishnu 23112020*/
		COPY_DYNFLD(searchLnkSt, A_SearchLnk, A_SearchLnk_ComplianceMethodEn,
					domainPtr, A_Domain, A_Domain_ComplianceMethodEn );

        /*if cashplan realignment then we need to load all strategy link*/
            SET_ENUM(searchLnkSt, A_SearchLnk_ComplianceMethodEn, complianceMethodEn::LoadAll);
        
        /* REF7420 - RAK - 020627 */
        /* New parameter to the proc sel_sh_strategy_link_by_id used */
        /* for test on link_nature which is different if received    */
        /* link_nature is a domain or a strategy link_nature         */
        SET_FLAG(searchLnkSt, A_SearchLnk_AdminFlg, FALSE);

        /* Initialize dom_port_strat and dom_strat tables according to     */
        /* portfolio and strategy dimensions and select S_StratLnk records */

        /* Now call to DBA_SelStratLnkById has been optimized. (DVP529 - 970701 - GRD). */

        /* REF2746 - SSO - 980902: TRICK: using short because ENUM_T is too small here */
        /* SET_ENUM(searchLnkSt, A_SearchLnk_StratLnkEn, ExtStratLnk); */
        /* REF2746 - SSO - 981124: EnumType->SmallintType for A_SearchLnk_StratLnk(En) */
        SET_SMALLINT(searchLnkSt, A_SearchLnk_StratLnk, (short)ExtStratLnk);

		/*
        if (*ptfIdNbr == 0) /-* REF2755 - SSO - 990215 *-/
        {
            ret = DBA_Select2(StratLnk,
                              DBA_ROLE_LOAD_STRAT_LNK,
                              A_SearchLnk,
                              searchLnkSt,
                              S_StratLnk,
                              &tmpStratLnkData,
                              UNUSED,
                              UNUSED,
                              &tmpStratLnkRows,
                              UNUSED,
                              UNUSED);
        }
        else
        {
		*/
			if (ptfIdNbr != NULL && *ptfIdNbr != 0)
			{
				/* REF11434 - CHU - 051007 */
				/* give ptf ids (force ptf dimension to list) */
				SET_DICT(searchLnkSt, A_SearchLnk_DimPortDictId, listEntDictId);
				SET_NULL_ID(searchLnkSt, A_SearchLnk_PortObjId); /* to avoid joins in sql requests */
				SET_FLAG(searchLnkSt, A_SearchLnk_LoadParentFlg, FALSE);
			}

            ret = DBA_SelStratLnkByIdWithPtfs(searchLnkSt,
                                              &tmpStratLnkData,
                                              &tmpStratLnkRows,
                                              UNUSED,
                                              UNUSED,
                                              UNUSED,
                                              ptfIdTab,
                                              ptfIdNbr,
                                              FALSE, /* REF7758 - DDV - 020919 */
											  domainPtr); /* PMSTA-12724-CHU-110907 */

        	mp.ownerDynStpTab(tmpStratLnkData,tmpStratLnkRows);

            /* OCS-47724 - CHU - 160217 */
            if (GET_ENUM(domainPtr, A_Domain_OutputTpEn) == TSLDimPort &&
                GET_ENUM(domainPtr, A_Domain_LoadHierFlg) == LoadHierPtf_Full &&
                (GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_CheckStrat ||
                 GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_ReconcStrat ||
                 GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_AllocateOrder))
            {
                if ((ret = FIN_KRA(nullptr, domainPtr, *ptfIdTab, *ptfIdNbr)) == RET_DBA_ERR_KRANOTFOUND)
                {
                    ret = RET_DBA_ERR_CONNOTFOUND;
                }
                return(ret);
            }
		/*
        }*/
        /*SRU REF7993 020926*/
        continueProcess =
           (FLAG_T)( ( ( (GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_AllocateOrder) ||
	                      (GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_OrderAllocation) ) &&
                       (GET_ENUM(domainPtr, A_Domain_CheckStratEn) == (ENUM_T)CheckStrat_None) ) ||
                     ( (GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_PreTradeCheckStrat) &&
                       ( (IS_NULLFLD(domainPtr, A_Domain_CheckTradingFlg) == FALSE ) &&
	                      (GET_FLAG(domainPtr, A_Domain_CheckTradingFlg) == TRUE ) ) )
						|| /* REF11387 - CHU - 051114 : continue loading for VPO */
						(GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_ViewDerivedStrategyObjectives)
						||
						( IS_NULLFLD(domainPtr, A_Domain_FctDictId) == FALSE &&					/* REF11686 - TEB - 060206 */
						  GET_DICT(domainPtr,   A_Domain_FctDictId) == DictFct_RpcEditConstr)	/* REF11686 - TEB - 060206 */
						);

        if (ret == RET_SUCCEED && tmpStratLnkRows > 0)
        {
            char copy;

            if (((*stratLnkDataPtr) = (DBA_DYNFLD_STP *)CALLOC(tmpStratLnkRows, sizeof(DBA_DYNFLD_STP))) == NULL) /* REF7264 - LJE - 020131 */
            {
                MSG_RETURN(RET_MEM_ERR_ALLOC);
            }

            TLS_Sort((char *) tmpStratLnkData, tmpStratLnkRows, sizeof(DBA_DYNFLD_STP),
                    (TLS_CMPFCT *)DBA_CmpSStratLnkPtfStrat, NULL, SortRtnTp_None); /* REF7264 - LJE - 020131 */

            for (i=0; i<tmpStratLnkRows; i++)
            {
                copy = TRUE;
                if (IS_NULLFLD(tmpStratLnkData[i], S_StratLnk_PtfId) == TRUE)
                {
                    copy = FALSE;
                }
                else
                {
                    if (i >= 1) /* copy first occurence */
                    {
                        if (GET_ID(tmpStratLnkData[i], S_StratLnk_PtfId) ==
                            GET_ID(tmpStratLnkData[i-1], S_StratLnk_PtfId) &&
                            GET_ID(tmpStratLnkData[i], S_StratLnk_StratId) ==
                            GET_ID(tmpStratLnkData[i-1], S_StratLnk_StratId))
                        {
                            copy = FALSE;
                        }
                    }
                    /* REF3314 - SSO - 990212: if allocate order or check strat, do not load recomm lists */
                    if ((GET_ENUM(tmpStratLnkData[i], S_StratLnk_StratNatEn) == StratNat_RecomList)
                        && ((GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_AllocateOrder)
                        || (GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_CheckStrat)
                        /* REF3371 - RAK - 991221 */
                        || (GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_PreTradeCheckStrat)))
                    {
                        copy = FALSE;
                    }
                }

                if (copy == TRUE)
                {
                    if (((*stratLnkDataPtr)[(*stratLnkRowsPtr)] = ALLOC_DYNST(S_StratLnk)) == NULL)
                    {
                        DBA_FreeDynStTab((*stratLnkDataPtr), (*stratLnkRowsPtr), S_StratLnk);
                        MSG_RETURN(RET_MEM_ERR_ALLOC);
                    }
                    COPY_DYNST((*stratLnkDataPtr)[(*stratLnkRowsPtr)], tmpStratLnkData[i], S_StratLnk);
                    ++(*stratLnkRowsPtr);
                }
            }
        }

        if ( (ret != RET_SUCCEED) || ( ( (*stratLnkRowsPtr) == 0) &&
           /*SRU REF7993 020926*/(!continueProcess) ) )
        {
			if (applStratActivateNoLinkError == TRUE) /* PMSTA10000-CHU-100603 : The ultimate parameter! */
			{
                MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "Strategy Link"); /* PMSTA-30076 - CHU - 180227 : useless message if system parameter = 0 */
				DBA_FreeDynStTab((*stratLnkDataPtr), (*stratLnkRowsPtr), S_StratLnk);
				/* REF4341 - SSO - 000320  return(ret); -> specific msg for gui */
				return(RET_FIN_ERR_NO_STRAT_LNK);
			}

        }

        /* Create an unique list of strategy id's */
        ret = DBA_SortUniqueStratId((*stratLnkDataPtr), (*stratLnkRowsPtr), &ioIdTab, &ioIdNbr);
        
		mp.owner(ioIdTab,ioIdNbr);
        
		if (ret != RET_SUCCEED)
        {
            MSG_SendMesg(RET_GEN_ERR_SORTSIZE, 0, FILEINFO);
            DBA_FreeDynStTab((*stratLnkDataPtr), (*stratLnkRowsPtr), S_StratLnk);
            return(ret);
        }

        /* Get a free connection in the connection list */
        if (((*connectNo) = DBA_GetConnection(SqlServer)) == DBA_CONN_NOT_FOUND)
        {
            DBA_FreeDynStTab((*stratLnkDataPtr), (*stratLnkRowsPtr), S_StratLnk);
            MSG_RETURN(RET_DBA_ERR_CONNOTFOUND);
        }

        /* Create temporary tables #dom_strat and #dom_port */
        if ((ret = DBA_CreateDomPortAndDomStratTables((*connectNo), TRUE)) != RET_SUCCEED)
        {
            DBA_FreeDynStTab((*stratLnkDataPtr), (*stratLnkRowsPtr), S_StratLnk);
            DBA_EndConnection((*connectNo));
            return(ret);
        }

        /* REF-6168 VST 010801 */
        /* Before calling DBA_Select2 below we need to fill #dom_port also */
		searchLnkSt = mp.allocDynst(FILEINFO,A_SearchLnk);

        COPY_DYNFLD(searchLnkSt, A_SearchLnk, A_SearchLnk_DimPortDictId,
                    domainPtr, A_Domain, A_Domain_DimPtfDictId);
        COPY_DYNFLD(searchLnkSt, A_SearchLnk, A_SearchLnk_PortObjId,
                    domainPtr, A_Domain, A_Domain_PtfObjId);
        COPY_DYNFLD(searchLnkSt, A_SearchLnk, A_SearchLnk_DimStratDictId,
                     domainPtr, A_Domain, A_Domain_DimStratDictId);
        COPY_DYNFLD(searchLnkSt, A_SearchLnk, A_SearchLnk_StratObjId,
                     domainPtr, A_Domain, A_Domain_StratObjId);
        COPY_DYNFLD(searchLnkSt, A_SearchLnk, A_SearchLnk_StratObjId,
                    domainPtr, A_Domain, A_Domain_StratObjId);
        COPY_DYNFLD(searchLnkSt, A_SearchLnk, A_SearchLnk_LoadHierFlg,
                     domainPtr, A_Domain, A_Domain_LoadHierFlg);
        SET_FLAG(searchLnkSt, A_SearchLnk_LoadParentFlg, FALSE);

/* #if 0 */ /* PMSTA16595-CHU-130826 Reactivate this part of code */
		/* REF8055-10009 - CHU - 040324 : Use dynamically built ptf list if "All Portfolios" */
		if (ptfIdNbr != NULL && (*ptfIdNbr != 0)												/* Reactivated */
			&&																					/* Reactivated */
			(GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_PreTradeCheckStrat &&			/* Reactivated */
			 IS_NULLFLD(domainPtr, A_Domain_PtfObjId) == TRUE)									/* Reactivated */
			||																					/* Reactivated */
			/* REF10857 - CHU - 050428 : also use this list for several Alloc Order natures */	/* Reactivated */
			(GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_AllocateOrder &&				/* Reactivated */
			 GET_ENUM(domainPtr,A_Domain_OrderAllocNatEn) == DomOrderAllocNat_PtfOrderQty ||	/* Reactivated */
			 GET_ENUM(domainPtr,A_Domain_OrderAllocNatEn) == DomOrderAllocNat_PtfResultQty)		/* Reactivated */
			||																					/* Reactivated */
			/* REF10857 - CHU - 050503 : also use this list for Order Entry... */				/* Reactivated */
			(GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_PreTradeCheckStrat &&			/* Reactivated */
			GET_DICT(domainPtr, A_Domain_InitialFctDictId) == DictFct_OrderEntry))				/* Reactivated */
		{																						/* Reactivated */
			/* REF11434 - CHU - 051007 */														/* Reactivated */
			/* give ptf ids (force ptf dimension to list) */									/* Reactivated */
			/* PMSTA16894-CHU-130905 : not for WUI/TSL */
			if (IS_NULLFLD(domainPtr, A_Domain_JobReference) == TRUE &&
                /* PMSTA - 41580 - sanand - 28082020
                For Portfolio builder, its possible to run PTCC with ZERO draft orders
                */
                ((DomSessionNat_PortfolioBuilder !=
                    static_cast<DOMSESSIONNAT_ENUM>(GET_ENUM(domainPtr, A_Domain_SessionNatureEn))) &&
				 (DomSessionNat_InvestmentProposal !=
					static_cast<DOMSESSIONNAT_ENUM>(GET_ENUM(domainPtr, A_Domain_SessionNatureEn))) && /* PMSTA-46855 - AAKASH - 02122021 */
                 (DomSessionNat_InvestmentProposalViaBuilder !=
                    static_cast<DOMSESSIONNAT_ENUM>(GET_ENUM(domainPtr, A_Domain_SessionNatureEn))) &&
				 (DomSessionNat_PortfolioBuilderSameStrategy !=
					static_cast<DOMSESSIONNAT_ENUM>(GET_ENUM(domainPtr, A_Domain_SessionNatureEn))) && 
				 (DomSessionNat_PortfolioBuilderSimpleHierarchy !=
					static_cast<DOMSESSIONNAT_ENUM>(GET_ENUM(domainPtr, A_Domain_SessionNatureEn))) && 
				 (DomSessionNat_PortfolioBuilderDetailedHierarchy !=
					static_cast<DOMSESSIONNAT_ENUM>(GET_ENUM(domainPtr, A_Domain_SessionNatureEn))) && 
				 (DomSessionNat_PortfolioBuilderHeteroclite !=
					static_cast<DOMSESSIONNAT_ENUM>(GET_ENUM(domainPtr, A_Domain_SessionNatureEn))) && 
				 (DomSessionNat_PortfolioBuilderOverlay !=
					static_cast<DOMSESSIONNAT_ENUM>(GET_ENUM(domainPtr, A_Domain_SessionNatureEn))))
                )
			{
				SET_DICT(searchLnkSt, A_SearchLnk_DimPortDictId, listEntDictId);						/* Reactivated */
				SET_NULL_ID(searchLnkSt, A_SearchLnk_PortObjId); /* to avoid joins in sql requests */	/* Reactivated */
				SET_FLAG(searchLnkSt, A_SearchLnk_LoadParentFlg, FALSE);								/* Reactivated */
			}

			/* Call init later
			ret = DBA_InitStratLnk(searchLnkSt, connectNo, ptfIdTab, ptfIdNbr, domainPtr);
			*/
		}
		/*
		else
		{	/-* Call init later
			ret = DBA_InitStratLnk(searchLnkSt, connectNo, (ID_T **)NULL, (int *)NULL, domainPtr);
		}
		*/
/*#endif*/
		ret = DBA_InitStratLnk(searchLnkSt, connectNo, ptfIdTab, ptfIdNbr, domainPtr);
        if (ret != RET_SUCCEED)
        {
            DBA_DelDomPortAndDomStratTables((*connectNo), TRUE);
            DBA_EndConnection((*connectNo));
            return(ret);
        }

        /* REF-6168 VST 010801*/
        /* Now, empty #dom_strat table and fill it as before. */

        DBA_SqlExec("delete from #dom_strat ", (*connectNo), DBA_SET_CONN);

        /* Insert strategy Id's from given strategie list into dom_strat */ /* REF5062 - SSO - 000824 ret test */
        if ((ret = SERV_InsDomTable("#dom_strat", ioIdTab, ioIdNbr, (*connectNo))) != RET_SUCCEED)
        {
            DBA_FreeDynStTab((*stratLnkDataPtr), (*stratLnkRowsPtr), S_StratLnk);
            DBA_EndConnection((*connectNo));
            return(ret);
        }

        /* Free allocated memory */
    }
    else
    {
        /******************************************************/
        /***               FORCE LINK = 1 = TRUE            ***/
        /***               (use strategy dimension)         ***/
        /******************************************************/

        /* Get a free connection in the connection list */
        if (((*connectNo) = DBA_GetConnection(SqlServer)) == DBA_CONN_NOT_FOUND)
        {
            MSG_RETURN(RET_DBA_ERR_CONNOTFOUND);
        }

        /* Create temporary tables #dom_strat and #dom_port */
        if ((ret = DBA_CreateDomPortAndDomStratTables((*connectNo), TRUE)) != RET_SUCCEED)
        {
            DBA_DelDomPortAndDomStratTables((*connectNo), TRUE);
            DBA_EndConnection((*connectNo));
            return(ret);
        }

        /* Initialize dom_strat according to domain strategy dimension */
        searchLnkSt = mp.allocDynst(FILEINFO,A_SearchLnk);

        COPY_DYNFLD(searchLnkSt, A_SearchLnk, A_SearchLnk_DimPortDictId,
                   domainPtr, A_Domain, A_Domain_DimPtfDictId);
        COPY_DYNFLD(searchLnkSt, A_SearchLnk, A_SearchLnk_PortObjId,
                    domainPtr, A_Domain, A_Domain_PtfObjId);
        COPY_DYNFLD(searchLnkSt, A_SearchLnk, A_SearchLnk_DimStratDictId,
                     domainPtr, A_Domain, A_Domain_DimStratDictId);
        COPY_DYNFLD(searchLnkSt, A_SearchLnk, A_SearchLnk_StratObjId,
                    domainPtr, A_Domain, A_Domain_StratObjId);
        COPY_DYNFLD(searchLnkSt, A_SearchLnk, A_SearchLnk_StratObjId,
                     domainPtr, A_Domain, A_Domain_StratObjId);
        COPY_DYNFLD(searchLnkSt, A_SearchLnk, A_SearchLnk_LoadHierFlg,
                     domainPtr, A_Domain, A_Domain_LoadHierFlg);
        SET_FLAG(searchLnkSt, A_SearchLnk_LoadParentFlg, FALSE);

		/* PMSTA-12529 - RAK - 110815  */
		COPY_DYNFLD(searchLnkSt, A_SearchLnk, A_SearchLnk_OwnershipRuleEn,
						domainPtr, A_Domain, A_Domain_OwnershipRuleEn);
		COPY_DYNFLD(searchLnkSt, A_SearchLnk, A_SearchLnk_ThirdCompoEn,
						domainPtr, A_Domain, A_Domain_ThirdCompoEn);
		/* PCC-15685 - RAK - 110823
		COPY_DYNFLD(searchLnkSt, A_SearchLnk, A_SearchLnk_LoadHierFlg, already done :) */

		/* REF8055-10009 - CHU - 040402 : Use dynamically built ptf list if "All Portfolios" */
		/* PMSTA04637-CHU-080215 : call fct with all paramenters
		if ((GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_PreTradeCheckStrat) &&
			(IS_NULLFLD(domainPtr, A_Domain_PtfObjId) == TRUE) && (*ptfIdNbr != 0))
		{ */
			/* REF11434 - CHU - 051007 */
			/* give ptf ids (force ptf dimension to list) */
			if (ptfIdNbr != NULL && (*ptfIdNbr != 0))
			{
				SET_DICT(searchLnkSt, A_SearchLnk_DimPortDictId, listEntDictId);
				SET_NULL_ID(searchLnkSt, A_SearchLnk_PortObjId); /* to avoid joins in sql requests */
				SET_FLAG(searchLnkSt, A_SearchLnk_LoadParentFlg, FALSE);
			}

			ret = DBA_InitStratLnk(searchLnkSt, connectNo, ptfIdTab, ptfIdNbr, domainPtr);
		/*
		}
		else
		{
			ret = DBA_InitStratLnk(searchLnkSt, connectNo, (ID_T **)NULL, (int *)NULL, domainPtr);
		}
		*/

        if (ret != RET_SUCCEED)
        {
            DBA_DelDomPortAndDomStratTables((*connectNo), TRUE);
            DBA_EndConnection((*connectNo));
            return(ret);
        }
    }

    return(RET_SUCCEED);    /* and connectNo is filled with connection which containt #dom_strat */
}

/* REF2639 - SSO - 980901 : double entry point */
RET_CODE DBA_SelStratLnkById(DBA_DYNFLD_STP       searchLnkSt,
                             DBA_DYNFLD_STP       **stratLnkData,
                             int                  *dataRows,
                             DbiConnectionHelper& dbiConnHelper)
{
    RET_CODE            ret;

    ret = DBA_SelStratLnkByIdWithPtfs(searchLnkSt, stratLnkData, dataRows,
                                      dbiConnHelper.getConnection()->getId(), dbiConnHelper.dbaGetOptions(), nullptr, NULL, 0, FALSE, NULL); /* no ptf ids */ /* REF7758 - DDV - 020919 */

    return(ret);
}

/************************************************************************
*
*   Function      : DBA_GetMktSegtGridIdFromMultiSelect()
*
*   Description   : Get gridId of a market segment, first verify in S_MktSegt received,
*                   and only if not found call database
*
*   Arguments     :
*
*   Return        : RET_SUCCEED or error code
*
*   Creation Date : REF7420 - RAK - 020626 - now verify in select market segment first !
*
*************************************************************************/
STATIC RET_CODE DBA_GetMktSegtGridIdFromMultiSelect(DBA_DYNFLD_STP *sMktSegtTab,
                                                    int            sMktSegtNbr,
                                                    ID_T           mktSegtId,
                                                    ID_T           *gridId)
{
    DBA_DYNFLD_STP  inputPtr=NULL, outputPtr=NULL;
    RET_CODE        ret=RET_SUCCEED;
    int             i;

    /* Search in selected S_MktSegt */
    for (i=0; i<sMktSegtNbr; i++)
    {
        if (GET_ID(sMktSegtTab[i], S_MktSegt_Id) == mktSegtId)
        {
            *gridId = GET_ID(sMktSegtTab[i], S_MktSegt_GridId);
            return(RET_SUCCEED);
        }
    }

    /* If not found in selected market segments, call database */

    /* Memory allocation of an Adm_Arg structure */
    if ((inputPtr = ALLOC_DYNST(S_MktSegt)) == NULL)
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "S_MktSegt");
        return(RET_MEM_ERR_ALLOC);
    }

    /* Memory allocation */
    if ((outputPtr = ALLOC_DYNST(A_MktSegt)) == NULL)
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "A_MktSegt");
        FREE_DYNST(inputPtr, S_MktSegt);
        return(RET_MEM_ERR_ALLOC);
    }

    SET_ID(inputPtr, S_MktSegt_Id, mktSegtId);

    ret = DBA_Get2(MktSegt, UNUSED,
                   S_MktSegt, inputPtr,
                   A_MktSegt, &outputPtr,
                   UNUSED, UNUSED, UNUSED);

    if (ret != RET_SUCCEED)
    {
        MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "Market_Segment");
        ret = RET_DBA_ERR_NODATA;
    }
    else
    {
        *gridId = GET_ID(outputPtr, A_MktSegt_GridId);
    }

    FREE_DYNST(inputPtr, S_MktSegt);
    FREE_DYNST(outputPtr, A_MktSegt);
    return(ret);
}

/************************************************************************
*   Function             : DBA_CreateDomPortAndDomStratTables()
*
*   Description          : Create temporary table dom_strat and if received
*              domPOrtStratFlg == TRUE dom_port_strat too.
*
*   Arguments            : connectNo : connection number
*
*   Return               : RET_SUCCEED or error code
*
*   Creation             : REF3729 - RAK - 990615
*   Last modif. :
*           REF5010 - SSO - 000828
*	  		REF6168 - RAK - VST - 011009
*           REF7395 - CSY - 020322: EXTERN now
*           REF7560 - 020716 - PMO : Order Managament Entity light project: database infrastructure
*************************************************************************/
RET_CODE    DBA_CreateDomPortAndDomStratTables(int connectNo, FLAG_T domPortStratFlg)
{
    int     retCode;

    if((retCode = DBA_CreateTempTables(&connectNo, DOM_STRAT)) != RET_SUCCEED)
    {
        return(retCode);
    }

    if (domPortStratFlg == TRUE)
    {
		if((retCode = DBA_CreateTempTables(&connectNo,
                                           DOM_POSITION_INSTR_PORT|TCT_VECTOR_ID|OBJ_ID)) != RET_SUCCEED)  /* REF9187 - LJE - 030604 */
        {
			return retCode;
        }
    }

    return(RET_SUCCEED);

}

/************************************************************************
*   Function             : DBA_DelDomPortAndDomStratTables()
*
*   Description          : Send a Delete table request.
*
*   Arguments            : connectNo  : a connection number in the connection
*                                       list
*              domPOrtStratFlg delete dom_port_strat too
*
*
*   Return               : RET_SUCCEED              : if ok
*                          RET_DBA_ERR_DBPROBLEM    : if conn/DB problem
*
*   Creation Date        : 25.09.95 - PEC
*   Last Modif           : 12.11.96 - PEC - Ref.: DVP249
*                          24.03.97 - PEC - Ref.: DVP400
*              		       REF3729 - RAK - 990615 - New arg domPortStratFlg
*   			           REF6168 - RAK - VST - 011009
*                          REF7395 - CSY - 020322:  now EXTERN
*                          REF7560 - 020716 - PMO : Order Managament Entity light project: database infrastructure
*************************************************************************/
RET_CODE DBA_DelDomPortAndDomStratTables(int connectNo, FLAG_T domPortStratFlg)
{
    /* PMSTA-18593 - LJE - 151103 */
    RET_CODE retCode = DBA_CreateTempTables(&connectNo, DOM_STRAT);

    if (domPortStratFlg == TRUE && RET_SUCCEED == retCode)
    {
		retCode = DBA_CreateTempTables(&connectNo, DOM_POSITION_INSTR_PORT|TCT_VECTOR_ID);    /* REF7560 - PMO */
    }

    return retCode;
}

/************************************************************************
*   Function             : DBA_InitDomStrat
*
*   Description          : Initialize dom_strat table according to strategy dimension :
*                          - if strat dimension is a constraint list,
*                            enumerate the list and fill dom_strat
*              - call procedure 'init_strategy_by_domain'
*
*   Arguments            : domainPtr    pointer on domain dynamic structure
*              connectNo    a connection number in the connection
*                                       list
*
*   Return               : RET_SUCCEED              if ok
*                          RET_GEN_ERR_INVARG       errors in arguments
*              RET_MEM_ERR_ALLOC        memory allocation error
*              RET_GEN_ERR_NOACTION     error in DBA_Notif
*              RET_DBA_ERR_READ_DATA    error in retrieving data
*
*   Creation Date        : 28.11.95 - DED
*
*   Modif.       	: REF855 - RAK - 971104
*            		: REF3729 - RAK - 990616
*   			: REF6168 - RAK - VST - 011009
*
*************************************************************************/
STATIC RET_CODE DBA_InitDomStrat(DBA_DYNFLD_STP dynStPtr, DBA_DYNST_ENUM dynStEn, DbiConnection &dbiConn)
{
    DBA_DYNFLD_STP  admArg=NULL, sList=NULL;
    OBJECT_ENUM     dimObject;
    LISTNAT_ENUM    nature;
    int             statusDomStrat=TRUE;

    /* Check arguments */
    if (dynStPtr == NULL ||
        (dynStEn != A_Domain && dynStEn != A_SearchLnk))      /* REF3729 */
    {
        MSG_RETURN(RET_GEN_ERR_INVARG);
    }

    /* Retrieve Strategy Dimension from DomainPtr */
    if (dynStEn == A_Domain)    /* REF3729 */
    {
        if (GET_DICT(dynStPtr, A_Domain_DimStratDictId) == 0)
           dimObject = NullEntity;
        else
           DBA_GetObjectEnum(GET_DICT(dynStPtr, A_Domain_DimStratDictId), &dimObject);
    }
    else
    {
        if (GET_DICT(dynStPtr, A_SearchLnk_DimStratDictId) == 0)
           dimObject = NullEntity;
        else
           DBA_GetObjectEnum(GET_DICT(dynStPtr, A_SearchLnk_DimStratDictId), &dimObject);
    }

    /* If strategy dimension is a list, check out if enumerated or constrainted */
    if (dimObject == List)
    {
        /* Allocate memory */
        if ((admArg = ALLOC_DYNST(Adm_Arg)) == NULL)
        {
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "Adm_Arg");
            return(RET_MEM_ERR_ALLOC);
        }
        if ((sList = ALLOC_DYNST(S_List)) == NULL)
        {
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "S_List");
            FREE_DYNST(admArg, Adm_Arg);
            return(RET_MEM_ERR_ALLOC);
        }

        /* Fill key with strategy Id */
        if (dynStEn == A_Domain)    /* REF3729 */
        {
            COPY_DYNFLD(admArg, Adm_Arg, Adm_Arg_Id, dynStPtr, A_Domain, A_Domain_StratObjId);
        }
        else
        {
            COPY_DYNFLD(admArg, Adm_Arg, Adm_Arg_Id, dynStPtr, A_SearchLnk, A_SearchLnk_StratObjId);
        }

        /* Get the LIST record */
        if (DBA_Get2(List, UNUSED, Adm_Arg, admArg, S_List,
                     &sList, UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
        {
            MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, "List", GET_ID(admArg, Adm_Arg_Id));
            FREE_DYNST(admArg, Adm_Arg);
            FREE_DYNST(sList, S_List);
            return(RET_DBA_ERR_NODATA);
        }

        /* If the Strat list is a constraint list */
        if ((nature = (LISTNAT_ENUM)GET_ENUM(sList, S_List_NatEn)) == ListNat_Constr ||
             nature == ListNat_Search || nature == ListNat_Hierarch)
        {
            DICT_T      entDictId;

            DBA_GetDictId(Strat, &entDictId);

            /* Insert strategy Id from the Constraint List into dom_strat */
            SERV_ListMgm(ListMgmFct_LoadStratLnk,
                         entDictId,
                         GET_ID(sList, S_List_Id),
                         NULL,
                         dbiConn,
                         nullptr);

            statusDomStrat = FALSE;
        }

        /* Free memory allocation */
        FREE_DYNST(admArg, Adm_Arg);
        FREE_DYNST(sList, S_List);
    }

    /* If dom_strat is still empty, call stored procedure */
    if (statusDomStrat == TRUE)
    {
        /* Send an Init request to fill dom_strat table */
        DbiConnectionHelper dbiConnHelper(&dbiConn);

        if (dynStEn == A_Domain)    /* REF3729 */
        {
            if (DBA_Notif(Strat, UNUSED, dynStEn, dynStPtr, dbiConnHelper) != RET_SUCCEED)
            {
                DBA_DelDomPortAndDomStratTables(dbiConn.getId(), TRUE);
                MSG_RETURN(RET_GEN_ERR_NOACTION);
            }
        }
        else
        {
            if (DBA_Notif(StratLnk, UNUSED, dynStEn, dynStPtr, dbiConnHelper) != RET_SUCCEED)
            {
                DBA_DelDomPortAndDomStratTables(dbiConn.getId(), TRUE);
                MSG_RETURN(RET_GEN_ERR_NOACTION);
            }
        }
    }
    return(RET_SUCCEED);
}


/************************************************************************
**  Function             : DBA_SelIPBenchStratHistoCompo()
**
**  Description          : For all strategies of nature Investment Profile,
**                         expand StratLnk with the historisation and the composition of the strategy.
**
**  Arguments            : stratLnkTab  : pointer on array to be filled with strategy links
**                         stratLnkNbr  : pointer on the number of strategy link returned
**
**  Return               : RET_SUCCEED              : if no problem was detected
**                         a RET_CODE               : if a message has been received
**
**  Creation Date        : REF9187 - LJE - 030613
**  Last Modification    :
*************************************************************************/
STATIC RET_CODE DBA_SelIPBenchStratHistoCompo(DBA_DYNFLD_STP   searchLnkSt,
                                               STRATNAT_ENUM    stratNatEn,
                                               DBA_DYNFLD_STP  **sStratLnkTab,
                                               int              *sStratLnkNbr)
{
    RET_CODE       ret = RET_SUCCEED;
    DBA_DYNFLD_STP *compoStratLnkTab=NULL;
    int            compoStratLnkNbr=0, i, j, k, sameStratNbr=0,
                   newStratLnkNbr=0, inputStratLnkNbr=*sStratLnkNbr;
    DICT_T         stratDictId, ptfDictId;
    DATE_T         gblFromDate, gblTillDate;
    FLAG_T         addNewStratLnkFlg; /* REF9187 - LJE - 030806 */

    DBA_GetDictId(Strat, &stratDictId);
    DBA_GetDictId(Ptf,   &ptfDictId);

    if (GET_FLAG(searchLnkSt, A_SearchLnk_AllHistFlg) == TRUE)
    {
        gblFromDate = SYB_BEGIN_DATE;
        gblTillDate = MAGIC_END_DATE;
    }
    else
    {
        if (IS_NULLFLD(searchLnkSt, A_SearchLnk_BeginDate) == TRUE)
        {
            gblFromDate = DATE_CurrentDate();
        }
        else
        {
            gblFromDate = GET_DATETIME(searchLnkSt, A_SearchLnk_BeginDate).date;
        }

        if (IS_NULLFLD(searchLnkSt, A_SearchLnk_EndDate) == TRUE)
        {
            gblTillDate = gblFromDate;
        }
        else
        {
            gblTillDate = GET_DATETIME(searchLnkSt, A_SearchLnk_EndDate).date;
        }
    }

    /* Sort all stratLnk by StratId */
    if ((*sStratLnkNbr) > 1)
        TLS_Sort((char *) (*sStratLnkTab), *sStratLnkNbr, sizeof(DBA_DYNFLD_STP),
			    (TLS_CMPFCT *) DBA_CmpSLStrat, NULL, SortRtnTp_None);

    for (i=0; i<inputStratLnkNbr; i++)
    {
        /* REF9187 - LJE - 030806 */
        if ((*sStratLnkTab)[i] == NULL)
            continue;

        /* REF9187 - LJE - 030829 */
        if (GET_DICT((*sStratLnkTab)[i], S_StratLnk_LnkObjDictId) != ptfDictId)
            continue;

        /* If nature is needed, select historisations and compositions, and create new links */
        if (GET_ENUM((*sStratLnkTab)[i], S_StratLnk_StratNatEn)   == stratNatEn &&
            GET_DICT((*sStratLnkTab)[i], S_StratLnk_ToEntDictId)  == stratDictId)
        {
            /* update S_StratLnk_LnkObjDictId and S_StratLnk_ObjId */
            SET_DICT((*sStratLnkTab)[i], S_StratLnk_LnkObjDictId, stratDictId);
            SET_ID((*sStratLnkTab)[i], S_StratLnk_ObjId, GET_ID((*sStratLnkTab)[i], S_StratLnk_ToObjId));

            if ((ret = DBA_SelStratHistoCompo(GET_ID((*sStratLnkTab)[i], S_StratLnk_ToObjId),
                                              gblFromDate,
                                              gblTillDate,
                                              (*sStratLnkTab)[i],
                                              &compoStratLnkTab,
                                              &compoStratLnkNbr)) != RET_SUCCEED)
            {
                return(ret);
            }

            /* count the number of links with the same strategy and same period */
            sameStratNbr=1;
            while (i+sameStratNbr < (*sStratLnkNbr) &&
                   CMP_DYNFLD((*sStratLnkTab)[i], (*sStratLnkTab)[i+sameStratNbr],
                              S_StratLnk_ToObjId, S_StratLnk_ToObjId, IdType) == 0 &&
                   CMP_DYNFLD((*sStratLnkTab)[i], (*sStratLnkTab)[i+sameStratNbr],
                              S_StratLnk_BegDate, S_StratLnk_BegDate, DateType) == 0 &&
                   CMP_DYNFLD((*sStratLnkTab)[i], (*sStratLnkTab)[i+sameStratNbr],
                              S_StratLnk_EndDate, S_StratLnk_EndDate, DateType) == 0)
            {
                sameStratNbr++;
            }

            newStratLnkNbr = sameStratNbr*compoStratLnkNbr;

            /* realloc array for new links */
            if (newStratLnkNbr > 0)
            {
                if (((*sStratLnkTab) = (DBA_DYNFLD_STP *) REALLOC((*sStratLnkTab), ((*sStratLnkNbr) + newStratLnkNbr)*sizeof(DBA_DYNFLD_STP))) == NULL)
                {
					DBA_FreeDynStTab(compoStratLnkTab, compoStratLnkNbr, S_StratLnk);	/* REF8712 - YST - 030807 */
                    DBA_FreeDynStTab((*sStratLnkTab),(*sStratLnkNbr), S_StratLnk);
                    MSG_RETURN(RET_MEM_ERR_ALLOC);
                }
            }

            addNewStratLnkFlg = FALSE; /* REF9187 - LJE - 030806 */

            for (j=0; j < compoStratLnkNbr; j++)
            {
                /* Move here */ /* REF10723 - LJE - 041027 */
                if (GET_ENUM(searchLnkSt, A_SearchLnk_LnkNatEn) != StratLnkNat_All &&
                    GET_ENUM(searchLnkSt, A_SearchLnk_LnkNatEn) != GET_ENUM(compoStratLnkTab[j], S_StratLnk_LnkNatEn) &&
                    /* REF9187 - LJE - 030806 */
                    GET_ENUM(compoStratLnkTab[j], S_StratLnk_LnkNatEn)   != StratLnkNat_All                          &&
                    GET_ENUM(compoStratLnkTab[j], S_StratLnk_StratNatEn) != StratNat_InvestProfile                   &&
                    GET_ENUM(compoStratLnkTab[j], S_StratLnk_StratNatEn) != StratNat_Benchmark )
                {
					/* PMSTA02752 - LJE - 080122 */
					if (((GET_ENUM(searchLnkSt, A_SearchLnk_LnkNatEn) == StratLnkNat_Strat  ||
						  GET_ENUM(searchLnkSt, A_SearchLnk_LnkNatEn) == StratLnkNat_Bench) &&
						  GET_ENUM(compoStratLnkTab[j], S_StratLnk_LnkNatEn) == StratLnkNat_StratBench) ||

						((GET_ENUM(compoStratLnkTab[j], S_StratLnk_LnkNatEn) == StratLnkNat_Strat  ||
						 GET_ENUM(compoStratLnkTab[j], S_StratLnk_LnkNatEn) == StratLnkNat_Bench) &&
						 GET_ENUM(searchLnkSt, A_SearchLnk_LnkNatEn) == StratLnkNat_StratBench))
					{
						// Ok
					}
					else
					{
						continue;
					}
                }

                if (IS_NULLFLD(searchLnkSt, A_SearchLnk_MinLnkPriority)    == FALSE &&
                    IS_NULLFLD(compoStratLnkTab[j], S_StratLnk_Priority) == FALSE &&
                    GET_TINYINT(searchLnkSt, A_SearchLnk_MinLnkPriority) >
                        GET_TINYINT(compoStratLnkTab[j], S_StratLnk_Priority))
                {
                    continue;
                }

                if (IS_NULLFLD(searchLnkSt, A_SearchLnk_MaxLnkPriority)    == FALSE &&
                    IS_NULLFLD(compoStratLnkTab[j], S_StratLnk_Priority) == FALSE &&
                    GET_TINYINT(searchLnkSt, A_SearchLnk_MaxLnkPriority) <
                        GET_TINYINT(compoStratLnkTab[j], S_StratLnk_Priority))
                {
                    continue;
                }

                for (k=0; k<sameStratNbr; k++)
                {
                    if (((*sStratLnkTab)[(*sStratLnkNbr)] = ALLOC_DYNST(S_StratLnk)) == NULL)
                    {
                        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "S_StratLnk");
                        return(RET_MEM_ERR_ALLOC);
                    }

                    COPY_DYNST((*sStratLnkTab)[(*sStratLnkNbr)], compoStratLnkTab[j], S_StratLnk);

                    SET_NULL_ID((*sStratLnkTab)[(*sStratLnkNbr)], S_StratLnk_Id);
                    SET_DICT((*sStratLnkTab)[(*sStratLnkNbr)], S_StratLnk_LnkObjDictId,  ptfDictId);
					SET_ID(  (*sStratLnkTab)[(*sStratLnkNbr)], S_StratLnk_ObjId,     GET_ID((*sStratLnkTab)[i+k], S_StratLnk_PtfId));
					SET_CODE((*sStratLnkTab)[(*sStratLnkNbr)], S_StratLnk_ObjCd,     GET_CODE((*sStratLnkTab)[i+k], S_StratLnk_PtfCd));
					SET_ID(  (*sStratLnkTab)[(*sStratLnkNbr)], S_StratLnk_PtfId,     GET_ID((*sStratLnkTab)[i+k], S_StratLnk_PtfId));
					SET_CODE((*sStratLnkTab)[(*sStratLnkNbr)], S_StratLnk_PtfCd,     GET_CODE((*sStratLnkTab)[i+k], S_StratLnk_PtfCd));
					SET_FLAG((*sStratLnkTab)[(*sStratLnkNbr)], S_StratLnk_DirectFlg, FALSE);
					SET_FLAG((*sStratLnkTab)[(*sStratLnkNbr)], S_StratLnk_EnumFlg,   FALSE);

                    SET_DICT((*sStratLnkTab)[(*sStratLnkNbr)], S_StratLnk_FromEntDictId, ptfDictId);
					SET_ID(  (*sStratLnkTab)[(*sStratLnkNbr)], S_StratLnk_FromObjId,     GET_ID((*sStratLnkTab)[i+k], S_StratLnk_PtfId));
					SET_CODE((*sStratLnkTab)[(*sStratLnkNbr)], S_StratLnk_FromObjCd,     GET_CODE((*sStratLnkTab)[i+k], S_StratLnk_PtfCd));

                    (*sStratLnkNbr)++;

                    addNewStratLnkFlg = TRUE; /* REF9187 - LJE - 030806 */
                }

            }

            /* REF9187 - LJE - 030806 : If no compo, remove Benchmark or InvestProfile */
            if (addNewStratLnkFlg == FALSE &&
                GET_ENUM(searchLnkSt, A_SearchLnk_LnkNatEn) != StratLnkNat_All)
            {
                for (k=0; k<sameStratNbr; k++)
                {
                    FREE_DYNST((*sStratLnkTab)[i+k], S_StratLnk);
                }
            }

            i += sameStratNbr-1; /* REF10723 - LJE - 041027 */

			DBA_FreeDynStTab(compoStratLnkTab, compoStratLnkNbr, S_StratLnk);	/* PMSTA14443 - DDV - 120709 - Purify */
        }
    }

    return(RET_SUCCEED);
}

/*************************************************************************************
*   Function             : DBA_SetStratLnkFromAStrat()
*
*   Description          : set strategy links values from strategy record
*
*   Arguments            :
*
*   Return               : RET_SUCCEED if ok
*
*   Creation Date        : PMSTA-21056 - CHU - 151026
*
*   Last Modif           :
*
**************************************************************************************/
STATIC RET_CODE DBA_SetStratLnkFromAStrat(DBA_DYNFLD_STP domainPtr, DBA_DYNFLD_STP sSLPtr, DBA_DYNFLD_STP aStratPtr, DBA_DYNFLD_STP ptfSt)
{
	RET_CODE	ret = RET_SUCCEED;
	DICT_T		ptfDictId, stratDictId;

	if (domainPtr == NULL || sSLPtr == NULL || aStratPtr == NULL || ptfSt == NULL)
	{
		ret = RET_GEN_ERR_INVARG;
	}
	else
	{
		DBA_GetDictId(Ptf,		&ptfDictId);
		DBA_GetDictId(Strat,	&stratDictId);

		SET_NULL_ID(		sSLPtr,				S_StratLnk_Id);
		COPY_DYNFLD(		sSLPtr, S_StratLnk,	S_StratLnk_StratId,			aStratPtr, A_Strat, A_Strat_Id);
		SET_DICT(			sSLPtr,				S_StratLnk_LnkObjDictId,	ptfDictId);
		COPY_DYNFLD(		sSLPtr, S_StratLnk,	S_StratLnk_ObjId,			ptfSt, A_Ptf, A_Ptf_Id);
		SET_ENUM(			sSLPtr,				S_StratLnk_LnkNatEn,		StratLnkNat_Strat);
		COPY_DYNFLD(		sSLPtr, S_StratLnk,	S_StratLnk_BegDate,			domainPtr, A_Domain, A_Domain_InterpStratDate);
		SET_NULL_DATETIME(	sSLPtr,				S_StratLnk_EndDate);		/* ?? I think not needed */
		COPY_DYNFLD(		sSLPtr, S_StratLnk,	S_StratLnk_Priority,		domainPtr, A_Domain, A_Domain_MinLnkPriority);
		COPY_DYNFLD(		sSLPtr, S_StratLnk,	S_StratLnk_DataSecuProfId,	aStratPtr, A_Strat, A_Strat_DataSecuProfId);
		SET_DICT(			sSLPtr,				S_StratLnk_FromEntDictId,	ptfDictId);
		SET_ID(				sSLPtr,				S_StratLnk_FromObjId,		GET_ID(ptfSt, A_Ptf_Id));
		SET_DICT(			sSLPtr,				S_StratLnk_ToEntDictId,		stratDictId);
		SET_ID(				sSLPtr,				S_StratLnk_ToObjId,			GET_ID(aStratPtr, A_Strat_Id));
	/*	{"parent_strategy_link_id"       , FALSE, &S_StratLnk_ParStratLnkId           , IdType            , TRUE },		*/
	/*	SET_SMALLINT(		sSLPtr,				S_StratLnk_Rank,			1); */ /* ?? I think not needed */
		SET_CODE(			sSLPtr,				S_StratLnk_StratCd,			GET_CODE(ptfSt, A_Strat_Cd));
		COPY_DYNFLD(		sSLPtr, S_StratLnk,	S_StratLnk_StratNatEn,		aStratPtr, A_Strat, A_Strat_NatEn);
		SET_CODE(			sSLPtr,				S_StratLnk_ObjCd,			GET_CODE(ptfSt, A_Ptf_Cd));
		SET_FLAG(			sSLPtr,				S_StratLnk_DirectFlg,		TRUE);
		SET_FLAG(			sSLPtr,				S_StratLnk_EnumFlg,			FALSE);
		COPY_DYNFLD(		sSLPtr, S_StratLnk,	S_StratLnk_PtfId,			ptfSt, A_Ptf, A_Ptf_Id);
		SET_CODE(			sSLPtr,				S_StratLnk_PtfCd,			GET_CODE(ptfSt, A_Ptf_Cd));
		SET_NULL_ID(		sSLPtr,				S_StratLnk_ListId);
	/*	{"_ListCd"                       ,  TRUE, &S_StratLnk_ListCd                  , CodeType          , FALSE},		*/
		COPY_DYNFLD(		sSLPtr, S_StratLnk,	S_StratLnk_ParStratId,		aStratPtr, A_Strat, A_Strat_ParentStratId);
		COPY_DYNFLD(		sSLPtr, S_StratLnk,	S_StratLnk_DimGridDictId,	aStratPtr, A_Strat, A_Strat_DimGridDictId);
		COPY_DYNFLD(		sSLPtr, S_StratLnk,	S_StratLnk_GridObjId,		aStratPtr, A_Strat, A_Strat_GridObjId);
	/*	{"_ParGridId"                    ,  TRUE, &S_StratLnk_ParGridId               , IdType            , FALSE},		*/
	/*	{"_MktSegId"                     ,  TRUE, &S_StratLnk_MktSegId                , IdType            , FALSE},		*/
	/*	{"_FromEntCd"                    , FALSE, &S_StratLnk_FromEntCd               , CodeType          , FALSE},		*/
		SET_CODE(			sSLPtr,				S_StratLnk_FromObjCd,		GET_CODE(ptfSt, A_Ptf_Cd));
	/*	{"_ToEntCd"                      , FALSE, &S_StratLnk_ToEntCd                 , CodeType          , FALSE},		*/
		SET_CODE(			sSLPtr,				S_StratLnk_ToObjCd,			GET_CODE(ptfSt, A_Strat_Cd));
		SET_FLAG(			sSLPtr, GET_FLD_AUTH_UPD(S_StratLnk),		TRUE);
		SET_FLAG(			sSLPtr, GET_FLD_AUTH_DEL(S_StratLnk),		TRUE);
		SET_ENUM(			sSLPtr,				S_StratLnk_CriticalnessEn,	GET_ENUM(aStratPtr, A_Strat_CriticalnessEn));
	}

	return (ret);
}

/*************************************************************************************
*   Function             : DBA_ResetStratLnkWithDomPtfCompo()
*
*   Description          : Select Domain Ptf Compo from function result and reset strategy links
*
*   Arguments            :
*
*   Return               : RET_SUCCEED if ok
*
*   Creation Date        : PMSTA-21056 - CHU - 151026
*
*   Last Modif           :
*
**************************************************************************************/
STATIC RET_CODE DBA_ResetStratLnkWithDomPtfCompo(DBA_DYNFLD_STP			domainPtr,
												 DBA_HIER_HEAD_STP		hierHead,
												 DBA_DYNFLD_STP			**stratLnkTab,
												 int					*stratLnkNbr,
												 int					*connectNo,
												 int					selOptions,
												 DBA_ERRMSG_INFOS_STP	msgStructPtr)
{
	RET_CODE		ret = RET_SUCCEED;
	DBA_DYNFLD_STP	*domPtfCompoTab = NULL, *localStratLnkTab = NULL;
	int				domPtfCompoNbr  = 0, localStratLnkNbr = 0;
	FLAG_T			foundFlg = FALSE;
	DBA_DYNFLD_STP	*addedRowsTab=NULL;
	int				addedRowsNbr=0, deletedRowsNbr=0;
    MemoryPool      mp;

	/* PMSTA-21056 - CHU - 151028 : eventually replace selected strategies with the ones from domain_portfolio_compo */
	if (domainPtr != NULL
		&&
		IS_NULLFLD(domainPtr, A_Domain_FctResultId) == FALSE
		&&
		(DOMSESSIONNAT_ENUM)GET_ENUM(domainPtr, A_Domain_SessionNatureEn) == DomSessionNat_InvestmentProposalClient
		 &&
		 (GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_ReconcStrat ||
		  GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_PreTradeCheckStrat))
	{
		
		int				domPtfCompoIdx = 0, stratLnkIdx = 0, i = 0;
		FLAG_T			allocPtfFlg = FALSE, allocStratFlg = FALSE;

		DBA_DYNFLD_STP getArg = mp.allocDynst(FILEINFO,Get_Arg);
		
		SET_ID(getArg, Get_Arg_Id, GET_ID(domainPtr, A_Domain_FctResultId));
		if((ret = DBA_Select2(DomainPtfCompo, DBA_ROLE_FCT_RESULT,
							  Get_Arg, getArg,
							  A_DomainPtfCompo,
							  &domPtfCompoTab,
							  selOptions, UNUSED,
							  &domPtfCompoNbr,
							  connectNo,
							  msgStructPtr)) == RET_SUCCEED)
		{
			for (domPtfCompoIdx = 0; domPtfCompoIdx < domPtfCompoNbr; domPtfCompoIdx++)
			{
				foundFlg = FALSE;

				if (IS_NULLFLD(domPtfCompoTab[domPtfCompoIdx], A_DomainPtfCompo_ForcedStratId) == FALSE &&
					CMP_ID(GET_ID(domPtfCompoTab[domPtfCompoIdx], A_DomainPtfCompo_ForcedStratId),
						   GET_ID(domPtfCompoTab[domPtfCompoIdx], A_DomainPtfCompo_DefaultStratId)) != 0 )
				{
                    DBA_DYNFLD_STP	aStratPtr = NULLDYNST, ptfSt=NULLDYNST;

					if (DBA_GetPtfById(GET_ID(domPtfCompoTab[domPtfCompoIdx], A_DomainPtfCompo_PtfId),
										FALSE, &allocPtfFlg, &ptfSt, hierHead, UNUSED, UNUSED) != RET_SUCCEED)
					{
						DBA_FreeDynStTab(domPtfCompoTab, domPtfCompoNbr, A_DomainPtfCompo);
						return(RET_GEN_ERR_INVARG);
					}
					/* load details about forced strategy */
					if (DBA_GetStratById(GET_ID(domPtfCompoTab[domPtfCompoIdx], A_DomainPtfCompo_ForcedStratId),
										 FALSE, &allocStratFlg, &aStratPtr, hierHead,
										 selOptions, connectNo) == RET_SUCCEED &&
										 aStratPtr != NULL)
					{
						/* look for existing strategy link attached to current portfolio */
						for (stratLnkIdx = 0; stratLnkIdx < *stratLnkNbr; stratLnkIdx++)
						{
							if ((*stratLnkTab)[stratLnkIdx] == NULL)
							{
								continue; /* OCS-47394 - CHU - 151201 : skip the record instead of exiting the loop */
							}

							if (CMP_ID(GET_ID(domPtfCompoTab[domPtfCompoIdx], A_DomainPtfCompo_PtfId),
										GET_ID((*stratLnkTab)[stratLnkIdx], S_StratLnk_PtfId)) == 0)
							{
								if (foundFlg == TRUE) /* another strategy link for same portfolio : remove it */
								{
									DBA_FreeDynSt((*stratLnkTab)[stratLnkIdx], S_StratLnk);
									(*stratLnkTab)[stratLnkIdx] = NULL;
									deletedRowsNbr++;
								}
								else
								{
									/* update existing strategy link for current portfolio... �crabouillage */
									if ((ret = DBA_SetStratLnkFromAStrat(domainPtr, (*stratLnkTab)[stratLnkIdx], aStratPtr, ptfSt)) != RET_SUCCEED)
									{
										DBA_FreeDynStTab(domPtfCompoTab, domPtfCompoNbr, A_DomainPtfCompo);
										if (addedRowsNbr > 0)
										{
											DBA_FreeDynStTab(addedRowsTab, S_StratLnk, addedRowsNbr);
										}
                                        if (allocPtfFlg == TRUE) { FREE_DYNST(ptfSt,A_Ptf) };                                        
                                        if (allocStratFlg == TRUE) { FREE_DYNST(aStratPtr,A_Strat) };
										return(RET_GEN_ERR_INVARG);
									}
									foundFlg = TRUE;
								}
							}
						}

						/* if strategy link not found for this portfolio : create a new one */
						if (foundFlg == FALSE)
						{
							if (addedRowsNbr == 0)
							{
								if ((addedRowsTab = (DBA_DYNFLD_STP*)CALLOC(1, sizeof(DBA_DYNFLD_STP))) == NULL)
								{
									MSG_RETURN(RET_MEM_ERR_ALLOC);
								}
							}
							else
							{
								if ((addedRowsTab = (DBA_DYNFLD_STP*)REALLOC(addedRowsTab, (addedRowsNbr + 1) * sizeof(DBA_DYNFLD_STP))) == NULL)
								{
									MSG_RETURN(RET_MEM_ERR_ALLOC);
								}
							}

							addedRowsTab[addedRowsNbr] = ALLOC_DYNST(S_StratLnk);

							/* update new strategy link for current portfolio */
							if ((ret = DBA_SetStratLnkFromAStrat(domainPtr, addedRowsTab[addedRowsNbr], aStratPtr, ptfSt)) != RET_SUCCEED)
							{
								DBA_FreeDynStTab(addedRowsTab, S_StratLnk, addedRowsNbr + 1);
							}
							else
								addedRowsNbr++;
						}
					}
					if (allocPtfFlg == TRUE) { FREE_DYNST(ptfSt,A_Ptf) };                                  
                    if (allocStratFlg == TRUE) { FREE_DYNST(aStratPtr,A_Strat) };
				}
			}

			DBA_FreeDynStTab(domPtfCompoTab, domPtfCompoNbr, A_DomainPtfCompo);

			if (deletedRowsNbr > 0 || addedRowsNbr > 0)
			{
				if ((localStratLnkTab = (DBA_DYNFLD_STP*)CALLOC((*stratLnkNbr) - deletedRowsNbr + addedRowsNbr, sizeof(DBA_DYNFLD_STP))) == NULL)
				{
					if (addedRowsNbr > 0)
					{
						DBA_FreeDynStTab(addedRowsTab, S_StratLnk, addedRowsNbr);
					}
					MSG_RETURN(RET_MEM_ERR_ALLOC);
				}
				for (i = 0; i < (*stratLnkNbr); i++)
				{
					if ((*stratLnkTab)[i] != NULL)
					{
						localStratLnkTab[localStratLnkNbr] = ALLOC_DYNST(S_StratLnk);
						COPY_DYNST(localStratLnkTab[localStratLnkNbr], (*stratLnkTab)[i], S_StratLnk);
						DBA_FreeDynSt((*stratLnkTab)[i], S_StratLnk);
						localStratLnkNbr++;
					}
				}
				for (i = 0; i < (addedRowsNbr); i++)
				{
					localStratLnkTab[localStratLnkNbr] = addedRowsTab[i];
					localStratLnkNbr++;
				}
				*stratLnkTab = localStratLnkTab;
				*stratLnkNbr = localStratLnkNbr;
				FREE(addedRowsTab);
			}
		}
	}

	return (ret);
}

/************************************************************************
*
*   Function        :   FIN_KRA() Kreate the Right Array (of portfolios)
*
*   Description     :   Load TSL portfolio dimension with session content
*                       or domain portfolio dimension
*
*   Arguments       :   domainPtr		:	pointer on  current domain
*                       ptfIdTab		:	pointer on ptf's id list
*						ptfIdNbr		:	pointer on ptf's id list number
*
*   Return          :   RET_SUCCEED	or error code
*
*   Creation date   :   OCS-38780-CHU-110802
*						RATTATOUILLE ma p'tite RATTATOUILLE suis bien content d'avoir cr�e une fonction � ton nom
*
*  Modification     :   OCS-47724 - CHU - moved from srvstra1
*
*************************************************************************/
RET_CODE FIN_KRA(DBA_HIER_HEAD_STP* hierHeadPtr,
                 DBA_DYNFLD_STP		domainPtr,
                 ID_T				*ptfIdTab,
                 int				ptfIdNbr)
{
    RET_CODE	ret = RET_SUCCEED;
    char		*buff = NULL;
    int			buffLen = 0, iPtf;
    char		sep;
    ID_T		*localPtfIdTab = NULL;
    int			localPtfIdNbr = 0;

    if (ptfIdNbr > 0)
    {
        localPtfIdNbr = ptfIdNbr;
        localPtfIdTab = (ID_T *)CALLOC(localPtfIdNbr, sizeof(ID_T));
        for (iPtf = 0; iPtf < localPtfIdNbr; iPtf++)
        {
            localPtfIdTab[iPtf] = ptfIdTab[iPtf];
        }
    }
    else
    {
        DBA_DYNFLD_STP	*ptfDynTab = NULL;
        int				ptfDynNbr = 0;
        MemoryPool      mp;

        if ((ret = DBA_SelPtfByDomain(domainPtr,
                                      &ptfDynTab,
                                      &ptfDynNbr,
                                      NULL)) == RET_SUCCEED
            && ptfDynNbr > 0)
        {
            mp.ownerDynStpTab(ptfDynTab,ptfDynNbr);
            /* PMSTA-16590 - CHU - 140505
            The above function is already filling #dom_port...
            So it will call the transfer to TSL by itself
            for other functions than: (OCS-44712 - CHU - 140516)
            CheckStrat, ReconcStrat and AllocateOrder
            */

            /* OCS-44712 - CHU - 140516 : regression, add some conditions...  */
            if (GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_CheckStrat ||
                GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_ReconcStrat ||
                GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_AllocateOrder)
            {
                return(ret);
            }
            else
            {
				/* PMSTA-23902 - CHU - 180112 : add check on absent ESE's for selective list of portfolios */
                bool isSelectivePTCCFlg = (GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_PreTradeCheckStrat &&
                                           IS_NULLFLD(domainPtr, A_Domain_FctResultId) == FALSE &&
                                           GET_ENUM(domainPtr, A_Domain_CompDataEn) == CompData_SelectiveReplOld);

                FLAG_T SelectiveReplOldESLFlg = TRUE;
				
                /* OCS-44712 - CHU - 140516 : Portfolios should be returned for some functions! */
                localPtfIdNbr = ptfDynNbr;
                localPtfIdTab = (ID_T *)CALLOC(localPtfIdNbr, sizeof(ID_T));
                for (iPtf = 0; iPtf < localPtfIdNbr; iPtf++)
                {
                    /* PMSTA-23902 - CHU - 180112 : add check on 'SelectiveReplOld' ESL (calculated_e = 99) for selective list of portfolios */
                    if (isSelectivePTCCFlg == true &&
                        DBA_IsReplOldESLByPtfId(GET_ID(ptfDynTab[iPtf], A_Ptf_Id), GET_ID(domainPtr, A_Domain_FctResultId), &SelectiveReplOldESLFlg, UNUSED, UNUSED) == RET_SUCCEED &&
                        SelectiveReplOldESLFlg == FALSE)
                    {
                        continue;
                    }
                    localPtfIdTab[iPtf] = GET_ID(ptfDynTab[iPtf], A_Ptf_Id);
                }
            }
        }
    }

    if (localPtfIdNbr > 0)
    {
        DbiConnectionHelper dbiConnHelper;

		if (dbiConnHelper.isValidAndInit() == false)
		{
			FREE(localPtfIdTab);
			MSG_RETURN(RET_DBA_ERR_KRANOTFOUND);
		}

		/* PMSTA-28234 - Hemanth - 180111 : Handling wrong portfolio being passed to TSL incase of multiple threads */
		/* PMSTA-29302 - CHU - 180112 */ /* Create temporary tables   */
		if ((ret = DBA_CreateTempTables(*dbiConnHelper.getConnection(),
			DOM_STRAT | GRID_VECTOR | STRAT_MARKET | DOM_PARENT_STRAT |
			TMP_STRAT_HIST | STRATEGY | DOM_POSITION_INSTR_PORT | TCT_VECTOR_ID)) != RET_SUCCEED)
		{
			FREE(localPtfIdTab);
			return(ret);
		}

		/* PMSTA-51847 - SRN - 31012023*/
		int MaxNoOfSqlInsert = 0, min_limit = 0,
			max_limit = (localPtfIdNbr >= MAX_NUMBER_EXP_IN_LIST) ? MAX_NUMBER_EXP_IN_LIST : localPtfIdNbr;	/* Maximum limit for portfolio. If localPtfIdNbr is greater, then maxlimit will be 999 else maxlimit is localPtfIdNbr. */
		MaxNoOfSqlInsert = localPtfIdNbr / MAX_NUMBER_EXP_IN_LIST;											/* Maximum number of iteration to execute a loop. */
		MaxNoOfSqlInsert = MaxNoOfSqlInsert + 1;															/* Default to iterate once, if the potrfolio count is less than 1000 or it exceeds 1000. */

		while (MaxNoOfSqlInsert > 0)
		{
			buff = (char *)CALLOC(1, 2048);

			/*  fill dom_port   */
			sprintf(buff, "insert into #dom_port (id,port_pos_set_id,hier_port_id,fusion_date_rule_e) select id, 0, null, 0 "
				"from portfolio_vw where id in (");

			buffLen = SYS_StrLen(buff);
			sep = ' ';

			buff = (char *)REALLOC(buff, (buffLen + localPtfIdNbr * (ID_T_LEN + 1) + 2) * sizeof(char));
			for (iPtf = min_limit; iPtf < max_limit; iPtf++)	/* changed the initial value of for loop to min_limit and end value to max_limit */
			{
				sprintf(buff + buffLen, "%c%*" szFormatId, sep, ID_T_LEN, localPtfIdTab[iPtf]);
				buffLen += ID_T_LEN + 1;
				sep = ',';
			}
			sprintf(buff + buffLen, ")");

			if (DBA_SqlExec(buff, *dbiConnHelper.getConnection()) != RET_SUCCEED)
			{
				FREE(buff);
				FREE(localPtfIdTab);
				return(RET_GEN_INFO_NOACTION);
			}

			/* PMSTA-51847 - SRN - 31012023*/
			MaxNoOfSqlInsert--;					/* Decrement this value to found next iteration. */
			if (MaxNoOfSqlInsert == 1)			/* If it was last iteration, */
			{
				min_limit = max_limit;		/* change the max limit to min. */
				max_limit = localPtfIdNbr;	/* ptfNbr to max. */
			}
			else
			{
				min_limit = max_limit;					/* If the MaxNoOfSqlInsert is greater than 1, change the max limit to min and */
				max_limit += MAX_NUMBER_EXP_IN_LIST;	/* max limit will be addition of 999, for every iteration. */
			}
		}

        /*  fill tsl_dom_port   */
        ret = DBA_TransferDomPortToTSL(hierHeadPtr, domainPtr, dbiConnHelper);
        FREE(buff);
    }

    FREE(localPtfIdTab);
    return(ret);
}

/*************************************************************************************
*   Function             : DBA_SelStratLnkByIdWithPtfs()
*
*   Description          : Select all strategy links according to ptf and strat dimension.
*
*                          - if ptf dimension is a constraint list,
*                            enumerate the list and fill dom_port
*
*                          - if strat dimension is a constraint list,
*                            enumerate the list and fill dom_strat
*
*   Arguments            : searchLnkSt : dyn. struct A_SearchLnk
*
*   Return               : RET_SUCCEED             : if ok
*                          RET_DBA_ERR_CONNOTFOUND : if no connection found
*                          RET_DBA_ERR_DBPROBLEM   : if conn/DB problem
*                          RET_GEN_ERR_INVARG      : if conn/DB problem
*                          RET_MEM_ERR_ALLOC       : if allocation failure
*
*   Creation Date        : 25.09.95
*   Last Modif           : 04.03.96 - PEC - Ref.: BUG002
*              28.03.96 - DED - DVP023
*              05.06.97 - RAK - DVP460
*              09.06.97 - RAK - BUG391
*              11.06.97 - RAK - BUG393
*                          01.07.97 - GRD - DVP529: Function call is optimized.
*              REF2639 - SSO - 980901
*              REF2755 - SSO - 990215
*              REF6153 - CSY - 010713
*              REF9187 - LJE - 030603 : Reengineering with use FIN_IsInList (check with CMS)
**************************************************************************************/
EXTERN RET_CODE DBA_SelStratLnkByIdWithPtfs(DBA_DYNFLD_STP          searchLnkSt,
                                            DBA_DYNFLD_STP        **stratLnkData,
                                            int                    *dataRows,
                                            int                     allocConn,
                                            int                     selOptionsParam,
                                            DBA_ERRMSG_INFOS_STP    msgStructPtr,
                                            ID_T                   **ptfIdTab,
                                            int                     *ptfIdNbr,
                                            FLAG_T                  initDoneFlg,
											DBA_DYNFLD_STP			domainPtr)
{
    int            i = 0, j = 0, k = 0, connectNo = NO_VALUE, addedRows = 0, deletedRows = 0;
    int            selOptions;
    RET_CODE       retCode, ret;
    DBA_DYNFLD_STP *addedRowsTab=NULL;
    int            addedRowsAlloc=0;                  /* REF11199 - LJE - 051205 */
    DICT_T         ptfDictId, stratDictId;
    FLAG_T         resultFlg, resultBeforeFlg, founded, expandFlg;
    OBJECT_ENUM    entObjectEnum;
    int            structIdx=0, rows[]={0,0,0,0,0};
    DBA_DYNFLD_STP *outputData[]={0,0,0,0,0};

    DBA_DYNFLD_STP *ptfsOutput=NULL;
    int            ptfsRows=0;

    DBA_DYNFLD_STP *localStratLnkData=NULL;
    DBA_DYNST_ENUM outputSt = NullDynSt;
    const DBA_DYNST_ENUM *outputStLst[] =  { &S_StratLnk, /* Direct StrategyLink of the portfolio */
                                             &S_StratLnk, /* All StrategyLink of all list */
                                             &A_List,     /* All the lists which have a StrategyLink */
                                             &A_ListCompo,/* All current (validityDate = NULL) ListCompo of Lists */
                                             &A_ListCompo /* All historical (validityDate <> NULL)  ListCompo of Lists */
                                           };

    DATETIME_T  dateHisto, endPeriodDate, gblEndDate, gblBegDate;
    DATETIME_T  *crystalDatesTab=NULL;
    int         crystalNbr=0, rank = 1;/* PMSTA49957 - VSW - 160822 *//* REF9264 - LJE - 030709 */
    char        endPeriodFlg=FALSE;
 	OBJECT_ENUM	dimObject=NullEntity;
    FLAG_T      gblEndDateFlg;               /* REF11199 - LJE - 051205 */

	OBJECT_ENUM		ptfDim;					/* PMSTA-12724-CHU-110907 */

	DBA_HIER_HEAD_STP hierHead = DBA_CreateHier(); /* REF10276 - LJE - 040527 */
    DICT_T         emptyDictId;
    DBA_GetDictId(Empty, &emptyDictId);

	DBA_GetObjectEnum(GET_DICT(searchLnkSt, A_SearchLnk_DimPortDictId), &dimObject);
    DBA_GetDictId(Ptf,   &ptfDictId);
    DBA_GetDictId(Strat, &stratDictId); /* REF9187 - LJE - 030806 */

    if (searchLnkSt == NULL || stratLnkData == NULL || dataRows == NULL)
    {
		DBA_FreeHier(hierHead); /* REF10276 - LJE - 040527 */
        return(RET_GEN_ERR_INVARG);
    }

    /* REF11199 - LJE - 051205 : Test dates */
    if (GET_FLAG(searchLnkSt,   A_SearchLnk_AllHistFlg) == FALSE &&
        GET_FLAG(searchLnkSt,   A_SearchLnk_CurrentFlg) == FALSE &&
        IS_NULLFLD(searchLnkSt, A_SearchLnk_BeginDate)  == FALSE   &&
        IS_NULLFLD(searchLnkSt, A_SearchLnk_EndDate)  == FALSE   &&
        CMP_DYNFLD(searchLnkSt, searchLnkSt, A_SearchLnk_BeginDate, A_SearchLnk_EndDate, DateType) > 0)
    {
		DBA_FreeHier(hierHead);
        return(RET_GEN_ERR_INVARG);
    }


    if (IS_NULLFLD(searchLnkSt, A_SearchLnk_StratLnk) == FALSE)
    {
        outputSt = (DBA_DYNST_ENUM) GET_SMALLINT(searchLnkSt, A_SearchLnk_StratLnk);
    }

    /* Initialize dom_port and dom_strat tables according to ptf and strat dimensions */
    /* REF7758 - DDV - 020919 do it only if not allready done */
    if (initDoneFlg == FALSE)
    {
        selOptions = DBA_SET_CONN | DBA_NO_CLOSE;
        if (IS_NULLFLD(searchLnkSt, A_SearchLnk_StratObjId) || 
            GET_DICT(searchLnkSt, A_SearchLnk_StratObjId) == 0)
        {
            SET_DICT(searchLnkSt, A_SearchLnk_StratObjId, emptyDictId); /* PMSTA-46575 - 211214 - DDV - Don't fill DOM_STRAT for all strategies */
        }
		if((retCode = DBA_InitStratLnk(searchLnkSt, &connectNo, ptfIdTab, ptfIdNbr, NULL)) != RET_SUCCEED)
		{
            if (GET_DICT(searchLnkSt, A_SearchLnk_StratObjId) == emptyDictId)
            {
                SET_NULL_DICT(searchLnkSt, A_SearchLnk_StratObjId); /* PMSTA-46575 - 211214 - DDV */
            }
			DBA_EndConnection(connectNo);
			DBA_FreeHier(hierHead); /* REF10276 - LJE - 040527 */
			return(retCode);
		}
    }
    else
    {
        /* connection (and selOptions) passed in parameter must be used for multiselect */
        connectNo = allocConn;
        selOptions = selOptionsParam;
    }
    DbiConnectionHelper dbiConnHelper(&connectNo);

    /*
        The fifth data block (A_Ptf) is not systematically provided, depending of portfolio dimension.
    */
    rows[2] = 0;

	/* PMSTA-12724-CHU-110907 */
	/* Achtung les mobylettes... avec la rustine, et on monte les tours !! */
	/* ensure loading of all portfolios which have a strategy link */
	if (domainPtr != NULL &&
		GET_DICT(domainPtr, A_Domain_InitialFctDictId) == (DICT_FCT_ENUM)DictFct_CheckStrat)
	{
		DBA_GetObjectEnum(GET_DICT(domainPtr, A_Domain_DimPtfDictId), &ptfDim);

		if (ptfDim == Third  &&
			GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None &&
			(PTFCONSRULE_ENUM) GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) == PtfConsRule_DetailedChildren)
		{
			char	   buffer[1024];
			strcpy(buffer, "update #dom_port set hier_port_id = NULL "); /* Ben ouais, froidement... */
			ret = DBA_SqlExec(buffer, connectNo, DBA_SET_CONN|DBA_NO_CLOSE);
		}
	}

    if ((retCode = DBA_CreateTempTables(&connectNo, TT_LIST_STRAT_LINK)) != RET_SUCCEED)
    {
        return(retCode);
    }
    /* Select strategy_link records (5 blocks) */
    if ((retCode = DBA_MultiSelect2(StratLnk,
                                    DBA_ROLE_LOAD_STRAT_LNK,
                                    A_SearchLnk,
                                    searchLnkSt,
                                    outputStLst,
                                    outputData,
                                    selOptions,
                                    UNUSED,
                                    rows,
                                    &connectNo,
                                    UNUSED)) != RET_SUCCEED)
    {
        if (initDoneFlg == FALSE)
        {
            if (GET_DICT(searchLnkSt, A_SearchLnk_StratObjId) == emptyDictId)
            {
                SET_NULL_DICT(searchLnkSt, A_SearchLnk_StratObjId); /* PMSTA-46575 - 211214 - DDV */
            }
            DBA_DelDomPortAndDomStratTables(connectNo, TRUE);
            DBA_EndConnection(connectNo);
			DBA_FreeHier(hierHead); /* REF10276 - LJE - 040527 */
            return(retCode);
        }
    }

    if (initDoneFlg == FALSE && GET_DICT(searchLnkSt, A_SearchLnk_StratObjId) == emptyDictId)
    {
        SET_NULL_DICT(searchLnkSt, A_SearchLnk_StratObjId); /* PMSTA-46575 - 211214 - DDV */
    }

    /* PMSTA-21056 - CHU - 151028 : eventually replace selected strategies with the ones from domain_portfolio_compo */
	DBA_ResetStratLnkWithDomPtfCompo(domainPtr, hierHead, &(outputData[0]), &(rows[0]), &connectNo, selOptions, msgStructPtr);

    /* Sort all List by Id */
    if ((rows[2]) > 1)
        TLS_Sort((char *) outputData[2], rows[2], sizeof(DBA_DYNFLD_STP),
			    (TLS_CMPFCT *) DBA_CmpListById, NULL, SortRtnTp_None);

    /* Sort all ListCompo by ListId, ObjectId */
    if ((rows[3]) > 1)
        TLS_Sort((char *) outputData[3], rows[3], sizeof(DBA_DYNFLD_STP),
			    (TLS_CMPFCT *) DBA_CmpListCompoByLidOidDt, NULL, SortRtnTp_None);

    if (IS_NULLFLD(searchLnkSt, A_SearchLnk_DimPortDictId) == TRUE)
    {
        /* Generate current list compo, if needed */
        for (i=0; i<rows[2]; i++)
        {
            for (;j<rows[3] && GET_ID(outputData[3][j], A_ListCompo_Id) != GET_ID(outputData[2][i], A_List_Id); j++);

            if (j==rows[3] || GET_ID(outputData[3][j], A_ListCompo_Id) != GET_ID(outputData[2][i], A_List_Id))
            {
                if (SERV_ListMgm(ListMgmFct_LoadPos,
                                 ptfDictId,
                                 GET_ID(outputData[2][i], A_List_Id),
                                 NULL,
                                 *dbiConnHelper.getConnection(),
                                 nullptr) == RET_SUCCEED)
                {
                    /* Copy #dom_port to #vector_id */
                    ret = DBA_Notif(Ptf,
                                    DBA_ROLE_LOAD_STRAT_LNK,
                                    NullDynSt,
                                    NULL,
                                    &connectNo,
                                    selOptions);
                }

            }
        }

    }

    /* Select portfolios */
    if ((retCode = DBA_Select2(Ptf,
                               DBA_ROLE_LOAD_STRAT_LNK,
                               NullDynSt,
                               NULL,
                               A_Ptf,
                               &ptfsOutput,
                               selOptions,
                               UNUSED,
                               &ptfsRows,
                               &connectNo,
                               UNUSED)) != RET_SUCCEED)
    {
        if (initDoneFlg == FALSE)
        {
            DBA_DelDomPortAndDomStratTables(connectNo, TRUE);
            DBA_EndConnection(connectNo);
			DBA_FreeHier(hierHead); /* REF10276 - LJE - 040527 */
            return(retCode);
        }
    }

    if (initDoneFlg == FALSE)
    {
        DBA_DelDomPortAndDomStratTables(connectNo, TRUE);
        DBA_EndConnection(connectNo);
        connectNo = NO_VALUE;
    }


    /* Sort all StrategyLink by ObjectLink, strategy_id and begin_d */
    if ((rows[1]) > 1)
        TLS_Sort((char *) outputData[1], rows[1], sizeof(DBA_DYNFLD_STP),
			    (TLS_CMPFCT *) DBA_CmpStratLinkByOidDt, NULL, SortRtnTp_None);

    /* Sort all ptf by Id */
    if ((ptfsRows) > 1)
        TLS_Sort((char *) ptfsOutput, ptfsRows, sizeof(DBA_DYNFLD_STP),
			    (TLS_CMPFCT *) DBA_CmpPtfById, NULL, SortRtnTp_None);

    /* Sort all ListCompo by ListId, ObjectId and ValidityDate */
    if ((rows[4]) > 1)
        TLS_Sort((char *) outputData[4], rows[4], sizeof(DBA_DYNFLD_STP),
			    (TLS_CMPFCT *) DBA_CmpListCompoByLidOidDt, NULL, SortRtnTp_None);


    /* Parameters used :
     *  - A_SearchLnk_AllHistFlg
     *  - A_SearchLnk_CurrentFlg
     *  - A_SearchLnk_PhysicalLnkFlg
     *  - A_SearchLnk_BeginDate
     *  - A_SearchLnk_EndDate
     */

    gblBegDate.date = SYB_BEGIN_DATE;
    gblBegDate.time = 0;

    gblEndDate.date = MAGIC_END_DATE;
    gblEndDate.time = 0;

    dateHisto  = gblBegDate;

    /* Get crystal date for period */
    if (GET_FLAG(searchLnkSt,   A_SearchLnk_AllHistFlg) == FALSE &&
        GET_FLAG(searchLnkSt,   A_SearchLnk_CurrentFlg) == FALSE &&
        IS_NULLFLD(searchLnkSt, A_SearchLnk_BeginDate)  == FALSE &&
        IS_NULLFLD(searchLnkSt, A_SearchLnk_EndDate)  == FALSE )
    {
        gblBegDate.date = GET_DATE(searchLnkSt, A_SearchLnk_BeginDate);
        gblEndDate.date = GET_DATE(searchLnkSt, A_SearchLnk_EndDate);

        DATE_CrystalDates(gblBegDate,
                          gblEndDate,
                          1,
                          FreqUnit_Month,
                          FALSE,
                          &crystalDatesTab,
		                  &crystalNbr,
                          &endPeriodFlg,
                          &endPeriodDate,
                          EndOf,
                          nullptr,
                          nullptr);

    }
    else if (IS_NULLFLD(searchLnkSt, A_SearchLnk_BeginDate)  == FALSE)
    {
        dateHisto.date  = GET_DATE(searchLnkSt, A_SearchLnk_BeginDate);
        crystalNbr = 2;
    }
    else
    {
        dateHisto.date = DATE_CurrentDate();
        dateHisto.time = 0;
        crystalNbr     = 2;
    }

    if (GET_FLAG(searchLnkSt,   A_SearchLnk_CurrentFlg) == TRUE)
    {
        gblBegDate      = dateHisto;
        gblEndDate      = dateHisto;

        SET_FLAG(searchLnkSt, A_SearchLnk_SinglePeriodFlg, FALSE); /* REF9187 - LJE - 030710 */
    }

    /* If the fourth data block (constraints lists) has rows */
    if (rows[1] > 0)
    {
        addedRowsAlloc = (ptfsRows * rows[1] * 2) + 1;
        addedRowsTab = (DBA_DYNFLD_STP *)CALLOC(addedRowsAlloc, sizeof(DBA_DYNFLD_STP));

        DBA_GetObjectEnum(ptfDictId, &entObjectEnum);
        resultFlg = FALSE;

		/* REF9107 - RAK/DDV - 030521 */
		if (GET_FLAG(searchLnkSt, A_SearchLnk_PhysicalLnkFlg) == FALSE &&
            ptfsRows > 0 )
		{
            LISTNAT_ENUM   listNatEnum;
            DICT_T         entDictId;
            FLAG_T         histListFlg;
            int            listPos, listCompoHisto=0, listCompoCurr=0, stratLnkPos=0, ptfPos=0;
            int            firstListAddedRows;
            DATETIME_T     tmpEndDate;
            DBA_DYNFLD_STP listSt=NULL, listCompoSt=NULL, stratLnkSt=NULL, ptfSt=NULL;

            /* For each List */
            for (listPos=0; listPos < rows[2]; listPos++)
            {
                tmpEndDate = gblEndDate;

                listSt = outputData[2][listPos];

                listNatEnum  = (LISTNAT_ENUM)GET_ENUM(listSt, A_List_NatEn);
	            entDictId    = GET_DICT(listSt, A_List_EntityDictId);
                histListFlg  = GET_FLAG(listSt, A_List_HistoricalListFlg);

                /* Find if exists ListCompo histo */
                for (;listCompoHisto<rows[4] &&
                      GET_ID(outputData[4][listCompoHisto], A_ListCompo_Id) < GET_ID(listSt, A_List_Id);
                      listCompoHisto++);

                /* Find if exists ListCompo current */
                for (;listCompoCurr<rows[3] &&
                      GET_ID(outputData[3][listCompoCurr], A_ListCompo_Id) < GET_ID(listSt, A_List_Id);
                      listCompoCurr++);

                /* Find StratLnk for this List */
                for (;stratLnkPos<rows[1] &&
                      GET_ID(outputData[1][stratLnkPos], S_StratLnk_ObjId) < GET_ID(listSt, A_List_Id);
                      stratLnkPos++);

                if (listCompoHisto<rows[4] &&
                    GET_ID(outputData[4][listCompoHisto], A_ListCompo_Id) == GET_ID(listSt, A_List_Id))
                {
                    ptfPos             = 0;
                    firstListAddedRows = addedRows;

                    gblEndDateFlg = TRUE; /* REF11199 - LJE - 051205 */

                    for (;listCompoHisto<rows[4] &&
                          GET_ID(outputData[4][listCompoHisto], A_ListCompo_Id) ==
                            GET_ID(listSt, A_List_Id); listCompoHisto++)
                    {
                        listCompoSt = outputData[4][listCompoHisto];

                        /* Ignore list compo over main period */
                        if (DATETIME_CMP(GET_DATETIME(listCompoSt, A_ListCompo_ValidDt), gblEndDate) > 0 ||
                            IS_NULLFLD(listCompoSt, A_ListCompo_ObjId) == TRUE)
                        {
                            tmpEndDate = GET_DATETIME(listCompoSt, A_ListCompo_ValidDt);

                            gblEndDateFlg = FALSE; /* REF11199 - LJE - 051205 */

                            continue;
                        }

                        if (GET_ID(ptfsOutput[ptfPos], A_Ptf_Id) != GET_ID(listCompoSt, A_ListCompo_ObjId))
                        {
                            /* Find Portfolio for this ListCompo */
                            for (ptfPos=0;ptfPos<ptfsRows &&
                                  GET_ID(ptfsOutput[ptfPos], A_Ptf_Id) < GET_ID(listCompoSt, A_ListCompo_ObjId);
                                  ptfPos++);
                        }

                        ptfSt = ptfsOutput[ptfPos];

                        /* For each ListCompo generate all StratLnk in period */
                        for (j=stratLnkPos;
                             j<rows[1] && GET_ID(outputData[1][j], S_StratLnk_ObjId) == GET_ID(listSt, A_List_Id);
                             j++)
                        {
                            stratLnkSt = outputData[1][j];

                            if (CMP_DYNFLD(stratLnkSt,
                                           listCompoSt,
                                           S_StratLnk_EndDate,
                                           A_ListCompo_ValidDt,
                                           DatetimeType) > 0 &&
                                DATETIME_CMP(GET_DATETIME(stratLnkSt, S_StratLnk_BegDate),tmpEndDate) <= 0)
                            {
                                /* REF11199 - LJE - 051205 : Avoid crash... */
                                if (addedRows >= addedRowsAlloc)
                                {
                                    addedRowsAlloc++;
                                    if ((addedRowsTab = (DBA_DYNFLD_STP*)REALLOC(addedRowsTab, addedRowsAlloc * sizeof(DBA_DYNFLD_STP))) == NULL)
                                    {
			                            DBA_FreeHier(hierHead);
                                        MSG_RETURN(RET_MEM_ERR_ALLOC);
                                    }
                                    addedRowsTab[addedRowsAlloc-1] = NULL;
                                }

  							    /* Add a row in addedRowsTab */
							    addedRowsTab[addedRows] = ALLOC_DYNST(S_StratLnk);

							    COPY_DYNST(addedRowsTab[addedRows], stratLnkSt, S_StratLnk);

							    SET_NULL_ID(addedRowsTab[addedRows], S_StratLnk_Id);
							    SET_DICT(   addedRowsTab[addedRows], S_StratLnk_LnkObjDictId,  ptfDictId);
							    SET_ID(     addedRowsTab[addedRows], S_StratLnk_ObjId,         GET_ID(ptfSt,    A_Ptf_Id));
							    SET_CODE(   addedRowsTab[addedRows], S_StratLnk_ObjCd,         GET_CODE(ptfSt,  A_Ptf_Cd));
							    SET_ID(     addedRowsTab[addedRows], S_StratLnk_PtfId,         GET_ID(ptfSt,    A_Ptf_Id));
							    SET_CODE(   addedRowsTab[addedRows], S_StratLnk_PtfCd,         GET_CODE(ptfSt,  A_Ptf_Cd));
							    SET_FLAG(   addedRowsTab[addedRows], S_StratLnk_DirectFlg,     FALSE);
							    SET_FLAG(   addedRowsTab[addedRows], S_StratLnk_EnumFlg,       FALSE);

                                /* REF9187 - LJE - 030618 */
                                SET_DICT(addedRowsTab[addedRows], S_StratLnk_FromEntDictId, ptfDictId);
                                SET_ID(addedRowsTab[addedRows],   S_StratLnk_FromObjId, GET_ID(ptfSt,    A_Ptf_Id));
                                SET_CODE(addedRowsTab[addedRows], S_StratLnk_FromObjCd, GET_CODE(ptfSt,  A_Ptf_Cd));

                                if (CMP_DYNFLD(stratLnkSt,
                                               listCompoSt,
                                               S_StratLnk_BegDate,
                                               A_ListCompo_ValidDt,
                                               DatetimeType) < 0)
                                {
                                    COPY_DYNFLD(addedRowsTab[addedRows],
                                                S_StratLnk,
                                                S_StratLnk_BegDate,
                                                listCompoSt,
                                                A_ListCompo,
                                                A_ListCompo_ValidDt);

                                }

                                /* REF11199 - LJE - 050524 */
                                if (GET_DATE(addedRowsTab[addedRows], S_StratLnk_EndDate) > tmpEndDate.date &&
                                    gblEndDateFlg == FALSE) /* REF11199 - LJE - 050524 */
                                {
                                    SET_DATE(addedRowsTab[addedRows], S_StratLnk_EndDate, tmpEndDate.date);
                                }

                                /* REF11199 - LJE - 050524 : Change find predececing algo */

                                /* Search preceding strategy link */
                                for (i=firstListAddedRows; i<addedRows; i++)
                                {
                                    if (addedRows > 0                                              &&
                                        GET_FLAG(addedRowsTab[i], S_StratLnk_DirectFlg) == FALSE   &&
                                        GET_ID(addedRowsTab[i], S_StratLnk_ObjId)  ==
                                               GET_ID(addedRowsTab[addedRows], S_StratLnk_ObjId)   &&
                                        GET_ID(addedRowsTab[i], S_StratLnk_StratId) ==
                                               GET_ID(addedRowsTab[addedRows], S_StratLnk_StratId) &&
                                        CMP_DYNFLD(addedRowsTab[i],
                                                   addedRowsTab[addedRows],
                                                   S_StratLnk_BegDate,
                                                   S_StratLnk_EndDate,
                                                   DatetimeType) == 0)
                                    {
                                        COPY_DYNFLD(addedRowsTab[i],
                                                    S_StratLnk,
                                                    S_StratLnk_BegDate,
                                                    addedRowsTab[addedRows],
                                                    S_StratLnk,
                                                    S_StratLnk_BegDate);
                                        break;
                                    }
                                }

                                /* REF11199 - LJE - 051205 */
                                if (i==addedRows &&
                                    (GET_DATE(addedRowsTab[addedRows], S_StratLnk_BegDate) != gblEndDate.date ||
                                     gblBegDate.date == gblEndDate.date))
                                {
    							    addedRows++;

                                    /* Add direct element */
                                    if (GET_FLAG(stratLnkSt, S_StratLnk_DirectFlg) == TRUE)
                                    {
                                        /* REF11199 - LJE - 051205 : Avoid crash... */
                                        if (addedRows >= addedRowsAlloc)
                                        {
                                            addedRowsAlloc++;
                                            if ((addedRowsTab = (DBA_DYNFLD_STP*)REALLOC(addedRowsTab, addedRowsAlloc * sizeof(DBA_DYNFLD_STP))) == NULL)
                                            {
			                                    DBA_FreeHier(hierHead);
                                                MSG_RETURN(RET_MEM_ERR_ALLOC);
                                            }
                                            addedRowsTab[addedRowsAlloc-1] = NULL;
                                        }

                                        addedRowsTab[addedRows] = ALLOC_DYNST(S_StratLnk);
    						            COPY_DYNST(addedRowsTab[addedRows], stratLnkSt, S_StratLnk);
                                        addedRows++;

                                        /* Put only one */
                                        SET_FLAG(stratLnkSt, S_StratLnk_DirectFlg, FALSE);
                                    }

                                }
                                else
                                {
                                    FREE_DYNST(addedRowsTab[addedRows], S_StratLnk);
                                }
                            }
                        }
                    }
                }
                else if (histListFlg == FALSE  &&
                         listCompoCurr<rows[3] &&
                         GET_ID(outputData[3][listCompoCurr], A_ListCompo_Id) == GET_ID(listSt, A_List_Id))
                {
                    /* Get current listCompo */

                    ptfPos=0;

                    for (;listCompoCurr<rows[3] && GET_ID(outputData[3][listCompoCurr], A_ListCompo_Id) == GET_ID(listSt, A_List_Id); listCompoCurr++)
                    {
                        listCompoSt = outputData[3][listCompoCurr];

						/* REF10276 - LJE - 040517 */
						if (IS_NULLFLD(listCompoSt, A_ListCompo_ObjId) == TRUE)
						{
							continue;
						}

                        /* Find if Portfolio for this ListCompo */
                        for (;ptfPos<ptfsRows &&
                              GET_ID(ptfsOutput[ptfPos], A_Ptf_Id) < GET_ID(listCompoSt, A_ListCompo_ObjId);
                              ptfPos++);

                        ptfSt = ptfsOutput[ptfPos];

                        /* For each ListCompo generate all StratLnk */
                        for (j=stratLnkPos;
                             j<rows[1] && GET_ID(outputData[1][j], S_StratLnk_ObjId) == GET_ID(listSt, A_List_Id);
                             j++)
                        {
                            stratLnkSt = outputData[1][j];

                            /* REF11199 - LJE - 051205 : Avoid crash... */
                            if (addedRows >= addedRowsAlloc)
                            {
                                addedRowsAlloc++;
                                if ((addedRowsTab = (DBA_DYNFLD_STP*)REALLOC(addedRowsTab, addedRowsAlloc * sizeof(DBA_DYNFLD_STP))) == NULL)
                                {
			                        DBA_FreeHier(hierHead);
                                    MSG_RETURN(RET_MEM_ERR_ALLOC);
                                }
                                addedRowsTab[addedRowsAlloc-1] = NULL;
                            }

  							/* Add a row in addedRowsTab */
							addedRowsTab[addedRows] = ALLOC_DYNST(S_StratLnk);

							COPY_DYNST(addedRowsTab[addedRows], stratLnkSt, S_StratLnk);

							SET_NULL_ID(addedRowsTab[addedRows], S_StratLnk_Id);
							SET_DICT(   addedRowsTab[addedRows], S_StratLnk_LnkObjDictId,  ptfDictId);
							SET_ID(     addedRowsTab[addedRows], S_StratLnk_ObjId,         GET_ID(ptfSt,    A_Ptf_Id));
							SET_CODE(   addedRowsTab[addedRows], S_StratLnk_ObjCd,         GET_CODE(ptfSt,  A_Ptf_Cd));
							SET_ID(     addedRowsTab[addedRows], S_StratLnk_PtfId,         GET_ID(ptfSt,    A_Ptf_Id));
							SET_CODE(   addedRowsTab[addedRows], S_StratLnk_PtfCd,         GET_CODE(ptfSt,  A_Ptf_Cd));
							SET_FLAG(   addedRowsTab[addedRows], S_StratLnk_DirectFlg,     FALSE);
							SET_FLAG(   addedRowsTab[addedRows], S_StratLnk_EnumFlg,       FALSE);

                            /* REF9187 - LJE - 030618 */
							SET_DICT(   addedRowsTab[addedRows], S_StratLnk_FromEntDictId,  ptfDictId);
							SET_ID(     addedRowsTab[addedRows], S_StratLnk_FromObjId,      GET_ID(ptfSt,    A_Ptf_Id));
							SET_CODE(   addedRowsTab[addedRows], S_StratLnk_FromObjCd,      GET_CODE(ptfSt,  A_Ptf_Cd));

                            addedRows++;

                            /* Add direct element */
                            if (GET_FLAG(stratLnkSt, S_StratLnk_DirectFlg) == TRUE)
                            {
                                /* REF11199 - LJE - 051205 : Avoid crash... */
                                if (addedRows >= addedRowsAlloc)
                                {
                                    addedRowsAlloc++;
                                    if ((addedRowsTab = (DBA_DYNFLD_STP*)REALLOC(addedRowsTab, addedRowsAlloc * sizeof(DBA_DYNFLD_STP))) == NULL)
                                    {
			                            DBA_FreeHier(hierHead);
                                        MSG_RETURN(RET_MEM_ERR_ALLOC);
                                    }
                                    addedRowsTab[addedRowsAlloc-1] = NULL;
                                }

                                addedRowsTab[addedRows] = ALLOC_DYNST(S_StratLnk);
    						    COPY_DYNST(addedRowsTab[addedRows], stratLnkSt, S_StratLnk);
                                addedRows++;

                                /* Put only one */
                                SET_FLAG(stratLnkSt, S_StratLnk_DirectFlg, FALSE);
                            }

                        }

                    }
                }
				/* REF10270 - RAK - 040505 */
                else if (GET_ENUM(listSt, A_List_NatEn) != ListNat_Hierarch &&
					     GET_ENUM(listSt, A_List_NatEn) != ListNat_Enum &&
						 GET_ENUM(listSt, A_List_NatEn) != ListNat_Query)
                {
					/* For each portfolio */
					for (i=0 ; i<ptfsRows ; i++)
					{
                        ptfSt = ptfsOutput[i];

                        /* For each ListCompo generate all StratLnk */
                        for (j=stratLnkPos;
                             j<rows[1] && GET_ID(outputData[1][j], S_StratLnk_ObjId) == GET_ID(listSt, A_List_Id);
                             j++)
                        {
                            resultBeforeFlg = FALSE;

                            stratLnkSt = outputData[1][j];

                            for (k=0; k<crystalNbr; k++) /* REF11199 - LJE - 051205 */
                            {
                                if (crystalDatesTab!=NULL)
                                {
                                    dateHisto = crystalDatesTab[k];
                                }
                                else if (GET_FLAG(searchLnkSt,   A_SearchLnk_AllHistFlg) == TRUE)
                                {
                                    dateHisto = GET_DATETIME(stratLnkSt, S_StratLnk_BegDate);
                                }

                                /* Don't process if crystal date is over period of strategy link */
                                if (DATE_Cmp(dateHisto.date, GET_DATE(stratLnkSt, S_StratLnk_BegDate)) < 0 ||
                                    DATE_Cmp(dateHisto.date, GET_DATE(stratLnkSt, S_StratLnk_EndDate)) > 0 )
                                {
                                    continue;
                                }

                                FIN_IsInList(hierHead, /* REF10276 - LJE - 040527 */
                                             GET_ID(ptfSt, A_Ptf_Id),
                                             ptfSt,
                                             entObjectEnum,
                                             GET_ID(stratLnkSt, S_StratLnk_ListId),
                                             &listSt,
                                             &connectNo,
                                             histListFlg,
                                             &dateHisto,
                                             &resultFlg);

						        /* If portfolio i belong to ptf list j */
						        if (resultFlg == TRUE && resultBeforeFlg == FALSE &&
                                    (k<crystalNbr-1 || crystalNbr==1))  /* REF11199 - LJE - 051205 */
						        {
							        founded = TRUE;

                                    /* REF11199 - LJE - 051205 : Move before strat lnk ptf insert */
                                    /* Add direct element */
                                    if (GET_FLAG(stratLnkSt, S_StratLnk_DirectFlg) == TRUE &&
                                        (dimObject != List || /* list */
                                         GET_ID(searchLnkSt, A_SearchLnk_PortObjId) != GET_ID(stratLnkSt, S_StratLnk_ListId)))
                                    {
                                        /* REF11199 - LJE - 051205 : Avoid crash... */
                                        if (addedRows >= addedRowsAlloc)
                                        {
                                            addedRowsAlloc++;
                                            if ((addedRowsTab = (DBA_DYNFLD_STP*)REALLOC(addedRowsTab, addedRowsAlloc * sizeof(DBA_DYNFLD_STP))) == NULL)
                                            {
			                                    DBA_FreeHier(hierHead);
                                                MSG_RETURN(RET_MEM_ERR_ALLOC);
                                            }
                                            addedRowsTab[addedRowsAlloc-1] = NULL;
                                        }

                                        addedRowsTab[addedRows] = ALLOC_DYNST(S_StratLnk);
    						            COPY_DYNST(addedRowsTab[addedRows], stratLnkSt, S_StratLnk);
                                        addedRows++;

                                        /* Put only one */
                                        SET_FLAG(stratLnkSt, S_StratLnk_DirectFlg, FALSE);
                                    }

                                    /* REF11199 - LJE - 051205 : Avoid crash... */
                                    if (addedRows >= addedRowsAlloc)
                                    {
                                        addedRowsAlloc++;
                                        if ((addedRowsTab = (DBA_DYNFLD_STP*)REALLOC(addedRowsTab, addedRowsAlloc * sizeof(DBA_DYNFLD_STP))) == NULL)
                                        {
			                                DBA_FreeHier(hierHead);
                                            MSG_RETURN(RET_MEM_ERR_ALLOC);
                                        }
                                        addedRowsTab[addedRowsAlloc-1] = NULL;
                                    }

  							        /* Add a row in addedRowsTab */
							        addedRowsTab[addedRows] = ALLOC_DYNST(S_StratLnk);

							        COPY_DYNST(addedRowsTab[addedRows], stratLnkSt, S_StratLnk);

							        SET_NULL_ID(addedRowsTab[addedRows], S_StratLnk_Id);
							        SET_DICT(   addedRowsTab[addedRows], S_StratLnk_LnkObjDictId,  ptfDictId);
							        SET_ID(     addedRowsTab[addedRows], S_StratLnk_ObjId,         GET_ID(ptfSt,    A_Ptf_Id));
							        SET_CODE(   addedRowsTab[addedRows], S_StratLnk_ObjCd,         GET_CODE(ptfSt,  A_Ptf_Cd));
							        SET_ID(     addedRowsTab[addedRows], S_StratLnk_PtfId,         GET_ID(ptfSt,    A_Ptf_Id));
							        SET_CODE(   addedRowsTab[addedRows], S_StratLnk_PtfCd,         GET_CODE(ptfSt,  A_Ptf_Cd));
							        SET_FLAG(   addedRowsTab[addedRows], S_StratLnk_DirectFlg,     FALSE);
							        SET_FLAG(   addedRowsTab[addedRows], S_StratLnk_EnumFlg,       FALSE);

							        SET_DICT(   addedRowsTab[addedRows], S_StratLnk_FromEntDictId, ptfDictId);
							        SET_ID(     addedRowsTab[addedRows], S_StratLnk_FromObjId,     GET_ID(ptfSt,    A_Ptf_Id));
							        SET_CODE(   addedRowsTab[addedRows], S_StratLnk_FromObjCd,     GET_CODE(ptfSt,  A_Ptf_Cd));

                                    if (crystalDatesTab!=NULL)
                                    {
                                        SET_DATETIME(addedRowsTab[addedRows], S_StratLnk_BegDate, dateHisto);
                                    }

							        addedRows++;

						        }
                                else if (resultFlg == FALSE && resultBeforeFlg == TRUE)
                                {
                                    SET_DATE(addedRowsTab[addedRows-1], S_StratLnk_EndDate, dateHisto.date);

                                }

                                resultBeforeFlg = resultFlg;

                                /* For the not historized lists, it is not necessary
                                   to make the treatment for each month */
                                if (histListFlg == FALSE)
                                {
                                    break;
                                }
                            }
					    }
                    }
                }
            }
        }
    }
	FREE(crystalDatesTab); /* REF8712 - YST - 030807 */

    if (IS_NULLFLD(searchLnkSt, A_SearchLnk_DimPortDictId) == FALSE)
    {
        /* REF9107 - RAK/DDV - Keep domain list */
        /* For each Strategy Link */
        for (j=0 ; j<rows[1] ; j++)
        {
		    if (dimObject != List || /* list */
                GET_ID(searchLnkSt, A_SearchLnk_PortObjId) != GET_ID(outputData[1][j], S_StratLnk_ListId))
		    {
                /* If no porfolio belong to ptf list j, suppress list j */
                deletedRows++;
                FREE_DYNST(outputData[1][j], S_StratLnk);
                outputData[1][j] = NULL;
            }
	    }
    }

    *dataRows = rows[0] + rows[1] - deletedRows + addedRows;

    if (*dataRows > 0)
    {
        localStratLnkData = (DBA_DYNFLD_STP *)CALLOC(*dataRows, sizeof(DBA_DYNFLD_STP)); /* REF7264 - LJE - 020131 */
    }

    structIdx = 0;

    /* Delete records with portfolio_id NULL */

    for (i=0 ; i<rows[0] ; i++)
    {
        if (outputSt == ExtStratLnk && IS_NULLFLD(outputData[0][i], S_StratLnk_PtfId) == TRUE)
        {
            --(*dataRows);
            FREE_DYNST(outputData[0][i], S_StratLnk);
            continue;
        }

        localStratLnkData[structIdx] = outputData[0][i];
        structIdx++;
    }

    for (i=0 ; i<rows[1] ; i++)
    {
        if (outputData[1][i] == NULL)
            continue;

        if (outputSt == ExtStratLnk)
        {
            --(*dataRows);
            FREE_DYNST(outputData[1][i], S_StratLnk);
            continue;
        }

        localStratLnkData[structIdx] = outputData[1][i];
        structIdx++;
    }

    for (i=0 ; i<addedRows ; i++)
    {
        if (outputSt == ExtStratLnk && IS_NULLFLD(addedRowsTab[i], S_StratLnk_PtfId) == TRUE)
        {
            --(*dataRows);
            FREE_DYNST(addedRowsTab[i], S_StratLnk);
            continue;
        }

        localStratLnkData[structIdx] = addedRowsTab[i];
        structIdx++;
    }

    FREE(outputData[0]);
    FREE(outputData[1]);

    DBA_FreeDynStTab(outputData[2], rows[2], A_List);
    DBA_FreeDynStTab(outputData[3], rows[3], A_ListCompo);
    DBA_FreeDynStTab(outputData[4], rows[4], A_ListCompo);

    for (i=0 ; i<ptfsRows ; i++)
    {
        FREE_DYNST(ptfsOutput[i], A_Ptf);
    }

    if (ptfsOutput)
    {
        FREE(ptfsOutput);
    }

    if (addedRowsTab != NULL)
    {
        FREE(addedRowsTab);
    }

    *stratLnkData = localStratLnkData;

	/* PMSTA-8785 - RAK - 100105 */
	/* mix between REF9187, PMSTA-8573, PMSTA-8723, ... */
	/* In case of expansion is performed here, we can filter IP on his priority and link nature     */
	/* For productivity function (no expansion), we must keep IP for the FIN_CreateESLIPBenchmark() */
	/* decomposition and the FIN_CreateESLStratCompoDetail() filter on priority/link nature         */
	expandFlg = FALSE;
    /* REF9187 - LJE - 030613 : Two call for expand Benchmark in IP  */
    if (GET_ENUM(searchLnkSt, A_SearchLnk_ExpandStratEn) == ExpandStrat_IP   ||
        GET_ENUM(searchLnkSt, A_SearchLnk_ExpandStratEn) == ExpandStrat_IPBench )
    {
        DBA_SelIPBenchStratHistoCompo(searchLnkSt, StratNat_InvestProfile, stratLnkData, dataRows);
		expandFlg = TRUE;
    }

    if (GET_ENUM(searchLnkSt, A_SearchLnk_ExpandStratEn) == ExpandStrat_Bench   ||
        GET_ENUM(searchLnkSt, A_SearchLnk_ExpandStratEn) == ExpandStrat_IPBench )
    {
        DBA_SelIPBenchStratHistoCompo(searchLnkSt, StratNat_Benchmark, stratLnkData, dataRows);
		expandFlg = TRUE;
    }

	/* PMSTA02752 - LJE - 080122 */
    /* REF9187 - LJE - 030806 : Remove the BENCH not having good strategy_link_nature */
    for (i=0; i<(*dataRows); i++)
    {
        if ((*stratLnkData)[i] != NULL)
        {
			/* PMSTA-8785 - RAK - 100105 */
			/* Keep IP for the decomposition. Priority/link of StratCompo will be filtered by FIN_CreateESLStratCompoDetail() */
			if (domainPtr != NULL && /* PMSTA-17752 - CHU - 140709 : called by a keyword */
				expandFlg == FALSE &&
				(STRATNAT_ENUM)GET_ENUM((*stratLnkData)[i], S_StratLnk_StratNatEn) == StratNat_InvestProfile)
				continue;

            /* REF9187 - LJE - 040206 : Remove bad priority too */
            if (IS_NULLFLD(searchLnkSt, A_SearchLnk_MinLnkPriority)   == FALSE &&
                IS_NULLFLD((*stratLnkData)[i], S_StratLnk_Priority) == FALSE &&
                GET_TINYINT(searchLnkSt, A_SearchLnk_MinLnkPriority) >
					GET_TINYINT((*stratLnkData)[i], S_StratLnk_Priority))
            {
                FREE_DYNST((*stratLnkData)[i], S_StratLnk);
				continue;
            }

            if (IS_NULLFLD(searchLnkSt, A_SearchLnk_MaxLnkPriority)   == FALSE &&
                IS_NULLFLD((*stratLnkData)[i], S_StratLnk_Priority) == FALSE &&
                GET_TINYINT(searchLnkSt, A_SearchLnk_MaxLnkPriority) <
                    GET_TINYINT((*stratLnkData)[i], S_StratLnk_Priority))
            {
                FREE_DYNST((*stratLnkData)[i], S_StratLnk);
				continue;
            }

			/* PMSTA08776 - RAK - 091019 - Use DomStratLnkNat enum for searchLnkSt */
			if ((GET_ENUM(searchLnkSt, A_SearchLnk_LnkNatEn) == DomStratLnkNat_Strat  ||
			     GET_ENUM(searchLnkSt, A_SearchLnk_LnkNatEn) == DomStratLnkNat_Bench) &&
				 GET_ENUM((*stratLnkData)[i], S_StratLnk_LnkNatEn) == StratLnkNat_StratBench)
			{
				continue;
			}

			/* PMSTA08776 - RAK - 091019 - Use DomStratLnkNat enum for searchLnkSt */
			if ((GET_ENUM((*stratLnkData)[i], S_StratLnk_LnkNatEn) == StratLnkNat_Strat  ||
			     GET_ENUM((*stratLnkData)[i], S_StratLnk_LnkNatEn) == StratLnkNat_Bench) &&
				 GET_ENUM(searchLnkSt, A_SearchLnk_LnkNatEn) == DomStratLnkNat_StratBench)
			{
				continue;
			}

            /* PMSTA08776 - RAK - 091019 - Use test performed in stored proc,       */
			/* in case of specific link in domain, strategies link must be the same */
			/* with an exception for 4 (ConstrOnly) and 5 (ConstrStrat)             */
			/* OLD :
			if (GET_ENUM(searchLnkSt, A_SearchLnk_LnkNatEn)            != StratLnkNat_All        &&
				GET_ENUM((*stratLnkData)[i], S_StratLnk_LnkNatEn)     != StratLnkNat_All        &&
                GET_ENUM(searchLnkSt, A_SearchLnk_LnkNatEn) != GET_ENUM((*stratLnkData)[i], S_StratLnk_LnkNatEn))
            {
                FREE_DYNST((*stratLnkData)[i], S_StratLnk);
				continue;
            }
			*/

			/* PMSTA08776 - RAK - 091019 - Don't verify strategy link nature in case of all link is specified in domain */
			if (GET_ENUM(searchLnkSt, A_SearchLnk_LnkNatEn) == DomStratLnkNat_All)
				continue;
			/* PMSTA08776 - RAK - 091019 - Only constraint */
			if (GET_ENUM(searchLnkSt, A_SearchLnk_LnkNatEn) == DomStratLnkNat_ConstrOnly)
			{
				if (GET_ENUM((*stratLnkData)[i], S_StratLnk_LnkNatEn) != StratLnkNat_Constr)
				{ FREE_DYNST((*stratLnkData)[i], S_StratLnk);}

				continue;
			}
            /* PMSTA08776 - RAK - 091019 - Only constraint and strategies */
            if (GET_ENUM(searchLnkSt, A_SearchLnk_LnkNatEn) == DomStratLnkNat_ConstrStrat)
            {
                if (GET_ENUM((*stratLnkData)[i], S_StratLnk_LnkNatEn) != StratLnkNat_Strat &&
                    GET_ENUM((*stratLnkData)[i], S_StratLnk_LnkNatEn) != StratLnkNat_CheckOnly &&
                    GET_ENUM((*stratLnkData)[i], S_StratLnk_LnkNatEn) != StratLnkNat_Constr)
				{ FREE_DYNST((*stratLnkData)[i], S_StratLnk); }

				continue;
            }

			/* PMSTA08620 - RAK - 091019 - for other case DomStratLnkNat value == StratLnkNat value */
			if (GET_ENUM(searchLnkSt, A_SearchLnk_LnkNatEn) != StratLnkNat_All &&
				GET_ENUM((*stratLnkData)[i], S_StratLnk_LnkNatEn) != StratLnkNat_All &&
				GET_ENUM(searchLnkSt, A_SearchLnk_LnkNatEn) != GET_ENUM((*stratLnkData)[i], S_StratLnk_LnkNatEn))
			{
				FREE_DYNST((*stratLnkData)[i], S_StratLnk);
				continue;
			}
        }
    }

    /* REF9187 - LJE - 030806 : reorg table */
    for (i=0, j=0; i < (*dataRows); i++)
    {
        if ((*stratLnkData)[i] == NULL)
            continue;

        if (j!=i)
        {
            (*stratLnkData)[j] = (*stratLnkData)[i];
        }
        j++;
    }

    (*dataRows) = j;

    /* Get "from" and "to" dict entity name */
    for (i=0; i < (*dataRows); i++)
    {
        OBJECT_ENUM objEn;

        if (IS_NULLFLD((*stratLnkData)[i], S_StratLnk_FromEntDictId) == FALSE &&
            DBA_GetObjectEnum(GET_DICT((*stratLnkData)[i], S_StratLnk_FromEntDictId), &objEn)  == TRUE &&
            DBA_GetDictEntitySt(objEn) != NULL)
        {
            SET_CODE((*stratLnkData)[i], S_StratLnk_FromEntCd, DBA_GetDictEntitySt(objEn)->nameStr.c_str());
        }

        if (IS_NULLFLD((*stratLnkData)[i], S_StratLnk_ToEntDictId) == FALSE &&
            DBA_GetObjectEnum(GET_DICT((*stratLnkData)[i], S_StratLnk_ToEntDictId), &objEn)  == TRUE &&
            DBA_GetDictEntitySt(objEn) != NULL)
        {
            SET_CODE((*stratLnkData)[i], S_StratLnk_ToEntCd, DBA_GetDictEntitySt(objEn)->nameStr.c_str());
        }

    }


    /* Generate single period */
    if ((*dataRows) > 1 &&
        GET_FLAG(searchLnkSt,   A_SearchLnk_CurrentFlg)    == FALSE &&
        GET_FLAG(searchLnkSt,   A_SearchLnk_AllHistFlg)    == FALSE &&
        GET_FLAG(searchLnkSt, A_SearchLnk_SinglePeriodFlg) == TRUE)
    {
        int    datesNbr=0;
        DATE_T prevBegDate=0, prevEndDate=0;
        DATE_T *crystalDates=NULL;
        int    ptfFirst=-1;
        ID_T   currPtfId=0;

        /* REF9770 - LJE - 040116 : Manage dates by portfolio */


        TLS_Sort((char *) (*stratLnkData), (*dataRows), sizeof(DBA_DYNFLD_STP),
                 (TLS_CMPFCT *)DBA_CmpStratLinkByPtfDts, NULL, SortRtnTp_None);

        for (i=0; i < (*dataRows); i++)
        {
            if (IS_NULLFLD((*stratLnkData)[i], S_StratLnk_PtfId) == FALSE)
            {
                if (currPtfId == 0)
                {
                    ptfFirst  = i;
                    currPtfId = GET_ID((*stratLnkData)[i], S_StratLnk_PtfId);
                }

                if (i != 0 &&
                    GET_ID((*stratLnkData)[i], S_StratLnk_PtfId) != currPtfId)
                {
                    TLS_Sort((char *) crystalDates, datesNbr, sizeof(DATE_T),
			                (TLS_CMPFCT *) DBA_CmpDate, NULL, SortRtnTp_None);

                    addedRows = 0;

                    for (k=ptfFirst; k < i; k++)
                    {
                        if (IS_NULLFLD((*stratLnkData)[k], S_StratLnk_PtfId) == FALSE)
                        {
                            /* Split current strategy_link */
                            for (j=0; j<datesNbr &&
                                      DATE_Cmp(crystalDates[j], GET_DATE((*stratLnkData)[k], S_StratLnk_BegDate)) < 0; j++);

                            j++;

                            for (;j<datesNbr &&
                                  DATE_Cmp(crystalDates[j], GET_DATE((*stratLnkData)[k], S_StratLnk_EndDate)) < 0; j++)
                            {
                                if (j == 0 ||
                                    crystalDates[j] != crystalDates[j-1])
                                {
                                    /* Alloc and copy new element */
                                    addedRows++;
                                    (*stratLnkData) = (DBA_DYNFLD_STP*)REALLOC((*stratLnkData),
                                                                               ((*dataRows)+addedRows)*sizeof(DBA_DYNFLD_STP));
                                    (*stratLnkData)[(*dataRows)+addedRows-1] = ALLOC_DYNST(S_StratLnk);
                                    COPY_DYNST((*stratLnkData)[(*dataRows)+addedRows-1], (*stratLnkData)[k], S_StratLnk);

                                    /* Modify dates, for multi-periods, the new one is on begin period */
                                    SET_DATE((*stratLnkData)[k], S_StratLnk_BegDate, crystalDates[j]);
                                    SET_DATE((*stratLnkData)[(*dataRows)+addedRows-1], S_StratLnk_EndDate, crystalDates[j]);
                                }

                            }
                        }
                    }

                    (*dataRows) += addedRows;
		            FREE(crystalDates); /* REF8712 - YST - 030807 */

                    datesNbr    = 0;
                    prevBegDate = 0;
                    prevEndDate = 0;

                    /* REF10236 - LJE - 040611 */
                    ptfFirst    = i;
                    currPtfId   = GET_ID((*stratLnkData)[i], S_StratLnk_PtfId);
                }

                if (DATE_Cmp(GET_DATE((*stratLnkData)[i], S_StratLnk_BegDate), gblBegDate.date) < 0)
                {
                    SET_DATE((*stratLnkData)[i], S_StratLnk_BegDate, gblBegDate.date);
                }

                if (GET_DATE((*stratLnkData)[i], S_StratLnk_BegDate) != prevBegDate &&
                    DATE_Cmp(GET_DATE((*stratLnkData)[i], S_StratLnk_BegDate), gblBegDate.date) >= 0)
                {
                    datesNbr++;
                    crystalDates = (DATE_T*)REALLOC(crystalDates, datesNbr * sizeof(DATE_T));

                    crystalDates[datesNbr-1] = GET_DATE((*stratLnkData)[i], S_StratLnk_BegDate);

                    prevBegDate = crystalDates[datesNbr-1]; /* REF9187 - LJE - 030829 */
                }

                if (DATE_Cmp(GET_DATE((*stratLnkData)[i], S_StratLnk_EndDate), gblEndDate.date) > 0)
                {
                    SET_DATE((*stratLnkData)[i], S_StratLnk_EndDate, gblEndDate.date);
                }

                if (GET_DATE((*stratLnkData)[i], S_StratLnk_EndDate) != prevEndDate &&
                    DATE_Cmp(GET_DATE((*stratLnkData)[i], S_StratLnk_EndDate), gblEndDate.date) <= 0)
                {
                    datesNbr++;
                    crystalDates = (DATE_T*)REALLOC(crystalDates, datesNbr * sizeof(DATE_T));

                    crystalDates[datesNbr-1] = GET_DATE((*stratLnkData)[i], S_StratLnk_EndDate);

                    prevEndDate = crystalDates[datesNbr-1]; /* REF9187 - LJE - 030829 */
                }

            }
        }

        TLS_Sort((char *) crystalDates, datesNbr, sizeof(DATE_T),
			    (TLS_CMPFCT *) DBA_CmpDate, NULL, SortRtnTp_None);

        addedRows = 0;

        for (i=ptfFirst; i < (*dataRows); i++)
        {
            if (IS_NULLFLD((*stratLnkData)[i], S_StratLnk_PtfId) == FALSE)
            {
                /* Split current strategy_link */
                for (j=0; j<datesNbr &&
                          DATE_Cmp(crystalDates[j], GET_DATE((*stratLnkData)[i], S_StratLnk_BegDate)) < 0; j++);

                j++;

                for (;j<datesNbr &&
                      DATE_Cmp(crystalDates[j], GET_DATE((*stratLnkData)[i], S_StratLnk_EndDate)) < 0; j++)
                {
                    if (j == 0 ||
                        crystalDates[j] != crystalDates[j-1])
                    {
                        /* Alloc and copy new element */
                        addedRows++;
                        (*stratLnkData) = (DBA_DYNFLD_STP*)REALLOC((*stratLnkData),
                                                                   ((*dataRows)+addedRows)*sizeof(DBA_DYNFLD_STP));
                        (*stratLnkData)[(*dataRows)+addedRows-1] = ALLOC_DYNST(S_StratLnk);
                        COPY_DYNST((*stratLnkData)[(*dataRows)+addedRows-1], (*stratLnkData)[i], S_StratLnk);

                        /* Modify dates, for multi-periods, the new one is on begin period */
                        SET_DATE((*stratLnkData)[i], S_StratLnk_BegDate, crystalDates[j]);
                        SET_DATE((*stratLnkData)[(*dataRows)+addedRows-1], S_StratLnk_EndDate, crystalDates[j]);
                    }

                }
            }
        }

        (*dataRows) += addedRows;
		FREE(crystalDates); /* REF8712 - YST - 030807 */

    }

    /* REF9187 - LJE - 030709 */
    if ((*dataRows) > 1)
    {
        if (GET_FLAG(searchLnkSt,   A_SearchLnk_CurrentFlg) == TRUE)
        {
            TLS_Sort((char *) (*stratLnkData), (*dataRows), sizeof(DBA_DYNFLD_STP),
			        (TLS_CMPFCT *) DBA_CmpSLPriorityCurrent, NULL, SortRtnTp_None);
        }
        else
        {
            TLS_Sort((char *) (*stratLnkData), (*dataRows), sizeof(DBA_DYNFLD_STP),
			        (TLS_CMPFCT *) DBA_CmpSLPriority, NULL, SortRtnTp_None);
        }
    }

    /* Only for current and period select (not for all) */ /* REF9264 - LJE - 030709 */
    if (GET_FLAG(searchLnkSt,   A_SearchLnk_CurrentFlg) == TRUE ||
        (GET_FLAG(searchLnkSt,   A_SearchLnk_AllHistFlg)    == FALSE &&
         GET_FLAG(searchLnkSt, A_SearchLnk_SinglePeriodFlg) == TRUE))
    {
        for (i=0; i<(*dataRows); i++)
        {
            if (i==0 ||
                (GET_FLAG(searchLnkSt, A_SearchLnk_SinglePeriodFlg) == TRUE  &&
                 GET_DATE((*stratLnkData)[i], S_StratLnk_BegDate) != GET_DATE((*stratLnkData)[i-1], S_StratLnk_BegDate)))
            {
                rank = 1;
            }

            SET_INT((*stratLnkData)[i], S_StratLnk_Rank, rank);/* PMSTA49957 - VSW - 160822 */

            rank++;
        }
    }

    /* PMSTA-17695 - LJE - 140304 */
    if ((*dataRows) == 0)
    {
        FREE((*stratLnkData));
    }

	DBA_FreeHier(hierHead); /* REF10276 - LJE - 040527 */
    return(RET_SUCCEED);
}

/************************************************************************
*
*   Function      : DBA_SelConstrScriptStratData
*
*   Description   : Select data for  Strategy function (simulation)
*                   - all script definition
*
*   Arguments     : domainPtr       domain dynamic structure pointer
*           strategyHierHead    strategy hierarchy header pointer
*
*   Return        : RET_SUCCEED         if ok
*           RET_GEN_ERR_INVARG      errors in arguments
*           RET_DBA_ERR_CONNOTFOUND error in finding free connection
*           RET_DBA_ERR_NODATA      error in data retrieval
*           RET_MEM_ERR_ALLOC       error in memory allocation
*           RET_GEN_ERR_SORTSIZE    error in sorting function
*           RET_DBA_ERR_MD      error in meta-dictionnary
*
*   Creation Date : REF2996 - SSO - 990114
*
*************************************************************************/
RET_CODE DBA_SelConstrScriptStratData(DBA_DYNFLD_STP domainPtr, DBA_HIER_HEAD_STP strategyHierHead)
{
    DBA_DYNFLD_STP      getArgSt;
    RET_CODE        ret;
    DBA_DYNFLD_STP      *ScriptDefTab=NULL, *groupScriptDefTab=NULL;
    int         rowNb=0,groupScriptDefNbr=0,i;
    FLAG_T          groupScriptFlg;

    if ((getArgSt = ALLOC_DYNST(Get_Arg)) == NULL)
    {
           MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "Get_Arg");
           return(RET_MEM_ERR_ALLOC);
    }

    SET_ID(getArgSt, Get_Arg_Id, GET_ID(domainPtr, A_Domain_FctResultId))

        if ((ret = DBA_Select2(ScriptDef,
            DBA_ROLE_SCPT_DEF_STRAT,
            Get_Arg,
            getArgSt,
            A_ScriptDef,
            &ScriptDefTab,
            UNUSED,
            UNUSED,
            &rowNb,
            UNUSED,
            UNUSED)) != RET_SUCCEED)
        {
                FREE_DYNST(getArgSt, Get_Arg);
                return(ret);
        }
    FREE_DYNST(getArgSt, Get_Arg);

    /* NB: code copied from DBA_SelCheckStratData */
    groupScriptFlg = FALSE;
    if (rowNb > 0)              /* BUG266 */
    {
        /* BUG454 - RAK - 970805 */
        ret = DBA_GroupScriptDef(ScriptDefTab, rowNb, FALSE, FALSE, &groupScriptDefTab,
                     &groupScriptDefNbr);
        if (ret == RET_SUCCEED)
            groupScriptFlg = TRUE;

        if (ret == RET_GEN_INFO_NOACTION)
        {
                ret = DBA_AddHierRecordList(strategyHierHead,
                                            ScriptDefTab,
                                            rowNb,
                                            A_ScriptDef,
                                            TRUE);
        }
        else if (ret == RET_SUCCEED)
        {
                ret = DBA_AddHierRecordList(strategyHierHead,
                                            groupScriptDefTab,
                                            groupScriptDefNbr,
                                            A_ScriptDef,
                                            TRUE);

                /* free all record from ScriptDefTab (not insert in hierarchy) */
                /* don't free array !!! XDI 13/08/97 */
                for (i=0; i<rowNb; i++)
                   FREE_DYNST((ScriptDefTab[i]), A_ScriptDef);
        }

            if (ret != RET_SUCCEED)
            {
                MSG_SendMesg(RET_DBA_ERR_HIER, 0 , FILEINFO);
        DBA_FreeDynStTab(ScriptDefTab, rowNb, A_ScriptDef);
        if (groupScriptFlg == TRUE) /* BUG165 */
            DBA_FreeDynStTab(groupScriptDefTab, groupScriptDefNbr, A_ScriptDef);
                return(ret);
            }
    }

    /* nb: A_StratElt_A_ScriptDef_Ext link will be done in FIN_CheckStrat_Sim */

    /* free arrays */
    FREE(ScriptDefTab);
    FREE(groupScriptDefTab);

    return(RET_SUCCEED);
}

/************************************************************************
*   Function             : DBA_SortUniquePtfId
*
*   Description          : Sort a portfolio list and suppress duplicate records.
*
*   Arguments            : stratLnkTab  pointer on an array of strategy link records
*              rowNb    number of strategy link records
*              ioIdTab  pointer on an array of sorted indexes
*              resultRowNb  number of sorted Id's
*
*   Return               : RET_SUCCEED             : if ok
*
*   Creation Date        : 22.11.95 - PEC
*   Last Modif           : 29.02.96 - PEC - Ref.: DVP016
*************************************************************************/
#ifdef NOT_USED
    STATIC RET_CODE DBA_SortUniquePtfId(DBA_DYNFLD_STP **stratLnkTab,
                    int            rowNb,
                    DBA_DYNFLD_STP **ioIdTab,
                    int            *resultRowNb)
    {
        DBA_DYNFLD_STP *localTab=NULL;
        DBA_DYNFLD_STP *localStratLnkTab=NULL;
        ID_T           currPtfId=0;
        DBA_DYNFLD_STP *stratLnkSt=NULL;
        int            i;
        PTR            *indexPtr=NULL;
        int            (*icmp) ();

        indexPtr = (PTR *)CALLOC(rowNb, sizeof(PTR *));

        localTab = *stratLnkTab;

        for (i=0 ; i<rowNb ; i++)
            indexPtr[i] = (PTR) &localTab[i];

        icmp = DBA_CmpShStratLnkPtfId;

        qsort(*indexPtr, rowNb, sizeof(PTR *), icmp);

        *resultRowNb = 0;

        localTab = CALLOC(rowNb, sizeof(DBA_DYNFLD_STP));

        for (i=0 ; i<rowNb ; i++)
        {
            stratLnkSt = (DBA_DYNFLD_STP *)indexPtr[i];

            if (currPtfId != GET_ID(stratLnkSt[0], S_StratLnk_PtfId))
            {
                localTab[*resultRowNb] = ALLOC_DYNST(Io_Id);
                COPY_DYNFLD(localTab[*resultRowNb], Io_Id, Io_Id_Id,
                    stratLnkSt[0], S_StratLnk, S_StratLnk_PtfId);
                ++(*resultRowNb);
                currPtfId = GET_ID(stratLnkSt[0], S_StratLnk_PtfId);
            }
        }

        *ioIdTab = localTab;

        /******** BEGIN DVP016 **************/
        localStratLnkTab = CALLOC(rowNb, sizeof(DBA_DYNFLD_STP));

        for (i=0 ; i<rowNb ; i++)
        {
            stratLnkSt = (DBA_DYNFLD_STP *)indexPtr[i];
            localStratLnkTab[i] = stratLnkSt[0];
        }

        FREE(*stratLnkTab);

        *stratLnkTab = localStratLnkTab;
        /********* END DVP016 *****************/

        FREE(indexPtr);

        return(RET_SUCCEED);
    }
#endif

/************************************************************************
*   Function             : DBA_SortUniqueStratId
*
*   Description          : Sort a list of strategy id's by creating a new
*              index pointer array.  Function uses comparison function
*              DBA_CmpShStratLnkStratId.
*
*   Arguments            : stratLnkTab  pointer on an array of strategy link records
*              rowNb    number of strategy link records
*              ioIdTab  pointer on an array of sorted indexes
*              resultRowNb  number of sorted Id's
*
*   Return               : RET_SUCCEED if ok, RET_CODE otherwise
*
*   Creation Date        : 28.11.95 - DED
*   Last Modif           : REF7395 - CSY - 020322: STATIC to EXTERN
*************************************************************************/
RET_CODE DBA_SortUniqueStratId(DBA_DYNFLD_STP *stratLnkTab, int rowNb,
                          DBA_DYNFLD_STP **ioIdTab, int *resultRowNb)
{
    DBA_DYNFLD_STP *localTab=NULL;
    ID_T           currStratId=0;
    DBA_DYNFLD_STP *stratLnkSt=NULL;
    int            i;
    PTR            *indexPtr=NULL;
    int            (*icmp) (const void*, const void*);

	/* REF7248B - CHU - 020314 */
	if(rowNb == 0)
		return(RET_SUCCEED);

    indexPtr = (PTR *)CALLOC(rowNb, sizeof(PTR *));

    for (i=0 ; i<rowNb ; i++)
        indexPtr[i] = (PTR) &stratLnkTab[i];

    icmp = (int (*)(const void*, const void*))DBA_CmpShStratLnkStratId;

    qsort(*indexPtr, rowNb, sizeof(PTR *), icmp);

    *resultRowNb = 0;

    localTab = (DBA_DYNFLD_STP *)CALLOC(rowNb, sizeof(DBA_DYNFLD_STP)); /* REF7264 - LJE - 020131 */

    for (i=0 ; i<rowNb ; i++)
    {
        stratLnkSt = (DBA_DYNFLD_STP *)indexPtr[i];

        if (currStratId != GET_ID(stratLnkSt[0], S_StratLnk_StratId))
        {
            localTab[*resultRowNb] = ALLOC_DYNST(Io_Id);
            COPY_DYNFLD(localTab[*resultRowNb], Io_Id, Io_Id_Id,
                        stratLnkSt[0], S_StratLnk, S_StratLnk_StratId);
            ++(*resultRowNb);
            currStratId = GET_ID(stratLnkSt[0], S_StratLnk_StratId);
        }
    }

    *ioIdTab = localTab;

    FREE(indexPtr);

    return(RET_SUCCEED);
}

/************************************************************************
*   Function             : DBA_UpdInstrStratElt()
*
*   Description          : Replaces instruments of selected strategy elements
*
*   Arguments            : updStrat pointer on A_UpdStratElt
*
*   Return               : RET_CODE
*
*   Creation date        : REF4908 - 000620 - DED
*   Last modification    : REF9303 - 030915 - PMO : Implementation of Unicode
*
*************************************************************************/
RET_CODE DBA_UpdInstrStratElt(DBA_DYNFLD_STP updStrat)
{
    DBA_HIER_HEAD_STP       hierStrat=NULL;
    int                     j;
    RET_CODE                ret=RET_SUCCEED;
    DBA_ACCESS_STP          accessPtr=NULL;
    const DBA_DYNST_ENUM    *outputStLst[]={&A_Strat, &A_StratHist, &A_StratElt};  /* REF8844 - LJE - 030416 */
    int                     stratEltNbr=0, size=0, ICErrNbr=0, ICWarnNbr=0, updStratEltNbr=0;
    int                     dataRows[3]={0,0,0};
    DBA_DYNFLD_STP          *data[3]={NULL, NULL, NULL},
                            *stratEltTab=NULL,
                            domainArg=NULL,
                            stratPtr=NULL,
                            stratHistPtr=NULL,
                            oldInstrPtr=NULL,
                            *message=NULL,
                            newInstrPtr=NULL;
    FLAG_T                  allocFlg=FALSE,
                            errorFlg=FALSE,
                            allocFlg1=FALSE;
    char                    *buffer=NULL;
    DbiConnection*          dbiConn=nullptr;

    /* Check arguments */
    if (updStrat == NULL ||
        IS_NULLFLD(updStrat, A_UpdStratElt_OldInstrId) == TRUE ||
        IS_NULLFLD(updStrat, A_UpdStratElt_NewInstrId) == TRUE)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_UpdInstrStratElt", "updStrat, Old instrument or New instrument");
        return(RET_GEN_ERR_INVARG);
    }

    /* Check if new instrument = old instrument */
    if (CMP_DYNFLD(updStrat, updStrat, A_UpdStratElt_OldInstrId, A_UpdStratElt_NewInstrId,
        GET_FLD_TYPE(A_UpdStratElt, A_UpdStratElt_NewInstrId)) == 0)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_UpdInstrStratElt", "Old=New Instrument");
        return(RET_GEN_ERR_INVARG);
    }

    /* Get two instruments records */
    if ((ret = DBA_GetInstrById(GET_ID(updStrat, A_UpdStratElt_OldInstrId), FALSE, &allocFlg, &oldInstrPtr,
                    NULL, UNUSED, UNUSED)) != RET_SUCCEED)
    {
        MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, "instrument", GET_ID(updStrat, A_UpdStratElt_OldInstrId));
        if (allocFlg == TRUE) FREE_DYNST(oldInstrPtr, A_Instr);
        return(RET_DBA_ERR_NODATA);
    }
    if ((ret = DBA_GetInstrById(GET_ID(updStrat, A_UpdStratElt_NewInstrId), FALSE, &allocFlg1, &newInstrPtr,
                    NULL, UNUSED, UNUSED)) != RET_SUCCEED)
    {
        MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, "instrument", GET_ID(updStrat, A_UpdStratElt_NewInstrId));
        if (allocFlg == TRUE) FREE_DYNST(oldInstrPtr, A_Instr);
        if (allocFlg1 == TRUE) FREE_DYNST(newInstrPtr, A_Instr);
        return(RET_DBA_ERR_NODATA);
    }

    /* message */

    MSG_LogSrvMesg(UNUSED, UNUSED,
        "Start Strategy Switch Instrument (%1 -> %2)",
        CodeType, GET_CODE(oldInstrPtr, A_Instr_Cd),
        CodeType, GET_CODE(newInstrPtr, A_Instr_Cd));

    /********************************* Prepare data load *******************************/

    /* Memory allocation for domain */
    if ((domainArg = ALLOC_DYNST(A_Domain)) == NULL)
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "A_Domain");
        MSG_LogSrvMesg(UNUSED, UNUSED,
            "Exit Strategy Switch Instrument (%1 -> %2) with errors. Check log file of Financial server.",
            CodeType, GET_CODE(oldInstrPtr, A_Instr_Cd),
            CodeType, GET_CODE(newInstrPtr, A_Instr_Cd));
        if (allocFlg == TRUE) FREE_DYNST(oldInstrPtr, A_Instr);
        if (allocFlg1 == TRUE) FREE_DYNST(newInstrPtr, A_Instr);
        return(RET_MEM_ERR_ALLOC);
    }

    /* Set fields */
    COPY_DYNFLD(domainArg, A_Domain, A_Domain_DimStratDictId, updStrat, A_UpdStratElt, A_UpdStratElt_DimStratDictId);
    COPY_DYNFLD(domainArg, A_Domain, A_Domain_StratObjId, updStrat, A_UpdStratElt, A_UpdStratElt_StratObjId);
    COPY_DYNFLD(domainArg, A_Domain, A_Domain_InterpFromDate, updStrat, A_UpdStratElt, A_UpdStratElt_FromDate);
    COPY_DYNFLD(domainArg, A_Domain, A_Domain_InstrObjId, updStrat, A_UpdStratElt, A_UpdStratElt_OldInstrId);

    /* Get a free connection in the connection list */
    if ((dbiConn = DBA_GetDbiConnection()) == nullptr)
    {
        MSG_LogSrvMesg(UNUSED, UNUSED,
            "Exit Strategy Switch Instrument (%1 -> %2) with errors. Check log file of Financial server.",
            CodeType, GET_CODE(oldInstrPtr, A_Instr_Cd),
            CodeType, GET_CODE(newInstrPtr, A_Instr_Cd));
        FREE_DYNST(domainArg, A_Domain);
        if (allocFlg == TRUE) FREE_DYNST(oldInstrPtr, A_Instr);
        if (allocFlg1 == TRUE) FREE_DYNST(newInstrPtr, A_Instr);
        MSG_RETURN(RET_DBA_ERR_CONNOTFOUND);
    }

    /* Create temporary tables #dom_strat */  /* REF5062 - SSO - 000824 ret test */
    if ((ret = DBA_CreateDomPortAndDomStratTables(dbiConn->getId(), FALSE))  != RET_SUCCEED)
    {
        MSG_LogSrvMesg(UNUSED, UNUSED,
            "Exit Strategy Switch Instrument (%1 -> %2) with errors. Check log file of Financial server.",
            CodeType, GET_CODE(oldInstrPtr, A_Instr_Cd),
            CodeType, GET_CODE(newInstrPtr, A_Instr_Cd));
        FREE_DYNST(domainArg, A_Domain);
        if (allocFlg == TRUE) FREE_DYNST(oldInstrPtr, A_Instr);
        if (allocFlg1 == TRUE) FREE_DYNST(newInstrPtr, A_Instr);
        DBA_DelDomPortAndDomStratTables(dbiConn->getId(), FALSE);
        DBA_EndConnection(&dbiConn);
        return(ret);
    }

    /* Initialize dom_strat according to domain strategy dimension */
    if ((ret = DBA_InitDomStrat(domainArg, A_Domain, *dbiConn)) != RET_SUCCEED)
    {
        MSG_LogSrvMesg(UNUSED, UNUSED,
            "Exit Strategy Switch Instrument (%1 -> %2) with errors. Check log file of Financial server.",
            CodeType, GET_CODE(oldInstrPtr, A_Instr_Cd),
            CodeType, GET_CODE(newInstrPtr, A_Instr_Cd));
        FREE_DYNST(domainArg, A_Domain);
        if (allocFlg == TRUE) FREE_DYNST(oldInstrPtr, A_Instr);
        if (allocFlg1 == TRUE) FREE_DYNST(newInstrPtr, A_Instr);
        DBA_DelDomPortAndDomStratTables(dbiConn->getId(), FALSE);
        DBA_EndConnection(&dbiConn);
        return(ret);
    }

    /* Keep only strategies of nature "Recommendation List" and "Model Portfolio" */
    DBA_SqlExec("delete from #dom_strat "
        "where nature_e not in (2,3) ", *dbiConn);

    /************************************* Data Load ***********************************/

    /* Using '#dom_strat', select 3 blocks of data :
    - strategy
    - strategy history
    - strategy element
    */

	/*
	 * REF11435 - TEB - 051012 : Remark but no modification :
	 * In this ref I have replaced domain by search link for the
	 * call of sel_exd_strategy_by_domain, but for following case
	 * it is a call to sel_exd_strategy_by_instr. So I dont
	 * modify the entry point. (Juste un pense bete)
	 */
    if ((ret = DBA_MultiSelect2(Strat,
                                UNUSED,
                                A_Domain,
                                domainArg,
                                outputStLst,
                                data,
                                DBA_SET_CONN|DBA_NO_CLOSE,
                                UNUSED,
                                dataRows,
                                *dbiConn,
                                UNUSED)) != RET_SUCCEED)
    {
        MSG_SendMesg(RET_DBA_ERR_NODATA, 0, FILEINFO);
        MSG_LogSrvMesg(UNUSED, UNUSED,
            "Exit Strategy Switch Instrument (%1 -> %2) with errors. Check log file of Financial server.",
            CodeType, GET_CODE(oldInstrPtr, A_Instr_Cd),
            CodeType, GET_CODE(newInstrPtr, A_Instr_Cd));
        FREE_DYNST(domainArg, A_Domain);
        if (allocFlg == TRUE) FREE_DYNST(oldInstrPtr, A_Instr);
        if (allocFlg1 == TRUE) FREE_DYNST(newInstrPtr, A_Instr);
        DBA_DelDomPortAndDomStratTables(dbiConn->getId(), FALSE);
        DBA_EndConnection(&dbiConn);
        return(ret);
    }

    /* End connection */
    FREE_DYNST(domainArg, A_Domain);
    DBA_DelDomPortAndDomStratTables(dbiConn->getId(), FALSE);
    DBA_EndConnection(&dbiConn);

    /* Test number of strategy elements found */
    if (dataRows[2] < 1)
    {
        MSG_LogSrvMesg(UNUSED, UNUSED,
            "Exit Strategy Switch Instrument (%1 -> %2) : No strategy elements to update ...",
            CodeType, GET_CODE(oldInstrPtr, A_Instr_Cd),
            CodeType, GET_CODE(newInstrPtr, A_Instr_Cd));
        if (allocFlg == TRUE) FREE_DYNST(oldInstrPtr, A_Instr);
        if (allocFlg1 == TRUE) FREE_DYNST(newInstrPtr, A_Instr);
        DBA_MultiFree(data, outputStLst, dataRows, 3);
        return(RET_DBA_ERR_NODATA);
    }

    /* Create strategy hierarchy */
    if ((hierStrat = DBA_CreateHier()) == NULL)  /* REF5239 - RAK - 001025 */
    {
        if (allocFlg == TRUE) FREE_DYNST(oldInstrPtr, A_Instr);
        if (allocFlg1 == TRUE) FREE_DYNST(newInstrPtr, A_Instr);
        DBA_MultiFree(data, outputStLst, dataRows, 3);
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    /* Add records in hierarchy */
    for (int i=0; i<3; i++)
    {
        if ((ret = DBA_AddHierRecordList(hierStrat, data[i], dataRows[i], *(outputStLst[i]), TRUE)) != RET_SUCCEED) /* REF7264 - LJE - 020131 */
        {
            if (allocFlg == TRUE) FREE_DYNST(oldInstrPtr, A_Instr);
            if (allocFlg1 == TRUE) FREE_DYNST(newInstrPtr, A_Instr);
            /*
            DBA_MultiFree(data, outputStLst, dataRows, 3);
            */
            DBA_FreeHier(hierStrat);
            return(ret);
        }
    }

    /***************************** Update strategy elements ***************************/

    /* Init */
    stratEltTab = data[2];
    stratEltNbr = dataRows[2];

    if (stratEltNbr > 0)
    {
        if ((accessPtr = (DBA_ACCESS_STP)CALLOC(stratEltNbr, sizeof(DBA_ACCESS_ST))) == NULL)
        {
            MSG_LogSrvMesg(UNUSED, UNUSED,
                "Exit Strategy Switch Instrument (%1 -> %2) with errors. Check log file of Financial server.",
                CodeType, GET_CODE(oldInstrPtr, A_Instr_Cd),
                CodeType, GET_CODE(newInstrPtr, A_Instr_Cd));
            if (allocFlg == TRUE) FREE_DYNST(oldInstrPtr, A_Instr);
            if (allocFlg1 == TRUE) FREE_DYNST(newInstrPtr, A_Instr);
            /*
            DBA_MultiFree(data, outputStLst, dataRows, 3);
            */
            DBA_FreeHier(hierStrat);
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }
    }
    else
    {
        accessPtr = NULL;
    }

    /* Loop on all strategy elements */
    for (int i=0; i<stratEltNbr; i++)
    {
        /* Continue if instrument equals new instrument */
        if (CMP_DYNFLD(updStrat, stratEltTab[i], A_UpdStratElt_NewInstrId, A_StratElt_InstrId,
            GET_FLD_TYPE(A_UpdStratElt, A_UpdStratElt_NewInstrId)) == 0)
        {
            /* Fill up records array */
            continue;
        }

        /* Continue if instrument is different from old instrument */
        if (CMP_DYNFLD(updStrat, stratEltTab[i], A_UpdStratElt_OldInstrId, A_StratElt_InstrId,
            GET_FLD_TYPE(A_UpdStratElt, A_UpdStratElt_OldInstrId)) != 0)
        {
            /* Fill up records array */
            continue;
        }

        /* By default replace instrument by new one */
        COPY_DYNFLD(stratEltTab[i], A_StratElt, A_StratElt_InstrId, updStrat, A_UpdStratElt, A_UpdStratElt_NewInstrId);

        /* Reset */
        errorFlg=FALSE;

        /* Call input controls */
        SCPT_ComputeIC(StratElt, stratEltTab[i], &size, &message, TRUE);
        if(size>0)
        {
            /* Loop on all messages */
            for (j=0; j<size; j++)
            {
                /* Display message in log file */
                MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, GET_NOTE(message[j], Msg_String));

                if (GET_ENUM(message[j], Msg_NatEn) == MsgNat_Error)
                {
                    errorFlg=TRUE;
                }
            }

            if (errorFlg==TRUE)
            {
                /* Init */
                stratHistPtr=NULL;
                stratPtr=NULL;

                /* Display message */
                /* Get strategy History record from hierarchy */
                DBA_GetRecPtrFromHierById(hierStrat,
                    GET_ID(stratEltTab[i], A_StratElt_StratHistId),
                    A_StratHist,
                    &stratHistPtr);
                if (stratHistPtr != NULL)
                {
                    /* Get strategy record from hierarchy */
                    DBA_GetRecPtrFromHierById(hierStrat,
                        GET_ID(stratHistPtr, A_StratHist_StratId),
                        A_Strat,
                        &stratPtr);
                    if (stratPtr != NULL)
                    {
                        char dateFmt[30], buf[30];

                        buffer = (char*) CALLOC(1, GET_MAXDATALEN(NoteType)*SCPTDEF_MAX_REC);
                        DATETIME64_ST date = GET_DATETIMEST(stratHistPtr, A_StratHist_BegDate);
                        CONV_GetDfltDateFmt(DatetimeType, dateFmt, NULL);
                        CONV_DataToStr(buf,
                                       sizeof(buf),     /* REF9303 - 030915 - PMO */
                                       DatetimeType,
                                       dateFmt,
                                       &date,
                                       FALSE,
                                       TextConversion_None);
                        sprintf(buffer, "Function Switch instrument : no update of instrument %s possible (strategy %s, strategy history begin date %s, strategy element rank %d)",
                            GET_CODE(oldInstrPtr, A_Instr_Cd),
                            GET_CODE(stratPtr, A_Strat_Cd),
                            buf,
                            GET_SMALLINT(stratEltTab[i], A_StratElt_Rank));
                        MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, buffer);
                        MSG_LogSrvMesg(UNUSED, UNUSED, buffer);
                        FREE(buffer);
                    }
                }

                /* Reset old instrument in strategy element */
                COPY_DYNFLD(stratEltTab[i], A_StratElt, A_StratElt_InstrId, updStrat, A_UpdStratElt, A_UpdStratElt_OldInstrId);
        ICErrNbr++;

            }
            else
            {
                /* Fill up records array */
                accessPtr[i].action = Update;
                accessPtr[i].role   = UNUSED;
                accessPtr[i].object = StratElt;
                accessPtr[i].entity = A_StratElt;
                accessPtr[i].stamp  = 0;
                accessPtr[i].data   = stratEltTab[i];

                updStratEltNbr++;
        ICWarnNbr++;
            }

            /* Free error messages array */
            DBA_FreeDynStTab(message, size, Msg);
            size=0;
            message=NULL;
        }
        else
        {
            /* Fill up records array */
            accessPtr[i].action = Update;
            accessPtr[i].role   = UNUSED;
            accessPtr[i].object = StratElt;
            accessPtr[i].entity = A_StratElt;
            accessPtr[i].stamp  = 0;
            accessPtr[i].data   = stratEltTab[i];

            updStratEltNbr++;
        }
    }

    /********************************* Update database *************************************/

    /* Get a free connection in the connection list */
    if ((dbiConn = DBA_GetDbiConnection()) == nullptr)
    {
        MSG_SendMesg(RET_DBA_ERR_CONNOTFOUND, 0, FILEINFO);
        MSG_LogSrvMesg(UNUSED, UNUSED,
            "Exit Strategy Switch Instrument (%1 -> %2) with errors. Check log file of Financial server.",
            CodeType, GET_CODE(oldInstrPtr, A_Instr_Cd),
            CodeType, GET_CODE(newInstrPtr, A_Instr_Cd));
        if (allocFlg == TRUE) FREE_DYNST(oldInstrPtr, A_Instr);
        if (allocFlg1 == TRUE) FREE_DYNST(newInstrPtr, A_Instr);
        /*
        DBA_MultiFree(data, outputStLst, dataRows, 3);
        */
        DBA_FreeHier(hierStrat);
        if (accessPtr) FREE(accessPtr);
        return(RET_DBA_ERR_CONNOTFOUND);
    }

    dbiConn->setModifStat(1); /* PMSTA-28916 - LJE - 171214 */

    {
        DbaMultiAccessHelper       multiAccessHelper(accessPtr, updStratEltNbr);

        /* Call MultiAccess */
        ret = multiAccessHelper.callMultiAccess(UNUSED, DBA_SET_CONN|DBA_NO_CLOSE, *dbiConn, true);
        if (ret != RET_SUCCEED || dbiConn->emptyMsg() == false)
        {
            MSG_LogSrvMesg(UNUSED, UNUSED,
                "Exit Strategy Switch Instrument (%1 -> %2) : %3 strategy elements to update (IC : %4 refused, %5 warnings, %6 database errors).",
                CodeType, GET_CODE(oldInstrPtr, A_Instr_Cd),
                CodeType, GET_CODE(newInstrPtr, A_Instr_Cd),
                IntType, stratEltNbr,
                IntType, ICErrNbr,
                IntType, ICWarnNbr,
                IntType, static_cast<int>(dbiConn->m_msgStructHeaderSt.msgStructTab.size()));

            multiAccessHelper.sendAllMultiAccessMsg();
        }
        else
        {
            MSG_LogSrvMesg(UNUSED, UNUSED,
                "Exit Strategy Switch Instrument (%1 -> %2) : %3 of %4 strategy elements updated (IC : %5 refused, %6 warnings).",
                CodeType, GET_CODE(oldInstrPtr, A_Instr_Cd),
                CodeType, GET_CODE(newInstrPtr, A_Instr_Cd),
                IntType, updStratEltNbr,
                IntType, stratEltNbr,
            IntType, ICErrNbr,
            IntType, ICWarnNbr);
        }
    }

    dbiConn->setModifStat(0); /* PMSTA-28916 - LJE - 171214 */
    DBA_UpdTableModifStat(*dbiConn, StratElt);

    /* Update global memory with changed local values */
    DBA_VerifOptiTab();

    /* End connection */
    if (DBA_EndConnection(&dbiConn) != RET_SUCCEED)
    {
        MSG_SendMesg(RET_DBA_ERR_DISCONNECTED, 0, FILEINFO);
    }

    /* Free memory allocations */
    if (allocFlg == TRUE) FREE_DYNST(oldInstrPtr, A_Instr);
    if (allocFlg1 == TRUE) FREE_DYNST(newInstrPtr, A_Instr);
    /*
    DBA_MultiFree(data, outputStLst, dataRows, 3);
    */
    DBA_FreeHier(hierStrat);
    if (accessPtr) FREE(accessPtr);

    return(ret);
}

/************************************************************************
**
**  Function    :   DBA_CmpPtfSynthPtfDateGlobal()
**
**  Description :   Synthetics sorted by portfolio id, date, global lines
**                  (detail level)
**
**  Arguments   :   ptr1   pointer on dynamic structure type ExtPos
**                  ptr2   pointer on dynamic structure type ExtPos
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation  	:   REF6912 - CSY - 010810
**
*************************************************************************/
STATIC int DBA_CmpPtfSynthPtfDateGlobal(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
	/* Portfolio */
	if (GET_ID((*ptr1), A_PtfSynth_PtfId) == GET_ID((*ptr2), A_PtfSynth_PtfId))
	{
	    /* Date */
        if (DATETIME_CMP(GET_DATETIME((*ptr1), A_PtfSynth_InitialDate),
		                GET_DATETIME((*ptr2), A_PtfSynth_InitialDate)) == 0)
        {
            /* level global : A_PtfSynth_MktSegtId null and A_PtfSynth_InstrId null */
            if (IS_NULLFLD((*ptr1), A_PtfSynth_MktSegtId)
                && IS_NULLFLD((*ptr1), A_PtfSynth_InstrId) &&
                IS_NULLFLD((*ptr2), A_PtfSynth_MktSegtId)
                && IS_NULLFLD((*ptr2), A_PtfSynth_InstrId))
            {
                return (0);
            }
            else if (IS_NULLFLD((*ptr1), A_PtfSynth_MktSegtId)
                && IS_NULLFLD((*ptr1), A_PtfSynth_InstrId) &&
                (IS_NULLFLD((*ptr2), A_PtfSynth_MktSegtId) == FALSE
                || IS_NULLFLD((*ptr2), A_PtfSynth_InstrId) == FALSE))
            {
                /* put global lines before detail lines */
                return (-1);
            }
            else
            {
                return (1);
            }
        }
        else
        {
	        return(DATETIME_CMP(GET_DATETIME((*ptr1), A_PtfSynth_InitialDate),
		                GET_DATETIME((*ptr2), A_PtfSynth_InitialDate)));
        }
	}
	else
	{
	    return(CMP_ID(GET_ID((*ptr1), A_PtfSynth_PtfId) , GET_ID((*ptr2), A_PtfSynth_PtfId))); /* DLA - REF9089 - 030509 */
	}
}

STATIC int DBA_ParentInList(ID_T ParPtfId, DBA_DYNFLD_STP *data, int dataRows)
{

   int j;

   if(ParPtfId == (ID_T)0)
      return (FALSE);
   for(j=0; j< dataRows; j++)
   {
      if(GET_ID(data[j], A_Ptf_Id) == ParPtfId)
         return(TRUE);
   }
   return (FALSE);
}



/************************************************************************
**
**  Function    :   FIN_checkForHierTCApplicable()
**
**  Description :   Check if trading constraint is applicable 
**                  for the portfolio based on Application scope and load Hier flag  
**
**  Arguments   :  
**                 
**
**  Return      :  true :- trading constraint is applicable
**                 false :- trading constraint is not applicable
**
**  Creation  	:   PMSTA-41153 - Vishnu - 250720
**
*************************************************************************/
static bool FIN_checkForHierTCApplicable(DBA_DYNFLD_STP domainPtr,
    DBA_DYNFLD_STP ** data, int *dataRows,
    int tradConstrIdx1, int tradConstrIdx2, int dataPtfIdx, int ptfCnt, int TCcnt)
{
    /*If not same hier ignore*/
    if (CMP_DYNFLD(data[tradConstrIdx1][TCcnt], data[dataPtfIdx][ptfCnt], A_TradConstr_HierHeadPtf, A_Ptf_HierHeadPtf, IdType) != 0)
        return false;

    enum TradConstrApplicationScopeEn applScopeEn = static_cast<TradConstrApplicationScopeEn> (GET_ENUM(data[tradConstrIdx1][TCcnt], A_TradConstr_ApplicationScopeEn));

    /* if Hierarchy Individual then always link*/
    if (applScopeEn == TradConstrApplicationScopeEn::HierarchyIndividual &&
        (DBA_Check_Hier_Lnk(GET_ID(data[tradConstrIdx1][TCcnt], A_TradConstr_PtfId), GET_ID(data[dataPtfIdx][ptfCnt], A_Ptf_Id)) == true))      /*WEALTH-5840-Satya*/
        return true;

    /*else (None/PortfolioOnly) link only if Constraints directly linked to the portfolio*/
    if (CMP_DYNFLD(data[tradConstrIdx1][TCcnt], data[dataPtfIdx][ptfCnt], A_TradConstr_PtfId, A_Ptf_Id, IdType) == 0)
        return true;

    return false;
}

STATIC RET_CODE DBA_TradConstr2ExtStratLnk(DBA_DYNFLD_STP domainPtr, /* PMSTA04614-CHU-071030 */
										   DBA_DYNFLD_STP ** data, int *dataRows,
                                           DBA_DYNFLD_STP * extStratLnkData, int *p_id, /* PMSTA08801 - DDV - 091126 */
                                           int tradConstrIdx1, int tradConstrIdx2, int dataPtfIdx)
{

   int i, j, k, m;
   int idx = *p_id; /* DLA - REF9089 - 030509 */ /* PMSTA08801 - DDV - 091126 */
   DICT_T ptfDictId;
   DBA_DYNFLD_STP getListPtr = NULL, sListPtr = NULL, inputPtr = NULL;
   DBA_DYNFLD_STP *ioIdTab=NULL;
   int ioIdNbr, listNatEn;
   FLAG_T resultFlag;
   RET_CODE ret;
   OBJECT_ENUM entObjectEnum;
   int found = 0;
   FLAG_T chkHldgCstrFlg = (FLAG_T)(GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_CheckHoldingConstraints);
   FLAG_T hierConstrUsed = 0;
   GEN_GetApplInfo(ApplHierConstraintUsed, &hierConstrUsed);

   DBA_GetDictId(Ptf, &ptfDictId);
   DBA_GetObjectEnum(ptfDictId, &entObjectEnum);

   for (i = 0; i < dataRows[tradConstrIdx1]; i++)
   {
       /*use existing logic*/
       if (hierConstrUsed == 0)
           break;

       /*Set hier head ptfolio id for all trading constraint otfs*/
       if (IS_NULLFLD(data[tradConstrIdx1][i], A_TradConstr_HierHeadPtf) == TRUE)
       {
           ID_T hierPtfId = ZERO_ID;
           DBA_GetHierHeadPTF(GET_ID(data[tradConstrIdx1][i], A_TradConstr_PtfId), &hierPtfId);

           SET_ID(data[tradConstrIdx1][i], A_TradConstr_HierHeadPtf, hierPtfId);
           for (j = 0; j < dataRows[tradConstrIdx1]; j++)
           {
               if (CMP_DYNFLD(data[tradConstrIdx1][i], data[tradConstrIdx1][j], A_TradConstr_PtfId, A_TradConstr_PtfId, IdType) == 0)
                   SET_ID(data[tradConstrIdx1][j], A_TradConstr_HierHeadPtf, hierPtfId);
           }

           for (j = 0; j < dataRows[dataPtfIdx]; j++)
           {
               /*set hier ptf id in A_ptf also*/
               if (CMP_DYNFLD(data[tradConstrIdx1][i], data[dataPtfIdx][j], A_TradConstr_PtfId, A_Ptf_Id, IdType) == 0)
                   SET_ID(data[dataPtfIdx][j], A_Ptf_HierHeadPtf, hierPtfId);
           }

       }
   }

   for (i = 0; i < dataRows[dataPtfIdx]; i++)
   {
       /*use existing logic*/
       if (hierConstrUsed == 0)
           break;

       /*find hier head ptf details for all loaded portfolios*/
       if (IS_NULLFLD(data[dataPtfIdx][i], A_Ptf_HierHeadPtf) == TRUE)
       {
           ID_T hierPtfId = ZERO_ID;
           DBA_GetHierHeadPTF(GET_ID(data[dataPtfIdx][i], A_Ptf_Id), &hierPtfId);

           SET_ID(data[dataPtfIdx][i], A_Ptf_HierHeadPtf, hierPtfId);
       }

   }

   for (i=0; i<dataRows[tradConstrIdx1]; i++)
   {
       /* skip duplicates */

      found = 0;
      for(j=0; j<idx; j++) /* PMSTA08801 - DDV - 091126 */
      {
          if( (GET_ID(data[tradConstrIdx1][i], A_TradConstr_PortObjId) == GET_ID(extStratLnkData[j], ExtStratLnk_ObjId))
             && (GET_ID(data[tradConstrIdx1][i], A_TradConstr_Id) == GET_ID(extStratLnkData[j], ExtStratLnk_TradConstrId)))
          {
             found = 1;
             break;
          }
      }
      if(found)
         continue;

      /*PMSTA-41153 - Vishnu - 250720
        With hierarchy constraints we need to add ESL for every valid Trading constraint even the 
            trading constraints related to other portfolios if it�s in the same hierarchy.*/
      REBAL_METHOD_ENUM   rebalMethodEn = static_cast<REBAL_METHOD_ENUM>GET_ENUM(domainPtr, A_Domain_RebalMethodEn);

      for (int ptfCnt = 0; ptfCnt < dataRows[dataPtfIdx]; ptfCnt++)
      {
          /*use existing logic*/
          if (hierConstrUsed == 0)
          {
              /*existing logic link only trading constraints for same PTF*/
              if (CMP_DYNFLD(data[tradConstrIdx1][i], data[dataPtfIdx][ptfCnt], A_TradConstr_PortObjId, A_Ptf_Id, IdType) != 0)
                  continue;
          }
          else
          {
              if (true != FIN_checkForHierTCApplicable(domainPtr, data, dataRows, tradConstrIdx1, tradConstrIdx2, dataPtfIdx, ptfCnt, i))
                  continue;

          }

          if ((extStratLnkData[idx] = ALLOC_DYNST(ExtStratLnk)) == NULL) /* PMSTA08801 - DDV - 091126 */
          {
             return(RET_MEM_ERR_ALLOC);
          }

          if (rebalMethodEn != REBAL_METHOD_ENUM::Default && 
               IS_NULLFLD(data[dataPtfIdx][ptfCnt], A_Ptf_ParentPortId) == FALSE)
          {
              COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_PtfId, data[dataPtfIdx][ptfCnt], A_Ptf, A_Ptf_ParentPortId);
              COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_ObjId, data[dataPtfIdx][ptfCnt], A_Ptf, A_Ptf_ParentPortId);
              COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_OverlayPtfId, data[dataPtfIdx][ptfCnt], A_Ptf, A_Ptf_Id);   
          }
          else
          {
              COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_PtfId, data[dataPtfIdx][ptfCnt], A_Ptf, A_Ptf_Id); /* PMSTA08801 - DDV - 091126 */
              COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_ObjId, data[dataPtfIdx][ptfCnt], A_Ptf, A_Ptf_Id);    /* PMSTA08801 - DDV - 091126 */
          }


          /* Set values in extended strategy link */
          COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_TradConstrId, data[tradConstrIdx1][i], A_TradConstr, A_TradConstr_Id);   /* PMSTA08801 - DDV - 091126 */
          SET_DICT(extStratLnkData[idx],    ExtStratLnk_LnkObjDictId, ptfDictId);                                                             /* PMSTA08801 - DDV - 091126 */
          /*PMSTA-41153 Vishnu setting ExtStratLnk_ObjId as that of looping ptf*/
          COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_BegDate, data[tradConstrIdx1][i], A_TradConstr, A_TradConstr_BeginDate); /* PMSTA08801 - DDV - 091126 */
          COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_EndDate, data[tradConstrIdx1][i], A_TradConstr, A_TradConstr_EndDate);   /* PMSTA08801 - DDV - 091126 */

	      /* PMSTA07121 - RAK - 090514 */
	      COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_CriticalnessEn, data[tradConstrIdx1][i], A_TradConstr, A_TradConstr_CriticalnessEn); /* PMSTA08801 - DDV - 091126 */


          SET_ENUM(extStratLnkData[idx],    ExtStratLnk_StratNatEn, StratNat_TradingConstr); /* PMSTA08801 - DDV - 091126 */

          /* REF6082 - RAK - 011106 */
          SET_ENUM(extStratLnkData[idx],    ExtStratLnk_ConstrNatEn, ESLConstrNat_TradingConstr); /* PMSTA08801 - DDV - 091126 */

          SET_FLAG(extStratLnkData[idx],    ExtStratLnk_DirectFlg, TRUE); /* PMSTA08801 - DDV - 091126 */
          /*SET_FLAG(extStratLnkData[idx],    ExtStratLnk_EnumFlg, FALSE);*/ /* PMSTA08801 - DDV - 091126 */
          /*PMSTA-41153 Vishnu setting ExtStratLnk_ObjId as that of looping ptf*/

          /* set the child portfolio id in extStratLnk */
          for(j=0; j<dataRows[dataPtfIdx]; j++)
          {
             if(GET_ID(extStratLnkData[idx], ExtStratLnk_PtfId) == GET_ID(data[dataPtfIdx][j], A_Ptf_Id) && /* PMSTA08801 - DDV - 091126 */
                DBA_ParentInList(GET_ID(data[dataPtfIdx][j], A_Ptf_ParentPortId), data[dataPtfIdx], dataRows[dataPtfIdx]) &&
			    /* PMSTA05762-CHU-080519 - Old bug !? */
			    /* When TC direct link on child with parent in list, no use to mention it if Load Hier is None... right ?
			       Then, maybe the PMSTA04614 is a wrong way of correction here...
			     */
			    GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None)
             {
			    /* PMSTA04614-CHU-071030 : if Check Holding Constraint, Load hier flag must be true */
			     /*
			    if (chkHldgCstrFlg == FALSE || GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None)
			    {
			    */
	                COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_ParentPtfId, data[dataPtfIdx][j], A_Ptf, A_Ptf_ParentPortId); /* PMSTA08801 - DDV - 091126 */
				    break;
			    /*}*/
             }
          }

          /* Increment record number */
          idx++; /* PMSTA08801 - DDV - 091126 */
       }
   }

   /* VST - 27-09-2001 */
   /* Portfolios linked from non enumerated ists */
   /* If the ninth data block has rows */

   if (dataRows[tradConstrIdx2] > 0)
   {

      /* Some allocations */

      if ((getListPtr = ALLOC_DYNST(Adm_Arg)) == NULL)
      {
         MSG_RETURN(RET_MEM_ERR_ALLOC);
      }

      if ((sListPtr = ALLOC_DYNST(S_List)) == NULL)
      {
         FREE_DYNST(getListPtr, Adm_Arg);
         MSG_RETURN(RET_MEM_ERR_ALLOC);
      }

      if ((inputPtr = ALLOC_DYNST(Adm_Arg)) == NULL)
      {
         FREE_DYNST(getListPtr, Adm_Arg);
         FREE_DYNST(sListPtr, S_List);
         MSG_RETURN(RET_MEM_ERR_ALLOC);
      }

   }


   /* For each Strategy Link */
   for (i=0 ; i<dataRows[tradConstrIdx2] ; i++)
   {

      ioIdNbr = 0;

      SET_ID(getListPtr, Adm_Arg_Id, GET_ID(data[tradConstrIdx2][i], A_TradConstr_PortObjId));

      if ((ret = DBA_Get2(List,
                          UNUSED,
                          Adm_Arg,
                          getListPtr,
                          S_List,
                          &sListPtr,
                          UNUSED,
                          UNUSED,
                          UNUSED))!=RET_SUCCEED)
      {
         FREE_DYNST(getListPtr, Adm_Arg);
         FREE_DYNST(sListPtr, S_List);
         FREE_DYNST(inputPtr, Adm_Arg);
         return(RET_DBA_ERR_NODATA);
      }

      listNatEn = (LISTNAT_ENUM) GET_ENUM(sListPtr, S_List_NatEn);

      if (listNatEn != ListNat_Search)   /* PMSTA-46050 - Deepthi - 20240321 */
      {
         SET_NULL_DYNST(inputPtr, Adm_Arg); /* REF8844 - LJE - 030402 */
         DBA_SelectByListId(GET_ID(data[tradConstrIdx2][i], A_TradConstr_PortObjId),
                            Ptf,
                            UNUSED,
                            Adm_Arg,
                            inputPtr,
                            Io_Id,
                            &ioIdTab,
                            UNUSED,
                            UNUSED,
                            &ioIdNbr,
                            NULL);
         if (ioIdNbr == 0 || ioIdTab == NULL)
            continue;

         for (j=0;  j<ioIdNbr; j++)
            for(k=0; k<dataRows[dataPtfIdx]; k++)
               if (GET_ID(data[dataPtfIdx][k], A_Ptf_Id) == GET_ID(ioIdTab[j], Io_Id_Id))
               {
                  /* skip duplicates */
                  found = 0;
                  for(m=0; m<idx; m++) /* PMSTA08801 - DDV - 091126 */
                  {
                     if( (GET_ID(data[dataPtfIdx][k], A_Ptf_Id) == GET_ID(extStratLnkData[m], ExtStratLnk_ObjId))
                        && (GET_ID(data[tradConstrIdx2][i], A_TradConstr_Id) == GET_ID(extStratLnkData[m], ExtStratLnk_TradConstrId)))
                     {
                        found = 1;
                        break;
                     }
                  }
                  if(found)
                     continue;

                  if ((extStratLnkData[idx] = ALLOC_DYNST(ExtStratLnk)) == NULL) /* PMSTA08801 - DDV - 091126 */
                  {
                     return(RET_MEM_ERR_ALLOC);
                  }

                  /* Set values in extended strategy link */
                  COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_TradConstrId, data[tradConstrIdx2][i], A_TradConstr, A_TradConstr_Id);   /* PMSTA08801 - DDV - 091126 */
                  SET_DICT(extStratLnkData[idx],    ExtStratLnk_LnkObjDictId, ptfDictId);                                                             /* PMSTA08801 - DDV - 091126 */
                  COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_ObjId, data[dataPtfIdx][k], A_Ptf, A_Ptf_Id);                            /* PMSTA08801 - DDV - 091126 */
                  COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_BegDate, data[tradConstrIdx2][i], A_TradConstr, A_TradConstr_BeginDate); /* PMSTA08801 - DDV - 091126 */
                  COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_EndDate, data[tradConstrIdx2][i], A_TradConstr, A_TradConstr_EndDate);   /* PMSTA08801 - DDV - 091126 */

				  /* PMSTA07121 - RAK - 090514 */
				  COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_CriticalnessEn, data[tradConstrIdx2][i], A_TradConstr, A_TradConstr_CriticalnessEn); /* PMSTA08801 - DDV - 091126 */

				  SET_ENUM(extStratLnkData[idx],    ExtStratLnk_StratNatEn, StratNat_TradingConstr);                                                  /* PMSTA08801 - DDV - 091126 */
				  SET_ENUM(extStratLnkData[idx],    ExtStratLnk_ConstrNatEn, ESLConstrNat_TradingConstr); /* PMSTA-43081-Badhri-11012021*/
                  SET_FLAG(extStratLnkData[idx],    ExtStratLnk_DirectFlg, TRUE);                                                                     /* PMSTA08801 - DDV - 091126 */
                  /*SET_FLAG(extStratLnkData[idx],    ExtStratLnk_EnumFlg, FALSE);*/                                                                  /* PMSTA08801 - DDV - 091126 */
                  COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_PtfId, data[dataPtfIdx][k], A_Ptf, A_Ptf_Id);                            /* PMSTA08801 - DDV - 091126 */

                  /* set the child portfolio id in extStratLnk */
				 for(m=0; m<dataRows[dataPtfIdx]; m++)
				 {
                     if(GET_ID(extStratLnkData[idx], ExtStratLnk_PtfId) == GET_ID(data[dataPtfIdx][m], A_Ptf_Id)) /* PMSTA08801 - DDV - 091126 */
					 {
						/* PMSTA04614-CHU-071030 : if Check Holding Constraint, Load hier flag must be true */
						if (chkHldgCstrFlg == FALSE || GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None)
						{
							COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_ParentPtfId, data[dataPtfIdx][m], A_Ptf, A_Ptf_ParentPortId); /* PMSTA08801 - DDV - 091126 */
						}
					 }
				 }

                  /* Increment record number */
                  idx++; /* PMSTA08801 - DDV - 091126 */
               }
         DBA_FreeDynStTab(ioIdTab, ioIdNbr, Io_Id);

      }
      else
      {
         for(j=0; j<dataRows[dataPtfIdx]; j++)
         {
            resultFlag = 0;
            SCPT_EvalConstList(GET_ID(data[tradConstrIdx2][i],  A_TradConstr_PortObjId),
                               entObjectEnum,
                               GET_ID(data[dataPtfIdx][j], A_Ptf_Id),
                               data[dataPtfIdx][j], /* REF3853 - 990728 - DDV */
                               NULL,
                               &resultFlag,
                               (DBA_HIER_HEAD_STP) NULL,
                               NULL,  /* REF7411 - LJE - 020806 */
                               NULL,  /* REF7411 - LJE - 020814 */
                               UNUSED,
                               UNUSED);
            if(resultFlag)
            {
               /* skip duplicates */
               found = 0;
               for(m=0; m<idx; m++) /* PMSTA08801 - DDV - 091126 */
               {
                  if( (GET_ID(data[dataPtfIdx][j], A_Ptf_Id) == GET_ID(extStratLnkData[m], ExtStratLnk_ObjId))
                     && (GET_ID(data[tradConstrIdx2][i], A_TradConstr_Id) == GET_ID(extStratLnkData[m], ExtStratLnk_TradConstrId)))
                  {
                     found = 1;
                     break;
                  }
               }
               if(found)
                  continue;

               if ((extStratLnkData[idx] = ALLOC_DYNST(ExtStratLnk)) == NULL) /* PMSTA08801 - DDV - 091126 */
               {
                  return(RET_MEM_ERR_ALLOC);
               }

               /* Set values in extended strategy link */
               COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_TradConstrId, data[tradConstrIdx2][i], A_TradConstr, A_TradConstr_Id);   /* PMSTA08801 - DDV - 091126 */
               SET_DICT(extStratLnkData[idx],    ExtStratLnk_LnkObjDictId, ptfDictId);                                                             /* PMSTA08801 - DDV - 091126 */
               COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_ObjId, data[dataPtfIdx][j], A_Ptf, A_Ptf_Id);                            /* PMSTA08801 - DDV - 091126 */
               COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_BegDate, data[tradConstrIdx2][i], A_TradConstr, A_TradConstr_BeginDate); /* PMSTA08801 - DDV - 091126 */
               COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_EndDate, data[tradConstrIdx2][i], A_TradConstr, A_TradConstr_EndDate);   /* PMSTA08801 - DDV - 091126 */

			   /* PMSTA07121 - RAK - 090514 */
			   COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_CriticalnessEn, data[tradConstrIdx2][i], A_TradConstr, A_TradConstr_CriticalnessEn); /* PMSTA08801 - DDV - 091126 */

               SET_ENUM(extStratLnkData[idx],    ExtStratLnk_StratNatEn, StratNat_TradingConstr);                                                  /* PMSTA08801 - DDV - 091126 */
			   SET_ENUM(extStratLnkData[idx],    ExtStratLnk_ConstrNatEn, ESLConstrNat_TradingConstr); /* PMSTA-43081-Badhri-11012021*/
               SET_FLAG(extStratLnkData[idx],    ExtStratLnk_DirectFlg, TRUE);                                                                     /* PMSTA08801 - DDV - 091126 */
               /*SET_FLAG(extStratLnkData[idx],    ExtStratLnk_EnumFlg, FALSE);*/                                                                  /* PMSTA08801 - DDV - 091126 */
               COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_PtfId, data[dataPtfIdx][j], A_Ptf, A_Ptf_Id);                            /* PMSTA08801 - DDV - 091126 */

               /* set the child portfolio id in extStratLnk */
               if(DBA_ParentInList(GET_ID(data[dataPtfIdx][j], A_Ptf_ParentPortId), data[dataPtfIdx], dataRows[dataPtfIdx]))
			   {
				/* PMSTA04614-CHU-071030 : if Check Holding Constraint, Load hier flag must be true */
				if (chkHldgCstrFlg == FALSE || GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None)
				{
                  COPY_DYNFLD(extStratLnkData[idx], ExtStratLnk, ExtStratLnk_ParentPtfId, data[dataPtfIdx][j], A_Ptf, A_Ptf_ParentPortId); /* PMSTA08801 - DDV - 091126 */
				}
			   }

               /* Increment record number */
               idx++; /* PMSTA08801 - DDV - 091126 */
            }
         }
      }

   }


   FREE_DYNST(getListPtr, Adm_Arg);
   FREE_DYNST(sListPtr, S_List);
   FREE_DYNST(inputPtr, Adm_Arg);

   *p_id = idx; /* PMSTA08801 - DDV - 091126 */

   return RET_SUCCEED;
}



RET_CODE DBA_SelOneSslData(ID_T sslId, DBA_HIER_HEAD_STP stratHierHead, DBA_DYNFLD_STP   domainPtr)
{
    RET_CODE            ret = RET_SUCCEED;
	DBA_DYNFLD_STP		searchLnkSt = NULL;
    int                 connectNo=UNUSED;
    int                 selOptions=UNUSED;
    DICT_T				entDictId;

	if ((searchLnkSt = ALLOC_DYNST(A_SearchLnk)) == NULL)
	{
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "A_SearchLnk");
		return RET_MEM_ERR_ALLOC;
	}


    DBA_GetDictId(Strat, &entDictId);

	SET_DICT(searchLnkSt, A_SearchLnk_DimStratDictId, entDictId);
	SET_ID(searchLnkSt, A_SearchLnk_StratObjId, sslId);
    /* REF9187 - LJE - 030710 */
    if (IS_NULLFLD(domainPtr, A_Domain_InterpStratDate) == FALSE)
    {
        SET_DATE(searchLnkSt, A_SearchLnk_BeginDate, GET_DATETIME(domainPtr, A_Domain_InterpStratDate).date);
    }
    else
    {
        SET_NULL_DATE(searchLnkSt, A_SearchLnk_BeginDate);
    }
    SET_NULL_DATE(searchLnkSt, A_SearchLnk_EndDate);
    SET_ENUM(searchLnkSt, A_SearchLnk_ComplianceMethodEn, complianceMethodEn::Default);
    SET_FLAG(searchLnkSt, A_SearchLnk_DynamicSeverityFlg, FALSE);
    SET_FLAG(searchLnkSt, A_SearchLnk_LoadHierFlg, FALSE);
    SET_FLAG(searchLnkSt, A_SearchLnk_CaseDurationFlg, FALSE);
    
    if ((connectNo = DBA_GetConnection(SqlServer)) == DBA_CONN_NOT_FOUND)
    {
       	FREE_DYNST(searchLnkSt, A_SearchLnk);
		MSG_RETURN(RET_DBA_ERR_CONNOTFOUND);
    }

    /* Create temporary tables   */
    ret = DBA_CreateTempTables(&connectNo, DOM_STRAT | GRID_VECTOR | STRAT_MARKET | DOM_PARENT_STRAT |
                                TMP_STRAT_HIST | STRATEGY | DOM_POSITION_INSTR_PORT | TCT_VECTOR_ID);

    selOptions = DBA_SET_CONN | DBA_NO_CLOSE;

    if (ret == RET_SUCCEED)
    {
		ret = FIN_SelStratDataLoad(searchLnkSt, stratHierHead, selOptions, &connectNo);
    }

	FREE_DYNST(searchLnkSt, A_SearchLnk);	/* PURIFY - RAK - 060810 */
	DBA_EndConnection(connectNo);
	connectNo=UNUSED;
	selOptions=UNUSED;
	return RET_SUCCEED;
}


/************************************************************************
**
**  Function    :   DBA_CmpListById()
**
**  Description :   List table is sort by id,
**
**  Arguments   :   ptr1   pointer on dynamic structure type A_List
**                  ptr2   pointer on dynamic structure type A_List
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation Date        : REF9187 - LJE - 030605
**  Last Modification    :
*************************************************************************/
STATIC int DBA_CmpListById(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    return(CMP_DYNFLD(*ptr1, *ptr2, A_List_Id, A_List_Id, IdType));
}

/************************************************************************
**
**  Function    :   DBA_CmpPtfById()
**
**  Description :   List table is sort by id,
**
**  Arguments   :   ptr1   pointer on dynamic structure type A_Ptf
**                  ptr2   pointer on dynamic structure type A_Ptf
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation Date        : REF9187 - LJE - 030605
**  Last Modification    :
*************************************************************************/
STATIC int DBA_CmpPtfById(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    return(CMP_DYNFLD(*ptr1, *ptr2, A_Ptf_Id, A_Ptf_Id, IdType));
}

/************************************************************************
**
**  Function    :   DBA_CmpListCompoByLidOidDt()
**
**  Description :   ListCompo table is sort by list_id, object_id
**                  and validity date descending
**
**  Arguments   :   ptr1   pointer on dynamic structure type A_ListCompo
**                  ptr2   pointer on dynamic structure type A_ListCompo
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation Date        : REF9187 - LJE - 030605
**  Last Modification    :
*************************************************************************/
STATIC int DBA_CmpListCompoByLidOidDt(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    int cmp;

    if ((cmp = CMP_DYNFLD(*ptr1, *ptr2, A_ListCompo_Id, A_ListCompo_Id, IdType)) != 0)
        return(cmp);

    /* descending */
    if ((cmp = CMP_DYNFLD(*ptr2, *ptr1, A_ListCompo_ValidDt, A_ListCompo_ValidDt, DatetimeType)) != 0)
        return(cmp);

    return(CMP_DYNFLD(*ptr1, *ptr2, A_ListCompo_ObjId, A_ListCompo_ObjId, IdType));

}

/************************************************************************
**
**  Function    :   DBA_CmpStratLinkByOidDt()
**
**  Description :   StrategyLink table is sort by list_id, begin_date
**
**  Arguments   :   ptr1   pointer on dynamic structure type S_StratLnk
**                  ptr2   pointer on dynamic structure type S_StratLnk
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation Date        : REF9187 - LJE - 030605
**  Last Modification    :
*************************************************************************/
STATIC int DBA_CmpStratLinkByOidDt(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    int cmp;

    if ((cmp = CMP_DYNFLD(*ptr1, *ptr2, S_StratLnk_ObjId, S_StratLnk_ObjId, IdType)) != 0)
        return(cmp);

    if ((cmp = CMP_DYNFLD(*ptr1, *ptr2, S_StratLnk_StratId, S_StratLnk_StratId, IdType)) != 0)
        return(cmp);

    /* descending */
    return(CMP_DYNFLD(*ptr2, *ptr1, S_StratLnk_BegDate, S_StratLnk_BegDate, DateType));
}

/************************************************************************
**
**  Function    :   DBA_CmpStratLinkByPtfDts()
**
**  Description :   StrategyLink table is sort by begin_date, end_date
**
**  Arguments   :   ptr1   pointer on dynamic structure type S_StratLnk
**                  ptr2   pointer on dynamic structure type S_StratLnk
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation Date        : REF9187 - LJE - 030605
**  Last Modification    :
*************************************************************************/
STATIC int DBA_CmpStratLinkByPtfDts(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    int cmp;

    /* REF9770 - LJE - 040116 */
    if ((cmp = CMP_DYNFLD(*ptr1, *ptr2, S_StratLnk_PtfId, S_StratLnk_PtfId, IdType)) != 0)
        return(cmp);

    if ((cmp = CMP_DYNFLD(*ptr1, *ptr2, S_StratLnk_BegDate, S_StratLnk_BegDate, DateType)) != 0)
        return(cmp);

    return(CMP_DYNFLD(*ptr1, *ptr2, S_StratLnk_EndDate, S_StratLnk_EndDate, DateType));
}

/************************************************************************
**
**  Function    :   DBA_CmpSLPriority()
**
**  Description :   Extended strategy link table is sort by priority,
**
**  Arguments   :   ptr1   pointer on dynamic structure type ExtPos
**                  ptr2   pointer on dynamic structure type ExtPos
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation Date        : 020919 - DDV - REF7758
**  Last Modification    : REF9264 - LJE - 030709 : Move from dbaperfa.c
*************************************************************************/
STATIC int DBA_CmpSLPriority(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    int cmp;

    if ((cmp = CMP_DYNFLD(*ptr1, *ptr2, S_StratLnk_PtfId, S_StratLnk_PtfId, IdType)) != 0)
        return(cmp);

    /* REF9187 - LJE - 030624 */
    /* for same portfolio, then sort by begin_d (ascending) */
    if ((cmp = CMP_DYNFLD(*ptr1, *ptr2, S_StratLnk_BegDate, S_StratLnk_BegDate, DateType)) != 0)
        return(cmp);

    /* same end_d, then sort by end_d (descending) */
    if ((cmp = CMP_DYNFLD(*ptr2, *ptr1, S_StratLnk_EndDate, S_StratLnk_EndDate, DateType)) != 0)
        return(cmp);

    /* REF1664 - Strategy link nature 'strategy' before all others */
    if ((STRATLNKNAT_ENUM) GET_ENUM((*ptr1), S_StratLnk_LnkNatEn) == StratLnkNat_Strat &&
        (STRATLNKNAT_ENUM) GET_ENUM((*ptr2), S_StratLnk_LnkNatEn) != StratLnkNat_Strat)
        return(-1);

    if ((STRATLNKNAT_ENUM) GET_ENUM((*ptr2), S_StratLnk_LnkNatEn) == StratLnkNat_Strat &&
        (STRATLNKNAT_ENUM) GET_ENUM((*ptr1), S_StratLnk_LnkNatEn) != StratLnkNat_Strat)
        return(1);

    /* Two strategy link nature 'strategy' or  */
    /* two not strategy link nature 'strategy' */
    /* then sort by priority */

    if ((cmp = CMP_DYNFLD(*ptr1, *ptr2, S_StratLnk_Priority, S_StratLnk_Priority, TinyintType)) != 0)
        return(cmp);

    /* same begin_d, sort link by entity. First strat (500) second Ptf (800) then Instr (900) */
    if ((cmp = CMP_DYNFLD(*ptr1, *ptr2, S_StratLnk_ToEntDictId, S_StratLnk_ToEntDictId, DictType)) != 0)
        return(cmp);

    /* same priority, then sort by grid (Entity+Object) */
    if ((cmp = CMP_DYNFLD(*ptr1, *ptr2, S_StratLnk_DimGridDictId, S_StratLnk_DimGridDictId, DictType)) != 0)
        return(cmp);

    if ((cmp = CMP_DYNFLD(*ptr1, *ptr2, S_StratLnk_GridObjId, S_StratLnk_GridObjId, IdType)) != 0)
        return(cmp);

    /* same grid, then sort by strategy id (descending) */
    return(CMP_DYNFLD(*ptr2, *ptr1, S_StratLnk_StratId, S_StratLnk_StratId, IdType));
}

/************************************************************************
**
**  Function    :   DBA_CmpSLPriorityCurrent()
**
**  Description :   Extended strategy link table is sort by priority,
**
**  Arguments   :   ptr1   pointer on dynamic structure type ExtPos
**                  ptr2   pointer on dynamic structure type ExtPos
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation Date        : 020919 - DDV - REF7758
**  Last Modification    : REF9264 - LJE - 030709 : Move from dbaperfa.c
*************************************************************************/
STATIC int DBA_CmpSLPriorityCurrent(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    int cmp;

    if ((cmp = CMP_DYNFLD(*ptr1, *ptr2, S_StratLnk_PtfId, S_StratLnk_PtfId, IdType)) != 0)
        return(cmp);

    /* REF1664 - Strategy link nature 'strategy' before all others */
    if ((STRATLNKNAT_ENUM) GET_ENUM((*ptr1), S_StratLnk_LnkNatEn) == StratLnkNat_Strat &&
        (STRATLNKNAT_ENUM) GET_ENUM((*ptr2), S_StratLnk_LnkNatEn) != StratLnkNat_Strat)
        return(-1);

    if ((STRATLNKNAT_ENUM) GET_ENUM((*ptr2), S_StratLnk_LnkNatEn) == StratLnkNat_Strat &&
        (STRATLNKNAT_ENUM) GET_ENUM((*ptr1), S_StratLnk_LnkNatEn) != StratLnkNat_Strat)
        return(1);

    /* Two strategy link nature 'strategy' or  */
    /* two not strategy link nature 'strategy' */
    /* then sort by priority */

    if ((cmp = CMP_DYNFLD(*ptr1, *ptr2, S_StratLnk_Priority, S_StratLnk_Priority, TinyintType)) != 0)
        return(cmp);

    /* same begin_d, sort link by entity. First strat (500) second Ptf (800) then Instr (900) */
    if ((cmp = CMP_DYNFLD(*ptr1, *ptr2, S_StratLnk_ToEntDictId, S_StratLnk_ToEntDictId, DictType)) != 0)
        return(cmp);

    /* same priority, then sort by grid (Entity+Object) */
    if ((cmp = CMP_DYNFLD(*ptr1, *ptr2, S_StratLnk_DimGridDictId, S_StratLnk_DimGridDictId, DictType)) != 0)
        return(cmp);

    if ((cmp = CMP_DYNFLD(*ptr1, *ptr2, S_StratLnk_GridObjId, S_StratLnk_GridObjId, IdType)) != 0)
        return(cmp);

    /* same grid, then sort by strategy id (descending) */
    return(CMP_DYNFLD(*ptr2, *ptr1, S_StratLnk_StratId, S_StratLnk_StratId, IdType));
}

/************************************************************************
**
**  Function    :   DBA_FilterPtfMC()
**
**  Description :   Suppress model constraint linked to ptfs
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   REF11435 - TEB - 051021
**
*************************************************************************/
STATIC int DBA_FilterPtfMC(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP notUsed)
{
	OBJECT_ENUM	objEn;

	if (IS_NULLFLD(dynSt, A_ModelConstr_DimPortDictId) == FALSE &&
		DBA_GetObjectEnum(GET_DICT(dynSt, A_ModelConstr_DimPortDictId), &objEn) &&
		objEn == Ptf )
	{
		return(TRUE);
	}
	else
	{
		return(FALSE);
	}
}

/************************************************************************
**
**  Function    :   DBA_FilterMCEFromMC()
**
**  Description :   Get model constraint element of model constraint
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   REF11435 - TEB - 051021
**
*************************************************************************/
STATIC int DBA_FilterMCEFromMC(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP filterSt)
{
	if (GET_ID(dynSt, A_ModelConstrElt_ModelConstrId) == GET_ID(filterSt, A_ModelConstr_Id))
		return(TRUE);
	else
		return(FALSE);
}

/************************************************************************
*
*   Function           : DBA_LoadHouseholdFromHeadPtf
*
*   Description        : Get Household through Head Portfolio
*
*   Arguments          :
*
*   Return             : RET_SUCCEED
*
*  Creation Date       : PMSTA-46692 - CHU - 110222
*
*************************************************************************/
RET_CODE DBA_LoadHouseholdFromHeadPtf(DBA_DYNFLD_STP ptfPtr, DBA_DYNFLD_STP *householdPtr)
{
    RET_CODE          ret = RET_SUCCEED;
    DBA_DYNFLD_STP	  getThird = NULL, aThird = NULLDYNST;
    DBA_DYNFLD_STP	  getHH = NULL;
    MemoryPool mp;

    /* 1    if nature_e == 11 (HouseholdHead) */
    if (CMP_ENUM(GET_ENUM(ptfPtr, A_Ptf_NatEn), static_cast<ENUM_T>(PtfNatEn::HouseholdHead)) != 0)
    {
        ret = RET_GEN_INFO_NOACTION;
    }
    else
    {
        /* 2    get third_party record where id == ptf.third_id        */
        getThird = mp.allocDynst(FILEINFO, S_Third);
        if (nullptr == getThird)
        {
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        aThird = mp.allocDynst(FILEINFO, A_Third);
        if (nullptr == aThird)
        {
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        SET_ID(getThird, S_Third_Id, GET_ID(ptfPtr, A_Ptf_ThirdId));
        if ((ret = DBA_Get2(Third, UNUSED, S_Third, getThird, A_Third, &aThird, UNUSED, UNUSED, UNUSED)) != RET_SUCCEED)
        {
            ret = RET_GEN_ERR_INVARG;
            return(ret);
        }

        /* 3  get HH record where household_head_id == third_id        */
        getHH = mp.allocDynst(FILEINFO, Adm_Arg);
        if (nullptr == getHH)
        {
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        /* Set Adm_Arg_Id from third_party:    get_all_household_by_tid */
        /* Set Adm_Arg_CodifId from portfolio: get_all_household_by_pid */
        SET_ID(getHH, Adm_Arg_Id, GET_ID(aThird, A_Third_Id));
        if ((ret = DBA_Get2(Household, UNUSED, Adm_Arg, getHH, A_Household, householdPtr, UNUSED, UNUSED, UNUSED)) != RET_SUCCEED)
        {
            ret = RET_GEN_ERR_INVARG;
            return(ret);
        }

        if (TRUE == IS_NULLFLD(*householdPtr, A_Household_HouseholdListId))
        {
            /* Household has no Portfolio List defined */
            FREE_DYNST(*householdPtr, A_Household);
            ret = RET_GEN_INFO_NOACTION;
        }
    }

    return(ret);
}

/************************************************************************
*
*   Function           : FIN_CopyAllHierElem
*
*   Description        : Copy All Hier Element from srcHier to destHier
*
*   Arguments          :
*
*   Return             : RET_SUCCEED
*
*  Creation Date       : PMSTA-46692 - CHU - 020322
*
*************************************************************************/
STATIC RET_CODE FIN_CopyAllHierElem(DBA_HIER_HEAD_STP srcHier,
                                    DBA_HIER_HEAD_STP destHier)
{
    RET_CODE        ret     = RET_SUCCEED;
    int             recNbr  = 0;
    DBA_DYNFLD_STP *recTab  = nullptr;
    DBA_DYNFLD_STP *copyRecTab = nullptr;
    MemoryPool      mp;

    for (auto &it : srcHier->hierEltByDynStMap)
    {
        if (it.second == nullptr || it.first == A_Domain)
        {
            continue;
        }

        /* extract with copy flag set to TRUE */
        if ((ret = DBA_ExtractHierEltRec(srcHier, it.first, TRUE, NULLFCT, NULLFCT, &recNbr, &recTab)) != RET_SUCCEED)
        {
            ret = RET_DBA_ERR_HIER;
            return(ret);
        }
        mp.owner(recTab);

        copyRecTab = (DBA_DYNFLD_STP *)CALLOC(recNbr, sizeof(DBA_DYNFLD_STP));
        mp.owner(copyRecTab);
        for (int cpIdx = 0; cpIdx < recNbr; cpIdx++)
        {
            copyRecTab[cpIdx] = ALLOC_DYNST(it.first);
            COPY_DYNST(copyRecTab[cpIdx], recTab[cpIdx], it.first);
        }

        /* add records in new hier */
        if (recNbr > 0)
        {
            if ((ret = DBA_AddHierRecordList(destHier, copyRecTab, recNbr, it.first, FALSE)) != RET_SUCCEED)
            {
                ret = RET_DBA_ERR_HIER;
                return(ret);
            }
        }

        recNbr = 0;
    }

    return ret;
}

/*****************************************************************/
/* Manage Household Portfolio Lists - PMSTA-46692 - CHU - 110222 */
/*****************************************************************/
RET_CODE DBA_ManageHouseholdFromPtfs(DBA_HIER_HEAD_STP hierStp,
                                     DBA_DYNFLD_STP    domainPtr)
{
    RET_CODE                ret = RET_SUCCEED;
    MemoryPool              mp;
    DBA_DYNFLD_STP          householdPtr = nullptr, tmpDomainPtr = nullptr;
    DICT_T                  listDictId, ptfDictId;
    DBA_HIER_HEAD_STP       hh_HierHead = nullptr;
    ID_T                   *ptfIdTab = nullptr;
    int					    ptfIdNbr = 0;
    DBA_DYNFLD_STP          *inPtfTab = nullptr;
    int					    inPtfNbr = 0;
    MODELCONSTRVALID_ENUM   modelConstrValidEn = ModelConstrValid_Actif;

    if (nullptr == hierStp || nullptr == domainPtr)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 0, FILEINFO);
        return(ret);
    }

    if ((ret = DBA_ExtractHierEltRec((DBA_HIER_HEAD_STP)hierStp,
                                     A_Ptf,
                                     FALSE,
                                     NULLFCT,
                                     NULLFCT,
                                     &inPtfNbr,
                                     &inPtfTab)) != RET_SUCCEED || inPtfNbr == 0)
    {
        ret = RET_DBA_ERR_HIER;
        return ret;
    }

    for (int i = 0; i < (inPtfNbr); i++)
    {
        if (CMP_ENUM(GET_ENUM(inPtfTab[i], A_Ptf_NatEn), static_cast<ENUM_T>(PtfNatEn::HouseholdHead)) == 0)
        {
            householdPtr = ALLOC_DYNST(A_Household);
            if (nullptr == householdPtr)
            {
                MSG_RETURN(RET_MEM_ERR_ALLOC);
            }

            /* Get household record(s) from portfolio(s) */
            ret = DBA_LoadHouseholdFromHeadPtf(inPtfTab[i], &householdPtr);
            if (RET_GEN_INFO_NOACTION == ret)
            {
                FREE_DYNST(householdPtr, A_Household);
                continue;
            }

            /*  If asked, store all records into hierarchy */
            if (nullptr != hierStp)
            {
                if ((ret = DBA_AddHierRecord(hierStp, householdPtr, A_Household, TRUE, HierAddRec_TestMandatLnk)) != RET_SUCCEED)
                {
                    FREE_DYNST(householdPtr, A_Household);
                    return(ret);
                }
            }

            /* Get household List from household(s) */
            if ((tmpDomainPtr = ALLOC_DYNST(A_Domain)) == NULLDYNST)
            {
                MSG_RETURN(RET_MEM_ERR_ALLOC);
            }

            COPY_DYNST(tmpDomainPtr, domainPtr, A_Domain);

            DBA_GetDictId(List, &listDictId);
            SET_DICT(tmpDomainPtr, A_Domain_DimPtfDictId, listDictId);
            SET_ID(tmpDomainPtr, A_Domain_PtfObjId, GET_ID(householdPtr, A_Household_HouseholdListId));

            SET_NULL_ID(tmpDomainPtr, A_Domain_InstrObjId);
            SET_NULL_DICT(tmpDomainPtr, A_Domain_DimInstrDictId);

            SET_DICT(tmpDomainPtr, A_Domain_InitialFctDictId, GET_DICT(tmpDomainPtr, A_Domain_FctDictId));

            /* Load Strat Data into temporary hierarchy */
            hh_HierHead = DBA_CreateHier();
            ret = DBA_SelCheckStratData(tmpDomainPtr, hh_HierHead, &ptfIdTab, &ptfIdNbr, modelConstrValidEn);

            DBA_DYNFLD_STP          *subPtfTab = nullptr;
            int					    subPtfNbr = 0;

            DBA_DYNFLD_STP          *subESLTab = nullptr;
            int					    subESLNbr = 0;

            /* Get portfolios loaded from Household list */
            if ((ret = DBA_ExtractHierEltRec((DBA_HIER_HEAD_STP)hh_HierHead,
                                             A_Ptf,
                                             FALSE,
                                             NULLFCT,
                                             NULLFCT,
                                             &subPtfNbr,
                                             &subPtfTab)) != RET_SUCCEED || inPtfNbr == 0)
            {
                ret = RET_DBA_ERR_HIER;
                return ret;
            }

            /* Set parent & hier_ptf to top portfolio */
            for (int ptfIdx = 0; ptfIdx < subPtfNbr; ptfIdx++)
            {
                SET_ID(subPtfTab[ptfIdx], A_Ptf_ParentPortId, GET_ID(householdPtr, A_Household_HouseholdHeadPtfId));
                SET_ID(subPtfTab[ptfIdx], A_Ptf_HierPortId, GET_ID(householdPtr, A_Household_HouseholdHeadPtfId));
            }

            /* Get strategy links from Household list(s) */
            if ((ret = DBA_ExtractHierEltRec((DBA_HIER_HEAD_STP)hh_HierHead,
                                             ExtStratLnk,
                                             FALSE,
                                             NULLFCT,
                                             NULLFCT,
                                             &subESLNbr,
                                             &subESLTab)) != RET_SUCCEED || inPtfNbr == 0)
            {
                ret = RET_DBA_ERR_HIER;
                return ret;
            }

            /* Set strategy links list_id to NULL */
            /* Set List strategy links to top portfolio */
            DBA_GetDictId(Ptf, &ptfDictId);
            for (int eslIdx = 0; eslIdx < subESLNbr; eslIdx++)
            {
                if (CMP_ID(GET_ID(subESLTab[eslIdx], ExtStratLnk_ListId), GET_ID(householdPtr, A_Household_HouseholdListId)) == 0)
                {
                    SET_NULL_ID(subESLTab[eslIdx], ExtStratLnk_ListId);
                    SET_DICT(subESLTab[eslIdx], ExtStratLnk_LnkObjDictId, ptfDictId);
                    SET_ID(subESLTab[eslIdx], ExtStratLnk_ObjId, GET_ID(householdPtr, A_Household_HouseholdHeadPtfId));
                }
            }
           
            /* Transfer all records into main hierarchy */
            FIN_CopyAllHierElem(hh_HierHead, hierStp);

            DBA_FreeHier(hh_HierHead);
        }
    }

    /* Set Household extension links */
    if ((ret = DBA_SetHierLnkUsed(hierStp, A_Household, A_Household_A_HeadPtf_Ext)) != RET_SUCCEED)
    {
        MSG_SendMesg(RET_DBA_ERR_HIER, 0, FILEINFO);
        return(ret);
    }

    if ((ret = DBA_SetHierLnkUsed(hierStp, A_Household, A_Household_A_List_Ext)) != RET_SUCCEED)
    {
        MSG_SendMesg(RET_DBA_ERR_HIER, 0, FILEINFO);
        return(ret);
    }

    if ((ret = DBA_SetHierLnkUsed(hierStp, A_Household, A_Household_A_Third_Ext)) != RET_SUCCEED)
    {
        MSG_SendMesg(RET_DBA_ERR_HIER, 0, FILEINFO);
        return(ret);
    }

    /* Make all links */
    if (DBA_MakeLinks(hierStp) != RET_SUCCEED)
    {
        MSG_SendMesg(RET_DBA_ERR_HIER, 0, FILEINFO);
        return(ret);
    }

    return(ret);
};

/************************************************************************
*   Function             : FIN_FilterHierIndvMCE()
*
*   Description          : Select all Hierarchy Individual Constraints
*                           for a given Constraint Nature(SecIn/SecOut/ModTrad)
*
*   Arguments            :
*
*   Return               : RET_SUCCEED or error code
*
*   Creation Date        : PMSTA-48867-Satya
*
*************************************************************************/
STATIC int FIN_FilterHierIndvMCE(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP dynFilt)
{
    if(CMP_DYNFLD(dynSt, dynFilt, A_ModelConstrElt_ApplicationScopeEn, A_ModelConstrElt_ApplicationScopeEn, EnumType) == 0)
        return true;
    else
        return false;
}

/************************************************************************
*   Function             : FIN_CreateDummyMCRecord()
*
*   Description          : Create Model constraint Records For
*                            Hierarchy Individual Constraints
*
*   Arguments            :
*
*   Return               : RET_SUCCEED or error code
*
*   Creation Date        : PMSTA-48867-Satya
*
*************************************************************************/
static RET_CODE FIN_CreateDummyMCRecord(DBA_DYNFLD_STP	  domainPtr,
                                        DBA_HIER_HEAD_STP   stratHierHead,
                                        int MCNbr,
                                        DBA_DYNFLD_STP *MCTab,
                                        int MCENbr,
                                        DBA_DYNFLD_STP *MCETab,
                                        int PTFNbr,
                                        DBA_DYNFLD_STP *PTFTab)
{

    MODELCONSTRNAT_ENUM cnstrNatEn = ModelConstr_All;
    ID_T OrigModCnstrId = ZERO_ID, hierPtfId = ZERO_ID;;
    /*LOADHIERPTF_ENUM Domain_LoadHierFlg = (LOADHIERPTF_ENUM)GET_ENUM(domainPtr, A_Domain_LoadHierFlg);*/
    MemoryPool mp;    
    DBA_DYNFLD_STP *sChildPtfTab = NULLDYNSTPTR;
    int sChildPtfNb = 0;
    RET_CODE ret = RET_SUCCEED;
    bool sameHierMc = false, samePtfMc = false, constrExists = false;;

    DBA_DYNFLD_STP ioId = mp.allocDynst(FILEINFO, Io_Id);
    DbiConnectionHelper connHelper;
    if (!connHelper.isValidAndInit())
    {
        MSG_SendMesg(FILEINFO, "FIN_CreateDummyMCRecord : connection not valid / init ");
        return RET_DBA_ERR_CONNOTFOUND;
    }

    for (int k = 0; k < MCENbr; k++)
    {
        for (int ptf = 0; ptf < PTFNbr; ptf++)
        {
            hierPtfId = ZERO_ID;

            if (IS_NULLFLD(PTFTab[ptf], A_Ptf_HierHeadPtf))
                hierPtfId = GET_ID(PTFTab[ptf], A_Ptf_Id);
            else
                hierPtfId = GET_ID(PTFTab[ptf], A_Ptf_HierHeadPtf);

            if (GET_ID(MCETab[k], A_ModelConstrElt_HierHeadPtfId) != hierPtfId)
                continue;

            sameHierMc = false, samePtfMc = false;

            if (!sameHierMc &&
                (GET_ID(MCETab[k], A_ModelConstrElt_HierHeadPtfId) == hierPtfId))
            {
                /*model constraint exist in same hier*/
                sameHierMc = true;
                cnstrNatEn = static_cast<MODELCONSTRNAT_ENUM>(GET_ENUM(MCETab[k], A_ModelConstrElt_ConstrNatEn));
                OrigModCnstrId = GET_ID(MCETab[k], A_ModelConstrElt_ModelConstrId);
            }

            if (!samePtfMc &&
                (CMP_DYNFLD(MCETab[k], PTFTab[ptf], A_ModelConstrElt_ptfId, A_Ptf_Id, IdType) == 0))
            {
                /*model constraint exist in same hier*/
                samePtfMc = true;
            }

            if (sameHierMc && !samePtfMc)
            {
                constrExists = false;
                for (int MCcnt = 0; MCcnt < MCNbr; MCcnt++)
                {
                    if (CMP_DYNFLD(MCTab[MCcnt], PTFTab[ptf], A_ModelConstr_PtfId, A_Ptf_Id, IdType) == 0 &&
                        cnstrNatEn == GET_ENUM(MCTab[MCcnt], A_ModelConstr_NatEn))
                        constrExists = true;
                }

                if (constrExists == true)
                    continue;

                /*if input portfolio doesnot have MC but there is hierracy level MC applicable then create a dummy ptf*/
                DBA_DYNFLD_STP dummyMCrec = NULLDYNSTPTR;
                if ((dummyMCrec = ALLOC_DYNST(A_ModelConstr)) == NULLDYNST)
                {
                    MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "A_ModelConstr");
                    return(RET_MEM_ERR_ALLOC);
                }

                SET_ENUM(dummyMCrec, A_ModelConstr_NatEn, cnstrNatEn);
                SET_DICT(dummyMCrec, A_ModelConstr_DimPortDictId, PtfCst);

                SET_ID(dummyMCrec, A_ModelConstr_PtfId, GET_ID(PTFTab[ptf], A_Ptf_Id));
                SET_ID(dummyMCrec, A_ModelConstr_PortObjId, GET_ID(PTFTab[ptf], A_Ptf_Id));
                SET_ID(dummyMCrec, A_ModelConstr_HierHeadPtfId, GET_ID(PTFTab[ptf], A_Ptf_HierHeadPtf));
                SET_ID(dummyMCrec, A_ModelConstr_OriginalModelConstrId, OrigModCnstrId);
                SET_ID(dummyMCrec, A_ModelConstr_OriginalModelConstrEltId, GET_ID(MCETab[k], A_ModelConstrElt_Id));

                /*get child PTF number to check if standalone ptf or not*/
                SET_ID(ioId, Io_Id_Id, GET_ID(PTFTab[ptf], A_Ptf_Id));

                /* sel_sh_portfolio_by_parent */
                sChildPtfTab = NULLDYNSTPTR;
                if ((ret = connHelper.dbaSelect(Ptf, UNUSED, ioId, S_Ptf, &sChildPtfTab, &sChildPtfNb)) != RET_SUCCEED)
                {
                    MSG_SendMesg(FILEINFO, "FIN_OverlayLoadData : Select failed");
                    DBA_FreeDynStTab(sChildPtfTab, sChildPtfNb, S_Ptf);
                    return ret;
                }
                DBA_FreeDynStTab(sChildPtfTab, sChildPtfNb, S_Ptf);
                SET_INT(dummyMCrec, A_ModelConstr_ChildPtfNos, sChildPtfNb);

                if ((ret = DBA_AddHierRecord(stratHierHead,
                    dummyMCrec, A_ModelConstr, FALSE, HierAddRec_NoLnk)) != RET_SUCCEED)
                {
                    FREE_DYNST(dummyMCrec, A_ModelConstr);
                    return(RET_DBA_ERR_HIER);
                }
            }
        }
    }
    return RET_SUCCEED;
}

/************************************************************************
*   Function             : FIN_CreateMCForHierConstr()
*
*   Description          : Create Model constraint Records For 
*                            Hierarchy Individual Constraints
*
*   Arguments            :
*
*   Return               : RET_SUCCEED or error code
*
*   Creation Date        : PMSTA-48867-Satya
*
*************************************************************************/
static RET_CODE FIN_CreateMCForHierConstr(DBA_DYNFLD_STP	  domainPtr,
                                            DBA_HIER_HEAD_STP   stratHierHead)
{
    RET_CODE            ret = RET_SUCCEED;
    FLAG_T              hierConstrUsed = 0;
    MemoryPool          mp;
    DBA_DYNFLD_STP      *MCTab = NULLDYNSTPTR,
                        *MCETab = NULLDYNSTPTR,
                        *PTFTab = NULLDYNSTPTR;

    int MCNbr = 0, MCENbr = 0, PTFNbr = 0;

    GEN_GetApplInfo(ApplHierConstraintUsed, &hierConstrUsed);
    if (hierConstrUsed == 0)
        return ret;

    if ((ret = DBA_ExtractHierEltRec((DBA_HIER_HEAD_STP)stratHierHead,
        A_ModelConstr,
        FALSE,
        NULLFCT,
        NULLFCT,
        &MCNbr,
        &MCTab)) != RET_SUCCEED)
    {
        free(MCTab);
        MSG_LogMesg(ret, 1, FILEINFO, "FIN_SetAddDetailsinMC: Unable to extract A_ModelConstr Operation from hierarchy");
        return ret;
    }

    if (MCNbr == 0)
        return RET_SUCCEED;
    else if (MCNbr > 0)
        mp.ownerPtr(MCTab);

    if ((ret = DBA_ExtractHierEltRec((DBA_HIER_HEAD_STP)stratHierHead,
        A_Ptf,
        FALSE,
        NULLFCT,
        NULLFCT,
        &PTFNbr,
        &PTFTab)) != RET_SUCCEED)
    {
        free(PTFTab);
        MSG_LogMesg(ret, 1, FILEINFO, "FIN_SetAddDetailsinMC: Unable to extract A_Ptf Operation from hierarchy");
        return ret;
    }

    if (PTFNbr == 0)
        return RET_SUCCEED;
    else if (PTFNbr > 0)
        mp.ownerPtr(PTFTab);
    
    DBA_DYNFLD_STP     mceInputSt = mp.allocDynst(FILEINFO, A_ModelConstrElt);

    SET_ENUM(mceInputSt, A_ModelConstrElt_ConstrNatEn, ModelConstr_SecurityInConstr);
    SET_ENUM(mceInputSt, A_ModelConstrElt_ApplicationScopeEn, StratApplicationScopeEn::HierarchyIndividual);

    if ((ret = DBA_ExtractHierEltRecWithFilterSt(stratHierHead,
        A_ModelConstrElt,
        FALSE,
        FIN_FilterHierIndvMCE,
        mceInputSt,
        NULLFCT,
        &MCENbr,
        &MCETab)) != RET_SUCCEED)
    {
        free(MCETab);
        MSG_LogMesg(ret, 1, FILEINFO, "FIN_CreateMCForHierConstr: Unable to extract A_ModelConstrElt from hierarchy.");
        return ret;
    }

    if (MCENbr == 0)
        return RET_SUCCEED;
    else if (MCENbr > 0)
        mp.ownerPtr(MCETab);

    if ((ret = FIN_CreateDummyMCRecord(domainPtr, stratHierHead, MCNbr, MCTab, MCENbr, MCETab, PTFNbr, PTFTab)) != RET_SUCCEED)
    {
        MSG_LogMesg(ret, 1, FILEINFO, "FIN_CreateMCForHierConstr: Unable to Create Model Constraint Record for Hier Individual Constraint.");
        return ret;
    }

    return ret;
}
/*************************************************************************
**   END  dbaserv.c                                            UNICIBLE **
*************************************************************************/

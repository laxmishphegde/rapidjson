/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DBAEXEC_C

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define MATH_H
#define TIME_H
#define STDLIB_H

#include "unidef.h"
#include "gen.h"
#include "conv.h"
#include "dba.h"
#include "ope.h"
#include "proc.h"
#include "date.h"
#include "cmp.h"
#include "hier.h"
#include "scptyl.h"
#include "fin.h"
#include "dbaexec.h"
#include "taxlotprocess.h"

/************************************************************************
**      External entry points
**
** DBA_LoadOrderExecAndFeeByPtf Load all order, executions and globalFee for a portfolio
**
** DBA_SplitExtOpBlock          Split and filter all ExtOp (from ext_order, execution and global_execution_fee tables).
**                              Filter is based on instrument dimension define in Domain.
**                              Op/Pos/BalPos are inserted according to function parameters
**
** DBA_LoadPPSForDomain         Load all Portfolio position Set (PPS)
**                              matching the domain definition for one portfolio
**
** DBA_CheckPPSDim              Check if Portfolio position Set (PPS)
**                              is include for domain PPS parameters
**                              This function is based on stored proc ini_exd_position_by_pps
**
**
*************************************************************************/


/************************************************************************
**      Local functions
**
** DBA_SplitExtOp               Split and filter all ExtOp (from ext_order, execution and global_execution_fee tables).
**                              Filter is based on instrument dimension define in Domain.
**                              Op/Pos/BalPos are inserted according to function parameters
**
*************************************************************************/

/************************************************************************
**      Static definitions & data
*************************************************************************/

STATIC RET_CODE DBA_SplitExtOp(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, FLAG_T, FLAG_T, FLAG_T, FLAG_T, FLAG_T, DBA_DYNFLD_STP **, int *, DBA_DYNFLD_STP **, int *, DBA_DYNFLD_STP *, int, int *);

STATIC int FIN_CmpExtOpDbId(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *),
           FIN_CmpExtOpOrderId(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *);

/************************************************************************
**      FONCTIONS
************************************************************************/


/************************************************************************
**
**  Function    :   DBA_LoadOrderExecAndFeeByPtf()
**
**  Description :   Load all order, executions and globalFee for a portfolio
**
**  Arguments   :   getArg       Input structure
**                  outputStLst  Definition of Entity returned,
**                  data         Array used to store result of multiselect
**                  rows         Array with the number of records for each block
**                  connectNo    Connection to used
**                  selOptions   Option for select
**
**  Return      :   RET_CODE
**
**
**
**  Creation    :   REF7650 - DDV - 020815
**  Modif       :
*************************************************************************/
EXTERN RET_CODE DBA_LoadOrderExecAndFeeByPtf(DBA_DYNFLD_STP    getArg,
                                             DBA_DYNFLD_STP    **extPosTab,
                                             int               *extPosNbr,
                                             int               *connectNoParam,
                                             DBA_HIER_HEAD_STP hierHead)
{
    const DBA_DYNST_ENUM *outputStLst[] = {&ExtOp, &ExtOp, &ExtOp};
	int             outputBlkNb = 3;
	DBA_DYNFLD_STP  *data[3]={NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR};
	int             rows[3] = {0,0,0};
    RET_CODE        ret=RET_SUCCEED;
    int             i;
    int             connectNo;
    DICT_ENTITY_STP dictEntity;
	DBA_DYNFLD_STP  domainPtr=NULLDYNST;
    FLAG_T          checkInstrDimFlg = FALSE;

    if (*connectNoParam == NO_VALUE)
    {
    	if ((connectNo = DBA_GetConnection(SqlServer)) == DBA_CONN_NOT_FOUND)
        {
            MSG_SendMesg(RET_DBA_ERR_NOFREESYNCCONN, 0, FILEINFO);
            return(DBA_CONN_NOT_FOUND);
        }
    }
    else
        connectNo = *connectNoParam;

    ret = DBA_CreateTempTables(&connectNo, DOM_POSITION_INSTR_PORT | TCT_VECTOR_ID);

	if (ret != RET_SUCCEED)
    {
        if (*connectNoParam == NO_VALUE) {DBA_EndConnection(connectNo);}
	    return ret;
    }

    if (DBA_MultiSelect2(EOp,
                         UNUSED,
                         Get_Arg,
                         getArg,
					     outputStLst,
                         data,
		        	     DBA_SET_CONN|DBA_NO_CLOSE,
					     UNUSED,
                         rows,
                         &connectNo,
                         UNUSED) != RET_SUCCEED)
	{

		MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_MultiSelect failed ... Retry ...");

		if ((ret = DBA_MultiSelect2(EOp,
                                    UNUSED,
                                    Get_Arg,
                                    getArg,
                                    outputStLst,
                                    data,
                                    DBA_SET_CONN|DBA_NO_CLOSE,
                                    UNUSED,
                                    rows,
                                    &connectNo,
                                    UNUSED)) != RET_SUCCEED)
		{
			MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO,
					"DBA_MultiSelect failed again");
            if (DBA_CreateTempTables(
                    &connectNo, DOM_POSITION_INSTR_PORT | TCT_VECTOR_ID) != RET_SUCCEED)
			    MSG_LogMesg(
                    RET_GEN_ERR_PERSONAL, 1, FILEINFO,
					    "DBA_CreateTempTables failed");
            if (*connectNoParam == NO_VALUE) {DBA_EndConnection(connectNo);}
			return(ret);
		}
	}

    /* PMSTA12956 - DDV - 111214 - If excution and execution_fee must not be used, free second anf thrid block */
    if (GET_ENUM(getArg, Get_Arg_Enum1) == SelExtPos_NoExecution)
    {
        DBA_FreeDynStTab(data[1], rows[1], *(outputStLst[1]));
        data[1]=NULLDYNSTPTR;
        rows[1]=0;

        DBA_FreeDynStTab(data[2], rows[2], *(outputStLst[2]));
        data[2]=NULLDYNSTPTR;
        rows[2]=0;

    }

    /* alloc a domain, and use it for split function */
	if ((domainPtr = ALLOC_DYNST(A_Domain)) == NULLDYNST)
	{
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);

        for (i=0; i<outputBlkNb; i++)
            DBA_FreeDynStTab(data[i], rows[i], *(outputStLst[i])); /* REF8844 - LJE - 030423 */
        if (DBA_CreateTempTables(
                &connectNo, DOM_POSITION_INSTR_PORT | TCT_VECTOR_ID) != RET_SUCCEED)
	        MSG_LogMesg(
                RET_GEN_ERR_PERSONAL, 1, FILEINFO,
			        "DBA_CreateTempTables failed");
        if (*connectNoParam == NO_VALUE) {DBA_EndConnection(connectNo);}
		return(RET_MEM_ERR_ALLOC);
	}

    /* set portfolio dimension and object */
    dictEntity = (DICT_ENTITY_STP)DBA_GetDictEntitySt(Ptf);
    SET_DICT(domainPtr, A_Domain_DimPtfDictId, dictEntity->entDictId);
    COPY_DYNFLD(domainPtr, A_Domain, A_Domain_PtfObjId,
                getArg,    Get_Arg,  Get_Arg_Id);

    /* set instrument dimension and object */
    dictEntity = (DICT_ENTITY_STP)DBA_GetDictEntitySt(Instr);
    SET_DICT(domainPtr, A_Domain_DimInstrDictId, dictEntity->entDictId);
    COPY_DYNFLD(domainPtr, A_Domain, A_Domain_InstrObjId,
                getArg,    Get_Arg,  Get_Arg_ObjId);

    /* PMSTA00201 - TGU - 061019 - If instr_id is NULL, set instrument dimension to NULL */
    if (IS_NULLFLD(getArg, Get_Arg_ObjId) == FALSE)
    {
        dictEntity = (DICT_ENTITY_STP)DBA_GetDictEntitySt(Instr);
        SET_DICT(domainPtr, A_Domain_DimInstrDictId, dictEntity->entDictId);
        COPY_DYNFLD(domainPtr, A_Domain, A_Domain_InstrObjId,
                    getArg,    Get_Arg,  Get_Arg_ObjId);
        checkInstrDimFlg = TRUE;
    }
    else
    {
        SET_DICT(domainPtr, A_Domain_DimInstrDictId, NullEntity);
        checkInstrDimFlg = FALSE;
    }

    bool     bExecuteDV = GET_FLAG(getArg, Get_Arg_Flag2) == FALSE;  /* PMSTA-60007 - DDV - 249926 - Execute DV only if updateOnylQuantityOrder param is FALSE */
    if ((ret= DBA_SplitExtOpBlock(A_Domain, domainPtr, hierHead,
                                  outputBlkNb, data, rows, outputStLst,
                                  FALSE, TRUE, FALSE, TRUE, checkInstrDimFlg, FALSE,
                                  (DBA_DYNFLD_STP **) NULL, NULL,
                                  extPosTab, extPosNbr, NULLDYNSTPTR, 0, &connectNo, bExecuteDV)) != RET_SUCCEED) /* PMSTA-53814 - AAKASH - 2023-08-07 :  Connection not re-used between script keyword SEL_EXTPOS and the filtering of DBA_SplitExtOpBlock */
    {
        if (DBA_CreateTempTables(
                &connectNo, DOM_POSITION_INSTR_PORT | TCT_VECTOR_ID) != RET_SUCCEED)
	        MSG_LogMesg(
                RET_GEN_ERR_PERSONAL, 1, FILEINFO,
			        "DBA_CreateTempTables failed");
        if (*connectNoParam == NO_VALUE) {DBA_EndConnection(connectNo);}
        return(ret);
    }

    if ((ret = DBA_CreateTempTables(
            &connectNo, DOM_POSITION_INSTR_PORT | TCT_VECTOR_ID)) != RET_SUCCEED)
	    MSG_LogMesg(
            RET_GEN_ERR_PERSONAL, 1, FILEINFO,
			    "DBA_CreateTempTables failed");
    if (*connectNoParam == NO_VALUE) {DBA_EndConnection(connectNo);}

    FREE_DYNST(domainPtr, A_Domain);
    return(ret);
}

/************************************************************************
**  Function             :  DBA_ExtOpToTaxLot()
**
**  Description          :  Convert extended order to tax lot.
**
**  Arguments            :  domainPtr   pointer to doamin
**                          hierHead	pointer on hierarchy header pointer
**			                extOpPtr    pounter to ext order
**			                taxLotTab   pointer to tax lot record array
**                          taxLotNbr   number of tax lot records
**
**  Return               :  RET_SUCCEED or error code
**
**  Creation 		     :  PMSTA-34116 - 220219 - vkumar
**
**  Modif.               :
*************************************************************************/
RET_CODE DBA_ExtOpToTaxLot( DBA_DYNFLD_STP        domainPtr,
	                        DBA_HIER_HEAD_STP     hierHead,
	                        DBA_DYNFLD_STP        extOpPtr,
	                        DBA_DYNFLD_STP        **taxLotTab,
	                        int                   *taxLotNbr)
{
	RET_CODE        ret = RET_SUCCEED;
    FLAG_T sleeveMAnagedInBO = FALSE;
    GEN_GetApplInfo(ApplTaxlotSleeveInBO, &sleeveMAnagedInBO);

	if (DBA_IsRejectedOrder(extOpPtr) == TRUE)
	{
		return(ret);
	}

	/* Allocate tax lot */
    MemoryPool      mp;
    DBA_DYNFLD_STP  taxLot = NULLDYNST;

	taxLot = mp.allocDynst(FILEINFO, A_TaxLot);

	TaxLotLog taxLotLog(taxLot);

	/* Populate tax lot record */
	ret = createTaxLotFromExtOp(hierHead, extOpPtr, taxLot, ORDER_ENUM::Order, GET_ID(domainPtr, A_Domain_FctResultId), sleeveMAnagedInBO);

	if (RET_SUCCEED == ret && false == taxLotLog.empty())
	{
		/* Insert tax lot into array */
		if (*taxLotNbr % 100 == 0)
		{
            DBA_DYNFLD_STP * tmpTaxLotTab = nullptr;

            if (*taxLotNbr == 0)
			{
				tmpTaxLotTab = static_cast<DBA_DYNFLD_STP *>(CALLOC(100, sizeof(DBA_DYNFLD_STP *)));
			}
			else
			{
				tmpTaxLotTab = static_cast<DBA_DYNFLD_STP *>(REALLOC(*taxLotTab, (*taxLotNbr + 100) * sizeof(DBA_DYNFLD_STP *)));
			}

			if (tmpTaxLotTab == NULLDYNSTPTR)
			{
				MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
				return(RET_MEM_ERR_ALLOC);
			}

            *taxLotTab = tmpTaxLotTab;
		}
		(*taxLotTab)[*taxLotNbr] = taxLot;
		(*taxLotNbr)++;
        mp.remove(taxLot);
	}

	return ret;
}

/************************************************************************
**  Function             :  DBA_SplitExtOpBlock()
**
**  Description          :  Split and filter all ExtOp (from ext_order, execution and global_execution_fee tables).
**                          Filter is based on instrument dimension define in Domain.
**                          Op/Pos/BalPos are inserted according to function parameters
**
**  Arguments            :  hierHeadPtr	pointer on hierarchy header pointer
**			                hierDefNbr   hierarchy definition number
**			                outputMatch  pointer on hierarchy element array
**                          outputBlkNb  number of hierarchy element
**                          data		pointer on record array to insert
**                          rows         record number on array
**                          outputStLst  record dynamic structure type
**
**  Return               :  RET_SUCCEED or error code
**
**  Creation 		     :  REF7560 - DDV - 020613 - Create ExtPos for orders abd executions.
**                          PMSTA00469 - DDV - 061026 - Add PtfTab to check dimension.
**
**  Modif.               : PMSTA-53814 - AAKASH - 2023-08-07 :  Connection not re-used between script keyword SEL_EXTPOS and the filtering of DBA_SplitExtOpBlock
*************************************************************************/
EXTERN RET_CODE DBA_SplitExtOpBlock(DBA_DYNST_ENUM       inputSt,
                                    DBA_DYNFLD_STP       domainPtr,
                                    DBA_HIER_HEAD_STP    hierHead,
                                    int                  outputBlkNb,
                                    DBA_DYNFLD_STP       **data,
                                    int                  *rows,
                                    const DBA_DYNST_ENUM **outputStLst, /* REF8844 - LJE - 030415 */
                                    FLAG_T               insertOpFlg,
                                    FLAG_T               insertPosFlg,
                                    FLAG_T               insertBalPosFlg,
                                    FLAG_T               keepOnlyPosMatchingPtfDimFlg,
                                    FLAG_T               keepOnlyPosMatchingInstrDimFlg,
                                    FLAG_T               addResultInHierFlg,
                                    DBA_DYNFLD_STP       **opTabParam,
                                    int                  *opNbrParam,
                                    DBA_DYNFLD_STP       **extPosTabParam,
                                    int                  *extPosNbrParam,
                                    DBA_DYNFLD_STP       *ptfTab,
                                    int                  ptfNbr, 
                                    int                  *allocConn,
                                    bool                 bExecuteDV)
{
	int		       blockIdx, orderIdx=0, executionIdx=0, globalFeeIdx=0, opNbr=0, extPosNbr=0, taxLotNbr = 0;
    DBA_DYNFLD_STP *opTab=NULLDYNSTPTR, *extPosTab=NULLDYNSTPTR, *taxLotTab = NULLDYNSTPTR;
	int		       orderNbr=NO_VALUE, executionNbr=NO_VALUE, globalFeeNbr=NO_VALUE;
    DBA_DYNFLD_STP *orderTab=NULLDYNSTPTR, *executionTab=NULLDYNSTPTR, *globalFeeTab=NULLDYNSTPTR;
    NUMBER_T       qty;
    FLAG_T *       flagTab = (FLAG_T *) NULL;
	RET_CODE       ret=RET_SUCCEED;

	FLAG_T                loadTaxLotFlg    = (static_cast<DOMTAXLOT_ENUM>(GET_ENUM(domainPtr, A_Domain_TaxLotEn)) != DomTaxLotEn_None);          /* PMSTA-34116 - 220219 - vkumar */
    TAX_LOT_ACCOUNTING    taxLotAccounting = TAX_LOT_ACCOUNTING::NoTaxLot;                                                                       /* PMSTA-34116 - 220219 - vkumar */
    GEN_GetApplInfo(ApplTaxLotAccountingEn, &taxLotAccounting);

	/* search Order and Execution blocks and sort them */
	for (blockIdx=0; blockIdx<outputBlkNb && ret == RET_SUCCEED; blockIdx++)
	{
        if (*(outputStLst[blockIdx]) == ExtOp)
        {
            if(orderNbr == NO_VALUE)
            {
                orderTab = data[blockIdx];
                orderNbr = rows[blockIdx];
                if (orderNbr > 1)
                    TLS_Sort((char *) orderTab, orderNbr, sizeof(DBA_DYNFLD_STP),
                             (TLS_CMPFCT*) FIN_CmpExtOpDbId, (PTR **) NULL, SortRtnTp_None);
            }
            else if(executionNbr == NO_VALUE)
            {
                executionTab = data[blockIdx];
                executionNbr = rows[blockIdx];

                if (executionNbr > 1)
                    TLS_Sort((char *) executionTab, executionNbr, sizeof(DBA_DYNFLD_STP),
                             (TLS_CMPFCT*) FIN_CmpExtOpOrderId, (PTR **) NULL, SortRtnTp_None);
            }
            else if(globalFeeNbr == NO_VALUE)
            {
                globalFeeTab = data[blockIdx];
                globalFeeNbr = rows[blockIdx];

                if (globalFeeNbr > 1)
                    TLS_Sort((char *) globalFeeTab, globalFeeNbr, sizeof(DBA_DYNFLD_STP),
                             (TLS_CMPFCT*) FIN_CmpExtOpOrderId, (PTR **) NULL, SortRtnTp_None);
            }
            else
            {
                /* Error three ExtOp blocks ?!?!?!? */
            }
        }
    }

	/* No hier => nothing to do ! */
	if (addResultInHierFlg == TRUE && hierHead == (DBA_HIER_HEAD_STP) NULL)
    {
        return(RET_SUCCEED);
    }

    /* Domain is mandatory to filter on intrument dimension */
	if (inputSt != A_Domain)
	{
        MSG_SendMesg(RET_FIN_ERR_INVDATA, 2, FILEINFO, "DBA_SplitExtOpBlock", "No domain");
        DBA_FreeDynStTab(orderTab,     orderNbr, ExtOp);
        DBA_FreeDynStTab(executionTab, executionNbr, ExtOp);
        DBA_FreeDynStTab(globalFeeTab, globalFeeNbr, ExtOp);
        return(RET_FIN_ERR_INVDATA);
	}

    /* Update, Split and filter all orders */
    for (orderIdx=0, executionIdx=0; orderIdx < orderNbr; orderIdx++)
    {
        /* PMSTA-25573 - CHU - 170505 */
        if (DBA_IsRejectedOrder(orderTab[orderIdx]) == TRUE)
        {
            continue;
        }

        /* update order if executed flag is TRUE */
        if (GET_FLAG(orderTab[orderIdx], ExtOp_ExecutedFlg) == TRUE)
        {
            /* compute new quantity */
            qty = GET_NUMBER(orderTab[orderIdx], ExtOp_Qty);
            while (executionIdx < executionNbr &&
                   CMP_DYNFLD(executionTab[executionIdx], orderTab[orderIdx],
                              ExtOp_ExtOrderId, ExtOp_DbId, IdType) < 0)
                executionIdx++;

            while (executionIdx < executionNbr &&
                   CMP_DYNFLD(executionTab[executionIdx], orderTab[orderIdx],
                              ExtOp_ExtOrderId, ExtOp_DbId, IdType) == 0)
            {
                qty -= GET_NUMBER(executionTab[executionIdx], ExtOp_Qty);
                executionIdx++;
            }

            /* if all the quantity of the order is excuted, don't keep it */
            if (qty <= 0)
                continue;

            /* if (qty != GET_NUMBER(orderTab[orderIdx], ExtOp_Qty)) */ /* REF9954 - TEB - 040225 - Lint messages corrections */
            if (CMP_NUMBER(qty,GET_NUMBER(orderTab[orderIdx], ExtOp_Qty)) != 0)
            {
                SET_NUMBER(orderTab[orderIdx], ExtOp_Qty, qty);

                /* update operation date and begin date with the begin date of last execution */
                SET_DATETIME(orderTab[orderIdx], ExtOp_OpDate,
                             GET_DATETIME(executionTab[executionIdx-1], ExtOp_BeginDate));
                SET_DATETIME(orderTab[orderIdx], ExtOp_BeginDate,
                             GET_DATETIME(executionTab[executionIdx-1], ExtOp_BeginDate));

                /* PMSAT-60007 - DDV - 240926 - Allow to skip DV to avoid infinite loop in DV */
                if (bExecuteDV)
                {
                    /* execute default value */
                    if (flagTab == (FLAG_T*) NULL)
                    {
                        if ((flagTab = (FLAG_T*)CALLOC(GET_FLD_NBR(ExtOp),sizeof(FLAG_T))) == NULL)
                        {
                            DBA_FreeDynStTab(opTab, opNbr, A_Op);
                            DBA_FreeDynStTab(extPosTab, extPosNbr, ExtPos);
                            DBA_FreeDynStTab(orderTab,     orderNbr, ExtOp);
                            DBA_FreeDynStTab(executionTab, executionNbr, ExtOp);
                            DBA_FreeDynStTab(globalFeeTab, globalFeeNbr, ExtOp);
						    DBA_FreeDynStTab(taxLotTab, taxLotNbr, A_TaxLot);
                            MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO, RET_MEM_ERR_ALLOC);
                            return(RET_MEM_ERR_ALLOC);
                        }
                        flagTab[ExtOp_Qty] = 1;
                        flagTab[ExtOp_OpDate] = 1;
                        flagTab[ExtOp_BeginDate] = 1;
                    }

                    SCPT_ComputeScreenDV(EOp,
                                         GET_DICT(domainPtr, A_Domain_FctDictId),
                                         flagTab,
                                         NULL,          /* HFI-PMSTA-25327-171023  Dedicated flag tab for filter    */
                                         orderTab[orderIdx],
                                         NULL,
                                         domainPtr,
                                         NULLDYNST,   /* PMSTA13283 - DDV - 120117 */
                                         FALSE,
                                         TRUE,                  /*  FPL-REF9507-030930  Transform FALSE in TRUE */
                                         EvalType_DefVal,       /*  FPL-REF9507-030930  Only Def val            */
                                         -1,
                                         allocConn,             /* PMSTA-53814 - AAKASH - 2023-08-07 : Connection re-used */
                                         NULL,
                                         hierHead,
                                         0,
                                         DictScreen,            /*  FIH-REF9789-040209  */
                                         NULL,
                                         NULL,
                                         NULL,
                                         NULL,
                                         NULL,
                                         NullEntity,
                                         FALSE,
                                         FALSE,
                                         0);        /*  FPL-REF9215-030811  Flag Impact */
                }
            }
        }

        /* split and filter order */
        if ((ret = DBA_SplitExtOp(domainPtr,
                                  hierHead,
                                  orderTab[orderIdx],
                                  insertOpFlg,
                                  insertPosFlg,
                                  insertBalPosFlg,
                                  keepOnlyPosMatchingPtfDimFlg,
                                  keepOnlyPosMatchingInstrDimFlg,
                                  &opTab,
                                  &opNbr,
                                  &extPosTab,
                                  &extPosNbr,
                                  ptfTab,
                                  ptfNbr,
                                  allocConn)) != RET_SUCCEED)
        {
            FREE(flagTab);
            DBA_FreeDynStTab(opTab, opNbr, A_Op);
            DBA_FreeDynStTab(extPosTab, extPosNbr, ExtPos);
            DBA_FreeDynStTab(orderTab,     orderNbr, ExtOp);
            DBA_FreeDynStTab(executionTab, executionNbr, ExtOp);
            DBA_FreeDynStTab(globalFeeTab, globalFeeNbr, ExtOp);
			DBA_FreeDynStTab(taxLotTab, taxLotNbr, A_TaxLot);
            return(ret);
        }

        if (TRUE == loadTaxLotFlg &&
            static_cast<DOMTAXLOT_ENUM>(GET_ENUM(domainPtr, A_Domain_TaxLotEn)) != DomTaxLotEn_PTCCOnlySimulation &&                       /* PMSTA-34295 - 300319 - vkumar */
            TAX_LOT_ACCOUNTING::TaxLotByBackOffice == taxLotAccounting)                                                                    /* PMSTA-34116 - 220219 - vkumar */
		{
			/* create Tax Lot */
			if ((ret = DBA_ExtOpToTaxLot(domainPtr, hierHead, orderTab[orderIdx], &taxLotTab, &taxLotNbr)) != RET_SUCCEED)
			{
				FREE(flagTab);
				DBA_FreeDynStTab(opTab, opNbr, A_Op);
				DBA_FreeDynStTab(extPosTab, extPosNbr, ExtPos);
				DBA_FreeDynStTab(orderTab, orderNbr, ExtOp);
				DBA_FreeDynStTab(executionTab, executionNbr, ExtOp);
				DBA_FreeDynStTab(globalFeeTab, globalFeeNbr, ExtOp);
				DBA_FreeDynStTab(taxLotTab, taxLotNbr, A_TaxLot);
				return(ret);
			}
		}
    }

    /* Split and filter all executions */
    for (executionIdx=0; executionIdx < executionNbr; executionIdx++)
    {
        /* remove all accounted executions (excuted flag is used to return accounted flag for executions and global fees) */
        if (GET_FLAG(executionTab[executionIdx], ExtOp_ExecutedFlg) == TRUE)
            continue;

        if ((ret = DBA_SplitExtOp(domainPtr,
                                  hierHead,
                                  executionTab[executionIdx],
                                  insertOpFlg,
                                  insertPosFlg,
                                  insertBalPosFlg,
                                  keepOnlyPosMatchingPtfDimFlg,
                                  keepOnlyPosMatchingInstrDimFlg,
                                  &opTab,
                                  &opNbr,
                                  &extPosTab,
                                  &extPosNbr,
                                  ptfTab,
                                  ptfNbr,
                                  allocConn)) != RET_SUCCEED)
        {
            FREE(flagTab);
            DBA_FreeDynStTab(opTab, opNbr, A_Op);
            DBA_FreeDynStTab(extPosTab, extPosNbr, ExtPos);
            DBA_FreeDynStTab(orderTab,     orderNbr, ExtOp);
            DBA_FreeDynStTab(executionTab, executionNbr, ExtOp);
            DBA_FreeDynStTab(globalFeeTab, globalFeeNbr, ExtOp);
			DBA_FreeDynStTab(taxLotTab, taxLotNbr, A_TaxLot);
            return(ret);
        }

        if (TRUE == loadTaxLotFlg &&
            static_cast<DOMTAXLOT_ENUM>(GET_ENUM(domainPtr, A_Domain_TaxLotEn)) != DomTaxLotEn_PTCCOnlySimulation &&                     /* PMSTA-34295 - 300319 - vkumar */
            TAX_LOT_ACCOUNTING::TaxLotByBackOffice == taxLotAccounting)                                                                  /* PMSTA-34116 - 220219 - vkumar */
		{
			/* create Tax Lot */
			if ((ret = DBA_ExtOpToTaxLot(domainPtr, hierHead, executionTab[executionIdx], &taxLotTab, &taxLotNbr)) != RET_SUCCEED)
			{
				FREE(flagTab);
				DBA_FreeDynStTab(opTab, opNbr, A_Op);
				DBA_FreeDynStTab(extPosTab, extPosNbr, ExtPos);
				DBA_FreeDynStTab(orderTab, orderNbr, ExtOp);
				DBA_FreeDynStTab(executionTab, executionNbr, ExtOp);
				DBA_FreeDynStTab(globalFeeTab, globalFeeNbr, ExtOp);
				DBA_FreeDynStTab(taxLotTab, taxLotNbr, A_TaxLot);
				return(ret);
			}
		}
    }

    /* Split and filter all global fees */
    for (globalFeeIdx=0; globalFeeIdx < globalFeeNbr; globalFeeIdx++)
    {
        /* remove all accounted global fees (excuted flag is used to return accounted flag for executions and global fees) */
        if (GET_FLAG(globalFeeTab[globalFeeIdx], ExtOp_ExecutedFlg) == TRUE)
            continue;

        if ((ret = DBA_SplitExtOp(domainPtr,
                                  hierHead,
                                  globalFeeTab[globalFeeIdx],
                                  insertOpFlg,
                                  insertPosFlg,
                                  insertBalPosFlg,
                                  keepOnlyPosMatchingPtfDimFlg,
                                  keepOnlyPosMatchingInstrDimFlg,
                                  &opTab,
                                  &opNbr,
                                  &extPosTab,
                                  &extPosNbr,
                                  ptfTab,
                                  ptfNbr,
                                  allocConn)) != RET_SUCCEED)
        {
            FREE(flagTab);
            DBA_FreeDynStTab(opTab, opNbr, A_Op);
            DBA_FreeDynStTab(extPosTab, extPosNbr, ExtPos);
            DBA_FreeDynStTab(orderTab,     orderNbr, ExtOp);
            DBA_FreeDynStTab(executionTab, executionNbr, ExtOp);
            DBA_FreeDynStTab(globalFeeTab, globalFeeNbr, ExtOp);
			DBA_FreeDynStTab(taxLotTab, taxLotNbr, A_TaxLot);
            return(ret);
        }

        if (TRUE == loadTaxLotFlg &&
            static_cast<DOMTAXLOT_ENUM>(GET_ENUM(domainPtr, A_Domain_TaxLotEn)) != DomTaxLotEn_PTCCOnlySimulation &&               /* PMSTA-34295 - 300319 - vkumar */
            TAX_LOT_ACCOUNTING::TaxLotByBackOffice == taxLotAccounting)                                                            /* PMSTA-34116 - 220219 - vkumar */
		{
			/* create Tax Lot */
			if ((ret = DBA_ExtOpToTaxLot(domainPtr, hierHead, globalFeeTab[globalFeeIdx], &taxLotTab, &taxLotNbr)) != RET_SUCCEED)
			{
				FREE(flagTab);
				DBA_FreeDynStTab(opTab, opNbr, A_Op);
				DBA_FreeDynStTab(extPosTab, extPosNbr, ExtPos);
				DBA_FreeDynStTab(orderTab, orderNbr, ExtOp);
				DBA_FreeDynStTab(executionTab, executionNbr, ExtOp);
				DBA_FreeDynStTab(globalFeeTab, globalFeeNbr, ExtOp);
				DBA_FreeDynStTab(taxLotTab, taxLotNbr, A_TaxLot);
				return(ret);
			}
		}
    }

    if (addResultInHierFlg == TRUE)
    {
        /* insert all operations in hierarchy */
 	    DBA_AddHierRecordList(hierHead, opTab, opNbr, A_Op, FALSE);

        /* insert all positions and balance positions in hierarchy */
 	    DBA_AddHierRecordList(hierHead, extPosTab, extPosNbr, ExtPos, FALSE);

		/* insert all tax lots in hierarchy */
		DBA_AddHierRecordList(hierHead, taxLotTab, taxLotNbr, A_TaxLot, FALSE);

        FREE(opTab);
        FREE(extPosTab);
		FREE(taxLotTab);
    }
    else
    {
        if (opTabParam != (DBA_DYNFLD_STP **) NULL && opNbrParam != (int *) NULL)
        {
            (*opTabParam) = opTab;
            (*opNbrParam) = opNbr;
            opTab = NULLDYNSTPTR;
            opNbr = 0;
        }
        else
            DBA_FreeDynStTab(opTab, opNbr, A_Op);

        if (extPosTabParam != (DBA_DYNFLD_STP **) NULL && extPosNbrParam != (int *) NULL)
        {
            (*extPosTabParam) = extPosTab;
            (*extPosNbrParam) = extPosNbr;
            extPosTab = NULLDYNSTPTR;
            extPosNbr = 0;
        }
        else
            DBA_FreeDynStTab(extPosTab, extPosNbr, ExtPos);
    }

    FREE(flagTab);

    DBA_FreeDynStTab(orderTab,     orderNbr, ExtOp);
    DBA_FreeDynStTab(executionTab, executionNbr, ExtOp);
    DBA_FreeDynStTab(globalFeeTab, globalFeeNbr, ExtOp);

	return(ret);
}

/************************************************************************
**  Function             :  DBA_SplitCollectedExtOp()
**
**  Description          :  Split and filter all collected ExtOp
**                          Filter is based on instrument dimension define in Domain.
**                          Op/Pos/BalPos are inserted according to function parameters
**
**  Arguments            :  domainPtr	pointer on the domain DS
**							hierHeadPtr	pointer on hierarchy header pointer
**
**
**  Return               :  RET_SUCCEED or error code
**
**  Creation 		     :  PMSTA00954 - RAK - 070214
**
**  Modif.               :
*************************************************************************/
EXTERN RET_CODE DBA_SplitCollectedExtOp(DBA_DYNFLD_STP       domainPtr,
										DBA_HIER_HEAD_STP    hierHead,
										FLAG_T               insertOpFlg,
										FLAG_T               insertPosFlg,
										FLAG_T               insertBalPosFlg,
										FLAG_T               keepOnlyPosMatchingPtfDimFlg,
										FLAG_T               keepOnlyPosMatchingInstrDimFlg,
										DBA_DYNFLD_STP       *ptfTab,
										int                  ptfNbr)
{
	DBA_DYNFLD_STP	*cExtOpTab=NULLDYNSTPTR, *extPosTab=NULLDYNSTPTR, *opTab=NULLDYNSTPTR;
	int				i, j, cExtOpNbr=0, extPosNbr=0, opNbr=0, deletedNbr=0;
	RET_CODE		ret=RET_SUCCEED;

	/* OCS39224-CHU-110929 : Call new Extract function for Collected records */
	if ((ret = DBA_HierEltCollectedRecExtract(hierHead, ExtOp,
											  FALSE, NULLFCT, NULLFCT,
											  &cExtOpNbr, &cExtOpTab)) != RET_SUCCEED)
	{
		return(ret);
	}

	for (i=0; i < cExtOpNbr; i++)
    {
		if ((ret = DBA_SplitExtOp(domainPtr,
                                  hierHead,
                                  cExtOpTab[i],
                                  insertOpFlg,
                                  insertPosFlg,
                                  insertBalPosFlg,
                                  keepOnlyPosMatchingPtfDimFlg,
                                  keepOnlyPosMatchingInstrDimFlg,
                                  &opTab,
                                  &opNbr,
                                  &extPosTab,
                                  &extPosNbr,
                                  ptfTab,
                                  ptfNbr,
                                  UNUSED)) != RET_SUCCEED)
        {
			FREE(cExtOpTab);
            return(ret);
        }

		/* insert all operations in hierarchy */
 		DBA_AddHierRecordList(hierHead, opTab, opNbr, A_Op, FALSE);

		if (opNbr > 0 && opTab != NULLDYNSTPTR && opTab[0] != NULLDYNST)
		{
			/* PMSTA07728 - RAK - 090113 - use j (it's really better :)) */
			for (j=0; j<extPosNbr; j++)
			{
				COPY_DYNFLD(extPosTab[j], ExtPos, ExtPos_OpenOpId,
							opTab[0],     A_Op,   A_Op_Id);
				COPY_DYNFLD(extPosTab[j], ExtPos, ExtPos_PosObjId, /* PMSTA09451 - DDV - 100316 - Set pos oject id to allow logical fusion working correctly when intrument is not in position */
							opTab[0],     A_Op,   A_Op_Id);
            }
		}

		/* insert all positions and balance positions in hierarchy */
 		DBA_AddHierRecordList(hierHead, extPosTab, extPosNbr, ExtPos, FALSE);

		FREE(opTab);
		opNbr=0;     /* PMSTA07735 - RAK - 090113 - Set it to zero to avoid crash */
		FREE(extPosTab);
		extPosNbr=0; /* PMSTA07735 - RAK - 090113 - Set it to zero to avoid crash */
    }


	FREE(cExtOpTab);

	ret = DBA_DelHierEltCollectedRec(hierHead, ExtOp, NULLFCT, NULLDYNST, TRUE /* freeFlg */, &deletedNbr);

	return(ret);
}

/************************************************************************
**
**  Function    :   DBA_FilterExternalPos()
**
**  Description :   Filter current external 'positions'
**                  ExtOp's with status_e == EXTERNAL_POS_STATUS
**
**  Arguments   :   ptr1   pointer on dynamic structure type ExtPos
**                  ptr2   pointer on dynamic structure type ExtPos
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation    :   PMSTA11101-CHU-110221
**
*************************************************************************/
STATIC int DBA_FilterExternalPos(DBA_DYNFLD_STP eOpPtr,
                                 DBA_DYNST_ENUM dynStTp,
                                 DBA_DYNFLD_STP seOpPtr)
{
	OPSTAT_ENUM	applExternalPosStatus = OpStat_Cancelled;
	GEN_GetApplInfo(ApplExternalPosStatus, &applExternalPosStatus);

	if (applExternalPosStatus > OpStat_Cancelled &&
		applExternalPosStatus == (OPSTAT_ENUM)GET_ENUM(eOpPtr, ExtOp_StatusEn))
	{
		return(TRUE);
	}
    return(FALSE);
}

/************************************************************************
**  Function             :  DBA_SplitExternalPos()
**
**  Description          :  Split and filter all External Pos (See EXTERNAL_POS_STATUS)
**                          Filter is based on instrument dimension define in Domain.
**                          Op/Pos/BalPos are inserted according to function parameters
**
**  Arguments            :  domainPtr	pointer on the domain DS
**							hierHeadPtr	pointer on hierarchy header pointer
**
**
**  Return               :  RET_SUCCEED or error code
**
**  Creation 		     :  PMSTA11101-CHU-110221
**
**  Modif.               :
*************************************************************************/
EXTERN RET_CODE DBA_SplitExternalPos(DBA_DYNFLD_STP       domainPtr,
									 DBA_HIER_HEAD_STP    hierHead,
									 FLAG_T               insertOpFlg,
									 FLAG_T               insertPosFlg,
									 FLAG_T               insertBalPosFlg,
									 FLAG_T               keepOnlyPosMatchingPtfDimFlg,
									 FLAG_T               keepOnlyPosMatchingInstrDimFlg,
									 DBA_DYNFLD_STP       *ptfTab,
									 int                  ptfNbr)
{
	DBA_DYNFLD_STP	*cExtOpTab=NULLDYNSTPTR, *extPosTab=NULLDYNSTPTR, *opTab=NULLDYNSTPTR;
	int				i, j, cExtOpNbr=0, extPosNbr=0, opNbr=0, deletedNbr=0;
	RET_CODE		ret=RET_SUCCEED;

	if ((ret = DBA_ExtractHierEltRec(hierHead, ExtOp,
									 FALSE, DBA_FilterExternalPos, NULLFCT,
									 &cExtOpNbr, &cExtOpTab)) != RET_SUCCEED)
	{
		return(ret);
	}

	for (i=0; i < cExtOpNbr; i++)
    {
		if ((ret = DBA_SplitExtOp(domainPtr,
                                  hierHead,
                                  cExtOpTab[i],
                                  insertOpFlg,
                                  insertPosFlg,
                                  insertBalPosFlg,
                                  keepOnlyPosMatchingPtfDimFlg,
                                  keepOnlyPosMatchingInstrDimFlg,
                                  &opTab,
                                  &opNbr,
                                  &extPosTab,
                                  &extPosNbr,
                                  ptfTab,
                                  ptfNbr,
                                  UNUSED)) != RET_SUCCEED)
        {
			FREE(cExtOpTab);
            return(ret);
        }

		/* insert all operations in hierarchy */
 		DBA_AddHierRecordList(hierHead, opTab, opNbr, A_Op, FALSE);

		if (opNbr > 0 && opTab != NULLDYNSTPTR && opTab[0] != NULLDYNST)
		{
			/* PMSTA07728 - RAK - 090113 - use j (it's really better :)) */
			for (j=0; j<extPosNbr; j++)
			{
				COPY_DYNFLD(extPosTab[j], ExtPos, ExtPos_OpenOpId,
							opTab[0],     A_Op,   A_Op_Id);
				COPY_DYNFLD(extPosTab[j], ExtPos, ExtPos_PosObjId, /* PMSTA09451 - DDV - 100316 - Set pos oject id to allow logical fusion working correctly when intrument is not in position */
							opTab[0],     A_Op,   A_Op_Id);
            }
		}

		/* insert all positions and balance positions in hierarchy */
 		DBA_AddHierRecordList(hierHead, extPosTab, extPosNbr, ExtPos, FALSE);

		FREE(opTab);
		opNbr=0;     /* PMSTA07735 - RAK - 090113 - Set it to zero to avoid crash */
		FREE(extPosTab);
		extPosNbr=0; /* PMSTA07735 - RAK - 090113 - Set it to zero to avoid crash */
    }


	FREE(cExtOpTab);

	ret = DBA_DelAndFreeHierEltRecWithFilter(hierHead, ExtOp, DBA_FilterExternalPos, NULLDYNST, &deletedNbr);

	return(ret);
}

/************************************************************************
**  Function             :  DBA_SplitExtOp()
**
**  Description          :  Split and filter all ExtOp (from ext_order, execution and global_execution_fee tables).
**                          Filter is based on instrument dimension define in Domain.
**                          Op/Pos/BalPos are inserted according to function parameters
**
**  Arguments            :  domainPtr	          pointer on domain
**                          hierHead              pointer on hierarchy header pointer
**                          extOpPtr              pointer on entended operation to split
**                          insertOpFlg           insert operation into hierarchy
**                          insertPosFlg          insert position into hierarchy
**                          insertBalPosFlg       insert balance position into hierarchy
**                          keepOnlyMatchingPosFlg only position matching Instrument/PPS dimension are keept
**                          allOpTab              pointer on operation tab
**                          allOpNbr              number of operation in tab
**                          allExtPosTab          pointer on extended position tab
**                          allExtPosNbr          number of extended position in tab
**
**  Return               :  RET_SUCCEED or error code
**
**  Creation 		     :  REF7560 - DDV - 020613 - Create ExtPos for orders abd executions.
**                          PMSTA00469 - DDV - 061026 - Use PtfTab to check dimension.
**
**  Modif.               :  PMSTA-5219 - 140808 - PMO : Logical Fusion : When we use, operations with reference nature "Future FIFO" or "Future WMP" , the logical fusion is wrong
*************************************************************************/
STATIC RET_CODE DBA_SplitExtOp(DBA_DYNFLD_STP    domainPtr,
                               DBA_HIER_HEAD_STP hierHead,
                               DBA_DYNFLD_STP    extOpPtr,
                               FLAG_T            insertOpFlg,
                               FLAG_T            insertPosFlg,
                               FLAG_T            insertBalPosFlg,
                               FLAG_T            keepOnlyPosMatchingPtfDimFlg,
                               FLAG_T            keepOnlyPosMatchingInstrDimFlg,
                               DBA_DYNFLD_STP    **allOpTab,
                               int               *allOpNbr,
                               DBA_DYNFLD_STP    **allExtPosTab,
                               int               *allExtPosNbr,
                               DBA_DYNFLD_STP    *ptfTab,
                               int               ptfNbr,
                               int               *allocConn)
{
    DBA_DYNFLD_STP      instrPtr=NULLDYNST, ptfPtr=NULLDYNST, instrListPtr=NULLDYNST, ptfListPtr=NULLDYNST;
    DBA_DYNFLD_STP	    op=NULLDYNST, *extPosTab=NULLDYNSTPTR;
    DBA_DYNFLD_STP	    *ppsTab=NULLDYNSTPTR;
    FLAG_T              allocInstrFlg=FALSE, allocPtfFlg=FALSE;
    FLAG_T		        adjCashFlag=FALSE, genPPSFlg=FALSE;
    FLAG_T              matchPtfDimFlg = FALSE, matchInstrDimFlg = FALSE,
                        keepAllFlg = FALSE, onePosMatchInstrFlg=FALSE, onePosMatchPtfFlg=FALSE;
	RET_CODE            ret=RET_SUCCEED;
    int                 extPosNbr, i;
    int                 ppsNbr=0;
    ID_T                refCurrId = (ID_T) 0;
	OBJECT_ENUM         domainPtfDim=NullEntity, domainInstrDim=NullEntity;
    MemoryPool          mp;

    /* PMSTA-25573 - CHU - 170505 */
    if (DBA_IsRejectedOrder(extOpPtr) == TRUE)
    {
        return(ret);
    }

    /* REF11116 - 050523 - DDV - Get instrument and porfolio dimension in domain */
	DBA_GetObjectEnum(GET_DICT(domainPtr, A_Domain_DimPtfDictId), &domainPtfDim);
	DBA_GetObjectEnum(GET_DICT(domainPtr, A_Domain_DimInstrDictId), &domainInstrDim);

    DBA_GetInstrById(GET_ID(extOpPtr, ExtOp_InstrId), TRUE, &allocInstrFlg, &instrPtr,
                     hierHead, UNUSED, allocConn);

    if(allocInstrFlg == TRUE)
    {
        mp.ownerDynStp(instrPtr);
    }
    DBA_GetPtfById(GET_ID(extOpPtr, ExtOp_PtfId), TRUE, &allocPtfFlg, &ptfPtr,
                   hierHead, UNUSED, allocConn);

    if(allocPtfFlg == TRUE)
    {
        mp.ownerDynStp(ptfPtr);
    }

    if (GET_ENUM(domainPtr, A_Domain_PpsLoadEn) == Domain_PpsLoadEn_NoPps &&
        GET_DICT(domainPtr, A_Domain_FctDictId) != DictFct_OpList) /* REF7560 - DDV - For operation list generate position for all PPS */
        genPPSFlg = FALSE;
    else
    {
        genPPSFlg = TRUE;
        DBA_LoadPPSForPtf(ptfPtr, domainPtr, &ppsTab, &ppsNbr);
    }

    if (GET_FLAG(domainPtr, A_Domain_DefCurrFlg) == FALSE)
	    refCurrId = GET_ID(domainPtr, A_Domain_CurrId);

	else
	{
		refCurrId = GET_ID(ptfPtr, A_Ptf_CurrId);
	}

    /* Split Extop to Op/Pos/BalPos */
    if ((ret = OPE_ExtOpToOpExtPos(extOpPtr,
                                   (OPNAT_ENUM) GET_ENUM(extOpPtr, ExtOp_NatureEn),
                                   refCurrId,
                                   (FUSDATERULE_ENUM) GET_ENUM(domainPtr, A_Domain_FusDateRuleEn),
                                   A_Ptf,
                                   ptfPtr,
                                   genPPSFlg,
                                   ppsTab,
                                   ppsNbr,
                                   A_Instr,
                                   instrPtr,
                                   &op,
                                   &extPosTab,
                                   &extPosNbr,
                                   (allocConn != NULL) ? *allocConn : NO_VALUE,    /* PMSTA-53814 - AAKASH - 2023-08-07 : Connection re-used */
                                   UNUSED,
                                   &adjCashFlag,	/* DVP489 - 970602 - XMT, adjCashFlag */
                                   TRUE)) != RET_SUCCEED) /* PMSTA13471 - DDV - 120131 - Allow partial position generation when data security decline access to adj portfolio */
    {
        FREE_DYNST(op,A_Op);
        DBA_FreeDynStTab(extPosTab, extPosNbr, ExtPos);
	    return(RET_GEN_ERR_INVARG);
    }

    mp.ownerDynStp(op);
    mp.ownerDynStpTab(extPosTab,extPosNbr);

    /* Filter positions according to instrument dimension, portfolio dimension
       and quantity_n (filter define in domain)*/
    for (i=0; i < extPosNbr && keepAllFlg == FALSE; i++)
    {
        if(extPosTab[i] != NULLDYNST)
        {
            if (DBA_CheckQuantity(domainPtr, extPosTab[i], FALSE) == TRUE)  /* PMSTA-5219 - 140808 - PMO */
            {
                /* REF9941 - DDV - 040227 - If portfolio is deferent, load the right one */
                if (NULLDYNST == ptfPtr || CMP_DYNFLD(extPosTab[i], ptfPtr,
                               ExtPos_PtfId, A_Ptf_Id, IdType) != 0)
                {
                    ptfPtr = NULLDYNST; // in memorypool
                    DBA_GetPtfById(GET_ID(extPosTab[i], ExtPos_PtfId), TRUE, &allocPtfFlg, &ptfPtr,
                                   hierHead, UNUSED, allocConn);
                    if(allocPtfFlg == TRUE)
                    {
                        mp.ownerDynStp(ptfPtr);
                    }
                }

				/* REF11116 - 050523 - DDV - if portfolio not found don't call DBA_CheckPtfDim, just check domain dimension */
				if (ptfPtr != NULLDYNST)
				{
					matchPtfDimFlg = DBA_CheckPtfDim(domainPtr, hierHead,
													 GET_ID(extPosTab[i], ExtPos_PtfId),
													 ptfPtr, &ptfListPtr, FALSE,
													 (DATETIME_STP) NULL, ptfTab, ptfNbr);
                    mp.ownerDynStp(ptfListPtr);
				}
				else
				{
					if (domainPtfDim == NullEntity)
						matchPtfDimFlg = TRUE;
					else
						matchPtfDimFlg = FALSE;
				}

                /* REF9941 - DDV - 040227 - If instrument is deferent, load the right one */
                if (NULLDYNST == instrPtr || CMP_DYNFLD(extPosTab[i], instrPtr,
                               ExtPos_InstrId, A_Instr_Id, IdType) != 0)
                {
                    instrPtr = NULLDYNST; // in memorypool
                    DBA_GetInstrById(GET_ID(extPosTab[i], ExtPos_InstrId), TRUE, &allocInstrFlg, &instrPtr,
                                     hierHead, UNUSED, allocConn);
                    if(allocInstrFlg == TRUE)
                    {
                        mp.ownerDynStp(instrPtr);
                    }
                }

				/* REF11116 - 050523 - DDV - if instrument not found don't call DBA_CheckPtfDim, just check domain dimension */
				if (instrPtr != NULLDYNST)
				{
					matchInstrDimFlg = DBA_CheckInstrDim(domainPtr, hierHead,
														 GET_ID(extPosTab[i], ExtPos_InstrId),
														 instrPtr, &instrListPtr, allocConn, FALSE,
														 (DATETIME_STP) NULL, FALSE);
                    mp.ownerDynStp(instrListPtr);
				}
				else
				{
					if (domainInstrDim == NullEntity)
						matchInstrDimFlg = TRUE;
					else
						matchInstrDimFlg = FALSE;
				}

				if (matchInstrDimFlg == TRUE)
					onePosMatchInstrFlg = TRUE;

				if (matchPtfDimFlg == TRUE)
					onePosMatchPtfFlg = TRUE;

                if (keepOnlyPosMatchingPtfDimFlg == TRUE &&
                    keepOnlyPosMatchingInstrDimFlg == TRUE)
                {
                    if (matchPtfDimFlg == FALSE ||
                        matchInstrDimFlg == FALSE)
                        mp.freeDynStp(extPosTab[i]);
                }
                else if (keepOnlyPosMatchingPtfDimFlg == TRUE &&
                         keepOnlyPosMatchingInstrDimFlg == FALSE)
                {
                    if (matchPtfDimFlg == FALSE)
                       mp.freeDynStp(extPosTab[i]);
                }
                else if (keepOnlyPosMatchingPtfDimFlg == FALSE &&
                         keepOnlyPosMatchingInstrDimFlg == TRUE)
                {
                    if (matchInstrDimFlg == FALSE)
                        mp.freeDynStp(extPosTab[i]);
                }
                else if (keepOnlyPosMatchingPtfDimFlg == FALSE &&
                         keepOnlyPosMatchingInstrDimFlg == FALSE)

                {
                    if (matchPtfDimFlg == TRUE &&
                        matchInstrDimFlg == TRUE)
                        keepAllFlg = TRUE;
                }
            }
            else
                mp.freeDynStp(extPosTab[i]);
        }
    }

	/* REF11233 - DDV - 050829 - remove all position if no position match restricted Ptf or Instr dimension */
	if ((domainInstrDim != NullEntity && onePosMatchInstrFlg == FALSE) ||
		(domainPtfDim != NullEntity && onePosMatchPtfFlg == FALSE))
	{
        return(RET_SUCCEED);
	}

    /* if no instrument match domain dimension, free Op and ExtPos and return */
    if (keepAllFlg == FALSE &&
        keepOnlyPosMatchingPtfDimFlg == FALSE &&
        keepOnlyPosMatchingInstrDimFlg == FALSE)
    {
        return(RET_SUCCEED);
    }

    /* Filter positions according to domain PPS definition */
    if (genPPSFlg == TRUE)
    {
        for (i=0; i < extPosNbr; i++)
        {
            if(extPosTab[i] != NULLDYNST)
            {
                if (DBA_CheckPPSDim(extPosTab[i], domainPtr, ppsTab, ppsNbr) == FALSE)
                    mp.freeDynStp(extPosTab[i]);
            }
        }
    }

    /* PMSTA-47578 - DDV - 220323 */
    if (IS_NULLFLD(extOpPtr, ExtOp_DbId) == FALSE)
    {
        COPY_DYNFLD(op, A_Op, A_Op_Id, extOpPtr, ExtOp, ExtOp_DbId);
    }

    /* REF7560 - DDV - 020614 - Update ExtPos flields (begin_d . . . ) To check */
    for (i=0; i < extPosNbr; i++)
    {
        if(extPosTab[i] != NULLDYNST)
        {
            if (IS_NULLFLD(extOpPtr, ExtOp_DbId) == FALSE)
            {
                COPY_DYNFLD(extPosTab[i], ExtPos, ExtPos_OpenOpId,
		                    extOpPtr, ExtOp, ExtOp_DbId);
            }

	        COPY_DYNFLD(extPosTab[i], ExtPos, ExtPos_Fus,
		                extOpPtr, ExtOp, ExtOp_FusionEn);
	        COPY_DYNFLD(extPosTab[i], ExtPos, ExtPos_FusRuleEn,
		                extOpPtr, ExtOp, ExtOp_FusRuleEn);

            if (GET_ENUM(extPosTab[i], ExtPos_StatEn) == OpStat_Cancelled)
            {
	            COPY_DYNFLD(extPosTab[i], ExtPos, ExtPos_EndDate,
		                    extPosTab[i], ExtPos, ExtPos_BegDate);
            }
        }
    }

    /* Insert operation record in array */
    if (insertOpFlg == TRUE)
    {
        if (*allOpNbr % 100 == 0)
        {
            if (*allOpNbr == 0)
                *allOpTab = (DBA_DYNFLD_STP *) CALLOC(100, sizeof(DBA_DYNFLD_STP *));
            else
                *allOpTab = (DBA_DYNFLD_STP *) REALLOC(*allOpTab, (*allOpNbr+100) * sizeof(DBA_DYNFLD_STP *));

            if (*allOpTab == NULLDYNSTPTR)
            {
                MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
                return(RET_MEM_ERR_ALLOC);
            }
        }
        (*allOpTab)[*allOpNbr] = op;
        (*allOpNbr)++;					/* PMSTA00954 - RAK - 070215 */
        mp.removeDynStp(op);
    }

    /* Add ExtPos in array */
    for (i=0; i < extPosNbr; i++)
    {
        if(extPosTab[i] != NULLDYNST)
        {
            if ((IS_NULLFLD(extPosTab[i], ExtPos_BalPosTpId) == TRUE && insertPosFlg == TRUE) ||
                (IS_NULLFLD(extPosTab[i], ExtPos_BalPosTpId) == FALSE && insertBalPosFlg == TRUE))
            {
                if (*allExtPosNbr % 100 == 0)
                {
                    if (*allExtPosNbr == 0)
                        *allExtPosTab = (DBA_DYNFLD_STP *) CALLOC(100, sizeof(DBA_DYNFLD_STP *));
                    else
                        *allExtPosTab = (DBA_DYNFLD_STP *) REALLOC(*allExtPosTab, (*allExtPosNbr+100) * sizeof(DBA_DYNFLD_STP *));

                    if (*allExtPosTab == NULLDYNSTPTR)
                    {
                        MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
                        return(RET_MEM_ERR_ALLOC);
                    }
                }
                (*allExtPosTab)[*allExtPosNbr] = extPosTab[i];
                (*allExtPosNbr)++;
                mp.removeDynStp(extPosTab[i]);

            }
            else
                 mp.freeDynStp(extPosTab[i]);
        }
    }

    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_CmpExtOpDbId()
**
**  Description :   Sort extended operation by ExtOp_DbId
**
**  Arguments   :   ptr1   pointer on dynamic structure type ExtOp
**                  ptr2   pointer on dynamic structure type ExtOp
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation    :   REF7650 - DDV - 020715
**  Modif       :
*************************************************************************/
STATIC int FIN_CmpExtOpDbId(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    int ret;

    ret = CMP_DYNFLD((*ptr1), (*ptr2),
                     ExtOp_DbId, ExtOp_DbId, IdType);

    return ret;
}

/************************************************************************
**
**  Function    :   FIN_CmpExtOpOrderId()
**
**  Description :   Sort extended operation by ExtOp_extOrderId and ExtOp_BeginDate
**
**  Arguments   :   ptr1   pointer on dynamic structure type ExtOp
**                  ptr2   pointer on dynamic structure type ExtOp
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation    :   REF7650 - DDV - 020715
**  Modif       :
*************************************************************************/
STATIC int FIN_CmpExtOpOrderId(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    int ret;

    if ((ret = CMP_DYNFLD((*ptr1), (*ptr2),
                          ExtOp_ExtOrderId, ExtOp_ExtOrderId, IdType)) != 0)
        return ret;


    ret = CMP_DYNFLD((*ptr1), (*ptr2),
                     ExtOp_BeginDate, ExtOp_BeginDate, DatetimeType);

    return ret;
}

/************************************************************************
**
**  Function         : DBA_CheckPositions()
**
**  Description      : Verify zero quantify and so one (and suppress positions if necessary)
**
**  Arguments        : domainPtr  domain pointer
**                     extPosPtr  pointer on position to check
**
**  Return           : RET_SUCCEED or error code
**
** Creation Date     : PMSTA05219 - RAK - 080812
** Last Modification : PMSTA-5219 - 140808 - PMO : Logical Fusion : When we use, operations with reference nature "Future FIFO" or "Future WMP" , the logical fusion is wrong
**
*************************************************************************/
EXTERN RET_CODE DBA_CheckPositions(DBA_DYNFLD_STP domainPtr, DBA_HIER_HEAD_STP hierHead)
{
	int				i, posNbr=0;
	DBA_DYNFLD_STP	*extractPos=NULLDYNSTPTR;
	RET_CODE		ret=RET_SUCCEED;

	if ((GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_Valo		 ||
		 GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_MultiValo	 ||
		 GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_Return	 ||
		 GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_SynthAdmin ||
		 GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_PtfStorage) &&
         (DBA_GetCashFlowMgtEnum(domainPtr,NULL) != CashFlowMgt_None || /* DLA - PMSTA04851 - 080318 */
		  GET_FLAG(domainPtr, A_Domain_ZeroQtyFlg) == TRUE))
	{
		/* PMSTA00485 - 061117 - DDV - If zero qantity flag was forced to TRUE, remove remaining zero positions */
		SET_ENUM(domainPtr, A_Domain_CashFlowMgtEn, CashFlowMgt_All);
		SET_FLAG(domainPtr, A_Domain_ZeroQtyFlg, GET_FLAG(domainPtr, A_Domain_SaveZeroQtyFlg)); /* DLA - PMSTA04851 - 080326 */

		if ((ret = DBA_ExtractHierEltRec(hierHead, ExtPos,
				                     FALSE, NULL, NULL, &posNbr, &extractPos)) == RET_SUCCEED)
		{
			for (i=0; i<posNbr && ret==RET_SUCCEED; i++)	/* stop if not succeed */
			{
				if (  DBA_CheckQuantity(domainPtr, extractPos[i], TRUE) == FALSE)   /* PMSTA-5219  - 140808 - PMO */
	   			{
					ret = DBA_DelHierEltRec(hierHead, ExtPos, extractPos[i]);
	   			}
			}
		}

		FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
	}

	return(ret);	/* RET_SUCCEED or not */
}

/************************************************************************
**
**  Function    :   DBA_GetCashFlowMgtEnum()
**
**  Description :   Return the Cash Flow Management Enum following this rule:
**                  1 search in domain, 2 search in ptf, 3 search in INCLUDE_DIV_ACCRUAL system parameter (This is TRUE only is domain AND ptf are given)
**                  N.B: If all cash flow management variable are set to CashFlowMgt_Default fct return CashFlowMgt_None
**                       If only a domain is in parameter (ptf NULL) and A_Domain_CashFlowMgtEn == CashFlowMgt_Default we return CashFlowMgt_All
**
**  Arguments   :   domainPtr		domain pointer
**                  argHierHead		hierarchy pointer
**                  ptfId           portfolio Id if avalaible
**
**  Return      :   CASHFLOWMGT_ENUM
**
**  Creation    :   DLA - PMSTA04851 - 080312
**	Modif		:	PMSTA05219 - RAK - 080812 -> FIN_GetCashFlowMgtEnum() -> DBA_GetCashFlowMgtEnum()
**
*************************************************************************/
CASHFLOWMGT_ENUM DBA_GetCashFlowMgtEnum(DBA_DYNFLD_STP domainPtr,
                                        DBA_DYNFLD_STP ptfPtr )
{
    CASHFLOWMGT_ENUM cashFlowMgtEnum = CashFlowMgt_None;

    if (domainPtr != NULLDYNST  && GET_ENUM(domainPtr, A_Domain_CashFlowMgtEn) != CashFlowMgt_Default )
    {
        return ((CASHFLOWMGT_ENUM)GET_ENUM(domainPtr, A_Domain_CashFlowMgtEn));
    }
    else
    {
        if ( ptfPtr != NULLDYNST )
        {
            if (GET_ENUM(ptfPtr, A_Ptf_DividendAccrualEn) != CashFlowMgt_Default )
            {
                return ((CASHFLOWMGT_ENUM)GET_ENUM(ptfPtr, A_Ptf_DividendAccrualEn));
            }
        }
        else
        {
            return ((CASHFLOWMGT_ENUM)CashFlowMgt_All);
        }

   		GEN_GetApplInfo(ApplIncludeDivAccrual, &cashFlowMgtEnum);

        if ( cashFlowMgtEnum == CashFlowMgt_Default)
            cashFlowMgtEnum = CashFlowMgt_None;
    }

    return (cashFlowMgtEnum);
}


/************************************************************************
*   Function             : DBA_CheckMarginCallPositionToRemove()
*
*   Description          : Check if a dervived margin call position in operation list must be removed
*
*   Arguments            : domainPtr    Domain structure pointer
*                          pos          Position to check
*
*   Return               : TRUE  The position must be removed
*                          FALSE Keep the position
*
*   Creation Date        : PMSTA08594 - 140909 - PMO : Unexplained difference running operation list : different number of extended_pos retrieved
*
*   Last Modification    :
*
*************************************************************************/
FLAG_T DBA_CheckMarginCallPositionToRemove(const DBA_DYNFLD_STP domainPtr, const DBA_DYNFLD_STP pos)
{
    DBA_DYNFLD_STP      instrPtr;
    const DATETIME_T    tmpDate     = {MAGIC_END_DATE,0};

    return GET_ID(domainPtr, A_Domain_FctDictId)                  == DictFct_OpList
           && (POSPRIMARY_ENUM)GET_ENUM(pos,  ExtPos_PrimaryEn)   == PosPrimary_Derived
           && (POSNAT_ENUM)GET_ENUM(pos,      ExtPos_PosNatEn)    == PosNat_None
           && (OPNAT_ENUM)GET_ENUM(pos,       ExtPos_OpenOpNatEn) == OpNat_Adjust
           && (OPADJUSTNAT_ENUM)GET_ENUM(pos, ExtPos_AdjustNatEn) == OpAdjustNat_None
           && DATETIME_CMP(GET_DATETIME(pos,  ExtPos_EndDate), tmpDate) < 0
           &&!(DATETIME_CMP(GET_DATETIME(pos,  ExtPos_BegDate),  GET_DATETIME(domainPtr, A_Domain_InterpFromDate)) > 0  /* DLA - PMSTA07211 - 081020 */
              ||DATETIME_CMP(GET_DATETIME(pos,  ExtPos_EndDate), GET_DATETIME(domainPtr, A_Domain_InterpTillDate)) <=0 )
           && GET_EXTENSION_PTR(pos, ExtPos_A_Instr_Ext) != NULL
           && ((instrPtr = *(GET_EXTENSION_PTR(pos, ExtPos_A_Instr_Ext))) != NULLDYNST)
           && GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_Future
           ?  (FLAG_T)TRUE : (FLAG_T)FALSE;
}


/************************************************************************
*   Function             : DBA_IsTechnicalCashPosition()
*
*   Description          : Check if it is a technical cash position
*
*   Arguments            : pos          Position to check
*
*   Return               : true  The position is a technical cash
*                          false The position is not a technical cash
*
*   Creation Date        : PMSTA-20838 - 160715 - PMO : Spot movements created by a forex swap do not merge and create multiple positions even if value date is reached
*
*   Last Modification    :
*
*************************************************************************/
bool DBA_IsTechnicalCashPosition(const DBA_DYNFLD_STP pos)
{
    const POSNAT_ENUM posNat = (POSNAT_ENUM)GET_ENUM(pos, ExtPos_PosNatEn);

    return    posNat == PosNat_TechnicalCashMain
           || posNat == PosNat_TechnicalCashAcct2
           || posNat == PosNat_TechnicalCashAcct3;
}


/************************************************************************
*   Function             : DBA_IsTechnicalPosition()
*
*   Description          : Check if it is a technical position
*
*   Arguments            : pos          Position to check
*
*   Return               : true  The position is technical
*                          false The position is not technical
*
*   Creation Date        : PMSTA-20838 - 160715 - PMO : Spot movements created by a forex swap do not merge and create multiple positions even if value date is reached
*
*   Last Modification    :
*
*************************************************************************/
bool DBA_IsTechnicalPosition(const DBA_DYNFLD_STP pos)
{
    return    (POSNAT_ENUM)   GET_ENUM(pos, ExtPos_PosNatEn)  == PosNat_FeesRatePos
           || (OPLOCKNAT_ENUM)GET_ENUM(pos, ExtPos_LockNatEn) == OpLockNat_LockData             /* PMSTA-22130 - DDV - 160125 */
           || DBA_IsTechnicalCashPosition(pos)                == true;
}


/************************************************************************
*   Function             : DBA_CheckPositionToRemove()
*
*   Description          : Check if the position must be removed
*                          - adjustment account positions must be removed
*                          - buy or sell (forward) account2 position must be removed
*
*   Arguments            : domainPtr    Domain structure pointer
*                          pos          Position to check
*
*   Return               : TRUE  The position must be removed
*                          FALSE Keep the position
*
*   Creation Date        : PMSTA-5595 - 190808 - PMO
*
*   Last Modification    : PMSTA-7110 - 100908 - PMO : Account positions are displayed in the valuation when FUSION_CASH_VALUE_DATE_FLAG is set to 1
*                          PMSTA-6924 - 280109 - PMO : Cash Portfolio on Forwards
*                          PMSTA08594 - 140909 - PMO : Unexplained difference running operation list : different number of extended_pos retrieved
*                          PMSTA-9072 - 050510 - PMO : Future instrument with Fees&Taxes at opening position: exchange rate at opening position are not saved after adjustment operation
*                          PMSTA-16180 - 100413 - PMO : Financial server crash when performing valuation
*                          PMSTA-16533 - 221113 - PMO : Cost price (quote_n) of a position is wrong for price calculation rule "Partially Paid Bonds" after an adjustment of nature "Gross Amount"
*                          PMSTA-17317 - 171213 - PMO : The remark of an operation after a locking & unlocking process must not be lost and it must be displayed in the new, unlocked position
*                          PMSTA-20838 - 160715 - PMO : Spot movements created by a forex swap do not merge and create multiple positions even if value date is reached
*
*************************************************************************/
FLAG_T DBA_CheckPositionToRemove(const DBA_DYNFLD_STP domainPtr, const DBA_DYNFLD_STP pos)  /* Function renamed PMSTA-6924 - 280109 - PMO */
{
    const DATETIME_T            tmpDate             = {MAGIC_END_DATE,0};
    bool                        removePositionFlg   = false;

    if (NULL != pos)    /* PMSTA-16180 - 100413 - PMO */
    {
        /* PMSTA-6924 - 280109 - PMO */
        if (0 == CMP_ID(GET_ID(pos, ExtPos_OpenOpId), GET_ID(pos, ExtPos_CloseOpId))
          &&0 == DATETIME_CMP(GET_DATETIME(pos, ExtPos_BegDate), GET_DATETIME(pos, ExtPos_EndDate))
          &&PosPrimary_Primary == (POSPRIMARY_ENUM)GET_ENUM(pos,  ExtPos_PrimaryEn)
          &&FALSE == IS_NULLFLD(pos, ExtPos_CashPortfolioId)
          &&0     != CMP_ID(GET_ID(pos, ExtPos_PtfId), GET_ID(pos, ExtPos_CashPortfolioId))
          )
        {
            CASHADJNEUTRALIZING_ENUM    applAdjCashNeutEnum;                                        /* PMSTA-6924 - 280109 - PMO */

            /* Get neutralization mode */
            (void)GEN_GetApplInfo(ApplCashAdjNeutralizingEnum, &applAdjCashNeutEnum);

            if (CashAdjNeut_Pos == applAdjCashNeutEnum || CashAdjNeut_None == applAdjCashNeutEnum)  /* PMSTA08471 - 280709 - PMO */
            {
                removePositionFlg = (POSNAT_ENUM)GET_ENUM(pos,      ExtPos_PosNatEn)    == PosNat_MainAcctPos
                                  &&( (POSNAT_ENUM)GET_ENUM(pos,    ExtPos_RefNatEn)    == PosRefNat_FwdOpen
                                    ||(POSNAT_ENUM)GET_ENUM(pos,    ExtPos_RefNatEn)    == PosRefNat_FwdClose
                                    )
                                  &&( (OPNAT_ENUM)GET_ENUM(pos,     ExtPos_OpenOpNatEn) == OpNat_Buy
                                    ||(OPNAT_ENUM)GET_ENUM(pos,     ExtPos_OpenOpNatEn) == OpNat_Sell
                                    );

                if (removePositionFlg == false)
                {
                    removePositionFlg = (POSNAT_ENUM)GET_ENUM(pos,  ExtPos_PosNatEn)    == PosNat_Acct2Pos
                                      &&IS_NULLFLD(pos,             ExtPos_BalPosTpId)  == TRUE;
                }
            }
        }

        /* Test code for margin call transfered in DBA_CheckMarginCallPositionToRemove and called later PMSTA08594 - 140909 - PMO */
        if (removePositionFlg == false && GET_ID(domainPtr, A_Domain_FctDictId) != DictFct_OpList)
        { /* For the valuation */
            removePositionFlg = (POSPRIMARY_ENUM)GET_ENUM(pos,  ExtPos_PrimaryEn)   == PosPrimary_Derived
                              &&(POSNAT_ENUM)GET_ENUM(pos,      ExtPos_PosNatEn)    == PosNat_None
                              &&(OPNAT_ENUM)GET_ENUM(pos,       ExtPos_OpenOpNatEn) == OpNat_Adjust
                              &&(OPADJUSTNAT_ENUM)GET_ENUM(pos, ExtPos_AdjustNatEn) == OpAdjustNat_None
                              &&DATETIME_CMP(GET_DATETIME(pos,  ExtPos_EndDate), GET_DATETIME(domainPtr, A_Domain_InterpFromDate)) <= 0;

            if (removePositionFlg == false)
            { /* For the valuation, account adjustment position that must be removed */
                removePositionFlg = (POSPRIMARY_ENUM)GET_ENUM(pos,   ExtPos_PrimaryEn)   != PosPrimary_Primary  /* PMSTA-7110 - 100908 - PMO */
                                   &&(POSNAT_ENUM)GET_ENUM(pos,      ExtPos_PosNatEn)    == PosNat_AdjPos
                                   &&(OPNAT_ENUM)GET_ENUM(pos,       ExtPos_OpenOpNatEn) == OpNat_Adjust
                                   &&(OPADJUSTNAT_ENUM)GET_ENUM(pos, ExtPos_AdjustNatEn) == OpAdjustNat_MarginCall
                                   &&DATETIME_CMP(GET_DATETIME(pos,  ExtPos_EndDate), tmpDate) < 0;
            }
        }

	    if (removePositionFlg == false)
	    {
		    /* PMSTA-11030 - RAK - 101214 */
		    /* For the valuation, trans from acct1 to acct2 must be removed */
		    removePositionFlg = (POSPRIMARY_ENUM)GET_ENUM(pos,  ExtPos_PrimaryEn)   == PosPrimary_Second
                              &&(POSNAT_ENUM)GET_ENUM(pos,      ExtPos_PosNatEn)    == PosNat_AdjTransAcct
                              &&(OPNAT_ENUM)GET_ENUM(pos,       ExtPos_OpenOpNatEn) == OpNat_Adjust
                              &&(OPADJUSTNAT_ENUM)GET_ENUM(pos, ExtPos_AdjustNatEn) == OpAdjustNat_MarginCall;
	    }

        /* PMSTA-9072 - 050510 - PMO */
        if (removePositionFlg == false)
        {
            /*  PMSTA-20838 - 160715 - PMO
             *  Technical position used by the fusion engine only
             */
            removePositionFlg = DBA_IsTechnicalPosition(pos);
        }

        /* PMSTA-16533 - 221113 - PMO */
        if (removePositionFlg == false)
        {
            removePositionFlg = (POSPRIMARY_ENUM)   GET_ENUM(pos, ExtPos_PrimaryEn)   == PosPrimary_Primary
                             && (POSNAT_ENUM)       GET_ENUM(pos, ExtPos_PosNatEn)    == PosNat_AdjPos
                             && (OPNAT_ENUM)        GET_ENUM(pos, ExtPos_OpenOpNatEn) == OpNat_Adjust
                             && (OPADJUSTNAT_ENUM)  GET_ENUM(pos, ExtPos_AdjustNatEn) == OpAdjustNat_PartiallyPaid;
        }
#if 0 /* PMSTA-22130 - 160125 - DDV - This check has been added in DBA_IsTechnicalPosition. Code removed */
        /* PMSTA-17317 - 171213 - PMO */
        if (removePositionFlg == false)
        {
            removePositionFlg = (OPLOCKNAT_ENUM) GET_ENUM(pos, ExtPos_LockNatEn) == OpLockNat_LockData;
        }
#endif
    } /* End if */

    return removePositionFlg ? (FLAG_T)TRUE : (FLAG_T)FALSE;
}


/************************************************************************
**
**  Function         : DBA_CheckQuantity()
**
**  Description      : Check if quantity is matching domain parameters
**
**  Arguments        : domainPtr  domain pointer
**                     extPosPtr  pointer on position to check
**                     removePositionsForLogicalFusion (Must be FALSE if a logical fusion
**                                                      can be done because some position with zero
**                                                      quantity are need by the fusion process.
**                                                      After the logical fusion a call to
**                                                      DBA_CheckPositions can be done)
**
**  Return           : RET_SUCCEED or error code
**
** Creation Date     : REF7560 - DDV - 020722
** Last Modification : PMSTA-5219 - 140808 - PMO : Logical Fusion : When we use, operations with reference nature "Future FIFO" or "Future WMP" , the logical fusion is wrong
**                     PMSTA-5595 - 190808 - PMO : Margin call on Future / Wrong Cash account sign in Stock flow analysis
*************************************************************************/
EXTERN FLAG_T DBA_CheckQuantity(DBA_DYNFLD_STP    domainPtr,
                                DBA_DYNFLD_STP    extPosPtr,
                                const FLAG_T      removePositionsForLogicalFusion)
{
    FLAG_T zeroQtyFlg, zeroAccrAmtFlg, zeroPosNetAmtFlg;

    /* PMSTA-5219 - 140808 - PMO
     * This type of position is need by the logical fusion
     */
    if (removePositionsForLogicalFusion == FALSE
       &&((POSPRIMARY_ENUM)GET_ENUM(extPosPtr, ExtPos_PrimaryEn)     == PosPrimary_Primary
         &&(POSNAT_ENUM)GET_ENUM(extPosPtr, ExtPos_PosNatEn)         == PosNat_AdjPos
         &&(OPNAT_ENUM)GET_ENUM(extPosPtr, ExtPos_OpenOpNatEn)       == OpNat_Adjust
         &&(OPADJUSTNAT_ENUM)GET_ENUM(extPosPtr, ExtPos_AdjustNatEn) == OpAdjustNat_MarginCall
         )
         || DBA_CheckPositionToRemove(domainPtr, extPosPtr)    /* Function renamed PMSTA-6924 - 280109 - PMO / PMSTA-5595 - 190808 - PMO */
       )
    {
        zeroQtyFlg = FALSE;
    }
    else
    {
        if (IS_NULLFLD(extPosPtr, ExtPos_Qty) == TRUE ||
            CMP_NUMBER(GET_NUMBER(extPosPtr, ExtPos_Qty), 0.0) == 0)
            zeroQtyFlg = TRUE;
        else
            zeroQtyFlg = FALSE;
    }

    if (IS_NULLFLD(extPosPtr, ExtPos_AccrAmt) == TRUE ||
        CMP_NUMBER(GET_NUMBER(extPosPtr, ExtPos_AccrAmt), 0.0) == 0)
        zeroAccrAmtFlg = TRUE;
    else
        zeroAccrAmtFlg = FALSE;

    if (IS_NULLFLD(extPosPtr, ExtPos_PosNetAmt) == TRUE ||
        CMP_NUMBER(GET_NUMBER(extPosPtr, ExtPos_PosNetAmt), 0.0) == 0)
        zeroPosNetAmtFlg = TRUE;
    else
        zeroPosNetAmtFlg = FALSE;

    switch(GET_DICT(domainPtr, A_Domain_FctDictId))
    {
        case DictFct_OpHist:
	    case DictFct_OpList:
	    case DictFct_CurrencyModify:
	    case DictFct_CopyOperation:
            return(TRUE);
            break;
        case DictFct_FundValo:
            if (IS_NULLFLD(extPosPtr, ExtPos_BalPosTpId) == TRUE)
            {
                /* test for positions */
                if (zeroQtyFlg == FALSE || zeroAccrAmtFlg == FALSE)
                    return(TRUE);
                else
                    return(FALSE);
            }
            else
            {
                /* test for balance positions */
                if (zeroQtyFlg == FALSE || zeroPosNetAmtFlg == FALSE)
                    return(TRUE);
                else
                    return(FALSE);
            }

            break;

        default:
            if (GET_FLAG(domainPtr, A_Domain_ZeroQtyFlg) == FALSE)
            {
                if (zeroQtyFlg == FALSE || zeroAccrAmtFlg == FALSE)
                    return(TRUE);
                else
                    return(FALSE);
            }
            break;
	}

    return(TRUE);
}

/************************************************************************
**
**  Function         : DBA_LoadPPSForDomain()
**
**  Description      : Load all Portfolio position Set (PPS)
**                     matching the domain definition for one portfolio
**
**  Arguments        : ptfPtr     pointer on portfolio
**                     domainPtr  pointer on domain
**                     ppsTab     pointer to pps array to fill
**                     ppsNbr     int pointer
**
**  Return           : RET_SUCCEED or error code
**
** Creation Date     : REF7560 - DDV - 020708
** Last Modification :
**
*************************************************************************/
EXTERN RET_CODE DBA_LoadPPSForPtf(DBA_DYNFLD_STP    ptfPtr,
                                  DBA_DYNFLD_STP    domainPtr,
                                  DBA_DYNFLD_STP    **ppsTab,
                                  int               *ppsNbr)
{
    DBA_DYNFLD_STP  admArgPtr = NULLDYNST;
    int             i, j, nbPPSMatching = 0;
    RET_CODE        ret=RET_SUCCEED;

    if ((admArgPtr = ALLOC_DYNST(Adm_Arg)) == NULLDYNST)
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
        return(FALSE);
    }

    COPY_DYNFLD(admArgPtr, Adm_Arg, Adm_Arg_Id,
                ptfPtr, A_Ptf, A_Ptf_Id);

    /* Load all PPS */
    if ((ret = DBA_Select2(PtfPosSet, UNUSED, Adm_Arg, admArgPtr,
			               A_PtfPosSet, ppsTab, UNUSED, UNUSED,
			               ppsNbr, UNUSED, UNUSED)) != RET_SUCCEED)
    {
        FREE_DYNST(admArgPtr, Adm_Arg);
        return(ret);
    }
    FREE_DYNST(admArgPtr, Adm_Arg);

    /* reduce PPS list to all matching domain parameter */
    for (i=0; i<(*ppsNbr); i++)
    {
        /* REF7560 - DDV - For operation list generate position for all PPS */
        if (GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_OpList)
        {
            nbPPSMatching ++;
        }
        else if (GET_FLAG(domainPtr, A_Domain_PpsCurrFlg) == FALSE ||
                 CMP_DYNFLD((*ppsTab)[i], domainPtr,
                           A_PtfPosSet_CurrId, A_Domain_CurrId, IdType) == 0)
        {
            if (GET_FLAG(domainPtr, A_Domain_PpsTypeFlg) == FALSE ||
                CMP_DYNFLD((*ppsTab)[i], domainPtr,
                           A_PtfPosSet_TpId, A_Domain_PortPosSetId, IdType) == 0)
            {
                if (GET_FLAG(domainPtr, A_Domain_PpsConsPflFlg) == FALSE ||
                    CMP_DYNFLD((*ppsTab)[i], domainPtr,
                               A_PtfPosSet_ConsPtfId, A_Domain_ConsPtfId, IdType) == 0)
                {
                    nbPPSMatching ++;
                }
                else
                    FREE_DYNST((*ppsTab)[i], A_PtfPosSet);
            }
            else
                FREE_DYNST((*ppsTab)[i], A_PtfPosSet);
        }
        else
            FREE_DYNST((*ppsTab)[i], A_PtfPosSet);
    }

    if (nbPPSMatching == 0)
    {
        DBA_FreeDynStTab((*ppsTab), (*ppsNbr), A_PtfPosSet);
        *ppsNbr=0;
        return(RET_SUCCEED);
    }

    for (i=0; i<(*ppsNbr); i++)
    {
        if ((*ppsTab)[i] == NULLDYNST)
        {
            for (j=i; j<(*ppsNbr)-1; j++)
                (*ppsTab)[j] = (*ppsTab)[j+1];
            (*ppsNbr)--;
            (*ppsTab)[(*ppsNbr)] = NULLDYNST;
            i--;
        }

    }

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function         : DBA_CheckPPSDim()
**
**  Description      : Check if Portfolio position Set (PPS)
**                     is include for domain PPS parameters
**                     This function is based on stored proc ini_exd_position_by_pps
**
**  Arguments        : extPosPtr  pointer on position to check
**                     domainPtr  domain pointer
**                     hierHead   hierarchy pointer
**                     instrPtr   instrument pointer
**
**  Return           : RET_SUCCEED or error code
**
** Creation Date     : REF7560 - DDV - 020614
** Last Modification :
**
*************************************************************************/
EXTERN FLAG_T DBA_CheckPPSDim(DBA_DYNFLD_STP    extPosPtr,
                              DBA_DYNFLD_STP    domainPtr,
                              DBA_DYNFLD_STP    *ppsTab,
                              int               ppsNbr)
{
    int     i;

     /* REF7560 - DDV - For operation list generate position for all PPS */
    if (GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_OpList)
            return(TRUE);

    if (GET_ENUM(domainPtr, A_Domain_PpsLoadEn) == Domain_PpsLoadEn_NoPps)
    {
        if (IS_NULLFLD(extPosPtr, ExtPos_PtfPosSetId) == FALSE)
            return(FALSE);
        else
            return(TRUE);
    }

    if (ppsNbr == 0)
    {
        /* if PPSLoadEn is Domain_PpsLoadEn_LoadPpsOrDflt and no PPS matching, then accept main */
        if (GET_ENUM(domainPtr, A_Domain_PpsLoadEn) == Domain_PpsLoadEn_LoadPpsOrDflt &&
            IS_NULLFLD(extPosPtr, ExtPos_PtfPosSetId) == TRUE)
            return(TRUE);
        else
            return(FALSE);
    }

    /* if it is a main position then refuse it (There are matching PPS) */
    if (IS_NULLFLD(extPosPtr, ExtPos_PtfPosSetId) == TRUE)
        return(FALSE);

    for (i=0; i<ppsNbr; i++)
    {
        if (ppsTab[i] != NULLDYNST &&
            CMP_DYNFLD(ppsTab[i], extPosPtr,
                       A_PtfPosSet_Id, ExtPos_PtfPosSetId, IdType) == 0)
        {
            return(TRUE);
        }

    }

	return(FALSE);
}

/************************************************************************
**
**  Function         : DBA_CheckPtfDim()
**
**  Description      : Check if portfolio is include in portfolio dimension
**                     from domain
**
**  Arguments        : domainPtr  domain pointer
**                     hierHead   hierarchy pointer
**                     instrPtr   instrument pointer
**
**  Return           : RET_SUCCEED or error code
**
** Creation Date     : REF7560 - DDV - 020719
** Last Modification :
**
**  REF11404 EFE 051013 : add management of third parties in valo.
*************************************************************************/
EXTERN FLAG_T DBA_CheckPtfDim(DBA_DYNFLD_STP    domainPtr,
                              DBA_HIER_HEAD_STP hierHead,
                              ID_T              ptfId,
                              DBA_DYNFLD_STP    ptfPtrParam,
                              DBA_DYNFLD_STP    *listPtr,
                              FLAG_T            listHistoflg,
                              DATETIME_STP      dateHisto,
                              DBA_DYNFLD_STP    *ptfTab,
                              int               ptfNbr)
{
	OBJECT_ENUM     ptfDim=NullEntity;
    DBA_DYNFLD_STP  ptfPtr = ptfPtrParam;
	FLAG_T          result = FALSE, ptfAllocFlg = FALSE;
    DBA_DYNFLD_STP  evalRec = (DBA_DYNFLD_STP)NULL, admArg = NULLDYNST;
    DBA_DYNFLD_STP  *ptfThirdCompoTab = NULLDYNSTPTR;
    SCPT_ARG_STP    qSearchTree;
    int             incrNb = 0, i=0, ptfThirdCompoNbr=0;

	DBA_GetObjectEnum(GET_DICT(domainPtr, A_Domain_DimPtfDictId), &ptfDim);

    /* PMSTA00469 - DDV - 061026 - If ptfTab is given, use it to check the portfolio */
    if (ptfTab != NULLDYNSTPTR && ptfNbr != 0)
    {
        for (i=0;i<ptfNbr;i++)
        {
            if (GET_ID(ptfTab[i], A_Ptf_Id) == ptfId)
                return(TRUE);
        }
        return(FALSE);
    }


    /* REF8844 - LJE - 030415 */
	if (ptfDim == NullEntity)
    {
        return(TRUE);
    }
    else if (ptfDim == Ptf)
    {
		if (ptfId == GET_ID(domainPtr, A_Domain_PtfObjId))
            result = TRUE;	/* REF9291 - RAK - 030717 */
		else
            result = FALSE;	/* REF9291 - RAK - 030717 */
    }
        /*<REF11404-EFE-051013*/
    else if (ptfDim == Third)
    {
        if (ptfPtr == NULLDYNST)
        {
            DBA_GetPtfById(ptfId, FALSE, &ptfAllocFlg, &ptfPtr, hierHead,UNUSED, UNUSED);
        }

        if (GET_ENUM(domainPtr, A_Domain_ThirdCompoEn) == PtfThirdCompo_DirectAndIndirect ||
            GET_ENUM(domainPtr, A_Domain_ThirdCompoEn) == PtfThirdCompo_Direct)
		{
			if (CMP_DYNFLD(ptfPtr, domainPtr,
						   A_Ptf_ThirdId, A_Domain_PtfObjId, IdType) == 0)
				result = TRUE;
		}


        /* PMSTA12465 - DDV - 110822 - Load PttThirdCompo and check if Third define in domain is found */
        if (result == FALSE &&
            (GET_ENUM(domainPtr, A_Domain_ThirdCompoEn) == PtfThirdCompo_DirectAndIndirect ||
             GET_ENUM(domainPtr, A_Domain_ThirdCompoEn) == PtfThirdCompo_Indirect))
        {
            if ((admArg = ALLOC_DYNST(Adm_Arg)) == NULLDYNST)
            {
                if (ptfAllocFlg == TRUE)
                    FREE_DYNST(ptfPtr, A_Ptf);

                return(FALSE);
            }

            SET_ID(admArg, Adm_Arg_Id, ptfId);
            COPY_DYNFLD(admArg, Adm_Arg, Adm_Arg_Date,
                        domainPtr, A_Domain, A_Domain_InterpFromDate);

            if (DBA_Select2(PtfThirdCompo, UNUSED, Adm_Arg, admArg,
			                S_PtfThirdCompo, &ptfThirdCompoTab, UNUSED, UNUSED,
			                &ptfThirdCompoNbr, UNUSED, UNUSED) != RET_SUCCEED)
            {
                if (ptfAllocFlg == TRUE)
                    FREE_DYNST(ptfPtr, A_Ptf);

                FREE_DYNST(admArg, Adm_Arg);

                return(FALSE);
            }

            FREE_DYNST(admArg, Adm_Arg);

            for (i=0; i<ptfThirdCompoNbr && result == FALSE; i++)
            {
		        if (CMP_DYNFLD(ptfThirdCompoTab[i], domainPtr,
				    	       S_PtfThirdCompo_ThirdId, A_Domain_PtfObjId, IdType) == 0)
                {
                    result = TRUE;
                }
            }

            DBA_FreeDynStTab(ptfThirdCompoTab, ptfThirdCompoNbr, S_PtfThirdCompo);
        }
    }
    /*>REF11404-EFE-051013*/
    else if (ptfDim == QuickSearch || ptfDim == DomainPtfCompo)  /*NRAO- PMSTA-41967 - Handle Domain Ptf compo*/
    {
		DBA_DYNFLD_STP tascJobSt=NULL;

		if (ptfPtr == NULLDYNST)
        {
            DBA_GetPtfById(ptfId, FALSE, &ptfAllocFlg,
                             &ptfPtr, hierHead,UNUSED, UNUSED);
        }

		/* PMSTA08246 - LJE - 090615 */
		if (IS_NULLFLD(domainPtr, A_Domain_PtfListDef)   == TRUE  &&
			IS_NULLFLD(domainPtr, A_Domain_JobReference) == FALSE)
		{
			int		connectNo  = NO_VALUE,
					getOptions = UNUSED;

			result = FALSE;

			if ((tascJobSt = ALLOC_DYNST(A_TascJob)) != NULL  &&
				DBA_Get2(TascJob,
						 UNUSED,
						 A_Domain,
						 domainPtr,
		 				 A_TascJob,
						 &tascJobSt,
                         UNUSED,
                         UNUSED,
						 UNUSED) == RET_SUCCEED  &&
				IS_NULLFLD(tascJobSt, A_TascJob_PortfoliosetTbName) == FALSE)
			{
				DBA_DYNFLD_STP ioIdSt=NULL, searchArgSt=NULL;

				if ((searchArgSt = ALLOC_DYNST(Arg_Test)) != NULL)
				{
                    /* PMSTA09969 - DDV - 100601 - Allocate ioIdSt to make get2 working */
    				if ((ioIdSt = ALLOC_DYNST(Io_Id)) != NULL)
	    			{
						SET_ID(searchArgSt, Arg_Test_Id, GET_ID(tascJobSt, A_TascJob_Id));     /* PMSTA-31569 - TEB - 180530 */
			    		SET_ID(searchArgSt, Arg_Test_Id2, ptfId);

                        /* PMSTA09969 - DDV - 100601 - Add chunk_number */
                        if (IS_NULLFLD(domainPtr, A_Domain_ChunkNumber) == FALSE)
                            {SET_INT(searchArgSt, Arg_Test_Int, GET_INT(domainPtr, A_Domain_ChunkNumber));}
                        else
                            {SET_INT(searchArgSt, Arg_Test_Int, 1);}

				    	if (DBA_Get2(TascJob,
					    	  		 UNUSED,
						    		 Arg_Test,
							    	 searchArgSt,
		 						    Io_Id,
    								 &ioIdSt,
	    							 getOptions,
		    						 &connectNo,
			    					 UNUSED) == RET_SUCCEED &&
					    	IS_NULLFLD(ioIdSt, Io_Id_Id) == FALSE)
    					{
	    					result = TRUE;
		    			}

    				    FREE_DYNST(ioIdSt, Io_Id);
	    			}

    			    FREE_DYNST(searchArgSt, Arg_Test);
				}

    			FREE_DYNST(tascJobSt, A_TascJob);
			}
		}
		else if (ptfDim == QuickSearch)
		{
			if (SCPT_PrepTreeForFilter(GET_STRING(domainPtr, A_Domain_PtfListDef),
									   hierHead, domainPtr, Ptf,
									   &qSearchTree,0, NULLDYNSTPTR) == RET_SUCCEED) /* REF7758 - LJE - 020920 */
			{
				if (SCPT_IsRemoveWithFilterTree(hierHead, Ptf,
													 &qSearchTree, ptfPtr,
													 &evalRec, &incrNb) == TRUE)  /* PMSTA-21701 - 151116 - DDV - Remove HierElt arguments */
					result = FALSE;
				else
					result = TRUE;

				SCPT_FreeTreeForFilter(&qSearchTree);
			}
		}
		else  /*PMSTA-41967 - Ravindra - Handle Domain Ptf composition */
		{
			DBA_DYNFLD_STP	 ptfHierPtr = NULL;
			if (hierHead != NULL)
			{
				if (DBA_GetRecPtrFromHierById(hierHead, ptfId, A_Ptf, &ptfHierPtr) == RET_SUCCEED && ptfHierPtr != NULL) {
					if (ptfId == GET_ID(ptfHierPtr, A_Ptf_Id))
						result = TRUE;
					else
						result = FALSE;
				}
				else {
					result = FALSE;
				}
			}
		}

        if (ptfPtrParam == NULLDYNST && ptfAllocFlg == TRUE)
        {
            if (result == TRUE)
                DBA_AddHierRecord(hierHead, ptfPtr, A_Ptf, FALSE, HierAddRec_ForceInsert);
			else
                FREE_DYNST(ptfPtr, A_Ptf);
        }

		/* REF9291 - RAK - 030717 - wait the end */
        /* return(result); */
    }
    else if (ptfDim == List)
    {
        FIN_IsInList(hierHead, ptfId, ptfPtrParam, Ptf, GET_ID(domainPtr, A_Domain_PtfObjId), listPtr,  /* REF8857 - LJE - 030228 */
                     UNUSED, listHistoflg, dateHisto, &result);

		/* REF9291 - RAK - 030717 - wait the end */
        /* return(result); */
    }
	
	/* REF9291 - RAK - 030717 - verify if parent portfolio belong to domain */
	if (result == FALSE && GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None)
	{
		ptfAllocFlg = FALSE;
		if (ptfPtr == NULLDYNST)
        {
            DBA_GetPtfById(ptfId, FALSE, &ptfAllocFlg,
                           &ptfPtr, hierHead, UNUSED, UNUSED);
        }

		if (ptfPtr != NULLDYNST &&
			IS_NULLFLD(ptfPtr, A_Ptf_HierPortId) == FALSE &&
			GET_ID(ptfPtr, A_Ptf_HierPortId) != ptfId)
		{
			/* Call Check function with parent portfolio (don't send struct just identifier) */
			ptfId = GET_ID(ptfPtr, A_Ptf_HierPortId);

			result = DBA_CheckPtfDim(domainPtr, hierHead, ptfId, NULLDYNST,
									 listPtr, listHistoflg, dateHisto, ptfTab, ptfNbr);
		}

		if (ptfPtrParam == NULLDYNST && ptfAllocFlg == TRUE)
        {
            if (result == TRUE)
                DBA_AddHierRecord(hierHead, ptfPtr, A_Ptf, FALSE, HierAddRec_ForceInsert);
			else
                FREE_DYNST(ptfPtr, A_Ptf);
        }

		/* PMSTA04637-CHU-080215 - make sure we get child positions */
		if (result == FALSE && IS_NULLFLD(domainPtr, A_Domain_FullLoadHierOldPtfId) == FALSE)
			result = TRUE;
	}

	return(result);
}

/************************************************************************
**
**  Function         : DBA_CheckInstrDim()
**
**  Description      : Check if instrument is include instrument dimension
**                     from domain
**
**  Arguments        : domainPtr  domain pointer
**                     hierHead   hierarchy pointer
**                     instrPtr   instrument pointer
**
**  Return           : RET_SUCCEED or error code
**
** Creation Date     : 990308 - XDI - REF3205
** Last Modification : REF7560 - DDV - Add QSearch dimension
**
*************************************************************************/
EXTERN FLAG_T DBA_CheckInstrDim(DBA_DYNFLD_STP    domainPtr,
                                DBA_HIER_HEAD_STP hierHead,
                                ID_T              instrId,
                                DBA_DYNFLD_STP    instrPtrParam,
                                DBA_DYNFLD_STP    *listPtr,
                                int               *connectNoParam,
                                FLAG_T            listHistoflg,
                                DATETIME_STP      dateHisto,
                                FLAG_T            isPEFundShare)
{
	OBJECT_ENUM     instrDim=NullEntity;
    DBA_DYNFLD_STP  instrPtr = instrPtrParam;
	FLAG_T          result = FALSE, instrAllocFlg = FALSE;
    DBA_DYNFLD_STP  evalRec = (DBA_DYNFLD_STP)NULL;
    SCPT_ARG_STP    qSearchTree;
    int             incrNb = 0;

	if (instrId < 0 && instrPtr != NULL)
		instrId = GET_ID(instrPtr, A_Instr_ParentInstrId);

	DBA_GetObjectEnum(GET_DICT(domainPtr, A_Domain_DimInstrDictId), &instrDim);

	if (instrDim == NullEntity)
    {
        result = TRUE;
    }
    else if (instrDim == Instr)
    {
		if (instrId == GET_ID(domainPtr, A_Domain_InstrObjId))
            result = TRUE;
        else
            result = FALSE;
    }
    else if (instrDim == QuickSearch)
    {
        if (instrPtr == NULLDYNST)
        {
            DBA_GetInstrById(instrId, FALSE, &instrAllocFlg,
                             &instrPtr, hierHead,UNUSED, UNUSED);
        }

		if (SCPT_PrepTreeForFilter(GET_STRING(domainPtr, A_Domain_InstrListDef),
                                   hierHead, domainPtr, Instr,
                                   &qSearchTree,0, NULLDYNSTPTR) == RET_SUCCEED) /* REF7758 - LJE - 020920 */
		{
			if (SCPT_IsRemoveWithFilterTree(hierHead, Instr,
                                                 &qSearchTree, instrPtr,
                                                 &evalRec, &incrNb) == TRUE)  /* PMSTA-21701 - 151116 - DDV - Remove HierElt arguments */
                result = FALSE;
            else
                result = TRUE;

			SCPT_FreeTreeForFilter(&qSearchTree);
		}

        if (instrPtrParam == NULLDYNST && instrAllocFlg == TRUE)
        {
            if (result == TRUE)
                DBA_AddHierRecord(hierHead, instrPtr, A_Instr, FALSE, HierAddRec_ForceInsert);
            else
                FREE_DYNST(instrPtr, A_Instr);
        }
    }
    else if (instrDim == List)
    {
        FIN_IsInList(hierHead, instrId, instrPtrParam, Instr, GET_ID(domainPtr, A_Domain_InstrObjId), listPtr,
                     connectNoParam, listHistoflg, dateHisto, &result);

    }

    if (result == FALSE && isPEFundShare == FALSE && instrPtrParam != NULLDYNST &&
        DBA_IsPEFundShare(instrPtrParam, SubNat_None) == TRUE &&
        (GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_Journal ||
         GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_EventGeneration))
    {
        DBA_DYNFLD_STP *linkedInstrTab = NULLDYNSTPTR;
        int linkedInstrNbr = 0, i = 0;
        FLAG_T freeLinkedInstrTab = FALSE;

        DBA_GetAllLinkedInstrsForPE(hierHead, instrPtrParam, &linkedInstrTab, &linkedInstrNbr, &freeLinkedInstrTab);

        for (i = 0; i < linkedInstrNbr && result == FALSE; i++)
        {
            if ((CMP_ID(GET_ID(linkedInstrTab[i], A_Instr_Id), GET_ID(instrPtrParam, A_Instr_Id)) != 0) &&
                CMP_DYNFLD(linkedInstrTab[i], instrPtrParam, A_Instr_CommonRef, A_Instr_CommonRef, InfoType) == 0) /*PMSTA-37628 - AIS - 191029*/
            {
                result = DBA_CheckInstrDim(domainPtr, hierHead, GET_ID(linkedInstrTab[i], A_Instr_Id), linkedInstrTab[i],
                                           listPtr, NULL, FALSE, NULL, TRUE);
            }
        }
        if (freeLinkedInstrTab == TRUE)
        {
            FREE(linkedInstrTab);
        }
    }
    return(result);
}


/************************************************************************
 **   END  dbaexec.c
 *************************************************************************/

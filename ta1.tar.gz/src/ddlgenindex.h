/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef DDLGENINDEX_H
#define DDLGENINDEX_H

#include      "ddlgen.h"

/************************************************************************
**      Constant & Macro definitions
*************************************************************************/

/************************************************************************
**      Structures & typedef definitions
*************************************************************************/

/************************************************************************
**      External definitions attached to : ddlgenindex.cpp
*************************************************************************/
#ifdef  EXTERN
#undef	EXTERN
#endif
#ifdef  DDLGENINDEX_CPP
#define	EXTERN
#else
#define EXTERN extern
#endif

class DdlGenIndex :public DdlGen {

public:
    typedef std::unique_ptr<DdlGenIndex> Ptr;

    // Constructors
    DdlGenIndex(OBJECT_ENUM           paramObjectEn,
                std::string           paramIdxSqlNameOnly,
                DdlGenContext        &paramDdlGenContext,
                DdlGenEntity         *paramDdlGenEntityPtr,
                DdlGenFile           *paramFileHelper,
                TARGET_TABLE_ENUM     paramTargetTableEn);

    DdlGenIndex(OBJECT_ENUM       paramObjectEn,
                DdlGenContext    &paramDdlGenContext,
                DdlGenEntity     *paramDdlGenEntityPtr,
                TARGET_TABLE_ENUM paramTargetTableEn);

    DdlGenIndex(const DdlGenIndex&) = delete;

    // Destructor
    virtual ~DdlGenIndex();

    // Methods
    DdlGenIndex& operator = (const DdlGenIndex&) = delete;
    RET_CODE          build();
    RET_CODE          setSpecificIdx(DBA_IDX_FUNCTION_ENUM paramIndexFunctionEn,
                                     bool                  paramUniqueOnly,
                                     bool                  paramClusteredOnly);

    std::string       getCreateCmd(bool bOneLine);

    enum class DuplicateManagment
    {
        None,
        Delete,
        LogOnly,
        External
    };

    DuplicateManagment           m_duplicateManagment;
    std::vector<std::string>     m_onErrorRequests;

protected:
    // 
    DBA_IDX_FUNCTION_ENUM indexFunctionEn;
    bool                  bUniqueOnly;
    bool                  bClusteredOnly;
    std::string           idxSqlNameOnly;

    // Methods
    RET_CODE         printFooter();
                     
    RET_CODE         checkAndFixData(DdlGenRequestHelper &);
    RET_CODE         drop(DdlGenRequestHelper &);
    RET_CODE         create(DdlGenRequestHelper *);
    RET_CODE         grant();

    RET_CODE         removeDuplicates();
                     
    RET_CODE         setIndexStatus(DdlGenRequestHelper &, XD_STATUS_ENUM, bool);
                     
    RET_CODE         setName();

    std::string      getCurrSegmentSqlName();

    DBA_DYNFLD_STP   shDictSegmentStp;

private:
    //
    DBA_DYNFLD_STP   currXdIndexStp;
    DBA_DYNFLD_STP   currSysXdIndexStp;
    bool             bIdxByExternalInfo;
};


#endif	                               /* ifndef DDLGENINDEX_H */
/************************************************************************
**      END       ddlgenindex.h                                   Odyssey
*************************************************************************/

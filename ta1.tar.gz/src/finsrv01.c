/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines      
*************************************************************************/
#define FINSRV01_C

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H
#define MATH_H

#include "unidef.h"         /* Mandatory */
#include "gen.h"
#include "date.h"
#include "dba.h"
#include "hier.h"
#include "fin.h"
#include "finsrv.h"
#include "srvstra.h"
#include "scelib.h"

#ifndef TLS_H
#include "tls.h"
#endif

#include "ope.h"
#include "scptyl.h"
#include "serv.h"
#include "fus.h"
#include "dbaexec.h"

/************************************************************************
**      External entry points
**
** FIN_AnalysisJournal()     Make a journal on a position set
**
*************************************************************************/

/************************************************************************
**      FIN tools
**
** FIN_JournalProcess()      Compute position set flows and generate new pos 
**
*************************************************************************/

/************************************************************************
**      Local functions
**
** FIN_CmpPosInstr()           Comparison fct to sort positions by instrument
** FIN_FilterFlow()            used to extract all flow from hierarchy
** FIN_GeneratePosition()      Generate new operation
** FIN_GenExtOpNewInstrPrice() Search new instrument price. (cash = exchange, FIN_InstrPrice())
**
*************************************************************************/

/************************************************************************
**      Static definitions & data
*************************************************************************/
#ifdef AAATIMER
static TIMER_ST SV_FIN_GeneratePos;
static TIMER_ST SV_TOT_FIN_GeneratePos;
#endif

STATIC RET_CODE FIN_GeneratePosition(DBA_HIER_HEAD_STP, ID_T,
				     FUSDATERULE_ENUM, OPSTAT_ENUM, 
		                     DBA_DYNFLD_STP, DBA_DYNFLD_STP,
                                     DICT_FCT_ENUM, DATETIME_T, EVTPLRULE_ENUM,
		                     DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, 
                                     DBA_DYNFLD_STP *, int, DBA_DYNFLD_STP *, DATETIME_T),
                FIN_GenExtOpExchFlow(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, 
                                     DBA_DYNFLD_STP*, DBA_HIER_HEAD_STP, 
                                     FLAG_T*, FLAG_T,
                                     RNDRULE_ENUM, QTYTYPE_ENUM, QTYTYPE_ENUM, FLAG_T),	/* REF3929 - SSO - 990909 */
                FIN_GenExtOpTermFlow(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, 
				     /*DBA_DYNFLD_STP* ,*/ DBA_DYNFLD_STP*, DBA_HIER_HEAD_STP, 
				     DATETIME_T, FLAG_T*, int, int*, EVTPLRULE_ENUM, 
				     EVTPLRULE_ENUM, OBJECT_ENUM*, FLAG_T*),
		FIN_GenExtOpNewInstrPrice(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DATETIME_T, 
					  DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, FLAG_T*),	/* REF233 */
                FIN_GetValoResult(DBA_HIER_HEAD_STP , ID_T , NUMBER_T *),
                FIN_ComputeIncomeQty(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, double *);

STATIC int      FIN_CmpPosInstr(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *),
                FIN_CmpPosPtfInstr(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *),
 		FIN_FilterFlow(DBA_DYNFLD_STP , DBA_DYNST_ENUM, DBA_DYNFLD_STP), /* REF7264 - DDV - 020325 - Compil C++ */
        FIN_FilterRemoveTechnical(DBA_DYNFLD_STP , DBA_DYNST_ENUM, DBA_DYNFLD_STP),         /* PMSTA-22130 - DDV - 160125 - Filter technical positions */
 		FIN_FilterStandingInstruction(DBA_DYNFLD_STP , DBA_DYNST_ENUM, DBA_DYNFLD_STP), /* PMSTA06761 - DDV - 080811 */
		FIN_FilterPEFundPos(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP); /*PMSTA-32106 -NRAO 180904*/

STATIC RET_CODE FIN_CheckExistPos(DBA_DYNFLD_STP *, int, DBA_DYNFLD_STP, DBA_DYNFLD_STP *, 
                                  DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, FLAG_T *, FLAG_T, DBA_DYNFLD_STP, FLAG_T); /* REF3939 - CSY - 000105 */
STATIC RET_CODE FIN_ComputeTheoPrice(ID_T,ID_T,DBA_DYNFLD_STP,DBA_DYNFLD_STP, DATETIME_T,/* REF3740 - AKO - 990701 */ /* PMSTA01649 - TGU - 070402 */
				     DBA_HIER_HEAD_STP,FLAG_T,NUMBER_T,NUMBER_T,ID_T, EVTDATERULE_ENUM, PRICE_T*); /* REF4075 - CSY - 991027 */
STATIC RET_CODE FIN_SplitExtOpForJrnl(DBA_DYNFLD_STP,ID_T, FUSDATERULE_ENUM, DBA_DYNFLD_STP,
					  DBA_HIER_HEAD_STP,DBA_DYNFLD_STP,DBA_DYNFLD_STP,DBA_DYNFLD_STP);
STATIC RET_CODE	FIN_ComputePropAttribPrice(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP,DBA_DYNFLD_STP);
STATIC int FIN_CmpExtopByDate(DBA_DYNFLD_STP*, DBA_DYNFLD_STP*);
STATIC int FIN_FilterPropAttrib(DBA_DYNFLD_STP, DBA_DYNST_ENUM ,DBA_DYNFLD_STP); /* REF7264 - DDV - 020326 - Compil C++ */
STATIC RET_CODE	FIN_CreatePropAttribCashOpe(DBA_DYNFLD_STP, DBA_DYNFLD_STP, 
					    DBA_HIER_HEAD_STP,DATETIME_T, FLAG_T*, NUMBER_T);
STATIC FLAG_T FIN_IsLockedPos(DBA_DYNFLD_STP stock); /* REF10793 - DDV - 041130 */

STATIC RET_CODE FIN_EvtGenerationSession(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP);	/* PMSTA06761 - RAK - 080730 */

STATIC RET_CODE FIN_GenerateStandInstructOp(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP,  DBA_DYNFLD_STP, DBA_DYNFLD_STP *, int, DBA_DYNFLD_STP *, 
    DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP *,AMOUNT_T =0 ,bool = FALSE);

STATIC int FIN_CmpPlanInvestHistoByPlanDefIdBeginDate(DBA_DYNFLD_STP, DBA_DYNFLD_STP),
           FIN_CmpFreeDepositHistoByPlanDefIdInvestDate(DBA_DYNFLD_STP, DBA_DYNFLD_STP),
           FIN_FilterValidSI(DBA_DYNFLD_STP , DBA_DYNST_ENUM , DBA_DYNFLD_STP ),
           FIN_CmpStandInstructWeight(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *);

extern RET_CODE DBA_TabulaRasa(ID_T, CASEMANAGEMENTNAT_ENUM, int*); /* OCS-39365-CHU-111017 */

STATIC RET_CODE FIN_GetPlanRecordsByDate(DATETIME_T, DBA_DYNFLD_STP, DBA_DYNFLD_STP *, DBA_DYNFLD_STP *, DBA_DYNFLD_STP *);
STATIC RET_CODE FIN_ComputeMinMaxAmt(DBA_DYNFLD_STP, DBA_DYNFLD_STP, AMOUNT_T *, AMOUNT_T *, FLAG_T *, FLAG_T *, AMOUNT_T *);							  
STATIC RET_CODE FIN_ComputeObjectivePeriod(DATE_T, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DATE_T *, DATE_T *, AMOUNT_T, AMOUNT_T, FLAG_T *, FLAG_T *, AMOUNT_T *, AMOUNT_T *, AMOUNT_T);
STATIC RET_CODE FIN_LoadPeriodInvestedAmt(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DATE_T, DATE_T, AMOUNT_T *);								   
STATIC RET_CODE FIN_ComputeAmtToInvest(DATE_T, DATE_T, DATE_T, AMOUNT_T, AMOUNT_T, AMOUNT_T, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, AMOUNT_T *);
STATIC RET_CODE FIN_AddEventExtOpInHier(DBA_DYNFLD_STP, DICT_T, ID_T, FUSDATERULE_ENUM, DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP);
STATIC RET_CODE FIN_AddCashTranfertOpInHier(DBA_DYNFLD_STP, OPNAT_ENUM, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP *, int, DBA_DYNFLD_STP *);
STATIC RET_CODE FIN_GenerateWithrawalAndInvestOp(DATETIME_T, DBA_DYNST_ENUM, DBA_DYNFLD_STP, ID_T, ID_T, AMOUNT_T *, OPSTAT_ENUM, CODE_T, INT_T, DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP *, int, DBA_DYNFLD_STP *);
STATIC RET_CODE FIN_ManageOneInvestPlan(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP *, int, DBA_DYNFLD_STP *, FLAG_T, FLAG_T, DBA_DYNFLD_STP, DBA_DYNFLD_STP *, int);
STATIC RET_CODE FIN_ManageAllInvestPlan(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP *, int, DBA_DYNFLD_STP *, FLAG_T, FLAG_T);
STATIC RET_CODE FIN_CheckAndUpdPlanInvestDate(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP *, int);
STATIC RET_CODE FIN_IndexAmt(AMOUNT_T *, ENUM_T, NUMBER_T);
STATIC RET_CODE FIN_CheckExistEventPos(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, NUMBER_T, FLAG_T*);
STATIC INT_T FIN_CalcEvtNbr(DATE_T);
STATIC int FIN_FilterEventExtPos(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);
STATIC int FIN_FilterEventExtPosNI(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);
STATIC RET_CODE FIN_SetLinkedInstrForPE(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, SUBNAT_ENUM, DBA_DYNFLD_STP); /*PMSTA-32106 -NRAO 180904*/
STATIC RET_CODE FIN_ExtractLinkedPEQtyFromHier(DBA_DYNFLD_STP,DBA_DYNFLD_STP, SUBNAT_ENUM, DBA_HIER_HEAD_STP, NUMBER_T *); /*PMSTA-32106 -NRAO 180904*/
STATIC RET_CODE FIN_ComputeMinMaxAmtWithPercentage(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, AMOUNT_T *, AMOUNT_T *, FLAG_T *, FLAG_T *, AMOUNT_T *);  /*PMSTA - 46093 - lalby - 11082021*/
EXTERN ID_T  getCashAcctId(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP);
EXTERN int FIN_startEltSort(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2);
STATIC RET_CODE FIN_GetCashBalanceFromInstrExt(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, AMOUNT_T *);
EXTERN RET_CODE FIN_CreateExtraOpForNotionalInstr(DBA_HIER_HEAD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, FIN_PTFINFO_STP,
            FIN_ORDERINFO_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, ENUM_T,ID_T, AMOUNT_T *, DBA_DYNFLD_STP, DBA_DYNFLD_STP = nullptr);
    

/************************************************************************
**  PMSTA-16124 - 250413 - PMO
**  UNUSED FUNCTION REMOVED BY: CMS 176466 
**
**
**  Function    : STATIC int FIN_CmpStandInstruct(void *arg1, void *arg2)
**
**  Description : order standing instruction by begin date
**
*************************************************************************/


/************************************************************************
**
**  Function         : FIN_AnalysisJournal()
**
**  Description      : Make a journal on a position set
**                     
**  Arguments        : domainPtr     domain structure pointer
**                     hierHead      position hierarchy header pointer
**
**  Return           : RET_SUCCEED or error code
**
** Creation Date     : April 95 - RAK
** Last Modification : 02/03/96 DD add event domain argument (DVP001)
** Modif.	     :	REF1211 - 980210 - RAK
**                  REF2580 - SSO - 980727
**      			REF3178 - SSO - 990106
**                  PMSTA7419 - EFE - 090313 : added a pointer on ptf for logical fusion
**                  PMSTA05966 - 090525 - PMO : Logical Fusion - Generic Money Market Instrument - Sell Operation with reference nature "Close" doesn't merge with respective "Open" Operation
**                  PMSTA-11645 - 170311 - PMO : Positions with sub position natures cannot be merged even when requested via a domain parameter
*************************************************************************/
RET_CODE FIN_AnalysisJournal(DBA_DYNFLD_STP domainPtr, DBA_HIER_HEAD_STP posHierHead)
{
	RET_CODE          ret;
	int               posNbr, i, fusionInitial = 0, fusionFinal=0;
	char              copyRecFlg;
	DBA_DYNFLD_STP    *extractPos=NULL;
	LOGICIDRULE_ENUM  logicIdRule;
	ID_T		  ptfId=UNUSED; /* REF3178 - SSO - 990106 */ 
	OBJECT_ENUM       dimPtfEn;	/* REF3178 - SSO - 990106 */ 
    GENINSTRRULE_ENUM   genInstrRule = GenInstrRule_MergeAll;

	/* PMSTA06761 - RAK - 080805 - Don't create flow and operation in case of Delete / Delete ALL */
	/* PMSTA28294 - RAK - 171215 - 9years after, do the same for Mutual Funds systematic plan (CreateSessionAndCheck) */
	/* PMSTA-28879 - RAK - 180108 - Mutual Fund Back end Mandatory : Batch : EvtGen_CheckSplitAndPublish */
	if	(GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_EventGeneration &&
		 (GET_ENUM(domainPtr, A_Domain_EvtGenNatEn) == EvtGen_CreateSession ||
		  GET_ENUM(domainPtr, A_Domain_EvtGenNatEn) == EvtGen_CreateSessionAndCheck ||
		  GET_ENUM(domainPtr, A_Domain_EvtGenNatEn) == EvtGen_CheckSplitAndPublish ||
          GET_ENUM(domainPtr, A_Domain_EvtGenNatEn) == EvtGen_CheckCaseSplitAndPublish) &&
		 (GET_ENUM(domainPtr, A_Domain_CompDataEn) == CompData_Delete || 
		  GET_ENUM(domainPtr, A_Domain_CompDataEn) == CompData_DeleteAll))
	{
			ret = FIN_EvtGenerationSession(domainPtr, posHierHead);
			return(ret);
	}

    GEN_GetApplInfo(ApplGenericInstrRule, &genInstrRule);

	copyRecFlg = FALSE;
	if ((ret = DBA_ExtractHierEltRec(posHierHead, ExtPos, 
					 copyRecFlg, NULL, FIN_CmpCheckLogicFus, /* REF1211 */
					 &posNbr, &extractPos)) != RET_SUCCEED)
		return(ret);

 	/* BUG196 - XDI - 961107 */
	if (posNbr == 0 && GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_Journal)
		return(RET_SUCCEED);

	if (GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_Journal)
	{
		/* Check if it is necessary to perform the fusion process. Take care of the positions order / PMSTA-11645 - 170311 - PMO */
        ret = FIN_CheckLogicalFusion(domainPtr, posHierHead, posNbr, extractPos, &logicIdRule);

		if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
		{
			FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
			return(ret);
		}  

		/* Convert ref. gross and net amounts in received ref. currency */
		if ((ret = FIN_UpdPosRefAmt(extractPos, posNbr, 
		       	GET_ID(domainPtr, A_Domain_CurrId), 
			(DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId), 
			posHierHead, domainPtr)) != RET_SUCCEED) /* REF2580 - SSO - 980727 */ /* REF6220 - LJE - 020319 */
		{
			FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
			return(ret);
		}

		/* convert sys amounts if necessary */
		if ((ret = FIN_UpdPosSysAmt(domainPtr, extractPos, posNbr)) != RET_SUCCEED) /* REF3178 - SSO - 990106 */
		{
			FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
			return(ret);
		}

		/* ExtPos moved because of their operation and value dates, -> force fusion */
		for (i=0; i < posNbr ; i++)
		{
			if (GET_ENUM(extractPos[i], ExtPos_NatEn) == ExtPosNat_InitStock)
				fusionInitial++;

			if (GET_ENUM(extractPos[i], ExtPos_NatEn) == ExtPosNat_FinalStock)
				fusionFinal++;
		}

		/* REF3178 - SSO - 990106 : if single ptf, give its if to the fusion */
		if (IS_NULLFLD(domainPtr, A_Domain_DimPtfDictId) == FALSE)
		{
		    DBA_GetObjectEnum(GET_DICT(domainPtr, A_Domain_DimPtfDictId), &dimPtfEn);
		    if (dimPtfEn == Ptf)
		    {
			ptfId = GET_ID(domainPtr, A_Domain_PtfObjId);
		    }
		}
		/*<PMSTA7419-EFE-090313*/
		DBA_DYNFLD_STP ptfPtr = NULL; 
		FLAG_T         allocFlg=FALSE;
        MemoryPool     mp;

        if ( ptfId > 0 && ( ret = DBA_GetPtfById(ptfId, FALSE, &allocFlg, &ptfPtr,
			                                     posHierHead , UNUSED, UNUSED) ) != RET_SUCCEED )
		{
	        FREE(extractPos);  /* Only array pointer */
		    return(ret);
		}
        /*>PMSTA7419-EFE-090313*/

        if (allocFlg == TRUE)
        {
            mp.ownerDynStp(ptfPtr);
        }

		/*if (ret == RET_SUCCEED) OLD CODE */
		if (fusionInitial > 1)
		{
	   		/* Perform a logical fusion (with no impact on database) on a */
	   		/* set of positions given as input. (initial stock position)  */
	   		/* At end of fusion, build an output set of positions         */
	   		/* containing only the positions still opened.                */
	   		if ((ret = FIN_LogicalFusion(
			     		GET_DATETIME(domainPtr, A_Domain_InterpFromDate), 
			     		posHierHead, FIN_FilterInitStock, NULL,
			     		(PTFFUSRULE_ENUM) GET_ENUM(domainPtr, A_Domain_FusRuleEn), /* REF7264 - DDV - 020325 - Compil C++ */
			     		logicIdRule,
					GET_FLAG(domainPtr,A_Domain_ClosPosFlg), ptfId, ptfPtr )) != RET_SUCCEED) /* PMSTA7419-EFE-090313*/
	   		{
				FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
				return(ret);
	   		}

		}

		if (fusionFinal > 1)
		{
	   		/* Perform a logical fusion (with no impact on database) on a */
	   		/* set of positions given as input. (final stock position)  */
	   		/* At end of fusion, build an output set of positions         */
	   		/* containing only the positions still opened.                */
	   		if ((ret = FIN_LogicalFusion(
			     		GET_DATETIME(domainPtr, A_Domain_CalcRefDate), 
			     		posHierHead, FIN_FilterFinalStock, NULL,
			     		(PTFFUSRULE_ENUM) GET_ENUM(domainPtr, A_Domain_FusRuleEn), /* REF7264 - DDV - 020325 - Compil C++ */
			     		logicIdRule,
					GET_FLAG(domainPtr,A_Domain_ClosPosFlg), ptfId, ptfPtr )) != RET_SUCCEED)  /* PMSTA7419-EFE-090313*/
	   		{
				FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
				return(ret);
	   		}
	   	}
		/* comment by sme optim
	   	if ((ret = DBA_SuppressHierEltRec(posHierHead, ExtPos, 
			      	                  FIN_FilterCloseStock)) != RET_SUCCEED)
	   	{
			FREE(extractPos);
			return(ret);
			}*/
	}

	FREE(extractPos);  /* Only array pointer, copy flag is FALSE */

	/* REF10175 - DDV - 041011 - Merge of generic MM  */
    if (genInstrRule == GenInstrRule_MergeAll && 
		(GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_Journal ||
		 GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_EventGeneration))
    {
		if ((ret = DBA_ExtractHierEltRec(posHierHead, ExtPos, 
										 FALSE, NULL, FIN_CmpPosInstrIdRefNat, &posNbr, &extractPos)) != RET_SUCCEED)   /* PMSTA05966 - 090525 - PMO */
		{
			return(ret);
		}

		for (i=0; i<posNbr;i++)
		{
	   		ret = DBA_GenericInstr(posHierHead, extractPos[i], extractPos, i,
                                   GET_DATETIME(domainPtr, A_Domain_InterpFromDate));  /* PMSTA05966 - 090525 - PMO */

	   		if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
	   		{
				FREE(extractPos); /* Only array pointer */
				return(ret);
	   		}
		}
			
		FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
	}

	/*** Search flows for filtered position on domain reference dates ***/
	return(FIN_JournalProcess(domainPtr, posHierHead, FIN_FilterPStock));
}

/************************************************************************
**
**  Function    :   FIN_FilterFinalAndNewTwoLegsAgainsPtfCurPos()
**
**  Description :   Extract final stock position and new position created by journal
**                  for instrument having as sub nature
**                  return TRUE  -> record must be extract
**                         FALSE -> record musn't be extract
**
**  Arguments   :   dynSt      dynamic structure pointer
**                  dynStTp    dynamic structure definition
**
**  Return      :   TRUE or FALSE
**
**  Creation    :   PMSTA-52091 - DDV - 230208
**
*************************************************************************/
int FIN_FilterFinalAndNewTwoLegsAgainsPtfCurPos(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP notUse)
{
    DBA_DYNFLD_STP  mainPosPtr = NULLDYNST;
    DBA_DYNFLD_STP  instrPtr = NULLDYNST;

    if ((IS_NULLFLD(dynSt, ExtPos_FlowId) == FALSE && GET_ENUM(dynSt, ExtPos_NatEn) == ExtPosNat_Flow) ||
        GET_ENUM(dynSt, ExtPos_NatEn) == ExtPosNat_FinalStock)
    {
        if (GET_FLAG(dynSt, ExtPos_MainFlg) == TRUE)
        {
            mainPosPtr = dynSt;
        }
        else
        {
            if (GET_EXTENSION_PTR(dynSt, ExtPos_Main_ExtPos_Ext) != NULL)
            {
                mainPosPtr = *(GET_EXTENSION_PTR(dynSt, ExtPos_Main_ExtPos_Ext));
            }
        }
    }

    if (mainPosPtr != NULLDYNST &&
        GET_EXTENSION_PTR(mainPosPtr, ExtPos_A_Instr_Ext) != NULL &&
        (instrPtr = *(GET_EXTENSION_PTR(mainPosPtr, ExtPos_A_Instr_Ext))) != NULL &&
        GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_FXFwd_TwoLegsAgainsPtfCurr)
    {
        return(TRUE);
    }

    return(FALSE);
}

/************************************************************************
**
**  Function         : FIN_JournalProcess()
**
**  Description      : Compute position flows and generate new positions.
**                      
**  Arguments        : domainPtr         domain structure pointer
**                     hierHead          extended position hierarchy header
**                     journalProcFilter filter for position to evaluate
**
**  Return           : RET_SUCCEED or error code
**
** Creation Date     : April 95 - RAK
** Last Modification : 02/03/96 DD add test for event operation generation
**                     Flow are stored into hierarchy, then flow structure 
**                     must not be free. (DVP001)
** Modif.            : REF1365 - RAK - 980316
** Modif.            : REF2669 - DDV - 980817 - Same hierarchy for journal and event generation
** Modif.            : REF3501 - RAK - 990326 - DebtFullCouponFlg
** Modif.            : REF3939 - CSY - 991015 - Operation date out of the domain
** Modif.            : REF3939 - CSY - 991103 - add listPtr parameter, required to check exist pos. 
** Modif.            : REF4146 - CSY - 991130 - generate flows and operations only for positions
**                                              that have status >= ACCOUNTING_STATUS
** Modif.            : REF4075 - CSY - 991208 - parameter A_Domain_EvtDateRuleEn passed to FIN_GenerateInstrFlows
** Modif.            : REF11218 - TEB - 050627
**                     PMSTA-22472 - 040316 - PMO : Income operation is not generating when in cash account value is NIL
**                     PMSTA-32116 - 200818 - PMO : [KD-1022A] WS - Structured Product - Instrument Financial Processing : Financial functions
**
*************************************************************************/
RET_CODE FIN_JournalProcess(DBA_DYNFLD_STP domainPtr,
                            DBA_HIER_HEAD_STP posHierHead,
		                    HIER_FLTFCT    *journalProcFilter) /* REF7264 - DDV - 020325 - Compil C++ */
{
	int               i, j, posNbr, extractFlowPosNbr = 0, 
                          flowNbr=0, connectNo = 0;
	char              copyRecFlg;
	DBA_DYNFLD_STP    *extractPos=NULL, 
	                  *extractFlowPos=NULL, 
			  *flowTab=NULL, instrPtr=NULL,
			  listPtr=NULL;
	ID_T		  oldInstrId=0;
	RET_CODE          ret;
	DBA_HIER_HEAD_STP hierHeadValo = NULL;/* REF7264 - DDV - 020325 - Compil C++ */
	FLAG_T              firstFlowTab = TRUE, fundValoDebtScriptFlag = FALSE,
	                  computeValo = FALSE, instrDimFlg = TRUE;
	OPSTAT_ENUM         opStatus, evtGenMinStatus;
	DATETIME_T	        fromDate,tillDate, tmpDate;
	DICT_T              initialFctDict;
    GENINSTRFLOW_ENUM   genInstrFlowEn = GenInstrFlow_Journal;  /* REF8866 - YST - 030311 */
	ID_T                refCurrDomain=0;                        /* REF6220 - LJE - 020319 */
    DATETIME_T			databaseDate;							/* PMSTA9969 - PRS - 101216 */
    bool                bIsInstrDCIorTCI = false;               /* PMSTA-34288 - CHU - 190202 */

    /* REF6220 - LJE - 020319 */
	if (domainPtr != NULL)
	{
	    refCurrDomain = GET_ID(domainPtr, A_Domain_CurrId);
	}


	DATE_RESET_TIMER (&SV_TOT_FIN_GeneratePos, TIMER_MASK_FIN);

	/* PMSTA07550 -.DDV - 090427 - Get the minimum operation status define in appl_param */
	GEN_GetApplInfo(ApplEvtGenMinStatus, &evtGenMinStatus);

	/* Get the status of operation to create */
	if (GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_EventGeneration) 
    {
		opStatus = (OPSTAT_ENUM) GET_ENUM(domainPtr, A_Domain_EvtOperStatEn);   /* REF7264 - DDV - 020325 - Compil C++ */
        genInstrFlowEn = GenInstrFlow_EvtGen;                                   /* REF8866 - YST - 030311 */
    }
	else
		GEN_GetApplInfo(ApplJournalFlowStatus, &opStatus);

	/* if mode is EvtGen_FlowInstr or  EvtGen_FlowInstrPtf, generate only Flows */
	if (GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_EventGeneration &&
	    (GET_ENUM(domainPtr, A_Domain_EvtGenNatEn) == EvtGen_FlowInstr ||
    	 GET_ENUM(domainPtr, A_Domain_EvtGenNatEn) == EvtGen_FlowInstrPtf))
	{
		if ((ret = DBA_ExtractHierEltRec(posHierHead,
                                        A_Instr,
                                        FALSE,
                                        NULL,
                                        NULL,
                                        &posNbr,
                                        &extractPos)) != RET_SUCCEED)
        {
            return(ret);
        }

		for (i=0; i<posNbr; i++)
		{
			instrPtr = extractPos[i];
		    /* Compute instrument flows */
		    ret = FIN_GenerateInstrFlows( 
	                            GET_DATETIME(domainPtr, A_Domain_CalcRefDate),
	   	                        GET_DATETIME(domainPtr, A_Domain_InterpTillDate),
	   	                        GET_DATETIME(domainPtr, A_Domain_CalcRefDate),
								FALSE,	/* PMSTA-9032 - RAK - 091216 */
		                        GET_ID(instrPtr, A_Instr_Id), instrPtr, 
           	                    GET_MASK64(domainPtr, A_Domain_EvtFlowSubNatLst),
           	                    (EVTGEN_ENUM) GET_ENUM(domainPtr, A_Domain_EvtGenNatEn), /* REF7264 - DDV - 020325 - Compil C++ */
                                (EVTDATERULE_ENUM) GET_ENUM(domainPtr, A_Domain_EvtDateRuleEn), /* REF7264 - DDV - 020325 - Compil C++ */ /* REF4075 - 991208 - CSY : A_Domain_PosValRuleEn field used
                                                                            for test,replaced with  A_Domain_EvtDateRuleEn*/
           	                    GET_FLAG(domainPtr, A_Domain_DebtFlg),
                                genInstrFlowEn,                     /* REF8866 - YST - 030311 */
								AccrRule_None,		                /* REF11218 - TEB - 050627 */
		                     	&flowTab, &flowNbr, posHierHead);   /* REF7264 - DDV - 020325 - Compil C++ */
			/* insert FlowTab into hierarchy */
			if (flowNbr > 0)
                        {
				if (ret == RET_SUCCEED)
				{
		  			if (DBA_AddHierRecordList(posHierHead, flowTab, flowNbr, Flow, FALSE) != RET_SUCCEED)
		  			{
						FREE(extractPos);
						DBA_FreeDynStTab(flowTab, flowNbr, Flow);
						return(RET_DBA_ERR_HIER);
		  			}
					FREE(flowTab);
		  		}
				else
					DBA_FreeDynStTab(flowTab, flowNbr, Flow);
		  	}
		}
		
		if (DBA_MakeSpecRecLinks(posHierHead, Flow, /* REF7264 - DDV - 020325 - Compil C++ */
                                 Flow_A_Instr_Ext) != RET_SUCCEED)
		{
			FREE(extractPos);
			return(RET_DBA_ERR_HIER);
		}
		FREE(extractPos);
		return(RET_SUCCEED);
	}

	copyRecFlg = FALSE;
	if ((ret = DBA_ExtractHierEltRec(posHierHead, ExtPos, 
		                             copyRecFlg, FIN_FilterRemoveTechnical, FIN_CmpPosInstr, /* PMSTA-22130 - DDV - 160125 - Filter technical positions */
		                             &posNbr, &extractPos)) != RET_SUCCEED)
	{
		return(ret);
	}

	/* BUG220 - XDI - 961105 */
	if ((ret = DBA_ExtractHierEltRec(posHierHead, ExtPos, 
		                             copyRecFlg, FIN_FilterFlow, FIN_CmpPosInstr, 
		                             &extractFlowPosNbr, &extractFlowPos)) != RET_SUCCEED)
	{
		FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
		return(ret);
	}

	/* if there are debt with script definition and */
	/* debt flag is true and FUND_VALO_DEBT_SCRIPT_FLAG is true */
    /* and generation of flow with a debt nature is active */
	/* then compute a fund valo to know debt value */
    GEN_GetApplInfo(ApplFundValoDebtScriptFlag, &fundValoDebtScriptFlag);

	if (GET_FLAG(domainPtr, A_Domain_DebtFlg) == TRUE &&
	    fundValoDebtScriptFlag == TRUE &&
            GET_MASK64_BIT(domainPtr, A_Domain_EvtFlowSubNatLst, FlowSubNat_Any) == TRUE ||
            GET_MASK64_BIT(domainPtr, A_Domain_EvtFlowSubNatLst, FlowSubNat_ProviPlan) == TRUE ||
            GET_MASK64_BIT(domainPtr, A_Domain_EvtFlowSubNatLst, FlowSubNat_DebtAmort) == TRUE)
	{	
		/* BUG452 - 970805 - XMT, initialisation moved at the top of the test */
		for (i=0; i<posNbr && computeValo == FALSE; i++)
		{
		if (GET_EXTENSION_PTR(extractPos[i], ExtPos_A_Instr_Ext) != NULL &&
		    (instrPtr = *(GET_EXTENSION_PTR(extractPos[i], ExtPos_A_Instr_Ext)))!=NULL &&
	            GET_ENUM(instrPtr, A_Instr_ValRuleEn) == ValRule_Script)	
				computeValo = TRUE;
		}
		
		if (computeValo == TRUE)
		{
			/* REF3501 - Keep old value */
			FLAG_T	oldDebtFullCouponFlg = GET_FLAG(domainPtr, A_Domain_DebtFullCouponFlg);

			initialFctDict = GET_DICT(domainPtr, A_Domain_FctDictId);
			SET_ENUM(domainPtr, A_Domain_PosValRuleEn, PosValRule_LoadNothing);
			SET_DICT(domainPtr, A_Domain_FctDictId, DictFct_FundValo);
			SET_FLAG(domainPtr, A_Domain_DebtFullCouponFlg, TRUE); /* BUG299 - XDI - 970312 */ /* set again to TRUE ??? */
                        fromDate = GET_DATETIME(domainPtr, A_Domain_InterpFromDate); /* BUG182 - XDI - 961016 */
                        tillDate = GET_DATETIME(domainPtr, A_Domain_InterpTillDate); /* BUG299 - XDI - 970312 */
                        tmpDate = GET_DATETIME(domainPtr, A_Domain_CalcRefDate); /* BUG182 - XDI - 961016 */
                        tmpDate.date = DATE_Move(tmpDate.date, 1, Day);          /* DVP578 - XDI - 970901 */
                        SET_DATETIME(domainPtr, A_Domain_InterpFromDate, tmpDate);
                        COPY_DYNFLD(domainPtr, A_Domain, A_Domain_InterpTillDate,    /* BUG299 - XDI - 970312 */
                                    domainPtr, A_Domain, A_Domain_CalcRefDate);      /* BUG299 - XDI - 970312 */

			if ((ret = DBA_LoadPos(domainPtr, &hierHeadValo, /* DVP460 */
                                                   NULL, 0, NULL, 0)) != RET_SUCCEED)	/* BUG467 - 970822 - DED */
            {
				FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
				FREE(extractFlowPos); /* Only array pointer, copy flag is FALSE */
                return(ret);
            }
			FIN_AnalysisFundValo(domainPtr, hierHeadValo);
			SET_DICT(domainPtr, A_Domain_FctDictId, initialFctDict);
                        SET_DATETIME(domainPtr, A_Domain_InterpFromDate, fromDate); /* BUG182 - XDI - 961016 */
                        SET_DATETIME(domainPtr, A_Domain_InterpTillDate, tillDate); /* BUG299 - XDI - 970312 */

			/* REF3501 - Reset old value */
			SET_FLAG(domainPtr, A_Domain_DebtFullCouponFlg, oldDebtFullCouponFlg);
		}
	}
	
    /* REF2834 - DDV - 981112 - Index update is supress for performance, 
       Sort in done later with DBA_SortHierRecord function */
    DBA_HierAllIndexNoUpdate(posHierHead, ExtPos);
	
    /* PMSTA9969 - PRS - 101216: set last modified time */
    RET_CODE date_ret = DBA_GetDbDate(&databaseDate);
	if (date_ret != RET_SUCCEED)
	{
		databaseDate.date = 0;
		databaseDate.time = 0;
	}

    bool       bGenPosCalledForTwoLegsAgainsPtfCurr = false;

	for (i=0; i<posNbr; i++)
	{
        /* REF6220 - LJE - 020319 : Active the portfolio currency if the def curr flag is "default" */
		FIN_UpdDomainRefCurr(domainPtr, extractPos[i]);

		if (GET_EXTENSION_PTR(extractPos[i], ExtPos_A_Instr_Ext) != NULL &&
		    (instrPtr = *(GET_EXTENSION_PTR(extractPos[i], ExtPos_A_Instr_Ext)))!=NULL)
		{
		    if (GET_ID(instrPtr, A_Instr_Id) != oldInstrId)
			instrDimFlg = DBA_CheckInstrDim(domainPtr, posHierHead, 
                                            GET_ID(instrPtr, A_Instr_Id), instrPtr, 
                                            &listPtr, NULL, FALSE, NULL, FALSE);

		    if (instrDimFlg == FALSE)
            {
		        oldInstrId = GET_ID(instrPtr, A_Instr_Id);
			    continue;
            }

            /* PMSTA-52091 - DDV - 230207 - Generate flows and positions only on main position */
            if (GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_FXFwd_TwoLegsAgainsPtfCurr &&
                GET_FLAG(extractPos[i], ExtPos_MainFlg) != TRUE)
            {
                continue;
            }
		}
		else
			continue;

        /* PMSTA-34288 - CHU - 190202 */ /* PMSTA-34885 - CHU - 190325 : Add test on function and Event Generation nature */
        if (DictFct_EventGeneration == GET_DICT(domainPtr, A_Domain_FctDictId) &&
            EvtGen_EventOp == (EVTGEN_ENUM)GET_ENUM(domainPtr, A_Domain_EvtGenNatEn) &&
            (InstrumentNature::isDualCurrencyInvestMoneyMarket(instrPtr) ||
             InstrumentNature::isDualCurrencyInvestMoneyMarket(instrPtr)))
        {
            /* Surprisingly, the MoneyMarket instruments don't reach this point when A_Domain_EvtGenNatEn == EvtGen_EventOp
             * as their ExtPos_NatEn is set to  ExtPosNat_Flow, so they are skipped by the condition below
             * (GET_ENUM(extractPos[i], ExtPos_NatEn) == ExtPosNat_FinalStock)
             * But why then this test in FIN_GenerateInstrFlows() ?
             *     case InstrNat_MoneyMkt :    /-* REF9085 - YST - 030520 - new accrual rules *-/
                            ret = FIN_NewBondFlows(...);
             */
            bIsInstrDCIorTCI = true;
        }

		/* Read position instrument (can be created record) */
		if ( IS_NULLFLD( extractPos[i], ExtPos_BalPosTpId) == TRUE                   &&
			                         (GET_ENUM(extractPos[i], ExtPos_NatEn) == ExtPosNat_FinalStock ||
                                      true == bIsInstrDCIorTCI)                      &&                /* PMSTA-34288 - CHU - 190202 */
		                             GET_ENUM(extractPos[i], ExtPos_StatEn) >= evtGenMinStatus &&      /* PMSTA07550 - DDV - 090427 - Check is based on new appl_param instead of accouting status */
             (GET_NUMBER(extractPos[i], ExtPos_Qty) != 0.0 || GET_AMOUNT(extractPos[i], ExtPos_AccrAmt) != 0.0) /* PMSTA-22472 - 040316 - PMO */
           )
		{
            bIsInstrDCIorTCI = false; /* PMSTA-34288 - CHU - 190202 : reset for next instrument */

		    /* DVP001 : Event Operation Generation (960229) */
		    if (GET_ID(instrPtr, A_Instr_Id) != oldInstrId)
		    {
		        oldInstrId = GET_ID(instrPtr, A_Instr_Id);
		        if (firstFlowTab == FALSE && flowNbr > 0)
			    {
				    FREE(flowTab);
			    }
			
			    firstFlowTab = FALSE;

                /* Compute instrument flows */
                ret = FIN_GenerateInstrFlows(GET_DATETIME(domainPtr, A_Domain_CalcRefDate),
                                    GET_DATETIME(domainPtr, A_Domain_InterpTillDate),
                                    GET_DATETIME(domainPtr, A_Domain_CalcRefDate),
                                    FALSE,	/* PMSTA-9032 - RAK - 091216 */
                                    GET_ID(instrPtr, A_Instr_Id), instrPtr, 
                                    GET_MASK64(domainPtr, A_Domain_EvtFlowSubNatLst),
                                    (EVTGEN_ENUM) GET_ENUM(domainPtr, A_Domain_EvtGenNatEn), /* REF7264 - DDV - 020325 - Compil C++ */
                                    (EVTDATERULE_ENUM) GET_ENUM(domainPtr, A_Domain_EvtDateRuleEn), /* REF7264 - DDV - 020325 - Compil C++ */ /* REF4075 - 991208 - CSY: A_Domain_PosValRuleEn 
                                                                          (teporarily used for test) replaced with A_Domain_EvtDateRuleEn */
                                    GET_FLAG(domainPtr, A_Domain_DebtFlg),
                                    genInstrFlowEn,                     /* REF8866 - YST - 030311 */
                                    AccrRule_None,                      /* REF11218 - TEB - 050627 */
                                    &flowTab, &flowNbr, posHierHead,    /* REF7264 - DDV - 020325 - Compil C++ */
                                    extractPos[i]);                     /* PMSTA-32116 - 200818 - PMO */

                 /* insert FlowTab into hierarchy */
                if (flowNbr > 0 && DBA_AddHierRecordList(posHierHead, flowTab, flowNbr, Flow, FALSE) != RET_SUCCEED)
                {
                    FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
                    FREE(extractFlowPos); /* Only array pointer, copy flag is FALSE */
                    return(RET_DBA_ERR_HIER);
                }
            }

		    if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
		    {
			    /* WARNINGS tmpDate may be used without having been initialised - RAK - 990301 */
			    tmpDate.time = 0;
			    if (IS_NULLFLD(extractPos[i], ExtPos_ExpirDate) == FALSE) /* REF2444 - DDV - 980831 */
				    tmpDate.date = GET_DATETIME(extractPos[i], ExtPos_ExpirDate).date; /* REF2444 - DDV - 980831 */
			    else
				    tmpDate.date = MAGIC_END_DATE;

		        /* Create operation and position for each flow */
		        for(j=0; j<flowNbr; j++)
		        {
			        /* DVP063 - 960521 - XDI */ /* BUG220 - XDI - 961205 */
			        /* if (FIN_CheckExistPosOld(extractFlowPos, extractFlowPosNbr, flowTab[j], extractPos[i])==FALSE && REF1434-REF1435 - DDV - 980318 */
			        if (GET_ENUM(extractPos[i], ExtPos_LockNatEn) != OpLockNat_LockingPos && /* DVP198 - XDI */
                        GET_ENUM(extractPos[i], ExtPos_LockNatEn) != OpLockNat_UnlockingPos && /* DVP198 - XDI */
                        GET_ENUM(extractPos[i], ExtPos_LockNatEn) != OpLockNat_RepoLocking  && /* REF1365 */
                        GET_ENUM(extractPos[i], ExtPos_LockNatEn) != OpLockNat_RepoUnlocking &&
                        GET_ENUM(extractPos[i], ExtPos_LockNatEn) != OpLockNat_SellBuyBackLocking  && /* REF2444 - 980717 - DDV */
                        GET_ENUM(extractPos[i], ExtPos_LockNatEn) != OpLockNat_SellBuyBackUnlocking && /* REF2444 - 980717 - DDV */
                        GET_ENUM(extractPos[i], ExtPos_LockNatEn) != OpLockNat_SellBuyBackLocked  && /* REF2444 - 980717 - DDV */
                        GET_ENUM(extractPos[i], ExtPos_LockNatEn) != OpLockNat_BuySellBackUnlocking && /* REF2444 - 980717 - DDV */
                        GET_ENUM(extractPos[i], ExtPos_LockNatEn) != OpLockNat_RemereLocking &&
                        GET_ENUM(extractPos[i], ExtPos_LockNatEn) != OpLockNat_RemereUnlocking &&
                        GET_ENUM(extractPos[i], ExtPos_LockNatEn) != OpLockNat_RevRepoLocking &&
                        GET_ENUM(extractPos[i], ExtPos_LockNatEn) != OpLockNat_RevRepoUnlocking &&

						/* REF3939 - 991015 - CSY */
						((FlowSubNat_ConvExch != GET_ENUM(flowTab[j], Flow_SubNatEn)) ?   /* PMSTA-37786 - 191112 - sanand */
                        DATETIME_CMP(GET_DATETIME(flowTab[j] ,Flow_OptimalDate), GET_DATETIME(domainPtr, A_Domain_InterpTillDate))<=0 : TRUE ) &&
                        DATETIME_CMP(GET_DATETIME(flowTab[j] ,Flow_OptimalDate), GET_DATETIME(domainPtr, A_Domain_CalcRefDate))>=0 &&
						/* end REF3939 */

                        GET_ENUM(extractPos[i], ExtPos_LockNatEn) != OpLockNat_BuySellBackLocking  || /* REF2444 - 980831 - DDV */
                        (GET_ENUM(extractPos[i], ExtPos_LockNatEn) == OpLockNat_BuySellBackLocking  && /* REF2444 - 980831 - DDV */
                            DATETIME_CMP(GET_DATETIME(flowTab[j] ,Flow_OptimalDate), tmpDate) <= 0 ))
			        {
				        /* Lets talk about timers. */
				        DATE_RESET_TIMER (&SV_FIN_GeneratePos, TIMER_MASK_FIN);
				        DATE_START_TIMER (&SV_FIN_GeneratePos, TIMER_MASK_FIN);
				        DATE_START_TIMER (&SV_TOT_FIN_GeneratePos, TIMER_MASK_FIN);

                        if (GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_FXFwd_TwoLegsAgainsPtfCurr)
                        {
                            bGenPosCalledForTwoLegsAgainsPtfCurr = true;
                        }

                        ret = FIN_GeneratePosition(posHierHead,
                                                    GET_ID(domainPtr, A_Domain_CurrId),
                                                    (FUSDATERULE_ENUM) GET_ENUM(domainPtr, A_Domain_FusDateRuleEn),
                                                    opStatus, 
                                                    extractPos[i], 
                                                    flowTab[j], 
                                                    (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId),
                                                    GET_DATETIME(domainPtr, A_Domain_CalcRefDate),
                                                    (EVTPLRULE_ENUM) GET_ENUM(domainPtr, A_Domain_EvtPlRuleEn),
                                                    hierHeadValo, 
                                                    domainPtr,
                                                    extractFlowPos,	 /* REF1434-REF1435 - DDV  */
                                                    extractFlowPosNbr,	 /* REF1434-REF1435 - DDV  */
                                                    &listPtr,    /* REF3939 - CSY - 991104 */
                                                    databaseDate);   /* PMSTA9969 - PRS - 101216 */

				        DATE_STOP_TIMER (&SV_FIN_GeneratePos, TIMER_MASK_FIN);
				        DATE_STOP_TIMER (&SV_TOT_FIN_GeneratePos, TIMER_MASK_FIN);
				        DATE_DISPLAY_TIMER (&SV_FIN_GeneratePos, TIMER_MASK_FIN, "Time to generate position");
			        }
		        }

			    /* compute proportional attribution price */
			    if (ret==RET_SUCCEED)
			    {
			        ret = FIN_ComputePropAttribPrice(posHierHead, /* REF7264 - DDV - 020325 - Compil C++ */
							         extractPos[i],
							         domainPtr); 
			    }
			    else /* PMSTA00177 - TGU - 061205 - Return Code of one position should not impact to other positions */
			    {
				    ret = RET_SUCCEED;
			    }
		    }
		}
	}

	if (listPtr != NULL)
		FREE_DYNST(listPtr, A_List);

	if (computeValo == TRUE)
		DBA_FreeHier(hierHeadValo);

    if (flowNbr > 0)
	{
		FREE(flowTab);
	}

	FREE(extractFlowPos); /* Only array pointer, copy flag is FALSE */

    /* extract all positions with an event code and an event number (these fields are allways set for standing instructions) */
	if ((ret = DBA_ExtractHierEltRec(posHierHead, ExtPos, 
		                             copyRecFlg, FIN_FilterStandingInstruction, FIN_CmpPosInstr, 
		                             &extractFlowPosNbr, &extractFlowPos)) != RET_SUCCEED)
	{
		FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
		return(ret);
	}

    /* PMSTA06761 - DDV -080731 - Generate all flows and operations linked to standing instructions */
    FIN_GenerateStandInstruct(domainPtr, posHierHead, extractFlowPos, extractFlowPosNbr, &listPtr);

	FREE(extractFlowPos); /* Only array pointer, copy flag is FALSE */

	/* Free all Script for Default Values */
	SCPT_FreeScriptDV(NullEntity); /* PMSTA06772 - 080619 - DDV */

	/* DVP001 : Event Operation Generation (960229) */
	if (GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_Journal)
	{
		/* Sort for optimize link setting (main and accounting) */
		if (DBA_HierRebuildAllIndex(posHierHead, ExtPos) != RET_SUCCEED) 
		{  
			return(RET_DBA_ERR_HIER);
		} 

		/* Create record links */
		if (DBA_MakeLinks(posHierHead) != RET_SUCCEED)
		{
			return(RET_DBA_ERR_HIER);
		}

        /* PMSTA-52091 - DDV - 230208 - Execute logical fusion to have secondary position for SubNat_FXFwd_TwoLegsAgainsPtfCurr */
        if (bGenPosCalledForTwoLegsAgainsPtfCurr)
        {
            int               posForFusionNbr;
            DBA_DYNFLD_STP    *posForFusionTab = NULL;
            DBA_DYNFLD_STP    initExtPos = NULLDYNST;

            DBA_ExtractHierEltRec(posHierHead, ExtPos, FALSE, FIN_FilterFinalAndNewTwoLegsAgainsPtfCurPos, NULLFCT, &posForFusionNbr, &posForFusionTab);

            if (posForFusionNbr > 0)
            {
                for (i = 0; i < posForFusionNbr; ++i)
                {
                    if (IS_NULLFLD(posForFusionTab[i], ExtPos_FlowId) == FALSE && 
                        GET_ENUM(posForFusionTab[i], ExtPos_NatEn) == ExtPosNat_Flow &&
                        IS_NULLFLD(posForFusionTab[i], ExtPos_InitExtPosId) == FALSE)
                    {
                        DBA_GetRecPtrFromHierById(posHierHead, GET_ID(posForFusionTab[i], ExtPos_InitExtPosId), ExtPos, &initExtPos);

                        if (initExtPos != NULLDYNST)
                        {
                            COPY_DYNFLD(posForFusionTab[i], ExtPos, ExtPos_StatEn, initExtPos, ExtPos, ExtPos_StatEn);
                        }
                    }
                }

                FIN_LogicalFusion(GET_DATETIME(domainPtr, A_Domain_InterpTillDate),
                                  posHierHead, (HIER_FLTFCT *)FIN_FilterFinalAndNewTwoLegsAgainsPtfCurPos, NULLFCT,
                                  (PTFFUSRULE_ENUM)GET_ENUM(domainPtr, A_Domain_FusRuleEn),
                                  LogicIdRule_Basic, TRUE, NULL, NULL, true); /* PMSTA-52091 - DDV - 230608 */

                /* Reset ExtPos_StatEn */
                for (i = 0; i < posForFusionNbr; ++i)
                {
                    if (IS_NULLFLD(posForFusionTab[i], ExtPos_FlowId) == FALSE &&
                        GET_ENUM(posForFusionTab[i], ExtPos_NatEn) == ExtPosNat_Flow &&
                        IS_NULLFLD(posForFusionTab[i], ExtPos_InitExtPosId) == FALSE)
                    {
                        SET_ENUM(posForFusionTab[i], ExtPos_StatEn, opStatus);
                    }
                }

                /* compute ExtPos_NatEn for position created by logical fusion */
                DBA_ExtractHierEltRec(posHierHead, ExtPos, FALSE, NULLFCT, NULLFCT, &posForFusionNbr, &posForFusionTab);
                for (i = 0; i < posForFusionNbr; ++i)
                {
                    if (IS_NULLFLD(posForFusionTab[i], ExtPos_NatEn) == TRUE)
                    {
                        SET_ENUM(posForFusionTab[i], ExtPos_StatEn, opStatus);

                        if (IS_NULLFLD(posForFusionTab[i], ExtPos_EndDate) == TRUE ||
                            CMP_DYNFLD(posForFusionTab[i], domainPtr, ExtPos_EndDate, A_Domain_InterpTillDate, DateType) > 0)
                        {
                            DBA_DelAndFreeHierEltRec(posHierHead, ExtPos, posForFusionTab[i]); /* Delete final positions generated by logical fusion */
                        }
                        else
                        {
                            SET_ENUM(posForFusionTab[i], ExtPos_NatEn, ExtPosNat_Flow);
                        }
                    }
                }
            }
        }

        /* BUG450 - 970829 - XDI - loop moved to keep link between extpos and mainextpos */
		/* delete all flow not between from and ref date */	
		for (i=0; i<posNbr; i++)
		{
			/* BUG110 - 960828 - XDI - New Code */
			if (GET_FLAG(extractPos[i], ExtPos_ForecastFlg) == FALSE &&
			    GET_ENUM(extractPos[i], ExtPos_NatEn) == ExtPosNat_Flow &&
			    ((DATETIME_CMP(GET_DATETIME(extractPos[i], ExtPos_ExtPosDate),
			                  GET_DATETIME(domainPtr, A_Domain_CalcRefDate)) > 0 &&
			     DATETIME_CMP(GET_DATETIME(extractPos[i], ExtPos_BegDate),
				 GET_DATETIME(domainPtr, A_Domain_CalcRefDate)) > 0)  &&   /* PMSTA-24937 - ANJANA - 161018 */
			     DATETIME_CMP(GET_DATETIME(extractPos[i], ExtPos_ExtPosDate),
			                  GET_DATETIME(domainPtr, A_Domain_InterpFromDate)) <= 0))
			{
				DBA_DelHierEltRec(posHierHead, ExtPos, extractPos[i]);
			}
		}

		FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
	}
	else
	{
		FREE(extractPos);  /* Only array pointer, copy flag is FALSE */

		if (DBA_MakeSpecRecLinks(posHierHead, Flow, 
                                 Flow_A_Instr_Ext) != RET_SUCCEED)
		{
			return(RET_DBA_ERR_HIER);
		}

		/* if operation generation mode is automatic, */
		/* data will be insert in database */
		/* use a transction to insert records in database */
		if (GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_EventGeneration &&
		    GET_ENUM(domainPtr, A_Domain_EvtGenNatEn) == EvtGen_Automatic)
		{
			/* extract all extended operation from hierarchy */
			copyRecFlg = FALSE;
			if ((ret = DBA_ExtractHierEltRec(posHierHead, ExtOp, 
		       	                            copyRecFlg, NULL, NULL, 
		       		                        &posNbr, &extractPos)) != RET_SUCCEED)
			{
				return(ret);
			}

        	/* Get a free connection in the connection list */
        	if ((connectNo = DBA_GetConnection(SqlServer)) == DBA_CONN_NOT_FOUND)
			{
				FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
            	MSG_RETURN(RET_DBA_ERR_CONNOTFOUND);
			}

			/* Begin Transaction */
			if ((ret = DBA_BeginTransaction(connectNo)) != RET_SUCCEED)
        	{
        		if (DBA_EndConnection(connectNo) != RET_SUCCEED)
				{
					MSG_SendMesg(RET_DBA_ERR_DISCONNECTED, 0, FILEINFO);
				}
				FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
            	MSG_RETURN(ret);
        	}

			/* insert all extended operation into database */
			for (i=0; i < posNbr; i++)
			{
                		if (DBA_Insert2(EOp, UNUSED, ExtOp, extractPos[i], 
				                DBA_SET_CONN|DBA_NO_CLOSE, &connectNo, 
				                UNUSED) != RET_SUCCEED)
				{
					/* End Transaction */
					if ((ret = DBA_EndTransaction(connectNo, TRUE)) != RET_SUCCEED)
					{
						FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
						return(RET_DBA_ERR_DBPROBLEM);
					}

					/* End connection */
        				if (DBA_EndConnection(connectNo) != RET_SUCCEED)
					{
						MSG_SendMesg(RET_DBA_ERR_DISCONNECTED, 0, FILEINFO);
					}
					FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
					return(RET_DBA_ERR_DBPROBLEM);
				}
			}
			FREE(extractPos);  /* Only array pointer, copy flag is FALSE */

			/* End Transaction */
			if ((ret = DBA_EndTransaction(connectNo, TRUE)) != RET_SUCCEED)
			{
				return(RET_DBA_ERR_DBPROBLEM);
			}

			/* End connection */
        		if (DBA_EndConnection(connectNo) != RET_SUCCEED)
			{
				MSG_SendMesg(RET_DBA_ERR_DISCONNECTED, 0, FILEINFO);
			}
		}
		/* PMST06761 - RAK - 080730 */
		/* create or update a session (according to compute data and function result parameters) */
		/* PMSTA28294 - RAK - 171215 - 9years after, do the same for Mutual Funds systematic plan (CreateSessionAndCheck) */
		/* PMSTA-28879 - RAK - 180108 - Mutual Fund Back end Mandatory : Batch : EvtGen_CheckSplitAndPublish */
		else if	(GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_EventGeneration &&
			     (GET_ENUM(domainPtr, A_Domain_EvtGenNatEn) == EvtGen_CreateSession ||
				  GET_ENUM(domainPtr, A_Domain_EvtGenNatEn) == EvtGen_CreateSessionAndCheck ||
				  GET_ENUM(domainPtr, A_Domain_EvtGenNatEn) == EvtGen_CheckSplitAndPublish ||
                  GET_ENUM(domainPtr, A_Domain_EvtGenNatEn) == EvtGen_CheckCaseSplitAndPublish))
		{
			if ((ret = FIN_EvtGenerationSession(domainPtr, posHierHead)) != RET_SUCCEED)
			{
				return(ret);
			}

			/* PMSTA28294 - RAK - 171215 - Call PTCC */
			/* PMSTA-28879 - RAK - 180108 - Mutual Fund Back end Mandatory : Batch : EvtGen_CheckSplitAndPublish */
			if (GET_ENUM(domainPtr, A_Domain_EvtGenNatEn) == EvtGen_CreateSessionAndCheck ||
				GET_ENUM(domainPtr, A_Domain_EvtGenNatEn) == EvtGen_CheckSplitAndPublish ||
                GET_ENUM(domainPtr, A_Domain_EvtGenNatEn) == EvtGen_CheckCaseSplitAndPublish)
			{
				DBA_HIER_HEAD_STP PTCCHierHead;

				/* PMSTA-34067 - RAK - Goal based batch - Keep calling fct and update of domain not necessary */
				SET_DICT(domainPtr, A_Domain_InitialFctDictId, GET_DICT(domainPtr, A_Domain_FctDictId));

				SET_DICT(domainPtr, A_Domain_FctDictId, DictFct_PreTradeCheckStrat);
				SET_ENUM(domainPtr, A_Domain_CompDataEn, CompData_ReplOld);

				/* PMSTA-34067 - RAK - Goal based batch - Keep calling fct and update of domain not necessary */
				/*SET_DICT(domainPtr, A_Domain_InitialFctDictId, DictFct_PreTradeCheckStrat);*/
				/*ret = DBA_Update2(Domain, UNUSED, A_Domain, domainPtr, UNUSED, UNUSED, UNUSED);*/

				if ((PTCCHierHead = DBA_CreateHier()) == NULL)
					return(RET_DBA_ERR_HIER);

				/* PMSTA-34067 - RAK - Goal based batch - Update with calling function */
				if (ret == RET_SUCCEED)
				{
                    /* PMSTA-35330 - DDV - 190329 - Restore function only if it has been set */
                    if (IS_NULLFLD(domainPtr, A_Domain_RpcFctDictId) == FALSE)
                    {
                        SET_DICT(domainPtr, A_Domain_FctDictId, GET_DICT(domainPtr, A_Domain_RpcFctDictId));
                    }

					ret = DBA_Update2(Domain, UNUSED, A_Domain, domainPtr, UNUSED, UNUSED, UNUSED);
				}
			
				ret = FIN_CheckReconcStrategy(domainPtr, PTCCHierHead);

				DBA_FreeHier(PTCCHierHead);

				if (ret != RET_SUCCEED)
					return(ret);
			}
		}
	}

    /* REF6220 - LJE - 020319 */
	if (domainPtr != NULL)
	{
	    SET_ID(domainPtr, A_Domain_CurrId, refCurrDomain);
	}

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function         : FIN_DeleteFctResult()
**
**  Description      : delete domain function result (delete associated records) 
**                      
**  Arguments        : domainPtr	domain structure pointer
**                     getArg		working structure pointer
**                     fctResStp	function result structure pointer (updated)
**
**  Return           : RET_SUCCEED or error code
**
** Creation Date     : PMSTA06761 - RAK - 080805
**
*************************************************************************/
RET_CODE FIN_DeleteFctResult(DBA_DYNFLD_STP			domainPtr, 
						     DBA_DYNFLD_STP			getArg)
{
	RET_CODE		ret=RET_SUCCEED;
	DICT_FCT_STP	dictFctInfo;

	if (IS_NULLFLD(domainPtr, A_Domain_FctResultId) == TRUE)
	{
		return(RET_SRV_LIB_ERR_PARAMNOTSUPPLIED);
	}

	/* Delete Function Result record and all attached ext_strategy_link 
 	   and ext_strategy_element */	
	if (DBA_Delete2(FctResult, DBA_ROLE_LOAD_STRAT_LNK, Get_Arg, getArg, UNUSED, UNUSED) != RET_SUCCEED)
		ret = RET_SRV_LIB_ERR_COMMAND_ABORTED;

	if (ret == RET_SUCCEED)
	{
		/* REF2510 - SSO - 980907 */
		DBA_GetDictFctInfo(GET_DICT(domainPtr, A_Domain_FctDictId), DictFctInfo_Stp, &dictFctInfo); /* DLA - REF9089 - 030512 */
		MSG_LogSrvMesg(UNUSED, UNUSED, "%1 :"
		               " Delete of function result %2 succeed",
			           NameType, dictFctInfo->name,
					   CodeType, GET_CODE(domainPtr, A_Domain_FctResultCd));
	}

	return(ret);
}

/************************************************************************
**
**  Function         : FIN_DeleteAllFctResult()
**
**  Description      : delete all function result of current domain function 
**                      
**  Arguments        : domainPtr	domain structure pointer
**                     getArg		working structure pointer
**                     fctResStp	function result structure pointer (updated)
**
**  Return           : RET_SUCCEED or error code
**
** Creation Date     : PMSTA06761 - RAK - 080805
**
*************************************************************************/
RET_CODE FIN_DeleteAllFctResult(DBA_DYNFLD_STP			domainPtr, 
								DBA_DYNFLD_STP			getArg)
{
	RET_CODE		ret=RET_SUCCEED;
	DICT_FCT_STP	dictFctInfo;

	SET_DICT(getArg, Get_Arg_FctDictId, GET_DICT(domainPtr, A_Domain_FctDictId));
	SET_NULL_ID(getArg, Get_Arg_Id);

	if (DBA_Delete2(FctResult, DBA_ROLE_LOAD_STRAT_LNK, Get_Arg, getArg, UNUSED, UNUSED) != RET_SUCCEED)
		ret = RET_SRV_LIB_ERR_COMMAND_ABORTED;

	if (ret == RET_SUCCEED)
	{
		/* REF2510 - SSO - 980907 */
		DBA_GetDictFctInfo(GET_DICT(domainPtr, A_Domain_FctDictId), DictFctInfo_Stp, &dictFctInfo); /* DLA - REF9089 - 030512 */
		MSG_LogSrvMesg(UNUSED, UNUSED, "%1 :"
			           " Delete of function result records succeed",
				       NameType, dictFctInfo->name);
	}

	return(ret);
}

/************************************************************************
**
**  Function         : FIN_ComputeNewFctResult()
**
**  Description      : create new domain function result 
**                      
**  Arguments        : domainPtr	domain structure pointer
**                     getArg		working structure pointer
**                     fctResStp	function result structure pointer (updated)
**
**  Return           : RET_SUCCEED or error code
**
** Creation Date     : PMSTA06761 - RAK - 080805
**
*************************************************************************/
RET_CODE FIN_ComputeNewFctResult(DBA_DYNFLD_STP       domainPtr, 
								 DBA_DYNFLD_STP       *fctResStp)
{
	RET_CODE		ret=RET_SUCCEED;
    MemoryPool      mp;

	/* REFQBE - RAK - 000411 - Sometimes GUI could send a function result */
    if (IS_NULLFLD(domainPtr, A_Domain_FctResultId) == FALSE)
    {   
        DBA_DYNFLD_STP sFctResultPtr = mp.allocDynst(FILEINFO,S_FctResult);
	    (*fctResStp) = mp.allocDynst(FILEINFO,A_FctResult);

	    SET_ID(sFctResultPtr, S_FctResult_Id, GET_ID(domainPtr, A_Domain_FctResultId));

	    if ((ret = DBA_Get2(FctResult, UNUSED, 
                            S_FctResult, sFctResultPtr, 
				            A_FctResult, fctResStp, 
                            UNUSED, UNUSED, UNUSED)) != RET_SUCCEED)
	    {
		    return(RET_SRV_LIB_ERR_COMMAND_ABORTED);
	    }
    }

    /* REFQBE - RAK - 000411 */
    /* *fctRestStp is set if A_Domain_FctResultId wasn't NULL, */
    /* DBA_NewFctResult() treat this case and update domain and fct result */
	if ((ret = DBA_NewFctResult(domainPtr, fctResStp, NULL)) != RET_SUCCEED)
	{
		MSG_LogMesg(ret, 0, FILEINFO);
		return(RET_SRV_LIB_ERR_COMMAND_ABORTED);
	}

    mp.removeDynStp(*fctResStp);
	return(ret);
}

/************************************************************************
**
**  Function         : FIN_ReplOldFctResult()
**
**  Description      : verify domain function result (delete associated records) 
**                      
**  Arguments        : domainPtr	domain structure pointer
**                     getArg		working structure pointer
**                     fctResStp	function result structure pointer (updated)
**
**  Return           : RET_SUCCEED or error code
**
** Creation Date     : PMSTA06761 - RAK - 080805
**
** Last modif.       : PMSTA-15184 - 151012 - PMO : Some warnings during TA build process
**
*************************************************************************/
RET_CODE FIN_ReplOldFctResult(DBA_DYNFLD_STP       domainPtr, 
							  DBA_DYNFLD_STP       getArg,
							  DBA_DYNFLD_STP       *fctResStp)
{
	DBA_DYNFLD_STP          sFctResultPtr=NULLDYNST, shFctGet=NULLDYNST, admArg=NULLDYNST;
	RET_CODE                ret=RET_SUCCEED;
	ID_T				    fctResId;
	FLAG_T				    fFctResToCreate=TRUE;
	DICT_T				    fctDictId = GET_DICT(domainPtr, A_Domain_FctDictId);
	FCTRESULTSTATUS_ENUM	fctStatus = FctResultStatus_None;
	DBA_DYNFLD_STP      sDomain = NULL, aDomain = NULL;
    MemoryPool          mp;

	/* < OCS-39365-CHU-111017 */
	DBA_ERRMSG_HEADER_ST msgStructHead;
	/* > OCS-39365-CHU-111017 */
	
	/* test if function result still exist */
	if (IS_NULLFLD(domainPtr, A_Domain_FctResultId) == FALSE)
	{
		if ((admArg = ALLOC_DYNST(Adm_Arg)) == NULLDYNST)
		{ 
		    MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		if ((sFctResultPtr = ALLOC_DYNST(S_FctResult)) == NULLDYNST)
		{ 
		    FREE_DYNST(admArg, Adm_Arg);
		    MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		fctResId = GET_ID(domainPtr, A_Domain_FctResultId);
		SET_ID(admArg, Adm_Arg_Id, fctResId); 

		ret = DBA_Get2(FctResult, UNUSED, Adm_Arg, admArg,
					   S_FctResult, &sFctResultPtr, UNUSED, UNUSED, UNUSED);
        if (ret == RET_SUCCEED)
		{
		   fctStatus = (FCTRESULTSTATUS_ENUM)GET_ENUM(sFctResultPtr, S_FctResult_StatusEn);
		}

	    FREE_DYNST(admArg, Adm_Arg);
		FREE_DYNST(sFctResultPtr, S_FctResult);

		if (ret == RET_SUCCEED)
		{
		    /* this function result still exist */
		    fFctResToCreate = FALSE;
			if((GET_ENUM(domainPtr, A_Domain_CompDataEn) == (ENUM_T)CompData_Append) &&
			   (fctStatus != FctResultStatus_InProgress))
			{
				MSG_LogSrvMesg(UNUSED, UNUSED, "Wrong status for function result code %1. The status has to be InProgress",
						       CodeType, 
						       GET_CODE(domainPtr, A_Domain_FctResultCd));
				return RET_SRV_LIB_ERR_INVFCTRESSTATUS;
			}

		}
		else
		{
			/*if Append mode, don't create it, return error*/
            if(GET_ENUM(domainPtr, A_Domain_CompDataEn) == (ENUM_T)CompData_Append)
			{
               return RET_DBA_ERR_NODATA;
			}
		    /* function result need to be created, but verify that provided code isn't used */
		    if (IS_NULLFLD(domainPtr, A_Domain_FctResultCd) == FALSE)
		    {
				if ((shFctGet = ALLOC_DYNST(S_FctResult)) == NULLDYNST)
				{ 
					MSG_RETURN(RET_MEM_ERR_ALLOC);
				}

				if ((sFctResultPtr = ALLOC_DYNST(S_FctResult)) == NULLDYNST)
				{ 
					FREE_DYNST(shFctGet, S_FctResult);
					MSG_RETURN(RET_MEM_ERR_ALLOC);
				}

				COPY_DYNFLD(shFctGet, S_FctResult, S_FctResult_Cd,
							domainPtr, A_Domain,   A_Domain_FctResultCd);

				ret = DBA_Get2(FctResult, UNUSED, S_FctResult, shFctGet,
							   S_FctResult, &sFctResultPtr, UNUSED, UNUSED, UNUSED);

				FREE_DYNST(shFctGet, S_FctResult);
				FREE_DYNST(sFctResultPtr, S_FctResult);

				if (ret == RET_SUCCEED)
				{
					/* this code is already used */
					return(RET_FIN_ERR_CODE_USED);
				}

				if (ret != RET_DBA_INFO_NODATA)
				{
					/* database error */
					return(RET_SRV_LIB_ERR_COMMAND_ABORTED);
				}
		    }
		}
	}

	/*  DVP460 - Create a new domain with a new function result */
	/* (some informations (domain or fctRes) could be changed)  */
	if (fFctResToCreate == TRUE)
	{
	    SET_NULL_ID(domainPtr, A_Domain_Id);
	    ret = DBA_NewFctResult(domainPtr, fctResStp, NULL);

    	if (ret != RET_SUCCEED)
		  return(RET_SRV_LIB_ERR_COMMAND_ABORTED);
	}
	else
	{
		if(GET_ENUM(domainPtr, A_Domain_CompDataEn) != (ENUM_T)CompData_Append)
		{
		  /* Logical update of the result */
		  int 			connectNo;

	      /* Work in transaction */
	      if ((connectNo = DBA_GetConnection(SqlServer)) == DBA_CONN_NOT_FOUND)
	      {
	         MSG_RETURN(RET_DBA_ERR_CONNOTFOUND);
	      }

          if ((ret = DBA_BeginTransaction(connectNo)) != RET_SUCCEED)
	      {
	        DBA_EndConnection(connectNo);
	        return(ret);
	      }

		  /* PMSTA06761 - RAK - 080805 - No ESL and ESE for EventGenration */
		  if (fctDictId != DictFct_EventGeneration)
		  {
              /* PMSTA-29302 - CHU - 180126 */
              /* Delete only in the case of CompData_ReplOld with no chunk, no slicing and not in any TSL mode */
              /* else deletion must happen later when portfolio id's are known if there's a related tasc job */
              if ((GET_ENUM(domainPtr, A_Domain_OutputTpEn) != TSLDimPort &&
                  GET_ENUM(domainPtr, A_Domain_OutputTpEn) != TASCTableOutput &&
                  IS_NULLFLD(domainPtr, A_Domain_JobReference) == TRUE &&
                  IS_NULLFLD(domainPtr, A_Domain_ChunkNumber) == TRUE)
                  ||
                  ((DOMSESSIONNAT_ENUM)GET_ENUM(domainPtr, A_Domain_SessionNatureEn) == DomSessionNat_InvestmentProposal ||
                   (DOMSESSIONNAT_ENUM)GET_ENUM(domainPtr, A_Domain_SessionNatureEn) == DomSessionNat_InvestmentProposalClient)
                 )
              {
                  if (GET_ENUM(domainPtr, A_Domain_CompDataEn) != (ENUM_T)CompData_SelectiveReplOld) /* PMSTA-29302 - CHU - 180221 */
                  {
        		    /* delete extstrat */   /* REF5219 - RAK - 000913 DBA_SET_CONN|DBA_NO_CLOSE */
        		    if ((ret = DBA_Delete2(EStratLnk, DBA_ROLE_LOAD_STRAT_LNK, 
        				       Get_Arg, getArg, DBA_SET_CONN|DBA_NO_CLOSE, 
                               &connectNo)) != RET_SUCCEED)
        		    {
        	                DBA_EndTransaction(connectNo, FALSE);
        	                DBA_EndConnection(connectNo);
        		            return(RET_SRV_LIB_ERR_COMMAND_ABORTED);
        		    }
        
        		    /* del extstratelts */  /* REF5219 - RAK - 000913 DBA_SET_CONN|DBA_NO_CLOSE */
        		    SET_FLAG(getArg, Get_Arg_Flag, FALSE);
        		    if ((ret = DBA_Delete2(EStratElt, DBA_ROLE_LOAD_STRAT_LNK, 
        				       Get_Arg, getArg, DBA_SET_CONN|DBA_NO_CLOSE, 
                               &connectNo)) != RET_SUCCEED)
        		    {
        	                DBA_EndTransaction(connectNo, FALSE);
        	                DBA_EndConnection(connectNo);
        		            return(RET_SRV_LIB_ERR_COMMAND_ABORTED);
        		    }
        
        		    if ((ret = DBA_Delete2(RiskESElt, DBA_ROLE_LOAD_STRAT_LNK, 
        				       Get_Arg, getArg, DBA_SET_CONN|DBA_NO_CLOSE, 
                               &connectNo)) != RET_SUCCEED)
        		    {
        	                DBA_EndTransaction(connectNo, FALSE);
        	                DBA_EndConnection(connectNo);
        		            return(RET_SRV_LIB_ERR_COMMAND_ABORTED);
        		    }			
        
        		    if ((ret = DBA_Delete2(RiskESEltCompo, DBA_ROLE_LOAD_STRAT_LNK, 
        				       Get_Arg, getArg, DBA_SET_CONN|DBA_NO_CLOSE, 
                               &connectNo)) != RET_SUCCEED)
        		    {
        	                DBA_EndTransaction(connectNo, FALSE);
        	                DBA_EndConnection(connectNo);
        		            return(RET_SRV_LIB_ERR_COMMAND_ABORTED);
        		    }
        
        			/* PMSTA-21255 - Cashwini - 150921 */
        			if ((ret = DBA_Delete2(LombardCheck, DBA_ROLE_LOAD_STRAT_LNK,
        				Get_Arg, getArg, DBA_SET_CONN | DBA_NO_CLOSE,
        				&connectNo)) != RET_SUCCEED)
        			{
        				DBA_EndTransaction(connectNo, FALSE);
        				DBA_EndConnection(connectNo);
        				return(RET_SRV_LIB_ERR_COMMAND_ABORTED);
        			}
        
        			/* < OCS-39365-CHU-111017 */
        			/* delete Cases if called from the WUI */	
        			if (((GET_ENUM(domainPtr, A_Domain_EvtGenNatEn) == EvtGen_CreateSessionAndCheck) ||				/* PMSTA-30451-RAK-180305 - Mutual Funds Systematic Plan */
        				
        				(IS_NULLFLD(domainPtr, A_Domain_SessionStatusEn)	== FALSE &&
        				 (SESSIONSTATUS_ENUM)GET_ENUM(domainPtr, A_Domain_SessionStatusEn)	!= SessionStatus_None && /* PMSTA16378-CHU-130603 */
        				 IS_NULLFLD(domainPtr, A_Domain_SessionNatureEn)	== FALSE &&
        				 (DOMSESSIONNAT_ENUM)GET_ENUM(domainPtr, A_Domain_SessionNatureEn)  != DomSessionNat_None) /* PMSTA16378-CHU-130603 */
        				||
        				(IS_NULLFLD(domainPtr, A_Domain_ProposalNatureEn)	== FALSE &&
        				 (PROPOSALNAT_ENUM)GET_ENUM(domainPtr, A_Domain_ProposalNatureEn)	!= ProposalNat_None) /* PMSTA16378-CHU-130603 */
        				|| 
        				IS_NULLFLD(domainPtr, A_Domain_JobReference)		== FALSE)
                        ||
                        ((IS_NULLFLD(domainPtr, A_Domain_SessionNatureEn) == FALSE &&     /*PMSTA-53578-CHANDRU-04072013*/ /*Delete old cases if any modification or start over is initiated via PtfBulder*/
                         ((DOMSESSIONNAT_ENUM)GET_ENUM(domainPtr, A_Domain_SessionNatureEn) == DomSessionNat_PortfolioBuilder) ||
                         ((DOMSESSIONNAT_ENUM)GET_ENUM(domainPtr, A_Domain_SessionNatureEn) == DomSessionNat_PortfolioBuilderSameStrategy) ||
                         ((DOMSESSIONNAT_ENUM)GET_ENUM(domainPtr, A_Domain_SessionNatureEn) == DomSessionNat_PortfolioBuilderSimpleHierarchy) ||
                         ((DOMSESSIONNAT_ENUM)GET_ENUM(domainPtr, A_Domain_SessionNatureEn) == DomSessionNat_PortfolioBuilderDetailedHierarchy) ||
                         ((DOMSESSIONNAT_ENUM)GET_ENUM(domainPtr, A_Domain_SessionNatureEn) == DomSessionNat_PortfolioBuilderHeteroclite) ||
                         ((DOMSESSIONNAT_ENUM)GET_ENUM(domainPtr, A_Domain_SessionNatureEn) == DomSessionNat_PortfolioBuilderOverlay)) &&
                         (GET_ENUM(domainPtr, A_Domain_FctResultStatEn) != FctResultStatus_Final)))
        			{
                        /* WEALTH-233 cases should not be deleted if compute data is set as retain ESE. */
                        if (GET_ENUM(domainPtr, A_Domain_CompDataEn) != (ENUM_T)CompData_DeleteESEAndRetainCases) 
                        {
                            if ((ret = DBA_TabulaRasa(GET_ID(getArg, Get_Arg_Id),
                                CaseManagementNat_Last,
                                &connectNo)) != RET_SUCCEED)
                            {
                                /*PMSTA-44536-ARUN-05042021*/
                                DBA_EndTransaction(connectNo, FALSE);
                                DBA_EndConnection(connectNo);
                                return(RET_SRV_LIB_ERR_COMMAND_ABORTED);
                            }
                        }
        			}
                  } /* > OCS-39365-CHU-111017 */
              }
		 }

		/* del ext_op if needed */		  
		if ( (fctDictId == DictFct_AllocateOrder) || (fctDictId == DictFct_ReconcStrat) ||
             (fctDictId == DictFct_OrderAllocation) ||	/* REF7228 - RAK - 011205 */
			 (fctDictId == DictFct_EventGeneration))	/* PMSTA06761 - RAK - 080805 */
		{
            /* REF5219 - RAK - 000913 - DBA_SET_CONN|DBA_NO_CLOSE */
		    if ((ret = DBA_Delete2(EOp, DBA_ROLE_LOAD_STRAT_LNK, 
				       Get_Arg, getArg, DBA_SET_CONN|DBA_NO_CLOSE, 
                       &connectNo)) != RET_SUCCEED)
		    {
	            	DBA_EndTransaction(connectNo, FALSE);
	            	DBA_EndConnection(connectNo);
			        return(RET_SRV_LIB_ERR_COMMAND_ABORTED);
		    }
		}
		
		/* OCS-47441 - CODE CHANGES FOR ADVISORY PG - Deletion of ext_operations*/
		if (fctDictId == DictFct_PreTradeCheckStrat && 
		(DOMSESSIONNAT_ENUM)GET_ENUM(domainPtr, A_Domain_SessionNatureEn) == DomSessionNat_InvestmentProposal)
		{
			if ((sDomain = ALLOC_DYNST(S_Domain)) == NULL)
			{
				MSG_RETURN(RET_MEM_ERR_ALLOC);
			}

			if ((aDomain = ALLOC_DYNST(A_Domain)) == NULL)
			{
				FREE_DYNST(sDomain, S_Domain);
				MSG_RETURN(RET_MEM_ERR_ALLOC);
			 }

			SET_ID(sDomain, S_Domain_Id, GET_ID(domainPtr, A_Domain_Id));

            /*PMSTA-44536-ARUN-05042021  In case the domaintPtr->domainId is null , fetch it from function result and populate*/
            if (GET_ID(domainPtr, A_Domain_Id) == (ID_T)NULL)
            {
                if (IS_NULLFLD(domainPtr, A_Domain_FctResultId) == FALSE)
                {
                    if ((admArg = ALLOC_DYNST(Adm_Arg)) == NULLDYNST)
                    {
                        MSG_RETURN(RET_MEM_ERR_ALLOC);
                    }

                    if ((sFctResultPtr = ALLOC_DYNST(S_FctResult)) == NULLDYNST)
                    {
                        FREE_DYNST(admArg, Adm_Arg);
                        MSG_RETURN(RET_MEM_ERR_ALLOC);
                    }

                    fctResId = GET_ID(domainPtr, A_Domain_FctResultId);
                    SET_ID(admArg, Adm_Arg_Id, fctResId);

                    ret = DBA_Get2(FctResult, UNUSED, Adm_Arg, admArg,
                        S_FctResult, &sFctResultPtr, UNUSED, UNUSED, UNUSED);
                    if (ret == RET_SUCCEED)
                    {
                        SET_ID(sDomain, S_Domain_Id, GET_ID(sFctResultPtr, A_FctResult_DomainId));
                    }


                    FREE_DYNST(admArg, Adm_Arg);
                    FREE_DYNST(sFctResultPtr, S_FctResult);
                }

            }

			if (DBA_Get2(Domain, UNUSED, S_Domain, sDomain, A_Domain, &aDomain,
				DBA_SET_CONN | DBA_NO_CLOSE,
				&connectNo, UNUSED) != RET_SUCCEED) /*DLA - REF7057 - 011003 */
			{
				FREE_DYNST(sDomain, S_Domain);
				FREE_DYNST(aDomain, A_Domain);
				return(RET_DBA_ERR_NODATA);
			}
			FREE_DYNST(sDomain, S_Domain);
			/* OCS-47741 - SHR - 061016 */
			if (GET_ID(domainPtr, A_Domain_StratObjId) != GET_ID(aDomain, A_Domain_StratObjId))
				{
					if ((ret = DBA_Delete2(CaseManagement, UNUSED,
						Get_Arg, getArg, DBA_SET_CONN | DBA_NO_CLOSE,
						&connectNo)) != RET_SUCCEED)
					{
						DBA_EndTransaction(connectNo, FALSE);
						DBA_EndConnection(connectNo);
						FREE_DYNST(aDomain, A_Domain);
						return(RET_SRV_LIB_ERR_COMMAND_ABORTED);
					}
				}
			if (GET_ENUM(domainPtr, A_Domain_LoadHierFlg) != GET_ENUM(aDomain, A_Domain_LoadHierFlg))
				{
					if ((ret = DBA_Delete2(EOp, DBA_ROLE_LOAD_STRAT_LNK, 
						  Get_Arg, getArg, DBA_SET_CONN | DBA_NO_CLOSE,
						  &connectNo)) != RET_SUCCEED)
					{
						DBA_EndTransaction(connectNo, FALSE);
						DBA_EndConnection(connectNo);
						FREE_DYNST(aDomain, A_Domain);
						return(RET_SRV_LIB_ERR_COMMAND_ABORTED);
					}
					if ((ret = DBA_Delete2(ExtOrder, UNUSED,
						Get_Arg, getArg, DBA_SET_CONN | DBA_NO_CLOSE,
						&connectNo)) != RET_SUCCEED)
					{
						DBA_EndTransaction(connectNo, FALSE);
						DBA_EndConnection(connectNo);
						FREE_DYNST(aDomain, A_Domain);
						return(RET_SRV_LIB_ERR_COMMAND_ABORTED);
					}
					/* OCS - 48178 - sshreyos - 160502 */
					if ((ret = DBA_Delete2(CaseManagement, UNUSED,
						Get_Arg, getArg, DBA_SET_CONN | DBA_NO_CLOSE,
						&connectNo)) != RET_SUCCEED)
					{
						DBA_EndTransaction(connectNo, FALSE);
						DBA_EndConnection(connectNo);
						FREE_DYNST(aDomain, A_Domain);
						return(RET_SRV_LIB_ERR_COMMAND_ABORTED);
					}
					/* OCS - 48183 - sshreyos - 160509 */
					if ((ret = DBA_Delete2(ApplComment, UNUSED,
						Get_Arg, getArg, DBA_SET_CONN | DBA_NO_CLOSE,
						&connectNo)) != RET_SUCCEED)
					{
						DBA_EndTransaction(connectNo, FALSE);
						DBA_EndConnection(connectNo);
						FREE_DYNST(aDomain, A_Domain); 
						return(RET_SRV_LIB_ERR_COMMAND_ABORTED);

					}

				}

		}

	    DBA_EndTransaction(connectNo, TRUE);
	    DBA_EndConnection(connectNo);
		FREE_DYNST(aDomain, A_Domain);
	}

      /* REF5104 - SSO - 000918 : if pre-trade check, keep order entry as A_Domain_FctDictId in db ! */
		if ((fctDictId == DictFct_PreTradeCheckStrat) ||
            (fctDictId == DictFct_OrderEntryAllocate))
		{
/*              FIH-REF7228-011211  May be Order Entry or Order Allocation
                SET_DICT(domainPtr, A_Domain_FctDictId, DictFct_OrderEntry);
*/
			SET_DICT(domainPtr, A_Domain_FctDictId, GET_DICT(domainPtr, A_Domain_InitialFctDictId)); /* DLA - REF9089 - 030512 */
		}
           
		/* OCS-44766 - CHU - 140526 : change condition, session should be updated to 'checked' */
		/* PMSTA-18107 - CHU - 140513 : check if update is not useless */
		if (GET_ENUM(domainPtr, A_Domain_CompDataEn) != CompData_Append)
			/*
			IS_NULLFLD(domainPtr, A_Domain_ChunkNumber)==TRUE &&
			IS_NULLFLD(domainPtr, A_Domain_JobReference)==TRUE)
			*/
		{
		/* upd domain */
		DBA_RestorePtfDim(domainPtr); /* PMSTA09899-CHU-100521 */
		if ((ret = DBA_Update2(Domain, UNUSED, 
				   A_Domain, domainPtr, UNUSED, UNUSED)) != RET_SUCCEED)
		{
		    return(RET_SRV_LIB_ERR_COMMAND_ABORTED);
		}
			DBA_SetTascJobPtfDim(domainPtr, NULL); /* PMSTA09899-CHU-100521 */ /* OCS-49362 - TEB - 170508 */
		}

		/* init fctResStp from existing one (cf DBA_NewFctResult but without insert) */
		if (((*fctResStp) = ALLOC_DYNST(A_FctResult)) == NULLDYNST)
			return(RET_MEM_ERR_ALLOC);
        
		SET_DICT((*fctResStp), A_FctResult_FctDictId, GET_DICT(domainPtr, A_Domain_FctDictId));
        
        if (IS_NULLFLD(domainPtr, A_Domain_FctResultCd) == FALSE)
        {
			COPY_DYNFLD((*fctResStp), A_FctResult, A_FctResult_Cd,
				        domainPtr,    A_Domain,    A_Domain_FctResultCd);
        }
		
        COPY_DYNFLD((*fctResStp), A_FctResult, A_FctResult_DomainId, 
			    domainPtr,    A_Domain,    A_Domain_Id);
		
        COPY_DYNFLD((*fctResStp), A_FctResult, A_FctResult_UserId, 
			    domainPtr,    A_Domain,    A_Domain_UsrId);
		
        COPY_DYNFLD((*fctResStp), A_FctResult, A_FctResult_CalcFromDate, 
			    domainPtr,    A_Domain,    A_Domain_InterpFromDate);
        
        COPY_DYNFLD((*fctResStp), A_FctResult, A_FctResult_CalcStratDate, 
			    domainPtr,    A_Domain,    A_Domain_InterpStratDate);
       
        COPY_DYNFLD((*fctResStp), A_FctResult, A_FctResult_Id,
                    domainPtr,    A_Domain,    A_Domain_Id);

        COPY_DYNFLD((*fctResStp), A_FctResult, A_FctResult_DimPtfDictId,
                    domainPtr,    A_Domain,    A_Domain_DimPtfDictId);
        COPY_DYNFLD((*fctResStp), A_FctResult, A_FctResult_PtfObjId,
                    domainPtr,    A_Domain,    A_Domain_PtfObjId);

        COPY_DYNFLD((*fctResStp), A_FctResult, A_FctResult_DimInstrDictId,
                    domainPtr,    A_Domain,    A_Domain_DimInstrDictId);
        COPY_DYNFLD((*fctResStp), A_FctResult, A_FctResult_InstrObjId,
                    domainPtr,    A_Domain,    A_Domain_InstrObjId);

        COPY_DYNFLD((*fctResStp), A_FctResult, A_FctResult_DimStratDictId,
                    domainPtr,    A_Domain,    A_Domain_DimStratDictId);
        COPY_DYNFLD((*fctResStp), A_FctResult, A_FctResult_StratObjId,
                    domainPtr,    A_Domain,    A_Domain_StratObjId);

        COPY_DYNFLD((*fctResStp), A_FctResult, A_FctResult_StatusEn,
                    domainPtr,    A_Domain,    A_Domain_FctResultStatEn);

        /* REF5104 - SSO - 000918 : if pre-trade check, keep order entry as A_Domain_FctDictId in db ! */
        if (fctDictId == DictFct_PreTradeCheckStrat) 
        {
            SET_DICT(domainPtr, A_Domain_FctDictId, DictFct_PreTradeCheckStrat); /* restore */
        }

        if (fctDictId == DictFct_OrderEntryAllocate) 
        {
            SET_DICT(domainPtr, A_Domain_FctDictId, DictFct_OrderEntryAllocate); /* restore */
            /*SET_DICT(domainPtr, A_Domain_InitialFctDictId, DictFct_OrderEntryAllocate);*/
        }
	}

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_EvtGenerationSession
**
**  Description :   Create (or update) a session with generated operation
**
**  Return      :  
**
**  Creation	:   PMST06761 - RAK - 080730
**
*************************************************************************/
STATIC RET_CODE FIN_EvtGenerationSession(DBA_DYNFLD_STP domainPtr, 
										 DBA_HIER_HEAD_STP hierHead)
{
	DBA_DYNFLD_STP			*EOTab=NULLDYNSTPTR, fctResStp=NULLDYNST;
	int						i, EONbr=0;
	DICT_FCT_STP			dictFctInfo;
	ID_T					fctResId;
	RET_CODE				ret=RET_SUCCEED;
    DbiConnectionHelper     dbiConnHelper; /* PMSTA-26888 - CHU 170629 */
    MemoryPool              mp;

	DBA_GetDictFctInfo(GET_DICT(domainPtr, A_Domain_FctDictId), DictFctInfo_Stp, &dictFctInfo); 

	DBA_DYNFLD_STP getArg = mp.allocDynst(FILEINFO,Get_Arg);

	if (IS_NULLFLD(domainPtr, A_Domain_FctResultId) == FALSE)
	{	
	    SET_ID(getArg, Get_Arg_Id, GET_ID(domainPtr, A_Domain_FctResultId)); 
	}

	switch (GET_ENUM(domainPtr, A_Domain_CompDataEn))
	{
	case CompData_CompNew: 
		
		if ((ret = FIN_ComputeNewFctResult(domainPtr,  &fctResStp)) != RET_SUCCEED)
		{
			return(ret);
		}
        mp.ownerDynStp(fctResStp);
		break;

	case CompData_ReplOld:
    case CompData_SelectiveReplOld: /* PMSTA-29302 - CHU - 180109 */
		
		if ((ret = FIN_ReplOldFctResult(domainPtr, getArg, &fctResStp)) != RET_SUCCEED)
		{
			return(ret);
		}
        mp.ownerDynStp(fctResStp);
		break;

	case CompData_Delete:
		
		ret = FIN_DeleteFctResult(domainPtr, getArg);
		return(ret);
		break;

	case CompData_DeleteAll:
		
		ret = FIN_DeleteAllFctResult(domainPtr, getArg);
		return(ret);
		break;
	}

	if ((ret = DBA_ExtractHierEltRec(hierHead, ExtOp, 
		       	                    FALSE, NULLFCT, NULLFCT, 
		       		                &EONbr, &EOTab)) != RET_SUCCEED)
	{
		return(ret);
	}

    mp.ownerPtr(EOTab);
	
	fctResId = GET_ID(domainPtr, A_Domain_FctResultId);

	for (i=0; i < EONbr; i++)
	{
		SET_ID(EOTab[i], ExtOp_FctResultId, fctResId);
	}
	
	ret = DBA_FamilyOrder(Action_SaveDraft, 
						  (DBA_DYNFLD_STP*) EOTab,
						  EONbr,
							0, 	
							NULLDYNST, 
							(PTR) NULL,
							DBA_NO_ERROR,
                            dbiConnHelper, /* PMSTA-26888 - CHU 170629 */
							GET_DICT(domainPtr, A_Domain_FctDictId),
							domainPtr, 
							NULLDYNSTPTR, 0,	/* CaseManagement */ /* PMSTA07121-CHU-081030 */
							NULLDYNSTPTR,		/* PMSTA09118-CHU-100121 - draft FctRes */
                            (PTR)NULL,          /* PMSTA-28596 - CHU - 171012 */
                            false);             /* PMSTA-31673 - CHU - 180607 : to know if session splitting was already performed */



	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_CreatePropAttribCashOpe
**
**  Description :   Create an cash operation for proportional attribution
**
**  Arguments   :  stock	    - pointer to position 
**		   extOperation	    - pointer to the extended ope to generate 
**		   hierHead	    - pointer to hierarchy
**		   fromDateTime	    - start date
**		   scptFlagTabExtOp - DV table
**		   cashAmt	    - current cash amount of the previous ope.
**  Return      :  
**
**  Creation	:   REF4505 - AKO - 000327
**
*************************************************************************/
STATIC RET_CODE	FIN_CreatePropAttribCashOpe(DBA_DYNFLD_STP  stock, 
                                            DBA_DYNFLD_STP	    extOperation,			             
                                            DBA_HIER_HEAD_STP	    hierHead,
                                            DATETIME_T		    fromDateTime,
                                            FLAG_T		    *scptFlagTabExtOp,
                                            NUMBER_T		    cashAmt)
{
    RET_CODE		retCd=RET_SUCCEED;
    DBA_DYNFLD_STP	oldInstr=NULL, pricePtr=NULL;
    NUMBER_T		supplAmt=0.0, grossCostAmt=0.0, 
			priceN_1jour=0.0, oldInstrQty=0.0;
    FLAG_T		freeOldInstrFlg=FALSE;
    ID_T		BPTypeId=(ID_T)0;

    /* Currency P balance position type id */
    if (GEN_GetApplInfo(ApplCapPBpTypeId, &BPTypeId)!=TRUE)
	MSG_RETURN(RET_GEN_ERR_INVARG);
    /*SET_ID(extOperation, ExtOp_BalPosTpId,   BPTypeId);
    scptFlagTabExtOp[ExtOp_BalPosTpId]=TRUE;       
    */
    SET_ID(extOperation, ExtOp_AdjBpTpId,   BPTypeId);
    scptFlagTabExtOp[ExtOp_AdjBpTpId]=TRUE;   


    /* retrieve Old instrument */
    if ((retCd=DBA_GetInstrById(GET_ID(stock, ExtPos_InstrId), TRUE, &freeOldInstrFlg, 
			 &oldInstr, hierHead, UNUSED, UNUSED)) != RET_SUCCEED)
    {
	 MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "Instr");
	 return(RET_DBA_ERR_NODATA);
    }

    if ((pricePtr = ALLOC_DYNST(A_InstrPrice)) == NULL)
    {
	if (freeOldInstrFlg==TRUE) {FREE_DYNST(oldInstr, A_Instr);}
	MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    /* get the price of the old instrument */
    fromDateTime.date = DATE_Move(GET_DATE(extOperation, ExtOp_AcctDate), (-1), Day); 
    if ((retCd=FIN_InstrPrice(GET_ID(oldInstr, A_Instr_Id), NULL, fromDateTime,
			NULL, (ID_T)0, NULL, NULL, NULL,
			hierHead, pricePtr, FALSE)) != RET_SUCCEED) /* PMSTA14876 - DDV - 120911 - Add a new parameter, no impact for this call */
    {
	MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, "FIN_CreatePropAttribCashOpe", 
		     GET_CODE(oldInstr, A_Instr_Cd), "InstrPrice");
	FREE_DYNST(pricePtr, A_InstrPrice);
	if (freeOldInstrFlg==TRUE) {FREE_DYNST(oldInstr, A_Instr);}
	return(retCd);
    }
    else
    {
	priceN_1jour = GET_PRICE(pricePtr, A_InstrPrice_Price);
    }

    SET_PRICE(extOperation, ExtOp_Price, 0.0);
    SET_PRICE(extOperation, ExtOp_Quote, 0.0);
    scptFlagTabExtOp[ExtOp_Price]=TRUE;   
    scptFlagTabExtOp[ExtOp_Quote]=TRUE;  

    COPY_DYNFLD(extOperation,ExtOp,ExtOp_AdjInstrId,stock,ExtPos,ExtPos_InstrId);
    scptFlagTabExtOp[ExtOp_AdjInstrId]=TRUE;   

    COPY_DYNFLD(extOperation, ExtOp, ExtOp_InstrId, stock,ExtPos,ExtPos_InstrId);
    scptFlagTabExtOp[ExtOp_InstrId]=TRUE;

    SET_ENUM(extOperation, ExtOp_AdjNatEn, OpAdjustNat_GrossAmt);
    scptFlagTabExtOp[ExtOp_AdjNatEn]=TRUE;     
    SET_NUMBER(extOperation, ExtOp_AdjQty, 0);
    scptFlagTabExtOp[ExtOp_AdjQty]=TRUE;       
    SET_NUMBER(extOperation, ExtOp_Qty, 0.0);
    scptFlagTabExtOp[ExtOp_Qty]=TRUE;
    COPY_DYNFLD(extOperation, ExtOp, ExtOp_AdjPosCurrId, stock, ExtPos, ExtPos_PosCurrId);
    scptFlagTabExtOp[ExtOp_AdjPosCurrId]=TRUE; 
    COPY_DYNFLD(extOperation, ExtOp, ExtOp_AdjDepoId, stock, ExtPos, ExtPos_DepoId);
    scptFlagTabExtOp[ExtOp_AdjDepoId]=TRUE;   
    

    SET_ID(extOperation, ExtOp_InstrCurrId, GET_ID(oldInstr, A_Instr_RefCurrId));
    scptFlagTabExtOp[ExtOp_InstrCurrId]=TRUE;

    SET_ENUM(extOperation, ExtOp_DbStatusEn, ExtOpDbStatus_ToInsert);
    SET_FLAG(extOperation, ExtOp_ConfirmedFlg, TRUE); 

    /* ----------- */
    /* use formula */
    /* ----------- */
    if (IS_NULLFLD(stock, ExtPos_Qty)!=TRUE)
	{oldInstrQty = GET_NUMBER(stock, ExtPos_Qty);}

    /* gross cost amount in extPos */
    if (IS_NULLFLD(stock, ExtPos_PosGrossAmt)!=TRUE)
	grossCostAmt = GET_NUMBER(stock, ExtPos_PosGrossAmt);
    
    if ((CMP_NUMBER(priceN_1jour*oldInstrQty, 0.0)!=0))
    {
	supplAmt = cashAmt * (1 - grossCostAmt / (priceN_1jour*oldInstrQty));
	SET_NUMBER(extOperation, ExtOp_SupplAmt, supplAmt);
	scptFlagTabExtOp[ExtOp_SupplAmt]=TRUE;
    }
    else
    {
	MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO,"FIN_CreatePropAttribCashOpe", 
		     GET_CODE(oldInstr, A_Instr_Cd), "InstrPrice - Price is null");
	retCd = RET_FIN_ERR_INVDATA;
    }
    FREE_DYNST(pricePtr, A_InstrPrice);

    if (freeOldInstrFlg==TRUE)
	FREE_DYNST(oldInstr, A_Instr);

    return(retCd);
}


/************************************************************************
**
**  Function    :   FIN_ComputePropAttribPrice
**
**  Description :   compute proportional attribution price
**
**  Arguments   :   hierHead	- hierarchy header pointer
**		    stock	- position
**
**
**  Return      :   RET_SUCCEED
**                  RET_MEM_ERR_ALLOC
**                  RET_GEN_ERR_INVARG
**		    retCd
**
**  Creation	:   REF3740 - AKO - 990721 
**
*************************************************************************/
STATIC RET_CODE	FIN_ComputePropAttribPrice(DBA_HIER_HEAD_STP	hierHead,
					   DBA_DYNFLD_STP	stock,
					   DBA_DYNFLD_STP	domainPtr)
{
    DBA_DYNFLD_STP	*extractExtOpTab=NULL, 
			        *currExtOpTab=NULL, newInstrPtr=NULL,
			        adjInstrPtr=NULL, pricePtr=NULL, operation=NULL,
			        flowPtr=NULL, ptfPtr=NULL;
    RET_CODE		retCd=RET_SUCCEED;
    DATETIME_T		firstPosDateTime;
    FLAG_T		    cancelFlg=FALSE, adjPLFlg = FALSE, hierFlg=TRUE, continueFlg=TRUE;
    AMOUNT_T		extOpSumCashAmt=0.0, extOpSumNetAmtNew=0.0, extPosNetAmtOld=0.0,
			        extPosGrossCostAmt=0.0;
    ID_T		    trgPtfCurrId=(ID_T)0, adjInstrId=(ID_T)0,srcInstrPriceCurrId=(ID_T)0;
    PRICE_T		propPrice=0.0, extOpPrice=0.0;
    AMOUNT_T		AdjPriceInstr=0.0, adjQty=0.0; 
    PRICE_T		    *extopPriceSave=NULL;
    FLAG_T          *scptFlagTabOp=NULL;
    FIN_EXCHARG_ST	exchArgSt;
    DBA_DYNFLD_STP  *flowExtension=NULL, *instrExtension=NULL;
    double		    adjExchRate=0.0;
    int			    extOpNbr=0,currExtOpNbr=0, i=0, firstPos=0, lastPos=0, adjIndex=-1;

    /* ------------------------------------------------------ */
    /* extract all adjustment operations having the same date */
    /* ------------------------------------------------------ */
    if (((retCd = DBA_ExtractHierEltRec(hierHead, ExtOp, 
		                                FALSE, FIN_FilterPropAttrib, FIN_CmpExtopByDate, 
		                                &extOpNbr, &extractExtOpTab)) != RET_SUCCEED) || (extOpNbr<=0))
    {
	return(RET_SUCCEED);
    }

    firstPosDateTime.time=0;
    extPosGrossCostAmt = GET_NUMBER(stock, ExtPos_RefGrossAmt);

    if ((scptFlagTabOp = (FLAG_T *) CALLOC(GET_FLD_NBR(AdjustOp),sizeof(FLAG_T))) == NULL) /* REF7264 - DDV - 020326 - Compil C++ */
    {
	for (i=0; i<extOpNbr; i++)
	    SET_ENUM(extractExtOpTab[i], ExtOp_DbStatusEn, ExtOpDbStatus_ToInsert);
        FREE(extractExtOpTab);
	MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    for (i=0; i<GET_FLD_NBR(AdjustOp) ;i++)
        scptFlagTabOp[i]=FALSE;

    scptFlagTabOp[AdjustOp_Quote]=TRUE; 
    scptFlagTabOp[AdjustOp_Price]=TRUE; 

    if ((operation = ALLOC_DYNST(AdjustOp)) == NULL)
    {
	for (i=0; i<extOpNbr; i++)
	    SET_ENUM(extractExtOpTab[i], ExtOp_DbStatusEn, ExtOpDbStatus_ToInsert);
        FREE(extractExtOpTab);
	FREE(scptFlagTabOp);
	MSG_RETURN(RET_MEM_ERR_ALLOC);
    }
  
    while (firstPos < extOpNbr)
    {
	continueFlg=TRUE;
	while ((lastPos < extOpNbr) && 
	       (GET_DATETIME(extractExtOpTab[lastPos], ExtOp_AcctDate).date ==
	        GET_DATETIME(extractExtOpTab[firstPos], ExtOp_AcctDate).date))
	{
	    lastPos++;
	}
	currExtOpTab = &(extractExtOpTab[firstPos]);
	currExtOpNbr = (lastPos - firstPos);

	/* save price for block */
	if ((extopPriceSave=(PRICE_T*)CALLOC(currExtOpNbr, sizeof(PRICE_T)))==NULL)
	{
	    for (i=0; i<extOpNbr; i++)
		SET_ENUM(extractExtOpTab[i], ExtOp_DbStatusEn, ExtOpDbStatus_ToInsert);
	    FREE(extractExtOpTab);
	    MSG_RETURN(RET_MEM_ERR_ALLOC);
	}
	else
	{
	    for (i=0; i < currExtOpNbr; i++)
	    {
		extopPriceSave[i] = GET_PRICE(currExtOpTab[i], ExtOp_Price); 
	    }
	}

	firstPos = lastPos;
	/* ------------- */
	/* cancel block  */
	/* ------------- */
	cancelFlg = FALSE;
	for (i=0; i<currExtOpNbr && cancelFlg == FALSE; i++)
	{
	    if (GET_ENUM(currExtOpTab[i], ExtOp_DbStatusEn)== ExtOpDbStatus_PropAttribExist)
		cancelFlg=TRUE;
	}

	if (cancelFlg == TRUE)
	{
	    /* free all records of the block of the multi-events */
	    for (i=0; i<currExtOpNbr; i++)
	    {
		    /* DelAndFree */ ;	
		    if ((retCd = DBA_DelAndFreeHierEltRec(hierHead, ExtOp, 
					                              currExtOpTab[i])) != RET_SUCCEED)
		    {
		        /* ignore all the the block of the multi-events */
		        continueFlg=FALSE;
		        break;
		    }
	    }

	    if (continueFlg==FALSE)
	    {
		/* treat next block of the multi-events */
		continue;
	    }
	}
	else
	{
	    for (i=0; i<currExtOpNbr; i++)
		SET_ENUM(currExtOpTab[i], ExtOp_DbStatusEn, ExtOpDbStatus_ToInsert);

	    /* ----------- */
	    /*  sum cash   */
	    /* ----------- */
	    extOpSumCashAmt	=   0.0;
	    extOpSumNetAmtNew	=   0.0;
	    adjPLFlg		=   FALSE;
	    hierFlg		=   TRUE;

	    for (i=0; i<currExtOpNbr; i++)
	    {
		if (NULL == GET_EXTENSION_PTR(currExtOpTab[i], ExtOp_A_Instr_Ext))
		{
		    continueFlg=FALSE;
		    break;
		}

		if((newInstrPtr = *(GET_EXTENSION_PTR(currExtOpTab[i],ExtOp_A_Instr_Ext)))==NULL)
		{
    		    continueFlg=FALSE;
		    break;
		}

		/* summ cash amount and check if P&L adjustment */
		firstPosDateTime.date = GET_DATETIME(extractExtOpTab[i], ExtOp_AcctDate).date;
		trgPtfCurrId = GET_ID(extractExtOpTab[i], ExtOp_PtfCurrId);
		if ((InstrNat_CashAcct == GET_ENUM(newInstrPtr, A_Instr_NatEn)) ||
		    (IS_NULLFLD(extractExtOpTab[i], ExtOp_AdjBpTpId)!=TRUE))
		{
		    /* -------------------------------------------------- */
		    /* REF4441 - AKO - 000412 substract new cash amount	  */
		    /* of type Capital profit of proportional attribution */
		    /* -------------------------------------------------- */
		    /* cash intrument - fill in Cash */
		    if (IS_NULLFLD(extractExtOpTab[i], ExtOp_AdjBpTpId)!=TRUE) 
			{extOpSumCashAmt += ((-1) * (GET_NUMBER(currExtOpTab[i], ExtOp_PtfNetAmt)));}
		    else
			{extOpSumCashAmt += GET_NUMBER(currExtOpTab[i], ExtOp_PtfNetAmt);} 
		}
		else
		{
		    /* other instrument - fill in NetAmtNew */
		    extOpSumNetAmtNew += GET_NUMBER(currExtOpTab[i], ExtOp_PtfNetAmt);
		}

		if (GET_ENUM(currExtOpTab[i], ExtOp_AdjNatEn) == OpAdjustNat_Pl)
		{
		    adjInstrId = GET_ID(currExtOpTab[i], ExtOp_AdjInstrId);
		    adjQty = GET_NUMBER(currExtOpTab[i], ExtOp_AdjQty);
		    srcInstrPriceCurrId = GET_ID(currExtOpTab[i], ExtOp_AdjInstrCurrId);
		    adjIndex = i;
		    adjPLFlg = TRUE;
		}
	    }

	    if (continueFlg==FALSE)
	    {
		/* treat nextblock of the multi-events */
		continue;
	    }

	    if (TRUE != adjPLFlg)
	    {
		if ( (GET_EXTENSION_PTR(stock, ExtPos_A_Instr_Ext) != NULL)
			&& ((adjInstrPtr = *(GET_EXTENSION_PTR(stock,
							       ExtPos_A_Instr_Ext)))== NULL))
		{
		    /* treat next block of the multi-events */
		    continue;
		}
		adjQty	= GET_NUMBER(stock, ExtPos_Qty);
	    }
	    else
	    {
		/* case adjutment P&L , retrieve adj. instrument */
		if (FIN_GetHierInstr(hierHead, adjInstrId,
				     (char *) &hierFlg, &adjInstrPtr) != RET_SUCCEED)
		{
		    if (hierFlg == FALSE)
			FREE_DYNST(adjInstrPtr, A_Instr);
		    /* treat the block of the multi-events */
		    continue;
		}
	    }

	    /* call instrPrice */
	    if ((pricePtr = ALLOC_DYNST(A_InstrPrice)) == NULL)
	    {
		if (hierFlg == FALSE)
			FREE_DYNST(adjInstrPtr, A_Instr);
		FREE_DYNST(operation, AdjustOp);
		FREE(scptFlagTabOp);
		FREE(extractExtOpTab);
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }

	    /* set variables */
	    if (FIN_InstrPrice(GET_ID(adjInstrPtr, A_Instr_Id), NULL, firstPosDateTime,
				NULL, (ID_T)0, NULL, NULL, NULL,
				hierHead, pricePtr, FALSE) != RET_SUCCEED) /* PMSTA14876 - DDV - 120911 - Add a new parameter, no impact for this call */
	    {
		MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
			     "FIN_ComputePropAttribPrice", 
			     GET_CODE(adjInstrPtr, A_Instr_Cd), "InstrPrice");
		FREE_DYNST(pricePtr, A_InstrPrice);
		if (hierFlg == FALSE)
			FREE_DYNST(adjInstrPtr, A_Instr);
		continue;   /* treat next block of the multi-events */
	    }

	    AdjPriceInstr	= GET_PRICE(pricePtr,A_InstrPrice_Price); 
	    srcInstrPriceCurrId	= GET_ID(pricePtr, A_InstrPrice_CurrId);

	    /* free price instrument */
	    FREE_DYNST(pricePtr, A_InstrPrice);
	    if (hierFlg == FALSE)
		FREE_DYNST(adjInstrPtr, A_Instr);


	    memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));
	    if (FIN_GetExchRate(GET_DATETIME(stock, ExtPos_OpDate), 
				srcInstrPriceCurrId,
				trgPtfCurrId,
		    		(ID_T)0, NULL, stock, &exchArgSt, &adjExchRate) != RET_SUCCEED) /* PMSTA01649 - TGU - 070402 */
	    {
		continue;
	    }

	    /* ------------------------------------------ */
	    /*  if instr A = C use ExtPos.instrExchRate	  */
	    /* ------------------------------------------ */
	    /* REF3912 - 990820 - AKO */
	    if ((adjIndex > -1) && (adjIndex < currExtOpNbr))
	    {
		if (GET_ID(currExtOpTab[adjIndex], ExtOp_AdjInstrCurrId) == GET_ID(stock, ExtPos_InstrCurrId))
		{
		    if (IS_NULLFLD(stock, ExtPos_InstrExchRate)!=TRUE)
		    {
			adjExchRate = GET_NUMBER(stock, ExtPos_InstrExchRate);
		    }
		    else
		    {
			MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
			     "FIN_ComputePropAttribPrice", 
			     GET_CODE(adjInstrPtr, A_Instr_Cd), "InstrExchRate in position is NULL");
		    }
		}
		else if (GET_ID(currExtOpTab[adjIndex], ExtOp_AdjInstrCurrId) == GET_ID(stock, ExtPos_PosCurrId))
		{
		    if (IS_NULLFLD(stock, ExtPos_PosExchRate)!=TRUE)
		    {
			adjExchRate = GET_NUMBER(stock, ExtPos_PosExchRate);
		    }
		    else
		    {
			MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
			     "FIN_ComputePropAttribPrice", 
			     GET_CODE(adjInstrPtr, A_Instr_Cd), "PosExchRate in position is NULL");
		    }
		}
		else 
		{
		    if (GET_EXTENSION_PTR(stock, ExtPos_A_Ptf_Ext) != NULL)
		    {
			    ptfPtr = *(GET_EXTENSION_PTR(stock,ExtPos_A_Ptf_Ext));
		    }

		    if (ptfPtr != NULL)
		    {
			if (IS_NULLFLD(ptfPtr, A_Ptf_SysCurrId) != TRUE)
			{
			    if (GET_ID(currExtOpTab[adjIndex], ExtOp_AdjInstrCurrId) 
				== GET_ID(ptfPtr, A_Ptf_SysCurrId))
			    {
				if (IS_NULLFLD(stock, ExtPos_SysExchRate)!=TRUE)
				{
				    adjExchRate = GET_NUMBER(stock, ExtPos_SysExchRate);
				}
				else
				{
				    MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
					 "FIN_ComputePropAttribPrice", 
					 GET_CODE(adjInstrPtr, A_Instr_Cd), "SysExchRate in position is NULL");
				}
			    }
			}
			else
			{
			    ID_T    applCurrId= (ID_T)0;
			    GEN_GetApplInfo(ApplSysCurrId, &applCurrId);

			    if (GET_ID(currExtOpTab[adjIndex], ExtOp_AdjInstrCurrId) == applCurrId)
			    {
				if (IS_NULLFLD(stock, ExtPos_SysExchRate)!=TRUE)
				{

				    adjExchRate = GET_NUMBER(stock, ExtPos_SysExchRate);
				}
				else
				{
				    MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
					 "FIN_ComputePropAttribPrice", 
					 GET_CODE(adjInstrPtr, A_Instr_Cd), "SysExchRate in position is NULL");
				}
			    }
			}
		    }

		}
	    }

	    /* ------------------------- */
	    /* sub_formula of NetAmtOld  */
	    /* ------------------------- */
	    extPosNetAmtOld = AdjPriceInstr * adjQty * adjExchRate;
	    extPosNetAmtOld = CAST_AMOUNT(extPosNetAmtOld, trgPtfCurrId);

	    /* ---------------------------------- */
	    /*  Compute current Block of n-events */
	    /* ---------------------------------- */
	    /* compute new price via formula-2 */

	    for (i=0; i<currExtOpNbr; i++)
	    {
		DBA_DYNFLD_STP	tmpInstrPtr=NULL;
		PRICE_T  quoteCalc=0.0;

		continueFlg = TRUE;
		SET_ENUM(currExtOpTab[i], ExtOp_DbStatusEn, ExtOpDbStatus_ToInsert); 
		SET_FLAG(currExtOpTab[i], ExtOp_ConfirmedFlg, TRUE);
		extOpPrice = GET_PRICE(currExtOpTab[i], ExtOp_Price);

		if (NULL == GET_EXTENSION_PTR(currExtOpTab[i], ExtOp_A_Instr_Ext))
		{
		    MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
			     "FIN_ComputePropAttribPrice", 
			     GET_ID(currExtOpTab[i], A_Instr_Id), "get_extension to instr");
		    continueFlg = FALSE;
		    break;
		}
		if((tmpInstrPtr = *(GET_EXTENSION_PTR(currExtOpTab[i],ExtOp_A_Instr_Ext)))==NULL)
		{
		    MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
			     "FIN_ComputePropAttribPrice", 
			     GET_ID(currExtOpTab[i], A_Instr_Id), "get_extension to instr");
		    continueFlg = FALSE;
		    break;
		}

		/* don't compute price for Cash Account */ 
		/* DDV - 990806 - convert Extop To extPos for journal ! */
		if (GET_ENUM(tmpInstrPtr, A_Instr_NatEn) != InstrNat_CashAcct)
		{

		    if (CMP_NUMBER((extOpSumNetAmtNew + extPosNetAmtOld) , 0.0) == 0)
		    {
		        MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
			         "FIN_ComputePropAttribPrice", 
			         GET_CODE(tmpInstrPtr, A_Instr_Cd), "division by zero - Events not treated");
		        continueFlg = FALSE;
		        break;
		    }
    
		    /* ----------- */
		    /* formule-2   */
		    /* ----------- */
		    propPrice = extOpPrice * (extPosGrossCostAmt - extOpSumCashAmt) / 
			        (extOpSumNetAmtNew + extPosNetAmtOld);

		    /* dfv, extop to op */

		    /* Load and initialise flag array for script */
		    SET_PRICE(currExtOpTab[i], ExtOp_Price, propPrice);
		    FIN_PriceToQuote((PRICECALCRULE_ENUM) GET_ENUM(newInstrPtr, A_Instr_PriceCalcRuleEn), /* REF7264 - DDV - 020326 - Compil C++ */
				     GET_ID(newInstrPtr, A_Instr_Id), 
				     newInstrPtr,
				     firstPosDateTime, 
				     NULL, 
				     propPrice,
				     &quoteCalc,
				     hierHead);
		    SET_PRICE(currExtOpTab[i], ExtOp_Quote, quoteCalc);

		    OPE_ExtOpToOp(currExtOpTab[i], operation, hierHead,FALSE);        /*  FPL-REF9215-030811  */
		    SCPT_ComputeDV(AdjustOpEnt, scptFlagTabOp, operation, FALSE, TRUE, NULL); /* REF4229 - SSO - 000919 */

		    /* store information of extension 
		       to restore it after convertion from operation to extoperation */
		    flowExtension = GET_EXTENSION_PTR(currExtOpTab[i], ExtOp_A_Flow_Ext);
		    instrExtension = GET_EXTENSION_PTR(currExtOpTab[i], ExtOp_A_Instr_Ext);
    
		    if (OPE_OpToExtOp(operation, (OPNAT_ENUM) GET_ENUM(currExtOpTab[i], ExtOp_NatureEn), currExtOpTab[i], FALSE) != RET_SUCCEED)  /*  FPL-REF9215-030811  Add Flag Impact */ /* REF7264 - DDV - 020326 - Compil C++ */
		    {
		        MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
			         "FIN_ComputePropAttribPrice", 
			         GET_CODE(tmpInstrPtr, A_Instr_Cd), "OPE_OpToExtOp - Events not treated");
		        continueFlg = FALSE;
		        break;
		    }

		    /* restore extension */
		    SET_EXTENSION(currExtOpTab[i], ExtOp_A_Flow_Ext, flowExtension, Flow, 1);
		    SET_EXTENSION(currExtOpTab[i], ExtOp_A_Instr_Ext, instrExtension, A_Instr, 1);
		    SET_ENUM(currExtOpTab[i], ExtOp_DbStatusEn, ExtOpDbStatus_ToInsert);
		    SET_FLAG(currExtOpTab[i], ExtOp_ConfirmedFlg, TRUE); 
		}
		
		/* split for journal */
		if (DictFct_Journal == (DICT_FCT_ENUM) GET_ID(domainPtr, A_Domain_FctDictId)) 
		{
		    if (NULL == GET_EXTENSION_PTR(currExtOpTab[i], ExtOp_A_Flow_Ext))
			    continue;   /* treat the next block of the multi-events */

		    if((flowPtr = *(GET_EXTENSION_PTR(currExtOpTab[i],ExtOp_A_Flow_Ext)))==NULL)
			    continue;  /* treat the next block of the multi-events */

		    /* Block moved to function FIN_SplitExtOpForJrnl */
		    /* operation not already exist in database - we insert */
		    if ((retCd=FIN_SplitExtOpForJrnl(currExtOpTab[i],
						   trgPtfCurrId, /* ??? */
						   (FUSDATERULE_ENUM) GET_ENUM(domainPtr, A_Domain_FusDateRuleEn),
						   newInstrPtr,
						   hierHead,
						   flowPtr,/* ??? */
						   domainPtr,/* ??? */
                           ptfPtr)) != RET_SUCCEED)
		    {
			    MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
				            "FIN_ComputePropAttribPrice", 
				            GET_CODE(tmpInstrPtr, A_Instr_Cd), 
                            "OPE_OpToExtOp - Events not treated");
			    continueFlg = FALSE;
			    break;
		    }

		    /* DDV - 990806 - Del and Free extended operation from hierachy */
		    DBA_DelAndFreeHierEltRec(hierHead, ExtOp, currExtOpTab[i]);
		}
	    }

	    /* restore ExtOp_Price related to the current bloc */
	    if (FALSE==continueFlg)
	    {
		    for (i=0; i < currExtOpNbr; i++)
		    {
		        SET_PRICE(currExtOpTab[i], ExtOp_Price, extopPriceSave[i]); 
		    }
		    continue;
	    }
	}
	/* firstPos = lastPos; */
	FREE(extopPriceSave);
    } /* end while */

    FREE_DYNST(operation, AdjustOp);
    FREE(scptFlagTabOp);
    FREE(extractExtOpTab);

    return(retCd);
}


/************************************************************************
**
**  Function    :   FIN_CmpExtopByDate()
**
**  Description :   Sort extended position by instrument
**
**  Arguments   :   ptr1    first element pointer
**                  prt2    second element pointer
**
**  Creation	:   REF3740 - AKO - 990715
**
*************************************************************************/
STATIC int FIN_CmpExtopByDate(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    return (DATETIME_CMP(GET_DATETIME((*ptr1), ExtOp_AcctDate), 
		                GET_DATETIME((*ptr2), ExtOp_AcctDate)));
}


/************************************************************************
**
**  Function    :   FIN_FilterPropAttrib()
**
**  Description :   Extract valid record for prop. attribution.
**		    return TRUE  -> record must be extract
**                         FALSE -> record musn't be extract
**                 
**  Arguments   :   dynSt      dynamic structure pointer
**                  dynStTp    dynamic structure definition
**
**  Return      :   TRUE or FALSE
**
**  Creation	:   REF3740 - AKO - 990715
**
*************************************************************************/
STATIC int FIN_FilterPropAttrib(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP notUsed) /* REF7264 - DDV - 020325 - Compil C++ */
{
    if (((GET_ENUM(dynSt, ExtOp_DbStatusEn) == ExtOpDbStatus_PropAttribCompPrice) ||
         (GET_ENUM(dynSt, ExtOp_DbStatusEn) == ExtOpDbStatus_PropAttribExist))  &&
	/*(GET_ENUM(dynSt, ExtOp_DbStatusEn) == ExtOpDbStatus_ToInsert)) && */
	(OpNat_Adjust == GET_ENUM(dynSt, ExtOp_NatureEn))
       )
	return(TRUE);
    else
	return(FALSE);
}

/*****************************************************************************************************
**
**  Function    :   FIN_IsLockedPos
**
**  Description :   Compute the quantity for income operation.
**                  This function load qantity from previous day and 
**                  compute the quantiy according to locked positions. 
**                  Only positions with benig egal to from date called this function.
**                 
**  Arguments   :   stock position to check
**
**
**  Return      :   TRUE or FALSE
**
**  Creation    :   REF10793 - DDV - 041130
**
**  Modif.      :   
**
*********************************************************************************************************/
STATIC FLAG_T FIN_IsLockedPos(DBA_DYNFLD_STP stock)
{
    if (GET_ENUM(stock, ExtPos_LockNatEn) == OpLockNat_LockedPos ||
	    GET_ENUM(stock, ExtPos_LockNatEn) == OpLockNat_LockedInstr ||
	    GET_ENUM(stock, ExtPos_LockNatEn) == OpLockNat_LockedUnderlyInstr ||
	    GET_ENUM(stock, ExtPos_LockNatEn) == OpLockNat_LockedCash ||
	    GET_ENUM(stock, ExtPos_LockNatEn) == OpLockNat_LockedUnderlyCash ||
	    GET_ENUM(stock, ExtPos_LockNatEn) == OpLockNat_RemereLocked)
        return(TRUE);
    else
        return(FALSE);
}

/*****************************************************************************************************
**
**  Function    :   FIN_ComputeIncomeQty
**
**  Description :   Compute the quantity for income operation.
**                  This function load qantity from previous day and 
**                  compute the quantiy according to locked positions. 
**                  Only positions with benig egal to from date called this function.
**                 
**  Arguments   :   hierHead   hierarchy header pointer
**
**
**  Return      :   a RET_CODE
**
**  Creation    :   REF10793 - DDV - 041130
**
**  Modif.      :   
**
*********************************************************************************************************/
STATIC RET_CODE FIN_ComputeIncomeQty(DBA_HIER_HEAD_STP hierHead,
                                     DBA_DYNFLD_STP    domainPtr, 
                                     DBA_DYNFLD_STP    stock, 
                                     DBA_DYNFLD_STP    instrPtr, 
                                     DBA_DYNFLD_STP    flowPtr,
                                     double            *qty)
{
    DATETIME_T          tmpDate;
    DBA_DYNFLD_STP      getArgSt=NULL, *posTabPrevDay=NULL, *posTab=NULL;                            
    int                 posNbr = 0, posNbrPrevDay = 0, notLockedPosNbr = 0, i;
    NUMBER_T            closedQty=0.0, newLockedQty=0.0, biggestQty=0.0;
    RET_CODE            ret=RET_SUCCEED;
    ID_T                instrId=(ID_T)0, biggestPosId=(ID_T)0;
    FLAG_T              generateFlow = FALSE;
    OPSTAT_ENUM         evtGenMinStatus;

	/* PMSTA07550 -.DDV - 090427 - Get the minimum operation status define in appl_param */
    GEN_GetApplInfo(ApplEvtGenMinStatus, &evtGenMinStatus);

    /* for locked positions, don't modifie quantity for income operation */
    if (FIN_IsLockedPos(stock) == TRUE)
    {
        *qty=GET_NUMBER(stock, ExtPos_Qty);
        return(ret);
    }
        
    if ((getArgSt = ALLOC_DYNST(Get_Arg)) == NULL)
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

    if (GET_ID(instrPtr, A_Instr_Id) > 0)
    {instrId = GET_ID(instrPtr, A_Instr_Id);}
    else
    {instrId = GET_ID(instrPtr, A_Instr_ParentInstrId);}

    SET_ID(getArgSt,      Get_Arg_InstrId, instrId);

    tmpDate.time = 0;
    tmpDate.date = DATE_Move(GET_DATE(flowPtr, Flow_OptimalDate), -1, Day);
    SET_DATETIME(getArgSt, Get_Arg_DateTime,      tmpDate);  
    SET_ID(getArgSt,       Get_Arg_PtfId,         GET_ID(stock, ExtPos_PtfId)); 
    SET_ID(getArgSt,       Get_Arg_PtfPosSetId,   GET_ID(domainPtr, A_Domain_PortPosSetId));
    SET_ENUM(getArgSt,     Get_Arg_Enum1,         GET_ENUM(domainPtr, A_Domain_MinStatEn));
    SET_ENUM(getArgSt,     Get_Arg_Enum2,         GET_ENUM(domainPtr, A_Domain_MaxStatEn));

    /* REF10793 - DDV - 041202 - use a new proc to load all positions (Primary, Derived and secondary) */
	if ((ret = DBA_Select2(Pos, DBA_ROLE_LOAD_SH_POS, Get_Arg, getArgSt, S_Pos, &posTabPrevDay,  
                           UNUSED, UNUSED, &posNbrPrevDay, UNUSED, UNUSED)) != RET_SUCCEED)
    {
        MSG_SendMesg(RET_DBA_ERR_NODATA, 3, FILEINFO, "FIN_GeneratePosition", 
                GET_CODE(instrPtr, A_Instr_Cd), "Positions");
        FREE_DYNST(getArgSt, Get_Arg);
		return(ret);
    }
    FREE_DYNST(getArgSt, Get_Arg);

    /* compute the sum of positions which are cloed at FlowOptimalDate (all locked and not locked) */ 
    for (i=0; i<posNbrPrevDay; i++)
    {
        if (DATETIME_CMP(GET_DATETIME(flowPtr, Flow_OptimalDate),
                         GET_DATETIME(posTabPrevDay[i], S_Pos_EndDate)) == 0)
        {
            closedQty+=GET_NUMBER(posTabPrevDay[i], S_Pos_Qty);
        }
    }

    /* free data */
    if(posNbrPrevDay > 0) { DBA_FreeDynStTab(posTabPrevDay,posNbrPrevDay,S_Pos); }

    /* compute the sum of positions locked and open at FlowOptimalDate */ 
	if ((ret = DBA_ExtractHierEltRec(hierHead, ExtPos, 
					                 FALSE, NULLFCT, FIN_CmpPosPtfInstr, 
					                 &posNbr, &posTab)) != RET_SUCCEED)
    {
       
        return(ret);
    }

    /* skip position from other portfolios */
    for (i=0; i<posNbr && 
              CMP_DYNFLD(stock, posTab[i], ExtPos_PtfId, ExtPos_PtfId, IdType) <0; i++);

    /* skip position from other instruments */
    for (/* no  init */; i<posNbr && 
                         CMP_DYNFLD(stock, posTab[i], ExtPos_PtfId, ExtPos_PtfId, IdType) == 0 &&
                         GET_ID(posTab[i], ExtPos_InstrId) < instrId; i++);

    for (/* no  init */; i<posNbr &&
                         CMP_DYNFLD(stock, posTab[i], ExtPos_PtfId, ExtPos_PtfId, IdType) == 0 &&
                         GET_ID(posTab[i], ExtPos_InstrId) == instrId; i++)
    {
        if (DATETIME_CMP(GET_DATETIME(posTab[i], ExtPos_BegDate),
                         GET_DATETIME(flowPtr, Flow_OptimalDate)) <= 0 &&
            DATETIME_CMP(GET_DATETIME(posTab[i], ExtPos_EndDate),
                         GET_DATETIME(flowPtr, Flow_OptimalDate)) > 0)
        {
    		switch (GET_DICT(domainPtr, A_Domain_FctDictId))
	    	{
		        case DictFct_Journal:
			        generateFlow = (FLAG_T) (IS_NULLFLD(posTab[i], ExtPos_BalPosTpId) == TRUE &&
			                                 GET_ENUM(posTab[i], ExtPos_NatEn) == ExtPosNat_FinalStock &&
	                                         ((IS_NULLFLD(posTab[i], ExtPos_EvtNbr) == TRUE &&
		                      	               IS_NULLFLD(posTab[i], ExtPos_EvtCd) == TRUE) ||
 		                     	              GET_ENUM(posTab[i], ExtPos_StatEn) >= evtGenMinStatus) && /* PMSTA07550 - DDV - 090427 - Check is based on new appl_param instead of accouting status */
         				                      GET_NUMBER(posTab[i], ExtPos_Qty) != 0.0);
    	    		break;
		        default:
        			generateFlow = (FLAG_T) (IS_NULLFLD(posTab[i], ExtPos_BalPosTpId) == TRUE &&
                                             GET_ENUM(posTab[i], ExtPos_StatEn) >= evtGenMinStatus && /* PMSTA07550 - DDV - 090427 - Check is based on new appl_param instead of accouting status */
		    	                             GET_ENUM(posTab[i], ExtPos_NatEn) == ExtPosNat_FinalStock &&
			    	                         GET_NUMBER(posTab[i], ExtPos_Qty) != 0.0);
    			    break;
	    	}

            if (generateFlow == TRUE)
            {
                if (FIN_IsLockedPos(posTab[i]) == TRUE)
                {
                    newLockedQty += GET_NUMBER(posTab[i], ExtPos_Qty);
                }
                else
                {
                    notLockedPosNbr++;
                    if (biggestQty == 0.0 || 
                        biggestQty < GET_NUMBER(posTab[i], ExtPos_Qty))
                    {
                        biggestQty = GET_NUMBER(posTab[i], ExtPos_Qty);
                        biggestPosId = GET_ID(posTab[i], ExtPos_PosObjId);
                    }
                    else if (biggestQty == GET_NUMBER(posTab[i], ExtPos_Qty) &&
                             biggestPosId < GET_ID(posTab[i], ExtPos_PosObjId))
                    {
                        biggestPosId = GET_ID(posTab[i], ExtPos_PosObjId);
                    }
                }
            }
        }
    }

    if (notLockedPosNbr <= 1 ||
        biggestPosId == GET_ID(stock, ExtPos_PosObjId))
    {
        *qty = closedQty - newLockedQty;
    }
    else
    {
        *qty=0.0;
    }

	return(ret);
}

/*****************************************************************************************************
**
**  Function    :   FIN_GeneratePosition
**
**  Description :   Generate new operation according to 
**                  received flow and stock position
**                 
**  Arguments   :   hierHead   hierarchy header pointer
**
**  Warning     :   Calling function is FIN_InstrFlows()
**
**  Return      :   RET_SUCCEED
**                  RET_MEM_ERR_ALLOC
**                  RET_GEN_ERR_INVARG
**
**  Modified    :   960506 XDI DVP063, many many modifications !!!
**
**  Modif.      :   RAK - 961023 - DVP229
**  Modif.      :   RAK - 970501 - DVP440
**		    DED - 970512 - DVP454 : Handling of Repo/Remere reference natures
**		    RAK - 971209 - REF358
**                  GRD - 980915 - REF2807: Added connection info when used inside a transaction.
**		    REF3178 - SSO - 990106
**		    REF3422 - AKO - 990312
**		    REF3740 - AKO - 990628 : Corporate actions
**		    REF3929 - SSO - 990909 : term open for artesia
**          REF3939 - CSY - 991104 : new parameter domain listPtr needed for FIN_CheckExistPos
**          REF4075 - CSY - 991208 : parameter A_Domain_EvtDateRuleEn passed to FIN_ComputeTheoPrice
**          REF3939 - CSY - 000105 : existPosFlg: output parameter of FIN_CheckExistPos
**	        REF4505 - AKO - 000331 : Create a supplementary extOp for prop. attribution
**	        REF3154 - SSO - 000403 : particular case for MM income+redemption
**          REF7054 - AKO - 011227 : Have Event geneation to generate income position...
**          REF7265 - YST - 020409/020702
**          REF7792 - YST - 030110 
**          REF9068 - TEB - 050318
**          REF11218 - TEB - 050627
**			REF9334 - TEB - 050809
**          PMSTA-17422 - 130114 - PMO : Using the accrual rule ACTACT for sinking funds, the quantities of the operations are wrong in Event Generation and Journal of Liquidities
**          PMSTA-18511 - 120814 - PMO : Incomes with 0 dividend amounts must be displayed in the Journal function
**          PMSTA-32116 - 200818 - PMO : [KD-1022A] WS - Structured Product - Instrument Financial Processing : Financial functions
**          PMSTA-34774 - 070319 - PMO : Journal of liquidity is calculating wrong price for Discount Certificate and Bonus note
**          PMSTA-35020 - 080319 - PMO : Dev Full Coverage - Journal - CPN's
**
*********************************************************************************************************/
STATIC RET_CODE FIN_GeneratePosition(DBA_HIER_HEAD_STP hierHead,
                                    ID_T              refCurrId,
                                    FUSDATERULE_ENUM  refFusDateRule,
                                    OPSTAT_ENUM       statusInput, 
                                    DBA_DYNFLD_STP    stock, 
                                    DBA_DYNFLD_STP    flowPtr,
                                    DICT_FCT_ENUM     fctDictId,
                                    DATETIME_T        fromDateTime,
                                    EVTPLRULE_ENUM    domainPlRule,
                                    DBA_HIER_HEAD_STP hierHeadValo,
                                    DBA_DYNFLD_STP    domainPtr,
                                    DBA_DYNFLD_STP    *extractFlowPos,	    /* REF1434 - REF1435 - DDV */
                                    int               extractFlowPosNbr,   /* REF1434 - REF1435 - DDV */
                                    DBA_DYNFLD_STP    *listPtr,            /* REF3939 - 991104 - CSY */
									DATETIME_T        currentTime)         /* PMSTA9969 - PRS - 101216 */
{
    RET_CODE            ret = RET_SUCCEED;
	NUMBER_T        qty, copyQty = ZERO_NUMBER;  /*PMSTA-32106 -NRAO 180904*/;
    PRICE_T		price = 0.0, quote = 0.0;
    NUMBER_T            baseValue, multiplier, cashAmt=0.0; /* REF4441 - AKO - 000329 */
    AMOUNT_T            tmpAmt=0.0;
    OBJECT_ENUM         objectOperation=NullEntity;
    ID_T                dfltTpId = 0;
    DBA_DYNFLD_STP      extOperation=NULL, operation=NULL,ptfPtr=NULL,
                        instrPtr=NULL, posInstrPtr = NULL, /* newInstr=NULL, - REF3913 - DDV - newIntsr no more used, if new instrument needed, 
	                                                                                   load it and store it in hierarchy. *//*PMSTA-18355 - SHR - 140807*/
			            getArgSt=NULL,lockingPos=NULL;                            
    int                 posNbr, posNbrToCreate; 
    long                i,j; 
    FLAG_T              *scptFlagTabExtOp, *scptFlagTabOp, dontCreateOp, 
                        getLockingPos = FALSE, found = FALSE,
						isPECapitalCall = FALSE, isPECapReturn = FALSE,
						isPECapToReceive = FALSE, isPECapReduc = FALSE, isPEFinalRedem = FALSE;  /*PMSTA-32106 -NRAO 180904*/;
    EVTPLRULE_ENUM      exchangePlRule, futuresSettlPlRule, 
                        optionExercisePlRule;
    /* DBA_ERRMSG_INFOS_ST msgStruct;*/
    FIN_PRICEARG_ST	priceArgSt;
    FIN_MKTVAL_ST       mktVal;
    DATE_PERIOD_ST      period;
    double              freq, posQty=0.0;
    RNDRULE_ENUM	    roundRule=RndRule_None;
    FLAG_T		        treatRefNatFlg = FALSE;			        /* REF3929 - SSO - 990909 */
    FLAG_T		        existPosFlg,				            /* REF3939 - CSY - 000105 */
			            toGenerateOpPropAttribCashFlg=FALSE;	/* REF4505 - AKO - 000331 */
    FLAG_T              fullCouponFlg = FALSE;
    ENUM_T		        propAttribRule=PropAttribRule_None;	    /* REF4505 - AKO - 000331 */
    FLAG_T		        mmIncRedemFlg = FALSE, anyFlow = FALSE;	/* REF3154 - SSO - 000403 */
    ENUM_T		        refNatEn;				                /* REF3154 - SSO - 000403 */ /* REF9789 - LJE - 031230 */
    FLAG_T              fusCashvalueDateflg=TRUE;               /* REF7054 - AKO - 011227 */
    POSFUSRULE_ENUM     fusMmktAmendValdateEn;                  /* REF7054 - AKO - 011227*/
	ID_T				instrId;								/*PMSTA-18355 - SHR - 140807*/ 
	ID_T				calendarId = 0;                         /*PMSTA-22396  - SRIDHARA ï¿½ 160430 */
    bool                bSTNComputation = false;                /* PMSTA-34774 - 070319 - PMO */

    memset(&priceArgSt, 0, sizeof(FIN_PRICEARG_ST));

    /* get instrument structure *//*PMSTA-18355 - SHR - 140807*/ 
    if (GET_EXTENSION_PTR(stock, ExtPos_A_Instr_Ext) != NULL)
    	posInstrPtr = instrPtr = *(GET_EXTENSION_PTR(stock, ExtPos_A_Instr_Ext));

    if (instrPtr == NULL)
    {
        return(RET_GEN_ERR_INVARG); 
    }

    /* DVP384 - XDI - 970314 - if FlowNat is Exchange and instrument nature is */
    /* Bond, CumBond or ConvertBond, don't generate position */
    /*if (GET_ENUM(flowPtr, Flow_NatEn) == FlowNat_Exch &&
	(GET_ENUM(instrPtr,  A_Instr_NatEn) == InstrNat_Bond ||
	GET_ENUM(instrPtr,  A_Instr_NatEn) == InstrNat_CumOption ||
	GET_ENUM(instrPtr,  A_Instr_NatEn) == InstrNat_ConvertBond))
	    return(RET_SUCCEED);*/

    /* DVP514 - XDI - 970919 */
    /* REF3025 - DDV - 981124 - Old code
    if ((DATETIME_CMP(GET_DATETIME(flowPtr, Flow_OptimalDate),
		      GET_DATETIME(stock, ExtPos_ValDate)) < 0 ) &&
         (GET_ENUM(instrPtr,  A_Instr_NatEn) == InstrNat_Bond ||
	  GET_ENUM(instrPtr,  A_Instr_NatEn) == InstrNat_CumOption ||
	  GET_ENUM(instrPtr,  A_Instr_NatEn) == InstrNat_ConvertBond))
	    return(RET_SUCCEED);
    */
    GEN_GetApplInfo(ApplFusionCashValueDateFlg, &fusCashvalueDateflg);
    GEN_GetApplInfo(ApplFusMmktAmendValueDateFlag, &fusMmktAmendValdateEn);
    /* --------------------------------------------------------------- */
    /* REF7054 - AKO - 011227 : take into account these new conditions */
    /* --------------------------------------------------------------- */
    if ((DATETIME_CMP(GET_DATETIME(flowPtr, Flow_OptimalDate),GET_DATETIME(stock, ExtPos_ValDate)) < 0 ) 
        &&
        (GET_ENUM(flowPtr, Flow_NatEn) == FlowNat_Inc)
        &&  
        (
            (GET_ENUM(instrPtr,  A_Instr_NatEn) == InstrNat_Bond) 
            ||
            (GET_ENUM(instrPtr,  A_Instr_NatEn) == InstrNat_CumOption) 
            ||
            (GET_ENUM(instrPtr,  A_Instr_NatEn) == InstrNat_ConvertBond) 
            ||
            ((GET_ENUM(instrPtr,  A_Instr_NatEn) == InstrNat_CashAcct) && (fusCashvalueDateflg == TRUE)) 
            || 
            ((GET_ENUM(instrPtr,  A_Instr_NatEn)==InstrNat_MoneyMkt) 
             && 
             (   ((PosFusRule_None == GET_ENUM(stock, ExtPos_FusRuleEn)) && (PosFusRule_None == fusMmktAmendValdateEn))
                 ||
                 ((PosFusRule_AIReset != GET_ENUM(stock, ExtPos_FusRuleEn)) && (PosFusRule_Amendment == fusMmktAmendValdateEn))
             ))))
    {
	    return(RET_SUCCEED);
    }

    /* REF3025 - DDV - 981124 - New code */
    /*  REF7054 - AKO - 011227 : below replaced by the one above

        if ((DATETIME_CMP(GET_DATETIME(flowPtr, Flow_OptimalDate),
		      GET_DATETIME(stock, ExtPos_ValDate)) < 0 ) &&
        GET_ENUM(flowPtr, Flow_NatEn) == FlowNat_Inc)
	    return(RET_SUCCEED);
    */

    /* REF1225 - 980203 - XDI - don't pay coupon for a buy operation when value is coupon date */
    /* REF4973 - SSO - 001002 : do this only if a unique buy (i.e. F. Stock not fusioned) */
    if(GET_ENUM(flowPtr, Flow_NatEn) == FlowNat_Inc &&
       GET_ENUM(stock, ExtPos_OpenOpNatEn) == OpNat_Buy &&
   	   GET_ENUM(stock, ExtPos_PosNatEn) != PosNat_None &&	/* added by REF4977 - SSO - 010111  */
       DATETIME_CMP(GET_DATETIME(flowPtr, Flow_OptimalDate),
                      GET_DATETIME(stock, ExtPos_ValDate)) == 0 &&
       (INSTRNAT_ENUM)GET_ENUM(instrPtr, A_Instr_NatEn) != InstrNat_Stock) /* REF8889 - YST - 030514 */
    {
	    return(RET_SUCCEED);
    }

    /* REF3154 - SSO - 000403 */
    if (GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_MoneyMkt)
    { 
	    anyFlow = (FLAG_T) GET_BIT64(GET_MASK64(domainPtr, A_Domain_EvtFlowSubNatLst), FlowSubNat_Any);
	    if ((anyFlow == TRUE) || 
	        (anyFlow == FALSE && GET_BIT64(GET_MASK64(domainPtr, A_Domain_EvtFlowSubNatLst), FlowSubNat_FxdRate) == TRUE) 
			         && GET_BIT64(GET_MASK64(domainPtr, A_Domain_EvtFlowSubNatLst), FlowSubNat_FinalRedm))
	    {
	        mmIncRedemFlg = TRUE;
	    }
    }

    GEN_GetApplInfo(ApplExchangePlRule, &exchangePlRule);
    GEN_GetApplInfo(ApplPropAttribRule, &propAttribRule);
    switch (domainPlRule)
    {
        case EvtPlRule_Default:
            if (exchangePlRule == EvtPlRule_ForcedInstrument) /* REF848 - DDV - 980317 */
                exchangePlRule = EvtPlRule_Instrument; 
            else if (exchangePlRule == EvtPlRule_ForcedUnderlying) /* REF848 - DDV - 980317 */
                exchangePlRule = EvtPlRule_Underlying; 

            GEN_GetApplInfo(ApplFuturesSettlPlRule, &futuresSettlPlRule);
            GEN_GetApplInfo(ApplOptionExercisePlRule, &optionExercisePlRule);
            break;

        case EvtPlRule_Instrument:
            if (exchangePlRule == EvtPlRule_ForcedUnderlying) /* REF848 - DDV - 980317 */
                exchangePlRule = EvtPlRule_Underlying; 
            else
                exchangePlRule = EvtPlRule_Instrument;

            futuresSettlPlRule = EvtPlRule_Instrument;
            optionExercisePlRule = EvtPlRule_Instrument;
            break;

        case EvtPlRule_Underlying:
	default :
            if (exchangePlRule == EvtPlRule_ForcedInstrument) /* REF848 - DDV - 980317 */
                exchangePlRule = EvtPlRule_Instrument; 
            else
                exchangePlRule = EvtPlRule_Underlying;

            futuresSettlPlRule = EvtPlRule_Underlying;
            optionExercisePlRule = EvtPlRule_Underlying;
            break;
    }

    posNbrToCreate = 1;
    for (posNbr = 1; posNbr <= posNbrToCreate; posNbr++)
    {	        
        /* get instrument structure */
        if (GET_EXTENSION_PTR(stock, ExtPos_A_Instr_Ext) != NULL)
            instrPtr = *(GET_EXTENSION_PTR(stock, ExtPos_A_Instr_Ext));

        if (GET_EXTENSION_PTR(stock, ExtPos_A_Ptf_Ext) != NULL)
        	ptfPtr = *(GET_EXTENSION_PTR(stock, ExtPos_A_Ptf_Ext));

        /* REFNON - DDV - 980428 - If event generation and extpos on
           unloaded portfolio (Ptf Transfert Operation) do nothing */
        if (ptfPtr == NULL &&
            fctDictId == DictFct_EventGeneration)
            return(RET_GEN_ERR_INVARG);
        
        if ((extOperation = ALLOC_DYNST(ExtOp)) == NULL)
        {
            MSG_RETURN(RET_MEM_ERR_ALLOC); 
        }

	    DBA_SetDfltEntityFld(EOp, ExtOp, extOperation);
        
        SET_DATETIME(extOperation, ExtOp_AcctDate, GET_DATETIME(flowPtr ,Flow_OptimalDate));
        SET_DATETIME(extOperation, ExtOp_OpDate, GET_DATETIME(flowPtr ,Flow_OptimalDate));
		/*SET_DATETIME(extOperation, ExtOp_ValueDate, GET_DATETIME(flowPtr, Flow_OptimalValDate)); REF1193 - DDV - 980324 */
        
		/* PMSTA - 48783 - ankita - 17052022 */
		AppEvtGenOnDivPayDate appEvtGenOnDivPayDate = AppEvtGenOnDivPayDate::addBeginDate;

		GEN_GetApplInfo(AppEvtGenOnDivPayDateEnum, &appEvtGenOnDivPayDate);

		if (GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_Stock && appEvtGenOnDivPayDate == AppEvtGenOnDivPayDate::addFirstCouponDate)
		{
			SET_DATETIME(extOperation, ExtOp_ValueDate, GET_DATETIME(flowPtr, Flow_OptimalDate));
		}

		/* PMSTA9969 - PRS - 101216: set last modified time */
        SET_DATETIME(extOperation, ExtOp_CreationTime, currentTime);
       
	    /* REF1139 - XDI - 980209 */ 
        COPY_DYNFLD(extOperation, ExtOp, ExtOp_InitExtPosId, stock,   ExtPos, ExtPos_Id);
        COPY_DYNFLD(extOperation, ExtOp, ExtOp_PtfId,        stock,   ExtPos, ExtPos_PtfId);
        COPY_DYNFLD(extOperation, ExtOp, ExtOp_DepoId,       stock,   ExtPos, ExtPos_DepoId);
        COPY_DYNFLD(extOperation, ExtOp, ExtOp_InstrCurrId,  stock ,  ExtPos, ExtPos_InstrCurrId); 
        COPY_DYNFLD(extOperation, ExtOp, ExtOp_FlowId,       flowPtr, Flow,   Flow_Id);

	    /* BUG088 - 960808 - XDI - Old Code */
        /*COPY_DYNFLD(extOperation, ExtOp, ExtOp_PtfCurrId, ptfPtr , A_Ptf, A_Ptf_CurrId); */

	    /* BUG088 - 960808 - XDI - New Code Begin */
        if (fctDictId == DictFct_Journal)
        {
        	COPY_DYNFLD(extOperation, ExtOp, ExtOp_PtfCurrId, stock , ExtPos, ExtPos_RefCurrId);
	    }
	    else /* EventGeneration */
        {
        	COPY_DYNFLD(extOperation, ExtOp, ExtOp_PtfCurrId, ptfPtr , A_Ptf, A_Ptf_CurrId); 
	    }
	    /* BUG088 - 960808 - XDI - New Code End */

        SET_ENUM(extOperation, ExtOp_StatusEn, statusInput);
        
        SET_CODE(extOperation, ExtOp_EvtCd, GET_CODE(flowPtr, Flow_EvtCd));
        SET_NUMBER(extOperation,  ExtOp_EvtNbr, (NUMBER_T)GET_INT(flowPtr, Flow_EvtNbr)); /* REF8844 - LJE - 030327 */
        
        SET_NULL_PRICE(extOperation, ExtOp_SpotPrice);
        
        if (GET_ID(flowPtr, Flow_InstrId) < 0)
        {
            COPY_DYNFLD(extOperation, ExtOp, ExtOp_InstrId, instrPtr,  A_Instr, A_Instr_ParentInstrId);
        }
        else
        {
            COPY_DYNFLD(extOperation, ExtOp, ExtOp_InstrId, flowPtr,  Flow, Flow_InstrId);
        }

	    /* ----------------------------------------------------- */ /* REF4108 - AKO - 991216 */
	    /* forcer le ExtOp_Price ï¿½ 1.0 et ne plus le modifier si */
	    /* instr=CashAccount et Flow=Income			 */
	    /* ----------------------------------------------------- */
	    if ( (GET_ENUM(flowPtr, Flow_NatEn)==FlowNat_Inc) &&	    
	         (GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_CashAcct))
	    {
	        SET_PRICE(extOperation, ExtOp_Price, 1.0);
	    }
        SET_ENUM(extOperation, ExtOp_PriceCalcRuleEn, GET_ENUM(stock ,ExtPos_PriceCalcRuleEn));
        COPY_DYNFLD(extOperation, ExtOp, ExtOp_Quote, flowPtr, Flow, Flow_Quote);
	    /* REF3422 - AKO - 990312 */
	    if ((fctDictId == DictFct_EventGeneration) && (InstrNat_ForexSwaps==GET_ENUM(instrPtr,  A_Instr_NatEn)))
		    {COPY_DYNFLD(extOperation, ExtOp, ExtOp_OpCurrId, stock, ExtPos, ExtPos_PosCurrId);}
	    else
		    {COPY_DYNFLD(extOperation, ExtOp, ExtOp_OpCurrId, flowPtr , Flow, Flow_AmtCurrId);}

        /* Load and initialise flag array for script */
        if ((scptFlagTabExtOp = (FLAG_T *) CALLOC(GET_FLD_NBR(ExtOp),sizeof(FLAG_T))) == NULL) /* REF7264 - DDV - 020326 - Compil C++ */
        {
            FREE_DYNST(extOperation, ExtOp);
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }
        
        for (i=0; i<GET_FLD_NBR(ExtOp) ;i++)
            scptFlagTabExtOp[i]=FALSE;
        
        /* if (fctDictId == DictFct_Journal) deleted 980402 - DDV */ /* Delete line after DED modification of insertion */
        scptFlagTabExtOp[ExtOp_Cd]=TRUE; 
        scptFlagTabExtOp[ExtOp_TpId]=TRUE;
        scptFlagTabExtOp[ExtOp_AcctDate]=TRUE;
        scptFlagTabExtOp[ExtOp_OpDate]=TRUE;
        /*scptFlagTabExtOp[ExtOp_ValueDate]=TRUE; REF1193 -DDV - 980324 */
        scptFlagTabExtOp[ExtOp_StatusEn]=TRUE;
        scptFlagTabExtOp[ExtOp_PtfId]=TRUE;
        scptFlagTabExtOp[ExtOp_InstrId]=TRUE;
        scptFlagTabExtOp[ExtOp_DepoId]=TRUE;
        scptFlagTabExtOp[ExtOp_OpCurrId]=TRUE;
        scptFlagTabExtOp[ExtOp_InstrCurrId]=TRUE;
        scptFlagTabExtOp[ExtOp_PtfCurrId]=TRUE;
        scptFlagTabExtOp[ExtOp_EvtCd]=TRUE;
        scptFlagTabExtOp[ExtOp_EvtNbr]=TRUE;
        scptFlagTabExtOp[ExtOp_Qty]=TRUE;
        scptFlagTabExtOp[ExtOp_SpotPrice]=TRUE;
	    /* ----------------------------------------------------- */ /* REF4108 - AKO - 991216 */
	    /* forcer le ExtOp_Price ï¿½ 1.0 et ne plus le modifier si */
	    /* instr=CashAccount et Flow=Income			 */
	    /* ----------------------------------------------------- */
	    if ( (GET_ENUM(flowPtr, Flow_NatEn)==FlowNat_Inc) &&
	        (GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_CashAcct))
	    {
        	scptFlagTabExtOp[ExtOp_Price]=TRUE; 
	    }
        scptFlagTabExtOp[ExtOp_Quote]=TRUE; 
        scptFlagTabExtOp[ExtOp_FlowId]=TRUE;
        
        dontCreateOp = FALSE;

        switch (GET_ENUM(flowPtr, Flow_NatEn))
        {
        case FlowNat_Inc :
            objectOperation = IncOpEnt;

            SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Income);
            GEN_GetApplInfo(ApplIncOpTpId, &dfltTpId);

            /* general case: get quantity from today */
            posQty = GET_NUMBER(stock, ExtPos_Qty); 

            /* REF7266 - YST - 020702/021016 - special case: for bond type instruments */
            if (GET_ENUM(instrPtr,  A_Instr_NatEn) == InstrNat_Bond ||
                GET_ENUM(instrPtr,  A_Instr_NatEn) == InstrNat_CumOption ||
                GET_ENUM(instrPtr,  A_Instr_NatEn) == InstrNat_ConvertBond)
            {
                DBA_DYNFLD_STP      *selPosTab=NULL;
                FLAG_T              bondIncomePosFlg = FALSE;
                int                 selPosNbr = 0, selPosIdx = 0;

                GEN_GetApplInfo(FullCouponFlag, &fullCouponFlg);
                GEN_GetApplInfo(ApplBondIncomePosFlag, &bondIncomePosFlg);

                /* REF7266 - YST - 020702/021016 - get quantity from previous day */
                if (fullCouponFlg == FALSE &&
                    DATETIME_CMP(GET_DATETIME(flowPtr, Flow_OptimalDate),
                                 GET_DATETIME(stock, ExtPos_BegDate /*ExtPos_ValDate*/)) == 0)
                {
                    /* REF10793 - DDV - 041130 - New code to compute qty of income */
					FIN_ComputeIncomeQty(hierHead, domainPtr, stock, instrPtr, flowPtr, &posQty);
                }

                /* REF7792 - YST - 030110 - add quantities from sell operations */
                if (bondIncomePosFlg == TRUE)            
                {
                    selPosNbr = 0;

                    if ((getArgSt = ALLOC_DYNST(Get_Arg)) == NULL)
                    {
		                FREE_DYNST(extOperation, ExtOp);
                        FREE(scptFlagTabExtOp);
                        MSG_RETURN(RET_MEM_ERR_ALLOC);
	                }

                    if (GET_ID(instrPtr, A_Instr_Id) > 0)
                    {SET_ID(getArgSt,      Get_Arg_InstrId,     GET_ID(instrPtr, A_Instr_Id));}
                    else
                    {SET_ID(getArgSt,      Get_Arg_InstrId,     GET_ID(instrPtr, A_Instr_ParentInstrId));}
              
                    SET_ID(getArgSt,       Get_Arg_PtfId,       GET_ID(stock, ExtPos_PtfId)); 
                    SET_DATETIME(getArgSt, Get_Arg_DateTime,    GET_DATETIME(flowPtr, Flow_OptimalDate));
                  
                    SET_ENUM(getArgSt, Get_Arg_Enum1,       GET_ENUM(domainPtr, A_Domain_MinStatEn));
                    SET_ENUM(getArgSt, Get_Arg_Enum2,       GET_ENUM(domainPtr, A_Domain_MaxStatEn));
                    
                    /* Select positions */
			        if ((ret = DBA_Select2(Pos, UNUSED, Get_Arg, getArgSt, A_Pos, &selPosTab,  
	                                  UNUSED, UNUSED, &selPosNbr, UNUSED, UNUSED)) != RET_SUCCEED)
                    {
                        MSG_SendMesg(RET_DBA_ERR_NODATA, 3, FILEINFO, "FIN_GeneratePosition", 
                                GET_CODE(instrPtr, A_Instr_Cd), "Positions");
		                FREE_DYNST(extOperation, ExtOp);
                        FREE(scptFlagTabExtOp);
                        FREE_DYNST(getArgSt, Get_Arg);
		                return(ret);
                    }
                    FREE_DYNST(getArgSt, Get_Arg);

                    for (selPosIdx=0; selPosIdx<selPosNbr; selPosIdx++)
                    {
                        /* REF7792 - YST - 030120 - add condition */
                        if (!((fullCouponFlg == TRUE && 
                            DATETIME_CMP(GET_DATETIME(selPosTab[selPosIdx], A_Pos_ValDate),
                                         GET_DATETIME(flowPtr, Flow_OptimalDate)) == 0)
                                         ||
                            (fullCouponFlg == FALSE && 
                            DATETIME_CMP(GET_DATETIME(selPosTab[selPosIdx], A_Pos_BegDate),
                                         GET_DATETIME(flowPtr, Flow_OptimalDate)) == 0) 
                                         ||
                            DATETIME_CMP(GET_DATETIME(domainPtr, A_Domain_CalcRefDate),
                                         GET_DATETIME(selPosTab[selPosIdx], A_Pos_BegDate)) < 0))
                        {
                            posQty -= GET_NUMBER(selPosTab[selPosIdx], A_Pos_Qty);
                        }
                    }
                    DBA_FreeDynStTab(selPosTab, selPosNbr, A_Pos);
                }

            }

            /* Ref quantiy sign analysed in ext pos generation */
            /* PMSTA-17422 - 130114 - PMO */
            if ((INSTRNAT_ENUM)  GET_ENUM(instrPtr, A_Instr_NatEn)      == InstrNat_Bond                  &&
	            (FLOWNAT_ENUM)   GET_ENUM(flowPtr,  Flow_NatEn)         == FlowNat_Inc                    &&
				(FLOWSUBNAT_ENUM)GET_ENUM(flowPtr,  Flow_SubNatEn)      == FlowSubNat_AmortisationFxdRate  )
            { /* Quantity is computed by the proportion of the redemption */
                qty = posQty * ((100. - GET_PERCENT(flowPtr, Flow_IoRPrct)) * 0.01);
            }
            else
            {
                if (GET_NUMBER(flowPtr, Flow_RefQty) == 0.0)
                {
                    qty = posQty * (GET_PERCENT(flowPtr, Flow_Proba) / 100.0);
                }
                else
                {
	                /* REF358 - RAK - 971209 */
	                /* Flow_RefQty is like 0.8 so multiply ExtPos_Qty by Flow_RefQty */
                    qty = posQty * GET_NUMBER(flowPtr, Flow_RefQty) *
                          (GET_PERCENT(flowPtr, Flow_Proba) / 100.0);
                }
            }

            SET_NUMBER(extOperation, ExtOp_Qty, CAST_NUMBER(qty)); /* REF3288 - SSO - 990205 */
            /* REF7266 - YST - 020702 - remove code of REF4977 */
            /* REF4977 - DDV - 010111 - Remove quantity computation, moved to default value */
            /* scptFlagTabExtOp[ExtOp_Qty]=FALSE; */

		    /* REF3154 - SSO - 000403 : mmkt income: ref forced to none */
		    refNatEn = GET_ENUM(stock, ExtPos_RefNatEn);
		    if ( (mmIncRedemFlg == TRUE) &&
		         (refNatEn == PosRefNat_Open || refNatEn == PosRefNat_RepoOpen|| refNatEn == PosRefNat_RemereOpen) )
		    {
		        SET_ENUM(extOperation, ExtOp_RefNatEn, PosRefNat_None);
                /* REF7511 - YST - 020426 - mmkt income: copy stock open operation code to extOperation */
		        COPY_DYNFLD(extOperation, ExtOp, ExtOp_RefOpCd, 
						    stock, ExtPos, ExtPos_OpenOpCd);
		        scptFlagTabExtOp[ExtOp_RefNatEn]=TRUE;
		        scptFlagTabExtOp[ExtOp_RefOpCd]=TRUE;
		    }
		    else
		    {
		        /* REF1714 - DDV - 980421 */
		        switch(refNatEn)
		        {
			        case PosRefNat_Open :
				        SET_ENUM(extOperation, ExtOp_RefNatEn, PosRefNat_Open);
				        COPY_DYNFLD(extOperation, ExtOp, ExtOp_RefOpCd, 
						    stock, ExtPos, ExtPos_OpenOpCd);
				        scptFlagTabExtOp[ExtOp_RefNatEn]=TRUE;
				        scptFlagTabExtOp[ExtOp_RefOpCd]=TRUE;
				        break;
			        case PosRefNat_RepoOpen :
				        SET_ENUM(extOperation, ExtOp_RefNatEn, PosRefNat_RepoOpen);
				        COPY_DYNFLD(extOperation, ExtOp, ExtOp_RefOpCd, 
						    stock, ExtPos, ExtPos_OpenOpCd);
				        scptFlagTabExtOp[ExtOp_RefNatEn]=TRUE;
				        scptFlagTabExtOp[ExtOp_RefOpCd]=TRUE;
				        break;
			        case PosRefNat_RemereOpen :
				        SET_ENUM(extOperation, ExtOp_RefNatEn, PosRefNat_RemereOpen);
				        COPY_DYNFLD(extOperation, ExtOp, ExtOp_RefOpCd, 
						    stock, ExtPos, ExtPos_OpenOpCd);
				        scptFlagTabExtOp[ExtOp_RefNatEn]=TRUE;
				        scptFlagTabExtOp[ExtOp_RefOpCd]=TRUE;
				        break;
		        }
		    }

		    /* BUG170 - XDI - 961008 */
            /* REF673 - XDI - 971017 */
            if (GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_MoneyMkt)
            {
                if (GET_NUMBER(stock, ExtPos_Qty) != 0)
                {
                    price = GET_PRICE(flowPtr, Flow_AmtUnit); /*+
                            (GET_AMOUNT(stock, ExtPos_AccrAmt) /
                             GET_NUMBER(stock, ExtPos_Qty)); REF899 - XDI - 971117 */
                }
                else
                    price = 0.0;

                SET_PRICE(extOperation, ExtOp_Price, price);

                /* REF2185 - DDV - 980529 */
                /* SET_PRICE(extOperation, ExtOp_Quote, 100.0*price); */ 
                FIN_PriceToQuote((PRICECALCRULE_ENUM) GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn), /* REF7264 - DDV - 020326 - Compil C++ */
                                 GET_ID(instrPtr, A_Instr_Id), 
                                 instrPtr,
                                 fromDateTime, 
                                 NULL, 
                                 price, 
                                 &quote,
                                 hierHead);
                SET_PRICE(extOperation, ExtOp_Quote, quote);

                tmpAmt = /* GET_AMOUNT(stock, ExtPos_AccrAmt) + REF899 - XDI - 971117 */
                         (GET_PRICE(flowPtr, Flow_AmtUnit) *
                          GET_NUMBER(stock, ExtPos_Qty));
                SET_AMOUNT(extOperation, ExtOp_OpGrossAmt, tmpAmt);
                scptFlagTabExtOp[ExtOp_OpGrossAmt]=FALSE; /* PMSTA-18128 - SHR - 140514 ï¿½ Let DV update this amount */
            }
            else if (GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_CashAcct) /* REF784 - DDV - 980317 */
            {
                    /* If first income, add accr amount of position and interest until next income */
		        if (DATETIME_CMP(GET_DATETIME(flowPtr, Flow_BegPayDate),
                                     GET_DATETIME(stock, ExtPos_ValDate)) <= 0)
                {
                    FIN_AIARG_ST      accrInterArg;

			        accrInterArg.scptAIStp = NULL;
                    accrInterArg.fullCoupFlg = GET_FLAG(domainPtr, A_Domain_DebtFullCouponFlg);
                    accrInterArg.fusDateRule = (FUSDATERULE_ENUM) GET_ENUM(domainPtr, A_Domain_FusDateRuleEn); /* REF7264 - DDV - 020326 - Compil C++ */
                    accrInterArg.calcAccrInterFlg = FALSE;
                    accrInterArg.txdInterFlg = FALSE;
                    accrInterArg.accrInterMethod = AccrInterMethod_Default;    /* REF7265 - YST - 020409 */
                    accrInterArg.accrValFromDate.date = 0;                     /* REF7265 - YST - 020409 */
                    accrInterArg.accrValFromDate.time = 0;                     /* REF7265 - YST - 020409 */
					accrInterArg.accrRule             = AccrRule_None;         /* REF11218 - TEB - 050627 */
                    accrInterArg.useDefinedDateFlg    = FALSE;                 /* PMSTA08308 - 090609 - PMO */

                    /* call AccrInter to compute income value */
                    ret = FIN_AccrInter(GET_DATETIME(flowPtr, Flow_EndPayDate),
                                        GET_ID(instrPtr, A_Instr_Id), instrPtr,
                                        GET_ID(extOperation, ExtOp_OpCurrId),
                                        &accrInterArg,
                                        GET_NUMBER(stock, ExtPos_Qty),
                                        stock, &mktVal, hierHead);

                    if (ret  != RET_SUCCEED)
                    {
                        SET_NUMBER(extOperation, ExtOp_Qty, 0);
                    }
                    else 
                    {
                        SET_NUMBER(extOperation, ExtOp_Qty, mktVal.accrInterRefCurr);
                    }
                }
                else /* compute interest for period */
                {
                    /* Obtain days number in year and days between from and till date */
                    FIN_PeriodUnitNbr((FREQUNIT_ENUM) GET_ENUM(flowPtr, Flow_FreqUnitEn), /* REF7264 - DDV - 020326 - Compil C++ */
                                      GET_TINYINT(flowPtr, Flow_Freq),
                                      FreqUnit_Month, &freq);
					/* PMSTA-22396  - SRIDHARA ï¿½ 160430 */
					DBA_GetCalendarFromInstr(instrPtr, &calendarId);
                    DATE_AccrPeriod(GET_DATETIME(flowPtr, Flow_BegPayDate).date, 
                                    GET_DATETIME(flowPtr, Flow_EndPayDate).date, 
                                    (ACCRRULE_ENUM) GET_ENUM(instrPtr, A_Instr_AccrualRuleEn), /* REF7264 - DDV - 020326 - Compil C++ */
                                    (PERIOD_T) freq, &period, calendarId);
                    qty = GET_NUMBER(stock, ExtPos_Qty) * 
                          GET_PRICE(flowPtr, Flow_AmtUnit)/100.0 *
                          period.num / period.denom;
                    SET_NUMBER(extOperation, ExtOp_Qty, CAST_NUMBER(qty)); /* REF3288 - SSO - 990205 */

                }
            }
			else if (GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_FundShare  &&
					(GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_MoneyMarketFundShare ||
					 GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_FixedIncomeFundShare))
			{
				/************************************************************
				 **  PMSTA01512 - CHU - 070504 : Event Gen for FundShares  **
				 ************************************************************/

                FIN_AIARG_ST	accrInterArg;
				DBA_DYNFLD_STP	posCopy = NULL;

			    accrInterArg.scptAIStp				= NULL;
                accrInterArg.fullCoupFlg			= GET_FLAG(domainPtr, A_Domain_DebtFullCouponFlg);
                accrInterArg.fusDateRule			= (FUSDATERULE_ENUM) GET_ENUM(domainPtr, A_Domain_FusDateRuleEn); /* REF7264 - DDV - 020326 - Compil C++ */
                accrInterArg.calcAccrInterFlg		= FALSE;
                accrInterArg.txdInterFlg			= FALSE;
                accrInterArg.accrInterMethod		= AccrInterMethod_Default; /* REF7265 - YST - 020409 */
                accrInterArg.accrValFromDate.date	= 0;                       /* REF7265 - YST - 020409 */
                accrInterArg.accrValFromDate.time	= 0;                       /* REF7265 - YST - 020409 */
				accrInterArg.accrRule				= AccrRule_None;           /* REF11218 - TEB - 050627 */
                accrInterArg.useDefinedDateFlg      = FALSE;                   /* PMSTA08308 - 090609 - PMO */

                /* If first income, add accr amount of position and interest until next income */
		        if (DATETIME_CMP(GET_DATETIME(flowPtr, Flow_BegPayDate),
                                     GET_DATETIME(stock, ExtPos_ValDate)) <= 0)
                {
                    /* call AccrInter to compute income value */
                    ret = FIN_AccrInter(GET_DATETIME(flowPtr, Flow_EndPayDate),
                                        GET_ID(instrPtr, A_Instr_Id), instrPtr,
                                        GET_ID(extOperation, ExtOp_OpCurrId),
                                        &accrInterArg,
                                        GET_NUMBER(stock, ExtPos_Qty),
                                        stock, &mktVal, hierHead);

                    if (ret != RET_SUCCEED || CMP_NUMBER(mktVal.accrInterRefCurr, 0.0) == 0)
                    {
                        SET_NUMBER(extOperation, ExtOp_Qty, 0);
                    }
                    else 
                    {
                        SET_NUMBER(extOperation, ExtOp_Qty, 1.0);
						SET_PRICE(extOperation, ExtOp_Price, mktVal.accrInterRefCurr);
                    }
				}
                else /* compute interest for period */
                {
					if ((posCopy = ALLOC_DYNST(ExtPos)) == NULL)
					{
						FREE_DYNST(extOperation, ExtOp);
						FREE(scptFlagTabExtOp);
						MSG_RETURN(RET_MEM_ERR_ALLOC);
					}
					COPY_DYNST(posCopy, stock, ExtPos);
					COPY_DYNFLD(posCopy, ExtPos, ExtPos_BegDate, flowPtr, Flow, Flow_BegPayDate);

                    ret = FIN_AccrInter(GET_DATETIME(flowPtr, Flow_EndPayDate),
                                        GET_ID(instrPtr, A_Instr_Id), instrPtr,
                                        GET_ID(extOperation, ExtOp_OpCurrId),
                                        &accrInterArg,
                                        GET_NUMBER(stock, ExtPos_Qty),
                                        posCopy, &mktVal, hierHead);

                    if (ret != RET_SUCCEED || CMP_NUMBER(mktVal.accrInterRefCurr, 0.0) == 0)
                    {
                        SET_NUMBER(extOperation, ExtOp_Qty, 0);
                    }
                    else 
                    {
                        SET_NUMBER(extOperation, ExtOp_Qty, 1.0);
						SET_PRICE(extOperation, ExtOp_Price, mktVal.accrInterRefCurr);
                    }

					FREE_DYNST(posCopy, ExtPos);
                }
			}
            else
            {
                SET_PRICE(extOperation, ExtOp_Price, GET_PRICE(flowPtr, Flow_AmtUnit));
            }

            if (GET_NUMBER(instrPtr, A_Instr_ContractSize)  != 0)
            {
                qty = GET_NUMBER(extOperation, ExtOp_Qty) / GET_NUMBER(instrPtr, A_Instr_ContractSize);
                SET_NUMBER(extOperation, ExtOp_Qty, CAST_NUMBER(qty)); /* REF3288 - SSO - 990205 */
            }
            break;

        case FlowNat_Debt :
            /* Ref quantiy sign analysed in ext pos generation */
            if (GET_NUMBER(flowPtr, Flow_RefQty) == 0.0)
            {
                qty = GET_NUMBER(stock, ExtPos_Qty) * (GET_PERCENT(flowPtr, Flow_Proba) / 100.0);
            }
            else
            {
                qty = GET_NUMBER(stock, ExtPos_Qty) / GET_NUMBER(flowPtr, Flow_RefQty) *
                      (GET_PERCENT(flowPtr, Flow_Proba) / 100.0);
            }

            SET_NUMBER(extOperation, ExtOp_Qty, CAST_NUMBER(qty)); /* REF3288 - SSO - 990205 */
    
            switch (GET_ENUM(instrPtr, A_Instr_ValRuleEn))
            {
 		    case ValRule_Script:
                /* the quantity is the result of fund valuation */
                if (hierHeadValo == NULL)
                {
                    FREE_DYNST(extOperation, ExtOp);
                    FREE(scptFlagTabExtOp);
                    MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "Valo Hierarchy");
                    return(RET_DBA_ERR_NODATA);
                }                

                FIN_GetValoResult(hierHeadValo, GET_ID(stock, ExtPos_PosObjId), &qty);
                qty = CAST_AMOUNT(qty, GET_ID(extOperation, ExtOp_OpCurrId)); /* BUG182 - XDI - 961016 */
		        SET_NUMBER(extOperation, ExtOp_Qty, qty);
                break;
 		    case ValRule_SimpleScript: /* REF2338 - DDV - 981029 */
                baseValue = 1.0;
                multiplier = 1.0;
                /* the quantity is the result of script definition */
                FIN_ComputeDebtSimpleScriptPos(domainPtr,
                                               hierHead,
                                               stock,
                                               &baseValue,
                                               &multiplier);

                qty = baseValue * multiplier * GET_NUMBER(stock, ExtPos_Qty)*
			    GET_PERCENT(flowPtr,  Flow_IoRPrct)/100;  /* 990106 - DDV - Add division */
                qty = CAST_AMOUNT(qty, GET_ID(extOperation, ExtOp_OpCurrId)); 
		        SET_NUMBER(extOperation, ExtOp_Qty, qty);
                break;
            }

		    /* REF2435 - DDV - 980703 */
		    switch(GET_ENUM(flowPtr, Flow_SubNatEn))
		    {
            case FlowSubNat_ProviPlan:
                objectOperation = IncOpEnt;
                SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Income);
                /* GEN_GetApplInfo(ApplIncOpTpId, &dfltTpId); REF6109 - DDV - 011130 */
			    break;

            case FlowSubNat_FinalRedm:
            case FlowSubNat_DebtAmort:
                /* REF2435 - DDV - 980831 */
                COPY_DYNFLD(extOperation, ExtOp, ExtOp_Price,
                            flowPtr , Flow, Flow_AmtUnit);
                if (GET_NUMBER(stock, ExtPos_Qty) >= 0)
                {
                    objectOperation = SellOpEnt;
                    SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);
                }
                else
                {
                    objectOperation = BuyOpEnt;
                    SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);
                    SET_NUMBER(extOperation, ExtOp_Qty, GET_NUMBER(extOperation, ExtOp_Qty)*(-1));
                }
                break;

            case FlowSubNat_FullyPaidIss:
            case FlowSubNat_PartialPaidIss:
            case FlowSubNat_CallRedm:
            case FlowSubNat_PutRedm:
            case FlowSubNat_SinkingRedm:
            case FlowSubNat_CapReduc:
                if (GET_NUMBER(stock, ExtPos_Qty) >= 0)
                {
                    objectOperation = SellOpEnt;
                    SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);
                }
                else
                {
                    objectOperation = BuyOpEnt;
                    SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);
                    SET_NUMBER(extOperation, ExtOp_Qty, GET_NUMBER(extOperation, ExtOp_Qty)*(-1));
                }
			    break;
		    }

            break;

        case FlowNat_Iss :
            GEN_GetApplInfo(ApplIssueOpTpId, &dfltTpId);     

			/*PMSTA-32106 -NRAO-180904*/
			if ((DBA_IsPEFundShare(instrPtr, SubNat_PECapitalCall) == TRUE) &&
				(FLOWSUBNAT_ENUM)GET_ENUM(flowPtr, Flow_SubNatEn) == FlowSubNat_FullyPaidIss &&
				(CMP_ID(GET_ID(instrPtr, A_Instr_Id), GET_ID(flowPtr, Flow_InstrId)) == 0))
			{
				/*Special case for PE-FundShares - Unit Allocation*/
				if (posNbr == 1)
				{
					posNbrToCreate = 2;
					objectOperation = WithdrOpEnt;
					SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Withdr);
					scptFlagTabExtOp[ExtOp_Quote] = FALSE;
					scptFlagTabExtOp[ExtOp_Price] = FALSE;
				}
				else
				{
					DBA_DYNFLD_STP linkedInstrPtr = NULLDYNST;
					DBA_DYNFLD_STP actualPEpricePtr = NULLDYNST;
					FLAG_T freeInstrFlg = FALSE;
					objectOperation = InvestOpEnt;
					SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Invest);

					if ((ret = DBA_GetLinkedInstrForPE(hierHead, instrPtr, &linkedInstrPtr, &freeInstrFlg,
						                               SubNat_ActualPESecurity)) == RET_SUCCEED && linkedInstrPtr != NULLDYNST)
					{
						SET_ID(extOperation, ExtOp_InstrId, GET_ID(linkedInstrPtr, A_Instr_Id));
					}
					else
					{
						if (freeInstrFlg == TRUE)
						{
							FREE_DYNST(linkedInstrPtr, A_Instr);
						}
						return (ret);
					}

					if ((actualPEpricePtr = ALLOC_DYNST(A_InstrPrice)) == NULL)
					{
						if (freeInstrFlg == TRUE) 
						{ 
							FREE_DYNST(linkedInstrPtr, A_Instr); 
						}
						MSG_RETURN(RET_MEM_ERR_ALLOC);
					}

					if (FIN_InstrPrice(GET_ID(linkedInstrPtr, A_Instr_Id), NULL, GET_DATETIME(flowPtr, Flow_OptimalDate),
						               NULL, (ID_T)0, NULL, NULL, NULL, hierHead, actualPEpricePtr, FALSE) == RET_SUCCEED &&
						actualPEpricePtr != NULLDYNST &&
						(GET_PRICE(actualPEpricePtr, A_InstrPrice_Price) != ZERO_PRICE))
					{
						SET_PRICE(extOperation, ExtOp_Price, GET_PRICE(actualPEpricePtr, A_InstrPrice_Price));
					}
					else
					{
						SET_PRICE(extOperation, ExtOp_Price, 1);
					}
					scptFlagTabExtOp[ExtOp_Price] = TRUE;
					scptFlagTabExtOp[ExtOp_Quote] = FALSE;

					if (freeInstrFlg == TRUE)
					{
						FREE_DYNST(linkedInstrPtr, A_Instr);
					}
					FREE_DYNST(actualPEpricePtr, A_InstrPrice);
				}
			}
			else
			{
				objectOperation = BuyOpEnt;
				SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);
			}

            /* Ref quantiy sign analysed in ext pos generation */
            if (GET_NUMBER(flowPtr, Flow_RefQty) == 0.0)
            {
                qty = GET_NUMBER(stock, ExtPos_Qty) * (GET_PERCENT(flowPtr, Flow_Proba) / 100.0);
            }
            else
            {
                qty = GET_NUMBER(stock, ExtPos_Qty) / GET_NUMBER(flowPtr, Flow_RefQty) *
                      (GET_PERCENT(flowPtr, Flow_Proba) / 100.0);
            }

            SET_NUMBER(extOperation, ExtOp_Qty, CAST_NUMBER(qty)); /* REF3288 - SSO - 990205 */
    
            if (GET_NUMBER(instrPtr, A_Instr_ContractSize)  != 0)
            {
                qty = GET_NUMBER(extOperation, ExtOp_Qty) / GET_NUMBER(instrPtr, A_Instr_ContractSize);
                SET_NUMBER(extOperation, ExtOp_Qty, CAST_NUMBER(qty)); /* REF3288 - SSO - 990205 */
            }
            break;

        case FlowNat_Redm :
			/*PMSTA-32106 -NRAO 180904*/
			if (DBA_IsPEFundShare(instrPtr, SubNat_None) == TRUE)
			{
				if ((FLOWSUBNAT_ENUM)GET_ENUM(flowPtr, Flow_SubNatEn) == FlowSubNat_CapitalReturn)
				{
					GEN_GetApplInfo(ApplCapitalReturnTpId, &dfltTpId);
				}
				else if ((FLOWSUBNAT_ENUM)GET_ENUM(flowPtr, Flow_SubNatEn) == FlowSubNat_CapReduc)
				{
					GEN_GetApplInfo(ApplCapitalReductionTpId, &dfltTpId);
				}
				else if ((FLOWSUBNAT_ENUM)GET_ENUM(flowPtr, Flow_SubNatEn) == FlowSubNat_RedemCapitalToRec)
				{
					GEN_GetApplInfo(ApplCapitalToRecieveTpId, &dfltTpId);
				}
				else if ((FLOWSUBNAT_ENUM)GET_ENUM(flowPtr, Flow_SubNatEn) == FlowSubNat_RedemCapitalToPay)
				{
					GEN_GetApplInfo(ApplCapitalToPayTpId, &dfltTpId);
				}
				else
				{
					GEN_GetApplInfo(ApplRedempOpTpId, &dfltTpId);
				}
			}
			else
			{
				GEN_GetApplInfo(ApplRedempOpTpId, &dfltTpId);
			}

            /* PMSTA07549 - DDV - 090514 - Don't create operation if the position is part of an operation generated by the same event */
            if(DATETIME_CMP(GET_DATETIME(flowPtr, Flow_OptimalDate),
                            GET_DATETIME(stock, ExtPos_OpDate)) == 0 &&
               CMP_DYNFLD(flowPtr, stock,
                          Flow_EvtCd, ExtPos_EvtCd, CodeType) == 0 &&
               IS_NULLFLD(stock, ExtPos_EvtNbr) == FALSE &&
               GET_NUMBER(stock, ExtPos_EvtNbr) != 0 &&
               GET_NUMBER(stock, ExtPos_EvtNbr) == (NUMBER_T) GET_INT(flowPtr, Flow_EvtNbr))
            {
                operation = NULLDYNST;
                if (DBA_GetRecPtrFromHierById(hierHead, GET_ID(stock, ExtPos_OpenOpId), A_Op, &operation) == RET_SUCCEED &&
                    operation != NULLDYNST)
                {
                    if (GET_ID(operation, A_Op_TpId) == dfltTpId)
                        dontCreateOp = TRUE;
                }
                operation = NULLDYNST;
            }

            /* PMSTA-34774 - 070319 - PMO */
            bSTNComputation = InstrumentNature::isJournalSTNCompuation(instrPtr);   /* PMSTA-35020 - 080319 - PMO */

            /* PMSTA-32116 - 200818 - PMO */
            if (true == bSTNComputation)
            {
                // Input data
                InstrumentSTNComputation stn(stock, instrPtr, fromDateTime);

                // Computation
                ret = stn.computeJournal();
                    
                // Grab resulting data
                qty = stn.getQty();
                SET_PRICE(extOperation, ExtOp_Quote, stn.getQuote());
            } /* < PMSTA-34288 - 190221 - CHU */
            else if (InstrumentNature::isDualCurrencyInvestMoneyMarket(instrPtr)    ||
                     InstrumentNature::isTripleCurrencyInvestMoneyMarket(instrPtr))
            {
                SET_EXCHANGE(extOperation, ExtOp_OpExchRate, GET_EXCHANGE(flowPtr, Flow_FxdExchRate));
                scptFlagTabExtOp[ExtOp_OpExchRate] = TRUE;
                
                qty = GET_NUMBER(stock, ExtPos_Qty);
            } /* > PMSTA-34288 - 190221 - CHU */
            else
            {
                /* PMSTA-17422 - 130114 - PMO */
                if ((INSTRNAT_ENUM)  GET_ENUM(instrPtr, A_Instr_NatEn)      == InstrNat_Bond           &&
	                (FLOWNAT_ENUM)   GET_ENUM(flowPtr,  Flow_NatEn)         == FlowNat_Redm            &&
				    (FLOWSUBNAT_ENUM)GET_ENUM(flowPtr,  Flow_SubNatEn)      == FlowSubNat_Amortisation  )
                { /* Quantity is computed by the proportion of the redemption */
                    qty = GET_NUMBER(stock, ExtPos_Qty) * (GET_PERCENT(flowPtr, Flow_IoRPrct) * 0.01);
                }
                else
                {
                    /* Ref quantity sign analysed in ext pos generation */
                    if (GET_NUMBER(flowPtr, Flow_RefQty) == 0.0)
                    {
                        qty = GET_NUMBER(stock, ExtPos_Qty) * (GET_PERCENT(flowPtr, Flow_Proba) / 100.0);
                    }
                    else
                    {
	                    /* REF358 - RAK - 971209 */
	                    /* Flow_RefQty is like 0.8 so multiply ExtPos_Qty by Flow_RefQty */
                        qty = GET_NUMBER(stock, ExtPos_Qty) * GET_NUMBER(flowPtr, Flow_RefQty) *
                              (GET_PERCENT(flowPtr, Flow_Proba) / 100.0);
                    }
                }
            }

			/*PMSTA-32106 -NRAO 180904*/
			if (DBA_IsPEFundShare(instrPtr, SubNat_PEDrawdown) == TRUE &&
				(FLOWSUBNAT_ENUM)GET_ENUM(flowPtr, Flow_SubNatEn) == FlowSubNat_RedemCapitalToPay &&
				(CMP_ID(GET_ID(instrPtr, A_Instr_Id), GET_ID(flowPtr, Flow_InstrId)) == 0))
			{
				/*Special case for PE-FundShares - Capital Call*/
				isPECapitalCall = TRUE;
				if (posNbr == 1)
				{
					posNbrToCreate = 2;
					objectOperation = SellOpEnt;
					SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);

					if ((ret = FIN_ExtractLinkedPEQtyFromHier(ptfPtr, instrPtr, SubNat_PEInitialCommitment, hierHead, &posQty)) != RET_SUCCEED)
					{
						qty = 0;
						return (ret);
					}

					qty = posQty * (GET_PERCENT(flowPtr, Flow_IoRPrct) * 0.01);
					copyQty = qty;
				}
				else
				{
					objectOperation = BuyOpEnt;
					SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);

					if ((ret = FIN_SetLinkedInstrForPE(hierHead, instrPtr, SubNat_PECapitalCall, extOperation)) != RET_SUCCEED)
					{
						qty = 0;
						return (ret);
					}
					qty = copyQty;
				}
				scptFlagTabExtOp[ExtOp_Price] = FALSE;
				scptFlagTabExtOp[ExtOp_Quote] = FALSE;

			}

			/*PMSTA-32106 -NRAO 180904*/
			if (DBA_IsPEFundShare(instrPtr, SubNat_PEInitialCommitment) == TRUE &&
				(FLOWSUBNAT_ENUM)GET_ENUM(flowPtr, Flow_SubNatEn) == FlowSubNat_CapReduc &&
				(CMP_ID(GET_ID(instrPtr, A_Instr_Id), GET_ID(flowPtr, Flow_InstrId)) == 0))
			{
				/*Special case for PE-FundShares - Capital Reduction*/
				isPECapReduc = TRUE;
				if (posNbr == 1)
				{
					posNbrToCreate = 2;
					copyQty = qty = GET_NUMBER(stock, ExtPos_Qty) * (GET_PERCENT(flowPtr, Flow_IoRPrct) * 0.01);
				}
				else
				{
					if ((ret = FIN_SetLinkedInstrForPE(hierHead, instrPtr, SubNat_PEDrawdown, extOperation)) == RET_SUCCEED &&
						((ret = FIN_ExtractLinkedPEQtyFromHier(ptfPtr, instrPtr, SubNat_PEDrawdown, hierHead, &posQty)) == RET_SUCCEED))
					{
						if (posQty < copyQty)
							qty = posQty;
						else
							qty = copyQty;
					}
					else
					{
						qty = 0;
						return (ret);
					}
				}

				if (qty >= 0)
				{
					objectOperation = SellOpEnt;
					SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);
				}

				scptFlagTabExtOp[ExtOp_Price] = FALSE;
				scptFlagTabExtOp[ExtOp_Quote] = FALSE;

			}

			/*PMSTA-32106 -NRAO 180904*/
			if (DBA_IsPEFundShare(instrPtr, SubNat_PECapitalCall) == TRUE &&
				(FLOWSUBNAT_ENUM)GET_ENUM(flowPtr, Flow_SubNatEn) == FlowSubNat_CapitalReturn &&
				(CMP_ID(GET_ID(instrPtr, A_Instr_Id), GET_ID(flowPtr, Flow_InstrId)) == 0))
			{
				/*Special case for PE-FundShares - Capital Return*/
				isPECapReturn = TRUE;
				if (posNbr == 1)
				{
					posNbrToCreate = 2;
					objectOperation = SellOpEnt;
					SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);

					if ((ret = FIN_ExtractLinkedPEQtyFromHier(ptfPtr, instrPtr, SubNat_PEInitialCommitment, hierHead, &posQty)) != RET_SUCCEED)
					{
						qty = 0;
						return (ret);
					}

					qty = posQty * (GET_PERCENT(flowPtr, Flow_IoRPrct) * 0.01);
					copyQty = qty;
				}
				else
				{
					objectOperation = BuyOpEnt;
					SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);

					if ((ret = FIN_SetLinkedInstrForPE(hierHead, instrPtr, SubNat_PEDrawdown, extOperation)) != RET_SUCCEED)
					{
						qty = 0;
						return (ret);
					}

					qty = copyQty;
				}
				scptFlagTabExtOp[ExtOp_Price] = FALSE;
				scptFlagTabExtOp[ExtOp_Quote] = FALSE;
			}

			/*PMSTA-32106 -NRAO 180904*/
			if (DBA_IsPEFundShare(instrPtr, SubNat_ActualPESecurity) == TRUE &&
				(FLOWSUBNAT_ENUM)GET_ENUM(flowPtr, Flow_SubNatEn) == FlowSubNat_RedemCapitalToRec &&
				(CMP_ID(GET_ID(instrPtr, A_Instr_Id), GET_ID(flowPtr, Flow_InstrId)) == 0))
			{
				/*Special case for PE-FundShares - Capital to Receive*/
				isPECapToReceive = TRUE;
				if (posNbr == 1)
				{
					DBA_DYNFLD_STP actualPEpricePtr = NULLDYNST;
					posNbrToCreate = 2;
					objectOperation = SellOpEnt;
					SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);

					if ((ret = FIN_ExtractLinkedPEQtyFromHier(ptfPtr, instrPtr, SubNat_PEInitialCommitment, hierHead, &posQty)) == RET_SUCCEED)
					{
						qty = posQty * (GET_PERCENT(flowPtr, Flow_IoRPrct) * 0.01);

                        if (qty > GET_NUMBER(stock, ExtPos_Qty))
                        {
                            qty = GET_NUMBER(stock, ExtPos_Qty);
                        }

						copyQty = qty;

						if ((actualPEpricePtr = ALLOC_DYNST(A_InstrPrice)) == NULL)
						{
							qty = 0;
							MSG_RETURN(RET_MEM_ERR_ALLOC);
						}

						if (FIN_InstrPrice(GET_ID(instrPtr, A_Instr_Id), NULL, GET_DATETIME(flowPtr, Flow_OptimalDate),
							               NULL, (ID_T)0, NULL, NULL, NULL, hierHead, actualPEpricePtr, FALSE) == RET_SUCCEED &&
							actualPEpricePtr != NULLDYNST &&
							GET_PRICE(actualPEpricePtr, A_InstrPrice_Price) != ZERO_PRICE)
						{
							SET_PRICE(extOperation, ExtOp_Price, GET_PRICE(actualPEpricePtr, A_InstrPrice_Price));
						}
						else
							SET_PRICE(extOperation, ExtOp_Price, 1);

						scptFlagTabExtOp[ExtOp_Price] = TRUE;
						scptFlagTabExtOp[ExtOp_Quote] = FALSE;

						FREE_DYNST(actualPEpricePtr, A_InstrPrice);
					}
					else
					{
						qty = 0;
						return (ret);
					}
				}
				else
				{
					objectOperation = BuyOpEnt;
					SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);

					if ((ret = FIN_SetLinkedInstrForPE(hierHead, instrPtr, SubNat_PEDrawdown, extOperation)) != RET_SUCCEED)
					{
						qty = 0;
						return (ret);
					}

					qty = copyQty;
					scptFlagTabExtOp[ExtOp_Price] = FALSE;
					scptFlagTabExtOp[ExtOp_Quote] = FALSE;
				}
			}

			/*PMSTA-32106 -NRAO 180904*/
			if (DBA_IsPEFundShare(instrPtr, SubNat_None) == TRUE &&
				(FLOWSUBNAT_ENUM)GET_ENUM(flowPtr, Flow_SubNatEn) == FlowSubNat_FinalRedm &&
				(CMP_ID(GET_ID(instrPtr, A_Instr_Id), GET_ID(flowPtr, Flow_InstrId)) == 0))
			{
				/*Special case for PE-FundShares - Final Redemption*/
				isPEFinalRedem = TRUE;
				scptFlagTabExtOp[ExtOp_Quote] = FALSE;
				scptFlagTabExtOp[ExtOp_Price] = FALSE;

				if ((SUBNAT_ENUM)GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_ActualPESecurity)
				{
					SET_PRICE(extOperation, ExtOp_Quote, GET_PRICE(flowPtr, Flow_Quote));
					SET_PRICE(extOperation, ExtOp_Price, GET_PRICE(flowPtr, Flow_AmtUnit));

					scptFlagTabExtOp[ExtOp_Quote] = TRUE;
					scptFlagTabExtOp[ExtOp_Price] = TRUE;
				}
			}
            SET_NUMBER(extOperation, ExtOp_Qty, CAST_NUMBER(qty)); /* REF3288 - SSO - 990205 */
            
            if (GET_ENUM(stock, ExtPos_RefNatEn) == PosRefNat_Close ||
		        GET_ENUM(stock, ExtPos_RefNatEn) == PosRefNat_RepoClose ||
		        GET_ENUM(stock, ExtPos_RefNatEn) == PosRefNat_RemereClose) 	/* DVP454 - 970512 - DED */
            {
                FREE_DYNST(extOperation, ExtOp);
                FREE(scptFlagTabExtOp);
                return(RET_SUCCEED);
            }
            
			if (isPECapitalCall == FALSE && isPECapReturn == FALSE && isPECapToReceive == FALSE && isPECapReduc == FALSE) /*PMSTA-32106 -NRAO 180904*/
			{
				if (GET_NUMBER(stock, ExtPos_Qty) >= 0)
				{
					objectOperation = SellOpEnt;
					SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);
				}
				else
				{
					objectOperation = BuyOpEnt;
					SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);
					SET_NUMBER(extOperation, ExtOp_Qty, GET_NUMBER(extOperation, ExtOp_Qty)*(-1));
				}
			}

		    refNatEn = GET_ENUM(stock, ExtPos_RefNatEn);  /* REF3154 - SSO - 000403 */
		    /* DVP454 - 970512 - DED */
		    switch(refNatEn)
		    {
			case PosRefNat_Open :
				SET_ENUM(extOperation, ExtOp_RefNatEn, PosRefNat_Close);
				COPY_DYNFLD(extOperation, ExtOp, ExtOp_RefOpCd, 
                                            stock, ExtPos, ExtPos_OpenOpCd);
				break;
			case PosRefNat_RepoOpen :
				SET_ENUM(extOperation, ExtOp_RefNatEn, PosRefNat_RepoClose);
				COPY_DYNFLD(extOperation, ExtOp, ExtOp_RefOpCd, 
                                            stock, ExtPos, ExtPos_OpenOpCd);
                                getLockingPos = TRUE; /* REF2667 - DDV - 980903 */
				break;
			case PosRefNat_RemereOpen :
				SET_ENUM(extOperation, ExtOp_RefNatEn, PosRefNat_RemereClose);
				COPY_DYNFLD(extOperation, ExtOp, ExtOp_RefOpCd, 
                                            stock, ExtPos, ExtPos_OpenOpCd);
                                getLockingPos = TRUE; /* REF2667 - DDV - 980903 */
				break;

			/* REF1485 - RAK - 980331 */
			case PosRefNat_FRAOpen :
				SET_ENUM(extOperation, ExtOp_RefNatEn, PosRefNat_FRAClose);
				COPY_DYNFLD(extOperation, ExtOp, ExtOp_RefOpCd, 
                                            stock, ExtPos, ExtPos_OpenOpCd);

				break;

			case PosRefNat_SwapOpen :
				SET_ENUM(extOperation, ExtOp_RefNatEn, PosRefNat_SwapClose);
				COPY_DYNFLD(extOperation, ExtOp, ExtOp_RefOpCd, 
                                            stock, ExtPos, ExtPos_OpenOpCd);
				break;

			case PosRefNat_FXSwapOpen :
				SET_ENUM(extOperation, ExtOp_RefNatEn, PosRefNat_FXSwapClose);
				COPY_DYNFLD(extOperation, ExtOp, ExtOp_RefOpCd, 
                                            stock, ExtPos, ExtPos_OpenOpCd);
				break;
		    }

		    /* REF3154 - SSO - 000403 : mmkt income: set AI reset */
		    if ( (mmIncRedemFlg == TRUE) &&
		         (refNatEn == PosRefNat_Open || refNatEn == PosRefNat_RepoOpen|| refNatEn == PosRefNat_RemereOpen) )
		    {
		        SET_ENUM(extOperation, ExtOp_FusRuleEn, PosFusRule_AIReset);
		        scptFlagTabExtOp[ExtOp_FusRuleEn]=TRUE;
		    }

		    /* REF2667 - DDV - 980904 */
            if (getLockingPos == TRUE)
            {
                /* REF2667 - DDV - 980831 */
                if ((getArgSt = ALLOC_DYNST(Get_Arg)) == NULL)
                {
                    FREE_DYNST(extOperation, ExtOp);
                    FREE(scptFlagTabExtOp);
                    MSG_RETURN(RET_MEM_ERR_ALLOC);
                }

                if ((lockingPos = ALLOC_DYNST(ExtPos)) == NULL)
                {
                    FREE_DYNST(getArgSt, Get_Arg);
                    FREE_DYNST(extOperation, ExtOp);
                    FREE(scptFlagTabExtOp);
                    MSG_RETURN(RET_MEM_ERR_ALLOC);
                }

                COPY_DYNFLD(getArgSt, Get_Arg, Get_Arg_Id,
                            stock,    ExtPos,  ExtPos_OpenOpId);
                SET_ENUM(getArgSt, Get_Arg_PosNatEn, PosNat_LockingPos);


                if ((ret = DBA_Get2(EPos, UNUSED, Get_Arg, getArgSt,
                                    ExtPos, &lockingPos,
                                    UNUSED, UNUSED, UNUSED)) != RET_SUCCEED)
                {
                    /* REF3557 - DDV - 990424 - If locking operation not found,
                       try to find it using ref_oper_code stored in main part of stock operation */
                    DBA_DYNFLD_STP    *extract;
                    int               extractNbr = 0;

                    if ((ret = DBA_ExtractHierEltRec(hierHead, ExtPos,
                                   FALSE, NULL, NULL,
                                   &extractNbr, &extract)) != RET_SUCCEED)
                    {
                        FREE_DYNST(lockingPos, ExtPos);
                        FREE_DYNST(getArgSt, Get_Arg);
                        FREE_DYNST(extOperation, ExtOp);
                        FREE(scptFlagTabExtOp);
                        return(RET_DBA_ERR_NODATA);
                    }

                    found = FALSE; 
                    for (i=0; i < extractNbr && found == FALSE; i++)
                    {
                        if (GET_ENUM(extract[i], ExtPos_PosNatEn) == PosNat_MainPos &&
                            CMP_DYNFLD(extract[i], stock,
                                       ExtPos_OpenOpId, ExtPos_OpenOpId, IdType) == 0)	
                        {
                            /* search reference op in hierarchy */
                            for (j=0; j < extractNbr && found == FALSE; j++)
                            {
                                if (CMP_DYNFLD(extract[i], extract[j],
                                               ExtPos_RefOpCd, ExtPos_OpenOpCd, CodeType) == 0)
                                {
                                    COPY_DYNFLD(getArgSt,   Get_Arg, Get_Arg_Id,
                                                extract[j], ExtPos,  ExtPos_OpenOpId);
                                    found = TRUE;
                                }
                            }

                            /* if reference operation not found get it in database */
                            if (found == FALSE)
                            {
                                DBA_DYNFLD_STP      getOp=NULL, sOp=NULL; 
                                if ((getOp = ALLOC_DYNST(S_Op)) == NULL)
                                {
                                    FREE_DYNST(lockingPos, ExtPos);
                                    FREE_DYNST(getArgSt, Get_Arg);
                                    FREE_DYNST(extOperation, ExtOp);
                                    FREE(scptFlagTabExtOp);
                                    FREE(extract);
                                    MSG_RETURN(RET_MEM_ERR_ALLOC);
                                }
        
                                if ((sOp = ALLOC_DYNST(S_Op)) == NULL)
                                {
                                    FREE_DYNST(lockingPos, ExtPos);
                                    FREE_DYNST(getArgSt, Get_Arg);
                                    FREE_DYNST(extOperation, ExtOp);
                                    FREE(scptFlagTabExtOp);
                                    FREE(extract);
                                    FREE_DYNST(getOp, S_Op);
                                    MSG_RETURN(RET_MEM_ERR_ALLOC);
                                }

                                COPY_DYNFLD(getOp, S_Op, S_Op_Cd,
                                            extract[i], ExtPos,  ExtPos_RefOpCd);
                                COPY_DYNFLD(getOp, S_Op, S_Op_StatEn,
                                            extract[i], ExtPos,  ExtPos_StatEn);
        

                                if ((ret = DBA_Get2(Op, UNUSED, S_Op, getOp,
                                                S_Op, &sOp,
                                                UNUSED, UNUSED, UNUSED)) != RET_SUCCEED)
                                {
                                    FREE_DYNST(lockingPos, ExtPos);
                                    FREE_DYNST(getArgSt, Get_Arg);
                                    FREE_DYNST(extOperation, ExtOp);
                                    FREE(scptFlagTabExtOp);
                                    FREE(extract);
                                    FREE_DYNST(getOp, S_Op);
                                    FREE_DYNST(sOp, S_Op);
                                    return(RET_DBA_ERR_NODATA);
                                }
                                COPY_DYNFLD(getArgSt,   Get_Arg, Get_Arg_Id,
                                            sOp, S_Op, S_Op_Id);
                                found = TRUE;
                                FREE_DYNST(getOp, S_Op);
                                FREE_DYNST(sOp, S_Op);
                            }

                            /* REF3305 - ..\Src\finsrv01.c(2221) : warning C4702: unreachable code 
                            if (found == FALSE)
                            {
                                    FREE_DYNST(lockingPos, ExtPos);
                                    FREE_DYNST(getArgSt, Get_Arg);
                                    FREE_DYNST(extOperation, ExtOp);
                                    FREE(scptFlagTabExtOp);
                                    FREE(extract);
                                    return(RET_DBA_ERR_NODATA);
                            }
                            */
                        }
                    }

                    if (found == FALSE)
                    {
                            FREE_DYNST(lockingPos, ExtPos);
                            FREE_DYNST(getArgSt, Get_Arg);
                            FREE_DYNST(extOperation, ExtOp);
                            FREE(scptFlagTabExtOp);
                            FREE(extract);
                            return(RET_DBA_ERR_NODATA);
                    }

                    if ((ret = DBA_Get2(EPos, UNUSED, Get_Arg, getArgSt,
                                    ExtPos, &lockingPos,
                                    UNUSED, UNUSED, UNUSED)) != RET_SUCCEED)
                    {
                            FREE_DYNST(lockingPos, ExtPos);
                            FREE_DYNST(getArgSt, Get_Arg);
                            FREE_DYNST(extOperation, ExtOp);
                            FREE(scptFlagTabExtOp);
                            FREE(extract);
                            return(RET_DBA_ERR_NODATA);
                    }
                    FREE(extract);
                }

                FREE_DYNST(getArgSt, Get_Arg);

                /* REF1333 - DDV - 980526 */
                switch (GET_ENUM(lockingPos, ExtPos_LockNatEn))
                {
                    case OpLockNat_RepoLocking:
                        SET_ENUM(extOperation, ExtOp_LockNatEn, OpLockNat_RepoUnlocking);
                        break;
                    case OpLockNat_RemereLocking:
                        SET_ENUM(extOperation, ExtOp_LockNatEn, OpLockNat_RemereUnlocking);
                        break;
                    case OpLockNat_RevRepoLocking:
                        SET_ENUM(extOperation, ExtOp_LockNatEn, OpLockNat_RevRepoUnlocking);
				        COPY_DYNFLD(extOperation, ExtOp, ExtOp_LockOpCd, lockingPos, ExtPos, ExtPos_OpenOpCd);  /* REF4925 - 000704 - DED */
                        scptFlagTabExtOp[ExtOp_LockOpCd] = TRUE;						/* REF4925 - 000704 - DED */
                        break;
                    case OpLockNat_SellBuyBackLocking:
                        SET_ENUM(extOperation, ExtOp_LockNatEn, OpLockNat_SellBuyBackUnlocking);
                        break;
                    case OpLockNat_BuySellBackLocking:
                        SET_ENUM(extOperation, ExtOp_LockNatEn, OpLockNat_BuySellBackUnlocking);
				        COPY_DYNFLD(extOperation, ExtOp, ExtOp_LockOpCd, lockingPos, ExtPos, ExtPos_OpenOpCd);  /* REF4925 - 000704 - DED */
                        scptFlagTabExtOp[ExtOp_LockOpCd] = TRUE;                                                /* REF4925 - 000704 - DED */
                        break;
                }

                COPY_DYNFLD(extOperation, ExtOp, ExtOp_LockInstrId, lockingPos, ExtPos, ExtPos_InstrId);
                COPY_DYNFLD(extOperation, ExtOp, ExtOp_LockQty, lockingPos, ExtPos, ExtPos_Qty);

                scptFlagTabExtOp[ ExtOp_LockNatEn] = TRUE;
                scptFlagTabExtOp[ExtOp_LockInstrId] = TRUE;
                scptFlagTabExtOp[ExtOp_LockQty] = TRUE;

                FREE_DYNST(lockingPos, ExtPos);
            }

            switch (GET_ENUM(stock, ExtPos_LockNatEn))
            {
                case OpLockNat_RepoLocked:
                    SET_ENUM(extOperation, ExtOp_RefNatEn, PosRefNat_RepoClose);
                    SET_ENUM(extOperation, ExtOp_LockNatEn, OpLockNat_RepoUnlocking);
                    COPY_DYNFLD(extOperation, ExtOp, ExtOp_LockQty, 
                                stock, ExtPos, ExtPos_Qty);
                    scptFlagTabExtOp[ExtOp_RefNatEn]=TRUE;     
                    scptFlagTabExtOp[ExtOp_LockNatEn]=TRUE;     
                    scptFlagTabExtOp[ExtOp_LockQty]=TRUE;     
                    break;
                case OpLockNat_RemereLocked:
                    SET_ENUM(extOperation, ExtOp_RefNatEn, PosRefNat_RemereClose);
                    SET_ENUM(extOperation, ExtOp_LockNatEn, OpLockNat_RemereUnlocking);
                    COPY_DYNFLD(extOperation, ExtOp, ExtOp_LockQty, 
                                stock, ExtPos, ExtPos_Qty);
                    scptFlagTabExtOp[ExtOp_RefNatEn]=TRUE;     
                    scptFlagTabExtOp[ExtOp_LockNatEn]=TRUE;     
                    scptFlagTabExtOp[ExtOp_LockQty]=TRUE;     
                    break;
                case OpLockNat_RevRepoLocking:
                    SET_ENUM(extOperation, ExtOp_RefNatEn, PosRefNat_RepoClose);
                    SET_ENUM(extOperation, ExtOp_LockNatEn, OpLockNat_RevRepoUnlocking);
                    COPY_DYNFLD(extOperation, ExtOp, ExtOp_LockQty, 
                                stock, ExtPos, ExtPos_Qty);
                    scptFlagTabExtOp[ExtOp_RefNatEn]=TRUE;     
                    scptFlagTabExtOp[ExtOp_LockNatEn]=TRUE;     
                    scptFlagTabExtOp[ExtOp_LockQty]=TRUE;     
                    break;
            }

			/*PMSTA-32106 -NRAO 180904*/
			if (isPECapitalCall == FALSE && isPECapReturn == FALSE &&
				isPECapToReceive == FALSE && isPECapReduc == FALSE && isPEFinalRedem == FALSE)
			{
                /* PMSTA-34774 - 070319 - PMO */
                if (true == bSTNComputation && PriceCalcRule_Quote == static_cast<PRICECALCRULE_ENUM> (GET_ENUM(extOperation, ExtOp_PriceCalcRuleEn)))
                {
                    SET_PRICE(extOperation, ExtOp_Price, GET_PRICE(extOperation, ExtOp_Quote));
                }
                else
                {
                    /* PMSTA-40199 - Silpakal - 200610 */
                    if (GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_Swap)
                    {
                        PRINCIPAL_RULE_ENUM principalRule = PRINCIPAL_RULE_ENUM::PrincipalRule_NoExchange;
                        principalRule = static_cast<PRINCIPAL_RULE_ENUM>(GET_ENUM(instrPtr, A_Instr_PrincipalRuleEn));

                        if ((principalRule == PRINCIPAL_RULE_ENUM::PrincipalRule_NoExchange) ||
                            (principalRule == PRINCIPAL_RULE_ENUM::PrincipalRule_Initial))
                        {
                            SET_PRICE(extOperation, ExtOp_Price, ZERO_PRICE);
                        }
                        else if ((principalRule == PRINCIPAL_RULE_ENUM::PrincipalRule_Final) ||
                            (principalRule == PRINCIPAL_RULE_ENUM::PrincipalRule_InitialFinal))
                        {
                            SET_PRICE(extOperation, ExtOp_Price, 1);
                        }                        
                    }
                    else
                    {
                        /* BUG170 - XDI - 961008 */
                        SET_PRICE(extOperation, ExtOp_Price, GET_PRICE(flowPtr, Flow_AmtUnit));
                    }
                }

				scptFlagTabExtOp[ExtOp_Price] = TRUE;		/* REF9068 - TEB - 050318 */
			}
            scptFlagTabExtOp[ExtOp_RefNatEn]=TRUE;      
            scptFlagTabExtOp[ExtOp_RefOpCd]=TRUE;      
            SET_NUMBER(extOperation, ExtOp_AccrIntrAmt, 0.0);
            scptFlagTabExtOp[ExtOp_AccrIntrAmt]=TRUE;      

            if (GET_NUMBER(instrPtr, A_Instr_ContractSize)  != 0)
            {
                qty = GET_NUMBER(extOperation, ExtOp_Qty) / GET_NUMBER(instrPtr, A_Instr_ContractSize);
                SET_NUMBER(extOperation, ExtOp_Qty, CAST_NUMBER(qty)); /* REF3288 - SSO - 990205 */
            }
            break;

        case FlowNat_Exch :
		    treatRefNatFlg = FALSE;	 /* not treated by default REF3929 - SSO - 990909 */

		    /* ---------------------------------------------------- */
		    /* REF4441 - AKO - 000329 Use cash amount to generate a */
		    /* new operation in case of proportional attribution.   */
		    /* ---------------------------------------------------- */

		    if (posNbr == posNbrToCreate && toGenerateOpPropAttribCashFlg==TRUE)
		    {
			    objectOperation = AdjustOpEnt;
			    SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Adjust);
			    ret = FIN_CreatePropAttribCashOpe(  stock, extOperation,
							        hierHead,fromDateTime,
							        scptFlagTabExtOp, cashAmt);
		    }
		    else
		    {
		    /* --------------------------------------------------- */
		    /* REF4441 - AKO - 000329 Create an standard operation */
		    /* --------------------------------------------------- */
            /* PMSTA-36275 - SANAND - 220719
            If the Instrument Nature is ConvertBond,
            Exchange nature is Convert - New Instrument is to be created
            as per the Exchange_Event configuration */
            FLAG_T newInstrFlg = FALSE,convBondToExch = FALSE;
            if ((FlowSubNat_ConvExch == static_cast<FLOWSUBNAT_ENUM>GET_ENUM(flowPtr, Flow_SubNatEn)) &&
                (InstrNat_ConvertBond == static_cast<INSTRNAT_ENUM>GET_ENUM(instrPtr, A_Instr_NatEn)))
            {
                newInstrFlg = TRUE;
                convBondToExch = TRUE;
            }

            switch(GET_ENUM(flowPtr, Flow_EuroConvRuleEn))
		    {
			case EuroConvRule_None:
			    if (GET_FLAG(flowPtr, Flow_ReplaceFlg) == TRUE)
			    {
				switch (exchangePlRule)
				{
				case EvtPlRule_Underlying:

                    if (IS_NULLFLD(flowPtr, Flow_Quote) == TRUE ||
	                    GET_PRICE(flowPtr, Flow_Quote) == 0)
                    {
                        /* REF3089 - 990607 - DDV - All cases rewrite */
                        switch(GET_ENUM(flowPtr, Flow_OddLotCompEn))
                        {
					    case OddLotComp_Kept:
                            /* One adjustment operation on old instrument */
                            posNbrToCreate = 1;
                            treatRefNatFlg = TRUE; /* REF3929 - SSO - 990909 */

                            if (GET_ENUM(flowPtr, Flow_RoundRuleEn) != RndRule_None)
                                roundRule = RndRule_Down;
                            else
                                roundRule = RndRule_None;

                            objectOperation = AdjustOpEnt;
                            SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Adjust);

                            ret = FIN_GenExtOpExchFlow(stock, flowPtr, extOperation, 
		                             &instrPtr, hierHead, 
		                             scptFlagTabExtOp, newInstrFlg, roundRule,  /* PMSTA-36275 - SANAND - 220719 - New Intrument creation */
		                             QtyType_Rounded, QtyType_Rounded, 
		                             treatRefNatFlg); /* REF3929 - SSO - 990909 */
                            break;

                        case OddLotComp_Lost:
                            /* One adjustment operation on old instrument */
                            posNbrToCreate = 1;
                            treatRefNatFlg = TRUE; /* REF3929 - SSO - 990909 */

                            objectOperation = AdjustOpEnt;
                            SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Adjust);

                            ret = FIN_GenExtOpExchFlow(stock, flowPtr, extOperation, 
		                             &instrPtr, hierHead, 
		                             scptFlagTabExtOp, newInstrFlg,   /* PMSTA-36275 - SANAND - 220719 - New Intrument creation */
		                             (RNDRULE_ENUM) GET_ENUM(flowPtr, Flow_RoundRuleEn), /* REF7264 - DDV - 020326 - Compil C++ */
		                             QtyType_NotRounded, QtyType_Rounded, 
		                             treatRefNatFlg); /* REF3929 - SSO - 990909 */
                            break;

					    case OddLotComp_CashCompensationNew:
						/* two operations, one ajustment of old instrument 
						    and on buy or sell of new instrument for cash compensation */ 

                            /* PMSTA-36275 - SANAND - 220719 -
                            If Instrument Nature is ConvertBond, Exchange Nature is Conversion, only one
                            Adjustment needs to be created */
                            posNbrToCreate = (TRUE == convBondToExch) ? 1 : 2;
                            if (GET_ENUM(flowPtr, Flow_RoundRuleEn) == RndRule_None)/* REF3929 - SSO - 990909 */
                            {
                                treatRefNatFlg = TRUE;    
                            }

                            if (posNbr == 1)
                            {
                              objectOperation = AdjustOpEnt;
                              SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Adjust);

                              ret = FIN_GenExtOpExchFlow(stock, flowPtr, extOperation, 
			                             &instrPtr, hierHead, 
			                             scptFlagTabExtOp, newInstrFlg, RndRule_None,  /* PMSTA-36275 - SANAND - 220719 - New Intrument creation*/
			                                 QtyType_NotRounded, QtyType_NotRounded, 
			                             treatRefNatFlg); /* REF3929 - SSO - 990909 */
                            }
                            else if (posNbr == 2)
                            {
                                if (GET_NUMBER(stock, ExtPos_Qty) >= 0)
                                {
                                    switch(GET_ENUM(flowPtr, Flow_RoundRuleEn))
                                    {
                                    case RndRule_Nearest: /* suppose will be down, if not FIN_GenExtOpExchFlow change op */
                                    case RndRule_Down:
                                        objectOperation = SellOpEnt;
                                        SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);
                                        break;
                                    case RndRule_Up:
                                        objectOperation = BuyOpEnt;
                                        SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);
                                        break;
                                    default: /* REF3929 - SSO - 990909  "none" case! */
                                        dontCreateOp = TRUE;
                                        break;
                                    }
                                }
                                else
                                {
                                    switch(GET_ENUM(flowPtr, Flow_RoundRuleEn))
                                    {
                                    case RndRule_Nearest: /* suppose will be down, if not FIN_GenExtOpExchFlow change op */
                                    case RndRule_Down:
                                        objectOperation = BuyOpEnt;
                                        SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);
                                        break;
                                    case RndRule_Up:
                                        objectOperation = SellOpEnt;
                                        SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);
                                        break;
                                    default: /* REF3929 - SSO - 990909  "none" case! */
                                        dontCreateOp = TRUE;
                                        break;
                                    }
                                }

						        if (dontCreateOp == FALSE) /* REF3929 - SSO - 990909  "none" case! */
						        {
							        ret = FIN_GenExtOpExchFlow(stock, flowPtr, extOperation, 
                                                    &instrPtr, hierHead, 
                                                    scptFlagTabExtOp, TRUE, 
                                                    (RNDRULE_ENUM) GET_ENUM(flowPtr, Flow_RoundRuleEn), /* REF7264 - DDV - 020326 - Compil C++ */
                                                    QtyType_Remain, QtyType_Zero, 
                                                    treatRefNatFlg); /* REF3929 - SSO - 990909 */

							        switch(GET_ENUM(extOperation, ExtOp_NatureEn))
							        { 
							        case OpNat_Sell:
							            objectOperation = SellOpEnt;
							            break;
							        case OpNat_Buy:
							            objectOperation = BuyOpEnt;
							            break;
    						        default: /* REF3929 - SSO - 990909  "none" case! */
							            dontCreateOp = TRUE;
							            break;
							        }
						        }
						    }
						    break;
					    case OddLotComp_CashCompensationOld:
						/* two operations, one ajustment of old instrument 
						    and on buy or sell of old instrument for cash compensation */ 

                            /* PMSTA-36275 - SANAND - 220719 -
                            If Instrument Nature is ConvertBond, Exchange Nature is Conversion, only one
                            Adjustment needs to be created */
                            posNbrToCreate = (TRUE == convBondToExch) ? 1 : 2;
						    if (GET_ENUM(flowPtr, Flow_RoundRuleEn) == RndRule_Down
						        || GET_ENUM(flowPtr, Flow_RoundRuleEn) == RndRule_None)/* REF3929 - SSO - 990909 */
						    {
							    treatRefNatFlg = TRUE;    
						    }

						    if (posNbr == 1)
						    {
						        objectOperation = AdjustOpEnt;
						        SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Adjust);

						        ret = FIN_GenExtOpExchFlow(stock, flowPtr, extOperation, 
										        &instrPtr, hierHead, 
										        scptFlagTabExtOp, newInstrFlg,   /* PMSTA-36275 - SANAND - 220719 - New Intrument creation*/
										        (RNDRULE_ENUM) GET_ENUM(flowPtr, Flow_RoundRuleEn), /* REF7264 - DDV - 020326 - Compil C++ */
			    							    QtyType_Rounded, QtyType_Rounded, 
										        treatRefNatFlg); /* REF3929 - SSO - 990909 */
						    }
						    else if (posNbr == 2)
						    {
						        if (GET_NUMBER(stock, ExtPos_Qty) >= 0)
						        {
                                    switch(GET_ENUM(flowPtr, Flow_RoundRuleEn))
                                    {
                                    case RndRule_Nearest: /* suppose will be down, if not FIN_GenExtOpExchFlow change op */
                                    case RndRule_Down:
                                        objectOperation = SellOpEnt;
                                        SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);
                                        break;
                                    case RndRule_Up:
                                        objectOperation = BuyOpEnt;
                                        SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);
                                        break;
                                    default: /* REF3929 - SSO - 990909  "none" case! */
                                        dontCreateOp = TRUE;
                                        break;
                                    }
                                }
                                else
                                {
                                    switch(GET_ENUM(flowPtr, Flow_RoundRuleEn))
                                    {
                                    case RndRule_Nearest: /* suppose will be down, if not FIN_GenExtOpExchFlow change op */
                                    case RndRule_Down:
                                        objectOperation = BuyOpEnt;
                                        SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);
                                        break;
                                    case RndRule_Up:
                                        objectOperation = SellOpEnt;
                                        SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);
                                        break;
                                    default: /* REF3929 - SSO - 990909  "none" case! */
                                        dontCreateOp = TRUE;
                                        break;
                                    }
                                }

						        if (dontCreateOp == FALSE) /* REF3929 - SSO - 990909  "none" case! */
						        {
							        ret = FIN_GenExtOpExchFlow(stock, flowPtr, extOperation, 
										       &instrPtr, hierHead, 
										       scptFlagTabExtOp, newInstrFlg,   /* PMSTA-36275 - SANAND - 220719 - New Intrument creation*/
										       (RNDRULE_ENUM) GET_ENUM(flowPtr, Flow_RoundRuleEn), /* REF7264 - DDV - 020326 - Compil C++ */
										       QtyType_Remain, QtyType_Zero, 
										        treatRefNatFlg); /* REF3929 - SSO - 990909 */

							        switch(GET_ENUM(extOperation, ExtOp_NatureEn))
							        {
							        case OpNat_Sell:
							            objectOperation = SellOpEnt;
							            break;
							        case OpNat_Buy:
							            objectOperation = BuyOpEnt;
							            break;
                                    case OpNat_None: /* REF7479 - YST - 020409 */
							            dontCreateOp = TRUE; 
							            break;
							        }
						        }
						    }
						    break;
					    }
				    }
				    else
				    {
                        switch(GET_ENUM(flowPtr, Flow_OddLotCompEn))
                        {
					    case OddLotComp_Kept:
					      /* two operation, one adjustment operation on old instrument
						      and a buy or sell operation on new instrument */

                              /* PMSTA-36275 - SANAND - 220719 -
                              If Instrument Nature is ConvertBond, Exchange Nature is Conversion, only one
                              Adjustment needs to be created */
                            posNbrToCreate = (TRUE == convBondToExch) ? 1 : 2;

						    if (posNbr == 1)
						    {
                                if (GET_ENUM(flowPtr, Flow_RoundRuleEn) != RndRule_None)
					  		        roundRule = RndRule_Down;
						        else
					  		        roundRule = RndRule_None;

						        objectOperation = AdjustOpEnt;
						        SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Adjust);

						        ret = FIN_GenExtOpExchFlow(stock, flowPtr, extOperation, 
										     &instrPtr, hierHead, 
										     scptFlagTabExtOp, newInstrFlg, roundRule,  /* PMSTA-36275 - SANAND - 220719 - New Intrument creation*/
										     QtyType_Rounded, QtyType_Zero, 
										     treatRefNatFlg); /* REF3929 - SSO - 990909 */

						    }
						    else if (posNbr == 2)
						    {
                                if (GET_ENUM(flowPtr, Flow_RoundRuleEn) != RndRule_None)
					  		        roundRule = RndRule_Down;
						        else
					  		        roundRule = RndRule_None;

						        if (GET_NUMBER(stock, ExtPos_Qty) >= 0)
						        {
							        objectOperation = BuyOpEnt;
							        SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);
						        }
						        else
						        {
							        objectOperation = SellOpEnt;
							        SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);
						        }

						        ret = FIN_GenExtOpExchFlow(stock, flowPtr, extOperation, 
										         &instrPtr, hierHead, 
										         scptFlagTabExtOp, TRUE, 
										         roundRule,
										         QtyType_Rounded, QtyType_Zero, 
										         treatRefNatFlg); /* REF3929 - SSO - 990909 */
						    }

						    break;
					    case OddLotComp_Lost:
					       /* two operation, one adjustment operation on old instrument
						      and a buy or sell operation on new instrument */

                              /* PMSTA-36275 - SANAND - 220719 -
                              If Instrument Nature is ConvertBond, Exchange Nature is Conversion, only one
                              Adjustment needs to be created */
                            posNbrToCreate = (TRUE == convBondToExch) ? 1 : 2;

						    if (posNbr == 1)
						    {
						        objectOperation = AdjustOpEnt;
						        SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Adjust);

						        ret = FIN_GenExtOpExchFlow(stock, flowPtr, extOperation, 
										         &instrPtr, hierHead, 
										         scptFlagTabExtOp, newInstrFlg, RndRule_None, /* PMSTA-36275 - SANAND - 220719 - New Intrument creation*/
										         QtyType_NotRounded, QtyType_Zero, 
										         treatRefNatFlg); /* REF3929 - SSO - 990909 */

						    }
						    else if (posNbr == 2)
						    {

						        if (GET_NUMBER(stock, ExtPos_Qty) >= 0)
						        {
							        objectOperation = BuyOpEnt;
							        SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);
                                }
                                else
                                {
                                    objectOperation = SellOpEnt;
                                    SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);
                                }

                                ret = FIN_GenExtOpExchFlow(stock, flowPtr, extOperation, 
										         &instrPtr, hierHead, 
										         scptFlagTabExtOp, TRUE, 
										         (RNDRULE_ENUM) GET_ENUM(flowPtr, Flow_RoundRuleEn), /* REF7264 - DDV - 020326 - Compil C++ */
										         QtyType_Rounded, QtyType_Zero, 
										         treatRefNatFlg); /* REF3929 - SSO - 990909 */
						    }
						    break;
					    case OddLotComp_CashCompensationNew:
					      /* three operations, one ajustment of old instrument 
						     and one buy or sell of new instrument for cash compensation
						     and one buy or sell of new instrument */ 

                             /* PMSTA-36275 - SANAND - 220719 -
                             If Instrument Nature is ConvertBond, Exchange Nature is Conversion, only one
                             Adjustment needs to be created */
                            posNbrToCreate = (TRUE == convBondToExch) ? 1 : 3;

						    if (posNbr == 1)
						    {
						        objectOperation = AdjustOpEnt;
						        SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Adjust);

						        ret = FIN_GenExtOpExchFlow(stock, flowPtr, extOperation, 
										         &instrPtr, hierHead, 
										         scptFlagTabExtOp, newInstrFlg, RndRule_None,  /* PMSTA-36275 - SANAND - 220719 - New Intrument creation*/
			    							     QtyType_NotRounded, QtyType_Zero, 
										        treatRefNatFlg); /* REF3929 - SSO - 990909 */
						    }
						    else if (posNbr == 2)
						    {

						        if (GET_NUMBER(stock, ExtPos_Qty) >= 0)
						        {
							        objectOperation = BuyOpEnt;
							        SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);
						        }
						        else
						        {
							        objectOperation = SellOpEnt;
							        SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);
						        }

						        ret = FIN_GenExtOpExchFlow(stock, flowPtr, extOperation, 
										         &instrPtr, hierHead, 
										         scptFlagTabExtOp, TRUE, 
										         (RNDRULE_ENUM) GET_ENUM(flowPtr, Flow_RoundRuleEn), /* REF7264 - DDV - 020326 - Compil C++ */
										         QtyType_NotRounded, QtyType_Zero, 
										         treatRefNatFlg); /* REF3929 - SSO - 990909 */
						    }
						    else if (posNbr == 3)
						    {
                                if (GET_NUMBER(stock, ExtPos_Qty) >= 0)
                                {
                                    switch(GET_ENUM(flowPtr, Flow_RoundRuleEn))
                                    {
                                    case RndRule_Nearest: /* suppose will be down, if not FIN_GenExtOpExchFlow change op */
                                    case RndRule_Down:
                                        objectOperation = SellOpEnt;
                                        SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);
                                        break;
                                    case RndRule_Up:
                                        objectOperation = BuyOpEnt;
                                        SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);
                                        break;
                                    default: /* REF3929 - SSO - 990909  "none" case! */
                                        dontCreateOp = TRUE;
                                        break;
                                    }
                                }
                                else
                                {
                                    switch(GET_ENUM(flowPtr, Flow_RoundRuleEn))
                                    {
                                    case RndRule_Nearest: /* suppose will be down, if not FIN_GenExtOpExchFlow change op */
                                    case RndRule_Down:
                                        objectOperation = BuyOpEnt;
                                        SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);
                                        break;
                                    case RndRule_Up:
                                        objectOperation = SellOpEnt;
                                        SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);
                                        break;
                                    default: /* REF3929 - SSO - 990909  "none" case! */
                                        dontCreateOp = TRUE;
                                        break;
                                    }
                                }

						        if (dontCreateOp == FALSE) /* REF3929 - SSO - 990909  "none" case! */
						        {
							        ret = FIN_GenExtOpExchFlow(stock, flowPtr, extOperation, 
										           &instrPtr, hierHead, 
										           scptFlagTabExtOp, TRUE, 
										           (RNDRULE_ENUM) GET_ENUM(flowPtr, Flow_RoundRuleEn), /* REF7264 - DDV - 020326 - Compil C++ */
										           QtyType_Remain, QtyType_Zero, 
										            treatRefNatFlg); /* REF3929 - SSO - 990909 */

							        switch(GET_ENUM(extOperation, ExtOp_NatureEn))
							        { 
							        case OpNat_Sell:
							            objectOperation = SellOpEnt;
							            break;
							        case OpNat_Buy:
							            objectOperation = BuyOpEnt;
							            break;
                                    case OpNat_None: /* REF7479 - YST - 020409 */
							            dontCreateOp = TRUE; 
							            break;
							        }
						        }
						    }
						    break;
					    case OddLotComp_CashCompensationOld:
					     /* three operations, one ajustment of old instrument 
						     and one buy or sell of old instrument for cash compensation
						     and one buy or sell of new instrument */ 

                             /* PMSTA-36275 - SANAND - 220719 -
                             If Instrument Nature is ConvertBond, Exchange Nature is Conversion, only one
                             Adjustment needs to be created */
                            posNbrToCreate = (TRUE == convBondToExch) ? 1 : 3;

						    if (posNbr == 1)
						    {
						        objectOperation = AdjustOpEnt;
						        SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Adjust);

						        ret = FIN_GenExtOpExchFlow(stock, flowPtr, extOperation, 
										     &instrPtr, hierHead, 
										     scptFlagTabExtOp, newInstrFlg, /* PMSTA-36275 - SANAND - 220719 - New Intrument creation*/
										     (RNDRULE_ENUM) GET_ENUM(flowPtr, Flow_RoundRuleEn),/* REF7264 - DDV - 020326 - Compil C++ */
			    						     QtyType_Rounded, QtyType_Zero, 
										    treatRefNatFlg); /* REF3929 - SSO - 990909 */
						    }
						    else if (posNbr == 2)
						    {

						        if (GET_NUMBER(stock, ExtPos_Qty) >= 0)
						        {
							        objectOperation = BuyOpEnt;
							        SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);
						        }
						        else
						        {
							        objectOperation = SellOpEnt;
							        SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);
						        }

						        ret = FIN_GenExtOpExchFlow(stock, flowPtr, extOperation, 
										         &instrPtr, hierHead, 
										         scptFlagTabExtOp, TRUE, 
										         (RNDRULE_ENUM) GET_ENUM(flowPtr, Flow_RoundRuleEn), /* REF7264 - DDV - 020326 - Compil C++ */
										         QtyType_Rounded, QtyType_Zero, 
										         treatRefNatFlg); /* REF3929 - SSO - 990909 */
						    }
						    else if (posNbr == 3)
						    {
                                if (GET_NUMBER(stock, ExtPos_Qty) >= 0)
                                {
                                    switch(GET_ENUM(flowPtr, Flow_RoundRuleEn))
                                    {
                                    case RndRule_Nearest: /* suppose will be down, if not FIN_GenExtOpExchFlow change op */
                                    case RndRule_Down:
                                        objectOperation = SellOpEnt;
                                        SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);
                                        break;
                                    case RndRule_Up:
                                        objectOperation = BuyOpEnt;
                                        SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);
                                        break;
                                    default: /* REF3929 - SSO - 990909  "none" case! */
                                        dontCreateOp = TRUE;
                                        break;
                                    }
                                }
                                else
                                {
                                    switch(GET_ENUM(flowPtr, Flow_RoundRuleEn))
                                    {
                                    case RndRule_Nearest: /* suppose will be down, if not FIN_GenExtOpExchFlow change op */
                                    case RndRule_Down:
                                        objectOperation = BuyOpEnt;
                                        SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);
                                        break;
                                    case RndRule_Up:
                                        objectOperation = SellOpEnt;
                                        SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);
                                        break;
                                    default: /* REF3929 - SSO - 990909  "none" case! */
                                        dontCreateOp = TRUE;
                                        break;
                                    }
                                }

						        if (dontCreateOp == FALSE) /* REF3929 - SSO - 990909  "none" case! */
						        {
							        ret = FIN_GenExtOpExchFlow(stock, flowPtr, extOperation, 
										           &instrPtr, hierHead, 
										           scptFlagTabExtOp, FALSE, 
										           (RNDRULE_ENUM) GET_ENUM(flowPtr, Flow_RoundRuleEn), /* REF7264 - DDV - 020326 - Compil C++ */
										           QtyType_Remain, QtyType_Zero, 
										            treatRefNatFlg); /* REF3929 - SSO - 990909 */

							        switch(GET_ENUM(extOperation, ExtOp_NatureEn))
							        {
							        case OpNat_Sell:
							            objectOperation = SellOpEnt;
							            break;
							        case OpNat_Buy:
							            objectOperation = BuyOpEnt;
							            break;
                                    case OpNat_None: /* REF7479 - YST - 020409 */
							            dontCreateOp = TRUE; 
							            break;
							        }
						        }

					        }
					        break;
                        }
                    }
                    break;

			    case EvtPlRule_Instrument:

                    /* REF3089 - 990607 - DDV - All cases rewrite */
                    switch(GET_ENUM(flowPtr, Flow_OddLotCompEn))
                    {
                    case OddLotComp_Kept:
                        /* Two operations of buy or sell of new instrument */
                        posNbrToCreate = 2;

                        if (GET_ENUM(flowPtr, Flow_RoundRuleEn) != RndRule_None)
                            roundRule = RndRule_Down;
                        else
                            roundRule = RndRule_None;

                        if (posNbr == 1)
                        {
						    if (GET_NUMBER(stock, ExtPos_Qty) >= 0)
						    {
						       objectOperation = BuyOpEnt;
						       SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);
						    }
						    else
						    {
						       objectOperation = SellOpEnt;
						       SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);
						    }
						    ret = FIN_GenExtOpExchFlow(stock, flowPtr, extOperation, 
									       &instrPtr, hierHead, 
									       scptFlagTabExtOp, TRUE, 
									       roundRule, QtyType_Rounded, 
									       QtyType_Zero, 
									        treatRefNatFlg); /* REF3929 - SSO - 990909 */
					    }
					    else if (posNbr == 2)
					    {
						    if (GET_NUMBER(stock, ExtPos_Qty) >= 0)
						    {
						       objectOperation = SellOpEnt;
						       SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);
						    }
						    else
						    { 
						       objectOperation = BuyOpEnt;
						       SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);
						    }

						    ret = FIN_GenExtOpExchFlow(stock, flowPtr, extOperation, 
									       &instrPtr, hierHead, 
									       scptFlagTabExtOp, FALSE, 
									       roundRule, QtyType_Rounded, 
									       QtyType_Zero, 
									        treatRefNatFlg); /* REF3929 - SSO - 990909 */
					    }
					    break;
                    case OddLotComp_Lost:
					    /* Two operations of buy or sell of new instrument */
					    posNbrToCreate = 2;
					    if (posNbr == 1)
					    {
						    if (GET_NUMBER(stock, ExtPos_Qty) >= 0)
						    {
						       objectOperation = BuyOpEnt;
						       SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);
						    }
						    else
						    {
						       objectOperation = SellOpEnt;
						       SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);
						    }
						    ret = FIN_GenExtOpExchFlow(stock, flowPtr, extOperation, 
									       &instrPtr, hierHead, 
									       scptFlagTabExtOp, TRUE, 
									       (RNDRULE_ENUM) GET_ENUM(flowPtr, Flow_RoundRuleEn), /* REF7264 - DDV - 020326 - Compil C++ */
									       QtyType_Rounded, QtyType_Zero, 
									        treatRefNatFlg); /* REF3929 - SSO - 990909 */
					    }
					    else if (posNbr == 2)
					    {
						    if (GET_NUMBER(stock, ExtPos_Qty) >= 0)
						    {
						       objectOperation = SellOpEnt;
						       SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);
						    }
						    else
						    { 
						       objectOperation = BuyOpEnt;
						       SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);
						    }

						    ret = FIN_GenExtOpExchFlow(stock, flowPtr, extOperation, 
									       &instrPtr, hierHead, 
									       scptFlagTabExtOp, FALSE, 
									       RndRule_None, QtyType_NotRounded, 
									       QtyType_Zero, 
									        treatRefNatFlg); /* REF3929 - SSO - 990909 */
                        }
                        break;
                    case OddLotComp_CashCompensationNew:
					    /* two operations, one buy or sell of new instrument, 
					     and one other for cash compensation */ 
					    if(GET_ENUM(flowPtr, Flow_RoundRuleEn) != RndRule_None)
						    posNbrToCreate = 3;
					    else
						    posNbrToCreate = 2;

                        if (posNbr == 1)
                        {
						    if (GET_NUMBER(stock, ExtPos_Qty) >= 0)
						    {
						       objectOperation = BuyOpEnt;
						       SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);
						    }
						    else
						    {
						       objectOperation = SellOpEnt;
						       SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);
						    }
						    ret = FIN_GenExtOpExchFlow(stock, flowPtr, extOperation, 
									       &instrPtr, hierHead, 
									       scptFlagTabExtOp, TRUE, 
									       RndRule_None, QtyType_NotRounded, 
									       QtyType_Zero, 
									        treatRefNatFlg); /* REF3929 - SSO - 990909 */
					    }
					    else if (posNbr == 2)
					    {
						    if (GET_NUMBER(stock, ExtPos_Qty) >= 0)
						    {
						       objectOperation = SellOpEnt;
						       SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);
						    }
						    else
						    {
						       objectOperation = BuyOpEnt;
						       SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);
						    }
						    ret = FIN_GenExtOpExchFlow(stock, flowPtr, extOperation, 
									       &instrPtr, hierHead, 
									       scptFlagTabExtOp, FALSE, 
									       RndRule_None, QtyType_NotRounded, 
									       QtyType_Zero, 
									        treatRefNatFlg); /* REF3929 - SSO - 990909 */
					    }
					    else if (posNbr == 3)
					    {
						    if (GET_NUMBER(stock, ExtPos_Qty) >= 0)
						    {
                                switch(GET_ENUM(flowPtr, Flow_RoundRuleEn))
                                {
                                case RndRule_Nearest: /* suppose will be down, if not FIN_GenExtOpExchFlow change op */
                                case RndRule_Down:
                                    objectOperation = SellOpEnt;
                                    SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);
                                    break;
                                case RndRule_Up:
                                    objectOperation = BuyOpEnt;
                                    SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);
                                    break;
                                default: /* REF3929 - SSO - 990909  "none" case! */
                                    dontCreateOp = TRUE;
                                    break;
                                }
						    }
						    else
						    {
                                switch(GET_ENUM(flowPtr, Flow_RoundRuleEn))
                                {
                                case RndRule_Nearest: /* suppose will be down, if not FIN_GenExtOpExchFlow change op */
                                case RndRule_Down:
                                    objectOperation = BuyOpEnt;
                                    SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);
                                    break;
                                case RndRule_Up:
                                    objectOperation = SellOpEnt;
                                    SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);
                                    break;
                                default: /* REF3929 - SSO - 990909  "none" case! */
                                    dontCreateOp = TRUE;
                                    break;
                                }
						    }

						    if (dontCreateOp == FALSE) /* REF3929 - SSO - 990909  "none" case! */
						    {
						        ret = FIN_GenExtOpExchFlow(stock, flowPtr, extOperation, 
									           &instrPtr, hierHead, 
									           scptFlagTabExtOp, TRUE, 
									           (RNDRULE_ENUM) GET_ENUM(flowPtr, Flow_RoundRuleEn), /* REF7264 - DDV - 020326 - Compil C++ */
									           QtyType_Remain, QtyType_Zero, 
										    treatRefNatFlg); /* REF3929 - SSO - 990909 */

						        switch(GET_ENUM(extOperation, ExtOp_NatureEn))
						        {
						        case OpNat_Sell:
							        objectOperation = SellOpEnt;
							        break;
						        case OpNat_Buy:
							        objectOperation = BuyOpEnt;
							        break;
						        }
						    }

                        }
                        break;
                    case OddLotComp_CashCompensationOld:
					      /* two operations, one buy or sell of new instrument, 
					     and one other for cash compensation */ 
					    if(GET_ENUM(flowPtr, Flow_RoundRuleEn) != RndRule_None)
						    posNbrToCreate = 3;
					    else
						    posNbrToCreate = 2;

					    if (posNbr == 1)
					    {
						    if (GET_NUMBER(stock, ExtPos_Qty) >= 0)
						    {
						       objectOperation = BuyOpEnt;
						       SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);
						    }
						    else
						    {
						       objectOperation = SellOpEnt;
						       SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);
						    }
						    ret = FIN_GenExtOpExchFlow(stock, flowPtr, extOperation, 
									       &instrPtr, hierHead, 
									       scptFlagTabExtOp, TRUE, 
									       (RNDRULE_ENUM) GET_ENUM(flowPtr, Flow_RoundRuleEn), /* REF7264 - DDV - 020326 - Compil C++ */
									       QtyType_Rounded, 
									       QtyType_Zero, 
									        treatRefNatFlg); /* REF3929 - SSO - 990909 */
					    }
					    else if (posNbr == 2)
					    {
						    if (GET_NUMBER(stock, ExtPos_Qty) >= 0)
						    {
						       objectOperation = SellOpEnt;
						       SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);
						    }
						    else
						    {
						       objectOperation = BuyOpEnt;
						       SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);
						    }
						    ret = FIN_GenExtOpExchFlow(stock, flowPtr, extOperation, 
									       &instrPtr, hierHead, 
									       scptFlagTabExtOp, FALSE, 
									       (RNDRULE_ENUM) GET_ENUM(flowPtr, Flow_RoundRuleEn), /* REF7264 - DDV - 020326 - Compil C++ */
									       QtyType_Rounded, 
									       QtyType_Zero, 
									        treatRefNatFlg); /* REF3929 - SSO - 990909 */
					    }
					    else if (posNbr == 3)
					    {
						    if (GET_NUMBER(stock, ExtPos_Qty) >= 0)
						    {
                                switch(GET_ENUM(flowPtr, Flow_RoundRuleEn))
                                {
                                case RndRule_Nearest: /* suppose will be down, if not FIN_GenExtOpExchFlow change op */
                                case RndRule_Down:
                                    objectOperation = SellOpEnt;
                                    SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);
                                    break;
                                case RndRule_Up:
                                    objectOperation = BuyOpEnt;
                                    SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);
                                    break;
                                default: /* REF3929 - SSO - 990909  "none" case! */
                                    dontCreateOp = TRUE;
                                    break;
                                }
                            }
                            else
                            {
                                switch(GET_ENUM(flowPtr, Flow_RoundRuleEn))
                                {
                                case RndRule_Nearest: /* suppose will be down, if not FIN_GenExtOpExchFlow change op */
                                case RndRule_Down:
                                    objectOperation = BuyOpEnt;
                                    SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);
                                    break;
                                case RndRule_Up:
                                    objectOperation = SellOpEnt;
                                    SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);
                                    break;
                                default: /* REF3929 - SSO - 990909  "none" case! */
                                    dontCreateOp = TRUE;
                                    break;
                                }
                            }

						    if (dontCreateOp == FALSE) /* REF3929 - SSO - 990909  "none" case! */
						    {
						        ret = FIN_GenExtOpExchFlow(stock, flowPtr, extOperation, 
									           &instrPtr, hierHead, 
									           scptFlagTabExtOp, FALSE, 
									           (RNDRULE_ENUM) GET_ENUM(flowPtr, Flow_RoundRuleEn), /* REF7264 - DDV - 020326 - Compil C++ */
									           QtyType_Remain, QtyType_Zero, 
										        treatRefNatFlg); /* REF3929 - SSO - 990909 */

						        switch(GET_ENUM(extOperation, ExtOp_NatureEn))
						        {
						        case OpNat_Sell:
							        objectOperation = SellOpEnt;
							        break;
						        case OpNat_Buy:
							        objectOperation = BuyOpEnt;
							        break;
						        }
						    }

                        }
                        break;
                    }
                    break;
                }
                }
	    	    else
		        {
			    switch (exchangePlRule)
			    {
				case EvtPlRule_Underlying:
				    /* One operation of adjustment or buy or sell of new instrument */

				    switch(GET_ENUM(flowPtr, Flow_OddLotCompEn))
				    {
					case OddLotComp_Kept: /* no sense */
					case OddLotComp_Lost:
					    posNbrToCreate = 1;
					    if (GET_PRICE(flowPtr, Flow_AmtUnit) == 0)
					    {
						    objectOperation = AdjustOpEnt;
						    SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Adjust);
					    }
					    else if (GET_NUMBER(stock, ExtPos_Qty) >= 0)
					    {
						    objectOperation = BuyOpEnt;
						    SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);
					    }
					    else
					    {
						    objectOperation = SellOpEnt;
						    SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);
					    }
					    ret = FIN_GenExtOpExchFlow(stock, flowPtr, extOperation, 
									 &instrPtr, hierHead, 
									 scptFlagTabExtOp, TRUE, 
									 (RNDRULE_ENUM) GET_ENUM(flowPtr, Flow_RoundRuleEn), /* REF7264 - DDV - 020326 - Compil C++ */
									 QtyType_Rounded, QtyType_Zero, 
									treatRefNatFlg); /* REF3929 - SSO - 990909 */

					    break;

					case OddLotComp_CashCompensationNew:
					    if(GET_ENUM(flowPtr, Flow_RoundRuleEn) != RndRule_None)
						    posNbrToCreate = 2;
					    else
						    posNbrToCreate = 1;

					    if (posNbr == 1)
					    {
						    if (GET_PRICE(flowPtr, Flow_AmtUnit) == 0)
						    {
						        objectOperation = AdjustOpEnt;
						        SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Adjust);
						    }
						    else if (GET_NUMBER(stock, ExtPos_Qty) >= 0)
						    {
						        objectOperation = BuyOpEnt;
						        SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);
						    }
						    else
						    {
						        objectOperation = SellOpEnt;
						        SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);
						    }
						    ret = FIN_GenExtOpExchFlow(stock, flowPtr, extOperation, 
									           &instrPtr, hierHead, 
									           scptFlagTabExtOp, TRUE, 
									           RndRule_None, QtyType_NotRounded, QtyType_Zero, 
									            treatRefNatFlg); /* REF3929 - SSO - 990909 */
					    }
					    else if (posNbr == 2)
					    {
                            if (GET_NUMBER(stock, ExtPos_Qty) >= 0)
                            {
                                switch(GET_ENUM(flowPtr, Flow_RoundRuleEn))
                                {
                                case RndRule_Nearest: /* suppose will be down, if not FIN_GenExtOpExchFlow change op */
                                case RndRule_Down:
                                    objectOperation = SellOpEnt;
                                    SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);
                                    break;
                                case RndRule_Up:
                                    objectOperation = BuyOpEnt;
                                    SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);
                                    break;
                                default: /* REF3929 - SSO - 990909  "none" case! */
                                    dontCreateOp = TRUE;
                                    break;
                                }
                            }
                            else
                            {
                                switch(GET_ENUM(flowPtr, Flow_RoundRuleEn))
                                {
                                case RndRule_Nearest: /* suppose will be down, if not FIN_GenExtOpExchFlow change op */
                                case RndRule_Down:
                                    objectOperation = BuyOpEnt;
                                    SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);
                                    break;
                                case RndRule_Up:
                                    objectOperation = SellOpEnt;
                                    SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);
                                    break;
                                default: /* REF3929 - SSO - 990909  "none" case! */
                                    dontCreateOp = TRUE;
                                    break;
                                }
                            }

						    if (dontCreateOp == FALSE) /* REF3929 - SSO - 990909  "none" case! */
						    {
						        ret = FIN_GenExtOpExchFlow(stock, flowPtr, extOperation, 
									           &instrPtr, hierHead, 
									           scptFlagTabExtOp, TRUE, 
									           (RNDRULE_ENUM) GET_ENUM(flowPtr, Flow_RoundRuleEn), /* REF7264 - DDV - 020326 - Compil C++ */
									           QtyType_Remain, QtyType_Zero, 
										        treatRefNatFlg); /* REF3929 - SSO - 990909 */

						        switch(GET_ENUM(extOperation, ExtOp_NatureEn))
						        {
						        case OpNat_Sell:
							        objectOperation = SellOpEnt;
							        break;
						        case OpNat_Buy:
							        objectOperation = BuyOpEnt;
							        break;
						        }
						    }

                        }
                        break;
                    }
                    break;

                case EvtPlRule_Instrument:
				    switch(GET_ENUM(flowPtr, Flow_OddLotCompEn))
				    {
				    case OddLotComp_Kept: /* no sense */
				    case OddLotComp_Lost:
					    /* One operation buy or sell of new instrument */
					    posNbrToCreate = 1;
					    if (GET_NUMBER(stock, ExtPos_Qty) >= 0)
					    {
					        objectOperation = BuyOpEnt;
					        SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);
					    }
					    else
					    {
					        objectOperation = SellOpEnt;
					        SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);
					    }
					    ret = FIN_GenExtOpExchFlow(stock, flowPtr, extOperation, 
								     &instrPtr, hierHead, 
								     scptFlagTabExtOp, TRUE, 
								     (RNDRULE_ENUM) GET_ENUM(flowPtr, Flow_RoundRuleEn), /* REF7264 - DDV - 020326 - Compil C++ */
								     QtyType_Rounded, QtyType_Zero, 
									    treatRefNatFlg); /* REF3929 - SSO - 990909 */
					    break;
				    case OddLotComp_CashCompensationNew:
					  /* two operations, one buy or sell of new instrument, 
					 and one other for cash compensation */ 
					    if(GET_ENUM(flowPtr, Flow_RoundRuleEn) != RndRule_None)
					        posNbrToCreate = 2;
					    else
					        posNbrToCreate = 1;

					    if (posNbr == 1)
					    {
					        if (GET_NUMBER(stock, ExtPos_Qty) >= 0)
					        {
					           objectOperation = BuyOpEnt;
					           SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);
					        }
					        else
					        {
					           objectOperation = SellOpEnt;
					           SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);
					        }
					        ret = FIN_GenExtOpExchFlow(stock, flowPtr, extOperation, 
								           &instrPtr, hierHead, 
								           scptFlagTabExtOp, TRUE, 
								           RndRule_None, QtyType_NotRounded, QtyType_Zero, 
									        treatRefNatFlg); /* REF3929 - SSO - 990909 */
					    }
					    else if (posNbr == 2)
					    {
                            if (GET_NUMBER(stock, ExtPos_Qty) >= 0)
                            {
                                switch(GET_ENUM(flowPtr, Flow_RoundRuleEn))
                                {
                                case RndRule_Nearest: /* suppose will be down, if not FIN_GenExtOpExchFlow change op */
                                case RndRule_Down:
                                    objectOperation = SellOpEnt;
                                    SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);
                                    break;
                                case RndRule_Up:
                                    objectOperation = BuyOpEnt;
                                    SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);
                                    break;
                                default: /* REF3929 - SSO - 990909  "none" case! */
                                    dontCreateOp = TRUE;
                                    break;
                                }
                            }
                            else
                            {
                                switch(GET_ENUM(flowPtr, Flow_RoundRuleEn))
                                {
                                case RndRule_Nearest: /* suppose will be down, if not FIN_GenExtOpExchFlow change op */
                                case RndRule_Down:
                                    objectOperation = BuyOpEnt;
                                    SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);
                                    break;
                                case RndRule_Up:
                                    objectOperation = SellOpEnt;
                                    SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);
                                    break;
                                default: /* REF3929 - SSO - 990909  "none" case! */
                                    dontCreateOp = TRUE;
                                    break;
                                }
                            }

					        if (dontCreateOp == FALSE) /* REF3929 - SSO - 990909  "none" case! */
					        {
						        ret = FIN_GenExtOpExchFlow(stock, flowPtr, extOperation, 
									       &instrPtr, hierHead, 
									       scptFlagTabExtOp, TRUE, 
									       (RNDRULE_ENUM) GET_ENUM(flowPtr, Flow_RoundRuleEn), /* REF7264 - DDV - 020326 - Compil C++ */
									       QtyType_Remain, QtyType_Zero, 
    									    treatRefNatFlg); /* REF3929 - SSO - 990909 */

						        switch(GET_ENUM(extOperation, ExtOp_NatureEn))
						        {
						        case OpNat_Sell:
							        objectOperation = SellOpEnt;
							        break;
						        case OpNat_Buy:
							        objectOperation = BuyOpEnt;
							        break;
						        }
					        }

                        }
                        break;
                    }
                    break;
                }
                }
                break;
		    case EuroConvRule_BottomUpOneCent:
		    case EuroConvRule_TopDownOneCent:
		    case EuroConvRule_TopDownMinLot:
		    case EuroConvRule_BottomUpOneEuroLost:    /* REF2957 - DDV - 981103 */
		    case EuroConvRule_BottomUpMinDenomOneCent: /* REF6187 - DDV - 010810 */
			/* Only one adjustment operation */

			    posNbrToCreate = 1;
			    objectOperation = AdjustOpEnt;
			    SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Adjust);
			    ret = FIN_GenExtOpExchFlow(stock, flowPtr, extOperation, 
						       &instrPtr, hierHead, 
						       scptFlagTabExtOp, newInstrFlg, RndRule_None,  /* PMSTA-36275 - SANAND - 220719 - New Intrument creation */
						       QtyType_NotRounded, QtyType_Zero, 
						    treatRefNatFlg); /* REF3929 - SSO - 990909 */
			    break;

		    case EuroConvRule_TopDownOneEuro:
		    case EuroConvRule_TopDownMinDenom:
		    case EuroConvRule_BottomUpMinDenomOneEuro:     /* REF6187 - DDV - 010810 */
		    case EuroConvRule_BottomUpHolding25Cents: /* REF6187 - DDV - 010810 */
			    /* two operation one adjustment and one sell */
			    posNbrToCreate = 2;
			    if (posNbr == 1)
			    {
			       objectOperation = AdjustOpEnt;
			       SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Adjust);
			       ret = FIN_GenExtOpExchFlow(stock, flowPtr, extOperation, 
						      &instrPtr, hierHead, 
						      scptFlagTabExtOp, newInstrFlg, RndRule_None,  /* PMSTA-36275 - SANAND - 220719 - New Intrument creation */
						      QtyType_NotRounded, QtyType_Zero, 
							    treatRefNatFlg); /* REF3929 - SSO - 990909 */
			    }
			    else if (posNbr == 2)
			    {
			       objectOperation = SellOpEnt;
			       SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);
			       ret = FIN_GenExtOpExchFlow(stock, flowPtr, extOperation, 
						      &instrPtr, hierHead, 
						      scptFlagTabExtOp, TRUE, RndRule_None, 
						      QtyType_NotRounded, QtyType_Remain, 
							    treatRefNatFlg); /* REF3929 - SSO - 990909 */
			    }
			    break;
		    case EuroConvRule_BottomUpOneEuro:
		    case EuroConvRule_BottomUpMinDenom:
		    /*case EuroConvRule_TopDownOneEuro:
		    case EuroConvRule_TopDownMinDenom: REF6131 - DDV - 010806 */
			    /* two operation one adjustment and one sell */
			    posNbrToCreate = 2;
			    if (posNbr == 1)
			    {
			       objectOperation = AdjustOpEnt;
			       SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Adjust);
			       ret = FIN_GenExtOpExchFlow(stock, flowPtr, extOperation, 
						      &instrPtr, hierHead, 
						      scptFlagTabExtOp, newInstrFlg, RndRule_None,  /* PMSTA-36275 - SANAND - 220719 - New Intrument creation */
						      QtyType_NotRounded, QtyType_Zero, 
							    treatRefNatFlg); /* REF3929 - SSO - 990909 */
			    }
			    else if (posNbr == 2)
			    {
			       objectOperation = SellOpEnt;
			       SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);
			       ret = FIN_GenExtOpExchFlow(stock, flowPtr, extOperation, 
						      &instrPtr, hierHead, 
						      scptFlagTabExtOp, TRUE, RndRule_None, 
						      QtyType_NotRounded, QtyType_Zero, 
							    treatRefNatFlg); /* REF3929 - SSO - 990909 */
			    }
			    break;
        
		    }
		    /* ----------------------------------------------------------------------- */
		    /* REF4441 - AKO - 000329						       */
		    /* create a second cash operation after the first cash op. of prop. attrib */
		    /* ----------------------------------------------------------------------- */
		    if (    (GET_ENUM(extOperation, ExtOp_NatureEn)==OpNat_Adjust) &&
			    (FlowSubNat_PropAttrib==(FLOWSUBNAT_ENUM)GET_ENUM(flowPtr, Flow_SubNatEn)) &&
			    (PropAttribRule_NewCash==(PROPATTRIBRULE_ENUM)propAttribRule) &&
			    (InstrNat_CashAcct==(INSTRNAT_ENUM)GET_ENUM(instrPtr, A_Instr_NatEn))
		    )
		    {
		        toGenerateOpPropAttribCashFlg=TRUE;
		    
		        if (IS_NULLFLD(extOperation, ExtOp_Qty)!=TRUE)
		        {
			        cashAmt = GET_NUMBER(extOperation, ExtOp_Qty);
		        }
		        posNbrToCreate++;

		    }	/* end secondcash amount treatment */
		    }
	    
            if (ret != RET_SUCCEED)
	        {
                FREE_DYNST(extOperation, ExtOp);
                FREE(scptFlagTabExtOp);
                return(ret);
	        }
            break;
            
        case FlowNat_Term :

            ret = FIN_GenExtOpTermFlow(stock, flowPtr, extOperation,
                                       &instrPtr, hierHead, fromDateTime, scptFlagTabExtOp, 
                                       posNbr, &posNbrToCreate, optionExercisePlRule, 
                                       futuresSettlPlRule, &objectOperation, &dontCreateOp);

			/* PMSTA00689 - TGU - 061219 - Use DV to compute Operation and accounting date */
            if (GET_ENUM(instrPtr,  A_Instr_NatEn) == InstrNat_Forward) 
            {
                scptFlagTabExtOp[ExtOp_AcctDate]=FALSE;
                scptFlagTabExtOp[ExtOp_OpDate]=FALSE;
            }

            if (ret != RET_SUCCEED)
	        {
                FREE_DYNST(extOperation, ExtOp);
                FREE(scptFlagTabExtOp);
                return(ret);
	        }
            break;

        default :
            FREE_DYNST(extOperation, ExtOp);
            FREE(scptFlagTabExtOp);
        
            MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
                         "FIN_GeneratePosition", 
                         GET_CODE(instrPtr, A_Instr_Cd), "event category");
            return(RET_FIN_ERR_INVDATA);

        } /* end switch flow nature */
        
        /* REF2270 - 980604 - DDV - Check moved after default value 
        if (dontCreateOp == TRUE  ||
            FIN_CheckExistPos(extractFlowPos, 
                              extractFlowPosNbr, 
                              extOperation)==TRUE)
        */
		/*PMSTA-18355 - SHR - 140807*/
		if (GET_ID(posInstrPtr, A_Instr_Id) < 0)
		instrId = GET_ID(posInstrPtr, A_Instr_ParentInstrId);
		else
		instrId = GET_ID(posInstrPtr, A_Instr_Id); 
		
		if((PosRefNat_ReferenceCode == GET_POSREFNAT(stock, ExtPos_RefNatEn)) && instrId == GET_ID(extOperation, ExtOp_InstrId))
		{
			COPY_DYNFLD(extOperation, ExtOp, ExtOp_RefOpCd ,  stock ,  ExtPos, ExtPos_RefOpCd); 
			COPY_DYNFLD(extOperation, ExtOp, ExtOp_RefNatEn, stock, ExtPos, ExtPos_RefNatEn);
			scptFlagTabExtOp[ExtOp_RefOpCd]=TRUE;
			scptFlagTabExtOp[ExtOp_RefNatEn]=TRUE;
		}


        if (dontCreateOp == TRUE)
	    {
            FREE_DYNST(extOperation, ExtOp);
            FREE(scptFlagTabExtOp);
            continue;
	    }

	    if (!dfltTpId)
		    scptFlagTabExtOp[ExtOp_TpId] = FALSE;
	    else
            SET_ID(extOperation,          ExtOp_TpId, dfltTpId);
        
        if ((objectOperation==NullEntity) || ((operation = ALLOC_DYNST(GET_EDITGUIST(objectOperation))) == NULL))
        {   /* REF1055 - AKO - 991201 : gerer le cas oï¿½ nullEntity sinon boom! */
            FREE_DYNST(extOperation, ExtOp);
            FREE(scptFlagTabExtOp);
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

	    /* REF2807, added connection info. */
        OPE_ExtOpToOp(extOperation, operation, hierHead,FALSE);        /*  FPL-REF9215-030811  */
        
        if ((scptFlagTabOp = (FLAG_T *) CALLOC(GET_FLD_NBR(ExtOp),sizeof(FLAG_T))) == NULL) /* REF7264 - DDV - 020326 - Compil C++ */
        {
            FREE_DYNST(operation, GET_EDITGUIST(objectOperation));
            FREE_DYNST(extOperation, ExtOp);
            FREE(scptFlagTabExtOp);
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }
        
        OPE_ExtFlToFl(scptFlagTabExtOp, scptFlagTabOp, (OPNAT_ENUM) GET_ENUM(extOperation, ExtOp_NatureEn), TRUE); /* REF7264 - DDV - 020326 - Compil C++ */
        /* FREE(scptFlagTabExtOp); REF3740 - AKO - 990708 - Moved after theoritical price treatment */
        
        /* Compute Default Values */
        SCPT_ComputeDV(objectOperation, scptFlagTabOp, operation, TRUE, TRUE, NULL); /* REF4229 - SSO - 000919 */
        
        FREE(scptFlagTabOp);
        
        if (OPE_OpToExtOp(operation, (OPNAT_ENUM) GET_ENUM(extOperation, ExtOp_NatureEn), extOperation, FALSE) != RET_SUCCEED)  /*  FPL-REF9215-030811  Add Flag Impact */ /* REF7264 - DDV - 020326 - Compil C++ */
        {
            FREE_DYNST(operation, GET_EDITGUIST(objectOperation));
            FREE_DYNST(extOperation, ExtOp);
            return(RET_GEN_ERR_INVARG);
        }

	    SET_ENUM(extOperation, ExtOp_DbStatusEn, ExtOpDbStatus_ToInsert);        

	    /* -------------------------------- */	    
	    /*  BBL project : corporate actions */	    /* REF3740 - AKO - 990628 */
	    /*  Theorical calculation price     */	
	    /* -------------------------------- */
	    if ((FlowNat_Exch == GET_ENUM(flowPtr, Flow_NatEn)) &&
	        (GET_FLAG(flowPtr, Flow_ReplaceFlg) == FALSE) &&
	        (OpNat_Adjust == GET_ENUM(extOperation, ExtOp_NatureEn)) &&
	        ((FlowSubNat_AttribTheoPrice == GET_ENUM(flowPtr, Flow_SubNatEn)) ||
	         (FlowSubNat_PropAttrib == GET_ENUM(flowPtr, Flow_SubNatEn))) &&
	         (TRUE == IS_NULLFLD(extOperation, ExtOp_Price)))
	    {
	        PRICE_T  theoPrice=ZERO_PRICE;

	        if (FIN_ComputeTheoPrice(GET_ID(stock, ExtPos_InstrId),
				         GET_ID(instrPtr, A_Instr_Id),  /* instrPtr contain flow.newinstr  */
				         instrPtr,	/* (done in FIN_GenExtOpExchFlows) */
						 stock,		/* PMSTA01649 - TGU - 070405 */
				         GET_DATETIME(extOperation, ExtOp_AcctDate), /* Flow_OptimalDate */
				         hierHead,					 /* OR ExchEvt_EndDate */
				         (FLAG_T)(FlowSubNat_PropAttrib == GET_ENUM(flowPtr, Flow_SubNatEn)),
				         GET_NUMBER(flowPtr, Flow_RefQty),   /* QOR : reference qty */
				         GET_NUMBER(flowPtr, Flow_QtyUnit),  /* QOI : qty of new instr. */
				         GET_ID(flowPtr, Flow_AmtCurrId),
				         (EVTDATERULE_ENUM) GET_ENUM(domainPtr, A_Domain_EvtDateRuleEn),  /* REF7264 - DDV - 020326 - Compil C++ */ /* REF4075 - CSY - 991208 A_Domain_PosValRuleEn 
                                                                        (temporarily used for tests) replaced 
                                                                        with A_Domain_EvtDateRuleEn*/
				        &theoPrice) == RET_SUCCEED)
	        {
		    if (CMP_PRICE(theoPrice , 0.0) != 0)
		    {
		        NUMBER_T    quoteCalc=0.0;

		        /* reset flag tab for script */
		        for (i=0; i<GET_FLD_NBR(ExtOp) ;i++)
               		    scptFlagTabExtOp[i]=FALSE;

		        SET_PRICE(extOperation, ExtOp_Price, (PRICE_T)theoPrice);
		        /* set flag for price */
		        scptFlagTabExtOp[ExtOp_Price]=TRUE;

		        /* calculate quote */
		        FIN_PriceToQuote((PRICECALCRULE_ENUM) GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn), /* REF7264 - DDV - 020326 - Compil C++ */
				         GET_ID(instrPtr, A_Instr_Id), 
				         instrPtr,
				         fromDateTime, 
				         NULL, 
				         theoPrice,
				         &quoteCalc,
				         hierHead);
		        SET_PRICE(extOperation, ExtOp_Quote, quoteCalc);
		        scptFlagTabExtOp[ExtOp_Quote]=TRUE; 
		        

		        if ((operation = ALLOC_DYNST(GET_EDITGUIST(objectOperation))) == NULL)
		        {
			        FREE_DYNST(extOperation, ExtOp);
			        FREE(scptFlagTabExtOp);
			        MSG_RETURN(RET_MEM_ERR_ALLOC);
		        }

		        /* REF2807, added connection info. */
                OPE_ExtOpToOp(extOperation, operation, hierHead, FALSE);        /* FPL-REF9215-030811 */

		        if ((scptFlagTabOp = (FLAG_T *) CALLOC(GET_FLD_NBR(ExtOp),sizeof(FLAG_T))) == NULL) /* REF7264 - DDV - 020326 - Compil C++ */
		        {
			        FREE_DYNST(operation, GET_EDITGUIST(objectOperation));
			        FREE_DYNST(extOperation, ExtOp);
			        FREE(scptFlagTabExtOp);
			        MSG_RETURN(RET_MEM_ERR_ALLOC);
		        }

		        OPE_ExtFlToFl(scptFlagTabExtOp, scptFlagTabOp, (OPNAT_ENUM) GET_ENUM(extOperation, ExtOp_NatureEn), TRUE); /* REF7264 - DDV - 020326 - Compil C++ */

		        /* Compute Default Values */
		        SCPT_ComputeDV(objectOperation, scptFlagTabOp, operation, FALSE, TRUE, NULL);/* FALSE=partial update */ /* REF4229 - SSO - 000919 */

		        FREE(scptFlagTabOp);

		        if (OPE_OpToExtOp(operation, (OPNAT_ENUM) GET_ENUM(extOperation, ExtOp_NatureEn), extOperation,FALSE) != RET_SUCCEED)   /*  FPL-REF9215-030811  */ /* REF7264 - DDV - 020326 - Compil C++ */
		        {
			        FREE_DYNST(operation, GET_EDITGUIST(objectOperation));
			        FREE_DYNST(extOperation, ExtOp);
        		        FREE(scptFlagTabExtOp);
			        return(RET_GEN_ERR_INVARG);
		        }
		    }
	        }
	    }

        FREE(scptFlagTabExtOp);
	    FREE_DYNST(operation, GET_EDITGUIST(objectOperation));

        SET_FLAG(extOperation, ExtOp_ConfirmedFlg, GET_FLAG(flowPtr, Flow_ConfirmedFlg));
	    SET_ENUM(extOperation, ExtOp_DbStatusEn, ExtOpDbStatus_ToInsert); 


        { /* For nature income and no net amount, check if we generate positions */
            FLAG_T displayZeroDividend = FALSE;                                         /* PMSTA-18511 - 120814 - PMO */

            (void)GEN_GetApplInfo(ApplDisplayZeroDividendFlag, &displayZeroDividend);

		    /* REF9334 - TEB - 050809 */
		    if ( FALSE        == displayZeroDividend                    &&              /* PMSTA-18511 - 120814 - PMO */
                 FlowNat_Inc  == GET_ENUM(flowPtr, Flow_NatEn)          &&
	             OpNat_Income == GET_ENUM(extOperation, ExtOp_NatureEn) &&
	             (TRUE == IS_NULLFLD(extOperation, ExtOp_PtfNetAmt) ||
			      CMP_NUMBER(GET_NUMBER(extOperation, ExtOp_PtfNetAmt), 0.0) == 0))
		    {
			    FREE_DYNST(extOperation, ExtOp);
			    continue;
		    }
        }

	    /* ---------------------------------------------------------------------------- */
	    /* REF3740 - AKO - 000324  Set the operation status to Proportional_attribution	*/
	    /* in order to treat it later, by the function computePropAttrib		*/
	    /* ---------------------------------------------------------------------------- */
	    if ((FlowSubNat_PropAttrib == GET_ENUM(flowPtr, Flow_SubNatEn)) &&
	        (TRUE != IS_NULLFLD(extOperation, ExtOp_Price)) &&
	        (OpNat_Adjust == GET_ENUM(extOperation, ExtOp_NatureEn)))
	    {
            if ((ret = FIN_CheckExistPos(extractFlowPos, extractFlowPosNbr, extOperation,
		                                 listPtr, domainPtr, hierHead, &existPosFlg, FALSE, stock, FALSE))!=RET_SUCCEED) /* REF3939 - CSY - 991102 */
	        /* REF3939 - CSY - 000105: existPosFlg and return code management */
            {
                MSG_SendMesg(RET_FIN_ERR_CHECKFAILED, 0, FILEINFO, GET_CODE(ptfPtr, A_Ptf_Cd), 
			     GET_CODE(instrPtr, A_Instr_Cd)); 
                FREE_DYNST(extOperation, ExtOp); /* REF3939 - CSY - 000105 */
                return ret;
            }
            else
            {
		        if (existPosFlg == TRUE)
		        {
		            SET_ENUM(extOperation, ExtOp_DbStatusEn, ExtOpDbStatus_PropAttribExist); 
		        }
		        else
		        {
		            /* Then we must treat the case Flow_ReplaceFlg==TRUE for PropAttrib */ /* REF3740 - AKO - 000324 */
		            SET_ENUM(extOperation, ExtOp_DbStatusEn,ExtOpDbStatus_PropAttribCompPrice); 
		        }
            }
	    }
	    else
	    {
	        /* if op exist, we don't need  to treat it */
            if ((ret = FIN_CheckExistPos(extractFlowPos, 
                              extractFlowPosNbr, 
                              extOperation, listPtr, domainPtr, hierHead, &existPosFlg, FALSE, stock, FALSE))!=RET_SUCCEED) /* REF3939 - CSY - 991103 */
            /*REF3939 - CSY - 000105 : existPosFlg and return code management */
            {
                MSG_SendMesg(RET_FIN_ERR_CHECKFAILED, 0, FILEINFO,
                    GET_CODE(ptfPtr, A_Ptf_Cd), 
                    GET_CODE(instrPtr, A_Instr_Cd)); 
                FREE_DYNST(extOperation, ExtOp);
                return ret;
            }
            else
	        {
                if (existPosFlg == TRUE) 
                {
		            FREE_DYNST(extOperation, ExtOp);
		            continue;
                }

	        }
	    }
        
        if ((ret = FIN_AddEventExtOpInHier(extOperation, fctDictId, refCurrId, refFusDateRule, instrPtr, hierHead, flowPtr, domainPtr, ptfPtr)) != RET_SUCCEED)
        {
            return(ret);
        }
    }

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_ComputeTheoPrice
**
**  Description :   calculate thï¿½orical price of a corporate action
**		    instrument
**                 
**  Arguments   :   refInstrId		- id of parent instrument.
**		    instrId		- id of exchanged instrument
**		    inputInstrPtr	- pointer to parent instrument
**		    fromDateTime	- domain begin date
**		    hierHead		- pointer to hierachy
**		    allFlg		- compute allexc. instr or not.
**		    oldInstrMarketPrice	- parent instrument price (MarketPrice)
**		    oldInstrRefQty	- qty of the parent instrument (QOR)
**		    oldWithNewInstrQty	- qty of current instrument (QOI)
**		    srcCurrId		- source currency
**          evtDateRule     - enum used in event generation for event operation date rule (set in domain)
**		    theoPrice		- pointer to price to calculate
**  
**
**  Return      :   RET_SUCCEED
**                  RET_MEM_ERR_ALLOC
**
**  Creation	:   REF3740 - AKO - 990701
**  Modification:   REF4075 - CSY - 991027
**
*************************************************************************/
STATIC RET_CODE FIN_ComputeTheoPrice(ID_T		refInstrId, 
				     ID_T               instrId,
				     DBA_DYNFLD_STP	inputInstrPtr,
					 DBA_DYNFLD_STP  posPtr,			/* PMSTA01649 - TGU - 070405 */
				     DATETIME_T		fromDateTime,
				     DBA_HIER_HEAD_STP	hierHead,
				     FLAG_T		propAttribFlg,
				     NUMBER_T		oldInstrRefQty,
				     NUMBER_T		oldWithNewInstrQty,
				     ID_T		instrRefCurrId, /* Flow_CurrId */
				     EVTDATERULE_ENUM   evtDateRule,  /* REF4075 - CSY - 991027 */
				     PRICE_T		*theoPrice)
{
    DBA_DYNFLD_STP  *flowTab=NULL, 
		     instrPtr=NULL, pricePtr=NULL, instrZptr=NULL;
    FLAG_T	    freeInstrFlg=FALSE,  replace=FALSE, hierFlg=TRUE;
    FIN_EXCHARG_ST  exchArgSt;
	PRICE_T	    subscriptPrice = 0.0,	    /* quote_n of newNewInstrr  */
		oldInstrMarketPrice;    /* market price		*/
    NUMBER_T	    newNewInstrQty=0.0,	    /* QII : qty of new instr.  */
		    newNewRefQty=0.0,	    /* QIR : reference qty	*/
		    ctrCtSize_I=0.0, ctrCtSize_Z=0.0;
    int		    i=0, allocSz=0,flowNbr=0;
    double	    exchRate=0.0, exchRate2=0.0;
    DATETIME_T	    endDate;
    ID_T	    instrPriceMktCurrId=(ID_T)0, flowSpCurrId=(ID_T)0;

    *theoPrice=0.0;
    memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));
    if ((instrPtr=inputInstrPtr) == NULL)
    { /* verify current instrument */
        /* REF3913 - 990819 - DDV */
        if (DBA_GetInstrById(instrId, FALSE, &freeInstrFlg, 
                             &inputInstrPtr, hierHead, UNUSED, UNUSED) != RET_SUCCEED)
	{
	    return(RET_SUCCEED);
	}
	instrPtr=inputInstrPtr;
    }

    if ((InstrNat_Stock !=(INSTRNAT_ENUM)GET_ENUM(instrPtr, A_Instr_NatEn)) &&
	(InstrNat_Option != (INSTRNAT_ENUM)GET_ENUM(instrPtr, A_Instr_NatEn))) 
    {
	if(freeInstrFlg == TRUE) { FREE_DYNST(instrPtr, A_Instr);}
        MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
                     "FIN_ComputeTheoPrice", 
                     GET_CODE(instrPtr, A_Instr_Cd), "instrnat not stock, not option");
	return(RET_SUCCEED);
    }


    endDate.date = MAGIC_END_DATE;
    endDate.time = 0;

    /* load new instrument exchanged flows */
    if ((FIN_CreateExchangeFlows(instrPtr, fromDateTime, &endDate, fromDateTime, evtDateRule, /* REF4075 - CSY - 991027 */
		 &allocSz, &flowNbr, &flowTab, hierHead) != RET_SUCCEED) || (flowNbr <= 0))
    {
	if(freeInstrFlg == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
        MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
                     "FIN_ComputeTheoPrice", 
                     GET_CODE(instrPtr, A_Instr_Cd), "flow not created");
	return(RET_SUCCEED);
    }

    for (i=0, replace=FALSE; (i<flowNbr && replace==FALSE); i++)
    {
	if (GET_FLAG(flowTab[i], Flow_ReplaceFlg) == TRUE)
	    replace=TRUE;
    }
    if (i>0) i = i - 1;

    if (replace !=TRUE)
    {
	if(freeInstrFlg == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
        MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
                     "FIN_ComputeTheoPrice", 
                     GET_CODE(instrPtr, A_Instr_Cd), "unreplace instrument");
	return(RET_SUCCEED);
    }

    /* ----------------	*/
    /*  Instr_Price - Z	*/
    /* ---------------- */ 
    if ((pricePtr = ALLOC_DYNST(A_InstrPrice)) == NULL)
    {
	if(freeInstrFlg == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
	MSG_RETURN(RET_MEM_ERR_ALLOC);
    }
    if (FIN_InstrPrice(GET_ID(flowTab[i], Flow_NewInstrId), NULL, fromDateTime,
			NULL, (ID_T)0, NULL, NULL, NULL,
			hierHead, pricePtr, FALSE) != RET_SUCCEED) /* PMSTA14876 - DDV - 120911 - Add a new parameter, no impact for this call */
    {
	if(freeInstrFlg == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
	FREE_DYNST(pricePtr, A_InstrPrice);
        MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
                     "FIN_ComputeTheoPrice", 
                     GET_CODE(instrPtr, A_Instr_Cd), "Market price");
	return(RET_SUCCEED);
    }

    /*******************************/
    /* COA:  O ---> I ----> Z	   */
    /*******************************/
    /* ------------ */
    /* CurrId(Z=O)  */
    /* ------------ */
    instrPriceMktCurrId = GET_ID(pricePtr, A_InstrPrice_CurrId);

    /* ------------ */
    /* CurrId(I)    */
    /* ------------ */
    /* instrRefCurrId : received as parameter Flow_AmtCurrId */ 

    /* ------------ */
    /* CurrId(SP)   */
    /* ------------ */
    flowSpCurrId =GET_ID(flowTab[i], Flow_AmtCurrId);

    /* compute exchangeRate-1 CurrId(Z) % CurrId(I) */
    if (FIN_GetExchRate(fromDateTime, 
			instrPriceMktCurrId,
			instrRefCurrId,
		    	(ID_T)0, NULL, posPtr, &exchArgSt, &exchRate) != RET_SUCCEED)	/* PMSTA01649 - TGU - 070405 */
    {
	if(freeInstrFlg == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
	FREE_DYNST(pricePtr, A_InstrPrice);
        MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
                     "FIN_ComputeTheoPrice", 
                     GET_CODE(instrPtr, A_Instr_Cd), "exchange rate");
	return(RET_SUCCEED);
    }

    /* compute exchangeRate-2 CurrId(SP) % CurrId(I) */
    if (FIN_GetExchRate(fromDateTime, 
			flowSpCurrId,
			instrRefCurrId,
		    	(ID_T)0, NULL, posPtr, &exchArgSt, &exchRate2) != RET_SUCCEED)	/* PMSTA01649 - TGU - 070405 */
    {
	if(freeInstrFlg == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
	FREE_DYNST(pricePtr, A_InstrPrice);
        MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
                     "FIN_ComputeTheoPrice", 
                     GET_CODE(instrPtr, A_Instr_Cd), "exchange rate");
	return(RET_SUCCEED);
    }

    oldInstrMarketPrice = GET_PRICE(pricePtr,A_InstrPrice_Price);  /* market price */
    newNewInstrQty  = GET_NUMBER(flowTab[i], Flow_QtyUnit); /* QII : qty of new instr. */
    newNewRefQty    = GET_NUMBER(flowTab[i], Flow_RefQty);  /* QIR : reference qty */
    subscriptPrice  = GET_PRICE(flowTab[i], Flow_Quote);
    ctrCtSize_I	    = GET_NUMBER(instrPtr, A_Instr_ContractSize);

    /* retrieve pointer to instrument Z */
    if (FIN_GetHierInstr(hierHead, GET_ID(flowTab[i], Flow_NewInstrId),
			 (char *) &hierFlg, &instrZptr) != RET_SUCCEED)
    {
	if (hierFlg == FALSE) {FREE_DYNST(instrZptr, A_Instr);}
	if(freeInstrFlg == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
	FREE_DYNST(pricePtr, A_InstrPrice);
	return(RET_SUCCEED);
    }
    ctrCtSize_Z	= GET_NUMBER(instrZptr, A_Instr_ContractSize);

    /* check data validity before compute theo. price formula*/
    if ((CMP_NUMBER(oldInstrRefQty,0.0)==0) || (CMP_NUMBER(newNewInstrQty,0.0)==0) || 
	(CMP_NUMBER(oldWithNewInstrQty,0.0)==0) || (CMP_NUMBER(newNewRefQty,0.0)==0) ||
	(CMP_NUMBER(((newNewRefQty/newNewInstrQty) * ctrCtSize_I),0.0)==0) ||
	(CMP_NUMBER((((oldWithNewInstrQty / oldInstrRefQty) + (newNewRefQty / 
	    newNewInstrQty)) * ctrCtSize_I) , 0.0)==0)
       ) 
    {
	if(freeInstrFlg == TRUE) { FREE_DYNST(instrPtr, A_Instr);}
	if (hierFlg == FALSE) {FREE_DYNST(instrZptr, A_Instr);}
	FREE_DYNST(pricePtr, A_InstrPrice);
        MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
                     "FIN_ComputeTheoPrice", 
                     GET_CODE(instrPtr, A_Instr_Cd), "division by zero - invalid calculation");

	return(RET_SUCCEED);
    }

    /* ---------------------------------- */
    /* Perform theoritical Price formula  */
    /* ---------------------------------- */
    if (refInstrId == GET_ID(flowTab[i], Flow_NewInstrId))
    {	/* compute formule related to case instr(O)=instr(Z) */

	    *theoPrice = (( (oldInstrMarketPrice * exchRate) - (subscriptPrice * exchRate2) ) * ctrCtSize_Z)/
			(((oldWithNewInstrQty / oldInstrRefQty) + (newNewRefQty / newNewInstrQty)) * ctrCtSize_I);
    }
    else
    {	/* compute formule related to case instr(O) != instr(Z) */

	/* For BBL : perform formula only if case of */
	/* Proportionl Attribution: (A-->B-->A)	     */
        if (FALSE == propAttribFlg)
	{
 		*theoPrice = (((oldInstrMarketPrice * exchRate) - (subscriptPrice * exchRate2)) * ctrCtSize_Z)/
			     ((newNewRefQty/newNewInstrQty) * ctrCtSize_I);
	}

    }
    
    if (freeInstrFlg==TRUE) {FREE_DYNST(instrPtr, A_Instr);}
    if (hierFlg == FALSE) {FREE_DYNST(instrZptr, A_Instr);}
    FREE_DYNST(pricePtr, A_InstrPrice);

    return(RET_SUCCEED);
}



/**********************************************************************************
**
**  Function    :   FIN_SplitExtOpForJrnl
**
**  Description :   intermediate treatment in order to treat corporate actions
**                 
**  Arguments   :   
**  
**
**  Return      :   retCd
**
**  Creation	:   REF3740 - AKO - 990713
**
************************************************************************************/
STATIC RET_CODE    FIN_SplitExtOpForJrnl(DBA_DYNFLD_STP	    extOperation,
                                         ID_T			    refCurrId,
                                         FUSDATERULE_ENUM	    refFusDateRule,
                                         DBA_DYNFLD_STP	    instrPtr,
                                         DBA_HIER_HEAD_STP	    hierHead,
                                         DBA_DYNFLD_STP	    flowPtr,
                                         DBA_DYNFLD_STP	    domainPtr,
                                         DBA_DYNFLD_STP	    ptfPtr) 
{
     DBA_DYNFLD_STP	    hierInstr = instrPtr;

    DBA_DYNFLD_STP	    op=NULL, *extPosTab=NULL;
    RET_CODE		    ret=TRUE;
    FLAG_T		    adjCashFlag=FALSE;
    DATETIME_T		    begDate;
    int			    nboExtPos=0, i=0, k=0;

    begDate.date = 0;
    begDate.time = 0;

	/* PMSTA07815-DDV-090408 ptfPtr is not mandatory, so do not exit.
	   previous test in R4.30.2 was also wrong and was hiding this bug.
    if (ptfPtr == NULLDYNST)
	    return(RET_GEN_ERR_INVARG);
	*/

    /* PMSTA-25573 - CHU - 170505 */
    if (DBA_IsRejectedOrder(extOperation) == TRUE)
    {
        return ret;
    }

    /* Generate extended position and operation */
    if (OPE_ExtOpToOpExtPos(extOperation, 
			    (OPNAT_ENUM) GET_ENUM(extOperation, ExtOp_NatureEn), /* REF7264 - DDV - 020326 - Compil C++ */
			    refCurrId, refFusDateRule,
			    A_Ptf,
			    ptfPtr,
			    FALSE,    /* genPPSExtPos */
			    NULL,		/* DVP489 - 970602 - XMT, ptfPosSetPtr */
			    0,			/* DVP489 - 970602 - XMT, ptfPosSetNb */
			    A_Instr, 
			    instrPtr,
			    &op, 
			    &extPosTab, 
			    &nboExtPos, 
			    NO_VALUE, 		/* BUG252 - 970115 - DED */ /* REF10929 - DDV - 050118 */
			    UNUSED,		/* BUG252 - 970115 - DED */
			    &adjCashFlag,	/* DVP489 - 970602 - XMT, adjCashFlag */
			    FALSE) != RET_SUCCEED) /* PMSTA13471 - DDV - 120131 */
    {
	    /*FREE_DYNST(newInstr, A_Instr);*/
	    return(RET_GEN_ERR_INVARG);
    }

    /* convert sys amounts if necessary */
    if ((ret = FIN_UpdPosSysAmt(domainPtr, extPosTab, nboExtPos)) != RET_SUCCEED) /* REF3178 - SSO - 990106 */
    {
	    /*FREE_DYNST(newInstr, A_Instr);*/
	    for (i=0; i< nboExtPos; i++) 
	        {FREE_DYNST(extPosTab[i], ExtPos);}
	    FREE(extPosTab);
	    FREE_DYNST(op, A_Op);
	    return(ret);
    }

    /*** Distribute procedure output into hierarchy ***/
    /* Use hierarchy definition Hier_Fmt */
    if ((ret = DBA_AddHierRecord(hierHead, op, A_Op, FALSE, HierAddRec_ForceInsert)) != RET_SUCCEED)
    {
	/* FREE_DYNST(newInstr, A_Instr);*/
	for (i=0; i< nboExtPos; i++)
	    FREE_DYNST(extPosTab[i], ExtPos);
	FREE(extPosTab);
	FREE_DYNST(op, A_Op);
	return(ret);
    }

    COPY_DYNFLD(extOperation, ExtOp, ExtOp_OpId, op, A_Op, A_Op_Id);

    /* Set Operation Id, nature and code in extended positions */
    switch (refFusDateRule)
    {
	case FusDateRule_OpDate :
	    begDate = GET_DATETIME(extOperation, ExtOp_OpDate);
	    break;
	case FusDateRule_AcctDate :
	    begDate = GET_DATETIME(extOperation, ExtOp_AcctDate);
	    break;
	case FusDateRule_ValDate :
	    begDate = GET_DATETIME(extOperation, ExtOp_ValueDate);
	    break;
	case FusDateRule_None :
	    begDate = GET_DATETIME(extOperation, ExtOp_OpDate);                    
	    break;
    }

    for (i=0; i<nboExtPos; i++)
    {
	DBA_DYNFLD_STP      tmpInstr=NULL;
	FLAG_T              hierFlg = TRUE;

	/* REF2154 - DDV - 980513 - if instrument not in hierarchy, insert it */
	if (FIN_GetHierInstr(hierHead,
			     GET_ID(extPosTab[i], ExtPos_InstrId),
			     (char *) &hierFlg, &tmpInstr) == RET_SUCCEED)
	{
                /* DDV - 990809 - if instrPtr is the same as tmpInstr, update hierInstr */
                if (CMP_DYNFLD(tmpInstr, hierInstr,
                               A_Instr_Id, A_Instr_Id, IdType) == 0)
                        hierInstr = tmpInstr;

	    if (hierFlg == FALSE)
	    {
		    DBA_AddHierRecord(hierHead, tmpInstr, A_Instr, TRUE,
				              HierAddRec_ForceInsert);
	    }
	}

	COPY_DYNFLD(extPosTab[i], ExtPos, ExtPos_OpenOpId, 
		    op, A_Op, A_Op_Id);
	SET_ENUM(extPosTab[i], ExtPos_NatEn, ExtPosNat_Flow);
	SET_FLAG(extPosTab[i], ExtPos_ForecastFlg, TRUE);
	SET_ENUM(extPosTab[i], ExtPos_RiskNatEn, ExtPosRisk_NoRisk);
	SET_FLAG(extPosTab[i], ExtPos_AcctFlg, TRUE);

    /* PMSTA-21265 - DDV - 151015 - Avoid crash if flowPtr is not given */
    if (flowPtr != NULLDYNST)
    {
	SET_PERCENT(extPosTab[i], ExtPos_Proba, GET_PERCENT(flowPtr, Flow_Proba));
    }

	SET_ENUM(extPosTab[i], ExtPos_Fus, OpFusion_Treated);     /* DVP058 - 960520 - DED */
	SET_ENUM(extPosTab[i], ExtPos_FusRuleEn, PosFusRule_None);

	COPY_DYNFLD(extPosTab[i], ExtPos, ExtPos_InitExtPosId, /* REF2669 - 980818 - DDV */
		    extOperation, ExtOp, ExtOp_InitExtPosId);      /* DDV - 090408 */
	COPY_DYNFLD(extPosTab[i], ExtPos, ExtPos_FlowId,       /* REF2669 - 980818 - DDV */
		    extOperation, ExtOp, ExtOp_FlowId);            /* DDV - 090408 */

	if (begDate.date == 0)
	{
	    SET_NULL_DATETIME(extPosTab[i], ExtPos_ExtPosDate);
	    SET_NULL_DATETIME(extPosTab[i], ExtPos_BegDate);
	}
	else
	{
	    SET_DATETIME(extPosTab[i], ExtPos_ExtPosDate, begDate);
	    SET_DATETIME(extPosTab[i], ExtPos_BegDate, begDate);
	}
    }

    if (DBA_AddHierRecordList(hierHead, extPosTab, nboExtPos, ExtPos, FALSE) != RET_SUCCEED)
    {
	    /* FREE_DYNST(newInstr, A_Instr);*/
	    for (i=0; i< nboExtPos; i++)
	        FREE_DYNST(extPosTab[i], ExtPos);
	    FREE(extPosTab);
	    return(RET_GEN_ERR_INVARG);
    }

    /* DVP229 */
    /* if (DBA_MakeSpecRecLinks(hierHead, ExtPos,
			     ExtPos_A_Instr_Ext) != RET_SUCCEED) */
    for (k=0; k<nboExtPos; k++)
    {
	/* DVP229 - XDI - 241096 - if instrument in hierarchy */
	/* and same instrument as position, force link else make link */
	if (/* instrPtr != newInstr && */ GET_ID(hierInstr, A_Instr_Id) == GET_ID(extPosTab[k],ExtPos_InstrId))
	{
	    if ((ret = DBA_ForceLink(hierHead, ExtPos, 
				     ExtPos_A_Instr_Ext, extPosTab[k], hierInstr)) != RET_SUCCEED)
	    {
		    /* FREE_DYNST(newInstr, A_Instr);*/
		    FREE(extPosTab);
		    return(RET_GEN_ERR_INVARG);
	    }
	}
	else
	{
	    if (DBA_MakeSpecRecordLinks(hierHead, ExtPos, 
					                ExtPos_A_Instr_Ext, extPosTab[k]) != RET_SUCCEED)
	    {
		/* FREE_DYNST(newInstr, A_Instr);*/
		FREE(extPosTab);
		return(RET_GEN_ERR_INVARG);
	    }
	}
    }
    FREE(extPosTab);

    return(ret);
}



/************************************************************************
**
**  Function    :   FIN_GenExtOpExchFlow()
**
**  Description :   Fill in extended operation generate for a exchange flow
**                 
**  Arguments   :                                        
**
**  Return      :                                         
**
**  Modif	:   REF233 - RAK - 971113
**		        REF3929 - SSO - 990909: added treatRefNatFlg to indicat if ref nat must be treated
**					    NB: it is NEVER done if multiples ops are generated, i.e. here if newInstrFlg == TRUE
**              REF4455 - YST - 020404 
**              REF7479 - YST - 020409
**              REF9956 - 041117 - PMO : FlexeLint message
**
*************************************************************************/
STATIC RET_CODE FIN_GenExtOpExchFlow(DBA_DYNFLD_STP    stock, 
                                    DBA_DYNFLD_STP    flowPtr,
                                    DBA_DYNFLD_STP    extOperation,
                                    DBA_DYNFLD_STP    *instrPtr,
                                    DBA_HIER_HEAD_STP hierHead,
                                    FLAG_T            *scptFlagTabExtOp,
                                    FLAG_T            newInstrFlg, 
                                    RNDRULE_ENUM      roundRule,
                                    QTYTYPE_ENUM      qtyType,
                                    QTYTYPE_ENUM      adjQtyType,
                                    FLAG_T	          treatRefNatFlg)
{
   NUMBER_T            qty=0.0, sign =1.0, roundedQty=0.0, roundUnit=0.0;
   NUMBER_T            oldInstrQty, oldInstrRoundedQty, newInstrQty, newInstrRoundedQty;
   ID_T                dfltTpId;
   DBA_DYNFLD_STP      newInstrLocal=NULL;
   FLAG_T              allocOk = FALSE;

   GEN_GetApplInfo(ApplExchOpTpId, &dfltTpId);

   if (newInstrFlg == TRUE)
   {
      COPY_DYNFLD(extOperation, ExtOp, ExtOp_InstrId, flowPtr, Flow, Flow_NewInstrId);
      
      /* REF3913 - 990819 - DDV */
      if (DBA_GetInstrById(GET_ID(flowPtr, Flow_NewInstrId), TRUE, &allocOk, 
                             &newInstrLocal, hierHead, UNUSED, UNUSED) != RET_SUCCEED)
      {
         FREE(scptFlagTabExtOp);
         MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "Instr");
         return(RET_DBA_ERR_NODATA);
      }

      /* REF233 - ExtOp_InstrCurrId depending on ExtOp_InstrId */
      COPY_DYNFLD(extOperation, ExtOp, ExtOp_InstrCurrId,
                  newInstrLocal, A_Instr, A_Instr_RefCurrId); 
  
      /* if quote in exchange event is null, use default value to fill price and quote */
      if (IS_NULLFLD(flowPtr, Flow_Quote) == TRUE) /* REF2215 - DDV - 980528 */
      { 
         SET_NULL_PRICE(extOperation, ExtOp_Price);
         SET_NULL_PRICE(extOperation, ExtOp_Quote);
         scptFlagTabExtOp[ExtOp_Price]=FALSE;   
         scptFlagTabExtOp[ExtOp_Quote]=FALSE;    /* REF2064 - DDV - 980430 */
      }

      if (GET_ENUM(extOperation, ExtOp_NatureEn) == OpNat_Adjust)
      {

         COPY_DYNFLD(extOperation, ExtOp, ExtOp_AdjInstrId, 
                     stock, ExtPos, ExtPos_InstrId);
         scptFlagTabExtOp[ExtOp_AdjInstrId]=TRUE;   
                               
         /* PMSTA - 36247 - SANAND - 110719 - Only when the InstrumentNature is Convertible Bond
         Exchange Nature will be conversion, set values for the new instrument */
         if( ( FlowSubNat_ConvExch  == static_cast<FLOWSUBNAT_ENUM>GET_ENUM(flowPtr, Flow_SubNatEn) ) &&
             nullptr != *instrPtr && InstrNat_ConvertBond == static_cast<INSTRNAT_ENUM>GET_ENUM(*instrPtr, A_Instr_NatEn))
         {
             SET_ENUM(extOperation, ExtOp_AdjNatEn, OpAdjustNat_Conversion);
             scptFlagTabExtOp[ExtOp_AdjNatEn] = TRUE;

             SET_NUMBER(extOperation, ExtOp_AdjQty, -GET_NUMBER(stock, ExtPos_Qty));
             scptFlagTabExtOp[ExtOp_AdjQty] = TRUE;

             if ( TRUE == IS_NULLFLD(flowPtr, Flow_Quote) )
             {
                 SET_PRICE(extOperation, ExtOp_Quote, GET_PRICE(flowPtr, Flow_Quote));
                 scptFlagTabExtOp[ExtOp_Quote] = TRUE;
             }
         }
         else
         {
             SET_ENUM(extOperation, ExtOp_AdjNatEn, OpAdjustNat_GrossAmt);
             scptFlagTabExtOp[ExtOp_AdjNatEn] = TRUE;

             SET_NUMBER(extOperation, ExtOp_AdjQty, 0);
             scptFlagTabExtOp[ExtOp_AdjQty] = TRUE;
         }
                                  
                                  
         COPY_DYNFLD(extOperation, ExtOp, ExtOp_AdjPosCurrId, 
                     stock, ExtPos, ExtPos_PosCurrId);
         scptFlagTabExtOp[ExtOp_AdjPosCurrId]=TRUE; 
                                 
         COPY_DYNFLD(extOperation, ExtOp, ExtOp_AdjDepoId, 
                     stock, ExtPos, ExtPos_DepoId);
         scptFlagTabExtOp[ExtOp_AdjDepoId]=TRUE;    

      }

      if (GET_FLAG(flowPtr, Flow_ReplaceFlg) == FALSE)
      {
         if (GET_NUMBER(flowPtr, Flow_RefQty) == 0.0)
         {
             qty = GET_NUMBER(stock, ExtPos_Qty) * (GET_PERCENT(flowPtr, Flow_Proba) / 100.0);
         }
         else
         {
             qty = GET_NUMBER(stock, ExtPos_Qty) / GET_NUMBER(flowPtr, Flow_RefQty) *
                   (GET_PERCENT(flowPtr, Flow_Proba) / 100.0);
         }
         if (GET_NUMBER((*instrPtr), A_Instr_ContractSize)  != 0)
            { qty /= GET_NUMBER((*instrPtr), A_Instr_ContractSize); }
         qty *= GET_NUMBER(flowPtr, Flow_QtyUnit);
         if (qty < 0)
         {
            qty *=-1;
            if (GET_ENUM(extOperation, ExtOp_NatureEn) == OpNat_Adjust)
                sign=-1;
            else
                sign=+1;
         }

         /* REF3397 - 990331 - DDV - implementation of rounding rule and cash compensation */ 
         if (GET_NUMBER(flowPtr, Flow_NewInstrMinDenom) != 0.0)
           roundUnit = GET_NUMBER(flowPtr, Flow_NewInstrMinDenom);
         else if (GET_NUMBER(newInstrLocal, A_Instr_OddLotQty) != 0.0)
           roundUnit = GET_NUMBER(newInstrLocal, A_Instr_OddLotQty);
         else
           roundUnit = 1.0;

         roundedQty  = TLS_Round(qty, roundUnit, roundRule);

         switch (qtyType)
         {
           case QtyType_Rounded:
             SET_NUMBER(extOperation,      ExtOp_Qty, roundedQty*sign);
             break;
           case QtyType_Remain:
             /* for remain quantiy, always use market price */
             SET_NULL_PRICE(extOperation, ExtOp_Price);
             SET_NULL_PRICE(extOperation, ExtOp_Quote);
             scptFlagTabExtOp[ExtOp_Price]=FALSE;   
             scptFlagTabExtOp[ExtOp_Quote]=FALSE;    /* REF2064 - DDV - 980430 */

             qty = qty - roundedQty;

             if (qty < 0)
             {
               qty *=-1;
               /* for nearest rouding rule supposition was 'down' if not change operation and quantity sign */
               if (roundRule == RndRule_Nearest)
               {
                 if(GET_ENUM(extOperation, ExtOp_NatureEn) == OpNat_Sell)
                   {SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);}
                 else
                   {SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);}
               }
             }
             /* REF7479 - YST - 020409 - no operation should be created when quantity is zero */
             if (qty == 0)
                SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_None);

             SET_NUMBER(extOperation,      ExtOp_Qty, qty);
             break;
           case QtyType_Zero:
             SET_NUMBER(extOperation,      ExtOp_Qty, 0);
             break;
           case QtyType_NotRounded:
           default:
             SET_NUMBER(extOperation,      ExtOp_Qty, CAST_NUMBER(qty*sign));
             break;
         }
      }
      else
      {
        /* REF4455 - YST - 020404 - copy fixed exchange rate (not NULL) from flow to ext operation for convertible bonds */
        if ((INSTRNAT_ENUM)GET_ENUM((*instrPtr), A_Instr_NatEn) == InstrNat_ConvertBond &&
            IS_NULLFLD(flowPtr, Flow_FxdExchRate) != TRUE) /* REF8012 - YST - 021001 */
        {  
	        switch(GET_ENUM(extOperation, ExtOp_NatureEn))
            {
            case OpNat_Buy:
                COPY_DYNFLD(extOperation, ExtOp, ExtOp_OpExchRate, 
                            flowPtr, Flow, Flow_FxdExchRate);
                scptFlagTabExtOp[ExtOp_OpExchRate]=TRUE; 
                COPY_DYNFLD(extOperation, ExtOp, ExtOp_InstrExchRate, 
                            flowPtr, Flow, Flow_FxdExchRate);
                scptFlagTabExtOp[ExtOp_InstrExchRate]=TRUE;
            break;
            case OpNat_Sell:
                COPY_DYNFLD(extOperation, ExtOp, ExtOp_OpExchRate, 
                            flowPtr, Flow, Flow_FxdExchRate);
                scptFlagTabExtOp[ExtOp_OpExchRate]=TRUE;
            break;

            case OpNat_Adjust:
                COPY_DYNFLD(extOperation, ExtOp, ExtOp_AdjPosExchRate, 
                            flowPtr, Flow, Flow_FxdExchRate);
                scptFlagTabExtOp[ExtOp_AdjPosExchRate]=TRUE;
                COPY_DYNFLD(extOperation, ExtOp, ExtOp_AdjInstrExchRate,
                            flowPtr, Flow, Flow_FxdExchRate);
                scptFlagTabExtOp[ExtOp_AdjInstrExchRate]=TRUE;
            break;
            default:
            break;
            }
        }
          
          qty = GET_NUMBER(stock, ExtPos_Qty) * 
              (GET_PERCENT(flowPtr, Flow_Proba) / 100.0);
         if (GET_NUMBER((*instrPtr), A_Instr_ContractSize)  != 0)
            { qty /= GET_NUMBER((*instrPtr), A_Instr_ContractSize); }
         if (GET_NUMBER(flowPtr, Flow_RefQty) != 0.0)
            { qty /= GET_NUMBER(flowPtr, Flow_RefQty); }

         switch (GET_ENUM(flowPtr, Flow_EuroConvRuleEn))
         {
             case EuroConvRule_None: /* REF3089 - 990607 - DDV - Modificatioons for new method CashCompensationOld */
		if (GET_NUMBER(flowPtr, Flow_RefQty) == 0.0)
		{
		    qty = GET_NUMBER(stock, ExtPos_Qty) * (GET_PERCENT(flowPtr, Flow_Proba) / 100.0);
		}
		else
		{
		    qty = GET_NUMBER(stock, ExtPos_Qty) / GET_NUMBER(flowPtr, Flow_RefQty) *
			  (GET_PERCENT(flowPtr, Flow_Proba) / 100.0);
		}

	        if (GET_NUMBER((*instrPtr), A_Instr_ContractSize)  != 0)
			{qty /= GET_NUMBER((*instrPtr), A_Instr_ContractSize); }

	        qty *= GET_NUMBER(flowPtr, Flow_QtyUnit);

		if (qty < 0)
	        {
		    qty *=-1;
	            if (GET_ENUM(extOperation, ExtOp_NatureEn) == OpNat_Adjust)
		        sign=-1;
	            else
		        sign=+1;
	        }

		/* REF3089 - 990607 - DDV - implementation of rounding rule and cash compensation */ 
	        if (GET_NUMBER(flowPtr, Flow_NewInstrMinDenom) != 0.0)
		    roundUnit = GET_NUMBER(flowPtr, Flow_NewInstrMinDenom);
	        else if (GET_NUMBER(newInstrLocal, A_Instr_OddLotQty) != 0.0)
		    roundUnit = GET_NUMBER(newInstrLocal, A_Instr_OddLotQty);
	        else
		    roundUnit = 1.0;

	        roundedQty  = TLS_Round(qty, roundUnit, roundRule);

		switch (qtyType)
	        {
		   case QtyType_Rounded:
	             SET_NUMBER(extOperation,      ExtOp_Qty, roundedQty*sign);
		     break;
	           case QtyType_Remain:
		     /* for remain quantiy, always use market price */
	             SET_NULL_PRICE(extOperation, ExtOp_Price);
		     SET_NULL_PRICE(extOperation, ExtOp_Quote);
	             scptFlagTabExtOp[ExtOp_Price]=FALSE;   
		     scptFlagTabExtOp[ExtOp_Quote]=FALSE;

	             qty = qty - roundedQty;
             
		     if (qty < 0)
	             {
		       qty *=-1;
	               /* for nearest rouding rule supposition was 'down' if not change operation and quantity sign */
		       if (roundRule == RndRule_Nearest)
	               {
		         if(GET_ENUM(extOperation, ExtOp_NatureEn) == OpNat_Sell)
			   {SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);}
	                 else
		           {SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);}
	               }
		     }
             /* REF7479 - YST - 020409 - no operation should be created when quantity is zero */
             if (qty == 0)
                SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_None);
             
	             SET_NUMBER(extOperation,      ExtOp_Qty, qty);
		     break;
                   case QtyType_Zero:
                     SET_NUMBER(extOperation,      ExtOp_Qty, 0);
		     break;
	           case QtyType_NotRounded:
		   default:
	             SET_NUMBER(extOperation,      ExtOp_Qty, CAST_NUMBER(qty*sign));
		     break;
	        }
                 break;

             case EuroConvRule_BottomUpOneEuro:
             case EuroConvRule_BottomUpOneEuroLost: /* REF2957 - DDV - 981110 */

                 qty = (TLS_RoundEnum(qty * GET_NUMBER(flowPtr, Flow_QtyUnit),
                                      RndUnit_0_00001, RndRule_Down)) -
                       (TLS_RoundEnum(qty * GET_NUMBER(flowPtr, Flow_QtyUnit),
                                      RndUnit_1_00, RndRule_Down));
                 SET_NUMBER(extOperation, ExtOp_Qty, qty);
                 break;

             case EuroConvRule_BottomUpMinDenom:

                 qty = (TLS_RoundEnum(qty * GET_NUMBER(flowPtr, Flow_QtyUnit),
                                      RndUnit_0_00001, RndRule_Down)) -
                       (TLS_Round(qty * GET_NUMBER(flowPtr, Flow_QtyUnit),
                                  GET_NUMBER(flowPtr, Flow_NewInstrMinDenom), 
                                  RndRule_Down));
                 SET_NUMBER(extOperation, ExtOp_Qty, qty);
                 break;

             case EuroConvRule_TopDownOneEuro:

                 qty = (TLS_RoundEnum(qty * GET_NUMBER(flowPtr, Flow_QtyUnit),
                                      RndUnit_0_00001, RndRule_Down) ) -
                       /* qty * (TLS_RoundEnum(GET_NUMBER(flowPtr, Flow_QtyUnit), 
                                             RndUnit_1_00, RndRule_Down)); - REF6131.3511 - 010710 - DDV - The value to rounding has changed */
                       (TLS_RoundEnum(qty * GET_NUMBER(flowPtr, Flow_QtyUnit), 
                                             RndUnit_1_00, RndRule_Down));

                 SET_NUMBER(extOperation, ExtOp_Qty, CAST_NUMBER(qty));
                 break;

             case EuroConvRule_TopDownMinDenom:

                 qty = (qty * GET_NUMBER(flowPtr, Flow_QtyUnit)) -
                       ( qty * TLS_Round(GET_NUMBER(flowPtr, Flow_QtyUnit), 
                                         GET_NUMBER(flowPtr, Flow_NewInstrMinDenom),
                                         RndRule_Down));
                 SET_NUMBER(extOperation, ExtOp_Qty, CAST_NUMBER(qty));
                 break;

             case EuroConvRule_TopDownMinLot:   /* Never call */
             case EuroConvRule_BottomUpOneCent: /* Never call */
             case EuroConvRule_TopDownOneCent:  /* Never call */
             case EuroConvRule_BottomUpMinDenomOneCent: /* REF6187 - DDV - 010810 */
                 break;
             case EuroConvRule_BottomUpMinDenomOneEuro:     /* REF6187 - DDV - 010810 */

            	 qty = GET_NUMBER(stock, ExtPos_Qty) * 
                       (GET_PERCENT(flowPtr, Flow_Proba) / 100.0);
                 if (GET_NUMBER((*instrPtr), A_Instr_ContractSize)  != 0)
                    { qty /= GET_NUMBER((*instrPtr), A_Instr_ContractSize); }
                 
                 if (IS_NULLFLD((*instrPtr), A_Instr_FaceValue) == FALSE &&
                     GET_PRICE((*instrPtr), A_Instr_FaceValue) != 0)
                    { qty /= GET_PRICE((*instrPtr), A_Instr_FaceValue); }


                 qty = (TLS_RoundEnum((TLS_RoundEnum(GET_NUMBER(flowPtr, Flow_RefQty) / GET_NUMBER(flowPtr, Flow_NewInstrMinDenom),
                                                     RndUnit_0_00001, RndRule_Down) -
                                       TLS_RoundEnum(GET_NUMBER(flowPtr, Flow_RefQty) / GET_NUMBER(flowPtr, Flow_NewInstrMinDenom),
                                                     RndUnit_1_00, RndRule_Down)) *
                                      GET_NUMBER(flowPtr, Flow_NewInstrMinDenom) * qty,
                                      RndUnit_0_01, RndRule_Down));
                 SET_NUMBER(extOperation, ExtOp_Qty, qty);
                 break;

             case EuroConvRule_BottomUpHolding25Cents: /* REF6187 - DDV - 010810 */

            	 qty = GET_NUMBER(stock, ExtPos_Qty) * 
                       (GET_PERCENT(flowPtr, Flow_Proba) / 100.0);
                 if (GET_NUMBER((*instrPtr), A_Instr_ContractSize)  != 0)
                    { qty /= GET_NUMBER((*instrPtr), A_Instr_ContractSize); }
                 
                 if (GET_NUMBER(flowPtr, Flow_RefQty) != 0.0)
                    { qty /= GET_NUMBER(flowPtr, Flow_RefQty); }
                 
                 qty = TLS_RoundEnum(qty, RndUnit_0_00001, RndRule_Down) / 0.25;

                 qty = (qty - TLS_RoundEnum(qty, RndUnit_1_00, RndRule_Down)) * 0.25;

                 SET_NUMBER(extOperation, ExtOp_Qty, qty);
                 break;

         }
      }
      *instrPtr = newInstrLocal;
   }
   else /* else newInstrFlg == FALSE */
   {
   
      /* REF3913 - 990819 - DDV */
      if (DBA_GetInstrById(GET_ID(flowPtr, Flow_NewInstrId), TRUE, &allocOk, 
                             &newInstrLocal, hierHead, UNUSED, UNUSED) != RET_SUCCEED)
      {
         FREE(scptFlagTabExtOp);
         MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "Instr");
         return(RET_DBA_ERR_NODATA);
      }

        /* REF4455 - YST - 020404 - copy fixed exchange rate (not NULL) from flow to ext operation for convertible bonds */
        if ((INSTRNAT_ENUM)GET_ENUM((*instrPtr), A_Instr_NatEn) == InstrNat_ConvertBond &&
            IS_NULLFLD(flowPtr, Flow_FxdExchRate) != TRUE) /* REF8012 - YST - 021001 */
        {  
	        switch(GET_ENUM(extOperation, ExtOp_NatureEn))
            {
            case OpNat_Buy:
                COPY_DYNFLD(extOperation, ExtOp, ExtOp_OpExchRate, 
                            flowPtr, Flow, Flow_FxdExchRate);
                scptFlagTabExtOp[ExtOp_OpExchRate]=TRUE;
                COPY_DYNFLD(extOperation, ExtOp, ExtOp_InstrExchRate, 
                            flowPtr, Flow, Flow_FxdExchRate);
                scptFlagTabExtOp[ExtOp_InstrExchRate]=TRUE;
            break;
            case OpNat_Sell:
                COPY_DYNFLD(extOperation, ExtOp, ExtOp_OpExchRate, 
                            flowPtr, Flow, Flow_FxdExchRate);
                scptFlagTabExtOp[ExtOp_OpExchRate]=TRUE;           
            break;

            case OpNat_Adjust:
                COPY_DYNFLD(extOperation, ExtOp, ExtOp_AdjPosExchRate, 
                            flowPtr, Flow, Flow_FxdExchRate);
                scptFlagTabExtOp[ExtOp_AdjPosExchRate]=TRUE;
                COPY_DYNFLD(extOperation, ExtOp, ExtOp_AdjInstrExchRate,
                            flowPtr, Flow, Flow_FxdExchRate);
                scptFlagTabExtOp[ExtOp_AdjInstrExchRate]=TRUE;
            break;
            default:
            break;
            }
        }

      switch(GET_ENUM(extOperation, ExtOp_NatureEn))
      {
         case OpNat_Adjust:
            COPY_DYNFLD(extOperation, ExtOp, ExtOp_AdjInstrId, 
                        flowPtr, Flow, Flow_NewInstrId);
            scptFlagTabExtOp[ExtOp_AdjInstrId]=TRUE;   
                                  
            SET_ENUM(extOperation, ExtOp_AdjNatEn, OpAdjustNat_Pl);
            scptFlagTabExtOp[ExtOp_AdjNatEn]=TRUE;     
                                  
            SET_PRICE(extOperation, ExtOp_Price, 0);
            SET_PRICE(extOperation, ExtOp_Quote, 0);
            COPY_DYNFLD(extOperation, ExtOp, ExtOp_AdjPosCurrId, 
                        flowPtr, Flow, Flow_AmtCurrId);
            scptFlagTabExtOp[ExtOp_AdjPosCurrId]=TRUE;
                                  
            COPY_DYNFLD(extOperation, ExtOp, ExtOp_AdjDepoId, 
                        stock, ExtPos, ExtPos_DepoId);
            scptFlagTabExtOp[ExtOp_AdjDepoId]=TRUE;    
                                  
            COPY_DYNFLD(extOperation, ExtOp, ExtOp_DepoId, 
                        stock, ExtPos, ExtPos_DepoId);

            COPY_DYNFLD(extOperation, ExtOp, ExtOp_OpCurrId,  /* REF1138 - XDI - 980204 */
                        stock, ExtPos, ExtPos_PosCurrId);

            /* REF2563 - DDV - 980820 - BEGIN */

	    if (treatRefNatFlg == TRUE)  /* REF3929 - SSO - 990909 */
	    {
		/* REF2563 - DDV - 980820 - BEGIN */
		switch(GET_ENUM(stock, ExtPos_RefNatEn)) /* REF2563 - DDV - 980828 */
		{
		  case PosRefNat_Open :
		    SET_ENUM(extOperation, ExtOp_RefNatEn, PosRefNat_Close);
		    scptFlagTabExtOp[ExtOp_RefNatEn]=TRUE;

		    COPY_DYNFLD(extOperation, ExtOp, ExtOp_RefOpCd,
				stock, ExtPos, ExtPos_OpenOpCd);
		    scptFlagTabExtOp[ExtOp_RefOpCd]=TRUE;
		    break;
		  case PosRefNat_TermOpen:  /* REF3929 - SSO - 990909 */
		    SET_ENUM(extOperation, ExtOp_RefNatEn, PosRefNat_TermClose);
		    scptFlagTabExtOp[ExtOp_RefNatEn]=TRUE;

		    COPY_DYNFLD(extOperation, ExtOp, ExtOp_RefOpCd,
				stock, ExtPos, ExtPos_OpenOpCd);
		    scptFlagTabExtOp[ExtOp_RefOpCd]=TRUE;

		    COPY_DYNFLD(extOperation, ExtOp, ExtOp_ValueDate,
				stock, ExtPos, ExtPos_ValDate);
		    scptFlagTabExtOp[ExtOp_ValueDate]=TRUE;
		    break;
		}
	    }

            COPY_DYNFLD(extOperation, ExtOp, ExtOp_ExpirDate,
                        stock, ExtPos, ExtPos_ExpirDate);
            scptFlagTabExtOp[ExtOp_ExpirDate]=TRUE;

            COPY_DYNFLD(extOperation, ExtOp, ExtOp_Rate,
                        stock, ExtPos, ExtPos_Rate);
            scptFlagTabExtOp[ExtOp_Rate]=TRUE;

            /* REF2563 - DDV - 980820 - END */

            qty = GET_NUMBER(stock, ExtPos_Qty) * 
                  (GET_PERCENT(flowPtr, Flow_Proba) / 100.0);
            if (GET_NUMBER((*instrPtr), A_Instr_ContractSize)  != 0)
               { qty /= GET_NUMBER((*instrPtr), A_Instr_ContractSize); }

            switch (GET_ENUM(flowPtr, Flow_EuroConvRuleEn))
            {
                case EuroConvRule_None:
                    qty = GET_NUMBER(stock, ExtPos_Qty) * (GET_PERCENT(flowPtr, Flow_Proba) / 100.0);

		    if (GET_NUMBER((*instrPtr), A_Instr_ContractSize)  != 0)
			{qty /= GET_NUMBER((*instrPtr), A_Instr_ContractSize); }

		    if (qty < 0)
		    { 
		        qty *=-1;
                        sign=-1;
		    }

		    oldInstrQty = qty;

		    if (GET_NUMBER(flowPtr, Flow_RefQty) != 0.0)
			{qty /= GET_NUMBER(flowPtr, Flow_RefQty); }

		    qty *= GET_NUMBER(flowPtr, Flow_QtyUnit);

		    newInstrQty = qty;

		    /* REF3089 - 990607 - DDV - implementation of rounding rule and cash compensation */ 
	            if (GET_NUMBER(flowPtr, Flow_NewInstrMinDenom) != 0.0)
		        roundUnit = GET_NUMBER(flowPtr, Flow_NewInstrMinDenom);
	            else if (GET_NUMBER(newInstrLocal, A_Instr_OddLotQty) != 0.0)
    		        roundUnit = GET_NUMBER(newInstrLocal, A_Instr_OddLotQty);
	            else
		        roundUnit = 1.0;

	            newInstrRoundedQty  = TLS_Round(qty, roundUnit, roundRule);

		    qty = newInstrRoundedQty * GET_NUMBER(flowPtr, Flow_RefQty);

		    if (GET_NUMBER(flowPtr, Flow_QtyUnit) != 0.0)
			{qty /= GET_NUMBER(flowPtr, Flow_QtyUnit); }

		    oldInstrRoundedQty = qty;

		    switch (qtyType)
		    { 
		       case QtyType_Rounded:
	                 SET_NUMBER(extOperation,      ExtOp_Qty, oldInstrRoundedQty*sign*(-1));
		         break;
	               case QtyType_Remain:
		         /* for remain quantiy, always use market price */
	                 SET_NULL_PRICE(extOperation, ExtOp_Price);
		         SET_NULL_PRICE(extOperation, ExtOp_Quote);
	                 scptFlagTabExtOp[ExtOp_Price]=FALSE;   
		         scptFlagTabExtOp[ExtOp_Quote]=FALSE;

	                 qty = oldInstrQty - oldInstrRoundedQty;
                    
                    /* REF7479 - YST - 020409 - no operation should be created when quantity is zero */
                    if (qty == 0)
                        SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_None);
             
	                 SET_NUMBER(extOperation,      ExtOp_Qty, qty);
		         break;
	               case QtyType_Zero:
	                 SET_NUMBER(extOperation,      ExtOp_Qty, 0);
                 break;     /* REF9956 - 041117 - PMO */
	               case QtyType_NotRounded:
		       default:
	                 SET_NUMBER(extOperation,      ExtOp_Qty, CAST_NUMBER(oldInstrQty*sign*(-1)));
		         break;
		    }

		    switch (adjQtyType)
		    { 
		       case QtyType_Rounded:
	                 SET_NUMBER(extOperation,      ExtOp_AdjQty, newInstrRoundedQty*sign);
		         break;
	               case QtyType_Remain:

	                 qty = newInstrQty - newInstrRoundedQty;
             
	                 SET_NUMBER(extOperation,      ExtOp_AdjQty, qty);
		         break;
	               case QtyType_Zero:
	                 SET_NUMBER(extOperation,      ExtOp_AdjQty, 0);
		         break;
	               case QtyType_NotRounded:
		       default:
	                 SET_NUMBER(extOperation,      ExtOp_AdjQty, CAST_NUMBER(newInstrQty*sign));
		         break;
		    }
                    break;
                case EuroConvRule_BottomUpOneCent:
                    SET_NUMBER(extOperation, ExtOp_Qty, (-1) * qty);

                    if (GET_NUMBER(flowPtr, Flow_RefQty) != 0.0)
                       { qty /= GET_NUMBER(flowPtr, Flow_RefQty); }

                    qty  = TLS_RoundEnum(qty*GET_NUMBER(flowPtr, Flow_QtyUnit), 
                                         RndUnit_0_01, RndRule_Nearest);
                    SET_NUMBER(extOperation, ExtOp_AdjQty, qty);
                    break;

                case EuroConvRule_BottomUpOneEuro:
                    SET_NUMBER(extOperation, ExtOp_Qty, (-1) * qty);

                    if (GET_NUMBER(flowPtr, Flow_RefQty) != 0.0)
                       { qty /= GET_NUMBER(flowPtr, Flow_RefQty); }

                    qty  = TLS_RoundEnum(qty*GET_NUMBER(flowPtr, Flow_QtyUnit), 
                                         RndUnit_0_00001, RndRule_Down);
                    SET_NUMBER(extOperation, ExtOp_AdjQty, qty);
                    break;

                case EuroConvRule_BottomUpOneEuroLost: /* REF2957 - DDV - 981104 */
                    SET_NUMBER(extOperation, ExtOp_Qty, (-1) * qty);

                    if (GET_NUMBER(flowPtr, Flow_RefQty) != 0.0)
                       { qty /= GET_NUMBER(flowPtr, Flow_RefQty); }

                    qty  = TLS_RoundEnum(qty*GET_NUMBER(flowPtr, Flow_QtyUnit), 
                                         RndUnit_1_00, RndRule_Up);
                    SET_NUMBER(extOperation, ExtOp_AdjQty, qty);
                    break;

                case EuroConvRule_BottomUpMinDenom:
                    SET_NUMBER(extOperation, ExtOp_Qty, (-1) * qty);

                    if (GET_NUMBER(flowPtr, Flow_RefQty) != 0.0)
                       { qty /= GET_NUMBER(flowPtr, Flow_RefQty); }

                    qty  = TLS_RoundEnum(qty*GET_NUMBER(flowPtr, Flow_QtyUnit), 
                                         RndUnit_0_00001, RndRule_Down);
                    SET_NUMBER(extOperation, ExtOp_AdjQty, qty);
                    break;

                case EuroConvRule_TopDownOneCent:
                    SET_NUMBER(extOperation, ExtOp_Qty, (-1) * qty);

                    if (GET_NUMBER(flowPtr, Flow_RefQty) != 0.0)
                       { qty /= GET_NUMBER(flowPtr, Flow_RefQty); }

                    /* qty  *= TLS_RoundEnum(GET_NUMBER(flowPtr, Flow_QtyUnit), 
                                          RndUnit_0_01, RndRule_Nearest); - REF6131.3511 - 010713 - DDV */
                    qty  = TLS_RoundEnum(qty * GET_NUMBER(flowPtr, Flow_QtyUnit), 
                                          RndUnit_0_01, RndRule_Down);

                    SET_NUMBER(extOperation, ExtOp_AdjQty, qty);
                    break;

                case EuroConvRule_TopDownOneEuro:
                    SET_NUMBER(extOperation, ExtOp_Qty, (-1) * qty);

                    if (GET_NUMBER(flowPtr, Flow_RefQty) != 0.0)
                       { qty /= GET_NUMBER(flowPtr, Flow_RefQty); }

                    /*qty  *= GET_NUMBER(flowPtr, Flow_QtyUnit); - REF6131.3511 - 010710 - DDV */
                    qty  = TLS_RoundEnum(qty * GET_NUMBER(flowPtr, Flow_QtyUnit), 
                                         RndUnit_0_00001, RndRule_Down);
                    SET_NUMBER(extOperation, ExtOp_AdjQty, qty);
                    break;

                case EuroConvRule_TopDownMinDenom:
                    SET_NUMBER(extOperation, ExtOp_Qty, (-1) * qty);

                    if (GET_NUMBER(flowPtr, Flow_RefQty) != 0.0)
                       { qty /= GET_NUMBER(flowPtr, Flow_RefQty); }

                    qty  *= GET_NUMBER(flowPtr, Flow_QtyUnit);
                    SET_NUMBER(extOperation, ExtOp_AdjQty, CAST_NUMBER(qty)); /* REF3288 - SSO - 990205 */
                    break;

                case EuroConvRule_TopDownMinLot:
                    SET_NUMBER(extOperation, ExtOp_Qty, (-1) * qty);

                    if (GET_NUMBER(flowPtr, Flow_RefQty) != 0.0)
                       { qty /= GET_NUMBER(flowPtr, Flow_RefQty); }

                    qty  *= TLS_RoundEnum(GET_NUMBER(flowPtr, Flow_QtyUnit), 
                                          RndUnit_0_01, RndRule_Nearest);
                    SET_NUMBER(extOperation, ExtOp_AdjQty, qty);
                    break;

                case EuroConvRule_BottomUpMinDenomOneEuro: /* REF6187 - DDV - 010810 */

                    qty = GET_NUMBER(stock, ExtPos_Qty) * (GET_PERCENT(flowPtr, Flow_Proba) / 100.0);

        		    if (GET_NUMBER((*instrPtr), A_Instr_ContractSize)  != 0)
		            	{qty /= GET_NUMBER((*instrPtr), A_Instr_ContractSize); }

                    SET_NUMBER(extOperation, ExtOp_Qty, (-1) * qty);

                    if (IS_NULLFLD((*instrPtr), A_Instr_FaceValue) == FALSE &&
                        GET_PRICE((*instrPtr), A_Instr_FaceValue) != 0)
                        { qty /= GET_PRICE((*instrPtr), A_Instr_FaceValue); }

                    qty = TLS_RoundEnum(TLS_RoundEnum(GET_NUMBER(flowPtr, Flow_RefQty) / GET_NUMBER(flowPtr, Flow_NewInstrMinDenom), 
                                                      RndUnit_0_00001, RndRule_Down) * GET_NUMBER(flowPtr, Flow_NewInstrMinDenom) * qty,
                                        RndUnit_0_01, RndRule_Down);

                    SET_NUMBER(extOperation, ExtOp_AdjQty, qty);
                    break;

                case EuroConvRule_BottomUpMinDenomOneCent: /* REF6187 - DDV - 010810 */

                    qty = GET_NUMBER(stock, ExtPos_Qty) * (GET_PERCENT(flowPtr, Flow_Proba) / 100.0);

        		    if (GET_NUMBER((*instrPtr), A_Instr_ContractSize)  != 0)
		            	{qty /= GET_NUMBER((*instrPtr), A_Instr_ContractSize); }

                    SET_NUMBER(extOperation, ExtOp_Qty, (-1) * qty);

                    if (IS_NULLFLD((*instrPtr), A_Instr_FaceValue) == FALSE &&
                        GET_PRICE((*instrPtr), A_Instr_FaceValue) != 0)
                        { qty /= GET_PRICE((*instrPtr), A_Instr_FaceValue); }

                    qty *= GET_NUMBER(flowPtr, Flow_RefQty);

                    SET_NUMBER(extOperation, ExtOp_AdjQty, qty);
                    break;

                case EuroConvRule_BottomUpHolding25Cents: /* REF6187 - DDV - 010810 */

                    qty = GET_NUMBER(stock, ExtPos_Qty) * (GET_PERCENT(flowPtr, Flow_Proba) / 100.0);

        		    if (GET_NUMBER((*instrPtr), A_Instr_ContractSize)  != 0)
		            	{qty /= GET_NUMBER((*instrPtr), A_Instr_ContractSize); }

                    SET_NUMBER(extOperation, ExtOp_Qty, (-1) * qty);

                    if (GET_NUMBER(flowPtr, Flow_RefQty) != 0.0)
                       { qty /= GET_NUMBER(flowPtr, Flow_RefQty); }

                    qty = TLS_RoundEnum(qty, RndUnit_0_00001, RndRule_Down);

                    SET_NUMBER(extOperation, ExtOp_AdjQty, qty);
                    break;
            }
            break;
                          
         case OpNat_Buy:
         case OpNat_Sell:
            qty = GET_NUMBER(stock, ExtPos_Qty) * 
                  (GET_PERCENT(flowPtr, Flow_Proba) / 100.0);
            if (GET_NUMBER((*instrPtr), A_Instr_ContractSize)  != 0)
               { qty /= GET_NUMBER((*instrPtr), A_Instr_ContractSize); }
            if (GET_NUMBER(flowPtr, Flow_RefQty) != 0.0)
               { qty /= GET_NUMBER(flowPtr, Flow_RefQty); }

	    if (treatRefNatFlg == TRUE)  /* REF3929 - SSO - 990909 */
	    {
		if (GET_ENUM(stock, ExtPos_RefNatEn) == PosRefNat_TermOpen)
		{
		    SET_ENUM(extOperation, ExtOp_RefNatEn, PosRefNat_TermClose);
		    scptFlagTabExtOp[ExtOp_RefNatEn]=TRUE;

		    COPY_DYNFLD(extOperation, ExtOp, ExtOp_RefOpCd,
				stock, ExtPos, ExtPos_OpenOpCd);
		    scptFlagTabExtOp[ExtOp_RefOpCd]=TRUE;

		    COPY_DYNFLD(extOperation, ExtOp, ExtOp_ValueDate,
				stock, ExtPos, ExtPos_ValDate);
		    scptFlagTabExtOp[ExtOp_ValueDate]=TRUE;
		}
	    }

            switch (GET_ENUM(flowPtr, Flow_EuroConvRuleEn))
            {
                case EuroConvRule_None: /* REF3089 - 990607 - DDV - Modificatioons for new method CashCompensationOld */

                    SET_PRICE(extOperation, ExtOp_Quote, 0);
                    SET_PRICE(extOperation, ExtOp_Price, 0);

                    qty = GET_NUMBER(stock, ExtPos_Qty) * (GET_PERCENT(flowPtr, Flow_Proba) / 100.0);

		    if (GET_NUMBER((*instrPtr), A_Instr_ContractSize)  != 0)
			{qty /= GET_NUMBER((*instrPtr), A_Instr_ContractSize); }

		    if (qty < 0)
		    { 
		        qty *=-1;
	                if (GET_ENUM(extOperation, ExtOp_NatureEn) == OpNat_Adjust)
		            sign=-1;
	                else
		            sign=+1;
		    }

		    oldInstrQty = qty;

		    if (GET_NUMBER(flowPtr, Flow_RefQty) != 0.0)
			{qty /= GET_NUMBER(flowPtr, Flow_RefQty); }

		    qty *= GET_NUMBER(flowPtr, Flow_QtyUnit);

		    newInstrQty = qty;

		    /* REF3089 - 990607 - DDV - implementation of rounding rule and cash compensation */ 
	            if (GET_NUMBER(flowPtr, Flow_NewInstrMinDenom) != 0.0)
		        roundUnit = GET_NUMBER(flowPtr, Flow_NewInstrMinDenom);
	            else if (GET_NUMBER(newInstrLocal, A_Instr_OddLotQty) != 0.0)
    		        roundUnit = GET_NUMBER(newInstrLocal, A_Instr_OddLotQty);
	            else
		        roundUnit = 1.0;

	            newInstrRoundedQty  = TLS_Round(qty, roundUnit, roundRule);

		    qty = newInstrRoundedQty * GET_NUMBER(flowPtr, Flow_RefQty);

		    if (GET_NUMBER(flowPtr, Flow_QtyUnit) != 0.0)
			{qty /= GET_NUMBER(flowPtr, Flow_QtyUnit); }

		    oldInstrRoundedQty = qty;

		    switch (qtyType)
		    { 
		       case QtyType_Rounded:
	                 SET_NUMBER(extOperation,      ExtOp_Qty, oldInstrRoundedQty*sign);
		         break;
	               case QtyType_Remain:
		             /* for remain quantiy, always use market price */
	                     SET_NULL_PRICE(extOperation, ExtOp_Price);
		             SET_NULL_PRICE(extOperation, ExtOp_Quote);
	                     scptFlagTabExtOp[ExtOp_Price]=FALSE;   
		             scptFlagTabExtOp[ExtOp_Quote]=FALSE;

	                     qty = oldInstrQty - oldInstrRoundedQty;
             
		             if (qty < 0)
			         {
		                   qty *=-1;
	                           /* for nearest rouding rule supposition was 'down' if not change operation and quantity sign */
		                   if (roundRule == RndRule_Nearest)
			           {
		                     if(GET_ENUM(extOperation, ExtOp_NatureEn) == OpNat_Sell)
				        {SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);}
	                             else
				        {SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);}
			           }
			         }
                    /* REF7479 - YST - 020409 - no operation should be created when quantity is zero */
                    if (qty == 0)
                        SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_None);
             
	                 SET_NUMBER(extOperation,      ExtOp_Qty, qty);
		         break;
	               case QtyType_Zero:
	                 SET_NUMBER(extOperation,      ExtOp_Qty, 0);
		         break;
	               case QtyType_NotRounded:
		       default:
	                 SET_NUMBER(extOperation,      ExtOp_Qty, CAST_NUMBER(oldInstrQty*sign));
		         break;
		    }

                    break;

                case EuroConvRule_BottomUpOneEuro:
                case EuroConvRule_BottomUpOneEuroLost: /* REF2957 - DDV - 981104 */

                    qty = (TLS_RoundEnum(qty * GET_NUMBER(flowPtr, Flow_QtyUnit),
                                         RndUnit_0_00001, RndRule_Down)) -
                          (TLS_RoundEnum(qty * GET_NUMBER(flowPtr, Flow_QtyUnit),
                                         RndUnit_1_00, RndRule_Down));
                    SET_NUMBER(extOperation, ExtOp_Qty, CAST_NUMBER(qty)); /* REF3288 - SSO - 990205 */
                    break;

                case EuroConvRule_BottomUpMinDenom:

                    qty = (TLS_RoundEnum(qty * GET_NUMBER(flowPtr, Flow_QtyUnit),
                                         RndUnit_0_00001, RndRule_Down)) -
                          (TLS_Round(qty * GET_NUMBER(flowPtr, Flow_QtyUnit),
                                     GET_NUMBER(flowPtr, Flow_NewInstrMinDenom), 
                                     RndRule_Down));
                    SET_NUMBER(extOperation, ExtOp_Qty, CAST_NUMBER(qty)); /* REF3288 - SSO - 990205 */
                    break;

                case EuroConvRule_TopDownOneEuro:
                    /* qty = (qty * GET_NUMBER(flowPtr, Flow_QtyUnit)) -
                          ( qty * TLS_RoundEnum(GET_NUMBER(flowPtr, Flow_QtyUnit), 
                                                RndUnit_1_00, RndRule_Down)); - REF6131.3511 - 010713 - DDV */

                    qty = (TLS_RoundEnum(qty * GET_NUMBER(flowPtr, Flow_QtyUnit),
                                         RndUnit_0_00001, RndRule_Down) ) -
                          (TLS_RoundEnum(qty * GET_NUMBER(flowPtr, Flow_QtyUnit), 
                                                RndUnit_1_00, RndRule_Down));
                    SET_NUMBER(extOperation, ExtOp_Qty, CAST_NUMBER(qty)); /* REF3288 - SSO - 990205 */
                    break;

                case EuroConvRule_TopDownMinDenom:

                    qty = (qty * GET_NUMBER(flowPtr, Flow_QtyUnit)) -
                          ( qty * TLS_Round(GET_NUMBER(flowPtr, Flow_QtyUnit), 
                                            GET_NUMBER(flowPtr, Flow_NewInstrMinDenom),
                                            RndRule_Down));
                    SET_NUMBER(extOperation, ExtOp_Qty, CAST_NUMBER(qty)); /* REF3288 - SSO - 990205 */
                    break;

                case EuroConvRule_TopDownMinLot:   /* Never call */
                case EuroConvRule_BottomUpOneCent: /* Never call */
                case EuroConvRule_TopDownOneCent:  /* Never call */
                case EuroConvRule_BottomUpMinDenomOneEuro:     /* REF6187 - DDV - 010810 */
                case EuroConvRule_BottomUpMinDenomOneCent: /* REF6187 - DDV - 010810 */
                case EuroConvRule_BottomUpHolding25Cents: /* REF6187 - DDV - 010810 */
                    break;
            }

      }
      /*FREE_DYNST(newInstrLocal, A_Instr);*/
   }
   return(RET_SUCCEED);
}

/*************************************************************************
**
**  Function    :   FIN_GenExtOpTermFlow()
**
**  Description :   Fill in extended operation generate for a term flow
** 		    For options :              
**		    cash : 
**		    - positive position - sell option at IV
**                  - negative position - buy option at IV
**                  IV = call : max (underlying price - exercice price, 0)
**                       put  : max (exercice price - underlying price, 0)
**                  physical :
**		    - positive position - sell option at 0
**                    - if IV > 0, (call) buy underlying or adjustment
**                                 (put) sell underlying or adjustment
**                  - negative position - buy option at 0
**                    - if IV > 0, (call) sell underlying or adjustment
**                                 (put) buy underlying or adjustment
**                 
**  Arguments   :                                        
**
**  Return      :                                         
**
**  Modif	: DVP440  - 970502 - RAK 
**		  BUG427  - 970708 - GRD 
** 		  BUG487  - 970902 - RAK 
** 		  REF233  - 971111 - RAK 
** 		  REF053  - 980420 - RAK 
**		  REF1055 - 991119 - AKO
**		  REF4938 - 000629 - AKO :  New treatment for FRA 
**        PMSTA-4559 - 011107 - PMO : Futures Management (margin calls)
**        PMSTA-17133 - 051113 - PMO : Many compilation warnings in C code especially " Converting a 64-bit type value to "int" causes truncation."
**        PMSTA-17898 - 160414 - PMO : New Fusion Criteria to manage the contract dates for margin calls after partial closing
**
*************************************************************************/
STATIC RET_CODE FIN_GenExtOpTermFlow(DBA_DYNFLD_STP    stock, 
                                    DBA_DYNFLD_STP    flowPtr,
                                    DBA_DYNFLD_STP    extOperation,
                                    DBA_DYNFLD_STP    *instrPtr,
                                    DBA_HIER_HEAD_STP hierHead,
                                    DATETIME_T        fromDateTime,
                                    FLAG_T            *scptFlagTabExtOp,
                                    int               posNbr,
                                    int               *posNbrToCreate,
                                    EVTPLRULE_ENUM    optionExercisePlRule,
                                    EVTPLRULE_ENUM    futuresSettlPlRule,
                                    OBJECT_ENUM       *objectOperation,
                                    FLAG_T            *dontCreateOp)
{
    NUMBER_T		qty;
    PRICE_T		quote=0.0;
    ID_T			dfltTpId;
    FLAG_T		cashFlg=FALSE, allocOk = FALSE;
    DBA_DYNFLD_STP	pricePtr=NULL, newInstrLocal=NULL, acctPos;
    FIN_PRICEARG_ST	priceArgSt;
    AMOUNT_T		instrAmt=0.0;
    RET_CODE		ret=RET_SUCCEED; /* REF1055 - AKO -991202 */
    MemoryPool              mp;

    /* Ref quantiy sign analysed in ext pos generation */
    if (GET_NUMBER(flowPtr, Flow_RefQty) == 0.0)
    {
        qty = GET_NUMBER(stock, ExtPos_Qty) * (GET_PERCENT(flowPtr, Flow_Proba) / 100.0);
    }
    else
    {
        qty = GET_NUMBER(stock, ExtPos_Qty) / GET_NUMBER(flowPtr, Flow_RefQty) *
              (GET_PERCENT(flowPtr, Flow_Proba) / 100.0);
    }

    SET_NUMBER(extOperation, ExtOp_Qty, CAST_NUMBER(qty)); /* REF3288 - SSO - 990205 */
                
    if (GET_ENUM((*instrPtr), A_Instr_NatEn) == InstrNat_Option ||  /* REF1055 - AKO 991125 : InstrNat_ExoticOptions */
        GET_ENUM((*instrPtr), A_Instr_NatEn) == InstrNat_ExoticOptions)
    {
        GEN_GetApplInfo(ApplOptionOpTpId, &dfltTpId);

        /* DVP440 - RAK - 970502 */
        /* if (GET_FLAG(flowPtr, Flow_PhysicalFlg) == FALSE || posNbr == 2) */
        if (posNbr == 1) 
        {
            /* Set Op nature */ 
            switch (optionExercisePlRule)
            {
            case EvtPlRule_Underlying:
                *objectOperation = AdjustOpEnt;
                SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Adjust);
                break;

            case EvtPlRule_Instrument:
                if (GET_NUMBER(stock, ExtPos_Qty) >= 0)
                {
                    *objectOperation = SellOpEnt;
                    SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);
                }
                else
                {
                    *objectOperation = BuyOpEnt;
                    SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);
                    SET_NUMBER(extOperation, ExtOp_Qty, 
		            GET_NUMBER(extOperation, ExtOp_Qty)*(-1));
                }
                break;
            }
            SET_PRICE(extOperation, ExtOp_Price, GET_PRICE(flowPtr, Flow_AmtUnit));
            if (GET_ENUM(extOperation, ExtOp_NatureEn) == OpNat_Adjust)
            {
                COPY_DYNFLD(extOperation, ExtOp, ExtOp_AdjInstrId, flowPtr, Flow, Flow_NewInstrId);
                scptFlagTabExtOp[ExtOp_AdjInstrId]=TRUE;   
   
                SET_ENUM(extOperation, ExtOp_AdjNatEn, OpAdjustNat_Pl);
                scptFlagTabExtOp[ExtOp_AdjNatEn]=TRUE;     
                            
                SET_NUMBER(extOperation, ExtOp_Qty, GET_NUMBER(extOperation, ExtOp_Qty)*(-1));
                            
                COPY_DYNFLD(extOperation, ExtOp, ExtOp_AdjPosCurrId, stock, ExtPos, ExtPos_PosCurrId);
                scptFlagTabExtOp[ExtOp_AdjPosCurrId]=TRUE; 
                                     
                SET_NUMBER(extOperation, ExtOp_AdjQty, 0);
                scptFlagTabExtOp[ExtOp_AdjQty]=TRUE;       
            }

            /* Allocate underlying instrument structure */
            if ((pricePtr = ALLOC_DYNST(A_InstrPrice)) == NULL)
            {
               MSG_RETURN(RET_MEM_ERR_ALLOC);
            }

	        /* REF233 - Call new fct which analyse instrument's nature for price calcualation */
	        if (FIN_GenExtOpNewInstrPrice(flowPtr, stock, fromDateTime, 
					       hierHead, pricePtr, NULL) != RET_SUCCEED)
	        {
                FREE_DYNST(pricePtr, A_InstrPrice);
                MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "Instrument Price");
                return(RET_DBA_ERR_NODATA);
	        }
            instrAmt = GET_PRICE(pricePtr, A_InstrPrice_Price);
            COPY_DYNFLD(extOperation, ExtOp, ExtOp_OpCurrId, pricePtr, A_InstrPrice, A_InstrPrice_CurrId);
            FREE_DYNST(pricePtr, A_InstrPrice);

            /* --------------------------------------------------------- */
	        /* REF1055 - AKO - 991129 : utiliser chrono.val pour le prix */
	        /* des Exotic Options RateLookback et AvrgRateAsian		 */
	        /* --------------------------------------------------------- */
	        if ((GET_ENUM((*instrPtr), A_Instr_SubNatEn) == SubNat_RateLookback) ||  
	            (GET_ENUM((*instrPtr), A_Instr_SubNatEn) == SubNat_AvrgRateAsian))
	        {	/* search instrChrono instrument */
	            DBA_DYNFLD_STP	instrChronoStp=NULL, dimChronoPtr=NULL;
	            NUMBER_T	chronoVal=0.0;
	            if ((instrChronoStp=ALLOC_DYNST(A_InstrChrono))==NULL)
	            {
		            FREE_DYNST(pricePtr, A_InstrPrice);
		            MSG_RETURN(RET_MEM_ERR_ALLOC);
	            }
	            if ((dimChronoPtr = ALLOC_DYNST(Dim_InstrChrono)) == NULL)
	            {
		            FREE_DYNST(instrChronoStp, A_InstrChrono);
		            MSG_RETURN(RET_MEM_ERR_ALLOC);
	            }
	            SET_ID(dimChronoPtr,       Dim_InstrChrono_InstrId, GET_ID((*instrPtr), A_Instr_Id));
	            SET_DATETIME(dimChronoPtr, Dim_InstrChrono_RefDate,fromDateTime);
	            if (GET_ENUM((*instrPtr), A_Instr_SubNatEn) == SubNat_RateLookback)
                {
		            SET_ENUM(dimChronoPtr, Dim_InstrChrono_NatEn, ChronoNat_LookbackCurrentExtreme);
                }
	            else
                {
		            SET_ENUM(dimChronoPtr, Dim_InstrChrono_NatEn, ChronoNat_AsianCurrentAverage);
                }
	            SET_FLAG(dimChronoPtr, Dim_InstrChrono_ComputeFlg,  FALSE);
	            if ((ret=FIN_InstrChrono(dimChronoPtr, (*instrPtr), instrChronoStp, hierHead))==RET_SUCCEED)
	            {
		            /* 
		            ** TGU-REF11704-060413-Use GET_LONGAMOUNT since data type for field 
		            ** instr_chrono.value_n has been changed from NUMBER to LONGAMOUTN. 
		            */
                    if (IS_NULLFLD(instrChronoStp, A_InstrChrono_Val) != TRUE)
                    {
                        chronoVal = GET_LONGAMOUNT(instrChronoStp, A_InstrChrono_Val);
                    }
		            else
                    {
                        ret=RET_FIN_ERR_INVDATA;
                    }
	            }
		        FREE_DYNST(dimChronoPtr, Dim_InstrChrono);
		        FREE_DYNST(instrChronoStp, A_InstrChrono);
		        if (RET_SUCCEED==ret)
		        {
                    if (chronoVal < 0)
                    {
                        chronoVal = 0; /* ??? */
                    }
		            instrAmt = chronoVal;
		        }
            }
   
            if (GET_ENUM(flowPtr, Flow_OptClassEn) == OptClass_Call)
            {
                /* IV =  max(underlying price - exercice price, 0) (instrAmt = instrAmt - X ) */
                instrAmt -= (GET_PRICE(flowPtr, Flow_AmtUnit));

	            /* REF3285 - Move SET_ after Flow_QtyUnit treatment */
                /* if (instrAmt > 0.0)
	            { SET_PRICE(extOperation, ExtOp_Price, instrAmt); }
                else
                { SET_PRICE(extOperation, ExtOp_Price, 0.0); } */

                if (CMP_NUMBER(instrAmt, 0.0) <= 0)
                {
                    instrAmt = 0.0;
                }
		
            }
            else
            {
	            /* IV =  max(exercice price - underlying price, 0) */
                instrAmt = GET_PRICE(flowPtr, Flow_AmtUnit) - instrAmt;

	            /* REF3285 - Move SET_ after Flow_QtyUnit treatment */
                /* if (instrAmt > 0.0)
                { SET_PRICE(extOperation, ExtOp_Price, instrAmt); }
                else
                { SET_PRICE(extOperation, ExtOp_Price, 0.0); } */

                if (CMP_NUMBER(instrAmt, 0.0) <= 0)
                {
                    instrAmt = 0.0;
                }
            }
	    
	        /* ------------------------------------------------------------ */
	        /* REF1055 - AKO - 991201 : calcul du 'Price/quote' spï¿½cifique  */
	        /* aux 'Exotic Option' concernï¿½s - Appel nouvelle routine	    */
	        /* FIN_GetDataRebateInTermEvt() retournant structure de prix    */
	        /* ------------------------------------------------------------ */
	        if 	((SubNat_OneTouchDigital==GET_ENUM((*instrPtr), A_Instr_SubNatEn)) ||
		        (SubNat_Barrier==GET_ENUM((*instrPtr), A_Instr_SubNatEn)) ||
		        (SubNat_Binary==GET_ENUM((*instrPtr), A_Instr_SubNatEn)) ||
		        (SubNat_DoubleKnockOut==GET_ENUM((*instrPtr), A_Instr_SubNatEn)))
	        {
		        DBA_DYNFLD_STP	    termEvt=NULL;
                PAYOFFREBATE_ST	rebateSt;

		        memset(&rebateSt,0,sizeof(PAYOFFREBATE_ST));        /* PMSTA-17133 - 051113 - PMO */
		        if ((ret=FIN_GetDataRebateInTermEvt((*instrPtr), &termEvt, fromDateTime, fromDateTime, 
						                            &rebateSt,hierHead))==RET_SUCCEED)
		        {
		            /* ---------------------------------------------------------------------- */
		            /* case when exotic option is not knocked out and different payoff nature */
		            /* and payoff nature is Binary or Asseton, other cases are treated above  */
		            /* ---------------------------------------------------------------------- */
		            switch (GET_ENUM(termEvt, A_TermEvt_PayOffNatEn))
		            {
			        case TermEvt_Payoff_Binary:
			        case TermEvt_Payoff_Asseton:
				        instrAmt = GET_PRICE(flowPtr, Flow_AmtUnit); 
			            break;
			        case TermEvt_Payoff_Vanilla:
			            break;
			        case TermEvt_Payoff_Gap:
			            break;
			        default:
			            ret= RET_DBA_ERR_NODATA;
		            }

		            /* -------------------------------------- */
		            /* case when exotic option is knocked out */
		            /* -------------------------------------- */
		            switch(GET_ENUM((*instrPtr), A_Instr_SubNatEn))
		            {
			        case SubNat_Barrier:
			            if (rebateSt.payOffStatus == Std_Rebate)
			            {
				            instrAmt = GET_PRICE(flowPtr, Flow_AmtUnit); /* rebateSt.payOffRebate;*/
			            }
			            break;
			        case SubNat_DoubleKnockOut:
			            if ((rebateSt.payOffStatus == Upper_Rebate) || (rebateSt.payOffStatus == Std_Rebate))
			            {
				            instrAmt = GET_PRICE(flowPtr, Flow_AmtUnit); 
			            }
			            break;
			        case SubNat_OneTouchDigital:
			            if (rebateSt.payOffStatus == Std_Rebate)
			            {
				            instrAmt = GET_PRICE(flowPtr, Flow_AmtUnit); 
			            }
			            break;
			        case SubNat_Binary: /* nothing to do */
			            break;
			        default:
			            ret= RET_DBA_ERR_NODATA;
		            }
		            FREE_DYNST(termEvt, A_TermEvt);
		        }
	        }

	        if (ret!=RET_SUCCEED) /* stop process */
	        {
		        FREE_DYNST(pricePtr, A_InstrPrice);
		        MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO,"FIN_GenExtOpTermFlow",
		            GET_CODE((*instrPtr), A_Instr_Cd),
		            "FIN_GetDataRebateInTermEvt failed");
		        return(RET_DBA_ERR_NODATA);
	        }

	        /* REF3285 - RAK - 990224 */
	        /* price must be multiplied by underlying qty which is stored in "Flow_QtyUnit" */
            if (CMP_NUMBER(GET_NUMBER(flowPtr, Flow_QtyUnit), 0.0) != 0)
            {
                instrAmt *= GET_NUMBER(flowPtr, Flow_QtyUnit);
            }
	        SET_PRICE(extOperation, ExtOp_Price, instrAmt);

            /* BUG427 - 970708 - GRD */
            if ((GET_FLAG(flowPtr, Flow_PhysicalFlg) == TRUE &&
                 (GET_PRICE(extOperation, ExtOp_Price) > 0))
                ||
                (InstrumentNature::isParticipatingForward(*instrPtr)  || /* PMSTA-34288 - CHU - 190224 */
                 InstrumentNature::isTargetKnockOutForward(*instrPtr) || /* PMSTA-34288 - CHU - 190224 */
                 InstrumentNature::isDecumulator(*instrPtr)           || /* PMSTA-34990 - CHU - 190329 */
                 (InstrumentNature::isAccumulator(*instrPtr) && (CMP_PRICE(GET_PRICE(extOperation, ExtOp_Price), 0.0) == 0))))
            {
               /* two operations must be generate (adjustment or buy or sell) */
               (*posNbrToCreate)++;		/* BUG487 */
               SET_PRICE(extOperation, ExtOp_Price, 0.0);
            }

            FIN_PriceToQuote((PRICECALCRULE_ENUM) GET_ENUM((*instrPtr), A_Instr_PriceCalcRuleEn), /* REF7264 - DDV - 020326 - Compil C++ */
                             GET_ID((*instrPtr), A_Instr_Id), 
                             (*instrPtr),
                             fromDateTime, 
                             NULL, 
                             GET_PRICE(extOperation, ExtOp_Price), 
                             &quote,
                             hierHead);
	        SET_PRICE(extOperation, ExtOp_Quote, quote); 
                       
            if (GET_NUMBER((*instrPtr), A_Instr_ContractSize)  != 0)
            {
                qty = GET_NUMBER(extOperation, ExtOp_Qty) / GET_NUMBER((*instrPtr), A_Instr_ContractSize);
                SET_NUMBER(extOperation,      ExtOp_Qty, CAST_NUMBER(qty)); /* REF3288 - SSO - 990205 */
            }

             if (GET_ENUM(stock, ExtPos_RefNatEn) == PosRefNat_FutOpen      || 
                 GET_ENUM(stock, ExtPos_RefNatEn) == PosRefNat_FRAOpen      ||  /* DVP440 */
                 GET_ENUM(stock, ExtPos_RefNatEn) == PosRefNat_FutWMP       ||  /* PMSTA-4559 - 011107 - PMO */
                 GET_ENUM(stock, ExtPos_RefNatEn) == PosRefNat_FutContract  ||  /* PMSTA-17898 - 160414 - PMO */
                 GET_ENUM(stock, ExtPos_RefNatEn) == PosRefNat_FutFifo)
             {
                COPY_DYNFLD(extOperation, ExtOp, ExtOp_RefOpCd, stock, ExtPos, ExtPos_OpenOpCd);
                scptFlagTabExtOp[ExtOp_RefOpCd]=TRUE;      
                            
                COPY_DYNFLD(extOperation, ExtOp, ExtOp_AcctId, stock, ExtPos, ExtPos_AcctExtPosId);
                scptFlagTabExtOp[ExtOp_AcctId]=TRUE;       
                            
                SET_ENUM(extOperation, ExtOp_RefNatEn, GET_ENUM(stock, ExtPos_RefNatEn));
                scptFlagTabExtOp[ExtOp_RefNatEn]=TRUE;   
	            scptFlagTabExtOp[ExtOp_Price]=TRUE;  /* REF1055 - AKO - 991202 */    
             }
        }
        else 	/* Physical flag == TRUE, second operation on underlying */
        {
            /* two operations must be generate */
            /* one like a cash settlement (physicalFlg == FALSE) and price = 0*/
            /* and an other Buy or Sell. */
            /* To create the first one, increment nb of pos to create */

            /* Allocate underlying instrument structure */
            if ((pricePtr = ALLOC_DYNST(A_InstrPrice)) == NULL)
            {
                MSG_RETURN(RET_MEM_ERR_ALLOC);
            }

            /* REF233 - Call new fct which analyse instrument's nature for price calcualation */
            if (FIN_GenExtOpNewInstrPrice(flowPtr, stock, fromDateTime,
                hierHead, pricePtr, &cashFlg) != RET_SUCCEED)
            {
                FREE_DYNST(pricePtr, A_InstrPrice);
                MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "Instrument Price");
                return(RET_DBA_ERR_NODATA);
            }

            if (!InstrumentNature::isParticipatingForward(*instrPtr)    &&
                !InstrumentNature::isTargetKnockOutForward(*instrPtr)   &&
                !InstrumentNature::isAccumulator(*instrPtr)             &&
                !InstrumentNature::isDecumulator(*instrPtr)) /* PMSTA-34288 - CHU - 190224 */
            {
                instrAmt = GET_PRICE(pricePtr, A_InstrPrice_Price);
            }

            /* REF233 */
            if (cashFlg == FALSE)
            {
                COPY_DYNFLD(extOperation, ExtOp, ExtOp_OpCurrId, pricePtr, A_InstrPrice, A_InstrPrice_CurrId);
            }
            FREE_DYNST(pricePtr, A_InstrPrice);

            if (GET_ENUM(flowPtr, Flow_OptClassEn) == OptClass_Call)
            {
                /* IV =  max(underlying price - exercice price, 0) */
                instrAmt -= (GET_PRICE(flowPtr, Flow_AmtUnit));
                if (instrAmt <= 0.0)
                {
                    if (!InstrumentNature::isParticipatingForward(*instrPtr)    &&
                        !InstrumentNature::isTargetKnockOutForward(*instrPtr)   &&
                        !InstrumentNature::isAccumulator(*instrPtr)             &&
                        !InstrumentNature::isDecumulator(*instrPtr)) /* PMSTA-34288 - CHU - 190224 */
                    {
                        *dontCreateOp = TRUE;
                    }
                }
            }
            else
            {
                /* IV =  max(exercice price - underlying price, 0) */
                instrAmt = GET_PRICE(flowPtr, Flow_AmtUnit) - instrAmt;
                if (instrAmt <= 0.0)
                {
                    if (!InstrumentNature::isParticipatingForward(*instrPtr)    &&
                        !InstrumentNature::isTargetKnockOutForward(*instrPtr)   &&
                        !InstrumentNature::isAccumulator(*instrPtr)             &&
                        !InstrumentNature::isDecumulator(*instrPtr)) /* PMSTA-34288 - CHU - 190224 */
                    {
                        *dontCreateOp = TRUE;
                    }
                }
            }

            if (InstrumentNature::isParticipatingForward(*instrPtr)     ||
                InstrumentNature::isTargetKnockOutForward(*instrPtr)    ||
                InstrumentNature::isAccumulator(*instrPtr)              ||
                InstrumentNature::isDecumulator(*instrPtr)) /* PMSTA-34288 - CHU - 190224 */
            {
                if (InstrumentNature::isDecumulator(*instrPtr)) /* PMSTA-34990 - CHU - 190329 */
                {
                    *objectOperation = SellOpEnt;
                    SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);
                }
                else
                {
                    *objectOperation = BuyOpEnt;
                    SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);
                }

            }
            else
            {
                /* posNbrToCreate++; */ /* DVP440 - RAK - 970502 */
                if ((GET_NUMBER(stock, ExtPos_Qty) >= 0 && GET_ENUM(flowPtr, Flow_OptClassEn) == OptClass_Call)
                    ||
                    (GET_NUMBER(stock, ExtPos_Qty) < 0 && GET_ENUM(flowPtr, Flow_OptClassEn) == OptClass_Put))
                {
                    *objectOperation = BuyOpEnt;
                    SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);
                }
                else
                {
                    *objectOperation = SellOpEnt;
                    SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);
                }
            }
            COPY_DYNFLD(extOperation, ExtOp, ExtOp_InstrId, flowPtr, Flow, Flow_NewInstrId);

	        /* REF233 - In case of cash accounts, force price and accounting and use strike price */
	        if (cashFlg == TRUE)
	        {
		        DBA_DYNFLD_STP	dfltCashPtr=NULL;

		        SET_PRICE(extOperation, ExtOp_Price, 1.0);
		        SET_PRICE(extOperation, ExtOp_Quote, 1.0);
                scptFlagTabExtOp[ExtOp_Price] = TRUE;      
                scptFlagTabExtOp[ExtOp_Quote] = TRUE;      

                /* < PMSTA-34288 - 190221 - CHU */
                if (InstrumentNature::isParticipatingForward(*instrPtr) ||
                    InstrumentNature::isTargetKnockOutForward(*instrPtr))
                {
                    SET_EXCHANGE(extOperation, ExtOp_OpExchRate, GET_EXCHANGE(flowPtr, Flow_FxdExchRate));
                    SET_EXCHANGE(extOperation, ExtOp_AcctExchRate, GET_EXCHANGE(flowPtr, Flow_FxdExchRate));
                    scptFlagTabExtOp[ExtOp_AcctExchRate] = TRUE;
                } /* > PMSTA-34288 - 190221 - CHU */
                else
                {
                    SET_EXCHANGE(extOperation, ExtOp_AcctExchRate, GET_PRICE((*instrPtr), A_Instr_RedempPrice));
                }
                scptFlagTabExtOp[ExtOp_OpExchRate] = TRUE;

         	    if ((dfltCashPtr = ALLOC_DYNST(A_Instr)) == NULL)
		        {
                    MSG_RETURN(RET_MEM_ERR_ALLOC);
		        }

		        if ((ret = FIN_PtfDefAccount(GET_ID(stock, ExtPos_PtfId), 
					                            GET_ID((*instrPtr), A_Instr_RefCurrId),
				                                GET_ENUM(extOperation, ExtOp_NatureEn), 0, 0, 
					                            dfltCashPtr, hierHead)) != RET_SUCCEED)
		        {
            	    FREE_DYNST(dfltCashPtr, A_Instr);
                    return(ret);
		        }

		        /* REF965 - Verify returned accounting currency */
		        if (GET_ID((*instrPtr), A_Instr_RefCurrId) != GET_ID(dfltCashPtr, A_Instr_RefCurrId))
		        {
			        DBA_DYNFLD_STP	getArgSt=NULL;

         		    if ((getArgSt = ALLOC_DYNST(Get_Arg)) == NULL)
			        {
                        FREE_DYNST(dfltCashPtr, A_Instr);
			            MSG_RETURN(RET_MEM_ERR_ALLOC);
			        }
			
			        SET_ID(getArgSt, Get_Arg_RefCurrId, GET_ID((*instrPtr), A_Instr_RefCurrId));
			        SET_ENUM(getArgSt, Get_Arg_NatEn, (ENUM_T)InstrNat_CashAcct);

			        if ((ret = DBA_Get2(Instr, UNUSED, Get_Arg, getArgSt, 
				                        A_Instr, &dfltCashPtr, 
					                    UNUSED, UNUSED, UNUSED)) != RET_SUCCEED)
			        {
                        FREE_DYNST(dfltCashPtr, A_Instr);
                        FREE_DYNST(getArgSt, Get_Arg);
			            return(ret);
			        }
			        FREE_DYNST(getArgSt, Get_Arg);
		        }
		        SET_ID(extOperation, ExtOp_AcctId, GET_ID(dfltCashPtr, A_Instr_Id));
                scptFlagTabExtOp[ExtOp_AcctId] = TRUE;      

                FREE_DYNST(dfltCashPtr, A_Instr);
	        }
                        
            /* REF3913 - 990819 - DDV */
            if (DBA_GetInstrById(GET_ID(flowPtr, Flow_NewInstrId), TRUE, &allocOk, 
                                 &newInstrLocal, hierHead, UNUSED, UNUSED) != RET_SUCCEED)
            {
                MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "Instr");
                return(RET_DBA_ERR_NODATA);
            }
            *instrPtr = newInstrLocal;

            /* REF233 - ExtOp_InstrCurrId depending on ExtOp_InstrId */
            COPY_DYNFLD(extOperation, ExtOp, ExtOp_InstrCurrId, (*instrPtr), A_Instr, A_Instr_RefCurrId); 

            qty = GET_NUMBER(extOperation, ExtOp_Qty);
            if (GET_NUMBER((*instrPtr), A_Instr_ContractSize)  != 0)
            {
                qty /= GET_NUMBER((*instrPtr), A_Instr_ContractSize);
            }
            qty *= GET_NUMBER(flowPtr, Flow_QtyUnit);
            SET_NUMBER(extOperation, ExtOp_Qty, fabs(qty));
                        
	        /* REF233 - Already updated */
	        if (cashFlg == FALSE)
	        { 
	            SET_PRICE(extOperation, ExtOp_Price, GET_PRICE(flowPtr, Flow_AmtUnit)); 
	            scptFlagTabExtOp[ExtOp_Price]=TRUE;  /* REF1055 - AKO - 991202 */    
	            COPY_DYNFLD(extOperation, ExtOp, ExtOp_OpCurrId,flowPtr, Flow, Flow_AmtCurrId);
	        }
	        else
	        {
                COPY_DYNFLD(extOperation, ExtOp, ExtOp_OpCurrId, (*instrPtr), A_Instr, A_Instr_RefCurrId); 
	        }
        }
    }    
    else if (GET_ENUM((*instrPtr), A_Instr_NatEn) == InstrNat_Future ||
             GET_ENUM((*instrPtr), A_Instr_NatEn) == InstrNat_FRA)		/* DVP440 */
    {
        GEN_GetApplInfo(ApplFutureOpTpId, &dfltTpId);
                
        if (GET_ENUM(stock, ExtPos_RefNatEn) == PosRefNat_FutClose ||
            GET_ENUM(stock, ExtPos_RefNatEn) == PosRefNat_FRAClose)		/* DVP440 */
        {
            /*FREE_DYNST(extOperation, ExtOp);
            FREE(scptFlagTabExtOp); - REFLASTALPHABUG - DDV - 980430-15h10 */
            *dontCreateOp = TRUE;
            return(RET_SUCCEED);
        }
                
        /* DVP440 - RAK - 970502 */
        /* if (GET_FLAG(flowPtr, Flow_PhysicalFlg) == FALSE || posNbr == 2) */
        if (posNbr == 1)
        {
            /* Set Op nature */
            switch (futuresSettlPlRule)
            {
            case EvtPlRule_Underlying:
                *objectOperation = AdjustOpEnt;
                SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Adjust);
                break;
            case EvtPlRule_Instrument:
                if (GET_NUMBER(stock, ExtPos_Qty) >= 0)
                {
                    *objectOperation = SellOpEnt;
                    SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);
                }
                else
                {
                    *objectOperation = BuyOpEnt;
                    SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);
                    SET_NUMBER(extOperation, ExtOp_Qty, 
                    GET_NUMBER(extOperation, ExtOp_Qty)*(-1));
                }
                break;
            }
                    
	        if (GET_ENUM((*instrPtr), A_Instr_NatEn) == InstrNat_FRA)		/* REF053 */
	        {   /* ----------------------------------------------- */
	            /* REF4938 - AKO - 000629 :  New treatment for FRA */
	            /* ----------------------------------------------- */
                /* SET_PRICE(extOperation, ExtOp_Price, GET_PRICE(flowPtr, Flow_AmtUnit)); */
	            if ((pricePtr = ALLOC_DYNST(A_InstrPrice)) == NULL)
	            {
		            MSG_RETURN(RET_MEM_ERR_ALLOC);
	            }

	            if ( (IS_NULLFLD((*instrPtr), A_Instr_EndDate)==FALSE) &&	
		            (GET_DATE((*instrPtr), A_Instr_EndDate)!=MAGIC_END_DATE) &&
		            (stock != NULL))
	            {
		            memset(&priceArgSt, 0, sizeof(FIN_PRICEARG_ST));
		            priceArgSt.discFacDate = fromDateTime;
		            priceArgSt.expirDate = GET_DATETIME((*instrPtr), A_Instr_EndDate);

		            if (FIN_InstrPrice(GET_ID(flowPtr, Flow_InstrId), 
				                       (*instrPtr),
				                       GET_DATETIME((*instrPtr), A_Instr_EndDate),
				                       NULL, 0, &priceArgSt, NULL, 
				                       stock, hierHead, pricePtr, FALSE) != RET_SUCCEED) /* PMSTA14876 - DDV - 120911 - Add a new parameter, no impact for this call */
		            {
		                FREE_DYNST(pricePtr, A_InstrPrice);
		                MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "Instrument Price");
		                return(RET_DBA_ERR_NODATA);
		            }
		            SET_PRICE(extOperation, ExtOp_Price, GET_PRICE(pricePtr, A_InstrPrice_Price));
	            }
	            FREE_DYNST(pricePtr, A_InstrPrice);
	        }
	        else
	        {
                /* Allocate instrument price structure */
                if ((pricePtr = ALLOC_DYNST(A_InstrPrice)) == NULL)
                {
            	    MSG_RETURN(RET_MEM_ERR_ALLOC);
                }

                /* DVP440 - RAK - 970501 */
                if (stock != NULL) 
                {
                    priceArgSt.costQuote = GET_PRICE(stock, ExtPos_Quote);
                }
   
                /* Compute instrument price, which will be amount per unit */
                if (FIN_InstrPrice(GET_ID(flowPtr, Flow_InstrId), 
                                (*instrPtr), 
                                GET_DATETIME(extOperation, ExtOp_AcctDate), 
                                NULL, 0, &priceArgSt, NULL, 
                                stock, hierHead, pricePtr, FALSE) != RET_SUCCEED) /* PMSTA14876 - DDV - 120911 - Add a new parameter, no impact for this call */
                {
                    FREE_DYNST(pricePtr, A_InstrPrice);
                    MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "Instrument Price");
                    return(RET_DBA_ERR_NODATA);
                }
                SET_PRICE(extOperation, ExtOp_Price, GET_PRICE(pricePtr, A_InstrPrice_Price));
                SET_PRICE(extOperation, ExtOp_Quote,GET_PRICE(pricePtr, A_InstrPrice_Quote))
                FREE_DYNST(pricePtr, A_InstrPrice);
	        }

            if (GET_ENUM(extOperation, ExtOp_NatureEn) == OpNat_Adjust)
            {
                COPY_DYNFLD(extOperation, ExtOp, ExtOp_AdjInstrId, flowPtr, Flow, Flow_NewInstrId);
                scptFlagTabExtOp[ExtOp_AdjInstrId]=TRUE;   
                               
                SET_ENUM(extOperation, ExtOp_AdjNatEn, OpAdjustNat_Pl);
                scptFlagTabExtOp[ExtOp_AdjNatEn]=TRUE;     
                            
                SET_NUMBER(extOperation, ExtOp_Qty, GET_NUMBER(extOperation, ExtOp_Qty)*(-1));
                                  
                COPY_DYNFLD(extOperation, ExtOp, ExtOp_AdjPosCurrId, stock, ExtPos, ExtPos_PosCurrId);
                scptFlagTabExtOp[ExtOp_AdjPosCurrId]=TRUE; 
                            
                SET_NUMBER(extOperation, ExtOp_AdjQty, 0);
                scptFlagTabExtOp[ExtOp_AdjQty]=TRUE;       
            }
                    
            if (GET_NUMBER((*instrPtr), A_Instr_ContractSize)  != 0)
            {
                qty = GET_NUMBER(extOperation, ExtOp_Qty) / GET_NUMBER((*instrPtr), A_Instr_ContractSize);
                SET_NUMBER(extOperation, ExtOp_Qty, CAST_NUMBER(qty)); /* REF3288 - SSO - 990205 */
            }
   
            COPY_DYNFLD(extOperation, ExtOp, ExtOp_RefOpCd, stock, ExtPos, ExtPos_OpenOpCd);
            scptFlagTabExtOp[ExtOp_RefOpCd]=TRUE;      
                            
            if (GET_EXTENSION_PTR(stock, ExtPos_Acct_ExtPos_Ext) != NULL &&
                (acctPos = *(GET_EXTENSION_PTR(stock, ExtPos_Acct_ExtPos_Ext))) != NULL)
            {
                COPY_DYNFLD(extOperation, ExtOp, ExtOp_AcctId, acctPos, ExtPos, ExtPos_InstrId);
                scptFlagTabExtOp[ExtOp_AcctId]=TRUE; 
            }
                            
            if (GET_ENUM(stock, ExtPos_RefNatEn) == PosRefNat_FutOpen) 
	        {
                SET_ENUM(extOperation, ExtOp_RefNatEn, PosRefNat_FutClose);
            }
            else if (GET_ENUM(stock, ExtPos_RefNatEn) == PosRefNat_FRAOpen)	/* DVP440 */
	        {
                SET_ENUM(extOperation, ExtOp_RefNatEn, PosRefNat_FRAClose);
            }
            else
	        {
                SET_ENUM(extOperation, ExtOp_RefNatEn, GET_ENUM(stock, ExtPos_RefNatEn));
            }
            scptFlagTabExtOp[ExtOp_RefNatEn]=TRUE;      

         /* DVP440 - RAK - 970502 */
            if (GET_FLAG(flowPtr, Flow_PhysicalFlg) == TRUE &&
                GET_ENUM(extOperation, ExtOp_NatureEn) != (ENUM_T) OpNat_Adjust)
            {
                /* two operations must be generate */
	            (*posNbrToCreate)++;		/* BUG487 */
            }
        }
        else 	/* Physical flag == TRUE, second operation on underlying */
        {
            /* two operations must be generate */
            /* one like a cash settlement (physicalFlg == FALSE) and price = 0*/
            /* and an other Buy or Sell. */
            /* To create the first one, increment nb of pos to create */
         
            /* posNbrToCreate++; */ /* DVP440 - RAK - 970502 */

            if (GET_NUMBER(stock, ExtPos_Qty) >= 0)
            {
                *objectOperation = BuyOpEnt;
                SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);
            }
            else
            {
                *objectOperation = SellOpEnt;
                SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);
                SET_NUMBER(extOperation, ExtOp_Qty, 
		        GET_NUMBER(extOperation, ExtOp_Qty)*(-1));
            }
                    
            COPY_DYNFLD(extOperation, ExtOp, ExtOp_InstrId, flowPtr, Flow, Flow_NewInstrId);
                           
            /* REF3913 - 990819 - DDV */
            if (DBA_GetInstrById(GET_ID(flowPtr, Flow_NewInstrId), TRUE, &allocOk, 
                                 &newInstrLocal, hierHead, UNUSED, UNUSED) != RET_SUCCEED)
            {
                MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "Instr");
                return(RET_DBA_ERR_NODATA);
            }
            *instrPtr = newInstrLocal;

            /* REF233 - ExtOp_InstrCurrId depending on ExtOp_InstrId */
            COPY_DYNFLD(extOperation, ExtOp, ExtOp_InstrCurrId, (*instrPtr), A_Instr, A_Instr_RefCurrId); 

            qty = GET_NUMBER(extOperation, ExtOp_Qty);
            if (GET_NUMBER((*instrPtr), A_Instr_ContractSize)  != 0)
            {
                qty /= GET_NUMBER((*instrPtr), A_Instr_ContractSize);
            }
            qty *= GET_NUMBER(flowPtr, Flow_QtyUnit);
            SET_NUMBER(extOperation, ExtOp_Qty, CAST_NUMBER(qty)); /* REF3288 - SSO - 990205 */
            /* REF1055 - AKO - 991119 :  get data from flow */                 
            /* SET_PRICE(extOperation, ExtOp_Price, GET_PRICE(stock, ExtPos_Price)); */
            /* SET_PRICE(extOperation, ExtOp_Quote, GET_PRICE(stock, ExtPos_Quote)); */
	        SET_PRICE(extOperation, ExtOp_Price, GET_PRICE(flowPtr, Flow_AmtUnit)); 
	        SET_PRICE(extOperation, ExtOp_Quote, GET_PRICE(flowPtr, Flow_Quote));
            COPY_DYNFLD(extOperation, ExtOp, ExtOp_OpCurrId, flowPtr, Flow, Flow_AmtCurrId);
        }
    }
    else if (GET_ENUM((*instrPtr), A_Instr_NatEn) == InstrNat_Forward)
    {
        GEN_GetApplInfo(ApplForwardOpTpId, &dfltTpId);
                
        if (GET_ENUM(stock, ExtPos_RefNatEn) != PosRefNat_FwdOpen) 
        {
            /*FREE_DYNST(extOperation, ExtOp);
            FREE(scptFlagTabExtOp); - REFLASTALPHABUG - DDV - 980430-15h10 */
            *dontCreateOp = TRUE;
            return(RET_SUCCEED);
        }
                   
        if (GET_NUMBER(stock, ExtPos_Qty) >= 0)
        {
            *objectOperation = SellOpEnt;
            SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);
        }
        else
        {
            *objectOperation = BuyOpEnt;
            SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);
            SET_NUMBER(extOperation, ExtOp_Qty, GET_NUMBER(extOperation, ExtOp_Qty)*(-1));
        }

        if (CMP_NUMBER(GET_NUMBER((*instrPtr), A_Instr_ContractSize), 0.0)  != 0)
        {
            qty = GET_NUMBER(extOperation, ExtOp_Qty) / GET_NUMBER((*instrPtr), A_Instr_ContractSize);
            SET_NUMBER(extOperation, ExtOp_Qty, CAST_NUMBER(qty)); /* REF3288 - SSO - 990205 */
        }

        SET_PRICE(extOperation, ExtOp_Price, GET_PRICE(stock, ExtPos_Price));
        SET_PRICE(extOperation, ExtOp_Quote, GET_PRICE(stock, ExtPos_Quote));
        // scptFlagTabExtOp[ExtOp_Price] = FALSE; 
        // scptFlagTabExtOp[ExtOp_Quote] = FALSE; 

        /* REF6925 - DDV - 020103 - Move it to set set exchange rate only if account is set 
        if (GET_PRICE(stock, ExtPos_Price)  != 0)
        {
            SET_EXCHANGE(extOperation, ExtOp_AcctExchRate, 1.0 / GET_PRICE(stock, ExtPos_Price));
            scptFlagTabExtOp[ExtOp_AcctExchRate]=TRUE;      
        } */
                       
        SET_ENUM(extOperation, ExtOp_RefNatEn, PosRefNat_FwdClose);
        scptFlagTabExtOp[ExtOp_RefNatEn]=TRUE;      
                    
        COPY_DYNFLD(extOperation, ExtOp, ExtOp_RefOpCd, stock, ExtPos, ExtPos_OpenOpCd);
        scptFlagTabExtOp[ExtOp_RefOpCd]=TRUE;      
    }
    return(RET_SUCCEED);
}

/*************************************************************************
**
**  Function    :   FIN_GenExtOpNewInstrPrice()
**
**  Description :   Search new instrument price.
**                  For cash account it's exchange rate, elsewhere call FIN_InstrPrice().
**                 
**  Arguments   :   flowPtr	 flow structure pointer
** 		    stock	 stock structure pointer
**		    fromDateTime date
**		    hierHead	 hierarchy header
**		    pricePtr	 price structure pointer
**
**  Return      :   RET_SUCCEED or error code
**
**  Modif	:   REF233 - 971111 - RAK 
**  Modif.	:   REF2580 - SSO - 980727
**
*************************************************************************/
STATIC RET_CODE FIN_GenExtOpNewInstrPrice(DBA_DYNFLD_STP    flowPtr,
					  DBA_DYNFLD_STP    stock, 
					  DATETIME_T        fromDateTime, 
                                          DBA_HIER_HEAD_STP hierHead,
					  DBA_DYNFLD_STP    pricePtr,
					  FLAG_T	    *cashFlg)
{
	DBA_DYNFLD_STP	newInstrPtr=NULL;
	char		hierFlg=FALSE;
	EXCHANGE_T	exch=0.0;
	RET_CODE 	ret=RET_SUCCEED;

	if ((ret = FIN_GetHierInstr((PTR) hierHead, GET_ID(flowPtr, Flow_NewInstrId), 
				    &hierFlg, &newInstrPtr)) != RET_SUCCEED)
	{
		return(ret);
	}

	if ((INSTRNAT_ENUM) GET_ENUM(newInstrPtr, A_Instr_NatEn) == InstrNat_CashAcct)
	{
	    FIN_EXCHARG_ST  exchArgSt;			/* REFXZ */
	    memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));
	    /* DBA_SetConnectNoToExchArg(&exchArgSt, DBA_GetConnectNoFromHier(hierHead)); *//* REF2580 - SSO - 980727 */
	    DBA_InitConnectNoToExchArg(&exchArgSt, hierHead); /* REF4213 - SSO - 991221 */

	    if (cashFlg != NULL)
	    	*cashFlg = TRUE;

	    if ((ret = FIN_GetExchRate(fromDateTime,
								    GET_ID(newInstrPtr, A_Instr_RefCurrId), 
								    GET_ID(flowPtr, Flow_AmtCurrId),
									0,
									NULL,
									stock,
									&exchArgSt,
									&exch)) == RET_SUCCEED)	/* PMSTA01649 - TGU - 070402*/
	    {
		    SET_PRICE(pricePtr, A_InstrPrice_Price,  exch);
            SET_ID(pricePtr,     A_InstrPrice_CurrId, GET_ID(flowPtr, Flow_AmtCurrId));
	    }
	}
	else
	{
	    if (cashFlg != NULL)
	    	*cashFlg = FALSE;

            /* Compute underlying instrument price, which will be amount per unit */
            ret = FIN_InstrPrice(GET_ID(flowPtr, Flow_NewInstrId), newInstrPtr, 
				                 fromDateTime, NULL, 0, NULL, NULL, stock, 
			                     hierHead, pricePtr, FALSE); /* PMSTA14876 - DDV - 120911 - Add a new parameter, no impact for this call */
	}

	if (hierFlg == FALSE) 
	{ FREE_DYNST(newInstrPtr, A_Instr); }

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_CmpPosPtfInstr()
**
**  Description :   Position table is sort by portfolio and instrument
**
**  Arguments   :   ptr1   pointer on dynamic structure type ExtPos
**                  ptr2   pointer on dynamic structure type ExtPos
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
*************************************************************************/
STATIC int FIN_CmpPosPtfInstr(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
        ID_T                cmp=0; /* PMSTA08801 - DDV - 091126 */
        ID_T                instrId1=(ID_T) 0, instrId2=(ID_T) 0;
    	DBA_DYNFLD_STP      instrPtr=NULL;

	if (*ptr1 == NULL && *ptr2 == NULL) /* BUG329 - XDI - 970409 */
		return(0);
	else if (*ptr1 == NULL)
		return(1);
	else if (*ptr2 == NULL)
		return(-1);

    cmp = CMP_DYNFLD((*ptr1), (*ptr2), ExtPos_PtfId, ExtPos_PtfId, IdType); /* PMSTA08801 - DDV - 091126 */
    
    /* PMSTA08801 - DDV - 091126 */
    if (cmp > 0)
	    return(1);
    else if (cmp < 0)
	    return(-1);

	/* if generic instrument, sort by parent instrument */
    if (GET_ID((*ptr1), ExtPos_InstrId) < 0)
    {
		/* get instrument structure */
  		if (GET_EXTENSION_PTR((*ptr1), ExtPos_A_Instr_Ext) != NULL)
    	{
   			instrPtr = *(GET_EXTENSION_PTR((*ptr1), ExtPos_A_Instr_Ext));
            instrId1 = GET_ID(instrPtr, A_Instr_ParentInstrId);
	    }
    }
	else
	{
		instrId1=GET_ID((*ptr1), ExtPos_InstrId);
	}

    if (GET_ID((*ptr2), ExtPos_InstrId) < 0)
    {
    	/* get instrument structure */
    	if (GET_EXTENSION_PTR((*ptr2), ExtPos_A_Instr_Ext) != NULL)
		{
    		instrPtr = *(GET_EXTENSION_PTR((*ptr2), ExtPos_A_Instr_Ext));
       		instrId2 = GET_ID(instrPtr, A_Instr_ParentInstrId);
		}
    }
	else
	{
		instrId2=GET_ID((*ptr2), ExtPos_InstrId);
	}

    cmp = instrId1 - instrId2;

    /* PMSTA08801 - DDV - 091126 */
    if (cmp > 0)
	    return(1);
    else if (cmp < 0)
	    return(-1);
    else
        return(0);

}

/************************************************************************
**
**  Function    :   FIN_CmpPosInstr()
**
**  Description :   Position table is sort by instrument , portfolio,
**                  operation nature, Event number and Event code,
**                  op nature, adjustment nature, ref nature, ref oper code
**
**  Arguments   :   ptr1   pointer on dynamic structure type ExtPos
**                  ptr2   pointer on dynamic structure type ExtPos
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
*************************************************************************/
STATIC int FIN_CmpPosInstr(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
        int                 cmp=0;
        ID_T                instrId1=(ID_T) 0, instrId2=(ID_T) 0;
    	DBA_DYNFLD_STP      instrPtr=NULL;

	if (*ptr1 == NULL && *ptr2 == NULL) /* BUG329 - XDI - 970409 */
		return(0);
	else if (*ptr1 == NULL)
		return(1);
	else if (*ptr2 == NULL)
		return(-1);

	/* if generic instrument, sort by parent instrument */
        if (GET_ID((*ptr1), ExtPos_InstrId) < 0)
        {
    		/* get instrument structure */
    		if (GET_EXTENSION_PTR((*ptr1), ExtPos_A_Instr_Ext) != NULL)
		{
    			instrPtr = *(GET_EXTENSION_PTR((*ptr1), ExtPos_A_Instr_Ext));

            		instrId1 = GET_ID(instrPtr, A_Instr_ParentInstrId);
		}
        }
	else
	{
		instrId1=GET_ID((*ptr1), ExtPos_InstrId);
	}

        if (GET_ID((*ptr2), ExtPos_InstrId) < 0)
        {
    		/* get instrument structure */
    		if (GET_EXTENSION_PTR((*ptr2), ExtPos_A_Instr_Ext) != NULL)
		{
    			instrPtr = *(GET_EXTENSION_PTR((*ptr2), ExtPos_A_Instr_Ext));

            		instrId2 = GET_ID(instrPtr, A_Instr_ParentInstrId);
		}
        }
	else
	{
		instrId2=GET_ID((*ptr2), ExtPos_InstrId);
	}

        if ((cmp = CMP_ID(instrId1 , instrId2)) != 0)	/* DLA - REF9089 - 030508 */
		return(cmp);

        if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2),
                              ExtPos_PtfId, ExtPos_PtfId, IdType)) != 0)	
		return(cmp);

        if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2),
                              ExtPos_EvtNbr, ExtPos_EvtNbr, NumberType)) != 0)	
		return(cmp);

        if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2),
                              ExtPos_EvtCd, ExtPos_EvtCd, CodeType)) != 0)	
		return(cmp);

        if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2),
                              ExtPos_OpenOpNatEn, ExtPos_OpenOpNatEn, EnumType)) != 0)	
		return(cmp);

        if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2),
                              ExtPos_AdjustNatEn, ExtPos_AdjustNatEn, EnumType)) != 0)	
		return(cmp);

        if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2),
                              ExtPos_RefNatEn, ExtPos_RefNatEn, EnumType)) != 0)	
		return(cmp);

        if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2),
                              ExtPos_RefOpCd, ExtPos_RefOpCd, CodeType)) != 0)	
		return(cmp);

	return(0);
}

/************************************************************************
**
**  Function    :   FIN_CheckExistPos()
**
**  Description :   Check if position with same instrument, portfolio,
**                  event number, event code and nature exit.
**
**  Arguments   :   extractPos   Array of all positions (sorted by instr, ptf, 
**                               nature, EvtNbr, EvtCd).
**                  posNbr       Number of position in extractPos
**                  extOperation generated operation to check if exist
**                  listPtr      need it to call DBA_CheckInstrDim
**                  domainPtr    domain pointer
**                  hierHead     pointer on hierarchy
**                  existPosFlg: output parameter set to: 
**                                      TRUE  if position exist
**                                      FALSE if position doesn't exist
**
**  Return      :   RET_SUCCEED  if no problem
**                  RET_MEM_ERR_ALLOC memory allocation error
**                  return codes from DBA_Get2, DBA_GetInstrById 
**                      if error in called functions DBA_Get2, DBA_GetInstrById
**                  
** Modif        :   REF1434-REF1435 - DDV - 980318 Check after position generation not before
** Modif        :   REF2270 - DDV - Add criteria posRefNat and OpenOpCd (rewrite of procedure)
** Modif        :   REF3740 - DDV - 990804 - Add criteria adjInstrId
** Modif        :   REF3740 - DDV - 990804 - instrId must be check with extract pos  criteria adjInstrId
** Modif        :   REF3939 - CSY - 991103 - call stored procedure if not in instrument dimension.
** Modif        :   REF3939 - CSY - 000105 - call stored procedure (through DBA_Get2)
**                                           get_open_oper_id_for_event.
**                                           return RET_CODE instead of FLAG_T
**                                           new output parameter existPosFlg (FLAG_T)
** Modif        :   REF3939 - CSY - 000117 - REF4242: comparision between extOperation instr_id and 
**                                                    extractPos instr_id (or parent instr_id)
**
*************************************************************************/
STATIC RET_CODE FIN_CheckExistPos(DBA_DYNFLD_STP    *extractPos, 
				                  int               posNbr, 
				                  DBA_DYNFLD_STP    extOperation,
				                  DBA_DYNFLD_STP    *listPtr,  /* REF3939 - CSY - 991103 : need domainPtr,listPtr and hierHead */
				                  DBA_DYNFLD_STP    domainPtr, /* to call DBA_CheckInstrDim */
				                  DBA_HIER_HEAD_STP hierHead,
				                  FLAG_T            *existPosFlg,
                                  FLAG_T            onlyStandInstructFlg,  /* REF3939 - CSY - 000105 */
                                  DBA_DYNFLD_STP    stock,
                                  FLAG_T            checkPtfDimFlg) 
{
    int                 i=0;
    ID_T                instrId=(ID_T) 0;
    DBA_DYNFLD_STP      instrPtr=NULL, adjPosPtr=NULL, ptfPtr=NULLDYNST;
    FLAG_T              found=FALSE; 
    FLAG_T              allocOk = FALSE;
    DBA_DYNFLD_STP      operId = NULL;     /* REF3939 - CSY - 000104 */
    RET_CODE            ret = RET_SUCCEED;      /* REF3939 - CSY - 000105 */
    DBA_DYNFLD_STP      getArgSt=NULL;     /* REF3939 - CSY - 000105 */
    ID_T                extPosInstrId=(ID_T) 0; /* REF4242 - CSY - 000117 */
    FLAG_T              bondCloseValDateFlg = FALSE, checkOpValDateInDb = FALSE;

    *existPosFlg = FALSE;                       /* REF3939 - CSY - 000105 */

	if (IS_NULLFLD(extOperation, ExtOp_EvtNbr))
    {
        /* return a error, event number must exist */
        /* REF3939 - CSY - 000105 */
        return ret;
    }		 
    
    /* REF3939 - CSY - 991104 */
    if ((ret = DBA_GetInstrById(GET_ID(extOperation, ExtOp_InstrId), FALSE, &allocOk, 
                         &instrPtr, NULL, UNUSED, UNUSED)) != RET_SUCCEED)
    {
        SYSNAME_T entSqlName;
        strcpy(entSqlName, DBA_GetDictEntitySqlName(Instr));
        MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, entSqlName, 
		    GET_ID(extOperation, ExtOp_InstrId));
        /* REF3939 - CSY - 000105 */
        return ret; 
    }
        
    /* PMSTA07549 - DDV - 090514 - if fusion rule is value_d and value date of operation is after domain's till date, 
       check in database for existing operation */
    if (stock != NULLDYNST && 
        IS_NULLFLD(extOperation, ExtOp_ValueDate) == FALSE &&
        CMP_DYNFLD(extOperation, domainPtr,
                   ExtOp_ValueDate, A_Domain_InterpTillDate, DateType) > 0)	
    {
        GEN_GetApplInfo(ApplFusBondCloseValueDate, &bondCloseValDateFlg);

        if (bondCloseValDateFlg == TRUE)
        {
            /* PMSTA-18340 - DDV - 140703 - Check that extension pointer is not null then access it*/
            if (GET_EXTENSION_PTR(stock, ExtPos_A_Instr_Ext) != NULL &&
                (instrPtr = *(GET_EXTENSION_PTR(stock, ExtPos_A_Instr_Ext))) != NULL &&
                GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_Bond ||
                GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_CumOption ||
                GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_ConvertBond)
                checkOpValDateInDb = TRUE;

        }
        else
        {
            /* PMSTA-18340 - DDV - 140703 - Check that extension pointer is not null then access it*/
            if (GET_EXTENSION_PTR(stock, ExtPos_A_Ptf_Ext) != NULL &&
                (ptfPtr = *(GET_EXTENSION_PTR(stock, ExtPos_A_Ptf_Ext))) != NULL &&
                DBA_GetFusDateRule(ptfPtr,
                                   A_Ptf_FusionDateRuleEn,
                                   A_Ptf_OldFusionDateRuleEn,
                                   NULL,
                                   0,
                                   extOperation,
                                   ExtOp) == FusDateRule_ValDate)
                checkOpValDateInDb = TRUE;
        }
    }

    if (DBA_CheckInstrDim(domainPtr, hierHead, GET_ID(instrPtr, A_Instr_Id), instrPtr, listPtr, NULL, FALSE, NULL, FALSE)==FALSE ||
        checkOpValDateInDb == TRUE ||
        (checkPtfDimFlg ==  TRUE && DBA_CheckPtfDim(domainPtr, hierHead, GET_ID(extOperation, ExtOp_PtfId), ptfPtr, listPtr, FALSE, NULL, NULLDYNSTPTR, 0)==FALSE))
    {
        if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr)};
        /* if instrument of operation is not in instr dimension from domain, 
        call stored procedure to see if the operation is already stored in DB */

        /* REF3939 - CSY - 000104 */

        /* allocate dynamic structure for input argument of DBA_Get2*/
        if ((getArgSt = ALLOC_DYNST(Get_Arg)) == NULL)
        {
            /* REF3939 - CSY - 000105 */
            return (RET_MEM_ERR_ALLOC);
        }
        /* portfolio_id */
        COPY_DYNFLD(getArgSt, Get_Arg, Get_Arg_PtfId,
                    extOperation, ExtOp,  ExtOp_PtfId);
        /* instr_id */
        COPY_DYNFLD(getArgSt, Get_Arg, Get_Arg_InstrId,
                    extOperation, ExtOp,  ExtOp_InstrId);
        /* min_status_e */
        COPY_DYNFLD(getArgSt, Get_Arg, Get_Arg_Enum1,
                    domainPtr, A_Domain,  A_Domain_MinStatEn);

        /* max_status_e */
        COPY_DYNFLD(getArgSt, Get_Arg, Get_Arg_Enum2,
                    domainPtr, A_Domain,  A_Domain_MaxStatEn);

        /* begin_d */
        COPY_DYNFLD(getArgSt, Get_Arg, Get_Arg_DateTime, 
                    domainPtr, A_Domain,  A_Domain_InterpFromDate);

        /* end_d */ /* PMSTA07549 - DDV - 090514 - Use value date when it is bigger that till date */
        if (checkOpValDateInDb == TRUE)
        {
            COPY_DYNFLD(getArgSt, Get_Arg, Get_Arg_DateTime2, 
                        extOperation, ExtOp,  ExtOp_ValueDate);
        }
        else
        {
            COPY_DYNFLD(getArgSt, Get_Arg, Get_Arg_DateTime2, 
                        domainPtr, A_Domain,  A_Domain_InterpTillDate);
        }

        /* event_number_n */
        COPY_DYNFLD(getArgSt, Get_Arg, Get_Arg_Number, 
                    extOperation, ExtOp,  ExtOp_EvtNbr);
        /* event_code */
        COPY_DYNFLD(getArgSt, Get_Arg, Get_Arg_Cd,
                    extOperation, ExtOp,  ExtOp_EvtCd);
        /* open_oper nat_e */
        COPY_DYNFLD(getArgSt, Get_Arg, Get_Arg_Enum3,
                    extOperation, ExtOp,  ExtOp_NatureEn);

        /* adjustment_nat_e */
        COPY_DYNFLD(getArgSt, Get_Arg, Get_Arg_Enum4,
                    extOperation, ExtOp,  ExtOp_AdjNatEn);

        /* ref_nat_e */
        COPY_DYNFLD(getArgSt, Get_Arg, Get_Arg_Enum5,
                    extOperation, ExtOp,  ExtOp_RefNatEn);  

        /* ref_oper_code */
        COPY_DYNFLD(getArgSt, Get_Arg, Get_Arg_Cd2, 
                    extOperation, ExtOp,  ExtOp_RefOpCd);
        
        /* allocate dynamic structure for output argument of DBA_Get2 */
        if ((operId = ALLOC_DYNST(Io_Id)) == NULL)
        {
            FREE_DYNST(getArgSt, Get_Arg);
            /* REF3939 - CSY - 000105 */
            return (RET_MEM_ERR_ALLOC);    
        }
        
        /* call procedure get_open_oper_id_for_event through DBA_Get2 */
        if ((ret = DBA_Get2(Op, UNUSED, Get_Arg, getArgSt, Io_Id, &operId, 
            UNUSED, UNUSED, UNUSED))!= RET_SUCCEED)
        {
            FREE_DYNST(getArgSt, Get_Arg);
            FREE_DYNST(operId, Io_Id);
        }
        else
        {  
            if (IS_NULLFLD(operId, Io_Id_Id)==FALSE) /* REF3939 - CSY - 000111 */
                *existPosFlg = TRUE;

            FREE_DYNST(getArgSt, Get_Arg);
            FREE_DYNST(operId, Io_Id);
        }
    return ret; /* REF3939 - CSY - 000113 */    
    }

    if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr)};

    /* REF3939 - CSY - 000113 */
    if (posNbr == 0) 
    {
        /* if no extractPos return FALSE */
        /* REF3939 - CSY - 000105 */
         return ret;
    }

	/* All positions are sorted by instrument, portfolio, */
	/* event number and event code. It's easy to find a position. */
	while (i < posNbr && found == FALSE)
	{
		/* if generic instrument, sorted by parent instrument */
        if (GET_ID(extractPos[i], ExtPos_InstrId) < 0)
        {
    		/* get instrument structure */
    		if (GET_EXTENSION_PTR(extractPos[i], ExtPos_A_Instr_Ext) != NULL)
		    {
    			instrPtr = *(GET_EXTENSION_PTR(extractPos[i], ExtPos_A_Instr_Ext));
            	instrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
		    }
        }
		else
		{
			instrId=GET_ID(extractPos[i], ExtPos_InstrId);
		}

		if (instrId < GET_ID(extOperation, ExtOp_InstrId))
			i++;
		else
			found = TRUE;
	}

	if (i == posNbr ||
            instrId != GET_ID(extOperation, ExtOp_InstrId))
    {
        /* REF3939 - CSY - 000105 */
		return ret;
    }

	while (i < posNbr &&
               CMP_DYNFLD(extractPos[i], extOperation,
                          ExtPos_PtfId, ExtOp_PtfId, IdType) < 0)	
		i++;
    
    if (i == posNbr) /* REF4242 - CSY - 000316: avoid overflow */
        return(ret);

    /* REF4242 - CSY - 000117 : set extPosInstrId in order
    to compare it with instr id . If generic instrument, 
    extPosInstrId is set to parent instrument id */
    if (GET_ID(extractPos[i], ExtPos_InstrId) < 0)
    {
    	/* get instrument structure */
    	if (GET_EXTENSION_PTR(extractPos[i], ExtPos_A_Instr_Ext) != NULL)
		{
    		instrPtr = *(GET_EXTENSION_PTR(extractPos[i], ExtPos_A_Instr_Ext));
            extPosInstrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
		}
    }
	else
	{
		extPosInstrId=GET_ID(extractPos[i], ExtPos_InstrId); 
	}

	if (    /* REF4242 - CSY - 000117 : compare instrId with extPosInstrId */
            instrId != extPosInstrId ||
            CMP_DYNFLD(extractPos[i], extOperation,
                       ExtPos_PtfId, ExtOp_PtfId, IdType) != 0)	
    {
        /* REF3939 - CSY - 000105 */
		return ret;
    }

	while (i < posNbr &&
               CMP_DYNFLD(extractPos[i], extOperation,
                          ExtPos_EvtNbr, ExtOp_EvtNbr, NumberType) < 0)	
		i++;

    if (i == posNbr) /* REF4242 - CSY - 000316: avoid overflow */
        return(ret);

    /* REF4242 - CSY - 000117 : set extPosInstrId in order
    to compare it with instr id . If generic instrument, 
    extPosInstrId is set to parent instrument id */
    if (GET_ID(extractPos[i], ExtPos_InstrId) < 0)
    {
    	/* get instrument structure */
    	if (GET_EXTENSION_PTR(extractPos[i], ExtPos_A_Instr_Ext) != NULL)
		{
    		instrPtr = *(GET_EXTENSION_PTR(extractPos[i], ExtPos_A_Instr_Ext));
            extPosInstrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
		}
    }
	else
	{
		extPosInstrId=GET_ID(extractPos[i], ExtPos_InstrId); 
	}

	if (
            /* REF4242 - CSY - 000117 : compare instrId with extPosInstrId */
            instrId != extPosInstrId ||
            CMP_DYNFLD(extractPos[i], extOperation,
                       ExtPos_PtfId, ExtOp_PtfId, IdType) != 0 ||
            CMP_DYNFLD(extractPos[i], extOperation,
                       ExtPos_EvtNbr, ExtOp_EvtNbr, NumberType) != 0)	
	{
        /* REF3939 - CSY - 000105 */
		return ret;
    }

	while (i < posNbr &&
               CMP_DYNFLD(extractPos[i], extOperation,
                          ExtPos_EvtCd, ExtOp_EvtCd, CodeType) < 0)	
		i++;

    if (i == posNbr) /* REF4242 - CSY - 000316: avoid overflow */
        return(ret);

    /* REF4242 - CSY - 000117 : set extPosInstrId in order
    to compare it with instr id . If generic instrument, 
    extPosInstrId is set to parent instrument id */
    if (GET_ID(extractPos[i], ExtPos_InstrId) < 0)
    {
    	/* get instrument structure */
    	if (GET_EXTENSION_PTR(extractPos[i], ExtPos_A_Instr_Ext) != NULL)
		{
    		instrPtr = *(GET_EXTENSION_PTR(extractPos[i], ExtPos_A_Instr_Ext));
            extPosInstrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
		}
    }
	else
	{
		extPosInstrId=GET_ID(extractPos[i], ExtPos_InstrId); 
	}

	if (
            /* REF4242 - CSY - 000117 : compare instrId with extPosInstrId */
            instrId != extPosInstrId ||
            CMP_DYNFLD(extractPos[i], extOperation,
                       ExtPos_PtfId, ExtOp_PtfId, IdType) != 0 ||
            CMP_DYNFLD(extractPos[i], extOperation,
                       ExtPos_EvtNbr, ExtOp_EvtNbr, NumberType) != 0 ||
            CMP_DYNFLD(extractPos[i], extOperation,
                       ExtPos_EvtCd, ExtOp_EvtCd, CodeType) != 0)	
	{
        /* REF3939 - CSY - 000105 */
		return ret;
    }
    else if (onlyStandInstructFlg == TRUE) /* PSMATA06761 - DDV - For standing instruction just check Ptf, Instr, EvtCd and EvtNbr */
    {
        *existPosFlg = TRUE;
		return ret;
    }

	while (i < posNbr &&
               CMP_DYNFLD(extractPos[i], extOperation,
                          ExtPos_OpenOpNatEn, ExtOp_NatureEn, EnumType) < 0)	
		i++;

    if (i == posNbr) /* REF4242 - CSY - 000316: avoid overflow */
        return(ret);

   /* REF4242 - CSY - 000117 : set extPosInstrId in order
    to compare it with instr id . If generic instrument, 
    extPosInstrId is set to parent instrument id */
    if (GET_ID(extractPos[i], ExtPos_InstrId) < 0)
    {
    	/* get instrument structure */
    	if (GET_EXTENSION_PTR(extractPos[i], ExtPos_A_Instr_Ext) != NULL)
		{
    		instrPtr = *(GET_EXTENSION_PTR(extractPos[i], ExtPos_A_Instr_Ext));
            extPosInstrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
		}
    }
	else
	{
		extPosInstrId=GET_ID(extractPos[i], ExtPos_InstrId); 
	}

	if (
            /* REF4242 - CSY - 000117 : compare instrId with extPosInstrId */
            instrId != extPosInstrId ||
            CMP_DYNFLD(extractPos[i], extOperation,
                       ExtPos_PtfId, ExtOp_PtfId, IdType) != 0 ||
            CMP_DYNFLD(extractPos[i], extOperation,
                       ExtPos_EvtNbr, ExtOp_EvtNbr, NumberType) != 0 ||
            CMP_DYNFLD(extractPos[i], extOperation,
                       ExtPos_EvtCd, ExtOp_EvtCd, CodeType) != 0 ||
            CMP_DYNFLD(extractPos[i], extOperation,
                       ExtPos_OpenOpNatEn, ExtOp_NatureEn, EnumType) != 0)	
	{
        /* REF3939 - CSY - 000105 */
		return ret;
    }

	while (i < posNbr &&
               CMP_DYNFLD(extractPos[i], extOperation,
                          ExtPos_AdjustNatEn, ExtOp_AdjNatEn, EnumType) < 0)	
		i++;

    if (i == posNbr) /* REF4242 - CSY - 000316: avoid overflow */
        return(ret);

    /* REF4242 - CSY - 000117 : set extPosInstrId in order
    to compare it with instr id . If generic instrument, 
    extPosInstrId is set to parent instrument id */
    if (GET_ID(extractPos[i], ExtPos_InstrId) < 0)
    {
    	/* get instrument structure */
    	if (GET_EXTENSION_PTR(extractPos[i], ExtPos_A_Instr_Ext) != NULL)
		{
    		instrPtr = *(GET_EXTENSION_PTR(extractPos[i], ExtPos_A_Instr_Ext));
            extPosInstrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
		}
    }
	else
	{
		extPosInstrId=GET_ID(extractPos[i], ExtPos_InstrId); 
	}

	if (
            /* REF4242 - CSY - 000117 : compare instrId with extPosInstrId */
            instrId != extPosInstrId ||
            CMP_DYNFLD(extractPos[i], extOperation,
                       ExtPos_PtfId, ExtOp_PtfId, IdType) != 0 ||
            CMP_DYNFLD(extractPos[i], extOperation,
                       ExtPos_EvtNbr, ExtOp_EvtNbr, NumberType) != 0 ||
            CMP_DYNFLD(extractPos[i], extOperation,
                       ExtPos_EvtCd, ExtOp_EvtCd, CodeType) != 0 ||
            CMP_DYNFLD(extractPos[i], extOperation,
                       ExtPos_OpenOpNatEn, ExtOp_NatureEn, EnumType) != 0 ||
            CMP_DYNFLD(extractPos[i], extOperation,
                       ExtPos_AdjustNatEn, ExtOp_AdjNatEn, EnumType) != 0)	
	{
        /* REF3939 - CSY - 000105 */
		return ret;
    }

	while (i < posNbr &&
               CMP_DYNFLD(extractPos[i], extOperation,
                          ExtPos_RefNatEn, ExtOp_RefNatEn, EnumType) < 0)	
		i++;

    if (i == posNbr) /* REF4242 - CSY - 000316: avoid overflow */
        return ret;

    /* REF4242 - CSY - 000117 : set extPosInstrId in order
    to compare it with instr id . If generic instrument, 
    extPosInstrId is set to parent instrument id */
    if (GET_ID(extractPos[i], ExtPos_InstrId) < 0)
    {
    	/* get instrument structure */
    	if (GET_EXTENSION_PTR(extractPos[i], ExtPos_A_Instr_Ext) != NULL)
		{
    		instrPtr = *(GET_EXTENSION_PTR(extractPos[i], ExtPos_A_Instr_Ext));
            extPosInstrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
		}
    }
	else
	{
		extPosInstrId=GET_ID(extractPos[i], ExtPos_InstrId); 
	}

	if ( /* XDI- 970124 - BUG265 */
            /* REF4242 - CSY - 000117 : compare instrId with extPosInstrId */
            instrId != extPosInstrId ||
            CMP_DYNFLD(extractPos[i], extOperation,
                       ExtPos_PtfId, ExtOp_PtfId, IdType) != 0 ||
            CMP_DYNFLD(extractPos[i], extOperation,
                       ExtPos_EvtNbr, ExtOp_EvtNbr, NumberType) != 0 ||
            CMP_DYNFLD(extractPos[i], extOperation,
                       ExtPos_EvtCd, ExtOp_EvtCd, CodeType) != 0 ||
            CMP_DYNFLD(extractPos[i], extOperation,
                       ExtPos_OpenOpNatEn, ExtOp_NatureEn, EnumType) != 0 ||
            CMP_DYNFLD(extractPos[i], extOperation,
                       ExtPos_AdjustNatEn, ExtOp_AdjNatEn, EnumType) != 0 ||
            CMP_DYNFLD(extractPos[i], extOperation,
                       ExtPos_RefNatEn, ExtOp_RefNatEn, EnumType) != 0)	
	{
        /* REF3939 - CSY - 000105 */
		return ret;
    }

	while (i < posNbr &&
               CMP_DYNFLD(extractPos[i], extOperation,
                          ExtPos_RefOpCd, ExtOp_RefOpCd, CodeType) < 0)	
		i++;

    if (i == posNbr) /* REF4242 - CSY - 000316: avoid overflow */
        return ret;

    /* REF4242 - CSY - 000117 : set extPosInstrId in order
    to compare it with instr id . If generic instrument, 
    extPosInstrId is set to parent instrument id */
    if (GET_ID(extractPos[i], ExtPos_InstrId) < 0)
    {
    	/* get instrument structure */
    	if (GET_EXTENSION_PTR(extractPos[i], ExtPos_A_Instr_Ext) != NULL)
		{
    		instrPtr = *(GET_EXTENSION_PTR(extractPos[i], ExtPos_A_Instr_Ext));
            extPosInstrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
		}
    }
	else
	{
		extPosInstrId=GET_ID(extractPos[i], ExtPos_InstrId); 
	}

	if (
            /* REF4242 - CSY - 000117 : compare instrId with extPosInstrId */
            instrId != extPosInstrId ||
            CMP_DYNFLD(extractPos[i], extOperation,
                       ExtPos_PtfId, ExtOp_PtfId, IdType) != 0 ||
            CMP_DYNFLD(extractPos[i], extOperation,
                       ExtPos_EvtNbr, ExtOp_EvtNbr, NumberType) != 0 ||
            CMP_DYNFLD(extractPos[i], extOperation,
                       ExtPos_EvtCd, ExtOp_EvtCd, CodeType) != 0 ||
            CMP_DYNFLD(extractPos[i], extOperation,
                       ExtPos_OpenOpNatEn, ExtOp_NatureEn, EnumType) != 0 ||
            CMP_DYNFLD(extractPos[i], extOperation,
                       ExtPos_AdjustNatEn, ExtOp_AdjNatEn, EnumType) != 0 ||
            CMP_DYNFLD(extractPos[i], extOperation,
                       ExtPos_RefNatEn, ExtOp_RefNatEn, EnumType) != 0 ||
            CMP_DYNFLD(extractPos[i], extOperation,
                       ExtPos_RefOpCd, ExtOp_RefOpCd, CodeType) != 0)	
	{
        /* REF3939 - CSY - 000105 */
		return ret;
    }

    /* REF4242 - CSY - 000117 : set extPosInstrId in order
    to compare it with instr id . If generic instrument, 
    extPosInstrId is set to parent instrument id */
    /* initialise extPosInstrId */
    if (GET_ID(extractPos[i], ExtPos_InstrId) < 0)
    {
    	/* get instrument structure */
    	if (GET_EXTENSION_PTR(extractPos[i], ExtPos_A_Instr_Ext) != NULL)
		{
    		instrPtr = *(GET_EXTENSION_PTR(extractPos[i], ExtPos_A_Instr_Ext));
            extPosInstrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
		}
    }
	else
	{
		extPosInstrId=GET_ID(extractPos[i], ExtPos_InstrId); 
	}

        /* REF3740 - 990803 - DDV - Check if adj instrument is the same */
	while (i < posNbr && 
               /* REF4242 - CSY - 000117 : compare instrId with extPosInstrId */
               instrId == extPosInstrId &&
               CMP_DYNFLD(extractPos[i], extOperation,
                          ExtPos_PtfId, ExtOp_PtfId, IdType) == 0 &&
               CMP_DYNFLD(extractPos[i], extOperation,
                          ExtPos_EvtNbr, ExtOp_EvtNbr, NumberType) == 0 &&
               CMP_DYNFLD(extractPos[i], extOperation,
                          ExtPos_EvtCd, ExtOp_EvtCd, CodeType) == 0 &&
               CMP_DYNFLD(extractPos[i], extOperation,
                          ExtPos_OpenOpNatEn, ExtOp_NatureEn, EnumType) == 0 &&
               CMP_DYNFLD(extractPos[i], extOperation,
                          ExtPos_AdjustNatEn, ExtOp_AdjNatEn, EnumType) == 0 &&
               CMP_DYNFLD(extractPos[i], extOperation,
                          ExtPos_RefNatEn, ExtOp_RefNatEn, EnumType) == 0 &&
               CMP_DYNFLD(extractPos[i], extOperation,
                          ExtPos_RefOpCd, ExtOp_RefOpCd, CodeType) == 0)
    {

        /* REF4242 - CSY - 000117 : set the extPosInstrId */
        if (GET_ID(extractPos[i], ExtPos_InstrId) < 0)
        {
    	    /* get instrument structure */
    	    if (GET_EXTENSION_PTR(extractPos[i], ExtPos_A_Instr_Ext) != NULL)
		    {
    		    instrPtr = *(GET_EXTENSION_PTR(extractPos[i], ExtPos_A_Instr_Ext));
                extPosInstrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
		    }
        }
	    else
	    {
		    extPosInstrId=GET_ID(extractPos[i], ExtPos_InstrId); 
	    }

        adjPosPtr = NULL;
        if (GET_EXTENSION_PTR(extractPos[i], ExtPos_Adjust_ExtPos_Ext) != NULL)
                adjPosPtr = *(GET_EXTENSION_PTR(extractPos[i], ExtPos_Adjust_ExtPos_Ext));

        if (IS_NULLFLD(extOperation, ExtOp_AdjInstrId) == TRUE &&
            adjPosPtr == NULL)
        {
            *existPosFlg = TRUE; /* REF3939 - CSY - 000105 */
		    return ret;
        }

        if (CMP_DYNFLD(adjPosPtr, extOperation,
                       ExtPos_InstrId, ExtOp_AdjInstrId, IdType) == 0)
        {
            *existPosFlg = TRUE; /* REF3939 - CSY - 000105 */
		    return ret;
        }
        i++;
    }

	return ret;

}

/************************************************************************
**
**  Function         : FIN_GetValoResult()
**
**  Description      : Find in hierarchy the position with the same PosObjId
**                     and return the value stored in the PosVal.
**                      
**  Arguments        : hierHeadValo      hierarchy with the result of valo
**                     posObjId          id to find in hierarchy           
**                     qty               quantity
**
**  Return           : RET_SUCCEED or error code
**
** Creation Date     : 960620 - XDI - DVP077
** Last Modification :
**                   
*************************************************************************/
STATIC RET_CODE FIN_GetValoResult(DBA_HIER_HEAD_STP hierHeadValo,
                                  ID_T              posObjId,
                                  NUMBER_T          *qty) 
{
	int               i, posNbr;
	char              copyRecFlg;
	DBA_DYNFLD_STP    *extractPos=NULL, 
			  posValPtr=NULL;
	FLAG_T            found = FALSE;
	RET_CODE          ret;

	copyRecFlg = FALSE;
	if ((ret = DBA_ExtractHierEltRec(hierHeadValo, ExtPos, 
		                             copyRecFlg, NULL, NULL, 
		                             &posNbr, &extractPos)) != RET_SUCCEED)
		return(ret);

	for (i=0; i<posNbr && found == FALSE; i++)
	{
		if (posObjId == GET_ID(extractPos[i], ExtPos_PosObjId))
		{
			if (GET_EXTENSION_PTR(extractPos[i], ExtPos_PosVal_Ext) != NULL &&
			    (posValPtr = *(GET_EXTENSION_PTR(extractPos[i], 
					       ExtPos_PosVal_Ext)))!=NULL)
			{
                                /* BUG182 - XDI - 961016 */
                                *qty = GET_NUMBER(posValPtr, PosVal_PosMktValAmt)*
                                       ((double) GET_SMALLINT(posValPtr, PosVal_AccrInterDenomPeriod) /
                                        (double) GET_SMALLINT(posValPtr, PosVal_AccrInterNumPeriod));

				found = TRUE;
			}
		}
	}

	FREE(extractPos);
	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_FilterFlow()
**
**  Description :   Extract Flow position and balance position
**                  Used by hierarchy tools function DBA_ExtractHierEltRec()
**                  return TRUE  -> record must be extract
**                         FALSE -> record musn't be extract
**                 
**  Arguments   :   dynSt      dynamic structure pointer
**                  dynStTp    dynamic structure definition
**
**  Return      :   TRUE or FALSE
**
*************************************************************************/
STATIC int FIN_FilterFlow(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP notUsed) /* REF7264 - DDV - 020325 - Compil C++ */
{
    if (GET_ENUM(dynSt, ExtPos_NatEn) == ExtPosNat_Flow &&
        DBA_IsTechnicalPosition(dynSt) == false)                /* PMSTA-22130 - DDV - 160125 - Filter technical positions */
	return(TRUE);
    else
	return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_FilterRemoveTechnical()
**
**  Description :   Extract Flow position and balance position (remove technical positions)
**                  Used by hierarchy tools function DBA_ExtractHierEltRec()
**                  return TRUE  -> record must be extract
**                         FALSE -> record musn't be extract
**                 
**  Arguments   :   dynSt      dynamic structure pointer
**                  dynStTp    dynamic structure definition
**
**  Return      :   TRUE or FALSE
**
*************************************************************************/
STATIC int FIN_FilterRemoveTechnical(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP notUsed) /* REF7264 - DDV - 020325 - Compil C++ */
{
    if (DBA_IsTechnicalPosition(dynSt) == false)                /* PMSTA-22130 - DDV - 160125 - Filter technical positions */
	return(TRUE);
    else
	return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_FilterStandingInstruction()
**
**  Description :   Extract Flow position and balance position with event code and event number.
**                  Used by hierarchy tools function DBA_ExtractHierEltRec()
**                  return TRUE  -> record must be extract
**                         FALSE -> record musn't be extract
**                 
**  Arguments   :   dynSt      dynamic structure pointer
**                  dynStTp    dynamic structure definition
**
**  Return      :   TRUE or FALSE
**
*************************************************************************/
STATIC int FIN_FilterStandingInstruction(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP notUsed) /* REF7264 - DDV - 020325 - Compil C++ */
{
    if (IS_NULLFLD(dynSt, ExtPos_EvtCd) == FALSE &&
        IS_NULLFLD(dynSt, ExtPos_EvtNbr) == FALSE)
    	return(TRUE);
    else
	    return(FALSE);
}

/************************************************************************
*
*   Function        :   FIN_FilterStratLnkWithStratId()
*
*   Description     :  Filter portfolio for the given ESL strategy in same hier
*
**  Arguments       : mpESL input esl with strategy and parent port id
**
*
*   Return : TRUE or FALSE
*
*   Creation Date :PMSTA-45637 Autocash Vishnu 23122020
*
*************************************************************************/
STATIC int FIN_FilterStratLnkWithStratId(DBA_DYNFLD_STP  dynSt, DBA_DYNST_ENUM, DBA_DYNFLD_STP  mpESL)
{
    if (CMP_DYNFLD(dynSt, mpESL, S_StratLnk_StratId, ExtStratLnk_StratId, IdType) == 0)
    {
        FLAG_T         allocPtfFlg;
        DBA_DYNFLD_STP childPtf = NULL;
        MemoryPool     mp;
        /* return Strat Link belonging to the head portfolio */
        if (DBA_GetPtfById(GET_ID(dynSt, S_StratLnk_PtfId), TRUE, &allocPtfFlg,
            &childPtf, NULL, UNUSED, UNUSED) == RET_SUCCEED)
        {
            if(allocPtfFlg == TRUE)
            {
                mp.ownerDynStp(childPtf);
            }
            if (CMP_DYNFLD(mpESL, childPtf, ExtStratLnk_PtfId, A_Ptf_ParentPortId, IdType) == 0)
                return TRUE;
        }
    }
    return FALSE;
}

/************************************************************************************************************
*
*   Function        :  FIN_GetNonManagedStrategyLinkList
*
*   Description     :SMA/Sleeve portfolio which is in the overlay hierarchy and that is linked to 
                     this SMA/Sleeve model portfolio is retrieved
*
**  Arguments       :
**
*
*   Return : TRUE or FALSE
*
*   Creation Date : PMSTA - 46093 - lalby - 24082021
*
****************************************************************************************************************/

static RET_CODE FIN_GetNonManagedStrategyLinkList(DBA_DYNFLD_STP   notionalInstrPtr, 
                                                  DBA_HIER_HEAD_STP  hierHead, 
                                                  ID_T headPtf, 
                                                  std::set <ID_T> *nonManagedPtfIdList)
{
    RET_CODE ret = RET_SUCCEED;
    DBA_DYNFLD_STP insStratPtr = NULLDYNST;

    /*get strat for the notional instrument strategy*/
    if (DBA_GetRecPtrFromHierById(hierHead,
        GET_ID(notionalInstrPtr, A_Instr_ModelPtfId),
        A_Strat,
        &insStratPtr) != RET_SUCCEED ||
        insStratPtr == NULLDYNST)
    {
        return(RET_SUCCEED);
    }

    /*get strat elemts for the strategy*/
    DBA_DYNFLD_STP  stratHistPtr = NULLDYNSTPTR;
    
    if (IS_NULLFLD(insStratPtr, A_Strat_A_StratHist_Ext) != TRUE &&
        (stratHistPtr = *(GET_EXTENSION_PTR(insStratPtr, A_Strat_A_StratHist_Ext))) != NULLDYNST)
    {
        int  stratEltNbr = GET_EXTENSION_NBR(stratHistPtr, A_StratHist_A_StratElt_Ext);

        if (stratEltNbr > 0)
        {
            DBA_DYNFLD_STP * stratLnkTab = NULLDYNSTPTR;
            int              stratLnkNbr = 0;

            DBA_DYNFLD_STP dummyEsl = NULLDYNST;
            if ((dummyEsl = ALLOC_DYNST(ExtStratLnk)) == NULLDYNST)
            {
                MSG_RETURN(RET_MEM_ERR_ALLOC);
            }

            COPY_DYNFLD(dummyEsl, ExtStratLnk, ExtStratLnk_StratId, stratHistPtr, A_StratHist, A_StratHist_StratId);
            SET_ID(dummyEsl, ExtStratLnk_PtfId, headPtf); //ptfInfoStp->ptfId);

            /*Get the non managed portfolio linked to the strategy with same head portfolio  from strategy_link
                this should be loaded in hier by sel_exd_strategy_by_domain*/
            if ((ret = DBA_HierEltRecExtract(hierHead, S_StratLnk, FALSE, FIN_FilterStratLnkWithStratId,
                dummyEsl, NULLFCT, FALSE, FALSE, &stratLnkNbr, &stratLnkTab)) != RET_SUCCEED || 0 == stratLnkNbr)
            {
                MSG_SendMesg(FILEINFO, "FIN_CreateOrderForNI: no portfolio link fetched for SI");
                FREE_DYNST(dummyEsl, ExtStratLnk);
                return ret;
            }

            for (int i = 0; i < stratLnkNbr; ++i)
            {
                ID_T nonManagedPtfId = GET_ID(stratLnkTab[i], S_StratLnk_ObjId);
                nonManagedPtfIdList->insert(nonManagedPtfId);
            }

            FREE_DYNST(dummyEsl, ExtStratLnk);
            FREE(stratLnkTab);
        }
    }

   return ret;
}

/*********************************************************************************************
*
*   Function        :  FIN_GETStratElements()
*
*   Description     : Get strategy associated with the instrument
*
**  Arguments       : instrument ptr, hierHead 
                      out-strategyelement
**
*
*   Return : TRUE or FALSE
*
*   Creation Date : PMSTA - 46093 - lalby - 24082021
*
**********************************************************************************************/

static RET_CODE FIN_GETStratElements(DBA_DYNFLD_STP   notionalInstrPtr, 
                                     DBA_HIER_HEAD_STP  hierHead, 
                                     DBA_DYNFLD_STP **stratEltTab,
                                     int    *stratEltNbr)
{
    RET_CODE ret = RET_SUCCEED;
    DBA_DYNFLD_STP insStratPtr = NULLDYNSTPTR;

    /*get strat for the notional instrument strategy*/
    if (DBA_GetRecPtrFromHierById(hierHead,
        GET_ID(notionalInstrPtr, A_Instr_ModelPtfId),
        A_Strat,
        &insStratPtr) != RET_SUCCEED ||
        insStratPtr == NULLDYNST)
    {
        return(RET_SUCCEED);
    }

    /*get strat elemts for the strategy*/
    DBA_DYNFLD_STP  stratHistPtr = NULLDYNSTPTR;

    if (IS_NULLFLD(insStratPtr, A_Strat_A_StratHist_Ext) != TRUE &&
        (stratHistPtr = *(GET_EXTENSION_PTR(insStratPtr, A_Strat_A_StratHist_Ext))) != NULLDYNST)
    {
        *stratEltTab = GET_EXTENSION_PTR(stratHistPtr, A_StratHist_A_StratElt_Ext);
        *stratEltNbr = GET_EXTENSION_NBR(stratHistPtr, A_StratHist_A_StratElt_Ext);
    }

    return ret;
}


/**********************************************************************************************************************
*
*   Function        : FIN_GetConvertedCurrencyAmount()
*
*   Description     : get exchange rate and convert the currency to another currency

**  Arguments       : domainPtr, hierHead, srcAmount , source currency ID, target currency ID
**
*   Return          : coverted currency if GetExchangeRate is success
*
*   Creation Date   : PMSTA-46255 - lalby - 01102021
*
*************************************************************************************************************************/
AMOUNT_T FIN_GetConvertedCurrencyAmount(  DBA_DYNFLD_STP      domainPtr,
                                          DBA_HIER_HEAD_STP   hierHead,
                                          AMOUNT_T        srcAmount,
                                          ID_T            srcCurrId,
                                          ID_T            trgtCurrId
                                        )
{
    if (srcCurrId == trgtCurrId)
    {
        return srcAmount;
    }

    DATETIME_T      refDateTime = GET_DATETIME(domainPtr, A_Domain_InterpFromDate);
    FIN_EXCHARG_ST  exchArgSt;
    EXCHANGE_T  exch;
    AMOUNT_T targetCurrAmount = 0;

    RET_CODE ret = RET_SUCCEED;

    memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));
    DBA_InitConnectNoToExchArg(&exchArgSt, hierHead);

    ret = FIN_GetExchRate(refDateTime, srcCurrId, trgtCurrId, (ID_T)0, NULLDYNST, NULLDYNST, &exchArgSt, &exch);

    if (ret == RET_SUCCEED)
    {
        targetCurrAmount = srcAmount * exch;
    }
    else
    {
        targetCurrAmount = srcAmount;
    }

    return targetCurrAmount;
}
 
/**********************************************************************************************************************
*
*   Function        :  FIN_CreateOrderForNI()
*
*   Description     :1)The SMA/Sleeve portfolio which is in the overlay hierarchy and that is linked to this
                        SMA/Sleeve model portfolio  is retrieved. 
                     2) a percentage (defined in the standing instruction for the notional instrument) of cash deviation 
                     is transferred into this portfolio (Amount to invest) using cash portfolio functionality as we do in 
                     Inter Rebalancing a cash transfer. 
                     3)the cash is invested into the SMA/Sleeve portfolio linked to the model, this cash is used to 
                     generate buy orders in the portfolio linked to the model based on the instruments
                     and objectives defined in the model. 

*
**  Arguments       : instr,SI
**
*
*   Return : TRUE or FALSE
*
*   Creation Date : PMSTA - 46093 - lalby - 24082021
*
*************************************************************************************************************************/
static RET_CODE FIN_CreateOrderForNI(DBA_DYNFLD_STP      domainPtr,
                                     DBA_HIER_HEAD_STP   hierHead,
                                     DBA_DYNFLD_STP    flowPtr,
                                     DBA_DYNFLD_STP    standInstructPtr,
                                     DBA_DYNFLD_STP	  planDefPtr,
                                     DBA_DYNFLD_STP      notionalInstrPtr,
                                     AMOUNT_T           niOrderAmt,
                                     FIN_PTFINFO_STP     inPtfInfoStp,
                                     DBA_DYNFLD_STP    *extractFlowPos,
                                     int               extractFlowPosNbr,
                                     DBA_DYNFLD_STP	  *listPtr,
                                     std::vector< DBA_DYNFLD_STP > *notionalExtListPtr)
{
    RET_CODE ret = RET_SUCCEED;
    MemoryPool       mp;

    FIN_PTFINFO_STP		    ptfInfoStp;
    FIN_ORDERINFO_STP       orderInfoStp;

    FIN_ORDERINFO_ST orderInfoSt;

    ptfInfoStp = (FIN_PTFINFO_STP)mp.calloc(FILEINFO, 1, sizeof(FIN_PTFINFO_ST));
    orderInfoStp = (FIN_ORDERINFO_STP)mp.calloc(FILEINFO, 1, sizeof(FIN_ORDERINFO_ST));

    FIN_OrderInfoInit(&orderInfoSt, hierHead);
    memcpy(ptfInfoStp, inPtfInfoStp, sizeof(FIN_PTFINFO_ST));          //Parent portfolio

    /*1)The SMA / Sleeve portfolio which is in the overlay hierarchy and that is linked to this
    SMA / Sleeve model portfolio  is retrieved. nonmanaged portfolios linked with same strategy of notionalinstrument having same 
    parent*/
    std::set <ID_T> nonManagedPtfIdList;
    FIN_GetNonManagedStrategyLinkList(notionalInstrPtr, hierHead, ptfInfoStp->ptfId, &nonManagedPtfIdList);

    /*PMSTA-46226 - lalby - 02092021*/
    bool opInHeadOnly = false;
    ENUM_T          applOpStatusSimulationEnum;
    GEN_GetApplInfo(AppSysOpStatusSimulationEnum, &applOpStatusSimulationEnum);

    if ((GET_ENUM(domainPtr, A_Domain_EvtOperStatEn)== applOpStatusSimulationEnum) && nonManagedPtfIdList.empty()==TRUE)
    {
        //if there is no such portfolio in the hierarchy linked to the MP of the notional instrument, 
        //then the orders are created in the head if the session is launched in simulation mode 
        nonManagedPtfIdList.insert(ptfInfoStp->ptfId);
        opInHeadOnly = true;
    }

    for ( ID_T nonManagedPtfId : nonManagedPtfIdList)  
    {
        DBA_DYNFLD_STP          childPtfPtr = NULLDYNST;
        FLAG_T                  allocFlg = FALSE;

        DBA_GetPtfById(nonManagedPtfId, TRUE, &allocFlg, &childPtfPtr,
            hierHead, UNUSED, UNUSED);

        if (NULLDYNST == childPtfPtr)
            return RET_MEM_ERR_ALLOC;
        
        if(allocFlg == TRUE) mp.ownerDynStp(childPtfPtr);

        DBA_DYNFLD_STP *stratEltTab = NULLDYNSTPTR;
        int    stratEltNbr;

        //Get strategy elements associated with the notional instruments from hierarchy
        FIN_GETStratElements(notionalInstrPtr, hierHead, &stratEltTab, &stratEltNbr);

        if (stratEltNbr == 0 || stratEltTab == NULLDYNSTPTR)
            return ret;

        if (opInHeadOnly == false)  //do cash transfer to child
        {
            /*PMSTA-46255 - Lalby - 29092021 plan objective currency is different from head portfolio currency */
            if (GET_EXTENSION_PTR(planDefPtr, A_PlanDefinition_PlanObjectiveHisto_Ext) != NULL)
            {
                DBA_DYNFLD_STP objectiveStp = nullptr;
                objectiveStp = GET_EXTENSION_PTR(planDefPtr, A_PlanDefinition_PlanObjectiveHisto_Ext)[0];
 
                if ((ptfInfoStp->ptfPtr != NULL &&
                    GET_ID(ptfInfoStp->ptfPtr, A_Ptf_CurrId) != GET_ID(objectiveStp, A_PlanObjectiveHisto_CurrId)))
                {
                    //convert into portfolio currency
                    niOrderAmt = FIN_GetConvertedCurrencyAmount(domainPtr, hierHead, niOrderAmt,
                                                                 GET_ID(objectiveStp, A_PlanObjectiveHisto_CurrId),
                                                                 GET_ID(ptfInfoStp->ptfPtr, A_Ptf_CurrId));
                }
            }

            /*2) a percentage(defined in the standing instruction for the notional instrument) of cash deviation
                is transferred into this portfolio(Amount to invest) using cash portfolio functionality as we do in
                Inter Rebalancing a cash transfer.*/

            ID_T childCashAccount = GET_ID(stratEltTab[0], A_StratElt_InstrId);

            DBA_DYNFLD_STP 	    eslPtr = NULLDYNST;  //dummy arguments to call existing cash transfer function.
            DBA_DYNFLD_STP 	    esePtr = NULLDYNST;

            FIN_CreateExtraOpForNotionalInstr(hierHead, hierHead, domainPtr, ptfInfoStp, orderInfoStp,
                                               stratEltTab[0], eslPtr, esePtr, OpNat_Buy,
                                               childCashAccount, &niOrderAmt, childPtfPtr, notionalInstrPtr);

        }

        if (stratEltNbr > 0)
        {
             /* sort elements based on weight  high to low */
             TLS_Sort((char*)(stratEltTab), (unsigned)stratEltNbr, sizeof(DBA_DYNFLD_STP),
                    (TLS_CMPFCT *)FIN_startEltSort, NULL, SortRtnTp_None);
        }
 
        DBA_DYNFLD_STP StratEleInstrPtr = NULLDYNSTPTR;
        AMOUNT_T ChildPtfCashAvb = 0;

        NEGCASH_ENUM negativeCashEn = static_cast<NEGCASH_ENUM> GET_ENUM(childPtfPtr, A_Ptf_NegativeCashEn);

        /*PMSTA-46257 -lalby - 11102021  check -ve cash allowed in head*/
        if (StandInstructOpNatEn::Buy == static_cast<StandInstructOpNatEn>(GET_ENUM(standInstructPtr, A_StandInstruct_OpNatEn)) &&
            (negativeCashEn == NEGCASH_ENUM::NegCash_NotPermitted))
        {
             FIN_ValoProcess(domainPtr, hierHead, FIN_FilterPStock);
             FIN_GetCashBalanceFromInstrExt(hierHead, childPtfPtr, &ChildPtfCashAvb);

             ChildPtfCashAvb += niOrderAmt; //avilable cash with transfered amount
             
             if (CMP_AMOUNT(ChildPtfCashAvb, 0.0, GET_ID(childPtfPtr, A_Ptf_CurrId)) <= 0)
                 break;
        }

        /*iterate each strategy elements and create order for each non cash instrument*/
        for (int elt = 0; elt < stratEltNbr; elt++)
        {
            if (IS_NULLFLD(stratEltTab[elt], A_StratElt_InstrId) == TRUE ||
                STRATELTNAT_ENUM::StratEltNat_ModelPtf != static_cast<STRATELTNAT_ENUM>(GET_ENUM(stratEltTab[elt], A_StratElt_NatEn)))
            {
                continue;
            }

            FLAG_T allocInstrFlg = FALSE;

            if ((ret = DBA_GetInstrById(GET_ID(stratEltTab[elt], A_StratElt_InstrId),
                TRUE, &allocInstrFlg,
                &StratEleInstrPtr, hierHead,
                UNUSED, UNUSED)) != RET_SUCCEED)
            {
                if (TRUE == allocInstrFlg)
                    FREE_DYNST(StratEleInstrPtr, A_Instr);
                continue;
            }

            if (GET_ENUM(StratEleInstrPtr, A_Instr_NatEn) == InstrNat_CashAcct)
                continue;

            AMOUNT_T orderAmt = (niOrderAmt) * GET_PERCENT(stratEltTab[elt], A_StratElt_Value) / 100;

            if (negativeCashEn == NEGCASH_ENUM::NegCash_NotPermitted)
            {
                if (CMP_AMOUNT(ChildPtfCashAvb , 0.0, GET_ID(childPtfPtr, A_Ptf_CurrId)) <= 0)
                    break;

                if (CMP_AMOUNT(ChildPtfCashAvb, orderAmt, GET_ID(childPtfPtr, A_Ptf_CurrId)) <= 0)
                {
                    orderAmt = ChildPtfCashAvb;
                }
            }

            DBA_DYNFLD_STP   extOpStp = NULL;
            /* 3) generate buy orders in the portfolio linked to the model based on the instruments
                     and objectives defined in the model*/

            /*PMSTA-46230 -lalby- 28102021 -Flow_AmtCurrId will copy into ExtOp_OpCurrId and using script
                           to get account_id for the cash account */
            if (CMP_DYNFLD(flowPtr, StratEleInstrPtr,Flow_AmtCurrId, A_Instr_RefCurrId, IdType) != 0)
            {
                //convert orderAmt into instrument currency
                orderAmt = FIN_GetConvertedCurrencyAmount(domainPtr, hierHead, orderAmt,
                    GET_ID(flowPtr, Flow_AmtCurrId),
                    GET_ID(StratEleInstrPtr, A_Instr_RefCurrId));

                COPY_DYNFLD(flowPtr, Flow, Flow_AmtCurrId, StratEleInstrPtr, A_Instr, A_Instr_RefCurrId);
            }

            FIN_GenerateStandInstructOp(domainPtr, hierHead, flowPtr, standInstructPtr,
                planDefPtr, extractFlowPos,
                extractFlowPosNbr, listPtr, StratEleInstrPtr, childPtfPtr, &extOpStp, orderAmt, TRUE);

            COPY_DYNFLD(flowPtr, Flow, Flow_AmtCurrId, standInstructPtr, A_StandInstruct, A_StandInstruct_OpAmtCurrId);

            if (ret == RET_SUCCEED && extOpStp != NULLDYNST &&
                CMP_NUMBER(GET_NUMBER(extOpStp, ExtOp_Qty), ZERO_NUMBER) != 0)
            {
                notionalExtListPtr->push_back(extOpStp);
                ChildPtfCashAvb -= orderAmt;
            }

            if (ret == RET_SUCCEED && extOpStp != NULLDYNST &&
                CMP_NUMBER(GET_NUMBER(extOpStp, ExtOp_Qty), ZERO_NUMBER) == 0)
            {
                FREE_DYNST(extOpStp, ExtOp);
            }
        }
 
    }
    return ret;
}

 /******************************************************************************************************************
*
*   Function        :   FIN_ComputeMinMaxAmtWithPercentage
*
*   Description     :  if plan_objective_histo.amount_nature_e = 3 {Invested Percent} is defined
                       flow amount =Portfolioâ€™s Total Market Value * Invested Percent (invest_p)
*
**  Arguments       :  IN  - domainPtr , hierarchyHead,plandefinition ptr,instrPtr,standInstructPtr
**                     OUT -flowwlement
**
*
*   Return : TRUE or FALSE
*
*   Creation Date :    PMSTA-46093 - lalby - 11082021
*
*******************************************************************************************************************/

 STATIC RET_CODE FIN_ComputeMinMaxAmtWithPercentage(DBA_DYNFLD_STP domainPtr,
                                                    DBA_HIER_HEAD_STP hierHead,
                                                    DBA_DYNFLD_STP planDefPtr,
                                                    DBA_DYNFLD_STP     planRuleHistoStp,
                                                    DBA_DYNFLD_STP     objectiveStp,
                                                    AMOUNT_T           *minAmt,
                                                    AMOUNT_T           *maxAmt,
                                                    FLAG_T             *indexMinAmtFlg,
                                                    FLAG_T             *indexMaxAmtFlg,
                                                    AMOUNT_T           *ruleMaxAmtPtr,
                                                    bool calculateMvFlag)
 {
     RET_CODE          ret = RET_SUCCEED;

     AMOUNT_T         objMinAmt = NO_VALUE, objMaxAmt = NO_VALUE;
     AMOUNT_T         ruleMinAmt = NO_VALUE, ruleMaxAmt = NO_VALUE;
     FLAG_T           useObjectiveFlg = TRUE;

     (*ruleMaxAmtPtr) = NO_VALUE;
     (*indexMinAmtFlg) = FALSE;
     (*indexMaxAmtFlg) = FALSE;


     if (objectiveStp != nullptr && IS_NULLFLD(objectiveStp, A_PlanObjectiveHisto_AmountNature) == FALSE &&
         GET_ENUM(objectiveStp, A_PlanObjectiveHisto_AmountNature) == PlanObjectiveAmtNat_InvestedPercent)
     {
         PERCENT_T investPercentage{ 0 };
         if (IS_NULLFLD(objectiveStp, A_PlanObjectiveHisto_InvestP) == FALSE)
         {
             investPercentage = GET_PERCENT(objectiveStp, A_PlanObjectiveHisto_InvestP);
         }
         else
         {
             MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "FIN_UpdateFlowForInvestedPercentageAmount", "Plan Objective Invested Percent ");
             return(RET_GEN_ERR_INVARG);
         }

         ID_T ptfID = GET_ID(planDefPtr, A_PlanDefinition_PortfolioId);
         DBA_DYNFLD_STP ptfPtr;
         FLAG_T allocFlg = false;
         if (DBA_GetPtfById(ptfID, TRUE, &allocFlg, &ptfPtr,
             hierHead, UNUSED, UNUSED) != RET_SUCCEED)
         {
             MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "FIN_UpdateFlowForInvestedPercentageAmount", "Portfolio");
             return(RET_GEN_ERR_INVARG);
         }

         AMOUNT_T portfolioMarketValue = 0;
         if (ptfPtr != nullptr)
         {
             if (calculateMvFlag == TRUE && IS_NULLFLD(ptfPtr, A_Ptf_MktValM) == TRUE)
             {
                 ret = FIN_AnalysisValo(domainPtr, hierHead);

                 if (ret != RET_SUCCEED)
                 {
                     MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "FIN_UpdateFlowForInvestedPercentageAmount", "portfolioMarketValue");
                     return(RET_GEN_ERR_INVARG);
                 }
             }

             portfolioMarketValue = GET_AMOUNT(ptfPtr, A_Ptf_MktValM);

             if (GET_ID(ptfPtr, A_Ptf_CurrId) != GET_ID(domainPtr, A_Domain_CurrId))
             {
                 //convert into portfolio currency
                 portfolioMarketValue = FIN_GetConvertedCurrencyAmount(domainPtr, hierHead, portfolioMarketValue,
                                                                       GET_ID(domainPtr, A_Domain_CurrId),
                                                                       GET_ID(ptfPtr, A_Ptf_CurrId));
             }

             objMinAmt = (investPercentage / 100)*portfolioMarketValue;
         }
     }

     if (IS_NULLFLD(objectiveStp, A_PlanObjectiveHisto_MaxAmount) == FALSE)
     {
         objMaxAmt = GET_AMOUNT(objectiveStp, A_PlanObjectiveHisto_MaxAmount);
     }

     if (planRuleHistoStp != NULLDYNSTPTR)
     {
         if (IS_NULLFLD(planRuleHistoStp, A_PlanRuleHisto_MinAmount) == FALSE)
         {
             ruleMinAmt = GET_AMOUNT(planRuleHistoStp, A_PlanRuleHisto_MinAmount);
         }

         if (IS_NULLFLD(planRuleHistoStp, A_PlanRuleHisto_MaxAmount) == FALSE)
         {
             (*ruleMaxAmtPtr) = ruleMaxAmt = GET_AMOUNT(planRuleHistoStp, A_PlanRuleHisto_MaxAmount);
         }
     }

     /* Use min amount from objective or rule ? */
     if (objMinAmt == NO_VALUE)
         useObjectiveFlg = FALSE;
     else if (ruleMinAmt == NO_VALUE)
         useObjectiveFlg = TRUE;
     else if (objMinAmt < ruleMinAmt)
     {   /* this case must not happend, error message ? */
         useObjectiveFlg = FALSE;
     }
     else
         useObjectiveFlg = TRUE;


     if (useObjectiveFlg == TRUE)
     {
         (*minAmt) = objMinAmt;

         if (objMinAmt != NO_VALUE &&
             (GET_ENUM(objectiveStp, A_PlanObjectiveHisto_MinAmtIndexRule) == PlanObjectiveIdxRule_Amount ||
                 GET_ENUM(objectiveStp, A_PlanObjectiveHisto_MinAmtIndexRule) == PlanObjectiveIdxRule_Percent) &&
             GET_NUMBER(objectiveStp, A_PlanObjectiveHisto_MinAmtIndexValue) > 0.0)
             (*indexMinAmtFlg) = TRUE;
     }
     else
     {
         (*minAmt) = ruleMinAmt;
     }

     /* Use max amount from objective or rule ? */
     if (objMaxAmt == NO_VALUE)
         useObjectiveFlg = FALSE;
     else if (ruleMaxAmt == NO_VALUE)
         useObjectiveFlg = TRUE;
     else if (objMaxAmt > ruleMaxAmt)
     {   /* this case must not happend, error message ? */
         useObjectiveFlg = FALSE;
     }
     else
         useObjectiveFlg = TRUE;

     if (useObjectiveFlg == TRUE)
     {
         (*maxAmt) = objMaxAmt;

         if (objMaxAmt != NO_VALUE &&
             (GET_ENUM(objectiveStp, A_PlanObjectiveHisto_MaxAmtIndexRule) == PlanObjectiveIdxRule_Amount ||
                 GET_ENUM(objectiveStp, A_PlanObjectiveHisto_MaxAmtIndexRule) == PlanObjectiveIdxRule_Percent) &&
             GET_NUMBER(objectiveStp, A_PlanObjectiveHisto_MaxAmtIndexValue) > 0.0)
             (*indexMaxAmtFlg) = TRUE;
     }
     else
     {
         (*maxAmt) = ruleMaxAmt;
     }

     return(RET_SUCCEED);

 }
 
/*************************************************************************
**
**  Function    :   FIN_GenerateStandInstructOpForNotionalInstr()
**
**  Description : Generate all operations for standing instructions for NotionalInstr
**
**  Arguments   : 
**                 
**
**  Return : RET_SUCCEED or error code
**
**  Creation : PMSTA - 46093 - lalby - 24082021
**
*************************************************************************/

RET_CODE FIN_GenerateStandInstructOpForNotionalInstr(   DBA_DYNFLD_STP	  domainPtr,
                                                        DBA_HIER_HEAD_STP hierHead,
                                                        DBA_DYNFLD_STP    flowPtr,
                                                        DBA_DYNFLD_STP    standInstructPtr,
                                                        DBA_DYNFLD_STP	  planDefPtr,
                                                        DBA_DYNFLD_STP    *extractFlowPos,
                                                        int               extractFlowPosNbr,
                                                        DBA_DYNFLD_STP	  *listPtr,
                                                        DBA_DYNFLD_STP	  instrPtr,
                                                        std::vector< DBA_DYNFLD_STP > *notionalExtListPtr
 )
{

    RET_CODE          ret = RET_SUCCEED;

    if (instrPtr != NULLDYNST &&
        GET_ENUM(instrPtr, A_Instr_NatEn) != InstrNat_NotionalInstr &&
        GET_ENUM(instrPtr, A_Instr_SubNatEn) != SubNat_ModelPortfolio )
    {
        return false;
    }

    AMOUNT_T            niOrderAmt=0;
 
    if (standInstructPtr != NULLDYNSTPTR)
        niOrderAmt = GET_AMOUNT(standInstructPtr, A_StandInstruct_OpAmt);
 
	DBA_SetHierLnkUsed(hierHead, A_Strat, A_Strat_A_StratHist_Ext);
	DBA_MakeSpecRecLinks(hierHead, A_Strat, A_Strat_A_StratHist_Ext);

	DBA_SetHierLnkUsed(hierHead, A_StratHist, A_StratHist_A_StratElt_Ext);
	DBA_MakeSpecRecLinks(hierHead, A_StratHist, A_StratHist_A_StratElt_Ext);

    FIN_PTFINFO_ST 		    ptfInfoSt;
    memset(&ptfInfoSt, 0, sizeof(FIN_PTFINFO_ST));
    ID_T planDefPortId = GET_ID(planDefPtr, A_PlanDefinition_PortfolioId);
    FIN_CheckStratPtfTotal(hierHead, domainPtr, planDefPortId, &ptfInfoSt);  //head portfolio

    SET_ENUM(domainPtr, A_Domain_OpNatEn, OpNat_Buy);

     FIN_CreateOrderForNI(domainPtr, hierHead, flowPtr, standInstructPtr,
            planDefPtr, instrPtr,
            niOrderAmt, &ptfInfoSt, extractFlowPos, extractFlowPosNbr, listPtr,
            notionalExtListPtr);

    return ret;
 }
    

/************************************************************************
**
**  Function    :   FIN_GenerateStandInstructOp()
**
**  Description :   Generate all operations for standing instructions
**                 
**  Arguments   :   domainPtr	  domain pointer
**                  argHierHead   hierarchy pointer
**
**  Return      :   RET_SUCCEED 	or error code
**
**  Creation    :   PMSTA06761 - DDV - 080731
**  Modification:   PMSTA44270 - VSW - 260821 - Ensuring the Holiday Calendar if available is picked for all SI creations and not only for Sytematic Invesment Plan
**
*************************************************************************/
STATIC RET_CODE FIN_GenerateStandInstructOp(DBA_DYNFLD_STP	  domainPtr,
                                            DBA_HIER_HEAD_STP hierHead,
                                            DBA_DYNFLD_STP    flowPtr,
                                            DBA_DYNFLD_STP    standInstructPtr,
											DBA_DYNFLD_STP	  planDefPtr,
                                            DBA_DYNFLD_STP    *extractFlowPos, 
                                            int               extractFlowPosNbr,
                                            DBA_DYNFLD_STP	  *listPtr,
                                            DBA_DYNFLD_STP	  instrPtr,
                                            DBA_DYNFLD_STP	  ptfPtr,
                                            DBA_DYNFLD_STP	  *extOpPtr,
                                            AMOUNT_T          orderAmount,
                                            bool isNotional)
{
    RET_CODE          ret = RET_SUCCEED;
    DBA_DYNFLD_STP    extOperation=NULL, operation=NULL;
    FLAG_T            *scptFlagTabExtOp, *scptFlagTabOp, existPosFlg = FALSE, stopFlg=FALSE;
	int               i, qtyFld = NO_VALUE, opNetAmtFld = NO_VALUE, step, cmp, opCurrFld = 0, acctFld = 0, acctCurrFld = 0, opPriceFld = NO_VALUE;
    OBJECT_ENUM       objectOperation=NullEntity;
    NUMBER_T          oddLotQty=1.0, qty=0.0;
    AMOUNT_T          targetAmt=0.0, prevOpNetAmt=0.0;
	DATETIME_T		  opDate;
	opDate.date = 0;
	opDate.time = 0;
    bool isInternal = false, isExternal = false;

    if ((extOperation = ALLOC_DYNST(ExtOp)) == NULL)
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC); 
    }

    DBA_SetDfltEntityFld(EOp, ExtOp, extOperation);

    if (isNotional == true)
    {
        COPY_DYNFLD(extOperation, ExtOp, ExtOp_PtfId, ptfPtr, A_Ptf, A_Ptf_Id);
        COPY_DYNFLD(extOperation, ExtOp, ExtOp_InstrId, instrPtr, A_Instr, A_Instr_Id);
        COPY_DYNFLD(extOperation, ExtOp, ExtOp_NotionalInstrId, standInstructPtr, A_StandInstruct, A_StandInstruct_InstrId);
        SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);
    }
    else
    {
        COPY_DYNFLD(extOperation, ExtOp, ExtOp_PtfId, standInstructPtr, A_StandInstruct, A_StandInstruct_PtfId);
        COPY_DYNFLD(extOperation, ExtOp, ExtOp_InstrId, flowPtr, Flow, Flow_InstrId);
    }

    COPY_DYNFLD(extOperation, ExtOp, ExtOp_InstrCurrId,  instrPtr,         A_Instr,         A_Instr_RefCurrId); 
    COPY_DYNFLD(extOperation, ExtOp, ExtOp_PtfCurrId,    ptfPtr ,          A_Ptf,           A_Ptf_CurrId); 
    COPY_DYNFLD(extOperation, ExtOp, ExtOp_StatusEn,     domainPtr,        A_Domain,        A_Domain_EvtOperStatEn); 
    COPY_DYNFLD(extOperation, ExtOp, ExtOp_FlowId,       flowPtr,          Flow,            Flow_Id);
    COPY_DYNFLD(extOperation, ExtOp, ExtOp_EvtCd,        flowPtr,          Flow,            Flow_EvtCd);
    SET_NUMBER(extOperation, ExtOp_EvtNbr, (NUMBER_T) GET_INT(flowPtr, Flow_EvtNbr));
    COPY_DYNFLD(extOperation, ExtOp, ExtOp_AcctDate,     flowPtr,          Flow,            Flow_OptimalDate);

    /*SI Chnages LIK*/
    if (StandInstructOpNatEn::Invest == static_cast<StandInstructOpNatEn>(GET_ENUM(standInstructPtr, A_StandInstruct_OpNatEn))
        && (!IS_NULLFLD(standInstructPtr, A_StandInstruct_CashPtfId) && !IS_NULLFLD(standInstructPtr, A_StandInstruct_AccountId)))
    {

        SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Buy);
        COPY_DYNFLD(extOperation, ExtOp, ExtOp_CashPtfId, standInstructPtr, A_StandInstruct, A_StandInstruct_CashPtfId);
        COPY_DYNFLD(extOperation, ExtOp, ExtOp_AcctId, standInstructPtr, A_StandInstruct, A_StandInstruct_AccountId);
        isInternal = true;
    }
    else if (StandInstructOpNatEn::Withdrawal == static_cast<StandInstructOpNatEn>(GET_ENUM(standInstructPtr, A_StandInstruct_OpNatEn))
        && (!IS_NULLFLD(standInstructPtr, A_StandInstruct_CashPtfId) && !IS_NULLFLD(standInstructPtr, A_StandInstruct_AccountId)))
    {

        SET_ENUM(extOperation, ExtOp_NatureEn, OpNat_Sell);
        COPY_DYNFLD(extOperation, ExtOp, ExtOp_CashPtfId, standInstructPtr, A_StandInstruct, A_StandInstruct_CashPtfId);
        COPY_DYNFLD(extOperation, ExtOp, ExtOp_AcctId, standInstructPtr, A_StandInstruct, A_StandInstruct_AccountId);
        isInternal = true;

    }
    else if (StandInstructOpNatEn::Invest == static_cast<StandInstructOpNatEn>(GET_ENUM(standInstructPtr, A_StandInstruct_OpNatEn)) || 
        StandInstructOpNatEn::Withdrawal == static_cast<StandInstructOpNatEn>(GET_ENUM(standInstructPtr, A_StandInstruct_OpNatEn)))
    {
        SET_ENUM(extOperation, ExtOp_NatureEn, (StandInstructOpNatEn::Invest == static_cast<StandInstructOpNatEn>(GET_ENUM(standInstructPtr, A_StandInstruct_OpNatEn))? OpNat_Invest : OpNat_Withdr));
        COPY_DYNFLD(extOperation, ExtOp, ExtOp_ExternalBankAcctOwnrName, standInstructPtr, A_StandInstruct, A_StandInstruct_ExternalBankAcctOwnrName);
        COPY_DYNFLD(extOperation, ExtOp, ExtOp_CounterpartAccount, standInstructPtr, A_StandInstruct, A_StandInstruct_CounterpartAccount);
        COPY_DYNFLD(extOperation, ExtOp, ExtOp_ExtrnlBnkAcctOwnrAddr1, standInstructPtr, A_StandInstruct, A_StandInstruct_ExtrnlBnkAcctOwnrAddr1);
        COPY_DYNFLD(extOperation, ExtOp, ExtOp_ExternalBankBic, standInstructPtr, A_StandInstruct, A_StandInstruct_ExternalBankBic);
        SET_NULL_ID(extOperation, ExtOp_CashPtfId);
        SET_NULL_ID(extOperation, ExtOp_AcctId);
        isExternal = true;
            
    }
    else
    {
        COPY_DYNFLD(extOperation, ExtOp, ExtOp_NatureEn, standInstructPtr, A_StandInstruct, A_StandInstruct_OpNatEn);
    }
	/* < PMSTA-28682 - RAK - 171219 - Operation date business day management */
	/*COPY_DYNFLD(extOperation, ExtOp, ExtOp_OpDate, flowPtr, Flow, Flow_OptimalDate); */
	opDate = GET_DATETIME(flowPtr, Flow_OptimalDate);

	CALNEXTBUSDATERULE_ENUM nextBusDate = CalNextBusDateRule_Next;
	/* standing instruction calendar if exist, instrument or system then */
	if ((ret = SCE_CldrNextBusinessDate(instrPtr, GET_ID(standInstructPtr, A_StandInstruct_CalendarId),
		&nextBusDate, GET_DATETIME(flowPtr, Flow_OptimalDate), &opDate)) != RET_SUCCEED)
	{
		FREE_DYNST(extOperation, ExtOp);
		return ret;
	}
	
	SET_DATETIME(extOperation, ExtOp_OpDate, opDate);
	/* PMSTA-28682 - RAK - 190109 > */

    COPY_DYNFLD(extOperation, ExtOp, ExtOp_OpCurrId,     flowPtr ,         Flow,            Flow_AmtCurrId);
	COPY_DYNFLD(extOperation, ExtOp, ExtOp_StandInstructId, flowPtr,       Flow,            Flow_StandInstructId); /* PMSTA28294 - RAK - 171128 */

    if (GET_ENUM(extOperation, ExtOp_NatureEn) == OpNat_Buy)
        objectOperation = BuyOpEnt;
    else if (GET_ENUM(extOperation, ExtOp_NatureEn) == OpNat_Sell)
        objectOperation = SellOpEnt;
    else if (GET_ENUM(extOperation, ExtOp_NatureEn) == OpNat_Invest)
        objectOperation = InvestOpEnt;
    else if (GET_ENUM(extOperation, ExtOp_NatureEn) == OpNat_Withdr)
        objectOperation = WithdrOpEnt;

	/* if op exist, we don't need  to treat it */
    if ((ret = FIN_CheckExistPos(extractFlowPos, 
                                 extractFlowPosNbr, 
                                 extOperation, listPtr, domainPtr, hierHead, &existPosFlg, TRUE, NULLDYNST, FALSE))!=RET_SUCCEED)
    {
        MSG_SendMesg(RET_FIN_ERR_CHECKFAILED, 0, FILEINFO,
            GET_CODE(ptfPtr, A_Ptf_Cd), 
            GET_CODE(instrPtr, A_Instr_Cd)); 
        FREE_DYNST(extOperation, ExtOp);
        return ret;
    }

    if (existPosFlg == FALSE)
    {
        if ((scptFlagTabExtOp = (FLAG_T *) CALLOC(GET_FLD_NBR(ExtOp),sizeof(FLAG_T))) == NULL) /* REF7264 - DDV - 020326 - Compil C++ */
        {
            FREE_DYNST(extOperation, ExtOp);
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        for (i=0; i<GET_FLD_NBR(ExtOp) ;i++)
            scptFlagTabExtOp[i]=FALSE;

        scptFlagTabExtOp[ExtOp_PtfId]=TRUE; 
        scptFlagTabExtOp[ExtOp_NatureEn]=TRUE; 
        scptFlagTabExtOp[ExtOp_InstrCurrId]=TRUE;
        scptFlagTabExtOp[ExtOp_PtfCurrId]=TRUE;
        scptFlagTabExtOp[ExtOp_StatusEn]=TRUE;
        scptFlagTabExtOp[ExtOp_FlowId]=TRUE;
        scptFlagTabExtOp[ExtOp_EvtCd]=TRUE;
        scptFlagTabExtOp[ExtOp_EvtNbr]=TRUE;
        scptFlagTabExtOp[ExtOp_InstrId]=TRUE;
        scptFlagTabExtOp[ExtOp_AcctDate]=TRUE;
        scptFlagTabExtOp[ExtOp_OpDate]=TRUE;
        scptFlagTabExtOp[ExtOp_OpCurrId]=TRUE;
        if (isExternal)
        {
            scptFlagTabExtOp[ExtOp_ExternalBankAcctOwnrName] = TRUE;
            scptFlagTabExtOp[ExtOp_CounterpartAccount] = TRUE;
            scptFlagTabExtOp[ExtOp_ExtrnlBnkAcctOwnrAddr1] = TRUE;
            scptFlagTabExtOp[ExtOp_ExternalBankBic] = TRUE;
            scptFlagTabExtOp[ExtOp_CashPtfId] = TRUE;
            scptFlagTabExtOp[ExtOp_AcctId] = TRUE;
        }
        else if (isInternal)
        {
            scptFlagTabExtOp[ExtOp_CashPtfId] = TRUE;
            scptFlagTabExtOp[ExtOp_AcctId] = TRUE;
        }

        /* first step is to estimate the op_net_amount for an odd lot (or for one unit if odd lot is null) */
		/* PMSTA-17209 - DDV - 131217 - Special case for cash account. Use 1000 instead of 1 to avoid rounding error and set oddlot to 0.01 to allow cents in quantity */
        if (GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_CashAcct)
         {
            SET_NUMBER(extOperation, ExtOp_Qty, 1000);
            oddLotQty=0.01;
        } 
        else if (IS_NULLFLD(instrPtr, A_Instr_OddLotQty) == FALSE)
        {
            oddLotQty=GET_NUMBER(instrPtr, A_Instr_OddLotQty);
            if (oddLotQty < 1.0)
            {
                SET_NUMBER(extOperation, ExtOp_Qty, 1.0);
            }
            else
            {
            COPY_DYNFLD(extOperation, ExtOp, ExtOp_Qty, instrPtr, A_Instr, A_Instr_OddLotQty);
            }
        }
        else
        {
            SET_NUMBER(extOperation, ExtOp_Qty, 1.0);
            oddLotQty=GET_NUMBER(extOperation, ExtOp_Qty);
        }
        scptFlagTabExtOp[ExtOp_Qty]=TRUE;

        if ((objectOperation==NullEntity) || ((operation = ALLOC_DYNST(GET_EDITGUIST(objectOperation))) == NULL))
        {
            FREE_DYNST(extOperation, ExtOp);
            FREE(scptFlagTabExtOp);
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        OPE_ExtOpToOp(extOperation, operation, hierHead, FALSE);
    
        if ((scptFlagTabOp = (FLAG_T *) CALLOC(GET_FLD_NBR(GET_EDITGUIST(objectOperation)),sizeof(FLAG_T))) == NULL)
        {
            FREE_DYNST(operation, GET_EDITGUIST(objectOperation));
            FREE_DYNST(extOperation, ExtOp);
            FREE(scptFlagTabExtOp);
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }
    
        OPE_ExtFlToFl(scptFlagTabExtOp, scptFlagTabOp, (OPNAT_ENUM) GET_ENUM(extOperation, ExtOp_NatureEn), TRUE); /* REF7264 - DDV - 020326 - Compil C++ */
    
        /* Compute Default Values */
		/* PMSTA-30063 - RAK - Use screen profile and screen -> call ComputeScreenDv with DictFct_EventGeneration and DictScreen */
        /* SCPT_ComputeDV(objectOperation, scptFlagTabOp, operation, TRUE, TRUE, NULL); */ /* REF4229 - SSO - 000919 */
		SCPT_ComputeScreenDV(objectOperation, DictFct_EventGeneration, scptFlagTabOp, NULL, operation,
							NULLDYNST,
							domainPtr,
							NULLDYNST,			
							TRUE,
							TRUE,
							EvalType_DefValAndFilter,
							-1,
							NULL,
							NULL,
							hierHead,
							0,
							DictScreen,
							NULL,
							NULL,
							NULL,
							NULL,
							NULL,
							NullEntity,
							FALSE,
							FALSE,
							0);
    

        /* now adjust quantity to match the target amount */

        if (isNotional == true)
        {
            targetAmt = orderAmount;
        }
        else
        targetAmt = GET_PRICE(flowPtr, Flow_AmtUnit);
        if (objectOperation == BuyOpEnt)
        {
            qtyFld      = BuyOp_Qty;
            opNetAmtFld = BuyOp_OpNetAmt;
            acctCurrFld = BuyOp_AcctCurrId;
			opPriceFld = BuyOp_Price; //PMSTA-48440
        }
        else if (objectOperation == SellOpEnt)
        {
            qtyFld = SellOp_Qty;
            opNetAmtFld = SellOp_OpNetAmt;
            acctCurrFld = SellOp_AcctCurrId;
			opPriceFld = SellOp_Price; //PMSTA-48440
        }
        else if (objectOperation == InvestOpEnt)
        {
            qtyFld = InvestOp_Qty;
            opNetAmtFld = InvestOp_OpNetAmt;
            acctCurrFld = InvestOp_AcctCurrId;
			opPriceFld = InvestOp_Price; //PMSTA-48440
        }
        else if (objectOperation == WithdrOpEnt)
        {
            qtyFld = WithdrOp_Qty;
            opNetAmtFld = WithdrOp_OpNetAmt;
            acctCurrFld = WithdrOp_AcctCurrId;
			opPriceFld = WithdrOp_Price; //PMSTA-48440
        }
    
        if (CMP_AMOUNT(GET_AMOUNT(operation, opNetAmtFld) ,0.0, GET_ID(extOperation, ExtOp_OpCurrId)) == 0)
        {
            /* error */
	        MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
			             "FIN_GenerateStandInstructOp", "op_net_amount_m");
            FREE_DYNST(operation, GET_EDITGUIST(objectOperation));
            FREE_DYNST(extOperation, ExtOp);
            FREE(scptFlagTabExtOp);
            FREE(scptFlagTabOp);
            return(RET_FIN_ERR_INVDATA);
        }

		//PMSTA-48440: compare for the price
		if (CMP_NUMBER(GET_NUMBER(operation, opPriceFld), 0.0) == 0)
		{
			/* error */
			MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO,
				"FIN_GenerateStandInstructOp", "price_n");
			FREE_DYNST(operation, GET_EDITGUIST(objectOperation));
			FREE_DYNST(extOperation, ExtOp);
			FREE(scptFlagTabExtOp);
			FREE(scptFlagTabOp);
			return(RET_FIN_ERR_INVDATA);
		}

        /* estimate the down quantity using the op for one oddlot, and update op with this qty  */
        for (i=0; i<GET_FLD_NBR(GET_EDITGUIST(objectOperation));i++)
            scptFlagTabExtOp[i]=FALSE;

        /* PMSTA-17209 - DDV - 140508 - If its is a Forex operation and the account have the same currency than standing instruction (SI)
           - change op currency to instrument currency.
           - lock account and op currency fields to avoid change by DV.
           - use account amount instead of op amount to match SI amount. 
        */
        if (GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_CashAcct &&
            CMP_DYNFLD(flowPtr, operation, Flow_AmtCurrId, acctCurrFld, IdType) == 0)
        {
            if (objectOperation == BuyOpEnt)
            {
                opCurrFld   = BuyOp_OpCurrId;
                acctFld     = BuyOp_AcctId;
                opNetAmtFld = BuyOp_AcctNetAmt;
            }
            else if(objectOperation == SellOpEnt)
            {
                opCurrFld   = SellOp_OpCurrId;
                acctFld     = SellOp_AcctId;
                opNetAmtFld = SellOp_AcctNetAmt;
            }
            else if (objectOperation == InvestOpEnt)
            {
                opCurrFld = InvestOp_OpCurrId;
                acctFld = InvestOp_AcctId;
                opNetAmtFld = InvestOp_AcctNetAmt;
            }
            else if (objectOperation == WithdrOpEnt)
            {
                opCurrFld = WithdrOp_OpCurrId;
                acctFld = WithdrOp_AcctId;
                opNetAmtFld = WithdrOp_AcctNetAmt;
            }

            COPY_DYNFLD(operation, GET_EDITGUIST(objectOperation), opCurrFld,     instrPtr,         A_Instr,         A_Instr_RefCurrId);
            scptFlagTabOp[opCurrFld]=TRUE;
            scptFlagTabOp[acctFld]=TRUE;
        }

        scptFlagTabExtOp[qtyFld]=TRUE;

		/* PMSTA-17209 - DDV - 131217 - Special case for cash account, apply 1000 factor */
        if (GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_CashAcct)
        {
            qty = TLS_Round((targetAmt*1000.0)/GET_AMOUNT(operation, opNetAmtFld), 0.01, RndRule_Down);
            SET_NUMBER(operation, qtyFld, qty);
        }
        else
        {
			//PMSTA-48440: Use price instead of Net amount to arrive at quantity since the opNetAmtFld is calculated from
			// gross amount which is basically rounded off amount of price.Ex: if price is 14.678144, the gross amount is rounded off to
			// 14.68 and hence the opNetAmtFld will also be 14.68. This will result in calculating the qty wrong.
			//qty = TLS_Round(targetAmt/GET_AMOUNT(operation, opNetAmtFld), oddLotQty, RndRule_Down);
			qty = TLS_Round(targetAmt / GET_NUMBER(operation, opPriceFld), oddLotQty, RndRule_Down);
            SET_NUMBER(operation, qtyFld, qty * GET_NUMBER(extOperation, ExtOp_Qty));
        }


        /* Compute Default Values */
		/* PMSTA-30063 - RAK - Use screen profile and screen -> call ComputeScreenDv with DictFct_EventGeneration and DictScreen */
        /* SCPT_ComputeDV(objectOperation, scptFlagTabOp, operation, FALSE, TRUE, NULL); */
		SCPT_ComputeScreenDV(objectOperation, DictFct_EventGeneration, scptFlagTabOp, NULL, operation,
			NULLDYNST,
			domainPtr,
			NULLDYNST,
			FALSE,
			TRUE,
			EvalType_DefValAndFilter,
			-1,
			NULL,
			NULL,
			hierHead,
			0,
			DictScreen,
			NULL,
			NULL,
			NULL,
			NULL,
			NULL,
			NullEntity,
			FALSE,
			FALSE,
			0);

        cmp = CMP_AMOUNT(GET_AMOUNT(operation, opNetAmtFld), targetAmt, GET_ID(extOperation, ExtOp_OpCurrId));

        stopFlg = FALSE;
        step=0;

        if (cmp > 0)
            step = -1;
        else if (cmp < 0)
            step = +1;
        else 
            stopFlg = TRUE;

        while (step != 0)
        {
            qty = GET_NUMBER(operation, qtyFld) + ((NUMBER_T) step * oddLotQty);
            SET_NUMBER(operation, qtyFld, qty);
            prevOpNetAmt = GET_AMOUNT(operation, opNetAmtFld);

            /* Compute Default Values */
			/* PMSTA-30063 - RAK - Use screen profile and screen -> call ComputeScreenDv with DictFct_EventGeneration and DictScreen */
			/* SCPT_ComputeDV(objectOperation, scptFlagTabOp, operation, FALSE, TRUE, NULL); */
			SCPT_ComputeScreenDV(objectOperation, DictFct_EventGeneration, scptFlagTabOp, NULL, operation,
				NULLDYNST,
				domainPtr,
				NULLDYNST,
				FALSE,
				TRUE,
				EvalType_DefValAndFilter,
				-1,
				NULL,
				NULL,
				hierHead,
				0,
				DictScreen,
				NULL,
				NULL,
				NULL,
				NULL,
				NULL,
				NullEntity,
				FALSE,
				FALSE,
				0);

            cmp = CMP_AMOUNT(GET_AMOUNT(operation, opNetAmtFld), targetAmt, GET_ID(extOperation, ExtOp_OpCurrId));

            if (CMP_AMOUNT(GET_AMOUNT(operation, opNetAmtFld) , prevOpNetAmt, GET_ID(extOperation, ExtOp_OpCurrId)) == 0)
            {
                /* error */
	            MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
			                 "FIN_GenerateStandInstructOp", "op_net_amount_m");
                FREE_DYNST(operation, GET_EDITGUIST(objectOperation));
                FREE_DYNST(extOperation, ExtOp);
                FREE(scptFlagTabExtOp);
                FREE(scptFlagTabOp);
                return(RET_FIN_ERR_INVDATA);
            }

            if (stopFlg == TRUE || cmp == 0)
            {
                step = 0;
            }
            else if (step == +1 && cmp > 0)
            {
                step = -1;
                stopFlg = TRUE;
            }
            else if (step == -1 && cmp < 0)
            {
                step = 0;
                stopFlg = TRUE;
            }
        }
            
        if (OPE_OpToExtOp(operation, (OPNAT_ENUM) GET_ENUM(extOperation, ExtOp_NatureEn), extOperation, FALSE) != RET_SUCCEED)  /*  FPL-REF9215-030811  Add Flag Impact */ /* REF7264 - DDV - 020326 - Compil C++ */
        {
            FREE_DYNST(operation, GET_EDITGUIST(objectOperation));
            FREE_DYNST(extOperation, ExtOp);
            return(RET_GEN_ERR_INVARG);
        }

	    SET_ENUM(extOperation, ExtOp_DbStatusEn, ExtOpDbStatus_ToInsert);        

        FREE(scptFlagTabOp);
        FREE(scptFlagTabExtOp);
	    FREE_DYNST(operation, GET_EDITGUIST(objectOperation));

        SET_FLAG(extOperation, ExtOp_ConfirmedFlg, GET_FLAG(flowPtr, Flow_ConfirmedFlg));
	    SET_ENUM(extOperation, ExtOp_DbStatusEn, ExtOpDbStatus_ToInsert); 

        /* operation is generated, set information into standing instruct for last_generation_d update */
        SET_FLAG(standInstructPtr, A_StandInstruct_UpdGenDateFlg, TRUE);

        (*extOpPtr) = extOperation;
    }
    else
    {
        FREE_DYNST(extOperation, ExtOp);
    }

    return(RET_SUCCEED);
}   

/************************************************************************
*
*   Function      :   FIN_FilterCashPosByInstrExt
*
*   Description   :   Return cash instrument postions
*                     return TRUE  -> record must be extract
*                            FALSE -> record musn't be extract
*
*   Arguments     :   dynSt   first element pointer
*
*   Return        :   TRUE or FALSE
*
*   Creation      :   PMSTA-46257 -  Lalby -  12102021
*
*************************************************************************/
STATIC int FIN_FilterCashPosByInstrExt(DBA_DYNFLD_STP extPos, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP notUsed)
{
    if (GET_EXTENSION_PTR(extPos, ExtPos_A_Instr_Ext) != nullptr)
    {
        DBA_DYNFLD_STP instrPtr = *(GET_EXTENSION_PTR(extPos, ExtPos_A_Instr_Ext));

        if (static_cast<INSTRNAT_ENUM> GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_CashAcct)
        {
            return(TRUE);
        }
    }

    return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_GetCashBalanceFromInstrExt()
**
**  Description :   calculate cash balance for the portfolio from the extpos
**
**  Arguments   :   DBA_HIER_HEAD_STP   stratHierHead
**                  DBA_DYNFLD_STP      childPtfPtr
**                  AMOUNT_T            * cashAvb
**
**
**  Return      :   RET_CODE
**
*************************************************************************/
STATIC RET_CODE FIN_GetCashBalanceFromInstrExt(DBA_HIER_HEAD_STP    stratHierHead,
    DBA_DYNFLD_STP       childPtfPtr,
    AMOUNT_T *           cashAvb)
{
    RET_CODE ret = RET_SUCCEED;

    DBA_DYNFLD_STP  *extPosTab = NULLDYNSTPTR;
    int              extPosNbr = 0;

    /*get all cash postions for the portfolio*/
    if ((ret = DBA_ExtractHierEltRecByIndexKey(stratHierHead,
        ExtPos,
        ExtPos_PtfId,
        *childPtfPtr,
        FALSE, /* copyRecFlag */
        FIN_FilterCashPosByInstrExt, NULLDYNST, NULLFCT, FALSE,
        &extPosNbr,
        &extPosTab)) != RET_SUCCEED)
    {
        FREE(extPosTab);
        return(ret);

    }

    for (int i = 0; i < extPosNbr; i++)
    {
        DBA_DYNFLD_STP posVal = NULL;
        if (GET_EXTENSION_PTR(extPosTab[i], ExtPos_PosVal_Ext) != NULL &&
            (posVal = *(GET_EXTENSION_PTR(extPosTab[i], ExtPos_PosVal_Ext))) != NULL)
        {
            /*get value for each valid cash postions*/
            if (GET_FLAG(extPosTab[i], ExtPos_AcctFlg) == TRUE) {
                *cashAvb += GET_NUMBER(posVal, PosVal_PosMktValAmt);
            }

        }
    }

    FREE(extPosTab);

    return ret;
}


/************************************************************************
**
**  Function    :   FIN_GenerateStandInstructFlowsAndOps()
**
**  Description :   Generate all Flows and operations for standing instructions
**
**  Arguments   :   domainPtr	  domain pointer
**                  argHierHead   hierarchy pointer
**
**  Return      :   RET_SUCCEED 	or error code
**
**  Creation    :   PMSTA06761 - DDV - 080731
**
*************************************************************************/
RET_CODE FIN_GenerateStandInstructFlowsAndOps(DBA_DYNFLD_STP	 domainPtr,
											  DBA_HIER_HEAD_STP hierHead,
											  DBA_DYNFLD_STP    *extractFlowPos,
											  int               extractFlowPosNbr,
											  DBA_DYNFLD_STP    *standInstructTab,
											  int               standInstructNbr,
											  DBA_DYNFLD_STP    planDefStp,
											  DBA_DYNFLD_STP	*listPtr,
                                              FLAG_T            insertDataInHierFlg,
											  DBA_DYNFLD_STP    **flowTabPtr,
											  int               *flowNbrPtr,
											  DBA_DYNFLD_STP    **extOpTabPtr,
											  int               *extOpNbrPtr)
{
	int				i=0, j=0, k=0, flowNbr=0, tmpFlowNbr=0, extOpNbr=0,
                    flowAllocSz=0, extOpAllocSz=0;
	RET_CODE        ret = RET_SUCCEED;
	DBA_DYNFLD_STP  *flowTab = NULLDYNSTPTR, *tmpFlowTab = NULLDYNSTPTR, *extOpTab = NULLDYNSTPTR, extOpStp = NULLDYNST;
    DBA_DYNFLD_STP  instrPtr=NULLDYNST, ptfPtr=NULLDYNST;
    MemoryPool      mpLocal;
    MemoryPool      mpCaller;
	
    if (standInstructNbr == 0)
        return(RET_SUCCEED);

    if (insertDataInHierFlg == FALSE)
    {
        if (flowTabPtr == NULLDYNSTPTR ||
            flowNbrPtr == NULLDYNSTPTR ||
            extOpTabPtr == NULLDYNSTPTR ||
            extOpNbrPtr == NULLDYNSTPTR
           )
        {
            return(RET_GEN_ERR_INVARG);
        }
        else
        {
            extOpAllocSz = flowAllocSz = 5 * standInstructNbr;
            flowTab = (DBA_DYNFLD_STP *) mpCaller.calloc(flowAllocSz, sizeof(DBA_DYNFLD_STP));
            extOpTab = (DBA_DYNFLD_STP *) mpCaller.calloc(extOpAllocSz, sizeof(DBA_DYNFLD_STP));
        }
    }


    AMOUNT_T headCashAvb = 0;

	/* for each standing instruction generate the flows */
	for (i = 0; i < standInstructNbr; i++)
	{
		if ((ret = FIN_GenerateStandInstructFlows(domainPtr,
                                                  GET_DATETIME(domainPtr, A_Domain_CalcRefDate),
                                                  GET_DATETIME(domainPtr, A_Domain_InterpTillDate),
                                                  hierHead, standInstructTab[i], &tmpFlowTab, &tmpFlowNbr)) == RET_SUCCEED)
		{           
            if (insertDataInHierFlg == TRUE)
			{
                /* add all flows into hierarchy */
			    if (DBA_AddHierRecordList(hierHead, tmpFlowTab, tmpFlowNbr, Flow, FALSE) != RET_SUCCEED)
			    {
                    DBA_FreeDynStTab(tmpFlowTab, tmpFlowNbr, Flow);
				    return(RET_DBA_ERR_HIER);
                }
                mpLocal.ownerPtr(tmpFlowTab);
            }
            else
            {
                mpLocal.ownerPtr(tmpFlowTab);
                /* realloc if needed */
                if ((flowNbr + tmpFlowNbr) > flowAllocSz)
                {
                    flowAllocSz += tmpFlowNbr;
                    flowTab = (DBA_DYNFLD_STP *) mpCaller.realloc(flowTab, flowAllocSz * sizeof(DBA_DYNFLD_STP));
                }

                for (k=0; k<tmpFlowNbr; k++)
                {
                    flowTab[flowNbr] = tmpFlowTab[k];
                    flowNbr++;
                }
            }
 
			/* for each flow, generate the operation */
			for (j = 0; j < tmpFlowNbr; j++)
            {
                FLAG_T allocInstr = FALSE;
                if (DBA_GetInstrById(GET_ID(standInstructTab[i], A_StandInstruct_InstrId), TRUE, &allocInstr, &instrPtr,
                                     hierHead, UNUSED, UNUSED) != RET_SUCCEED)
                {
	                MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,  "FIN_GenerateStandInstructOp", "instrument");
                    return(RET_GEN_ERR_INVARG);
                }

                if(allocInstr == TRUE)
                {
                    mpLocal.ownerDynStp(instrPtr);
                }

                /*PMSTA-46257 -lalby - 11102021  check -ve cash allowed in head*/
                if (planDefStp != nullptr && 
                    (StandInstructOpNatEn::Buy == static_cast<StandInstructOpNatEn>(GET_ENUM(standInstructTab[i], A_StandInstruct_OpNatEn))))
                {
                    if (i == 0) //first standing instruction for the plan definition
                    {
                        FLAG_T allocPtf = FALSE;
                        if (DBA_GetPtfById(GET_ID(standInstructTab[i], A_StandInstruct_PtfId), TRUE, &allocPtf, &ptfPtr,
                            hierHead, UNUSED, UNUSED) != RET_SUCCEED)
                        {
                            MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "FIN_GenerateStandInstructOp", "portfolio");
                            return(RET_GEN_ERR_INVARG);
                        }

                        if(allocPtf == TRUE)
                        {
                            mpLocal.ownerDynStp(ptfPtr);
                        }

                        if (GET_ENUM(ptfPtr, A_Ptf_NegativeCashEn) == NEGCASH_ENUM::NegCash_NotPermitted)
                        {
                            FIN_ValoProcess(domainPtr, hierHead, FIN_FilterPStock);
                            FIN_GetCashBalanceFromInstrExt(hierHead, ptfPtr, &headCashAvb);
                        }
                    }

                    if (GET_ENUM(ptfPtr, A_Ptf_NegativeCashEn) == NEGCASH_ENUM::NegCash_NotPermitted)
                    {
                        if (CMP_AMOUNT(headCashAvb, 0.0, GET_ID(ptfPtr, A_Ptf_CurrId)) <= 0)
                            break;

                        if (CMP_AMOUNT(headCashAvb, GET_AMOUNT(standInstructTab[i], A_StandInstruct_OpAmt), GET_ID(ptfPtr, A_Ptf_CurrId)) <= 0)
                        {
                            SET_AMOUNT(standInstructTab[i], A_StandInstruct_OpAmt, headCashAvb);
                        }
                    }
                }

                /*PMSTA - 46093 - lalby - 24082021*/
                bool isNotional = FALSE;
                if (planDefStp !=nullptr && instrPtr != NULLDYNST &&
                    GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_NotionalInstr &&
                    GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_ModelPortfolio && 
                    (StandInstructOpNatEn::Buy == static_cast<StandInstructOpNatEn>(GET_ENUM(standInstructTab[i], A_StandInstruct_OpNatEn))) &&
                    (GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_EventGeneration))  //journal case?
                {
                    isNotional = TRUE;
                    std::vector< DBA_DYNFLD_STP > notionalExtList;
 
                    ret = FIN_GenerateStandInstructOpForNotionalInstr(domainPtr, hierHead, tmpFlowTab[j], standInstructTab[i], 
                        planDefStp, extractFlowPos, extractFlowPosNbr, listPtr, instrPtr, &notionalExtList);
 
                    if (ret == RET_SUCCEED && notionalExtList.empty()==FALSE)
                    {
                        if (insertDataInHierFlg == TRUE)
                        {
                            for (auto tmpextOpStp  : notionalExtList)
                            {
                                if ((ret = FIN_AddEventExtOpInHier(tmpextOpStp, GET_ID(domainPtr, A_Domain_FctDictId), GET_ID(domainPtr, A_Domain_CurrId),
                                    (FUSDATERULE_ENUM)GET_ENUM(domainPtr, A_Domain_FusDateRuleEn), instrPtr, hierHead, tmpFlowTab[j], domainPtr, ptfPtr)) != RET_SUCCEED)
                                {
                                    return(ret);
                                }
                            }
                        }
                        else
                        {
                            for (auto tmpextOpStp : notionalExtList)
                            {
                                /* realloc if needed */
                                if ((extOpNbr + 1) > extOpAllocSz)
                                {
                                    extOpAllocSz += 10;
                                    extOpTab = (DBA_DYNFLD_STP *)mpCaller.realloc(extOpTab, extOpAllocSz * sizeof(DBA_DYNFLD_STP));
                                }

                                SET_INT(tmpextOpStp, ExtOp_StandInstructIdx, i);
                                SET_INT(tmpextOpStp, ExtOp_FlowIdx, j);

                                extOpTab[extOpNbr] = tmpextOpStp;
                                extOpNbr++;
                            }
                        }

                        headCashAvb -= GET_AMOUNT(standInstructTab[i], A_StandInstruct_OpAmt);
                    }
                }
                else
                {
                    FLAG_T allocPtf = FALSE;
                     if (DBA_GetPtfById(GET_ID(standInstructTab[i], A_StandInstruct_PtfId), TRUE, &allocPtf, &ptfPtr,
                        hierHead, UNUSED, UNUSED) != RET_SUCCEED)
                    {
                        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "FIN_GenerateStandInstructOp", "portfolio");
                        return(RET_GEN_ERR_INVARG);
                    }

                    if(allocPtf == TRUE)
                    {
                        mpLocal.ownerDynStp(ptfPtr);
                    }
					/* PMSTA-46255 Lekshmi plan objective currency is different from head portfolio currency */
					if (planDefStp != NULL && GET_EXTENSION_PTR(planDefStp, A_PlanDefinition_PlanObjectiveHisto_Ext) != NULL)
					{
						DBA_DYNFLD_STP objectiveStp = nullptr;
						objectiveStp = GET_EXTENSION_PTR(planDefStp, A_PlanDefinition_PlanObjectiveHisto_Ext)[0];

						if ((ptfPtr != NULL &&
							GET_ID(ptfPtr, A_Ptf_CurrId) != GET_ID(objectiveStp, A_PlanObjectiveHisto_CurrId)))
						{
							AMOUNT_T		totOrderAmt =  GET_AMOUNT(standInstructTab[i], A_StandInstruct_OpAmt);
							totOrderAmt = FIN_GetConvertedCurrencyAmount(domainPtr, hierHead, totOrderAmt,
								GET_ID(objectiveStp, A_PlanObjectiveHisto_CurrId),
								GET_ID(ptfPtr, A_Ptf_CurrId));
							SET_ID(tmpFlowTab[j], Flow_AmtCurrId, GET_ID(ptfPtr, A_Ptf_CurrId));
							SET_PRICE(tmpFlowTab[j], Flow_AmtUnit, totOrderAmt);
						}
					}

                    /*PMSTA-46903 -lalby- 09112021 -Flow_AmtCurrId will copy into ExtOp_OpCurrId and using script
                         to get account_id for the cash account */

                    if (CMP_DYNFLD(tmpFlowTab[j], instrPtr, Flow_AmtCurrId, A_Instr_RefCurrId, IdType) != 0)
                    {
                        //convert orderAmt into instrument currency
                         AMOUNT_T flowAmount = FIN_GetConvertedCurrencyAmount(domainPtr, hierHead, GET_PRICE(tmpFlowTab[j], Flow_AmtUnit),
                            GET_ID(tmpFlowTab[j], Flow_AmtCurrId),
                            GET_ID(instrPtr, A_Instr_RefCurrId));

                        SET_PRICE(tmpFlowTab[j], Flow_AmtUnit, flowAmount);
                        COPY_DYNFLD(tmpFlowTab[j], Flow, Flow_AmtCurrId, instrPtr, A_Instr, A_Instr_RefCurrId);
                    }

					
                    ret = FIN_GenerateStandInstructOp(domainPtr, hierHead, tmpFlowTab[j], standInstructTab[i], planDefStp, extractFlowPos, 
                        extractFlowPosNbr, listPtr, instrPtr, ptfPtr, &extOpStp);

                }

                if (ret == RET_SUCCEED && extOpStp != NULLDYNST && !isNotional)
                {
                    if (insertDataInHierFlg == TRUE)
			        {
                        /* add operations into hierarchy */
                        if ((ret = FIN_AddEventExtOpInHier(extOpStp, GET_ID(domainPtr, A_Domain_FctDictId), GET_ID(domainPtr, A_Domain_CurrId), 
                                                            (FUSDATERULE_ENUM) GET_ENUM(domainPtr, A_Domain_FusDateRuleEn), instrPtr, hierHead, tmpFlowTab[j], domainPtr, ptfPtr)) != RET_SUCCEED)
                        {
                            return(ret);
                        }
                    }
                    else
                    {
                        /* realloc if needed */
                        if ((extOpNbr + 1) > extOpAllocSz)
                        {
                            extOpAllocSz += 10;
                            extOpTab = (DBA_DYNFLD_STP *) mpCaller.realloc(extOpTab, extOpAllocSz * sizeof(DBA_DYNFLD_STP));
                        }

                        SET_INT(extOpStp, ExtOp_StandInstructIdx, i);
                        SET_INT(extOpStp, ExtOp_FlowIdx, j);

                        extOpTab[extOpNbr] = extOpStp;
                        extOpNbr++;
                    }

                    headCashAvb -= GET_AMOUNT(standInstructTab[i], A_StandInstruct_OpAmt);
                }
            }
			tmpFlowNbr = 0;
		}
	}

    if (insertDataInHierFlg == FALSE)
    {
        (*extOpTabPtr) = extOpTab;
        (*extOpNbrPtr) = extOpNbr;
        (*flowTabPtr) = flowTab;
        (*flowNbrPtr) = flowNbr;
        mpCaller.removeAll();
    }

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_UpdCashPlanDateInDb()
**
**  Description :   Generate all cash plan execution dates for given cash plan param
**
**  Arguments   :   hierHead            hierarchy pointer
**                  cashPlanParamPtr    Cash Plan Param to be processed
**
**  Return      :   RET_SUCCEED 	or error code
**
**  Creation    :   PMSTA-42402 Autocash Vishnu 12012021
**
*************************************************************************/
static RET_CODE FIN_UpdCashPlanDateInDb(DBA_HIER_HEAD_STP   hierHead,
                                        DBA_DYNFLD_STP	cashPlanParamPtr)
{
    RET_CODE            ret = RET_SUCCEED;

    DBA_DYNFLD_STP     *dbCashPlanDateTab = nullptr;
    int                 dbCashPlanDateNbr = 0;

    MemoryPool mp;

    DBA_DYNFLD_STP selArgStp = mp.allocDynst(FILEINFO, Sel_Arg);

    SET_ID(selArgStp, Sel_Arg_Id1, GET_ID(cashPlanParamPtr,A_CashPlanExecParam_Id));

    DATE_T currentDate = DATE_CurrentDate();
    
    DbiConnectionHelper connexion(SqlServer);
    
    /*get current cash execution records from db, all future records should be deleted*/
    if((ret = connexion.dbaSelect(CashPlanExecDate, UNUSED, selArgStp, A_CashPlanExecDate, &dbCashPlanDateTab, &dbCashPlanDateNbr)) != RET_SUCCEED)
    {
        return ret;
    }
    
    mp.ownerDynStpTab(dbCashPlanDateTab,dbCashPlanDateNbr);
    
    for (int i = 0; i < dbCashPlanDateNbr; i++)
    {
        /*need to delete only future executions */
        if (currentDate <= GET_DATE(dbCashPlanDateTab[i],A_CashPlanExecDate_ExecutionDate)  )
        {
            DBA_DYNFLD_STP sCashExecDateStp = mp.allocDynst(FILEINFO, S_CashPlanExecDate);
            
            COPY_DYNFLD(sCashExecDateStp, S_CashPlanExecDate, S_CashPlanExecDate_Id,
                            dbCashPlanDateTab[i], A_CashPlanExecDate, A_CashPlanExecDate_Id);
            
            if ((ret = connexion.dbaDelete(CashPlanExecDate, UNUSED, sCashExecDateStp)) != RET_SUCCEED)
            {
                return ret;
            }
        }
    }

    /*insert newly added records*/
    DBA_DYNFLD_STP      *cashPlanExecDateTab = NULLDYNSTPTR;
    int                  cashPlanExecDateNbr = 0;
    
    /*Get newly computed cash exec date records from Hier*/
    if ((ret = DBA_ExtractHierEltRec(hierHead, A_CashPlanExecDate, FALSE, NULL, NULLFCT,
                    &cashPlanExecDateNbr, &cashPlanExecDateTab)) != RET_SUCCEED)
    {
        return(ret);
    }

    mp.owner(cashPlanExecDateTab);

    /*Insert new records in DB*/
    for (int i = 0; i < cashPlanExecDateNbr; i++)
    {
        ret = connexion.dbaInsert(CashPlanExecDate, UNUSED, cashPlanExecDateTab[i]);

        if (ret != RET_SUCCEED)
        {
            return ret;
        }
    }

    return ret;
}


/************************************************************************
**
**  Function    :   FIN_CheckAndUpdCashPlanDetails()
**
**  Description :   Generate all cash plan execution dates
**
**  Arguments   :   domainPtr	   domain pointer
**                  hierHead       hierarchy pointer
**
**  Return      :   RET_SUCCEED 	or error code
**
**  Creation    :   PMSTA-42402 Autocash Vishnu 12012021
**
*************************************************************************/
static RET_CODE FIN_CheckAndUpdCashPlanDetails(DBA_DYNFLD_STP		domainStp,
                                               DBA_HIER_HEAD_STP 	hierHead)
{
    RET_CODE            ret = RET_SUCCEED;
    DBA_DYNFLD_STP      *planDefTab = NULLDYNSTPTR;
    int                 planDefNbr = 0;
    MemoryPool          mp;

    /*get plan definition records from hier */
    if ((ret = DBA_ExtractHierEltRec(hierHead, A_PlanDefinition, FALSE, NULL, NULLFCT,
        &planDefNbr, &planDefTab)) != RET_SUCCEED)
    {
        FREE(planDefTab);
        return(ret);
    }

    mp.ownerPtr(planDefTab);

    DATE_T              currentDate = 0, maxUpdPeriodEndDate = 0;

    currentDate = DATE_CurrentDate();
    maxUpdPeriodEndDate = DATE_Move(currentDate, 1, Year); //max calculate upto 1 year only similar to invest plan

    /*for each plan definition compute details*/
    for (int plan = 0; plan < planDefNbr; plan++)
    {
        /*computation needed only for cash managment plan*/
        if (GET_ENUM(planDefTab[plan], A_PlanDefinition_Nature) != PlanDefNat_CashManagementPlan)
            continue;

        /*get all cash plan for the plan def*/
        DBA_DYNFLD_STP          *cashParamTab = NULLDYNSTPTR;
        int                      cashParamNbr = 0;

        /*get cash execution param for the plan*/
        if (DBA_Select2(CashPlanExecParam, UNUSED,
            A_PlanDefinition, planDefTab[plan], A_CashPlanExecParam, &cashParamTab, UNUSED, UNUSED,
            &cashParamNbr, UNUSED, UNUSED) != RET_SUCCEED)
        {
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "An error occurs while select CashPlanExecParam records");
            return(RET_GEN_INFO_NODATA);
        }

        mp.ownerDynStpTab(cashParamTab,cashParamNbr);

        /*for each plan compute the execution dates*/
        for (int i = 0; i < cashParamNbr; i++)
        {
            FREQUNIT_ENUM		targFreqUnitE;
            double              freq;

            DATETIME_T          beginDate, endDate;
            DATE_UNIT_ENUM		dateFreqUnitE;

            DATE_T maxEndDate = 0;


            if (maxUpdPeriodEndDate > GET_DATETIME(domainStp, A_Domain_InterpTillDate).date)
                maxEndDate = maxUpdPeriodEndDate;
            else
                maxEndDate = GET_DATETIME(domainStp, A_Domain_InterpTillDate).date;

            /*if end date is given then calculate till that date*/
            if (IS_NULLFLD(cashParamTab[i], A_CashPlanExecParam_EndDate) != TRUE )
            {
                maxEndDate = GET_DATETIME(cashParamTab[i], A_CashPlanExecParam_EndDate).date;
            }

            dateFreqUnitE = Month;
            targFreqUnitE = FreqUnit_Month;

            if ((FREQUNIT_ENUM)GET_ENUM(cashParamTab[i], A_CashPlanExecParam_FreqUnitEn) <= FreqUnit_Week)
            {
                dateFreqUnitE = Day;
                targFreqUnitE = FreqUnit_Day;
            }

            FIN_PeriodUnitNbr((FREQUNIT_ENUM)GET_ENUM(cashParamTab[i], A_CashPlanExecParam_FreqUnitEn),
                static_cast<SMALLINT_T>(GET_NUMBER(cashParamTab[i], A_CashPlanExecParam_Freq)),
                targFreqUnitE, &freq);

            if (freq == 0)
            {
                MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
                    "FIN_CheckAndUpdCashPlanDetails", "investment's frequency");
                return(RET_GEN_ERR_INVARG);
            }

            
            if (IS_NULLFLD(cashParamTab[i], A_CashPlanExecParam_FirstExecDate) == TRUE)
            {
                endDate.date = beginDate.date = GET_DATETIME(cashParamTab[i], A_CashPlanExecParam_BeginDate).date;
            }
            else
            {
                /*if first execution date is given then use that instead of start date*/
                endDate.date = beginDate.date = GET_DATETIME(cashParamTab[i], A_CashPlanExecParam_FirstExecDate).date;
            }


            DAY_T               day, d;
            MONTH_T             m;
            YEAR_T              y;

            char                endMFlg = FALSE;

            if (dateFreqUnitE != Day)
            {
                switch (GET_ENUM(cashParamTab[i], A_CashPlanExecParam_EndOfMonthConvEn))
                {
                case InstrEom_Last:
                    endMFlg = (char)TRUE;
                    break;
                case InstrEom_Same:
                    endMFlg = (char)FALSE;
                    break;
                case InstrEom_Last360:
                    if (endMFlg == TRUE)
                        day = 30;
                    endMFlg = (char)FALSE;
                    break;
                default:
                    endMFlg = (char)DATE_IsLastInMonth(endDate.date);
                    break;
                }
            }

            while (endDate.date <= maxEndDate)
            {
                beginDate.date = endDate.date;
                endDate.date = DATE_Move(beginDate.date, (int)freq, dateFreqUnitE);	
                DATE_Get(beginDate.date, (YEAR_T*)NULL, (MONTH_T*)NULL, &day);

                if (currentDate > beginDate.date)
                    continue;

                if (dateFreqUnitE != Day)
                {
                    DATE_VerifyEndMonth(&endDate.date, day, endMFlg);

                    if (GET_ENUM(cashParamTab[i], A_CashPlanExecParam_EndOfMonthConvEn) == InstrEom_Last360 && day == 30)
                    {
                        DATE_Get(endDate.date, &y, &m, &d);
                        if (m == (MONTH_T)2 && d == (DAY_T)29)
                        {
                            endDate.date = DATE_Put(y, m, (DAY_T)28);
                        }
                    }
                }

                DBA_DYNFLD_STP cashPlanExecDatePtr = mp.allocDynst(FILEINFO, A_CashPlanExecDate);
                SET_ID(cashPlanExecDatePtr, A_CashPlanExecDate_CashPlanExecParamId,GET_ID(cashParamTab[i], A_CashPlanExecParam_Id));
                SET_DATE(cashPlanExecDatePtr, A_CashPlanExecDate_ExecutionDate, beginDate.date);
                SET_ENUM(cashPlanExecDatePtr, A_CashPlanExecDate_StatusEn, CashPlanExecDateCompliantEn::NONE);
                SET_ENUM(cashPlanExecDatePtr, A_CashPlanExecDate_CompliantEn, CashPlanExecDateStatusEn::Untreated);

                /*add newly computed record to Hier*/
                if (DBA_AddHierRecord(hierHead, cashPlanExecDatePtr, A_CashPlanExecDate, FALSE, HierAddRec_ForceInsert) != RET_SUCCEED)
                {
                    return(RET_DBA_ERR_HIER);
                }

                mp.removeDynStp(cashPlanExecDatePtr);
            }

            /*update/insert the records in DB*/
            ret = FIN_UpdCashPlanDateInDb(hierHead, cashParamTab[i]);
            
            if (ret != RET_SUCCEED)
                return ret;

        }
    }

    return ret;
}


/************************************************************************
**
**  Function    :   FIN_GenerateStandInstruct()
**
**  Description :   Generate all Flows and operations for standing instructions
**                 
**  Arguments   :   domainPtr	  domain pointer
**                  argHierHead   hierarchy pointer
**
**  Return      :   RET_SUCCEED 	or error code
**
**  Creation    :   PMSTA06761 - DDV - 080731
**
*************************************************************************/
RET_CODE FIN_GenerateStandInstruct(DBA_DYNFLD_STP	 domainPtr,
								   DBA_HIER_HEAD_STP hierHead,
                                   DBA_DYNFLD_STP    *extractFlowPos, 
                                   int               extractFlowPosNbr,
                                   DBA_DYNFLD_STP	 *listPtr)
{
	int             standInstructNbr = 0;
	DBA_DYNFLD_STP  *standInstructTab = NULLDYNSTPTR;
    RET_CODE        ret=RET_SUCCEED;
    FLAG_T          standInstructBuyFlg = FALSE, standInstructSellFlg = FALSE, 
        anyFlg = FALSE, displayFlg, standInstructInvFlg = FALSE, standInstructWithFlg=FALSE;
    ENUMMASK_T          flowSubNatLst;
    MemoryPool mp;

    /* check if standing instruction must be treated or not according to domain parameters */
	GEN_GetApplInfo(ApplStandingInstructionDisplayFlag, &displayFlg);

    flowSubNatLst = GET_MASK64(domainPtr, A_Domain_EvtFlowSubNatLst);
    anyFlg               = (FLAG_T) GET_BIT64(flowSubNatLst, FlowSubNat_Any);
    standInstructBuyFlg  = (FLAG_T) GET_BIT64(flowSubNatLst, FlowSubNat_StandInstructBuy);
    standInstructSellFlg = (FLAG_T)GET_BIT64(flowSubNatLst, FlowSubNat_StandInstructSell);
    standInstructWithFlg = (FLAG_T)GET_BIT64(flowSubNatLst, FlowSubNat_StandInstructionWithdraw);
    standInstructInvFlg = (FLAG_T)GET_BIT64(flowSubNatLst, FlowSubNat_StandInstructionInvest);

    DBA_DYNFLD_STP filterArgs = mp.allocDynst(FILEINFO,StandInstructFilterArg);
    SET_FLAG(filterArgs, StandInstructFilterArg_AllFlag, (anyFlg == FALSE? FALSE : displayFlg));
    SET_FLAG(filterArgs, StandInstructFilterArg_BuyFlag, standInstructBuyFlg );
    SET_FLAG(filterArgs, StandInstructFilterArg_SellFlag, standInstructSellFlg );
    SET_FLAG(filterArgs, StandInstructFilterArg_InvestFlag, standInstructInvFlg); /* change this after conf to 64bit*/
    SET_FLAG(filterArgs, StandInstructFilterArg_WithdrawFlag, standInstructWithFlg);
    SET_DATETIME(filterArgs, StandInstructFilterArg_CalcRefDate, GET_DATETIME(domainPtr, A_Domain_CalcRefDate));
    
    if (anyFlg == FALSE && 
        standInstructBuyFlg == FALSE &&
        standInstructSellFlg == FALSE &&
        standInstructInvFlg == FALSE &&
        standInstructWithFlg == FALSE)
        return(RET_SUCCEED);

    if (anyFlg == TRUE && 
        standInstructBuyFlg == FALSE &&
        standInstructSellFlg == FALSE &&
        standInstructInvFlg == FALSE &&
        standInstructWithFlg == FALSE &&
        displayFlg == FALSE)
        return(RET_SUCCEED);

   
	if ((ret = DBA_ExtractHierEltRecWithFilterSt(hierHead,
                                                 A_StandInstruct,
                                                 FALSE,
                                                 FIN_FilterValidSI,
                                                 filterArgs,
                                                 NULL,
                                                 &standInstructNbr,
                                                 &standInstructTab)) != RET_SUCCEED)
    {
        return(ret);
    }
	if (ret == RET_SUCCEED)
		{
			ret = FIN_GenerateStandInstructFlowsAndOps(domainPtr, 
													hierHead, 
													extractFlowPos,
													extractFlowPosNbr, 
													standInstructTab, 
													standInstructNbr, 
													NULLDYNST,
													listPtr,
                                                    TRUE,
                                                    NULLDYNSTPTR,
                                                    NULL,
                                                    NULLDYNSTPTR,
                                                    NULL);
		}

	if (ret == RET_SUCCEED)
	{
        ret = FIN_ManageAllInvestPlan(domainPtr, hierHead, extractFlowPos, extractFlowPosNbr, listPtr, standInstructBuyFlg, standInstructSellFlg);
    }

	if (ret == RET_SUCCEED)
	{
        ret = FIN_CheckAndUpdCashPlanDetails(domainPtr, hierHead);
    }

    FREE(standInstructTab);
	standInstructNbr = 0;

    /* extract all standing instruction and update last_event_generate_d */
	if ((ret = DBA_ExtractHierEltRec(hierHead,
                                     A_StandInstruct,
                                     FALSE,
                                     NULL,
                                     NULL,
                                     &standInstructNbr,
                                     &standInstructTab)) == RET_SUCCEED)
    {
    	ret = DBA_UpdStandInstructLastEventGenDate(standInstructTab, standInstructNbr);
    }

    FREE(standInstructTab);
    return(ret);
}
/************************************************************************
*
*  Function    : FIN_CmpStandInstructWeight()
*
*  Description :  sort
**
**  Arguments   :   ptr1   pointer on dynamic structure type A_StandInstruct
**                  ptr2   pointer on dynamic structure type A_StandInstruct
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation    :   Sorting orders as per weight - PMSTA - 46225 - Lekshmi
*
*************************************************************************/
STATIC int FIN_CmpStandInstructWeight(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
	
	return(-1 * CMP_DYNFLD((*ptr1), (*ptr2), A_StandInstruct_Weight, A_StandInstruct_Weight, PercentType));
	
}
/************************************************************************
*
*  Function    : FIN_CmpPlanInvestHistoByPlanDefIdBeginDate()
*
*  Description :  sort PlanInvestHistoParam by PlanDefinitionId and BeginDate
**                 
**  Arguments   :   ptr1   pointer on dynamic structure type ExtPos
**                  ptr2   pointer on dynamic structure type ExtPos
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation    :   
*
*************************************************************************/
STATIC int FIN_CmpPlanInvestHistoByPlanDefIdBeginDate(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    int cmp;

	/* Portfolio */
	if ((cmp = CMP_ID(GET_ID((*ptr1), A_PlanInvestParamHisto_PlanDefinitionId),
                      GET_ID((*ptr2), A_PlanInvestParamHisto_PlanDefinitionId))) != 0)
	{
        return(cmp);
    }
    else
    {
		return(DATETIME_CMP(GET_DATETIME((*ptr1), A_PlanInvestParamHisto_BeginDate),
			                GET_DATETIME((*ptr2), A_PlanInvestParamHisto_BeginDate)));
	}
}

/************************************************************************
*
*  Function    : FIN_CmpFreeDepositHistoByPlanDefIdInvestDate()
*
*  Description :  sort FreeDepoHisto by PlanDefinitionId and InvestmentDate
**                 
**  Arguments   :   ptr1   pointer on dynamic structure type ExtPos
**                  ptr2   pointer on dynamic structure type ExtPos
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation    :   
*
*************************************************************************/
STATIC int FIN_CmpFreeDepositHistoByPlanDefIdInvestDate(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    int cmp;

	/* Portfolio */
	if ((cmp = CMP_ID(GET_ID((*ptr1), A_FreeDepositHisto_PlanDefinitionId),
                      GET_ID((*ptr2), A_FreeDepositHisto_PlanDefinitionId))) != 0)
	{
        return(cmp);
    }
    else
    {
		return(DATETIME_CMP(GET_DATETIME((*ptr1), A_FreeDepositHisto_InvestmentDate),
			                GET_DATETIME((*ptr2), A_FreeDepositHisto_InvestmentDate)));
	}
}

/***********************************************************************
**
**  Function    :   FIN_ManageAllInvestPlan ()
**
**  Description :   Generate all Flows and operations for standing instructions
**
**  Arguments   :   domainPtr	  domain pointer
**                  argHierHead   hierarchy pointer
**
**  Return      :   RET_SUCCEED 	or error code
**
**  Creation    :   PMSTA06761 - DDV - 080731
**
*************************************************************************/
STATIC RET_CODE FIN_AddEltInInvestDateArray(DBA_DYNFLD_STP		investDateStp,
                                            DBA_DYNFLD_STP		freeDepoStp,
                                            DBA_DYNFLD_STP		**newInvestDateArray, 
                                            int                 *newInvestNbrPtr, 
                                            int                 *newInvestAllocSzPtr,
                                            FLAG_T              copyFlg,
                                            MemoryPool &        mp)
{
    int                nbr, allocSz;
    DBA_DYNFLD_STP     *dynStArray;

    if (newInvestDateArray == NULLDYNSTPTR ||
        newInvestNbrPtr == NULL ||
        newInvestAllocSzPtr == NULL ||
        (investDateStp == NULLDYNST && freeDepoStp == NULLDYNST))
    {
        return(RET_SUCCEED);
    }

    nbr = (*newInvestNbrPtr);
    allocSz = (*newInvestAllocSzPtr);
    dynStArray = (*newInvestDateArray);

    if (allocSz == 0 || nbr == allocSz)
    {
        allocSz += 20;
        dynStArray = (DBA_DYNFLD_STP *) mp.realloc(dynStArray, allocSz * sizeof (DBA_DYNFLD_STP));
    }

    if (investDateStp != NULLDYNST)
    {
        if (copyFlg == TRUE)
        {
            dynStArray[nbr] = mp.allocDynst(FILEINFO,A_PlanInvestDate);
            COPY_DYNST(dynStArray[nbr], investDateStp, A_PlanInvestDate);
        }
        else
        {
            dynStArray[nbr] = investDateStp;
        }

        nbr++;
    }
    else if (freeDepoStp != NULLDYNST)
    {
        dynStArray[nbr] = mp.allocDynst(FILEINFO,A_PlanInvestDate);
        COPY_DYNFLD(dynStArray[nbr], A_PlanInvestDate, A_PlanInvestDate_InvestmentDate,
                    freeDepoStp, A_FreeDepositHisto, A_FreeDepositHisto_InvestmentDate);
        COPY_DYNFLD(dynStArray[nbr], A_PlanInvestDate, A_PlanInvestDate_Status,
                    freeDepoStp, A_FreeDepositHisto, A_FreeDepositHisto_Status);
        SET_FLAG(dynStArray[nbr], A_PlanInvestDate_ValidFlag, TRUE);
        COPY_DYNFLD(dynStArray[nbr], A_PlanInvestDate, A_PlanInvestDate_FreeDepositHistoId,
                    freeDepoStp, A_FreeDepositHisto, A_FreeDepositHisto_Id);

        nbr++;
    }

    (*newInvestNbrPtr) = nbr;
    (*newInvestAllocSzPtr) = allocSz ;
    (*newInvestDateArray) = dynStArray;

    return(RET_SUCCEED);
}



/***********************************************************************
**
**  Function    :   FIN_ManageAllInvestPlan ()
**
**  Description :   Generate all Flows and operations for standing instructions
**
**  Arguments   :   domainPtr	  domain pointer
**                  argHierHead   hierarchy pointer
**
**  Return      :   RET_SUCCEED 	or error code
**
**  Creation    :   PMSTA06761 - DDV - 080731
**
*************************************************************************/
STATIC RET_CODE FIN_ManageAllInvestPlan(DBA_DYNFLD_STP		domainStp,
                                        DBA_HIER_HEAD_STP 	hierHead,
                                        DBA_DYNFLD_STP    	*extractFlowPos,
                                        int               	extractFlowPosNbr,
                                        DBA_DYNFLD_STP		*listPtr,
                                        FLAG_T          	standInstructBuyFlg,
                                        FLAG_T				standInstructSellFlg)
{
	int				           planInvestParamHistoNbr, i, j, freeDepoIdx=0, planInvestDateNbr, freeDepositHistoNbr, 
                               newInvestDateNbr = 0, newInvestAllocSz=0;
	DBA_DYNFLD_STP             *planInvestParamHistoArray = NULLDYNSTPTR, *planInvestDateArray = NULLDYNSTPTR,
		                       *freeDepositHistoArray = NULLDYNSTPTR, *newInvestDateArray =  NULLDYNSTPTR, planDefStp = NULLDYNST;
	RET_CODE                   ret = RET_SUCCEED;
	ID_T                       planDefId = 0;
	FLAG_T                     execPlanFlg;
	DATE_T                     nextBeginDate;
    FINPLANNING_LICENSEE_ENUM  licenceLevelEn = FinPlanningLicensee_No;
    MemoryPool                 mp;

    /* PMSTA-24771 - DDV - 160916 - Get license level */
    GEN_GetApplInfo(ApplFinPlanningLicence, &licenceLevelEn);

    DBA_SetHierLnkUsed(hierHead, A_PlanDefinition, A_PlanDefinition_PlanObjectiveHisto_Ext);
    DBA_SetHierLnkUsed(hierHead, A_PlanDefinition, A_PlanDefinition_PlanInvestParamHisto_Ext);
    DBA_SetHierLnkUsed(hierHead, A_PlanDefinition, A_PlanDefinition_StandInstruct_Ext);

    DBA_MakeAllRecLinks(hierHead, A_PlanDefinition);

	if ((ret = DBA_ExtractHierEltRec(hierHead, A_PlanInvestParamHisto, FALSE, NULL, FIN_CmpPlanInvestHistoByPlanDefIdBeginDate,
		                             &planInvestParamHistoNbr, &planInvestParamHistoArray)) != RET_SUCCEED)
	{
        FREE(planInvestParamHistoArray);
		return(ret);
	}

    mp.ownerPtr(planInvestParamHistoArray);

	if ((ret = DBA_ExtractHierEltRec(hierHead, A_FreeDepositHisto, FALSE, NULL, FIN_CmpFreeDepositHistoByPlanDefIdInvestDate,
		                             &freeDepositHistoNbr, &freeDepositHistoArray)) != RET_SUCCEED)
	{
        FREE(freeDepositHistoArray);
        return(ret);
    }

    mp.ownerPtr(freeDepositHistoArray);

    if (planInvestParamHistoNbr == 0 && freeDepositHistoNbr == 0)
    {
        return(RET_SUCCEED);
    }
        
    /* PMSTA-24771 - DDV - 160916 - Check license */
    if (licenceLevelEn < FinPlanningLicensee_Level1)
    {
        MSG_SendMesg(RET_ENV_ERR_WRONGLICENSEKEY, 1, FILEINFO, "Financial Planning");
        return(RET_SUCCEED);
    }

    newInvestAllocSz=1;
    newInvestDateArray = (DBA_DYNFLD_STP*)mp.calloc(newInvestAllocSz, sizeof(DBA_DYNFLD_STP));

	FIN_CheckAndUpdPlanInvestDate(domainStp, hierHead, planInvestParamHistoArray, planInvestParamHistoNbr);

	for (i = 0; i < planInvestParamHistoNbr; i++)
	{
		/* PMSTA-30317 - Duplicate orders for ptf list (re-init newInvestDateNbr) */
		newInvestDateNbr = 0;

		if (i < (planInvestParamHistoNbr-1) &&
            CMP_DYNFLD(planInvestParamHistoArray[i + 1], planInvestParamHistoArray[i], A_PlanInvestParamHisto_PlanDefinitionId, A_PlanInvestParamHisto_PlanDefinitionId, IdType) == 0)
		{
    		nextBeginDate = GET_DATETIME(planInvestParamHistoArray[i + 1], A_PlanInvestParamHisto_BeginDate).date;
            execPlanFlg = FALSE;
		}
		else
		{
			nextBeginDate = MAGIC_END_DATE;
            execPlanFlg = TRUE;
		}

        /* treat freeDepo on plan without loaded Invest Param */
        while(freeDepoIdx < freeDepositHistoNbr && 
              CMP_DYNFLD(freeDepositHistoArray[freeDepoIdx], planInvestParamHistoArray[i], 
                         A_FreeDepositHisto_PlanDefinitionId,A_PlanInvestParamHisto_PlanDefinitionId, IdType) < 0)
        {
            do
            {          
                /* Add freeDepo in new invest date array */
                FIN_AddEltInInvestDateArray(NULLDYNST, freeDepositHistoArray[freeDepoIdx], &newInvestDateArray, &newInvestDateNbr, &newInvestAllocSz, TRUE,mp);
                planDefId = GET_ID(freeDepositHistoArray[freeDepoIdx], A_FreeDepositHisto_PlanDefinitionId);
                freeDepoIdx++;

            } while(freeDepoIdx < freeDepositHistoNbr && 
                    CMP_DYNFLD(freeDepositHistoArray[freeDepoIdx-1], freeDepositHistoArray[freeDepoIdx], 
                               A_FreeDepositHisto_PlanDefinitionId, A_FreeDepositHisto_PlanDefinitionId, IdType) == 0);

            /* treat current plan */
            if (DBA_GetRecPtrFromHierById(hierHead, planDefId, A_PlanDefinition, &planDefStp) == RET_SUCCEED)
                FIN_ManageOneInvestPlan(domainStp, hierHead, extractFlowPos, extractFlowPosNbr, listPtr, standInstructBuyFlg, standInstructSellFlg, planDefStp, newInvestDateArray, newInvestDateNbr);
        }

        planInvestDateArray = NULL;
        planInvestDateNbr = 0;

		if (GET_EXTENSION_PTR(planInvestParamHistoArray[i], A_PlanInvestParamHisto_PlanInvestDate_Ext) != NULL)
		{
			planInvestDateArray = GET_EXTENSION_PTR(planInvestParamHistoArray[i], A_PlanInvestParamHisto_PlanInvestDate_Ext);
			planInvestDateNbr = GET_EXTENSION_NBR(planInvestParamHistoArray[i], A_PlanInvestParamHisto_PlanInvestDate_Ext);
        }

		for (j = 0; j < planInvestDateNbr; j++)
		{
			if (IS_NULLFLD(planInvestDateArray[j], A_PlanInvestDate_InvestmentDate) == TRUE)
                continue;

            /* insert freeDepo */
            while(freeDepoIdx < freeDepositHistoNbr && 
                  CMP_DYNFLD(freeDepositHistoArray[freeDepoIdx], planInvestParamHistoArray[i], 
                               A_FreeDepositHisto_PlanDefinitionId, A_PlanInvestParamHisto_PlanDefinitionId, IdType) == 0 &&
                  CMP_DYNFLD(freeDepositHistoArray[freeDepoIdx], planInvestDateArray[j], 
                             A_FreeDepositHisto_InvestmentDate, A_PlanInvestDate_InvestmentDate, DatetimeType) <= 0 &&
                             GET_DATETIME(freeDepositHistoArray[freeDepoIdx], A_FreeDepositHisto_InvestmentDate).date < nextBeginDate)
            {
                /* Add freeDepo in new invest date array */
                FIN_AddEltInInvestDateArray(NULLDYNST, freeDepositHistoArray[freeDepoIdx], &newInvestDateArray, &newInvestDateNbr, &newInvestAllocSz, TRUE,mp);
                planDefId = GET_ID(freeDepositHistoArray[freeDepoIdx], A_FreeDepositHisto_PlanDefinitionId);
                freeDepoIdx++;
            }

			if (GET_DATETIME(planInvestDateArray[j], A_PlanInvestDate_InvestmentDate).date < nextBeginDate)
			{
				SET_FLAG(planInvestDateArray[j], A_PlanInvestDate_ValidFlag, TRUE);
			}
			else
            {
				SET_FLAG(planInvestDateArray[j], A_PlanInvestDate_ValidFlag, FALSE);
			}

            /* Add investDateo in new invest date array */
            FIN_AddEltInInvestDateArray(planInvestDateArray[j], NULLDYNST, &newInvestDateArray, &newInvestDateNbr, &newInvestAllocSz, TRUE, mp);
            planDefId = GET_ID(planInvestParamHistoArray[i], A_PlanInvestParamHisto_PlanDefinitionId);

		}

        while(freeDepoIdx < freeDepositHistoNbr && 
              (freeDepoIdx == 0  || CMP_DYNFLD(freeDepositHistoArray[freeDepoIdx-1], freeDepositHistoArray[freeDepoIdx], 
                         A_FreeDepositHisto_PlanDefinitionId, A_PlanInvestParamHisto_PlanDefinitionId, IdType) == 0) &&
              GET_DATETIME(freeDepositHistoArray[freeDepoIdx], A_FreeDepositHisto_InvestmentDate).date < nextBeginDate)
        {
            /* Add freeDepo in new invest date array */
            FIN_AddEltInInvestDateArray(NULLDYNST, freeDepositHistoArray[freeDepoIdx], &newInvestDateArray, &newInvestDateNbr, &newInvestAllocSz, TRUE, mp);
            planDefId = GET_ID(freeDepositHistoArray[freeDepoIdx], A_FreeDepositHisto_PlanDefinitionId);
            freeDepoIdx++;
        }

        if (execPlanFlg == TRUE)
        {
            /* Treat current plan */
            if (DBA_GetRecPtrFromHierById(hierHead, planDefId, A_PlanDefinition, &planDefStp) == RET_SUCCEED)
                FIN_ManageOneInvestPlan(domainStp, hierHead, extractFlowPos, extractFlowPosNbr, listPtr, standInstructBuyFlg, standInstructSellFlg, planDefStp, newInvestDateArray, newInvestDateNbr);
        }
    }

    return(RET_SUCCEED);
}


/************************************************************************
*
*  Function    : FIN_FilterSellStandInstruct()
*
*  Description : return only valid sell standing intruction
*
*  Arguments   : dynSt     : pointer on a dynamic structure
*                dynStTp   : dynamic structure type
*
*  Return      : TRUE or FALSE
*
*  Creation    : PMSTA06761 - DDV - 080804
*
*  Last modif. :
*
*************************************************************************/
STATIC int FIN_FilterValidSI(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP filterArgs)
{
    STANDINSTRUCTSTATUS_ENUM status;

    GEN_GetApplInfo(ApplStandingInstructionExecStatEn, &status);

    /* common condition for all sis*/
    if (GET_ENUM(dynSt, A_StandInstruct_StatusEn) < status ||
        (IS_NULLFLD(dynSt, A_StandInstruct_EndDate) == FALSE &&
            DATETIME_CMP(GET_DATETIME(dynSt, A_StandInstruct_EndDate), GET_DATETIME(filterArgs, StandInstructFilterArg_CalcRefDate)) < 0))
    {
        return(FALSE);
    }

    if (GET_FLAG(filterArgs, StandInstructFilterArg_AllFlag) == TRUE 
        && IS_NULLFLD(dynSt, A_StandInstruct_PlanDefinitionId) == TRUE)
    {
        return(TRUE);
    }
    else if (GET_FLAG(filterArgs, StandInstructFilterArg_SellFlag) == TRUE  
        && (GET_ENUM(dynSt, A_StandInstruct_OpNatEn) == OpNat_Sell)
        && IS_NULLFLD(dynSt, A_StandInstruct_PlanDefinitionId) == TRUE)
    {
        return(TRUE);
    }
    else if (GET_FLAG(filterArgs, StandInstructFilterArg_BuyFlag) == TRUE
        && (GET_ENUM(dynSt, A_StandInstruct_OpNatEn) == OpNat_Buy)
        && IS_NULLFLD(dynSt, A_StandInstruct_PlanDefinitionId) == TRUE)
    {
        return (TRUE);
    }
    else if (GET_FLAG(filterArgs, StandInstructFilterArg_InvestFlag) == TRUE
        && (static_cast<StandInstructOpNatEn>(GET_ENUM(dynSt, A_StandInstruct_OpNatEn)) == StandInstructOpNatEn::Invest)
        && IS_NULLFLD(dynSt, A_StandInstruct_PlanDefinitionId) == TRUE)
    {
        return (TRUE);
    }
    else if (GET_FLAG(filterArgs, StandInstructFilterArg_WithdrawFlag) == TRUE
        && (static_cast<StandInstructOpNatEn>(GET_ENUM(dynSt, A_StandInstruct_OpNatEn)) == StandInstructOpNatEn::Withdrawal)
        && IS_NULLFLD(dynSt, A_StandInstruct_PlanDefinitionId) == TRUE)
    {
        return (TRUE);
    }
    else
    {
        return(FALSE);
    }
}

/************************************************************************
**
**  Function    :   FIN_EditDomainPtfCompo()
**
**  Description :   Retrieve all portfolies belonging to a client.
**
**  Arguments   :   domainPtr	  domain pointer
**                  domPtfCompoHierHead   hierarchy pointer
**
**  Return      :   RET_SUCCEED 	or error code
**
**  Creation    :   PMSTA-21256 - chandrak - 151006
**					OCS-47441 - sshreyos - 160502
**					PMSTA-24250 - sshreyos - 160829
**
*************************************************************************/
RET_CODE FIN_EditDomainPtfCompo(DBA_DYNFLD_STP		domainPtr,
								DBA_HIER_HEAD_STP	domPtfCompoHierHead)
{
    OBJECT_ENUM     ptfDim = NullEntity;
    int             i = 0, j = 0, ptfThirdCompoNbr = 0, domainPtfCompoNbr = 0, ptfNbr = 0, ptfThirdCompoAllocSize = 0;
    DBA_DYNFLD_STP *ptfThirdCompoTab = NULLDYNSTPTR, *eltDomainPtfCompoTab = NULLDYNSTPTR, *ptfList=NULLDYNSTPTR;
    DBA_DYNFLD_STP  ptfListPtr=NULLDYNST;
    DBA_DYNFLD_STP  admArg = NULLDYNST;
    RET_CODE        ret = RET_SUCCEED;
    FLAG_T         *scptFlagTab = NULL;

    DBA_GetObjectEnum(GET_DICT(domainPtr, A_Domain_DimPtfDictId), &ptfDim);
    
    if (ptfDim == Third || ptfDim == Ptf || ptfDim == DomainPtfCompo)
    {
        /* Select directly linked portfolios */
        DBA_SelPtfByDomain(domainPtr, &ptfList, &ptfNbr, domPtfCompoHierHead); /* sets hier_port_id */

        /* does not set hier_port_id
        ret = DBA_Select2(Ptf, DBA_ROLE_LOAD_STRAT_LNK,
        A_Domain, domainPtr, A_Ptf, &ptfList,
        UNUSED, UNUSED, &ptfNbr, UNUSED, UNUSED);
        */

        if (ptfNbr > 0)
        {
            FLAG_T foundDuplicateFlg = FALSE; /* OCS-47334 - CHU - 151126 */

            if (DBA_AddHierRecordList(domPtfCompoHierHead, ptfList, ptfNbr, A_Ptf, FALSE) != RET_SUCCEED)
            {
                MSG_SendMesg(RET_DBA_ERR_HIER, 0, FILEINFO);
                DBA_FreeDynStTab(ptfList, ptfNbr, A_Ptf);
                return(RET_DBA_ERR_HIER);
            }

            ptfThirdCompoAllocSize = ptfNbr;
            if ((eltDomainPtfCompoTab = (DBA_DYNFLD_STP *)CALLOC(ptfThirdCompoAllocSize, sizeof(DBA_DYNFLD_STP))) == NULL)
            {
                MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
                FREE(ptfList);
                return(RET_MEM_ERR_ALLOC);
            }

            for (i = 0; i < ptfNbr; i++)
            {
                if (DBA_CheckPtfDim(domainPtr, domPtfCompoHierHead,
                                    GET_ID(ptfList[i], A_Ptf_Id), ptfList[i],
                                    &ptfListPtr, FALSE,
                                    (DATETIME_STP)NULL, ptfList, ptfNbr) == TRUE)
                {

                    /* < OCS-47334 - CHU - 151126 */
                    foundDuplicateFlg = FALSE;
                    for (j = 0; j < domainPtfCompoNbr; j++)
                    {
                        if (CMP_ID(GET_ID(ptfList[i], A_Ptf_Id),
                            GET_ID(eltDomainPtfCompoTab[j], A_DomainPtfCompo_PtfId)) == 0)
                        {
                            foundDuplicateFlg = TRUE;
                            break;
                        }
                    }
                    /* > OCS-47334 - CHU - 151126 */
                    if (foundDuplicateFlg == FALSE)
                    {
                        if ((eltDomainPtfCompoTab[domainPtfCompoNbr] = ALLOC_DYNST(A_DomainPtfCompo)) == NULLDYNST) /* OCS-47544 - CHU - 151215 */
                        {
                            MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
                            FREE(ptfList);
                            DBA_FreeDynStTab(eltDomainPtfCompoTab, domainPtfCompoNbr, A_DomainPtfCompo);
                            return(RET_MEM_ERR_ALLOC);
                        }

                        COPY_DYNFLD(eltDomainPtfCompoTab[domainPtfCompoNbr], A_DomainPtfCompo, A_DomainPtfCompo_PtfId, /* OCS-47544 - CHU - 151215 */
                                    ptfList[i], A_Ptf, A_Ptf_Id);

                        COPY_DYNFLD(eltDomainPtfCompoTab[domainPtfCompoNbr], A_DomainPtfCompo, A_DomainPtfCompo_ThirdId, /* OCS-47544 - CHU - 151215 */
                                    ptfList[i], A_Ptf, A_Ptf_ThirdId);
                        SET_ID(eltDomainPtfCompoTab[domainPtfCompoNbr], A_DomainPtfCompo_FunctionResultId, GET_ID(domainPtr, A_Domain_FctResultId));
                        domainPtfCompoNbr++;
                    }
                }
            }
        }
    }

    if (ptfDim == Third || ptfDim == Ptf)
    {
        /* Select portfolios from Third Compo */
        if ((admArg = ALLOC_DYNST(Adm_Arg)) == NULLDYNST)
        {
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
            FREE(ptfList);
            DBA_FreeDynStTab(eltDomainPtfCompoTab, domainPtfCompoNbr, A_DomainPtfCompo);
            return(RET_MEM_ERR_ALLOC);
        }

        /* PMSTA - 24250 - sshreyos - 160829 *//* Code changes for displaying direct and indirect owners in identification screen */
        if ((DOMSESSIONNAT_ENUM)GET_ENUM(domainPtr, A_Domain_SessionNatureEn) == DomSessionNat_None && ptfDim == Ptf)
        {
            for (int k = 0; k < ptfNbr; k++)
            {
                SET_ID(admArg, Adm_Arg_Id, GET_ID(ptfList[k], A_Ptf_Id));

                if (DBA_Select2(PtfThirdCompo, UNUSED,
                                Adm_Arg, admArg, S_PtfThirdCompo, &ptfThirdCompoTab, UNUSED, UNUSED,
                                &ptfThirdCompoNbr, UNUSED, UNUSED) != RET_SUCCEED)
                {
                    MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "An error occurs while select PtfThirdCompo records");
                    FREE_DYNST(admArg, Adm_Arg);
                    DBA_FreeDynStTab(ptfThirdCompoTab, ptfThirdCompoNbr, S_PtfThirdCompo);
                    FREE(ptfList);
                    DBA_FreeDynStTab(eltDomainPtfCompoTab, domainPtfCompoNbr, A_DomainPtfCompo);
                    return(FALSE);
                }

                if ((domainPtfCompoNbr + ptfThirdCompoNbr + 1) >= ptfThirdCompoAllocSize)
                {
                    DBA_DYNFLD_STP *oldTab = eltDomainPtfCompoTab;

                    ptfThirdCompoAllocSize = domainPtfCompoNbr + ptfThirdCompoNbr + 10;
                    if ((eltDomainPtfCompoTab = (DBA_DYNFLD_STP *)REALLOC(eltDomainPtfCompoTab, ptfThirdCompoAllocSize * sizeof(DBA_DYNFLD_STP))) == NULL)
                    {
                        MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
                        FREE_DYNST(admArg, Adm_Arg);
                        DBA_FreeDynStTab(ptfThirdCompoTab, ptfThirdCompoNbr, S_PtfThirdCompo);
                        FREE(ptfList);
                        DBA_FreeDynStTab(oldTab, domainPtfCompoNbr, A_DomainPtfCompo);
                        return(RET_MEM_ERR_ALLOC);
                    }
                }

                for (i = 0; i < ptfThirdCompoNbr; i++)
                {
                    /* PMSTA-44861 - JOS - 18042021 - code to eliminate duplicate entries inserted into domain_portfolio_compo table */
                    FLAG_T    foundInThird = FALSE;
                    if (IS_NULLFLD(domainPtr, A_Domain_FctResultCd) == FALSE)
                    {
                        for (j = 0; j < domainPtfCompoNbr; j++)
                        {
                            if (CMP_ID(GET_ID(ptfThirdCompoTab[i], S_PtfThirdCompo_PtfId),
                                GET_ID(eltDomainPtfCompoTab[j], A_DomainPtfCompo_PtfId)) == 0)
                            {
                                if (IS_NULLFLD(eltDomainPtfCompoTab[j], A_DomainPtfCompo_ThirdId) == TRUE)
                                {
                                    COPY_DYNFLD(eltDomainPtfCompoTab[j], A_DomainPtfCompo, A_DomainPtfCompo_ThirdId,
                                        ptfThirdCompoTab[i], S_PtfThirdCompo, S_PtfThirdCompo_ThirdId);
                                }

                                COPY_DYNFLD(eltDomainPtfCompoTab[j], A_DomainPtfCompo, A_DomainPtfCompo_PtfThirdCompoId,
                                    ptfThirdCompoTab[i], S_PtfThirdCompo, S_PtfThirdCompo_Id);
                                foundInThird = TRUE;
                                break;
                            }
                        }
                    }
                    

                    if (foundInThird == FALSE) 
                    {
                        if ((eltDomainPtfCompoTab[domainPtfCompoNbr] = ALLOC_DYNST(A_DomainPtfCompo)) == NULLDYNST)
                        {
                            MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
                            FREE_DYNST(admArg, Adm_Arg);
                            FREE(ptfList);
                            DBA_FreeDynStTab(eltDomainPtfCompoTab, domainPtfCompoNbr, A_DomainPtfCompo);
                            DBA_FreeDynStTab(ptfThirdCompoTab, ptfThirdCompoNbr, S_PtfThirdCompo);
                            return(RET_MEM_ERR_ALLOC);
                        }
                        COPY_DYNFLD(eltDomainPtfCompoTab[domainPtfCompoNbr], A_DomainPtfCompo, A_DomainPtfCompo_PtfId,
                            ptfThirdCompoTab[i], S_PtfThirdCompo, S_PtfThirdCompo_PtfId);

                        COPY_DYNFLD(eltDomainPtfCompoTab[domainPtfCompoNbr], A_DomainPtfCompo, A_DomainPtfCompo_ThirdId,
                            ptfThirdCompoTab[i], S_PtfThirdCompo, S_PtfThirdCompo_ThirdId);

                        COPY_DYNFLD(eltDomainPtfCompoTab[domainPtfCompoNbr], A_DomainPtfCompo, A_DomainPtfCompo_PtfThirdCompoId,
                            ptfThirdCompoTab[i], S_PtfThirdCompo, S_PtfThirdCompo_Id);

                        domainPtfCompoNbr++;

                    }

                }
                DBA_FreeDynStTab(ptfThirdCompoTab, ptfThirdCompoNbr, S_PtfThirdCompo);
            }
        }
        else
        {
            SET_ID(admArg, Adm_Arg_Id, GET_ID(domainPtr, A_Domain_PtfObjId));
            if (DBA_Select2(PtfThirdCompo, DBA_ROLE_SEL_PTFTHIRDCOMPO_BY_THIRD,
                            Adm_Arg, admArg, S_PtfThirdCompo, &ptfThirdCompoTab, UNUSED, UNUSED,
                            &ptfThirdCompoNbr, UNUSED, UNUSED) != RET_SUCCEED)
            {
                MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "An error occurs while select PtfThirdCompo records");
                FREE_DYNST(admArg, Adm_Arg);
                DBA_FreeDynStTab(ptfThirdCompoTab, ptfThirdCompoNbr, S_PtfThirdCompo);
                FREE(ptfList);
                DBA_FreeDynStTab(eltDomainPtfCompoTab, domainPtfCompoNbr, A_DomainPtfCompo);
                return(FALSE);
            }

            FREE_DYNST(admArg, Adm_Arg);

            if (ptfThirdCompoNbr > 0)
            {
                if ((domainPtfCompoNbr + ptfThirdCompoNbr + 1) >= ptfThirdCompoAllocSize)
                {
                    DBA_DYNFLD_STP *oldTab = eltDomainPtfCompoTab;

                    ptfThirdCompoAllocSize = domainPtfCompoNbr + ptfThirdCompoNbr + 10;
                    if ((eltDomainPtfCompoTab = (DBA_DYNFLD_STP *)REALLOC(eltDomainPtfCompoTab, ptfThirdCompoAllocSize * sizeof(DBA_DYNFLD_STP))) == NULL)
                    {
                        MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
                        FREE_DYNST(admArg, Adm_Arg);
                        DBA_FreeDynStTab(ptfThirdCompoTab, ptfThirdCompoNbr, S_PtfThirdCompo);
                        FREE(ptfList);
                        DBA_FreeDynStTab(oldTab, domainPtfCompoNbr, A_DomainPtfCompo);
                        return(RET_MEM_ERR_ALLOC);
                    }
                }

                for (i = 0; i < ptfThirdCompoNbr; i++)
                {
                    FLAG_T    foundInThird = FALSE;
                    if (DBA_CheckPtfDim(domainPtr, domPtfCompoHierHead,
                                        GET_ID(ptfThirdCompoTab[i], S_PtfThirdCompo_PtfId), NULL,
                                        &ptfListPtr, FALSE,
                                        (DATETIME_STP)NULL, ptfList, ptfNbr) == TRUE)
                    {
                        /* Check if portfolio already selected by sel_all_portfolio_by_tid above *
                           If so update existing record with its ThirdCompoId */
                        for (j = 0; j < domainPtfCompoNbr; j++)
                        {
                            if (CMP_ID(GET_ID(ptfThirdCompoTab[i], S_PtfThirdCompo_PtfId),
                                       GET_ID(eltDomainPtfCompoTab[j], A_DomainPtfCompo_PtfId)) == 0)
                            {
                                if (IS_NULLFLD(eltDomainPtfCompoTab[j], A_DomainPtfCompo_ThirdId) == TRUE)
                                {
                                    COPY_DYNFLD(eltDomainPtfCompoTab[j], A_DomainPtfCompo, A_DomainPtfCompo_ThirdId,
                                                ptfThirdCompoTab[i], S_PtfThirdCompo, S_PtfThirdCompo_ThirdId);
                                }

                                COPY_DYNFLD(eltDomainPtfCompoTab[j], A_DomainPtfCompo, A_DomainPtfCompo_PtfThirdCompoId,
                                            ptfThirdCompoTab[i], S_PtfThirdCompo, S_PtfThirdCompo_Id);
                                foundInThird = TRUE;
                                break;
                            }
                        }

                        if (foundInThird == FALSE)
                        {
                            DBA_DYNFLD_STP    ptfPtr = NULL;
                            FLAG_T            ptfAllocFlg = FALSE;

                            if ((eltDomainPtfCompoTab[domainPtfCompoNbr] = ALLOC_DYNST(A_DomainPtfCompo)) == NULLDYNST)
                            {
                                MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
                                FREE_DYNST(admArg, Adm_Arg);
                                DBA_FreeDynStTab(ptfThirdCompoTab, ptfThirdCompoNbr, S_PtfThirdCompo);
                                FREE(ptfList);
                                DBA_FreeDynStTab(eltDomainPtfCompoTab, domainPtfCompoNbr, A_DomainPtfCompo);
                                return(RET_MEM_ERR_ALLOC);
                            }

                            COPY_DYNFLD(eltDomainPtfCompoTab[domainPtfCompoNbr], A_DomainPtfCompo, A_DomainPtfCompo_PtfId,
                                ptfThirdCompoTab[i], S_PtfThirdCompo, S_PtfThirdCompo_PtfId);

                            COPY_DYNFLD(eltDomainPtfCompoTab[domainPtfCompoNbr], A_DomainPtfCompo, A_DomainPtfCompo_ThirdId,
                                ptfThirdCompoTab[i], S_PtfThirdCompo, S_PtfThirdCompo_ThirdId);

                            COPY_DYNFLD(eltDomainPtfCompoTab[domainPtfCompoNbr], A_DomainPtfCompo, A_DomainPtfCompo_PtfThirdCompoId,
                                ptfThirdCompoTab[i], S_PtfThirdCompo, S_PtfThirdCompo_Id);

                            if ((ret = DBA_GetPtfById(GET_ID(ptfThirdCompoTab[i], S_PtfThirdCompo_PtfId), TRUE, &ptfAllocFlg,
                                                      &ptfPtr, (PTR)domPtfCompoHierHead, UNUSED, UNUSED)) != RET_SUCCEED)
                            {
                                MSG_SendMesg(RET_DBA_ERR_HIER, 0, FILEINFO);
                                FREE_DYNST(admArg, Adm_Arg);
                                DBA_FreeDynStTab(ptfThirdCompoTab, ptfThirdCompoNbr, S_PtfThirdCompo);
                                FREE(ptfList);
                                DBA_FreeDynStTab(eltDomainPtfCompoTab, domainPtfCompoNbr, A_DomainPtfCompo);
                                return(RET_DBA_ERR_HIER);
                            }

                            if(ptfAllocFlg == TRUE) FREE_DYNST(ptfPtr,A_Ptf);

                            domainPtfCompoNbr++;
                        }
                    }
                }
                DBA_FreeDynStTab(ptfThirdCompoTab, ptfThirdCompoNbr, S_PtfThirdCompo);
            }
        }
        FREE_DYNST(admArg, Adm_Arg);
    }

    if (domainPtfCompoNbr > 0)
    {
        /* Load and initialise flag array for script */
        if ((scptFlagTab = (FLAG_T *)CALLOC(GET_FLD_NBR(A_DomainPtfCompo), sizeof(FLAG_T))) == NULL)
        {
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
            DBA_FreeDynStTab(eltDomainPtfCompoTab, domainPtfCompoNbr, A_DomainPtfCompo);
            return(RET_MEM_ERR_ALLOC);
        }

        /* Force all flags to FALSE (=re-evalute all fields) */
        memset(scptFlagTab, FALSE, GET_FLD_NBR(A_DomainPtfCompo)*sizeof(FLAG_T));

        for (i = 0; i < domainPtfCompoNbr; i++)
        {
            scptFlagTab[A_DomainPtfCompo_PtfId] = TRUE;
            scptFlagTab[A_DomainPtfCompo_ThirdId] = TRUE;
            scptFlagTab[A_DomainPtfCompo_PtfThirdCompoId] = TRUE;

            if (SCPT_ComputeDV(DomainPtfCompo, scptFlagTab, eltDomainPtfCompoTab[i], FALSE, TRUE, NULL) != 0)
            {
                MSG_SendMesg(RET_SCPT_ERR_SYNTAX, 0, FILEINFO);
                FREE(scptFlagTab);
                FREE(ptfList);
                DBA_FreeDynStTab(eltDomainPtfCompoTab, domainPtfCompoNbr, A_DomainPtfCompo);
                return(RET_SCPT_ERR_SYNTAX);
            }
        }
        FREE(scptFlagTab);

        if (DBA_AddHierRecordList(domPtfCompoHierHead, eltDomainPtfCompoTab, domainPtfCompoNbr, A_DomainPtfCompo, FALSE) != RET_SUCCEED)
        {
            MSG_SendMesg(RET_DBA_ERR_HIER, 0, FILEINFO);
            FREE(ptfList);
            return(RET_DBA_ERR_HIER);
        }
    }

    FREE(eltDomainPtfCompoTab);
    FREE(ptfList);
    return (ret);
}

/************************************************************************
*
*  Function    : FIN_UpdTreatedResult()
*
*  Description : According to operation/position existence, 
*				 change a Treated in Success or Failed 
*				 change a RetryTreated in RetrySuccess or RetryFailed
*  Arguments   : 
*
*  Return      : 
*
*  Creation    : PMSTA28294 - RAK - 171123
*
*************************************************************************/
STATIC RET_CODE FIN_UpdTreatedResult(DBA_HIER_HEAD_STP hierHead, DBA_DYNFLD_STP domainStp, DBA_DYNFLD_STP stdInstructStp, DBA_DYNFLD_STP dbInvestDate, bool *successFlg)
{
	RET_CODE ret = RET_SUCCEED;
	FLAG_T eventPosFlg = FALSE;
	MemoryPool mp;

	/* verify if an operation/position with same received ptf, instr, event_code, event_number,
	 * a minimum status > domain minimum status already exists */
	if (GET_ENUM(dbInvestDate, A_PlanInvestDate_Status) == PlanInvestDateStatus_Treated ||
		GET_ENUM(dbInvestDate, A_PlanInvestDate_Status) == PlanInvestDateStatus_RetryTreated)
	{
		DBA_DYNFLD_STP           instrRec = NULLDYNSTPTR;
		FLAG_T                   allocInstrFlg = FALSE;

		if (DBA_GetInstrById(GET_ID(stdInstructStp, A_StandInstruct_InstrId), TRUE, &allocInstrFlg, &instrRec, hierHead, UNUSED, UNUSED) != RET_SUCCEED)
		{
			MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "FIN_UpdTreatedResult", "instrument read failed");
			return(RET_GEN_ERR_INVARG);
		}

		/* for notional instruments */
		if (GET_ENUM(instrRec, A_Instr_NatEn) == InstrNat_NotionalInstr && GET_ENUM(instrRec, A_Instr_SubNatEn) == SubNat_ModelPortfolio)
		{
			DBA_SetHierLnkUsed(hierHead, A_Strat, A_Strat_A_StratHist_Ext);
			DBA_MakeSpecRecLinks(hierHead, A_Strat, A_Strat_A_StratHist_Ext);

			DBA_SetHierLnkUsed(hierHead, A_StratHist, A_StratHist_A_StratElt_Ext);
			DBA_MakeSpecRecLinks(hierHead, A_StratHist, A_StratHist_A_StratElt_Ext);


			DBA_DYNFLD_STP NIStratPtr = nullptr;
			if ((DBA_GetRecPtrFromHierById(hierHead, (GET_ID(instrRec, A_Instr_ModelPtfId)), A_Strat, &NIStratPtr) == RET_SUCCEED)
				&& NIStratPtr != nullptr)
			{
				/*get strat elemts for the strategy*/
				DBA_DYNFLD_STP  stratHistPtr = NULLDYNSTPTR;

				if (IS_NULLFLD(NIStratPtr, A_Strat_A_StratHist_Ext) != TRUE &&
					(stratHistPtr = *(GET_EXTENSION_PTR(NIStratPtr, A_Strat_A_StratHist_Ext))) != NULLDYNST)
				{
					DBA_DYNFLD_STP *stratEltTab = GET_EXTENSION_PTR(stratHistPtr, A_StratHist_A_StratElt_Ext);
					int            stratEltNbr = GET_EXTENSION_NBR(stratHistPtr, A_StratHist_A_StratElt_Ext);
					std::vector<ID_T> instrList;
					if (stratEltNbr > 0)
					{
						DBA_DYNFLD_STP           instrPtr = NULLDYNSTPTR;
						FLAG_T                   allocFlg = FALSE;
						for (int idx = 0; idx < stratEltNbr; ++idx)
						{
							if (GET_ENUM(stratEltTab[idx], A_StratElt_NatEn) == StratEltNat_ModelPtf)
							{
								if (DBA_GetInstrById(GET_ID(stratEltTab[idx], A_StratElt_InstrId), TRUE, &allocFlg, &instrPtr, hierHead, UNUSED, UNUSED) != RET_SUCCEED)
								{
									MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "FIN_UpdTreatedResult", "instrument");
									return(RET_GEN_ERR_INVARG);
								}
								if (instrPtr != NULLDYNSTPTR && (GET_ENUM(instrPtr, A_Instr_NatEn) != InstrNat_CashAcct))
								{
									instrList.push_back(GET_ID(stratEltTab[idx], A_StratElt_InstrId));
								}
							}
						}
					}

					// now get the strat links for portfolio
					DBA_DYNFLD_STP dummyEsl = mp.allocDynst(FILEINFO, ExtStratLnk);
					COPY_DYNFLD(dummyEsl, ExtStratLnk, ExtStratLnk_StratId, stratHistPtr, A_StratHist, A_StratHist_StratId);
					SET_ID(dummyEsl, ExtStratLnk_PtfId, GET_ID(stdInstructStp, A_StandInstruct_PtfId));

					DBA_DYNFLD_STP * stratLnkTab = NULLDYNSTPTR;
					int              stratLnkNbr = 0;

					/*Get the non managed portfolio linked to the strategy with same head portfolio  from strategy_link
						this should be loaded in hier by sel_exd_strategy_by_domain*/
					if ((ret = DBA_HierEltRecExtract(hierHead, S_StratLnk, FALSE, FIN_FilterStratLnkWithStratId,
						dummyEsl, NULLFCT, FALSE, FALSE, &stratLnkNbr, &stratLnkTab)) != RET_SUCCEED || 0 == stratLnkNbr)
					{
						MSG_SendMesg(FILEINFO, "FIN_UpdTreatedResult: no portfolio link fetched for SI");
						return ret;
					}

					mp.owner(stratLnkTab);

					eventPosFlg = TRUE;

					/* now we have the child ptf and the instruments, look for positions which has the event number */
					DBA_DYNFLD_STP getArgPtr = mp.allocDynst(FILEINFO, Get_Arg);
					int				extPosNbr = 0;
					DBA_DYNFLD_STP	*extPosTab = nullptr;
					SET_ID(getArgPtr, Get_Arg_PtfId, GET_ID(stratLnkTab[0], S_StratLnk_ObjId));
					SET_CODE(getArgPtr, Get_Arg_Cd, GET_CODE(stdInstructStp, A_StandInstruct_Cd));
					SET_NUMBER(getArgPtr, Get_Arg_Number, GET_INT(dbInvestDate, A_PlanInvestDate_EventNumber));
					SET_ENUM(getArgPtr, Get_Arg_Enum1, GET_ENUM(domainStp, A_Domain_MinStatEn));
					for (auto instrId : instrList)
					{
						SET_ID(getArgPtr, Get_Arg_InstrId, instrId);
						if ((ret = DBA_ExtractHierEltRecWithFilterSt(hierHead, ExtPos, FALSE,
							FIN_FilterEventExtPosNI, getArgPtr,
							NULLFCT, &extPosNbr, &extPosTab)) != RET_SUCCEED)
						{
							return(ret);
						}

						FREE(extPosTab);

						if (extPosNbr == 0)
						{
							eventPosFlg = FALSE;
							break;
						}

					}
				}
			}
		}
		else
		{
			FIN_CheckExistEventPos(hierHead, domainStp, stdInstructStp, GET_INT(dbInvestDate, A_PlanInvestDate_EventNumber), &eventPosFlg);
		}

		if (eventPosFlg == TRUE)
		{
			if (GET_ENUM(dbInvestDate, A_PlanInvestDate_Status) == PlanInvestDateStatus_Treated)
			{
				SET_ENUM(dbInvestDate, A_PlanInvestDate_Status, PlanInvestDateStatus_Success);
			}
			else
			{
				SET_ENUM(dbInvestDate, A_PlanInvestDate_Status, PlanInvestDateStatus_RetrySuccess);
			}

			*successFlg = TRUE; 
		}
		else
		{
			/* rester sur la pï¿½riode ?
			ApplEvtGenCheckDays = A_Domain_InterpFromDate
			+ */
			if (GET_ENUM(dbInvestDate, A_PlanInvestDate_Status) == PlanInvestDateStatus_Treated)
			{
				SET_ENUM(dbInvestDate, A_PlanInvestDate_Status, PlanInvestDateStatus_Failed);
			}
			else
			{
				SET_ENUM(dbInvestDate, A_PlanInvestDate_Status, PlanInvestDateStatus_RetryFailed);
			}

			*successFlg = FALSE;
		}
		SET_ENUM(dbInvestDate, A_PlanInvestDate_DbActionEn, ExtOpActionEn_ToUpdate);
	}
	else if (GET_ENUM(dbInvestDate, A_PlanInvestDate_Status) == PlanInvestDateStatus_Success ||
		     GET_ENUM(dbInvestDate, A_PlanInvestDate_Status) == PlanInvestDateStatus_RetrySuccess)
	{
		*successFlg = TRUE;
	}

	return(RET_SUCCEED);
}

/************************************************************************
*
*  Function    : FIN_UpdPlanInvestDateInDb()
*
*  Description : check and update invest_date
*
*  Arguments   : dynSt     : pointer on a dynamic structure
*                dynStTp   : dynamic structure type
*
*  Return      : TRUE or FALSE
*
*  Creation    : PMSTA21265 - DDV - 151022
*
*  Last modif. : PMSTA28294 - RAK - 171123 
*
*************************************************************************/
STATIC RET_CODE FIN_UpdPlanInvestDateInDb(DBA_DYNFLD_STP      domainStp,
										  DBA_HIER_HEAD_STP   hierHead,
										  ID_T                investParamId,
                                          DBA_DYNFLD_STP      *investDateArray, 
                                          int                 investDateNbr,
                                          DATE_T              beginDate,
                                          DATE_T              endDate,
                                          DATE_T              nextBeginDate,
										  int			      firstDateIdx,
										  DBA_DYNFLD_STP	  standInstructStp,
										  DBA_DYNFLD_STP	  planDefStp)
{
    RET_CODE            ret=RET_SUCCEED;
    DBA_DYNFLD_STP      *tmpArray, *dbInvestDateArray=nullptr; 
    int                 i=0, db=0, tmpNbr, dbInvestDateNbr=0;
	INT_T				retryNbr, lastEvtNbr;
	bool				successFlg=FALSE, doNotRetry=FALSE;
	ENUM_T			    crtEvtStatus;

    if (investParamId == ZERO_ID)
        return(RET_GEN_ERR_INVARG);

	MemoryPool mp;

	DBA_DYNFLD_STP selArgStp = mp.allocDynst(FILEINFO, Sel_Arg);

    /* Load All dates on same period from db */
	SET_ID(selArgStp, Sel_Arg_Id1, investParamId);
	SET_DATE(selArgStp, Sel_Arg_FromDate, beginDate);
	SET_DATE(selArgStp, Sel_Arg_TillDate, endDate);

	DbiConnectionHelper connexion(SqlServer);

	/* WSC-5852 - RAK - 180322 - delete old plan investment date for simulation */
	if (GET_ENUM(domainStp, A_Domain_EvtGenNatEn) == EvtGen_CreateSessionAndCheck &&
		GET_ENUM(domainStp, A_Domain_CompDataEn) == CompData_ReplOld)
	{
		connexion.dbaDelete(PlanInvestDate, UNUSED, selArgStp);
		/* and these stay dbInvestDateNbr=0,  dbInvestDateArray=null*/
	}
	else
	{
		connexion.dbaSelect(PlanInvestDate, UNUSED, selArgStp, A_PlanInvestDate, &dbInvestDateArray, &dbInvestDateNbr);
		mp.owner(dbInvestDateArray, dbInvestDateNbr);
	}

    /* set action None/Ins/Upd/Del */
	retryNbr = 0;
	lastEvtNbr = 0;
	crtEvtStatus = PlanInvestDateStatus_Untreated;

    for (i=0, db=0; i < investDateNbr; i++)
	{		
		if (GET_DATETIME(investDateArray[i], A_PlanInvestDate_InvestmentDate).date < beginDate ||
			GET_DATETIME(investDateArray[i], A_PlanInvestDate_InvestmentDate).date > endDate)
		{
			SET_ENUM(investDateArray[i], A_PlanInvestDate_DbActionEn, ExtOpActionEn_UpToDate);
			continue;
		}

		while(db < dbInvestDateNbr &&
                CMP_DYNFLD(dbInvestDateArray[db], investDateArray[i], A_PlanInvestDate_InvestmentDate, A_PlanInvestDate_InvestmentDate, DatetimeType) < 0)
        {
			/* delete old untreated */
            if (GET_ENUM(dbInvestDateArray[db], A_PlanInvestDate_Status) == PlanInvestDateStatus_Untreated)
            {
                SET_ENUM(dbInvestDateArray[db], A_PlanInvestDate_DbActionEn, ExtOpActionEn_ToDelete);
            }
            else
            {
				/* < PMSTA28294 - RAK - 171221 */
				if (GET_ENUM(planDefStp, A_PlanDefinition_Nature) != PlanDefNat_SystematicInvestPlan)
				{
					SET_ENUM(dbInvestDateArray[db], A_PlanInvestDate_DbActionEn, ExtOpActionEn_UpToDate);
				}
				else
				{
					if (GET_ENUM(dbInvestDateArray[db], A_PlanInvestDate_Status) == PlanInvestDateStatus_RetryCandidate)
					{
						if (successFlg == TRUE)
							SET_ENUM(dbInvestDateArray[db], A_PlanInvestDate_DbActionEn, ExtOpActionEn_ToDelete);
					}
					else
					{
						/* change a Treated in Success or Failed */
						/* change a RetryTreated in RetrySuccess or RetryFailed */
						FIN_UpdTreatedResult(hierHead, domainStp, standInstructStp, dbInvestDateArray[db], &successFlg);
					}
				}
				/* PMSTA28294 - RAK - 171221 > */
            }
            db++;
        }

		if (db == dbInvestDateNbr ||
			CMP_DYNFLD(dbInvestDateArray[db], investDateArray[i], A_PlanInvestDate_InvestmentDate, A_PlanInvestDate_InvestmentDate, DatetimeType) > 0)
		{
			/* < PMSTA28294 - RAK - 171221 */
			if (GET_ENUM(planDefStp, A_PlanDefinition_Nature) != PlanDefNat_SystematicInvestPlan)
			{
				SET_ENUM(investDateArray[i], A_PlanInvestDate_DbActionEn, ExtOpActionEn_ToInsert);
			}
			/* PMSTA-29917 - rak - 180122 - For the creation of Untreated at validation or new date of plan */
			else if ((db == dbInvestDateNbr && GET_ENUM(investDateArray[i], A_PlanInvestDate_Status) != PlanInvestDateStatus_RetryCandidate) || 
				     (successFlg == FALSE && (crtEvtStatus > PlanInvestDateStatus_Untreated || doNotRetry==FALSE)))
			{
				SET_ENUM(investDateArray[i], A_PlanInvestDate_DbActionEn, ExtOpActionEn_ToInsert);
			}
			else if (successFlg == TRUE && lastEvtNbr == GET_INT(investDateArray[i], A_PlanInvestDate_EventNumber))
			{
				SET_ENUM(investDateArray[i], A_PlanInvestDate_Status, PlanInvestDateStatus_RetryCancelled);
			}
		}

        if (db < dbInvestDateNbr &&
            CMP_DYNFLD(dbInvestDateArray[db], investDateArray[i], A_PlanInvestDate_InvestmentDate, A_PlanInvestDate_InvestmentDate, DatetimeType) == 0)
        {
			/* < PMSTA28294 - RAK - 171207 - Keep std treatment */
			if (GET_ENUM(planDefStp, A_PlanDefinition_Nature) != PlanDefNat_SystematicInvestPlan)
			{
				SET_ENUM(dbInvestDateArray[db], A_PlanInvestDate_DbActionEn, ExtOpActionEn_UpToDate);
            	COPY_DYNST(investDateArray[i], dbInvestDateArray[db], A_PlanInvestDate);
			}
			else
			{
				/* reinit successFlg for new investment date */
				if (lastEvtNbr != GET_INT(dbInvestDateArray[db], A_PlanInvestDate_EventNumber))
				{
					lastEvtNbr = GET_INT(dbInvestDateArray[db], A_PlanInvestDate_EventNumber);
					doNotRetry = FALSE;
					if (GET_ENUM(dbInvestDateArray[db], A_PlanInvestDate_Status) == PlanInvestDateStatus_RetrySuccess ||
						GET_ENUM(dbInvestDateArray[db], A_PlanInvestDate_Status) == PlanInvestDateStatus_Success)
						successFlg = TRUE;
					else
						successFlg = FALSE;
				}

				if (GET_ENUM(dbInvestDateArray[db], A_PlanInvestDate_Status) == PlanInvestDateStatus_RetryCandidate)
				{
					if (successFlg == TRUE)
						SET_ENUM(dbInvestDateArray[db], A_PlanInvestDate_DbActionEn, ExtOpActionEn_ToDelete);
				}
				else
				{
					/* change a Treated in Success or Failed */
					/* change a RetryTreated in RetrySuccess or RetryFailed */
					FIN_UpdTreatedResult(hierHead, domainStp, standInstructStp, dbInvestDateArray[db], &successFlg);
					crtEvtStatus = GET_ENUM(dbInvestDateArray[db], A_PlanInvestDate_Status);
					/* PMSTA-30733 - RAK - 180326 - Add test on firstDateIdx NO_VALUE and not create retry before the first invest date */
					if ((firstDateIdx == NO_VALUE || i == firstDateIdx) && crtEvtStatus == PlanInvestDateStatus_Untreated)
						doNotRetry = TRUE;
				}

				COPY_DYNST(investDateArray[i], dbInvestDateArray[db], A_PlanInvestDate);
				SET_ENUM(dbInvestDateArray[db], A_PlanInvestDate_DbActionEn, ExtOpActionEn_UpToDate);
			}
			db++;
			/* PMSTA28294 - RAK - 171207 > */
        }
    }

	/* aussi dans le cas systematic ?? */
	while(db < dbInvestDateNbr)
    {
        if (GET_ENUM(dbInvestDateArray[db], A_PlanInvestDate_Status) == PlanInvestDateStatus_Untreated)
        {
            SET_ENUM(dbInvestDateArray[db], A_PlanInvestDate_DbActionEn, ExtOpActionEn_ToDelete);
        }
        else
        {
			SET_ENUM(dbInvestDateArray[db], A_PlanInvestDate_DbActionEn, ExtOpActionEn_UpToDate);
        }
        db++;
    }

	DBA_DYNFLD_STP sInvestDateStp = mp.allocDynst(FILEINFO, S_PlanInvestDate);

	if (false == connexion.isValidAndInit())
		return(RET_DBA_ERR_CONNOTFOUND);

	if ((ret = connexion.beginTransaction()) != RET_SUCCEED)
		return(ret);

    tmpArray = investDateArray;
    tmpNbr = investDateNbr;

	/* loop first on investDateArray, then on dbInvestDateArray to update database */
    do
    {
        for (i=0; i < tmpNbr && ret == RET_SUCCEED; i++)
        {
            switch(GET_ENUM(tmpArray[i], A_PlanInvestDate_DbActionEn))
            {
                 case ExtOpActionEn_ToDelete:
                    COPY_DYNFLD(sInvestDateStp, S_PlanInvestDate, S_PlanInvestDate_Id,
                                tmpArray[i],    A_PlanInvestDate, A_PlanInvestDate_Id);
					ret = connexion.dbaDelete(PlanInvestDate, UNUSED, sInvestDateStp);
					
                    break;

                 case ExtOpActionEn_ToInsert:
                    /* insert it only if investment_d is before nextBeginDate */
                    if (GET_DATETIME(tmpArray[i], A_PlanInvestDate_InvestmentDate).date < nextBeginDate)          
                        ret = connexion.dbaInsert(PlanInvestDate, UNUSED, tmpArray[i]);
					break;

				 case ExtOpActionEn_ToUpdate:
					 /* update it only if investment_d is before nextBeginDate */
					 if (GET_DATETIME(tmpArray[i], A_PlanInvestDate_InvestmentDate).date < nextBeginDate)
						ret = connexion.dbaUpdate(PlanInvestDate, UNUSED, tmpArray[i]);
					break;
            }
        }

        if (tmpArray == investDateArray)	/* loop first on investDateArray, then on dbInvestDateArray*/
        {
            tmpArray = dbInvestDateArray;
            tmpNbr = dbInvestDateNbr;
        }
        else
        {
            tmpArray = NULLDYNSTPTR;
            tmpNbr = 0;
        }
    }
    while (tmpArray != NULLDYNSTPTR);

	/* End Transaction */
	ret = connexion.endTransaction(ret == RET_SUCCEED);
    return(ret);
}

/************************************************************************
*
*  Function    : FIN_CheckAndUpdPlanInvestDate()
*
*  Description : check and update invest_date
*
*  Arguments   : dynSt     : pointer on a dynamic structure
*                dynStTp   : dynamic structure type
*
*  Return      : TRUE or FALSE
*
*  Creation    : PMSTA21265 - DDV - 151022
*
*  Last modif. : 
*
*************************************************************************/
STATIC RET_CODE FIN_CheckAndUpdPlanInvestDate(DBA_DYNFLD_STP      domainStp,
                                              DBA_HIER_HEAD_STP   hierHead,
                                              DBA_DYNFLD_STP      *investParamArray, 
                                              int                 investParamNbr)
{
	DBA_DYNFLD_STP      *investDateArray, planDefStp, stdInstructStp = NULLDYNST;
	int                 investDateNbr, investDateAllocSz, i, j, periodDateNbr = 0, firstDateIdx;
    DATETIME_T          beginDate, endDate, retryDate;
	DATE_T              currentDate=0, maxUpdPeriodEndDate=0, maxEndDate, objMaxEndDate, nextBeginDate, updPeriodEndDate=0;
	double              freq, retryFreq;
	DATE_UNIT_ENUM		dateFreqUnitE;	/* PMSTA-32591 - RAK - 180822 - Treat Week */
	FREQUNIT_ENUM		targFreqUnitE;	/* PMSTA-32591 - RAK - 180822 - Treat Week */
    char                endMFlg=FALSE;
   	DAY_T               day, d;
   	MONTH_T             m;
   	YEAR_T              y;
	INT_T				evtNbr, retryNbr=0;
	FLAG_T				firstRetryFlg;
    MemoryPool          mp;

    beginDate.date = 0;
    beginDate.time = 0;
    endDate.date = 0;
    endDate.time = 0;
	retryDate.date = 0;
	retryDate.time = 0;

    currentDate = DATE_CurrentDate();
    maxUpdPeriodEndDate = DATE_Move(currentDate, 1, Year);

    if (maxUpdPeriodEndDate > GET_DATETIME(domainStp, A_Domain_InterpTillDate).date)
        maxEndDate = maxUpdPeriodEndDate;
    else
        maxEndDate = GET_DATETIME(domainStp, A_Domain_InterpTillDate).date;

    
    investDateAllocSz=1;
    investDateArray = (DBA_DYNFLD_STP*)mp.calloc(investDateAllocSz, sizeof(DBA_DYNFLD_STP));

    for (i=0; i < investParamNbr; i++)
    {
        investDateNbr = 0;
		investDateAllocSz = 0;
		investDateArray = NULLDYNSTPTR;
        firstDateIdx=NO_VALUE;
        periodDateNbr=0;

        /* dont't generate date for free amount objective nature */
        if (DBA_GetRecPtrFromHierById(hierHead, GET_ID(investParamArray[i], A_PlanInvestParamHisto_PlanDefinitionId), A_PlanDefinition, &planDefStp) == RET_SUCCEED &&
            GET_ENUM(planDefStp, A_PlanDefinition_ObjectiveNature) == PlanDefObjectiveNat_FreeAmount)
            continue;

		/* PMSTA28294 - RAK - 171123- To get the A_PlanInvestDate_EventCd */
		if (planDefStp != NULL && GET_EXTENSION_PTR(planDefStp, A_PlanDefinition_StandInstruct_Ext) != NULL)
			stdInstructStp = *(GET_EXTENSION_PTR(planDefStp, A_PlanDefinition_StandInstruct_Ext));

        /* build new date array */
/* PMSTA-32591 - RAK - 180822 - In case of week, use Day frequency */
		dateFreqUnitE = Month;	/* use for the DATE_Move() */
		targFreqUnitE = FreqUnit_Month;

		if ((FREQUNIT_ENUM)GET_ENUM(investParamArray[i], A_PlanInvestParamHisto_InvestFreqUnit) <= FreqUnit_Week)
		{
			dateFreqUnitE = Day; /* use for the DATE_Move() */
			targFreqUnitE = FreqUnit_Day;
		}
		
	    FIN_PeriodUnitNbr((FREQUNIT_ENUM)GET_ENUM(investParamArray[i], A_PlanInvestParamHisto_InvestFreqUnit),
				            GET_TINYINT(investParamArray[i], A_PlanInvestParamHisto_InvestFreq), 
							targFreqUnitE, &freq);

        if (freq == 0)
        {
	        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, 
			                "FIN_CheckAndUpdPlanInvestDate", "investment's frequency");
            return(RET_GEN_ERR_INVARG);
        }

        endDate.date = beginDate.date = GET_DATETIME(investParamArray[i], A_PlanInvestParamHisto_FirstInvestDate).date;

	    DATE_Get(beginDate.date, (YEAR_T*)NULL, (MONTH_T*)NULL, &day);

		if (dateFreqUnitE != Day)
		{
			switch (GET_ENUM(investParamArray[i], A_PlanInvestParamHisto_EndOfMonthConv))
			{
			case InstrEom_Last:
				endMFlg = (char)TRUE;
				break;
			case InstrEom_Same:
				endMFlg = (char)FALSE;
				break;
			case InstrEom_Last360:
				if (endMFlg == TRUE)
					day = 30;
				endMFlg = (char)FALSE;
				break;
			default:
				endMFlg = (char)DATE_IsLastInMonth(endDate.date);
				break;
			}
		}

		/* PMSTA28294 - RAK - 171116 - Treat retry if specified for SystematicInvestPlan */
		/* PMSTA-29806 - RAK - 180115 - In "simulation" don't add retries */
		retryFreq = 0;
		if (GET_ENUM(planDefStp, A_PlanDefinition_Nature) == PlanDefNat_SystematicInvestPlan && 
			GET_ENUM(domainStp, A_Domain_EvtGenNatEn) != EvtGen_CreateSessionAndCheck && 
			!IS_NULLFLD(investParamArray[i], A_PlanInvestParamHisto_RetryFreq) && !IS_NULLFLD(investParamArray[i], A_PlanInvestParamHisto_MaxRetry))
		{
			FIN_PeriodUnitNbr((FREQUNIT_ENUM)GET_ENUM(investParamArray[i], A_PlanInvestParamHisto_RetryFreqUnit),
				GET_TINYINT(investParamArray[i], A_PlanInvestParamHisto_RetryFreq),
				FreqUnit_Day, &retryFreq);

			if (retryFreq == 0)
			{
				MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
					"FIN_CheckAndUpdPlanInvestDate", "Retry's frequency");
				return(RET_GEN_ERR_INVARG);
			}
		}

		/* PMSTA-29806 - RAK - 180116 - Other small improvements: */
		/* If end date exists (plan_objective_histo.objective_d) generate the plan invest dates until the end date  */
		objMaxEndDate = maxEndDate;  /* 1 year by default */
		if (GET_ENUM(planDefStp, A_PlanDefinition_Nature) == PlanDefNat_SystematicInvestPlan)
		{
			DBA_DYNFLD_STP objectiveStp = nullptr;

			if (GET_EXTENSION_PTR(planDefStp, A_PlanDefinition_PlanObjectiveHisto_Ext) != NULL)
				objectiveStp = GET_EXTENSION_PTR(planDefStp, A_PlanDefinition_PlanObjectiveHisto_Ext)[0];
		
			if (objectiveStp != nullptr && !IS_NULLFLD(objectiveStp, A_PlanObjectiveHisto_ObjectiveDate))
			{
				objMaxEndDate = GET_DATETIME(objectiveStp, A_PlanObjectiveHisto_ObjectiveDate).date;
			}
		}

		firstRetryFlg = FALSE;
	    while (endDate.date <= objMaxEndDate)
        {	
            beginDate.date = endDate.date;
		    endDate.date = DATE_Move(beginDate.date, (int)freq, dateFreqUnitE);		/* PMSTA-32591 - RAK - 180822 - Use unit (Month or Day) */
			if (dateFreqUnitE != Day) 
			{
				DATE_VerifyEndMonth(&endDate.date, day, endMFlg);

				if (GET_ENUM(investParamArray[i], A_PlanInvestParamHisto_EndOfMonthConv) == InstrEom_Last360 && day == 30)
				{
					DATE_Get(endDate.date, &y, &m, &d);
					if (m == (MONTH_T)2 && d == (DAY_T)29)
					{
						endDate.date = DATE_Put(y, m, (DAY_T)28);
					}
				}
			}

			evtNbr = FIN_CalcEvtNbr(beginDate.date);

            DBA_DYNFLD_STP investDateStp = mp.allocDynst(FILEINFO,A_PlanInvestDate);

            COPY_DYNFLD(investDateStp, A_PlanInvestDate, A_PlanInvestDate_PlanInvestParamHistoId,
                        investParamArray[i], A_PlanInvestParamHisto, A_PlanInvestParamHisto_Id);
            SET_DATETIME(investDateStp, A_PlanInvestDate_InvestmentDate, beginDate);
            SET_ENUM(investDateStp,		A_PlanInvestDate_Status,		 PlanInvestDateStatus_Untreated);
			SET_INT(investDateStp,		A_PlanInvestDate_EventNumber,	 evtNbr);
			if (stdInstructStp) { SET_CODE(investDateStp, A_PlanInvestDate_EventCd, GET_CODE(stdInstructStp, A_StandInstruct_Cd)); }

			/* PMSTA28294 - RAK - 171228 old bug but with small chance to occurs with large frequency */
			/* change the <= on test on end date as it will mark treated in invest date but no operation will be generated */
            if (beginDate.date >= GET_DATETIME(domainStp, A_Domain_InterpFromDate).date &&
                beginDate.date < GET_DATETIME(domainStp, A_Domain_InterpTillDate).date)
            {
                if (firstDateIdx == NO_VALUE)
                    firstDateIdx = investDateNbr;

                periodDateNbr++;
            }

            FIN_AddEltInInvestDateArray(investDateStp, NULLDYNST, &investDateArray, &investDateNbr, &investDateAllocSz, FALSE,mp);

			/* PMSTA28294 - RAK - 171116 - PlanDefNat_SystematicInvestPlan - Retry mechanism */
			if (retryFreq != 0 && firstRetryFlg == FALSE)
			{
				retryNbr = 0;
				retryDate.date = beginDate.date;
				
				while (retryNbr < (INT_T)GET_TINYINT(investParamArray[i], A_PlanInvestParamHisto_MaxRetry))
				{
					retryNbr++;

					retryDate.date = DATE_Move(retryDate.date, (int)retryFreq, Day);

					/* Create all retry, then in UpdDb decide if we insert them in database */
					investDateStp = mp.allocDynst(FILEINFO,A_PlanInvestDate);
					COPY_DYNFLD(investDateStp, A_PlanInvestDate, A_PlanInvestDate_PlanInvestParamHistoId,
						investParamArray[i], A_PlanInvestParamHisto, A_PlanInvestParamHisto_Id);
					SET_DATETIME(investDateStp, A_PlanInvestDate_InvestmentDate, retryDate);
					SET_ENUM(investDateStp, A_PlanInvestDate_Status, PlanInvestDateStatus_RetryCandidate);
					SET_INT(investDateStp, A_PlanInvestDate_RetryNumber, retryNbr);
					SET_INT(investDateStp, A_PlanInvestDate_EventNumber, (INT_T)evtNbr);
					if (stdInstructStp) { SET_CODE(investDateStp, A_PlanInvestDate_EventCd, GET_CODE(stdInstructStp, A_StandInstruct_Cd)); }

					/* only in the domain period */
					if ((beginDate.date >= GET_DATETIME(domainStp, A_Domain_InterpFromDate).date &&
						beginDate.date < GET_DATETIME(domainStp, A_Domain_InterpTillDate).date) ||
						(retryDate.date >= GET_DATETIME(domainStp, A_Domain_InterpFromDate).date &&
						retryDate.date < GET_DATETIME(domainStp, A_Domain_InterpTillDate).date))
					{
						if (firstDateIdx == NO_VALUE)
							firstDateIdx = investDateNbr;
							
						periodDateNbr++;
					}

					if (retryDate.date >= GET_DATETIME(domainStp, A_Domain_InterpFromDate).date)
						firstRetryFlg = TRUE;

					FIN_AddEltInInvestDateArray(investDateStp, NULLDYNST, &investDateArray, &investDateNbr, &investDateAllocSz, FALSE, mp);
				}
			}
	    }

        /* Check till when this invest param must be use */
		if (i < (investParamNbr-1) &&
            CMP_DYNFLD(investParamArray[i + 1], investParamArray[i], A_PlanInvestParamHisto_PlanDefinitionId, A_PlanInvestParamHisto_PlanDefinitionId, IdType) == 0)
		{
    		nextBeginDate = GET_DATETIME(investParamArray[i + 1], A_PlanInvestParamHisto_BeginDate).date;
		}
		else
		{
			nextBeginDate = MAGIC_END_DATE;
		}

		/* PMSTA-29806 - RAK - 180116 - Other small improvements: */
		/* If end date exists (plan_objective_histo.objective_d) generate the plan invest dates until the end date  */
		if (GET_ENUM(planDefStp, A_PlanDefinition_Nature) == PlanDefNat_SystematicInvestPlan)
		{
			updPeriodEndDate = objMaxEndDate;
		}
		else
		{
			updPeriodEndDate = maxUpdPeriodEndDate;
		}

        /* Update investment date in db, the investDateArray will be used to generate flows on periodDateNbr */
		FIN_UpdPlanInvestDateInDb(domainStp, hierHead, GET_ID(investParamArray[i], A_PlanInvestParamHisto_Id), investDateArray, investDateNbr,
			                      currentDate, updPeriodEndDate, nextBeginDate, 
								  firstDateIdx, stdInstructStp, planDefStp);

		/* < PMSTA28294 - RAK - 171116 - because previous succeed */
		if (firstDateIdx != NO_VALUE && 
			GET_ENUM(planDefStp, A_PlanDefinition_Nature) == PlanDefNat_SystematicInvestPlan)
		{
			for (j = firstDateIdx; j < (firstDateIdx + periodDateNbr); j++)
			{
				if ((GET_ENUM(investDateArray[j], A_PlanInvestDate_Status) == PlanInvestDateStatus_RetryCandidate &&
					 GET_ENUM(investDateArray[j], A_PlanInvestDate_DbActionEn) == ExtOpActionEn_ToDelete) ||			/*  retry after success */
					 GET_ENUM(investDateArray[j], A_PlanInvestDate_Status) == PlanInvestDateStatus_RetryCancelled)   
					periodDateNbr--;

				/* Don't do a second time an order */
				if ((GET_ENUM(investDateArray[j], A_PlanInvestDate_Status) == PlanInvestDateStatus_Failed ||
					GET_ENUM(investDateArray[j], A_PlanInvestDate_Status) == PlanInvestDateStatus_RetryFailed) && j == firstDateIdx)
					firstDateIdx = NO_VALUE;
			}

			if (periodDateNbr == 0)
				firstDateIdx = NO_VALUE;
		}
		/* PMSTA28294 - RAK - 171116 > */

		if (firstDateIdx > NO_VALUE)
		{
			/* put in hierarchy only the date(s) of flow(s)/operation(s)*/
			DBA_AddHierRecordList(hierHead, &(investDateArray[firstDateIdx]), periodDateNbr, A_PlanInvestDate, TRUE);
				
			for (j = firstDateIdx; j < (firstDateIdx + periodDateNbr); j++)
			{
				mp.removeDynStp(investDateArray[j]);
			}
		}
    }

    DBA_SetHierLnkUsed(hierHead, A_PlanInvestParamHisto, A_PlanInvestParamHisto_PlanInvestDate_Ext);
    DBA_MakeAllRecLinks(hierHead, A_PlanInvestParamHisto);

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    : FIN_GetPlanRecordsByDate()
**
**  Description : 
**
**  Arguments   : 
**
**  Return      : TRUE or FALSE
**
**  Creation    : PMSTA-21265 - DDV - 151008
**
**  Last modif. :
**
*************************************************************************/
STATIC RET_CODE FIN_GetPlanRecordsByDate(DATETIME_T         dateSt,
                                         DBA_DYNFLD_STP     planDefStp,
                                         DBA_DYNFLD_STP     *objectiveStp,
                                         DBA_DYNFLD_STP     *planRuleHistoStp,
                                         DBA_DYNFLD_STP     *investParamStp)
{
    int i;
    DBA_DYNFLD_STP     *dynStpArray=NULLDYNSTPTR;
	DBA_DYNFLD_STP     getArgStp=NULLDYNST;
	DBA_DYNFLD_STP     getRecStp=NULLDYNST;
	int                dynStpNbr=0;

    *objectiveStp     = NULLDYNSTPTR;
    *planRuleHistoStp = NULLDYNSTPTR;
    *investParamStp   = NULLDYNSTPTR;

	/* Find objective to use at this date                                                                                 */
    if (GET_EXTENSION_PTR(planDefStp, A_PlanDefinition_PlanObjectiveHisto_Ext) != NULL)
    {
        dynStpArray = GET_EXTENSION_PTR(planDefStp, A_PlanDefinition_PlanObjectiveHisto_Ext);
        dynStpNbr   = GET_EXTENSION_NBR(planDefStp, A_PlanDefinition_PlanObjectiveHisto_Ext);

        for (i=0; i < dynStpNbr; i++)
        {
            if (DATETIME_CMP(GET_DATETIME(dynStpArray [i], A_PlanObjectiveHisto_BeginDate), dateSt) <= 0)
                (*objectiveStp) = dynStpArray[i];
            else
                break;
        }
    }
  
	/* Find objective rule_histo use at this date                                                                                 */
    /* Load Rule if a rule is use */
    if (IS_NULLFLD(planDefStp, A_PlanDefinition_PlanRuleId) == FALSE)
    {
        DBA_DYNFLD_STP     planRuleStp = NULLDYNST;
        MemoryPool         mp;

        if (DBA_GetRecordById(PlanRule, GET_ID(planDefStp, A_PlanDefinition_PlanRuleId), A_PlanRule, &planRuleStp, mp) == RET_SUCCEED)
        {
            /* Load active history */
	        if ((getArgStp = ALLOC_DYNST(Get_Arg)) == NULL)
	        {
		        return(RET_MEM_ERR_ALLOC);
	        }

    	    if ((getRecStp = ALLOC_DYNST(A_PlanRuleHisto)) == NULL)
	        {
		        FREE_DYNST(getArgStp, Get_Arg);
		        return(RET_MEM_ERR_ALLOC);
	        }

            SET_ID(getArgStp, Get_Arg_Id, GET_ID(planDefStp, A_PlanDefinition_PlanRuleId));
            SET_DATETIME(getArgStp, Get_Arg_DateTime, dateSt);

            if (DBA_Get2(PlanRuleHisto, UNUSED, Get_Arg, getArgStp, A_PlanRuleHisto, &getRecStp, UNUSED, UNUSED, UNUSED) == RET_SUCCEED)
            {
                (*planRuleHistoStp) = getRecStp;
            }
            else
            {
                FREE_DYNST(getRecStp, A_PlanRuleHisto);
            }
		    FREE_DYNST(getArgStp, Get_Arg);
	    }
        else
        {
            MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, "plan_rule");
            return(RET_DBA_ERR_NODATA);
        }
    }

	/* Find investment param to use at this date                                                                                 */
    if (GET_EXTENSION_PTR(planDefStp, A_PlanDefinition_PlanInvestParamHisto_Ext) != NULL)
    {
        dynStpArray = GET_EXTENSION_PTR(planDefStp, A_PlanDefinition_PlanInvestParamHisto_Ext);
        dynStpNbr   = GET_EXTENSION_NBR(planDefStp, A_PlanDefinition_PlanInvestParamHisto_Ext);

        for (i=0; i < dynStpNbr; i++)
        {
            if (DATETIME_CMP(GET_DATETIME(dynStpArray [i], A_PlanInvestParamHisto_BeginDate), dateSt) <= 0)
                (*investParamStp) = dynStpArray[i];
            else
                break;
        }
    }

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    : FIN_ComputeMinMaxAmt()
**
**  Description : 
**
**  Arguments   : 
**
**  Return      : TRUE or FALSE
**
**  Creation    : PMSTA-21265 - DDV - 151008
**
**  Last modif. :
**
*************************************************************************/
STATIC RET_CODE FIN_ComputeMinMaxAmt(DBA_DYNFLD_STP     planRuleHistoStp,
                                     DBA_DYNFLD_STP     objectiveStp,
                                     AMOUNT_T           *minAmt,
                                     AMOUNT_T           *maxAmt,
                                     FLAG_T             *indexMinAmtFlg,
                                     FLAG_T             *indexMaxAmtFlg,
                                     AMOUNT_T           *ruleMaxAmtPtr)
{
    AMOUNT_T         objMinAmt = NO_VALUE, objMaxAmt = NO_VALUE;
    AMOUNT_T         ruleMinAmt = NO_VALUE, ruleMaxAmt = NO_VALUE;
    FLAG_T           useObjectiveFlg=TRUE;

    (*ruleMaxAmtPtr) = NO_VALUE;
    (*indexMinAmtFlg) = FALSE;
    (*indexMaxAmtFlg) = FALSE;

    if (IS_NULLFLD(objectiveStp, A_PlanObjectiveHisto_MinAmount) == FALSE)
    {
        objMinAmt = GET_AMOUNT(objectiveStp, A_PlanObjectiveHisto_MinAmount);
    }

    if (IS_NULLFLD(objectiveStp, A_PlanObjectiveHisto_MaxAmount) == FALSE)
    {
        objMaxAmt = GET_AMOUNT(objectiveStp, A_PlanObjectiveHisto_MaxAmount);
    }

    if (planRuleHistoStp != NULLDYNSTPTR)
    {
        if (IS_NULLFLD(planRuleHistoStp, A_PlanRuleHisto_MinAmount) == FALSE)
        {
            ruleMinAmt = GET_AMOUNT(planRuleHistoStp, A_PlanRuleHisto_MinAmount);
        }

        if (IS_NULLFLD(planRuleHistoStp, A_PlanRuleHisto_MaxAmount) == FALSE)
        {
            (*ruleMaxAmtPtr) = ruleMaxAmt = GET_AMOUNT(planRuleHistoStp, A_PlanRuleHisto_MaxAmount);
        }
    }

    /* Use min amount from objective or rule ? */
    if (objMinAmt == NO_VALUE)
        useObjectiveFlg = FALSE;
    else if (ruleMinAmt == NO_VALUE)
        useObjectiveFlg = TRUE;
    else if (objMinAmt < ruleMinAmt)
    {   /* this case must not happend, error message ? */
        useObjectiveFlg = FALSE;
    }
    else
        useObjectiveFlg = TRUE;


    if (useObjectiveFlg == TRUE)
    {
        (*minAmt) = objMinAmt;

        if(objMinAmt != NO_VALUE &&
           (GET_ENUM(objectiveStp, A_PlanObjectiveHisto_MinAmtIndexRule) == PlanObjectiveIdxRule_Amount ||
            GET_ENUM(objectiveStp, A_PlanObjectiveHisto_MinAmtIndexRule) == PlanObjectiveIdxRule_Percent) &&
           GET_NUMBER(objectiveStp, A_PlanObjectiveHisto_MinAmtIndexValue) > 0.0)
            (*indexMinAmtFlg) = TRUE;
    }
    else
    {
        (*minAmt) = ruleMinAmt;
    }


    /* Use max amount from objective or rule ? */
    if (objMaxAmt == NO_VALUE)
        useObjectiveFlg = FALSE;
    else if (ruleMaxAmt == NO_VALUE)
        useObjectiveFlg = TRUE;
    else if (objMaxAmt > ruleMaxAmt)
    {   /* this case must not happend, error message ? */
        useObjectiveFlg = FALSE;
    }
    else
        useObjectiveFlg = TRUE;

    if (useObjectiveFlg == TRUE)
    {
        (*maxAmt) = objMaxAmt;

        if (objMaxAmt != NO_VALUE &&
            (GET_ENUM(objectiveStp, A_PlanObjectiveHisto_MaxAmtIndexRule) == PlanObjectiveIdxRule_Amount ||
             GET_ENUM(objectiveStp, A_PlanObjectiveHisto_MaxAmtIndexRule) == PlanObjectiveIdxRule_Percent) &&
            GET_NUMBER(objectiveStp, A_PlanObjectiveHisto_MaxAmtIndexValue) > 0.0)
            (*indexMaxAmtFlg) = TRUE;
    }
    else
    {
        (*maxAmt) = ruleMaxAmt;
    }

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    : FIN_IndexAmt
**
**  Description : 
**
**  Arguments   : 
**
**  Return      : TRUE or FALSE
**
**  Creation    : PMSTA-21900 - DDV - 151208
**
**  Last modif. :
**
*************************************************************************/
STATIC RET_CODE FIN_IndexAmt(AMOUNT_T          *amt, 
                             ENUM_T            indexationRuleEn, 
                             NUMBER_T          indexationValue)
{
    if (amt == NULL || indexationValue < 0.0)
        return(RET_GEN_ERR_INVARG);

    switch((PLANOBJECTIVE_IDXRULE_ENUM) indexationRuleEn)
    {
    	case PlanObjectiveIdxRule_Amount:
            if (indexationValue > 0.0)
                (*amt) += indexationValue;
            break;

    	case PlanObjectiveIdxRule_Percent:
                (*amt) *= (1+indexationValue/100.0);
            break;

    	case PlanObjectiveIdxRule_AmountDefByRule:
    	case PlanObjectiveIdxRule_None:
        default:
            break;
    }

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    : FIN_ComputeObjectivePeriod
**
**  Description : 
**
**  Arguments   : 
**
**  Return      : TRUE or FALSE
**
**  Creation    : PMSTA-21265 - DDV - 151012
**
**  Last modif. :
**
*************************************************************************/
STATIC RET_CODE FIN_ComputeObjectivePeriod(DATE_T            currentDate,
                                           DBA_DYNFLD_STP    objectiveStp,
                                           DBA_DYNFLD_STP    planRuleHistoStp,
                                           DATE_T            *objBeginDate,
                                           DATE_T            *objEndDate,
                                           AMOUNT_T          minAmt,
                                           AMOUNT_T          maxAmt, 
                                           FLAG_T            indexMinAmtFlg,
                                           FLAG_T            indexMaxAmtFlg,
                                           AMOUNT_T          *minAmtIndexed,
                                           AMOUNT_T          *maxAmtIndexed,
                                           AMOUNT_T          ruleMaxAmt)
{
    DATETIME_T    beginDate, endDate;
    double        freq;
    char          endMFlg=FALSE;
   	DAY_T         day;
    AMOUNT_T      newMinAmt = 0.0;
    AMOUNT_T      newMaxAmt = 0.0;

    beginDate.date = 0;
    beginDate.time = 0;
	endDate.date = 0;
	endDate.time = 0;

    newMinAmt = minAmt;
    newMaxAmt = maxAmt;

    if (IS_NULLFLD(objectiveStp, A_PlanObjectiveHisto_ObjectiveDate) == FALSE)
    {
	    endDate = GET_DATETIME(objectiveStp, A_PlanObjectiveHisto_ObjectiveDate);
    }
    else
    {
        if (planRuleHistoStp == NULLDYNST)
        {
	        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, 
			                "FIN_ComputeObjectivePeriod", "objective's date not define");
            return(RET_GEN_ERR_INVARG);
        }
        else
        {
            if (IS_NULLFLD(planRuleHistoStp, A_PlanRuleHisto_LastInvestDate) == FALSE)
            {
	            endDate = GET_DATETIME(planRuleHistoStp, A_PlanRuleHisto_LastInvestDate);
            }
            else
            {
	            MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, 
			                 "FIN_ComputeObjectivePeriod", "objective's date and rule last investment date not define");
                return(RET_GEN_ERR_INVARG);
            }
        }
    }

	FIN_PeriodUnitNbr((FREQUNIT_ENUM)GET_ENUM(objectiveStp, A_PlanObjectiveHisto_PeriodFreqUnit),
				        GET_TINYINT(objectiveStp, A_PlanObjectiveHisto_PeriodFreq), 
				        FreqUnit_Month, &freq);

    if (freq == 0)
    {
	    MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, 
			         "FIN_ComputeObjectivePeriod", "objective's frequency");
        return(RET_GEN_ERR_INVARG);
    }

	endMFlg = (char) DATE_IsLastInMonth(endDate.date);
	DATE_Get(endDate.date, (YEAR_T*)NULL, (MONTH_T*)NULL, &day);

    if (endDate.date >= currentDate)
    {
		beginDate.date = DATE_Move(endDate.date, (int)((-1) * freq), Month);
		DATE_VerifyEndMonth(&endDate.date, day, endMFlg);
    }
    else
    {
	    while (endDate.date < currentDate)
        {
            beginDate.date = endDate.date;
		    endDate.date = DATE_Move(beginDate.date, (int)freq, Month);
		    DATE_VerifyEndMonth(&endDate.date, day, endMFlg);

            if (indexMaxAmtFlg == TRUE && (ruleMaxAmt == NO_VALUE || newMaxAmt < ruleMaxAmt))
            {
                FIN_IndexAmt(&newMaxAmt, GET_ENUM(objectiveStp, A_PlanObjectiveHisto_MaxAmtIndexRule), GET_NUMBER(objectiveStp, A_PlanObjectiveHisto_MaxAmtIndexValue));

                if (ruleMaxAmt != NO_VALUE && newMaxAmt > ruleMaxAmt)
                    newMaxAmt = ruleMaxAmt;
            }

            if (indexMinAmtFlg == TRUE  && (newMaxAmt == NO_VALUE || newMinAmt < newMaxAmt))
            {
                FIN_IndexAmt(&newMinAmt, GET_ENUM(objectiveStp, A_PlanObjectiveHisto_MinAmtIndexRule), GET_NUMBER(objectiveStp, A_PlanObjectiveHisto_MinAmtIndexValue));
                if (newMaxAmt != NO_VALUE && newMinAmt > newMaxAmt)
                    newMinAmt = newMaxAmt;
            }
	    }
	}

    if (minAmtIndexed != NULL)
        (*minAmtIndexed) = newMinAmt;

    if (maxAmtIndexed != NULL)
        (*maxAmtIndexed) = newMaxAmt;

    if (objBeginDate != NULL)
        (*objBeginDate) = beginDate.date;

    if (objEndDate != NULL)
        (*objEndDate) = endDate.date;

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    : FIN_LoadPeriodInvestedAmt
**
**  Description : 
**
**  Arguments   : 
**
**  Return      : TRUE or FALSE
**
**  Creation    : PMSTA-21265 - DDV - 151012
**
**  Last modif. :
**
*************************************************************************/
STATIC RET_CODE FIN_LoadPeriodInvestedAmt(DBA_DYNFLD_STP    planDefStp,
                                          DBA_DYNFLD_STP    investParamStp,
                                          DATE_T            objBeginDate,
                                          DATE_T            currentDate,
                                          AMOUNT_T          *periodCurrentAmt)
{
    RET_CODE          ret=RET_SUCCEED;
    DBA_DYNFLD_STP    *investPosArray=NULLDYNSTPTR, inputArg=NULLDYNST;
    int               investPosNbr, i;
    AMOUNT_T          amt=0.0;

    (*periodCurrentAmt) = 0.0;
    if ((inputArg = ALLOC_DYNST(Sel_Arg)) == NULLDYNST)
    { 
        MSG_RETURN(RET_MEM_ERR_ALLOC); 
    }

    SET_ID(inputArg, Sel_Arg_Id1, GET_ID(planDefStp, A_PlanDefinition_PortfolioId));
    SET_ID(inputArg, Sel_Arg_Id2, GET_ID(investParamStp, A_PlanInvestParamHisto_InvestAcctId));
    SET_DATE(inputArg, Sel_Arg_FromDate, objBeginDate);
    SET_DATE(inputArg, Sel_Arg_TillDate, currentDate);

	if ((ret = DBA_Select2(Pos, UNUSED, Sel_Arg, inputArg, A_Pos, &investPosArray,  
                           UNUSED, UNUSED, &investPosNbr, UNUSED, UNUSED)) != RET_SUCCEED)
    {
        MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, "position");
        FREE_DYNST(inputArg, Sel_Arg);
		return(ret);
    }

    for (i=0; i < investPosNbr; i++)
    {
        if (GET_ENUM(investPosArray[i], A_Pos_OpenOpNatEn) == OpNat_Invest &&
            GET_ENUM(investPosArray[i], A_Pos_PrimaryEn)   == PosPrimary_Primary &&
            IS_NULLFLD(investPosArray[i], A_Pos_InstrGrossAmt) == FALSE)
        {
            amt += GET_AMOUNT(investPosArray[i], A_Pos_InstrGrossAmt);
        }
    }

    (*periodCurrentAmt) = amt;
    FREE_DYNST(inputArg, Sel_Arg);
    DBA_FreeDynStTab(investPosArray, investPosNbr, A_Pos);

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    : FIN_LoadPeriodInvestedAmt
**
**  Description : 
**
**  Arguments   : 
**
**  Return      : TRUE or FALSE
**
**  Creation    : PMSTA-21265 - DDV - 151012
**
**  Last modif. :
**
*************************************************************************/
STATIC RET_CODE FIN_ComputeAmtToInvest(DATE_T           objBeginDate, 
                                       DATE_T           objEndDate, 
                                       DATE_T           currentDate, 
                                       AMOUNT_T         minAmt, 
                                       AMOUNT_T         maxAmt, 
                                       AMOUNT_T         periodCurrentAmt, 
                                       DBA_DYNFLD_STP   planDefStp, 
                                       DBA_DYNFLD_STP   investParamStp, 
                                       DBA_DYNFLD_STP   objectiveStp, 
                                       AMOUNT_T         *amtToInvest)
{
    int           investNbr=0;
    AMOUNT_T      targetAmt=0.0, currentAmt=0.0, amt=0.0;
    DATETIME_T    beginDate, endDate;
    double        freq;
    char          endMFlg=FALSE;
   	DAY_T         day, d;
   	MONTH_T       m;
   	YEAR_T        y;

    beginDate.date = 0;
    beginDate.time = 0;
	endDate.date = 0;
	endDate.time = 0;
    (*amtToInvest) = 0.0;

    switch (GET_ENUM(planDefStp, A_PlanDefinition_ObjectiveNature))
    {
        case PlanDefObjectiveNat_InvestAmount:
            /*PMSTA - 46093 - lalby - 24082021*/
            if (objectiveStp != nullptr && IS_NULLFLD(objectiveStp, A_PlanObjectiveHisto_AmountNature) == FALSE &&
                GET_ENUM(objectiveStp, A_PlanObjectiveHisto_AmountNature) == PlanObjectiveAmtNat_InvestedPercent &&
                minAmt > 0)
            {
                targetAmt = minAmt;
            }
            else
              targetAmt = GET_AMOUNT(objectiveStp, A_PlanObjectiveHisto_MinAmount); 
 
			/* PMSTA-21782 - DDV - 151130 - Take care of free deposit */           
            if (GET_ENUM(investParamStp, A_PlanInvestParamHisto_UpdAmtToObjective) == PlanInvestParamUpdAmtRule_ReachMinAmt)
                currentAmt = periodCurrentAmt;
            else
                currentAmt = 0.0;

            investNbr = 1;
            break;

        case PlanDefObjectiveNat_PeriodAmount:
        case PlanDefObjectiveNat_GlobalAmount:

            /* compute number of payementr till objective end date */
	        FIN_PeriodUnitNbr((FREQUNIT_ENUM)GET_ENUM(investParamStp, A_PlanInvestParamHisto_InvestFreqUnit),
				                GET_TINYINT(investParamStp, A_PlanInvestParamHisto_InvestFreq), 
				                FreqUnit_Month, &freq);

            if (freq == 0)
            {
	            MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, 
			                    "FIN_ComputeObjectivePeriod", "investment's frequency");
                return(RET_GEN_ERR_INVARG);
            }

	        DATE_Get(endDate.date, (YEAR_T*)NULL, (MONTH_T*)NULL, &day);

	        switch(GET_ENUM(investParamStp, A_PlanInvestParamHisto_EndOfMonthConv))
            {
                case InstrEom_Last:
    	            endMFlg = (char) TRUE;
                    break;
                case InstrEom_Same:
    	            endMFlg = (char) FALSE;
                    break;
                case InstrEom_Last360:
                    if (endMFlg == TRUE)
                        day=30;
    	            endMFlg = (char) FALSE;
                    break;
                default:
                    endMFlg = (char) DATE_IsLastInMonth(endDate.date);
                    break;
            }

            endDate.date = currentDate;
	        while (endDate.date <= objEndDate)
            {
                beginDate.date = endDate.date;
		        endDate.date = DATE_Move(beginDate.date, (int)freq, Month);
		        DATE_VerifyEndMonth(&endDate.date, day, endMFlg);

    	        if (GET_ENUM(investParamStp, A_PlanInvestParamHisto_EndOfMonthConv) == InstrEom_Last360 && day == 30)
                {
                    DATE_Get(endDate.date, &y, &m, &d);
                    if (m == (MONTH_T) 2 && d == (DAY_T) 29)
                    {
                        endDate.date = DATE_Put(y, m, (DAY_T) 28);
                    }
                }
                investNbr++;
	        }

            switch (GET_ENUM(investParamStp, A_PlanInvestParamHisto_UpdAmtToObjective))
            {
                case PlanInvestParamUpdAmtRule_None:
                    if (minAmt != NO_VALUE)
                        targetAmt = minAmt;

                    currentAmt = 0.0;

                    /* add begining if period investments */
                    beginDate.date = currentDate;
                    investNbr--;                        /* current date has already been add, decrease investNbr to have a correct count */
                    while (beginDate.date > objBeginDate)
                    {
                        endDate.date = beginDate.date;
		                beginDate.date = DATE_Move(endDate.date, (int)((-1) * freq), Month);
		                DATE_VerifyEndMonth(&beginDate.date, day, endMFlg);

    	                if (GET_ENUM(investParamStp, A_PlanInvestParamHisto_EndOfMonthConv) == InstrEom_Last360 && day == 30)
                        {
                            DATE_Get(beginDate.date, &y, &m, &d);
                            if (m == (MONTH_T) 2 && d == (DAY_T) 29)
                            {
                                beginDate.date = DATE_Put(y, m, (DAY_T) 28);
                            }
                        }
                        investNbr++;
                    }
                    break;

                case PlanInvestParamUpdAmtRule_ReachMinAmt:
                    if (minAmt != NO_VALUE)
                        targetAmt = minAmt; 
                    else 
                    {
                	    MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "FIN_ComputeAmtToInvest", "min_amt");
                    }
                    currentAmt = periodCurrentAmt;
                    break;

                case PlanInvestParamUpdAmtRule_ReachMaxAmt:
                    if (maxAmt != NO_VALUE)
                        targetAmt = maxAmt;
                    else if (minAmt != NO_VALUE)
                        targetAmt = minAmt;

                    currentAmt = periodCurrentAmt;
                    break;
            }
            break;
    }

    if (investNbr != 0)
        amt = (targetAmt - currentAmt) / investNbr;

    if  (IS_NULLFLD(investParamStp, A_PlanInvestParamHisto_MaxInvestAmt) == FALSE &&
         amt > GET_AMOUNT(investParamStp, A_PlanInvestParamHisto_MaxInvestAmt))
    {
        amt = GET_AMOUNT(investParamStp, A_PlanInvestParamHisto_MaxInvestAmt);
    }

    (*amtToInvest) = amt;

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    : FIN_AddEventExtOpInHier
**
**  Description : 
**
**  Arguments   : 
**
**  Return      : TRUE or FALSE
**
**  Creation    : PMSTA-21265 - DDV - 151015
**
**  Last modif. :
**
*************************************************************************/
STATIC RET_CODE FIN_AddEventExtOpInHier(DBA_DYNFLD_STP         extOpStp,
                                        DICT_T                 fctDictId,
                                        ID_T                   refCurrId,
                                        FUSDATERULE_ENUM	   refFusDateRule,
                                        DBA_DYNFLD_STP	       instrStp,
                                        DBA_HIER_HEAD_STP	   hierHead,
                                        DBA_DYNFLD_STP         flowStp,
                                        DBA_DYNFLD_STP	       domainStp,
                                        DBA_DYNFLD_STP	       ptfStp) 
{
    RET_CODE           ret=RET_SUCCEED;

    if ((fctDictId == DictFct_Journal) && (ExtOpDbStatus_ToInsert == GET_ENUM(extOpStp, ExtOp_DbStatusEn)))
    {
        if ((ret=FIN_SplitExtOpForJrnl(extOpStp,
                                        refCurrId,
                                        refFusDateRule,
                                        instrStp,
                                        hierHead,
                                        flowStp,
                                        domainStp,
                                        ptfStp)) != RET_SUCCEED)
        {
            FREE_DYNST(extOpStp, ExtOp);
            return(ret);
        }
        FREE_DYNST(extOpStp, ExtOp);
    }
    else
    {
        if (DBA_AddHierRecord(hierHead, extOpStp, ExtOp, FALSE, HierAddRec_ForceInsert) != RET_SUCCEED)
        {
            FREE_DYNST(extOpStp, ExtOp);
            return(RET_DBA_ERR_HIER);
        }
    }   

    return (RET_SUCCEED);
}

/************************************************************************
**
**  Function    : FIN_AddCashTransferOpInHier
**
**  Description : 
**
**  Arguments   : 
**
**  Return      : TRUE or FALSE
**
**  Creation    : PMSTA-21265 - DDV - 151015
**
**  Last modif. :
**
*************************************************************************/
STATIC RET_CODE FIN_AddCashTranfertOpInHier(DBA_DYNFLD_STP         opStp,
                                            OPNAT_ENUM             opNatEn,
                                            DBA_HIER_HEAD_STP	   hierHead,
                                            DBA_DYNFLD_STP	       domainStp,
                                            DBA_DYNFLD_STP         *extractFlowPos,
                                            int                    extractFlowPosNbr,
                                            DBA_DYNFLD_STP         *listPtr)
{
    DBA_DYNFLD_STP         extOpStp = NULLDYNST, ptfStp = NULLDYNST, instrStp = NULLDYNST;
    FLAG_T                 allocPtfFlg=FALSE, allocInstrFlg=FALSE, existPosFlg=FALSE;
    RET_CODE               ret=RET_SUCCEED;

    if ((extOpStp = ALLOC_DYNST(ExtOp)) == NULLDYNST)
    { 
        MSG_RETURN(RET_MEM_ERR_ALLOC); 
    }

    if ((ret = OPE_OpToExtOp(opStp, opNatEn, extOpStp, FALSE)) != RET_SUCCEED)
    {
        FREE_DYNST(extOpStp, ExtOp);
        return(ret);
    }

    /* If operation already exist, exit wihtout inserting it into hierarchy */
    FIN_CheckExistPos(extractFlowPos, extractFlowPosNbr, extOpStp, listPtr, domainStp, hierHead, &existPosFlg, FALSE, NULLDYNST, TRUE);

    if (existPosFlg == TRUE) 
    {
        FREE_DYNST(extOpStp, ExtOp);
        return RET_SUCCEED;
    }

    SET_ENUM(extOpStp, ExtOp_DbStatusEn, ExtOpDbStatus_ToInsert);

    if (DBA_GetInstrById(GET_ID(extOpStp, ExtOp_InstrId), TRUE, &allocInstrFlg, &instrStp, hierHead, UNUSED, UNUSED) != RET_SUCCEED)
    {
	    MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "FIN_AddCashTranfertOpInHier", "instrument");
        FREE_DYNST(extOpStp, ExtOp);
        return(RET_GEN_ERR_INVARG);
    }

    if (DBA_GetPtfById(GET_ID(extOpStp, ExtOp_PtfId), TRUE, &allocPtfFlg, &ptfStp, hierHead, UNUSED, UNUSED) != RET_SUCCEED)
    {
	    MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "FIN_AddCashTranfertOpInHier", "portfolio");
        FREE_DYNST(extOpStp, ExtOp);
        if (allocInstrFlg == TRUE) {FREE_DYNST(instrStp, A_Instr);}
        return(RET_GEN_ERR_INVARG);
    }

    if ((ret = FIN_AddEventExtOpInHier(extOpStp, GET_DICT(domainStp, A_Domain_FctDictId), GET_ID(domainStp, A_Domain_CurrId), 
                            (FUSDATERULE_ENUM) GET_ENUM(domainStp, A_Domain_FusDateRuleEn), instrStp, hierHead, NULLDYNST, domainStp, ptfStp)) != RET_SUCCEED)
    {
        if (allocInstrFlg == TRUE) {FREE_DYNST(instrStp, A_Instr);}
        if (allocPtfFlg == TRUE) {FREE_DYNST(ptfStp, A_Ptf);}
        return(ret);
    }

    if (allocInstrFlg == TRUE) {FREE_DYNST(instrStp, A_Instr);}
    if (allocPtfFlg == TRUE) {FREE_DYNST(ptfStp, A_Ptf);}

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    : FIN_LoadPeriodInvestedAmt
**
**  Description : 
**
**  Arguments   : 
**
**  Return      : TRUE or FALSE
**
**  Creation    : PMSTA-21265 - DDV - 151014
**
**  Last modif. : PMSTA-33148 - RAK - 181003
**
*************************************************************************/
STATIC RET_CODE FIN_GenerateWithrawalAndInvestOp(DATETIME_T         investDate,
												 DBA_DYNST_ENUM freeInvestSt,	/* PMSTA - 33148 - RAK - 181003 */
												 DBA_DYNFLD_STP freeInvestStp,	/* PMSTA-33148 - RAK - 181003 */
                                                 ID_T               toPtfId,
                                                 ID_T               toAcctId,
                                                 AMOUNT_T           *amtToInvest,
                                                 OPSTAT_ENUM        statusInput, 
                                                 CODE_T             flowEvtCode, 
                                                 INT_T              flowEvtNbr, 
                                                 DBA_DYNFLD_STP     domainStp,
                                                 DBA_HIER_HEAD_STP  hierHead,
                                                 DBA_DYNFLD_STP     *extractFlowPos,
                                                 int                extractFlowPosNbr,
                                                 DBA_DYNFLD_STP     *listPtr)
{
    DBA_DYNFLD_STP      withdrawalOpStp=nullptr, investOpStp=nullptr;
	FLAG_T				genWithrawalFlg;
    RET_CODE            ret=RET_SUCCEED;

	/* PMSTA-33148 - RAK - 181003 - Don't generate withdrawal */
	if (freeInvestSt == A_FreeDepositHisto && IS_NULLFLD(freeInvestStp, A_FreeDepositHisto_CounterpartAcctC) == FALSE)
		genWithrawalFlg = FALSE;
	else
		genWithrawalFlg = TRUE;

	if (genWithrawalFlg == TRUE)
	{
		/* create Withrawal operation */
		if ((withdrawalOpStp = ALLOC_DYNST(WithdrOp)) == NULLDYNST)
		{
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		DBA_SetDfltEntityFld(WithdrOpEnt, WithdrOp, withdrawalOpStp);

		DBA_ResetGetSetFlg(withdrawalOpStp, WithdrOp);

		if (freeInvestSt == A_FreeDepositHisto)
		{
			SET_ID(withdrawalOpStp, WithdrOp_PtfId, GET_ID(freeInvestStp, A_FreeDepositHisto_TransferFromPortfolioId));
			SET_ID(withdrawalOpStp, WithdrOp_InstrId, GET_ID(freeInvestStp, A_FreeDepositHisto_TransferFromAcctId));
		}
		else
		{
			SET_ID(withdrawalOpStp, WithdrOp_PtfId, GET_ID(freeInvestStp, A_PlanInvestParamHisto_TransferFromPortfolioId));
			SET_ID(withdrawalOpStp, WithdrOp_InstrId, GET_ID(freeInvestStp, A_PlanInvestParamHisto_TransferFromAcctId));
		}

		SET_DATETIME(withdrawalOpStp, WithdrOp_AcctDate, investDate);
		SET_AMOUNT(withdrawalOpStp, WithdrOp_OpGrossAmt, (*amtToInvest));
		SET_NUMBER(withdrawalOpStp, WithdrOp_Qty, (*amtToInvest));
		SET_ENUM(withdrawalOpStp, WithdrOp_StatusEn, statusInput);
		SET_CODE(withdrawalOpStp, WithdrOp_EvtCd, flowEvtCode);
		SET_NUMBER(withdrawalOpStp, WithdrOp_EvtNbr, (NUMBER_T)flowEvtNbr);
		SET_FLAG(withdrawalOpStp, WithdrOp_ConfirmedFlg, TRUE)

		/* ComputeDV */
		SCPT_ComputeScreenDV(WithdrOpEnt,
							DictFct_0,
							NULL, /* pflagScpt, */
							NULL,              /* HFI-PMSTA-25327-171023  Dedicated flag tab for filter    */
							withdrawalOpStp,
							NULL,
							NULLDYNST,
							NULLDYNST,
							TRUE,	            /* analyse type (all)*/
							TRUE,				/* guiFlag */
							EvalType_DefVal,
							0,					/* attribIdx */
							NULL,              /* connectNo */
							NULL,				/* filterTab */
							NULL,	            /* hierHead */
							0,
							DictScreen,
							NULL,
							NULL,
							NULL,
							NULL,
							NULL,
							NullEntity,
							FALSE,
							FALSE,
							0);
	}


    /* create Investement operation */
    if ((investOpStp = ALLOC_DYNST(InvestOp)) == NULLDYNST)
    { 
        FREE_DYNST(withdrawalOpStp, WithdrOp);
        MSG_RETURN(RET_MEM_ERR_ALLOC); 
    }

    DBA_SetDfltEntityFld(InvestOpEnt, InvestOp, investOpStp);

	DBA_ResetGetSetFlg(investOpStp, InvestOp);

    SET_ID(investOpStp,			InvestOp_PtfId,			toPtfId);
    SET_ID(investOpStp,			InvestOp_InstrId,		toAcctId);
    SET_DATETIME(investOpStp,	InvestOp_AcctDate,		investDate);
    SET_AMOUNT(investOpStp,		InvestOp_OpGrossAmt,	(*amtToInvest));
    SET_NUMBER(investOpStp,		InvestOp_Qty,			(*amtToInvest));
    SET_ENUM(investOpStp,		InvestOp_StatusEn,		statusInput);
    SET_CODE(investOpStp,		InvestOp_EvtCd,			flowEvtCode);
    SET_NUMBER(investOpStp,		InvestOp_EvtNbr,		(NUMBER_T) flowEvtNbr);
	SET_FLAG(investOpStp,		InvestOp_ConfirmedFlg,	TRUE);

	/* PMSTA-33148 - RAK - 181003 - Don't generate withdrawal */
	if (freeInvestSt == A_FreeDepositHisto && IS_NULLFLD(freeInvestStp, A_FreeDepositHisto_CounterpartAcctC) == FALSE)
	{
		COPY_DYNFLD(investOpStp, InvestOp, InvestOp_CounterpartAccount, freeInvestStp, A_FreeDepositHisto, A_FreeDepositHisto_CounterpartAcctC);
		COPY_DYNFLD(investOpStp, InvestOp, InvestOp_CounterpartCurrencyId, freeInvestStp, A_FreeDepositHisto, A_FreeDepositHisto_CurrId);
	}

    /* ComputeDV */
    SCPT_ComputeScreenDV(InvestOpEnt,
                         DictFct_0,
                         NULL, /* pflagScpt, */
                         NULL,              /* HFI-PMSTA-25327-171023  Dedicated flag tab for filter    */
						 investOpStp,
                         NULL,
                         NULLDYNST,
                         NULLDYNST,
                         TRUE,	            /* analyse type (all)*/
                         TRUE,				/* guiFlag */
                         EvalType_DefVal, 
                         0,					/* attribIdx */
                         NULL,              /* connectNo */
                         NULL,				/* filterTab */
                         NULL,	            /* hierHead */
                         0,
                         DictScreen,      
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NullEntity,
                         FALSE,
                         FALSE,
                         0);     

    /* convert operations to ExtOp (or ExtPos for jurnal) and add them into hierarchy */
	/* PMSTA-33148 - RAK - 181003 Don't generate withdrawal */
	if (genWithrawalFlg == TRUE)
	{
		if ((ret = FIN_AddCashTranfertOpInHier(withdrawalOpStp, OpNat_Withdr, hierHead, domainStp,
			                                   extractFlowPos, extractFlowPosNbr, listPtr)) != RET_SUCCEED)
		{
			FREE_DYNST(withdrawalOpStp, WithdrOp);
			FREE_DYNST(investOpStp, InvestOp);
			MSG_RETURN(ret);
		}

		FREE_DYNST(withdrawalOpStp, WithdrOp);
    }

    if ((ret = FIN_AddCashTranfertOpInHier(investOpStp, OpNat_Invest, hierHead, domainStp, 
                                           extractFlowPos, extractFlowPosNbr, listPtr)) != RET_SUCCEED)
    { 
        FREE_DYNST(withdrawalOpStp, WithdrOp);
        FREE_DYNST(investOpStp, InvestOp);
        MSG_RETURN(ret); 
    }

    FREE_DYNST(investOpStp, InvestOp);
    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    : FIN_UpdStandingInstructArray()
**
**  Description : 
**
**  Arguments   : 
**                
**
**  Return      : TRUE or FALSE
**
**  Creation    : PMSTA-21265 - DDV - 151016
**
**  Last modif. :
**
*************************************************************************/
STATIC RET_CODE FIN_UpdStandingInstructArray(DBA_DYNFLD_STP	   planDefStp,
                                             DBA_DYNFLD_STP    investParamStp,
                                             DATETIME_T        investDatetime,
                                             AMOUNT_T          amtToInvest, 
											 INT_T			   flowEvtNbr,
                                             AMOUNT_T          *remainAmt, 
                                             DBA_DYNFLD_STP    **standInstructArray,
                                             int               *standInstructNbr,
                                             DBA_HIER_HEAD_STP hierHead)
{
    DBA_DYNFLD_STP           *allArray=NULLDYNSTPTR, *newArray=NULLDYNSTPTR;
    DBA_DYNFLD_STP           planCashAcctStp = NULLDYNST;
    int                      allNbr=0, newNbr=0, i=0, biggestWeightPos=0;
    DATETIME_T               endDate;
    PERCENT_T                totalWeight= 0.0, biggestWeight=0.0;
    AMOUNT_T                 totAmt = 0.0, amt=0.0, reservedAmt=0.0, newAmtToInvest=0.0;
    FLAG_T                   allocInstrFlg=FALSE;
    STANDINSTRUCTSTATUS_ENUM status;
    MemoryPool               mpLocal;    
    MemoryPool               mpCaller;

	GEN_GetApplInfo(ApplStandingInstructionExecStatEn, &status);

    endDate.time = 0;

    (*standInstructArray) = NULLDYNSTPTR;
    (*standInstructNbr) = 0;

    if (DBA_GetInstrById(GET_ID(investParamStp, A_PlanInvestParamHisto_InvestAcctId), TRUE, &allocInstrFlg, &planCashAcctStp, hierHead, UNUSED, UNUSED) != RET_SUCCEED)
    {
	    MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "FIN_UpdStandingInstructArray", "instrument");
        return(RET_GEN_ERR_INVARG);
    }

    if(allocInstrFlg == TRUE)
    {
        mpLocal.ownerDynStp(planCashAcctStp);
    }

	/* Find objective to use at this date                                                                                 */
    if (GET_EXTENSION_PTR(planDefStp, A_PlanDefinition_StandInstruct_Ext) != NULL)
    {
        allArray = GET_EXTENSION_PTR(planDefStp, A_PlanDefinition_StandInstruct_Ext);
        allNbr = GET_EXTENSION_NBR(planDefStp, A_PlanDefinition_StandInstruct_Ext);
    }
		
    if (allNbr > 0)
    {
		/*Sorting orders as per weight - PMSTA - 46225 - Lekshmi */
		TLS_Sort((char*)(allArray), (unsigned)allNbr, sizeof(DBA_DYNFLD_STP),
			(TLS_CMPFCT *)FIN_CmpStandInstructWeight, NULL, SortRtnTp_None);

        newArray = (DBA_DYNFLD_STP *) mpCaller.calloc(allNbr, sizeof(DBA_DYNFLD_STP));

        /* build a new array containing only valid standing instructions */
        for (i=0; i < allNbr; i++)
        {
            /* on never used standing instruction, reset op amt to avoid wrong reserved cash */
            if (IS_NULLFLD(allArray[i], A_StandInstruct_LastEvntGenDate) == TRUE &&
                GET_FLAG(allArray[i], A_StandInstruct_UpdGenDateFlg) == FALSE)
            {
                SET_AMOUNT(allArray[i], A_StandInstruct_OpAmt, 0.0);
            }

            /* keep only buy operation */
            if (GET_ENUM(allArray[i], A_StandInstruct_StatusEn) >= status &&
                DATETIME_CMP(GET_DATETIME(allArray[i], A_StandInstruct_BegDate), investDatetime) <= 0 &&
                (IS_NULLFLD(allArray[i], A_StandInstruct_EndDate) == TRUE ||
                 DATETIME_CMP(GET_DATETIME(allArray[i], A_StandInstruct_EndDate), investDatetime) > 0) &&
                GET_ENUM(allArray[i], A_StandInstruct_OpNatEn) == OpNat_Buy)
            {
                newArray[newNbr] = mpCaller.allocDynst(FILEINFO, A_StandInstruct);

                COPY_DYNST(newArray[newNbr], allArray[i], A_StandInstruct);

                totalWeight += GET_PERCENT(newArray[newNbr], A_StandInstruct_Weight);

                if (GET_AMOUNT(newArray[newNbr], A_StandInstruct_OpAmt) > 0.0)
                    reservedAmt += GET_AMOUNT(newArray[newNbr], A_StandInstruct_OpAmt);

                if (GET_PERCENT(newArray[newNbr], A_StandInstruct_Weight) > biggestWeight)
                {
                    biggestWeight = GET_PERCENT(newArray[newNbr], A_StandInstruct_Weight);
                    biggestWeightPos = newNbr;
                }

                newNbr++;
            }
        }

        /* if total weight is not 100%, it's an error, exit */
        if (CMP_PERCENT(totalWeight, 100.0) != 0)
        {
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 6, FILEINFO,  "Total of standing instruction weight is not 100% for investment plan: ", GET_CODE(planDefStp, A_PlanDefinition_Cd));
            return(RET_GEN_ERR_INVARG); /* PMSTA-21859 - DDV - 151202 */
        }
        else
        {
			/* flowEvtNbr = FIN_CalcEvtNbr(investDatetime.date);  PMSTA - 28294 - RAK - 171123 */
	        
        	endDate.date = DATE_Move(investDatetime.date, (int)1, Day);

            newAmtToInvest = amtToInvest;

            if ((*remainAmt) > reservedAmt)
                newAmtToInvest += (*remainAmt) - reservedAmt;

            for (i=0; i < newNbr; i++)
            {
                /* skip biggest weight, it will be treated later */
                if (i == biggestWeightPos)
                    continue;

                amt = (GET_PERCENT(newArray[i], A_StandInstruct_Weight) / 100.0) * newAmtToInvest;

                if (GET_AMOUNT(newArray[i], A_StandInstruct_OpAmt) > 0.0)
                    amt += GET_AMOUNT(newArray[i], A_StandInstruct_OpAmt);

				/* PMSTA-30421-RAK-180305 - Systematic Plan use Plan currency for order generation (StandinInstruct COPY_DYNST done upper)  */
				if (GET_ENUM(planDefStp, A_PlanDefinition_Nature) != PlanDefNat_SystematicInvestPlan)
				{
					CAST_AMOUNT(amt, GET_ID(planCashAcctStp, A_Instr_RefCurrId));
					SET_ID(newArray[i], A_StandInstruct_OpAmtCurrId, GET_ID(planCashAcctStp, A_Instr_RefCurrId));
				}
                SET_AMOUNT(newArray[i], A_StandInstruct_OpAmt, amt);
                
                SET_DATETIME(newArray[i], A_StandInstruct_BegDate, investDatetime);
                SET_DATETIME(newArray[i], A_StandInstruct_EndDate, endDate);
                SET_INT(newArray[i], A_StandInstruct_FlowEvtNbr, flowEvtNbr);
                totAmt += amt;
            }

            /* treat biggest weight alloc it remaining amt */
            amt = newAmtToInvest + reservedAmt - totAmt;

            /* already added included in reservedAmt
            if (GET_AMOUNT(newArray[biggestWeightPos], A_StandInstruct_OpAmt) > 0.0)
                amt += GET_AMOUNT(newArray[biggestWeightPos], A_StandInstruct_OpAmt);
            */

			/* PMSTA-30421-RAK-180305 - Systematic Plan use Plan currency for order generation (StandinInstruct COPY_DYNST done upper)  */
			if (GET_ENUM(planDefStp, A_PlanDefinition_Nature) != PlanDefNat_SystematicInvestPlan)
			{
				CAST_AMOUNT(amt, GET_ID(planCashAcctStp, A_Instr_RefCurrId));
				SET_ID(newArray[biggestWeightPos], A_StandInstruct_OpAmtCurrId, GET_ID(planCashAcctStp, A_Instr_RefCurrId));
			}
            SET_AMOUNT(newArray[biggestWeightPos], A_StandInstruct_OpAmt, amt);

            SET_DATETIME(newArray[biggestWeightPos], A_StandInstruct_BegDate, investDatetime);
            SET_DATETIME(newArray[biggestWeightPos], A_StandInstruct_EndDate, endDate);
            SET_INT(newArray[biggestWeightPos], A_StandInstruct_FlowEvtNbr, flowEvtNbr);
            totAmt += amt;
        }
    }
  
    (*standInstructArray) = newArray;
    (*standInstructNbr) = newNbr;
    (*remainAmt) = amtToInvest + (*remainAmt) - totAmt;    
     mpCaller.removeAll();

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    : DBA_LoadCashPos()
**
**  Description : 
**
**  Arguments   : 
**                
**
**  Return      : TRUE or FALSE
**
**  Creation    : PMSTA-21265 - DDV - 151109
**
**  Last modif. :
**
*************************************************************************/
STATIC RET_CODE DBA_LoadCashPos(ID_T            ptfId,
                                ID_T            cashAcctId,
                                DATETIME_T      datetime,                                
                                AMOUNT_T        *cashAmt)
{
    DBA_DYNFLD_STP           getArgStp, *posArray;
    int                      posNbr, i;
    RET_CODE                 ret = RET_SUCCEED;

    (*cashAmt) = 0.0;

    if ((getArgStp = ALLOC_DYNST(Get_Arg)) == NULLDYNST)
    { 
        MSG_RETURN(RET_MEM_ERR_ALLOC); 
    }

    SET_ID(getArgStp, Get_Arg_Id, ptfId);
    SET_ID(getArgStp, Get_Arg_ObjId, cashAcctId);
    SET_DATETIME(getArgStp, Get_Arg_DateTime, datetime);

    if ((ret = DBA_Select2(EPos, UNUSED, Get_Arg, getArgStp, ExtPos, &posArray, UNUSED, UNUSED, &posNbr, UNUSED, UNUSED)) == RET_SUCCEED)
    {
        for (i=0; i < posNbr; i++)
        {
            (*cashAmt) += GET_AMOUNT(posArray[i], ExtPos_InstrGrossAmt);
        }
        DBA_FreeDynStTab(posArray, posNbr, ExtPos);
    }

    FREE_DYNST(getArgStp, Get_Arg);
    return(RET_SUCCEED);
}

STATIC int FIN_FilterEventExtPos(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP getArgPtr)
{
	/* REF3641 - strat focus elements need same treatment than reconcil elements */
	if (CMP_DYNFLD(dynSt, getArgPtr, ExtPos_PtfId,   Get_Arg_PtfId, IdType) == 0 &&
		CMP_DYNFLD(dynSt, getArgPtr, ExtPos_InstrId, Get_Arg_InstrId, IdType) == 0 &&
		CMP_DYNFLD(dynSt, getArgPtr, ExtPos_EvtCd,   Get_Arg_Cd, CodeType) == 0 &&
		CMP_DYNFLD(dynSt, getArgPtr, ExtPos_EvtNbr,  Get_Arg_Number, NumberType) == 0 &&
		CMP_DYNFLD(dynSt, getArgPtr, ExtPos_StatEn,  Get_Arg_Enum1, EnumType) >= 0)
		return(TRUE);

	return(FALSE);
}

STATIC int FIN_FilterEventExtPosNI(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP getArgPtr)
{
	if (CMP_DYNFLD(dynSt, getArgPtr, ExtPos_PtfId, Get_Arg_PtfId, IdType) == 0 &&
		CMP_DYNFLD(dynSt, getArgPtr, ExtPos_InstrId, Get_Arg_InstrId, IdType) == 0 &&
		CMP_DYNFLD(dynSt, getArgPtr, ExtPos_EvtNbr, Get_Arg_Number, NumberType) == 0 &&
		CMP_DYNFLD(dynSt, getArgPtr, ExtPos_StatEn, Get_Arg_Enum1, EnumType) >= 0)
		return(TRUE);

	return(FALSE);
}

/************************************************************************
**
**  Function    : FIN_CheckExistEventPos()
**
**  Description : Verify if a position with same received ptf, instr, event_code, event_number 
**                already exists with a minimum status > domain minimum status
**
**  Arguments   : 
**
**  Return      : TRUE or FALSE
**
**  Creation    : PMSTA28294 - RAK - 171114
**
**  Last modif. :
**
*************************************************************************/
STATIC RET_CODE FIN_CheckExistEventPos(DBA_HIER_HEAD_STP hierPtr, 
	                                   DBA_DYNFLD_STP domainPtr, DBA_DYNFLD_STP standInstructPtr, 
									   NUMBER_T eventNbr, FLAG_T *existFlg)
{
	int				extPosNbr=0;
	DBA_DYNFLD_STP	*extPosTab = nullptr, getArgPtr = nullptr;
	RET_CODE		ret;
	DbiConnectionHelper dbiConnHelper(AAATransactionEnum::NotTransactionnal);

	*existFlg = FALSE;
	
	if ((getArgPtr = ALLOC_DYNST(Get_Arg)) == NULLDYNST)
	{ MSG_RETURN(RET_MEM_ERR_ALLOC);}

	SET_ID(getArgPtr,       Get_Arg_Id, GET_ID(standInstructPtr, A_StandInstruct_PtfId)); /*PMSTA46781 - 26102021 - HLA */
	SET_ID(getArgPtr,       Get_Arg_PtfId,		GET_ID(standInstructPtr, A_StandInstruct_PtfId));
	SET_ID(getArgPtr,		Get_Arg_InstrId,	GET_ID(standInstructPtr, A_StandInstruct_InstrId));
	SET_CODE(getArgPtr,		Get_Arg_Cd,			GET_CODE(standInstructPtr, A_StandInstruct_Cd));
	SET_NUMBER(getArgPtr,	Get_Arg_Number,		eventNbr); 
	SET_ENUM(getArgPtr,		Get_Arg_Enum1,		GET_ENUM(domainPtr, A_Domain_MinStatEn));
	
	if ((ret = DBA_ExtractHierEltRecWithFilterSt(hierPtr, ExtPos, FALSE,
		FIN_FilterEventExtPos, getArgPtr,
		NULLFCT, &extPosNbr, &extPosTab)) != RET_SUCCEED)
	{
		FREE_DYNST(getArgPtr, Get_Arg);
		return(ret);
	}

	if (extPosNbr == 0)
	{
		/* select in database GetArgPtr */
		if ((ret = dbiConnHelper.dbaSelect(EPos, DBA_ROLE_EXIST_EVT_POS, getArgPtr, ExtPos, &extPosTab, &extPosNbr)) != RET_SUCCEED)		
		{
			FREE_DYNST(getArgPtr, Get_Arg);
			return ret;
		}
	}

	if (extPosNbr > 0)
		*existFlg = TRUE;

	FREE_DYNST(getArgPtr, Get_Arg);
	if (extPosTab) { FREE(extPosTab); }
	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    : FIN_CalcEvtNbr()
**
**  Description : According to received date, compute an event number
**	
**
**  Arguments   : DATETIME_T : date
**
**  Return      : the flow event number
**
**  Creation    : PMSTA28294 - RAK - 171114
**
**  Last modif. :
**
*************************************************************************/
STATIC INT_T FIN_CalcEvtNbr(DATE_T flowDate)
{
	INT_T            flowEvtNbr;
	DAY_T               d;
	MONTH_T             m;
	YEAR_T              y;
	
	DATE_Get(flowDate, &y, &m, &d);
	flowEvtNbr = y * 10000 + m * 100 + d;
	return(flowEvtNbr);
}

/************************************************************************
**
**  Function    : FIN_ManageOneInvestPlan()
**
**  Description : Manage one ivestment plan. This function will compute the amopunt to invest. 
**                Manage cash if needed. Update satnding instructions and generate flows and operations.
**
**  Arguments   : dynSt     : pointer on a dynamic structure
**                dynStTp   : dynamic structure type
**
**  Return      : TRUE or FALSE
**
**  Creation    : PMSTA-21265 - DDV - 151008
**
**  Last modif. :
**
*************************************************************************/
STATIC RET_CODE FIN_ManageOneInvestPlan(DBA_DYNFLD_STP     domainStp,
                                        DBA_HIER_HEAD_STP  hierHead,
                                        DBA_DYNFLD_STP     *extractFlowPos,
                                        int                extractFlowPosNbr,
                                        DBA_DYNFLD_STP     *listPtr,
                                        FLAG_T             standInstructBuyFlg,
                                        FLAG_T             standInstructSellFlg,
                                        DBA_DYNFLD_STP     planDefStp,
                                        DBA_DYNFLD_STP     *investDateArray,
                                        int                investDateNbr)
{
	DATE_T              fromD=0, tillD=0, objBeginDate=0, objEndDate=0;
	DBA_DYNFLD_STP      objectiveStp=NULLDYNST, investParamStp=NULLDYNST, planRuleHistoStp=NULLDYNST, 
                        prevObjectiveStp=NULLDYNST, prevInvestParamStp=NULLDYNST, freeDepoStp=NULLDYNST,
                        tmpStandInstructStp=NULLDYNST, hierStandInstructStp=NULLDYNST;
    DBA_DYNFLD_STP      *standInstructArray = NULLDYNSTPTR;
    DBA_DYNFLD_STP      *flowTab = NULLDYNSTPTR, *extOpTab = NULLDYNSTPTR;
    int                 i=0, j=0, standInstructNbr=0, flowNbr=0, extOpNbr=0, connectNo;
    AMOUNT_T            minAmt=0.0, maxAmt=0.0, minAmtIndexed=0.0, maxAmtIndexed=0.0, srcCashAmt = 0.0, planCashAmt = 0.0, 
                        periodCurrentAmt=0.0, amtToInvest=0.0, remainAmt=0.0, cashAmt = 0.0, freeSrcCashAmt=0.0, ruleMaxAmt=NO_VALUE;
    OPSTAT_ENUM         opStatus; 
    ID_T                planRuleHistoId=0, prevPlanRuleHistoId=0;
    INT_T               flowEvtNbr;
	FLAG_T              indexMinAmtFlg = FALSE, indexMaxAmtFlg = FALSE, updAmtFlg = FALSE;
    MemoryPool          mp;

	if (GET_ID(domainStp, A_Domain_FctDictId) == DictFct_EventGeneration) 
    {
		opStatus = (OPSTAT_ENUM) GET_ENUM(domainStp, A_Domain_EvtOperStatEn);
    }
	else
		GEN_GetApplInfo(ApplJournalFlowStatus, &opStatus);


    if (investDateNbr <= 0 || investDateArray == NULLDYNSTPTR)
        return(RET_SUCCEED);

    if (planDefStp == NULLDYNST)
    {
	    MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, 
			         "FIN_ManageOneInvestPlan", "plan defintion");
        return(RET_GEN_ERR_INVARG);
    }

    fromD = GET_DATETIME(domainStp, A_Domain_InterpFromDate).date;
    tillD = GET_DATETIME(domainStp, A_Domain_InterpTillDate).date;


    /* reset all db status to UpToDate */
    for (i=0; i < investDateNbr ; i++)
    {
        SET_ENUM(investDateArray[i], A_PlanInvestDate_DbActionEn, ExtOpActionEn_ToInsert);
    }

	/* For each date : */
	flowEvtNbr = 0;

    for (i=0; i < investDateNbr ; i++)
    {
		flowEvtNbr = GET_INT(investDateArray[i], A_PlanInvestDate_EventNumber);	/* PMSTA28294 - RAK - 171114 */

        if (GET_FLAG(investDateArray[i], A_PlanInvestDate_ValidFlag) == FALSE ||
            GET_ENUM(investDateArray[i], A_PlanInvestDate_Status) == PlanInvestDateStatus_Cancelled ||
            fromD > GET_DATETIME(investDateArray[i], A_PlanInvestDate_InvestmentDate).date ||
            tillD <= GET_DATETIME(investDateArray[i], A_PlanInvestDate_InvestmentDate).date)
            continue;

		/* < PMSTA28294 - RAK - 171207 - Keep std treatment */
		if (GET_ENUM(planDefStp, A_PlanDefinition_Nature) != PlanDefNat_SystematicInvestPlan)
		{
			 if (GET_ENUM(investDateArray[i], A_PlanInvestDate_Status) != PlanInvestDateStatus_Treated)
        	 {
	            SET_ENUM(investDateArray[i], A_PlanInvestDate_DbActionEn, ExtOpActionEn_ToUpdate);
	            SET_ENUM(investDateArray[i], A_PlanInvestDate_Status, PlanInvestDateStatus_Treated);
			 }
        }
		else
		{
			if (GET_ENUM(investDateArray[i], A_PlanInvestDate_Status) != PlanInvestDateStatus_Treated &&
				GET_ENUM(investDateArray[i], A_PlanInvestDate_Status) != PlanInvestDateStatus_Failed &&
				GET_ENUM(investDateArray[i], A_PlanInvestDate_Status) != PlanInvestDateStatus_Success &&
				GET_ENUM(investDateArray[i], A_PlanInvestDate_Status) != PlanInvestDateStatus_RetryFailed &&
				GET_ENUM(investDateArray[i], A_PlanInvestDate_Status) != PlanInvestDateStatus_RetrySuccess)
	        {
				/* PMSTA-29806 - RAK - 180115 - In "simulation" leave the event to untreated */
				if (GET_ENUM(domainStp, A_Domain_EvtGenNatEn) != EvtGen_CreateSessionAndCheck)
				{
					if (GET_ENUM(investDateArray[i], A_PlanInvestDate_Status) == PlanInvestDateStatus_RetryCandidate)
					{
						SET_ENUM(investDateArray[i], A_PlanInvestDate_DbActionEn, ExtOpActionEn_ToUpdate);
						SET_ENUM(investDateArray[i], A_PlanInvestDate_Status, PlanInvestDateStatus_RetryTreated);
					}
					else
					{
						SET_ENUM(investDateArray[i], A_PlanInvestDate_DbActionEn, ExtOpActionEn_ToUpdate);
						SET_ENUM(investDateArray[i], A_PlanInvestDate_Status, PlanInvestDateStatus_Treated);
					}
				}
	        }
		}
		/* PMSTA28294 - RAK - 171207 > */

        FIN_GetPlanRecordsByDate(GET_DATETIME(investDateArray[i], A_PlanInvestDate_InvestmentDate), planDefStp, 
                                 &objectiveStp, &planRuleHistoStp, &investParamStp);

        /* PMSTA-21993 - DDV - 160302 - If no objective find skip date to avoid crash */
        if (objectiveStp == NULLDYNST)
            continue;

        if (planRuleHistoStp != NULLDYNST)
            planRuleHistoId = GET_ID(planRuleHistoStp, A_PlanRuleHisto_Id);

        updAmtFlg=FALSE;

	    /* Compute min and max amount based on objective and rule.                                                            */
        if (i == 0 || planRuleHistoId != prevPlanRuleHistoId || objectiveStp != prevObjectiveStp)
        {

            if (IS_NULLFLD(objectiveStp, A_PlanObjectiveHisto_AmountNature) == FALSE &&              /* PMSTA-46093 - lalby - 11082021 */
                GET_ENUM(objectiveStp, A_PlanObjectiveHisto_AmountNature) == PlanObjectiveAmtNat_InvestedPercent)
            {
                bool calculateMvFlag = (i == 0) ? TRUE : FALSE;
                FIN_ComputeMinMaxAmtWithPercentage(domainStp, hierHead, planDefStp,
                    planRuleHistoStp, objectiveStp, &minAmt, &maxAmt, &indexMinAmtFlg, &indexMaxAmtFlg, &ruleMaxAmt, calculateMvFlag);
            }
            else
            {
                FIN_ComputeMinMaxAmt(planRuleHistoStp, objectiveStp, &minAmt, &maxAmt, &indexMinAmtFlg, &indexMaxAmtFlg, &ruleMaxAmt);
            }
            maxAmtIndexed = maxAmt; /* PMSTA-21988 - DDV - 151222 */
            minAmtIndexed = minAmt; /* PMSTA-21988 - DDV - 151222 */
            updAmtFlg=TRUE;
        }

        /* if it is a new period or new objective, reset currentAmt to zero */
        if (GET_ENUM(planDefStp, A_PlanDefinition_ObjectiveNature) == PlanDefObjectiveNat_PeriodAmount &&
            (GET_DATETIME(investDateArray[i], A_PlanInvestDate_InvestmentDate).date > objEndDate ||
             objectiveStp != prevObjectiveStp || 
             (updAmtFlg == TRUE && (indexMinAmtFlg == TRUE || indexMaxAmtFlg == TRUE ))
            )
           )
        {

            if (FIN_ComputeObjectivePeriod(GET_DATETIME(investDateArray[i], A_PlanInvestDate_InvestmentDate).date, objectiveStp, planRuleHistoStp, &objBeginDate, &objEndDate, 
                                           minAmt, maxAmt, indexMinAmtFlg, indexMaxAmtFlg, &minAmtIndexed, &maxAmtIndexed, ruleMaxAmt) != RET_SUCCEED)
                continue;

            periodCurrentAmt = 0.0;
        }

        if (GET_ENUM(planDefStp, A_PlanDefinition_ObjectiveNature) == PlanDefObjectiveNat_GlobalAmount &&
            objectiveStp != prevObjectiveStp)
        {
            objEndDate = GET_DATETIME(objectiveStp, A_PlanObjectiveHisto_ObjectiveDate).date;
        }

	    /* On first record in planInvestDateArray :                                                                           */
        if (i == 0 &&
            (GET_ENUM(planDefStp, A_PlanDefinition_ObjectiveNature) == PlanDefObjectiveNat_PeriodAmount ||
             GET_ENUM(planDefStp, A_PlanDefinition_ObjectiveNature) == PlanDefObjectiveNat_GlobalAmount))
        {
            if (GET_ENUM(planDefStp, A_PlanDefinition_ObjectiveNature) == PlanDefObjectiveNat_GlobalAmount)
            {
                objBeginDate = GET_DATETIME(planDefStp, A_PlanDefinition_CreationDate).date;
                objEndDate = GET_DATETIME(objectiveStp, A_PlanObjectiveHisto_ObjectiveDate).date;
            }

	        /* Depending of objective definition, load current situation(to be detailed later).                                   */
            switch(GET_ENUM(objectiveStp, A_PlanObjectiveHisto_AmountNature))
            {
                case PlanObjectiveAmtNat_InvestedAmount:
                case PlanObjectiveAmtNat_InvestedPercent:
                    FIN_LoadPeriodInvestedAmt(planDefStp, investParamStp, objBeginDate, GET_DATETIME(investDateArray[i], A_PlanInvestDate_InvestmentDate).date, &periodCurrentAmt);
                    break;

                case PlanObjectiveAmtNat_MarketValue:
                    /*FIN_LoadPeriodInvestedAmt(&periodCurrentAmt); Not in 10.0.0 scope will be develop later */
                    break;
                default:
                    break;
            }
            
	        /* Depending of upd_amt_to_cash_e and gen_cash_op_f load available cash and src available cash (to be detailed later). */
            if (GET_ENUM(investParamStp, A_PlanInvestParamHisto_UpdAmtToCash) == PlanInvestParamCashRule_SkipInvest ||
                GET_ENUM(investParamStp, A_PlanInvestParamHisto_UpdAmtToCash) == PlanInvestParamCashRule_InvestAllCash)
            {
                DBA_LoadCashPos(GET_ID(planDefStp, A_PlanDefinition_PortfolioId), GET_ID(investParamStp, A_PlanInvestParamHisto_InvestAcctId), 
                                GET_DATETIME(investDateArray[i], A_PlanInvestDate_InvestmentDate), &planCashAmt);

                if (GET_FLAG(investParamStp, A_PlanInvestParamHisto_GenCashOp) == TRUE)
                {
                    DBA_LoadCashPos(GET_ID(planDefStp, A_PlanInvestParamHisto_TransferFromPortfolioId), GET_ID(investParamStp, A_PlanInvestParamHisto_TransferFromAcctId), 
                                    GET_DATETIME(investDateArray[i], A_PlanInvestDate_InvestmentDate), &srcCashAmt);
                }
            }
        }

	    /* If it is a free deposit                                                                                            */
        if (IS_NULLFLD(investDateArray[i], A_PlanInvestDate_FreeDepositHistoId) == FALSE)
        {
            amtToInvest = 0.0;

            if (DBA_GetRecPtrFromHierById(hierHead, GET_ID(investDateArray[i], A_PlanInvestDate_FreeDepositHistoId), A_FreeDepositHisto, &freeDepoStp) == RET_SUCCEED)
            {
                amtToInvest = GET_AMOUNT(freeDepoStp, A_FreeDepositHisto_Amount);

	            /* If actual situation + free_invest > max amount, adapt free invest amount                                           */
                if (maxAmt != NO_VALUE && (periodCurrentAmt + amtToInvest) > maxAmt)
                    amtToInvest = maxAmt - periodCurrentAmt;

                if (IS_NULLFLD(freeDepoStp, A_FreeDepositHisto_TransferFromAcctId) == FALSE)
                {
	                /* If free depo is on first date, manage available cash. */
                    if (CMP_DYNFLD(investDateArray[i], investDateArray[0], A_PlanInvestDate_InvestmentDate, A_PlanInvestDate_InvestmentDate, DatetimeType) == 0)
                    {
                        if (CMP_DYNFLD(freeDepoStp, investParamStp, A_FreeDepositHisto_TransferFromAcctId, A_PlanInvestParamHisto_TransferFromAcctId, IdType) == 0 &&
                            CMP_DYNFLD(freeDepoStp, investParamStp, A_FreeDepositHisto_TransferFromPortfolioId, A_PlanInvestParamHisto_TransferFromPortfolioId, IdType) == 0)
                        {
                            freeSrcCashAmt = srcCashAmt;
                        }
                        else
                        {
                            DBA_LoadCashPos(GET_ID(freeDepoStp, A_FreeDepositHisto_TransferFromPortfolioId), GET_ID(freeDepoStp, A_FreeDepositHisto_TransferFromAcctId), 
                                            GET_DATETIME(investDateArray[i], A_PlanInvestDate_InvestmentDate), &freeSrcCashAmt);
                        }

	                    /* Adapt amt to invest regarding upd_amt_to_cash_e and available cash.                                                */
                        if (amtToInvest > freeSrcCashAmt)
                        {
                            switch (GET_ENUM(investParamStp, A_PlanInvestParamHisto_UpdAmtToCash))
                            {
                                case PlanInvestParamCashRule_SkipInvest:
                                    amtToInvest = 0.0;
                                    break;
    
                                case PlanInvestParamCashRule_InvestAllCash:
                                    amtToInvest = freeSrcCashAmt;
                                    break;

                                case PlanInvestParamCashRule_AlwaysInvest:
                                default:
                                    break;
                            }
                        }
                    }

                    if (amtToInvest > 0.0)
                    {
	                    /* If first free invest from cash account is the same than current invest plan cash account, decrease src available cash. */
                        if (CMP_DYNFLD(investDateArray[i], investDateArray[0], A_PlanInvestDate_InvestmentDate, A_PlanInvestDate_InvestmentDate, DatetimeType) == 0)
                        {
                            if (CMP_DYNFLD(freeDepoStp, investParamStp, A_FreeDepositHisto_TransferFromAcctId, A_PlanInvestParamHisto_TransferFromAcctId, IdType) == 0 &&
                                CMP_DYNFLD(freeDepoStp, investParamStp, A_FreeDepositHisto_TransferFromPortfolioId, A_PlanInvestParamHisto_TransferFromPortfolioId, IdType) == 0)
                            {
                                srcCashAmt -= amtToInvest;
                            }
                        }
                    }
                }
            }
            /*PMSTA-43411 - Smitha - 20210420 */
            /* Fix to handle the condition where the free deposit
            account is external to the system 
            Transfer from Account --> empty , Transfer from Portfolio --> empty
            Counterpart Account --> not empty
            */
            if (amtToInvest > 0.0)
            {
                flowEvtNbr = FIN_CalcEvtNbr(GET_DATETIME(freeDepoStp, A_FreeDepositHisto_InvestmentDate).date); /* PMSTA28294 - RAK - 171114 */

                /* Generate cash transfer operation(respecting free deposit upd_amt_cash_e value) and increase available cash. */
                /* PMSTA-33148 - RAK - 181003 - Give freeDepositHisto as parameter */
                FIN_GenerateWithrawalAndInvestOp(GET_DATETIME(freeDepoStp, A_FreeDepositHisto_InvestmentDate), A_FreeDepositHisto, freeDepoStp,
                    GET_ID(planDefStp, A_PlanDefinition_PortfolioId),
                    GET_ID(investParamStp, A_PlanInvestParamHisto_InvestAcctId),
                    &amtToInvest, opStatus,
                    GET_CODE(freeDepoStp, A_FreeDepositHisto_Cd),
                    flowEvtNbr,
                    domainStp, hierHead, extractFlowPos, extractFlowPosNbr, listPtr);

                planCashAmt += amtToInvest;
            }
            periodCurrentAmt += amtToInvest;
        }
        else
        {
	        /* Call new function to compute the amount to invest */
            FIN_ComputeAmtToInvest(objBeginDate, objEndDate, GET_DATETIME(investDateArray[i], A_PlanInvestDate_InvestmentDate).date, 
                                   minAmtIndexed, maxAmtIndexed, periodCurrentAmt, 
                                   planDefStp, investParamStp, objectiveStp, &amtToInvest);
    
       	    /* If  gen_cash_op_f is true                                                                                          */
            if (GET_FLAG(investParamStp, A_PlanInvestParamHisto_GenCashOp) == TRUE && amtToInvest > 0.0)
            {
                cashAmt = amtToInvest;
	            /* If current record date is the same than first record :                                                             */
                if (CMP_DYNFLD(investDateArray[i], investDateArray[0], A_PlanInvestDate_InvestmentDate, A_PlanInvestDate_InvestmentDate, DatetimeType) == 0)
                {
	                /* Adapt amt to invest regarding upd_amt_to_cash_e and available cash.                                                */
                    if (cashAmt > srcCashAmt)
                    {
                        switch (GET_ENUM(investParamStp, A_PlanInvestParamHisto_UpdAmtToCash))
                        {
                            case PlanInvestParamCashRule_SkipInvest:
                                cashAmt = 0.0;
                                break;
    
                            case PlanInvestParamCashRule_InvestAllCash:
                                cashAmt = planCashAmt;
                                break;

                            case PlanInvestParamCashRule_AlwaysInvest:
                            default:
                                break;
                        }
                    }
               }   

        	    /* Generate cash transfer operation(respecting plan invest param upd_amt_cash_e value) and increase available cash.   */
				/* PMSTA-33148 - RAK - 181003 - Give A_PlanInvestParamHisto as parameter */
				/* PMSTA-33836 - RAK - 181130 - No investment nore withdrawal must be generated if the counterpart_account_c is set in plan_invets_param_histo */
				if (IS_NULLFLD(investParamStp, A_PlanInvestParamHisto_CounterpartAcctC))
				{
					FIN_GenerateWithrawalAndInvestOp(GET_DATETIME(investDateArray[i], A_PlanInvestDate_InvestmentDate),
													A_PlanInvestParamHisto, investParamStp,
													GET_ID(planDefStp, A_PlanDefinition_PortfolioId),
													GET_ID(investParamStp, A_PlanInvestParamHisto_InvestAcctId),
													&cashAmt, opStatus,
													GET_CODE(planDefStp, A_PlanDefinition_Cd),
													flowEvtNbr,
													domainStp, hierHead, extractFlowPos, extractFlowPosNbr, listPtr);
					planCashAmt += cashAmt;
				}
            }

	        /* If current record date is the same than first record :                                                             */
            if (CMP_DYNFLD(investDateArray[i], investDateArray[0], A_PlanInvestDate_InvestmentDate, A_PlanInvestDate_InvestmentDate, DatetimeType) == 0)
            {
	            /* Adapt amt to invest regarding upd_amt_to_cash_e and available cash.                                                */
                if (amtToInvest > planCashAmt)
                {
                    switch (GET_ENUM(investParamStp, A_PlanInvestParamHisto_UpdAmtToCash))
                    {
                        case PlanInvestParamCashRule_SkipInvest:
                            amtToInvest = 0.0;
                            break;
    
                        case PlanInvestParamCashRule_InvestAllCash:
                            amtToInvest = planCashAmt;
                            break;

                        case PlanInvestParamCashRule_AlwaysInvest:
                        default:
                            break;
                    }
                }
           }         

            if (maxAmt != NO_VALUE && (periodCurrentAmt + amtToInvest) > maxAmt)
                amtToInvest = maxAmt - periodCurrentAmt;

	        /* Adapt available cash(substract amount to invest).                                                                  */
            planCashAmt -= amtToInvest;

            /* PMSTA-21782 - DDV - 151130 - for objective of invest amount nature, reset period currrent amount at each payment */
            if (GET_ENUM(planDefStp, A_PlanDefinition_ObjectiveNature) == PlanDefObjectiveNat_InvestAmount)
                periodCurrentAmt = 0.0;
            else
                periodCurrentAmt += amtToInvest;
        }

        if (amtToInvest > 0.0)
		{
			/* PMSTA-33148 - RAK - 181005 - Not for suspended plan (as could be returned in case of A_PlanDefinition_DepositExecRuleEn is : generated even on suspended plan */
			extOpNbr = 0;
			extOpTab = nullptr;
		
			if (GET_ENUM(planDefStp, A_PlanDefinition_Status) != PlanDefStatus_Suspended)
			{
				/* Update all standing instruction structure to distribute invest amt using defined weight.                           */
				FIN_UpdStandingInstructArray(planDefStp, investParamStp,
					GET_DATETIME(investDateArray[i], A_PlanInvestDate_InvestmentDate), amtToInvest, flowEvtNbr, &remainAmt,
					&standInstructArray, &standInstructNbr, hierHead);

                mp.ownerDynStpTab(standInstructArray,standInstructNbr);

				/* Call FIN_GenerateStandInstructFlowsAndOps function.Using updated standing instructions.                            */
				FIN_GenerateStandInstructFlowsAndOps(domainStp, hierHead, extractFlowPos, extractFlowPosNbr,
					standInstructArray, standInstructNbr, planDefStp, listPtr,
					FALSE, &flowTab, &flowNbr, &extOpTab, &extOpNbr);
			}

            /* check that min_invest_amt is respected */
            for (j=0; j < extOpNbr; j++)
            {
                tmpStandInstructStp = NULLDYNST;
                hierStandInstructStp = NULLDYNST;
                if (IS_NULLFLD(extOpTab[j], ExtOp_StandInstructIdx) == FALSE &&
                    GET_INT(extOpTab[j], ExtOp_StandInstructIdx) >= 0 &&
                    GET_INT(extOpTab[j], ExtOp_StandInstructIdx) < standInstructNbr)
                {
                    tmpStandInstructStp = standInstructArray[GET_INT(extOpTab[j], ExtOp_StandInstructIdx)];

                    /* as Standing instruction in array are copied from hierarchy get the original record to update it with remaining amt */
                    if (tmpStandInstructStp != NULLDYNST)
                    {
                        DBA_GetRecPtrFromHierById(hierHead, GET_ID(tmpStandInstructStp, A_StandInstruct_Id), A_StandInstruct, &hierStandInstructStp);
                    }
                }

                if (hierStandInstructStp != NULLDYNST)
                {
                    if (GET_FLAG(tmpStandInstructStp, A_StandInstruct_UpdGenDateFlg) == TRUE)
                    {
                        SET_FLAG(hierStandInstructStp, A_StandInstruct_UpdGenDateFlg, TRUE);
                    }

                    if (IS_NULLFLD(hierStandInstructStp, A_StandInstruct_MinInvestAmt) == FALSE &&
                        GET_AMOUNT(hierStandInstructStp, A_StandInstruct_MinInvestAmt) != 0.0 &&
                        CMP_AMOUNT(GET_AMOUNT(extOpTab[j], ExtOp_OpNetAmt), 
                                   GET_AMOUNT(hierStandInstructStp, A_StandInstruct_MinInvestAmt), GET_ID(extOpTab[j], ExtOp_OpId)) < 0)
                    {
                        remainAmt += GET_AMOUNT(tmpStandInstructStp, A_StandInstruct_OpAmt);
                        COPY_DYNFLD(hierStandInstructStp, A_StandInstruct, A_StandInstruct_OpAmt, 
                                    tmpStandInstructStp, A_StandInstruct, A_StandInstruct_OpAmt);

                        if (IS_NULLFLD(extOpTab[j], ExtOp_FlowIdx) == FALSE &&
                            GET_INT(extOpTab[j], ExtOp_FlowIdx) >= 0 &&
                            GET_INT(extOpTab[j], ExtOp_FlowIdx) < flowNbr)
                        {
                            FREE_DYNST(flowTab[GET_INT(extOpTab[j], ExtOp_FlowIdx)], Flow);
                        }
                        FREE_DYNST(extOpTab[j], ExtOp);
                    }
                    else
                    {
                        SET_AMOUNT(hierStandInstructStp, A_StandInstruct_OpAmt, GET_AMOUNT(tmpStandInstructStp, A_StandInstruct_OpAmt) - GET_AMOUNT(extOpTab[j], ExtOp_OpNetAmt));
                        if (GET_ENUM(extOpTab[j], ExtOp_NatureEn) == OpNat_Buy)
                        {
                            planCashAmt -= GET_AMOUNT(extOpTab[j], ExtOp_OpNetAmt);  
                        }
                        else if (GET_ENUM(extOpTab[j], ExtOp_NatureEn) == OpNat_Sell)
                        {
                            planCashAmt += GET_AMOUNT(extOpTab[j], ExtOp_OpNetAmt);  
                        }
                    }
                }
                else
                {
                    if (GET_ENUM(extOpTab[j], ExtOp_NatureEn) == OpNat_Buy)
                    {
                        planCashAmt -= GET_AMOUNT(extOpTab[j], ExtOp_OpNetAmt);  
                    }
                    else if (GET_ENUM(extOpTab[j], ExtOp_NatureEn) == OpNat_Sell)
                    {
                        planCashAmt += GET_AMOUNT(extOpTab[j], ExtOp_OpNetAmt);  
                    }
                }
            }
            
            /* Add flows records in hierarchy */
		    DBA_AddHierRecordList(hierHead, flowTab, flowNbr, Flow, FALSE);

            /* update flow_id in operation. */
            for (j=0; j < extOpNbr; j++)
            {
                if (extOpTab[j] != NULLDYNST &&
                    IS_NULLFLD(extOpTab[j], ExtOp_FlowIdx) == FALSE &&
                    GET_INT(extOpTab[j], ExtOp_FlowIdx) >= 0 &&
                    GET_INT(extOpTab[j], ExtOp_FlowIdx) < flowNbr &&
                    flowTab[GET_INT(extOpTab[j], ExtOp_FlowIdx)] != NULLDYNST)
                {
                    COPY_DYNFLD(extOpTab[j], ExtOp, ExtOp_FlowId,       
                                flowTab[GET_INT(extOpTab[j], ExtOp_FlowIdx)], Flow, Flow_Id);
                }
            }

            /* Add operation records in hierarchy */
		    DBA_AddHierRecordList(hierHead, extOpTab, extOpNbr, ExtOp, FALSE);

            FREE(flowTab);
            FREE(extOpTab);


            planCashAmt += remainAmt;  
        }

        prevObjectiveStp = objectiveStp;
        prevInvestParamStp = investParamStp;

        if (planRuleHistoStp != NULLDYNST)
        {
            prevPlanRuleHistoId = planRuleHistoId;
            FREE_DYNST(planRuleHistoStp, A_PlanRuleHisto);
        }
        else
            prevPlanRuleHistoId = 0;
    }

	/* Update plan_invest_date and free_deposit_hist statuses */
    if ((connectNo = DBA_GetConnection(SqlServer)) != DBA_CONN_NOT_FOUND)
	{
        for (i=0; i < investDateNbr ; i++)
        {
            if (IS_NULLFLD(investDateArray[i], A_PlanInvestDate_FreeDepositHistoId) == TRUE)
            {
                /* update plan_invest_date */
                if (GET_ENUM(investDateArray[i], A_PlanInvestDate_DbActionEn) == ExtOpActionEn_ToUpdate)
                {
                    DBA_Update2(PlanInvestDate, UNUSED, A_PlanInvestDate, investDateArray[i], DBA_SET_CONN | DBA_NO_CLOSE, &connectNo, UNUSED);
                }
            }
            else
            {
                /* update free_deposit_histo */
                if (GET_ENUM(investDateArray[i], A_PlanInvestDate_DbActionEn) == ExtOpActionEn_ToUpdate)
                {
                    if (DBA_GetRecPtrFromHierById(hierHead, GET_ID(investDateArray[i], A_PlanInvestDate_FreeDepositHistoId), A_FreeDepositHisto, &freeDepoStp) == RET_SUCCEED)
                    {
                        COPY_DYNFLD(freeDepoStp, A_FreeDepositHisto, A_FreeDepositHisto_Status,
                                    investDateArray[i], A_PlanInvestDate, A_PlanInvestDate_Status);
                        DBA_Update2(FreeDepositHisto, UNUSED, A_FreeDepositHisto,freeDepoStp, DBA_SET_CONN | DBA_NO_CLOSE, &connectNo, UNUSED);
                    }
                }
            }
        }

        DBA_EndConnection(connectNo);
    }

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_FilterPEFundPos()
**
**  Description :   Filter for PE Fund share positions based on the arg given
**
**                  return TRUE  -> record must be extract
**                         FALSE ->	 record musn't be extract
**
**  Arguments   :   dynSt      dynamic structure pointer
**                  dynStTp    dynamic structure definition
**
**  Return      :   TRUE or FALSE
**
**  Creation    :   PMSTA-32106 -NRAO 180904
*************************************************************************/

STATIC int FIN_FilterPEFundPos(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP admArg)
{
	DBA_DYNFLD_STP  instrPtr = NULLDYNST;

	if (DBA_IsTechnicalPosition(dynSt) == false &&
		CMP_ENUM(GET_ENUM(dynSt, ExtPos_StatEn), GET_ENUM(admArg, Adm_Arg_StatusEn)) >= 0 &&
		GET_EXTENSION_PTR(dynSt, ExtPos_A_Instr_Ext) != NULL &&
		(instrPtr = *(GET_EXTENSION_PTR(dynSt, ExtPos_A_Instr_Ext))) != NULLDYNST &&
		CMP_ID(GET_ID(instrPtr, A_Instr_Id), GET_ID(admArg, Adm_Arg_Id)) == 0 &&
		CMP_ENUM(GET_ENUM(instrPtr, A_Instr_SubNatEn), GET_ENUM(admArg, Adm_Arg_NatEn)) == 0 &&
		CMP_DYNFLD(instrPtr, admArg, A_Instr_CommonRef, Adm_Arg_Info, InfoType) == 0)
	{
		return TRUE;
	}
	return(FALSE);
}
/************************************************************************
**
**  Function    :   FIN_SetLinkedInstrForPE()
**
**  Description :   Set Linked Instr for PE Fund
**
**  Return      :   RET_CODE
**
**  Creation    :   PMSTA-32106 -NRAO 180904
*************************************************************************/
STATIC RET_CODE FIN_SetLinkedInstrForPE(DBA_HIER_HEAD_STP hierHead,
										DBA_DYNFLD_STP    instrPtr,
										SUBNAT_ENUM       linkedFundSubNatEn,
										DBA_DYNFLD_STP    extOp)
{
	RET_CODE           ret = RET_SUCCEED;
	FLAG_T             freeInstrFlg = FALSE;
	DBA_DYNFLD_STP     linkedInstrPtr = NULLDYNST;

	if ((ret = DBA_GetLinkedInstrForPE(hierHead, instrPtr, &linkedInstrPtr, &freeInstrFlg, linkedFundSubNatEn)) != RET_SUCCEED)
	{
		return(ret);
	}

	if (linkedInstrPtr != NULLDYNST)
	{
		SET_ID(extOp, ExtOp_InstrId, GET_ID(linkedInstrPtr, A_Instr_Id));
	}

	if (freeInstrFlg == TRUE)
	{
		FREE_DYNST(linkedInstrPtr, A_Instr);
	}
	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_ExtractLinkedPEQtyFromHier()
**
**  Description :
**
**                  return TRUE  -> record must be extract
**                         FALSE ->	 record musn't be extract
**
**  Arguments   :   dynSt      dynamic structure pointer
**                  dynStTp    dynamic structure definition
**
**  Return      :   TRUE or FALSE
**
**  Creation    :   PMSTA-32106 -NRAO 180904
*************************************************************************/
STATIC RET_CODE FIN_ExtractLinkedPEQtyFromHier(DBA_DYNFLD_STP   ptfPtr,
	                                           DBA_DYNFLD_STP   instrPtr,
											   SUBNAT_ENUM      reqSubNature,
											   DBA_HIER_HEAD_STP hierHead,
											   NUMBER_T         *qty)
{
	OPSTAT_ENUM    evtGenMinStatus = OpStat_None;
	DBA_DYNFLD_STP admArgIn = NULLDYNST, *extractPosTab = NULLDYNSTPTR, linkedInstrPtr = NULLDYNST;
	MemoryPool mp;
	RET_CODE ret = RET_SUCCEED;
	int extractPosNbr = 0;
	FLAG_T freeInstrFlg = FALSE;

	if (ptfPtr == NULLDYNST) 
		return(RET_DBA_ERR_INVDATA);

	admArgIn = mp.allocDynst(FILEINFO, Adm_Arg);
	GEN_GetApplInfo(ApplEvtGenMinStatus, &evtGenMinStatus);

    SET_INFO(admArgIn, Adm_Arg_Info, GET_INFO(instrPtr, A_Instr_CommonRef));
	SET_ENUM(admArgIn, Adm_Arg_StatusEn, evtGenMinStatus);
	SET_ENUM(admArgIn, Adm_Arg_NatEn, (ENUM_T)reqSubNature);


	if ((ret = DBA_GetLinkedInstrForPE(hierHead, instrPtr, &linkedInstrPtr,
		                                &freeInstrFlg, reqSubNature)) == RET_SUCCEED && linkedInstrPtr != NULLDYNST)
	{
		SET_ID(admArgIn, Adm_Arg_Id, GET_ID(linkedInstrPtr, A_Instr_Id));
	}

	if (freeInstrFlg == TRUE)
	{
		FREE_DYNST(linkedInstrPtr, A_Instr);
	}

	if ((ret = DBA_ExtractHierEltRecWithFilterSt(hierHead, ExtPos, FALSE, FIN_FilterPEFundPos, admArgIn, NULL,
		                                         &extractPosNbr, &extractPosTab)) != RET_SUCCEED || extractPosNbr == 0)
	{
		return(ret);
	}

	mp.owner(extractPosTab);

	int k = 0;
	for (k = 0; k < extractPosNbr; k++)
	{
		if (extractPosTab[k] != NULLDYNST &&
			CMP_ID(GET_ID(extractPosTab[k], ExtPos_PtfId), GET_ID(ptfPtr, A_Ptf_Id)) == 0 && 
			GET_ENUM(extractPosTab[k], ExtPos_NatEn) == ExtPosNat_FinalStock)
		{
			*qty = GET_NUMBER(extractPosTab[k], ExtPos_Qty);
		}
	}
	return (ret);
}

/************************************************************************
**      END  finsrv01.c                                              OAMS
*************************************************************************/

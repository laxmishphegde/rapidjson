/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**  Produce a stack trace for Solaris systems. 
**  Copyright (C) 1995-1998 Andrew Gabriel <and...@cucumber.demon.co.uk>
**  Parts derived from Usenet postings of Bart Smaalders and Casper Dik.
************************************************************************/

/************************************************************************
**      Include files
*************************************************************************/

#include <set>
#include <string>  

#include <setjmp.h> 
#include <sys/types.h> 
#include <sys/reg.h> 
#include <sys/frame.h> 
#include <dlfcn.h> 
#include <errno.h> 
#include <unistd.h> 
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#if defined(sparc) || defined(__sparc) 
#define FLUSHWIN() asm("ta 3"); 
#define FRAME_PTR_INDEX 1 
#define SKIP_FRAMES 0 
#endif 

#if defined(i386) || defined(__i386) 
#define FLUSHWIN() 
#define FRAME_PTR_INDEX 3 
#define SKIP_FRAMES 1 
#endif 


#if defined(ppc) || defined(__ppc) 
#define FLUSHWIN() 
#define FRAME_PTR_INDEX 0 
#define SKIP_FRAMES 2 
#endif 

/*******************************************************************************
**      Global variables
*******************************************************************************/

static std::set<std::string> SV_SetBannedFunction;


/************************************************************************
**
**  Function    :   OS_InitializationCallStack()
**
**  Description :   This create a set of function to not display on the callstack to have a "light" stack trace 
**
**  Arguments   :
**
**
**  Return      :
**
**  Last modif. :  PMSTA-22000 - 231215 - PMO : Finish, test and integrate the stack trace on Windows
**
*************************************************************************/
void OS_InitializationCallStack()
{
    SV_SetBannedFunction.insert("_BuildCatchObjectHelper");
    SV_SetBannedFunction.insert("BaseThreadInitThunk");
    SV_SetBannedFunction.insert("mainCRTStartup");
    SV_SetBannedFunction.insert("__tmainCRTStartup");
    SV_SetBannedFunction.insert("OS_GetCallStack");
    SV_SetBannedFunction.insert("SYS_GetCallStack");
    SV_SetBannedFunction.insert("RtlUserThreadStart");
    SV_SetBannedFunction.insert("RtlCaptureContext");
    SV_SetBannedFunction.insert("RtlInitializeExceptionChain");
    SV_SetBannedFunction.insert("RtlRestoreContext");
    SV_SetBannedFunction.insert("RtlUnicodeStringToInteger");
    SV_SetBannedFunction.insert("beginthreadex");
    SV_SetBannedFunction.insert("endthreadex");
    SV_SetBannedFunction.insert("QThread::start");
    SV_SetBannedFunction.insert("srv_regcreate");
    SV_SetBannedFunction.insert("srv_run");
    SV_SetBannedFunction.insert("srv_capability_info");
    SV_SetBannedFunction.insert("srv_ucwakeup");
    SV_SetBannedFunction.insert("WinMainCRTStartup");
}


/************************************************************************
**
**  Function    :   OS_RemoveCallStack()
**
**  Description :   Memory cleanup
**
**  Arguments   :
**
**
**  Return      :
**
**  Last modif. :   PMSTA-25852 - 110117 - PMO : Integrate getcallstack as a standard TripleA library
**
*************************************************************************/
void OS_RemoveCallStack()
{
    SV_SetBannedFunction.clear();
}


#ifdef _LP64
/*
 * 64 Bits code
 */

/* PMSTA-25852 - 110117 - PMO */
char * OS_GetCallStack(const bool)
{
    return nullptr;
}

#else
/*
 * 32 Bits code
 */


/************************************************************************
**
**  Function    :   validaddr()
**
**  Description :   
**                 
**  Arguments   :   
**                  
**
**  Return      :   
**
*************************************************************************/
static int validaddr(void *addr)
{ 
    static long pagemask = -1;
    char c;
    if (pagemask == -1)
    pagemask = ~(sysconf(_SC_PAGESIZE) - 1);
    addr = (void *)((long)addr & pagemask);
    if (mincore((char*) addr, 1, &c) == -1 && errno == ENOMEM)
    {
        return 0;  /* invalid */
    }
    else 
    {
        return 1;  /* valid */
    }
} 

/************************************************************************
**
**  Function    :   getcallstack()
**
**  Description :   function walks up call stack,once for each stack frame
**                 
**  Arguments   :   
**                  
**
**  Return      :   NULL    Malloc Failed
**                  Pointer on a buffer that contain the stacktrace and that can be freed with free
**
**  Last modif. :   REF11847 - 050706 - PMO : Write the fucntion callstack when writing an error message
**
*************************************************************************/
char * OS_GetCallStack(const bool printAddress)
{ 
    struct frame *sp;
    jmp_buf env; 
    int i;
    char buff[512]; /* REF11847 - 050706 - PMO */
    std::string     stackFrame;                                                        /* Storage of the final stack frame */
    int * iptr;
    FLUSHWIN();

    setjmp(env);
    iptr = (int*) env; 
    sp = (struct frame *) iptr[FRAME_PTR_INDEX];

    for (i=0; i<SKIP_FRAMES && sp; i++)
    {
        if (!validaddr(sp) || !validaddr(&sp->fr_savpc))
        { 
        /*  fprintf(stderr, "***[stack pointer corrupt]\n" );  */
            stackFrame += "***[stack pointer corrupt]\n";

            return strdup(stackFrame.c_str());
        } 
        sp = (struct frame *)sp->fr_savfp; 
     } 

     i = 100;  /* looping check */

    while (validaddr(sp) && validaddr(&sp->fr_savpc) && sp->fr_savpc && --i ) 
    { 
        Dl_info info;
        if(printAddress)
	{
            /* REF11847 - 050706 - PMO */
            if (dladdr((void*)sp->fr_savpc, &info) == 0)
            { /* not found */
                snprintf(buff,sizeof(buff), "0x%x  ??\n",(unsigned int)(void*)sp->fr_savpc);
            }
            else
            { /* found */
                snprintf(buff,sizeof(buff), "0x%x  %s:%s+0x%x\n",(unsigned int)(void*)sp->fr_savpc,info.dli_fname,info.dli_sname,(unsigned int)(void*)sp->fr_savpc - (unsigned int)info.dli_saddr);
            }
        }
	else
	{
	    /* REF11847 - 050706 - PMO */
	    if (dladdr((void*)sp->fr_savpc, &info) == 0)
	    { /* not found */
	        snprintf(buff,sizeof(buff), "??\n");
	    }
	    else
	    { /* found */
	        snprintf(buff,sizeof(buff), "%s:%s+0x%x\n",info.dli_fname,info.dli_sname,(unsigned int)(void*)sp->fr_savpc - (unsigned int)info.dli_saddr);
	    }
	}
        stackFrame += buff;

        sp = (struct frame *)sp->fr_savfp;
    }

    return strdup(stackFrame.c_str());
} 

#endif



/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef DYNAMICSEVERITY_H
#define DYNAMICSEVERITY_H
#endif

#ifndef SRVSTRA1_C
#include    "unidef.h"
#include       "gen.h"
#include       "fin.h"
#include   "srvstra.h"
#include    "finsrv.h"
#include      "hier.h"
#include    "scptyl.h"
#include      <math.h>
#endif

enum class DeviationType
{
    DeviationGap = 0,
    DeviationDuration = 1
};


class DynamicSeverity
{
public:
    DynamicSeverity(DBA_HIER_HEAD_STP   stratHierHead,
        DBA_DYNFLD_STP      domainPtr,
        FIN_PTFINFO_STP     ptfInfoStp

    ) : m_stratHierHead(stratHierHead),
        m_domain(domainPtr),
        m_ptfInfoStp(ptfInfoStp) 
    {
        m_portfolioLinkedseveRuleTab       = (DBA_DYNFLD_STP*)NULLDYNST;
        m_portfolioListLinkedseveRuleTab   = (DBA_DYNFLD_STP*)NULLDYNST;
        m_businessUnitLinkedseveRuleTab    = (DBA_DYNFLD_STP*)NULLDYNST;
        m_businessEntityLinkedseveRuleTab  = (DBA_DYNFLD_STP*)NULLDYNST;
        m_defaultseveRuleTab               = (DBA_DYNFLD_STP*)NULLDYNST;

        m_portfolioLinkedseveRuleNbr = 0;
        m_portfolioListLinkedseveRuleNbr = 0;
        m_businessUnitLinkedseveRuleNbr = 0;
        m_businessEntityLinkedseveRuleNbr = 0;
        m_defaultseveRuleTabNbr = 0;
    }

    ~DynamicSeverity() {}
     DynamicSeverity(const DynamicSeverity &) = delete;
     DynamicSeverity & operator=(const DynamicSeverity &) = delete;

     /* initialise object with Rules */
     RET_CODE initialiseDynamicSeverity();
     /*function to identify getSeverityRuleByPriority(), computeDeviationGap() and update ESE */
     RET_CODE setRuleAndComputeDeviationGap();
     /*find the duration criticalness using the case generated - both from static severity and dynamic*/
     RET_CODE processDeviationDerivation();
 
private:
    
    DBA_HIER_HEAD_STP        m_stratHierHead;

    DBA_DYNFLD_STP           m_domain;

    DBA_DYNFLD_STP           *m_portfolioLinkedseveRuleTab;
    DBA_DYNFLD_STP           *m_portfolioListLinkedseveRuleTab;
    DBA_DYNFLD_STP           *m_businessUnitLinkedseveRuleTab;
    DBA_DYNFLD_STP           *m_businessEntityLinkedseveRuleTab;
    DBA_DYNFLD_STP           *m_defaultseveRuleTab;

    FIN_PTFINFO_STP          m_ptfInfoStp;

    int                      m_portfolioLinkedseveRuleNbr;
    int                      m_portfolioListLinkedseveRuleNbr;
    int                      m_businessUnitLinkedseveRuleNbr;
    int                      m_businessEntityLinkedseveRuleNbr;
    int                      m_defaultseveRuleTabNbr;

    MemoryPool               m_ruleTabMemeoryPool;

 
    /*compute deviationGap by passing ESE and severity rule*/
    NUMBER_T computeDeviationGap(DBA_DYNFLD_STP , DBA_DYNFLD_STP );
    RET_CODE getSeverityRuleElement(DeviationType enDeviationType, DBA_DYNFLD_STP svRrule, NUMBER_T deviationValue,
                                    DBA_DYNFLD_STP *svRruleElem);
    /*validate scope_e,sub_nature_e,objcet_id */
    RET_CODE getRuleByNature(DBA_DYNFLD_STP, DBA_DYNFLD_STP , DBA_DYNFLD_STP *);
    /*get the severityrule in output parameter using the priority check - portfolio/list/business entity/business unit/default startegy*/
    RET_CODE getSeverityRuleByPriority(DBA_DYNFLD_STP , DBA_DYNFLD_STP *);
    RET_CODE isMatchedSeverityRuleScope(DBA_DYNFLD_STP);
    RET_CODE getLinkedRules();
    NUMBER_T computeDeviationDuration(DBA_DYNFLD_STP, DBA_DYNFLD_STP *);
    /*compare rule object with ESE*/
    bool  isMatchedRuleObject(DBA_DYNFLD_STP, DBA_DYNFLD_STP);
};

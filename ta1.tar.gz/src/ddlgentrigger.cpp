/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DDLGENTRIGGER_CPP

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H

#include          "unidef.h"     /* Mandatory */
#include             "gen.h"
#include          "ddlgen.h"
#include       "ddlgenvar.h"
#include   "ddlgentrigger.h"
#include  "ddlgenfromfile.h"

#include               <set>

using namespace std;

/************************************************************************
**      External entry points
**
*************************************************************************/

/************************************************************************
**      Local functions
**
*************************************************************************/

/************************************************************************
**      Static definitions & data
**
*************************************************************************/
#define TAG_NEW                "NEW"
#define TAG_OLD                "OLD"


/************************************************************************
**      FONCTIONS
**
************************************************************************/

/************************************************************************
**
**  Function    :   DdlGenTrigger::DdlGenTrigger()
**
**  Description :   Constructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 110311
**
*************************************************************************/
DdlGenTrigger::DdlGenTrigger(OBJECT_ENUM      paramObjectEn,
                             DDL_OBJ_ENUM     paramDdlObjEn,
                             DdlGenContext   &paramDdlGenContext,
                             DdlGenVarHelper *paramVarHelperPtr,
                             DdlGenEntity    *paramDdlGenEntityPtr,
                             DdlGenFile        *paramFileHelper,
                             TARGET_TABLE_ENUM  paramTargetTableEn)
    : DdlGen(paramObjectEn, paramDdlObjEn, paramDdlGenContext, paramVarHelperPtr, paramDdlGenEntityPtr, paramFileHelper, paramTargetTableEn)
{
    DdlGen::init(paramObjectEn,
                 DynType_All,
                 TRUE,
                 FALSE,
                 FALSE,
                 EntSecuLevel_NoSecured,
                 FALSE);

    DICT_ENTITY_STP locDictEntityStp = this->getDictEntityStp();

    DBA_GetDictId(DictEntity, &entityDictId);
    DBA_GetDictId(Empty, &emptyDictId);

    this->currEventPos     = EventPos_All;
    this->currDmlEvent     = DmlEvent_None;
    this->currTriggerPos   = TriggerPos_None;
    this->m_bIsInitPrinted = true;

    if (this->getDdlObjEn() == DdlObj_TriggerUdField)
    {
        this->bUdTableTrig = true;
        this->m_scptDllObjEn = DdlObj_TriggerUdFieldBody;
    }
    else
    {
        this->bUdTableTrig = false;
        this->m_scptDllObjEn = DdlObj_TriggerBody;
    }

    this->bTblModifStat         = locDictEntityStp->tableModifStatEn == LastModif_TrackingAuto;
    this->bObjModifStatPrinted  = false;     /* PMSTA-32982 - LJE - 181016 */

    for (int i = TriggerPos_BeforeStandard; i < TriggerPos_Last; i++)
    {
        for (int j = DmlEvent_Insert; j < DmlEvent_Last; j++)
        {
            this->beforeVarTab[i][j]        = new DdlGenVarHelper(this, nullptr);
            this->beforeEachRowVarTab[i][j] = new DdlGenVarHelper(this, nullptr);
            this->afterEachRowVarTab[i][j]  = new DdlGenVarHelper(this, nullptr);
            this->afterVarTab[i][j]         = new DdlGenVarHelper(this, nullptr);
        }
    }

    for (int i = DmlEvent_Insert; i < DmlEvent_Last; i++)
    {
        this->currDmlEvent = (DML_EVENT_ENUM)i;

        this->varHelperPtr->cleanAllVar();
        this->setName();

        this->initCheckSecurityAndFk();

        if (this->currDmlEvent == DmlEvent_Update)
        {
            DICTATTR_ENUM calcToCheckTab[] = { DictAttr_LastModifManagment, DictAttr_CreationManagment, DictAttr_NoMD };

            for (int j = 0; calcToCheckTab[j] != DictAttr_NoMD; j++)
            {
                bool bFirst = true;
                for (auto& dictAttribStp : locDictEntityStp->attr)
                {
                    if ((this->m_ddlObjEn == DdlObj_TriggerUdField && dictAttribStp->custFlg == FALSE) ||
                        (this->m_ddlObjEn == DdlObj_Trigger && dictAttribStp->custFlg == TRUE))
                    {
                        continue;
                    }

                    if ((calcToCheckTab[j] == DictAttr_LastModifManagment || calcToCheckTab[j] == DictAttr_CreationManagment) &&
                        this->isAllowModifNewRecord())
                    {
                        continue;
                    }

                    if (dictAttribStp->calcEn == calcToCheckTab[j])
                    {
                        if (bFirst)
                        {
                            bFirst = false;
                            this->discardTriggerTab[TriggerPos_BeforeStandard][this->currDmlEvent] << this->newLine()
                                << "/* Nothing to do if only the special attributes are updated */" << this->newLine()
                                << "#IF ";
                        }
                        else
                        {
                            this->discardTriggerTab[TriggerPos_BeforeStandard][this->currDmlEvent]
                                << this->newLine() << " or ";
                        }
                        this->discardTriggerTab[TriggerPos_BeforeStandard][this->currDmlEvent]
                            << "#UPDATING(" << dictAttribStp->sqlName << ") /* (calculated_e = " << dictAttribStp->calcEn << ") */ ";
                    }
                }
                if (bFirst == false)
                {
                    this->discardTriggerTab[TriggerPos_BeforeStandard][this->currDmlEvent]
                        << this->newLine() << "#{"
                        << this->newLine() << "\t#DISCARD_TRIGGER"
                        << this->newLine() << "#}" << endl << endl;
                }
            }
        }

        this->initCascadeDelRef();
        this->initTableModifStat();

        for (int j = TriggerPos_BeforeStandard; j < TriggerPos_Last; j++)
        {
            this->beforeVarTab[j][this->currDmlEvent]->copyVariables(this->varHelperPtr);
            this->beforeEachRowVarTab[j][this->currDmlEvent]->copyVariables(this->varHelperPtr);
            this->afterEachRowVarTab[j][this->currDmlEvent]->copyVariables(this->varHelperPtr);
            this->afterVarTab[j][this->currDmlEvent]->copyVariables(this->varHelperPtr);
        }
    }
    this->currDmlEvent = DmlEvent_None;

}

/************************************************************************
**
**  Function    :   DdlGenTrigger::~DdlGenTrigger()
**
**  Description :   Destructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 110311
**
*************************************************************************/
DdlGenTrigger::~DdlGenTrigger()
{
    for (int i = TriggerPos_BeforeStandard; i < TriggerPos_Last; i++)
    {
        for (int j = DmlEvent_Insert; j < DmlEvent_Last; j++)
        {
            delete this->beforeVarTab[i][j];
            this->beforeVarTab[i][j] = nullptr;

            delete this->beforeEachRowVarTab[i][j];
            this->beforeEachRowVarTab[i][j] = nullptr;

            delete this->afterEachRowVarTab[i][j];
            this->afterEachRowVarTab[i][j] = nullptr;

            delete this->afterVarTab[i][j];
            this->afterVarTab[i][j] = nullptr;
        }
    }
}

/************************************************************************
**
**  Function    :   DdlGenTrigger::init()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 141215
**
*************************************************************************/
RET_CODE DdlGenTrigger::init(DML_EVENT_ENUM	dmlEventEn, EVENT_POS_ENUM eventPosEn, TRIGGER_POS_ENUM triggerPos)
{
    this->currDmlEvent   = dmlEventEn;
    this->currEventPos   = eventPosEn;
    this->currTriggerPos = triggerPos;

    return RET_SUCCEED;
}

/************************************************************************
**
**  Function    :   DdlGenTrigger::grant()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-16194 - LJE - 130522
**
*************************************************************************/
RET_CODE DdlGenTrigger::grant()
{
    RET_CODE ret=RET_SUCCEED;

    this->cmdType = DDlCmdType_Grant;

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenTrigger::pushBeforeStatement()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 141217
**
*************************************************************************/
RET_CODE DdlGenTrigger::pushBeforeStatement(string script, TRIGGER_POS_ENUM trgPosEn, DML_EVENT_ENUM dmlEventEn)
{
    RET_CODE ret = RET_SUCCEED;

    if (script.find_first_not_of(" \t\n") == string::npos)
    {
        return ret;
    }

    if (trgPosEn == TriggerPos_Init)
    {
        this->beforeStreamTab[TriggerPos_AfterStandard][dmlEventEn].initStream() << endl << script << endl;
    }
    else
    {
        this->beforeStreamTab[trgPosEn][dmlEventEn] << endl << script << endl;
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenTrigger::pushBeforeEachRowStatement()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 141217
**
*************************************************************************/
RET_CODE DdlGenTrigger::pushBeforeEachRowStatement(string script, TRIGGER_POS_ENUM trgPosEn, DML_EVENT_ENUM dmlEventEn)
{
    RET_CODE ret = RET_SUCCEED;
    if (script.find_first_not_of(" \t\n") == string::npos)
    {
        return ret;
    }

    this->beforeEachRowStreamTab[trgPosEn][dmlEventEn] << endl << script << endl;
    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenTrigger::pushAfterStatement()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 141217
**
*************************************************************************/
RET_CODE DdlGenTrigger::pushAfterStatement(string script, TRIGGER_POS_ENUM trgPosEn, DML_EVENT_ENUM dmlEventEn)
{
    RET_CODE ret = RET_SUCCEED;
    if (script.find_first_not_of(" \t\n") == string::npos)
    {
        return ret;
    }

    this->afterStreamTab[trgPosEn][dmlEventEn] << endl << script << endl;
    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenTrigger::pushAfterEachRowStatement()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 141217
**
*************************************************************************/
RET_CODE DdlGenTrigger::pushAfterEachRowStatement(string script, TRIGGER_POS_ENUM trgPosEn, DML_EVENT_ENUM dmlEventEn)
{
    RET_CODE ret = RET_SUCCEED;
    if (script.find_first_not_of(" \t\n") == string::npos)
    {
        return ret;
    }

    this->afterEachRowStreamTab[trgPosEn][dmlEventEn] << endl << script << endl;
    return ret;
}


/************************************************************************
**
**  Function    :   DdlGenTrigger::printDeclareVariables()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14452 - LJE - 130131
**
*************************************************************************/
RET_CODE DdlGenTrigger::printDeclareVariables()
{
    RET_CODE ret = RET_SUCCEED;

    if (this->varHelperPtr->getVariable("user_id", false) != nullptr)
    {
        this->ddlGenContextPtr->bUserId = true;
    }

    /* PMSTA-26108 - LJE - 170819 */
    DdlGenSqlBlock      declareVarSqlBlock;
    DdlGen::printDeclareVariables(declareVarSqlBlock);

    if (declareVarSqlBlock.empty() == false && this->ddlGenContextPtr->m_rdbmsEn == Oracle)
    {
        DdlGenVar *initUsrVar = this->varHelperPtr->addVariable("is_init_usr_f", FlagType);
        initUsrVar->strDefault = "0";
        this->setIndent(1);
        this->initVarSqlBlock.initStream()
            << this->newLine() << "if " << initUsrVar->printSqlName() << " = 0 then" << endl;
        this->initVarSqlBlock.releaseStream()
            << this->newLine() << this->getCmdAssignByValue(*initUsrVar, "1");
        this->initVarSqlBlock.releaseStream()
            << this->newLine() << "end if;";
        this->setIndent(-1);
    }

    this->initVarSqlBlock << declareVarSqlBlock.str();

    this->setIndent(1);
    this->varHelperPtr->printVarList(*this, this->headerDeclareStream, this->initStream, true, this->newLine());
    this->setIndent(-1);

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenTrigger::setName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenTrigger::setName()
{
    RET_CODE            ret=RET_SUCCEED;
    string              udPrefix;
    string              ddlObjSqlName;

    if (this->bUdTableTrig)
    {
        this->targetTableEn = TargetTable_UserDefinedFields;
        udPrefix = "ud_";
    }

    if (this->currDmlEvent == DmlEvent_All)
    {
        ddlObjSqlName = "delete_all_trg";
    }
    else
    {
        switch (this->currDmlEvent)
        {
            case DmlEvent_Insert:
                ddlObjSqlName.append("i");
                break;

            case DmlEvent_Update:
                ddlObjSqlName.append("u");
                break;

            case DmlEvent_Delete:
                ddlObjSqlName.append("d");
                break;

            default:
                break;
        }

        switch (this->currEventPos)
        {
            case EventPos_Before:
                ddlObjSqlName += "_before";
                break;
            case EventPos_After:
                ddlObjSqlName += "_after";
                break;
        }

        switch (this->currTriggerPos)
        {
            case TriggerPos_Before:
                ddlObjSqlName += "_before";
                break;
            case TriggerPos_BeforeEachRow:
                ddlObjSqlName += "_before_row";
                break;
            case TriggerPos_AfterEachRow:
                ddlObjSqlName += "_after_row";
                break;
            case TriggerPos_After:
                ddlObjSqlName += "_after";
                break;
        }

        ddlObjSqlName.append("_");
        ddlObjSqlName.append(udPrefix + this->getDictEntityStp()->mdSqlName).append("_trg");
    }

    this->standardize(ddlObjSqlName);
    this->ddlGenContextPtr->ddlObjSqlName = ddlObjSqlName;

    this->setDdlObjSqlName(ddlObjSqlName);
    this->ddlGenContextPtr->setMsgSqlName(ddlObjSqlName);

    this->setDdlObjFullSqlName(this->getTargetDBName(), this->getDdlObjSqlName());

    this->ddlObjName = "trigger";
    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenTrigger::drop()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:  PMSTA-13109 - LJE - 111116
**
*************************************************************************/
RET_CODE DdlGenTrigger::drop()
{
    RET_CODE ret = RET_SUCCEED;
    if (this->currDmlEvent == DmlEvent_All)
    {
        this->clear();
        this->clearIndent();

        auto  &allDbTriggerSet = this->getAllDbTrigger();
        string database = this->ddlGenContextPtr->getDdlDestDbName();

        for (auto it = allDbTriggerSet.begin(); it != allDbTriggerSet.end(); ++it)
        {
            this->bodySqlBlock << this->getCmdDrop(database,
                                                   it->second.getEntitySqlName(),
                                                   it->second.getObjName(),
                                                   it->second.getDdlObjEn());
            this->cmdType = DDlCmdType_DropAll;
            this->flush();
        }
        allDbTriggerSet.clear();
    }
    else if (this->isReplaceAllowed(this->getDdlObjEn()) == false)
    {
        string       database = this->ddlGenContextPtr->getDdlDestDbName();

        DdlObjDefKey ddlObjDefKey = DdlObjDefKey(this->ddlGenContextPtr->m_rdbmsEn,
                                                 this->getDdlObjEn(),
                                                 database,
                                                 this->getEntitySqlName(),
                                                 this->getEntitySqlName(),
                                                 this->getDdlObjSqlName());

        auto trgDbIt = this->m_allDbTriggerMap.find(ddlObjDefKey);

        if (trgDbIt != this->m_allDbTriggerMap.end())
        {
            this->ddlGenContextPtr->setDdlDestDbName(database, this);
            this->bodySqlBlock << this->getCmdDrop(database,
                                                   trgDbIt->second.getEntitySqlName(),
                                                   trgDbIt->second.getObjName(),
                                                   trgDbIt->second.getDdlObjEn());
            this->cmdType = DDlCmdType_Drop;
            this->flush();
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenTrigger::create()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenTrigger::create()
{
    RET_CODE    ret = RET_SUCCEED;

    this->cmdType = DDlCmdType_Create;
    this->outputDynNatEn = DynType_All;

    if (this->currDmlEvent == DmlEvent_All)
    {
        return ret;
    }

    if ((ret = this->printHeader()) == RET_SUCCEED &&
        (ret = this->printBody()) == RET_SUCCEED &&
        (ret = this->printFooter()) == RET_SUCCEED)
    {
        ret = this->flush();
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenTrigger::build()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenTrigger::build()
{
    RET_CODE ret = RET_SUCCEED;
    bool     bUserId = this->ddlGenContextPtr->bUserId;

    if (RET_GET_LEVEL((ret = DdlGen::build())) == RET_LEV_ERROR)
    {
        this->printMsg(ret, "Create " + this->msgObjTypeStr + " " + this->getMsgSqlName() + " failed");
        return ret;
    }

    this->varHelperPtr->setAllVarToNotPrinted();

    if (this->currDmlEvent != DmlEvent_All)
    {
        this->ddlGenContextPtr->bUserId = bUserId;
    }

    this->ddlGenContextPtr->dmlEventEn = this->currDmlEvent;

    if (RET_GET_LEVEL((ret = this->initRequest())) == RET_LEV_ERROR ||
        RET_GET_LEVEL((ret = this->setName()))     == RET_LEV_ERROR ||
        RET_GET_LEVEL((ret = this->drop()))        == RET_LEV_ERROR ||
        RET_GET_LEVEL((ret = this->create()))      == RET_LEV_ERROR)
    {
        this->printMsg(ret, "Create " + this->msgObjTypeStr + " " + this->getMsgSqlName() + " failed");
        return ret;
    }
    else if (this->ddlGenContextPtr->lastErrRetCode == RET_GEN_INFO_NOACTION)
    {
        this->printMsg(ret, "Create " + this->msgObjTypeStr + " " + this->getMsgSqlName() + " not modified");
    }
    else
    {
        this->printMsg(ret, "Create " + this->msgObjTypeStr + " " + this->getMsgSqlName() + " done");
    }

    /* PMSTA-15962 - LJE - 130225 - Check and fix table_modif_stat entry */
    if (this->ddlGenContextPtr->ddlGenAction.m_installLevel < 9 &&
        this->currDmlEvent == DmlEvent_Update &&
        this->getDictEntityStp()->tableModifStatEn != LastModif_NoTracking)
    {
        DdlGenDbaAccessGuard ddlGenDbaAccessGuard(*this->ddlGenContextPtr);
        auto tableModifStatStp = ddlGenDbaAccessGuard.getDdlGenDbaAccess().getRecordById(TabModifStat, this->getTableModifStatEntityDictId(), true);

        if (tableModifStatStp == nullptr)
        {
            tableModifStatStp = ddlGenDbaAccessGuard.getDdlGenDbaAccess().allocDynSt(FILEINFO, A_TabModifStat);

            SET_DICT(tableModifStatStp,     A_TabModifStat_DictId, this->getTableModifStatEntityDictId());
            SET_DATETIME(tableModifStatStp, A_TabModifStat_LastModifDate, this->ddlGenContextPtr->getBuildDate());
            SET_INT(tableModifStatStp,      A_TabModifStat_LastModifDateMs, 0);

            ddlGenDbaAccessGuard.getDdlGenDbaAccess().insUpdDelRecord(Insert, TabModifStat, UNUSED, tableModifStatStp, false);
        }
    }

    if (this->currDmlEvent == DmlEvent_All)
    {
        this->ddlGenContextPtr->bUserId = bUserId;
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenTrigger::printHeader()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13122 - LJE - 120502
**
*************************************************************************/
RET_CODE DdlGenTrigger::printHeader()
{
    RET_CODE ret=RET_SUCCEED;
    this->getCmdCreateTrigger(this->headerStream,
                              this->footerStream,
                              this->getDictEntityStp(),
                              this->getDdlObjSqlName(),
                              this->getGenInfo(true),
                              this->currDmlEvent,
                              this->currEventPos,
                              this->currTriggerPos);
    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenTrigger::printBody()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13122 - LJE - 120503
**
*************************************************************************/
RET_CODE DdlGenTrigger::printBody()
{
    RET_CODE ret=RET_SUCCEED;

    this->m_beforeStream.clear();
    this->m_beforeEachRowStream.clear();
    this->m_afterEachRowStream.clear();
    this->m_afterStream.clear();

    this->initVarSqlBlock.clear();

    this->clearIndent();
    this->varHelperPtr->cleanAllVar();

    this->scriptDdlGen->setMsgEntitySqlName(this->getMsgEntitySqlName());
    this->scriptDdlGen->setMsgObjType(this->getMsgObjType());
    this->scriptDdlGen->setMsgSqlName(this->getMsgSqlName());
    this->scriptDdlGen->setInBlock(true);
    this->getDdlGenFromFileContextPtr()->m_bInBlock = true;

    this->ddlGenContextPtr->bStdIinsObjectModifStat = this->getDictEntityStp()->objModifStatEn == LastModif_TrackingAuto;
    this->ddlGenContextPtr->bUserId                 = false;
    this->bObjModifStatPrinted                      = false;

    this->setRootEntityManagementNeeded();

    if (RET_GET_LEVEL(ret) != RET_LEV_ERROR &&
        (this->currTriggerPos == TriggerPos_AfterEachRow ||
        (this->currTriggerPos == TriggerPos_None &&
         (this->currEventPos == EventPos_All || this->currEventPos == EventPos_Before))))
    {
        ret = this->initUdFieldsManagment();
    }

    if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
    {
        ret = this->printBeforeStatement();
    }

    if (RET_GET_LEVEL(ret) != RET_LEV_ERROR && 
        (this->currEventPos == EventPos_After || this->currTriggerPos == TriggerPos_After))
    {
        ret = this->printAfterStatement();
    }

    if (RET_GET_LEVEL(ret) != RET_LEV_ERROR &&
        (this->currTriggerPos == TriggerPos_AfterEachRow ||
         (this->currTriggerPos == TriggerPos_None &&
          (this->currEventPos == EventPos_All || this->currEventPos == EventPos_After))))
    {
        ret = this->printAfterEachRowStatement();
    }

    if (RET_GET_LEVEL(ret) != RET_LEV_ERROR &&
        (this->currTriggerPos == TriggerPos_BeforeEachRow ||
         (this->currTriggerPos == TriggerPos_None &&
          (this->currEventPos == EventPos_All || this->currEventPos == EventPos_Before))))
    {
        ret = this->printBeforeEachRowStatement();
    }

    if (RET_GET_LEVEL(ret) != RET_LEV_ERROR && 
        this->currEventPos == EventPos_All && 
        this->currTriggerPos == TriggerPos_None)
    {
        ret = this->printAfterStatement();
    }

    if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
    {
        ret = this->initRootManagment();
    }

    this->scriptDdlGen->clearTriggerInfo();

    if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
    {
        ret = this->printDeclareVariables();
    }

    std::stringstream currStream;
    if (this->ddlGenContextPtr->m_rdbmsEn == Oracle)
    {
        if (this->m_beforeStream.bodyStream().str().empty() == false)
        {
            currStream
                << endl << "before statement is"
                << endl << "begin" << endl
                << this->m_beforeStream.initStream().str()
                << this->initVarSqlBlock.str()
                << this->m_beforeStream.bodyStream().str()
                << this->m_beforeStream.releaseStream().str()
                << endl << "end before statement" << this->endOfCmd() << endl;
        }

        if (this->m_beforeEachRowStream.bodyStream().str().empty() == false)
        {
            currStream
                << endl << "before each row is"
                << endl << "begin" << endl
                << this->m_beforeEachRowStream.initStream().str()
                << this->initVarSqlBlock.str()
                << this->m_beforeEachRowStream.bodyStream().str()
                << this->m_beforeEachRowStream.releaseStream().str()
                << endl << "end before each row" << this->endOfCmd() << endl;
        }

        if (this->m_afterEachRowStream.bodyStream().str().empty() == false)
        {
            currStream
                << endl << "after each row is"
                << endl << "begin" << endl
                << this->m_afterEachRowStream.initStream().str()
                << this->initVarSqlBlock.str()
                << this->m_afterEachRowStream.bodyStream().str()
                << this->m_afterEachRowStream.releaseStream().str()
                << endl << "end after each row" << this->endOfCmd() << endl;

        }

        if (this->m_afterStream.bodyStream().str().empty() == false)
        {
            currStream
                << endl << "after statement is"
                << endl << "begin" << endl
                << this->m_afterStream.initStream().str()
                << this->initVarSqlBlock.str()
                << this->m_afterStream.bodyStream().str()
                << this->m_afterStream.releaseStream().str()
                << endl << "end after statement" << this->endOfCmd() << endl;
        }
    }
    else if (this->ddlGenContextPtr->m_rdbmsEn == Sybase)
    {
        currStream
            << this->initVarSqlBlock.str()
            << this->m_beforeStream.str()
            << this->m_beforeEachRowStream.str()
            << this->m_afterEachRowStream.str()
            << this->m_afterStream.str();
    }
    else if (this->ddlGenContextPtr->m_rdbmsEn == Nuodb)
    {
        if (this->currEventPos == EventPos_Before)
        {
            if (this->m_beforeEachRowStream.bodyStream().str().empty() == false)
            {
                currStream
                    << this->initVarSqlBlock.str()
                    << this->m_beforeStream.initStream().str()
                    << this->m_beforeEachRowStream.str()
                    << this->m_afterStream.releaseStream().str();
            }
        }
        else if (this->currEventPos == EventPos_After)
        {
            if (this->m_afterEachRowStream.bodyStream().str().empty() == false)
            {
                currStream
                    << this->initVarSqlBlock.str()
                    << this->m_beforeStream.initStream().str()
                    << this->m_afterEachRowStream.str();
            }
        }
    }
    else if (this->ddlGenContextPtr->m_rdbmsEn == PostgreSQL)
    {
        if (this->currTriggerPos == TriggerPos_Before)
        {
            if (this->m_beforeStream.str().empty() == false)
            {
                currStream
                    << this->initVarSqlBlock.str()
                    << this->m_beforeStream.str()
                    << this->m_afterStream.releaseStream().str();
            }
        }
        else if (this->currTriggerPos == TriggerPos_BeforeEachRow)
        {
            if (this->m_beforeEachRowStream.bodyStream().str().empty() == false)
            {
                currStream
                    << this->initVarSqlBlock.str()
                    << this->m_beforeStream.str()
                    << this->m_beforeEachRowStream.str()
                    << this->m_afterStream.releaseStream().str();
            }
        }
        else if (this->currTriggerPos == TriggerPos_AfterEachRow)
        {
            if (this->m_afterEachRowStream.bodyStream().str().empty() == false)
            {
                currStream
                    << this->initVarSqlBlock.str()
                    << this->m_beforeStream.initStream().str()
                    << this->m_afterEachRowStream.str();
            }
        }
        else if (this->currTriggerPos == TriggerPos_After)
        {
            if (this->m_afterStream.str().empty() == false)
            {
                currStream
                    << this->initVarSqlBlock.str()
                    << this->m_beforeStream.initStream().str()
                    << this->m_afterStream.str();
            }
        }
    }
    else if (this->ddlGenContextPtr->m_rdbmsEn == MSSql)
    {
        currStream
            << this->initVarSqlBlock.str()
            << this->m_beforeStream.str()
            << this->m_beforeEachRowStream.str()
            << this->m_afterEachRowStream.str()
            << this->m_afterStream.str();
    }

    if (currStream.str().find_first_not_of(" \t\n") == string::npos)
    {
        ret = RET_GEN_INFO_NODATA;
    }

    this->ddlGenContextPtr->m_releaseTriggerStream << this->m_afterStream.releaseStream().str();

    if (ret != RET_GEN_INFO_NOACTION &&
        ret != RET_GEN_INFO_NODATA &&
        this->ddlGenContextPtr->m_rdbmsEn == PostgreSQL)
    {
        DictSprocClass  &dictSprocSt = this->ddlGenContextPtr->getDictSprocSt();
        DdlGenSProc      ddlGenSProc(dictSprocSt.getObjectEn(), *this->ddlGenContextPtr, NULL, this->ddlGenEntityPtr, this->fileHelper, TargetTable_Main);
        
        auto dropDdlStrTab = this->ddlGenContextPtr->m_dropDdlStrTab;

        this->scriptDdlGen->setDdlObjEn(DdlObj_SProc);
        this->scriptDdlGen->setMsgSqlName(string());

        dictSprocSt.reset();
        dictSprocSt.setObjectEn(this->getObjectEn());
        ddlGenSProc.init(false);

        dictSprocSt.sqlName = this->getDdlObjSqlName();
        dictSprocSt.procActionEn = Trigger;

        stringstream sprocBody;

        sprocBody
            << "#FUNC_BEGIN " << dictSprocSt.sqlName << endl
            << "#RETURNS trigger" << endl
            << "#END" << endl
            << this->headerDeclareStream.str() << endl
            << "begin" << endl
            << this->scriptDdlGen->buildScript(currStream.str(), DdlObj_Trigger) << endl
            << "\t#RETURN" << endl
            << "end;" << endl
            << "#FUNC_END " << dictSprocSt.sqlName;

        this->ddlGenContextPtr->resetContext(dictSprocSt.sqlName);
        
        string lineStr;
        while (getline(sprocBody, lineStr))
        {
            this->scriptDdlGen->context->currBlockVector.push_back(lineStr);
        }
        this->scriptDdlGen->buildBlock(DdlObj_SProc);

        this->headerDeclareStream.clear();
        this->headerDeclareStream.str(string());

        this->bodySqlBlock.clear();

        this->ddlGenContextPtr->m_dropDdlStrTab = dropDdlStrTab;
    }
    else
    {
        this->bodySqlBlock
            << this->scriptDdlGen->buildScript(currStream.str(), DdlObj_Trigger);
    }
    this->ddlGenContextPtr->m_releaseTriggerStream.clear();
    this->ddlGenContextPtr->m_releaseTriggerStream.str(std::string());

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenTrigger::treatNewOldVariable()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 150722
**
*************************************************************************/
RET_CODE DdlGenTrigger::treatNewOldVariable(TRIGGER_POS_ENUM  triggerPos,
                                            string           &stringToTreat,
                                            stringstream     &selectStream,
                                            stringstream     &assignStream,
                                            std::set<string> &cursorDelcareSet,
                                            bool             &bFirst,
                                            bool             &bNew,
                                            bool             &bOld)
{
    RET_CODE     ret = RET_SUCCEED;
    int          step = 0;
    string::size_type pos, posEnd;
    string       varPrefix = this->getVarPrefix();
    bool         bUseCursor = false;

    if (this->ddlGenContextPtr->m_rdbmsEn != Nuodb &&
        this->ddlGenContextPtr->m_rdbmsEn != PostgreSQL &&
        (this->ddlGenContextPtr->m_rdbmsEn == Sybase ||
         this->ddlGenContextPtr->m_rdbmsEn == MSSql ||
         triggerPos == TriggerPos_AfterStandard))
    {
        bUseCursor = true;
    }

    if (this->ddlGenContextPtr->m_rdbmsEn == Oracle)
    {
        varPrefix = "t_";
    }

    string curTag = "#", varAlias = "i";
    curTag += TAG_NEW;
    pos = 0;
    while (curTag.empty() == false)
    {
        while ((pos = stringToTreat.find(curTag, pos)) != string::npos)
        {
            if (bUseCursor)
            {
                string attribStr;
                DICT_ATTRIB_STP attribStp;

                stringToTreat.replace(pos, curTag.size() + 1, varPrefix + varAlias + "_");
                pos += varPrefix.length() + 2;
                posEnd = stringToTreat.find_first_of(" \t()\n,;", pos);

                if (posEnd != string::npos)
                {
                    attribStr = stringToTreat.substr(pos, posEnd - pos);
                }
                else
                {
                    attribStr = stringToTreat.substr(pos);
                }

                attribStp = DBA_GetAttributeBySqlName(this->getDictEntityStp()->objectEn, attribStr.c_str());

                if (attribStp != NULL)
                {
                    string varStr = varAlias + "_" + attribStr;

                    if (this->ddlGenContextPtr->m_rdbmsEn == Oracle)
                    {
                        stringToTreat.replace(pos + attribStr.length(), 0, "(i)");
                    }

                    if (cursorDelcareSet.find(varStr) == cursorDelcareSet.end())
                    {
                        cursorDelcareSet.insert(varStr);

                        DdlGenVar *cursorVar = this->varHelperPtr->addVariable(varStr, attribStp->dataTpProgN);
                        cursorVar->m_bTriggerCursor = true;

                        switch (this->ddlGenContextPtr->m_rdbmsEn)
                        {
                            case Oracle:
                            {
                                string tableName = varPrefix + varStr;

                                selectStream
                                    << this->newLine() << tableName << " := " << varStr << "_TBL();";

                                assignStream
                                    << this->newLine() << tableName << ".EXTEND;"
                                    << this->newLine() << tableName << "(" << tableName << ".LAST) := :" << curTag.substr(1) << "." << attribStr << ";";

                                break;
                            }

                            case Sybase:
                            case MSSql:
                            {
                                if (bFirst == false)
                                {
                                    selectStream << "," << this->newLine();
                                    assignStream << "," << this->newLine();
                                }

                                selectStream << varAlias << "." << attribStr;
                                assignStream << varPrefix << varStr;

                                break;
                            }

                            case Nuodb:
                            case PostgreSQL:
                                break;
                        }
                        bFirst = false;
                    }

                    if (step)
                    {
                        bOld = true;
                    }
                    else
                    {
                        bNew = true;
                    }
                }
                else
                {
                    this->printMsg(RET_GEN_ERR_INVARG, "(for each row) Unknown attribute: " + attribStr);
                    ret = RET_GEN_ERR_INVARG;
                }
            }
            else if (this->ddlGenContextPtr->m_rdbmsEn == Oracle)
            {
                stringToTreat[pos] = ':';
            }
            else if (this->ddlGenContextPtr->m_rdbmsEn == Nuodb ||
                     this->ddlGenContextPtr->m_rdbmsEn == PostgreSQL)
            {
                stringToTreat.erase(pos, 1);
            }
        }

        if (step == 0)
        {
            step++;
            pos = 0;
            curTag.replace(1, 3, TAG_OLD);
            varAlias = "d";
        }
        else
        {
            curTag.clear();
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenTrigger::fillDdlGenSqlBlock()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-nuodb - LJE - 190913
**
*************************************************************************/
RET_CODE DdlGenTrigger::fillDdlGenSqlBlock(DdlGenSqlBlock &inputDdlGenSqlBlock, DdlGenSqlBlock &outputDdlGenSqlBlock, bool bNotBody)
{
    RET_CODE ret = RET_SUCCEED, gblRet = RET_SUCCEED;
    outputDdlGenSqlBlock.initStream()
        << this->scriptDdlGen->buildScript(inputDdlGenSqlBlock.initStream().str(), this->m_scptDllObjEn);
    ret = this->scriptDdlGen->lastErrRetCode;
    if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
    {
        gblRet = ret;
    }

    if (bNotBody == false)
    {
        outputDdlGenSqlBlock.bodyStream()
            << this->scriptDdlGen->buildScript(inputDdlGenSqlBlock.bodyStream().str(), this->m_scptDllObjEn);
        ret = this->scriptDdlGen->lastErrRetCode;
        if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
        {
            gblRet = ret;
        }
    }

    outputDdlGenSqlBlock.releaseStream()
        << this->scriptDdlGen->buildScript(inputDdlGenSqlBlock.releaseStream().str(), this->m_scptDllObjEn);
    ret = this->scriptDdlGen->lastErrRetCode;
    if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
    {
        gblRet = ret;
    }

    return gblRet;
}

/************************************************************************
**
**  Function    :   DdlGenTrigger::printForEachRowStatement()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 141212
**
*************************************************************************/
RET_CODE DdlGenTrigger::printForEachRowStatement(stringstream       &eachRowBeforeStream,
                                                 stringstream       &eachRowAfterStream,
                                                 stringstream       &outStream,
                                                 TRIGGER_POS_ENUM   triggerPos)
{
    RET_CODE ret = RET_SUCCEED;
    string cursorName;

    if (triggerPos == TriggerPos_BeforeStandard)
    {
        cursorName = "before_each_row_cur";
    }
    else if (triggerPos == TriggerPos_AfterStandard ||
             triggerPos == TriggerPos_AfterEachRow)
    {
        cursorName = "after_each_row_cur";

        if (triggerPos == TriggerPos_AfterEachRow &&
            this->ddlGenContextPtr->m_rdbmsEn == Nuodb && 
            this->m_afterStream.str().find_first_not_of(" \t\n") != string::npos)
        {
            eachRowAfterStream << this->m_afterStream.str() << endl;
        }
    }

    if (eachRowBeforeStream.str().find_first_not_of(" \t\n") != string::npos ||
        eachRowAfterStream.str().find_first_not_of(" \t\n") != string::npos ||
        (this->ddlGenContextPtr->m_rdbmsEn == Nuodb && this->m_beforeStream.str().find_first_not_of(" \t\n") != string::npos))
    {
        stringstream selectStream, assignStream, locCursorStream;
        std::set<string>  cursorDelcareSet;

        bool bFirst = true, bNew = false, bOld = false;

        this->setIndent(1);

        if (this->ddlGenContextPtr->m_rdbmsEn == Nuodb && this->m_beforeStream.str().find_first_not_of(" \t\n") != string::npos)
        {
            locCursorStream << this->m_beforeStream.str() << endl;
        }

        locCursorStream << eachRowBeforeStream.str() << endl << eachRowAfterStream.str();

        string curScript = locCursorStream.str();

        /* Treat #NEW and #OLD */
        this->treatNewOldVariable(triggerPos, curScript, selectStream, assignStream, cursorDelcareSet, bFirst, bNew, bOld);
        locCursorStream.clear();
        locCursorStream.str(curScript);

        if (this->ddlGenContextPtr->m_rdbmsEn == Sybase || 
            this->ddlGenContextPtr->m_rdbmsEn == MSSql)
        {
            this->scriptDdlGen->varHelperPtr->setInCursorName(cursorName);
        }

        string outStr = this->scriptDdlGen->buildScript(locCursorStream.str(), this->m_scptDllObjEn);
        ret = this->scriptDdlGen->lastErrRetCode;

        /* Check only in bootstrap mode */
        if (this->ddlGenContextPtr->ddlGenAction.m_installLevel > 8)
        {
            stringstream chkStream, currStream;
            currStream << outStr;
            this->removeComments(currStream, chkStream);

            if (chkStream.str().empty())
            {
                this->setIndent(-1);
                return ret;
            }
        }

        /* Treat new #NEW and #OLD */
        this->treatNewOldVariable(triggerPos, outStr, selectStream, assignStream, cursorDelcareSet, bFirst, bNew, bOld);

        if (bOld && this->currDmlEvent == DmlEvent_Insert)
        {
            ret = RET_DBA_ERR_INVDATA;
            this->printMsg(ret, "It's not allowed to access to #OLD in INSERT trigger!");
        }

        this->scriptDdlGen->varHelperPtr->clearInCursorName();

        if (this->ddlGenContextPtr->m_rdbmsEn == Sybase && bFirst == false)
        {
            outStream << this->newLine()
                << "declare " << cursorName << " cursor" << this->newLine()
                << "for" << this->newLine()
                << "select " << this->newLine()
                << selectStream.str();

            if (!bOld && bNew)
            {
                outStream << this->newLine()
                    << "from inserted i";
            }
            else if (bOld && !bNew)
            {
                outStream << this->newLine()
                    << "from deleted d";
            }
            else
            {
                int keyNbr = 0;
                DICT_ATTRIB_STP *keyTab = NULL;
                DICT_ATTRIB_ST udAttribSt;
                DICT_ATTRIB_STP udAttribTab = &udAttribSt;

                if (this->bUdTableTrig)
                {
                    strcpy(udAttribSt.sqlName, "ud_id");
                    keyNbr = 1;
                    keyTab = &udAttribTab;
                }
                else if (this->getDictEntityStp()->dbPKNbr > 0)
                {
                    keyNbr = this->getDictEntityStp()->dbPKNbr;
                    keyTab = this->getDictEntityStp()->dbPKTab;
                }
                else if (this->getDictEntityStp()->bkAttrNbr > 0)
                {
                    keyNbr = this->getDictEntityStp()->bkAttrNbr;
                    keyTab = this->getDictEntityStp()->bkAttr;
                }

                if (keyNbr == 0)
                {
                    this->printMsg(RET_GEN_ERR_INVARG, "(for each row) Unable to create trigger having mix OLD/NEW access without primary key nor business key!");
                    ret = RET_GEN_ERR_INVARG;
                }

                outStream << this->newLine()
                    << "from inserted i inner join deleted d on ";

                for (int kPos = 0; kPos < keyNbr; kPos++)
                {
                    if (kPos > 0)
						outStream << " and ";   /* PMSTA-21068 - TEB - 150819 */

                    outStream
                        << this->getWhereComp(string("i.") + keyTab[kPos]->sqlName,
                                              keyTab[kPos],
                                              string("d.") + keyTab[kPos]->sqlName,
                                              keyTab[kPos],
                                              "=",
                                              false);
                }
            }

            outStream << this->newLine()
                << "open " << cursorName << this->newLine()
                << "fetch " << cursorName << " into " << this->newLine()
                << assignStream.str();

            outStream << this->newLine()
                << "while (@@sqlstatus = 0)" << this->newLine()
                << "begin";

            outStream
                << endl << endl << outStr;

            outStream << this->newLine()
                << "fetch " << cursorName << " into " << this->newLine()
                << assignStream.str();

            outStream << this->newLine()
                << "end" << this->newLine()
                << "close " << cursorName << this->newLine()
                << "deallocate cursor " << cursorName << endl;
        }
        else if (this->ddlGenContextPtr->m_rdbmsEn == MSSql && bFirst == false)
        {
            outStream << this->newLine()
                << "declare " << cursorName << " cursor local" << this->newLine()
                << "for" << this->newLine()
                << "select " << this->newLine()
                << selectStream.str();

            if (!bOld && bNew)
            {
                outStream << this->newLine()
                    << "from inserted i";
            }
            else if (bOld && !bNew)
            {
                outStream << this->newLine()
                    << "from deleted d";
            }
            else
            {
                int keyNbr = 0;
                DICT_ATTRIB_STP *keyTab = NULL;
                DICT_ATTRIB_ST udAttribSt;
                DICT_ATTRIB_STP udAttribTab = &udAttribSt;

                if (this->bUdTableTrig)
                {
                    strcpy(udAttribSt.sqlName, "ud_id");
                    keyNbr = 1;
                    keyTab = &udAttribTab;
                }
                else if (this->getDictEntityStp()->dbPKNbr > 0)
                {
                    keyNbr = this->getDictEntityStp()->dbPKNbr;
                    keyTab = this->getDictEntityStp()->dbPKTab;
                }
                else if (this->getDictEntityStp()->bkAttrNbr > 0)
                {
                    keyNbr = this->getDictEntityStp()->bkAttrNbr;
                    keyTab = this->getDictEntityStp()->bkAttr;
                }

                if (keyNbr == 0)
                {
                    this->printMsg(RET_GEN_ERR_INVARG, "(for each row) Unable to create trigger having mix OLD/NEW access without primary key nor business key!");
                    ret = RET_GEN_ERR_INVARG;
                }

                outStream << this->newLine()
                    << "from inserted i inner join deleted d on ";

                for (int kPos = 0; kPos < keyNbr; kPos++)
                {
                    if (kPos > 0)
                        outStream << " and ";   /* PMSTA-21068 - TEB - 150819 */

                    outStream
                        << this->getWhereComp(string("i.") + keyTab[kPos]->sqlName,
                                              keyTab[kPos],
                                              string("d.") + keyTab[kPos]->sqlName,
                                              keyTab[kPos],
                                              "=",
                                              false);
                }
            }

            outStream << this->newLine()
                << "open " << cursorName << this->newLine()
                << "fetch " << cursorName << " into " << this->newLine()
                << assignStream.str();

            outStream << this->newLine()
                << "while (@@fetch_status = 0)" << this->newLine()
                << "begin";

            outStream
                << endl << endl << outStr;

            outStream << this->newLine()
                << "fetch " << cursorName << " into " << this->newLine()
                << assignStream.str();

            outStream << this->newLine()
                << "end" << this->newLine()
                << "close " << cursorName << this->newLine()
                << "deallocate " << cursorName << endl;
        }
        else
        {
            if (this->ddlGenContextPtr->m_rdbmsEn == Oracle &&
                triggerPos == TriggerPos_AfterStandard &&
                cursorDelcareSet.size() &&
                (bNew || bOld) &&
                outStr.find_first_not_of(" \t") != string::npos)
            {
                string tableName = "t_" + *(cursorDelcareSet.begin());
                DdlGenVar *initVar = this->varHelperPtr->addVariable("is_init_f", FlagType);
                initVar->strDefault = "0";

                this->m_beforeStream << selectStream.str();

                outStream << assignStream.str();

                this->setIndent(1);
                this->m_afterStream
                    << this->newLine() << "if " << initVar->printSqlName() << " = 1 then";
                this->setIndent(1);

                this->m_afterStream
                << this->newLine() << "if " << tableName << ".COUNT > 0 then"
                    << this->newLine() << "for i in " << tableName << ".first.." << tableName << ".last loop";

                this->m_afterStream << outStr;

                this->m_afterStream
                    << this->newLine() << "end loop;"
                    << this->newLine() << "end if;";

                this->setIndent(-1);
                this->m_afterStream
                    << this->newLine() << "end if;";
                this->setIndent(-1);
            }
            else
            {
                outStream << outStr;
            }
        }

        this->setIndent(-1);
    }
    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenTrigger::printBeforeStatement()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 141212
**
*************************************************************************/
RET_CODE DdlGenTrigger::printBeforeStatement()
{
    RET_CODE     ret = RET_SUCCEED, gblRet = RET_SUCCEED;
    stringstream currStream, chkStream;
    DdlGenSqlBlock initTrgStream, beforeStream, afterStream;

    std::set<std::string> beforeStreamVarSet;

    this->scriptDdlGen->setTriggerInfo(TriggerPos_Before, this->currDmlEvent, this->afterStreamTab[TriggerPos_After][this->currDmlEvent].str());

    this->varHelperPtr->copyVariables(this->beforeVarTab[this->currEventPos][this->currDmlEvent]);

    if (this->currEventPos == EventPos_All)
    {
        this->varHelperPtr->copyVariables(this->beforeVarTab[EventPos_Before][this->currDmlEvent]);
        this->varHelperPtr->copyVariables(this->beforeVarTab[EventPos_After][this->currDmlEvent]);
    }

    this->ddlGenContextPtr->bAvoidUserPrint = true;

    initTrgStream.initStream()
        << this->scriptDdlGen->buildScript(this->discardTriggerTab[TriggerPos_BeforeStandard][this->currDmlEvent].str(), this->m_scptDllObjEn);
    ret = this->scriptDdlGen->lastErrRetCode;
    if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
    {
        gblRet = ret;
    }

    ret = fillDdlGenSqlBlock(this->beforeStreamTab[TriggerPos_Before][this->currDmlEvent], initTrgStream);
    if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
    {
        gblRet = ret;
    }

    if (this->currEventPos == EventPos_Before || this->currEventPos == EventPos_All)
    {
        this->varHelperPtr->resetAccessVarNbr();
        ret = fillDdlGenSqlBlock(this->beforeStreamTab[TriggerPos_BeforeStandard][this->currDmlEvent], beforeStream);
        if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
        {
            gblRet = ret;
        }
        this->varHelperPtr->getAccededVarSet(beforeStreamVarSet);

        ret = fillDdlGenSqlBlock(this->beforeStreamTab[TriggerPos_AfterStandard][this->currDmlEvent], afterStream);
        if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
        {
            gblRet = ret;
        }
    }
    else
    {
        ret = fillDdlGenSqlBlock(this->beforeStreamTab[TriggerPos_AfterStandard][this->currDmlEvent], afterStream, true);
        if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
        {
            gblRet = ret;
        }
    }

    this->initVarSqlBlock << afterStream.initStream().str();

    this->ddlGenContextPtr->bAvoidUserPrint = false;

    currStream << beforeStream.bodyStream().str() << afterStream.bodyStream().str();
    this->removeComments(currStream, chkStream);
    if (chkStream.str().find_first_not_of(" \t\n") == string::npos)
    {
        currStream.str(string());
        currStream.clear();
    }

    if (this->ddlGenContextPtr->m_rdbmsEn == Oracle)
    {
        if (initTrgStream.bodyStream().str().find_first_not_of(" \t\n") != string::npos ||
            currStream.str().find_first_not_of(" \t\n") != string::npos)
        {
            DdlGenVar *discardVar = this->varHelperPtr->getVariable("discard_trigger_flg", false);
            DdlGenVar *initVar = this->varHelperPtr->addVariable("is_init_f", FlagType);
            initVar->strDefault = "0";
            this->m_bIsInitPrinted = false;

            this->setIndent(1);
            this->m_beforeStream
                << this->newLine() << initTrgStream.str()
                << afterStream.bodyStream().str();
            this->setIndent(-1);

            this->removeComments(beforeStream.bodyStream(), chkStream);

            if (chkStream.str().find_first_not_of(" \t\n") != string::npos)
            {
                if (beforeStreamVarSet.empty() ||
                    (beforeStreamVarSet.find("user_id") == beforeStreamVarSet.end() &&
                     beforeStreamVarSet.find("data_profile_id") == beforeStreamVarSet.end() &&
                     beforeStreamVarSet.find("data_profile_id_user") == beforeStreamVarSet.end()))
                {
                    this->m_beforeStream.initStream()
                        << beforeStream.str();
                }
                else
                {
                    this->m_beforeStream
                        << beforeStream.str();
                }

                this->m_beforeStream
                    << this->newLine() << this->getCmdAssignByValue(*initVar, "1");

                if (discardVar != NULL)
                {
                    this->m_beforeStream.initStream()
                        << this->newLine() << "if " << discardVar->printSqlName() << " = 0 "
                        << this->newLine() << "then" << endl;

                    this->setIndent(1);
                }

                if (discardVar != NULL)
                {
                    this->m_beforeStream.releaseStream() << this->newLine() << "end if;";
                    this->setIndent(-1);
                }

                this->setIndent(-1);
            }
        }
    }
    else
    {
        this->m_beforeStream.initStream()
            << initTrgStream.initStream().str();

        if (initTrgStream.bodyStream().str().find_first_not_of(" \t\n") != string::npos ||
            currStream.str().find_first_not_of(" \t\n") != string::npos)
        {
            this->m_beforeStream
                << initTrgStream.bodyStream().str()
                << endl
                << currStream.str();
        }
    }

    this->m_afterStream.releaseStream()
        << initTrgStream.releaseStream().str();

    if (this->ddlGenContextPtr->m_rdbmsEn == PostgreSQL)
    {
        this->discardTriggerTab[TriggerPos_BeforeStandard][this->currDmlEvent].clear();
        this->discardTriggerTab[TriggerPos_BeforeStandard][this->currDmlEvent].str(string());
    }

    return gblRet;
}

/************************************************************************
**
**  Function    :   DdlGenTrigger::printBeforeEachRowStatement()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 141212
**
*************************************************************************/
RET_CODE DdlGenTrigger::printBeforeEachRowStatement()
{
    RET_CODE ret = RET_SUCCEED;
    stringstream currStream, chkStream;

    this->scriptDdlGen->setTriggerInfo(TriggerPos_BeforeEachRow, this->currDmlEvent, this->afterStreamTab[TriggerPos_After][this->currDmlEvent].str());

    this->initChangeSetManagement();

    this->varHelperPtr->copyVariables(this->beforeEachRowVarTab[this->currEventPos][this->currDmlEvent]);

    if (this->currEventPos == EventPos_All)
    {
        this->varHelperPtr->copyVariables(this->beforeEachRowVarTab[EventPos_Before][this->currDmlEvent]);
        this->varHelperPtr->copyVariables(this->beforeEachRowVarTab[EventPos_After][this->currDmlEvent]);
    }

    ret = this->printForEachRowStatement(this->beforeEachRowStreamTab[TriggerPos_BeforeStandard][this->currDmlEvent],
                                         this->beforeEachRowStreamTab[TriggerPos_AfterStandard][this->currDmlEvent],
                                         currStream,
                                         TriggerPos_BeforeStandard);
    this->removeComments(currStream, chkStream);
    if (chkStream.str().find_first_not_of(" \t\n") == string::npos)
    {
        currStream.str(string());
        currStream.clear();
    }
    chkStream.str(string());
    chkStream.clear();

    bool bPrintCurr = currStream.str().find_first_not_of(" \t\n") != string::npos;

    if (bPrintCurr || this->m_bIsInitPrinted == false)                                /* PMSTA-26250 - LJE - 170530 */
    {
        if (this->ddlGenContextPtr->m_rdbmsEn == Oracle)
        {
            DdlGenVar *discardVar = this->varHelperPtr->getVariable("discard_trigger_flg", false);
            DdlGenVar *initVar = this->varHelperPtr->getVariable("is_init_f", false);

            if (initVar != NULL && this->m_beforeStream.bodyStream().str().empty() == false)
            {
                this->m_bIsInitPrinted = true;
                this->setIndent(1);
                this->m_beforeEachRowStream
                    << this->newLine() << "if " << initVar->printSqlName() << " = 0"
                    << this->newLine() << "then"
                    << this->newLine() << this->getCmdAssignByValue(*initVar, "1")
                    << this->m_beforeStream.bodyStream().str()
                    << this->newLine() << "end if;";
                this->setIndent(-1);
            }

            if (bPrintCurr)
            {
                if (discardVar != NULL)
                {
                    this->m_beforeEachRowStream.initStream()
                        << this->newLine() << "if " << discardVar->printSqlName() << " = 0 "
                        << this->newLine() << "then" << endl;

                    this->setIndent(1);
                }

                this->m_beforeEachRowStream << currStream.str();

                if (discardVar != NULL)
                {
                    this->m_beforeEachRowStream.releaseStream() << this->newLine() << "end if;";
                    this->setIndent(-1);
                }
            }
        }
        else
        {
            this->m_beforeEachRowStream
                << currStream.str();
        }
    }
    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenTrigger::printAfterEachRowStatement()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 141212
**
*************************************************************************/
RET_CODE DdlGenTrigger::printAfterEachRowStatement()
{
    RET_CODE ret = RET_SUCCEED;
    stringstream currStream, chkStream, locEmptyStream, afterStream;

    this->scriptDdlGen->setTriggerInfo(TriggerPos_AfterEachRow, this->currDmlEvent, this->afterStreamTab[TriggerPos_After][this->currDmlEvent].str());

    this->varHelperPtr->copyVariables(this->afterEachRowVarTab[this->currEventPos][this->currDmlEvent]);

    if (this->currEventPos == EventPos_All)
    {
        this->varHelperPtr->copyVariables(this->afterEachRowVarTab[EventPos_Before][this->currDmlEvent]);
        this->varHelperPtr->copyVariables(this->afterEachRowVarTab[EventPos_After][this->currDmlEvent]);
    }

    ret = this->printObjectModifStat();

    ret = this->printForEachRowStatement(this->afterEachRowStreamTab[TriggerPos_BeforeStandard][this->currDmlEvent],
                                         this->afterEachRowStreamTab[TriggerPos_AfterStandard][this->currDmlEvent],
                                         currStream,
                                         TriggerPos_AfterStandard);

    if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
    {
	    ret = this->printForEachRowStatement(this->afterEachRowStreamTab[TriggerPos_AfterEachRow][this->currDmlEvent],
	                                         locEmptyStream,
	                                         afterStream,
	                                         TriggerPos_AfterEachRow);
    }

    this->removeComments(currStream, chkStream);
    if (chkStream.str().find_first_not_of(" \t\n") == string::npos)
    {
        currStream.str(string());
        currStream.clear();
    }
    chkStream.str(string());
    chkStream.clear();

    if (currStream.str().find_first_not_of(" \t\n") != string::npos ||
        afterStream.str().find_first_not_of(" \t\n") != string::npos)
    {
        if (this->ddlGenContextPtr->m_rdbmsEn == Oracle)
        {
            DdlGenVar *initVar = this->varHelperPtr->getVariable("is_init_f", false);
            if (initVar != NULL && this->m_beforeStream.bodyStream().str().empty() == false)
            {
                this->setIndent(1);
                this->m_bIsInitPrinted = true;
                this->m_afterEachRowStream
                    << this->newLine() << "if " << initVar->printSqlName() << " = 0"
                    << this->newLine() << "then"
                    << this->newLine() << this->getCmdAssignByValue(*initVar, "1")
                    << this->m_beforeStream.bodyStream().str()
                    << this->newLine() << "end if;";
                this->setIndent(-1);
            }

            if (currStream.str().find_first_not_of(" \t\n") != string::npos)
            {
                DdlGenVar *discardVar = this->varHelperPtr->getVariable("discard_trigger_flg", false);

                if (discardVar != NULL)
                {
                    this->m_afterEachRowStream.initStream()
                        << this->newLine() << "if " << discardVar->printSqlName() << " = 0 "
                        << this->newLine() << "then" << endl;

                    this->setIndent(1);
                }

                this->m_afterEachRowStream << currStream.str();

                if (discardVar != NULL)
                {
                    this->setIndent(-1);
                    this->m_afterEachRowStream.releaseStream() << this->newLine() << "end if;";
                }
            }

            this->m_afterEachRowStream.bodyStream() << afterStream.str();
        }
        else
        {
            this->m_afterEachRowStream
                << currStream.str()
                << afterStream.str();
        }
    }
    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenTrigger::printAfterStatement()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 141212
**
*************************************************************************/
RET_CODE DdlGenTrigger::printAfterStatement()
{
    RET_CODE ret = RET_SUCCEED, gblRet = RET_SUCCEED;
    stringstream   currStream, chkStream;
    DdlGenSqlBlock releaseStream;

    this->scriptDdlGen->setTriggerInfo(TriggerPos_After, this->currDmlEvent, this->afterStreamTab[TriggerPos_After][this->currDmlEvent].str());

    this->varHelperPtr->copyVariables(this->afterVarTab[this->currEventPos][this->currDmlEvent]);

    if (this->currEventPos == EventPos_All)
    {
        this->varHelperPtr->copyVariables(this->afterVarTab[EventPos_Before][this->currDmlEvent]);
        this->varHelperPtr->copyVariables(this->afterVarTab[EventPos_After][this->currDmlEvent]);
    }

    currStream
        << this->scriptDdlGen->buildScript(this->afterStreamTab[TriggerPos_BeforeStandard][this->currDmlEvent].str(), this->m_scptDllObjEn) << endl;
    ret = this->scriptDdlGen->lastErrRetCode;
    if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
    {
        gblRet = ret;
    }

    releaseStream
        << this->scriptDdlGen->buildScript(this->afterStreamTab[TriggerPos_After][this->currDmlEvent].str(), this->m_scptDllObjEn);
    ret = this->scriptDdlGen->lastErrRetCode;
    if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
    {
        gblRet = ret;
    }

    currStream
        << this->scriptDdlGen->buildScript(this->afterStreamTab[TriggerPos_AfterStandard][this->currDmlEvent].str(), this->m_scptDllObjEn);
    ret = this->scriptDdlGen->lastErrRetCode;
    if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
    {
        gblRet = ret;
    }
    currStream
        << this->scriptDdlGen->buildScript(this->discardTriggerTab[TriggerPos_AfterStandard][this->currDmlEvent].str(), this->m_scptDllObjEn);
    ret = this->scriptDdlGen->lastErrRetCode;
    if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
    {
        gblRet = ret;
    }
    this->removeComments(currStream, chkStream);
    if (chkStream.str().find_first_not_of(" \t\n") == string::npos)
    {
        currStream.str(string());
        currStream.clear();
    }

    if (releaseStream.bodyStream().str().find_first_not_of(" \t\n") != string::npos ||
        currStream.str().find_first_not_of(" \t\n") != string::npos ||
        this->m_afterStream.str().empty() == false)
    {
        if (this->ddlGenContextPtr->m_rdbmsEn == Oracle)
        {
            DdlGenVar *discardVar = this->varHelperPtr->getVariable("discard_trigger_flg", false);

            this->setIndent(1);

            if (currStream.str().empty() == false)
            {
                if (discardVar != NULL)
                {
                    this->m_afterStream.initStream()
                        << this->newLine() << "if " << discardVar->printSqlName() << " = 0 "
                        << this->newLine() << "then" << endl;
                    this->setIndent(1);
                }

                this->m_afterStream
                    << currStream.str();

                if (discardVar != NULL)
                {
                    this->setIndent(-1);
                    this->m_afterStream.releaseStream() << this->newLine() << "end if;";
                }
            }

            this->m_afterStream.releaseStream()
                << releaseStream.str();

            this->setIndent(-1);
            this->m_afterStream.releaseStream();
        }
        else
        {
            this->m_afterStream
                << currStream.str()
                << releaseStream.str();
        }
    }
    return gblRet;
}


/************************************************************************
**
**  Function    :   DdlGenTrigger::printFooter()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 111116
**
*************************************************************************/
RET_CODE DdlGenTrigger::printFooter()
{
    RET_CODE ret=RET_SUCCEED;
    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenTrigger::initDeleteRule()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13122 - LJE - 120515
**
*************************************************************************/
RET_CODE DdlGenTrigger::initDeleteRule(DICT_ENTITY_STP refDictEntityStp, DICT_ATTRIB_STP attribStp, bool bForceCascadeOnTrigger)
{
    RET_CODE             ret=RET_SUCCEED;

    REF_DELETE_RULE_ENUM refDelRuleEn = attribStp->refDeleteRuleEn;

    stringstream         currStream;
    DICT_ENTITY_STP      currDictEntityStp;

    currDictEntityStp = this->getDictEntityStp();

    if (currDictEntityStp == NULL)
    {
        return RET_GEN_INFO_NOACTION;
    }

    if (refDictEntityStp->entDictId == currDictEntityStp->entDictId &&
        attribStp->refEntDictId != 0)
    {
        OBJECT_ENUM refObjEn;
        DBA_GetObjectEnum(attribStp->refEntDictId,  &refObjEn);
        refDictEntityStp = DBA_GetDictEntitySt(refObjEn);
    }

    /* PMSTA-36158 - LJE - 190627 */
	if (this->isReferenceOnFk() &&
		refDelRuleEn == RefDelRule_Inherited &&
        attribStp->linkAttrDictTab.empty() == false &&
        attribStp->custFlg == TRUE)
    {
        for (size_t i = 0; i < attribStp->linkAttrDictTab.size(); i++)
        {
            if (attribStp->linkAttrDictTab[i]->entDictId == currDictEntityStp->entDictId)
            {
                refDelRuleEn = attribStp->linkAttrDictTab[i]->refDeleteRuleEn;
                break;
            }
        }
    }

    /* No rule, or constraints on foreign key, nothing to do */
    if (refDelRuleEn == RefDelRule_None ||
        refDelRuleEn == RefDelRule_NoAction ||
        refDelRuleEn == RefDelRule_Inherited)
    {
        return RET_GEN_INFO_NOACTION;
    }

    if (bForceCascadeOnTrigger == false &&
        this->isReferenceOnFk() &&
        attribStp->refCheckRuleEn == RefChkRule_Checked &&
        attribStp->custFlg == FALSE) /* PMSTA-36158 - LJE - 190613 */
    {
        if (attribStp->logicalFlg == FALSE)
        {
            return RET_GEN_INFO_NOACTION;
        }
        else if (attribStp->linkedAttrDictStp == NULL || attribStp->linkedAttrDictStp->linkedAttrDictStp == NULL)
        {
            return RET_GEN_INFO_NOACTION;
        }
    }

    if (attribStp->logicalFlg == TRUE)
    {
        if (attribStp->linkedAttrDictStp != NULL &&
            attribStp->linkedAttrDictStp->refDeleteRuleEn != RefDelRule_Inherited)
        {
            ret = RET_DBA_ERR_INVDATA;
            this->printMsg(ret,
                           string("Inconsistent linked attribute (") +
                           attribStp->sqlName +
                           "), The linked attribute(" +
                           refDictEntityStp->mdSqlName + "." + attribStp->linkedAttrDictStp->sqlName +
                           ") must have the reference delete rule set to 'Inherited'");
        }

        if (this->isReferenceOnFk() &&
            attribStp->linkedAttrDictStp != NULL &&
            attribStp->linkedAttrDictStp->refCheckRuleEn == RefChkRule_Checked &&
            attribStp->linkedAttrDictStp->linkedAttrDictStp == NULL &&
            refDictEntityStp->primKeyNbr == 1)
        {
            return RET_GEN_INFO_NOACTION;
        }
    }

    string viewExt(attribStp->custFlg == TRUE || (attribStp->linkedAttrDictStp && attribStp->linkedAttrDictStp->custFlg == TRUE) ? "_uvw" : "");
    switch(refDelRuleEn)
    {
    case RefDelRule_SetNULL:
        currStream
            << this->newLine() << "#NO_MULTI_ENTITY"
            << this->newLine() << "#UPDATE " << this->getEntitySqlName(refDictEntityStp, TargetTable_Main, true) << viewExt << " null"
            << this->newLine() << attribStp->sqlName << " = null"
            << this->newLine() << "#WHERE"
            << this->newLine() << this->getPkAccessWhere(refDictEntityStp, attribStp, "", "#OLD", true)
            << this->newLine() << "#END"
            << this->newLine() << "#MULTI_ENTITY" << endl;
        this->pushAfterEachRowStatement(currStream.str(), TriggerPos_AfterStandard, this->currDmlEvent);
        break;

    case RefDelRule_Restrict:
        currStream
            << this->newLine() << "#NO_MULTI_ENTITY"
            << this->newLine() << "#IF_EXISTS (select 'x'"
            << this->newLine() << "	   from " << this->getEntityFullSqlName(refDictEntityStp, TargetTable_Main, true) << viewExt << " E"
            << this->newLine() << "	   where " << this->getPkAccessWhere(refDictEntityStp, attribStp, "E", "#OLD", false) << ")"
            << this->newLine() << "#{"
            << this->newLine() << "    #APPL_RAISERROR" << " 20010, " << this->getDdlObjSqlName() << ","
            << this->newLine() << "			   " << currDictEntityStp->mdSqlName << ","
            << this->newLine() << "			   " << this->getEntityFullSqlName(refDictEntityStp) << ","
            << this->newLine() << "			   " << attribStp->sqlName
            << this->newLine() << "	#ROLLBACK_TRAN"
            << this->newLine() << "	#RETURN"
            << this->newLine() << "#}"
            << this->newLine() << "#MULTI_ENTITY" << endl << endl;
        this->pushBeforeEachRowStatement(currStream.str(), TriggerPos_AfterStandard, this->currDmlEvent);
        break;

    case RefDelRule_CascadeDelete:
        currStream
            << this->newLine() << "#NO_MULTI_ENTITY"
            << this->newLine() << "#DELETE " << this->getEntitySqlName(refDictEntityStp, TargetTable_Main, true) << viewExt
            << this->newLine() << "#WHERE"
            << this->newLine() << this->getPkAccessWhere(refDictEntityStp, attribStp, "", "#OLD", true)
            << this->newLine() << "#END"
            << this->newLine() << "#MULTI_ENTITY" << endl;
        this->pushAfterEachRowStatement(currStream.str(), TriggerPos_AfterStandard, this->currDmlEvent);
        break;

    case RefDelRule_None:
    case RefDelRule_NoAction:
    default:
        break;

    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenTrigger::initCascadeDelRef()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13122 - LJE - 120515
**
*************************************************************************/
RET_CODE DdlGenTrigger::initCascadeDelRef()
{
    RET_CODE          ret=RET_SUCCEED;

    if (this->currDmlEvent != DmlEvent_Delete || this->bUdTableTrig || this->ddlGenContextPtr->ddlGenAction.m_installLevel > 6)
    {
        return ret;
    }

    auto  dictEntityStp = this->getDictEntityStp();
    if (dictEntityStp->primKeyNbr != 1 ||
        dictEntityStp->primKeyTab == NULL)
    {
        return  ret;
    }

    this->setIndent(1);

    map<DICT_T, DICT_ATTRIB_STP> refEntityAttribMap;

    auto& dictEntityVector = DICT_GetDictEntityVector();

    for (auto entityIt = dictEntityVector.begin(); entityIt != dictEntityVector.end(); ++entityIt)
    {
        DICT_ENTITY_STP refDictEntityStp = *entityIt;

        if (refDictEntityStp != NULL &&
            refDictEntityStp->objectEn != Empty &&
            refDictEntityStp->logicalFlg == FALSE &&
            refDictEntityStp->databaseName.empty() == false &&
            refDictEntityStp->isPhysicalEntity(this->targetTableEn) &&
            refDictEntityStp->entNatEn != EntityNat_TempTable)
        {
            for (auto& refDictAttribStp : refDictEntityStp->attr)
            {
                if (refDictAttribStp->attrDictId < 0 ||
                    refDictAttribStp->precompFlg == TRUE ||
                    refDictAttribStp->isPhysicalAttribute() == false)
                    continue;

                if (refDictAttribStp->refEntDictId == this->getDictEntityStp()->entDictId ||
                    (refDictAttribStp->refEntDictId == 0 &&
                     refDictAttribStp->linkedAttrDictStp != NULL &&
                     refDictAttribStp->linkedAttrDictStp->entDictId == entityDictId))
                {
                    refEntityAttribMap[refDictAttribStp->attrDictId] = refDictAttribStp;
                }
            }
        }
    }

    for (auto attribIt = refEntityAttribMap.begin(); attribIt != refEntityAttribMap.end(); ++attribIt)
    {
        this->initDeleteRule(attribIt->second->dictEntityStp, attribIt->second, false);
    }


    /* PMSTA-43103 - LJE - 210106 */
    if (dictEntityStp->entNatEn == EntityNat_DerivedEntity &&
        dictEntityStp->dbRuleEn == DbRule_PrimaryKeyTable &&
        dictEntityStp->linkedEntityStp != nullptr)
    {
        if (dictEntityStp->linkedEntityStp->shadowEntityStp != nullptr)
        {
            DICT_ENTITY_STP shEntityStp(dictEntityStp->linkedEntityStp->shadowEntityStp);
            DICT_ATTRIB_ST  pkAttribSt(*shEntityStp->primKeyTab[0]);

            pkAttribSt.refDeleteRuleEn  = RefDelRule_CascadeDelete;
            pkAttribSt.refEntDictId     = dictEntityStp->entDictId;
            pkAttribSt.refDictEntityStp = dictEntityStp;

            this->initDeleteRule(shEntityStp, &pkAttribSt, true);
        }

        DICT_ENTITY_STP mainEntityStp(dictEntityStp->linkedEntityStp);
        DICT_ATTRIB_ST  mainAttribSt(*mainEntityStp->primKeyTab[0]);

        mainAttribSt.refDeleteRuleEn  = RefDelRule_CascadeDelete;
        mainAttribSt.refEntDictId     = dictEntityStp->entDictId;
        mainAttribSt.refDictEntityStp = dictEntityStp;

        this->initDeleteRule(mainEntityStp, &mainAttribSt, true);
    }

    /* OCS-43062 - LJE - 130909 */
    for (auto attribIt = dictEntityStp->logicalTab.begin(); attribIt != dictEntityStp->logicalTab.end(); ++attribIt)
    {
        DICT_ATTRIB_STP attribStp = *attribIt;

        if (attribStp->logicalFkFlg == TRUE ||
            (attribStp->refEntDictId != 0 &&
             (attribStp->linkedAttrDictStp == NULL || attribStp->linkedAttrDictStp->entDictId != dictEntityStp->entDictId)))
        {
            this->initDeleteRule(dictEntityStp, attribStp, false);
        }
    }

    this->setIndent(-1);
    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenTrigger::getAllDbTrigger()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   
**
*************************************************************************/
std::map<DdlObjDefKey, DdlObjDef> &DdlGenTrigger::getAllDbTrigger()
{
    bool bToLoad = false;
    if (this->getDictEntityStp()->isPhysicalEntity(TargetTable_Main) &&
        this->getDdlObjEn() == DdlObj_Trigger)
    {
        bToLoad = true;
    }
    else if (this->getDictEntityStp()->custAuthFlg == TRUE &&
             this->getDictEntityStp()->isPhysicalEntity(TargetTable_UserDefinedFields) &&
             this->getDdlObjEn() == DdlObj_TriggerUdField)
    {
        bToLoad = true;
    }

    if (bToLoad &&
        this->m_dbTriggerLoadSet.find(this->getDdlObjEn()) == this->m_dbTriggerLoadSet.end())
    {
        this->getAllDdlObjListFromDb(this->m_allDbTriggerMap,
                                     this->ddlGenContextPtr->getDdlDestDbName(),
                                     (this->getDdlObjEn() == DdlObj_Trigger ? this->getDictEntityStp()->dbSqlName : this->getDictEntityStp()->custSqlName),
                                     string(),
                                     this->getDdlObjEn());
        this->m_dbTriggerLoadSet.insert(this->getDdlObjEn());
    }

    return this->m_allDbTriggerMap;
}

/************************************************************************
**
**  Function    :   DdlGenTrigger::setRootEntityManagementNeeded()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-32982 - LJE - 181016
**
*************************************************************************/
void DdlGenTrigger::setRootEntityManagementNeeded()
{
    this->ddlGenContextPtr->bRootEntityManagement = false;

    if (this->targetTableEn != TargetTable_Main ||
        strcasecmp(this->ddlGenContextPtr->getMainDbName().c_str(), this->getTargetDBName().c_str()) != 0)
    {
        return;
    }

    for (auto entityIt = DICT_GetDictEntityVector().begin(); entityIt != DICT_GetDictEntityVector().end(); ++entityIt)
    {
        DICT_ENTITY_STP   refDictEntityStp = *entityIt;

        if (refDictEntityStp != NULL &&
            refDictEntityStp->objectEn != Empty &&
            refDictEntityStp->logicalFlg == FALSE &&
            refDictEntityStp->databaseName.empty() == false &&
            refDictEntityStp->isPhysicalEntity(this->targetTableEn) &&
            refDictEntityStp->entNatEn != EntityNat_TempTable)
        {
            for (auto& refDictAttribStp : refDictEntityStp->attr)
            {
                if (refDictAttribStp->attrDictId < 0 ||
                    refDictAttribStp->logicalFlg == TRUE ||
                    refDictAttribStp->precompFlg == TRUE ||
                    refDictAttribStp->isPhysicalAttribute() == false)
                    continue;

                if (refDictAttribStp->refEntDictId == 0 &&
                    refDictAttribStp->linkedAttrDictStp != NULL &&
                    refDictAttribStp->linkedAttrDictStp->entDictId == entityDictId)
                {
                    this->ddlGenContextPtr->bRootEntityManagement = true;
                    return;
                }
            }
        }
    }
}


/************************************************************************
**
**  Function    :   DdlGenTrigger::attribToCheck()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13122 - LJE - 120515
**
*************************************************************************/
bool DdlGenTrigger::attribToCheck(DICT_ATTRIB_STP attribStp)
{
    if (attribStp != nullptr &&
        (this->isReferenceOnFk() == false ||
        attribStp->refDeleteRuleEn == RefDelRule_None ||
        attribStp->refDeleteRuleEn == RefDelRule_NoAction ||
        attribStp->refCheckRuleEn == RefChkRule_CheckedZeroAllowed ||
         (attribStp->refDictEntityStp != nullptr && attribStp->refDictEntityStp->objectEn == Tp) ||      /* PMSTA-36158 - LJE - 190627 */
        attribStp->refEntDictId == 0) &&                                                                 /* PMSTA-26108 - LJE - 171201 */
        attribStp->logicalFlg == FALSE &&
        attribStp->precompFlg == FALSE &&
        attribStp->refEntDictId != this->emptyDictId &&
        (attribStp->refEntDictId != 0 || attribStp->linkedAttrDictStp) &&                                /* PMSTA-26108 - LJE - 171201 */
        (attribStp->calcEn == DictAttr_Physical || attribStp->calcEn == DictAttr_PhysSpecUpd) &&
        (attribStp->dataTpProgN == IdType || attribStp->dataTpProgN == DictType) &&
        this->bUdTableTrig == (attribStp->custFlg == TRUE))
    {
        if (attribStp->refCheckRuleEn == RefChkRule_None ||
            attribStp->refCheckRuleEn == RefChkRule_NotChecked)
        {
            return false;
        }
        return true;
    }

    return false;
}

/************************************************************************
**
**  Function    :   DdlGenTrigger::getCurrModifDate()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 141222
**
*************************************************************************/
string DdlGenTrigger::getCurrModifDate(DdlGenVarHelper  *targetVarHelperPtr)
{
    string varCurrModifDate = "curr_modif_d";

    targetVarHelperPtr->addVariable(varCurrModifDate, DatetimeType, DdlGenDbi::getCmdGetDateTime()); /* PMSTA-25331 - TEB - 20171018 - Need millisecond precision for DateTime */

    return varCurrModifDate;
}

/************************************************************************
**
**  Function    :   DdlGenTrigger::getCurrModifDate()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 141222
**
*************************************************************************/
string DdlGenTrigger::getCurrUser(DdlGenVarHelper  *targetVarHelperPtr)
{
    string varCurrUser = "user_id";

    this->ddlGenContextPtr->bUserId = true;
    targetVarHelperPtr->addVariable(varCurrUser, IdType);

    return varCurrUser;
}


/************************************************************************
**
**  Function    :   DdlGenTrigger::getTableModifStatEntityDictId()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-23300 - TEB - 160622
**
*************************************************************************/
DICT_T DdlGenTrigger::getTableModifStatEntityDictId()
{
	DICT_T   modifStatEntityDictId = this->getDictEntityStp()->entDictId;

    if (this->getDictEntityStp()->linkedEntityStp != nullptr &&
            this->getDictEntityStp()->linkedEntityStp->dbRuleEn != DbRule_Template)
    {
        /*PMSTA-58225 - vpr - 20240730 if parent is template entity then use original entity*/
        modifStatEntityDictId = this->getDictEntityStp()->linkedEntityDictId;
    }
    
	return modifStatEntityDictId;
}


/************************************************************************
**
**  Function    :   DdlGenTrigger::initUdFieldsManagment()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14452 - LJE - 121102
**
*************************************************************************/
RET_CODE DdlGenTrigger::initUdFieldsManagment()
{
    RET_CODE ret=RET_SUCCEED;

    this->setIndent(2);
    if (this->getDictEntityStp()->custAuthFlg == TRUE &&        /* PMSTA-32145 - LJE - 180721 */
        this->udTableName.empty() == false &&
        this->getDictEntityStp()->primKeyNbr == 1)
    {
        if (this->bUdTableTrig == false)
        {
            /* PMSTA-29748 - LJE - 180109 */
            stringstream partionSetStream, partionDeclStream;

            if (this->currDmlEvent != DmlEvent_Delete &&
                this->getDictEntityStp()->partAuthEn == FeatureAuth_Enable)
            {
                for (auto it = this->getDictEntityStp()->attribMap.begin(); it != this->getDictEntityStp()->attribMap.end(); ++it)
                {
                    if (it->second->calcEn == DictAttr_PhysicalPartition &&
                        it->second->featureEn != XdEntityFeatureFeatureEn::MultiBusinessEntityManagement)            /* PMSTA-34367 - LJE - 190128 */
                    {
                        partionSetStream << this->newLine() << it->second->sqlName << " = #NEW." << it->second->sqlName;
                        partionDeclStream << this->newLine() << it->second->sqlName;
                    }
                }
            }

            if (this->currDmlEvent == DmlEvent_Insert)
            {
                this->afterEachRowStreamTab[TriggerPos_AfterEachRow][this->currDmlEvent]
                    << this->newLine() << "#INSERT " << this->udTableName << " null " << this->getDictEntityStp()->mdSqlName
                    << this->newLine() << this->getUdIdSqlName()
                    << partionDeclStream.str()
                    << this->newLine() << "#VALUES"
                    << this->newLine() << this->getUdIdSqlName() << " = " << "#NEW." << this->getDictEntityStp()->primKeyTab[0]->sqlName
                    << partionSetStream.str()
                    << this->newLine() << "#END" << endl;
            }
            else if (this->currDmlEvent == DmlEvent_Delete)
            {
                this->afterEachRowStreamTab[TriggerPos_AfterEachRow][this->currDmlEvent]
                    << this->newLine() << "#DELETE " << this->udTableName
                    << this->newLine() << "#WHERE"
                    << this->newLine() << this->getUdIdSqlName() << " = #OLD." << this->getDictEntityStp()->primKeyTab[0]->sqlName
                    << this->newLine() << "#END" << endl;
            }
            /* PMSTA-29748 - LJE - 180109 */
            else if (this->currDmlEvent == DmlEvent_Update)
            {
                if (partionSetStream.str().empty() == false)
                {
                    this->afterEachRowStreamTab[TriggerPos_AfterEachRow][this->currDmlEvent]
                        << this->newLine() << "#UPDATE " << this->udTableName << " null"
                        << partionSetStream.str()
                        << this->newLine() << "#WHERE"
                        << this->newLine() << this->getUdIdSqlName() << " = #OLD." << this->getDictEntityStp()->primKeyTab[0]->sqlName
                        << this->newLine() << "#END" << endl;
                }
            }
        }
    }
    this->setIndent(-2);
    return ret;
}


/************************************************************************
**
**  Function    :   DdlGenTrigger::initChangeSetManagement()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26250 - LJE - 170424
**
*************************************************************************/
RET_CODE DdlGenTrigger::initChangeSetManagement()
{
    RET_CODE ret = RET_SUCCEED;

    if (this->targetTableEn == TargetTable_UserDefinedFields)
    {
        return ret;
    }

    string keyStr = "check_lock";

    if (this->getDictEntityStp()->dbRuleEn == DbRule_PrimaryKeyTable)
    {
        keyStr.append("_pk");
    }

    switch (this->currDmlEvent)
    {
        case DmlEvent_Insert:
            keyStr.append("_ins");
            break;

        case DmlEvent_Update:
            keyStr.append("_upd");
            break;

        case DmlEvent_Delete:
            keyStr.append("_del");
            break;
    }

    if (this->getDictEntityStp()->dbRuleEn == DbRule_PrimaryKeyTable)
    {
        DdlGenCfgTemplateKey cfgKey(CfgTemplate_ChangeSet,
                                    this->ddlGenContextPtr->getTemplateVersion(),
                                    DdlObj_Trigger,
                                    keyStr);

        auto lockTemplate = this->ddlGenContextPtr->getTemplateFileHelper().getCfgTemplate(cfgKey);

        if (lockTemplate && lockTemplate->bodyStr.empty() == false)
        {
            this->beforeEachRowStreamTab[TriggerPos_BeforeStandard][this->currDmlEvent] << endl << lockTemplate->bodyStr;
        }
    }
    else if (this->getDictEntityStp()->changeSetAuthEn == FeatureAuth_Enable &&
             this->getDictEntityStp()->dbRuleEn == DbRule_ShadowTable)
    {
        DdlGenCfgTemplateKey cfgKey(CfgTemplate_Shadow,
                                    this->ddlGenContextPtr->getTemplateVersion(),
                                    DdlObj_Trigger,
                                    keyStr);

        auto lockTemplate = this->ddlGenContextPtr->getTemplateFileHelper().getCfgTemplate(cfgKey);

        if (lockTemplate && lockTemplate->bodyStr.empty() == false)
        {
            this->beforeEachRowStreamTab[TriggerPos_BeforeStandard][this->currDmlEvent] << endl << lockTemplate->bodyStr;
        }
    }
    else if (this->getDictEntityStp()->changeSetAuthEn == FeatureAuth_Enable)
    {
        DdlGenCfgTemplateKey cfgKey(CfgTemplate_ChangeSet,
                                    this->ddlGenContextPtr->getTemplateVersion(),
                                    DdlObj_Trigger,
                                    keyStr);

        auto lockTemplate = this->ddlGenContextPtr->getTemplateFileHelper().getCfgTemplate(cfgKey);

        if (lockTemplate && lockTemplate->bodyStr.empty() == false)
        {
            this->beforeEachRowStreamTab[TriggerPos_BeforeStandard][this->currDmlEvent] << endl << lockTemplate->bodyStr;
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenTrigger::initRootManagment()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-21197 - LJE - 160415
**
*************************************************************************/
RET_CODE DdlGenTrigger::initRootManagment()
{
    RET_CODE ret = RET_SUCCEED;

    string varSqlName("is_root_level_");

    if (this->ddlGenContextPtr->bRootEntityManagement &&
        this->varHelperPtr->getVariable(varSqlName, false) == nullptr)
    {
        this->varHelperPtr->addVariable(varSqlName, FlagType, "0");

        stringstream currStream;

        this->setIndent(1);
        currStream
            << this->newLine() << "#IF #GET_ROOT_ENTITY is null"
            << this->newLine() << "#{";

        this->setIndent(1);
        currStream
            << this->newLine() << "#SET_ROOT_ENTITY"
            << this->newLine() << "#ASSIGN @" << varSqlName << " = 1";

        this->setIndent(-1);
        currStream
            << this->newLine() << "#}";
        this->setIndent(-1);

        this->m_beforeStream.initStream()
            << this->scriptDdlGen->buildScript(currStream.str(), this->m_scptDllObjEn) << endl;

        if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
        {
            ret = this->releaseRootManagment();
        }
    }
    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenTrigger::releaseRootManagment()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-21197 - LJE - 160415
**
*************************************************************************/
RET_CODE DdlGenTrigger::releaseRootManagment()
{
    RET_CODE ret = RET_SUCCEED;

    if (this->ddlGenContextPtr->bRootEntityManagement)
    {
        stringstream currStream;

        this->setIndent(1);
        currStream << endl
            << this->newLine() << "#IF #IS_ROOT_LEVEL"
            << this->newLine() << "#{";

        this->setIndent(1);
        currStream
            << this->newLine() << "#RM_ROOT_ENTITY";
        this->setIndent(-1);

        currStream
            << this->newLine() << "#}";
        this->setIndent(-1);

        this->m_afterStream.releaseStream()
            << this->scriptDdlGen->buildScript(currStream.str(), this->m_scptDllObjEn) << endl;
    }
    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenTrigger::initObjectModifStat()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13122 - LJE - 120515
**
*************************************************************************/
RET_CODE DdlGenTrigger::printObjectModifStat()
{
    RET_CODE     ret=RET_SUCCEED;
    stringstream actionStream;
    string       recTypeStr;
    int          attribImpactedNbr = 0;

    /* PMSTA-17089 - DDV - 131211 - Don't generate object_modif_stat code for ud_ tables' triggers */
    if (this->ddlGenContextPtr->bStdIinsObjectModifStat == false || this->bUdTableTrig || this->bObjModifStatPrinted)
    {
        return ret;
    }

    this->bObjModifStatPrinted = true;

    if (this->currDmlEvent == DmlEvent_Insert)
    {
        actionStream << ObjModifStatAction_Insert;
        recTypeStr = "#NEW.";
    }
    else if (this->currDmlEvent == DmlEvent_Update)
    {
        actionStream << ObjModifStatAction_Update;
        recTypeStr = "#NEW.";
    }
    else if (this->currDmlEvent == DmlEvent_Delete)
    {
        actionStream << ObjModifStatAction_Delete;
        recTypeStr = "#OLD.";
    }

	this->scriptDdlGen->varHelperPtr->addVariable("action_e", EnumType, actionStream.str());

    this->setIndent(2);
    for (auto& attribStp : this->getDictEntityStp()->attr)
    {
        int             attProgN = attribStp->progN;

        if (attribStp->objModifStatEn == LastModif_TrackingAuto)
        {
            stringstream impactedEntityDictStr;

            if (this->getDictEntityStp()->attr[attProgN]->refEntDictId == 0)
            {
                if (this->getDictEntityStp()->primKeyNbr == 1 &&
                    this->getDictEntityStp()->attr[attProgN]->primFlg == TRUE)
                {
                    impactedEntityDictStr << this->getTableModifStatEntityDictId();
                }
                else if (this->getDictEntityStp()->attr[attProgN]->linkedAttrDictStp != 0)
                {
                    impactedEntityDictStr << recTypeStr << this->getDictEntityStp()->attr[attProgN]->linkedAttrDictStp->sqlName;
                }
            }
            else
            {
                impactedEntityDictStr << this->getDictEntityStp()->attr[attProgN]->refEntDictId;
            }

            attribImpactedNbr++;
            // modifStatStream
            this->afterEachRowStreamTab[TriggerPos_AfterStandard][this->currDmlEvent]
                << endl
                << this->newLine() << "#EXEC ins_object_modif_stat_trg"
                << this->newLine() << "	@action_e = @action_e,"
                << this->newLine() << "	@updated_entity_dict_id = " << this->getTableModifStatEntityDictId() << ","
                << this->newLine() << "	@impacted_entity_dict_id = " << impactedEntityDictStr.str() << ","
                << this->newLine() << "	@impacted_object_id = " << recTypeStr << this->getDictEntityStp()->attr[attProgN]->sqlName << ","
                << this->newLine() << "	@object_impact_d = @" << this->getCurrModifDate(this->afterEachRowVarTab[EventPos_After][this->currDmlEvent]) << endl << endl;
        }
    }
    this->setIndent(-2);

    if (attribImpactedNbr == 0)
    {
        ret = RET_DBA_ERR_MD;
        this->printMsg(ret, "Entity having object modif. stat. activated without attribute to track!");
    }
    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenTrigger::initTableModifStat()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-15962 - LJE - 130225
**
*************************************************************************/
RET_CODE DdlGenTrigger::initTableModifStat()
{
    RET_CODE ret=RET_SUCCEED;

    if (this->bTblModifStat == false || this->bUdTableTrig)
        return ret;

    this->afterStreamTab[TriggerPos_AfterStandard][this->currDmlEvent]
        << endl
        << this->newLine() << "#EXEC upd_table_modif_stat"
		<< this->newLine() << "	@entity_dict_id = " << this->getTableModifStatEntityDictId() << ","     /* PMSTA-23300 - TEB - 160622 */
        << this->newLine() << "	@last_modif_d = @" << this->getCurrModifDate(this->afterVarTab[EventPos_After][this->currDmlEvent]) << endl;

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenTrigger::initCheckSecurityAndFk()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13122 - LJE - 120515
**
*************************************************************************/
RET_CODE DdlGenTrigger::initCheckSecurityAndFk()
{
    RET_CODE ret=RET_SUCCEED;
    bool     bLastModif = false, bCrModif = false;
    string   rowVersion;

    this->setIndent(1);

    if (this->bUdTableTrig == false)
    {
        bLastModif = this->getDictEntityStp()->lastModifEn == LastModif_TrackingAuto;
    }

    /* PMSTA-26108 - LJE - 170818 */
    const DICT_ATTRIB_STP connBusinessEntAttrStp = this->getConnBusinessEntAttrStp(this->getDictEntityStp());

    if (this->getDictEntityStp()->multiEntityCateg.isCheckInTrigger() &&
        this->ddlGenContextPtr->getMultiEntityLevel() == MultiEntityLevel_Active &&
        this->targetTableEn == TargetTable_Main)
    {
        if (this->currDmlEvent == DmlEvent_Insert || this->currDmlEvent == DmlEvent_Update)
        {
            if (connBusinessEntAttrStp)
            {
                if (this->getDictEntityStp()->multiEntityCateg.isDeniedInMaster())
                {
                    this->beforeEachRowStreamTab[TriggerPos_AfterStandard][this->currDmlEvent]
                        << this->newLine() << "#IF #NEW." << connBusinessEntAttrStp->sqlName << " = #MASTER_BUSINESS_ENTITY_ID"
                        << this->newLine() << "#{"
                        << this->newLine() << "\t#APPL_RAISERROR 20565, " << this->getDdlObjSqlName()
                        << this->newLine() << "\t#ROLLBACK_TRAN"
                        << this->newLine() << "\t#RETURN"
                        << this->newLine() << "#}";
                }
                else if (this->getDictEntityStp()->multiEntityCateg.isCheckOnCurrentBe())
                {
                    this->beforeEachRowStreamTab[TriggerPos_AfterStandard][this->currDmlEvent]
                        << this->newLine() << "#IF #NEW." << connBusinessEntAttrStp->sqlName << " <> #CONNECT_BUSINESS_ENTITY_ID"
                        << this->newLine() << "#{"
                        << this->newLine() << "\t#APPL_RAISERROR 20565, " << this->getDdlObjSqlName()
                        << this->newLine() << "\t#ROLLBACK_TRAN"
                        << this->newLine() << "\t#RETURN"
                        << this->newLine() << "#}";
                }

                if (this->currDmlEvent == DmlEvent_Insert &&
                    this->getDictEntityStp()->multiEntityCateg.isCheckIfNotExtistOnMaster())
                {
                    this->beforeEachRowStreamTab[TriggerPos_AfterStandard][this->currDmlEvent]
                        << this->newLine() << "#GEN_IF_BEGIN bk"
                        << this->newLine() << "#NO_MULTI_ENTITY"
                        << this->newLine() << "#NO_SECURED"
                        << this->newLine() << "#IF #NEW." << connBusinessEntAttrStp->sqlName << " = #MASTER_BUSINESS_ENTITY_ID"
                        << this->newLine() << "#{"
                        << this->newLine() << "\t#IF_EXISTS ("
                        << this->newLine() << "\t\t#SELECT " << this->getDictEntityStp()->mdSqlName << " null "
                        << this->newLine() << "\t\t\t1"
                        << this->newLine() << "\t\t\t#FROM"
                        << this->newLine() << "\t\t\t#WHERE"
                        << this->newLine() << "\t\t\tbk"
                        << this->newLine() << "\t\t\t" << connBusinessEntAttrStp->sqlName << " <> #MASTER_BUSINESS_ENTITY_ID"
                        << this->newLine() << "\t\t\t#END"
                        << this->newLine() << "\t\t)"
                        << this->newLine() << "\t\t#{"
                        << this->newLine() << "\t\t\t#APPL_RAISERROR 20563, " << this->getDdlObjSqlName()
                        << this->newLine() << "\t\t\t#ROLLBACK_TRAN"
                        << this->newLine() << "\t\t\t#RETURN"
                        << this->newLine() << "\t\t#}"
                        << this->newLine() << "#}"
                        << this->newLine() << "#ELSE"
                        << this->newLine() << "#{"
                        << this->newLine() << "\t#IF_EXISTS ("
                        << this->newLine() << "\t\t#SELECT " << this->getDictEntityStp()->mdSqlName << " null "
                        << this->newLine() << "\t\t\t1"
                        << this->newLine() << "\t\t\t#FROM"
                        << this->newLine() << "\t\t\t#WHERE"
                        << this->newLine() << "\t\t\tbk"
                        << this->newLine() << "\t\t\t" << connBusinessEntAttrStp->sqlName << " = #MASTER_BUSINESS_ENTITY_ID"
                        << this->newLine() << "\t\t\t#END"
                        << this->newLine() << "\t\t)"
                        << this->newLine() << "\t\t#{"
                        << this->newLine() << "\t\t\t#APPL_RAISERROR 20563, " << this->getDdlObjSqlName()
                        << this->newLine() << "\t\t\t#ROLLBACK_TRAN"
                        << this->newLine() << "\t\t\t#RETURN"
                        << this->newLine() << "\t\t#}"
                        << this->newLine() << "#}"
                        << this->newLine() << "#MULTI_ENTITY"
                        << this->newLine() << "#SECURED"
                        << this->newLine() << "#GEN_IF_END";
                }
            }
            else if (this->currDmlEvent == DmlEvent_Delete)
            {
                if (this->getDictEntityStp()->multiEntityCateg.isInsUpdOnLocalBe())
                {
                    this->beforeEachRowStreamTab[TriggerPos_AfterStandard][this->currDmlEvent]
                        << this->newLine() << "#IF #OLD." << connBusinessEntAttrStp->sqlName << " <> #CONNECT_BUSINESS_ENTITY_ID"
                        << this->newLine() << "#{"
                        << this->newLine() << "\t#APPL_RAISERROR 20565, " << this->getDdlObjSqlName()
                        << this->newLine() << "\t#ROLLBACK_TRAN"
                        << this->newLine() << "\t#RETURN"
                        << this->newLine() << "#}";
                }
            }
        }

        if (this->getDictEntityStp()->multiEntityCateg.isAllowedOnlyInMaster())
        {
            this->beforeEachRowStreamTab[TriggerPos_AfterStandard][this->currDmlEvent]
                << this->newLine() << "#IF #CONNECT_BUSINESS_ENTITY_ID <> #MASTER_BUSINESS_ENTITY_ID"
                << this->newLine() << "#{"
                << this->newLine() << "\t#APPL_RAISERROR 20565, " << this->getDdlObjSqlName()
                << this->newLine() << "\t#ROLLBACK_TRAN"
                << this->newLine() << "\t#RETURN"
                << this->newLine() << "#}";
        }
    }

    if (this->bUdTableTrig == false &&
        (this->currDmlEvent == DmlEvent_Update || (this->currDmlEvent == DmlEvent_Delete && this->getDictEntityStp()->dbRuleEn != DbRule_ShadowTable)) &&
        this->isSecuredLevel(this->getDictEntityStp()->securityLevelEn))
    {
        this->beforeStreamTab[TriggerPos_AfterStandard][this->currDmlEvent]
            << this->newLine() << "#DATA_PROFILE"
            << this->newLine() << "#DECLARE @data_profile_id_user id_t";

        if (this->ddlGenContextPtr->m_rdbmsEn == Sybase || this->ddlGenContextPtr->m_rdbmsEn == MSSql)
        {
            this->beforeEachRowVarTab[this->currEventPos][this->currDmlEvent]->addVariable("return_status", IntType);

            this->beforeEachRowStreamTab[TriggerPos_AfterStandard][this->currDmlEvent]
                << this->newLine() << "/* verify user has security access to this record */";

            if (this->currDmlEvent == DmlEvent_Update)
            {
                this->beforeEachRowStreamTab[TriggerPos_AfterStandard][this->currDmlEvent]
                    << this->newLine() << "#EXEC @return_status = chk_data_secu_prof_for_upd" << endl;;
            }
            else if (this->currDmlEvent == DmlEvent_Delete)
            {
                this->beforeEachRowStreamTab[TriggerPos_AfterStandard][this->currDmlEvent]
                    << this->newLine() << "#EXEC @return_status = chk_data_secu_prof_for_del" << endl;
            }

            this->beforeEachRowStreamTab[TriggerPos_AfterStandard][this->currDmlEvent] << " @data_profile_id, @data_profile_id_user, #OLD.data_secu_prof_id";

            if (this->getDictEntityStp()->securityLevelEn == EntSecuLevel_Secured2ndLevel)
            {
                this->beforeEachRowStreamTab[TriggerPos_AfterStandard][this->currDmlEvent] << ", #OLD.data_secu_prof2_id";
            }

            this->beforeEachRowStreamTab[TriggerPos_AfterStandard][this->currDmlEvent]
                << this->newLine() << "#IF @return_status = -1"
                << this->newLine() << "#{"
                << this->newLine() << "\t#ROLLBACK_TRAN"
                << this->newLine() << "\t#RETURN"
                << this->newLine() << "#}";
        }
        else
        {
            this->beforeEachRowStreamTab[TriggerPos_AfterStandard][this->currDmlEvent]
                << this->newLine() << "/* verify user has security access to this record */";

            if (this->currDmlEvent == DmlEvent_Update)
            {
                this->beforeEachRowStreamTab[TriggerPos_AfterStandard][this->currDmlEvent]
                    << this->newLine() << "#EXEC chk_data_secu_prof_for_upd" << endl;
            }
            else if (this->currDmlEvent == DmlEvent_Delete)
            {
                this->beforeEachRowStreamTab[TriggerPos_AfterStandard][this->currDmlEvent]
                    << this->newLine() << "#EXEC chk_data_secu_prof_for_del" << endl;
            }

            this->beforeEachRowStreamTab[TriggerPos_AfterStandard][this->currDmlEvent] << " @data_profile_id, @data_profile_id_user, #OLD.data_secu_prof_id";

            if (this->getDictEntityStp()->securityLevelEn == EntSecuLevel_Secured2ndLevel)
            {
                this->beforeEachRowStreamTab[TriggerPos_AfterStandard][this->currDmlEvent] << ", #OLD.data_secu_prof2_id";
            }
        }

    }

    vector<string> lastUserIdStr, lastModifDateStr, crUserIdStr, crDateStr;

    if (this->currDmlEvent == DmlEvent_Update || this->currDmlEvent == DmlEvent_Insert)
    {
        for (auto attribIt = this->getDictEntityStp()->attr.begin(); attribIt != this->getDictEntityStp()->attr.end(); ++attribIt)
        {
            DICT_ATTRIB_STP attribStp = (*attribIt);

            if (attribStp == nullptr || this->bUdTableTrig != (attribStp->custFlg == TRUE))
                continue;

            if (this->attribToCheck(attribStp))
            {
                this->beforeEachRowStreamTab[TriggerPos_AfterStandard][this->currDmlEvent] << this->newLine() << "#CHECK #NEW." << attribStp->sqlName;
            }

            if (attribStp->calcEn == DictAttr_CreationManagment ||
                attribStp->calcEn == DictAttr_LastModifManagment)
            {
                if (attribStp->dataTpProgN == DatetimeType)
                {
                    if (attribStp->calcEn == DictAttr_CreationManagment)
                    {
                        bCrModif = true;
                        crDateStr.push_back(attribStp->sqlName);
                        this->beforeEachRowVarTab[this->currEventPos][this->currDmlEvent]->addVariable(crDateStr.back(), DatetimeType);
                    }
                    else
                    {
                        bLastModif = true;
                        lastModifDateStr.push_back(attribStp->sqlName);
                    }
                }

                if (attribStp->dataTpProgN == IdType)
                {
                    if (attribStp->calcEn == DictAttr_CreationManagment)
                    {
                        bCrModif = true;
                        crUserIdStr.push_back(attribStp->sqlName);
                        this->beforeEachRowVarTab[this->currEventPos][this->currDmlEvent]->addVariable(crUserIdStr.back(), IdType);
                    }
                    else
                    {
                        bLastModif = true;
                        lastUserIdStr.push_back(attribStp->sqlName);
                    }
                }
            }

            /* PMSTA-26252 - LJE - 170209 */
            if (this->getDictEntityStp()->optimisticLockingAttrStp &&
                DdlGenDbi::getOptimisticLockingRule(attribStp) == OptimisticLocking_RowVersion)
            {
                bLastModif = true;
                rowVersion = DdlGenDbi::getOptimisticLockingSqlName(this->getDictEntityStp());
            }

            if (this->ddlGenContextPtr->ddlGenAction.m_installLevel > 8)
            {
                if (crUserIdStr.empty() == false)
                {
                    crUserIdStr.clear();
                }
                if (lastUserIdStr.empty() == false)
                {
                    lastUserIdStr.clear();
                }
                if (rowVersion.empty() == false)
                {
                    rowVersion.clear();
                }
            }
        }

        if (bLastModif)
        {
            this->beforeEachRowStreamTab[TriggerPos_AfterStandard][this->currDmlEvent]
                << this->newLine()
                << this->newLine() << "#NO_MULTI_ENTITY"
                << this->newLine() << "#UPDATE_NEW " << this->getDictEntityStp()->mdSqlName << " null";

            for (auto &it : lastUserIdStr)
            {
                this->beforeEachRowStreamTab[TriggerPos_AfterStandard][this->currDmlEvent]
                    << this->newLine() << it << " = @" << this->getCurrUser(this->beforeEachRowVarTab[EventPos_Before][this->currDmlEvent]);
            }

            for (auto& it : lastModifDateStr)
            {
                this->beforeEachRowStreamTab[TriggerPos_AfterStandard][this->currDmlEvent]
                    << this->newLine() << it << " = @" << this->getCurrModifDate(this->beforeEachRowVarTab[EventPos_Before][this->currDmlEvent]);
            }

            if (rowVersion.empty() == false)
            {
                this->beforeEachRowStreamTab[TriggerPos_AfterStandard][this->currDmlEvent]
                    << this->newLine() << rowVersion << " = #ISNULL(#NEW." << rowVersion << ",0) + 1";
            }

            this->beforeEachRowStreamTab[TriggerPos_AfterStandard][this->currDmlEvent]
                << this->newLine() << "#WHERE"
                << this->newLine() << "#END"
                << this->newLine() << "#MULTI_ENTITY"
                << this->newLine() << this->newLine();
        }

        if (bCrModif && this->currDmlEvent == DmlEvent_Insert)
        {
            this->beforeEachRowStreamTab[TriggerPos_AfterStandard][this->currDmlEvent]
                << this->newLine()
                << this->newLine() << "#NO_MULTI_ENTITY"
                << this->newLine() << "#UPDATE_NEW " << this->getDictEntityStp()->mdSqlName << " null";

            for (auto& it : crUserIdStr)
            {
                this->beforeEachRowStreamTab[TriggerPos_AfterStandard][this->currDmlEvent]
                    << this->newLine() << it << " = @" << this->getCurrUser(this->beforeEachRowVarTab[EventPos_Before][this->currDmlEvent]);
            }

            for (auto& it : crDateStr)
            {
                this->beforeEachRowStreamTab[TriggerPos_AfterStandard][this->currDmlEvent]
                    << this->newLine() << it << " = @" << this->getCurrModifDate(this->beforeEachRowVarTab[EventPos_Before][this->currDmlEvent]);
            }

            this->beforeEachRowStreamTab[TriggerPos_AfterStandard][this->currDmlEvent]
                << this->newLine() << "#WHERE"
                << this->newLine() << "#END"
                << this->newLine() << "#MULTI_ENTITY"
                << this->newLine() << this->newLine();
        }
    }

    if (this->bUdTableTrig == false &&
        this->currDmlEvent == DmlEvent_Update &&
        this->getDictEntityStp()->dlmAuthEn == FeatureAuth_Enable)
    {
        this->beforeEachRowStreamTab[TriggerPos_AfterStandard][this->currDmlEvent]
            << this->newLine()
            << this->newLine() << "#IF #UPDATING(dlm_e)"
            << this->newLine() << "#{";
        this->setIndent(1);

        this->beforeEachRowStreamTab[TriggerPos_AfterStandard][this->currDmlEvent]
            << this->newLine()
            << this->newLine() << "#NO_MULTI_ENTITY"
            << this->newLine() << "#UPDATE_NEW " << this->getDictEntityStp()->mdSqlName << " null"
            << this->newLine() << "dlm_move_d = @" << this->getCurrModifDate(this->beforeEachRowVarTab[EventPos_Before][this->currDmlEvent])
            << this->newLine() << "#WHERE"
            << this->newLine() << "#END"
            << this->newLine() << "#MULTI_ENTITY"
            << this->newLine() << this->newLine();
        this->setIndent(-1);
        this->beforeEachRowStreamTab[TriggerPos_AfterStandard][this->currDmlEvent]
            << this->newLine() << "#}";
    }

    this->setIndent(-1);
    return ret;
}


/*************************************************************************
**   END  ddlgentrigger.cpp                                        Odyssey **
*************************************************************************/


/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef DBA_SEND_MSG_OPTIONS_STRUCT_H
#define DBA_SEND_MSG_OPTIONS_STRUCT_H

struct DBA_SEND_MSG_OPTIONS_STRUCT
{
    int changeErrorForTimeStampToInfo;  /* Change an error message to an information message. TRUE=yes FALSE=no */
    int dropMessage;                    /* Remove an error message                            TRUE=yes FALSE=no */
    bool strictErrorHandling;           /* For the fusion only. Strict error handling       PMSTA-14660 - 160712 - PMO  */
    bool fatalError;                    /* For the fusion only. Strict error handling       PMSTA-14660 - 160712 - PMO  */
};

typedef struct DBA_SEND_MSG_OPTIONS_STRUCT		DBA_SEND_MSG_OPTIONS_ST;
typedef struct DBA_SEND_MSG_OPTIONS_STRUCT *	DBA_SEND_MSG_OPTIONS_STP;

#endif


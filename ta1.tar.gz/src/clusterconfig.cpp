/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/*******************************************************************************
**      Defines
*******************************************************************************/

/*******************************************************************************
**      Include files
*******************************************************************************/
#define STRING_H
#define STDLIB_H

#include <QUuid>
#include "unidef.h"     /* Mandatory */
#include "dbiconnection.h"
#include "clusterconfig.h"

using namespace std;

static Atomic<ThreadState>  SV_ThreadSrvAdmin(ThreadState::Initialization);
static Lock                 SV_ThreadSrvAdminLock;
static std::vector<ClusterServProperties> SV_FusServers;

extern ServerClientConfig   EV_CurrentSrvConfig;

/*******************************************************************************
**      Local declarations of prototypes
*******************************************************************************/

/*******************************************************************************
**      Local declarations of definitions
*******************************************************************************/


/************************************************************************
*   Function        :   isManagedByFusion
*   
*   Description     :  if fusion manages or independent like SUBD
*
*   Return          :  
*
*   Creation Date   :  PMSTA-47605 - JBC - 220113 
*                           
*   Last Modif.     :  
*
*************************************************************************/
bool ServiceCfg::isManagedByFusion()
{
    switch(getNature())
    {
        case ServiceCfgNat_SubcriptionDaemon:
            return false;
        case ServiceCfgNat_FusionLockPortfolio:
            return true;        
        case ServiceCfgNat_CurrencyChangeRequest:
            return false;
        default:
            return false;
    }
}

bool ServiceCfg::isServiceValid()
{
    return getServiceId() > ZERO_ID;
}

/************************************************************************
*   Function        :   SVC_GetLockTblEn
*   
*   Description     :  lock table based on nature
*
*   Return          :  
*
*   Creation Date   :  PMSTA-47605 - JBC - 220113 
*                           
*   Last Modif.     :  
*
*************************************************************************/
OBJECT_ENUM ServiceCfg::getLockTblEn()
{
    switch(getNature())
    {
        case ServiceCfgNat_SubcriptionDaemon:
            return LockEventMap;
        case ServiceCfgNat_FusionLockPortfolio:
            return LockPortfolio;
        case ServiceCfgNat_CurrencyChangeRequest:
            return CurrencyChangeRequest;
        default:
            return NullEntity;
    }
}

/************************************************************************
*   Function        :   SVC_GetLockTblEn
*   
*   Description     :  lock table based on nature
*
*   Return          :  
*
*   Creation Date   :  PMSTA-47605 - JBC - 220113 
*                           
*   Last Modif.     :  
*
*************************************************************************/
OBJECT_ENUM ServiceCfg::getMainTblEn()
{
    /* not yet implemented */
    switch(getNature())
    {   
        case ServiceCfgNat_SubcriptionDaemon:
        case ServiceCfgNat_FusionLockPortfolio:
        case ServiceCfgNat_CurrencyChangeRequest:
        default:        
            return NullEntity;
    }
}

/************************************************************************
*   Function        :   SERV_PingService
*   
*   Description     :  update service_running last seen
*
*   Argments          :  connHelper
*                        serviceId
*                        aServiceRunning - optional
*
*   Creation Date   :  PMSTA-47605 - JBC - 220113 
*                           
*   Last Modif.     :  
*
*************************************************************************/
RET_CODE SERV_PingService(DbiConnectionHelper & connHelper, ID_T serviceId, const bool isInsert, DBA_DYNFLD_STP aServiceRunning)
{
    RET_CODE ret = RET_SUCCEED;
    MemoryPool mp;
    bool toPopulate = false;
    if(aServiceRunning == nullptr)
    {   toPopulate = true;
        aServiceRunning = mp.allocDynst(FILEINFO,A_ServiceRunning);
    }
    
    SET_ID(aServiceRunning, A_ServiceRunning_ServiceId, serviceId);
    if(toPopulate)
    {
        SET_NOTE(aServiceRunning, A_ServiceRunning_Host, SYS_GetHostName().c_str());
        SET_INT(aServiceRunning, A_ServiceRunning_Pid,static_cast<int>(SYS_GetPid()));
        SET_INT(aServiceRunning, A_ServiceRunning_Port,EV_CurrentSrvConfig.getExternalPort());
    }

    if(isInsert)
    {
        DATETIME_T dbDate;
        if(connHelper.isValidAndInit() == false || (ret = DBA_GetDbDateOnServer(&dbDate,*connHelper.getConnection())) != RET_SUCCEED)
        {
            DATE_CurrentDateTime(&dbDate);   /* PMSTA-37366 - LJE - 191112 */
        }
        SET_DATETIME(aServiceRunning,A_ServiceRunning_LastSeenDate,dbDate);
    }

    ret =  isInsert ? connHelper.dbaInsert(ServiceRunning, UNUSED, aServiceRunning)
        : connHelper.dbaUpdate(ServiceRunning, DBA_ROLE_SVC_CFG,aServiceRunning);

   return ret;
}

/************************************************************************
*   Function        :   SERV_StartThreadClusterSvcAdmin
*
*   Description     :   The adminstrator thread for the service.
*
*   Arguments       :   CLUST_SRVC_THREAD_ARG_ST
*
*   Creation Date   :   PMSTA-34827 - JBC - 19021
*
*   Last Modif.     :
*
*************************************************************************/
void SERV_ThreadStandaloneServiceAdmin(ThreadArg * _threadArg)
{
    RET_CODE            ret = RET_SUCCEED;

    ThreadStateCycle threadStateCycle(SV_ThreadSrvAdmin);
    MemoryPool          mp;
    auto *              threadArg     = static_cast<ServiceCfgThreadArg *>(_threadArg);
    ServiceCfg          serviceCfg(threadArg->srvcId,false);

    SYS_SetThreadUseServerUser(true);
    AAALocalConnectionProvider::initAdminSessionMap();

    auto busEntityCds = SYS_GetApplSessionRankedBusEntCds(true);
    const int busEntityNb = static_cast<int>(busEntityCds.size());
    threadStateCycle.setRunning();

    while(threadStateCycle.isRunning())
    {       
        {
            DbiConnectionHelper connHelper;
            ret = RET_SUCCEED;
            /* update last seen for this cluster service */
            if(SERV_PingService(connHelper,serviceCfg.getServiceId(),false) == RET_SUCCEED)
            {
                for(int i=0;i<busEntityNb;i++)
                {
                    if(GEN_IsMultiEntity())
                    {
                        connHelper.setCurrBusinessEntity(busEntityCds[i].first);
                    }

                    serviceCfg.cleanupServiceLocks(connHelper);
                }

                if(GEN_IsMultiEntity())
                {
                    connHelper.setCurrBusinessEntity(EV_MasterBusinessEntity);
                }
            }
        }

        /* wait 30 seconds (in 1 second increments to ping again */
        for(int i=0;i<30 && threadStateCycle.isRunning();i++)
        {
            SYS_MilliSleep(1000);
        }
    }
}

/************************************************************************
*   Function        :   ServiceCfg::ServiceCfg
*
*   Description     :   ServiceCfg class constructor
*
*   Arguments       :   see main constructor
*
*   Creation Date   :   PMSTA-34827 - JBC - 19021
*
*   Last Modif.     :
*
*************************************************************************/
ServiceCfg::ServiceCfg(DBA_DYNFLD_STP aServiceCfg, const bool isKeepAlive) :
    m_aServiceConfig(nullptr),
    m_keepAlive(isKeepAlive)
{
    if ((m_aServiceConfig = ALLOC_DYNST(A_ServiceConfig)) != NULLDYNST)
    {
        COPY_DYNST(m_aServiceConfig,aServiceCfg,A_ServiceConfig);
        createServiceConfig();
    }
}

/************************************************************************
*   Function        :   ServiceCfg::ServiceCfg
*
*   Description     :   get an existing ClusterService object
*
*   Arguments       :   serviceId
*                       isKeepAlive - get existing service but don't stop on destruct
*
*   Creation Date   :   PMSTA-47605 - JBC - 220113 
*   
*   Last Modif.     :
*
*************************************************************************/
ServiceCfg::ServiceCfg(const ID_T serviceId, const bool isKeepAlive) :
        m_aServiceConfig(nullptr),
        m_keepAlive(isKeepAlive)
{         
    if ((m_aServiceConfig = ALLOC_DYNST(A_ServiceConfig)) != NULLDYNST)
    {
        MemoryPool mp;
        DBA_DYNFLD_STP sServiceConfig = mp.allocDynst(FILEINFO,S_ServiceConfig);    
        SET_ID(sServiceConfig,A_ServiceConfig_Id,serviceId);

        DbiConnectionHelper connHelper;

        if(connHelper.dbaGet(ServiceConfig,UNUSED,sServiceConfig,&sServiceConfig) == RET_SUCCEED)
        {
            SET_CODE(m_aServiceConfig,A_ServiceConfig_Cd,GET_CODE(sServiceConfig, S_ServiceConfig_Cd));
            SET_ID(m_aServiceConfig,A_ServiceConfig_Id,serviceId);
            SET_ENUM(m_aServiceConfig,A_ServiceConfig_NatEn,GET_ENUM(sServiceConfig, S_ServiceConfig_NatEn));
            SET_ID(m_aServiceConfig,A_ServiceConfig_TslJobId,GET_ID(sServiceConfig,S_ServiceConfig_TslJobId));
            if(IS_NULLFLD(sServiceConfig,S_ServiceConfig_TslChunk) == false)
            {
                SET_INT(m_aServiceConfig,A_ServiceConfig_TslChunk,GET_INT(sServiceConfig,S_ServiceConfig_TslChunk));
            }
            SET_INT(m_aServiceConfig,A_ServiceConfig_TimeoutSec,GET_INT(sServiceConfig,S_ServiceConfig_TimeoutSec))
            SET_FLAG(m_aServiceConfig,A_ServiceConfig_AsyncFlg,GET_FLAG(sServiceConfig,S_ServiceConfig_AsyncFlg));
            SET_ENUM(m_aServiceConfig,A_ServiceConfig_StatusEn,GET_ENUM(sServiceConfig, S_ServiceConfig_StatusEn));
        }   
    }
}


ServiceCfg::~ServiceCfg()
{    
    stopAdminThread();

    if(m_keepAlive == false)
    {
        stopService(false);
    }
    DBA_FreeDynSt(m_aServiceConfig,A_ServiceConfig);
}


void ServiceCfg::stopAdminThread()
{    
    if(isManagedByFusion() == false)
    {
        LockGuard Lock(SV_ThreadSrvAdminLock);

        if (ThreadState::Initialization == SV_ThreadSrvAdmin.load())
        { /* The thread was not started */
            SV_ThreadSrvAdmin.store(ThreadState::Stopped);
        }
        else
        {            
            SV_ThreadSrvAdmin.store(ThreadState::Leaving);
        }
    }
}

void ServiceCfg::stopService(bool isForceStop)
{    
    if(isServiceValid() && (isAsync() == false || isForceStop))
    {
        if(isStopped() == false)
        {
            if(  isManagedByFusion())
            {
                MemoryPool mp;
                DbiConnectionHelper connHelper;
                bool isFinal = false;   // failed or succeeded in event sched
                /* mark service as stopping fusion engine must handle record in event_scheduler */
                DBA_DYNFLD_STP sServiceConfig = mp.allocDynst(FILEINFO,S_ServiceConfig);
                SET_ID(sServiceConfig,S_ServiceConfig_Id,getServiceId());
                SET_ENUM(sServiceConfig,S_ServiceConfig_StatusEn,ServiceCfgStatus_Stopping);
                SET_INT(sServiceConfig,S_ServiceConfig_ReturnStatus,-1)
                /* upd_service_config_stat_by_id */
                if(connHelper.dbaUpdate(ServiceConfig,DBA_ROLE_SVC_CFG,sServiceConfig) != RET_SUCCEED)
                {
                     setStatus(ServiceCfgStatus_Stopping);
                    isFinal = true;
                }
                /* async req must query for final status independently */
                if(isAsync() == false)
                {
                    // repurpose sServiceConfig
                    SET_NULL_ENUM(sServiceConfig,S_ServiceConfig_StatusEn);
                    
                    while(isFinal == false)
                    {
                        SET_ID(sServiceConfig,S_ServiceConfig_Id,getServiceId());
                        SET_INT(sServiceConfig,S_ServiceConfig_ReturnStatus,-1)
                        /* chk_service_config_stopped */
                        if(connHelper.dbaCheck(EventSched,DBA_ROLE_CLUSTER,sServiceConfig) != RET_SUCCEED)
                        {
                            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO,"Stop Service failed to check Event Scheduler.");
                            isFinal = true;
                        }

                        if(GET_INT(sServiceConfig,S_ServiceConfig_ReturnStatus) == 0)
                        {
                            isFinal = true;
                        }
                        else
                        {
                           SYS_MilliSleep(2000); 
                        }
                    }

                    SET_ENUM(sServiceConfig,S_ServiceConfig_StatusEn,ServiceCfgStatus_Stopped);
                    SET_INT(sServiceConfig,S_ServiceConfig_ReturnStatus,-1)
                    if(connHelper.dbaUpdate(ServiceConfig,DBA_ROLE_SVC_CFG,sServiceConfig) == RET_SUCCEED)
                    {
                        setStatus(ServiceCfgStatus_Stopped);
                    }
                }
            }                   
        }
    }
}

 ID_T ServiceCfg::getServiceId()
{
    return  isServiceCfgFldNotNull(A_ServiceConfig_Id) ? GET_ID(m_aServiceConfig,A_ServiceConfig_Id) : ZERO_ID;
}

std::string ServiceCfg::getServiceCd()
{
    return isServiceCfgFldNotNull(A_ServiceConfig_Cd) ? GET_CODE(m_aServiceConfig,A_ServiceConfig_Cd) : "ERR";
}


int ServiceCfg::getTimeoutSec()
{
    return isServiceCfgFldNotNull(A_ServiceConfig_TimeoutSec) ? GET_INT(m_aServiceConfig,A_ServiceConfig_TimeoutSec) : 180;
}

SERVICECFGNAT_ENUM ServiceCfg::getNature()
{
    return static_cast<SERVICECFGNAT_ENUM>(isServiceCfgFldNotNull(A_ServiceConfig_NatEn) ? GET_ENUM(m_aServiceConfig,A_ServiceConfig_NatEn) : 0);
}

bool ServiceCfg::isRunning()
{
    return isServiceValid() && (getStatus() == ServiceCfgStatus_Unknown || getStatus() == ServiceCfgStatus_Running || getStatus() == ServiceCfgStatus_Stopping);
}


bool ServiceCfg::isTimedOut()
{
    return getStatus() == ServiceCfgStatus_TimeOut;
}

bool ServiceCfg::isStopping()
{
    return getStatus() == ServiceCfgStatus_Stopping;
}

bool ServiceCfg::isStopped()
{
    return getStatus() == ServiceCfgStatus_Stopped;
}

bool ServiceCfg::isAsync()
{
    return isServiceCfgFldNotNull(A_ServiceConfig_AsyncFlg) ? GET_FLAG(m_aServiceConfig,A_ServiceConfig_AsyncFlg) == TRUE : false;
}

SERVICECFGTSTATUS_ENUM ServiceCfg::getStatus()
{
    return static_cast<SERVICECFGTSTATUS_ENUM>(isServiceCfgFldNotNull(A_ServiceConfig_StatusEn)  ? GET_ENUM(m_aServiceConfig,A_ServiceConfig_StatusEn) : 0);
}

void ServiceCfg::setStatus(SERVICECFGTSTATUS_ENUM status)
{
    if(m_aServiceConfig != nullptr)
    {
        SET_ENUM(m_aServiceConfig,A_ServiceConfig_StatusEn,status);
    }
}

ID_T ServiceCfg::getTslJobId()
{
    return isServiceCfgFldNotNull(A_ServiceConfig_TslJobId) ? GET_ID(m_aServiceConfig,A_ServiceConfig_TslJobId) : ZERO_ID;
}


INT_T ServiceCfg::getTslChunk()
{
    return isServiceCfgFldNotNull(A_ServiceConfig_TslChunk) ? GET_INT(m_aServiceConfig,A_ServiceConfig_TslChunk) : 0;
}

DBA_DYNFLD_STP ServiceCfg::getServiceConfig()
{
    return m_aServiceConfig;
}

bool ServiceCfg::isServiceCfgFldNotNull(FIELD_IDX_T aServiceCfgFldIdx)
{
     return m_aServiceConfig != nullptr && IS_NULLFLD(m_aServiceConfig,aServiceCfgFldIdx) == false;
}



/************************************************************************
*   Function        :   ServiceCfg::getWorkerEventSchedNat()
*   
*   Description     :  this defines the eventsched nature of the worker rows
*
*   Return          :  
*
*   Creation Date   :  PMSTA-47605 - JBC - 220113 
*                           
*   Last Modif.     :  
*
*************************************************************************/
EVENTSCHEDNAT_ENUM ServiceCfg::getWorkerEventSchedNat()
{
    EVENTSCHEDNAT_ENUM eventSchedNature = EventSchedNat_All;
    /* only fusion managed services */
    switch(getNature())
    {
        case ServiceCfgNat_FusionLockPortfolio:
            eventSchedNature = EventSchedNat_FusionLockPortfolio;
            break;
        default:
            break;
    }

    return eventSchedNature;
}


/************************************************************************
*   Function        :   ServiceCfg::getWorkerEventSchedName()
*   
*   Description     :  gives eventsched nature test
*
*   Return          :  
*
*   Creation Date   :  PMSTA-47605 - JBC - 220113 
*                           
*   Last Modif.     :  
*
*************************************************************************/
const char * ServiceCfg::getWorkerEventSchedName()
{
    return DBA_GetPermValName(EventSched,A_EventSched_NatEn,getWorkerEventSchedNat());
}




/************************************************************************
*   Function        :   SERV_CreateServiceUuid
*   
*   Description     :  generate uuid for service
*
*   Return          :  
*
*   Creation Date   :  PMSTA-47605 - JBC - 220113 
*                           
*   Last Modif.     :  
*
*************************************************************************/
RET_CODE SERV_CreateServiceUuid(DbiConnectionHelper & connHelper, std::string & serviceUuid)
{
    RET_CODE ret = RET_SUCCEED;
    DBA_DYNFLD_STP   *      sServiceCfgTab = nullptr;
    int                     sServiceCfgNb = 0;
    std::set<std::string>   guidSet;

    /* get set of existing codes */
    if(connHelper.dbaSelect(ServiceConfig,DBA_ROLE_SVC_CFG, nullptr,S_ServiceConfig, &sServiceCfgTab,&sServiceCfgNb) == RET_SUCCEED
        && sServiceCfgNb > 0)
    {
        for(int i = 0; i< sServiceCfgNb; i++)
        {
            std::string guid = GET_CODE(sServiceCfgTab[i], S_ServiceConfig_Cd);
            guidSet.insert(guid);
        }
        DBA_FreeDynStTab(sServiceCfgTab, sServiceCfgNb, S_ServiceConfig);
    }
    
    for(int i=0;i<100;i++)
    {
        QString local_uuid = QUuid::createUuid().toString(); //QUuid::WithoutBraces doesn't exists in QT 4.8
        local_uuid = local_uuid.remove(QChar('{')).remove(QChar('}'));
        std::string tmpUuid(local_uuid.toLocal8Bit().data());
        /* verify guid does not already exist  */
       if(guidSet.count(tmpUuid) == 0)
       {    
            serviceUuid = tmpUuid;
            break;
       }

        if(i==99)
        {
            ret = RET_SRV_LIB_ERR_DUPLICATEKEY;
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Failed to obtain valid unique UUID for Service Config");
            break;
        }
    }
    return ret;
}


/************************************************************************
*   Function        :   ServiceCfg::createService
*
*   Description     :   Derives a new GUID to identify the service and
*                       attempts to register it. When successful it launches
*                       a separate admin thread.
*
*   Arguments       :   aServiceConfig
*
*
*   Creation Date   :   PMSTA-34827 - JBC - 19021
*
*   Last Modif.     :
*
*************************************************************************/
void ServiceCfg::createServiceConfig()
{
    DbiConnectionHelper     connHelper;
    MemoryPool              mp;
    RET_CODE                ret = RET_SUCCEED;
    std::set<std::string>   guidSet;

    std::string serviceUuid;
    ret = SERV_CreateServiceUuid(connHelper, serviceUuid);

    if(ret == RET_SUCCEED)
    {   /* map vars */
        if(IS_NULLFLD(m_aServiceConfig,A_ServiceConfig_TimeoutSec) || GET_INT(m_aServiceConfig,A_ServiceConfig_TimeoutSec) <= 0)
        {
            int newTimeoutSec = 0;
            GEN_GetApplInfo(ApplSvcUnlockInterval, &newTimeoutSec);
            if(newTimeoutSec<=0)
            {   
                newTimeoutSec = 180;
            }
            SET_INT(m_aServiceConfig,A_ServiceConfig_TimeoutSec,newTimeoutSec);
        }
        
        /* Update Service Config */
        SET_CODE(m_aServiceConfig, A_ServiceConfig_Cd, serviceUuid.c_str());
        SET_ENUM(m_aServiceConfig, A_ServiceConfig_StatusEn, ServiceCfgStatus_Unknown);
 
         /* insert service */
        if ((ret = connHelper.dbaInsert(ServiceConfig, UNUSED, m_aServiceConfig)) == RET_SUCCEED)
        {            
            /* insert server running */        
            ret = SERV_PingService(connHelper,getServiceId(),true);
        }
    }

    if(ret == RET_SUCCEED)
    {   /* delete expired services */        
        initServiceCleanup(connHelper);

        if(isManagedByFusion() == false)
        {   /* launch independent  ping and admin thread */
            startThreadStandaloneSvcAdmin();
        }
    }
}

/************************************************************************
*   Function        :   SERV_ServiceAdminClearLocks
*
*   Description     :   CLear stale locks
*
*   Arguments       :   CLUST_SRVC_THREAD_ARG_ST
*
*   Creation Date   :   PMSTA-34827 - JBC - 19021
*
*   Last Modif.     :
*
*************************************************************************/
void ServiceCfg::cleanupServiceLocks(DbiConnectionHelper & connHelper)
{
    RET_CODE ret = RET_SUCCEED;
    MemoryPool mp;    
    
    DBA_DYNFLD_STP argLockUpd =  mp.allocDynst(FILEINFO, Adm_Arg);
    SET_ID(argLockUpd, Adm_Arg_Id, getServiceId()); /* service to exclude */ 
    SET_ENUM(argLockUpd, Adm_Arg_NatEn, getNature());
    SET_INT(argLockUpd, Adm_Arg_Integer, getTimeoutSec());

    /* cleanup stale and non-existent locks and process tables */
    /* optional if service also does main table row locking */
    if(getMainTblEn() > 0)
    {
        /* requires a lock cleanup proc in main table */
        ret = connHelper.dbaUpdate(getMainTblEn(),DBA_ROLE_SVC_CFG,argLockUpd);
    }
    /* requires a lock cleanup proc in lock table */
    if(getLockTblEn() > 0)
    {
        if(ret != RET_SUCCEED || connHelper.dbaUpdate(getLockTblEn(),DBA_ROLE_SVC_CFG,argLockUpd) != RET_SUCCEED)
        {
            MSG_SendMesg(FILEINFO, SYS_Stringer("Service Config id [", getServiceId(),"] code [",getServiceCd(),"] encountered error clearing stale locks."));
        }
    }
}


/************************************************************************
*   Function        :   ServiceCfg::initServiceCleanup
*
*   Description     :   On service startup, cleanup stale services
*                       for given nature; 
*
*   Arguments       :    
*
*   Creation Date   :   PMSTA-34827 - JBC - 19021
*
*   Last Modif.     :
*
*************************************************************************/
void ServiceCfg::initServiceCleanup(DbiConnectionHelper & connHelper)
{
    MemoryPool           mp;
    int                 applNumDays = 0;
    DBA_DYNFLD_STP      delArg =  mp.allocDynst(FILEINFO, Del_Arg);

    SET_ENUM(delArg, Del_Arg_NatEn, getNature());

    GEN_GetApplInfo(ApplSvcPurgeInterval, &applNumDays);
    if(applNumDays<=0)
    {
        applNumDays = 7;
    }
    SET_INT(delArg, Del_Arg_Integer, applNumDays);

    if(connHelper.dbaDelete(ServiceConfig, DBA_ROLE_SVC_CFG, delArg) != RET_SUCCEED)
    {
         MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Failed to cleanup Service Config table");
    }

    /* PMSTA-57346 - JBC  -20240704 */
    cleanupServiceLocks(connHelper);
}

/************************************************************************
*   Function        :   ServiceCfg::startThreadSrvAdmin
*
*   Description     :   Launches a thread to update the last_seen_d for the
*                       cluster service and watch for expired services to
*                       cleanup locks.
*
*   Arguments       :
*
*   Creation Date   :   PMSTA-34827 - JBC - 19021
*
*   Last Modif.     :
*
*************************************************************************/
void ServiceCfg::startThreadStandaloneSvcAdmin()
{
    LockGuard Lock(SV_ThreadSrvAdminLock);

    auto *threadArg = new ServiceCfgThreadArg();

    threadArg->srvcId      = getServiceId();

    if (!SYS_SpawnAdministrativeThread(SERV_ThreadStandaloneServiceAdmin, threadArg, SYS_Stringer("SERV_ThreadStandaloneServiceAdmin [",threadArg->srvcId,"]").c_str()))
	{
		(void)MSG_SendMesg(RET_SRV_LIB_ERR_GENERAL, 0, FILEINFO,
            SYS_Stringer("Start of the Service Admin Thread for id [", threadArg->srvcId,"] failed").c_str());
	}

}

/************************************************************************
*   Function        :   ClusterServerCfg::ClusterServerCfg
*
*   Description     :   ClusterServerCfg class constructor
*                       Note, the thread Nb for actual cluster threads should
*                       be managed with a Static Atomic Variable.
*                       For cluster config that is just for maintenance use zero
*
*   Arguments       :   DbiConnectionHelper&
*                       srvNm
*                       threadNb
*                       cfgType - if none some logging is surpressed
*                       
*
*   Creation Date   :   PMSTA-33371 - JBC  - 181211
*
*   Last Modif.     : PMSTA-40377 - JBC - 201004
*
*************************************************************************/
ClusterServerCfg::ClusterServerCfg(DbiConnectionHelper& connHelper, const std::string &  srvNm, const int threadNb, CLUSTERCFGTYPE_ENUM cfgType, AtomicInt & adminDelegateThread, 
    FusionTimer & adminDelegateTimer, AtomicBool & isDelegateValid, FusionTimer & adminDelayTimer) :
        m_serverNm(srvNm),
        m_threadRank(threadNb),
        m_serverId(ZERO_ID),
        m_configType(cfgType),
        m_delegateThreadRank(adminDelegateThread),
        m_delegateTimer(adminDelegateTimer),
        m_isDelegateValid(isDelegateValid),
        m_adminDelayTimer(adminDelayTimer)
{
    m_delegateTimer.setTimeOutInSeconds(15);
    m_delegateTimer.resetTimer();
    int adminDelaySecs;
    GEN_GetApplInfo(ApplActiveFusAdmDelay, &adminDelaySecs); /* PMSTA-48143 - JBC - 220222 */
    if(adminDelaySecs <= 0) { adminDelaySecs = 45; }
    m_adminDelayTimer.setTimeOutInSeconds(adminDelaySecs);
    m_adminDelayTimer.resetTimer();
    /* get cluster info */
    DBA_RefreshFusServers(connHelper);
}

/************************************************************************
*   Function        :   ClusterServerCfg::~ClusterServerCfg
*
*   Description     :   ClusterServerCfg class destructor
*
*   Creation Date   :   PMSTA-33371 - JBC  - 181101
*
*   Last Modif.     :
*
*************************************************************************/
ClusterServerCfg::~ClusterServerCfg()
{
}

/************************************************************************
*   Function        :   ClusterServerCfg::DBA_RefreshValidFusServers()
*
*   Description     :   refreshes the set of fus servers, sorted
*                       by id in proc to minimize possible reordering
*
*   Arguments       :   isInit - initiation waits for concurrent server startup
*
*   Creation Date   :   PMSTA-33371 - JBC  - 181204
*
*   Last Modif.     :
*
*************************************************************************/
void ClusterServerCfg::DBA_RefreshFusServers(DbiConnectionHelper & connHelper)
{
    
    std::map<std::string,int>   busEntityCdMap;
    std::set<std::string>       prevRunningServers;
    std::string                 prevPrimeSrvNm = m_primeSrvNm;

    /* for logging */
    if(m_threadRank == 1)
    {
        for(auto it = m_runServers.begin(); it != m_runServers.end();++it)
        {
            prevRunningServers.insert(it->first);
        }
    }
    m_runServers.clear();

    /* gather fusion server status - use last thread */
    if(isServAdminDelegate() || SV_FusServers.empty())
    {
        DBA_DYNFLD_STP *            sServConnectTab = nullptr;
        int                         sServConnectNb = 0;

        if(connHelper.dbaSelect(ServConnect,
            DBA_ROLE_CLUSTER,
            nullptr,
            S_ServConnect,
            &sServConnectTab,
            &sServConnectNb) == RET_SUCCEED)
        {
            if(sServConnectNb > 0)
            {
                LockGuard _(SV_ThreadSrvAdminLock);
                SV_FusServers.clear();

                for (int i = 0; i < sServConnectNb; i++)
                {
                    std::string srvNm = GET_CODE(sServConnectTab[i], S_ServConnect_ServerName);
                    std::string srvBusEntityCd;
                    if( GEN_IsMultiEntity() && IS_NULLFLD(sServConnectTab[i], S_ServConnect_BusEntityCd) == false)
                    {
                        srvBusEntityCd = GET_CODE(sServConnectTab[i], S_ServConnect_BusEntityCd);
                    }
                    ClusterServProperties servProperties(srvNm,GET_ID(sServConnectTab[i], S_ServConnect_Id),
                       GET_ENUM(sServConnectTab[i], S_ServConnect_NatEn),GET_ENUM(sServConnectTab[i], S_ServConnect_StatusEn),
                        static_cast<int>GET_SMALLINT(sServConnectTab[i], S_ServConnect_MaxFusion),srvBusEntityCd);

                    SV_FusServers.push_back(servProperties);
                }
            }
            DBA_FreeDynStTab(sServConnectTab, sServConnectNb, S_ServConnect);
        }
    }

    /* make copy */
    std::vector<ClusterServProperties> fusServers;
    {        
        LockGuard _(SV_ThreadSrvAdminLock);
        fusServers = SV_FusServers;
    }

    /* process running servers */
    std::vector<std::string> primeCandidates;

    for (size_t i = 0; i < fusServers.size(); i++)
    {
         /* my server is always running (avoiding debugging timeout last_seen) */
        if((m_serverNm == fusServers[i].m_serverNm ||  fusServers[i].m_status == ServConnectStatus_Running)
            && fusServers[i].m_nature == ServConnectNat_Instance)
        {
            m_runServers[fusServers[i].m_serverNm] = fusServers[i].m_serverId;

            std::string srvBusEntityCd;
            if( GEN_IsMultiEntity() && fusServers[i].m_busEntityCd.empty() == false)
            {
                srvBusEntityCd = fusServers[i].m_busEntityCd;
            }
            else
            {   /* prefer to servers not locked to a specific BE */
                primeCandidates.push_back(fusServers[i].m_serverNm);
            }

            if(m_serverNm == fusServers[i].m_serverNm)
            {
                m_serverId =  fusServers[i].m_serverId;
                m_lockedBusEntityCd = srvBusEntityCd;
            }
        }            
    }

    /* process servers for master ranking */
    int threadCount = 0;
    int servCount = 0;
    bool isPrimeSet = false;

    ;for (size_t i = 0; i < fusServers.size(); i++)
    {
        /* running servers */
        if(m_runServers.count(fusServers[i].m_serverNm) != 0)
        {
            /* 
             * If a server has a locked BE, it only considers other servers with same BE
             * this is a problem as it will spawn datadep, even if there is a lower ranked
             * server with a different BE (or none). So an prime server must be chosed first
             * to ensure there is only ever one expected. However preference is given to
             * first server with no specified BE, if exists
             */
            if (isPrimeSet == false)
            {
                if(primeCandidates.empty() == false)
                {   /* first prime candidate */
                    m_primeSrvNm = primeCandidates[0];
                }
                else
                {   /* first running server */
                    m_primeSrvNm = fusServers[i].m_serverNm;;
                }
                 isPrimeSet = true;                    
            }

            std::string srvBusEntityCd;
            if( GEN_IsMultiEntity() && fusServers[i].m_busEntityCd.empty() == false)
            {
                srvBusEntityCd = fusServers[i].m_busEntityCd;
            }

            /* PMSTA-41113 - KNI - 040920 */
            /* if this server is a fixed single BE only work with servers with same (or all) BE */
            if ((GEN_IsMultiEntity() 
                && (isLockedBusEntity() == false && srvBusEntityCd.empty() == false
                    || (isLockedBusEntity() && m_lockedBusEntityCd != srvBusEntityCd))))
            {
                    continue;
            }                

            servCount++;

            if (m_serverNm == fusServers[i].m_serverNm)
            {                    
                m_modRank = threadCount + m_threadRank;
                
            }
            /* track thread count by server and increase total threads (maxfus) */
            m_srvThreadCount = m_configType == ClusterCfg_TaxLot ? 1 : fusServers[i].m_maxFusionNb;                
            threadCount += m_srvThreadCount;
            /* logging */ 
            if(m_threadRank == 1 && m_serverNm == fusServers[i].m_serverNm && isLogged() && prevRunningServers.count(fusServers[i].m_serverNm) == 0)
            {                  
                std::string beMsg;
                if(GEN_IsMultiEntity() && isLockedBusEntity())
                {
                    beMsg.append(" Entity [").append(m_lockedBusEntityCd).append("]");
                }

                MSG_LogSrvMesg(UNUSED, UNUSED, SYS_Stringer(getClusterTypeName()," Configuration: Server [",fusServers[i].m_serverNm,"] with [",
                    m_srvThreadCount,"] Threads running.",beMsg).c_str());
            }
        }
    }
    /* master rank count for all running servers */
    m_maxRankThreadCount = threadCount;
}

ID_T ClusterServerCfg::getSrvId() const
{
    return m_serverId;
}

std::string & ClusterServerCfg::getSrvName()
{
    return m_serverNm;
}

/**
 * ThreadRank and ServerId are used for DB Locking operations only.
 * threadrank is only unique within a serverId
 *
 *  server_id, rank_n = lock
 */
int ClusterServerCfg::getThreadRank() const
{
    return m_threadRank;
}

/**
 * Mod rank is used for segmenting queue data.
 * Mod Rank is unique across all threads and servers
 *
 * Not used for locking, which is serverId, threadRank
 */
int ClusterServerCfg::getModRank() const
{
    return m_modRank;
}

/**
 * This is the max_fusion_nb for this server
 *  aka num threads for just this server
 */
int ClusterServerCfg::getSrvThreadCount() const
{
    return m_srvThreadCount;
}

/**
 * This is the max rank for segmentation, and
 * also the total thread count =
 *   sum(running servers max_fusion_n)
 */
int ClusterServerCfg::getMaxRankThreadCount() const
{
    return m_maxRankThreadCount;
}
/**
 * Returns true if mod(object,maxRank) + 1 = threadRank
 */
bool ClusterServerCfg::isObjSrvRankEqual(ID_T objectId) const
{
    return objectId % m_maxRankThreadCount + 1 == m_modRank;

}


std::string ClusterServerCfg::getSrvThreadInfo()
{
    return SYS_Stringer(getSrvName()," T",getThreadRank());
}


/************************************************************************
*   Function        :   ClusterServerCfg::isPrimeThread()
*
*   Description     :   returns true if is prime server and this thread is
*                       the current rotating admin thread. This is used to 
*                       conduct maintenance items that required or are 
*                       best served by one thread and were previously
*                       handled by the dispatcher.
*
*   Creation Date   :   PMSTA-33371 - JBC  - 181204
*
*   Last Modif.     : PMSTA-40377 - JBC 201004 : Rotate Delegates in Prime Server
*
*************************************************************************/
bool ClusterServerCfg::isPrimeThread()
{
    return isPrimeServer() && m_threadRank == 1;
}


/************************************************************************
*   Function        :   ClusterServerCfg::isPrimeServer()
*
*   Description     :   returns true if the current server has the prime thread
*                       This is for non-cluster threads spawned that
*                       are doing admin tasks can kill themselves if the
*                       server config changes.
*
*   Creation Date   :   PMSTA-33371 - JBC  - 181204
*
*   Last Modif.     :
*
*************************************************************************/
bool ClusterServerCfg::isPrimeServer() const
{
    return EV_CurrentSrvConfig.getServerName() == m_primeSrvNm;
}

/************************************************************************
*   Function        :   ClusterServerCfg::isServAdminDelegate()
*
*   Description     :   rather than have thread 1 always be the admin thread
*                       this method keeps the current thread delegate within
*                       the server that is currently the 'admin', to avoid
*                       blockages due to long fusions etc so there is always
*                       a roving delegate elected doing admin.
*                       The delegate is changed based on a timer.
*
*   Creation Date   :   PMSTA-40377 - JBC  - 201004
*
*   Last Modif.     :
*
*************************************************************************/
bool ClusterServerCfg::isServAdminDelegate()
{
    /* first thread in server is always a delegate */
    if(m_srvThreadCount == 1 || m_threadRank == 1)
    {
        return true;
    }
    /* PMSTA-53744 -JBC - 230706 */
    if(m_isDelegateValid.load() == false)
    {
        return false;
    }

    {
        const int preLockRank = m_delegateThreadRank.load();
        if(preLockRank > m_srvThreadCount ||preLockRank <= 0)
        {
            LockGuard _(m_lock);
            const int postLockRank = m_delegateThreadRank.load();
            if(preLockRank == postLockRank)
            {
                 m_delegateThreadRank.store(1);
                m_delegateTimer.resetTimer();
            }
        }
    }

    /* if we have done the time, increment to next thread */
    if(m_delegateTimer.isTimedOut())
    {   
        const int preLockRank = m_delegateThreadRank.load();  
        LockGuard _(m_lock);
        const int postLockRank = m_delegateThreadRank.load();
        if(preLockRank == postLockRank)
        {
            /* threadRank is base 1 */
            m_delegateThreadRank.store((m_threadRank == postLockRank ? 1 : postLockRank + 1)); 
            m_delegateTimer.resetTimer(); 
        }       
    }

    return m_threadRank == m_delegateThreadRank.load();
}


/************************************************************************
*   Function        :   ClusterServerCfg::isAdminDelayTimedOut()
*
*   Description     :   delay admin tasks/procs to minimize deadlocks/race
*                       during start_allsrv which can cause inconsistent 
*                       cluster configurations for first 30 seconds
*
*   Creation Date   :   PMSTA-48143 - JBC  - 220222
*
*   Last Modif.     :
*
*************************************************************************/
bool ClusterServerCfg::isAdminDelayTimedOut()
{
    return m_adminDelayTimer.isTimedOut();
}

/************************************************************************
*   Function        :   ClusterServerCfg::getPrimeSrvNm()
*
*   Description     :   returns current prime srv name
*
*   Creation Date   :   PMSTA-33371 - JBC  - 181204
*
*   Last Modif.     :
*
*************************************************************************/
std::string & ClusterServerCfg::getPrimeSrvNm()
{
    return m_primeSrvNm;
}

/************************************************************************
*   Function        :   ClusterServerCfg::isFusSrvRunning()
*
*   Description     :   returns true if srv name in running list
*
*   Creation Date   :   PMSTA-33371 - JBC  - 181204
*
*   Last Modif.     :
*
*************************************************************************/
bool ClusterServerCfg::isFusSrvRunning(std::string & srvNm) const
{
    return m_runServers.count(srvNm) != 0;
}


/************************************************************************
*   Function        :   ClusterServerCfg::getRunningSrvIds()
*
*   Description     :   populates vector of running srv ids
*
*   Creation Date   :   PMSTA-33371 - JBC  - 181204
*
*   Last Modif.     :
*
*************************************************************************/
void ClusterServerCfg::getRunningSrvIds(std::vector<ID_T> & srvIds)
{
    for(auto it = m_runServers.begin();it != m_runServers.end();++it)
    {
        srvIds.push_back(it->second);
    }
}


/************************************************************************
*   Function        :   ClusterServerCfg::getRunningSrvNames()
*
*   Description     :   populates vector of running srv names
*
*   Creation Date   :   PMSTA-40887 - JBC  - 200718
*                           
*   Last Modif.     :   
*
*************************************************************************/
void ClusterServerCfg::getRunningSrvNames(std::vector<std::string> & srvNames)
{
    for(auto it = m_runServers.begin();it != m_runServers.end();++it)
    {
        srvNames.push_back(it->first);
    }  
}

int ClusterServerCfg::getRunningSrvCount() const
{
    return static_cast<int>(m_runServers.size());
}


/************************************************************************
*   Function        :   ClusterServerCfg::isSingleBusEntity()
*   
*   Description     :  
*
*   Return          :  
*
*   Creation Date   :   PMSTA-41113 - JBC - 200922 : Server by BE
*                           
*   Last Modif.     :  
*
*************************************************************************/
bool ClusterServerCfg::isLockedBusEntity()
{
    return m_lockedBusEntityCd.empty() == false;
}


/************************************************************************
*   Function        :   ClusterServerCfg::getLockedBusEntity()
*   
*   Description     :  
*
*   Return          :  
*
*   Creation Date   :   PMSTA-41113 - JBC - 200922 : Server by BE
*                           
*   Last Modif.     :  
*
*************************************************************************/
std::string & ClusterServerCfg::getLockedBusEntity()
{
    return m_lockedBusEntityCd;
}


/************************************************************************
*   Function        :   ClusterServerCfg::setDelegateValidity()
*   
*   Description     :  
*
*   Return          :  
*
*   Creation Date   :   PMSTA-53744 - JBC - 230706
*                           
*   Last Modif.     :  
*
*************************************************************************/
void ClusterServerCfg::setDelegateValidity(const bool isValid)
{
    if(isPrimeThread())
    {
        m_isDelegateValid.store(isValid);
    }  
}


/************************************************************************
*   Function        :   ClusterServerCfg::getClusterTypeName()
*   
*   Description     :  For logging messages
*
*   Return          :  
*
*   Creation Date   :   PMSTA-40377 - JBC - 200928 : Cluster Active Fusion - Cash Portfolios, Benchmarking, Subscription, Pass Automator / UTP
*                           
*   Last Modif.     :  
*
*************************************************************************/
std::string ClusterServerCfg::getClusterTypeName()
{
    switch(m_configType)
    {
        case ClusterCfg_Fusion:
            return "Active Fusion";
        case ClusterCfg_TaxLot:
            return "Active Tax Lot";
        default:
            return "Default";
    }
}


/************************************************************************
*   Function        :   ClusterServerCfg::isLogged()
*   
*   Description     :  for log messages
*
*   Return          :  
*
*   Creation Date   :   PMSTA-40377 - JBC - 200928 : Cluster Active Fusion - Cash Portfolios, Benchmarking, Subscription, Pass Automator / UTP
*                           
*   Last Modif.     :  
*
*************************************************************************/
bool ClusterServerCfg::isLogged()
{
   switch(m_configType)
   {
        case ClusterCfg_Fusion:
            return true;
        case ClusterCfg_TaxLot:
            return isPrimeThread();
        default:
            return false;
   }
}

void SERV_StopAllServiceConfig()
{
    LockGuard Lock(SV_ThreadSrvAdminLock);

    if (ThreadState::Initialization == SV_ThreadSrvAdmin.load())
    { /* The thread was not started */
        SV_ThreadSrvAdmin.store(ThreadState::Stopped);
    }
    else
    {            
        SV_ThreadSrvAdmin.store(ThreadState::Leaving);
    }
}

/*******************************************************************************
 **      END  clusterconfig.cpp
 *******************************************************************************/

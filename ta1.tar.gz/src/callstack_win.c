/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#pragma once

#include <windows.h>
#include <set>
#include <string>
#ifdef NT
#pragma warning(disable:4091)       /*  To avoid compilation warning: warning C4091: 'typedef ': ignored on left of '<unnamed-enum-hdBase>' when no variable is declared    */
#endif
#include <dbghelp.h>
#ifdef NT
#pragma warning(default:4091)
#endif

#include "sysformat.h"

/*******************************************************************************
**      Global variables
*******************************************************************************/

static std::set<std::string> SV_SetBannedFunction;

/************************************************************************
**
**  Function    :   OS_InitializationCallStack()
**
**  Description :   This create a set of function to not display on the callstack to have a "light" stack trace
**
**  Arguments   :
**
**
**  Return      :
**
**  Last modif. :  PMSTA-22000 - 231215 - PMO : Finish, test and integrate the stack trace on Windows
**
*************************************************************************/
void OS_InitializationCallStack()
{
    HANDLE          hProcess = GetCurrentProcess();
    SymInitialize(hProcess, NULL, TRUE);

    SV_SetBannedFunction.insert("_BuildCatchObjectHelper");
    SV_SetBannedFunction.insert("BaseThreadInitThunk");
    SV_SetBannedFunction.insert("mainCRTStartup");
    SV_SetBannedFunction.insert("__tmainCRTStartup");
    SV_SetBannedFunction.insert("__scrt_common_main");
    SV_SetBannedFunction.insert("__scrt_common_main_seh");
    SV_SetBannedFunction.insert("invoke_main");
    SV_SetBannedFunction.insert("OS_GetCallStack");
    SV_SetBannedFunction.insert("SYS_GetCallStack");
    SV_SetBannedFunction.insert("RtlUserThreadStart");
    SV_SetBannedFunction.insert("RtlCaptureContext");
    SV_SetBannedFunction.insert("RtlInitializeExceptionChain");
    SV_SetBannedFunction.insert("RtlRestoreContext");
    SV_SetBannedFunction.insert("RtlUnicodeStringToInteger");
    SV_SetBannedFunction.insert("beginthreadex");
    SV_SetBannedFunction.insert("endthreadex");
    SV_SetBannedFunction.insert("DispatchMessageW");
    SV_SetBannedFunction.insert("QRectF::y");
    SV_SetBannedFunction.insert("QThread::start");
    SV_SetBannedFunction.insert("QTcpServer::serverAddress");
    SV_SetBannedFunction.insert("QInternal::callFunction");
    SV_SetBannedFunction.insert("QStateMachinePrivate::processedPendingEvents");
    SV_SetBannedFunction.insert("QDnsLookup::pointerRecords");
    SV_SetBannedFunction.insert("QUrl::setQuery");
    SV_SetBannedFunction.insert("qHash");
    SV_SetBannedFunction.insert("srv_regcreate");
    SV_SetBannedFunction.insert("srv_run");
    SV_SetBannedFunction.insert("srv_capability_info");
    SV_SetBannedFunction.insert("srv_ucwakeup");
    SV_SetBannedFunction.insert("WinMainCRTStartup");
    SV_SetBannedFunction.insert("CallWindowProcW");
    SV_SetBannedFunction.insert("QAbstractTransition::d_func");
    SV_SetBannedFunction.insert("QSslCipher::usedBits");
    SV_SetBannedFunction.insert("QItemSelectionRange::isValid");
    SV_SetBannedFunction.insert("QAuthenticator::setRealm");
    SV_SetBannedFunction.insert("QTimeZone::hasDaylightTime");
    SV_SetBannedFunction.insert("QNetworkAddressEntry::isPermanent");
}


/************************************************************************
**
**  Function    :   OS_RemoveCallStack()
**
**  Description :   Memory cleanup
**
**  Arguments   :
**
**
**  Return      :
**
**  Last modif. :   PMSTA-25852 - 110117 - PMO : Integrate getcallstack as a standard TripleA library
**
*************************************************************************/
void OS_RemoveCallStack()
{
    HANDLE          hProcess = GetCurrentProcess();
    SymCleanup(hProcess); /* PMSTA-33980 - LJE - 181210 */

    SV_SetBannedFunction.clear();
}


/************************************************************************
**
**  Function    :   OS_GetCallStack()
**
**  Description :
**
**  Arguments   :   binaryDebug  bool    If the binary is compiled in debug mode
**
**  Return      :
**
**  Last modif. :  PMSTA-21097 100815 - SRIDHARA- START
**                 PMSTA-22000 - 231215 - PMO : Finish, test and integrate the stack trace on Windows
**
*************************************************************************/
char * OS_GetCallStack(const bool printAddress)
{
    const int       maxFrame = 100;
    void         *  stack[maxFrame];
    std::string     stackFrame;
    HANDLE          hProcess = GetCurrentProcess();

    const int       frames = CaptureStackBackTrace(0, maxFrame, stack, NULL);

    // This ugly coding practice comes from  Microsoft example. It crash Without the +256 :-O
    SYMBOL_INFO  *  symbol = (SYMBOL_INFO *)calloc(sizeof(SYMBOL_INFO) + 256 * sizeof(char), 1);
    symbol->MaxNameLen   = 255;
    symbol->SizeOfStruct = sizeof(SYMBOL_INFO);

    IMAGEHLP_LINE64 imgHelpLine;
    DWORD           displacement;

    for (int i = 0; i < frames; i++)
    {
        const BOOL  bSymbol         = SymFromAddr         (hProcess, (DWORD64)stack[i], 0, symbol);
        bool        bannedFunction  = false;
        bool        endGUIStack = false;     /* PMSTA-27348 CMILOS 121118 */

        if (TRUE == bSymbol)
        {   // Look for a banned function
            std::set<std::string>::iterator it = SV_SetBannedFunction.find(symbol->Name);
            bannedFunction  = it != SV_SetBannedFunction.end();
        }
        else
        { /* Avoid to have only the address */
            bannedFunction = true;
        }

        if (false == bannedFunction)
        {
            const BOOL bSource = SymGetLineFromAddr64(hProcess, (DWORD64)stack[i], &displacement, &imgHelpLine);

            // a line like that: 000000000141a660 : main  line:918  aaa.c
            if (printAddress)
            {
                if (TRUE == bSymbol)
                {
                    stackFrame += SYS_ToString((void*)symbol->Address);
                }
                else
                {
                    stackFrame += SYS_ToString((void*)stack[i]);
                }

                stackFrame += " : ";
            }

            if (TRUE == bSymbol)
            {
                stackFrame += symbol->Name;
                /* PMSTA-27348 CMILOS 121118 */
                if (strcmp(symbol->Name, "main_gui2") == 0)
                    endGUIStack = true;
            }

            if (TRUE == bSource)
            {
                stackFrame += "  line:";
                stackFrame += SYS_ToString(int(imgHelpLine.LineNumber));
                stackFrame += "  ";

                std::string     filePath = imgHelpLine.FileName;
                const size_t    endTag   = filePath.rfind("\\");

                if (std::string::npos != endTag)
                { // Remove the path
                    filePath.erase(0, endTag + 1);
                }

                stackFrame += filePath;
            }

            stackFrame += "\n";
        }

        /* PMSTA-27348 CMILOS 121118 */
        if (endGUIStack == true)
            break;
    }

    free(symbol);

    #pragma warning( disable: 4996 )    // The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: _strdup. See online help for details.
    return strdup(stackFrame.c_str());
}

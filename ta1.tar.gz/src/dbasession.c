/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**    Main subject : various TSL/PG related session and ordering services
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DBASESSION_C

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H

#include "unidef.h"     /* Mandatory */
#include "gen.h"
#include "dba.h"
#include "fin.h"
#include "proc.h"
#include "cmp.h"
#include "ope.h"

#ifndef TLS_H
#include "tls.h"
#endif

#ifndef HIER_H
#include "hier.h"
#endif

#include "scptyl.h"

#ifdef NT
#include <crtdbg.h>
#endif

#if ((defined AAAPURIFY) || (defined AAAQUANTIFY)) && (defined NT)
#include <pure.h>
#endif


/************************************************************************
**      External entry points
**
*************************************************************************/
extern RET_CODE DBA_TabulaRasa(ID_T, CASEMANAGEMENTNAT_ENUM, int*);

/************************************************************************
**      Local functions
**
*************************************************************************/

/************************************************************************
**      Static definitions & data
**
*************************************************************************/

/************************************************************************
**      FONCTIONS
**
************************************************************************/

/************************************************************************
*   Function             : DBA_InitDataForSessionHandling()
*
*   Description          : Get session and current user for publish/copy session
*
*   Arguments            : getArgPtr    : RPC input params
*                          sFctResPtr   : initial function result
*                          aApplUserPtr : current user settings
*
*   Return               : RET_SUCCEED or error
*
*   Creation Date        : PMSTA09151/PMSTA9264-CHU-100219
*
*   Modif                : PMSTA13167 - DDV - 111222 - Change inputSt to SessionMgt
*                          PMSTA-16124 - 250413 - PMO : Ensure coherence of printf / scanf formats with 32bits / 64 bits datatypes
*
*************************************************************************/
RET_CODE DBA_InitDataForSessionHandling(DBA_DYNFLD_STP			sessionMgt,
										DBA_DYNFLD_STP			*aFctResPtr,
										DBA_DYNFLD_STP			*aApplUserPtr,
                                        DbiConnection           &dbiConn)
{
	RET_CODE		ret         = RET_SUCCEED;
	DBA_DYNFLD_STP	sApplUserSt = NULL,
					sFctResSt   = NULL;

	if (IS_NULLFLD(sessionMgt, SessionMgt_UserId) == FALSE &&
		GET_ID(sessionMgt, SessionMgt_UserId) > 0)
	{
	/* Check the User */
		sApplUserSt = ALLOC_DYNST(S_ApplUser);
		(*aApplUserPtr) = ALLOC_DYNST(A_ApplUser);

		COPY_DYNFLD(sApplUserSt, S_ApplUser, S_ApplUser_Id,
					sessionMgt,  SessionMgt,     SessionMgt_UserId);

		if ((ret = DBA_Get2(ApplUser, UNUSED,
				   S_ApplUser, sApplUserSt,
				   A_ApplUser, aApplUserPtr,
				   DBA_SET_CONN|DBA_NO_CLOSE, dbiConn,
				   UNUSED)) != RET_SUCCEED)
		{
			char idStr[256];
			sprintf(idStr, "%" szFormatId, GET_ID(sessionMgt, SessionMgt_UserId));              /* PMSTA-16124 - 250413 - PMO */

			MSG_SendMesg(RET_DBA_ERR_NODATA, 4, FILEINFO, "appl_user", idStr);
			return(RET_DBA_INFO_NODATA);
		}
		FREE_DYNST(sApplUserSt, S_ApplUser);
	}
	else
	{
		return(RET_DBA_INFO_NODATA);
	}

	if ((sFctResSt = ALLOC_DYNST(S_FctResult)) == NULL)
	{
		return(RET_MEM_ERR_ALLOC);
	}

	/* Retrieve Original session */
	COPY_DYNFLD(sFctResSt, S_FctResult, S_FctResult_Id,
				sessionMgt, SessionMgt,     SessionMgt_FromId);

	COPY_DYNFLD(sFctResSt, S_FctResult, S_FctResult_Cd,
				sessionMgt, SessionMgt,     SessionMgt_FromCd);

	if (IS_NULLFLD(sFctResSt, S_FctResult_Id) == TRUE &&
		IS_NULLFLD(sFctResSt, S_FctResult_Cd) == TRUE)
	{
		FREE_DYNST(sFctResSt, S_FctResult);
		return(RET_SRV_GEN_ERR_INVARG);
	}

	/******************************************/
	/*** Allocate a A_FctResult             ***/
	/******************************************/
	if (((*aFctResPtr) = ALLOC_DYNST(A_FctResult)) == NULL)
	{
		FREE_DYNST(sFctResSt, S_FctResult);
		return(RET_MEM_ERR_ALLOC);
	}

	/* Load A_FctResult */
	if ((ret = DBA_Get2(FctResult, 
                        UNUSED, 
                        S_FctResult, 
                        sFctResSt,
                        A_FctResult, 
                        aFctResPtr, 
                        DBA_SET_CONN|DBA_NO_CLOSE,
                        dbiConn)) != RET_SUCCEED)
	{
		FREE_DYNST(sFctResSt, S_FctResult);
		FREE_DYNST((*aFctResPtr), A_FctResult);
		return(RET_SRV_GEN_ERR_INVARG);
	}

	FREE_DYNST(sFctResSt, S_FctResult);

	/* PMSTA11002-CHU-101220 : get additional parameters for manage_session */
	if(IS_NULLFLD(sessionMgt, SessionMgt_Mode)==FALSE)
	{
        /* PMSTA-34173 - CHU - 181218 : The COPY_DYNFLD is setting this attribute as NOT NULL
           even if it's null in the initial input dynSt given to the RPC
	    if (IS_NULLFLD(sessionMgt, SessionMgt_BuySellFlg) == TRUE)
        */
	    {
    	    if (IS_NULLFLD(sessionMgt, SessionMgt_OldOption) == FALSE)
		    {
	            if (GET_ENUM(sessionMgt, SessionMgt_OldOption) == sessionMgtOption_AddBuySell ||
	                GET_ENUM(sessionMgt, SessionMgt_OldOption) == sessionMgtOption_AddOrCleanAll)
	            {
	                SET_FLAG(sessionMgt, SessionMgt_BuySellFlg, TRUE);
	            }
	            else
	            {
	                SET_FLAG(sessionMgt, SessionMgt_BuySellFlg, FALSE);
	            }
		    }
		    else
		    {
                SET_FLAG(sessionMgt, SessionMgt_BuySellFlg, TRUE);
			    /* set technical default */
		        switch(GET_ENUM(sessionMgt, SessionMgt_Mode))
			    {
			    case	sessionMgtMode_Trade:
				case	sessionMgtMode_PostValidation: /* PMSTA15852-CHU-130125 */
	                SET_FLAG(sessionMgt, SessionMgt_BuySellFlg, TRUE);
				    break;

			    case 	sessionMgtMode_Copy :
			    case	sessionMgtMode_Amend:
			    case	sessionMgtMode_Clean:
			    case	sessionMgtMode_Cancel: /* N/A */
			    /* no break */
			    default:
			        SET_ENUM(sessionMgt, SessionMgt_OldOption, sessionMgtOption_AddOrCleanAll);
				    break;
			    }
		    }
	    }
	}

    /* PMSTA-34173 - CHU - 181218 : The COPY_DYNFLD is setting this attribute as NOT NULL
       even if it's null in the initial input dynSt given to the RPC
	if (IS_NULLFLD(sessionMgt, SessionMgt_ExternalPosFlg) == TRUE)
    */
	{
    	if (IS_NULLFLD(sessionMgt, SessionMgt_OldOption) == FALSE)
    	{
	        if (GET_ENUM(sessionMgt, SessionMgt_OldOption) == sessionMgtOption_AddExternPos ||
	            GET_ENUM(sessionMgt, SessionMgt_OldOption) == sessionMgtOption_AddOrCleanAll)
		{
	            SET_FLAG(sessionMgt, SessionMgt_ExternalPosFlg, TRUE);
	        }
	        else
	        {
	            SET_FLAG(sessionMgt, SessionMgt_ExternalPosFlg, FALSE);
	        }
		}
		else
		{
			/* set technical default */
		    switch(GET_ENUM(sessionMgt, SessionMgt_Mode))
			{
			case	sessionMgtMode_Trade:
			case	sessionMgtMode_PostValidation: /* PMSTA15852-CHU-130125 */
	            SET_FLAG(sessionMgt, SessionMgt_ExternalPosFlg, FALSE);
				break;

			case 	sessionMgtMode_Copy :
			case	sessionMgtMode_Amend:
			case	sessionMgtMode_Clean:
			case	sessionMgtMode_Cancel: /* N/A */
			/* no break */
			default:
	            SET_FLAG(sessionMgt, SessionMgt_ExternalPosFlg, TRUE);
				break;
			}
		}
	}

    /* PMSTA-34173 - CHU - 181218 : The COPY_DYNFLD is setting this attribute as NOT NULL
       even if it's null in the initial input dynSt given to the RPC
    */
    if (IS_NULLFLD(sessionMgt, SessionMgt_KeepCommFlg) == TRUE ||
        (IS_NULLFLD(sessionMgt, SessionMgt_OldOption) == FALSE &&
         GET_ENUM(sessionMgt, SessionMgt_OldOption) == sessionMgtOption_AddOrCleanAll &&
         GET_FLAG(sessionMgt, SessionMgt_KeepCommFlg) == FALSE))
	{
		/* set technical default */
		switch(GET_ENUM(sessionMgt, SessionMgt_Mode))
		{
		case	sessionMgtMode_Trade:
		case	sessionMgtMode_PostValidation: /* PMSTA15852-CHU-130125 */
    		SET_FLAG(sessionMgt, SessionMgt_KeepCommFlg, FALSE);
			break;

		case 	sessionMgtMode_Copy :
		case	sessionMgtMode_Amend:
		case	sessionMgtMode_Clean:
		case	sessionMgtMode_Cancel: /* N/A */
		/* no break */
		default:
    		SET_FLAG(sessionMgt, SessionMgt_KeepCommFlg, TRUE);
			break;
		}
	}

	return(ret);
}

/************************************************************************
*   Function             : DBA_NewExtOpForCopySession()
*
*   Description          : Make new ExtOp for Copy Session  RPC
*
*   Arguments            : the ExtOp to clean
*
*   Return               : RET_SUCCEED
*
*   Creation Date        : PMSTA09264-CHU-100212
*
*   Modif.               : PMSTA-21231 - CHU - 150915 : use same connectNo for DV's
*
*************************************************************************/
RET_CODE DBA_NewExtOpForCopySession(DBA_DYNFLD_STP	destExtOpPtr,
									DBA_DYNFLD_STP	src_ExtOpPtr,
									DBA_DYNFLD_STP	newFctResPtr,
									DBA_DYNFLD_STP	domainPtr,
									DATETIME_T		currentDateTime,
									int				*connectNo) /* PMSTA-21231 - CHU - 150915 */
{
	RET_CODE	ret = RET_SUCCEED;
	int			i;
	FLAG_T		*pflagTab;

	if ((pflagTab = (FLAG_T*) CALLOC(GET_FLD_NBR(ExtOp), sizeof(FLAG_T))) == NULL)
	{
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	COPY_DYNST(destExtOpPtr, src_ExtOpPtr, ExtOp);

	SET_NULL_ID(destExtOpPtr, ExtOp_OpId);
	SET_NULL_ID(destExtOpPtr, ExtOp_DbId);
	SET_NULL_ID(destExtOpPtr, ExtOp_DraftOrderId);

	SET_NULL_ID(destExtOpPtr, ExtOp_ExtStratEltId);
	SET_NULL_DATETIME(destExtOpPtr, ExtOp_BeginDate);
	SET_NULL_CODE(destExtOpPtr, ExtOp_Cd);
	SET_NULL_DATETIME(destExtOpPtr, ExtOp_EndDate);
	SET_NULL_DATETIME(destExtOpPtr, ExtOp_LastModifDate);
	SET_NULL_DATETIME(destExtOpPtr, ExtOp_AudModifDate);
	SET_NULL_DATETIME(destExtOpPtr, ExtOp_ValueDate);

	SET_DATETIME(destExtOpPtr, ExtOp_AcctDate, currentDateTime);
	SET_DATETIME(destExtOpPtr, ExtOp_OpDate,   currentDateTime);

	SET_ID(destExtOpPtr, ExtOp_FctResultId, GET_ID(newFctResPtr, A_FctResult_Id));

	SET_ENUM(destExtOpPtr, ExtOp_CheckStratEn, CheckStrat_None);
	SET_FLAG_TRUE(destExtOpPtr, ExtOp_ConfirmedFlg); /* ou bien ? */

	SET_ID(destExtOpPtr, ExtOp_InputUserId,	GET_ID(domainPtr, A_Domain_UsrId));
	SET_ID(destExtOpPtr, ExtOp_LastUserId,	GET_ID(domainPtr, A_Domain_UsrId));

	memset(pflagTab, 0, sizeof(FLAG_T) * GET_FLD_NBR(ExtOp));
	for (i = 0; i < GET_FLD_NBR(ExtOp); i++)
	{
		if (IS_NULLFLD(destExtOpPtr,i) == FALSE)
		{
			pflagTab[i] = TRUE;
		}
	}

	pflagTab[ExtOp_NatureEn] = TRUE;
	/* pflagTab[ExtOp_Cd] = TRUE; */ /* do not generate any code */
    pflagTab[ExtOp_Cd] = DBA_GetOrderCodeInSessionSysParam(); /* PMSTA-25183 - CHU - 161108 */

	/* Et zou, les DV */
	SCPT_ComputeScreenDV(EOp,
						 GET_DICT(domainPtr, A_Domain_FctDictId),
						 pflagTab,
                         NULL,              /* HFI-PMSTA-25327-171023  Dedicated flag tab for filter    */
						 destExtOpPtr,
						 NULL,
						 domainPtr,
                         NULLDYNST,   /* PMSTA13283 - DDV - 120117 */
						 TRUE,
						 TRUE,
						 EvalType_DefVal,
						 -1,
						 connectNo,	/* PMSTA-21231 - CHU - 150915 */
						 NULL,
						 NULL,
						 0,
						 DictScreen,
						 NULL,
						 NULL,
						 NULL,
						 NULL,
						 NULL,
						 NullEntity,
						 FALSE,
						 FALSE,
                         0);

	return(ret);
}

/************************************************************************
*   Function             : DBA_UpdateDomainsForManageSession()
*
*   Description          : Update fields of both domains for Manage Session  RPC
*
*   Arguments            : the Domains to update
*
*   Return               : RET_SUCCEED
*
*   Creation Date        : PMSTA11002-CHU-110126
*
*************************************************************************/
void DBA_SetSessionDescription(DBA_DYNFLD_STP			dest_A_DomainPtr,
							   SESSION_MGT_MODE_ENUM	sessMgtMode)
{
	INFO_T	newDescriptionPtr;
	char	copy_trade_Str[80];
	int		strPos = 0;

	if (sessMgtMode == sessionMgtMode_Copy)
	{
		SET_NULL_INFO(dest_A_DomainPtr, A_Domain_SessionDescriptionInfo);
	}
	else
	{
		strcpy(newDescriptionPtr, GET_INFO(dest_A_DomainPtr, A_Domain_SessionDescriptionInfo));

		if (sessMgtMode == sessionMgtMode_Amend)
		{
			strcpy(copy_trade_Str, "- Copy");
		}
		else if (sessMgtMode ==sessionMgtMode_Trade)
		{
			strcpy(copy_trade_Str, "- Trade");
		}
		else if (sessMgtMode ==sessionMgtMode_PostValidation) /* PMSTA15852-CHU-130125 */
		{
			strcpy(copy_trade_Str, "- Post Val");
		}

		if (strlen(newDescriptionPtr) + strlen(copy_trade_Str) > GET_MAXCHARLEN(InfoType))  /* PMSTA-33077 - DLA - 181005 */
		{
			strPos = GET_MAXCHARLEN(InfoType) - SYS_StrLen(copy_trade_Str);
			strcat(&newDescriptionPtr[strPos], copy_trade_Str);
		}
		else
		{
			strcat(newDescriptionPtr, copy_trade_Str);
		}
	}
	return;
}

/************************************************************************
*   Function             : DBA_UpdateDomainsForManageSession()
*
*   Description          : Update fields of both domains for Manage Session  RPC
*
*   Arguments            : the Domains to update
*
*   Return               : RET_SUCCEED
*
*   Creation Date        : PMSTA11002-CHU-110126
*
*************************************************************************/
RET_CODE DBA_UpdateDomainsForManageSession(DBA_DYNFLD_STP			src_A_DomainPtr,
										   DBA_DYNFLD_STP			dest_A_DomainPtr,
										   DATETIME_T				currentDateTime,
										   SESSION_MGT_MODE_ENUM	sessMgtMode,
										   FLAG_T					*updateSrcSessionFlg,
										   FLAG_T					*createNewSessionFlg)
{
	RET_CODE	ret = RET_SUCCEED;

	switch(sessMgtMode)
	{
	case sessionMgtMode_Copy:
		/* ********************* */
		/* Manage Source Session */
		/* ********************* */
		/* N/A */

		/* ********************* */
		/* Manage Target Session */
		/* ********************* */
		COPY_DYNST(   dest_A_DomainPtr, src_A_DomainPtr, A_Domain);

		/* OCS-47409 - CHU - 151201 : Keep original nature if PG or PG Client */
		if ((DOMSESSIONNAT_ENUM)GET_ENUM(dest_A_DomainPtr, A_Domain_SessionNatureEn) != DomSessionNat_InvestmentProposal &&
			(DOMSESSIONNAT_ENUM)GET_ENUM(dest_A_DomainPtr, A_Domain_SessionNatureEn) != DomSessionNat_InvestmentProposalClient)
		{
			SET_ENUM(     dest_A_DomainPtr, A_Domain_SessionNatureEn,	DomSessionNat_InvestmentProposal);
		}
		SET_ENUM(     dest_A_DomainPtr, A_Domain_ProposalNatureEn,	ProposalNat_Main);
		SET_NULL_ID(  dest_A_DomainPtr, A_Domain_ParentSessionId);
		*createNewSessionFlg = TRUE;
		break;

	case sessionMgtMode_Amend:
		/* ********************* */
		/* Manage Source Session */
		/* ********************* */
		SET_ENUM(     src_A_DomainPtr, A_Domain_ProposalNatureEn,	ProposalNat_Archive);
		*updateSrcSessionFlg = TRUE;

		/* ********************* */
		/* Manage Target Session */
		/* ********************* */
		COPY_DYNST(   dest_A_DomainPtr, src_A_DomainPtr, A_Domain);

		SET_ENUM(     dest_A_DomainPtr, A_Domain_ProposalNatureEn,	ProposalNat_Main);
		SET_ID(		  dest_A_DomainPtr, A_Domain_ParentSessionId,	GET_ID(src_A_DomainPtr, A_Domain_FctResultId));
		*createNewSessionFlg = TRUE;
		break;

	case sessionMgtMode_Trade:
	case sessionMgtMode_PostValidation: /* PMSTA15852-CHU-130125 */
		/* ********************* */
		/* Manage Source Session */
		/* ********************* */
		/* SET_ENUM(     src_A_DomainPtr, A_Domain_FctResultStatEn,	FctResultStatus_Final); */
		*updateSrcSessionFlg = TRUE;

		/* ********************* */
		/* Manage Target Session */
		/* ********************* */
		COPY_DYNST(   dest_A_DomainPtr, src_A_DomainPtr, A_Domain);

		SET_ENUM(     dest_A_DomainPtr, A_Domain_SessionNatureEn,	DomSessionNat_Order);
		SET_ENUM(     dest_A_DomainPtr, A_Domain_ProposalNatureEn,	ProposalNat_Trade);
		SET_ID(		  dest_A_DomainPtr, A_Domain_ParentSessionId,	GET_ID(src_A_DomainPtr, A_Domain_FctResultId));
		*createNewSessionFlg = TRUE;
		break;

	case sessionMgtMode_Cancel:
		/* ********************* */
		/* Manage Source Session */
		/* ********************* */
		SET_ENUM(     src_A_DomainPtr, A_Domain_SessionStatusEn,	SessionStatus_Cancelled);
		*updateSrcSessionFlg = TRUE;

		/* ********************* */
		/* Manage Target Session */
		/* ********************* */
		/* N/A */
		break;
	}

	/* PMSTA15852-CHU-130125 : Manage new session status */
	if (sessMgtMode == sessionMgtMode_PostValidation)
	{
		SET_ENUM(src_A_DomainPtr, A_Domain_SessionStatusEn,	SessionStatus_ValidatedForTrading);
	}
	else if (sessMgtMode == sessionMgtMode_Trade)
	{
		SET_ENUM(src_A_DomainPtr, A_Domain_SessionStatusEn,	SessionStatus_ReleasedForTrading);
	}

	if (TRUE == (*createNewSessionFlg))
	{
		SET_NULL_ID(  dest_A_DomainPtr, A_Domain_Id);
		SET_NULL_ID(  dest_A_DomainPtr, A_Domain_FctResultId);
		SET_NULL_CODE(dest_A_DomainPtr, A_Domain_FctResultCd);

		/* Not sure if this is really useful :o)
		DBA_SetSessionDescription(dest_A_DomainPtr, sessMgtMode);
		*/

		SET_DATETIME( dest_A_DomainPtr, A_Domain_SessionCreationDate,	currentDateTime);
		SET_DATETIME( dest_A_DomainPtr, A_Domain_CalcRefDate,			currentDateTime);
		SET_DATETIME( dest_A_DomainPtr, A_Domain_InterpFromDate,		currentDateTime);
		SET_DATETIME( dest_A_DomainPtr, A_Domain_InterpStratDate,		currentDateTime);
		SET_DATETIME( dest_A_DomainPtr, A_Domain_InterpTillDate,		currentDateTime);
		SET_DATETIME( dest_A_DomainPtr, A_Domain_InterpFreqDate,		currentDateTime);
		SET_ENUM(     dest_A_DomainPtr, A_Domain_SessionStatusEn,		SessionStatus_Working);
		SET_ENUM(     dest_A_DomainPtr, A_Domain_FctResultStatEn,		FctResultStatus_Draft);
		/**** Not yet decided ***
		SET_ID(		  dest_A_DomainPtr, A_Domain_UsrId,	GET_ID(aApplUserPtr, A_ApplUser_Id));
		*/
	}

	return (ret);
}

/************************************************************************
*   Function             : DBA_NewExtOpForManageSession()
*
*   Description          : Make new ExtOp for Copy Session  RPC
*
*   Arguments            : the ExtOp to clean
*
*   Return               : RET_SUCCEED
*
*   Creation Date        : PMSTA09264-CHU-100212
*
*   Modif.               : PMSTA-21231 - CHU - 150915 : use same connectNo for DV's
*
*************************************************************************/
RET_CODE DBA_NewExtOpForManageSession(DBA_DYNFLD_STP	destExtOpPtr,
									  DBA_DYNFLD_STP	src_ExtOpPtr,
									  DBA_DYNFLD_STP	newFctResPtr,
									  DBA_DYNFLD_STP	domainPtr,
									  DATETIME_T		currentDateTime,
									  SESSION_MGT_MODE_ENUM	sessionMode,
									  int				*connectNo) /* PMSTA-21231 - CHU - 150915 */
{
	RET_CODE	ret = RET_SUCCEED;
	FLAG_T		savedExtOpNoPositionFlg=FALSE;
	OPSTAT_ENUM	applExternalPosStatus = OpStat_Cancelled;
    DICT_T saveDictId = GET_DICT(domainPtr, A_Domain_FctDictId);
	MemoryPool mp;

	GEN_GetApplInfo(ApplExternalPosStatus, &applExternalPosStatus);

	FLAG_T *pflagTab = (FLAG_T*) mp.calloc(GET_FLD_NBR(ExtOp), sizeof(FLAG_T));
	memset(pflagTab, 0, sizeof(FLAG_T) * GET_FLD_NBR(ExtOp));

	COPY_DYNST(destExtOpPtr, src_ExtOpPtr, ExtOp);

    /* ****************** */
    /* Fields set to NULL */
    /* ****************** */
	/* PMSTA-20603-CHU-150715 : do this later, when links are set for DBA_FamilyOrder() */
	/*
	SET_NULL_ID(destExtOpPtr,		ExtOp_OpId);
	SET_NULL_ID(destExtOpPtr,		ExtOp_DbId);
	SET_NULL_ID(destExtOpPtr,		ExtOp_DraftOrderId);
	SET_NULL_CODE(destExtOpPtr,		ExtOp_Cd);
	SET_NULL_CODE(destExtOpPtr,		ExtOp_ParOpCd); */ /* PMSTA-20603 - CHU - 150610 */

	SET_NULL_ID(destExtOpPtr,		ExtOp_ExtStratEltId);
	SET_NULL_DATETIME(destExtOpPtr,	ExtOp_BeginDate);
	SET_NULL_DATETIME(destExtOpPtr, ExtOp_AudModifDate);
	SET_NULL_DATETIME(destExtOpPtr, ExtOp_ValueDate);
    SET_NULL_DATETIME(destExtOpPtr, ExtOp_CommunicationDate);

    /* Forced Fields */
	SET_DATETIME(destExtOpPtr,		ExtOp_OpDate,       currentDateTime);                       pflagTab[ExtOp_OpDate]      = TRUE;
    SET_DATETIME(destExtOpPtr,		ExtOp_CreationTime, currentDateTime);                       pflagTab[ExtOp_CreationTime]= TRUE;
	SET_ID(destExtOpPtr,			ExtOp_FctResultId,  GET_ID(newFctResPtr, A_FctResult_Id));  pflagTab[ExtOp_FctResultId] = TRUE;
	SET_ENUM(destExtOpPtr,			ExtOp_CheckStratEn, StratCheck_None);                       pflagTab[ExtOp_CheckStratEn]= TRUE;
	SET_ID(destExtOpPtr,			ExtOp_InputUserId,	GET_ID(domainPtr, A_Domain_UsrId));     pflagTab[ExtOp_InputUserId] = TRUE;
    SET_FLAG_TRUE(destExtOpPtr,		ExtOp_ConfirmedFlg);                                        pflagTab[ExtOp_ConfirmedFlg]= TRUE;

    /* **************** */
    /* Protected Fields */
    /* **************** */
	pflagTab[ExtOp_NatureEn]=TRUE; /* Keep operation nature... */

	if (applExternalPosStatus > OpStat_Cancelled && /* specifically protect External Pos status from any DV */
		applExternalPosStatus == (OPSTAT_ENUM)GET_ENUM(destExtOpPtr, ExtOp_StatusEn))
	{
		pflagTab[ExtOp_StatusEn]		= TRUE;
		pflagTab[ExtOp_AcctId]			= TRUE;
		pflagTab[ExtOp_OpCurrId]		= TRUE;
		savedExtOpNoPositionFlg = GET_FLAG(destExtOpPtr, ExtOp_NoPositionFlg);
	}
	else /* for regular extended operations */
	{
		/* PMSTA-20603 - CHU - 150610 : allow code generation for block orders */
		if ((GET_ENUM(destExtOpPtr, ExtOp_ParOpNatEn) != ParOpNat_UnallocBlkOrder) &&
			(GET_ENUM(destExtOpPtr, ExtOp_ParOpNatEn) != ParOpNat_BlockOrder) &&
			(GET_ENUM(destExtOpPtr, ExtOp_ParOpNatEn) != ParOpNat_CombinedOrder))
		{
			/* pflagTab[ExtOp_Cd] = TRUE; */ /* do not generate any code */
            pflagTab[ExtOp_Cd] = DBA_GetOrderCodeInSessionSysParam(); /* PMSTA-25183 - CHU - 161108 */
		}
		SET_NULL_DATETIME(destExtOpPtr, ExtOp_EndDate);

		pflagTab[ExtOp_TargetNatureEn]	= TRUE;
		pflagTab[ExtOp_RenewalAmount]	= TRUE;
		pflagTab[ExtOp_TargetNumber]	= TRUE;
		pflagTab[ExtOp_MarketSegmentId]	= TRUE;
        pflagTab[ExtOp_StatusEn] = TRUE;  /* PMSTA-35917 - Aiswarya - 20190515 */
        pflagTab[ExtOp_OpCurrId] = TRUE;  /* PMSTA-35917 - Aiswarya - 20190515 */
        pflagTab[ExtOp_MktThirdId] = TRUE;  /* PMSTA-35917 - Aiswarya - 20190515 */
	}

	/* Anyway, also protect these fields for all copied ext_operations/ext_orders : */
    pflagTab[ExtOp_ParOpNatEn]= TRUE; /* PMSTA-24292 - CHU - 160808 : reset to 0 when calling DV's on Sell orders... strange! */
	pflagTab[ExtOp_InstrId]	= TRUE;
	pflagTab[ExtOp_PtfId]	= TRUE;
	pflagTab[ExtOp_Qty]		= TRUE;

    /* ****************** */
    /* Call DV Evaluation */
    /* ****************** */
    SET_DICT(domainPtr, A_Domain_FctDictId, GET_DICT(domainPtr, A_Domain_InitialFctDictId));
    SCPT_ComputeScreenDVCreate(EOp,
                               GET_DICT(domainPtr, A_Domain_InitialFctDictId),
						       pflagTab,
                               NULL,              /* HFI-PMSTA-25327-171023  Dedicated flag tab for filter    */
						       destExtOpPtr,
						       NULL,
						       domainPtr,
                               FALSE,  /* partial because of some fiels are forced */
                               TRUE,   /* GUI mode because of we want to use GUI dflt */
						       -1,
						       connectNo,	/* PMSTA-21231 - CHU - 150915 */
						       NULL,
						       NULL,
						       0,
						       NULL,
                               NULL);
    SET_DICT(domainPtr, A_Domain_FctDictId, saveDictId);

	/* specifically protect External Pos status from any DV */
	if (applExternalPosStatus > OpStat_Cancelled &&
		applExternalPosStatus == (OPSTAT_ENUM)GET_ENUM(destExtOpPtr, ExtOp_StatusEn))
	{
		SET_FLAG(destExtOpPtr, ExtOp_NoPositionFlg, savedExtOpNoPositionFlg);
	}

	return(ret);
}

/************************************************************************
*   Function             : DBA_NewCommentForManageSession()
*
*   Description          : Make new Comments for Manage Session  RPC
*
*   Arguments            : the Comments to initialize
*
*   Return               : RET_SUCCEED
*
*   Creation Date        : PMSTA11002-CHU-101220
*
*   Modif                : PMSTA-21231 - CHU - 150915 : Use same connectNo for DV's
*
*************************************************************************/
RET_CODE DBA_NewCommentForManageSession(DBA_DYNFLD_STP	destCommPtr,
										DBA_DYNFLD_STP	src_CommPtr,
										DBA_DYNFLD_STP	newFctResPtr,
										DBA_DYNFLD_STP	domainPtr,
										DATETIME_T		currentDateTime,
										int				*connectNo) /* PMSTA-21231 - CHU - 150915 */
{
	RET_CODE	ret = RET_SUCCEED;
	FLAG_T		*pflagTab;

	if ((pflagTab = (FLAG_T*) CALLOC(GET_FLD_NBR(A_ApplComment), sizeof(FLAG_T))) == NULL)
	{
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}
	memset(pflagTab, 0, sizeof(FLAG_T) * GET_FLD_NBR(A_ApplComment));

	COPY_DYNST(destCommPtr, src_CommPtr, A_ApplComment);

	SET_NULL_ID(destCommPtr,		A_ApplComment_Id);

	SET_ID (destCommPtr,	A_ApplComment_ObjectId, GET_ID(newFctResPtr, A_FctResult_Id));
	pflagTab[A_ApplComment_ObjectId]=TRUE;

	SET_DATETIME(destCommPtr, A_ApplComment_CreationDate,   currentDateTime);
	pflagTab[A_ApplComment_CreationDate]=TRUE;

	SET_ID (destCommPtr,	A_ApplComment_LastUserId, GET_ID(domainPtr, A_Domain_UsrId));
	pflagTab[A_ApplComment_LastUserId]=TRUE;

	SET_DATETIME(destCommPtr, A_ApplComment_LastModifDate,  currentDateTime);
	pflagTab[A_ApplComment_LastModifDate]=TRUE;

	/* Et zou, les DV */
	SCPT_ComputeScreenDV(ApplComment,
						 GET_DICT(domainPtr, A_Domain_FctDictId),
						 pflagTab,
                         NULL,              /* HFI-PMSTA-25327-171023  Dedicated flag tab for filter    */
						 destCommPtr,
						 NULL,
						 domainPtr,
                         NULLDYNST,   /* PMSTA13283 - DDV - 120117 */
						 TRUE,
						 TRUE,
						 EvalType_DefVal,
						 -1,
						 connectNo,	/* PMSTA-21231 - CHU - 150915 */
						 NULL,
						 NULL,
						 0,
						 DictScreen,
						 NULL,
						 NULL,
						 NULL,
						 NULL,
						 NULL,
						 NullEntity,
						 FALSE,
						 FALSE,
                         0);

	return(ret);
}


/************************************************************************
*   Function             : DBA_NewDomainPtfCompoForManageSession()
*
*   Description          : Make new DomainPtfCompo for Manage Session  RPC
*
*   Arguments            : the DomainPtfCompo to initialize
*
*   Return               : RET_SUCCEED
*
*   Creation Date        : PMSTA-21529-CHU-151021
*
*************************************************************************/
RET_CODE DBA_NewDomainPtfCompoForManageSession(DBA_DYNFLD_STP	destDomPtfCompoPtr,
											   DBA_DYNFLD_STP	src_DomPtfCompoPtr,
											   DBA_DYNFLD_STP	newFctResPtr,
											   DBA_DYNFLD_STP	domainPtr,
											   DATETIME_T		currentDateTime,
											   int				*connectNo) /* PMSTA-21231 - CHU - 150915 */
{
	RET_CODE	ret = RET_SUCCEED;
	MemoryPool	mp;

	FLAG_T		*pflagTab = (FLAG_T*) mp.calloc(GET_FLD_NBR(A_DomainPtfCompo), sizeof(FLAG_T));
	memset(pflagTab, 0, sizeof(FLAG_T) * GET_FLD_NBR(A_DomainPtfCompo));

	COPY_DYNST(destDomPtfCompoPtr, src_DomPtfCompoPtr, A_DomainPtfCompo);

	SET_NULL_ID(destDomPtfCompoPtr,		A_DomainPtfCompo_Id);

	SET_ID (destDomPtfCompoPtr,	A_DomainPtfCompo_FunctionResultId, GET_ID(newFctResPtr, A_FctResult_Id));
	pflagTab[A_DomainPtfCompo_FunctionResultId]=TRUE;

	/* Et zou, les DV */
	SCPT_ComputeScreenDV(DomainPtfCompo,
						 GET_DICT(domainPtr, A_Domain_FctDictId),
						 pflagTab,
                         NULL,              /* HFI-PMSTA-25327-171023  Dedicated flag tab for filter    */
						 destDomPtfCompoPtr,
						 NULL,
						 domainPtr,
                         NULLDYNST,   /* PMSTA13283 - DDV - 120117 */
						 TRUE,
						 TRUE,
						 EvalType_DefVal,
						 -1,
						 connectNo,	/* PMSTA-21231 - CHU - 150915 */
						 NULL,
						 NULL,
						 0,
						 DictScreen,
						 NULL,
						 NULL,
						 NULL,
						 NULL,
						 NULL,
						 NullEntity,
						 FALSE,
						 FALSE,
                         0);

	return(ret);
}
/************************************************************************
*   Function             : DBA_CleanSession()
*
*   Description          : empty session (remove ESL, ESE, Eop & Cases)
*
*   Arguments            : DomainPtr
*
*   Return               : RET_SUCCEED
*
*   Creation Date        : PMSTA11002-CHU-110126
*
*************************************************************************/
RET_CODE DBA_CleanSession(DBA_DYNFLD_STP			domainPtr,
						  int						*connectNo,
						  FLAG_T					sessMgtKeepCommFlg,
						  DBA_DYNFLD_STP			sessionMgt)
{
	RET_CODE			ret			= RET_SUCCEED;	

	if (domainPtr != NULL)
	{
		MemoryPool			mp;
		DBA_DYNFLD_STP getArgPtr = mp.allocDynst(FILEINFO,Get_Arg);

		SET_ID(getArgPtr, Get_Arg_Id, GET_ID(domainPtr, A_Domain_FctResultId));

		/* delete Extended Strategy Links */
		ret = DBA_Delete2(EStratLnk, DBA_ROLE_LOAD_STRAT_LNK,
			   Get_Arg, getArgPtr, DBA_SET_CONN|DBA_NO_CLOSE,
			   connectNo);

		if (ret == RET_SUCCEED)
		{
			/* delete Extended Strategy Elements */
			SET_FLAG(getArgPtr, Get_Arg_Flag, FALSE);
			ret = DBA_Delete2(EStratElt, DBA_ROLE_LOAD_STRAT_LNK,
					   Get_Arg, getArgPtr, DBA_SET_CONN|DBA_NO_CLOSE,
					   connectNo);
		}

		if (ret == RET_SUCCEED)
		{
            ret = DBA_Delete2(RiskESElt, DBA_ROLE_LOAD_STRAT_LNK,
                              Get_Arg, getArgPtr, DBA_SET_CONN | DBA_NO_CLOSE,
                              connectNo);
		}

		if (ret == RET_SUCCEED)
		{
			ret = DBA_Delete2(RiskESEltCompo, DBA_ROLE_LOAD_STRAT_LNK,
							  Get_Arg, getArgPtr, DBA_SET_CONN | DBA_NO_CLOSE,
							  connectNo);
		}

		/* PMSTA-21255 - Cashwini - 150921 */
		if (ret == RET_SUCCEED)
		{
			ret = DBA_Delete2(LombardCheck, DBA_ROLE_LOAD_STRAT_LNK,
				Get_Arg, getArgPtr, DBA_SET_CONN | DBA_NO_CLOSE,
				connectNo);
		}

		if (GET_FLAG(sessionMgt, SessionMgt_BuySellFlg) == TRUE)
		{
			if (ret == RET_SUCCEED)
			{
				/* delete Extended Operations */
				ret = DBA_Delete2(EOp, DBA_ROLE_LOAD_STRAT_LNK,
						   Get_Arg, getArgPtr, DBA_SET_CONN|DBA_NO_CLOSE,
						   connectNo);
			}
		}

		if (GET_FLAG(sessionMgt, SessionMgt_ExternalPosFlg) == TRUE)
		{
			if (ret == RET_SUCCEED)
			{
				/* delete Extended Operations */
				ret = DBA_Delete2(ExtOrder, UNUSED,
						   Get_Arg, getArgPtr, DBA_SET_CONN|DBA_NO_CLOSE,
						   connectNo);
			}
		}

		if (ret == RET_SUCCEED)
		{
			/* delete Case Management records */
			ret = DBA_TabulaRasa(GET_ID(getArgPtr, Get_Arg_Id),
								 CaseManagementNat_Last,
								 connectNo);
		}

		if (ret == RET_SUCCEED &&
			FALSE == sessMgtKeepCommFlg)
		{
			/* delete Comments */
			ret = DBA_Delete2(ApplComment, UNUSED,
					   Get_Arg, getArgPtr, DBA_SET_CONN|DBA_NO_CLOSE,
					   connectNo);
		}
	}

	return (ret);
}

/************************************************************************
**
**  Function    :   DBA_LoadSessionExternalPos()
**
**  Description :   Load all external pos linked to a session into hierarchy, if provided
**                  The store proc may use #dom_port and #dom_instr or not.
**
**  Arguments   :   domainPtr    Domain of the financial function
**                  hierHead     pointer on hierarchy structure
**
**  Return      :   RET_CODE
**
**  Creation    :   PMSTA11101-CHU-110201
**
**  Modif       :   PMSTA-17695-CHU-140314 : Purify
*************************************************************************/
RET_CODE DBA_LoadSessionExternalPos(DBA_DYNFLD_STP		domainPtr,
									PTR					argHierHeadPtr,
									int					*connectNo,
									FLAG_T				useDomPortFlg, /* TRUE = MultiSelect / FALSE = Select */
									DBA_DYNFLD_STP		**externPosTab, /* NULL if useDomPortFlg == TRUE */
									int					*externPosNbr) /* NULL if useDomPortFlg == TRUE */
{
	RET_CODE        ret=RET_SUCCEED;

	if (TRUE == useDomPortFlg &&
		NULL != argHierHeadPtr)
	{
		DBA_DYNFLD_STP		*tmpExternPosTab=NULLDYNSTPTR;
		int					tmpExternPosNbr=0;
		DBA_HIER_HEAD_STP	hierHead = (DBA_HIER_HEAD_STP)argHierHeadPtr;

		DBA_DYNFLD_STP getArgPtr = NULL;

        if ((getArgPtr = ALLOC_DYNST(Get_Arg)) == NULL)
		{
			ret = RET_MEM_ERR_ALLOC;
		}
		else
		{
			if (IS_NULLFLD(domainPtr, A_Domain_FctResultId) == FALSE)
			{
				SET_ID(getArgPtr, Get_Arg_Id, GET_ID(domainPtr, A_Domain_FctResultId));
				if ((ret = DBA_Select2(ExtOrder, UNUSED,
								  Get_Arg, getArgPtr,
								  ExtOp, &tmpExternPosTab,
								  DBA_SET_CONN|DBA_NO_CLOSE,
								  UNUSED, &tmpExternPosNbr,
								  connectNo)) == RET_SUCCEED &&
								  tmpExternPosNbr > 0)
				{
					DBA_AddHierRecordList(hierHead, tmpExternPosTab, tmpExternPosNbr, ExtOp, TRUE);
					FREE(tmpExternPosTab); /* PMSTA-17695 - CHU - 140314 : Purify */
				}
			}
			FREE_DYNST(getArgPtr, Get_Arg); /* PMSTA14453 - DDV - 120712 - Purify */
		}
	}
	else
	{
		DBA_DYNFLD_STP getArgPtr = NULL;

        if ((getArgPtr = ALLOC_DYNST(Get_Arg)) == NULL)
		{
			ret = RET_MEM_ERR_ALLOC;
		}
		else
		{
			if (IS_NULLFLD(domainPtr, A_Domain_FctResultId) == FALSE)
			{
				SET_ID(getArgPtr, Get_Arg_Id, GET_ID(domainPtr, A_Domain_FctResultId));
				ret = DBA_Select2(ExtOrder, UNUSED,
								  Get_Arg, getArgPtr,
								  ExtOp, externPosTab,
								  DBA_SET_CONN|DBA_NO_CLOSE,
								  UNUSED, externPosNbr,
								  connectNo);
			}
			FREE_DYNST(getArgPtr, Get_Arg); /* PMSTA14453 - DDV - 120712 - Purify */
		}
	}

    return(ret);
}

/************************************************************************
**
**  Function    :   DBA_BuildCopyArgTab()
**
**  Description :   Build a array of A_CopyArg based on SessionMgt_CopyEntityList
**
**  Arguments   :
**
**  Return      :   RET_CODE
**
**  Creation    :   PMSTA13167 - DDV - 111222
**
**  Modif       :
*************************************************************************/
RET_CODE DBA_BuildCopyArgTab(DBA_DYNFLD_STP     srcRec,
                             OBJECT_ENUM        srcObjectEn,
                             char              *copyEntityListParam,
                             DBA_DYNFLD_STP   **copyArgTab,
                             int               *copyArgNbr)
{
    char *copyEntityList;
    char *entityAttributeStr = NULL;
    char *entityStr = NULL;
    char *attributeStr = NULL;
    int  nbr=0;
    DICT_ENTITY_STP   srcEntitySt = (DICT_ENTITY_STP) DBA_GetDictEntitySt(srcObjectEn);
    DICT_ENTITY_STP   entitySt=NULL;
    DICT_ATTRIB_STP   attributeSt=NULL;
    OBJECT_ENUM       entityObjectEnum=NullEntity;
    RET_CODE          ret=RET_SUCCEED;

    *copyArgTab = NULL;
    *copyArgNbr = 0;

    if ((copyEntityList = (char *) CALLOC(strlen(copyEntityListParam)+1, sizeof(char))) == NULL)
    {
	    MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    strncpy(copyEntityList, copyEntityListParam, strlen(copyEntityListParam));;
    if(copyEntityList == NULL ||
       copyEntityList[0] == END_OF_STRING)
        return(RET_SUCCEED);

    entityAttributeStr=copyEntityList;
    nbr=1;
    while ((entityAttributeStr = strchr(entityAttributeStr,';')) != NULL)
    {
        entityAttributeStr++;
        nbr++;
    }

    if (nbr > 0)
    {
        /* allocate Copy_arg array */
	    if ((*copyArgTab = (DBA_DYNFLD_STP *) CALLOC(nbr, sizeof(DBA_DYNFLD_STP))) == NULL)
	    {
	        FREE(copyEntityList);
		    MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }

        nbr=0;
        entityAttributeStr=copyEntityList;
        while (copyEntityList != NULL)
        {
            entityStr = NULL;
            attributeStr = NULL;

            entityAttributeStr=copyEntityList;
            if ((copyEntityList = strchr(entityAttributeStr,';')) != NULL)
            {
                copyEntityList[0]=END_OF_STRING;
                copyEntityList++;
            }

            if ((attributeStr=strchr(entityAttributeStr, '.')) != NULL)
            {
                attributeStr[0]=END_OF_STRING;
                attributeStr++;
                entityStr=entityAttributeStr;
            }
            else
            {
                if (entityAttributeStr[0] != END_OF_STRING)
                    attributeStr = entityAttributeStr;
            }

            if (attributeStr != NULL)
            {
                /* alloc A_CopyArg and set values */
	            if (((*copyArgTab)[nbr] = ALLOC_DYNST(A_CopyArg)) == NULLDYNST)
	            {
        	        ret = RET_MEM_ERR_ALLOC;
	            }
	            else
	            {
                    /* get entity and attribute structures and fill A_CopyArg */
                    if (entityStr != NULL)
                    {
                        /* source entity must have only one PK attribute (and in this case PK prog_n is 0) */
                        if (srcEntitySt->primKeyNbr == 1)
                        {
                            if ((entitySt = DBA_GetEntityBySqlName(entityStr)) != NULL)
                            {
                                DBA_GetObjectEnum(entitySt->entDictId, &entityObjectEnum);
                                if ((attributeSt = DBA_GetAttributeBySqlName(entityObjectEnum, attributeStr)) != NULL)
                                {
                                    /* check that it is a FK on main copied entity */
                                    DBA_GetObjectEnum(attributeSt->refEntDictId, &entityObjectEnum);
                                    if (entityObjectEnum == srcObjectEn)
                                    {
                                        /* alloc A_CopyArg and set values */
	                                    if (((*copyArgTab)[nbr] = ALLOC_DYNST(A_CopyArg)) != NULLDYNST)
	                                    {
                                            SET_ID((*copyArgTab)[nbr], A_CopyArg_FromId, GET_ID(srcRec, 0));
                                            SET_DICT((*copyArgTab)[nbr], A_CopyArg_EntityDictId, attributeSt->entDictId);
                                            SET_DICT((*copyArgTab)[nbr], A_CopyArg_AttribDictId, attributeSt->attrDictId);
                                            SET_ENUM((*copyArgTab)[nbr], A_CopyArg_CopyMethodEn, CopyMethod_LoadDynAndInsert);
                                            nbr++;
                                        }
                                        else
                                            ret=RET_MEM_ERR_ALLOC;
                                    }
                                    else
                                        ret=RET_DBA_ERR_INVDATA;
                                }
                                else
                                    ret=RET_DBA_ERR_INVDATA;
                            }
                            else
                                ret=RET_DBA_ERR_INVDATA;
                        }
                        else
                            ret=RET_DBA_ERR_INVDATA;
                    }
                    else
                    {
                        if ((attributeSt = DBA_GetAttributeBySqlName(srcObjectEn, attributeStr)) != NULL &&
                             IS_NULLFLD(srcRec, attributeSt->progN) == FALSE)
                        {
                            /* alloc A_CopyArg and set values */
                            if (((*copyArgTab)[nbr] = ALLOC_DYNST(A_CopyArg)) != NULLDYNST)
                            {
                                SET_ID((*copyArgTab)[nbr], A_CopyArg_FromId, GET_ID(srcRec, attributeSt->progN));
                                SET_DICT((*copyArgTab)[nbr], A_CopyArg_AttribDictId, attributeSt->attrDictId);
                                SET_ENUM((*copyArgTab)[nbr], A_CopyArg_CopyMethodEn, CopyMethod_LoadDynAndInsert);
                                nbr++;
                            }
                            else
                                ret = RET_MEM_ERR_ALLOC;
                        }
                        else
                            ret=RET_DBA_ERR_INVDATA;
                    }
                }
            }

            if (ret != RET_SUCCEED)
            {
                FREE(copyEntityList);
                DBA_FreeDynStTab(*copyArgTab, nbr, A_CopyArg);
                MSG_RETURN(ret);
            }
        }
        *copyArgNbr=nbr;
    }

    FREE(copyEntityList);

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   DBA_LoadDataToCopy()
**
**  Description :   Load all data to copy as define in A_CopyArg array
**
**  Arguments   :
**
**  Return      :   RET_CODE
**
**  Creation    :   PMSTA13167 - DDV - 111222
**
**  Modif       :
*************************************************************************/
RET_CODE DBA_LoadDataToCopy(DBA_DYNFLD_STP    srcRec,
                            OBJECT_ENUM       srcObjectEn,
                            DBA_DYNFLD_STP   *copyArgTab,
                            int               copyArgNbr,
                            DBA_DYNFLD_STP ***copyDataTab,
                            int             **copyDataNbr,
                            int              *connectNo)
{
    int     i=0, j=0;
    char    *scriptDef=NULL;
    DICT_ATTRIB_STP   attributeSt=NULL;
    OBJECT_ENUM       entityObjectEnum=NullEntity;
    DICT_ATTRIB_STP   *pkAttrTab=NULL;
    int               pkAttrNbr=0;
    DICT_T            outputDictId=0;
    RET_CODE          ret=RET_SUCCEED;

    if (copyArgNbr == 0)
        return(RET_SUCCEED);

    if (copyArgTab == NULL ||
        copyDataTab == NULL ||
        copyDataNbr == NULL)
    {
        MSG_RETURN(RET_SRV_GEN_ERR_INVARG);
    }

    /* allocate copyDataTab and copyDataNbr */
    if ((scriptDef = (char *) CALLOC(256, sizeof(char))) == NULL)
    {
	    MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    if ((*copyDataTab = (DBA_DYNFLD_STP **) CALLOC(copyArgNbr, sizeof(DBA_DYNFLD_STP *))) == NULL)
    {
        FREE(scriptDef);
	    MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    if ((*copyDataNbr = (int *) CALLOC(copyArgNbr, sizeof(int))) == NULL)
    {
        FREE(scriptDef);
        FREE(*copyDataTab);
	    MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    for (i=0; i < copyArgNbr; i++)
    {
        scriptDef[0]=END_OF_STRING;

        switch(GET_ENUM(copyArgTab[i], A_CopyArg_CopyMethodEn))
        {
            case CopyMethod_LoadDynAndInsert:
                /* Build query based on A_CopyArg */
                if (IS_NULLFLD(copyArgTab[i], A_CopyArg_EntityDictId) == TRUE)
                {
                    if ((attributeSt = DBA_GetAttributeById(GET_DICT(copyArgTab[i], A_CopyArg_AttribDictId))) != NULL)
                    {
                        outputDictId = attributeSt->refEntDictId;
                        DBA_GetObjectEnum(outputDictId, &entityObjectEnum);
                        if (entityObjectEnum != NullEntity)
                        {
                            DBA_GetPrimaryAttrib(entityObjectEnum, &pkAttrNbr, &pkAttrTab);

                            if (pkAttrNbr == 1)
                            {
                                sprintf(scriptDef, "&%s = %" szFormatId, pkAttrTab[0]->sqlName, GET_ID(copyArgTab[i], A_CopyArg_FromId));
                            }
                            else
                                ret=RET_DBA_ERR_INVDATA;
                        }
                        else
                            ret=RET_DBA_ERR_INVDATA;
                    }
                    else
                        ret=RET_DBA_ERR_INVDATA;
                }
                else /* A_CopyArg_EntityDictId is not NULL */
                {
                    if ((attributeSt = DBA_GetAttributeById(GET_DICT(copyArgTab[i], A_CopyArg_AttribDictId))) != NULL)
                    {
                        outputDictId = attributeSt->entDictId;
                        DBA_GetObjectEnum(outputDictId, &entityObjectEnum);
                        if (entityObjectEnum != NullEntity)
                        {
                            sprintf(scriptDef, "&%s = %" szFormatId, attributeSt->sqlName, GET_ID(copyArgTab[i], A_CopyArg_FromId));
                        }
                        else
                            ret=RET_DBA_ERR_INVDATA;
                    }
                    else
                        ret=RET_DBA_ERR_INVDATA;
                }

                if (ret == RET_SUCCEED)
                {

                    /* Select Data */
                    ret = SCPT_EvalFilterScript(scriptDef,
                                                (SCPT_ARG_STP) NULL,
                                                srcObjectEn,
                                                srcRec,
                                                outputDictId,
                                                FALSE,
                                                NULL,
                                                &((*copyDataTab)[i]),
                                                &((*copyDataNbr)[i]),
	                                            (*connectNo),
                                                0,
                                                NULL,
                                                NULL,
                                                NULL,
                                                CSTLIST_NONE,
                                                TRUE,
                                                0);
                }
                else
                    ret=RET_DBA_ERR_INVDATA;

                break;
            case CopyMethod_StdSelectAndInsert:
                /* select Data */

                break;
            case CopyMethod_CallCopyProc:
                /* Nothing to load for this method*/
                break;
        }

        if (ret != RET_SUCCEED)
        {
            for (j=0; j<=i; j++)
            {
                    if ((attributeSt = DBA_GetAttributeById(GET_DICT(copyArgTab[j], A_CopyArg_AttribDictId))) != NULL)
                    {
                        outputDictId = attributeSt->entDictId;
                        DBA_GetObjectEnum(outputDictId, &entityObjectEnum);

                        DBA_FreeDynStTab((*copyDataTab)[j],(*copyDataNbr)[j], GET_EDITGUIST(entityObjectEnum));
                    }
            }
            FREE(scriptDef);
            FREE(*copyDataTab);
            FREE(*copyDataNbr);
	        MSG_RETURN(ret);
        }
    }
    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   DBA_UpdateDataToCopy()
**
**  Description :   update all data to copy as define in A_CopyArg array
**
**  Arguments   :
**
**  Return      :   RET_CODE
**
**  Creation    :   PMSTA13167 - DDV - 111222
**
**  Modif       :
*************************************************************************/
RET_CODE DBA_UpdateDataToCopy(DBA_DYNFLD_STP   destRec,
                              OBJECT_ENUM      destObjectEn,
                              DBA_DYNFLD_STP  *copyArgTab,
                              int              copyArgNbr,
                              DBA_DYNFLD_STP **copyDataTab,
                              int             *copyDataNbr,
                              int             *connectNo)
{
    int     i=0, j=0, k=0;
    DICT_ATTRIB_STP   attributeSt=NULL;
    OBJECT_ENUM       entityObjectEnum=NullEntity;
    DICT_ATTRIB_STP   *pkAttrTab=NULL;
    int               pkAttrNbr=0;
    DICT_ATTRIB_STP   *bkAttrTab=NULL;
    int               bkAttrNbr=0;
    DICT_T            outputDictId;
    FLAG_T            *scptFlagTab=NULL;
    FLAG_T            applyDVonBK=FALSE;
    RET_CODE          ret=RET_SUCCEED;

    if (copyArgNbr == 0)
        return(RET_SUCCEED);

    if (copyArgTab == NULL ||
        copyDataTab == NULL ||
        copyDataNbr == NULL ||
        copyDataTab == NULL ||
        copyDataNbr == NULL)
    {
        MSG_RETURN(RET_SRV_GEN_ERR_INVARG);
    }

    for (i=0; i < copyArgNbr; i++)
    {
        if (copyDataNbr[i]==0)
            continue;

        applyDVonBK =FALSE;

        switch(GET_ENUM(copyArgTab[i], A_CopyArg_CopyMethodEn))
        {
            case CopyMethod_LoadDynAndInsert:
            case CopyMethod_StdSelectAndInsert:

                if (IS_NULLFLD(copyArgTab[i], A_CopyArg_EntityDictId) == TRUE)
                {
                    if ((attributeSt = DBA_GetAttributeById(GET_DICT(copyArgTab[i], A_CopyArg_AttribDictId))) != NULL)
                    {
                        outputDictId = attributeSt->refEntDictId;
                        DBA_GetObjectEnum(outputDictId, &entityObjectEnum);
                        if (entityObjectEnum != NullEntity)
                        {
                            DBA_GetPrimaryAttrib(entityObjectEnum, &pkAttrNbr, &pkAttrTab);

                            if (pkAttrNbr == 1)
                            {
                                /* if attribute is not part of BK, DV must be computed */
                                if (pkAttrTab[0]->busKeyFlg == FALSE)
                                    applyDVonBK = TRUE;

                                for (j=0; j<copyDataNbr[i]; j++)
                                {
                                    SET_NULL_ID(copyDataTab[i][j] , pkAttrTab[0]->progN);
                                }
                            }
                            else
                                ret=RET_DBA_ERR_INVDATA;
                        }
                        else
                            ret=RET_DBA_ERR_INVDATA;
                    }
                    else
                        ret=RET_DBA_ERR_INVDATA;
                }
                else /* A_CopyArg_EntityDictId is not NULL */
                {
                    if ((attributeSt = DBA_GetAttributeById(GET_DICT(copyArgTab[i], A_CopyArg_AttribDictId))) != NULL)
                    {
                        outputDictId = attributeSt->entDictId;
                        DBA_GetObjectEnum(outputDictId, &entityObjectEnum);
                        if (entityObjectEnum != NullEntity)
                        {
                            DBA_GetPrimaryAttrib(destObjectEn, &pkAttrNbr, &pkAttrTab);

                            if (pkAttrNbr == 1)
                            {
                                /* set new id in copied record */
                                for (j=0; j<copyDataNbr[i]; j++)
                                {
                                    SET_ID(copyDataTab[i][j] , attributeSt->progN, GET_ID(destRec, pkAttrTab[0]->progN));
                                }

                                /* if attribute is not part of BK, DV must be computed */
                                if (attributeSt->busKeyFlg == FALSE)
                                    applyDVonBK = TRUE;
                            }
                        }
                        else
                            ret=RET_DBA_ERR_INVDATA;
                    }
                    else
                        ret=RET_DBA_ERR_INVDATA;
                }
                break;

            case CopyMethod_CallCopyProc:
                /* Nothing to update for this method*/
                break;
        }

        if (ret == RET_SUCCEED && applyDVonBK == TRUE)
        {
            bkAttrNbr = 0;

            DBA_GetBusinessAttrib(entityObjectEnum, &bkAttrNbr, &bkAttrTab);

            if (bkAttrNbr > 0)
            {
                if ((scptFlagTab = (FLAG_T *) CALLOC(GET_FLD_NBR(GET_EDITGUIST(entityObjectEnum)),sizeof(FLAG_T))) == NULL)
                {
                    ret = RET_MEM_ERR_ALLOC;
                }
                else
                {

                    for (k=0; k<GET_FLD_NBR(GET_EDITGUIST(entityObjectEnum)) ;k++)
                        scptFlagTab[k]=TRUE;

                    for (k=0; k<bkAttrNbr ;k++)
                        scptFlagTab[bkAttrTab[k]->progN]=FALSE;

                    /* Set NULL BK and Compute DV */
                    for (j=0; j<copyDataNbr[i]; j++)
                    {
                        for (k=0; k<bkAttrNbr; k++)
                            SET_NULL(copyDataTab[i][j], bkAttrTab[k]->progN, bkAttrTab[k]->dataTpProgN);

                        if (SCPT_ComputeScreenDV(entityObjectEnum,
                                                 DictFct_0,
                                                 scptFlagTab,
                                                 NULL,              /* HFI-PMSTA-25327-171023  Dedicated flag tab for filter    */
                                                 copyDataTab[i][j],
                                                 NULL,
                                                 NULLDYNST,
                                                 NULLDYNST,   /* PMSTA13283 - DDV - 120117 */
                                                 TRUE,
                                                 TRUE,
                                                 EvalType_DefVal,
                                                 -1,
                                                 connectNo,
                                                 NULL,
                                                 NULL,
                                                 0,
                                                 DictScreen,
                                                 NULL,
                                                 NULL,
                                                 NULL,
                                                 NULL,
                                                 NULL,
                                                 NullEntity,
                                                 FALSE,
                                                 FALSE,
                                                 0) != 0)
                        {
                            ret=RET_DBA_ERR_INVDATA;
                        }
                    }
                    FREE(scptFlagTab);
                }
            }
        }

        if (ret != RET_SUCCEED)
        {
            MSG_RETURN(ret);
        }
    }

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   DBA_InsertDataToCopy()
**
**  Description :   insert all data to copy as define in A_CopyArg array
**
**  Arguments   :
**
**  Return      :   RET_CODE
**
**  Creation    :   PMSTA13167 - DDV - 111222
**
**  Modif       :
*************************************************************************/
RET_CODE DBA_InsertDataToCopy(DBA_DYNFLD_STP       destRec,
                              OBJECT_ENUM          destObjectEn,
                              DBA_DYNFLD_STP       *copyArgTab,
                              int                  copyArgNbr,
                              DBA_DYNFLD_STP       **copyDataTab,
                              int                  *copyDataNbr,
                              DbiConnectionHelper &dbiConnHelper,
                              FLAG_T               *destRecModifFlg)
{
    int                  i=0;
    DICT_ATTRIB_STP      attributeSt=NULL;
    OBJECT_ENUM          entityObjectEnum=NullEntity;
    DICT_ATTRIB_STP      *pkAttrTab=NULL;
    int                  pkAttrNbr=0;
    DICT_T               outputDictId;
	DBA_ERRMSG_HEADER_ST msgStructHead;
	RET_CODE             ret=RET_SUCCEED;

    if (copyArgNbr == 0)
        return(RET_SUCCEED);

    if (copyArgTab == NULL ||
        copyDataTab == NULL ||
        copyDataNbr == NULL ||
        copyDataTab == NULL ||
        copyDataNbr == NULL)
    {
        MSG_RETURN(RET_SRV_GEN_ERR_INVARG);
    }

    for (i=0; i < copyArgNbr; i++)
    {
        if (copyDataNbr[i]==0)
            continue;

        switch(GET_ENUM(copyArgTab[i], A_CopyArg_CopyMethodEn))
        {
            case CopyMethod_LoadDynAndInsert:
            case CopyMethod_StdSelectAndInsert:

                if ((attributeSt = DBA_GetAttributeById(GET_DICT(copyArgTab[i], A_CopyArg_AttribDictId))) != NULL)
                {
                    if (IS_NULLFLD(copyArgTab[i], A_CopyArg_EntityDictId) == TRUE)
                    {
                        outputDictId = attributeSt->refEntDictId;
                    }
                    else
                    {
                        outputDictId = attributeSt->entDictId;
                    }
                    DBA_GetObjectEnum(outputDictId, &entityObjectEnum);

                    if (entityObjectEnum != NullEntity)
                    {

                        if (copyDataNbr[i] == 1)
                        {
                            /* simple insert */
                            ret = dbiConnHelper.dbaInsert(entityObjectEnum,
                                                          UNUSED,
                                                          copyDataTab[i][0]);

                            /* If needed, update srcRec FK value */
                            if (ret == RET_SUCCEED && IS_NULLFLD(copyArgTab[i], A_CopyArg_EntityDictId) == TRUE)
                            {
                                if ((attributeSt = DBA_GetAttributeById(GET_DICT(copyArgTab[i], A_CopyArg_AttribDictId))) != NULL)
                                {
                                    outputDictId = attributeSt->refEntDictId;
                                    DBA_GetObjectEnum(outputDictId, &entityObjectEnum);
                                    if (entityObjectEnum != NullEntity)
                                    {
                                        DBA_GetPrimaryAttrib(entityObjectEnum, &pkAttrNbr, &pkAttrTab);

                                        if (pkAttrNbr == 1)
                                        {
                                            (*destRecModifFlg) = TRUE;
                                            SET_ID(destRec, attributeSt->progN, GET_ID(copyDataTab[i][0] , pkAttrTab[0]->progN));
                                        }
                                    }
                                    else
                                        ret=RET_DBA_ERR_INVDATA;
                                }
                                else
                                    ret=RET_DBA_ERR_INVDATA;
                            }
                        }
                        else /* dataNbr > 1, use InsertByBlock */
                        {
                            ret = DBA_InsertByBlock(entityObjectEnum,
                                                    UNUSED,
                                                    GET_EDITGUIST(entityObjectEnum),
	                                                copyDataTab[i],
                                                    copyDataNbr[i],
                                                    DBA_SET_CONN|DBA_IN_TRAN|DBA_NO_CLOSE,
                                                    *dbiConnHelper.getConnection(),
                                                    UNUSED);

                            for (size_t j=0; j<msgStructHead.msgStructTab.size();j++)
                            {
                                MSG_SendMsgInfosFromMA(&(msgStructHead.msgStructTab[j]));
                            }
                            msgStructHead.clear();
                        }
                    }
                    else
                        ret=RET_DBA_ERR_INVDATA;
                }
                else
                    ret=RET_DBA_ERR_INVDATA;

                break;


            case CopyMethod_CallCopyProc:
                break;
        }

        if (ret != RET_SUCCEED)
        {
            MSG_RETURN(ret);
        }
    }

    return(RET_SUCCEED);
}

/************************************************************************
**   END  dbasession.c                                                 **
*************************************************************************/

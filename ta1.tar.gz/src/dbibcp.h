/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef DBI_BCP_H
#define DBI_BCP_H

/************************************************************************
**      BEGIN External definitions attached to : dbibcp.c
*************************************************************************/
#ifdef EXTERN
#undef EXTERN
#endif
#ifdef  DBIBCP_C
#define EXTERN
#else
#define EXTERN extern
#endif

#ifndef DBA_H
#include "dba.h"
#endif

#include "dbi.h"

struct DBI_BLKDEF_STRUCT
{
    /* PMSTA-23981 - 070716 - PMO */
    DBI_BLKDEF_STRUCT() 
        : dbiConnPtr(nullptr)
        , connectNo(0)
        , colNb(0)
        , firstCol(0)
        , count(0)
        , allocSize(0)
        , curRow(0)
        , colName(nullptr)
        , fieldType(nullptr)
        , internal(nullptr)
        , bIdentityInserted(false)
    {
        tableName[0] = 0;
    }

    /* PMSTA-23981 - 070716 - PMO */
    ~DBI_BLKDEF_STRUCT()
    {
		FREE(fieldType);                /* PMSTA-25190 - 061116 - PMO */
        FREE(colName);  

        dbiConnPtr      = nullptr;
        tableName[0]    = 0;
        fieldType       = nullptr;
        internal        = nullptr;
    }

	DBI_BLKDEF_STRUCT(const DBI_BLKDEF_STRUCT &) = delete;
	DBI_BLKDEF_STRUCT & operator=(const DBI_BLKDEF_STRUCT &) = delete;

    DbiConnection          *dbiConnPtr;
    int		                connectNo;                      /* Connection Number */
    LONGSYSNAME_T		    tableName;              		/* Table name in witch bulk copies are done */  /* PMSTA-33077 - DLA - 181003 */
    int		                colNb;                          /* Number of column in 'tableName' table */
    int                     firstCol;                       /* index of first column to be inserted in table */
    int                     count;                          /* Number of row to be bulk copied at one go */
    size_t                  allocSize;
    int                     curRow;                         /* Current row */
    SYSNAME_T*              colName;						/* Columns names */
    DATATYPE_ENUM *         fieldType;						/* data-type array used for conversion */
    void *                  internal;                       /* structure related to the internal implementation*/
    bool                    bIdentityInserted;
};

typedef struct DBI_BLKDEF_STRUCT    DBI_BLKDEF_ST;
typedef struct DBI_BLKDEF_STRUCT *  DBI_BLKDEF_STP;


extern void         DBI_BcpFree(DBI_BLKDEF_STP &);
extern RET_CODE     DBI_BcpInInit(DbiConnection&, char *, SYSNAME_T*, DATATYPE_ENUM  *, int, int, int, void **);
extern RET_CODE     DBI_BcpInsert(DBA_DYNFLD_STP, DBI_BLKDEF_STP, int*, const char*);
extern RET_CODE     DBI_BcpEnd(DBI_BLKDEF_STP, int*, const char*);
extern int			DBI_GetBcpBlockSize(DBI_BLKDEF_STP);

#endif

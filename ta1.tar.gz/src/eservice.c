/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define ESERVICE_C

/************************************************************************
**      Include files
*************************************************************************/
#ifdef NTWIN
#pragma warning (push)
#pragma warning(disable:4101)
#pragma warning(disable:4127)
#pragma warning(disable:4267)
#pragma warning(disable:4702)
#pragma warning(disable:4996)
#endif
#include "jwt/jwt.hpp"
#ifdef NTWIN
#pragma warning (pop)
#endif

#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H
#define MATH_H

#include "unidef.h"     /* Mandatory */
#include "gen.h"
#include "date.h"
#include "dba.h"
#include "syslib.h"     /* PMO - Rename our sys.h to syslib.h and use it */
#include "tls.h"
#include "hier.h"
#include "fin.h"
#include "scptyl.h"
#include "scelib.h"
#include "eservice.h"
#include "json.h"

#ifndef HTTPCLIENT_H
#include "httpclient.h"
#endif

#include "document.h"

#include "usercontext.h"
#include "jwthandler.h"
#include <openssl/ossl_typ.h>
#include <openssl/rsa.h>
#include <mutex>

/************************************************************************
**      External entry points
**
** extern RET_CODE FIN_CallRiskExtService(PTR, DBA_DYNFLD_STP, FLAG_T);
** extern RET_CODE FIN_CallLombardExtService(PTR, DBA_DYNFLD_STP);
** extern RET_CODE ESRV_CallAllExtServiceByNat(ID_T, ESERVPROFCOMPO_NAT_ENUM, DICT_T, DBA_HIER_HEAD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, FLAG_T);
** extern RET_CODE ESRV_CallOneExtService(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, FLAG_T);
** extern void     ESRV_FreeOpti();
**
*************************************************************************/

/************************************************************************
**      Local functions
**
**
**
*************************************************************************/
STATIC RET_CODE ESRV_LoadExtServiceByNature(ID_T, ESERVPROFCOMPO_NAT_ENUM, DICT_T, DBA_DYNFLD_STP **, int *);
STATIC RET_CODE ESRV_LoadExtServiceCompo(ID_T, DBA_DYNFLD_STP **, int *);
STATIC RET_CODE ESRV_CreateESData(EXT_SERVICE_DATA_STP *, DBA_DYNFLD_STP);
STATIC int FIN_CmpESCompoDirRank(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *);
STATIC RET_CODE ESRV_FreeEServiceData(EXT_SERVICE_DATA_STP *);
STATIC RET_CODE ESRV_PrepareData(DBA_HIER_HEAD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, EXT_SERVICE_DATA_STP, EXT_SERVICE_DATA_STP *);
STATIC RET_CODE ESRV_SendExternalRequest(EXT_SERVICE_DATA_STP);
STATIC RET_CODE HttpESClient(EXT_SERVICE_DATA_STP);
STATIC RET_CODE ESRV_RetrieveData(DBA_HIER_HEAD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, EXT_SERVICE_DATA_STP);
STATIC RET_CODE ESRV_ConvertSourceToTarget(EXT_SERVICE_DATA_STP, DBA_HIER_HEAD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, EXT_SERVICE_ELT_STP); /* PMSTA-25920 - CHU - 170207 */
STATIC RET_CODE ESRV_LoadEntityTabWithCompoFilterScpt(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP **, int *);
STATIC RET_CODE ESRV_LoadCompoFilterScpt(DBA_DYNFLD_STP, DBA_DYNFLD_STP *);
STATIC RET_CODE ESRV_WriteOpti(EXT_SERVICE_DATA_STP); /* PMSTA-22496 - DDV - 160614 */
STATIC RET_CODE ESRV_ReadOpti(EXT_SERVICE_DATA_STP);  /* PMSTA-22496 - DDV - 160614 */
STATIC RET_CODE ESRV_CopyEsData(EXT_SERVICE_DATA_STP, EXT_SERVICE_DATA_STP); /* PMSTA-22496 - DDV - 160621 */
STATIC RET_CODE ESRV_CopyEsElt(EXT_SERVICE_ELT_STP, EXT_SERVICE_ELT_STP, FLAG_T); /* PMSTA-22496 - DDV - 160621 */
STATIC RET_CODE ESRV_RestructureData(EXT_SERVICE_DATA_STP, EXT_SERVICE_DATA_STP *, int *, int); /*PMSTA-29906 -NRAO -180215*/
STATIC int FIN_FilterExtOpByPtfId(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP); /* PMSTA-37528 - Kramadevi - 11102019 */
extern RET_CODE FIN_AddCaseLinkedObject(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DICT_T, ID_T); /*PMSTA-39985 -NRAO -28-APR-2020*/

/************************************************************************
**      Static definitions & data
*************************************************************************/

/**** INTERNAL STRUCTURES ****/


/************************************************************************
**      Functions
*************************************************************************/

/*******************************************************************************
**      Local declarations of propotypes
*******************************************************************************/

/************************************************************************
**
**  Function    : FIN_CallRiskExtService()
**
**  Description : Make an 'online' call to External Risk Service
**
**  Arguments   : 1. pointer on hierarchy
**                2. pointer on domain
**
**  Return      : RET_SUCCEED or error code
**
**  Creation    : PMSTA-18426 - CHU - 141030
**
**  Modif.      :
**
*************************************************************************/
RET_CODE FIN_CallRiskExtService(PTR               argStratHierHead,
                                DBA_DYNFLD_STP    domainPtr,
                                FLAG_T            postOrderRiskFlg)
{
    RET_CODE                ret = RET_SUCCEED;
    DBA_HIER_HEAD_STP        hierHead = (DBA_HIER_HEAD_STP)argStratHierHead;
    ID_T                    extServiceProfId=0;

    /* PMSTA-65205 - JPR - 20250205 - external service profile to be picked from the application session */
    DBA_DYNFLD_STP applSession = SYS_GetThreadApplSessionStp();
    extServiceProfId = GET_ID(applSession, A_ApplSession_ExtServiceProfId);

    /* if (extServiceProfId >= 0) */ /* PMSTA-34503 - CHU - 190124 : why >= ?*/
    if (extServiceProfId > 0)
    {
        if ((ret = ESRV_CallAllExtServiceByNat(extServiceProfId, ExtServiceProfCompoNat_RiskCheck, 0, hierHead, hierHead, domainPtr, TRUE)) == RET_SUCCEED)
        {
            /* < PMSTA-20526 - CHU - 150618 */
            if (postOrderRiskFlg == TRUE)
            {
                DBA_DYNFLD_STP  *hierRVETab = NULLDYNST;
                int                hierRVENbr = 0, i = 0;

                if ((ret = DBA_ExtractHierEltRec(hierHead,
                    A_RiskValueElt,
                    FALSE,
                    NULLFCT,
                    NULLFCT,
                    &hierRVENbr,
                    &hierRVETab)) == RET_SUCCEED)
                {
                    for (i = 0; i < hierRVENbr; i++)
                    {
                        SET_FLAG_TRUE(hierRVETab[i], A_RiskValueElt_PostOrderFlg);
                    }
                    FREE(hierRVETab);
                }
            }
            /* > PMSTA-20526 - CHU - 150618 */

            if ((ret = DBA_SetHierLnkUsed(hierHead, A_RiskValueElt, A_RiskValueElt_A_RiskValueEltCompo_Ext)) != RET_SUCCEED)
            {
                MSG_SendMesg(RET_DBA_ERR_HIER, 0, FILEINFO);
                return(RET_DBA_ERR_HIER);
            }

            if (DBA_MakeSpecRecLinks(hierHead, A_RiskValueElt, A_RiskValueElt_A_RiskValueEltCompo_Ext) != RET_SUCCEED)
            {
                MSG_SendMesg(RET_DBA_ERR_HIER, 0, FILEINFO);
                return(RET_DBA_ERR_HIER);
            }
        }
    }

    return (ret);
}

/************************************************************************
**
**  Function    : FIN_CallLombardExtService()
**
**  Description : Make an call to External Lombard Service
**
**  Arguments   : 1. pointer on hierarchy
**                2. pointer on domain
**
**  Return      : RET_SUCCEED or error code
**
**  Creation    : PMSTA-21251 - Cashwini - 150928
**
**  Modif.      :
**
*************************************************************************/
RET_CODE FIN_CallLombardExtService(PTR                argStratHierHead,
                                   DBA_DYNFLD_STP     domainPtr)
{
    RET_CODE                ret = RET_SUCCEED;
    DBA_HIER_HEAD_STP        hierHead = (DBA_HIER_HEAD_STP)argStratHierHead;
    ID_T                    extServiceProfId=0;

    /* PMSTA-65205 - JPR - 20250205 - external service profile to be picked from the application session */
    DBA_DYNFLD_STP applSession = SYS_GetThreadApplSessionStp();
    extServiceProfId = GET_ID(applSession, A_ApplSession_ExtServiceProfId);

    if (extServiceProfId >= 0)
    {
        if ((ret = ESRV_CallAllExtServiceByNat(extServiceProfId, ExtServiceProfCompoNat_LombardCheck, 0, hierHead, hierHead, domainPtr, TRUE)) == RET_SUCCEED)
        {
            DBA_DYNFLD_STP  *LombardCheckTab = NULLDYNST;
            int                LombardCheckNbr = 0, i = 0;

            if ((ret = DBA_ExtractHierEltRec(hierHead,
                A_LombardCheck,
                FALSE,
                NULLFCT,
                NULLFCT,
                &LombardCheckNbr,
                &LombardCheckTab)) != RET_SUCCEED)
            {
                return (ret);
            }

            if (LombardCheckNbr > 0)
            {
                for (i = 0; i < LombardCheckNbr; i++)
                {
                    if (IS_NULLFLD(LombardCheckTab[i], A_LombardCheck_FunctionResultId) == TRUE)
                    {
                        SET_ID(LombardCheckTab[i], A_LombardCheck_FunctionResultId, GET_ID(domainPtr, A_Domain_FctResultId));
                    }
                    /* Then should i save in DB OR ?? */
                }
            }
            FREE(LombardCheckTab);
        }
    }

    return(ret);
}

/************************************************************************
**
**  Function    : FIN_CallBuyingPowerExtService()
**
**  Description : Make an call to External BuyingPower Service
**
**  Arguments   : 1. pointer on hierarchy
**                2. pointer on domain
**
**  Return      : RET_SUCCEED or error code
**
**  Creation    : PMSTA-34546 - kkramadevi - 280119
**
**  Modif.      :
**
*************************************************************************/
RET_CODE FIN_CallBuyingPowerExtService(PTR                argStratHierHead,
                                       DBA_DYNFLD_STP     domainPtr)
{
    RET_CODE                ret = RET_SUCCEED;
    DBA_HIER_HEAD_STP       hierHead = (DBA_HIER_HEAD_STP)argStratHierHead;
    ID_T                    extServiceProfId = 0;

    /* PMSTA-65205 - JPR - 20250205 - external service profile to be picked from the application session */
    DBA_DYNFLD_STP applSession = SYS_GetThreadApplSessionStp();
    extServiceProfId = GET_ID(applSession, A_ApplSession_ExtServiceProfId);;

    if (extServiceProfId >= 0)
    {
        ret = ESRV_CallAllExtServiceByNat(extServiceProfId, ExtServiceProfCompoNat_BuyingPower, 0, hierHead, hierHead, domainPtr, TRUE);
    }

    return(ret);
}

/************************************************************************
**
**  Function    : FIN_CallComplianceExtService()
**
**  Description : Make a call to Compliance External Service
**
**  Arguments   : 1. pointer on hierarchy
**                2. pointer on domain
**
**  Return      : RET_SUCCEED or error code
**
**  Creation    : PMSTA-37528 - kramadevi - 11102019
**
*************************************************************************/
RET_CODE FIN_CallComplianceExtService(PTR                argStratHierHead,
                                      DBA_DYNFLD_STP     domainPtr,
                                      OBJECT_ENUM* entityObject) /* PMSTA-64470 - Deepthi - 20250122 */
{
    RET_CODE                ret = RET_SUCCEED;
    DBA_HIER_HEAD_STP       hierHead = (DBA_HIER_HEAD_STP)argStratHierHead;
    ID_T                    extServiceProfId = 0;
    DBA_DYNFLD_STP          *extServiceTab = NULLDYNSTPTR;
    int                     extServiceNbr = 0;
    MemoryPool              mp;

    /* PMSTA-65205 - JPR - 20250205 - external service profile to be picked from the application session */
    DBA_DYNFLD_STP applSession = SYS_GetThreadApplSessionStp();
    extServiceProfId = GET_ID(applSession, A_ApplSession_ExtServiceProfId);

    if (extServiceProfId >= 0)
    {
        ret = ESRV_CallAllExtServiceByNat(extServiceProfId, ExtServiceProfCompoNat_Compliance, 0, hierHead, hierHead, domainPtr, TRUE);
    }
    /* PMSTA-64470 - Deepthi - 20250122 */
    if (ret == RET_SUCCEED && (ESRV_LoadExtServiceByNature(extServiceProfId, ExtServiceProfCompoNat_Compliance, 0, &extServiceTab, &extServiceNbr) == RET_SUCCEED &&
        extServiceNbr > 0))
    {
        DBA_DYNFLD_STP          *esCompoTab = NULLDYNST;
        int                      esCompoNbr = 0;
        FLAG_T                   sameCompoForInOutFlg = FALSE;

        mp.ownerDynStpTab(extServiceTab, extServiceNbr);

        if ((ret = ESRV_LoadExtServiceCompo(GET_ID(extServiceTab[0], A_ExtService_Id), &esCompoTab, &esCompoNbr)) != RET_SUCCEED)
        {
            DBA_FreeDynStTab(esCompoTab, esCompoNbr, A_ExtServiceCompo);
            return(ret);
        }

        mp.ownerDynStpTab(esCompoTab, esCompoNbr);

        /* get the target entity id's object enum of 'In' direction from external service compo*/
        if (esCompoNbr == 1)
        {    /* assume only one record with direction is None =
                1. convert the first into the second and send the second to external service
                2. get the second back from external service and convert it into the first
            */
            if ((ESERVICE_DIRECTION_ENUM)GET_ENUM(esCompoTab[0], A_ExtServiceCompo_DirectionEn) != ExtServiceDirection_None)
            {
                return(RET_DBA_ERR_EXT_SERVICE_FAILURE);
            }
            else
            {
                sameCompoForInOutFlg = TRUE;
            }
        }
        for (auto i = 0; i < esCompoNbr; i++)
        {
            /* External Service -> TAP */
            if ((ESERVICE_DIRECTION_ENUM)GET_ENUM(esCompoTab[i], A_ExtServiceCompo_DirectionEn) == ExtServiceDirection_In ||
                sameCompoForInOutFlg == TRUE)
            {
                DBA_GetObjectEnum(GET_DICT(esCompoTab[i], A_ExtServiceCompo_DestEntityDictId), entityObject); /*Obtaining the target entities Object Enum*/
                break;
            }
        }
    }

    return(ret);
}

/************************************************************************
**
**  Function    : FIN_CallPtfTransfExtService()
**
**  Description : Make an call to External Portfolio Transfer Fees Service
**
**  Arguments   : 1. pointer on hierarchy
**                2. pointer on domain
**
**  Return      : RET_SUCCEED or error code
**
**  Creation    : PMSTA-39717 - KNI - 01062020
**
**  Modif.      :
**
*************************************************************************/
RET_CODE FIN_CallPtfTransfExtService(PTR                argStratHierHead,
	DBA_DYNFLD_STP     domainPtr)
{
	RET_CODE                ret = RET_SUCCEED;
	DBA_HIER_HEAD_STP       hierHead = (DBA_HIER_HEAD_STP)argStratHierHead;
	ID_T                    extServiceProfId = ZERO_ID;

    /* PMSTA-65205 - JPR - 20250205 - external service profile to be picked from the application session */
    DBA_DYNFLD_STP applSession = SYS_GetThreadApplSessionStp();
    extServiceProfId = GET_ID(applSession, A_ApplSession_ExtServiceProfId);

	if (extServiceProfId >= 0)
	{
		ret = ESRV_CallAllExtServiceByNat(extServiceProfId, ExtServiceProfCompoNat_PtfTransfFees, 0, hierHead, hierHead, domainPtr, TRUE);
	}

	return(ret);
}

std::string base64_decode(const std::string& encoded) {
    BIO* bio, * b64;
    char buffer[1024];
    bio = BIO_new_mem_buf(encoded.c_str(), -1);
    b64 = BIO_new(BIO_f_base64());
    bio = BIO_push(b64, bio);
    BIO_set_flags(bio, BIO_FLAGS_BASE64_NO_NL);
    int length = BIO_read(bio, buffer, (unsigned int)encoded.size());
    BIO_free_all(bio); // frees the entire BIO chain, no need to free b64 explicitly
    return std::string(buffer, length);
}

/************************************************************************
**
**  Function    : ESERV_CallOAuthServiceJWKSEndPoint()
**
*************************************************************************/
RET_CODE ESERV_CallOAuthServiceJWKSEndPoint(DBA_DYNFLD_STP aExtServiceStp)
{
    RET_CODE         ret         = RET_SUCCEED;
    bool			 httpExecRet = true;
    int				 httpStatus  = HTTP_STATUS_OK;

    HttpClient		 http;
    HttpMethodGet    methodGet;

    if (IS_NULLFLD(aExtServiceStp, A_ExtService_UrlAddress) == FALSE)
    {
        std::string url(GET_URL(aExtServiceStp, A_ExtService_UrlAddress));
        if (resolveEnvVariableToValueInURL(url) == true)
        {
            methodGet.setUrl(url.c_str());
            methodGet.setContentType(HttpAbstractRequestReply::ContentType::HTTP_JSON);
            methodGet.setTimeOut(GET_INT(aExtServiceStp, A_ExtService_TimeoutT));
            methodGet.setTokenAuthentication("");

            httpExecRet = http.executeMethod(&methodGet);
            httpStatus = methodGet.getHttpStatus();
            if (httpExecRet == true && httpStatus == HTTP_STATUS_OK)
            {
                const std::string& result = methodGet.getResponseResult();
                rapidjson::Document document;
                document.Parse(result.c_str());
                /* for KeyCloak/Oauth 2.0 end points it will be "keys" */
                if (document.HasMember("keys") && document["keys"].IsArray())
                {
                    for (auto& value : document["keys"].GetArray())
                    {
                        std::string kid = value.HasMember("kid") ? value["kid"].GetString() : "";
                        if (!kid.empty())
                        {
                            std::string certificate;
                            if (value.HasMember("x5c"))
                            {
                                /* take only if the certificate is intended for verifying signature
                                 * https://datatracker.ietf.org/doc/html/rfc7517#section-4.2 */
                                if (value.HasMember("use") && strcmp(value["use"].GetString(), "sig") == 0)
                                {
                                    if (value["x5c"].GetArray().Size() > 0) // to ensure the cert chain has elements
                                    {
                                        certificate = value["x5c"].GetArray()[0].GetString(); //first element is certificate
                                        /* TODO - should other elements in the chain be considered, this needs to be confirmed */
                                    }
                                }
                                JSONWebKeyCertificate jwk;
                                jwk.setKeyId(kid);
                                jwk.setAlgo(JWKAlgorithm::RSA256);
                                jwk.setX5CCertificate(certificate);
                                JSONWebKeyCertificateCache::getJSONWebKeyCertificateCache().addToCache(kid, jwk);
                            }
                            /* if JWK doesn't have x5c certificate chain (which is the case of Infinity JWK),
                             * then derive public key from n and e */
                            else
                            {
                                if (value.HasMember("n") && value.HasMember("e"))
                                {
                                    /* the format of n and e will be base64_url encoded,
                                    * so convert to base64 encoded format
                                    */
                                    const char* n_base64 = value["n"].GetString();
                                    std::string base64_encoded_n(n_base64);
                                    std::replace(base64_encoded_n.begin(), base64_encoded_n.end(), '-', '+');
                                    std::replace(base64_encoded_n.begin(), base64_encoded_n.end(), '_', '/');
                                    std::string n_str = base64_decode(base64_encoded_n);

                                    const char* e_base64 = value["e"].GetString();
                                    std::string base64_encoded_e(e_base64);
                                    std::replace(base64_encoded_e.begin(), base64_encoded_e.end(), '-', '+');
                                    std::replace(base64_encoded_e.begin(), base64_encoded_e.end(), '_', '/');
                                    std::string e_str = base64_decode(base64_encoded_e);

                                    // Convert binary to RSA
                                    RSA* rsa = RSA_new();
                                    RSA_set0_key(rsa,
                                        BN_bin2bn((unsigned char*)n_str.c_str(), (unsigned int)n_str.length(), NULL),
                                        BN_bin2bn((unsigned char*)e_str.c_str(), (unsigned int)e_str.length(), NULL),
                                        NULL);

                                    EVP_PKEY* pkey = EVP_PKEY_new();
                                    EVP_PKEY_set1_RSA(pkey, rsa);

                                    // Convert EVP_PKEY to PEM formatted string
                                    BIO* bio2 = BIO_new(BIO_s_mem());
                                    PEM_write_bio_PUBKEY(bio2, pkey);
                                    BUF_MEM* mem = nullptr;
                                    BIO_get_mem_ptr(bio2, &mem);
                                    if (mem != nullptr)
                                    {
                                        //SYS_MilliSleep(60000);
                                        QString pemString(mem->data);
                                        // Load PEM formatted string into QSslKey
                                        QSslKey sslKey(pemString.toUtf8(), QSsl::Rsa, QSsl::Pem, QSsl::PublicKey);
                                        QByteArray pubKeyBA = sslKey.toPem();
                                        std::string publicKey = pubKeyBA.data();

                                        JSONWebKeyCertificate jwk;
                                        jwk.setKeyId(kid);
                                        jwk.setAlgo(JWKAlgorithm::RSA256);
                                        jwk.setPublicKey(publicKey);
                                        JSONWebKeyCertificateCache::getJSONWebKeyCertificateCache().addToCache(kid, jwk);
                                    }

                                    BIO_free(bio2);
                                    EVP_PKEY_free(pkey);
                                    RSA_free(rsa);
                                }
                                else
                                {
                                    ret = RET_DBA_ERR_INVDATA;
                                    MSG_SendMesg(FILEINFO, std::string("JWK doesn't have key, n or e."));
                                }
                            }
                        }
                    }

                }
                else
                {
                    ret = RET_DBA_ERR_INVDATA;
                    MSG_SendMesg(FILEINFO, std::string("key attribute not present in the JWK, unable to get public key"));
                }
            }
            else
            {
                ret = RET_DBA_ERR_EXT_SERVICE_FAILURE;
                MSG_SendMesg(FILEINFO, std::string("Call to OAuth JWKS end point to fetch public keys failed."));
            }
        }
        else
        {
            ret = RET_DBA_ERR_EXT_SERVICE_FAILURE;
            MSG_SendMesg(FILEINFO, std::string("OAuth server url not set in environment variable."));
        }

        
    }
    else
    {
        ret = RET_DBA_ERR_EXT_SERVICE_FAILURE;
        MSG_SendMesg(FILEINFO, std::string("URL not defined in external service"));
    }
    
    return ret;
}


/************************************************************************
**
**  Function    : FIN_CallOAuthServiceJWKSEndPoint()
**
*************************************************************************/
RET_CODE FIN_CallOAuthServiceJWKSEndPoint()
{
    RET_CODE              ret              = RET_SUCCEED;
    ID_T                  extServiceProfId = 0;
    DBA_DYNFLD_STP *      extServiceTab    = NULLDYNSTPTR;
    int                   extServiceNbr    = 0;
    MemoryPool mp;

    DBA_GetUserInfo2(A_ApplUser_ExtServiceProfId, &extServiceProfId, TRUE);

    if (extServiceProfId > 0)
    {
        DBA_DYNFLD_STP       selArgStp = mp.allocDynst(FILEINFO, Sel_Arg);
        SET_ENUM(selArgStp, Sel_Arg_Enum1, ExtServiceNatEn::OAuthJWKSURI);

        DbiConnectionHelper  dbiConnHelper;
        if (dbiConnHelper.isValidAndInit() == false)
        {
            return RET_DBA_ERR_CONNOTFOUND;
        }

        ret = dbiConnHelper.dbaSelect(ExtService, UNUSED, selArgStp, A_ExtService, &extServiceTab, &extServiceNbr);

        for (int idx = 0; idx < extServiceNbr; ++idx)
        {
            ESERV_CallOAuthServiceJWKSEndPoint(extServiceTab[idx]);
        }
    }
    else
    {
        ret = RET_DBA_ERR_EXT_SERVICE_FAILURE;
        MSG_SendMesg(FILEINFO, std::string("Error - external service profile is not defined for user."));
    }

    return ret;
}

/************************************************************************
**
**  Function    : FIN_CallAllExtServiceByNat()
**
**  Description : Call all external services from profile for a specific nature.
**
**  Arguments   : extServiceProfileId     id of the external_service_profile
**                extServiceNature        nature of service(s) to return
**                fctDictId               function dict id
**                srcHierHead             hierchary with data to send to external service
**                destHierHead            hierchary to use to store data return by service
**                domainPtr               domain
**                optiFlg                 optimisation flag
**
**
**  Return      : RET_SUCCEED or error code
**
**  Creation    : PMSTA-22496 - DDV - 160504
**
**  Modif.      :
**
*************************************************************************/
RET_CODE ESRV_CallAllExtServiceByNat(ID_T                     extServiceProfileId,
                                     ESERVPROFCOMPO_NAT_ENUM  extServiceProfCompoNature,
                                     DICT_T                   fctDictId,
                                     DBA_HIER_HEAD_STP        srcHierHead,
                                     DBA_HIER_HEAD_STP        destHierHead,
                                     DBA_DYNFLD_STP           domainPtr,
                                     FLAG_T                   optiFlg)
{

	RET_CODE                ret = RET_SUCCEED;
	DBA_DYNFLD_STP         *extServiceTab = NULLDYNSTPTR;
	int                     extServiceNbr = 0;
    MemoryPool              mp;

    ret = ESRV_LoadExtServiceByNature(extServiceProfileId, extServiceProfCompoNature, fctDictId, &extServiceTab, &extServiceNbr);

    mp.ownerDynStpTab(extServiceTab, extServiceNbr);

    if (ret == RET_SUCCEED && extServiceNbr > 0)
	{
		for (int i = 0; i < extServiceNbr; i++)
		{
			if (GET_ENUM(extServiceTab[i], A_ExtService_NatEn) == ExtServiceNat_Compliance ||
                GET_ENUM(extServiceTab[i], A_ExtService_NatEn) == ExtServiceNat_ComplianceExAntePostOrders)
            {

                switch (GET_ENUM(extServiceTab[i], A_ExtService_BreakCriteriaEn))
                {
                    case ExtServiceBreakCriteriaEn_Session:
                    case ExtServiceBreakCriteriaEn_Client:
                    {
                        ret = ESRV_CallOneExtService(extServiceTab[i], srcHierHead, destHierHead, domainPtr, optiFlg);

                        /*PMSTA-39985 -NRAO -28-APR-2020*/
                        FIN_DelCaseMgtRecordByNature(domainPtr, (ENUM_T)CaseManagementNat_ExtServiceFailOver);

                        if (ret != RET_SUCCEED)
                        {
                            FIN_CreateCaseForExtSErviceFailure(extServiceTab[i], destHierHead, domainPtr);
                        }
                        break;
                    }
                    /*call ESRV_CallOneExtService for each portfolio when the break_criteria_e value is portfolio*/
                    case ExtServiceBreakCriteriaEn_Portfolio:
                    {
                        int                      ptfNbr     = 0, extOpNbr = 0;
                        DBA_DYNFLD_STP	         *ptfTab    = NULLDYNSTPTR, *extOpTab = NULLDYNSTPTR;
                        DBA_HIER_HEAD_STP        hierHead   = (DBA_HIER_HEAD_STP)NULL;

                        /*extract all the portfolios from hierarchy*/
                        ret = DBA_ExtractHierEltRec(srcHierHead,
                                                         A_Ptf,
                                                         FALSE,
                                                         NULLFCT,
                                                         NULLFCT,
                                                         &ptfNbr,
                                                         &ptfTab);

                        mp.ownerPtr(ptfTab);

                        if (ret == RET_SUCCEED && ptfNbr > 0)
                        {
                            DBA_CopyHier(&hierHead, srcHierHead);

                            for (int k = 0; k < ptfNbr; k++)
                            {
                                /*Extract extOp records of each portfolio and add it to new hierarchy and pass it to external service*/
                                ret = DBA_ExtractHierEltRecWithFilterSt((DBA_HIER_HEAD_STP)srcHierHead,
                                                                             ExtOp,
                                                                             TRUE,
                                                                             FIN_FilterExtOpByPtfId,
                                                                             ptfTab[k],
                                                                             NULLFCT,
                                                                             &extOpNbr,
                                                                             &extOpTab);

                                mp.ownerPtr(extOpTab);

                                if(ret == RET_SUCCEED && extOpNbr > 0)
                                {
                                    /*delete all the ExtOp element and add back only those ExtOp's matching with the current portfolio id*/
                                    DBA_DelAndFreeHierElt(hierHead, ExtOp);

                                    if ((ret = DBA_AddHierRecordList(hierHead,
                                                                extOpTab,
                                                                extOpNbr,
                                                                ExtOp, TRUE)) != RET_SUCCEED)
                                    {
                                        return(ret);
                                    }
                                    ret = ESRV_CallOneExtService(extServiceTab[i], hierHead, destHierHead, domainPtr, optiFlg);
                                }
                            }
                        }
                        break;
                    }
                    default:
                        break;
                }
            }
			else if (IS_NULLFLD(domainPtr, A_Domain_RiskRuleId) == FALSE &&
                GET_ID(domainPtr, A_Domain_RiskRuleId) > 0)
			{
                DBA_DYNFLD_STP *sRiskRuleCompoTab = NULLDYNSTPTR, *extStratEltTab = NULLDYNSTPTR; /*PMSTA-22458 - cashwini - 04062016 >*/
                int sRiskRuleCompoNbr = 0, extStratEltNbr = 0;/* <PMSTA-22458 - cashwini - 04062016*/

                DBA_DYNFLD_STP  aRiskArgSt = mp.allocDynst(FILEINFO, A_RiskRuleCompo);
				SET_ID(aRiskArgSt, A_RiskRuleCompo_RiskRuleId, GET_ID(domainPtr, A_Domain_RiskRuleId));

				if ((ret = DBA_Select2(RiskRuleCompo,
					UNUSED,
					A_RiskRuleCompo,
					aRiskArgSt,
					S_RiskRuleCompo,
					&sRiskRuleCompoTab,
					UNUSED,
					UNUSED,
					&sRiskRuleCompoNbr,
					UNUSED,
					NULL)) != RET_SUCCEED)
				{
                    char buffer[1024];

                    sprintf(buffer, "External Service call on %s : An error occurred while selecting RiskRule Composition", GET_CODE(extServiceTab[i], A_ExtService_Cd));
					MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, buffer);
					return(RET_DBA_ERR_NODATA);
				}

                mp.ownerDynStpTab(sRiskRuleCompoTab,sRiskRuleCompoNbr);

                if ((ret = DBA_ExtractHierEltRec(srcHierHead,
                    ExtStratElt, FALSE, NULLFCT,
                    NULLFCT,
                    &extStratEltNbr, &extStratEltTab)) != RET_SUCCEED)
                {
                    return(ret);
                }

                mp.ownerPtr(extStratEltTab);

				for (int j = 0; j < sRiskRuleCompoNbr; j++)
				{
                    for (int k = 0; k < extStratEltNbr; k++)
					{
						SET_ID(extStratEltTab[k], ExtStratElt_RiskRuleCompoId, GET_ID(sRiskRuleCompoTab[j], S_RiskRuleCompo_Id));
					}
                    ESRV_CallOneExtService(extServiceTab[i], srcHierHead, destHierHead, domainPtr, optiFlg);
				}
			}
            else
            {
                ESRV_CallOneExtService(extServiceTab[i], srcHierHead, destHierHead, domainPtr, optiFlg);
            }
		}
	}

    return (ret);
}

/************************************************************************
**
**  Function    : ESRV_SetExtSvcTraceFile()
**
**  Description : Create External Service trace file.
**
**  Arguments   : esDataPtr               external service data
**
**  Return      : RET_SUCCEED or error code
**
**  Creation    : PMSTA-25920 - CHU - 170207
**
**  Modif.      :
**
*************************************************************************/
void ESRV_SetExtSvcTraceFile(EXT_SERVICE_DATA_STP esDataPtr)
{
    if (SYS_GetEnv("AAAEXTSVCTRACE") != NULL)
    {
        std::string   srvName;
        char        usrCode[MAX_USERINFO_LEN + 1];
        YEAR_T          y;
        MONTH_T         m;
        DAY_T           d;
        HOUR_T          h;
        MINUTE_T        min;
        SECOND_T        s;
        MICROSECOND_T   usec;

        const void		*threadNo = DBA_GetCurrThread();

        DBA_GetUserInfo2(A_ApplUser_Cd, (PTR)usrCode, TRUE);

        srvName[0] = END_OF_STRING;
        if (SERVER_MODE())
        {
            GEN_GetApplInfo(ApplServerName, srvName);
        }
        else
        {
            srvName = "NoSrv";
        }

        SYS_CurrentTimeUs(&y, &m, &d, &h, &min, &s, &usec);
        if (y<1900)
        {
            y += 1900;
        }

        std::string buffer;
        {
            SYS_StringFormat(buffer
                , "%s%s%s-%s-%s_%04d-%02d-%02d-%02dh%02dm%02ds.%06d_(" szFormatPointer").csv"
                , GEN_GetPath(MsgDir)
                , FILE_SEPARATOR
                , GET_CODE(esDataPtr->esPtr, A_ExtService_Cd)
                , usrCode
                , srvName.c_str()
                , y
                , m
                , d
                , h
                , min
                , s
                , usec
                , threadNo
                );
        }

        size_t fileNameLen = SYS_StrLen(buffer.c_str());

        if ((esDataPtr->extSvcTraceFileSt.extSvcTraceFilename = (char *)CALLOC(fileNameLen + 1, sizeof(char))) != NULL)
        {
            DBA_DYNFLD_STP   domainPtr = NULL;
            FILE            *fileHandler = NULL;

            strcpy(esDataPtr->extSvcTraceFileSt.extSvcTraceFilename, buffer.c_str());
            esDataPtr->extSvcTraceFileSt.extSvcTraceStatus = RET_SUCCEED;

            fileHandler = fopen(esDataPtr->extSvcTraceFileSt.extSvcTraceFilename, "a+");
            AAA_RPT1(_CRT_WARN, "%s\n", esDataPtr->extSvcTraceFileSt.extSvcTraceFilename); /* REF9586 - LJE - 031029 */

            if (fileHandler == NULL)
            {
                FREE(esDataPtr->extSvcTraceFileSt.extSvcTraceFilename);
                esDataPtr->extSvcTraceFileSt.extSvcTraceStatus = RET_GEN_INFO_NOACTION;
            }
            else
            {
                MSG_LogSrvMesg(UNUSED, UNUSED, "AAAEXTSVCTRACE - writing traces to log filename : %1",
                    String1000Type, esDataPtr->extSvcTraceFileSt.extSvcTraceFilename);

                if ((domainPtr = DBA_GetDomainPtr(NO_VALUE)) != NULL)
                {
                    DBA_NewDispDynStFH(domainPtr,
                        fileHandler,
                        1,
                        "Global",
                        FALSE);

                    fprintf(fileHandler, "$END$\n");
                    fclose(fileHandler);
                }
            }
        }
    }
}

/************************************************************************
**
**  Function    : ESRV_WriteExtSvcTraceFile()
**
**  Description : Create External Service trace file.
**
**  Arguments   : esDataPtr               external service data
**
**  Return      : RET_SUCCEED or error code
**
**  Creation    : PMSTA-25920 - CHU - 170207
**
**  Modif.      :
**
*************************************************************************/
void ESRV_WriteExtSvcTraceFile(EXT_SERVICE_DATA_STP esDataPtr, DBA_DYNFLD_STP *p, int from, int till)
{
    if (esDataPtr->extSvcTraceFileSt.extSvcTraceStatus == RET_SUCCEED)
    {
        int      i = 0;
        FLAG_T   firstEltFlg = TRUE;
        FILE    *fileHandler = NULL;


        fileHandler = fopen(esDataPtr->extSvcTraceFileSt.extSvcTraceFilename, "a+");
        AAA_RPT1(_CRT_WARN, "%s\n", esDataPtr->extSvcTraceFileSt.extSvcTraceFilename); /* REF9586 - LJE - 031029 */

        if (fileHandler == NULL)
        {
            FREE(esDataPtr->extSvcTraceFileSt.extSvcTraceFilename);
            esDataPtr->extSvcTraceFileSt.extSvcTraceStatus = RET_GEN_INFO_NOACTION;
        }
        else
        {
            for (i = from; i < till; i++)
            {
                DBA_NewDispDynStFH(p[i], fileHandler,
                    firstEltFlg ? 1 : 2, NULL, FALSE);
                firstEltFlg = FALSE;
            }

            if (firstEltFlg == FALSE)
            {
                fprintf(fileHandler, "$END$\n");
            }

            fclose(fileHandler);
        }
    }
}

/************************************************************************
**
**  Function    : ESRV_CallOneExtService()
**
**  Description : Call one external service.
**
**  Arguments   : extServiceStp           dynamic structure of the service to call
**                srcHierHead             hierchary with data to send to external service
**                destHierHead            hierchary to use to store data returned by service
**                domainPtr               domain
**                optiFlg                 optimisation flag
**
**
**  Return      : RET_SUCCEED or error code
**
**  Creation    : PMSTA-22496 - DDV - 160504
**
**  Modif.      :
**
*************************************************************************/
RET_CODE ESRV_CallOneExtService(DBA_DYNFLD_STP         extServiceStp,
                                DBA_HIER_HEAD_STP      srcHierHead,
                                DBA_HIER_HEAD_STP      destHierHead,
                                DBA_DYNFLD_STP         domainPtr,
                                FLAG_T                 optiFlg)
{
    RET_CODE                ret = RET_SUCCEED;
    EXT_SERVICE_DATA_STP    esDataPtr = NULL;
	EXT_SERVICE_DATA_STP    filteredESDataPtr = NULL;
    FLAG_T                  dataFoundFlg = FALSE;
    int                     i;

    if (extServiceStp == NULL)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "ESRV_CallOneExtService", "extServiceStp");
        return(RET_GEN_ERR_INVARG);
    }

    if (IS_NULLFLD(extServiceStp, A_ExtService_UrlAddress) == TRUE)
    {
        MSG_SendMesg(RET_GEN_ERR_PERSONAL, 6, FILEINFO, "URL is not define in external service", GET_CODE(extServiceStp, A_ExtService_Cd));
        ESRV_FreeEServiceData(&esDataPtr);
        return (RET_DBA_ERR_EXT_SERVICE_FAILURE);
    }

    //WEALTH-16486 - ankita - changes to convert the relative URL into absolute
    std::string url(GET_URL(extServiceStp, A_ExtService_UrlAddress));

    if (!resolveEnvVariableToValueInURL(url))
    {
        MSG_SendMesg(RET_GEN_ERR_PERSONAL, 6, FILEINFO, "Invalid URL define in external service", GET_CODE(extServiceStp, A_ExtService_Cd));
        ESRV_FreeEServiceData(&esDataPtr);
        return (RET_DBA_ERR_EXT_SERVICE_FAILURE);
    }

    SET_STRING(extServiceStp, A_ExtService_UrlAddress, url.c_str());

    if ((ret = ESRV_CreateESData(&esDataPtr, extServiceStp)) != RET_SUCCEED)
    {
        MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Creation of esData structure failed");
        ESRV_FreeEServiceData(&esDataPtr);
        return (RET_DBA_ERR_EXT_SERVICE_FAILURE);
    }

	if ((ret = ESRV_PrepareData(srcHierHead, destHierHead, domainPtr, esDataPtr, &filteredESDataPtr)) != RET_SUCCEED)
    {
        ESRV_FreeEServiceData(&esDataPtr);
		ESRV_FreeEServiceData(&filteredESDataPtr);
        if (ret == RET_GEN_INFO_NODATA || ret == RET_GEN_INFO_NOACTION)
        {
            if (ret == RET_GEN_INFO_NOACTION)
            {
                /*PMSTA-34129-NRAO-181214 */
                MSG_SendMesg(RET_GEN_INFO_NOACTION, 1, FILEINFO, "Filtering of the data left no records to be sent to external service");
      	    }
            return (RET_SUCCEED);
        }
        else
        {
            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Preparation of data to send to external service failed");
            return (RET_DBA_ERR_EXT_SERVICE_FAILURE);
        }
    }
	else
	{
		if ((filteredESDataPtr != NULL) &&
			 (esDataPtr != NULL) &&
			 (filteredESDataPtr->requestESEltNbr < esDataPtr->requestESEltNbr))
		{
			ESRV_FreeEServiceData(&esDataPtr);
			esDataPtr = filteredESDataPtr;
		}
		else if (filteredESDataPtr != NULL)
			ESRV_FreeEServiceData(&filteredESDataPtr);

	}

    if (optiFlg == TRUE)
    {
        /* Search in ES cache */
        if (ESRV_ReadOpti(esDataPtr) == RET_SUCCEED)
            dataFoundFlg = TRUE;
    }

    if (dataFoundFlg == FALSE)
    {
        if ((ret = ESRV_SendExternalRequest(esDataPtr)) != RET_SUCCEED)
        {
            /*PMSTA-61837 Jagan 17122024 If Call to external service failed then still it will cache the request*/
            if (optiFlg == TRUE) {
                ESRV_WriteOpti(esDataPtr);
            }
            ESRV_FreeEServiceData(&esDataPtr);
            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Call to external service failed");
            return (RET_DBA_ERR_EXT_SERVICE_FAILURE);
        }
    }

    if ((ret = ESRV_RetrieveData(srcHierHead, destHierHead, domainPtr, esDataPtr)) != RET_SUCCEED)
    {
        ESRV_FreeEServiceData(&esDataPtr);
        MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Preparation of data retrieved by external service failed");
        return (RET_DBA_ERR_EXT_SERVICE_FAILURE);
    }

     if (optiFlg == TRUE && dataFoundFlg == FALSE)
    {
        /* Store in ES cache */
        ESRV_WriteOpti(esDataPtr);
    }

    /* remove intermediate records DDVTODO Remove only temp. record not the whole element */
    for (i = 0; i < esDataPtr->requestESEltNbr; i++)
    {
        if (esDataPtr->requestESEltTab[i].targetDynStEnum > InvalidDynSt &&
            esDataPtr->requestESEltTab[i].targetDynStEnum != esDataPtr->requestESEltTab[i].sourceDynStEnum)
        {
            DBA_DelAndFreeHierElt(srcHierHead, esDataPtr->requestESEltTab[i].targetDynStEnum);
        }
    }

    for (i = 0; i < esDataPtr->responseESEltNbr; i++)
    {
        if (esDataPtr->responseESEltTab[i].targetDynStEnum > InvalidDynSt &&
            esDataPtr->responseESEltTab[i].targetDynStEnum != esDataPtr->responseESEltTab[i].sourceDynStEnum)
        {
            DBA_DelAndFreeHierElt(destHierHead, esDataPtr->responseESEltTab[i].sourceDynStEnum);
        }
    }


    ESRV_FreeEServiceData(&esDataPtr);
    return (ret);
}

/************************************************************************
**
**  Function    : ESRV_LoadExtServiceByNature()
**
**  Description : Load all external services from profile for a specific nature.
**
**  Arguments   : extServiceProfileId       id of the external_service_profile
**                extServiceNature          nature of service(s) to return
**                fctDictId                 function dict id
**                extServiceTabPtr          pointer used to return the array
**                extServiceNbrPtr          pointer used to return  the number of service(s)
**
**
**  Return      : RET_SUCCEED or error code
**
**  Creation    : PMSTA-22496 - DDV - 160504
**
**  Modif.      :
**
*************************************************************************/
STATIC RET_CODE ESRV_LoadExtServiceByNature(ID_T                      extServiceProfileId,
                                            ESERVPROFCOMPO_NAT_ENUM   extServiceProfCompoNature,
                                            DICT_T                    fctDictId,
                                            DBA_DYNFLD_STP          **extServiceTabPtr,
                                            int                      *extServiceNbrPtr)
{
    RET_CODE             ret = RET_SUCCEED;
    DBA_DYNFLD_STP       selArgStp = NULLDYNST;

    if (extServiceTabPtr == NULL)
        return(RET_SRV_GEN_ERR_INVARG);

    *extServiceTabPtr = NULLDYNSTPTR;

    if (extServiceNbrPtr == NULL)
        return(RET_SRV_GEN_ERR_INVARG);

    *extServiceNbrPtr = 0;

    if (extServiceProfileId <= 0)
        return(RET_SUCCEED);

    if ((selArgStp = ALLOC_DYNST(Sel_Arg)) == NULLDYNST)
    {
        return(RET_MEM_ERR_ALLOC);
    }

    SET_ID(selArgStp,   Sel_Arg_Id1, extServiceProfileId);
    SET_ENUM(selArgStp, Sel_Arg_Enum1, extServiceProfCompoNature);

    if (extServiceProfCompoNature == ExtServiceProfCompoNat_FinFct)
        SET_DICT(selArgStp, Sel_Arg_DictId1, fctDictId);

    ret = DBA_Select2(ExtService, UNUSED, Sel_Arg, selArgStp, A_ExtService, extServiceTabPtr, UNUSED, UNUSED, extServiceNbrPtr, UNUSED, NULL);

    FREE_DYNST(selArgStp, Sel_Arg);
    return(ret);
}

/************************************************************************
*
*  Function          : ESRV_LoadExtServiceCompo()
*
*  Description       : Load all External Service Compo for one service
*
*  Arguments         :
*
*  Return            : RET_CODE
*
*  Creation date     : PMSTA-20235 - CHU - 150402
*
*  Last modification :
*
*************************************************************************/
STATIC RET_CODE ESRV_LoadExtServiceCompo(ID_T                 eServiceId,
								         DBA_DYNFLD_STP		**esCompoTab,
								   int					*esCompoNbr)
{
	RET_CODE			ret = RET_SUCCEED;
    DBA_DYNFLD_STP        admArgSt = NULL;
	int					connectNo = DBA_CONN_NOT_FOUND;

    if (esCompoTab == NULL || esCompoNbr == NULL)
	{
        return(RET_SRV_GEN_ERR_INVARG);
    }

    *esCompoTab = NULL;
    *esCompoNbr = 0;

    if ((connectNo = DBA_GetConnection(SqlServer)) == DBA_CONN_NOT_FOUND)
    {
        MSG_SendMesg(RET_DBA_ERR_CONNOTFOUND, 0, FILEINFO);
        MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "ESRV_LoadExtServiceByCode(): Error getting a connection.");
        return(RET_SUCCEED);
    }

    if ((admArgSt = ALLOC_DYNST(Adm_Arg)) == NULL)
    {
        DBA_EndConnection(connectNo);
		return(RET_MEM_ERR_ALLOC);
	}

    SET_ID(admArgSt, Adm_Arg_Id, eServiceId);
    if ((ret = DBA_Select2(ExtServiceCompo, UNUSED, Adm_Arg, admArgSt, A_ExtServiceCompo, esCompoTab, UNUSED, UNUSED, esCompoNbr, UNUSED, NULL)) != RET_SUCCEED)
	{
        FREE_DYNST(admArgSt, Adm_Arg);
        DBA_EndConnection(connectNo);
        return(RET_SRV_LIB_ERR_COMMAND_ABORTED);
    }
    FREE_DYNST(admArgSt, Adm_Arg);
    DBA_EndConnection(connectNo);

    return (ret);
}

/************************************************************************
**
**  Function    : ESRV_CreateESData()
**
**  Description : Create and initialite esData structure.
**
**  Arguments   : esDataPtr               pointer on esData
**                extServiceStp           DynSt with A_ExtService record
**
**
**  Return      : RET_SUCCEED or error code
**
**  Creation    : PMSTA-22496 - DDV - 160512
**
**  Modif.      :
**
*************************************************************************/
STATIC RET_CODE ESRV_CreateESData(EXT_SERVICE_DATA_STP  *esDataPtr,
                                  DBA_DYNFLD_STP         extServiceStp)
{
    RET_CODE                ret = RET_SUCCEED;
    DBA_DYNFLD_STP           *esCompoTab = NULLDYNST;
    int                        esCompoNbr = 0, i = 0;
    FLAG_T                    sameCompoForInOutFlg = FALSE;
    OBJECT_ENUM                entityObject = NullEntity;

    if (esDataPtr == NULL)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "ESRV_CreateESData", "esDataPtr");
        return(RET_GEN_ERR_INVARG);
    }

    if (((*esDataPtr) = (EXT_SERVICE_DATA_STP)CALLOC(1, sizeof(EXT_SERVICE_DATA_ST))) == NULL)
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "EXT_SERVICE_DATA_STP");
		return(RET_MEM_ERR_ALLOC);
	}

    (*esDataPtr)->extSvcTraceFileSt.extSvcTraceStatus = RET_GEN_INFO_NOACTION; /* PMSTA-25920 - CHU - 170207 */

    if ((ret = ESRV_LoadExtServiceCompo(GET_ID(extServiceStp, A_ExtService_Id), &esCompoTab, &esCompoNbr)) != RET_SUCCEED)
    {
        FREE((*esDataPtr));
        return(ret);
    }

    (*esDataPtr)->esPtr = extServiceStp;
    (*esDataPtr)->esFreeFlg = FALSE;

    if (esCompoNbr == 0)
    {
        FREE(*esDataPtr);
        return (RET_DBA_ERR_EXT_SERVICE_FAILURE);
    }
    else
    {
        if (esCompoNbr == 1)
        {    /* assume only one record with direction is None =
                1. convert the first into the second and send the second to external service
                2. get the second back from external service and convert it into the first
            */
            if ((ESERVICE_DIRECTION_ENUM)GET_ENUM(esCompoTab[0], A_ExtServiceCompo_DirectionEn) != ExtServiceDirection_None)
            {
                DBA_FreeDynStTab(esCompoTab, esCompoNbr, A_ExtServiceCompo);
                return(RET_DBA_ERR_EXT_SERVICE_FAILURE);
            }
            else
	        {
                sameCompoForInOutFlg = TRUE;
            }
        }

        /* Initialize Elt Data */
        if (((*esDataPtr)->requestESEltTab = (EXT_SERVICE_ELT_STP)CALLOC(esCompoNbr, sizeof(EXT_SERVICE_ELT_ST))) == NULL)
        {
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "EXT_SERVICE_ELT_STP");
            ESRV_FreeEServiceData(esDataPtr);
            DBA_FreeDynStTab(esCompoTab, esCompoNbr, A_ExtServiceCompo);
            return(RET_MEM_ERR_ALLOC);
        }

        if (((*esDataPtr)->responseESEltTab = (EXT_SERVICE_ELT_STP)CALLOC(esCompoNbr, sizeof(EXT_SERVICE_ELT_ST))) == NULL)
        {
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "EXT_SERVICE_ELT_STP");
            ESRV_FreeEServiceData(esDataPtr);
            DBA_FreeDynStTab(esCompoTab, esCompoNbr, A_ExtServiceCompo);
            return(RET_MEM_ERR_ALLOC);
	    }

        /* Sort in/out esCompoTab's by direction and rank */
        TLS_Sort((char *)esCompoTab, esCompoNbr, sizeof(DBA_DYNFLD_STP),
            (TLS_CMPFCT*)FIN_CmpESCompoDirRank, NULL, SortRtnTp_None);

        ((*esDataPtr)->requestESEltNbr) = 0;
        ((*esDataPtr)->responseESEltNbr) = 0;

        /* Look for entity to send and to retreive */
        for (i = 0; i < esCompoNbr; i++)
        {
            /* TAP -> External Service */
            if ((ESERVICE_DIRECTION_ENUM)GET_ENUM(esCompoTab[i], A_ExtServiceCompo_DirectionEn) == ExtServiceDirection_Out ||
                sameCompoForInOutFlg == TRUE)
	        {
                (*esDataPtr)->requestESEltTab[(*esDataPtr)->requestESEltNbr].esCompoStp = esCompoTab[i];

                DBA_GetObjectEnum(GET_DICT(esCompoTab[i], A_ExtServiceCompo_SrcEntityDictId), &entityObject);
                (*esDataPtr)->requestESEltTab[(*esDataPtr)->requestESEltNbr].sourceObjectEnum = entityObject;

                if (entityObject == NullEntity || entityObject == InvalidEntity)
                    (*esDataPtr)->requestESEltTab[(*esDataPtr)->requestESEltNbr].sourceDynStEnum = NullDynSt;
                else
                    (*esDataPtr)->requestESEltTab[(*esDataPtr)->requestESEltNbr].sourceDynStEnum = GET_EDITGUIST(entityObject);

                DBA_GetObjectEnum(GET_DICT(esCompoTab[i], A_ExtServiceCompo_DestEntityDictId), &entityObject);
                (*esDataPtr)->requestESEltTab[(*esDataPtr)->requestESEltNbr].targetObjectEnum = entityObject;

                if (entityObject == NullEntity || entityObject == InvalidEntity)
                    (*esDataPtr)->requestESEltTab[(*esDataPtr)->requestESEltNbr].targetDynStEnum = NullDynSt;
                else
                    (*esDataPtr)->requestESEltTab[(*esDataPtr)->requestESEltNbr].targetDynStEnum = GET_EDITGUIST(entityObject);

                ((*esDataPtr)->requestESEltNbr)++;
	        }

            /* External Service -> TAP */
            if ((ESERVICE_DIRECTION_ENUM)GET_ENUM(esCompoTab[i], A_ExtServiceCompo_DirectionEn) == ExtServiceDirection_In ||
                sameCompoForInOutFlg == TRUE)
            {
                (*esDataPtr)->responseESEltTab[(*esDataPtr)->responseESEltNbr].esCompoStp = esCompoTab[i];

                DBA_GetObjectEnum(GET_DICT(esCompoTab[i], A_ExtServiceCompo_SrcEntityDictId), &entityObject);
                (*esDataPtr)->responseESEltTab[(*esDataPtr)->responseESEltNbr].sourceObjectEnum = entityObject;

                if (entityObject == NullEntity || entityObject == InvalidEntity)
                    (*esDataPtr)->responseESEltTab[(*esDataPtr)->responseESEltNbr].sourceDynStEnum = NullDynSt;
                else
                    (*esDataPtr)->responseESEltTab[(*esDataPtr)->responseESEltNbr].sourceDynStEnum = GET_EDITGUIST(entityObject);

                DBA_GetObjectEnum(GET_DICT(esCompoTab[i], A_ExtServiceCompo_DestEntityDictId), &entityObject);
                (*esDataPtr)->responseESEltTab[(*esDataPtr)->responseESEltNbr].targetObjectEnum = entityObject;

                if (entityObject == NullEntity || entityObject == InvalidEntity)
                    (*esDataPtr)->responseESEltTab[(*esDataPtr)->responseESEltNbr].targetDynStEnum = NullDynSt;
                else
                    (*esDataPtr)->responseESEltTab[(*esDataPtr)->responseESEltNbr].targetDynStEnum = GET_EDITGUIST(entityObject);

                ((*esDataPtr)->responseESEltNbr)++;
            }
        }
        FREE(esCompoTab);

        if (((*esDataPtr)->requestESEltNbr) == 0 || ((*esDataPtr)->responseESEltNbr) == 0)
	    {
            ESRV_FreeEServiceData(esDataPtr);
            return(RET_DBA_ERR_EXT_SERVICE_FAILURE); /* At least one in each direction is mandatory */
        }

        /* PMSTA-25920 - CHU - 170207 */
        ESRV_SetExtSvcTraceFile((*esDataPtr));

	}

    return(RET_SUCCEED);
}

/************************************************************************
*
*  Function          : FIN_CmpESCompoDirRank()
*
*  Description       : Sort elements on Direction / Rank
*
*  Arguments         :
*
*  Return            : RET_CODE
*
*  Creation date     : PMSTA-20235 - CHU - 150420
*
*  Last modification :
*
*************************************************************************/
STATIC int FIN_CmpESCompoDirRank(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    if (GET_ENUM((*ptr1), A_ExtServiceCompo_DirectionEn) == GET_ENUM((*ptr2), A_ExtServiceCompo_DirectionEn))
	{
        return(GET_INT((*ptr1), A_ExtServiceCompo_Rank) - GET_INT((*ptr2), A_ExtServiceCompo_Rank));
	}

    return(GET_ENUM((*ptr1), A_ExtServiceCompo_DirectionEn) - GET_ENUM((*ptr2), A_ExtServiceCompo_DirectionEn));
}

/************************************************************************
*
*  Function          : ESRV_FreeEServiceData()
*
*  Description       : Allocate and init external service data structures
*
*  Arguments         :
*
*  Return            : RET_CODE
*
*  Creation date     : PMSTA-20235 - CHU - 150421
*
*  Last modification :
*
*************************************************************************/
STATIC RET_CODE ESRV_FreeEServiceData(EXT_SERVICE_DATA_STP *esDataPtr)
{
	RET_CODE				ret = RET_SUCCEED;
    int            i = 0;

    if(esDataPtr != NULL &&
       (*esDataPtr) != (EXT_SERVICE_DATA_STP)NULL)
	{
        for (i=0; i < (*esDataPtr)->requestESEltNbr; i++)
		{
            if ((*esDataPtr)->requestESEltTab[i].sourceDataTab != NULL)
                FREE((*esDataPtr)->requestESEltTab[i].sourceDataTab);

            if ((*esDataPtr)->requestESEltTab[i].targetDataTab != NULL)
                FREE((*esDataPtr)->requestESEltTab[i].targetDataTab);

            if ((*esDataPtr)->requestESEltTab[i].esCompoStp != NULLDYNST)
                FREE_DYNST((*esDataPtr)->requestESEltTab[i].esCompoStp, A_ExtServiceCompo);
		}
        FREE((*esDataPtr)->requestESEltTab);

        for (i=0; i < (*esDataPtr)->responseESEltNbr; i++)
        {
            if ((*esDataPtr)->responseESEltTab[i].sourceDataTab != NULL)
                FREE((*esDataPtr)->responseESEltTab[i].sourceDataTab);

            if((*esDataPtr)->responseESEltTab[i].targetDataTab != NULL)
                FREE((*esDataPtr)->responseESEltTab[i].targetDataTab);

            if ((*esDataPtr)->responseESEltTab[i].esCompoStp != NULLDYNST)
                FREE_DYNST((*esDataPtr)->responseESEltTab[i].esCompoStp, A_ExtServiceCompo);
        }
        FREE((*esDataPtr)->responseESEltTab);

        if ((*esDataPtr)->esFreeFlg == TRUE)
		{
            FREE_DYNST((*esDataPtr)->esPtr, A_ExtService);
		}

        /* PMSTA - 25920 - CHU - 170207 */
        if (SYS_GetEnv("AAAEXTSVCTRACE") != NULL &&
            (*esDataPtr)->extSvcTraceFileSt.extSvcTraceStatus == RET_SUCCEED)
        {
            FREE((*esDataPtr)->extSvcTraceFileSt.extSvcTraceFilename);
            (*esDataPtr)->extSvcTraceFileSt.extSvcTraceStatus = RET_GEN_INFO_NOACTION;
        }

        FREE(*esDataPtr);
	}

    return(ret);
}

/************************************************************************
*
*  Function          : ESRV_PrepareData()
*
*  Description       : Prepare data to send to external service
*
*  Arguments         :
*
*  Return            : RET_CODE
*
*  Creation date     : PMSTA-20235 - CHU - 150413
*
*  Last modification :
*
*************************************************************************/
STATIC RET_CODE ESRV_PrepareData(DBA_HIER_HEAD_STP      srcHierHead,
                                 DBA_HIER_HEAD_STP      destHierHead,
                                 DBA_DYNFLD_STP         domainPtr,
                                 EXT_SERVICE_DATA_STP   esDataPtr,
								 EXT_SERVICE_DATA_STP   *filteredESDataPtr)
{
	RET_CODE                ret = RET_SUCCEED;
	int                     i = 0, filteredReqCount = 0;
	int                     *filteredReqRows = (int *)NULL;

	if ((filteredReqRows = (int *)CALLOC(esDataPtr->requestESEltNbr, sizeof(int))) == NULL)
	{
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO);
		return(RET_MEM_ERR_ALLOC);

	}

	for (i = 0; i < (esDataPtr)->requestESEltNbr; i++)
	{
		/* Convert this... */
		/* input source records should be available in hierarchy */
		if ((ESRV_LoadEntityTabWithCompoFilterScpt(srcHierHead,
			                                       domainPtr,
			                                       esDataPtr->requestESEltTab[i].esCompoStp,
	                                        	   esDataPtr->requestESEltTab[i].sourceDynStEnum,
			                                       &(esDataPtr->requestESEltTab[i].sourceDataTab),
			                                       &(esDataPtr->requestESEltTab[i].sourceDataNbr))) == RET_SUCCEED)
		{
			if (esDataPtr->requestESEltTab[i].sourceDataNbr > 0)
			{
				if ((ret = ESRV_ConvertSourceToTarget(esDataPtr, srcHierHead, destHierHead, domainPtr, &(esDataPtr->requestESEltTab[i]))) != RET_SUCCEED) /* PMSTA-25920 - CHU - 170207 */
				{
					FREE(filteredReqRows);
					return(ret);
				}

				/*PMSTA-29906 -NRAO -180215 - keep a record of requests with valid sourceDataTab */
				filteredReqRows[filteredReqCount] = i;
				filteredReqCount++;
			}
			else
			{
				MSG_LogSrvMesg(UNUSED, UNUSED, "No Data to send for External Service Request with SOURCE -> %1 and TARGET -> %2",
					SysnameType, DBA_GetDictEntitySqlName(esDataPtr->requestESEltTab[i].sourceObjectEnum),
					SysnameType, DBA_GetDictEntitySqlName(esDataPtr->requestESEltTab[i].targetObjectEnum));
			}

		}
		else
		{
			MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "ESRV_ExecCallToExtService", "no data to send");
			FREE(filteredReqRows);
			return(RET_GEN_ERR_INVARG);
		}


	}

	/*PMSTA-29906 -NRAO -180215 - Rebuild ES Data only with valid request elements */
	if ((ret = ESRV_RestructureData(esDataPtr, filteredESDataPtr, filteredReqRows, filteredReqCount)) != RET_SUCCEED)
	{
		FREE(filteredReqRows);
		return ret;
	}

	FREE(filteredReqRows);

	return (ret);
}

/************************************************************************
*
*  Function          : ESRV_SendExternalRequest()
*
*  Description       : Call external service
*
*  Arguments         :
*
*  Return            : RET_CODE
*
*  Creation date     : PMSTA-20235 - CHU - 150413
*
*  Last modification :
*
*************************************************************************/
STATIC RET_CODE ESRV_SendExternalRequest(EXT_SERVICE_DATA_STP    esDataPtr)
{
    RET_CODE    ret = RET_SUCCEED;

    MSG_LogSrvMesg(UNUSED, UNUSED, "Call External Service %1",
        CodeType, GET_CODE(esDataPtr->esPtr, A_ExtService_Cd));

    ret = HttpESClient(esDataPtr);

    return (ret);
}

/************************************************************************
**
**  Function    :   TestJson::HttpESClient
**
**  Description :   Connect to a http server and send some json data that we will receive back
**                  Test also:
**                      - HTTP header
**                      - HTTP status
**
**  Arguments   :   None
**
**  Return      :   None
**
**  Last modif. :   PMSTA-20235 - CHU - 150420
**                  PMSTA-20626 - 300615 - PMO : Timeout in external service not implemented
**
*************************************************************************/

static std::string to_String (AuthenticationMechanismAlgorithmEn value)
{
    switch (value)
    {
    case AuthenticationMechanismAlgorithmEn::NONE:
        return "None";
        break;
    case AuthenticationMechanismAlgorithmEn::HS256:
        return "Hs256";
        break;
    case AuthenticationMechanismAlgorithmEn::HS384:
        return "Hs384";
        break;
    case AuthenticationMechanismAlgorithmEn::HS512:
        return "Hs512";
        break;
    case AuthenticationMechanismAlgorithmEn::RS256:
        return "Rs256";
        break;
    case AuthenticationMechanismAlgorithmEn::RS384:
        return "Rs384";
        break;
    case AuthenticationMechanismAlgorithmEn::RS512:
        return "Rs512";
        break;
    case AuthenticationMechanismAlgorithmEn::ES256:
        return "Es256";
        break;
    case AuthenticationMechanismAlgorithmEn::ES384:
        return "Es384";
        break;
    case AuthenticationMechanismAlgorithmEn::ES512:
        return "Es512";
        break;
    default:
        return "None";
        break;
    }

};

STATIC RET_CODE HttpESClient(EXT_SERVICE_DATA_STP esDataPtr)
{
	RET_CODE			  retCode = RET_SUCCEED;
	HttpClient			  http;
	HttpMethodPost		  methodPost;
    FormatFieldsRapidJson formatFields;
    BuildBindOption       es_buildBindOption(BuildBindOption::Categ::MdAttribute);
    ReaderParserRapidJson es_jsonParser(es_buildBindOption, nullptr);
	int					  httpStatus = HTTP_STATUS_OK;
	bool				  httpExecRet = true;

    std::string loginName;
    SYSNAME_T OboUser;

	GEN_GetUserInfo(UserLogin, loginName);
    PasswordEncrypted * pE = nullptr;
    GEN_GetUserInfo(UserPasswd, &pE);

    DBA_GetUserInfo2(A_ApplUser_Cd, (PTR) OboUser, TRUE); /* PMSTA-24049 - CHU - 160728 */

    CURRENTCHARSETCODE_ENUM charset;

    GEN_GetApplInfo(ApplCurrentCharsetCodeEnum, &charset);
    formatFields.setCharsetUtf8(charset == CurrentCharsetCode_UTF8);

	http.setErrorCallback(MSG_SendMesg);
	es_jsonParser.setErrorCallback(MSG_SendMesg);
	formatFields.setErrorCallback(MSG_SendMesg);

	methodPost.setUser(loginName.c_str());
	methodPost.setPassword(pE->getClearPassword().getPassword());
    methodPost.setOnBehalfOfUser(OboUser); /* PMSTA-24049 - CHU - 160728 */
	methodPost.setContentType(HttpAbstractRequestReply::ContentType::HTTP_JSON);  /* PMSTA-32895 - 140119 - FME Cluster Logger */

    methodPost.setTimeOut(GET_INT(esDataPtr->esPtr, A_ExtService_TimeoutT));      /* PMSTA-20626 - 300615 - PMO */
    methodPost.setUrl(GET_URL(esDataPtr->esPtr, A_ExtService_UrlAddress));

    DbiConnectionHelper dbiConnHelper(SqlServer);
    MemoryPool      mp;


    if (IS_NULLFLD(esDataPtr->esPtr, A_ExtService_AuthenticationMechanismId) == FALSE)
    {
        /* PMSTA-50575 - FME - 20221011  */
        AAALogger logger = AAALogger::get(AAALogger::Logger::Application);
        logger.info("Start JWT");
        DBA_DYNFLD_STP      sAuthMech = mp.allocDynst(FILEINFO, S_AuthenticationMechanism);
        DBA_DYNFLD_STP      aAuthMech = mp.allocDynst(FILEINFO, A_AuthenticationMechanism);
        DBA_DYNFLD_STP *    authAttribTab = nullptr;
        int                 authAttribNb = 0;

        DBA_CopyDynFld(sAuthMech, S_AuthenticationMechanism_Id, esDataPtr->esPtr, A_ExtService_AuthenticationMechanismId);

        retCode = dbiConnHelper.dbaGet(AuthenticationMechanism, UNUSED, sAuthMech, &aAuthMech);
        if (retCode != RET_SUCCEED) {
            MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, "HttpESClient()", "can not retreive AuthenticationMechanism");
            return retCode;
        }

        if (GET_A_AuthenticationMechanism_NatEn(aAuthMech) == AuthenticationMechanismNatEn::JWTCreate)
        {
            // @@TODO create a cache of Token
            jwt::jwt_object jwt_obj;

            const std::string algoStr = to_String(GET_A_AuthenticationMechanism_AlgorithmEn(aAuthMech));
            const std::string privateKey = GET_NOTE(aAuthMech, A_AuthenticationMechanism_Privatekey);
            jwt_obj = { jwt::params::algorithm(algoStr), jwt::params::secret(privateKey) };

            const std::string issuer = GET_NOTE(aAuthMech, A_AuthenticationMechanism_Issuer);
            jwt_obj.add_claim(jwt::registered_claims::issuer, issuer);
            
            int tokenValidityDuration = GET_INT(aAuthMech, A_AuthenticationMechanism_LifeTime);
            if (tokenValidityDuration < 60)
            {
                tokenValidityDuration = 60;
            }
            auto creationTime = std::chrono::system_clock::now();
            jwt_obj.add_claim(jwt::registered_claims::issued_at, creationTime);
            jwt_obj.add_claim(jwt::registered_claims::expiration, creationTime + std::chrono::seconds{ tokenValidityDuration });
            //jwt_obj.add_claim(jwt::registered_claims::not_before, creationTime - std::chrono::seconds{ 10 });

            const std::string audience = GET_NOTE(aAuthMech, A_AuthenticationMechanism_Audience);
            jwt_obj.add_claim(jwt::registered_claims::audience, audience);

            DBA_DYNFLD_STP      admArg = mp.allocDynst(FILEINFO, Adm_Arg);
            DBA_CopyDynFld(admArg, Adm_Arg_Id, sAuthMech, S_AuthenticationMechanism_Id);


            retCode = dbiConnHelper.dbaSelect(AuthenticationAttribute, UNUSED, admArg, S_AuthenticationAttribute, &authAttribTab, &authAttribNb);
            if (retCode != RET_SUCCEED) {
                MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, "HttpESClient()", "can not retrieve AuthenticationAttribute Short");
                return retCode;
            }

            mp.owner(authAttribTab, authAttribNb);
            for (int i = 0; i < authAttribNb; i++)
            {
                DBA_DYNFLD_STP      aAuthAttrib = mp.allocDynst(FILEINFO, A_AuthenticationAttribute);

                retCode = dbiConnHelper.dbaGet(AuthenticationAttribute, UNUSED, authAttribTab[i], &aAuthAttrib);
                if (retCode != RET_SUCCEED) {
                    MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, "HttpESClient()", "can not retrieve AuthenticationAttribute All");
                    return retCode;
                }
                AuthenticationAttributeKindEn kind = GET_A_AuthenticationAttribute_KindEn(aAuthAttrib);

                std::string  keyName;
                /* PMSTA-55146 - 20231208 - FME  UniVarchar fix */
                // Should have be defined as code_t instead of uni_name_t
                if (IS_USTRINGFLD(A_AuthenticationAttribute, A_AuthenticationAttribute_KeyName) == TRUE)
                {
                    char *convKeyNamePtr = nullptr;
                    ICU4AAA_ConvertToDefaultCharSet(GET_UNAME(aAuthAttrib, A_AuthenticationAttribute_KeyName), -1, &convKeyNamePtr, NULL);
                    keyName = convKeyNamePtr;
                    FREE(convKeyNamePtr);
                }
                else
                {
                    keyName = GET_NAME(aAuthAttrib, A_AuthenticationAttribute_KeyName);
                }

                const std::string value = GET_NOTE(aAuthAttrib, A_AuthenticationAttribute_Value);
                switch (kind)
                {
                case AuthenticationAttributeKindEn::JWTPrivateClaim:
                {
                    jwt_obj.add_claim(keyName, value);
                }
                break;
                case AuthenticationAttributeKindEn::JWTHeader:
                {
                    jwt_obj.header().add_header(keyName, value);
                }
                break;
                default:
                    retCode = RET_DBA_ERR_INVDATA;
                    MSG_SendMesg(retCode, 1, FILEINFO, "HttpESClient()", "Invalid AuthenticationAttributeKindEn");
                    return retCode;
                    break;
                }
            }
            logger.info("Generate JWT");
            const std::string token = jwt_obj.signature();
            methodPost.setTokenAuthentication(token);
            logger.info("End JWT");

        }
        else if (GET_A_AuthenticationMechanism_NatEn(aAuthMech) == AuthenticationMechanismNatEn::JWTForward)
        {
            retCode = RET_DBA_ERR_INVDATA;
            MSG_SendMesg(retCode, 1, FILEINFO, "HttpESClient()", "Not yet implemented AuthenticationMechanismNatEn::JWTForward");
            return retCode;
        }
        else if (GET_A_AuthenticationMechanism_NatEn(aAuthMech) == AuthenticationMechanismNatEn::Basic)
        {
            retCode = RET_DBA_ERR_INVDATA;
            MSG_SendMesg(retCode, 1, FILEINFO, "HttpESClient()", "Not yet implemented AuthenticationMechanismNatEn::Basic");
            return retCode;
        }
        else {
            retCode = RET_DBA_ERR_INVDATA;
            MSG_SendMesg(retCode, 1, FILEINFO, "HttpESClient()", "Invalid AuthenticationMechanismNatEn");
            return retCode;

        }

    }


    /*PMSTA-40058 -NRAO - 08Jun2020 -Proxy capability for external service*/
    if (IS_NULLFLD(esDataPtr->esPtr, A_ExtService_Proxy) == FALSE)
    {
        const std::string tokenStr = GET_NOTE(esDataPtr->esPtr, A_ExtService_Proxy);
        std::vector<std::string>    tokens;
        SYS_StringTokenize(tokens, tokenStr, ": ");
        bool useProxy = false;

        for (size_t idx = 0; idx < tokens.size(); idx++)
        {
            if (idx == 0) /*Host*/
            {
               methodPost.setProxyHostName(QString::fromStdString(tokens[idx]));
               useProxy = false;
            }
            else if (idx == 1) /*port*/
            {
               std::stringstream nPortStr(tokens[idx]);
               qint16 nPort = 0;
               nPortStr >> nPort;
               methodPost.setProxyPort(nPort);
               useProxy = true;
            }
            else if (idx == 2) /*Proxy username*/
            {
                methodPost.setProxyUserName(QString::fromStdString(tokens[idx]));
                useProxy = false;
            }
            else if (idx == 3) /*proxy password*/
            {
                methodPost.setProxyPassword(QString::fromStdString(tokens[idx]));
                useProxy = true;
            }
        }

        methodPost.setUseProxy(useProxy);
        methodPost.setProxySource(HttpAbstractRequestReply::ProxySource::Service_External);
    }

    for (int idxDyn = 0; idxDyn < esDataPtr->requestESEltNbr; idxDyn++)
	{
        DBA_DYNST_ENUM     inputDySt = esDataPtr->requestESEltTab[idxDyn].targetDynStEnum;
        OBJECT_ENUM        object = esDataPtr->requestESEltTab[idxDyn].targetObjectEnum;
        DbiBindDataDef     mapBindDataDef;
        BuildBindOption    buildBindOption;

        ReaderParser::buildBindMapFromData(std::string(), object, inputDySt, nullptr, mapBindDataDef, buildBindOption);

        formatFields.blockModeBegin(object, inputDySt);

        formatFields.blockModeAdd(esDataPtr->requestESEltTab[idxDyn].targetDataTab,
                                  esDataPtr->requestESEltTab[idxDyn].targetDataNbr,
                                  mapBindDataDef,
                                  buildBindOption);

        formatFields.blockModeEnd();
    }

	std::string dataToSend;                          /* Data serialized */
	formatFields.getDataSerialized(dataToSend, true);

	if (true == formatFields.isError())
	{
        retCode = RET_DBA_ERR_INVDATA;
		MSG_SendMesg(retCode, 1, FILEINFO, "HttpESClient()", "Error formatting data");
        return retCode;
	}

	methodPost.setRequestBody(dataToSend);
	httpExecRet = http.executeMethod(&methodPost);
	httpStatus = methodPost.getHttpStatus();
	if (httpExecRet == true && httpStatus == HTTP_STATUS_OK)
	{ /* ok */
       const std::string& result = methodPost.getResponseResult();    /* DLA - PMSTA-27039 - 170419 */ /* PMSTA-32895 - 140119 - FME Cluster Logger */

        es_jsonParser.parse(result);

        size_t idxESCompo = 0; /* PMSTA-25920 - CHU - 140324 */
        while (es_jsonParser.setNextResultSet()) /* PMSTA-25920 - CHU - 140324 */
        {
			const size_t jsonNbDyn = es_jsonParser.getCurrDynNbr();

            if (jsonNbDyn == 0)  /* Deepthi - PMSTA-52299 - 201230315 */
            {
                MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "No JSON data found");
                continue;
            }
			(esDataPtr->responseESEltTab[idxESCompo].sourceDataTab) = (DBA_DYNFLD_STP *)CALLOC(jsonNbDyn, sizeof(DBA_DYNFLD_STP));

			DBA_DYNFLD_STP currentDynStPtr;
			while ((currentDynStPtr = es_jsonParser.getNextDynStp(ReaderParser::MEMORY_OWNED_BY::Requester)) != nullptr)
			{
				if (GET_DYNSTENUM(currentDynStPtr) == ((esDataPtr->responseESEltTab[idxESCompo].sourceDynStEnum)))
				{
					(esDataPtr->responseESEltTab[idxESCompo].sourceDataTab)[esDataPtr->responseESEltTab[idxESCompo].sourceDataNbr] = currentDynStPtr;
					(esDataPtr->responseESEltTab[idxESCompo].sourceDataNbr)++;
				}
			}
			if (es_jsonParser.getResultSetNbr() == 0) /* PMSTA-25920 - CHU - 140324 */
				break;
			idxESCompo++; /* PMSTA-25920 - CHU - 140324 */
		}

        retCode = (true == es_jsonParser.isError() ? RET_DBA_ERR_INVDATA : RET_SUCCEED);
	}
	else
	{
        retCode = RET_DBA_ERR_INVDATA;
	}

	return retCode;
}

/************************************************************************
*
*  Function          : ESRV_RetrieveData()
*
*  Description       : Call external service
*
*  Arguments         :
*
*  Return            : RET_CODE
*
*  Creation date     : PMSTA-20235 - CHU - 150413
*
*  Last modification :
*
*************************************************************************/
STATIC RET_CODE ESRV_RetrieveData(DBA_HIER_HEAD_STP      srcHierHead,
                                  DBA_HIER_HEAD_STP      destHierHead,
                                  DBA_DYNFLD_STP         domainPtr,
                                  EXT_SERVICE_DATA_STP   esDataPtr)
{
	RET_CODE	ret = RET_SUCCEED;
    int                        i = 0, row = 0, responseSourceNbr = 0;
    DBA_DYNFLD_STP            aScriptDef = NULLDYNST;
    DBA_DYNFLD_STP            *responseSourceTab = NULLDYNSTPTR;
    SCPT_ARG_STP             localFilterTree = NULL;
    DBA_DYNFLD_STP           evalRec = (DBA_DYNFLD_STP)NULL;
    int                      incrNb = 0;

    for (i = 0; i < esDataPtr->responseESEltNbr; i++)
    {
        /* Convert this... */
        /* get output source records, apply filter and store them into hierarchy */
        if ((ret = ESRV_LoadCompoFilterScpt(esDataPtr->responseESEltTab[i].esCompoStp, &aScriptDef)) != RET_SUCCEED)
        {
            return(ret);
        }

        if (aScriptDef != NULLDYNST &&
            IS_NULLFLD(aScriptDef, A_ScriptDef_Def) == FALSE &&
            GET_STRING(aScriptDef, A_ScriptDef_Def)[0] != END_OF_STRING &&
            SCPT_PrepTreeForFilter(GET_STRING(aScriptDef, A_ScriptDef_Def),
                                   destHierHead,
                                   domainPtr,
                                   esDataPtr->responseESEltTab[i].sourceObjectEnum,
                                   &localFilterTree,0, NULLDYNSTPTR) == RET_SUCCEED)
        {
            if (esDataPtr->responseESEltTab[i].sourceDataNbr == 0) /* Deepthi - PMSTA-52299 - 201230315 */
            {
                MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "No source data found");
                continue;
            }

            if ((responseSourceTab = (DBA_DYNFLD_STP *) CALLOC(esDataPtr->responseESEltTab[i].sourceDataNbr, sizeof(DBA_DYNFLD_STP))) == NULL)
            {
                SCPT_FreeTreeForFilter(&localFilterTree);
                FREE_DYNST(aScriptDef, A_ScriptDef);
                MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "output responseSourceTab ");
                return(RET_MEM_ERR_ALLOC);
            }
            responseSourceNbr = 0;

            for(row=0; row< esDataPtr->responseESEltTab[i].sourceDataNbr; row++)
            {
                if(SCPT_IsRemoveWithFilterTree(destHierHead,
                                               esDataPtr->responseESEltTab[i].sourceObjectEnum,
                                               &localFilterTree,
                                               esDataPtr->responseESEltTab[i].sourceDataTab[row],
                                               &evalRec,
                                               &incrNb))
                {
                    FREE_DYNST(esDataPtr->responseESEltTab[i].sourceDataTab[row], esDataPtr->responseESEltTab[i].sourceDynStEnum);
                }
                else
                {
                    responseSourceTab[responseSourceNbr] = esDataPtr->responseESEltTab[i].sourceDataTab[row];
                    responseSourceNbr++;
                }
            }

            FREE(esDataPtr->responseESEltTab[i].sourceDataTab);
            esDataPtr->responseESEltTab[i].sourceDataTab = responseSourceTab;
            esDataPtr->responseESEltTab[i].sourceDataNbr = responseSourceNbr;
        }

        FREE_DYNST(aScriptDef, A_ScriptDef);

        /* store response source records into destination hierarchy */
        DBA_AddHierRecordList(destHierHead,
                              esDataPtr->responseESEltTab[i].sourceDataTab,
                              esDataPtr->responseESEltTab[i].sourceDataNbr,
                              esDataPtr->responseESEltTab[i].sourceDynStEnum, TRUE);

        /* Converted response source records to target entity */
        if ((ret = ESRV_ConvertSourceToTarget(esDataPtr, srcHierHead, destHierHead, domainPtr, &(esDataPtr->responseESEltTab[i]))) != RET_SUCCEED) /* PMSTA-25920 - CHU - 170207 */
        {
            return(ret);
        }
    }

	return (ret);
}

/************************************************************************
*
*  Function          : ESRV_ConvertSourceToTarget()
*
*  Description       : Prepare data to send to external service
*
*  Arguments         :
*
*  Return            : RET_CODE
*
*  Creation date     : PMSTA-20235 - CHU - 150413
*
*  Last modification :
*
*************************************************************************/
STATIC RET_CODE ESRV_ConvertSourceToTarget(EXT_SERVICE_DATA_STP   esDataPtr, /* PMSTA-25920 - CHU - 170207 */
                                           DBA_HIER_HEAD_STP      srcHierHead,
                                           DBA_HIER_HEAD_STP      destHierHead,
										   DBA_DYNFLD_STP		  domainPtr,
                                           EXT_SERVICE_ELT_STP    esDataElt)
{
	RET_CODE				ret = RET_SUCCEED;
	int						i = 0, j = 0;
    FLAG_T                 *scptFlagTab = NULL, AddInHierFlg=FALSE;
    DBA_HIER_HEAD_STP       mainHierHead;

    if (esDataElt->sourceDataNbr > 0)
	{
        switch (GET_ENUM(esDataElt->esCompoStp, A_ExtServiceCompo_DirectionEn))
		{
            case ExtServiceDirection_In: /* Response */
                mainHierHead = destHierHead;
                break;

            case ExtServiceDirection_Out: /* Request */
            default:
                mainHierHead = srcHierHead;
		}

        /* Alloc new array */
        if((esDataElt->targetDataTab = (DBA_DYNFLD_STP *)CALLOC(esDataElt->sourceDataNbr, sizeof(DBA_DYNFLD_STP))) == NULL)
		{
			MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "input targetDataTab[i]");
			return(RET_MEM_ERR_ALLOC);
		}

        if (esDataElt->targetDynStEnum > InvalidDynSt &&
            esDataElt->targetDynStEnum != esDataElt->sourceDynStEnum)
		{
            if ((scptFlagTab = (FLAG_T *)CALLOC(GET_FLD_NBR(esDataElt->targetDynStEnum), sizeof(FLAG_T))) == NULL)
			{
				MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "scptFlagTab");
				return(RET_MEM_ERR_ALLOC);
			}
            memset(scptFlagTab, FALSE, GET_FLD_NBR(esDataElt->targetDynStEnum)*sizeof(FLAG_T));
		}

        for (j = 0; j < esDataElt->sourceDataNbr; j++)
	    {
            /* PMSTA-22496 - DDV - 160517 - If target entity is define and not egal to source entity, convert records */
            if (esDataElt->targetDynStEnum > InvalidDynSt &&
                esDataElt->targetDynStEnum != esDataElt->sourceDynStEnum)
		    {
                AddInHierFlg=TRUE;

                if ((esDataElt->targetDataTab[j] = ALLOC_DYNST(esDataElt->targetDynStEnum)) == NULL)
				{
                    MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "input targetDataTab[j]");
					return(RET_MEM_ERR_ALLOC);
				}
                (esDataElt->targetDataNbr)++;

				/* Apply DV's to convert source into target */
                if (SCPT_ComputeScreenDV (  esDataElt->targetObjectEnum,
                                            DictFct_0,
                                            scptFlagTab,
                                            NULL,              /* HFI-PMSTA-25327-171023  Dedicated flag tab for filter    */
                                            esDataElt->targetDataTab[j],
                                            NULL,
                                            domainPtr,
                                            NULLDYNST,			/* PMSTA13283 - DDV - 120117 */
                                            TRUE,
                                            TRUE,				/*  FIH-REF8711-030122  Put TRUE in place of FALSE  */
                                            EvalType_DefValAndFilter,
                                            0,
                                            (int*)NULL,
                                            NULL,
                                            mainHierHead,
                                            GET_DICT(esDataElt->esCompoStp, A_ExtServiceCompo_ScreenDictId),
                                            DictScreen,			/*  FIH-REF9789-040209  */
                                            NULL,
                                            NULL,
                                            /* pscptFmtDataDef */NULL,
                                            esDataElt->sourceDataTab[j],    /*Currently selected data(format data)   */
                                            esDataElt->sourceDataTab[j],    /*Reference data(real data)               */
                                            esDataElt->sourceObjectEnum,
                                            FALSE,				/*  True DV on Buy or Sell                  */
                                            FALSE,
                                            0) != 0)
				{
					char convStr[256];

					sprintf(convStr, "applying DV on element %d (from %s to %s)", i,
                        DBA_GetDictEntitySqlName(esDataElt->sourceObjectEnum),
                        DBA_GetDictEntitySqlName(esDataElt->targetObjectEnum));

					ret = RET_GEN_ERR_INVARG;
					FREE(scptFlagTab);
                    MSG_SendMesg(ret, 1, FILEINFO, "ESRV_PrepareData()", convStr);
					return (ret);
				}
			}
	        else
	        {
                AddInHierFlg=FALSE;
                esDataElt->targetDataTab[j] = esDataElt->sourceDataTab[j];
            }
	    }
        FREE(scptFlagTab);

        /* store results into hierarchy */
        if (AddInHierFlg == TRUE)
	    {
            ret = DBA_AddHierRecordList(mainHierHead,
                                        esDataElt->targetDataTab,
                                        esDataElt->targetDataNbr,
                                        esDataElt->targetDynStEnum, TRUE);
        }
	}

    MSG_LogSrvMesg(UNUSED, UNUSED, "External Service converted %1 %2 into %3 %4",
        IntType, esDataElt->sourceDataNbr,
        SysnameType, DBA_GetDictEntitySqlName(esDataElt->sourceObjectEnum),
        IntType, esDataElt->targetDataNbr,
        SysnameType, DBA_GetDictEntitySqlName(esDataElt->targetObjectEnum));

    /* < PMSTA-25920 - CHU - 170207 */
    if (esDataElt->sourceDataNbr > 0)
        ESRV_WriteExtSvcTraceFile(esDataPtr, esDataElt->sourceDataTab, 0, esDataElt->sourceDataNbr);
    if (esDataElt->targetDataNbr > 0)
        ESRV_WriteExtSvcTraceFile(esDataPtr, esDataElt->targetDataTab, 0, esDataElt->targetDataNbr);
    /* > PMSTA-25920 - CHU - 170207 */

    return(ret);
}

/************************************************************************
*
*  Function          : ESRV_LoadEntityTabWithCompoFilterScpt()
*
*  Description       : load IN/Out source entity with filter
*
*  Arguments         :
*
*  Return            : RET_CODE
*
*  Creation date     : PMSTA-20235 - CHU - 150413
*
*  Last modification :
*
*************************************************************************/
STATIC RET_CODE ESRV_LoadEntityTabWithCompoFilterScpt(DBA_HIER_HEAD_STP   srcHierHead,
                                                      DBA_DYNFLD_STP      domainPtr,
                                                      DBA_DYNFLD_STP      esCompoTab,
                                                      DBA_DYNST_ENUM      esDynStEnum,
                                                      DBA_DYNFLD_STP    **filteredEntityTab,
                                                      int                *filteredEntityNbr)
{
    RET_CODE                ret = RET_SUCCEED;
    DBA_DYNFLD_STP            aScriptDef = NULLDYNST;
    int                        tmpRecNbr = 0;

    if ((ret = ESRV_LoadCompoFilterScpt(esCompoTab, &aScriptDef)) != RET_SUCCEED)
    {
        return(ret);
    }

    tmpRecNbr = DBA_GetHierEltWithScptFilter(srcHierHead,
                                             esDynStEnum,
                                             NULL,
                                             NULL,
                                             aScriptDef != NULL ? GET_STRING(aScriptDef, A_ScriptDef_Def) : NULL,
                                             domainPtr,
                                             FALSE,
                                             filteredEntityNbr,
                                             filteredEntityTab);

    if (tmpRecNbr != *filteredEntityNbr)
    {
        int i, pos;
        for (i=0, pos=0; i<*filteredEntityNbr;i++)
	{
                if ((*filteredEntityTab)[i] == NULLDYNSTPTR)
                    continue;

                (*filteredEntityTab)[pos]=(*filteredEntityTab)[i];
                pos++;
        }
        *filteredEntityNbr = pos;
	}
    FREE_DYNST(aScriptDef, A_ScriptDef);

    return (ret);
}

/************************************************************************
*
*  Function          : ESRV_LoadEntityTabWithCompoFilterScpt()
*
*  Description       : load IN/Out source entity with filter
*
*  Arguments         :
*
*  Return            : RET_CODE
*
*  Creation date     : PMSTA-20235 - CHU - 150413
*
*  Last modification :
*
*************************************************************************/
STATIC RET_CODE ESRV_LoadCompoFilterScpt(DBA_DYNFLD_STP     esCompoStp,
                                         DBA_DYNFLD_STP    *aScriptDefPtr)
{
	RET_CODE ret = RET_SUCCEED;
    DICT_ATTRIB_STP            filterDictAttrStp;

    if (DBA_SearchAttribSqlName(ExtServiceCompo, "filter", &filterDictAttrStp) == RET_SUCCEED)
    {
        if (((*aScriptDefPtr) = ALLOC_DYNST(A_ScriptDef)) == NULLDYNST)
	{
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        SET_DICT((*aScriptDefPtr), A_ScriptDef_AttrDictId, filterDictAttrStp->attrDictId);

        COPY_DYNFLD((*aScriptDefPtr), A_ScriptDef, A_ScriptDef_ObjId,
            esCompoStp, A_ExtServiceCompo, A_ExtServiceCompo_Id);

        SET_ENUM((*aScriptDefPtr), A_ScriptDef_NatEn, ScriptDef_ObjDefVal);

        if ((ret = DBA_Get2(ScriptDef, UNUSED, A_ScriptDef, (*aScriptDefPtr),
            A_ScriptDef, aScriptDefPtr,
            UNUSED, NULL, UNUSED)) != RET_SUCCEED)
        {
            FREE_DYNST((*aScriptDefPtr), A_ScriptDef);

            if (ret == RET_DBA_INFO_NODATA || ret == RET_DBA_INFO_NODATAWITHOPTI)
            {
                /*No filter defined*/
                *aScriptDefPtr = NULLDYNST;
                ret= RET_SUCCEED;
            }
        }
    }
    else
    {
        MSG_SendMesg(RET_DBA_ERR_MD, 1, FILEINFO, "external_service_compo", "filter");
        /* return (RET_DBA_ERR_MD); */ /* ben... pas de filtre, pas de filtre... */
	}

    return (ret);
}

/************************************************************************
*
*  Function          : ESRV_ReadOpti
*
*  Description       : Read dedicated cache for external services calls
*
*  Arguments         :
*
*  Return            : RET_CODE
*
*  Creation date     : PMSTA-22496 - DDV - 160614
*
*  Last modification :
*
*************************************************************************/
STATIC RET_CODE ESRV_ReadOpti(EXT_SERVICE_DATA_STP esDataPtr)
{
    ESRV_OPTIHEAD_STP      eSRVOptiHeadPtr = NULL;
    ESRV_OPTI_STP          eSRVOptiPtr = NULL;
    int                    optiTabIdx, optiIdx, requestEltIdx, responseEltIdx, recIdx, dataNbr, inDataNbr;
    EXT_SERVICE_DATA_STP   optiEsDataPtr = NULL, matchingEsDataPtr = NULL;
    EXT_SERVICE_ELT_STP    optiRequestEltPtr = NULL, inRequestEltPtr = NULL;
    EXT_SERVICE_ELT_STP    optiResponseEltPtr = NULL, inResponseEltPtr = NULL;
    FLAG_T                 continueCheckFlg = TRUE;
    DBA_DYNFLD_STP         *dataTab = NULLDYNSTPTR, *inDataTab = NULLDYNSTPTR;
    DBA_DYNST_ENUM         dynStEnum;

    if ((eSRVOptiHeadPtr = (ESRV_OPTIHEAD_STP) DBA_GetESRVOptiHeadPtr()) != NULL)
    {
        for (optiTabIdx = 0; optiTabIdx < eSRVOptiHeadPtr->eSRVOptiTabNbr && matchingEsDataPtr == NULL; optiTabIdx++)
	{
            if ((eSRVOptiPtr = eSRVOptiHeadPtr->eSRVOptiTabTab[optiTabIdx]) == NULL)
                continue;

            if (GET_ID(esDataPtr->esPtr, A_ExtService_Id) != GET_ID(eSRVOptiPtr->esDataTab[0]->esPtr, A_ExtService_Id))
                continue;

            for (optiIdx=0; optiIdx < eSRVOptiPtr->esDataNbr && matchingEsDataPtr == NULL; optiIdx++)
	{
                if ((optiEsDataPtr = eSRVOptiPtr->esDataTab[optiIdx]) == NULL)
                    continue;

                if (optiEsDataPtr->requestESEltNbr != esDataPtr->requestESEltNbr)
                    continue;

                continueCheckFlg = TRUE;

                for (requestEltIdx=0; requestEltIdx < optiEsDataPtr->requestESEltNbr && continueCheckFlg == TRUE; requestEltIdx++)
                {
                    if (optiEsDataPtr->requestESEltNbr == esDataPtr->requestESEltNbr)
	{
                        optiRequestEltPtr = &(optiEsDataPtr->requestESEltTab[requestEltIdx]);
                        inRequestEltPtr = &(esDataPtr->requestESEltTab[requestEltIdx]);

                        if (optiRequestEltPtr->sourceDynStEnum == inRequestEltPtr->sourceDynStEnum &&
                            optiRequestEltPtr->targetDynStEnum == inRequestEltPtr->targetDynStEnum)
                        {
                            if (optiRequestEltPtr->targetDynStEnum == NullDynSt)
	{
                                dynStEnum = optiRequestEltPtr->sourceDynStEnum;
                                dataTab = optiRequestEltPtr->sourceDataTab;
                                dataNbr = optiRequestEltPtr->sourceDataNbr;
                                inDataTab = inRequestEltPtr->sourceDataTab;
                                inDataNbr = inRequestEltPtr->sourceDataNbr;
	}
                            else
	{
                                dynStEnum = optiRequestEltPtr->targetDynStEnum;
                                dataTab = optiRequestEltPtr->targetDataTab;
                                dataNbr = optiRequestEltPtr->targetDataNbr;
                                inDataTab = inRequestEltPtr->targetDataTab;
                                inDataNbr = inRequestEltPtr->targetDataNbr;
	}

                            if (dataNbr != inDataNbr)
                                continueCheckFlg = FALSE;

                            for (recIdx=0; recIdx < dataNbr && continueCheckFlg == TRUE; recIdx++)
	{
                                if (CMP_DYNST(dataTab[recIdx], inDataTab[recIdx], dynStEnum, TRUE, TRUE) != 0)
                                    continueCheckFlg = FALSE;
                            }
	}
                        else
	{
                            continueCheckFlg = FALSE;
                        }
	}
                    else
	{
                        continueCheckFlg = FALSE;
                    }
	}

                if (continueCheckFlg == TRUE)
                    matchingEsDataPtr = optiEsDataPtr;
            }
	}

        /* if element found, copy results into esDataPtr */
        if (matchingEsDataPtr != NULL)
        {
            for (responseEltIdx=0; responseEltIdx < optiEsDataPtr->responseESEltNbr; responseEltIdx++)
	{
                optiResponseEltPtr = &(optiEsDataPtr->responseESEltTab[responseEltIdx]);
                inResponseEltPtr = &(esDataPtr->responseESEltTab[responseEltIdx]);

                if (ESRV_CopyEsElt(inResponseEltPtr, optiResponseEltPtr, TRUE) != RET_SUCCEED)
	{
                    int i;

                    for (i=0; i < responseEltIdx; i++)
	{
                        inResponseEltPtr = &(esDataPtr->responseESEltTab[responseEltIdx]);
                        DBA_FreeDynStTab(inResponseEltPtr->sourceDataTab, inResponseEltPtr->sourceDataNbr, inResponseEltPtr->sourceDynStEnum);
                    }
                    return(RET_DBA_ERR_OPTI);
                }
	}

            return(RET_SUCCEED);
	}
	}
    return(RET_DBA_INFO_NODATAOPTI);
}

/************************************************************************
*
*  Function          : ESRV_WriteOpti
*
*  Description       : Write current result into dedicated cache for external services calls
*
*  Arguments         :
*
*  Return            : RET_CODE
*
*  Creation date     : PMSTA-22496 - DDV - 160614
*
*  Last modification :
*
*************************************************************************/
STATIC RET_CODE ESRV_WriteOpti(EXT_SERVICE_DATA_STP esDataPtr)
{
    ESRV_OPTIHEAD_STP      eSRVOptiHeadPtr = NULL;
    ESRV_OPTI_STP          eSRVOptiPtr = NULL;
    int                    optiTabIdx, optiIdx;
    EXT_SERVICE_DATA_STP   optiEsDataPtr = NULL;

    static int          useOptiFlg = NO_VALUE;

    if (useOptiFlg == NO_VALUE)
	{
        char        *paramStr = NULL ;
        int         paramInt;

        useOptiFlg = TRUE;

        if ( ( paramStr = SYS_GetEnv ("AAANOESRVOPTI") )!= NULL)
	{
            paramInt = atoi (paramStr);
            if (paramInt == 1)
                useOptiFlg = FALSE;
        }
	}

    if (useOptiFlg == FALSE)
        return(RET_SUCCEED);

    if ((eSRVOptiHeadPtr = (ESRV_OPTIHEAD_STP) DBA_GetESRVOptiHeadPtr()) == NULL)
	{
        if ((eSRVOptiHeadPtr = (ESRV_OPTIHEAD_STP) CALLOC(1, sizeof (ESRV_OPTIHEAD_ST))) == NULL)
		return(RET_MEM_ERR_ALLOC);

        DBA_SetESRVOptiHeadPtr((PTR) eSRVOptiHeadPtr);

        if (DBA_GetESRVOptiHeadPtr() == NULL)
            return(RET_DBA_ERR_OPTI);
	}

    for (optiTabIdx = 0; optiTabIdx < eSRVOptiHeadPtr->eSRVOptiTabNbr; optiTabIdx++)
	{
        if ((eSRVOptiPtr = eSRVOptiHeadPtr->eSRVOptiTabTab[optiTabIdx]) == NULL)
            continue;

        if (GET_ID(esDataPtr->esPtr, A_ExtService_Id) == GET_ID(eSRVOptiPtr->esDataTab[0]->esPtr, A_ExtService_Id))
            break;
	}

    /* current service not found, add a new Opti in OptiTab */
    if (optiTabIdx == eSRVOptiHeadPtr->eSRVOptiTabNbr)
	{
        if (eSRVOptiHeadPtr->eSRVOptiTabAllocSz == eSRVOptiHeadPtr->eSRVOptiTabNbr)
	{
            eSRVOptiHeadPtr->eSRVOptiTabAllocSz += 20;
            eSRVOptiHeadPtr->eSRVOptiTabTab = (ESRV_OPTI_STP *) REALLOC(eSRVOptiHeadPtr->eSRVOptiTabTab, eSRVOptiHeadPtr->eSRVOptiTabAllocSz * sizeof(ESRV_OPTI_STP));
	}

        if ((eSRVOptiHeadPtr->eSRVOptiTabTab[optiTabIdx] = (ESRV_OPTI_STP) CALLOC(1, sizeof(ESRV_OPTI_ST))) == NULL)
            return(RET_DBA_ERR_OPTI);

        eSRVOptiHeadPtr->eSRVOptiTabNbr++;

	}

    eSRVOptiPtr = eSRVOptiHeadPtr->eSRVOptiTabTab[optiTabIdx];

    /* copy data in optimisation */
    if (eSRVOptiPtr->esDataTabAllocSz == eSRVOptiPtr->esDataNbr)
	{
        eSRVOptiPtr->esDataTabAllocSz += 50;
        eSRVOptiPtr->esDataTab = (EXT_SERVICE_DATA_STP *) REALLOC(eSRVOptiPtr->esDataTab, eSRVOptiPtr->esDataTabAllocSz * sizeof(EXT_SERVICE_DATA_STP));
	}

    optiIdx = eSRVOptiPtr->esDataNbr;

    if ((optiEsDataPtr = eSRVOptiPtr->esDataTab[optiIdx] = (EXT_SERVICE_DATA_STP) CALLOC(1, sizeof(EXT_SERVICE_DATA_ST))) == NULL)
        return(RET_DBA_ERR_OPTI);

    if (ESRV_CopyEsData(optiEsDataPtr, esDataPtr) != RET_SUCCEED)
	{
        FREE(eSRVOptiPtr->esDataTab[optiIdx]);
        return(RET_DBA_ERR_OPTI);
	}

    eSRVOptiPtr->esDataNbr++;

    return(RET_SUCCEED);
}

/************************************************************************
*
*  Function          : ESRV_CopyEsData
*
*  Description       : Copy all usefull esData's information into esData used by optimisation.
*
*  Arguments         :
*
*  Return            : RET_CODE
*
*  Creation date     : PMSTA-22496 - DDV - 160621
*
*  Last modification :
*
*************************************************************************/
STATIC RET_CODE ESRV_CopyEsData(EXT_SERVICE_DATA_STP destEsDataPtr,
                                EXT_SERVICE_DATA_STP srcEsDataPtr)
{
    int                    requestEltIdx, responseEltIdx;
    EXT_SERVICE_ELT_STP    optiRequestEltPtr = NULL, srcRequestEltPtr = NULL;
    EXT_SERVICE_ELT_STP    optiResponseEltPtr = NULL, srcResponseEltPtr = NULL;

    if (destEsDataPtr == NULL)
        return(RET_DBA_ERR_OPTI);

    if ((destEsDataPtr->esPtr = ALLOC_DYNST(A_ExtService)) == NULLDYNST)
        return(RET_DBA_ERR_OPTI);

    destEsDataPtr->esFreeFlg = TRUE;
    COPY_DYNST(destEsDataPtr->esPtr, srcEsDataPtr->esPtr, A_ExtService);

    /* copy all request elements */
    if ((destEsDataPtr->requestESEltTab = (EXT_SERVICE_ELT_STP) CALLOC(srcEsDataPtr->requestESEltNbr, sizeof(EXT_SERVICE_ELT_ST))) == NULL)
        return(RET_DBA_ERR_OPTI);

    destEsDataPtr->requestESEltNbr = srcEsDataPtr->requestESEltNbr;

    for (requestEltIdx=0; requestEltIdx < srcEsDataPtr->requestESEltNbr; requestEltIdx++)
	{
        optiRequestEltPtr = &(destEsDataPtr->requestESEltTab[requestEltIdx]);
        srcRequestEltPtr = &(srcEsDataPtr->requestESEltTab[requestEltIdx]);

        if (ESRV_CopyEsElt(optiRequestEltPtr, srcRequestEltPtr, FALSE) != RET_SUCCEED)
            return(RET_DBA_ERR_OPTI);
		}


    /* copy all response elements */
    if ((destEsDataPtr->responseESEltTab = (EXT_SERVICE_ELT_STP) CALLOC(srcEsDataPtr->responseESEltNbr, sizeof(EXT_SERVICE_ELT_ST))) == NULL)
        return(RET_DBA_ERR_OPTI);

    destEsDataPtr->responseESEltNbr = srcEsDataPtr->responseESEltNbr;

    for (responseEltIdx=0; responseEltIdx < srcEsDataPtr->responseESEltNbr; responseEltIdx++)
			{
        optiResponseEltPtr = &(destEsDataPtr->responseESEltTab[responseEltIdx]);
        srcResponseEltPtr = &(srcEsDataPtr->responseESEltTab[responseEltIdx]);

        if (ESRV_CopyEsElt(optiResponseEltPtr, srcResponseEltPtr, TRUE) != RET_SUCCEED)
            return(RET_DBA_ERR_OPTI);
			}

    return(RET_SUCCEED);
}

/************************************************************************
*
*  Function          : ESRV_CopyEsElt
*
*  Description       : Copy external service element data.
*
*  Arguments         :
*
*  Return            : RET_CODE
*
*  Creation date     : PMSTA-22496 - DDV - 160621
*
*  Last modification :
*
*************************************************************************/
STATIC RET_CODE ESRV_CopyEsElt(EXT_SERVICE_ELT_STP destEsEltPtr,
                               EXT_SERVICE_ELT_STP srcEsEltPtr,
                               FLAG_T srcOnlyFlg)
{
    int                    recIdx, srcDataNbr, *optiDataNbrPtr;
    DBA_DYNFLD_STP         *srcDataTab = NULLDYNSTPTR;
    DBA_DYNFLD_STP         **optiDataTabPtr = NULLDYNSTPTR;
    DBA_DYNST_ENUM         dynStEnum;

    destEsEltPtr->sourceDynStEnum = srcEsEltPtr->sourceDynStEnum;
    destEsEltPtr->targetDynStEnum = srcEsEltPtr->targetDynStEnum;

    if (srcOnlyFlg == TRUE || srcEsEltPtr->targetDynStEnum == NullDynSt)
    {
        dynStEnum = srcEsEltPtr->sourceDynStEnum;
        srcDataTab = srcEsEltPtr->sourceDataTab;
        srcDataNbr = srcEsEltPtr->sourceDataNbr;
        optiDataTabPtr = &(destEsEltPtr->sourceDataTab);
        optiDataNbrPtr = &(destEsEltPtr->sourceDataNbr);
			}
    else
    {
        dynStEnum = srcEsEltPtr->targetDynStEnum;
        srcDataTab = srcEsEltPtr->targetDataTab;
        srcDataNbr = srcEsEltPtr->targetDataNbr;
        optiDataTabPtr = &(destEsEltPtr->targetDataTab);
        optiDataNbrPtr = &(destEsEltPtr->targetDataNbr);
		}

    *optiDataNbrPtr=0;

    if (srcDataNbr > 0)
		{
        if ((*optiDataTabPtr = (DBA_DYNFLD_STP *) CALLOC(srcDataNbr, sizeof(DBA_DYNFLD_STP))) == NULL)
            return(RET_DBA_ERR_OPTI);

        for (recIdx=0; recIdx < srcDataNbr; recIdx++)
		{
            if (((*optiDataTabPtr)[recIdx] = ALLOC_DYNST(dynStEnum)) == NULLDYNST)
                return(RET_DBA_ERR_OPTI);

            (*optiDataNbrPtr)++;
            COPY_DYNST((*optiDataTabPtr)[recIdx], srcDataTab[recIdx], dynStEnum);
		}
	}

    return(RET_SUCCEED);
}

/*************************************************************************
*
*  Function          : ESRV_FreeOpti
*
*  Description       : Free dedicated cache for external services calls
*
*  Arguments         :
*
*  Return            : RET_CODE
*
*  Creation date     : PMSTA-22496 - DDV - 160621
*
*  Last modification :
*
*************************************************************************/
void ESRV_FreeOpti()
{
    ESRV_OPTIHEAD_STP      eSRVOptiHeadPtr = NULL;
    ESRV_OPTI_STP          eSRVOptiPtr = NULL;
    int                    optiTabIdx, optiIdx, requestEltIdx, responseEltIdx;
    EXT_SERVICE_DATA_STP   optiEsDataPtr = NULL;
    EXT_SERVICE_ELT_STP    optiRequestEltPtr = NULL;
    EXT_SERVICE_ELT_STP    optiResponseEltPtr = NULL;

    if ((eSRVOptiHeadPtr = (ESRV_OPTIHEAD_STP) DBA_GetESRVOptiHeadPtr()) != NULL)
	{
        for (optiTabIdx = 0; optiTabIdx < eSRVOptiHeadPtr->eSRVOptiTabNbr; optiTabIdx++)
		{
            if ((eSRVOptiPtr = eSRVOptiHeadPtr->eSRVOptiTabTab[optiTabIdx]) == NULL)
                continue;

            for (optiIdx=0; optiIdx < eSRVOptiPtr->esDataNbr; optiIdx++)
			{
                if ((optiEsDataPtr = eSRVOptiPtr->esDataTab[optiIdx]) == NULL)
                    continue;

                if (optiEsDataPtr->esFreeFlg == TRUE)
				{
                    FREE_DYNST(optiEsDataPtr->esPtr, A_ExtService);
                }

                for (requestEltIdx=0; requestEltIdx < optiEsDataPtr->requestESEltNbr; requestEltIdx++)
					{
                    optiRequestEltPtr = &(optiEsDataPtr->requestESEltTab[requestEltIdx]);

                    if (optiRequestEltPtr->sourceDynStEnum != NullDynSt)
			{
                        DBA_FreeDynStTab(optiRequestEltPtr->sourceDataTab,
                                         optiRequestEltPtr->sourceDataNbr,
                                         optiRequestEltPtr->sourceDynStEnum);
			}

                    if (optiRequestEltPtr->targetDynStEnum != NullDynSt)
			{
                        DBA_FreeDynStTab(optiRequestEltPtr->targetDataTab,
                                         optiRequestEltPtr->targetDataNbr,
                                         optiRequestEltPtr->targetDynStEnum);
		}

                    FREE_DYNST(optiRequestEltPtr->esCompoStp, A_ExtServiceCompo);

                }
                FREE(optiEsDataPtr->requestESEltTab);

                for (responseEltIdx=0; responseEltIdx < optiEsDataPtr->responseESEltNbr; responseEltIdx++)
	{
                    optiResponseEltPtr = &(optiEsDataPtr->responseESEltTab[responseEltIdx]);

                    if (optiResponseEltPtr->sourceDynStEnum != NullDynSt)
			{
                        DBA_FreeDynStTab(optiResponseEltPtr->sourceDataTab,
                                         optiResponseEltPtr->sourceDataNbr,
                                         optiResponseEltPtr->sourceDynStEnum);
			}

                    if (optiResponseEltPtr->targetDynStEnum != NullDynSt)
				{
                        DBA_FreeDynStTab(optiResponseEltPtr->targetDataTab,
                                         optiResponseEltPtr->targetDataNbr,
                                         optiResponseEltPtr->targetDynStEnum);
					}

                    FREE_DYNST(optiResponseEltPtr->esCompoStp, A_ExtServiceCompo);
				}
                FREE(optiEsDataPtr->responseESEltTab);
                FREE(optiEsDataPtr);
			}
            FREE(eSRVOptiPtr->esDataTab);
            FREE(eSRVOptiPtr);
		}
        FREE(eSRVOptiHeadPtr->eSRVOptiTabTab)
        FREE(eSRVOptiHeadPtr);
	}
    return;
}

/*************************************************************************
*
*  Function          : ESRV_RestructureData
*
*  Description       : Rebuilds Es Data with only valid request elements
*
*  Arguments         :
*
*  Return            : RET_CODE
*
*  Creation date     : PMSTA-29906 -NRAO - 180215
*
*  Last modification :
*
*************************************************************************/
STATIC RET_CODE ESRV_RestructureData(EXT_SERVICE_DATA_STP esDataPtr,
	                                 EXT_SERVICE_DATA_STP *filteredESDataPtr,
	                                 int* filteredReqRows,
	                                 int filteredReqCount)
{
	RET_CODE ret = RET_SUCCEED;

    /*PMSTA-34129-NRAO-181214 */
    if (filteredReqCount <= 0)
    {
        /*Do nothing if filtered request count is zero*/
        return (RET_GEN_INFO_NOACTION);
    }

	if (filteredReqCount < esDataPtr->requestESEltNbr)
	{
		int                    requestEltIdx, responseEltIdx;
		EXT_SERVICE_ELT_STP    restructuredRequestEltPtr = NULL, srcRequestEltPtr = NULL;
		EXT_SERVICE_ELT_STP    restructuredResponseEltPtr = NULL, srcReqsponseEltPtr = NULL;

		if (filteredESDataPtr == NULL)
		{
			MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "ESRV_CreateESData", "restructuredESDataPtr");
			return(RET_GEN_ERR_INVARG);
		}

		if ((*(filteredESDataPtr) = (EXT_SERVICE_DATA_STP)CALLOC(1, sizeof(EXT_SERVICE_DATA_ST))) == NULL)
		{
			MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "EXT_SERVICE_DATA_STP");
			return(RET_MEM_ERR_ALLOC);
		}

		if (((*filteredESDataPtr)->requestESEltTab = (EXT_SERVICE_ELT_STP)CALLOC(filteredReqCount, sizeof(EXT_SERVICE_ELT_ST))) == NULL)
		{
			MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "EXT_SERVICE_ELT_STP");
			ESRV_FreeEServiceData(filteredESDataPtr);
			return(RET_MEM_ERR_ALLOC);
		}

		if (((*filteredESDataPtr)->responseESEltTab = (EXT_SERVICE_ELT_STP)CALLOC(esDataPtr->responseESEltNbr, sizeof(EXT_SERVICE_ELT_ST))) == NULL)
		{
			MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "EXT_SERVICE_ELT_STP");
			ESRV_FreeEServiceData(filteredESDataPtr);
			return(RET_MEM_ERR_ALLOC);
		}

		if (((*filteredESDataPtr)->esPtr = ALLOC_DYNST(A_ExtService)) == NULLDYNST)
		{
			ESRV_FreeEServiceData(filteredESDataPtr);
			return(RET_MEM_ERR_ALLOC);
		}

/*		(*filteredESDataPtr)->extSvcTraceFileSt = esDataPtr->extSvcTraceFileSt;  //check this */
        /* PMSTA-34525 - DDV - 190129 - Copy string to avoid crash due to double free of the same pointer */
        /* PMSTA-34571 - CHU - 190201 - If traces disabled, the pointer is NULL */
        if (NULL != esDataPtr->extSvcTraceFileSt.extSvcTraceFilename)
        {
            if (((*filteredESDataPtr)->extSvcTraceFileSt.extSvcTraceFilename = (char *)CALLOC(strlen(esDataPtr->extSvcTraceFileSt.extSvcTraceFilename) + 1, sizeof(char))) != NULL)
            {
                strcpy((*filteredESDataPtr)->extSvcTraceFileSt.extSvcTraceFilename, esDataPtr->extSvcTraceFileSt.extSvcTraceFilename);
            }
        }
        (*filteredESDataPtr)->extSvcTraceFileSt.extSvcTraceStatus = esDataPtr->extSvcTraceFileSt.extSvcTraceStatus;

		COPY_DYNST((*filteredESDataPtr)->esPtr, esDataPtr->esPtr, A_ExtService);
		(*filteredESDataPtr)->esFreeFlg = esDataPtr->esFreeFlg;
		(*filteredESDataPtr)->requestESEltNbr = filteredReqCount;
		(*filteredESDataPtr)->responseESEltNbr = esDataPtr->responseESEltNbr;

		/*Fill new ES Data ptr with valid request elements */
		for (requestEltIdx = 0; requestEltIdx < (*filteredESDataPtr)->requestESEltNbr; requestEltIdx++)
		{
			(*filteredESDataPtr)->requestESEltTab[requestEltIdx].sourceObjectEnum = esDataPtr->requestESEltTab[filteredReqRows[requestEltIdx]].sourceObjectEnum;
			(*filteredESDataPtr)->requestESEltTab[requestEltIdx].sourceDynStEnum = esDataPtr->requestESEltTab[filteredReqRows[requestEltIdx]].sourceDynStEnum;

			(*filteredESDataPtr)->requestESEltTab[requestEltIdx].targetObjectEnum = esDataPtr->requestESEltTab[filteredReqRows[requestEltIdx]].targetObjectEnum;
			(*filteredESDataPtr)->requestESEltTab[requestEltIdx].targetDynStEnum = esDataPtr->requestESEltTab[filteredReqRows[requestEltIdx]].targetDynStEnum;

			if (((*filteredESDataPtr)->requestESEltTab[requestEltIdx].esCompoStp = ALLOC_DYNST(A_ExtServiceCompo)) == NULLDYNST)
			{
				ESRV_FreeEServiceData(filteredESDataPtr);
				return(RET_MEM_ERR_ALLOC);

			}
			COPY_DYNST((*filteredESDataPtr)->requestESEltTab[requestEltIdx].esCompoStp, esDataPtr->requestESEltTab[filteredReqRows[requestEltIdx]].esCompoStp, A_ExtServiceCompo);

			restructuredRequestEltPtr = &((*filteredESDataPtr)->requestESEltTab[requestEltIdx]);  //dest
			srcRequestEltPtr = &(esDataPtr->requestESEltTab[filteredReqRows[requestEltIdx]]); //src

			if (ESRV_CopyEsElt(restructuredRequestEltPtr, srcRequestEltPtr, TRUE) != RET_SUCCEED)
			{
				ESRV_FreeEServiceData(filteredESDataPtr);
				return ret;
			}

			if (ESRV_CopyEsElt(restructuredRequestEltPtr, srcRequestEltPtr, FALSE) != RET_SUCCEED)
			{
				ESRV_FreeEServiceData(filteredESDataPtr);
				return ret;
			}
		}

		/*Fill new ES Data ptr with all response elements */
		for (responseEltIdx = 0; responseEltIdx < (*filteredESDataPtr)->responseESEltNbr; responseEltIdx++)
		{
			(*filteredESDataPtr)->responseESEltTab[responseEltIdx].sourceObjectEnum = esDataPtr->responseESEltTab[responseEltIdx].sourceObjectEnum;
			(*filteredESDataPtr)->responseESEltTab[responseEltIdx].sourceDynStEnum = esDataPtr->responseESEltTab[responseEltIdx].sourceDynStEnum;

			(*filteredESDataPtr)->responseESEltTab[responseEltIdx].targetObjectEnum = esDataPtr->responseESEltTab[responseEltIdx].targetObjectEnum;
			(*filteredESDataPtr)->responseESEltTab[responseEltIdx].targetDynStEnum = esDataPtr->responseESEltTab[responseEltIdx].targetDynStEnum;

			if (((*filteredESDataPtr)->responseESEltTab[responseEltIdx].esCompoStp = ALLOC_DYNST(A_ExtServiceCompo)) == NULLDYNST)
			{
				ESRV_FreeEServiceData(filteredESDataPtr);
				return(RET_MEM_ERR_ALLOC);
			}
			COPY_DYNST((*filteredESDataPtr)->responseESEltTab[responseEltIdx].esCompoStp, esDataPtr->responseESEltTab[responseEltIdx].esCompoStp, A_ExtServiceCompo);

			restructuredResponseEltPtr = &((*filteredESDataPtr)->responseESEltTab[responseEltIdx]);  //dest
			srcReqsponseEltPtr = &(esDataPtr->responseESEltTab[responseEltIdx]); //src

			if (ESRV_CopyEsElt(restructuredResponseEltPtr, srcReqsponseEltPtr, TRUE) != RET_SUCCEED)
			{
				ESRV_FreeEServiceData(filteredESDataPtr);
				return ret;
			}
			if (ESRV_CopyEsElt(restructuredResponseEltPtr, srcReqsponseEltPtr, FALSE) != RET_SUCCEED)
			{
				ESRV_FreeEServiceData(filteredESDataPtr);
				return ret;
			}
		}

	}
	return ret;
}
/************************************************************************
*
*   Function      :   FIN_FilterExtOpByPtfId()
*
*   Description : Filter ExtOp's that are matching with the current portfolio_id
*                 return TRUE->record must be extract
*                 FALSE->record musn't be extract
*
*   Arguments : dynSt    element pointer
*               dynStTp  element description enum
*
*   Return : TRUE or FALSE
*
*   Creation : PMSTA-37528 - kramadevi - 11102019
*
*************************************************************************/
STATIC int FIN_FilterExtOpByPtfId(DBA_DYNFLD_STP   extOpStp,
                                  DBA_DYNST_ENUM   dynStTp,
                                  DBA_DYNFLD_STP   ptfSt)
{
    if(CMP_ID(GET_ID(extOpStp, ExtOp_PtfId), GET_ID(ptfSt, A_Ptf_Id)) == 0)
        return(TRUE);

    return(FALSE);
}


/***************************************************************************************
**
**  Function    :   FIN_CreateCaseForExtSErviceFailure()
**
**  Description :   Create a case for external service adapter failure
**
**  Argument    :   domainPtr
**                  hierHead
**                  extServiceStp
**
**  Return      :   RET_SUCCEED or return code
**
**  creation    :   PMSTA-39985 -NRAO -28-APR-2020
**
***************************************************************************************/
RET_CODE FIN_CreateCaseForExtSErviceFailure(DBA_DYNFLD_STP         extServiceStp,
	DBA_HIER_HEAD_STP        hierHead,
	DBA_DYNFLD_STP           domainPtr)
{
	RET_CODE                        ret = RET_SUCCEED;
	DBA_DYNFLD_STP                  casePtr = NULLDYNST;
	DICT_T                          entityDictId;

	if (IS_NULLFLD(extServiceStp, A_ExtService_CaseGenFlg) == TRUE ||
		GET_FLAG(extServiceStp, A_ExtService_CaseGenFlg) == FALSE)
	{
		return(ret);
	}

	if ((casePtr = ALLOC_DYNST(A_CaseManagement)) == NULLDYNST)
	{
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "Case");
		return(RET_MEM_ERR_ALLOC);
	}

	DBA_SetDfltEntityFld(CaseManagement, A_CaseManagement, casePtr);

	SET_ENUM(casePtr, A_CaseManagement_NatEn, CaseManagementNat_ExtServiceFailOver);
	SET_ENUM(casePtr, A_CaseManagement_SubNatEn, CaseManagementSubNat_None);

	if (IS_NULLFLD(extServiceStp, A_ExtService_CaseCriticalnessEn) == FALSE)
	{
		COPY_DYNFLD(casePtr, A_CaseManagement, A_CaseManagement_CriticalnessEn,
			extServiceStp, A_ExtService, A_ExtService_CaseCriticalnessEn);
	}

	if (IS_NULLFLD(domainPtr, A_Domain_FctResultId) == FALSE)
	{
		COPY_DYNFLD(casePtr, A_CaseManagement, A_CaseManagement_SessionId,
			domainPtr, A_Domain, A_Domain_FctResultId);
	}

	DBA_GetDictId(FctResult, &entityDictId);
	SET_DICT(casePtr, A_CaseManagement_MainEntityDictId, entityDictId);

	SET_ID(casePtr, A_CaseManagement_MainObjId, GET_ID(domainPtr, A_Domain_FctResultId));

	if ((ret = DBA_AddHierRecord(hierHead, casePtr, A_CaseManagement,
		TRUE, HierAddRec_NoLnk)) != RET_SUCCEED)
	{
		FREE_DYNST(casePtr, A_CaseManagement);
		return(ret);
	}

	if (IS_NULLFLD(casePtr, A_CaseManagement_MainObjId) == FALSE)
	{
		if ((ret = FIN_AddCaseLinkedObject(domainPtr, hierHead, casePtr,
			entityDictId, GET_ID(casePtr, A_CaseManagement_MainObjId))) != RET_SUCCEED)
		{
			return(ret);
		}
	}

	FLAG_T	*scptFlagTab = NULL;
	if ((scptFlagTab = (FLAG_T *)CALLOC(GET_FLD_NBR(A_CaseManagement), sizeof(FLAG_T))) == NULL)
	{
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ScriptFlag");
		return(RET_MEM_ERR_ALLOC);
	}

	scptFlagTab[A_CaseManagement_NatEn] = TRUE;
	scptFlagTab[A_CaseManagement_SubNatEn] = TRUE;
	scptFlagTab[A_CaseManagement_PtfId] = TRUE;
	scptFlagTab[A_CaseManagement_InstrId] = TRUE;
	scptFlagTab[A_CaseManagement_SessionId] = TRUE;
	scptFlagTab[A_CaseManagement_CriticalnessEn] = TRUE;
	scptFlagTab[A_CaseManagement_MainEntityDictId] = TRUE;
	scptFlagTab[A_CaseManagement_MainObjId] = TRUE;
	scptFlagTab[A_CaseManagement_StatusEn] = TRUE;

	if (IS_NULLFLD(casePtr, A_CaseManagement_Cd) == TRUE)
	{
		DBA_MakeSpecRecordLinks(hierHead, A_CaseManagement, A_CaseManagement_A_CaseLink_Ext, casePtr);
		scptFlagTab[A_CaseManagement_Cd] = FALSE;
		scptFlagTab[A_CaseManagement_Description] = FALSE;

		if (SCPT_ComputeScreenDV(CaseManagement,
			DictFct_0,
			scptFlagTab,
			NULL,
			casePtr,
			NULLDYNST,
			domainPtr,
			NULLDYNST,
			TRUE,
			TRUE,
			EvalType_DefValAndFilter,
			-1,
			NULL,
			NULL,
			hierHead,
			0,
			NullEntity,
			NULL,
			NULL,
			NULL,
			NULL,
			NULL,
			NullEntity,
			FALSE,
			FALSE,
			0) != 0)
		{
			MSG_SendMesg(RET_SCPT_ERR_SYNTAX, 0, FILEINFO);
		}
	}

	FREE(scptFlagTab);
	return ret;
}

/***************************************************************************************
**
**  Function    :   FIN_DelCaseMgtRecordByNature()
**
**  Description :   Delete case management record/s
**
**  Argument    :   domainPtr
**
**  Return      :   RET_SUCCEED or return code
**
**  creation    :   PMSTA-39985-NRAO -28-APR-2020
**
***************************************************************************************/
RET_CODE FIN_DelCaseMgtRecordByNature(DBA_DYNFLD_STP domainPtr, ENUM_T caseMgtNatEn)
{
	RET_CODE                    delRet = RET_SUCCEED;

	DbiConnectionHelper dbiConnHelper;
	if (dbiConnHelper.isValidAndInit() == false)
	{
		MSG_DispMesg(RET_DBA_ERR_CONNOTFOUND, NULL, NULL);
		return delRet;
	}

	MemoryPool mp;
	DBA_DYNFLD_STP shCasemgmtstp = mp.allocDynst(FILEINFO, S_CaseManagement);
	SET_ENUM(shCasemgmtstp, S_CaseManagement_NatEn, caseMgtNatEn);
	SET_ID(shCasemgmtstp, S_CaseManagement_SessionId, GET_ID(domainPtr, A_Domain_FctResultId));

	/*del_case_management_by_sid*/
	delRet = dbiConnHelper.dbaDelete(CaseManagement, UNUSED, shCasemgmtstp);

	return delRet;
}

/***************************************************************************************
**
**  Function    :   resolveEnvVariableToValueInURL()
**
**  Description :   convert the relative url into absolute
**
**  Argument    :   url 
**
**  Return      :   true or false
**
**  creation    :   WEALTH-16486
**
***************************************************************************************/
bool resolveEnvVariableToValueInURL(std::string& url)
{
    bool ret = true;
    std::string envVar;
    const std::string prefix("${");
    const std::string suffix("}");
    size_t start = url.find(prefix);
    if (start != std::string::npos)
    {
        size_t end = url.find(suffix, start); // search after the first brace
        if (end != std::string::npos)
        {
            envVar = url.substr(start + prefix.length(), end - start - prefix.length());

            if (envVar.size() > 0)
            {
                std::string envVarValue = SYS_GetEnvStringOrDefValue(envVar.c_str(), "");

                /* if still empty, then flag as error*/
                if (envVarValue.empty())
                {
                    ret = false;
                }
                url.replace(start, end + suffix.length() - start, envVarValue);
            }
        }
    }
    return ret;
}

/************************************************************************
      END  eservice.c                                               OAMS
*************************************************************************/

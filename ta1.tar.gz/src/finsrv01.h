/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef FINSRV01_H
#define FINSRV01_H

/************************************************************************
**      BEGIN : Global definitions attached to finsrv01.c
*************************************************************************/
#ifdef  EXTERN
#undef  EXTERN
#endif
#ifdef  FINSRV01_C
#define	EXTERN
#else
#define EXTERN extern
#endif

EXTERN RET_CODE FIN_AnalysisJournal(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP),
                FIN_JournalProcess(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, HIER_FLTFCT *); /* REF7264 - DDV - 020325 - Compil C++ */

EXTERN RET_CODE FIN_ReplOldFctResult(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP*),	/* PMSTA06761 - RAK - 080805 */
				FIN_ComputeNewFctResult(DBA_DYNFLD_STP, DBA_DYNFLD_STP*),
				FIN_DeleteFctResult(DBA_DYNFLD_STP, DBA_DYNFLD_STP),
				FIN_DeleteAllFctResult(DBA_DYNFLD_STP, DBA_DYNFLD_STP);
EXTERN RET_CODE FIN_GenerateStandInstruct(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP*, int, DBA_DYNFLD_STP *);

EXTERN RET_CODE FIN_EditDomainPtfCompo(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP);		/* PMSTA-21256 - chandrak - 151006 */
#endif /* FINSRV01_H */


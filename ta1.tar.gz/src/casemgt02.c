/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define CASEMGT02_C

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H
#define MATH_H

#include "unidef.h"     /* Mandatory */
#include "gen.h"
#include "date.h"
#include "dba.h"
#include "syslib.h"
#include "tls.h"
#include "hier.h"
#include "fin.h"
#include "scptyl.h"
#include "scelib.h"
#include "casemgt.h"
#include "finlib04.h"

/************************************************************************
**      External entry points
**
**  FIN_CreateObjectiveMarginCase()	Generate Cases from Objective Margin violations.
**
*************************************************************************/

/************************************************************************
**      Local functions
**
**
**
*************************************************************************/

/************************************************************************
**      Static definitions & data
*************************************************************************/


/**** INTERNAL STRUCTURES ****/

/************************************************************************
**      Functions
*************************************************************************/

/************************************************************************
**
**  Function    : FIN_IsOrdinate()
**
**  Description : ignore ordinate only market segments for CMC.
**
**  Arguments   : sMktSegtSt :    (short) market segment pointer
**
**  Return      : RET_SUCCEED or error code
**
**  Creation    : PMSTA08425-CHU-090728
**
*************************************************************************/
STATIC FLAG_T FIN_IsOrdinate(DBA_DYNFLD_STP      sMktSegtSt)
{
    if (sMktSegtSt != NULLDYNST &&
        IS_NULLFLD(sMktSegtSt, S_MktSegt_AbcissaListId) == TRUE &&    /* totaliser of a 1D grid */
        IS_NULLFLD(sMktSegtSt, S_MktSegt_OrdinateListId) == FALSE)
    {
        return (TRUE);
    }

    return (FALSE);
}

/***************************************************************************************
**
**  Function    :   FIN_IsOrdinateESE()
**
**  Description :   Check if current ESE is an ordinate only (no Case to be created)
**
**  Arguments   :   esePtr    element pointer
**
**  Return      :   TRUE or FALSE
**
**  creation	:   PMSTA08413-CHU-090721
**
**  Last modif. :
**
**
***************************************************************************************/
STATIC FLAG_T FIN_IsOrdinateESE(DBA_HIER_HEAD_STP	hierHead,
								 DBA_DYNFLD_STP		esePtr)
{
	DBA_DYNFLD_STP  sMktSgtSt=NULL;

	if (DBA_GetRecPtrFromHierById(hierHead,
		GET_ID(esePtr, ExtStratElt_MktSegtId),
		S_MktSegt, &sMktSgtSt) != RET_SUCCEED)
	{
		return(FALSE);
	}

	return(FIN_IsOrdinate(sMktSgtSt));
}

/************************************************************************
**
**  Function    :   FIN_CmpESEPtfId()
**
**  Description :   Sort ESE by portfolio identifier
**
**  Arguments   :   ptr1   pointer on dynamic structure type ExtStratElt
**                  ptr2   pointer on dynamic structure type ExtStratElt
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation    : PMSTA07121-CHU-081013
**
*************************************************************************/
STATIC int FIN_CmpESEPtfId(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
	return(CMP_ID(GET_ID((*ptr1), ExtStratElt_PtfId) , GET_ID((*ptr2), ExtStratElt_PtfId)));
}

/***************************************************************************************
**
**  Function    :   FIN_CreateCaseFromESE()
**
**  Description :   Complete Case Data from ESE
**
**  Argument    :   domainPtr
**                  hierHead
**					esePtr
**
**  Return      :   RET_SUCCEED or return code
**
**  creation	:   PMSTA07121-CHU-081013
**
**  Last modif. :   PMSTA-17133 - 051113 - PMO : Many compilation warnings in C code especially " Converting a 64-bit type value to "int" causes truncation."
**
***************************************************************************************/
RET_CODE FIN_CreateCaseFromESE(DBA_DYNFLD_STP		domainPtr,
							   DBA_HIER_HEAD_STP	hierHead,
							   DBA_DYNFLD_STP		esePtr,
							   DBA_DYNFLD_STP		ptfPtr)
{
	RET_CODE			ret = RET_SUCCEED;
	DBA_DYNFLD_STP		casePtr = NULLDYNST;
	STRATNAT_ENUM		stratNatEn;
	DICT_T				entityDictId;

	if((casePtr = ALLOC_DYNST(A_CaseManagement)) == NULLDYNST)
	{
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "Case");
		return(RET_MEM_ERR_ALLOC);
	}

	DBA_SetDfltEntityFld(CaseManagement, A_CaseManagement, casePtr);

	stratNatEn = (STRATNAT_ENUM)GET_ENUM(esePtr, ExtStratElt_StratNatEn);

	/* PMSTA - 39192 - VMU - 17032020 : Added Check For Case Management Nature - Strategy Investment Check */
	if ((IS_NULLFLD(esePtr, ExtStratElt_InvestCheckEn) == FALSE) &&
	   (GET_ENUM(esePtr, ExtStratElt_InvestCheckEn) == (ENUM_T)StratCheck_NotChecked))
	{
		SET_ENUM(casePtr, A_CaseManagement_NatEn, CaseManagementNat_StrategyInvestmentCheck);
	}
	else
	{
		SET_ENUM(casePtr, A_CaseManagement_NatEn, CaseManagementNat_Strategy);
	}

	switch(stratNatEn)
	{
	case StratNat_Alloc :
		SET_ENUM(casePtr, A_CaseManagement_SubNatEn, CaseManagementSubNat_Allocation);
		break;

	case StratNat_ModelPtf:
		SET_ENUM(casePtr, A_CaseManagement_SubNatEn, CaseManagementSubNat_ModelPtf);
		break;

    default:
        break;
    }

	if (IS_NULLFLD(esePtr, ExtStratElt_ChildPtfId) == FALSE)
	{
		COPY_DYNFLD(casePtr, A_CaseManagement, A_CaseManagement_PtfId,
					esePtr,  ExtStratElt, ExtStratElt_ChildPtfId);
	}
    else if (GET_FLAG(ptfPtr, A_Ptf_OverlayFlg) == TRUE  &&
                LOADHIERPTF_ENUM::LoadHierPtf_None != static_cast<LOADHIERPTF_ENUM>(GET_ENUM(domainPtr, A_Domain_LoadHierFlg)))
    {
        /*overlay case*/
        if (IS_NULLFLD(esePtr, ExtStratElt_OverlayPtfId) == FALSE)
        {
            COPY_DYNFLD(casePtr, A_CaseManagement, A_CaseManagement_PtfId,
                esePtr, ExtStratElt, ExtStratElt_OverlayPtfId);
        }
        else
        {
            DBA_DYNFLD_STP		parEsePtr = esePtr, parEseDel= NULLDYNST;

            /*if overlay ptf is null then get parent ese*/
            while (IS_NULLFLD(parEsePtr, ExtStratElt_LnkPar_ExtStratElt_Ext) == FALSE)
            {
                if (GET_EXTENSION_PTR(parEsePtr, ExtStratElt_LnkPar_ExtStratElt_Ext) != NULL &&
                    (parEseDel = *(GET_EXTENSION_PTR(parEsePtr, ExtStratElt_LnkPar_ExtStratElt_Ext))) != NULLDYNST)
                {
                    if (IS_NULLFLD(parEseDel, ExtStratElt_OverlayPtfId) == FALSE)
                    {
                        COPY_DYNFLD(casePtr, A_CaseManagement, A_CaseManagement_PtfId,
                            parEseDel, ExtStratElt, ExtStratElt_OverlayPtfId);
                        break;
                    }
                }
                else
                    break;
                parEsePtr = parEseDel;
            }

            if (IS_NULLFLD(casePtr, A_CaseManagement_PtfId) == TRUE && 
                IS_NULLFLD(esePtr, ExtStratElt_PtfId) == FALSE)
            {
                /*if still not set then set as head ptf*/
                COPY_DYNFLD(casePtr, A_CaseManagement, A_CaseManagement_PtfId,
                    parEseDel, ExtStratElt, ExtStratElt_PtfId);
            }
        }
    }
    else if (IS_NULLFLD(esePtr, ExtStratElt_PtfId) == FALSE)
	{
		COPY_DYNFLD(casePtr, A_CaseManagement, A_CaseManagement_PtfId,
					esePtr,  ExtStratElt, ExtStratElt_PtfId);
	}

	COPY_DYNFLD(casePtr, A_CaseManagement, A_CaseManagement_ParentPortId,		/*WEALTH-7147-Satya*/
		esePtr, ExtStratElt, ExtStratElt_PtfId);

	if (IS_NULLFLD(esePtr, ExtStratElt_InstrId) == FALSE)
	{
		COPY_DYNFLD(casePtr, A_CaseManagement, A_CaseManagement_InstrId,
					esePtr,  ExtStratElt, ExtStratElt_InstrId);
	}

	if (IS_NULLFLD(domainPtr, A_Domain_FctResultId) == FALSE)
	{
		COPY_DYNFLD(casePtr,	A_CaseManagement,	A_CaseManagement_SessionId,
			        domainPtr,	A_Domain,			A_Domain_FctResultId);
	}
	/*Load hierarchy population from domain flag*/
	COPY_DYNFLD(casePtr, A_CaseManagement, A_CaseManagement_LoadHierFlg,
		domainPtr, A_Domain, A_Domain_LoadHierFlg);

	if (IS_NULLFLD(esePtr, ExtStratElt_CriticalnessEn) == FALSE)
	{
		COPY_DYNFLD(casePtr, A_CaseManagement, A_CaseManagement_CriticalnessEn,
					esePtr,  ExtStratElt, ExtStratElt_CriticalnessEn);
	}

	DBA_GetDictId(FctResult, &entityDictId);
	SET_DICT(casePtr, A_CaseManagement_MainEntityDictId, entityDictId);

	SET_ID(casePtr,	 A_CaseManagement_MainObjId, GET_ID(domainPtr, A_Domain_FctResultId));

	if ((ret = DBA_AddHierRecord(hierHead, casePtr, A_CaseManagement,
								 TRUE, HierAddRec_NoLnk)) != RET_SUCCEED)
	{
		FREE_DYNST(casePtr, A_CaseManagement);
		return(ret);    /* PMSTA-17133 - 051113 - PMO */
	}

	/* Add Portfolio to Case Linked Objects */
	if (IS_NULLFLD(casePtr, A_CaseManagement_PtfId) == FALSE)
	{
		DBA_GetDictId(Ptf, &entityDictId);
		if((ret = FIN_AddCaseLinkedObject(domainPtr, hierHead, casePtr,
										  entityDictId, GET_ID(casePtr, A_CaseManagement_PtfId))) != RET_SUCCEED)
		{
			return(ret);
		}
	}

	/* Add Instrument to Case Linked Objects */
	if (IS_NULLFLD(casePtr, A_CaseManagement_InstrId) == FALSE)
	{
		DBA_GetDictId(Instr, &entityDictId);
		if((ret = FIN_AddCaseLinkedObject(domainPtr, hierHead, casePtr,
										  entityDictId, GET_ID(casePtr, A_CaseManagement_InstrId))) != RET_SUCCEED)
		{
			return(ret);
		}
	}

	/* Add Strategy to Case Linked Objects */
	DBA_GetDictId(Strat, &entityDictId);
	if (IS_NULLFLD(esePtr, ExtStratElt_RefStratId) == FALSE)
	{
		if((ret = FIN_AddCaseLinkedObject(domainPtr, hierHead, casePtr,
										  entityDictId, GET_ID(esePtr, ExtStratElt_RefStratId))) != RET_SUCCEED)
		{
			return(ret);
		}
	}
	else
	{
		if (IS_NULLFLD(esePtr, ExtStratElt_StratId) == FALSE)
		{
			if((ret = FIN_AddCaseLinkedObject(domainPtr, hierHead, casePtr,
											  entityDictId, GET_ID(esePtr, ExtStratElt_StratId))) != RET_SUCCEED)
			{
				return(ret);
			}
		}
	}

	/* Add Market Segment to Case Linked Objects */
	if (IS_NULLFLD(esePtr, ExtStratElt_MktSegtId) == FALSE)
	{
		DBA_GetDictId(MktSegt, &entityDictId);
		if((ret = FIN_AddCaseLinkedObject(domainPtr, hierHead, casePtr,
										  entityDictId, GET_ID(esePtr, ExtStratElt_MktSegtId))) != RET_SUCCEED)
		{
			return(ret);
		}
	}

	/* Add Grid to Case Linked Objects */
	if (IS_NULLFLD(esePtr, ExtStratElt_GridId) == FALSE)
	{
		DBA_GetDictId(Grid, &entityDictId);
		if((ret = FIN_AddCaseLinkedObject(domainPtr, hierHead, casePtr,
										  entityDictId, GET_ID(esePtr, ExtStratElt_GridId))) != RET_SUCCEED)
		{
			return(ret);
		}
	}

	/* Also add current ESE to Case Linked Objects */
	DBA_GetDictId(EStratElt, &entityDictId);
	if((ret = FIN_AddCaseLinkedObject(domainPtr, hierHead, casePtr,
									  entityDictId, GET_ID(esePtr, ExtStratElt_Id))) != RET_SUCCEED)
	{
		return(ret);
	}

	return(ret);
}

/************************************************************************
*
*   Function      :   FIN_FilterNotCheckedESE()
*
*   Description   :
*
*   Arguments     :   dynSt    element pointer
*                     dynStTp  element description enum
*
*   Return        :   TRUE or FALSE
*
*   Creation      :   PMSTA09284-CHU-100204
*
*************************************************************************/
STATIC int FIN_FilterNotCheckedESE(DBA_DYNFLD_STP esePtr, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP ptfPtr)
{
	/* REF3641 - strat focus elements need same treatment than reconcil elements */
	if (GET_ID(esePtr, ExtStratElt_PtfId) == GET_ID(ptfPtr, A_Ptf_Id)
		&&
		(GET_ENUM(esePtr, ExtStratElt_ObjWeightCheckEn) == StratCheck_NotChecked ||
		/* PMSTA08405-CHU-090728 : discard not checked MC - handled by Constraint Breaches
		 GET_ENUM(esePtr, ExtStratElt_MinWeightCheckEn) == StratCheck_NotChecked ||
		 GET_ENUM(esePtr, ExtStratElt_MaxWeightCheckEn) == StratCheck_NotChecked ||
		 */
		 GET_ENUM(esePtr, ExtStratElt_ObjDuraCheckEn)   == StratCheck_NotChecked ||
		 GET_ENUM(esePtr, ExtStratElt_ObjBetaCheckEn)   == StratCheck_NotChecked ||
		 GET_ENUM(esePtr, ExtStratElt_InvestCheckEn)	== StratCheck_NotChecked)
		&&
		GET_ENUM(esePtr, ExtStratElt_CriticalnessEn) > ConstrCriticalness_None  &&
		(GET_ENUM(esePtr, ExtStratElt_StratNatEn) == StratNat_Alloc ||
		 GET_ENUM(esePtr, ExtStratElt_StratNatEn) == StratNat_ModelPtf ||
		 GET_ENUM(esePtr, ExtStratElt_NatEn) == ExtStratEltNat_PtfHead ||
		 GET_ENUM(esePtr, ExtStratElt_NatEn) == ExtStratEltNat_StratIPHead  /* PMSTA-38326 - SPB - 29012020 : Consider Portfolio head record */
		)
		 /* PMSTA08405-CHU-090722 : Create Case on margin violation even if MC exists on same element
		 &&
		IS_NULLFLD(esePtr, ExtStratElt_ModelConstrEltId) == TRUE
		*/
		)
    {
		return(TRUE);
    }
	else
	{
		FLAG_T				allocFlg=FALSE;
		DBA_HIER_HEAD_STP	hierHead=(DBA_HIER_HEAD_STP)DBA_GetHierOptiPtr();
		DBA_DYNFLD_STP		esePtfPtr=NULLDYNST;

		if (IS_NULLFLD(esePtr, ExtStratElt_PtfId) == FALSE && /* avoid a DBA_Get2() on id=0 */
			DBA_GetPtfById(GET_ID(esePtr, ExtStratElt_PtfId), FALSE, &allocFlg,
	                           &esePtfPtr, hierHead, UNUSED, UNUSED) == RET_SUCCEED)
		{
			if (GET_ID(esePtfPtr, A_Ptf_HierPortId) == GET_ID(ptfPtr, A_Ptf_Id)
				&&
				(GET_ENUM(esePtr, ExtStratElt_ObjWeightCheckEn) == StratCheck_NotChecked ||
				/* PMSTA08405-CHU-090728 : discard not checked MC - handled by Constraint Breaches
				 GET_ENUM(esePtr, ExtStratElt_MinWeightCheckEn) == StratCheck_NotChecked ||
				 GET_ENUM(esePtr, ExtStratElt_MaxWeightCheckEn) == StratCheck_NotChecked ||
				 */
				 GET_ENUM(esePtr, ExtStratElt_ObjDuraCheckEn)   == StratCheck_NotChecked ||
				 GET_ENUM(esePtr, ExtStratElt_ObjBetaCheckEn)   == StratCheck_NotChecked ||
				 GET_ENUM(esePtr, ExtStratElt_InvestCheckEn)    == StratCheck_NotChecked)
				&&
				GET_ENUM(esePtr, ExtStratElt_CriticalnessEn) > ConstrCriticalness_None  &&
				(GET_ENUM(esePtr, ExtStratElt_StratNatEn) == StratNat_Alloc ||
				 GET_ENUM(esePtr, ExtStratElt_StratNatEn) == StratNat_ModelPtf ||
				 GET_ENUM(esePtr, ExtStratElt_NatEn) == ExtStratEltNat_PtfHead) /* PMSTA-38326 - SPB - 29012020 : Consider Portfolio head record */
				 /* PMSTA08405-CHU-090722 : Create Case on margin violation even if MC exists on same element
				 &&
				IS_NULLFLD(esePtr, ExtStratElt_ModelConstrEltId) == TRUE
				*/
				)
            {
				if (allocFlg == TRUE) { FREE_DYNST(esePtfPtr, A_Ptf); } /* PMSTA39941 - 02052020 - HLA - If ptf record fetched from DB */
				return(TRUE);
            }
		}

		if (allocFlg == TRUE) { FREE_DYNST(esePtfPtr, A_Ptf);}
	}

    return(FALSE);
}

/***************************************************************************************
**
**  Function    :   FIN_CreateObjectiveMarginCase()
**
**  Description :   Generate Cases from Objective Margin violations
**
**  Argument    :   domainPtr
**                  hearHead
**
**  Return      :   RET_SUCCEED or return code
**
**  creation	:   PMSTA07121-CHU-081013
**
**  Last modif. :
**
***************************************************************************************/
RET_CODE FIN_CreateObjectiveMarginCase(DBA_DYNFLD_STP	domainPtr,
									   PTR				argHierHead,
									   DBA_DYNFLD_STP	ptfPtr)
{
	DBA_HIER_HEAD_STP		hierHead=(DBA_HIER_HEAD_STP)argHierHead;
    DBA_DYNFLD_STP			*extStratEltTab=NULL;
    int						i, extStratEltNbr=0;
    RET_CODE				ret = RET_SUCCEED;
    CONSTRCRITICALNESS_ENUM applStratBlockConstrCriticalness;

    GEN_GetApplInfo(ApplStratBlockConstrCriticalness, &applStratBlockConstrCriticalness);

	/* if this param not set - keep old process : no Case creation */
	if (applStratBlockConstrCriticalness == ConstrCriticalness_None)
		return  (ret);

	/* Extract all ESE with a CheckEn > None and Not_Checked ans a Criticalness > None */
	if ((ret = DBA_ExtractHierEltRecWithFilterSt(hierHead,
                                                  ExtStratElt,
                                                  FALSE,
                                                  FIN_FilterNotCheckedESE,
                                                  ptfPtr,
                                                  FIN_CmpESEPtfId,
                                                  &extStratEltNbr,
                                                  &extStratEltTab)) != RET_SUCCEED)
	{
		return(ret);
	}

	for (i=0; i< extStratEltNbr; i++)
	{
		/* PMSTA07121 - RAK - 090430 - Don't create cases in case of criticalnes is none */
		/* PMSTA14055 - CHU - 120405 - Merci Madame la voyante */
		if ((CONSTRCRITICALNESS_ENUM)GET_ENUM(extStratEltTab[i], ExtStratElt_CriticalnessEn) != ConstrCriticalness_None &&
			IS_NULLFLD(extStratEltTab[i], ExtStratElt_TradConstrId) == TRUE &&
			IS_NULLFLD(extStratEltTab[i], ExtStratElt_ModelConstrEltId) == TRUE)
		{
			/* PMSTA08413-CHU-090721 - No Case for totalizers */
			if (FIN_IsOrdinateESE(hierHead, extStratEltTab[i]) == TRUE)
			{
				continue;
			}

			/*No case for ESE with No target weight */
            /*PMSTA-46435   if special case of no-target weight where IP having single MP then raise cases.*/
			if (GET_FLAG(ptfPtr,A_Ptf_singleMPNoTargetWgtFlg) == FALSE &&
                STRATELT_NOTARGETWT_ENUM::NoTargetWeight ==
				static_cast<STRATELT_NOTARGETWT_ENUM>GET_ENUM(extStratEltTab[i], ExtStratElt_NoTargetWeightEn))
			{
				continue;
			}

			/* Create Case for current ESE and add it into hierarchy */
			if ((ret = FIN_CreateCaseFromESE(domainPtr, hierHead, extStratEltTab[i],ptfPtr)) != RET_SUCCEED)
			{
				FREE(extStratEltTab);
				return(ret);
			}
		}
	}

	FREE(extStratEltTab);
	return(ret);
}

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DBAEXCH_C

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H

#include "unidef.h"     /* Mandatory */
#include "gen.h"
#include "dba.h"
#include "fin.h"
#include "proc.h"
#include "date.h"
#include "cmp.h"
#include "hier.h"
#include "scptyl.h"

/************************************************************************
**      External entry points
**
** DBA_GetExchRate() 		Get exchange between two currencies.
** DBA_ExchRateByFreq() 	Search rates between two currencies at determined frequency.
** DBA_GetEuroConversionDate() 	Verify euro conversion date validity.
**
*************************************************************************/

/************************************************************************
**      Local functions
**
** DBA_CurrLending() 		Compute currency price.
** DBA_CmpExchRateDate		Compare exchange rate date
*************************************************************************/

/************************************************************************
**      Static definitions & data
*************************************************************************/
STATIC RET_CODE DBA_CurrLending(DBA_DYNFLD_STP, DATETIME_T, ID_T, DBA_DYNFLD_STP,
			        ENUM_T, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP);

/************************************************************************
**      FONCTIONS
************************************************************************/

/************************************************************************
**
**  Function    :   DBA_CmpExchRateDate()
**
**  Description :   Compare exchange rate date
**
**  Arguments   :   two records to compare
**
**  Return      :
**     a negative value if first element < second element
**     a null value     if first element = second element
**     a positive value if first element > second element
**
**  Modif:	REF2544 - SSO - 980717 - TLS_Sort is done in DBA_ExchRateByFreq
**		    Thus, this function is moved from finlib04.c to dbaexch.c
**  Modif:	REF7061 - TEB - 030128 - Correction of sort, by requested date !!
**
*************************************************************************/
STATIC int DBA_CmpExchRateDate(DBA_DYNFLD_STP  *exchRate1,
				   DBA_DYNFLD_STP  *exchRate2)
{
/*	return(CMP_DYNFLD((*exchRate1), (*exchRate2),
			  Freq_ExchRate_ExchDate, Freq_ExchRate_ExchDate,
			  DatetimeType)); */
    /* REF7061 - TEB - 030128 */
	return(CMP_DYNFLD((*exchRate1), (*exchRate2),
			  Freq_ExchRate_RequestDate, Freq_ExchRate_RequestDate,
			  DatetimeType));

}

/******************************************************************************
**  Function             : DBA_GetConnectNoFromExchArg()
**
**  Description          : access the connexion number stocked in the exch arg
**
**  Arguments            : exchArgStp  pointer on exch arg
**
**	    WARNING: the stocked # is the REAL # + 1.
**		     thus, for all existing memset(NULL), the return value is -1
**			and the optimization for DBA_GetDomainPtr is not used
**
**  Return               : connexion number (for current thread)
**
**  Created		 : REF2580 - SSO - 980727
**
*******************************************************************************/
int DBA_GetConnectNoFromExchArg(PTR exchArgStp)
{
    if (exchArgStp != NULL)
	return ((FIN_EXCHARG_STP)exchArgStp)->threadConnNbrPlusOne - 1;
    else
	return(-1);
}

/******************************************************************************
**  Function             : DBA_SetConnectNoToExchArg()
**
**  Description          : access the connexion number stocked in the exch arg
**
**  Arguments            : exchArgStp  pointer on exch arg
**
**	    WARNING: the stocked # is the REAL # + 1.
**		     thus, for all existing memset(NULL), the return value is -1
**			and the optimization for DBA_GetDomainPtr is not used
**
**  Return               : connexion number (for current thread)
**
**  Created		 : REF2580 - SSO - 980727
**  Deleted		   REF4213 - SSO - 991221
*******************************************************************************/
/*
void DBA_SetConnectNoToExchArg(PTR exchArgStp, int threadConnNbr)
{
    if (exchArgStp != NULL)
	((FIN_EXCHARG_STP)exchArgStp)->threadConnNbrPlusOne = threadConnNbr + 1;
}
*/

/******************************************************************************
**  Function             : DBA_InitConnectNoToExchArg()
**
**  Description          : access the connexion number stocked in the exch arg
**
**  Arguments            : exchArgStp  pointer on exch arg
**
**	    WARNING: the stocked # is the REAL # + 1.
**		     thus, for all existing memset(NULL), the return value is -1
**			and the optimization for DBA_GetDomainPtr is not used
**
**  Return               : connexion number (for current thread)
**
**  Created		 : REF4213 - SSO - 991221
**
*******************************************************************************/
void DBA_InitConnectNoToExchArg(PTR exchArgStp, DBA_HIER_HEAD_STP hierHead)
{
    /* DLA - PMSTA-20089 - 160526 */
#if 0
    int threadConnNbr;
    if (exchArgStp != NULL)
    {
	if (hierHead != NULL)
	    threadConnNbr = DBA_GetConnectNoFromHier((DBA_HIER_HEAD_STP)hierHead);
	else
	    threadConnNbr = DBA_GetThreadConnNbr();

	if (threadConnNbr > -1)
	    ((FIN_EXCHARG_STP)exchArgStp)->threadConnNbrPlusOne = threadConnNbr + 1;
    }
#endif
}



/************************************************************************
**
**  Function    :   DBA_GetExchRate()
**
**  Description :   Get exchange between two currencies, using optional
**                  parameters (type and market) and direct exchange rate
**                  flag.
**
**  Arguments   :   refDateTime        exchange date
**                  srcCurrId          source currency identifier
**                  trgtCurrId         target currency identifier
**                  valRuleId          id of valuation rule to use
**                  valRulePtr         pointer on valuation rule structure
**                  tpId               type identifier (optional)
**                  marketId           market identifier (optional)
**                  providerId         provider identifier (optional)
**                  directFlg          direct exchange rate required or not
**                  tpMandFlg          type mandatory flag
**                  mktMandFlg         market mandatory flag
**                  porvMandFlg        provider mandatory flag
**                  exchRetMet         exchange retrieval method
**                  exchRateTabSrcIn   array of exchange rate for source currency (used to optimize)
**                  exchRateNbrSrcIn   number of exchange rate in array
**                  exchRateTabSrcDest array of exchange rate for target currency (used to optimize)
**                  exchRateNbrSrcDest number of exchange rate in array
**                  exch               pointer on exchange
**                  isFutureExchRate   Decides whether to take fture exchange rates based on the operation_d
**
**
**  Return      :   RET_SUCCEED         exchPtr is pointer on structure exchange
**                  RET_FIN_INFO_NOEXCH exchPtr is parameter exchange
**                  error code          exchPtr is parameter exchange
**
**  Modif	:   REF1177 - RAK - 980130
**  Modif	:   REFXZ - RAK - 980609
**  Modif	:   REF2580 - SSO - 980727
**  Modif.  :   REF5248 - RAK - 001005
**
*************************************************************************/
RET_CODE DBA_GetExchRate(DATETIME_T     refDateTime,
		         ID_T           srcCurrId,
		         ID_T           trgtCurrId,
		         ID_T           valRuleId,
			 DBA_DYNFLD_STP inputValRulePtr,
			 DBA_DYNFLD_STP posPtr,		/* PMSTA01649 - TGU - 070329 */
			 ENUM_T         valRuleCoefNatEn,
			 PTR		exchArgPtr,		/* REFXZ */
		         DBA_DYNFLD_STP *exchRateTabSrcIn,
		         int            exchRateNbrSrcIn,
		         DBA_DYNFLD_STP *exchRateTabDestIn,
		         int            exchRateNbrDestIn,
		         DBA_DYNFLD_STP exchPtr,
                 FLAG_T         isFutureExchRate)
{
	DBA_DYNFLD_STP     getCurr=NULLDYNST, srcCurrPtr=NULLDYNST, destCurrPtr=NULLDYNST;
	DBA_DYNFLD_STP     getValRule=NULLDYNST, valRulePtr=NULLDYNST;
	DBA_DYNFLD_STP     valRuleHistPtr=NULLDYNST, classifResult=NULLDYNST;
	DBA_DYNFLD_STP     admArgPtr=NULLDYNST;
	DBA_DYNFLD_STP     *valRuleEltTab=NULLDYNSTPTR;
	DBA_DYNFLD_STP     domainPtr=NULLDYNST;
	ID_T	           listIdSrc=(ID_T)0, listIdDest=(ID_T)0, crossCurrId=(ID_T)0;
	int	           valRuleEltNbr = 0;
	int	           limite = 0 /*, exchRateNbrDest = 0 REF6999 */;
	int	           bestExchRateSrc = -1, bestExchRateDest = -1;
	int	           i,j;
	int	           nbRuleSrc, nbRuleDest;
	int	           firstRuleSrc, firstRuleDest;
	FLAG_T	           foundSrc = FALSE, foundDest = FALSE, datePriority = FALSE;
	FLAG_T	           allocDest = FALSE, allocSrc = FALSE;
	RET_CODE           ret=RET_SUCCEED;
	char               allocValRuleOk=FALSE;
	EXCHANGE_T         missingExch;
	OBJECT_ENUM        entity;
	DATE_T	           currentDate;
	DATETIME_T         euroDate;				/* REF1177 */
	FIN_EXCHTABARG_ST  exchTabArgSt;
	FIN_EXCHOUT_ST	   exchOutSt;
	FIN_EXCHARG_STP	   exchArgStp= (FIN_EXCHARG_STP) exchArgPtr;		/* REFXZ */
    FLAG_T             freeSrcFlag=FALSE, freeDestFlag=FALSE;

	exchTabArgSt.exchRateTabSrcIn  = exchRateTabSrcIn;	/* REF1177 */
	exchTabArgSt.exchRateNbrSrcIn  = exchRateNbrSrcIn;
	exchTabArgSt.exchRateTabDestIn = exchRateTabDestIn;
	exchTabArgSt.exchRateNbrDestIn = exchRateNbrDestIn;

	memset(&exchOutSt, 0, sizeof(FIN_EXCHOUT_ST));		/* REF1177 */
	memset(&euroDate, 0, sizeof(DATETIME_T));

        /* Set default values (received param and system dflt exchange rate) */
        GEN_GetApplInfo(ApplMissingExchRate, &missingExch);

	/* if refDateTime is future, seach today's exchange rate */
	if (isFutureExchRate != TRUE)    /* PMSTA - 41969 - AIS - 201005 */
	{
		currentDate = DATE_CurrentDate();
		if (refDateTime.date > currentDate)
			refDateTime.date = currentDate;
        }

        SET_EXCHANGE(exchPtr, A_ExchRate_ExchRate,    missingExch);
        SET_ID(exchPtr,       A_ExchRate_CurrId,      srcCurrId);
        SET_ID(exchPtr,       A_ExchRate_UnderCurrId, trgtCurrId);
        SET_DATETIME(exchPtr, A_ExchRate_ExchDate,    refDateTime);

        if (exchArgStp->tpId == 0)
            {SET_NULL_ID(exchPtr, A_ExchRate_TpId);}
        else
            SET_ID(exchPtr, A_ExchRate_TpId, exchArgStp->tpId);

        if (exchArgStp->marketId == 0)
            {SET_NULL_ID(exchPtr, A_ExchRate_MktThirdId);}
        else
            SET_ID(exchPtr, A_ExchRate_MktThirdId, exchArgStp->marketId);

        if (exchArgStp->providerId == 0)
            {SET_NULL_ID(exchPtr, A_ExchRate_ThirdId);}
        else
            SET_ID(exchPtr, A_ExchRate_ThirdId, exchArgStp->providerId);

	/* if no valuation rule look for it in Domain */
	if (valRuleId == (ID_T)0 &&
	    (domainPtr = DBA_GetDomainPtr(DBA_GetConnectNoFromExchArg(exchArgStp))) != NULLDYNST) /* REF2580 - SSO - 980727 */
	{
		/* PMSTA01649 - TGU - 070410 - if no valution rule identifier is set, instead of looking in domain only use new function
		** to look for it in domain, pps or portfolio */

		/*if (IS_NULLFLD(domainPtr, A_Domain_ExchValRuleId) == FALSE)
			valRuleId = GET_ID(domainPtr, A_Domain_ExchValRuleId);*/

		FIN_GetExchValRuleIdInDomPPSPtf(domainPtr, posPtr, NULLDYNST, &valRuleId);
	}


	if (srcCurrId == 0 || trgtCurrId == 0)
	{
		SET_EXCHANGE(exchPtr, A_ExchRate_ExchRate, 1.0);
		return(RET_FIN_INFO_NOEXCH);
	}

	/* if no valRule in parameter use default define with appl_param */
	if (valRuleId == (ID_T)0)
	{
		/* if source currency is the same as target currency return 1 */
	        if (srcCurrId == trgtCurrId)
	        {
                    SET_EXCHANGE(exchPtr, A_ExchRate_ExchRate, 1.0);
	            return(ret);
	        }

		if ((exchOutSt.exchRateSrc = ALLOC_DYNST(A_ExchRate)) == NULLDYNST)
			MSG_RETURN(RET_MEM_ERR_ALLOC);

		if ((exchOutSt.exchRateDest = ALLOC_DYNST(A_ExchRate)) == NULLDYNST)
		{
		        FREE_DYNST(exchOutSt.exchRateSrc, A_ExchRate);
		        MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		/* ------------------------------------------------ */
		/* REF1177 - Select prices and choose default price */
		exchOutSt.defaultFlg = TRUE;
		/* ------------------------------------------------ */

		/* REF1177 - Verify first that dflt underlying currency for exchange isn't set */
		GEN_GetApplInfo(ApplExchUnderCurrId, &crossCurrId);
		if (crossCurrId == 0)
			GEN_GetApplInfo(ApplSysCurrId, &crossCurrId);

		/* REF1177 - Verify euro introduction */
		if (DBA_GetEuroConversionDate(&euroDate.date, DBA_GetConnectNoFromExchArg(exchArgStp)) == TRUE)
		{
		    /* cross currency can be modified to old underlying exchange currency */
		    ret = FIN_EuroExchRate(srcCurrId, trgtCurrId, &crossCurrId, euroDate,
					   refDateTime, exchArgStp, &exchTabArgSt, &exchOutSt);

		    if (ret != RET_SUCCEED)
		    {
			FREE_DYNST(exchOutSt.exchRateSrc, A_ExchRate);
			FREE_DYNST(exchOutSt.exchRateDest, A_ExchRate);
			return(ret);
		    }
		}
		else 							/* NO EURO */
		{
		    if (crossCurrId != srcCurrId)
		    {
			exchOutSt.srcDestEn = SrcDest_Src;
			ret = FIN_SelDfltExchRate(srcCurrId, crossCurrId, refDateTime, FALSE,
		                                  exchArgStp, &exchTabArgSt, &exchOutSt);
		    }

	            if (ret != RET_SUCCEED)
	            {
		        FREE_DYNST(exchOutSt.exchRateSrc, A_ExchRate);
		        FREE_DYNST(exchOutSt.exchRateDest, A_ExchRate);
		        return(ret);
	            }

	            if (crossCurrId != trgtCurrId)
		    {
			exchOutSt.srcDestEn = SrcDest_Dest;
		        ret = FIN_SelDfltExchRate(trgtCurrId, crossCurrId, refDateTime, FALSE,
		                                  exchArgStp, &exchTabArgSt, &exchOutSt);
		    }

		    if (ret != RET_SUCCEED)
		    {
			FREE_DYNST(exchOutSt.exchRateSrc, A_ExchRate);
			FREE_DYNST(exchOutSt.exchRateDest, A_ExchRate);
			return(ret);
		    }
		}

		if (crossCurrId != srcCurrId && crossCurrId != trgtCurrId)
			FIN_MergeExchRate(exchOutSt.exchRateSrc, exchOutSt.exchRateDest, exchPtr);
		else if (crossCurrId != srcCurrId)
			COPY_DYNST(exchPtr, exchOutSt.exchRateSrc, A_ExchRate);
		else if (crossCurrId != trgtCurrId)
		{
			COPY_DYNST(exchPtr, exchOutSt.exchRateDest, A_ExchRate);
			SET_ID(exchPtr, A_ExchRate_CurrId, srcCurrId);
			SET_ID(exchPtr, A_ExchRate_UnderCurrId, trgtCurrId);

			if (GET_EXCHANGE(exchOutSt.exchRateDest, A_ExchRate_ExchRate) != 0)
			{
			    SET_EXCHANGE(exchPtr, A_ExchRate_ExchRate,
				1/GET_EXCHANGE(exchOutSt.exchRateDest, A_ExchRate_ExchRate));
			}
			else
			    SET_EXCHANGE(exchPtr, A_ExchRate_ExchRate, 0.0);
		}
		else
			SET_EXCHANGE(exchPtr, A_ExchRate_ExchRate, 1.0);

		FREE_DYNST(exchOutSt.exchRateSrc, A_ExchRate);
		FREE_DYNST(exchOutSt.exchRateDest, A_ExchRate);
		return(ret);
	}

	/**** LOAD Valuation Rule ****/
	/* If valuation rule structure was load upper, his pointer is given */
	/* in parameters list. So function use it and don't free it.    */
	if (inputValRulePtr != NULLDYNST)
	{
		valRulePtr = inputValRulePtr;
		allocValRuleOk = FALSE;
	}
	else
	{
		if ((getValRule = ALLOC_DYNST(S_ValRule)) == NULLDYNST)
		{
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		if ((valRulePtr = ALLOC_DYNST(A_ValRule)) == NULLDYNST)
		{
			FREE_DYNST(getValRule, S_ValRule);
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		SET_ID(getValRule, S_ValRule_Id, valRuleId);
		if (DBA_Get2(ValRule, UNUSED, S_ValRule, getValRule, A_ValRule, &valRulePtr,
		             UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
		{
			SYSNAME_T entSqlName;
			strcpy(entSqlName, DBA_GetDictEntitySqlName(ValRule));
			MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO,
			             entSqlName, GET_ID(getValRule, S_ValRule_Id));
			FREE_DYNST(getValRule, S_ValRule);
			FREE_DYNST(valRulePtr, A_ValRule);
			return(RET_DBA_ERR_NODATA);
		}

		FREE_DYNST(getValRule, S_ValRule);
		allocValRuleOk = TRUE;
	}

	/* if source currency is the same as target currency and */
        /* rule is not currency lending, return 1 */
	if (srcCurrId == trgtCurrId &&
	    GET_ENUM(valRulePtr, A_ValRule_NatEn) != ValRuleNat_CurrLending)
	{
	    if (allocValRuleOk == TRUE) {FREE_DYNST(valRulePtr, A_ValRule);}
            SET_EXCHANGE(exchPtr, A_ExchRate_ExchRate, 1.0);
	    return(ret);
	}

	/* Load Currency */
    /* REF5248 - RAK - 001005 */
    /* Suppress DBA_Get2(Curr) and FREE_DYNST for srcCurrPtr and destCurrPtr */
	/* PMSTA16847 - DDV - 130924 - Add freeFlag parameter */
    if (DBA_GetCurrById(srcCurrId, &srcCurrPtr, &freeSrcFlag) != RET_SUCCEED)
    {
        SYSNAME_T entSqlName;
		strcpy(entSqlName, DBA_GetDictEntitySqlName(Curr));
		MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO,
		             entSqlName, GET_ID(getCurr, S_Curr_Id));
		if (allocValRuleOk == TRUE) {FREE_DYNST(valRulePtr, A_ValRule);}
		return(RET_DBA_ERR_NODATA);
    }

	/* PMSTA16847 - DDV - 130924 - Add freeFlag parameter */
    if (DBA_GetCurrById(trgtCurrId, &destCurrPtr, &freeDestFlag) != RET_SUCCEED)
	{
		SYSNAME_T entSqlName;
		strcpy(entSqlName, DBA_GetDictEntitySqlName(Curr));
		MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO,
		             entSqlName, GET_ID(getCurr, S_Curr_Id));
		if (allocValRuleOk == TRUE) {FREE_DYNST(valRulePtr, A_ValRule);}
        if (freeSrcFlag == TRUE) {FREE_DYNST(srcCurrPtr, A_Curr);}
		return(RET_DBA_ERR_NODATA);
	}

	/* Get valuation History record corresponding with rule and date */
	if ((admArgPtr = ALLOC_DYNST(Adm_Arg)) == NULLDYNST)
	{
		if (allocValRuleOk == TRUE) {FREE_DYNST(valRulePtr, A_ValRule);}
        if (freeSrcFlag == TRUE) {FREE_DYNST(srcCurrPtr, A_Curr);}
        if (freeDestFlag == TRUE) {FREE_DYNST(destCurrPtr, A_Curr);}
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	if ((valRuleHistPtr = ALLOC_DYNST(A_ValRuleHist)) == NULLDYNST)
	{
		if (allocValRuleOk == TRUE) {FREE_DYNST(valRulePtr, A_ValRule);}
		FREE_DYNST(admArgPtr, Adm_Arg);
        if (freeSrcFlag == TRUE) {FREE_DYNST(srcCurrPtr, A_Curr);}
        if (freeDestFlag == TRUE) {FREE_DYNST(destCurrPtr, A_Curr);}
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	SET_ID(admArgPtr, Adm_Arg_Id, valRuleId);
	SET_DATETIME(admArgPtr, Adm_Arg_Date, refDateTime);

	if (DBA_Get2(ValRuleHist, DBA_GET_LAST, Adm_Arg, admArgPtr, A_ValRuleHist, &valRuleHistPtr, /* DDV - 180918 - Add role to avoid confusion with BK */
	             UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
	{
		SYSNAME_T entSqlName;
		strcpy(entSqlName, DBA_GetDictEntitySqlName(ValRuleHist));
		MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO,
		             entSqlName, GET_ID(admArgPtr, Adm_Arg_Id));
		if (allocValRuleOk == TRUE) {FREE_DYNST(valRulePtr, A_ValRule);}
		FREE_DYNST(admArgPtr, Adm_Arg);
		FREE_DYNST(valRuleHistPtr, A_ValRuleHist);
        if (freeSrcFlag == TRUE) {FREE_DYNST(srcCurrPtr, A_Curr);}
        if (freeDestFlag == TRUE) {FREE_DYNST(destCurrPtr, A_Curr);}
		return(RET_DBA_ERR_NODATA);
	}
	FREE_DYNST(admArgPtr, Adm_Arg);

    DBA_GetObjectEnum(GET_DICT(valRuleHistPtr, A_ValRuleHist_EntityDictId), &entity);

	if (entity == Curr)
	{
	        if ((classifResult = ALLOC_DYNST(A_ClassifCompo)) == NULLDYNST)
	        {
		        if (allocValRuleOk == TRUE) {FREE_DYNST(valRulePtr, A_ValRule);}
		        FREE_DYNST(valRuleHistPtr, A_ValRuleHist);
                if (freeSrcFlag == TRUE) {FREE_DYNST(srcCurrPtr, A_Curr);}
                if (freeDestFlag == TRUE) {FREE_DYNST(destCurrPtr, A_Curr);}
		        MSG_RETURN(RET_MEM_ERR_ALLOC);
	        }

	        /* Classify source currency */
	        FIN_Classify(GET_DICT(valRuleHistPtr, A_ValRuleHist_EntityDictId),  /* PMSTA-10070 - LJE - 101004 */
                         srcCurrId, GET_ID(valRuleHistPtr, A_ValRuleHist_ClassifId),
       	                 srcCurrPtr, classifResult, NULL, NULL, &refDateTime, domainPtr, FALSE, TRUE,
                         UNUSED, UNUSED); /* no optimisation and no hierarchy */
	        listIdSrc = GET_ID(classifResult, A_ClassifCompo_ListId);

	        /* Classify destination currency */
	        FIN_Classify(GET_DICT(valRuleHistPtr, A_ValRuleHist_EntityDictId), /* PMSTA-10070 - LJE - 101004 */
                         trgtCurrId, GET_ID(valRuleHistPtr, A_ValRuleHist_ClassifId),
       	                 destCurrPtr, classifResult, NULL, NULL, &refDateTime, domainPtr, FALSE, TRUE,
                         UNUSED, UNUSED); /* no optimisation and no hierarchy */
	        listIdDest = GET_ID(classifResult, A_ClassifCompo_ListId);

		FREE_DYNST(classifResult, A_ClassifCompo);
	}
	else
	{
		if (allocValRuleOk == TRUE) {FREE_DYNST(valRulePtr, A_ValRule);}
		FREE_DYNST(valRuleHistPtr, A_ValRuleHist);
        if (freeSrcFlag == TRUE) {FREE_DYNST(srcCurrPtr, A_Curr);}
        if (freeDestFlag == TRUE) {FREE_DYNST(destCurrPtr, A_Curr);}
		return(RET_FIN_INFO_NOEXCH);
	}

    /* Select all valuation rule element */
	if ((admArgPtr = ALLOC_DYNST(Adm_Arg)) == NULLDYNST)
	{
		if (allocValRuleOk == TRUE) {FREE_DYNST(valRulePtr, A_ValRule);}
	    FREE_DYNST(valRuleHistPtr, A_ValRuleHist);
        if (freeSrcFlag == TRUE) {FREE_DYNST(srcCurrPtr, A_Curr);}
        if (freeDestFlag == TRUE) {FREE_DYNST(destCurrPtr, A_Curr);}
    	MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	SET_ID(admArgPtr, Adm_Arg_Id, GET_ID(valRuleHistPtr, A_ValRuleHist_Id));

    if ((DBA_Select2(ValRuleElt, UNUSED, Adm_Arg, admArgPtr,
                     A_ValRuleElt, &valRuleEltTab, UNUSED, UNUSED,
                     &valRuleEltNbr, UNUSED, UNUSED)) != RET_SUCCEED)
	{
		SYSNAME_T entSqlName;
		strcpy(entSqlName, DBA_GetDictEntitySqlName(ValRuleElt));
		MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO,
		             entSqlName, GET_ID(admArgPtr, Adm_Arg_Id));
		if (allocValRuleOk == TRUE) {FREE_DYNST(valRulePtr, A_ValRule);}
		FREE_DYNST(admArgPtr, Adm_Arg);
		FREE_DYNST(valRuleHistPtr, A_ValRuleHist);
        if (freeSrcFlag == TRUE) {FREE_DYNST(srcCurrPtr, A_Curr);}
        if (freeDestFlag == TRUE) {FREE_DYNST(destCurrPtr, A_Curr);}
		return(RET_DBA_ERR_NODATA);
	}
	FREE_DYNST(admArgPtr, Adm_Arg);

	/* count number of valuation ruler element for each currency */
	nbRuleSrc= 0;
	nbRuleDest= 0;
	firstRuleSrc = -1;
	firstRuleDest = -1;

	for (i=0; i<valRuleEltNbr; i++)
	{
		if (GET_ID(valRuleEltTab[i], A_ValRuleElt_ListId) == listIdSrc)
		{
			nbRuleSrc++;
			if (firstRuleSrc == -1)
				firstRuleSrc = i;
		}

		if (GET_ID(valRuleEltTab[i], A_ValRuleElt_ListId) == listIdDest)
		{
			nbRuleDest++;
			if (firstRuleDest == -1)
				firstRuleDest = i;
		}
	}

	/* if valaluation rule element is intrument lending, call specific procedure */
	/* return MISSING_EXCHANGE_RASTE */
	if (GET_ENUM(valRulePtr, A_ValRule_NatEn) == ValRuleNat_CurrLending)
	{
	    /* if no vale rule element for source currency, return MISSING_EXCHANGE_RASTE */
	    if (nbRuleSrc == 0)
	    {
		    if (allocValRuleOk == TRUE) {FREE_DYNST(valRulePtr, A_ValRule);}
		    FREE_DYNST(valRuleHistPtr, A_ValRuleHist);
            DBA_FreeDynStTab(valRuleEltTab, valRuleEltNbr, A_ValRuleElt);
            if (freeSrcFlag == TRUE) {FREE_DYNST(srcCurrPtr, A_Curr);}
            if (freeDestFlag == TRUE) {FREE_DYNST(destCurrPtr, A_Curr);}
		    return(RET_FIN_INFO_NOEXCH);
	    }
	    else
	    {
		    ret = DBA_CurrLending(srcCurrPtr, refDateTime, valRuleId, valRuleEltTab[firstRuleSrc],
                                          valRuleCoefNatEn, NULL /*hierHead*/, exchPtr);
		    return(ret);
	    }
	}

    if (freeSrcFlag == TRUE) {FREE_DYNST(srcCurrPtr, A_Curr);}
    if (freeDestFlag == TRUE) {FREE_DYNST(destCurrPtr, A_Curr);}

	/* if no vale rule element for source or destination currency */
	/* return default Exchange Rate */
	/* DDV - 980330 - Use default exchange */
	if (nbRuleSrc == 0)
	{
	    if ((exchOutSt.exchRateSrc = ALLOC_DYNST(A_ExchRate)) == NULLDYNST)
        {
		    if (allocValRuleOk == TRUE) {FREE_DYNST(valRulePtr, A_ValRule);}
		    FREE_DYNST(valRuleHistPtr, A_ValRuleHist);
            DBA_FreeDynStTab(valRuleEltTab, valRuleEltNbr, A_ValRuleElt);
		    return(ret);
        }
        allocSrc = TRUE;

	    /* Verify first that dflt underlying currency for exchange isn't set */
	    GEN_GetApplInfo(ApplExchUnderCurrId, &crossCurrId);
	    if (crossCurrId == 0)
		GEN_GetApplInfo(ApplSysCurrId, &crossCurrId);

	    foundSrc = TRUE;
	    if (crossCurrId != srcCurrId)
	    {
		    exchOutSt.defaultFlg = TRUE;
		    exchOutSt.srcDestEn = SrcDest_Src;
		    ret = FIN_SelDfltExchRate(srcCurrId, crossCurrId, refDateTime, FALSE,
	                                      exchArgStp, &exchTabArgSt, &exchOutSt);
	    }

	    if (ret != RET_SUCCEED)
	    {
		    FREE_DYNST(exchOutSt.exchRateSrc, A_ExchRate);
		    if (allocValRuleOk == TRUE) {FREE_DYNST(valRulePtr, A_ValRule);}
		    FREE_DYNST(valRuleHistPtr, A_ValRuleHist);
            DBA_FreeDynStTab(valRuleEltTab, valRuleEltNbr, A_ValRuleElt);
		    return(ret);
	    }
	}

	/* DDV - 980330 - Use default exchange */
	if (nbRuleDest == 0)
	{
	    if ((exchOutSt.exchRateDest = ALLOC_DYNST(A_ExchRate)) == NULLDYNST)
	    {
		    if (allocSrc == TRUE) {FREE_DYNST(exchOutSt.exchRateSrc, A_ExchRate);}
		    if (allocValRuleOk == TRUE) {FREE_DYNST(valRulePtr, A_ValRule);}
		    FREE_DYNST(valRuleHistPtr, A_ValRuleHist);
            DBA_FreeDynStTab(valRuleEltTab, valRuleEltNbr, A_ValRuleElt);
		    return(ret);
	    }
        allocDest = TRUE;

	    /* Verify first that dflt underlying currency for exchange isn't set */
	    GEN_GetApplInfo(ApplExchUnderCurrId, &crossCurrId);
	    if (crossCurrId == 0)
		    GEN_GetApplInfo(ApplSysCurrId, &crossCurrId);

	    foundDest = TRUE;
        if (crossCurrId != trgtCurrId)
	    {
		    exchOutSt.defaultFlg = TRUE;
		    exchOutSt.srcDestEn = SrcDest_Dest;
	        ret = FIN_SelDfltExchRate(trgtCurrId, crossCurrId, refDateTime, FALSE,
	                                  exchArgStp, &exchTabArgSt, &exchOutSt);
	    }

	    if (ret != RET_SUCCEED)
	    {
		    if (allocSrc == TRUE) {FREE_DYNST(exchOutSt.exchRateSrc, A_ExchRate);}
		    FREE_DYNST(exchOutSt.exchRateDest, A_ExchRate);
		    if (allocValRuleOk == TRUE) {FREE_DYNST(valRulePtr, A_ValRule);}
		    FREE_DYNST(valRuleHistPtr, A_ValRuleHist);
            DBA_FreeDynStTab(valRuleEltTab, valRuleEltNbr, A_ValRuleElt);
		    return(ret);
	    }
	}

	if (IS_NULLFLD(valRulePtr, A_ValRule_CrossCurrId) == FALSE)
		crossCurrId = GET_ID(valRulePtr, A_ValRule_CrossCurrId);
	else
	{
		/* REF1177 - Verify first that default underlying currency for exchange isn't set */
		GEN_GetApplInfo(ApplExchUnderCurrId, &crossCurrId);
		if (crossCurrId == 0)
			GEN_GetApplInfo(ApplSysCurrId, &crossCurrId);
	}

	/* ----------------------- */
	/* REF1177 - Select prices */
	exchOutSt.defaultFlg = FALSE;
	/* ----------------------- */

	/* REF1177 - Separate select from best choice and call new function for euro */
	if (DBA_GetEuroConversionDate(&euroDate.date, DBA_GetConnectNoFromExchArg(exchArgStp)) == TRUE)
	{
		ret = FIN_EuroExchRate(srcCurrId, trgtCurrId, &crossCurrId, euroDate, refDateTime,
				       exchArgStp, &exchTabArgSt, &exchOutSt);
	}
	else					/* NO EURO */
	{
	    if (srcCurrId != crossCurrId)
	    {
		    exchOutSt.srcDestEn = SrcDest_Src;
		    ret = FIN_SelDfltExchRate(srcCurrId, crossCurrId, refDateTime, FALSE,
		                              exchArgStp, &exchTabArgSt, &exchOutSt);
	    }
	    else
		ret = RET_SUCCEED;

	    if (ret == RET_SUCCEED && trgtCurrId != crossCurrId)
	    {
	        /* extract all exchange rate for destination currency */
		    exchOutSt.srcDestEn = SrcDest_Dest;
		    ret = FIN_SelDfltExchRate(trgtCurrId, crossCurrId, refDateTime, FALSE,
		                              exchArgStp, &exchTabArgSt, &exchOutSt);
	    }
	}

	if (ret != RET_SUCCEED)
	{
	    if (allocSrc == TRUE) {FREE_DYNST(exchOutSt.exchRateSrc, A_ExchRate);}
	    if (allocDest == TRUE) {FREE_DYNST(exchOutSt.exchRateDest, A_ExchRate);}
	    if (allocValRuleOk == TRUE) {FREE_DYNST(valRulePtr, A_ValRule);}
	    FREE_DYNST(valRuleHistPtr, A_ValRuleHist);
        DBA_FreeDynStTab(valRuleEltTab, valRuleEltNbr, A_ValRuleElt);
        if (exchOutSt.allocTabSrc == TRUE)
            DBA_FreeDynStTab(exchOutSt.exchRateTabSrc, exchOutSt.exchRateNbrSrc, A_ExchRate);
        if (exchOutSt.allocTabDest == TRUE)
            DBA_FreeDynStTab(exchOutSt.exchRateTabDest, exchOutSt.exchRateNbrDest, A_ExchRate);
	    return(RET_FIN_INFO_NOEXCH);
	}

	datePriority = GET_FLAG(valRulePtr, A_ValRule_DatePriorityFlg);

	if (srcCurrId != crossCurrId && foundSrc == FALSE)
	{
	    limite = exchOutSt.exchRateNbrSrc;

	        /* for each rule, check if one exchange rate is valid for source currency */
            for (i=firstRuleSrc; i<firstRuleSrc+nbRuleSrc && foundSrc == FALSE; i++)
            {
                /* check each exchange rate */
                for (j=0; j<limite && foundSrc == FALSE; j++)
                {
                    if (FIN_IsExchRateValid(exchOutSt.exchRateTabSrc[j],
                                            valRuleEltTab[i]) == TRUE)
                    {
                        /* if date priority if false, return the first one else */
                        /* continue to search a other can be valid and more recent */
                        if (datePriority == FALSE)
                        {
                            bestExchRateSrc = j;
                            foundSrc = TRUE;
                        }
                        else
                        {
                            /* if the first element is valid stop searching, */
                            /* there is no exchange rate more recent */
                            if (j == 0)
                            {
                                /* REF5573 - SSO - 010110 report REF1915 + fixed comparison */
				                if (bestExchRateSrc != -1 &&
                                    DATETIME_CMP(GET_DATETIME(exchOutSt.exchRateTabSrc[j], A_ExchRate_ExchDate),
                                                 GET_DATETIME(exchOutSt.exchRateTabSrc[bestExchRateSrc], A_ExchRate_ExchDate)) > 0)
                                {
                                    bestExchRateSrc = j;
                                }
                                else if (bestExchRateSrc == -1)
                                {
                                    bestExchRateSrc = j;
                                }
                                foundSrc = TRUE;
                            }
                            else
                            {
                                /* REF5573 - SSO - 010110 report REF1915 + fixed comparison */
				                if (bestExchRateSrc != -1 &&
                                    DATETIME_CMP(GET_DATETIME(exchOutSt.exchRateTabSrc[j], A_ExchRate_ExchDate),
                                                 GET_DATETIME(exchOutSt.exchRateTabSrc[bestExchRateSrc], A_ExchRate_ExchDate)) > 0)
                                {
                                    bestExchRateSrc = j;
                                    limite = j;
                                }
                                else if (bestExchRateSrc == -1)
                                {
                                    bestExchRateSrc = j;
                                    limite = j;
                                }
                            }
                        }
                    }
                }
            }
        }
/* BEGIN BUG452 - 970805 - XMT */
/* PMSTA07185 - DDV - 081023
	else
	{
	    exchOutSt.allocTabSrc = FALSE;
	}*/
/* END BUG452 - 970805 - XMT */

	/* if noting is found return RET_FIN_INFO_NOPRICE */
        if (foundSrc == FALSE && bestExchRateSrc == -1 && srcCurrId != crossCurrId)
	{
	    if (allocSrc == TRUE) {FREE_DYNST(exchOutSt.exchRateSrc, A_ExchRate);}
	    if (allocDest == TRUE) {FREE_DYNST(exchOutSt.exchRateDest, A_ExchRate);}
	    if (allocValRuleOk == TRUE) {FREE_DYNST(valRulePtr, A_ValRule);}
	    FREE_DYNST(valRuleHistPtr, A_ValRuleHist);
        DBA_FreeDynStTab(valRuleEltTab, valRuleEltNbr, A_ValRuleElt);
        if (exchOutSt.allocTabSrc == TRUE)
            DBA_FreeDynStTab(exchOutSt.exchRateTabSrc, exchOutSt.exchRateNbrSrc, A_ExchRate);
        /* PMSTA07185 - DDV - 081023 */
        if (exchOutSt.allocTabDest == TRUE)
            DBA_FreeDynStTab(exchOutSt.exchRateTabDest, exchOutSt.exchRateNbrDest, A_ExchRate);
	    return(RET_FIN_INFO_NOEXCH);
	}

	if (trgtCurrId != crossCurrId && foundDest == FALSE)
	{
	    /* limite = exchRateNbrDest; REF6999 - DDV - 011105 */
        limite = exchOutSt.exchRateNbrDest;

	    /* for each rule, check if one exchange rate is valid for source currency */
            for (i=firstRuleDest; i<firstRuleDest+nbRuleDest && foundDest == FALSE; i++)
            {
                /* check each exchange rate */
                for (j=0; j<limite && foundDest == FALSE; j++)
                {
                    if (FIN_IsExchRateValid(exchOutSt.exchRateTabDest[j],
                                            valRuleEltTab[i]) == TRUE)
                    {
                        /* if date priority if false, return the first one else */
                        /* continue to search a other can be valid and more recent */
                        if (datePriority == FALSE)
                        {
                            bestExchRateDest = j;
                            foundDest = TRUE;
                        }
                        else
                        {
                            /* if the first element is valid stop searching, */
                            /* there is no exchange rate more recent */
                            if (j == 0)
                            {
                                /* REF6999 - DDV - Report modification from REF5573 (not done by SSO ????)*/
				                if (bestExchRateDest != -1 &&
                                    DATETIME_CMP(GET_DATETIME(exchOutSt.exchRateTabDest[j], A_ExchRate_ExchDate),
                                                 GET_DATETIME(exchOutSt.exchRateTabDest[bestExchRateDest], A_ExchRate_ExchDate)) > 0)
                                {
                                    bestExchRateDest = j;
                                }
                                else if (bestExchRateDest == -1)
                                {
                                    bestExchRateDest = j;
                                }
                                foundDest = TRUE;
                            }
                            else
                            {
                                bestExchRateDest = j;
                                limite = j;
                            }
                        }
                    }
                }
            }
        }
/* BEGIN BUG452 - 970805 - XMT */
/*	PMSTA07185 - DDV - 081023
    else
	{
	    exchOutSt.allocTabDest = FALSE;
	}*/
/* END BUG452 - 970805 - XMT */

	/* if noting is found return RET_FIN_INFO_NOPRICE */
        if (foundDest == FALSE && bestExchRateDest == -1 && trgtCurrId != crossCurrId)
	{
	    if (allocSrc == TRUE) {FREE_DYNST(exchOutSt.exchRateSrc, A_ExchRate);}
	    if (allocDest == TRUE) {FREE_DYNST(exchOutSt.exchRateDest, A_ExchRate);}
	    if (allocValRuleOk == TRUE) {FREE_DYNST(valRulePtr, A_ValRule);}
	    FREE_DYNST(valRuleHistPtr, A_ValRuleHist);
        DBA_FreeDynStTab(valRuleEltTab, valRuleEltNbr, A_ValRuleElt);
        if (exchOutSt.allocTabSrc == TRUE)
            DBA_FreeDynStTab(exchOutSt.exchRateTabSrc, exchOutSt.exchRateNbrSrc, A_ExchRate);
        if (exchOutSt.allocTabDest == TRUE)
            DBA_FreeDynStTab(exchOutSt.exchRateTabDest, exchOutSt.exchRateNbrDest, A_ExchRate);
	    return(RET_FIN_INFO_NOEXCH);
	}

	/* DDV - 980330 - Use default exchange */
    if (bestExchRateSrc != -1)
	    exchOutSt.exchRateSrc = exchOutSt.exchRateTabSrc[bestExchRateSrc];

    if (bestExchRateDest != -1)
            exchOutSt.exchRateDest = exchOutSt.exchRateTabDest[bestExchRateDest];

	if (crossCurrId != srcCurrId && crossCurrId != trgtCurrId)
	    FIN_MergeExchRate(exchOutSt.exchRateSrc,
                              exchOutSt.exchRateDest, exchPtr);
	else if (crossCurrId != srcCurrId)
	    COPY_DYNST(exchPtr, exchOutSt.exchRateSrc, A_ExchRate);
	else if (crossCurrId != trgtCurrId)
	{
	    COPY_DYNST(exchPtr, exchOutSt.exchRateDest, A_ExchRate);
            SET_ID(exchPtr, A_ExchRate_CurrId, srcCurrId);
            SET_ID(exchPtr, A_ExchRate_UnderCurrId, trgtCurrId);

            if (GET_EXCHANGE(exchOutSt.exchRateDest, A_ExchRate_ExchRate) != 0)
            {
	            SET_EXCHANGE(exchPtr, A_ExchRate_ExchRate,
			         1 / GET_EXCHANGE(exchOutSt.exchRateDest,
					          A_ExchRate_ExchRate));
            }
            else
	            SET_EXCHANGE(exchPtr, A_ExchRate_ExchRate, 0.0);
	}
	else
	    SET_EXCHANGE(exchPtr, A_ExchRate_ExchRate, 1.0);

	if (allocSrc == TRUE) {FREE_DYNST(exchOutSt.exchRateSrc, A_ExchRate);}
	if (allocDest == TRUE) {FREE_DYNST(exchOutSt.exchRateDest, A_ExchRate);}
	if (allocValRuleOk == TRUE) {FREE_DYNST(valRulePtr, A_ValRule);}
	FREE_DYNST(valRuleHistPtr, A_ValRuleHist);
    DBA_FreeDynStTab(valRuleEltTab, valRuleEltNbr, A_ValRuleElt);
    if (exchOutSt.allocTabSrc == TRUE)
        DBA_FreeDynStTab(exchOutSt.exchRateTabSrc, exchOutSt.exchRateNbrSrc, A_ExchRate);
    if (exchOutSt.allocTabDest == TRUE)
        DBA_FreeDynStTab(exchOutSt.exchRateTabDest, exchOutSt.exchRateNbrDest, A_ExchRate);

	return(ret);
}

/************************************************************************
**
**  Function    :   DBA_ExchRateByFreq()
**
**  Description :   Search rates between two currencies at determined frequency
**
**  Arguments   :   sysCurrId   system curreny identifier
**                  underCurrId underlying curreny identifier
**                  optCurrId   option curreny identifier
**                  techArgPtr  pointer on arguments structure (Tech_Vola)
**
**  Arguments   :   date         end date of the series
**                  freq         frequency at which the data is extracted
**                  freqUnitEn   frequency at which the data is extracted
**                  reading      how many occurrences are to be selected
**                  currId       currency identifier
**                  underCurrId  underlying currency identifier
**                  method       missing data resolution method           - REF7061 - TEB - 030121
**                  exchTab      pointer on rates array to update
**                  exchNbr      pointer on rates number to update
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation	:   DVP005 - RAK - 960313
**
**  Modif.	:   BUG111 - RAK - 960829
**              REF547 - RAK - 971021
**              REF964 - RAK - 971203
**              REF1177 - RAK - 980209
**              REFXZ - RAK - 980609
**              REF2537 - RAK - 980710
**              REF2544 - SSO - 980717
**              REF7264 - 020205 - PMO : Compilation errors and warnings with C++ compiler
**              REF7061 - TEB - 030121
**
*************************************************************************/
RET_CODE DBA_ExchRateByFreq(DATETIME_T     date,
			    TINYINT_T               freq,
			    FREQUNIT_ENUM           freqUnit,
			    int                     reading,
			    ID_T                    currId,
			    ID_T                    underCurrId,
			    ID_T                    valRuleId,
			    DBA_DYNFLD_STP          inputValRulePtr,
                MISSINGDATA_METHOD_ENUM method,      /* REF7061 - TEB - 030121 */
			    DBA_DYNFLD_STP          **exchRateTab,
			    int                     *exchRateNbr)
{
	DBA_DYNFLD_STP		getValRule=NULLDYNST,valRulePtr=NULLDYNST;
	DBA_DYNFLD_STP		ask=NULLDYNST;
	DBA_DYNFLD_STP		exchRatePtr=NULLDYNST;
	DBA_DYNFLD_STP		*exchRateTabSrc=NULLDYNSTPTR, *exchRateTabDest=NULLDYNSTPTR;
	RET_CODE		    ret = RET_SUCCEED;
	int			        i=0, j=0, validity=0, k;
	int			        exchRateNbrSrc=0, exchRateNbrDest=0;
	char			    allocValRuleOk=FALSE;
	DATETIME_T		    begDate;
	DATE_UNIT_ENUM		dateUnit;
	ID_T			    crossCurrId=(ID_T)0;
	FLAG_T			    inverseFlg;
	FIN_EXCHARG_ST 		exchArgSt;		             /* REFXZ */
    int                 nbExch;                      /* REF7061 - TEB - 030121 */
    EXCHANGE_T          sumExch, prevExch, nextExch; /* REF7061 - TEB - 030121 */

	memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));	 /* REFXZ */

	*exchRateNbr = 0;

    sumExch = 0;                                     /* REF7061 - TEB - 030121 */

	if ((ask = ALLOC_DYNST(Sel_Arg)) == NULLDYNST)
	{
	    MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

    if (inputValRulePtr != NULLDYNST)
    {
            valRulePtr = inputValRulePtr;
            allocValRuleOk = FALSE;
    }
    else if (valRuleId != (ID_T)0)
    {
        if ((getValRule = ALLOC_DYNST(S_ValRule)) == NULLDYNST)
        {
            FREE_DYNST(ask, Sel_Arg);
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        if ((valRulePtr = ALLOC_DYNST(A_ValRule)) == NULLDYNST)
        {
            FREE_DYNST(getValRule, S_ValRule);
            FREE_DYNST(ask, Sel_Arg);
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        SET_ID(getValRule, S_ValRule_Id, valRuleId);
        if (DBA_Get2(ValRule, UNUSED, S_ValRule, getValRule, A_ValRule, &valRulePtr,
                     UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
        {
            SYSNAME_T entSqlName;
            strcpy(entSqlName, DBA_GetDictEntitySqlName(ValRule));
            MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO,
                         entSqlName, GET_ID(getValRule, S_ValRule_Id));
            FREE_DYNST(getValRule, S_ValRule);
            FREE_DYNST(valRulePtr, A_ValRule);
            FREE_DYNST(ask, Sel_Arg);
            return(RET_DBA_ERR_NODATA);
        }

        FREE_DYNST(getValRule, S_ValRule);
        allocValRuleOk = TRUE;
    }

	switch(freqUnit)
	{
        case FreqUnit_Day:
            dateUnit = Day;
            break;

        case FreqUnit_BusDay:
            dateUnit = Day;
            break;

        case FreqUnit_Week:
            dateUnit = Week;
            break;

        case FreqUnit_Month:
            dateUnit = Month;
            break;

        case FreqUnit_Quarter:
            dateUnit = Quarter;
            break;

        case FreqUnit_Semester:
            dateUnit = Semester;
            break;

        case FreqUnit_Year:
            dateUnit = Year;
            break;

	    default:
		dateUnit = Day;
    }

    if (valRulePtr != NULLDYNST && IS_NULLFLD(valRulePtr, A_ValRule_CrossCurrId) == FALSE)
        	crossCurrId = GET_ID(valRulePtr, A_ValRule_CrossCurrId);
	else
	{
		/* REF1177 - Verify first that dflt underlying currency for exchange isn't set */
		GEN_GetApplInfo(ApplExchUnderCurrId, &crossCurrId);
		if (crossCurrId == 0)
			GEN_GetApplInfo(ApplSysCurrId, &crossCurrId);
	}

	begDate.time = 0;		/* REF964 */
	begDate.date = DATE_Move(date.date, (-1) * (reading - 1) * freq, dateUnit);

	GEN_GetApplInfo(ApplPricePeriodValidity, &validity);
        begDate.date = DATE_Move(begDate.date, (-1) * validity, Day);

	SET_ID(ask,       Sel_Arg_Id1,         currId);
	SET_ID(ask,       Sel_Arg_Id2,         crossCurrId);
	SET_DATETIME(ask, Sel_Arg_FromDate,    begDate);
	SET_DATETIME(ask, Sel_Arg_TillDate,    date);
	SET_FLAG(ask,     Sel_Arg_DistinctFlg, FALSE);

	if (crossCurrId != currId)
	{
	    ret = DBA_Select2(ExchRate, UNUSED, Sel_Arg, ask,
                              A_ExchRate, &exchRateTabSrc, UNUSED, UNUSED,
                              &exchRateNbrSrc, UNUSED, UNUSED);

	    /* RAK - 990222 */
	    if (ret != RET_SUCCEED)
	    {
        	FREE_DYNST(ask, Sel_Arg);
		    return(ret);
	    }
	}

	SET_ID(ask,       Sel_Arg_Id1,         underCurrId);		/* REF964 */
	if (crossCurrId != underCurrId)
	{
	    ret = DBA_Select2(ExchRate, UNUSED, Sel_Arg, ask,
                              A_ExchRate, &exchRateTabDest, UNUSED, UNUSED,
                              &exchRateNbrDest, UNUSED, UNUSED);

	    /* RAK - 990222 */
	    if (ret != RET_SUCCEED)
	    {
        	FREE_DYNST(ask, Sel_Arg);
        	DBA_FreeDynStTab(exchRateTabSrc, exchRateNbrSrc, A_ExchRate);
		    return(ret);
	    }
	}

    FREE_DYNST(ask, Sel_Arg);

	/* REF1266 - It is possible to store the exchange rates in the database */
	/* inversely relative to the present method. Required for EURO.        */
	GEN_GetApplInfo(ApplExchInverseFlag, &inverseFlg);
	if (inverseFlg == TRUE)
	{
		FIN_InverseExchRate(exchRateTabSrc, exchRateNbrSrc);
		FIN_InverseExchRate(exchRateTabDest, exchRateNbrDest);
	}

    /* alloc array for Freq_ExchRate */
	/* REF547 - Allocate maximal pointer number (use reading) */
	/* REF2537 - exchRateTab will contain blank exchange rates -> *exchRateNbr = reading */
    *exchRateNbr = reading;
    if ((*exchRateTab=(DBA_DYNFLD_STP *) CALLOC(reading, sizeof(DBA_DYNFLD_STP))) == NULL)
    {
        if (allocValRuleOk == TRUE){FREE_DYNST(valRulePtr, A_ValRule);}
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    if ((exchRatePtr = ALLOC_DYNST(A_ExchRate)) == NULLDYNST)
    {
        if (allocValRuleOk == TRUE){FREE_DYNST(valRulePtr, A_ValRule);}
	FREE((*exchRateTab));			/* REF547 */
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

	/*** ---------------------------------------------------- ***/
	/* Compute exchange rate for each date, we need to          */
	/* interprete valuation rules (coding in DBA_GetExchRate()) */
	/*** ---------------------------------------------------- ***/
    for (i=0; i<reading; i++)
    {
	/* REF2537 - exchRateTab will contain blank exchange rates */
        if (((*exchRateTab)[i] = ALLOC_DYNST(Freq_ExchRate)) == NULLDYNST)
        {
            FREE_DYNST(exchRatePtr, A_ExchRate);
		    for (j=0; j<i; j++)
            {
                FREE_DYNST((*exchRateTab)[j], Freq_ExchRate);
            }
		    FREE((*exchRateTab));
            if (allocValRuleOk == TRUE){FREE_DYNST(valRulePtr, A_ValRule);}
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        begDate.date = DATE_Move(date.date, (-1) * i * freq, dateUnit);

	    /* REF547 - Allocate and copy only valid exchange rate (test return) */
	    if ((ret = DBA_GetExchRate(begDate, currId, underCurrId,
		   valRuleId, valRulePtr, NULLDYNST, 0, /* coefNatEn */ /* PMSTA01649 - TGU - 070405 */
		   (PTR) &exchArgSt, 
                                   exchRateTabSrc, exchRateNbrSrc, 
                                   exchRateTabDest, exchRateNbrDest, 
				   exchRatePtr,FALSE)) == RET_SUCCEED)
        {
            /* Copy InstrPrice into Freq_InstrPrice */
            COPY_DYNFLD((*exchRateTab)[i], Freq_ExchRate, Freq_ExchRate_CurrId,
                        exchRatePtr, A_ExchRate, A_ExchRate_CurrId);
            COPY_DYNFLD((*exchRateTab)[i], Freq_ExchRate, Freq_ExchRate_UnderCurrId,
                        exchRatePtr, A_ExchRate, A_ExchRate_UnderCurrId);
            COPY_DYNFLD((*exchRateTab)[i], Freq_ExchRate, Freq_ExchRate_TpId,
                        exchRatePtr, A_ExchRate, A_ExchRate_TpId);
            COPY_DYNFLD((*exchRateTab)[i], Freq_ExchRate, Freq_ExchRate_ThirdId,
                        exchRatePtr, A_ExchRate, A_ExchRate_ThirdId);
            COPY_DYNFLD((*exchRateTab)[i], Freq_ExchRate, Freq_ExchRate_MktThirdId,
                        exchRatePtr, A_ExchRate, A_ExchRate_MktThirdId);
            COPY_DYNFLD((*exchRateTab)[i], Freq_ExchRate, Freq_ExchRate_ExchDate,
                        exchRatePtr, A_ExchRate, A_ExchRate_ExchDate);
            COPY_DYNFLD((*exchRateTab)[i], Freq_ExchRate, Freq_ExchRate_DailyDfltFlg,
                        exchRatePtr, A_ExchRate, A_ExchRate_DailyDfltFlg);

            /* REF7061 - TEB - 021224 - Adding test on method */
            if ( method == MissingDataMethod_LastValid ||
                 DATETIME_CMP(GET_DATETIME(exchRatePtr, Freq_ExchRate_ExchDate), begDate) == 0)
            {
                COPY_DYNFLD((*exchRateTab)[i], Freq_ExchRate, Freq_ExchRate_ExchRate,
                            exchRatePtr, A_ExchRate, A_ExchRate_ExchRate);
            }

            SET_DATETIME((*exchRateTab)[i], Freq_ExchRate_RequestDate, begDate);
        }
	    else
        {
		    SET_DATETIME((*exchRateTab)[i], Freq_ExchRate_ExchDate, begDate);
        }
    }

	/* REF2544 - SSO - 980717 - TLS_Sort is moved from FIN_ExchRateArray to DBA_ExchRateByFreq */
    /* REF2387 - DDV - 980619 - Sort exchange rate ascending by date */
	TLS_Sort((char *) *exchRateTab,
             *exchRateNbr,
             sizeof(DBA_DYNFLD_STP),
	         (TLS_CMPFCT*) DBA_CmpExchRateDate,  /* REF7264 - PMO */
             (PTR **) NULL,
             SortRtnTp_None);

    /* REF7061 - TEB - 030121 - Adding missing data resolution method - Begin modif. */
    nbExch = 0;
    if (method == MissingDataMethod_Average)
		for (i=0; i<reading; i++)
            if (IS_NULLFLD((*exchRateTab)[i], Freq_ExchRate_ExchRate) == FALSE)
            {
                sumExch += GET_EXCHANGE((*exchRateTab)[i], Freq_ExchRate_ExchRate);
                nbExch++;
            }

	for (i=0; i<reading; i++)
	{
        if ( IS_NULLFLD((*exchRateTab)[i], Freq_ExchRate_ExchRate) == TRUE)
        {
            switch(method)
            {
                case MissingDataMethod_IgnoreMissing:
                    (*exchRateNbr)--;
                    reading--;
                    FREE_DYNST((*exchRateTab)[i], Freq_ExchRate);
                    for(j=i; j<reading; j++)
                        (*exchRateTab)[j] = (*exchRateTab)[j+1];
                    (*exchRateTab)[j] = NULLDYNST;
                    i--;
                    break;

                case MissingDataMethod_Average:
                    if (nbExch!=0)
                        SET_EXCHANGE((*exchRateTab)[i], Freq_ExchRate_ExchRate, sumExch/nbExch);
                    break;

                case MissingDataMethod_Encadrante:
                    if (i == 0)
                    {
                        reading--;
                        (*exchRateNbr)--;
                        FREE_DYNST((*exchRateTab)[i], Freq_ExchRate);
                        for(j=i; j<reading; j++)
                            (*exchRateTab)[j] = (*exchRateTab)[j+1];
                        (*exchRateTab)[j] = NULLDYNST;
                        i--;
                    }
                    else
                    {
                        prevExch = GET_EXCHANGE((*exchRateTab)[i-1], Freq_ExchRate_ExchRate);

                        for (j=i;
                             j<reading && IS_NULLFLD((*exchRateTab)[j], Freq_ExchRate_ExchRate) == TRUE;
                             j++) ; /* I want it */

                        if (j<reading)
                        {
                            nextExch = GET_EXCHANGE((*exchRateTab)[j], Freq_ExchRate_ExchRate);
                            for (k=i; k<j; k++)
                                SET_EXCHANGE((*exchRateTab)[k], Freq_ExchRate_ExchRate, (prevExch+nextExch)/2);
                        }
                        else
                        {
                            for(j=i; j<reading; j++)
                                FREE_DYNST((*exchRateTab)[j], Freq_ExchRate);
                            reading=i;
                            (*exchRateNbr)=i;
                        }
                    }
                    break;
            }
        }
    }
    /* REF7061 - TEB - 030121 - End modif */


    FREE_DYNST(exchRatePtr, A_ExchRate);
	DBA_FreeDynStTab(exchRateTabSrc, exchRateNbrSrc, A_ExchRate);   /* sme REF3542 */
	DBA_FreeDynStTab(exchRateTabDest, exchRateNbrDest, A_ExchRate); /* sme REF3542 */

    if (allocValRuleOk == TRUE){FREE_DYNST(valRulePtr, A_ValRule);}

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   DBA_CurrLending()
**
**  Description :   Compute currency price
**
**  Arguments   :   currPtr          allocated currency structure pointer
**                  refDateTime      reference date
**                  valRuleId        id of used valuation rule
**                  valRuleEltPtr    allocated val rule element structure pointer
**                  valRuleCoefNaten nature of coeff to return into instr price
**                  hierHear         hierarchy
**                  exchPtr	     allocated price structure pointer to fill
**
**  Return      :   RET_SUCCEED, RET_FIN_INFO_NOPRICE or error code,
**                  exchPtr will be fill up
**
**  Modif       :   DVP395 - XDI - 970327
**
*************************************************************************/
STATIC RET_CODE DBA_CurrLending(DBA_DYNFLD_STP    currPtr,
  			        DATETIME_T        refDateTime,
			        ID_T              valRuleId,
			        DBA_DYNFLD_STP    valRuleEltPtr,
			        ENUM_T	          valRuleCoefNatEn,
			        DBA_HIER_HEAD_STP hierHead,
		                DBA_DYNFLD_STP    exchPtr)
{
	DICT_ATTRIB_STP  attribStp = (DICT_ATTRIB_STP) NULL;
	DBA_DYNFLD_STP   aScriptDef=NULLDYNST, *scriptDefTab=NULLDYNSTPTR;
	DBA_DYNFLD_STP   sValRuleCoeff=NULLDYNST, aValRuleCoeff=NULLDYNST;
	DBA_DYNFLD_ST    result;
	int 		 scriptDefNbr,i;
        char             *scptBuf;
        SCPT_ARG_STP     genContext = (SCPT_ARG_STP)NULL;
	RET_CODE         ret=RET_SUCCEED;
        EXCHANGE_T       missingExch;
	memset(&result, 0, sizeof(DBA_DYNFLD_ST));

        /* Set default values (received param and system dflt exchange rate) */
        GEN_GetApplInfo(ApplMissingExchRate, &missingExch);


	/* get val rule coeff */
	if ((sValRuleCoeff = ALLOC_DYNST(S_ValRuleCoeff)) == NULLDYNST)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

	if ((aValRuleCoeff = ALLOC_DYNST(A_ValRuleCoeff)) == NULLDYNST)
	{
		FREE_DYNST(sValRuleCoeff, S_ValRuleCoeff);
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	COPY_DYNFLD(sValRuleCoeff, S_ValRuleCoeff, S_ValRuleCoeff_ValRuleElemId,
	            valRuleEltPtr, A_ValRuleElt, A_ValRuleElt_Id);
	SET_ENUM(sValRuleCoeff, S_ValRuleCoeff_NatEn, valRuleCoefNatEn);

	if (DBA_Get2(ValRuleCoeff, UNUSED, S_ValRuleCoeff, sValRuleCoeff, A_ValRuleCoeff,
                     &aValRuleCoeff, UNUSED, UNUSED, UNUSED) == RET_SUCCEED)
	{
		COPY_DYNFLD(exchPtr, A_ExchRate, A_ExchRate_ValRuleCoef,
                    	    aValRuleCoeff, A_ValRuleCoeff, A_ValRuleCoeff_Value);
		SET_ENUM(exchPtr, A_ExchRate_CoefNatEn, valRuleCoefNatEn);
	}
	else
	{
		SET_NULL_NUMBER(exchPtr, A_ExchRate_ValRuleCoef);
		SET_NULL_ENUM(exchPtr, A_ExchRate_CoefNatEn);
	}
	FREE_DYNST(sValRuleCoeff, S_ValRuleCoeff);
	FREE_DYNST(aValRuleCoeff, A_ValRuleCoeff);

	COPY_DYNFLD(exchPtr, A_ExchRate, A_ExchRate_CurrId,
		    currPtr, A_Curr, A_Curr_Id);
	SET_NULL_ID(exchPtr, A_ExchRate_TpId);
	SET_NULL_ID(exchPtr, A_ExchRate_ThirdId);
	SET_NULL_ID(exchPtr, A_ExchRate_MktThirdId);
	SET_DATETIME(exchPtr, A_ExchRate_ExchDate, refDateTime);
	SET_FLAG(exchPtr, A_ExchRate_DailyDfltFlg, FALSE);
	SET_NUMBER(exchPtr, A_ExchRate_ExchRate, missingExch);
	SET_ID(exchPtr, A_ExchRate_ValRuleId, valRuleId);
	COPY_DYNFLD(exchPtr, A_ExchRate, A_ExchRate_ValRuleEltId,
		    valRuleEltPtr, A_ValRuleElt, A_ValRuleElt_Id);

	if ((aScriptDef = ALLOC_DYNST(A_ScriptDef)) == NULLDYNST)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

	attribStp = DBA_GetAttributeBySqlName(ValRuleElt, "script_definition");

	SET_DICT(aScriptDef, A_ScriptDef_AttrDictId, attribStp->attrDictId);
	COPY_DYNFLD(aScriptDef, A_ScriptDef, A_ScriptDef_ObjId,
	            valRuleEltPtr, A_ValRuleElt, A_ValRuleElt_Id);
	SET_ENUM(aScriptDef, A_ScriptDef_NatEn, ScriptDef_ObjDefVal);

        if ((DBA_Select2(ScriptDef, UNUSED, A_ScriptDef, aScriptDef,
                         A_ScriptDef, &scriptDefTab, UNUSED, UNUSED,
                         &scriptDefNbr, UNUSED, UNUSED)) != RET_SUCCEED)
	{
		SYSNAME_T entSqlName;
		strcpy(entSqlName, DBA_GetDictEntitySqlName(ScriptDef));
		MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO,
		             entSqlName, GET_ID(aScriptDef, A_ScriptDef_ObjId));
		FREE_DYNST(aScriptDef, A_ScriptDef);
		return(RET_DBA_ERR_NODATA);
	}
	FREE_DYNST(aScriptDef, A_ScriptDef);

	if ((scptBuf = (char *) CALLOC(1, GET_MAXDATALEN(NoteType) * SCPTDEF_MAX_REC)) == NULL) /* PMSTA-33077 - DLA - 181010 */
		MSG_RETURN(RET_MEM_ERR_ALLOC);

        scptBuf[0] = END_OF_STRING;
        for (i=0; i<scriptDefNbr; i++)
                strcat(scptBuf, GET_STRING(scriptDefTab[i], A_ScriptDef_Def));

        DBA_FreeDynStTab(scriptDefTab, scriptDefNbr, A_ScriptDef);

	if (scptBuf[0] != END_OF_STRING)
	{
		 /* generate evaluation tree */
                if ((ret = SCPT_GenerateScptTree(scptBuf,
                                                 Curr,
                                                 InternalSMode,
                                                 NumberType,
                                                 &genContext)) == RET_SUCCEED)
                {
	                COPY_DYNFLD(currPtr, A_Curr, A_Curr_LendingValRuleEltId,
	                            valRuleEltPtr, A_ValRuleElt, A_ValRuleElt_Id);
                        ret = SCPT_ExecScptTree(genContext,
                                                DBA_GetDomainPtr(DBA_GetConnectNoFromHier(hierHead)),/* REF2580 - SSO - 980727 */
                                                hierHead,
                                                currPtr,
                                                NumberType,
                                                &result,
												NULLDYNST); /* PMSTA14443 - DDV - 120709 */
		}

		SCPT_FreeScptTree(genContext);

		if (ret == RET_SUCCEED)
		{
			SET_NUMBER(exchPtr, A_ExchRate_ExchRate,
			           GET_NUMBER((&result), 0));
		}
	}
	FREE(scptBuf);

	if (ret != RET_SUCCEED)
		ret = RET_FIN_INFO_NOEXCH;

	return(ret);
}

/************************************************************************
**
**  Function    :   DBA_GetEuroConversionDate()
**
**  Description :   Verify euro conversion date validity
**		    if system parameter is set and equal or before
**		    system date, euro conversion is valid.
**
**  Arguments   :   euroDatePtr	euro conversion date pointer
**		    threadConnNbr : connexion # for DBA_GetDomainPtr ( -1 if no optimization)
**
**  Return      :   TRUE if euro conversion date is set and valid,
**		    FALSE elsewhere
**                  euroDatePtr will be fill up
**
**  Creation    :   REF1177 - RAK - 980528
**
**  Modif:	    REF2580 - SSO - 980727
*************************************************************************/
char DBA_GetEuroConversionDate(DATE_T *euroDatePtr, int threadConnNbr)
{
	DATE_T		sysDate;
	DBA_DYNFLD_STP	domainPtr;

	GEN_GetApplInfo(ApplEuroExchConvDate, euroDatePtr);

	if (*euroDatePtr == MAGIC_END_DATE)
	{
		return(FALSE);			/* NO EURO */
	}
	else					/* is EURO conversion date valid ? */
	{
		/* System date is perhaps stored in domain (thread) */
		domainPtr = DBA_GetDomainPtr(threadConnNbr);

		if (domainPtr == NULLDYNST)
			sysDate = DATE_CurrentDate();
		else
		{
			/* If sysDate isn't already stored, update it */
			if (IS_NULLFLD(domainPtr, A_Domain_SysDate) == TRUE)
			{
				sysDate = DATE_CurrentDate();
				SET_DATE(domainPtr, A_Domain_SysDate, sysDate);
			}
			else
				sysDate = GET_DATE(domainPtr, A_Domain_SysDate);
		}

		if (sysDate >= *euroDatePtr)
			return(TRUE);
		else
			return(FALSE);
	}
}

/************************************************************************
**   END  dbaexch.c                                           UNICIBLE **
*************************************************************************/

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DDLGENFK_CPP

/************************************************************************
**      Include files
*************************************************************************/
#include      "unidef.h"     /* Mandatory */
#include         "dba.h"
#include   "ddlgendbi.h"
#include  "ddlgenfile.h"
#include    "ddlgenfk.h"

#include <math.h>       /* pow */

using namespace std;

/************************************************************************
**      External entry points
**
*************************************************************************/

/************************************************************************
**      Local functions
**
*************************************************************************/

/************************************************************************
**      Static definitions & data
**
*************************************************************************/

/************************************************************************
**      FONCTIONS
**
************************************************************************/
/************************************************************************
**
**  Function    :   DdlGenFK::DdlGenFK()
**
**  Description :   Constructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 110311
**
*************************************************************************/
DdlGenFK::DdlGenFK(OBJECT_ENUM      paramObjectEn,
                   DdlGenContext   &paramDdlGenContext,
                   DdlGenEntity    *paramDdlGenEntityPtr,
                   DdlGenFile        *paramFileHelper,
                   TARGET_TABLE_ENUM  paramTargetTableEn)
    : DdlGen(paramObjectEn, DdlObj_ForeignKey, paramDdlGenContext, NULL, paramDdlGenEntityPtr, paramFileHelper, paramTargetTableEn)
{
    init(paramObjectEn,
         DynType_All,
         FALSE,
         FALSE,
         FALSE,
         EntSecuLevel_NoSecured,
         FALSE);
}

/************************************************************************
**
**  Function    :   DdlGenFK::DdlGenFK()
**
**  Description :   Constructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37366 - LJE - 191125
**
*************************************************************************/
DdlGenFK::DdlGenFK(const DdlGen & refDdlGen)
    : DdlGen(refDdlGen.getObjectEn(), refDdlGen)
{
    init(this->getObjectEn(),
         DynType_All,
         FALSE,
         FALSE,
         FALSE,
         EntSecuLevel_NoSecured,
         FALSE);
}

/************************************************************************
**
**  Function    :   DdlGenTable::~DdlGenTable()
**
**  Description :   Destructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 110311
**
*************************************************************************/
DdlGenFK::~DdlGenFK()
{
}

/************************************************************************
**
**  Function    :   DdlGenFK::setName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenFK::setName()
{
    this->setDdlObjSqlName(this->getEntitySqlName());
    this->ddlGenContextPtr->ddlObjSqlName = this->getDdlObjSqlName();
    return RET_SUCCEED;
}

/************************************************************************
**
**  Function    :   DdlGenFK::setName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenFK::setName(DICT_T attribDictId)
{
    stringstream fkSqlNameStream;

    fkSqlNameStream << "fk_" << attribDictId;
    this->setDdlObjSqlName(fkSqlNameStream.str());

    return RET_SUCCEED;
}

/************************************************************************
**
**  Function    :   DdlGenFK::isFKAttrib()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 110311
**
*************************************************************************/
bool DdlGenFK::isFKAttrib(const DICT_ATTRIB_STP currAttribStp) const
{
    if (currAttribStp->isPhysicalAttribute() &&
        currAttribStp->refEntDictId != 0 &&
        currAttribStp->custFlg == FALSE &&
        currAttribStp->precompFlg == FALSE)
    {
        return true;
    }

    return false;
}
/************************************************************************
**
**  Function    :   DdlGenFK::dropOneFK()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:  PMSTA-13109 - LJE - 111116
**
*************************************************************************/
RET_CODE DdlGenFK::dropOneFK(DICT_ATTRIB_STP currAttribStp)
{
    RET_CODE ret = RET_SUCCEED;

    DICT_ENTITY_STP currEntityStp = currAttribStp->dictEntityStp;
    OBJECT_ENUM             fkObjEn         = NullEntity;
    const TARGET_TABLE_ENUM fkTargetTableEn = currAttribStp->custFlg == TRUE ? TargetTable_UserDefinedFields : TargetTable_Main;

    DBA_GetObjectEnum(currAttribStp->refEntDictId, &fkObjEn);

    if (fkObjEn == FctResult)
    {
        fkObjEn = Domain;
    }
    const DICT_ENTITY_STP fkDictEntityStp = DBA_GetDictEntitySt(fkObjEn);

    if (fkDictEntityStp != NULL)
    {
        string selObjInDb = this->getCmdSelObjInDb(this->ddlGenContextPtr->getDdlDestDbName(),
                                                   this->getEntitySqlName(currEntityStp, fkTargetTableEn),
                                                   this->getDdlObjSqlName(),
                                                   DdlObj_ForeignKey,
                                                   string(),
                                                   fkDictEntityStp->dbSqlName,
                                                   currAttribStp->sqlName);

        this->setName(currAttribStp->attrDictId);
        this->bodySqlBlock << this->getCmdIfExsists(selObjInDb,
                                                  "\t" + this->getDdlModif(
                                                  this->getCmdDrop(this->ddlGenContextPtr->getDdlDestDbName(),
                                                                   this->getEntitySqlName(currEntityStp, fkTargetTableEn),
                                                                   this->getDdlObjSqlName(),
                                                                   DdlObj_ForeignKey,
                                                                   nullptr,
                                                                   fkDictEntityStp->dbSqlName,
                                                                   currAttribStp->sqlName)),
                                                  string());
        this->cmdType = DDlCmdType_DbProcess;
        ret = this->flush();
    }
    else
    {
        char msg[255];
        sprintf(msg,
                "Invalid fk on attribute %s, entity %s",
                currAttribStp->sqlName,
                currEntityStp->mdSqlName);
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DdlGenFK", msg);

        ret = RET_DBA_ERR_INVDATA;
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenFK::createOneFK()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:  PMSTA-13109 - LJE - 111116
**
*************************************************************************/
RET_CODE DdlGenFK::createOneFK(DICT_ATTRIB_STP currAttribStp, bool bForceOne)
{
    RET_CODE ret = RET_SUCCEED, gblRet = RET_SUCCEED;

    DICT_ENTITY_STP         currEntityStp    = currAttribStp->dictEntityStp;
    OBJECT_ENUM             fkObjEn          = NullEntity;
    DICT_ATTRIB_STP         derivedAttribStp = NULL;
    const TARGET_TABLE_ENUM fkTargetTableEn  = currAttribStp->custFlg == TRUE ? TargetTable_UserDefinedFields : TargetTable_Main;

    bForceOne |= this->isAllowMultiAlterTable() == false;

    if (currEntityStp->entNatEn == EntityNat_DerivedEntity)
    {
        OBJECT_ENUM     derivedObjEn;
        DBA_GetObjectEnum(currEntityStp->linkedEntityDictId, &derivedObjEn);
        derivedAttribStp = DBA_GetAttributeBySqlName(derivedObjEn, currAttribStp->sqlName);
    }

    /* PMSTA-36158 - LJE - 190613 */
    if (fkTargetTableEn == TargetTable_UserDefinedFields)
    {
        fkObjEn = currEntityStp->objectEn;
    }
    else if (currAttribStp->refEntDictId)
    {
        DBA_GetObjectEnum(currAttribStp->refEntDictId, &fkObjEn);
    }
    /* PMSTA-43103 - LJE - 210107 */
    else if (currAttribStp->primFlg == TRUE &&
             currEntityStp->shadowEntityStp != nullptr)
    {
        DBA_GetObjectEnum(currEntityStp->shadowEntityStp->entDictId, &fkObjEn);
    }
    else
    {
        return gblRet;
    }

    if (fkObjEn == FctResult)
    {
        fkObjEn = Domain;
    }
    DICT_ENTITY_STP fkDictEntityStp = DBA_GetDictEntitySt(fkObjEn);

    if (fkDictEntityStp != nullptr &&
        fkDictEntityStp->logicalFlg == FALSE &&
        fkDictEntityStp->isPhysicalEntity(this->targetTableEn) &&
        fkDictEntityStp->xdStatusEn == XdStatus_Inserted &&
        (this->isReferenceOnFk() || this->getDictEntityStp()->databaseName == fkDictEntityStp->databaseName) &&
        (this->ddlGenContextPtr->bGenFromDbi == false || fkDictEntityStp->bIsInitEntity))
    {
        DICT_ATTRIB_STP               logAttrStp = NULL;
        const REF_CHECK_RULE_ENUM     refCheckRuleEn  = currAttribStp->refCheckRuleEn;
        REF_DELETE_RULE_ENUM          refDeleteRuleEn = currAttribStp->refDeleteRuleEn;

        /* PMSTA-43103 - LJE - 210107 */
        if (currAttribStp->primFlg == TRUE &&
            currEntityStp->pkEntityStp != nullptr)
        {
            refDeleteRuleEn = RefDelRule_CascadeDelete;
        }

        string fkAttribStr(currAttribStp->sqlName); /* PMSTA-26554 - LJE - 181102 */

        if (fkDictEntityStp->dbPKNbr == 2 &&
            fkDictEntityStp->ownerBusinessEntAttrStp &&
            currEntityStp->ownerBusinessEntAttrStp)
        {
            fkAttribStr += ", ";
            fkAttribStr += currEntityStp->ownerBusinessEntAttrStp->sqlName;
        }

        this->setName(currAttribStp->attrDictId);

        if (currEntityStp->entNatEn != EntityNat_CustomDS &&
            currEntityStp->entNatEn != EntityNat_ModelBank)     /* PMSTA-27352 - LJE - 170606 */
        {
            /* Try to find logical attribute point on current attribute */
            for (auto & attribStp : fkDictEntityStp->logicalTab)
            {
                if (attribStp->linkedAttrDictId == currAttribStp->attrDictId ||
                    (derivedAttribStp != nullptr && attribStp->linkedAttrDictId == derivedAttribStp->attrDictId))  /* PMSTA-26250 - LJE - 170324 */
                {
                    logAttrStp = attribStp;
                    break;
                }
            }

            if (logAttrStp == nullptr && 
                currAttribStp->refDeleteRuleEn == RefDelRule_Inherited)
            {
                for (auto& attribStp : currAttribStp->linkAttrDictTab)
                {
                    if (attribStp->linkedAttrDictId == currAttribStp->attrDictId)
                    {
                        logAttrStp = attribStp;
                        break;
                    }
                }
            }

            if (currAttribStp->refDeleteRuleEn != RefDelRule_Inherited)
            {
                if (logAttrStp != nullptr &&
                    (logAttrStp->refEntDictId == currAttribStp->entDictId ||
                     logAttrStp->refDeleteRuleEn != RefDelRule_NoAction))
                {
                    stringstream msgStream;

                    msgStream << "Mismatch value of reference delete rule between main attribute ("
                        << currAttribStp->sqlName << "=" << refDeleteRuleEn << ") and logical referenced ("
                        << fkDictEntityStp->mdSqlName << "." << logAttrStp->sqlName << "=" << logAttrStp->refDeleteRuleEn << "), the main attribute should be 'Inherited'";

                    gblRet = RET_GEN_ERR_INVARG;
                    this->printMsg(gblRet, msgStream.str());

                    refDeleteRuleEn = RefDelRule_None;
                }
            }
            else if (logAttrStp == NULL)
            {
                stringstream msgStream;

                msgStream << "An attribute (" << currAttribStp->sqlName << ") having reference delete rule set to 'Inherited' must have a linked attribute!";

                gblRet = RET_GEN_ERR_INVARG;
                this->printMsg(gblRet, msgStream.str());

                refDeleteRuleEn = RefDelRule_None;
            }
            else if (logAttrStp->refDeleteRuleEn == RefDelRule_Inherited)
            {
                stringstream msgStream;

                msgStream << "When a attribute (" << currAttribStp->sqlName << ") have reference delete rule set to 'Inherited', the linked attribute cannot having the delete rule set to 'Inherited'!";

                ret = RET_GEN_ERR_INVARG;
                this->printMsg(ret, msgStream.str());

                refDeleteRuleEn = RefDelRule_None;
            }
            else
            {
                refDeleteRuleEn = logAttrStp->refDeleteRuleEn;
            }
        }

        if (refCheckRuleEn == RefChkRule_Checked && refDeleteRuleEn != RefDelRule_None && refDeleteRuleEn != RefDelRule_NoAction)
        {
            DICT_ENTITY_STP realFkDictEntityStp = (fkDictEntityStp->pkEntityStp ? fkDictEntityStp->pkEntityStp : fkDictEntityStp); /* PMSTA-26250 - LJE - 170504 */
            string alterEntityStr = this->getEntitySqlName(currEntityStp, fkTargetTableEn);
            string fkEntityStr = this->getEntitySqlName(realFkDictEntityStp, TargetTable_Main);

            auto fkIt = this->m_AllDbForeignKeySet.find(DdlObjDefKey(this->ddlGenContextPtr->m_rdbmsEn,
                                                                     DdlObj_ForeignKey,
                                                                     currEntityStp->databaseName,
                                                                     currEntityStp->mdSqlName,
                                                                     this->getDdlObjSqlName(),
                                                                     this->getDdlObjSqlName()));

            if (fkDictEntityStp->primKeyNbr > 1)
            {
                gblRet = RET_GEN_ERR_INVARG;
                this->printMsg(gblRet, "Impossible to generate a foreign key on a primary key having more than 1 attribute on primary key: " + string(currAttribStp->sqlName));
            }
            else if (fkDictEntityStp->primKeyNbr == 0)
            {
                gblRet = RET_GEN_ERR_INVARG;
                this->printMsg(gblRet, "Impossible to generate a foreign key on a primary key having no primary key: " + string(currAttribStp->sqlName));
            }
            else if (this->isReferenceOnFk())
            {
                if (fkIt == this->m_AllDbForeignKeySet.end() ||
                    fkIt->second.m_refEntity.compare(fkEntityStr) != 0 ||
                    fkIt->second.m_refDeleteRuleEn != refDeleteRuleEn)
                {
                    this->m_fkCreationStr += this->getCmdCreate(currEntityStp->databaseName,
                                                                alterEntityStr,
                                                                this->getDdlObjSqlName(),
                                                                DdlObj_ForeignKey,
                                                                fkEntityStr,
                                                                fkAttribStr,
                                                                this->m_fkCreationStr.empty());

                    this->setName(currAttribStp->attrDictId);

                    string fullFkTableName = this->getTableFullDbName(realFkDictEntityStp->databaseName, "", fkEntityStr);
                    switch (refDeleteRuleEn)
                    {
                        case RefDelRule_SetNULL:
                            this->m_fkCreationStr += " references " + fullFkTableName + " on delete set null";
                            break;

                        case RefDelRule_CascadeDelete:
                            this->m_fkCreationStr += " references " + fullFkTableName + " on delete cascade";
                            break;

                        case RefDelRule_Restrict:
                            this->m_fkCreationStr += " references " + fullFkTableName;

                            if (this->ddlGenContextPtr->m_rdbmsEn == PostgreSQL)
                            {
                                this->m_fkCreationStr += " on delete restrict";
                            }
                            break;

                        case RefDelRule_None:
                        case RefDelRule_NoAction:
                        default:
                            break;
                    }

                    if (this->ddlGenContextPtr->m_rdbmsEn == Oracle &&
                        bForceOne == false &&
                        this->ddlGenContextPtr->ddlGenAction.m_bOraCreateIdxHint)
                    {
                        this->m_fkCreationStr += " enable novalidate";

                        if (this->m_fkValidateStr.empty())
                        {
                            this->m_fkBeginValidateVec.push_back("alter session enable parallel ddl");
                            this->m_fkBeginValidateVec.push_back("alter table " + alterEntityStr + " parallel");

                            this->m_fkValidateStr += "alter table " + alterEntityStr;

                            this->m_fkEndValidateVec.push_back("alter table " + alterEntityStr + " noparallel");
                            this->m_fkEndValidateVec.push_back("alter session disable parallel ddl");
                        }

                        this->m_fkValidateStr += " enable validate constraint " + this->getDdlObjSqlName() + "\n";
                    }

                    for (auto it = this->m_AllDbForeignKeySet.begin(); it != this->m_AllDbForeignKeySet.end(); ++it)
                    {
                        if (it->second.m_bTreated == false &&
                            (it->second.m_refEntity.compare(realFkDictEntityStp->dbSqlName) == 0 &&
                             it->second.m_refAttributeTab.size() &&
                             it->second.m_refAttributeTab[0].compare(currAttribStp->sqlName) == 0) ||
                            it->second.getObjName().compare(this->getDdlObjSqlName()) == 0)
                        {
                            string dropSameFkStr = this->getCmdDrop(currEntityStp->databaseName,
                                                                    alterEntityStr,
                                                                    it->second.getObjName(),
                                                                    DdlObj_ForeignKey);
                            this->bodySqlBlock << dropSameFkStr;
                            this->cmdType = DDlCmdType_Drop;
                            ret = this->flush();

                            it->second.m_bTreated = true;       /* PMSTA-43367 - LJE - 210430 */

                            if (ret != RET_SUCCEED)
                            {
                                gblRet = ret;
                            }
                            break;
                        }
                    }

                    if (bForceOne)
                    {
                        this->bodySqlBlock << this->m_fkCreationStr;
                    }
                }
            }
            else if (this->ddlGenContextPtr->m_rdbmsEn == Sybase)
            {
                string selObjInDb = this->getCmdSelObjInDb(currEntityStp->databaseName,
                                                           this->getEntitySqlName(currEntityStp, fkTargetTableEn),
                                                           string(),
                                                           DdlObj_ForeignKey,
                                                           string(),
                                                           this->getEntitySqlName(realFkDictEntityStp),
                                                           currAttribStp->sqlName);

                this->bodySqlBlock << this->getCmdIfExsists(selObjInDb,
                                                            "\t" + this->getDdlModif(
                                                                this->getCmdCreate(currEntityStp->databaseName,
                                                                                   this->getEntitySqlName(currEntityStp, fkTargetTableEn),
                                                                                   string(),
                                                                                   DdlObj_ForeignKey,
                                                                                   this->getEntitySqlName(realFkDictEntityStp),
                                                                                   fkAttribStr)),
                                                            string(),
                                                            true);

                this->bodySqlBlock << this->getCmdEndDDLObj() << endl;
            }
            else
            {
                if (fkIt == this->m_AllDbForeignKeySet.end() ||
                    fkIt->second.m_refEntity.compare(fkEntityStr) != 0)
                {
                    for (auto it = this->m_AllDbForeignKeySet.begin(); it != this->m_AllDbForeignKeySet.end(); ++it)
                    {
                        if (it->second.m_bTreated == false &&
                            (it->second.m_refEntity.compare(realFkDictEntityStp->dbSqlName) == 0 &&
                             it->second.m_refAttributeTab.size() &&
                             it->second.m_refAttributeTab[0].compare(currAttribStp->sqlName) == 0) ||
                            it->second.getObjName().compare(this->getDdlObjSqlName()) == 0)
                        {
                            string dropSameFkStr = this->getCmdDrop(currEntityStp->databaseName,
                                                                    alterEntityStr,
                                                                    it->second.getObjName(),
                                                                    DdlObj_ForeignKey);
                            this->bodySqlBlock << dropSameFkStr;
                            this->cmdType = DDlCmdType_Drop;
                            ret = this->flush();

                            it->second.m_bTreated = true;       /* PMSTA-43367 - LJE - 210430 */

                            if (ret != RET_SUCCEED)
                            {
                                gblRet = ret;
                            }
                            break;
                        }
                    }

                    this->m_fkCreationStr += this->getCmdCreate(currEntityStp->databaseName,
                                                                this->getEntitySqlName(currEntityStp, fkTargetTableEn),
                                                                this->getDdlObjSqlName(),
                                                                DdlObj_ForeignKey,
                                                                this->getEntitySqlName(realFkDictEntityStp),
                                                                fkAttribStr);

                    if (bForceOne)
                    {
                        this->bodySqlBlock << this->m_fkCreationStr << this->getCmdEndDDLObj() << endl;
                    }
                }
            }

            /* PMSTA-36158 - LJE - 190627 */
            if (fkIt != this->m_AllDbForeignKeySet.end())
            {
                fkIt->second.m_bTreated = true;
            }

            /* PMSTA-30453 - LJE - 180406 */
            if (gblRet == RET_SUCCEED && this->bodySqlBlock.str().empty() == false)
            {
                this->cmdType = DDlCmdType_Create;

                gblRet = this->flush();

                if (gblRet != RET_SUCCEED)
                {
                    stringstream errorMsg;

                    errorMsg << "Unable to create foreign key: \"" + this->m_fkCreationStr + "\"";

                    this->printMsg(gblRet, errorMsg.str());

                    if (this->isReferenceOnFk())
                    {
                        /* select * from D_TAP_ORA10_MAINDB.XD_PERM_VALUE xpv where not exists (select 1 from D_TAP_ORA10_MAINDB.xd_attribute xa where xpv.xd_attrib_id = xa.id); */

                        errorMsg
                            << endl << "Please execute the following command to find the issue:" << endl << endl
                            << "select * from "
                            << this->getEntitySqlName(currEntityStp, fkTargetTableEn)
                            << " " << currEntityStp->aliasSqlname << "_fk"
                            << " where ";

                        if (currAttribStp->dbMandatoryFlg == FALSE)
                        {
                            errorMsg
                                << currEntityStp->aliasSqlname << "_fk." << currAttribStp->sqlName << " is not null and ";
                        }

                        errorMsg
                            << " not exists(select 1 from "
                            << this->getEntitySqlName(realFkDictEntityStp) << " " << realFkDictEntityStp->aliasSqlname
                            << " where " << currEntityStp->aliasSqlname << "_fk." << currAttribStp->sqlName
                            << " = " << realFkDictEntityStp->aliasSqlname << "." << realFkDictEntityStp->primKeyTab[0]->sqlName << ")"
                            << this->endOfCmd() << endl;

                        SYS_SetThreadCallStackGeneration(false);
                        MSG_LogMesg(RET_GEN_ERR_PERSONAL,
                                    1,
                                    this->fileHelper->outputFileStr.c_str(),
                                    this->fileHelper->outFileLinePos,
                                    errorMsg.str().c_str());
                        SYS_SetThreadCallStackGeneration(true);

                        gblRet = RET_SUCCEED;   /* PMSTA-43367 - LJE - 210427 - To be able to continue the process, that would be managed by the customer after the installation */
                    }
                }
            }
        }
    }

    if (this->isAllowMultiAlterTable() == false)
    {
        this->m_fkCreationStr.clear();
    }

    return gblRet;
}

/************************************************************************
**
**  Function    :   DdlGenFK::drop()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:  PMSTA-13109 - LJE - 111116
**
*************************************************************************/
RET_CODE DdlGenFK::drop()
{
    RET_CODE ret = RET_SUCCEED, gblRet = RET_SUCCEED;

    this->cmdType = DDlCmdType_Drop;
    this->clear();

    if (this->ddlGenContextPtr->bSimulation)
    {
        this->bodySqlBlock
            << DdlGenDbi::getCmdPrintMsg("Dropping foreign keys " + this->getDdlObjSqlName(), false) << endl
            << DdlGenDbi::getCmdGo() << endl;
    }

    DICT_ENTITY_STP locDictEntityStp = this->getDictEntityStp();

    for (auto& dictAttribStp : locDictEntityStp->attr)
    {
        if (this->isFKAttrib(dictAttribStp))
        {
            ret = this->dropOneFK(dictAttribStp);

            if (ret != RET_SUCCEED)
                gblRet = ret;
        }
    }

    return gblRet;
}

/************************************************************************
**
**  Function    :   DdlGenFK::create()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:  PMSTA-13109 - LJE - 111116
**
*************************************************************************/
RET_CODE DdlGenFK::create()
{
    RET_CODE ret = RET_SUCCEED, gblRet = RET_SUCCEED;
    this->cmdType = DDlCmdType_Create;
    this->clear();

    DICT_ENTITY_STP locDictEntityStp = this->getDictEntityStp();

    for (auto& dictAttribStp : locDictEntityStp->attr)
    {
        if (this->isFKAttrib(dictAttribStp))
        {
            ret = this->createOneFK(dictAttribStp, false);

            if (ret != RET_SUCCEED)
            {
                gblRet = ret;

                if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
                {
                    this->printMsg(ret, "Create foreign key " + this->getDdlObjSqlName() + " skipped");
                }
                else
                {
                    this->printMsg(ret, "Create foreign key " + this->getDdlObjSqlName() + " failed");
                }
            }
        }
    }

    if (this->m_fkCreationStr.empty() == false)
    {
        this->bodySqlBlock << this->m_fkCreationStr;

        if (this->bodySqlBlock.str().empty() == false)
        {
            this->cmdType = DDlCmdType_Create;
            ret = this->flush();

            if (ret != RET_SUCCEED)
            {
                this->m_fkCreationStr.clear();

                for (auto& dictAttribStp : locDictEntityStp->attr)
                {
                    if (this->isFKAttrib(dictAttribStp))
                    {
                        ret = this->createOneFK(dictAttribStp, true);

                        if (ret != RET_SUCCEED)
                        {
                            gblRet = ret;
                        }
                    }
                }
            }
            else if (this->m_fkValidateStr.empty() == false)
            {
                for (auto it = this->m_fkBeginValidateVec.begin(); it != this->m_fkBeginValidateVec.end(); ++it)
                {
                    this->bodySqlBlock << (*it);
                    this->cmdType = DDlCmdType_DbProcess;
                    (void)this->flush();
                }
                this->bodySqlBlock << this->m_fkValidateStr;
                this->cmdType = DDlCmdType_Create;
                ret = this->flush();

                for (auto it = this->m_fkEndValidateVec.begin(); it != this->m_fkEndValidateVec.end(); ++it)
                {
                    this->bodySqlBlock << (*it);
                    this->cmdType = DDlCmdType_DbProcess;
                    (void)this->flush();
                }
            }
        }
    }

    if (this->ddlGenContextPtr->m_rdbmsEn != Sybase)
    {
        /* PMSTA-36158 - LJE - 190627 */
        for (auto fkIt = this->m_AllDbForeignKeySet.begin(); fkIt != this->m_AllDbForeignKeySet.end(); ++fkIt)
        {
            if (fkIt->second.m_bTreated == false)
            {
                string dropFkStr = this->getCmdDrop(locDictEntityStp->databaseName,
                                                    fkIt->second.getEntitySqlName(),
                                                    fkIt->second.getDbObjName(),
                                                    DdlObj_ForeignKey,
                                                    nullptr,
                                                    fkIt->first.getDbObjName(),
                                                    string());
                this->bodySqlBlock << dropFkStr;

                this->cmdType = DDlCmdType_DbProcess;
                ret = this->flush();
                if (ret != RET_SUCCEED)
                {
                    gblRet = ret;
                }
            }
        }
    }

    return gblRet;
}

/************************************************************************
**
**  Function    :   DdlGenFK::dropByRefEntity()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:  PMSTA-13109 - LJE - 111116
**
*************************************************************************/
RET_CODE DdlGenFK::dropByRefEntity()
{
    RET_CODE ret = RET_SUCCEED, gblRet = RET_SUCCEED;
    DICT_T   currEntDictId = this->getDictEntityStp()->entDictId;

    this->cmdType = DDlCmdType_Drop;
    this->clear();

    if (this->ddlGenContextPtr->bSimulation)
    {
        this->bodySqlBlock
            << DdlGenDbi::getCmdPrintMsg("Dropping foreign keys " + this->getDdlObjSqlName(), false) << endl
            << DdlGenDbi::getCmdGo() << endl;
    }

    for (OBJECT_ENUM objEn = NullEntity; objEn < LASTENTITYOBJECT; objEn++)
    {
        DICT_ENTITY_STP refDictEntityStp = DBA_GetDictEntitySt(objEn);

        if (refDictEntityStp != NULL && this->isFKOnEntity(refDictEntityStp))
        {
            for (auto& refDictAttribStp : refDictEntityStp->attr)
            {
                if (this->isFKAttrib(refDictAttribStp))
                {
                    if (refDictAttribStp->refEntDictId == currEntDictId)
                    {
                        ret = this->dropOneFK(refDictAttribStp);

                        if (ret != RET_SUCCEED)
                        {
                            gblRet = ret;
                        }
                    }
                }
            }
        }
    }

    return gblRet;
}

/************************************************************************
**
**  Function    :   DdlGenFK::createByRefEntity()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:  PMSTA-13109 - LJE - 111116
**
*************************************************************************/
RET_CODE DdlGenFK::createByRefEntity()
{
    RET_CODE ret = RET_SUCCEED, gblRet = RET_SUCCEED;
    DICT_T   currEntDictId = this->getDictEntityStp()->entDictId;

    this->cmdType = DDlCmdType_Create;
    this->clear();

    for (OBJECT_ENUM objEn = NullEntity; objEn < LASTENTITYOBJECT; objEn++)
    {
        DICT_ENTITY_STP refDictEntityStp = DBA_GetDictEntitySt(objEn);

        if (refDictEntityStp != NULL && this->isFKOnEntity(refDictEntityStp))
        {
            for (auto& refDictAttribStp : refDictEntityStp->attr)
            {
                if (this->isFKAttrib(refDictAttribStp))
                {
                    if (refDictAttribStp->refEntDictId == currEntDictId)
                    {
                        ret = this->createOneFK(refDictAttribStp, true);

                        if (ret != RET_SUCCEED)
                        {
                            gblRet = ret;
                        }
                    }
                }
            }
        }
    }

    return gblRet;
}

/************************************************************************
**
**  Function    :   DdlGenFK::grant()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenFK::grant()
{
    RET_CODE            ret = RET_SUCCEED;

    this->cmdType = DDlCmdType_Grant;

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenFK::build()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenFK::build()
{
    RET_CODE ret = RET_SUCCEED;

    if ((ret = DdlGen::build()) != RET_SUCCEED)
    {
        this->printMsg(ret, "Create foreign key(s) failed");
        return ret;
    }

    this->setName();

    MSG_LogSrvMesg(UNUSED, UNUSED, "Create foreign key(s) on table %1",
                   SysnameType, this->getDdlObjSqlName().c_str());

    if (this->ddlGenContextPtr->bForceReBuild && 
        this->ddlGenContextPtr->ddlGenAction.m_mainDdlObjNatEn == DbObjDdlObjNat_ForeignKey)
    {
        ret = this->drop();
    }

    if (this->ddlGenContextPtr->bGenFromDbi)
    {
        ret = RET_GEN_INFO_NOACTION;
    }
    else
    {
        this->getAllDdlObjListFromDb(this->m_AllDbForeignKeySet,
                                     this->ddlGenContextPtr->getDdlDestDbName(),
                                     this->getDictEntityStp()->dbSqlName,
                                     std::string(),
                                     DdlObj_ForeignKey);

        /* PMSTA-36158 - LJE - 190613 */
        if (this->getDictEntityStp()->custAuthFlg == TRUE)
        {
            this->getAllDdlObjListFromDb(this->m_AllDbForeignKeySet,
                                         this->ddlGenContextPtr->getDdlDestDbName(),
                                         this->getEntitySqlName(this->getDictEntityStp(), TargetTable_UserDefinedFields),
                                         std::string(),
                                         DdlObj_ForeignKey);
        }
    }

    if (ret != RET_SUCCEED ||
        (ret = this->create()) != RET_SUCCEED ||
        (ret = this->grant()) != RET_SUCCEED)
    {
        if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
        {
            this->printMsg(ret, "Create foreign key(s) skipped");
        }
        else
        {
            this->printMsg(ret, "Create foreign key(s) failed");
        }
        return ret;
    }

    MSG_LogSrvMesg(UNUSED, UNUSED, "The foreign key(s) on table %1 created successfully",
                   SysnameType, this->getDdlObjSqlName().c_str());
    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenFK::printFooter()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 111116
**
*************************************************************************/
RET_CODE DdlGenFK::printFooter()
{
    RET_CODE ret = RET_SUCCEED;

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenFK::isFKOnEntity()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 111116
**
*************************************************************************/
bool DdlGenFK::isFKOnEntity(DICT_ENTITY_STP dictEntityStp)
{
    if (dictEntityStp == nullptr)
    {
        return false;
    }

    bool bFk = false;

    if (GET_BIT(dictEntityStp->automaticMask, Automatic_Table) == TRUE &&
        dictEntityStp->isPhysicalEntity(TargetTable_Main))
    {
        if (dictEntityStp->entNatEn == EntityNat_SearchFmt ||
            dictEntityStp->entNatEn == EntityNat_ReportFmt ||
            dictEntityStp->entNatEn == EntityNat_TempTable)
        {
            bFk = false;
        }
        else
        {
            bFk = true;
        }
    }
    else
    {
        bFk = false;
    }

    return bFk;
}

/************************************************************************
**
**  Function    :   DdlGenFK::getPrimaryKey()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:  PMSTA-14452 - LJE - 121105
**
*************************************************************************/
string DdlGenFK::getPrimaryKey()
{
    string pkStr;

    if (this->targetTableEn == TargetTable_Main)
    {
        int i;
        for (i = 0; i < this->getDictEntityStp()->dbPKNbr; i++)
        {
            if (i != 0)
            {
                pkStr += ", ";
            }
            pkStr += this->getDictEntityStp()->dbPKTab[i]->sqlName;
        }
    }
    else if (this->targetTableEn == TargetTable_UserDefinedFields)
    {
        pkStr = DdlGen::getUdIdSqlName();
    }
    else if (this->targetTableEn == TargetTable_Precomp)
    {
        pkStr = "x_id";
    }
    return pkStr;
}

/************************************************************************
**
**  Function    :   DdlGenFK::createPk()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:  PMSTA-13109 - LJE - 111116
**
*************************************************************************/
RET_CODE DdlGenFK::createPk()
{
    RET_CODE ret = RET_SUCCEED;

    if (this->getDictEntityStp()->isPkToDo(this->targetTableEn) == false)
    {
        return ret;
    }

    this->setDdlObjEn(DdlObj_PrimaryKey);
    this->cmdType = DDlCmdType_Create;
    this->clear();

    std::map<DdlObjDefKey, DdlObjDef>  primaryKeyDefMap;
    bool                               pkToCreate = this->ddlGenContextPtr->m_parentContext->bCreatePK;

    if (EV_GenDdlContext.bSqlFileOnly)
    {
        this->bodySqlBlock
            << this->getCmdPrintMsg("Creating primary key of table " + this->getEntitySqlName(), false) << endl
            << this->getCmdGo() << endl;
        ret = this->flush();
    }
    else
    {

        DdlObjDefKey searchDdlObjDefKey(this->ddlGenContextPtr->m_rdbmsEn,
                                        DdlObj_PrimaryKey,
                                        this->ddlGenContextPtr->getDdlDestDbName(),
                                        this->getEntitySqlName(),
                                        this->getEntitySqlName(),
                                        std::string());

        DdlGenDbaAccessGuard ddlGenDbaAccessGuard(*this->ddlGenContextPtr);
        auto primaryKey = ddlGenDbaAccessGuard.getDdlGenDbaAccess().getDdlObjDef(searchDdlObjDefKey);

        if (primaryKey != nullptr)
        {
            pkToCreate = false;

            if (primaryKey->check() == false ||
                primaryKey->m_isClustered != this->ddlGenContextPtr->m_parentContext->bUseClusterIdx ||
                this->ddlGenContextPtr->m_parentContext->bCreatePK == false)
            {
                pkToCreate = this->ddlGenContextPtr->m_parentContext->bCreatePK;

                this->bodySqlBlock << this->getCmdDrop(this->ddlGenContextPtr->getDdlDestDbName(), 
                                                       this->getEntitySqlName(), 
                                                       (primaryKey->getDbObjName() != primaryKey->getTableSqlName() ? primaryKey->getDbObjName() : this->ddlGenEntityPtr->getPkSqlName(this->targetTableEn)),
                                                       DdlObj_PrimaryKey);
                this->cmdType = DDlCmdType_Drop;
                ret = this->flush("Drop primary key");

                ddlGenDbaAccessGuard.getDdlGenDbaAccess().eraseDdlObjDef(*primaryKey);
            }
            else if (primaryKey->m_bValidated == false)
            {
                /* Enable the primary key of the current entity */
                this->bodySqlBlock << this->getCmdChangeState(this->ddlGenContextPtr->getDdlDestDbName(), this->getEntitySqlName(), string(), DdlObj_PrimaryKey, false);
                this->cmdType = DDlCmdType_DbProcess;
                ret = this->flush("Enable primary key");
            }
        }
    }

    if (this->getDictEntityStp()->primKeyNbr > 0 && pkToCreate)
    {
        if (this->ddlGenContextPtr->bGenFromDbi)
        {
            this->bodySqlBlock << this->getCmdIfExsists(this->getCmdSelObjInDb(this->ddlGenContextPtr->getDdlDestDbName(), this->getEntitySqlName(), this->ddlGenEntityPtr->getPkSqlName(this->targetTableEn), DdlObj_PrimaryKey),
                                                        "\t" + this->getDdlModif(this->getCmdCreate(this->ddlGenContextPtr->getDdlDestDbName(),
                                                                                                    this->getEntitySqlName(),
                                                                                                    this->ddlGenEntityPtr->getPkSqlName(this->targetTableEn),
                                                                                                    DdlObj_PrimaryKey,
                                                                                                    string(),
                                                                                                    this->getPrimaryKey())),
                                                        string(), true);
        }
        else
        {
            this->bodySqlBlock << this->getCmdCreate(this->ddlGenContextPtr->getDdlDestDbName(),
                                                     this->getEntitySqlName(),
                                                     this->ddlGenEntityPtr->getPkSqlName(this->targetTableEn),
                                                     DdlObj_PrimaryKey,
                                                     string(),
                                                     this->getPrimaryKey());

            DdlObjDefKey ddlObjDefKey(this->ddlGenContextPtr->m_rdbmsEn,
                                      DdlObj_PrimaryKey,
                                      this->ddlGenContextPtr->getDdlDestDbName(),
                                      this->getEntitySqlName(),
                                      this->getEntitySqlName(),
                                      this->getDdlObjSqlName());

            DdlGenDbaAccessGuard ddlGenDbaAccessGuard(*this->ddlGenContextPtr);
            ddlGenDbaAccessGuard.getDdlGenDbaAccess().addDdlObjDefByKey(ddlObjDefKey);
        }

        this->cmdType = DDlCmdType_Create;
        ret = this->flush("Create primary key");
    }

    this->setDdlObjEn(DdlObj_ForeignKey);

    return ret;
}

/*************************************************************************
**   END  ddlgenfk.cpp                                        Odyssey **
*************************************************************************/

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DBAFMT_C

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H

#include "unidef.h"     /* Mandatory */
#include "gen.h"
#include "dba.h"
#include "dbafmt.h"
#include "fin.h"
#include "proc.h"
#include "cmp.h"
#include "ope.h"		/*  FIH-REF10606-040927 for function OPE_GetOpTableFromDynFld   */
#include "casemgt.h"	/* PMSTA10444-CHU-110504 */
#include "dbiconnection.h"
#include "ddlgen.h"

#ifndef TLS_H
#include "tls.h"
#endif

#ifndef HIER_H
#include "hier.h"
#endif

#include "scptyl.h"

#ifdef NT
#include <crtdbg.h>
#endif

/************************************************************************
**      External entry points
**
** DBA_InsFmtById()
** DBA_UpdFmt()
** DBA_DelFmt()
** DBA_InsFmtEltById()
** DBA_UpdFmtElt()
** DBA_DelFmtElt()
**
*************************************************************************/

/************************************************************************
**      Local functions
**
** DBA_CreateXdEntityFromFmt()
** DBA_CreateXdAttribFromFmtElt()
**
*************************************************************************/

/************************************************************************
**      Static definitions & data
*************************************************************************/

STATIC RET_CODE DBA_CreateXdEntityFromFmt(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_ACTION_ENUM, DbiConnectionHelper &);      /* PMSTA13876 - DDV - 130806 */

/************************************************************************
**      FONCTIONS
************************************************************************/

/************************************************************************
**  Function    :   DBA_CopyFmtToXd
**
**  Description :   Copy all format to xd model
**
**  Arguments   :   fmtCd         Format code
**
**  Return      :   RET_SUCCEED if success, or error code
**
**  Creation	:   PMSTA-22072 - LJE - 160108
**
*************************************************************************/
RET_CODE DBA_CopyFmtToXd(DBA_DYNFLD_STP shXdEntityStp, DdlGenContext &ddlGenContext)
{
    RET_CODE       retCode = RET_SUCCEED;
    MemoryPool     mp;

    std::string msg = SYS_Stringer("Creation of data model for format: ", GET_SYSNAME(shXdEntityStp, S_XdEntity_SqlName));

    ddlGenContext.printMsg(RET_SRV_INFO_RUNNING, msg);

    DdlGenConnGuard     ddlGenConnGuard(ddlGenContext);
    DbiConnectionHelper dbiConnHelper(&ddlGenConnGuard.getDbiConn());

    if (dbiConnHelper.isValidAndInit() == false)
    {
        MSG_DispMesg(RET_DBA_ERR_CONNOTFOUND, NULL, NULL);
        return(RET_DBA_ERR_CONNOTFOUND);
    }

    /* Create or update the xd_entity */
    DdlGenDbaAccessGuard ddlGenDbaAccessGuard(ddlGenContext);

    /* Create or update the xd_entity */
    DBA_ACTION_ENUM action = Insert;
    DBA_DYNFLD_STP  xdEntityRec = ddlGenDbaAccessGuard.getDdlGenDbaAccess().allocDynSt(FILEINFO, A_XdEntity);
    DBA_DYNFLD_STP  sFmtRec = mp.allocDynst(FILEINFO, S_Fmt);
    DBA_DYNFLD_STP  aFmtRec = mp.allocDynst(FILEINFO, A_Fmt);
    bool            bFmtFound = false;

    COPY_DYNFLD(sFmtRec, S_Fmt, S_Fmt_Cd, shXdEntityStp, S_XdEntity, S_XdEntity_SqlName);
    dbiConnHelper.dbaSetOptions(DBA_SET_CONN | DBA_NO_CLOSE);
    if (dbiConnHelper.dbaGet(Fmt, UNUSED, sFmtRec, &aFmtRec) == RET_SUCCEED)
    {
        bFmtFound = true;
        CONVERT_DYNST(sFmtRec, S_Fmt, aFmtRec, A_Fmt);
    }

    /* load xdEntity record, if not found, create a new one */
    retCode = dbiConnHelper.dbaGet(XdEntity, UNUSED, shXdEntityStp, &xdEntityRec);

    /* PMSTA-31054 - DDV - 180419 - If data has been return by optimisation, try to load it directly from db */
    if (retCode == RET_DBA_INFO_NODATAWITHOPTI)
        retCode = dbiConnHelper.dbaGet(XdEntity, DBA_ROLE_NO_OPTI, shXdEntityStp, &xdEntityRec);

    if (retCode == RET_SUCCEED)
    {
        action = Update;
    }
    else if (bFmtFound == false)
    {
        MSG_LogMesg(RET_DBA_ERR_NODATA, 4, FILEINFO, "format", GET_SYSNAME(shXdEntityStp, S_XdEntity_SqlName));
        MSG_RETURN(RET_DBA_ERR_NODATA);
    }

    DBA_DYNFLD_STP* aFmtEltTab = NULLDYNSTPTR;
    int             fmtEltNbr = 0;

    /* select all format element and create all xd_attribute */
    if (bFmtFound &&
        (dbiConnHelper.dbaSelect(FmtElt, UNUSED, sFmtRec, A_FmtElt, &aFmtEltTab, &fmtEltNbr) != RET_SUCCEED ||
         fmtEltNbr == 0))
    {
        bFmtFound = false;
    }
    else
    {
        mp.ownerDynStpTab(aFmtEltTab, fmtEltNbr);
    }

    if (bFmtFound)
    {
        SET_ENUM(shXdEntityStp, S_XdEntity_XdActionEn, XdAction_ToInsert);

        if ((retCode = DBA_CreateXdEntityFromFmt(aFmtRec, xdEntityRec, action, dbiConnHelper)) != RET_SUCCEED)
        {
            return(retCode);
        }
    }
    else if (action == Insert)
    {
        MSG_LogMesg(RET_DBA_ERR_NODATA, 4, FILEINFO, "format element", GET_SYSNAME(shXdEntityStp, S_XdEntity_SqlName));
        MSG_RETURN(RET_DBA_ERR_NODATA);
    }
    else
    {
        SET_ENUM(shXdEntityStp, S_XdEntity_XdActionEn, XdAction_ToPhysicallyDelete);

        SET_ENUM(xdEntityRec, A_XdEntity_XdActionEn, XdAction_ToPhysicallyDelete);
        COPY_DYNFLD(shXdEntityStp, S_XdEntity, S_XdEntity_XdStatusEn, xdEntityRec, A_XdEntity, A_XdEntity_XdStatusEn);
    }

    /* insert it into database */
    if (action == Update)
    {
        retCode = dbiConnHelper.dbaUpdate(XdEntity, UNUSED, xdEntityRec);
    }
    else
    {
        retCode = dbiConnHelper.dbaInsert(XdEntity, UNUSED, xdEntityRec);
    }

    if (retCode == RET_SUCCEED && bFmtFound)
    {
        /* PMSTA-46681 - LJE - 231201 - Sorting rank management */
        std::vector<DBA_DYNFLD_STP> sortFmtEltVector;
        for (int i = 0; i < fmtEltNbr; i++)
        {
            if (IS_NOTNULL(aFmtEltTab[i], A_FmtElt_SortRank))
            {
                sortFmtEltVector.push_back(aFmtEltTab[i]);
            }
        }
        if (sortFmtEltVector.empty() == false)
        {
            std::sort(sortFmtEltVector.begin(), sortFmtEltVector.end(),
                      [](const DBA_DYNFLD_STP &a, const DBA_DYNFLD_STP &b) -> bool
                      {
                          int iCmp = CMP_DYNFLD(a, b, A_FmtElt_SortRank, A_FmtElt_SortRank, SmallintType);
                          if (iCmp < 0)
                          {
                              return true;
                          }
                          if (iCmp != 0)
                          {
                              return false;
                          }
                          return GET_SMALLINT(a, A_FmtElt_Rank) < GET_SMALLINT(b, A_FmtElt_Rank);
                      });

            SMALLINT_T sortRank = 1;
            for (auto &it : sortFmtEltVector)
            {
                SET_SMALLINT(it, A_FmtElt_SortRank, sortRank++);
            }
        }

        DBA_DYNFLD_STP sXdAttribRec = mp.allocDynst(FILEINFO, S_XdAttrib);
        DBA_DYNFLD_STP xdAttribRec = mp.allocDynst(FILEINFO, A_XdAttrib);

        SET_ID(sXdAttribRec, S_XdAttrib_XdEntityId, GET_ID(xdEntityRec, A_XdEntity_Id));

        INT_T attribProgN = 10;
        for (int i = 0; i < fmtEltNbr && retCode == RET_SUCCEED; i++)
        {
            SET_SYSNAME(sXdAttribRec, S_XdAttrib_SqlName, GET_CODE(aFmtEltTab[i], A_FmtElt_SqlName));

            /* load xdAttrib record, if not found, create a new one */
            if (dbiConnHelper.dbaGet(XdAttrib, UNUSED, sXdAttribRec, &xdAttribRec) == RET_SUCCEED)
            {
                action = Update;
            }
            else
            {
                action = Insert;
            }

            /* convert fmt to xd_entity record */
            if ((retCode = DBA_CreateXdAttribFromFmtElt(dbiConnHelper, aFmtEltTab[i], xdAttribRec, sFmtRec, xdEntityRec, attribProgN, action)) != RET_SUCCEED)
            {
                dbiConnHelper.rollback();
                return(retCode);
            }

            /* update it in database */
            if (action == Update)
            {
                retCode = dbiConnHelper.dbaUpdate(XdAttrib, UNUSED, xdAttribRec);
            }
            else
            {
                retCode = dbiConnHelper.dbaInsert(XdAttrib, UNUSED, xdAttribRec);
            }
        }
    }

    if (retCode == RET_SUCCEED)
    {
        dbiConnHelper.commit();
    }
    else
    {
        dbiConnHelper.rollback();
    }

    return(retCode);
}

/************************************************************************
**  Function    :   DBA_GetXdFromFmt
**
**  Description :   Get xd model from format
**
**  Arguments   :   fmtCd         Format code
**
**  Return      :   RET_SUCCEED if success, or error code
**
**  Creation	:   PMSTA-37366 - LJE - 200309
**
*************************************************************************/
RET_CODE DBA_GetXdFromFmt(DbiConnectionHelper         &dbiConnHelper,
                          const char                  *fmtCd,
                          DBA_DYNFLD_STP              &xdEntityRec,
                          std::vector<DBA_DYNFLD_STP> &xdAttribVector,
                          MemoryPool                  &mp)
{
    RET_CODE       retCode = RET_SUCCEED;
    DBA_DYNFLD_STP sFmtRec, aFmtRec, *aFmtEltTab = NULLDYNSTPTR;
    int            fmtEltNbr = 0, i = 0;

    if (dbiConnHelper.isValidAndInit() == false)
    {
        MSG_DispMesg(RET_DBA_ERR_CONNOTFOUND, NULL, NULL);
        return(RET_DBA_ERR_CONNOTFOUND);
    }

    dbiConnHelper.beginTransaction();

    xdEntityRec = mp.allocDynst(FILEINFO, A_XdEntity);
    aFmtRec = mp.allocDynst(FILEINFO, A_Fmt);
    sFmtRec = mp.allocDynst(FILEINFO, S_Fmt);

    SET_CODE(sFmtRec, S_Fmt_Cd, fmtCd);
    if (dbiConnHelper.dbaGet(Fmt, UNUSED, sFmtRec, &aFmtRec) != RET_SUCCEED)
    {
        MSG_LogMesg(RET_DBA_ERR_NODATA, 4, FILEINFO, "format", fmtCd);
        MSG_RETURN(RET_DBA_ERR_NODATA);
    }

    retCode = DBA_CreateXdEntityFromFmt(aFmtRec, xdEntityRec, NullAction, dbiConnHelper);

    if (retCode == RET_SUCCEED)
    {
        INT_T attribProgN = 10;

        /* select all format element and create all xd_attribute */
        CONVERT_DYNST(sFmtRec, S_Fmt, aFmtRec, A_Fmt);
        if ((dbiConnHelper.dbaSelect(FmtElt, UNUSED, sFmtRec, A_FmtElt, &aFmtEltTab, &fmtEltNbr)) == RET_SUCCEED)
        {
            for (i = 0; i < fmtEltNbr && retCode == RET_SUCCEED; i++)
            {
                DBA_DYNFLD_STP xdAttribRec = mp.allocDynst(FILEINFO, A_XdAttrib);
                xdAttribVector.push_back(xdAttribRec);

                /* convert fmt to xd_entity record */
                if ((retCode = DBA_CreateXdAttribFromFmtElt(dbiConnHelper, aFmtEltTab[i], xdAttribRec, sFmtRec,xdEntityRec, attribProgN, NullAction)) != RET_SUCCEED)
                {
                    dbiConnHelper.endTransaction(false);
                    DBA_FreeDynStTab(aFmtEltTab, fmtEltNbr, A_FmtElt);
                    return(retCode);
                }
            }
            DBA_FreeDynStTab(aFmtEltTab, fmtEltNbr, A_FmtElt);
        }
    }


    dbiConnHelper.endTransaction(retCode == RET_SUCCEED);

    return(retCode);
}

/************************************************************************
**  Function    :   DBA_InsFmtById
**
**  Description :   Create a new format.
**
**  Arguments   :   object        will be Fmt.
**  		        inputSt 	  A_Fmt.
**                  inputData     A_Fmt data.
**                  connectNo     Connection number.
**                  msgStructPtr  Kind of error message.
**
**  Return      :   RET_SUCCEED if success, or error code
**
**  Creation	:   PMSTA13876 - DDV - 130806
**
*************************************************************************/
RET_CODE DBA_InsFmtById(OBJECT_ENUM          object,
                        DBA_DYNST_ENUM       inputSt,
                        DBA_DYNFLD_STP       inputData,
                        DbiConnectionHelper& dbiConnHelper)
{
    RET_CODE       retCode = RET_SUCCEED;
    unsigned int length = 0;

    length = SYS_StrLen(GET_SYSNAME(inputData, A_Fmt_TableName));
    if (strcspn(GET_SYSNAME(inputData, A_Fmt_TableName), DBA_FORBIDEN_SYSNAME) != length)
    {
        char *tmp = MSG_BuildMesg(UNUSED,
            "ERR_FORBIDDEN_CHAR",
            UNUSED,
            CodeType,
            (GET_CODE(inputData, A_Fmt_TableName))
        );
        std::string buffer(tmp);
        buffer += " Forbidden Characters in table_name are  ";
        buffer += DBA_FORBIDEN_SYSNAME;
        FREE(tmp);

        MSG_DispMsgText(RET_GEN_ERR_INVARG, buffer.c_str());
        return(RET_GEN_ERR_INVARG);
    }

    /* Check arguments */
    if (inputData == NULL)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_InsFmtById", "inputData");
        return(RET_GEN_ERR_INVARG);
    }

    if (GET_ENUM(inputData, A_Fmt_NatEn) == FmtNat_Persisted ||
        GET_ENUM(inputData, A_Fmt_NatEn) == FmtNat_SearchData)  /*  PMSTA-16528 - DDV - 140625 - Add new format and entity nature for search table */
    {
        MemoryPool      mp;
        DBA_DYNFLD_STP xdEntityRec = mp.allocDynst(FILEINFO, A_XdEntity);
        DBA_DYNFLD_STP sXdEntityRec = mp.allocDynst(FILEINFO, S_XdEntity);

        SET_SYSNAME(sXdEntityRec, S_XdEntity_SqlName, GET_CODE(inputData, A_Fmt_Cd));

        /* load xdEntity record, if not found, create a new one */
        retCode = dbiConnHelper.dbaGet(XdEntity, UNUSED, sXdEntityRec, &xdEntityRec);

        /* PMSTA-31054 - DDV - 180419 - If data has been return by optimisation, try to load it directly from db */
        if (retCode == RET_DBA_INFO_NODATAWITHOPTI)
        {
            retCode = dbiConnHelper.dbaGet(XdEntity, DBA_ROLE_NO_OPTI, sXdEntityRec, &xdEntityRec);
        }

        if (retCode == RET_SUCCEED)
        {
            SET_ENUM(sXdEntityRec, S_XdEntity_XdActionEn, XdAction_ToInsert);
            retCode = dbiConnHelper.dbaUpdate(XdEntity, UNUSED, sXdEntityRec);
        }
        else
        {
            if ((retCode = DBA_CreateXdEntityFromFmt(inputData, xdEntityRec, Insert, dbiConnHelper)) != RET_SUCCEED)
        {
            return(retCode);
        }

            retCode = dbiConnHelper.dbaInsert(XdEntity, UNUSED, xdEntityRec);
        }
    }

    /***** INSERT STANDARD PAR PROC STOCKEE SQL *****/
    if (retCode == RET_SUCCEED)
    {
        retCode = dbiConnHelper.dbaInsert(object, DBA_ROLE_USESTOREDPROC, inputData);
    }

    return retCode;
}

/************************************************************************
**  Function    :   DBA_UpdFmt
**
**  Description :   Update an existing format.
**
**  Arguments   :   object        will be Fmt.
**  		        inputSt 	  A_Fmt.
**                  inputData     A_Fmt data.
**                  connectNo     Connection number.
**                  msgStructPtr  Kind of error message.
**
**  Return      :   RET_SUCCEED if success, or error code
**
**  Creation	:   PMSTA13876 - DDV - 130806
**
*************************************************************************/
RET_CODE DBA_UpdFmt(OBJECT_ENUM          object,
                    DBA_DYNST_ENUM       inputSt,
                    DBA_DYNFLD_STP       inputData,
                    DbiConnectionHelper& dbiConnHelper)
{
    RET_CODE         retCode = RET_SUCCEED;

    /* Check arguments */
    if (inputData == NULL)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_UpdFmt", "inputData");
        return(RET_GEN_ERR_INVARG);
    }

    MemoryPool mp;
    DBA_DYNFLD_STP sXdEntityRec = mp.allocDynst(FILEINFO, S_XdEntity);

    SET_SYSNAME(sXdEntityRec, S_XdEntity_SqlName, GET_CODE(inputData, S_Fmt_Cd));

    if(GET_ENUM(inputData, A_Fmt_NatEn) == FmtNat_Persisted ||
       GET_ENUM(inputData, A_Fmt_NatEn) == FmtNat_SearchData) /* PMSTA-16528 - DDV - 140625 - Add new format and entity nature for search table */
    {
        DBA_DYNFLD_STP xdEntityRec = mp.allocDynst(FILEINFO, A_XdEntity);

        /* load xdEntity record, if not found, create a new one */
        retCode = dbiConnHelper.dbaGet(XdEntity, UNUSED, sXdEntityRec, &xdEntityRec);

        /* PMSTA-31054 - DDV - 180419 - If data has been return by optimisation, try to load it directly from db */
        if (retCode == RET_DBA_INFO_NODATAWITHOPTI)
        {
            retCode = dbiConnHelper.dbaGet(XdEntity, DBA_ROLE_NO_OPTI, sXdEntityRec, &xdEntityRec);
        }

        DBA_ACTION_ENUM  action = Insert;
        if (retCode == RET_SUCCEED)
        {
            action = Update;
        }

        /* update it in database */
        if (action == Update)
        {
            SET_ENUM(sXdEntityRec, S_XdEntity_XdActionEn, XdAction_ToInsert);
            retCode = dbiConnHelper.dbaUpdate(XdEntity, UNUSED, sXdEntityRec);
        }
        else
        {
            if ((retCode = DBA_CreateXdEntityFromFmt(inputData, xdEntityRec, action, dbiConnHelper)) != RET_SUCCEED)
            {
                return(retCode);
            }

            retCode = dbiConnHelper.dbaInsert(XdEntity, UNUSED, xdEntityRec);
        }
    }

    /***** UPDATE STANDARD PAR PROC STOCKEE SQL *****/
    if (retCode == RET_SUCCEED)
    {
        retCode = dbiConnHelper.dbaUpdate(object, DBA_ROLE_USESTOREDPROC, inputData);
    }

    return retCode;
}

/************************************************************************
**  Function    :   DBA_DelFmt
**
**  Description :   Delete a format.
**
**  Arguments   :   object        will be Fmt.
**  		        inputSt 	  A_Fmt.
**                  inputData     A_Fmt data.
**                  connectNo     Connection number.
**                  msgStructPtr  Kind of error message.
**
**  Return      :   RET_SUCCEED if success, or error code
**
**  Creation	:   PMSTA13876 - DDV - 130806
**
*************************************************************************/
RET_CODE DBA_DelFmt(OBJECT_ENUM object,
                    DBA_DYNST_ENUM inputSt,
                    DBA_DYNFLD_STP inputData,
                    DbiConnectionHelper& dbiConnHelper)
{
    RET_CODE   retCode = RET_SUCCEED;

    /* Check arguments */
    if (inputData == NULL)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_DelFmt", "inputData");
        return(RET_GEN_ERR_INVARG);
    }

    MemoryPool mp;
    DBA_DYNFLD_STP sXdEntityRec = mp.allocDynst(FILEINFO, S_XdEntity);

    SET_SYSNAME(sXdEntityRec, S_XdEntity_SqlName, GET_CODE(inputData, S_Fmt_Cd));
    SET_ENUM(sXdEntityRec, S_XdEntity_XdActionEn, XdAction_ToPhysicallyDelete);

    /* load xdEntity record, if not found, create a new one */
    dbiConnHelper.dbaUpdate(XdEntity, UNUSED, sXdEntityRec);

    /***** INSERT STANDARD PAR PROC STOCKEE SQL *****/
    if (retCode == RET_SUCCEED)
    {
        retCode = dbiConnHelper.dbaDelete(object, DBA_ROLE_USESTOREDPROC, inputData);
    }

    return retCode;
}

/************************************************************************
**  Function    :   DBA_CreateXdEntityFromFmt
**
**  Description :   Create or update xd record corresponding to a persisted format.
**
**  Arguments   :   fmtRec        dynamic structure on format record.
**  		        xdEntityRec   dynamic structure on xdEntity record to create or update.
**                  action        database action (Insert or Update) to manage correctly DV.
**
**  Return      :   RET_SUCCEED if success, or error code
**
**  Creation	:   PMSTA13876 - DDV - 130806
**
*************************************************************************/
STATIC RET_CODE DBA_CreateXdEntityFromFmt(DBA_DYNFLD_STP  fmtRec,
                                          DBA_DYNFLD_STP  xdEntityRec,
                                          DBA_ACTION_ENUM action,
                                          DbiConnectionHelper &dbiConnHelper)
{
    RET_CODE  retCode = RET_SUCCEED;

    if (action == Insert || action == NullAction)
    {
        SET_NULL_DYNST(xdEntityRec, A_XdEntity);
        if ((retCode = DBA_SetDfltEntityFld(XdEntity, A_XdEntity, xdEntityRec)) != RET_SUCCEED)
            return(retCode);
    }

    SET_ENUM(xdEntityRec, A_XdEntity_XdActionEn, XdAction_None); /* Change to "ToInsert" into the stored procedure "upd_xd_entity" */

    DBA_ResetGetSetFlg(xdEntityRec, A_XdEntity);

    COPY_DYNFLD(xdEntityRec, A_XdEntity, A_XdEntity_SqlName,
                fmtRec,     A_Fmt,    A_Fmt_Cd);
    COPY_DYNFLD(xdEntityRec, A_XdEntity, A_XdEntity_Name,
                fmtRec,     A_Fmt,    A_Fmt_Name);
    COPY_DYNFLD(xdEntityRec, A_XdEntity, A_XdEntity_DbSqlName,
                fmtRec,     A_Fmt,    A_Fmt_Cd);

    /* PMSTA-37366 - LJE - 200311 */
    if (IS_NULLFLD(fmtRec, A_Fmt_TableName) == FALSE)
    {
        COPY_DYNFLD(xdEntityRec, A_XdEntity, A_XdEntity_ShortSqlName,
                    fmtRec, A_Fmt, A_Fmt_TableName);
        COPY_DYNFLD(xdEntityRec, A_XdEntity, A_XdEntity_AliasSqlName,
                    fmtRec, A_Fmt, A_Fmt_TableName);
    }
    else
    {
        COPY_DYNFLD(xdEntityRec, A_XdEntity, A_XdEntity_DbSqlName,
                    fmtRec,      A_Fmt,      A_Fmt_Cd);
    }
    SET_ENUM(xdEntityRec, A_XdEntity_AuditEn, FeatureAuth_Forbidden);
    SET_FLAG(xdEntityRec, A_XdEntity_CustAuthFlg, FALSE);
    SET_ENUM(xdEntityRec, A_XdEntity_SecurityLevelEn, EntSecuLevel_NoSecured);
    SET_FLAG(xdEntityRec, A_XdEntity_MainFlg, FALSE);
    SET_FLAG(xdEntityRec, A_XdEntity_IdentityFlg, FALSE);
    SET_ENUM(xdEntityRec, A_XdEntity_PkRuleEn, PkRule_NoIdentity);
    SET_ENUM(xdEntityRec, A_XdEntity_InterfaceEn, 0);

    /* PMSTA-37366 - LJE - 200311 */
    if (action == NullAction)
    {
        SET_ENUM(xdEntityRec, A_XdEntity_NatEn, EntityNat_Internal);
        SET_MASK(xdEntityRec, A_XdEntity_AutomaticMask, 0);
        SET_FLAG(xdEntityRec, A_XdEntity_LogicalFlg, TRUE);
        SET_FLAG(xdEntityRec, A_XdEntity_QuickSearchFlg, FALSE);
    }
    else
    {
        /* values specifics to format's nature */
        switch (GET_ENUM(fmtRec, A_Fmt_NatEn))
        {
            case FmtNat_Persisted:
                SET_ENUM(xdEntityRec, A_XdEntity_NatEn, EntityNat_PersistedFmt);
                SET_MASK(xdEntityRec, A_XdEntity_AutomaticMask, 0);
                SET_FLAG(xdEntityRec, A_XdEntity_LogicalFlg, TRUE);
                SET_FLAG(xdEntityRec, A_XdEntity_QuickSearchFlg, FALSE);

                break;

            case FmtNat_SearchData: /* PMSTA-16528 - DDV - 140625 */
                SET_ENUM(xdEntityRec, A_XdEntity_NatEn, EntityNat_SearchFmt);
                SET_MASK(xdEntityRec, A_XdEntity_AutomaticMask, 0);
                SET_FLAG(xdEntityRec, A_XdEntity_LogicalFlg, FALSE);
                SET_FLAG(xdEntityRec, A_XdEntity_QuickSearchFlg, TRUE);
                break;

            default:
                SET_ENUM(xdEntityRec, A_XdEntity_NatEn, EntityNat_ReportFmt);
                SET_MASK(xdEntityRec, A_XdEntity_AutomaticMask, 0);
                SET_FLAG(xdEntityRec, A_XdEntity_LogicalFlg, FALSE);
                SET_FLAG(xdEntityRec, A_XdEntity_QuickSearchFlg, FALSE);
        }
    }

    /* hard coded values for XdEntity */
    SET_FLAG(xdEntityRec, A_XdEntity_QuickSearchFlg, TRUE);

    SCPT_ComputeScreenDV(XdEntity,
                         DictFct_0,
                         NULL, /* pflagScpt, */
                         NULL,              /* HFI-PMSTA-25327-171023  Dedicated flag tab for filter    */
                         xdEntityRec,
                         NULL,
                         NULLDYNST,
                         NULLDYNST,
                         TRUE,	            /* analyse type (all)*/
                         FALSE,				/* guiFlag */
                         EvalType_DefVal,
                         0,					/* attribIdx */
                         &(dbiConnHelper.getConnection()->getId()),              /* connectNo */
                         NULL,				/* filterTab */
                         NULL,	            /* hierHead */
                         0,
                         NullEntity,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NullEntity,
                         FALSE,
                         FALSE,
                         0);
    return(RET_SUCCEED);
}

/************************************************************************
**  Function    :   DBA_InsFmtEltById
**
**  Description :   Create a new format elemnt.
**
**  Arguments   :   object        will be FmtElt.
**  		        inputSt 	  A_FmtElt.
**                  inputData     A_FmtElt data.
**                  connectNo     Connection number.
**                  msgStructPtr  Kind of error message.
**
**  Return      :   RET_SUCCEED if success, or error code
**
**  Creation	:   PMSTA13876 - DDV - 130807
**
*************************************************************************/
RET_CODE DBA_InsFmtEltById(OBJECT_ENUM          object,
                           DBA_DYNST_ENUM       inputSt,
                           DBA_DYNFLD_STP       inputData,
                           DbiConnectionHelper& dbiConnHelper)
{
    RET_CODE       retCode = RET_SUCCEED;
    MemoryPool     mp;

    /* Check arguments */
    if (inputData == NULL)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_InsFmtEltById", "inputData");
        return(RET_GEN_ERR_INVARG);
    }

    DBA_DYNFLD_STP sFmtRec = mp.allocDynst(FILEINFO, S_Fmt);

    SET_ID(sFmtRec, S_Fmt_Id, GET_ID(inputData, A_FmtElt_FmtId));

    if ((dbiConnHelper.dbaGet(Fmt, UNUSED, sFmtRec, &sFmtRec)) == RET_SUCCEED)
    {
        DBA_DYNFLD_STP sXdEntityRec = mp.allocDynst(FILEINFO, S_XdEntity);

        SET_SYSNAME(sXdEntityRec, S_XdEntity_SqlName, GET_CODE(sFmtRec, S_Fmt_Cd));

        if(GET_ENUM(sFmtRec, S_Fmt_NatEn) == FmtNat_Persisted ||
           GET_ENUM(sFmtRec, S_Fmt_NatEn) == FmtNat_SearchData) /* PMSTA-16528 - DDV - 140625 - Add new format and entity nature for search table */
        {
            DBA_DYNFLD_STP sXdAttribRec = mp.allocDynst(FILEINFO, S_XdAttrib);
            DBA_DYNFLD_STP xdAttribRec  = mp.allocDynst(FILEINFO, A_XdAttrib);
            DBA_DYNFLD_STP xdEntityRec  = mp.allocDynst(FILEINFO, A_XdEntity);

            /* load xdEntity record */
            retCode = dbiConnHelper.dbaGet(XdEntity, UNUSED, sXdEntityRec, &xdEntityRec);

            /* PMSTA-31054 - DDV - 180419 - If data has been return by optimisation, try to load it directly from db */
            if (retCode == RET_DBA_INFO_NODATAWITHOPTI)
            {
                retCode = dbiConnHelper.dbaGet(XdEntity, DBA_ROLE_NO_OPTI, sXdEntityRec, &xdEntityRec);
            }

            if (retCode != RET_SUCCEED)
            {
                return(retCode);
            }

            SET_ID(sXdAttribRec, S_XdAttrib_XdEntityId, GET_ID(xdEntityRec, A_XdEntity_Id));
            SET_SYSNAME(sXdAttribRec, S_XdAttrib_SqlName, GET_CODE(inputData, A_FmtElt_SqlName));

            /* load xdAttrib record, if not found, create a new one */
            if (dbiConnHelper.dbaGet(XdAttrib, UNUSED, sXdAttribRec, &xdAttribRec) == RET_SUCCEED)
            {
                SET_SYSNAME(sXdAttribRec, S_XdAttrib_XdEntitySqlName, GET_CODE(sFmtRec, S_Fmt_Cd));
                SET_ENUM(sXdAttribRec, S_XdAttrib_XdActionEn, XdAction_ToInsert);

                dbiConnHelper.dbaUpdate(XdAttrib, UNUSED, sXdAttribRec);
            }
            else
            {
                INT_T attribProgN = 10 + GET_SMALLINT(inputData, A_FmtElt_Rank) - 1;
                if ((retCode = DBA_CreateXdAttribFromFmtElt(dbiConnHelper, inputData, xdAttribRec, sFmtRec, xdEntityRec, attribProgN, Insert)) != RET_SUCCEED)
                {
                    return(retCode);
                }

                retCode = dbiConnHelper.dbaInsert(XdAttrib, UNUSED, xdAttribRec);
            }
        }
        else
        {
            SET_ENUM(sXdEntityRec, S_XdEntity_XdActionEn, XdAction_ToInsert);

            dbiConnHelper.dbaUpdate(XdEntity, UNUSED, sXdEntityRec);
        }
    }

    /***** INSERT STANDARD PAR PROC STOCKEE SQL *****/
    if (retCode == RET_SUCCEED)
    {
        retCode = dbiConnHelper.dbaInsert(object, DBA_ROLE_USESTOREDPROC, inputData);
    }

    return retCode;
}

/************************************************************************
**  Function    :   DBA_UpdFmtElt
**
**  Description :   Update an existing format element.
**
**  Arguments   :   object        will be FmtElt.
**  		        inputSt 	  A_FmtElt.
**                  inputData     A_FmtElt data.
**                  connectNo     Connection number.
**                  msgStructPtr  Kind of error message.
**
**  Return      :   RET_SUCCEED if success, or error code
**
**  Creation	:   PMSTA13876 - DDV - 130806
**
*************************************************************************/
RET_CODE DBA_UpdFmtElt(OBJECT_ENUM          object,
                       DBA_DYNST_ENUM       inputSt,
                       DBA_DYNFLD_STP       inputData,
                       DbiConnectionHelper& dbiConnHelper)
{
    RET_CODE   retCode = RET_SUCCEED;
    MemoryPool mp;

    /* Check arguments */
    if (inputData == NULL)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_UpdFmtElt", "inputData");
        return(RET_GEN_ERR_INVARG);
    }

    DBA_DYNFLD_STP sFmtRec = mp.allocDynst(FILEINFO, S_Fmt);
    DBA_DYNFLD_STP sXdEntityRec = mp.allocDynst(FILEINFO, S_XdEntity);

    SET_ID(sFmtRec, S_Fmt_Id, GET_ID(inputData, A_FmtElt_FmtId));

    if ((dbiConnHelper.dbaGet(Fmt, UNUSED, sFmtRec, &sFmtRec)) == RET_SUCCEED)
    {
        SET_SYSNAME(sXdEntityRec, S_XdEntity_SqlName, GET_CODE(sFmtRec, S_Fmt_Cd));
        SET_ENUM(sXdEntityRec, S_XdEntity_XdActionEn, XdAction_ToInsert);

        dbiConnHelper.dbaUpdate(XdEntity, UNUSED, sXdEntityRec);
    }

    /***** UPDATE STANDARD PAR PROC STOCKEE SQL *****/
    if (retCode == RET_SUCCEED)
    {
        retCode = dbiConnHelper.dbaUpdate(object, DBA_ROLE_USESTOREDPROC, inputData);
    }

    return retCode;
}

/************************************************************************
**  Function    :   DBA_DelFmtElt
**
**  Description :   Delete a format element using its id.
**
**  Arguments   :   object        will be FmtElt.
**  		        inputSt 	  S_FmtElt.
**                  inputData     S_FmtElt data.
**                  connectNo     Connection number.
**                  msgStructPtr  Kind of error message.
**
**  Return      :   RET_SUCCEED if success, or error code
**
**  Creation	:   PMSTA13876 - DDV - 130806
**
*************************************************************************/
RET_CODE DBA_DelFmtElt(OBJECT_ENUM object,
                       DBA_DYNST_ENUM inputSt,
                       DBA_DYNFLD_STP inputData,
                       DbiConnectionHelper& dbiConnHelper)
{
    RET_CODE       retCode = RET_SUCCEED;
    MemoryPool     mp;

    /* Check arguments */
    if (inputData == NULL)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_DelFmtElt", "inputData");
        return(RET_GEN_ERR_INVARG);
    }

    DBA_DYNFLD_STP sFmtEltRec = nullptr;

    /* if format_id or sqlname_c are missing, load S_FmtElt using its id */
    if ((IS_NULLFLD(inputData, S_FmtElt_FmtId) == TRUE ||
         IS_NULLFLD(inputData, A_FmtElt_SqlName) == TRUE) &&
        IS_NULLFLD(inputData, A_FmtElt_Id) == FALSE)
    {
        sFmtEltRec = mp.allocDynst(FILEINFO, S_FmtElt);

        if ((retCode = dbiConnHelper.dbaGet(FmtElt, UNUSED, inputData, &sFmtEltRec)) != RET_SUCCEED)
        {
            return(retCode);
        }
    }
    else
    {
        sFmtEltRec=inputData;
    }

    DBA_DYNFLD_STP sFmtRec = mp.allocDynst(FILEINFO, S_Fmt);

    SET_ID(sFmtRec, S_Fmt_Id, GET_ID(inputData, S_FmtElt_FmtId));

    if ((dbiConnHelper.dbaGet(Fmt, UNUSED, sFmtRec, &sFmtRec)) == RET_SUCCEED)
    {
        DBA_DYNFLD_STP sXdAttribRec = mp.allocDynst(FILEINFO, S_XdAttrib);

        SET_SYSNAME(sXdAttribRec, S_XdAttrib_XdEntitySqlName, GET_CODE(sFmtRec, S_Fmt_Cd));
        SET_SYSNAME(sXdAttribRec, S_XdAttrib_SqlName, GET_CODE(inputData, A_FmtElt_SqlName));
        SET_ENUM(sXdAttribRec, S_XdAttrib_XdActionEn, XdAction_ToPhysicallyDelete);

        /* Update action of xdAttrib record */
        dbiConnHelper.dbaUpdate(XdAttrib, UNUSED, sXdAttribRec);
    }

    /***** INSERT STANDARD PAR PROC STOCKEE SQL *****/
    if (retCode == RET_SUCCEED)
    {
        retCode = dbiConnHelper.dbaDelete(object, DBA_ROLE_USESTOREDPROC, inputData);
    }

    return retCode;
}

/************************************************************************
**  Function    :   DBA_CopyFmtElt
**
**  Description :   Copy all format elements.
**
**  Arguments   :   object        will be FmtElt.
**  		        inputSt 	  A_CopyArg.
**                  inputData     A_CopyArg data.
**                  connectNo     Connection number.
**                  msgStructPtr  Kind of error message.
**
**  Return      :   RET_SUCCEED if success, or error code
**
**  Creation	:   PMSTA13876 - DDV - 130904
**
*************************************************************************/
RET_CODE DBA_CopyFmtElt(OBJECT_ENUM          object,
                        DBA_DYNFLD_STP       copyArg,
                        DbiConnectionHelper &dbiConnHelper)
{
    RET_CODE       retCode=RET_SUCCEED;
    DBA_DYNFLD_STP sFmtRec=NULLDYNST, *aFmtEltTab=NULLDYNSTPTR;
    int            fmtEltNbr=0, i=0;

    retCode = dbiConnHelper.dbaCopy(object, DBA_ROLE_USESTOREDPROC, copyArg);

    if (retCode == RET_SUCCEED)
    {
        /* Is it a persisted format ? */
        if ((sFmtRec = ALLOC_DYNST(S_Fmt)) == NULLDYNST)
            MSG_RETURN(RET_MEM_ERR_ALLOC);

        SET_ID(sFmtRec, S_Fmt_Id, GET_ID(copyArg, A_CopyArg_ToId));

        if (dbiConnHelper.dbaGet(Fmt, UNUSED, sFmtRec, &sFmtRec) == RET_SUCCEED)
        {
            if (GET_ENUM(sFmtRec, S_Fmt_NatEn) == FmtNat_Persisted ||
                GET_ENUM(sFmtRec, S_Fmt_NatEn) == FmtNat_SearchData) /* PMSTA-16528 - DDV - 140625 - Add new format and entity nature for search table */
            {
                DBA_DYNFLD_STP  xdEntityRec;
                DBA_DYNFLD_STP  sXdEntityRec;

                if ((xdEntityRec = ALLOC_DYNST(A_XdEntity)) == NULLDYNST)
                    MSG_RETURN(RET_MEM_ERR_ALLOC);

                if ((sXdEntityRec = ALLOC_DYNST(S_XdEntity)) == NULLDYNST)
                {
                    FREE_DYNST(xdEntityRec, A_XdEntity);
                    MSG_RETURN(RET_MEM_ERR_ALLOC);
                }

                if (sFmtRec != nullptr)
                {
                    SET_SYSNAME(sXdEntityRec, S_XdEntity_SqlName, GET_CODE(sFmtRec, S_Fmt_Cd));
                }

                /* load xdEntity record */
                retCode = dbiConnHelper.dbaGet(XdEntity, UNUSED, sXdEntityRec, &xdEntityRec);

                /* PMSTA-31054 - DDV - 180419 - If data has been return by optimisation, try to load it directly from db */
                if (retCode == RET_DBA_INFO_NODATAWITHOPTI)
                    retCode = dbiConnHelper.dbaGet(XdEntity, DBA_ROLE_NO_OPTI, sXdEntityRec, &xdEntityRec);

                FREE_DYNST(sXdEntityRec, S_XdEntity);
                if (retCode != RET_SUCCEED)
                {
                    FREE_DYNST(xdEntityRec, A_XdEntity);
                    return(retCode);
                }

                /* select all format element and create all xd_attribute */
                if ((dbiConnHelper.dbaSelect(FmtElt,UNUSED, sFmtRec, A_FmtElt, &aFmtEltTab, &fmtEltNbr)) == RET_SUCCEED)
                {
                    DBA_DYNFLD_STP xdAttribRec;
                    INT_T          attribProgN = 10;

                    if ((xdAttribRec = ALLOC_DYNST(A_XdAttrib)) == NULLDYNST)
                    {
                        FREE_DYNST(sFmtRec, S_Fmt);
                        DBA_FreeDynStTab(aFmtEltTab, fmtEltNbr, A_FmtElt);
                        MSG_RETURN(RET_MEM_ERR_ALLOC);
                    }

                    for (i=0; i<fmtEltNbr; i++)
                    {
                        /* convert fmt to xd_entity record */
                        if ((retCode = DBA_CreateXdAttribFromFmtElt(dbiConnHelper, aFmtEltTab[i], xdAttribRec, sFmtRec, xdEntityRec, attribProgN, InsUpd)) != RET_SUCCEED)
                        {
                            FREE_DYNST(sFmtRec, S_Fmt);
                            DBA_FreeDynStTab(aFmtEltTab, fmtEltNbr, A_FmtElt);
                            FREE_DYNST(xdAttribRec, A_XdAttrib);
                            return(retCode);
                        }
                                    /* insert it into database */
                        if ((retCode = dbiConnHelper.dbaInsert(XdAttrib, UNUSED, xdAttribRec)) != RET_SUCCEED)
                        {
                            FREE_DYNST(sFmtRec, S_Fmt);
                            DBA_FreeDynStTab(aFmtEltTab, fmtEltNbr, A_FmtElt);
                            FREE_DYNST(xdAttribRec, A_XdAttrib);
                            return(retCode);
                        }
                    }
                    DBA_FreeDynStTab(aFmtEltTab, fmtEltNbr, A_FmtElt);
                }
                FREE_DYNST(xdEntityRec, A_XdEntity);
            }
        }
        FREE_DYNST(sFmtRec, S_Fmt);
    }

    return(retCode);
}

/************************************************************************
**  Function    :   DBA_CreateXdAttribFromFmtElt
**
**  Description :   Create or update xd record corresponding to a persisted format element.
**
**  Arguments   :   fmtRec        dynamic structure on format record.
**  		        xdAttribRec   dynamic structure on xdAttrib record to create or update.
**                  action        database action (Insert or Update) to manage correctly DV.
**
**  Return      :   RET_SUCCEED if success, or error code
**
**  Creation	:   PMSTA13876 - DDV - 130806
**
*************************************************************************/
RET_CODE DBA_CreateXdAttribFromFmtElt(DbiConnectionHelper &dbiConnHelper,
                                      DBA_DYNFLD_STP       fmtEltRec,
                                      DBA_DYNFLD_STP       xdAttribRec,
                                      DBA_DYNFLD_STP       sFmtRec,
                                      DBA_DYNFLD_STP       xdEntityRec,
                                      INT_T               &currProgN,
                                      DBA_ACTION_ENUM      action)
{
    RET_CODE        retCode = RET_SUCCEED;
    DICT_ATTRIB_STP attribStp;
    DICT_ENTITY_STP entityStp;
    OBJECT_ENUM     refObjectEn;
    ID_T            xdAttribId = GET_ID(xdAttribRec, A_XdAttrib_Id);
    MemoryPool      mp;

    SET_NULL_DYNST(xdAttribRec, A_XdAttrib);
    if (action == Update)
    {
        SET_ID(xdAttribRec, A_XdAttrib_Id, xdAttribId);
    }
    else
    {
        xdAttribId = 0;
    }
    
    if ((retCode = DBA_SetDfltEntityFld(XdAttrib, A_XdAttrib, xdAttribRec)) != RET_SUCCEED)
    {
        return(retCode);
    }

    DBA_ResetGetSetFlg(xdAttribRec, A_XdAttrib);

    /* Set FmtElt informations */
    COPY_DYNFLD(xdAttribRec, A_XdAttrib, A_XdAttrib_SqlName,
                fmtEltRec,   A_FmtElt,   A_FmtElt_SqlName);
    COPY_DYNFLD(xdAttribRec, A_XdAttrib, A_XdAttrib_Name,
                fmtEltRec,   A_FmtElt,   A_FmtElt_Name);
    COPY_DYNFLD(xdAttribRec, A_XdAttrib, A_XdAttrib_DataTpDictId,
                fmtEltRec,   A_FmtElt,   A_FmtElt_DataTpDictId);
    COPY_DYNFLD(xdAttribRec, A_XdAttrib, A_XdAttrib_DispRank,
                fmtEltRec,   A_FmtElt,   A_FmtElt_DispColumn);

    SET_INT(xdAttribRec, A_XdAttrib_Prog, ++currProgN);

    if (IS_NULLFLD(fmtEltRec, A_FmtElt_SortRank) == TRUE)
    {
        SET_NULL_TINYINT(xdAttribRec, A_XdAttrib_SortRank);
    }
    else if (GET_TINYINT(xdAttribRec, A_XdAttrib_SortRank) != (TINYINT_T)GET_SMALLINT(fmtEltRec, A_FmtElt_SortRank))
    {
        SET_TINYINT(xdAttribRec, A_XdAttrib_SortRank, (TINYINT_T)GET_SMALLINT(fmtEltRec, A_FmtElt_SortRank));
    }

    /* value none don't exist in xdAttribute */
    if (CMP_DYNFLD(xdAttribRec, fmtEltRec, A_XdAttrib_SortRuleEn, A_FmtElt_SortRuleEn, EnumType) != 0 &&
        GET_ENUM(fmtEltRec, A_FmtElt_SortRuleEn) != SortRule_None)
    {
        COPY_DYNFLD(xdAttribRec, A_XdAttrib, A_XdAttrib_SortRuleEn,
                    fmtEltRec,   A_FmtElt,   A_FmtElt_SortRuleEn);
    }

    /* if attribute is define, check if A_XdAttrib_RefXdEntityId must be set */
    if (IS_NULLFLD(fmtEltRec, A_FmtElt_AttribDictId) == FALSE ||
        IS_NULLFLD(fmtEltRec, A_FmtElt_ParentAttribDictId) == FALSE)
    {
        DICT_T parentAttribDictId = (IS_NULLFLD(fmtEltRec, A_FmtElt_ParentAttribDictId) == FALSE ? GET_DICT(fmtEltRec, A_FmtElt_ParentAttribDictId) : GET_DICT(fmtEltRec, A_FmtElt_AttribDictId));

        if ((attribStp = DBA_GetAttributeById(parentAttribDictId)) != NULL &&
            attribStp->dataTpProgN == DATATYPE_DICT_TO_ENUM(GET_DICT(fmtEltRec, A_FmtElt_DataTpDictId))) /* PMSTA-26084 - LJE - 170202 */
        {
            /* copy default_c */
            if (IS_NULLFLD(xdAttribRec, A_XdAttrib_Default) == FALSE &&
                GET_NAME(xdAttribRec, A_XdAttrib_Default) != NULL)
            {
                if ( attribStp->dfltVal.empty() == false)
                {
                    SET_NAME(xdAttribRec, A_XdAttrib_Default, attribStp->dfltVal.c_str());
                }
                else
                {
                    SET_NULL_NAME(xdAttribRec, A_XdAttrib_Default);
                }
            }
            else if (attribStp->dfltVal.empty() == false)
            {
                SET_NAME(xdAttribRec, A_XdAttrib_Default, attribStp->dfltVal.c_str());
            }

            DBA_GetObjectEnum(attribStp->entDictId, &refObjectEn);

            if ((entityStp = DBA_GetDictEntitySt(refObjectEn)) != NULL)
            {
                DBA_DYNFLD_STP  sXdEntityRec = mp.allocDynst(FILEINFO, S_XdEntity);
                DBA_DYNFLD_STP  aXdEntityRec = mp.allocDynst(FILEINFO, A_XdEntity);

                SET_SYSNAME(sXdEntityRec, S_XdEntity_SqlName, entityStp->mdSqlName);

                /* load xdEntity record */
                retCode = dbiConnHelper.dbaGet(XdEntity, UNUSED, sXdEntityRec, &aXdEntityRec);

                /* PMSTA-31054 - DDV - 180419 - If data has been return by optimisation, try to load it directly from db */
                if (retCode == RET_DBA_INFO_NODATAWITHOPTI)
                    retCode = dbiConnHelper.dbaGet(XdEntity, DBA_ROLE_NO_OPTI, sXdEntityRec, &aXdEntityRec);

                if (retCode == RET_SUCCEED)
                {
                    DBA_DYNFLD_STP sXdAttribRec, aXdAttribRec;

                    if ((sXdAttribRec = ALLOC_DYNST(S_XdAttrib)) == NULLDYNST ||
                        (aXdAttribRec = ALLOC_DYNST(A_XdAttrib)) == NULLDYNST)
                    {
                        MSG_RETURN(RET_MEM_ERR_ALLOC);
                    }

                    SET_DICT(sXdAttribRec, S_XdAttrib_XdEntityId, GET_DICT(aXdEntityRec, A_XdEntity_Id));
                    SET_SYSNAME(sXdAttribRec, S_XdAttrib_SqlName, attribStp->sqlName);

                    if ((retCode = dbiConnHelper.dbaGet(XdAttrib, UNUSED, sXdAttribRec, &aXdAttribRec)) == RET_SUCCEED)
                    {
                        /* PMSTA-26000 - LJE - 170203 */
                        if (IS_NULLFLD(aXdAttribRec, A_XdAttrib_ParentXdAttribId) == TRUE)
                        {
                            COPY_DYNFLD(xdAttribRec, A_XdAttrib, A_XdAttrib_ParentXdAttribId,
                                        aXdAttribRec, A_XdAttrib, A_XdAttrib_Id);
                        }
                        else
                        {
                            COPY_DYNFLD(xdAttribRec, A_XdAttrib, A_XdAttrib_ParentXdAttribId,
                                        aXdAttribRec, A_XdAttrib, A_XdAttrib_ParentXdAttribId);
                        }
                    }
                    FREE_DYNST(sXdAttribRec, S_XdAttrib);
                    FREE_DYNST(aXdAttribRec, A_XdAttrib);
                }
            }
        }
    }

    /* PMSTA-16528 - DDV - 140625 - Manage primary/business key and search entity */
    COPY_DYNFLD(xdAttribRec, A_XdAttrib, A_XdAttrib_PrimaryFlg,
                fmtEltRec,   A_FmtElt,   A_FmtElt_PrimaryKeyFlg);

    SET_FLAG_FALSE(xdAttribRec, A_XdAttrib_VerticalPatternFlg);
    SET_FLAG_FALSE(xdAttribRec, A_XdAttrib_VerticalSearchFlg);
    switch (GET_A_FmtElt_TslSearchEn(fmtEltRec))
    {
        case XdAttributeCustoTslSearchEn::VerticalPattern:
            SET_FLAG_TRUE(xdAttribRec, A_XdAttrib_VerticalPatternFlg);
            break;
        case XdAttributeCustoTslSearchEn::VerticalSearch:
            SET_FLAG_TRUE(xdAttribRec, A_XdAttrib_VerticalSearchFlg);
            break;
    }

    /* PMSTA-18478 - DDV - 140807 - Set multilingual_f in xd_aatribute */
    switch(GET_ENUM(fmtEltRec, A_FmtElt_TslMultilingualEn))
    {
        case TslMultilingual_Multilingual:
            if (GET_FLAG(xdAttribRec, A_XdAttrib_MultiLangFlg) != TRUE)
                SET_FLAG(xdAttribRec, A_XdAttrib_MultiLangFlg, TRUE);
            break;
        case TslMultilingual_None:
        case TslMultilingual_MultilingualChild:
        default:
            if (GET_FLAG(xdAttribRec, A_XdAttrib_MultiLangFlg) != FALSE)
                SET_FLAG(xdAttribRec, A_XdAttrib_MultiLangFlg, FALSE);
            break;
    }

    /* PMSTA-37366 - LJE - 200515 */
    COPY_DYNFLD(xdAttribRec, A_XdAttrib, A_XdAttrib_DenomLangDictId,
                fmtEltRec,   A_FmtElt, A_FmtElt_LangDictId);

    /* PMSTA16528 - DDV - 140626 */
    if (IS_NULLFLD(fmtEltRec, A_FmtElt_RefEntityDictId) == TRUE)
    {
        if (IS_NULLFLD(xdAttribRec, A_XdAttrib_RefXdEntityId) == FALSE)
        {
            SET_NULL_FLD(xdAttribRec, A_XdAttrib_RefXdEntityId);
        }
    }
    else
    {
        DBA_GetObjectEnum(GET_DICT(fmtEltRec, A_FmtElt_RefEntityDictId), &refObjectEn);

        if ((entityStp =  DBA_GetDictEntitySt(refObjectEn)) != NULL &&
            entityStp->mdSqlName[0] != END_OF_STRING)
        {
            DBA_DYNFLD_STP  sXdEntityRec = mp.allocDynst(FILEINFO, S_XdEntity);
            DBA_DYNFLD_STP  aXdEntityRec = mp.allocDynst(FILEINFO, A_XdEntity);

            SET_SYSNAME(sXdEntityRec, S_XdEntity_SqlName, entityStp->mdSqlName);

            /* load xdEntity record */
            retCode = dbiConnHelper.dbaGet(XdEntity, UNUSED, sXdEntityRec, &aXdEntityRec);

            /* PMSTA-31054 - DDV - 180419 - If data has been return by optimisation, try to load it directly from db */
            if (retCode == RET_DBA_INFO_NODATAWITHOPTI)
                retCode = dbiConnHelper.dbaGet(XdEntity, DBA_ROLE_NO_OPTI, sXdEntityRec, &aXdEntityRec);

            if (retCode == RET_SUCCEED)
            {
                COPY_DYNFLD(xdAttribRec,  A_XdAttrib, A_XdAttrib_RefXdEntityId,
                            aXdEntityRec, A_XdEntity, A_XdEntity_Id);
            }
        }
    }

    /* Set xdEntity informations */
    if (CMP_DYNFLD(xdAttribRec, xdEntityRec, A_XdAttrib_XdEntityId, A_XdEntity_Id, IdType) != 0)
    {
        COPY_DYNFLD(xdAttribRec, A_XdAttrib, A_XdAttrib_XdEntityId,
                    xdEntityRec, A_XdEntity, A_XdEntity_Id);
    }

    /* hard coded values for XdAttribute */
    SET_ENUM(xdAttribRec, A_XdAttrib_CalcEn, DictAttr_Physical);
    SET_ENUM(xdAttribRec, A_XdAttrib_XdActionEn, XdAction_ToInsert);
    SET_ENUM(xdAttribRec, A_XdAttrib_XdStatusEn, XdStatus_Untreated);
    SET_MASK(xdAttribRec, A_XdAttrib_QuickSearchMask, 1);
    SET_MASK(xdAttribRec, A_XdAttrib_SearchMask, 1);

    /* PMSTA-49229 - LJE - 230120 */
    if (GET_FLAG(fmtEltRec, A_FmtElt_TslAttribMappingFlg) == TRUE)
    {
        SET_FLAG_TRUE(xdAttribRec, A_XdAttrib_BusKeyFlg);
    }

    COPY_DYNFLD(xdAttribRec,  A_XdAttrib, A_XdAttrib_OutboxPublishEn,fmtEltRec, A_FmtElt, A_FmtElt_OutboxPublishEn);
    
    SCPT_ComputeScreenDV(XdAttrib,
                         DictFct_0,
                         NULL, /* pflagScpt, */
                         NULL,              /* HFI-PMSTA-25327-171023  Dedicated flag tab for filter    */
                         xdAttribRec,
                         NULL,
                         NULLDYNST,
                         NULLDYNST,
                         TRUE,	/* analyse type (all)*/ /* PMSTA-24913 - LJE - 161012 - Always all */
                         FALSE,				/* guiFlag */
                         EvalType_DefVal,
                         0,					/* attribIdx */
                         &(dbiConnHelper.getId()), /* connectNo */
                         NULL,				/* filterTab */
                         NULL,	            /* hierHead */
                         0,
                         NullEntity,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NullEntity,
                         FALSE,
                         FALSE,
                         0);


    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   DBA_CmpFmtEltBySqlname
**
**  Description :   Sort format element by sqlname_c
**
**  Arguments   :   PTR stp1, PTR stp2
**
**  Return      :   int
**
**  Création	:   DDV - 140716 - PMSTA-16528
**
*************************************************************************/
STATIC int DBA_CmpFmtEltByRankLang(DBA_DYNFLD_STP *stp1, DBA_DYNFLD_STP *stp2)
{
    int cmp;
    if ((cmp = CMP_DYNFLD_SYB((*stp1), (*stp2), A_FmtElt_Rank, A_FmtElt_Rank, SmallintType)) != 0)
        return(cmp);

    return(CMP_DYNFLD_SYB((*stp1), (*stp2), A_FmtElt_LangDictId, A_FmtElt_LangDictId, DictType));
}

/************************************************************************
**  Function    :   DBA_TreatMultiLingualFmtElt
**
**  Description :   Complete xd model for multilingual nformation.
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED if success, or error code
**
**  Creation	:   PMSTA13876 - DDV - 130806
**
*************************************************************************/
STATIC RET_CODE DBA_TreatMultiLingualFmtElt(DBA_DYNFLD_STP shXdEntityStp, DBA_DYNFLD_STP *fmtEltTab, int fmtEltNbr, DBA_DYNFLD_STP *xdAttribTab, int xdAttribNbr, DbiConnectionHelper &dbiConnHelper)
{
    int             i=0, j=0, newXdAttribNbr=0, progN=0, cmp,
                    mlFmtEltPos, srcPos=0, destPos=0;
    SMALLINT_T      mlFmtEltRank=NO_VALUE; /* PMSTA-18720 - DDV - 141918 - Fix wrong access type error */
    MemoryPool      mp;

    DBA_DYNFLD_STP  *newXdAttribTab = (DBA_DYNFLD_STP*)mp.calloc(FILEINFO, fmtEltNbr, sizeof(DBA_DYNFLD_STP));

    if (GET_ENUM(shXdEntityStp, S_XdEntity_NatEn) == EntityNat_SearchFmt)
    {
        /* update or create xd_attribute for all format_elements */
        for (i = 0, j = 0; i < fmtEltNbr; i++)
        {
            /* if it's an additional xd_attribuite, skip it or delete it */
            while (j < xdAttribNbr && CMP_DYNFLD(fmtEltTab[i], xdAttribTab[j], A_FmtElt_SqlName, A_XdAttrib_SqlName, SysnameType)>0)
            {
                j++;
            }

            /* xd_attribute is missing, create it */
            if (j >= xdAttribNbr || (cmp = CMP_DYNFLD(fmtEltTab[i], xdAttribTab[j], A_FmtElt_SqlName, A_XdAttrib_SqlName, SysnameType)) < 0)
            {
                DBA_DYNFLD_STP xdAttribRec = mp.allocDynst(FILEINFO, A_XdAttrib);

                SET_INT(fmtEltTab[i], A_FmtElt_NewXdAttribPos, newXdAttribNbr);
                newXdAttribTab[newXdAttribNbr] = xdAttribRec;
                newXdAttribNbr++;
            }
            else if (j < xdAttribNbr && cmp == 0)
            {
                SET_INT(fmtEltTab[i], A_FmtElt_NewXdAttribPos, newXdAttribNbr);
                newXdAttribTab[newXdAttribNbr] = xdAttribTab[j];

                /* PMSTA-18571 - DDV - 140821 - Set status to "To Insert" to avoid virtual field creation */
                if (GET_ENUM(newXdAttribTab[newXdAttribNbr], A_XdAttrib_XdActionEn) != XdAction_ToInsert)
                {
                    SET_ENUM(newXdAttribTab[newXdAttribNbr], A_XdAttrib_XdActionEn, XdAction_ToInsert);
                }

                newXdAttribNbr++;
                j++;
            }
            else
            {
                SET_INT(fmtEltTab[i], A_FmtElt_NewXdAttribPos, NO_VALUE);
            }
        }
    }

    /* sort format element by rank and language */
    if (fmtEltNbr >1)
        TLS_Sort((char *) fmtEltTab, fmtEltNbr, sizeof(DBA_DYNFLD_STP),
                 (TLS_CMPFCT *) DBA_CmpFmtEltByRankLang, NULL, SortRtnTp_None);

    /* compute new prog_n */
    for (i=0;  i < fmtEltNbr; i++)
    {
        switch(GET_ENUM(fmtEltTab[i], A_FmtElt_TslMultilingualEn))
        {
            case TslMultilingual_Multilingual:
                mlFmtEltPos=i;
                mlFmtEltRank=GET_SMALLINT(fmtEltTab[i], A_FmtElt_Rank); /* PMSTA-18720 - DDV - 141918 - Fix wrong access type error */
                srcPos = GET_INT(fmtEltTab[i], A_FmtElt_NewXdAttribPos);
                SET_FLAG(newXdAttribTab[srcPos], A_XdAttrib_MultiLangFlg, TRUE); /* PMSTA-18478 - DDV - 140807 - Set multilingual_f in xd_attribute */
                break;

            case TslMultilingual_MultilingualChild:
                if (GET_SMALLINT(fmtEltTab[i], A_FmtElt_Rank) == mlFmtEltRank) /* PMSTA-18720 - DDV - 141918 - Fix wrong access type error */
                {
                    destPos = GET_INT(fmtEltTab[i], A_FmtElt_NewXdAttribPos);

                    if (srcPos != NO_VALUE && destPos != NO_VALUE)
                    {
                        ID_T			xdAttribId      = NO_VALUE;
                        DICT_T          attributeDictId = NO_VALUE;

                        /* OCS-45044 - EFE - 140814 update child xd_attribute */
                        if (IS_NULLFLD(newXdAttribTab[destPos], A_XdAttrib_Id) == false)
                        {
                            xdAttribId      = GET_ID(newXdAttribTab[destPos], A_XdAttrib_Id);
                            attributeDictId = GET_DICT(newXdAttribTab[destPos], A_XdAttrib_AttribDictId);
                        }

                        COPY_DYNST(newXdAttribTab[destPos], newXdAttribTab[srcPos], A_XdAttrib);
                        COPY_DYNFLD(newXdAttribTab[destPos], A_XdAttrib, A_XdAttrib_SqlName,
                                    fmtEltTab[i], A_FmtElt, A_FmtElt_SqlName);

                        if (xdAttribId == NO_VALUE) /* OCS-45044 - EFE - 140814 update child xd_attribute */
                        {
                            SET_NULL_ID(newXdAttribTab[destPos], A_XdAttrib_Id);
                            SET_NULL_DICT(newXdAttribTab[destPos], A_XdAttrib_AttribDictId);
                        }
                        else
                        {
                            SET_ID(newXdAttribTab[destPos], A_XdAttrib_Id, xdAttribId);
                            SET_DICT(newXdAttribTab[destPos], A_XdAttrib_AttribDictId, attributeDictId);
                        }

                        SET_FLAG_FALSE(newXdAttribTab[destPos], A_XdAttrib_MultiLangFlg); /* PMSTA-18478 - DDV - 140807 - Set multilingual_f in xd_aatribute */
                        SET_ENUM(newXdAttribTab[destPos], A_XdAttrib_CalcEn, DictAttr_Physical);
                    }
                }
                break;
        }

        if ((j = GET_INT(fmtEltTab[i], A_FmtElt_NewXdAttribPos)) != NO_VALUE)
        {
            SET_INT(newXdAttribTab[j], A_XdAttrib_Prog, progN);
            progN++;

            if (IS_NULLFLD(newXdAttribTab[j], A_XdAttrib_SqlName) == FALSE)
            {
                if (IS_NULLFLD(newXdAttribTab[j], A_XdAttrib_Id) == TRUE)
                {
                    dbiConnHelper.dbaInsert(XdAttrib, UNUSED, newXdAttribTab[j]);
                }
                else
                {
                    dbiConnHelper.dbaUpdate(XdAttrib, UNUSED, newXdAttribTab[j]);
                }
            }
        }
    }

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   DBA_CmpFmtEltBySqlname
**
**  Description :   Sort format element by sqlname_c
**
**  Arguments   :   PTR stp1, PTR stp2
**
**  Return      :   int
**
**  Création	:   DDV - 140716 - PMSTA-16528
**
*************************************************************************/
STATIC int DBA_CmpFmtEltBySqlname(DBA_DYNFLD_STP *stp1, DBA_DYNFLD_STP *stp2)
{
    return(CMP_DYNFLD((*stp1), (*stp2), A_FmtElt_SqlName, A_FmtElt_SqlName, SysnameType));
}

/************************************************************************
**
**  Function    :   DBA_CmpXdAttribBySqlname
**
**  Description :   Sort xd_attribute element by sqlname_c
**
**  Arguments   :   PTR stp1, PTR stp2
**
**  Return      :   int
**
**  Création	:   DDV - 140716 - PMSTA-16528
**
*************************************************************************/
STATIC int DBA_CmpXdAttribBySqlname(DBA_DYNFLD_STP *stp1, DBA_DYNFLD_STP *stp2)
{
    return(CMP_DYNFLD((*stp1), (*stp2), A_XdAttrib_SqlName, A_XdAttrib_SqlName, SysnameType));
}

/************************************************************************
**  Function    :   DBA_CopyFmtEltRankInAttribProgN
**
**  Description :   Complete xd model for multilingual nformation.
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED if success, or error code
**
**  Creation	:   PMSTA16528 - DDV - 140716
**
*************************************************************************/
STATIC RET_CODE DBA_CopyFmtEltRankInAttribProgN(DBA_DYNFLD_STP *fmtEltTab, int fmtEltNbr, DBA_DYNFLD_STP *xdAttribTab, int xdAttribNbr, DbiConnectionHelper &dbiConnHelper)
{
    RET_CODE ret = RET_SUCCEED;

    for (int i = 0, j = 0; i < fmtEltNbr && ret == RET_SUCCEED; i++)
    {
        while (j < xdAttribNbr && CMP_DYNFLD(xdAttribTab[j], fmtEltTab[i], A_XdAttrib_SqlName, A_FmtElt_SqlName, SysnameType) < 0)
        {
            j++;
        }

        if (j<xdAttribNbr && CMP_DYNFLD(xdAttribTab[j], fmtEltTab[i], A_XdAttrib_SqlName, A_FmtElt_SqlName, SysnameType) == 0)
        {
            SET_INT(xdAttribTab[j], A_XdAttrib_Prog,
                    GET_SMALLINT(fmtEltTab[i], A_FmtElt_Rank)); /* PMSTA-18720 - DDV - 141918 - Fix wrong access type error */
            SET_INT(xdAttribTab[j], A_XdAttrib_OldProg,
                    GET_SMALLINT(fmtEltTab[i], A_FmtElt_Rank)); /* PMSTA-18720 - DDV - 141918 - Fix wrong access type error */

            SET_MASK(xdAttribTab[j], A_XdAttrib_QuickSearchMask, 1);
            SET_MASK(xdAttribTab[j], A_XdAttrib_SearchMask, 1);

            ret = dbiConnHelper.dbaUpdate(XdAttrib, UNUSED, xdAttribTab[j]);
        }
    }

    return(ret);
}
/************************************************************************
**  Function    :   DBA_ConvertFmtDenomToLabel
**
**  Description :   Convert format's and format element's denomination to xdLabel
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED if success, or error code
**
**  Creation	:   PMSTA13876 - DDV - 130806
**
*************************************************************************/
STATIC RET_CODE DBA_ConvertFmtDenomToLabel(DBA_DYNFLD_STP shXdEntityStp,  DBA_DYNFLD_STP fmtStp,
                                           DBA_DYNFLD_STP *fmtEltTab,     int fmtEltNbr,
                                           DBA_DYNFLD_STP *xdAttribTab,   int xdAttribNbr,
                                           DBA_DYNFLD_STP *denomTab,      int denomNbr,
                                           DBA_DYNFLD_STP *xdLabelTab,    int xdLabelNbr,
                                           DbiConnectionHelper &dbiConnHelper)
{
    int             i=0, j=0;
    DICT_T          xdEntityDictId, xdAttributeDictId;
    DICT_T          fmtDictId, fmtEltDictId;
    DBA_DYNFLD_STP  fmtEltPtr;
    DBA_DYNFLD_STP  xdLabelPtr;
    DICT_T          xdLabelDictId;
    ID_T            xdLabelObjectId;
    FLAG_T          allocFlg;

    DBA_GetDictId(XdEntity,    &xdEntityDictId);
    DBA_GetDictId(XdAttrib,    &xdAttributeDictId);
    DBA_GetDictId(Fmt,         &fmtDictId);
    DBA_GetDictId(FmtElt,      &fmtEltDictId);

    for (j = 0; j < xdLabelNbr; j++)
    {
        xdLabelPtr = xdLabelTab[j];
        SET_ENUM(xdLabelPtr, A_XdLabel_XdActionEn, XdAction_ToPhysicallyDelete);

        dbiConnHelper.dbaUpdate(XdLabel, UNUSED, xdLabelPtr);
    }

    /* for each denom, creat a XdLabel record */
    for (i=0; i<denomNbr;i++)
    {
        xdLabelDictId   = InvalidEntityCst;
        xdLabelObjectId = NO_VALUE;

        if (GET_DICT(denomTab[i], A_Denom_EntDictId) == fmtDictId)
        {
            if (GET_ID(denomTab[i], A_Denom_ObjId) == GET_ID(fmtStp, A_Fmt_Id))
            {
                xdLabelDictId   = xdEntityDictId;
                xdLabelObjectId = GET_ID(shXdEntityStp, S_XdEntity_Id);
            }
        }
        else if (GET_DICT(denomTab[i], A_Denom_EntDictId) == fmtEltDictId)
        {
            fmtEltPtr=NULL;
            for (j=0; j<fmtEltNbr; j++)
            {
                if (GET_ID(denomTab[i], A_Denom_ObjId) == GET_ID(fmtEltTab[j], A_FmtElt_Id))
                {
                    fmtEltPtr=fmtEltTab[j];
                    break;
                }
            }

            if (fmtEltPtr != NULL)
            {
                for (j=0; j<xdAttribNbr; j++)
                {
                    if (strcmp(GET_SYSNAME(fmtEltPtr, A_FmtElt_SqlName), GET_SYSNAME(xdAttribTab[j], A_XdAttrib_SqlName)) == 0)
                    {
                        xdLabelDictId   = xdAttributeDictId;
                        xdLabelObjectId = GET_ID(xdAttribTab[j], A_XdAttrib_Id);
                        break;
                    }
                }
            }
        }

        if (xdLabelDictId != InvalidEntityCst && xdLabelObjectId != NO_VALUE)
        {
            xdLabelPtr = NULLDYNST;
            for (j=0; j<xdLabelNbr;j++)
            {
                if (GET_DICT(xdLabelTab[j], A_XdLabel_EntityDictId) == xdLabelDictId &&
                    GET_ID(xdLabelTab[j], A_XdLabel_ObjId) == xdLabelObjectId &&
                    GET_DICT(xdLabelTab[j], A_XdLabel_LangDictId) == GET_DICT(denomTab[i], A_Denom_LangEntDictId))
                {
                    xdLabelPtr = xdLabelTab[j];
                    break;
                }
            }

            allocFlg = FALSE;
            if (xdLabelPtr == NULLDYNST)
            {
                xdLabelPtr = ALLOC_DYNST(A_XdLabel);
                allocFlg = TRUE;
            }

            if (xdLabelPtr != NULLDYNST)
            {
                DBA_SetDfltEntityFld(XdLabel, A_XdLabel, xdLabelPtr);

                SET_DICT(xdLabelPtr, A_XdLabel_EntityDictId, xdLabelDictId);
                SET_ID(xdLabelPtr, A_XdLabel_ObjId, xdLabelObjectId);
                COPY_DYNFLD(xdLabelPtr,   A_XdLabel, A_XdLabel_LangDictId,
                            denomTab[i],  A_Denom,   A_Denom_LangEntDictId);

                COPY_DYNFLD(xdLabelPtr,   A_XdLabel, A_XdLabel_Name,
                            denomTab[i],  A_Denom,   A_Denom_Denom);
                SET_ENUM(xdLabelPtr, A_XdLabel_XdActionEn, XdAction_ToInsert);
                SET_ENUM(xdLabelPtr, A_XdLabel_XdStatusEn, XdStatus_Untreated);

                if (allocFlg == TRUE)
                {
                    dbiConnHelper.dbaInsert(XdLabel, UNUSED, xdLabelPtr);
                    FREE_DYNST(xdLabelPtr, A_XdLabel);
                }
                else
                {
                    dbiConnHelper.dbaUpdate(XdLabel, UNUSED, xdLabelPtr);
                }
            }
        }
    }

    return(RET_SUCCEED);
}

/************************************************************************
**  Function    :   DBA_CompleteXdModelForFmt
**
**  Description :   Complete xd model. Basis is created during Fmt/FmtElt insert and update.
**                  But multilingual FmtElt and Labels are not treated.
**
**  Arguments   :   shXdEntity     xd Entity to complete
**
**  Return      :   RET_SUCCEED if success, or error code
**
**  Creation	:   PMSTA13876 - DDV - 130806
**
*************************************************************************/
RET_CODE DBA_CompleteXdModelForFmt(DBA_DYNFLD_STP shXdEntityStp, DdlGenContext &ddlGenContext)
{
    if (shXdEntityStp == nullptr)
    {
        MSG_RETURN(RET_GEN_ERR_INVARG);
    }

    DBA_DYNFLD_STP  *data[]     = {NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR};
    int             rows[]      = {0,0,0,0,0};
    int             fmtPos      = 0;
    int             fmtEltPos   = 1;
    int             denomPos    = 2;
    int             xdAttribPos = 3;
    int             xdLabelPos  = 4;

    MemoryPool          mp;
    DdlGenConnGuard     ddlGenConnGuard(ddlGenContext);
    DbiConnectionHelper dbiConnHelper(&ddlGenConnGuard.getDbiConn());

    if (dbiConnHelper.getConnection()->getDdlGenDbaAccessPtr() == nullptr)
    {
        /* Load all data */
        if (dbiConnHelper.dbaMultiSelect(XdEntity,
                                         DBA_ROLE_FORMAT,
                                         shXdEntityStp,
                                         data,
                                         rows) != RET_SUCCEED)
        {
            MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "Retrieving Format information to complete xd model has failed");
            return(RET_DBA_ERR_NODATA);
        }
        mp.ownerDynStpTab(data[fmtPos], rows[fmtPos]);
    }
    else
    {
        DBA_DYNFLD_STP  sFmtRec = mp.allocDynst(FILEINFO, S_Fmt);
        data[fmtPos] = static_cast<DBA_DYNFLD_STP *>(mp.calloc(FILEINFO, 1, sizeof(DBA_DYNFLD_STP *)));
        data[fmtPos][0] = mp.allocDynst(FILEINFO, A_Fmt);

        COPY_DYNFLD(sFmtRec, S_Fmt, S_Fmt_Cd, shXdEntityStp, S_XdEntity, S_XdEntity_SqlName);
        dbiConnHelper.dbaGet(Fmt, UNUSED, sFmtRec, &data[fmtPos][0]);
        rows[fmtPos] = 1;

        CONVERT_DYNST(sFmtRec, S_Fmt, data[fmtPos][0], A_Fmt);
        dbiConnHelper.dbaSelect(FmtElt, UNUSED, sFmtRec, A_FmtElt, &data[fmtEltPos], &rows[fmtEltPos]);

        dbiConnHelper.dbaSelect(XdEntity, DBA_ROLE_FORMAT, shXdEntityStp, A_Denom, &data[denomPos], &rows[denomPos]);
        dbiConnHelper.dbaSelect(XdAttrib, UNUSED,          shXdEntityStp, A_XdAttrib, &data[xdAttribPos], &rows[xdAttribPos]);
        dbiConnHelper.dbaSelect(XdLabel,  DBA_ROLE_FORMAT, shXdEntityStp, A_XdLabel, &data[xdLabelPos], &rows[xdLabelPos]);
    }
    mp.ownerDynStpTab(data[fmtEltPos], rows[fmtEltPos]);
    mp.ownerDynStpTab(data[denomPos], rows[denomPos]);
    mp.ownerDynStpTab(data[xdAttribPos], rows[xdAttribPos]);
    mp.ownerDynStpTab(data[xdLabelPos], rows[xdLabelPos]);

    /* PMSTA-16528 - DDV - 140716 - Sort format elements and xd attributes by sqlname_c */
    if (rows[fmtEltPos] > 1)
    {
        TLS_Sort((char *)data[fmtEltPos], rows[fmtEltPos], sizeof(DBA_DYNFLD_STP),
            (TLS_CMPFCT *)DBA_CmpFmtEltBySqlname, NULL, SortRtnTp_None);
    }

    if (rows[xdAttribPos] > 1)
    {
        TLS_Sort((char *)data[xdAttribPos], rows[xdAttribPos], sizeof(DBA_DYNFLD_STP),
            (TLS_CMPFCT *)DBA_CmpXdAttribBySqlname, NULL, SortRtnTp_None);
    }
    else
    {
        SET_ENUM(shXdEntityStp, S_XdEntity_XdActionEn, XdAction_ToPhysicallyDelete);
    }

    if (rows[fmtEltPos] > 0)
    {
        DBA_CopyFmtEltRankInAttribProgN(data[fmtEltPos], rows[fmtEltPos], data[xdAttribPos], rows[xdAttribPos], dbiConnHelper);
        DBA_TreatMultiLingualFmtElt(shXdEntityStp, data[fmtEltPos], rows[fmtEltPos], data[xdAttribPos], rows[xdAttribPos], dbiConnHelper);
    }
    else
    {
        SET_ENUM(shXdEntityStp, S_XdEntity_XdActionEn, XdAction_ToPhysicallyDelete);
    }

    if (rows[fmtPos] > 0)
    {
        DBA_ConvertFmtDenomToLabel(shXdEntityStp, data[fmtPos][0],
                                   data[fmtEltPos], rows[fmtEltPos],
                                   data[xdAttribPos], rows[xdAttribPos],
                                   data[denomPos], rows[denomPos],
                                   data[xdLabelPos], rows[xdLabelPos],
                                   dbiConnHelper);
    }

    return(RET_SUCCEED);
}

/************************************************************************
**  Function    :   DBA_ConvertQuestDefToXdEntity
**
**  Description :   Create xd_entity record based on questionnaire_def record
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED if success, or error code
**
**  Creation	:   PMSTA-19243 - DDV - 150326
**
*************************************************************************/
RET_CODE DBA_ConvertQuestDefToXdEntity(DBA_DYNFLD_STP       questDefStp,
                                       DBA_DYNFLD_STP      *xdEntityStp,
                                       FLAG_T               updDbFlg,
                                       DbiConnectionHelper &dbiConnHelper)
{
    RET_CODE           ret = RET_SUCCEED;
    DBA_DYNFLD_STP     xdEntityRec = NULLDYNST;
    SYSNAME_T          entitySqlname;
    ID_T               recordId = 0;

    entitySqlname[0] = END_OF_STRING;
    (*xdEntityStp) = NULL;

    if (strlen(GET_SYSNAME(questDefStp, A_QuestDef_Cd)) > GET_MAXCHARLEN(SysnameType) - 3)
    {
        MSG_RETURN(RET_GEN_ERR_INVARG);
    }

    strcat(entitySqlname, "qu_");
    strcat(entitySqlname, GET_SYSNAME(questDefStp, A_QuestDef_Cd));
    if (GET_ENUM(questDefStp, A_QuestDef_CategoryEn) == (ENUM_T)QuestDefCategoryEn::Extensible)
    {
        SYSNAME_T buf;
        NUMBER_T  version = GET_NUMBER(questDefStp, A_QuestDef_Version);
        sprintf(buf, "%.0f", version);
        strcat(entitySqlname, "_");
        strcat(entitySqlname, buf);
    }

    if ((xdEntityRec = ALLOC_DYNST(A_XdEntity)) == NULLDYNST)
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    if (updDbFlg == TRUE)
    {
        SET_SYSNAME(xdEntityRec, A_XdEntity_SqlName, entitySqlname);

        if (dbiConnHelper.dbaGet(XdEntity, UNUSED, xdEntityRec, &xdEntityRec) == RET_SUCCEED)
        {
            recordId = GET_ID(xdEntityRec, A_XdEntity_Id);

            if (GET_ENUM(questDefStp, A_QuestDef_StatusEn) == QuestStatus_Rejected ||
                GET_ENUM(questDefStp, A_QuestDef_StatusEn) == QuestStatus_Suspended ||
                GET_ENUM(questDefStp, A_QuestDef_StatusEn) == QuestStatus_Deprecated ||
                GET_ENUM(questDefStp, A_QuestDef_StatusEn) == QuestStatus_Expired ||
                (GET_ENUM(questDefStp, A_QuestDef_CategoryEn) == (ENUM_T)QuestDefCategoryEn::Extensible &&
                    GET_ENUM(questDefStp, A_QuestDef_StatusEn) == QuestStatus_Cancelled) ||
                    (GET_ENUM(questDefStp, A_QuestDef_CategoryEn) != (ENUM_T)QuestDefCategoryEn::Extensible &&
                (GET_ENUM(questDefStp, A_QuestDef_StatusEn) == QuestStatus_Validated ||
                    GET_ENUM(questDefStp, A_QuestDef_StatusEn) == QuestStatus_Active)))
            {
                SET_ENUM(xdEntityRec, A_XdEntity_XdActionEn, XdAction_None);
                SET_ENUM(xdEntityRec, A_XdEntity_XdStatusEn, XdStatus_Inserted);

                ret = dbiConnHelper.dbaUpdate(XdEntity, DBA_ROLE_UDT, xdEntityRec);

                FREE_DYNST(xdEntityRec, A_XdEntity);

                if (ret == RET_SUCCEED)
                    return(RET_GEN_ERR_NOACTION);
                else
                    return(ret);
            }
        }
        SET_NULL_DYNST(xdEntityRec, A_XdEntity);
    }

    if ((ret = DBA_SetDfltEntityFld(XdEntity, A_XdEntity, xdEntityRec)) != RET_SUCCEED)
    {
        FREE_DYNST(xdEntityRec, A_XdEntity);
        return(ret);
    }

    DBA_ResetGetSetFlg(xdEntityRec, A_XdEntity);

    SET_SYSNAME(xdEntityRec, A_XdEntity_SqlName, entitySqlname);

    /* PMSTA-28633 - DDV - 170929 - Use COPY_DYNFLD to manage unicode string to string convertion */
    COPY_DYNFLD(xdEntityRec, A_XdEntity, A_XdEntity_Name, questDefStp, A_QuestDef, A_QuestDef_Name);

    SET_ENUM(xdEntityRec, A_XdEntity_AuditEn, FeatureAuth_Forbidden);
    SET_FLAG(xdEntityRec, A_XdEntity_CustAuthFlg, FALSE);
    SET_ENUM(xdEntityRec, A_XdEntity_SecurityLevelEn, EntSecuLevel_NoSecured);
    SET_FLAG(xdEntityRec, A_XdEntity_MainFlg, TRUE);
    SET_FLAG(xdEntityRec, A_XdEntity_IdentityFlg, FALSE);
    SET_ENUM(xdEntityRec, A_XdEntity_InterfaceEn, 1);
    SET_ENUM(xdEntityRec, A_XdEntity_NatEn, EntityNat_Questionnaire);
    SET_ENUM(xdEntityRec, A_XdEntity_PkRuleEn, PkRule_NoIdentity);

    if (GET_ENUM(questDefStp, A_QuestDef_CategoryEn) == (ENUM_T)QuestDefCategoryEn::Extensible)
    {
        /* set automatic mask */
        SET_MASKBIT(xdEntityRec, A_XdEntity_AutomaticMask, Automatic_Table, FALSE);
        SET_MASKBIT(xdEntityRec, A_XdEntity_AutomaticMask, Automatic_SProc, FALSE);
        SET_MASKBIT(xdEntityRec, A_XdEntity_AutomaticMask, Automatic_Trigger, FALSE);
        SET_MASKBIT(xdEntityRec, A_XdEntity_AutomaticMask, Automatic_Index, FALSE);
        SET_MASKBIT(xdEntityRec, A_XdEntity_AutomaticMask, Automatic_ViewFullAllSecured, FALSE);
        SET_MASKBIT(xdEntityRec, A_XdEntity_AutomaticMask, Automatic_ViewFullAll, FALSE);
        SET_MASKBIT(xdEntityRec, A_XdEntity_AutomaticMask, Automatic_ViewLightAll, FALSE);
        SET_MASKBIT(xdEntityRec, A_XdEntity_AutomaticMask, Automatic_ViewShortSecured, FALSE);
        SET_MASKBIT(xdEntityRec, A_XdEntity_AutomaticMask, Automatic_ViewShort, FALSE);
        SET_MASKBIT(xdEntityRec, A_XdEntity_AutomaticMask, Automatic_ViewFullAll4ForeignKey, FALSE);
        SET_MASKBIT(xdEntityRec, A_XdEntity_AutomaticMask, Automatic_MetaDictionary, FALSE);
        SET_MASKBIT(xdEntityRec, A_XdEntity_AutomaticMask, Automatic_Short, FALSE);
        SET_MASKBIT(xdEntityRec, A_XdEntity_AutomaticMask, Automatic_ShowInGUIMenu, FALSE);
        SET_FLAG(xdEntityRec, A_XdEntity_LogicalFlg, TRUE);
    }
    else
    {
        /* set automatic mask */
        SET_MASKBIT(xdEntityRec, A_XdEntity_AutomaticMask, Automatic_Table, TRUE);
        SET_MASKBIT(xdEntityRec, A_XdEntity_AutomaticMask, Automatic_SProc, TRUE);
        SET_MASKBIT(xdEntityRec, A_XdEntity_AutomaticMask, Automatic_Trigger, TRUE);
        SET_MASKBIT(xdEntityRec, A_XdEntity_AutomaticMask, Automatic_Index, TRUE);
        SET_MASKBIT(xdEntityRec, A_XdEntity_AutomaticMask, Automatic_ViewFullAllSecured, TRUE);
        SET_MASKBIT(xdEntityRec, A_XdEntity_AutomaticMask, Automatic_ViewFullAll, TRUE);
        SET_MASKBIT(xdEntityRec, A_XdEntity_AutomaticMask, Automatic_ViewLightAll, TRUE);
        SET_MASKBIT(xdEntityRec, A_XdEntity_AutomaticMask, Automatic_ViewShortSecured, TRUE);
        SET_MASKBIT(xdEntityRec, A_XdEntity_AutomaticMask, Automatic_ViewShort, TRUE);
        SET_MASKBIT(xdEntityRec, A_XdEntity_AutomaticMask, Automatic_ViewFullAll4ForeignKey, TRUE);
        SET_MASKBIT(xdEntityRec, A_XdEntity_AutomaticMask, Automatic_MetaDictionary, TRUE);
        SET_MASKBIT(xdEntityRec, A_XdEntity_AutomaticMask, Automatic_Short, FALSE);
        SET_MASKBIT(xdEntityRec, A_XdEntity_AutomaticMask, Automatic_ShowInGUIMenu, TRUE);
        SET_FLAG(xdEntityRec, A_XdEntity_LogicalFlg, FALSE);	
    }
    SET_FLAG(xdEntityRec, A_XdEntity_QuickSearchFlg, TRUE);
    SET_ENUM(xdEntityRec, A_XdEntity_XdActionEn, XdAction_ToInsert);
    SET_ENUM(xdEntityRec, A_XdEntity_XdStatusEn, XdStatus_Untreated);

    SCPT_ComputeScreenDV(XdEntity,
                         DictFct_0,
                         NULL, /* pflagScpt, */
                         NULL,              /* HFI-PMSTA-25327-171023  Dedicated flag tab for filter    */
                         xdEntityRec,
                         NULL,
                         NULLDYNST,
                         NULLDYNST,
                         TRUE,	            /* analyse type (all)*/
                         FALSE,				/* guiFlag */
                         EvalType_DefVal,
                         0,					/* attribIdx */
                         &(dbiConnHelper.getConnection()->getId()),              /* connectNo */
                         NULL,				/* filterTab */
                         NULL,	            /* hierHead */
                         0,
                         NullEntity,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NullEntity,
                         FALSE,
                         FALSE,
                         0);

    if (updDbFlg == TRUE)
    {
        if (recordId == 0)
        {
            ret = dbiConnHelper.dbaInsert(XdEntity, UNUSED, xdEntityRec);
        }
        else
        {
            SET_ID(xdEntityRec, A_XdEntity_Id, recordId);
            ret = dbiConnHelper.dbaUpdate(XdEntity, UNUSED, xdEntityRec);
        }

        if (ret == RET_SUCCEED)
        {
            ret = dbiConnHelper.dbaUpdate(XdEntity, DBA_ROLE_STATUS, xdEntityRec);
        }
    }

    (*xdEntityStp) = xdEntityRec;

    return(ret);
}

/************************************************************************
**  Function    :   DBA_ConvertQuestEltDefToXdAttrib
**
**  Description :   Create xd_attribute record based on questionnaire_element_def record
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED if success, or error code
**
**  Creation	:   PMSTA-19243 - DDV - 150326
**
*************************************************************************/
RET_CODE DBA_ConvertQuestEltDefToXdAttrib(DBA_DYNFLD_STP       xdEntityStp,
                                          DBA_DYNFLD_STP       questEltDefStp,
                                          DBA_DYNFLD_STP      *xdAttribStp,
                                          FLAG_T               updDbFlg,
                                          DbiConnectionHelper &dbiConnHelper)
{
    RET_CODE           ret = RET_SUCCEED;
    DBA_DYNFLD_STP     xdAttribRec = NULLDYNST;
    ID_T               recordId = 0;
    SMALLINT_T         dispRank = 0;
    OBJECT_ENUM        refObjectEn = NullEntity;

    (*xdAttribStp) = NULL;

    if ((xdAttribRec = ALLOC_DYNST(A_XdAttrib)) == NULLDYNST)
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    if (updDbFlg == TRUE)
    {
        COPY_DYNFLD(xdAttribRec, A_XdAttrib, A_XdAttrib_XdEntityId,
                    xdEntityStp, A_XdEntity, A_XdEntity_Id);
        COPY_DYNFLD(xdAttribRec,    A_XdAttrib,            A_XdAttrib_SqlName,
                    questEltDefStp, A_QuestEltDef, A_QuestEltDef_Cd);

        if (dbiConnHelper.dbaGet(XdAttrib, UNUSED, xdAttribRec, &xdAttribRec) == RET_SUCCEED)
        {
            recordId = GET_ID(xdAttribRec, A_XdAttrib_Id);
        }
        SET_NULL_DYNST(xdAttribRec, A_XdAttrib);
    }

    if ((ret = DBA_SetDfltEntityFld(XdAttrib, A_XdAttrib, xdAttribRec)) != RET_SUCCEED)
    {
        FREE_DYNST(xdAttribRec, A_XdAttrib);
        return(ret);
    }

    DBA_ResetGetSetFlg(xdAttribRec, A_XdAttrib);

    COPY_DYNFLD(xdAttribRec,    A_XdAttrib,     A_XdAttrib_XdEntityId,
                xdEntityStp,    A_XdEntity,     A_XdEntity_Id);
    COPY_DYNFLD(xdAttribRec,    A_XdAttrib,     A_XdAttrib_SqlName,
                questEltDefStp, A_QuestEltDef,  A_QuestEltDef_Cd);

    /* PMSTA-28633 - DDV - 170929 - Use COPY_DYNFLD to manage unicode string to string convertion */
    COPY_DYNFLD(xdAttribRec, A_XdAttrib, A_XdAttrib_Name, questEltDefStp, A_QuestEltDef, A_QuestEltDef_Name);

    if (DATATYPE_DICT_TO_ENUM(GET_DICT(questEltDefStp, A_QuestEltDef_AnswerDataTpDictId)) == FlagType)
    {
        SET_NAME (xdAttribRec, A_XdAttrib_Default, "0");
    }

    COPY_DYNFLD(xdAttribRec,    A_XdAttrib,     A_XdAttrib_DataTpDictId,
                questEltDefStp, A_QuestEltDef,  A_QuestEltDef_AnswerDataTpDictId);

    if (GET_SMALLINT(questEltDefStp, A_QuestEltDef_SectionRank) > 31)
        dispRank = 32000 + GET_SMALLINT(questEltDefStp, A_QuestEltDef_Rank);
    else
        dispRank = GET_SMALLINT(questEltDefStp, A_QuestEltDef_SectionRank) * 1000 + GET_SMALLINT(questEltDefStp, A_QuestEltDef_Rank);

    SET_SMALLINT(xdAttribRec, A_XdAttrib_DispRank, dispRank);
    SET_INT(xdAttribRec, A_XdAttrib_Prog, (INT_T) GET_SMALLINT(questEltDefStp, A_QuestEltDef_Rank));

    COPY_DYNFLD(xdAttribRec,    A_XdAttrib,     A_XdAttrib_MandatoryFlg,
                questEltDefStp, A_QuestEltDef,  A_QuestEltDef_MandatoryFlg);
    COPY_DYNFLD(xdAttribRec,    A_XdAttrib,     A_XdAttrib_DbMandatoryFlg,
                questEltDefStp, A_QuestEltDef,  A_QuestEltDef_MandatoryFlg);

    switch (GET_A_QuestEltDef_NatEn(questEltDefStp))
    {
        case QuestEltDefNatEn::Question:
            SET_ENUM(xdAttribRec, A_XdAttrib_CalcEn, DictAttr_Physical);
            break;
        case QuestEltDefNatEn::Score:
            SET_ENUM(xdAttribRec, A_XdAttrib_CalcEn, DictAttr_Physical);
            SET_ENUM(xdAttribRec, A_XdAttrib_EditEn, DictAttrib_EditNoEdit);
            break;
        case QuestEltDefNatEn::Comment:
            SET_ENUM(xdAttribRec, A_XdAttrib_CalcEn, DictAttr_Virtual);
            SET_ENUM(xdAttribRec, A_XdAttrib_EditEn, DictAttrib_EditNoEdit);
            break;
        case QuestEltDefNatEn::Technical:
        case QuestEltDefNatEn::Condition:
        case QuestEltDefNatEn::ObjectiveRule:
        case QuestEltDefNatEn::BusinessRule:
            SET_ENUM(xdAttribRec, A_XdAttrib_CalcEn, DictAttr_Physical);
            SET_ENUM(xdAttribRec, A_XdAttrib_EditEn, DictAttrib_EditNoEdit);
            SET_NULL_SMALLINT(xdAttribRec, A_XdAttrib_DispRank);
            break;
        case QuestEltDefNatEn::Virtual:
            SET_ENUM(xdAttribRec, A_XdAttrib_CalcEn, DictAttr_Virtual);
            break;
        default:
            break;
    }

    /* If attribute is "id" set it as PK/BK */
    if (strcmp(GET_SYSNAME(xdAttribRec, A_XdAttrib_SqlName), "id") == 0)
    {
        SET_FLAG(xdAttribRec,     A_XdAttrib_PrimaryFlg,        TRUE);
        SET_FLAG(xdAttribRec,     A_XdAttrib_MandatoryFlg,   TRUE);
        SET_FLAG(xdAttribRec,     A_XdAttrib_DbMandatoryFlg, TRUE);
    }
    else if (strcmp(GET_SYSNAME(xdAttribRec, A_XdAttrib_SqlName), "code") == 0)
    {
        SET_FLAG(xdAttribRec,     A_XdAttrib_PrimaryFlg,        FALSE);
        SET_FLAG(xdAttribRec,     A_XdAttrib_BusKeyFlg,      TRUE);
        SET_FLAG(xdAttribRec,     A_XdAttrib_MandatoryFlg,   TRUE);
        SET_FLAG(xdAttribRec,     A_XdAttrib_DbMandatoryFlg, TRUE);
        SET_SMALLINT(xdAttribRec, A_XdAttrib_ShortIdx,       1);
        SET_SMALLINT(xdAttribRec, A_XdAttrib_ShortDispRank,  1);
        SET_TINYINT(xdAttribRec,  A_XdAttrib_SortRank,       1);
        SET_ENUM(xdAttribRec,     A_XdAttrib_SortRuleEn,     SortRule_Ascending);
    }
    else
    {
        SET_FLAG(xdAttribRec,     A_XdAttrib_PrimaryFlg,        FALSE);
        SET_FLAG(xdAttribRec,     A_XdAttrib_BusKeyFlg,      FALSE);
    }

    DBA_GetObjectEnum(GET_DICT(questEltDefStp, A_QuestEltDef_RefEntityDictId), &refObjectEn);

    DICT_ENTITY_STP refEntityStp = DBA_GetDictEntitySt(refObjectEn);
    if (refEntityStp != nullptr &&
        refEntityStp->mdSqlName[0] != END_OF_STRING)
    {
        SET_ID(xdAttribRec, A_XdAttrib_RefXdEntityId, refEntityStp->xdEntityId);
    }

    SET_ENUM(xdAttribRec, A_XdAttrib_XdActionEn, XdAction_ToInsert);
    SET_ENUM(xdAttribRec, A_XdAttrib_XdStatusEn, XdStatus_Untreated);
    SET_MASK(xdAttribRec, A_XdAttrib_QuickSearchMask, 1);
    SET_MASK(xdAttribRec, A_XdAttrib_SearchMask, 1);

    SCPT_ComputeScreenDV(XdAttrib,
                         DictFct_0,
                         NULL, /* pflagScpt, */
                         NULL,              /* HFI-PMSTA-25327-171023  Dedicated flag tab for filter    */
                         xdAttribRec,
                         NULL,
                         NULLDYNST,
                         NULLDYNST,
                         TRUE,	            /* analyse type (all)*/
                         FALSE,				/* guiFlag */
                         EvalType_DefVal,
                         0,					/* attribIdx */
                         &dbiConnHelper.getConnection()->getId(),              /* connectNo */
                         NULL,				/* filterTab */
                         NULL,	            /* hierHead */
                         0,
                         NullEntity,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NullEntity,
                         FALSE,
                         FALSE,
                         0);

    if (updDbFlg == TRUE)
    {
        if (recordId != 0)
        {
            SET_ID(xdAttribRec, A_XdAttrib_Id, recordId);
            ret = dbiConnHelper.dbaUpdate(XdAttrib, UNUSED, xdAttribRec);
        }
        else
        {
            ret = dbiConnHelper.dbaInsert(XdAttrib, UNUSED, xdAttribRec);
        }

        if (ret == RET_SUCCEED)
        {
            ret = dbiConnHelper.dbaUpdate(XdAttrib, DBA_ROLE_STATUS, xdAttribRec);
        }
    }

    (*xdAttribStp) = xdAttribRec;

    return(ret);
}

/************************************************************************
**  Function    :   DBA_CreatePkXdAttrib
**
**  Description :   Create xd_attribute record for attribut id
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED if success, or error code
**
**  Creation	:   PMSTA-19243 - DDV - 150326
**
*************************************************************************/
RET_CODE DBA_CreatePkXdAttrib(DBA_DYNFLD_STP       xdEntityStp,
                              DBA_DYNFLD_STP      *xdAttribStp,
                              FLAG_T               updDbFlg,
                              DbiConnectionHelper &dbiConnHelper)
{
    RET_CODE           ret = RET_SUCCEED;
    DBA_DYNFLD_STP     xdAttribRec = NULLDYNST;
    ID_T               recordId = 0;

    (*xdAttribStp) = NULL;

    if ((xdAttribRec = ALLOC_DYNST(A_XdAttrib)) == NULLDYNST)
        MSG_RETURN(RET_MEM_ERR_ALLOC);

    if (updDbFlg == TRUE)
    {
        COPY_DYNFLD(xdAttribRec, A_XdAttrib, A_XdAttrib_XdEntityId,
                    xdEntityStp, A_XdEntity, A_XdEntity_Id);

        SET_SYSNAME(xdAttribRec, A_XdAttrib_SqlName, "questionnaire_histo_id");

        if (dbiConnHelper.dbaGet(XdAttrib, UNUSED, xdAttribRec, &xdAttribRec) == RET_SUCCEED)
        {
            recordId = GET_ID(xdAttribRec, A_XdAttrib_Id);
        }
        SET_NULL_DYNST(xdAttribRec, A_XdAttrib);
    }

    if ((ret = DBA_SetDfltEntityFld(XdAttrib, A_XdAttrib, xdAttribRec)) != RET_SUCCEED)
    {
        FREE_DYNST(xdAttribRec, A_XdAttrib);
        return(ret);
    }

    DBA_ResetGetSetFlg(xdAttribRec, A_XdAttrib);

    COPY_DYNFLD(xdAttribRec, A_XdAttrib, A_XdAttrib_XdEntityId,
                xdEntityStp, A_XdEntity, A_XdEntity_Id);

    SET_SYSNAME(xdAttribRec, A_XdAttrib_SqlName, "questionnaire_histo_id");
    SET_SYSNAME(xdAttribRec, A_XdAttrib_Name, "Questionnaire Histo");

    SET_DICT(xdAttribRec, A_XdAttrib_DataTpDictId, DATATYPE_ENUM_TO_DICT(IdType));

    SET_INT(xdAttribRec, A_XdAttrib_Prog, 0);

    SET_FLAG(xdAttribRec,     A_XdAttrib_PrimaryFlg,        TRUE);
    SET_FLAG(xdAttribRec,     A_XdAttrib_BusKeyFlg,      TRUE);
    SET_FLAG(xdAttribRec,     A_XdAttrib_MandatoryFlg,   TRUE);
    SET_FLAG(xdAttribRec,     A_XdAttrib_DbMandatoryFlg, TRUE);
    SET_SMALLINT(xdAttribRec, A_XdAttrib_ShortIdx,       0);
    SET_SMALLINT(xdAttribRec, A_XdAttrib_ShortDispRank,  1);
    SET_TINYINT(xdAttribRec,  A_XdAttrib_SortRank,       1);
    SET_ENUM(xdAttribRec,     A_XdAttrib_SortRuleEn,     SortRule_Ascending);
    SET_MASK(xdAttribRec,     A_XdAttrib_QuickSearchMask,1);
    SET_MASK(xdAttribRec,     A_XdAttrib_SearchMask,     1);

    SET_ENUM(xdAttribRec, A_XdAttrib_XdActionEn, XdAction_ToInsert);
    SET_ENUM(xdAttribRec, A_XdAttrib_XdStatusEn, XdStatus_Untreated);

    SCPT_ComputeScreenDV(XdAttrib,
                         DictFct_0,
                         NULL, /* pflagScpt, */
                         NULL,              /* HFI-PMSTA-25327-171023  Dedicated flag tab for filter    */
                         xdAttribRec,
                         NULL,
                         NULLDYNST,
                         NULLDYNST,
                         TRUE,	            /* analyse type (all)*/
                         FALSE,				/* guiFlag */
                         EvalType_DefVal,
                         0,					/* attribIdx */
                         &dbiConnHelper.getConnection()->getId(),              /* connectNo */
                         NULL,				/* filterTab */
                         NULL,	            /* hierHead */
                         0,
                         NullEntity,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NullEntity,
                         FALSE,
                         FALSE,
                         0);

    if (updDbFlg == TRUE)
    {
        if (recordId != 0)
        {
            SET_ID(xdAttribRec, A_XdAttrib_Id, recordId);
            ret = dbiConnHelper.dbaUpdate(XdAttrib, UNUSED, xdAttribRec);
        }
        else
        {
            ret = dbiConnHelper.dbaInsert(XdAttrib, UNUSED, xdAttribRec);
        }

        if (ret == RET_SUCCEED)
        {
            ret = dbiConnHelper.dbaUpdate(XdAttrib, DBA_ROLE_STATUS, xdAttribRec);
        }
    }
    (*xdAttribStp) = xdAttribRec;

    return(ret);
}

/************************************************************************
**  Function    :   RET_CODE DBA_CreateQuestHistoIdXdAttrib(DBA_DYNFLD_STP  m_xdEntityStp,

**
**  Description :   Create xd_attribute record for attribute questionnaire_histo_id
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED if success, or error code
**
**  Creation	:   PMSTA-19243 - DDV - 150326
**
*************************************************************************/
RET_CODE DBA_CreateQuestHistoIdXdAttrib(DBA_DYNFLD_STP       xdEntityStp,
                                        DBA_DYNFLD_STP      *xdAttribStp,
                                        FLAG_T               updDbFlg,
                                        DbiConnectionHelper &dbiConnHelper)
{
    RET_CODE           ret = RET_SUCCEED;
    DBA_DYNFLD_STP     xdAttribRec = NULLDYNST;
    ID_T               recordId = 0;
    
    (*xdAttribStp) = NULL;

    if ((xdAttribRec = ALLOC_DYNST(A_XdAttrib)) == NULLDYNST)
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    if (updDbFlg == TRUE)
    {
        COPY_DYNFLD(xdAttribRec, A_XdAttrib, A_XdAttrib_XdEntityId,
                    xdEntityStp, A_XdEntity, A_XdEntity_Id);

        SET_SYSNAME(xdAttribRec, A_XdAttrib_SqlName, "questionnaire_histo_id");

        if (dbiConnHelper.dbaGet(XdAttrib, UNUSED, xdAttribRec, &xdAttribRec) == RET_SUCCEED)
        {
            recordId = GET_ID(xdAttribRec, A_XdAttrib_Id);
        }
        SET_NULL_DYNST(xdAttribRec, A_XdAttrib);
    }

    if ((ret = DBA_SetDfltEntityFld(XdAttrib, A_XdAttrib, xdAttribRec)) != RET_SUCCEED)
    {
        FREE_DYNST(xdAttribRec, A_XdAttrib);
        return(ret);
    }

    DBA_ResetGetSetFlg(xdAttribRec, A_XdAttrib);

    COPY_DYNFLD(xdAttribRec, A_XdAttrib, A_XdAttrib_XdEntityId,
                xdEntityStp, A_XdEntity, A_XdEntity_Id);

    SET_SYSNAME(xdAttribRec, A_XdAttrib_SqlName, "questionnaire_histo_id");
    SET_SYSNAME(xdAttribRec, A_XdAttrib_Name, "Questionnaire Histo");

    SET_DICT(xdAttribRec, A_XdAttrib_DataTpDictId, DATATYPE_ENUM_TO_DICT(IdType));

    SET_INT(xdAttribRec, A_XdAttrib_Prog, 0);

    SET_FLAG(xdAttribRec,     A_XdAttrib_PrimaryFlg,        TRUE);
    SET_FLAG(xdAttribRec,     A_XdAttrib_BusKeyFlg,      TRUE);
    SET_FLAG(xdAttribRec,     A_XdAttrib_MandatoryFlg,   TRUE);
    SET_FLAG(xdAttribRec,     A_XdAttrib_DbMandatoryFlg, TRUE);

    SET_SMALLINT(xdAttribRec, A_XdAttrib_ShortIdx,       0);
    SET_SMALLINT(xdAttribRec, A_XdAttrib_ShortDispRank,  1);
    SET_TINYINT(xdAttribRec,  A_XdAttrib_SortRank,       1);
    SET_ENUM(xdAttribRec,     A_XdAttrib_SortRuleEn,     SortRule_Ascending);
    SET_MASK(xdAttribRec,     A_XdAttrib_QuickSearchMask,1);
    SET_MASK(xdAttribRec,     A_XdAttrib_SearchMask,     1);

    SET_ENUM(xdAttribRec, A_XdAttrib_XdActionEn, XdAction_ToInsert);
    SET_ENUM(xdAttribRec, A_XdAttrib_XdStatusEn, XdStatus_Untreated);

    DICT_ENTITY_STP  refEntityStp = DBA_GetDictEntitySt(QuestHisto);
    if (refEntityStp != nullptr &&
        refEntityStp->mdSqlName[0] != END_OF_STRING)
    {
        SET_ID(xdAttribRec, A_XdAttrib_RefXdEntityId, refEntityStp->xdEntityId);
    }

    SCPT_ComputeScreenDV(XdAttrib,
                         DictFct_0,
                         NULL, /* pflagScpt, */
                         NULL,              /* HFI-PMSTA-25327-171023  Dedicated flag tab for filter    */
                         xdAttribRec,
                         NULL,
                         NULLDYNST,
                         NULLDYNST,
                         TRUE,	            /* analyse type (all)*/
                         FALSE,				/* guiFlag */
                         EvalType_DefVal,
                         0,					/* attribIdx */
                         &dbiConnHelper.getConnection()->getId(),              /* connectNo */
                         NULL,				/* filterTab */
                         NULL,	            /* hierHead */
                         0,
                         NullEntity,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NullEntity,
                         FALSE,
                         FALSE,
                         0);

    if (updDbFlg == TRUE)
    {
        if (recordId != 0)
        {
            SET_ID(xdAttribRec, A_XdAttrib_Id, recordId);
            ret = dbiConnHelper.dbaUpdate(XdAttrib, UNUSED, xdAttribRec);
        }
        else
        {
            ret = dbiConnHelper.dbaInsert(XdAttrib, UNUSED, xdAttribRec);
        }

        if (ret == RET_SUCCEED)
        {
            ret = dbiConnHelper.dbaUpdate(XdAttrib, DBA_ROLE_STATUS, xdAttribRec);
        }
    }
    (*xdAttribStp) = xdAttribRec;

    return(ret);
}

/************************************************************************
**  Function    :   DBA_ConvertAnswerPVDefToXdPermVal
**
**  Description :   Create xd_perm_value record based on answer_perm_value_def record
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED if success, or error code
**
**  Creation	:   PMSTA-19243 - DDV - 150326
**
*************************************************************************/
RET_CODE DBA_ConvertAnswerPVDefToXdPermVal(DBA_DYNFLD_STP       xdAttribStp,
                                           DBA_DYNFLD_STP       answerPVDefStp,
                                           DBA_DYNFLD_STP      *xdPermValStp,
                                           FLAG_T               updDbFlg,
                                           DbiConnectionHelper &dbiConnHelper)
{
    RET_CODE           ret = RET_SUCCEED;
    DBA_DYNFLD_STP     xdPermValRec = NULLDYNST;
    ID_T               recordId = 0;

    (*xdPermValStp) = NULL;

    if ((xdPermValRec = ALLOC_DYNST(A_XdPermVal)) == NULLDYNST)
        MSG_RETURN(RET_MEM_ERR_ALLOC);

    if (updDbFlg == TRUE)
    {
        COPY_DYNFLD(xdPermValRec, A_XdPermVal, A_XdPermVal_XdAttribId,
                    xdAttribStp,  A_XdAttrib,  A_XdAttrib_Id);
        SET_ENUM(xdPermValRec, A_XdPermVal_PermValNatEn, GET_TINYINT(answerPVDefStp, A_AnswerPermValDef_PermValNat));

        if (dbiConnHelper.dbaGet(XdPermVal, UNUSED, xdPermValRec, &xdPermValRec) == RET_SUCCEED)
        {
            recordId = GET_ID(xdPermValRec, A_XdPermVal_Id);
        }
        SET_NULL_DYNST(xdPermValRec, A_XdPermVal);
    }

    if ((ret = DBA_SetDfltEntityFld(XdPermVal, A_XdPermVal, xdPermValRec)) != RET_SUCCEED)
    {
        FREE_DYNST(xdPermValRec, A_XdPermVal);
        return(ret);
    }

    DBA_ResetGetSetFlg(xdPermValRec, A_XdPermVal);

    COPY_DYNFLD(xdPermValRec, A_XdPermVal, A_XdPermVal_XdAttribId,
                xdAttribStp,  A_XdAttrib,  A_XdAttrib_Id);
    SET_ENUM(xdPermValRec, A_XdPermVal_PermValNatEn, GET_TINYINT(answerPVDefStp, A_AnswerPermValDef_PermValNat));

    COPY_DYNFLD(xdPermValRec, A_XdPermVal, A_XdPermVal_Name,
                answerPVDefStp,  A_AnswerPermValDef,  A_AnswerPermValDef_Name);

    COPY_DYNFLD(xdPermValRec, A_XdPermVal, A_XdPermVal_Rank,
                answerPVDefStp,  A_AnswerPermValDef,  A_AnswerPermValDef_Rank);

    SET_A_XdPermVal_PermValRuleEn(xdPermValRec, DictPermValPermValRuleEn::Standard);

    SET_ENUM(xdPermValRec, A_XdPermVal_XdActionEn, XdAction_ToInsert);
    SET_ENUM(xdPermValRec, A_XdPermVal_XdStatusEn, XdStatus_Untreated);

    if (updDbFlg == TRUE)
    {
        if (recordId != 0)
        {
            SET_ID(xdPermValRec, A_XdPermVal_Id, recordId);
            ret = dbiConnHelper.dbaUpdate(XdPermVal, UNUSED, xdPermValRec);
        }
        else
        {
            ret = dbiConnHelper.dbaInsert(XdPermVal, UNUSED, xdPermValRec);
        }

        if (ret == RET_SUCCEED)
        {
            ret = dbiConnHelper.dbaUpdate(XdPermVal, DBA_ROLE_STATUS, xdPermValRec);
        }
    }
    (*xdPermValStp) = xdPermValRec;

    return(ret);
}

/************************************************************************
**  Function    :   DBA_ConvertQuestEltCommentToXdAttComment
**
**  Description :   Create xd_attribute_comment record based on questionnaire_element_comment record
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED if success, or error code
**
**  Creation	:   PMSTA-19243 - DDV - 150511
**
*************************************************************************/
RET_CODE DBA_ConvertQuestEltCommentToXdAttComment(DBA_DYNFLD_STP       xdAttribStp,
                                                  DBA_DYNFLD_STP       questEltCommentStp,
                                                  DBA_DYNFLD_STP      *xdAttribCommentStp,
                                                  FLAG_T               updDbFlg,
                                                  DbiConnectionHelper &dbiConnHelper)
{
    RET_CODE           ret = RET_SUCCEED;
    DBA_DYNFLD_STP     xdAttribCommentRec = NULLDYNST;
    ID_T               recordId = 0;

    (*xdAttribCommentStp) = NULL;

    if ((xdAttribCommentRec = ALLOC_DYNST(A_XdAttribComment)) == NULLDYNST)
        MSG_RETURN(RET_MEM_ERR_ALLOC);

    if (updDbFlg == TRUE)
    {
        COPY_DYNFLD(xdAttribCommentRec, A_XdAttribComment, A_XdAttribComment_XdAttribId,
                    xdAttribStp,  A_XdAttrib,  A_XdAttrib_Id);
        COPY_DYNFLD(xdAttribCommentRec, A_XdAttribComment, A_XdAttribComment_LangDictId,
                    questEltCommentStp, A_QuestEltComment,  A_QuestEltComment_LangDictId);
        SET_ENUM(xdAttribCommentRec, A_XdAttribComment_NatEn, XdAttCommentNat_SysDoc);

        if (dbiConnHelper.dbaGet(XdAttribComment, UNUSED, xdAttribCommentRec, &xdAttribCommentRec) == RET_SUCCEED)
        {
            recordId = GET_ID(xdAttribCommentRec, A_XdAttribComment_Id);
        }
        SET_NULL_DYNST(xdAttribCommentRec, A_XdAttribComment);
    }

    if ((ret = DBA_SetDfltEntityFld(XdAttribComment, A_XdAttribComment, xdAttribCommentRec)) != RET_SUCCEED)
    {
        FREE_DYNST(xdAttribCommentRec, A_XdAttribComment);
        return(ret);
    }

    DBA_ResetGetSetFlg(xdAttribCommentRec, A_XdAttribComment);

    COPY_DYNFLD(xdAttribCommentRec, A_XdAttribComment, A_XdAttribComment_XdAttribId,
                xdAttribStp,  A_XdAttrib,  A_XdAttrib_Id);
    COPY_DYNFLD(xdAttribCommentRec, A_XdAttribComment, A_XdAttribComment_LangDictId,
                questEltCommentStp, A_QuestEltComment, A_QuestEltComment_LangDictId);
    SET_ENUM(xdAttribCommentRec, A_XdAttribComment_NatEn, XdAttCommentNat_SysDoc);

    COPY_DYNFLD(xdAttribCommentRec, A_XdAttribComment, A_XdAttribComment_Comment,
                questEltCommentStp, A_QuestEltComment, A_QuestEltComment_Comment);

    SET_ENUM(xdAttribCommentRec, A_XdAttribComment_XdActionEn, XdAction_ToInsert);
    SET_ENUM(xdAttribCommentRec, A_XdAttribComment_XdStatusEn, XdStatus_Untreated);

    if (updDbFlg == TRUE)
    {
        if (recordId != 0)
        {
            SET_ID(xdAttribCommentRec, A_XdAttribComment_Id, recordId);
            ret = dbiConnHelper.dbaUpdate(XdAttribComment, UNUSED, xdAttribCommentRec);
        }
        else
        {
            ret = dbiConnHelper.dbaInsert(XdAttribComment, UNUSED, xdAttribCommentRec);
        }

        if (ret == RET_SUCCEED)
        {
            ret = dbiConnHelper.dbaUpdate(XdAttribComment, DBA_ROLE_STATUS, xdAttribCommentRec);
        }

    }
    (*xdAttribCommentStp) = xdAttribCommentRec;

    return(ret);
}

/************************************************************************
**  Function    :   DBA_CreateXdLabel
**
**  Description :   Create xd_label record based on label record
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED if success, or error code
**
**  Creation	:   PMSTA-19243 - DDV - 150326
**
*************************************************************************/
RET_CODE DBA_CreateXdLabel(DICT_T               xdEntityDictId,
                           ID_T                 xdObjectId,
                           DBA_DYNFLD_STP       srcRecStp,
                           OBJECT_ENUM          srcObjectEn,
                           DBA_DYNFLD_STP      *xdLabelStp,
                           FLAG_T               updDbFlg,
                           DbiConnectionHelper &dbiConnHelper)
{
    RET_CODE           ret           = RET_SUCCEED;
    DBA_DYNFLD_STP     xdLabelRec    = NULLDYNST;
    ID_T               recordId      = 0;
    FIELD_IDX_T        langDictIdIdx = Null_Dynfld;
    FIELD_IDX_T        labelIdx      = Null_Dynfld;


    (*xdLabelStp) = NULL;

    switch (GET_OBJECT_CST(srcObjectEn))
    {
        case QuestDefLabelCst:
            langDictIdIdx = A_QuestDefLabel_LangDictId;
            labelIdx      = A_QuestDefLabel_Denom;
            break;

        case QuestEltLabelCst:
            langDictIdIdx = A_QuestEltLabel_LangDictId;
            labelIdx      = A_QuestEltLabel_Denom;
            break;

        case AnswerPermValLabelCst:
            langDictIdIdx = A_AnswerPermValLabel_LangDictId;
            labelIdx      = A_AnswerPermValLabel_Denom;
            break;

        default:
            MSG_RETURN(RET_GEN_ERR_INVARG);
    }

    if ((xdLabelRec = ALLOC_DYNST(A_XdLabel)) == NULLDYNST)
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }
        
    if (updDbFlg == TRUE)
    {
        COPY_DYNFLD(xdLabelRec, A_XdLabel, A_XdLabel_LangDictId,
                    srcRecStp,  GET_EDITGUIST(srcObjectEn),  langDictIdIdx);

        SET_DICT(xdLabelRec,A_XdLabel_EntityDictId, xdEntityDictId);
        SET_ID(xdLabelRec, A_XdLabel_ObjId, xdObjectId);
        SET_ENUM(xdLabelRec, A_XdLabel_NatEn, 1);

        if (dbiConnHelper.dbaGet(XdLabel, UNUSED, xdLabelRec, &xdLabelRec) == RET_SUCCEED)
        {
            recordId = GET_ID(xdLabelRec, A_XdLabel_Id);
        }
        SET_NULL_DYNST(xdLabelRec, A_XdLabel);
    }

    if ((ret = DBA_SetDfltEntityFld(XdLabel, A_XdLabel, xdLabelRec)) != RET_SUCCEED)
    {
        FREE_DYNST(xdLabelRec, A_XdLabel);
        return(ret);
    }

    DBA_ResetGetSetFlg(xdLabelRec, A_XdLabel);

    COPY_DYNFLD(xdLabelRec, A_XdLabel, A_XdLabel_LangDictId,
                srcRecStp,  GET_EDITGUIST(srcObjectEn),  langDictIdIdx);
    SET_DICT(xdLabelRec, A_XdLabel_EntityDictId, xdEntityDictId);
    SET_ID(xdLabelRec, A_XdLabel_ObjId, xdObjectId);
    SET_ENUM(xdLabelRec, A_XdLabel_NatEn, 1);

    COPY_DYNFLD(xdLabelRec,   A_XdLabel, A_XdLabel_Name,
                srcRecStp,  GET_EDITGUIST(srcObjectEn),   labelIdx);

    SET_ENUM(xdLabelRec, A_XdLabel_XdActionEn, XdAction_ToInsert);
    SET_ENUM(xdLabelRec, A_XdLabel_XdStatusEn, XdStatus_Untreated);

    if (updDbFlg == TRUE)
    {
        if (recordId != 0)
        {
            SET_ID(xdLabelRec, A_XdLabel_Id, recordId);
            ret = dbiConnHelper.dbaUpdate(XdLabel, UNUSED, xdLabelRec);
        }
        else
        {
            ret = dbiConnHelper.dbaInsert(XdLabel, UNUSED, xdLabelRec);
        }

        if (ret == RET_SUCCEED)
        {
            ret = dbiConnHelper.dbaUpdate(XdLabel, DBA_ROLE_STATUS, xdLabelRec);
        }

    }

    (*xdLabelStp) = xdLabelRec;

    return(ret);
}

/************************************************************************
**  Function    :   DBA_ConvertAnswerPVLabelToXdLabel
**
**  Description :   Create xd_label record based on answer_perm_value_def record and its label
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED if success, or error code
**
**  Creation	:   PMSTA-19243 - DDV - 150326
**
*************************************************************************/
RET_CODE DBA_ConvertAnswerPVLabelToXdLabel(DBA_DYNFLD_STP       xdPermValStp,
                                           DBA_DYNFLD_STP       answerPVLabelStp,
                                           DBA_DYNFLD_STP      *xdLabelStp,
                                           FLAG_T               updDbFlg,
                                           DbiConnectionHelper &dbiConnHelper)
{
    DICT_T             xdPermValDictId;

    DBA_GetDictId(XdPermVal,    &xdPermValDictId);

    return(DBA_CreateXdLabel(xdPermValDictId, GET_ID(xdPermValStp, A_XdPermVal_Id), answerPVLabelStp, AnswerPermValLabel, xdLabelStp, updDbFlg, dbiConnHelper));
}

/************************************************************************
**  Function    :   DBA_ConvertQuestDefLabelToXdLabel
**
**  Description :   Create xd_label record based on questionnaire_def record and its label
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED if success, or error code
**
**  Creation	:   PMSTA-19243 - DDV - 150326
**
*************************************************************************/
RET_CODE DBA_ConvertQuestDefLabelToXdLabel(DBA_DYNFLD_STP       xdEntityStp,
                                           DBA_DYNFLD_STP       questDefLabelStp,
                                           DBA_DYNFLD_STP      *xdLabelStp,
                                           FLAG_T               updDbFlg,
                                           DbiConnectionHelper &dbiConnHelper)
{
    DICT_T xdEntityDictId = 0;

    DBA_GetDictId(XdEntity, &xdEntityDictId);

    return(DBA_CreateXdLabel(xdEntityDictId, GET_ID(xdEntityStp, A_XdEntity_Id), questDefLabelStp, QuestDefLabel, xdLabelStp, updDbFlg, dbiConnHelper));
}

/************************************************************************
**  Function    :   DBA_ConvertQuestEltDefLabelToXdLabel
**
**  Description :   Create xd_label record based on questionnaire_element_def record and its label
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED if success, or error code
**
**  Creation	:   PMSTA-19243 - DDV - 150326
**
*************************************************************************/
RET_CODE DBA_ConvertQuestEltDefLabelToXdLabel(DBA_DYNFLD_STP       xdAttribStp,
                                              DBA_DYNFLD_STP       questEltLabelStp,
                                              DBA_DYNFLD_STP      *xdLabelStp,
                                              FLAG_T               updDbFlg,
                                              DbiConnectionHelper &dbiConnHelper)
{
    DICT_T xdAttribDictId = 0;

    DBA_GetDictId(XdAttrib, &xdAttribDictId);

    return(DBA_CreateXdLabel(xdAttribDictId, GET_ID(xdAttribStp, A_XdAttrib_Id), questEltLabelStp, QuestEltLabel, xdLabelStp, updDbFlg, dbiConnHelper));
}

/************************************************************************
**  Function    :   DBA_CreateXdModelForQuestByCd
**
**  Description :   Create xd model for questionnaire entity.
**
**  Arguments   :   shXdEntity     xd Entity to complete
**
**  Return      :   RET_SUCCEED if success, or error code
**
**  Creation	:   PMSTA-19243 - DDV - 150317
**
*************************************************************************/
RET_CODE DBA_CreateXdModelForQuest(DBA_DYNFLD_STP questDefStp, DbiConnectionHelper &dbiConnHelper, DdlGenContext &ddlGenContext)
{
    if (questDefStp == NULLDYNST)
        MSG_RETURN(RET_GEN_ERR_INVARG);

    /* PMSTA-39316 - obnilouf - 200413 */
    if (GET_ENUM(questDefStp, A_QuestDef_CategoryEn) == QuestCate_Dynamic)
    {
        return(RET_GEN_ERR_NOACTION);
    }

    RET_CODE              ret=RET_SUCCEED;
    MemoryPool            mp;

    std::set<ID_T>                 questDefSet;
    std::set<ID_T>                 newQuestDefSet;

    std::map<ID_T, DBA_DYNFLD_STP>              questSectDefMap;
    std::map<ID_T, std::vector<DBA_DYNFLD_STP>> questEltBySecMap;
    std::vector<DBA_DYNFLD_STP>                 questEltVector;
    std::map<ID_T, std::vector<DBA_DYNFLD_STP>> questAnswerPVMap;
    std::map<ID_T, std::vector<DBA_DYNFLD_STP>> questEltLabelMap;
    std::map<ID_T, std::vector<DBA_DYNFLD_STP>> questEltCommentMap;
    std::map<ID_T, std::vector<DBA_DYNFLD_STP>> questPVLabelMap;
    std::vector<DBA_DYNFLD_STP>                 questLabelVector;

    std::map<std::string, ID_T>                 dupSqlNameCheckMap;

    auto searchQuestDefStp = mp.duplicate(FILEINFO, questDefStp);

    questDefSet.insert(GET_ID(questDefStp, A_QuestDef_Id));
    newQuestDefSet = questDefSet;

    do
    {
        auto questDefToTreatSet = newQuestDefSet;
        newQuestDefSet.clear();

        for (auto &questDefIt : questDefToTreatSet)
        {
            DBA_DYNFLD_STP *questData[]        = { NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR };
            int             questRows[]        = { 0,0,0,0,0,0,0,0 };
            int             questDefLabelPos   = 0;
            int             questSectDefPos    = 1;
            int             questEltPos        = 2;
            int             questEltLabelPos   = 3;
            int             questAnswerPVPos   = 4;
            int             questPVLabelPos    = 5;
            int             questEltCommentPos = 6;
            int             questEltCompoPos   = 7;

            SET_ID(searchQuestDefStp, A_QuestDef_Id, questDefIt);

            if (ddlGenContext.ddlGenAction.m_fromImport)
            {
                DdlGenDbaAccessGuard ddlGenDbaAccessGuard(ddlGenContext);
                ddlGenDbaAccessGuard.getDdlGenDbaAccess().selRecords(QuestDefLabel, UNUSED, searchQuestDefStp, questData[questDefLabelPos], questRows[questDefLabelPos], mp);
                ddlGenDbaAccessGuard.getDdlGenDbaAccess().selRecords(QuestSectionDef, UNUSED, searchQuestDefStp, questData[questSectDefPos], questRows[questSectDefPos], mp);
                ddlGenDbaAccessGuard.getDdlGenDbaAccess().selRecords(QuestEltDef, UNUSED, searchQuestDefStp, questData[questEltPos], questRows[questEltPos], mp);
                ddlGenDbaAccessGuard.getDdlGenDbaAccess().selRecords(QuestionnaireDefCompo, UNUSED, searchQuestDefStp, questData[questEltCompoPos], questRows[questEltCompoPos], mp);

                for (int i = 0; i < questRows[questEltPos]; ++i)
                {
                    ddlGenDbaAccessGuard.getDdlGenDbaAccess().selRecords(QuestEltLabel, UNUSED, questData[questEltPos][i], questData[questEltLabelPos], questRows[questEltLabelPos], mp);
                    ddlGenDbaAccessGuard.getDdlGenDbaAccess().selRecords(AnswerPermValDef, UNUSED, questData[questEltPos][i], questData[questAnswerPVPos], questRows[questAnswerPVPos], mp);
                    ddlGenDbaAccessGuard.getDdlGenDbaAccess().selRecords(QuestEltComment, UNUSED, questData[questEltPos][i], questData[questEltCommentPos], questRows[questEltCommentPos], mp);
                }

                for (int i = 0; i < questRows[questAnswerPVPos]; ++i)
                {
                    ddlGenDbaAccessGuard.getDdlGenDbaAccess().selRecords(AnswerPermValLabel, UNUSED, questData[questAnswerPVPos][i], questData[questPVLabelPos], questRows[questPVLabelPos], mp);
                }
            }
            else
            {
                if (dbiConnHelper.dbaMultiSelect(QuestDef,
                                                 UNUSED,
                                                 searchQuestDefStp,
                                                 questData,
                                                 questRows) != RET_SUCCEED)
                {
                    MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "Retrieving Quest definition to create xd model has failed");
                    return(RET_DBA_ERR_NODATA);
                }

                for (int i = 0; i < (sizeof(questRows) / sizeof(questRows[0])); ++i)
                {
                    mp.ownerDynStpTab(questData[i], questRows[i]);
                }
            }

            for (int i = 0; i < questRows[questSectDefPos]; ++i)
            {
                questSectDefMap.insert(std::make_pair(GET_ID(questData[questSectDefPos][i], A_QuestSectionDef_Id),
                                                      questData[questSectDefPos][i]));
            }

            for (int i = 0; i < questRows[questEltPos]; ++i)
            {
                auto insertResult = dupSqlNameCheckMap.insert(std::make_pair(GET_CODE(questData[questEltPos][i], A_QuestEltDef_Cd), 
                                                                             GET_ID(questData[questEltPos][i], A_QuestEltDef_QuestionnaireDefId)));

                if (insertResult.second == false)
                {
                    std::string firstCode("N/A");
                    std::string secondCode("N/A");

                    auto dupQuestDefStp = mp.allocDynst(FILEINFO, S_QuestDef);

                    if (GET_ID(questDefStp, A_QuestDef_Id) == insertResult.first->second)
                    {
                        firstCode = SYS_Stringer(GET_CODE(questDefStp, A_QuestDef_Cd), "/", GET_INT(questDefStp, A_QuestDef_Revision));
                    }
                    else
                    {
                        SET_ID(dupQuestDefStp, S_QuestDef_Id, insertResult.first->second);
                        if (dbiConnHelper.dbaGet(QuestDef, UNUSED, dupQuestDefStp, &dupQuestDefStp) == RET_SUCCEED)
                        {
                            firstCode = SYS_Stringer(GET_CODE(dupQuestDefStp, S_QuestDef_Cd), "/", GET_INT(dupQuestDefStp, S_QuestDef_Revision));
                        }
                    }

                    SET_ID(dupQuestDefStp, S_QuestDef_Id, GET_ID(questData[questEltPos][i], A_QuestEltDef_QuestionnaireDefId));
                    if (dbiConnHelper.dbaGet(QuestDef, UNUSED, dupQuestDefStp, &dupQuestDefStp) == RET_SUCCEED)
                    {
                        secondCode = SYS_Stringer(GET_CODE(dupQuestDefStp, S_QuestDef_Cd), "/", GET_INT(dupQuestDefStp, S_QuestDef_Revision));
                    }

                    std::stringstream msg;
                    msg << "For questionnaire_def \"" << GET_CODE(questDefStp, A_QuestDef_Cd) << "\", duplicate values on questionnaire_element_def code \"" << GET_CODE(questData[questEltPos][i], A_QuestEltDef_Cd)
                         << "\" present on questionnaire_def \"" << firstCode << "\" and \"" << secondCode << "\"";

                    ret = RET_SRV_LIB_ERR_DUPLICATEKEY;
                    ddlGenContext.printMsg(ret, msg.str());
                }
                else
                {
                    if (GET_ID(questDefStp, A_QuestDef_Id) != GET_ID(searchQuestDefStp, A_QuestDef_Id))
                    {
                        SET_ID(questData[questEltPos][i], A_QuestEltDef_QuestionnaireDefId, GET_ID(questDefStp, A_QuestDef_Id));
                    }

                    questEltBySecMap[GET_ID(questData[questEltPos][i], A_QuestEltDef_QuestionnaireSectionDefId)].push_back(questData[questEltPos][i]);
                    questEltVector.push_back(questData[questEltPos][i]);
                }
            }

            if (GET_ID(questDefStp, A_QuestDef_Id) == GET_ID(searchQuestDefStp, A_QuestDef_Id))
            {
                for (int i = 0; i < questRows[questDefLabelPos]; ++i)
                {
                    questLabelVector.push_back(questData[questDefLabelPos][i]);
                }
            }

            for (int i = 0; i < questRows[questAnswerPVPos]; ++i)
            {
                questAnswerPVMap[GET_ID(questData[questAnswerPVPos][i], A_AnswerPermValDef_QuestionnaireElementDefId)].push_back(questData[questAnswerPVPos][i]);
            }

            for (int i = 0; i < questRows[questEltLabelPos]; ++i)
            {
                questEltLabelMap[GET_ID(questData[questEltLabelPos][i], A_QuestEltLabel_QuestionnaireElementDefId)].push_back(questData[questEltLabelPos][i]);
            }

            for (int i = 0; i < questRows[questEltCommentPos]; ++i)
            {
                questEltCommentMap[GET_ID(questData[questEltCommentPos][i], A_QuestEltComment_QuestionnaireElementDefId)].push_back(questData[questEltCommentPos][i]);
            }

            for (int i = 0; i < questRows[questPVLabelPos]; ++i)
            {
                questPVLabelMap[GET_ID(questData[questPVLabelPos][i], A_AnswerPermValLabel_AnswerPermittedValueDefId)].push_back(questData[questPVLabelPos][i]);
            }

            for (int i = 0; i < questRows[questEltCompoPos]; ++i)
            {
                if (questDefSet.insert(GET_ID(questData[questEltCompoPos][i], A_QuestionnaireDefCompo_ChildQuestionnaireDefId)).second)
                {
                    newQuestDefSet.insert(GET_ID(questData[questEltCompoPos][i], A_QuestionnaireDefCompo_ChildQuestionnaireDefId));
                }
            }
        }

    } while (newQuestDefSet.empty() == false);

    for (auto &questEltIt : questEltBySecMap)
    {
        auto questSectStp = questSectDefMap[questEltIt.first];

        for (auto questEltStp : questEltIt.second)
        {
            COPY_DYNFLD(questEltStp, A_QuestEltDef, A_QuestEltDef_SectionRank,
                        questSectStp, A_QuestSectionDef, A_QuestSectionDef_Rank);
        }
    }

    /* create/update xd_entity based on questionnaire_def record */
    DBA_DYNFLD_STP  xdEntityStp = nullptr;
    ret = DBA_ConvertQuestDefToXdEntity(questDefStp, &xdEntityStp, TRUE, dbiConnHelper);
    mp.ownerDynStp(xdEntityStp);

    if (ret == RET_SUCCEED)
    {
        if (GET_ID(xdEntityStp, A_XdEntity_Id) < 0)
        {
            ddlGenContext.m_parentContext->toInsertEntitySqlNameSet.insert(GET_SYSNAME(xdEntityStp, A_XdEntity_SqlName));
        }

        /* create all xd_label based on questionnaire_def's label records*/
        for (auto &questDefLabelStp : questLabelVector)
        {
            DBA_DYNFLD_STP xdLabelStp = nullptr;
            if ((ret = DBA_ConvertQuestDefLabelToXdLabel(xdEntityStp, questDefLabelStp, &xdLabelStp, TRUE, dbiConnHelper)) == RET_SUCCEED)
            {
                mp.ownerDynStp(xdLabelStp);
            }
        }


        DBA_DYNFLD_STP  codeXdAttribStp         = nullptr;
        DBA_DYNFLD_STP  questHistoIdXdAttribStp = nullptr;
        DBA_DYNFLD_STP  defaultXdPermValStp     = nullptr;
        DBA_DYNFLD_STP  flagXdAttribStp         = nullptr;

        /* create all xd_attributes based on questionnaire_element_def records */
        for (auto &questEltStp : questEltVector)
        {
            DBA_DYNFLD_STP xdAttribStp = nullptr;
            if ((ret = DBA_ConvertQuestEltDefToXdAttrib(xdEntityStp, questEltStp, &xdAttribStp, TRUE, dbiConnHelper)) == RET_SUCCEED)
            {
                mp.ownerDynStp(xdAttribStp);

                if (strcmp(GET_SYSNAME(xdAttribStp, A_XdAttrib_SqlName), "code") == 0)
                {
                    codeXdAttribStp = xdAttribStp;
                }
                else if (strcmp(GET_SYSNAME(xdAttribStp, A_XdAttrib_SqlName), "questionnaire_histo_id") == 0)
                {
                    questHistoIdXdAttribStp = xdAttribStp;
                }

                /* create all xd_label based on questionnaire_element_def's label records*/
                for (auto &questEltLabelStp : questEltLabelMap[GET_ID(questEltStp, A_QuestEltDef_Id)])
                {
                    DBA_DYNFLD_STP xdLabelStp = nullptr;
                    if ((ret = DBA_ConvertQuestEltDefLabelToXdLabel(xdAttribStp, questEltLabelStp, &xdLabelStp, TRUE, dbiConnHelper)) == RET_SUCCEED)
                    {
                        mp.ownerDynStp(xdLabelStp);
                    }
                }

                /* create all xd_attrib_comment based on questionnaire_element_comment records*/
                for (auto &questEltCommentStp : questEltCommentMap[GET_ID(questEltStp, A_QuestEltDef_Id)])
                {
                    DBA_DYNFLD_STP xdAttribCommentStp = nullptr;
                    if ((ret = DBA_ConvertQuestEltCommentToXdAttComment(xdAttribStp, questEltCommentStp, &xdAttribCommentStp, TRUE, dbiConnHelper)) == RET_SUCCEED)
                    {
                        mp.ownerDynStp(xdAttribCommentStp);
                    }
                }

                /* for enumeration, create all xd_perm_value based on answer_perm_value records */
                DATATYPE_ENUM   dataTypeEnum = DATATYPE_DICT_TO_ENUM(GET_DICT(questEltStp, A_QuestEltDef_AnswerDataTpDictId));
                if (dataTypeEnum  == EnumType || dataTypeEnum == EnumMaskType)
                {
                    defaultXdPermValStp = NULLDYNST;

                    for (auto &answerPVDefStp : questAnswerPVMap[GET_ID(questEltStp, A_QuestEltDef_Id)])
                    {
                        DBA_DYNFLD_STP xdPermValStp = nullptr;
                        if ((ret = DBA_ConvertAnswerPVDefToXdPermVal(xdAttribStp, answerPVDefStp, &xdPermValStp, TRUE, dbiConnHelper)) == RET_SUCCEED)
                        {
                            mp.ownerDynStp(xdPermValStp);

                            if (defaultXdPermValStp == NULLDYNST ||
                                GET_SMALLINT(xdPermValStp, A_XdPermVal_Rank) < GET_SMALLINT(defaultXdPermValStp, A_XdPermVal_Rank))
                            {
                                defaultXdPermValStp = xdPermValStp;
                            }

                            /* create all xd_label based on answer_perm_value's label records*/
                            for (auto &answerPVLabelStp : questPVLabelMap[GET_ID(answerPVDefStp, A_AnswerPermValDef_Id)])
                            {
                                DBA_DYNFLD_STP xdLabelStp = nullptr;
                                if ((ret = DBA_ConvertAnswerPVLabelToXdLabel(xdPermValStp, answerPVLabelStp, &xdLabelStp, TRUE, dbiConnHelper)) == RET_SUCCEED)
                                {
                                    mp.ownerDynStp(xdLabelStp);
                                }
                            }
                        }
                    }

                    /* update attribute's default_c with lowest rank DV */
                    if (defaultXdPermValStp != NULLDYNST)
                    {
                        NAME_T defC;
                        sprintf(defC, "%d", GET_ENUM(defaultXdPermValStp, A_XdPermVal_PermValNatEn));

                        if (defC[0] != END_OF_STRING)
                        {
                            SET_NAME(xdAttribStp, A_XdAttrib_Default, defC);
                            ret = dbiConnHelper.dbaUpdate(XdAttrib, UNUSED, xdAttribStp);
                        }
                    }
                }
                else if (dataTypeEnum == FlagType)
                {
                    if (flagXdAttribStp == nullptr)
                    {
                        auto tplDdlGenEntityPtr = ddlGenContext.getTemplateDdlGenEntityPtr();
                        if (tplDdlGenEntityPtr != nullptr)
                        {
                            flagXdAttribStp = tplDdlGenEntityPtr->getXdAttribBySqlName("active_f");
                        }
                    }
                    
                    if (flagXdAttribStp != nullptr)
                    {
                        COPY_DYNFLD(xdAttribStp, A_XdAttrib, A_XdAttrib_ParentXdAttribId, flagXdAttribStp, A_XdAttrib, A_XdAttrib_Id);
                        ret = dbiConnHelper.dbaUpdate(XdAttrib, UNUSED, xdAttribStp);
                    }
                }
            }
        }

        /* manage pk (questionnaire histo is is the pk) and code attributes */
        if (questHistoIdXdAttribStp != NULLDYNST)
        {
            if (codeXdAttribStp == NULLDYNST)
            {
                SET_FLAG(questHistoIdXdAttribStp,     A_XdAttrib_BusKeyFlg,      TRUE);
                SET_SMALLINT(questHistoIdXdAttribStp, A_XdAttrib_ShortIdx,       0);
                SET_SMALLINT(questHistoIdXdAttribStp, A_XdAttrib_ShortDispRank,  1);
                SET_TINYINT(questHistoIdXdAttribStp,  A_XdAttrib_SortRank,       1);
                SET_ENUM(questHistoIdXdAttribStp,     A_XdAttrib_SortRuleEn,     SortRule_Ascending);
                SET_MASK(questHistoIdXdAttribStp,     A_XdAttrib_QuickSearchMask,1);
                SET_MASK(questHistoIdXdAttribStp,     A_XdAttrib_SearchMask,     1);
                ret = DBA_Update2(XdAttrib, UNUSED, A_XdAttrib, questHistoIdXdAttribStp, UNUSED, NULL, NULL);
            }
        }
        else
        {
            DBA_CreateQuestHistoIdXdAttrib(xdEntityStp, &questHistoIdXdAttribStp, TRUE, dbiConnHelper);
            mp.ownerDynStp(questHistoIdXdAttribStp);
        }
    }

    if (ret == RET_GEN_ERR_NOACTION)
    {
        return(RET_SUCCEED);
    }

    return(ret);
}

/************************************************************************
**  Function    :   DBA_GetQuestByCd
**
**  Description :   Get a questionnaire entity.
**
**  Arguments   :   shXdEntity     xd Entity to complete
**
**  Return      :   RET_SUCCEED if success, or error code
**
**  Creation	:   PMSTA-53722 - LJE - 230713
**
*************************************************************************/
RET_CODE DBA_GetQuestByCd(const std::string& entitySqlnameStr, DdlGenContext& ddlGenContext, DBA_DYNFLD_STP &aQuestDefStp, MemoryPool &mp)
{
    RET_CODE             ret = RET_SUCCEED;

    std::string questDefCode(entitySqlnameStr.substr(3));
    std::string strRevision;

    for (auto it = entitySqlnameStr.end(); it != entitySqlnameStr.begin();)
    {
        --it;
        if (isdigit((*it)))
        {
            strRevision = (*it) + strRevision;
        }
        else
        {
            if ((*it) != '_')
            {
                strRevision.clear();
            }
            break;
        }
    }

    DdlGenConnGuard     ddlGenConnGuard(ddlGenContext);
    DbiConnectionHelper dbiConnHelper(&ddlGenConnGuard.getDbiConn());

    aQuestDefStp = mp.allocDynst(FILEINFO, A_QuestDef);

    if (strRevision.empty() == false)
    {
        int rev_n = atoi(strRevision.c_str());
        SET_INT(aQuestDefStp, A_QuestDef_Revision, rev_n);

        questDefCode.erase(questDefCode.length() - strRevision.length() - 1);
    }
    SET_SYSNAME(aQuestDefStp, A_QuestDef_Cd, questDefCode.c_str());

    ret = dbiConnHelper.dbaGet(QuestDef, UNUSED, aQuestDefStp, &aQuestDefStp);
    if (ret != RET_SUCCEED && strRevision.empty() == false)
    {
        SET_SYSNAME(aQuestDefStp, A_QuestDef_Cd, entitySqlnameStr.substr(3).c_str());
        SET_NULL_INT(aQuestDefStp, A_QuestDef_Revision);
        ret = dbiConnHelper.dbaGet(QuestDef, UNUSED, aQuestDefStp, &aQuestDefStp);
    }
    return(ret);
}


/************************************************************************
**  Function    :   DBA_CreateXdModelForQuestByCd
**
**  Description :   Create xd model for questionnaire entity.
**
**  Arguments   :   shXdEntity     xd Entity to complete
**
**  Return      :   RET_SUCCEED if success, or error code
**
**  Creation	:   PMSTA-19243 - DDV - 150317
**
*************************************************************************/
RET_CODE DBA_CreateXdModelForQuestByCd(const std::string &entitySqlnameStr, DdlGenContext &ddlGenContext)
{
    MemoryPool      mp;
    DBA_DYNFLD_STP  aQuestDefStp = nullptr;

    RET_CODE        ret = DBA_GetQuestByCd(entitySqlnameStr, ddlGenContext, aQuestDefStp, mp);

    if(ret == RET_SUCCEED)
    {
        DdlGenConnGuard     ddlGenConnGuard(ddlGenContext);
        DbiConnectionHelper dbiConnHelper(&ddlGenConnGuard.getDbiConn());

        ret = DBA_CreateXdModelForQuest(aQuestDefStp, dbiConnHelper, ddlGenContext);
    }
    else
    {
        ret = RET_DBA_ERR_INVDATA;
    }
    return(ret);
}

/************************************************************************
**  Function    :   DBA_CreateXdModelForQuestByCd
**
**  Description :   Create xd model for questionnaire entity.
**
**  Arguments   :   shXdEntity     xd Entity to complete
**
**  Return      :   RET_SUCCEED if success, or error code
**
**  Creation	:   PMSTA-19243 - DDV - 150317
**
*************************************************************************/
RET_CODE DBA_CreateAllXdModelForQuest(DdlGenContext &ddlGenContext)
{
    DBA_DYNFLD_STP       *aQuestDefTab = nullptr;
    int                   i = 0, questNbr = 0;
    RET_CODE              ret=RET_SUCCEED;

    DdlGenConnGuard     ddlGenConnGuard(ddlGenContext);
    DbiConnectionHelper dbiConnHelper(&ddlGenConnGuard.getDbiConn());

    if (dbiConnHelper.dbaSelect(QuestDef, UNUSED, nullptr, A_QuestDef, &aQuestDefTab, &questNbr) == RET_SUCCEED)
    {
        for (i = 0; i < questNbr; i++)
        {
            DBA_CreateXdModelForQuest(aQuestDefTab[i], dbiConnHelper, ddlGenContext);
        }
    }
    DBA_FreeDynStTab(aQuestDefTab, questNbr, A_QuestDef);
    return(ret);
}



/************************************************************************
**
**  Function      : DBA_CheckReferenceFormatElement
**
**  Description   : Check that sqlname and rank are unique in reference format element
**                  and return if requested the number and table of reference format element
**                  base of the generation of format element list.
**
**  Arguments     : ID_T                    idFormat            : identifier of the format
**                  DBA_DYNFLD_STP**        pdbadyntabRefFmtElt : number of reference format element
**                  int*                    piNbRefFmtElt       : table of short reference format element
**                  FLAG_T*                 pflagRankError      : indicate if 2 ranks are identical
**                  FLAG_T*                 pflagSqlNameError   : indicate if 2 sqlnames are identical
**                  DBA_DYNFLD_STP          pdbadynNewRefFmtElt : New all reference format element if provided then only checks lable but on the complete list.
**                  DBA_ERRMSG_INFOS_STP    msgStructPtr        : Message structure
**
**  Return        : RET_SUCCEED or error code
**
**  Creation      : HFI-PMSTA-38117-200127
**
************************************************************************/
RET_CODE DBA_CheckReferenceFormatElement(ID_T                    idFormat,
                                         DBA_DYNFLD_STP          **pdbadyntabRefFmtElt,
                                         int                     *piNbRefFmtElt,
                                         FLAG_T                  *pflagRankError,
                                         FLAG_T                  *pflagSqlNameError,
                                         DBA_DYNFLD_STP          pdbadynNewRefFmtElt,
                                         DBA_ERRMSG_INFOS_STP    msgStructPtr)
{
    RET_CODE        retCode = RET_SUCCEED;
    DBA_DYNFLD_STP  pdbadynAdmArg,
                    *pdbadynRefFmtElt = nullptr;
    int             iNbRefFmtElt = 0;

    if ((pdbadynAdmArg = ALLOC_DYNST(Adm_Arg)) == nullptr)
        retCode = RET_MEM_ERR_ALLOC;
    else
    {
        /*  Prepare input select parameter                          */
        SET_ID(pdbadynAdmArg, Adm_Arg_Id, idFormat);            /*  Given format                */
        SET_FLAG(pdbadynAdmArg, Adm_Arg_Flag, TRUE);            /*  include the given format    */

        /*  Select format elements and reference format elements    */
        if (((retCode = DBA_Select2(ReferenceFormatElement,
                                    DBA_ROLE_SELECT_REFERENCE_FORMAT,
                                    Adm_Arg,
                                    pdbadynAdmArg,
                                    S_ReferenceFormatElement,
                                    &pdbadynRefFmtElt,
                                    UNUSED,
                                    UNUSED,
                                    &iNbRefFmtElt,
                                    NULL,
                                    NULL)) == RET_SUCCEED) &&
            (iNbRefFmtElt > 0) &&
            (pdbadynRefFmtElt != nullptr))
        {
            FLAG_T  flagRankError = FALSE;
            FLAG_T  flagSqlNameError = FALSE;

            /*  In case of generation, remove some reference format element from the list   */
            /*  The list is supposed to be ordered from the child to the parent formats.    */
            /*  Deleted and Modified: remove all the records with the same sqlname          */
            /*  Deleted: also delete the current record                                     */
            if (pdbadynNewRefFmtElt == NULL)
            {
                for (int i = 0; i < iNbRefFmtElt; i++)
                {
                    if (pdbadynRefFmtElt[i] != nullptr)
                    {
                        ReferenceFormatElementReferenceNatEn    enRefNature = static_cast<ReferenceFormatElementReferenceNatEn>(GET_ENUM(pdbadynRefFmtElt[i], S_ReferenceFormatElement_ReferenceNatEn));
                        switch (enRefNature)
                        {
                            case ReferenceFormatElementReferenceNatEn::Deleted:
                            case ReferenceFormatElementReferenceNatEn::Modified:
                                for (int s = i + 1; s < iNbRefFmtElt; s++)
                                {
                                    if ((pdbadynRefFmtElt[s] != nullptr) &&
                                        (DBA_CmpDynFld( pdbadynRefFmtElt[s],
                                                        pdbadynRefFmtElt[i],
                                                        S_ReferenceFormatElement_SqlName,
                                                        S_ReferenceFormatElement_SqlName,
                                                        SysnameType,
                                                        TRUE) == 0))
                                    {
                                        FREE_DYNST(pdbadynRefFmtElt[s], S_ReferenceFormatElement);
                                        pdbadynRefFmtElt[s] = nullptr;
                                    }
                                }
                                if (ReferenceFormatElementReferenceNatEn::Deleted == enRefNature)
                                {
                                    FREE_DYNST(pdbadynRefFmtElt[i], S_ReferenceFormatElement);
                                    pdbadynRefFmtElt[i] = nullptr;
                                }
                                break;
                        }
                    }
                }

                /*  Check sqlname and rank unicity                      */
                for (int i = 0; i < iNbRefFmtElt; i++)
                {
                    if (pdbadynRefFmtElt[i] != nullptr)
                    {
                        for (int s = i + 1; s < iNbRefFmtElt; s++)
                        {
                            if (DBA_CmpDynFld ( pdbadynRefFmtElt[i],
                                                pdbadynRefFmtElt[s],
                                                S_ReferenceFormatElement_SqlName,
                                                S_ReferenceFormatElement_SqlName,
                                                SysnameType,
                                                TRUE) == 0)
                            {
                                if (msgStructPtr != NULL)
                                {
                                    retCode = RET_DBA_ERR_USED_SQLNAME;
                                    char *psz = MSG_BuildMesg ( UNUSED, "ERR_UsedSqlname", UNUSED,
                                                                SysnameType, GET_SYSNAME(pdbadynRefFmtElt[i],S_ReferenceFormatElement_SqlName),
                                                                CodeType, GET_CODE(pdbadynRefFmtElt[i],S_ReferenceFormatElement_OriginFmtCd));
                                    MSG_FillMsgStruct ( msgStructPtr,
                                                        RET_DBA_ERR_USED_SQLNAME,
                                                        psz,
                                                        NullHandler,
                                                        RET_LEV_BUSINESS_ERROR,
                                                        FALSE,
                                                        NULL,
                                                        NULL,
                                                        0);
                                     FREE(psz);
                                }
                                flagSqlNameError = TRUE;
                            }
                            if (DBA_CmpDynFld ( pdbadynRefFmtElt[i],
                                                pdbadynRefFmtElt[s],
                                                S_ReferenceFormatElement_Rank,
                                                S_ReferenceFormatElement_Rank,
                                                SmallintType,
                                                TRUE) == 0)
                            {
                                flagRankError = TRUE;
                            }
                        }
                    }
                }
            }
            else
            {
                /*  Check if the new sqlName already exists         */
                for (int i = 0; i < iNbRefFmtElt; i++)
                {
                    if (pdbadynRefFmtElt[i] != nullptr)
                    {
                        if ((DBA_CmpDynFld( pdbadynRefFmtElt[i],
                                            pdbadynNewRefFmtElt,
                                            S_ReferenceFormatElement_FmtId,
                                            A_ReferenceFormatElement_FmtId,
                                            IdType,
                                            TRUE) != 0) &&
                            (DBA_CmpDynFld( pdbadynRefFmtElt[i],
                                            pdbadynNewRefFmtElt,
                                            S_ReferenceFormatElement_SqlName,
                                            A_ReferenceFormatElement_SqlName,
                                            SysnameType,
                                            TRUE) == 0))
                        {
                            if (msgStructPtr != NULL)
                            {
                                retCode = RET_DBA_ERR_USED_SQLNAME;
                                char *psz = MSG_BuildMesg ( UNUSED, "ERR_UsedSqlname", UNUSED,
                                                            SysnameType, GET_SYSNAME(pdbadynRefFmtElt[i],S_ReferenceFormatElement_SqlName),
                                                            CodeType, GET_CODE(pdbadynRefFmtElt[i],S_ReferenceFormatElement_OriginFmtCd));
                                MSG_FillMsgStruct ( msgStructPtr,
                                                    RET_DBA_ERR_USED_SQLNAME,
                                                    psz,
                                                    NullHandler,
                                                    RET_LEV_BUSINESS_ERROR,
                                                    FALSE,
                                                    NULL,
                                                    NULL,
                                                    0);
                                FREE(psz);
                            }
                            flagSqlNameError = TRUE;
                        }
                    }
                }
            }

            /*  Free allocated memory                               */
            if ((pdbadyntabRefFmtElt == nullptr) ||
                /*  No generation in case of duplicated sqlname     */
                (flagSqlNameError == TRUE))
            {
                for (int i = 0; i < iNbRefFmtElt; i++)
                {
                    if (pdbadynRefFmtElt[i] != nullptr)
                    {
                        FREE_DYNST(pdbadynRefFmtElt[i], S_ReferenceFormatElement);
                    }
                }
                FREE(pdbadynRefFmtElt);
            }
            /*  Return value if requested                           */
            else
            {
                *pdbadyntabRefFmtElt = pdbadynRefFmtElt;
            }
            if (piNbRefFmtElt != nullptr)
                *piNbRefFmtElt = iNbRefFmtElt;
            if (pflagRankError != nullptr)
                *pflagRankError = flagRankError;
            if (pflagSqlNameError != nullptr)
                *pflagSqlNameError = flagSqlNameError;
        }
        FREE_DYNST(pdbadynAdmArg, Adm_Arg);
    }
    return retCode;
}


/************************************************************************
**
**  Function      : DBA_GenerateFormatElementFromReferenceFormatElement
**
**  Description   : Generate a list of format element based on a given table of reference format element
**
**  Arguments     : ID_T            idFormat                : identifier of the format
**                  DBA_DYNFLD_STP  pdbadynShortRefFmtElt   : table of short reference format element base of the generation
**                  DBA_DYNFLD_STP* pdbadynptrAllFmtElt     : table of all format element base to be inserted
**
**  Return        : RET_SUCCEED or error code
**
**  Creation      : HFI-PMSTA-38117-200109
**
************************************************************************/
STATIC RET_CODE DBA_GenerateFormatElementFromReferenceFormatElement(DBA_DYNFLD_STP pdbadynShortRefFmtElt,
                                                                    DBA_DYNFLD_STP *pdbadynptrAllFmtElt,
                                                                    ID_T            idFormat)
{
    DBA_DYNFLD_STP      pdbadynAllFmtElt = nullptr;
    RET_CODE            retCode = RET_SUCCEED;
    MemoryPool          mp;

    if ((pdbadynShortRefFmtElt != nullptr) &&
        (pdbadynptrAllFmtElt != nullptr))
    {
        /*  Allocate returned all format element                                */
        if ((pdbadynAllFmtElt = ALLOC_DYNST(A_FmtElt)) == NULL)
            MSG_RETURN(RET_MEM_ERR_ALLOC);

        /*  Create format element from a reference format_element               */
        if ((IS_NULLFLD(pdbadynShortRefFmtElt, S_ReferenceFormatElement_ReferenceNatEn) == FALSE) &&
            (ReferenceFormatElementReferenceNatEn::Original != static_cast<ReferenceFormatElementReferenceNatEn>(GET_ENUM(pdbadynShortRefFmtElt, S_ReferenceFormatElement_ReferenceNatEn))))
        {
            DBA_DYNFLD_STP  pdbadynAllRefFmtElt = ALLOC_DYNST(A_ReferenceFormatElement);
            if (pdbadynAllRefFmtElt == NULL)
                MSG_RETURN(RET_MEM_ERR_ALLOC);

            retCode = DBA_Get2(ReferenceFormatElement,
                               UNUSED,
                               S_ReferenceFormatElement,
                               pdbadynShortRefFmtElt,
                               A_ReferenceFormatElement,
                               &pdbadynAllRefFmtElt,
                               UNUSED,
                               NULL,
                               NULL);
            if (retCode == RET_SUCCEED)
            {
                CONVERT_DYNST (pdbadynAllFmtElt, A_FmtElt, pdbadynAllRefFmtElt, A_ReferenceFormatElement);
            }
            FREE_DYNST(pdbadynAllRefFmtElt, A_ReferenceFormatElement);
        }
        /*  Create reference format element from a reference format element */
        else
        {
            DBA_DYNFLD_STP  pdbadynShortFmtElt = mp.allocDynst(FILEINFO, S_FmtElt);
            if (pdbadynShortFmtElt == nullptr)
            {
                MSG_RETURN(RET_MEM_ERR_ALLOC);
            }

            SET_ID(pdbadynShortFmtElt, S_FmtElt_Id, GET_ID(pdbadynShortRefFmtElt, S_ReferenceFormatElement_Id));
            retCode = DBA_Get2(FmtElt,
                               UNUSED,
                               S_FmtElt,
                               pdbadynShortFmtElt,
                               A_FmtElt,
                               &pdbadynAllFmtElt,
                               UNUSED,
                               NULL,
                               NULL);
        }

        if ((retCode == RET_SUCCEED) &&
            (IS_NULLFLD(pdbadynAllFmtElt, A_FmtElt_Id) == FALSE))
        {
            SET_SMALLINT(pdbadynAllFmtElt, A_FmtElt_Rank, GET_SMALLINT(pdbadynShortRefFmtElt, S_ReferenceFormatElement_Rank));
            SET_NULL_ID(pdbadynAllFmtElt, A_FmtElt_Id);
            SET_ID(pdbadynAllFmtElt, A_FmtElt_FmtId, idFormat);
            *pdbadynptrAllFmtElt = pdbadynAllFmtElt;
        }
        else
        {
            FREE_DYNST(pdbadynAllFmtElt,A_FmtElt);
        }
    }
    return retCode;
}
/************************************************************************
**
**  Function    :   DBA_CmpShortRefFmtElt
**
**  Description :   Reference Format Element are sorted by rank then by level
**
**  Arguments   :   ptr1   pointer on dynamic structure Short Reference Format Element
**                  ptr2   pointer on dynamic structure Short Reference Format Element
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation      : HFI-PMSTA-38117-200229
**
*************************************************************************/
STATIC int DBA_CmpShortRefFmtElt (DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    int iRet = DBA_CmpDynFld(*ptr1,
                             *ptr2,
                             S_ReferenceFormatElement_Rank,
                             S_ReferenceFormatElement_Rank,
                             SmallintType,
                             FALSE);
    if (iRet == 0)
    {
        iRet = -DBA_CmpDynFld(*ptr1,
                              *ptr2,
                              S_ReferenceFormatElement_Level,
                              S_ReferenceFormatElement_Level,
                              IntType,
                              FALSE);
    }
    return iRet;
}

/************************************************************************
**
**  Function      : DBA_GenerateFormatElementOneFormat
**
**  Description   : Generate format element of the currently selected format
**
**  Arguments     : ID_T    idFormat : id of the format
**
**  Return        : RET_SUCCEED or error code
**
**  Creation      : HFI-PMSTA-38117-200109
**  Modif         : HFI-PMSTA-51611-2022-12-21  use of DbiConnectionHelper
**
************************************************************************/
STATIC RET_CODE DBA_GenerateFormatElementOneFormat (ID_T idFormat)
{
    RET_CODE            retCode = RET_SUCCEED;
    DBA_DYNFLD_STP      *pdbadynRefFmtElt = nullptr;
    DBA_DYNFLD_STP      *pdbadynNewFmtElt = nullptr;
    int                 iNbRefFmtElt = 0;
    FLAG_T              flagRankError = FALSE;
    FLAG_T              flagSqlNameError = FALSE;
    DBA_ERRMSG_INFOS_ST msgSt(FILEINFO);

    /********************************************************************/
    /*  PREPARE THE NEW FORMAT ELEMENT LIST                             */
    /********************************************************************/
    if ((DBA_CheckReferenceFormatElement (  idFormat,
                                            &pdbadynRefFmtElt,
                                            &iNbRefFmtElt,
                                            &flagRankError,
                                            &flagSqlNameError,
                                            NULL,
                                            &msgSt) == RET_SUCCEED) &&
        (flagSqlNameError == FALSE) &&
        (pdbadynRefFmtElt != NULL) &&
        (iNbRefFmtElt > 0))
    {
        /*  Manage Rank if necessary                            */
        if (flagRankError == TRUE)
        {
            /*  Sorting                                                 */
            TLS_Sort (  (char*) pdbadynRefFmtElt,
                        iNbRefFmtElt,
                        sizeof(DBA_DYNFLD_STP),
                        (TLS_CMPFCT*) DBA_CmpShortRefFmtElt,
                        NULL,
                        SortRtnTp_None);

            /*  Adapt Rank value to the sorting result              */
            for (SMALLINT_T i = 0; i < iNbRefFmtElt; i++)
            {
                if (pdbadynRefFmtElt[i] != nullptr)
                {
                    SET_SMALLINT(pdbadynRefFmtElt[i], S_ReferenceFormatElement_Rank, i + 1);
                }
            }
        }

        /*  Create New Format Element Table                     */
        pdbadynNewFmtElt = (DBA_DYNFLD_STP*) CALLOC(iNbRefFmtElt, sizeof(DBA_DYNFLD_STP));
        if (pdbadynNewFmtElt == nullptr)
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        for (int i = 0; i < iNbRefFmtElt; i++)
        {
            if (pdbadynRefFmtElt[i] != nullptr)
            {
                DBA_GenerateFormatElementFromReferenceFormatElement (pdbadynRefFmtElt[i],
                                                                     &pdbadynNewFmtElt[i],
                                                                     idFormat);
            }
        }

    /********************************************************************/
    /*  SAVE THE NEW FORMAT ELEMENT LIST                                */
    /*  1. delete the existing format element                           */
    /*  2. insert the format element                                    */
    /*  3. copy the format element logical attributes                   */
    /*  4. update format reference status                               */
    /********************************************************************/
        /*  manage connection and transaction                   */
        DbiConnectionHelper dbiConnHelper;
        if ((dbiConnHelper.isValidAndInit()) &&
            (dbiConnHelper.beginTransaction() == RET_SUCCEED))
        {
            dbiConnHelper.dbaSetOptions(DBA_SET_CONN | DBA_NO_CLOSE | DBA_NO_MAIN_LEVEL);

            /*  Delete Existing Format Element                      */
            if (retCode == RET_SUCCEED)
            {
                DBA_DYNFLD_STP  pdbadynShortFmt = ALLOC_DYNST(S_Fmt);
                if (pdbadynShortFmt == nullptr)
                {
                        retCode = RET_MEM_ERR_ALLOC;
                }
                    else
                    {
                        SET_ID(pdbadynShortFmt, S_Fmt_Id, idFormat);
                        retCode = DBA_Delete2 ( FmtElt,
                                                UNUSED,
                                                S_Fmt,
                                                pdbadynShortFmt,
                                            dbiConnHelper);
                        FREE_DYNST(pdbadynShortFmt, S_Fmt);
                    }
                }

                /*  Insert New Format Element and copy logicals         */
                for (int i = 0; i < iNbRefFmtElt && retCode == RET_SUCCEED; i++)
                {
                    if (pdbadynNewFmtElt[i] != nullptr)
                    {
                        /*  Insert New Format Element                   */
                        retCode = DBA_Insert2 ( FmtElt,
                                                UNUSED,
                                                A_FmtElt,
                                                pdbadynNewFmtElt[i],
                                            dbiConnHelper);

                        /*  Copy logicals                               */
                        if (retCode == RET_SUCCEED)
                        {
                            if ((IS_NULLFLD(pdbadynRefFmtElt[i], S_ReferenceFormatElement_ReferenceNatEn) == FALSE) &&
                                (ReferenceFormatElementReferenceNatEn::Original != static_cast<ReferenceFormatElementReferenceNatEn>(GET_ENUM(pdbadynRefFmtElt[i], S_ReferenceFormatElement_ReferenceNatEn))))
                            {
                                /*  From reference format element           */
                                retCode = DBA_CopyAutomatic(ReferenceFormatElement,
                                                            FmtElt,
                                                            GET_ID(pdbadynRefFmtElt[i], S_ReferenceFormatElement_Id),
                                                            GET_ID(pdbadynNewFmtElt[i], S_FmtElt_Id),
                                                        nullptr,
                                                        dbiConnHelper);
                            }
                            else
                            {
                                /*  From format element                     */
                                retCode = DBA_CopyAutomatic(FmtElt,
                                                            FmtElt,
                                                            GET_ID(pdbadynRefFmtElt[i], S_FmtElt_Id),
                                                            GET_ID(pdbadynNewFmtElt[i], S_FmtElt_Id),
                                                        nullptr,
                                                        dbiConnHelper);
                            }
                        }
                    }
                }

                /*  Update reference format status                      */
                if (retCode == RET_SUCCEED)
                {
                    DBA_DYNFLD_STP  pdbadynAllFmt = ALLOC_DYNST(A_Fmt);
                    if (pdbadynAllFmt == nullptr)
                        retCode = RET_MEM_ERR_ALLOC;
                    else
                    {
                        SET_ID(pdbadynAllFmt, A_Fmt_Id, idFormat);
                        SET_ENUM(pdbadynAllFmt, A_Fmt_ReferenceStatusEn, FmtReferenceStatusEn::UpToDate);
                        retCode = DBA_Update2 ( Fmt,
                                                DBA_ROLE_REFERENCE_STATUS,
                                                A_Fmt,
                                                pdbadynAllFmt,
                                            dbiConnHelper);
                        FREE_DYNST(pdbadynAllFmt, A_Fmt);
                    }
                }

            /*  End transaction: commit or rollback                 */
            dbiConnHelper.endTransaction(retCode == RET_SUCCEED ? TRUE : FALSE);
        }

        /*  Free allocated memory                               */
        for (int i = 0; i < iNbRefFmtElt; i++)
        {
            if (pdbadynRefFmtElt[i] != nullptr)
            {
                FREE_DYNST(pdbadynRefFmtElt[i], S_ReferenceFormatElement);
            }
            if (pdbadynNewFmtElt[i] != nullptr)
            {
                FREE_DYNST(pdbadynNewFmtElt[i], A_FmtElt);
            }
        }
        FREE(pdbadynRefFmtElt);
        FREE(pdbadynNewFmtElt);

        if ((retCode == RET_MEM_ERR_ALLOC) ||
            (retCode == RET_DBA_ERR_CONNOTFOUND))
        {
            MSG_RETURN(retCode);
        }
    }
    return retCode;
}


/************************************************************************
**
**  Function      : DBA_GenerateFormatElement
**
**  Description   : Manage the generation of format element of the currently selected format
**
**  Arguments     : GenerateFmteltScopeEn   enGenerateScope     : All, one, Child or Profile
**                : ID_T                    idFormat            : id of the format
**                : ID_T                    idUser              : id of the user (only for profile scope)
**                : ID_T                    idFmtProf           : id of a format profile
**                : DICT_T                  dictFunction        : dict of a function (only for profile scope)
**                : FLAG_T                  flagForceGenerate   : TRUE implies the value of reference_status_e is not considered
**
**  Return        : RET_SUCCEED
**                  RET_GEN_INFO_FMTELT_GEN_DONE    This may imply a reselection of format and format_element
**                  or error code
**
**  Creation      : HFI-PMSTA-38117-200302
**  Modification  : HFI-PMSTA-47343-211208  Add flagForceGenerate: possibility to force the generation
**
************************************************************************/
RET_CODE DBA_GenerateFormatElement( GenerateFmteltScopeEn           enGenerateScope,
                                    ID_T                            idFormat,
                                    ID_T                            idUser,
                                    ID_T                            idFmtProf,
                                    DICT_T                          dictFunction,
                                    FLAG_T                          flagForceGenerate,
                                    GenerateFmteltCheckApplParamEn  enCheckApplParam,
                                    std::set<std::string>          *childrenFmtSet)
{
    RET_CODE                        retCode = RET_SUCCEED;
    GenerateFmteltApplParamMethodEn enFmtEltDynGenMethod = GenerateFmteltApplParamMethodEn::FullGeneration;
    DBA_DYNFLD_STP                  *pdbadynFormat = nullptr;
    int                             iNbFormat = 0;

    /*  Is dynamic generation managed                                   */
    if (GenerateFmteltCheckApplParamEn::Yes == enCheckApplParam)
    {
        GEN_GetApplInfo(ApplFmtEltDynGenMethod, &enFmtEltDynGenMethod);
    }
    /*  Nothing to do if dynamic generation is not supported            */
    if (GenerateFmteltApplParamMethodEn::NotManaged != enFmtEltDynGenMethod)
    {
        switch (enGenerateScope)
        {
            case GenerateFmteltScopeEn::AllFormats:
                {
                    DBA_DYNFLD_STP  pdbadynAdmArg = ALLOC_DYNST(Adm_Arg);
                    if (pdbadynAdmArg == NULL)
                        MSG_RETURN(RET_MEM_ERR_ALLOC);
                    SET_ENUM(pdbadynAdmArg, Adm_Arg_NatEn, FmtNat_All);
                    retCode = DBA_Select2 ( Fmt,
                                            UNUSED,
                                            Adm_Arg,
                                            pdbadynAdmArg,
                                            S_Fmt,
                                            &pdbadynFormat,
                                            UNUSED,
                                            UNUSED,
                                            &iNbFormat,
                                            NULL,
                                            NULL);
                    FREE_DYNST(pdbadynAdmArg, Adm_Arg);
                }
                break;

            case GenerateFmteltScopeEn::ChildFormats:
                if (idFormat > 0)
                {
                    DBA_DYNFLD_STP  pdbadynAdmArg = ALLOC_DYNST(Adm_Arg);
                    if (pdbadynAdmArg == NULL)
                        MSG_RETURN(RET_MEM_ERR_ALLOC);
                    SET_ID(pdbadynAdmArg, Adm_Arg_Id, idFormat);                   /*  Given format profile                 */
                    SET_FLAG(pdbadynAdmArg, Adm_Arg_Flag, TRUE);                   /*  Include given format in selection    */
                    retCode = DBA_Select2 ( Fmt,
                                            DBA_ROLE_CHILD_REFERENCE,
                                            Adm_Arg,
                                            pdbadynAdmArg,
                                            S_Fmt,
                                            &pdbadynFormat,
                                            UNUSED,
                                            UNUSED,
                                            &iNbFormat,
                                            NULL,
                                            NULL);
                    FREE_DYNST(pdbadynAdmArg, Adm_Arg);
                }
                break;

            case GenerateFmteltScopeEn::OneFormat:
                if ((idFormat > 0) &&
                    (retCode == RET_SUCCEED))
                {
                    DBA_DYNFLD_STP  pdbadynAdmArg = ALLOC_DYNST(Adm_Arg);
                    DBA_DYNFLD_STP  pdbadynShortFmt = ALLOC_DYNST(S_Fmt);
                    if ((pdbadynAdmArg == nullptr) ||
                        (pdbadynShortFmt == nullptr))
                        MSG_RETURN(RET_MEM_ERR_ALLOC);

                    SET_ID(pdbadynAdmArg, Adm_Arg_Id, idFormat);
                    retCode = DBA_Get2( Fmt,
                                        UNUSED,
                                        Adm_Arg,
                                        pdbadynAdmArg,
                                        S_Fmt,
                                        &pdbadynShortFmt,
                                        UNUSED,
                                        NULL,
                                        NULL);
                    FREE_DYNST(pdbadynAdmArg, Adm_Arg);

                    if (retCode == RET_SUCCEED)
                    {
                        pdbadynFormat = (DBA_DYNFLD_STP*) CALLOC(1, sizeof(DBA_DYNFLD_STP));
                        if (pdbadynFormat == nullptr)
                            MSG_RETURN(RET_MEM_ERR_ALLOC);
                        pdbadynFormat[iNbFormat] = pdbadynShortFmt;
                        iNbFormat++;
                    }
                }
                break;

            case GenerateFmteltScopeEn::FormatProfile:
                /*  Get format profile if not provided          */
                if ((idFmtProf == UNUSED) &&
                    (idUser > 0))
                {
                    DBA_DYNFLD_STP pdbadynAllUser = ALLOC_DYNST(A_ApplUser);
                    DBA_DYNFLD_STP pdbadynShortUser = ALLOC_DYNST(S_ApplUser);
                    if ((pdbadynAllUser == nullptr) ||
                        (pdbadynShortUser == nullptr))
                        MSG_RETURN(RET_MEM_ERR_ALLOC);

                    SET_ID(pdbadynShortUser, S_ApplUser_Id, idUser);
                    if (DBA_Get2(ApplUser, UNUSED, S_ApplUser, pdbadynShortUser, A_ApplUser, &pdbadynAllUser, UNUSED, UNUSED, UNUSED) == RET_SUCCEED)
                    {
                        idFmtProf = GET_ID(pdbadynAllUser, A_ApplUser_FmtProfileId);
                    }
                    FREE_DYNST(pdbadynShortUser, S_ApplUser);
                    FREE_DYNST(pdbadynAllUser, A_ApplUser);
                }

                if (idFmtProf > 0)
                {
                    /*  Get format profile formats                  */
                    DBA_DYNFLD_STP  pdbadynAdmArg = ALLOC_DYNST(Adm_Arg);
                    if (pdbadynAdmArg == NULL)
                        MSG_RETURN(RET_MEM_ERR_ALLOC);
                    SET_ID(pdbadynAdmArg, Adm_Arg_Id, idFmtProf);                   /*  Given format profile        */
                    if (dictFunction > 0)
                        SET_DICT(pdbadynAdmArg, Adm_Arg_FctDictId, dictFunction);   /*  Given Function              */

                    /*  Select format by format profile and function            */
                    retCode = DBA_Select2 ( Fmt,
                                            UNUSED,
                                            Adm_Arg,
                                            pdbadynAdmArg,
                                            S_Fmt,
                                            &pdbadynFormat,
                                            UNUSED,
                                            UNUSED,
                                            &iNbFormat,
                                            NULL,
                                            NULL);
                    FREE_DYNST(pdbadynAdmArg, Adm_Arg);
                }
                break;
        }

        /*  Generate format element if necessary                            */
        if ((retCode == RET_SUCCEED) &&
            (pdbadynFormat != nullptr) &&
            (iNbFormat > 0))
        {
            FLAG_T  flagFmtEltGenDone = FALSE;
            for (int i = 0; i < iNbFormat; i++)
            {
                /* PMSTA-43367 - LJE - 210421 */
                if (childrenFmtSet != nullptr &&
                    IS_NULLFLD(pdbadynFormat[i], S_Fmt_Cd) == FALSE)
                {
                    childrenFmtSet->insert(GET_CODE(pdbadynFormat[i], S_Fmt_Cd));
                }

                if ((IS_NULLFLD(pdbadynFormat[i], S_Fmt_ReferenceFmtId) == FALSE) &&
                    (IS_NULLFLD(pdbadynFormat[i], S_Fmt_Id) == FALSE) &&
                    ((TRUE == flagForceGenerate) ||
                     (FmtReferenceStatusEn::ToBeGenerated == static_cast<FmtReferenceStatusEn> GET_ENUM(pdbadynFormat[i], S_Fmt_ReferenceStatusEn))))
                {
                    char            *pszMsg;
                    FLAG_T          flagError = FALSE;

                    /*  Format element is fully generated                           */
                    if (GenerateFmteltApplParamMethodEn::FullGeneration == enFmtEltDynGenMethod)
                    {
                        /*  Generate Formt Element List                             */
                        retCode = DBA_GenerateFormatElementOneFormat(GET_ID(pdbadynFormat[i], S_Fmt_Id));
                        /*  Manage Return                                           */
                        if (retCode == RET_SUCCEED)
                        {
                            flagFmtEltGenDone = TRUE;
                            pszMsg = "INFO_FMTELT_GEN_DONE";
                        }
                        else
                        {
                            flagError = FALSE;
                            pszMsg = "INFO_FMTELT_GEN_FAIL";
                        }
                    }
                    else
                    {
                        pszMsg = "INFO_FMTELT_GEN_NEED";
                    }

                    if (SYS_IsDdlGenMode() == FALSE)    /* PMSTA-43367 - LJE - 210421 */
                    {
                        /*  Generate message                                            */
                        char *psz = MSG_BuildMesg(UNUSED, pszMsg, UNUSED, CodeType, GET_CODE(pdbadynFormat[i], S_Fmt_Cd));

                        /*  Add the message in log                                      */
                        if (flagError == TRUE)
                        {
                            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, psz);
                        }
                        /*  Add the message in server log                               */
                        if (SYS_IsGuiMode() == FALSE)
                        {
                            MSG_LogSrvMesg(UNUSED, UNUSED, psz);
                        }
                        /*  Free allocated memory for message                           */
                        FREE(psz);
                    }
                }
                FREE_DYNST(pdbadynFormat[i], S_Fmt);
            }
            FREE(pdbadynFormat);

            if (flagFmtEltGenDone == TRUE)
            {
                retCode = RET_GEN_INFO_FMTELT_GEN_DONE;
            }
        }
    }
    return retCode;
}


/************************************************************************
**
**  Function      : DBA_GenerateReferenceFormatElement
**
**  Description   : Check that generation of reference format element is possible
**                  The generation could be done only if:
**                      - the selected format reference status is not Up To Date
**                      - the selected format has no reference format element
**                      - the reference format reference status is not To Be Generated
**
**  Arguments     : ID_T        idSelFormat : id of the selected format
**                  ID_T        idRefFormat : id of the reference format
**                  pszMsg**    pszMsg      : Error message
**
**  Return        : RET_SUCCEED         : no problem the generation can take place
**                  RET_GEN_ERR_INVARG  : the generation cannot take place
**                  or error code       : usually DB issue
**
**  Creation     :   HFI-PMSTA-38206-201128
**
************************************************************************/
RET_CODE DBA_CheckGenerateReferenceFormatElement( ID_T idSelFormat, ID_T idRefFormat, char **pszMsg)
{
    RET_CODE        retCode = RET_SUCCEED;
    DBA_DYNFLD_STP  pdbadynAdmArg = nullptr,
                    pdbadynShortFmt = nullptr;
    char            *psz = nullptr;

    /*  Check input parameter                                       */
    if (pszMsg == nullptr)
    {
        return(RET_GEN_ERR_INVARG);
    }

    /*  Allocate DB get input and output parameters                 */
    if (((pdbadynAdmArg = ALLOC_DYNST(Adm_Arg)) == nullptr) ||
        ((pdbadynShortFmt = ALLOC_DYNST(S_Fmt)) == nullptr))
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }
    /*  Get the selected format                                     */
    SET_ID(pdbadynAdmArg, Adm_Arg_Id, idSelFormat);
    if ((retCode = DBA_Get2(Fmt,
                            UNUSED,
                            Adm_Arg,
                            pdbadynAdmArg,
                            S_Fmt,
                            &pdbadynShortFmt,
                            UNUSED,
                            NULL,
                            NULL)) == RET_SUCCEED)
    {
        /*  The reference status must not be Up To Date             */
        /*  No format element generation occurs                     */
        if ((IS_NULLFLD(pdbadynShortFmt, S_Fmt_ReferenceStatusEn) == TRUE) ||
            (FmtReferenceStatusEn::UpToDate == static_cast<FmtReferenceStatusEn> (GET_ENUM(pdbadynShortFmt, S_Fmt_ReferenceStatusEn))))
        {
            psz = MSG_BuildMesg(UNUSED,"INFO_FMTELT_GEN_DONE",UNUSED,CodeType,GET_CODE(pdbadynShortFmt, S_Fmt_Cd));
            retCode = RET_GEN_ERR_INVARG;
        }
        else
        {
            DBA_DYNFLD_STP  *pdbadyntabOriRefFmtElt = nullptr;
            int             iNbOriRefFmtElt = 0;

            /*  Check that there is no reference format element         */
            SET_ID(pdbadynAdmArg, Adm_Arg_Id, idSelFormat);
            SET_ENUM(pdbadynAdmArg, Adm_Arg_NatEn, ReferenceFormatElementReferenceNatEn::All);      /*  HFI-PMSTA-46654-211012  */
            if ((retCode = DBA_Select2( ReferenceFormatElement,
                                        UNUSED,
                                        Adm_Arg,
                                        pdbadynAdmArg,
                                        S_ReferenceFormatElement,
                                        &pdbadyntabOriRefFmtElt,
                                        UNUSED,
                                        UNUSED,
                                        &iNbOriRefFmtElt,
                                        NULL,
                                        NULL)) == RET_SUCCEED)
            {
                /*  There is no reference format element at the moment  */
                if ((iNbOriRefFmtElt == 0) &&
                    (pdbadyntabOriRefFmtElt == nullptr))
                {
                    /*  Get reference format                                */
                    SET_ID(pdbadynAdmArg, Adm_Arg_Id, idRefFormat);
                    if ((retCode = DBA_Get2(Fmt,
                                            UNUSED,
                                            Adm_Arg,
                                            pdbadynAdmArg,
                                            S_Fmt,
                                            &pdbadynShortFmt,
                                            UNUSED,
                                            NULL,
                                            NULL)) == RET_SUCCEED)
                    {
                        /*  The reference status of the reference format is None or "Up To Date"    */
                        if ((IS_NULLFLD(pdbadynShortFmt, S_Fmt_ReferenceStatusEn) == TRUE) ||
                            (FmtReferenceStatusEn::ToBeGenerated == static_cast<FmtReferenceStatusEn> (GET_ENUM(pdbadynShortFmt, S_Fmt_ReferenceStatusEn))))
                        {
                            psz = MSG_BuildMesg(UNUSED,"INFO_FMTELT_GEN_NEED",UNUSED,CodeType,GET_CODE(pdbadynShortFmt, S_Fmt_Cd));
                            retCode = RET_GEN_ERR_INVARG;
                        }
                    }
                }
                else
                {
                    psz = MSG_BuildMesg(UNUSED,"INFO_REFFMTELT_GEN_UNECESSARY",UNUSED,CodeType,GET_CODE(pdbadynShortFmt, S_Fmt_Cd));
                    retCode = RET_GEN_ERR_INVARG;
                }
                for (int i = 0; i < iNbOriRefFmtElt; i++)
                {
                    FREE_DYNST(pdbadyntabOriRefFmtElt[i], S_ReferenceFormatElement);
                }
                FREE(pdbadyntabOriRefFmtElt);
            }
        }
    }

    /*  Free allocation                                             */
    FREE_DYNST(pdbadynShortFmt, S_Fmt);
    FREE_DYNST(pdbadynAdmArg, Adm_Arg);

    /*  Provide info message to display                             */
    if (psz != nullptr)
    {
        *pszMsg = psz;
    }
    return retCode;    
}


/************************************************************************
**
**  Function      : DBA_GenerateReferenceFormatElement
**
**  Description   : Manage the generation of reference format element based on the currently existing format element
**
**  Arguments     : ID_T        idSelFormat        : id of the selected format
**                  ID_T        idRefFormat        : id of the reference format
**
**  Return        : RET_SUCCEED
**                  RET_GEN_INFO_FMTELT_GEN_DONE    This may imply a reselection of format and format_element
**                  or error code
**
**  Creation     :   HFI-PMSTA-38206-201128
**  Modif        :   HFI-PMSTA-51611-2022-12-21  use of DbiConnectionHelper
**
************************************************************************/
RET_CODE DBA_GenerateReferenceFormatElement( ID_T idSelFormat, ID_T idRefFormat)
{
    DBA_DYNFLD_STP      *pdbadyntabOriFmtElt = nullptr,
                        *pdbadyntabRefFmtElt = nullptr;
    int                 iNbOriFmtElt = 0,
                        iNbRefFmtElt = 0;
    RET_CODE            retCode = RET_SUCCEED;
    DBA_HIER_HEAD_STP   phierOri = nullptr,
                        phierRef = nullptr;

    if (((retCode = DBA_LoadFormats(0,idSelFormat,0,UNUSED,nullptr,(PTR*) &phierOri)) == RET_SUCCEED) &&
        ((retCode = DBA_LoadFormats(0,idRefFormat,0,UNUSED,nullptr,(PTR*) &phierRef)) == RET_SUCCEED) &&
        ((retCode = DBA_HierEltRecExtract ( phierOri,
                                            A_FmtElt,
                                            FALSE,
                                            nullptr,
                                            nullptr,
                                            NULL,
                                            FALSE,
                                            FALSE,
                                            &iNbOriFmtElt,
                                            &pdbadyntabOriFmtElt)) == RET_SUCCEED) &&
        ((retCode = DBA_HierEltRecExtract ( phierRef,
                                            A_FmtElt,
                                            FALSE,
                                            nullptr,
                                            nullptr,
                                            NULL,
                                            FALSE,
                                            FALSE,
                                            &iNbRefFmtElt,
                                            &pdbadyntabRefFmtElt)) == RET_SUCCEED))
    {
        /*  manage connection and transaction                   */
        DbiConnectionHelper dbiConnHelper;
        if ((dbiConnHelper.isValidAndInit()) &&
            (dbiConnHelper.beginTransaction() == RET_SUCCEED))
        {
            dbiConnHelper.dbaSetOptions(DBA_SET_CONN | DBA_NO_CLOSE | DBA_NO_MAIN_LEVEL);

            for (int i = 0; (i < iNbOriFmtElt) && (retCode == RET_SUCCEED); i++)

            {
                if ((IS_NULLFLD(pdbadyntabOriFmtElt[i], A_FmtElt_TslMultilingualEn) == TRUE) ||
                    (GET_ENUM(pdbadyntabOriFmtElt[i], A_FmtElt_TslMultilingualEn) != TslMultilingual_MultilingualChild))
                {
                    ReferenceFormatElementReferenceNatEn enRefFmtEltNat = ReferenceFormatElementReferenceNatEn::Original;
                    DBA_DYNFLD_STP  pdbadynFmtElt = nullptr;
                    ID_T            idOriginFormat = 0;

                    DBA_GetRecPtrFromHierByCd(phierRef, GET_SYSNAME(pdbadyntabOriFmtElt[i],A_FmtElt_SqlName), A_FmtElt, &pdbadynFmtElt, UNUSED);
                    /*  New format element in new format                */
                    if (pdbadynFmtElt == nullptr)
                    {
                        enRefFmtEltNat = ReferenceFormatElementReferenceNatEn::Added;
                        idOriginFormat = idSelFormat;
                    }
                    else
                    {
                        if ((DBA_CmpDynRelevantFields(pdbadyntabOriFmtElt[i], pdbadynFmtElt, FmtElt) != 0) ||
                            (CMP_DYNFLD(pdbadyntabOriFmtElt[i], pdbadynFmtElt, A_FmtElt_ScriptDef, A_FmtElt_ScriptDef, NoteType) != 0) ||
                            (CMP_DYNFLD(pdbadyntabOriFmtElt[i], pdbadynFmtElt, A_FmtElt_CellFmt, A_FmtElt_CellFmt, NoteType) != 0))
                        {
                            enRefFmtEltNat = ReferenceFormatElementReferenceNatEn::Modified;
                            idOriginFormat = idRefFormat;
                        }
                    }

                    if (enRefFmtEltNat != ReferenceFormatElementReferenceNatEn::Original)
                    {
                        DBA_DYNFLD_STP  pdbadynNewRefFmtElt = ALLOC_DYNST(A_ReferenceFormatElement);
                        CONVERT_DYNST (pdbadynNewRefFmtElt, A_ReferenceFormatElement, pdbadyntabOriFmtElt[i], A_FmtElt);
                        SET_ID(pdbadynNewRefFmtElt, A_ReferenceFormatElement_FmtId, idSelFormat);
                        SET_ENUM(pdbadynNewRefFmtElt, A_ReferenceFormatElement_ReferenceNatEn, enRefFmtEltNat);
                        SET_ID(pdbadynNewRefFmtElt, A_ReferenceFormatElement_OriginFmtId, idOriginFormat);
                    
                        /*  Insert New Format Element                   */
                        retCode = DBA_Insert2 ( ReferenceFormatElement,
                                                UNUSED,
                                                A_ReferenceFormatElement,
                                                pdbadynNewRefFmtElt,
                                                dbiConnHelper);

                            /*  Copy logicals                               */
                            if (retCode == RET_SUCCEED)
                            {
                                /*  From reference format element           */
                                retCode = DBA_CopyAutomatic(FmtElt,
                                                            ReferenceFormatElement,
                                                            GET_ID(pdbadyntabOriFmtElt[i], S_FmtElt_Id),
                                                            GET_ID(pdbadynNewRefFmtElt, S_ReferenceFormatElement_Id),
                                                        nullptr,
                                                        dbiConnHelper);
                            }
                        }
                    }
                }
                SMALLINT_T  iRank = MAX_SHORT;
                for (int i = 0; (i < iNbRefFmtElt) && (retCode == RET_SUCCEED); i++)
                {
                    if ((IS_NULLFLD(pdbadyntabRefFmtElt[i], A_FmtElt_TslMultilingualEn) == TRUE) ||
                        (GET_ENUM(pdbadyntabRefFmtElt[i], A_FmtElt_TslMultilingualEn) != TslMultilingual_MultilingualChild))
                    {
                        DBA_DYNFLD_STP  pdbadynFmtElt = nullptr;
                        DBA_GetRecPtrFromHierByCd(phierOri, GET_SYSNAME(pdbadyntabRefFmtElt[i],A_FmtElt_SqlName), A_FmtElt, &pdbadynFmtElt, UNUSED);
                        /*  Format element removed in new format            */
                        if (pdbadynFmtElt == nullptr)
                        {
                        DBA_DYNFLD_STP  pdbadynNewRefFmtElt = ALLOC_DYNST(A_ReferenceFormatElement);
                        CONVERT_DYNST (pdbadynNewRefFmtElt, A_ReferenceFormatElement, pdbadyntabRefFmtElt[i], A_FmtElt);
                        SET_ID(pdbadynNewRefFmtElt, A_ReferenceFormatElement_FmtId, idSelFormat);
                        SET_ENUM(pdbadynNewRefFmtElt, A_ReferenceFormatElement_ReferenceNatEn, ReferenceFormatElementReferenceNatEn::Deleted);
                        SET_ID(pdbadynNewRefFmtElt, A_ReferenceFormatElement_OriginFmtId, idRefFormat);
                        SET_SMALLINT(pdbadynNewRefFmtElt, A_ReferenceFormatElement_Rank, iRank);
                        iRank--;

                        /*  Insert New Format Element                   */
                        retCode = DBA_Insert2 ( ReferenceFormatElement,
                                                UNUSED,
                                                A_ReferenceFormatElement,
                                                pdbadynNewRefFmtElt,
                                                dbiConnHelper);
                        }
                    }
                }

            /*  End transaction: commit or rollback                 */
            dbiConnHelper.endTransaction(retCode == RET_SUCCEED ? TRUE : FALSE);
        }
        FREE(pdbadyntabOriFmtElt);
        FREE(pdbadyntabRefFmtElt);
    }

    /*  Free hiearchy and complete allocation                       */
    DBA_FreeHier(phierOri);
    DBA_FreeHier(phierRef);

    return retCode;
}


/************************************************************************
**   END  dbafmt.c                                            UNICIBLE **
*************************************************************************/

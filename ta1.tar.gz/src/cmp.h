/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef CMP_H
#define CMP_H

/************************************************************************
**      Constant & Macro definitions
*************************************************************************/

/************************************************************************
**      Structures & typedef definitions
*************************************************************************/

/************************************************************************
**      External definitions attached to : cmplib.c
*************************************************************************/
#ifdef  EXTERN
#undef	EXTERN
#endif
#ifdef  CMPLIB_C
#define	EXTERN
#else
#define EXTERN extern
#endif

EXTERN int    CMP_ShCurrency(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *),
              CMP_InterCondByDt(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *),    /* DVP563 */
              CMP_InterCondByIdDt(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *),  /* DVP563 */
              CMP_ExchEvtByDt(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *); /* REF1132 - DDV - 980312 */

#endif					/* ifndef CMP_H */
/************************************************************************
*      END      cmp.h                                            UNICIBLE
*************************************************************************/

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define CASEMGT01_C

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H
#define MATH_H

#include "unidef.h"     /* Mandatory */
#include "gen.h"
#include "date.h"
#include "dba.h"
#include "syslib.h"
#include "tls.h"
#include "hier.h"
#include "fin.h"
#include "scptyl.h"
#include "scelib.h"
#include "casemgt.h"

/************************************************************************
**      External entry points
**
**  FIN_CreateConstrBreachCase()	Generate Cases from existing Constraint Breaches.
**
*************************************************************************/

/************************************************************************
**      Local functions
**
**
**
*************************************************************************/
STATIC int FIN_FilterCBFromPtf(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);
STATIC int FIN_FilterESETradingConstraint(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);
STATIC int FIN_FilterESEHoldingConstraint(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);
STATIC int FIN_FilterESEModellingCstr(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);
STATIC int FIN_FilterExtOpFromCB(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);
STATIC int FIN_FilterESEModelingTradingConstraint(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP); /*PMSTA-42156-Badhri-25112020*/

/************************************************************************
**      Static definitions & data
*************************************************************************/

/**** INTERNAL STRUCTURES ****/

/************************************************************************
**      Functions
*************************************************************************/


/************************************************************************
**
**  Function    :   FIN_CmpESELevel()
**
**  Description :   Sort ESE by Level
**
**  Arguments   :   ptr1   pointer on dynamic structure type ExtPos
**                  ptr2   pointer on dynamic structure type ExtPos
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation    :   PMSTA13559-CHU-120221
**
*************************************************************************/
STATIC int FIN_CmpESELevel(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
	return(GET_TINYINT((*ptr1), ExtStratElt_Level) -
		   GET_TINYINT((*ptr2), ExtStratElt_Level));
}

/***************************************************************************************
**
**  Function    :   FIN_CreateConstrBreachCase()
**
**  Description :   Generate Cases from existing Constraint Breaches
**
**  Argument    :   domainPtr
**                  hearHead
**
**  Return      :   RET_SUCCEED or return code
**
**  creation	:   PMSTA07121-CHU-081013
**
**  Last modif. :
**
***************************************************************************************/
RET_CODE FIN_CreateConstrBreachCase(DBA_DYNFLD_STP	domainPtr,
									PTR				hierHead,
									DBA_DYNFLD_STP  ptfPtr)
{
	RET_CODE			ret = RET_SUCCEED;
	OBJECT_ENUM			entity;
	DBA_HIER_HEAD_STP	hierPtr=(DBA_HIER_HEAD_STP)hierHead;
	DICT_T				entityDictId;
	DBA_DYNFLD_STP		*CBTab=NULLDYNSTPTR, casePtr=NULLDYNST, stratEltPtr=NULLDYNST, stratPtr=NULLDYNST,
						stratHistPtr=NULLDYNST, orderPtr=NULLDYNST, tradConstrPtr=NULLDYNST, MCEltPtr=NULLDYNST,
						MCPtr=NULLDYNST, ESEPtr=NULLDYNST, *ESETab=NULLDYNSTPTR;
	int					i, CBNbr=0, ESENbr=0;
	DBA_DYNFLD_ST		ptfIdDynSt;
	/*pmsta-13189 - sru -20120419*/
    DBA_DYNFLD_STP		*ExtOpTab=NULLDYNSTPTR;
	int ExtOpNbr = 0;
	HIER_FLTFCT *filterFn = NULLFCT;

	memset(&ptfIdDynSt, 0, sizeof(DBA_DYNFLD_ST));
	SET_ID((&ptfIdDynSt), 0, GET_ID(ptfPtr, A_Ptf_Id));

	/* extract all RL ESE */
	/* PMSTA07121 - RAK - extract CB for current portfolio */
	/* PMSTA07121 - RAK - extract CB for current portfolio */
	if ((ret = DBA_ExtractHierEltRecWithFilterSt(hierPtr,
                                     A_ConstraintBreach,
                                     FALSE,
					                 FIN_FilterCBFromPtf,
									 ptfPtr,
                                     NULLFCT,
					                 &CBNbr,
                                     &CBTab)) != RET_SUCCEED)
	{
 		return(ret);
	}

	for (i=0; i<CBNbr; i++)
	{
		stratEltPtr=stratPtr=stratHistPtr=NULLDYNST;
		MCPtr=MCEltPtr=NULLDYNST;
		orderPtr	  = NULLDYNST;
		tradConstrPtr = NULLDYNST;
		ESEPtr = NULLDYNST;
		ESETab = NULLDYNSTPTR;
		ESENbr = 0;

		if ((casePtr = ALLOC_DYNST(A_CaseManagement)) == NULLDYNST)
		{
			MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "A_CaseManagement");
			FREE(CBTab);
			return(RET_MEM_ERR_ALLOC);
		}

		DBA_SetDfltEntityFld(CaseManagement, A_CaseManagement, casePtr);

		/* Initialised below */
		COPY_DYNFLD(casePtr,	A_CaseManagement,	A_CaseManagement_SessionId,
			        domainPtr,	A_Domain,			A_Domain_FctResultId);

		COPY_DYNFLD(casePtr,	A_CaseManagement,	A_CaseManagement_PtfId,
					CBTab[i],   A_ConstraintBreach, A_ConstraintBreach_PortfolioId);

		COPY_DYNFLD(casePtr, A_CaseManagement, A_CaseManagement_ParentPortId,					/*WEALTH-7147-Satya*/
			ptfPtr, A_Ptf, A_Ptf_Id);

		/*Load hierarchy population from domain flag*/
		COPY_DYNFLD(casePtr,    A_CaseManagement,   A_CaseManagement_LoadHierFlg,
			domainPtr, A_Domain, A_Domain_LoadHierFlg);

		if (IS_NULLFLD(CBTab[i], A_ConstraintBreach_DraftOrderId) == FALSE)
		{
			/*pmsta-13189 - sru - 20120419 */

			if ((ret = DBA_ExtractHierEltRecWithFilterSt(hierPtr,
                                     ExtOp,
                                     FALSE,
					                 FIN_FilterExtOpFromCB,
									 CBTab[i],
                                     NULLFCT,
					                 &ExtOpNbr,
                                     &ExtOpTab)) != RET_SUCCEED)
	        {
		       FREE(CBTab);
			   FREE_DYNST(casePtr, A_CaseManagement);
 		       return(ret);
	        }
			/*pmsta-13189 - sru -20120419*/
			if(ExtOpNbr > 0)
			{
			  orderPtr = ExtOpTab[0];
			  FREE(ExtOpTab);
			  ExtOpNbr = 0;
		    }

			if (orderPtr != NULLDYNST)
			{
				FLAG_T			applCaseActivationFlag	  = FALSE;
				FLAG_T			applOrderConfirmedFlagMgmt = FALSE;

				GEN_GetApplInfo(ApplCaseActivationFlag, &applCaseActivationFlag);
				GEN_GetApplInfo(ApplOrderConfirmedFlagMgmt, &applOrderConfirmedFlagMgmt);

				if (applCaseActivationFlag == TRUE &&
					GET_FLAG(orderPtr, ExtOp_ConfirmedFlg)==FALSE &&
					applOrderConfirmedFlagMgmt == FALSE)
				{
					FREE_DYNST(casePtr, A_CaseManagement);
					continue;
				}
				COPY_DYNFLD(casePtr,  A_CaseManagement, A_CaseManagement_InstrId,
							orderPtr, ExtOp,            ExtOp_InstrId);
			}
		}

		switch ((STRATNAT_ENUM) GET_ENUM(CBTab[i], A_ConstraintBreach_NatureEn))
		{
		case StratNat_ConstraintSet :
			SET_ENUM(casePtr, A_CaseManagement_NatEn,    CaseManagementNat_TradHoldConstraint);
			SET_ENUM(casePtr, A_CaseManagement_SubNatEn, CaseManagementSubNat_HoldingConstraint);

			if (IS_NULLFLD(CBTab[i], A_ConstraintBreach_StrategyEltId) == FALSE)
			{
  				stratEltPtr = DBA_SearchHierRecById(hierPtr, A_StratElt,
					                           A_StratElt_Id, GET_ID(CBTab[i], A_ConstraintBreach_StrategyEltId));

				if (stratEltPtr != NULLDYNST)
				{
					stratHistPtr = DBA_SearchHierRecById(hierPtr, A_StratHist,
					                           A_StratHist_Id, GET_ID(stratEltPtr, A_StratElt_StratHistId));

					if (stratHistPtr != NULLDYNST)
					{
						stratPtr = DBA_SearchHierRecById(hierPtr, A_Strat,
					                           A_Strat_Id, GET_ID(stratHistPtr, A_StratHist_StratId));
					}

					if (stratPtr != NULLDYNST)
					{
						if ((CONSTRCRITICALNESS_ENUM) GET_ENUM(stratEltPtr, A_StratElt_CriticalnessEn) >
						(CONSTRCRITICALNESS_ENUM) GET_ENUM(stratPtr, A_Strat_CriticalnessEn))
						{
							COPY_DYNFLD(casePtr,     A_CaseManagement, A_CaseManagement_CriticalnessEn,
										stratEltPtr, A_StratElt,       A_StratElt_CriticalnessEn);
						}
						else
						{
							COPY_DYNFLD(casePtr,  A_CaseManagement, A_CaseManagement_CriticalnessEn,
										stratPtr, A_Strat,          A_Strat_CriticalnessEn);
						}
						/* WEALTH-10071 - KKM - 16072024 */
						if (IS_NULLFLD(stratEltPtr, A_StratElt_CaseMgtTypeId) == FALSE)
						{
							COPY_DYNFLD(casePtr,     A_CaseManagement, A_CaseManagement_CaseManagementTypeId,
								        stratEltPtr, A_StratElt,       A_StratElt_CaseMgtTypeId);
						}
					}


					if ((ret = DBA_ExtractHierEltRecByIndexKey(hierPtr,
														   ExtStratElt,
														   ExtStratElt_PtfId,
														   ptfIdDynSt,
														   FALSE,
														   FIN_FilterESEHoldingConstraint,
														   stratEltPtr,
														   NULLFCT,
														   FALSE,
														   &ESENbr, &ESETab)) != RET_SUCCEED)
					{
						FREE(CBTab);
						FREE_DYNST(casePtr, A_CaseManagement);
						return(ret);
					}

					if (ESENbr > 0)
					{
						ESEPtr = ESETab[0];
					}
					FREE(ESETab);

				}
			}

			break;

		case StratNat_TradingConstr :
			/*PMSTA-42156-Badhri-25112020*/
			if (StratNat_TradingConstr == GET_ENUM(CBTab[i], A_ConstraintBreach_NatureEn)  &&
				FALSE == IS_NULLFLD(CBTab[i], A_ConstraintBreach_TradingConstraintId))
			{
				SET_ENUM(casePtr, A_CaseManagement_NatEn, CaseManagementNat_TradHoldConstraint);
				SET_ENUM(casePtr, A_CaseManagement_SubNatEn, CaseManagementSubNat_TradingConstraint);

				filterFn = FIN_FilterESETradingConstraint;
			}
			else if (StratNat_TradingConstr == GET_ENUM(CBTab[i], A_ConstraintBreach_NatureEn) &&
				     FALSE == IS_NULLFLD(CBTab[i], A_ConstraintBreach_ModelConstrEltId))
			{
				SET_ENUM(casePtr, A_CaseManagement_NatEn, CaseManagementNat_ModellingCstr);
				SET_ENUM(casePtr, A_CaseManagement_SubNatEn, CaseManagementSubNat_ModellingTradConstr);

				filterFn = FIN_FilterESEModelingTradingConstraint;
			}

			if ((ret = DBA_ExtractHierEltRecByIndexKey(hierPtr,
														   ExtStratElt,
														   ExtStratElt_PtfId,
														   ptfIdDynSt,
														   FALSE,
														   filterFn, /* ExtStratElt_TradConstrId */ /*PMSTA-42156-Badhri-25112020*/
														   CBTab[i],
														   NULLFCT,
														   FALSE,
														   &ESENbr, &ESETab)) != RET_SUCCEED)
			{
				FREE(CBTab);
				FREE_DYNST(casePtr, A_CaseManagement);
				return(ret);
			}

			if (ESENbr > 0)
			{
				ESEPtr = ESETab[0];
			}
			FREE(ESETab);

			if (IS_NULLFLD(CBTab[i], A_ConstraintBreach_TradingConstraintId) == FALSE)
			{
				tradConstrPtr = DBA_SearchHierRecById(hierPtr, A_TradConstr,
											   A_TradConstr_Id, GET_ID(CBTab[i], A_ConstraintBreach_TradingConstraintId));

				if ((tradConstrPtr != NULLDYNST) &&
					 IS_NULLFLD(tradConstrPtr, A_TradConstr_CriticalnessEn) == FALSE)
				{
					COPY_DYNFLD(casePtr,       A_CaseManagement, A_CaseManagement_CriticalnessEn,
						        tradConstrPtr, A_TradConstr, A_TradConstr_CriticalnessEn);
				}
				/* WEALTH-10070 - KKM - 15072024 */
				if ((tradConstrPtr != NULLDYNST) &&
					 IS_NULLFLD(tradConstrPtr, A_TradConstr_CaseManagementTypeId) == FALSE)
				{
					COPY_DYNFLD(casePtr,       A_CaseManagement, A_CaseManagement_CaseManagementTypeId,
						        tradConstrPtr, A_TradConstr,     A_TradConstr_CaseManagementTypeId);
				}
			}
			else if (IS_NULLFLD(CBTab[i], A_ConstraintBreach_ModelConstrEltId) == FALSE) /*PMSTA-42156-Badhri-25112020*/
			{
				MCEltPtr = DBA_SearchHierRecById(hierPtr, A_ModelConstrElt,
					A_ModelConstrElt_Id, GET_ID(CBTab[i], A_ConstraintBreach_ModelConstrEltId));

				if (NULLDYNST != MCEltPtr)
				{
					MCPtr = DBA_SearchHierRecById(hierPtr, A_ModelConstr,
						A_ModelConstr_Id, GET_ID(MCEltPtr, A_ModelConstrElt_ModelConstrId));

					/* Get instrument */
					if (FALSE == IS_NULLFLD(MCEltPtr, A_ModelConstrElt_DimInstrDictId))
					{
						DBA_GetObjectEnum(GET_DICT(MCEltPtr, A_ModelConstrElt_DimInstrDictId), &entity);
						if (entity == Instr)
						{
							COPY_DYNFLD(casePtr, A_CaseManagement, A_CaseManagement_InstrId,
								MCEltPtr, A_ModelConstrElt, A_ModelConstrElt_InstrObjId);
						}
					}

					if (FALSE == IS_NULLFLD(MCEltPtr, A_ModelConstrElt_CriticalnessEn))
					{
						COPY_DYNFLD(casePtr, A_CaseManagement, A_CaseManagement_CriticalnessEn,
							MCEltPtr, A_ModelConstrElt, A_ModelConstrElt_CriticalnessEn);
					}
					/* WEALTH-10072 - KKM - 29072024 */
					if (IS_NULLFLD(MCEltPtr, A_ModelConstrElt_CaseMgtTypeId) == FALSE)
					{
						COPY_DYNFLD(casePtr, A_CaseManagement, A_CaseManagement_CaseManagementTypeId,
							        MCEltPtr, A_ModelConstrElt, A_ModelConstrElt_CaseMgtTypeId);
					}
				}
			}

			break;

		case StratNat_SecurityConstr:
			SET_ENUM(casePtr, A_CaseManagement_NatEn, CaseManagementNat_ModellingCstr);

			if (IS_NULLFLD(CBTab[i], A_ConstraintBreach_ModelConstrEltId) == FALSE)
			{
				MCEltPtr = DBA_SearchHierRecById(hierPtr, A_ModelConstrElt,
											   A_ModelConstrElt_Id, GET_ID(CBTab[i], A_ConstraintBreach_ModelConstrEltId));

				if (MCEltPtr != NULLDYNST)
				{
					/* Get instrument */
					if (IS_NULLFLD(MCEltPtr, A_ModelConstrElt_DimInstrDictId) == FALSE)
					{
						DBA_GetObjectEnum(GET_DICT(MCEltPtr, A_ModelConstrElt_DimInstrDictId),  &entity);
						if (entity == Instr)
						{
							COPY_DYNFLD(casePtr,  A_CaseManagement, A_CaseManagement_InstrId,
										MCEltPtr, A_ModelConstrElt, A_ModelConstrElt_InstrObjId);
						}
					}

					if ((ret = DBA_ExtractHierEltRecByIndexKey(hierPtr,
														   ExtStratElt,
														   ExtStratElt_PtfId,
														   ptfIdDynSt,
														   FALSE,
														   FIN_FilterESEModellingCstr, /* ExtStratElt_ModelConstrEltId */
														   MCEltPtr,
														   FIN_CmpESELevel, /* PMSTA13559-CHU-120221 */
														   FALSE,
														   &ESENbr, &ESETab)) != RET_SUCCEED)
					{
						FREE(CBTab);
						FREE_DYNST(casePtr, A_CaseManagement);
						return(ret);
					}

					if (ESENbr > 0)
					{
						ESEPtr = ESETab[0];
					}
					FREE(ESETab);

					MCPtr = DBA_SearchHierRecById(hierPtr, A_ModelConstr,
											   A_ModelConstr_Id, GET_ID(MCEltPtr, A_ModelConstrElt_ModelConstrId));

					/* PMSTA07121 - RAK - 090430 - If element criticity > strategy criticity use it */
					if ((CONSTRCRITICALNESS_ENUM) GET_ENUM(MCEltPtr, A_ModelConstrElt_CriticalnessEn) >
						(CONSTRCRITICALNESS_ENUM) GET_ENUM(MCPtr, A_ModelConstr_CriticalnessEn))
					{
						COPY_DYNFLD(casePtr,  A_CaseManagement, A_CaseManagement_CriticalnessEn,
									MCEltPtr, A_ModelConstrElt, A_ModelConstrElt_CriticalnessEn);
					}
					else
					{
						COPY_DYNFLD(casePtr, A_CaseManagement, A_CaseManagement_CriticalnessEn,
									MCPtr,   A_ModelConstr,    A_ModelConstr_CriticalnessEn);
					}
					/* WEALTH-10072 - KKM - 29072024 */
					if (IS_NULLFLD(MCEltPtr, A_ModelConstrElt_CaseMgtTypeId) == FALSE)
					{
						COPY_DYNFLD(casePtr, A_CaseManagement, A_CaseManagement_CaseManagementTypeId,
							        MCEltPtr, A_ModelConstrElt, A_ModelConstrElt_CaseMgtTypeId);
					}

					if (GET_ENUM(MCPtr, A_ModelConstr_NatEn) == ModelConstr_SecurityOutConstr)
					{
						SET_ENUM(casePtr, A_CaseManagement_SubNatEn, CaseManagementSubNat_SecurityOut);
					}
					else if (GET_ENUM(MCPtr, A_ModelConstr_NatEn) == ModelConstr_SecurityInConstr)
					{
						SET_ENUM(casePtr, A_CaseManagement_SubNatEn, CaseManagementSubNat_SecurityIn);
					}
				}
			}
			break;

		case StratNat_AllocConstr:

			SET_ENUM(casePtr, A_CaseManagement_NatEn,    CaseManagementNat_ModellingCstr);
			SET_ENUM(casePtr, A_CaseManagement_SubNatEn, CaseManagementSubNat_AllocConstr);

			if (IS_NULLFLD(CBTab[i], A_ConstraintBreach_ModelConstrEltId) == FALSE)
			{
				MCEltPtr = DBA_SearchHierRecById(hierPtr, A_ModelConstrElt,
											   A_ModelConstrElt_Id, GET_ID(CBTab[i], A_ConstraintBreach_ModelConstrEltId));

				if (MCEltPtr != NULLDYNST)
				{
					if ((ret = DBA_ExtractHierEltRecByIndexKey(hierPtr,
														   ExtStratElt,
														   ExtStratElt_PtfId,
														   ptfIdDynSt,
														   FALSE,
														   FIN_FilterESEModellingCstr, /* ExtStratElt_ModelConstrEltId */
														   MCEltPtr,
														   NULLFCT,
														   FALSE,
														   &ESENbr, &ESETab)) != RET_SUCCEED)
					{
						FREE(CBTab);
						FREE_DYNST(casePtr, A_CaseManagement);
						return(ret);
					}

					if (ESENbr > 0)
					{
						ESEPtr = ESETab[0];
					}
					FREE(ESETab);

					MCPtr = DBA_SearchHierRecById(hierPtr, A_ModelConstr,
											   A_ModelConstr_Id, GET_ID(MCEltPtr, A_ModelConstrElt_ModelConstrId));


					/* PMSTA07121 - RAK - 090430 - If element criticity > strategy criticity use it */
					if ((CONSTRCRITICALNESS_ENUM) GET_ENUM(MCEltPtr, A_ModelConstrElt_CriticalnessEn) >
						(CONSTRCRITICALNESS_ENUM) GET_ENUM(MCPtr, A_ModelConstr_CriticalnessEn))
					{
						COPY_DYNFLD(casePtr,  A_CaseManagement, A_CaseManagement_CriticalnessEn,
									MCEltPtr, A_ModelConstrElt, A_ModelConstrElt_CriticalnessEn);
					}
					else
					{
						COPY_DYNFLD(casePtr, A_CaseManagement, A_CaseManagement_CriticalnessEn,
									MCPtr,   A_ModelConstr,    A_ModelConstr_CriticalnessEn);
					}
				}
			}
			break;
		}

		/* session id */
		DBA_GetDictId(FctResult, &entityDictId);
		SET_DICT(casePtr, A_CaseManagement_MainEntityDictId, entityDictId);
		SET_ID(casePtr,	 A_CaseManagement_MainObjId, GET_ID(domainPtr, A_Domain_FctResultId));

        /*PMSTA-50420 -Lalby- use ese criticalness for dynamic severity if dynamic severity enabled and applied*/
        if (GET_FLAG(domainPtr, A_Domain_CheckSeverityRuleFlg) == TRUE &&
            GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_CheckStrat)
        {
            if (IS_NULLFLD(CBTab[i], A_ConstraintBreach_ExtStrategyEltId) == FALSE)
            {
                DBA_DYNFLD_STP   tempEsePtr = NULLDYNSTPTR;
                if (DBA_GetRecPtrFromHierById(hierPtr,
                    GET_ID(CBTab[i], A_ConstraintBreach_ExtStrategyEltId),
                    ExtStratElt,
                    &tempEsePtr) == RET_SUCCEED && tempEsePtr != NULLDYNSTPTR)
                {
                    /* check severity rule applied for this ESE*/
                    if (GET_ID(tempEsePtr, ExtStratElt_SeverityRuleElementId) > 0 &&
                        (GET_ENUM(tempEsePtr, ExtStratElt_CriticalnessEn) >= GET_ENUM(casePtr, A_CaseManagement_CriticalnessEn)))
                    {
                        COPY_DYNFLD(casePtr, A_CaseManagement, A_CaseManagement_CriticalnessEn,
                            tempEsePtr, ExtStratElt, ExtStratElt_CriticalnessEn);
                    }
                }
            }
        }

		if ((ret = DBA_AddHierRecord(hierPtr, casePtr, A_CaseManagement,
									 TRUE, HierAddRec_NoLnk)) != RET_SUCCEED)
		{
			FREE(CBTab);
			FREE_DYNST(casePtr, A_CaseManagement);
			return(ret);
		}

		/* Add Portfolio to Case Linked Objects */
		if (IS_NULLFLD(casePtr, A_CaseManagement_PtfId) == FALSE)
		{
			DBA_GetDictId(Ptf, &entityDictId);
			if((ret = FIN_AddCaseLinkedObject(domainPtr, hierPtr, casePtr,
										  entityDictId, GET_ID(casePtr, A_CaseManagement_PtfId))) != RET_SUCCEED)
			{
				FREE(CBTab);
				return(ret);
			}
		}

		/* Add Instrument to Case Linked Objects */
		if (IS_NULLFLD(casePtr, A_CaseManagement_InstrId) == FALSE)
		{
			DBA_GetDictId(Instr, &entityDictId);
			if((ret = FIN_AddCaseLinkedObject(domainPtr, hierPtr, casePtr,
										  entityDictId, GET_ID(casePtr, A_CaseManagement_InstrId))) != RET_SUCCEED)
			{
				FREE(CBTab);
				return(ret);
			}
		}

		/* Add Strategy element and Strategy to Case Linked Objects */
		if (stratEltPtr != NULLDYNST)
		{
			DBA_GetDictId(StratElt, &entityDictId);
			if((ret = FIN_AddCaseLinkedObject(domainPtr, hierPtr, casePtr,
										  entityDictId, GET_ID(stratEltPtr, A_StratElt_Id))) != RET_SUCCEED)
			{
				FREE(CBTab);
				return(ret);
			}

			/* get strategy */
			stratHistPtr = DBA_SearchHierRecById(hierPtr, A_StratHist,
											   A_StratHist_Id, GET_ID(stratEltPtr, A_StratElt_StratHistId));

			if (stratHistPtr != NULLDYNST)
			{
				stratPtr = DBA_SearchHierRecById(hierPtr, A_Strat,
											     A_Strat_Id, GET_ID(stratHistPtr, A_StratHist_StratId));
			}

			if (stratPtr != NULLDYNST)
			{
				DBA_GetDictId(Strat, &entityDictId);
				if((ret = FIN_AddCaseLinkedObject(domainPtr, hierPtr, casePtr,
										  entityDictId, GET_ID(stratPtr, A_Strat_Id))) != RET_SUCCEED)
				{
					FREE(CBTab);
					return(ret);
				}
			}
		}

		if (MCPtr != NULLDYNST)
		{
			DBA_GetDictId(ModelConstr, &entityDictId);
			if((ret = FIN_AddCaseLinkedObject(domainPtr, hierPtr, casePtr,
										  entityDictId, GET_ID(MCPtr, A_ModelConstr_Id))) != RET_SUCCEED)
			{
				FREE(CBTab);
				return(ret);
			}
		}

		if (MCEltPtr != NULLDYNST)
		{
			DBA_GetDictId(ModelConstrElt, &entityDictId);
			if((ret = FIN_AddCaseLinkedObject(domainPtr, hierPtr, casePtr,
										  entityDictId, GET_ID(MCEltPtr, A_ModelConstrElt_Id))) != RET_SUCCEED)
			{
				FREE(CBTab);
				return(ret);
			}
		}

		if (tradConstrPtr != NULLDYNST)
		{
			DBA_GetDictId(TradConstr, &entityDictId);
			if((ret = FIN_AddCaseLinkedObject(domainPtr, hierPtr, casePtr,
										  entityDictId, GET_ID(tradConstrPtr, A_TradConstr_Id))) != RET_SUCCEED)
			{
				FREE(CBTab);
				return(ret);
			}
		}

		if (orderPtr != NULLDYNST)
		{
			DBA_GetDictId(EOp, &entityDictId);
			if((ret = FIN_AddCaseLinkedObject(domainPtr, hierPtr, casePtr,
										  entityDictId, GET_ID(orderPtr, ExtOp_OpId))) != RET_SUCCEED)
			{
				FREE(CBTab);
				return(ret);
			}
		}
		/* WEALTH-12853 - Ravindra - 09092024 */
		if (CBTab[i] != NULLDYNST)
		{
			DBA_GetDictId(EStratElt, &entityDictId);
			if((ret = FIN_AddCaseLinkedObject(domainPtr, hierPtr, casePtr,
										  entityDictId, GET_ID(CBTab[i],A_ConstraintBreach_ExtStrategyEltId))) != RET_SUCCEED)
			{
				FREE(CBTab);
				return(ret);
			}
		}
	}

	FREE(CBTab);
	return(ret);
}

/************************************************************************
*
*   Function      :   FIN_FilterESETradingConstraint()
*
*   Description   :
*
*   Arguments     :   dynSt    element pointer
*                     dynStTp  element description enum
*
*   Return        :   TRUE or FALSE
*
*************************************************************************/
STATIC int FIN_FilterESETradingConstraint(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP CBPtr)
{

	if (GET_ID(dynSt, ExtStratElt_TradConstrId) == GET_ID(CBPtr, A_ConstraintBreach_TradingConstraintId) &&
		GET_ID(dynSt, ExtStratElt_ExtOpId)      == GET_ID(CBPtr, A_ConstraintBreach_DraftOrderId))
		return(TRUE);
	else
		return(FALSE);
}

/************************************************************************
*
*   Function      :   FIN_FilterESEModelingTradingConstraint()
*
*   Description   :
*
*   Arguments     :   dynSt    element pointer
*                     dynStTp  element description enum
*
*   Return        :   TRUE or FALSE
*
*************************************************************************/
STATIC int FIN_FilterESEModelingTradingConstraint(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP CBPtr)
{
	/*PMSTA-42156-Badhri-25112020*/
	if (CMP_ID(GET_ID(dynSt, ExtStratElt_ModelConstrEltId), GET_ID(CBPtr, A_ConstraintBreach_ModelConstrEltId)) == 0 &&
		CMP_ID(GET_ID(dynSt, ExtStratElt_ExtOpId), GET_ID(CBPtr, A_ConstraintBreach_DraftOrderId)) == 0)
		return(TRUE);
	else
		return(FALSE);
}

/************************************************************************
*
*   Function      :   FIN_FilterESEHoldingConstraint()
*
*   Description   :
*
*   Arguments     :   dynSt    element pointer
*                     dynStTp  element description enum
*
*   Return        :   TRUE or FALSE
*
*************************************************************************/
STATIC int FIN_FilterESEHoldingConstraint(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP stratEltPtr)
{

	if (GET_ID(dynSt, ExtStratElt_StratEltId) == GET_ID(stratEltPtr, A_StratElt_Id) &&
		GET_TINYINT(dynSt, ExtStratElt_Level) == 2)
		return(TRUE);
	else
		return(FALSE);
}

/************************************************************************
*
*   Function      :   FIN_FilterESEModellingCstr()
*
*   Description   :
*
*   Arguments     :   dynSt    element pointer
*                     dynStTp  element description enum
*
*   Return        :   TRUE or FALSE
*
*************************************************************************/
STATIC int FIN_FilterESEModellingCstr(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP MCEltPtr)
{
	if (GET_ID(dynSt, ExtStratElt_ModelConstrEltId) == GET_ID(MCEltPtr, A_ModelConstrElt_Id))
		return(TRUE);
	else
		return(FALSE);
}

/************************************************************************
*
*   Function      :   FIN_FilterCBFromPtf()
*
*   Description   :
*
*   Arguments     :   dynSt    element pointer
*                     dynStTp  element description enum
*
*   Return        :   TRUE or FALSE
*
*************************************************************************/
STATIC int FIN_FilterCBFromPtf(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP ptfPtr)
{
	/* REF3641 - strat focus elements need same treatment than reconcil elements */
	if (GET_ID(dynSt, A_ConstraintBreach_PortfolioId) == GET_ID(ptfPtr, A_Ptf_Id))
    {
		return(TRUE);
    }
	else
	{
		FLAG_T				allocFlg=FALSE;
		DBA_HIER_HEAD_STP	hierHead=(DBA_HIER_HEAD_STP)DBA_GetHierOptiPtr();
		DBA_DYNFLD_STP		cbPtfPtr=NULLDYNST;

		if (DBA_GetPtfById(GET_ID(dynSt, A_ConstraintBreach_PortfolioId), FALSE, &allocFlg,
	                           &cbPtfPtr, hierHead, UNUSED, UNUSED) == RET_SUCCEED)
		{
			if (GET_ID(cbPtfPtr,  A_Ptf_HierPortId) == GET_ID(ptfPtr, A_Ptf_Id))
			{
				if (allocFlg == TRUE) { FREE_DYNST(cbPtfPtr, A_Ptf); } /* PMSTA39941 - 02052020 - HLA - If ptf record fetched from DB */
				return(TRUE);
			}
		}

		if (allocFlg == TRUE) { FREE_DYNST(cbPtfPtr, A_Ptf);}
	}

    return(FALSE);
}

/************************************************************************
*
*   Function      :   FIN_FilterExtOpFromCB()
*
*   Description   :
*
*   Arguments     :   dynSt    element pointer
*                     dynStTp  element description enum
*
*   Return        :   TRUE or FALSE
*
*************************************************************************/
STATIC int FIN_FilterExtOpFromCB(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP CBPtr)
{
	/* PMSTA-14190-CHU-120429 : use CMP_ID() */
	if (CMP_ID(GET_ID(dynSt, ExtOp_PtfId),          GET_ID(CBPtr, A_ConstraintBreach_PortfolioId)) == 0 &&
		(CMP_ID(GET_ID(dynSt, ExtOp_OpId),          GET_ID(CBPtr, A_ConstraintBreach_DraftOrderId)) == 0 ||
		 CMP_ID(GET_ID(dynSt, ExtOp_DraftOrderId),  GET_ID(CBPtr, A_ConstraintBreach_DraftOrderId)) == 0))
    {
		return(TRUE);
    }

    return(FALSE);
}

/***************************************************************************************
**
**  Function    :   FIN_GenerateConstrBreachFromCase()
**
**  Description :   Generate Constraint Breaches from Cases (for old Constriant Breaches)
**
**  Argument    :   domainPtr
**                  hearHead
**
**  Return      :   RET_SUCCEED or return code
**
**  creation	:   PMSTA07121-RAK-081127
**  Last modif. :
**
***************************************************************************************/
RET_CODE FIN_GenerateConstrBreachFromCase(DBA_DYNFLD_STP	domainPtr,
										  PTR				hierHead)
{
	RET_CODE			ret = RET_SUCCEED;
	DBA_HIER_HEAD_STP	hierPtr=(DBA_HIER_HEAD_STP)hierHead;
	OBJECT_ENUM			entObj = NullEntity;
	DBA_DYNFLD_STP		CBPtr=NULLDYNST, *caseTab=NULLDYNSTPTR, *caseLnkTab=NULLDYNSTPTR;
	int					i, j, caseNbr=0, caseLnkNbr=0;

	/* PMSTA07121 - RAK - extract CB for current portfolio */
	if ((ret = DBA_ExtractHierEltRec(hierPtr,
                                     A_CaseManagement,
                                     FALSE,
									 FIN_FilterCasesForCB,
                                     NULLFCT,
					                 &caseNbr,
                                     &caseTab)) != RET_SUCCEED)
	{
 		return(ret);
	}

	for (i=0; i<caseNbr; i++)
	{
		if ((CBPtr = ALLOC_DYNST(A_ConstraintBreach)) == NULLDYNST)
		{
			MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "A_ConstraintBreach");
			FREE(caseTab);
			return(RET_MEM_ERR_ALLOC);
		}

		COPY_DYNFLD(CBPtr,   A_ConstraintBreach, A_ConstraintBreach_PortfolioId,
					caseTab[i],	A_CaseManagement,	A_CaseManagement_PtfId);

		switch ((STRATNAT_ENUM) GET_ENUM(caseTab[i], A_CaseManagement_NatEn))
		{
		case CaseManagementNat_TradHoldConstraint :

			if (GET_ENUM(caseTab[i], A_CaseManagement_SubNatEn) == CaseManagementSubNat_HoldingConstraint)
			{
				SET_ENUM(CBPtr, A_ConstraintBreach_NatureEn, StratNat_ConstraintSet);

			}
			else if (GET_ENUM(caseTab[i], A_CaseManagement_SubNatEn) == CaseManagementSubNat_TradingConstraint)
			{
				SET_ENUM(CBPtr, A_ConstraintBreach_NatureEn, StratNat_TradingConstr);

			}
			break;

		case CaseManagementNat_ModellingCstr :

			if (GET_ENUM(caseTab[i], A_CaseManagement_SubNatEn) == CaseManagementSubNat_AllocConstr)
			{
				SET_ENUM(CBPtr, A_ConstraintBreach_NatureEn, StratNat_Alloc);
			}
			else if (GET_ENUM(caseTab[i], A_CaseManagement_SubNatEn) == CaseManagementSubNat_SecurityOut ||
				     GET_ENUM(caseTab[i], A_CaseManagement_SubNatEn) == CaseManagementSubNat_SecurityIn)
			{
				SET_ENUM(CBPtr, A_ConstraintBreach_NatureEn, StratNat_SecurityConstr);
			}
			break;
		}

		caseLnkTab=NULLDYNSTPTR;
		caseLnkNbr = 0;

		if (GET_EXTENSION_PTR(caseTab[i], A_CaseManagement_A_CaseLink_Ext) != NULL &&
			(caseLnkTab = GET_EXTENSION_PTR(caseTab[i], A_CaseManagement_A_CaseLink_Ext)) != NULL)
		{
			caseLnkNbr = GET_EXTENSION_NBR(caseTab[i], A_CaseManagement_A_CaseLink_Ext);

			for (j=0; j<caseLnkNbr; j++)
			{
				DBA_GetObjectEnum(GET_DICT(caseLnkTab[j], A_CaseLink_EntDictId),  &entObj);

				if (entObj == StratElt)
				{
					SET_ID(CBPtr, A_ConstraintBreach_StrategyEltId, GET_ID(caseLnkTab[j], A_CaseLink_ObjId));
				}
				else if (entObj == ModelConstrElt)
				{
					SET_ID(CBPtr, A_ConstraintBreach_ModelConstrEltId, GET_ID(caseLnkTab[j], A_CaseLink_ObjId));
				}
				else if (entObj == TradConstr)
				{
					SET_ID(CBPtr, A_ConstraintBreach_TradingConstraintId, GET_ID(caseLnkTab[j], A_CaseLink_ObjId));
				}
				else if (entObj == EOp)
				{
					SET_ID(CBPtr, A_ConstraintBreach_DraftOrderId, GET_ID(caseLnkTab[j], A_CaseLink_ObjId));
					/* A_ConstraintBreach_OrderId */
				}
			}
		}

		if ((ret = DBA_AddHierRecord(hierPtr, CBPtr, A_ConstraintBreach,
									 TRUE, HierAddRec_NoLnk)) != RET_SUCCEED)
		{
			FREE(caseTab);
			FREE_DYNST(CBPtr, A_ConstraintBreach);
			return(ret);
		}
	}

	FREE(caseTab);
	return(ret);
}

/************************************************************************
*
*   Function      :   FIN_FilterCBFromPtf()
*
*   Description   :
*
*   Arguments     :   dynSt    element pointer
*                     dynStTp  element description enum
*
*   Return        :   TRUE or FALSE
*
*************************************************************************/
int FIN_FilterCasesForCB(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP ptfPtr)
{
	if (GET_ENUM(dynSt, A_CaseManagement_NatEn) == CaseManagementNat_TradHoldConstraint ||
		GET_ENUM(dynSt, A_CaseManagement_NatEn) == CaseManagementNat_ModellingCstr)
	{
		return(TRUE);
	}

	return(FALSE);
}

/************************************************************************
**   END  casemgt01.c                                         UNICIBLE **
*************************************************************************/

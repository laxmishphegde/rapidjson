/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DBAPERFA_C

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define MATH_H
#define TIME_H
#define STDLIB_H

#include "unidef.h"
#include "gen.h"
#include "conv.h"
#include "dba.h"
#include "ope.h"
#include "proc.h"
#include "date.h"
#include "cmp.h"
#include "hier.h"
#include "dbaperfa.h"
#include "finperfa.h"
#include "dbisqlexecbyblock.h"
#include "dbiconnection.h"
#include "fin.h"
#include "srvperf4.h"
#include "finsrv05.h"

/************************************************************************
**      External entry points
**
**
**
*************************************************************************/
/************************************************************************
**      Local functions
**
** DBA_SelectDefaultBenchmark Select the default benchmarks to use in analysis phase.
** DBA_SelectStratLnkByPtf    Select all strategy links for portfolios stored in #dom_port.
** DBA_FilterBestStratLnk     Select only the best StatLnk all delte all others (used by analyis phase).
** DBA_FillVectorId         Fill all temporary tables with objects needed for all links
**
*************************************************************************/

/************************************************************************
**      Static definitions & data
*************************************************************************/

STATIC int DBA_CmpInstrId(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *);
STATIC int DBA_CmpStratId(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *);
STATIC int DBA_CmpPtfByCd(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *);
STATIC int DBA_CmpStratHisto(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *);
STATIC int DBA_FilterStratWithBench(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);
STATIC int DBA_FilterInstrWithIndex(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);

/************************************************************************
**      FONCTIONS
************************************************************************/



/************************************************************************
**  Function             : DBA_InitObjectLnkPerfAna()
**
**  Description          : Initialise a ObjectLnk structure for each objects
**                         (Instr/Strat/Ptf) present in hierarchy.
**
**  Arguments            : domainPtr    : pointer on domain of financial function
**                         hierHead     : pointer on hierarchy
**                         allocConn    : the connection number allocated
**
**  Return               : RET_SUCCEED              : if no problem was detected
**                         a RET_CODE               : if a message has been received
**
**  Creation Date        : 020919 - DDV - REF7758
**  Last Modification    :
*************************************************************************/
RET_CODE DBA_InitObjectLnkForInstrStratPtf(DBA_DYNFLD_STP                domainPtr,
                                           DBA_HIER_HEAD_STP             hierHead,
                                           RETURNINPARENTPTFRULE_ENUM	returnInParPtfRuleEn) /* PMSTA-10775 - LJE - 101105 */
{
    DBA_DYNFLD_STP  *objTab=NULLDYNSTPTR;
    int             objNbr=0;
    RET_CODE        ret=RET_SUCCEED;
    OBJECT_ENUM     domPtfDim, ptfDim, domEntityDim;
    DBA_DYNST_ENUM  hierDynStEn=NullDynSt;
    FIELD_IDX_T     idField=0;
	DICT_T          dictEntity;
    MemoryPool      mp;    
    MemoryPool      mpObjLink;

    dictEntity = GET_DICT(domainPtr, A_Domain_DimEntityDictId);
    DBA_GetObjectEnum(dictEntity, &domEntityDim);
    
    dictEntity = GET_DICT(domainPtr, A_Domain_DimPtfDictId);
    DBA_GetObjectEnum(dictEntity, &domPtfDim);

    ptfDim = domPtfDim;

	switch(GET_OBJECT_CST(domPtfDim)) /* REF8844 - LJE - 030416 */
	{
	    case PtfCst:
            hierDynStEn=A_Ptf;
            idField=A_Ptf_Id;
		    break;

        case StratCst:
            hierDynStEn=A_Strat;
            idField=A_Strat_Id;
		    break;

        case InstrCst:
            hierDynStEn=A_Instr;
            idField=A_Instr_Id;
		    break;

		/* PMSTA06916 - LJE - 081107 : Third party used portfolios */
	    case ThirdCst:
			ptfDim=Ptf;
			DBA_GetDictId(ptfDim, &dictEntity);
            hierDynStEn=A_Ptf;
            idField=A_Ptf_Id;
		    break;

	    default:
		    break;
    }

    /* extract all objects and create a new object links */
   	if ((ret = DBA_ExtractHierEltRec(hierHead, hierDynStEn,
			                         FALSE, NULL, NULL, &objNbr, &objTab)) != RET_SUCCEED)
	{
        FREE(objTab);
		return(ret);
	}

    mp.ownerPtr(objTab);

    if (objNbr > 0) /* REF9613 - LJE - 031103 */
    {           
        DBA_DYNFLD_STP  *objLnkTab = (DBA_DYNFLD_STP *)mp.calloc(objNbr, sizeof (DBA_DYNFLD_STP));
        int objLnkPos=0;
        size_t reallocNb = 0;

        for (int i=0; i<objNbr; i++)
        {
			/* PMSTA06916 - LJE - 081007 - Only the virtual ptf is used */
            /* WEALTH-4556 - DDV - 240201 - Adapt check avoid creation of virtualportfolio when dimensions are one ptf */
			if ((domPtfDim == Third || domEntityDim == List || domEntityDim == QuickSearch) && 
				(PTFCONSRULE_ENUM) GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) == PtfConsRule_MergedTWR &&
                GET_ID(objTab[i], A_Ptf_Id) > 0 )
			{
				continue;
			}

            /* WEALTH-4556 - DDV - 240201 - Adapt check avoid creation of virtualportfolio when dimensions are one ptf */
            if (domPtfDim == Ptf && domEntityDim == One &&
                (PTFCONSRULE_ENUM)GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) == PtfConsRule_MergedTWR &&
                GET_ID(objTab[i], A_Ptf_Id) != GET_ID(domainPtr, A_Domain_PtfObjId))
            {
                continue;
            }

            /* PMSTA-10775 - LJE - 101105 - Move here */
			/* PMSTA02013 - RAK - 071112 - Suppress children */
			/* in case of ReturnInParentPtfRule_ParentUsingHierPSP, keep children ... */
			/* if the parent haven't a "hierarchical PSP" we nee to perform old computation */
			if (ptfDim == Ptf &&
				IS_NULLFLD(objTab[i], A_Ptf_HierPortId) == FALSE &&
				returnInParPtfRuleEn == ReturnInParentPtfRule_Parent &&
				GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None &&
				(PTFCONSRULE_ENUM) GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) != PtfConsRule_DetailedChildren &&
                ((static_cast<LOADHIERPTF_ENUM> GET_ENUM(domainPtr, A_Domain_LoadHierFlg) != LoadHierPtf_IntermediateHierarchy) ?
                    true : FIN_IsPtfConsRuleValidForIntermediateHierarchy(domainPtr) == false))
			{
				continue;
			}

            DatePeriodVec compPeriods;
            /*PMSTA-27728-NRAO-190211*/
            DATETIME_T fromDate = GET_DATETIME(domainPtr, A_Domain_CalcRefDate);
            DATETIME_T tillDate = GET_DATETIME(domainPtr, A_Domain_InterpTillDate);

            if (ptfDim == Ptf &&
                (GET_ID(objTab[i], A_Ptf_Id) > 0))
            {
                RET_CODE compRet = FIN_GetPtfCompPeriods(domainPtr, hierHead, objTab[i], fromDate, tillDate, compPeriods);
				if (compRet != RET_SUCCEED)
				{
					MSG_LogSrvMesg(RET_DBA_ERR_NODATA, UNUSED, "Failed to find valid Portfolio Computation Dates in Storage/Analysis for : %1.",CodeType, GET_CODE(objTab[i], A_Ptf_Cd));
                    continue;
				}
            }
            else
            {   // default period
                compPeriods.push_back(fromDate,tillDate);
            }

            if(compPeriods.size() > 1)
            {
                reallocNb += compPeriods.size()-1;
                objLnkTab = (DBA_DYNFLD_STP *)mp.realloc(objLnkTab, (objNbr + reallocNb) * sizeof (DBA_DYNFLD_STP));
            }

            for(size_t j=0;j<compPeriods.size();j++)
            {
                objLnkTab[objLnkPos] = mpObjLink.allocDynst(FILEINFO, A_ObjectLnk);

                SET_DICT(objLnkTab[objLnkPos], A_ObjectLnk_FromEntDictId, dictEntity);
                SET_ID(objLnkTab[objLnkPos], A_ObjectLnk_FromObjectId, GET_ID(objTab[i], idField));
                SET_DATETIME(objLnkTab[objLnkPos], A_ObjectLnk_BeginDate, compPeriods[j].getBegin());
                SET_DATETIME(objLnkTab[objLnkPos], A_ObjectLnk_EndDate, compPeriods[j].getEnd());

			    objLnkPos++; /* PMSTA06916 - LJE - 081007 */
            }
        }

        /* insert all object link in hierarchy */
        if (objLnkPos > 0
            && (ret = DBA_AddHierRecordList(hierHead,
                                    objLnkTab,
                                    objLnkPos,
                                    A_ObjectLnk,
                                    FALSE)) == RET_SUCCEED)
        {
            mpObjLink.removeAll();
    	}
    }

    return(ret);
}

/************************************************************************
**  Function             : DBA_InitObjectLnkForListPtf()
**
**  Description          : Initialise a ObjectLnk structure for list
**
**  Arguments            : domainPtr    : pointer on domain of financial function
**                         hierHead     : pointer on hierarchy
**                         allocConn    : the connection number allocated
**
**  Return               : RET_SUCCEED              : if no problem was detected
**                         a RET_CODE               : if a message has been received
**
**  Creation Date        : PMSTA-53952-14112023-lalby
**  Last Modification    :
*************************************************************************/
RET_CODE DBA_InitObjectLnkForListPtf(DBA_DYNFLD_STP                domainPtr,
    DBA_HIER_HEAD_STP             hierHead,
    RETURNINPARENTPTFRULE_ENUM	returnInParPtfRuleEn) 
{
    RET_CODE        ret = RET_SUCCEED;
    MemoryPool      mp;
 
    auto objLnkStp = mp.allocDynst(FILEINFO, A_ObjectLnk);

    if (GET_DICT(domainPtr, A_Domain_SavedDimEntityDictId) == ListCst ||
        GET_DICT(domainPtr, A_Domain_SavedDimEntityDictId) == QuickSearchCst)
    {
        SET_DICT(objLnkStp, A_ObjectLnk_FromEntDictId, ListCst);
    }
    else if (GET_DICT(domainPtr, A_Domain_SavedDimPtfDictId) == ThirdCst)
    {
        SET_DICT(objLnkStp, A_ObjectLnk_FromEntDictId, ThirdCst);
    }
 
    COPY_DYNFLD(objLnkStp, A_ObjectLnk, A_ObjectLnk_BeginDate,
        domainPtr, A_Domain, A_Domain_InterpFromDate);
    COPY_DYNFLD(objLnkStp, A_ObjectLnk, A_ObjectLnk_EndDate,
        domainPtr, A_Domain, A_Domain_InterpTillDate);
 
    if (GET_DICT(domainPtr, A_Domain_DimEntityDictId) == QuickSearchCst)
    {
        DBA_DYNFLD_STP* ptfTab = nullptr;
        int ptfNbr = 0;

        if ((ret = DBA_ExtractHierEltRecWithFilterSt(hierHead, A_Ptf, FALSE,
            FIN_FilterDummyPtf, NULL, NULLFCT, &ptfNbr, &ptfTab)) != RET_SUCCEED ||
            ptfNbr <= 0)
        {
            return(ret);
        }
        mp.owner(ptfTab);
        COPY_DYNFLD(objLnkStp, A_ObjectLnk,A_ObjectLnk_FromObjectId, ptfTab[0],A_Ptf, A_Ptf_Id);
    }
    else
    {
        COPY_DYNFLD(objLnkStp, A_ObjectLnk, A_ObjectLnk_FromObjectId,
            domainPtr, A_Domain, A_Domain_PtfObjId);
    }

    /* insert object link in hierarchy */
    ret = DBA_AddHierRecord(hierHead, objLnkStp, A_ObjectLnk, FALSE, HierAddRec_ForceInsert);
    if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
    {
        mp.remove(objLnkStp);
    }

    /* WEALTH-17471 - Lalby - 0602025 - create object links for the dummy ptf */
    auto objLnkForDymmyPtf = mp.allocDynst(FILEINFO, A_ObjectLnk);
    SET_DICT(objLnkForDymmyPtf, A_ObjectLnk_FromEntDictId, PtfCst);

    COPY_DYNFLD(objLnkForDymmyPtf, A_ObjectLnk, A_ObjectLnk_BeginDate,
        domainPtr, A_Domain, A_Domain_InterpFromDate);
    COPY_DYNFLD(objLnkForDymmyPtf, A_ObjectLnk, A_ObjectLnk_EndDate,
        domainPtr, A_Domain, A_Domain_InterpTillDate);

    DBA_DYNFLD_STP* ptfTab = nullptr;
    int ptfNbr = 0;

    if ((ret = DBA_ExtractHierEltRecWithFilterSt(hierHead, A_Ptf, FALSE,
        FIN_FilterDummyPtf, NULL, NULLFCT, &ptfNbr, &ptfTab)) != RET_SUCCEED ||
        ptfNbr <= 0)
    {
        return(ret);
    }
    mp.owner(ptfTab);
    COPY_DYNFLD(objLnkForDymmyPtf, A_ObjectLnk, A_ObjectLnk_FromObjectId, ptfTab[0], A_Ptf, A_Ptf_Id);
   
    ret = DBA_AddHierRecord(hierHead, objLnkForDymmyPtf, A_ObjectLnk, FALSE, HierAddRec_ForceInsert);
    if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
    {
        mp.remove(objLnkForDymmyPtf);
    }

    return(ret);
}

/************************************************************************
**  Function             : DBA_UpdateObjectLnkForRiskFree()
**
**  Description          : Select the default riskfree instrument to use in analysis phase.
**                         Update object links.
**
**  Arguments            : domainPtr    : pointer on domain of financial function
**                         hierHead     : pointer on hierarchy
**                         allocConn    : the connection number allocated
**
**  Return               : RET_SUCCEED              : if no problem was detected
**                         a RET_CODE               : if a message has been received
**
**  Creation Date        : 020919 - DDV - REF7758
**  Last Modification    :
*************************************************************************/
RET_CODE DBA_UpdateObjectLnkForRiskFree(DBA_DYNFLD_STP    domainPtr,
                                        DBA_HIER_HEAD_STP hierHead)
{
    DICT_T          instrDictId;
    DBA_DYNFLD_STP  objLnk=NULLDYNST;
    DBA_DYNFLD_STP  *objLnkTab=NULLDYNSTPTR;
    int             objLnkNbr, i;
    RET_CODE        ret=RET_SUCCEED;
    DATETIME_T     fromDate;
    DATETIME_T     tillDate;
	DBA_DYNFLD_STP  *newObjLnkTab=NULLDYNSTPTR; /* PMSTA06787 - LJE - 080506 */

    DBA_GetDictId(Instr, &instrDictId);

    /* REF9264 - LJE - 030805 : Object link always valid */
    fromDate.date = SYB_BEGIN_DATE;
    fromDate.time = 0;

    tillDate.date = MAGIC_END_DATE;
    tillDate.time = 0;


/* a new field must be created in domain (A_Domain_ForceRiskFeeFlg) to manage the defaut risk free instrument
    if (GET_FLAG(domainPtr, A_Domain_ForceRiskFeeFlg) == FALSE)
    {
        Extract all object Links
        Load Domain DV
        Extract all records and get its default risk free
        Update Object links
    }
    else
*/
    {
        if (IS_NULLFLD(domainPtr, A_Domain_RiskFreeInstrId) == FALSE)
        {
            /* extract all objectLinks order by object id */
   	        if ((ret = DBA_ExtractHierEltRec(hierHead, A_ObjectLnk,
			                                 FALSE, NULL, FIN_CmpObjectLnkFromObjectId,
                                             &objLnkNbr, &objLnkTab)) != RET_SUCCEED)
	        {
		        return(ret);
	        }

			/* PMSTA06311 - LJE - 080506 : Create new object link for all risk free */
			if (objLnkNbr > 0)
			{
				if ((newObjLnkTab = (DBA_DYNFLD_STP *) CALLOC(objLnkNbr, sizeof(DBA_DYNFLD_STP))) == NULL)
				{
					FREE(objLnkTab);
					MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
					return(RET_MEM_ERR_ALLOC);
				}

				for (i=0; i < objLnkNbr; i++)
				{
					newObjLnkTab[i] = ALLOC_DYNST(A_ObjectLnk);
					objLnk = newObjLnkTab[i];

					COPY_DYNST(objLnk, objLnkTab[i], A_ObjectLnk);

					SET_NULL_ID(objLnk, A_ObjectLnk_Id); /* PMSTA07393 - LJE - 090105 */

					SET_ENUM(objLnk, A_ObjectLnk_Nature, ObjectLnkNat_RiskFree);
					SET_INT(objLnk, A_ObjectLnk_Rank, 1); /* PMSTA50244 - MKK - 230123 */
					SET_DICT(objLnk, A_ObjectLnk_ToEntDictId, instrDictId);
					SET_ID(objLnk, A_ObjectLnk_ToObjectId, GET_ID(domainPtr, A_Domain_RiskFreeInstrId));
					SET_DATETIME(objLnk, A_ObjectLnk_BeginDate, fromDate);
					SET_DATETIME(objLnk, A_ObjectLnk_EndDate, tillDate);
				}

				/* PMSTA06311 - LJE - 080506 */
				/* insert all object link in hierarchy */
				ret = DBA_AddHierRecordList(hierHead,
											newObjLnkTab,
											objLnkNbr,
											A_ObjectLnk,
											FALSE);

				FREE(objLnkTab);
				FREE(newObjLnkTab);
			}
		}
    }
    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   DBA_CmpStratLinkByPtfDt()
**
**  Description :   strategy links are sorted by portfolio and date
**
**  Arguments   :   ptr1   pointer on dynamic structure type A_Strat
**                  ptr2   pointer on dynamic structure type A_Strat
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation D. : PMSTA09979 - LJE - 100721
**  Last modif. :
**
*************************************************************************/
STATIC int DBA_CmpStratLinkByPtfDt(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    int cmp;

    if ((cmp = CMP_DYNFLD(*ptr1, *ptr2, S_StratLnk_PtfId, S_StratLnk_PtfId, IdType)) != 0)
        return(cmp);

    /* Sort by begin_d (descending) */
    if ((cmp = CMP_DYNFLD(*ptr2, *ptr1, S_StratLnk_BegDate, S_StratLnk_BegDate, DateType)) != 0)
        return(cmp);

    return(cmp);
}

/************************************************************************
**
**  Function    :   DBA_CmpStratLinkByDt()
**
**  Description :   strategy links are sorted by begin date
**
**  Arguments   :   ptr1   pointer on dynamic structure type A_Strat
**                  ptr2   pointer on dynamic structure type A_Strat
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation D. : PMSTA-23226 - LJE - 160520
**  Last modif. :
**
*************************************************************************/
STATIC int DBA_CmpStratLinkByDt(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    int cmp;

    /* Sort by begin_d (descending) */
    if ((cmp = CMP_DYNFLD(*ptr1, *ptr2, S_StratLnk_BegDate, S_StratLnk_BegDate, DateType)) != 0)
        return(cmp);

    if ((cmp = CMP_DYNFLD(*ptr1, *ptr2, S_StratLnk_PtfId, S_StratLnk_PtfId, IdType)) != 0)
        return(cmp);

    return(cmp);
}

/************************************************************************
**
**  Function    :   DBA_CmpPtfByCd()
**
**  Description :   portfolio are sorted by A_Ptf_Cd
**
**  Arguments   :   ptr1   pointer on dynamic structure type A_Ptf
**                  ptr2   pointer on dynamic structure type A_Ptf
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation D. :   PMSTA-35396 - LJE - 190403
**  Last modif. :
**
*************************************************************************/
STATIC int DBA_CmpPtfByCd(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    return (strcmp(GET_CODE(*ptr1, A_Ptf_Cd), GET_CODE(*ptr2, A_Ptf_Cd)));
}

/************************************************************************
**  Function             : DBA_UpdateObjectLnkForBenchmark()
**
**  Description          : Select the default benchmarks to use in analysis phase.
**                         Update or create object links for benchmark.
**                         Insert in temp table #vector_id all new objects
**
**  Arguments            : domainPtr    : pointer on domain of financial function
**                         hierHead     : pointer on hierarchy
**                         allocConn    : the connection number allocated
**
**  Return               : RET_SUCCEED              : if no problem was detected
**                         a RET_CODE               : if a message has been received
**
**  Creation Date        : 020919 - DDV - REF7758
**  Last Modification    :
*************************************************************************/
EXTERN RET_CODE DBA_UpdateObjectLnkForBench(DBA_DYNFLD_STP    domainPtr,
                                            DBA_HIER_HEAD_STP hierHead)
{
  	OBJECT_ENUM     ptfDim=NullEntity;
    DBA_DYNFLD_STP  *sStratLnkTab=NULLDYNSTPTR;
    DBA_DYNFLD_STP  *objLnkTab=NULLDYNSTPTR;
    DBA_DYNFLD_STP  *newObjLnkTab=NULLDYNSTPTR;
    DBA_DYNFLD_STP  objLnk=NULLDYNST;
    DBA_DYNFLD_STP  *objTab=NULLDYNSTPTR, *ptfTab=NULL;
    int             sStratLnkNbr=0, j, objLnkNbr, objLnkPos=0, ptfNbr=0,
                    objNbr, newObjLnkPos=0;
    RET_CODE        ret=RET_SUCCEED;
    DICT_T          stratDictId, instrDictId, ptfDictId;
    ID_T            prevObjId, currPtfId=0;
    DATETIME_T     fromDate;
    DATETIME_T     tillDate;
    MemoryPool      mp;

	/* PMSTA08156 - LJE - 090422 */
	int             allocNewObjLnkNbr=0;

	/* PMSTA08284 - LJE - 090605 */
	FLAG_T                      useHierBehaviorFlg=GET_FLAG(domainPtr, A_Domain_LoadHierFlg)>LoadHierPtf_None;
	RETURNINPARENTPTFRULE_ENUM	returnInParPtfRuleEn=ReturnInParentPtfRule_Children;

    DBA_GetDictId(Strat, &stratDictId);
    DBA_GetDictId(Instr, &instrDictId);
    DBA_GetDictId(Ptf, &ptfDictId);

    /* REF9264 - LJE - 030805 : If forced, object link always valid */
    fromDate = GET_DATETIME(domainPtr, A_Domain_CalcRefDate);
    tillDate = GET_DATETIME(domainPtr, A_Domain_InterpTillDate);

   if (GET_FLAG(domainPtr, A_Domain_ForceLnkFlg) == FALSE)
    {
        /* extract all ObjectLink unused (objectLnk without Nature) Order by object id */
   	    if ((ret = DBA_ExtractHierEltRec(hierHead, A_ObjectLnk, FALSE,
                                         FIN_FilterUnusedObjectLnk, FIN_CmpObjectLnkFromObjectId,
                                         &objLnkNbr, &objLnkTab)) != RET_SUCCEED)
        {
            return(ret);
        }

        mp.ownerPtr(objLnkTab);

    	DBA_GetObjectEnum(GET_DICT(domainPtr, A_Domain_DimPtfDictId), &ptfDim);

        /* select all strategy link existing */
	    switch(GET_OBJECT_CST(ptfDim)) /* REF8844 - LJE - 030416 */
	    {
			case ThirdCst: /* PMSTA-11986 - LJE - 110428 */
	        case PtfCst:
                /* Select best strategy link for all portfolios */
                if ((ret = DBA_SelectStratLnkByPtf(domainPtr, hierHead, ExpandStrat_IP, &sStratLnkTab, &sStratLnkNbr)) != RET_SUCCEED) /* REF9187 - LJE - 030630 */
                {
                    return(ret);
                }

                mp.ownerDynStpTab(sStratLnkTab,sStratLnkNbr);

				/* PMSTA08284 - LJE - 090605 */
				if (useHierBehaviorFlg == TRUE)
				{
					if (GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) == PtfConsRule_DetailedChildren) 
					{
						useHierBehaviorFlg = FALSE;
					}
					else if (static_cast<LOADHIERPTF_ENUM> GET_ENUM(domainPtr, A_Domain_LoadHierFlg) != LoadHierPtf_IntermediateHierarchy)
					{
						GEN_GetApplInfo(ApplReturnInParentPtfRule, &returnInParPtfRuleEn);

                        if (returnInParPtfRuleEn == ReturnInParentPtfRule_Parent) /* PMSTA-24511 - LJE - 161206 */
						{
							useHierBehaviorFlg = FALSE;
						}
					}
				}

                /* PMSTA01113 - LJE - 061207 : copy first child link to the parent if needed */
                if (useHierBehaviorFlg == TRUE) /* PMSTA08284 - LJE - 090605 */
                {
                    /* Extract all ptf */
   	                if ((ret = DBA_ExtractHierEltRec(hierHead, A_Ptf, FALSE,
                                                     NULL, DBA_CmpPtfByCd,                  /* PMSTA-35396 - LJE - 190403 */
                                                     &ptfNbr, &ptfTab)) != RET_SUCCEED)
                    {
                        return(ret);
                    }

                    mp.ownerPtr(ptfTab);

                    /* PMSTA-23226 - LJE - 160520 */
                    TLS_Sort((char *)sStratLnkTab, sStratLnkNbr, sizeof(DBA_DYNFLD_STP),
                             (TLS_CMPFCT *)DBA_CmpStratLinkByDt, (PTR **)NULL, SortRtnTp_None);

                    for (int i = 0; i<ptfNbr; i++)
                    {
                        if (IS_NULLFLD(ptfTab[i], A_Ptf_HierPortId) == FALSE)
                        {
                            /* Search if the parent have strategy link */
                            for (j=0; j<sStratLnkNbr; j++)
                            {
                                if (GET_ID(ptfTab[i], A_Ptf_HierPortId) ==
                                     GET_ID(sStratLnkTab[j], S_StratLnk_PtfId))
                                {
                                    break;
                                }
                            }

                            if (j>=sStratLnkNbr)
                            {
                                /* Copy strategy link */
                                for (j=0; j<sStratLnkNbr; j++)
                                {
                                    if (GET_ID(ptfTab[i], A_Ptf_Id) ==
                                         GET_ID(sStratLnkTab[j], S_StratLnk_PtfId))
                                    {
                                        sStratLnkNbr++;
                                        sStratLnkTab = (DBA_DYNFLD_STP *) mp.realloc(sStratLnkTab, sStratLnkNbr*sizeof(DBA_DYNFLD_STP));
                                        sStratLnkTab[sStratLnkNbr-1] = mp.allocDynst(FILEINFO,S_StratLnk);

                                        COPY_DYNST(sStratLnkTab[sStratLnkNbr-1], sStratLnkTab[j], S_StratLnk);
                                        SET_ID(sStratLnkTab[sStratLnkNbr-1], S_StratLnk_PtfId, GET_ID(ptfTab[i], A_Ptf_HierPortId));
                                        SET_ID(sStratLnkTab[sStratLnkNbr-1], S_StratLnk_ObjId, GET_ID(ptfTab[i], A_Ptf_HierPortId));
                                        SET_ID(sStratLnkTab[sStratLnkNbr-1], S_StratLnk_FromObjId, GET_ID(ptfTab[i], A_Ptf_HierPortId));
                                        SET_NULL_CODE(sStratLnkTab[sStratLnkNbr-1], S_StratLnk_ObjCd);
                                        SET_NULL_CODE(sStratLnkTab[sStratLnkNbr-1], S_StratLnk_PtfCd);
                                        SET_NULL_CODE(sStratLnkTab[sStratLnkNbr-1], S_StratLnk_ToEntCd);
                                    }
                                }
                            }
                        }
                    }
                }

                /* PMSTA09979 - LJE - 100721 */
                TLS_Sort((char *) sStratLnkTab, sStratLnkNbr, sizeof(DBA_DYNFLD_STP),
    			         (TLS_CMPFCT *) DBA_CmpStratLinkByPtfDt, (PTR **) NULL, SortRtnTp_None);

                /* PMSTA01113 - LJE - 061208 : loop by object links */
                for (objLnkPos = 0; objLnkPos < objLnkNbr; objLnkPos++)
                {
                    currPtfId = GET_ID(objLnkTab[objLnkPos], A_ObjectLnk_FromObjectId);

                    /* PMSTA-55400 - DDV - 250220 - Copy given object link to use it later to fill holes */
                    DBA_DYNFLD_STP objLnkCopy = mp.allocDynst(FILEINFO, A_ObjectLnk);
                    COPY_DYNST(objLnkCopy, objLnkTab[objLnkPos], A_ObjectLnk);
                    SET_NULL_ID(objLnkCopy, A_ObjectLnk_Id);

                    if (useHierBehaviorFlg == TRUE) /* PMSTA08284 - LJE - 090605 */
                    {
                        for (j = 0; j < ptfNbr; j++)
                        {
                            if (currPtfId == GET_ID(ptfTab[j], A_Ptf_Id))
                    {
                                break;
                            }
                        }

                        if (j < ptfNbr &&
                            IS_NULLFLD(ptfTab[j], A_Ptf_HierPortId) == FALSE)
                        {
                            currPtfId = GET_ID(ptfTab[j], A_Ptf_HierPortId); /* Get the parent */
                        }
                    }

                    objLnk = objLnkTab[objLnkPos];
                    DatePeriod objLnkDates(GET_DATETIME(objLnkTab[objLnkPos], A_ObjectLnk_BeginDate), GET_DATETIME(objLnkTab[objLnkPos], A_ObjectLnk_EndDate)); /* WEALTH-14260 - DDV - 241112 - Initialisation move here to keep original object link dates. */

                    int stratLnkPos = 0;
                    /* PMSTA-10640 - LJE - 101025 - Search the current ptf strat link */
                    while (stratLnkPos < sStratLnkNbr && GET_ID(sStratLnkTab[stratLnkPos], S_StratLnk_PtfId) != currPtfId)
                    {
                        stratLnkPos++;
                    }

                    DatePeriodSet     periodSet;

                    /* Update or create object link for each strategy link */ /* PMSTA-55400 - DDV - 250220 - Refactoring of this loop */
                    for (;stratLnkPos < sStratLnkNbr && GET_ID(sStratLnkTab[stratLnkPos], S_StratLnk_PtfId) == currPtfId; ++stratLnkPos)
                    {
                        /* PMSTA09843 - LJE - 100716 - Keep only one benchmark if no perf attrib */
                        if ((GET_ENUM(domainPtr, A_Domain_ReturnAnalysisEn) != PAARetAnalysis_All &&
                             GET_ENUM(domainPtr, A_Domain_ReturnAnalysisEn) != PAARetAnalysis_PA  &&
                             GET_INT(sStratLnkTab[stratLnkPos], S_StratLnk_Rank) != 1))/* PMSTA49957 - VSW - 160822 */
                        {
                            continue;
                        }

                        /* WEALTH-7310 -JBC - 20240520 - skip out of range strat for objLnk due to comp periods */
                        if(objLnkDates.cmpBegin(GET_DATE(sStratLnkTab[stratLnkPos], S_StratLnk_EndDate)) >= 0
                            || objLnkDates.cmpEnd(GET_DATE(sStratLnkTab[stratLnkPos], S_StratLnk_BegDate)) <= 0)
                        {
                            continue;
                        }

                        if (objLnk == NULLDYNST)
                        {
						    /* PMSTA08156 - LJE - 090422 : Modify allocation to avoid crash */
						    if (allocNewObjLnkNbr <= newObjLnkPos)
						    {
							    allocNewObjLnkNbr += 10;
							    newObjLnkTab = (DBA_DYNFLD_STP *) mp.realloc(newObjLnkTab, allocNewObjLnkNbr * sizeof(DBA_DYNFLD_STP));
						    }

                            /* alloc a new ObjectLink and fill it */
                            objLnk = newObjLnkTab[newObjLnkPos] = mp.allocDynst(FILEINFO,A_ObjectLnk);
                            newObjLnkPos++;
                        }

                        fromDate = GET_DATETIME(sStratLnkTab[stratLnkPos], S_StratLnk_BegDate);
                        tillDate = GET_DATETIME(sStratLnkTab[stratLnkPos], S_StratLnk_EndDate);

                        SET_DICT(objLnk, A_ObjectLnk_FromEntDictId, ptfDictId);
                        SET_ID(objLnk, A_ObjectLnk_FromObjectId, GET_ID(objLnkTab[objLnkPos], A_ObjectLnk_FromObjectId));
                        SET_ENUM(objLnk,     A_ObjectLnk_Nature,      ObjectLnkNat_Bench);
                        SET_INT(objLnk,		 A_ObjectLnk_Rank,        GET_INT(sStratLnkTab[stratLnkPos], S_StratLnk_Rank)); /* REF9340 - LJE - 031121 */ /* PMSTA50244 - MKK - 230123 */
                        SET_DICT(objLnk,     A_ObjectLnk_ToEntDictId, GET_DICT(sStratLnkTab[stratLnkPos],     S_StratLnk_ToEntDictId)); /* REF9187 - LJE - 030625 */
                        SET_ID(objLnk,       A_ObjectLnk_ToObjectId,  GET_ID(sStratLnkTab[stratLnkPos],       S_StratLnk_ToObjId)); /* REF9187 - LJE - 030625 */

                        SET_DATETIME(objLnk, A_ObjectLnk_BeginDate,   fromDate); /* REF9187 - LJE - 030625 */
                        SET_DATETIME(objLnk, A_ObjectLnk_EndDate,     tillDate); /* REF9187 - LJE - 030625 */

                        /* PMSTA-55400 - DDV - 250220 - Put all strategy links periods into a set */
                        periodSet.insert(fromDate, tillDate);
                        objLnk = NULL;
                    }

                    /* PMSTA-55400 - DDV - 250311 - Fix overflow */
                    if (periodSet.size() > 0)
                    {
                        /* PMSTA-55400 - DDV - 250220  - Merge all periods and fill hole with default object link */
                        periodSet.mergePeriods();

                        DatePeriod  previousPeriod = *(periodSet.begin());
                        for (auto it = periodSet.begin(); it != periodSet.end(); ++it)
                        {
                            DATE_T     beginDate = 0;
                            DATE_T     endDate = 0;

                            if (it == periodSet.begin())
                            {
                                if ((*it).getBegin().date > GET_DATE(objLnkCopy, A_ObjectLnk_BeginDate))
                                {
                                    beginDate = GET_DATE(objLnkCopy, A_ObjectLnk_BeginDate);
                                    endDate = (*it).getBegin().date;
                                }
                            }
                            else
                            {
                                if (previousPeriod.getEnd() < (*it).getBegin())
                                {
                                    beginDate = previousPeriod.getEnd().date;
                                    endDate = (*it).getBegin().date;
                                }
                            }
                            previousPeriod = *it;

                            if (beginDate != 0 && endDate != 0)
                            {
                                if (allocNewObjLnkNbr <= newObjLnkPos)
                                {
                                    allocNewObjLnkNbr += 10;
                                    newObjLnkTab = (DBA_DYNFLD_STP*)mp.realloc(newObjLnkTab, allocNewObjLnkNbr * sizeof(DBA_DYNFLD_STP));
                                }

                                /* alloc a new ObjectLink and fill it */
                                DBA_DYNFLD_STP tmpObjLnk = newObjLnkTab[newObjLnkPos] = mp.allocDynst(FILEINFO, A_ObjectLnk);
                                newObjLnkPos++;

                                COPY_DYNST(tmpObjLnk, objLnkCopy, A_ObjectLnk);
                                SET_NULL_ID(tmpObjLnk, A_ObjectLnk_Id);
                                SET_DATETIME(tmpObjLnk, A_ObjectLnk_BeginDate, beginDate);
                                SET_DATETIME(tmpObjLnk, A_ObjectLnk_EndDate, endDate);

                            }
                        }

                        if (previousPeriod.getEnd().date < GET_DATE(objLnkCopy, A_ObjectLnk_EndDate))
                        {
                            if (allocNewObjLnkNbr <= newObjLnkPos)
                            {
                                allocNewObjLnkNbr += 10;
                                newObjLnkTab = (DBA_DYNFLD_STP*)mp.realloc(newObjLnkTab, allocNewObjLnkNbr * sizeof(DBA_DYNFLD_STP));
                            }

                            /* alloc a new ObjectLink and fill it */
                            DBA_DYNFLD_STP tmpObjLnk = newObjLnkTab[newObjLnkPos] = mp.allocDynst(FILEINFO, A_ObjectLnk);
                            newObjLnkPos++;

                            COPY_DYNST(tmpObjLnk, objLnkCopy, A_ObjectLnk);
                            SET_NULL_ID(tmpObjLnk, A_ObjectLnk_Id);
                            SET_DATETIME(tmpObjLnk, A_ObjectLnk_BeginDate, previousPeriod.getEnd().date);
                            SET_DATETIME(tmpObjLnk, A_ObjectLnk_EndDate, GET_DATE(objLnkCopy, A_ObjectLnk_EndDate));
                        }
                    }
                }
		        break;

            case StratCst:
                /* extract all strategies (order by id) and update or create ObjectLnk using Becnhentiy and BenchObjId*/
   	            if ((ret = DBA_ExtractHierEltRec(hierHead, A_Strat, FALSE,
                                                 DBA_FilterStratWithBench, DBA_CmpStratId,
                                                 &objNbr, &objTab)) != RET_SUCCEED)
                {
                    return(ret);
                }

                mp.ownerPtr(objTab);

                if (objNbr > objLnkNbr)
                {
                    newObjLnkTab = (DBA_DYNFLD_STP *) mp.calloc(objNbr-objLnkNbr, sizeof(DBA_DYNFLD_STP));
                }

                /* Update or create object link for each benchmark found in strategy */
                for (int i=0; i<objNbr; i++)
                {
                    while (objLnkPos < objLnkNbr &&
                           GET_ID(objLnkTab[objLnkPos], A_ObjectLnk_FromObjectId) < GET_ID(objTab[i], A_Strat_Id))
                        objLnkPos++;

                    if (objLnkPos < objLnkNbr &&
                        GET_ID(objLnkTab[objLnkPos], A_ObjectLnk_FromObjectId) == GET_ID(objTab[i], A_Strat_Id))
                    {
                        objLnk=objLnkTab[objLnkPos];
                    }
                    else
                    {
                        /* alloc a new ObjectLink and fill it */
                        objLnk = newObjLnkTab[newObjLnkPos] = mp.allocDynst(FILEINFO,A_ObjectLnk);
                        newObjLnkPos++;

                        SET_DICT(objLnk, A_ObjectLnk_FromEntDictId, stratDictId);
                        SET_ID(objLnk, A_ObjectLnk_FromObjectId, GET_ID(objTab[i], A_Strat_Id));
                    }

                    SET_ENUM(objLnk, A_ObjectLnk_Nature, ObjectLnkNat_Bench);
                    SET_INT(objLnk, A_ObjectLnk_Rank, 1); /* PMSTA50244 - MKK - 230123 */
                    SET_DICT(objLnk, A_ObjectLnk_ToEntDictId, GET_DICT(objTab[i], A_Strat_BenchEntityDictId));
                    SET_ID(objLnk, A_ObjectLnk_ToObjectId, GET_ID(objTab[i], A_Strat_BenchObjId));
                    SET_DATETIME(objLnk, A_ObjectLnk_BeginDate, fromDate);
                    SET_DATETIME(objLnk, A_ObjectLnk_EndDate, tillDate);
                }

		        break;

            case InstrCst:
                /* extract all instruments (order by id) and update or create ObjectLnk using index instrument */
   	            if ((ret = DBA_ExtractHierEltRec(hierHead, A_Instr, FALSE,
                                                 DBA_FilterInstrWithIndex, DBA_CmpInstrId,
                                                 &objNbr, &objTab)) != RET_SUCCEED)
                {
                    return(ret);
                }

                mp.ownerPtr(objTab);

                if (objNbr > objLnkNbr)
                {
                    newObjLnkTab = (DBA_DYNFLD_STP *) mp.calloc(objNbr-objLnkNbr, sizeof(DBA_DYNFLD_STP));
                }

                /* Update or create object link for each index instrument found */
                for (int i=0; i<objNbr; i++)
                {
                    while (objLnkPos < objLnkNbr &&
                           GET_ID(objLnkTab[objLnkPos], A_ObjectLnk_FromObjectId) < GET_ID(objTab[i], A_Instr_Id))
                        objLnkPos++;

                    if (objLnkPos < objLnkNbr &&
                        GET_ID(objLnkTab[objLnkPos], A_ObjectLnk_FromObjectId) == GET_ID(objTab[i], A_Instr_Id))
                    {
                        objLnk=objLnkTab[objLnkPos];
                    }
                    else
                    {
                        /* alloc a new ObjectLink and fill it */
                        objLnk = newObjLnkTab[newObjLnkPos] = mp.allocDynst(FILEINFO,A_ObjectLnk);
                        newObjLnkPos++;

                        SET_DICT(objLnk, A_ObjectLnk_FromEntDictId, instrDictId);
                        SET_ID(objLnk, A_ObjectLnk_FromObjectId, GET_ID(objTab[i], A_Instr_Id));
                    }

                    SET_ENUM(objLnk, A_ObjectLnk_Nature, ObjectLnkNat_Bench);
                    SET_INT(objLnk, A_ObjectLnk_Rank, 1); /* PMSTA50244 - MKK - 230123 */
                    SET_DICT(objLnk, A_ObjectLnk_ToEntDictId, instrDictId);
                    SET_ID(objLnk, A_ObjectLnk_ToObjectId, GET_ID(objTab[i], A_Instr_IdxInstrId));
                    SET_DATETIME(objLnk, A_ObjectLnk_BeginDate, fromDate);
                    SET_DATETIME(objLnk, A_ObjectLnk_EndDate, tillDate);
                }

		        break;

	        default:
		        break;
        }

        /* WEALTH-5069-Lalby-27032024 - if all portfolios are in the same benchmark then use the same benchmark for the list link */
        if (static_cast<PTFCONSRULE_ENUM>GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) == PtfConsRule_MergedTWR_Detail)
        {
            bool isSameBenchMark = true;
            ID_T prevStrategyId = 0;
            int listObjIndex = -1;
            int dummyPtfIndx = -1;

            for (objLnkPos = 0; objLnkPos < objLnkNbr; objLnkPos++)
            {
                DICT_T dimEntityDictId = 0;
                ID_T dimPortDictId = 0;

                if (IS_NULLFLD(domainPtr, A_Domain_DimEntityDictId) == FALSE)
                {
                    dimEntityDictId = GET_DICT(domainPtr, A_Domain_DimEntityDictId);
                }
                if (IS_NULLFLD(domainPtr, A_Domain_DimPtfDictId) == FALSE)
                {
                    dimPortDictId = GET_ID(domainPtr, A_Domain_DimPtfDictId);
                }

                if (IS_NULLFLD(objLnkTab[objLnkPos], A_ObjectLnk_FromObjectId) == FALSE &&
                    (GET_DICT(objLnkTab[objLnkPos], A_ObjectLnk_FromEntDictId) == ListCst ||
                     GET_DICT(objLnkTab[objLnkPos], A_ObjectLnk_FromEntDictId) == ThirdCst))
                {
                    if (((dimEntityDictId == ListCst || (dimPortDictId == ThirdCst && dimEntityDictId == OneCst)) &&  /* WEALTH-3197-Lalby-03062024 */
                        GET_DICT(objLnkTab[objLnkPos], A_ObjectLnk_FromObjectId) == GET_ID(domainPtr, A_Domain_PtfObjId)) ||
                        (dimEntityDictId == QuickSearchCst && GET_ID(objLnkTab[objLnkPos], A_ObjectLnk_FromObjectId) < 0)) /*WEALTH-7472-Lalby-09052024*/
                    {
                        listObjIndex = objLnkPos;
                    }
                }
                else if (IS_NULLFLD(objLnkTab[objLnkPos], A_ObjectLnk_ToObjectId) == FALSE &&
                    IS_NULLFLD(objLnkTab[objLnkPos], A_ObjectLnk_ToEntDictId) == FALSE &&
                    GET_DICT(objLnkTab[objLnkPos], A_ObjectLnk_ToEntDictId) == stratDictId &&
                    (static_cast<OBJECTLNK_NAT_ENUM> GET_ENUM(objLnkTab[objLnkPos], A_ObjectLnk_Nature) == ObjectLnkNat_Bench))
                {
                    if ((prevStrategyId != GET_ID(objLnkTab[objLnkPos], A_ObjectLnk_ToObjectId)) && prevStrategyId > 0)
                    {
                        isSameBenchMark = false;
                        MSG_LogSrvMesg(UNUSED, 0, "Portfolios in the list are not in same benchmark.Please use the forced benchmark option.");
                        break;
                    }
                    prevStrategyId = GET_ID(objLnkTab[objLnkPos], A_ObjectLnk_ToObjectId);
                }
                if( GET_ID(objLnkTab[objLnkPos], A_ObjectLnk_FromObjectId) < 0)
                {
                    dummyPtfIndx = objLnkPos;
                }
            }

            if (isSameBenchMark == false)
            {
                MSG_LogSrvMesg(UNUSED, 0, "Processing without Benchmark..");
                for (objLnkPos = 0; objLnkPos < objLnkNbr; objLnkPos++)
                {
                    if (GET_DICT(objLnkTab[objLnkPos], A_ObjectLnk_ToEntDictId) == StratCst ||
                        GET_DICT(objLnkTab[objLnkPos], A_ObjectLnk_ToEntDictId) == GridCst )
                    {
                        SET_NULL_ID(objLnkTab[objLnkPos], A_ObjectLnk_ToEntDictId);
                        SET_NULL_ID(objLnkTab[objLnkPos], A_ObjectLnk_ToObjectId);
                    }
                }
            }
            else if (isSameBenchMark == true && prevStrategyId > 0 && listObjIndex >= 0)
            {
                DICT_T dimEntityDictId = 0;
                ID_T dimPortDictId = 0;

                if (GET_DICT(objLnkTab[listObjIndex], A_ObjectLnk_FromEntDictId) == ListCst ||
                    GET_DICT(objLnkTab[listObjIndex], A_ObjectLnk_FromEntDictId) == ThirdCst)
                {
                    if (IS_NULLFLD(domainPtr, A_Domain_DimEntityDictId) == FALSE)
                    {
                        dimEntityDictId = GET_DICT(domainPtr, A_Domain_DimEntityDictId);
                    }
                    if (IS_NULLFLD(domainPtr, A_Domain_DimPtfDictId) == FALSE)
                    {
                        dimPortDictId = GET_ID(domainPtr, A_Domain_DimPtfDictId);
                    }
                    if (((dimEntityDictId == ListCst || dimPortDictId == ThirdCst ) && /* WEALTH-3197-Lalby-03062024 */
                        GET_DICT(objLnkTab[listObjIndex], A_ObjectLnk_FromObjectId) == GET_ID(domainPtr, A_Domain_PtfObjId)) ||
                        (dimEntityDictId == QuickSearchCst && GET_DICT(objLnkTab[listObjIndex], A_ObjectLnk_FromObjectId) < 0))
                    {
                        SET_DICT(objLnkTab[listObjIndex], A_ObjectLnk_ToEntDictId, stratDictId);
                        SET_DICT(objLnkTab[listObjIndex], A_ObjectLnk_ToObjectId, prevStrategyId);
                        SET_ENUM(objLnkTab[listObjIndex], A_ObjectLnk_Nature, ObjectLnkNat_Bench);
                        SET_INT(objLnkTab[listObjIndex], A_ObjectLnk_Rank, 1);
                    }
                }
                /* WEALTH-17471 - Lalby - 0602025 - Create objct link for the dummyPtf */
                if(dummyPtfIndx >= 0 && GET_DICT(objLnkTab[dummyPtfIndx], A_ObjectLnk_FromObjectId) < 0)
                {
                    SET_DICT(objLnkTab[dummyPtfIndx], A_ObjectLnk_ToEntDictId, stratDictId);
                    SET_DICT(objLnkTab[dummyPtfIndx], A_ObjectLnk_ToObjectId, prevStrategyId);
                    SET_ENUM(objLnkTab[dummyPtfIndx], A_ObjectLnk_Nature, ObjectLnkNat_Bench);
                    SET_INT(objLnkTab[dummyPtfIndx], A_ObjectLnk_Rank, 1);
                }
            }
        }
    }
    else /* forced benchmark */
    {
        FIELD_IDX_T* objEnIdxTab[] = {&A_Domain_Bench1EntityDictId, &A_Domain_Bench2EntityDictId, &A_Domain_Bench3EntityDictId},
                   * objIdIdxTab[] = {&A_Domain_Bench1ObjectId,     &A_Domain_Bench2ObjectId,     &A_Domain_Bench3ObjectId};

        /* extract all ObjectLink Order by object id */
   	    if ((ret = DBA_ExtractHierEltRec(hierHead, A_ObjectLnk, FALSE,
                                         NULLFCT, FIN_CmpObjectLnkFromObjectId,
                                         &objLnkNbr, &objLnkTab)) != RET_SUCCEED)
        {
            return(ret);
        }

        mp.ownerPtr(objLnkTab);

        DatePeriodVec compPeriods;

        for (int i=0; i<3; i++)  /* Bench mark setting */
        {
            if (IS_NULLFLD(domainPtr, *(objEnIdxTab[i])) == FALSE &&  /* REF8844 - LJE - 030410 */
                IS_NULLFLD(domainPtr, *(objIdIdxTab[i])) == FALSE) /* REF8844 - LJE - 030410 */
            {
                /* Update or create a object link for each object */
                for (j=0, prevObjId=0; j<objLnkNbr; j++)
                {
                    /* is it a new object ? */
                    if (prevObjId != GET_ID(objLnkTab[j], A_ObjectLnk_FromObjectId))
                    {
                        if (GET_DICT(objLnkTab[j], A_ObjectLnk_FromEntDictId) == ptfDictId &&
                            (PTFCONSRULE_ENUM)GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) != PtfConsRule_MergedTWR &&
                            GET_ID(objLnkTab[j], A_ObjectLnk_FromObjectId) > 0)
                            /*PMSTA-38173-ARUN-10122019- Virtual Ptf is used for merged TWR and the below if block should not be run for virtual ptf*/
                        {
                            /*PMSTA-27728-NRAO-190211*/
                            CODE_T ptfCode;
                            fromDate.date = GET_DATE(domainPtr, A_Domain_CalcRefDate);
                            tillDate.date = GET_DATE(domainPtr, A_Domain_InterpTillDate);

                            
                            if ((ret = DBA_UseCompPeriodsForStratLnk(domainPtr, hierHead, GET_ID(objLnkTab[j], A_ObjectLnk_FromObjectId), &fromDate, &tillDate, &ptfCode
                                                                        ,compPeriods)) != RET_SUCCEED)
                            {
                                MSG_LogSrvMesg(ret, UNUSED, "Failed to find valid Portfolio Computation Dates in Storage/Analysis for : %1.",
                                               CodeType, ptfCode);
                                continue;
                            }
                        }
                        else
                        {
                            compPeriods.push_back(fromDate, tillDate);
                        }

                        /* first time, it can be a update */
                        bool skipFirst = false;
                        if (i==0)
                        {
                            /* if link is unused, use it (it is a update) */
	                        if (IS_NULLFLD(objLnkTab[j], A_ObjectLnk_Nature) == TRUE ||
                                GET_ENUM(objLnkTab[j], A_ObjectLnk_Nature) == (ENUM_T) ObjectLnkNat_None)
                            {
                                objLnk=objLnkTab[j];
                                SET_ENUM(objLnk, A_ObjectLnk_Nature, ObjectLnkNat_Bench);
                                SET_INT(objLnk, A_ObjectLnk_Rank,(i+1)); /* PMSTA50244 - MKK - 230123 */
                                SET_DICT(objLnk, A_ObjectLnk_ToEntDictId, GET_DICT(domainPtr, *(objEnIdxTab[i]))); /* REF8844 - LJE - 030410 */
                                SET_ID(objLnk, A_ObjectLnk_ToObjectId, GET_ID(domainPtr, *(objIdIdxTab[i])));
                                SET_DATETIME(objLnk, A_ObjectLnk_BeginDate, compPeriods[0].getBegin());
                                SET_DATETIME(objLnk, A_ObjectLnk_EndDate, compPeriods[0].getEnd());
                                skipFirst = true;
                                if(compPeriods.size() == 1)
                                {
                                    continue;
                                }
                            }
                        }

						/* PMSTA08156 - LJE - 090422 : Modify allocation to avoid crash */
						if (allocNewObjLnkNbr <= newObjLnkPos + static_cast<int>(compPeriods.size()-1))
						{
							allocNewObjLnkNbr += 10;
							newObjLnkTab = (DBA_DYNFLD_STP *) mp.realloc(newObjLnkTab, allocNewObjLnkNbr * sizeof(DBA_DYNFLD_STP));
						}

                        for(size_t perIdx=0;perIdx<compPeriods.size();perIdx++)
                        {
                            if(skipFirst)
                            {
                               skipFirst = false;
                               continue;
                            }

                            /* create a new ObjectLnk */
                            objLnk = newObjLnkTab[newObjLnkPos] = mp.allocDynst(FILEINFO,A_ObjectLnk);
                            newObjLnkPos++;

                            SET_DICT(objLnk, A_ObjectLnk_FromEntDictId, GET_DICT(objLnkTab[j], A_ObjectLnk_FromEntDictId));
                            SET_ID(objLnk, A_ObjectLnk_FromObjectId, GET_ID(objLnkTab[j], A_ObjectLnk_FromObjectId));
                            SET_ENUM(objLnk, A_ObjectLnk_Nature, ObjectLnkNat_Bench);
                            SET_INT(objLnk, A_ObjectLnk_Rank,(i+1)); /* PMSTA50244 - MKK - 230123 */
                            SET_DICT(objLnk, A_ObjectLnk_ToEntDictId, GET_DICT(domainPtr, *(objEnIdxTab[i]))); /* REF8844 - LJE - 030410 */
                            SET_ID(objLnk, A_ObjectLnk_ToObjectId, GET_ID(domainPtr, *(objIdIdxTab[i])));
                            SET_DATETIME(objLnk, A_ObjectLnk_BeginDate, compPeriods[perIdx].getBegin());
                            SET_DATETIME(objLnk, A_ObjectLnk_EndDate, compPeriods[perIdx].getEnd());
                        }                       
                    }

                    prevObjId = GET_ID(objLnkTab[j], A_ObjectLnk_FromObjectId);
                }
            }
        }
    }

    /* insert all object link in hierarchy */
    if((ret = DBA_AddHierRecordList(hierHead,
                                newObjLnkTab,
                                newObjLnkPos,
                                A_ObjectLnk,
                                FALSE)) == RET_SUCCEED)
    {
        for(int k=0;k<newObjLnkPos;k++)
        {
            mp.removeDynStp(newObjLnkTab[k]);
        }        
    }

    return(RET_SUCCEED);
}

/************************************************************************
**  Function             : DBA_SelectStratLnkByPtf()
**
**  Description          : Select all strategy links for portfolios stored in #dom_port.
**                         and keep only the three best.
**
**  Arguments            : domainPtr    : pointer on domain of financial function
**                         stratLnkTab  : pointer on array to be filled with strategy links
**                         stratLnkNbr  : pointer on the number of strategy link returned
**
**  Return               : RET_SUCCEED              : if no problem was detected
**                         a RET_CODE               : if a message has been received
**
**  Creation Date        : 020919 - DDV - REF7758
**  Last Modification    :
*************************************************************************/
RET_CODE DBA_SelectStratLnkByPtf(DBA_DYNFLD_STP    domainPtr,
                                 DBA_HIER_HEAD_STP hierHead,
                                 EXPANDSTRAT_ENUM  expandStratEn,
                                 DBA_DYNFLD_STP   **sStratLnkTab,
                                 int               *sStratLnkNbr)
{
    RET_CODE       ret = RET_SUCCEED;
    DBA_DYNFLD_STP searchLnkSt = NULLDYNST;
    DBA_DYNFLD_STP *fromObjectLnkTab=NULLDYNSTPTR;
    int            fromObjectLnkNbr,i;
    DICT_T         ptfDictId, emptyDictId;
    int            maxBenchLoading=0; /* REF9187 - LJE - 030630 */
    DATETIME_T     tmpFromDate;       /* REF9264 - LJE - 031013 */

    DBA_GetDictId(Ptf, &ptfDictId);
    DBA_GetDictId(Empty, &emptyDictId);

    DbiConnectionHelper connHelper;

    if (connHelper.isValidAndInit() == false)
    {
        MSG_SendMesg(RET_DBA_ERR_NOFREESYNCCONN, 0, FILEINFO);
        return(DBA_CONN_NOT_FOUND);
    }

    /* Allocate a A_SearchLnk dynamic structure */
    if ((searchLnkSt = ALLOC_DYNST(A_SearchLnk)) == NULLDYNST)
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "A_SearchLnk");
        return(RET_MEM_ERR_ALLOC);
    }

    /* Fill Searchlink dynamic structure */
    /* Ptf Dimension */
    COPY_DYNFLD(searchLnkSt, A_SearchLnk, A_SearchLnk_DimPortDictId,
                domainPtr, A_Domain, A_Domain_DimEntityDictId);
    /* Ptf Obj Id */
    COPY_DYNFLD(searchLnkSt, A_SearchLnk, A_SearchLnk_PortObjId,
                domainPtr, A_Domain, A_Domain_PtfObjId);

    SET_NULL_DICT(searchLnkSt, A_SearchLnk_DimStratDictId);
    SET_DICT(searchLnkSt,   A_SearchLnk_StratObjId, emptyDictId); /* PMSTA-46575 - 211214 - DDV - Don't fill DOM_STRAT for new version of the proc */

    COPY_DYNFLD(searchLnkSt, A_SearchLnk, A_SearchLnk_LnkNatEn,
                domainPtr, A_Domain, A_Domain_StratLnkNatEn);
    SET_FLAG(searchLnkSt, A_SearchLnk_AllHistFlg, FALSE);
    SET_FLAG(searchLnkSt, A_SearchLnk_CurrentFlg, FALSE); /* REF9187 - LJE - 030624 */
    SET_FLAG(searchLnkSt, A_SearchLnk_PhysicalLnkFlg, FALSE);

    SET_ENUM(searchLnkSt, A_SearchLnk_ComplianceMethodEn, complianceMethodEn::Default);
    SET_FLAG(searchLnkSt, A_SearchLnk_DynamicSeverityFlg, FALSE);
    SET_FLAG(searchLnkSt, A_SearchLnk_LoadHierFlg, FALSE);
    SET_FLAG(searchLnkSt, A_SearchLnk_CaseDurationFlg, FALSE);

    /* REF9264 - LJE - 031013 : For this treatment, ref date is used */
    tmpFromDate = GET_DATETIME(domainPtr, A_Domain_InterpFromDate);

    /* TOCHECK */ /* REF8712 - LJE - 031013 */
    if (IS_NULLFLD(domainPtr, A_Domain_CalcRefDate) == FALSE &&
        CMP_DYNFLD(domainPtr, domainPtr, A_Domain_CalcRefDate, A_Domain_InterpFromDate, DatetimeType) < 0)
    {
        COPY_DYNFLD(domainPtr, A_Domain, A_Domain_InterpFromDate,
                    domainPtr, A_Domain, A_Domain_CalcRefDate);
    }

    COPY_DYNFLD(searchLnkSt, A_SearchLnk, A_SearchLnk_BeginDate,
                domainPtr, A_Domain, A_Domain_InterpFromDate);
    COPY_DYNFLD(searchLnkSt, A_SearchLnk, A_SearchLnk_EndDate,
                domainPtr, A_Domain, A_Domain_InterpTillDate);

    COPY_DYNFLD(searchLnkSt, A_SearchLnk, A_SearchLnk_MinLnkPriority,
                domainPtr, A_Domain, A_Domain_MinLnkPriority);
    COPY_DYNFLD(searchLnkSt, A_SearchLnk, A_SearchLnk_MaxLnkPriority,
                domainPtr, A_Domain, A_Domain_MaxLnkPriority);

    /* REF9187 - LJE - 030624 */
    /* For all strategies of nature Investment Profile,
       expand StratLnk with the historisation and the composition of the strategy */
    SET_ENUM(searchLnkSt, A_SearchLnk_ExpandStratEn,   expandStratEn);
    SET_FLAG(searchLnkSt, A_SearchLnk_SinglePeriodFlg, TRUE);

    SET_SMALLINT(searchLnkSt, A_SearchLnk_StratLnk, (short)ExtStratLnk);

    COPY_DYNFLD(searchLnkSt, A_SearchLnk, A_SearchLnk_LoadDimPortHistFlg,
                domainPtr, A_Domain, A_Domain_LoadDimPtfHistFlg);/* WEALTH-7310 - JBC - 20240601 */
    

	if((ret = connHelper.dbaCreateTempTables(DOM_STRAT|DOM_POSITION_INSTR_PORT|TCT_VECTOR_ID|OBJ_ID)) != RET_SUCCEED)
    {
        SET_DATETIME(domainPtr, A_Domain_InterpFromDate, tmpFromDate); /* REF9264 - LJE - 031013 */
    	return ret;
    }

    /* REF9187 - LJE - 030630 */
    if (GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_PerformanceAnalysis)
    {
        /* PMSTA10033 - LJE - 100615 */
	    switch (GET_ENUM(domainPtr, A_Domain_ReturnAnalysisEn))
		{
		case PAARetAnalysis_All : /* all */
		case PAARetAnalysis_PA : /* PA */
			maxBenchLoading = 3;
			break;
		case PAARetAnalysis_RA : /* RA */
		case PAARetAnalysis_StdPerf : /* Standard Perf */
			maxBenchLoading = 1;
			break;
		default:
			MSG_SendMesg(RET_GEN_ERR_INVARG, 5 , FILEINFO, "DBA_LoadDomPspTable", "domain", "return_analysis_e");
			return(RET_GEN_ERR_INVARG);
		}

        /* get all ObjectLnk and insert all portfolios in #dom_port */
        /* extract all ObjectLink Order by from object id */
   	    if ((ret = DBA_ExtractHierEltRec(hierHead, A_ObjectLnk, FALSE,
                                         NULLFCT, FIN_CmpObjectLnkFromObjectId,
                                         &fromObjectLnkNbr, &fromObjectLnkTab)) != RET_SUCCEED)
        {
            FREE_DYNST(searchLnkSt, A_SearchLnk);
            SET_DATETIME(domainPtr, A_Domain_InterpFromDate, tmpFromDate); /* REF9264 - LJE - 031013 */
            return(ret);
        }

        RequestHelper requestHelper(connHelper);
        
        std::map<ID_T,std::set<DatePeriod>> ptfPeriodSet;

        for (i=0; i<fromObjectLnkNbr; i++)
        {
            /* Check that it is a portfolio */
            if(GET_DICT(fromObjectLnkTab[i], A_ObjectLnk_FromEntDictId) != ptfDictId)
                continue;

            if(GET_FLAG(domainPtr,A_Domain_LoadDimPtfHistFlg) == FALSE 
                && ptfPeriodSet.count(GET_ID(fromObjectLnkTab[i], A_ObjectLnk_FromObjectId)) > 0)
                continue;

            DatePeriod datePeriod(GET_DATETIME(fromObjectLnkTab[i],A_ObjectLnk_BeginDate),GET_DATETIME(fromObjectLnkTab[i],A_ObjectLnk_EndDate));

            if(GET_FLAG(domainPtr,A_Domain_LoadDimPtfHistFlg) == TRUE 
                && ptfPeriodSet.count(GET_ID(fromObjectLnkTab[i], A_ObjectLnk_FromObjectId)) > 0
                && ptfPeriodSet[GET_ID(fromObjectLnkTab[i], A_ObjectLnk_FromObjectId)].count(datePeriod) > 0)
                continue;

            DBA_DYNFLD_STP domPortStp = requestHelper.getNewRecordForBatch(A_DomPort);
            SET_ID(domPortStp, A_DomPort_Id, GET_ID(fromObjectLnkTab[i], A_ObjectLnk_FromObjectId));
            if(GET_FLAG(domainPtr,A_Domain_LoadDimPtfHistFlg) == TRUE)
            {
                SET_DATETIME(domPortStp,A_DomPort_BeginDate,GET_DATETIME(fromObjectLnkTab[i],A_ObjectLnk_BeginDate));                    
                SET_DATETIME(domPortStp,A_DomPort_EndDate,GET_DATETIME(fromObjectLnkTab[i],A_ObjectLnk_EndDate));
            }

            ptfPeriodSet[GET_ID(fromObjectLnkTab[i], A_ObjectLnk_FromObjectId)].insert(datePeriod);
        }

        ret = requestHelper.executeBatch();
    }
    else
    {
        maxBenchLoading = 1; /* REF9187 - LJE - 030630 */
    }

    /* Send an Init request to fill dom_port_strat */
    /* and dom_strat table */
    if (DBA_Notif(StratLnk,
                  UNUSED,
                  A_SearchLnk,
                  searchLnkSt,
                  connHelper) != RET_SUCCEED)
    {
        FREE(fromObjectLnkTab);
        FREE_DYNST(searchLnkSt, A_SearchLnk);
        SET_DATETIME(domainPtr, A_Domain_InterpFromDate, tmpFromDate); /* REF9264 - LJE - 031013 */
        return(RET_GEN_ERR_NOACTION);
    }

    /* Call select function */
    ret = DBA_SelStratLnkByIdWithPtfs(searchLnkSt,
                                      sStratLnkTab,
                                      sStratLnkNbr,
                                      connHelper.getConnection()->getId(),
                                      DBA_SET_CONN | DBA_NO_CLOSE,
                                      NULL,
                                      NULL,
                                      0,
                                      TRUE, /* no ptf ids */ /* REF7758 - DDV - 020919 */
									  domainPtr); /* PMSTA-12724-CHU-110907 */

    if (ret == RET_SUCCEED)
    {
        if ((ret = DBA_FilterBestStratLnk(domainPtr, hierHead, sStratLnkTab, sStratLnkNbr, maxBenchLoading)) != RET_SUCCEED)
        {
            FREE_DYNST(searchLnkSt, A_SearchLnk);
            DBA_FreeDynStTab(*sStratLnkTab, *sStratLnkNbr, S_StratLnk);
            FREE(fromObjectLnkTab);
            SET_DATETIME(domainPtr, A_Domain_InterpFromDate, tmpFromDate); /* REF9264 - LJE - 031013 */
            return(ret);
        }
    }

    FREE_DYNST(searchLnkSt, A_SearchLnk);
    FREE(fromObjectLnkTab);
    SET_DATETIME(domainPtr, A_Domain_InterpFromDate, tmpFromDate); /* REF9264 - LJE - 031013 */
    return(ret);
}

/************************************************************************
**  Function             : DBA_FilterBestStratLnk()
**
**  Description          : Select only the best StatLnk and delete all others
**							(used by analyis phase and ptf storage).
**
**  Arguments            : domainPtr    : pointer on domain of financial function
**                         hierHead     : hierarchy pointer
**                         stratLnkTab  : array of strategy links to filter
**                         stratLnkNbr  : pointer on the number of strategy link remaining
**
**  Return               : RET_SUCCEED              : if no problem was detected
**                         a RET_CODE               : if a message has been received
**
**  Creation Date        : 020919 - DDV - REF7758
**  Last Modification    : 
*************************************************************************/
EXTERN RET_CODE DBA_FilterBestStratLnk(DBA_DYNFLD_STP domainPtr,
                                       DBA_HIER_HEAD_STP hierHead,		/* PMSTA-50467 - JBC - 221112 */
                                       DBA_DYNFLD_STP **sStratLnkTab,
                                       int            *sStratLnkNbr,
                                       int            lnkNbrByObject)
{

    DICT_T          stratDictId, instrDictId, ptfDictId;

    if (lnkNbrByObject == 0)
    {
        DBA_FreeDynStTab((*sStratLnkTab), (*sStratLnkNbr), S_StratLnk);
        return(RET_SUCCEED);
    }

    DBA_GetDictId(Strat, &stratDictId); /* REF9187 - LJE - 030630 */
    /* REF10806 - LJE - 041208 */
    DBA_GetDictId(Instr, &instrDictId);
    DBA_GetDictId(Ptf,   &ptfDictId);

   
    std::set<ID_T> ptfToFree;    
    std::vector<std::pair<ID_T,DatePeriodVec>> ptfInOrder;
    std::set<int> idxToKeep;
    std::vector<DBA_DYNFLD_STP> newStratLnkTab;
    MemoryPool mp;

    /* create ptf strat index map */
    for (int i=0; i<(*sStratLnkNbr);i++)
    {
        const ID_T ptfId = GET_ID((*sStratLnkTab)[i], S_StratLnk_PtfId);

        if(ptfInOrder.empty() || ptfInOrder[ptfInOrder.size()-1].first != ptfId)
        {
            RET_CODE ret = RET_SUCCEED;
            DatePeriodVec compPeriods;
            CODE_T  ptfCode;
            DATETIME_T fromDate = GET_DATETIME(domainPtr, A_Domain_InterpFromDate);
            DATETIME_T tillDate = GET_DATETIME(domainPtr, A_Domain_InterpTillDate);
            
            if ((ret = DBA_UseCompPeriodsForStratLnk(domainPtr, hierHead, ptfId, &fromDate, &tillDate, &ptfCode, compPeriods)) != RET_SUCCEED)
            {
                MSG_LogSrvMesg(ret, UNUSED, "Failed to find valid Portfolio Computation Dates in Storage/Analysis for : %1.",
                               CodeType, ptfCode);
                ptfToFree.insert(ptfId);
            }

            ptfInOrder.push_back(std::make_pair(ptfId,compPeriods));
        }

    }

    size_t ptfIdx = 0;

    for(int stratLnkIdx = 0;stratLnkIdx<(*sStratLnkNbr);stratLnkIdx++)
    {
        if(GET_ID((*sStratLnkTab)[stratLnkIdx], S_StratLnk_PtfId) != ptfInOrder[ptfIdx].first)
        {
            ptfIdx++;
        }

        const ID_T ptfId = ptfInOrder[ptfIdx].first;

        if(ptfToFree.count(ptfId)
            || /* REF9187 - LJE - 040211 */ 
                ( (GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_PerformanceAnalysis ||
                GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_PtfStorage) &&
                GET_ENUM((*sStratLnkTab)[stratLnkIdx], S_StratLnk_StratNatEn) != StratNat_Alloc &&
                GET_ENUM((*sStratLnkTab)[stratLnkIdx], S_StratLnk_StratNatEn) != StratNat_ModelPtf &&
                GET_ENUM((*sStratLnkTab)[stratLnkIdx], S_StratLnk_StratNatEn) != StratNat_Benchmark &&
                GET_ENUM((*sStratLnkTab)[stratLnkIdx], S_StratLnk_StratNatEn) != StratNat_Index && /* PMSTA-20534 - LJE - 150529 */
                /* REF10820 - LJE - 041208 */
                (GET_ENUM((*sStratLnkTab)[stratLnkIdx], S_StratLnk_StratNatEn) != StratNat_All ||
                (GET_DICT((*sStratLnkTab)[stratLnkIdx], S_StratLnk_ToEntDictId) != instrDictId &&
                    GET_DICT((*sStratLnkTab)[stratLnkIdx], S_StratLnk_ToEntDictId) != ptfDictId))
                )
            || /* REF9770 - LJE - 040302 */ /* Strategy link to instrument or portfolio are allowed only for Performance Analysis */
                (GET_ID(domainPtr, A_Domain_FctDictId) != DictFct_PerformanceAnalysis &&
                     GET_DICT((*sStratLnkTab)[stratLnkIdx], S_StratLnk_ToEntDictId) != stratDictId)
            )
        {
            continue;
        }
        
        DatePeriodVec compPeriods = ptfInOrder[ptfIdx].second;
        const int     ptfStratLnkStart = stratLnkIdx;

        for(size_t perIdx=0;perIdx<compPeriods.size();perIdx++)
        {
            int           lnkNbr = 0;
            DATE_T        prevBeginDate = 0;
            stratLnkIdx = ptfStratLnkStart;

            while(stratLnkIdx < (*sStratLnkNbr) && GET_ID((*sStratLnkTab)[stratLnkIdx], S_StratLnk_PtfId)  == ptfId)
            {
                if(compPeriods[perIdx].cmpBegin(GET_DATE((*sStratLnkTab)[stratLnkIdx], S_StratLnk_EndDate)) >= 0
                        || compPeriods[perIdx].cmpEnd(GET_DATE((*sStratLnkTab)[stratLnkIdx], S_StratLnk_BegDate)) <= 0)
                {
                    stratLnkIdx++;
                    continue;
                }
                else if (prevBeginDate != GET_DATE((*sStratLnkTab)[stratLnkIdx], S_StratLnk_BegDate)) /* WEALTH-14260 - DDV - 241112 - Same portfolio may have several strategy links. */
                {
                    lnkNbr = 0;
                    prevBeginDate = GET_DATE((*sStratLnkTab)[stratLnkIdx], S_StratLnk_BegDate);
                }

                if (lnkNbr < lnkNbrByObject)
                {                    
                    lnkNbr++;
                    DBA_DYNFLD_STP sStratLnk = nullptr;              
                    
                    if(compPeriods.size() == 1)
                    {
                        sStratLnk = (*sStratLnkTab)[stratLnkIdx];
                        idxToKeep.insert(stratLnkIdx);
                    }
                    else
                    {   // copy always to avoid date issues, don't keep any
                        sStratLnk = mp.allocDynst(FILEINFO,S_StratLnk);
                        COPY_DYNST(sStratLnk,(*sStratLnkTab)[stratLnkIdx],S_StratLnk);
                    }                    
                     /* REF9922 - LJE - 040213 */
                    SET_INT(sStratLnk, S_StratLnk_Rank, (lnkNbr));/* PMSTA49957 - VSW - 160822 */

                    if (compPeriods[perIdx].cmpBegin(GET_DATE(sStratLnk, S_StratLnk_BegDate)) > 0)
                    {
                        SET_DATE(sStratLnk, S_StratLnk_BegDate, compPeriods[perIdx].getBegin().date);
                    }

                    if (compPeriods[perIdx].cmpEnd(GET_DATE(sStratLnk, S_StratLnk_EndDate)) < 0)
                    {
                        SET_DATE(sStratLnk, S_StratLnk_EndDate, compPeriods[perIdx].getEnd().date);
                    }

                    newStratLnkTab.push_back(sStratLnk);                   
                }
                stratLnkIdx++;
            }
        }
        stratLnkIdx--;  //set back
    }

    const int origStratLnkNb = (*sStratLnkNbr);

    if(static_cast<int>(newStratLnkTab.size()) > (*sStratLnkNbr))
    {   //resize
        (*sStratLnkTab) = (DBA_DYNFLD_STP *)mp.realloc((*sStratLnkTab), newStratLnkTab.size() * sizeof (DBA_DYNFLD_STP));
        (*sStratLnkNbr) = static_cast<int>(newStratLnkTab.size());
    }

    for(int i=0;i<(*sStratLnkNbr);i++)
    {
        if(i < origStratLnkNb && idxToKeep.count(i) == 0)
        {
            FREE_DYNST((*sStratLnkTab)[i],S_StratLnk);
        }

        if(i < static_cast<int>(newStratLnkTab.size()))
        {
            (*sStratLnkTab)[i] = newStratLnkTab[i];
        }
    }
    //reconfirm size
    (*sStratLnkNbr) = static_cast<int>(newStratLnkTab.size());

    mp.removeAll();

    return(RET_SUCCEED);
}

STATIC std::string to_string(const PerfCompPeriodTechNatEn techNature, bool isHierPtf = false)
{
    switch(techNature)
    {
        case PerfCompPeriodTechNatEn::PerfFirstOp:
        	if(isHierPtf)
                return "hier_perf_first_op_d-1";
            else
                return "perf_first_op_d-1";
        case PerfCompPeriodTechNatEn::Database:
            return "Database";
        case PerfCompPeriodTechNatEn::Domain:
            return "Domain";
        case PerfCompPeriodTechNatEn::PtfMerged:
            return "PtfMerged";
        case PerfCompPeriodTechNatEn::PerfFirstStored:
            return "std_perf_first_stored_d";
        default:
            return "";
    }
}

/************************************************************************
**  Function             : DBA_MergePerfCompPeriods()
**
**  Description          : Check/update/merge computation period data
**
**  Arguments            : hierarchy, domain
**
**  Return               : RET_SUCCEED              : if no problem was detected
**                         a RET_CODE               : if a message has been received
**
**  Creation Date        : PMSTA-50467 - JBC 221222
**  Last Modification    :
*************************************************************************/
STATIC RET_CODE DBA_AddCompPeriodsToHier(DBA_HIER_HEAD_STP hierHead,  DBA_DYNFLD_STP domainPtr, std::string & pcpCd, 
    const ID_T ptfId, std::string & ptfCd, DatePeriodVec & compPeriods,const PerfCompPeriodTechNatEn techNature, const ID_T hierPtfId)
{
    RET_CODE ret = RET_SUCCEED;
    MemoryPool  mp;

    for(size_t i=0;i<compPeriods.size();i++)
    {
        DBA_DYNFLD_STP sCompPeriod = mp.allocDynst(FILEINFO,S_PerfComputationPeriod);
        SET_NULL_ID(sCompPeriod,S_PerfComputationPeriod_Id);
        SET_CODE(sCompPeriod,S_PerfComputationPeriod_Cd,(pcpCd.empty() ? to_string(techNature,hierPtfId > ZERO_ID).c_str() : pcpCd.c_str()));
        SET_ID(sCompPeriod,S_PerfComputationPeriod_PtfId,ptfId);                
        SET_CODE(sCompPeriod,S_PerfComputationPeriod_PtfCd,ptfCd.c_str());
        SET_DATETIME(sCompPeriod,S_PerfComputationPeriod_BeginDate,compPeriods[i].getBegin());
        SET_DATETIME(sCompPeriod,S_PerfComputationPeriod_EndDate,compPeriods[i].getEnd());
        if(hierPtfId > ZERO_ID && CMP_ID(ptfId,hierPtfId) != 0)
        {
            SET_ID(sCompPeriod, S_PerfComputationPeriod_HierPortId,hierPtfId);   
        }
        SET_ENUM(sCompPeriod,S_PerfComputationPeriod_TechNatEn,techNature);
        SET_DATETIME(sCompPeriod,S_PerfComputationPeriod_CalcFromDate,GET_DATETIME(domainPtr,A_Domain_InterpFromDate));
        SET_DATETIME(sCompPeriod,S_PerfComputationPeriod_CalcTillDate,GET_DATETIME(domainPtr,A_Domain_InterpTillDate));
        
        if((ret = DBA_AddHierRecord(hierHead,sCompPeriod,S_PerfComputationPeriod, TRUE,HierAddRec_NoLnk)) != RET_SUCCEED)
        {
            return ret;
        }
        mp.remove(sCompPeriod);
    };

    return ret;
}

/************************************************************************
**  Function             : DBA_MergePerfCompPeriods()
**
**  Description          : Check/update/merge computation period data
**
**  Arguments            : hierarchy, domain
**
**  Return               : RET_SUCCEED              : if no problem was detected
**                         a RET_CODE               : if a message has been received
**
**  Creation Date        : PMSTA-50467 - JBC 221222
**  Last Modification    :
*************************************************************************/
RET_CODE DBA_MergePerfCompPeriods(DBA_HIER_HEAD_STP hierHead, DBA_DYNFLD_STP domainPtr, DBA_DYNFLD_STP * ptfTab, int ptfNb)
{
    RET_CODE            ret = RET_SUCCEED;    
    MemoryPool          mp;
    DATETIME_T          magicEndDate = {MAGIC_END_DATE,0};
    bool                hasNewPtf = false;
    std::string         emptyPcpCd;
    static const int    HIER_PTF = 0;
    static const int    CHILD_PTF = 1;
    
    if(ptfTab == nullptr || ptfNb == 0)
    {    
        if ((ret = DBA_ExtractHierEltRec(hierHead, A_Ptf, FALSE, NULL, NULL,  &ptfNb, &ptfTab)) != RET_SUCCEED)
	    {
		    return(ret);
	    }
        mp.ownerPtr(ptfTab);
    }
    RETURNINPARENTPTFRULE_ENUM returnInParentPtfRuleEn=ReturnInParentPtfRule_Children;
	GEN_GetApplInfo(ApplReturnInParentPtfRule, &returnInParentPtfRuleEn);
    PTF_MGTDATE_RULE_ENUM   ptfMgtDateRuleEn = PtfMgtDateRule_None;
    GEN_GetApplInfo(ApplPerfManagementDateRule, &ptfMgtDateRuleEn);
    std::map<ID_T,DBA_DYNFLD_STP> ptfPtrMap; 
    std::map<ID_T,ID_T> ptfToHierMap;
    std::map<ID_T,DBA_DYNFLD_STP> ptfFirstOpMap;
    std::set<ID_T> emptyHierPtfs;
    std::map<ID_T,DATETIME_T> domPeriodPtfs;  // ptf , dom begin date
    std::set<ID_T> hasPcpPtfs;
    std::set<ID_T> virtualPtfs;
    bool isSinglePtfTWR = ptfNb == 1 && (GET_ENUM(domainPtr,A_Domain_PtfConsRuleEn) == PtfConsRule_MergedTWR 
            || GET_ENUM(domainPtr,A_Domain_PtfConsRuleEn) == PtfConsRule_MergedTWR_Detail);

    for(int i = 0;i < ptfNb;i++)
    {   
        const ID_T ptfId = GET_ID(ptfTab[i],A_Ptf_Id);
        ptfPtrMap[ptfId] = ptfTab[i];

        /* check if already done for ptf */
        {
            int finalPeriodNb = 0;
            DBA_HierGetRecNbrWithFilterSt(hierHead, S_PerfComputationPeriod, FIN_FilterPtfPerfCompPeriod, ptfTab[i], &finalPeriodNb, FALSE);

            if(finalPeriodNb == 0)
            {
				hasNewPtf = true;
            }
        }
    }

    /* quick exit */
    if(hasNewPtf == false)
    {
	    return ret;
    }

    DBA_DYNFLD_STP *    sDomCompPeriodTab = NULLDYNSTPTR;
    int                 sDomCompPeriodNb = 0;

   	if ((ret = DBA_ExtractHierEltRec(hierHead, S_PerfComputationPeriod, FALSE,  FIN_FilterDomainCompPeriod,
                                    FIN_CmpCompPeriodBeginDate,  &sDomCompPeriodNb, &sDomCompPeriodTab)) != RET_SUCCEED)
	{
        FREE(sDomCompPeriodTab);
		return(ret);
	}

    mp.ownerPtr(sDomCompPeriodTab);

    for(int i=0;i<sDomCompPeriodNb;i++)
    {    /* build hier port map */
        const ID_T ptfId = GET_ID(sDomCompPeriodTab[i],S_PerfComputationPeriod_PtfId);
        ID_T hierPtfId = IS_NULLFLD(sDomCompPeriodTab[i],S_PerfComputationPeriod_HierPortId) ? ZERO_ID : GET_ID(sDomCompPeriodTab[i],S_PerfComputationPeriod_HierPortId);
        if(GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None)
        {   
            if(ptfToHierMap.count(ptfId) == 0
                && hierPtfId > ZERO_ID)
            {
                ptfToHierMap[ptfId] = hierPtfId;

                if(ptfPtrMap.count(hierPtfId) == 0)
                {                
                    DBA_DYNFLD_STP hierPtfPtr = NULLDYNSTPTR;
                    if(DBA_GetRecPtrFromHierById(hierHead,hierPtfId,A_Ptf,&hierPtfPtr) == RET_SUCCEED && hierPtfPtr != NULLDYNSTPTR)
                    {
                        ptfPtrMap[hierPtfId] = hierPtfPtr;
                    }
                }
            }
        }

        if(GET_FLAG(domainPtr, A_Domain_LoadHierHistFlg) == TRUE
            || GET_FLAG(domainPtr, A_Domain_LoadDimPtfHistFlg) == TRUE)
        {   
            if(domPeriodPtfs.count(ptfId) == 0)
            {   // only take earliest for ref
                domPeriodPtfs[ptfId] = GET_DATETIME(sDomCompPeriodTab[i],S_PerfComputationPeriod_BeginDate);
            }
        }
        
        if(IS_NULLFLD(sDomCompPeriodTab[i],S_PerfComputationPeriod_Cd))
        {   /* readability */
            SET_CODE(sDomCompPeriodTab[i],S_PerfComputationPeriod_Cd,to_string(PerfCompPeriodTechNatEn::Domain).c_str());
        }
        if(IS_NULLFLD(sDomCompPeriodTab[i],S_PerfComputationPeriod_PtfCd) && ptfPtrMap.count(ptfId) > 0)
        {   /* readability */
            SET_CODE(sDomCompPeriodTab[i],S_PerfComputationPeriod_PtfCd,GET_CODE(ptfPtrMap[ptfId],A_Ptf_Cd));
        }
    }

    /* update perf first and psp data */
    { 
        /* perf_first_op_d and psp records */
        DBA_DYNFLD_STP *allPerfFirstTab = nullptr;
        int allPerfFirstNb = 0;

        if((ret = DBA_ExtractHierEltRecWithFilterSt(hierHead, S_PerfComputationPeriod, FALSE, FIN_FilterFirstCompPeriod, 
                                                nullptr, NULLFCT, &allPerfFirstNb, &allPerfFirstTab)) != RET_SUCCEED)
        {
            return ret;
        }

        mp.ownerPtr(allPerfFirstTab);

        for(int j=0;j<allPerfFirstNb;j++)
        {               
            const ID_T ptfId = GET_ID(allPerfFirstTab[j],S_PerfComputationPeriod_PtfId);

            auto techNatEn = static_cast<PerfCompPeriodTechNatEn>(GET_ENUM(allPerfFirstTab[j],S_PerfComputationPeriod_TechNatEn));
            if(techNatEn == PerfCompPeriodTechNatEn::PerfFirstOp)
            {               
                    ptfFirstOpMap[ptfId] = allPerfFirstTab[j];
            }

            SET_CODE(allPerfFirstTab[j],S_PerfComputationPeriod_Cd,to_string(techNatEn,ptfToHierMap.count(ptfId) == 0).c_str());
            SET_CODE(allPerfFirstTab[j],S_PerfComputationPeriod_PtfCd,GET_CODE(ptfPtrMap[ptfId],A_Ptf_Cd));

            if(GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None && ptfToHierMap.count(ptfId) > 0)
            {
	            SET_ID(allPerfFirstTab[j],S_PerfComputationPeriod_HierPortId,ptfToHierMap[ptfId]);
            }
        }
    }

   /* hier ptf must be done first */
    for(int ptfSet = 0;ptfSet < 2;ptfSet++)
    {  
	    /* first create any in-memory PCPs required and prepare data*/
	    for(int i = 0;i < ptfNb;i++)
	    {   
	        const ID_T ptfId = GET_ID(ptfTab[i],A_Ptf_Id);

            if(ptfSet == HIER_PTF && ptfToHierMap.count(ptfId) > 0
                || (ptfSet == CHILD_PTF && ptfToHierMap.count(ptfId) == 0))
            {   // either already processed or must be done on next loop
	            continue;
            }

	        if(ptfId <= 0)
	        {   // virtual hier portfolio
	            hasNewPtf = true;
	            virtualPtfs.insert(ptfId);
	            continue; 
	        }

	        std::string ptfCd =  IS_NULLFLD(ptfTab[i],A_Ptf_Cd) ? "" : GET_CODE(ptfTab[i],A_Ptf_Cd);
	        
	        /* check if already done for ptf */
	        {
	            int finalPeriodNb = 0;
	            DBA_HierGetRecNbrWithFilterSt(hierHead, S_PerfComputationPeriod, FIN_FilterPtfPerfCompPeriod, ptfTab[i], &finalPeriodNb, FALSE);

	            if(finalPeriodNb > 0)
	            {
	                continue;
	            }
	            hasNewPtf = true;
	        }
	       
	        /* extract true records from perf_computation_period */
	        int dbPeriodNb = 0;
	        DBA_HierGetRecNbrWithFilterSt(hierHead, S_PerfComputationPeriod, FIN_FilterPtfDbCompPeriod, ptfTab[i], &dbPeriodNb, FALSE);

	        if(dbPeriodNb == 0)
	        {         
	            /* PMSTA-50467 check portfolio migrations for mgt begin/end */  
	            if(ptfMgtDateRuleEn != PtfMgtDateRule_None && IS_NULLFLD(ptfTab[i], A_Ptf_MgtBeginDate) == FALSE)
	            {
	               /* portfolio can't have any pcps for any range */
	                DBA_DYNFLD_STP chkArg = mp.allocDynst(FILEINFO,Chk_Arg);
	                SET_ID(chkArg,Chk_Arg_Id,ptfId);
	                SET_INT(chkArg,Chk_Arg_ReturnStatus,0);

	                DbiConnectionHelper connHelper;
	                if((ret = connHelper.dbaCheck(PerfComputationPeriod,DBA_ROLE_PERF_FIRST_OP,chkArg)) != RET_SUCCEED)
	                {
	                   return ret;
	                }
	                
	                if(GET_INT(chkArg,Chk_Arg_ReturnStatus) == FALSE)
	                {
	                    DatePeriod newCompPeriod(GET_DATETIME(ptfTab[i],A_Ptf_MgtBeginDate),magicEndDate);
	                    
	                    if(ptfMgtDateRuleEn == PtfMgtDateRule_UseMgtDates && IS_NULLFLD(ptfTab[i],A_Ptf_MgtEndDate) == false)
	                    {
	                       newCompPeriod.setEnd(GET_DATETIME(ptfTab[i],A_Ptf_MgtEndDate));
	                    }

	                    /* get code index */
	                    DICT_T pcpDictId = ZERO_ID;
	                    DBA_GetDictId(PerfComputationPeriod, &pcpDictId);
	                    DBA_DYNFLD_STP aDocIndex = mp.allocDynst(FILEINFO,A_DocIndex);

	                    if ((ret = DBA_GetNewDocIndex(pcpDictId, NULL, newCompPeriod.getBegin(), DocIndexNat_SystemCd, aDocIndex)) != RET_SUCCEED)
	                    {
	                        return ret;
	                    }

	                    char pcpCdStr[60];
	                    sprintf(pcpCdStr, "%s%012d", "PTFMGTDT", GET_INT(aDocIndex,A_DocIndex_Index));

	                    DBA_DYNFLD_STP aDatabasePeriod = mp.allocDynst(FILEINFO,A_PerfComputationPeriod);
	                    SET_ID(aDatabasePeriod,A_PerfComputationPeriod_PtfId,ptfId);
	                    SET_CODE(aDatabasePeriod, A_PerfComputationPeriod_Cd, pcpCdStr);
	                    SET_DATETIME(aDatabasePeriod,A_PerfComputationPeriod_BeginDate,newCompPeriod.getBegin());
	                    SET_DATETIME(aDatabasePeriod,A_PerfComputationPeriod_EndDate,newCompPeriod.getEnd());

	                    if((ret = connHelper.dbaInsert(PerfComputationPeriod,UNUSED,aDatabasePeriod)) != RET_SUCCEED)
	                    {
	                        return ret;
	                    }

	                    /* add to hierarchy */
	                    DBA_DYNFLD_STP sDatabasePeriod = mp.allocDynst(FILEINFO,S_PerfComputationPeriod);
	                    DBA_ConvertAllDynstToShort(PerfComputationPeriod,aDatabasePeriod,&sDatabasePeriod);               
	                    SET_CODE(sDatabasePeriod,S_PerfComputationPeriod_PtfCd,ptfCd.c_str());
	                    SET_ENUM(sDatabasePeriod,S_PerfComputationPeriod_TechNatEn,PerfCompPeriodTechNatEn::Database);
	                    if(ptfToHierMap.count(ptfId) > 0)
	                    {
	                        SET_ID(sDatabasePeriod, S_PerfComputationPeriod_HierPortId,ptfToHierMap[ptfId]);   
	                    }

	                    if((ret = DBA_AddHierRecord(hierHead,sDatabasePeriod,S_PerfComputationPeriod, TRUE,HierAddRec_NoLnk)) != RET_SUCCEED)
	                    {
	                        return ret;
	                    }        
	                    mp.remove(sDatabasePeriod);
	                    dbPeriodNb++;
	                    // has true pcp
	                    hasPcpPtfs.insert(ptfId);
	                }
	            }
	        }
	        else 
	        {   // has true pcp
	            hasPcpPtfs.insert(ptfId);
	        }

	        /* WEALTH-15270 - JBC - 20241023 */
	        if(ptfToHierMap.count(ptfId) == 0 && dbPeriodNb == 0)
	        {   /* merge perf first dates of hierarchy */
	            DBA_DYNFLD_STP *hierFirstOpTab = nullptr;
	            int             hierFirstOpNb = 0;

	            if((ret = DBA_ExtractHierEltRecWithFilterSt(hierHead, S_PerfComputationPeriod, FALSE, FIN_FilterHierFirstOpCompPeriod,
	                                                ptfTab[i], NULLFCT, &hierFirstOpNb, &hierFirstOpTab)) != RET_SUCCEED)
		        {
		            return ret;
		        }

	            mp.ownerPtr(hierFirstOpTab);

	            /* merge first op if more than one or the hier ptf has none */
	            if(hierFirstOpNb > 1 || (hierFirstOpNb > 0 && ptfFirstOpMap[ptfId] == nullptr))
	            {   
            		 DatePeriod  hierFirstOpPeriod;
	                 hierFirstOpPeriod.setBegin(GET_DATETIME(hierFirstOpTab[0],S_PerfComputationPeriod_BeginDate));

	                if(hierFirstOpNb > 1)
	                {
		                 for(int j=1;j<hierFirstOpNb;j++)
		                 {
			                 if(hierFirstOpPeriod.cmpBegin(GET_DATETIME(hierFirstOpTab[j],S_PerfComputationPeriod_BeginDate)) > 0)
			                 {
				                 hierFirstOpPeriod.setBegin(GET_DATETIME(hierFirstOpTab[j],S_PerfComputationPeriod_BeginDate));
			                 }
		                 }
	                }
            		
            		/* update hier rec */
	                if(ptfFirstOpMap[ptfId] != nullptr)
	                {
		                SET_DATETIME(ptfFirstOpMap[ptfId],S_PerfComputationPeriod_BeginDate,hierFirstOpPeriod.getBegin());
	                }
	                else /* generate record for hier */
	                {   
	                    DatePeriodVec tmpPeriodVec;
	                    tmpPeriodVec.push_back(hierFirstOpPeriod);
	                    std::string pcpCd = to_string(PerfCompPeriodTechNatEn::PerfFirstOp,true);                    

		                if((ret = DBA_AddCompPeriodsToHier(hierHead,domainPtr,pcpCd,ptfId,ptfCd,tmpPeriodVec,
				            PerfCompPeriodTechNatEn::PerfFirstOp,ZERO_ID)) != RET_SUCCEED)
				        {
				            return ret;
				        }
	                }	            
	            }	        
	        }

	        /* perf_first_op_d and psp records for ptf only */
	        DBA_DYNFLD_STP *perfFirstTab = nullptr;
	        int perfFirstNb = 0;

	        if((ret = DBA_ExtractHierEltRecWithFilterSt(hierHead, S_PerfComputationPeriod, FALSE, FIN_FilterPtfFirstCompPeriod, 
	                                                ptfTab[i], NULLFCT, &perfFirstNb, &perfFirstTab)) != RET_SUCCEED)
	        {
	            return ret;
	        }

	        mp.ownerPtr(perfFirstTab);

	        /* delete or promote any perf_first_op_d recs to Database recs for calculation purpose  */
	        /* only 1 record is possible per ptf */
	        if(hasPcpPtfs.count(ptfId) > 0 && perfFirstNb > 0)
	        {   // pcp overrides perf_first_op_d / std_perf_first_stored_d
	            int delNb = 0;
	            if ((ret = DBA_DelHierEltRecWithFilter(hierHead, S_PerfComputationPeriod,
	                        FIN_FilterPtfFirstCompPeriod,ptfTab[i],&delNb)) != RET_SUCCEED)
	            {
	                return ret;
	            }
	        }
	        else
	        {   
                bool delPerfFirstStored = false;
	            for(int j=0;j<perfFirstNb;j++)
	            {
	                if(static_cast<PerfCompPeriodTechNatEn>(GET_ENUM(perfFirstTab[j],S_PerfComputationPeriod_TechNatEn)) == PerfCompPeriodTechNatEn::PerfFirstStored
	                    &&  GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None
	                    && ptfToHierMap.count(ptfId) > 0
	                    && returnInParentPtfRuleEn == ReturnInParentPtfRule_Parent)
	                {   // child psp not used
			            delPerfFirstStored = true;
	                }
	                else
	                {
						SET_ENUM(perfFirstTab[j],S_PerfComputationPeriod_TechNatEn,PerfCompPeriodTechNatEn::Database);
	                }
	            }
                
                if(delPerfFirstStored)
                {
	                int delNb = 0;
		            if ((ret = DBA_DelHierEltRecWithFilter(hierHead, S_PerfComputationPeriod,
		                        FIN_FilterPtfFirstStoredCompPeriod,ptfTab[i],&delNb)) != RET_SUCCEED)
		            {
		                return ret;
		            }
                }
	        }

	         /* check perf_first_op_d integrity on ptf level  */
	        if(IS_NULLFLD(ptfTab[i], A_Ptf_PerfFirstOpDate))
	        { 
	            DATETIME_T perfFirstOpDate;

	            if(OPE_GetPtfPerfFirstOpDate(ptfId,perfFirstOpDate))
	            {
	                SET_DATETIME(ptfTab[i],A_Ptf_PerfFirstOpDate,perfFirstOpDate);  
	            }
	            else if(GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None && ptfToHierMap.count(ptfId) == 0
	                && perfFirstNb == 0)  // could have stored data
	            {
	                emptyHierPtfs.insert(ptfId); // empty parent ptf
	            }
	        }
	    }
    }

    if(hasNewPtf == false)
    {   /* quick exit */
        return ret;
    }    

    /* build */
    for(auto it = ptfPtrMap.begin();it !=  ptfPtrMap.end();++it)
    {   
        const ID_T ptfId = it->first;

        if(ptfId <= 0)
        {   // virtual hier portfolio or already done
            continue; 
        }

        DBA_DYNFLD_STP ptfPtr = it->second;  
        /* check if already done for ptf */
        {
            int finalPeriodNb = 0;
            DBA_HierGetRecNbrWithFilterSt(hierHead, S_PerfComputationPeriod, FIN_FilterPtfPerfCompPeriod, ptfPtr, &finalPeriodNb, FALSE);

            if(finalPeriodNb > 0)
            {
                continue;
            }
        }
            
        std::string ptfCd =  IS_NULLFLD(ptfPtr,A_Ptf_Cd) ? "" : GET_CODE(ptfPtr,A_Ptf_Cd); 
        const ID_T hierPtfId = ptfToHierMap.count(ptfId) > 0 ? ptfToHierMap[ptfId] : ZERO_ID;
               
        DatePeriodSet dbPeriodSet;
        /* extract recs  derived from perf_computation_period / perf_first_op_d */    
        DBA_DYNFLD_STP *    sDbCompPeriodTab = NULLDYNSTPTR;
        int                 sDbCompPeriodNb = 0;

        ID_T dbCompPtfId = ptfId;
        /* if the hier ptf has is empty and has comp periods then override child PCPs */
        if(hierPtfId > ZERO_ID 
            && emptyHierPtfs.count(hierPtfId) > 0
            && hasPcpPtfs.count(hierPtfId) > 0)
        {
            dbCompPtfId = hierPtfId;
        }

   	    if (dbCompPtfId > ZERO_ID && (ret = DBA_ExtractHierEltRecWithFilterSt(hierHead, S_PerfComputationPeriod,FALSE, (dbCompPtfId > ZERO_ID ? FIN_FilterPtfDbCompPeriod : FIN_FilterDbCompPeriod),
                                       (dbCompPtfId > ZERO_ID ? ptfPtrMap[dbCompPtfId] : nullptr),FIN_CmpCompPeriodBeginDate, &sDbCompPeriodNb, &sDbCompPeriodTab)) != RET_SUCCEED)
	    {
		    return(ret);
	    }

        mp.ownerPtr(sDbCompPeriodTab);

        /* store dates */
        for(int i=0;i<sDbCompPeriodNb;i++)
        {
            if(IS_NULLFLD(sDbCompPeriodTab[i],S_PerfComputationPeriod_PtfCd))
            {   
                SET_CODE(sDbCompPeriodTab[i],S_PerfComputationPeriod_PtfCd,ptfCd.c_str());
            }

            DatePeriod dbPeriod(GET_DATETIME(sDbCompPeriodTab[i],S_PerfComputationPeriod_BeginDate),GET_DATETIME(sDbCompPeriodTab[i],S_PerfComputationPeriod_EndDate));

            // WEALTH-13782 - multi db recs with psp hist - look ahead to merge periods
            {
                auto nextIdx = i + 1;
                while(nextIdx < sDbCompPeriodNb)
                {   // next period overlaps, merge into existing.
                    DatePeriod nextPeriod(GET_DATETIME(sDbCompPeriodTab[nextIdx],S_PerfComputationPeriod_BeginDate),GET_DATETIME(sDbCompPeriodTab[nextIdx],S_PerfComputationPeriod_EndDate));
                    if(nextPeriod.cmpBegin(dbPeriod.getEnd()) <= 0 && nextPeriod.cmpEnd(dbPeriod.getEnd()) > 0
                        /* PMSTA-65215 - Deepthi JBC - 20250210 : if no PCP allow merge of PSP stored date and Perf first op date periods   */
                        || (hasPcpPtfs.count(dbCompPtfId) == 0 && nextPeriod.cmpEnd(dbPeriod.getEnd()) > 0) 
                        )
                    {
                        dbPeriod.setEnd(nextPeriod.getEnd());
                        i++; // already handled
                    }
                    else if(nextPeriod.cmpBegin(dbPeriod.getEnd()) <= 0 || nextPeriod.cmpEnd(dbPeriod.getEnd()) <= 0)
                    {
	                    i++; // already inside range
                    }
                    else
                    {   // advance to next new range
                        break;
                    }
                    nextIdx++;
                }
            }

            dbPeriodSet.insert(dbPeriod);
        }

        DatePeriodSet domPeriodSet; 
        /* create domain periods - only exist if hier flags are used */      
        DBA_DYNFLD_STP *    sDomPeriodTab = NULLDYNSTPTR;
        int                 sDomPeriodNb = 0;

   	    if ((ret = DBA_ExtractHierEltRecWithFilterSt(hierHead, S_PerfComputationPeriod, FALSE,  FIN_FilterPtfDomainCompPeriod,
                                        ptfPtr, FIN_CmpCompPeriodBeginDate,  &sDomPeriodNb, &sDomPeriodTab)) != RET_SUCCEED)
	    {
		    return(ret);
	    }

        mp.ownerPtr(sDomPeriodTab);
        /* merge dom dates */
        for(int j=0;j<sDomPeriodNb;j++)
        {
            DatePeriod domainPeriod(GET_DATETIME(sDomPeriodTab[j],S_PerfComputationPeriod_BeginDate),GET_DATETIME(sDomPeriodTab[j],S_PerfComputationPeriod_EndDate));
            // look ahead to merge periods
            {
                auto nextIdx = j + 1;
                while(nextIdx < sDomPeriodNb)
                {   // next period overlaps, merge into existing.
                    DatePeriod nextPeriod(GET_DATETIME(sDomPeriodTab[nextIdx],S_PerfComputationPeriod_BeginDate),GET_DATETIME(sDomPeriodTab[nextIdx],S_PerfComputationPeriod_EndDate));
                    if(nextPeriod.cmpBegin(domainPeriod.getEnd()) <= 0 && nextPeriod.cmpEnd(domainPeriod.getEnd()) > 0)
                    {
                        domainPeriod.setEnd(nextPeriod.getEnd());
                        j++; // already handled
                    }
                    else
                    {   // advance to next new range
                        break;
                    }
                    nextIdx++;
                }
            }
                
            domPeriodSet.insert(domainPeriod);
        }      
       
        DatePeriodVec mergedPeriods;        
        if(domPeriodSet.empty())
        {
            dbPeriodSet.copyToVector(mergedPeriods);
        }
        else if(dbPeriodSet.empty())
        {
            domPeriodSet.copyToVector(mergedPeriods);
        }
        else
        {   // create intersection of db periods and domain
            // anchor by db period
            DatePeriodVec domPeriodVec;
            domPeriodSet.copyToVector(domPeriodVec);
            for(auto dbPeriod = dbPeriodSet.begin(); dbPeriod != dbPeriodSet.end();++dbPeriod)
            {
                DatePeriod mergedPeriod((*dbPeriod));
                for(size_t i=0;i< domPeriodVec.size();i++)
                {
                    if(domPeriodVec[i].cmpBegin(dbPeriod->getEnd()) >= 0 || domPeriodVec[i].cmpEnd(dbPeriod->getBegin()) <= 0)  
                    {   // unrelated
                        continue;
                    }
                    mergedPeriod.set(std::max(mergedPeriod.getBegin(),domPeriodVec[i].getBegin()), std::min(mergedPeriod.getEnd(),domPeriodVec[i].getEnd()));
                    // look ahead if multiple periods are needed
                    {
                        auto nextIdx = i + 1;
                        while(nextIdx < domPeriodVec.size())
                        {   // if next dom period overlaps  dbPeriod create multiples
                            DatePeriod nextPeriod(domPeriodVec[nextIdx]);
                            if(nextPeriod.cmpBegin(dbPeriod->getEnd()) < 0)
                            {
                                mergedPeriods.push_back(mergedPeriod);
                                // set period limts and assign as next merged period
                                nextPeriod.setEnd(std::min(nextPeriod.getEnd(),dbPeriod->getEnd()));
                                mergedPeriod = nextPeriod;
                                i++; // already handled
                            }
                            else
                            {   // advance to next new range
                                break;
                            }
                            nextIdx++;
                        }
                    }
                    mergedPeriods.push_back(mergedPeriod);
                }
            }
        }

        if(mergedPeriods.empty() == false && isSinglePtfTWR)
        {  //only send one max period
            DatePeriod singlePtfTWRPeriod(mergedPeriods[0].getBegin(),mergedPeriods[mergedPeriods.size()-1].getEnd());
            mergedPeriods.clear();
            mergedPeriods.push_back(singlePtfTWRPeriod);
        }

        if((ret = DBA_AddCompPeriodsToHier(hierHead,domainPtr,emptyPcpCd,ptfId,ptfCd,mergedPeriods,
            PerfCompPeriodTechNatEn::PtfMerged,hierPtfId)) != RET_SUCCEED)
        {
            return ret;
        }
    }

    /* 
     * for merged twr support limiting of start date
     */    
    for(auto it = virtualPtfs.begin();it != virtualPtfs.end();++it)
    {
        const ID_T ptfId = (*it);

         DBA_DYNFLD_STP ptfPtr = ptfPtrMap[ptfId];
        
        int compPeriodNb = 0;
        DBA_HierGetRecNbrWithFilterSt(hierHead, S_PerfComputationPeriod, FIN_FilterPtfPerfCompPeriod,ptfPtr, &compPeriodNb, FALSE);
        
        if(compPeriodNb == 0)
        {
            DatePeriodVec       mergedPeriods;
            DBA_DYNFLD_STP *    virtualCompPeriodTab = NULLDYNSTPTR;
            int                 virtualCompPeriodNb = 0;

            /* get all final hier records, or just top hier if pcp overrride */
   	        if ((ret = DBA_ExtractHierEltRecWithFilterSt(hierHead, S_PerfComputationPeriod, FALSE, FIN_FilterPerfCompPeriodForVirtual, 
                                                           nullptr, FIN_CmpCompPeriodBeginDate,  &virtualCompPeriodNb, &virtualCompPeriodTab)) != RET_SUCCEED)
	        {
		        return(ret);
	        }

            mp.ownerPtr(virtualCompPeriodTab);
            if(virtualCompPeriodNb == 0)
            {
                continue;
            }

            DatePeriod mergedPeriod;

            for(int i=0;i<virtualCompPeriodNb;i++)
        { 
                mergedPeriod.setBegin((i==0) ? GET_DATETIME(virtualCompPeriodTab[i],S_PerfComputationPeriod_BeginDate)
                                             // keep widest begin date within the calc from/till
                                             :  std::min(mergedPeriod.getBegin(),GET_DATETIME(virtualCompPeriodTab[i],S_PerfComputationPeriod_BeginDate))
                );
            }
            
            mergedPeriods.push_back(mergedPeriod);

            std::string ptfCd = IS_NULLFLD(ptfPtr,A_Ptf_Cd) ? "" : GET_CODE(ptfPtr,A_Ptf_Cd); 
            if((ret = DBA_AddCompPeriodsToHier(hierHead,domainPtr,emptyPcpCd,ptfId,ptfCd,mergedPeriods,
                PerfCompPeriodTechNatEn::PtfMerged,ZERO_ID)) != RET_SUCCEED)
            {
                return ret;
            }
        }
    }

    if(EV_TracePerf)
    {
        std::string filenamePrefix("perf_comp_period_");
	    DBA_HierDump(hierHead,S_PerfComputationPeriod, FALSE, nullptr,filenamePrefix.c_str());
    }

    return ret;
}

/************************************************************************
**  Function             : DBA_FillVectorIdAndLoadData()
**
**  Description          : Fill all temporary tables with objects needed for all links.
**
**  Arguments            : domainPtr    : pointer on domain of financial function
**                         hierHead     : pointer on hierarchy
**                         allocConn    : the connection number allocated
**
**  Return               : RET_SUCCEED              : if no problem was detected
**                         a RET_CODE               : if a message has been received
**
**  Creation Date        : 020919 - DDV - REF7758
**  Last Modification    :
*************************************************************************/
RET_CODE DBA_FillVectorIdAndLoadData(DBA_DYNFLD_STP    domainPtr,
                                     DBA_HIER_HEAD_STP hierHead,
                                     DbiConnection     &dbiConn)
{
    DBA_DYNFLD_STP  *fromObjectLnkTab=NULLDYNSTPTR;
    DBA_DYNFLD_STP  *toObjectLnkTab=NULLDYNSTPTR;
    int             fromObjectLnkNbr, toObjectLnkNbr=0, fromPos, toPos;
    ID_T            prevObjId=0, prevEntityId=0;  /* PMSTA08801 - DDV - 091126 */
    RET_CODE        ret=RET_SUCCEED;

    /* extract all ObjectLink Order by from object id */
   	if ((ret = DBA_ExtractHierEltRec(hierHead, A_ObjectLnk, FALSE,
                                     NULLFCT, FIN_CmpObjectLnkFromObjectId,
                                     &fromObjectLnkNbr, &fromObjectLnkTab)) != RET_SUCCEED)
    {
        return(ret);
    }

    /* extract all ObjectLink Order by to object id */
   	if ((ret = DBA_ExtractHierEltRec(hierHead, A_ObjectLnk, FALSE,
                                     FIN_FilterUsedObjectLnk, FIN_CmpObjectLnkToObjectId,
                                     &toObjectLnkNbr, &toObjectLnkTab)) != RET_SUCCEED)
    {
        FREE(fromObjectLnkTab);
        return(ret);
    }

    /* REF10329 - LJE - 040930 : Move here */
    /* truncate table #vector_id */
    if ((ret=DBA_CreateTempTables(dbiConn, TCT_VECTOR_ID)) != RET_SUCCEED)
    {
        FREE(fromObjectLnkTab);
        FREE(toObjectLnkTab);
        return(ret);
    }

    RequestHelper requestHelper(&dbiConn);

    for(toPos=0, fromPos=0; toPos < toObjectLnkNbr; toPos++)
    {
        if (prevObjId == GET_ID(toObjectLnkTab[toPos], A_ObjectLnk_ToObjectId) &&
            prevEntityId == GET_DICT(toObjectLnkTab[toPos], A_ObjectLnk_ToEntDictId))
        {
            continue;
        }

        /* search same id */
        while (fromPos < fromObjectLnkNbr &&
               GET_ID(fromObjectLnkTab[fromPos], A_ObjectLnk_FromObjectId) <
               GET_ID(toObjectLnkTab[toPos], A_ObjectLnk_ToObjectId))
            fromPos++;

        /* check the entity */
        while (fromPos < fromObjectLnkNbr &&
               GET_ID(fromObjectLnkTab[fromPos], A_ObjectLnk_FromObjectId) ==
               GET_ID(toObjectLnkTab[toPos], A_ObjectLnk_ToObjectId) &&
               GET_DICT(fromObjectLnkTab[fromPos], A_ObjectLnk_FromEntDictId) !=
               GET_DICT(toObjectLnkTab[toPos], A_ObjectLnk_ToEntDictId))
            fromPos++;

        /* if to object not fount in from object array, add it into #vector_id */
        if (fromPos == fromObjectLnkNbr ||
            /* REF10329 - LJE - 040528 */
            GET_ID(fromObjectLnkTab[fromPos], A_ObjectLnk_FromObjectId) != GET_ID(toObjectLnkTab[toPos], A_ObjectLnk_ToObjectId) ||
            GET_ID(fromObjectLnkTab[fromPos], A_ObjectLnk_FromEntDictId) != GET_ID(toObjectLnkTab[toPos], A_ObjectLnk_ToEntDictId))
        {
            DBA_DYNFLD_STP vectorIdStp = requestHelper.getNewRecordForBatch(A_VectorId);

            COPY_DYNFLD(vectorIdStp,           A_VectorId,  A_VectorId_Id, 
                        toObjectLnkTab[toPos], A_ObjectLnk, A_ObjectLnk_ToObjectId);
            COPY_DYNFLD(vectorIdStp, A_VectorId, A_VectorId_EntityDictId,
                        toObjectLnkTab[toPos], A_ObjectLnk, A_ObjectLnk_ToEntDictId);
        }
        prevObjId = GET_ID(toObjectLnkTab[toPos], A_ObjectLnk_ToObjectId);
        prevEntityId = GET_DICT(toObjectLnkTab[toPos], A_ObjectLnk_ToEntDictId);
    }

    ret = requestHelper.executeBatch();

    /* select all data */
    ret = DBA_LoadInstrPtfStrat(&hierHead, domainPtr, dbiConn, DBA_ROLE_USE_VECTOR_ID); /* PMSTA12427-CHU-110725 */

    FREE(fromObjectLnkTab);
    FREE(toObjectLnkTab);
	return(ret);
}

/************************************************************************
**  Function             : DBA_LoadInstrPtfStrat()
**
**  Description          : Load Instruments, portfolios and startegies
**                         if role is UNUSED, the load is based on content of
**                             #dom_instr #dom_port and #dom_strat
**                         else if role is DBA_ROLE_USE_VECTOR_ID. the load is based
**                             on content of #vector_id
**
**  Arguments            :
**
**  Return               : RET_SUCCEED or error code
**
**  Creation             : REF7758 - DDV - 021001
**
*************************************************************************/
RET_CODE DBA_LoadInstrPtfStrat(DBA_HIER_HEAD_STP  *hierHeadPtr,
                               DBA_DYNFLD_STP      domainPtr,
                               DbiConnection      &dbiConn,
                               int                 role)
{
    RET_CODE            ret=RET_SUCCEED;
    DbiConnectionHelper dbiConnHelper(&dbiConn, false);
    MemoryPool          mp;

	const DBA_DYNST_ENUM *outputStLst[] =  {&A_Instr, /* REF8844 - LJE - 030416 */
							                &A_Ptf,
                                            &A_Strat,
	                                        &S_PerfComputationPeriod};
	int             outputBlkNb = 4;
	DBA_DYNFLD_STP  *data[4]={NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR};
	int             rows[4] = {0,0,0,0};
    const int       aPtfIdx = 1;

    /* Begin function */

    /* Select instr, port and strat in DB, for each #dom_port, #dom_strat and #dom_instr */
    
   	if (dbiConnHelper.dbaMultiSelect(Ptf, role, domainPtr, data, rows) != RET_SUCCEED)
    {
        MSG_SendMesg(RET_DBA_ERR_NODATA, 2 , FILEINFO, "perf storage param");
		return(RET_DBA_ERR_NODATA);
    }

	if (GET_ENUM(domainPtr, A_Domain_OutputTpEn) == TSLDimPort)
	{
        ret = DBA_TransferDomPortToTSL(hierHeadPtr, domainPtr, dbiConnHelper);
		for (int i=0; i<outputBlkNb && ret == RET_SUCCEED; i++)
		{
			DBA_FreeDynStTab(data[i], rows[i], *(outputStLst[i]));	/* PMSTA14443 - DDV - 120709 - Purify */
		}

		return(ret);
	}

	if (*hierHeadPtr == (DBA_HIER_HEAD_STP) NULL)
	{
		if ((*hierHeadPtr = DBA_CreateHier())==NULL)    /* REF5239 - RAK - 001025 */
		{
			MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO,
			            "DBA_LoadInstrPtfStrat: Cannot create hierarchy");
			ret = RET_DBA_ERR_MD;
		}
	}

	/* Distribute loaded data (if creation is ok) */
	for (int i=0; i<outputBlkNb && ret == RET_SUCCEED; i++)
	{
		if (ret == RET_SUCCEED 
            && (ret = DBA_AddHierRecordList((*hierHeadPtr), data[i], rows[i], *(outputStLst[i]), TRUE)) == RET_SUCCEED)
        {       /* save for ptftab use */
                mp.ownerPtr(data[i]);
		}
        else
        {
            DBA_FreeDynStTab(data[i], rows[i], *(outputStLst[i]));	/* PMSTA14443 - DDV - 120709 - Purify */
        }
	}
    
    if(ret != RET_SUCCEED || (ret = DBA_MergePerfCompPeriods((*hierHeadPtr),domainPtr, data[aPtfIdx], rows[aPtfIdx])) != RET_SUCCEED)
    {
        return(ret);
    }


	/* PMSTA02013 - RAK - 071112 - Update link here because they are needed for next treatment (in DBA_SearchBestPSP()) */
	if ((ret = DBA_SetHierLnkUsed((*hierHeadPtr), A_Ptf, A_Ptf_HierPtf_Ext)) != RET_SUCCEED ||
        (ret = DBA_SetHierLnkUsed((*hierHeadPtr), A_Ptf, A_Ptf_HierChildrenPtf_Ext)) != RET_SUCCEED) /* PMSTA03044 - LJE - 070907 */
    {
	        return(ret);
    }

    DBA_SetHierLnkUsed((*hierHeadPtr), A_Ptf, A_Ptf_ParentHistoPCP_Ext);          /* WEALTH-16752 - DDV - 241120 */
    DBA_SetHierLnkUsed((*hierHeadPtr), A_Ptf, A_Ptf_ChildrenHistoPCP_Ext);        /* WEALTH-16752 - DDV - 241120 */
    DBA_SetHierLnkUsed((*hierHeadPtr), A_Ptf, A_Ptf_AllHierChildrenHistoPCP_Ext); /* WEALTH-16752 - DDV - 241120 */
    DBA_SetHierLnkUsed((*hierHeadPtr), S_PerfComputationPeriod, S_PerfComputationPeriod_Ptf_Ext);       /* WEALTH-16752 - DDV - 241125 */
    DBA_SetHierLnkUsed((*hierHeadPtr), S_PerfComputationPeriod, S_PerfComputationPeriod_ParentPtf_Ext); /* WEALTH-16752 - DDV - 241125 */
    DBA_SetHierLnkUsed((*hierHeadPtr), S_PerfComputationPeriod, S_PerfComputationPeriod_HierPtf_Ext);   /* WEALTH-16752 - DDV - 241125 */
    DBA_MakeAllRecLinks((*hierHeadPtr), S_PerfComputationPeriod);                                       /* WEALTH-16752 - DDV - 241125 */

	DBA_MakeAllRecLinks((*hierHeadPtr), A_Ptf);

    return(RET_SUCCEED);
}

/************************************************************************
**  Function             : DBA_LoadInstrPtfStratCurrThird()
**
**  Description          : Load Instruments, portfolios and startegies
**                         if role is UNUSED, the load is based on content of
**                             #dom_instr #dom_port #dom_strat  #dom_curr, #dom_third
**                         else if role is ... to determine fir future
**
**  Arguments            :
**
**  Return               : RET_SUCCEED or error code
**
**  Creation             : LR-1743 - DLA - 160512
**
*************************************************************************/
EXTERN RET_CODE DBA_LoadInstrPtfStratCurrThird( DBA_HIER_HEAD_STP   *hierHeadPtr,
                                                DBA_DYNFLD_STP       domainPtr,
                                                DbiConnectionHelper& dbiConnHelper,
                                                int                  role)
{
    RET_CODE        ret = RET_SUCCEED;
    int             i;

    const DBA_DYNST_ENUM *outputStLst[] = { &A_Instr, &A_Ptf, &A_Strat, &A_Curr, &A_Third };

    int             outputBlkNb = 5;
    DBA_DYNFLD_STP  *data[5] = { NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR };
    int             rows[5] = { 0, 0, 0, 0, 0 };


    /* Begin function */

    /* Select instr, port and strat in DB, for each #dom_port, #dom_strat and #dom_instr */
    if (DBA_MultiSelect2(Ptf,
        role,
        NullDynSt,
        NULLDYNST,
        outputStLst,
        data,
        DBA_SET_CONN | DBA_NO_CLOSE,
        UNUSED,
        rows,
        dbiConnHelper,
        UNUSED) != RET_SUCCEED)
    {
        MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "perf storage param");
        return(RET_DBA_ERR_NODATA);
    }


    if (*hierHeadPtr == (DBA_HIER_HEAD_STP)NULL)
    {
        if ((*hierHeadPtr = DBA_CreateHier()) == NULL)    /* REF5239 - RAK - 001025 */
        {
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO,
                "DBA_LoadInstrPtfStrat: Cannot create hierarchy");
            ret = RET_DBA_ERR_MD;
        }
    }

    /* Distribute loaded data (if creation is ok) */
    for (i = 0; i<outputBlkNb && ret == RET_SUCCEED; i++)
    {
        if (ret == RET_SUCCEED)
        {
            ret = DBA_AddHierRecordList((*hierHeadPtr), data[i], rows[i], *(outputStLst[i]), TRUE);
        }
    }

    for (i = 0; i<outputBlkNb; i++)
        FREE(data[i]);

    /* PMSTA02013 - RAK - 071112 - Update link here because they are needed for next treatment (in DBA_SearchBestPSP()) */
    if ((ret = DBA_SetHierLnkUsed((*hierHeadPtr), A_Ptf, A_Ptf_HierPtf_Ext)) != RET_SUCCEED ||
        (ret = DBA_SetHierLnkUsed((*hierHeadPtr), A_Ptf, A_Ptf_HierChildrenPtf_Ext)) != RET_SUCCEED) /* PMSTA03044 - LJE - 070907 */
    {
        return(ret);
    }

    DBA_MakeAllRecLinks((*hierHeadPtr), A_Ptf);

    return(RET_SUCCEED);
}


/************************************************************************
**  Function             : DBA_SelStratHistoCompo()
**
**  Description          : For one strategy return a S_StratLnk for each compo
**                         of all history valid during the period.
**
**  Arguments            : stratId           : id of the strategy
**                         fromDate          : begin date of the global period
**                         tillDate          : end date of the global period
**                         parentStratLnkSt  : Parent strategy link (can be NULL)
**                         compoStratLnkTab  : pointer on array to be filled with strategy links
**                         compoStratLnkNbr  : pointer on the number of strategy link returned
**
**  Return               : RET_SUCCEED              : if no problem was detected
**                         a RET_CODE               : if a message has been received
**
**  Creation Date        : 021009 - DDV - REF7758
**  Last Modification    : REF9187 - LJE - 030616
*************************************************************************/
EXTERN RET_CODE DBA_SelStratHistoCompo(ID_T           stratId,
                                       DATE_T         gblFromDate,
                                       DATE_T         gblTillDate,
                                       DBA_DYNFLD_STP parentStratLnkSt,
                                       DBA_DYNFLD_STP **compoStratLnkTab,
                                       int            *compoStratLnkNbr)
{
    int            i, connectNo;
    DBA_DYNFLD_STP *lnkTab = NULLDYNSTPTR;
    DBA_DYNFLD_STP sStratLnk = NULLDYNST;
    int            lnkNbr = 0;
    DATE_T         endDate, prevDate, fromDate, tillDate;
    RET_CODE       ret=RET_SUCCEED;

    *compoStratLnkTab = NULL;
    *compoStratLnkNbr = 0;

    if (stratId <= 0 || gblFromDate == 0 || gblTillDate == 0)
    {
        return(RET_GEN_ERR_INVARG);
    }


    if (parentStratLnkSt != NULLDYNST)
    {
        /* get little period for call store proc */

        if (GET_DATETIME(parentStratLnkSt, S_StratLnk_BegDate).date > gblFromDate)
        {
            fromDate = GET_DATETIME(parentStratLnkSt, S_StratLnk_BegDate).date;
        }
        else
        {
            fromDate = gblFromDate;
        }

        if (GET_DATETIME(parentStratLnkSt, S_StratLnk_EndDate).date < gblTillDate)
        {
            tillDate = GET_DATETIME(parentStratLnkSt, S_StratLnk_EndDate).date;
        }
        else
        {
            tillDate = gblTillDate;
        }

        endDate = GET_DATETIME(parentStratLnkSt, S_StratLnk_EndDate).date;
    }
    else
    {
        fromDate = gblFromDate;
        tillDate = gblTillDate;
        endDate  = tillDate;
    }


    /* REF7758 - DDV - 021007 - get a connection and create #vector_id */
  	if ((connectNo = DBA_GetConnection(SqlServer)) == DBA_CONN_NOT_FOUND)
    {
        MSG_SendMesg(RET_DBA_ERR_NOFREESYNCCONN, 0, FILEINFO);
        return(DBA_CONN_NOT_FOUND);
    }

	if((ret = DBA_CreateTempTables(&connectNo, TCT_VECTOR_ID)) != RET_SUCCEED)
    {
		DBA_EndConnection(connectNo);
        return(ret);
    }

    /* select all valid compo in database */
    if ((sStratLnk = ALLOC_DYNST(S_StratLnk)) == NULLDYNST)
    {
		DBA_EndConnection(connectNo);
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "S_StratLnk");
        return(RET_MEM_ERR_ALLOC);
    }

    SET_ID(sStratLnk, S_StratLnk_StratId, stratId);
    SET_DATE(sStratLnk, S_StratLnk_BegDate, fromDate);
    SET_DATE(sStratLnk, S_StratLnk_EndDate, tillDate);

    ret = DBA_Select2(StratLnk, UNUSED, S_StratLnk, sStratLnk,
		              S_StratLnk, &lnkTab, DBA_SET_CONN | DBA_NO_CLOSE, UNUSED, &lnkNbr,
                      &connectNo, UNUSED);

    FREE_DYNST(sStratLnk, S_StratLnk);
	DBA_EndConnection(connectNo);

	if (ret != RET_SUCCEED)
	{
		ret = RET_DBA_ERR_NODATA;
		MSG_SendMesg(ret, 0, FILEINFO);
        return(ret);
	}

    if (lnkNbr == 0)
    {
        return(RET_SUCCEED);
    }

    if (lnkNbr > 1)
        TLS_Sort((char *) lnkTab, lnkNbr, sizeof(DBA_DYNFLD_STP),
			(TLS_CMPFCT *) DBA_CmpStratHisto, (PTR **) NULL, SortRtnTp_None);


    endDate = GET_DATETIME(parentStratLnkSt, S_StratLnk_EndDate).date;

    /* Remove elements out period (get for find end date) */
    for (i=0; i < lnkNbr && GET_DATE(lnkTab[i], S_StratLnk_BegDate) > tillDate; i++)
    {
        if (GET_DATE(lnkTab[i], S_StratLnk_BegDate) < endDate)
        {
            endDate = GET_DATE(lnkTab[i], S_StratLnk_BegDate);
        }

        FREE_DYNST(lnkTab[i], S_StratLnk);
        lnkTab[i] = NULL;
    }

    if (i < lnkNbr)
    {
        prevDate = GET_DATE(lnkTab[i], S_StratLnk_BegDate);

        *compoStratLnkTab = (DBA_DYNFLD_STP*)CALLOC(lnkNbr-i, sizeof(DBA_DYNFLD_STP));

        /* update begin and end date for the period (record are sorted by begin_d desc) */
        for (; i < lnkNbr; i++)
        {
            /* set end date */
            if (GET_DATE(lnkTab[i], S_StratLnk_BegDate) != prevDate)
            {
                endDate  = GET_DATE(lnkTab[i-1], S_StratLnk_BegDate);
                prevDate = GET_DATE(lnkTab[i], S_StratLnk_BegDate);
            }

            /* REF10820 - LJE - 041208 : Don't put the date after the end of strategy compo */
            if (GET_DATE(lnkTab[i], S_StratLnk_EndDate) > endDate)
            {
                SET_DATE(lnkTab[i], S_StratLnk_EndDate, endDate);
            }

            /* set begin date */
            if (GET_DATE(lnkTab[i], S_StratLnk_BegDate) < fromDate &&
                fromDate != tillDate)
            {
                SET_DATE(lnkTab[i], S_StratLnk_BegDate, fromDate);
            }

            (*compoStratLnkTab)[(*compoStratLnkNbr)] = ALLOC_DYNST(S_StratLnk);
            COPY_DYNST((*compoStratLnkTab)[(*compoStratLnkNbr)], lnkTab[i], S_StratLnk);
            (*compoStratLnkNbr)++;

        }
    }

    DBA_FreeDynStTab(lnkTab, lnkNbr, S_StratLnk);

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   DBA_CmpStratHisto()
**
**  Description :   strategies are sorted by date
**
**  Arguments   :   ptr1   pointer on dynamic structure type A_Strat
**                  ptr2   pointer on dynamic structure type A_Strat
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation D. : REF9187 - LJE - 030613
**  Last modif. :
**
*************************************************************************/
STATIC int DBA_CmpStratHisto(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    int cmp;

    /* Sort by begin_d (descending) */
    if ((cmp = CMP_DYNFLD(*ptr2, *ptr1, S_StratLnk_BegDate, S_StratLnk_BegDate, DateType)) != 0)
        return(cmp);

    return(cmp);
}

/************************************************************************
**
**  Function    :   DBA_CmpStratId()
**
**  Description :   strategies are sorted by A_Strat_Id
**
**  Arguments   :   ptr1   pointer on dynamic structure type A_Strat
**                  ptr2   pointer on dynamic structure type A_Strat
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation D. : REF7758 - DDV - 021002
**  Last modif. :
**
*************************************************************************/
STATIC int DBA_CmpStratId(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    return(CMP_ID(GET_ID((*ptr1), A_Strat_Id) , GET_ID((*ptr2), A_Strat_Id))); /* DLA - REF9089 - 030508 */
}

/************************************************************************
**
**  Function    :   DBA_CmpInstrId()
**
**  Description :   strategies are sorted by A_Instr_Id
**
**  Arguments   :   ptr1   pointer on dynamic structure type A_Strat
**                  ptr2   pointer on dynamic structure type A_Strat
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation D. : REF7758 - DDV - 021002
**  Last modif. :
**
*************************************************************************/
STATIC int DBA_CmpInstrId(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    return(CMP_ID(GET_ID((*ptr1), A_Instr_Id) , GET_ID((*ptr2), A_Instr_Id))); /* DLA - REF9089 - 030508 */
}

/************************************************************************
**
**  Function    :   DBA_FilterStratWithBench()
**
**  Description :   Return only strategy with a benchmark defined
**                  return TRUE  -> record must be extract
**                         FALSE -> record musn't be extract
**
**  Arguments   :   dynSt    element pointer
**                  dynStTp  element description enum
**
**  Return      : TRUE or FALSE
**
**  Creation Date : REF7758 - DDV - 021002
**
*************************************************************************/
STATIC int DBA_FilterStratWithBench(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP notUse)
{
	if (IS_NULLFLD(dynSt, A_Strat_BenchEntityDictId) == FALSE &&
        IS_NULLFLD(dynSt, A_Strat_BenchObjId) == FALSE )
        return(TRUE);
    return(FALSE);
}

/************************************************************************
**
**  Function    :   DBA_FilterInstrWithIndex()
**
**  Description :   Return only instrument with an index defined
**                  return TRUE  -> record must be extract
**                         FALSE -> record musn't be extract
**
**  Arguments   :   dynSt    element pointer
**                  dynStTp  element description enum
**
**  Return      : TRUE or FALSE
**
**  Creation Date : REF7758 - DDV - 021002
**
*************************************************************************/
STATIC int DBA_FilterInstrWithIndex(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP notUse)
{
	if (IS_NULLFLD(dynSt, A_Instr_IdxInstrId) == FALSE)
        return(TRUE);
    return(FALSE);
}

/************************************************************************
**  Function             : FIN_GenerateSPfromExtRA()
**
**  Description          : Generate StandardPerf record based on an array of ExtReturnAnalysis records
**
**  Arguments            : extRATab : pointer on array of ExtReturnAnaylsis records
**                         extRANbr : number of ExtReturnAnaylsis records
**                         spTab    : pointer on array to create
**                         spNbr    : pointer on the number of created records
**
**  Return               : RET_SUCCEED              : if no problem was detected
**                         a RET_CODE               : if a message has been received
**
**  Creation Date        : 021106 - DDV - REF7758
**  Last Modification    :
*************************************************************************/
EXTERN RET_CODE DBA_GenerateSPFromExtRA(DBA_DYNFLD_STP *extRATab,
                                        int            extRANbr,
                                        DBA_DYNFLD_STP **spTab,
                                        int            *spNbr)
{
    RET_CODE       ret = RET_SUCCEED;
    int            i=0;
    DBA_DYNFLD_STP sp=NULLDYNST;

    if (extRANbr == 0)
        return(RET_SUCCEED);

    /* alloc the array of extRA */
    if ((*spTab = (DBA_DYNFLD_STP *) CALLOC(extRANbr, sizeof (DBA_DYNFLD_STP))) == NULL)
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
        return(RET_MEM_ERR_ALLOC);
    }

    for (i=0; i<extRANbr; i++)
    {
        /* generate an StandardPerf record only for Global lines */
        if (IS_NULLFLD(extRATab[i], A_ExtRetAnalysis_MktSegtId ) == TRUE &&
            IS_NULLFLD(extRATab[i], A_ExtRetAnalysis_InstrId ) == TRUE)
        {
            /* alloc a new sp */
            if ((sp = ALLOC_DYNST(A_StandardPerf)) == NULLDYNST)
            {
                MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
                return(RET_MEM_ERR_ALLOC);
            }

            (*spTab)[*spNbr]=sp;

            /* REF9743 - LJE - 040204 */
            CONVERT_DYNST(sp, A_StandardPerf, extRATab[i], A_ExtRetAnalysis);

            (*spNbr)++;
        }
    }

    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_GetDomainFreqEnForPAA
**
**  Description :   Return the current frequency unit, according the domain
**                  and the kind of output entity
**
**  Arguments   :
**
**  Return      :
**
**
**
**  Creation D. : PMSTA07331 - LJE - 081030
**  Last modif. :
**
*************************************************************************/
FREQUNIT_ENUM FIN_GetDomainFreqEnForPAA(DBA_DYNFLD_STP    domainPtr,
										OBJECT_ENUM       outObjEn)
{

	FIELD_IDX_T   freqEnIdx;

	if (outObjEn == StandardPerf)
	{
		freqEnIdx = A_Domain_Freq2UnitEn;
	}
	else if (outObjEn == PerfAttrib)
	{
        /* PMSTA-10869 - LJE - 110104 - For perf attrib, only day or month is valid */
        if (GET_ENUM(domainPtr, A_Domain_PerfAttribFreqEn) == PerfAttribFreq_TWR ||
            (FREQUNIT_ENUM) GET_ENUM(domainPtr, A_Domain_Freq1UnitEn) == FreqUnit_Day)
    		return (FreqUnit_Day);

        return (FreqUnit_Month);
	}
	else
	{
		freqEnIdx = A_Domain_Freq1UnitEn;
	}

     /* PMSTA-10869 - LJE - 110104 - allow only Month and Day */
    if (((FREQUNIT_ENUM) GET_ENUM(domainPtr, freqEnIdx)) != FreqUnit_Month &&
        ((FREQUNIT_ENUM) GET_ENUM(domainPtr, freqEnIdx)) != FreqUnit_Day)
        return (FreqUnit_Month);
    else
	    return ((FREQUNIT_ENUM) GET_ENUM(domainPtr, freqEnIdx));

}

/************************************************************************
**
**  Function    :   FIN_GetMinDomainFreqEnForPAA
**
**  Description :   Return the current frequency unit, according the domain
**                  and the kind of output entity
**
**  Arguments   :
**
**  Return      :
**
**
**
**  Creation D. : PMSTA07331 - LJE - 081030
**  Last modif. :
**
*************************************************************************/
FREQUNIT_ENUM FIN_GetMinDomainFreqEnForPAA(DBA_DYNFLD_STP    domainPtr)
{
	FREQUNIT_ENUM freqLong, freqShort, freqPerfAttrib, freq;

	freqLong = ((FREQUNIT_ENUM) GET_ENUM(domainPtr, A_Domain_Freq2UnitEn));
	freqShort = ((FREQUNIT_ENUM) GET_ENUM(domainPtr, A_Domain_Freq1UnitEn));
	freqPerfAttrib = FIN_GetDomainFreqEnForPAA(domainPtr, PerfAttrib);

	freq = freqLong;

	if (GET_ENUM(domainPtr, A_Domain_ReturnAnalysisEn) == PAARetAnalysis_All ||
		GET_ENUM(domainPtr, A_Domain_ReturnAnalysisEn) == PAARetAnalysis_PA)
	{
		if (freqPerfAttrib < freq)
		{
			freq = freqPerfAttrib;
		}
	}

	if (GET_ENUM(domainPtr, A_Domain_ReturnAnalysisEn) == PAARetAnalysis_All ||
		GET_ENUM(domainPtr, A_Domain_ReturnAnalysisEn) == PAARetAnalysis_RA)
	{
		if (freqShort < freq)
		{
			freq = freqShort;
		}
	}

	return freq;

}

/************************************************************************
**  Function             : DBA_UseCompPeriodsForStratLnk()
**
**  Description          : Fetch Ptf Comp Periods dates to filter Strat links
**
**  Arguments            : domainPtr : pointer on Domain
**                         ptfId : Ptf ID
**                         interpFromDate: Domain From Date
**                         interpTillDate: Domain Till Date
**
**  Return               : RET_SUCCEED : if no problem
**                         a RET_CODE: if all okay
**
**  Creation Date        :  NRAO-PMSTA-27728-190211
**  Last Modification    :  PMSTA-50467 - JBC 221222
*************************************************************************/
RET_CODE DBA_UseCompPeriodsForStratLnk(DBA_DYNFLD_STP  domainPtr,
                                       DBA_HIER_HEAD_STP hierHead,    /* PMSTA-50467 - JBC - 221112 */
                                       ID_T           ptfId,
                                       DATETIME_T         *interpFromDate,
                                       DATETIME_T         *interpTillDate,
                                       CODE_T         *ptfCode,
                                       DatePeriodVec & compPeriods)
{
    RET_CODE       ret = RET_SUCCEED;
    DATETIME_T     fromDate, tillDate;
    FLAG_T         allocFlg = FALSE;
    DBA_DYNFLD_STP ptfPtr = NULLDYNST;

    (*ptfCode)[0] = END_OF_STRING;

    fromDate = *interpFromDate;

    tillDate = *interpTillDate;

    if ((ret = DBA_GetPtfById(ptfId, FALSE, &allocFlg, &ptfPtr,
                              NULL, UNUSED, UNUSED)) != RET_SUCCEED)
    {
        return(ret);
    }

    /* WEALTH-6600 - JBC - 20240503 */
    if (FIN_LimitByPtfCompPeriods(domainPtr, hierHead, ptfPtr, &fromDate, &tillDate,compPeriods))
    {
        *interpFromDate = fromDate;
        *interpTillDate = tillDate;
    }

    if(compPeriods.empty())
    {
        strcpy(*ptfCode, GET_CODE(ptfPtr, A_Ptf_Cd));
        ret = RET_DBA_ERR_NODATA;
    }


    if (allocFlg == TRUE)
    {
        FREE_DYNST(ptfPtr, A_Ptf);
    }

    return(ret);
}

/************************************************************************
 **   END  dbaperfa.c
 *************************************************************************/


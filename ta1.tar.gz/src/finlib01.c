/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define FINLIB01_C

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H
#define MATH_H

#include "unidef.h"     /* Mandatory */
#include "gen.h"
#include "date.h"
#include "dba.h"
#include "syslib.h"     /* PMO - Rename our sys.h to syslib.h and use it */
#include "tls.h"
#include "hier.h"
#include "dbaexec.h"
#include "fin.h"
#include "scpt.h"
#include "scptyl.h"
#include "scelib.h"     /* REF5416 - RAK - 010118 */
#include "ope.h"     /* REF5416 - RAK - 010118 */

/* REF5248 - RAK - 001005 */
/* Suppress FIN_CUrr_Hash_Table_init and FIN_Curr_Hash_Table_Get() */
/* and create in new file dbacurr.c DBA_CurrenciesMapInit() and DBA_CurrHashTableGet() */

/************************************************************************
**      External entry points
**
**  FIN_ComputeDebtScript()	        Compute debt positions with script nature.
**  FIN_ComputeDebtSimpleScript()    Compute all debt positions with simple script val rule.
**  FIN_ComputeDebtSimpleScriptPos() Compute one debt positions with simple script nature.
**  FIN_GenAccrNetValuePos()	     Generate accrued value and net value position.
**  FIN_MktVal() 		            This function allows to compute the value of a position.
**  FIN_PtfDefAccount()		        Get Default payment account for a given currency and portfolio.
**  FIN_Qty()			            Obtains the quantity of the position.
**  FIN_Round() 		            Round an amount depending on currency parameters.
**
*************************************************************************/

/************************************************************************
**      Local functions
**
**  FIN_CmpPosValRuleInstr()	Position table is sort by script def or others rule.
**  FIN_NetVal() 		        Obtains the value excluding any accrued interest of a position.
**  FIN_NetValDebt()		    Obtains the value of debt.
**  FIN_SetAccrValueAmt()	    Set all accrued value of extended position using pos val.
**  FIN_SetBookUnrealLossAmt()	Set all unrealised book value of extended position.
**  FIN_SetBookUnrealProfitAmt()Set all unrealised book value of extended position.
**  FIN_SetNetValueAmt()	    Set all net value of extended position using pos val.
**  FIN_SetUnrealPLAmt()	    Set all unrealised PL value of extended position using amt.
**  FIN_SetZeroPosAmt() 	    Set position amounts to value 0.
**  FIN_ResetTotPhase()         Reset to 0 all totfctPhase for totfctTab
**
*************************************************************************/

/************************************************************************
**      Static definitions & data
*************************************************************************/
STATIC RET_CODE FIN_NetVal(DATETIME_T, ID_T, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP,
                           char, NUMBER_T*, DBA_HIER_HEAD_STP),
		FIN_NetValDebt(DATETIME_T, ID_T, DBA_DYNFLD_STP, DBA_DYNFLD_STP, char,
	                       NUMBER_T*, double, DBA_DYNFLD_STP, DBA_HIER_HEAD_STP);


STATIC int 	FIN_CmpPosValRuleInstr(DBA_DYNFLD_STP*, DBA_DYNFLD_STP*);


STATIC void	FIN_SetAccrValueAmt(DBA_DYNFLD_STP, DBA_DYNFLD_STP),
		FIN_SetBookUnrealLossAmt(DBA_DYNFLD_STP, DBA_DYNFLD_STP),
		FIN_SetBookUnrealProfitAmt(DBA_DYNFLD_STP, DBA_DYNFLD_STP),
		FIN_SetNetValueAmt(DBA_DYNFLD_STP, DBA_DYNFLD_STP),
		FIN_SetUnrealPLAmt(DBA_DYNFLD_STP, ID_T, AMOUNT_T),
		FIN_ResetTotPhase(SCPT_ARG_STP);

/************************************************************************
**      Functions
*************************************************************************/

/************************************************************************
**
**  Function    :   FIN_GetAccFlag()
**
**  Description :   Get the current accounting flag according the domain
**                  and the application parameters
**
**  Arguments   :
**
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   PMSTA-13140 - LJE - 120319
**  Modif    	:
**
*************************************************************************/
RET_CODE FIN_GetAccFlag(DBA_DYNFLD_STP	domainPtr,
						DBA_DYNFLD_STP	currExtPosStp,
						FLAG_T         *futAccFlgPtr,
						FLAG_T         *fwdAccFlgPtr,
						FLAG_T         *termAccFlgPtr)
{
	RET_CODE	        ret=RET_SUCCEED;
	FLAG_T		        accFlgInReturnFlg;
	ID_T                perfExpoListId;

	DBA_DYNFLD_STP      mainPos, instrPtr;

	GEN_GetApplInfo(FutAccFlag,  futAccFlgPtr);
	GEN_GetApplInfo(FwdAccFlag,  fwdAccFlgPtr);
	GEN_GetApplInfo(TermAccFlag, termAccFlgPtr);
	GEN_GetApplInfo(ApplAccFlagInReturn, &accFlgInReturnFlg);  /* REF8876 - RAK - 030828 */
	GEN_GetApplInfo(ApplPerfExposureList, &perfExpoListId);

	if (domainPtr == NULL)
		return ret;

    if(GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_Return ||
	   GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_OnLineMktValuePL ||
       GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_SynthAdmin)
    {
		if (accFlgInReturnFlg == FALSE)
		{
			(*fwdAccFlgPtr)  = FALSE;
			(*futAccFlgPtr)  = FALSE;
			(*termAccFlgPtr) = FALSE;
		}
		else if (currExtPosStp != NULL)
		{
			/* PMSTA-10111 - RAK - 110405 - Verify forward PERF_EXPOSURE_LIST flag */
			/* PARTICULAR CASE if we are on a 1 leg valorisation but in risk and FWD in list */
			/* we perform a risk view on 2 legs */
			if (GET_FLAG(domainPtr, A_Domain_RiskExpoFlg) == TRUE)
			{
				RISKFUTRULE_ENUM    riskFut;
				GEN_GetApplInfo(ApplRiskFutRule, &riskFut);	/* PMSTA-9378 - RAK - 101025 */

				(*termAccFlgPtr) = FALSE;

				if (perfExpoListId == 0)
				{
					(*fwdAccFlgPtr)  = FALSE;
					(*futAccFlgPtr)  = FALSE;
				}

				/* get main position and instrument to verify forward PERF_EXPOSURE_LIST flag */
				if ((*fwdAccFlgPtr) == TRUE &&
					GET_EXTENSION_PTR(currExtPosStp, ExtPos_A_Instr_Ext) != NULL &&
					(instrPtr = *(GET_EXTENSION_PTR(currExtPosStp, ExtPos_A_Instr_Ext))) != NULL &&
					GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_Forward &&
					GET_FLAG(instrPtr, A_Instr_NoPerfExpoFlg) == FALSE)
				{
					(*fwdAccFlgPtr)  = FALSE;
				}
				if ((*fwdAccFlgPtr) == TRUE &&
					GET_EXTENSION_PTR(currExtPosStp, ExtPos_Main_ExtPos_Ext) != NULL &&
					(mainPos = *(GET_EXTENSION_PTR(currExtPosStp, ExtPos_Main_ExtPos_Ext))) != NULL &&
					GET_EXTENSION_PTR(mainPos, ExtPos_A_Instr_Ext) != NULL &&
					(instrPtr = *(GET_EXTENSION_PTR(mainPos, ExtPos_A_Instr_Ext))) != NULL &&
					GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_Forward &&
					GET_FLAG(instrPtr, A_Instr_NoPerfExpoFlg) == FALSE)
				{
					(*fwdAccFlgPtr)  = FALSE;
				}

				if ((*futAccFlgPtr) == TRUE &&
					GET_FLAG(domainPtr, A_Domain_RiskExpoFlg) == TRUE &&
					riskFut == RiskFutRule_UnderlyPosAndTimeValue)
				{
					if (GET_EXTENSION_PTR(currExtPosStp, ExtPos_A_Instr_Ext) != NULL &&
						(instrPtr = *(GET_EXTENSION_PTR(currExtPosStp, ExtPos_A_Instr_Ext))) != NULL &&
						GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_Future &&
						GET_FLAG(instrPtr, A_Instr_NoPerfExpoFlg) == FALSE)
					{
						(*futAccFlgPtr) = FALSE;
					}
					else if (GET_EXTENSION_PTR(currExtPosStp, ExtPos_Main_ExtPos_Ext) != NULL &&
							 (mainPos = *(GET_EXTENSION_PTR(currExtPosStp, ExtPos_Main_ExtPos_Ext))) != NULL &&
							 GET_EXTENSION_PTR(mainPos, ExtPos_A_Instr_Ext) != NULL &&
							 (instrPtr = *(GET_EXTENSION_PTR(mainPos, ExtPos_A_Instr_Ext))) != NULL &&
							 GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_Future &&
							 GET_FLAG(instrPtr, A_Instr_NoPerfExpoFlg) == FALSE)
					{
						(*futAccFlgPtr) = FALSE;
					}
				}
			}
		}
    }
	/* PMSTA-9489 - RAK - 100622 - Allocate order cash resulting % of portfolio */
	/* must work with a FWD/FUT/TERM ACC FLAG setted to TRUE (elsewhere % of cash mkt segment is wrong) */
	else if (GET_DICT(domainPtr, A_Domain_InitialFctDictId) == DictFct_AllocateOrder &&
		     (DOMORDERALLOCNAT_ENUM) GET_ENUM(domainPtr, A_Domain_OrderAllocNatEn) == DomOrderAllocNat_CashResultPctPtf)
	{
		(*fwdAccFlgPtr)  = FALSE;
		(*futAccFlgPtr)  = FALSE;
		(*termAccFlgPtr) = FALSE;
	}

	return ret;
}

/************************************************************************
**
**  Function    :   FIN_CmpPosInstrIdRefNat()
**
**  Description :   Position table is sort by
**  			    1 - Instrument ID
**                  2 - Put on front positions with a refnat none, *open or FutWMP
**                      (And on back  positions with a refnat close or fifo)
**                  3 - The begin date
**                  4 - The code
**
**  Arguments   :   ptr1   pointer on dynamic structure type ExtPos
**                  ptr2   pointer on dynamic structure type ExtPos
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Last modif. :   PMSTA05966 - 090525 - PMO : Logical Fusion - Generic Money Market Instrument - Sell Operation with reference nature "Close" doesn't merge with respective "Open" Operation
**                  PMSTA-17898 - 160414 - PMO : New Fusion Criteria to manage the contract dates for margin calls after partial closing
**
*************************************************************************/
int FIN_CmpPosInstrIdRefNat(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    const DBA_DYNFLD_STP pos1 = *ptr1;
    const DBA_DYNFLD_STP pos2 = *ptr2;

    /* Criteria 1 */
    int ret = CMP_ID(GET_ID(pos1, ExtPos_InstrId), GET_ID(pos2, ExtPos_InstrId));

    if (ret == 0)
    {
        /* Criteria 2 */
        const POSREFNAT_ENUM pos1RefNat = (POSREFNAT_ENUM)GET_ENUM(pos1, ExtPos_RefNatEn);
        const POSREFNAT_ENUM pos2RefNat = (POSREFNAT_ENUM)GET_ENUM(pos2, ExtPos_RefNatEn);

        const int pos1Front =   pos1RefNat == PosRefNat_None        ||
                                pos1RefNat == PosRefNat_Open        ||
                                pos1RefNat == PosRefNat_FwdOpen     ||
                                pos1RefNat == PosRefNat_TermOpen    ||
                                pos1RefNat == PosRefNat_FutOpen     ||
                                pos1RefNat == PosRefNat_FRAOpen     ||
                                pos1RefNat == PosRefNat_RepoOpen    ||
                                pos1RefNat == PosRefNat_RemereOpen  ||
                                pos1RefNat == PosRefNat_FXSwapOpen  ||
                                pos1RefNat == PosRefNat_FXSwapClose ||
                                pos1RefNat == PosRefNat_SwapOpen    ||
                                pos1RefNat == PosRefNat_FutWMP      ||
                                pos1RefNat == PosRefNat_FutContract;        /* PMSTA-17898 - 160414 - PMO */

        const int pos2Front =   pos2RefNat == PosRefNat_None        ||
                                pos2RefNat == PosRefNat_Open        ||
                                pos2RefNat == PosRefNat_FwdOpen     ||
                                pos2RefNat == PosRefNat_TermOpen    ||
                                pos2RefNat == PosRefNat_FutOpen     ||
                                pos2RefNat == PosRefNat_FRAOpen     ||
                                pos2RefNat == PosRefNat_RepoOpen    ||
                                pos2RefNat == PosRefNat_RemereOpen  ||
                                pos2RefNat == PosRefNat_FXSwapOpen  ||
                                pos2RefNat == PosRefNat_FXSwapClose ||
                                pos2RefNat == PosRefNat_SwapOpen    ||
                                pos2RefNat == PosRefNat_FutWMP      ||
                                pos2RefNat == PosRefNat_FutContract;        /* PMSTA-17898 - 160414 - PMO */

        ret = pos2Front - pos1Front;

        if (ret == 0)
        {
            /* Criteria 3 */
            ret = DATETIME_CMP(GET_DATETIME(pos1, ExtPos_BegDate), GET_DATETIME(pos2, ExtPos_BegDate));

            if (ret == 0)
            {
                /* Criteria 4 */
                ret = CMP_DYNFLD(pos1, pos2, ExtPos_OpenOpCd, ExtPos_OpenOpCd, GET_FLD_TYPE(ExtPos, ExtPos_OpenOpCd));
            }

            if (ret == 0)
            {
                /* Criteria 5 */
                /* PMSTA-59691 - MKK - 20240916  Added criteria to check Historical Quote  */
                ret = CMP_NUMBER(GET_NUMBER(pos1, ExtPos_HistQuote), GET_NUMBER(pos2, ExtPos_HistQuote));
            }
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :   FIN_CmpPosValRuleInstr()
**
**  Description :   Position table is sort by
**  			1 - Script Def with PosValId < 0 order by instr
**                      2 - Script Def with PosValId > 0 order by instr
**                      3 - Other rules order by instr
**
**  Arguments   :   ptr1   pointer on dynamic structure type ExtPos
**                  ptr2   pointer on dynamic structure type ExtPos
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
*************************************************************************/
STATIC int FIN_CmpPosValRuleInstr(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
	DBA_DYNFLD_STP    instrPtr1=NULL, instrPtr2=NULL;
	DBA_DYNFLD_STP    posValPtr1=NULL, posValPtr2=NULL;
	ID_T	          posValId1=0, posValId2=0;
	ENUM_T            rule1, rule2;

	/* DVP172 */
	instrPtr1 = NULL;
	if (GET_EXTENSION_PTR((*ptr1),  ExtPos_A_Instr_Ext) != NULL &&
	    (instrPtr1 = *(GET_EXTENSION_PTR((*ptr1),  ExtPos_A_Instr_Ext))) != NULL)
	{
	 	/* DVP172 */
		instrPtr2 = NULL;
		if (GET_EXTENSION_PTR((*ptr2),  ExtPos_A_Instr_Ext) != NULL &&
		    (instrPtr2 = *(GET_EXTENSION_PTR((*ptr2),  ExtPos_A_Instr_Ext))) != NULL)
		{
			rule1 = GET_ENUM(instrPtr1, A_Instr_ValRuleEn);
			rule2 = GET_ENUM(instrPtr2, A_Instr_ValRuleEn);

			/* BUG214 - XDI - 961126 */
			posValId1 = 0;
			if (rule1 == ValRule_Script)
			{
				posValPtr1 = NULL;
				if (GET_EXTENSION_PTR((*ptr1),  ExtPos_PosVal_Ext) != NULL &&
		    	            (posValPtr1 = *(GET_EXTENSION_PTR((*ptr1),  ExtPos_PosVal_Ext))) != NULL)
					posValId1 = GET_ID(posValPtr1, PosVal_Id);
			}

			posValId2 = 0;
			if (rule2 == ValRule_Script)
			{
				posValPtr2 = NULL;
				if (GET_EXTENSION_PTR((*ptr2),  ExtPos_PosVal_Ext) != NULL &&
		    	            (posValPtr2 = *(GET_EXTENSION_PTR((*ptr2),  ExtPos_PosVal_Ext))) != NULL)
					posValId2 = GET_ID(posValPtr2, PosVal_Id);
			}

			if (rule1 == rule2)
			{
				if (rule1 == ValRule_Script)
				{
					if (posValId1 > 0)
						return(+1);
					else if (posValId2 > 0)
						return(-1);
					else
						return(CMP_ID(GET_ID((*ptr1), ExtPos_InstrId),
					               GET_ID((*ptr2), ExtPos_InstrId))); /* DLA - REF9089 - 030508 */
				}
				else
					return(CMP_ID(GET_ID((*ptr1), ExtPos_InstrId),
				               GET_ID((*ptr2), ExtPos_InstrId))); /* DLA - REF9089 - 030508 */
			}
			else
			{
				if (rule1 == ValRule_Script)
					return(-1);
				else if (rule2 == ValRule_Script)
					return(+1);
				else
					return(CMP_ID(GET_ID((*ptr1), ExtPos_InstrId),
				               GET_ID((*ptr2), ExtPos_InstrId))); /* DLA - REF9089 - 030508 */
			}

		}
		else
			return(-1);
	}
	else
		return(+1);

}

#if 0
/************************************************************************
**
**  Function    :   FIN_ComputeDebtScript()
**
**  Description :   Compute debt positions with script nature
**
**  Arguments   :   domainPtr       pointer on domain
**                  posHierHead     hierarchy pointer
**                  valoProcFilter  filter for position to evaluate
**
**  Return      :   RET_SUCCEED or error code
**
**  Modif.		 : REF2313 - RAK - 980910
**  Modif.	:   REF2580 - SSO - 980727
**
*************************************************************************/
RET_CODE FIN_ComputeDebtScript(DBA_DYNFLD_STP    domainPtr,
			                DBA_HIER_HEAD_STP posHierHead,
		                    INTFCT            *valoProcFilter)
		                    /* INTFCT            *valoPosFilter) unused - DDV - 981028 */
{
    DBA_DYNFLD_STP    instrPtr=NULL, posValPtr=NULL,
                      *extractPos=NULL, getArgSt=NULL,
                      *scptDefTab=NULL;
    DBA_DYNFLD_ST     resultBaseVal, resultMultip;
    ID_T              instrId = (ID_T) 0, instrCurrId,
                      refCurrId, posCurrId;
    FLAG_T            *valoOkTab, valueChanged;
    AMOUNT_T          *amtResultTab, *refMktValTab, tmpVal,amtResult;
    PRICE_T           quote=ZERO_PRICE;
    EXCHANGE_T        tmpExch;
    SCPT_ARG_STP      genContBaseVal = (SCPT_ARG_STP)NULL,
                      genContMultip = (SCPT_ARG_STP)NULL;
    DICT_ATTRIB_STP   attribBaseVal, attribMultip;
    int               i, j, k, posNbr, scriptNbr, nbrToSolve, scptDefNbr;
    char              copyRecFlg;
    /*int               (*icmp) (); DDV - 981029 */
    char              *scptBuf;
    char              **scptDefBaseValTab = NULL,
                      **scptDefMultipTab  = NULL;
    RET_CODE          ret;
    FIN_EXCHARG_ST    exchArgSt;			/* REF2313 */

    memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));	/* REF2313 */
    /*DBA_SetConnectNoToExchArg(&exchArgSt, DBA_GetConnectNoFromHier(posHierHead)); *//* REF2580 - SSO - 980727 */
    DBA_InitConnectNoToExchArg(&exchArgSt, posHierHead); /* REF4213 - SSO - 991221 */


    /*** READ EACH EXTENDED POSITION TO VALUATE ***/
    /* Extract positions order by date, instr_id, curr_id and term_tp_id */
    copyRecFlg = FALSE;
    if ((ret = DBA_ExtractHierEltRec(posHierHead, ExtPos,
                                     copyRecFlg, valoProcFilter, FIN_CmpPosValRuleInstr,
                                     &posNbr, &extractPos)) != RET_SUCCEED)
    {
        return(ret);
    }

    /* sort extract position by nature and instrument */
    /* DDV - 981028 - Sort moved in extract */
    /* icmp = FIN_CmpPosValRuleInstr;
    qsort((void*)extractPos, posNbr, sizeof(DBA_DYNFLD_STP),
	  (int(*)(const void*, const void*))icmp); */

    /* count number of position with val rule in instrument = ValRule_Script */
    scriptNbr=0;
    for (i=0; i<posNbr; i++)
    {
	/* DVP172 */
	instrPtr = NULL;
        if (GET_EXTENSION_PTR(extractPos[i],  ExtPos_A_Instr_Ext) != NULL &&
	    (instrPtr = *(GET_EXTENSION_PTR(extractPos[i],  ExtPos_A_Instr_Ext))) != NULL)
        {
            	if (GET_ENUM(instrPtr, A_Instr_ValRuleEn) == ValRule_Script)
       		{
			/* BUG214 - XDI - 961126 */
        		if (GET_EXTENSION_PTR(extractPos[i],  ExtPos_PosVal_Ext) != NULL &&
		            (posValPtr = *(GET_EXTENSION_PTR(extractPos[i],  ExtPos_PosVal_Ext))) != NULL &&
                            GET_ID(posValPtr, PosVal_Id) < 0)
                		scriptNbr++;
            		else
                		continue;
       		}
            	else
               		continue;
        }
        else
            continue;
    }

    if (scriptNbr == 0)
    {
        FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
        return(RET_SUCCEED);
    }

    /* memory allocation for arrays */
    if ((valoOkTab = (FLAG_T *) CALLOC(scriptNbr,sizeof(FLAG_T)))== NULL)
    {
        FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, scriptNbr * sizeof(FLAG_T));
        return(RET_MEM_ERR_ALLOC);
    }

    if ((amtResultTab = (AMOUNT_T *) CALLOC(scriptNbr,sizeof(AMOUNT_T)))== NULL)
    {
        FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
        FREE(valoOkTab);
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, scriptNbr * sizeof(AMOUNT_T));
        return(RET_MEM_ERR_ALLOC);
    }

    if ((refMktValTab = (AMOUNT_T *) CALLOC(scriptNbr,sizeof(AMOUNT_T)))== NULL)
    {
        FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
        FREE(valoOkTab);
        FREE(amtResultTab);
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, scriptNbr * sizeof(SCPT_ARG_STP ));
        return(RET_MEM_ERR_ALLOC);
    }

    if ((scptDefBaseValTab = (char **) CALLOC(scriptNbr,sizeof(char *)))== NULL)
    {
        FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
        FREE(valoOkTab);
        FREE(amtResultTab);
        FREE(refMktValTab);
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, scriptNbr * sizeof(SCPT_ARG_STP ));
        return(RET_MEM_ERR_ALLOC);
    }

    if ((scptDefMultipTab = (char **) CALLOC(scriptNbr,sizeof(char *)))== NULL)
    {
        FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
        FREE(valoOkTab);
        FREE(amtResultTab);
        FREE(refMktValTab);
        FREE(scptDefBaseValTab);
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, scriptNbr * sizeof(SCPT_ARG_STP ));
        return(RET_MEM_ERR_ALLOC);
    }

    /* Load and build tree for script and initialise valoOkTab and MktValTab */
    instrId = (ID_T) 0;
    attribBaseVal = DBA_GetAttributeBySqlName(Instr, "script_def_base_value");
    attribMultip = DBA_GetAttributeBySqlName(Instr, "script_def_multiplier");

    if ((getArgSt = ALLOC_DYNST(Get_Arg)) == NULL)
    {
        FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
        FREE(valoOkTab);
        FREE(amtResultTab);
        FREE(refMktValTab);
        FREE(scptDefBaseValTab);
        FREE(scptDefMultipTab);
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, sizeof(DBA_DYNFLD_STP));
        return(RET_MEM_ERR_ALLOC);
    }

    if ((scptBuf = (char *) CALLOC(1, NOTE_T_LEN * SCPTDEF_MAX_REC)) == NULL)
    {
        FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
        FREE(valoOkTab);
        FREE(amtResultTab);
        FREE(refMktValTab);
        FREE(scptDefBaseValTab);
        FREE(scptDefMultipTab);
        FREE_DYNST(getArgSt, Get_Arg);
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, NOTE_T_LEN * SCPTDEF_MAX_REC);
        return(RET_MEM_ERR_ALLOC);
    }

    for (i=0; i<scriptNbr; i++)
    {
        valoOkTab[i] = FALSE;
        amtResultTab[i] = 0.0;

	/* DVP172 */
	posValPtr = NULL;
        if (GET_EXTENSION_PTR(extractPos[i], ExtPos_PosVal_Ext) != NULL &&
	    (posValPtr = *(GET_EXTENSION_PTR(extractPos[i],  ExtPos_PosVal_Ext))) != NULL)
            refMktValTab[i] = GET_AMOUNT(posValPtr, PosVal_RefMktValAmt);

        scptDefBaseValTab[i] = NULL;
        scptDefMultipTab[i]  = NULL;

        /* if new instrument, built script tree */
        if (GET_ID(extractPos[i], ExtPos_InstrId) != instrId)
        {
	    /* DVP172 */
	    instrPtr = NULL;
            if (GET_EXTENSION_PTR(extractPos[i],  ExtPos_A_Instr_Ext) != NULL &&
		(instrPtr = *(GET_EXTENSION_PTR(extractPos[i],  ExtPos_A_Instr_Ext))) != NULL)
            {
                /* load script */
                SET_ID(getArgSt, Get_Arg_Id,
                GET_ID(extractPos[i], ExtPos_InstrId));

                if ((DBA_Select2(ScriptDef, UNUSED, Get_Arg, getArgSt,
                                 A_ScriptDef, &scptDefTab, UNUSED, UNUSED,
                                 &scptDefNbr, UNUSED, UNUSED)) != RET_SUCCEED)
                {
                    /* free script and arrays */
                    for (k=0; k<i; k++)
                    {
                        FREE(scptDefBaseValTab[k]);
                        FREE(scptDefMultipTab[k]);
                    }
                    FREE(scptDefBaseValTab);
                    FREE(scptDefMultipTab);
                    FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
                    FREE(valoOkTab);
                    FREE(amtResultTab);
                    FREE(refMktValTab);
                    FREE_DYNST(getArgSt, Get_Arg);
                    FREE(scptBuf);
                    return(RET_DBA_ERR_NODATA);
                }

                /* build Base Value script */
                /* construct script string */
                scptBuf[0] = END_OF_STRING;
                for (j=0; j<scptDefNbr; j++)
                {
                    if (GET_DICT(scptDefTab[j], A_ScriptDef_AttrDictId) ==
                                 attribBaseVal->attrDictId)
                        strcat(scptBuf, GET_STRING(scptDefTab[j], A_ScriptDef_Def));
                }

                if (scptBuf[0] != END_OF_STRING)
                {
                    scptDefBaseValTab[i]= (char *)CALLOC(1, strlen(scptBuf) +1);
                    strcpy(scptDefBaseValTab[i], scptBuf);
                }

                /* build Multiplier script */
                /* construct script string */
                scptBuf[0] = END_OF_STRING;
                for (j=0; j<scptDefNbr; j++)
                {
                    if (GET_DICT(scptDefTab[j], A_ScriptDef_AttrDictId) ==
                    attribMultip->attrDictId)
                    strcat(scptBuf, GET_STRING(scptDefTab[j], A_ScriptDef_Def));
                }

                if (scptBuf[0] != END_OF_STRING)
                {
                    scptDefMultipTab[i]= (char *)CALLOC(1, strlen(scptBuf) +1);
                    strcpy(scptDefMultipTab[i], scptBuf);
                }

                DBA_FreeDynStTab(scptDefTab, scptDefNbr, A_ScriptDef);
            }
        }
        else
        {
            if (i>0)
            {
                if (scptDefBaseValTab[i-1] != NULL)
                {
                    scptDefBaseValTab[i]= (char *)CALLOC(1, strlen(scptDefBaseValTab[i-1]) +1);
                    strcpy(scptDefBaseValTab[i], scptDefBaseValTab[i-1]);
                }

                if (scptDefMultipTab[i-1] != NULL)
                {
                    scptDefMultipTab[i]= (char *)CALLOC(1, strlen(scptDefMultipTab[i-1]) +1);
                    strcpy(scptDefMultipTab[i], scptDefMultipTab[i-1]);
                }
            }
        }
    }

    FREE_DYNST(getArgSt, Get_Arg);
    FREE(scptBuf);

    /* eval script */
    nbrToSolve = scriptNbr;
    valueChanged = TRUE;

    /* number maximum of iteration choice to 50 */
    for (i=0; (i<scriptNbr+50) && (valueChanged==TRUE); i++)
    {
        valueChanged = FALSE;
        for (j=0; j<scriptNbr; j++)
        {
            SET_NUMBER((&resultBaseVal), 0, 1.0);
            SET_NUMBER((&resultMultip), 0, 1.0);

            if (scptDefBaseValTab[j] != NULL)
            {

                /* generate evaluation tree */
                if ((ret = SCPT_GenerateScptTree(scptDefBaseValTab[j],
                                                 EPos,
                                                 InternalSMode,
                                                 NumberType,
                                                 &genContBaseVal)) != RET_SUCCEED)
                {
                    /* free script and arrays */
                    for (k=0; k<scriptNbr; k++)
                    {
                        FREE(scptDefBaseValTab[k]);
                        FREE(scptDefMultipTab[k]);
                    }
                    FREE(scptDefBaseValTab);
                    FREE(scptDefMultipTab);
                    FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
                    FREE(valoOkTab);
                    FREE(amtResultTab);
                    FREE(refMktValTab);
                    return(ret);
                }

                if ((ret = SCPT_ExecScptTree(genContBaseVal,
                                             domainPtr,
                                             posHierHead,
                                             extractPos[j],
                                             NumberType,
                                             &resultBaseVal)) != RET_SUCCEED)
                {
                    /* free script and arrays */
                    for (k=0; k<scriptNbr; k++)
                    {
                        FREE(scptDefBaseValTab[k]);
                        FREE(scptDefMultipTab[k]);
                    }
                    FREE(scptDefBaseValTab);
                    FREE(scptDefMultipTab);
                    FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
                    FREE(valoOkTab);
                    FREE(amtResultTab);
                    FREE(refMktValTab);
                    SCPT_FreeScptTree(genContBaseVal); /* BUG330 - XDI - 970410 */
                    return(ret);
                }

                SCPT_FreeScptTree(genContBaseVal); /* BUG330 - XDI - 970410 */
            }
	    else
                SET_NUMBER((&resultBaseVal), 0, 1.0); /* BUG255  - XDI - 970115 */

            if (scptDefMultipTab[j] != NULL)
            {
                /* generate evaluation tree */
                if ((ret = SCPT_GenerateScptTree(scptDefMultipTab[j],
                                                 EPos,
                                                 InternalSMode,
                                                 NumberType,
                                                 &genContMultip)) != RET_SUCCEED)
                {
                    /* free script and arrays */
                    for (k=0; k<scriptNbr; k++)
                    {
                        FREE(scptDefBaseValTab[k]);
                        FREE(scptDefMultipTab[k]);
                    }
                    FREE(scptDefBaseValTab);
                    FREE(scptDefMultipTab);
                    FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
                    FREE(valoOkTab);
                    FREE(amtResultTab);
                    FREE(refMktValTab);
                    return(ret);
                }

                if ((ret = SCPT_ExecScptTree(genContMultip,
                                             domainPtr,
                                             posHierHead,
                                             extractPos[j],
                                             NumberType,
                                             &resultMultip)) != RET_SUCCEED)
                {
                    /* free script and arrays */
                    for (k=0; k<scriptNbr; k++)
                    {
                        FREE(scptDefBaseValTab[k]);
                        FREE(scptDefMultipTab[k]);
                    }
                    FREE(scptDefBaseValTab);
                    FREE(scptDefMultipTab);
                    FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
                    FREE(valoOkTab);
                    FREE(amtResultTab);
                    FREE(refMktValTab);
                    SCPT_FreeScptTree(genContMultip); /* BUG330 - XDI - 970410 */
                    return(ret);
                }

                SCPT_FreeScptTree(genContMultip); /* BUG330 - XDI - 970410 */
            }
	    else
                SET_NUMBER((&resultMultip), 0, 1.0); /* BUG255  - XDI - 970115 */

            /* update PosVal */
	    /* DVP172 */
	    posValPtr = NULL;
            if (GET_EXTENSION_PTR(extractPos[j], ExtPos_PosVal_Ext) == NULL ||
		(posValPtr = *(GET_EXTENSION_PTR(extractPos[j],
                               ExtPos_PosVal_Ext))) == NULL)
            {
                /* free script and arrays */
                for (k=0; k<scriptNbr; k++)
                {
                    FREE(scptDefBaseValTab[k]);
                    FREE(scptDefMultipTab[k]);
                }
                FREE(scptDefBaseValTab);
                FREE(scptDefMultipTab);
                FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
                FREE(valoOkTab);
                FREE(amtResultTab);
                FREE(refMktValTab);

                MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "PosVal");
                return(RET_DBA_ERR_NODATA);
            }

            /* Update PosVal fields (MktVal = NetVal, no accrint for debts) */
            refCurrId = GET_ID(domainPtr,A_Domain_CurrId);
            instrCurrId = GET_ID(extractPos[j], ExtPos_InstrCurrId);
            posCurrId = GET_ID(extractPos[j], ExtPos_PosCurrId);

            amtResult = GET_NUMBER((&resultBaseVal), 0) * GET_NUMBER((&resultMultip), 0) *
                        refMktValTab[j];
            amtResult = TLS_Round(amtResult, 0.001, RndRule_Nearest);

            /* compare result with a precision of 0.001 */
            if (amtResult != amtResultTab[j])
		valueChanged = TRUE;

            amtResultTab[j] = amtResult;
            amtResult = CAST_AMOUNT(amtResult, refCurrId);

            SET_AMOUNT(posValPtr, PosVal_RefMktValAmt, amtResult);
            SET_AMOUNT(posValPtr, PosVal_RefNetAmt,    GET_AMOUNT(posValPtr, PosVal_RefMktValAmt));

            if (instrCurrId != refCurrId)
            {
		exchArgSt.srcAmt = GET_AMOUNT(posValPtr, PosVal_RefNetAmt);
                FIN_ExchAmt(GET_DATETIME(extractPos[j], ExtPos_ExtPosDate),
                            refCurrId, instrCurrId,
		                    0, NULL, &exchArgSt, NULL, &tmpVal, &tmpExch);
                SET_AMOUNT(posValPtr, PosVal_InstrNetAmt, tmpVal);

                SET_AMOUNT(posValPtr, PosVal_InstrMktValAmt,
                           GET_AMOUNT(posValPtr, PosVal_InstrNetAmt));
            }
            else
            {
                SET_AMOUNT(posValPtr, PosVal_InstrNetAmt,
                           GET_AMOUNT(posValPtr, PosVal_RefNetAmt));

                SET_AMOUNT(posValPtr, PosVal_InstrMktValAmt,
                           GET_AMOUNT(posValPtr, PosVal_RefMktValAmt));
            }

            if (posCurrId != refCurrId)
            {
		exchArgSt.srcAmt = GET_AMOUNT(posValPtr, PosVal_RefNetAmt);
                FIN_ExchAmt(GET_DATETIME(extractPos[j], ExtPos_ExtPosDate),
                            refCurrId, posCurrId,
			                0, NULL, &exchArgSt, NULL, &tmpVal, &tmpExch);
                SET_AMOUNT(posValPtr, PosVal_PosNetAmt, tmpVal);

                SET_AMOUNT(posValPtr, PosVal_PosMktValAmt,
                           GET_AMOUNT(posValPtr, PosVal_PosNetAmt));
            }
            else
            {
                SET_AMOUNT(posValPtr, PosVal_PosNetAmt,
                           GET_AMOUNT(posValPtr, PosVal_RefNetAmt));

                SET_AMOUNT(posValPtr, PosVal_PosMktValAmt,
                           GET_AMOUNT(posValPtr, PosVal_RefMktValAmt));
            }

            /* Compute Price and Quote */
	    /* DVP172 */
	    instrPtr = NULL;
	    if(GET_EXTENSION_PTR(extractPos[j], ExtPos_A_Instr_Ext) != NULL)
                instrPtr = *(GET_EXTENSION_PTR(extractPos[j], ExtPos_A_Instr_Ext));
            SET_PRICE(posValPtr, PosVal_Price, CAST_PRICE(GET_AMOUNT(posValPtr, PosVal_InstrMktValAmt)/
                                                 GET_NUMBER(extractPos[j] ,ExtPos_Qty)));/* REF3288 - SSO - 990205 */

            FIN_PriceToQuote(GET_ENUM(posValPtr, PosVal_PriceCalcRuleEn),
                             GET_ID(instrPtr, A_Instr_Id), instrPtr,
                             GET_DATETIME(posValPtr, PosVal_Date), NULL,
                             GET_PRICE(posValPtr, PosVal_Price), &quote, posHierHead);

            SET_PRICE(posValPtr, PosVal_Quote, quote);

            SET_NUMBER(posValPtr, PosVal_DebtBaseVal, GET_NUMBER((&resultBaseVal), 0)); /* REF8844 - LJE - 030327 */

        }
    }

    /* free script and arrays */
    for (k=0; k<scriptNbr; k++)
    {
        FREE(scptDefBaseValTab[k]);
        FREE(scptDefMultipTab[k]);
    }
    FREE(scptDefBaseValTab);
    FREE(scptDefMultipTab);
    FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
    FREE(valoOkTab);
    FREE(amtResultTab);
    FREE(refMktValTab);

    return(RET_SUCCEED);
}
#endif

/************************************************************************
**
**  Function    :   FIN_ResetTotPhase()
**
**  Description :   Reset to 0 all totfctPhase for totfctTab
**
**  Arguments   :   The general context
**
**  Return      :   RET_SUCCEED or error code
**
**  Create	    :   REF7257 - LJE - 011207
**  Modif.	    :
**
*************************************************************************/
STATIC void FIN_ResetTotPhase(SCPT_ARG_STP genContext)
{

	int i;

	for(i=0; i<genContext->totfctNb; i++)
	{
		genContext->totfctTabPtr[i]->totfctPhase = 0;
	}

}

/************************************************************************
**
**  Function    :   FIN_ComputeDebtScript()
**
**  Description :   Compute debt positions with script nature
**
**  Arguments   :   domainPtr       pointer on domain
**                  posHierHead     hierarchy pointer
**                  valoProcFilter  filter for position to evaluate
**
**  Return      :   RET_SUCCEED or error code
**
**  Modif.		 : REF2313 - RAK - 980910
**  Modif.	:   REF2580 - SSO - 980727
**
*************************************************************************/
RET_CODE FIN_ComputeDebtScript(DBA_DYNFLD_STP    domainPtr,
			                DBA_HIER_HEAD_STP   posHierHead,
		                    HIER_FLTFCT         *valoProcFilter) /* REF7264 - LJE - 020131 */
		                    /* INTFCT            *valoPosFilter) unused - DDV - 981028 */
{
    DBA_DYNFLD_STP    instrPtr=NULL, posValPtr=NULL,
                      *extractPos=NULL, getArgSt=NULL,
                      *scptDefTab=NULL;
    DBA_DYNFLD_ST     resultBaseVal, resultMultip;
    ID_T              instrId = (ID_T) 0, instrCurrId,
                      refCurrId, posCurrId;
    FLAG_T            *valoOkTab, valueChanged;
    AMOUNT_T          *amtResultTab, *refMktValTab, tmpVal,amtResult;
    PRICE_T           quote=0.0;
    EXCHANGE_T        tmpExch;
    SCPT_ARG_STP      *genContBaseValStatic = NULL,
                      *genContMultipStatic  = NULL,
                      *genContBaseValDyn    = NULL,
                      *genContMultipDyn     = NULL;
    DICT_ATTRIB_STP   attribBaseVal, attribMultip;
    int               i, j, k, posNbr, scriptNbr, nbrToSolve, scptDefNbr;
    char              copyRecFlg;
    /*int               (*icmp) (); DDV - 981029 */
    char              *scptBuf;
    char              **scptDefBaseValTab = NULL,
                      **scptDefMultipTab  = NULL;
    RET_CODE          ret;
    FIN_EXCHARG_ST    exchArgSt;			/* REF2313 */

	ID_T              refCurrDomain=0;  /* REF6220 - LJE - 020319 */

    memset(&exchArgSt,     0, sizeof(FIN_EXCHARG_ST));	/* REF2313 */
    memset(&resultBaseVal, 0, sizeof(DBA_DYNFLD_ST));   /* REF7264 - RAK - 020307 */
    memset(&resultMultip,  0, sizeof(DBA_DYNFLD_ST));   /* REF7264 - RAK - 020307 */

    /*DBA_SetConnectNoToExchArg(&exchArgSt, DBA_GetConnectNoFromHier(posHierHead)); *//* REF2580 - SSO - 980727 */
    DBA_InitConnectNoToExchArg(&exchArgSt, posHierHead); /* REF4213 - SSO - 991221 */


    /* REF6220 - LJE - 020319 */
	if (domainPtr != NULL)
	{
	    refCurrDomain = GET_ID(domainPtr, A_Domain_CurrId);
	}

    /*** READ EACH EXTENDED POSITION TO VALUATE ***/
    /* Extract positions order by date, instr_id, curr_id and term_tp_id */
    copyRecFlg = FALSE;
    if ((ret = DBA_ExtractHierEltRec(posHierHead, ExtPos,
                                     copyRecFlg, valoProcFilter, FIN_CmpPosValRuleInstr,
                                     &posNbr, &extractPos)) != RET_SUCCEED)
    {
        return(ret);
    }

    /* sort extract position by nature and instrument */
    /* DDV - 981028 - Sort moved in extract */
    /* icmp = FIN_CmpPosValRuleInstr;
    qsort((void*)extractPos, posNbr, sizeof(DBA_DYNFLD_STP),
	  (int(*)(const void*, const void*))icmp); */

    /* count number of position with val rule in instrument = ValRule_Script */
    scriptNbr=0;
    for (i=0; i<posNbr; i++)
    {
	    /* DVP172 */
	    instrPtr = NULL;
        if (GET_EXTENSION_PTR(extractPos[i],  ExtPos_A_Instr_Ext) != NULL &&
	        (instrPtr = *(GET_EXTENSION_PTR(extractPos[i],  ExtPos_A_Instr_Ext))) != NULL)
        {
            	if (GET_ENUM(instrPtr, A_Instr_ValRuleEn) == ValRule_Script)
       		    {
			        /* BUG214 - XDI - 961126 */
        		    if (GET_EXTENSION_PTR(extractPos[i],  ExtPos_PosVal_Ext) != NULL &&
		                (posValPtr = *(GET_EXTENSION_PTR(extractPos[i],  ExtPos_PosVal_Ext))) != NULL &&
                                GET_ID(posValPtr, PosVal_Id) < 0)
                		    scriptNbr++;
            		    else
                		    continue;
       		    }
            	else
               		continue;
        }
        else
            continue;
    }

    if (scriptNbr == 0)
    {
        FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
        return(RET_SUCCEED);
    }

    /* memory allocation for arrays */
    if ((valoOkTab = (FLAG_T *) CALLOC(scriptNbr,sizeof(FLAG_T)))== NULL)
    {
        FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, scriptNbr * sizeof(FLAG_T));
        return(RET_MEM_ERR_ALLOC);
    }

    if ((amtResultTab = (AMOUNT_T *) CALLOC(scriptNbr,sizeof(AMOUNT_T)))== NULL)
    {
        FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
        FREE(valoOkTab);
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, scriptNbr * sizeof(AMOUNT_T));
        return(RET_MEM_ERR_ALLOC);
    }

    if ((refMktValTab = (AMOUNT_T *) CALLOC(scriptNbr,sizeof(AMOUNT_T)))== NULL)
    {
        FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
        FREE(valoOkTab);
        FREE(amtResultTab);
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, scriptNbr * sizeof(SCPT_ARG_STP ));
        return(RET_MEM_ERR_ALLOC);
    }

    if ((scptDefBaseValTab = (char **) CALLOC(scriptNbr,sizeof(char *)))== NULL)
    {
        FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
        FREE(valoOkTab);
        FREE(amtResultTab);
        FREE(refMktValTab);
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, scriptNbr * sizeof(SCPT_ARG_STP ));
        return(RET_MEM_ERR_ALLOC);
    }

    if ((scptDefMultipTab = (char **) CALLOC(scriptNbr,sizeof(char *)))== NULL)
    {
        FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
        FREE(valoOkTab);
        FREE(amtResultTab);
        FREE(refMktValTab);
        FREE(scptDefBaseValTab);
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, scriptNbr * sizeof(SCPT_ARG_STP ));
        return(RET_MEM_ERR_ALLOC);
    }

    /* Load and build tree for script and initialise valoOkTab and MktValTab */
    instrId = (ID_T) 0;
    attribBaseVal = DBA_GetAttributeBySqlName(Instr, "script_def_base_value");   /* REF7264 - CSY - 020131 */
    attribMultip = DBA_GetAttributeBySqlName(Instr, "script_def_multiplier");    /* REF7264 - CSY - 020131 */

    if ((getArgSt = ALLOC_DYNST(Get_Arg)) == NULL)
    {
        FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
        FREE(valoOkTab);
        FREE(amtResultTab);
        FREE(refMktValTab);
        FREE(scptDefBaseValTab);
        FREE(scptDefMultipTab);
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, sizeof(DBA_DYNFLD_STP));
        return(RET_MEM_ERR_ALLOC);
    }

    if ((scptBuf = (char *) CALLOC(1, GET_MAXDATALEN(NoteType) * SCPTDEF_MAX_REC)) == NULL) /* PMSTA-33077 - DLA - 181011 */
    {
        FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
        FREE(valoOkTab);
        FREE(amtResultTab);
        FREE(refMktValTab);
        FREE(scptDefBaseValTab);
        FREE(scptDefMultipTab);
        FREE_DYNST(getArgSt, Get_Arg);
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, GET_MAXDATALEN(NoteType) * SCPTDEF_MAX_REC);   /* PMSTA-33077 - DLA - 181011 */
        return(RET_MEM_ERR_ALLOC);
    }

    for (i=0; i<scriptNbr; i++)
    {
        valoOkTab[i] = FALSE;
        amtResultTab[i] = 0.0;

	    /* DVP172 */
	    posValPtr = NULL;
        if (GET_EXTENSION_PTR(extractPos[i], ExtPos_PosVal_Ext) != NULL &&
	        (posValPtr = *(GET_EXTENSION_PTR(extractPos[i],  ExtPos_PosVal_Ext))) != NULL)
            refMktValTab[i] = GET_AMOUNT(posValPtr, PosVal_RefMktValAmt);

        scptDefBaseValTab[i] = NULL;
        scptDefMultipTab[i]  = NULL;

        /* if new instrument, built script tree */
        if (GET_ID(extractPos[i], ExtPos_InstrId) != instrId)
        {
	        /* DVP172 */
	        instrPtr = NULL;
            if (GET_EXTENSION_PTR(extractPos[i],  ExtPos_A_Instr_Ext) != NULL &&
		        (instrPtr = *(GET_EXTENSION_PTR(extractPos[i],  ExtPos_A_Instr_Ext))) != NULL)
            {
                /* load script */
                SET_ID(getArgSt, Get_Arg_Id,
                GET_ID(extractPos[i], ExtPos_InstrId));

                if ((DBA_Select2(ScriptDef, UNUSED, Get_Arg, getArgSt,
                                 A_ScriptDef, &scptDefTab, UNUSED, UNUSED,
                                 &scptDefNbr, UNUSED, UNUSED)) != RET_SUCCEED)
                {
                    /* free script and arrays */
                    for (k=0; k<i; k++)
                    {
                        FREE(scptDefBaseValTab[k]);
                        FREE(scptDefMultipTab[k]);
                    }
                    FREE(scptDefBaseValTab);
                    FREE(scptDefMultipTab);
                    FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
                    FREE(valoOkTab);
                    FREE(amtResultTab);
                    FREE(refMktValTab);
                    FREE_DYNST(getArgSt, Get_Arg);
                    FREE(scptBuf);
                    return(RET_DBA_ERR_NODATA);
                }

                /* build Base Value script */
                /* construct script string */
                scptBuf[0] = END_OF_STRING;
                for (j=0; j<scptDefNbr; j++)
                {
                    if (GET_DICT(scptDefTab[j], A_ScriptDef_AttrDictId) ==
                                 attribBaseVal->attrDictId)
                        strcat(scptBuf, GET_STRING(scptDefTab[j], A_ScriptDef_Def));
                }

                if (scptBuf[0] != END_OF_STRING)
                {
                    scptDefBaseValTab[i]= (char *)CALLOC(1, strlen(scptBuf) +1);
                    strcpy(scptDefBaseValTab[i], scptBuf);
                }

                /* build Multiplier script */
                /* construct script string */
                scptBuf[0] = END_OF_STRING;
                for (j=0; j<scptDefNbr; j++)
                {
                    if (GET_DICT(scptDefTab[j], A_ScriptDef_AttrDictId) ==
                    attribMultip->attrDictId)
                    strcat(scptBuf, GET_STRING(scptDefTab[j], A_ScriptDef_Def));
                }

                if (scptBuf[0] != END_OF_STRING)
                {
                    scptDefMultipTab[i]= (char *)CALLOC(1, strlen(scptBuf) +1);
                    strcpy(scptDefMultipTab[i], scptBuf);
                }

                DBA_FreeDynStTab(scptDefTab, scptDefNbr, A_ScriptDef);
            }
        }
        else
        {
            if (i>0)
            {
                if (scptDefBaseValTab[i-1] != NULL)
                {
                    scptDefBaseValTab[i]= (char *)CALLOC(1, strlen(scptDefBaseValTab[i-1]) +1);
                    strcpy(scptDefBaseValTab[i], scptDefBaseValTab[i-1]);
                }

                if (scptDefMultipTab[i-1] != NULL)
                {
                    scptDefMultipTab[i]= (char *)CALLOC(1, strlen(scptDefMultipTab[i-1]) +1);
                    strcpy(scptDefMultipTab[i], scptDefMultipTab[i-1]);
                }
            }
        }
    }

    FREE_DYNST(getArgSt, Get_Arg);
    FREE(scptBuf);

    if ((genContBaseValStatic = (SCPT_ARG_STP *) CALLOC(scriptNbr, sizeof(SCPT_ARG_STP))) == NULL)
    {
        FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
        FREE(valoOkTab);
        FREE(amtResultTab);
        FREE(refMktValTab);
        FREE(scptDefBaseValTab);
        FREE(scptDefMultipTab);
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, GET_MAXDATALEN(NoteType) * SCPTDEF_MAX_REC);
        return(RET_MEM_ERR_ALLOC);
    }

    if ((genContMultipStatic = (SCPT_ARG_STP *) CALLOC(scriptNbr, sizeof(SCPT_ARG_STP))) == NULL)
    {
        FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
        FREE(valoOkTab);
        FREE(amtResultTab);
        FREE(refMktValTab);
        FREE(scptDefBaseValTab);
        FREE(scptDefMultipTab);
        FREE(genContBaseValStatic);
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, GET_MAXDATALEN(NoteType) * SCPTDEF_MAX_REC);
        return(RET_MEM_ERR_ALLOC);
    }

    if ((genContBaseValDyn = (SCPT_ARG_STP *) CALLOC(scriptNbr, sizeof(SCPT_ARG_STP))) == NULL)
    {
        FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
        FREE(valoOkTab);
        FREE(amtResultTab);
        FREE(refMktValTab);
        FREE(scptDefBaseValTab);
        FREE(scptDefMultipTab);
        FREE(genContBaseValStatic);
        FREE(genContMultipStatic);
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, GET_MAXDATALEN(NoteType) * SCPTDEF_MAX_REC);
        return(RET_MEM_ERR_ALLOC);
    }

    if ((genContMultipDyn = (SCPT_ARG_STP *) CALLOC(scriptNbr, sizeof(SCPT_ARG_STP))) == NULL)
    {
        FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
        FREE(valoOkTab);
        FREE(amtResultTab);
        FREE(refMktValTab);
        FREE(scptDefBaseValTab);
        FREE(scptDefMultipTab);
        FREE(genContBaseValStatic);
        FREE(genContMultipStatic);
        FREE(genContBaseValDyn);
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, GET_MAXDATALEN(NoteType) * SCPTDEF_MAX_REC);
        return(RET_MEM_ERR_ALLOC);
    }

    /* REF4038 - DDV - 000217 - Generate all scriptTree which will be used for static part,
       and compute static part. Generate a second tree which will be used for dynamic part */
    for (i=0; i<scriptNbr; i++)
    {
        if (scptDefBaseValTab[i] != NULL)
        {
            /* generate evaluation tree */
            if ((ret = SCPT_GenerateScptTree(scptDefBaseValTab[i],
                                             EPos,
                                             InternalSMode,
                                             NumberType,
                                             &genContBaseValStatic[i])) != RET_SUCCEED)
            {
                /* free script and arrays */
                for (k=0; k<scriptNbr; k++)
                {
                    FREE(scptDefBaseValTab[k]);
                    FREE(scptDefMultipTab[k]);
                    SCPT_FreeScptTree(genContBaseValStatic[k]);
                    SCPT_FreeScptTree(genContMultipStatic[k]);
                    SCPT_FreeScptTree(genContBaseValDyn[k]);
                    SCPT_FreeScptTree(genContMultipDyn[k]);
                }
                FREE(scptDefBaseValTab);
                FREE(scptDefMultipTab);
                FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
                FREE(valoOkTab);
                FREE(amtResultTab);
                FREE(refMktValTab);
                FREE(genContBaseValStatic);
                FREE(genContMultipStatic);
                FREE(genContBaseValDyn);
                FREE(genContMultipDyn);
                return(ret);
            }

            genContBaseValStatic[i]->totfctMode = TotFctMode_ComputeStatic;

            if ((ret = SCPT_ExecScptTree(genContBaseValStatic[i],
                                         domainPtr,
                                         posHierHead,
                                         extractPos[i], /* REF5090 - DDV - 000822 */
                                         NumberType,
                                         &resultBaseVal,
										 NULLDYNST)) != RET_SUCCEED) /* PMSTA14443 - DDV - 120709 */
            {
                /* free script and arrays */
                for (k=0; k<scriptNbr; k++)
                {
                    FREE(scptDefBaseValTab[k]);
                    FREE(scptDefMultipTab[k]);
                    SCPT_FreeScptTree(genContBaseValStatic[k]);
                    SCPT_FreeScptTree(genContMultipStatic[k]);
                    SCPT_FreeScptTree(genContBaseValDyn[k]);
                    SCPT_FreeScptTree(genContMultipDyn[k]);
                }
                FREE(scptDefBaseValTab);
                FREE(scptDefMultipTab);
                FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
                FREE(valoOkTab);
                FREE(amtResultTab);
                FREE(refMktValTab);
                FREE(genContBaseValStatic);
                FREE(genContMultipStatic);
                FREE(genContBaseValDyn);
                FREE(genContMultipDyn);
                return(ret);
            }

            /* generate evaluation tree */
            if ((ret = SCPT_GenerateScptTree(scptDefBaseValTab[i],
                                             EPos,
                                             InternalSMode,
                                             NumberType,
                                             &genContBaseValDyn[i])) != RET_SUCCEED)
            {
                /* free script and arrays */
                for (k=0; k<scriptNbr; k++)
                {
                    FREE(scptDefBaseValTab[k]);
                    FREE(scptDefMultipTab[k]);
                    SCPT_FreeScptTree(genContBaseValStatic[k]);
                    SCPT_FreeScptTree(genContMultipStatic[k]);
                    SCPT_FreeScptTree(genContBaseValDyn[k]);
                    SCPT_FreeScptTree(genContMultipDyn[k]);
                }
                FREE(scptDefBaseValTab);
                FREE(scptDefMultipTab);
                FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
                FREE(valoOkTab);
                FREE(amtResultTab);
                FREE(refMktValTab);
                FREE(genContBaseValStatic);
                FREE(genContMultipStatic);
                FREE(genContBaseValDyn);
                FREE(genContMultipDyn);
                return(ret);
            }

            genContBaseValDyn[i]->staticTotfctTabPtr = genContBaseValStatic[i]->totfctTabPtr;
            genContBaseValDyn[i]->totfctMode = TotFctMode_ComputeDynamic;
        }

        if (scptDefMultipTab[i] != NULL)
        {
            /* generate evaluation tree */
            if ((ret = SCPT_GenerateScptTree(scptDefMultipTab[i],
                                             EPos,
                                             InternalSMode,
                                             NumberType,
                                             &genContMultipStatic[i])) != RET_SUCCEED)
            {
                /* free script and arrays */
                for (k=0; k<scriptNbr; k++)
                {
                    FREE(scptDefBaseValTab[k]);
                    FREE(scptDefMultipTab[k]);
                    SCPT_FreeScptTree(genContBaseValStatic[k]);
                    SCPT_FreeScptTree(genContMultipStatic[k]);
                    SCPT_FreeScptTree(genContBaseValDyn[k]);
                    SCPT_FreeScptTree(genContMultipDyn[k]);
                }
                FREE(scptDefBaseValTab);
                FREE(scptDefMultipTab);
                FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
                FREE(valoOkTab);
                FREE(amtResultTab);
                FREE(refMktValTab);
                FREE(genContBaseValStatic);
                FREE(genContMultipStatic);
                FREE(genContBaseValDyn);
                FREE(genContMultipDyn);
                return(ret);
            }

            genContMultipStatic[i]->totfctMode = TotFctMode_ComputeStatic;

            if ((ret = SCPT_ExecScptTree(genContMultipStatic[i],
                                         domainPtr,
                                         posHierHead,
                                         extractPos[i], /* REF5090 - DDV - 000822 */
                                         NumberType,
                                         &resultMultip,
										 NULLDYNST)) != RET_SUCCEED) /* PMSTA14443 - DDV - 120709 */
            {
                /* free script and arrays */
                for (k=0; k<scriptNbr; k++)
                {
                    FREE(scptDefBaseValTab[k]);
                    FREE(scptDefMultipTab[k]);
                    SCPT_FreeScptTree(genContBaseValStatic[k]);
                    SCPT_FreeScptTree(genContMultipStatic[k]);
                    SCPT_FreeScptTree(genContBaseValDyn[k]);
                    SCPT_FreeScptTree(genContMultipDyn[k]);
                }
                FREE(scptDefBaseValTab);
                FREE(scptDefMultipTab);
                FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
                FREE(valoOkTab);
                FREE(amtResultTab);
                FREE(refMktValTab);
                FREE(genContBaseValStatic);
                FREE(genContMultipStatic);
                FREE(genContBaseValDyn);
                FREE(genContMultipDyn);
                return(ret);
            }

            /* generate evaluation tree */
            if ((ret = SCPT_GenerateScptTree(scptDefMultipTab[i],
                                             EPos,
                                             InternalSMode,
                                             NumberType,
                                             &genContMultipDyn[i])) != RET_SUCCEED)
            {
                /* free script and arrays */
                for (k=0; k<scriptNbr; k++)
                {
                    FREE(scptDefBaseValTab[k]);
                    FREE(scptDefMultipTab[k]);
                    SCPT_FreeScptTree(genContBaseValStatic[k]);
                    SCPT_FreeScptTree(genContMultipStatic[k]);
                    SCPT_FreeScptTree(genContBaseValDyn[k]);
                    SCPT_FreeScptTree(genContMultipDyn[k]);
                }
                FREE(scptDefBaseValTab);
                FREE(scptDefMultipTab);
                FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
                FREE(valoOkTab);
                FREE(amtResultTab);
                FREE(refMktValTab);
                FREE(genContBaseValStatic);
                FREE(genContMultipStatic);
                FREE(genContBaseValDyn);
                FREE(genContMultipDyn);
                return(ret);
            }
            genContMultipDyn[i]->staticTotfctTabPtr = genContMultipStatic[i]->totfctTabPtr;
            genContMultipDyn[i]->totfctMode = TotFctMode_ComputeDynamic;
        }
    }

    for (k=0; k<scriptNbr; k++)
    {
        FREE(scptDefBaseValTab[k]);
        FREE(scptDefMultipTab[k]);
    }
    FREE(scptDefBaseValTab);
    FREE(scptDefMultipTab);

    /* eval script */
    nbrToSolve = scriptNbr;
    valueChanged = TRUE;

    /* number maximum of iteration choice to 50 */
    for (i=0; (i<scriptNbr+50) && (valueChanged==TRUE); i++)
    {
        valueChanged = FALSE;
        for (j=0; j<scriptNbr; j++)
        {

			/* REF6220 - LJE - 020319 : Active the portfolio currency if the def curr flag is "default" */
			FIN_UpdDomainRefCurr(domainPtr, extractPos[j]);

            SET_NUMBER((&resultBaseVal), 0, 1.0);
            SET_NUMBER((&resultMultip), 0, 1.0);

            if (genContBaseValDyn[j] != NULL)
            {
				/* REF7257 - LJE - 011207 */
				FIN_ResetTotPhase(genContBaseValDyn[j]);

                if ((ret = SCPT_ExecScptTree(genContBaseValDyn[j],
                                             domainPtr,
                                             posHierHead,
                                             extractPos[j],
                                             NumberType,
                                             &resultBaseVal,
											 NULLDYNST)) != RET_SUCCEED) /* PMSTA14443 - DDV - 120709 */
                {
                    /* free script and arrays */
                    for (k=0; k<scriptNbr; k++)
                    {
                        SCPT_FreeScptTree(genContBaseValStatic[k]);
                        SCPT_FreeScptTree(genContMultipStatic[k]);
                        SCPT_FreeScptTree(genContBaseValDyn[k]);
                        SCPT_FreeScptTree(genContMultipDyn[k]);
                    }
                    FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
                    FREE(valoOkTab);
                    FREE(amtResultTab);
                    FREE(refMktValTab);
                    FREE(genContBaseValStatic);
                    FREE(genContMultipStatic);
                    FREE(genContBaseValDyn);
                    FREE(genContMultipDyn);
                    return(ret);
                }
            }
	        else
                SET_NUMBER((&resultBaseVal), 0, 1.0); /* BUG255  - XDI - 970115 */

            if (genContMultipDyn[j] != NULL)
            {
				/* REF7257 - LJE - 011207 */
				FIN_ResetTotPhase(genContMultipDyn[j]);

                if ((ret = SCPT_ExecScptTree(genContMultipDyn[j],
                                             domainPtr,
                                             posHierHead,
                                             extractPos[j],
                                             NumberType,
                                             &resultMultip,
											 NULLDYNST)) != RET_SUCCEED) /* PMSTA14443 - DDV - 120709 */
                {
                    /* free script and arrays */
                    for (k=0; k<scriptNbr; k++)
                    {
                        SCPT_FreeScptTree(genContBaseValStatic[k]);
                        SCPT_FreeScptTree(genContMultipStatic[k]);
                        SCPT_FreeScptTree(genContBaseValDyn[k]);
                        SCPT_FreeScptTree(genContMultipDyn[k]);
                    }
                    FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
                    FREE(valoOkTab);
                    FREE(amtResultTab);
                    FREE(refMktValTab);
                    FREE(genContBaseValStatic);
                    FREE(genContMultipStatic);
                    FREE(genContBaseValDyn);
                    FREE(genContMultipDyn);
                    return(ret);
                }
            }
	        else
                SET_NUMBER((&resultMultip), 0, 1.0); /* BUG255  - XDI - 970115 */

            /* update PosVal */
	        /* DVP172 */
	        posValPtr = NULL;
            if (GET_EXTENSION_PTR(extractPos[j], ExtPos_PosVal_Ext) == NULL ||
		        (posValPtr = *(GET_EXTENSION_PTR(extractPos[j],
                               ExtPos_PosVal_Ext))) == NULL)
            {
                /* free script and arrays */
                for (k=0; k<scriptNbr; k++)
                {
                    SCPT_FreeScptTree(genContBaseValStatic[k]);
                    SCPT_FreeScptTree(genContMultipStatic[k]);
                    SCPT_FreeScptTree(genContBaseValDyn[k]);
                    SCPT_FreeScptTree(genContMultipDyn[k]);
                }
                FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
                FREE(valoOkTab);
                FREE(amtResultTab);
                FREE(refMktValTab);
                FREE(genContBaseValStatic);
                FREE(genContMultipStatic);
                FREE(genContBaseValDyn);
                FREE(genContMultipDyn);

                MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "PosVal");
                return(RET_DBA_ERR_NODATA);
            }

            /* Update PosVal fields (MktVal = NetVal, no accrint for debts) */
            refCurrId = GET_ID(domainPtr,A_Domain_CurrId);
            instrCurrId = GET_ID(extractPos[j], ExtPos_InstrCurrId);
            posCurrId = GET_ID(extractPos[j], ExtPos_PosCurrId);

            amtResult = GET_NUMBER((&resultBaseVal), 0) * GET_NUMBER((&resultMultip), 0) *
                        refMktValTab[j];
            amtResult = TLS_Round(amtResult, 0.001, RndRule_Nearest);

            /* compare result with a precision of 0.001 */
            if (amtResult != amtResultTab[j])
		    valueChanged = TRUE;

            amtResultTab[j] = amtResult;
            amtResult = CAST_AMOUNT(amtResult, refCurrId);

            SET_AMOUNT(posValPtr, PosVal_RefMktValAmt, amtResult);
            SET_AMOUNT(posValPtr, PosVal_RefNetAmt,    GET_AMOUNT(posValPtr, PosVal_RefMktValAmt));

            if (instrCurrId != refCurrId)
            {
		        exchArgSt.srcAmt = GET_AMOUNT(posValPtr, PosVal_RefNetAmt);
                FIN_ExchAmt(GET_DATETIME(extractPos[j], ExtPos_ExtPosDate),
                            refCurrId, instrCurrId,
		                    0, NULL, extractPos[j], &exchArgSt,
			                NULL, &tmpVal, &tmpExch);	/* PMSTA01649 - TGU - 070405 */
                SET_AMOUNT(posValPtr, PosVal_InstrNetAmt, tmpVal);

                SET_AMOUNT(posValPtr, PosVal_InstrMktValAmt,
                           GET_AMOUNT(posValPtr, PosVal_InstrNetAmt));
            }
            else
            {
                SET_AMOUNT(posValPtr, PosVal_InstrNetAmt,
                           GET_AMOUNT(posValPtr, PosVal_RefNetAmt));

                SET_AMOUNT(posValPtr, PosVal_InstrMktValAmt,
                           GET_AMOUNT(posValPtr, PosVal_RefMktValAmt));
            }

            if (posCurrId != refCurrId)
            {
		        exchArgSt.srcAmt = GET_AMOUNT(posValPtr, PosVal_RefNetAmt);
                FIN_ExchAmt(GET_DATETIME(extractPos[j], ExtPos_ExtPosDate),
                            refCurrId, posCurrId,
			                0, NULL, extractPos[j], &exchArgSt,
			                NULL, &tmpVal, &tmpExch);	/* PMSTA01649 - TGU - 070405 */
                SET_AMOUNT(posValPtr, PosVal_PosNetAmt, tmpVal);

                SET_AMOUNT(posValPtr, PosVal_PosMktValAmt,
                           GET_AMOUNT(posValPtr, PosVal_PosNetAmt));
            }
            else
            {
                SET_AMOUNT(posValPtr, PosVal_PosNetAmt,
                           GET_AMOUNT(posValPtr, PosVal_RefNetAmt));

                SET_AMOUNT(posValPtr, PosVal_PosMktValAmt,
                           GET_AMOUNT(posValPtr, PosVal_RefMktValAmt));
            }

            /* Compute Price and Quote */
	        /* DVP172 */
	        instrPtr = NULL;
	        if(GET_EXTENSION_PTR(extractPos[j], ExtPos_A_Instr_Ext) != NULL)
                instrPtr = *(GET_EXTENSION_PTR(extractPos[j], ExtPos_A_Instr_Ext));
            SET_PRICE(posValPtr, PosVal_Price, CAST_PRICE(GET_AMOUNT(posValPtr, PosVal_InstrMktValAmt)/
                                                 GET_NUMBER(extractPos[j] ,ExtPos_Qty)));/* REF3288 - SSO - 990205 */

            FIN_PriceToQuote((PRICECALCRULE_ENUM)GET_ENUM(posValPtr, PosVal_PriceCalcRuleEn), /* REF7264 - CSY - 020130 */
                             GET_ID(instrPtr, A_Instr_Id), instrPtr,
                             GET_DATETIME(posValPtr, PosVal_Date), NULL,
                             GET_PRICE(posValPtr, PosVal_Price), &quote, posHierHead);

            SET_PRICE(posValPtr, PosVal_Quote, quote);

            SET_NUMBER(posValPtr, PosVal_DebtBaseVal, GET_NUMBER((&resultBaseVal), 0)); /* REF8844 - LJE - 030327 */

        }
    }

    /* REF6220 - LJE - 020319 */
	if (domainPtr != NULL)
	{
	    SET_ID(domainPtr, A_Domain_CurrId, refCurrDomain);
	}


    /* free script and arrays */
    for (k=0; k<scriptNbr; k++)
    {
        SCPT_FreeScptTree(genContBaseValStatic[k]);
        SCPT_FreeScptTree(genContMultipStatic[k]);
        SCPT_FreeScptTree(genContBaseValDyn[k]);
        SCPT_FreeScptTree(genContMultipDyn[k]);
    }
    FREE(extractPos);  /* Only array pointer, copy flag is FALSE */
    FREE(valoOkTab);
    FREE(amtResultTab);
    FREE(refMktValTab);
    FREE(genContBaseValStatic);
    FREE(genContMultipStatic);
    FREE(genContBaseValDyn);
    FREE(genContMultipDyn);

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_ComputeDebtSimpleScript()
**
**  Description :   Compute all debt positions with simple script val rule
**
**  Arguments   :   domainPtr       pointer on domain
**                  posHierHead     hierarchy pointer
**                  valoProcFilter  filter for position to evaluate
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   REF2338 - DDV - 981028
**  Modif.	:
**
*************************************************************************/
RET_CODE FIN_ComputeDebtSimpleScript(DBA_DYNFLD_STP     domainPtr,
			                        DBA_HIER_HEAD_STP   posHierHead,
		                            HIER_FLTFCT         *valoProcFilter) /* REF7264 - LJE - 020131 */
{
    DBA_DYNFLD_STP    instrPtr=NULL, *extractPos=NULL, posValPtr=NULL;
    FLAG_T            copyRecFlg;
    int               i, posNbr=0;
    NUMBER_T          baseValue, multiplier;
    PRICE_T           quote=0.0;
    EXCHANGE_T        tmpExch;
    ID_T              instrCurrId, refCurrId, posCurrId;
    AMOUNT_T          tmpVal,amtResult;
    RET_CODE          ret = RET_SUCCEED;
    FIN_EXCHARG_ST    exchArgSt;			/* REF2313 */

	ID_T              refCurrDomain=0;  /* REF6220 - LJE - 020319 */

    memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));	/* REF2313 */
    /*DBA_SetConnectNoToExchArg(&exchArgSt, DBA_GetConnectNoFromHier(posHierHead)); *//* REF2580 - SSO - 980727 */
    DBA_InitConnectNoToExchArg(&exchArgSt, posHierHead); /* REF4213 - SSO - 991221 */

    /* REF6220 - LJE - 020319 */
	if (domainPtr != NULL)
	{
	    refCurrDomain = GET_ID(domainPtr, A_Domain_CurrId);
	}

    /*** READ EACH EXTENDED POSITION TO VALUATE ***/
    /* Extract positions order by date, instr_id, curr_id and term_tp_id */
    copyRecFlg = FALSE;
    if ((ret = DBA_ExtractHierEltRec(posHierHead, ExtPos,
                                     copyRecFlg, valoProcFilter, NULLFCT,
                                     &posNbr, &extractPos)) != RET_SUCCEED)
    {
        return(ret);
    }

    /* count number of position with val rule in instrument = ValRule_SimpleScript */
    for (i=0; i<posNbr; i++)
    {
	    instrPtr = NULL;


        /* REF6220 - LJE - 020319 : Active the portfolio currency if the def curr flag is "default" */
		FIN_UpdDomainRefCurr(domainPtr, extractPos[i]);

        if (GET_EXTENSION_PTR(extractPos[i],  ExtPos_A_Instr_Ext) != NULL &&
	    (instrPtr = *(GET_EXTENSION_PTR(extractPos[i],  ExtPos_A_Instr_Ext))) != NULL)
        {
       	    if (GET_ENUM(instrPtr, A_Instr_ValRuleEn) == ValRule_SimpleScript)
       	    {
                baseValue=1.0;
                multiplier=1.0;

                /* compute base value and multiplier for position */
                FIN_ComputeDebtSimpleScriptPos(domainPtr, posHierHead,
                                               extractPos[i], &baseValue, &multiplier);

                /* Update PosVal fields (MktVal = NetVal, no accrint for debts) */
                refCurrId = GET_ID(domainPtr,A_Domain_CurrId);
                instrCurrId = GET_ID(extractPos[i], ExtPos_InstrCurrId);
                posCurrId = GET_ID(extractPos[i], ExtPos_PosCurrId);

                if (GET_EXTENSION_PTR(extractPos[i], ExtPos_PosVal_Ext) != NULL &&
	            (posValPtr = *(GET_EXTENSION_PTR(extractPos[i],  ExtPos_PosVal_Ext))) != NULL)
                {
                    amtResult = baseValue * multiplier * GET_AMOUNT(posValPtr, PosVal_RefMktValAmt);
                    amtResult = CAST_AMOUNT(amtResult, refCurrId);

                    SET_AMOUNT(posValPtr, PosVal_RefMktValAmt, amtResult);
                    SET_AMOUNT(posValPtr, PosVal_RefNetAmt,    GET_AMOUNT(posValPtr, PosVal_RefMktValAmt));

                    if (posCurrId != refCurrId)
                    {
	                    exchArgSt.srcAmt = GET_AMOUNT(posValPtr, PosVal_RefNetAmt);
                        FIN_ExchAmt(GET_DATETIME(extractPos[i], ExtPos_ExtPosDate),
                                    refCurrId, posCurrId,
                                    0, NULL, extractPos[i], &exchArgSt,
                                    NULL, &tmpVal, &tmpExch);	/* PMSTA01649 - TGU - 070405 */
                        SET_AMOUNT(posValPtr, PosVal_PosNetAmt, tmpVal);

                        SET_AMOUNT(posValPtr, PosVal_PosMktValAmt,
                                   GET_AMOUNT(posValPtr, PosVal_PosNetAmt));
                    }
                    else
                    {
                        SET_AMOUNT(posValPtr, PosVal_PosNetAmt,
                                   GET_AMOUNT(posValPtr, PosVal_RefNetAmt));

                        SET_AMOUNT(posValPtr, PosVal_PosMktValAmt,
                                   GET_AMOUNT(posValPtr, PosVal_RefMktValAmt));
                    }

                    if (instrCurrId != refCurrId)
                    {
	                    exchArgSt.srcAmt = GET_AMOUNT(posValPtr, PosVal_RefNetAmt);
                        FIN_ExchAmt(GET_DATETIME(extractPos[i], ExtPos_ExtPosDate),
                                    refCurrId, instrCurrId,
                                    0, NULL, extractPos[i], &exchArgSt,
                                    NULL, &tmpVal, &tmpExch);	/* PMSTA01649 - TGU - 070405 */
                        SET_AMOUNT(posValPtr, PosVal_InstrNetAmt, tmpVal);

                        SET_AMOUNT(posValPtr, PosVal_InstrMktValAmt,
                                   GET_AMOUNT(posValPtr, PosVal_InstrNetAmt));
                    }
                    else
                    {
                        SET_AMOUNT(posValPtr, PosVal_InstrNetAmt,
                                   GET_AMOUNT(posValPtr, PosVal_RefNetAmt));

                        SET_AMOUNT(posValPtr, PosVal_InstrMktValAmt,
                                   GET_AMOUNT(posValPtr, PosVal_RefMktValAmt));
                    }

                    /* Compute Price and Quote */
                    /* DVP172 */
                    instrPtr = NULL;
                    if (GET_EXTENSION_PTR(extractPos[i], ExtPos_A_Instr_Ext) != NULL &&
	                (instrPtr = *(GET_EXTENSION_PTR(extractPos[i],  ExtPos_A_Instr_Ext))) != NULL)
                    {
                        SET_PRICE(posValPtr, PosVal_Price, CAST_PRICE(GET_AMOUNT(posValPtr, PosVal_InstrMktValAmt)/ /* REF3288 - SSO - 990205 */
									GET_NUMBER(extractPos[i] ,ExtPos_Qty)));

                        FIN_PriceToQuote((PRICECALCRULE_ENUM)GET_ENUM(posValPtr, PosVal_PriceCalcRuleEn), /* REF7264 - CSY - 020130 */
                                         GET_ID(instrPtr, A_Instr_Id), instrPtr,
                                         GET_DATETIME(posValPtr, PosVal_Date), NULL,
                                         GET_PRICE(posValPtr, PosVal_Price), &quote, posHierHead);

                        SET_PRICE(posValPtr, PosVal_Quote, quote);

                        SET_NUMBER(posValPtr, PosVal_DebtBaseVal, baseValue); /* REF8844 - LJE - 030327 */
                    }
                }
            }
        }
    }

    /* REF6220 - LJE - 020319 */
	if (domainPtr != NULL)
	{
	    SET_ID(domainPtr, A_Domain_CurrId, refCurrDomain);
	}


    FREE(extractPos);  /* Only array pointer, copy flag is FALSE */

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_ComputeDebtSimpleScriptPos()
**
**  Description :   Compute one debt positions with simple script nature
**
**  Arguments   :   domainPtr       pointer on domain
**                  posHierHead     hierarchy pointer
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   REF2338 - DDV - 981029
**  Modif.	:
**
*************************************************************************/
RET_CODE FIN_ComputeDebtSimpleScriptPos(DBA_DYNFLD_STP    domainPtr,
			                            DBA_HIER_HEAD_STP posHierHead,
		                                DBA_DYNFLD_STP    posPtr,
                                        NUMBER_T          *baseValue,
                                        NUMBER_T          *multiplier)
{
    DBA_DYNFLD_STP    instrPtr=NULL, getArgSt=NULL,
                      *scptDefTab=NULL;
    ID_T              instrId = (ID_T) 0;
    SCPT_ARG_STP      genContext = (SCPT_ARG_STP)NULL;
    char              *scptBuf;
    DICT_ATTRIB_STP   attribBaseValue, attribMultiplier;
    int               i, scptDefNbr;
    DBA_DYNFLD_ST     resultBaseValue, resultMultiplier;
    RET_CODE          ret=RET_SUCCEED;

    memset(&resultBaseValue,  0, sizeof(DBA_DYNFLD_ST));   /* REF7264 - RAK - 020307 */
    memset(&resultMultiplier, 0, sizeof(DBA_DYNFLD_ST));   /* REF7264 - RAK - 020307 */

    /* Load and build tree for script */
    instrId = (ID_T) 0;
    attribBaseValue = DBA_GetAttributeBySqlName(Instr, "script_def_base_value");
    attribMultiplier = DBA_GetAttributeBySqlName(Instr, "script_def_multiplier");

    if ((getArgSt = ALLOC_DYNST(Get_Arg)) == NULL)
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, sizeof(DBA_DYNFLD_STP));
        return(RET_MEM_ERR_ALLOC);
    }

    if ((scptBuf = (char *) CALLOC(1, GET_MAXDATALEN(NoteType) * SCPTDEF_MAX_REC)) == NULL) /* PMSTA-33077 - DLA - 181011 */
    {
        FREE_DYNST(getArgSt, Get_Arg);
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, GET_MAXDATALEN(NoteType) * SCPTDEF_MAX_REC);
        return(RET_MEM_ERR_ALLOC);
    }

    /* built script tree */
    /* DVP172 */
    instrPtr = NULL;
    SET_NUMBER((&resultBaseValue), 0, 1.0);
    SET_NUMBER((&resultMultiplier), 0, 1.0);
    if (GET_EXTENSION_PTR(posPtr,  ExtPos_A_Instr_Ext) != NULL &&
	(instrPtr = *(GET_EXTENSION_PTR(posPtr,  ExtPos_A_Instr_Ext))) != NULL)
    {
        /* load script */
        SET_ID(getArgSt, Get_Arg_Id,
        GET_ID(posPtr, ExtPos_InstrId));

        if ((DBA_Select2(ScriptDef, UNUSED, Get_Arg, getArgSt,
                         A_ScriptDef, &scptDefTab, UNUSED, UNUSED,
                         &scptDefNbr, UNUSED, UNUSED)) != RET_SUCCEED)
        {
            FREE_DYNST(getArgSt, Get_Arg);
            FREE(scptBuf);
            return(RET_DBA_ERR_NODATA);
        }
        FREE_DYNST(getArgSt, Get_Arg);

        /* build Base Value script */
        /* construct script string */
        scptBuf[0] = END_OF_STRING;
        for (i=0; i<scptDefNbr; i++)
        {
            if (GET_DICT(scptDefTab[i], A_ScriptDef_AttrDictId) ==
                         attribBaseValue->attrDictId)
                strcat(scptBuf, GET_STRING(scptDefTab[i], A_ScriptDef_Def));
        }

        if (scptBuf[0] != END_OF_STRING)
        {
            /* generate evaluation tree */
            if ((ret = SCPT_GenerateScptTree(scptBuf,
                                             EPos,
                                             InternalSMode,
                                             NumberType,
                                             &genContext)) != RET_SUCCEED)
            {
                FREE(scptBuf);
                DBA_FreeDynStTab(scptDefTab, scptDefNbr, A_ScriptDef);
                return(ret);
            }

            if ((ret = SCPT_ExecScptTree(genContext,
                                         domainPtr,
                                         posHierHead,
                                         posPtr,
                                         NumberType,
                                         &resultBaseValue,
										 NULLDYNST)) != RET_SUCCEED) /* PMSTA14443 - DDV - 120709 */
            {
                SCPT_FreeScptTree(genContext);
                FREE(scptBuf);
                DBA_FreeDynStTab(scptDefTab, scptDefNbr, A_ScriptDef);
                return(ret);
            }

            SCPT_FreeScptTree(genContext);
        }

        /* build Multiplier script */
        /* construct script string */
        scptBuf[0] = END_OF_STRING;
        for (i=0; i<scptDefNbr; i++)
        {
            if (GET_DICT(scptDefTab[i], A_ScriptDef_AttrDictId) == attribMultiplier->attrDictId)
                strcat(scptBuf, GET_STRING(scptDefTab[i], A_ScriptDef_Def));
        }

        if (scptBuf[0] != END_OF_STRING)
        {
            /* generate evaluation tree */
            if ((ret = SCPT_GenerateScptTree(scptBuf,
                                             EPos,
                                             InternalSMode,
                                             NumberType,
                                             &genContext)) != RET_SUCCEED)
            {
                FREE(scptBuf);
                DBA_FreeDynStTab(scptDefTab, scptDefNbr, A_ScriptDef);
                return(ret);
            }

            if ((ret = SCPT_ExecScptTree(genContext,
                                         domainPtr,
                                         posHierHead,
                                         posPtr,
                                         NumberType,
                                         &resultMultiplier,
										 NULLDYNST)) != RET_SUCCEED) /* PMSTA14443 - DDV - 120709 */
            {
                SCPT_FreeScptTree(genContext);
                FREE(scptBuf);
                DBA_FreeDynStTab(scptDefTab, scptDefNbr, A_ScriptDef);
                return(ret);
            }

            SCPT_FreeScptTree(genContext);
        }

        DBA_FreeDynStTab(scptDefTab, scptDefNbr, A_ScriptDef);
    }
    FREE(scptBuf);

    *baseValue = GET_NUMBER((&resultBaseValue), 0);
    *multiplier = GET_NUMBER((&resultMultiplier), 0);

    return(RET_SUCCEED);
}

/***********************************************************************
*
*   Function             : FIN_GenAccrNetValuePos()
*
*   Description          : Generate accrued value and net value position.
*
*   Arguments            : HierHead  : pointer on a ExtPos hierarchy (HierExtPos)
*
*   Return               : RET_SUCCEED             : if ok
*
*   Creation Date        : 24.04.96 - XDI (DVP034)
*   Last Modif           :
*
*************************************************************************/
RET_CODE FIN_GenAccrNetValuePos(PTR hierHead)
{
	DBA_HIER_HEAD_STP posHierHead=(DBA_HIER_HEAD_ST *)hierHead; /* REF7264 - CSY - 020131 */
	DBA_DYNFLD_STP    *extractPos=NULL, newExtPos, posValPtr, instrPtr;
	DBA_DYNFLD_STP    unrealBV=NULL;
	int               posNbr, i, j, nbNewExtPos;
	char              copyRecFlg;
	EXTPOSNAT_ENUM    extPosNature;
	ID_T              bpTpId;
	int               netValue=-1, accrValue=-1;
	int               capitalProfit=-1, capitalLoss=-1;
	int               currencyProfit=-1, currencyLoss=-1;
	int               bookProfit=-1, bookLoss=-1;
    FIN_PL_ST         unrealPL;
	RET_CODE          ret;
    PORTPLCOMPRULE_ENUM portPLCompRule=PortPlCompRule_Dflt;     /* REF7264 - RAK - 020307 */
    CURRPLCOMPRULE_ENUM currPLCompRule=CurrPlCompRule_Instr;    /* REF7264 - RAK - 020307 */
    FLAG_T            useBookValueFlg=FALSE;

	/* create new ExtPos for each PosVal */
	copyRecFlg = FALSE;
	if ((ret = DBA_ExtractHierEltRec(posHierHead, ExtPos,
					 copyRecFlg, NULLFCT, NULLFCT,
					 &posNbr, &extractPos)) != RET_SUCCEED)
		return(ret);

	if (posNbr == 0)
		return(RET_SUCCEED);

    /* Portfolio P&L computation rule */
    GEN_GetApplInfo(ApplPortPlCompRule, &portPLCompRule);

    /* Get system parameter USE_BOOK_VALUES */
   	GEN_GetApplInfo(ApplUseBookValueFlag, &useBookValueFlg); /* DVP430 - XDI - 970620 */

	if ((unrealBV = ALLOC_DYNST(A_BookValue)) == NULL)
	{
		FREE(extractPos);
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	for(i=0; i<posNbr; i++)
	{
	   posValPtr = NULL;
       if (GET_EXTENSION_PTR(extractPos[i], ExtPos_PosVal_Ext) != NULL &&
    	   (posValPtr = *(GET_EXTENSION_PTR(extractPos[i], ExtPos_PosVal_Ext))) != NULL)
	   {
          extPosNature = (EXTPOSNAT_ENUM)GET_ENUM(extractPos[i], ExtPos_NatEn);
          if(extPosNature == ExtPosNat_InitStock || extPosNature == ExtPosNat_FinalStock)
          {
            /* Currency P&L computation rule */     /* REF4347 - 001124 - DED */
            if ((ret=GEN_GetCurrPlCompRule(GET_ID(extractPos[i], ExtPos_PtfId),
                                           NULL,
                                           GET_ID(extractPos[i], ExtPos_PtfPosSetId),
                                           NULL,
                                           hierHead,
                                           UNUSED,
                                           UNUSED,
                                           LogicIdRule_NoValue,
                                           &currPLCompRule)) != RET_SUCCEED)
            {
    			FREE(extractPos);
				FREE_DYNST(unrealBV, A_BookValue);
                return(ret);
            }

			/* Compute all unrealise value (Capital, Currency, Book) */
			FIN_CalcUnrealPL(extractPos[i], posValPtr, portPLCompRule, currPLCompRule,
                             GET_ID(extractPos[i], ExtPos_RefCurrId), PL_All, &unrealPL);

			nbNewExtPos = 0;
			netValue = -1;
			accrValue = -1;
			capitalProfit = -1;
			capitalLoss = -1;
			currencyProfit = -1;
			currencyLoss = -1;
			bookProfit = -1;
			bookLoss = -1;
			if (GET_AMOUNT(posValPtr, PosVal_RefNetAmt) != 0)
			{
				netValue = nbNewExtPos;
				nbNewExtPos++;
			}

			if (GET_AMOUNT(posValPtr, PosVal_RefAccrInterAmt) != 0)
			{
				accrValue = nbNewExtPos;
				nbNewExtPos++;
			}

			if (unrealPL.grossCap > 0)
			{
				capitalProfit = nbNewExtPos;
				nbNewExtPos++;
			}
			else if (unrealPL.grossCap < 0)
			{
				capitalLoss = nbNewExtPos;
				nbNewExtPos++;
			}

			if (unrealPL.grossCurr > 0)
			{
				currencyProfit = nbNewExtPos;
				nbNewExtPos++;
			}
			else if (unrealPL.grossCurr < 0)
			{
				currencyLoss = nbNewExtPos;
				nbNewExtPos++;
			}

            if (useBookValueFlg == TRUE)
			{
				/* Compute all unrealise value (Book) */
				FIN_CalcBookUnrealPL(extractPos[i], posValPtr, (DBA_HIER_HEAD_ST *)hierHead, unrealBV);

				if (GET_AMOUNT(unrealBV, A_BookValue_PtfNetAmt) > 0 ||
				    GET_AMOUNT(unrealBV, A_BookValue_OpNetAmt) > 0 ||
				    GET_AMOUNT(unrealBV, A_BookValue_InstrNetAmt) > 0 ||
				    GET_AMOUNT(unrealBV, A_BookValue_SysNetAmt) > 0)
				{
					bookProfit = nbNewExtPos;
					nbNewExtPos++;
				}
				else if (GET_AMOUNT(unrealBV, A_BookValue_PtfNetAmt) < 0 ||
				         GET_AMOUNT(unrealBV, A_BookValue_OpNetAmt) < 0 ||
				         GET_AMOUNT(unrealBV, A_BookValue_InstrNetAmt) < 0 ||
				         GET_AMOUNT(unrealBV, A_BookValue_SysNetAmt) < 0)
				{
					bookLoss = nbNewExtPos;
					nbNewExtPos++;
				}
			}

			for (j=0; j<nbNewExtPos;j++)
			{
				/* create new ExtPos */
				if ((newExtPos = ALLOC_DYNST(ExtPos)) == NULL)
				{
					FREE(extractPos);
					FREE_DYNST(unrealBV, A_BookValue);
					MSG_RETURN(RET_MEM_ERR_ALLOC);
				}
				COPY_DYNST(newExtPos, extractPos[i], ExtPos);

				SET_NULL_ID(newExtPos, ExtPos_Id);
				SET_NULL_ID(newExtPos, ExtPos_PosValId);

				if (j == netValue)
				{
					FIN_SetNetValueAmt(newExtPos, posValPtr);
				}
				else if (j == accrValue)
				{
					FIN_SetAccrValueAmt(newExtPos, posValPtr);
				}
				else if (j == capitalProfit)
				{
					/* load balance position type from appl_param */
					GEN_GetApplInfo(ApplDfltUnrealCapProfBpTpId, &bpTpId);

					FIN_SetUnrealPLAmt(newExtPos, bpTpId, unrealPL.grossCap);
				}
				else if (j == capitalLoss)
				{
					/* load balance position type from appl_param */
					GEN_GetApplInfo(ApplDfltUnrealCapLossBpTpId, &bpTpId);

					FIN_SetUnrealPLAmt(newExtPos, bpTpId, unrealPL.grossCap);
				}
				else if (j == currencyProfit)
				{
					/* load balance position type from appl_param */
					GEN_GetApplInfo(ApplDfltUnrealCurrProfBpTpId, &bpTpId);

					FIN_SetUnrealPLAmt(newExtPos, bpTpId, unrealPL.grossCurr);
				}
				else if (j == currencyLoss)
				{
					/* load balance position type from appl_param */
					GEN_GetApplInfo(ApplDfltUnrealCurrLossBpTpId, &bpTpId);

					FIN_SetUnrealPLAmt(newExtPos, bpTpId, unrealPL.grossCurr);
				}
				else if (j == bookProfit)
				{
					FIN_SetBookUnrealProfitAmt(newExtPos, unrealBV);
				}
				else if (j == bookLoss)
				{
					FIN_SetBookUnrealLossAmt(newExtPos, unrealBV);
				}

				COPY_DYNFLD(newExtPos, ExtPos, ExtPos_TermTpId,
			            	posValPtr, PosVal, PosVal_TermTpId);

				SET_NULL_EXTENSION(newExtPos, ExtPos_PosVal_Ext);

				SET_FLAG(newExtPos, ExtPos_MainFlg, FALSE);
				SET_PRICE(newExtPos, ExtPos_SpotPrice, 0);
				SET_PERCENT(newExtPos, ExtPos_Rate, 0);
				SET_AMOUNT(newExtPos, ExtPos_SupplAmt, 0);

				COPY_DYNFLD(newExtPos, ExtPos, ExtPos_PosNetAmt,
			            	    newExtPos, ExtPos, ExtPos_PosGrossAmt);

				COPY_DYNFLD(newExtPos, ExtPos, ExtPos_InstrNetAmt,
			            	    newExtPos, ExtPos, ExtPos_InstrGrossAmt);

				COPY_DYNFLD(newExtPos, ExtPos, ExtPos_RefNetAmt,
			            	    newExtPos, ExtPos, ExtPos_RefGrossAmt);

				COPY_DYNFLD(newExtPos, ExtPos, ExtPos_SysNetAmt,
			            	    newExtPos, ExtPos, ExtPos_SysGrossAmt);

				SET_AMOUNT(newExtPos, ExtPos_Bp1PosAmt, 0);
				SET_AMOUNT(newExtPos, ExtPos_Bp2PosAmt, 0);
				SET_AMOUNT(newExtPos, ExtPos_Bp3PosAmt, 0);
				SET_AMOUNT(newExtPos, ExtPos_Bp4PosAmt, 0);
				SET_AMOUNT(newExtPos, ExtPos_Bp5PosAmt, 0);
				SET_AMOUNT(newExtPos, ExtPos_Bp6PosAmt, 0);
				SET_AMOUNT(newExtPos, ExtPos_Bp7PosAmt, 0);
				SET_AMOUNT(newExtPos, ExtPos_Bp8PosAmt, 0);
				SET_AMOUNT(newExtPos, ExtPos_Bp9PosAmt, 0);
				SET_AMOUNT(newExtPos, ExtPos_Bp10PosAmt, 0);

				/* HierAddRec_NoLnk : Don't try to set links, they */
				/* are set after hierarchy sort by DBA_MakeLinks() */

				if ((ret = DBA_AddHierRecord((DBA_HIER_HEAD_ST *)hierHead,
					                     newExtPos, ExtPos, FALSE,
					                     HierAddRec_NoLnk)) != RET_SUCCEED)
				{
					FREE_DYNST(newExtPos, ExtPos);
					FREE(extractPos);
					FREE_DYNST(unrealBV, A_BookValue);
					return(ret);
				}

				/* DVP172 */
				instrPtr = NULL;
	     			if (GET_EXTENSION_PTR(extractPos[i], ExtPos_A_Instr_Ext) != NULL &&
				    (instrPtr = *(GET_EXTENSION_PTR(extractPos[i], ExtPos_A_Instr_Ext))) != NULL)
				    {
					    if ((ret = DBA_ForceLink((DBA_HIER_HEAD_ST *)hierHead, ExtPos,
		        	     		                     ExtPos_A_Instr_Ext, newExtPos,
								     instrPtr)) != RET_SUCCEED)
					    {
			   		        FREE(extractPos);
					        FREE_DYNST(unrealBV, A_BookValue);
			   		        return(ret);
					    }
				    }
                }
		    }
        }
	}

	FREE_DYNST(unrealBV, A_BookValue);
	FREE(extractPos);

	return(RET_SUCCEED);
}


/************************************************************************
**
**  Function    :   FIN_MktVal()
**
**  Description :   This function allows to compute the value of a position
**                  in a financial instrument. It receives as input the
**                  price of the asset and procedes to obtain the clean value
**                  (the value excluding any accrued interest) in the valuation
**                  currency. If required, it will then obtain the accrued
**                  interest for a specified quantity in the reference currency
**                  and finally return the net value in reference currency
**                  as well as all the pertinent details of the calculation.
**
**  Arguments   :   posPtr           pointer on position structure
**                  inputInstrPtr    pointer on instrument or NULL
**                  refDateTime      reference date
**                  fusDateRule      fusion date rule
**                  fullCoupFlg      parameter which determine if accrued
**                                   interest on the 1st interest accrual date
**                                   is equal to 0 or to a full interest period.
**                  calcAccrInterFlg flag which is TRUE if interest must be
**                                   calculated, FALSE if stored data
**                                   can be used.
**                  txdInterFlg      flag which indicates whether the process
**                                   should return after tax accrued interest
**                  mktValPtr        pointer on net value structure to fill
**
**  Return      :   RET_SUCCEED or error code (RET_MEM_ERR_ALLOC, ...)
**                  values of structure mktValPtr will be modified, it will be
**                  - mktValAmt        value + interest in reference currency
**                  - netAmt           value in reference currency
**                  - accrInterRefCurr interest in reference currency
**                  - accrInter        interest in accrued interest currency
**                  - accrInterCurrId  accrued interest currency identifier
**                  - accrInterPeriod  accrued interest days (num, denom)
**                  - accrInterRefExch exchange rate between accrued interest
**                                     currency and reference currency
**                  All field are initialised to 0 or NULL
**
**  Modif       :   DVP125 - RAK - 960620
**  Modif       :   BUG200 - RAK - 961112
**  Modif       :   REF1457 - RAK - 980324
**  Modif       :   REF5922.3511 - AKO - 040702
**  Modif       :   REF7419 - YST - 020313  - market value for swap
**  Modif       :   REF7782 - YST - 020904
**  Modif       :   REF8608 - YST - 030130
**                  REF11218 - TEB - 050627
**
*************************************************************************/
RET_CODE FIN_MktVal(DBA_DYNFLD_STP    posPtr,
                    DBA_DYNFLD_STP    inputInstrPtr,
                    DATETIME_T        refDateTime,
                    DATETIME_T        accrDateTime,
		            FIN_AIARG_STP     aiArgPtr,
	                FIN_MKTVAL_STP    mktValPtr,
	                DBA_HIER_HEAD_STP hierHead)
{
	DBA_DYNFLD_STP instrPtr=NULL, valPtr=NULL;
	FLAG_T         allocOk;
	RET_CODE       ret;
    NUMBER_T            unpaidPrct=0.0;  /* REF5922.3511 - AKO - 040702 */
    INSTRNAT_ENUM  instrNatEn = InstrNat_None;
    SUBNAT_ENUM    instrSubNatEn = SubNat_None;
	PRICE_T       price=0.0;

	mktValPtr->mktValAmt        = 0.0;
	mktValPtr->netAmt           = 0.0;
	mktValPtr->accrInterRefCurr = 0.0;
	mktValPtr->accrInter        = 0.0;
	mktValPtr->accrInterCurrId  = 0;
	mktValPtr->accrInterPeriod.num = 0;
	mktValPtr->accrInterPeriod.denom = 0;
	mktValPtr->accrInterRefExch = 0.0;

	/* Get valorisation extension */
	/* DVP172 */
	valPtr = NULL;
	if (GET_EXTENSION_PTR(posPtr, ExtPos_PosVal_Ext) == NULL ||
	    (valPtr = *(GET_EXTENSION_PTR(posPtr, ExtPos_PosVal_Ext))) == NULL)
	{
	    MSG_SendMesg(RET_DBA_ERR_HIER, 6, FILEINFO, "FIN_MktVal", ExtPos_PosVal_Ext);
		return(RET_DBA_ERR_HIER);
	}

    /* Get position instrument */
	if (inputInstrPtr == NULL)
    {
        /* REF3913 - 990819 - DDV */
        if (DBA_GetInstrById(GET_ID(posPtr, ExtPos_InstrId), FALSE, &allocOk,
                             &instrPtr, hierHead, UNUSED, UNUSED) != RET_SUCCEED)
        {
            SYSNAME_T entSqlName;
            strcpy(entSqlName, DBA_GetDictEntitySqlName(Instr));
            MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO,
                         entSqlName, GET_ID(posPtr, ExtPos_InstrId));
            return(RET_DBA_ERR_NODATA);  /* ?? */
        }
    }
    else
    {
	    instrPtr = inputInstrPtr;
        allocOk = FALSE;
    }

    /* REF8608 - YST - 030130 - formula for partial bonds must be applied to net value */
    if ((PRICECALCRULE_ENUM)GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn) == PriceCalcRule_PartiallyPaidStocks ||
        (PRICECALCRULE_ENUM)GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn) == PriceCalcRule_PartiallyPaidBonds)
    {
		/* PMSTA16076 - DDV - 130315 - If price is equal to quote and unpaid percent is define, it is wrong. Call FIN_QuoteToPrice to update price */
		if (((PRICECALCRULE_ENUM)GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn) == PriceCalcRule_PartiallyPaidStocks &&
			 CMP_PRICE(GET_PRICE(valPtr, PosVal_Price), GET_PRICE(valPtr, PosVal_Quote)) == 0) ||
		    ((PRICECALCRULE_ENUM)GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn) == PriceCalcRule_PartiallyPaidBonds &&
			 CMP_PRICE(GET_PRICE(valPtr, PosVal_Price)*100, GET_PRICE(valPtr, PosVal_Quote)) == 0))
		{
	        FIN_GetChronoNatUnpPrct(instrPtr, &unpaidPrct, refDateTime, hierHead);

			if (unpaidPrct != 0.0)
            {
				if (FIN_QuoteToPrice((PRICECALCRULE_ENUM)GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn),
					                 GET_ID(instrPtr, A_Instr_Id),
								     instrPtr,
								     GET_DATETIME(posPtr, ExtPos_ExtPosDate),
								     NULL,                               /*FIN_PRICEARG_STP   priceArgStp,*/
								     GET_PRICE(valPtr, PosVal_Quote),
			                         &price,
                                     hierHead) == RET_SUCCEED &&
								     price != 0.0)
				{
					SET_PRICE(valPtr, PosVal_Price, price);
				}
			}
		}

		mktValPtr->netAmt = GET_NUMBER(posPtr, ExtPos_Qty) * GET_PRICE(valPtr, PosVal_Price); /* PMSTA16076 - DDV - 130315 - Adapt formula for partially paid stocks and bond to use price */
        mktValPtr->netAmt = CAST_AMOUNT(mktValPtr->netAmt, GET_ID(posPtr, ExtPos_PosCurrId)); /* PMSTA-14620 - LJE - 120910 */
    }
    else
    {
	    /* Calculate value excluding any accrued interest of a quantity */
	    /* in reference currency */
	    if ((ret = FIN_NetVal(refDateTime, GET_ID(posPtr, ExtPos_InstrId), instrPtr, posPtr,
			                  valPtr, aiArgPtr->fullCoupFlg,
			                  &(mktValPtr->netAmt), hierHead)) != RET_SUCCEED)
	    {
		    if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
		    return(ret);
	    }
    }

	/* Market value is net value + accrued interest, */
	/* so init it to net value.                      */
	mktValPtr->mktValAmt = mktValPtr->netAmt;

	/* for debt value accrinterperiod is stored in PosVal */
	/* move it in MktVal and don't compute accr inter.    */
    if (GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_Debt)
	{
		mktValPtr->accrInterPeriod.num   = GET_SMALLINT(valPtr, PosVal_AccrInterNumPeriod);
		mktValPtr->accrInterPeriod.denom = GET_SMALLINT(valPtr, PosVal_AccrInterDenomPeriod);
	}
	else
	{
        /* Calculate accr. interest for qty in reference currency */
		/* DVP125 - RAK - 960620 */
		/* BUG200 - Compute accrued interest in position currency */
		aiArgPtr->accrRule =	AccrRule_None; /* REF11218 - TEB - 050627 */
        aiArgPtr->useDefinedDateFlg = FALSE;   /* PMSTA08308 - 090609 - PMO */
        aiArgPtr->domainRefDateTime = refDateTime ; /*  FPL-PMSTA12114-110601   */


		if ((ret = FIN_AccrInter(accrDateTime, GET_ID(posPtr, ExtPos_InstrId),
		                	    instrPtr, GET_ID(posPtr, ExtPos_PosCurrId),
					            aiArgPtr, GET_NUMBER(posPtr, ExtPos_Qty),
		                	    posPtr, mktValPtr, hierHead)) != RET_SUCCEED)
		{
	    	if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
			return(ret);
		}

        /* REF7419 - YST - 020313 - for standard swap: market value = net value,
           for all other instruments:  market value = net value + accrued interests */
        instrNatEn = (INSTRNAT_ENUM) GET_ENUM(instrPtr, A_Instr_NatEn);
        instrSubNatEn = (SUBNAT_ENUM) GET_ENUM(instrPtr, A_Instr_SubNatEn);

		/* PMSTA-48782 - ankita - 16052022 */
		AppIncDivAccrualPos applIncludeDivAccrualPos = AppIncDivAccrualPos::includeInCashPos;
		GEN_GetApplInfo(ApplIncludeDivAccrualPosEnum, &applIncludeDivAccrualPos);

        /* REF7782 - YST - 020904 - add SubNat_FixFltSwapHedgFix */
        if (!((InstrNat_Swap == instrNatEn &&
            (SubNat_FixFloatStdSwap == instrSubNatEn || SubNat_FixFltSwapHedgFix == instrSubNatEn ||
            SubNat_FixFixStdSwap == instrSubNatEn || SubNat_FltFltStdSwap == instrSubNatEn)) ||
            (InstrNat_Bond == instrNatEn &&
            (SubNat_RecSwapFixedLeg == instrSubNatEn || SubNat_RecSwapFloatLeg == instrSubNatEn ||
            SubNat_PaidSwapFixedLeg == instrSubNatEn || SubNat_PaidSwapFloatLeg == instrSubNatEn)))
		   && !(applIncludeDivAccrualPos == AppIncDivAccrualPos::includeInStockPos && GET_ENUM(instrPtr, A_Instr_NatEn) == (ENUM_T)InstrNat_Stock))
        {
            mktValPtr->mktValAmt += mktValPtr->accrInterRefCurr;
        }
	}

    if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_NetVal()-110752306.2

**
**  Description :   Obtains the value excluding any accrued interest of a
**                  quantity in the valuation (reference) currency.
**
**  Arguments   :   refDateTime       reference date
**                  instrId           instrument identification
**                  inputInstrPtr     pointer on instrument structure or NULL
**                  posPtr            pointer on position structure
**                  valPtr            pointer on valorisation structure
**                  fullCoupFlg       parameter which determine if accrued
**                                    interest on the 1st interest accrual date
**                                    is equal to 0 or to a full interest period.
**                  netAmtPtr         pointer on net amount
**
**  Return      :   RET_SUCCEED and netAmtPtr is clean value
**                  error code  and netAmtPtr is 1
**
**  Modif       :   BUG200 - RAK - 961112
**  Modif       :   DVP440 - RAK - 970428
**  Modif       :   REF495 - RAK - 980519
**  Modif       :   REF2313 - RAK - 980609
**  Modif.	:   REF2580 - SSO - 980727
**  Modif.	:   REF2610 - RAK - 980810
**  Modif.  :   REF5035 - CSY - 020220 force fwdAccFlg, futAccFlg, termAccFlg to FALSE in a context
**                                      of return or synth admin.
**              REF5035 - CSY - 020311: add test on domainPtr not null to avoid crash
**              REF7642 - YST - 020620
**              REF7679 - AKO - 020709
**              REF11163 - TEB - 050616
**              PMSTA-4559 - 011107 - PMO : Futures Management (margin calls)
**              PMSTA-17898 - 160414 - PMO : New Fusion Criteria to manage the contract dates for margin calls after partial closing
**
*************************************************************************/
STATIC RET_CODE FIN_NetVal(DATETIME_T           refDateTime,
                            ID_T                instrId,
                            DBA_DYNFLD_STP      inputInstrPtr,
                            DBA_DYNFLD_STP      posPtr,
                            DBA_DYNFLD_STP      valPtr,
                            char                fullCoupFlg,
                            NUMBER_T *          netAmtPtr,
                            DBA_HIER_HEAD_STP   hierHead)
{
	DBA_DYNFLD_STP instrPtr=NULL;
	INSTRNAT_ENUM  instrNat;
	RET_CODE       ret;
	ID_T           valCurrId=0;
	FLAG_T         allocOk, valDiffOk, testValDiffFlg=FALSE;
	double         qty;
	FLAG_T         fwdAccFlg, futAccFlg, termAccFlg;
	FIN_EXCHARG_ST exchArgSt;			/* REF2313 */
    DBA_DYNFLD_STP domainPtr = DBA_GetDomainPtr(DBA_GetConnectNoFromHier(hierHead));  /* REF5035 - CSY - 020220 */

	memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));	/* REF2313 */
	/*DBA_SetConnectNoToExchArg(&exchArgSt, DBA_GetConnectNoFromHier(hierHead)); *//* REF2580 - SSO - 980727 */
	DBA_InitConnectNoToExchArg(&exchArgSt, hierHead); /* REF4213 - SSO - 991221 */


	*netAmtPtr = 1.0;

	/**** LOAD INSTRUMENT ****/
	/* If instrument structure was load upper, his pointer is given */
	/* in parameters list. So function use it and don't free it.    */
	if (inputInstrPtr != NULL)
	{
		instrPtr = inputInstrPtr;
		allocOk = FALSE;
	}
	else
	{
        /* REF3913 - 990819 - DDV */
        if (DBA_GetInstrById(instrId, FALSE, &allocOk,
                             &instrPtr, hierHead, UNUSED, UNUSED) != RET_SUCCEED)
        {
            SYSNAME_T entSqlName;
            strcpy(entSqlName, DBA_GetDictEntitySqlName(Instr));
            MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO,
                         entSqlName, instrId);
            return(RET_DBA_ERR_NODATA); /* ?? */
        }
	}

	/* Compute adjusted quantity */
		/* SSO - 990208 qty = FIN_Qty(instrPtr, GET_NUMBER(posPtr,ExtPos_Qty)); */
	qty = GET_NUMBER(posPtr, ExtPos_Qty);

	/* In case of no risk valuation, test accounting flags and position */
	/* nature for decide if position is evaluated by difference or not. */
	valDiffOk = FALSE;

	/* REF5300 - RAK - 010717 - future of option, do the */
    /* same valuation in risk view as in accounting view */

	/* PMSTA-10111 - RAK - 110321 - 10 years after a conflict between option on future and EXPOSURE_LIST :) */
    /* comme dans le cas de la perf sur les instruments qui ne sont pas valorisé en risk */
    /* je mets la position initiale à risque et ben je me retrouve dans le else et badaboum */
    /* ça merde ... */
    testValDiffFlg = FALSE;
    if ((EXTPOSRISKNAT_ENUM) GET_ENUM(posPtr, ExtPos_RiskNatEn) == ExtPosRisk_NoRisk ||
		GET_FLAG(instrPtr, A_Instr_NoPerfExpoFlg) == TRUE)
        testValDiffFlg = TRUE;
    else
    {
        FIN_IsFutOptionFlg(instrPtr, hierHead, &testValDiffFlg);
    }

	/* if ((EXTPOSRISKNAT_ENUM) GET_ENUM(posPtr, ExtPos_RiskNatEn) == ExtPosRisk_NoRisk) */
    if (testValDiffFlg == TRUE)
	{
		/* PMSTA-13140 - LJE - 120319 */
		FIN_GetAccFlag(domainPtr,
	     			   posPtr,
					   &futAccFlg,
					   &fwdAccFlg,
					   &termAccFlg);

	    /* REF495 - Suppress test on forward, difference     */
	    /*          is stored in price by FIN_ForwardPrice() */
		if (fwdAccFlg == TRUE && GET_FLAG(posPtr, ExtPos_MainFlg) == TRUE &&
			(GET_ENUM(posPtr, ExtPos_RefNatEn) == PosRefNat_FwdOpen ||
				GET_ENUM(posPtr, ExtPos_RefNatEn) == PosRefNat_FwdClose))
		{
			/* PMSTA-51476 - DDV - 221219 - For this nature, no valo by difference */
			if (GET_ENUM(instrPtr, A_Instr_SubNatEn) != SubNat_FXFwd_TwoLegsAgainsPtfCurr)
			{
				valDiffOk = TRUE;
			}
		}

	    if (futAccFlg == TRUE && GET_FLAG(posPtr, ExtPos_MainFlg) == TRUE &&
	        (GET_ENUM(posPtr, ExtPos_RefNatEn) == PosRefNat_FutOpen     ||
	         GET_ENUM(posPtr, ExtPos_RefNatEn) == PosRefNat_FutClose    ||
	         GET_ENUM(posPtr, ExtPos_RefNatEn) == PosRefNat_FutFifo     ||
             GET_ENUM(posPtr, ExtPos_RefNatEn) == PosRefNat_FutWMP      ||  /* PMSTA-4559 - 011107 - PMO */
             GET_ENUM(posPtr, ExtPos_RefNatEn) == PosRefNat_FutContract ||  /* PMSTA-17898 - 160414 - PMO */
             GET_ENUM(posPtr, ExtPos_RefNatEn) == PosRefNat_FRAClose    ||
		     GET_ENUM(posPtr, ExtPos_RefNatEn) == PosRefNat_FRAOpen))
		    valDiffOk = TRUE;

	    if (termAccFlg == TRUE && GET_FLAG(posPtr, ExtPos_MainFlg) == TRUE &&
	        (GET_ENUM(posPtr, ExtPos_RefNatEn) == PosRefNat_TermOpen ||
	         GET_ENUM(posPtr, ExtPos_RefNatEn) == PosRefNat_TermClose))
		    valDiffOk = TRUE;
	}

    instrNat = (INSTRNAT_ENUM)GET_ENUM(instrPtr, A_Instr_NatEn);

	if (valDiffOk == TRUE &&
	    GET_ENUM(posPtr, ExtPos_RefNatEn) == PosRefNat_FRAClose ||
	    GET_ENUM(posPtr, ExtPos_RefNatEn) == PosRefNat_FRAOpen)
	{
        FIN_SetZeroPosAmt(posPtr);
	    valDiffOk = FALSE;
	}

	if (valDiffOk == TRUE)
	{
	    /* Set position amounts to value 0 */
		/*PMSTA-34291 -NRAO -181227 -Avoid setting pos amts to Zero for forward positions for onlineMktValPL method*/
		if ((GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_Return ||
			GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_PerformanceAnalysis) &&
			(PLMethod_OnLineMktValPL == (PLMETHOD_ENUM)GET_ENUM(domainPtr, A_Domain_PLMethodEn)))
		{
			if (!(GET_ENUM(posPtr, ExtPos_RefNatEn) == PosRefNat_FwdOpen ||
				GET_ENUM(posPtr, ExtPos_RefNatEn) == PosRefNat_FwdClose))
			{
				FIN_SetZeroPosAmt(posPtr);
			}
		}
		else
		{
			FIN_SetZeroPosAmt(posPtr);
		}

        /* REF5229 - SSO - 000921 valCurrId moved from FIN_NetValFutFwdValDiff */
        /* If price curr is not equal to cost price curr, */
	    /* convert the price into cost price currency.    */
	    valCurrId = GET_ID(posPtr, ExtPos_PosCurrId);

        /* REF1055 - RAK - 000202 - Create a function */
        /* REF5586 - RAK - 010207 - Send instrPtr instead of instrNat */
        ret = FIN_NetValFutFwdValDiff(hierHead, posPtr, valPtr, instrPtr, refDateTime,
                                      qty, netAmtPtr);

		if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
		{
			if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
			return(ret);
		}
	}
	else
	{
	    switch (instrNat)
	    {
            /* REF5416 - RAK - 010212 */
            case InstrNat_Forward :
            case InstrNat_CashAcct :
            {
                DBA_DYNFLD_STP  fwdInstrPtr=NULL, fwdPosPtr=NULL;
                NUMBER_T        discFac=1.0;

                if (instrNat == InstrNat_Forward ||
                    (instrNat == InstrNat_CashAcct &&
                     (GET_ENUM(posPtr, ExtPos_RefNatEn) == PosRefNat_FwdOpen ||
	                  GET_ENUM(posPtr, ExtPos_RefNatEn) == PosRefNat_FwdClose)))
                {
                    if (instrNat == InstrNat_CashAcct)  /* Get fwd informations */
                    {
						if (GET_ENUM(posPtr, ExtPos_RiskNatEn) == ExtPosRisk_NoRisk)
						{
							if (GET_EXTENSION_PTR(posPtr, ExtPos_Main_ExtPos_Ext) != NULL)
								fwdPosPtr = *(GET_EXTENSION_PTR(posPtr, ExtPos_Main_ExtPos_Ext));

							if (fwdPosPtr != NULL)
							{
								if (GET_EXTENSION_PTR(fwdPosPtr, ExtPos_A_Instr_Ext) != NULL)
        							fwdInstrPtr = *(GET_EXTENSION_PTR(fwdPosPtr, ExtPos_A_Instr_Ext));
							}
						}
                    }
                    else
                    {
                        fwdInstrPtr = instrPtr;
                        fwdPosPtr   = posPtr;

                    }

					/* PMSTA-8736 - RAK - 100222 - The "computation of discFac was totally wrong */
					/* put a lot of code in garbage and use new Forward discFac computation.     */
					if (fwdInstrPtr != NULL && fwdPosPtr != NULL)
                    {
						ID_T           defaultValuationRuleId;
                        FLAG_T         isFwdValRulePoint, isTheoriticalInstrument;

						FIN_GetAdAMInfoForInstr(fwdInstrPtr, &defaultValuationRuleId,
                                                &isFwdValRulePoint, &isTheoriticalInstrument);

						/* PMSTA-10345 - RAK - 100817 - Only for the theoritical forward */
						if (isTheoriticalInstrument == TRUE && isFwdValRulePoint == TRUE)
						{
							ret = SCE_DiscForwDisc(hierHead, fwdInstrPtr,
											   refDateTime, &discFac);
							if (ret == RET_SUCCEED)
							{
								SET_NUMBER(valPtr, PosVal_DiscFac, discFac);
							}
						}
                    }
                }

                /* discFac coulb be 1.0 if case isn't no exception */
                valCurrId = GET_ID(valPtr, PosVal_PriceCurrId);

                if (IS_NULLFLD(valPtr, PosVal_DiscFac) == FALSE)
                {
                    /* REF6018 - RAK - 010627 */
                    /* Forward = accounting view */
                    /* Cash = risk view done on the cash and the other leg is done by difference */
                    if (instrNat == InstrNat_Forward)
                    {
                        *netAmtPtr = qty * GET_PRICE(valPtr, PosVal_Price) *
                                     GET_NUMBER(valPtr, PosVal_DiscFac);
                    }
                    else
                    {
						*netAmtPtr = qty * GET_NUMBER(valPtr, PosVal_DiscFac);
						/* PMSTA-8637 - RAK - 100212 - 100817 - Don't update price and quote on risk legs */
						if (GET_ENUM(posPtr, ExtPos_RiskNatEn) == ExtPosRisk_NoRisk)
						{
							SET_PRICE(valPtr, PosVal_Price, GET_NUMBER(valPtr, PosVal_DiscFac));
							SET_PRICE(valPtr, PosVal_Quote, GET_PRICE(valPtr, PosVal_Price));
						}
                    }
                }
                else
                {
                    *netAmtPtr = qty * GET_PRICE(valPtr, PosVal_Price);
                }
            }
            break;

	        case InstrNat_Debt :
		        /* check ValRule */
		        if (GET_ENUM(instrPtr, A_Instr_ValRuleEn) == ValRule_Quote1 ||
                            GET_ENUM(instrPtr, A_Instr_ValRuleEn) == ValRule_Script ||
                            GET_ENUM(instrPtr, A_Instr_ValRuleEn) == ValRule_SimpleScript) /* REF2338 - DDV - 981028 */
		        {
			        FIN_NetValDebt(refDateTime, GET_ID(posPtr, ExtPos_InstrId), instrPtr,
				               valPtr, fullCoupFlg, netAmtPtr, qty, posPtr, hierHead);
		        }
		    break;

			/* REF11163 - TEB - 050616 */
			case InstrNat_Bond :
			case InstrNat_ConvertBond :

				valCurrId = GET_ID(valPtr, PosVal_PriceCurrId);

				/* Check price calculation rule */
				/* REF11814 - TEB - 060619 */
				/* Use the right price calc rule, for the case in the past */
				if ( PriceCalcRule_QuoteInUnit == (PRICECALCRULE_ENUM)GET_ENUM(valPtr/*instrPtr*/, PosVal_PriceCalcRuleEn/*A_Instr_PriceCalcRuleEn*/))
				{
					/* If Bonds quoted in unit use the face value */
					*netAmtPtr = qty * GET_PRICE(valPtr, PosVal_Price) * GET_PRICE(instrPtr, A_Instr_FaceValue);
				}
				else
				{
					*netAmtPtr = qty * GET_PRICE(valPtr, PosVal_Price);
				}
				break;

	        default :
		        valCurrId = GET_ID(valPtr, PosVal_PriceCurrId);
		        *netAmtPtr = qty * GET_PRICE(valPtr, PosVal_Price);
		    break;
	    }
	}

	if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}

	/* If necessary, convert founded net amount in ref. currency */
	if (valCurrId == 0)
		valCurrId = GET_ID(instrPtr, A_Instr_RefCurrId);

	/* BUG200 - Exchange net amount (in price currency) to position currency */
	if (valCurrId != GET_ID(posPtr, ExtPos_PosCurrId))
	{
		/* REF2610 - Call now FIN_ExchAmtEuro() */
		exchArgSt.srcAmt = *netAmtPtr;
		return(FIN_ExchAmtEuro(refDateTime, GET_ID(posPtr, ExtPos_RefCurrId),
				       valCurrId,  GET_ID(posPtr, ExtPos_PosCurrId),
			               0, NULL, &exchArgSt, posPtr,
				       NULL, netAmtPtr, NULL));
	}
	else
    {
		/* REF11679 - TGU - 060217 */
		if( (instrNat != InstrNat_Debt) ||
		    (GET_ENUM(instrPtr, A_Instr_ValRuleEn) != ValRule_Script &&
            GET_ENUM(instrPtr, A_Instr_ValRuleEn) != ValRule_SimpleScript))
		{
		/* REF9690 - LJE - 031117 */
        *netAmtPtr = CAST_AMOUNT((*netAmtPtr), valCurrId); /* REF11573 - DDV - 060420 - use the correct currency */
		}
		return(RET_SUCCEED);
    }
}

/************************************************************************
**
**  Function    :   FIN_NetValFutFwdValDiff()
**
**  Description :   Obtains the value by difference for future and forward.
**
**  Arguments   :   posPtr            pointer on position structure
**                  valPtr            pointer on valorisation structure
**                  instrNat          instrument nature
**                  refDateTime       reference date
**                  qty               quantity of the position
**                  netAmtPtr         pointer on net amount
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   REF1055 - RAK -000202
**  Modif		:	PMSTA05649 - TGU- 080219
**
*************************************************************************/
RET_CODE FIN_NetValFutFwdValDiff(PTR            hierHead,
                                 DBA_DYNFLD_STP posPtr,
                                 DBA_DYNFLD_STP valPtr,
                                 DBA_DYNFLD_STP instrPtr,
                                 DATETIME_T     refDateTime,
                                 double         qty,
                                 NUMBER_T       *netAmtPtr)
{
    EXCHANGE_T          exch;
    FIN_EXCHARG_ST      exchArgSt;
    RET_CODE            ret=RET_SUCCEED;
    double              price;
    INSTRNAT_ENUM       instrNat=(INSTRNAT_ENUM) GET_ENUM(instrPtr, A_Instr_NatEn);
	int					bpAmtFld;

	memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));	/* REF2313 */

    /* REF5229 - SSO - 000921: removed valCurrId from here, must be in FIN_NetVal */


    /* REF5416 - RAK - 010118 - Exception (use npv for market value) */
    if (instrNat == InstrNat_Forward)
    {
        ID_T                defaultValuationRuleId;
        FLAG_T              isAALicenseFlag, isTheoriticalInstrument;
        DBA_DYNFLD_STP      advArgStp=NULL, advAStp=NULL, fwdPtr=NULL;
        ID_T                calendarId=-1;

        /* REF5586 - RAK - 010207 - Use fct FIN_GetAdAMInfoForInstr() for more consistency */
        /*
        GEN_GetApplInfo(ApplAALicense, &isAALicenseEn);
        if (isAALicenseEn >= AdamLicencee_Level2)
        */
        FIN_GetAdAMInfoForInstr(instrPtr, &defaultValuationRuleId,
                                &isAALicenseFlag, &isTheoriticalInstrument);
        if (isAALicenseFlag == TRUE && isTheoriticalInstrument==TRUE)	/* PMSTA-10340 - RAK - 100727 */
        {
			/* Call Scecon functions to compute theo price */
			if ((advArgStp = ALLOC_DYNST(AdvA_Arg))==NULL)
			{
			    MSG_RETURN(RET_MEM_ERR_ALLOC);
			}

			if ((advAStp = ALLOC_DYNST(A_AdvA)) == NULL)
			{
			    FREE_DYNST(advArgStp, AdvA_Arg);
			    MSG_RETURN(RET_MEM_ERR_ALLOC);
			}

            if (GET_EXTENSION_PTR(posPtr, ExtPos_A_Instr_Ext) == NULL ||
        		(fwdPtr = *(GET_EXTENSION_PTR(posPtr, ExtPos_A_Instr_Ext))) == NULL)
            {
                MSG_SendMesg(RET_DBA_ERR_HIER, 6,
					         FILEINFO, "FIN_NetValFutFwdValDiff", ExtPos_A_Instr_Ext);
				FREE_DYNST(advArgStp, AdvA_Arg);
                FREE_DYNST(advAStp, A_AdvA);
                return(RET_DBA_ERR_HIER);
            }

			/* ---------------------- */
			/* build keyword argument */
			/* ---------------------- */

			/* CalendarId from reference currency. */
			if (((ret=DBA_GetCalendarFromInstr(fwdPtr, &calendarId))!=RET_SUCCEED) ||
			    (calendarId <= 0))
			{
			    /* force to find a system param. calendar */
			    GEN_GetApplInfo(ApplSysCalendarId, &calendarId);
			}
			SET_ID(advArgStp, AdvA_Arg_CalendarId, calendarId);
            SET_FLAG(advArgStp, AdvA_Arg_CalendarKeyWFlg, FALSE); /* REF5941 - YST - 011219 */

            /* instrument Id */
			SET_ID(advArgStp, AdvA_Arg_InstrId, GET_ID(fwdPtr, A_Instr_Id));

            /* Margin */
			SET_FLAG(advArgStp, AdvA_Arg_Margin, (FLAG_T)TRUE);

            /* domestic */
			SET_FLAG(advArgStp, AdvA_Arg_Domestic, (FLAG_T)TRUE);

            /* ref date */
			SET_DATE(advArgStp, AdvA_Arg_Date, refDateTime.date);

            /* spread */
			SET_NUMBER(advArgStp, AdvA_Arg_Spread, (NUMBER_T)0);

            /* shock */
			SET_NUMBER(advArgStp, AdvA_Arg_Shock, (NUMBER_T)0);

            /* CTD */
			SET_FLAG(advArgStp, AdvA_Arg_MarketCTD, (FLAG_T)TRUE);

			/* set the keyword nature */
			SET_ENUM(advArgStp, AdvA_Arg_KeyWordEn, AdvAKeyWord_DF_Fut);

            /* RAK - 010125 - add posPtr in arg list */
			if ((ret=SCE_ComputeCurrKeyWord(advArgStp, fwdPtr,
							    posPtr, hierHead, advAStp)) == RET_SUCCEED)
			{
                *netAmtPtr = qty * GET_NUMBER(advAStp, A_AdvA_NPV);
            }

            FREE_DYNST(advArgStp, AdvA_Arg);
            FREE_DYNST(advAStp, A_AdvA);
            return(ret);    /* end of exception, and don't do the following code */
        }
    }

	/* REF2610 - In that case, price curr is rarely different from pos curr. */
	if (GET_ID(valPtr, PosVal_PriceCurrId) != GET_ID(posPtr, ExtPos_PosCurrId))
	{
		ret = FIN_GetExchRate(refDateTime, GET_ID(valPtr, PosVal_PriceCurrId),
		                      GET_ID(posPtr, ExtPos_PosCurrId), 0, NULL,
				              posPtr, &exchArgSt, &exch);	/* REF2313 */ /* PMSTA01649 - TGU - 070405 */

		if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
		{
			return(ret);
		}

		price = GET_PRICE(valPtr, PosVal_Price) * exch;
    }
	else
	{
	    price = GET_PRICE(valPtr, PosVal_Price);
	}

	*netAmtPtr = qty * (price - GET_PRICE(posPtr, ExtPos_Price));

	if (instrNat == InstrNat_Forward)
	{
		/* PMSTA05649 - TGU- 080219 - Fees and Tax needs to be taken away from net value for Forwards */
		for (bpAmtFld = ExtPos_Bp1PosAmt; bpAmtFld < (ExtPos_Bp1PosAmt+ExtPos_BpPosAmtNb); bpAmtFld++)
		{
			*netAmtPtr -= GET_NUMBER(posPtr, bpAmtFld);
		}

	    *netAmtPtr /= (1 + GET_NUMBER(valPtr, PosVal_ActuRate));
	}

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_NetValDebt()
**
**  Description :   Obtains the value of debt.
**
**  Arguments   :   refDateTime       reference date
**                  instrId           instrument identification
**                  inputInstrPtr     pointer on instrument structure or NULL
**                  valPtr            pointer on valorisation structure
**                  fullCoupFlg       parameter which determine if accrued
**                                    interest on the 1st interest accrual date
**                                    is equal to 0 or to a full interest period.
**                  netAmtPtr         pointer on net amount
**                  qty               adjusted quantity
**                  posPtr            pointer on position
**
**  Return      :   RET_SUCCEED and netAmtPtr is clean value
**                  error code  and netAmtPtr is 1
**
*************************************************************************/
STATIC RET_CODE FIN_NetValDebt(DATETIME_T     refDateTime,
	                       ID_T           instrId,
	                       DBA_DYNFLD_STP inputInstrPtr,
	                       DBA_DYNFLD_STP valPtr,
                               char           fullCoupFlg,
	                       NUMBER_T       *netAmtPtr,
	                       double         qty,
	                       DBA_DYNFLD_STP posPtr,
                               DBA_HIER_HEAD_STP hierHead)
{
	DBA_DYNFLD_STP 	instrPtr=NULL,
			*iorTab=NULL;
	RET_CODE       	ret;
	PERCENT_T      	amortPrct = 0.0;
	PRICE_T 	quote=0.0;
	FLAG_T         	allocOk;
	int	       	iorNbr=0, i=0;
	long           	period=0, nbOfDays=0, periodTotal=0, daysTotal=0;
	double   	freqMonth=0;
	DATE_T         	date=0, prevDate=0;
	PERCENT_T	proporPrct; /* BUG255 - XDI - 970115 */
        DAY_T           lastDay;
        char            endMonthFlg;

	*netAmtPtr = 0.0;

	/**** LOAD INSTRUMENT ****/
	/* If instrument structure was load upper, his pointer is given */
	/* in parameters list. So function use it and don't free it.    */
	if (inputInstrPtr != NULL)
	{
		instrPtr = inputInstrPtr;
		allocOk = FALSE;
	}
	else
	{
        /* REF3913 - 990819 - DDV */
        if (DBA_GetInstrById(instrId, FALSE, &allocOk,
                             &instrPtr, hierHead, UNUSED, UNUSED) != RET_SUCCEED)
        {
            SYSNAME_T entSqlName;
            strcpy(entSqlName, DBA_GetDictEntitySqlName(Instr));
            MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO,
                         entSqlName, instrId);
            return(RET_DBA_ERR_NODATA); /* ?? */
        }
	}

	ret = DBA_SelectIOREvt(instrPtr, GET_DATETIME(instrPtr, A_Instr_BeginDate),
	                        refDateTime, refDateTime,/*GET_DATETIME(instrPtr, A_Instr_BeginDate),*/
		                    &iorTab, &iorNbr);

	if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
	{
		if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
		return(ret);
	}

	if (iorNbr == 0)
	{
		/* free iorTab */
		for (i=0; i<iorNbr; i++)
			FREE_DYNST(iorTab[i], A_IssueEvt);
		FREE(iorTab);

		if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
   		return(RET_DBA_ERR_NODATA);
	}

    /* PMSTA-22396  - SRIDHARA – 160430 */
    ID_T	calendarId = 0;
	DBA_GetCalendarFromInstr(instrPtr, &calendarId);

	switch ((ISSREDMNAT_ENUM) GET_ENUM(iorTab[0], A_IssueEvt_NatEn))
	{
	case IssRedmNat_DebtProvi :
		i = iorNbr-1;
		while (i >= 0 && GET_ENUM(iorTab[i], A_IssueEvt_NatEn) != IssRedmNat_DebtProvi)
			i--;

		if (i >= 0 && GET_DATE(iorTab[i], A_IssueEvt_EndDate) >= refDateTime.date) /* BUG255 - XDI - 970115 */
		{
			proporPrct = GET_PERCENT(iorTab[i], A_IssueEvt_ProporPrct);

			FIN_PeriodUnitNbr((FREQUNIT_ENUM)GET_ENUM(iorTab[i], A_IssueEvt_FreqUnitEn),    /* REF7264 - CSY - 020130 */
				  	        GET_TINYINT(iorTab[i], A_IssueEvt_Freq),
			          	    FreqUnit_Month, &freqMonth);

			date = GET_DATE(iorTab[i], A_IssueEvt_BegDate);
            endMonthFlg = (char) DATE_IsLastInMonth(date); /* BUG481 - XDI */
            DATE_Get(date, NULL, NULL, &lastDay); /* BUG481 - XDI */

			while (date < refDateTime.date  && freqMonth > 0)
			{
				prevDate = date;
				date = DATE_Move(date, (int) freqMonth, Month);
                /* Short month can corrupt day number */
                DATE_VerifyEndMonth(&date, lastDay, endMonthFlg); /* BUG481 - XDI */
			}
            if (freqMonth == 0)
            {
                proporPrct = 0.0; /* REF2708 - DDV - 980824 */
                period = 1;       /* REF2708 - DDV - 980824 */
                nbOfDays = 0;     /* REF2708 - DDV - 980824 */
            }
            else if (prevDate == 0) /* REF2435 - DDV - 980904 */
            {
                prevDate = date;
                date = DATE_Move(date, (int) freqMonth, Month);
                /* Short month can corrupt day number */
                DATE_VerifyEndMonth(&date, lastDay, endMonthFlg); /* BUG481 - XDI */
                DATE_DaysBetween(prevDate, date,
                                (ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn), /* REF7264 - CSY - 020130 */
                    &period, calendarId); /* PMSTA-22396  - SRIDHARA – 160430 */
                nbOfDays = 0;
            }
            else
            {
                DATE_DaysBetween(prevDate, date,
                                (ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn), /* REF7264 - CSY - 020130 */
                    &period, calendarId); /* PMSTA-22396  - SRIDHARA – 160430 */
                DATE_DaysBetween(prevDate, refDateTime.date,
                                 (ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn), /* REF7264 - CSY - 020130 */
                    &nbOfDays, calendarId); /* PMSTA-22396  - SRIDHARA – 160430 */
            }

		}
		else
		{
			/* proporPrct = 100.0; BUG255 - XDI - 970115 */
			proporPrct = 0.0; /* REF3501 - XDI - 990407 */
			period = 1; /* BUG255 - XDI - 970115 */
			nbOfDays = 1; /* BUG255 - XDI - 970115 */
		}

		*netAmtPtr = qty * GET_PRICE(valPtr, PosVal_Price) *
			         ((AMOUNT_T) nbOfDays / (AMOUNT_T) period) *
			         (proporPrct / 100.0);

		/* Round compute amount only if there is no script definition */
		if (GET_ENUM(instrPtr, A_Instr_ValRuleEn) != ValRule_Script &&
		    GET_ENUM(instrPtr, A_Instr_ValRuleEn) != ValRule_SimpleScript) /* REF2338 - DDV - 981029 */
			*netAmtPtr = CAST_AMOUNT(*netAmtPtr, GET_ID(valPtr,PosVal_PriceCurrId));

		/* Compute Price and Quote */
		SET_PRICE(valPtr, PosVal_Price, CAST_PRICE(*netAmtPtr / GET_NUMBER(posPtr ,ExtPos_Qty)));/* REF3288 - SSO - 990205 */

		FIN_PriceToQuote((PRICECALCRULE_ENUM)GET_ENUM(valPtr, PosVal_PriceCalcRuleEn), /* REF7264 - CSY - 020130 */
		                 GET_ID(instrPtr, A_Instr_Id), instrPtr,
		                 GET_DATETIME(valPtr, PosVal_Date), NULL,
				        GET_PRICE(valPtr, PosVal_Price), &quote, hierHead);

		SET_PRICE(valPtr, PosVal_Quote,       quote);
               	SET_NUMBER(valPtr, PosVal_DebtBaseVal, CAST_NUMBER(GET_NUMBER(posPtr ,ExtPos_Qty) * /* REF3288 - SSO - 990205 */ /* REF8844 - LJE - 030327 */
			   (proporPrct / 100.0)));

		/* Compute period and number of days */
		SET_SMALLINT(valPtr, PosVal_AccrInterNumPeriod, (SMALLINT_T) nbOfDays);
		SET_SMALLINT(valPtr, PosVal_AccrInterDenomPeriod, (SMALLINT_T) period);

		/* If from date is equal to the till date and payment day full */
		/* debt value is equal to 0. */
		if (fullCoupFlg == FALSE && period == nbOfDays)
		{
			/* check if it is the last period day */
            DATE_DaysBetween(prevDate, date, AccrRule_365_365, &period, 0);  /* PMSTA-22396  - SRIDHARA – 160430 */
            DATE_DaysBetween(prevDate, refDateTime.date, AccrRule_365_365, &nbOfDays, 0);  /* PMSTA-22396  - SRIDHARA – 160430 */
            if (period == nbOfDays)
				*netAmtPtr = 0.0;
		}
		break;

	case IssRedmNat_DebtAmort :
		for (i=0; i<iorNbr; i++)
		{
		   if (GET_ENUM(iorTab[i], A_IssueEvt_NatEn) == IssRedmNat_DebtAmort)
		   {
               /* PMSTA-22396  - SRIDHARA – 160430 */
               DATE_DaysBetween(GET_DATE(iorTab[i], A_IssueEvt_BegDate),
			                 GET_DATE(iorTab[i], A_IssueEvt_EndDate),
							 (ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn), &period, calendarId);    /* REF7264 - CSY - 020130 */
                DATE_DaysBetween(GET_DATE(iorTab[i], A_IssueEvt_BegDate),
			                 refDateTime.date, (ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn), /* REF7264 - CSY - 020130 */
							 &nbOfDays, calendarId);
                periodTotal += period;

                if (GET_DATE(iorTab[i], A_IssueEvt_EndDate) <= refDateTime.date)
                {
	                daysTotal += period;
	                amortPrct += GET_PERCENT(iorTab[i], A_IssueEvt_ProporPrct);
                }
                else
                {
	                daysTotal += nbOfDays;
	                if (period != 0)
	                   amortPrct += GET_PERCENT(iorTab[i], A_IssueEvt_ProporPrct) *
                                                    ((AMOUNT_T) nbOfDays/(AMOUNT_T) period);
                }
		   }
		}
		*netAmtPtr = qty * GET_AMOUNT(valPtr, PosVal_Price) * (1-(amortPrct/100));

		/* Round compute amount only if there is no script definition */ /* REF2435 - DDV - 980616 */
		if (GET_ENUM(instrPtr, A_Instr_ValRuleEn) != ValRule_Script &&
		    GET_ENUM(instrPtr, A_Instr_ValRuleEn) != ValRule_SimpleScript) /* REF2338 - DDV - 981029 */
			*netAmtPtr = CAST_AMOUNT(*netAmtPtr, GET_ID(valPtr,PosVal_PriceCurrId));

		/* Compute Price and Quote */
		SET_PRICE(valPtr, PosVal_Price, CAST_PRICE(*netAmtPtr / GET_NUMBER(posPtr ,ExtPos_Qty))); /* REF3288 - SSO - 990205 */

		FIN_PriceToQuote((PRICECALCRULE_ENUM)GET_ENUM(valPtr, PosVal_PriceCalcRuleEn), /* REF7204 - CSY - 020130 */
		                 GET_ID(instrPtr, A_Instr_Id), instrPtr,
		                 GET_DATETIME(valPtr, PosVal_Date), NULL,
		                 GET_PRICE(valPtr, PosVal_Price), &quote, hierHead);

		SET_PRICE(valPtr, PosVal_Quote,       quote);
               	SET_NUMBER(valPtr, PosVal_DebtBaseVal, GET_NUMBER(posPtr ,ExtPos_Qty)); /* BUG326 - XDI - 970408 */ /* REF8844 - LJE - 030327 */

		/* Compute period and number of days */
		SET_SMALLINT(valPtr, PosVal_AccrInterNumPeriod, (SMALLINT_T) daysTotal);
		SET_SMALLINT(valPtr, PosVal_AccrInterDenomPeriod, (SMALLINT_T) periodTotal);
		break;
	default : /* BUG255 - XDI - 970115 */
		*netAmtPtr = qty * GET_PRICE(valPtr, PosVal_Price);

		/* Round compute amount only if there is no script definition */
		if (GET_ENUM(instrPtr, A_Instr_ValRuleEn) != ValRule_Script &&
		    GET_ENUM(instrPtr, A_Instr_ValRuleEn) != ValRule_SimpleScript) /* REF2338 - DDV - 981029 */
			*netAmtPtr = CAST_AMOUNT(*netAmtPtr, GET_ID(valPtr,PosVal_PriceCurrId));

		/* Compute Price and Quote */
		SET_PRICE(valPtr, PosVal_Price, (*netAmtPtr / GET_NUMBER(posPtr ,ExtPos_Qty)));

		FIN_PriceToQuote((PRICECALCRULE_ENUM)GET_ENUM(valPtr, PosVal_PriceCalcRuleEn), /* REF7264 - CSY - 020130 */
		                 GET_ID(instrPtr, A_Instr_Id), instrPtr,
		                 GET_DATETIME(valPtr, PosVal_Date), NULL,
		                 GET_PRICE(valPtr, PosVal_Price), &quote, hierHead);

		SET_PRICE(valPtr, PosVal_Quote,       quote);
               	SET_NUMBER(valPtr, PosVal_DebtBaseVal, GET_NUMBER(posPtr ,ExtPos_Qty));

		/* Compute period and number of days */
		SET_SMALLINT(valPtr, PosVal_AccrInterNumPeriod, 1);
		SET_SMALLINT(valPtr, PosVal_AccrInterDenomPeriod, 1);
		break;
	}

	/* free iorTab */
	for (i=0; i<iorNbr; i++)
		FREE_DYNST(iorTab[i], A_IssueEvt);
	FREE(iorTab);

	if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);}

	return(RET_SUCCEED);
}

/************************************************************************
*
*  Function          : FIN_PtfDefAccount()
*
*  Description       : Get Default payment account for a given currency and
*                      portfolio.
*
*  Arguments         : ptfId          : portfolio id
*                      currId         : currency Id
*                      opNatEnParam   : operation nature (optional)
*                      opTpIdParam    : operation type (optional)
*                      opSubTpIdParam : operation subtype (optional)
*                      aInstrSt       : instrument structure to fill with result
*
*  Return            : RET_SUCCEED
*
*  Creation date     : 08.04.97 - XDI - DVP420
*  Last modification :
*
*************************************************************************/
RET_CODE FIN_PtfDefAccount(ID_T           ptfId,
                           ID_T           currId,
                           ENUM_T         opNatEnParam,
                           ID_T           opTpIdParam,
                           ID_T           opSubTpIdParam,
                           DBA_DYNFLD_STP aInstrSt,
                           DBA_HIER_HEAD_STP hierHead)
{
	DBA_DYNFLD_STP admArgSt=NULL,
	               *sPayInstructTab=NULL,
	               getArgSt=NULL,
	               instrPtr=NULL;
	int            i, rowNb=0;
	int            level1, level2, level3, level4,
	               level5, level6, level7, level8, found,
	               natureParam, typeParam, subtypeParam;
    FLAG_T         allocFlg;

	/*if (ptfId <= 0 || currId <= 0) - REF2194 - if no portfolio, use default cash account - DDV - 980528 */
	if (currId <= 0)
        return(RET_GEN_ERR_INVARG);

	level1 = -1;
	level2 = -1;
	level3 = -1;
	level4 = -1;
	level5 = -1;
	level6 = -1;
	level7 = -1;
	level8 = -1;
	found = -1;

    if (ptfId > 0 )
    {
        if ((admArgSt = ALLOC_DYNST(Adm_Arg)) == NULL)
            MSG_RETURN(RET_MEM_ERR_ALLOC);

        SET_ID(admArgSt, Adm_Arg_Id, ptfId);

        if (DBA_Select2(PayInstruct, UNUSED, Adm_Arg, admArgSt,
                      S_PayInstruct, &sPayInstructTab, UNUSED, UNUSED,
                      &rowNb, UNUSED, UNUSED) != RET_SUCCEED)
        {
            DBA_FreeDynStTab(sPayInstructTab, rowNb, S_PayInstruct);
            FREE_DYNST(admArgSt, Adm_Arg);
            return(RET_DBA_ERR_NODATA);
        }

        FREE_DYNST(admArgSt, Adm_Arg);

        if (opNatEnParam == 0)
            natureParam=FALSE;
        else
            natureParam=TRUE;

        if (opTpIdParam == 0)
            typeParam=FALSE;
        else
            typeParam=TRUE;

        if (opSubTpIdParam == 0)
            subtypeParam=FALSE;
        else
            subtypeParam=TRUE;

        /* To determine witch record is the best matching, a hierarchie is define */
        /* the best matching is level1 and the bad one is level8.                 */
        /*                                                                        */
        /* level1 : every fields match (Ptf, Currency, Nature, Type and Subtype)  */
        /* level2 : matching fields are : Ptf, Currency, Nature, Type             */
        /* level3 : matching fields are : Ptf, Currency, Nature                   */
        /* level4 : matching fields are : Ptf,           Nature, Type and Subtype */
        /* level5 : matching fields are : Ptf,           Nature, Type             */
        /* level6 : matching fields are : Ptf,           Nature                   */
        /* level7 : matching fields are : Ptf, Currency                           */
        /* level8 : matching field is   : Ptf                                     */
        /*                                                                        */
        /* a field match only if Database value egal paramater (if defined).      */
        /* Ptf match for all records (select criteria).                           */
        /* example : Parameters are Ptf/Currency/Nature, no type define and no    */
        /*           subtype define, possible levels are:                         */
        /*           - level3 / level6 / level7 / level8                          */

        for (i=0 ; i<rowNb; i++)
        {
            if (IS_NULLFLD(sPayInstructTab[i], S_PayInstruct_CurrId))
            {
                if (IS_NULLFLD(sPayInstructTab[i], S_PayInstruct_OpNatEn) ||
                    GET_ENUM(sPayInstructTab[i], S_PayInstruct_OpNatEn) == OpNat_None)
                {
                    level8 = i;
                }
                else
                {
                    if ((natureParam == TRUE) &&
                    (GET_ENUM(sPayInstructTab[i], S_PayInstruct_OpNatEn) == opNatEnParam ))
                    {
                        if (IS_NULLFLD(sPayInstructTab[i], S_PayInstruct_OpTpId))
                        {
                            level6 = i;
                        }
                        else
                        {
                            if ((typeParam == TRUE) &&
                            (GET_ID(sPayInstructTab[i], S_PayInstruct_OpTpId) == opTpIdParam))
                            {
                                if (IS_NULLFLD(sPayInstructTab[i], S_PayInstruct_OpSubTpId))
                                {
                                    level5 = i;
                                }
                                else
                                {
                                    if ((subtypeParam == TRUE) &&
                                       (GET_ID(sPayInstructTab[i], S_PayInstruct_OpSubTpId) == opSubTpIdParam))
                                    {
                                        level4 = i;
                                    }
                                }
                            }
                        }
                    }
                }
	        }
	        else /* instrument currency is not null */
	        {
                if (GET_ID(sPayInstructTab[i], S_PayInstruct_CurrId) == currId)
                {
                    if (IS_NULLFLD(sPayInstructTab[i], S_PayInstruct_OpNatEn) ||
                        GET_ENUM(sPayInstructTab[i], S_PayInstruct_OpNatEn) == OpNat_None)
                    {
                        level7 = i;
                    }
                    else
                    {
                        if ((natureParam == TRUE) &&
                        (GET_ENUM(sPayInstructTab[i], S_PayInstruct_OpNatEn) == opNatEnParam))
                        {
                            if (IS_NULLFLD(sPayInstructTab[i], S_PayInstruct_OpTpId))
                            {
                                level3 = i;
                            }
                            else
                            {
                                if ((typeParam == TRUE) &&
                                (GET_ID(sPayInstructTab[i], S_PayInstruct_OpTpId) == opTpIdParam))
                                {
                                    if (IS_NULLFLD(sPayInstructTab[i], S_PayInstruct_OpSubTpId))
                                    {
                                        level2 = i;
                                    }
                                    else
                                    {
                                        if ((subtypeParam == TRUE) &&
                                           (GET_ID(sPayInstructTab[i], S_PayInstruct_OpSubTpId) == opSubTpIdParam))
                                        {
                                            level1 = i;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
	    }/* end for */

        if (level1 != -1)
           found=level1;
        else
           if (level2 != -1)
	         found=level2;
          else
	         if (level3 != -1)
	            found=level3;
	         else
	            if (level4 != -1)
	               found=level4;
	            else
	               if (level5 != -1)
	                  found=level5;
	               else
	                  if (level6 != -1)
	                     found=level6;
	                  else
	                     if (level7 != -1)
	                        found=level7;
	                     else
	                        if (level8 != -1)
	                           found=level8;
    }

	/* if no record match then load system default account for currency */
	if (found == -1)
	{
        if (ptfId > 0 )
   	        DBA_FreeDynStTab(sPayInstructTab, rowNb, S_PayInstruct);

        if ((getArgSt = ALLOC_DYNST(Get_Arg)) == NULL)
        {
	        MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        SET_ID(getArgSt, Get_Arg_RefCurrId, currId);
        SET_ENUM(getArgSt, Get_Arg_NatEn, (ENUM_T)InstrNat_CashAcct);

        if (DBA_Get2(Instr, UNUSED, Get_Arg, getArgSt, A_Instr, &aInstrSt,
	             UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
        {
            FREE_DYNST(getArgSt, Get_Arg);
            return(RET_DBA_ERR_NODATA);
        }

        FREE_DYNST(getArgSt, Get_Arg);

        return(RET_SUCCEED);
	}

    /* REF3913 - 990819 - DDV */
    if (DBA_GetInstrById(GET_ID(sPayInstructTab[found], S_PayInstruct_AccInstrId), FALSE, &allocFlg,
                         &instrPtr, hierHead, UNUSED, UNUSED) != RET_SUCCEED)
    {
       DBA_FreeDynStTab(sPayInstructTab, rowNb, S_PayInstruct);
       return(RET_DBA_ERR_NODATA);
    }

    COPY_DYNST(aInstrSt, instrPtr, A_Instr);

    if (allocFlg == TRUE)
        FREE_DYNST(instrPtr, A_Instr)

   	DBA_FreeDynStTab(sPayInstructTab, rowNb, S_PayInstruct);

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_Qty()
**
**  Description :   Obtains the quantity of the position.
**
**  Arguments   :   instrPtr          pointer on instrument structure or NULL
**                  qty               quantity of instrument to be valued
**
**  ?? code to see ??
**
**  Return      :   qty * adjustment factor (if different from 0) *
**                  quantity adjustment (if different from NULL)
**
*************************************************************************/
#ifdef NOT_USED /* SSO - 990208 */
    double FIN_Qty(DBA_DYNFLD_STP instrPtr, NUMBER_T qty)
    {
	    double newQty;

	    newQty = qty;
	    return(newQty);
    }
#endif

/************************************************************************
**
**  Function    :   FIN_Round()
**
**  Description :   Round an amount depending on currency parameters
**
**  Arguments   :   currId	 currency identification
**                  nbr          number to round
**                  currCd       curency code (Could be NULL)
**
**  Return      :   The rounded number (equal to the received number
**                                      if an error occurs)
**
**  Modif       :   BUG104 - RAK - 960822
**  Modif.      :   REF5248 - RAK - 001005
**
*************************************************************************/
double FIN_Round(ID_T currId, double nbr, CODE_T currCd)
{
    double          precision, roundNbr;
    RNDRULE_ENUM    rule;
    DBA_DYNFLD_STP  currPtr=NULL;
    FLAG_T          freeFlag=FALSE;

    roundNbr = nbr;

    if (currId == 0 && (currCd == NULL || *currCd == END_OF_STRING))
    {
	    /* BUG104 */
	    if (nbr != 0.0)
	    {
	        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
			             "FIN_Round", "currency identifier");
	    }
	    return(roundNbr);
    }

/* REF5248 - RAK - 001005 */
/* Suppress DBA_Get2(Curr) and FREE_DYNST for currPtr */
#if 0
    if (currId != 0)
    {
        FIN_Curr_Hash_Table_Get(currId,&precision,&rule); /* REF4184 SME */
    }
    else
    {
        /* REF4525 */
        FIN_CURR_CODE_ST *found;
        FIN_CURR_CODE_ST key;

        strcpy(key.code,currCd);

        found = (FIN_CURR_CODE_ST *)bsearch(&key,SV_currencyCodeTable,nbCurrencyCodeTable,sizeof(FIN_CURR_CODE_ST),
                                            (int(*)(const void *,const void *))FIN_CmpCurrencyCode);
        if (found)
        {
            precision = found->ptr->precision;
            rule = found->ptr->rule;
        }
        else
        {
            /* take default value for precision and rule */
            FIN_Curr_Hash_Table_Get(currId,&precision,&rule); /* REF4184 SME */
        }
    }
#endif

    if (currId != 0)
    {
        if (DBA_GetCurrById(currId, &currPtr, &freeFlag) == RET_SUCCEED)
        {
            precision = DBA_GetCurrPrecision(currPtr);
            rule = (RNDRULE_ENUM) GET_ENUM(currPtr, A_Curr_RoundRuleEn);

        if (freeFlag == TRUE) {FREE_DYNST(currPtr, A_Curr);}
        }
        else
	    {
            /* take default value for precision and rule */
            precision = SV_DefaultMaxPrecision;  /* PMSTA-36302 - DDV - 190624 - Make 6 digits amount optional */
            rule      = RndRule_None;
	    }
    }
    else if (DBA_GetCurrByCd(currCd, &currPtr, &freeFlag) == RET_SUCCEED)
    {
        precision = DBA_GetCurrPrecision(currPtr);
        rule = (RNDRULE_ENUM) GET_ENUM(currPtr, A_Curr_RoundRuleEn);

        if (freeFlag == TRUE) {FREE_DYNST(currPtr, A_Curr);}
    }
	else
	{
        /* take default value for precision and rule */
        precision = SV_DefaultMaxPrecision; /* PMSTA-36302 - DDV - 190624 - Make 6 digits amount optional */
        rule      = RndRule_None;
	}

    roundNbr = TLS_Round(nbr, precision, rule);
    return(roundNbr);
}

/************************************************************************
**
**  Function    :   FIN_SetAccrValueAmt()
**
**  Description :   Set all accrued value of extended position using pos val
**
**  Arguments   :   newExtPos      extended position to fill
**                  posVal         value of position
**
**  Return      :   NULL or pointer on instrument
**
**  Creation date : 970515 - XDI - DVP468
**  Modif       :
**
*************************************************************************/
STATIC void FIN_SetAccrValueAmt(DBA_DYNFLD_STP newExtPos,
			        DBA_DYNFLD_STP posValPtr)
{
	ID_T              bpTpId;

	/* load balance position type from appl_param */
	GEN_GetApplInfo(ApplDfltAccrValBpTpId, &bpTpId);

	SET_ID(newExtPos, ExtPos_BalPosTpId, bpTpId);

	if (GET_NUMBER(newExtPos, ExtPos_Qty) != 0)
	{
		SET_PRICE(newExtPos, ExtPos_Price,
		           CAST_NUMBER(GET_AMOUNT(posValPtr, PosVal_PosAccrInterAmt)/ /* REF3288 - SSO - 990205 */
		           GET_NUMBER(newExtPos, ExtPos_Qty)));
	}
	else
	{
		SET_PRICE(newExtPos, ExtPos_Price, 0);
	}

	SET_ENUM(newExtPos, ExtPos_PriceCalcRuleEn, PriceCalcRule_None);
	COPY_DYNFLD(newExtPos, ExtPos, ExtPos_Quote,
	            newExtPos, ExtPos, ExtPos_Price);

	SET_AMOUNT(newExtPos, ExtPos_PosGrossAmt,
	           GET_AMOUNT(posValPtr, PosVal_PosAccrInterAmt));

	SET_AMOUNT(newExtPos, ExtPos_InstrGrossAmt,
	           GET_AMOUNT(posValPtr, PosVal_InstrAccrInterAmt));

	SET_AMOUNT(newExtPos, ExtPos_RefGrossAmt,
	           GET_AMOUNT(posValPtr, PosVal_RefAccrInterAmt));

	SET_AMOUNT(newExtPos, ExtPos_SysGrossAmt,
	           (GET_AMOUNT(posValPtr, PosVal_RefAccrInterAmt) /
	           GET_EXCHANGE(newExtPos, ExtPos_SysExchRate)));
}

/************************************************************************
**
**  Function    :   FIN_SetBookUnrealLossAmt()
**
**  Description :   Set all unrealised book value of extended position
**
**  Arguments   :   newExtPos      extended position to fill
**                  bpTpId         balance position type to create
**                  unrealBV       book value structure with unrealised amt
**
**  Return      :
**
**  Creation date : 970515 - XDI - DVP468
**  Modif       :
**
*************************************************************************/
STATIC void FIN_SetBookUnrealLossAmt(DBA_DYNFLD_STP newExtPos,
			             DBA_DYNFLD_STP unrealBV)
{
	ID_T              bpTpId;

	/* load balance position type from appl_param */
	GEN_GetApplInfo(ApplDfltBookUnrealLossBpTpId, &bpTpId);

	SET_ID(newExtPos, ExtPos_BalPosTpId, bpTpId);

	/* REF2189 - DDV - 980528 */
	if (GET_NUMBER(newExtPos, ExtPos_Qty) != 0)
	{
		SET_PRICE(newExtPos, ExtPos_Price,
		           CAST_NUMBER( GET_AMOUNT(unrealBV, A_BookValue_OpNetAmt)/ /* REF3288 - SSO - 990205 */
					GET_NUMBER(newExtPos, ExtPos_Qty)));
	}
	else
	{
		SET_PRICE(newExtPos, ExtPos_Price, 0);
	}

	COPY_DYNFLD(newExtPos, ExtPos, ExtPos_Quote, /* REF2189 - DDV - 980528 */
	            newExtPos, ExtPos, ExtPos_Price);

	/* COPY_DYNFLD(newExtPos, ExtPos, ExtPos_Price, - REF2189 - DDV - 980528
                    unrealBV, A_BookValue, A_BookValue_Price);

	COPY_DYNFLD(newExtPos, ExtPos, ExtPos_Quote,
                    unrealBV, A_BookValue, A_BookValue_Quote); */

	/* inverse sign of ammount for balance position */
	/* profit : amt < 0 and loss amt > 0 */
	if (GET_NUMBER(unrealBV, A_BookValue_PtfNetAmt) < 0)
	{
		SET_AMOUNT(newExtPos, ExtPos_RefGrossAmt,
	                   GET_AMOUNT(unrealBV, A_BookValue_PtfNetAmt) * (-1));
	}
	else
		SET_AMOUNT(newExtPos, ExtPos_RefGrossAmt, 0);

	if (GET_NUMBER(unrealBV, A_BookValue_OpNetAmt) < 0)
	{
		SET_AMOUNT(newExtPos, ExtPos_PosGrossAmt,
	                   GET_AMOUNT(unrealBV, A_BookValue_OpNetAmt) * (-1));
	}
	else
		SET_AMOUNT(newExtPos, ExtPos_PosGrossAmt, 0);

	if (GET_NUMBER(unrealBV, A_BookValue_InstrNetAmt) < 0)
	{
		SET_AMOUNT(newExtPos, ExtPos_InstrGrossAmt,
	                   GET_AMOUNT(unrealBV, A_BookValue_InstrNetAmt) * (-1));
	}
	else
		SET_AMOUNT(newExtPos, ExtPos_InstrGrossAmt, 0);

	if (GET_NUMBER(unrealBV, A_BookValue_SysNetAmt) < 0)
	{
		SET_AMOUNT(newExtPos, ExtPos_SysGrossAmt,
	                   GET_AMOUNT(unrealBV, A_BookValue_SysNetAmt) * (-1));
	}
	else
		SET_AMOUNT(newExtPos, ExtPos_SysGrossAmt, 0);
}

/************************************************************************
**
**  Function    :   FIN_SetBookUnrealProfitAmt()
**
**  Description :   Set all unrealised book value of extended position
**
**  Arguments   :   newExtPos      extended position to fill
**                  bpTpId         balance position type to create
**                  unrealBV       book value structure with unrealised amt
**
**  Return      :
**
**  Creation date : 970515 - XDI - DVP468
**  Modif       :
**
*************************************************************************/
STATIC void FIN_SetBookUnrealProfitAmt(DBA_DYNFLD_STP newExtPos,
			               DBA_DYNFLD_STP unrealBV)
{
	ID_T              bpTpId;

	/* load balance position type from appl_param */
	GEN_GetApplInfo(ApplDfltBookUnrealProfBpTpId, &bpTpId);

	SET_ID(newExtPos, ExtPos_BalPosTpId, bpTpId);

	/* REF2189 - DDV - 980528 */
	if (GET_NUMBER(newExtPos, ExtPos_Qty) != 0)
	{
		SET_PRICE(newExtPos, ExtPos_Price,
		           CAST_NUMBER( GET_AMOUNT(unrealBV, A_BookValue_OpNetAmt)/  /* REF3288 - SSO - 990205 */
					GET_NUMBER(newExtPos, ExtPos_Qty)));
	}
	else
	{
		SET_PRICE(newExtPos, ExtPos_Price, 0);
	}

	COPY_DYNFLD(newExtPos, ExtPos, ExtPos_Quote, /* REF2189 - DDV - 980528 */
	            newExtPos, ExtPos, ExtPos_Price);

	/* COPY_DYNFLD(newExtPos, ExtPos, ExtPos_Price, - REF2189 - DDV - 980528
                    unrealBV, A_BookValue, A_BookValue_Price);

	COPY_DYNFLD(newExtPos, ExtPos, ExtPos_Quote,
                    unrealBV, A_BookValue, A_BookValue_Quote); */

	/* inverse sign of ammount for balance position */
	/* profit : amt < 0 and loss amt > 0 */
	if (GET_NUMBER(unrealBV, A_BookValue_PtfNetAmt) > 0)
	{
		SET_AMOUNT(newExtPos, ExtPos_RefGrossAmt,
	                   GET_AMOUNT(unrealBV, A_BookValue_PtfNetAmt) * (-1));
	}
	else
		SET_AMOUNT(newExtPos, ExtPos_RefGrossAmt, 0);

	if (GET_NUMBER(unrealBV, A_BookValue_OpNetAmt) > 0)
	{
		SET_AMOUNT(newExtPos, ExtPos_PosGrossAmt,
	                   GET_AMOUNT(unrealBV, A_BookValue_OpNetAmt) * (-1));
	}
	else
		SET_AMOUNT(newExtPos, ExtPos_PosGrossAmt, 0);

	if (GET_NUMBER(unrealBV, A_BookValue_InstrNetAmt) > 0)
	{
		SET_AMOUNT(newExtPos, ExtPos_InstrGrossAmt,
	                   GET_AMOUNT(unrealBV, A_BookValue_InstrNetAmt) * (-1));
	}
	else
		SET_AMOUNT(newExtPos, ExtPos_InstrGrossAmt, 0);

	if (GET_NUMBER(unrealBV, A_BookValue_SysNetAmt) > 0)
	{
		SET_AMOUNT(newExtPos, ExtPos_SysGrossAmt,
	                   GET_AMOUNT(unrealBV, A_BookValue_SysNetAmt) * (-1));
	}
	else
		SET_AMOUNT(newExtPos, ExtPos_SysGrossAmt, 0);
}

/************************************************************************
**
**  Function    :   FIN_SetNetValueAmt()
**
**  Description :   Set all net value of extended position using pos val
**
**  Arguments   :   newExtPos      extended position to fill
**                  posValPtr      value of position
**
**  Return      :
**
**  Creation date : 970515 - XDI - DVP468
**  Modif       :
**
*************************************************************************/
STATIC void FIN_SetNetValueAmt(DBA_DYNFLD_STP newExtPos,
		   	       DBA_DYNFLD_STP posValPtr)
{
	ID_T              bpTpId;

	/* load balance position type from appl_param */
	GEN_GetApplInfo(ApplDfltNetValBpTpId, &bpTpId);

	SET_ID(newExtPos, ExtPos_BalPosTpId, bpTpId);

	if (GET_NUMBER(newExtPos, ExtPos_Qty) != 0)
	{
		SET_PRICE(newExtPos, ExtPos_Price,
		           CAST_NUMBER(GET_AMOUNT(posValPtr, PosVal_PosNetAmt)/ /* REF3288 - SSO - 990205 */
					GET_NUMBER(newExtPos, ExtPos_Qty)));
	}
	else
	{
		SET_PRICE(newExtPos, ExtPos_Price, 0);
	}

	COPY_DYNFLD(newExtPos, ExtPos, ExtPos_PriceCalcRuleEn,
	            posValPtr, PosVal, PosVal_PriceCalcRuleEn);

	COPY_DYNFLD(newExtPos, ExtPos, ExtPos_Quote,
	            posValPtr, PosVal, PosVal_Quote);

	SET_AMOUNT(newExtPos, ExtPos_PosGrossAmt,
	           GET_AMOUNT(posValPtr, PosVal_PosNetAmt));

	SET_AMOUNT(newExtPos, ExtPos_InstrGrossAmt,
	           GET_AMOUNT(posValPtr, PosVal_InstrNetAmt));

	SET_AMOUNT(newExtPos, ExtPos_RefGrossAmt,
	           GET_AMOUNT(posValPtr, PosVal_RefNetAmt));

	SET_AMOUNT(newExtPos, ExtPos_SysGrossAmt,
	           GET_AMOUNT(posValPtr, PosVal_RefNetAmt) /
	           GET_EXCHANGE(newExtPos, ExtPos_SysExchRate));
}

/************************************************************************
**
**  Function    :   FIN_SetUnrealPLAmt()
**
**  Description :   Set all unrealised PL value of extended position using amt
**
**  Arguments   :   newExtPos      extended position to fill
**                  bpTpId         balance position type to create
**                  amt            amount of PL
**
**  Return      :
**
**  Creation date : 970515 - XDI - DVP468
**  Modif       :
**
*************************************************************************/
STATIC void FIN_SetUnrealPLAmt(DBA_DYNFLD_STP newExtPos,
		               ID_T           bpTpId,
			       AMOUNT_T       amt)
{
	/* inverse sign of ammount for balance position */
	/* profit : amt < 0 and loss amt > 0 */
	amt *= -1;

	SET_ID(newExtPos, ExtPos_BalPosTpId, bpTpId);

	if (GET_NUMBER(newExtPos, ExtPos_Qty) != 0)
	{
		SET_PRICE(newExtPos, ExtPos_Price,
		           CAST_NUMBER(amt / GET_NUMBER(newExtPos, ExtPos_Qty))); /* REF3288 - SSO - 990205 */
	}
	else
	{
		SET_PRICE(newExtPos, ExtPos_Price, 0);
	}

	SET_ENUM(newExtPos, ExtPos_PriceCalcRuleEn, PriceCalcRule_None);
	COPY_DYNFLD(newExtPos, ExtPos, ExtPos_Quote,
	            newExtPos, ExtPos, ExtPos_Price);

	SET_AMOUNT(newExtPos, ExtPos_PosGrossAmt,
                   amt / GET_AMOUNT(newExtPos, ExtPos_PosExchRate));

	SET_AMOUNT(newExtPos, ExtPos_InstrGrossAmt,
                   amt / GET_AMOUNT(newExtPos, ExtPos_InstrExchRate));

	SET_AMOUNT(newExtPos, ExtPos_RefGrossAmt, amt);

	SET_AMOUNT(newExtPos, ExtPos_SysGrossAmt,
                   amt / GET_EXCHANGE(newExtPos, ExtPos_SysExchRate));
}

/************************************************************************
**
**  Function    :   FIN_SetZeroPosAmt()
**
**  Description :   Set position amounts to value 0.
**
**  Arguments   :   posPtr        position array pointer
**
**  Return      :   TRUE when position is updated, FALSE elsewhere
**
**  Modif.	:   REF3082 - RAK - 981130 (STATIC -> EXTERN)
**			:	PMSTA09649 - TGU - 080219 ( Keep fees and taxes for the forwards )
**
*************************************************************************/
FLAG_T FIN_SetZeroPosAmt(DBA_DYNFLD_STP posPtr)
{
	SET_AMOUNT(posPtr, ExtPos_SupplAmt,      0.0);

    /* PMSTA-10595 - LJE - 100909 - Keep all fees and taxes */
	SET_AMOUNT(posPtr, ExtPos_RefNetAmt,  GET_AMOUNT(posPtr, ExtPos_RefNetAmt) - GET_AMOUNT(posPtr, ExtPos_RefGrossAmt));
	SET_AMOUNT(posPtr, ExtPos_SysNetAmt,  GET_AMOUNT(posPtr, ExtPos_SysNetAmt) - GET_AMOUNT(posPtr, ExtPos_SysGrossAmt));
	SET_AMOUNT(posPtr, ExtPos_PosNetAmt,  GET_AMOUNT(posPtr, ExtPos_PosNetAmt) - GET_AMOUNT(posPtr, ExtPos_PosGrossAmt));
	SET_AMOUNT(posPtr, ExtPos_InstrNetAmt,  GET_AMOUNT(posPtr, ExtPos_InstrNetAmt) - GET_AMOUNT(posPtr, ExtPos_InstrGrossAmt));

	SET_AMOUNT(posPtr, ExtPos_PosGrossAmt,   0.0);
	SET_AMOUNT(posPtr, ExtPos_InstrGrossAmt, 0.0);
	SET_AMOUNT(posPtr, ExtPos_RefGrossAmt,   0.0);
	SET_AMOUNT(posPtr, ExtPos_SysGrossAmt,   0.0);

	return(TRUE);
}


/************************************************************************
**
**  Function    :   FIN_GetChronoNatUnpPrct()
**
**  Description :   retrieve in table Chrono the value UnpPrct
**
**  Arguments   :   instrPtr - curent instr.
**              :   UnpPrct  - the value to read in database
**              :   hierHead - hierachy head
**              :   refDate  - from date
**              :
**  Return      :   TRUE when position is updated, FALSE elsewhere
**
**  Modif.	:   :   REF5922.3511  - 010702 - AKO :
*************************************************************************/
RET_CODE FIN_GetChronoNatUnpPrct(DBA_DYNFLD_STP      instrPtr,
                                 NUMBER_T            *unpaidPrctPtr,
                                 DATETIME_T          refDate,
                                 DBA_HIER_HEAD_STP   hierHead)
{
    DBA_DYNFLD_STP      dimChronoPtr=NULL, instrChrono=NULL;
    RET_CODE            retCde=RET_SUCCEED;
    DATETIME_T          chronoDate;
    ID_T                instrId=0;


	*unpaidPrctPtr = 0.0;
    chronoDate.date = refDate.date;
    chronoDate.time = 0;

	if ((instrChrono = ALLOC_DYNST(A_InstrChrono)) == NULL)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

	if (GET_ID(instrPtr, A_Instr_Id) < 0)
		instrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
	else
		instrId = GET_ID(instrPtr, A_Instr_Id);

	if ((dimChronoPtr = ALLOC_DYNST(Dim_InstrChrono)) == NULL)
	{
		FREE_DYNST(instrChrono, A_InstrChrono);
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	SET_ID(dimChronoPtr,       Dim_InstrChrono_InstrId,     instrId);
    SET_ENUM(dimChronoPtr,     Dim_InstrChrono_NatEn,       ChronoNat_UnpPrct);
	SET_FLAG(dimChronoPtr,     Dim_InstrChrono_ComputeFlg,  FALSE);

    /* chronoDate (begin of the accrued period) instead of refDate */
	SET_DATETIME(dimChronoPtr, Dim_InstrChrono_RefDate,     chronoDate);
	retCde = FIN_InstrChrono(dimChronoPtr, instrPtr, instrChrono, hierHead);

	FREE_DYNST(dimChronoPtr, Dim_InstrChrono);

	if (retCde != RET_SUCCEED)  	/* In log file, missing chrono is signaled */
	{
		*unpaidPrctPtr = 0.0;
        retCde = RET_SUCCEED;       /* REF8608 - YST - 030211 */
	}
	else
	{
		/*
		** TGU-REF11704-060413-Use GET_LONGAMOUNT since data type for field
		** instr_chrono.value_n has been changed from NUMBER to LONGAMOUTN.
		*/
		*unpaidPrctPtr = GET_LONGAMOUNT(instrChrono, A_InstrChrono_Val);
	}
	FREE_DYNST(instrChrono, A_InstrChrono);

    return(retCde);
}


/************************************************************************
*
*  Function    : FIN_UpdDomainRefCurr
*
*  Description : Update the reference currency of domain with the portfolio currency (in extPos).
*                Only if the domain def curr flag is "Default".
*
*  Arguments   : domaintPtr, extPos
*
*  Return      : RET_SUCCEED
*
*  Creation D. : REF6220 - LJE - 020319
*  Last modif. :
*
*************************************************************************/
RET_CODE FIN_UpdDomainRefCurr(DBA_DYNFLD_STP domainPtr, DBA_DYNFLD_STP extPos)
{

	DBA_DYNFLD_STP ptfPtr=NULL;

    /* REF6220 - LJE - 020319 : Active the portfolio currency if the def curr flag is "default" */
	if (domainPtr != NULL &&
		GET_FLAG(domainPtr, A_Domain_DefCurrFlg) == TRUE &&
		GET_EXTENSION_PTR(extPos,  ExtPos_A_Ptf_Ext) != NULL &&
		(ptfPtr = *(GET_EXTENSION_PTR(extPos,  ExtPos_A_Ptf_Ext))) != NULL &&
		IS_NULLFLD(ptfPtr, A_Ptf_CurrId) == FALSE )
	{
		SET_ID(domainPtr, A_Domain_CurrId, GET_ID(ptfPtr, A_Ptf_CurrId));
	}

	return RET_SUCCEED;

}

/************************************************************************
**
**  Function    :   FIN_FilterTechnicalPosition()
**
**  Description :   Extract TechnicalPosition
**                  Used by hierarchy tools function
**                  return TRUE  -> record must be extract (or deleted)
**                         FALSE -> record musn't be extract (or deletde)
**
**  Arguments   :   dynSt      dynamic structure pointer
**                  dynStTp    dynamic structure definition
**
**  Return      :   TRUE or FALSE
**
**  Creation    :   PMSTA-22672 - DDV - 160301 - Remove technical positions
**  Modif       :
**
*************************************************************************/
STATIC int FIN_FilterTechnicalPosition(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP notUsed)
{
    if (DBA_IsTechnicalPosition(dynSt) == true)
	    return(TRUE);
    else
	    return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_DelTechnicalPosFromHier()
**
**  Description :   Del and free all technical positions from hierarchy
**
**  Arguments   :   hierHead   hierachy
**
**  Return      :
**
**  Creation    :   PMSTA-22672 - DDV - 160310 - Remove technical positions
**  Modif       :
**
*************************************************************************/
void FIN_DelTechnicalPosFromHier(DBA_HIER_HEAD_STP hierHead)
{
    DBA_DelAndFreeHierEltRecWithFilter(hierHead, ExtPos, FIN_FilterTechnicalPosition, NULLDYNST, NULL);
}

/************************************************************************
**
**  Function		   :   FIN_isFwdQuoteInstr()
**
**  Description		   :   check if instrument passed is forward instrument
**							FORWARD_VAL_RULE = Forward_Quote
**							FWD_ACC_FLAG = 0
**
**  Arguments		   :   DBA_DYNFLD_STP - extPosPtr
**
**
**  Return			   :   TRUE/FALSE
**
**  Creation date      : PMSTA-44218 - Savitha - 12052021
**  Last modification  :
**
*************************************************************************/
bool FIN_isFwdQuoteInstr(DBA_DYNFLD_STP      posPtr,
	DBA_DYNFLD_STP    instrPtr)
{
    if (instrPtr != NULL && CMP_ENUM(GET_ENUM(instrPtr, A_Instr_SubNatEn), SubNat_FXFwd_TwoLegsAgainsPtfCurr) == 0 &&
        GET_FLAG(posPtr, ExtPos_AcctFlg) == TRUE)
    {
            return TRUE;
    }

	return FALSE;
}

/************************************************************************
**  Function             :  FIN_IsPerfTimingRuleSet()
**
**  Description          :  Check if Perf Timing rule is maintained and
**                            accordingly update the invest timing rule
**
**  Arguments            :  hierHead                 Hierarchy Head
**                          extPos                   ExtPos pointer
**                          retInvestTimingRuleEn    Timing rule enum
**
**  Return               :  true or false
**
**  Creation             :  PMSTA-40491 - vkumar - 030920
**
**  Modif.               :
*************************************************************************/
bool FIN_IsPerfTimingRuleSet(DBA_HIER_HEAD_STP        hierHead,
                             const DBA_DYNFLD_STP     extPos,
                             INVESTTIMINGRULE_ENUM &  retInvestTimingRuleEn)
{
    PerfTimingRuleTimingRuleEn perfTimingRuleEn = PerfTimingRuleTimingRuleEn::EndOfTheDay;

    if (FIN_IsPerfTimingRuleSet(hierHead, extPos, perfTimingRuleEn))
    {
        retInvestTimingRuleEn = (PerfTimingRuleTimingRuleEn::BeginningOfTheDay == perfTimingRuleEn) ? InvestTimingRule_Beginning : InvestTimingRule_End;
        return(true);
    }
    return (false);
}

/************************************************************************
**  Function             :  FIN_IsPerfTimingRuleSet()
**
**  Description          :  Check if Perf Timing rule is maintained and
**                            accordingly update the invest timing rule
**
**  Arguments            :  hierHead                 Hierarchy Head
**                          extPos                   ExtPos pointer
**                          retInvestTimingRuleEn    Timing rule enum
**
**  Return               :  true or false
**
**  Creation             :  PMSTA-40491 - vkumar - 030920
**
**  Modif.               :
*************************************************************************/
bool FIN_IsPerfTimingRuleSet(DBA_HIER_HEAD_STP        hierHead,
                             const DBA_DYNFLD_STP     extPos,
                             PerfTimingRuleTimingRuleEn &  perfTimingRuleEn)
{
    bool        isPerfTimingRuleSet = false;
    MemoryPool  mp;

    if (hierHead == NULL)
    {
        hierHead = static_cast<DBA_HIER_HEAD_STP>(DBA_GetHierOptiPtr());
    }

    if (NULL != hierHead &&
        NULLDYNST != extPos)
    {
        DBA_DYNFLD_STP operPtr = NULLDYNST;

        if (GET_EXTENSION_PTR(extPos, ExtPos_Open_A_Op_Ext) != NULL)
        {
            operPtr = *GET_EXTENSION_PTR(extPos, ExtPos_Open_A_Op_Ext);
        }

        if (NULLDYNST == operPtr)
        {
            operPtr = DBA_SearchHierRecById(hierHead, A_Op, A_Op_Id, GET_ID(extPos, ExtPos_OpenOpId));
        }

        /* get operation if not present in hierarchy */
        if (NULLDYNST == operPtr)
        {
            return isPerfTimingRuleSet;
        }

        /* Get appropriate timing rule */
        /* Get the main instrument from operation as for the main instrument and cash,
           the timing rule has to be derived as per main instrument nature */
        DBA_DYNFLD_STP instrPtr = NULLDYNST;
        FLAG_T         allocInstrOk = FALSE;

        if (GET_EXTENSION_PTR(extPos, ExtPos_A_Instr_Ext) != NULL)
        {
            instrPtr = *GET_EXTENSION_PTR(extPos, ExtPos_A_Instr_Ext);
        }

        if (NULLDYNST == instrPtr)
        {

            if (RET_SUCCEED != DBA_GetInstrById(GET_ID(operPtr, A_Op_InstrId), TRUE, &allocInstrOk,                                       /* PMSTA-41826 - vkumar - 170920 */
                &instrPtr, hierHead, UNUSED, UNUSED) ||
                NULLDYNST == instrPtr)
            {
                return isPerfTimingRuleSet;
            }
        }

          /* PMSTA-47582 - JBC - 220406 */
        if (IS_NULLFLD(extPos, ExtPos_OpenOpTpId))
        {
            COPY_DYNFLD(extPos, ExtPos, ExtPos_OpenOpTpId, operPtr, A_Op, A_Op_TpId);
        }

        if (IS_NULLFLD(extPos, ExtPos_OpenOpTpId))
        {
            COPY_DYNFLD(extPos, ExtPos, ExtPos_OpenOpSubTpId, operPtr, A_Op, A_Op_SubTpId);
        }

        perfTimingRuleEn = OPE_GetPerfTimingRule(extPos, instrPtr);
        isPerfTimingRuleSet = true;
    }
    return isPerfTimingRuleSet;
}

/************************************************************************
**      END  finlib01.c                                          UNICIBLE
*************************************************************************/

/************************************************************************
**
**           Copyright (C) 1995-2024 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DBADICT_C

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define TIME_H
#define STDLIB_H
#define STRING_H

#include <assert.h>
#include "unidef.h"     /* Mandatory */
#include "icu4aaa.h" /* DLA */
#include <unicode/unistr.h>
#include "dbiconnection.h"
#include "fmtlib01.h"   /* For GUI structures and for the FAMOUS function */

#ifndef DBA_H
#include "dba.h"
#endif

#include "gen.h"

#ifndef SYSLIB_H
#include "syslib.h"     /* Necessary for FREE  PMO - Rename our sys.h to syslib.h and use it */
#endif

#include "date.h"

#ifndef TLS_H
#include "tls.h"
#endif

#include "crypt.h"
#include "conv.h"
#include "ope.h"
#include "str.h"

extern TIMER_ST EV_ExtractFileTimer;

extern int key_crypt(CRYPT_ACTION_ENUM, char *, int, char **);

// extern char   SV_ApplName[];  /* replace SV_ApplName by GEN_GetApplName() PMSTA-32895 - 140119 - FME Cluster Logger  */


FLAG_T	EV_accountingFlag;	/* DVP575 */
FLAG_T	EV_fundFlag;		/* DVP575 */

/************************************************************************
**      External entry points
**
** DBA_CmpDynSt		        Compare two dbadyn structures.
** DBA_InvalidLogicalList()     Compare two natures and give invalid logical attributes list
** DBA_FillCriterTab()          Construct criteria attributes list for an entity
** DBA_FillFkStruct()           Construct foreign key attributes list
** DBA_FillPermValTab()         Construct permitted values list for a field
**
** DBA_DictFctCheckAuth	        Setup DictFct Table according to current License Authorization.
**
**	DICT_DynStAlloc				Alloc given DBA_DYNST_ENUM.
**	DICT_DynStDatatypeSet		Set data-type for each field for given DBA_DYNST_ENUM.
**	DICT_GetAttribInfo			Get information on attribute.
**
** DBA_GetAllDictAttById()
** DBA_GetAllFunctionResultById Get All Function Result From Domain
** DBA_GetAttribFieldIdx()      Get attr fld idx and entity depending on criteria
** DBA_GetAttributeBySqlName()  Return ptr to attr depending on entity + sql name
** DBA_GetBusiIndex()           Return prog_n for unique visual key  (or -1)
** DBA_GetBusinessAttrib()      Return business attributes for given entity
** DBA_GetCustFldNbr()          Return customer field number for given entity
** DBA_GetPrecompFldNbr()       Return precomputed field number for given entity
** DBA_GetDictAttribCalcEn()    Return calculated enum for given attribute
** DBA_GetDictAttribIdxByDictId	Return the attribute index depending on received attribute dict id.
** DBA_GetDictAttribSqlName()   Return sqlname for the attribute
** DBA_GetDictAttribSt()        Return the asked attribute
** DBA_GetDictAttribStByShortIdx()	Return the attribute depending on short idx
** DBA_GetDictAttribShortIdxByIdx	Return index in S_ from given index in A_
** DBA_GetDictBusinessKey()     Return business key (sqlname or code or name) f
** DBA_GetDataTypeSQLNameC()    Return SQLNameC for a given DATATYPE_ENU�
**
** DBA_GetDictEntitiesList      Return a entity list according to given list type
** DBA_GetDictEntityInfo()      Return information on given entity
** DBA_GetDictEntityNat()       Get for an entity, it's possible nature
** DBA_GetDictEntitySqlName()   Get entity sql name
** DBA_GetDictEntitySt          Get the entitySt
**
** DBA_GetDictFctAdmAuth	Get administration authorization for given entity.
** DBA_GetDictFctInfo		Return info on given function.
** DBA_GetDictFctByProcName		Return info on given function.
** DBA_GetDictFctList		Return a function list according to list type
**
** DBA_GetDictId()              Return the entity id depending on object enum
** DBA_GetDictLangInfo()        Get languages list
** DBA_GetDictLangStruct()      Fill language dynamic structure for given language
** DBA_GetDictTechKey()         Return technical key for received entity
** DBA_GetEntityBySqlName()     Return ptr to entity depending on sql name
** DBA_GetMainFlag()            Return main flag for the given entity
** DBA_GetObjectEnum()          Return the object enum depending on entity id
** DBA_GetObjectEnumByDynSt()   Return the object enum depending on DBA_DYNST_ENUM
** DBA_GetPermValEnum
** DBA_GetPermValMax	        Return the maximum permitted value for given field
** DBA_GetPermValMaxLabelLen	Return the max permitted value label length for given field.
** DBA_GetUniPermValMaxLabelLen	Return the max permitted value unicode label length for given field.
** DBA_GetPermValName()
** DBA_GetUniPermValName()
** DBA_GetPermValNumber	        Return the number of permitted value for given field
** DBA_GetPermValPtr()          Get permitted value for an enum field
** DBA_GetPrimaryAttrib()       Return primary attributes for given entity
** DBA_GetShortBusiIndex()      Return short index for unique visual key  (or -1)
** DBA_GetTypingNat()           Return typing nature for the given entity
** DBA_GetUseScreenFlag         Return use screen flag for the received entity.
** DBA_GetVshEntityInfo()       Get label for received entity (entityRef given)
** DBA_GetShortSqlDyn()         Get short description for sql dynamic script
**
** DBA_SearchAttribSqlName()    Return ptr on attrib info depending on sql name
** DBA_SearchEntityBySqlName()  Return ptr on entity info depending on sql name
** DBA_SetDfltEntityFld()       Update default value (if exist) for each field
** DBA_SetFldDictInfo()         Update received structure (db flag and data-type)
** DBA_SetUseScreenFlag         Set use screen flag for the received entity.
** DBA_IsAnOperationObject()    return TRUE if OBJECT_ENUM is an operation
** DBA_CheckString()            return 0 if string OK , =-1 elsewhere
** DBA_CheckOpNatAuth           Manage the operation nature list in guipope.c
** DBA_CheckOpAdmAuth		Check current given operation status authorization.
**
** DBA_ConvertAllDynstToShort	Convert a A_xxx to S_xxx structure
** DBA_LoadUserDataProfInfo()   Load the data profile id of the current user.
**
** DBA_ConvUniDataTypeToDataType()  Convert an unicode data-type to an not unicode data-type
** DBA_ConvDataTypeToUniDataType()  Convert an not unicode data-type to an unicode data-type
** DBA_TruncateCodeNameToMDLength() Truncate the code and name to the length defined in the meta dict
*************************************************************************/

/************************************************************************
**      Local functions
**
** DBA_CmpAttribDispRank()	Sort attribute list by display rank
** DBA_CmpAttribLabel()		Sort attribute list by label
** DBA_CmpAttribSqlName()	Sort attribute list by sqlname
** DBA_CmpEntList()		Sort entities list by label
** DBA_CmpAttribTab()           Sort list of pointers on  attributes by entity sqlname  REF2418 - OCE - 980810
** DBA_FillAttribInfo()		Fill attribute generic information
** DBA_FillAttribTab()		Return all attributes (info on each) for an entity
** DBA_FillCriterTab() 		Construct criteria attributes list for an entity
** DBA_InitAdmArgFromMeta()     Init Adm_Arg structure with identifier (id and entity_dict_id)
** DBA_CheckOpPermVal		Construct step by step permValTab.
**
*************************************************************************/

/*************
** Macros for attribute table (copied SV_DictAttribTab part)
** e = OBJECT_ENUM
** f = field number
**************/
#define DICTATTR_BUSKFLG(a)          (a->busKeyFlg)
#define	DICTATTR_CALC(a)             (a->calcEn)
#define	DICTATTR_CUSTFLG(a)          (a->custFlg)
#define DICTATTR_DATATYPE(a)         (a->dataTpProgN)
#define DICTATTR_DEFVAL(a)           (a->dfltVal)
#define DICTATTR_EDITEN(a)           (a->editionEn) /* DVP039 - RAK - 960508 */
#define DICTATTR_SUBTYPEMASK(a)      (a->subTypeMask)           /*  editionMask is replaced by subTypeMask      HFI-PMSTA-38117-200202  */
#define DICTATTR_EDITIONMASK(a)      (a->editionMask)           /*  editionEn could now be managed by nature    HFI-PMSTA-38117-200202  */
#define DICTATTR_LABEL(a)            (a->GET_daLabel())
#define DICTATTR_UNILABEL(a)         (a->GET_daUniLabel())
#define	DICTATTR_LOGICFLG(a)         (a->logicalFlg)
#define	DICTATTR_MANDAFLG(a)         (a->mandatoryFlg)
#define	DICTATTR_PARATTRDICTID(a)    (a->parAttrDictId)
#define	DICTATTR_PARATTRENTDICTID(a) (a->parAttrEntDictId)
#define	DICTATTR_PARATTRPROGN(a)     (a->parAttrProgN)
#define	DICTATTR_PERMVALNBR(a)       (a->permVal.size())
#define	DICTATTR_PRIMAFLG(a)         (a->primFlg)
#define DICTATTR_PROGN(a)            (a->progN)
#define DICTATTR_PROGPKN(a)          (a->progPkN)
#define DICTATTR_QUICKSEARCH(a)      (a->qSearchMask)
#define DICTATTR_RANK(a)             (a->dispRank)
#define DICTATTR_REFENTDICTID(a)     (a->refEntDictId)
#define DICTATTR_ENTDICTID(a)        (a->entDictId)
#define DICTATTR_SEARCH(a)           (a->searchMask)
#define DICTATTR_SHORTIDX(a)         (a->shortIdx)
#define DICTATTR_ISNULLSHORTIDX(a)   (a->isNullShortIdx) /* REF8844 - LJE - 030305 */
#define DICTATTR_SQLNAME(a)          (a->sqlName)
#define DICTATTR_DICTID(a)           (a->attrDictId)
#define DICTATTR_WGTEN(a)            (a->widgetEn)           /* MRA - 000119 - REF4115 */
#define DICTATTR_DIMINDEX(a)         (a->iDimIndex)          /*  FIH-REF11457-051005 */
#define DICTATTR_OBJINDEX(a)         (a->iObjIndex)          /*  FIH-REF11457-051005 */
#define DICTATTR_DEFLISTOBJECT(a)    (a->enDefListObject)    /*  FIH-REF11457-051005 */

/*************
** Macros for criteria table SV_DictCriterTab
** e = OBJECT_ENUM
** f = criteria number
**************/
#define DICTCRIT_ATTRPROGN(c)    (c->attrPtr->progN)
#define	DICTCRIT_BUSKFLG(c)      (c->attrPtr->busKeyFlg)
#define DICTCRIT_DATATYPE(c)     (c->attrPtr->dataTpProgN)
#define DICTCRIT_LABEL(c)        (c->GET_dcLabel())
#define DICTCRIT_UNILABEL(c)     (c->GET_dcUniLabel())
#define	DICTCRIT_PRIMAFLG(c)     (c->attrPtr->primFlg)
#define DICTCRIT_PROGPKN(c)      (c->attrPtr->progPkN)
#define DICTCRIT_DICTID(c)       (c->attrPtr->entDictId)
#define DICTCRIT_PROGN(c)        (c->progN)


/*************
** Macros for entity table SV_DictEntityTab
** e = OBJECT_ENUM
**************/
#define DICTENT_ATTRIBNBR(e)    (e->attrNbr)
#define DICTENT_CRITERNBR(e)    (static_cast<int>(e->criterMap.size()))
#define DICTENT_CUSTNBR(e)      (e->custNbr)
#define DICTENT_PRECOMPNBR(e)   (e->precompNbr)
#define DICTENT_DICTID(e)       (e->entDictId)
#define DICTENT_ENTITYFLG(e)    (e->entDictIdFlg)
#define DICTENT_LISTFLG(e)      (e->listFlg)
#define DICTENT_MAINFLG(e)      (e->mainFlg)
#define DICTENT_PRIMKNBR(e)     (e->primKeyNbr)
#define DICTENT_UNIQUEKNBR(e)   ((e->primKeyNbr!=0)?e->primKeyNbr:e->bkAttrNbr)         /*  HFI-PMSTA-21799-151115  */
#define DICTENT_UNIQUEATTRTAB(e) ((e->primKeyNbr!=0)?e->primKeyTab:e->bkAttr)           /*  HFI-PMSTA-21799-151115  */
#define DICTENT_QUICKSEARCH(e)  (e->qSearchFlg)
#define DICTENT_MDSQLNAME(e)    (e->mdSqlName)
#define DICTENT_DBSQLNAME(e)    (e->dbSqlName)
#define DICTENT_UDSQLNAME(e)    (e->udSqlName)
#define DICTENT_SYNONFLG(e)     (e->synonFlg)
#define DICTENT_TYPINGNAT(e)    (e->tpNatEn)
#define DICTENT_VISKNBR(e)      (e->visKeyNbr)
#define DICTENT_VISKIDX(e)      (e->visUnKeyIdx)
#define DICTENT_VALIDENT(e)     (e->validEntFlg)
#define DICTENT_VIRTUALFLG(e)   (e->virtualEntFlg)
#define DICTENT_COPYNATURE(e)   (e->copyRightEn)
#define DICTENT_ACTIVEFLAG(e)   (e->activeAuthEn == FeatureAuth_Enable ? TRUE : FALSE)
#define DICTENT_NBLINKEDDIMOBJ(e) (e->iNbLinkedDimObj)
#define DICTENT_LOGICALFLG(e)   (e->logicalFlg)
#define DICTENT_PARINDEX(e)     (e->isNullParIndex?-1:e->parIndex) /* PMSTA-13109 - LJE - 111115 */
#define DICTENT_NATINDEX(e)     (e->isNullNatIndex?-1:e->natIndex) /* PMSTA-13109 - LJE - 111115 */

/*************
** Macros for datatype table SV_DictDataTpTab
** d = DATATYPE_ENUM
**************/
#define	DICTDATATP_DICTID(d)   (d->dictId)
#define	DICTDATATP_LABEL(d)    (d->label)
#define	DICTDATATP_UNILABEL(d) (d->uniLabel) /* REF9303 - LJE - 030912 */
#define	DICTDATATP_SQLNAME(d)  (d->sqlName)
#define	DICTDATATP_PROGN(d)    (d->progN)

/*************
** Macros for widget_e - DictAttrib_WgtTypeDateTimeStampWithMS
** DPT- PMSTA-43901 - 02032021
**************/

typedef struct {
    OBJECT_ENUM *objectPtr;
    char        sepFlag;
} DBA_ENTSEL_ST;


static DBA_ENTSEL_ST SV_FmtEntSel[] = {     /* will be sorted by label */
/*       object,          sepFlag  */
     {&Curr,           FALSE},
     {&Geo,            FALSE},
     {&Sect,           FALSE},
     {&Rating,         FALSE},
     {&Tp,             FALSE},
     {&BalPosTp,       FALSE},
     {&Mgr,            FALSE},
     {&Ptf,            FALSE},
     {&Instr,          FALSE},
     {&Third,          FALSE},
     {&EPos,           FALSE},
     {&EOp,            FALSE},
     {&Domain,         FALSE},
     {&PtfSynth,       FALSE},
     {&EStratLnk,      FALSE},
     {&EStratElt,      FALSE},
     /* {StratEltDetail, FALSE}, */ /* DVP095 - RAK - 960606 */
     {&InstrFlow,      FALSE},
     /* --------------------------- */
     /* BEGIN DVP095 - RAK - 960606 */
     {&ApplUser,      FALSE},
     {&ApplRule,      FALSE},
     {&Depo,          FALSE},
     {&Grid,          FALSE},
     {&List,          FALSE},
     /* END DVP095 - RAK - 960606 */
     /* ------------------------- */
     {&InstrPrice,    FALSE}
};
#define FMT_ENTSEL_NBR 23

/* ------------------------------------------- */
/* DVP010 : New menu organisation (RAK 960314) */
static DBA_ENTSEL_ST SV_SecurityEntSel[] = {
/*      object,         sepFlag  */
    {&ApplUser,       FALSE},
    {&DictUser,       FALSE},
    {&ClientConnect,  FALSE},
    {&ServConnect,    FALSE},
    {&LoginHist,      FALSE},
    {&ApplParam,      FALSE},
    {&DictEntity,     FALSE},
    {&DictFct,        FALSE},
    {&DictFctAttrib,  FALSE},    /* PMSTA12344 - DDV - 120120 */
    {&DictLang,       FALSE},    /* RAK - 970606 - DVP496    */
    {&DictDatabase,   FALSE},    /* PMSTA-13109 - LJE - 111109 */
    {&XdEntity,       FALSE},    /* PMSTA-13109 - LJE - 111109 */
    {&ApplChannel,     TRUE},    /* PMSTA-22551 - EFE - 20160323 */
    {&ApplSession,    FALSE},    /* PMSTA-22551 - EFE - 20160524 */
    {&ApplSessionHisto,TRUE},    /* PMSTA-22551 - EFE - 20160524 */
    {&EntityComment,  FALSE},    /*  FPL-PMSTA10558-110610   */
    {&ApplParamComment,TRUE},    /*  FPL-PMSTA10558-110610   */
    {&DataProf,		FALSE},			/* MRA - 010212 - REF5562 */
    {&DataSecuProf, FALSE},
	{&ApplChannelProf,   FALSE}, /* PMSTA-22551 - EFE - 20160323 */
    {&FctSecuProf,  FALSE},
    {&FmtProf,      FALSE},
    {&ReportProf,   FALSE},
    {&ScreenProf,   FALSE},
    {&PrinterProf,  FALSE},
    {&OptiProf,     FALSE},    /* REF11767 - LJE - 060419 */
    {&AccProfile,   FALSE},      /*  FPL-PMSTA00488-061116   */
    {&ExtServiceProf,   TRUE},   /*  HFI-PMSTA-22496-160502  */
    {&SearchCrit,   FALSE},
    {&SearchProf,   FALSE},
    {&Fmt,          FALSE},
    {&Report,       FALSE},
    {&ApplMsg,      FALSE},
    {&TabCnt,       FALSE},
    {&Printer,      FALSE},
    {&DictScreen,   FALSE},
    {&FctResult,	   FALSE},
    {&ConstrTemplate,FALSE},	/* MDE - REF7289 - 2002 02 14 */
    {&CaseMsgTemplate, FALSE}   /*  FPL-081110-PMSTA07121   */
};
#define SECURITY_ENTSEL_NBR 39


static DBA_ENTSEL_ST SV_FctProfStratAdmEntSel[] = {
/*      object,		sepFlag  */
    {&Strat,		FALSE},
    {&StratElt,	FALSE},
    {&StratLnk,	FALSE},
    {&StratHist,	FALSE}
};
#define FCTPROFSTRATADM_ENTSEL_NBR 4

/*  FIH-REF6082-020118  */
static DBA_ENTSEL_ST SV_FctProfConstrAdmEntSel[] = {
/*      object,		sepFlag  */
    {&ModelConstr,		FALSE},
    {&ModelConstrElt,    FALSE},
    {&TradConstr,        FALSE}
};
#define FCTPROFCONSTRADM_ENTSEL_NBR 3       /* MRA - 040318 - REF10071 change 2 to 3 */

/* ROI - 970408 - DVP413 */
static DBA_ENTSEL_ST SV_ValRuleHistEntSel[] = {
/*      object,		sepFlag  */
    {&Curr,		FALSE},
    {&Instr,		FALSE},
    {&EPos,		FALSE}
};
#define VALRULEHIST_ENTSEL_NBR 3

#define ENT_BLOCK_ALLOC     20   /* for step by step allocation */
#define SQLNAME_T_LEN	    50	 /* varchar(50)	*/			/* REF4204 */

typedef char           SQLNAME_T[SQLNAME_T_LEN+1];   /* varchar */	/* REF4204 */

typedef struct fk_denom_elm *FK_DENOM_ELM_STP;				/* REF4204 */
typedef struct fk_denom_elm{
    char				*denom;
    FK_DENOM_ELM_STP	fkDenomElmNext;
} FK_DENOM_ELM_ST;


/*********************************
***  DEV5502 - CSA - 21122000  ***
*********************************/
typedef struct
{
    struct  DICT_LABEL_LANG_ST  *dictLanguagesTab;
    int                         dictLanguagesLoaded;
}   DICT_LABEL_ENTRYPOINT_ST, *DICT_LABEL_ENTRYPOINT_STP;
STATIC  DICT_LABEL_ENTRYPOINT_STP   dictLabelEntryPoint = NULL;



/************************************************************************
**      Functions
*************************************************************************/
STATIC int DBA_CmpAttribDispRank(ALL_ATTRIB_INFO_STP, ALL_ATTRIB_INFO_STP),
       DBA_CmpAttribLabel(ALL_ATTRIB_INFO_STP, ALL_ATTRIB_INFO_STP),
       DBA_CmpAttribSqlName(ALL_ATTRIB_INFO_STP, ALL_ATTRIB_INFO_STP);
/*	   DBA_CmpEntList(VSH_ENTITY_INFO_STP, VSH_ENTITY_INFO_STP),        HFI-PMSTA-12110-110606  No more static def in fmtlib01.h    */

STATIC FLAG_T	DBA_ValidAttrib(META_TYPE_ENUM, DICT_ENTITY_STP, DICT_ATTRIB_STP, FLAG_T, ID_T);    /*  FPL-PMSTA08801-091008 longID from long    */

STATIC RET_CODE DBA_BuildStr(FK_DENOM_ELM_STP, int, char *, FLAG_T, char *, const char *,FLAG_T,std::string &, FLAG_T);			/* REF4204 */   /*  HFI-PMSTA-41842-200916  Add flagJSonSyntax  */
STATIC RET_CODE DBA_FreeTree(FK_DENOM_ELM_STP, int);						/* REF4204 */
STATIC RET_CODE DBA_ModifSqlName(char *, char *,FLAG_T);			        /* REF4204 */   /*  HFI-PMSTA-41842-200916  Add flagJSonSyntax/flagFullyQualifiedName  */
STATIC RET_CODE DBA_SuppValueSpace(char *, SQLNAME_T);						/* REF4204 */
STATIC RET_CODE DICT_CheckLanguage(DICT_T, DbiConnectionHelper &);      /*  DEV5502 - CSA - 29012001    */
STATIC RET_CODE DICT_SearchLabel(DICT_T, DICT_T, DICT_T, const char **); /*  DEV5502 - CSA - 29012001    */
STATIC RET_CODE DICT_SearchUniLabel(DICT_T, DICT_T, DICT_T, const UChar **); /* REF9303 - LJE - 030912 */
STATIC RET_CODE DICT_LoadLanguage(DICT_T, DbiConnectionHelper &);       /*  DEV5502 - CSA - 29012001    */
STATIC int      FindLanguageIndex(DICT_T);                              /*  DEV5502 - CSA - 29012001    */
STATIC int      FindEntityIndex(int, DICT_T);                           /*  DEV5502 - CSA - 29012001    */
STATIC RET_CODE FindLabel(int, int, DICT_T, const char **);                   /*  DEV5502 - CSA - 29012001    */
STATIC RET_CODE FindUniLabel(int, int, DICT_T, const UChar **);               /* REF9303 - LJE - 030912 */
STATIC RET_CODE DICT_LoadLanguageInDB(DICT_T, DBA_DYNFLD_STP **, int *, DbiConnectionHelper &);/*  DEV5502 - CSA - 29012001    */
STATIC RET_CODE DICT_AddLanguage(DICT_T, DBA_DYNFLD_STP *, int);        /*  DEV5502 - CSA - 29012001    */
STATIC int      DICT_GetEntitiesNumber(DBA_DYNFLD_STP *, int);          /*  DEV5502 - CSA - 29012001    */
STATIC int      DICT_GetObjectsNumber(DICT_T, DBA_DYNFLD_STP *, int);   /*  DEV5502 - CSA - 29012001    */

STATIC RET_CODE DBA_FillAttribTab(META_TYPE_ENUM, ENTITY_INFO_STP, DICT_T),
                DBA_FillAttribInfo(ENTITY_INFO_STP, int, ALL_ATTRIB_INFO_STP, DICT_T);

FLAG_T  DBA_GetGuiInterfaceFlag (OBJECT_ENUM);  /*  FPL-REF6149-050530  */

/************************************************************************
**
**  Function    :   DBA_GetEntityCodeIndex
**
**  Description :   Return code index in a all structure
**
**  Arguments   :   OBJECT_ENUM enObject
**
**  Return      :   int iIndex  Index of the attribute code in a all structure
**                              -1 if code does not exist
**
**  Modif.      :   HFI-PMSTA-13647-120207
**
*************************************************************************/
int DBA_GetEntityCodeIndex (OBJECT_ENUM enObject)
{
    DICT_ATTRIB_STP     pdictattr;
    int                 iCodeIndex;

    if (DBA_GetGuiMainEntFlag(enObject) == TRUE)
        iCodeIndex = 1 ;
    else
        iCodeIndex = -1 ;

    switch (GET_OBJECT_CST(enObject))
    {
        case ApplParamCst :
            iCodeIndex = A_ApplParam_ParamName ;
            break;
        case ExtOrderCst :
            iCodeIndex = ExtOp_Cd ;
            break;
        case DictScreenCst:
            iCodeIndex = A_DictScreen_Name;
            break;
        case EventSchedCst :
        case ModelConstrCst :
        case ExecutionEntCst :
        case GlExecFeeEntCst :
        case PerfAnalysisParamCst :
        case StratLnkCst :
        case SubscriptionCodifCompoCst :
        case EntityCommentCst :
        case ApplParamCommentCst :
            iCodeIndex = -1 ;
            break;
    }
    if ((iCodeIndex != -1) &&
        (((pdictattr = (DICT_ATTRIB_STP) DBA_GetDictAttribSt(enObject,iCodeIndex)) == NULL) ||
         ((GET_CTYPE(pdictattr->dataTpProgN) != CharPtrCType) &&
          (GET_CTYPE(pdictattr->dataTpProgN) != TextPtrCType))))
        iCodeIndex = -1;

    return iCodeIndex;
}


/************************************************************************
**  Function    : DBA_GetDynMaxDbLen()
**
**  Description :
**
**                      !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
**                      IF you add something here, please add it too in
**                      DBA_SetDynDispAndMaxLength and DBA_GetDynDefDispLen
**                      !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
**
**  Arguments   :
**
**
**
**  Return      :
**
**  Creation    :
**
**  Last modif. : PMSTA-30941 - 200418 - PMO : Fix gcc 8 compilations warnings related to the stabilization
**
*************************************************************************/
STATIC int  DBA_GetDynMaxDbLen(OBJECT_ENUM        entityRef
                              , FIELD_IDX_T       fld
                              , OBJECT_ENUM       parEntityRef
)
{
    DICT_ENTITY_STP  dictEntityStp = DBA_GetDictEntitySt(entityRef);

    if (dictEntityStp == nullptr)
    {
        return 0;
    }

    DICT_ATTRIB_STP dictAttribStp = dictEntityStp->attr[fld];
    if (dictAttribStp == nullptr)
    {
        return 0;
    }

    switch (GET_OBJECT_CST(entityRef))
    {
        case SynonCst:
            if (fld == A_Synon_Cd)
            {
                DICT_ATTRIB_STP dictAttrib = DBA_GetAttributeBySqlName(parEntityRef, "code");       /* PMSTA-30941 - 200418 - PMO */
                if (dictAttrib != NULL)
                {
                    return dictAttrib->maxDbLenN;
                }
                return 0;
            }
    }

    /*  return size of dataType if nothing found in meta-dictionary.    */
    /*  We don't set value with default size of datatype for id,        */
    /*  because we take size of fk fields. Exception is made if user    */
    /*  has set value on id field to force size                         */
    if ((dictAttribStp->maxDbLenN == 0) &&
        (DICTATTR_DATATYPE(dictAttribStp) != IdType) &&
        (DICTATTR_DATATYPE(dictAttribStp) != EnumType))
    {
        /*  special case for datetime field and other having a widgetEn > 0 */
        if ((dictAttribStp->widgetEn == DictAttrib_WgtTypeDateTimeInGui) ||
            (dictAttribStp->widgetEn == DictAttrib_WgtTypeDateTimeBothGuiImp) ||
            (dictAttribStp->widgetEn == DictAttrib_WgtTypeDateTimeStampWithMS))
            return 0 ;

        /*  normal case */
        return GET_GUIFMTLEN(DICTATTR_DATATYPE(dictAttribStp));
    }
    return dictAttribStp->maxDbLenN;
}

/************************************************************************
**  Function    : DBA_GetDynDefDispLen()
**
**  Description :
**
**                      !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
**                      IF you add something here, please add it too in
**                      DBA_GetDynMaxDbLen and DBA_SetDynDispAndMaxLength
**                      !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
**
**  Arguments   :
**
**
**
**  Return      :
**
**  Creation    :
**
*************************************************************************/
STATIC int  DBA_GetDynDefDispLen ( OBJECT_ENUM          entityRef
                                 , INT_T                fld
                                 , OBJECT_ENUM          parEntityRef
                                 )
{
   DICT_ENTITY_STP     dictEntityStp ;

    if ((dictEntityStp = DBA_GetDictEntitySt(entityRef)) == NULL)
        return 0 ;

    DICT_ATTRIB_STP dictAttribStp = dictEntityStp->attr[fld];
    if (dictAttribStp == nullptr)
    {
        return 0;
    }

    if (dictEntityStp->attr[fld]->defaultDisplayLenN < 0)
    {
        switch (GET_OBJECT_CST(entityRef))
        {
            case SynonCst  :
                if (fld == A_Synon_Cd)
                {
                    DICT_ATTRIB_STP dictAttrib = DBA_GetAttributeBySqlName(parEntityRef, "code");
                    if (dictAttrib != NULL)
                        return dictAttrib->defaultDisplayLenN ;
                    else
                        return 0 ;
                }
        }
    }
    /*  return size of dataType if nothing found in metadictionnary */
    /*  We don't set value with default size of datatype for id,        */
    /*  because we take size of fk fields. Exception is made if user    */
    /*  has set value on id field to force size                         */
    if ((dictEntityStp->attr[fld]->defaultDisplayLenN == 0) &&
        (DICTATTR_DATATYPE(dictAttribStp) != IdType) &&
        (DICTATTR_DATATYPE(dictAttribStp) != EnumType))
    {
        /*  special case for datetime field and other having a widgetEn > 0 */
        if ((dictEntityStp->attr[fld]->widgetEn == DictAttrib_WgtTypeDateTimeInGui) ||
            (dictEntityStp->attr[fld]->widgetEn == DictAttrib_WgtTypeDateTimeBothGuiImp))
            return 0 ;

        /*  normal case */
        return GET_GUIFMTLEN(DICTATTR_DATATYPE(dictAttribStp));
    }
    return dictEntityStp->attr[fld]->defaultDisplayLenN;
}

/************************************************************************
**  Function    :   DBA_GetDictNatEntitiesList
**
**  Description :   Returns the list of all entity of a particular nature.
**
**  Arguments   :   DBA_ENTITY_NAT_ENUM enEntityNat     : entity nature
**                  DICT_ENTITY_STP     *pdictenttabNat : table of selected dict_entity
**                  int                 *piNbNatEnt     : size of the entity table
**                  bool                bReturnLogical  : true  include logical entities
**                                                        false exclude logical entities
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   HFI-PMSTA-33431-191027  Manage access to function and entites in master environment
**  Modif       :   HFI-PMSTA-45585-210624  Logical entities must not be an entry in administration GUI menu
**
*************************************************************************/
RET_CODE    DBA_GetDictNatEntitiesList (DBA_ENTITY_NAT_ENUM enEntityNat,
                                        DICT_ENTITY_STP     **pdictenttabNat,
                                        int                 *piNbNatEnt,
                                        bool                bReturnLogical)
{
    DICT_ENTITY_STP *pdictenttab;
    int             iNbEntity = 0;
    OBJECT_ENUM     objEn;
    int             k;
    FLAG_T          showAllUdeInGUIFlg = FALSE;
    char            *pszEnv;
    RET_CODE        retCode= RET_SUCCEED;

    if ((pszEnv = SYS_GetEnv("AAASHOWALLUDEINGUI")) != NULL)
    {
        showAllUdeInGUIFlg = (FLAG_T)atoi(pszEnv);
    }

    for (objEn = 0; objEn < LASTOBJECT; objEn++)
    {
        DICT_ENTITY_STP     locDictEntityStp = DBA_GetDictEntitySt(objEn);
        if ((locDictEntityStp != NULL) &&
            (locDictEntityStp->mainFlg == TRUE) &&
            ((showAllUdeInGUIFlg == TRUE) || (GET_BIT(locDictEntityStp->automaticMask, Automatic_ShowInGUIMenu) == 1)) &&   /* PMSTA-17813 - LJE - 140319 */
            (locDictEntityStp->entNatEn == enEntityNat) &&
            ((bReturnLogical == true) ||
             ((bReturnLogical == false) && (locDictEntityStp->logicalFlg == FALSE))))
        {
            iNbEntity++;
        }
    }

    if (iNbEntity > 0)
    {
        if ((pdictenttab = (DICT_ENTITY_STP*) CALLOC(iNbEntity, sizeof(DICT_ENTITY_STP))) == NULL)
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        else
        {
            int entSelPos=0;
            for (objEn = 0, k = 0; objEn < LASTOBJECT && entSelPos < iNbEntity; objEn++)
            {
                DICT_ENTITY_STP     locDictEntityStp = DBA_GetDictEntitySt(objEn);
                if ((locDictEntityStp != NULL) &&
                    (locDictEntityStp->mainFlg == TRUE) &&
                    ((showAllUdeInGUIFlg == TRUE) || (GET_BIT(locDictEntityStp->automaticMask, Automatic_ShowInGUIMenu) == 1)) &&   /* PMSTA-17813 - LJE - 140319 */
                    (locDictEntityStp->entNatEn == enEntityNat) &&
                    ((bReturnLogical == true) ||
                     ((bReturnLogical == false) && (locDictEntityStp->logicalFlg == FALSE))))
                {
                    pdictenttab[k++] = locDictEntityStp;
                }
            }
        }
         if (pdictenttabNat != NULL)
            *pdictenttabNat = pdictenttab;
        if (piNbNatEnt != NULL)
            *piNbNatEnt = k;
    }
    return retCode;
}


/************************************************************************
**  Function             : DBA_GetDictEntityUniLabel()
**
**  Description          : Get entity sql name
**
**  Arguments            : object 	: OBJECT_ENUM member
**
**  Return               :
**  Last modif.          : PMSTA-34279 - 211218 - PMO : Regression - Drop down values are not properly displayed in Forex Order screen
**
*************************************************************************/
STATIC void DBA_SetDictEntityUniLabel(UChar *uniLabel, OBJECT_ENUM object, FLAG_T sqlnameFlg)
{
    DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(object);

    if (dictEntityStp)
    {
        if (sqlnameFlg)
        {
            ICU4AAA_ConvertFromASCII(dictEntityStp->mdSqlName, -1, uniLabel, GET_MAXCHARLEN(NameType), NULL);   /* PMSTA-33077 - DLA - 181003 */
        }
        else
        {
            u_strcpy(uniLabel, dictEntityStp->uniLabelStr.getTerminatedBuffer());                               /* PMSTA-34279 - 211218 - PMO */
        }
    }
}


/************************************************************************
**  Function    :   DBA_FillVshEntityInfo
**
**  Description :   Fill VSH_ENTITY_INFO_STP based on the given entity
**
**  Arguments   :   VSH_ENTITY_INFO_STP pentinfo    structure to fill
**                  OBJECT_ENUM         enObjectEnt given entity
**                  FLAG_T              flagSqlname Fill name (FALSE) or sqlName (TRUE).
**
**  return          void
**
**  Creation    :   PMSTA-33431-191027  Simplify DBA_GetDictEntitiesList
**
*************************************************************************/
void    DBA_FillVshEntityInfo ( VSH_ENTITY_INFO_STP pentinfo,
                                FLAG_T              flagSqlname,
                                OBJECT_ENUM         enObjectEnt)
{
    pentinfo->entityRef = enObjectEnt;
    DBA_GetDictId(enObjectEnt, &pentinfo->id);
    strcpy(pentinfo->sqlName, DBA_GetDictEntitySqlName(enObjectEnt));
    strcpy(pentinfo->label, DBA_GetDictEntityLabel(enObjectEnt,flagSqlname));
    DBA_SetDictEntityUniLabel(pentinfo->uniLabel,enObjectEnt,flagSqlname);
}

/************************************************************************
**  Function    : DBA_GetDictEntitiesList()
**
**  Description : According to the received list type,
**                return a entity list with object enum, label.
**
**  Arguments   : entSelTp    list type
**                entInfoPtr  structure which will be filled.
**                sqlNameFlg  Fill name or sqlName.
**                output : entityNb (entity number)
**                         entityTab is allocated and filled
**
**  Warning !!  : parent function must deallocate the pointer
**
**  Return      : RET_SUCCEED or error code
**
**  Modif       :   DVP010 - RAK - 960314
**              :   DVP033 - RAK - 960509
**              :   DVP095 - RAK - 960610
**  Modif.      :   ROI - 961118 - DVP253
**  Modif.      :   ROI - 961121 - DVP260
**  Modif.      :   ROI - 970408 - DVP413
**  Modif.      :   ROI - 970409 - DVP424
**  Modif.      :   ROI - 970718 - DVP542
**  Modif.      :   ROI - 970916 - DVP587
**  Modif.      :   ROI - 971015 - REF204
**  Modif.      :   FIH - 971201 - REF925
**  Modif.      :   FIH - 980205 - REF893.2
**  Modif.      :   FIH - 980323 - REF1483
**  Modif.      :   FIH - 980414 - REF1611
**	Modif.		:	MDE - 000217 - REF4204
**	Modif.		:	ROI - 000413 - REF4497
**  Modif.      :   MRA - 001023 - REFCatherine
**  Modif.      :   FPL-081210-PMSTA07121 Add refEntity
**                  PMSTA-34279 - 211218 - PMO : Regression - Drop down values are not properly displayed in Forex Order screen
**                  HFI-PMSTA-33431-191027  Use of DBA_GetDictNatEntitiesList to centralize code.
**
*************************************************************************/
RET_CODE DBA_GetDictEntitiesList(ENT_SEL_TP_ENUM   entSelTp,
                                 ENTITIES_INFO_STP entInfoPtr,
                                 FLAG_T            sqlnameFlg,
                                 OBJECT_ENUM       refEntity)
{
    OBJECT_ENUM     entity, refEnt, opObject;
    DBA_DYNST_ENUM  opDynst;
    DBA_ENTSEL_ST   *crtEntSel;
    signed          crtOpNat;
    int             j, i, allocSz;
    char            copyFlg, fnd;
    RET_CODE        ret;
    OPNAT_ENUM      operNat;

    entInfoPtr->entityNb = 0;
    entInfoPtr->entityTab = NULL;

    /* 2 hardcode entities :                                    */
    /* Instrument and third party for rating sector attribution */
    /* Instrument and currency for scenario                     */
    if (entSelTp == ScenaEntSel)
    {
        entInfoPtr->entityNb = 2;
        i = 0;

        if ((entInfoPtr->entityTab = (VSH_ENTITY_INFO_STP)
            CALLOC(entInfoPtr->entityNb, sizeof(VSH_ENTITY_INFO_ST))) == NULL)
        {
            entInfoPtr->entityNb = 0;
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        /* Instrument for three cases */
        DBA_FillVshEntityInfo (&entInfoPtr->entityTab[i++],sqlnameFlg,Instr);
        DBA_FillVshEntityInfo (&entInfoPtr->entityTab[i++],sqlnameFlg,Curr);
        return(RET_SUCCEED);
    }

    /* 2 hardcode entities :                                    */
    /*  Portfolio and instrument for strategy                   */
    if (entSelTp == StratEntSel)
    {
        entInfoPtr->entityNb = 3;
        i = 0;
        if ((entInfoPtr->entityTab = (VSH_ENTITY_INFO_STP)
        CALLOC(entInfoPtr->entityNb, sizeof(VSH_ENTITY_INFO_ST))) == NULL)
        {
            entInfoPtr->entityNb = 0;
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        DBA_FillVshEntityInfo (&entInfoPtr->entityTab[i++],sqlnameFlg,Ptf);
        DBA_FillVshEntityInfo (&entInfoPtr->entityTab[i++],sqlnameFlg,Instr);
        DBA_FillVshEntityInfo (&entInfoPtr->entityTab[i++],sqlnameFlg,Strat);
        return(RET_SUCCEED);
    }

    /* MRA - 031030 - REF9589 */    /* seperate the case of StratLnkEltEntSel with StratEntSel */
    /* Portfolio and portfolio list for strategy link element   */
    if (entSelTp == StratLnkEltEntSel)
    {
        entInfoPtr->entityNb = 2;
        i = 0;
        if ((entInfoPtr->entityTab = (VSH_ENTITY_INFO_STP)
        CALLOC(entInfoPtr->entityNb, sizeof(VSH_ENTITY_INFO_ST))) == NULL)
        {
            entInfoPtr->entityNb = 0;
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }
        DBA_FillVshEntityInfo (&entInfoPtr->entityTab[i++],sqlnameFlg,Ptf);
        DBA_FillVshEntityInfo (&entInfoPtr->entityTab[i++],sqlnameFlg,List);
        return(RET_SUCCEED);
    }

    /*  FIH-REF7323-020530  */
    if (entSelTp == RightToRunActionEntSel)
    {
        entInfoPtr->entityNb = 3;           /*  FIH-REF11037-050314 Add ExtOp   */
        i = 0;
        if ((entInfoPtr->entityTab = (VSH_ENTITY_INFO_STP) CALLOC(entInfoPtr->entityNb, sizeof(VSH_ENTITY_INFO_ST))) == NULL)
        {
            entInfoPtr->entityNb = 0;
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }
        DBA_FillVshEntityInfo (&entInfoPtr->entityTab[i++],sqlnameFlg,EOp);
        DBA_FillVshEntityInfo (&entInfoPtr->entityTab[i++],sqlnameFlg,EPos);
        DBA_FillVshEntityInfo (&entInfoPtr->entityTab[i++],sqlnameFlg,EStratElt);
        return(RET_SUCCEED);
    }

    /*  FIH-REF7174-020918  */
    if (entSelTp == RightToRunExtOpFctEntSel)
    {
        entInfoPtr->entityNb = 1;
        i = 0;
        if ((entInfoPtr->entityTab = (VSH_ENTITY_INFO_STP) CALLOC(entInfoPtr->entityNb, sizeof(VSH_ENTITY_INFO_ST))) == NULL)
        {
            entInfoPtr->entityNb = 0;
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }
        DBA_FillVshEntityInfo (&entInfoPtr->entityTab[i++],sqlnameFlg,EOp);
        return(RET_SUCCEED);
    }

    /*  FIH-REF10433-040706 */
    if (entSelTp == UpdateFieldsRightEntSel)
    {
        FLAG_T  genericFlg=FALSE; /* PMSTA-22506 - DDV - 160421 - Add generic case */

        /*  FPL-081210-PMSTA07121 Number of entities    */
        switch (GET_OBJECT_CST(refEntity))
        {
            case EOpCst :
            case ExtExecutionEntCst :
            case CaseManagementCst :
                entInfoPtr->entityNb = 1 ;
                break ;
            case NullEntityCst :
                entInfoPtr->entityNb = 3 ;
                break;
            default:
                genericFlg=TRUE;
                entInfoPtr->entityNb = 1 ;
                break ;
        }
        /*entInfoPtr->entityNb = 2;         FPL-081208-PMSTA7121 manage variable nb of entities */
        i = 0;
        if ((entInfoPtr->entityTab = (VSH_ENTITY_INFO_STP) CALLOC(entInfoPtr->entityNb, sizeof(VSH_ENTITY_INFO_ST))) == NULL)
        {
            entInfoPtr->entityNb = 0;
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        /* PMSTA-22506 - DDV - 160421 - Add generic case */
        if (genericFlg == FALSE)
        {
            if ((refEntity == EOp) ||               /*  FPL-081208-PMSTA7121 Manage by entity   */
                (refEntity == NullEntity))
            {
                DBA_FillVshEntityInfo (&entInfoPtr->entityTab[i++],sqlnameFlg,EOp);
            }

            if ((refEntity == ExtExecutionEnt) ||   /*  FPL-081208-PMSTA7121 Manage by entity   */
                (refEntity == NullEntity))
            {
                DBA_FillVshEntityInfo (&entInfoPtr->entityTab[i++],sqlnameFlg,ExtExecutionEnt);
            }

            /*  FPL-081208-PMSTA7121 Manage by entity   */
            if ((refEntity == CaseManagement) ||
                (refEntity == NullEntity))
            {
                DBA_FillVshEntityInfo (&entInfoPtr->entityTab[i++],sqlnameFlg,CaseManagement);
            }
        }
        else
        {
            /* PMSTA-22506 - DDV - 160421 - Add generic case */
            DBA_FillVshEntityInfo (&entInfoPtr->entityTab[i++],sqlnameFlg,refEntity);
        }
        return(RET_SUCCEED);
    }

    /*  FIH-REF7174-020530  */
     /* PMSTA-40208 - sanand - 24092020 - For Hierarchy Grouping like Order Grouping,
     we need to set attributes for Buy and Sell Operation */
    if (entSelTp == GroupingEntSel || entSelTp == HierarchyGroupingEntSel)
    {
        entInfoPtr->entityNb = 2;
        i = 0;
        if ((entInfoPtr->entityTab = (VSH_ENTITY_INFO_STP) CALLOC(entInfoPtr->entityNb, sizeof(VSH_ENTITY_INFO_ST))) == NULL)
        {
            entInfoPtr->entityNb = 0;
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }
        DBA_FillVshEntityInfo (&entInfoPtr->entityTab[i++],sqlnameFlg,BuyOpEnt);
        DBA_FillVshEntityInfo (&entInfoPtr->entityTab[i++],sqlnameFlg,SellOpEnt);
        return(RET_SUCCEED);
    }

    /*  Unmatched entities      FIH-REF10136-040406 */
    if (entSelTp == UnmatchedEntSel)
    {
        entInfoPtr->entityNb = 2;
        i = 0;
        if ((entInfoPtr->entityTab = (VSH_ENTITY_INFO_STP) CALLOC(entInfoPtr->entityNb, sizeof(VSH_ENTITY_INFO_ST))) == NULL)
        {
            entInfoPtr->entityNb = 0;
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }
        DBA_FillVshEntityInfo (&entInfoPtr->entityTab[i++],sqlnameFlg,UnMatchedExecution);
        DBA_FillVshEntityInfo (&entInfoPtr->entityTab[i++],sqlnameFlg,UnMatchedGlExecFee);
        return(RET_SUCCEED);
    }

    /*  FIH-REF10433-040706 */
    if (entSelTp == UpdateFieldsDefEntSel)
    {
        FLAG_T    genericFlg = FALSE; /* PMSTA-22506 - DDV - 160421 - Add generic case */

        /*  FPL-081210-PMSTA07121 Number of entities    */
        switch (GET_OBJECT_CST(refEntity))
        {
#if 0 /* PMSTA-22506 - DDV - 1606002 - It was not possible to define a update field sub-function with entity egal ExtOp.
                                       To be coherent with automatic data update and to make mass data update working on ExtOp, I remopved it */
            case EOpCst :
                entInfoPtr->entityNb = (int) OpNat_OpNatNbr - 1 ;
                break ;
#endif
            case ExtExecutionEntCst :
                entInfoPtr->entityNb = 2 ;
                break ;
            case CaseManagementCst :
                entInfoPtr->entityNb = 1 ;
                break ;
            case NullEntityCst :
                entInfoPtr->entityNb = (int) OpNat_OpNatNbr - 1 + 2 + 1;
                break ;
            default:
                entInfoPtr->entityNb = 1 ;
                genericFlg = TRUE;
                break;
        }

        /*entInfoPtr->entityNb = (int) OpNat_OpNatNbr - 1 + 2 ;*/    /*  FPL-081209-PMSTA07121 manage variable entities  */
        if ((entInfoPtr->entityTab = (VSH_ENTITY_INFO_STP)
            CALLOC(entInfoPtr->entityNb, sizeof(VSH_ENTITY_INFO_ST))) == NULL)
        {
            entInfoPtr->entityNb = 0;
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        i=0 ;                                   /*  FPL-081208-PMSTA7121 */
        /* PMSTA-22506 - DDV - 160421 - Add generic case */
        if (genericFlg == FALSE)
        {
            if ((refEntity == EOp) ||               /*  FPL-081208-PMSTA7121 Manage by entity   */
                (refEntity == NullEntity))
            {
                for (i=0, crtOpNat=OpNat_Buy; crtOpNat<OpNat_OpNatNbr; crtOpNat++, i++)
                {
                    if ((ret = OPE_OperNatToDictEnum((OPNAT_ENUM) crtOpNat, &opDynst, &opObject)) != RET_SUCCEED)
                    {
                        FREE(entInfoPtr->entityTab);
                        return(ret);
                    }
                    DBA_FillVshEntityInfo (&entInfoPtr->entityTab[i],sqlnameFlg,opObject);
                }
            }

            if ((refEntity == ExtExecutionEnt) ||   /*  FPL-081208-PMSTA7121 Manage by entity   */
                (refEntity == NullEntity))
            {
                DBA_FillVshEntityInfo (&entInfoPtr->entityTab[i++],sqlnameFlg,ExecutionEnt);
                DBA_FillVshEntityInfo (&entInfoPtr->entityTab[i++],sqlnameFlg,GlExecFeeEnt);
            }

            /*  FPL-081208-PMSTA7121 Manage by entity   */
            if ((refEntity == CaseManagement) ||
                (refEntity == NullEntity))
            {
                DBA_FillVshEntityInfo (&entInfoPtr->entityTab[i++],sqlnameFlg,CaseManagement);
            }
        }
        else
        {
            /* PMSTA-22506 - DDV - 160421 - Add generic case */
            DBA_FillVshEntityInfo (&entInfoPtr->entityTab[i++],sqlnameFlg,refEntity);
        }

        return(RET_SUCCEED);
    }


    /*  List of possible created entities by function init execution    */  /*  FIH-PMSTA2553-070711    */
    if (entSelTp == ExecutionEntSel)
    {
        entInfoPtr->entityNb = 1;
        i = 0;
        if ((entInfoPtr->entityTab = (VSH_ENTITY_INFO_STP) CALLOC(entInfoPtr->entityNb, sizeof(VSH_ENTITY_INFO_ST))) == NULL)
        {
            entInfoPtr->entityNb = 0;
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }
        DBA_FillVshEntityInfo (&entInfoPtr->entityTab[i++],sqlnameFlg,ExecutionEnt);
        return(RET_SUCCEED);
    }


    /*  Format entities for fucntion init execution                     */  /*  FIH-PMSTA2553-070711    */
    if (entSelTp == InitExecutionRightEntSel)
    {
        entInfoPtr->entityNb = 2;
        i = 0;
        if ((entInfoPtr->entityTab = (VSH_ENTITY_INFO_STP) CALLOC(entInfoPtr->entityNb, sizeof(VSH_ENTITY_INFO_ST))) == NULL)
        {
            entInfoPtr->entityNb = 0;
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }
        DBA_FillVshEntityInfo (&entInfoPtr->entityTab[i++],sqlnameFlg,EOp);
        DBA_FillVshEntityInfo (&entInfoPtr->entityTab[i++],sqlnameFlg,EPos);
        return(RET_SUCCEED);
    }


    /*  FIH-REF11457-051003 */
    if (entSelTp == UpdateDataRightEntSel)
    {
        /* PMSTA-22506 - DDV - 160429 */
        if (refEntity == NullEntity)
        {
            entInfoPtr->entityNb = 2;               /*  HFI-PMSTA10685-101015   Add EOp     */
            i = 0;
            if ((entInfoPtr->entityTab = (VSH_ENTITY_INFO_STP) CALLOC(entInfoPtr->entityNb, sizeof(VSH_ENTITY_INFO_ST))) == NULL)
            {
                entInfoPtr->entityNb = 0;
                MSG_RETURN(RET_MEM_ERR_ALLOC);
            }
            DBA_FillVshEntityInfo (&entInfoPtr->entityTab[i++],sqlnameFlg,EStratElt);
            DBA_FillVshEntityInfo (&entInfoPtr->entityTab[i++],sqlnameFlg,EOp);
        }
        else
        {
            /* PMSTA-22506 - DDV - 160429 */
            entInfoPtr->entityNb = 1;
            i = 0;
            if ((entInfoPtr->entityTab = (VSH_ENTITY_INFO_STP) CALLOC(entInfoPtr->entityNb, sizeof(VSH_ENTITY_INFO_ST))) == NULL)
            {
                entInfoPtr->entityNb = 0;
                MSG_RETURN(RET_MEM_ERR_ALLOC);
            }
            DBA_FillVshEntityInfo (&entInfoPtr->entityTab[i++],sqlnameFlg,refEntity);
        }
        return(RET_SUCCEED);
    }

    /*  FIH-REF11457-051003 */
    if (entSelTp == UpdateDataDefEntSel)
    {
        /* PMSTA-22506 - DDV - 160429 */
        if (refEntity == NullEntity)
        {
            entInfoPtr->entityNb = 3;               /*  HFI-PMSTA10685-101015   Add Buy and Sell    */
            i = 0;
            if ((entInfoPtr->entityTab = (VSH_ENTITY_INFO_STP) CALLOC(entInfoPtr->entityNb, sizeof(VSH_ENTITY_INFO_ST))) == NULL)
            {
                entInfoPtr->entityNb = 0;
                MSG_RETURN(RET_MEM_ERR_ALLOC);
            }
            DBA_FillVshEntityInfo (&entInfoPtr->entityTab[i++],sqlnameFlg,EStratElt);
            DBA_FillVshEntityInfo (&entInfoPtr->entityTab[i++],sqlnameFlg,BuyOpEnt);
            DBA_FillVshEntityInfo (&entInfoPtr->entityTab[i++],sqlnameFlg,SellOpEnt);
        }
        else
        {
            /* PMSTA-22506 - DDV - 160429 */
            entInfoPtr->entityNb = 1;
            i = 0;
            if ((entInfoPtr->entityTab = (VSH_ENTITY_INFO_STP) CALLOC(entInfoPtr->entityNb, sizeof(VSH_ENTITY_INFO_ST))) == NULL)
            {
                entInfoPtr->entityNb = 0;
                MSG_RETURN(RET_MEM_ERR_ALLOC);
            }
            DBA_FillVshEntityInfo (&entInfoPtr->entityTab[i++],sqlnameFlg,refEntity);
        }
        return(RET_SUCCEED);
    }

    /*  FPL-070926-PMSTA03123-PMSTA02061    */
    if (entSelTp == DomainBreakDefEntSel)
    {
        entInfoPtr->entityNb = 1;
        i = 0;
        if ((entInfoPtr->entityTab = (VSH_ENTITY_INFO_STP) CALLOC(entInfoPtr->entityNb, sizeof(VSH_ENTITY_INFO_ST))) == NULL)
        {
            entInfoPtr->entityNb = 0;
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }
        DBA_FillVshEntityInfo (&entInfoPtr->entityTab[i++],sqlnameFlg,Domain);
        return(RET_SUCCEED);
    }

    /* ------------------------------------ */
    /* DVP033 : Operation list (RAK 960509) */
    if (entSelTp == PosOpEntSel)
    {
        /* read enum */
        entInfoPtr->entityNb = (int) OpNat_OpNatNbr - 1;

        if ((entInfoPtr->entityTab = (VSH_ENTITY_INFO_STP)
        CALLOC(entInfoPtr->entityNb, sizeof(VSH_ENTITY_INFO_ST))) == NULL)
        {
            entInfoPtr->entityNb = 0;
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        for (i=0, crtOpNat=OpNat_Buy; crtOpNat<OpNat_OpNatNbr; crtOpNat++, i++)
        {
            if ((ret = OPE_OperNatToDictEnum((OPNAT_ENUM) crtOpNat, &opDynst, &opObject)) != RET_SUCCEED)
            {
                FREE(entInfoPtr->entityTab);
                return(ret);
            }
            DBA_FillVshEntityInfo (&entInfoPtr->entityTab[i],sqlnameFlg,opObject);
        }

        return(RET_SUCCEED);
    }
    /* END DVP033 */
    /* ---------- */

    /* ------------------------------------------- */
    /* DVP010 : New menu organisation (RAK 960314) */
    crtEntSel = NULL;
    switch(entSelTp)
    {
        /* Entity List for format */
        case FmtEntSel :
            entInfoPtr->entityNb = FMT_ENTSEL_NBR;
            crtEntSel            = SV_FmtEntSel;
            break;

        /* User, Language, ... */
        case SecurityEntSel :
            entInfoPtr->entityNb = SECURITY_ENTSEL_NBR;
            crtEntSel            = SV_SecurityEntSel;
            break;

        /* Other entities lists */
        /* FctProfStratAdmEntSel */
        case FctProfStratAdmEntSel :
            entInfoPtr->entityNb = FCTPROFSTRATADM_ENTSEL_NBR;
            crtEntSel            = SV_FctProfStratAdmEntSel;
            break;

        /* FctProfConstrAdmEntSel */    /*  FIH-REF6082-020118  */
        case FctProfConstrAdmEntSel :
            entInfoPtr->entityNb = FCTPROFCONSTRADM_ENTSEL_NBR;
            crtEntSel            = SV_FctProfConstrAdmEntSel;
            break;

        /* ValRuleHistEntSel - ROI - 970408 - DVP413 */
        case ValRuleHistEntSel :
            entInfoPtr->entityNb = VALRULEHIST_ENTSEL_NBR;
            crtEntSel            = SV_ValRuleHistEntSel;
            break;
    }

    if (crtEntSel != NULL)
    {
        int                         nb=0;                                    /* PMSTA-24771 - DDV - 161011 */
        if ((entInfoPtr->entityTab = (VSH_ENTITY_INFO_STP) CALLOC(entInfoPtr->entityNb, sizeof(VSH_ENTITY_INFO_ST))) == NULL)
        {
            entInfoPtr->entityNb = 0;
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        for (i=0; i<entInfoPtr->entityNb; i++)
        {
            entity = *(crtEntSel[i].objectPtr); /* REF8844 - LJE - 030415 */
			if (DBA_GetDictEntitySqlName(entity) != NULL)
			{
                DBA_FillVshEntityInfo (&entInfoPtr->entityTab[nb++],sqlnameFlg,entity);
			}
		}
        entInfoPtr->entityNb = nb;

        if (entSelTp == FmtEntSel)
        {
            return (TLS_Sort((char *) entInfoPtr->entityTab,
                    entInfoPtr->entityNb,
                    sizeof(VSH_ENTITY_INFO_ST),
                    (TLS_CMPFCT *)DBA_CmpEntList,
                    NULL,
                    SortRtnTp_None)); /* REF7264 - LJE - 020205 */
        }
        else
        {
            return(RET_SUCCEED);
        }
    }
    /* END DVP010 */
    /* ---------- */

    /* For other cases, entities number isn't know , ENT_BLOCK_ALLOC */
    /* spaces are allocated and during filling the table we test for */
    /* reallocate spaces if necessary                                */
    entInfoPtr->entityNb = 0;
    allocSz = ENT_BLOCK_ALLOC;
    if ((entInfoPtr->entityTab = (VSH_ENTITY_INFO_STP) CALLOC(allocSz, sizeof(VSH_ENTITY_INFO_ST))) == NULL)
    {
        entInfoPtr->entityNb = 0;
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    /* Read entities list */
    j = 0;
    for (auto it = DICT_GetDictEntityVector().begin(); it != DICT_GetDictEntityVector().end(); ++it)
    {
        /* REF7264 */
        DICT_ENTITY_STP dictEntityStp = *it;

        if ((dictEntityStp == nullptr) ||	                                /* PMSTA07964 - LJE - 090317 */
            ((entSelTp != ScreenEntSel) &&                                  /*  HFI-PMSTA-51777-2022-01-06  Test for screen facility moved to DBA_SetDictScreenRights   */
             ((DICTENT_VIRTUALFLG(dictEntityStp) == TRUE)  ||               /*  FIH-REF9790-040218  */
              (DICTENT_VALIDENT(dictEntityStp) == FALSE) ||
              /* PMSTA-22342 - LJE - 160524 */
              ((dictEntityStp->entNatEn != EntityNat_System) &&
               (dictEntityStp->entNatEn != EntityNat_Standard) &&
               (dictEntityStp->entNatEn != EntityNat_Packaging) &&
               (dictEntityStp->entNatEn != EntityNat_Custom) &&
               (dictEntityStp->entNatEn != EntityNat_ModelBank) &&          /* PMSTA-27352 - LJE - 170606 */
			   (dictEntityStp->entNatEn != EntityNat_Tsl) &&			    /* PMSTA-25257 - TEB - 161115 */
               (dictEntityStp->entNatEn != EntityNat_CustomDS) &&
               (dictEntityStp->entNatEn != EntityNat_Questionnaire)))))     /* PMSTA-26282 - DDV - 170214 - Allow uppercase char */
        {
            continue;
        }

        entity = dictEntityStp->objectEn;
        copyFlg = FALSE;

        switch (entSelTp)
        {
        case ListEntSel:
        if (DICTENT_LISTFLG(dictEntityStp) == TRUE)
        {
            ++entInfoPtr->entityNb;
            copyFlg = TRUE;
        }
        break;

        case MainEntSel :
        if (DICTENT_MAINFLG(dictEntityStp) == TRUE)
        {
            ++entInfoPtr->entityNb;
            copyFlg = TRUE;
        }
        break;

        case SynonEntSel:
        if (DICTENT_SYNONFLG(dictEntityStp) == TRUE)
        {
            ++entInfoPtr->entityNb;
            copyFlg = TRUE;
        }
        break;

        case TpEntSel:
        /* Read each entity attributes, search an which have a */
        /* reference on type and isn't a logical attribute     */
                /*  FIH-REF925-971201 Suppress screen profile compo from the list   */
            if (entity == ScreenProfCompo)
                break;

            fnd = FALSE;
            for (auto& dictAttribStp : dictEntityStp->attr)
            {
                DICT_T dictId = DICTATTR_REFENTDICTID(dictAttribStp);
                if (dictId != 0)
                {
                    DBA_GetObjectEnum(dictId, &refEnt);
                    if (refEnt == Tp &&
                        DICTATTR_PARATTRDICTID(dictAttribStp) == 0 &&
                        DICTATTR_LOGICFLG(dictAttribStp) == FALSE &&
                        DICTATTR_SUBTYPEMASK(dictAttribStp) != FALSE &&
                        DICTATTR_RANK(dictAttribStp) != 0)
                    {
                        ++entInfoPtr->entityNb;
                        copyFlg = TRUE;
                        fnd = TRUE;

                        break;
                    }
                }
        }
        break;

        case FilterEntSel :
        case DfltValEntSel :
            if (DICT_EntityHasDefValue(entity) == TRUE)
            {
                ++entInfoPtr->entityNb;
                copyFlg = TRUE;
            }
            break;

        case FctProfOpAdmEntSel :       /*  FIH-REF4258-000112  */
            if ((((OPE_DictEnumToOperNat(entity, &operNat) == RET_SUCCEED) &&
                  (operNat != OpNat_None)) ||
                 (entity == Op)))

            {
                ++entInfoPtr->entityNb;
                copyFlg = TRUE;
            }
            break;

        /*  FPL-PMSTA09855-100518 only "all" for this special case (update field with entity case management)   */
        case FctProfUpdFldCMEntSel :
            break;

        case FctProfOpAndCaseEntSel :   /*  FPL-PMSTA07121-090623 for PMSTA08338    */
            if ((((OPE_DictEnumToOperNat(entity, &operNat) == RET_SUCCEED) &&
                  (operNat != OpNat_None)) ||
                 (entity == Op) ||
                 (entity == CaseManagement)))
            {
                ++entInfoPtr->entityNb;
                copyFlg = TRUE;
            }
            break ;

        /* MRA - 020822 - REF7560 */
        case FctProfOpAndExeEntSel :
            if ((((OPE_DictEnumToOperNat(entity, &operNat) == RET_SUCCEED) &&
                  (operNat != OpNat_None)) ||
                 (entity == Op) ||
                 (entity == ExecutionEnt) ||
                 (entity == GlExecFeeEnt)))

            {
                ++entInfoPtr->entityNb;
                copyFlg = TRUE;
            }
            break;

        case FctProfOpAndAllEntSel :
            if ((entity == Op) ||
                (entity == CaseManagement)) /*  FPL-PMSTA07121-090623 for PMSTA08338    */
            {
                ++entInfoPtr->entityNb;
                copyFlg = TRUE;
            }
            break;

        case FctProfAdmEntSel :
            /* Suppressing BuyOp, ... */
            if (/*(SV_DictEntityTab[entity].interf == 1) &&         FPL-REF6149-050530  */
                (DBA_GetGuiInterfaceFlag(entity) == 1) &&       /*  FPL-REF6149-050530  */
                (DBA_IsAnOperationObject(entity) == FALSE) &&
                (entity != Strat) &&			/* SV_FctProfStratAdmEntSel */
                (entity != StratElt) &&
                (entity != StratLnk) &&
                (entity != StratHist) &&
                (entity != AccPer) &&			/* SV_FctProfAccAdmEntSel */
                (entity != AccPerParam) &&
                (entity != AccPlan) &&
                (entity != AccPlanElt) &&
                (entity != FundVal) &&			/* SV_FctProfFundAdmEntSel */
                (entity != FundValElt) &&
                (entity != ModelConstr) &&	    /* SV_FctProfConstrAdmEntSel    FIH-REF6082-020118  */
                (entity != ModelConstrElt) &&
                (entity != TradConstr)                              /* MRA - 040322 - REF10071 */
               )
            {
                ++entInfoPtr->entityNb;
                copyFlg = TRUE;
            }

            /* Adding Op */
            if (entity == Op)
            {
                ++entInfoPtr->entityNb;
                copyFlg = TRUE;
            }

            /*  Adding all entity op (Buy, Sell ...)    FIH-REF893.2-980205 */
            if (OPE_DictEnumToOperNat(entity, (OPNAT_ENUM*) &crtOpNat) == RET_SUCCEED)
            {
                ++entInfoPtr->entityNb;
                copyFlg = TRUE;
            }
            break;

            case ScreenEntSel :
                if (dictEntityStp->bDictScreenRights == true)       /*  HFI-PMSTA-51777-2022-01-06  */
                {
                    ++entInfoPtr->entityNb;
                    copyFlg = TRUE;
                }
                break;
        case InputCtrlEntSel :
        if (dictEntityStp->inputCtrlFlg == TRUE)
        {
            ++entInfoPtr->entityNb;
            copyFlg = TRUE;
        }
        break;

        /* PMSTA13283 - DDV - 120125 */
        case AllEntSel :
            ++entInfoPtr->entityNb;
            copyFlg = TRUE;
        break;


            /* Entity authorized in packaging   */  /*  HFI-PMSTA-48816-220411  */
            case PackagingEntSel :
                if ((dictEntityStp->isId() == true) &&
                    (dictEntityStp->logicalFlg == FALSE) &&
                    (dictEntityStp->interf != FALSE) &&
                    (entity != DictDataTp) &&
                    (entity != DictEntity) &&
                    (entity != DictCriter) &&
                    (entity != DictAttr) &&
                    (entity != DictLabel) &&
                    (entity != DictPermVal))
                {
                    ++entInfoPtr->entityNb;
                    copyFlg = TRUE;
                }
                break;

            /* Questionnaire entities           */  /*  HFI-PMSTA-51450-2022-11-30  */
            case QuestionnaireEntSel :
                if (dictEntityStp->entNatEn == EntityNat_Questionnaire)
                {
                    ++entInfoPtr->entityNb;
                    copyFlg = TRUE;
                }
                break;
        }

        if (copyFlg == TRUE)
        {
            /* Control if we must reallocate space */
            /* before update structure.            */
            if (j == allocSz)
            {
                allocSz += ENT_BLOCK_ALLOC;
                if ((entInfoPtr->entityTab = (VSH_ENTITY_INFO_STP)
                     REALLOC(entInfoPtr->entityTab,
                     (allocSz * sizeof(VSH_ENTITY_INFO_ST)))) == NULL)
                {
                    MSG_RETURN(RET_MEM_ERR_REALLOC);
                }
            }

            DBA_FillVshEntityInfo (&entInfoPtr->entityTab[j], sqlnameFlg, entity);
            ++j;
        }
    }

    /* Sort data */
    switch(entSelTp)
    {
        case MainEntSel :
        case TpEntSel :
        case DfltValEntSel :
        case FctProfAdmEntSel :
        case FctProfOpAdmEntSel :
        case FctProfOpAndCaseEntSel :   /*  FPL-PMSTA07121-090623 for PMSTA08338    */
        case FctProfUpdFldCMEntSel :    /*  FPL-PMSTA09855-100518   */
        case InputCtrlEntSel :
        case FilterEntSel :
        case ScreenEntSel :
        case FctProfOpAndExeEntSel :
        case ListEntSel :               /*  HFI-PMSTA-21862-151204  */
        case AllEntSel :                /*  HFI-PMSTA-31588-180604  */
        case PackagingEntSel :          /*  HFI-PMSTA-48816-220411  */
        case QuestionnaireEntSel :      /*  HFI-PMSTA-51450-2022-11-30  */
            TLS_Sort((char*) entInfoPtr->entityTab,
                     entInfoPtr->entityNb,
                     sizeof(VSH_ENTITY_INFO_ST),
                     (TLS_CMPFCT *)DBA_CmpEntList, /* REF7264 - LJE - 020205 */
                     NULL,
                     SortRtnTp_None
                    );
            break;
    }
    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   DBA_SetNullAttribWhileCopyingOneAttrib
**
**  Description :   Set some field to null
**
**  Arguments   :   DICT_ENTITY_STP dictEntityStp   : meta  dict entity
**                  DICT_ATTRIB_STP dictAttribStp   : meta dict attribute
**                  DBA_DYNFLD_STP  dbaDynStp       : Structure where some filed must be set to NULL
**                  OBJECT_ENUM     entityRef       : the entity...
**                  DBA_DYNST_ENUM  enDynSt         : the dynamic structure
**                  FLAGT**         evalDVTab       : array of flag to know if we need to run DV or not for the attrib
**                  int             iCpt            : index in the array of flag
**
**  Return      :   None
**
**  Creation    :   HFI-PMSTA-41842-200916  Set Null while copying for one particular attribute
**
*************************************************************************/
void DBA_SetNullAttribWhileCopyingOneAttrib (DICT_ENTITY_STP dictEntityStp, DICT_ATTRIB_STP dictAttribStp, DBA_DYNFLD_STP dbaDynStp, OBJECT_ENUM entityRef, DBA_DYNST_ENUM enDynSt, FLAG_T **evalDVTab, int iCpt, FLAG_T flagCopyingOneRecord)
{
    if ((dictAttribStp->enSetNullWhileCopying == DictNullCopy_HardCoded) ||
        ((dictAttribStp->enSetNullWhileCopying == DictNullCopy_One_HardCoded) && (flagCopyingOneRecord == TRUE)))
    {
        if (dictEntityStp->objectEn == XdEntity)
        {
            if (dictAttribStp->progN == A_XdEntity_AutomaticMask)
            {
                SET_MASK(dbaDynStp, dictAttribStp->progN, 4096);
            }
        }
        else if (dictEntityStp->objectEn == XdAttrib)
        {
            if (dictAttribStp->progN == A_XdAttrib_ParentXdAttribId)
            {
                DATATYPE_ENUM       enDataType = NullDataType;
                DICT_ENTITY_STP     pdictent = DBA_GetEntityBySqlName("tsl_perm_value");        /*  Particular case for tsl_perm_value  */
                if ((pdictent->xdEntityId != GET_ID(dbaDynStp, A_XdAttrib_XdEntityId)) &&
                    (IS_NULLFLD(dbaDynStp, A_XdAttrib_ParentXdAttribId) == TRUE) &&
                    (IS_NULLFLD(dbaDynStp, A_XdAttrib_Id) == FALSE) &&
                    (IS_NULLFLD(dbaDynStp, A_XdAttrib_DataTpDictId) == FALSE) &&
                    ((enDataType = DATATYPE_DICT_TO_ENUM(GET_DICT(dbaDynStp, A_XdAttrib_DataTpDictId))) != NullDataType) &&
                    ((enDataType == EnumType) || (enDataType == EnumMaskType) ||(enDataType == FlagType)))
                {
                    SET_ID(dbaDynStp, dictAttribStp->progN, GET_ID(dbaDynStp, A_XdAttrib_Id));
                }
            }
        }
        (*evalDVTab)[iCpt] = TRUE;
    }
    else if (((dictAttribStp->enSetNullWhileCopying == DictNullCopy_SetToNull) ||
              ((dictAttribStp->enSetNullWhileCopying == DictNullCopy_One_SetToNull) && (flagCopyingOneRecord == TRUE))) ||
             ((dictAttribStp->enSetNullWhileCopying == DictNullCopy_SetToNullAndDV) ||
              ((dictAttribStp->enSetNullWhileCopying == DictNullCopy_One_SetToNullAndDV) && (flagCopyingOneRecord == TRUE))))
    {
        if (((dictAttribStp->dataTpProgN == EnumType) || (dictAttribStp->dataTpProgN == FlagType)) &&
            (dictAttribStp->dfltVal.empty() == false))
        {
            DBA_StrToData(dictAttribStp->dfltVal.c_str(), dbaDynStp, dictAttribStp->progN);
        }
        else
        {
            SET_NULL_FLD(dbaDynStp, dictAttribStp->progN);
        }
        /*  FPL-REF10603-041229 */
        if ((dictAttribStp->enSetNullWhileCopying == DictNullCopy_SetToNullAndDV) ||
            ((dictAttribStp->enSetNullWhileCopying == DictNullCopy_One_SetToNullAndDV) && (flagCopyingOneRecord == TRUE)))
        {
            (*evalDVTab)[iCpt] = FALSE;
        }
    }
}

/************************************************************************
**
**  Function    :   DBA_SetNullAttribWhileCopying
**
**  Description :   Set some field to null
**
**  Arguments   :   dbaDynStp   :   Structure where some filed must be set to NULL
**                  entityRef   :   the entity...
**                  evalDVTab   :   array of flag to know if we need to run DV or not for the attrib    FPL-REF10603-041229
**
**  Return      :   None
**
**  Creation    :   FPL-REF10305-040915
**  Modif       :   HFI-PMSTA-41842-200916  Set Metadictionnary DV for Enum and Flag + particular case Xd entities
**
*************************************************************************/
void DBA_SetNullAttribWhileCopying(DBA_DYNFLD_STP dbaDynStp, OBJECT_ENUM entityRef, FLAG_T **evalDVTab, FLAG_T flagCopyingOneRecord)
{
    /*  set some field to null */
    DICT_ENTITY_STP     dictEntityStp = DBA_GetDictEntitySt(entityRef);
    DBA_DYNST_ENUM      enDynSt = GET_EDITGUIST(entityRef);
    if (dictEntityStp != nullptr)
    {
        /*  Loop on all attributes except primary                       */
        for (auto& dictAttribStp : dictEntityStp->attr)
        {
            int iCpt = dictAttribStp->progN;

            (*evalDVTab)[iCpt] = TRUE;

            if ((dictAttribStp != NULL) &&
                (dictAttribStp->primFlg == FALSE) &&
                (dictAttribStp->enSetNullWhileCopying != DictNullCopy_NotSetToNull))  /*  FPL-REF10603-041229 */
            {
                DBA_SetNullAttribWhileCopyingOneAttrib(dictEntityStp, dictAttribStp, dbaDynStp, entityRef, enDynSt, evalDVTab, iCpt, flagCopyingOneRecord);
            }
        }
        /*  Check only primary                                          */
        for (auto& dictAttribStp : dictEntityStp->attr)
        {
            int iCpt = dictAttribStp->progN;

            if ((dictAttribStp != NULL) &&
                (dictAttribStp->primFlg == TRUE) &&
                (dictAttribStp->enSetNullWhileCopying != DictNullCopy_NotSetToNull))
            {
                DBA_SetNullAttribWhileCopyingOneAttrib(dictEntityStp, dictAttribStp, dbaDynStp, entityRef, enDynSt, evalDVTab, iCpt, flagCopyingOneRecord);
            }
        }
    }
}

/************************************************************************
**
**  Function    :   DBA_GetAdmDictFct
**
**  Description :
**
**  Arguments   :   entityRef           :   the entity to be tested
**                  *entity             :   returned entity, can be NULL
**                  *fctEn              :   returned dict function enum
**
**  Return      :
**
**  Creation    :   FPL-REF10253-040504
**
*************************************************************************/
RET_CODE    DBA_GetAdmDictFct ( OBJECT_ENUM     entityRef
                              , OBJECT_ENUM     *entity
                              , DICT_T          *fctEn      /*  FPL-PMSTA12499-110818 DICT_FCT_ENUM*->DICT_T*   */
                              )
{

    /* test for security */
    if (fctEn   == NULL)
        return RET_GEN_ERR_INVARG ;

    /* initialisation */
    if (entity != NULL)
        *entity = entityRef ;

    /* Check administration authorization for action button */  /*  FIH-REF10209-040429 */
    switch (GET_OBJECT_CST(entityRef))
    {
        /* Strategy Administration */
        case StratCst :
        case StratEltCst :
        case StratLnkCst :
        case StratHistCst :
            *fctEn = DictFct_StratAdmin;
            break;

        /* REF4047 */
        case EStratEltCst :
            *fctEn = DictFct_StratAdmin;
            if (entity != NULL)
                *entity = StratElt;
            break;

        /* Accounting Administration */
        case AccPerCst :
        case AccPerParamCst :
        case AccPlanCst :
        case AccPlanEltCst :
            *fctEn = DictFct_AccAdmin;
            break;

        /* Fund Administration */
        case FundValCst :
        case FundValEltCst :
            *fctEn = DictFct_FundAdmin;
            break;

        /* MRA - 020516 - REF7190 */
        case ModelConstrCst :
        case ModelConstrEltCst :
        case TradConstrCst :                                    /* FPL-REF7291-020814 add trading constraint */
            *fctEn = DictFct_ConstraintAdministration;
            break;

        default :
            *fctEn = DictFct_Admin;
            break;
    }


    return RET_SUCCEED ;

}


/************************************************************************
**
**  Function    :   DBA_CmpDynSt
**
**  Description :   Compare two dbadyn structures.
**
**  Arguments   :   entity,
**		            stEnum,
**                  dynStp1,
**                  dynStp2
**                  compareDbFieldOnly  if database field are compared
**
**  Return      :   int
**
**  Creation	:   ROI - 960911 - DVP204
**
**  Modif.	    :   ROI - 961126 - BUG213
**                  PMSTA-19029 - 041114 - PMO : Operation - Duplicate Key message when trying to modify an operation
**
*************************************************************************/
int	DBA_CmpDynSt(OBJECT_ENUM entity, DBA_DYNST_ENUM stEnum, DBA_DYNFLD_STP dynStp1, DBA_DYNFLD_STP dynStp2, const bool compareDbFieldOnly)
{
	/* Test given arguments */
	if (entity == NullEntity || stEnum == NullDynSt)
	  return -1;

	/* Test NULL ptr */
    if (dynStp1 == NULL)
    {
        if (dynStp2 == NULL) return 0;
        else return 1;
    }
    else if (dynStp2 == NULL) return -1;

	/* Start comparison */
    int       value = 0;
	const int fldNb = EV_DynStPtr[stEnum].fldNbr;
	for (int i = 0; value == 0 && i < fldNb ; i++)
	{
        if (false == compareDbFieldOnly || TRUE == IS_DBFLD(stEnum, i))  /* PMSTA-19029 - 041114 - PMO */
        {
            value = DBA_CmpDynFld(dynStp1,
                                  dynStp2,
                                  i,
                                  i,
                                  GET_FLD_TYPE(stEnum, i),  /* DICT_GetAttribDataType(entity, i) */  /* REF8844 - LJE - 030408 */
                                  FALSE,                     /* Case insensitive */
								  FALSE						/*	PMSTA-54403	- GAD - 29082023 */
                                  );
        }
	}

	return value;
}


/************************************************************************
**
**  Function    :   DBA_ExtractSpecificField
**
**  Description :   Compare a dynamic structure to a reference structure
**                  And set equal field to NULL
**
**  Arguments   :   OBJECT_ENUM     enObject    : Compared entity
**                  DBA_DYNST_ENUM  enDynSt     : Compared struture type (A_..., S_...)
**                  DBA_DYNFLD_STP  pdbadyn     : Compared structure
**                  DBA_DYNFLD_STP  pdbadynRef  : Reference structure
**
**  Return      :   int                         : 0 if equal, +-1 if not
**
**  Creation	:   FIH-REF9546-031030
**
*************************************************************************/
int	DBA_ExtractSpecificField (OBJECT_ENUM enObject, DBA_DYNST_ENUM enDynSt, DBA_DYNFLD_STP pdbadyn, DBA_DYNFLD_STP pdbadynRef)
{
    int     iValue,         /*  Returned value                          */
            iReturnedValue, /*  Returned value                          */
            i,              /*  Loop variable                           */
            iNbField;       /*  Number of filed in dynamic structure    */

    /*  Test given arguments                                            */
    if ((enObject == NullEntity) ||
        (enDynSt == NullDynSt))
        return -1;

    /*  Test NULL ptr                                                   */
    if (pdbadyn == NULL)
    {
        if (pdbadynRef == NULL)
            return 0;
        else
            return 1;
    }
    else if (pdbadynRef == NULL)
        return -1;

    /*  Init local variable                                             */
    iReturnedValue = 0;
    i = 0;
    iNbField = EV_DynStPtr[enDynSt].fldNbr;

    /*  Compare field with reference                                    */
    for (i = 0; i < iNbField; i++)
    {
        if (IS_NULLFLD(pdbadyn,i) == FALSE)
        {
            if ((iValue = DBA_CmpDynFld(pdbadyn,
                                        pdbadynRef,
                                        i,
                                        i,
                                        DICT_GetAttribDataType(enObject, i),
                                        FALSE)) != 0)
                iReturnedValue = iValue;
            else
            {
                /*  Set equal field to NULL                             */
                if ((DICT_GetAttribDataType(enObject, i) == FlagType) ||
                    (DICT_GetAttribDataType(enObject, i) == EnumType))
                {
                    SET_NULL_ENUM(pdbadyn,i);
                }
                else
                {
                    SET_NULL_FLD(pdbadyn,i);
                }
            }
        }
    }
    return iReturnedValue;
}



/************************************************************************
**
**  Function             : DBA_InitAdmArgFromMeta()
**
**  Description          : Init Adm_Arg structure with identifier (id and entity_dict_id)
**
**  Arguments		 : admArgStp	structure to fill
**			   info	        entity informations or NULL
**			   objEn	entity object
**			   parObjEn	parent object enum
**		           parObjId	record identifier
**
**  Return               : RET_SUCCEED or error code
**
**  Creation		 : DVP329 - RAK - 970124
************************************************************************/
RET_CODE DBA_InitAdmArgFromMeta(DBA_DYNFLD_STP 	admArgStp,
                PTR 		info,
                OBJECT_ENUM 	objEn,
                OBJECT_ENUM      parObjEn,
                ID_T 		parObjId)
{
    ENTITY_INFO_STP	infoStp;
    ENTITY_INFO_ST	infoSt;
    RET_CODE	retCode;
    DICT_T		dictId;

    infoStp = (ENTITY_INFO_STP) info;

    if (admArgStp == NULL)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
                 "DBA_InitAdmArgFromMeta", "admArgStp");
        return(RET_GEN_ERR_INVARG);
    }

    if (infoStp == NULL)
    {
        memset(&infoSt, 0, sizeof(ENTITY_INFO_ST));

        infoSt.entityRef     = objEn;
        infoSt.metaTypeEnum  = AllMeta;
        infoSt.structEnum    = GET_EDITGUIST(infoSt.entityRef);

        if ((retCode = DBA_GetDictEntityInfo(&infoSt)) != RET_SUCCEED)
        return(retCode);

        infoStp = &infoSt;
    }

    /* Entity with entityDictId (idx 0) and objectId (idx 1) */
    if (infoStp->dictEntFlag == TRUE)
    {
        DBA_GetDictId(parObjEn, &dictId);
        SET_DICT(admArgStp, Adm_Arg_EntDictId, dictId);
        SET_ID(admArgStp,   Adm_Arg_Id,        parObjId);
    }
    else	/* Or an entity with an objectId (idx 0) */
    {
        SET_ID(admArgStp, Adm_Arg_Id, parObjId);
    }

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function             : DBA_InvalidLogicalList()
**
**  Description          : Compare two natures and suppress invalid logical
**			   attributes if record identifier is received
**
**  Arguments		 : objEn	      entity object
**  			   oldNatEn	      old nature
**			   oldInfo	      old entity informations or NULL
**			   newNatEn	      new nature
**			   newInfo	      new entity informations or NULL
**			   invalidListPtr     pointer on invalid logical attribute list or NULL
**			   invalidNbrPtr      pointer on invalid logical attribute number
**
**
**  Return               : RET_SUCCEED or error code
**
**  Creation		 : DVP329 - RAK - 970123
************************************************************************/
RET_CODE DBA_InvalidLogicalList(OBJECT_ENUM     objEn,
                ENUM_T 	        oldNatEn,
                PTR		oldInfo,
                ENUM_T 	        newNatEn,
                PTR		newInfo,
                OBJECT_ENUM	**invalidListPtr,
                int		*invalidNbrPtr)
{
    ENTITY_INFO_STP		oldInfoStp, newInfoStp;
    ENTITY_INFO_ST		oldInfoSt, newInfoSt;
    ALL_ATTRIB_INFO_STP	attribTab, oldAttribStp, newAttribStp;
    OBJECT_ENUM		*invalidList=NULL;
    int			i, j, firstNewLogical,
                allocSz=0, invalidNbr=0;
    char			found, firstNewSet;
    RET_CODE		retCode;

    if (invalidNbrPtr == NULL || invalidListPtr == NULL)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
             "DBA_InvalidLogicalList", "list or number pointer");
        return(RET_GEN_ERR_INVARG);
    }

    oldInfoStp = (ENTITY_INFO_STP) oldInfo;
    newInfoStp = (ENTITY_INFO_STP) newInfo;

    if (oldInfoStp == NULL)
    {
        memset(&oldInfoSt, 0, sizeof(ENTITY_INFO_ST));
        oldInfoSt.nature = new PermitedValuesClass;
        if (oldInfoSt.nature == nullptr)
        {
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        oldInfoSt.entityRef     = objEn;
        oldInfoSt.nature->value = (long) oldNatEn;
        oldInfoSt.metaTypeEnum  = AllMeta;
        oldInfoSt.structEnum    = GET_EDITGUIST(oldInfoSt.entityRef);

        if ((retCode = DBA_GetDictEntityInfo(&oldInfoSt)) != RET_SUCCEED)
        {
            if (oldInfoSt.nature != nullptr)
            {
                delete oldInfoSt.nature;
                oldInfoSt.nature = nullptr;
            }
            return(retCode);
        }

        oldInfoStp = &oldInfoSt;
    }

    if (newInfoStp == NULL)
    {
        memset(&newInfoSt, 0, sizeof(ENTITY_INFO_ST));
        oldInfoSt.nature = new PermitedValuesClass;
        if (oldInfoSt.nature == nullptr)
        {
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        newInfoSt.entityRef     = objEn;
        newInfoSt.nature->value = (long) newNatEn;
        newInfoSt.metaTypeEnum  = AllMeta;
        newInfoSt.structEnum    = GET_EDITGUIST(newInfoSt.entityRef);

        if ((retCode =  DBA_GetDictEntityInfo(&newInfoSt)) != RET_SUCCEED)
        {
            if (newInfoSt.nature != nullptr)
            {
                delete newInfoSt.nature;
                newInfoSt.nature = nullptr;
            }
            return(retCode);
        }

        newInfoStp = &newInfoSt;
    }

    if (oldInfoStp->entityRef != newInfoStp->entityRef)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
                 "DBA_InvalidLogicalList", "entities");
        return(RET_GEN_ERR_INVARG);
    }

    /* Nothing to compare */
    if (oldInfoStp->nature->value == newInfoStp->nature->value)
        return(RET_SUCCEED);

    /* Prepare invalide logical attribute list pointer */
    if (invalidNbrPtr != NULL && invalidListPtr != NULL)
    {
        *invalidListPtr = invalidList;	/* NULL */
        *invalidNbrPtr = invalidNbr;	/* 0 */
    }

    firstNewLogical = 0;
    firstNewSet     = FALSE;

    for (i=0; i<oldInfoStp->attribNb; i++)
    {
        attribTab = (ALL_ATTRIB_INFO_STP) oldInfoStp->attribTab;
        oldAttribStp = &(attribTab[i]);

        /* Search logical attributes */
        if (oldAttribStp->logRefFlag == TRUE)
        {
        /* Search same logical attribute in new structure */
            for (j=firstNewLogical, found=FALSE; j<newInfoStp->attribNb && found==FALSE; j++)
            {
                attribTab = (ALL_ATTRIB_INFO_STP) newInfoStp->attribTab;
                newAttribStp = &(attribTab[j]);

            if (newAttribStp->logRefFlag == TRUE)
            {
            if (firstNewSet == FALSE)
            {
                firstNewSet = TRUE;
                firstNewLogical = j;
            }

                if (!strcmp(oldAttribStp->sqlName, newAttribStp->sqlName))
                found = TRUE;
            }
        }

        /* Logical attributes don't exist in new structure */
        if (found == FALSE)
        {
            if (invalidList == NULL || invalidNbr >= allocSz)
            {
            allocSz += 10;
            if ((invalidList = (OBJECT_ENUM*) REALLOC(invalidList, allocSz*sizeof(OBJECT_ENUM)))== NULL)
            {
                MSG_RETURN(RET_MEM_ERR_ALLOC);
            }
            }

            invalidList[invalidNbr] = oldAttribStp->entityRef;
            ++invalidNbr;
        }
        }
    }

    /* Prepare invalide logical attribute list pointer */
    if (invalidNbrPtr != NULL && invalidListPtr != NULL)
    {
        *invalidListPtr = invalidList;
        *invalidNbrPtr = invalidNbr;
    }

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   DBA_GetRefEntityDictId
**
**  Description :
**
**  Argument    :   DICT_T          *refEntityDictIdPtr
**                  OBJECT_ENUM     objectEn
**                  int             attributeIndex
**                  DBA_DYNFLD_STP  dbaDynStp
**
**  Return      :   DICT_T
**
**  Modif       :   FIH - 000323 - REF4497  creation
**
*************************************************************************/
DICT_T  DBA_GetRefEntityDictId (DICT_T          *refEntityDictIdPtr,
                                OBJECT_ENUM     objectEn,
                                int             attributeIndex,
                                DBA_DYNFLD_STP  dbaDynStp)
{
    int         dimIndex;
    OBJECT_ENUM dimObjectEn;
    DICT_T      dimDictId;

    if (objectEn == Domain)
    {
        dimObjectEn = NullEntity;

        /* REF8844 - LJE - 030410
            switch (attributeIndex)
            {
                case A_Domain_PtfObjId :    dimObjectEn = Ptf;      break;
                case A_Domain_InstrObjId :  dimObjectEn = Instr;    break;
                case A_Domain_StratObjId :  dimObjectEn = Strat;    break;
            }
        */
        if (attributeIndex==A_Domain_PtfObjId)
        {
            dimObjectEn = Ptf;
        }
        else if (attributeIndex==A_Domain_InstrObjId)
        {
            dimObjectEn = Instr;
        }
        else if (attributeIndex==A_Domain_StratObjId)
        {
            dimObjectEn = Strat;
        }

        if (dimObjectEn != NullEntity)
        {
            DBA_GetDictId(dimObjectEn,&dimDictId);
            if (dbaDynStp == NULL)
                *refEntityDictIdPtr = dimDictId;
            else
            {
                dimIndex = -1;
                /* REF8844 - LJE - 030410
                    switch (attributeIndex)
                    {
                        case A_Domain_PtfObjId :    dimIndex = A_Domain_DimPtfDictId;   break;
                        case A_Domain_InstrObjId :  dimIndex = A_Domain_DimInstrDictId; break;
                        case A_Domain_StratObjId :  dimIndex = A_Domain_DimStratDictId; break;
                    }
                */
                if (attributeIndex==A_Domain_PtfObjId)
                {
                    dimIndex = A_Domain_DimPtfDictId;
                }
                else if (attributeIndex==A_Domain_InstrObjId)
                {
                    dimIndex = A_Domain_DimInstrDictId;
                }
                else if (attributeIndex==A_Domain_StratObjId)
                {
                    dimIndex = A_Domain_DimStratDictId;
                }
                else if (attributeIndex==A_Domain_FctResultId)  /*  FPL-090211-PMSTA07121   */
                {
                    dimIndex = A_Domain_DimFctResultDictId;
                }


                if ((dimIndex != -1) &&
                    (IS_NULLFLD(dbaDynStp,dimIndex) == FALSE) &&
                    (GET_DICT(dbaDynStp,dimIndex) == dimDictId))
                    *refEntityDictIdPtr = dimDictId;
                else
                    *refEntityDictIdPtr = 0;
            }
        }
    }
    /*  FIH-REF9825-040113  */
    else if (objectEn == ModelConstrElt)
    {
        dimObjectEn = NullEntity;
        if (attributeIndex == A_ModelConstrElt_InstrObjId)
        {
            dimObjectEn = List;
        }
        if (dimObjectEn != NullEntity)
        {
            DBA_GetDictId(dimObjectEn,&dimDictId);
            if (dbaDynStp == NULL)
                *refEntityDictIdPtr = dimDictId;
            else
            {
                dimIndex = -1;
                if (attributeIndex == A_ModelConstrElt_InstrObjId)
                {
                    dimIndex = A_ModelConstrElt_DimInstrDictId;
                }
                if ((dimIndex != -1) &&
                    (IS_NULLFLD(dbaDynStp,dimIndex) == FALSE) &&
                    (GET_DICT(dbaDynStp,dimIndex) == dimDictId))
                    *refEntityDictIdPtr = dimDictId;
                else
                    *refEntityDictIdPtr = 0;
            }
        }
    }
    return *refEntityDictIdPtr;
}

/************************************************************************
**
**  Function    :   DBA_GetDictFctAdmAuthByUser
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation    :   FPL-REF11314-060512
**
*************************************************************************/
RET_CODE    DBA_GetDictFctAdmAuthByUser ( DICT_T                fctEn
                                        , OBJECT_ENUM           entity
                                        , DICT_FCT_STP          *pfctStp
                                        )
{
    DICT_FCT_STP              fctStp;
    std::vector<DICT_FCT_ST> *fctTab;
    DICT_T                    entityDictId;
    FLAG_T          found;
    int             i;
    int             index ;
    int             iNbRows ;


    /* Test given argument */
    if (pfctStp == NULL)
        MSG_RETURN(RET_GEN_ERR_INVARG);


    /* Init local variables */
    DBA_GetDictId(entity, &entityDictId);
    found = FALSE;
    i = 0;
    DBA_GetDictFctTab(fctTab);
    iNbRows = static_cast<int>(fctTab->size());

    /* Get default administration status */

    index = DictFct_0;
    while ((index < iNbRows) &&
           (fctEn != (*fctTab)[index].dictId))
    {
        index++ ;
    }
    if (index >= iNbRows)
    {
        return RET_GEN_ERR_INVARG ;
    }

    /* Init local variable */
    fctStp = &((*fctTab)[index]);

    *pfctStp = fctStp;


    /* Loop looking for given function */
    while ((i < iNbRows) && (found == FALSE))
    {
        /* Init loop variable */
        fctStp = &((*fctTab)[i++]);

        /* Check if current function correspond */
        if ((fctStp->dictId == fctEn) &&
            (fctStp->entityDictId == entityDictId))
        {
            found = TRUE;
            *pfctStp = fctStp;
        }
    }
    return RET_SUCCEED;
}



/************************************************************************
**  Function    :   DBA_GetSelectModeInfo
**
**  Description :   Get select Mode Info
**
**  Arguments   :   OBJECT_ENUM entityRef
**                  char*       pszSelectString
**                  short*      iSelectStringIndex
**                  short*      enSelectMode
**                  ENUM_T*     enSelectNature
**                  ID_T*       dictSelectFunction
**
**  Return      :   RET_CODE
**
**  Modif       :   FIH-990204-REF1816
**
*************************************************************************/
RET_CODE DBA_GetSelectModeInfo ( OBJECT_ENUM    entityRef
                               , char           *pszSelectString
                               , int            *iSelectStringIndex
                               , short          *enSelectMode
                               , ID_T           *enSelectNature
                               , ID_T           *dictSelectFunction
                               , DBA_DYNFLD_STP *dynQSearchStp          /*  FPL-REF10391-041202 */
                               , DBA_DYNFLD_STP *dynListStp             /*  FPL-REF10391-041202 */
                               )
{
    DICT_ENTITY_STP     dictEntityStp;

    if ((entityRef <= LASTENTITYOBJECT) &&
        (entityRef != NullEntity)       &&
        (dictEntityStp = DBA_GetDictEntitySt(entityRef)) != NULL) /* PMSTA07964 - LJE - 090309 */
    {
        if (pszSelectString != NULL)
        {
            if (dictEntityStp->pszSelectString[0] == END_OF_STRING)
                pszSelectString = nullptr;
            else
                strcpy(pszSelectString,dictEntityStp->pszSelectString);
        }

        if ((dictEntityStp->pdbadynSelectList != NULL) &&               /*  FPL-REF10391-041202 */
            (dynListStp != NULL))
        {
            if ((*dynListStp == NULL) &&
                ((*dynListStp = ALLOC_DYNST(S_List)) == NULL))
                MSG_RETURN(RET_MEM_ERR_ALLOC);
            COPY_DYNST(*dynListStp, dictEntityStp->pdbadynSelectList, S_List) ;
        }

        if ((dictEntityStp->pdbadynQSearch != NULL) &&                   /*  FPL-REF10391-041210 */
            (dynQSearchStp != NULL))
        {
            if ((*dynQSearchStp == NULL) &&
                ((*dynQSearchStp = ALLOC_DYNST(S_List)) == NULL))
                MSG_RETURN(RET_MEM_ERR_ALLOC);
            COPY_DYNST(*dynQSearchStp, dictEntityStp->pdbadynQSearch, S_List) ;
        }

        *enSelectMode = dictEntityStp->enSelectMode;
        *iSelectStringIndex = dictEntityStp->iSelectStringIndex;
        *enSelectNature = dictEntityStp->enSelectNature;
        *dictSelectFunction = dictEntityStp->dictSelectFunction;
        return RET_SUCCEED;
    }
    else
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_GetSelectModeInfo", "entityRef");
        return RET_GEN_ERR_INVARG;
    }
}

/************************************************************************
**  Function    :   DBA_SetSelectModeInfo
**
**  Description :   Set select Mode Info
**
**  Arguments   :   OBJECT_ENUM entityRef
**                  char*       pszSelectString
**                  short       iSelectStringIndex
**                  short       selectMode
**                  long        enSelectNature
**                  ID_T        dictSelectFunction
**                  FLAG_T      setStringFlag
**
**  Return      :   RET_CODE
**
**  Modif       :   FIH-990204-REF1816
**
*************************************************************************/
RET_CODE DBA_SetSelectModeInfo ( OBJECT_ENUM        entityRef
                               , char               *pszSelectString
                               , int                iSelectStringIndex
                               , short              enSelectMode
                               , ID_T               enSelectNature      /*  FPL-PMSTA08801-091119 long to ID_T  */
                               , ID_T               dictSelectFunction
                               , DBA_DYNFLD_STP     dynQSearchStp       /*  FPL-REF10391-041210 */
                               , DBA_DYNFLD_STP     dynListStp          /*  FPL-REF10391-041202 */
                               , char               *pszList            /*  FPL-REF10391-041210 */
                               , FLAG_T             setStringFlag
                               )
{
    DICT_ENTITY_STP     dictEntityStp;

    if ((entityRef <= LASTENTITYOBJECT) &&
        (entityRef != NullEntity)       &&
        (dictEntityStp = DBA_GetDictEntitySt(entityRef)) != NULL) /* PMSTA07964 - LJE - 090309 */
    {
        if (setStringFlag == TRUE)
        {
            if ((pszSelectString != NULL) &&
                (pszSelectString[0] != END_OF_STRING))
                strcpy(dictEntityStp->pszSelectString,pszSelectString);
            else
                dictEntityStp->pszSelectString[0] = END_OF_STRING;
            dictEntityStp->iSelectStringIndex = iSelectStringIndex;
        }
        else
        {
            dictEntityStp->enSelectNature = enSelectNature;
            dictEntityStp->dictSelectFunction = dictSelectFunction;
        }

        /*  FPL-REF10391-041203 */
        if ((pszList != NULL) &&
            (pszList[0] != '\0') &&
            dynListStp != NULL)
        {
            if (dictEntityStp->pszList != NULL)
                FREE(dictEntityStp->pszList);
            dictEntityStp->pszList = pszList ;

            if ((dictEntityStp->pdbadynSelectList == NULL) &&
                ((dictEntityStp->pdbadynSelectList = ALLOC_DYNST(S_List)) == NULL))
                MSG_RETURN(RET_MEM_ERR_ALLOC);
            COPY_DYNST(dictEntityStp->pdbadynSelectList, dynListStp, S_List);

        }

        /*  FPL-REF10391-041210 */
        if (dynQSearchStp != NULL)
        {
            if ((dictEntityStp->pdbadynQSearch == NULL) &&
                ((dictEntityStp->pdbadynQSearch = ALLOC_DYNST(S_List)) == NULL))
                MSG_RETURN(RET_MEM_ERR_ALLOC);
            COPY_DYNST(dictEntityStp->pdbadynQSearch, dynQSearchStp, S_List);
        }

        dictEntityStp->enSelectMode = enSelectMode;
        return RET_SUCCEED;
    }
    else
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_GetSelectModeInfo", "entityRef");
        return RET_GEN_ERR_INVARG;
    }
}


/************************************************************************
**  Function    :   DBA_GetRightToRunIndex
**
**  Description :   Get the iRightToRunIndex field
**
**  Arguments   :   OBJECT_ENUM entityRef
**
**  Return      :   int : the index of the field
**
**  Creation    :   FPL-REF11314-060718
**  Modif.          PMSTA-22506 - DDV - 160421
**
*************************************************************************/
int DBA_GetRightToRunIndex ( OBJECT_ENUM        entityRef
                           )
{

    int               iRightToRunIndex ;
    DICT_ENTITY_STP   dictEntityStp = DBA_GetDictEntitySt(entityRef);

    iRightToRunIndex = -1 ;

    /* PMSTA-22506 - 160421 - Use MD information to get this index instead of old hard coded function */
    if (dictEntityStp != NULL &&
        dictEntityStp->updFctAuthEn == FeatureAuth_Enable &&
        dictEntityStp->rightToRunAttrStp != NULL)
    {
        /* PMSTA-23385 - LJE - 160714 - Use the MD information */
        iRightToRunIndex = dictEntityStp->rightToRunAttrStp->progN;
    }

    return iRightToRunIndex ;
}

/************************************************************************
*   Function             : DBA_GetDictEntityInfo()
*
*   Description          : Return information on entity. (entityRef is given)
*                          Fill attributes informations depending on metaTypeEnum
*                          (ALL_ATTRIB_INFO or SH_ATTRIB_INFO)
*
*   Arguments            : entity structure pointer
*                            input  : entityRef  entity object enum
*                                     typingFlag TRUE if subtyping
*                                     nature     pointer on 1 structure which
*                                                contains the nature to test
*                                     metaTypeEnum    for attributes informations
*
*                            output : attribNb   attribute number
*                                     attribTab is allocated and filled
*
*   Warning !!           : parent function must deallocate the pointer
*
*   Return               : RET_SUCCEED, RET_GEN_INFO_NODATA or error code
*
*   Modif                : DVP039 - RAK - 960426
*                          DVP169 - RAK - 960813
*                          DVP200 - RAK - 960925
*                          REF1344 - FIH - 980223
*                          PMSTA-34279 - 211218 - PMO : Regression - Drop down values are not properly displayed in Forex Order screen
*
*************************************************************************/
RET_CODE DBA_GetDictEntityInfo(ENTITY_INFO_STP entity)
{
    int                 totAttribNb;
    const char          *theLabel = NULL;
    const UChar         *theUniLabel = NULL;    /* REF9303 - LJE - 030912 */
    RET_CODE            ret;
    DICT_ENTITY_STP     pdictent;               /*  FIH-REF10778-041124 */
    ALL_ATTRIB_INFO_STP attribStp;              /*  FIH-REF10778-041124 */
    DICT_ENTITY_STP     dictEntityStp = DBA_GetDictEntitySt(entity->entityRef);
    DbiConnectionHelper dbiConnHelper;

    /*  Inserer le test ici */
    if (dictEntityStp == NULL) /* PMSTA07964 - LJE - 090317 */
        return(RET_GEN_ERR_INVARG);

    /* Update entity flags and keys number */
    entity->mainEntFlag   = DICTENT_MAINFLG(dictEntityStp);
    entity->primKeyIdFlag = ((dictEntityStp->pkRuleEn == PkRule_Identity || dictEntityStp->pkRuleEn == PkRule_ExternalPk)? TRUE : FALSE);     /*DICTENT_MAINFLG(dictEntityStp);  DVP169 */    /*  HFI-PMSTA-27958-170824  Main Flag is now correct in database    */    /*  PMSTA-30121-180205  Add PkRule_ExternalPk to the test   */
    entity->dictEntFlag   = DICTENT_ENTITYFLG(dictEntityStp);
    entity->listFlag      = DICTENT_LISTFLG(dictEntityStp);
    entity->synonFlag     = DICTENT_SYNONFLG(dictEntityStp);
    entity->qSearchFlag   = DICTENT_QUICKSEARCH(dictEntityStp);
    entity->iUniqueKeyNb  = DICTENT_UNIQUEKNBR(dictEntityStp);          /*  Replace DICTENT_PRIMKNBR by DICTENT_UNIQUEKNBR  HFI-PMSTA-21799-151115  */
    entity->visKeyNb      = DICTENT_VISKNBR(dictEntityStp);
    entity->activeFlg     = DICTENT_ACTIVEFLAG(dictEntityStp);  /*  FPL-REF11444-050922 */
    entity->iNbLinkedDimObj = DICTENT_NBLINKEDDIMOBJ(dictEntityStp);    /*  FPL-REF11563-051209 */
    entity->parIndex      = DICTENT_PARINDEX(dictEntityStp);           /* PMSTA-13109 - LJE - 111115 */
    entity->natIndex      = DICTENT_NATINDEX(dictEntityStp);           /* PMSTA-13109 - LJE - 111115 */

    /* PMSTA-13122 - LJE - 120612 */
    if (entity->parIndex > Null_Dynfld &&
        dictEntityStp->attr[entity->parIndex]->linkedAttrDictStp != NULL)
    {
        entity->parDictIndex = dictEntityStp->attr[entity->parIndex]->linkedAttrDictStp->progN;
    }
    else
    {
        entity->parDictIndex = Null_Dynfld;
    }

    /*  FIH-REF7128-011024  Fill field iFilterIndex     */
    /* REF8844 - LJE - 030415 */
    if (entity->entityRef == EOp)
    {
        entity->iEditBackupIndex = ExtOp_EditBackupPtr;
    }
    else if (entity->entityRef == EStratElt)
    {
        entity->iEditBackupIndex = ExtStratElt_EditBackupPtr;
    }
    else if (entity->entityRef == StratElt)         /*  HFI-PMSTA-13470-120121  */
    {
        entity->iEditBackupIndex = A_StratElt_EditBackupPtr;
    }
    else if (entity->entityRef == UnMatchedExecution)
    {
        entity->iEditBackupIndex = A_UnMatchedExecution_EditBackupPtr;
    }
    else if (entity->entityRef == ExtTransaction)
    {
        entity->iEditBackupIndex = A_ExtTransaction_EditBackupPtr;
    }
    else if (entity->entityRef == CaseManagement)
    {
        entity->iEditBackupIndex = A_CaseManagement_EditBackupPtr;
    }
    else
    {
        entity->iEditBackupIndex = -1;
    }

#ifdef REF11314 /*  FPL-REF11314-060718 replace by function DBA_GetRightToRunIndex  */

    /*  FIH-REF7128-020530  Fill field iRightToRunIndex */
    /* REF8844 - LJE - 030415 */
    if (entity->entityRef == EPos )
    {
        entity->iRightToRunIndex = ExtPos_RightToRunFlg;
    }
    else if (entity->entityRef == EStratElt)
    {
        entity->iRightToRunIndex = ExtStratElt_RightToRunFlg;
    }
    else if (entity->entityRef == EOp )
    {
        entity->iRightToRunIndex = ExtOp_RightToRunFlg;
    }
    else if (entity->entityRef == ExtExecutionEnt )     /*  FIH-REF10433-040929 */
    {
        entity->iRightToRunIndex = A_ExtExecution_RightToRunFlg;
    }
    else
    {
        entity->iRightToRunIndex = -1;
    }

#endif
    entity->iRightToRunIndex = DBA_GetRightToRunIndex(entity->entityRef);   /*  FPL-REF11314-060718 */

    /*  FIH-REF7174-020722  Fill field iGroupingCriteriaIndex   */
    /* REF8844 - LJE - 030415 */
    if (entity->entityRef == EOp )
    {
        entity->iGroupingCriteriaIndex = ExtOp_GroupingCriteria;
    }
    else if (entity->entityRef == BuyOpEnt )
    {
        entity->iGroupingCriteriaIndex = BuyOp_GroupingCriteria;
    }
    else if (entity->entityRef == SellOpEnt)
    {
        entity->iGroupingCriteriaIndex = SellOp_GroupingCriteria;
    }
    else
    {
        entity->iGroupingCriteriaIndex = -1;
    }

    /*  FIH-REF7174-020722  Fill field iGroupingIndexIndex      */
    /* REF8844 - LJE - 030415 */
    if (entity->entityRef == EOp )
    {
        entity->iGroupingIndexIndex = ExtOp_OrderGroupingCd;
    }
    else if (entity->entityRef == BuyOpEnt )
    {
        entity->iGroupingIndexIndex = BuyOp_OrderGroupingCd;
    }
    else if (entity->entityRef == SellOpEnt)
    {
        entity->iGroupingIndexIndex = SellOp_OrderGroupingCd;
    }
    else
    {
        entity->iGroupingIndexIndex = -1;
    }

	/* PMSTA-37058 - Silpakal - 190903*/
	if (entity->entityRef == EOp)
	{
		entity->iSwitchingCriteriaIndex = ExtOp_SwitchingCriteria;
	}
	else
	{
		entity->iSwitchingCriteriaIndex = -1;
	}
    /* PMSTA - 38314 - adarsh - 27012020 */
    if (entity->entityRef == EOp)
    {
        entity->iNettingCriteriaIndex = ExtOp_NettingCriteria;
    }
    else
    {
        entity->iNettingCriteriaIndex = -1;
    }

    /* PMSTA-41770 - Vishnu -270920 : order sequencing*/
    if (entity->entityRef == EOp)
    {
        /*Linking to portfolio id since the script will return ptf cash balance */
        entity->iOrdeSeqCriteriaIndex= ExtOp_PtfId;
    }
    else
    {
        entity->iOrdeSeqCriteriaIndex = -1;
    }
   /* PMSTA-40208 - sanand - 24092020 */
    if (entity->entityRef == EOp)
    {
        entity->iHierarchyOrderGroupingCriteriaIndex = ExtOp_HierGroupingCriteria;
    }
    else if (entity->entityRef == BuyOpEnt)
    {
        entity->iHierarchyOrderGroupingCriteriaIndex = BuyOp_HierGroupingCriteria;
    }
    else if (entity->entityRef == SellOpEnt)
    {
        entity->iHierarchyOrderGroupingCriteriaIndex = SellOp_HierGroupingCriteria;
    }
    else
    {
        entity->iHierarchyOrderGroupingCriteriaIndex = -1;
    }

    /*  FIH-REF11457-051014 Fill field iSelectedFlagIndex       */
    if (entity->entityRef == EOp )
    {
        entity->iSelectedFlagIndex = ExtOp_SelectedFlg;
    }
    else if (entity->entityRef == EStratElt)
    {
        entity->iSelectedFlagIndex = ExtStratElt_SelectedFlg;
    }
    else if (entity->entityRef == ExtExecutionEnt)
    {
        entity->iSelectedFlagIndex = A_ExtExecution_SelectedFlg;
    }
    else
    {
        entity->iSelectedFlagIndex = -1;
    }

    /* MRA - 010212 - REF5435 */
    if ((entity->langDictId > 0) &&
        ((ret = DICT_GetLabel(entity->langDictId, 1101, DICTENT_DICTID(dictEntityStp), &theLabel, dbiConnHelper)) == RET_SUCCEED))
        strcpy(entity->label, theLabel);
    else
        strcpy(entity->label, DBA_GetDictEntityLabel(entity->entityRef,FALSE));

    /* REF9303 - LJE - 030912 */
    if ((entity->langDictId > 0) &&
        ((ret = DICT_GetUniLabel(entity->langDictId, 1101, DICTENT_DICTID(dictEntityStp), &theUniLabel, dbiConnHelper)) == RET_SUCCEED))
        u_strcpy(entity->uniLabel, theUniLabel);
    else
        u_strcpy(entity->uniLabel,dictEntityStp->uniLabelStr.getTerminatedBuffer()); /* PMSTA-34279 - 211218 - PMO / REF9303 - LJE - 030912 */

    /*  FIH-REF8683-030725  */
    strcpy(entity->pszSqlName, DBA_GetDictEntitySqlName(entity->entityRef));

    /* Test if entity is subtyped */
    entity->typingEn = DICTENT_TYPINGNAT(dictEntityStp);
    if ((DICTENT_TYPINGNAT(dictEntityStp) == SubTyping) ||
        (DICTENT_TYPINGNAT(dictEntityStp) == TypingNat_Parent))    /* FPL-REF7420-020715 */
    {
        entity->typingFlag = TRUE;
        if (entity->nature != NULL && entity->nature->value < 0)
        {
            MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,"DBA_GetDictEntityInfo", "nature");
            return(RET_GEN_ERR_INVARG);
        }
    }
    else
    {
        entity->typingFlag = FALSE;
    }

    ret = RET_SUCCEED;
    switch(entity->metaTypeEnum)    /* MRA - 001010 - REF5270 */
    {
        case ShortMeta :
            /*  ParIndex in Short may be <> from ParIndex in the All    */  /*  HFI-PMSTA-21828-151127  */
            if ((entity->parIndex > Null_Dynfld) &&
                (dictEntityStp->attr[entity->parIndex]->shortIdx > Null_Dynfld))
                entity->parIndex = dictEntityStp->attr[entity->parIndex]->shortIdx;
            else
                entity->parIndex = Null_Dynfld;

            /* Read table SV_DictCriterTab associated to the entity */
            totAttribNb = DICTENT_CRITERNBR(dictEntityStp);

            /* Add primary keys number to criteria attributes number, */
            /* if one attribute is an primary key and an criteria     */
            /* attribute these number will be modified.               */
            totAttribNb += entity->iUniqueKeyNb;                        /*  Replace keyNb by iUniqueKeyNb   HFI-PMSTA-21799-151115  */

            /* Fill informations for all attributes */
            /* primary keys and criteria fields     */
            if (totAttribNb != 0)
            {
                if ((pdictent =  DBA_GetDictEntitySt(entity->entityRef)) != NULL)                      /*  HFI-PMSTA-21799-151115  */
                ret = DBA_FillCriterTab(entity->entityRef,
                                        (SH_ATTRIB_INFO_STP *) &(entity->attribTab), totAttribNb,
                                            entity->iUniqueKeyNb,                       /*  Replace keyNb by iUniqueKeyNb   HFI-PMSTA-21799-151115  */
                                            DICTENT_UNIQUEATTRTAB(pdictent),            /*  Add unique attribute table      HFI-PMSTA-21799-151115  */
                                            &entity->attribNb, FALSE);
                else
                    ret = DBA_FillCriterTab(entity->entityRef,
                                            (SH_ATTRIB_INFO_STP *) &(entity->attribTab), totAttribNb,
                                            entity->iUniqueKeyNb,                       /*  Replace keyNb by iUniqueKeyNb   HFI-PMSTA-21799-151115  */
                                            NULL,                                       /*  Add unique attribute table      HFI-PMSTA-21799-151115  */
                                            &entity->attribNb, FALSE);
            }
            else
            {
                entity->attribTab = NULL;
                ret = RET_GEN_INFO_NODATA;
            }
            break;

        case AllMeta :
        case ScriptMeta :
        case QuickSearchMeta :
        case SearchMeta :
        case Meta_CopiedLogical:    /*  FIH-REF10967-050204 */
        case AllDynMeta : 	        /* DVP200 - RAK - 960925 */
        case Meta_Business :        /*  FIH-REF10766-041112 */
            /* Read table SV_DictENtityTab = attribute number */
            /* Determine return attribute number */
            entity->attribNb = 0;
            for (auto& dictAttribStp : dictEntityStp->attr)
            {
                ID_T value = entity->nature == NULL ? 0 : entity->nature->value;    /*  FPL-PMSTA08801-091008 longID from long    */

                if (DBA_ValidAttrib(entity->metaTypeEnum, dictEntityStp, dictAttribStp, entity->typingFlag, value) == TRUE)
                    ++entity->attribNb;
            }

            if (entity->attribNb != 0)
            {
                ret = DBA_FillAttribTab(entity->metaTypeEnum, entity, entity->langDictId);
            }
            else
            {
                entity->attribTab = NULL;
                ret = RET_GEN_INFO_NODATA;
            }

            /*  Suppress some nature according to the value of ApplParam USER_TYPE  */  /*  FIH-REF10778-041124 */
            if ((ret == RET_SUCCEED) &&
                (entity->metaTypeEnum == QuickSearchMeta) &&
                (DBA_GetTypingNat(entity->entityRef) != NoTyping) &&
                ((pdictent =  DBA_GetDictEntitySt(entity->entityRef)) != NULL) &&
                (pdictent->natIndex > 0) &&
                ((attribStp = FMT_AttribFromFldIdx ((ALL_ATTRIB_INFO_STP) entity->attribTab,
                                                    entity->attribNb,
                                                    pdictent->natIndex,
                                                    NULL)) != NULL))
            {
                attribStp->flagNature = TRUE;
                FMT_PermValTabFill (entity->entityRef,
                                    pdictent->natIndex,
                                    &(attribStp->permitedValuesNb),
                                    &(attribStp->permitedValuesTab),
                                    attribStp,                          /*  FPL-REF11796-060421 */
                                    FALSE,
                                    entity->fldValStp,
                                    GUI_RIGHT_ALL);
            }
            break;

        default:
            break;

    }

    return ret;
}



/************************************************************************
**  Function             : DBA_ValidAttrib()
**
**  Description          : Test if entity field must be display
**
**  Arguments            : metaTp     attribute list type
**                         entityRef  entity OBJECT_ENUM
**                         field      entity field
**                         typingFlag subtyped entity or not
**                         nature     current nature (if subtyped entity)
**
**  Return               : TRUE, FALSE
**
**  Modif                : DVP039 - RAK - 960426
**                         BUG042 - RAK - 960626
**                         REF5270 - MRA - 001013
**                         HFI-PMSTA-38538-201501   Replace DICTATTR_EDITMASK by CHECK_BITMASK(DICTATTR_EDITMASK()) for entity not managed by nature
**                         HFI-PMSTA-38117-200202   Replace DICTATTR_EDITMASK by DICTATTR_SUBTYPEMASK
**
*************************************************************************/
STATIC FLAG_T DBA_ValidAttrib(META_TYPE_ENUM metaTp,
                              DICT_ENTITY_STP dictEntityStp, /* PMSTA-26108 - LJE - 170920 */
                              DICT_ATTRIB_STP dictAttribStp, /* PMSTA-26108 - LJE - 170920 */
                              FLAG_T         typingFlag,
                              ID_T           nature)        /*  FPL-PMSTA08801-091008 longID from long    */
{
    FLAG_T      valid=FALSE;

    /* PMSTA07964 - LJE - 090317 */
    if (dictEntityStp == NULL)
        return FALSE;

    if (metaTp == ScriptMeta)
    {
        /* Display rank */
        if (DICTATTR_RANK(dictAttribStp) != 0 ||
            (dictEntityStp->updFctAuthEn == FeatureAuth_Enable && dictAttribStp->featureEn == XdEntityFeatureFeatureEn::UpdateFunction) /* PMSTA-22506 - DDV - 160422 - Add execption for rigth_to_run_f */ /* PMSTA-23385 - LJE - 160714 */
           )
            valid = TRUE;
    }
    else
    {
        /* --------------------------- */
        /* BEGIN DVP039 - RAK - 960426 */
        if (metaTp == Meta_CopiedLogical)       /*  FIH-REF10967-050204 */
        {
            /* Logical flag */
            if ((DICTATTR_LOGICFLG(dictAttribStp) == TRUE) &&
                (dictAttribStp->copyRightEn != DictAttrCopyNat_Denied))         /*  HFI-PMSTA-51477-2022-12-16  */
            {
                valid = DBA_ValidAttrib(AllMeta, dictEntityStp, dictAttribStp, typingFlag, nature);
            }
        }
        else
        /* END DVP039 - RAK - 960426 */
        /* ------------------------- */
        {
            /* No subtyping, control TRUE or FALSE */
            if (typingFlag == FALSE)
            {
                switch (metaTp)
                {
                    case Meta_Business :            /*  FIH-REF10766-041112 */
                        if (DICTATTR_BUSKFLG(dictAttribStp) == TRUE)
                            valid = TRUE;
                        break;

                    case AllMeta :
                        if (CHECK_BITMASK(DICTATTR_SUBTYPEMASK(dictAttribStp), 0) == TRUE)
                            valid = TRUE;
                        break;

                    case AllDynMeta :       /* MRA - 001013 - REF5270 */
                        if (DICTATTR_DICTID(dictAttribStp) > 0)
                            valid = TRUE;
                        break;

                    case QuickSearchMeta :
                        if (CHECK_BITMASK(DICTATTR_QUICKSEARCH(dictAttribStp), 0) == TRUE)
                            valid = TRUE;
                        break;

                    case SearchMeta :
                        if (CHECK_BITMASK(DICTATTR_SEARCH(dictAttribStp), 0) == TRUE)
                            valid = TRUE;
                        break;

                    default:
                        break;
                }
            }
            /* Subtyping, control bit a bit depending on nature */
            /* except if nature is a negativ value thats means  */
            /* all fields will be returned.                     */
            else
            {
                switch (metaTp)
                {
                    case Meta_Business :            /*  FIH-REF10766-041112 */
                        if (CHECK_BITMASK(DICTATTR_BUSKFLG(dictAttribStp), nature) == TRUE)
                            valid = TRUE;
                        break;

                    case AllMeta :
                        if (CHECK_BITMASK(DICTATTR_SUBTYPEMASK(dictAttribStp), nature) == TRUE)
                            valid = TRUE;
                        break;

                    case AllDynMeta :       /* MRA - 001013 - REF5270 */
                        if (DICTATTR_DICTID(dictAttribStp) > 0)
                            valid = TRUE;
                        break;

                    case QuickSearchMeta :
                        if (CHECK_BITMASK(DICTATTR_QUICKSEARCH(dictAttribStp), nature) == TRUE)
                            valid = TRUE;
                        break;

                    case SearchMeta :
                        if (CHECK_BITMASK(DICTATTR_SEARCH(dictAttribStp), nature) == TRUE)
                            valid = TRUE;
                        break;
                }
            }
        }
    }
    return(valid);
}

/************************************************************************
**  Function             : DBA_FillAttribTab()
**
**  Description          : Return all attributes for an entity
**                         For each attribute, fill struct ALL_ATTRIB_INFO_ST
**                         informations.
**
**  Arguments            :  metaTp
**                          entity         pointer on entity structure
**                          langDictId
**
**  Return               : RET_SUCCEED, RET_DBA_INFO_MD or error code
**
**  Modif                : BUG042 - RAK - 960626
**                         DVP200 - RAK - 960925
**                         MRA - 001123 - REF5435 Add langDictId in parameters
**                          HFI-PMSTA-43673-210303  Add filter to the package definition added logical attribute to avoid crash while using UDS
**
*************************************************************************/
STATIC RET_CODE DBA_FillAttribTab(META_TYPE_ENUM  metaTp, ENTITY_INFO_STP entity, DICT_T langDictId)
{
    ALL_ATTRIB_INFO_STP attribTab;
    OBJECT_ENUM         entityRef;
    DICT_T              dictId;
    TLS_CMPFCT          *cmpFct; /* REF7264 - LJE - 020205 */
    ID_T                nature; /*  FPL-PMSTA08801-091008 longID from long    */
    int                 i, k, totAttribNb, attribNb;
    char                typingFlag;
    RET_CODE            ret, retFin;
    DICT_ENTITY_STP		dictEntityStp = DBA_GetDictEntitySt(entity->entityRef);
    int                 iAddAttrForPackDef = 0;                 /*  HFI-PMSTA-43673-210303  */

    if (entity->entityRef > LASTENTITYOBJECT ||
        entity->entityRef == NullEntity      ||
        dictEntityStp     == NULL) /* PMSTA07964 - LJE - 090309 */  /*  FPL-PMSTA07964-090312 != -> ==  */
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
                 "DBA_FillAttribTab", "entityRef");
        return(RET_GEN_ERR_INVARG);
    }

    entityRef   = entity->entityRef;
    nature      = entity->nature == NULL ? 0 : entity->nature->value;
    typingFlag  = entity->typingFlag;
    totAttribNb = (int)dictEntityStp->attr.size();
    attribNb    = entity->attribNb;

    /*  Particular case to list package definition with a particular object in composition  */  /*  HFI-PMSTA-41842-200916  */
    if ((metaTp == AllMeta) &&
        (SYS_IsGuiMode() == TRUE) &&
        (dictEntityStp->enIsPackage ==   DictEntityClass::IsPackageEn::Record))
    {
        entity->attribNb++;
        iAddAttrForPackDef = 1;
    }
    if ((entity->attribTab = CALLOC(entity->attribNb, sizeof(ALL_ATTRIB_INFO_ST))) == NULL)
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    if ((entity->filterTab = (FILTER_STP)CALLOC(totAttribNb + iAddAttrForPackDef, sizeof(FILTER_ST))) == NULL)
    {
        FREE(entity->attribTab);
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    attribTab = (ALL_ATTRIB_INFO_STP) entity->attribTab;

    /* k is structures index, it is increase only
    ** when attribute must be returned */
    k = 0;
    retFin = RET_SUCCEED;
    for (auto& dictAttribStp : dictEntityStp->attr)
    {
        i = dictAttribStp->progN;

        if (entity->filterTab != NULL)                  /*  FIH-REF7587-020527  */
            entity->filterTab[i].oldValueEn = -1;       /*  FIH-REF3590-990426  */
        /* DPV200 */
        if (DBA_ValidAttrib(metaTp, dictEntityStp, dictAttribStp, typingFlag, nature) == TRUE)
        {
            if (entity->filterTab != NULL)                  /*  FIH-REF7587-020527  */
            {
                attribTab[k].filterStp = &(entity->filterTab[i]);
                entity->filterTab[i].attribStp = &(attribTab[k]);
            }
            attribTab[k].entity = NullEntity;

            ret = DBA_FillAttribInfo(entity, i, &(attribTab[k]), langDictId);

            if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                retFin = RET_DBA_INFO_MD;

            dictId = DICTATTR_REFENTDICTID(dictAttribStp);
            if (dictId != 0)
            {
                DBA_GetObjectEnum(dictId, &(attribTab[k].entityRef));   /*  FPL-PMSTA10200-100714 move here */
                DICT_ENTITY_STP	dictRefEntityStp = DBA_GetDictEntitySt(attribTab[k].entityRef);

                if (dictRefEntityStp != NULL) /* PMSTA07964 - LJE - 090317 */
                {
                    /*DBA_GetObjectEnum(dictId, &(attribTab[k].entityRef)); FPL-PMSTA10200-100714 move upper    */
                    if (attribTab[k].attribType == LogicalAttr)
                        attribTab[k].logRefFlag = ! DICTENT_LOGICALFLG(dictRefEntityStp);   /*  FPL-REF11698-060208 logRef to say "logical with ref in db" DICTENT_ENTITYFLG(attribTab[k].entityRef);  */
                    if ((metaTp == Meta_CopiedLogical) &&           /*  FIH-REF10967-050204 */
                         (attribTab[k].entityRef > 0))
                    {
                        attribTab[k].copyNature  = dictAttribStp->copyRightEn;
                    }
                }
            }
            else
                attribTab[k].entityRef = NullEntity;

            if (metaTp != QuickSearchMeta && metaTp != SearchMeta)
            {
                if ((attribTab[k].attribType != LogicalAttr) && dictId!=0)
                {
                    ret = DBA_FillFkStruct(&(attribTab[k]));

                    if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                        retFin = RET_DBA_INFO_MD;
                }
            }
            ++k;                            /* structure index */
        }
    }

    /*  Particular case to list package definition with a particular object in composition  */  /*  HFI-PMSTA-41842-200916  */
    if ((metaTp == AllMeta) &&
        (SYS_IsGuiMode() == TRUE) &&
        (dictEntityStp->enIsPackage ==   DictEntityClass::IsPackageEn::Record))
    {
        const char  *theLabel = NULL;
        const UChar *theUniLabel = NULL;
        DbiConnectionHelper         dbiConnHelper;

        attribTab[k].parent = entity;
        attribTab[k].rank = MAX_SHORT;
        attribTab[k].dataType  = IdType;
        attribTab[k].attribType = LogicalAttr;
        attribTab[k].copyNature = DictAttrCopyNat_NoCopy;
        attribTab[k].entityRef = PackageDefinition;
        strcpy(attribTab[k].sqlName,"package_definition");
        DICT_ENTITY_STP pdictent = DBA_GetDictEntitySt(PackageDefinition);
        if (((langDictId > 0) &&
            (ret = DICT_GetLabel(langDictId, DictEntity, pdictent->entDictId, &theLabel, dbiConnHelper)) == RET_SUCCEED))
        {
            strcpy(attribTab[k].label,   theLabel);
        }
        else
        {
            strcpy(attribTab[k].label, pdictent->labelStr.c_str());
        }
        if (((langDictId > 0) &&
            (ret = DICT_GetUniLabel(langDictId, DictEntity, pdictent->entDictId, &theUniLabel, dbiConnHelper)) == RET_SUCCEED))
        {
            u_strcpy(attribTab[k].uniLabel,   theUniLabel);
        }
        else
        {
            u_strcpy(attribTab[k].uniLabel, pdictent->uniLabelStr.getTerminatedBuffer());
        }

        if (entity->filterTab != NULL)
        {
            attribTab[k].filterStp = &(entity->filterTab[totAttribNb]);
            entity->filterTab[totAttribNb].attribStp = &(attribTab[k]);
        }
    }


    /* order by sqlname for script and by display rank for other type */
    if (metaTp == ScriptMeta)
        cmpFct = (TLS_CMPFCT *)DBA_CmpAttribSqlName; /* REF7264 - LJE - 020205 */
    else if (metaTp == QuickSearchMeta || metaTp == SearchMeta)
        cmpFct = (TLS_CMPFCT *)DBA_CmpAttribLabel; /* REF7264 - LJE - 020205 */
    else
        cmpFct = (TLS_CMPFCT *)DBA_CmpAttribDispRank; /* REF7264 - LJE - 020205 */

    if (TLS_Sort((char *) attribTab, attribNb, sizeof(ALL_ATTRIB_INFO_ST), cmpFct, NULL, SortRtnTp_None) == FALSE)
        retFin = RET_DBA_INFO_MD;

    /*  FIH-REFr049-991014  Cross refernec must be rebuild after sorting    */
    for (k=0; k<attribNb ; k++)
    {
        if (attribTab[k].filterStp != NULL)
            attribTab[k].filterStp->attribStp = &(attribTab[k]);
    }

    /*  FIH-REF10766-041116 */
    if (metaTp == Meta_Business)
    {
        for (k=0; k<attribNb ; k++)
            attribTab[k].editEnum = DictAttrib_EditNoEdit;
    }
    return(retFin);
}


/************************************************************************
**
**  Function            :   DBA_SetAttribEditEnum
**
**  Description         :   Set editEnum for given entity attribute
**
**  Arguments           :
**
**  Return              :
**
**	Creation            :  FPL-080610-PMSTA06647
**
**  Modification        :  PMSTA-15733 - 150113 - PMO : Chinese character Display problem in Operation screen from Order List
**
*************************************************************************/
RET_CODE DBA_SetAttribEditEnum ( ENTITY_INFO_STP        entity
                               , ALL_ATTRIB_INFO_STP    attribPtr
                               , int                    fld
                               )
{
    TEXT_CONVERSION_TYPE_ENUM   enTextConversion ;
    char                        *pszEnv;

    if ((SYS_IsGuiMode() == TRUE) &&        /*  FIH-REF9303-030909  Unicode datatype are not editable in GUI    */
        (((pszEnv = SYS_GetEnv("AAAEDITUNICODEINGUI")) == NULL) ||
         (strcmp(pszEnv,"TRUE") != 0)) &&
        (GEN_GetApplInfo(ApplTextConversionTypeEn,&enTextConversion) == TRUE) &&
        (enTextConversion == TextConversion_Iso8 || enTextConversion == TextConversion_None) && /* PMSTA-15733 - 150113 - PMO */
        ((GET_CTYPE(attribPtr->dataType ) == UniCharPtrCType) ||
         (GET_CTYPE(attribPtr->dataType ) == UniTextPtrCType)))
        attribPtr->editEnum  = DictAttrib_EditNoEdit;
    else
    {
        DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(entity->entityRef);
        if (dictEntityStp != NULL)
        {
            if (entity->typingFlag == FALSE)
            {
                attribPtr->editEnum  = DICTATTR_EDITEN(dictEntityStp->attr[fld]);
            }
            /*  Edition enum could be managed by nature             */      /*  HFI-PMSTA-38117-200202  */
            else
            {
                ID_T value = entity->nature == NULL ? 0 : entity->nature->value;
                if (CHECK_BITMASK(DICTATTR_EDITIONMASK(attribPtr->dictAttribStp), value) == TRUE)
                    attribPtr->editEnum  = DICTATTR_EDITEN(dictEntityStp->attr[fld]);
                else
                    attribPtr->editEnum  = DictAttrib_EditNoEdit;
            }
        }
        else
        {
            return RET_GEN_ERR_INVARG;
        }
    }

    return RET_SUCCEED ;
}


/************************************************************************
**  Function             : DBA_FillAttribInfo()
**
**  Description          : fill attribute generic information
**
**  Arguments            : entity         pointer on entity structure
**                         fld            entity field
**                         attribPtr      pointer on attribute structure
**                         langDictId
**
**  Return               : RET_SUCCEED or error code
**
**	Modif.				 : MRA - 000119 - REF4115
**  Modif.               : MRA - 001123 - REF5435   Add langDictId in parameters
**	Modif.				 : MRA - 010212 - REF5435
*************************************************************************/
STATIC RET_CODE DBA_FillAttribInfo(ENTITY_INFO_STP     entity,
                                   int                 fld,
                                   ALL_ATTRIB_INFO_STP attribPtr,
                                   DICT_T              langDictId)
{
    OBJECT_ENUM                 entityRef = entity->entityRef;
    DICT_T                      parEntDictId;
    RET_CODE                    ret;
    const char                  *theLabel = NULL;
    const UChar                 *theUniLabel = NULL;                /* REF9303 - LJE - 030912 */
    /*TEXT_CONVERSION_TYPE_ENUM   enTextConversion;                     FIH-REF9303-030909  */  /*  FPL-080610-PMSTA06647   */
    /*char                        *pszEnv;                              FIH-REF9303-031117  */  /*  FPL-080610-PMSTA06647   */
    OBJECT_ENUM                 parEntityRef;                       /*  FPL-PMSTA09887-101122   */
    DICT_ENTITY_STP             dictEntityStp = DBA_GetDictEntitySt(entityRef);
    DbiConnectionHelper         dbiConnHelper;

    if (dictEntityStp == NULL) /* PMSTA07964 - LJE - 090317 */
    {
        return RET_GEN_ERR_INVARG;
    }

    attribPtr->dictAttribStp = dictEntityStp->attr[fld];

    attribPtr->parent    = entity;
    attribPtr->dictId = DICTATTR_DICTID(attribPtr->dictAttribStp);
    attribPtr->rank = DICTATTR_RANK(attribPtr->dictAttribStp);
    attribPtr->dataType  = DICT_GetAttribDataType(entityRef, fld);

    DBA_SetAttribEditEnum(entity, attribPtr, fld);  /*  FPL-080610-PMSTA06647   */
    attribPtr->parDictId   = DICTATTR_PARATTRDICTID(attribPtr->dictAttribStp);
    attribPtr->parFldIdx   = DICTATTR_PARATTRPROGN(attribPtr->dictAttribStp);
    attribPtr->nature      = -1;
    attribPtr->flagVirtual = FALSE;                                 /*  FIH-REF7285-020110  */

    parEntDictId = DICTATTR_PARATTRENTDICTID(attribPtr->dictAttribStp);
    DBA_GetObjectEnum(parEntDictId, &(attribPtr->parEntRef));

    /* Update attribute type depending on flags */
    attribPtr->attribType = PhysicalAttr;
    if (DICTATTR_LOGICFLG(attribPtr->dictAttribStp) == TRUE)
        attribPtr->attribType = LogicalAttr;
    if (DICTATTR_CALC(attribPtr->dictAttribStp) == DictAttr_Calculated)
        attribPtr->attribType = CalculatedAttr;
    else if (DICTATTR_CALC(attribPtr->dictAttribStp) == DictAttr_Denorm)      /* OCS-43152 - LJE - 130620 */
        attribPtr->attribType = DenormAttr;
    else if (DICTATTR_CALC(attribPtr->dictAttribStp) == DictAttr_Virtual)     /*  FIH-REF4989-000707  */
    {
        attribPtr->attribType = VirtualAttr;
        attribPtr->flagVirtual = TRUE;                              /*  FIH-REF7285-020110  */
    }
    if (DICTATTR_CUSTFLG(attribPtr->dictAttribStp) == TRUE)
        attribPtr->attribType = CustomAttr;

    strcpy(attribPtr->sqlName, DICTATTR_SQLNAME(attribPtr->dictAttribStp));

    /*  FPL-PMSTA09887-101122   */
    parEntityRef                  = entityRef ;
    if (entity->fldValStp != NULL)
        parEntityRef = entity->fldValStp->parDictRef ;
    attribPtr->maxDbLenN          = DBA_GetDynMaxDbLen(entityRef, fld, parEntityRef);
    attribPtr->defaultDisplayLenN = DBA_GetDynDefDispLen(entityRef, fld, parEntityRef);

    /* MRA - 010212 - REF5435 */
    if (((langDictId > 0) &&
        (ret = DICT_GetLabel(langDictId, 1103, attribPtr->dictId, &theLabel, dbiConnHelper)) == RET_SUCCEED)
       )
        strcpy(attribPtr->label,   theLabel);
    else
        strcpy(attribPtr->label, DICTATTR_LABEL(attribPtr->dictAttribStp));

    /* PMSTA-44466 - DDV - 210324 - Allow # only in synonym's code */
    if (attribPtr->dictAttribStp != nullptr && attribPtr->dictAttribStp->dictEntityStp != nullptr &&
        attribPtr->dictAttribStp->dictEntityStp->objectEn == Synon &&
        strcmp(attribPtr->dictAttribStp->sqlName, "code") == 0)
    {
        attribPtr->bIsSynonymCode = TRUE;
    }
    else
    {
        attribPtr->bIsSynonymCode = FALSE;
    }
    attribPtr->codifId = 0;

    /* REF9303 - LJE - 030912 */
    if (((langDictId > 0) &&
         (ret = DICT_GetUniLabel(langDictId, 1103, attribPtr->dictId, &theUniLabel, dbiConnHelper)) == RET_SUCCEED)
        )
    {
        u_strcpy(attribPtr->uniLabel, theUniLabel);
    }
    else
    {
        u_strcpy(attribPtr->uniLabel, DICTATTR_UNILABEL(attribPtr->dictAttribStp));
    }

    attribPtr->mandatoryFlag = DICTATTR_MANDAFLG(attribPtr->dictAttribStp);
    attribPtr->primaryFlag = DICTATTR_PRIMAFLG(attribPtr->dictAttribStp);
    attribPtr->viskeyFlag = DICTATTR_BUSKFLG(attribPtr->dictAttribStp);
    attribPtr->structFieldIndex = DICTATTR_PROGN(attribPtr->dictAttribStp);


    /*  Manage Link between dim and obj attributes      */  /*  FIH-REF11457-051005 */
    attribPtr->iDimIndex = DICTATTR_DIMINDEX(attribPtr->dictAttribStp);
    attribPtr->iObjIndex = DICTATTR_OBJINDEX(attribPtr->dictAttribStp);
    attribPtr->enDefListObject = DICTATTR_DEFLISTOBJECT(attribPtr->dictAttribStp);

    /* Store entity object enum, 0 = null entity in metadictionary */
    attribPtr->fkStruct = NULL;

    /* List of values */
    attribPtr->permitedDefIndex = 0;
    ret = DBA_FillPermValTab(entityRef,
                             fld,
                             &(attribPtr->permitedValuesTab),
                             &(attribPtr->permitedValuesNb),
                             langDictId);

    /* MRA - 000119 - REF4115 */
    attribPtr->wgtType = DICTATTR_WGTEN(attribPtr->dictAttribStp);

    return(ret);
}

/************************************************************************
*
*  Function          : DBA_EnumAdd()     Script : ENUMADD() and STATUSADD()
*
*  Description       :
*
*  Arguments         : dictattr     : dict attribute
*                      curEnum      : the value of enum from where we want to start
*                      incr         : the increment (+/-)
*
*
*  Return            : RET_SUCCEED
*
*  Creation date     : FPL-REF10174-050228
*  Modification      :  HFI-PMSTA-37732-191030  rewrite function to avoid direct access in Map permVal
*
*************************************************************************/
RET_CODE DBA_EnumAdd ( DICT_ATTRIB_STP  pdictattr
                     , double           curVal
                     , double           incr
                     , double           *newVal
                     , double           *badVal
                     )
{
    FIELD_IDX_T             enumPos = 0;
    FLAG_T                  bFound = FALSE ;

    /* Check mandatory elements */
    if ((curVal < 0) ||
        (pdictattr == NULL) ||
        (pdictattr->permValMap.empty()))
    {
        return RET_GEN_ERR_INVARG ;
    }

    /*  initialization          */
    *newVal = -1 ;

    /*  search for current enum */
    for (auto it = pdictattr->permValMap.begin(); it != pdictattr->permValMap.end() && bFound == FALSE; ++it)
    {
        if (it->second.permVal == curVal)
        {
            bFound = TRUE;
        }
        else
        {
            enumPos++;
        }
    }

    /*  get the permval with increment  */
    if (bFound == TRUE)
    {
        enumPos = (FIELD_IDX_T)(enumPos + incr);
        if ((enumPos < 0) ||
            (enumPos >= (FIELD_IDX_T)pdictattr->permValMap.size()))
        {
            *badVal = enumPos ;     /*  return this value for error message in log */
            return RET_GUI_ERR_INVALID_PERMVAL_POS;
        }
        else
        {
            FIELD_IDX_T iCpt = 0;
            for (auto it = pdictattr->permValMap.begin(); it != pdictattr->permValMap.end() && (*newVal == -1); ++it, iCpt++)
            {
                if (iCpt == enumPos)
                    *newVal = it->second.permVal;
            }
        }
    }
    else
    {
        *badVal = curVal ;          /*  return this value for error message in log */
        return RET_GUI_ERR_INVALID_PERMVAL ;
    }
    return RET_SUCCEED;
}

/************************************************************************
*   Function             : DBA_CmpAttribDispRank()
*
*   Description          : Sort attribute list by display rank.
*                          Function call by TLS_Sort(), 1 level
*
*   Arguments            : ptr1      pointer or first structure to compare
*                          ptr2      pointer or second structure to compare
*
*   Return               : difference between two ranks.
*                          negative value if first element < second element
*                          null value     if first element = second element
*                          positive value if first element > second element
*
*
*************************************************************************/
STATIC int DBA_CmpAttribDispRank(ALL_ATTRIB_INFO_STP ptr1,
                 ALL_ATTRIB_INFO_STP ptr2)
{
    int	val;

    val = (int) (ptr1->rank - ptr2->rank);
    if (val == 0)
      val = (int) strcmp(ptr1->sqlName, ptr2->sqlName);

    return val;
}

/************************************************************************
*   Function             : DBA_CmpAttribTab()
*
*   Description          : Sort a list of pointers on attribute by entity, sqlName.
*                          Function called by TLS_Sort(), 1 level
*
*   Arguments            : ptr1      pointer or first structure to compare
*                          ptr2      pointer or second structure to compare
*
*   Return               : difference between two ranks.
*                          negative value if first element < second element
*                          null value     if first element = second element
*                          positive value if first element > second element
*
*
*************************************************************************/
int DBA_CmpAttribTab(const void *ptr1, const void *ptr2)
{
    const DICT_ATTRIB_STP *dictPtr1 = (const DICT_ATTRIB_STP*) ptr1;
    const DICT_ATTRIB_STP *dictPtr2 = (const DICT_ATTRIB_STP*) ptr2;

    DICT_ATTRIB_STP dictattr1 = *dictPtr1;
    DICT_ATTRIB_STP dictattr2 = *dictPtr2;

    return ((int) strcmp(dictattr1->sqlName,dictattr2->sqlName));
}

/************************************************************************
*   Function             : DBA_CmpAttribLabel()
*
*   Description          : Sort attribute list by label.
*                          Function call by TLS_Sort(), 1 level
*
*   Arguments            : ptr1      pointer or first structure to compare
*                          ptr2      pointer or second structure to compare
*
*   Return               : difference between two ranks.
*                          negative value if first element < second element
*                          null value     if first element = second element
*                          positive value if first element > second element
*
*
*************************************************************************/
STATIC int DBA_CmpAttribLabel(ALL_ATTRIB_INFO_STP ptr1,
                              ALL_ATTRIB_INFO_STP ptr2)
{
    return((int)strcmp(ptr1->label, ptr2->label));
}

/************************************************************************
*   Function             : DBA_CmpAttribSqlName()
*
*   Description          : Sort attribute list by sqlname.
*                          Function call by TLS_Sort(), 1 level
*
*   Arguments            : ptr1      pointer or first structure to compare
*                          ptr2      pointer or second structure to compare
*
*   Return               : difference between two ranks.
*                          negative value if first element < second element
*                          null value     if first element = second element
*                          positive value if first element > second element
*
*
*************************************************************************/
STATIC int DBA_CmpAttribSqlName(ALL_ATTRIB_INFO_STP ptr1,
                        ALL_ATTRIB_INFO_STP ptr2)
{
    return((int)strcmp(ptr1->sqlName, ptr2->sqlName));
}

/************************************************************************
*   Function             : DBA_CmpEntList()
*
*   Description          : Sort entities list by label.
*                          Function call by TLS_Sort(), 1 level
*
*   Arguments            : ptr1      pointer or first structure to compare
*                          ptr2      pointer or second structure to compare
*
*   Return               : difference between two ranks.
*                          negative value if first element < second element
*                          null value     if first element = second element
*                          positive value if first element > second element
*
*   Modif                :  HFI-PMSTA-12110-110606  remove STATIC
*
*
*************************************************************************/
int DBA_CmpEntList(VSH_ENTITY_INFO_STP ptr1, VSH_ENTITY_INFO_STP ptr2)
{
    return((int)strcmp(ptr1->label, ptr2->label));
}

/************************************************************************
*   Function             : DBA_GetShortSqlDyn()
*
*   Description          : Get short description for sql dynamic script
*
*   Arguments            : entity     : entity object enum
*                          alias      : alias for sql script
*                          synFlg     : Special case if synonym in script
*                          sameSynFlg : Special case if synonym in script with same codification for search and display  - REF9517 - DDV - 040219
*
*   Return               : The script
*
*   Modif                : PMSTA-20159 - TEB - 150624
*
*************************************************************************/
void DBA_GetShortSqlDyn(std::stringstream &shortFieldsStream, OBJECT_ENUM entity, const char *alias, FLAG_T synFlg, FLAG_T sameSynFlg)
{
    std::string       sep;

    DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(entity);

    for (auto citerIt = dictEntityStp->shortDictCriteriaMap.begin(); citerIt != dictEntityStp->shortDictCriteriaMap.end(); ++citerIt)
    {
        if (citerIt->second->index >= 0) /* PMSTA-30645 - LJE - 180412 */
        {
            if (citerIt != dictEntityStp->shortDictCriteriaMap.begin())
            {
                shortFieldsStream << ", ";
            }

            if (citerIt->second->entAttrPtr == nullptr)
            {
                shortFieldsStream << "NULL " << " as " << citerIt->second->sqlName;
            }
            else if (citerIt->second->entAttrPtr->calcEn != DictAttr_Virtual &&
                     citerIt->second->entAttrPtr->calcEn != DictAttr_NoMD)
            {
                if (synFlg == FALSE || strcmp("code", citerIt->second->sqlName) != 0)
                {
                    shortFieldsStream << alias << "." << citerIt->second->sqlName;
                }
                else
                {
                    /* REF9517 - DDV - 040220 - If search and display codif are the same use only sy2 and not sy */
                    if (sameSynFlg == TRUE)
                    {
                        shortFieldsStream << "sy2." << citerIt->second->sqlName;
                    }
                    else
                    {
                        shortFieldsStream
                            << "#ISNULL(sy." << citerIt->second->sqlName << ", "
                            << alias << "." << citerIt->second->sqlName << ")";
                    }
                }
                shortFieldsStream << " as " << citerIt->second->sqlName;
            }
        }
    }
}

/************************************************************************
*   Function             : DBA_FillFkStruct()
*
*   Description          : Construct foreign key attributes list.
*
*   Arguments            : fkAttribPtr   foreign key attribute pointer
*
*   Return               : RET_SUCCEED, RET_DBA_ERR_MD or error other code
*************************************************************************/
RET_CODE DBA_FillFkStruct(ALL_ATTRIB_INFO_STP fkAttribPtr)
{
    int             fkAttribNb;
    DICT_ENTITY_STP refDictEntityStp;
    RET_CODE        retCode;                /*  HFI-PMSTA-14944-120907  */
    OBJECT_ENUM     fkEntityRef;

    /* OCS-43062 - LJE - 131011 */
    if (fkAttribPtr->dictAttribStp != NULL &&
        fkAttribPtr->dictAttribStp->logicalFkFlg == TRUE)
    {
        fkEntityRef = fkAttribPtr->parent->entityRef;
    }
    else
    {
        fkEntityRef = fkAttribPtr->entityRef;
    }
    refDictEntityStp = DBA_GetDictEntitySt(fkEntityRef);

    if (fkAttribPtr->entityRef > LASTENTITYOBJECT ||
        fkAttribPtr->entityRef == NullEntity      ||
        refDictEntityStp       == NULL) /* PMSTA07964 - LJE - 090309 */ /*  FPL-PMSTA07964-090312 != -> ==  */
    {
        DICT_ENTITY_STP dictEntityStp;

        /*  Particular case : virtual entity for initiate order in server   FIH-REF11818-060522 */
        if ((fkAttribPtr->parent != NULL) &&
            (dictEntityStp = DBA_GetDictEntitySt(fkAttribPtr->parent->entityRef)) != NULL &&
            (DICTENT_VIRTUALFLG(dictEntityStp) == TRUE) &&
            (DICTENT_VALIDENT(dictEntityStp) == TRUE))
            return RET_SUCCEED;
        else
        {
            MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_FillFkStruct", "entityRef");
            return(RET_GEN_ERR_INVARG);
        }
    }

    if ((fkAttribPtr->fkStruct = (ENTITY_INFO_STP) CALLOC(1, sizeof(ENTITY_INFO_ST))) == NULL)
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    fkAttribPtr->fkStruct->entityRef = fkEntityRef;
    fkAttribPtr->fkStruct->structEnum = GET_ADMINGUIST(fkAttribPtr->fkStruct->entityRef);

    fkAttribPtr->fkStruct->synonFlag = DICTENT_SYNONFLG(refDictEntityStp);
    fkAttribPtr->fkStruct->parent = fkAttribPtr;            /*  FIH-REF10766-041116 */

    fkAttribPtr->fkStruct->activeFlg = DICTENT_ACTIVEFLAG(refDictEntityStp);  /*  FPL-REF11444-050923 */

    /* Read table SV_DictCriterTab associated to the entity */
    fkAttribNb = DICTENT_CRITERNBR(refDictEntityStp);

    /* Compute primary keys number */
    fkAttribPtr->fkStruct->iUniqueKeyNb = DICTENT_UNIQUEKNBR(refDictEntityStp);                /*  Replace DICTENT_PRIMKNBR by DICTENT_UNIQUEKNBR  HFI-PMSTA-21799-151115  */

    /* FIH-REFXXX-971104  Compute qick search flag */
    fkAttribPtr->fkStruct->qSearchFlag = DICTENT_QUICKSEARCH(refDictEntityStp);

    /* Compute visual keys number */
    fkAttribPtr->fkStruct->visKeyNb = DICTENT_VISKNBR(refDictEntityStp);

    /*  FIH-REF7471-020705  manage maintFlag and fill field fldIdxSt    */
    fkAttribPtr->fkStruct->mainEntFlag = DBA_GetGuiMainEntFlag(fkAttribPtr->fkStruct->entityRef);

    /* Add primary keys number to criteria attributes number, if one */
    /* attribute is an primary key and an criteria attribute these   */
    /* number will be modified                                       */
    fkAttribNb += fkAttribPtr->fkStruct->iUniqueKeyNb;                                      /*  Replace keyNb by iUniqueKeyNb   HFI-PMSTA-21799-151115  */

    /* Fill informations for all attributes */
    /* (primary keys and criteria fields)   */
    if (fkAttribNb != 0)
    {
        retCode = DBA_FillCriterTab(fkAttribPtr->fkStruct->entityRef,
                                    (SH_ATTRIB_INFO_STP*)&(fkAttribPtr->fkStruct->attribTab),
                                    fkAttribNb,
                                    fkAttribPtr->fkStruct->iUniqueKeyNb,                    /*  Replace keyNb by iUniqueKeyNb   HFI-PMSTA-21799-151115  */
                                    DICTENT_UNIQUEATTRTAB(refDictEntityStp),                /*  Add unique attribute table      HFI-PMSTA-21799-151115  */
                                    &fkAttribPtr->fkStruct->attribNb, TRUE);
    }
    else
    {
        fkAttribPtr->fkStruct->attribTab = NULL;
        MSG_SendMesg(RET_DBA_ERR_MD, 1, FILEINFO,
                     fkAttribPtr->entityRef, fkAttribPtr->structFieldIndex);
        retCode = RET_DBA_ERR_MD;
    }

    /*  Call moved after the generation of the attribute table      */  /*  HFI-PMSTA-14944-120907  */
    FMT_DynStpShFldIdx(fkAttribPtr->fkStruct);

    return retCode;
}

/************************************************************************
*   Function             : DBA_FillCriterTab()
*
*   Description          : Construct criteria attributes list for an entity.
*
*   Arguments            : entityRef     entity object enum
*                          shTbPtr       pointer on array pointer
*                                        allocate and fill
*                          attribNb      attributes number (primary + criteria)
*                          primKeyNb     primary key number
*                          shortAttribNb final attribute number to update
*                          fkFlag	 tab used for forign keys
*
*   Functions call       : None
*
*   Global var. modified : None
*
* 13 september : dans la table criteria se trouvent les clefs visuels
* (repr�sentant les id d'autres tables), des colonnes seront rajout�es
* pour expliquer que telle clefs visuels corresponds � tel clef primaire.
*
**  Return	: RET_SUCCEED or error code
**
**  Modif.	:   ROI - 961216 - BUG228
**  Modif.	:   ROI - 970407 - DVP414
**  Modif.	:   ROI - 000322 - REF4497
**  Modif.  :   FPL-REF10500-040729     No more static function
**              PMSTA-13761 - 240212 - PMO : GUI crash in Order Entry when saving a session using an active subscription
**          :   HFI-PMSTA-21799-151115  Add uniqueKeyTab
**          :   HFI-PMSTA-54117-2023-08-08  Clean sqlName management
**
*************************************************************************/
RET_CODE DBA_FillCriterTab(OBJECT_ENUM           entityRef,
                           SH_ATTRIB_INFO_STP    *shTbPtr,
                           int                   attribNb,
                           int                   uniqueKeyNb,                /*  Rename primKeyNb uniqueKeyNb    HFI-PMSTA-21799-151115  */
                           DICT_ATTRIB_STP       *uniqueKeyTab,              /*  Manage provided unique key tab  HFI-PMSTA-21799-151115  */
                           int                   *shortAttribNb,
                           FLAG_T                fkFlag)
{
    int                 j, k, visKeyNbr;
    char                flg;
    int                 iNbShortIndexAttr;      /*  FIH-REF8691-030210  Number of attribute with short index >0 */
    SH_ATTRIB_INFO_STP  pshortattr;             /*  FIH-REF8691-030210  New short attribute table               */
    DICT_ENTITY_STP     dictEntityStp = DBA_GetDictEntitySt(entityRef); /* PMSTA07964 - LJE - 090309 */
    INT_T               progN;                 /*  FPL-PMSTA09887-110117   / PMSTA-13761 - 240212 - PMO */
    OBJECT_ENUM         objectEnum;            /*  FPL-PMSTA09887-110119   */
    int                 s;                      /*  Loop variable           */  /*  HFI-PMSTA-12393-110721  */
    FLAG_T              foundFlg;
    FLAG_T              fkStructFlag = fkFlag;


    if (entityRef > LASTENTITYOBJECT ||
        entityRef == NullEntity ||
        dictEntityStp == NULL) /* PMSTA07964 - LJE - 090309 */
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
                     "DBA_FillCriterTab", "entityRef");
        return(RET_GEN_ERR_INVARG);
    }

    /* allocate memory */
    if ((*shTbPtr = (SH_ATTRIB_INFO_STP)CALLOC(attribNb, sizeof(SH_ATTRIB_INFO_ST))) == NULL)
        MSG_RETURN(RET_MEM_ERR_ALLOC);

    *shortAttribNb = attribNb;
    visKeyNbr = DICTENT_VISKNBR(dictEntityStp);

    /* Check criteria attributes with not null fkRank in criteria */
    if (fkFlag == TRUE)
    {
        fkFlag = FALSE;
        auto criteriaIt = dictEntityStp->criterMap.begin();
        while (criteriaIt != dictEntityStp->criterMap.end() && fkFlag == FALSE)
        {
            if (criteriaIt->second->isNullFkIndex == false) /* PMSTA-14452 - LJE - 130213 */
                fkFlag = TRUE;
            else
                ++criteriaIt;
        }
    }

    /* Read entity attributes table for primary keys */
    s = 0;                                                          /*  HFI-PMSTA-11298-110125  New index           */
    if (uniqueKeyTab != NULL)                                       /*  Manage provided unique key tab  HFI-PMSTA-21799-151115  */
    {
        for (auto attribIt = dictEntityStp->attr.begin(); attribIt != dictEntityStp->attr.end() && s < uniqueKeyNb; ++attribIt)
        {
            int i = (*attribIt)->progN;

            /* primary keys aren't display and are technical arguments */
            (*shTbPtr)[s].techFlag = TRUE;
            (*shTbPtr)[s].displayRank = 0;
            (*shTbPtr)[s].flagPrimaryKey = uniqueKeyTab[i]->primFlg;

            /* keyIndex : index in dynamic structure Get_Arg */
            (*shTbPtr)[s].keyIndex = uniqueKeyTab[i]->progPkN;

            /* structFieldIndex : index in short dynamic structure
            ** primary keys are at begin of short dynamic structure */
            if (uniqueKeyTab[i]->isNullShortIdx == false)
                (*shTbPtr)[s].structFieldIndex = uniqueKeyTab[i]->shortIdx;
            else
                (*shTbPtr)[s].structFieldIndex = uniqueKeyTab[i]->progN;

            (*shTbPtr)[s].rank = (short)s;

            (*shTbPtr)[s].dataType = uniqueKeyTab[i]->dataTpProgN;                      /*  HFI-PMSTA-22599-160411  */
            strcpy((*shTbPtr)[s].label, uniqueKeyTab[i]->GET_daLabel());                /*  HFI-PMSTA-22599-160411  */
            u_strcpy((*shTbPtr)[s].uniLabel, uniqueKeyTab[i]->GET_daUniLabel());        /*  HFI-PMSTA-22599-160411  */
            strcpy((*shTbPtr)[s].sqlName, uniqueKeyTab[i]->sqlName);

            /* Update for test if criteria field is a primary key */
            (*shTbPtr)[s].progN = uniqueKeyTab[i]->progN;
            (*shTbPtr)[s].refNo = uniqueKeyTab[i]->entDictId;

            (*shTbPtr)[s].attrDictId = uniqueKeyTab[i]->attrDictId;
            DBA_GetObjectEnum(uniqueKeyTab[i]->refEntDictId, &(*shTbPtr)[s].entityRef);

            (*shTbPtr)[s].maxDbLenN          = DBA_GetDynMaxDbLen(entityRef, (*shTbPtr)[s].progN, (*shTbPtr)[s].entityRef);
            (*shTbPtr)[s].defaultDisplayLenN = DBA_GetDynDefDispLen(entityRef, (*shTbPtr)[s].progN, (*shTbPtr)[s].entityRef);

            s++;
        }
    }
    else
    {
        for (auto attribIt = dictEntityStp->attr.begin(); attribIt != dictEntityStp->attr.end() && s < uniqueKeyNb; ++attribIt)
        {
            int i = (*attribIt)->progN;
            DICT_ATTRIB_STP dictAttribStp = (*attribIt);

            if (DICTATTR_PRIMAFLG(dictAttribStp) == TRUE)            /*  HFI-PMSTA-11298-110125  Only primary key    */
            {
                /* primary keys aren't display and are technical arguments */
                (*shTbPtr)[s].techFlag = TRUE;
                (*shTbPtr)[s].displayRank = 0;
                (*shTbPtr)[s].flagPrimaryKey = TRUE;

                /* keyIndex : index in dynamic structure Get_Arg */
                (*shTbPtr)[s].keyIndex = DICTATTR_PROGPKN(dictAttribStp);

                /* structFieldIndex : index in short dynamic structure
                ** primary keys are at begin of short dynamic structure */
                if (DICTATTR_ISNULLSHORTIDX(dictAttribStp) == false) /* PMSTA-12391 - LJE - 110915 */
                    (*shTbPtr)[s].structFieldIndex = DICTATTR_SHORTIDX(dictAttribStp); /* REF8844 - LJE - 030409 */
                else
                    (*shTbPtr)[s].structFieldIndex = DICTATTR_PROGN(dictAttribStp); /* REF8844 - LJE - 030409 */

                /* ?? */ (*shTbPtr)[s].rank = (short)s;

                (*shTbPtr)[s].dataType = DICT_GetAttribDataType(entityRef, i);
                strcpy((*shTbPtr)[s].label, DICTATTR_LABEL(dictAttribStp));
                u_strcpy((*shTbPtr)[s].uniLabel, DICTATTR_UNILABEL(dictAttribStp)); /* REF9303 - LJE - 030912 */
                strcpy((*shTbPtr)[s].sqlName, dictAttribStp->sqlName);

                /* Update for test if criteria field is a primary key */
                (*shTbPtr)[s].progN = DICTATTR_PROGN(dictAttribStp);
                (*shTbPtr)[s].refNo = DICTATTR_ENTDICTID(dictAttribStp);

                /*  FPL-PMSTA09887-110119   */
                (*shTbPtr)[s].maxDbLenN          = DBA_GetDynMaxDbLen(entityRef, (*shTbPtr)[s].progN, (*shTbPtr)[s].entityRef);
                (*shTbPtr)[s].defaultDisplayLenN = DBA_GetDynDefDispLen(entityRef, (*shTbPtr)[s].progN, (*shTbPtr)[s].entityRef);

                /*  FIH-REF2598-981015
                if ((SV_DictEntityTab[entityRef].criter != NULL) &&
                (SV_DictEntityTab[entityRef].criter[s].attrPtr != NULL))
                (*shTbPtr)[s].attrDictId = SV_DictEntityTab[entityRef].criter[s].attrPtr->attrDictId; */

                /* Corrig� par ROI - 00328 - REF4497 */
                (*shTbPtr)[s].attrDictId = DICTATTR_DICTID(dictAttribStp);
                DBA_GetObjectEnum(DICTATTR_REFENTDICTID(dictAttribStp), &(*shTbPtr)[s].entityRef);     /*  FIH-REF9867-040122  */

                s++;                                                    /*  HFI-PMSTA-11298-110125  Index calculation   */
            }
        }
    }

    /* Read table SV_DictCriterTab associated to the entity */
    j = s;
    for (auto criteriaIt = dictEntityStp->criterMap.begin(); criteriaIt != dictEntityStp->criterMap.end(); ++criteriaIt) /* PMSTA-11505 - LJE - 110630 */ /* PMSTA-28916 - LJE - 171215 */
    {
        /*  FIH-REF2598-981015  */
        if ((criteriaIt->second->attrPtr != NULL))
            (*shTbPtr)[j].attrDictId = criteriaIt->second->attrPtr->attrDictId;

        /*  HFI-PMSTA-11298-110125  New test: old test was lucky lucky  */
        /* Don't compute two times primary key */
        if ((criteriaIt->second->attrPtr == NULL) ||
            (criteriaIt->second->attrPtr->entDictId != dictEntityStp->entDictId) ||
            (criteriaIt->second->attrPtr->primFlg == FALSE))
        {
            /* criteria fields are display and aren't
            ** technical fields, compute visual fields nbr */
            (*shTbPtr)[j].techFlag = FALSE;
            if (fkFlag == TRUE)
                (*shTbPtr)[j].displayRank = criteriaIt->second->fkIndex;
            else
                (*shTbPtr)[j].displayRank = criteriaIt->first + 1;

            if ((visKeyNbr > 0) &&
                (DICTCRIT_DICTID(criteriaIt->second) == DICTENT_DICTID(dictEntityStp)) &&
                (DICTCRIT_BUSKFLG(criteriaIt->second) == TRUE)
                )
            {
                (*shTbPtr)[j].viskeyFlag = TRUE;
                --visKeyNbr;
            }

            /* keyIndex : index in dynamic structure Get_Arg */
            (*shTbPtr)[j].keyIndex = DICTCRIT_PROGPKN(criteriaIt->second);

            /* structFieldIndex : idx in short dynamic struct */
            (*shTbPtr)[j].structFieldIndex = DICTCRIT_PROGN(criteriaIt->second);

            /* ?? */ (*shTbPtr)[j].rank = DICTCRIT_PROGN(criteriaIt->second);

            /*  FPL-PMSTA09887-101122   */
            objectEnum = NullEntity;
            DBA_GetObjectEnum(DICTCRIT_DICTID(criteriaIt->second), &objectEnum);
            if (objectEnum > InvalidEntity)
            {
                /*  FPL-PMSTA09887-110330 we can have a dict_criteria on an other entity (ex:appl_msg_text) */
                progN = (*shTbPtr)[j].structFieldIndex;
                /*if (objectEnum != entityRef)  FPL-PMSTA10558-110701 do it in all cases to get the All prog_n
                {*/
                DICT_GetAttribInfo(objectEnum
                                   , -1
                                   , (*shTbPtr)[j].attrDictId
                                   , NULL
                                   , A_DictAttr_Prog
                                   , &progN
                                   );

                /*}*/
                (*shTbPtr)[j].maxDbLenN          = DBA_GetDynMaxDbLen(objectEnum, progN, (*shTbPtr)[j].entityRef);
                (*shTbPtr)[j].defaultDisplayLenN = DBA_GetDynDefDispLen(objectEnum, progN, (*shTbPtr)[j].entityRef);
            }

            (*shTbPtr)[j].dataType = DICTCRIT_DATATYPE(criteriaIt->second);
            strcpy((*shTbPtr)[j].label, DICTCRIT_LABEL(criteriaIt->second));
            u_strcpy((*shTbPtr)[j].uniLabel, DICTCRIT_UNILABEL(criteriaIt->second)); /* REF9303 - LJE - 030912 */
            strcpy((*shTbPtr)[j].sqlName, criteriaIt->second->sqlName);

            (*shTbPtr)[j].criteriaPtr = criteriaIt->second; /* OCS41141 - DDV - 120830 - Link criteria to short attribute */

            j++;
        }
        else
        {
            /* One primary key must be display, search which */
            k = 0;
            flg = FALSE;
            while (k < uniqueKeyNb && flg == FALSE)
            {
                if ((DICTCRIT_ATTRPROGN(criteriaIt->second) == (*shTbPtr)[k].progN) &&
                    (DICTCRIT_DICTID(criteriaIt->second) == (*shTbPtr)[k].refNo))
                    flg = TRUE;
                else
                    k++;
            }

            /* Modify short attribute number and display the primary key */
            if (flg == TRUE)
            {
                --(*shortAttribNb);
                if (fkFlag == TRUE)
                    (*shTbPtr)[j].displayRank = criteriaIt->second->fkIndex;
                else
                    (*shTbPtr)[k].displayRank = criteriaIt->first + 1;

                if (visKeyNbr >= 0 &&
                    DICTCRIT_BUSKFLG(criteriaIt->second) == TRUE) /* PMSTA-15183 - LJE - 121116 */
                {
                    (*shTbPtr)[j].viskeyFlag = DICTCRIT_BUSKFLG(criteriaIt->second);
                    --visKeyNbr;
                }
            }
        }
    }

    /*  FIH-REF8691-030210  Add short_index attribute for TASK  */
    if (SYS_IsGuiMode() == FALSE)
    {
        iNbShortIndexAttr = 0;
        attribNb = *shortAttribNb;          /*  HFI-PMSTA-11298-110125  check on the initialized attribute  */

        for (auto& dictAttribStp : dictEntityStp->attr)
        {
            int             i = dictAttribStp->progN;

            if ((DICTATTR_SHORTIDX(dictAttribStp) != 0) &&
                (DICTATTR_DICTID(dictAttribStp) > 0))                 /*  HFI-PMSTA-21960-160121  */
            {
                for (j = 0, foundFlg = FALSE; (j < attribNb) && foundFlg == FALSE; j++)
                {
                    if ((*shTbPtr)[j].attrDictId == DICTATTR_DICTID(dictAttribStp))
                    {
                        /* OCS41141 - DDV - 120830 - For short attribute derived from criteria, check that it is a direct criteria, not a reference to the same entity */
                        if ((*shTbPtr)[j].criteriaPtr == NULL ||
                            ((*shTbPtr)[j].criteriaPtr->isNullParent1ProgN == true && (*shTbPtr)[j].criteriaPtr->isNullParent2ProgN == true))
                        {
                            foundFlg = TRUE;
                        }
                    }
                }

                if (foundFlg == FALSE)
                {
                    if ((GET_FLD_NBR(GET_ADMINGUIST(entityRef)) >= attribNb + iNbShortIndexAttr) && /* PMSTA-11505 - LJE - 110701 */
                        (GET_FLD_NBR(GET_ADMINGUIST(entityRef)) > DICTATTR_SHORTIDX(dictAttribStp)) &&
                        (EV_DynStPtr[GET_ADMINGUIST(entityRef)].dynStDefPtr[DICTATTR_SHORTIDX(dictAttribStp)].dataType == DICT_GetAttribDataType(entityRef, i)))
                        iNbShortIndexAttr++;
                    else
                    {
                        MSG_SendMesg(RET_DBA_ERR_MD, 4, FILEINFO, DICTENT_MDSQLNAME(dictEntityStp), DICTATTR_SQLNAME(dictAttribStp));   /*  FIH-REF11579-051205 replace RET_GEN_ERR_INVARG  */
                        iNbShortIndexAttr = 0;
                        break;
                    }
                }
            }
        }
        if (iNbShortIndexAttr != 0)
        {
            if ((pshortattr = (SH_ATTRIB_INFO_STP)CALLOC(iNbShortIndexAttr + attribNb, sizeof(SH_ATTRIB_INFO_ST))) == NULL)
            {
                MSG_RETURN(RET_MEM_ERR_ALLOC);
            }
            memcpy(pshortattr, *shTbPtr, attribNb*sizeof(SH_ATTRIB_INFO_ST));

            k = attribNb;
            for (auto& dictAttribStp : dictEntityStp->attr)
            {
                int             i = dictAttribStp->progN;

                if ((DICTATTR_SHORTIDX(dictAttribStp) != 0) &&
                    (DICTATTR_DICTID(dictAttribStp) > 0))             /*  HFI-PMSTA-21960-160121  */
                {
                    for (j = 0, foundFlg = FALSE; (j < attribNb) && foundFlg == FALSE; j++)
                    {
                        if ((*shTbPtr)[j].attrDictId == DICTATTR_DICTID(dictAttribStp))
                        {
                            /* OCS41141 - DDV - 120830 - For short attribute derived from criteria, check that it is a direct criteria, not a reference to the same entity */
                            if ((*shTbPtr)[j].criteriaPtr == NULL ||
                                ((*shTbPtr)[j].criteriaPtr->isNullParent1ProgN == true && (*shTbPtr)[j].criteriaPtr->isNullParent2ProgN == true))
                            {
                                foundFlg = TRUE;
                            }
                        }
                    }

                    if (foundFlg == FALSE)
                    {
                        /* primary keys aren't display and are technical arguments */
                        pshortattr[k].techFlag = FALSE;
                        pshortattr[k].displayRank = k;
                        pshortattr[k].flagPrimaryKey = FALSE;

                        /* keyIndex : index in dynamic structure Get_Arg */
                        pshortattr[k].keyIndex = DICTATTR_PROGPKN(dictAttribStp);

                        /* structFieldIndex : index in short dynamic structure
                        ** primary keys are at begin of short dynamic structure */
                        pshortattr[k].structFieldIndex = DICTATTR_SHORTIDX(dictAttribStp);

                        pshortattr[k].dataType = DICT_GetAttribDataType(entityRef, i);
                        pshortattr[k].label[0] = 0;
                        strcpy(pshortattr[k].label, DICTATTR_LABEL(dictAttribStp));
                        u_strcpy(pshortattr[k].uniLabel, DICTATTR_UNILABEL(dictAttribStp)); /* REF9303 - LJE - 030912 */
                        strcpy(pshortattr[k].sqlName, dictAttribStp->sqlName);

                        /* Update for test if criteria field is a primary key */
                        pshortattr[k].progN = DICTATTR_PROGN(dictAttribStp);
                        pshortattr[k].refNo = DICTATTR_ENTDICTID(dictAttribStp);
                        pshortattr[k].attrDictId = DICTATTR_DICTID(dictAttribStp);
                        pshortattr[k].viskeyFlag = DICTATTR_BUSKFLG(dictAttribStp);           /*  HFI-PMSTA-11298-110125  viskey was not managed  */

                        pshortattr[k].maxDbLenN = DBA_GetDynMaxDbLen(entityRef, pshortattr[k].progN, pshortattr[k].entityRef);
                        pshortattr[k].defaultDisplayLenN = DBA_GetDynDefDispLen(entityRef, pshortattr[k].progN, pshortattr[k].entityRef);

                        k++;
                    }
                }
            }
            attribNb += iNbShortIndexAttr;
            *shortAttribNb = attribNb;
            FREE(*shTbPtr);
            *shTbPtr = pshortattr;
        }
    }
    /*  Add Record location for main localised or specialised entities      */  /*  HFI-PMSTA-32148-181012  */
    else if ((fkStructFlag == FALSE) &&
             ((dictEntityStp->multiEntityCateg.get() == MultiEntityCategory_OptionalLocalization) ||
              (dictEntityStp->multiEntityCateg.get() == MultiEntityCategory_OptionalSpecialisation)) &&
             (GET_FLD_ME_REC_LOC(GET_ADMINGUIST(entityRef)) != Null_Dynfld))
    {
        if ((pshortattr = (SH_ATTRIB_INFO_STP)CALLOC(1 + attribNb, sizeof(SH_ATTRIB_INFO_ST))) == NULL)
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        memcpy(pshortattr, *shTbPtr, attribNb*sizeof(SH_ATTRIB_INFO_ST));

        for (auto critIt = dictEntityStp->shortDictCriteriaMap.begin(); critIt != dictEntityStp->shortDictCriteriaMap.end(); ++critIt)
        {
            DICT_CRITER_STP dictCritStp = critIt->second;

            if (DICTCRIT_PROGN(dictCritStp) == GET_FLD_ME_REC_LOC(GET_ADMINGUIST(entityRef)))
            {
                k = attribNb;

                /* primary keys aren't display and are technical arguments */
                pshortattr[k].techFlag = FALSE;
                pshortattr[k].displayRank = k;
                pshortattr[k].flagPrimaryKey = FALSE;

                /* structFieldIndex : index in short dynamic structure
                ** primary keys are at begin of short dynamic structure */
                pshortattr[k].structFieldIndex = GET_FLD_ME_REC_LOC(GET_ADMINGUIST(entityRef));

                pshortattr[k].dataType = DICTCRIT_DATATYPE(dictCritStp);
                strcpy(pshortattr[k].label, DICTCRIT_LABEL(dictCritStp));
                u_strcpy(pshortattr[k].uniLabel, DICTCRIT_UNILABEL(dictCritStp));
                strcpy(pshortattr[k].sqlName, dictCritStp->sqlName);
            }
        }
        attribNb++;
        *shortAttribNb = attribNb;
        FREE(*shTbPtr);
        *shTbPtr = pshortattr;
    }

    /*  Memorize the initial value as it could be overwritten in break criteria edition  */  /*  HFI-PMSTA-17125-131120  */
    for (int i = 0; i < *shortAttribNb; i++)
    {
        (*shTbPtr)[i].displayRankInit = (*shTbPtr)[i].displayRank;
    }

    TLS_Sort((char *)(*shTbPtr), *shortAttribNb, sizeof(SH_ATTRIB_INFO_ST),
             (TLS_CMPFCT *)DBA_CmpShortAttribRank, NULL, SortRtnTp_None); /* REF7264 - LJE - 020205 */

    return(RET_SUCCEED);
}

/************************************************************************
**  Function             : DBA_CmpShortAttribRank()
**
**  Description          : Order by display rank
**
**  Arguments            : stp1    attribute info structure pointer
**                         stp2    attribute info structure pointer
**
**  Return               : difference between two display rank
*************************************************************************/
int DBA_CmpShortAttribRank(PTR stp1, PTR stp2)
{
    return(((SH_ATTRIB_INFO_STP) stp1)->displayRank - ((SH_ATTRIB_INFO_STP)stp2)->displayRank);
}

/************************************************************************
**  Function    :   DBA_CmpFunctionRank
**
**  Description :   Order function by display rank
**
**  Arguments   :   stp1    dict function structure
**                  stp2    dict function structure
**
**  Return      :   difference between two function rank
**
**  Creation    :   HFI-PMSTA-37848-191112  order sub-function menu
**
*************************************************************************/
int DBA_CmpFunctionRank (PTR ptr1, PTR ptr2)
{
	const DICT_FCT_STP    pdictfct1 = *((const DICT_FCT_STP*) ptr1);
	const DICT_FCT_STP    pdictfct2 = *((const DICT_FCT_STP*) ptr2);

    if (pdictfct1->rank == pdictfct2->rank)
        return((int)(pdictfct1->dictId - pdictfct2->dictId));
    else
        return(pdictfct1->rank - pdictfct2->rank);
}

/************************************************************************
**
**  Function    :   DBA_GetSecuredTypeIndex
**
**  Description :   Get index of secured type
**
**  Arguments   :   OBJECT_ENUM     enObject        : Is this entity is securized
**                  FLAG_T          flagAllStruct   : TRUE if All structure FALSE else
**
**  Return      :   SECURETYPE_ENUM enSecureType: None, standard or secured by operation status
**
**  Creation    :   FIH-REF10288-040610
**
*************************************************************************/
int DBA_GetSecuredTypeIndex (OBJECT_ENUM enObject, FLAG_T flagAllStruct)
{
    int             iFieldIndex,    /*  Field index                     */
                    iFieldAllIndex; /*  Field index                     */
    DICT_ATTRIB_STP pdictattr;      /*  Metadictionnary attribute       */

    iFieldIndex = -1;
    if (flagAllStruct == FALSE)
    {
        /* Special case where the type_id of list_compo is not part of dict_attribute*/
        if (enObject == ListCompo) /* obnilouf-PMSTA-33569-190117 */
        {
             iFieldIndex = S_ListCompo_TypeId;
        }

        else
        {
             if (((iFieldAllIndex = DBA_GetSecuredTypeIndex(enObject, TRUE)) != -1) &&
                 (DICT_GetAttribInfo(enObject,
                                    (short)iFieldAllIndex,
                                    0,
                                    NULL,
                                    GET_FIX_NBR(A_DictAttr),
                                    &pdictattr) == RET_SUCCEED) &&
                   (pdictattr->shortIdx >= 0))
                   iFieldIndex = pdictattr->shortIdx;
        }
    }
    else
    {
        switch (GET_OBJECT_CST(enObject))
        {
            case InstrCst:              iFieldIndex = A_Instr_TypeId;                   break;
            case NotepadCst:            iFieldIndex = A_Notepad_TpId;                   break;
            case ListCst:               iFieldIndex = A_List_TypeId;                    break;
            case ExecutionEntCst:       iFieldIndex = A_Execution_TypeId;               break;
            case GlExecFeeEntCst:       iFieldIndex = A_GlExecFee_TypeId;               break;
            case UnMatchedExecutionCst: iFieldIndex = A_UnMatchedExecution_TypeId;      break;
            case UnMatchedGlExecFeeCst: iFieldIndex = A_UnMatchedGlExecFee_TypeId;      break;
            case OpDomainEntCst :       iFieldIndex = OpDomain_TpId;                    break;
            case EOpCst :               iFieldIndex = ExtOp_TpId;                       break;
            case ExtTransactionCst:
                iFieldIndex = DICT_GetVirtualProgN(ExtTransaction,EOp,ExtOp_TpId);
                break;
            default :
                if (DICT_GetAttribInfo(enObject,
                                       -1,
                                       0,
                                       "type_id",
                                       GET_FIX_NBR(A_DictAttr),
                                       &pdictattr) == RET_SUCCEED)
                    iFieldIndex = pdictattr->progN;
        }
    }
    return iFieldIndex;
}


/************************************************************************
**
**  Function    :   DBA_GetSecuredSubTypeIndex
**
**  Description :   Get index of secured subtype
**
**  Arguments   :   OBJECT_ENUM     enObject        : Is this entity is securized
**                  FLAG_T          flagAllStruct   : TRUE if All structure FALSE else
**
**  Return      :   SECURETYPE_ENUM enSecureType: None, standard or secured by operation status
**
**  Creation    :   FIH-REF10288-040610
**
*************************************************************************/
int DBA_GetSecuredSubTypeIndex (OBJECT_ENUM enObject, FLAG_T flagAllStruct)
{
    int             iFieldIndex,    /*  Field index                     */
                    iFieldAllIndex; /*  Field index                     */
    DICT_ATTRIB_STP pdictattr;      /*  Metadictionnary attribute       */

    iFieldIndex = -1;
    if (flagAllStruct == FALSE)
    {
        if (((iFieldAllIndex = DBA_GetSecuredSubTypeIndex(enObject,TRUE)) != -1) &&
            (DICT_GetAttribInfo(enObject,
                                (short) iFieldAllIndex,
                                0,
                                NULL,
                                GET_FIX_NBR(A_DictAttr),
                                &pdictattr) == RET_SUCCEED) &&
            (pdictattr->shortIdx >= 0))
            iFieldIndex = pdictattr->shortIdx;
    }
    else
    {
        switch (GET_OBJECT_CST(enObject))
        {
            case InstrCst:              iFieldIndex = A_Instr_SubTpId;                  break;
            case ExecutionEntCst:       iFieldIndex = A_Execution_SubtypeId;            break;
            case GlExecFeeEntCst:       iFieldIndex = A_GlExecFee_SubtypeId;            break;
            case UnMatchedExecutionCst: iFieldIndex = A_UnMatchedExecution_SubtypeId;   break;
            case UnMatchedGlExecFeeCst: iFieldIndex = A_UnMatchedGlExecFee_SubtypeId;   break;
            case OpDomainEntCst :       iFieldIndex = OpDomain_SubTpId;                 break;
            case EOpCst :               iFieldIndex = ExtOp_SubTpId;                    break;
            case ExtTransactionCst:
                iFieldIndex = DICT_GetVirtualProgN(ExtTransaction,EOp,ExtOp_SubTpId);
                break;
            default :
                if (DICT_GetAttribInfo(enObject,
                                       -1,
                                       0,
                                       "subtype_id",
                                       GET_FIX_NBR(A_DictAttr),
                                       &pdictattr) == RET_SUCCEED)
                    iFieldIndex = pdictattr->progN;
        }
    }
    return iFieldIndex;
}


/************************************************************************
**
**  Function    :   DBA_GetSecuredStatusIndex
**
**  Description :   Get index of secured status
**
**  Arguments   :   OBJECT_ENUM     enObject        : Is this entity is securized
**                  FLAG_T          flagAllStruct   : TRUE if All structure FALSE else
**
**  Return      :   SECURETYPE_ENUM enSecureType: None, standard or secured by operation status
**
**  Creation    :   FIH-REF10288-040610
**
*************************************************************************/
int DBA_GetSecuredStatusIndex (OBJECT_ENUM enObject, FLAG_T flagAllStruct)
{
    int             iFieldIndex;    /*  Field index                     */
    OPNAT_ENUM      enOpNat;        /*  Operation nature                */
    DICT_ATTRIB_STP pdictattr;      /*  Metadictionnary attribute       */

    iFieldIndex = -1;
    if (flagAllStruct == TRUE)
    {
        switch (GET_OBJECT_CST(enObject))
        {
            case ExecutionEntCst:       iFieldIndex = A_Execution_StatusEn;             break;
            case GlExecFeeEntCst:       iFieldIndex = A_GlExecFee_StatusEn;             break;
            case UnMatchedExecutionCst: iFieldIndex = A_UnMatchedExecution_StatusEn;    break;
            case UnMatchedGlExecFeeCst: iFieldIndex = A_UnMatchedGlExecFee_StatusEn;    break;
            case OpDomainEntCst :       iFieldIndex = OpDomain_StatusEn;                break;
            case EOpCst :               iFieldIndex = ExtOp_StatusEn;                   break;
            case ExtTransactionCst:
                iFieldIndex = DICT_GetVirtualProgN(ExtTransaction,EOp,ExtOp_SubTpId);
                break;
            default :
                OPE_DictEnumToOperNat(enObject,&enOpNat);
                if ((OpNat_None != enOpNat) &&
                    (DICT_GetAttribInfo(enObject,
                                        -1,
                                        0,
                                        "status_e",
                                        GET_FIX_NBR(A_DictAttr),
                                        &pdictattr) == RET_SUCCEED))
                    iFieldIndex = pdictattr->progN;
        }
    }
    return iFieldIndex;
}


/************************************************************************
**
**  Function    :   DBA_GetEntitySecuredType
**
**  Description :   Is a particular entity is secured.
**
**  Arguments   :   OBJECT_ENUM     enObject    : Is this entity is securized
**
**  Return      :   SECURETYPE_ENUM enSecureType: None, standard or secured by operation status
**
**  Creation    :   FIH-REF10288-040608
**
*************************************************************************/
SECURETYPE_ENUM DBA_GetEntitySecuredType (OBJECT_ENUM enObject)
{
    SECURETYPE_ENUM enSecureType;
    OPNAT_ENUM      enOpNat;

    enSecureType = SecuType_None;
    if ((enObject == Notepad) ||                /*  FIH-REF5512-001211  */
        (enObject == Instr) ||                 /*  FIH-REF10288-040526 */
        (enObject == List) ||                  /*  obnilouf-PMSTA-33569-190109 */
        (enObject == ListCompo))
        enSecureType = SecuType_Standard;
    else
    {
        OPE_DictEnumToOperNat(enObject, &enOpNat);
        if ((enOpNat != OpNat_None) ||
            (enObject == OpDomainEnt) ||
            (enObject == ExecutionEnt) ||	        /* MRA - 020910 - REF7560 */
            (enObject == GlExecFeeEnt) ||
            (enObject == UnMatchedExecution) ||	    /*  FIH-REF10265-040528 */
            (enObject == UnMatchedGlExecFee) ||     /*  FIH-REF10265-040528 */
            (enObject == EOp))
            enSecureType = SecuType_ByOpStatus;
    }
    return enSecureType;
}


/************************************************************************
**
**  Function    :   DBA_IsAnOperationObject()
**
**  Description :   return TRUE if object is an operation, FALSE
**                  elsewhere
**
**  Argument    :   object
**
**  Return      :   TRUE if object is an operation, FALSE elsewhere
**
*************************************************************************/
int DBA_IsAnOperationObject(OBJECT_ENUM object)
{
    for (signed n = (OPNAT_ENUM)0; n < OpNat_OpNatNbr; n++)
    {
        OBJECT_ENUM  operation;
        DBA_DYNST_ENUM discard;

        OPE_OperNatToDictEnum((OPNAT_ENUM) n, &discard, &operation);

        if (object == operation)
            return TRUE;
    }

    return FALSE;
}

/************************************************************************
**
**  Function    :   DBA_IsAnExtOperationObject()
**
**  Description :   return TRUE if object is an operation, FALSE
**                  elsewhere
**
**  Argument    :   object
**
**  Return      :   TRUE if object is an operation, FALSE elsewhere
**
*************************************************************************/
bool DBA_IsAnExtOperationObject(OBJECT_ENUM object)
{
    if (object == Op || object == EOp)
    {
        return true;
    }

    return DBA_IsAnOperationObject(object) == TRUE;
}

/************************************************************************
**
**  Function    :   DBA_CheckString()
**
**  Description :
**
**  Argument    :   type
**                  string
**
**  Return      :   0 on string OK, -1 elsewhere
**
**  Last Modif. :   GRD - 000204 - REF4204.
**                  NRAO -190601 - PMSTA-35996
**                  HFI-PMSTA-57324-2024-08-12  Allow quote on most of the string: see code in FMT_ChkAuthChar
**
*************************************************************************/
int DBA_CheckString(DATATYPE_ENUM type, char * string, DBA_DYNFLD_STP record, FIELD_IDX_T idx)
{
    unsigned int length = 0, fldLength = 0;
    DBA_DYNST_ENUM    dynStEnum = NullDynSt;

    if (record != NULLDYNST)
    {
        dynStEnum = GET_DYNSTENUM(record);
    }

    if (record != NULLDYNST && (dynStEnum != A_Synon && dynStEnum != S_Synon))
    {
        fldLength = GET_FLD_MD_MAXCHARLEN(dynStEnum, idx);
    }
    else
    {
        fldLength = GET_MAXCHARLEN(type);
    }

    if (GET_CTYPE(type) == CharPtrCType || GET_CTYPE(type) == TextPtrCType)
    {
        length = SYS_StrLen(string);
    }
    else if (GET_CTYPE(type) == UniCharPtrCType || GET_CTYPE(type) == UniTextPtrCType)
    {
        length = STRING_Length(string); /* PMSTA-28608 - DLA - 170926 */
    }

    if (length != 0)
    {
        if (type != CodeType || length <= fldLength)
        {
            if (length > fldLength && (GET_CTYPE(type) == CharPtrCType || GET_CTYPE(type) == UniCharPtrCType))   /* PMSTA-32747 - DLA - 181018 - No more truncation on (Uni)textPtrCType */
            {
                MSGNAT_ENUM msgType = MsgNat_None;
                GEN_GetApplInfo(ApplImportMessageOnStringOverflow, &msgType);

                switch (msgType)
                {
                case MsgNat_None:
                    break;
                case MsgNat_Warning:
                    MSG_SendMesg(RET_GEN_ERR_PERSONAL, 6, FILEINFO,
                        "Warning - The following string has been truncated - ", string);
                    break;
                case MsgNat_Error:
                    MSG_SendMesg(RET_GEN_ERR_PERSONAL, 6, FILEINFO,
                        SYS_Stringer("Error - The following string exceed the max data-type length (", length, " vs ", fldLength, ")").c_str(), string);
                    return -1;
                }

                STRING_Truncate(string, fldLength, type);   /* PMSTA-28608 - DLA - 170926 */
            }

            length = SYS_StrLen(string);
            switch (type)
            {
                case CodeType   :

                    /* PMSTA-44466 - DDV - 210324 - Allow # only in synonym's code */
                    if (dynStEnum == S_Synon && idx == S_Synon_Cd)
                    {
                        return(DBA_CheckSynonymCode(string, GET_ID(record, S_Synon_CodificationId)));
                    }
                    else if (dynStEnum == A_Synon && idx == A_Synon_Cd)
                    {
                        return(DBA_CheckSynonymCode(string, GET_ID(record, A_Synon_CodificationId)));
                    }
                    else if (strcspn(string, DBA_FORBIDEN_CODE) != length)
                    {
                        return -1;
                    }
                    break;

                case LongSysnameType:
                case SysnameType:
                    if (strcspn(string, DBA_FORBIDEN_SYSNAME) != length)
                    {
                        return -1;
                    }
                    break;

                case InfoType:
                case LongnameType:
                case NameType:
                case NoteType:
                case PhoneType:
                case ShortinfoType:
                    if (strcspn(string, DBA_FORBIDEN_DEFAULT) != length)
                    {
                        return -1;
                    }
                    break;
            }
        }
        else
        {
            return -1;
        }
    }
    else
    {
        return -1;
    }

    return 0;
}

/************************************************************************
**
**  Function    :   DBA_CreateStringFromObjId
**
**  Description :   Create a string from given dimension and object
**
**  Arguments   :   dim_..._dict_id and ...object_id
**
**  Return      :   char *
**
**  Creation    :   FPL-REF8928-030617
**
*************************************************************************/
STATIC char *   DBA_CreateStringFromObjId( ID_T dimId, ID_T objId)
{

    OBJECT_ENUM     objectEnum ;
    DBA_DYNST_ENUM  shDynEn ;
    DBA_DYNST_ENUM  allDynEn ;
    DBA_DYNFLD_STP  shDynStp ;
    DBA_DYNFLD_STP  allDynStp ;
    int             shId ;
    char            *pszRet ;
    char            *pszTmp ;
    DICT_ENTITY_STP pdictent ;

    /* test for security */
    if ((dimId <= 0) || (objId <= 0))
    {
        return NULL ;
    }

    DBA_GetObjectEnum(dimId, &objectEnum);      /* FPL-NOREF-031110 bug seen by LJE */


    switch(GET_OBJECT_CST(objectEnum))
    {
        case PtfCst :
            shDynEn  = S_Ptf ;
            allDynEn = A_Ptf ;
            shId     = S_Ptf_Id ;
            break ;

        case InstrCst :
            shDynEn  = S_Instr ;
            allDynEn = A_Instr ;
            shId     = S_Instr_Id ;
            break ;

        case StratCst :
            shDynEn  = NullDynSt ;
            allDynEn = NullDynSt ;
            shId     = S_Strat_Id ;
            break ;

        case  ListCst :
            shDynEn  = S_List ;
            allDynEn = A_List ;
            shId     = S_List_Id ;
            break ;
        default :
            shDynEn  = NullDynSt ;
            allDynEn = NullDynSt ;
            shId     = 0 ;
            break ;
    }


    /* Test allocations */
    if ((shDynStp  = ALLOC_DYNST(shDynEn))  == NULL)
    {
        FREE_DYNST(shDynStp, shDynEn);
        return NULL ;
    }

    /* Test allocations */
    if((allDynStp = ALLOC_DYNST(allDynEn)) == NULL)
    {
        FREE_DYNST(allDynStp, allDynEn);
        return NULL ;
    }

    SET_ID(shDynStp, shId, objId);

    if (DBA_Get2 ( objectEnum
                 , UNUSED
                 , shDynEn
                 , shDynStp
                 , allDynEn
                 , &allDynStp
                 , UNUSED
                 , UNUSED
                 , NULL) != RET_SUCCEED)
    {
        FREE_DYNST(shDynStp, shDynEn);
        return NULL ;
    }

    FREE_DYNST(shDynStp, shDynEn);


    /* keep only business key attributes */
    pdictent = DBA_GetDictEntitySt(objectEnum); /* PMSTA07964 - LJE - 090309 */
    if (pdictent != NULL)
    {
        for (auto& dictAttribStp : pdictent->attr)
        {
            if ((dictAttribStp->busKeyFlg != TRUE) &&
                (dictAttribStp->logicalFlg == FALSE))
            {
                switch (allDynStp[dictAttribStp->progN].dataType)
                {
                    case FlagType :
                        /* the SET_NULL_FLAG don't exist, so we use the SET_NULL_ENUM (same type) */
                    case EnumType :
                        SET_NULL_ENUM(allDynStp, dictAttribStp->progN);
                        break ;
                    default :
                        SET_NULL_FLD(allDynStp, dictAttribStp->progN);
                        break ;
                }
            }
        }
    }


    pszRet = DBA_GetStringFromDynStp(allDynStp, objectEnum, FALSE, FALSE, FALSE) ;      /*  FIH-REF9867-040121  Add last field TRUE for all struct  */ /* FPL-REF10328-040608 FALSE = All !!! */    /*  HFI-PMSTA-41842-200916  Add onlyBusinessKeyFlg  */


    switch (GET_OBJECT_CST(objectEnum))
    {
        case PtfCst :
            if ((pszTmp = (char*)REALLOC ( pszRet, (SYS_StrLen(pszRet) + 10) * sizeof(char))) == NULL)
                return NULL;
            pszRet = pszTmp ;
            memmove(pszRet+10, pszRet, SYS_StrLen(pszRet)+1);
            strncpy(pszRet, "portfolio=", 10);
            break ;

        case InstrCst :
            if ((pszTmp = (char*)REALLOC ( pszRet, (SYS_StrLen(pszRet) + 6) * sizeof(char))) == NULL)
                return NULL;
            pszRet = pszTmp ;
            memmove(pszRet+6, pszRet, SYS_StrLen(pszRet)+1);
            strncpy(pszRet, "instr=", 6);
            break ;

        case StratCst :
            if ((pszTmp = (char*)REALLOC ( pszRet, (SYS_StrLen(pszRet) + 6) * sizeof(char))) == NULL)
                return NULL;
            pszRet = pszTmp ;
            memmove(pszRet+6, pszRet, SYS_StrLen(pszRet)+1);
            strncpy(pszRet, "strat=", 6);
            break ;

        case  ListCst :
            if ((pszTmp = (char*)REALLOC ( pszRet, (SYS_StrLen(pszRet) + 5) * sizeof(char))) == NULL)
                return NULL;
            pszRet = pszTmp ;
            memmove(pszRet+5, pszRet, SYS_StrLen(pszRet)+1);
            strncpy(pszRet, "list=", 5);
            break ;
        default :
            break ;
    }


    FREE_DYNST(allDynStp, allDynEn);


    return pszRet ;
}



/************************************************************************
**
**  Function    :   DBA_CreateDynListForAdmaSelectMode
**
**  Description :   Create a dynStp list for QSearch or list in adma screen
**
**  Arguments   :   dynList     :   the S_List to be created
**                  bIsQSearch  :   TRUE = QSearch, FALSE = List
**
**  Return      :
**
**  Creation    :   FPL-REF10391-041206
**  Modif       :   HFI-PMSTA-38256-191213  rewrite function
**
*************************************************************************/
RET_CODE    DBA_CreateDynListForAdmaSelectMode ( DBA_DYNFLD_STP *dynList
                                               , char           *psz
                                               , FLAG_T         bIsQSearch)
{
    /*INFO_T          szString ;*/
    char            *pszString ;    /*  FPL-REF11126-050420 */
    char            *pszCursor ;
    int             iIndex ;


    /*  test for security       */
    if (dynList == NULL)
        return RET_GEN_ERR_INVARG ;

    /*  alloc of the short list */
    if ((*dynList == NULL) &&
        ((*dynList =  ALLOC_DYNST(S_List)) == NULL))
        return RET_MEM_ERR_ALLOC ;


    /*  format string           */
    pszString = (char*) CALLOC (SYS_StrLen(psz)+1, sizeof(char));   /*  FPL-REF11126-050420 */
    strcpy(pszString, psz);


    if (bIsQSearch == TRUE)     /*  Manage case of QSearch  */
    {
        SET_STRING((*dynList), S_List_ScptDef, pszString);
    }
    else                        /*  Manage case of List     */
    {
        iIndex = 0 ;
        while ((pszCursor = strstr(pszString, "=")) != NULL)    /*  search for value to be setted       */
        {
            iIndex = (int)(pszCursor - pszString) ;
            strcpy(pszString, &pszString[iIndex+1]);
        }

        if ((pszCursor = strstr(pszString, "\n")) != NULL)      /*  search if there is carriage return  */
        {
            iIndex = (int)(pszCursor - pszString) ;
            pszString[iIndex] = '\0' ;
        }

        SET_STRING((*dynList), S_List_Cd, pszString);
    }

    FREE(pszString);                                            /*  FPL-REF11126-050420 */

    return RET_SUCCEED ;
}


/************************************************************************
**
**  Function    :   DBA_WriteDomainInGuiContext
**
**  Description :   Read gui context file
**
**  Arguments   :   FILE*           pf              : GUI graphical context file
**                  DBA_DYNFLD_STP  pdbadynDomain   : Domain to save
**                  char*           buffer          : Sring to fill
**                  char*           pszTitle        : Title
**
**  Return      :   None
**
**  Modif.      :   FIH-REF9867-040226
**              :   REF11860 - 060808 - BSA : Compilation warnings with C++ compiler
**
*************************************************************************/
void DBA_WriteDomainInGuiContext (FILE *pf, DBA_DYNFLD_STP pdbadynDomain, char *buffer, const char *pszTitle)
{
    ID_T                idDomain,       /*  Saving the domain id            */
                        idPtf,          /*  port_object_id                  */
                        idInstr,        /*  inst_object_id                  */
                        idStrat,        /*  strat_object_id                 */
                        idBench1,       /*  bench1_object_id                */
                        idBench2,       /*  bench2_object_id                */
                        idBench3;       /*  bench3_object_id                */
    DICT_ENTITY_STP     pdictent;       /*  dict entity                     */
    char                *psz,           /*  Search string                   */
                        *pszPtf,        /*  To save dim of domain ptf       */
                        *pszInstr,      /*  To save dim of domain instr     */
                        *pszStrat,      /*  To save dim of domain strat     */
                        *pszBench1,     /*  To save dim of domain bench1    */
                        *pszBench2,     /*  To save dim of domain bench2    */
                        *pszBench3;     /*  To save dim of domain bench3    */
    OBJECT_ENUM         objectEnum;     /*  Obj Enum of the current entity  */

    if (pdbadynDomain != NULL &&
        (pdictent = DBA_GetDictEntitySt(Domain)) != NULL) /* PMSTA07964 - LJE - 090317 */
    {
        sprintf(buffer,"[%s:]\n",pszTitle);
        fwrite(buffer,sizeof(char),SYS_StrLen(buffer),pf);

        /* FPL-REF8928-030611 */
        if (IS_NULLFLD(pdbadynDomain, A_Domain_Id) == FALSE)
        {
            idDomain = GET_ID(pdbadynDomain, A_Domain_Id);
            SET_NULL_ID(pdbadynDomain, A_Domain_Id);
        }
        else
        {
            idDomain = 0 ;
        }

        /* save port_object_id in an other line */
        if ((IS_NULLFLD ( pdbadynDomain, A_Domain_PtfObjId     ) == FALSE ) &&
            (IS_NULLFLD ( pdbadynDomain, A_Domain_DimPtfDictId ) == FALSE ))
        {
            pszPtf = DBA_CreateStringFromObjId ( GET_ID(pdbadynDomain, A_Domain_DimPtfDictId)
                                               , GET_ID(pdbadynDomain, A_Domain_PtfObjId));
            idPtf = GET_ID(pdbadynDomain, A_Domain_PtfObjId);
            SET_NULL_ID(pdbadynDomain, A_Domain_PtfObjId);
        }
        else
        {
            idPtf = 0;
            pszPtf = NULL;
        }

        /* save instr_object_id in an other line */
        if ((IS_NULLFLD ( pdbadynDomain, A_Domain_InstrObjId     ) == FALSE ) &&
            (IS_NULLFLD ( pdbadynDomain, A_Domain_DimInstrDictId ) == FALSE ))
        {
            pszInstr = DBA_CreateStringFromObjId ( GET_ID(pdbadynDomain, A_Domain_DimInstrDictId)
                                                 , GET_ID(pdbadynDomain, A_Domain_InstrObjId));
            idInstr = GET_ID(pdbadynDomain, A_Domain_InstrObjId);
            SET_NULL_ID(pdbadynDomain, A_Domain_InstrObjId);
        }
        else
        {
            idInstr = 0;
            pszInstr = NULL;
        }

        /* save strat_object_id in an other line */
        if ((IS_NULLFLD ( pdbadynDomain, A_Domain_StratObjId     ) == FALSE ) &&
            (IS_NULLFLD ( pdbadynDomain, A_Domain_DimStratDictId ) == FALSE ))
        {
            pszStrat = DBA_CreateStringFromObjId ( GET_ID(pdbadynDomain, A_Domain_DimStratDictId)
                                                 , GET_ID(pdbadynDomain, A_Domain_StratObjId));
            idStrat = GET_ID(pdbadynDomain, A_Domain_StratObjId);
            SET_NULL_ID(pdbadynDomain, A_Domain_StratObjId);
        }
        else
        {
            idStrat = 0;
            pszStrat = NULL;
        }

        /* save bench1_object_id in an other line */
        if ((IS_NULLFLD ( pdbadynDomain, A_Domain_Bench1ObjectId     ) == FALSE ) &&
            (IS_NULLFLD ( pdbadynDomain, A_Domain_Bench1EntityDictId ) == FALSE ))
        {
            pszBench1 = DBA_CreateStringFromObjId ( GET_ID(pdbadynDomain, A_Domain_Bench1EntityDictId)
                                                  , GET_ID(pdbadynDomain, A_Domain_Bench1ObjectId));
            idBench1 = GET_ID(pdbadynDomain, A_Domain_Bench1ObjectId);
            SET_NULL_ID(pdbadynDomain, A_Domain_Bench1ObjectId);
        }
        else
        {
            idBench1 = 0;
            pszBench1 = NULL;
        }

        /* save Bench2_object_id in an other line */
        if ((IS_NULLFLD ( pdbadynDomain, A_Domain_Bench2ObjectId     ) == FALSE ) &&
            (IS_NULLFLD ( pdbadynDomain, A_Domain_Bench2EntityDictId ) == FALSE ))
        {
            pszBench2 = DBA_CreateStringFromObjId ( GET_ID(pdbadynDomain, A_Domain_Bench2EntityDictId)
                                                  , GET_ID(pdbadynDomain, A_Domain_Bench2ObjectId));
            idBench2 = GET_ID(pdbadynDomain, A_Domain_Bench2ObjectId);
            SET_NULL_ID(pdbadynDomain, A_Domain_Bench2ObjectId);
        }
        else
        {
            idBench2 = 0;
            pszBench2 = NULL;
        }

        /* save Bench2_object_id in an other line */
        if ((IS_NULLFLD ( pdbadynDomain, A_Domain_Bench3ObjectId     ) == FALSE ) &&
            (IS_NULLFLD ( pdbadynDomain, A_Domain_Bench3EntityDictId ) == FALSE ))
        {
            pszBench3 = DBA_CreateStringFromObjId ( GET_ID(pdbadynDomain, A_Domain_Bench3EntityDictId)
                                                  , GET_ID(pdbadynDomain, A_Domain_Bench3ObjectId));
            idBench3 = GET_ID(pdbadynDomain, A_Domain_Bench3ObjectId);
            SET_NULL_ID(pdbadynDomain, A_Domain_Bench3ObjectId);
        }
        else
        {
            idBench3 = 0;
            pszBench3 = NULL;
        }

        DBA_GetObjectEnum(pdictent->entDictId, &objectEnum);
        if ((psz = DBA_GetStringFromDynStp(pdbadynDomain, objectEnum, FALSE, FALSE, FALSE)) != NULL)        /*  FIH-REF9867-040121  Add last field TRUE for all struct  */ /* FPL-REF10328-040608 FALSE = All !!! */    /*  HFI-PMSTA-41842-200916  Add onlyBusinessKeyFlg  */
        {
            sprintf(buffer,"attributes=%s\n",psz);
            fwrite(buffer,sizeof(char),SYS_StrLen(buffer),pf);

            if (pszPtf != NULL)
            {
                sprintf(buffer,"object_id=port_object_id=%s\n",pszPtf);
                fwrite(buffer,sizeof(char),SYS_StrLen(buffer),pf);
                SET_ID(pdbadynDomain, A_Domain_PtfObjId, idPtf);
            }
            if (pszInstr != NULL)
            {
                sprintf(buffer,"object_id=instr_object_id=%s\n",pszInstr);
                fwrite(buffer,sizeof(char),SYS_StrLen(buffer),pf);
                SET_ID(pdbadynDomain, A_Domain_InstrObjId, idInstr);
            }
            if (pszStrat != NULL)
            {
                sprintf(buffer,"object_id=strat_object_id=%s\n",pszStrat);
                fwrite(buffer,sizeof(char),SYS_StrLen(buffer),pf);
                SET_ID(pdbadynDomain, A_Domain_StratObjId, idStrat);
            }
            if (pszBench1 != NULL)
            {
                sprintf(buffer,"object_id=Bench1_object_id=%s\n",pszBench1);
                fwrite(buffer,sizeof(char),SYS_StrLen(buffer),pf);
                SET_ID(pdbadynDomain, A_Domain_Bench1ObjectId, idBench1);
            }
            if (pszBench2 != NULL)
            {
                sprintf(buffer,"object_id=Bench2_object_id=%s\n",pszBench2);
                fwrite(buffer,sizeof(char),SYS_StrLen(buffer),pf);
                SET_ID(pdbadynDomain, A_Domain_Bench2ObjectId, idBench2);
            }
            if (pszBench3 != NULL)
            {
                sprintf(buffer,"object_id=Bench3_object_id=%s\n",pszBench3);
                fwrite(buffer,sizeof(char),SYS_StrLen(buffer),pf);
                SET_ID(pdbadynDomain, A_Domain_Bench3ObjectId, idBench3);
            }

            sprintf(buffer,"\n");
            fwrite(buffer,sizeof(char),SYS_StrLen(buffer),pf);

        }

        /* FPL-REF8928-030611 */
        if (idDomain != 0)
        {
            SET_ID(pdbadynDomain, A_Domain_Id, idDomain);
        }
    }
}


/************************************************************************
**
**  Function    :   DBA_WriteGuiContext
**
**  Description :   Read gui context file
**
**  Arguments   :   FILE    *pf : GUI graphical context file
**
**  Return      :   None
**
**  Modif.      :   FIH-REF7207-011126
**                  PMSTA-16124 - 250413 - PMO : Ensure coherence of printf / scanf formats with 32bits / 64 bits datatypes
**
*************************************************************************/
void DBA_WriteGuiContext (FILE *pf, DBA_DYNFLD_STP pdbadynDomain, DBA_DYNFLD_STP pdbadynOpDomain)
{
    MemoryPool          mp;
    char*               buffer = mp.allocChar(FILEINFO, 65535); /*  String read in file             */
    char*               psz;           /*  Search string                   */
    DICT_FCT_STP        pdictfct;       /*  dict function                   */
    DICT_ENTITY_STP     pdictent;       /*  dict entity                     */
    int                 i,s;            /*  Loop variables                  */
    FLAG_T              superUserFlg;   /*  Super user flag                 */
    ENTITIES_INFO_ST    entSt;          /*  Entities list                   */
    OBJECT_ENUM         objectEnum;     /*  Obj Enum of the current entity  */
    DICT_FCT_STP        fctStp;

/*  Test open file                                                      */
    if (pf == NULL)
        return;

/*  Save current domain                                                 */
    DBA_WriteDomainInGuiContext(pf,pdbadynDomain,buffer,"DOMAIN");

/*  Save current op domain                                              */
    DBA_WriteDomainInGuiContext(pf,pdbadynOpDomain,buffer,"OP_DOMAIN");

/*  Write function context file                                         */
    for (i = 0; i < DBA_GetDictFctRows(); i++)
    {
        pdictfct = DBA_GetDictFctStp(i); /* PMSTA07964 - LJE - 090309 */
        if ((pdictfct->finaFlag == TRUE) &&
            (pdictfct->entityDictId == 0))
        {
            sprintf(buffer,"[FCT:%s]\n",pdictfct->procName);
            fwrite(buffer,sizeof(char),SYS_StrLen(buffer),pf);
            sprintf(buffer,"origin=%d,%d\n",pdictfct->oriX,pdictfct->oriY);
            fwrite(buffer,sizeof(char),SYS_StrLen(buffer),pf);
            sprintf(buffer,"extension=%d,%d\n",pdictfct->extX,pdictfct->extY);
            fwrite(buffer,sizeof(char),SYS_StrLen(buffer),pf);
            sprintf(buffer,"maximize_f=%d\n",pdictfct->maximizeFlg);
            fwrite(buffer,sizeof(char),SYS_StrLen(buffer),pf);
            sprintf(buffer,"view_domain_f=%d\n",pdictfct->bViewDomain);         /* FPL-REF7542-020607 */
            fwrite(buffer,sizeof(char),SYS_StrLen(buffer),pf);
            sprintf(buffer,"view_toolbar_f=%d\n",pdictfct->bViewToolsBar);      /* FPL-REF7542-020607 */
            fwrite(buffer,sizeof(char),SYS_StrLen(buffer),pf);
            sprintf(buffer,"view_adminbut_f=%d\n",pdictfct->bViewAdminBut);     /*  FPL-REF10712-041022 */
            fwrite(buffer,sizeof(char),SYS_StrLen(buffer),pf);

            /*  FIH-REF9867-020406  */
            if (pdictfct->flagQuickSearch == TRUE)
            {
                sprintf(buffer,"full_search_f=%d\n",pdictfct->fullSearchFlg);
                fwrite(buffer,sizeof(char),SYS_StrLen(buffer),pf);
            }
            sprintf(buffer,"\n");
            fwrite(buffer,sizeof(char),SYS_StrLen(buffer),pf);
        }
    }

/*  Write entity context file                                           */
    if (DBA_GetUserInfo(A_ApplUser_SuperuserFlg,(PTR) &superUserFlg) != RET_SUCCEED)
        superUserFlg = FALSE;
    DBA_GetDictEntitiesList(ScreenEntSel, &entSt, TRUE, NullEntity);    /*  FPL-081210-PMSTA07121 add NullEntity    */
    for (auto it = DICT_GetDictEntityVector().begin(); it != DICT_GetDictEntityVector().end(); ++it)
    {
        pdictent = *it;
        if (pdictent)
        {
            DBA_GetObjectEnum(pdictent->entDictId, &objectEnum);
            for (s = 0;(s < entSt.entityNb) && (entSt.entityTab[s].id != pdictent->entDictId); s++);
            if ((pdictent->qSearchFlg == TRUE) ||
                (pdictent->synonFlg == TRUE) ||         /*  FIH-REF9867-040206  */
                (pdictent->tpNatEn != 0) ||
                ((superUserFlg == TRUE) &&
                 (s < entSt.entityNb)))
            {
                sprintf(buffer,"[ENT:%s]\n",pdictent->mdSqlName);
                fwrite(buffer,sizeof(char),SYS_StrLen(buffer),pf);
                if ((superUserFlg == TRUE) &&
                    (s < entSt.entityNb))
                {
                    sprintf(buffer,"use_screen_f=%d\n",pdictent->useScreenFlg);
                    fwrite(buffer,sizeof(char),SYS_StrLen(buffer),pf);
                }

                /*  FPL-REF11029-050311 save sorting col and if down or upward */
                if (pdictent->sortMenuId > 0)
                {
                    sprintf(buffer,"sort_menu_id=%d\n",pdictent->sortMenuId);
                    fwrite(buffer,sizeof(char),SYS_StrLen(buffer),pf);
                    sprintf(buffer,"invert_sort_f=%d\n",pdictent->invertSortFlag);
                    fwrite(buffer,sizeof(char),SYS_StrLen(buffer),pf);
                }

                if (pdictent->qSearchFlg == TRUE)
                {
                    sprintf(buffer,"full_search_f=%d\n",pdictent->fullSearchFlg);
                    fwrite(buffer,sizeof(char),SYS_StrLen(buffer),pf);
                }
                if (pdictent->synonFlg == TRUE)
                {
                    GEN_CODIFICATION_STP    codifStp;
                    int                     codifNb,
                                            defCodif;
                    if ((GEN_GetCodifInfo(Synon,
                                          objectEnum,
                                          FALSE,
                                          &codifStp,
                                          &codifNb,
                                          &defCodif) == TRUE) &&
                         (defCodif >= 0) &&
                         (defCodif < codifNb))
                    {
                        sprintf(buffer,"synonym_code=%s\n",codifStp[defCodif].code);
                        fwrite(buffer,sizeof(char),SYS_StrLen(buffer),pf);
                    }
                    FREE(codifStp);
                }
                if (pdictent->enSelectMode != SelectMode)
                {
                    sprintf(buffer,"select_mode=%d\n",pdictent->enSelectMode);  /*  FPL-REF10391-041207 select_mode_e -> select_mode    */
                    fwrite(buffer,sizeof(char),SYS_StrLen(buffer),pf);
                }

                /*  Save last select criteria           */          /*  FIH-REF10391-041126 */
                switch (pdictent->enSelectMode)
                {
                    case FindSelectMode :           /*  FPL-REF10391-041207 */
                    case SelectMode :
                        if (pdictent->tpNatEn != 0)
                        {
                            sprintf(buffer,"select_nature_e=%" szFormatId "\n",pdictent->enSelectNature);       /* PMSTA-16124 - 250413 - PMO */
                            fwrite(buffer,sizeof(char),SYS_StrLen(buffer),pf);
                        }
                        if (pdictent->dictSelectFunction > 0)
                        {
                            if ((DBA_GetDictFctInfo(pdictent->dictSelectFunction, DictFctInfo_Stp,(PTR) &fctStp)) == RET_SUCCEED)
                            {
                                sprintf(buffer,"select_function=%s\n",fctStp->procName);
                                fwrite(buffer,sizeof(char),SYS_StrLen(buffer),pf);
                            }
                        }
                    /*  No Break PLEASE             */
                    case PatternSelectMode :
                        if ((pdictent->pszSelectString != NULL) &&
                            (pdictent->pszSelectString[0] != '\0'))
                        {
                            sprintf(buffer,"select_string=%s\n",pdictent->pszSelectString);
                            fwrite(buffer,sizeof(char),SYS_StrLen(buffer),pf);
                        }
                        if (pdictent->iSelectStringIndex > 0)
                        {
                            sprintf(buffer,"select_string_index=%d\n",pdictent->iSelectStringIndex);
                            fwrite(buffer,sizeof(char),SYS_StrLen(buffer),pf);
                        }
                        break;

                    case SimpleSelectMode :
                        if (pdictent->pdbadynSearch != NULL)
                        {
                            if (((psz = DBA_GetStringFromDynStp(pdictent->pdbadynSearch, objectEnum, FALSE, FALSE, FALSE)) != NULL) &&      /*  FIH-REF9867-040121  Add last field TRUE for all struct  */  /* FPL-REF10328-040608 FALSE = All !!! */   /*  HFI-PMSTA-41842-200916  add onlyBusinessKeyFlg  */
                                (psz[0] != '\0'))
                            {
                                sprintf(buffer,"attributes=%s\n",psz);
                                fwrite(buffer,sizeof(char),SYS_StrLen(buffer),pf);
                            }
                        }
                        break;

                    case ListSelectMode :
                        if ((pdictent->pdbadynSelectList != NULL) &&
                            (pdictent->pszList != NULL) &&
                            (pdictent->pszList[0] != '\0'))
                        {
                            sprintf(buffer,"list=%s\n",pdictent->pszList);
                            fwrite(buffer,sizeof(char),SYS_StrLen(buffer),pf);
                        }
                        break;
                }

                /*  FPL-REF10391-041210 in all the case, we save the QSearch    */
                if ((pdictent->pdbadynQSearch != NULL) &&
                    (IS_NULLFLD(pdictent->pdbadynQSearch, S_List_ScptDef) == FALSE))
                {
                    sprintf(buffer,"select_quick_search_def=%s\n", GET_STRING(pdictent->pdbadynQSearch, S_List_ScptDef));
                    fwrite(buffer,sizeof(char),SYS_StrLen(buffer),pf);
                    sprintf(buffer,"\n");
                    fwrite(buffer,sizeof(char),SYS_StrLen(buffer),pf);

                }

                sprintf(buffer,"\n");
                fwrite(buffer,sizeof(char),SYS_StrLen(buffer),pf);
            }
        }
    }
}


/************************************************************************
**
**  Function    :   DBA_DictFctCheckAuth
**
**  Description :   Setup DictFct Table according to current License Authorization.
**
**  Argument    :   none
**
**  Return      :   RET_CODE
**
**  Creation	:   ROI - 961127 - DVP280.
**
**  Modif.		:   GRD - 970327 - DVP404.
**              :   GRD - 970808 - BUG457.
**              :   ROI - 970826 - DVP575.
**              :   FIH - 980206 - REF893.2
**              :   GRD - 980518 - REF1905
**				:	ROI - 981007 - REF2891
**				:	DRI - 20000223 - REF4306
**                  PMSTA-16124 - 250413 - PMO : Ensure coherence of printf / scanf formats with 32bits / 64 bits datatypes
**
*************************************************************************/
RET_CODE	DBA_DictFctCheckAuth()
{
    DBA_DYNFLD_STP  shParamStp, paramStp;
    DICT_FCT_STP    fctStp;
    RET_CODE        retCode;
    DATE_T          currentDate;
    DATE_T          licenseDate;
    DATE_FORMAT_ST  dateFormat;
    char*           licenceeUsers;
    char            licenceeKey[256];
    char            licenceeKey1[256];
    char            licenceeKey2[256];
    char            newApplName[256];
    char            convApplName[256];
#ifdef _DEBUG
    char            envVar[12];
    char            *pEnvVar = NULL;
    char            checkVar[10];	/* 7264 - RAK - 020905 */
#endif
    char**          arrayFields;
    short           coreModNb = 0, prodModNb = 0, attribModNb = 0, riskModNb = 0,
                    accModNb = 0, fundModNb = 0, corpActionsModNb = 0, advAnalyticsModNb = 0,
                    compManagementModNb = 0, excelReportModNb = 0, raModNb = 0, acmModNb = 0,
                    omModNb = 0,
                    netCoreNb = 0, netProdModNb = 0, netAttribModNb = 0, netRiskModNb = 0,
                    netAccModNb = 0, netFundModNb = 0, netCorpActionsModNb = 0, netAdvAnalyticsModNb = 0,
                    netCompManagementModNb = 0, netExcelReportModNb = 0, netRAModNb = 0, netACMModNb = 0,
                    netOMModNb = 0,
                    i = 0, modNb = 0;
    unsigned int    netTotalVal = 0, valToAdd = 0;              /* PMSTA-16124 - 250413 - PMO */
    int             retcode = OP_SUCCEDED;
    const char      *pszLicenseeUsers = "LICENSEE_USERS";   /* REF8728 - YST - 030219 */
    DICT_T          issDictId,
                    redmDictId;
    FLAG_T          isLicense = TRUE;
    int             stringLicenseNumber;        /*  FIH-REF6116-010618  */

    /* Test allocations */
    if (((shParamStp = ALLOC_DYNST(S_ApplParam)) == NULL) ||
        ((paramStp = ALLOC_DYNST(A_ApplParam)) == NULL))
    {
        FREE_DYNST(shParamStp, S_ApplParam);
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    /* Get current LICENSEE_USERS */
    SET_NAME(shParamStp, S_ApplParam_ParamName, pszLicenseeUsers); /* DLA - PMSTA09887 - 101115 */

    retCode = DBA_Get2(ApplParam,
                       UNUSED,
                       S_ApplParam,
                       shParamStp,
                       A_ApplParam,
                       &paramStp,
                       UNUSED,		/* Options */
                       UNUSED,		/* AllocConn */
                       NULL);

    /* BUG452 - 970821 - XMT: free variable */
    FREE_DYNST(shParamStp, S_ApplParam);

    if (retCode != RET_SUCCEED)
    {
        /* BUG452 - 970821 - XMT: free variable */
        FREE_DYNST(paramStp, A_ApplParam);
        return retCode;
    }

    /*
       Verify if license key is good.	DVP404. GRD.
    */

#ifdef _DEBUG /* must not be available in release version */
    strcpy(envVar, "AA");			/* REF1905 */
    strcat(envVar, "ALICE");
    strcat(envVar, "NSE");

    strcpy(checkVar, "noc");
    strcat(checkVar, "ount");

    pEnvVar = getenv(envVar);
    if (pEnvVar && (strcmp(getenv(envVar) , checkVar) == 0))
        isLicense = FALSE;
#endif

    if (isLicense == TRUE)								/* REF1905 */
    {
        /* Allocate space to store license key data.  */
        arrayFields = (char **)   CALLOC (4, sizeof (char *));      /*  FIH-REF6116-010618  Add LICENSEE_PACK 3-->4 */
        arrayFields[0] = (char *) CALLOC (255, sizeof(char));
        arrayFields[1] = (char *) CALLOC (255, sizeof(char));
        arrayFields[2] = (char *) CALLOC (255, sizeof(char));
        arrayFields[3] = (char *) CALLOC (255, sizeof(char));       /*  FIH-REF6116-010618  */

        /* Retrieve APPL-INFO table data. */
        GEN_GetApplInfo(ApplLicenseName,        arrayFields[0]);
        GEN_GetApplInfo(ApplLicenseUsers,       arrayFields[1]);
        GEN_GetApplInfo(ApplLicenseExpiration,  &licenseDate);
        GEN_GetApplInfo(ApplLicenseKey1,         licenceeKey1);
        GEN_GetApplInfo(ApplLicenseKey2,         licenceeKey2);

        if (*licenceeKey2)
        {
            if (*licenceeKey2 == ' ' ||
                    *licenceeKey1 && licenceeKey1[SYS_StrLen(licenceeKey1) - 1] == ' ')
                strcat(strcpy(
                    licenceeKey, licenceeKey1), licenceeKey2);
            else
                strcat(strcat(strcpy(
                    licenceeKey, licenceeKey1), " "),licenceeKey2);
        }
        else
            strcpy(licenceeKey, licenceeKey1);

        /*  FIH-REF6116-010618  Manage LICENSEE_PACK :license key nay be crypted on 3 or 4 strings  */
        GEN_GetApplInfo(ApplLicensePack,arrayFields[3]);
        if (arrayFields[3][0] != END_OF_STRING)
            stringLicenseNumber = 4;
        else
            stringLicenseNumber = 3;
        /*
           Convert this date to a string only if
           the license is not unlimited.
        */

        if (licenseDate != 0)
        {
            dateFormat.ordre = Dmy;
            strcpy(dateFormat.yearSep,  "/");
            strcpy(dateFormat.monthSep, "/");
            strcpy(dateFormat.daySep,   "/");
            dateFormat.yearFormat = 1;
            dateFormat.monthFormat = 0;

            DATE_FormatToStr(arrayFields[2], licenseDate, &dateFormat);
        }
        else
        {
            strcat(arrayFields[2], LICENSEEXPIRATION);
        }

        if ((retcode = key_crypt(CHECK, licenceeKey, stringLicenseNumber, arrayFields)) != OP_SUCCEDED)
        {
                /* BUG452 - 970821 - XMT: free variable */
            FREE_DYNST(paramStp, A_ApplParam);
            MSG_RETURN(RET_ENV_ERR_WRONGLICENSEKEY);
        }

        /*
            Now check for the license date, if not unlimited.
        */

        if (licenseDate != 0)
        {
            currentDate = DATE_CurrentDate();

            /* Is it still valid. */
            if (DATE_Cmp(currentDate, licenseDate) > 0)
            {
                    /* BUG452 - 970821 - XMT: free variable */
                FREE_DYNST(paramStp, A_ApplParam);
                MSG_RETURN(RET_ENV_ERR_LICENSEDATEEXPIRED);
            }
        }

        FREE(arrayFields[0]);
        FREE(arrayFields[1]);
        FREE(arrayFields[2]);
        FREE(arrayFields[3]);           /*  FIH-REF6116-010618  */
        FREE(arrayFields);
    }

    /* Init local variables */
    licenceeUsers = GET_INFO(paramStp, A_ApplParam_Value);

    coreModNb           = 0;
    prodModNb           = 0;
    attribModNb         = 0;
    riskModNb           = 0;
    accModNb            = 0;
    fundModNb           = 0;
    corpActionsModNb    = 0;
    advAnalyticsModNb   = 0;
    compManagementModNb = 0;
    excelReportModNb    = 0;
    raModNb             = 0;
    acmModNb            = 0;
    omModNb             = 0;

    /* BUG452 - 970821 - XMT: set netTotalVal to 0 */
    netTotalVal = 0;
    valToAdd = 0;

    /* Get modules Nb */
    short   sCompoundOrderLevel = 0, sRiskComplaianceLevel = 0, sQuestionnaireLevel = 0, sFinancialPlanningLevel = 0, sDataFrameworkLevel = 0, sCRMLevel = 0;
    DBA_CheckLicenseInfo  (licenceeUsers,
                           &coreModNb,
                           &prodModNb,
                           &attribModNb,
                           &riskModNb,
                           &accModNb,
                           &fundModNb,
                           &corpActionsModNb,
                           &advAnalyticsModNb,
                           &compManagementModNb,
                           &excelReportModNb,
                           &raModNb,
                           &acmModNb,
                           &omModNb,
                           &sCompoundOrderLevel,
                           &sRiskComplaianceLevel,
                           &sQuestionnaireLevel,
                           &sFinancialPlanningLevel,
                           &sDataFrameworkLevel,
                           &sCRMLevel);

    /* BUG452 - 970821 - XMT: free variable */
    FREE_DYNST(paramStp, A_ApplParam);

    /**********************************************************************/
    /*                                                                    */
    /*  A cet endroit, il faut charger les trois autres champs "Licensee" */
    /*                                                                    */
    /*  Faire la v�rification de la cl� avec le cryptage                  */
    /*                                                                    */
    /*  Compter le nombre de connexions client d�j� �tablies et d�cr�men- */
    /*  ter en cons�quence les variables "modNb"                          */
    /*                                                                    */
    /*  Cr�er une connexion client dont le "program name" SYBASE est :    */
    /*            aaa_gui_xxxx                                            */
    /*                                                                    */
    /*  O� xxxx est une conversion en h�xa des 10 nombres de module.      */
    /*                                                                    */
    /*  Si coreModNb = 0, il faut sortir de l'application avec le message */
    /*                                                                    */
    /*  "D�sol�, mais vous avez �puis� votre nombre de licences."         */
    /*                                                                    */
    /**********************************************************************/

    if (isLicense == TRUE)							/* REF1905 */
    {
        if ((retcode = DBA_GimmeNetRunning("aaa_gui.",			/* Kind of process to spy. */
                           &netCoreNb,
                           &netProdModNb,
                           &netAttribModNb,
                           &netRiskModNb,
                           &netAccModNb,
                           &netFundModNb,
                           &netCorpActionsModNb,
                           &netAdvAnalyticsModNb,
                           &netCompManagementModNb,
                           &netExcelReportModNb,
                           &netRAModNb,
                           &netACMModNb,
                           &netOMModNb
                          )) != RET_SUCCEED)
        {
            MSG_RETURN(RET_ENV_ERR_DBCONNECTPROBLEMS);
        }

        /* BUG452 - 970821 - XMT: netTotalVal is allways set to 0 */
        /* If there is no core module left, we must stop now. */
        if (coreModNb <= netCoreNb)
            MSG_RETURN(RET_ENV_ERR_TOOMUCHPROCESSES);
        else
            coreModNb = 1;

        if (prodModNb <= netProdModNb)
            prodModNb = 0;
        else
            prodModNb = 1;

        attribModNb = 1;

        if (riskModNb <= netRiskModNb)
            riskModNb = 0;
        else
            riskModNb = 1;

        if (accModNb <= netAccModNb)
            accModNb = 0;
        else
            accModNb = 1;

        if (fundModNb <= netFundModNb)
            fundModNb = 0;
        else
            fundModNb = 1;

        if (corpActionsModNb <= netCorpActionsModNb)
            corpActionsModNb = 0;
        else
            corpActionsModNb = 1;

        advAnalyticsModNb = 1;              /* REF1055 - SCO/GRD. */

        if (compManagementModNb <= netCompManagementModNb)
            compManagementModNb = 0;
        else
            compManagementModNb = 1;

        if (excelReportModNb <= netExcelReportModNb)
            excelReportModNb = 0;
        else
            excelReportModNb = 1;

        raModNb = 1;

        if (acmModNb <= netACMModNb)
            acmModNb = 0;
        else
            acmModNb = 1;

        if (omModNb <= netOMModNb)
            omModNb = 0;
        else
            omModNb = 1;
    }

    /* Suppression de la variable AAAFUNDS - DVP575 */
    if (accModNb > 0)
        EV_accountingFlag = TRUE;
    else
        EV_accountingFlag = FALSE;

    if (fundModNb > 0)
        EV_fundFlag = TRUE;
    else
    {
        EV_fundFlag = FALSE;

        /*  FIH-REF893.2-980206 Manage fund module  */
        DBA_GetDictId(ShareIssOpEnt,&issDictId);
        DBA_GetDictId(ShareRedmOpEnt, &redmDictId);
        for (i = 0; i < DBA_GetDictFctRows(); i++)
        {
            fctStp = DBA_GetDictFctStp(i); /* PMSTA07964 - LJE - 090309 */

            if ((fctStp->dictId == DictFct_Admin) &&
                ((fctStp->entityDictId == issDictId) ||
                (fctStp->entityDictId == redmDictId)))
            {
                fctStp->typeId = 0;
                fctStp->subtypeId = 0;
                fctStp->minOpStatus = 0;
                fctStp->maxOpStatus = (ENUM_T) DBA_GetPermValMax(Op, A_Op_StatEn);
                fctStp->createFlag = FALSE;
                fctStp->updateFlag = FALSE;
                fctStp->deleteFlag = FALSE;
                fctStp->riskViewFlag = FALSE;
                fctStp->realTimeFlag = FALSE;
            }
        }
    }

    /* Setup DictFctTab according to given modules Nb */
    for (i = 0; i < DBA_GetDictFctRows(); i++)
    {
        /* Init loop variable */
        fctStp = DBA_GetDictFctStp(i); /* PMSTA07964 - LJE - 090309 */

        switch(fctStp->module)
        {
            case DictFctMod_Core:
                modNb = coreModNb;
                valToAdd = MODULE_MASK_CORE;
                break;
            case DictFctMod_Productivity:
                modNb = prodModNb;
                valToAdd = MODULE_MASK_PROD;
                break;
            case DictFctMod_Attribution:
                modNb = attribModNb;
                valToAdd = MODULE_MASK_ATTRIB;
                break;
            case DictFctMod_Risk:
                modNb = riskModNb;
                valToAdd = MODULE_MASK_RISK;
                break;
            case DictFctMod_CorporateActions:
                modNb = corpActionsModNb;
                valToAdd = MODULE_MASK_CORPACTION;
                break;
            case DictFctMod_AdvancedAnalytics:
                modNb = advAnalyticsModNb;
                valToAdd = MODULE_MASK_ADVANAL;
                break;
            case DictFctMod_CompositeManagement:
                modNb = compManagementModNb;
                valToAdd = MODULE_MASK_COMPOMGR;
                break;
            case DictFctMod_ExcelReport:
                modNb = excelReportModNb;
                valToAdd = MODULE_MASK_EXCEL;
                break;
            case DictFctMod_ReturnAnalysis:
                modNb = raModNb;
                valToAdd = MODULE_MASK_RA;
                break;
            case DictFctMod_AdvancedConstraintManagement:
                modNb = acmModNb;
                valToAdd = MODULE_MASK_ACM;
                break;
            case DictFctMod_OrderManagement:
                modNb = omModNb;
                valToAdd = MODULE_MASK_OM;
                break;
            default:
                modNb = 0;
                valToAdd = 0;
                break;
        }

        /* Check if access to current function is allowed */
        if (modNb == 0)
            fctStp->accesStatus = DictFctAuth_None;

        if (fctStp->accesStatus != DictFctAuth_None)
            netTotalVal |= valToAdd;
    }

    if (isLicense == TRUE)							/* REF1905 */
    {
        sprintf(convApplName, "%08X", netTotalVal);

        /* Change the application name. */
        strcpy(newApplName, "aaa_gui.");
        strcat(newApplName, convApplName);

        GEN_ForceApplName(newApplName);  /* PMSTA-32895 - 140119 - FME Cluster Logger */
    }

    return RET_SUCCEED;
}

/************************************************************************
**
**  Function    :   DBA_FillPermValStatus
**
**  Description :   Fill a status permited values table
**
**  Argument    :   DICT_FCT_ENUM   dictFctEn   : Function  id
**		            DICT_T          entDictId   : Entity id
**		            DICT_T          typeId,     : Type id
**		            DICT_T          subtypeId   : SubType id
**		            short*          psCounter   : Pointer to number of authorised id
**                  DICT_T**        psDictIdTab : Table of authorised type id
**
**  Return      :   RET_CODE
**
**  Creation	:   FIH-REF10983-050210
**
*************************************************************************/
RET_CODE DBA_FillPermValStatus (int                 iNbFull,
                                PERMITED_VALUES_STP permvalFull,
                                int                 iNbAuthorised,
                                PERMITED_VALUES_STP permvalAuthorised)
{
    int         i,j;            /*  Loop variable                       */
    RET_CODE    retCode;        /*  Returned value                      */

    if ((permvalFull == NULL) ||
        (permvalAuthorised == NULL))
        retCode = RET_GEN_ERR_INVARG;
    else
    {
        for (i = 0 ; i < iNbAuthorised; i++)
        {
            for (j = 0;(j < iNbFull) && (permvalFull[j].value != permvalAuthorised[i].value); j++);
            if (j < iNbFull)
                permvalFull[j].rank = TRUE;
        }
        retCode = RET_SUCCEED;
    }
    return retCode;
}


/************************************************************************
**
**  Function    :   DBA_CheckOpEntTypeAuth
**
**  Description :   Check if an operation with a specific type can be created.
**
**  Argument    :   OPNAT_ENUM operNatEn,
**		            ID_T typeId,
**		            FLAG_T* createFlagPtr,
**
**  Return      :   RET_CODE
**
**  Creation	:   FIH - 980616 - REF1504
**  Modif       :   FIH-REF10983-050210 Add iNbPermVal and permvalStatus
**
*************************************************************************/
RET_CODE    DBA_CheckOpEntTypeAuth (DICT_T              dictFctEn,
                                    FLAG_T              *createFlagPtr,
                                    FLAG_T*             updateFlagPtr,
                                    short               statusEn,
                                    OPNAT_ENUM          operNatEn,
                                    OBJECT_ENUM         checkRef,
                                    ID_T                dictType,       /*  FPL-PMSTA08801-091008 longID from DICT_T    */
                                    int                 *piNbType,
                                    ID_T                **dictTabPtr,   /*  FPL-PMSTA08801-091008 longID from DICT_T    */
                                    int                 iNbPermVal,
                                    PERMITED_VALUES_STP permvalStatus)
{
    PERMITED_VALUES_STP permValStp = NULL;
    int                 permValNb;
    FLAG_T              *flagPtr;
    short               i,
                        sNbSubType;
    ID_T                *dictSubTypeTab = NULL; /*  FPL-PMSTA08801-091008 longID from DICT  */
    DICT_T              entDictId;
    DBA_DYNST_ENUM      dynStEn;
    OBJECT_ENUM         entityRef;
    FLAG_T              noneFlag = FALSE;

    /*  Security test   */
    if (((createFlagPtr == NULL) &&
         (updateFlagPtr == NULL)) ||
        ((createFlagPtr != NULL) &&
         (updateFlagPtr != NULL)))
        return RET_GEN_ERR_INVARG;
    if ((piNbType != NULL) &&
        ((dictTabPtr == NULL) ||
         (*dictTabPtr == NULL)))
        return RET_GEN_ERR_INVARG;
    if (dictType <= 0)
        return RET_SUCCEED;

    /*  Init variables  */
    if (createFlagPtr != NULL)
        flagPtr = createFlagPtr;
    else
        flagPtr = updateFlagPtr;
    *flagPtr = FALSE;

    if (piNbType != NULL)
        *piNbType = 0;

    /*  Security test   */
    if (checkRef == NullEntity)
    {
        if ((OPE_OperNatToDictEnum(operNatEn,&dynStEn,&entityRef) != RET_SUCCEED) ||
            (DBA_GetDictId(entityRef, &entDictId) == FALSE))
            return RET_GEN_ERR_INVARG;
    }
    else
        DBA_GetDictId(checkRef, &entDictId);

    /*  Test on each type       */
    DBA_FillPermValTab(OpDomainEnt, OpDomain_StatusEn, (PTR) &permValStp, &permValNb, 0);
    DBA_CheckOpAdmAuth(dictFctEn,
                       statusEn,
                       operNatEn,
                       checkRef,
                       dictType,
                       0,
                       0,
                       createFlagPtr,
                       updateFlagPtr,
                       NULL,
                       &permValNb,
                       (PTR) &permValStp);

    /*  Is None authorised ?    */
    if ((permValNb != 0) &&
        (piNbType != NULL))
    {
        (*dictTabPtr)[*piNbType] = 0;
        (*piNbType)++;
        noneFlag = TRUE;
    }
    if (permValStp != NULL)
    {
        delete [] permValStp;
        permValStp = nullptr;
        *flagPtr = TRUE;
    }

    /*  Test on each subtype    */
    if (((*flagPtr == FALSE) || (piNbType != NULL)) &&
        (DBA_CheckNumberOfDictFct(dictFctEn,entDictId,checkRef,dictType,-1,&sNbSubType,&dictSubTypeTab) == RET_SUCCEED) &&
        (sNbSubType != 0))
    {
        for (i = 0; (i < sNbSubType) && ((*flagPtr == FALSE) || (piNbType != NULL)); i++)
        {
            if (dictSubTypeTab[i] != 0)     /*  FIH-REF5735-120301  */
            {
                DBA_FillPermValTab(OpDomainEnt,OpDomain_StatusEn,(PTR) &permValStp,&permValNb, 0);
                DBA_CheckOpAdmAuth(dictFctEn,
                                   statusEn,
                                   operNatEn,
                                   checkRef,
                                   dictType,
                                   dictSubTypeTab[i],
                                   0,
                                   createFlagPtr,
                                   updateFlagPtr,
                                   NULL,
                                   &permValNb,
                                   (PTR) &permValStp);

                if ((piNbType != NULL) &&
                    ((permValNb != 0) &&
                     (noneFlag == FALSE)) ||
                    ((permValNb == 0) &&
                     (noneFlag == TRUE)))
                {
                    (*dictTabPtr)[*piNbType] = dictSubTypeTab[i];
                    (*piNbType)++;
                }
                if (permValStp != NULL)
                {
                    DBA_FillPermValStatus(iNbPermVal,permvalStatus,permValNb,permValStp);   /*  FIH-REF10983-050214 */
                    delete [] permValStp;
                    permValStp = nullptr;
                    *flagPtr = TRUE;    /*  FIH-REF3143-981215  */
                }
            }
        }
        FREE(dictSubTypeTab);
    }
    return RET_SUCCEED;
}

/************************************************************************
**
**  Function    :   DBA_CheckOpEntAuth
**
**  Description :   Check current given operation status authorization.
**
**  Argument    :   DICT_FCT_ENUM dictFctEn,
**					short opStatus,
**		            OPNAT_ENUM operNatEn,
**		            ID_T typeId,
**		            ID_T subtypeId,
**		            FLAG_T* createFlagPtr,
**		            FLAG_T* updateFlagPtr,
**		            FLAG_T* deleteFlagPtr
**		            int* permValNbPtr,
**		            PTR permValTabPtr
**
**  Return      :   RET_CODE
**
**  Creation	:   FIH - 980616 - REF1504
**  Modif       :   ROI	- 990111 - REF2644
**  Modif       :   FIH-REF10983-050210 Add iNbPermVal and permvalStatus
**
*************************************************************************/
RET_CODE    DBA_CheckOpEntAuth (DICT_T              dictFctEn,
                                FLAG_T              *createFlagPtr,
                                FLAG_T              *updateFlagPtr,
                                short               statusEn,
                                OPNAT_ENUM          operNatEn,
                                OBJECT_ENUM         checkRef,
                                int                 *piNbType,
                                ID_T                **dictTabPtr,   /*  FPL-PMSTA08801-091008 longID from DICT_T    */
                                int                 iNbPermVal,
                                PERMITED_VALUES_STP permvalStatus)
{
    PERMITED_VALUES_STP permValStp = NULL;
    int                 permValNb;
    FLAG_T              *flagPtr;
    short               s,
                        sNbType;
    ID_T                *dictTypeTab = NULL;    /*  FPL-PMSTA08801-091008 longID from DICT_T    */
    DICT_T              entDictId;
    DBA_DYNST_ENUM      dynStEn;
    OBJECT_ENUM         entityRef;
    FLAG_T              noneFlag = FALSE;

    /*  Security test   */
    if (((createFlagPtr == NULL) &&
         (updateFlagPtr == NULL)) ||
        ((createFlagPtr != NULL) &&
         (updateFlagPtr != NULL)))
        return RET_GEN_ERR_INVARG;
    if ((piNbType != NULL) &&
        ((dictTabPtr == NULL) ||
         (*dictTabPtr == NULL)))
        return RET_GEN_ERR_INVARG;

    /*  Init variables  */
    if (createFlagPtr != NULL)
        flagPtr = createFlagPtr;
    else
        flagPtr = updateFlagPtr;
    *flagPtr = FALSE;
    if (piNbType != NULL)
        *piNbType = 0;

    /*  Security test   */
    if (checkRef == NullEntity)
    {
        if ((OPE_OperNatToDictEnum(operNatEn,&dynStEn,&entityRef) != RET_SUCCEED) ||
            (DBA_GetDictId(entityRef, &entDictId) == FALSE))
            return RET_GEN_ERR_INVARG;
    }
    else
        DBA_GetDictId(checkRef, &entDictId);

    /*  Test on entity  */
    if ((DBA_CheckNumberOfDictFct(dictFctEn,entDictId,checkRef,0,0,&sNbType,&dictTypeTab) == RET_SUCCEED) &&
        (sNbType != 0))
    {
        DBA_FillPermValTab(OpDomainEnt, OpDomain_StatusEn, (PTR) &permValStp, &permValNb, 0);
        DBA_CheckOpAdmAuth(dictFctEn,
                           statusEn,
                           operNatEn,
                           checkRef,
                           0,
                           0,
                           0,
                           createFlagPtr,
                           updateFlagPtr,
                           NULL,
                           &permValNb,
                           (PTR) &permValStp);

        /*  None is authorised      */
        if ((permValNb != 0) &&
            (piNbType != NULL))
        {
            (*dictTabPtr)[*piNbType] = 0;
            (*piNbType)++;
            noneFlag = TRUE;
        }

        if (permValNb != 0)                                                         /*  FIH-REF11260-050622 */
            DBA_FillPermValStatus(iNbPermVal,permvalStatus,permValNb,permValStp);   /*  FIH-REF10983-050215 */

        if (permValStp != NULL)
        {
            delete [] permValStp;
            permValStp = nullptr;
            *flagPtr = TRUE;
        }

        /*  Test on each type       */
        if (((*flagPtr == FALSE) || (piNbType != NULL)) &&
            (DBA_CheckNumberOfDictFct(dictFctEn,entDictId,checkRef,-1,0,&sNbType,&dictTypeTab) == RET_SUCCEED) &&
            (sNbType != 0))
        {
            for (s = 0; (s < sNbType) && ((*flagPtr == FALSE) || (piNbType != NULL)); s++)
            {
                *flagPtr = FALSE;               /*  FIH-REF5735-120301  */
                if ((dictTypeTab[s] != 0) &&    /*  FIH-REF5735-120301  */
                    (DBA_CheckOpEntTypeAuth(dictFctEn,
                                            createFlagPtr,
                                            updateFlagPtr,
                                            statusEn,
                                            operNatEn,
                                            checkRef,
                                            dictTypeTab[s],
                                            NULL,
                                            NULL,
                                            iNbPermVal,             /*  FIH-REF10983-050210 */
                                            permvalStatus           /*  FIH-REF10983-050210 */
                                            ) == RET_SUCCEED) &&
                    (piNbType != NULL) &&
                    (((noneFlag == TRUE) &&
                      (*flagPtr == FALSE)) ||
                     ((noneFlag == FALSE) &&
                      (*flagPtr == TRUE))))
                {
                    (*dictTabPtr)[*piNbType] = dictTypeTab[s];
                    (*piNbType)++;
                }
            }
            FREE(dictTypeTab);
        }
    }
    else
    {
        DBA_FillPermValTab(OpDomainEnt, OpDomain_StatusEn,(PTR) &permValStp, &permValNb, 0);
        DBA_CheckOpAdmAuth(dictFctEn,
                           0,
                           OpNat_None,
                           checkRef,        /*  FIH-REF10336-040602 */
                           0,
                           0,
                           0,
                           createFlagPtr,
                           updateFlagPtr,
                           NULL,
                           &permValNb,
                           (PTR) &permValStp);
        if (permValStp != NULL)
        {
            DBA_FillPermValStatus(iNbPermVal,permvalStatus,permValNb,permValStp);   /*  FIH-REF10983-050210 */
            delete [] permValStp;
            permValStp = nullptr;
            if (permValNb != 0)
                *flagPtr = TRUE;
        }
    }
    return RET_SUCCEED;
}

/************************************************************************
**
**  Function    :   DBA_CheckOpNatAuth
**
**  Description :   Check current given operation status authorization.
**
**  Argument    :   DICT_FCT_ENUM dictFctEn,
**					FLAG_T  createFlag      : Copy or Create action
**					FLAG_T  updateFlag      : Modify Action
**					int     iNbPermVal      : Number of permitted values
**					PTR     permValTabPtr   : Table of permitted values
**
**  Return      :   RET_CODE
**
**  Creation	:   FIH - 980205 - REF893.2
**  Modif.		:   ROI - 990111 - REF2644
**
*************************************************************************/
RET_CODE    DBA_CheckOpNatAuth(DICT_T           dictFctEn,
                               FLAG_T			createFlag,
                               FLAG_T			updateFlag,
                               OPSTAT_ENUM		statusEn,
                               int				*permValNbPtr,
                               PTR				permValTabPtr)
{
    PERMITED_VALUES_STP permValTab;
    FLAG_T              *createFlagPtr = NULL,
                        *updateFlagPtr = NULL;
    short               i;
    int                 iNbPermVal;

    /*  Security test   */
    if (((permValTab = *((PERMITED_VALUES_STP*) permValTabPtr)) == NULL) ||
        (permValNbPtr == NULL))
        return RET_GEN_ERR_INVARG;

    /* Init local variables */
    iNbPermVal = *permValNbPtr;

    /*  Init filed rank in permitted tab : all permitted value authorised   */
    for (i = 0; i < iNbPermVal; i++)
        permValTab[i].rank = TRUE;

    /*  Find administration function  */
    if (createFlag == TRUE)
        createFlagPtr = &createFlag;
    if (updateFlag == TRUE)
        updateFlagPtr = &updateFlag;
    for (i = 0; i < iNbPermVal; i++)
    {
        DBA_CheckOpEntAuth(dictFctEn,
                           createFlagPtr,
                           updateFlagPtr,
                           (short) statusEn,
                           (OPNAT_ENUM) permValTab[i].value,
                           NullEntity,
                           NULL,
                           NULL,
                           0,               /*  FIH-REF10983-050210 */
                           NULL);           /*  FIH-REF10983-050210 */
        if (((createFlagPtr != NULL) &&
             (createFlag == FALSE)) ||
            ((updateFlagPtr != NULL) &&
             (updateFlag == FALSE)))
            permValTab[i].rank = FALSE;
    }

    /* Construct permValTab */
    if ((permValNbPtr != NULL) && (permValTabPtr != NULL))
    {
        *permValNbPtr = 0;
        for (i = 0; i < iNbPermVal; i++)
        if (permValTab[i].rank == TRUE)
            (*permValNbPtr)++;

        if (*permValNbPtr != 0)
        {
            *((PERMITED_VALUES_STP*) permValTabPtr) = new PermitedValuesClass [*permValNbPtr];
            if (*((PERMITED_VALUES_STP*) permValTabPtr) == nullptr)
            {
                MSG_RETURN(RET_MEM_ERR_ALLOC);
            }
            else
            {
                *permValNbPtr = 0;
                for (i = 0; i < iNbPermVal; i++)
                {
                    if (permValTab[i].rank == TRUE)
                    {
                        (*((PERMITED_VALUES_STP*) permValTabPtr))[(*permValNbPtr)++] = permValTab[i];
                    }
                }
            }
        }
        else
            *((PERMITED_VALUES_STP*) permValTabPtr) = NULL;

        delete [] permValTab;
        permValTab = nullptr;
    }
    return RET_SUCCEED;
}



/************************************************************************
**
**  Function    :   DBA_CheckCreateEntity
**
**  Description :   Check the right to create a specific entity
**
**  Argument    :   DICT_T      dictFctEn       : Function dict_id
**		            OBJECT_ENUM enObject        : Entity to test
**		            FLAG_T*     pflagCreate     : Create Flag
**		            FLAG_T*     pflagVisible    : Visible Flag
**
**  Return      :   RET_CODE
**
**  Creation	:   FPL-REF10234-040507
**  Modif       :   FIH-REF10234-040601 Rename
**
*************************************************************************/
RET_CODE DBA_CheckCreateEntity  ( DICT_T       dictFctEn
                                , OBJECT_ENUM  enObject
                                , FLAG_T       *pflagCreate
                                , FLAG_T       *pflagVisible)
{
    int                 s,
                        iNbRows;            /*  HFI-PMSTA-13562-120125  */
    FLAG_T              createFlag,
                        visibleFlag,
                        viewFlag,
                        flagFound;          /*  HFI-PMSTA-13562-120125  */
    DICT_FCT_STP        fctStp;
    DICT_T              dictObject;


    /*  Security test                                                   */
    if (pflagCreate == NULL)
        return RET_GEN_ERR_INVARG;

    /*  Init variables                                                  */
    createFlag  = FALSE;
    visibleFlag = TRUE;
    viewFlag    = TRUE;
    DBA_GetDictId(enObject,&dictObject);
    iNbRows = DBA_GetDictFctRows();

    /*  Find if there is one line in func secu prof compo invisible     */
    /*  Code review: check first funcSecuProfCompo that matches         */  /*  HFI-PMSTA-13562-120125  */
    /*  the entity: if it exists do not check entity NULL               */
    flagFound = FALSE;
    for ( s = 0 ; (s < iNbRows) && (visibleFlag == TRUE) ; s++)
    {
        fctStp = DBA_GetDictFctStp(s);
        if ((fctStp->dictId == dictFctEn) &&
            (fctStp->entityDictId == dictObject))
        {
            visibleFlag = fctStp->visibleFlag;
            flagFound = TRUE;
        }
    }
    if (flagFound == FALSE)
    {
        for ( s = 0 ; (s < iNbRows) && (visibleFlag == TRUE) ; s++)
        {
            fctStp = DBA_GetDictFctStp(s);
            if ((fctStp->dictId == dictFctEn) &&
                (fctStp->entityDictId == 0))
                visibleFlag = fctStp->visibleFlag;
        }
    }

    /*  Find if there is one line in func secu prof compo mot viewable  */
    flagFound = FALSE;
    for ( s = 0 ; (s < iNbRows) && (viewFlag == TRUE) ; s++)
    {
        fctStp = DBA_GetDictFctStp(s);
        if ((fctStp->dictId == dictFctEn) &&
            (fctStp->entityDictId == dictObject))
        {
            viewFlag = fctStp->viewFlag;
            flagFound = TRUE;
        }
    }
    if (flagFound == FALSE)
    {
        for ( s = 0 ; (s < iNbRows) && (viewFlag == TRUE) ; s++)
        {
            fctStp = DBA_GetDictFctStp(s);
            if ((fctStp->dictId == dictFctEn) &&
                (fctStp->entityDictId == 0))
                viewFlag = fctStp->viewFlag;
        }
    }

    /*  Check the right                                                 */
    if ((visibleFlag == TRUE) &&
        (viewFlag == TRUE))
    {
        DBA_CheckOpEntAuth ( dictFctEn
                           , &createFlag
                           , NULL
                           , 0
                           , OpNat_None
                           , enObject
                           , NULL
                           , NULL
                           , 0                  /*  FIH-REF10983-050210 */
                           , NULL               /*  FIH-REF10983-050210 */
                           );
    }
    else
    {
        createFlag = FALSE;
    }

    if (pflagCreate != NULL)
        *pflagCreate = createFlag;

    if (pflagVisible != NULL)
        *pflagVisible = visibleFlag;

    return RET_SUCCEED;
}


/************************************************************************
**
**  Function    :   DBA_CheckCreateOperation
**
**  Description :   Check current given operation status authorization.
**
**  Argument    :   DICT_FCT_ENUM   dictFctEn     : Function type
**		            FLAG_T*         createFlagPtr : Create Flag
**
**  Return      :   RET_CODE
**
**  Creation	:   FIH - 980616 - REF1504
**  Modif       :
**
*************************************************************************/
RET_CODE    DBA_CheckCreateOperation(DICT_T                 dictFctEn,
                                     FLAG_T*                createFlagPtr,
                                     FLAG_T*                visibleFlagPtr,
                                     int                    iNbPermVal,
                                     PERMITED_VALUES_STP    permvalStatus)
{
    PERMITED_VALUES_STP permValOpTypeStp = NULL;
    int                 iNbOpType;
    short               s;
    FLAG_T              createFlag,
                        visibleFlag,        /*  FIH-REF6203-010806  */
                        viewFlag,           /*  FIH-REF6203-010806  */
                        visibleAllFlag,     /*  FPL-PMSTA09777-100518   */
                        viewAllFlag,        /*  FPL-PMSTA09777-100518   */
                        foundFlag;          /*  FPL-PMSTA09777-100518   */
    DICT_T              opDictId;           /*  FIH-REF6203-010806  */
    DICT_FCT_STP        fctStp;             /*  FIH-REF6203-010806  */

    /*  Security test   */
    if (createFlagPtr == NULL)
        return RET_GEN_ERR_INVARG;

    /*  Init variables  */
    createFlag = FALSE;
    visibleFlag = TRUE;
    viewFlag = TRUE;
    visibleAllFlag = TRUE;  /*  FPL-PMSTA09777-100518   */
    viewAllFlag = TRUE;     /*  FPL-PMSTA09777-100518   */

    /*  FIH-REF6203-010806  Test visible and view flag  */
    DBA_GetDictId(Op, &opDictId);

    /*  FIH-REF6203-010806  */
    /*  FPL-PMSTA09777-100518 must be split in two part: one for "all" and one for specific entity
    for (s = 0;(s < DBA_GetDictFctRows()) && (visibleFlag == TRUE); s++)
    {
        fctStp = DBA_GetDictFctStp(s);
        if ((fctStp->dictId == dictFctEn) &&
            ((fctStp->entityDictId == 0) ||
             (fctStp->entityDictId == opDictId)))
            visibleFlag = fctStp->visibleFlag;
    }
    for (s = 0;(s < DBA_GetDictFctRows()) && (viewFlag == TRUE); s++)
    {
        fctStp = DBA_GetDictFctStp(s);
        if ((fctStp->dictId == dictFctEn) &&
            ((fctStp->entityDictId == 0) ||
             (fctStp->entityDictId == opDictId)))
            viewFlag = fctStp->viewFlag;
    }*/
    /***    FPL-PMSTA09777-100518 begin of changes  ***/
    /*  visible "all"       */
    for (s = 0;(s < DBA_GetDictFctRows()) && (visibleAllFlag == TRUE); s++)
    {
        fctStp = DBA_GetDictFctStp(s);
        if ((fctStp->dictId == dictFctEn) &&
            (fctStp->entityDictId == 0))
            visibleAllFlag = fctStp->visibleFlag;
    }
    /*  visible "entity"    */
    foundFlag = FALSE ;
    for (s = 0;(s < DBA_GetDictFctRows()) && (foundFlag== FALSE); s++)
    {
        fctStp = DBA_GetDictFctStp(s);
        if ((fctStp->dictId == dictFctEn) &&
            (fctStp->entityDictId == opDictId))
            {
                visibleFlag = fctStp->visibleFlag;
                foundFlag = TRUE ;
            }
    }
    /* if no scurity found for curent entity, we use right of all entity   */
    if (foundFlag == FALSE)
        visibleFlag = visibleAllFlag;

    /*  view "all"          */
    for (s = 0;(s < DBA_GetDictFctRows()) && (viewAllFlag == TRUE); s++)
    {
        fctStp = DBA_GetDictFctStp(s);
        if ((fctStp->dictId == dictFctEn) &&
            (fctStp->entityDictId == 0))
            viewAllFlag = fctStp->viewFlag;
    }
    /*  view "entity"       */
    foundFlag = FALSE ;
    for (s = 0;(s < DBA_GetDictFctRows()) && (foundFlag== FALSE); s++)
    {
        fctStp = DBA_GetDictFctStp(s);
        if ((fctStp->dictId == dictFctEn) &&
            (fctStp->entityDictId == opDictId))
            {
                viewFlag = fctStp->viewFlag;
                foundFlag = TRUE ;
            }
    }
    /* if no scurity found for curent entity, we use right of all entity   */
    if (foundFlag == FALSE)
        viewFlag = viewAllFlag;
    /***    FPL-PMSTA09777-100518 end of changes    ***/

    if ((visibleFlag == TRUE) &&
        (viewFlag == TRUE))
    {

        /*  Test on each entity    */
        DBA_FillPermValTab(OpDomainEnt, OpDomain_OpNatEn, (PTR) &permValOpTypeStp, &iNbOpType, 0);      /*  FIH-REF3996-990924  */

        /*  Be careful that the permitted value rank must be set to -1  */                              /*  FIH-REF11260-050621 */
        if ((permvalStatus != NULL) &&
            (iNbPermVal > 0))
        {
            for (s = 0; s < iNbPermVal; s++)
                permvalStatus[s].rank = -1;
        }

        for (s = 0; (s < iNbOpType) && (createFlag == FALSE); s++)
            DBA_CheckOpEntAuth(dictFctEn,
                               &createFlag,
                               NULL,
                               0,
                               (OPNAT_ENUM) permValOpTypeStp[s].value,
                               NullEntity,
                               NULL,
                               NULL,
                               iNbPermVal,                          /*  FIH-REF10983-050210 */
                               permvalStatus                        /*  FIH-REF10983-050210 */
                              );

        if (permValOpTypeStp != NULL)
        {
            delete [] permValOpTypeStp;
            permValOpTypeStp = nullptr;
        }
    }
    else
        createFlag = FALSE;

    if (createFlagPtr != NULL)
        *createFlagPtr = createFlag;
    if (visibleFlagPtr != NULL)
        *visibleFlagPtr = visibleFlag;

    return RET_SUCCEED;
}

/************************************************************************
**
**  Function    :   DBA_CheckStatusOpPermVal
**
**  Description :   Manage a value of operation status nature
**
**  Argument    :   DICT_FCT_STP        fctStp,
**                  int*                permValNbPtr
**                  PERMITED_VALUES_STP *permValTabPtr
**                  FLAG_T              newFlag
**                  DICT_FCT_STP*       fctTab
**
**  Return      :   RET_CODE
**
**  Creation	:   FIH - 980618 - REF1504
**
*************************************************************************/
STATIC RET_CODE	DBA_CheckStatusOpPermVal(DICT_FCT_STP fctStp,
                                         long value,
                                         DICT_FCT_STP *fctOldStpPtr,
                                         SMALLINT_T *flagPtr,
                                         FLAG_T newFlag)
{
    /* Check given arguments */
    if ((fctStp == NULL) ||
        (flagPtr == NULL) ||
        (fctOldStpPtr == NULL)
       ) MSG_RETURN(RET_GEN_ERR_INVARG);

    if ((fctStp->minOpStatus <= value) &&
        (value <= fctStp->maxOpStatus))
    {
        if (*flagPtr == -1)
        {
            *flagPtr = newFlag;
            *fctOldStpPtr = fctStp;
        }
        else if ((*fctOldStpPtr != NULL) &&
                 ((*fctOldStpPtr)->opSecuRank <= fctStp->opSecuRank))
        {
            if ((*fctOldStpPtr)->opSecuRank == fctStp->opSecuRank)
            {
                if (*flagPtr == TRUE)
                {
                    *flagPtr = newFlag;
                    *fctOldStpPtr = fctStp;
                }
            }
            else
            {
                *flagPtr = newFlag;
                *fctOldStpPtr = fctStp;
            }
        }
    }
    return RET_SUCCEED;
}

/************************************************************************
**
**  Function    :   DBA_CheckOpPermVal
**
**  Description :   Construct step by step permValTab.
**
**  Argument    :   DICT_FCT_STP        fctStp,
**                  int*                permValNbPtr
**                  PERMITED_VALUES_STP *permValTabPtr
**                  FLAG_T              newFlag
**                  DICT_FCT_STP*       fctTab
**
**  Return      :   RET_CODE
**
**  Cr�ation	:   ROI - 961211 - DVP302
**
*************************************************************************/
STATIC RET_CODE	DBA_CheckOpPermVal(DICT_FCT_STP fctStp,
                                   int* permValNbPtr,
                                   PERMITED_VALUES_STP* permValTabPtr,
                                   FLAG_T newFlg,
                                   DICT_FCT_STP* fctTab)
{
    short   i, value;

    /* Check given arguments */
    if ((fctStp == NULL) ||
        (permValNbPtr == NULL) ||
        (permValTabPtr == NULL)
       ) MSG_RETURN(RET_GEN_ERR_INVARG);

    /* Loop checking if current value is already in permValTab */
    for (i = 0; i < *permValNbPtr; i++)
    {
        value = (short) (*permValTabPtr)[i].value;
        if ((fctStp->minOpStatus <= value) &&
            (value <= fctStp->maxOpStatus))
        {
            if (fctTab == NULL)
            {
                if ((*permValTabPtr)[i].rank == TRUE)
                    (*permValTabPtr)[i].rank = newFlg;
            }
            else    /*  Only for create mode    */
            {
                if ((*permValTabPtr)[i].rank == -1)
                {
                    (*permValTabPtr)[i].rank = newFlg;
                    fctTab[i] = fctStp;
                }
                else if ((fctTab[i] != NULL) &&
                         (fctTab[i]->opSecuRank <= fctStp->opSecuRank))
                {
                    if (fctTab[i]->opSecuRank == fctStp->opSecuRank)
                    {
                        if ((*permValTabPtr)[i].rank == TRUE)
                        {
                            (*permValTabPtr)[i].rank = newFlg;
                            fctTab[i] = fctStp;
                        }
                    }
                    else
                    {
                        (*permValTabPtr)[i].rank = newFlg;
                        fctTab[i] = fctStp;
                    }
                }
            }
        }
    }
    return RET_SUCCEED;
}

/************************************************************************
**
**  Function    :   DBA_CheckOpAdmAuth
**
**  Description :   Check current given operation status authorization.
**
**  Argument    :   short opStatus,
**		            OPNAT_ENUM  operNatEn
**		            OBJECT_ENUM entityRef
**		            ID_T        typeId
**		            ID_T        subtypeId
**		            ENUM_T      natureEn
**		            FLAG_T*     createFlagPtr
**		            FLAG_T*     updateFlagPtr
**		            FLAG_T*     deleteFlagPtr
**		            int*        permValNbPtr
**		            PTR         permValTabPtr
**
**  Return      :   RET_CODE
**
**  Creation	:   ROI - 961208 - DVP302
**  Modif       :   FIH - 980205 - REF893.2
**  Modif       :   FIH - 980428 - REF1503
**
*************************************************************************/
RET_CODE    DBA_CheckOpAdmAuth(DICT_T           dictFctEn,
                               short            opStatus,
                               OPNAT_ENUM       operNatEn,
                               OBJECT_ENUM      checkRef,       /*  FIH-REF5512-001211  */
                               ID_T             typeId,
                               ID_T             subtypeId,
                               ENUM_T           natureEn,       /*  FIH-REF5512-001211  */
                               FLAG_T*          createFlagPtr,
                               FLAG_T*          updateFlagPtr,
                               FLAG_T*          deleteFlagPtr,
                               int*             permValNbPtr,
                               PTR              permValTabPtr)
{
    PERMITED_VALUES_STP permValTab    = NULL;
    DICT_FCT_STP        *fctTab       = NULL,
                        fctStp        = NULL,
                        createFctStp  = NULL,
                        deleteFctStp  = NULL,
                        updateFctStp  = NULL;

    std::vector<DICT_FCT_ST> *fctDictTab;
    DICT_T              opDictId,
                        entDictId;
    SMALLINT_T          updateFlag = -1, deleteFlag = -1, createFlag = -1;
    OBJECT_ENUM         entityRef;
    DBA_DYNST_ENUM      dynStEn;
    short               i = 0, permValNb = 0;
    int                 iNbRows ;                   /*  FPL-REF11314-060516 */
    FLAG_T              bCreate, bUpdate, bDelete ; /*  FPL-PMSTA09945-100527   */

    /*  First test : special case for security in operation list
    if (operNatEn == OpNat_None)
    {
        updateFlagPtr = NULL;
        deleteFlagPtr = NULL;
    }
*/
    /* Init local variables */
    entityRef = NullEntity;
    entDictId = 0;
    DBA_GetDictId(Op, &opDictId);
    DBA_GetDictFctTab(fctDictTab);       /*  FPL-REF11314-060516 */
    iNbRows = static_cast<int>(fctDictTab->size());

    /*  FIH-REF5512-001211  Manage Notepad by security  */
    if (checkRef != NullEntity)
    {
        entityRef = checkRef;
        DBA_GetDictId(entityRef, &entDictId);
    }
    else if (operNatEn != OpNat_None)
    {
        OPE_OperNatToDictEnum(operNatEn,&dynStEn,&entityRef);
        DBA_GetDictId(entityRef, &entDictId);
    }

    /*  Create a table with DictFct */
    if (((createFlagPtr != NULL) ||
         (updateFlagPtr != NULL))&&
        ((permValNbPtr != NULL) &&
        ((fctTab) = (DICT_FCT_STP*) CALLOC(*permValNbPtr, sizeof(DICT_FCT_STP))) == NULL))
        MSG_RETURN(RET_MEM_ERR_ALLOC);

    /* Init permValTab if necessary */
    if ((permValNbPtr != NULL) && (permValTabPtr != NULL))
    {
        permValNb = (short)(*permValNbPtr);
        permValTab = *((PERMITED_VALUES_STP*) permValTabPtr);
        /*  Specific case for List, Instr and Notepad                         */  /*  FIH-REF10288-040601 */
        /*  Cancelled is only authorised value in this case             */
        if (DBA_GetEntitySecuredType(checkRef) == SecuType_Standard)
        {
            permValTab[0].rank = -1;
            if (*permValNbPtr > 1)
            {
                for (i = 0; i < permValNb; i++)
                {
                    if (permValTab[i].value != OpStat_Cancelled)
                        permValTab[i].rank = FALSE;
                }
            }
        }
        else
        {
            for (i = 0; i < *permValNbPtr; i++)
                permValTab[i].rank = -1;
        }
    }

    /*  Fill opSecuRank     */
    for (i = 0; i < iNbRows; i++)       /*  FPL-REF11314-060516 SV_DictFctRows  */
    {
        fctStp = &((*fctDictTab)[i]);      /*  FPL-REF11314-060516 SV_DictFctTab   */
        fctStp->opSecuRank = 0;
        if (fctStp->dictId == dictFctEn)/* &&
            (fctStp->accesStatus == DictFctAuth_Ok))*/ /* FPL-020926 for test the module licence */ /*  FPL-PMSTA09945-100527 move lower    */
        {
            if (fctStp->entityDictId == 0)
            {
                if (fctStp->typeId == 0)
                    fctStp->opSecuRank = 1;
            }
            else if ((checkRef == NullEntity) &&        /*  FIH-REF5512-001211  */
                     (fctStp->entityDictId == opDictId))
            {
                if ((fctStp->subtypeId == subtypeId) && (subtypeId != 0))
                    fctStp->opSecuRank = 6;
                else if ((fctStp->typeId == typeId) && (fctStp->subtypeId == 0) && (typeId != 0))
                    fctStp->opSecuRank = 4;
                else if (fctStp->typeId == 0)
                    fctStp->opSecuRank = 2;
            }
            else if ((entityRef != NullEntity) && (fctStp->entityDictId == entDictId))
            {
/*	            OPE_DictEnumToOperNat(info->entityRef, &operNat);       */
                if ((fctStp->subtypeId == subtypeId) && (subtypeId != 0))
                    fctStp->opSecuRank = 7;
                else if ((fctStp->typeId == typeId) && (fctStp->subtypeId == 0) && (typeId != 0))
                    fctStp->opSecuRank = 5;
                else if (fctStp->typeId == 0)
                    fctStp->opSecuRank = 3;
            }
        }
    }

    for (i = 0; i < iNbRows; i++)       /*  FPL-REF11314-060516 SV_DictFctRows  */
    {
        fctStp = &((*fctDictTab)[i]);      /*  FPL-REF11314-060516 SV_DictFctTab   */
        if (fctStp->opSecuRank != 0)
        {
            /*  FPL-PMSTA09945-100527 move here and manage rights   */
            if (fctStp->accesStatus == DictFctAuth_Ok)
            {
                bCreate = fctStp->createFlag ;
                bUpdate = fctStp->updateFlag ;
                bDelete = fctStp->deleteFlag ;
            }
            else
            {
                bCreate = FALSE ;
                bUpdate = FALSE ;
                bDelete = FALSE ;
            }

            /*  Check Create flag   */
            if (createFlagPtr != NULL)
            {
                if ((permValNbPtr != NULL) &&
                    (permValTabPtr != NULL))
                    DBA_CheckOpPermVal(fctStp,
                                       permValNbPtr,
                                       (PERMITED_VALUES_STP*) permValTabPtr,
                                       bCreate,     /*  FPL-PMSTA09945-100527   fctStp->createFlag  */
                                       fctTab);
                /*  FIH-REF4281-000229  */
                DBA_CheckStatusOpPermVal(fctStp,
                                         opStatus,
                                         &createFctStp,
                                         &createFlag,
                                         bCreate);  /*  FPL-PMSTA09945-100527   fctStp->createFlag  */
            }
            /*  Check Update flag   */
            if (updateFlagPtr != NULL)
            {
                if ((permValNbPtr != NULL) &&
                    (permValTabPtr != NULL))
                    DBA_CheckOpPermVal(fctStp,
                                       permValNbPtr,
                                       (PERMITED_VALUES_STP*) permValTabPtr,
                                       bUpdate,     /*  FPL-PMSTA09945-100527   fctStp->updateFlag  */
                                       fctTab);
                DBA_CheckStatusOpPermVal(fctStp,
                                         opStatus,
                                         &updateFctStp,
                                         &updateFlag,
                                         bUpdate);  /*  FPL-PMSTA09945-100527   fctStp->updateFlag  */
            }
            /*  Check Delete flag   */
            if (deleteFlagPtr != NULL)
                DBA_CheckStatusOpPermVal(fctStp,
                                         opStatus,
                                         &deleteFctStp,
                                         &deleteFlag,
                                         bDelete);  /*  FPL-PMSTA09945-100527   fctStp->deleteFlag  */
        }
    }
    FREE(fctTab);

    /* Construct permValTab */
    if ((permValNbPtr != NULL) && (permValTabPtr != NULL))
    {
        *permValNbPtr = 0;
        for (i = 0; i < permValNb; i++)
        {
            if (permValTab[i].rank == TRUE)
                (*permValNbPtr)++;
        }

        *((PERMITED_VALUES_STP*) permValTabPtr) = NULL;
        if (*permValNbPtr != 0)
        {
            *((PERMITED_VALUES_STP*) permValTabPtr) = new PermitedValuesClass [*permValNbPtr];
            if (*((PERMITED_VALUES_STP*) permValTabPtr) == NULL)
            {
                MSG_RETURN(RET_MEM_ERR_ALLOC);
            }
            else
            {
                *permValNbPtr = 0;
                for (i = 0; i < permValNb; i++)
                {
                    if (permValTab[i].rank == TRUE)
                    {
                        (*((PERMITED_VALUES_STP*) permValTabPtr))[(*permValNbPtr)++] = permValTab[i];
                    }
                }
            }
        }
        delete [] permValTab;
        permValTab = nullptr;
    }

    /* Setup given variables */
    if (createFlagPtr != NULL)
    {
        if (((permValNbPtr != NULL) &&
            (*permValNbPtr != 0)) ||
            (createFlag == TRUE))
            *createFlagPtr = TRUE;
        else
            *createFlagPtr = FALSE;
    }
    if (updateFlagPtr != NULL)
    {
        if (updateFlag == TRUE)
            *updateFlagPtr = TRUE;
        else
            *updateFlagPtr = FALSE;
    }
    if (deleteFlagPtr != NULL)
    {
        if (deleteFlag == TRUE)
            *deleteFlagPtr = TRUE;
        else
            *deleteFlagPtr = FALSE;
    }
    return RET_SUCCEED;
}

/************************************************************************
**
**  Function    :   DICT_DynStAlloc
**
**  Description :   Allco given DBA_DYNST_ENUM.
**
**  Argument    :   DBA_DYNST_ENUM	stEnum
**
**  Return      :   RET_CODE
**
**  Creation	:   ROI - 990212 - REF2644
**  Modif.		:   ROI - 990624 - REF3537
**
*************************************************************************/
DBA_DYNFLD_STP	DICT_DynStAlloc(DBA_DYNST_ENUM stEnum)
{
    DBA_DYNFLD_STP	dynStp;

    /* Test given arguments */
    if (stEnum == NullDynSt)
        return NULL;

    dynStp = (DBA_DYNFLD_STP) CALLOC(EV_DynStPtr[stEnum].fldNbr,
                                     sizeof(DBA_DYNFLD_ST)
                                    );
    if (dynStp != NULL)
    {
        DICT_DynStDatatypeSet(dynStp, stEnum);

        EV_DynStPtr[stEnum].allocCpt++; /* REF9789 - LJE - 040102 */
    }

    return dynStp;

}

/************************************************************************
**
**  Function    :   DICT_DynStTabAlloc
**
**  Description :   Allco given DBA_DYNST_ENUM.
**
**  Argument    :   DBA_DYNST_ENUM	stEnum
**
**  Return      :   RET_CODE
**
**  Creation	:   REF8844 - LJE - 030321
**  Modif.		:
**
*************************************************************************/
DBA_DYNFLD_STP	DICT_DynStTabAlloc(DBA_DYNST_ENUM stEnum, int nbr)
{
    DBA_DYNFLD_STP	dynStp;
    int             i;

    /* Test given arguments */
    if (stEnum == NullDynSt)
        return NULL;

    dynStp = (DBA_DYNFLD_STP) CALLOC(EV_DynStPtr[stEnum].fldNbr*nbr, sizeof(DBA_DYNFLD_ST));

    if (dynStp != NULL)
    {
        for (i=0; i<nbr; i++)
        {
            DICT_DynStDatatypeSet(&(dynStp[EV_DynStPtr[stEnum].fldNbr*i]), stEnum);
        }
    }

    return dynStp;

}

/************************************************************************
**
**  Function    :   DICT_DynStTabRealloc
**
**  Description :   Allco given DBA_DYNST_ENUM.
**
**  Argument    :   DBA_DYNST_ENUM	stEnum
**
**  Return      :   RET_CODE
**
**  Creation	:   REF8844 - LJE - 030331
**
**  Modif.		:   PMSTA-16443 - 230713 - PMO : Add confirmation-to-continue messages in case not enough free memory is available for the GUI when loading data from a financial server
**
**
*************************************************************************/
DBA_DYNFLD_STP	DICT_DynStTabRealloc(DBA_DYNFLD_STP	dynStTab, DBA_DYNST_ENUM stEnum, int nbr)
{
    DBA_DYNFLD_STP	dynStp;
    int             i;

    /* Test given arguments */
    if (stEnum == NullDynSt)
        return NULL;

    dynStp = (DBA_DYNFLD_STP) REALLOC(dynStTab, EV_DynStPtr[stEnum].fldNbr * nbr * sizeof(DBA_DYNFLD_ST));

    if (dynStp != NULL)
    {
        for (i=0; i<nbr; i++)
        {
            DICT_DynStDatatypeSet(&(dynStp[EV_DynStPtr[stEnum].fldNbr*i]), stEnum);
        }
    }
    else
    { /* PMSTA-16443 - 230713 - PMO */
        FREE_DYNST(dynStTab, DataDef);
    }

    return dynStp;

}

/************************************************************************
**
**  Function    :   DICT_DynStWithoutDefAlloc
**
**  Description :   Allco given DBA_DYNST_ENUM.
**
**  Argument    :   int fldNbr : Number of fields
**
**  Return      :   Pointer to the dynamic structure
**
**  Creation	:   REF8844 - LJE - 030331
**  Modif.		:
**
*************************************************************************/
DBA_DYNFLD_STP	DICT_DynStWithoutDefAlloc(int fldNbr)
{
    DBA_DYNFLD_STP	dynStp;

    dynStp = (DBA_DYNFLD_STP) CALLOC(fldNbr,
                                     sizeof(DBA_DYNFLD_ST)
                                    );

    return dynStp;
}

/************************************************************************
**
**  Function    :   DICT_DynStWithDefAlloc
**
**  Description :
**
**  Argument    :   int fldNbr : Number of fields
**
**  Return      :   Pointer to the dynamic structure
**
**  Creation	:   PMSTA-41519 - DDV - 200820
**  Modif.		:
**
*************************************************************************/
DBA_DYNFLD_STP	DICT_DynStWithDefAlloc(int fldNbr, const DATATYPE_ENUM *datatypeTab)
{
    DBA_DYNFLD_STP	dynStp;

    dynStp = (DBA_DYNFLD_STP)CALLOC(fldNbr, sizeof(DBA_DYNFLD_ST));

    if (datatypeTab != NULL)
    {
        for (int i = 0; i < fldNbr; i++)
        {
            dynStp[i].dataType = (unsigned char) datatypeTab[i];
            dynStp[i].dynStEnum = NullDynSt;
        }
    }

    return dynStp;
}

/************************************************************************
**
**  Function    :   DICT_GetAllocKbSizeDynStWithoutDefTabAlloc
**
**  Description :   Compute the memory that will we allocated in kb
**
**  Argument    :   int fldNbr   : Number of fields
**                  int dynStNbr : Numbers sturcture to allocate
**
**  Return      :   Memory allocated in kb
**
**  Creation	:   PMSTA-16443 - 230713 - PMO : Add confirmation-to-continue messages in case not enough free memory is available for the GUI when loading data from a financial server
**
**  Modif.		:
**
*************************************************************************/
size_t DICT_GetAllocKbSizeDynStWithoutDefTabAlloc(const int fldNbr, const int dynStNbr)
{
    return (fldNbr * dynStNbr * sizeof(DBA_DYNFLD_ST)) >> 10;
}

/************************************************************************
**
**  Function    :   DICT_DynStWithoutDefTabAlloc
**
**  Description :   Allco given DBA_DYNST_ENUM.
**
**  Argument    :   int fldNbr   : Number of fields
**                  int dynStNbr : Numbers sturcture to allocate
**
**  Return      :   pointer to tab
**
**  Creation	:   REF8844 - LJE - 030321
**  Modif.		:   PMSTA-16443 - 230713 - PMO : Add confirmation-to-continue messages in case not enough free memory is available for the GUI when loading data from a financial server
**
*************************************************************************/
DBA_DYNFLD_STP	DICT_DynStWithoutDefTabAlloc(int fldNbr, int dynStNbr)
{
    return (DBA_DYNFLD_STP) CALLOC(fldNbr*dynStNbr, sizeof(DBA_DYNFLD_ST));
}

/************************************************************************
**
**  Function    :   DICT_DynStWithoutDefTabRealloc
**
**  Description :   Allco given DBA_DYNST_ENUM.
**
**  Argument    :   int fldNbr   : Number of fields
**                  int dynStNbr : Numbers sturcture to allocate
**
**  Return      :   pointer to tab
**
**  Creation	:   REF8844 - LJE - 030321
**  Modif.		:
**
*************************************************************************/
DBA_DYNFLD_STP	DICT_DynStWithoutDefTabRealloc(DBA_DYNFLD_STP dynStTab, int fldNbr, int dynStNbr)
{
    return (DBA_DYNFLD_STP) REALLOC(dynStTab, fldNbr*dynStNbr*sizeof(DBA_DYNFLD_ST));

}

/************************************************************************
**
**  Function    :   DICT_DynStAllocSupplFld
**
**  Description :   Alloc given DBA_DYNST_ENUM and supplementary fields.
**		    Update fields nature according to DBA_DYNST_ENUM
**
**  Argument    :   DBA_DYNST_ENUM	stEnum
**		    int			totalFldNbr
**
**  Return      :   RET_CODE
**
**  Creation	:   RAK - 990602 - REF3729
**
*************************************************************************/
DBA_DYNFLD_STP	DICT_DynStAllocSupplFld(DBA_DYNST_ENUM stEnum, int totalFldNbr)
{
    DBA_DYNFLD_STP	dynStp;

    /* Test given arguments */
    if (stEnum == NullDynSt)
        return NULL;

    /* REF8844 - LJE - 030331 */
    if (EV_DynStPtr[stEnum].fldNbr >= totalFldNbr)
    {
        dynStp = DICT_DynStAlloc(stEnum);
    }
    else
    {
        dynStp = (DBA_DYNFLD_STP) CALLOC(totalFldNbr, sizeof(DBA_DYNFLD_ST));

        if (dynStp != NULL)
            DICT_DynStDatatypeSet(dynStp, stEnum);

    }

    return dynStp;

}

/************************************************************************
**
**  Function    :   DICT_DynStDatatypeSet
**
**  Description :   Set dataype for each field for given DBA_DYNST_ENUM.
**
**  Argument    :   DBA_DYNFLD_STP	dynStp,
**					DBA_DYNST_ENUM	stEnum
**
**  Return      :   RET_CODE
**
**  Creation	:   ROI - 990212 - REF2644
**
*************************************************************************/
RET_CODE	DICT_DynStDatatypeSet(DBA_DYNFLD_STP dynStp, DBA_DYNST_ENUM stEnum)
{
    int	i;
    int fldNbr;

    /* Test given arguments */
    if ((stEnum == NullDynSt) ||
        (dynStp == NULL)
       ) return RET_GEN_ERR_INVARG;

    fldNbr = EV_DynStPtr[stEnum].fldNbr;

    for (i=0; i < fldNbr ; i++)
    {
        dynStp[i].dataType  = (unsigned char) EV_DynStPtr[stEnum].dynStDefPtr[i].dataType;
        dynStp[i].index     = (short) i;
        dynStp[i].dynStEnum = (short) stEnum;  /* REF9303 - LJE - 030904 */
    }

    return RET_SUCCEED;

}

/************************************************************************
**
**  Function    :   DICT_EntityHasDefValue
**
**  Description :   Check if given entity may have default values.
**
**  Argument    :   OBJECT_ENUM entity
**
**  Return      :   FLAG_T
**
**  Creation:   ROI - 971029 - REF469
**  Modif.	:   FIH - 971111 - REF905	OpDomainEnt has default values
**  Modif.	:   FIH - 981007 - REF2273	Server connect has default values
**  Modif.	:   ROI - 981207 - REF2644	FctResult has default values
**  Modif.	:   ROI - 990622 - REF3729	SearchLnk has default values
**
*************************************************************************/
FLAG_T	DICT_EntityHasDefValue(OBJECT_ENUM entity)
{
    FLAG_T	entityHasDefVal;
    DICT_ENTITY_STP pdictent;

    /* Test given argument */
    if ((entity > NullEntity) && (entity <= LASTENTITYOBJECT))
    {
        /* REF8844 - LJE - 030415 */
        if (entity == DictDataTp ||
            entity == DictEntity ||
            entity == DictCriter ||
            entity == DictAttr ||
            entity == DictLabel ||
            entity == DictPermVal ||
            entity == DictLang ||
/*		    entity == DictFct ||            HFI-PMSTA-14985-120913  */
            entity == DataDesc ||     /*  FIH-REF5058-020826  */
            entity == DataDisp ||     /*  FIH-REF5058-020826  */
            entity == Pos ||
            entity == BalPos ||
            entity == Op ||
            entity == OpCompo ||
            entity == EventSched ||
            entity == EPos ||
            entity == CommMgr ||
            entity == AdminMgr ||
            entity == PtfReturn ||
            entity == EvtExcl ||
            entity == InstrFlow ||
            entity == Ytm ||
            entity == UInter ||
            entity == TabModifStat ||
/*          entity == ApplParam ||          HFI-PMSTA-28972-171101  */
            entity == CheckList ||
            entity == DocIndex ||
            entity == EStratLnk ||
            entity == StratEltDetail ||
            entity == EOp ||
            entity == BalPosRule ||
            entity == BalPosRuleSet ||
            entity == RuleCompo ||
            entity == Stat ||
            entity == Regr ||
            entity == ConstraintParameter ||/*  FIH-REF9764-040319  */
            entity == ExtOrder ||           /*  FIH-REF9764-040301  */ /* REF11713 - DDV - 060223 - Rename LightOrder to ExtOrder */
            entity == ExtTransaction ||     /*  FIH-REF9764-040301  */
            entity == UnMatchedExecution || /*  FIH-REF9764-040301  */
            entity == ExtExecutionEnt ||    /*  FIH-REF9764-040219  */
		    entity == UnMatchedGlExecFee || /*  FIH-REF10234-040528 */
		    entity == EventGroupingId ||    /*  HFI-PMSTA-18525-140815  */
		    entity == EventUpdate ||        /*  HFI-PMSTA-18525-140815  */
		    entity == QuickSearch ||        /*  HFI-PMSTA-18525-140815  */
		    entity == One ||                /*  HFI-PMSTA-18525-140815  */
		    entity == Empty)                /*  HFI-PMSTA-18525-140815  */
        {
            /*case UserDataProf : REF6180 - DDV - 010717 */		/* MRA - 010223 - REF5562 */
            entityHasDefVal = FALSE;
        }
        /*  Search Format Entity are not def val entities   */  /*  HFI-PMSTA-18525-140815  */
        else if ((pdictent =  DBA_GetDictEntitySt(entity)) != NULL)
        {
            if (pdictent->entNatEn == EntityNat_SearchFmt)
			    entityHasDefVal = FALSE;
            else
                entityHasDefVal = TRUE;
        }
        else
			entityHasDefVal = FALSE;
    }
    else entityHasDefVal = FALSE;

    return entityHasDefVal;
}


/************************************************************************
**
** Function    : DBA_ExtOpToExport
**
** Description :
**
** Arguments   :
**
** Return      :
**
** Creation    : sme (Tuesday April 04 2000)
**
** Last modif. : REF11780 - 100406 - PMO : Implementation of the Sybase timestamp field
**
************************************************************************/
FLAG_T DBA_FieldToExport(DBA_DYNST_ENUM inputSt,int field)
{
    if (inputSt == ExtOp )
    {
        if (field==ExtOp_DbId           ||
            field==ExtOp_OpId           ||
            field==ExtOp_ConfirmedFlg   ||
            field==ExtOp_DbStatusEn     ||
            field==ExtOp_AudUserName    ||
            field==ExtOp_AudModifDate   ||  /* REF11780 - 100406 - PMO */
            field==ExtOp_TimeStamp      ||
            field==ExtOp_AudAction)
        {
            return FALSE;
        }
        else
        {
            return TRUE;
        }
    }

/* REF8844 - LJE - 030410
    switch(field)
    {
    case ExtOp_DbId:
    case ExtOp_OpId:
    case ExtOp_ConfirmedFlg:
    case ExtOp_DbStatusEn:
    case ExtOp_AudUserName:
    case ExtOp_AudModifDate:
    case ExtOp_AudAction:
        return FALSE;
    default:
        return TRUE;
    }
*/
    else
    {
        return TRUE;
    }
}


/************************************************************************
**
**  Function    :   DBA_DispTree
**
**  Description :
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED
**
**  Creation	:   SME
**  Modif.      :
**
*************************************************************************/
STATIC void DBA_DispTree(FK_DENOM_ELM_STP dictDenomStp, int level)
{
    FK_DENOM_ELM_STP	inputDenomStpWk = dictDenomStp;
    static FILE *fp;

    if (level == 0)
    {
        fp = fopen("/tmp/debugtree.txt","a+");
        if (fp == NULL)
        {
            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO,"cannot open file /tmp/debugtree.txt");
            return;
        }

        fprintf(fp,"** start tree\n");
    }

    while (inputDenomStpWk != NULL)
    {
        if (inputDenomStpWk->denom != NULL)
        {
            int i=level;

            while (i--)
            {
                fprintf(fp,"-+");
            }
            fprintf(fp,"lev=%d denom = %s\n",level,inputDenomStpWk->denom);
            if (inputDenomStpWk->fkDenomElmNext == NULL)
            {
                inputDenomStpWk++;
            }
            else
            {
                DBA_DispTree(inputDenomStpWk->fkDenomElmNext, level +1);
                inputDenomStpWk++;
            }
        }
        else
        {
            /*fprintf(fp,"lev=%d denom = NULL\n",level);*/
            if (level > 0)
            {
                inputDenomStpWk = NULL;
            }
            else
            {
                if (inputDenomStpWk != dictDenomStp)
                {
                    inputDenomStpWk = NULL;
                }
                else
                {
                    inputDenomStpWk++;
                }
            }
        }
    }

    if (level == 0)
    {
        fprintf(fp,"** end tree\n");

        fclose(fp);
    }

    return ;
}

/************************************************************************
**
**  Function    :   getValue
**
**  Description :   currDenomSansId
**
**  Argument    :   DBA_DYNST_ENUM	stEnum
**
**  Return      :   char *
**
**  Creation    :    PMSTA-52377 -DES TAP TDL Integration -
**  Modif.      :
**
*************************************************************************/
STATIC  char * getValue(char *currDenomSansId, unsigned char   recordSeparator)
{
    char *valueStr = NULL;
    if (currDenomSansId == NULL)
        return valueStr;

    valueStr = strchr(currDenomSansId, '=');
    if (valueStr)
    {
        int len, n;
        valueStr++;
        len = SYS_StrLen(valueStr) - 1;
        valueStr[len - 1] = 0;

        n = len - 2;
        while (n >= 0)
        {
            if (valueStr[n] == recordSeparator)
            {
                valueStr[n] = 0;
                break;
            }

            n--;
        }
    }
    return valueStr;
}

/************************************************************************
**
**  Function    :   DBA_BackupExtension
**
**  Description :   Copy all the extension structure in a backup structure
**
**  Arguments   :   OBJECT_ENUM     enEntityRef     : current window
**					DBA_DYNFLD_STP  pdbadynSource   : source structure
**                  DBA_DYNFLD_STP  pdbadynDest     : destination structure
**
**  Return      :   RET_CODE
**
**	Creation	:	FIH-REF11457-050930
**
*************************************************************************/
RET_CODE DBA_BackupExtension (OBJECT_ENUM enEntityRef, DBA_DYNFLD_STP pdbadynDest, DBA_DYNFLD_STP pdbadynSource)
{
    RET_CODE            retCode;            /*  Returned value          */
    DICT_ENTITY_STP     pdictent;           /*  Global entity structure */

    if (((pdictent =  DBA_GetDictEntitySt(enEntityRef)) != NULL) &&
        (pdbadynDest != NULL))
    {
        retCode = RET_SUCCEED;

        for (auto& dictAttribStp : pdictent->attr)
        {
            if (dictAttribStp->dataTpProgN == ExtensionType)
            {
                if (pdbadynSource != NULL)
                {
                    COPY_EXTENSION_INFO(pdbadynDest, dictAttribStp->progN, pdbadynSource, dictAttribStp->progN);
                }
                else
                {
                    SET_NULL_EXTENSION(pdbadynDest, dictAttribStp->progN);
                }
            }
        }
    }
    else
        retCode = RET_GEN_ERR_INVARG;
    return retCode;
}


/************************************************************************
**
**  Function    :   DBA_ConvertDynStToString
**
**  Description :   Given a dynamic structure, resolve all foreign keys and
**                  return a string containing all the values.
**
**  Arguments   :   object          : Data type object.
**                  inputSt         : Input data type.
**                  inputData       : Input data.
**                  level           : Level of recursivity.
**                  shortDataFlg    : Is it called using a short or an all?
**                  inputDenomStp   : Points to the current denom.
**                  outputDataBuf   : Buffer that will contain the data string.
**                  convOptions     : Used for DBA_Get.
**                  importStrFlg    : Is it for archiving?
**                  flagSaveVirtual : Save virtual or not (Yes for subscription No for Gui MAcro)
**                  dbiConn         : Current connection.
**                  msgStructPtr    : Messages returned by DBA_Get.
**
**  Return      :   RET_CODE
**
**  Creation	:   GRD/XSH - 000209 - REF4204.
**
**  Modif.      :   GRD     - 010206 - REF5635. Do not use user specific format for subscription.
**                                              (use of the defaultFmt flag).
**                  GRD     - 010207 - REF5660. Forgot the 'ShortinfoType'.
**                  REF9303 - TEB - 030908 : Unicode
**                  REF9303 - 030915 - PMO : Implementation of Unicode
**
*************************************************************************/
RET_CODE DBA_ConvertDynStToString(OBJECT_ENUM           object,
                                  DBA_DYNST_ENUM        inputSt,
                                  DBA_DYNFLD_STP        inputData,
                                  int                   level,
                                  FLAG_T                shortDataFlg,   /* Is it called using a short or a all? */
                                  void                  *inputDenomStp,
                                  char                  **outputDataBuf,
                                  int                   convOptions,
                                  FLAG_T                importStrFlg,
                                  FLAG_T                flagSaveVirtual,
                                  DbiConnection&        dbiConn)
{

        return DBA_ConvertDynStToString2( object,
                                      inputSt,
                                      inputData,
                                      level,
                                      shortDataFlg,
                                      inputDenomStp,
                                      outputDataBuf,
                                      convOptions,
                                      importStrFlg,
                                      flagSaveVirtual,
                                      dbiConn,
                                      FALSE,	/* truncation DLA - PMSTA-12367 - 110719 */
                                      FALSE,
                                      FALSE);
}

/************************************************************************
**
**  Function    :   DBA_ConvertDynStToString2
**
**  Description :   Given a dynamic structure, resolve all foreign keys and
**                  return a string containing all the values.
**
**  Arguments   :   object          : Data type object.
**                  inputSt         : Input data type.
**                  inputData       : Input data.
**                  level           : Level of recursivity.
**                  shortDataFlg    : Is it called using a short or an all?
**                  inputDenomStp   : Points to the current denom.
**                  outputDataBuf   : Buffer that will contain the data string.
**                  convOptions     : Used for DBA_Get.
**                  importStrFlg    : Is it for archiving?
**                  flagSaveVirtual : Save virtual or not (Yes for subscription No for Gui MAcro)
**                  dbiConn         : Current connection.
**                  truncationFlg   : truncate inputData if its more than the lenght of dictAttributeWrk->dataTpProgN)?
**                  onlyBusinessKeyFlg : is it for only business keys?
**                  flagJSonSyntax  :is it for Json syntax?
**                  flagFullyQualifiedName:Is it called to use a full qualified name of attributes?
**
**  Return      :   RET_CODE
**
**  Creation	:   GRD/XSH - 000209 - REF4204.
**
**  Modif.      :   GRD     - 010206 - REF5635. Do not use user specific format for subscription.
**                                              (use of the defaultFmt flag).
**                  GRD     - 010207 - REF5660. Forgot the 'ShortinfoType'.
**                  REF9303 - TEB - 030908 : Unicode
**                  REF9303 - 030915 - PMO : Implementation of Unicode
**                  HFI-PMSTA-41842-200916 : Generation of a JSon string
**
*************************************************************************/
RET_CODE DBA_ConvertDynStToString2(OBJECT_ENUM           object,
                                  DBA_DYNST_ENUM        inputSt,
                                  DBA_DYNFLD_STP        inputData,
                                  int                   level,
                                  FLAG_T                shortDataFlg,   /* Is it called using a short or a all? */
                                  void                  *inputDenomStp,
                                  char                  **outputDataBuf,
                                  int                   convOptions,
                                  FLAG_T                importStrFlg,
                                  FLAG_T                flagSaveVirtual,
                                  DbiConnection&        dbiConn,
                                  FLAG_T				truncationFlg,
                                  FLAG_T                onlyBusinessKeyFlg,
                                  FLAG_T                flagJSonSyntax,
                                  SubscriptionNatEn     subcriptionEn)
{
    RET_CODE                retCode = RET_SUCCEED;
    SQLNAME_T               tmp;
    int                     i = 0;
    int                     dictDenomCursor = 0;
    DICT_ENTITY_STP         dictEntityStp     = NULL;
    char                    *tmpBuf			  = NULL,
                            *tmpDataBuf       = NULL;
    PTR                     valPtr            = NULL;
    OBJECT_ENUM             objectEn;
    DBA_DYNFLD_STP          allOutput = NULL,
                            admArg = NULL,
                            shOutput = NULL;
    FK_DENOM_ELM_STP        dictDenomStp = NULL;
    FK_DENOM_ELM_STP        denomStp = NULL;
    FLAG_T                  objectIdFlg = FALSE;
    SQLNAME_T               objectName = "",
                            entityObjectName = "";
    /* CURRENTCHARSETCODE_ENUM currCharset = CurrentCharsetCode_IsNull; */ /* REF9303 - TEB - 031008 */
    unsigned char           currSeparator   = SV_CharUnitSeparator;         /* REF9303 - TEB - 031008 change from 164 to 31 */
    unsigned char           recordSeparator = SV_CharRecordSeparator;         /* REF9303 - TEB - 031008 change from 59  to 30 */
    FLAG_T                  allocFlg = FALSE,
                            synonFlg = FALSE;
    ID_T                    codifId = 0;
    int                     progIndex;      /* May change depending on 'Short' or 'All' structure. */
    FLAG_T                  shortFlg = FALSE;
    ID_T                    iId;        /* DLA - REF10547 - 040811 */
    int                     bUdF=FALSE; /* DLA - REF10547 - 040811 */
    DICT_T                  tmpRefEntDictId; /* REF10459 - LJE - 050125 */
    char                    *pszEqual = "=";        /*  HFI-PMSTA-41842-200916  */
    char                    *pszNull = "NULL";      /*  HFI-PMSTA-41842-200916  */

    int n, count;
    DICT_ATTRIB_STP *attributes;

    if (inputData == NULL)
    {
        return(RET_DBA_INFO_NODATA);
    }

    denomStp = (FK_DENOM_ELM_STP)inputDenomStp;
    if ((dictEntityStp = DBA_GetDictEntitySt(object)) == NULL)
        return RET_GEN_ERR_INVARG;


    /*PMSTA-49250 - 20052022 - Lalby -use a full qualified name of attributes for DES application parsing */
    FLAG_T flagFullyQualifiedName = (SubscriptionNatEn::Outbox == subcriptionEn) ? TRUE : FALSE;

    /*  Define separator string for JSon string                 */  /*  HFI-PMSTA-41842-200916  */
    if (flagJSonSyntax == TRUE)
    {
        currSeparator = '"';
        recordSeparator = ',';
        pszEqual = "\": ";
        pszNull = "null";
    }

    dictDenomStp = (FK_DENOM_ELM_STP) CALLOC(dictEntityStp->attr.size() + 1, sizeof(FK_DENOM_ELM_ST));

    if (level > 0)
    {
        denomStp->fkDenomElmNext = dictDenomStp;
    }

    for (auto attribIt = dictEntityStp->attr.begin() ; attribIt != dictEntityStp->attr.end() && (retCode == RET_SUCCEED); ++attribIt, i++)  /* DLA - PMSTA-28850 -171023 */
    {
        DICT_ATTRIB_STP dictAttributeWrk = (*attribIt);

        if (onlyBusinessKeyFlg)
        {
            static int activated = -1;
            static Lock lock;

            {
                LockGuard guard(lock);

                if (activated < 0)
                {
                    char *p = SYS_GetEnv("AAA_EXTRA_FIELD_IN_EVENT");

                    if (p != NULL)
                        activated = atoi(p);
                    else
                        activated = 0;

                    if (activated < 0)
                        activated = -activated;
                }
            }

            bool toKeep = false;

            if (activated)
            {
                toKeep =
                    object == EOp && (
                        !strcmp(dictAttributeWrk->sqlName, "code"             ) ||
                        !strcmp(dictAttributeWrk->sqlName, "fusion_e"         ) ||
                        !strcmp(dictAttributeWrk->sqlName, "sequence_no_n"    ) ||
                        !strcmp(dictAttributeWrk->sqlName, "status_e"         ) ||
                        !strcmp(dictAttributeWrk->sqlName, "parent_oper_nat_e") ||
                        !strcmp(dictAttributeWrk->sqlName, "source_code"      ));
            }

            toKeep =
                object == EOp && (
                    !strcmp(dictAttributeWrk->sqlName, "status_e"));

            if (!toKeep && !dictAttributeWrk->busKeyFlg)
                continue;
        }

        if (level == 0)
        {
            if ((i == 0) && (dictEntityStp->mainFlg == TRUE)) /* DLA - REF7219 - 011205 */
            {
                continue;
            }

            /* PMSTA15199 - DDV - 130114 - If it is the only Pk field, it is an identity even if entity is not main */
            if (dictEntityStp->primKeyNbr == 1 && dictAttributeWrk->primFlg == TRUE && dictAttributeWrk->refEntDictId == 0 &&
                (dictAttributeWrk->dataTpProgN == IdType || dictAttributeWrk->dataTpProgN == DictType))
            {
                continue;
            }
        }


        /* DLA - REF10547 - 040811 */
        /* On recherche les attributs avec un Id final > 500 (UD Logique)  */
        iId = dictAttributeWrk->attrDictId - (dictAttributeWrk->attrDictId / 1000) * 1000;
        bUdF = ((iId >= 500) && (flagSaveVirtual == TRUE) && (importStrFlg == 0)) ? TRUE : FALSE;          /*  FIH-REF10666-041005 Add test with flagSaveVirtual   */ /* DLA - PMSTA01447 - 070525 */

        if (((level == 0) || ((level > 0) && (dictAttributeWrk->busKeyFlg == TRUE)) || ((level > 0) && (object == Communication) && (i > 0))) && /* DLA - PMSTA01447 - 070209 */
            (dictAttributeWrk->logicalFlg == 0) &&
            ((dictAttributeWrk->isPhysicalAttribute() || object == WarningMsgEnt) || (bUdF)) && /* DLA - REF9560 - 031015 bidouille suite � r�gression*/  /* DLA - REF10547 - 040811 */
            (DBA_FieldToExport(inputSt, i) == TRUE) && (strcmp(dictAttributeWrk->sqlName, "ud_id") != 0) && (strcmp(dictAttributeWrk->sqlName, "x_id") != 0)) /* PMSTA-41327 - DDV - 200805 - Add exception for x_id */
        {
            /* Are we currently using a 'Short' or an 'All' structure? */
            if (shortDataFlg == FALSE)
            {
                progIndex = dictAttributeWrk->progN;
            }
            else
            {
                progIndex = dictAttributeWrk->shortIdx;
                /*  shortIdx = 0 for the attribute not part of the short structure  HFI-PMSTA-41842-200916  */
                if ((progIndex == 0) &&
                    ((dictAttributeWrk->busKeyFlg == FALSE) ||
                     (dictAttributeWrk->primFlg == FALSE)))
                    continue;
            }

            switch (dictAttributeWrk->dataTpProgN)
            {
                case ExtensionType:
                case ArrayType:
                case MultiArrayType:
                case MaskType:
                case PtrType:   /*  FIH-REF9089-030513  */
                case ChainedTypeType: /* PMSTA-34470 - LJE - 190122 */
                    break;

                case CodeType:
                case NameType:
                case LongnameType:
                case InfoType:
                case NoteType:
                case PhoneType:
                case SysnameType:
                case LongSysnameType: /* PMSTA-14086 - LJE - 121008 */
                case TextType:
                case UrlType:
                case LongStringType:
                case ShortinfoType: /* REF5660 */
                case String1000Type: /*  DLA - PMSTA07121 - 081212 */
                case String2000Type:
                case String3000Type:
                case String4000Type:
                case String7000Type:
                case String15000Type:
                    if ((IS_NULLFLD(inputData, progIndex) == FALSE) && (strcmp(dictAttributeWrk->sqlName, "gui_context_t") != 0)) /* PMSTA41932 - VSW - 200924*/
                    {
                        /* <DLA - PMSTA-12367 - 110719 */
						int maxlength = 0;
						char * ptrStr = NULL;
						
						if (object != ScriptDef) /* DLA - PMSTA-26336 - 170623 */
						{
							if (truncationFlg == TRUE && SYS_StrLen(GET_STRING(inputData, progIndex)) >= GET_MAXLEN(dictAttributeWrk->dataTpProgN))
							{
								maxlength = GET_MAXLEN(dictAttributeWrk->dataTpProgN);

								/* PMSTA-46321 - 280921*/
								int newLineCount = 0;
								std::size_t  newLinePosition;
								std::string tempString(GET_STRING(inputData, progIndex), GET_MAXLEN(dictAttributeWrk->dataTpProgN));
								while ((newLinePosition = tempString.find("\n")) != std::string::npos)
								{
									tempString.assign(tempString.begin() + newLinePosition + 1, tempString.end());
									newLineCount = newLineCount + 1;
								}
								maxlength = maxlength - newLineCount;
							}
						}
                        /* DLA - PMSTA-12367 - 110719 >*/
                        dictDenomStp[dictDenomCursor].denom = (char*)
                            CALLOC(SYS_StrLen(dictAttributeWrk->sqlName) +
                            SYS_StrLen(GET_STRING(inputData, progIndex)) + 10,
                            sizeof(char));

                        if (dictDenomStp[dictDenomCursor].denom == NULL)
                        {
                            return(RET_MEM_ERR_ALLOC);
                        }


                        if (!importStrFlg)
                        {
                            DBA_GetObjectEnum(dictEntityStp->entDictId, &objectEn);

                            /* Test if this entity could have a synonym. */
                            synonFlg = (DBA_GetDictEntityStSafe(objectEn))->synonFlg;

                            /* Could be there a synonym for this entity?. */
                            if (synonFlg == TRUE && level == 0 && (strcmp(dictAttributeWrk->sqlName, "code") == 0) &&
                                DBA_GetSubsCodif(dictEntityStp->entDictId, &codifId, dbiConn) == TRUE)
                            {

                                if ((admArg = ALLOC_DYNST(Adm_Arg)) == NULL)
                                {
                                    return(RET_MEM_ERR_ALLOC);
                                }

                                if ((shOutput = ALLOC_DYNST(GET_ADMINGUIST(objectEn))) == NULL)
                                {
                                    FREE_DYNST(admArg, Adm_Arg);
                                    return(RET_MEM_ERR_ALLOC);
                                }

                                SET_ID(admArg, Adm_Arg_Id, GET_ID(inputData, 0));
                                SET_ID(admArg, Adm_Arg_CodifId, codifId);

                                retCode = DBA_Get2(objectEn,
                                                   UNUSED,
                                                   Adm_Arg,
                                                   admArg,
                                                   GET_ADMINGUIST(objectEn),        /* Short. */
                                                   &shOutput,
                                                   convOptions,                     /* Options */
                                                   dbiConn);

                                FREE_DYNST(admArg, Adm_Arg);
                                if (retCode != RET_SUCCEED)
                                {
                                    char msg[100];

                                    sprintf(msg, "objectEn=" szFormatObj " (%s),Adm_Arg_Id=%" szFormatId",Adm_Arg_CodifId=%" szFormatId", progIndex = %d", /* DLA - PMSTA08801 - 100209 */
                                            objectEn, DBA_GetObjectCName(objectEn), GET_ID(inputData, 0), codifId, progIndex); /* DLA - PMSTA05101 - 080404 */

                                    MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, msg);
                                    FREE_DYNST(shOutput, GET_ADMINGUIST(objectEn));
                                    return (retCode);
                                }
                                if ((dictDenomStp[dictDenomCursor].denom = (char*)
                                    REALLOC(dictDenomStp[dictDenomCursor].denom,
                                    (SYS_StrLen(dictAttributeWrk->sqlName) +
                                    SYS_StrLen(GET_STRING(shOutput, dictAttributeWrk->shortIdx)) + 10) *
                                    sizeof(char))) == NULL)
                                {
                                    FREE_DYNST(shOutput, GET_ADMINGUIST(objectEn));
                                    return(RET_MEM_ERR_ALLOC);
                                }

                                /* DLA - PMSTA-12367 - 110719 */
                                ptrStr = GET_STRING(shOutput, dictAttributeWrk->shortIdx);
                                if (maxlength > 0)
                                {
                                    ptrStr[maxlength] = 0;
                                }

                                sprintf(dictDenomStp[dictDenomCursor].denom, "%s%s%c%s%c%c ",
                                        dictAttributeWrk->sqlName,
                                        pszEqual,
                                        currSeparator,
                                        ptrStr,
                                        currSeparator,
                                        recordSeparator); /* REF9303 - TEB - 030908 */

                                FREE_DYNST(shOutput, GET_ADMINGUIST(objectEn));
                            }
                            else
                            {
                                /* DLA - PMSTA-12367 - 110719 */
                                ptrStr = GET_STRING(inputData, progIndex);
                                if (maxlength > 0)
                                {
                                    ptrStr[maxlength] = 0;
                                }

                                sprintf(dictDenomStp[dictDenomCursor].denom, "%s%s%c%s%c%c ",
                                        dictAttributeWrk->sqlName,
                                        pszEqual,
                                        currSeparator,
                                        ptrStr,
                                        currSeparator,
                                        recordSeparator); /* REF9303 - TEB - 030908 */

                            }
                        }
                        else
                        {
                            /* DLA - PMSTA-12367 - 110719 */
                            ptrStr = GET_STRING(inputData, progIndex);
                            if (maxlength > 0)
                            {
                                ptrStr[maxlength] = 0;
                            }

                            sprintf(dictDenomStp[dictDenomCursor].denom, "%s%s%s%c ",
                                    dictAttributeWrk->sqlName,
                                    pszEqual,
                                    ptrStr,
                                    recordSeparator); /* REF9303 - TEB - 030908 */

                        }
                    }
                    else
                    {
                        dictDenomStp[dictDenomCursor].denom = (char*)
                            CALLOC(SYS_StrLen(dictAttributeWrk->sqlName) + 10, sizeof(char));

                        if (dictDenomStp[dictDenomCursor].denom == NULL)
                        {
                            return(RET_MEM_ERR_ALLOC);
                        }

                        sprintf(dictDenomStp[dictDenomCursor].denom, "%s%s%s%c ",
                                dictAttributeWrk->sqlName,
                                pszEqual,
                                pszNull,
                                recordSeparator); /* REF9303 - TEB - 030908 */
                    }
                    /*
                                            if (strstr(dictDenomStp[dictDenomCursor].denom,"\'")) /-* DLA - REF11258 - 050629 *-/
                                            {
                                            CURRENTCHARSETCODE_ENUM  SybCharSet ;
                                            UErrorCode  UnicodeErr = U_ZERO_ERROR;
                                            UConverter *handle;
                                            const char *charsetSrc;
                                            int length  = SYS_StrLen(dictDenomStp[dictDenomCursor].denom);
                                            char  * convertstr = (char*) CALLOC(length*5+1, sizeof(char));


                                            GEN_GetApplInfo(ApplCurrentCharsetCodeEnum, &SybCharSet);
                                            charsetSrc  = GEN_GetCurCharset(SybCharSet,  CharsetCodeType_Icu);

                                            handle = ucnv_open(charsetSrc, &UnicodeErr);

                                            UnicodeString uString(dictDenomStp[dictDenomCursor].denom, length, handle, UnicodeErr);

                                            uString.findAndReplace("\'", "\'\'");

                                            uString.extract(convertstr, length*5+1, handle, UnicodeErr);

                                            ucnv_close(handle);

                                            dictDenomStp[dictDenomCursor].denom = (char *)REALLOC (dictDenomStp[dictDenomCursor].denom, SYS_StrLen(convertstr)+1 );
                                            strcpy ( dictDenomStp[dictDenomCursor].denom, convertstr);

                                            FREE(convertstr);
                                            }
                                            */
                    dictDenomCursor++;
                    break;

                    /* REF9303 - TEB - 030908 : Begin */
                case UniTextType:
                case UniUrlType:
                case UniCodeType:
                case UniInfoType:
                case UniLongnameType:
                case UniNameType:
                case UniNoteType:
                case UniPhoneType:
                case UniSysnameType:
                case UniShortinfoType:
                case UniString1000Type:   /*  DLA - PMSTA07121 - 081212 */
                case UniString2000Type:
                case UniString3000Type:
                case UniString4000Type:
                case UniString7000Type:
                case UniString15000Type:

                    if (IS_NULLFLD(inputData, progIndex) == FALSE)
                    {
                        /*< DLA - PMSTA-12367 - 110719 */
                        int maxlength = 0;
                        if (object != ScriptDef) /* DLA - PMSTA-26336 - 170623 */
                        {
                            if (truncationFlg == TRUE && ICU4AAA_UnicodeStrLen(GET_USTRING(inputData, progIndex), TextConversion_Xml) > GET_MAXLEN(dictAttributeWrk->dataTpProgN))
                                maxlength = GET_MAXLEN(dictAttributeWrk->dataTpProgN);
                            /* DLA - PMSTA-12367 - 110719 >*/
                        }
                        dictDenomStp[dictDenomCursor].denom = (char*)
                            CALLOC(SYS_StrLen(dictAttributeWrk->sqlName) +
                            /* REF9303 - TEB - 030908 */
                            ICU4AAA_UnicodeStrLen(GET_USTRING(inputData, progIndex), TextConversion_Xml) +
                            10,
                            sizeof(char));

                        if (dictDenomStp[dictDenomCursor].denom == NULL)
                        {
                            return(RET_MEM_ERR_ALLOC);
                        }

                        if (!importStrFlg)
                        {
                            DBA_GetObjectEnum(dictEntityStp->entDictId, &objectEn);

                            /* Test if this entity could have a synonym. */
                            synonFlg = (DBA_GetDictEntityStSafe(objectEn))->synonFlg;

                            /* Could be there a synonym for this entity?. */
                            if (synonFlg == TRUE && level == 0 && (strcmp(dictAttributeWrk->sqlName, "code") == 0) &&
                                DBA_GetSubsCodif(dictEntityStp->entDictId, &codifId, dbiConn) == TRUE)
                            {
                                /* REF9303 - TEB - 030908 */
                                char *htmlStr;

                                if ((admArg = ALLOC_DYNST(Adm_Arg)) == NULL)
                                {
                                    return(RET_MEM_ERR_ALLOC);
                                }

                                if ((shOutput = ALLOC_DYNST(GET_ADMINGUIST(objectEn))) == NULL)
                                {
                                    FREE_DYNST(admArg, Adm_Arg);
                                    return(RET_MEM_ERR_ALLOC);
                                }

                                SET_ID(admArg, Adm_Arg_Id, GET_ID(inputData, 0));
                                SET_ID(admArg, Adm_Arg_CodifId, codifId);

                                retCode = DBA_Get2(objectEn,
                                                   UNUSED,
                                                   Adm_Arg,
                                                   admArg,
                                                   GET_ADMINGUIST(objectEn),
                                                   &shOutput,
                                                   convOptions,
                                                   dbiConn);

                                FREE_DYNST(admArg, Adm_Arg);
                                if (retCode != RET_SUCCEED)
                                {
                                    char msg[100];

                                    sprintf(msg, "objectEn=" szFormatObj " (%s),Adm_Arg_Id=%" szFormatId",Adm_Arg_CodifId=%" szFormatId", progIndex = %d", /* DLA - PMSTA08801 - 100209 */
                                            objectEn, DBA_GetObjectCName(objectEn), GET_ID(inputData, 0), codifId, progIndex); /* DLA - PMSTA05101 - 080404 */

                                    MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, msg);
                                    FREE_DYNST(shOutput, GET_ADMINGUIST(objectEn));
                                    return (retCode);
                                }
                                if ((dictDenomStp[dictDenomCursor].denom = (char*)
                                    REALLOC(dictDenomStp[dictDenomCursor].denom,
                                    (SYS_StrLen(dictAttributeWrk->sqlName) +
                                    /* REF9303 - TEB - 030908 */
                                    ICU4AAA_UnicodeStrLen(GET_USTRING(shOutput, dictAttributeWrk->shortIdx), TextConversion_Xml) +
                                    10) *
                                    sizeof(char))) == NULL)
                                {
                                    FREE_DYNST(shOutput, GET_ADMINGUIST(objectEn));
                                    return(RET_MEM_ERR_ALLOC);
                                }

                                /* REF9303 - TEB - 030908 */
                                htmlStr = (char*)CALLOC(ICU4AAA_UnicodeStrLen(GET_USTRING(shOutput, dictAttributeWrk->shortIdx), TextConversion_Xml) + 1,
                                                        sizeof(char));

                                ICU4AAA_ConvertFromUChars(GET_USTRING(shOutput, dictAttributeWrk->shortIdx),
                                                          -1,
                                                          htmlStr,
                                                          ICU4AAA_UnicodeStrLen(GET_USTRING(shOutput, dictAttributeWrk->shortIdx), TextConversion_Xml) + 1,
                                                          NULL,
                                                          ICU4AAA_SQLServerUTF8 == TRUE ? TextConversion_Utf8 : TextConversion_Xml);/* DLA - PMSTA-13053 - 111101 */

                                /* DLA - PMSTA-12367 - 110719 */
                                if (maxlength > 0)
                                {
                                    htmlStr[maxlength] = 0;
                                }

                                sprintf(dictDenomStp[dictDenomCursor].denom, "%s%s%c%s%c%c ",
                                        dictAttributeWrk->sqlName,
                                        pszEqual,
                                        currSeparator,
                                        htmlStr,
                                        currSeparator,
                                        recordSeparator); /* REF9303 - TEB - 030908 */

                                FREE(htmlStr);
                                FREE_DYNST(shOutput, GET_ADMINGUIST(objectEn));
                            }
                            else
                            {
                                /* REF9303 - TEB - 030908 */
                                char *htmlStr;

                                htmlStr = (char*)CALLOC(ICU4AAA_UnicodeStrLen(GET_USTRING(inputData, progIndex), TextConversion_Xml) + 1,
                                                        sizeof(char));

                                ICU4AAA_ConvertFromUChars(GET_USTRING(inputData, progIndex),
                                                          -1,
                                                          htmlStr,
                                                          ICU4AAA_UnicodeStrLen(GET_USTRING(inputData, progIndex), TextConversion_Xml) + 1,
                                                          NULL,
                                                          ICU4AAA_SQLServerUTF8 == TRUE ? TextConversion_Utf8 : TextConversion_Xml); /* DLA - PMSTA-13053 - 111101 */

                                /* DLA - PMSTA-12367 - 110719 */
                                if (maxlength > 0)
                                {
                                    htmlStr[maxlength] = 0;
                                }

                                sprintf(dictDenomStp[dictDenomCursor].denom, "%s%s%c%s%c%c ",
                                        dictAttributeWrk->sqlName,
                                        pszEqual,
                                        currSeparator,
                                        htmlStr,
                                        currSeparator,
                                        recordSeparator); /* REF9303 - TEB - 030908 */

                                FREE(htmlStr);
                            }
                        }
                        else
                        {
                            /* REF9303 - TEB - 030908 */
                            char *htmlStr;

                            htmlStr = (char*)CALLOC(ICU4AAA_UnicodeStrLen(GET_USTRING(inputData, progIndex), TextConversion_Xml) + 1,
                                                    sizeof(char));

                            ICU4AAA_ConvertFromUChars(GET_USTRING(inputData, progIndex),
                                                      -1,
                                                      htmlStr,
                                                      ICU4AAA_UnicodeStrLen(GET_USTRING(inputData, progIndex), TextConversion_Xml) + 1,
                                                      NULL,
                                                      ICU4AAA_SQLServerUTF8 == TRUE ? TextConversion_Utf8 : TextConversion_Xml); /* DLA - PMSTA-13053 - 111101 */

                            /* DLA - PMSTA-12367 - 110719 */
                            if (maxlength > 0)
                            {
                                htmlStr[maxlength] = 0;
                            }

                            sprintf(dictDenomStp[dictDenomCursor].denom, "%s=%s%c ",
                                    dictAttributeWrk->sqlName,
                                    htmlStr,
                                    recordSeparator); /* REF9303 - TEB - 030908 */

                            FREE(htmlStr);
                        }
                    }
                    else
                    {
                        dictDenomStp[dictDenomCursor].denom = (char*)
                            CALLOC(SYS_StrLen(dictAttributeWrk->sqlName) + 10, sizeof(char));

                        if (dictDenomStp[dictDenomCursor].denom == NULL)
                        {
                            return(RET_MEM_ERR_ALLOC);
                        }

                        sprintf(dictDenomStp[dictDenomCursor].denom, "%s%s%s%c ",
                                dictAttributeWrk->sqlName,
                                pszEqual,
                                pszNull,
                                recordSeparator); /* REF9303 - TEB - 030908 */
                    }

                    dictDenomCursor++;
                    break;
                    /* REF9303 - TEB - 030908 : End */

                case IdType:
                case DictType:
                    if (dictAttributeWrk->refEntDictId)
                    {
                        DBA_GetObjectEnum(dictAttributeWrk->refEntDictId, &objectEn);

                        /* Test if this entity could have a synonym. */
                        synonFlg = (DBA_GetDictEntityStSafe(objectEn))->synonFlg;

                        /* Could be there a synonym for this entity?. */
                        if ((!importStrFlg) && synonFlg == TRUE &&
                            DBA_GetSubsCodif(dictAttributeWrk->refEntDictId, &codifId, dbiConn) == TRUE &&
                            (IS_NULLFLD(inputData, progIndex) == FALSE) && GET_ID(inputData, progIndex) != 0) /* DLA - PMSTA05101 - 080411 */
                        {
                            allocFlg = TRUE;

                            if ((admArg = ALLOC_DYNST(Adm_Arg)) == NULL)
                            {
                                return(RET_MEM_ERR_ALLOC);
                            }

                            if ((allOutput = ALLOC_DYNST(GET_ADMINGUIST(objectEn))) == NULL)
                            {
                                FREE_DYNST(admArg, Adm_Arg);
                                return(RET_MEM_ERR_ALLOC);
                            }

                            SET_ID(admArg, Adm_Arg_Id, GET_ID(inputData, progIndex));
                            SET_ID(admArg, Adm_Arg_CodifId, codifId);

                            retCode = DBA_Get2(objectEn,
                                               UNUSED,
                                               Adm_Arg,
                                               admArg,
                                               GET_ADMINGUIST(objectEn),        /* Short. */
                                               &allOutput,
                                               convOptions,                     /* Options */
                                               dbiConn);

                            FREE_DYNST(admArg, Adm_Arg);

                            if (retCode != RET_SUCCEED)
                            {
                                char msg[100];

                                sprintf(msg, "objectEn=" szFormatObj " (%s),Adm_Arg_Id=%" szFormatId",Adm_Arg_CodifId=%" szFormatId",progIndex = %d", /* DLA - PMSTA08801 - 100209 */
                                        objectEn, DBA_GetObjectCName(objectEn), GET_ID(inputData, progIndex), codifId, progIndex);  /* DLA - PMSTA05101 - 080404 */

                                MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, msg);
                                FREE_DYNST(allOutput, GET_ADMINGUIST(objectEn));
                                return (retCode);
                            }

                            shortFlg = TRUE;                                    /* Recursive call will use a 'Short'. */
                        }
                        else
                            if (objectEn == Instr)
                            {
                                if (IS_NULLFLD(inputData, progIndex) == FALSE && GET_ID(inputData, progIndex) != 0) /* DLA - PMSTA05101 - 080411 */
                                {
                                    retCode = DBA_GetInstrById(GET_ID(inputData, progIndex),
                                                               TRUE,
                                                               &allocFlg,
                                                               &allOutput,
                                                               NULL,
                                                               convOptions,
                                                               (int*)&dbiConn.getId());
                                    /*<PMSTA10131-EFE-111011 */
                                    if (retCode == RET_DBA_INFO_NODATA || retCode == RET_DBA_INFO_NODATAWITHOPTI)
                                    {
                                        if ((allOutput = ALLOC_DYNST(GET_ADMINGUIST(objectEn))) == NULL)
                                        {
                                            return(RET_MEM_ERR_ALLOC);
                                        }
                                        DBA_GetBusinessAttrib(objectEn, &count, &attributes);
                                        DATATYPE_ENUM dataType;

                                        for (n = 0; n < count; n++)
                                        {
                                            dataType = (DATATYPE_ENUM)GET_FLD_TYPE_MD(GET_EDITGUIST(objectEn), attributes[n]->shortIdx);
                                            if (dataType == CodeType)
                                            {
                                                SET_CODE((allOutput), attributes[n]->shortIdx, "xxxxxxxxxxxxxxxxxxxx");
                                            }
                                            else  if (dataType == IdType || dataType == DictType)
                                            {
                                                SET_NULL_ID((allOutput), attributes[n]->shortIdx);
                                            }
                                        }
                                        retCode = RET_SUCCEED;
                                    }/*>PMSTA10131-EFE-111011 */
                                    else if (retCode != RET_SUCCEED)
                                    {
                                        char msg[100];

                                        sprintf(msg, "DBA_GetInstrById GET_ID(inputData, progIndex) = %" szFormatId",progIndex = %d", /* DLA - PMSTA08801 - 100209 */
                                                GET_ID(inputData, progIndex), progIndex);
                                        MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, msg);
                                    }

                                    shortFlg = FALSE;                               /* Recursive call will use an 'All'. */
                                }
                                else
                                {
                                    allocFlg = TRUE;

                                    if ((allOutput = ALLOC_DYNST(GET_ADMINGUIST(objectEn))) == NULL)
                                    {
                                        FREE(dictDenomStp);
                                        return(RET_MEM_ERR_ALLOC);
                                    }

                                    shortFlg = TRUE;                               /* Recursive call will use an 'Short'. */
                                }
                            }
                            else
                            {
                                allocFlg = TRUE;

                                if (IS_NULLFLD(inputData, progIndex) == FALSE && GET_ID(inputData, progIndex) != 0) /* DLA - PMSTA05101 - 080411 */
                                {
                                    allocFlg = TRUE;

                                    /* We have to get data from DB. */
                                    retCode = DBA_GetShortAllData(objectEn,
                                                                  inputData,  /* PMSTA-16677 - LJE - 130712 */
                                                                  progIndex,  /* PMSTA-16677 - LJE - 130712 */
                                                                  &shortFlg,
                                                                  &allOutput,
                                                                  convOptions,
                                                                  (int*)&dbiConn.getId(),
                                                                  nullptr);

                                    if (retCode != RET_SUCCEED)
                                    {
                                        char msg[100];

                                        sprintf(msg, "objectEn=" szFormatObj " (%s),GET_ID(inputData, progIndex)=%" szFormatId",progIndex = %d", /* DLA - PMSTA08801 - 100209 */
                                                objectEn, DBA_GetObjectCName(objectEn), GET_ID(inputData, progIndex), progIndex);  /* DLA - PMSTA05101 - 080404 */
                                        MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, msg);

                                        FREE(dictDenomStp);
                                        return(retCode);
                                    }
                                }
                                else
                                {
                                    allocFlg = TRUE;

                                    if ((allOutput = ALLOC_DYNST(GET_ADMINGUIST(objectEn))) == NULL)
                                    {
                                        FREE(dictDenomStp);
                                        return(RET_MEM_ERR_ALLOC);
                                    }

                                    shortFlg = TRUE;                               /* Recursive call will use an 'Short'. */
                                }
                            }

                        /* Store the entity name into denom. */
                        dictDenomStp[dictDenomCursor].denom = (char*)
                            CALLOC(SYS_StrLen(dictAttributeWrk->sqlName) + 10, sizeof(char));

                        if (dictDenomStp[dictDenomCursor].denom == NULL)
                        {
                            FREE(dictDenomStp);
                            return(RET_MEM_ERR_ALLOC);
                        }

                        sprintf(dictDenomStp[dictDenomCursor].denom, "%s.", dictAttributeWrk->sqlName);

                        retCode = DBA_ConvertDynStToString2(objectEn,
                                                            (shortFlg == TRUE) ?
                                                            GET_ADMINGUIST(objectEn) : GET_EDITGUIST(objectEn),
                                                            allOutput,
                                                            level + 1,
                                                            shortFlg,
                                                            (void *)&dictDenomStp[dictDenomCursor],
                                                            NULL,
                                                            convOptions,
                                                            importStrFlg,
                                                            flagSaveVirtual,                 /*  FIH-REF10666-041005 */
                                                            dbiConn,
                                                            truncationFlg,
                                                            FALSE,
                                                            flagJSonSyntax);

                        if (allocFlg == TRUE)
                        {
                            FREE_DYNST(allOutput, (shortFlg == TRUE) ?
                                       GET_ADMINGUIST(objectEn) : GET_EDITGUIST(objectEn));
                        }

                        if (retCode != RET_SUCCEED)
                        {
                            FREE(dictDenomStp);
                            return(retCode);
                        }

                        dictDenomCursor++;
                    }
                    else	/* exception */
                    {
                        if (IS_NULLFLD(inputData, progIndex) == FALSE && GET_ID(inputData, progIndex) != 0) /* DLA - PMSTA05101 - 080411 */ /* DLA - REF8081 - 021101 */
                        {
                            if (strrstr(dictAttributeWrk->sqlName, "object_id") != NULL)
                            {
                                strncpy(&objectName[0], dictAttributeWrk->sqlName,
                                        SYS_StrLen(dictAttributeWrk->sqlName) - 9);
                                objectName[SYS_StrLen(dictAttributeWrk->sqlName) - 9] = END_OF_STRING;

                                objectIdFlg = FALSE;

                                /* PMSTA-55753 - AAKASH - 03042024 - Avoid GUI crash when creating strategy link */
                                for (auto attrib2It = dictEntityStp->attr.begin(); attrib2It != dictEntityStp->attr.end() && !objectIdFlg; attrib2It++)
                                {
                                    DICT_ATTRIB_STP dictAttributeWrk2 = (*attrib2It);

                                    if (strrstr(dictAttributeWrk2->sqlName, "dict_id") != NULL)
                                    {
                                        strncpy(&entityObjectName[0], dictAttributeWrk2->sqlName,
                                                SYS_StrLen(dictAttributeWrk2->sqlName) - 7);
                                        entityObjectName[SYS_StrLen(dictAttributeWrk2->sqlName) - 7] = END_OF_STRING;

                                        if (strrstr(entityObjectName, objectName) != 0)
                                        {
                                            DICT_T iDictId = 0; /* DLA - REF10450 - 040715 */

                                            attrib2It = dictEntityStp->attr.end();	/* break for */
                                            objectIdFlg = TRUE;

                                            iDictId = GET_DICT(inputData, (shortDataFlg == FALSE) ? /* DLA - REF9089 - 030512 */
                                                           dictAttributeWrk2->progN :
                                                           dictAttributeWrk2->shortIdx);


                                            if (strrstr(entityObjectName, "attribute_") != 0) /* DLA - PMSTA27554 - 170622 */
                                            {
                                                iDictId = (ID_T)iDictId / 1000;
                                            }


                                            DBA_GetObjectEnum(iDictId, &objectEn); /* DLA - REF10459 - 040715 */

                                            /* Test if this entity could have a synonym. */
                                            if (objectEn != NullEntity)
                                            {
                                                synonFlg = (DBA_GetDictEntityStSafe(objectEn))->synonFlg;
                                            }

                                            if (GET_OBJ_DYNST(GET_DYNSTENUM(inputData)) == ScriptDef) /* REF10459 - LJE - 050124 */
                                            {
                                                /* DLA - 10459 - 050120 Exception avec la nature */
                                                switch (GET_ENUM(inputData, A_ScriptDef_NatEn)) /* short/all it's the same... not enough time... */
                                                {
                                                    case ScriptDef_UpdateFieldsDefVal:
                                                    case ScriptDef_SysFnDefVal:
                                                    case ScriptDef_UserFnDefVal:
                                                    case ScriptDef_SysFnFilter:
                                                    case ScriptDef_UserFnFilter:
                                                    case ScriptDef_SysFnInputCtrl:
                                                    case ScriptDef_UserFnInputCtrl:
                                                    case ScriptDef_ChildInit:
                                                        objectEn = DictFct;
                                                        break;

                                                    case ScriptDef_RuleDefVal:
                                                        objectEn = ApplRule;
                                                        break;

                                                    case ScriptDef_ScreenDefVal:
                                                    case ScriptDef_ScreenCtrlVal:
                                                    case ScriptDef_ScreenFilter:
                                                        objectEn = DictScreen;
                                                        break;

                                                    case ScriptDef_SearchDefVal:
                                                    case ScriptDef_SearchFilter:
                                                    case ScriptDef_SearchFilterSelection:
                                                    case ScriptDef_SearchInputCtrl:
                                                        objectEn = SearchCrit;
                                                        break;

                                                    case ScriptDef_TemplateDefVal:
                                                    case ScriptDef_TemplateFilter:
                                                    case ScriptDef_TemplateFilterSelection:
                                                    case ScriptDef_TemplateInputCtrl:
                                                        objectEn = ConstrTemplate;
                                                        break;

                                                    default:
                                                        break;
                                                }
                                            }

                                            DBA_GetDictId(objectEn, &tmpRefEntDictId); /* REF10459 - LJE - 050125 */

                                            /* Could be there a synonym for this entity?. */
                                            if ((!importStrFlg) && synonFlg == TRUE &&
                                                DBA_GetSubsCodif(tmpRefEntDictId, &codifId, dbiConn) == TRUE && /* REF10459 - LJE - 050125 */
                                                (IS_NULLFLD(inputData, progIndex) == FALSE) && GET_ID(inputData, progIndex) != 0) /* DLA - PMSTA05101 - 080411 */
                                            {
                                                allocFlg = TRUE;

                                                if ((admArg = ALLOC_DYNST(Adm_Arg)) == NULL)
                                                {
                                                    return(RET_MEM_ERR_ALLOC);
                                                }

                                                if ((allOutput = ALLOC_DYNST(GET_ADMINGUIST(objectEn))) == NULL)
                                                {
                                                    FREE_DYNST(admArg, Adm_Arg);
                                                    return(RET_MEM_ERR_ALLOC);
                                                }

                                                SET_ID(admArg, Adm_Arg_Id, GET_ID(inputData, progIndex));
                                                SET_ID(admArg, Adm_Arg_CodifId, codifId);

                                                retCode = DBA_Get2(objectEn,
                                                                   UNUSED,
                                                                   Adm_Arg,
                                                                   admArg,
                                                                   GET_ADMINGUIST(objectEn),        /* Short. */
                                                                   &allOutput,
                                                                   convOptions,                     /* Options */
                                                                   dbiConn);

                                                FREE_DYNST(admArg, Adm_Arg);

                                                if (retCode != RET_SUCCEED)
                                                {
                                                    char msg[100];

                                                    sprintf(msg, "objectEn=" szFormatObj " (%s),Adm_Arg_Id=%" szFormatId",Adm_Arg_CodifId=%" szFormatId",progIndex = %d", /* DLA - PMSTA08801 - 100209 */
                                                            objectEn, DBA_GetObjectCName(objectEn), GET_ID(inputData, progIndex), codifId, progIndex); /* DLA - PMSTA05101 - 080404 */

                                                    MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, msg);

                                                    FREE_DYNST(allOutput, GET_ADMINGUIST(objectEn));
                                                    return (retCode);
                                                }

                                                shortFlg = TRUE;                     /* Recursive call will use a 'Short'. */
                                            }
                                            else
                                                if (objectEn == Instr)
                                                {
                                                    allocFlg = TRUE;

                                                    if (IS_NULLFLD(inputData, progIndex) == FALSE && GET_ID(inputData, progIndex) != 0) /* DLA - PMSTA05101 - 080411 */
                                                    {
                                                        retCode = DBA_GetInstrById(GET_ID(inputData, progIndex),
                                                                                   TRUE,
                                                                                   &allocFlg,
                                                                                   &allOutput,
                                                                                   NULL,
                                                                                   convOptions,
                                                                                   (int*)&dbiConn.getId());
                                                        /*<PMSTA10131-EFE-111011 */
                                                        if (retCode == RET_DBA_INFO_NODATA || retCode == RET_DBA_INFO_NODATAWITHOPTI)
                                                        {
                                                            if ((allOutput = ALLOC_DYNST(GET_ADMINGUIST(objectEn))) == NULL)
                                                            {
                                                                return(RET_MEM_ERR_ALLOC);
                                                            }
                                                            DBA_GetBusinessAttrib(objectEn, &count, &attributes);
                                                            DATATYPE_ENUM dataType;
                                                            for (n = 0; n < count; n++)
                                                            {
                                                                dataType = (DATATYPE_ENUM)GET_FLD_TYPE_MD(GET_EDITGUIST(objectEn), attributes[n]->shortIdx);
                                                                if (dataType == CodeType)
                                                                {
                                                                    SET_CODE((allOutput), attributes[n]->shortIdx, "xxxxxxxxxxxxxxxxxxxx");
                                                                }
                                                                else  if (dataType == IdType || dataType == DictType)
                                                                {
                                                                    SET_NULL_ID((allOutput), attributes[n]->shortIdx);
                                                                }
                                                            }
                                                            retCode = RET_SUCCEED;
                                                        } /*>PMSTA10131-EFE-111011 */
                                                        else if (retCode != RET_SUCCEED)
                                                        {
                                                            char msg[100];

                                                            sprintf(msg, "DBA_GetInstrById GET_ID(inputData, progIndex) = %" szFormatId",progIndex = %d",/* DLA - PMSTA08801 - 100209 */
                                                                    GET_ID(inputData, progIndex), progIndex);
                                                            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, msg);
                                                        }

                                                        shortFlg = FALSE;                 /* Recursive call will use an 'All'. */
                                                    }
                                                    else
                                                    {
                                                        allocFlg = TRUE;

                                                        if ((allOutput = ALLOC_DYNST(GET_ADMINGUIST(objectEn))) == NULL)
                                                        {
                                                            FREE(dictDenomStp);
                                                            return(RET_MEM_ERR_ALLOC);
                                                        }

                                                        shortFlg = TRUE;
                                                    }
                                                }
                                                else
                                                {
                                                    allocFlg = TRUE;

                                                    if (IS_NULLFLD(inputData, progIndex) == FALSE && GET_ID(inputData, progIndex) != 0) /* DLA - PMSTA05101 - 080411 */
                                                    {
                                                        /* We have to get data from DB. */
                                                        retCode = DBA_GetShortAllData(objectEn,
                                                                                      inputData, /* PMSTA-16677 - LJE - 130712 */
                                                                                      progIndex, /* PMSTA-16677 - LJE - 130712 */
                                                                                      &shortFlg,
                                                                                      &allOutput,
                                                                                      convOptions,
                                                                                      (int*)&dbiConn.getId(),
                                                                                      nullptr);

                                                        if (retCode != RET_SUCCEED)
                                                        {
                                                            char msg[100];

                                                            sprintf(msg, "objectEn=" szFormatObj " (%s),GET_ID(inputData, progIndex)=%" szFormatId",progIndex = %d", /* DLA - PMSTA08801 - 100209 */
                                                                    objectEn, DBA_GetObjectCName(objectEn), GET_ID(inputData, progIndex), progIndex); /* DLA - PMSTA05101 - 080404 */
                                                            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, msg);

                                                            FREE(dictDenomStp);
                                                            return(retCode);
                                                        }
                                                    }
                                                    else
                                                    {
                                                        if ((allOutput = ALLOC_DYNST(GET_ADMINGUIST(objectEn))) == NULL)
                                                        {
                                                            FREE(dictDenomStp);
                                                            return(RET_MEM_ERR_ALLOC);
                                                        }

                                                        shortFlg = TRUE;              /* Recursive call will use an 'Short'. */
                                                    }
                                                }

                                            /* Store the entity name into denom. */
                                            dictDenomStp[dictDenomCursor].denom = (char*)
                                                CALLOC(SYS_StrLen(dictAttributeWrk->sqlName) + 10, sizeof(char));

                                            if (dictDenomStp[dictDenomCursor].denom == NULL)
                                            {
                                                return(RET_MEM_ERR_ALLOC);
                                            }

                                            sprintf(dictDenomStp[dictDenomCursor].denom, "%s.",
                                                    dictAttributeWrk->sqlName);

                                            retCode = DBA_ConvertDynStToString(objectEn,
                                                                               (shortFlg == TRUE) ?
                                                                               GET_ADMINGUIST(objectEn) :
                                                                               GET_EDITGUIST(objectEn),
                                                                               allOutput,
                                                                               level + 1,
                                                                               shortFlg,
                                                                               (void *)&dictDenomStp[dictDenomCursor],
                                                                               NULL,
                                                                               convOptions,
                                                                               importStrFlg,
                                                                               flagSaveVirtual,                 /*  FIH-REF10666-041005 */
                                                                               dbiConn);

                                            if (allocFlg == TRUE)
                                            {
                                                FREE_DYNST(allOutput, (shortFlg == TRUE) ?
                                                           GET_ADMINGUIST(objectEn) : GET_EDITGUIST(objectEn));
                                            }

                                            if (retCode != RET_SUCCEED)
                                            {
                                                FREE(dictDenomStp);
                                                return(retCode);
                                            }

                                            dictDenomCursor++;
                                        }
                                    }
                                }

                                if (objectIdFlg == 0)
                                {
                                    /* error */
                                    MSG_SendMesg(RET_DBA_ERR_INVDATA, 3, FILEINFO,
                                                 dictAttributeWrk->sqlName, dictAttributeWrk->sqlName);
                                    return(RET_DBA_ERR_INVDATA);
                                }
                            }
                            else
                            {
                                /* error */
                                MSG_SendMesg(RET_DBA_ERR_INVDATA, 2, FILEINFO, dictAttributeWrk->sqlName);
                                return(RET_DBA_ERR_INVDATA);
                            }
                        }
                        else  /* DLA - REF8081 - 021101 */
                        {
                            dictDenomStp[dictDenomCursor].denom = (char*)
                                CALLOC(SYS_StrLen(dictAttributeWrk->sqlName) + 10,
                                sizeof(char));

                            if (dictDenomStp[dictDenomCursor].denom == NULL)
                            {
                                return(RET_MEM_ERR_ALLOC);
                            }

                            sprintf(dictDenomStp[dictDenomCursor].denom, "%s%s%s%c ",
                                    dictAttributeWrk->sqlName,
                                    pszEqual,
                                    pszNull,
                                    recordSeparator); /* REF9303 - TEB - 030908 */

                            dictDenomCursor++;

                        }
                    }
                    break;

                /*  Do not use number but name to describe permitted values of Enum and Flag attributes as output format in case of outbox generation.  */  /*  HFI-PMSTA-49442-220603  */
                case EnumType:
                case FlagType:
                    if ((IS_NULLFLD(inputData, progIndex) == FALSE) &&
                        (flagFullyQualifiedName == TRUE))
                    {
                        /*  DBA_GetPermValName always returns a value: Unknow in case the value is not part of the permited values      */
                        const char *psz = DBA_GetPermValName(dictEntityStp->objectEn, progIndex, GET_ENUM(inputData, progIndex)); 
                        dictDenomStp[dictDenomCursor].denom = (char*) CALLOC(SYS_StrLen(dictAttributeWrk->sqlName) + SYS_StrLen(psz) + 10, sizeof(char));

                        sprintf(dictDenomStp[dictDenomCursor].denom, "%s%s%c%s%c%c ",
                                dictAttributeWrk->sqlName,
                                pszEqual,
                                currSeparator,
                                psz,
                                currSeparator,
                                recordSeparator);
                        dictDenomCursor++;
                        break;
                    }
                    /*  No break: standard treatment is flagFullyQualifiedName is FALSE (normally enum and flag fields are not null)    */

                case EnumMaskType:	/* PMSTA13460 - TGU - 120423 */ /* DDV - 120510 - case moved, to treat it as numberic field */
                case DatetimeType:
                case DateType:
                case TinyintType:
                case SmallintType:
                case LongintType: /* PMSTA-20887 - LJE - 150909 */
                case NumberType:
                case PercentType:
                default:
                    if ((tmpDataBuf = (char *)CALLOC(500, sizeof(char))) == NULL)
                    {
                        MSG_RETURN(RET_MEM_ERR_ALLOC);
                    }

                    if (IS_NULLFLD(inputData, progIndex) == FALSE)
                    {
                        char  fmt[100]; /* DLA - REF10078 - 040401 */
                        valPtr = GET_FLDPTR_BY_DTP(dictAttributeWrk->dataTpProgN, inputData, progIndex);

                        strcpy(fmt, GET_CONV_MASK(GET_DFLTCONVFMT(dictAttributeWrk->dataTpProgN)));

                        if (dictAttributeWrk->dataTpProgN == DatetimeType && dictAttributeWrk->widgetEn > 0) /* DLA - REF10078 - 040401 */
                            strcat(fmt, " HH:II:SS");

                        if (dictAttributeWrk->dataTpProgN == DatetimeType && dictAttributeWrk->widgetEn == 5)  /* DPT - PMSTA-43901,PMSTA-44006 - 03032021 */
                        {
                            strcpy(fmt, GET_CONV_MASK(GET_DFLTCONVFMT(dictAttributeWrk->dataTpProgN)));
                            strcat(fmt, SPACE_STR_SEP);
                            strcat(fmt, TIME_FMT);
                            strcat(fmt, TIME_SEP);
                            strcat(fmt, MICROSECS_FMT);
                            strcat(fmt, ZERO_OFFSET_IND);
                        }

                        CONV_DataToStr(tmpDataBuf,
                                       500 * sizeof(char),  /* REF9303 - 030915 - PMO */
                                       dictAttributeWrk->dataTpProgN,
                                       fmt, /* DLA - REF10078 - 040401 */
                                       (PTR)valPtr,
                                       TRUE,           /* REF5635 */
                                       TextConversion_None);

                        dictDenomStp[dictDenomCursor].denom = (char*)
                            CALLOC(SYS_StrLen(dictAttributeWrk->sqlName) +
                            SYS_StrLen(tmpDataBuf) + 10,
                            sizeof(char));

                        if (dictDenomStp[dictDenomCursor].denom == NULL)
                        {
                            return(RET_MEM_ERR_ALLOC);
                        }

                        DBA_SuppValueSpace(tmpDataBuf, tmp);

                        /*  JSon Syntax requires quote for date     */  /*  HFI-PMSTA-55824-2024-06-28  */
                        if ((flagJSonSyntax == TRUE) &&
                            (tmp[0] != 0x00) &&
                            ((dictAttributeWrk->dataTpProgN == DatetimeType) || (dictAttributeWrk->dataTpProgN == DateType)))
                        {
                            sprintf(dictDenomStp[dictDenomCursor].denom, "%s%s%c%s%c%c ",
                                    dictAttributeWrk->sqlName,
                                    pszEqual,
                                    currSeparator,
                                    tmp,
                                    currSeparator,
                                    recordSeparator);
                        }
                        else
                        {
                            sprintf(dictDenomStp[dictDenomCursor].denom, "%s%s%s%c ",
                                    dictAttributeWrk->sqlName,
                                    pszEqual,
                                    (tmp[0] == 0x00) ? "NULL" : tmp,
                                    recordSeparator); /* REF9303 - TEB - 030908 */
                        }
                    }
                    else
                    {
                        dictDenomStp[dictDenomCursor].denom = (char*)
                            CALLOC(SYS_StrLen(dictAttributeWrk->sqlName) + 10,
                            sizeof(char));

                        if (dictDenomStp[dictDenomCursor].denom == NULL)
                        {
                            return(RET_MEM_ERR_ALLOC);
                        }

                        sprintf(dictDenomStp[dictDenomCursor].denom, "%s%s%s%c ",
                                dictAttributeWrk->sqlName,
                                pszEqual,
                                pszNull,
                                recordSeparator); /* REF9303 - TEB - 030908 */
                    }

                    dictDenomCursor++;
                    FREE(tmpDataBuf);
                    break;
            }
        }
    }

    if (level == 0)
    {
        if (retCode != RET_SUCCEED)
        {
            DBA_FreeTree(dictDenomStp, 0);		/* Free the allocated tree and all its elements. */
            FREE(dictDenomStp);
        }
        else
        {
            UChar * ucharTmpBufPtr; /* Pointer to Unicode string of tmpBuf  */

            if ((tmpBuf = (char *)CALLOC(GET_MAXDATALEN(TextType), sizeof(char))) == NULL)  /* PMSTA-33077 - DLA - 181011 */
            {
                DBA_FreeTree(dictDenomStp, 0);	/* Free the allocated tree and all its elements. */
                FREE(dictDenomStp);
                MSG_RETURN(RET_MEM_ERR_ALLOC);
            }

            std::string combinedStr;
            /*  Generate a flat JSon string                 */  /*  HFI-PMSTA-41842-200916  */
            if (flagJSonSyntax == TRUE)
            {
                sprintf(&tmpBuf[SYS_StrLen(tmpBuf)], "{");
                retCode = DBA_BuildStr(dictDenomStp, 0, tmpBuf, importStrFlg, NULL, "\"",flagJSonSyntax, combinedStr, FALSE);
                if (SYS_StrLen(tmpBuf) > 2)
                {
                    sprintf(&tmpBuf[SYS_StrLen(tmpBuf)-2], "}");
                }
            }
            else
            {
               /* PMSTA-52377 -DES TAP TDL Integration - hardcoded entitityId ,recID and companyCode required first
                  in the outbox entry */
               bool flagDesFlow = (SubscriptionNatEn::Outbox == subcriptionEn) ? TRUE : FALSE;

               if (flagDesFlow == TRUE)
               {
                   sprintf(tmpBuf, "entityId=%c%" szFormatId"%c%c",
                       SV_CharUnitSeparator, dictEntityStp->entDictId, SV_CharUnitSeparator, recordSeparator);

                   bool foundCode = false;
                   bool foundOwnerEntity = false;

                   if (dictEntityStp->ownerBusinessEntAttrStp == NULL ||
                       (IS_NULLFLD(inputData, dictEntityStp->ownerBusinessEntAttrStp->progN) == TRUE))
                   {
                       foundOwnerEntity = true; // not a multi entity - value will be NULL
                   }

                   for (int loop = 0; loop < dictDenomCursor && (foundOwnerEntity == false || foundCode == false); ++loop)
                   {
                       FK_DENOM_ELM_STP    tempInputDenomStpWk = &dictDenomStp[loop];

                       while (tempInputDenomStpWk != NULL && (foundOwnerEntity == false || foundCode == false))
                       {
                           if (tempInputDenomStpWk->denom != NULL)
                           {
                               if (foundOwnerEntity == false && strstr(tempInputDenomStpWk->denom, "owner_business_entity_id") != NULL )
                               {
                                   FK_DENOM_ELM_STP   currentInputDenomStpWk = tempInputDenomStpWk->fkDenomElmNext;
                                   if (currentInputDenomStpWk != NULL)
                                   {
                                       if (strstr(currentInputDenomStpWk->denom, "code") != NULL)
                                       {
                                           char * valuePtr = getValue(currentInputDenomStpWk->denom, recordSeparator);
                                           sprintf(&tmpBuf[SYS_StrLen(tmpBuf)], "context.companyCode=%s%c", valuePtr, recordSeparator);
                                           foundOwnerEntity = true;
                                       }
                                   }
                               }

                               /*code for the entity is exist*/
                               if (foundCode == false && strstr(tempInputDenomStpWk->denom, "code") != NULL)
                               {
                                   if (strstr(tempInputDenomStpWk->denom, "code") != NULL)
                                   {
                                       char * valuePtr = getValue(tempInputDenomStpWk->denom, recordSeparator);
                                       sprintf(&tmpBuf[SYS_StrLen(tmpBuf)], "recID=%s%c", valuePtr, recordSeparator);
                                       foundCode = true;
                                   }
                               }
                           }

                           /*reference entity-check the entity */
                           if (foundCode == false && strstr(tempInputDenomStpWk->denom, "_id") != NULL)
                               tempInputDenomStpWk = tempInputDenomStpWk->fkDenomElmNext;
                           else  /*check with next attribute*/
                               break;
                       }
                   }

                   if (foundCode == false)
                   {
                       sprintf(&tmpBuf[SYS_StrLen(tmpBuf)], "recID=%cNULL%c%c", SV_CharUnitSeparator,
                           SV_CharUnitSeparator,recordSeparator);
                   }

                   if ((dictEntityStp->ownerBusinessEntAttrStp == NULL ||
                       (IS_NULLFLD(inputData, dictEntityStp->ownerBusinessEntAttrStp->progN) == TRUE)) ||(foundOwnerEntity == false))
                   {
                       if (onlyBusinessKeyFlg) //format attached - get the data from DB
                       {
                           DBA_GetObjectEnum(dictEntityStp->entDictId, &objectEn);
                           DICT_ATTRIB_STP      dictAttrPtr1 = GEN_IsMultiEntity() ? DBA_GetAttributeBySqlName(objectEn,
                               "owner_business_entity_id") : nullptr;

                           FIELD_IDX_T   busEntityFldIdx = GEN_IsMultiEntity() && dictAttrPtr1 != nullptr ? dictAttrPtr1->progN : NO_VALUE;

                           if (busEntityFldIdx != NO_VALUE && IS_NULLFLD(inputData, busEntityFldIdx) == FALSE &&
                               GET_ID(inputData, busEntityFldIdx) != 0)
                           {
                               DBA_DYNFLD_STP  adm_Argument = NULLDYNST;
                               MemoryPool      mp;

                               if ((adm_Argument = mp.allocDynst(FILEINFO, Adm_Arg)) == NULLDYNST)
                               {
                                   MSG_RETURN(RET_MEM_ERR_ALLOC);
                               }

                               SET_ID(adm_Argument, Adm_Arg_Id, GET_ID(inputData, busEntityFldIdx));

                               DBA_DYNFLD_STP   businessEntityPtr = NULL;

                               if (((businessEntityPtr) = mp.allocDynst(FILEINFO,S_BusEntity)) == NULLDYNST)
                               {
                                   MSG_RETURN(RET_MEM_ERR_ALLOC);
                               }

                               int    getOptions = 0;

                               RET_CODE ret_get = DBA_Get2(BusEntity,
                                                           UNUSED,
                                                           S_BusEntity,
                                                           adm_Argument,
                                                           S_BusEntity,
                                                           &businessEntityPtr,
                                                           getOptions,
                                                            (int*)&dbiConn);

                               if (ret_get == RET_SUCCEED)
                               {
                                   char *value = GET_CODE(businessEntityPtr, S_BusEntity_Cd);
                                   sprintf(&tmpBuf[SYS_StrLen(tmpBuf)], "context.companyCode=%c%s%c%c", SV_CharUnitSeparator,
                                       value,SV_CharUnitSeparator, recordSeparator);
                               }
                               else
                                   sprintf(&tmpBuf[SYS_StrLen(tmpBuf)], "context.companyCode=%cNULL%c%c", SV_CharUnitSeparator,
                                       SV_CharUnitSeparator, recordSeparator);
 
                           }
                       }
                       else
                       {
                           sprintf(&tmpBuf[SYS_StrLen(tmpBuf)], "context.companyCode=%cNULL%c%c", SV_CharUnitSeparator,
                               SV_CharUnitSeparator, recordSeparator);
                       }
                   }
               }
                /*PMSTA-49250 - 20052022 - Lalby -use a full qualified name of attributes for DES application parsing */
                retCode = DBA_BuildStr(dictDenomStp, 0, tmpBuf, importStrFlg, NULL, onlyBusinessKeyFlg ? ":" : NULL, 
                                       flagFullyQualifiedName, combinedStr, flagDesFlow);
            }

            if (retCode != RET_SUCCEED)
            {
                char    buffer[255];

                sprintf(buffer, "Unable to prepare data for insertion, text too long for entity %s!", dictEntityStp->mdSqlName);

                MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, buffer);
                DBA_FreeTree(dictDenomStp, 0);	/* Free the allocated tree and all its elements. */
                FREE(dictDenomStp);
                FREE(tmpBuf);       /* REF9303 - 030924 - PMO */
                return (retCode);
            }

            /* REF9303 - 030924 - PMO */
            if (ICU4AAA_SQLServerUTF8 != 0)
            { /* Unicode processing */

                if ((ucharTmpBufPtr = (UChar *)CALLOC(GET_MAXDATALEN(UniTextType), sizeof(UChar))) != NULL) /* PMSTA-33077 - DLA - 181011 */
                { /* Ok */
                    if (SYS_IsSrvMode())
                    {
                        /* Some encoded unicode fields can exist */
                        if (0 == ICU4AAA_ConvertFromUTF8(tmpBuf, -1, ucharTmpBufPtr, GET_MAXCHARLEN(TextType), NULL))   /* PMSTA-33077 - DLA - 181011 */
                        { /* Conversion ok */

                            /* Conversion of all characters (not only unicode fields) */
                            if (-1 == ICU4AAA_ConvertToHTML(ucharTmpBufPtr, -1, tmpBuf, GET_MAXDATALEN(TextType), NULL))    /* PMSTA-33077 - DLA - 181011 */
                            { /* Error */
                                MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Error while converting to XML");
                            }
                        }
                        else
                        { /* Error */
                            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Error while converting from UTF8");
                        }
                    }
                    else
                    {
                        /* Some encoded unicode fields can exist */
                        if (0 == ICU4AAA_ConvertFromHTML(tmpBuf, -1, ucharTmpBufPtr, GET_MAXCHARLEN(TextType), NULL))   /* PMSTA-33077 - DLA - 181011 */
                        { /* Conversion ok */

                            /* Conversion of all characters (not only unicode fields) */
                            if (-1 == ICU4AAA_ConvertToHTML(ucharTmpBufPtr, -1, tmpBuf, GET_MAXDATALEN(TextType), NULL))    /* PMSTA-33077 - DLA - 181011 */
                            { /* Error */
                                MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Error while converting to XML");
                            }
                        }
                        else
                        { /* Error */
                            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Error while converting from XML");
                        }
                    }

                    FREE(ucharTmpBufPtr);
                }
                else
                { /* Error */
                    retCode = RET_MEM_ERR_ALLOC;
                    MSG_SendMesg(retCode, 0, FILEINFO);
                }
            }

            DBA_FreeTree(dictDenomStp, 0);	/* Free the allocated tree and all its elements. */
            FREE(dictDenomStp);

            if (retCode == RET_SUCCEED)
            { /* Ok */
                *outputDataBuf = tmpBuf;
            }
            else
            { /* Error */
                *outputDataBuf = NULL;
            }
        }
    }

    return (retCode);
}

/************************************************************************
**
**  Function    :   DBA_ConvDynStToStringWoFKSolved
**
**  Description :   Given a dynamic structure, return a string containing all the values.
**                  Warning : this function don't resolve the foreign keys
**
**  Arguments   :   object        : Data type object.
**                  inputSt       : Input data type.
**                  inputData     : Input data.
**                  outputDataBuf : Buffer that will contain the data string.
**                  allFieldFlg   : When TRUE all fields are returned
**
**  Return      :   RET_CODE
**
**  Creation	:   GRD/DLA - 001122 - REF5309.
**
**  Modif.      :   GRD     - 010206 - REF5635. Do not use user specific format for subscription.
**                                              (use of the defaultFmt flag).
**                  GRD     - 010207 - REF5660. Forgot the 'ShortinfoType'.
**                  REF9303 - TEB - 030908 : Unicode
**                  REF9303 - 030915 - PMO : Implementation of Unicode
**
*************************************************************************/
RET_CODE DBA_ConvDynStToStringWoFKSolved(OBJECT_ENUM           object,
                                         DBA_DYNST_ENUM        inputSt,
                                         DBA_DYNFLD_STP        inputData,
                                         char                  **outputDataBuf,
                                         FLAG_T                allFieldFlg)
{

    RET_CODE                retCode = RET_SUCCEED;
    SQLNAME_T               tmp;
    FIELD_IDX_T             i = 0;
    int                     dictDenomCursor  = 0;
    char                    *tmpBuf			 = NULL,
                            *tmpDataBuf      = NULL;
    DICT_ENTITY_STP         dictEntityStp    = NULL;
    PTR                     valPtr           = NULL;
    FK_DENOM_ELM_STP        dictDenomStp     = NULL;
    /* CURRENTCHARSETCODE_ENUM currCharset      = CurrentCharsetCode_IsNull; */ /* REF9303 - TEB - 031008 */
    unsigned char           currSeparator   = SV_CharUnitSeparator;         /* REF9303 - TEB - 031008 change from 164 to 31 */
    unsigned char           recordSeparator = SV_CharRecordSeparator;         /* REF9303 - TEB - 031008 change from 59  to 30 */
    int                     progIndex;


    if (inputData == NULL)
    {
        return(RET_DBA_INFO_NODATA);
    }

    if ((dictEntityStp = DBA_GetDictEntitySt(object)) == NULL)
        return RET_GEN_ERR_INVARG;

    dictDenomStp = (FK_DENOM_ELM_STP) CALLOC(dictEntityStp->attr.size() + 1, sizeof(FK_DENOM_ELM_ST));

    for (auto attribIt = dictEntityStp->attr.begin(); attribIt != dictEntityStp->attr.end() && (retCode == RET_SUCCEED); ++attribIt, i++)   /* DLA - PMSTA-28850 -171023 */
    {
        DICT_ATTRIB_STP dictAttributeWrk = (*attribIt);

        progIndex = dictAttributeWrk->progN;

        if (( dictAttributeWrk->logicalFlg == 0 ||
              allFieldFlg == TRUE) &&
            (DBA_FieldToExport(inputSt,i) == TRUE) &&
            (strcmp(dictAttributeWrk->sqlName, "ud_id") != 0) && (strcmp(dictAttributeWrk->sqlName, "x_id") != 0)) /* PMSTA-41327 - DDV - 200805 - Add exception for x_id */
        {

            switch (dictAttributeWrk->dataTpProgN)
            {
                case ExtensionType  :
                case ArrayType      :
                case MultiArrayType :
                case MaskType       :
                case PtrType        :       /*  FIH-REF9089-030513  */
                case ChainedTypeType: /* PMSTA-34470 - LJE - 190122 */
                    break;


                case CodeType           :
                case NameType           :
                case LongnameType       :
                case InfoType           :
                case NoteType           :
                case PhoneType          :
                case SysnameType        :
                case LongSysnameType    : /* PMSTA-14086 - LJE - 121008 */
                case TextType           :
                case UrlType            :
                case LongStringType     :
                case ShortinfoType      : /* REF5660. */
                case String1000Type  : /*  DLA - PMSTA07121 - 081212 */
                case String2000Type  :
                case String3000Type  :
                case String4000Type  :
                case String7000Type  :
                case String15000Type :

                    if (IS_NULLFLD(inputData, progIndex) == FALSE)
                    {
                        dictDenomStp[dictDenomCursor].denom = (char*)
                            CALLOC(SYS_StrLen(dictAttributeWrk->sqlName) +
                                   SYS_StrLen(GET_STRING(inputData, progIndex)) + 10,
                                   sizeof(char));

                        if (dictDenomStp[dictDenomCursor].denom == NULL)
                        {
                            retCode=RET_MEM_ERR_ALLOC;
                        }
                        else
                        {
                            sprintf(dictDenomStp[dictDenomCursor].denom,
                                    "%s=%c%s%c%c ",
                                    dictAttributeWrk->sqlName,
                                    currSeparator,
                                    GET_STRING(inputData, progIndex),
                                    currSeparator,
                                    recordSeparator); /* REF9303 - TEB - 030908 */
                        }
                    }
                    else
                    {
                        dictDenomStp[dictDenomCursor].denom = (char*)
                            CALLOC(SYS_StrLen(dictAttributeWrk->sqlName) + 10 ,
                                   sizeof(char));

                        if (dictDenomStp[dictDenomCursor].denom == NULL)
                        {
                            retCode=RET_MEM_ERR_ALLOC;
                        }
                        else
                        {
                            sprintf(dictDenomStp[dictDenomCursor].denom,
                                    "%s=NULL%c ",
                                    dictAttributeWrk->sqlName,
                                    recordSeparator); /* REF9303 - TEB - 030908 */
                        }
                    }
                     /* <DLA - PMSTA-11297 - 110127
                    if (strstr(dictDenomStp[dictDenomCursor].denom,"\'"))
                    {
                        CURRENTCHARSETCODE_ENUM  SybCharSet ;
                        UErrorCode  UnicodeErr = U_ZERO_ERROR;
                        UConverter *handle;
                        const char *charsetSrc;
                        int length  = SYS_StrLen(dictDenomStp[dictDenomCursor].denom);
                        char  * convertstr = (char*) CALLOC(length*5+1, sizeof(char));


                        GEN_GetApplInfo(ApplCurrentCharsetCodeEnum, &SybCharSet);
                        charsetSrc  = GEN_GetCurCharset(SybCharSet,  CharsetCodeType_Icu);

                        handle = ucnv_open(charsetSrc, &UnicodeErr);

                        UnicodeString uString(dictDenomStp[dictDenomCursor].denom, length, handle, UnicodeErr);

                        uString.findAndReplace("\'", "\'\'");

                        uString.extract(convertstr, length*5+1, handle, UnicodeErr);

                        ucnv_close(handle);

                        dictDenomStp[dictDenomCursor].denom = (char *)REALLOC (dictDenomStp[dictDenomCursor].denom, SYS_StrLen(convertstr)+1 );
                        strcpy ( dictDenomStp[dictDenomCursor].denom, convertstr);

                        FREE(convertstr);

                    }
                    >*/
                    dictDenomCursor++;
                    break;

                /* REF9303 - TEB - 030908 : Begin */
                case UniTextType      :
                case UniUrlType       :
                case UniCodeType      :
                case UniInfoType      :
                case UniLongnameType  :
                case UniNameType      :
                case UniNoteType      :
                case UniPhoneType     :
                case UniSysnameType   :
                case UniShortinfoType :
                case UniString1000Type  : /*  DLA - PMSTA07121 - 081212 */
                case UniString2000Type  :
                case UniString3000Type  :
                case UniString4000Type  :
                case UniString7000Type  :
                case UniString15000Type :

                    if (IS_NULLFLD(inputData, progIndex) == FALSE)
                    {
                        dictDenomStp[dictDenomCursor].denom = (char*)
                            CALLOC(SYS_StrLen(dictAttributeWrk->sqlName) +
                                   /* REF9303 - TEB - 030908 */
                                   ICU4AAA_UnicodeStrLen(GET_USTRING(inputData, progIndex),TextConversion_Xml) +
                                   10,
                                   sizeof(char));

                        if (dictDenomStp[dictDenomCursor].denom == NULL)
                        {
                            retCode=RET_MEM_ERR_ALLOC;
                        }
                        else
                        {
                            /* REF9303 - TEB - 030908 */
                            char *htmlStr;

                            htmlStr = (char*)CALLOC(ICU4AAA_UnicodeStrLen(GET_USTRING(inputData, progIndex),TextConversion_Xml)+1,
                                                   sizeof(char));

                            ICU4AAA_ConvertFromUChars(GET_USTRING(inputData, progIndex),
                                                      -1,
                                                      htmlStr,
                                                      ICU4AAA_UnicodeStrLen(GET_USTRING(inputData, progIndex),TextConversion_Xml)+1,
                                                      NULL,
                                                      ICU4AAA_SQLServerUTF8 == TRUE ? TextConversion_Utf8 : TextConversion_Xml); /* DLA - PMSTA-13053 - 111101 */

                            sprintf(dictDenomStp[dictDenomCursor].denom,
                                    "%s=%c%s%c%c ",
                                    dictAttributeWrk->sqlName,
                                    currSeparator,
                                    htmlStr,
                                    currSeparator,
                                    recordSeparator); /* REF9303 - TEB - 030908 */

                            FREE(htmlStr);
                        }
                    }
                    else
                    {
                        dictDenomStp[dictDenomCursor].denom = (char*)
                            CALLOC(SYS_StrLen(dictAttributeWrk->sqlName) + 10 ,
                                   sizeof(char));

                        if (dictDenomStp[dictDenomCursor].denom == NULL)
                        {
                            retCode=RET_MEM_ERR_ALLOC;
                        }
                        else
                        {
                            sprintf(dictDenomStp[dictDenomCursor].denom,
                                    "%s=NULL%c ",
                                    dictAttributeWrk->sqlName,
                                    recordSeparator); /* REF9303 - TEB - 030908 */
                        }
                    }

                    dictDenomCursor++;
                    break;
                /* REF9303 - TEB - 030908 : End */

                case IdType         :
                case DictType       :
                    if (IS_NULLFLD(inputData, progIndex) == FALSE)
                    {
                        tmpBuf = (char *) CALLOC(NUMBER_T_LEN, sizeof(char));

                        if (tmpBuf == NULL)
                        {
                            retCode=RET_MEM_ERR_ALLOC;
                        }
                        else
                        {
                            dictDenomStp[dictDenomCursor].denom = (char*)
                                CALLOC(SYS_StrLen(dictAttributeWrk->sqlName) + 10 +
                                       sprintf(tmpBuf, "%" szFormatId, GET_ID(inputData, progIndex)) , /* DLA - PMSTA08801 - 100209 */
                                       sizeof(char));

                            if (dictDenomStp[dictDenomCursor].denom == NULL)
                            {
                                retCode=RET_MEM_ERR_ALLOC;
                            }
                            else
                            {
                                sprintf(dictDenomStp[dictDenomCursor].denom,
                                        "%s=%s%c ",
                                        dictAttributeWrk->sqlName,
                                        tmpBuf,
                                        recordSeparator); /* REF9303 - TEB - 030908 */

                                FREE(tmpBuf);
                            }
                        }
                    }
                    else
                    {
                        dictDenomStp[dictDenomCursor].denom = (char*)
                            CALLOC(SYS_StrLen(dictAttributeWrk->sqlName) + 10,
                                   sizeof(char));

                        if (dictDenomStp[dictDenomCursor].denom == NULL)
                        {
                            retCode=RET_MEM_ERR_ALLOC;
                        }
                        else
                        {
                            sprintf(dictDenomStp[dictDenomCursor].denom,
                                    "%s=NULL%c ",
                                     dictAttributeWrk->sqlName,
                                     recordSeparator); /* REF9303 - TEB - 030908 */
                        }
                    }

                    dictDenomCursor++;
                    break;

                case EnumType       :
                case FlagType       :
                case DatetimeType   :
                case DateType       :
                case TinyintType    :
                case SmallintType   :
                case LongintType    : /* PMSTA-20887 - LJE - 150909 */
                case NumberType     :
                case PercentType    :
                default             :

                    if ((tmpDataBuf = (char *) CALLOC(500, sizeof(char))) == NULL)
                    {
                        retCode=RET_MEM_ERR_ALLOC;
                    }
                    else
                    {
                        if (IS_NULLFLD(inputData, progIndex) == FALSE)
                        {
                            char  fmt[100]; /* DLA - REF10078 - 040401 */
                            valPtr = GET_FLDPTR_BY_DTP(dictAttributeWrk->dataTpProgN, inputData, progIndex);

                            strcpy(fmt,GET_CONV_MASK(GET_DFLTCONVFMT(dictAttributeWrk->dataTpProgN)));

                            if(dictAttributeWrk->dataTpProgN == DatetimeType && dictAttributeWrk->widgetEn > 0) /* DLA - REF10078 - 040401 */
                                strcat(fmt," HH:II:SS");


                            CONV_DataToStr(tmpDataBuf,
                                           500 * sizeof(char),  /* REF9303 - 030915 - PMO */
                                           dictAttributeWrk->dataTpProgN,
                                           fmt, /* DLA - REF10078 - 040401 */
                                           (PTR)valPtr,
                                           TRUE,           /* REF5635 */
                                           TextConversion_None);

                            dictDenomStp[dictDenomCursor].denom = (char*)
                                CALLOC(SYS_StrLen(dictAttributeWrk->sqlName) +
                                       SYS_StrLen(tmpDataBuf) + 10, sizeof(char));

                            if (dictDenomStp[dictDenomCursor].denom == NULL)
                            {
                                retCode=RET_MEM_ERR_ALLOC;
                            }
                            else
                            {
                                DBA_SuppValueSpace(tmpDataBuf, tmp);

                                sprintf(dictDenomStp[dictDenomCursor].denom,
                                        "%s=%s%c ",
                                        dictAttributeWrk->sqlName,
                                        (tmp[0] == 0x00) ? "NULL" : tmp,
                                        recordSeparator); /* REF9303 - TEB - 030908 */
                            }
                        }
                        else
                        {
                            dictDenomStp[dictDenomCursor].denom = (char*)
                                CALLOC(SYS_StrLen(dictAttributeWrk->sqlName) + 10, sizeof(char));

                            if (dictDenomStp[dictDenomCursor].denom == NULL)
                            {
                                retCode=RET_MEM_ERR_ALLOC;
                            }
                            else
                            {
                                sprintf(dictDenomStp[dictDenomCursor].denom,
                                        "%s=NULL%c ",
                                        dictAttributeWrk->sqlName,
                                        recordSeparator); /* REF9303 - TEB - 030908 */
                            }
                        }
                    }

                    dictDenomCursor++;
                    FREE(tmpDataBuf);
                    break;
            }
        }
    }

    std::string combinedStr;

    if (retCode == RET_SUCCEED)
    {
        if ((tmpBuf = (char *) CALLOC(GET_MAXDATALEN(TextType), sizeof(char))) == NULL) /* PMSTA-33077 - DLA - 181011 */
        {
            retCode=RET_MEM_ERR_ALLOC;
        }
        else
        {
            if ((retCode = DBA_BuildStr(dictDenomStp, 0, tmpBuf, 0 , NULL, NULL, FALSE, combinedStr,FALSE)) != RET_SUCCEED)
            {
                sprintf(tmpBuf,
                        "Unable to prepare data for insertion, text too long for entity %s!",
                        dictEntityStp->mdSqlName);
                MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, tmpBuf);
                FREE(tmpBuf);
                retCode=RET_GEN_ERR_PERSONAL;
            }
            else
            {
                *outputDataBuf = tmpBuf;
            }
        }
    }

    for (i = 0; i<(FIELD_IDX_T)dictEntityStp->attr.size(); i++)
    {
        FREE(dictDenomStp[i].denom)
    }
    FREE(dictDenomStp);

    return (retCode);

} /*DBA_ConvDynStToStringWoFKSolved*/


/************************************************************************
**
**  Function    :   trimUnitSeparator
**
**  Description :   remove unit separator from begining and end
**
**  Arguments   :  

**  Return      :   void
**
**  Creation    :   PMSTA-52377 -DES TAP TDL Integration
**
*************************************************************************/

void   trimUnitSeparator(char * valuePtr)
{
    if (valuePtr != NULL && strstr(valuePtr, "NULL") == NULL)
    {
        /*remove unit separator from value ptr .combined field format : RS type_id= US  BUSINESS ! address  ! type_id US RS*/
        int length = SYS_StrLen(valuePtr) - 1;
        int pos = length - 3;
        while (pos >= 0 && pos <= length)
        {
            if (valuePtr[pos] == SV_CharUnitSeparator)
            {
                valuePtr[pos] = ' ';
            }
            pos++;
        }

        /*check first two character*/
        if (length >= 2)
        {
            int i = 0;
            while (i <= 2)
            {
                if (valuePtr[i] == SV_CharUnitSeparator)
                {
                    valuePtr[i] = ' ';
                }
                i++;
            }
        }
    }
}

/************************************************************************
**
**  Function    :   DBA_BuildStr
**
**  Description :
**
**  Arguments   : dictDenomStp   :
**                level          :
**                buf            :
**                importStrFlg   :
**                denom          :
**                prefix         :
**                flagFullyQualifiedName : flag to check whether to return fully qualifie name

**  Return      :   RET_SUCCEED
**
**  Creation	:   GRD/XSH - 000218 - REF4204.
**  Modif.      :   GRD     - 000822 - REF5172.
**                  REF9303 - TEB - 030908 : Unicode
**              :   BSA - PMSTA02098 - 070524
**              :   HFI-PMSTA-41842-200916  Add flagJSonSyntax
**
*************************************************************************/
STATIC RET_CODE DBA_BuildStr(FK_DENOM_ELM_STP dictDenomStp, int level, char *buf, FLAG_T importStrFlg,
    char *denom, const char *prefix, FLAG_T flagFullyQualifiedName, std::string &combinedStr, FLAG_T flagDesFlow)
{
    FK_DENOM_ELM_STP	inputDenomStpWk = dictDenomStp;
    RET_CODE            retCode = RET_SUCCEED;
    unsigned char       recordSeparator = SV_CharRecordSeparator;         /* REF9303 - TEB - 031008 change from 59  to 30 */

    char	*denomWk         = NULL;
    char	*denomSansId     = NULL,			/* REF5172 */
            *currDenomSansId = NULL; 		/* REF5172 */
    char	*valueStr        = NULL;

    denomSansId     = (char*) CALLOC(GET_MAXDATALEN(TextType), sizeof (char)); /* PMSTA-33077 - DLA - 181011 */

    if (denomSansId == NULL)
    {
        return(RET_MEM_ERR_ALLOC);              /* Not enough place to store data. */
    }

    currDenomSansId = (char*) CALLOC(GET_MAXDATALEN(TextType), sizeof (char)); /* PMSTA-33077 - DLA - 181011 */

    if (currDenomSansId == NULL)
    {
        FREE(denomSansId);
        return(RET_MEM_ERR_ALLOC);              /* Not enough place to store data. */
    }

    /* REF9303 - TEB - 030908 */
    /* REF9303 - TEB - 031008 */
    /* Always use code 30 as separator : */
/*
    if (ICU4AAA_SQLServerUTF8 != 0)
    {
*/
    recordSeparator = SV_CharRecordSeparator;             /* caract�re RS - Record Separator */
/*
    }
    else
    {
        recordSeparator = 59;
    }
*/
    const char *extra =
        (prefix != NULL && !importStrFlg && (flagDesFlow == FALSE) ) ? prefix : "";   /*PMSTA-52377 -DES TAP TDL Integration -":" is not required for DES */

    while (inputDenomStpWk != NULL)
    {
        if (inputDenomStpWk->denom != NULL)
        {
            if (inputDenomStpWk->fkDenomElmNext == NULL)
            {
                if (SYS_StrLen(buf) + SYS_StrLen(inputDenomStpWk->denom) + 2 +
                    ((denom != NULL) ? SYS_StrLen(denom) : 0) + SYS_StrLen(extra) > GET_MAXDATALEN(TextType))   /* PMSTA-33077 - DLA - 181011 */
                {
                    FREE(denomSansId);			/* REF5172 */
                    FREE(currDenomSansId);			/* REF5172 */
                    return(RET_MEM_ERR_ALLOC);		/* Not enough place to store data. */
                }

                /*  PMSTA-52377 -DES TAP TDL Integration - nexted attribute value should be combined 
                    together as single entity separated by ! 
                    eg: type_id=NULL!NULL  !NULL  */
                if (flagDesFlow == TRUE && level > 1 && !importStrFlg)
                {
                    DBA_ModifSqlName(inputDenomStpWk->denom, currDenomSansId, TRUE);
                    char * valuePtr = getValue(currDenomSansId,recordSeparator);
 
                    trimUnitSeparator(valuePtr);

                    /*Remove record separator from last - if any in exising buffer*/
                    int length = SYS_StrLen(buf) - 1;
                    int pos = length - 3;

                    while (pos > 0 && pos != length)
                    {
                        if (buf[pos] == recordSeparator || buf[pos] == SV_CharUnitSeparator)
                        {
                            buf[pos] = ' ';
                        }
                        pos++;
                    }

                    /*each combined field separated with !*/
                    if (valuePtr != NULL)
                        sprintf(&buf[SYS_StrLen(buf) - 1], "!%s", valuePtr);

                    /*if the first value is not NULL , unit separator should be there at the end*/
                    if (combinedStr.find("NULL") == std::string::npos)
                        sprintf(&buf[SYS_StrLen(buf)], "%c%c", SV_CharUnitSeparator, recordSeparator);
                    else //NULL doesnot need end Unit separator.
                        sprintf(&buf[SYS_StrLen(buf)], "%c", recordSeparator);
 
                    inputDenomStpWk++;
                    continue;
                }

                if (denom != NULL)
                {
                    if ((strstr(denom, "ud_") == NULL || !importStrFlg) && /* BSA - PMSTA02098 - 070524 */ /* DLA - PMSTA07972 - 090316 */
                        ((strstr(inputDenomStpWk->denom, "code") != NULL) ||
                        (strstr(inputDenomStpWk->denom, "sqlname_c") != NULL)))
                    {
                        DBA_ModifSqlName(denom, denomSansId, flagFullyQualifiedName);
                        if (flagFullyQualifiedName == FALSE)            /*  Keep "." for JSon Syntax HFI-PMSTA-41842-200916 */
                            denomSansId[SYS_StrLen(denomSansId) - 1] = END_OF_STRING;
                        
                        DBA_ModifSqlName(inputDenomStpWk->denom, currDenomSansId, flagFullyQualifiedName);
                        
                        if (flagDesFlow == TRUE && !importStrFlg) 
                        {
                            denomSansId[SYS_StrLen(denomSansId) - 1] = END_OF_STRING; // for des
                            DBA_ModifSqlName(inputDenomStpWk->denom, currDenomSansId, false);

                            if (strstr(denomSansId, "_id") != NULL)
                            {
                                combinedStr.clear();
                                combinedStr.append(currDenomSansId);
                            }
                        }
                        if (!importStrFlg )
                        {
                            if (flagDesFlow == TRUE)
                            {
                                /*record separator should be there after each record */
                                int length = SYS_StrLen(currDenomSansId);
                                int checkIndx = (length > 3 ) ? length - 3 : 0;
                                while (checkIndx <= length)
                                {
                                    if (currDenomSansId[checkIndx] == recordSeparator)
                                    {
                                        break;
                                    }
                                    checkIndx ++;
                                }

                                if(length > checkIndx)
                                    sprintf(&buf[SYS_StrLen(buf)], "%s%s%s", extra, denomSansId, currDenomSansId);
                                else
                                    sprintf(&buf[SYS_StrLen(buf)], "%s%s%s%c", extra, denomSansId, currDenomSansId,
                                    recordSeparator);
                            }
                            else
                            {
                                sprintf(&buf[SYS_StrLen(buf)], "%s%s%s", extra, denomSansId, currDenomSansId);
                            }
                        }
                        else
                        {
                            if (importStrFlg == 1)
                            {
                                sprintf(&buf[SYS_StrLen(buf)], "%s ", denomSansId);
                            }
                            else
                            {
                                valueStr = strchr(currDenomSansId, '=');
                                if(valueStr)
                                {
                                    int n;

                                    valueStr++;
                                    n = SYS_StrLen(valueStr) - 1 ;
                                    valueStr[n]=0; /* supp the last space */
                                    n = n - 2;
                                    while(n >= 0)
                                    {
                                        if (valueStr[n] == recordSeparator)   /* REF9303 - TEB - 030908 */
                                            valueStr[n] = ' ';
                                        n--;
                                    }
                                    sprintf(&buf[SYS_StrLen(buf)], "%s", valueStr);
                                }
                            }
                        }

                        denomSansId[0] = END_OF_STRING;
                        currDenomSansId[0] = END_OF_STRING;
                    }
                    else
                    {
                        /* BSA - PMSTA02098 - 070524 */
                        if(strstr(denom, "ud_") == NULL || !importStrFlg) /* DLA - PMSTA07972 - 090316 */
                        {
                            DBA_ModifSqlName(denom, denomSansId, flagFullyQualifiedName);
                            DBA_ModifSqlName(inputDenomStpWk->denom, currDenomSansId, flagFullyQualifiedName);
                        }
                        else
                        {
                             strcpy(denomSansId,denom);
                             strcpy(currDenomSansId,inputDenomStpWk->denom);
                        }

                        if (!importStrFlg)
                        {
                            sprintf(&buf[SYS_StrLen(buf)], "%s%s%s",
                                    extra,
                                    (strcmp(denomSansId, "") == 0) ? "" : denomSansId,
                                    (strcmp(currDenomSansId, "") == 0) ? "" : currDenomSansId);
                        }
                        else
                        {
                            valueStr = strchr(currDenomSansId, '=');
                            if (importStrFlg == 1)
                            {
                                /* fields , no value */
                                if(valueStr)
                                {
                                    *valueStr=0;
                                    sprintf(&buf[SYS_StrLen(buf)], "%s%s ",
                                            (strcmp(denomSansId, "") == 0) ? "" : denomSansId,
                                            (strcmp(currDenomSansId, "") == 0) ? "" : currDenomSansId); /* DLA - REF???? - 040608 */
                                }
                            }
                            else
                            {
                                if(valueStr)
                                {
                                    int n;

                                    valueStr++;
                                    n = SYS_StrLen(valueStr) - 1;
                                    valueStr[n]=0; /* supp the last space */
                                    n = n - 2;
                                    while(n >= 0)
                                    {
                                        if (valueStr[n] == recordSeparator)   /* REF9303 - TEB - 030908 */
                                            valueStr[n] = ' ';
                                        n--;
                                    }
                                    sprintf(&buf[SYS_StrLen(buf)], "%s", valueStr);
                                }
                            }
                        }

                        denomSansId[0] = END_OF_STRING;
                        currDenomSansId[0] = END_OF_STRING;
                    }
                }
                else
                {
                    if ((strstr(inputDenomStpWk->denom, "code") == NULL) &&
                        (strstr(inputDenomStpWk->denom, "sqlname_c") == NULL))              /*  HFI-PMSTA-41842-200916  */
                    {
                        DBA_ModifSqlName(inputDenomStpWk->denom, currDenomSansId, flagFullyQualifiedName);

                        if (!importStrFlg)
                        {
                            sprintf(&buf[SYS_StrLen(buf)],
                                "%s%s", extra, (strcmp(currDenomSansId, "") == 0) ? "" : currDenomSansId);
                        }
                        else
                        {
                            valueStr = strchr(currDenomSansId, '=');
                            if (importStrFlg == 1)
                            {
                                /* fields , no value */
                                if(valueStr)
                                {
                                    *valueStr=0;
                                    sprintf(&buf[SYS_StrLen(buf)], "%s ", currDenomSansId);
                                }
                            }
                            else
                            {
                                if(valueStr)
                                {
                                    int n;

                                    valueStr++;
                                    n = SYS_StrLen(valueStr) - 1;
                                    valueStr[n]=0; /* supp the last space */
                                    n = n - 2;
                                    while(n >= 0)
                                    {
                                        if (valueStr[n] == recordSeparator)   /* REF9303 - TEB - 030908 */
                                            valueStr[n] = ' ';
                                        n--;
                                    }
                                    sprintf(&buf[SYS_StrLen(buf)], "%s", valueStr);
                                }
                            }
                        }

                        currDenomSansId[0] = END_OF_STRING;
                    }
                    else
                    {
                        if (!importStrFlg)
                        {
                            /* entity_code= format required for TDL integration, to distinguish mainly 
                               entity code and code in the format */
                            if (flagDesFlow == TRUE )
                            {
                                sprintf(&buf[SYS_StrLen(buf)], "entity_%s%c",inputDenomStpWk->denom, recordSeparator);
                            }
                            else
                            sprintf(&buf[SYS_StrLen(buf)], "%s%s", extra, inputDenomStpWk->denom);
                        }
                        else
                        {
                            valueStr = strchr(inputDenomStpWk->denom, '=');
                            if (importStrFlg == 1)
                            {
                                /* fields , no value */
                                if(valueStr)
                                {
                                    *valueStr=0;
                                    sprintf(&buf[SYS_StrLen(buf)], "%s ", inputDenomStpWk->denom);
                                }
                            }
                            else
                            {
                                if(valueStr)
                                {
                                    int n;
                                    valueStr++;
                                    n = SYS_StrLen(valueStr) - 1;
                                    valueStr[n]=0; /* supp the last space */
                                    n = n - 2;
                                    while(n >= 0)
                                    {
                                        if (valueStr[n] == recordSeparator)   /* REF9303 - TEB - 030908 */
                                            valueStr[n] = ' ';
                                        n--;
                                    }
                                    sprintf(&buf[SYS_StrLen(buf)], "%s", valueStr);
                                }
                            }
                        }
                    }
                }

                inputDenomStpWk++;
            }
            else
            {
                /*  PMSTA-52377 -DES TAP TDL Integration - nexted attribute value should be combined 
                    together as single entity separated by ! 
                    eg: type_id=NULL!NULL  !NULL  */
                if (flagDesFlow == TRUE && level > 0 && !importStrFlg)
                {
                    DBA_ModifSqlName(inputDenomStpWk->denom, currDenomSansId, TRUE);
                    char * valuePtr = getValue(currDenomSansId,recordSeparator);

                    if (valuePtr != NULL)
                    {
                        combinedStr.append("!");
                        combinedStr.append(valuePtr);
                    }
                }

                else if (denom != NULL)
                {
                    denomWk = (char*) CALLOC(SYS_StrLen(denom) + SYS_StrLen(inputDenomStpWk->denom) + 1, sizeof (char));

                    /* BSA - PMSTA02098 - 070524 */
                    if(strstr(denom, "ud_") == NULL || !importStrFlg) /* DLA - PMSTA07972 - 090316 */
                    {
                        DBA_ModifSqlName(denom, denomSansId, flagFullyQualifiedName);
                        DBA_ModifSqlName(inputDenomStpWk->denom, currDenomSansId, flagFullyQualifiedName);
                    }
                    else
                    {
                        strcpy(denomSansId,denom);
                        strcpy(currDenomSansId,inputDenomStpWk->denom);
                    }
                    sprintf(denomWk, "%s%s",
                            (strcmp(denomSansId, "") == 0) ? "" : denomSansId,
                            (strcmp(currDenomSansId, "") == 0) ? "" : currDenomSansId);
                }
                else
                {
                    denomWk = inputDenomStpWk->denom;
                }

                retCode = DBA_BuildStr(inputDenomStpWk->fkDenomElmNext,
                                       level +1,
                                       buf,
                                       importStrFlg,
                                       denomWk, prefix,
                                       flagFullyQualifiedName, combinedStr, flagDesFlow);

                if (denom != NULL)
                {
                    FREE(denomWk);
                }

                if (retCode != RET_SUCCEED)
                {
                    FREE(currDenomSansId)		/* REF5172 */
                    FREE(denomSansId)		/* REF5172 */
                    return(retCode);
                }

                inputDenomStpWk++;
            }
        }
        else
        {
            if (level > 0)
            {
                inputDenomStpWk = NULL;
            }
            else
            {
                if (inputDenomStpWk != dictDenomStp)
                {
                    inputDenomStpWk = NULL;
                    combinedStr.clear();
                }
                else
                {
                    inputDenomStpWk++;
                }
            }
        }
    }

    FREE(currDenomSansId)		/* REF5172 */
    FREE(denomSansId)		/* REF5172 */
    return (retCode);
}

/************************************************************************
**
**  Function    :   DBA_FreeTree
**
**  Description :
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED
**
**  Creation	:   GRD/XSH - 000218 - REF4204.
**  Modif.      :
**
*************************************************************************/
STATIC RET_CODE DBA_FreeTree(FK_DENOM_ELM_STP dictDenomStp, int level)
{
    FK_DENOM_ELM_STP	inputDenomStpWk = dictDenomStp;

    while (inputDenomStpWk != NULL)
    {
        if (inputDenomStpWk->denom != NULL)
        {
            if (inputDenomStpWk->fkDenomElmNext == NULL)
            {
                FREE(inputDenomStpWk->denom);
                inputDenomStpWk++;
            }
            else
            {
                DBA_FreeTree(inputDenomStpWk->fkDenomElmNext, level +1);
                FREE(inputDenomStpWk->fkDenomElmNext);
                FREE(inputDenomStpWk->denom);
                inputDenomStpWk++;
            }
        }
        else
        {
            if (level > 0)
            {
                inputDenomStpWk = NULL;
            }
            else
            {
                if (inputDenomStpWk != dictDenomStp)
                {
                    inputDenomStpWk = NULL;
                }
                else
                {
                    inputDenomStpWk++;
                }
            }
        }
    }

    FREE(inputDenomStpWk);

    return (RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   DBA_ModifSqlName
**
**  Description :   Suppress '_id', '_dict_id', '.code', .sqlname_c'.
**
**  Arguments   :  sqlName : input sqlname value
**                 sqlNameC : out parameter to store string without fully qualified name
**                 flagFullyQualifiedName : flag to check keep the fully qualified na
**
**  Return      :   RET_SUCCEED
**
**  Creation	:   GRD/XSH - 000218 - REF4204.
**  Modif.      :   HFI-PMSTA-41842-200916  Add flagJSonSyntax
**
*************************************************************************/
STATIC RET_CODE DBA_ModifSqlName(char *sqlName, char *sqlNameC, FLAG_T flagFullyQualifiedName)
{
    if (flagFullyQualifiedName == TRUE)
    {
        strcpy(sqlNameC,sqlName);
    }
    else
    {
        char *posStr=NULL;
        if ((posStr = strstr(sqlName, "_dict_id.")) != NULL &&
            SYS_StrLen(posStr) == 9) /* REF10459 - LJE - 050124 */
        {
            strncpy(&sqlNameC[0], sqlName, SYS_StrLen(sqlName) - 9);
            sqlNameC[SYS_StrLen(sqlName) - 9] = END_OF_STRING;
            strcpy(&sqlNameC[SYS_StrLen(sqlNameC)], ".");
            sqlNameC[SYS_StrLen(sqlName) - 8] = END_OF_STRING;
        }
        else
        {
            if ((posStr = strstr(sqlName, "_id.")) != NULL &&
                SYS_StrLen(posStr) == 4) /* REF10459 - LJE - 050124 */
            {
                strncpy(&sqlNameC[0], sqlName, SYS_StrLen(sqlName) - 4);
                sqlNameC[SYS_StrLen(sqlName) - 4] = END_OF_STRING;
                strcpy(&sqlNameC[SYS_StrLen(sqlNameC)], ".");
                sqlNameC[SYS_StrLen(sqlName) - 3] = END_OF_STRING;
            }
            else
            {
                if (strstr(sqlName, "_code") != NULL)
                {
                    strcpy(&sqlNameC[0], sqlName);
                }
                else
                {
                    if ((posStr = strstr(sqlName, "code")) != NULL &&
                        posStr == sqlName) /* REF10459 - LJE - 050124 */
                    {
                        sqlName += 4;
                        strcpy(&sqlNameC[0], sqlName);
                    }
                    else
                    {
                        if ((posStr = strstr(sqlName, "sqlname_c")) != NULL &&
                            posStr == sqlName) /* REF10459 - LJE - 050124 */
                        {
                            sqlName += 9;
                            strcpy(&sqlNameC[0], sqlName);
                        }
                        else
                        {
                            strcpy(&sqlNameC[0], sqlName);
                        }
                    }
                }
            }
        }
    }
    return RET_SUCCEED;
}

/************************************************************************
**
**  Function    :   DBA_SuppValueSpace
**
**  Description :   Suppress space of value
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED
**
**  Cr�ation    :   GRD/XSH - 000308 - REF4204.
**
**  Modif.      :   GRD     - 010205 - REF5635. Do not use user specific formats.
*************************************************************************/
STATIC RET_CODE DBA_SuppValueSpace(char *tmpDataBuf, SQLNAME_T tmp)
{
    unsigned int    nmbSpaces = 0;
    FLAG_T          brkCrit = FALSE;
        char                *tmpBuf  = NULL,
                                *tmpBuf1 = NULL;

        tmpBuf = tmpDataBuf;

        while (strncmp(tmpBuf, " ", 1) == 0)
        {
                tmpBuf++;
        }

        nstrcpy(&tmp[0], sizeof(SQLNAME_T), tmpBuf);

    /*
       We also suppress all the trailling spaces.
       Beware of formats that allow blank separators.
       GRD - 000308 - REF5635.
     */

    tmpBuf1 = tmpDataBuf + SYS_StrLen(tmpDataBuf) - 1;

    while((tmpBuf1 > tmpBuf) && (brkCrit == FALSE))
    {
        if (strncmp(tmpBuf1, " ", 1) == 0)
        {
            nmbSpaces++;
        }
        else
        {
            brkCrit = TRUE;
        }

        tmpBuf1--;
    }

    if (nmbSpaces > 0)
    {
        tmp[SYS_StrLen(tmpBuf) - nmbSpaces] = END_OF_STRING;
    }

    return RET_SUCCEED;
}

/************************************************************************
**
**  Function    :   DBA_ConcatString
**
**  Description :
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED
**
**  Cr�ation    :   GRD/XSH - 000308 - REF4204.
**
**  Modif.      :   GRD     - 000516 - REF4790.
**                  REF9303 - TEB - 030908 : Unicode
**
*************************************************************************/
RET_CODE DBA_ConcatString(char *tmpDataBufOld, char *tmpDataBufNew, SUBSCRIPTION_ACTION_ENUM actionEn, char **tmpDataBufAudit)
{
    char    *tmpOld          = NULL,
            *tmpNew          = NULL,
            *cursorOld       = NULL,
            *cursorNew       = NULL,
            *sqlName_cNew    = NULL,
            *sqlName_cOld    = NULL,
            *tmpDataBufWrk   = NULL,
            *valueOld        = NULL,
            *motOld          = NULL,
            *motNew          = NULL,
            *motOldWithValue = NULL,
            *motNewWithValue = NULL;

    int     i = 0, j = 0, length = 0,
            dataNewLen = 0, dataOldLen = 0;
    /* CURRENTCHARSETCODE_ENUM currCharset = CurrentCharsetCode_IsNull; */ /* REF9303 - TEB - 031008 */
    unsigned char           currSeparator   = SV_CharUnitSeparator;         /* REF9303 - TEB - 031008 change from 164 to 31 */
    unsigned char           recordSeparator = SV_CharRecordSeparator;         /* REF9303 - TEB - 031008 change from 59  to 30 */
    unsigned char           oldNewSeparator = SV_CharFileSeparator;         /* DLA - REF9303 - 031010 replace pipeSeparator */

    FLAG_T                  denomString = FALSE,
                            neverEnddingLoop = TRUE;

    /* DLA - PMSTA02584 - 070601 */
    if ((motOld=(char *) CALLOC(GET_MAXDATALEN(TextType), sizeof (char))) == NULL) /* DLA - PMSTA07711 - 090107 */  /* PMSTA-33077 - DLA - 181011 */
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }
    if ((motNew=(char *) CALLOC(GET_MAXDATALEN(TextType), sizeof (char))) == NULL) /* DLA - PMSTA07711 - 090107 */  /* PMSTA-33077 - DLA - 181011 */
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }
    if ((motOldWithValue=(char *) CALLOC(GET_MAXDATALEN(TextType), sizeof (char))) == NULL) /* DLA - PMSTA07711 - 090107 */ /* PMSTA-33077 - DLA - 181011 */
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }
    if ((motNewWithValue=(char *) CALLOC(GET_MAXDATALEN(TextType), sizeof (char))) == NULL) /* DLA - PMSTA07711 - 090107 */ /* PMSTA-33077 - DLA - 181011 */
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    *motOld          = END_OF_STRING;
    *motNew          = END_OF_STRING;
    *motOldWithValue = END_OF_STRING;
    *motNewWithValue = END_OF_STRING;

    if (tmpDataBufNew != NULL)
    {
        dataNewLen = SYS_StrLen(tmpDataBufNew);
    }

    if (tmpDataBufOld != NULL)
    {
        dataOldLen = SYS_StrLen(tmpDataBufOld);
    }

    if ((*tmpDataBufAudit = (char *) CALLOC(dataNewLen + dataOldLen + 1, sizeof (char))) == NULL)
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    tmpDataBufWrk = *tmpDataBufAudit;

    switch (actionEn)
    {
        case Subscription_Action_Update:
            length += sprintf(&tmpDataBufWrk[length], "Update ");
            break;

        case Subscription_Action_Insert:
            length += sprintf(&tmpDataBufWrk[length], "Insert ");
            break;

        case Subscription_Action_Delete:
            length += sprintf(&tmpDataBufWrk[length], "Delete ");
            break;

        default:
            break;
    }

    tmpOld = tmpDataBufOld;
    tmpNew = tmpDataBufNew;

    while ((tmpOld != nullptr && strcmp(tmpOld, "") != 0) || (tmpNew != nullptr && strcmp(tmpNew, "") != 0) )
    {
        denomString = FALSE;            /* REF4790 */
        cursorOld = tmpOld;

        /*
         * Find the 'RS' delimitor. (since unicode version REF9303 - TEB - 030908)
         * Beware that this delimitor could be part of a denom string.
         * In such a case, ignore it.       REF4790.
         */

        while(neverEnddingLoop)
        {
            if ((unsigned char)*cursorOld == currSeparator)
            {
                if (denomString == FALSE)
                {
                    denomString = TRUE;         /* Denom is beginning. */
                }
                else
                {
                    denomString = FALSE;        /* Denom is endding */
                }
            }

            if (denomString == FALSE &&
                *cursorOld == recordSeparator) /* REF9303 - TEB - 030908 */
            {
                break;
            }

            i++;
            cursorOld++;
        }

        strncpy(&motOld[0], tmpOld, i);
        motOld[i] = END_OF_STRING;

        strcpy(&motOldWithValue[0], motOld);
        valueOld = strchr(motOldWithValue, '=');
        char * remMotOld = nullptr;
        sqlName_cOld = SYS_StrTok(motOldWithValue, "=",&remMotOld); /* PMSTA-66218 - JBC - 20250221 */
        cursorNew = tmpNew;


        /*
         * Find the 'RS' delimitor. (since unicode version REF9303 - TEB - 030908)
         * Beware that this delimitor could be part of a denom string.
         * In such a case, ignore it.       REF4790.
         */

        denomString = FALSE;            /* REF4790 */

        while(neverEnddingLoop)
        {
            if ((unsigned char)*cursorNew == currSeparator)
            {
                if (denomString == FALSE)
                {
                    denomString = TRUE;         /* Denom is beginning. */
                }
                else
                {
                    denomString = FALSE;        /* Denom is endding */
                }
            }

            if (denomString == FALSE &&
                *cursorNew == recordSeparator) /* REF9303 - TEB - 030908 */
            {
                break;
            }

            j++;
            cursorNew++;
        }

        strncpy(&motNew[0], tmpNew, j);
        motNew[j] = END_OF_STRING;

        strcpy(&motNewWithValue[0], motNew);
        char * remNotNew = nullptr;
        sqlName_cNew = SYS_StrTok(motNewWithValue, "=", &remNotNew);  /* PMSTA-66218 - JBC - 20250221 */

        tmpOld += i + 2;
        tmpNew += j + 2;
        i = 0;
        j = 0;

        switch (actionEn)
        {
            case Subscription_Action_Update:
                if (strcmp(sqlName_cNew, sqlName_cOld) == 0)
                {
                    valueOld++;
                    length += sprintf(&tmpDataBufWrk[length],
                                      "%s%c%s%c",
                                      motNew,
                                      oldNewSeparator,
                                      valueOld,
                                      recordSeparator); /* REF9303 - TEB - 030908 */
                }
                break;

            case Subscription_Action_Insert:
                length += sprintf(&tmpDataBufWrk[length],
                                  "%s%cNULL%c",
                                  motNew,
                                  oldNewSeparator,
                                  recordSeparator); /* REF9303 - TEB - 030908 */
                break;

            case Subscription_Action_Delete:
                valueOld++;
                length += sprintf(&tmpDataBufWrk[length],
                                  "%s=NULL%c%s%c",
                                  sqlName_cOld,
                                  oldNewSeparator,
                                  valueOld,
                                  recordSeparator); /* REF9303 - TEB - 030908 */
                break;

            default:
                break;
        }
    }

    /* DLA - PMSTA02584 - 070601 */
    FREE(motOld);
    FREE(motNew);
    FREE(motOldWithValue);
    FREE(motNewWithValue);

    return RET_SUCCEED;
}

/************************************************************************
**
** Function    : DBA_GetAllDictEntityById
**
** Description :
**
** Arguments   :
**
** Return      :
**
** Creation    : REF9764 - LJE - 040109
**
************************************************************************/
RET_CODE DBA_GetAllDictEntityById(OBJECT_ENUM              ,
                                  DBA_DYNFLD_STP           sDictEntity,
                                  DBA_DYNFLD_STP           *aDictEntity,
                                  int                      *,
                                  int                      ,
                                  DBA_ERRMSG_INFOS_STP     )
{
    DICT_ENTITY_STP     entity = NULL;
    OBJECT_ENUM         objectEntity;

    DBA_GetObjectEnum(GET_DICT(sDictEntity,S_DictEntity_DictId), &objectEntity);

    entity = DBA_GetDictEntitySt(objectEntity);

    if (entity == NULL)
    {
        return RET_DBA_ERR_NODATA;
    }

    SET_DICT((*aDictEntity),A_DictEntity_DictId,(entity->entDictId));
    SET_NAME((*aDictEntity),A_DictEntity_Name,(entity->nameStr.c_str())); /* DLA - PMSTA09887 - 101116 */
    SET_SYSNAME((*aDictEntity),A_DictEntity_SqlName,(entity->mdSqlName));
    SET_SYSNAME((*aDictEntity),A_DictEntity_Database,(entity->databaseName.c_str()));
    SET_FLAG((*aDictEntity),A_DictEntity_RefAuthFlg,(entity->refAuthFlg));

    SET_FLAG((*aDictEntity),A_DictEntity_CustAuthFlg,(entity->custAuthFlg));
    SET_FLAG((*aDictEntity),A_DictEntity_MainFlg,(entity->mainFlg));

    SET_ENUM((*aDictEntity),A_DictEntity_TypingNat,(entity->tpNatEn));

    SET_FLAG((*aDictEntity),A_DictEntity_DictEntityFlg,(entity->entDictIdFlg));
    SET_FLAG((*aDictEntity),A_DictEntity_SynonymFlg,(entity->synonFlg));
    SET_FLAG((*aDictEntity),A_DictEntity_ListFlg,(entity->listFlg));
    SET_FLAG((*aDictEntity),A_DictEntity_QuickSearchFlg,(entity->qSearchFlg));
    SET_FLAG((*aDictEntity),A_DictEntity_LogicalFlg,(entity->logicalFlg));

    SET_ENUM((*aDictEntity),A_DictEntity_InterfaceEn,(entity->interf));
    SET_ENUM((*aDictEntity), A_DictEntity_AuditEn, (entity->auditAuthEn));

    /* PMSTA-13109 - LJE - 111212 */
    SET_SYSNAME((*aDictEntity),A_DictEntity_ShortSqlName,(entity->shortSqlname));
    SET_SYSNAME((*aDictEntity),A_DictEntity_AliasSqlName,(entity->aliasSqlname));

    /* PMSTA-14094 - DDV - 120420 - New fields added */
    SET_SYSNAME((*aDictEntity),A_DictEntity_CustDatabase,(entity->custDbName.c_str()));
    SET_SYSNAME((*aDictEntity),A_DictEntity_PrecompDatabase,(entity->precompDbName));
    SET_FLAG((*aDictEntity),A_DictEntity_PrecompFlg,(entity->precompFlg));
    SET_FLAG((*aDictEntity),A_DictEntity_UsePrecompFlg,(entity->usePrecompFlg));
    SET_ID((*aDictEntity),A_DictEntity_PrecompStdFmtId,(entity->precompStdFormatId));
    SET_ID((*aDictEntity),A_DictEntity_PrecompUsrFmtId,(entity->precompUsrFormatId));
    SET_SMALLINT((*aDictEntity),A_DictEntity_PrecompRank,(entity->precompRankN));
    SET_ENUM((*aDictEntity),A_DictEntity_SecurityLevelEn,(entity->securityLevelEn));
    SET_MASK((*aDictEntity),A_DictEntity_AutomaticMask,(entity->automaticMask));
    SET_ENUM((*aDictEntity),A_DictEntity_PkRuleEn,(entity->pkRuleEn));
    SET_ENUM((*aDictEntity), A_DictEntity_DeleteRuleEn, (entity->deleteRuleEn));
    SET_ENUM((*aDictEntity), A_DictEntity_ObjModifStatEn, (entity->objModifStatEn));
    SET_ENUM((*aDictEntity), A_DictEntity_TableModifStatEn, (entity->tableModifStatEn));
    SET_ENUM((*aDictEntity), A_DictEntity_LastModifEn, (entity->lastModifEn));
    SET_ENUM((*aDictEntity), A_DictEntity_NatEn, entity->entNatEn);
    SET_ENUM((*aDictEntity),A_DictEntity_XdStatusEn,entity->xdStatusEn);
    SET_DICT((*aDictEntity),A_DictEntity_AdminFctDictId,entity->adminFctDictId);
    SET_SYSNAME((*aDictEntity), A_DictEntity_DbSqlName, (entity->dbSqlName));
    SET_ENUM((*aDictEntity), A_DictEntity_UpdFctAuthEn, entity->updFctAuthEn); /* PMSTA-22506 - DDV - 160420 */
    SET_ENUM((*aDictEntity), A_DictEntity_DbRuleEn, (entity->dbRuleEn));
    SET_DICT((*aDictEntity), A_DictEntity_LinkedEntityDictId, (entity->linkedEntityDictId));
    SET_DICT((*aDictEntity), A_DictEntity_PhysicalEntityDictId, (entity->physicalEntityDictId));

    SET_ENUM((*aDictEntity), A_DictEntity_LoadDictRuleEn, (entity->loadDictRuleEn));
    SET_ENUM((*aDictEntity), A_DictEntity_CopyRightEn, (entity->copyRightEn));
    SET_ENUM((*aDictEntity), A_DictEntity_ExternalSeqAuthEn, (entity->externalSeqAuthEn));
    SET_ENUM((*aDictEntity), A_DictEntity_ActiveAuthEn, (entity->activeAuthEn));
    SET_ENUM((*aDictEntity), A_DictEntity_DmlModifTrackEn, (entity->dmlModifTrackEn));
    SET_ENUM((*aDictEntity), A_DictEntity_PartAuthEn, (entity->partAuthEn));                /* PMSTA-24007 - LJE - 160921 */
    SET_ENUM((*aDictEntity), A_DictEntity_DlmAuthEn, (entity->dlmAuthEn));                /* PMSTA-24007 - LJE - 160921 */
    SET_ENUM((*aDictEntity), A_DictEntity_MultiEntityCategoryEn, (entity->multiEntityCateg.get())); /* PMSTA-26108 - LJE - 170727 */


    if (entity->isNullNatIndex)
    {
        SET_NULL_TINYINT((*aDictEntity), A_DictEntity_NatIdx);
    }
    else
    {
        SET_TINYINT((*aDictEntity), A_DictEntity_NatIdx, (TINYINT_T)(entity->natIndex));
    }

    if (entity->isNullParIndex)
    {
        SET_NULL_TINYINT((*aDictEntity), A_DictEntity_ParentIdx);
    }
    else
    {
        SET_TINYINT((*aDictEntity), A_DictEntity_ParentIdx, (TINYINT_T)(entity->parIndex));
    }

    return RET_SUCCEED;
}

/************************************************************************
**
** Function    : DBA_GetShortDictEntityById
**
** Description :
**
** Arguments   :
**
** Return      :
**
** Creation    : REF9764 - LJE - 040107
**
************************************************************************/
RET_CODE DBA_GetShortDictEntityById(OBJECT_ENUM              ,
                                    DBA_DYNFLD_STP           sInputSt,
                                    DBA_DYNFLD_STP           *sDictEntity,
                                    int                      *,
                                    int                      ,
                                    DBA_ERRMSG_INFOS_STP     )
{
    DICT_ENTITY_STP     entity = NULL;
    OBJECT_ENUM         objectEntity;

    if (GET_DYNSTENUM(sInputSt) == S_DictEntity)
    {
        DBA_GetObjectEnum(GET_DICT(sInputSt,S_DictEntity_DictId), &objectEntity);
    }
    else
    {
        DBA_GetObjectEnum(GET_DICT(sInputSt,Adm_Arg_Id), &objectEntity);
    }

    entity = DBA_GetDictEntitySt(objectEntity);

    if (entity == NULL)
    {
        return RET_DBA_ERR_NODATA;
    }

    SET_DICT((*sDictEntity),S_DictEntity_DictId,(entity->entDictId));
    SET_NAME((*sDictEntity),S_DictEntity_Name,(entity->nameStr.c_str())); /* DLA - PMSTA09887 - 101116 */
    SET_SYSNAME((*sDictEntity),S_DictEntity_SqlName,(entity->mdSqlName));
    SET_ENUM((*sDictEntity), S_DictEntity_NatEn, (entity->entNatEn));

    return RET_SUCCEED;
}

/************************************************************************
**
** Function    : DBA_GetAllDictAttById
**
** Description :
**
** Arguments   :
**
** Return      :
**
** Creation    : sme (Tuesday May 16 2000)
**
************************************************************************/
RET_CODE DBA_GetAllDictAttById(OBJECT_ENUM              entity,
                               DBA_DYNFLD_STP           sDictAttr,
                               DBA_DYNFLD_STP           *aDictAttr,
                               DbiConnectionHelper& )
{
    DICT_ATTRIB_STP     attr = NULL;

    attr = DBA_GetAttributeById(GET_DICT(sDictAttr,S_DictAttr_DictId)); /* DLA - REF9089 - 030512 */

    if (attr == NULL)
    {
        return RET_DBA_ERR_NODATA;
    }

    SET_DICT((*aDictAttr),A_DictAttr_DictId,(attr->attrDictId));
    SET_NAME((*aDictAttr),A_DictAttr_Name,(attr->name)); /* DLA - PMSTA09887 - 101116 */
    SET_DICT((*aDictAttr),A_DictAttr_EntityDictId,(attr->entDictId));
    SET_DICT((*aDictAttr),A_DictAttr_DataTpDictId,(DATATYPE_ENUM_TO_DICT(attr->dataTpProgN)));
    if (attr->refEntDictId != 0)    /*  FIH-REF5293-001205  */
        SET_DICT((*aDictAttr),A_DictAttr_RefEntityDictId,(attr->refEntDictId));
    if (attr->parAttrDictId != 0)   /*  FIH-REF5293-001205  */
        SET_DICT((*aDictAttr),A_DictAttr_ParentAttribDictId,(attr->parAttrDictId));
    SET_SYSNAME((*aDictAttr),A_DictAttr_SqlName,(attr->sqlName));
    SET_INT((*aDictAttr),A_DictAttr_Prog,(attr->progN)); /* REF8844 - LJE - 030327 */
    if (attr->isNullProgPkN) /* PMSTA-18593 - LJE - 151027 */
    {
        SET_NULL_SMALLINT((*aDictAttr), A_DictAttr_ProgPk);
    }
    else
    {
        SET_SMALLINT((*aDictAttr), A_DictAttr_ProgPk, (attr->progPkN));
    }
    if (attr->isNullProgBkN) /* PMSTA-18593 - LJE - 160121 */
    {
        SET_NULL_SMALLINT((*aDictAttr), A_DictAttr_ProgBk);
    }
    else
    {
        SET_SMALLINT((*aDictAttr), A_DictAttr_ProgBk, (attr->progBkN));
    }
    SET_SMALLINT((*aDictAttr), A_DictAttr_DispRank, (attr->dispRank));
    SET_FLAG((*aDictAttr),A_DictAttr_PrimaryFlg,(attr->primFlg));
    SET_FLAG((*aDictAttr),A_DictAttr_MandatoryFlg,(attr->mandatoryFlg));
    SET_FLAG((*aDictAttr),A_DictAttr_DbMandatoryFlg,(attr->dbMandatoryFlg));
    SET_NAME((*aDictAttr),A_DictAttr_Default,(attr->dfltVal.c_str()));

    if (attr->permValMap.empty() == false)
    {
        SET_FLAG_TRUE((*aDictAttr), A_DictAttr_PermValFlg);
    }
    else
    {
        SET_FLAG_FALSE((*aDictAttr), A_DictAttr_PermValFlg);
    }

    SET_FLAG((*aDictAttr),A_DictAttr_BusKeyFlg,(attr->busKeyFlg));
    SET_FLAG((*aDictAttr),A_DictAttr_LogicalFlg,(attr->logicalFlg));
    SET_FLAG((*aDictAttr),A_DictAttr_CustomFlg,(attr->custFlg));
    SET_ENUM((*aDictAttr),A_DictAttr_CalcEn,(attr->calcEn));
    SET_ENUM((*aDictAttr),A_DictAttr_PermAuthFlg,(attr->permAuthEn));
    SET_ENUM((*aDictAttr),A_DictAttr_EditEn,(attr->editionEn));
    SET_MASK((*aDictAttr),A_DictAttr_SubTpMask,(attr->subTypeMask));
    SET_MASK((*aDictAttr),A_DictAttr_QuickSearchMask,(attr->qSearchMask));
    SET_MASK((*aDictAttr),A_DictAttr_SearchMask,(attr->searchMask));
    SET_SMALLINT((*aDictAttr), A_DictAttr_ShortIdx, (SMALLINT_T)(attr->shortIdx));
    SET_ENUM((*aDictAttr),A_DictAttr_SecurityLevelEn,(attr->securityLevelEn));
    SET_NAME((*aDictAttr),A_DictAttr_KeyChar,(attr->keyCharC));
    SET_ENUM((*aDictAttr),A_DictAttr_WidgetEn,(attr->widgetEn));
    SET_SMALLINT((*aDictAttr),A_DictAttr_MaxDbLen, (SMALLINT_T)(attr->maxDbLenN));	/* DLA - PMSTA09887 - 101105 */
    SET_SMALLINT((*aDictAttr),A_DictAttr_DefaultDispLen, (SMALLINT_T)(attr->defaultDisplayLenN));	/* DLA - PMSTA09887 - 101105 */
    /* PMSTA-13664 - LJE - 120220 */
    SET_ENUM((*aDictAttr),A_DictAttr_TascViewEn,(attr->tascViewEn));
	/* DDV - 151029 - Avoid Break on debug when viewing dict_attribute in GUI */
    if (attr->refEntityAttributeDictId != 0)
        SET_DICT((*aDictAttr),A_DictAttr_RefEntityAttribDictId,(attr->refEntityAttributeDictId)); /* PMSTA-14452 - LJE - 121214 */
    SET_ENUM((*aDictAttr),A_DictAttr_FkPresentationEn,(attr->fkPresentationEn));
    SET_ENUM((*aDictAttr),A_DictAttr_PrecompFlg,(attr->precompFlg));
    SET_FLAG((*aDictAttr),A_DictAttr_VerticalSearchFlg,(attr->verticalSearchFlg));
    SET_FLAG((*aDictAttr),A_DictAttr_VerticalPatternFlg,(attr->verticalPatternFlg));
    SET_FLAG((*aDictAttr),A_DictAttr_MultiLangFlg,(attr->multiLanguageFlg));
    SET_ENUM((*aDictAttr),A_DictAttr_XdStatusEn,(attr->xdStatusEn));
    if (attr->linkedAttrDictId != 0)
        SET_DICT((*aDictAttr),A_DictAttr_LinkedAttribDictId,attr->linkedAttrDictId); /* PMSTA-13122 - LJE - 120524 */

    SET_ENUM((*aDictAttr), A_DictAttr_RefDeleteRuleEn, (attr->refDeleteRuleEn));
    SET_ENUM((*aDictAttr), A_DictAttr_RefSecurityRuleEn, (attr->refSecurityRuleEn));
    SET_ENUM((*aDictAttr), A_DictAttr_RefCheckRuleEn, (attr->refCheckRuleEn));
    SET_SMALLINT((*aDictAttr), A_DictAttr_ProgBk, (attr->progBkN));
    SET_ENUM((*aDictAttr), A_DictAttr_ExportEn, (attr->exportEn));
    SET_ENUM((*aDictAttr), A_DictAttr_ObjModifStatEn, (attr->objModifStatEn));
    SET_ENUM((*aDictAttr), A_DictAttr_FeatureEn, (attr->featureEn));
    SET_ENUM((*aDictAttr), A_DictAttr_ModelBankEn, (attr->modelBankEn)); /* PMSTA-27352 - LJE - 170606 */
    SET_ENUM((*aDictAttr), A_DictAttr_MeSpecialisationEn, (attr->meSpecialisationEn)); /* PMSTA-26108 - LJE - 170830 */
    SET_ENUM((*aDictAttr), A_DictAttr_OutboxPublishEn, (attr->outboxPublishEn));  /* PMSTA-45305 -Lalby- 210528 */

    return RET_SUCCEED;
}

/************************************************************************
**
** Function    : DBA_GetShortDictAttById
**
** Description :
**
** Arguments   :
**
** Return      :
**
** Creation    : REF9764 - LJE - 040107
**
************************************************************************/
RET_CODE DBA_GetShortDictAttById(OBJECT_ENUM              entity,
                                 DBA_DYNFLD_STP           sInputSt,
                                 DBA_DYNFLD_STP           *sDictAttr,
                                 DbiConnectionHelper&     )
{
    DICT_ATTRIB_STP     attr        = NULL;
    DICT_ENTITY_STP     dictEntity  = NULL;

    if (GET_DYNSTENUM(sInputSt) == S_DictAttr)
    {
        attr = DBA_GetAttributeById(GET_DICT(sInputSt,S_DictAttr_DictId));
    }
    else
    {
        attr = DBA_GetAttributeById(GET_DICT(sInputSt,Adm_Arg_Id));
    }

    dictEntity = DBA_GetDictEntitySt(entity);

    if (attr == NULL || dictEntity == NULL)
    {
        return RET_DBA_ERR_NODATA;
    }

    SET_DICT((*sDictAttr),S_DictAttr_DictId,(attr->attrDictId));
    SET_NAME((*sDictAttr),S_DictAttr_Name,(attr->name)); /* DLA - PMSTA09887 - 101116 */
    SET_DICT((*sDictAttr),S_DictAttr_EntityDictId,(attr->entDictId));
    SET_SYSNAME((*sDictAttr),S_DictAttr_SqlName,(attr->sqlName));
    SET_NAME((*sDictAttr),S_DictAttr_EntityName, (dictEntity->nameStr.c_str())); /* DLA - PMSTA09887 - 101116 */

    /* PMSTA-17208 - LJE - 140326 */
    SET_INT((*sDictAttr), S_DictAttr_Prog, (attr->progN));
    if (attr->isNullProgPkN) /* PMSTA-18593 - LJE - 151027 */
    {
        SET_NULL_SMALLINT((*sDictAttr), S_DictAttr_ProgPk);
    }
    else
    {
        SET_SMALLINT((*sDictAttr), S_DictAttr_ProgPk, (attr->progPkN));
    }
    SET_FLAG((*sDictAttr), S_DictAttr_BusKeyFlg, (attr->busKeyFlg));
    SET_SMALLINT((*sDictAttr), S_DictAttr_DispRank, (attr->dispRank));

    return RET_SUCCEED;
}


/************************************************************************
**
** Function    : DBA_GetAllFunctionResultById
**
** Description : Get All Function Result From Domain
**
** Arguments   :
**
** Return      :
**
** Creation    : MDE - REF5222 - 001129
**
************************************************************************/
RET_CODE   DBA_GetAllFunctionResultById(OBJECT_ENUM              ,
                                        DBA_DYNFLD_STP           sFunction,
                                        DBA_DYNFLD_STP           *aFunction,
                                        DbiConnectionHelper&     dbiConnHelper)
{
    DBA_DYNFLD_STP      sDomain=NULL, aDomain=NULL;
    RET_CODE            ret=RET_SUCCEED;

    if ((sDomain = ALLOC_DYNST(S_Domain)) == NULL)
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    if ((aDomain = ALLOC_DYNST(A_Domain)) == NULL)
    {
        FREE_DYNST(sDomain, S_Domain);
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    SET_ID(sDomain, S_Domain_Id, GET_ID(sFunction,S_FctResult_Id));
    if (dbiConnHelper.dbaGet(Domain, UNUSED, sDomain, &aDomain) != RET_SUCCEED) /*DLA - REF7057 - 011003 */
    {
        FREE_DYNST(sDomain, S_Domain);
        FREE_DYNST(aDomain, A_Domain);
        return(RET_DBA_ERR_NODATA);
    }
    FREE_DYNST(sDomain, S_Domain);

    COPY_DYNFLD(*aFunction, A_FctResult, A_FctResult_Id,             aDomain,A_Domain, A_Domain_FctResultId);
    COPY_DYNFLD(*aFunction, A_FctResult, A_FctResult_Cd,             aDomain,A_Domain, A_Domain_FctResultCd);
    COPY_DYNFLD(*aFunction, A_FctResult, A_FctResult_FctDictId,      aDomain,A_Domain, A_Domain_FctDictId);
    COPY_DYNFLD(*aFunction, A_FctResult, A_FctResult_DomainId,       aDomain,A_Domain, A_Domain_Id);
    COPY_DYNFLD(*aFunction, A_FctResult, A_FctResult_UserId,         aDomain,A_Domain, A_Domain_UsrId);
/*  COPY_DYNFLD(*aFunction, A_FctResult, A_FctResult_ModifDate,      aDomain,A_Domain, );*/
    COPY_DYNFLD(*aFunction, A_FctResult, A_FctResult_CalcFromDate,   aDomain,A_Domain, A_Domain_InterpFromDate);


    COPY_DYNFLD(*aFunction, A_FctResult, A_FctResult_CalcStratDate,  aDomain,A_Domain, A_Domain_InterpStratDate);

    COPY_DYNFLD(*aFunction, A_FctResult, A_FctResult_StatusEn,       aDomain,A_Domain, A_Domain_FctResultStatEn);
    COPY_DYNFLD(*aFunction, A_FctResult, A_FctResult_DimPtfDictId,   aDomain,A_Domain, A_Domain_DimPtfDictId);
    COPY_DYNFLD(*aFunction, A_FctResult, A_FctResult_PtfObjId,       aDomain,A_Domain, A_Domain_PtfObjId);
    COPY_DYNFLD(*aFunction, A_FctResult, A_FctResult_DimInstrDictId, aDomain,A_Domain, A_Domain_DimInstrDictId);
    COPY_DYNFLD(*aFunction, A_FctResult, A_FctResult_InstrObjId,     aDomain,A_Domain, A_Domain_InstrObjId);
    COPY_DYNFLD(*aFunction, A_FctResult, A_FctResult_DimStratDictId, aDomain,A_Domain, A_Domain_DimStratDictId);
    COPY_DYNFLD(*aFunction, A_FctResult, A_FctResult_StratObjId,     aDomain,A_Domain, A_Domain_StratObjId);

    FREE_DYNST(aDomain, A_Domain);

    return(ret);
}
/************************************************************************
**
** Function    : DBA_ConvShortDynstToAll
**
** Description :
**
** Arguments   :
**
** Return      :
**
** Creation    : GRD - REF4204.
**
************************************************************************/
EXTERN RET_CODE DBA_ConvShortDynstToAll(OBJECT_ENUM     object,
                                        DBA_DYNFLD_STP  sh,
                                        DBA_DYNFLD_STP  all)
{
    DICT_ENTITY_STP         dictEntityStp;

    if ((dictEntityStp = DBA_GetDictEntitySt(object)) == NULL)
        return RET_GEN_ERR_INVARG;

    for (auto& dictAttribStp : dictEntityStp->attr)
    {
        if ((dictAttribStp->shortIdx > 0) &&
            (dictAttribStp->busKeyFlg == TRUE) &&
            (dictAttribStp->isPhysicalAttribute()))
        {
            COPY_DYNFLD(all, GET_EDITGUIST(object), dictAttribStp->progN,
                        sh, GET_ADMINGUIST(object), dictAttribStp->shortIdx);
        }
    }

    return(RET_SUCCEED);
}

/************************************************************************
**
** Function    : DBA_GetShortAllData
**
** Description : Try to use the best way to get data.
**               Retrieve data using short or all.
**
** Arguments   :
**
** Return      :
**
** Creation    : GRD - REF4204 - 000627.
**               EFE - PMSTA-10131 - 111010  :
**                     return succedd even if no data are found :
**                     the user just don't have access to data due to
**                     its data profile .
**
************************************************************************/
EXTERN RET_CODE DBA_GetShortAllData(OBJECT_ENUM             object,
                                    DBA_DYNFLD_STP          inputDataStp, /* PMSTA-16677 - LJE - 130712 */
                                    FIELD_IDX_T             idxDataId,    /* PMSTA-16677 - LJE - 130712 */
                                    FLAG_T                  *shortDataFlg,
                                    DBA_DYNFLD_STP          *dataStp,
                                    int                     convOptions,
                                    int                     *connectNo,
                                    DBA_ERRMSG_INFOS_STP    msgStructPtr)
{
    DBA_PROC_STP    procedureSh = NULL;
    DBA_DYNFLD_STP  admArg = NULL,
                    shArg = NULL;
    RET_CODE        retCode = RET_SUCCEED;
    bool            bSecuredEntity = false;
    int n, count; /* PMSTA-10131-EFE-111010  */
    DICT_ATTRIB_STP *attributes; /* PMSTA-10131-EFE-111010  */
    ID_T            dataId=GET_ID(inputDataStp, idxDataId); /* PMSTA-16677 - LJE - 130712 */
    DICT_ENTITY_STP inputDictEntityStp;
    OBJECT_ENUM     inputObj;

    /*
     * We try to find the best way to get data.
     * We better use a 'get short' rather than a 'get all'.
     * We also better use an optimized stored procedure.
     */

/* PMSTA-17908 - 140501 - DDV - Same connection must be used to avoid lock.
   Old problem has been soved with PMSTA-14726 (DBA_Get2 get all messages on the connection).
   Now both cases must works correctly */
#if 0
    /* EFE - PMSTA-13511 -120110 */
    /* for those entity , we want to trap the message raised by the stored proc
     * That says :  The user %2! does not have Data Security Access to the code of entity
     * this can be done by modifying the option of connection
     */
    if ( object == CorporateAction ||
         object == List            ||
         object == Ptf             ||
         object == Strat           ||
         object == Third             )
    {
        convOptions = UNUSED;
    }
#endif

    inputObj = GET_OBJ_DYNST(GET_DYNSTENUM(inputDataStp));
    inputDictEntityStp = DBA_GetDictEntitySt(inputObj);

    if (inputObj == object &&
        inputDictEntityStp->primKeyNbr == 1 &&
        inputDictEntityStp->primKeyTab[0]->dataTpProgN == IdType &&
        GET_ID(inputDataStp, inputDictEntityStp->primKeyTab[0]->progN) == dataId &&
        GET_ADMINGUIST(inputObj) != NullDynSt)
    {
        if (((*dataStp) = ALLOC_DYNST(GET_ADMINGUIST(inputObj))) == NULL)
        {
            return(RET_MEM_ERR_ALLOC);
        }

        CONVERT_DYNST((*dataStp), GET_ADMINGUIST(inputObj), inputDataStp, GET_EDITGUIST(inputObj));

        *shortDataFlg = TRUE;
        return (retCode);
    }

    /* First of all, try to find a short. */
    if ((admArg = ALLOC_DYNST(Adm_Arg)) == NULL)
    {
        return(RET_MEM_ERR_ALLOC);
    }

    SET_ID(admArg, Adm_Arg_Id, dataId);

    procedureSh = DBA_GetStoredProcs(Get, object, UNUSED, Adm_Arg, admArg, GET_ADMINGUIST(object));

    /*
     * If no 'Short' exists or if not optimized, use the 'All'.
     */

    if ((procedureSh == NULL) || (procedureSh != NULL && procedureSh->optiIdx == NullOpti && bSecuredEntity == false ))
    {
        FREE_DYNST(admArg, Adm_Arg);

        if ( object != EOp ) /* DLA - REF11329 - 050721 */
        {
            if ((shArg = ALLOC_DYNST(GET_ADMINGUIST(object))) == NULL)     /* Use of 'Short' for input. */
            {
                FREE_DYNST(admArg, Adm_Arg);
                return(RET_MEM_ERR_ALLOC);
            }

            if ((*dataStp = ALLOC_DYNST(GET_EDITGUIST(object))) == NULL)   /* Use of 'All' for output. */
            {
                FREE_DYNST(admArg, Adm_Arg);
                FREE_DYNST(shArg, GET_ADMINGUIST(object));
                return(RET_MEM_ERR_ALLOC);
            }

            SET_ID(shArg, 0, dataId);
        }
        else /* DLA - REF11329 - 050721 */
        {
            if ((shArg = ALLOC_DYNST(S_Op)) == NULL)     /* Use of 'Short' for input. */
            {
                FREE_DYNST(admArg, Adm_Arg);
                return(RET_MEM_ERR_ALLOC);
            }

            if ((*dataStp = ALLOC_DYNST(GET_EDITGUIST(object))) == NULL)   /* Use of 'All' for output. */
            {
                FREE_DYNST(admArg, Adm_Arg);
                FREE_DYNST(shArg, S_Op);
                return(RET_MEM_ERR_ALLOC);
            }

            SET_ID(shArg, 0, dataId);

        }

        retCode = DBA_Get2(object,
                           UNUSED,
                           object != EOp ? GET_ADMINGUIST(object):S_Op,  /* Short. */ /* DLA - REF11329 - 050721 */
                           shArg,
                           GET_EDITGUIST(object),   /* All. */
                           dataStp,
                           convOptions,             /* Options */
                           connectNo,               /* AllocConn */
                           msgStructPtr);
        /*<PMSTA-10131 - EFE-111011*/
        if (retCode == RET_DBA_INFO_NODATA ||retCode ==  RET_DBA_INFO_NODATAWITHOPTI)
        {

                DBA_GetBusinessAttrib(object, &count, &attributes);
                DATATYPE_ENUM dataType;

                for (n = 0; n < count; n++)
                {
                    dataType = (DATATYPE_ENUM)GET_FLD_TYPE_MD(GET_EDITGUIST(object),attributes[n]->shortIdx);
                    if ( dataType == CodeType  )
                    {
                        SET_CODE((*dataStp), attributes[n]->shortIdx, "xxxxxxxxxxxxxxxxxxxx");
                    }
                    else  if ( dataType == IdType || dataType == DictType )
                    {
                        SET_NULL_ID((*dataStp),  attributes[n]->shortIdx);
                    }
                }
                retCode = RET_SUCCEED;
        } /*>PMSTA-10131 - EFE-111011*/
        else if (retCode != RET_SUCCEED)
        {
            FREE_DYNST(*dataStp, GET_EDITGUIST(object));
        }

        FREE_DYNST(shArg, object != EOp ? GET_ADMINGUIST(object):S_Op); /* DLA - REF11329 - 050721 */
        *shortDataFlg = FALSE;
    }
    else
    {
        if ((*dataStp = ALLOC_DYNST(GET_ADMINGUIST(object))) == NULL)  /* Use of 'Short'. */
        {
            FREE_DYNST(admArg, Adm_Arg);
            return(RET_MEM_ERR_ALLOC);
        }

        retCode = DBA_Get2(object,
                           UNUSED,
                           Adm_Arg,
                           admArg,
                           GET_ADMINGUIST(object),  /* Short. */
                           dataStp,
                           convOptions,             /* Options */
                           connectNo,               /* AllocConn */
                           msgStructPtr);

        /*<PMSTA-10131 - EFE-111011*/
        if (retCode == RET_DBA_INFO_NODATA ||retCode ==  RET_DBA_INFO_NODATAWITHOPTI)
        {

                DBA_GetBusinessAttrib(object, &count, &attributes);
                DATATYPE_ENUM dataType;

                for (n = 0; n < count; n++)
                {
                    dataType = (DATATYPE_ENUM)GET_FLD_TYPE_MD(GET_EDITGUIST(object),attributes[n]->shortIdx);
                    if ( dataType == CodeType  )
                    {
                        SET_CODE((*dataStp), attributes[n]->shortIdx, "xxxxxxxxxxxxxxxxxxxx");
                    }
                    else  if ( dataType == IdType || dataType == DictType )
                    {
                        SET_NULL_ID((*dataStp),  attributes[n]->shortIdx);
                    }
                }
                retCode = RET_SUCCEED;
        }/*>PMSTA-10131 - EFE-111011*/
        else if (retCode != RET_SUCCEED)
        {
            FREE_DYNST(*dataStp, GET_ADMINGUIST(object));
        }

        FREE_DYNST(admArg, Adm_Arg);
        *shortDataFlg = TRUE;
    }

    return(retCode);
}



/************************************************************************
**
**  Function    :   DICT_GetLabel
**
**  Description :   Get the label depending on the language, entity and object
**
**  Argument    :   DICT_T      language_dict_id
**                  DICT_T      entity_dict_id
**                  DICT_T      object_dict_id
**                  NAME_T		*name
**
**  WARNING     :   You must never free the name.
**  ATTENTION   :   Ne jamais lib�rer le name.
**
**  Return      :   RET_CODE
**
**  Creation	:   DEV5502 - CSA - 21122000
**  Modif.	    :
**
*************************************************************************/
RET_CODE    DICT_GetLabel(DICT_T language_dict_id, DICT_T entity_dict_id, DICT_T object_dict_id, const char **name, DbiConnectionHelper &dbiConnHelper)
{
    /************************
    ***  Local variables  ***
    ************************/
    RET_CODE    ret = RET_SUCCEED;


    /***********************
    ***  Test arguments  ***
    ***********************/
    if  (   (language_dict_id==EV_ServerLanguageID) ||  (EV_ServerLanguageID==0)    )
        ret = RET_GEN_INFO_NOACTION;
    if  (name==NULL)
        ret = RET_GEN_ERR_INVARG;


    /************************************
    ***  Test for the language array  ***
    ************************************/
    if  (   (ret==RET_SUCCEED)  &&  (dictLabelEntryPoint==NULL)    )
    {
        dictLabelEntryPoint = (DICT_LABEL_ENTRYPOINT_STP) CALLOC(1, sizeof(DICT_LABEL_ENTRYPOINT_ST));
        if  (dictLabelEntryPoint==NULL)
            ret = RET_MEM_ERR_ALLOC;
        else
        {
            dictLabelEntryPoint->dictLanguagesLoaded = 0;
            dictLabelEntryPoint->dictLanguagesTab = (struct DICT_LABEL_LANG_ST*) CALLOC(10, sizeof(struct DICT_LABEL_LANG_ST));
            if  (dictLabelEntryPoint->dictLanguagesTab==NULL)   ret = RET_MEM_ERR_ALLOC;
        }
    }


    /******************************
    ***  Test for the language  ***
    ******************************/
    if  (ret==RET_SUCCEED)
    {
        ret = DICT_CheckLanguage(language_dict_id, dbiConnHelper);
    }


    /*************************
    ***  Search the label  ***
    *************************/
    if  (ret==RET_SUCCEED)
    {
        ret = DICT_SearchLabel(language_dict_id, entity_dict_id, object_dict_id, name);
    }


    /**********************
    ***  Return status  ***
    **********************/
    return(ret);
}

/************************************************************************
**
**  Function    :   DICT_GetUniLabel
**
**  Description :   Get the label depending on the language, entity and object
**
**  Argument    :   DICT_T      language_dict_id
**                  DICT_T      entity_dict_id
**                  DICT_T      object_dict_id
**                  NAME_T		*name
**
**  WARNING     :   You must never free the name.
**  ATTENTION   :   Ne jamais lib�rer le name.
**
**  Return      :   RET_CODE
**
**  Creation	:   REF9303 - LJE - 030912
**  Modif.	    :
**
*************************************************************************/
RET_CODE    DICT_GetUniLabel(DICT_T language_dict_id, DICT_T entity_dict_id, DICT_T object_dict_id, const UChar **name, DbiConnectionHelper &dbiConnHelper)
{
    /************************
    ***  Local variables  ***
    ************************/
    RET_CODE    ret = RET_SUCCEED;


    /***********************
    ***  Test arguments  ***
    ***********************/
    if  (   (language_dict_id==EV_ServerLanguageID) ||  (EV_ServerLanguageID==0)    )
        ret = RET_GEN_INFO_NOACTION;
    if  (name==NULL)
        ret = RET_GEN_ERR_INVARG;


    /************************************
    ***  Test for the language array  ***
    ************************************/
    if  (   (ret==RET_SUCCEED)  &&  (dictLabelEntryPoint==NULL)    )
    {
        dictLabelEntryPoint = (DICT_LABEL_ENTRYPOINT_STP) CALLOC(1, sizeof(DICT_LABEL_ENTRYPOINT_ST));
        if  (dictLabelEntryPoint==NULL)
            ret = RET_MEM_ERR_ALLOC;
        else
        {
            dictLabelEntryPoint->dictLanguagesLoaded = 0;
            dictLabelEntryPoint->dictLanguagesTab = (struct DICT_LABEL_LANG_ST*) CALLOC(10, sizeof(struct DICT_LABEL_LANG_ST));
            if  (dictLabelEntryPoint->dictLanguagesTab==NULL)   ret = RET_MEM_ERR_ALLOC;
        }
    }


    /******************************
    ***  Test for the language  ***
    ******************************/
    if  (ret==RET_SUCCEED)
    {
        ret = DICT_CheckLanguage(language_dict_id, dbiConnHelper);
    }


    /*********************************
    ***  Search the unicode label  ***
    *********************************/
    if  (ret==RET_SUCCEED)
    {
        ret = DICT_SearchUniLabel(language_dict_id, entity_dict_id, object_dict_id, name);
    }


    /**********************
    ***  Return status  ***
    **********************/
    return(ret);
}


/************************************************************************
**
**  Function    :   DICT_CheckLanguage
**
**  Description :   Check if the language is loaded.
**                  Load it on demand !
**
**  Argument    :   DICT_T      language_dict_id
**
**  Return      :   RET_CODE
**
**  Creation	:   DEV5502 - CSA - 21122000
**  Modif.	    :
**
*************************************************************************/
STATIC  RET_CODE    DICT_CheckLanguage(DICT_T language_dict_id, DbiConnectionHelper &dbiConnHelper)
{
    /************************
    ***  Local variables  ***
    ************************/
    RET_CODE    ret = RET_SUCCEED;
    FLAG_T      languageLoaded = FALSE;
    int         i;


    /***************************
    ***  Check the language  ***
    ***************************/
    for (i=0 ; i<(dictLabelEntryPoint->dictLanguagesLoaded) ; i++)
    {
        if  (dictLabelEntryPoint->dictLanguagesTab[i].language_dict_id==language_dict_id)
        {
            languageLoaded = TRUE;
            break;
        }
    }


    /*************************************
    ***  If the language is not found  ***
    ***  Try to load it !              ***
    *************************************/
    if  (languageLoaded==FALSE)
    {
        ret = DICT_LoadLanguage(language_dict_id, dbiConnHelper);
    }


    /**********************
    ***  Return status  ***
    **********************/
    return(ret);
}



/************************************************************************
**
**  Function    :   DICT_SearchLabel
**
**  Description :   Search the good label...
**
**  Argument    :   DICT_T      language_dict_id
**                  DICT_T      entity_dict_id
**                  DICT_T      object_dict_id
**                  NAME_T  name
**
**  Return      :   RET_CODE
**
**  Creation	:   DEV5502 - CSA - 21122000
**  Modif.	    :
**
*************************************************************************/
STATIC  RET_CODE    DICT_SearchLabel(DICT_T language_dict_id, DICT_T entity_dict_id, DICT_T object_dict_id, const char **name)
{
    /************************
    ***  Local variables  ***
    ************************/
    RET_CODE    ret = RET_GEN_INFO_NODATA;
    int         languageIndex = -1;
    int         entityIndex = -1;


    /*********************************
    ***  Search the good language  ***
    *********************************/
    languageIndex = FindLanguageIndex(language_dict_id);


    /*******************************
    ***  Search the good entity  ***
    *******************************/
    if  (languageIndex>=0)
        entityIndex = FindEntityIndex(languageIndex, entity_dict_id);


    /*******************************
    ***  Search the good label   ***
    *******************************/
    if  (entityIndex>=0)
        ret = FindLabel(languageIndex, entityIndex, object_dict_id, name);


    /**********************
    ***  Return status  ***
    **********************/
    return(ret);
}

/************************************************************************
**
**  Function    :   DICT_SearchUniLabel
**
**  Description :   Search the good label...
**
**  Argument    :   DICT_T      language_dict_id
**                  DICT_T      entity_dict_id
**                  DICT_T      object_dict_id
**                  NAME_T		name
**
**  Return      :   RET_CODE
**
**  Creation	:   DEV5502 - CSA - 21122000
**  Modif.	    :
**
*************************************************************************/
STATIC  RET_CODE    DICT_SearchUniLabel(DICT_T language_dict_id, DICT_T entity_dict_id, DICT_T object_dict_id, const UChar **name)
{
    /************************
    ***  Local variables  ***
    ************************/
    RET_CODE    ret = RET_GEN_INFO_NODATA;
    int         languageIndex = -1;
    int         entityIndex = -1;


    /*********************************
    ***  Search the good language  ***
    *********************************/
    languageIndex = FindLanguageIndex(language_dict_id);


    /*******************************
    ***  Search the good entity  ***
    *******************************/
    if  (languageIndex>=0)
        entityIndex = FindEntityIndex(languageIndex, entity_dict_id);


    /***************************************
    ***  Search the good unicode label   ***
    ***************************************/
    if  (entityIndex>=0)
        ret = FindUniLabel(languageIndex, entityIndex, object_dict_id, name);


    /**********************
    ***  Return status  ***
    **********************/
    return(ret);
}


/************************************************************************
**
**  Function    :   FindLanguageIndex
**
**  Description :   Find the language in the general array
**
**  Argument    :   DICT_T      language_dict_id
**
**  Return      :   languageIndex
**
**  Creation	:   DEV5502 - CSA - 21122000
**  Modif.	    :
**
*************************************************************************/
STATIC  int FindLanguageIndex(DICT_T language_dict_id)
{
    /************************
    ***  Local variables  ***
    ************************/
    int retIdx;


    /*********************
    ***  Searching...  ***
    *********************/
    for (retIdx=0 ; retIdx<dictLabelEntryPoint->dictLanguagesLoaded ; retIdx++)
    {
        if  (dictLabelEntryPoint->dictLanguagesTab[retIdx].language_dict_id == language_dict_id)
            return(retIdx);
    }


    /*********************
    ***  Return index  ***
    *********************/
    return(-1);
}



/************************************************************************
**
**  Function    :   FindEntityIndex
**
**  Description :   Find the good entity in the selected language
**
**  Argument    :   int     languageIndex
**                  DICT_T  entity_dict_id
**
**  Return      :   entityIndex
**
**  Creation	:   DEV5502 - CSA - 21122000
**  Modif.	    :
**
*************************************************************************/
STATIC  int FindEntityIndex(int languageIndex, DICT_T entity_dict_id)
{
    /************************
    ***  Local variables  ***
    ************************/
    int                             retIdx, entitiesNumber;
    struct DICT_LABEL_ENTITY_IDX_ST *entities;


    /*********************
    ***  Searching...  ***
    *********************/
    entitiesNumber = dictLabelEntryPoint->dictLanguagesTab[languageIndex].entitiesNumber;
    entities = dictLabelEntryPoint->dictLanguagesTab[languageIndex].entities;
    for (retIdx=0 ; retIdx<entitiesNumber ; retIdx++)
    {
        if  (entities[retIdx].entity_dict_id == entity_dict_id)
            return(retIdx);
    }


    /*********************
    ***  Return index  ***
    *********************/
    return(-1);
}



/************************************************************************
**
**  Function    :   FindLabel
**
**  Description :   Find the label !
**
**  Argument    :   int         entityIndex
**                  DICT_T      object_dict_id
**                  NAME_T		*name
**
**  Return      :   RET_CODE
**
**  Creation	:   DEV5502 - CSA - 21122000
**  Modif.	    :
**
*************************************************************************/
STATIC  RET_CODE    FindLabel(int languageIndex, int entityIndex, DICT_T object_dict_id, const char **name)
{
    /************************
    ***  Local variables  ***
    ************************/
    RET_CODE                ret = RET_GEN_INFO_NODATA;
    int                     max, i, currentIdx, jump;
    FLAG_T                  flg;
    struct  DICT_LABEL_ST   *labels;


    /****************************
    ***  Data initialization  ***
    ****************************/
    max = dictLabelEntryPoint->dictLanguagesTab[languageIndex].entities[entityIndex].labelsNumber;
    currentIdx = max / 2;
    labels = dictLabelEntryPoint->dictLanguagesTab[languageIndex].entities[entityIndex].labels;
    jump = currentIdx;
    i = 0;
    flg = FALSE;


    /*********************
    ***  Searching...  ***
    *********************/
    while (flg==FALSE)
    {
        if  (labels[currentIdx].object_dict_id == object_dict_id)
        {
            /*  ObjectId has been found */
            ret = RET_SUCCEED;
            flg = TRUE;
            *name = labels[currentIdx].GET_dlLabel();
        }
        else
        {
            /*  ObjectId hasn't been found  */
            if  (jump>1)    jump = jump/2;
            if  (labels[currentIdx].object_dict_id > object_dict_id)
                currentIdx = currentIdx - jump;
            else
                currentIdx = currentIdx + jump;
            i++;
            if  (   (i==max)    ||  (currentIdx<0)  ||  (currentIdx>=max)   )
                flg = TRUE;
        }
    }


    /**********************
    ***  Return status  ***
    **********************/
    return(ret);
}

/************************************************************************
**
**  Function    :   FindUniLabel
**
**  Description :   Find the unicode label !
**
**  Argument    :   int         entityIndex
**                  DICT_T      object_dict_id
**                  NAME_T		*name
**
**  Return      :   RET_CODE
**
**  Creation	:
**  Modif.	    :
**
*************************************************************************/
STATIC  RET_CODE    FindUniLabel(int languageIndex, int entityIndex, DICT_T object_dict_id, const UChar **name)
{
    /************************
    ***  Local variables  ***
    ************************/
    RET_CODE                ret = RET_GEN_INFO_NODATA;
    int                     max, i, currentIdx, jump;
    FLAG_T                  flg;
    struct  DICT_LABEL_ST   *labels;


    /****************************
    ***  Data initialization  ***
    ****************************/
    max = dictLabelEntryPoint->dictLanguagesTab[languageIndex].entities[entityIndex].labelsNumber;
    currentIdx = max / 2;
    labels = dictLabelEntryPoint->dictLanguagesTab[languageIndex].entities[entityIndex].labels;
    jump = currentIdx;
    i = 0;
    flg = FALSE;


    /*********************
    ***  Searching...  ***
    *********************/
    while (flg==FALSE)
    {
        if  (labels[currentIdx].object_dict_id == object_dict_id)
        {
            /*  ObjectId has been found */
            ret = RET_SUCCEED;
            flg = TRUE;
            *name = labels[currentIdx].GET_dlUniLabel();
        }
        else
        {
            /*  ObjectId hasn't been found  */
            if  (jump>1)    jump = jump/2;
            if  (labels[currentIdx].object_dict_id > object_dict_id)
                currentIdx = currentIdx - jump;
            else
                currentIdx = currentIdx + jump;
            i++;
            if  (   (i==max)    ||  (currentIdx<0)  ||  (currentIdx>=max)   )
                flg = TRUE;
        }
    }


    /**********************
    ***  Return status  ***
    **********************/
    return(ret);
}

/************************************************************************
**
**  Function    :   DICT_LoadLanguage
**
**  Description :   Load the language requested
**
**  Argument    :   DICT_T      language_dict_id
**
**  Return      :   RET_CODE
**
**  Creation	:   DEV5502 - CSA - 21122000
**  Modif.	    :
**
*************************************************************************/
STATIC  RET_CODE    DICT_LoadLanguage(DICT_T language_dict_id, DbiConnectionHelper &dbiConnHelper)
{
    /************************
    ***  Local variables  ***
    ************************/
    RET_CODE        ret = RET_SUCCEED;
    DBA_DYNFLD_STP  *outputTab;
    int             outputNbr;


    /****************************************
    ***  Search the language in database  ***
    ****************************************/
    ret = DICT_LoadLanguageInDB(language_dict_id, &outputTab, &outputNbr, dbiConnHelper);


    /*************************************
    ***  Add elements into the arrays  ***
    *************************************/
    if  (ret==RET_SUCCEED && outputNbr > 0)
        ret = DICT_AddLanguage(language_dict_id, outputTab, outputNbr);


    /**********************
    ***  Return status  ***
    **********************/
    return(ret);
}


/************************************************************************
*   Function             : DBA_CmpLabel()
*
*   Description          : Sort a list of pointers on attribute by entity, sqlName.
*                          Function called by TLS_Sort(), 1 level
*
*   Arguments            : ptr1      pointer or first structure to compare
*                          ptr2      pointer or second structure to compare
*
*   Return               : difference between two ranks.
*                          negative value if first element < second element
*                          null value     if first element = second element
*                          positive value if first element > second element
*
*   Creation	         :   PMSTA07872 - LJE - 090213
*   Modif.	             :
*
*************************************************************************/
STATIC int DBA_CmpLabel(const void *ptr1, const void *ptr2)
{
    const DBA_DYNFLD_STP *dynPtr1 = (const DBA_DYNFLD_STP*) ptr1;
    const DBA_DYNFLD_STP *dynPtr2 = (const DBA_DYNFLD_STP*) ptr2;

    int ret;

    if ((ret = CMP_DYNFLD((*dynPtr1), (*dynPtr2), A_DictLabel_LangDictId, A_DictLabel_LangDictId, DictType)) != 0)
    {
        return ret;
    }

    if ((ret = CMP_DYNFLD((*dynPtr1), (*dynPtr2), A_DictLabel_EntDictId, A_DictLabel_EntDictId, DictType)) != 0)
    {
        return ret;
    }

    return (CMP_DYNFLD((*dynPtr1), (*dynPtr2), A_DictLabel_ObjDictId, A_DictLabel_ObjDictId, DictType));
}

/************************************************************************
**
**  Function    :   DICT_LoadLanguageInDB
**
**  Description :   Load the language requested from DB
**
**  Argument    :   DICT_T          language_dict_id
**                  DBA_DYNFLD_STP  **outputTab
**                  int             *outputNbr
**
**  Return      :   RET_CODE
**
**  Creation	:   DEV5502 - CSA - 21122000
**  Modif.	    :
**
*************************************************************************/
STATIC  RET_CODE    DICT_LoadLanguageInDB(DICT_T language_dict_id, DBA_DYNFLD_STP **outputTab, int *outputNbr, DbiConnectionHelper &dbiConnHelper)
{
    /************************
    ***  Local variables  ***
    ************************/
    RET_CODE        ret = RET_SUCCEED;
    DBA_DYNFLD_STP  inputArg = NULL;


    /**************************************************
    ***  Memory allocation for the input arguments  ***
    **************************************************/
    inputArg = ALLOC_DYNST(A_DictLabel);
    if (inputArg == NULL)    ret = RET_MEM_ERR_ALLOC;


    /*********************
    ***  Set argument  ***
    *********************/
    if  (ret==RET_SUCCEED)
        SET_ID(inputArg, A_DictLabel_LangDictId, language_dict_id);


    /****************************************************************
    ***  Call the Stored Procedure sel_all_dict_label_by_lang_id  ***
    ****************************************************************/
    if  (ret==RET_SUCCEED)
        ret = DBA_Select2(  DictLabel,      /*  Entitiy */
                            UNUSED,         /*  Role    */
                            A_DictLabel,    /*  Input structure datatype    */
                            inputArg,       /*  Input arguments */
                            A_DictLabel,    /*  Output structure datatype   */
                            outputTab,      /*  Array on output structures  */
                            UNUSED,         /*  Max rows    */
                            outputNbr,      /*  Number of element into the output array */
                            dbiConnHelper);        /*  Error structure */


    /*********************************
    ***  Free the input arguments  ***
    *********************************/
    FREE_DYNST(inputArg, A_DictLabel);

    /* PMSTA07872 - LJE - 090213 - Sort labels */
    if(TLS_Sort((char*)(*outputTab), (unsigned)*outputNbr, sizeof(DBA_DYNFLD_STP),
                (TLS_CMPFCT *)DBA_CmpLabel,
                NULL, SortRtnTp_None) == FALSE)
    {
        MSG_RETURN(RET_DBA_ERR_DBPROBLEM);
    }

    /**********************
    ***  Return status  ***
    **********************/
    return(ret);
}



/************************************************************************
**
**  Function    :   DICT_AddLanguage
**
**  Description :   Load the language requested
**
**  Argument    :   DICT_T          language_dict_id
**                  DBA_DYNFLD_STP  *outputTab
**                  int             outputNbr
**
**  Return      :   RET_CODE
**
**  Creation	:   DEV5502 - CSA - 21122000
**  Modif.	    :
**
*************************************************************************/
STATIC  RET_CODE    DICT_AddLanguage(DICT_T language_dict_id, DBA_DYNFLD_STP *outputTab, int outputNbr)
{
    /************************
    ***  Local variables  ***
    ************************/
    RET_CODE    ret = RET_SUCCEED;
    int         currentElt;
    DICT_T      entityID = -1;
    DICT_T      oldEntitiyID = -1;
    int         entitiesNbr, entityIdx;
    int         objectNbr, objectIdx = 0;

    /****************************
    ***  Add the language id  ***
    ****************************/
    dictLabelEntryPoint->dictLanguagesTab[dictLabelEntryPoint->dictLanguagesLoaded].language_dict_id = language_dict_id;


    /************************************
    ***  Allocate the entities array  ***
    ************************************/
    entitiesNbr = DICT_GetEntitiesNumber(outputTab, outputNbr);
    dictLabelEntryPoint->dictLanguagesTab[dictLabelEntryPoint->dictLanguagesLoaded].entitiesNumber = entitiesNbr;
    dictLabelEntryPoint->dictLanguagesTab[dictLabelEntryPoint->dictLanguagesLoaded].entities =
                                            (struct DICT_LABEL_ENTITY_IDX_ST*) CALLOC(entitiesNbr, sizeof(struct DICT_LABEL_ENTITY_IDX_ST));
    entityIdx = -1;
    if  (dictLabelEntryPoint->dictLanguagesTab[dictLabelEntryPoint->dictLanguagesLoaded].entities==NULL)
        ret = RET_MEM_ERR_ALLOC;


    /*****************************
    ***  Loop on all elements  ***
    *****************************/
    if  (ret==RET_SUCCEED)
        for (currentElt=0 ; currentElt<outputNbr ; currentElt++)
        {
            entityID = GET_DICT(outputTab[currentElt], A_DictLabel_EntDictId); /* DLA - REF9089 - 030512 */
            if  (oldEntitiyID!=entityID)
            {
                entityIdx++;
                dictLabelEntryPoint->dictLanguagesTab[dictLabelEntryPoint->dictLanguagesLoaded].entities[entityIdx].entity_dict_id = entityID;
                oldEntitiyID = entityID;
                objectNbr = DICT_GetObjectsNumber(entityID, outputTab, outputNbr);
                dictLabelEntryPoint->dictLanguagesTab[dictLabelEntryPoint->dictLanguagesLoaded].entities[entityIdx].labelsNumber = objectNbr;
                dictLabelEntryPoint->dictLanguagesTab[dictLabelEntryPoint->dictLanguagesLoaded].entities[entityIdx].labels =
                                                                (struct DICT_LABEL_ST*) CALLOC(objectNbr, sizeof(struct DICT_LABEL_ST));
                if  (dictLabelEntryPoint->dictLanguagesTab[dictLabelEntryPoint->dictLanguagesLoaded].entities[entityIdx].labels==NULL)
                {
                    ret = RET_MEM_ERR_ALLOC;
                    break;
                }
                objectIdx = 0;
            }

            dictLabelEntryPoint->dictLanguagesTab[dictLabelEntryPoint->dictLanguagesLoaded].entities[entityIdx].labels[objectIdx].object_dict_id =
                GET_DICT(outputTab[currentElt], A_DictLabel_ObjDictId); /* DLA - REF9089 - 030512 */
            dictLabelEntryPoint->dictLanguagesTab[dictLabelEntryPoint->dictLanguagesLoaded].entities[entityIdx].labels[objectIdx].SET_dlLabel(/* PMSTA-22278 - 160203 - DDV - Use char* and UChar* instead of STRING1000_T and UNI_STRING1000_T */
                    GET_VARSTRING1000( outputTab[currentElt], A_DictLabel_Name)); /* REF9303 - LJE - 030912 */ /* DLA - PMSTA09887 - 101116 */ /* PMSTA-19243 - DDV - 150427 - Change label datatype from name_t to note_t */

            /* REF9303 - LJE - 030912 */
            if (IS_USTRINGFLD(A_DictLabel, A_DictLabel_Name))
            {
                dictLabelEntryPoint->dictLanguagesTab[dictLabelEntryPoint->dictLanguagesLoaded].entities[entityIdx].labels[objectIdx].SET_dlUniLabel( /* PMSTA-22278 - 160203 - DDV - Use char* and UChar* instead of STRING1000_T and UNI_STRING1000_T */
                         GET_USTRING( outputTab[currentElt], A_DictLabel_Name));/* DLA - PMSTA09887 - 101116 */ /* PMSTA-19243 - DDV - 150427 - Change label datatype from name_t to note_t */
            }
            else
            {
                UNI_STRING1000_T  tmpUniLabel;
                ICU4AAA_ConvertFromASCII(GET_STRING( outputTab[currentElt], A_DictLabel_Name), /* DLA - PMSTA09887 - 101116 */ /* PMSTA-19243 - DDV - 150427 - Change label datatype from name_t to note_t */
                                         -1,
                                         tmpUniLabel,
                                         GET_MAXCHARLEN(outputTab[currentElt][A_DictLabel_Name].dataType),  /* PMSTA-33077 - DLA - 181004 */
                                         NULL);

                dictLabelEntryPoint->dictLanguagesTab[dictLabelEntryPoint->dictLanguagesLoaded].entities[entityIdx].labels[objectIdx].SET_dlUniLabel(tmpUniLabel); /* PMSTA-22278 - 160203 - DDV - Use char* and UChar* instead of STRING1000_T and UNI_STRING1000_T */
           }
            objectIdx++;
        }


    /**********************************************
    ***  Increase the loaded languages counter  ***
    **********************************************/
    dictLabelEntryPoint->dictLanguagesLoaded++;

    /******************************************************
    ***  Free the dynamic structure provided by the DB  ***
    ******************************************************/
    DBA_FreeDynStTab(outputTab, outputNbr, A_DictLabel);	/* PMSTA14443 - DDV - 120709 - Purify */

    /**********************
    ***  Return status  ***
    **********************/
    return(ret);
}



/************************************************************************
**
**  Function    :   DICT_GetEntitiesNumber
**
**  Description :   Return the entities number
**
**  Argument    :   DBA_DYNFLD_STP  *outputTab
**                  int             outputNbr
**
**  Return      :   int
**
**  Creation	:   DEV5502 - CSA - 21122000
**  Modif.	    :
**
*************************************************************************/
STATIC  int DICT_GetEntitiesNumber(DBA_DYNFLD_STP *outputTab, int outputNbr)
{
    /************************
    ***  Local variables  ***
    ************************/
    int i, ret = 0;
    DICT_T  oldEntityId = 0, newEntityID = 0;


    /*****************************
    ***  Loop on all elements  ***
    *****************************/
    for (i=0; i<outputNbr ; i++)
    {
        newEntityID = GET_DICT(outputTab[i], A_DictLabel_EntDictId); /* DLA - REF9089 - 030512 */
        if  (newEntityID!=oldEntityId)
        {
            ret++;
            oldEntityId = newEntityID;
        }
    }


    /*********************
    ***  Return value  ***
    *********************/
    return(ret);
}



/************************************************************************
**
**  Function    :   DICT_GetEntitiesNumber
**
**  Description :   Return the entities number
**
**  Argument    :   DBA_DYNFLD_STP  *outputTab
**                  int             outputNbr
**
**  Return      :   int
**
**  Creation	:   DEV5502 - CSA - 21122000
**  Modif.	    :
**
*************************************************************************/
STATIC  int DICT_GetObjectsNumber(DICT_T entityID, DBA_DYNFLD_STP *outputTab, int outputNbr)
{
    /************************
    ***  Local variables  ***
    ************************/
    int i, objNbr = 0;
    DICT_T  entID;


    /*****************************
    ***  Loop on all elements  ***
    *****************************/
    for (i=0; i<outputNbr ; i++)
    {
        entID = GET_DICT(outputTab[i], A_DictLabel_EntDictId); /* DLA - REF9089 - 030512 */
        if  (entID==entityID)   objNbr++;
    }


    /*********************
    ***  Return value  ***
    *********************/
    return(objNbr);
}


/************************************************************************
**
**  Function    :   DBA_LoadUserDataProfInfo
**
**  Description :   Load the data profile id of the current user.
**
**  Argument    :   None
**
**  Return      :   RET_CODE
**
**  Creation	:   SKE - 010222 -
**
**
*************************************************************************/
RET_CODE DBA_LoadUserDataProfInfo()
{
    RET_CODE        ret = RET_SUCCEED;
    DBA_DYNFLD_STP  sApplUserSt=NULL;
    DBA_DYNFLD_STP  aApplUserSt=NULL;
    ID_T            userId;
    ID_T            dataProfileId;
    std::string     login;
    DbiConnectionHelper dbiConnHelper(AAATransactionEnum::NotTransactionnal, SqlServer, ROLE_INIT);

    if (!dbiConnHelper.isValidAndInit())
    {
        return(RET_DBA_ERR_CANNOTCONNECT);
    }

    /* Get user login */
    GEN_GetUserInfo(UserId, &userId);
    GEN_GetUserInfo(UserLogin, login);

    sApplUserSt = ALLOC_DYNST(S_ApplUser);
    aApplUserSt = ALLOC_DYNST(A_ApplUser);


    SET_ID(sApplUserSt, S_ApplUser_Id, userId);
    ret = dbiConnHelper.dbaGet(ApplUser,
                               UNUSED,
                               sApplUserSt,
                               &aApplUserSt);

    if (ret == RET_DBA_INFO_NODATA)
    {
        MSG_SendMesg(RET_DBA_ERR_NODATA, 4, FILEINFO, "appl_user", login.c_str());
    }

    if (IS_NULLFLD(aApplUserSt, A_ApplUser_Id))
    {
        FREE_DYNST(aApplUserSt, A_ApplUser);
        FREE_DYNST(sApplUserSt, S_ApplUser);
        return(RET_DBA_ERR_NODATA);
    }

    dataProfileId = GET_ID(aApplUserSt, A_ApplUser_DataProfileId);
    GEN_SetUserInfo(DataProfileId, &dataProfileId);

    FREE_DYNST(aApplUserSt, A_ApplUser);
    FREE_DYNST(sApplUserSt, S_ApplUser);

    return(RET_SUCCEED);
}



/************************************************************************
*
*  Function    : DBA_GetAllInstrFK()
*
*  Description : Search all reference to fkentity in the main entity.
*
*  Arguments   : mainEntity : entity in which FK must be search
*                fKEntity   : entity of the researche FK
*                fkArray    : retuned array of integer containing index of all FK on fKEntity in mainEntity
*
*  Return      : RET_SUCCEED : if ok
*
*  Creation D. : REF7560 - DDV - 020603
*  Last modif. :
*
*************************************************************************/
RET_CODE DBA_GetAllFK(OBJECT_ENUM mainEntityObjEnum,
                      OBJECT_ENUM fKEntityObjEnum,
                      FLAG_T      ,
                      int         **fKArrayPtr,
                      int         *fKNbr)
{
    DICT_ENTITY_STP mainEntityDictSt, fKEntityDictSt;

    if (fKArrayPtr == NULL || fKNbr == NULL)
        return(RET_SRV_GEN_ERR_INVARG);

    (*fKNbr) = 0;

    if ((mainEntityDictSt =  DBA_GetDictEntitySt(mainEntityObjEnum)) == NULL ||
        (fKEntityDictSt =  DBA_GetDictEntitySt(fKEntityObjEnum)) == NULL)
        return RET_GEN_ERR_INVARG;

    if ((*fKArrayPtr) == NULL)
        (*fKArrayPtr) = (int *) CALLOC(mainEntityDictSt->attr.size(), sizeof(int));
    else
        (*fKArrayPtr) = (int *) REALLOC((*fKArrayPtr), mainEntityDictSt->attr.size() * sizeof(int));

    if ((*fKArrayPtr) == NULL)
        MSG_RETURN(RET_MEM_ERR_ALLOC);

    for (auto& dictAttribStp : mainEntityDictSt->attr)
    {
        if (dictAttribStp->refEntDictId == fKEntityDictSt->entDictId)
        {
            (*fKArrayPtr)[(*fKNbr)] = dictAttribStp->progN;
            (*fKNbr)++;
        }
    }

    (*fKArrayPtr) = (int *) REALLOC((*fKArrayPtr), (*fKNbr) * sizeof(int));

    return(RET_SUCCEED);
}


/************************************************************************
**
**  Function    :   DBA_CheckLogicalAttribEditMask
**
**  Description :   return if shortcut visible or not
**
**  Argument    :   entityIn, entityOut, nature
**
**  Return      :   FLAG_T
**
**  Creation    :   FPL-REF7420-020729
**
*************************************************************************/
FLAG_T  DBA_CheckLogicalAttribEditMask(OBJECT_ENUM entityIn, OBJECT_ENUM entityOut, ENUM_T nature)
{
    DICT_ENTITY_STP     dictEntityStp;
    DICT_T              dictId = 0;
    FLAG_T              retFlg = FALSE;


    if ((entityIn == NullEntity) ||
        (entityOut == NullEntity) ||
        (nature < 0))
    {
        return FALSE;
    }

    if ((dictEntityStp = DBA_GetDictEntitySt(entityIn)) != NULL)
    {
        for (auto& dictAttribStp : dictEntityStp->attr)
        {

            DBA_GetDictId(entityOut, &dictId);
            if ((dictAttribStp->logicalFlg == TRUE) &&
                (dictId == dictAttribStp->refEntDictId))
            {
                retFlg = (FLAG_T)CHECK_BITMASK(DICTATTR_SUBTYPEMASK(dictAttribStp), nature);
                break;  /* Stop the loop, because we find what we want */
            }
        }
    }
    else
    {
        retFlg = FALSE ;    /* if error, we don't give access to the button for security */
    }

    return retFlg ;
}

/************************************************************************
**
**  Function    :   DBA_GetMandatoryFieldList
**
**  Description :   Return the list of all fields that are mandatory and can not be computed by default value
**
**  Argument    :   none
**
**  Return      :   RET_CODE
**
**  Creation	:   PMSTA05469 - DDV - 080131
**
**  Modif.		:   PMSTA-17133 - 051113 - PMO : Many compilation warnings in C code especially " Converting a 64-bit type value to "int" causes truncation."
**
*************************************************************************/
EXTERN RET_CODE	DBA_GetMandatoryFieldList(DBA_DYNST_ENUM dynSt, FLAG_T *flgTab, const size_t flgTabNb)
{

    if (flgTab == NULL)
    {
        MSG_RETURN(RET_GEN_ERR_INVARG);
    }

    memset(flgTab, '\0', flgTabNb * sizeof(FLAG_T));    /* PMSTA-17133 - 051113 - PMO */

    if (dynSt == ExtOp)
    {
        flgTab[ExtOp_NatureEn] = TRUE;
        flgTab[ExtOp_PtfId] = TRUE;
        flgTab[ExtOp_InstrId] = TRUE;
    }

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   DBA_GetFieldToCompleteList
**
**  Description :   Return the list of all fields that are mandatory and can be computed by default value
**
**  Argument    :   none
**
**  Return      :   RET_CODE
**
**  Creation	:   PMSTA05469 - DDV - 080131
**
**  Modif.		:   PMSTA-17133 - 051113 - PMO : Many compilation warnings in C code especially " Converting a 64-bit type value to "int" causes truncation."
**
*************************************************************************/
EXTERN RET_CODE	DBA_GetFieldToCompleteList(DBA_DYNST_ENUM dynSt, FLAG_T *flgTab, const size_t flgTabNb)
{

    if (flgTab == NULL)
    {
        MSG_RETURN(RET_GEN_ERR_INVARG);
    }

    memset(flgTab, '\0', flgTabNb * sizeof(FLAG_T));    /* PMSTA-17133 - 051113 - PMO */

    if (dynSt == ExtOp)
    {
        flgTab[ExtOp_PtfCurrId] = TRUE;
        flgTab[ExtOp_InstrCurrId] = TRUE;
        flgTab[ExtOp_AcctCurrId] = TRUE;
        flgTab[ExtOp_Acct2CurrId] = TRUE;
        flgTab[ExtOp_Acct3CurrId] = TRUE;
        flgTab[ExtOp_AdjInstrCurrId] = TRUE;
        flgTab[ExtOp_AdjPosCurrId] = TRUE;
        flgTab[ExtOp_AdjPortCurrId] = TRUE;
        flgTab[ExtOp_CashPtfCurrId] = TRUE;
        flgTab[ExtOp_LockOpCurrId] = TRUE;
        flgTab[ExtOp_LockFiCurrId] = TRUE;
        flgTab[ExtOp_InstrNetAmt] = TRUE;
    }

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   DBA_GetDataFromDynStp
**
**  Description :   Add specific Format initialisation for DynList format.
**
**  Arguments   :   GUI_FMT_STP fmtStp, GUI_FINA_STP finaStp
**
**  Return      :   PTR
**
**  Creation    :   FIH - REF - 980804
**  Modif       :   FIH-REF8683-030521  Moved from guilib03.c
**                  REF11780 - 100406 - PMO : Implementation of the Sybase timestamp field
**
*************************************************************************/
PTR DBA_GetDataFromDynStp (DATATYPE_ENUM dataType, DBA_DYNFLD_STP dbaDynStp)
{
    return DBA_GetDataFromDynFldData(dataType, dbaDynStp->data);
}

/************************************************************************
**
**  Function    :   DBA_GetDataFromDynFldData
**
**  Description :
**
**  Arguments   :
**
**  Return      :   PTR
**
**  Creation    :   PMSTA-nuodb - LJE - 190425
**  Modif.      :
**
*************************************************************************/
PTR  DBA_GetDataFromDynFldData(DATATYPE_ENUM dataType, DBA_DYNFLDDATA_UN &dynFldDataPtr)
{
    switch (GET_CTYPE(dataType))
    {
        case DoubleCType:        return &dynFldDataPtr.dbleValue;
        case IntCType:           return &dynFldDataPtr.intValue;
        case LongLongCType:      return &dynFldDataPtr.longlongValue;
        case ShortCType:         return &dynFldDataPtr.shortValue;
        case TextPtrCType:
        case CharPtrCType:       return dynFldDataPtr.strData.ptr;
        case UniTextPtrCType:
        case UniCharPtrCType:    return dynFldDataPtr.ustrData.ptr;
        case PtrCType:           return dynFldDataPtr.ptr;
        case UCharCType:         return &dynFldDataPtr.ucharValue;
        case UIntCType:          return &dynFldDataPtr.uintValue;
        case UShortCType:        return &dynFldDataPtr.ushortValue;
        case DateTimeStCType:    return &dynFldDataPtr.datetime64St;
        case MultiArrayPtrCType: return &dynFldDataPtr.multiArrayDataPtr;
        case ExtPtrCType:        return &dynFldDataPtr.extPtr;
        case ArrayPtrCType:      return &dynFldDataPtr.arrayPtr;
        case TimeStampCType:     return &dynFldDataPtr.timeStampValue;
        case BinaryCType:        return &dynFldDataPtr.binaryValue;
    }

    return nullptr;
}

/************************************************************************
**
**  Function    :   DBA_GetDataSizeFromDynFldData
**
**  Description :
**
**  Arguments   :
**
**  Return      :   size_t
**
**  Creation    :   PMSTA-49178 - LJE - 220906
**  Modif.      :
**
*************************************************************************/
size_t  DBA_GetDataSizeFromDynFldData(DATATYPE_ENUM dataType, DBA_DYNFLDDATA_UN& dynFldDataPtr)
{
    switch (GET_CTYPE(dataType))
    {
        case DoubleCType:        return sizeof(dynFldDataPtr.dbleValue);
        case IntCType:           return sizeof(dynFldDataPtr.intValue);
        case LongLongCType:      return sizeof(dynFldDataPtr.longlongValue);
        case ShortCType:         return sizeof(dynFldDataPtr.shortValue);
        case TextPtrCType:
        case CharPtrCType:       return sizeof(dynFldDataPtr.strData.ptr);
        case UniTextPtrCType:
        case UniCharPtrCType:    return sizeof(dynFldDataPtr.ustrData.ptr);
        case PtrCType:           return sizeof(dynFldDataPtr.ptr);
        case UCharCType:         return sizeof(dynFldDataPtr.ucharValue);
        case UIntCType:          return sizeof(dynFldDataPtr.uintValue);
        case UShortCType:        return sizeof(dynFldDataPtr.ushortValue);
        case DateTimeStCType:    return sizeof(dynFldDataPtr.datetime64St);
        case MultiArrayPtrCType: return sizeof(dynFldDataPtr.multiArrayDataPtr);
        case ExtPtrCType:        return sizeof(dynFldDataPtr.extPtr);
        case ArrayPtrCType:      return sizeof(dynFldDataPtr.arrayPtr);
        case TimeStampCType:     return sizeof(dynFldDataPtr.timeStampValue);
        case BinaryCType:        return sizeof(dynFldDataPtr.binaryValue);
    }

    return 0;
}

/************************************************************************
**  Function             : DBA_GetDictFctList()
**
**  Description          : According to the received list type,
**                         return a function list with object enum, label.
**
**  Arguments            : fctSelTp    list type
**                         fctInfoPtr  structure which will be filled.
**                         output : entityNb (function number)
**                                  entityTab is allocated and filled
**
**  Warning !!           : parent function must deallocate the pointer
**
**  Return               : RET_SUCCEED or error code
**
**  Modif.	    :   ROI - 961114 - DVP245
**  Modif.	    :   ROI - 000413 - REF4497
**
*************************************************************************/
RET_CODE DBA_GetDictFctList(FCT_SEL_TP_ENUM fctSelTp,
                            ENTITIES_INFO_STP fctInfoPtr)
{
    DICT_FCT_STP	fctStp;
    RET_CODE		ret;
    char			*label;
    UChar			*uniLabel; /* REF9303 - LJE - 030912 */
    int				i, j, iCpt, iPos;

    fctInfoPtr->entityNb = 0;
    fctInfoPtr->entityTab = NULL;

    switch (fctSelTp)
    {
    case FormatFctList :
            fctInfoPtr->entityNb = EV_DictFctWithFmtNb;

        if ((fctInfoPtr->entityTab = (VSH_ENTITY_INFO_STP)
               CALLOC(fctInfoPtr->entityNb,
                  sizeof(VSH_ENTITY_INFO_ST))) == NULL)
        {
          fctInfoPtr->entityNb = 0;
          MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        /* FormatFctSel list */
        j = 0;                      /*  FIH-REF5917-010404  */
        for (i=0; i < fctInfoPtr->entityNb; i++)
        {
            fctStp = EV_DictFctWithFmtTab[i];
            if (fctStp->entityDictId == 0)
            {
                fctInfoPtr->entityTab[j].entityRef = (OBJECT_ENUM) fctStp->dictId;
                fctInfoPtr->entityTab[j].id = fctStp->dictId;
                strcpy(fctInfoPtr->entityTab[j].sqlName, fctStp->procName);	/* ROI - 000413 - REF4497 */
                strcpy(fctInfoPtr->entityTab[j].label, fctStp->label);
                u_strcpy(fctInfoPtr->entityTab[j].uniLabel, fctStp->uniLabel); /* REF9303 - LJE - 030912 */
                j++;                /*  FIH-REF5917-010404  */
            }
        }
        fctInfoPtr->entityNb = j;   /*  FIH-REF5917-010404  */
        if ((fctInfoPtr->entityTab = (VSH_ENTITY_INFO_STP) REALLOC(fctInfoPtr->entityTab, j * sizeof(VSH_ENTITY_INFO_ST))) == NULL)
        {
            fctInfoPtr->entityNb = 0;
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }
        break;

    case FctResultList:		/* REF2644 */
        fctInfoPtr->entityNb = 12;   /* REF3371 */       /*  FIH-REF7228-020207  8 become 9  */ /*  FPL-080818-PMSTA06761 9->10 */  /*  HFI-PMSTA-31802-180618  11  */ /* PMSTA-30894 - CHU - 180711 12 */
        if ((fctInfoPtr->entityTab = (VSH_ENTITY_INFO_STP)
               CALLOC(fctInfoPtr->entityNb,
                  sizeof(VSH_ENTITY_INFO_ST))) == NULL)
        {
          fctInfoPtr->entityNb = 0;
          MSG_RETURN(RET_MEM_ERR_ALLOC);
        }


        /* REF 2644 : hard coded : */
        i=0;
        fctInfoPtr->entityTab[i++].id = DictFct_CheckStrat;
        fctInfoPtr->entityTab[i++].id = DictFct_ReconcStrat;
        fctInfoPtr->entityTab[i++].id = DictFct_Report;
        fctInfoPtr->entityTab[i++].id = DictFct_SynthAdmin;
        fctInfoPtr->entityTab[i++].id = DictFct_PLRestart;
        fctInfoPtr->entityTab[i++].id = DictFct_AllocateOrder;
        fctInfoPtr->entityTab[i++].id = DictFct_OrderEntry;
        fctInfoPtr->entityTab[i++].id = DictFct_PreTradeCheckStrat;	/* REF3371 - RAK - 991221 */
        fctInfoPtr->entityTab[i++].id = DictFct_OrderAllocation;    /*  FIH-REF7228-011210  */
        fctInfoPtr->entityTab[i++].id = DictFct_EventGeneration;    /*  FPL-080818-PMSTA06761   */
        fctInfoPtr->entityTab[i++].id = DictFct_ManageSession;      /*  HFI-PMSTA-31802-180618  */
        fctInfoPtr->entityTab[i++].id = DictFct_ManagePayout;       /* PMSTA-30894 - CHU - 180711 */

        for (i = 0; i < fctInfoPtr->entityNb ; i++)
        {
            fctInfoPtr->entityTab[i].entityRef = (OBJECT_ENUM)(signed)fctInfoPtr->entityTab[i].id; /* REF7264 - LJE - 020205 */
            DBA_GetDictFctInfo(fctInfoPtr->entityTab[i].id, DictFctInfo_ProcName, (PTR) &label);	/* ROI - 000413 - REF4497 */ /* REF7264 - LJE - 020205 */   /*  FPL-PMSTA08801-100714   */
            strcpy(fctInfoPtr->entityTab[i].sqlName, label);										/* ROI - 000413 - REF4497 */
            DBA_GetDictFctInfo(fctInfoPtr->entityTab[i].id, DictFctInfo_Label, (PTR) &label); /* REF7264 - LJE - 020205 */  /*  FPL-PMSTA08801-100714   */
            strcpy(fctInfoPtr->entityTab[i].label, label);
            /* REF9303 - LJE - 030912 */
            DBA_GetDictFctInfo(fctInfoPtr->entityTab[i].id, DictFctInfo_UniLabel, (PTR) &uniLabel); /*  FPL-PMSTA08801-100714   */
            u_strcpy(fctInfoPtr->entityTab[i].uniLabel, uniLabel);
        }
        /* FPL-REF7641-020820 we need to add sub-function */
        for (iCpt = 0 ; iCpt < DBA_GetDictFctRows() ; iCpt++)
        {
            fctStp = DBA_GetDictFctStp(iCpt);
            if ((fctStp->parFctDictId != fctStp->dictId)
                &&
                (fctStp->entityDictId == 0) /* FPL-REF7862-020911 */
                &&
                ((fctStp->parFctDictId == DictFct_CheckStrat) ||
                 (fctStp->parFctDictId == DictFct_ReconcStrat) ||
                 (fctStp->parFctDictId == DictFct_Report) ||
                 (fctStp->parFctDictId == DictFct_SynthAdmin) ||
                 (fctStp->parFctDictId == DictFct_PLRestart) ||
                 (fctStp->parFctDictId == DictFct_AllocateOrder) ||
                 (fctStp->parFctDictId == DictFct_OrderEntry) ||
				 (fctStp->parFctDictId == DictFct_SessionsMonitoring) ||
                 (fctStp->parFctDictId == DictFct_PreTradeCheckStrat) ||
                 (fctStp->parFctDictId == DictFct_OrderAllocation) ||
                 (fctStp->parFctDictId == DictFct_EventGeneration) ||
                 (fctStp->parFctDictId == DictFct_ManageSession) ||                /*  HFI-PMSTA-31802-180618  */
                 (fctStp->parFctDictId == DictFct_ManagePayout)                    /* PMSTA-30894 - CHU - 180711 */
                )
               )
            {
                /* here, we are in case of a sub-fn for one of the tested fn */
                iPos = fctInfoPtr->entityNb ;
                fctInfoPtr->entityNb++;
                fctInfoPtr->entityTab = (VSH_ENTITY_INFO_STP) REALLOC ( fctInfoPtr->entityTab
                                                                      , fctInfoPtr->entityNb * sizeof(VSH_ENTITY_INFO_ST)
                                                                      );
                fctInfoPtr->entityTab[iPos].id        = (OBJECT_ENUM)(signed)fctStp->dictId;
                fctInfoPtr->entityTab[iPos].entityRef = (OBJECT_ENUM)(signed)fctStp->dictId;
                DBA_GetDictFctInfo(fctInfoPtr->entityTab[iPos].id, DictFctInfo_ProcName, (PTR) &label); /*  FPL-PMSTA08801-100714   */
                strcpy(fctInfoPtr->entityTab[iPos].sqlName, label);
                DBA_GetDictFctInfo(fctInfoPtr->entityTab[iPos].id, DictFctInfo_Label, (PTR) &label);    /*  FPL-PMSTA08801-100714   */
                strcpy(fctInfoPtr->entityTab[iPos].label, label);
                /* REF9303 - LJE - 030912 */
                DBA_GetDictFctInfo(fctInfoPtr->entityTab[iPos].id, DictFctInfo_UniLabel, (PTR) &uniLabel);  /*  FPL-PMSTA08801-100714   */
                u_strcpy(fctInfoPtr->entityTab[iPos].uniLabel, uniLabel);
            }
        }
        break;

    case FctFuncSecuProfCompo :
    case AllFctList :
        fctInfoPtr->entityNb = DBA_GetDictFctRows();

        if ((fctInfoPtr->entityTab = (VSH_ENTITY_INFO_STP) CALLOC(fctInfoPtr->entityNb, sizeof(VSH_ENTITY_INFO_ST))) == NULL)
        {
            fctInfoPtr->entityNb = 0;
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        /* AllFctList list */
        j = 0;
        for (i=0; i < fctInfoPtr->entityNb; i++)
        {
            fctStp = DBA_GetDictFctStp(i);
            if ((fctStp->entityDictId == 0) &&
                ((fctSelTp != FctFuncSecuProfCompo) ||                      /*  FIH-REF8406-021108  */
#ifdef REF10246     /*  FIH-REF10246-040428 */
                 ((fctStp->dictId != DictFct_StrategyDerivation) &&         /*  FIH-REF8436-030108  */
#endif
                 ((fctStp->dictId != DictFct_EditStrategyObjectives) &&     /*  FIH-REF8406-021108  */
                  (fctStp->dictId != DictFct_EditAllocConstr) &&            /*  FIH-REF8432-021219  */
                  (fctStp->dictId != DictFct_ComputeComplianceChrono) &&    /*  HFI-PMSTA-54127-2024-02-06  */
                  (fctStp->dictId != DictFct_ComputeInstrumentChrono) &&    /*  HFI-PMSTA-54127-2024-02-06  */
				  (fctStp->dictId != DictFct_SelectGridMktSgt))) &&	        /*  PMSTA-20843 - CHU - 150724  */
                (fctStp->parFctDictId < DictFct_LastFromMetadictionary))   /*  FIH-REF7323-020708  Sub child must not be visible   */
                                        /* REF11686 - TEB - 060206 */
            {
                fctInfoPtr->entityTab[j].entityRef = (OBJECT_ENUM)(signed)fctStp->dictId; /* REF7264 - LJE - 020205 */
                fctInfoPtr->entityTab[j].id = fctStp->dictId;
                strcpy(fctInfoPtr->entityTab[j].sqlName, fctStp->procName);	/* ROI - 000413 - REF4497 */
                strcpy(fctInfoPtr->entityTab[j].label, fctStp->label);
                u_strcpy(fctInfoPtr->entityTab[j].uniLabel, fctStp->uniLabel); /* REF9303 - LJE - 030912 */
                j++;
            }
        }

        if (j < i)
        {
            fctInfoPtr->entityNb = j;
            fctInfoPtr->entityTab = (VSH_ENTITY_INFO_STP) REALLOC(fctInfoPtr->entityTab, j*sizeof(VSH_ENTITY_INFO_ST));
        }
        break;

    default :
        ret = RET_GEN_ERR_INVARG;
        MSG_SendMesg(ret, 1,FILEINFO, "DBA_GetDictFctList", "fctSelTp");
    }

    /* Sorting tab by label */
    ret = TLS_Sort((char*) fctInfoPtr->entityTab,
                   fctInfoPtr->entityNb ,
                   sizeof(VSH_ENTITY_INFO_ST),
                   (TLS_CMPFCT *)DBA_CmpEntList, /* REF7264 - LJE - 020205 */
                   NULL,
                   SortRtnTp_None
                  );

    return(ret);
}

/************************************************************************
**  Function             : DBA_ConvUniDataTypeToDataType()
**
**  Description          : Convert an unicode datatype to not unicode datatype.
**
**
**  Arguments            :
**
**
**
**
**  Return               : RET_SUCCEED or error code
**
**  Creation             : PMSTA8525 - DDV - 091030
**  Modif.	             :
**
*************************************************************************/
DATATYPE_ENUM DBA_ConvUniDataTypeToDataType(DATATYPE_ENUM uniDataType)
{
    if (ICU4AAA_SQLServerUTF8 != 0)
    {
        switch (uniDataType)
        {
            case VarInfoType:
                return(UniInfoType);
                break;
            case VarLongnameType:
                return(UniLongnameType);
                break;
            case VarNameType:
                return(UniNameType);
                break;
            case VarNoteType:
                return(UniNoteType);
                break;
            case VarTextType:
                return(UniTextType);
                break;
            case VarString1000Type:
                return(UniString1000Type);
                break;
            case VarString2000Type:
                return(UniString2000Type);
                break;
            case VarString3000Type:
                return(UniString3000Type);
                break;
            case VarString4000Type:
                return(UniString4000Type);
                break;
            case VarString7000Type:
                return(UniString7000Type);
                break;
            case VarString15000Type:
                return(UniString15000Type);
                break;

            default:
                /* Nothing to do */
                break;
        }

        return (uniDataType);
    }

    switch(uniDataType)
    {
    case UniCodeType     :
        return(CodeType);
        break;
    case UniInfoType     :
    case VarInfoType:
        return(InfoType);
        break;
    case UniLongnameType :
    case VarLongnameType:
        return(LongnameType);
        break;
    case UniNameType     :
    case VarNameType:
        return(NameType);
        break;
    case UniNoteType     :
    case VarNoteType:
        return(NoteType);
        break;
    case UniPhoneType    :
        return(PhoneType);
        break;
    case UniSysnameType  :
        return(SysnameType);
        break;
    case UniShortinfoType  :
        return(ShortinfoType);
        break;
    case UniTextType       :
    case VarTextType:
        return(TextType);
        break;
    case UniUrlType        :
        return(UrlType);
        break;
    case UniString1000Type :
    case VarString1000Type:
        return(String1000Type);
        break;
    case UniString2000Type :
    case VarString2000Type:
        return(String2000Type);
        break;
    case UniString3000Type :
    case VarString3000Type:
        return(String3000Type);
        break;
    case UniString4000Type :
    case VarString4000Type:
        return(String4000Type);
        break;
    case UniString7000Type :
    case VarString7000Type:
        return(String7000Type);
        break;
    case UniString15000Type:
    case VarString15000Type:
        return(String15000Type);
        break;

    default :
        /* Nothing to do */
        break;
    }

    return(uniDataType);
}

/************************************************************************
**  Function             : DBA_ConvDataTypeToIsoDataType()
**
**  Description          : Convert an unicode datatype to not unicode datatype.
**
**
**  Arguments            :
**
**
**
**
**  Return               : RET_SUCCEED or error code
**
**  Creation             : PMSTA-34344 - LJE - 201112
**  Modif.	             :
**
*************************************************************************/
DATATYPE_ENUM DBA_ConvDataTypeToIsoDataType(DATATYPE_ENUM uniDataType)
{
    switch (uniDataType)
    {
        case UniCodeType:
            return(CodeType);
            break;
        case UniInfoType:
        case VarInfoType:
            return(InfoType);
            break;
        case UniLongnameType:
        case VarLongnameType:
            return(LongnameType);
            break;
        case UniNameType:
        case VarNameType:
            return(NameType);
            break;
        case UniNoteType:
        case VarNoteType:
            return(NoteType);
            break;
        case UniPhoneType:
            return(PhoneType);
            break;
        case UniSysnameType:
            return(SysnameType);
            break;
        case UniShortinfoType:
            return(ShortinfoType);
            break;
        case UniTextType:
        case VarTextType:
            return(TextType);
            break;
        case UniUrlType:
            return(UrlType);
            break;
        case UniString1000Type:
        case VarString1000Type:
            return(String1000Type);
            break;
        case UniString2000Type:
        case VarString2000Type:
            return(String2000Type);
            break;
        case UniString3000Type:
        case VarString3000Type:
            return(String3000Type);
            break;
        case UniString4000Type:
        case VarString4000Type:
            return(String4000Type);
            break;
        case UniString7000Type:
        case VarString7000Type:
            return(String7000Type);
            break;
        case UniString15000Type:
        case VarString15000Type:
            return(String15000Type);
            break;

        default:
            /* Nothing to do */
            break;
    }

    return(uniDataType);
}

/************************************************************************
**  Function             : DBA_ConvDataTypeToUniDataType()
**
**  Description          : Convert an not unicode datatype to unicode datatype.
**
**
**  Arguments            :
**
**
**
**
**  Return               : RET_SUCCEED or error code
**
**  Creation             : PMSTA8525 - DDV - 091030
**  Modif.	             :
**
*************************************************************************/
EXTERN DATATYPE_ENUM DBA_ConvDataTypeToUniDataType(DATATYPE_ENUM dataType)
{
    switch(dataType)
    {
    case CodeType     :
        return(UniCodeType);
        break;
    case InfoType     :
        return(UniInfoType);
        break;
    case LongnameType :
        return(UniLongnameType);
        break;
    case NameType     :
        return(UniNameType);
        break;
    case NoteType     :
        return(UniNoteType);
        break;
    case PhoneType    :
        return(UniPhoneType);
        break;
    case SysnameType  :
        return(UniSysnameType);
        break;
    case ShortinfoType  :
        return(UniShortinfoType);
        break;
    case TextType       :
        return(UniTextType);
        break;
    case UrlType        :
        return(UniUrlType);
        break;
    case String1000Type :
        return(UniString1000Type);
        break;
    case String2000Type :
        return(UniString2000Type);
        break;
    case String3000Type :
        return(UniString3000Type);
        break;
    case String4000Type :
        return(UniString4000Type);
        break;
    case String7000Type :
        return(UniString7000Type);
        break;
    case String15000Type:
		return(UniString15000Type);
		break;

	default:
		/* Nothing to do */
		break;
	}
	return(dataType);
}

/************************************************************************
**  Function             : DBA_GetMDMaxLen()
**
**  Description          : Return the max length of the attribute according that is
**                         defined in MD field max_db_length.
**						   The synonyms are treated.
**
**  Arguments            :
**
**  Return               :
**
**  Creation             : PMSTA-34373 - LJE - 190222
**  Modif.	             :
**
*************************************************************************/
unsigned int DBA_GetMDMaxLen(DBA_DYNFLD_STP record, FIELD_IDX_T fldIdx)
{
    DBA_DYNST_ENUM dynStEnum   = GET_DYNSTENUM(record);
    DATATYPE_ENUM  fldDataType = GET_FLD_TYPE_MD(dynStEnum, fldIdx);
    unsigned int   maxLen      = GET_FLD_MD_MAXCHARLEN(dynStEnum, fldIdx);

    if (fldDataType == CodeType)
    {
        if ((dynStEnum == A_Synon && fldIdx == A_Synon_Cd) ||
            (dynStEnum == S_Synon && fldIdx == S_Synon_Cd))
        {
            OBJECT_ENUM synObject;
            if (DBA_GetObjectEnum(GET_DICT(record, A_Synon_EntityDictId), &synObject) && synObject != NullEntity)
            {
                DICT_ATTRIB_STP codeAttribStp = DBA_GetAttributeBySqlName(synObject, "code");

                if (codeAttribStp != NULL)
                {
                    maxLen = codeAttribStp->maxDbLenN;
                }
            }
        }
    }
    return maxLen;
}

/************************************************************************
**  Function             : DBA_IsScriptDefinitionField()
**
**  Description          : Return true if field may contain a full script definition.
**                         In this case it will not be truncate.
**
**  Arguments            : dynst enum, field index
**
**  Return               : true, if attribute has been modified, else false
**
**  Creation             : PMSTA-35850 - DDV - 190513
**  Modif.	             :
**
*************************************************************************/
STATIC bool DBA_IsScriptDefinitionField(DBA_DYNST_ENUM dynStEnum, FIELD_IDX_T fldIdx)
{

    if ((dynStEnum == A_ScriptDef               && fldIdx == A_ScriptDef_Def) ||
        (dynStEnum == A_TradingConstraintScript && fldIdx == A_TradingConstraintScript_Definition) ||
        (dynStEnum == A_HoldingConstraintScript && fldIdx == A_HoldingConstraintScript_Definition)
       )
    {
        return(true);
    }

    return(false);
}

/************************************************************************
**  Function             : DBA_TruncateCodeNameToMDLength()
**
**  Description          : Truncate one fields to the length
**                         defined in MD field max_db_length.
**						   The synonyms are treated.
**
**  Arguments            : record, field index
**
**  Return               : true, if attribute has been modified, else false
**
**  Creation             : PMSTA-34373 - LJE - 190222
**  Modif.	             :
**
*************************************************************************/
bool DBA_TruncateStringToMDLength(DBA_DYNFLD_STP record, FIELD_IDX_T fldIdx)
{
    if (record == nullptr || _IS_NULLFLD(record, fldIdx) == TRUE)
    {
        return false;
    }

    DATATYPE_ENUM dataType = GET_FLD_TYPE_MD(GET_DYNSTENUM(record), fldIdx);

    /* PMSTA-34373 - LJE - 190314 - Exception for Script Definition... */
    if ((IS_STRING_TYPE(dataType) || IS_USTRING_TYPE(dataType)) &&
        DBA_IsScriptDefinitionField(GET_DYNSTENUM(record), fldIdx) == false)
    {
        return STRING_Truncate(GET_STRING(record, fldIdx), DBA_GetMDMaxLen(record, fldIdx), dataType);
    }

    return false;
}

/************************************************************************
**  Function             : DBA_TruncateCodeNameToMDLength()
**
**  Description          : Truncate all code and name datatype fields to the length
**                         defined in MD field max_db_length.
**						   The synonyms are treated.
**
**  Arguments            : record
**
**  Return               : true, if attribute has been modified, else false
**
**  Creation             : PMSTA-34373 - LJE - 190222
**  Modif.	             :
**
*************************************************************************/
bool DBA_TruncateDynStStringToMDLength(DBA_DYNFLD_STP record)
{
    if (SYS_IsSqlMode() || record == nullptr)
    {
        return false;
    }

    DBA_DYNST_ENUM dynStEnum  = GET_DYNSTENUM(record);
    OBJECT_ENUM    objectEn   = GET_OBJ_DYNST(dynStEnum);
    bool      bStringUpdated  = false;

    if (objectEn != NullEntity)
    {
        for (int i = 0; i < GET_FLD_NBR(dynStEnum); i++)
        {
            if (DBA_TruncateStringToMDLength(record, i) == true)
            {
                bStringUpdated = true;
            }
        }
    }
    return bStringUpdated;
}

/************************************************************************
**  Function             : DBA_CheckSynonymCode()
**
**  Description          : Check synonym's code and manage exception for this field
**
**  Arguments            : code         string to check
**                         codifId      codification of the synonym (actually not implemented)
**
**  Return               : 0 if all characters are allow
**                        -1 if forbidden char is found
**
**  Creation             : PMSTA-44466 - DDV - 210324 - Allow # only in synonym's code
**  Modif.	             :
**
*************************************************************************/
int DBA_CheckSynonymCode(char *code, ID_T codifId)
{
    static CODE_T synonymCodeForbbiden = "";

    if (synonymCodeForbbiden[0] == END_OF_STRING)
    {
        int pos=0, idx=0;

        while (DBA_FORBIDEN_CODE[pos] != END_OF_STRING)
        {
            if (strchr(DBA_SYNONYM_CODE_ALLOW, DBA_FORBIDEN_CODE[pos]) == nullptr)
            {
                synonymCodeForbbiden[idx++] = DBA_FORBIDEN_CODE[pos];
            }
            pos++;
        }
    }

    size_t length = SYS_StrLen(code);
    if (strcspn(code, synonymCodeForbbiden) != length)
    {
        return -1;
    }

    return 0;
}

/************************************************************************
**
**  Function             : DBA_GetNatureForSelectAll
**
**  Description          : Get the nature used for select All
**
**  Arguments            : OBJECT_ENUM  enEntityRef : the given entity 
**
**  Return               : ENUM_T      enSlelectAll : the nature used for select all
**
**  Creation             : HFI-PMSTA-55081-2023-11-24
**
*************************************************************************/
ENUM_T  DBA_GetNatureForSelectAll (OBJECT_ENUM enEntityRef)
{
    ENUM_T      enSlelectAll = 0;    

    DICT_ENTITY_STP pdictent = DBA_GetEntityBySqlName(DBA_GetDictEntitySqlName(enEntityRef));
    if (pdictent != nullptr)
    {
        DICT_ATTRIB_STP pdictattr = DBA_GetDictAttribSt(enEntityRef, pdictent->natIndex);
        if ((pdictattr != nullptr) &&
            (pdictattr->permValMap.empty() == false))
        {
            bool    bFind = false;
            for (auto it = pdictattr->permValMap.begin(); it != pdictattr->permValMap.end() && bFind == false; ++it)
            {
                if (it->second.permValRuleEn == PermValRule_All)
                {
                    enSlelectAll = it->second.permVal;
                    bFind = true;
                }
            }
        }
    }
    return enSlelectAll;
}


/************************************************************************
**      END          dbadict.c
*************************************************************************/


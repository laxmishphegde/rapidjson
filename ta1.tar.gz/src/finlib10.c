/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define FINLIB10_C

#define STDIO_H
#define STRING_H
#define STDLIB_H

/************************************************************************
**      Includes
*************************************************************************/
#include "unidef.h"        /* Mandatory */
#include "fin.h"

/************************************************************************
**
**      Functions Description
**      FIN_FieldStratUpdRecAndParent   Update Parent ESE values (weight/contribution ...)
**                                      according to modified fields.
**		FIN_StratChildrenTot			Compute total (and contrib total if obj_weight).
**		FIN_StratGetParESEPtr			Get extended strategy element parent.
**		FIN_StratCmpESLLevel			Extended strategy link table is sort by level
**		FIN_StratCmpEltNat				Strategy element table is sort with model total line at the begin.
**      FIN_StratFilterListCompo        Filter the A_ListCompo records related to
**                                      the grid list id criteria.
**      FIN_StratFilterSMS              Filter the S_MktSegt records related to
**                                      the grid id criteria.
**      FIN_StratCmpListCompo           Sort A_ListCompo record by grid hierarchy
**                                      (parent grid to child grid).
**      FIN_StratCmpStrat               Sort A_Strat record by hierarchy (parent to child).
**		FIN_StratFilterChildrenESE	    Filter all children of parent ESE argument
**		FIN_StratFilterOrdChildrenESE	Filter all ordinate children of parent ESE argument
*************************************************************************/

/************************************************************************
**      Constants
*************************************************************************/

/************************************************************************
**      Macro Definitions
*************************************************************************/

/************************************************************************
**      Type  Definitions
*************************************************************************/

/************************************************************************
**      Global Functions
**
*************************************************************************/

/************************************************************************
**      Static Functions
**
*************************************************************************/

STATIC RET_CODE FIN_StratChildrenTot(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP*, int, int, NUMBER_T*, NUMBER_T*);
STATIC int FIN_StratFilterOrdChildrenESE(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);

/************************************************************************
**
**  Function    :   FIN_FieldStratUpdRecAndParent()
**
**  Description :   Update Parent ESE values (weight/contribution ...)
**                  according to modified fields.
**
**
**
**  Arguments   :
**
**
**
**  Return      :   TRUE or FALSE
**
**  Creation Date :
**
*************************************************************************/
RET_CODE FIN_FieldStratUpdRecAndParent(DBA_HIER_HEAD_STP     stratHierPtr,
                                      DBA_DYNFLD_STP        ESEPtr,
                                      DBA_DYNFLD_STP        deletedESEPtr,
                                      DBA_ACTION_ENUM       action,
                                      int                   field,
                                      int                   selOptions,
                                      int*                  connectNo,
                                      int                   (*fct)(PTR , DBA_DYNFLD_STP, FLAG_T*),
                                      PTR                   context,
                                      FLAG_T               *dfltValTab,
                                      FLAG_T                keepAllStratEltFlg) /* PMSTA-27076 - CHU - 170626 */
{
    RET_CODE	    ret                 = RET_SUCCEED;
    int		        ESENbr              = 0;
    NUMBER_T	    tot                 = 0.0;
    NUMBER_T        totContrib          = 0.0;
    NUMBER_T        contrib             = 0.0;
    NUMBER_T        objWeight           = 0.0;
    DBA_DYNFLD_STP *ESETab              = NULLDYNSTPTR;
    DBA_DYNFLD_STP  parESEPtr           = NULLDYNST;
    DBA_DYNFLD_STP  contribParESEPtr    = NULLDYNST;


   /* Compute new sum of children value */
   if ( field == ExtStratElt_ObjWeight          ||
        /* REF4047 - 991224 - SKE */
        field == ExtStratElt_ObjWeightContrib   ||
        field == ExtStratElt_ObjDuraContrib     ||
        field == ExtStratElt_ObjBetaContrib     ||
        field == ExtStratElt_ObjCrtYieldContrib ||
        field == ExtStratElt_ActualWeight       ||  /* SKE 000913 REF5192 */
        field == ExtStratElt_ActualWeightContrib)   /* SKE 000913 REF5192 */
    {
	    if (GET_EXTENSION_PTR(ESEPtr, ExtStratElt_LnkPar_ExtStratElt_Ext) != NULL                       &&
	        (parESEPtr = *(GET_EXTENSION_PTR(ESEPtr, ExtStratElt_LnkPar_ExtStratElt_Ext))) != NULLDYNST &&
	        GET_TINYINT(parESEPtr, ExtStratElt_Level) != 0                                              &&
            /* REF4047 - 991207 - SKE : Keep the update inside the same strategy */
            CMP_DYNFLD(ESEPtr, parESEPtr, ExtStratElt_StratId, ExtStratElt_StratId, GET_FLD_TYPE(ExtStratElt, ExtStratElt_StratId)) == 0)
	    {
	        SET_NUMBER(parESEPtr, field, 0.0);
	        if (field == ExtStratElt_ObjWeight)
	        {
                SET_NUMBER(parESEPtr, ExtStratElt_ObjWeightContrib, 0.0);
	        }
            /* REF4047 - 991224 - SKE */
            else if (field == ExtStratElt_ObjWeightContrib)
            {
                SET_NUMBER(parESEPtr, ExtStratElt_ObjWeight, 0.0);
            }
            /* <SKE 000913 REF5192 */
            else if (field == ExtStratElt_ActualWeight)
            {
                /* Compute obj weight */
                SET_NUMBER(parESEPtr, ExtStratElt_ActualWeightContrib, 0.0);
                objWeight = GET_NUMBER(ESEPtr, ExtStratElt_ActualWeight) + GET_NUMBER(ESEPtr, ExtStratElt_ObjConstrVal);
                SET_NUMBER(ESEPtr, ExtStratElt_ObjWeight, CAST_NUMBER(objWeight));
            }
            else if (field == ExtStratElt_ActualWeightContrib)
            {
                /* Compute obj weight */
                SET_NUMBER(parESEPtr, ExtStratElt_ActualWeight, 0.0);
                objWeight = GET_NUMBER(ESEPtr, ExtStratElt_ObjConstrVal) * (1.0 + (GET_NUMBER(ESEPtr, ExtStratElt_ActualWeightContrib)/100.0));
                SET_NUMBER(ESEPtr, ExtStratElt_ObjWeight, CAST_NUMBER(objWeight));
            }
            /* SKE 000913 REF5192> */

	        ret = DBA_ExtractHierEltRecWithFilterSt(stratHierPtr,
			                                        ExtStratElt,
			                                        FALSE,
			                                        (HIER_FLTFCT *)FIN_StratFilterChildrenESE,
                                                    parESEPtr,
			                                        NULLFCT,
			                                        &ESENbr,
                                                    &ESETab);

            if (ret != RET_SUCCEED)
            {
                return(ret);
            }

	        if (ESENbr > 0)
	        {
                /* And update ESEPtr contrib value (if field is obj_weight, min_weight, max_weight) */
                if ((ret = FIN_StratChildrenTot(ESEPtr,
                                                deletedESEPtr,
                                                ESETab,
                                                ESENbr,
                                                field,
                                                &tot,
                                                &totContrib)) != RET_SUCCEED)
                {
	                FREE(ESETab);
	                return(ret);
                }

                /* Update parent */
                if (field == ExtStratElt_ObjWeight ||
                    field == ExtStratElt_ObjWeightContrib ||
                    field == ExtStratElt_ActualWeight ||        /* SKE 000913 REF5192 */
                    field == ExtStratElt_ActualWeightContrib)   /* SKE 000913 REF5192 */
                {
                    NUMBER_T absRatio = (NUMBER_T)0;
                    NUMBER_T relRatio = (NUMBER_T)0;

                    SET_NUMBER(parESEPtr, ExtStratElt_ObjWeight, tot);
	                SET_NUMBER(parESEPtr, ExtStratElt_ObjWeightContrib, totContrib);
                    /* <SKE 000913 REF5192 */
                    /* Update absolute ratio */
                    if (GET_ENUM(parESEPtr, ExtStratElt_StratNatEn) == (ENUM_T) StratNat_Alloc)
                    {
                        absRatio = GET_NUMBER(parESEPtr, ExtStratElt_ObjWeight) - GET_NUMBER(parESEPtr, ExtStratElt_ObjConstrVal);
                        SET_NUMBER(parESEPtr, ExtStratElt_ActualWeight, CAST_NUMBER(absRatio));
                        /* Update relative ratio */
                        if (IS_NULLFLD(parESEPtr, ExtStratElt_ObjConstrVal) == FALSE &&
                            GET_NUMBER(parESEPtr, ExtStratElt_ObjConstrVal) != (NUMBER_T)0)
                        {
                            relRatio = 100.0 * absRatio / GET_NUMBER(parESEPtr, ExtStratElt_ObjConstrVal);
                            SET_NUMBER(parESEPtr, ExtStratElt_ActualWeightContrib, CAST_NUMBER(relRatio));
                        }
                    }
                    /* SKE 000913 REF5192> */
                }
                else
                {
                    SET_NUMBER(parESEPtr, field, tot);
                }

		        FREE(ESETab);

                /* REF4047 - 000107 - SKE :  Update A_StratElt linked to parESEPtr */
                ret = FIN_StratUpdHierAndValue(stratHierPtr,
                                               parESEPtr,
                                               Update,
                                               field,
                                               selOptions,
                                               connectNo,
                                               keepAllStratEltFlg); /* PMSTA-27076 - CHU - 170626 */

                if (ret != RET_SUCCEED)
                {
                    return(ret);
                }
	        }

	        /* Do same thing with parent */
		    ret = FIN_StratUpdRecAndParent(stratHierPtr,
                                           parESEPtr,
                                           action,
                                           field,
                                           selOptions,
                                           connectNo,
                                           fct,
                                           context,
                                           dfltValTab,
                                           keepAllStratEltFlg); /* PMSTA-27076 - CHU - 170626 */

		    if (ret != RET_SUCCEED)
            {
                return(ret);
            }
	    }

	    /* Ordinate parent */
	    if (GET_EXTENSION_PTR(ESEPtr, ExtStratElt_OrdPar_ExtStratElt_Ext) != NULL                       &&
	        (parESEPtr = *(GET_EXTENSION_PTR(ESEPtr, ExtStratElt_OrdPar_ExtStratElt_Ext))) != NULLDYNST &&
	        GET_TINYINT(parESEPtr, ExtStratElt_Level) != 0                                              &&
            /* REF4047 - 991207 - SKE : Keep the update inside the same strategy */
            CMP_DYNFLD(ESEPtr, parESEPtr, ExtStratElt_StratId, ExtStratElt_StratId, GET_FLD_TYPE(ExtStratElt, ExtStratElt_StratId)) == 0)
	    {
            tot = 0.0;
            totContrib = 0.0;
	        SET_NUMBER(parESEPtr, field, 0.0);
	        if (field == ExtStratElt_ObjWeight)
	        {
                SET_NUMBER(parESEPtr, ExtStratElt_ObjWeightContrib, 0.0);
	        }
            /* REF4047 - 991224 - SKE */
            else if (field == ExtStratElt_ObjWeightContrib)
            {
                SET_NUMBER(parESEPtr, ExtStratElt_ObjWeight, 0.0);
            }

	        ret = DBA_ExtractHierEltRecWithFilterSt(stratHierPtr,
			                                        ExtStratElt,
			                                        FALSE,
			                                        (HIER_FLTFCT *)FIN_StratFilterOrdChildrenESE,
					                                parESEPtr,
			                                        NULLFCT,
			                                        &ESENbr,
                                                    &ESETab);

            if (ret != RET_SUCCEED)
            {
                return(ret);
            }

	        if (ESENbr > 0)
	        {
		        /* It's not necessary to update current record value (already done) */
		        if ((ret = FIN_StratChildrenTot(NULLDYNST,
                                                deletedESEPtr,
                                                ESETab,
                                                ESENbr,
                                                field,
                                                &tot,
                                                &totContrib)) != RET_SUCCEED)
		        {
		            FREE(ESETab);
		            return(ret);
		        }

		        /* Update parent */
		        if (field == ExtStratElt_ObjWeight)
		        {
                    SET_NUMBER(parESEPtr, field, tot);
		            SET_NUMBER(parESEPtr, ExtStratElt_ObjWeightContrib, totContrib);
		        }
                /* REF4047 - 991224 - SKE */
                else if (field == ExtStratElt_ObjWeightContrib)
                {
                    SET_NUMBER(parESEPtr, field, totContrib);
                    SET_NUMBER(parESEPtr, ExtStratElt_ObjWeight, tot);
                }
                else
                {
                    SET_NUMBER(parESEPtr, field, tot);
                }

		        FREE(ESETab);
                /* REF4047 - 000107 - SKE :  Update A_StratElt linked to parESEPtr */
                ret = FIN_StratUpdHierAndValue(stratHierPtr,
                                               parESEPtr,
                                               Update,
                                               field,
                                               selOptions,
                                               connectNo,
                                               keepAllStratEltFlg); /* PMSTA-27076 - CHU - 170626 */

                if (ret != RET_SUCCEED)
                {
                    return(ret);
                }
	        }
	    }
    }
    /* In case of obj_weight_margin is modified, recompute ob_weight_margin_contrib */
    else if (field == ExtStratElt_ObjWeightMarg)
    {
	    /* Update weight contrib using parent information ... */
	    if (IS_NULLFLD(ESEPtr, ExtStratElt_ObjWeightMarg) == FALSE)
        {
	        if (IS_NULLFLD(ESEPtr, ExtStratElt_ParMktSegtId) == TRUE)
	        {
	            SET_NUMBER(ESEPtr, ExtStratElt_ObjWeightContribMarg, GET_NUMBER(ESEPtr, ExtStratElt_ObjWeightMarg));
	        }
	        else
	        {
	            if ((contribParESEPtr = FIN_StratGetParESEPtr(ESEPtr)) != NULLDYNST)
	            {
		            if (IS_NULLFLD(contribParESEPtr, ExtStratElt_ObjWeightContrib) == FALSE)
		            {

							switch(GET_ENUM(ESEPtr, ExtStratElt_ForecastFlg))/* <SKE - 010208 - REF5599 */
							{
								case ExtStratEltForecast_Absolute:
	 			                     contrib = GET_NUMBER(ESEPtr, ExtStratElt_ObjWeightMarg) *
                                      GET_NUMBER(contribParESEPtr, ExtStratElt_ObjWeightContrib) / 100.0;
									 SET_NUMBER(ESEPtr, ExtStratElt_ObjWeightContribMarg, CAST_NUMBER(contrib));
								     break;
								case ExtStratEltForecast_Relative:
 	                                 SET_NUMBER(ESEPtr, ExtStratElt_ObjWeightContribMarg, GET_NUMBER(ESEPtr, ExtStratElt_ObjWeightMarg));
            					     break;
	 			            	case ExtStratEltForecast_AbsoluteContrib: /* REF7319 - 020308 - MCA */
									 SET_NUMBER(ESEPtr, ExtStratElt_ObjWeightContribMarg,
                                     GET_NUMBER(ESEPtr, ExtStratElt_ObjWeightMarg));
 	 			            		 break;
							}
		            }
	            }
	        }
        }
        else
        {
            SET_NULL_NUMBER(ESEPtr, ExtStratElt_ObjWeightContribMarg);
        }
    }
    /*  REF4047 - 991207 - SKE : In case of obj_weight_cont_margin is modified,
        recompute obj_weight_margin                                              */
    else if (field == ExtStratElt_ObjWeightContribMarg)
    {
	    if (IS_NULLFLD(ESEPtr, ExtStratElt_ObjWeightContribMarg) == FALSE)
        {
	        if (IS_NULLFLD(ESEPtr, ExtStratElt_ParMktSegtId) == TRUE)
	        {
	            SET_NUMBER(ESEPtr, ExtStratElt_ObjWeightMarg, GET_NUMBER(ESEPtr, ExtStratElt_ObjWeightContribMarg));
	        }
	        else
	        {
	            if ((contribParESEPtr = FIN_StratGetParESEPtr(ESEPtr)) != NULLDYNST)
	            {
		            if (IS_NULLFLD(contribParESEPtr, ExtStratElt_ObjWeightContrib) == FALSE &&
                        GET_NUMBER(contribParESEPtr, ExtStratElt_ObjWeightContrib) != 0.0)
		            {

					switch(GET_ENUM(ESEPtr, ExtStratElt_ForecastFlg))/* <SKE - 010208 - REF5599 */
					{
						case ExtStratEltForecast_Absolute:
							 tot = 100.0 * GET_NUMBER(ESEPtr, ExtStratElt_ObjWeightContribMarg) /
										   GET_NUMBER(contribParESEPtr, ExtStratElt_ObjWeightContrib);
							 SET_NUMBER(ESEPtr, ExtStratElt_ObjWeightMarg, CAST_NUMBER(tot));
				     		 break;
						case ExtStratEltForecast_Relative:
							 SET_NUMBER(ESEPtr, ExtStratElt_ObjWeightMarg, GET_NUMBER(ESEPtr, ExtStratElt_ObjWeightContribMarg));
            				 break;
	 					case ExtStratEltForecast_AbsoluteContrib: /* REF7319 - 020308 - MCA */
							 SET_NUMBER(ESEPtr, ExtStratElt_ObjWeightMarg,
                             GET_NUMBER(ESEPtr, ExtStratElt_ObjWeightContribMarg));
	 						 break;
					}

		            }
                }
            }
        }
        else
        {
            SET_NULL_NUMBER(ESEPtr, ExtStratElt_ObjWeightMarg);
        }
    }
    else if (field == ExtStratElt_MaxWeightContrib)
    {
		if (IS_NULLFLD(ESEPtr, ExtStratElt_ParMktSegtId) == TRUE)
	    {
            COPY_DYNFLD(ESEPtr, ExtStratElt, ExtStratElt_MaxWeight,
                        ESEPtr, ExtStratElt, ExtStratElt_MaxWeightContrib);
	    }
	    else
	    {
            if (IS_NULLFLD(ESEPtr, ExtStratElt_MaxWeightContrib) == FALSE)
            {
		        if ((contribParESEPtr = FIN_StratGetParESEPtr(ESEPtr)) != NULLDYNST)
		        {
		            if (IS_NULLFLD(contribParESEPtr, ExtStratElt_ObjWeightContrib) == FALSE &&
                        GET_NUMBER(contribParESEPtr, ExtStratElt_ObjWeightContrib) != 0.0)
		            {
			            tot = 100.0 * GET_NUMBER(ESEPtr, ExtStratElt_MaxWeightContrib) /
                              GET_NUMBER(contribParESEPtr, ExtStratElt_ObjWeightContrib);
                        SET_NUMBER(ESEPtr, ExtStratElt_MaxWeight, CAST_NUMBER(tot));
		            }
		        }
            }
            else
            {
                SET_NULL_NUMBER(ESEPtr, ExtStratElt_MaxWeight);
            }
        }
    }
    else if (field == ExtStratElt_MinWeightContrib)
    {
		if (IS_NULLFLD(ESEPtr, ExtStratElt_ParMktSegtId) == TRUE)
	    {
            COPY_DYNFLD(ESEPtr, ExtStratElt, ExtStratElt_MinWeight,
                        ESEPtr, ExtStratElt, ExtStratElt_MinWeightContrib);
	    }
	    else
	    {
            if (IS_NULLFLD(ESEPtr, ExtStratElt_MinWeightContrib) == FALSE)
            {
		        if ((contribParESEPtr = FIN_StratGetParESEPtr(ESEPtr)) != NULLDYNST)
		        {
		            if (IS_NULLFLD(contribParESEPtr, ExtStratElt_ObjWeightContrib) == FALSE &&
                        GET_NUMBER(contribParESEPtr, ExtStratElt_ObjWeightContrib) != 0.0)
		            {
			            tot = 100.0 * GET_NUMBER(ESEPtr, ExtStratElt_MinWeightContrib) /
                              GET_NUMBER(contribParESEPtr, ExtStratElt_ObjWeightContrib);
                        SET_NUMBER(ESEPtr, ExtStratElt_MinWeight, CAST_NUMBER(tot));
		            }
		        }
            }
            else
            {
                SET_NULL_NUMBER(ESEPtr, ExtStratElt_MinWeight);
            }
        }
    }
    else if (field == ExtStratElt_MaxWeight)
    {
		if (IS_NULLFLD(ESEPtr, ExtStratElt_ParMktSegtId) == TRUE)
	    {
            COPY_DYNFLD(ESEPtr, ExtStratElt, ExtStratElt_MaxWeightContrib,
                        ESEPtr, ExtStratElt, ExtStratElt_MaxWeight);
	    }
	    else
	    {
            if (IS_NULLFLD(ESEPtr, ExtStratElt_MaxWeight) == FALSE)
            {
		        if ((contribParESEPtr = FIN_StratGetParESEPtr(ESEPtr)) != NULLDYNST)
		        {
		            if (IS_NULLFLD(contribParESEPtr, ExtStratElt_ObjWeightContrib) == FALSE)
		            {
			            contrib = GET_NUMBER(ESEPtr, ExtStratElt_MaxWeight) *
                                  GET_NUMBER(contribParESEPtr, ExtStratElt_ObjWeightContrib) / 100.0;
                        SET_NUMBER(ESEPtr, ExtStratElt_MaxWeightContrib, CAST_NUMBER(contrib));
		            }
		        }
            }
            else
            {
                SET_NULL_NUMBER(ESEPtr, ExtStratElt_MaxWeightContrib);
            }
        }
    }
    else if (field == ExtStratElt_MinWeight)
    {
		if (IS_NULLFLD(ESEPtr, ExtStratElt_ParMktSegtId) == TRUE)
	    {
            COPY_DYNFLD(ESEPtr, ExtStratElt, ExtStratElt_MinWeightContrib,
                        ESEPtr, ExtStratElt, ExtStratElt_MinWeight);
	    }
	    else
	    {
            if (IS_NULLFLD(ESEPtr, ExtStratElt_MinWeight) == FALSE)
            {
		        if ((contribParESEPtr = FIN_StratGetParESEPtr(ESEPtr)) != NULLDYNST)
		        {
		            if (IS_NULLFLD(contribParESEPtr, ExtStratElt_ObjWeightContrib) == FALSE)
		            {
			            contrib = GET_NUMBER(ESEPtr, ExtStratElt_MinWeight) *
                                  GET_NUMBER(contribParESEPtr, ExtStratElt_ObjWeightContrib) / 100.0;
                        SET_NUMBER(ESEPtr, ExtStratElt_MinWeightContrib, CAST_NUMBER(contrib));
		            }
		        }
            }
            else
            {
                SET_NULL_NUMBER(ESEPtr, ExtStratElt_MinWeightContrib);
            }
        }
    }

    /* Call default value function and format element update function */
    if (action != Delete && fct != NULL) /* REF7264 - LJE - 020131 */
    {
	    fct(context, ESEPtr, NULL); /* REF7264 - LJE - 020131 */
    }

    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_StratChildrenTot()
**
**  Description :   Compute total (and contrib total if obj_weight).
**
**  Arguments   :   ESEPtr	extended strategy element to update
**		    ESETab	all children table
**		    ESENbr	children number
**                  field	modified field
**		    tot		pointer on total to compute
**		    totContrib	pointer on contrib total to compute
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation Date : 20.07.99 - REF3729
**
*************************************************************************/
STATIC RET_CODE FIN_StratChildrenTot(DBA_DYNFLD_STP     ESEPtr,
                                     DBA_DYNFLD_STP     deletedESEPtr,
                                     DBA_DYNFLD_STP    *ESETab,
                                     int                ESENbr,
                                     int                field,
                                     NUMBER_T          *tot,
                                     NUMBER_T          *totContrib)
{
    int             i;
    NUMBER_T	    contrib             = (NUMBER_T)0.0;
    NUMBER_T	    weight              = (NUMBER_T)0.0;
    NUMBER_T        absRatio            = (NUMBER_T)0;
    NUMBER_T        relRatio            = (NUMBER_T)0;
    DBA_DYNFLD_STP  contribParESEPtr    = NULLDYNST;


    (*tot)          = 0;
    (*totContrib)   = 0;

	if (field == ExtStratElt_ObjWeightContrib)
    {
        for (i=0; i<ESENbr; i++)
        {
            weight = 0.0;
            contrib = 0.0;

            if (IS_NULLFLD(ESETab[i], ExtStratElt_ObjWeightContrib) == FALSE)
            {
                (*totContrib) += GET_NUMBER(ESETab[i], ExtStratElt_ObjWeightContrib);
	            /* Update weight contrib using parent information ... */
	            if (IS_NULLFLD(ESETab[i], ExtStratElt_ObjWeightContrib) == FALSE &&
		            IS_NULLFLD(ESETab[i], ExtStratElt_ParMktSegtId) == TRUE)
                {
                    weight = GET_NUMBER(ESETab[i], ExtStratElt_ObjWeightContrib);
                }
                else
                {
		            if ((contribParESEPtr = FIN_StratGetParESEPtr(ESETab[i])) != NULLDYNST)
		            {
                        if (IS_NULLFLD(contribParESEPtr, ExtStratElt_ObjWeightContrib) == FALSE &&
                            GET_NUMBER(contribParESEPtr, ExtStratElt_ObjWeightContrib) != 0.0 )
                        {
			                weight = 100.0 * GET_NUMBER(ESETab[i], ExtStratElt_ObjWeightContrib)
                                   / GET_NUMBER(contribParESEPtr, ExtStratElt_ObjWeightContrib);
                        }
                    }
                }
                (*tot) += weight;
                if (ESETab[i] == ESEPtr) /* Update only modified record */
                {
			        SET_NUMBER(ESEPtr, ExtStratElt_ObjWeight, CAST_NUMBER(weight));

                    /* <SKE 000913 REF5192 */
                    if (GET_ENUM(ESEPtr, ExtStratElt_StratNatEn) == (ENUM_T) StratNat_Alloc)
                    {
                        /* Update absolute ratio */
                        absRatio = GET_NUMBER(ESEPtr, ExtStratElt_ObjWeight) - GET_NUMBER(ESEPtr, ExtStratElt_ObjConstrVal);
                        SET_NUMBER(ESEPtr, ExtStratElt_ActualWeight, CAST_NUMBER(absRatio));
                        /* Update relative ratio */
                        if (IS_NULLFLD(ESEPtr, ExtStratElt_ObjConstrVal) == FALSE    &&
                            GET_NUMBER(ESEPtr, ExtStratElt_ObjConstrVal) != (NUMBER_T)0)
                        {
                            relRatio = 100.0 * absRatio / GET_NUMBER(ESEPtr, ExtStratElt_ObjConstrVal);
                            SET_NUMBER(ESEPtr, ExtStratElt_ActualWeightContrib, CAST_NUMBER(relRatio));
                        }
                    }
                    /* SKE 000913 REF5192> */
                }
            }
            else
            {
                if (ESETab[i] == ESEPtr) /* Update only modified record */
                {
                    SET_NULL_NUMBER(ESETab[i], ExtStratElt_ObjWeight);
                }
            }
        }
    }
    else if (field == ExtStratElt_ObjWeight     ||
             field == ExtStratElt_ActualWeight  ||      /* SKE 000913 REF5192 */
             field == ExtStratElt_ActualWeightContrib)  /* SKE 000913 REF5192 */
    {
        for (i=0; i<ESENbr; i++)
        {
            /* REF4047 - 000120 - SKE : exclude deleted instrument */
            if (deletedESEPtr != NULLDYNST)
            {
                if (deletedESEPtr == ESETab[i]) continue;
            }
            contrib = 0.0;
            if (IS_NULLFLD(ESETab[i], ExtStratElt_ObjWeight) == FALSE)
            {
	            (*tot) += GET_NUMBER(ESETab[i], ExtStratElt_ObjWeight);
		        if (IS_NULLFLD(ESETab[i], ExtStratElt_ParMktSegtId) == TRUE)
	            {
                    contrib = GET_NUMBER(ESETab[i], ExtStratElt_ObjWeight);
	            }
	            else
	            {
		            if ((contribParESEPtr = FIN_StratGetParESEPtr(ESETab[i])) != NULLDYNST)
		            {
		                if (IS_NULLFLD(contribParESEPtr, ExtStratElt_ObjWeightContrib) == FALSE)
		                {
			                contrib = GET_NUMBER(ESETab[i], ExtStratElt_ObjWeight) *
                                      GET_NUMBER(contribParESEPtr, ExtStratElt_ObjWeightContrib)
                                      / 100.0;
		                }
		            }
                }
                (*totContrib) += contrib;
                if (ESETab[i] == ESEPtr) /* Update only modified record */
                {
                    SET_NUMBER(ESEPtr, ExtStratElt_ObjWeightContrib, CAST_NUMBER(contrib));
                    /* <SKE 000913 REF5192 */
                    if (GET_ENUM(ESEPtr, ExtStratElt_StratNatEn) == (ENUM_T) StratNat_Alloc)
                    {
                        /* Update absolute ratio */
                        absRatio = GET_NUMBER(ESEPtr, ExtStratElt_ObjWeight) - GET_NUMBER(ESEPtr, ExtStratElt_ObjConstrVal);
                        if (field != ExtStratElt_ActualWeight)
                        {
                            SET_NUMBER(ESEPtr, ExtStratElt_ActualWeight, CAST_NUMBER(absRatio));
                        }
                        /* Update relative ratio */
                        if (field != ExtStratElt_ActualWeightContrib                    &&
                            IS_NULLFLD(ESEPtr, ExtStratElt_ObjConstrVal) == FALSE    &&
                            GET_NUMBER(ESEPtr, ExtStratElt_ObjConstrVal) != (NUMBER_T)0)
                        {
                            relRatio = 100.0 * absRatio / GET_NUMBER(ESEPtr, ExtStratElt_ObjConstrVal);
                            SET_NUMBER(ESEPtr, ExtStratElt_ActualWeightContrib, CAST_NUMBER(relRatio));
                        }
                    }
                    /* SKE 000913 REF5192> */
                }
            }
            else
            {
                if (ESETab[i] == ESEPtr) /* Update only modified record */
                {
                    SET_NULL_NUMBER(ESEPtr, ExtStratElt_ObjWeightContrib);
                }
            }
        }
    }
    else
    {
        for (i=0; i<ESENbr; i++)
        {
            /* REF4047 - 000120 - SKE : exclude deleted instrument */
            if (deletedESEPtr != NULLDYNST)
            {
                if (deletedESEPtr == ESETab[i]) continue;
            }
            if (IS_NULLFLD(ESETab[i], field) == FALSE)
            {
	            (*tot) += GET_NUMBER(ESETab[i], field);
            }
        }
    }

    return(RET_SUCCEED);
}


/************************************************************************
*************** TOOLS ***************************************************
*************************************************************************/

/*************************************************************************************
*   Function             : FIN_StratGetParESEPtr()
*
*   Description          : Get extended strategy element parent.
*
*   Arguments            : ESEPtr          : extended strategy element pointer
*
*   Return               : RET_SUCCEED or error code
*
*   Creation Date        : 23.06.99 - REF3729
*
**************************************************************************************/
DBA_DYNFLD_STP FIN_StratGetParESEPtr(DBA_DYNFLD_STP ESEPtr)
{
    DBA_DYNFLD_STP  parESEPtr = NULLDYNST;

    /*
        REF4047 - 991207 - RAK/SKE :
        Go up level per level to reach the contribution ESE.
        The contribution ESE is either the parent strategy market segment
        or the top level (header) of a grid/grid list.
    */
    /*
    Display parent is parent of parent for some strategy element with level 2

    if (GET_EXTENSION_PTR(ESEPtr, ExtStratElt_LnkPar_ExtStratElt_Ext) != NULL           &&
	    (parESEPtr = *(GET_EXTENSION_PTR(ESEPtr, ExtStratElt_LnkPar_ExtStratElt_Ext))) != NULLDYNST)
    {
	    if (GET_TINYINT(ESEPtr, ExtStratElt_Level) == 2)
	    {
	        if (GET_EXTENSION_PTR(parESEPtr, ExtStratElt_LnkPar_ExtStratElt_Ext) != NULL)
		        parESEPtr = *(GET_EXTENSION_PTR(parESEPtr, ExtStratElt_LnkPar_ExtStratElt_Ext));
	    }
    }

    return(parESEPtr);
    */

    if (GET_TINYINT(ESEPtr, ExtStratElt_Level) == 0)
    {
        return(ESEPtr);
    }
    if (GET_EXTENSION_PTR(ESEPtr, ExtStratElt_LnkPar_ExtStratElt_Ext) != NULL           &&
	    (parESEPtr = *(GET_EXTENSION_PTR(ESEPtr, ExtStratElt_LnkPar_ExtStratElt_Ext))) != NULLDYNST)
    {
        if (CMP_DYNFLD(ESEPtr, parESEPtr, ExtStratElt_StratId, ExtStratElt_StratId, GET_FLD_TYPE(ExtStratElt, ExtStratElt_StratId)) != 0)
        {
            /* parESEPtr is the parent strategy market segment */
            return(parESEPtr);
        }
        return(FIN_StratGetParESEPtr(parESEPtr));
    }

    /* it would never occurs */
    return(parESEPtr);
}

/************************************************************************
**
**  Function    :   FIN_StratCmpESLLevel()
**
**  Description :   Extended strategy link table is sort by strategy and
**                  level
**
**  Arguments   :   ptr1   pointer on dynamic structure type ExtPos
**                  ptr2   pointer on dynamic structure type ExtPos
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation Date : 19.06.99 - REF3729
**  Modif.   Date : REF4047 - 991207 - SKE sort by strategy id
**	Modif.		  : REF7420 - RAK - 021024
**	Modif.		  : REF8777 - CHU - 030204
**
*************************************************************************/
int FIN_StratCmpESLLevel(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
	/* PMSTA03422 - RAK - 070807 - use CMP_DYNFLD instead of - */
	return(CMP_DYNFLD((*ptr1), (*ptr2), ExtStratLnk_Level, ExtStratLnk_Level, TinyintType));
}

/************************************************************************
**
**  Function    :   FIN_CmpParGridLevelInverse()
**
**  Description :   Sort ESL record by inverse grid hierarchy (child grid to parent grid)
**
**  Arguments   :   ptr1   pointer on dynamic structure type ExtStratLnk
**                  ptr2   pointer on dynamic structure type ExtStratLnk
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation Date : PMSTA06840-CHU-080718
**
*************************************************************************/
int FIN_CmpParGridLevelInverse(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    int cmp;

    if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2), ExtStratLnk_ParGridId, ExtStratLnk_ParGridId, IdType)) != 0)
    {
        return(cmp);
    }

    return (CMP_DYNFLD((*ptr1), (*ptr2), ExtStratLnk_Level, ExtStratLnk_Level, TinyintType));
}


/************************************************************************
**
**  Function    :   FIN_StratCmpEltNat()
**
**  Description :   Strategy element table is sort with model
**	            total line at the begin.
**
**  Arguments   :   ptr1   pointer on dynamic structure type ExtPos
**                  ptr2   pointer on dynamic structure type ExtPos
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation Date : 19.06.99 - REF3729
**
*************************************************************************/
int FIN_StratCmpEltNat(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
	/* Total model line */
	if (GET_ENUM((*ptr1), A_StratElt_NatEn) == StratEltNat_Model    ||
        GET_ENUM((*ptr1), A_StratElt_NatEn) == StratEltNat_ModelConstWeight)
    {
        return(-1);
    }
	else if (GET_ENUM((*ptr2), A_StratElt_NatEn) == StratEltNat_Model ||
             GET_ENUM((*ptr2), A_StratElt_NatEn) == StratEltNat_ModelConstWeight)
    {
        return(1);
    }
	else
    {
		return(0);
    }
}

/*************************************************************************************
*   Function             : FIN_StratFilterListCompo()
*
*   Description          : Filter the A_ListCompo records related to
*                          the grid list id criteria.
*
*
*   Arguments            : listCompoPtr : list compo element
*                          dynStTp      : element description enum
*                          stratPtr     : strategy pointer
*
*   Return               : TRUE if the condition is verified, FALSE otherwise.
*
*   Creation Date        : REF4047 - 991207 - SKE
*
**************************************************************************************/
int FIN_StratFilterListCompo(DBA_DYNFLD_STP   listCompoPtr,
				             DBA_DYNST_ENUM   dynStTp,
				             DBA_DYNFLD_STP   Io_IdPtr)
{

    OBJECT_ENUM objEn  = NullEntity;

    if (DBA_GetObjectEnum(GET_DICT(listCompoPtr, A_ListCompo_EntDictId), &objEn) == FALSE)
        return(FALSE);
    if (GET_EDITGUIST(objEn) != A_Grid)
        return(FALSE);
    if (IS_NULLFLD(listCompoPtr, A_ListCompo_A_Grid_Ext) == TRUE)
        return(FALSE);
    if (GET_EXTENSION_PTR(listCompoPtr, A_ListCompo_A_Grid_Ext) == NULL)
        return(FALSE);

    if (CMP_DYNFLD(listCompoPtr, Io_IdPtr, A_ListCompo_Id, Io_Id_Id, IdType) == 0)
    {
        return(TRUE);
    }
    return(FALSE);
}


/*************************************************************************************
*   Function             : FIN_StratFilterSMS()
*
*   Description          : Filter the S_MktSegt records related to
*                          the grid id criteria.
*
*
*
*   Arguments            : sMSPtr       : short market segment element
*                          dynStTp      : element description enum
*                          stratPtr     : ext strategy link pointer
*
*   Return               : TRUE if the condition is verified, FALSE otherwise.
*
*   Creation Date        : REF4047 - 991207 - SKE
*
**************************************************************************************/
int FIN_StratFilterSMS(DBA_DYNFLD_STP   sMSPtr,
				              DBA_DYNST_ENUM   dynStTp,
				              DBA_DYNFLD_STP   ESLPtr)
{
    if (CMP_DYNFLD(sMSPtr, ESLPtr, S_MktSegt_GridId, ExtStratLnk_GridId, IdType) == 0)
    {
        return(TRUE);
    }
    return(FALSE);
}


/************************************************************************
**
**  Function    :   FIN_StratCmpListCompo()
**
**  Description :   Sort A_ListCompo record by grid hierarchy
**                  (parent grid to child grid)
**
**
**  Arguments   :   ptr1   pointer on dynamic structure type A_ListCompo
**                  ptr2   pointer on dynamic structure type A_ListCompo
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation Date : REF4047 - 991207 - SKE
**  Modification  : REF7645 - 021129 - CHU
**
*************************************************************************/
int FIN_StratCmpListCompo(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    DBA_DYNFLD_STP  grid1       = NULLDYNST;
    DBA_DYNFLD_STP  grid2       = NULLDYNST;
    DBA_DYNFLD_STP *mktSegtTab  = NULLDYNSTPTR;
    int             mktSegtNbr;
    int             i;

    grid1 = *(GET_EXTENSION_PTR((*ptr1), A_ListCompo_A_Grid_Ext));
    grid2 = *(GET_EXTENSION_PTR((*ptr2), A_ListCompo_A_Grid_Ext));

    /* Is grid1 a top grid ? */
    if (IS_NULLFLD(grid1, A_Grid_ParMktSegtId) == TRUE)
        return(-1);
    /* Is grid2 a top grid ? */
    if (IS_NULLFLD(grid2, A_Grid_ParMktSegtId) == TRUE)
        return(1);

	/* REF7645 - CHU - 021129 : If levels are different and gap between them is    */
	/* no more than 1, a check must be made if a given grid is parent of the other */
	if ((GET_INT(grid1, A_Grid_ListCompoLevel) != GET_INT(grid2, A_Grid_ListCompoLevel)) &&
		abs(GET_INT(grid1, A_Grid_ListCompoLevel) - GET_INT(grid2, A_Grid_ListCompoLevel)) == 1)
	{
		/* Is grid1 the parent grid of grid2 ? */
		mktSegtNbr = GET_EXTENSION_NBR(grid1, A_Grid_S_MktSegt_Ext);
		mktSegtTab = GET_EXTENSION_PTR(grid1, A_Grid_S_MktSegt_Ext);
		for (i=0 ; i < mktSegtNbr ; i++)
		{
			if (GET_ID(mktSegtTab[i], S_MktSegt_Id) == GET_ID(grid2, A_Grid_ParMktSegtId))
			{
				return(-1);
			}
	    }
		/* Is grid2 the parent grid of grid1 ? */
		mktSegtNbr = GET_EXTENSION_NBR(grid2, A_Grid_S_MktSegt_Ext);
		mktSegtTab = GET_EXTENSION_PTR(grid2, A_Grid_S_MktSegt_Ext);
		for (i=0 ; i < mktSegtNbr ; i++)
		{
			if (GET_ID(mktSegtTab[i], S_MktSegt_Id) == GET_ID(grid1, A_Grid_ParMktSegtId))
			{
	            return(1);
		    }
		}
	}
	/* REF7645 - CHU - 021129 : Whatever the levels may be, identical or not if no parent  */
	/* was detected (see above in the code), return the difference between the grid levels */
	return(GET_INT(grid1, A_Grid_ListCompoLevel) -
			GET_INT(grid2, A_Grid_ListCompoLevel));
}

/************************************************************************
**
**  Function    :   FIN_StratListCompoSetGridLevel()
**
**  Description :   Sets Levels in ListCompo Grid records
**
**  Arguments   :   argHierHead		hierarchy pointer
**                  listCompoTab	pointer ListCompo array
**					listCompoNbr	number of ListCompo in the array
**
**  Return      :   RET_SUCCED or ret
**
**  Creation Date : REF7645 - CHU - 021129
**
*************************************************************************/
RET_CODE FIN_StratListCompoSetGridLevel(DBA_HIER_HEAD_STP	stratHierHead,
										int					listCompoNbr,
										DBA_DYNFLD_STP		*listCompoTab)
{
    DBA_DYNFLD_STP  loopGridPtr		= NULLDYNST;
	DBA_DYNFLD_STP  initialGridPtr	= NULLDYNST;
    int             i;
	int				gLevel;
	FLAG_T			mktSgtPtrAllocFlg = FALSE, topReached;
	DBA_DYNFLD_STP	ask=NULLDYNST, mktSgtPtr=NULLDYNST;
	int				ret = RET_SUCCEED;


	for (i = 0; i < listCompoNbr; i++)
	{
		gLevel = 0;
		topReached = FALSE;
		initialGridPtr = *(GET_EXTENSION_PTR(listCompoTab[i], A_ListCompo_A_Grid_Ext));
		loopGridPtr = initialGridPtr;

		while (topReached == FALSE)
		{
			if((loopGridPtr != NULLDYNST) && (IS_NULLFLD(loopGridPtr, A_Grid_ParMktSegtId) == FALSE))
			{
				mktSgtPtr = DBA_SearchHierRecById(stratHierHead,
                                          S_MktSegt,
					                      S_MktSegt_Id,
                                          GET_ID(loopGridPtr, A_Grid_ParMktSegtId));

				if (mktSgtPtr == NULLDYNST)
				{
					mktSgtPtrAllocFlg = TRUE;
					if ((ask = ALLOC_DYNST(Adm_Arg)) == NULLDYNST)
					{
						MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "Adm_Arg");
						return(RET_MEM_ERR_ALLOC);
					}
					if ((mktSgtPtr = ALLOC_DYNST(S_MktSegt)) == NULLDYNST)
					{
						MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "S_MktSegt");
						FREE_DYNST(ask, Adm_Arg);
						return(RET_MEM_ERR_ALLOC);
					}
					SET_ID(ask, Adm_Arg_Id, GET_ID(loopGridPtr, A_Grid_ParMktSegtId));
					if ((ret = DBA_Get2(MktSegt, UNUSED, Adm_Arg, ask,
										S_MktSegt, &mktSgtPtr, UNUSED, UNUSED, UNUSED)) != RET_SUCCEED)
					{
						FREE_DYNST(ask, Adm_Arg);
						FREE_DYNST(mktSgtPtr, S_MktSegt);
						MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "Market_Segment");
						return(RET_DBA_ERR_NODATA);
					}
					FREE_DYNST(ask, Adm_Arg);
				}

				gLevel++;

				if (IS_NULLFLD(mktSgtPtr, S_MktSegt_GridId) == FALSE)
				{
					/* Search short market segment in hierarchy */
					loopGridPtr = DBA_SearchHierRecById(stratHierHead, A_Grid,
						                       A_Grid_Id, GET_ID(mktSgtPtr, S_MktSegt_GridId));
				}
			}
			else
				topReached = TRUE;
		}
		SET_INT(initialGridPtr, A_Grid_ListCompoLevel, gLevel);
	}
	if (mktSgtPtrAllocFlg == TRUE)
	{
		FREE_DYNST(ask, Adm_Arg);
		FREE_DYNST(mktSgtPtr, S_MktSegt);
	}
	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_StratCmpStrat()
**
**  Description :   Sort A_Strat record by hierarchy (parent to child)
**
**
**  Arguments   :   ptr1   pointer on dynamic structure type A_ListCompo
**                  ptr2   pointer on dynamic structure type A_ListCompo
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation Date : REF4047 - 991207 - SKE
**
*************************************************************************/
int FIN_StratCmpStrat(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    if (IS_NULLFLD((*ptr1), A_Strat_ParentStratId) == TRUE)
    {
        return(-1);
    }
    if (IS_NULLFLD((*ptr2), A_Strat_ParentStratId) == TRUE)
    {
        return(1);
    }
    if (GET_ID((*ptr1), A_Strat_ParentStratId) == GET_ID((*ptr2), A_Strat_Id))
    {
        return(1);
    }
    if (GET_ID((*ptr2), A_Strat_ParentStratId) == GET_ID((*ptr1), A_Strat_Id))
    {
        return(-1);
    }

    return(0);
}



/************************************************************************
**
**  Function    :   FIN_StratFilterChildrenESE()
**
**  Description :   Filter all children ESE of parESE
**                  return TRUE  -> record must be extract
**                         FALSE -> record musn't be extract
**
**  Arguments   :   dynSt       element pointer
**                  dynStTp     element description enum
**                  parESE      parent ESE
**
**  Return      :   TRUE or FALSE
**
**  Creation Date : REF4047 - 20000207 - SKE
**
*************************************************************************/
int FIN_StratFilterChildrenESE(DBA_DYNFLD_STP   dynSt,
		                      DBA_DYNST_ENUM   dynStTp,
		                      DBA_DYNFLD_STP   parESE)
{
    if (IS_NULLFLD(dynSt, ExtStratElt_ParExtStratEltId) == TRUE)
    {
        return(FALSE);
    }
    if (GET_ID(dynSt, ExtStratElt_ParExtStratEltId) != GET_ID(parESE, ExtStratElt_Id))
    {
        return(FALSE);
    }
	/* Except ordinate children */
	if (IS_NULLFLD(dynSt, ExtStratElt_AbsListId) == TRUE &&
	    IS_NULLFLD(dynSt, ExtStratElt_OrdListId) == FALSE)
    {
	    return(FALSE);
    }
	return(TRUE);
}


/************************************************************************
**
**  Function    :   FIN_StratFilterChildrenESE()
**
**  Description :   Filter all ordinate children ESE of parESE
**                  return TRUE  -> record must be extract
**                         FALSE -> record musn't be extract
**
**  Arguments   :   dynSt       element pointer
**                  dynStTp     element description enum
**                  parESE      parent ESE
**
**  Return      :   TRUE or FALSE
**
**  Creation Date : REF4047 - 20000207 - SKE
**  Modification  : REF7067 - 20011001 - MCA --> corrected error "cut and paste"

*************************************************************************/
STATIC int FIN_StratFilterOrdChildrenESE(DBA_DYNFLD_STP   dynSt,
		                                 DBA_DYNST_ENUM   dynStTp,
		                                 DBA_DYNFLD_STP   parESE)
{
    if (IS_NULLFLD(dynSt, ExtStratElt_OrdParExtStratEltId) == TRUE)
    {
        return(FALSE);
    }
    if (GET_ID(dynSt, ExtStratElt_OrdParExtStratEltId) != GET_ID(parESE, ExtStratElt_Id))
    {
        return(FALSE);
    }
	return(TRUE);
}





/************************************************************************
**      END  finlib10.c
*************************************************************************/

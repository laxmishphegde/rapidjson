/************************************************************************
**
**              Copyright (C) Temenos Software Luxembourg SA 1995-2021.
**                       All Rights Reserved
**
**                   Portfolio Management System
**
*************************************************************************/

#include "unidef.h"     /* Mandatory */

#include "gen.h"

#define GENVERSION_H_INCLUDED_ALLOWED
#include "genversion.h"
#include "genversion_git.h"

/************************************************************************
*   Static             : AAAVersion
*
*   Description        : singleton containing Version information
*
*************************************************************************/

AAAVersion* AAAVersion::sv_AAAVersion = nullptr;

/************************************************************************
*   Method             : AAAVersion::getVersion
*
*   Description        : static access to singleton
*
*************************************************************************/
const AAAVersion& AAAVersion::getVersion()
{
    if (sv_AAAVersion == nullptr) {
        sv_AAAVersion = new AAAVersion();
    }
    return *sv_AAAVersion;
}

/************************************************************************
*   Method             : AAAVersion::AAAVersion
*
*   Description        : private Constructor -> use AAAVersion::getVersion()
*
*************************************************************************/
AAAVersion::AAAVersion()
{
    mMajor = SV_Major;
    mMinor = SV_Minor;
    int _revision=_REVISION_VERSION_;
    if (strlen(_PRIVATE_HOTFIX_INDICATOR_STR_) > 0)
    {
        if (_revision > 0) {
            mFixCode = __TO_STRING(_FIX_VERSION_) _PRIVATE_HOTFIX_INDICATOR_STR_ __TO_STRING(_revision);
        }
        else
        {
            mFixCode = __TO_STRING(_FIX_VERSION_) _PRIVATE_HOTFIX_INDICATOR_STR_;
        }
    }
    else
    {
        if (_revision > 0) {
            mFixCode = __TO_STRING(_FIX_VERSION_)  __TO_STRING(_revision);
        }
        else
        {
            mFixCode = __TO_STRING(_FIX_VERSION_);
        }
    }
    mBits = sizeof(char *) == 4 ? 32 : 64;

    mMajorCode = std::to_string(mMajor);
    mMinorCode = std::to_string(mMinor);

    mOsName = SV_operatingSystemName;
    mBitsCode = std::to_string(mBits);
    mComercialName = _COMERCIAL_NAME_STR_;
    mComercialVersion = _COMERCIAL_VERSION_STR_;
    mDebugIndicator = SV_debugInfo;
    mbuildDate = SV_buildDate;
    mGitDescribeInfo = GIT_VERSION_STRING;
    mLegalCopyright = _LEGAL_COPYRIGHT_STR_;
    mLegalTripleATrademarks = _LEGAL_TAP_TRADEMARK_STR_;
    mLegalTrademarksCommon = _LEGAL_TRADEMARK_COMMON_STR_;
    mLegalTrademarksOracle = _LEGAL_TRADEMARK_ORACLE_STR_;
    mLegalTrademarksSybase = _LEGAL_TRADEMARK_SYBASE_STR_;
    mLegalTrademarksNuoDB = _LEGAL_TRADEMARK_NUODB_STR_;

}
/************************************************************************
*   Method             : AAAVersion::compare
*
*   Description        : return 0 if equal, <0 if argument are greater(major and then minor), >0 if argument are lower
*
*************************************************************************/
int AAAVersion::compare(int withMajor, int withMinor) const
{
    if (mMajor == withMajor && mMinor == withMinor)
    {
        return 0;
    }
    else if(mMajor < withMajor || mMajor == withMajor && mMinor < withMinor)
    {
        return -1;
    }
    else
    {
        return +1;
    }

}
/************************************************************************
*   Method             : AAAVersion::getVersionCode
*
*   Description        : e.g.
*                           R25.4
*
*************************************************************************/
const std::string AAAVersion::getVersionCode() const
{
return SV_VersionPrefix + mMajorCode + '.' + mMinorCode;
}

/************************************************************************
*   Method             : AAAVersion::buildDateAndInfo
*
*   Description        : e.g.
*                           R25.4.0 2019-Jul-16 18:00:16 (WIN64 Debug)
*
*************************************************************************/
const std::string AAAVersion::buildDateAndInfo() const
{
    std::string result (getVersionAndFix() + ' ' + mbuildDate + " (" + mOsName + mBitsCode);

    if (mDebugIndicator.length() > 0)
    {
        result.append(' ' + mDebugIndicator);
    }

    result.append(")");

    return result;

}

/************************************************************************
*   Method             : AAAVersion::getfullVersionInfo
*
*   Description        : Get The full version info as e.g
*                        R25.1.1 2019-Jun-16 20:08:16 (AIX64) 25.1.0-309-g9e41dc6a
*                        R25.4.0 2019-Jul-16 18:00:16 (WIN64 Debug) 25.2.0-153-g7623bd11
*                        old format was
*                        R25.1.01.Jun 16 2019-20:08:16 (AIX64)
*                        R25.2.0.Jun 17 2019-11:02:33 with debug info (LIN64)
*
*************************************************************************/
const std::string AAAVersion::getfullVersionInfo() const
{
    return buildDateAndInfo() + ' ' + getGitDescribeInfo();
}

/************************************************************************
*   Method             : AAAVersion::getVersionAndFix
*
*   Description        : e.g.
*                           R25.4.0
*
*************************************************************************/
const std::string AAAVersion::getVersionAndFix() const
{
    return getVersionCode() + '.' + mFixCode;
}

/************************************************************************
*   Method             : AAAVersion::getVersionFixAndBuildDate
*
*   Description        : e.g.
*                           R25.4.0.2019-Jul-16 18:00:16
*
*************************************************************************/
const std::string  AAAVersion::getVersionFixAndBuildDate() const
{
    return getVersionAndFix() + '.' + mbuildDate;
}

/************************************************************************
*   Method             : AAAVersion::getComercialNameAndVersion
*
*   Description        : e.g.
*                           WealthSuite Front Office
*
*************************************************************************/
const std::string AAAVersion::getComercialNameAndVersion() const
{
    if (mComercialVersion.length() == 0)
    {
        return mComercialName;
    }
    else
    {
        return mComercialName + '.' + mComercialVersion;
    }
}


/************************************************************************
*   Method             : AAAVersion::getCopyright
*
*   Description        : e.g.
*                           Temenos Copyright (C) 1995-2019
*
*************************************************************************/
const std::string  AAAVersion::getCopyright() const
{
    return mLegalCopyright;
}


/************************************************************************
*   Method             : AAAVersion::getLegalTripleATrademarks
*
*   Description        : e.g.
*                           @TDB
*
*************************************************************************/
const std::string  AAAVersion::getLegalTripleATrademarks() const
{
    return mLegalTripleATrademarks;
}

/************************************************************************
*   Method             : AAAVersion::getLegalOtherTrademarks
*
*   Description        : e.g.
*                           @TDB
*
*************************************************************************/
const std::string  AAAVersion::getLegalOtherTrademarks(DBA_RDBMS_ENUM vendor) const
{
    std::string result(mLegalTrademarksCommon);
    switch (vendor)
    {
    case Sybase:
        result.append(mLegalTrademarksSybase);
        break;
    case Oracle:
        result.append(mLegalTrademarksOracle);
        break;
        //case NuoDb:
        //     result.append(mLegalTrademarksNuoDB);
        //    break;
    case QtHttp:
    case UnknownRdbms:
        break;
    }
    return result;
}

/************************************************************************
*   Method             : AAAVersion::printExample
*
*   Description        : Print the examples
*
*************************************************************************/
std::ostream&  AAAVersion::printExample(std::ostream& os) const
{

    os << "getfullVersionInfo() = " << getfullVersionInfo() << "\n";
    os << "getMajor() = " << getMajor() << "\n";
    os << "getMinor() = " << getMinor() << "\n";
    os << "getBits() = " << getBits() << "\n";
    os << "getVersionCode() = " << getVersionCode() << "\n";
    os << "getFixCode() = " << getFixCode() << "\n";
    os << "buildDateAndInfo() = " << buildDateAndInfo() << "\n";
    os << "getOsName() = " << getOsName() << "\n";
    os << "getBitsCode() = " << getBitsCode() << "\n";
    os << "getVersionAndFix() = " << getVersionAndFix() << "\n";
    os << "getBuildDate() = " << getBuildDate() << "\n";
    os << "getVersionFixAndBuildDate() = " << getVersionFixAndBuildDate() << "\n";
    os << "getDebugIndicator() = " << getDebugIndicator() << "\n";
    os << "getGitDescribeInfo() = " << getGitDescribeInfo() << "\n";
    os << "getComercialName() = " << getComercialName() << "\n";
    os << "getComercialVersion() = " << getComercialVersion() << "\n";
    os << "getComercialNameAndVersion() = " << getComercialNameAndVersion() << "\n";
    os << "getCopyright() = " << getCopyright() << "\n";
    os << "getLegalTripleATrademarks() = " << getLegalTripleATrademarks() << "\n";
    os << "getLegalOtherTrademarks() = " << getLegalOtherTrademarks(UnknownRdbms) << "\n";

    return os;
}

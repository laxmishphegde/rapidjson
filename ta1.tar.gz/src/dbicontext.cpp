/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#include "dbicontext.h"
#include "connection.h"
#include "conprovider.h"

DbiContext::DbiContext( const AAAConnection& connection)
{
	this->dbiConnection = static_cast<const DbiConnection *>(&connection);

}

const DbiConnection*  DbiContext::getDbiConnection()
{
	return this->dbiConnection;
}

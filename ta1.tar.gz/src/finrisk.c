/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define FINRISK_C

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H
#define MATH_H

#include "unidef.h"         /* Mandatory */
#include "gen.h"
#include "date.h"
#include "dba.h"
#include "hier.h"
#include "fin.h"
#include "finsrv.h"
#include "serv.h"
#include "scptyl.h"
#include "scelib.h"
#include "finrisk01.h"

/*  ------------------------------------------------------------------------------------------ **
**  FUND SPLITTING FUNCTIONS
**  ------------------------
**  FIN_FundSplitting() 	    Determines the characteristics of a fund and evaluate positions
**
**  FIN_FundSplittingComposit() Treat composit fund splitting
**  FIN_FundSplittingTreat()    Treat position's instrument (test fundShare)
**
**  ------------------------------------------------------------------------------------------ **
**  RISK FUNCTIONS
**  --------------
**  FIN_RiskAnalysis() 		        Test risk flag and init risk computation
**  FIN_PosRiskAnalysis() 	        Determine whether risk adjusted position must be computed
**
**  FIN_AddValoRiskCashPos() 	    Add cash position for risk valuation
**  FIN_AddValoRiskOptCashPos()     Add and valorise risk cash position for option
**  FIN_AddValoRiskPos() 	        Add risk position in hierarchy and valorise it
**  FIN_ComputeRiskAmt() 	        Compute with ratio from original position amount all sons amount
**  FIN_CreateInstrDiscount()       Create a discount.
**  FIN_CreateInstrMoneyMkt()       Create a money market.
**  FIN_CreateRiskAmt() 	        Read original position amts for initialize risk amts to total amts
**  FIN_GetFutFwdUnderlyInfo()	    Return underly for future or forward position
**  FIN_RiskGetInstrPtr()           Get instrument and in case of generic forward add underlying info.
**  FIN_RiskPosLink() 		        Prepare risk position link
**  FIN_RiskSonPriceAmt() 	        Compute risk son price depending on status (Son - LastSon)
**  FIN_TreatCompoRisk() 	        Create risk position (normal position or final component)
**  FIN_TreatFRACashPos()           Treat FRA cash position.
**  FIN_TreatFRARisk() 		        Create risk position(s) for FRA position
**  FIN_TreatFRARiskMoneyMktPos()   Treate money market
**  FIN_TreatFutFwdRisk() 	        Create risk position(s) for future and forward position
**  FIN_TreatOptionRisk() 	        Create risk position for option
**  FIN_UpdRiskPosHier() 	        Update risk pos and add it in hierarchy with instr and valo ext
**
**  FIN_CmpCashPos()                Position table is sort by instr nature : cash are last.
**  ------------------------------------------------------------------------------------------ */

/************************************************************************
**      Static definitions & data
*************************************************************************/
STATIC RET_CODE FIN_ComputeRiskAmt(DBA_DYNFLD_STP, DBA_DYNFLD_STP, int, NUMBER_T, ID_T, ID_T,
				                   DBA_DYNFLD_STP, int, RISK_ANALYSIS_ENUM, DBA_HIER_HEAD_STP), /* REF2580 - SSO - 980727 */
		        FIN_CreateInstrDiscount(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP,
					                    DATE_T, DATE_T, DBA_DYNFLD_STP*),
		        FIN_CreateInstrMoneyMkt(DBA_HIER_HEAD_STP, FIN_MONEYMKTINFO_STP, DBA_DYNFLD_STP*),
                FIN_FundSplitting(DBA_DYNFLD_STP, FIN_DOMAIN_ARG_STP, FIN_AIARG_STP,
				                  DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP),	/* REF524 */
		        FIN_FundSplittingComposit(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, FIN_DOMAIN_ARG_STP,
					                      FIN_AIARG_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP,
					                      RISK_QTY_STP), /*BUG175*/
		        /* DVP191 - RAK - 960918 */
		        FIN_RiskGetInstrPtr(DBA_HIER_HEAD_STP, DATETIME_T, ID_T, DBA_DYNFLD_STP,
                                    DBA_DYNFLD_STP*, char*),
	            FIN_TreatFutFwdRisk(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, FIN_DOMAIN_ARG_STP, FIN_AIARG_STP,
				                    DBA_DYNFLD_STP, DBA_DYNFLD_STP, char, DBA_DYNFLD_STP,
				                    RISK_QTY_STP, FIN_PRICEARG_STP, RISK_ANALYSIS_ENUM, RISK_FUTFWD_ENUM), /*DVP189*/
	            FIN_TreatFRARisk(DBA_HIER_HEAD_STP, FIN_DOMAIN_ARG_STP, FIN_AIARG_STP,
				                 DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP,
				                 RISK_QTY_STP, FIN_PRICEARG_STP, RISK_ANALYSIS_ENUM), 	/* REF2852 */
		        FIN_TreatFRARiskMoneyMktPos(DBA_HIER_HEAD_STP, FIN_DOMAIN_ARG_STP, FIN_AIARG_STP,
                                            DBA_DYNFLD_STP, DBA_DYNFLD_STP,
				                            RISK_QTY_STP, FIN_PRICEARG_STP, RISK_ANALYSIS_ENUM,
				                            DBA_DYNFLD_STP, char),
		        FIN_TreatFRACashPos(DBA_HIER_HEAD_STP, FIN_DOMAIN_ARG_STP, FIN_AIARG_STP,
				                    DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP),
				FIN_TreatOptionRisk(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, FIN_DOMAIN_ARG_STP, FIN_AIARG_STP,
				DBA_DYNFLD_STP, DBA_DYNFLD_STP, char, DBA_DYNFLD_STP,
				RISK_QTY_STP, FIN_PRICEARG_STP, RISK_ANALYSIS_ENUM),
				FIN_TreatFutTimeValue(DBA_HIER_HEAD_STP, FIN_DOMAIN_ARG_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP);

STATIC int FIN_CmpCashPos(DBA_DYNFLD_STP*, DBA_DYNFLD_STP*);

STATIC void FIN_PosRiskAnalysisInitAdAM(INSTRCATEGORY_ENUM, FLAG_T*);

STATIC RET_CODE FIN_FundSplittingCalcRule(FUNDSPLITCALCRULE_ENUM, DBA_DYNFLD_STP, DBA_DYNFLD_STP,
										  DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP);
STATIC RET_CODE FIN_RiskUnderlyExtPosPriceAndAI(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, PRICE_T*, NUMBER_T*);


/************************************************************************
**  Function             : FIN_FundSplitting()
**
**  Description          : Determines the characteristics of a fund either
**                         in terms of components or as characteristics of
**                         the components and attributes these on a prorata
**                         basis to the portfolio containing fund shares.
**
**  Arguments            : domainPtr    domain pointer
**                  	   domainArgPtr pointer on some domain informations
**                         posHierHead  hierarchy pointer
**                         origPos      position pointer
**
**  Return               : RET_SUCCEED, RET_GEN_INFO_NOACTION or error code
**
**  Modif.		 : DVP082 - 960613 - DED : Delete attribute 'GreatestValDate'
**  Modif.		 : BUG135 - 960924 - RAK
**  Modif.		 : BUG154 - 961003 - RAK
**  Modif.		 : BUG175 - 961010 - RAK
**  Modif.		 : DVP239 - 961104 - RAK
**  Modif.		 : REF524 - 971014 - RAK
**  Modif.		 : REF1457 - RAK - 980324
**  Modif.		 : REF2313 - RAK - 980910
**  Modif.		 : REF2562 - SSO - 980723
**  Modif. 		 : REF3357 - RAK - 990223
**  Modif.       : REF5746 - RAK - 010404
**  Modif.       : REF7661 - YST - 020725
*************************************************************************/
STATIC RET_CODE FIN_FundSplitting(DBA_DYNFLD_STP     domainPtr,
                                  FIN_DOMAIN_ARG_STP domainArgPtr,
				                  FIN_AIARG_STP      aiArgPtr,
                                  DBA_HIER_HEAD_STP  posHierHead,
		                          DBA_DYNFLD_STP     origPos,
				                  DBA_DYNFLD_STP     origInstr)			/* REF524 */
{
	SMALLINT_T				level;
	RET_CODE				ret=RET_GEN_INFO_NOACTION;
	FUNDSPLITCALCRULE_ENUM	fundSplitCalcRule;
    MemoryPool              mp;

	/* Fund splitting asked and fund share position */
	DBA_DYNFLD_STP fundDomainPtr = mp.allocDynst(FILEINFO,A_Domain);
	DBA_DYNFLD_STP fundPtr = mp.allocDynst(FILEINFO,A_FundWgt);

	/* Developer Information Not Obsolete Serious And Useful Recommendation � DINOSAUR � KPV � 110831 */
	/* here the trouble really start with the verifcation of level and the fund weight selection */

	/* Add one level */
	level = GET_SMALLINT(domainPtr, A_Domain_FundSplitLevel);	/* BUG175 */
	level += 1;
	SET_SMALLINT(fundDomainPtr, A_Domain_FundSplitLevel, level);  /* portfolio case */

	SET_ID(fundPtr,       A_FundWgt_InstrId, GET_ID(origInstr, A_Instr_Id));
	SET_DATETIME(fundPtr, A_FundWgt_BegDate, GET_DATETIME(domainPtr, A_Domain_InterpFromDate));

	/* Fund weight not found, instrument is composite */
	if (GET_FLAG(domainPtr, A_Domain_RiskExpoFlg) == TRUE)
		domainArgPtr->fundRiskEn = FinFundRisk_FundRisk;
	else
		domainArgPtr->fundRiskEn = FinFundRisk_FundCompo;

	/* REF9030 - RAK - 030430 */
	/* Test on domaine FundSplitting rule which have    */
	/* new values first case is standard (and old) case */
	switch (GET_ENUM(domainPtr, A_Domain_FundSplitRuleEn))
	{
    /* Standard method */
	case FundSplitRule_Split :
		/* Fund weight isn't found, use composite method */
		if (DBA_Get2(FundWgt, UNUSED, A_FundWgt, fundPtr, A_FundWgt, &fundPtr,
					 UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
		{
			RISK_QTY_ST    riskQtySt;
			DBA_DYNFLD_STP totPosRisk=NULL;

			domainArgPtr->riskDecompoLevel = 0;

			/* DVP175 - RAK - 961010 */ /* REF5416 - RAK - 010118 - new arg posHierHead */
			if ((totPosRisk = FIN_CreateRiskAmt(posHierHead, origPos, domainArgPtr->fromDateTime,
												domainArgPtr->refCurrId)) != NULL)
			{
                mp.ownerDynStp(totPosRisk);

				riskQtySt.idxCalcRuleEn = IdxCalcRule_None;
				riskQtySt.qty           = GET_NUMBER(origPos, ExtPos_Qty);
				riskQtySt.price         = 0.0;
				riskQtySt.priceCurrId   = (ID_T)0;
				riskQtySt.pricePtr      = NULL;

				ret = FIN_FundSplittingComposit(posHierHead, domainPtr, domainArgPtr, aiArgPtr,
					                            origPos, totPosRisk, &riskQtySt);

				if (ret == RET_SUCCEED)
				{ SET_ENUM(origPos, ExtPos_FundSplitNatEn, FundSplitNat_Splitted);}
			}
			else
				ret = RET_GEN_INFO_NOACTION;
		}
		else
		{
			/* DVP003 : New application parameter (96/02/27) */
			GEN_GetApplInfo(ApplFundSplitCalcRule, &fundSplitCalcRule);

			ret = FIN_FundSplittingCalcRule(fundSplitCalcRule, fundPtr, fundDomainPtr,
											domainPtr, posHierHead, origPos, origInstr);
		}
		break;

	case FundSplitRule_ForceCompo :
	{
		RISK_QTY_ST    riskQtySt;
		DBA_DYNFLD_STP totPosRisk=NULL;

		domainArgPtr->riskDecompoLevel = 0;

		ret = RET_GEN_INFO_NOACTION;

		if ((totPosRisk = FIN_CreateRiskAmt(posHierHead, origPos, domainArgPtr->fromDateTime,
											domainArgPtr->refCurrId)) != NULL)
		{
            mp.ownerDynStp(totPosRisk);

			riskQtySt.idxCalcRuleEn = IdxCalcRule_None;
			riskQtySt.qty           = GET_NUMBER(origPos, ExtPos_Qty);
			riskQtySt.price         = 0.0;
			riskQtySt.priceCurrId   = (ID_T)0;
			riskQtySt.pricePtr      = NULL;

			ret = FIN_FundSplittingComposit(posHierHead, domainPtr, domainArgPtr, aiArgPtr,
					                        origPos, totPosRisk, &riskQtySt);

			if (ret == RET_SUCCEED)
			{ SET_ENUM(origPos, ExtPos_FundSplitNatEn, FundSplitNat_Splitted);}
		}

		/* Composit method doesn't work */
		if (ret != RET_SUCCEED)
		{
			if ((ret = DBA_Get2(FundWgt, UNUSED, A_FundWgt, fundPtr, A_FundWgt, &fundPtr,
					            UNUSED, UNUSED, UNUSED)) == RET_SUCCEED)
			{
				GEN_GetApplInfo(ApplFundSplitCalcRule, &fundSplitCalcRule);

				ret = FIN_FundSplittingCalcRule(fundSplitCalcRule, fundPtr, fundDomainPtr,
												domainPtr, posHierHead, origPos, origInstr);
			}
		}
		break;
	}

	case FundSplitRule_SplitMethod1 :
		if ((ret = DBA_Get2(FundWgt, UNUSED, A_FundWgt, fundPtr, A_FundWgt, &fundPtr,
					        UNUSED, UNUSED, UNUSED)) == RET_SUCCEED)
		{
			ret = FIN_FundSplittingCalcRule(FundSplitCalcRule_RatioOfValues, fundPtr, fundDomainPtr,
											domainPtr, posHierHead, origPos, origInstr);
		}
		break;

	case FundSplitRule_SplitMethod2 :
		if ((ret = DBA_Get2(FundWgt, UNUSED, A_FundWgt, fundPtr, A_FundWgt, &fundPtr,
					        UNUSED, UNUSED, UNUSED)) == RET_SUCCEED)
		{
			ret = FIN_FundSplittingCalcRule(FundSplitCalcRule_NbrOfIssuedShares, fundPtr, fundDomainPtr,
										domainPtr, posHierHead, origPos, origInstr);
		}
		break;

	case FundSplitRule_SplitMethod3 :
		if ((ret = DBA_Get2(FundWgt, UNUSED, A_FundWgt, fundPtr, A_FundWgt, &fundPtr,
					        UNUSED, UNUSED, UNUSED)) == RET_SUCCEED)
		{
			ret = FIN_FundSplittingCalcRule(FundSplitCalcRule_NAV, fundPtr, fundDomainPtr,
										domainPtr, posHierHead, origPos, origInstr);
		}
		break;
	}

	return(ret);
}

/************************************************************************
**  Function             : FIN_FundSplittingCalcRule()
**
**  Description          : Compute fund splitting according to calculation rule.
**
**  Arguments            :
**
**  Return               : RET_SUCCEED, RET_GEN_INFO_NOACTION or error code
**
**  Creation			 : REF9030 - RAK - 030429
**  Modification		 : REF9991 - RAK - 040317
**
*************************************************************************/
STATIC RET_CODE FIN_FundSplittingCalcRule(FUNDSPLITCALCRULE_ENUM fundSplitCalcRule,
										  DBA_DYNFLD_STP		 fundPtr,
										  DBA_DYNFLD_STP		 fundDomainPtr,
										  DBA_DYNFLD_STP         domainPtr,
										  DBA_HIER_HEAD_STP      posHierHead,
										  DBA_DYNFLD_STP         origPos,
									      DBA_DYNFLD_STP         origInstr)
{
	DBA_HIER_HEAD_STP fundHierHead;
	DBA_DYNFLD_STP    val=NULL, extVal=NULL,
			          pos=NULL, newInstr=NULL, dimChronoPtr=NULL,
			          fundPtfPtr=NULL, *fundPos=NULL,
                      admArgPtr=NULL, *fundWgtTab=NULL, pricePtr=NULL;
	DBA_DYNFLD_STP    chronoPtr=NULL;
	NUMBER_T          ratio=0.0, ratioWithoutExch=0.0, tmp, fundVal, nbrOfShares=0.0, netAssetVal=0.0;
	AMOUNT_T          denom, tmpAmt; /* PMSTA-18064 - 060614 */
	EXCHANGE_T        exch;
	DICT_T            ptfDictId;
	int               i, posNbr, bpAmtFld, dbFlg=FALSE, fundWgtNbr;
	char              addOk;
	RET_CODE          ret;
    DBA_DYNFLD_STP	  *newExtTab=NULL; /* REF5442 - DDV - 010205 */
    FLAG_T            fwdAccFlg = FALSE, futAccFlg = FALSE, termAccFlg = FALSE; /* REF7661 - YST - 020725 */
	DBA_DYNFLD_STP      valo = NULLDYNST;
	/* REF2562 - SSO - 980723 : need to compute total amounts to adjust last fund share record */
	/* for last fund record, the amount must be adjusted to avoid rounding problems;
	   this need to be done only for some fields: the sum for all records (composing the share)
	   must be equal to the corresponding field in the share fund valo */
	/* vars for total amounts (for the fund share) */
	AMOUNT_T	    ep_TotSysGrossAmt=0.0, ep_TotSysNetAmt=0.0, ep_TotRefGrossAmt=0.0, ep_TotRefNetAmt=0.0,
			        pv_TotRefMktValAmt=0.0, pv_TotRefAccrInterAmt=0.0, pv_TotRefNetAmt=0.0;
	/* vars for total ratio amounts (for the current pos; i.e. computed with the ratio) */
	AMOUNT_T	    ep_RatTotSysGrossAmt=0.0, ep_RatTotSysNetAmt=0.0, ep_RatTotRefGrossAmt=0.0, ep_RatTotRefNetAmt=0.0,
			        pv_RatTotRefMktValAmt=0.0, pv_RatTotRefAccrInterAmt=0.0, pv_RatTotRefNetAmt=0.0;

	/* Already read number of shares because of   */
	/* if it don't exist, don't splitt fund share */
	if (fundSplitCalcRule == FundSplitCalcRule_NbrOfIssuedShares)
	{
		if ((chronoPtr = ALLOC_DYNST(A_InstrChrono)) == NULL)
		{
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

	    if ((dimChronoPtr = ALLOC_DYNST(Dim_InstrChrono)) == NULL)
	    {
		    FREE_DYNST(chronoPtr, A_InstrChrono);
			MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }

	    SET_ID(dimChronoPtr,       Dim_InstrChrono_InstrId, GET_ID(origInstr, A_Instr_Id));
	    SET_ENUM(dimChronoPtr,     Dim_InstrChrono_NatEn,      ChronoNat_NbrShares);
	    SET_FLAG(dimChronoPtr,     Dim_InstrChrono_ComputeFlg, FALSE);
	    SET_DATETIME(dimChronoPtr, Dim_InstrChrono_RefDate,
		GET_DATETIME(domainPtr, A_Domain_InterpFromDate));

	    ret = FIN_InstrChrono(dimChronoPtr, origInstr, chronoPtr, posHierHead);
	    FREE_DYNST(dimChronoPtr, Dim_InstrChrono);

        if (ret != RET_SUCCEED)
		{
			FREE_DYNST(chronoPtr, A_InstrChrono);
			return(ret);
		}
		else
		{
			/*
			** TGU-REF11704-060413-Use GET_LONGAMOUNT since data type for field
			** instr_chrono.value_n has been changed from NUMBER to LONGAMOUNT.
			*/
			if (IS_NULLFLD(chronoPtr, A_InstrChrono_Val) == TRUE ||
			    GET_LONGAMOUNT(chronoPtr, A_InstrChrono_Val) <= 0.0)
			{
			    MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, "FIN_FundSplitting",
				             GET_CODE(origInstr, A_Instr_Cd), "number of shares");
			    FREE_DYNST(chronoPtr, A_InstrChrono);
			    return(RET_FIN_ERR_INVDATA);
			}
			else
			{
			    nbrOfShares = GET_LONGAMOUNT(chronoPtr, A_InstrChrono_Val); /* REF11704 - TGU - 060419 - Change datatype */
			    FREE_DYNST(chronoPtr, A_InstrChrono);
			}
		}
	}

	/* REF9030 - RAK - 030429 - New calculation rule */
	/* Already read NAV (Net Asset Value) because of */
	/* if it don't exist, don't splitt fund share    */
	if (fundSplitCalcRule == FundSplitCalcRule_NAV)
	{
		if ((chronoPtr = ALLOC_DYNST(A_PtfChrono)) == NULL)
	    		MSG_RETURN(RET_MEM_ERR_ALLOC);

	    if ((ret = DBA_GetPortChrono(GET_ID(fundPtr, A_FundWgt_PtfId), 0,
									 GET_DATETIME(domainPtr, A_Domain_InterpFromDate),
									 PtfChronoNat_NAV, TimeDim_Last, TRUE, chronoPtr)) == RET_SUCCEED)
	    {
			if (IS_NULLFLD(chronoPtr, A_PtfChrono_Val) == TRUE ||
			    GET_NUMBER(chronoPtr, A_PtfChrono_Val) <= 0.0)
			{
				MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, "FIN_FundSplitting",
				             GET_CODE(origInstr, A_Instr_Cd), "NAV (Net Asset Value)");
			    FREE_DYNST(chronoPtr, A_PtfChrono);
			    return(RET_FIN_ERR_INVDATA);
			}
			else
			{
			    netAssetVal = GET_NUMBER(chronoPtr, A_PtfChrono_Val);
			    FREE_DYNST(chronoPtr, A_PtfChrono);
			}
	    }
		else
		{
			FREE_DYNST(chronoPtr, A_PtfChrono);
			return(ret);
		}
	}

	/* Portfolio can't have itself fund part */
	if (GET_ID(fundPtr, A_FundWgt_PtfId) == GET_ID(domainPtr, A_Domain_PtfObjId))
	{
   		return(RET_GEN_INFO_NOACTION);
	}

	/* Use original domain and evaluate new portfolio */
	COPY_DYNST(fundDomainPtr, domainPtr, A_Domain);

	SET_ID(fundDomainPtr,        A_Domain_PtfObjId, GET_ID(fundPtr, A_FundWgt_PtfId));
	SET_NULL_DICT(fundDomainPtr, A_Domain_DimInstrDictId);
	SET_NULL_ID(fundDomainPtr,   A_Domain_InstrObjId);

	DBA_GetDictId(Ptf, &ptfDictId);
	SET_DICT(fundDomainPtr, A_Domain_DimPtfDictId, ptfDictId);

	/* Debt aren't be evaluated when fund splitting */
	SET_FLAG(fundDomainPtr, A_Domain_DebtFlg, FALSE);

	/* REF9991 - RAK - 040316 - Do valorisation in position currency elsewhere exchange is applied twice */
	COPY_DYNFLD(fundDomainPtr, A_Domain, A_Domain_CurrId,
		        origPos, ExtPos, ExtPos_PosCurrId);

	/* Developer Information Not Obsolete Serious And Useful Recommendation � DINOSAUR � KPV � 110831 */
	/* load and evaluate fund portfolio */

	/* Load POSITIONS, PORTFOLIO(S) and INSTRUMENT(S) */
	/* according to Domain parameters */
	/* BEGIN DVP023 960417 RAK */
	fundHierHead = (DBA_HIER_HEAD_STP) NULL;
	if ((ret = DBA_LoadPos(fundDomainPtr, &fundHierHead, NULL, 0, 
			               NULL, 0)) != RET_SUCCEED)	/* BUG467 - 970822 - DED */
	{
		return(RET_FIN_ERR_POSITIONS);
	}

	if ((ret = FIN_AnalysisValo(fundDomainPtr, fundHierHead)) != RET_SUCCEED)
	{
		return(ret);
	}

	/* Extract all loaded positions */
	if ((ret = DBA_ExtractHierEltRec(fundHierHead, ExtPos, FALSE,
		                             NULLFCT, FIN_CmpCashPos,
					                 &posNbr, &fundPos)) != RET_SUCCEED)
	{
		return(ret);
	}

	if (posNbr == 0)
    {
        return(RET_GEN_INFO_NOACTION); /* REF1203 - RAK - 980127 */
    }

	if (GET_EXTENSION_PTR(fundPos[0], ExtPos_A_Ptf_Ext) != NULL &&
	    (fundPtfPtr = *(GET_EXTENSION_PTR(fundPos[0], ExtPos_A_Ptf_Ext))) != NULL)
	{
		/* DVP023 (Productivity) 960503 RAK */
		/* fundVal = GET_NUMBER(fundPtfPtr, A_Ptf_NetVal); */
		fundVal = GET_NUMBER(fundPtfPtr, A_Ptf_MktValM);
	}
	else
	{
		FREE(fundPos);
	    MSG_SendMesg(RET_DBA_ERR_HIER, 6, FILEINFO, "FIN_FundSplitting", ExtPos_A_Ptf_Ext);
		return(RET_DBA_ERR_HIER);
	}

	if (GET_EXTENSION_PTR(origPos, ExtPos_PosVal_Ext) == NULL ||
	    (extVal = *(GET_EXTENSION_PTR(origPos, ExtPos_PosVal_Ext))) == NULL)
	{
		FREE(fundPos);
	    MSG_SendMesg(RET_DBA_ERR_HIER, 6, FILEINFO, "FIN_FundSplitting", ExtPos_PosVal_Ext);
		return(RET_DBA_ERR_HIER);
	}

	/* REF11014 - RAK - 050308 */
	/* Get Exchange rate between valorisation currency (ExtPos_PosCurrId set in fundDomainPtr)   */
	/* and reference currency of origPos (which is domain currency in case of DefCurrFlg = FALSE */
	/*                                    or ptf currency in case of DefCurrFlg = TRUE)          */
	if (GET_ID(origPos, ExtPos_PosCurrId) != GET_ID(origPos, ExtPos_RefCurrId))
	{
		FIN_EXCHARG_ST  exchArgSt;			/* REF2313 */
		memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));
		/*DBA_SetConnectNoToExchArg(&exchArgSt, DBA_GetConnectNoFromHier(posHierHead));*/ /* REF2580 - SSO - 980727 */
		DBA_InitConnectNoToExchArg(&exchArgSt, posHierHead); /* REF4213 - SSO - 991221 */

   	    FIN_GetExchRate(GET_DATETIME(origPos, ExtPos_ExtPosDate),
		                GET_ID(origPos, ExtPos_PosCurrId),
				        GET_ID(origPos, ExtPos_RefCurrId),
			            (ID_T)0, NULL, origPos, &exchArgSt, &exch);  /* PMSTA01649 - TGU - 070402 */
	}
	else
	{
		exch = 1.0;
	}

	/* Developer Information Not Obsolete Serious And Useful Recommendation � DINOSAUR � KPV � 110831 */
	/* Compute ratios */

    /* DVP003 : New application parameter (96/02/27) */
	switch (fundSplitCalcRule)
	{
	case FundSplitCalcRule_RatioOfValues :
		if (fundVal != 0)
		{
			ratio = (GET_PRICE(extVal,PosVal_Price) * exch * GET_NUMBER(origPos,ExtPos_Qty)) / fundVal;
			ratioWithoutExch = (GET_PRICE(extVal,PosVal_Price) * GET_NUMBER(origPos,ExtPos_Qty)) / fundVal; /* REF9991 - RAK - 040316 */
		}
		else
		{
			ratio = 0.0;
			ratioWithoutExch = 0.0;		/* REF9991 - RAK - 040316 */
		    /*(GET_PERCENT(fundPtr, A_FundWgt_WgtPrct) / 100.0)) / fundVal;*/
		}
		break;

	case FundSplitCalcRule_NbrOfIssuedShares :
		/* DVP239 - A_FundWgt_WgtPrct or  nbrOfShares can be 0 */
		/* DVP402 - 970325 - XDI */
		if (nbrOfShares != 0.0)
		{
		    /* Select all fundWeight with same Portfolio */
		    if ((admArgPtr = ALLOC_DYNST(Adm_Arg)) == NULL)
		    {
		        FREE(fundPos);
		        MSG_RETURN(RET_MEM_ERR_ALLOC);
            }

		    COPY_DYNFLD(admArgPtr, Adm_Arg, Adm_Arg_Id,
				        fundPtr, A_FundWgt, A_FundWgt_PtfId);
		    COPY_DYNFLD(admArgPtr, Adm_Arg, Adm_Arg_Date,
                        domainPtr, A_Domain, A_Domain_InterpFromDate);

            if ((DBA_Select2(FundWgt, UNUSED, Adm_Arg, admArgPtr,
                             A_FundWgt, &fundWgtTab, UNUSED, UNUSED,
                             &fundWgtNbr, UNUSED, UNUSED)) != RET_SUCCEED)
            {
		        FREE_DYNST(admArgPtr, Adm_Arg);
		        FREE(fundPos);
		        MSG_RETURN(RET_MEM_ERR_ALLOC);
            }

		    FREE_DYNST(admArgPtr, Adm_Arg);

		    /* Compute ratio using all loaded Fund weight */
		    if ((pricePtr = ALLOC_DYNST(A_InstrPrice)) == NULL)
		    {
		        FREE(fundPos);
		        DBA_FreeDynStTab(fundWgtTab, fundWgtNbr, A_FundWgt);
		        MSG_RETURN(RET_MEM_ERR_ALLOC);
                    }

		    if ((chronoPtr = ALLOC_DYNST(A_InstrChrono)) == NULL)
		    {
		        FREE(fundPos);
		        DBA_FreeDynStTab(fundWgtTab, fundWgtNbr, A_FundWgt);
		        FREE_DYNST(pricePtr, A_InstrPrice);
			    MSG_RETURN(RET_MEM_ERR_ALLOC);
            }

	        if ((dimChronoPtr = ALLOC_DYNST(Dim_InstrChrono)) == NULL)
	        {
		    	FREE_DYNST(chronoPtr, A_InstrChrono);
		        FREE(fundPos);
		        DBA_FreeDynStTab(fundWgtTab, fundWgtNbr, A_FundWgt);
		        FREE_DYNST(pricePtr, A_InstrPrice);
		        MSG_RETURN(RET_MEM_ERR_ALLOC);
	    	}

	    	SET_ENUM(dimChronoPtr,     Dim_InstrChrono_NatEn,      ChronoNat_NbrShares);
	    	SET_FLAG(dimChronoPtr,     Dim_InstrChrono_ComputeFlg, FALSE);
	    	SET_DATETIME(dimChronoPtr, Dim_InstrChrono_RefDate,
		    GET_DATETIME(domainPtr, A_Domain_InterpFromDate));

		    denom = 0.0;
		    for (i=0; i<fundWgtNbr; i++)
		    {
			    if (CMP_DYNFLD(origInstr, fundWgtTab[i],
                                       A_Instr_Id, A_FundWgt_InstrId, IdType) != 0)
			    {
			        FIN_InstrPrice(GET_ID(fundWgtTab[i], A_FundWgt_InstrId), NULL,
                        		   GET_DATETIME(domainPtr, A_Domain_InterpFromDate),
                        		   NULL, (ID_T)0, NULL, NULL, NULL,
                        		   posHierHead, pricePtr, FALSE); /* PMSTA14876 - DDV - 120911 - Add a new parameter, no impact for this call */
			    }
			    else
			    {
			        COPY_DYNFLD(pricePtr, A_InstrPrice, A_InstrPrice_Price,
                                        extVal, PosVal, PosVal_Price);
			    }

			    COPY_DYNFLD(dimChronoPtr, Dim_InstrChrono, Dim_InstrChrono_InstrId,
                            fundWgtTab[i], A_FundWgt, A_FundWgt_InstrId);

	    	    if ((ret = FIN_InstrChrono(dimChronoPtr, NULL, chronoPtr,
                                           posHierHead)) != RET_SUCCEED)
	            {
					DBA_DYNFLD_STP	msgInstrPtr=NULL;
					FLAG_T			msgInstrAllocFlg=FALSE;

		            /* REF9030 - RAK - 031022 - Don't return RET_MEM_ERR_ALLOC */
					/* MSG_RETURN(RET_MEM_ERR_ALLOC); */

					/* REF9030 - RAK - 031022 - if get of instrument succeed */
					/* display message (99,99% of the cases) elsewhere don't display it */
					if (DBA_GetInstrById(GET_ID(fundWgtTab[i], A_FundWgt_InstrId), FALSE, &msgInstrAllocFlg,
                                    &msgInstrPtr, posHierHead, UNUSED, UNUSED) == RET_SUCCEED)
					{
						MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, "FIN_FundSplittingCalcRule",
				                     GET_CODE(msgInstrPtr, A_Instr_Cd), "number of shares");
						if (msgInstrAllocFlg == TRUE) {FREE_DYNST(msgInstrPtr, A_Instr);}
					}

					FREE_DYNST(chronoPtr, A_InstrChrono);
		            FREE(fundPos);
		            DBA_FreeDynStTab(fundWgtTab, fundWgtNbr, A_FundWgt);
		            FREE_DYNST(pricePtr, A_InstrPrice);
	    	        FREE_DYNST(dimChronoPtr, Dim_InstrChrono);
					return(ret);
	    	    }

			    denom += GET_LONGAMOUNT(chronoPtr, A_InstrChrono_Val) *
				         GET_PRICE(pricePtr, A_InstrPrice_Price); /* REF11704 - TGU - 060419 - Change datatype */
		    }

	    	FREE_DYNST(dimChronoPtr, Dim_InstrChrono);
		    FREE_DYNST(chronoPtr, A_InstrChrono);
		    FREE_DYNST(pricePtr, A_InstrPrice);
		    DBA_FreeDynStTab(fundWgtTab, fundWgtNbr, A_FundWgt);

		    if (denom != 0)
		        ratio = (GET_NUMBER(origPos, ExtPos_Qty) *
                         GET_PRICE(extVal, PosVal_Price))  / denom;
		    else
		        ratio = 0.0;
		}
		else
		{
		    ratio = GET_NUMBER(origPos, ExtPos_Qty);
		}

		ratioWithoutExch = ratio;	/* REF9991 - RAK - 040317 */

		break;

	/* REF9030 - RAK - 030429 - New calculation method */
	case FundSplitCalcRule_NAV :
		if (netAssetVal != 0)
		{
			ratio = (GET_PRICE(extVal,PosVal_Price) * exch * GET_NUMBER(origPos,ExtPos_Qty)) / netAssetVal;
			ratioWithoutExch = (GET_PRICE(extVal,PosVal_Price) * GET_NUMBER(origPos,ExtPos_Qty)) / netAssetVal;	/* REF9991 - RAK - 040317 */
		}
		else
		{
			ratio = 0.0;
			ratioWithoutExch = 0.0;		/* REF9991 - RAK - 040317 */
		}
		break;
	}

	/* Developer Information Not Obsolete Serious And Useful Recommendation � DINOSAUR � KPV � 110831 */
	/* Apply ratios on fund positions and put them in current valuation/hierarchy */
	for (i=0; i<posNbr; i++)
	{
		if ((pos = ALLOC_DYNST(ExtPos)) == NULL)
		{
			FREE(fundPos);
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		COPY_DYNST(pos, fundPos[i], ExtPos);

		/* REF11014 - RAK - 050308 - Update generated position reference currency */
		if (GET_ID(origPos, ExtPos_PosCurrId) != GET_ID(origPos, ExtPos_RefCurrId))
		{
			SET_ID(pos, ExtPos_RefCurrId, GET_ID(origPos, ExtPos_RefCurrId));

			/* REF11014 - RAK - 050308 - Update exchange rates */
			tmp = GET_EXCHANGE(pos, ExtPos_PosExchRate) * exch;
			SET_EXCHANGE(pos, ExtPos_PosExchRate, tmp);

			tmp = GET_EXCHANGE(pos, ExtPos_InstrExchRate) * exch;
			SET_EXCHANGE(pos, ExtPos_InstrExchRate, tmp);

			tmp = GET_EXCHANGE(pos, ExtPos_SysExchRate) * exch;
			SET_EXCHANGE(pos, ExtPos_SysExchRate, tmp);
		}

		SET_FLAG(pos, ExtPos_AcctFlg, FALSE);
		/* SET_ENUM(pos, ExtPos_FundSplitNatEn, FundSplitNat_Split); */ /* BUG175 */
		/* REF3931 - SSO - 990924 : UNcommented out */

        /* REF5746 - RAK - 010404 */
        /* If fund position is splitted (because it's a fund share too), keep the information */
        if (GET_ENUM(pos, ExtPos_FundSplitNatEn) != FundSplitNat_Splitted)
        { SET_ENUM(pos, ExtPos_FundSplitNatEn, FundSplitNat_Split); }

		SET_DATETIME(pos, ExtPos_ExtPosDate, GET_DATETIME(origPos, ExtPos_ExtPosDate));
		SET_DATETIME(pos, ExtPos_BegDate,    GET_DATETIME(origPos, ExtPos_BegDate));
		SET_DATETIME(pos, ExtPos_EndDate,    GET_DATETIME(origPos, ExtPos_EndDate));
		SET_DATETIME(pos, ExtPos_OpDate,     GET_DATETIME(origPos, ExtPos_OpDate));
		SET_DATETIME(pos, ExtPos_AcctDate,   GET_DATETIME(origPos, ExtPos_AcctDate));
		SET_DATETIME(pos, ExtPos_ExpirDate,  GET_DATETIME(origPos, ExtPos_ExpirDate));

		SET_DATETIME(pos, ExtPos_OrderLimitDate,
		    GET_DATETIME(origPos, ExtPos_OrderLimitDate));

		/* REF2562 - SSO - 980723: modified computing with ratio */

	    tmp = GET_NUMBER(pos, ExtPos_Qty) * ratioWithoutExch;	  /* REF9991 - RAK - 040317 */
	    SET_NUMBER(pos, ExtPos_Qty, tmp);

		/* REF11014 - RAK - 050308 - Aren't in reference currency - so use ratioWithoutExch */
	    tmp = GET_AMOUNT(pos, ExtPos_SupplAmt) * ratioWithoutExch;
		SET_AMOUNT(pos, ExtPos_SupplAmt, tmp);

	    tmp = GET_AMOUNT(pos, ExtPos_PosGrossAmt) * ratioWithoutExch;
		SET_AMOUNT(pos, ExtPos_PosGrossAmt, tmp);

	    tmp = GET_AMOUNT(pos, ExtPos_PosNetAmt) * ratioWithoutExch;
		SET_AMOUNT(pos, ExtPos_PosNetAmt, tmp);

	    tmp = GET_AMOUNT(pos, ExtPos_InstrGrossAmt) * ratioWithoutExch;
		SET_AMOUNT(pos, ExtPos_InstrGrossAmt, tmp);

		tmp = GET_AMOUNT(pos, ExtPos_InstrNetAmt) * ratioWithoutExch;
		SET_AMOUNT(pos, ExtPos_InstrNetAmt, tmp);

		ep_TotSysGrossAmt += GET_AMOUNT(pos, ExtPos_SysGrossAmt);  /* compute total amount (valo of the fund) */
		if (i != posNbr-1 || fundSplitCalcRule == FundSplitCalcRule_NAV)	/* REF9030 - RAK - 030429 - For NAV don't compute the last with remainder */
		{
		    tmp = GET_AMOUNT(pos, ExtPos_SysGrossAmt) * ratioWithoutExch;
		    ep_RatTotSysGrossAmt += tmp;  /* compute total (with ratio) */
		}
		else
		{
		    tmp = (ep_TotSysGrossAmt * ratioWithoutExch) - ep_RatTotSysGrossAmt; /* if last record, use the remainder amount */
		}
		SET_AMOUNT(pos, ExtPos_SysGrossAmt, tmp);

		ep_TotSysNetAmt += GET_AMOUNT(pos, ExtPos_SysNetAmt);
		if (i != posNbr-1 || fundSplitCalcRule == FundSplitCalcRule_NAV)	/* REF9030 - RAK - 030429 - For NAV don't compute the last with remainder */
		{
		    tmp = GET_AMOUNT(pos, ExtPos_SysNetAmt) * ratioWithoutExch;
		    ep_RatTotSysNetAmt += tmp;
		}
		else
		{
		    tmp = (ep_TotSysNetAmt * ratioWithoutExch) - ep_RatTotSysNetAmt;
		}
		SET_AMOUNT(pos, ExtPos_SysNetAmt, tmp);

		ep_TotRefGrossAmt += GET_AMOUNT(pos, ExtPos_RefGrossAmt);
		if (i != posNbr-1 || fundSplitCalcRule == FundSplitCalcRule_NAV)	/* REF9030 - RAK - 030429 - For NAV don't compute the last with remainder */
		{
		    tmp = GET_AMOUNT(pos, ExtPos_RefGrossAmt) * ratio;
		    ep_RatTotRefGrossAmt += tmp;
		}
		else
		{
		    tmp = (ep_TotRefGrossAmt * ratio) - ep_RatTotRefGrossAmt;
		}
		SET_AMOUNT(pos, ExtPos_RefGrossAmt, tmp);

		ep_TotRefNetAmt += GET_AMOUNT(pos, ExtPos_RefNetAmt);
		if (i != posNbr-1 || fundSplitCalcRule == FundSplitCalcRule_NAV)	/* REF9030 - RAK - 030429 - For NAV don't compute the last with remainder */
		{
		    tmp = GET_AMOUNT(pos, ExtPos_RefNetAmt) * ratio;
		    ep_RatTotRefNetAmt += tmp;
		}
		else
		{
		    tmp = (ep_TotRefNetAmt * ratio) - ep_RatTotRefNetAmt;
		}
		tmpAmt = CAST_AMOUNT(tmp, GET_ID(pos, ExtPos_PosCurrId)); /* PMSTA-18064 - 060614 */ /* PMSTA-42605 - DDV - 200114 */
		SET_AMOUNT(pos, ExtPos_RefNetAmt, tmpAmt);

		for (bpAmtFld = ExtPos_Bp1PosAmt;
	             bpAmtFld < (ExtPos_Bp1PosAmt+ExtPos_BpPosAmtNb); bpAmtFld++)
		{
		    tmp = GET_AMOUNT(pos, bpAmtFld) * ratio;
		    SET_AMOUNT(pos, bpAmtFld, tmp);
		}

		/* BUG154 */
		addOk = FALSE;

		/* generated instr have a new identifier in other hierarchy */
		if (GET_ID(pos, ExtPos_InstrId) < 0)
		{
			dbFlg = FALSE;
			addOk = TRUE;
		}
		/* search fund hierarchy instrument in origin hierarchy */
		else if ((newInstr =
			  DBA_SearchHierRecById(posHierHead, A_Instr, A_Instr_Id,
						            GET_ID(pos, ExtPos_InstrId))) == NULL)
		{
			dbFlg = TRUE;
			addOk = TRUE;
		}

		/* Add database instrument (not already in origin hierarchy) */
		if (addOk == TRUE)
		{
		    if ((newInstr = ALLOC_DYNST(A_Instr)) == NULL)
		    {
			    FREE(fundPos);
			    return(ret);
		    }

		    if (GET_EXTENSION_PTR(fundPos[i],ExtPos_A_Instr_Ext) != NULL)
		    	COPY_DYNST(newInstr,
			       *(GET_EXTENSION_PTR(fundPos[i],ExtPos_A_Instr_Ext)), A_Instr);

		    if (dbFlg == FALSE)
			SET_NULL_ID(newInstr, A_Instr_Id);

		    /* REF3357 - RAK - 990223 */
		    /* Don't try to do link (A_Instr_Compo_A_Instr_Ext, A_Instr_Cond_A_Instr_Ext) */
		    /* In fact we found a problem in function DBA_SelAllInterestCond..            */
		    /* which don't found InterCond (which exist)                                  */
		    if ((ret = DBA_AddHierRecord(posHierHead, newInstr,
				                         A_Instr, dbFlg, HierAddRec_NoLnk)) != RET_SUCCEED)
		    {
			    FREE(fundPos);
			    FREE_DYNST(newInstr, A_Instr);
			    return(ret);
		    }
		    SET_ID(pos, ExtPos_InstrId, GET_ID(newInstr, A_Instr_Id));
		}

		if ((val = ALLOC_DYNST(PosVal)) == NULL)
		{
			FREE(fundPos);
			return(ret);
		}

		/* Add valorisation extension in origin hierarchy */
		if (GET_EXTENSION_PTR(fundPos[i], ExtPos_PosVal_Ext) != NULL)
		{
			COPY_DYNST(val, *(GET_EXTENSION_PTR(fundPos[i], ExtPos_PosVal_Ext)), PosVal);
		}

		SET_NULL_ID(val, PosVal_Id);

		/* REF11014 - RAK - 050308 - Aren't in reference currency - so use ratioWithoutExch */
		tmp = GET_AMOUNT(val, PosVal_PosMktValAmt) * ratioWithoutExch;
        tmpAmt = CAST_AMOUNT(tmp, GET_ID(pos, ExtPos_PosCurrId)); /* PMSTA-42605 - DDV - 200114 */
        SET_AMOUNT(val, PosVal_PosMktValAmt, tmpAmt);

		tmp = GET_AMOUNT(val, PosVal_PosAccrInterAmt) * ratioWithoutExch;
        tmpAmt = CAST_AMOUNT(tmp, GET_ID(pos, ExtPos_PosCurrId)); /* PMSTA-42605 - DDV - 200114 */
        SET_AMOUNT(val, PosVal_PosAccrInterAmt, tmpAmt);

		tmp = GET_AMOUNT(val, PosVal_PosNetAmt) * ratioWithoutExch;
        tmpAmt = CAST_AMOUNT(tmp, GET_ID(pos, ExtPos_PosCurrId)); /* PMSTA-42605 - DDV - 200114 */
        SET_AMOUNT(val, PosVal_PosNetAmt, tmpAmt);

		pv_TotRefMktValAmt += GET_AMOUNT(val, PosVal_RefMktValAmt);
		if (i != posNbr-1 || fundSplitCalcRule == FundSplitCalcRule_NAV)	/* REF9030 - RAK - 030429 - For NAV don't compute the last by difference */
		{
		    tmp = GET_AMOUNT(val, PosVal_RefMktValAmt) * ratio;
		    pv_RatTotRefMktValAmt += tmp;
		}
        else
		{
		    tmp = (pv_TotRefMktValAmt * ratio) - pv_RatTotRefMktValAmt;
		}

		tmpAmt = CAST_AMOUNT(tmp, GET_ID(pos, ExtPos_RefCurrId)); /* PMSTA-18064 - 060614 */ /* PMSTA-42605 - DDV - 200114 */
		SET_AMOUNT(val, PosVal_RefMktValAmt, tmpAmt);

		pv_TotRefAccrInterAmt += GET_AMOUNT(val, PosVal_RefAccrInterAmt);
		if (i != posNbr-1 || fundSplitCalcRule == FundSplitCalcRule_NAV)	/* REF9030 - RAK - 030429 - For NAV don't compute the last by difference */
		{
		    tmp = GET_AMOUNT(val, PosVal_RefAccrInterAmt) * ratio;
		    pv_RatTotRefAccrInterAmt += tmp;
		}
        else
		{
		    tmp = (pv_TotRefAccrInterAmt * ratio) - pv_RatTotRefAccrInterAmt;
		}
		tmpAmt = CAST_AMOUNT(tmp, GET_ID(pos, ExtPos_RefCurrId)); /* PMSTA-18064 - 060614 */ /* PMSTA-42605 - DDV - 200114 */
		SET_AMOUNT(val, PosVal_RefAccrInterAmt, tmpAmt);

		pv_TotRefNetAmt += GET_AMOUNT(val, PosVal_RefNetAmt);
		if (i != posNbr-1 || fundSplitCalcRule == FundSplitCalcRule_NAV)	/* REF9030 - RAK - 030429 - For NAV don't compute the last by difference */
		{
		    tmp = GET_AMOUNT(val, PosVal_RefNetAmt) * ratio;
		    pv_RatTotRefNetAmt += tmp;
		}
        else
		{
		    tmp = (pv_TotRefNetAmt * ratio) - pv_RatTotRefNetAmt;
		}
		tmpAmt = CAST_AMOUNT(tmp, GET_ID(pos, ExtPos_RefCurrId));  /* PMSTA-42605 - DDV - 200114 */
		SET_AMOUNT(val, PosVal_RefNetAmt, tmpAmt);

		/* REF11014 - RAK - 050308 - Aren't in reference currency - so use ratioWithoutExch */
		tmp = GET_AMOUNT(val, PosVal_InstrMktValAmt) * ratioWithoutExch;
        tmpAmt = CAST_AMOUNT(tmp, GET_ID(pos, ExtPos_InstrCurrId)); /* PMSTA-42605 - DDV - 200114 */
        SET_AMOUNT(val, PosVal_InstrMktValAmt, tmpAmt);

		tmp = GET_AMOUNT(val, PosVal_InstrAccrInterAmt) * ratioWithoutExch;
        tmpAmt = CAST_AMOUNT(tmp, GET_ID(pos, ExtPos_InstrCurrId)); /* PMSTA-42605 - DDV - 200114 */
        SET_AMOUNT(val, PosVal_InstrAccrInterAmt, tmpAmt);

		tmp = GET_AMOUNT(val, PosVal_InstrNetAmt) * ratioWithoutExch;
        tmpAmt = CAST_AMOUNT(tmp, GET_ID(pos, ExtPos_InstrCurrId)); /* PMSTA-42605 - DDV - 200114 */
        SET_AMOUNT(val, PosVal_InstrNetAmt, tmpAmt);

		/* REF11014 - RAK - 050308 - Update generated position reference currency */
		if (GET_ID(origPos, ExtPos_PosCurrId) != GET_ID(origPos, ExtPos_RefCurrId))
		{
			EXCHANGE_T		valExch=1.0;
			FIN_EXCHARG_ST  valExchArgSt;
			memset(&valExchArgSt, 0, sizeof(FIN_EXCHARG_ST));
			DBA_InitConnectNoToExchArg(&valExchArgSt, posHierHead);

   			FIN_GetExchRate(GET_DATETIME(domainPtr, A_Domain_CalcRefDate),
		                GET_ID(origPos, ExtPos_PosCurrId),
				        GET_ID(origPos, ExtPos_RefCurrId),
			            (ID_T)0, NULL, origPos, &valExchArgSt, &valExch);    /* PMSTA01649 - TGU - 070402 */

			/* REF11014 - RAK - 050308 - Update exchange rates */
			tmp = GET_EXCHANGE(val, PosVal_PriceExchRate) * valExch;
			SET_EXCHANGE(val, PosVal_PriceExchRate, tmp);

			tmp = GET_EXCHANGE(val, PosVal_PosExchRate) * valExch;
			SET_EXCHANGE(val, PosVal_PosExchRate, tmp);

			tmp = GET_EXCHANGE(val, PosVal_InstrExchRate) * valExch;
			SET_EXCHANGE(val, PosVal_InstrExchRate, tmp);
		}

		if ((ret = DBA_AddHierRecord(posHierHead, val, PosVal,
					                 FALSE, HierAddRec_TestMandatLnk)) != RET_SUCCEED)
		{
			FREE(fundPos);
			FREE_DYNST(val, PosVal);
			return(ret);
		}

		SET_ID(pos, ExtPos_PosValId, GET_ID(val, PosVal_Id));

		/* Set reference on original portfolio */
		SET_ID(pos, ExtPos_PtfId, GET_ID(origPos, ExtPos_PtfId));

		/* BUG135 */
	    SET_ID(pos, ExtPos_RiskOriginExtPosId, GET_ID(origPos, ExtPos_Id));
	    SET_ID(pos, ExtPos_RiskParInstrId,     GET_ID(origPos, ExtPos_InstrId));

		SET_NULL_ID(pos, ExtPos_MainExtPosId);
		SET_NULL_ID(pos, ExtPos_AcctExtPosId);
		SET_NULL_ID(pos, ExtPos_AdjustExtPosId);
		SET_NULL_ID(pos, ExtPos_Id);

	    if ((ret = DBA_AddHierRecord(posHierHead, pos, ExtPos,
					                 FALSE, HierAddRec_TestMandatLnk)) != RET_SUCCEED)
	    {
			FREE(fundPos);
			return(ret);
		}

        /* REF7661 - YST - 020725 - set fund split nature to None for following extended position */
		/* PMSTA-13140 - LJE - 120319 */
		FIN_GetAccFlag(domainPtr,
	     			   pos,
					   &futAccFlg,
					   &fwdAccFlg,
					   &termAccFlg);

        if ((fwdAccFlg == TRUE || futAccFlg == TRUE) &&
            (FUNDSPLITRULE_ENUM)GET_ENUM(domainPtr, A_Domain_FundSplitRuleEn) ==  FundSplitRule_Split &&
            (FUNDSPLITNAT_ENUM)GET_ENUM(pos, ExtPos_FundSplitNatEn) == FundSplitNat_Split &&
            (EXTPOSRISKNAT_ENUM)GET_ENUM(pos, ExtPos_RiskNatEn) == ExtPosRisk_NoRisk &&
            GET_FLAG(pos, ExtPos_AcctFlg) != TRUE)
        {
            /* ExtPos_MainExtPosId is set in last call DBA_AddHierRecord() some lines above */
            if (IS_NULLFLD(pos, ExtPos_MainExtPosId) != TRUE && GET_ID(pos, ExtPos_MainExtPosId) != 0)
            {
                DBA_DYNFLD_STP  mainExtPos = NULL, instrPtr = NULL;
                FLAG_T          allocOkFlg = FALSE;

                if (DBA_GetRecPtrFromHierById(posHierHead, GET_ID(pos, ExtPos_MainExtPosId),
		                                ExtPos, &mainExtPos) == RET_SUCCEED && mainExtPos != NULL)
                {
                    if (DBA_GetInstrById(GET_ID(mainExtPos, ExtPos_InstrId), FALSE, &allocOkFlg, &instrPtr,
                                        posHierHead, UNUSED, UNUSED) == RET_SUCCEED && instrPtr != NULL)
		            {
		                if ((futAccFlg == TRUE && InstrNat_Future == (INSTRNAT_ENUM)GET_ENUM(instrPtr, A_Instr_NatEn)) ||
                            (fwdAccFlg == TRUE && InstrNat_Forward == (INSTRNAT_ENUM)GET_ENUM(instrPtr, A_Instr_NatEn)))
                        {
		                    SET_ENUM(pos, ExtPos_FundSplitNatEn, FundSplitNat_None);
                        }
                    }
                    if (allocOkFlg == TRUE) {FREE_DYNST(instrPtr, A_Instr);}
                }
            }
        }
      /* PMSTA-49329 - BSV - 220523 */
	  /* Automator Case :Valuation\LGE_VALO_FUND_SPLITTING_03 */
      if (GET_EXTENSION_PTR(pos, ExtPos_PosVal_Ext) == NULL ||
			(valo = *(GET_EXTENSION_PTR(pos, ExtPos_PosVal_Ext))) == NULLDYNST)
		{

			/* REF5442 - DDV - 010205 - Make links between manually (PosVal->ExtPos and ExtPos->PosVal) */
			if ((newExtTab = (DBA_DYNFLD_STP*)
				CALLOC(sizeof(DBA_DYNFLD_STP), 1)) == NULL)
				MSG_RETURN(RET_MEM_ERR_ALLOC);

			newExtTab[0] = val;

			SET_HIER_EXTENSION(pos, ExtPos_PosVal_Ext, newExtTab, PosVal, 1);
		}
		if (GET_EXTENSION_PTR(val, PosVal_ExtPos_Ext) == NULL ||
			(valo = *(GET_EXTENSION_PTR(val, PosVal_ExtPos_Ext))) == NULLDYNST)
		{
			if ((newExtTab = (DBA_DYNFLD_STP*)
				CALLOC(sizeof(DBA_DYNFLD_STP), 1)) == NULL)
				MSG_RETURN(RET_MEM_ERR_ALLOC);

			newExtTab[0] = pos;

			SET_HIER_EXTENSION(val, PosVal_ExtPos_Ext, newExtTab, ExtPos, 1);
			COPY_DYNFLD(val, PosVal, PosVal_ExtPosId, pos, ExtPos, ExtPos_Id);
		}
	}

	/* BUG135 - Cash positions are insert at the end */
	if (posNbr > 0)
	    DBA_MakeSpecRecLinks(posHierHead, ExtPos, ExtPos_Acct_ExtPos_Ext);

	/* Developer Information Not Obsolete Serious And Useful Recommendation � DINOSAUR � KPV � 110831 */
	SET_ENUM(origPos, ExtPos_FundSplitNatEn, FundSplitNat_Splitted);	/* splitted */

	FREE(fundPos);
    DBA_FreeHier(fundHierHead);
	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_FundSplittingComposit()
**
**  Description :
**
**  Arguments   :   posHierHead    extended position hierarchy header
**                  domainPtr      pointer on domain structure
**                  domainArgPtr   pointer on some domain informations
**                  origPos        initial position pointer
**		            totPosRisk	   pointer on total risk structure
**		            riskQtyStp	   pointer on risk quantity informations
**
**  Return      :   RET_SUCCEED, RET_GEN_INFO_NOACTION or error code
**
**  Creation    :   BUG175 - RAK - 961010
**  Modif.      :   DVP510 - RAK - 970618
**  Modif.      :   REF524 - RAK - 971014
**  Modif.	    :   REF1457 - RAK - 980324
**  Modif.      :   REF5652 - RAK - 010228
**
*************************************************************************/
STATIC RET_CODE FIN_FundSplittingComposit(DBA_HIER_HEAD_STP    posHierHead,
				                            DBA_DYNFLD_STP     domainPtr,
				                            FIN_DOMAIN_ARG_STP domainArgPtr,
					                        FIN_AIARG_STP	   aiArgPtr,
                                            DBA_DYNFLD_STP     origPos,
				                            DBA_DYNFLD_STP     totPosRisk,
					                        RISK_QTY_STP       riskQtyStp)
{
	DBA_DYNFLD_STP      instrPtr=NULL, *compoTab=NULL,
			            riskInstrPtr=NULL, valo=NULL, newInstrPtr=NULL,
			            newFundPos=NULL;
	char                instrHierFlg;
	int                 i, compoNbr;
	RISK_QTY_ST	        compoQtySt;
	RISK_ANALYSIS_ENUM  status;
    FIN_FUNDRISK_ENUM   svdFundRiskEn;          /* REF5652 - RAK - 010228 */
	RET_CODE            ret;

	/* REF3030 */
	FIN_PRICEARG_ST	  priceArgSt;
	memset(&priceArgSt, 0, sizeof(FIN_PRICEARG_ST));
	memset(&compoQtySt, 0, sizeof(RISK_QTY_ST)); /* PMSTA-34140 - RAK - 190122 - Avoid wrong init of all fields */

	if (posHierHead == (DBA_HIER_HEAD_STP)NULL)
	{
	    MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
		             "FIN_FundSplittingComposit", "posHierHead");
		return(RET_GEN_ERR_INVARG);
	}

	if (origPos == NULL)
	{
	    MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
		             "FIN_FundSplittingComposit", "position");
		return(RET_GEN_ERR_INVARG);
	}

	if (GET_EXTENSION_PTR(origPos, ExtPos_A_Instr_Ext) == NULL ||
	    (instrPtr = *(GET_EXTENSION_PTR(origPos, ExtPos_A_Instr_Ext))) == NULL)
	{
	    MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
		             "FIN_FundSplittingComposit", "position without instrument");
		return(RET_GEN_ERR_INVARG);
	}

	ret = DBA_SelectInstrCompo(GET_ID(instrPtr, A_Instr_Id),
                               domainArgPtr->fromDateTime,
				               &compoTab, &compoNbr);

	if (ret == RET_SUCCEED && compoNbr > 0)
	{
	    compoQtySt.idxCalcRuleEn = (IDXCALCRULE_ENUM)GET_ENUM(instrPtr, A_Instr_IdxCalcRuleEn);
	    compoQtySt.qty           = 0.0;
	    compoQtySt.price         = 0.0;
	    compoQtySt.priceCurrId   = (ID_T)0;
	    compoQtySt.pricePtr      = NULL;

	    if (compoNbr > 0)  /* treat composite instrument */
	    {
		    /* Read father price and currency */
		    if (compoQtySt.idxCalcRuleEn == IdxCalcRule_PctValue)
		    {
		        valo = NULL;
		        if (GET_EXTENSION_PTR(origPos, ExtPos_PosVal_Ext) != NULL &&
	                (valo = *(GET_EXTENSION_PTR(origPos, ExtPos_PosVal_Ext))) != NULL)
		        {
			    compoQtySt.priceCurrId = GET_ID(valo, PosVal_PriceCurrId);
			    compoQtySt.price       = GET_PRICE(valo, PosVal_Price);
		        }

		        if ((compoQtySt.pricePtr = ALLOC_DYNST(A_InstrPrice)) == NULL)
		        {
		   	        for(i=0; i<compoNbr; i++)
			            FREE_DYNST(compoTab[i], A_InstrCompo);
		   	        FREE(compoTab);
			        MSG_RETURN(RET_MEM_ERR_ALLOC);
		        }
		    }

		    for (i=0; i<compoNbr; i++)
		    {
		        if (compoQtySt.idxCalcRuleEn == IdxCalcRule_PctValue)
		        {
			        /* qty = (father's qty * father's price * compo qty) / son's price */
			        compoQtySt.qty = (riskQtyStp->qty * compoQtySt.price *
					                 GET_NUMBER(compoTab[i], A_InstrCompo_Quantity));
		        }
		        else
		        {
			        /* qty = father's qty * compo qty */
			        compoQtySt.qty = riskQtyStp->qty *
					                 GET_NUMBER(compoTab[i], A_InstrCompo_Quantity);
		        }

		        status = Risk_Son;

		        /* Determine last son for difference */
		        if (i == compoNbr-1)
		        {
			        /* Composite instrument is valorised by its */
			        /* components, don't compute difference for last */
			        if (GET_ENUM(instrPtr, A_Instr_ValRuleEn) != ValRule_Composite &&
			            compoQtySt.idxCalcRuleEn != IdxCalcRule_PctValue)
			            status = Risk_LastSon;
		        }

		        SET_NUMBER(totPosRisk, RiskAmt_CompoQty,
		            GET_NUMBER(compoTab[i], A_InstrCompo_Quantity));

		        if ((ret = FIN_RiskGetInstrPtr(posHierHead, domainArgPtr->fromDateTime,
			                       GET_ID(compoTab[i], A_InstrCompo_InstrId),
			                       NULL, &newInstrPtr, &instrHierFlg)) != RET_SUCCEED)
		        {
		   	        for(i=0; i<compoNbr; i++)
			            FREE_DYNST(compoTab[i], A_InstrCompo);
		   	        FREE(compoTab);
			        return(ret);
		        }

		        newFundPos = NULL;

		        if ((ret = FIN_TreatCompoRisk(posHierHead, domainArgPtr, aiArgPtr,
                                              origPos, newInstrPtr, instrHierFlg, totPosRisk,
					                          &compoQtySt, &priceArgSt, status,
                                              &newFundPos)) != RET_SUCCEED)
		        {
		   	        for(i=0; i<compoNbr; i++)
			            FREE_DYNST(compoTab[i], A_InstrCompo);
		   	        FREE(compoTab);
			        return(ret);
		        }

		        /*** TREAT NEW POSITION ***/
                /* REF5652 - RAk - 010228 - Change only for current position */
                svdFundRiskEn = domainArgPtr->fundRiskEn;
                domainArgPtr->fundRiskEn = FinFundRisk_None;

				/* Developer Information Not Obsolete Serious And Useful Recommendation � DINOSAUR � KPV � 110831 */
				/* here we treat the Fund included in a fund */
		        if (GET_ENUM(domainPtr, A_Domain_FundSplitRuleEn) != FundSplitRule_None &&
		            GET_SMALLINT(domainPtr, A_Domain_FundSplitLevel) != FUNDSPLIT_MAXLEVEL)
		        {
			        /* REF524 - Call FIN_FundSplittingTreat() */
			        ret = FIN_FundSplittingTreat(domainPtr, domainArgPtr, aiArgPtr,
						                         posHierHead, newFundPos);

			        if (RET_GET_LEVEL(ret) == RET_LEV_ERROR &&
	               	    RET_GET_CATEG(ret) == RET_CATEG_MEM)
			        {
		   	            for(i=0; i<compoNbr; i++)
			                FREE_DYNST(compoTab[i], A_InstrCompo);
		   	            FREE(compoTab);

                        /* REF5652 - RAk - 010228 - Change only for current position */
                        domainArgPtr->fundRiskEn = svdFundRiskEn;
			            return(ret);
			        }
		        }

                /* REF5652 - RAK - 010228 - Add test on fundRiskEn like in */
                /* FIN_ValoProcess() elsewhere sub-funds are decomposed two times */
                if (GET_FLAG(domainPtr, A_Domain_RiskExpoFlg) == TRUE &&
                    domainArgPtr->fundRiskEn == FinFundRisk_None)
		        {
					/* PMSTA-10111 - RAK - 110311 - add domainPtr as arg */
			        domainArgPtr->riskDecompoLevel = 0;
			        ret = FIN_RiskAnalysis(posHierHead, domainPtr, domainArgPtr, aiArgPtr, newFundPos);

			        if (RET_GET_LEVEL(ret) == RET_LEV_ERROR &&
	               	    RET_GET_CATEG(ret) == RET_CATEG_MEM)
			        {
		   	            for(i=0; i<compoNbr; i++)
			                FREE_DYNST(compoTab[i], A_InstrCompo);
		   	            FREE(compoTab);

                        /* REF5652 - RAk - 010228 - Change only for current position */
                        domainArgPtr->fundRiskEn = svdFundRiskEn;
			            return(ret);
			        }
		        }

                /* REF5652 - RAk - 010228 - Change only for current position */
                domainArgPtr->fundRiskEn = svdFundRiskEn;
		    }

		    if (compoQtySt.pricePtr != NULL)
			    FREE_DYNST(compoQtySt.pricePtr, A_InstrPrice);

		    for(i=0; i<compoNbr; i++)
		        FREE_DYNST(compoTab[i], A_InstrCompo);
		    FREE(compoTab);

		    /* Suppress risk link and nature to parent (hybrid instrument) */
		    if (GET_EXTENSION_PTR(origPos, ExtPos_RiskPar_A_Instr_Ext) != NULL &&
	            (riskInstrPtr = *(GET_EXTENSION_PTR(origPos,
							      ExtPos_RiskPar_A_Instr_Ext))) != NULL)
		    {
		        /* DVP510 - RAK - 970618 */
		        INSTRNAT_ENUM instrNatEn = (INSTRNAT_ENUM)GET_ENUM(riskInstrPtr, A_Instr_NatEn);
	    	    if (instrNatEn == InstrNat_Option ||
			        instrNatEn == InstrNat_ExoticOptions ||
	    	        instrNatEn == InstrNat_SwapOptions )
		        {
			        SET_ENUM(origPos, ExtPos_RiskNatEn, ExtPosRisk_NoRisk);
			        SET_NULL_ID(origPos, ExtPos_RiskOriginExtPosId);
			        SET_NULL_ID(origPos, ExtPos_RiskParInstrId);
		        }
		    }
	    }
	    return(RET_SUCCEED);
	}
	else
	{
	    if (compoNbr == 0)
		    ret = RET_DBA_ERR_NODATA;
	    return(ret);
	}
}

/************************************************************************
**  Function             : FIN_FundSplittingTreat()
**
**  Description          : Treat position's instrument (test fundShare)
**
**  Arguments            : domainPtr    domain pointer
**                  	   domainArgPtr pointer on some domain informations
**                         posHierHead  hierarchy pointer
**                         origPos      position pointer
**
**  Return               : RET_SUCCEED, RET_GEN_INFO_NOACTION or error code
**
**  Creation		     : REF524 - 971013 - RAK : risk for fundShare without composition
**  Modif.		         : REF1457 - RAK - 980324
**
*************************************************************************/
RET_CODE FIN_FundSplittingTreat(DBA_DYNFLD_STP     domainPtr,
                                FIN_DOMAIN_ARG_STP domainArgPtr,
				                FIN_AIARG_STP	  aiArgPtr,
                                DBA_HIER_HEAD_STP  posHierHead,
		                        DBA_DYNFLD_STP     origPos)
{
	DBA_DYNFLD_STP	origInstr=NULL;
	RET_CODE	    ret=RET_SUCCEED;

	/* Developer Information Not Obsolete Serious And Useful Recommendation � DINOSAUR � KPV � 110831 */
	/* here the trouble start, in fact not really here this function just call FIN_FundSplitting() */
	/* not that in case of risk is asked, fund splitting is performed so in case of error in decomposition */
	/* the fund share position is just flagged to risk (the aim of the else) */

	/* Read instrument */
	if ((origInstr = *(GET_EXTENSION_PTR(origPos, ExtPos_A_Instr_Ext))) == NULL)
	{
		MSG_SendMesg(RET_DBA_ERR_HIER, 6, FILEINFO,
			         "FIN_FundSplittingTreat", ExtPos_A_Instr_Ext);
		return(RET_DBA_ERR_HIER);
	}

	/* Treat only fund share */
	if ((INSTRNAT_ENUM) GET_ENUM(origInstr, A_Instr_NatEn) != InstrNat_FundShare)
	{
		return(RET_GEN_INFO_NOACTION);
	}
	else
	{
		ret = FIN_FundSplitting(domainPtr, domainArgPtr, aiArgPtr,
					            posHierHead, origPos, origInstr);

		/* Do nothing in case of memory error */
		if (RET_GET_LEVEL(ret) == RET_LEV_ERROR &&
		    RET_GET_CATEG(ret) == RET_CATEG_MEM)
		{
			return(ret);
		}
		/* Set risk enum in case of fund share isn't splitted */
		else if (domainArgPtr->fundRiskEn == FinFundRisk_FundRisk &&
			     GET_ENUM(origPos, ExtPos_FundSplitNatEn) != (ENUM_T) FundSplitNat_Splitted)
		{
			SET_ENUM(origPos, ExtPos_RiskNatEn, ExtPosRisk_FinRisk);
		}
	}

	return(ret);
}


/************************************************************************
**
**  Function    :   FIN_RiskAnalysis()
**
**  Description :   Test risk flag and init risk computation
**
**  Arguments   :   posHierHead    extended position hierarchy header
**                  domainArgPtr   pointer on some domain informations
**                  origPos        initial position pointer
**
**  Return      :   RET_SUCCEED, RET_GEN_INFO_NOACTION or error code
**
**  Modif.      :   BUG034 - RAK - 960523
**  Modif.      :   DVP189 - RAK - 960902
**  Modif.	    :   REF1457 - RAK - 980324
**
*************************************************************************/
RET_CODE FIN_RiskAnalysis(DBA_HIER_HEAD_STP  posHierHead,
						  DBA_DYNFLD_STP	domainPtr,	/* PMSTA-10111 - RAK - 110311 - add domainPtr as arg */
				          FIN_DOMAIN_ARG_STP domainArgPtr,
				          FIN_AIARG_STP	    aiArgPtr,
                          DBA_DYNFLD_STP     origPos)
{
	DBA_DYNFLD_STP totPosRisk=NULL;
	DBA_DYNFLD_STP instrPtr=NULL;
	RET_CODE       ret;
	RISK_QTY_ST    riskQtySt;
	memset(&riskQtySt, 0, sizeof(RISK_QTY_ST)); /* PMSTA-34140 - RAK - 190122 - Avoid wrong init of all fields */

	/* init for PosRiskAnalysis call */
	if (GET_EXTENSION_PTR(origPos, ExtPos_A_Instr_Ext) != NULL)
		instrPtr = *(GET_EXTENSION_PTR(origPos, ExtPos_A_Instr_Ext));

	/* PMSTA-51476 - DDV - 230130 - No new risk position to create for forward having SubNat_FXFwd_TwoLegsAgainsPtfCurr as sub_nature, just flag pos as risk */
	if (instrPtr != NULLDYNST && GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_FXFwd_TwoLegsAgainsPtfCurr)
	{
        SET_ENUM(origPos, ExtPos_RiskNatEn, ExtPosRisk_FinRisk);
		/* WEALTH-6060 - Deepthi - Setting Risk Origin Position and Instrument ID
								   same as that of the original position */
		SET_ID(origPos, ExtPos_RiskOriginExtPosId, GET_ID(origPos, ExtPos_Id));
		SET_ID(origPos, ExtPos_RiskParInstrId, GET_ID(origPos, ExtPos_InstrId));
        return(RET_SUCCEED);
	}

	/* PMSTA-10111 - RAK - 110307 - Verify the EXPOSURE_LIST flag init in FIN_ComputePtfSynth() */
	/* updated only in case of Perf Analysis and for future/forward (for the moment) */
	if (GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_Return ||
		GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_OnLineMktValuePL ||
		GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_SynthAdmin)
	{
		/* fwd, future */
		if (instrPtr != NULL && GET_FLAG(instrPtr, A_Instr_NoPerfExpoFlg) == TRUE)
		{
			/* don't perform a risk decomposition just flag as risk */
			SET_ENUM(origPos, ExtPos_RiskNatEn, ExtPosRisk_FinRisk);
			return(RET_SUCCEED);
		}

		/* cash pos */
		if (instrPtr != NULL && GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_CashAcct &&
			GET_FLAG(origPos, ExtPos_MainFlg) == FALSE)
		{
			DBA_DYNFLD_STP mainInstrPtr=NULL, mainPos=NULL;

			/* get main position and instrument */
			if (GET_EXTENSION_PTR(origPos, ExtPos_Main_ExtPos_Ext) != NULL &&
				(mainPos = *(GET_EXTENSION_PTR(origPos, ExtPos_Main_ExtPos_Ext))) != NULL &&
				GET_EXTENSION_PTR(mainPos, ExtPos_A_Instr_Ext) != NULL &&
				(mainInstrPtr = *(GET_EXTENSION_PTR(mainPos, ExtPos_A_Instr_Ext))) != NULL &&
				GET_FLAG(mainInstrPtr, A_Instr_NoPerfExpoFlg) == TRUE)
			{
				/* don't perform a risk decomposition just flag as risk */
				SET_ENUM(origPos, ExtPos_RiskNatEn, ExtPosRisk_FinRisk);
				return(RET_SUCCEED);
			}
		}
	}

    /* PMSTA-20886 - DDV - 151027 - The instrument nature with Basket Options and Structured Options are excluded from risk split. */
	if (instrPtr != NULL &&
        (GET_FLAG(instrPtr, A_Instr_SubNatEn) == SubNat_BasketOption ||
         GET_FLAG(instrPtr, A_Instr_SubNatEn) == SubNat_StructuredOption
        )
       )
	{
		/* don't perform a risk decomposition just flag as risk */
		SET_ENUM(origPos, ExtPos_RiskNatEn, ExtPosRisk_FinRisk);
		return(RET_SUCCEED);
	}

    /* REF5416 - RAK - 010118 - new arg posHierHead */
	if ((totPosRisk = FIN_CreateRiskAmt(posHierHead, origPos, domainArgPtr->fromDateTime,
                                        domainArgPtr->refCurrId)) != NULL)
	{
		/* DVP189 */
		riskQtySt.idxCalcRuleEn = IdxCalcRule_None;
		riskQtySt.qty           = GET_NUMBER(origPos, ExtPos_Qty);
		riskQtySt.price         = 0.0;
		riskQtySt.priceCurrId   = (ID_T)0;
		riskQtySt.pricePtr      = NULL;

		ret = FIN_PosRiskAnalysis(posHierHead, domainPtr, domainArgPtr, aiArgPtr, origPos,
					              GET_ID(origPos, ExtPos_InstrId),
			                      instrPtr,
			                      totPosRisk, &riskQtySt, Risk_Father, FALSE);
		FREE_DYNST(totPosRisk, RiskAmt);

        if (RET_SUCCEED==ret)   /* REF5101.3501 - AKO/CSA - 001016 */
        {
            ret=FIN_ChangeInstrLegNatEn(instrPtr, posHierHead);
        }

	}
	else
		ret = RET_GEN_INFO_NOACTION;

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_PosRiskAnalysisInitAdAM()
**
**  Description :   Init some variables used by AdAM fonctionality
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED, RET_GEN_INFO_NOACTION or error code
**
**  Creation    :   REF1055 - RAK - 000315
**  Modif       :   REF5586 - AKO - 000125 License not requiered no more
**
*************************************************************************/
STATIC void FIN_PosRiskAnalysisInitAdAM(INSTRCATEGORY_ENUM instrCategory,
                                        FLAG_T             *isAALicenseFlag)
{
    ADAM_LICENCEE_ENUM  isAALicenseEn=AdamLicencee_No;
    GEN_GetApplInfo( ApplAALicense, &isAALicenseEn);

    if ((instrCategory == InstrCategory_Swap ||
         instrCategory == InstrCategory_ForexSwap) &&
        isAALicenseEn >= AdamLicencee_Level1)
    {
        *isAALicenseFlag = TRUE;
    }
    else if ((instrCategory == InstrCategory_BondFutures ||
              /* instrCategory == InstrCategory_BondForwards ||     REF5586 - AKO-RAK - 010207 */
              /* instrCategory == InstrCategory_CurrencyForwards || REF5586 - AKO-RAK - 010207 */
              instrCategory == InstrCategory_EquityFutures ||
              instrCategory == InstrCategory_CurrencyFutures ||
              instrCategory == InstrCategory_FRA) &&        /* REF4763 - RAK - 000622 */
             isAALicenseEn >= AdamLicencee_Level2)
    {
        *isAALicenseFlag = TRUE;
    }
    else if ((instrCategory == InstrCategory_Options ||
              instrCategory == InstrCategory_ExoticOptions ||
              instrCategory == InstrCategory_ConvertibleBond ||
			  instrCategory == InstrCategory_ACDC) &&	/* PMSTA-34140 - RAK - 190131 - Treat as Exotic option */
             isAALicenseEn >= AdamLicencee_Level3)
    {
        *isAALicenseFlag = TRUE;
    }
    /* REF5586 - RAK - 010207 - If AA_DEF_VAL_RULE is defined -> use Adam for Forward */
    else if (instrCategory ==  InstrCategory_BondForwards ||
             instrCategory ==  InstrCategory_EquityForwards ||
             instrCategory ==  InstrCategory_CurrencyForwards)
    {
        /* REF5586 - RAK - 010221 - If FORWARD_VAL_RULE is defined -> use Adam for Forward */
        FORWARD_VAL_ENUM    fwdValRuleEn;
        GEN_GetApplInfo(ApplForwardValRule, &fwdValRuleEn);
        if (fwdValRuleEn == Forward_Point)
            *isAALicenseFlag = TRUE;
        else
            *isAALicenseFlag = FALSE;
    }
    else
    {
        *isAALicenseFlag = FALSE;
    }
}

/************************************************************************
**
**  Function    :   FIN_PosRiskAnalysis()
**
**  Description :   Determine whether risk adjusted position must be computed
**                  and which parameters are to be applied.
**
**  Arguments   :   posHierHead     extended position hierarchy header
**                  domainArgPtr    pointer on some domain informations
**                  fromDateTime
**                  refCurrId
**                  quoteRetMet     quotation retrieval method, can be
**                                  undefined (NO_VALUE) so it will be read in
**                                  position portfolio.
**                  fusDatePtfFlg   use ptf or domain fusion date rule
**                  fusDateRule     fusion date rule
**                  origPos         initial position pointer
**                  instrId         instrument identifier
**                  inputInstrPtr   instrument pointer, can be NULL
**		            totPosRisk	    pointer on total risk structure
**                  riskQtyStp      quantity structure
**                  status 	        Risk_Father, Risk_Son, Risk_LastSon
**		            compoFlg	    composit flag
**
**  Warning     :   totPricePtr is used like a work zone, il will be modified
**                  at each risk position creation. First call to the function
**                  must be made with a neutral array pointer.
**
**		            FIN_PosRiskAnalysis() is called by FIN_RiskAnalysis()
**		            or by itself.
**		            domainArgPtr->fundRiskEn is FinFundRisk_None for risk only
**		                                FinFundRisk_FundCompo for fund only
**		                                FinFundRisk_FundRisk for fund and risk
**		            compoFlg is TRUE when FIN_PosRiskAnalysis() is called by itself
**		            (hybrid instrument or fund splitting)
**
**  Return      :   RET_SUCCEED or error code
**
**  Modif.      :   DVP187 - RAK - 960829
**  Modif.      :   DVP189 - RAK - 960902
**  Modif.      :   DVP191 - RAK - 960918
**  Modif.      :   BUG145 - RAK - 960930
**  Modif.      :   BUG175 - RAK - 961010
**  Modif.      :   DVP440 - RAK - 970428
**  Modif.      :   DVP510 - RAK - 970618
**  Modif.      :   BUG410 - GRD - 970630
**  Modif.      :   BUG412 - GRD - 970701
**  Modif.      :   REF1457 - RAK - 980324
**  Modif.	    :   REF495 - RAK - 980520
**  Modif.	    :   REF3030 - RAK - 981119
**  Modif.      :   REF6057 - AKO - 010914 - Wrong decomposition of futures,
**                                           froward and options in risk view
**  Modif:          REF5035 - CSY - 020220 - force fwdAccFlg, futAccFlg, termAccFlg to FALSE
**                                          in a context of return or synth admin
**  Modif.      :   REF6089 - YST - 020228 - reporting code from R3.51.1
**                  PMSTA-4559 - 011107 - PMO : Futures Management (margin calls)
**                  PMSTA-17898 - 160414 - PMO : New Fusion Criteria to manage the contract dates for margin calls after partial closing
**                  PMSTA-27661 - 080817 - PMO : Regression: Risk Valuation is not working properly (underlying data not displayed when) RISK_FUT_RULE = 5
**
*************************************************************************/
EXTERN RET_CODE FIN_PosRiskAnalysis(DBA_HIER_HEAD_STP  posHierHead,
									DBA_DYNFLD_STP	   domainPtr,	/* PMSTA-10111 - RAK - 110311 - Add domainPtr as arg */
				                    FIN_DOMAIN_ARG_STP domainArgPtr,
				                    FIN_AIARG_STP      aiArgPtr,
                                    DBA_DYNFLD_STP     origPos,
				                    ID_T               instrId,
				                    DBA_DYNFLD_STP     inputInstrPtr,
				                    DBA_DYNFLD_STP     totPosRisk,
				                    RISK_QTY_STP       riskQtyStp,	/* DVP189 */
				                    RISK_ANALYSIS_ENUM status,
				                    char               compoFlg) 	/* BUG034 - RAK - 960523 */
{
	DBA_DYNFLD_STP      instrPtr=NULL,
			            riskInstrPtr=NULL, valo=NULL, *instrLegTab=NULL;
	RISKFWDRULE_ENUM    riskFwd, riskFut;
	RISK_ANALYSIS_ENUM  sonStatus;
	INSTRNAT_ENUM       childInstrNat;
	char                instrHierFlg, childInstrHierFlg=FALSE;  /* REF7264 - RAK - 020314 */
	int                 i, j, instrLegNb=0;
	RET_CODE            ret;
	RET_CODE            retCode;
	RISK_QTY_ST	        compoQtySt;
	FIN_PRICEARG_ST	    priceArgSt; 		/* REF3030 */
    FLAG_T              freeLegFlg, riskFutTimeValue=FALSE;;     /* DEV1055 - CSA - 04012000 */
    FLAG_T              isAALicenseFlag=FALSE, isOpConvertBondFlg=FALSE, riskDecompoFlg=FALSE;
    DBA_DYNFLD_STP      childInstrPtr=NULL;
	FLAG_T              fwdAccFlg, futAccFlg, termAccFlg;

	/* PMSTA-10111 - RAK - 110311 - add domainPtr as arg */
    /* DBA_DYNFLD_STP domainPtr = DBA_GetDomainPtr(DBA_GetConnectNoFromHier(posHierHead)); */ /* REF5035 - CSY - 020220 */
	memset(&priceArgSt, 0, sizeof(FIN_PRICEARG_ST));	/* REF3030 */
	memset(&compoQtySt, 0, sizeof(RISK_QTY_ST));		/* PMSTA-34140 - RAK - 190122 - Avoid wrong init of all fields */
	priceArgSt.riskFlg = TRUE;				            /* REF3030 */

	if (posHierHead == (DBA_HIER_HEAD_STP)NULL)
	{
	    MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
		             "FIN_PosRiskAnalysis", "posHierHead");
		return(RET_GEN_ERR_INVARG);
	}

	if (origPos == NULL)
	{
	    MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
		             "FIN_PosRiskAnalysis", "origPos");
		return(RET_GEN_ERR_INVARG);
	}
	/* WEALTH-1147 - cash derivative amount was not getting added in valuation */
	if ((ret = DBA_SetHierLnkUsed(posHierHead, ExtPos,
		ExtPos_Acct_ExtPos_Ext)) != RET_SUCCEED)
	{
		DBA_FreeHier(posHierHead);
		return(ret);
	}


	if (domainArgPtr->riskDecompoLevel != RISKDECOMPO_MAXLEVEL)
	{
		/* PMSTA-13140 - LJE - 120319 */
		FIN_GetAccFlag(domainPtr,
			origPos,
			&futAccFlg,
			&fwdAccFlg,
			&termAccFlg);

		/* BUG034 -  RAK - 960523 */
		/* domainArgPtr->riskDecompoLevel += 1; */
		/* Replaced by :                        */
		if (compoFlg == FALSE)
			domainArgPtr->riskDecompoLevel += 1;

		/* BUG175 */
		if ((ret = FIN_RiskGetInstrPtr(posHierHead, domainArgPtr->fromDateTime, instrId,
			inputInstrPtr, &instrPtr, &instrHierFlg)) != RET_SUCCEED)
		{
			return(ret);
		}

		/* if (GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_ForexSwaps)
			SET_ENUM(instrPtr, A_Instr_RiskNatEn, RiskNat_Hybrid); */

		const INSTRNAT_ENUM       instrNat = (INSTRNAT_ENUM)GET_ENUM(instrPtr, A_Instr_NatEn);      /*  Get the nature of the instrument */ /* 000127 - RAK - moved */
		const INSTRCATEGORY_ENUM  instrCategory = FIN_InstrCategory(instrPtr, posHierHead);         /*  Get the category of the instrument      */
		const ENUM_T              riskNature = GET_ENUM(instrPtr, A_Instr_RiskNatEn);               /*  Get the risk nature of the instrument   */

		/*
			DEV1055 - CSA - 21121999
			Get for the Advanced Analytics License flag
			*/
		FIN_PosRiskAnalysisInitAdAM(instrCategory, &isAALicenseFlag);

		/* PMSTA-8736 - KRA - 091103 */
		GEN_GetApplInfo(ApplRiskFutRule, &riskFut); /* 000127 - RAK - moved/021010 - YST - moved again */

		/*** HYBRID INSTRUMENT ***/
		/* PMSTA-32112 - RAK - 180907 - Use STN specifics functions */
		if ((riskNature == RiskNat_Hybrid) ||
			((instrCategory != InstrCategory_Others) && instrCategory != InstrCategory_StructuredNotes))
		{
			DBA_DYNFLD_STP *    compoTab = nullptr;
			int                 compoNbr = 0;

			switch (instrCategory)
			{
			case    InstrCategory_BondFutures:
			case    InstrCategory_BondForwards:
			case    InstrCategory_EquityFutures:
			case    InstrCategory_EquityForwards:
			case    InstrCategory_CurrencyFutures:
			case    InstrCategory_CurrencyForwards:
			case    InstrCategory_Swap:	        /* now use FIN_GenericInstrCompo() */
			case    InstrCategory_ForexSwap:    /* now use FIN_GenericInstrCompo() */
			case    InstrCategory_Options:
			case    InstrCategory_ExoticOptions:
			case    InstrCategory_ConvertibleBond:
			case    InstrCategory_ACDC:			/* PMSTA-34140 - RAK - 190131 - AC/DC*/
				{
					FLAG_T compoOk = TRUE;

					/* 000223 - RAK - For options, parameter RISK_OPT_VAL_RULE must */
					/* be UnderlyPrice and A_Domain_OptRiskRuleEn must be Full or Delta */
					/* REF5049 - RAK - 010215 */
					/* For options of a convertible bond, do always the decomposition in */
					/* underlying instr (new instr of exchange event) and fixed income   */

					if (instrCategory == InstrCategory_Options ||
						instrCategory == InstrCategory_ExoticOptions)
					{
						RISKOPTVALRULE_ENUM optValRule;
						GEN_GetApplInfo(ApplRiskOptValRule, &optValRule);

						FIN_IsOptConvertBondFlg(instrPtr, posHierHead, &isOpConvertBondFlg);

						if (isOpConvertBondFlg == FALSE &&
							(optValRule != RiskOptValRule_UnderlyPrice ||
							domainArgPtr->optDeltaRule == OptDelta_None))
							compoOk = FALSE;
					}

					/* PMSTA-8736 - KRA - 091103 - Don't create compoTab for future and Time Value leg */
					riskFutTimeValue = FALSE;
					if ((instrCategory == InstrCategory_BondFutures ||
						instrCategory == InstrCategory_EquityFutures ||
						instrCategory == InstrCategory_CurrencyFutures) && riskFut == RiskFutRule_UnderlyPosAndTimeValue)
					{
						compoOk = FALSE;
						riskFutTimeValue = TRUE;
					}

					/* Test for Advanced Analytics license flag  */
					if (isAALicenseFlag == TRUE && compoOk == TRUE)
					{
						/* PMSTA-34752 - RAK - 190221 - Add grand father information for Tarko */
						ret = FIN_GenericInstrCompo(instrPtr, posHierHead,
							origPos, &compoTab, &compoNbr, riskQtyStp->STNEn);
					}
					else if (riskFutTimeValue == FALSE) /* Use default */
					{
						if (instrId < 0)
							instrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
						ret = DBA_SelectInstrCompo(instrId, domainArgPtr->fromDateTime,
							&compoTab, &compoNbr);
					}
				}
				break;

			/* Developer Information Not Obsolete Serious And Useful Recommendation � DINOSAUR � KPV � 110831 */
			/* here fund share described by InstrCompo is decomposed even if fund splitting isn't asked */
			/* perhaps a very small limit between an old decision and a bug */
			case    InstrCategory_Others:
			default:
				if (instrId < 0)			/* BUG412 - GRD - 970701 */
					instrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
				ret = DBA_SelectInstrCompo(instrId, domainArgPtr->fromDateTime, &compoTab, &compoNbr);
				break;
			}

			/* DVP189 */
			compoQtySt.idxCalcRuleEn = (IDXCALCRULE_ENUM)GET_ENUM(instrPtr, A_Instr_IdxCalcRuleEn);
			compoQtySt.qty = 0.0;
			compoQtySt.price = 0.0;
			compoQtySt.priceCurrId = ZERO_ID;
			compoQtySt.pricePtr = NULL;

			/* PMSTA-34672 - RAK - 190215 */
			if (instrCategory == InstrCategory_ACDC && compoNbr > 0)
			{
				compoQtySt.STNEn = StnSpecific_Treatment;	/* specific treatment for STN computation */
				compoQtySt.price = GET_PRICE(compoTab[0], A_InstrCompo_BasketExerPrice); /* init by FIN_GenericInstrCompo(), in fact TermEvt exerPrice */
				compoQtySt.priceCurrId = GET_ID(instrPtr, A_Instr_RefCurrId);
			}

			/* PMSTA-34140 - RAK - 190122 - RAK - Use received riskQtyStp info in case of STN computation */
			if (riskQtyStp->STNEn == StnSpecific_Treatment)
			{
				compoQtySt.idxCalcRuleEn = riskQtyStp->idxCalcRuleEn;
				compoQtySt.price = riskQtyStp->price;
				compoQtySt.priceCurrId = riskQtyStp->priceCurrId;
				compoNbr = 1; /* first leg only */
				FREE_DYNST(compoTab[1], A_InstrCompo);
				
			}
			/* PMSTA-35133 - RAK - 190507 - keep specific information for redemption price */
			else if (riskQtyStp->STNEn == StnSpecific_FXTarkoOption)
			{
				compoQtySt.STNEn = riskQtyStp->STNEn;
				compoQtySt.idxCalcRuleEn = riskQtyStp->idxCalcRuleEn;
				compoQtySt.price = riskQtyStp->price;
				compoQtySt.priceCurrId = riskQtyStp->priceCurrId;
			}

			MemoryPool  mp;         /* PMSTA-27661 - 080817 - PMO */
			mp.owner(compoTab, compoNbr);

			/* BOUM if you don't test ret SUCCEED */
			if (ret == RET_SUCCEED && compoNbr > 0) /* PMSTA-27661 - 080817 - PMO */
			{
				if (compoNbr > 0)   /* treat composite instrument */
				{
					/* Read father price and currency */
					if (compoQtySt.idxCalcRuleEn == IdxCalcRule_PctValue)
					{
						valo = NULL;
						if (GET_EXTENSION_PTR(origPos, ExtPos_PosVal_Ext) != NULL &&
							(valo = *(GET_EXTENSION_PTR(origPos, ExtPos_PosVal_Ext))) != NULL)
						{
							compoQtySt.priceCurrId = GET_ID(valo, PosVal_PriceCurrId);
							compoQtySt.price = GET_PRICE(valo, PosVal_Price);
						}

						compoQtySt.pricePtr = mp.allocDynst(FILEINFO, A_InstrPrice);        /* PMSTA-27661 - 080817 - PMO */
					}

					/* REF6089 - YST - 020228 - Create or load leg for the Swap */
					if (GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_Swap)
					{
						FIN_SwapLegInstr(instrPtr, posHierHead,
							GET_DATETIME(origPos, ExtPos_ExtPosDate),
							&instrLegTab,
							&instrLegNb, &freeLegFlg);
					}

					for (i = 0; i < compoNbr; i++)
					{
						/* REF5886 - RAK - 010404 - Moved upper for next test */
						childInstrPtr = NULL;

						/* REF6089 - YST - 020228 - Use instrument generated by FIN_SwapLegInstr */
						if (instrLegTab != NULL)
						{
							for (j = 0; childInstrPtr == NULL && j < instrLegNb; j++)
							{
								if (GET_ID(instrLegTab[j], A_Instr_ParentInstrId) == GET_ID(compoTab[i], A_InstrCompo_InstrId) &&
									GET_ID(instrLegTab[j], A_Instr_RefInstrId) == instrId)
									childInstrPtr = instrLegTab[j];
							}
							FREE(instrLegTab); /* PMSTAS-21898 - DDV - 151214 - Purify */
						}

						if (childInstrPtr == NULL)
						{
							if ((ret = FIN_RiskGetInstrPtr(posHierHead, domainArgPtr->fromDateTime,
								GET_ID(compoTab[i], A_InstrCompo_InstrId),
								NULL, &childInstrPtr,
								&childInstrHierFlg)) != RET_SUCCEED)
							{
								return(ret);
							}
						}

						childInstrNat = (INSTRNAT_ENUM)GET_ENUM(childInstrPtr, A_Instr_NatEn);

						/* REF5886 - RAK - 010404 - Convertible bond */
						if (instrCategory == InstrCategory_ConvertibleBond &&
							childInstrNat == InstrNat_Bond &&
							CMP_AMOUNT(GET_AMOUNT(totPosRisk, RiskAmt_PosMktValAmt), 0.0,
							GET_ID(totPosRisk, RiskAmt_PosCurrId)) < 0 &&
							CMP_NUMBER(GET_NUMBER(compoTab[i], A_InstrCompo_Quantity), 0.0) > 0)
						{
							NUMBER_T tmpQty = GET_NUMBER(compoTab[i], A_InstrCompo_Quantity)*-1;
							SET_NUMBER(compoTab[i], A_InstrCompo_Quantity, tmpQty);
						}

						/* DVP189 */
						if (compoQtySt.idxCalcRuleEn == IdxCalcRule_PctValue)
						{
							/* qty = (father's qty * father's price * compo qty) / son's price */
							compoQtySt.qty = (riskQtyStp->qty * compoQtySt.price *
								GET_NUMBER(compoTab[i], A_InstrCompo_Quantity));
						}
						else
						{
							/* qty = father's qty * compo qty */
							compoQtySt.qty = riskQtyStp->qty *
								GET_NUMBER(compoTab[i], A_InstrCompo_Quantity);
						}

						sonStatus = Risk_Son;

						/* Determine last son for difference */
						if (i == compoNbr - 1)
						{
							/* PMSTA-34140 - RAK - 190201 - Don't put LastSon for AC/DC */
							/* its the cash leg (and qty already computed in compo by FIN_GenericInstrCompo, price will be 1.0 */
							if (instrCategory != InstrCategory_ACDC)
							{
								/* Composite instrument is valorised by its */
								/* components, don't compute difference for last */
								if (GET_ENUM(instrPtr, A_Instr_ValRuleEn) != ValRule_Composite &&
									compoQtySt.idxCalcRuleEn != IdxCalcRule_PctValue) /* DVP189 */
								{
									/* Only father and last son can have last son */
									if (status == Risk_Father || status == Risk_LastSon)
										sonStatus = Risk_LastSon;
								}
							}
							else /* PMSTA-34672 - RAK - 190215 */
							{
								/* in case of AC/DC, don't use TermEvt/InstrCompo/compQtySt.price for the (second) cash leg */
								compoQtySt.idxCalcRuleEn = IdxCalcRule_None;
								compoQtySt.STNEn = StnSpecific_None; /* PMSTA-35133 - RAK - 190314 */
							}
						}

						SET_NUMBER(totPosRisk, RiskAmt_CompoQty,
							GET_NUMBER(compoTab[i], A_InstrCompo_Quantity));

						/* REF5049 - RAK - 010216 - Option of convertible bond -> de the risk decomposition */
						riskDecompoFlg = TRUE;

						if (childInstrNat == InstrNat_Option)
						{
							/* TRUE if option of convertible bond, FALSE for other options */
							FIN_IsOptConvertBondFlg(childInstrPtr, posHierHead, &riskDecompoFlg);
						}
						else if (childInstrNat == InstrNat_ExoticOptions ||
							childInstrNat == InstrNat_Future ||
							childInstrNat == InstrNat_ConvertBond) /* REF5049 - AKO -001114 */
						{
							riskDecompoFlg = FALSE;
						}

						if (riskDecompoFlg == FALSE)
						{
							FLAG_T          isFutOptionFlg = FALSE;
							DBA_DYNFLD_STP  childRiskPos = NULL;

							ret = FIN_TreatCompoRisk(posHierHead, domainArgPtr, aiArgPtr, origPos,
								childInstrPtr, childInstrHierFlg,
								totPosRisk, &compoQtySt,
								&priceArgSt, sonStatus,
								&childRiskPos);

							/* REF5300 - RAK - 010717 */
							FIN_IsFutOptionFlg(childInstrPtr, posHierHead, &isFutOptionFlg);
							if (ret == RET_SUCCEED && childRiskPos != NULL && isFutOptionFlg == TRUE)
							{
								/* PMSTA-10111 - RAK - 110311 - add domainPtr as arg */
								ret = FIN_RiskAnalysis(posHierHead, domainPtr, domainArgPtr, aiArgPtr, childRiskPos);
							}
						}
						else
						{
							/* REF5049 - RAK - 010215 */
							/* Add chilInstrPtr (instead of NULL) in arg list */
							/* (I don't know why we don't do that before)          */
							ret = FIN_PosRiskAnalysis(posHierHead, domainPtr, /* PMSTA-10111 - RAK - 110311 - add domainPtr as arg */
								domainArgPtr, aiArgPtr, origPos,
								/* GET_ID(compoTab[i], A_InstrCompo_InstrId),  REF6089 - YST - Use id of Child */
								GET_ID(childInstrPtr, A_Instr_Id),
								childInstrPtr, totPosRisk, &compoQtySt,
								sonStatus, TRUE);
						}
					}

					/* DVP187 */
					/* Suppress risk link and nature to parent (hybrid instrument) */
					if (GET_EXTENSION_PTR(origPos, ExtPos_RiskPar_A_Instr_Ext) != NULL &&
						(riskInstrPtr = *(GET_EXTENSION_PTR(origPos,
						ExtPos_RiskPar_A_Instr_Ext))) != NULL)
					{
						/* DVP510 - RAK - 970618 */
						INSTRNAT_ENUM instrNatEn = (INSTRNAT_ENUM)GET_ENUM(riskInstrPtr, A_Instr_NatEn);
						if (instrNatEn == InstrNat_Option ||
							instrNatEn == InstrNat_ExoticOptions ||
							instrNatEn == InstrNat_SwapOptions ||
							/* PMSTA-35943 - DCI/TCI la ligne option disparait elegamment */
							InstrumentNature::isDualCurrencyInvestMoneyMarket(riskInstrPtr) ||
						    InstrumentNature::isTripleCurrencyInvestMoneyMarket(riskInstrPtr))
						{
							SET_ENUM(origPos, ExtPos_RiskNatEn, ExtPosRisk_NoRisk);
							SET_NULL_ID(origPos, ExtPos_RiskOriginExtPosId);
							SET_NULL_ID(origPos, ExtPos_RiskParInstrId);
						}
					}
				}

				return(RET_SUCCEED);	/* BUG175 */
			}
		}

		/*** DERIVATIVE INSTRUMENT ***/
		/* no hybrid or hybrid but no composite and no special case */

		/* PMSTA-32112 - RAK - 180820 */
		/* PMSTA-34140 - RAK - 190122 - Add riskQtyStp arg to all fct */
		if (instrCategory == InstrCategory_StructuredNotes)
		{
			retCode = RET_SUCCEED;

			if (true == InstrumentNature::isAirBagCertificates(instrPtr))
			{
				retCode = FIN_TreatInstrCategoryAirbag(posHierHead, domainPtr, domainArgPtr, aiArgPtr,
					origPos, instrPtr, instrHierFlg, &priceArgSt, riskQtyStp, status);
			}

			if (true == InstrumentNature::isEquityLinkedNotes(instrPtr) ||
				        InstrumentNature::isBondsLinkedNotes(instrPtr) ||
						InstrumentNature::isCapProtectNotes(instrPtr))
			{
				retCode = FIN_TreatInstrCategoryELN(posHierHead, domainPtr, domainArgPtr, aiArgPtr,
					origPos, instrPtr, instrHierFlg, &priceArgSt, riskQtyStp, status);
			}

			if (true == InstrumentNature::isCapProtectNotesWCoupon(instrPtr))
			{
				retCode = FIN_TreatInstrCategoryPPN(posHierHead, domainPtr, domainArgPtr, aiArgPtr,
						origPos, instrPtr, instrHierFlg, &priceArgSt, riskQtyStp, status);
			}

			if (true == InstrumentNature::isMemoryCoupons(instrPtr))
			{
				retCode = FIN_TreatInstrCategoryMemoryC(posHierHead, domainPtr, domainArgPtr, aiArgPtr,
						origPos, instrPtr, instrHierFlg, &priceArgSt, riskQtyStp, status);
			}

			if (true == InstrumentNature::isReverseConvertible(instrPtr) ||
				        InstrumentNature::isReverseConvertibleELN(instrPtr) ||
						InstrumentNature::isReverseConvertibleBLN(instrPtr))
			{
				retCode = FIN_TreatInstrCategoryRCN(posHierHead, domainPtr, domainArgPtr, aiArgPtr,
						origPos, instrPtr, instrHierFlg, &priceArgSt, riskQtyStp, status);
			}

			if (true == InstrumentNature::isReverseConvertibleCLN(instrPtr))
			{
				retCode = FIN_TreatInstrCategoryCLN(posHierHead, domainPtr, domainArgPtr, aiArgPtr,
						origPos, instrPtr, instrHierFlg, &priceArgSt, riskQtyStp, status);
			}

			if (true == InstrumentNature::isDiscountCertificates(instrPtr))
			{
				retCode = FIN_TreatInstrCategoryDiscountC(posHierHead, domainPtr, domainArgPtr, aiArgPtr,
						origPos, instrPtr, instrHierFlg, &priceArgSt, riskQtyStp, status);
			}

			if (true == InstrumentNature::isTwinWinCertificates(instrPtr))
			{
				retCode = FIN_TreatInstrCategoryTwinWin(posHierHead, domainPtr, domainArgPtr, aiArgPtr,
						origPos, instrPtr, instrHierFlg, &priceArgSt, riskQtyStp, status);
			}

			if (true == InstrumentNature::isBonusNotes(instrPtr))
			{
				retCode = FIN_TreatInstrCategoryBonusNotes(posHierHead, domainPtr, domainArgPtr, aiArgPtr,
						origPos, instrPtr, instrHierFlg, &priceArgSt, riskQtyStp, status);
			}

			if (true == InstrumentNature::isMiniFuturesTurbo(instrPtr))
			{
				retCode = FIN_TreatInstrCategoryTurbo(posHierHead, domainPtr, domainArgPtr, aiArgPtr,
						origPos, instrPtr, instrHierFlg, &priceArgSt, riskQtyStp, status);
			}

			/* PMSTA-34140 - RAK - 190104 - New case for option based STN */
			if (InstrumentNature::isParticipatingForward(instrPtr) ||
				InstrumentNature::isTargetKnockOutForward(instrPtr))
			{
				retCode = FIN_TreatInstrCategorySTNForward(posHierHead, domainPtr, domainArgPtr, aiArgPtr,
					origPos, instrPtr, instrHierFlg, &priceArgSt, riskQtyStp, status);
			}

			if (InstrumentNature::isDualCurrencyInvestMoneyMarket(instrPtr) ||
				InstrumentNature::isTripleCurrencyInvestMoneyMarket(instrPtr))
			{
				retCode = FIN_TreatInstrCategoryDCITCI(posHierHead, domainPtr, domainArgPtr, aiArgPtr,
					origPos, instrPtr, instrHierFlg, &priceArgSt, riskQtyStp, status);
			}

			return(retCode);
		}

		/* Developer Information Not Obsolete Serious And Useful Recommendation � DINOSAUR � KPV � 110831 */
		/* here the call to option treatment */
		/* DVP510 - RAK - 970618 */
	    if ((instrNat == InstrNat_Option ||
		    instrNat == InstrNat_ExoticOptions ||
		    instrNat == InstrNat_SwapOptions) && instrCategory != InstrCategory_ACDC)
	    {
		    retCode = FIN_TreatOptionRisk(posHierHead, domainPtr, domainArgPtr, aiArgPtr,
				                          origPos, instrPtr, instrHierFlg,
					                      totPosRisk, riskQtyStp,
                                          &priceArgSt, status); /* DVP189 */
			return(retCode);
	    }

        /* REF1055 - RAK - 000314 */
		/* Developer Information Not Obsolete Serious And Useful Recommendation � DINOSAUR � KPV � 110831 */
		/* here the call to future, forward and FRA treatment, I agree not easy to understand             */
		/* why 3 different calls ... anyway go inside it will perhaps be enaught.                         */
        if (instrNat == InstrNat_Future || instrNat == InstrNat_Forward ||
            (instrNat == InstrNat_FRA && isAALicenseFlag == FALSE))
	    {
            GEN_GetApplInfo(ApplRiskFwdRule, &riskFwd); /* 000127 - RAK - moved/021010 - YST - moved again */

	        if (((instrNat==InstrNat_Future || instrNat==InstrNat_FRA) && 	/* DVP440 */
		        riskFut==RiskFutRule_FutPos) ||
	            (instrNat==InstrNat_Forward && riskFwd==RiskFwdRule_FwdPos))
	        {
	            /* Risk position is future (forward) position */
		        if (status == Risk_Father)
		        {
		            RISK_FUTFWD_ENUM riskFutFwdEn=RiskFutFwd_None;

		            if (GET_FLAG(origPos, ExtPos_MainFlg) == TRUE &&
			            (GET_ENUM(origPos, ExtPos_RefNatEn) == PosRefNat_FwdOpen ||
		                 GET_ENUM(origPos, ExtPos_RefNatEn) == PosRefNat_FwdClose))
		            {
			            /* Create a risk forward position */
		    	        if (fwdAccFlg == TRUE)
				            riskFutFwdEn = RiskFutFwd_FutFwd;
			            else
				            riskFutFwdEn = RiskFutFwd_None;
		            }

		            if (GET_FLAG(origPos, ExtPos_MainFlg) == TRUE &&
		    	        (GET_ENUM(origPos, ExtPos_RefNatEn) == PosRefNat_FutOpen        ||
		                 GET_ENUM(origPos, ExtPos_RefNatEn) == PosRefNat_FutClose       ||
		                 GET_ENUM(origPos, ExtPos_RefNatEn) == PosRefNat_FutFifo        ||
                         GET_ENUM(origPos, ExtPos_RefNatEn) == PosRefNat_FutWMP         ||  /* PMSTA-4559 - 011107 - PMO */
                         GET_ENUM(origPos, ExtPos_RefNatEn) == PosRefNat_FutContract    ||  /* PMSTA-17898 - 160414 - PMO */
                         GET_ENUM(origPos, ExtPos_RefNatEn) == PosRefNat_FRAOpen        ||
			             GET_ENUM(origPos, ExtPos_RefNatEn) == PosRefNat_FRAClose)) /* DVP440 */
		            {
			            /* Create a risk future position */
		    	        if (futAccFlg == TRUE)
			                riskFutFwdEn = RiskFutFwd_FutFwd;
			            else
			                riskFutFwdEn = RiskFutFwd_None;
		            }

	    	        /* Set current position to risk position */
	    	        retCode = FIN_TreatFutFwdRisk(posHierHead, domainPtr, domainArgPtr, aiArgPtr, origPos,
				                                instrPtr, instrHierFlg, totPosRisk,
						                        riskQtyStp, &priceArgSt, status, riskFutFwdEn);

					return(retCode);
		        }
		        else
		        {
		            /* Create a risk future (forward) position */
	    	        retCode = FIN_TreatFutFwdRisk(posHierHead, domainPtr, domainArgPtr, aiArgPtr, origPos,
				                                instrPtr, instrHierFlg, totPosRisk,
						                        riskQtyStp, &priceArgSt, status, RiskFutFwd_FutFwd);
					return(retCode);
		        }
	        }
	        else
	        {
	    	    /* Risk position is underlying position */
		        retCode = FIN_TreatFutFwdRisk(posHierHead, domainPtr, domainArgPtr, aiArgPtr, origPos,
				                        instrPtr, instrHierFlg, totPosRisk, riskQtyStp,
				                        &priceArgSt, status, RiskFutFwd_Underly);	/* DVP189 */
				return(retCode);
	       }
	    }
	    else if (instrNat == InstrNat_FRA && isAALicenseFlag == TRUE)      /* REF1055 - RAK - 000314 */
	    {
		    retCode = FIN_TreatFRARisk(posHierHead, domainArgPtr, aiArgPtr, origPos,
					                   instrPtr, totPosRisk, riskQtyStp,
					                   &priceArgSt, status);
			return(retCode);
	    }

	    /* Final component or "normal position" */
	    if (status == Risk_Father)
	    {
	        if (termAccFlg == TRUE && GET_FLAG(origPos, ExtPos_MainFlg) == TRUE &&
		        (GET_ENUM(origPos, ExtPos_RefNatEn)==PosRefNat_TermOpen ||
		         GET_ENUM(origPos, ExtPos_RefNatEn)==PosRefNat_TermClose))
	        {
		        retCode = FIN_TreatCompoRisk(posHierHead, domainArgPtr, aiArgPtr,
						                    origPos, instrPtr, instrHierFlg,
						                    totPosRisk, riskQtyStp, &priceArgSt, status,
						                    NULL);  	/* DVP189 */
				return(retCode);
	        }
	        else
	        {
		        FORWARD_VAL_ENUM valRule;
		        GEN_GetApplInfo(ApplForwardValRule, &valRule);

		        /* REF3030 - New system forward valuation rule is blocked */
		        valRule = Forward_Extrapo;

		        /* REF53.1 - Don't set to risk FRA cash position */
		        if (instrNat == InstrNat_CashAcct &&
			        (GET_ENUM(origPos, ExtPos_RefNatEn) == PosRefNat_FRAOpen ||
			         GET_ENUM(origPos, ExtPos_RefNatEn) == PosRefNat_FRAClose ||
			         (valRule == Forward_Point && 	/* REF495 */
			          (GET_ENUM(origPos, ExtPos_RefNatEn) == PosRefNat_FwdOpen ||
			           GET_ENUM(origPos, ExtPos_RefNatEn) == PosRefNat_FwdClose))))
		        {
			        SET_FLAG(origPos, ExtPos_AcctFlg, FALSE);
		        }
		        else
		        {
	    	        /* Set current position to risk position */
		            if (domainArgPtr->fundRiskEn != FinFundRisk_FundCompo)
                    {
                        /* REF4763 - RAK - 000518 */
                        /* Cash position don't appear if discounted is created */
                        /*  with main instrument position risk decomposition   */
                        FLAG_T  cashRiskFlg=TRUE;

                        if (instrNat == InstrNat_CashAcct &&
                            (GET_ENUM(origPos, ExtPos_RefNatEn) == PosRefNat_FwdOpen        ||
                             GET_ENUM(origPos, ExtPos_RefNatEn) == PosRefNat_FRAOpen        ||
                             GET_ENUM(origPos, ExtPos_RefNatEn) == PosRefNat_FutOpen        ||
                             GET_ENUM(origPos, ExtPos_RefNatEn) == PosRefNat_FutWMP         || /* PMSTA-4559 - 011107 - PMO */
                             GET_ENUM(origPos, ExtPos_RefNatEn) == PosRefNat_FutContract    || /* PMSTA-17898 - 160414 - PMO */
                             GET_ENUM(origPos, ExtPos_RefNatEn) == PosRefNat_FutFifo))
                        {
                            /* REF5586 - RAK - 010207 */
                            /* Use FIN_PosRiskAnalysisInitAdAM() for more consistency */
                            /*
                            ADAM_LICENCEE_ENUM  isAALicenseEn=AdamLicencee_No;
                            GEN_GetApplInfo(ApplAALicense, &isAALicenseEn);
                            if (isAALicenseEn >= AdamLicencee_Level2)
                                cashRiskFlg = FALSE;
                            */

                            /* REF5586 - RAK - 010213 - Test on main instrument */
                            DBA_DYNFLD_STP  mainPosPtr=NULL, mainInstrPtr=NULL;
                            ID_T            defaultValuationRuleId=-1;
                            FLAG_T          isTheoriticalInstrument=FALSE;

                            if (GET_EXTENSION_PTR(origPos, ExtPos_Main_ExtPos_Ext) != NULL)
		                        mainPosPtr = *(GET_EXTENSION_PTR(origPos, ExtPos_Main_ExtPos_Ext));

							/* PMSTA4551 - RAK - 080107 - Create link */
							if (mainPosPtr == NULL)
							{
								DBA_MakeSpecRecordLinks(posHierHead,
                                            ExtPos,
                                            ExtPos_Main_ExtPos_Ext,
                                            origPos);

								if (GET_EXTENSION_PTR(origPos, ExtPos_Main_ExtPos_Ext) != NULL)
									mainPosPtr = *(GET_EXTENSION_PTR(origPos, ExtPos_Main_ExtPos_Ext));
							}

                            if (mainPosPtr != NULL)
                            {
                                if (GET_EXTENSION_PTR(mainPosPtr, ExtPos_A_Instr_Ext) != NULL)
        		                    mainInstrPtr = *(GET_EXTENSION_PTR(mainPosPtr, ExtPos_A_Instr_Ext));
                            }

                            if (mainInstrPtr != NULL)
                            {
                                FIN_GetAdAMInfoForInstr(mainInstrPtr, &defaultValuationRuleId,
                                                        &isAALicenseFlag, &isTheoriticalInstrument);

                                if (isAALicenseFlag == TRUE)
                                    cashRiskFlg = FALSE;

								/* PMSTA-8736 - RAK - 091218 - cash leg must be risk */
								if ((INSTRNAT_ENUM)GET_ENUM(mainInstrPtr, A_Instr_NatEn) == InstrNat_Future &&
									riskFut == RiskFutRule_UnderlyPosAndTimeValue)
								{
									cashRiskFlg = TRUE;
								}
							}
                        }

						/* PMSTA00828 - ACB - 061208 - We don't know why this modification is here ...      */
						/* but it create an unbalance in risk valorisation for check strat ... so REMOVE it */
						/* in the LN it isn't spoken about risk */
						/* (perhaps client didn't know that he works with a risk strat and so a risk valorisation */
						/* with a different total from a standard valorisation (according to FWD_ACC_FLG and RISK_FWD_RULE) */
                        /* REF11379 - TEB - 050912 */
						if (cashRiskFlg == TRUE /*|| GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_CheckStratValo*/)
						{
		                    SET_ENUM(origPos, ExtPos_RiskNatEn, ExtPosRisk_FinRisk);
						}


                    }

	                if (domainArgPtr->fundRiskEn != FinFundRisk_None)
		                SET_ENUM(origPos, ExtPos_FundSplitNatEn, FundSplitNat_Split);
		        }

				return(RET_SUCCEED);
	        }
	    }
	    else
	    {
	        /* Create new risk position, totPosRisk will be modified */
	        retCode = FIN_TreatCompoRisk(posHierHead, domainArgPtr, aiArgPtr, origPos,
					     instrPtr, instrHierFlg, totPosRisk, riskQtyStp,
					     &priceArgSt, status, NULL);	/* DVP189 */
			return(retCode);
	    }
    }
	else
		return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_AddValoRiskOptCashPos()
**
**  Description :   Add and valorise risk cash position for option
**
**  Arguments   :   posHierHead    hierarchy header pointer
**                  domainArgPtr   pointer on some domain informations
**                  riskPos        original position pointer
**                  cashId         cash identifier
**
**  Return      :   RET_SUCCEED or error code
**
**  Modif	:   REF964 - RAK - 971210
**  Modif	:   REF1812 - RAK - 980501
**  Modif.	:   REF2313 - RAK - 980910
**  Modif.	:   REF3209 - RAK - 990113
**
*************************************************************************/
EXTERN RET_CODE FIN_AddValoRiskOptCashPos(DBA_HIER_HEAD_STP  posHierHead,
                                          FIN_DOMAIN_ARG_STP domainArgPtr,
				                          DBA_DYNFLD_STP     riskPos,
										  FIN_OPTINFO_STP  optInfoStp)
{
	DBA_DYNFLD_STP	cashPos=NULL, getData=NULL,
					cashInstr=NULL, valo=NULL, cashValo=NULL;
	EXCHANGE_T		exch;
	AMOUNT_T		amt;
	PRICE_T		        price, quote;
	int				posBpAmtFld;
	RET_CODE		ret;
	FIN_EXCHARG_ST  exchArgSt;			/* REF2313 */
	MemoryPool		mp;

	memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));	/* REF2313 */
	/*DBA_SetConnectNoToExchArg(&exchArgSt, DBA_GetConnectNoFromHier(posHierHead));*/ /* REF2580 - SSO - 980727 */
	DBA_InitConnectNoToExchArg(&exchArgSt, posHierHead); /* REF4213 - SSO - 991221 */

	/*** COMPUTE OPTION POUND IN RISK DECOMPOSITION ***/
	if ((cashPos = ALLOC_DYNST(ExtPos)) == NULL)
	{
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	cashInstr = mp.allocDynst(FILEINFO, A_Instr);		 /* PMSTA-49339 - JBC - 20220817 */
    getData = mp.allocDynst(FILEINFO, Get_Arg);

	/* Search currency instrument with reference currency */
	SET_ID(getData,   Get_Arg_RefCurrId, optInfoStp->exerCurrId);
	SET_ENUM(getData, Get_Arg_NatEn,     InstrNat_CashAcct);

	if (DBA_Get2(Instr, UNUSED, Get_Arg, getData, A_Instr, &cashInstr,
	             UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
	{
		/* PMSTA00485 - RAK - 061122 - Not realy the subject of dvp but add an clear message, so use it */
		DBA_DYNFLD_STP	currPtr=NULL;
        FLAG_T          freeFlag=FALSE;

		/* PMSTA16847 - DDV - 130924 - Add freeFlag parameter */
		if (DBA_GetCurrById(optInfoStp->exerCurrId, &currPtr, &freeFlag) == RET_SUCCEED)
		{ MSG_SendMesg(RET_DBA_ERR_NODATA, 10, FILEINFO, GET_CODE(currPtr, A_Curr_Cd));}
		else
		{ MSG_SendMesg(RET_DBA_ERR_NODATA, 11, FILEINFO, optInfoStp->exerCurrId);}

        if (freeFlag == TRUE) {FREE_DYNST(currPtr, A_Curr);}
		FREE_DYNST(cashPos, ExtPos);
   		return(RET_DBA_ERR_NODATA);
	}


	/* ExtPos_SysGrossAmt, ExtPos_SysNetAmt, ExtPos_RefGrossAmt, */
	/* ExtPos_RefNetAmt are same in cash position */
	COPY_DYNST(cashPos, riskPos, ExtPos);

	/* Suppress extension identifier (copied from origin position) */
	SET_NULL_ID(cashPos, ExtPos_MainExtPosId);
	SET_NULL_ID(cashPos, ExtPos_AcctExtPosId);
	SET_NULL_ID(cashPos, ExtPos_AdjustExtPosId);
	SET_NULL_ID(cashPos, ExtPos_PosValId);

	SET_ID(cashPos, ExtPos_RiskParInstrId, GET_ID(riskPos, ExtPos_RiskParInstrId));
	SET_ID(cashPos, ExtPos_InstrId,        GET_ID(cashInstr, A_Instr_Id));
	SET_ID(cashPos, ExtPos_InstrCurrId,    GET_ID(cashInstr, A_Instr_RefCurrId));
	SET_ID(cashPos, ExtPos_PosCurrId,      GET_ID(cashInstr, A_Instr_RefCurrId));
	SET_ID(cashPos, ExtPos_MainExtPosId,   GET_ID(riskPos, ExtPos_Id));

    SET_FLAG(cashPos, ExtPos_MainFlg, FALSE);

	/* PMSTA04793 - RAK - 071115 - Verify if cash is already loaded in hierarchy  */
	bool isHierCashInstr = (DBA_SearchHierRecById(posHierHead,
                                          A_Instr,
						                  A_Instr_Id,
                                          GET_ID(cashInstr, A_Instr_Id)) != nullptr);
    
    /* FIN_UpdRiskPosHier will free if add to hier fails */
    if(isHierCashInstr == false)
    {
        mp.remove(cashInstr);
    }

	if ((ret = FIN_UpdRiskPosHier(posHierHead, domainArgPtr,
		cashPos, cashInstr, (isHierCashInstr) ? (FLAG_T) TRUE : (FLAG_T) FALSE)) != RET_SUCCEED)
	{
		return(ret);
	}

	/* Update link between risk position and cash position */
	if ((ret = DBA_ForceLink(posHierHead, ExtPos,
		                     ExtPos_Acct_ExtPos_Ext, riskPos, cashPos)) != RET_SUCCEED)
	{
		return(ret);
	}

	if (GET_EXTENSION_PTR(riskPos, ExtPos_PosVal_Ext) == NULL ||
	    (valo = *(GET_EXTENSION_PTR(riskPos, ExtPos_PosVal_Ext))) == NULL)
	{
		MSG_SendMesg(RET_DBA_ERR_HIER, 6, FILEINFO, "FIN_AddValoRiskOptCashPos", ExtPos_PosVal_Ext);
		return(RET_DBA_ERR_HIER);
	}

	if (GET_EXTENSION_PTR(cashPos, ExtPos_PosVal_Ext) == NULL ||
	    (cashValo = *(GET_EXTENSION_PTR(cashPos, ExtPos_PosVal_Ext))) == NULL)
	{
		MSG_SendMesg(RET_DBA_ERR_HIER, 6, FILEINFO, "FIN_AddValoRiskOptCashPos", ExtPos_PosVal_Ext);
		return(RET_DBA_ERR_HIER);
	}

	/* REF3209 - Market value should be computed at strike price */
	amt =  GET_NUMBER(riskPos, ExtPos_Qty) * optInfoStp->exerPrice * -1.0;
	exchArgSt.srcAmt = amt;
	FIN_ExchAmt(GET_DATETIME(cashPos, ExtPos_BegDate),
		        optInfoStp->exerCurrId,
		        GET_ID(cashPos,ExtPos_RefCurrId),
		        0, NULL, cashPos, &exchArgSt,
		        NULL, &amt, NULL);	/* PMSTA01649 - TGU - 070405 */
	SET_AMOUNT(cashValo, PosVal_RefNetAmt,       amt);
	SET_AMOUNT(cashValo, PosVal_RefMktValAmt,    amt);
    SET_AMOUNT(cashValo, PosVal_RefAccrInterAmt, 0);

	/* REF3209 - Convert amount in cash position currency */
	exchArgSt.srcAmt = GET_AMOUNT(cashValo, PosVal_RefNetAmt);
	FIN_ExchAmt(GET_DATETIME(cashPos, ExtPos_BegDate),
		        GET_ID(cashPos,ExtPos_RefCurrId),
		        GET_ID(cashPos,ExtPos_PosCurrId),
		        0, NULL, cashPos, &exchArgSt,
		        NULL, &amt, NULL);	/* PMSTA01649 - TGU - 070405 */

	/* Position and instrument currency is same */
	SET_AMOUNT(cashValo, PosVal_PosNetAmt,       amt);
	SET_AMOUNT(cashValo, PosVal_PosMktValAmt,    amt);
    SET_AMOUNT(cashValo, PosVal_PosAccrInterAmt, 0);

	SET_AMOUNT(cashValo, PosVal_InstrNetAmt,       amt);
	SET_AMOUNT(cashValo, PosVal_InstrMktValAmt,    amt);
    SET_AMOUNT(cashValo, PosVal_InstrAccrInterAmt, 0);

	price = 1.0;
	FIN_PriceToQuote((PRICECALCRULE_ENUM)GET_ENUM(cashInstr, A_Instr_PriceCalcRuleEn), 		/* DVP440 */ /* REF7264 - LJE - 020131 */
	                 GET_ID(cashInstr, A_Instr_Id), cashInstr,
			         GET_DATETIME(cashPos, ExtPos_BegDate), NULL,
			         price, &quote, posHierHead);

	SET_PRICE(cashValo, PosVal_Price,       price);
	SET_PRICE(cashValo, PosVal_Quote,       quote);
	SET_ID(cashValo,     PosVal_PriceCurrId, GET_ID(cashPos, ExtPos_PosCurrId));

	SET_PRICE(cashPos, ExtPos_Price, price);
	SET_PRICE(cashPos, ExtPos_Quote, quote);

	/* REF1812 - RAK - 980501 */
	/* REF3209 - Qty should be multiplied by -1, counterparty of risk position */
	/* WEALTH-791 - JPR - 230703 - RefNetAmt should be multiplied by -1, counterparty of risk position*/
	SET_NUMBER(cashPos, ExtPos_Qty,   (GET_AMOUNT(riskPos, ExtPos_InstrNetAmt)*-1.0));
	SET_NUMBER(cashPos, ExtPos_RefNetAmt, (GET_AMOUNT(riskPos, ExtPos_RefNetAmt) * -1.0));

    FIN_GetExchRate(GET_DATETIME(cashPos, ExtPos_BegDate),
	                GET_ID(cashPos, ExtPos_InstrCurrId), GET_ID(cashPos, ExtPos_RefCurrId),
		            (ID_T)0, NULL, cashPos, &exchArgSt, &exch);	/* PMSTA01649 - TGU - 070402 */
    SET_EXCHANGE(cashPos, ExtPos_InstrExchRate, exch);

	FIN_GetExchRate(GET_DATETIME(cashPos, ExtPos_BegDate),
	                GET_ID(cashPos, ExtPos_PosCurrId), GET_ID(cashPos, ExtPos_RefCurrId),
			        (ID_T)0, NULL, cashPos, &exchArgSt, &exch);	/* PMSTA01649 - TGU - 070402 */
	SET_EXCHANGE(cashPos, ExtPos_PosExchRate, exch);

	SET_AMOUNT(cashPos, ExtPos_SupplAmt, 0);

	for (posBpAmtFld = ExtPos_Bp1PosAmt;
	     posBpAmtFld < (ExtPos_Bp1PosAmt+ExtPos_BpPosAmtNb); posBpAmtFld++)
	{
	  	SET_AMOUNT(cashPos, posBpAmtFld, 0.0);
	}

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_AddValoRiskPos()
**
**  Description :   Add risk position in hierarchy and valorise it
**
**  Arguments   :   posHierHead     extended position hierarchy header
**                  domainArgPtr    some domain arguments pointer
**                  riskPos         risk position pointer
**                  instrPtr        instrument pointer
**                  instrHierFlg    TRUE if instrument is already in hierarchy
**                  optExPricePtr   for option, pointer on exercise price and
**				    currency of the option
**                  ctdConvFactPtr  pointer on cheapest to deliver converstion factor or NULL
**                  pricePtr        pointer on structure with calculated price or NULL
**
**  Return      :   RET_SUCCEED or error code
**
**  Modif.      :   DVP190 - RAK - 960830
**  Modif.      :   DVP191 - RAK - 960830
**  Modif.      :   BUG200 - RAK - 961113
**  Modif.      :   DVP510 - RAK - 970618
**  Modif.      :   REF1457 - RAK - 980323
**  Modif.	    :   REF2313 - RAK - 980910
**  Modif.	    :   REF2580 - SSO - 980727
**  Modif.	    :   REF3197 - SSO - 990106
**                  REF5035 - CSY - 020220 fwdAccFlf, futAccFlg, termAccFlg set to FALSE for return and synth admin
**  Modif       :   REF5035 - CSY - 020311: add test domainPtr not null to avoid crash server
**  Modif       :   REF7419 - YST - 020313  - market value for swap
**                  REF11218 - TEB - 050627
**
*************************************************************************/
 EXTERN RET_CODE FIN_AddValoRiskPos(DBA_HIER_HEAD_STP  posHierHead,
				                   FIN_DOMAIN_ARG_STP domainArgPtr,
				                   FIN_AIARG_STP      aiArgPtr,
                                   DBA_DYNFLD_STP     origPos,          /* REF5416 - RAK - 010208 */
                                   DBA_DYNFLD_STP     riskPos,
				                   DBA_DYNFLD_STP     instrPtr,
				                   char               instrHierFlg,
				                   DBA_DYNFLD_STP     totPosRisk,
				                   FIN_PRICEARG_STP   priceArgStp,	    /* REF3030 */
				                   RISK_ANALYSIS_ENUM status,
								   FIN_OPTINFO_STP    optExPricePtr,
				                   NUMBER_T	          *ctdConvFactPtr, 	/* DVP191 */
								   DBA_DYNFLD_STP     inPricePtr,
	                               RISK_QTY_STP       riskQtyStp) /* PMSTA-35133 - RAK - 190517 */
{
	DBA_DYNFLD_STP		pricePtr = nullptr, prPtr=nullptr,
			            valo=nullptr,
			            riskParInstr=nullptr, riskParPos=nullptr, origPosInstr=nullptr;
	FIN_MKTVAL_ST       mktVal;
	DATETIME_T          accrDate;
	ID_T		        priceCurrId=-1; /* REF3197 - SSO - 990106 */
	FIN_OPTINFO_ST    optExPrice;
	PRICE_T            price=1.0, quote;
	AMOUNT_T            tmp, tmpVal;
	EXCHANGE_T          exch, underlyExch, tmpExch;
	RISKOPTVALRULE_ENUM optValRule;
	RISK_VALOPRICE_ENUM riskValoPriceEn;
	char                priceOK; 
	RET_CODE            ret = RET_SUCCEED;  /* PMSTA-37912 - Silpakal - 200102 */
	FIN_EXCHARG_ST      exchArgSt;			/* REF2313 */
    INSTRNAT_ENUM  instrNatEn = InstrNat_None;
    SUBNAT_ENUM    instrSubNatEn = SubNat_None;

	/* PMSTA-35133 - RAK - 190517 - Moved in function as riskQtyStp received as arg */
	if (riskQtyStp != nullptr && riskQtyStp->idxCalcRuleEn == IdxCalcRule_PctValue)
		pricePtr = riskQtyStp->pricePtr;
	else
		pricePtr = inPricePtr;

	memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));	/* REF2313 */
	/*DBA_SetConnectNoToExchArg(&exchArgSt, DBA_GetConnectNoFromHier(posHierHead)); *//* REF2580 - SSO - 980727 */
	DBA_InitConnectNoToExchArg(&exchArgSt, posHierHead); /* REF4213 - SSO - 991221 */

    /* PMSTA-37912 - Silpakal - 200102 */
    if (InstrumentNature::isReverseConvertibleCLN(instrPtr))
    {
        const bool barrierKnockedIn = FALSE == IS_NULLFLD(instrPtr, A_Instr_KnockInDate) &&
            DATE_Cmp(GET_DATETIME(riskPos, ExtPos_ExtPosDate).date, GET_DATE(instrPtr, A_Instr_KnockInDate)) >= 0;

        const bool barrierKnockedOut = FALSE == IS_NULLFLD(instrPtr, A_Instr_KnockOutDate) &&
            DATE_Cmp(GET_DATETIME(riskPos, ExtPos_ExtPosDate).date, GET_DATE(instrPtr, A_Instr_KnockOutDate)) >= 0;

        if ((barrierKnockedIn == TRUE) || (barrierKnockedOut == TRUE))
        {
            return(ret);
        }
    }

	if ((ret = FIN_UpdRiskPosHier(posHierHead, domainArgPtr,
                                  riskPos, instrPtr, instrHierFlg)) != RET_SUCCEED)
		return(ret);

	optExPrice.exerPrice  = 0.0;
	optExPrice.exerCurrId = GET_ID(instrPtr, A_Instr_RefCurrId);
	underlyExch           = 1.0;

	/*** OBTAINS POSITION PRICE ***/
	if ((prPtr = ALLOC_DYNST(A_InstrPrice)) == NULL)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

	/* DVP189 - DVP190 - DVP191 */
	riskValoPriceEn = Risk_ValoPrice_Dflt;

	if (pricePtr != NULL && 		   /* already calculated, use received pricePtr */
	    GET_ID(pricePtr, A_InstrPrice_InstrId) == GET_ID(instrPtr, A_Instr_Id))
	{
		riskValoPriceEn = Risk_ValoPrice_Calc;
	}
	else
	{
	    /* price is computed by difference */
	    if (status==Risk_LastSon &&
            GET_ENUM(instrPtr, A_Instr_ValRuleEn) != ValRule_ParInstr)
		    riskValoPriceEn = Risk_ValoPrice_LastSon;
	    else
	    {
	    	if (GET_ENUM(instrPtr, A_Instr_ValRuleEn) == ValRule_ParInstr)
		        riskValoPriceEn = Risk_ValoPrice_ParPrice;
		    else
		    {
				/* PMSTA-10439 - RAK - 100901 - Add exception for created risk fwd leg */
				/* NB 1 : FWD_VAL_RULE=2 don't use this part of code with the father */
				/* (but treat legs trough TreatCompoRisk()) */
				/* NB 2 : I don't really understand the old code, add shortcuts to */
				/* avoid wrong computation in FIN_ForwardTheoPrice() */
				if (status== Risk_Father &&
					(GET_ENUM(riskPos, ExtPos_RefNatEn) == PosRefNat_FwdOpen ||
					 GET_ENUM(riskPos, ExtPos_RefNatEn) == PosRefNat_FwdClose))
				{
					riskValoPriceEn = Risk_ValoPrice_ParPrice; /* get his own price */
				}
				else
				{
					riskParInstr = NULL;
					if (GET_EXTENSION_PTR(riskPos, ExtPos_RiskPar_A_Instr_Ext) != NULL &&
						(riskParInstr = *(GET_EXTENSION_PTR(riskPos,
							  ExtPos_RiskPar_A_Instr_Ext))) != NULL)
					{
						/* Option position decomposition */
						/* DVP510 - RAK - 970618 */
						instrNatEn = (INSTRNAT_ENUM) GET_ENUM(riskParInstr, A_Instr_NatEn);
						if (instrNatEn == InstrNat_Option ||
							instrNatEn == InstrNat_ExoticOptions ||
							instrNatEn == InstrNat_SwapOptions)
							riskValoPriceEn = Risk_ValoPrice_UnderlyOpt;

						/*** forward and future position decomposition ***/
						if ((INSTRNAT_ENUM) GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_CashAcct)
						{
							if((INSTRNAT_ENUM)
							   GET_ENUM(riskParInstr, A_Instr_NatEn) == InstrNat_Future ||
							   (INSTRNAT_ENUM)
							   GET_ENUM(riskParInstr, A_Instr_NatEn) == InstrNat_FRA)	/* DVP440 */
								riskValoPriceEn = Risk_ValoPrice_Underly;

							if ((INSTRNAT_ENUM)
								GET_ENUM(riskParInstr, A_Instr_NatEn) == InstrNat_Forward)
								riskValoPriceEn = Risk_ValoPrice_Exchange;	/* DVP190 */
						}
						else if((INSTRNAT_ENUM)
								 GET_ENUM(riskParInstr, A_Instr_NatEn) == InstrNat_Future &&
								 ctdConvFactPtr != NULL)
							riskValoPriceEn = Risk_ValoPrice_Cheapest;		/* DVP191 */
					}
				}
	        }
	    }
	}

	switch (riskValoPriceEn)
	{
	case Risk_ValoPrice_LastSon : 			/* price is computed by difference */

        if (GET_EXTENSION_PTR(riskPos, ExtPos_PosVal_Ext) == NULL ||
	        (valo = *(GET_EXTENSION_PTR(riskPos, ExtPos_PosVal_Ext))) == NULL)
	    {
		    MSG_SendMesg(RET_DBA_ERR_HIER, 6, FILEINFO, "FIN_AddValoRiskPos", ExtPos_PosVal_Ext);
		    FREE_DYNST(prPtr, A_InstrPrice);
		    return(RET_DBA_ERR_HIER);
	    }

		/**** COMPUTE ACCRUED INTEREST ****/
		/* REF1457 - fusDateRule, calcAccrInterflg, fullCoupFlg argument are in aiArgPtr, */
		/*           they are initialised in function FIN_PosNetVal().                    */
		/*           Suppressed code was same as this in FIN_PosNetVal().                 */

		if (DATETIME_CMP(GET_DATETIME(riskPos, ExtPos_ExtPosDate),
							GET_DATETIME(riskPos, ExtPos_ValDate)) >= 0)
			accrDate = GET_DATETIME(riskPos, ExtPos_ExtPosDate);
		else
			accrDate = GET_DATETIME(riskPos, ExtPos_ValDate);

		/* BUG200 - Use position currency */
		aiArgPtr->accrRule = AccrRule_None;     /* REF11218 - TEB - 050627 */
		aiArgPtr->useDefinedDateFlg = FALSE;    /* PMSTA08308 - 090609 - PMO */
		if ((ret = FIN_AccrInter(accrDate, GET_ID(riskPos, ExtPos_InstrId), instrPtr,
									GET_ID(riskPos, ExtPos_PosCurrId), aiArgPtr,
									GET_NUMBER(riskPos, ExtPos_Qty),
									riskPos, &mktVal, posHierHead)) != RET_SUCCEED)
		{
			FREE_DYNST(prPtr, A_InstrPrice);
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		SET_AMOUNT(valo, PosVal_PosAccrInterAmt, mktVal.accrInterRefCurr)

		if (GET_ID(riskPos, ExtPos_RefCurrId) != GET_ID(riskPos, ExtPos_PosCurrId))
		{
			/* REF2313 */
			exchArgSt.srcAmt = mktVal.accrInterRefCurr;
			FIN_ExchAmt(accrDate, GET_ID(riskPos, ExtPos_PosCurrId),
						GET_ID(riskPos, ExtPos_RefCurrId),
						0, NULL, riskPos, &exchArgSt,
						NULL, &tmpVal, &tmpExch);	/* PMSTA01649 - TGU - 070405 */
			SET_AMOUNT(valo, PosVal_RefAccrInterAmt, tmpVal);
			SET_EXCHANGE(valo, PosVal_PosExchRate, tmpExch);
		}
		else
		{
			SET_AMOUNT(valo,   PosVal_RefAccrInterAmt, mktVal.accrInterRefCurr);
			SET_EXCHANGE(valo, PosVal_PosExchRate,     1.0);
		}

	    FIN_GetExchRate(accrDate, mktVal.accrInterCurrId, GET_ID(riskPos, ExtPos_RefCurrId),
			            (ID_T)0, NULL, riskPos, &exchArgSt, &tmpExch);	/* PMSTA01649 - TGU - 070402 */
	    SET_EXCHANGE(valo, PosVal_AccrInterExchRate, tmpExch);
	    SET_ID(valo,       PosVal_AccrInterCurrId,   mktVal.accrInterCurrId);

	    SET_SMALLINT(valo, PosVal_AccrInterNumPeriod,
			               (SMALLINT_T) mktVal.accrInterPeriod.num);
	    SET_SMALLINT(valo, PosVal_AccrInterDenomPeriod,
		                   (SMALLINT_T) mktVal.accrInterPeriod.denom);

		/* PMSTA-35133 - RAK - 190517 - New risk computation for FX fwd and Tarko */
		if (riskQtyStp != nullptr && riskQtyStp->STNEn == StnSpecific_FXTarkoOption)
		{
			SET_AMOUNT(valo, PosVal_PosMktValAmt, GET_NUMBER(riskPos, ExtPos_Qty));

			exchArgSt.srcAmt = GET_AMOUNT(valo, PosVal_PosMktValAmt);
			FIN_ExchAmt(domainArgPtr->fromDateTime,
				GET_ID(riskPos, ExtPos_PosCurrId),
				GET_ID(riskPos, ExtPos_RefCurrId),
				0, NULL, riskPos, &exchArgSt,
				NULL, &tmp, &exch);
			SET_AMOUNT(valo, PosVal_RefMktValAmt, tmp);
		}
		else
		{
			/*  FPL-PMSTA13033-111102 */
			if (GET_ID(totPosRisk, RiskAmt_PosCurrId) != GET_ID(riskPos, ExtPos_PosCurrId))
			{
				exchArgSt.srcAmt = GET_AMOUNT(totPosRisk, RiskAmt_PosMktValAmt);
				FIN_ExchAmt(domainArgPtr->fromDateTime,
					GET_ID(totPosRisk, RiskAmt_PosCurrId),
					GET_ID(riskPos, ExtPos_PosCurrId),
					0, NULL, riskPos, &exchArgSt,
					NULL, &tmp, &exch);
				SET_AMOUNT(valo, PosVal_PosMktValAmt, tmp);
			}
			else
			{
				/* Market values */
				SET_AMOUNT(valo, PosVal_PosMktValAmt,
					GET_AMOUNT(totPosRisk, RiskAmt_PosMktValAmt));
			}
			SET_AMOUNT(valo, PosVal_RefMktValAmt,
				GET_AMOUNT(totPosRisk, RiskAmt_RefMktValAmt));
		}

	    /* Instrument market value and accrued interest */
	    if (GET_ID(instrPtr, A_Instr_RefCurrId) != GET_ID(riskPos, ExtPos_RefCurrId))
	    {
		    /* REF2313 */
		    exchArgSt.srcAmt = GET_AMOUNT(valo, PosVal_RefMktValAmt);
		    FIN_ExchAmt(domainArgPtr->fromDateTime,
			            GET_ID(riskPos, ExtPos_RefCurrId),
			            GET_ID(instrPtr, A_Instr_RefCurrId),
			            0, NULL, riskPos, &exchArgSt,
			            NULL, &tmp, &exch);	/* PMSTA01649 - TGU - 070405 */
		    SET_AMOUNT(valo, PosVal_InstrMktValAmt, tmp);   /*  FPL-PMSTA13033-111102 previousely set bad value: PosVal_InstrNetAmt */

		    exch = 1 / exch;
		    SET_EXCHANGE(valo, PosVal_InstrExchRate, exch);

		    /* REF2313 */
		    exchArgSt.srcAmt = GET_AMOUNT(valo, PosVal_RefAccrInterAmt);
		    FIN_ExchAmt(domainArgPtr->fromDateTime,
			            GET_ID(riskPos, ExtPos_RefCurrId),
			            GET_ID(instrPtr, A_Instr_RefCurrId),
			            0, NULL, riskPos, &exchArgSt,
			            NULL, &tmp, NULL);	/* PMSTA01649 - TGU - 070405 */
		    SET_AMOUNT(valo, PosVal_InstrAccrInterAmt, tmp);
	    }
	    else
	    {
		    SET_AMOUNT(valo,   PosVal_InstrMktValAmt,    GET_AMOUNT(valo, PosVal_RefMktValAmt));
		    SET_AMOUNT(valo,   PosVal_InstrAccrInterAmt, GET_AMOUNT(valo, PosVal_RefAccrInterAmt));
		    SET_EXCHANGE(valo, PosVal_InstrExchRate,     1.0);
	    }

	    /* REF7419 - YST - 020313 - Net values are equal to market values for swap legs */
        instrNatEn = (INSTRNAT_ENUM) GET_ENUM(instrPtr, A_Instr_NatEn);
        instrSubNatEn = (SUBNAT_ENUM) GET_ENUM(instrPtr, A_Instr_SubNatEn);

        if (InstrNat_Bond == instrNatEn &&
           (SubNat_RecSwapFixedLeg == instrSubNatEn || SubNat_RecSwapFloatLeg == instrSubNatEn ||
           SubNat_PaidSwapFixedLeg == instrSubNatEn || SubNat_PaidSwapFloatLeg == instrSubNatEn))
        {
            SET_AMOUNT(valo, PosVal_PosNetAmt, GET_AMOUNT(valo, PosVal_PosMktValAmt));
            SET_AMOUNT(valo, PosVal_RefNetAmt, GET_AMOUNT(valo, PosVal_RefMktValAmt));
            SET_AMOUNT(valo, PosVal_InstrNetAmt, GET_AMOUNT(valo, PosVal_InstrMktValAmt));
        }
        else
        {
	        tmp = GET_AMOUNT(valo, PosVal_PosMktValAmt) - GET_AMOUNT(valo, PosVal_PosAccrInterAmt);
	        SET_AMOUNT(valo, PosVal_PosNetAmt, tmp);
	        tmp = GET_AMOUNT(valo, PosVal_RefMktValAmt) - GET_AMOUNT(valo, PosVal_RefAccrInterAmt);
	        SET_AMOUNT(valo, PosVal_RefNetAmt, tmp);
	        tmp = GET_AMOUNT(valo, PosVal_InstrMktValAmt) - GET_AMOUNT(valo, PosVal_InstrAccrInterAmt);
	        SET_AMOUNT(valo, PosVal_InstrNetAmt, tmp);
        }

	    /* Price informations */
	    /* REF3719 - SSO - 990602 : avoid div. by zero.. */
		/* PMSTA-35133 - RAK - 190517 - New risk computation for FX fwd and Tarko */
		if (riskQtyStp == nullptr || riskQtyStp->STNEn != StnSpecific_FXTarkoOption)
		{
			if (CMP_NUMBER(GET_NUMBER(riskPos, ExtPos_Qty), 0.0) != 0)
			{
				price = GET_AMOUNT(valo, PosVal_PosNetAmt) / GET_NUMBER(riskPos, ExtPos_Qty);
			}
			else
			{
				price = 0.0;
			}
		}

        SET_PRICE(valo,   PosVal_Price,            CAST_PRICE(price)); /* REF3288 - SSO - 990205 */

		/* PMSTA16573 - DDV - 130627 - Compute quote using instrument's price calc rule */
		FIN_PriceToQuote((PRICECALCRULE_ENUM)GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn), 		/* DVP440 */ /* REF7264 - LJE - 020131 */
				         GET_ID(instrPtr, A_Instr_Id), instrPtr,
				         GET_DATETIME(riskPos, ExtPos_BegDate), NULL,
					     GET_PRICE(valo,   PosVal_Price), &quote, posHierHead);

        SET_PRICE(valo,   PosVal_Quote,            quote); /* REF3288 - SSO - 990205 */

		SET_ID(valo,       PosVal_PriceCurrId,      GET_ID(riskPos, ExtPos_PosCurrId));
        SET_DATETIME(valo, PosVal_QuoteDate,        domainArgPtr->fromDateTime);
	    SET_ENUM(valo,     PosVal_PriceCalcRuleEn,  GET_ENUM(instrPtr,A_Instr_PriceCalcRuleEn));
	    SET_EXCHANGE(valo, PosVal_PriceExchRate,    1.0);
        SET_NULL_ID(valo,  PosVal_PriceTpId);
        SET_NULL_ID(valo,  PosVal_PriceThirdId);
        SET_NULL_ID(valo,  PosVal_TermTpId);

	    FREE_DYNST(prPtr, A_InstrPrice);
	    return(RET_SUCCEED);

        break;

	case Risk_ValoPrice_ParPrice : 		/* parent price */

        if (GET_EXTENSION_PTR(riskPos, ExtPos_RiskOrigin_ExtPos_Ext) != NULL &&
	        (riskParPos = *(GET_EXTENSION_PTR(riskPos, ExtPos_RiskOrigin_ExtPos_Ext))) != NULL)
	    {
	   	    if (GET_EXTENSION_PTR(riskParPos, ExtPos_PosVal_Ext) != NULL &&
	   	        (valo = *(GET_EXTENSION_PTR(riskParPos, ExtPos_PosVal_Ext))) != NULL)
		    {
		        price = GET_PRICE(valo, PosVal_Price);
		        priceCurrId = GET_ID(valo, PosVal_PriceCurrId); /* REF3197 - SSO - 990106 */
		    }
		    else
		    {
		        price = 1.0;
		    }
	    }
	    else
	    {
		    price = 1.0;
	    }

	    SET_PRICE(prPtr, A_InstrPrice_Price,           price);
	    SET_ENUM(prPtr,   A_InstrPrice_PriceCalcRuleEn, GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn));

	    FIN_PriceToQuote((PRICECALCRULE_ENUM)GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn), 	/* DVP440 */ /* REF7264 - LJE - 020131 */
			             GET_ID(instrPtr, A_Instr_Id), instrPtr,
                         domainArgPtr->fromDateTime,
			             NULL, GET_PRICE(prPtr, A_InstrPrice_Price), &price, posHierHead);

	    SET_PRICE(prPtr, A_InstrPrice_Quote, price);

	    if (priceCurrId == -1) /* REF3197 - SSO - 990106 */
	    {
		    priceCurrId = GET_ID(totPosRisk, RiskAmt_PosCurrId);
	    }

        SET_ID(prPtr,       A_InstrPrice_CurrId,    priceCurrId);
	    SET_DATETIME(prPtr, A_InstrPrice_QuoteDate, domainArgPtr->fromDateTime);
	    SET_NULL_ID(prPtr,  A_InstrPrice_TpId);
	    SET_NULL_ID(prPtr,  A_InstrPrice_ThirdId);
	    SET_NULL_ID(prPtr,  A_InstrPrice_TermTpId);

	    ret = RET_SUCCEED;
	    break;

	/* Price is underlying price at begin date of the position */
	/* or exercise price of the option founded in term event   */
	case Risk_ValoPrice_UnderlyOpt : 	/* options */

        /* PMSTA-52520 - JPR - 230529 - Valution of an option on a future instrument is wrong*/
        if (GET_EXTENSION_PTR(origPos, ExtPos_A_Instr_Ext) != NULL &&
            (origPosInstr = *(GET_EXTENSION_PTR(origPos, ExtPos_A_Instr_Ext))) != NULL &&
            (INSTRNAT_ENUM)GET_ENUM(origPosInstr, A_Instr_NatEn) != InstrNat_Option)    /* WEALTH-812 - JPR - 290720*/
        {
            ret = FIN_PosPrice(riskPos, instrPtr, domainArgPtr->fromDateTime,
                priceArgStp, prPtr, NULL, posHierHead);
			/* WEALTH-8223 - KKM - 29082024 */
			GEN_GetApplInfo(ApplRiskOptValRule, &optValRule);
			if (optValRule == RiskOptValRule_ExercisePrice)
			{
				SET_PRICE(prPtr, A_InstrPrice_Quote, optExPricePtr->exerPrice);
				SET_PRICE(prPtr, A_InstrPrice_Price, optExPricePtr->exerPrice);
				SET_ID(prPtr, A_InstrPrice_CurrId, optExPricePtr->exerCurrId);
				SET_DATETIME(prPtr, A_InstrPrice_QuoteDate, domainArgPtr->fromDateTime);
				SET_NULL_ID(prPtr, A_InstrPrice_TpId);
				SET_NULL_ID(prPtr, A_InstrPrice_ThirdId);
				SET_NULL_ID(prPtr, A_InstrPrice_TermTpId);
				SET_ENUM(prPtr, A_InstrPrice_PriceCalcRuleEn,
					     GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn));
			}
        }
        else
        {
            GEN_GetApplInfo(ApplRiskOptValRule, &optValRule);
            switch (optValRule)
            {
            case RiskOptValRule_UnderlyPrice :
                ret = FIN_PosPrice(riskPos, instrPtr, domainArgPtr->fromDateTime,
                                   priceArgStp, prPtr, NULL, posHierHead);
                break;

            case RiskOptValRule_ExercisePrice :
                if (optExPricePtr == (FIN_OPTINFO_STP)NULL)
                {
                    MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
                                 "FIN_AddValoRiskPos", "optExPricePtr");
                    optExPricePtr = &optExPrice;
                }

                SET_PRICE(prPtr,   A_InstrPrice_Quote,     optExPricePtr->exerPrice);
                SET_PRICE(prPtr,   A_InstrPrice_Price,     optExPricePtr->exerPrice);
                SET_ID(prPtr,       A_InstrPrice_CurrId,    optExPricePtr->exerCurrId);
                SET_DATETIME(prPtr, A_InstrPrice_QuoteDate, domainArgPtr->fromDateTime);
                SET_NULL_ID(prPtr,  A_InstrPrice_TpId);
                SET_NULL_ID(prPtr,  A_InstrPrice_ThirdId);
                SET_NULL_ID(prPtr,  A_InstrPrice_TermTpId);
                SET_ENUM(prPtr,     A_InstrPrice_PriceCalcRuleEn,
                    GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn));
                ret = RET_SUCCEED;
                break;

            /* ?? */
            case RiskOptValRule_UnderlyDelta :
                if (optExPricePtr == (FIN_OPTINFO_STP)NULL)
                {
                    MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
                                 "FIN_AddValoRiskPos", "optExPricePtr");
                    optExPricePtr = &optExPrice;
                }

                SET_PRICE(prPtr,   A_InstrPrice_Quote,     optExPricePtr->exerPrice);
                SET_PRICE(prPtr,   A_InstrPrice_Price,     optExPricePtr->exerPrice);
                SET_ID(prPtr,       A_InstrPrice_CurrId,    optExPricePtr->exerCurrId);
                SET_DATETIME(prPtr, A_InstrPrice_QuoteDate, domainArgPtr->fromDateTime);
                SET_NULL_ID(prPtr,  A_InstrPrice_TpId);
                SET_NULL_ID(prPtr,  A_InstrPrice_ThirdId);
                SET_NULL_ID(prPtr,  A_InstrPrice_TermTpId);
                SET_ENUM(prPtr,     A_InstrPrice_PriceCalcRuleEn,
                    GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn));
                ret = RET_SUCCEED;
                break;
            }
        }
        break;

	case Risk_ValoPrice_Underly : 		/* future on cash accounts */

        SET_PRICE(prPtr,   A_InstrPrice_Quote,     underlyExch);
	    SET_PRICE(prPtr,   A_InstrPrice_Price,     underlyExch);
	    SET_ID(prPtr,       A_InstrPrice_CurrId,    GET_ID(instrPtr,A_Instr_RefCurrId));
	    SET_DATETIME(prPtr, A_InstrPrice_QuoteDate, domainArgPtr->fromDateTime);
	    SET_NULL_ID(prPtr,  A_InstrPrice_TpId);
	    SET_NULL_ID(prPtr,  A_InstrPrice_ThirdId);
        SET_NULL_ID(prPtr,  A_InstrPrice_TermTpId);
	    SET_ENUM(prPtr,     A_InstrPrice_PriceCalcRuleEn,
            GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn));
	    ret = RET_SUCCEED;
	    break;

	/* DVP190 */
	case Risk_ValoPrice_Exchange :		/* forward on cash accounts */
        {
            ID_T           defaultValuationRuleId;
            FLAG_T         futAccFlg, fwdAccFlg, termAccFlg, isFwdValRulePoint=FALSE, isTheoriticalInstrument=FALSE;
            NUMBER_T       discFac=1.0;
            DBA_DYNFLD_STP domainPtr = DBA_GetDomainPtr(DBA_GetConnectNoFromHier(posHierHead));  /* REF5035 - CSY - 020220 */

			/* PMSTA-13140 - LJE - 120319 */
			FIN_GetAccFlag(domainPtr,
	     				   riskPos,
						   &futAccFlg,
						   &fwdAccFlg,
						   &termAccFlg);

            riskParInstr = NULL;
		    if (GET_EXTENSION_PTR(riskPos, ExtPos_RiskPar_A_Instr_Ext) != NULL &&
	            (riskParInstr = *(GET_EXTENSION_PTR(riskPos, ExtPos_RiskPar_A_Instr_Ext))) != NULL)
            {
                FIN_GetAdAMInfoForInstr(riskParInstr, &defaultValuationRuleId,
                                        &isFwdValRulePoint, &isTheoriticalInstrument);

				/* PMSTA-10345 - RAK - 100816 Wrong valo for quoted fwd */
                if (isFwdValRulePoint == TRUE && isTheoriticalInstrument == TRUE)
                {
                    DBA_DYNFLD_STP origValo = NULL;
		            if (GET_EXTENSION_PTR(origPos, ExtPos_PosVal_Ext) != NULL &&
	                (origValo = *(GET_EXTENSION_PTR(origPos, ExtPos_PosVal_Ext))) != NULL)
                    {
                        if (fwdAccFlg == TRUE) /* DiscFac don't computed */
                        {
							/* PMSTA-8736 - RAK - 100202 */
							/* Here call the new function to compute the price */
							/* of the leg1 according to discfac. */
							ret = SCE_DiscForwDisc(posHierHead, instrPtr,
												   GET_DATETIME(domainPtr, A_Domain_InterpFromDate),
								                   &discFac);
						}
                        else				/* DiscFac already computed so use information to get it */
                        {
                            /* compute discFac with known informations */
                            discFac = GET_NUMBER(origPos, ExtPos_Qty) *
                                      GET_EXCHANGE(origValo, PosVal_PriceExchRate);

                            if (CMP_NUMBER(discFac, 0.0) != 0)
                            {
                                discFac = GET_AMOUNT(origValo, PosVal_RefMktValAmt) / discFac;

                                discFac = discFac / GET_PRICE(origValo, PosVal_Price);
                            }
                            else
                                discFac = 1.0;
                        }

                        SET_NUMBER(prPtr, A_InstrPrice_DiscFac, discFac);
                    }
                }
            }

            SET_PRICE(prPtr,   A_InstrPrice_Quote,     1.0);
	        SET_PRICE(prPtr,   A_InstrPrice_Price,     1.0);
	        SET_ID(prPtr,       A_InstrPrice_CurrId,    GET_ID(instrPtr,A_Instr_RefCurrId));
	        SET_DATETIME(prPtr, A_InstrPrice_QuoteDate, domainArgPtr->fromDateTime);
	        SET_NULL_ID(prPtr,  A_InstrPrice_TpId);
	        SET_NULL_ID(prPtr,  A_InstrPrice_ThirdId);
            SET_NULL_ID(prPtr,  A_InstrPrice_TermTpId);
	        SET_ENUM(prPtr,     A_InstrPrice_PriceCalcRuleEn,
                GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn));
	        ret = RET_SUCCEED;
        }
	    break;

	/* DVP191 */
	case Risk_ValoPrice_Cheapest : 		/* future on cheapest to deliver instrument */

        priceOK = FALSE;
	    riskParPos = NULL;
	    if (GET_EXTENSION_PTR(riskPos, ExtPos_RiskOrigin_ExtPos_Ext) != NULL &&
	        (riskParPos = *(GET_EXTENSION_PTR(riskPos, ExtPos_RiskOrigin_ExtPos_Ext))) != NULL)
	    {
		    valo = NULL;
		    if (GET_EXTENSION_PTR(riskParPos, ExtPos_PosVal_Ext) != NULL &&
	            (valo = *(GET_EXTENSION_PTR(riskParPos, ExtPos_PosVal_Ext))) != NULL)
		    {
		        price = GET_PRICE(valo, PosVal_Price);
		        priceOK = TRUE;
		    }
	    }

	    if (priceOK == TRUE && *ctdConvFactPtr != 0.0)
	    {
		    price *= (*ctdConvFactPtr);

		    FIN_PriceToQuote((PRICECALCRULE_ENUM)GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn), 	/* DVP440 */ /* REF7264 - LJE - 020131 */
		                     GET_ID(instrPtr, A_Instr_Id), instrPtr,
				             domainArgPtr->fromDateTime, NULL, price, &quote, posHierHead);

		    SET_PRICE(prPtr,   A_InstrPrice_Price,     CAST_PRICE(price)); /* REF3288 - SSO - 990205 */
		    SET_PRICE(prPtr,   A_InstrPrice_Quote,     CAST_PRICE(quote)); /* REF3288 - SSO - 990205 */
		    SET_ID(prPtr,       A_InstrPrice_CurrId,    GET_ID(instrPtr, A_Instr_RefCurrId));
		    SET_DATETIME(prPtr, A_InstrPrice_QuoteDate, domainArgPtr->fromDateTime);
		    SET_NULL_ID(prPtr,  A_InstrPrice_TpId);
		    SET_NULL_ID(prPtr,  A_InstrPrice_ThirdId);
		    SET_NULL_ID(prPtr,  A_InstrPrice_TermTpId);
		    SET_ENUM(prPtr,     A_InstrPrice_PriceCalcRuleEn,
		        GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn));
		    ret = RET_SUCCEED;
	    }
	    else
	    {
	 	    ret = FIN_PosPrice(riskPos, instrPtr, domainArgPtr->fromDateTime,
				               priceArgStp, prPtr, NULL, posHierHead);
	    }
	    break;

	case Risk_ValoPrice_Dflt :		/* FIN_PosPrice() call */

	    ret = FIN_PosPrice(riskPos, instrPtr, domainArgPtr->fromDateTime,
			               priceArgStp, prPtr, NULL, posHierHead);
	    break;

	case Risk_ValoPrice_Calc :		/* already calculated, use received pricePtr */

        COPY_DYNST(prPtr, pricePtr, A_InstrPrice);
	    ret = RET_SUCCEED;
	    break;
	}

	/* Stop if error occurs (all cases except LastSon) */
	if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
	{
	    FREE_DYNST(prPtr, A_InstrPrice);
	    return(ret);
	}

	/* PMSTA-35276 - Silpakal -190325 */
	if (InstrumentNature::isDiscountCertificates(instrPtr))
	{
		PRICE_T  newPrice = 0;
		newPrice = GET_PRICE(prPtr, A_InstrPrice_Price) * 100;
		SET_PRICE(prPtr, A_InstrPrice_Price, newPrice);
	}
    
	/*** COPY PRICE IN POSITION ***/
	if (FIN_SetPriceToPos(domainArgPtr->fromDateTime, domainArgPtr->refCurrId,
			              riskPos, prPtr, posHierHead) == TRUE) /* REF2580 - SSO - 980727 */
	{
	    /*** COMPUTE POSITION NET VALUE ***/
	    ret = FIN_PosNetVal(posHierHead, domainArgPtr, riskPos, NULL, aiArgPtr);
	}

   	if (status != Risk_Cash && status != Risk_Father)
	{
	    if (GET_EXTENSION_PTR(riskPos, ExtPos_PosVal_Ext) == NULL ||
	        (valo = *(GET_EXTENSION_PTR(riskPos, ExtPos_PosVal_Ext))) == NULL)
	    {
		    MSG_SendMesg(RET_DBA_ERR_HIER, 6, FILEINFO, "FIN_AddValoRiskPos", ExtPos_PosVal_Ext);
	    	FREE_DYNST(prPtr, A_InstrPrice);
		    return(RET_DBA_ERR_HIER);
	    }

	    /* Compute last son's amounts */
		/* PMSTA15709 - DDV - 130305 - If risk position currency is not the same than accounting position, apply exchange rate to compute pos amount*/
		if (GET_ID(riskPos, ExtPos_PosCurrId) != GET_ID(totPosRisk, RiskAmt_PosCurrId))
		{
			memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));

			DBA_InitConnectNoToExchArg(&exchArgSt, posHierHead);
	   		ret = FIN_GetExchRate(GET_DATETIME(valo, PosVal_Date),
								  GET_ID(riskPos, ExtPos_PosCurrId), GET_ID(totPosRisk, RiskAmt_PosCurrId),
								  (ID_T)0, NULL, riskPos, &exchArgSt, &exch);	/* PMSTA01649 - TGU - 070402 */

    		if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
				return(ret);
		}
		else
			exch=1.0;


	    tmp = GET_AMOUNT(totPosRisk, RiskAmt_PosMktValAmt) -
	          GET_AMOUNT(valo, PosVal_PosMktValAmt) * exch;
	    SET_AMOUNT(totPosRisk, RiskAmt_PosMktValAmt, tmp);

	    tmp = GET_AMOUNT(totPosRisk, RiskAmt_RefMktValAmt) -
	          GET_AMOUNT(valo, PosVal_RefMktValAmt);
	    SET_AMOUNT(totPosRisk, RiskAmt_RefMktValAmt, tmp);
	}

	FREE_DYNST(prPtr, A_InstrPrice);
	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_ComputeRiskAmt()
**
**  Description :   Compute with ratio from original position amount
**                  all sons amount, for the last, use the difference between
**                  original total and sons amount.
**                  If asked, modify risk position with computed amount
**
**  Arguments   :   origPos        original position pointer
**                  riskPos        risk position pointer
**                  fld            position field number to update
**                  ratio          ratio to apply
**                  initCurrId     original position currency identifier
**                  riskCurrId     risk position currency identifier
**                  totPosRisk     risk totalizator pointer
**                  totFld         totalizator field number to update
**                  status         risk status (LastSon, Son, Father, Extra)
**
**  Return      :   RET_SUCCEED or error code
**
**  Modif.	    :   REF2313 - RAK - 980910
**  Modif.	    :   REF2580 - SSO - 980727
**  Modif.		:   PMSTA-38541 -Silpakal -200313
**
*************************************************************************/
STATIC RET_CODE FIN_ComputeRiskAmt(DBA_DYNFLD_STP     origPos,
				                   DBA_DYNFLD_STP     riskPos,
				                   int                fld,
				                   NUMBER_T           ratio,
				                   ID_T               initCurrId,
				                   ID_T               riskCurrId,
				                   DBA_DYNFLD_STP     totPosRisk,
				                   int                totFld,
				                   RISK_ANALYSIS_ENUM status,
				                   DBA_HIER_HEAD_STP  posHierHead)
{
	AMOUNT_T amt, tot;
	
	/* PMSTA-38541 -Silpakal -200313 */	
	FLAG_T				allocOk = FALSE;
	DBA_DYNFLD_STP      instrPtr = NULL;
	INSTR_CLASS_ENUM    instrInstrClass = INSTR_CLASS_ENUM::None;
	RET_CODE			ret = RET_SUCCEED;

	if (status == Risk_LastSon)
	{
		amt = GET_AMOUNT(totPosRisk, totFld);
	}
	else
	{
		amt = GET_AMOUNT(origPos, fld) * ratio;
		tot = GET_AMOUNT(totPosRisk, totFld) - amt;
		SET_AMOUNT(totPosRisk, totFld, tot);
	}

	/* PMSTA-38541 -Silpakal -200313 */	
	if ((ret = DBA_GetInstrById(GET_ID(origPos, ExtPos_InstrId), FALSE, &allocOk,
								&instrPtr, posHierHead, UNUSED, UNUSED)) == RET_SUCCEED)
	{
		instrInstrClass = (INSTR_CLASS_ENUM)GET_ENUM(instrPtr, A_Instr_InstrumentClassEn);
	}

	if ((riskPos != NULL) && (instrInstrClass != INSTR_CLASS_ENUM::StructuredProduct_StandAlone))
	{
		if (riskCurrId != initCurrId)
		{
			/* REF2313 */
    		FIN_EXCHARG_ST    exchArgSt;
    		memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));
			/*DBA_SetConnectNoToExchArg(&exchArgSt, DBA_GetConnectNoFromHier(posHierHead)); */ /* REF2580 - SSO - 980727 */
			DBA_InitConnectNoToExchArg(&exchArgSt, posHierHead); /* REF4213 - SSO - 991221 */

			exchArgSt.srcAmt = amt;
			FIN_ExchAmt(GET_DATETIME(origPos, ExtPos_BegDate),
			            initCurrId, riskCurrId,
				        0, NULL, riskPos, &exchArgSt,
			            NULL, &amt, NULL);	/* PMSTA01649 - TGU - 070405 */
		}
		SET_AMOUNT(riskPos, fld, amt);
	}

	if (allocOk == TRUE) 
	{ 
		FREE_DYNST(instrPtr, A_Instr); 
	}

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_CreateInstrDiscount()
**
**  Description :   Create a discount
**
**  Arguments   :   newPtr  	pointer on new instrument
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation	:   DVP440 - RAK - 970428
**  Modif.  	:   REF495 - RAK - 980520
**
*************************************************************************/
STATIC RET_CODE FIN_CreateInstrDiscount(DBA_HIER_HEAD_STP   hierHead,
                                        DBA_DYNFLD_STP      underPtr,
					                    DATE_T              begDate,
                                        DATE_T              endDate,
                                        DBA_DYNFLD_STP      *newPtr)
{
	RET_CODE	ret;

	if ((*newPtr = ALLOC_DYNST(A_Instr)) == NULL)
	{ MSG_RETURN(RET_MEM_ERR_ALLOC); }

	COPY_DYNST((*newPtr), underPtr, A_Instr);

	SET_NULL_ID((*newPtr), A_Instr_Id);

	SET_ENUM((*newPtr),   A_Instr_NatEn,       (ENUM_T) InstrNat_Discount);
	SET_ENUM((*newPtr),   A_Instr_ValRuleEn,   (ENUM_T) ValRule_Theo);
	SET_NUMBER((*newPtr), A_Instr_RedempQuote, 100.0);
	SET_PRICE((*newPtr), A_Instr_RedempPrice, 1.0);
	SET_DATE((*newPtr),   A_Instr_EndDate,     endDate);
	SET_DATE((*newPtr),   A_Instr_BeginDate,     begDate);
	SET_FLAG((*newPtr),   A_Instr_GenericFlg,  FALSE);

	if (hierHead != (DBA_HIER_HEAD_STP) NULL)
	{
	    if ((ret = DBA_AddHierRecord(hierHead, (*newPtr), A_Instr, FALSE,
					                 HierAddRec_NoLnk)) != RET_SUCCEED)
	    {
		    FREE_DYNST((*newPtr), A_Instr);
		    return(ret);
	    }
	    SET_ID((*newPtr), A_Instr_ParentInstrId, GET_ID(underPtr, A_Instr_Id));
	}

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_CreateInstrMoneyMkt()
**
**  Description :   Create a money market
**
**  Arguments   :   hierHead    hierarchy header
**		            infoStp	    money market information pointer
**		            newPtr  	pointer on new instrument
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation	:   DVP440 - RAK - 970428
**
*************************************************************************/
STATIC RET_CODE FIN_CreateInstrMoneyMkt(DBA_HIER_HEAD_STP    hierHead,
					                    FIN_MONEYMKTINFO_STP infoStp,
					                    DBA_DYNFLD_STP       *newPtr)
{
	RET_CODE	ret;
	FLAG_T		*scptFlagTab=NULL;

	if ((*newPtr = ALLOC_DYNST(A_Instr)) == NULL)
	{ MSG_RETURN(RET_MEM_ERR_ALLOC); }

	/* Load and initialise flag array for script */
	if ((scptFlagTab = (FLAG_T *)CALLOC(GET_FLD_NBR(A_Instr), sizeof(FLAG_T))) == NULL) /* REF7264 - LJE - 020131 */
	{
	    FREE_DYNST((*newPtr), A_Instr);
	    MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ScriptFlag");
	    return(RET_MEM_ERR_ALLOC);
	}

	SET_ENUM((*newPtr),    A_Instr_NatEn,         (ENUM_T) InstrNat_MoneyMkt);
	SET_CODE((*newPtr),    A_Instr_Cd,            infoStp->code);
	SET_NAME((*newPtr),    A_Instr_Name,          infoStp->name);
	SET_DATE((*newPtr),    A_Instr_BeginDate,       infoStp->begDate.date);
	SET_DATE((*newPtr),    A_Instr_EndDate,       infoStp->endDate.date);
	SET_PERCENT((*newPtr), A_Instr_InterestRateP, infoStp->rate);
	SET_ENUM((*newPtr),    A_Instr_AccrualRuleEn,    (ENUM_T) infoStp->accrRuleEn);
	SET_ID((*newPtr),      A_Instr_RefCurrId,     infoStp->currId);
	SET_ENUM((*newPtr),    A_Instr_ValRuleEn,     infoStp->valRuleEn);	/* REF53.1 */

	scptFlagTab[A_Instr_NatEn]         = TRUE;
	scptFlagTab[A_Instr_Cd]            = TRUE;
	scptFlagTab[A_Instr_Name]          = TRUE;
	scptFlagTab[A_Instr_BeginDate]       = TRUE;
	scptFlagTab[A_Instr_EndDate]       = TRUE;
	scptFlagTab[A_Instr_InterestRateP] = TRUE;
	scptFlagTab[A_Instr_AccrualRuleEn]    = TRUE;
	scptFlagTab[A_Instr_RefCurrId]     = TRUE;
	scptFlagTab[A_Instr_ValRuleEn]     = TRUE;

	/* Default Values */
	if ((ret = SCPT_ComputeDV(Instr, scptFlagTab, (*newPtr), TRUE, TRUE, NULL)) != 0)/* REF4229 - SSO - 000919 */
	{
	    FREE_DYNST((*newPtr), A_Instr);
	    FREE(scptFlagTab);
	    return(ret);
	}
	FREE(scptFlagTab);

	if (hierHead != (DBA_HIER_HEAD_STP) NULL)
	{
	    if ((ret = DBA_AddHierRecord(hierHead, (*newPtr), A_Instr, FALSE,
					                 HierAddRec_NoLnk)) != RET_SUCCEED)
	    {
		    FREE_DYNST((*newPtr), A_Instr);
		    return(ret);
	    }

	    SET_ID((*newPtr), A_Instr_ParentInstrId, infoStp->underlyId);
	}

	/* Free all Script for Default Values */
	SCPT_FreeScriptDV(NullEntity); /* PMSTA06772 - 080619 - DDV */

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_CreateRiskAmt()
**
**  Description :   Read original position amounts for initialize
**                  risk amounts to total amounts
**
**  Arguments   :   origPos           original position pointer
**
**  Return      :   NULL or pointer on risk amount structure
**
**  Modif.      :   REF5416 - RAK - 010118 - new arg posHierHead
**                  REF5035 - CSY - 020220 fwdAccFlg, futAccFlg, termAccFlg set to FALSE for return and synth admin
**  Modif:          REF5035 - CSY - 020311: add test domainPtr not null
**                  REF6057 - YST - 021010: I hope this is the last modification for this incident
**                  PMSTA-4559 - 011107 - PMO : Futures Management (margin calls)
**                  PMSTA-17898 - 160414 - PMO : New Fusion Criteria to manage the contract dates for margin calls after partial closing
**
*************************************************************************/
DBA_DYNFLD_STP FIN_CreateRiskAmt(DBA_HIER_HEAD_STP   posHierHead,
                                 DBA_DYNFLD_STP      origPos,
                                 DATETIME_T          refDateTime,
                                  ID_T                refCurrId)
{
	DBA_DYNFLD_STP riskAmt=NULL, extValo=NULL;
	int            riskBpAmtFld, posBpAmtFld;

	if ((riskAmt = ALLOC_DYNST(RiskAmt)) == NULL)
	{
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
	}
	else
	{
	    SET_PRICE(riskAmt, RiskAmt_Price,         GET_PRICE(origPos, ExtPos_Price));
	    SET_NUMBER(riskAmt, RiskAmt_CompoQty,      1);
	    SET_AMOUNT(riskAmt, RiskAmt_SupplAmt,      GET_AMOUNT(origPos, ExtPos_SupplAmt));
	    SET_AMOUNT(riskAmt, RiskAmt_PosGrossAmt,   GET_AMOUNT(origPos, ExtPos_PosGrossAmt));
	    SET_AMOUNT(riskAmt, RiskAmt_PosNetAmt,     GET_AMOUNT(origPos, ExtPos_PosNetAmt));
	    SET_AMOUNT(riskAmt, RiskAmt_InstrGrossAmt, GET_AMOUNT(origPos, ExtPos_InstrGrossAmt));
	    SET_AMOUNT(riskAmt, RiskAmt_InstrNetAmt,   GET_AMOUNT(origPos, ExtPos_InstrNetAmt));
	    SET_AMOUNT(riskAmt, RiskAmt_RefGrossAmt,   GET_AMOUNT(origPos, ExtPos_RefGrossAmt));
	    SET_AMOUNT(riskAmt, RiskAmt_RefNetAmt,     GET_AMOUNT(origPos, ExtPos_RefNetAmt));
	    SET_AMOUNT(riskAmt, RiskAmt_SysGrossAmt,   GET_AMOUNT(origPos, ExtPos_SysGrossAmt));
	    SET_AMOUNT(riskAmt, RiskAmt_SysNetAmt,     GET_AMOUNT(origPos, ExtPos_SysNetAmt));

	    for (posBpAmtFld=ExtPos_Bp1PosAmt, riskBpAmtFld=RiskAmt_Bp1PosAmt;
	     	 posBpAmtFld < (ExtPos_Bp1PosAmt+ExtPos_BpPosAmtNb);
	         posBpAmtFld++, riskBpAmtFld++)
	    {   SET_AMOUNT(riskAmt, riskBpAmtFld, GET_AMOUNT(origPos, posBpAmtFld)); }

		if (GET_EXTENSION_PTR(origPos, ExtPos_PosVal_Ext) != NULL &&
		    (extValo = *(GET_EXTENSION_PTR(origPos, ExtPos_PosVal_Ext))) != NULL)
		{
            FLAG_T              updAmt=FALSE;
            FLAG_T              fwdAccFlg, futAccFlg, termAccFlg;
            /*RISKFWDRULE_ENUM    riskFwd, riskFut;*//* REF6057 - YST - 021010 */
            DBA_DYNFLD_STP      instrPtr=NULL;

            /* REF5586 - RAK - 010207 */
            /* Use FIN_PosRiskAnalysisInitAdAM() for more consistency */
            /*
            ADAM_LICENCEE_ENUM  isAALicenseEn=AdamLicencee_No;
            GEN_GetApplInfo(ApplAALicense, &isAALicenseEn);
            */
			FLAG_T				isAALicenseFlag=FALSE;
            DBA_DYNFLD_STP domainPtr = DBA_GetDomainPtr(DBA_GetConnectNoFromHier(posHierHead));  /* REF5035 - CSY - 020220 */

			/* PMSTA-13140 - LJE - 120319 */
			FIN_GetAccFlag(domainPtr,
	     				   origPos,
						   &futAccFlg,
						   &fwdAccFlg,
						   &termAccFlg);

            /* REF6057 - YST - 021010 - ApplRiskFutRule and ApplRiskFwdRule are only used for setting instr nature
            and not for computation of market value, price, ... */
            /*GEN_GetApplInfo(ApplRiskFutRule, &riskFut);
	        GEN_GetApplInfo(ApplRiskFwdRule, &riskFwd); */

            /* Do the difference for risk computation if valuation isn't */
            /* done by difference (FwdAccFlg or FutAccFlg = FALSE)       */
            /* REF5586 - RAK - 010207 */
            /* Use FIN_PosRiskAnalysisInitAdAM() for more consistency */
            /*
            if (isAALicenseEn >= AdamLicencee_Level2)
            */
            if (GET_EXTENSION_PTR(origPos, ExtPos_A_Instr_Ext) != NULL &&
	           (instrPtr = *(GET_EXTENSION_PTR(origPos, ExtPos_A_Instr_Ext))) != NULL)
            {
                INSTRCATEGORY_ENUM  instrCategory=FIN_InstrCategory(instrPtr, posHierHead);
                FIN_PosRiskAnalysisInitAdAM(instrCategory, &isAALicenseFlag);
            }

            if (isAALicenseFlag == TRUE)
            {
                if (fwdAccFlg == FALSE && /*riskFwd == RiskFutRule_UnderlyPos &&*//* REF6057 - YST - 021010 */
                    GET_FLAG(origPos, ExtPos_MainFlg) == TRUE &&
		            (GET_ENUM(origPos, ExtPos_RefNatEn) == PosRefNat_FwdOpen ||
		             GET_ENUM(origPos, ExtPos_RefNatEn) == PosRefNat_FwdClose))
			        updAmt = TRUE;

		        if (futAccFlg == FALSE && /*riskFut == RiskFutRule_UnderlyPos &&*//* REF6057 - YST - 021010 */
                    GET_FLAG(origPos, ExtPos_MainFlg) == TRUE &&
		            (GET_ENUM(origPos, ExtPos_RefNatEn) == PosRefNat_FutOpen        ||
		             GET_ENUM(origPos, ExtPos_RefNatEn) == PosRefNat_FutClose       ||
                     GET_ENUM(origPos, ExtPos_RefNatEn) == PosRefNat_FutWMP         ||  /* PMSTA-4559 - 011107 - PMO */
                     GET_ENUM(origPos, ExtPos_RefNatEn) == PosRefNat_FutContract    ||  /* PMSTA-17898 - 160414 - PMO */
                     GET_ENUM(origPos, ExtPos_RefNatEn) == PosRefNat_FutFifo))
			        updAmt = TRUE;
            }

            if (updAmt == TRUE &&
                GET_EXTENSION_PTR(origPos, ExtPos_A_Instr_Ext) != NULL &&
	            (instrPtr = *(GET_EXTENSION_PTR(origPos, ExtPos_A_Instr_Ext))) != NULL)
            {
                AMOUNT_T        val=0.0;
                FIN_EXCHARG_ST  exchArgSt;
                ID_T            posCurrId = GET_ID(origPos, ExtPos_PosCurrId);

                memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));

                /* REF5416 - RAK - 010118 - new arg posHierHead */
                /* REF5586 - RAK - 010207 - Send instrPtr instead of instrNat */
                FIN_NetValFutFwdValDiff(posHierHead, origPos, extValo, instrPtr,
                                        refDateTime, GET_NUMBER(origPos, ExtPos_Qty), &val);

                SET_AMOUNT(riskAmt, RiskAmt_PosMktValAmt, val);

	            if (refCurrId != posCurrId)
   	            {
		            exchArgSt.srcAmt = val;
		            FIN_ExchAmtEuro(refDateTime, refCurrId, posCurrId, refCurrId,
				                    0, NULL, &exchArgSt, origPos, NULL, &val, NULL);
                }
                SET_AMOUNT(riskAmt, RiskAmt_RefMktValAmt, val);
            }
            else
            {
			    SET_AMOUNT(riskAmt, RiskAmt_PosMktValAmt, GET_AMOUNT(extValo, PosVal_PosMktValAmt));
			    SET_AMOUNT(riskAmt, RiskAmt_RefMktValAmt, GET_AMOUNT(extValo, PosVal_RefMktValAmt));
            }

            SET_ID(riskAmt, RiskAmt_PosCurrId, GET_ID(origPos, ExtPos_PosCurrId));
		}
	}

	return(riskAmt);
}

/************************************************************************
**
**  Function    :   FIN_GetFutFwdUnderlyInfo()
**
**  Description :   Return underly for future or forward position
**
**  Arguments   :   instrPtr       instrument data pointer
**                  fromDateTime   from date
**                  underIdPtr     underly identifier pointer or NULL
**                  ctdFlgPtr      cheapest to deliver flag pointer
**                  ctdConvFactPtr cheapest to deliver conversion factor pointer or NULL
**
**  Return      :   RET_GEN_INFO_NOACTION, RET_SUCCEED or error code
**                  For future and forward, underIdPtr, ctdFlgPtr, ctdConvFactPtr are filled
**
**  Creation    :   DVP191 - RAK - 960830
**
*************************************************************************/
RET_CODE FIN_GetFutFwdUnderlyInfo(DBA_DYNFLD_STP instrPtr,
                                 DATETIME_T     fromDateTime,
                                 ID_T           *underIdPtr,
                                 char           *ctdFlgPtr,
			                     NUMBER_T       *ctdConvFactPtr)
{
	DBA_DYNFLD_STP termEvt=NULL;
	ID_T           underId;

	underId = 0;

	*ctdFlgPtr = FALSE;
	if (underIdPtr != NULL) *underIdPtr = 0;
	if (ctdConvFactPtr != NULL) *ctdConvFactPtr = 0.0;

	if ((INSTRNAT_ENUM) GET_ENUM(instrPtr, A_Instr_NatEn) != InstrNat_Future &&
	    (INSTRNAT_ENUM) GET_ENUM(instrPtr, A_Instr_NatEn) != InstrNat_FRA &&	/* DVP440 */
	    (INSTRNAT_ENUM) GET_ENUM(instrPtr, A_Instr_NatEn) != InstrNat_Forward)
		return(RET_GEN_INFO_NOACTION);

	if ((INSTRNAT_ENUM) GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_Future)
	{
   	    /* Get event information */
	    if ((termEvt = ALLOC_DYNST(A_TermEvt)) == NULL)
	    {
   		    MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }

	    if (DBA_GetTermEvt(instrPtr, fromDateTime.date, termEvt) == RET_SUCCEED)
	    {
		    if (IS_NULLFLD(termEvt, A_TermEvt_CheapestInstrId) == FALSE)
		    {
		        underId = GET_ID(termEvt, A_TermEvt_CheapestInstrId);

		        *ctdFlgPtr = TRUE;
		        if (ctdConvFactPtr != NULL)
		            *ctdConvFactPtr = GET_NUMBER(termEvt, A_TermEvt_CtdConvFact);
		    }
		    else
		    {
		        underId = GET_ID(termEvt, A_TermEvt_UnderlyInstrId);
		    }
	    }

	    FREE_DYNST(termEvt, A_TermEvt);
	}
	else
	{
	    underId = GET_ID(instrPtr, A_Instr_UnderlyInstrId);
	}

	if (underId == 0)
	{
		MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, " FIN_GetFutFwdUnderlyInfo",
			     GET_CODE(instrPtr, A_Instr_Cd), "underlying");
		return(RET_FIN_ERR_INVDATA);
	}
	else
	{
		if (underIdPtr != NULL) *underIdPtr = underId;
		return(RET_SUCCEED);
	}
}

/************************************************************************
**
**  Function    :   FIN_RiskGetInstrPtr()
**
**  Description :   Get instrument (in hierarchy or database) and
**                  in case of generic forward add underlying informations.
**
**  Arguments   :   posHierHead     extended position hierarchy header
**                  fromDateTime
**                  instrId         instrument identifier
**                  inputInstrPtr   instrument pointer, can be NULL
**		            instrPtrPtr	    pointer on instrument
**		            instrHierFlgPtr pointer on instrument hierarchy flag
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   BUG175 - RAK - 961010
**  Modif. 	    :   REF3357 - RAK - 990223
**
*************************************************************************/
STATIC RET_CODE FIN_RiskGetInstrPtr(DBA_HIER_HEAD_STP posHierHead,
			             DATETIME_T        fromDateTime,
			             ID_T              instrId,
			             DBA_DYNFLD_STP    inputInstrPtr,
			             DBA_DYNFLD_STP    *instrPtrPtr,
				         char              *instrHierFlgPtr)
{
	RET_CODE ret;

	if (inputInstrPtr != NULL)
	{
	    *instrPtrPtr     = inputInstrPtr;
	    *instrHierFlgPtr = TRUE;
	    ret = RET_SUCCEED;
	}
	else
	{
	    /* Search instrument in hierarchy, if not found,  */
	    /* load it from database and add it to hierarchy. */
	    ret = FIN_GetHierInstr(posHierHead, instrId, instrHierFlgPtr, instrPtrPtr);

	    if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
	    {
		    return(ret);
	    }

	    if ((*instrHierFlgPtr) == FALSE)
	    {
		    /* New loaded instrument, treat forward */
		    if (GET_ENUM((*instrPtrPtr), A_Instr_NatEn) == InstrNat_Forward)
		    {
		        if (GET_FLAG((*instrPtrPtr), A_Instr_GenericFlg) == FALSE)
		        {
			        ret = DBA_UpdFwdTermInfo((*instrPtrPtr), NULL, fromDateTime);

			        if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
			        {
			            FREE_DYNST((*instrPtrPtr), A_Instr);
			            return(ret);
			        }
		        }
		        else
		        {
		  	        FREE_DYNST((*instrPtrPtr), A_Instr);
			        return(RET_DBA_ERR_INVDATA);
		        }
		    }

		    /* REF3357 - RAK - 990223 */
		    /* Don't try to do link (A_Instr_Compo_A_Instr_Ext, A_Instr_Cond_A_Instr_Ext) */
		    /* In fact we found a problem in function DBA_SelAllInterestCond..            */
		    /* which don't found InterCond (which exist)                                  */
		    if ((ret = DBA_AddHierRecord(posHierHead, (*instrPtrPtr), A_Instr,
					                     TRUE, HierAddRec_NoLnk)) != RET_SUCCEED)
		    {
		        FREE_DYNST((*instrPtrPtr), A_Instr);
		        return(ret);
		    }

		    *instrHierFlgPtr = TRUE;
	    }
	}
	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_RiskPosLink()
**
**  Description :   Prepare risk position link
**
**  Arguments   :   riskPos	        pointer on risk position
**  		        origPos	        pointer on original position
**  		        riskParInstrId  risk parent instrument identifier
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   DVP187 - RAK - 960829
**  Modif.      :   DVP510 - RAK - 970618
**
*************************************************************************/
EXTERN RET_CODE FIN_RiskPosLink(DBA_DYNFLD_STP riskPos,
				                DBA_DYNFLD_STP origPos,
				                ID_T riskParInstrId)
{
	DBA_DYNFLD_STP riskInstrPtr=NULL;

	if (GET_EXTENSION_PTR(origPos, ExtPos_RiskPar_A_Instr_Ext) != NULL &&
	    (riskInstrPtr = *(GET_EXTENSION_PTR(origPos,
						ExtPos_RiskPar_A_Instr_Ext))) != NULL)
	{
	    /* DVP510 - RAK - 970618 */
	    INSTRNAT_ENUM instrNatEn = (INSTRNAT_ENUM) GET_ENUM(riskInstrPtr, A_Instr_NatEn);
	    if (instrNatEn == InstrNat_Option ||
		    instrNatEn == InstrNat_ExoticOptions ||
		    instrNatEn == InstrNat_SwapOptions)
	    {
		    /* Get risk link from parent */
	        SET_ID(riskPos, ExtPos_RiskOriginExtPosId,
		    GET_ID(origPos, ExtPos_RiskOriginExtPosId));
	        SET_ID(riskPos, ExtPos_RiskParInstrId,
		    GET_ID(origPos, ExtPos_RiskParInstrId));
	    }
	    else
	    {
	        SET_ID(riskPos, ExtPos_RiskOriginExtPosId, GET_ID(origPos, ExtPos_Id));
	        SET_ID(riskPos, ExtPos_RiskParInstrId,     riskParInstrId);
	    }
	}
	else
	{
	    SET_ID(riskPos, ExtPos_RiskOriginExtPosId, GET_ID(origPos, ExtPos_Id));
	    SET_ID(riskPos, ExtPos_RiskParInstrId,     riskParInstrId);
	}

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_RiskSonPriceAmt()
**
**  Description :   Compute risk son price depending on status (Son - LastSon)
**		    at position begin date and update total price
**                  If update risk position flag is set to TRUE, update
**                  risk positions amounts.
**
**  Arguments   :   posHierHead  hierarchy header pointer
**                  domainArgPtr some domain arguments pointer
**                  origPos      original position pointer (loaded)
**                  riskPos      risk position pointer (generated)
**                  instrPtr     pointer on instrument structure
**                  totRiskPos   risk totalizator pointer
**                  status       risk status (LastSon, Son, Father)
**                  pricePtr     price pointer
**                  riskUpdFlg   flag which indicate if risk position must
**                               be updated or not (only totalizator updated)
**
**  Return      :   RET_SUCCEED or error code
**
**  Modif.     	:   REF053 - RAK - 980319
**  Modif.	    :   REF2313 - RAK - 980910
**  Modif.	    :   REF2580 - SSO - 980727
**                  REF5035 - CSY - 020220 fwdAccFlg, futAccFlg, termAccFlg set to FALSE for return and synth admin
**  Modif:          REF5035 - CSY - 020311: add test domainPtr not null
**                  PMSTA-17898 - 160414 - PMO : New Fusion Criteria to manage the contract dates for margin calls after partial closing
**                  PMSTA-25190 - 061116 - PMO : Fixes of some errors founded by AddressSanitizer
**                  PMSTA-32504 - SIL - 190103 : Not required to recalculate the price for the baskets (structured note)
**
*************************************************************************/
EXTERN RET_CODE FIN_RiskSonPriceAmt(DBA_HIER_HEAD_STP  posHierHead,
				                    FIN_DOMAIN_ARG_STP domainArgPtr,
                                    DBA_DYNFLD_STP     origPos,
                                    DBA_DYNFLD_STP     riskPos,
				                    DBA_DYNFLD_STP     instrPtr,
				                    DBA_DYNFLD_STP     totPosRisk,
				                    FIN_PRICEARG_STP   priceArgStp,	/* REF3030 */
				                    RISK_ANALYSIS_ENUM status,
				                    PRICE_T           *pricePtr,
									RISK_QTY_STP	   riskQtyStp,	/* PMSTA-34140 - RAK - 190122 - Used for STN computation */
				                    char               riskUpdFlg)
{
	DBA_DYNFLD_STP prPtr=NULL, updPtr=NULL;
	ID_T           priceCurrId=-1;
	PRICE_T        totPrice;
	EXCHANGE_T     exch;
    FLAG_T         fwdAccFlg, futAccFlg, termAccFlg, allocFlg=FALSE;
	int            posBpAmtFld, riskBpAmtFld;
	char           priceOk;
	RET_CODE       ret;
    DBA_DYNFLD_STP domainPtr = DBA_GetDomainPtr(DBA_GetConnectNoFromHier(posHierHead));  /* REF5035 - CSY - 020220 */
	DBA_DYNFLD_STP parInstrPtr=NULL;

	if (status != Risk_Father &&
        GET_ENUM(instrPtr, A_Instr_ValRuleEn) == ValRule_ParInstr)
	{
		*pricePtr = GET_PRICE(origPos, ExtPos_Price);
		return(RET_SUCCEED);
	}

	switch (status)
	{
	/* Price is total position price minus all component price */
	case Risk_LastSon :

		/* PMSTA-35133 - RAK - 190507 - Use redemption price */
		if (riskQtyStp->STNEn == StnSpecific_FXTarkoOption)
		{
			*pricePtr   = riskQtyStp->price;
			priceCurrId = riskQtyStp->priceCurrId;
			priceOk = TRUE;
			ret = RET_SUCCEED;
		}
		else
		{
			/* REF3719 - SSO - 990602 : avoid div. by zero.. */
			if (CMP_NUMBER(GET_NUMBER(totPosRisk, RiskAmt_CompoQty), 0.0) != 0)
			{
				*pricePtr = GET_PRICE(totPosRisk, RiskAmt_Price) /
					GET_NUMBER(totPosRisk, RiskAmt_CompoQty);
			}
			else
			{
				*pricePtr = 0;
			}

			priceOk = TRUE;
			ret = RET_SUCCEED;
		}
		break;

	/* For forward, future or term price is founded in position */
	case Risk_Father :

		/* PMSTA-13140 - LJE - 120319 */
		FIN_GetAccFlag(domainPtr,
	     			   riskPos,
					   &futAccFlg,
					   &fwdAccFlg,
					   &termAccFlg);

		priceOk = FALSE;

		if (fwdAccFlg == TRUE &&
		    GET_FLAG(riskPos, ExtPos_MainFlg) == TRUE &&
		    (GET_ENUM(riskPos, ExtPos_RefNatEn) == PosRefNat_FwdOpen ||
		     GET_ENUM(riskPos, ExtPos_RefNatEn) == PosRefNat_FwdClose))
			priceOk = TRUE;

		if (futAccFlg == TRUE &&
		    GET_FLAG(riskPos, ExtPos_MainFlg) == TRUE &&
		    (GET_ENUM(riskPos, ExtPos_RefNatEn) == PosRefNat_FutOpen        ||
		     GET_ENUM(riskPos, ExtPos_RefNatEn) == PosRefNat_FutClose       ||
             GET_ENUM(riskPos, ExtPos_RefNatEn) == PosRefNat_FutWMP         ||  /* PMSTA-4559 - 011107 - PMO */
             GET_ENUM(riskPos, ExtPos_RefNatEn) == PosRefNat_FutContract    ||  /* PMSTA-17898 - 160414 - PMO */
             GET_ENUM(riskPos, ExtPos_RefNatEn) == PosRefNat_FutFifo        ||
		     GET_ENUM(riskPos, ExtPos_RefNatEn) == PosRefNat_FRAOpen        || /* DVP440 */
		     GET_ENUM(riskPos, ExtPos_RefNatEn) == PosRefNat_FRAClose))
			priceOk = TRUE;

	    if (termAccFlg == TRUE &&
		    GET_FLAG(riskPos, ExtPos_MainFlg) == TRUE &&
		    (GET_ENUM(riskPos,ExtPos_RefNatEn) == PosRefNat_TermOpen ||
		     GET_ENUM(riskPos,ExtPos_RefNatEn) == PosRefNat_TermClose))
			priceOk = TRUE;

		if (priceOk == TRUE)
			*pricePtr = GET_PRICE(riskPos, ExtPos_Price);
		ret = RET_SUCCEED;
		break;

	/* Compute son price */
	case Risk_Son :
	case Risk_Cash :
	default :

        priceOk = FALSE;
		ret = RET_SUCCEED;
		break;
	}

	/* PMSTA-34140 - RAK - 190122 - Use dedicated enum instead of strange value in old one */
	if (priceOk == FALSE && riskQtyStp->STNEn == StnSpecific_Treatment)
	{
		*pricePtr = riskQtyStp->price;	/* Use the price of parent for ParticipatingForward, TargetKnockOutForward */
		priceCurrId = riskQtyStp->priceCurrId;
		priceOk = TRUE;
	}

    /* REF5300 - RAK - 010717 */
    /* get strike price of option (which is future price) */
	if (priceOk == FALSE)
	{
        FLAG_T  isFutOptionFlg=FALSE;
        FIN_IsFutOptionFlg(instrPtr, posHierHead, &isFutOptionFlg);

		if (isFutOptionFlg == TRUE)
        {
            if (IS_NULLFLD(instrPtr, A_Instr_ParentInstrId) == FALSE)
			{
                DATE_T fromDate=domainArgPtr->fromDateTime.date;
				FIN_OPTINFO_ST optInfo;
				allocFlg = FALSE;
				memset(&optInfo, 0, sizeof(FIN_OPTINFO_ST));

				if ((ret = DBA_GetInstrById(GET_ID(instrPtr, A_Instr_ParentInstrId),
                                        TRUE, &allocFlg, &parInstrPtr, posHierHead,
                                        UNUSED, UNUSED)) == RET_SUCCEED)
                {
					/* PMSTA-32505 - RAK - 180907 - change name as used for STN too */
					if ((ret = FIN_GetOptionInfo(parInstrPtr, fromDate, &optInfo)) == RET_SUCCEED)
                    {
                        priceOk = TRUE;
                        priceCurrId = optInfo.exerCurrId;
	                    *pricePtr   = optInfo.exerPrice;
                    }
                }

				if (allocFlg == TRUE) { FREE_DYNST(parInstrPtr, A_Instr);}
            }
        }
    }

	/* PMSTA-8736 - RAK - 100204 */
	if (priceOk == FALSE &&
		status == Risk_Son &&
		(GET_ENUM(origPos, ExtPos_RefNatEn) == PosRefNat_FwdOpen ||
		 GET_ENUM(origPos, ExtPos_RefNatEn) == PosRefNat_FwdClose))
	{
		*pricePtr   = 1.0;
		priceCurrId = GET_ID(origPos, ExtPos_PosCurrId);
		priceOk     = TRUE;
	}

	/* PMSTA-10439 - RAK - 100901 - risk valuation for FWD_VAL_RULE=1 is wrong : */
	/* why compute a theoretical price : use the position price */
	/* NB FWD_VAL_RULE=2 don't use this part of code with the father (but treat legs trough TreatCompoRisk())*/
	if (priceOk == FALSE && status == Risk_Father &&
		(GET_ENUM(origPos, ExtPos_RefNatEn) == PosRefNat_FwdOpen ||
		 GET_ENUM(origPos, ExtPos_RefNatEn) == PosRefNat_FwdClose))
	{
		*pricePtr = GET_PRICE(origPos, ExtPos_Price);
		priceCurrId = GET_ID(origPos, ExtPos_PosCurrId);
		priceOk = TRUE;
	}


	if (priceOk == FALSE)
	{
		/*** OBTAINS POSITION PRICE ***/
		if ((prPtr = ALLOC_DYNST(A_InstrPrice)) == NULL)
			MSG_RETURN(RET_MEM_ERR_ALLOC);

		ret = FIN_PosPrice(riskPos, instrPtr, GET_DATETIME(riskPos, ExtPos_BegDate),
			priceArgStp, prPtr, NULL, posHierHead);

		/* REF053 - If price isn't found at begin date, search price at reference date. */
		if (RET_GET_LEVEL(ret) == RET_LEV_ERROR &&
			RET_GET_CATEG(ret) != RET_CATEG_MEM)
			ret = FIN_PosPrice(riskPos, instrPtr, GET_DATETIME(riskPos, ExtPos_ExtPosDate),
				priceArgStp, prPtr, NULL, posHierHead);

		if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
		{
			FREE_DYNST(prPtr, A_InstrPrice);
			return(ret);
		}

		priceCurrId = GET_ID(prPtr, A_InstrPrice_CurrId);
		*pricePtr = GET_PRICE(prPtr, A_InstrPrice_Price);

		FREE_DYNST(prPtr, A_InstrPrice);
	}


	if (status == Risk_Son)
	{
	    /* If necessary (and useful), convert price in initial   */
	    /* position currency before modify current "total price" */
	    if (ret == RET_SUCCEED && priceCurrId != GET_ID(riskPos, ExtPos_PosCurrId))
	    {
		    FIN_EXCHARG_ST  exchArgSt;			/* REF2313 */
		    memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));
		    /*DBA_SetConnectNoToExchArg(&exchArgSt, DBA_GetConnectNoFromHier(posHierHead)); *//* REF2580 - SSO - 980727 */
		    DBA_InitConnectNoToExchArg(&exchArgSt, posHierHead); /* REF4213 - SSO - 991221 */

	   	    ret = FIN_GetExchRate(GET_DATETIME(riskPos, ExtPos_BegDate),
			                      priceCurrId, GET_ID(riskPos, ExtPos_PosCurrId),
			                      (ID_T)0, NULL, riskPos, &exchArgSt, &exch);	/* PMSTA01649 - TGU - 070402 */

    		if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
			    return(ret);

		    (*pricePtr) *= exch;
	    }

	    /* Compute the last son's price */
		/* PMSTA-8736 - RAK - 100204 */
		if ((GET_ENUM(origPos, ExtPos_RefNatEn) != PosRefNat_FwdOpen &&
		    GET_ENUM(origPos, ExtPos_RefNatEn) != PosRefNat_FwdClose))
		{
			/* PMSTA15709 - DDV - 130305 - If price currency is not the same than accounting position, apply exchange rate.
			   But do it only if position currency is not the same than accounting position currency (in this case price has already been updated) */
			if (priceCurrId != GET_ID(totPosRisk, RiskAmt_PosCurrId) && GET_ID(riskPos, ExtPos_PosCurrId) != GET_ID(totPosRisk, RiskAmt_PosCurrId))
			{
				FIN_EXCHARG_ST  exchArgSt;			/* REF2313 */
				memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));

				DBA_InitConnectNoToExchArg(&exchArgSt, posHierHead);
	   			ret = FIN_GetExchRate(GET_DATETIME(riskPos, ExtPos_BegDate),
									  priceCurrId, GET_ID(totPosRisk, RiskAmt_PosCurrId),
									  (ID_T)0, NULL, riskPos, &exchArgSt, &exch);	/* PMSTA01649 - TGU - 070402 */

    			if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
					return(ret);
			}
			else
				exch=1.0;

			totPrice = GET_PRICE(totPosRisk, RiskAmt_Price) -
		           ((*pricePtr) * exch * GET_NUMBER(totPosRisk, RiskAmt_CompoQty));
			SET_PRICE(totPosRisk, RiskAmt_Price, CAST_PRICE(totPrice)); /* REF3288 - SSO - 990205 */
		}
	}

	/* Stop if error occurs upper */
	if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
		return(ret);

	NUMBER_T ratio = ZERO_NUMBER;

    if (ZERO_PRICE != GET_PRICE(origPos, ExtPos_Price))   /* PMSTA-25190 - 061116 - PMO */
    {
	    ratio = (*pricePtr) * GET_NUMBER(totPosRisk, RiskAmt_CompoQty) / GET_PRICE(origPos, ExtPos_Price);
    }

	if (riskUpdFlg == TRUE)

		updPtr = riskPos;
	else
		updPtr = NULL;

	/* REF2580 - SSO - 980727 added posHierHead to FIN_ComputeRiskAmt */
	FIN_ComputeRiskAmt(origPos, updPtr, ExtPos_RefGrossAmt,
	                   ratio, 0, 0, totPosRisk, RiskAmt_RefGrossAmt, status, posHierHead);
	FIN_ComputeRiskAmt(origPos, updPtr, ExtPos_RefNetAmt,
	                   ratio, 0, 0, totPosRisk, RiskAmt_RefNetAmt, status, posHierHead);

	FIN_ComputeRiskAmt(origPos, updPtr, ExtPos_SysGrossAmt,
	                   ratio, 0, 0, totPosRisk, RiskAmt_SysGrossAmt, status, posHierHead);
	FIN_ComputeRiskAmt(origPos, updPtr, ExtPos_SysNetAmt,
	                   ratio, 0, 0, totPosRisk, RiskAmt_SysNetAmt, status, posHierHead);

	for (posBpAmtFld=ExtPos_Bp1PosAmt, riskBpAmtFld=RiskAmt_Bp1PosAmt;
             posBpAmtFld < (ExtPos_Bp1PosAmt+ExtPos_BpPosAmtNb);
             posBpAmtFld++, riskBpAmtFld++)
    {
        FIN_ComputeRiskAmt(origPos, updPtr, posBpAmtFld, ratio,
		                   GET_ID(origPos,ExtPos_PosCurrId), GET_ID(origPos,ExtPos_PosCurrId),
			               totPosRisk, riskBpAmtFld, status, posHierHead);
	}

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_TreatCompoRisk()
**
**  Description :   Create risk position (normal position or final component)
**
**  Arguments   :   posHierHead    extended position hierarchy header
**                  domainArgPtr   pointer on some domain informations
**		            origPos	       pointer on original position
**		            instrPtr   	   pointer on instrument
**		            instrHierFlg   flag which indicates if instrument is in hierarchy or not
**                  totPosRisk     total structure pointer
**                  riskQtyStp     quantity structure pointer
**                  status         Risk_Son, Risk_LastSon
**		            riskPosPtr	   pointer on risk position pointer (updated)
**
**  Return      :   RET_SUCCEED, RET_GEN_INFO_NOACTION or error code
**
**  Modif.      :   DVP187 - RAK - 960829
**  Modif.      :   DVP189 - RAK - 960902
**  Modif.      :   BUG145 - RAK - 961008
**  Modif.      :   BUG175 - RAK - 961010
**  Modif.      :   REF796 - RAK - 971029
**  Modif.	    :   REF1457 - RAK - 980324
**  Modif.	    :   REF2313 - RAK - 980910
**  Modif.	    :   REF2580 - SSO - 980727
**		            REF3118 - SSO - 981214
**                  REF7661 - YST - 020725
**
*************************************************************************/
EXTERN RET_CODE FIN_TreatCompoRisk(DBA_HIER_HEAD_STP  posHierHead,
	FIN_DOMAIN_ARG_STP domainArgPtr,
	FIN_AIARG_STP      aiArgPtr,
	DBA_DYNFLD_STP     origPos,
	DBA_DYNFLD_STP     instrPtr,
	char               instrHierFlg,
	DBA_DYNFLD_STP     totPosRisk,
	RISK_QTY_STP       riskQtyStp,	/* DVP189 */
	FIN_PRICEARG_STP   priceArgStp,	/* REF3030 */
	RISK_ANALYSIS_ENUM status,
	DBA_DYNFLD_STP     *riskPosPtr)	/* BUG175 */
{
	DBA_DYNFLD_STP riskPos = NULL, ptfPtr = NULL;
	PRICE_T        price, quote;
	NUMBER_T       qty;
	AMOUNT_T       netAmt, grossAmt, amt;
	EXCHANGE_T     exch;
	ID_T           sysCurrId;
	FLAG_T	       allocPtfFlg, isFutOptionFlg = FALSE;
	RET_CODE       ret;
	FIN_EXCHARG_ST    exchArgSt;			/* REF2313 */

	memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));	/* REF2313 */
	/*DBA_SetConnectNoToExchArg(&exchArgSt, DBA_GetConnectNoFromHier(posHierHead)); *//* REF2580 - SSO - 980727 */
	DBA_InitConnectNoToExchArg(&exchArgSt, posHierHead); /* REF4213 - SSO - 991221 */

	if ((riskPos = ALLOC_DYNST(ExtPos)) == NULL)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

	/* BUG175 */
	if (riskPosPtr != NULL)
		*riskPosPtr = riskPos;

	/*** GENERATE POSITION ***/
	COPY_DYNST(riskPos, origPos, ExtPos);

	/* A risk position parent can't be risk */
	SET_ENUM(origPos, ExtPos_RiskNatEn, ExtPosRisk_NoRisk);		/* BUG145 */

	/* REF7661 - YST - 020725 - risk position can't be main position */
	SET_FLAG(riskPos, ExtPos_MainFlg, FALSE);

	/* Suppress extension identifier (copied from origin position) */
	SET_NULL_ID(riskPos, ExtPos_MainExtPosId);
	SET_NULL_ID(riskPos, ExtPos_AcctExtPosId);
	SET_NULL_ID(riskPos, ExtPos_AdjustExtPosId);
	SET_NULL_ID(riskPos, ExtPos_PosValId);

	/* Risk position is in origin position currency except for currencies */
	if ((INSTRNAT_ENUM)
		GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_CashAcct)
	{
		SET_ID(riskPos, ExtPos_PosCurrId, GET_ID(instrPtr, A_Instr_RefCurrId));
	}

	/* REF5300 - RAK - 010717 */
	FIN_IsFutOptionFlg(instrPtr, posHierHead, &isFutOptionFlg);
	if (isFutOptionFlg == TRUE)
	{
		SET_ENUM(riskPos, ExtPos_RefNatEn, PosRefNat_FutOpen);
	}

	ret = FIN_RiskSonPriceAmt(posHierHead, domainArgPtr, origPos, riskPos,
			                      instrPtr, totPosRisk, priceArgStp, status, &price, riskQtyStp, TRUE); /* PMSTA-34140 - RAK - 190122 - Add riskQtyStp for STN computation */

	if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
	{
		FREE_DYNST(riskPos, ExtPos);
		return(ret);
	}

	FIN_PriceToQuote((PRICECALCRULE_ENUM)GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn), 		/* DVP440 */ /* REF7264 - LJE - 020131 */
					GET_ID(instrPtr, A_Instr_Id), instrPtr,
					GET_DATETIME(riskPos, ExtPos_BegDate), NULL,
					price, &quote, posHierHead);

	/* DVP189 */
	if (riskQtyStp->idxCalcRuleEn == IdxCalcRule_PctValue)
	{
	    PRICE_T       tmpPrice = 0.0;

	    if ((ret = FIN_PosPrice(riskPos, instrPtr, domainArgPtr->fromDateTime,
				                priceArgStp, riskQtyStp->pricePtr,
                                NULL, posHierHead)) == RET_SUCCEED)
	    {
	        if (GET_ID(riskQtyStp->pricePtr, A_InstrPrice_CurrId) != riskQtyStp->priceCurrId)
	        {
		        /* BUG145 */
   	            FIN_GetExchRate(domainArgPtr->fromDateTime,
		                        GET_ID(riskQtyStp->pricePtr, A_InstrPrice_CurrId),
                                riskQtyStp->priceCurrId,
				                (ID_T)0, NULL, origPos, &exchArgSt, &exch);	/* PMSTA01649 - TGU - 070402 */
		    }
		    else
			    exch = 1.0;

		    tmpPrice = GET_PRICE(riskQtyStp->pricePtr, A_InstrPrice_Price) * exch;
	    }

	    if (ret != RET_SUCCEED || tmpPrice == 0.0)
	    {
		    FREE_DYNST(riskPos, ExtPos);
		    /* REF796 - Don't stop process but don't splitt fund share */
		    return(RET_GEN_INFO_NOACTION);
	    }
	    qty = CAST_NUMBER(riskQtyStp->qty / tmpPrice); /* REF3288 - SSO - 990205 */
	}
	else
	{
		if (riskQtyStp->STNEn == StnSpecific_FXTarkoOption)
		{
			qty = TLS_Round(riskQtyStp->qty, 1.0, RndRule_Nearest);

		}
		else
		{
			qty = riskQtyStp->qty;
		}
	}

	SET_NUMBER(riskPos, ExtPos_Qty,   qty);
	SET_PRICE(riskPos, ExtPos_Price, price);
	SET_PRICE(riskPos, ExtPos_Quote, quote);
	SET_ENUM(riskPos, ExtPos_PriceCalcRuleEn, GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn)); /* PMSTA16573 - DDV - 130627 - Set instrument's price calc rule into pos to be coherent with price and quote */

	amt = CAST_AMOUNT(qty * price, GET_ID(riskPos, ExtPos_PosCurrId));
	SET_AMOUNT(riskPos, ExtPos_PosNetAmt,   amt);
	SET_AMOUNT(riskPos, ExtPos_PosGrossAmt, amt);

	/*** Reference currency ***/
	if (GET_ID(riskPos, ExtPos_RefCurrId) != GET_ID(riskPos, ExtPos_PosCurrId))
	{
		/* PMSTA04748 - RAK - 071204 - use original pos exch rate (if possible) */
		if (GET_ID(origPos, ExtPos_RefCurrId) == GET_ID(riskPos, ExtPos_RefCurrId) &&
			GET_ID(origPos, ExtPos_PosCurrId) == GET_ID(riskPos, ExtPos_PosCurrId))
		{
			exch = GET_EXCHANGE(origPos, ExtPos_PosExchRate);
			netAmt = GET_AMOUNT(riskPos, ExtPos_PosNetAmt) * exch;
			grossAmt = GET_AMOUNT(riskPos, ExtPos_PosGrossAmt) * exch;
		}
		else
		{
			/* REF2313 */
			exchArgSt.srcAmt = GET_AMOUNT(riskPos, ExtPos_PosNetAmt);
			FIN_ExchAmt(GET_DATETIME(riskPos, ExtPos_BegDate),
			        GET_ID(riskPos, ExtPos_PosCurrId),
			        GET_ID(riskPos, ExtPos_RefCurrId),
			        0, NULL, riskPos, &exchArgSt,NULL, &netAmt, &exch);	/* PMSTA01649 - TGU - 070405 */

			exchArgSt.srcAmt = GET_AMOUNT(riskPos, ExtPos_PosGrossAmt);
			FIN_ExchAmt(GET_DATETIME(riskPos, ExtPos_BegDate),
			        GET_ID(riskPos, ExtPos_PosCurrId),
			        GET_ID(riskPos, ExtPos_RefCurrId),
			        0, NULL, riskPos, &exchArgSt, &exch, &grossAmt, NULL);	/* PMSTA01649 - TGU - 070405 */
		}
	}
	else
	{
		netAmt   = GET_AMOUNT(riskPos, ExtPos_PosNetAmt);
		grossAmt = GET_AMOUNT(riskPos, ExtPos_PosGrossAmt);
		exch     = 1.0;
	}
	SET_AMOUNT(riskPos,   ExtPos_RefGrossAmt, grossAmt);
	SET_AMOUNT(riskPos,   ExtPos_RefNetAmt,   netAmt);
	SET_EXCHANGE(riskPos, ExtPos_PosExchRate, exch);

	/*** Instrument currency ***/
	SET_ID(riskPos, ExtPos_InstrId,     GET_ID(instrPtr, A_Instr_Id));
	SET_ID(riskPos, ExtPos_InstrCurrId, GET_ID(instrPtr,A_Instr_RefCurrId));

	if (GET_ID(riskPos, ExtPos_InstrCurrId) != GET_ID(riskPos, ExtPos_RefCurrId))
	{
	    if (GET_ID(riskPos, ExtPos_InstrCurrId) != GET_ID(riskPos, ExtPos_PosCurrId))
	    {
			/* PMSTA04748 - RAK - 071204 Use original instr exch rate (if possible) */
			if (GET_ID(origPos, ExtPos_InstrCurrId) == GET_ID(riskPos, ExtPos_InstrCurrId))
			{
				exch = GET_EXCHANGE(origPos, ExtPos_InstrExchRate);
				netAmt = GET_AMOUNT(riskPos, ExtPos_RefNetAmt) * 1/exch;
				grossAmt = GET_AMOUNT(riskPos, ExtPos_RefNetAmt) * 1/exch;
				SET_EXCHANGE(riskPos, ExtPos_InstrExchRate, exch);
			}
			else
			{
				exchArgSt.srcAmt = GET_AMOUNT(riskPos, ExtPos_RefNetAmt);
	    		FIN_ExchAmt(GET_DATETIME(riskPos, ExtPos_BegDate),
			            GET_ID(riskPos, ExtPos_RefCurrId),
   			            GET_ID(riskPos, ExtPos_InstrCurrId),
			            0, NULL, riskPos, &exchArgSt,NULL, &netAmt, &exch);	/* PMSTA01649 - TGU - 070405 */

				exchArgSt.srcAmt = GET_AMOUNT(riskPos, ExtPos_RefGrossAmt);
	    		FIN_ExchAmt(GET_DATETIME(riskPos, ExtPos_BegDate),
			            GET_ID(riskPos, ExtPos_RefCurrId),
			            GET_ID(riskPos, ExtPos_InstrCurrId),
			            0, NULL, riskPos, &exchArgSt, &exch, &grossAmt, NULL);	/* PMSTA01649 - TGU - 070405 */

				SET_EXCHANGE(riskPos, ExtPos_InstrExchRate, (1/exch));
			}
	    }
	    else
	    {
		    netAmt   = GET_AMOUNT(riskPos,   ExtPos_PosNetAmt);
		    grossAmt = GET_AMOUNT(riskPos,   ExtPos_PosGrossAmt);
		    SET_EXCHANGE(riskPos, ExtPos_InstrExchRate,
				GET_EXCHANGE(riskPos, ExtPos_PosExchRate));
	    }
	}
	else
	{
		netAmt   = GET_AMOUNT(riskPos, ExtPos_RefNetAmt);
		grossAmt = GET_AMOUNT(riskPos, ExtPos_RefGrossAmt);
		SET_EXCHANGE(riskPos, ExtPos_InstrExchRate, 1.0);
	}

	SET_AMOUNT(riskPos, ExtPos_InstrGrossAmt, grossAmt);
	SET_AMOUNT(riskPos, ExtPos_InstrNetAmt,   netAmt);

	/*** System currency ***/
	/* REF3118 - SSO - 981214 : get the syscurrid from ptf before from appl param */
	sysCurrId = 0;
	if (GET_EXTENSION_PTR(riskPos , ExtPos_A_Ptf_Ext) != NULL &&
	    (ptfPtr = *(GET_EXTENSION_PTR(riskPos, ExtPos_A_Ptf_Ext)))!= NULL)
	{
	    if (IS_NULLFLD(ptfPtr, A_Ptf_SysCurrId) == FALSE)
	    {
		    sysCurrId = GET_ID(ptfPtr, A_Ptf_SysCurrId);
	    }
	}
	else
	{
	    if (IS_NULLFLD(riskPos, ExtPos_PtfId) == FALSE)
	    {
		    /* no ext set: get2 to do... */
		    /* REF3913 - Use hierarchy or get A_Ptf in db */
		    if ((ret = DBA_GetPtfById(GET_ID(riskPos, ExtPos_PtfId), FALSE, &allocPtfFlg,
	                                  &ptfPtr, posHierHead, UNUSED, UNUSED)) != RET_SUCCEED)
		    {
		        FREE_DYNST(riskPos, ExtPos);
		        return (ret);
		    }

            if (IS_NULLFLD(ptfPtr, A_Ptf_SysCurrId) == FALSE)
		    {
		        sysCurrId = GET_ID(ptfPtr, A_Ptf_SysCurrId);
		    }

		    if (allocPtfFlg == TRUE) { FREE_DYNST(ptfPtr, A_Ptf); }
	    }
	}

	if (sysCurrId == 0)
	{
	    GEN_GetApplInfo(ApplSysCurrId, &sysCurrId);
	}

	if (sysCurrId != GET_ID(riskPos, ExtPos_RefCurrId))
	{
	    if (sysCurrId != GET_ID(riskPos, ExtPos_PosCurrId))
	    {
		    /* REF2313 */
		    exchArgSt.srcAmt = GET_AMOUNT(riskPos, ExtPos_RefNetAmt);
	    	FIN_ExchAmt(GET_DATETIME(riskPos, ExtPos_BegDate),
			            GET_ID(riskPos, ExtPos_RefCurrId), sysCurrId,
			            0, NULL, riskPos, &exchArgSt,
			            NULL, &netAmt, &exch);	/* PMSTA01649 - TGU - 070405 */

		    exchArgSt.srcAmt = GET_AMOUNT(riskPos, ExtPos_RefGrossAmt);
	        FIN_ExchAmt(GET_DATETIME(riskPos, ExtPos_BegDate),
			            GET_ID(riskPos, ExtPos_RefCurrId), sysCurrId,
			            0, NULL, riskPos, &exchArgSt,
			            &exch, &grossAmt, NULL);	/* PMSTA01649 - TGU - 070405 */

		    SET_EXCHANGE(riskPos, ExtPos_SysExchRate, (1/exch));
	    }
	    else
	    {
		    netAmt   = GET_AMOUNT(riskPos, ExtPos_PosNetAmt);
		    grossAmt = GET_AMOUNT(riskPos, ExtPos_PosGrossAmt);
		    SET_EXCHANGE(riskPos, ExtPos_SysExchRate,
		        GET_EXCHANGE(riskPos, ExtPos_PosExchRate));
	    }
	}
	else
	{
		netAmt   = GET_AMOUNT(riskPos, ExtPos_RefNetAmt);
		grossAmt = GET_AMOUNT(riskPos, ExtPos_RefGrossAmt);
		SET_EXCHANGE(riskPos, ExtPos_SysExchRate, 1.0);
	}

	SET_AMOUNT(riskPos,   ExtPos_SysGrossAmt, grossAmt);
	SET_AMOUNT(riskPos,   ExtPos_SysNetAmt,   netAmt);

	/* For risk position link */	/* DVP187 */
	FIN_RiskPosLink(riskPos, origPos, GET_ID(origPos, ExtPos_InstrId));

	ret = FIN_AddValoRiskPos(posHierHead, domainArgPtr, aiArgPtr, origPos, riskPos, instrPtr,
		instrHierFlg, totPosRisk, priceArgStp, status,
		NULL, NULL, nullptr, riskQtyStp); /* PMSTA-35133 - RAK - 190517 */

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_TreatFRACashPos()
**
**  Description :   Treat FRA cash position.
**
**  Arguments   :   origPos FRA accounting position
**                  riskPos FRA risk position
**                  FRAPtr  FRA instrument
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   REF53.1 - RAK - 980408
**  Modification:   REF7661 - YST - 020725
**
*************************************************************************/
STATIC RET_CODE FIN_TreatFRACashPos(DBA_HIER_HEAD_STP  posHierHead,
				                    FIN_DOMAIN_ARG_STP domainArgPtr,
				                    FIN_AIARG_STP      aiArgPtr,
				                    DBA_DYNFLD_STP     origPos,
				                    DBA_DYNFLD_STP     riskPos,
				                    DBA_DYNFLD_STP     FRAPtr)
{
	double		    tmp, price;
	int		        k;
	DBA_DYNFLD_STP	posValPtr=NULL, acctPos=NULL, discInstrPtr=NULL,
			        cashInstrPtr=NULL, FRAPosValPtr=NULL, riskAcctPos=NULL,
			        pricePtr=NULL;
	RET_CODE	    ret;

	/* --------------------------------------- */
	/* Read accounting position and instrument */
	/* --------------------------------------- */
	if (GET_EXTENSION_PTR(origPos, ExtPos_Acct_ExtPos_Ext) == NULL  ||
	    (acctPos = *(GET_EXTENSION_PTR(origPos, ExtPos_Acct_ExtPos_Ext))) == NULL)
		MSG_RETURN(RET_DBA_ERR_HIER);

	if (GET_EXTENSION_PTR(acctPos, ExtPos_A_Instr_Ext) == NULL  ||
	    (cashInstrPtr = *(GET_EXTENSION_PTR(acctPos, ExtPos_A_Instr_Ext))) == NULL)
		MSG_RETURN(RET_DBA_ERR_HIER);

	/* ------------------------------------------------ */
	/* Create accounting position instrument (discount) */
	/* ------------------------------------------------ */
	if ((discInstrPtr = ALLOC_DYNST(A_Instr)) == NULL)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

	COPY_DYNST(discInstrPtr, cashInstrPtr, A_Instr);

	SET_ID(discInstrPtr, A_Instr_ParentInstrId, GET_ID(discInstrPtr, A_Instr_Id));
	SET_NULL_ID(discInstrPtr, A_Instr_Id);

	SET_ENUM(discInstrPtr, A_Instr_NatEn,     (ENUM_T) InstrNat_Discount);
	SET_ENUM(discInstrPtr, A_Instr_ValRuleEn, (ENUM_T) ValRule_Quote);

	SET_DATE(discInstrPtr, A_Instr_BeginDate, GET_DATE(FRAPtr, A_Instr_BeginDate));
	SET_DATE(discInstrPtr, A_Instr_EndDate, GET_DATE(FRAPtr, A_Instr_EndDate));

	/* ------------------------------- */
	/* Create risk accounting position */
	/* ------------------------------- */
	if ((riskAcctPos = ALLOC_DYNST(ExtPos)) == NULL)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

	COPY_DYNST(riskAcctPos, acctPos, ExtPos);

    /* REF7661 - YST - 020725 - risk position can't be main position */
    SET_FLAG(riskAcctPos, ExtPos_MainFlg, FALSE);

	/* Suppress extension identifier (copied from origin position) */
	SET_NULL_ID(riskAcctPos, ExtPos_Id);
	SET_NULL_ID(riskAcctPos, ExtPos_AcctExtPosId);
	SET_NULL_ID(riskAcctPos, ExtPos_AdjustExtPosId);
	SET_NULL_ID(riskAcctPos, ExtPos_PosValId);

	SET_ID(riskAcctPos, ExtPos_InstrCurrId,    GET_ID(discInstrPtr, A_Instr_RefCurrId));
	SET_ID(riskAcctPos, ExtPos_PosCurrId,      GET_ID(discInstrPtr, A_Instr_RefCurrId));
	SET_ID(riskAcctPos, ExtPos_RiskParInstrId, GET_ID(riskPos, ExtPos_RiskParInstrId));
	SET_ID(riskAcctPos, ExtPos_MainExtPosId,   GET_ID(riskPos, ExtPos_Id));

	if ((ret = FIN_UpdRiskPosHier(posHierHead, domainArgPtr,
				      riskAcctPos, discInstrPtr, FALSE)) != RET_SUCCEED)
	{
		return(ret);
	}

	/* Update link between risk position and cash position */
	if ((ret = DBA_ForceLink(posHierHead, ExtPos,
				             ExtPos_Acct_ExtPos_Ext, riskPos, riskAcctPos)) != RET_SUCCEED)
	{
		return(ret);
	}

	/* -------------------------------------- */
	/* Modify accounting position information */
	/* -------------------------------------- */
	tmp =  GET_NUMBER(riskAcctPos, ExtPos_Qty) * -1.0;
	SET_NUMBER(riskAcctPos, ExtPos_Qty, tmp);

	for (k=ExtPos_SupplAmt; k<=ExtPos_BookSysNetAmt; k++)
	{
		tmp =  GET_AMOUNT(riskAcctPos, k) * -1.0;
		SET_AMOUNT(riskAcctPos, k, tmp);
	}

	for (k=ExtPos_Bp1PosAmt; k<ExtPos_BpPosAmtNb; k++)
	{
		tmp =  GET_AMOUNT(riskAcctPos, k) * -1.0;
		SET_AMOUNT(riskAcctPos, k, tmp);
	}

	if (GET_EXTENSION_PTR(riskPos, ExtPos_PosVal_Ext) != NULL &&
	    (posValPtr = *(GET_EXTENSION_PTR(riskPos, ExtPos_PosVal_Ext))) != NULL &&
	    GET_EXTENSION_PTR(origPos, ExtPos_PosVal_Ext) != NULL &&
	    (FRAPosValPtr = *(GET_EXTENSION_PTR(origPos, ExtPos_PosVal_Ext))) != NULL)
	{
		if ((pricePtr = ALLOC_DYNST(A_InstrPrice)) == NULL)
			MSG_RETURN(RET_MEM_ERR_ALLOC);

	   	/* Modify current price : difference between FRA price and rate price */
		price = CAST_PRICE(GET_PRICE(FRAPosValPtr, PosVal_Price) +
				    GET_PRICE(posValPtr, PosVal_Price));   /* REF3288 - SSO - 990205 */

		SET_ID(pricePtr,     A_InstrPrice_InstrId, GET_ID(discInstrPtr, A_Instr_Id));
		SET_ID(pricePtr,     A_InstrPrice_CurrId,  GET_ID(discInstrPtr, A_Instr_RefCurrId));
		SET_PRICE(pricePtr, A_InstrPrice_Quote,   price);
		SET_PRICE(pricePtr, A_InstrPrice_Price,   price);
		SET_ENUM(pricePtr,     A_InstrPrice_PriceCalcRuleEn, (ENUM_T) PriceCalcRule_Quote);
		SET_DATETIME(pricePtr, A_InstrPrice_QuoteDate,       domainArgPtr->fromDateTime);

		/*** COPY PRICE IN POSITION ***/
		if (FIN_SetPriceToPos(domainArgPtr->fromDateTime, domainArgPtr->refCurrId,
			              riskAcctPos, pricePtr, posHierHead) == TRUE) /* REF2580 - SSO - 980727 */
		{
	    		/*** COMPUTE POSITION NET VALUE ***/
	    		ret = FIN_PosNetVal(posHierHead, domainArgPtr, riskAcctPos,
					    NULL, aiArgPtr);
		}

		FREE_DYNST(pricePtr, A_InstrPrice);
	}

	/* Set created position to risk position */
	if (domainArgPtr->fundRiskEn != FinFundRisk_FundCompo)
	{ SET_ENUM(riskAcctPos, ExtPos_RiskNatEn, ExtPosRisk_FinRisk); }

	if (domainArgPtr->fundRiskEn != FinFundRisk_None)
	{ SET_ENUM(riskAcctPos, ExtPos_FundSplitNatEn, FundSplitNat_Split); }

	return(RET_SUCCEED);
}


/************************************************************************
**
**  Function    :   FIN_TreatFRARisk()
**
**  Description :   Create risk position(s) for FRA position
**
**  Arguments   :   posHierHead    hierarchy header pointer
**                  domainArgPtr   pointer on some domain informations
**                  origPos        original position pointer
**                  genInstrPtr    generic instrument pointer
**                  totPosRisk     total risk position pointer
**                  riskQtyStp     quantity structure pointer
**                  status         risk status (Father, Son, LastSon)
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation	:   REF2852 - RAK - 990119
**
*************************************************************************/
STATIC RET_CODE FIN_TreatFRARisk(DBA_HIER_HEAD_STP  posHierHead,
				                 FIN_DOMAIN_ARG_STP domainArgPtr,
				                 FIN_AIARG_STP      aiArgPtr,
                                 DBA_DYNFLD_STP     origPos,
				                 DBA_DYNFLD_STP     genInstrPtr,
				                 DBA_DYNFLD_STP     totPosRisk,
				                 RISK_QTY_STP       riskQtyStp,
				                 FIN_PRICEARG_STP   priceArgStp,
				                 RISK_ANALYSIS_ENUM status)
{
	FIN_MONEYMKTINFO_ST	infoSt;
	DBA_DYNFLD_STP		moneyMktPosPtr=NULL, moneyMktNegPtr=NULL,
				        underPtr=NULL;
	NUMBER_T		    ctdConvFact;
	PRICE_T			    price;
	ID_T			    underId;
	FIN_LIFE_ST 		uLifeSt;
	char			    hierFlg, ctdFlg;
	RET_CODE		    ret;

	memset(&uLifeSt, 0, sizeof(FIN_LIFE_ST));	/* REF3477 - RAK - 990325 */

	/* Use origPos for hierarchy count */
	ret = FIN_RiskSonPriceAmt(posHierHead, domainArgPtr, origPos, origPos,
				              genInstrPtr, totPosRisk, priceArgStp, status, &price, riskQtyStp, FALSE); /* PMSTA-34140 - RAK - 190122 - Add riskQtyStp for STN computation */

	if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
		return(ret);

	ret = FIN_GetFutFwdUnderlyInfo(genInstrPtr, domainArgPtr->fromDateTime, &underId,
				                   &ctdFlg, &ctdConvFact);

	if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
		return(ret);

	ret = FIN_GetHierInstr(posHierHead, underId, &hierFlg, &underPtr);

	if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
	{
		if (hierFlg == FALSE) { FREE_DYNST(underPtr, A_Instr); }
		return(ret);
	}

	if ((ret = FIN_InstrOrUnderlyLife(TRUE, genInstrPtr,
					                  domainArgPtr->fromDateTime,
                                      &uLifeSt, posHierHead)) != RET_SUCCEED)
	{
		if (hierFlg == FALSE) { FREE_DYNST(underPtr, A_Instr); }
		return(ret);
	}

	/* Create money market : set underlying identifier in parInstrId */
	infoSt.currId    = GET_ID(underPtr, A_Instr_RefCurrId);
	infoSt.underlyId = GET_ID(underPtr, A_Instr_Id);

	/* Fill key */

	strcpy(infoSt.code, GET_CODE(genInstrPtr, A_Instr_Cd));
	strcpy(infoSt.name, GET_NAME(genInstrPtr, A_Instr_Name));

	infoSt.accrRuleEn = (ACCRRULE_ENUM)GET_ENUM(underPtr, A_Instr_AccrualRuleEn); /* REF7264 - LJE - 020131 */
	infoSt.valRuleEn  = ValRule_Theo;

	/* Info for positiv money market ... */
	infoSt.begDate = GET_DATETIME(origPos, ExtPos_OpDate);

	infoSt.endDate.date = uLifeSt.begDate;
	infoSt.endDate.time = 0;

	infoSt.rate = 0.0;

	if ((ret = FIN_CreateInstrMoneyMkt(posHierHead, &infoSt, &moneyMktPosPtr)) != RET_SUCCEED)
	{
		if (hierFlg == FALSE) { FREE_DYNST(underPtr, A_Instr); }
		    return(ret);
	}

	COPY_DYNFLD(moneyMktPosPtr, A_Instr, A_Instr_YieldCurveInstrId,
		        underPtr,       A_Instr, A_Instr_YieldCurveInstrId);

	/* price computed by difference ... */
	if ((ret = FIN_TreatFRARiskMoneyMktPos(posHierHead, domainArgPtr, aiArgPtr, origPos,
				 	                       totPosRisk, riskQtyStp, priceArgStp, Risk_Son,
                                           moneyMktPosPtr, FALSE)) != RET_SUCCEED)
	{
		if (hierFlg == FALSE) { FREE_DYNST(underPtr, A_Instr); }
		FREE_DYNST(moneyMktPosPtr, A_Instr);
		return(ret);
	}

	/* Info for negativ money market ... */
	infoSt.begDate.date = uLifeSt.begDate;
	infoSt.begDate.time = 0;

	infoSt.endDate.date = uLifeSt.endDate;
	infoSt.endDate.time = 0;

	infoSt.rate = GET_PRICE(origPos, ExtPos_Quote);

	if ((ret = FIN_CreateInstrMoneyMkt(posHierHead, &infoSt, &moneyMktNegPtr)) != RET_SUCCEED)
	{
		if (hierFlg == FALSE) { FREE_DYNST(underPtr, A_Instr); }
		    return(ret);
	}

	COPY_DYNFLD(moneyMktNegPtr, A_Instr, A_Instr_YieldCurveInstrId,
		        underPtr,       A_Instr, A_Instr_YieldCurveInstrId);

	if ((ret = FIN_TreatFRARiskMoneyMktPos(posHierHead, domainArgPtr, aiArgPtr, origPos,
				 	                       totPosRisk, riskQtyStp, priceArgStp, Risk_LastSon,
                                           moneyMktNegPtr, TRUE)) != RET_SUCCEED)
	{
		if (hierFlg == FALSE) { FREE_DYNST(underPtr, A_Instr); }
		FREE_DYNST(moneyMktNegPtr, A_Instr);
		return(ret);
	}

	if (hierFlg == FALSE) { FREE_DYNST(underPtr, A_Instr); }
	return(RET_SUCCEED);
}



/************************************************************************
**
**  Function    :   FIN_TreatFRARiskMoneyMktPos()
**
**  Description :
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation	:
**  Modification:   REF7661 - YST - 020725
**
*************************************************************************/
STATIC RET_CODE FIN_TreatFRARiskMoneyMktPos(DBA_HIER_HEAD_STP  posHierHead,
				                            FIN_DOMAIN_ARG_STP domainArgPtr,
				                            FIN_AIARG_STP      aiArgPtr,
                                            DBA_DYNFLD_STP     origPos,
				                            DBA_DYNFLD_STP     totPosRisk,
				                            RISK_QTY_STP       riskQtyStp,
				                            FIN_PRICEARG_STP   priceArgStp,
				                            RISK_ANALYSIS_ENUM status,
				                            DBA_DYNFLD_STP     moneyMktPtr,
					                        char	           negFlg)
{
	DBA_DYNFLD_STP	ptfPtr=NULL, riskPos=NULL;
				    /*admArgPtr=NULL;   */            /* REF3777 - OCE - 990707 */
	ID_T			sysCurrId;
    FIN_EXCHARG_ST  exchArgSt;
	EXCHANGE_T		exch;
	FLAG_T			allocPtfFlg=FALSE;
	RET_CODE		ret;

	memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));
	/*DBA_SetConnectNoToExchArg(&exchArgSt, DBA_GetConnectNoFromHier(posHierHead));*/
	DBA_InitConnectNoToExchArg(&exchArgSt, posHierHead); /* REF4213 - SSO - 991221 */

	if ((riskPos = ALLOC_DYNST(ExtPos)) == NULL)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

	COPY_DYNST(riskPos, origPos, ExtPos);

	/* REF3118 - SSO - 981214 : get the syscurrid from ptf before from appl param */
	sysCurrId = 0;
	if (GET_EXTENSION_PTR(origPos , ExtPos_A_Ptf_Ext) != NULL &&
	    (ptfPtr = *(GET_EXTENSION_PTR(origPos, ExtPos_A_Ptf_Ext)))!= NULL)
	{
	    if (IS_NULLFLD(ptfPtr, A_Ptf_SysCurrId) == FALSE)
        { sysCurrId = GET_ID(ptfPtr, A_Ptf_SysCurrId); }
	}
	else
	{
	    if (IS_NULLFLD(riskPos, ExtPos_PtfId) == FALSE)
	    {
		    /* no ext set: get2 to do... */
		    /* REF3913 - Use hierarchy or get A_Ptf in db */
		    if ((ret = DBA_GetPtfById(GET_ID(riskPos, ExtPos_PtfId), FALSE, &allocPtfFlg,
	                                         &ptfPtr, posHierHead, UNUSED, UNUSED)) != RET_SUCCEED)
		    {
		        FREE_DYNST(riskPos, ExtPos);
		        return (ret);
		    }

		    if (IS_NULLFLD(ptfPtr, A_Ptf_SysCurrId) == FALSE)
            { sysCurrId = GET_ID(ptfPtr, A_Ptf_SysCurrId); }

		    if (allocPtfFlg == TRUE) { FREE_DYNST(ptfPtr, A_Ptf); }
	    }
	}

	if (sysCurrId == 0)
    { GEN_GetApplInfo(ApplSysCurrId, &sysCurrId); }

	/* A risk position parent can't be risk */
	SET_ENUM(origPos, ExtPos_RiskNatEn, ExtPosRisk_NoRisk);		/* BUG145 */

    /* REF7661 - YST - 020725 - risk position can't be main position */
    SET_FLAG(riskPos, ExtPos_MainFlg, FALSE);

	/* Suppress extension identifier (copied from origin position) */
	SET_NULL_ID(riskPos, ExtPos_MainExtPosId);
	SET_NULL_ID(riskPos, ExtPos_AcctExtPosId);
	SET_NULL_ID(riskPos, ExtPos_AdjustExtPosId);
	SET_NULL_ID(riskPos, ExtPos_PosValId);

	SET_ID(riskPos, ExtPos_InstrId,            GET_ID(moneyMktPtr, A_Instr_Id));
	SET_ID(riskPos, ExtPos_InstrCurrId,        GET_ID(moneyMktPtr, A_Instr_RefCurrId));
	SET_ID(riskPos, ExtPos_RiskOriginExtPosId, GET_ID(origPos, ExtPos_Id));
	SET_ID(riskPos, ExtPos_RiskParInstrId,     GET_ID(origPos, ExtPos_InstrId));

	if (GET_ID(riskPos, ExtPos_RefCurrId) != GET_ID(riskPos, ExtPos_PosCurrId))
	{
   		FIN_GetExchRate(GET_DATETIME(riskPos, ExtPos_BegDate),
		                GET_ID(riskPos, ExtPos_PosCurrId),
				        GET_ID(riskPos, ExtPos_RefCurrId),
			            (ID_T)0, NULL, origPos, &exchArgSt, &exch);  /* PMSTA01649 - TGU - 070402 */
	    SET_EXCHANGE(riskPos, ExtPos_PosExchRate, exch);
	}
	else
	{ SET_EXCHANGE(riskPos, ExtPos_PosExchRate, 1.0); }

	if (GET_ID(riskPos, ExtPos_RefCurrId) != GET_ID(riskPos, ExtPos_InstrCurrId))
	{
		FIN_GetExchRate(GET_DATETIME(riskPos, ExtPos_BegDate),
		                GET_ID(riskPos, ExtPos_InstrCurrId),
			            GET_ID(riskPos, ExtPos_RefCurrId),
			            (ID_T)0, NULL, origPos, &exchArgSt, &exch);  /* PMSTA01649 - TGU - 070402 */
	    SET_EXCHANGE(riskPos, ExtPos_InstrExchRate, exch);
	}
	else
	{ SET_EXCHANGE(riskPos, ExtPos_InstrExchRate, 1.0); }

	if (GET_ID(riskPos, ExtPos_RefCurrId) != sysCurrId)
	{
   	        FIN_GetExchRate(GET_DATETIME(riskPos, ExtPos_BegDate), sysCurrId,
		                    GET_ID(riskPos, ExtPos_RefCurrId),
			                (ID_T)0, NULL, origPos, &exchArgSt, &exch);     /* PMSTA01649 - TGU - 070402 */
	        SET_EXCHANGE(riskPos, ExtPos_SysExchRate, exch);
	}
	else
	{ SET_EXCHANGE(riskPos, ExtPos_SysExchRate, 1.0); }

	if (negFlg == TRUE)
	{
		NUMBER_T qty = GET_NUMBER(riskPos, ExtPos_Qty) * -1.0;
		SET_NUMBER(riskPos, ExtPos_Qty, qty);
	}

	ret = FIN_AddValoRiskPos(posHierHead, domainArgPtr, aiArgPtr, origPos, riskPos, moneyMktPtr,
							 TRUE, totPosRisk, priceArgStp, status, (FIN_OPTINFO_STP)NULL,
				             NULL, nullptr, riskQtyStp); /* PMSTA-35133 - RAK - 190517 */
	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_TreatFutFwdRisk()
**
**  Description :   Create risk position(s) for future and forward position
**
**  Arguments   :   posHierHead    hierarchy header pointer
**                  domainArgPtr   pointer on some domain informations
**                  origPos        original position pointer
**                  genInstrPtr    generic instrument pointer
**                  instrHierFlg   instrument already in hierarchy or not
**                  totPosRisk     total risk position pointer
**                  riskQtyStp     quantity structure pointer
**                  status         risk status (Father, Son, LastSon)
**                  riskFutFwdEn   future or forward  (RiskFutFwd_None, ...)
**
**  Return      :   RET_SUCCEED or error code
**
**  Modif.      :   DVP187 - RAK - 960829
**  Modif.      :   DVP190 - RAK - 960830
**  Modif.      :   DVP191 - RAK - 960830
**  Modif.      :   DVP189 - RAK - 960902
**  Modif.      :   BUG145 - RAK - 961008
**  Modif.      :   REF1457 - RAK - 980324
**  Modif.	    :   REF495 - RAK - 980520
**  Modif.	    :   REF2313 - RAK - 980910
**  Modif.	    :   REF2507 - RAK - 980703
**  Modif.	    :   REF2580 - SSO - 980727
**		            REF3118 - SSO - 981214
**                  REF5086 - AKO - 000809
**                  REF7661 - YST - 020725
*************************************************************************/
STATIC RET_CODE FIN_TreatFutFwdRisk(DBA_HIER_HEAD_STP  posHierHead,
									DBA_DYNFLD_STP		domainPtr,	/* PMSTA-10111 - RAK - 110311 - add domainPtr as arg */
				                    FIN_DOMAIN_ARG_STP domainArgPtr,
				                    FIN_AIARG_STP      aiArgPtr,
                                    DBA_DYNFLD_STP     origPos,
				                    DBA_DYNFLD_STP     genInstrPtr,
				                    char               instrHierFlg,
				                    DBA_DYNFLD_STP     totPosRisk,
				                    RISK_QTY_STP       riskQtyStp,	/* DVP189 */
				                    FIN_PRICEARG_STP   priceArgStp,	/* REF3030 */
				                    RISK_ANALYSIS_ENUM status,
				                    RISK_FUTFWD_ENUM   riskFutFwdEn)
{
	DBA_DYNFLD_STP 	riskPos=NULL, underPtr=NULL, moneyMktPtr=NULL,
		       	    currInstr=NULL, discountPtr=NULL,
		       	    pricePtr=NULL /* DVP190 */, acctPos=nullptr,
			        ptfPtr=NULL;
	ID_T           	underId, sysCurrId;
	PRICE_T       	price, quote;
	NUMBER_T	ctdConvFact, qty, unitAI=0.0;
	AMOUNT_T       	amt, grossAmt, exchAmt;
	EXCHANGE_T     	exch;
	FORWARD_VAL_ENUM valRule;
	FLAG_T		    allocPtfFlg=FALSE;
	char            hierFlg, currHierFlg, exchFwdFlg, ctdFlg /* DVP190 */, newInstrFlg=FALSE /* REF2507 */;
	RET_CODE        ret;
	FIN_EXCHARG_ST  exchArgSt;			/* REF2313 */
	RISKFUTRULE_ENUM riskFut;

	memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));	/* REF2313 */
	/*DBA_SetConnectNoToExchArg(&exchArgSt, DBA_GetConnectNoFromHier(posHierHead));*/ /* REF2580 - SSO - 980727 */
	DBA_InitConnectNoToExchArg(&exchArgSt, posHierHead); /* REF4213 - SSO - 991221 */

	GEN_GetApplInfo(ApplForwardValRule, &valRule);
	GEN_GetApplInfo(ApplRiskFutRule, &riskFut);

	/* REF3030 - New system forward valuation rule is blocked */
	valRule = Forward_Extrapo;

	if ((riskPos = ALLOC_DYNST(ExtPos)) == NULL)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

	COPY_DYNST(riskPos, origPos, ExtPos);

	/* REF3118 - SSO - 981214 : get the syscurrid from ptf before from appl param */
	sysCurrId = 0;
	if (GET_EXTENSION_PTR(origPos , ExtPos_A_Ptf_Ext) != NULL &&
	    (ptfPtr = *(GET_EXTENSION_PTR(origPos, ExtPos_A_Ptf_Ext)))!= NULL)
	{
	    if (IS_NULLFLD(ptfPtr, A_Ptf_SysCurrId) == FALSE)
	    {
		    sysCurrId = GET_ID(ptfPtr, A_Ptf_SysCurrId);
	    }
	}
	else
	{
	    if (IS_NULLFLD(riskPos, ExtPos_PtfId) == FALSE)
	    {
		    /* no ext set: get2 to do... */
		    /* REF3913 - Use hierarchy or get A_Ptf in db */
		    if ((ret = DBA_GetPtfById(GET_ID(riskPos, ExtPos_PtfId), FALSE, &allocPtfFlg,
	                                  &ptfPtr, posHierHead, UNUSED, UNUSED)) != RET_SUCCEED)
		    {
		        FREE_DYNST(riskPos, ExtPos);
		        return (ret);
		    }

		    if (IS_NULLFLD(ptfPtr, A_Ptf_SysCurrId) == FALSE)
		    {
		        sysCurrId = GET_ID(ptfPtr, A_Ptf_SysCurrId);
		    }

		    if (allocPtfFlg == TRUE) { FREE_DYNST(ptfPtr, A_Ptf); }
	    }
	}

	if (sysCurrId == 0)
	{
	    GEN_GetApplInfo(ApplSysCurrId, &sysCurrId);
	}

	/* A risk position parent can't be risk */
	SET_ENUM(origPos, ExtPos_RiskNatEn, ExtPosRisk_NoRisk);		/* BUG145 */

    /* REF7661 - YST - 020725 - risk position can't be main position */
    SET_FLAG(riskPos, ExtPos_MainFlg, FALSE);

    /* Suppress extension identifier (copied from origin position) */
	SET_NULL_ID(riskPos, ExtPos_MainExtPosId);
	SET_NULL_ID(riskPos, ExtPos_AcctExtPosId);
	SET_NULL_ID(riskPos, ExtPos_AdjustExtPosId);
	SET_NULL_ID(riskPos, ExtPos_PosValId);

	/* DVP191 */
	ret = FIN_GetFutFwdUnderlyInfo(genInstrPtr, domainArgPtr->fromDateTime, &underId,
				                   &ctdFlg, &ctdConvFact);

    if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
	{
	    FREE_DYNST(riskPos, ExtPos);
	    return(ret);
	}

	ret = FIN_GetHierInstr(posHierHead, underId, &hierFlg, &underPtr);

	if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
	{
		if (hierFlg == FALSE) { FREE_DYNST(underPtr, A_Instr); }
		    return(ret);
	}

	/* PMSTA-9376 - RAK - 100901 */
	if ((INSTRNAT_ENUM) GET_ENUM(genInstrPtr, A_Instr_NatEn) == InstrNat_Future &&
		riskFut == RiskFutRule_UnderlyPosAndTimeValue)
	{
		ret = FIN_RiskUnderlyExtPosPriceAndAI(posHierHead, origPos, underPtr, &price, &unitAI);
	}
	else
	{
		/* Use origPos for hierarchy count */
		ret = FIN_RiskSonPriceAmt(posHierHead, domainArgPtr, origPos, origPos,
				              genInstrPtr, totPosRisk, priceArgStp, status, &price, riskQtyStp, FALSE); /* PMSTA-34140 - RAK - 190122 - Add riskQtyStp for STN computation */
	}

	if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
	{
		if (hierFlg == FALSE) { FREE_DYNST(underPtr, A_Instr); }
		    return(ret);
	}

	/*** ADD RISK POSITION (can be only risk flag to set) ***/
	if (riskFutFwdEn == RiskFutFwd_None)
	{
	    if (GET_ID(genInstrPtr, A_Instr_RefCurrId) ==  GET_ID(underPtr, A_Instr_RefCurrId))
	    {
		    if (domainArgPtr->fundRiskEn != FinFundRisk_FundCompo)
		        SET_ENUM(origPos, ExtPos_RiskNatEn, ExtPosRisk_FinRisk);

	        if (domainArgPtr->fundRiskEn != FinFundRisk_None)
		        SET_ENUM(origPos,ExtPos_FundSplitNatEn, FundSplitNat_Split);

		    if (hierFlg == FALSE) { FREE_DYNST(underPtr, A_Instr); }
		        return(RET_SUCCEED);
	    }
	    else
		    riskFutFwdEn = RiskFutFwd_FutFwd;
	}

	/*** ADD UNDERLYING POSITION ***/
	exchFwdFlg = FALSE;
	if (riskFutFwdEn == RiskFutFwd_Underly)
	{
	    if ((INSTRNAT_ENUM) GET_ENUM(genInstrPtr, A_Instr_NatEn) == InstrNat_FRA ||
	        ((INSTRNAT_ENUM) GET_ENUM(genInstrPtr, A_Instr_NatEn) == InstrNat_Future &&
		    (INSTRNAT_ENUM) GET_ENUM(underPtr, A_Instr_NatEn) == InstrNat_Rate))
	    {
		    /* Create money market : set underlying identifier in parInstrId */
		    FIN_MONEYMKTINFO_ST	infoSt;
		    double     		freq;

		    strcpy(infoSt.code, GET_CODE(underPtr, A_Instr_Cd));
		    strcpy(infoSt.name, GET_NAME(underPtr, A_Instr_Name));

		    infoSt.currId    = GET_ID(underPtr, A_Instr_RefCurrId);
		    infoSt.underlyId = GET_ID(underPtr, A_Instr_Id);

		    infoSt.begDate.date = GET_DATE(genInstrPtr, A_Instr_EndDate);
		    infoSt.begDate.time = 0;

		    FIN_PeriodUnitNbr((FREQUNIT_ENUM)GET_ENUM(underPtr, A_Instr_RateFreqUnitEn),  /* REF7264 - LJE - 020131 */
		                      GET_SMALLINT(underPtr, A_Instr_RateFreq), /* PMSTA-45526 - VSW - 080721 */
                              FreqUnit_Month, &freq);
		    infoSt.endDate.date = DATE_Move(infoSt.begDate.date, (int)freq, Month);
		    infoSt.endDate.time = 0;

		    infoSt.accrRuleEn = (ACCRRULE_ENUM)GET_ENUM(underPtr, A_Instr_AccrualRuleEn); /* REF7264 - LJE - 020131 */
		    infoSt.valRuleEn  = ValRule_Theo;	/* REF53.1 */

		    if ((INSTRNAT_ENUM) GET_ENUM(genInstrPtr, A_Instr_NatEn) == InstrNat_FRA)
		    { infoSt.rate = GET_PRICE(origPos, ExtPos_Quote); }
		    else
		    { infoSt.rate = (100.0 - GET_PRICE(origPos, ExtPos_Quote)) / 100.0; }

		    if ((ret = FIN_CreateInstrMoneyMkt(posHierHead, &infoSt,
						                       &moneyMktPtr)) != RET_SUCCEED)
		    {
			    if (hierFlg == FALSE) { FREE_DYNST(underPtr, A_Instr); }
			        return(ret);
		    }

		    /* current instrument is created money market */
		    currInstr = moneyMktPtr;
		    currHierFlg = TRUE;
		    newInstrFlg = TRUE;	/* REF2507 - risk position is created on an other instrument */
	    }
	    else
	    {
	        currInstr   = underPtr;
	        currHierFlg = hierFlg;
		    newInstrFlg = TRUE;	/* REF2507 - risk position is created on an other instrument */

	        /* Exchange forward  DVP190 */
	        if ((INSTRNAT_ENUM) GET_ENUM(genInstrPtr, A_Instr_NatEn) == InstrNat_Forward)
	        {
	    	    if ((INSTRNAT_ENUM) GET_ENUM(underPtr, A_Instr_NatEn) == InstrNat_CashAcct)
		        {
		            exchFwdFlg = TRUE;
		        }
	        }
	    }
	}
	else
	{
	    if (GET_ID(genInstrPtr, A_Instr_RefCurrId) == GET_ID(underPtr, A_Instr_RefCurrId))
	    {
	    	/* Use existent fwd */
	    	currInstr   = genInstrPtr;
	    	currHierFlg = instrHierFlg;
	    }
	    else
	    {
		    /* Create a new fwd instrument in underly currency */
		    if ((currInstr = ALLOC_DYNST(A_Instr)) == NULL)
		    {
			    if (hierFlg == FALSE) { FREE_DYNST(underPtr, A_Instr); }
			    MSG_RETURN(RET_MEM_ERR_ALLOC);
		    }

		    COPY_DYNST(currInstr, genInstrPtr, A_Instr);

	   	    /* REF2507 - Currency modification is missing */
		    /* REF3030 - We don't understand this modification .... */
		    if ((VALRULE_ENUM) GET_ENUM(genInstrPtr, A_Instr_ValRuleEn) == ValRule_Theo)
		    {
		        SET_ID(currInstr, A_Instr_RefCurrId,
		            GET_ID(underPtr, A_Instr_RefCurrId));
		    }

		    /* REF2507 - For non-generic instrument (future) modify parent instrument identifier */
		    if (IS_NULLFLD(currInstr, A_Instr_ParentInstrId) == TRUE)
		    {
			    SET_ID(currInstr, A_Instr_ParentInstrId,
			        GET_ID(currInstr, A_Instr_Id));
		    }
		    SET_NULL_ID(currInstr, A_Instr_Id);
	    	currHierFlg = FALSE;
	    }
	}

	SET_ID(riskPos, ExtPos_InstrId,    GET_ID(currInstr, A_Instr_Id));
	SET_ID(riskPos, ExtPos_InstrCurrId,GET_ID(currInstr,A_Instr_RefCurrId));

	/* Position is in origin position currency except for curr */
	/* PMSTA-8736 - RAK - 100114 - Why not a bond in other currency as underlying */
	/* if ((INSTRNAT_ENUM) GET_ENUM(currInstr, A_Instr_NatEn) == InstrNat_CashAcct) */
	{   SET_ID(riskPos, ExtPos_PosCurrId, GET_ID(currInstr, A_Instr_RefCurrId)); }

	/* DVP190 */
	if (exchFwdFlg == FALSE)	/* Future, FRA */
	{
	    if (GET_ID(riskPos, ExtPos_RefCurrId) != GET_ID(riskPos, ExtPos_PosCurrId))
	    {
			/* PMSTA-8736 - RAK - 100125 - Use positon exchange rate */
			if ((INSTRNAT_ENUM) GET_ENUM(genInstrPtr, A_Instr_NatEn) == InstrNat_Forward)
			{
				exch = GET_EXCHANGE(origPos, ExtPos_PosExchRate);
			}
			else
			{
   				FIN_GetExchRate(GET_DATETIME(riskPos, ExtPos_BegDate),
		                    GET_ID(riskPos,ExtPos_PosCurrId),GET_ID(riskPos,ExtPos_RefCurrId),
			                (ID_T)0, NULL, origPos, &exchArgSt, &exch);	/* PMSTA01649 - TGU - 070402 */
			}
	        SET_EXCHANGE(riskPos, ExtPos_PosExchRate, exch);
	    }
	    else
	    { SET_EXCHANGE(riskPos, ExtPos_PosExchRate, 1.0); }

	    if (GET_ID(riskPos, ExtPos_RefCurrId) != GET_ID(riskPos, ExtPos_InstrCurrId))
	    {
			/* PMSTA-8736 - RAK - 100125 - Use positon exchange rate */
			if ((INSTRNAT_ENUM) GET_ENUM(genInstrPtr, A_Instr_NatEn) == InstrNat_Forward)
			{
				exch = GET_EXCHANGE(origPos, ExtPos_InstrExchRate);
			}
			else
			{
				FIN_GetExchRate(GET_DATETIME(riskPos, ExtPos_BegDate),
		                    GET_ID(riskPos, ExtPos_InstrCurrId),
				            GET_ID(riskPos, ExtPos_RefCurrId),
			                (ID_T)0, NULL, origPos, &exchArgSt, &exch);	/* PMSTA01649 - TGU - 070402 */
			}
	        SET_EXCHANGE(riskPos, ExtPos_InstrExchRate, exch);
	    }
	    else
	    { SET_EXCHANGE(riskPos, ExtPos_InstrExchRate, 1.0); }

	    if (GET_ID(riskPos, ExtPos_RefCurrId) != sysCurrId)
	    {
			/* PMSTA-8736 - RAK - 100125 - Use positon exchange rate */
			if ((INSTRNAT_ENUM) GET_ENUM(genInstrPtr, A_Instr_NatEn) == InstrNat_Forward)
			{
				exch = GET_EXCHANGE(origPos, ExtPos_SysExchRate);
			}
			else
			{
   				FIN_GetExchRate(GET_DATETIME(riskPos, ExtPos_BegDate), sysCurrId,
		                    GET_ID(riskPos, ExtPos_RefCurrId),
			                (ID_T)0, NULL, origPos, &exchArgSt, &exch);	/* PMSTA01649 - TGU - 070402 */
			}
	        SET_EXCHANGE(riskPos, ExtPos_SysExchRate, exch);
	    }
	    else
	    { SET_EXCHANGE(riskPos, ExtPos_SysExchRate, 1.0); }
	}

	/* DVP190 */
	if (exchFwdFlg == TRUE)	/* Cash price is 1.0 */
		price = 1.0;

	/* DVP191 */
	if (ctdFlg == TRUE)
	{
	    if ((pricePtr = ALLOC_DYNST(A_InstrPrice)) == NULL)
	    {
	  	    if (hierFlg == FALSE) { FREE_DYNST(underPtr, A_Instr); }
		    MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }

	    if ((ret = FIN_InstrPrice(GET_ID(currInstr, A_Instr_Id), currInstr,
			                      domainArgPtr->fromDateTime, NULL,
				                  (ID_T)0, NULL, NULL,
                                  riskPos, posHierHead, pricePtr, FALSE)) != RET_SUCCEED) /* PMSTA14876 - DDV - 120911 - Add a new parameter, no impact for this call */
	    {
		    FREE_DYNST(pricePtr, A_InstrPrice);
		    if (hierFlg == FALSE) { FREE_DYNST(underPtr, A_Instr); }
            /* REF5086 - AKO - 000809 */
		    /* MSG_RETURN(RET_MEM_ERR_ALLOC); */

		    MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, "FIN_InstrPrice",
				         GET_CODE(currInstr, A_Instr_Cd), "Cannot retrieve price !");
            return(ret);
	    }

	    price = GET_PRICE(pricePtr, A_InstrPrice_Price);
	    quote = GET_PRICE(pricePtr, A_InstrPrice_Quote);
	    FREE_DYNST(pricePtr, A_InstrPrice);
	}
	else	/* use FIN_RiskSonPriceAmt() price */
	{
	    FIN_PriceToQuote((PRICECALCRULE_ENUM)GET_ENUM(currInstr, A_Instr_PriceCalcRuleEn), 	/* DVP440 */ /* REF7264 - LJE - 020131 */
			             GET_ID(currInstr, A_Instr_Id), currInstr,
			             GET_DATETIME(riskPos, ExtPos_BegDate), NULL,
			             price, &quote, posHierHead);
	}

	/* DVP189 */
	if (riskQtyStp->idxCalcRuleEn == IdxCalcRule_PctValue)
	{
	    PRICE_T       tmpPrice = 0.0;

	    if ((ret = FIN_PosPrice(riskPos, currInstr, domainArgPtr->fromDateTime,
				                priceArgStp, riskQtyStp->pricePtr,
                                NULL, posHierHead)) == RET_SUCCEED)
	    {
	        if (GET_ID(riskQtyStp->pricePtr, A_InstrPrice_CurrId) != riskQtyStp->priceCurrId)
	        {
   	            FIN_GetExchRate(GET_DATETIME(riskPos, ExtPos_BegDate),
		                        GET_ID(riskQtyStp->pricePtr, A_InstrPrice_CurrId),
				riskQtyStp->priceCurrId, (ID_T)0, NULL, origPos, &exchArgSt, &exch);	/* PMSTA01649 - TGU - 070402 */
		    }
		    else
			    exch = 1.0;

		    tmpPrice = GET_PRICE(riskQtyStp->pricePtr, A_InstrPrice_Price) * exch;
	    }

	    if (ret != RET_SUCCEED || tmpPrice == 0.0)
	    {
		    FREE_DYNST(riskPos, ExtPos);
		    MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }

	    qty = riskQtyStp->qty / tmpPrice;
	}
	else
	{
	    if (ctdFlg == TRUE && ctdConvFact != 0.0)	/* DVP191 */
		    qty = riskQtyStp->qty / ctdConvFact;    /* BUG308 - XDI - 970319 */
	    else
		    qty = riskQtyStp->qty;
	}

	/* DVP440 - RAK - 970501 */
	if ((INSTRNAT_ENUM) GET_ENUM(genInstrPtr, A_Instr_NatEn) == InstrNat_FRA ||
	    ((INSTRNAT_ENUM) GET_ENUM(genInstrPtr, A_Instr_NatEn) == InstrNat_Forward &&
	      valRule == Forward_Point))	/* REF495 */
		qty *= -1.0;

	SET_NUMBER(riskPos, ExtPos_Qty,   CAST_NUMBER(qty)); /* REF3288 - SSO - 990205 */
	SET_PRICE(riskPos, ExtPos_Price, CAST_PRICE(price)); /* REF3288 - SSO - 990205 */
	SET_PRICE(riskPos, ExtPos_Quote, CAST_PRICE(quote)); /* REF3288 - SSO - 990205 */

	SET_NULL_PRICE(riskPos, ExtPos_SpotPrice);	/* DVP190 */
	SET_NULL_PRICE(riskPos, ExtPos_SpotQuote);	/* DVP190 */

	amt		 = qty * price;
	grossAmt = qty * (price + unitAI);	/* PMSTA-8736 - RAK - 091123 */

	SET_NUMBER(riskPos, ExtPos_Qty, CAST_NUMBER(qty)); /* REF3288 - SSO - 990205 */
	SET_AMOUNT(riskPos, ExtPos_PosGrossAmt, grossAmt);
	SET_AMOUNT(riskPos, ExtPos_PosNetAmt, amt);

	if (GET_ID(riskPos, ExtPos_PosCurrId) == GET_ID(riskPos, ExtPos_InstrCurrId))
	{
		SET_AMOUNT(riskPos, ExtPos_InstrGrossAmt, grossAmt);
		SET_AMOUNT(riskPos, ExtPos_InstrNetAmt, amt);
	}
	else
	{
		/* PMSTA-8736 - RAK - 100125 - Use calculated exchRate */
		exchAmt = CAST_AMOUNT((amt * GET_EXCHANGE(riskPos, ExtPos_InstrExchRate)),
			GET_ID(riskPos, ExtPos_InstrCurrId));
		SET_AMOUNT(riskPos, ExtPos_InstrNetAmt, exchAmt);

		exchAmt = CAST_AMOUNT((grossAmt * GET_EXCHANGE(riskPos, ExtPos_InstrExchRate)),
			GET_ID(riskPos, ExtPos_InstrCurrId));
		SET_AMOUNT(riskPos, ExtPos_InstrGrossAmt, exchAmt);
	}

	if (GET_ID(riskPos, ExtPos_PosCurrId) == GET_ID(riskPos, ExtPos_RefCurrId))
	{
		SET_AMOUNT(riskPos, ExtPos_RefGrossAmt, grossAmt);
		SET_AMOUNT(riskPos, ExtPos_RefNetAmt, amt);
	}
	else
	{
		/* DVP190 */
		if (exchFwdFlg == TRUE)
		{
			acctPos = NULL;
			if (GET_EXTENSION_PTR(origPos, ExtPos_Acct_ExtPos_Ext) != NULL &&
				(acctPos = *(GET_EXTENSION_PTR(origPos, ExtPos_Acct_ExtPos_Ext))) != NULL)
				exchAmt = GET_AMOUNT(acctPos, ExtPos_RefNetAmt) * -1.0;
			else
				exchAmt = 1.0;

			SET_AMOUNT(riskPos, ExtPos_RefGrossAmt, exchAmt);
			SET_AMOUNT(riskPos, ExtPos_RefNetAmt, exchAmt);
		}
		else
		{
			/* PMSTA-8736 - RAK - 100125 - Use calculated exchRate */
			exchAmt = CAST_AMOUNT((amt * GET_EXCHANGE(riskPos, ExtPos_PosExchRate)),
				GET_ID(riskPos, ExtPos_RefCurrId));
			SET_AMOUNT(riskPos, ExtPos_RefNetAmt, exchAmt);

			exchAmt = CAST_AMOUNT((grossAmt * GET_EXCHANGE(riskPos, ExtPos_PosExchRate)),
				GET_ID(riskPos, ExtPos_RefCurrId));
			SET_AMOUNT(riskPos, ExtPos_RefGrossAmt, exchAmt);
		}
	}

	if (GET_ID(riskPos, ExtPos_PosCurrId) == sysCurrId)
	{
		SET_AMOUNT(riskPos, ExtPos_SysGrossAmt, grossAmt);
		SET_AMOUNT(riskPos, ExtPos_SysNetAmt, amt);
	}
	else
	{
		if (exchFwdFlg == TRUE)
		{
			acctPos = NULL;
			if (GET_EXTENSION_PTR(origPos, ExtPos_Acct_ExtPos_Ext) != NULL &&
				(acctPos = *(GET_EXTENSION_PTR(origPos, ExtPos_Acct_ExtPos_Ext))) != NULL)
				exchAmt = GET_AMOUNT(acctPos, ExtPos_SysNetAmt) * -1.0;
			else
				exchAmt = 1.0;

			SET_AMOUNT(riskPos, ExtPos_SysGrossAmt, exchAmt);
			SET_AMOUNT(riskPos, ExtPos_SysNetAmt, exchAmt);
		}
		else
		{
			/* PMSTA-8736 - RAK - 100125 - Use calculated exchRate */
			exchAmt = CAST_AMOUNT((amt * GET_EXCHANGE(riskPos, ExtPos_SysExchRate)), sysCurrId);
			SET_AMOUNT(riskPos, ExtPos_SysNetAmt, exchAmt);

			exchAmt = CAST_AMOUNT((grossAmt * GET_EXCHANGE(riskPos, ExtPos_SysExchRate)), sysCurrId);
			SET_AMOUNT(riskPos, ExtPos_SysNetAmt, exchAmt);
		}
	}

	/* DVP190 */
	if (exchFwdFlg == TRUE)
	{
		exch = GET_AMOUNT(riskPos, ExtPos_RefNetAmt) /
			GET_AMOUNT(riskPos, ExtPos_SysNetAmt);
		SET_EXCHANGE(riskPos, ExtPos_SysExchRate, exch);

		exch = GET_AMOUNT(riskPos, ExtPos_RefNetAmt) /
			GET_AMOUNT(riskPos, ExtPos_PosNetAmt);
		SET_EXCHANGE(riskPos, ExtPos_PosExchRate, exch);

		exch = GET_AMOUNT(riskPos, ExtPos_RefNetAmt) /
			GET_AMOUNT(riskPos, ExtPos_InstrNetAmt);
		SET_EXCHANGE(riskPos, ExtPos_InstrExchRate, exch);
	}

	/* For risk position link */	/* DVP187 */
	FIN_RiskPosLink(riskPos, origPos, GET_ID(origPos, ExtPos_InstrId));

	/* REF495 - Create a discount like underlyning.  */
	if ((INSTRNAT_ENUM) GET_ENUM(genInstrPtr, A_Instr_NatEn) == InstrNat_Forward &&
	    valRule == Forward_Point)
	{
		if ((ret = FIN_CreateInstrDiscount(posHierHead, currInstr,
			       GET_DATE(genInstrPtr, A_Instr_BeginDate),
			       GET_DATE(genInstrPtr, A_Instr_EndDate),
			       &discountPtr))!=RET_SUCCEED)
			return(ret);

		currInstr   = discountPtr;
		currHierFlg = TRUE;
	}

	/* DVP191 */ /* PMSTA-35133 - RAK - 190519 - change call with ctdFlg and riskQtyStp */
	ret = FIN_AddValoRiskPos(posHierHead, domainArgPtr, aiArgPtr, origPos, riskPos, currInstr,
				                 currHierFlg, totPosRisk, priceArgStp, status,
								 (FIN_OPTINFO_STP)NULL, (ctdFlg ? &ctdConvFact : NULL), nullptr, riskQtyStp);

	/* In case of generated instrument, must be decomposed */	/* BUG145 */
	/* REF2507 - Verify new risk position if it's in an "new" instrument (underlying) */
	if (ret == RET_SUCCEED && newInstrFlg == TRUE)
		ret = FIN_RiskAnalysis(posHierHead, domainPtr, domainArgPtr, aiArgPtr, riskPos);

	if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
		return(ret);

	/* REF53.1 - Modify cash position and create a discount instrument instead of the cash */
	if ((INSTRNAT_ENUM) GET_ENUM(genInstrPtr, A_Instr_NatEn) == InstrNat_FRA ||
	    ((INSTRNAT_ENUM) GET_ENUM(genInstrPtr, A_Instr_NatEn) == InstrNat_Forward &&
	      valRule == Forward_Point))	/* REF495 */
	{
		ret = FIN_TreatFRACashPos(posHierHead, domainArgPtr, aiArgPtr,
					              origPos, riskPos, genInstrPtr);
		if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
			return(ret);
	}

	/* PMSTA-8736 - RAK - 091104 */
	if ((INSTRNAT_ENUM) GET_ENUM(genInstrPtr, A_Instr_NatEn) == InstrNat_Future)
	{
		/* Create the Time Value leg */
		if (riskFut == RiskFutRule_UnderlyPosAndTimeValue)
		{
			FIN_TreatFutTimeValue(posHierHead, domainArgPtr, origPos, riskPos);
		}
	}

	return(RET_SUCCEED);	/* suppress INFO RET_CODE */
}


/************************************************************************
**
**  Function    :   FIN_RiskUnderlyExtPosPriceAndAI()
**
**  Description :   Compute underlying leg price and AI
**
**  Arguments   :   posHierHead    hierarchy header pointer
**                  origPos        original position pointer
**                  instrPtr       instrument pointer
**                  totPosRisk     total risk position pointer
**                  riskQtyStp     quantity structure pointer
**
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation	:	PMSTA-8736 - RAK -  091123
**
*************************************************************************/
STATIC RET_CODE FIN_RiskUnderlyExtPosPriceAndAI(DBA_HIER_HEAD_STP	posHierHead,
												 DBA_DYNFLD_STP		origPos,
												 DBA_DYNFLD_STP		underInstrPtr,
												 PRICE_T			*price,
												 NUMBER_T			*unitAI)
{
	RET_CODE			ret=RET_SUCCEED;
	DBA_DYNFLD_STP		pricePtr=NULLDYNST, unitInterPtr;
	FLAG_T				fullCoupFlg, calcAccrInterFlg;
	DATETIME_T			calcDate;
	FIN_EXCHARG_ST		exchArgSt;
	EXCHANGE_T			exch=1.0;
	DATE_T				fusionSwitchDate;
	FUSDATERULE_ENUM	fusDateRule = FusDateRule_None;

	memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));
	*price = 0.0;
	*unitAI = 0.0;

	calcDate=GET_DATETIME(origPos, ExtPos_BegDate);

	GEN_GetApplInfo(FullCouponFlag, &fullCoupFlg);

	if ((pricePtr = ALLOC_DYNST(A_InstrPrice)) == NULL)
	{
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	if ((ret = FIN_InstrPrice(GET_ID(underInstrPtr, A_Instr_Id), underInstrPtr,
			                  calcDate, NULL,
				              (ID_T)0, NULL, NULL,
                              origPos, posHierHead, pricePtr, FALSE)) != RET_SUCCEED) /* PMSTA14876 - DDV - 120911 - Add a new parameter, no impact for this call */
	{
		FREE_DYNST(pricePtr, A_InstrPrice);
		MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, "FIN_InstrPrice",
				         GET_CODE(underInstrPtr, A_Instr_Cd), "Cannot retrieve price !");
		return(ret);
	}

	*price = GET_PRICE(pricePtr, A_InstrPrice_Price);
	FREE_DYNST(pricePtr, A_InstrPrice);

	if ((unitInterPtr = ALLOC_DYNST(UnitInter)) == NULL)
	{ MSG_RETURN(RET_MEM_ERR_ALLOC); }

	/* If system parameter is set, and date is before switch date, use  OldFusionDateRule */
	if (GEN_GetApplInfo(ApplFusionSwitchDate, &fusionSwitchDate) == FALSE ||
		fusionSwitchDate == MAGIC_END_DATE )
	{
		GEN_GetApplInfo(ApplFusDateRule, &fusDateRule);
	}
	else
	{
		if (DATE_Cmp(calcDate.date, fusionSwitchDate) < 0)
		{
			GEN_GetApplInfo(ApplOldFusionDateRule, &fusDateRule);
		}
		else
		{
			GEN_GetApplInfo(ApplFusDateRule, &fusDateRule);
		}
	}

	GEN_GetApplInfo(FullCouponFlag, &fullCoupFlg);

	if (fusDateRule == FusDateRule_None)
		calcAccrInterFlg = FALSE;
	else
		calcAccrInterFlg = TRUE;

	/* Compute AI */
	ret = FIN_UnitAccrInter(calcDate,
							GET_ID(underInstrPtr, A_Instr_Id), underInstrPtr,
							fusDateRule, fullCoupFlg, calcAccrInterFlg,
							AccrInterMethod_Default, calcDate,
							AccrRule_None, NULLDYNST,
					        unitInterPtr, posHierHead, FALSE, NULL);

	if (RET_GET_LEVEL(ret) != RET_LEV_ERROR && ret != RET_GEN_INFO_NOACTION)
	{
		if (GET_NUMBER(unitInterPtr, UnitInter_UnitAccrInter) != 0.0 &&
            GET_ID(unitInterPtr, UnitInter_CurrId) !=
            GET_ID(underInstrPtr, A_Instr_RefCurrId))
		{
			FIN_GetExchRate(calcDate, GET_ID(unitInterPtr, UnitInter_CurrId),
                            GET_ID(underInstrPtr, A_Instr_RefCurrId),
                            0,NULLDYNST, NULLDYNST, &exchArgSt, &exch);	/* PMSTA01649 - TGU - 070405 */

			*unitAI = GET_NUMBER(unitInterPtr, UnitInter_UnitAccrInter) * exch;
		}
        else
		{ *unitAI = GET_NUMBER(unitInterPtr, UnitInter_UnitAccrInter); }
	}

	FREE_DYNST(unitInterPtr, UnitInter);
	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_TreatFutTimeValue()
**
**  Description :   Create Time Value leg.
**
**  Arguments   :   posHierHead    hierarchy header pointer
**                  domainArgPtr   pointer on some domain informations
**                  origPos        original position pointer
**
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation	:	PMSTA-8736 - RAK -  091104
**
*************************************************************************/
STATIC RET_CODE FIN_TreatFutTimeValue(DBA_HIER_HEAD_STP  posHierHead,
				                    FIN_DOMAIN_ARG_STP domainArgPtr,
				                    DBA_DYNFLD_STP     origPos,
									DBA_DYNFLD_STP     legPos)
{
	RET_CODE		ret=RET_SUCCEED;
	DBA_DYNFLD_STP	riskPos=NULLDYNST, cashLegPos=NULLDYNST, origVal=NULLDYNST, legVal=NULLDYNST, riskVal=NULLDYNST,
					cashLegVal=NULLDYNST, ptfPtr=NULLDYNST, futInstrPtr=NULLDYNST;
	DBA_DYNFLD_STP	domainPtr = DBA_GetDomainPtr(DBA_GetConnectNoFromHier(posHierHead));
	PRICE_T			price;
	NUMBER_T		qty=0.0;
	AMOUNT_T		mktVal=0.0, exchAmt=0.0, tmpVal, tmpExch, futMktValAmt=0.0, legAmt=0.0, cashLegAmt=0.0;
	FLAG_T			futAccFlg, fwdAccFlg, termAccFlg, allocPtfFlg;
	FIN_EXCHARG_ST  exchArgSt;
	ID_T			sysCurrId;

	memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));
	DBA_InitConnectNoToExchArg(&exchArgSt, posHierHead);

	sysCurrId = 0;
	if (GET_EXTENSION_PTR(origPos , ExtPos_A_Ptf_Ext) != NULL &&
	    (ptfPtr = *(GET_EXTENSION_PTR(origPos, ExtPos_A_Ptf_Ext)))!= NULL)
	{
	    if (IS_NULLFLD(ptfPtr, A_Ptf_SysCurrId) == FALSE)
	    {
		    sysCurrId = GET_ID(ptfPtr, A_Ptf_SysCurrId);
	    }
	}
	else
	{
	    if (IS_NULLFLD(riskPos, ExtPos_PtfId) == FALSE)
	    {
		    if ((ret = DBA_GetPtfById(GET_ID(riskPos, ExtPos_PtfId), FALSE, &allocPtfFlg,
	                                  &ptfPtr, posHierHead, UNUSED, UNUSED)) != RET_SUCCEED)
		    {
		        FREE_DYNST(riskPos, ExtPos);
		        return (ret);
		    }

		    if (IS_NULLFLD(ptfPtr, A_Ptf_SysCurrId) == FALSE)
		    {
		        sysCurrId = GET_ID(ptfPtr, A_Ptf_SysCurrId);
		    }

		    if (allocPtfFlg == TRUE) { FREE_DYNST(ptfPtr, A_Ptf); }
	    }
	}

	if (sysCurrId == 0)
	{
	    GEN_GetApplInfo(ApplSysCurrId, &sysCurrId);
	}

	if (GET_EXTENSION_PTR(origPos, ExtPos_Acct_ExtPos_Ext) == NULL ||
		(cashLegPos = *(GET_EXTENSION_PTR(origPos,ExtPos_Acct_ExtPos_Ext))) == NULL)
	{
		MSG_RETURN(RET_DBA_ERR_HIER);
	}

	if (GET_EXTENSION_PTR(origPos, ExtPos_PosVal_Ext) == NULL ||
	    (origVal = *(GET_EXTENSION_PTR(origPos, ExtPos_PosVal_Ext))) == NULL)
		MSG_RETURN(RET_DBA_ERR_HIER);

	if (GET_EXTENSION_PTR(legPos, ExtPos_PosVal_Ext) == NULL ||
	    (legVal = *(GET_EXTENSION_PTR(legPos, ExtPos_PosVal_Ext))) == NULL)
		MSG_RETURN(RET_DBA_ERR_HIER);

	if (GET_EXTENSION_PTR(cashLegPos, ExtPos_PosVal_Ext) == NULL ||
	    (cashLegVal = *(GET_EXTENSION_PTR(cashLegPos, ExtPos_PosVal_Ext))) == NULL)
		MSG_RETURN(RET_DBA_ERR_HIER);

	if (GET_EXTENSION_PTR(origPos, ExtPos_A_Instr_Ext) == NULL ||
	    (futInstrPtr = *(GET_EXTENSION_PTR(origPos, ExtPos_A_Instr_Ext))) == NULL)
		MSG_RETURN(RET_DBA_ERR_HIER);

	if ((riskPos = ALLOC_DYNST(ExtPos)) == NULL)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

	COPY_DYNST(riskPos, origPos, ExtPos);

	/* Wasn't computed by difference, so do it */
	/* PMSTA-13140 - LJE - 120319 */
	FIN_GetAccFlag(domainPtr,
     			   origPos,
				   &futAccFlg,
				   &fwdAccFlg,
				   &termAccFlg);

	if (futAccFlg == FALSE)
	{
		qty = GET_NUMBER(origPos, ExtPos_Qty);
		ret = FIN_NetValFutFwdValDiff(posHierHead, origPos, origVal, futInstrPtr, domainArgPtr->fromDateTime,
                                      qty, &futMktValAmt);
	}
	else
		futMktValAmt = GET_AMOUNT(origVal, PosVal_PosMktValAmt);

	/* convert all amounts in risk position currency */
	if (GET_ID(riskPos, ExtPos_PosCurrId) != GET_ID(origPos, ExtPos_PosCurrId))
	{
		exchArgSt.srcAmt = futMktValAmt;
		FIN_ExchAmt(domainArgPtr->fromDateTime, GET_ID(origPos, ExtPos_PosCurrId),
			        GET_ID(riskPos, ExtPos_PosCurrId),
			        0, NULL, origPos, &exchArgSt,
			        NULL, &futMktValAmt, NULL);
	}

	SET_FLAG(riskPos, ExtPos_MainFlg, FALSE);

	/* Suppress extension identifier (copied from origin position) */
	SET_NULL_ID(riskPos, ExtPos_Id);
	SET_NULL_ID(riskPos, ExtPos_MainExtPosId);
	SET_NULL_ID(riskPos, ExtPos_AcctExtPosId);
	SET_NULL_ID(riskPos, ExtPos_AdjustExtPosId);
	SET_NULL_ID(riskPos, ExtPos_PosValId);

	if ((ret = FIN_UpdRiskPosHier(posHierHead, domainArgPtr,
								   riskPos, futInstrPtr, TRUE)) != RET_SUCCEED)
	{
		FREE_DYNST(riskPos, ExtPos);
		return(ret);
	}

	/* For risk position link */
	FIN_RiskPosLink(riskPos, origPos, GET_ID(origPos, ExtPos_InstrId));

	if (GET_EXTENSION_PTR(riskPos, ExtPos_PosVal_Ext) == NULL ||
	    (riskVal = *(GET_EXTENSION_PTR(riskPos, ExtPos_PosVal_Ext))) == NULL)
		MSG_RETURN(RET_DBA_ERR_HIER);


	/* convert all amounts in risk position currency */
	if (GET_ID(riskPos, ExtPos_PosCurrId) != GET_ID(legPos, ExtPos_PosCurrId))
	{
		exchArgSt.srcAmt = GET_AMOUNT(legPos, ExtPos_PosGrossAmt);
		FIN_ExchAmt(GET_DATETIME(origPos, ExtPos_BegDate), GET_ID(legPos, ExtPos_PosCurrId),
			        GET_ID(riskPos, ExtPos_PosCurrId),
			        0, NULL, legPos, &exchArgSt,
			        NULL, &legAmt, NULL);
	}
	else
		legAmt = GET_AMOUNT(legPos, ExtPos_PosGrossAmt);

	if (GET_ID(riskPos, ExtPos_PosCurrId) != GET_ID(cashLegPos, ExtPos_PosCurrId))
	{
		exchArgSt.srcAmt = GET_AMOUNT(cashLegPos, ExtPos_PosGrossAmt);
		FIN_ExchAmt(GET_DATETIME(origPos, ExtPos_BegDate), GET_ID(cashLegPos, ExtPos_PosCurrId),
			        GET_ID(riskPos, ExtPos_PosCurrId),
			        0, NULL, cashLegPos, &exchArgSt,
			        NULL, &cashLegAmt, NULL);
	}
	else
		cashLegAmt = GET_AMOUNT(cashLegPos, ExtPos_PosGrossAmt);

	/* compute the leg value at opening date */
	qty = (-1.0 * cashLegAmt) - legAmt;


	/* convert all amounts in risk position currency */
	if (GET_ID(riskPos, ExtPos_PosCurrId) != GET_ID(legPos, ExtPos_PosCurrId))
	{
		exchArgSt.srcAmt = GET_AMOUNT(legVal, PosVal_PosMktValAmt);
		FIN_ExchAmt(domainArgPtr->fromDateTime, GET_ID(legPos, ExtPos_PosCurrId),
			        GET_ID(riskPos, ExtPos_PosCurrId),
			        0, NULL, legPos, &exchArgSt,
			        NULL, &legAmt, NULL);
	}
	else
		legAmt = GET_AMOUNT(legVal, PosVal_PosMktValAmt);

	if (GET_ID(riskPos, ExtPos_PosCurrId) != GET_ID(cashLegPos, ExtPos_PosCurrId))
	{
		exchArgSt.srcAmt = GET_AMOUNT(cashLegVal, PosVal_PosMktValAmt);
		FIN_ExchAmt(domainArgPtr->fromDateTime, GET_ID(cashLegPos, ExtPos_PosCurrId),
			        GET_ID(riskPos, ExtPos_PosCurrId),
			        0, NULL, cashLegPos, &exchArgSt,
			        NULL, &cashLegAmt, NULL);
	}
	else
		cashLegAmt = GET_AMOUNT(cashLegVal, PosVal_PosMktValAmt);

	/* compute leg mkt value */
	mktVal = -1.0 * (legAmt + cashLegAmt +(-1 * futMktValAmt));

	price = mktVal / qty;

	/* Valorisation */
	SET_AMOUNT(riskVal, PosVal_PosMktValAmt,    mktVal);
	SET_AMOUNT(riskVal, PosVal_PosNetAmt,	    mktVal);
	SET_AMOUNT(riskVal, PosVal_PosAccrInterAmt, 0.0);

	if (GET_ID(riskPos, ExtPos_RefCurrId) != GET_ID(riskPos, ExtPos_PosCurrId))
	{
		exchArgSt.srcAmt = mktVal;
		FIN_ExchAmt(domainArgPtr->fromDateTime, GET_ID(riskPos, ExtPos_PosCurrId),
			        GET_ID(riskPos, ExtPos_RefCurrId),
			        0, NULL, riskPos, &exchArgSt,
			        NULL, &tmpVal, &tmpExch);
		    SET_AMOUNT(riskVal, PosVal_RefMktValAmt, tmpVal);
			SET_AMOUNT(riskVal, PosVal_RefNetAmt, tmpVal);
			SET_EXCHANGE(riskVal, PosVal_PosExchRate, tmpExch);
	}
	else
	{
		SET_AMOUNT(riskVal,   PosVal_RefMktValAmt, mktVal);
		SET_AMOUNT(riskVal,   PosVal_RefNetAmt,    mktVal);
		SET_EXCHANGE(riskVal, PosVal_PosExchRate,  1.0);
	}

	if (GET_ID(futInstrPtr, A_Instr_RefCurrId) != GET_ID(riskPos, ExtPos_RefCurrId))
	{
		exchArgSt.srcAmt = GET_AMOUNT(riskVal, PosVal_RefMktValAmt);
		FIN_ExchAmt(domainArgPtr->fromDateTime,
			        GET_ID(riskPos, ExtPos_RefCurrId),
			        GET_ID(futInstrPtr, A_Instr_RefCurrId),
			        0, NULL, riskPos, &exchArgSt,
			        NULL, &tmpVal, &tmpExch);
		SET_AMOUNT(riskVal, PosVal_InstrMktValAmt, tmpVal);
		SET_AMOUNT(riskVal, PosVal_InstrNetAmt,    tmpVal);

		tmpExch = 1.0/tmpExch;
		SET_EXCHANGE(riskVal, PosVal_InstrExchRate, tmpExch);
	}
	else
	{
		SET_AMOUNT(riskVal,   PosVal_InstrMktValAmt, mktVal);
		SET_AMOUNT(riskVal,   PosVal_InstrNetAmt,    mktVal);
		SET_EXCHANGE(riskVal, PosVal_InstrExchRate,  1.0);
	}

	SET_PRICE(riskVal,   PosVal_Quote,            CAST_PRICE(price)); /* REF3288 - SSO - 990205 */
    SET_PRICE(riskVal,   PosVal_Price,            CAST_PRICE(price)); /* REF3288 - SSO - 990205 */
    SET_ID(riskVal,       PosVal_PriceCurrId,      GET_ID(riskPos, ExtPos_PosCurrId));
    SET_DATETIME(riskVal, PosVal_QuoteDate,        domainArgPtr->fromDateTime);
	SET_ENUM(riskVal,     PosVal_PriceCalcRuleEn,  GET_ENUM(futInstrPtr, A_Instr_PriceCalcRuleEn));
	SET_EXCHANGE(riskVal, PosVal_PriceExchRate,    1.0);


	/* Position */
	qty = CAST_AMOUNT(qty, GET_ID(riskPos, ExtPos_PosCurrId));
	SET_NUMBER(riskPos, ExtPos_Qty,   CAST_NUMBER(qty));
	SET_PRICE(riskPos, ExtPos_Price, 1.0);
	SET_PRICE(riskPos, ExtPos_Quote, 1.0);

	SET_NULL_PRICE(riskPos, ExtPos_SpotPrice);
	SET_NULL_PRICE(riskPos, ExtPos_SpotQuote);

	SET_AMOUNT(riskPos, ExtPos_PosGrossAmt, qty);
	SET_AMOUNT(riskPos, ExtPos_PosNetAmt,   qty);

	if (GET_ID(riskPos, ExtPos_PosCurrId) == GET_ID(riskPos, ExtPos_InstrCurrId))
	{
	    SET_AMOUNT(riskPos, ExtPos_InstrGrossAmt, qty);
	    SET_AMOUNT(riskPos, ExtPos_InstrNetAmt,   qty);
	}
	else
	{
		exchArgSt.srcAmt = qty;
		FIN_ExchAmt(GET_DATETIME(riskPos, ExtPos_BegDate),
		            GET_ID(riskPos,ExtPos_PosCurrId),
			        GET_ID(riskPos,ExtPos_InstrCurrId),
		            0, NULL, riskPos, &exchArgSt,
			        NULL, &exchAmt, NULL);

	    SET_AMOUNT(riskPos, ExtPos_InstrGrossAmt, exchArgSt.srcAmt);
	    SET_AMOUNT(riskPos, ExtPos_InstrNetAmt,   exchArgSt.srcAmt);
	}

	if (GET_ID(riskPos, ExtPos_PosCurrId) == GET_ID(riskPos, ExtPos_RefCurrId))
	{
	    SET_AMOUNT(riskPos, ExtPos_RefGrossAmt, qty);
	    SET_AMOUNT(riskPos, ExtPos_RefNetAmt,   qty);
	}
	else
	{
		exchArgSt.srcAmt = qty;
		FIN_ExchAmt(GET_DATETIME(riskPos, ExtPos_BegDate),
			            GET_ID(riskPos,ExtPos_PosCurrId),
				        GET_ID(riskPos,ExtPos_RefCurrId),
			            0, NULL, riskPos, &exchArgSt,
				        NULL, &exchAmt, NULL);

		SET_AMOUNT(riskPos, ExtPos_RefGrossAmt, exchAmt);
	    SET_AMOUNT(riskPos, ExtPos_RefNetAmt,   exchAmt);
	}

	if (GET_ID(riskPos, ExtPos_PosCurrId) == sysCurrId)
	{
	    SET_AMOUNT(riskPos, ExtPos_SysGrossAmt, qty);
	    SET_AMOUNT(riskPos, ExtPos_SysNetAmt,   qty);
	}
	else
	{
		exchArgSt.srcAmt = qty;
		FIN_ExchAmt(GET_DATETIME(riskPos, ExtPos_BegDate),
			            GET_ID(riskPos, ExtPos_PosCurrId), sysCurrId,
			            0, NULL, riskPos, &exchArgSt,
				        NULL, &exchAmt, NULL);

	    SET_AMOUNT(riskPos, ExtPos_SysGrossAmt, exchAmt);
	    SET_AMOUNT(riskPos, ExtPos_SysNetAmt,   exchAmt);
	}

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_TreatOptionRisk()
**
**  Description :   Create risk position for option
**
**  Arguments   :   posHierHead    hierarchy header pointer
**                  domainArgPtr   pointer on some domain informations
**                  origPos        original position pointer
**                  instrPtr       instrument pointer
**                  instrHierFlg   instrument already in hierarchy or not
**                  totPosRisk     total risk position pointer
**                  riskQtyStp     quantity structure pointer
**                  status         risk status (Father, Son, LastSon)
**
**  Return      :   RET_SUCCEED or error code
**
**  Modif.      :   DVP187 - RAK - 960829
**  Modif.      :   DVP189 - RAK - 960902
**  Modif.      :   BUG136 - RAK - 960924
**  Modif.      :   BUG217 - RAK - 961204
**  Modif.	    :   REF1457 - RAK - 980324
**  Modif.	    :   REF2313 - RAK - 980910
**  Modif.	    :   REF2580 - SSO - 980727
**		            REF3118 - SSO - 981214
**  Modif.	    :   REF3209 - RAK - 990113
**                  REF7661 - YST - 020725
**                  REF9082 - TEB - 030619
**
*************************************************************************/
EXTERN RET_CODE FIN_TreatOptionRisk(DBA_HIER_HEAD_STP  posHierHead,
									DBA_DYNFLD_STP		domainPtr,
				                    FIN_DOMAIN_ARG_STP domainArgPtr,
				                    FIN_AIARG_STP      aiArgPtr,
                                    DBA_DYNFLD_STP     origPos,
				                    DBA_DYNFLD_STP     instrPtr,
				                    char               instrHierFlg,
				                    DBA_DYNFLD_STP     totPosRisk,
				                    RISK_QTY_STP       riskQtyStp,	/* DVP189 */
				                    FIN_PRICEARG_STP   priceArgStp,	/* REF3030 */
				                    RISK_ANALYSIS_ENUM status)
{
	DBA_DYNFLD_STP       riskPos=NULL, underPtr=NULL, prPtr=NULL, advArgStp=NULL;  /* REF9082 - TEB - 030619 */
	FIN_OPTINFO_ST       optInfo;
	RISKCOSTRULE_ENUM	 optCostRule;
	ID_T                 priceCurrId;
	EXCHANGE_T           exch;
	AMOUNT_T             amt;
	NUMBER_T             delta , qty ;
	PRICE_T		     price, quote;
	char                 hierFlg;
	RET_CODE             ret;
	FIN_EXCHARG_ST       exchArgSt;			/* REF2313 */
    double               pricingModel;      /* REF9082 - TEB - 030619 */

	memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));	/* REF2313 */
	/*DBA_SetConnectNoToExchArg(&exchArgSt, DBA_GetConnectNoFromHier(posHierHead)); *//* REF2580 - SSO - 980727 */
	DBA_InitConnectNoToExchArg(&exchArgSt, posHierHead); /* REF4213 - SSO - 991221 */

	/*** COMPUTE OPTION POUND IN RISK DECOMPOSITION ***/
	if (status != Risk_Father)
	{
		/* Add an option position */
		ret = FIN_TreatCompoRisk(posHierHead, domainArgPtr, aiArgPtr, origPos, instrPtr,
					             instrHierFlg, totPosRisk,
					             riskQtyStp, priceArgStp,
					             status, NULL);	/* DVP189 */
	}
	else
	{
		ret = FIN_RiskSonPriceAmt(posHierHead, domainArgPtr, origPos, origPos, instrPtr,
					              totPosRisk, priceArgStp, status, &price, riskQtyStp, FALSE); /* PMSTA-34140 - RAK - 190122 - Add riskQtyStp for STN computation */
	}

	if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
		return(ret);

	/* Don't create risk position for option */
	if (domainArgPtr->optDeltaRule == OptDelta_None)
	{
		/* PMSTA_32112 - RAK - 180910 - SubFunction */
		FIN_SetRiskPosNoExposure(domainArgPtr, status, origPos);
		return(RET_SUCCEED);
	}

	if ((riskPos = ALLOC_DYNST(ExtPos)) == NULL)
	{
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	if ((prPtr = ALLOC_DYNST(A_InstrPrice)) == NULL)
	{
		FREE_DYNST(riskPos, ExtPos);
   		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	/*** COMPUTE OPTION RISK POSITION ***/
	if ((ret = FIN_GetOptionInfo(instrPtr, domainArgPtr->fromDateTime.date, &optInfo)) != RET_SUCCEED)
	{
		if (domainArgPtr->fundRiskEn != FinFundRisk_FundCompo)
		    SET_ENUM(origPos, ExtPos_RiskNatEn, ExtPosRisk_FinRisk);

	    if (domainArgPtr->fundRiskEn != FinFundRisk_None)
		    SET_ENUM(origPos,ExtPos_FundSplitNatEn, FundSplitNat_Split);

		FREE_DYNST(prPtr, A_InstrPrice);
		FREE_DYNST(riskPos, ExtPos);
		return(RET_SUCCEED);
	}

	/* Underly can't be position instrument */
	if (optInfo.underId == GET_ID(instrPtr, A_Instr_Id))
	{
		FREE_DYNST(prPtr, A_InstrPrice);
		FREE_DYNST(riskPos, ExtPos);
		ret = RET_FIN_ERR_INVDATA;
		MSG_SendMesg(ret, 1, FILEINFO, "FIN_TreatOptionRisk",
			         GET_CODE(instrPtr, A_Instr_Cd), "underlying");
		return(ret);
	}

	ret = FIN_GetHierInstr(posHierHead, optInfo.underId, &hierFlg, &underPtr);

	if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
	{
		FREE_DYNST(prPtr, A_InstrPrice);
		FREE_DYNST(riskPos, ExtPos);
		return(ret);
	}

	COPY_DYNST(riskPos, origPos, ExtPos);

	/* A risk position parent can't be risk */
	SET_ENUM(origPos, ExtPos_RiskNatEn, ExtPosRisk_NoRisk);		/* BUG145 */

    /* REF7661 - YST - 020725 - risk position can't be main position */
    SET_FLAG(riskPos, ExtPos_MainFlg, FALSE);

	/* Suppress extension identifier (copied from origin position) */
	SET_NULL_ID(riskPos, ExtPos_MainExtPosId);
	SET_NULL_ID(riskPos, ExtPos_AcctExtPosId);
	SET_NULL_ID(riskPos, ExtPos_AdjustExtPosId);
	SET_NULL_ID(riskPos, ExtPos_PosValId);

	SET_ID(riskPos, ExtPos_InstrId,     GET_ID(underPtr, A_Instr_Id));
	SET_ID(riskPos, ExtPos_InstrCurrId, GET_ID(underPtr,A_Instr_RefCurrId));

	/* Risk position is in origin position currency except for currencies */
	if ((INSTRNAT_ENUM) GET_ENUM(underPtr, A_Instr_NatEn) == InstrNat_CashAcct)
	{ SET_ID(riskPos, ExtPos_PosCurrId, GET_ID(underPtr, A_Instr_RefCurrId)); }

	/* Price is underlying price at begin date of the position */
	/* or exercise price of the option founded in term event   */
	GEN_GetApplInfo(ApplRiskOptCostRule, &optCostRule);

	switch (optCostRule)
	{
	case RiskCostRule_ClosingPrice :
	{

	    ret = FIN_PosPrice(riskPos, underPtr, GET_DATETIME(riskPos, ExtPos_BegDate),
			               priceArgStp, prPtr,
                           NULL, posHierHead);

	    if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
	    {
			FREE_DYNST(riskPos, ExtPos);
			FREE_DYNST(prPtr, A_InstrPrice);
			return(ret);
	    }

	    price       = GET_PRICE(prPtr, A_InstrPrice_Price);
	    priceCurrId = GET_ID(prPtr, A_InstrPrice_CurrId);
	    break;
	}

	case RiskCostRule_ExercisePrice :
	{
	    price       = optInfo.exerPrice;
	    priceCurrId = optInfo.exerCurrId;
	    break;
	}

	/* ?? */
	case RiskCostRule_UnderlyDelta :
	default :
	{
	     price       = optInfo.exerPrice;
	     priceCurrId = optInfo.exerCurrId;
	     break;
	}
	} /* end switch */

	FREE_DYNST(prPtr, A_InstrPrice);

	/* Convert price in position currency */
    FIN_GetExchRate(GET_DATETIME(riskPos, ExtPos_BegDate),
			        priceCurrId, GET_ID(riskPos, ExtPos_PosCurrId),
			        (ID_T)0, NULL, riskPos, &exchArgSt, &exch);	/* PMSTA01649 - TGU - 070405 */
	price *= exch;

	if (GET_ID(riskPos, ExtPos_RefCurrId) != GET_ID(riskPos, ExtPos_PosCurrId))
	{
   	    FIN_GetExchRate(GET_DATETIME(riskPos, ExtPos_BegDate),
		                GET_ID(riskPos, ExtPos_PosCurrId),
                        GET_ID(riskPos, ExtPos_RefCurrId),
			            (ID_T)0, NULL, riskPos, &exchArgSt, &exch);	/* PMSTA01649 - TGU - 070405 */
	    SET_EXCHANGE(riskPos, ExtPos_PosExchRate, exch);
	}
	else
	{
	    SET_EXCHANGE(riskPos, ExtPos_PosExchRate, 1.0);
	}

	if (GET_ID(riskPos, ExtPos_RefCurrId) != GET_ID(riskPos, ExtPos_InstrCurrId))
	{
   	    FIN_GetExchRate(GET_DATETIME(riskPos, ExtPos_BegDate),
		                GET_ID(riskPos,ExtPos_InstrCurrId),
                        GET_ID(riskPos,ExtPos_RefCurrId),
			            (ID_T)0, NULL, riskPos, &exchArgSt, &exch);	/* PMSTA01649 - TGU - 070405 */
	    SET_EXCHANGE(riskPos, ExtPos_InstrExchRate, exch);
	}
	else
	{
	    SET_EXCHANGE(riskPos, ExtPos_InstrExchRate, 1.0);
	}

	FIN_PriceToQuote((PRICECALCRULE_ENUM)GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn), 		/* DVP440 */ /* REF7264 - LJE - 020131 */
	                 GET_ID(instrPtr, A_Instr_Id), instrPtr,
	                 GET_DATETIME(riskPos, ExtPos_BegDate), NULL,
			         price, &quote, posHierHead);
	SET_PRICE(riskPos, ExtPos_Price, price);
	SET_PRICE(riskPos, ExtPos_Quote, quote);

	/* DVP189 */
	if (riskQtyStp->idxCalcRuleEn == IdxCalcRule_PctValue)
	{
	    PRICE_T       tmpPrice = 0.0;

	    if ((ret = FIN_PosPrice(riskPos, instrPtr, domainArgPtr->fromDateTime,
				                priceArgStp, riskQtyStp->pricePtr,
                                NULL, posHierHead)) == RET_SUCCEED)
	    {
	        if (GET_ID(riskQtyStp->pricePtr, A_InstrPrice_CurrId) != riskQtyStp->priceCurrId)
	        {
   	            FIN_GetExchRate(GET_DATETIME(riskPos, ExtPos_BegDate),
		                        GET_ID(riskQtyStp->pricePtr, A_InstrPrice_CurrId),
 				riskQtyStp->priceCurrId, (ID_T)0, NULL, riskPos, &exchArgSt, &exch);	/* PMSTA01649 - TGU - 070405 */
		    }
		    else
			    exch = 1.0;

		    tmpPrice = GET_PRICE(riskQtyStp->pricePtr, A_InstrPrice_Price) * exch;
	    }

	    if (ret != RET_SUCCEED || tmpPrice == 0.0)
	    {
		    FREE_DYNST(riskPos, ExtPos);
		    MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }

	    qty = riskQtyStp->qty / tmpPrice;
	}
	else
	{
	    qty = riskQtyStp->qty;
	}

    /* PMSTA-52520 - JPR - 230529 */
    if (GET_ENUM(underPtr, A_Instr_NatEn) == InstrNat_Future)
    {
        qty *= GET_NUMBER(underPtr, A_Instr_ContractSize);
    }

	if (domainArgPtr->optDeltaRule == OptDelta_Delta)
	{
        /* REF9082 - TEB - 030619 - Begin*/
        /* Replace Tech with Simcorp */
	    /* Create input structure. */
	    if ((advArgStp = ALLOC_DYNST(AdvA_Arg)) == NULL)
        {
		    FREE_DYNST(riskPos, ExtPos);
		    return(RET_SUCCEED);
        }

        /* Set the sensitivity to Delta */
	    SET_ENUM(advArgStp, AdvA_Arg_SensitivityEn, OptSens_Delta);

        /* Set the intrument id */
        SET_ID(advArgStp, AdvA_Arg_InstrId, GET_ID(instrPtr, A_Instr_Id));

        /* Set the pricing model */
	    if (IS_NULLFLD(instrPtr, A_Instr_DefModelEn) == TRUE  ||
		    GET_ENUM(instrPtr, A_Instr_DefModelEn)   == OptModel_None)
	    {
		    GEN_GetApplInfo(ApplOptPricingModel, &pricingModel);
		    SET_ENUM(advArgStp, AdvA_Arg_PricingModelEn, pricingModel);
	    }
	    else
	    {
		    SET_ENUM(advArgStp, AdvA_Arg_PricingModelEn, GET_ENUM(instrPtr, A_Instr_DefModelEn));
	    }

        /* Set the reference date */
        SET_DATE(advArgStp, AdvA_Arg_RefDate, domainArgPtr->fromDateTime.date);
        COPY_DYNFLD(advArgStp, AdvA_Arg, AdvA_Arg_Date, advArgStp, AdvA_Arg, AdvA_Arg_RefDate );

        /* set the keyword nature */
	    SET_ENUM(advArgStp, AdvA_Arg_KeyWordEn, AdvAKeyWord_OPT_SENS);

	    /* Execute the sensitivity (Delta) computation */
	    if (FIN_OptSens(advArgStp,
						/*TRUE*/FALSE,  /* PMSTA02881-CHU-070628 : Read Chrono first */
						instrPtr,NULL,
				        posHierHead, &delta) != RET_SUCCEED)
        {
		    FREE_DYNST(advArgStp, AdvA_Arg);
            FREE_DYNST(riskPos,   ExtPos);
		    return(RET_SUCCEED);
	    }

	    FREE_DYNST(advArgStp, AdvA_Arg);
        /* REF9082 - TEB - 030619 - End */

		qty *= delta;
	}
	else if (domainArgPtr->optDeltaRule == OptDelta_Full)
	{
		if (optInfo.optClassEn == OptClass_Put) qty *= -1;
	}

	if (optInfo.underQty != 0.0)	/* BUG136 */
	    qty *= optInfo.underQty;

	/* In position currency */
	amt = qty * price;
	SET_NUMBER(riskPos, ExtPos_Qty,         CAST_NUMBER(qty)); /* REF3288 - SSO - 990205 */
 	SET_AMOUNT(riskPos, ExtPos_PosGrossAmt, amt);
	SET_AMOUNT(riskPos, ExtPos_PosNetAmt,   amt);

	/* PMSTA-32502 - RAK - 180921 - Use new fct for simplification */
	/* Convert in instrument currency */
	FIN_RiskPosSetExtPosPosAmtTo(ExtPos_InstrNetAmt, posHierHead, riskPos, &exchArgSt);

	/* Convert in reference currency */
	FIN_RiskPosSetExtPosPosAmtTo(ExtPos_RefNetAmt, posHierHead, riskPos, &exchArgSt);

	/* Convert in system currency */
	FIN_RiskPosSetExtPosPosAmtTo(ExtPos_SysNetAmt, posHierHead, riskPos, &exchArgSt);

	/* DVP187 */
	FIN_RiskPosLink(riskPos, origPos, GET_ID(instrPtr, A_Instr_Id));

	ret = FIN_AddValoRiskPos(posHierHead, domainArgPtr, aiArgPtr, origPos, riskPos,
		underPtr, hierFlg, totPosRisk, priceArgStp, Risk_Father, &optInfo,
		NULL, nullptr, riskQtyStp);

	if (ret != RET_SUCCEED)
		return(ret);

	/*** CASH POSITION and INSTRUMENT ***/
	/* REF3209 - send optInfo .. */
	if ((ret = FIN_AddValoRiskOptCashPos(posHierHead, domainArgPtr, riskPos, &optInfo)) != RET_SUCCEED)
		return(ret);

	/* In case of generated instrument, must be decomposed */
	ret = FIN_RiskAnalysis(posHierHead, domainPtr, domainArgPtr, aiArgPtr, riskPos);

	return(ret);
}


/************************************************************************
**
**  Function    :   FIN_UpdRiskPosHier()
**
**  Description :   Update risk position and add it in hierarchy with
**                  instrument (if not already) and valorisation extension
**
**  Arguments   :   posHierHead     extended position hierarchy header
**                  domainArgPtr    some domain arguments pointer
**                  riskPos         risk position pointer
**                  instrPtr        instrument pointer
**                  instrHierFlg    TRUE if instrument is already in hierarchy
**
**  Return      :   RET_SUCCEED or error code
**
**  Modif.      :   DVP510 - RAK - 970618
**  Modif. 	    :   REF3357 - RAK - 990223
**
*************************************************************************/
RET_CODE FIN_UpdRiskPosHier(DBA_HIER_HEAD_STP  posHierHead,
				                   FIN_DOMAIN_ARG_STP domainArgPtr,
                                   DBA_DYNFLD_STP     riskPos,
				                   DBA_DYNFLD_STP     instrPtr,
				                   char               instrHierFlg)
{
	RET_CODE 	ret;
	INSTRNAT_ENUM	instrNatEn=(INSTRNAT_ENUM) GET_ENUM(instrPtr, A_Instr_NatEn);

	/* For create a new position identifier by hierarchy tools */
	SET_NULL_ID(riskPos, ExtPos_Id);
	SET_NULL_ID(riskPos, ExtPos_PosObjId);

	/* DVP510 - RAK - 970618 */
	if (instrNatEn == InstrNat_Option ||
	    instrNatEn == InstrNat_ExoticOptions ||
	    instrNatEn == InstrNat_SwapOptions)
	{
	    if (domainArgPtr->optDeltaRule == OptDelta_None)
	    {
		    if (domainArgPtr->fundRiskEn != FinFundRisk_FundCompo)
			    SET_ENUM(riskPos, ExtPos_RiskNatEn, ExtPosRisk_FinRisk);
	    }
	    else
	    {
		    SET_ENUM(riskPos, ExtPos_RiskNatEn, ExtPosRisk_NoRisk);
	    }
	}
	else
	{
	    if (domainArgPtr->fundRiskEn != FinFundRisk_FundCompo)
	    	SET_ENUM(riskPos, ExtPos_RiskNatEn, ExtPosRisk_FinRisk);
	}

	if (domainArgPtr->fundRiskEn != FinFundRisk_None)
		SET_ENUM(riskPos, ExtPos_FundSplitNatEn, FundSplitNat_Split);

	SET_FLAG(riskPos, ExtPos_AcctFlg,   FALSE);

	/* Add instrument */
	if (instrHierFlg == FALSE)
	{
		/* REF3357 - RAK - 990223 */
		/* Don't try to do link (A_Instr_Compo_A_Instr_Ext, A_Instr_Cond_A_Instr_Ext) */
		/* In fact we found a problem in function DBA_SelAllInterestCond..            */
		/* which don't found InterCond (which exist)                                  */
		if ((ret = DBA_AddHierRecord(posHierHead, instrPtr, A_Instr,
					                 TRUE, HierAddRec_NoLnk)) != RET_SUCCEED)
		{
			FREE_DYNST(instrPtr, A_Instr);
			FREE_DYNST(riskPos, ExtPos);
			return(ret);
		}

		/* For link between risk position and new instrument */
		SET_ID(riskPos, ExtPos_InstrId, GET_ID(instrPtr, A_Instr_Id));
	}

	/* Force record insertion, link PosVal is made in FIN_PosExtValo() */
	if ((ret = DBA_AddHierRecord(posHierHead, riskPos, ExtPos, FALSE,
		                         HierAddRec_ForceInsert)) != RET_SUCCEED)
	{
		FREE_DYNST(riskPos, ExtPos);
		return(ret);
	}

	/*** ADD VALORISATION EXTENSION ***/
    return(FIN_PosExtValo(posHierHead, riskPos));
}

/************************************************************************
**
**  Function    :   FIN_CmpCashPos()
**
**  Description :   Position table is sort by instr nature : cash are last
**
**  Arguments   :   ptr1   pointer on dynamic structure type ExtPos
**                  ptr2   pointer on dynamic structure type ExtPos
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation	:   BUG135 - RAK - 960924
**
*************************************************************************/
STATIC int FIN_CmpCashPos(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *)
{
	DBA_DYNFLD_STP instr1Ptr=NULL;

	if (GET_EXTENSION_PTR((*ptr1), ExtPos_A_Instr_Ext) != NULL &&
	    (instr1Ptr = *(GET_EXTENSION_PTR((*ptr1), ExtPos_A_Instr_Ext))) != NULL)
	{
	    if ((INSTRNAT_ENUM) GET_ENUM(instr1Ptr, A_Instr_NatEn) == InstrNat_CashAcct)
		    return(1);
	}

	return(-1);
}

/************************************************************************
**      END  finrisk.c                                          UNICIBLE
*************************************************************************/

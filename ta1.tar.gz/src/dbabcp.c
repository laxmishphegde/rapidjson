/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DBABCP_C

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H

#include "unidef.h"     /* Mandatory */
#include "timer.h"      /* REF2421 - OCE - 980825 */
#include "dba.h"
#include "dbabcp.h"
#include "bkpublic.h"
#include "date.h"
#include "gen.h"

#include "dbibcp.h"
#include "dbiconnection.h"

/************************************************************************
*************************************************************************
**
**    P U B L I C      F U N C T I O N S
**
*************************************************************************
*************************************************************************/

/*************************************************************************
*
*   Function             : DBA_BcpInInit
*
*   Description          : This function initializes a bulk copy
*                          It allocates a special work area which must be
*                          freed after each BCP operation in calling
*                          DB_BcpEnd
*
*   Usage                : 1) DBA_BcpInInit
*                          2) loop { DBA_BcpInsert() }
*                          3) DBA_BcpEnd
*
*
*   Arguments            : connectNo   (in) : DbiConnection to use during bulk copy 
*                                              This connection must not have any
*                                              pending result
*                          tableName    (in) : table name in wich bulk copies are done
*                          fieldType    (in) :
*                          colNb        (in) : number of column in 'tableName' table
*                          count        (in) : number of row to be bulk copied at one go.
*                          blkdef      (out) : a pointer to a virgin SYB_BLKDEF_ST
*
*   Functions call       :
*
*   Return               : RET_CODE
*
*   Modification         : REF8798 - YST - 030320 - insert PerfAttribData, StdPerfData etc. by BCP
*
*************************************************************************/
RET_CODE DBA_BcpInInit(DbiConnection&  dbiConn,
                       char           *tableName,
                       SYSNAME_T      *colName,
                       DATATYPE_ENUM  *fieldType,
                       int             colNb,
                       int             firstCol,
                       int             count,
                       void          **blkdef)
{
    return DBI_BcpInInit(dbiConn, tableName, colName, fieldType, colNb, firstCol, count, blkdef);
}


/*************************************************************************
*
*   Function             : DBA_BcpInsert
*
*   Description          : this function insert a bloc of records by bulk copy
*
*   Usage                : 1) DBA_BcpInit
*                          2) loop { DBA_BcpInsert() }
*                          3) DBA_BcpEnd
*
*   Arguments            : record          (in) : array of DBA_DYNFLD_STP
*                          blkdef      (in/out) : a pointer to an initialised SYB_BLKDEF_ST
*                          outRowNb       (out) : number of rows really inserted
*
*   Side Effects         : THE FIRST DIMENSION 'record' ARRAY IS THE COLUMN NUMBER,
*                          THE SECOND ONE IS THE ROW NUMBER !
*
*   Functions call       : DBi_BcpInsert
*
*   Return               : RET_CODE
*
*   Modification         : REF8798 - YST - 030327 - add treatment _blkdef->firstCol
*                          PMSTA-23981 - 070716 - PMO : Financial server crash when launching report
*
*************************************************************************/
RET_CODE DBA_BcpInsert(DBA_DYNFLD_STP   record,
                       void *          blkdef,
                       int *           outRowNb,
                       const char *    objectName)   /* REF8728 - YST - 030213 */
{
    return DBI_BcpInsert(record, static_cast<DBI_BLKDEF_STP>(blkdef), outRowNb, objectName);    /* PMSTA-23981 - 070716 - PMO */
}



/*************************************************************************
*
*   Function             : DBA_BcpEnd
*
*   Description          :
*
*   Arguments            :
*
*   Functions call       : DBI_BcpEnd.
*
*   Return               : RET_CODE
*
*   Modification         : PMSTA-23981 - 070716 - PMO : Financial server crash when launching report
*
*************************************************************************/
RET_CODE DBA_BcpEnd(void *          blkdef,
                    int *           outRowNb,
                    const char *    objectName)    /* REF8728 - YST - 030213 */
{
    return DBI_BcpEnd(static_cast<DBI_BLKDEF_STP>(blkdef), outRowNb, objectName);   /* PMSTA-23981 - 070716 - PMO */
}




/*************************************************************************
*
*   Function             : SYB_BcpFree
*
*   Description          : This function frees memory used for bulkcpy
*
*   Arguments            : blkdef      (in) : a pointer to a SYB_BLKDEF_ST in used
*
*   Functions call       : None.
*
*   Return               : RET_CODE
*
*   Modification         : PMSTA-23981 - 070716 - PMO : Financial server crash when launching report
*                          PMSTA-49328 - MSS - 200622 : free allocated blkdef pointer for fixing memory leak. Null check before deleting.
*
*************************************************************************/
void DBA_BcpFree(void * & blkdef)                                                   /* PMSTA-23981 - 070716 - PMO */
{
    DBI_BLKDEF_STP  _blkdef = static_cast<DBI_BLKDEF_STP>(blkdef);                  /* PMSTA-23981 - 070716 - PMO */

    if(_blkdef != nullptr)
    {
        DBI_BcpFree(_blkdef);                                                           /* PMSTA-23981 - 070716 - PMO */
    }
    blkdef = nullptr;                                                               /* PMSTA-23981 - 070716 - PMO */
}

/* REF2421 - OCE - 980825 */
/* Begin                  */
/*************************************************************************
*
*   Function             : DBA_BcpModeOPFlg
*
*   Description          : This function returns if the bulk copy mode is set.
*                          This information is given by an environment variable
*                          which concerns the all application
*
*   Arguments            : none
*
*   Return               : FLAG_T
*
*   Modification         : PMSTA15781 - DDV - 130301
*
*************************************************************************/
FLAG_T DBA_BcpModeOPFlg()
{
    static int   bcpModeOPFlg = -1;

    if (bcpModeOPFlg == -1)
    {
        if (EV_RdbmsVendor == Sybase || EV_RdbmsVendor == Oracle)
        {
            bcpModeOPFlg = SYS_GetEnvBoolOrDefValue("AAABCPMOD", true) ? TRUE : FALSE;
        }
        else
        {
            bcpModeOPFlg = FALSE;
        }
    }

    return static_cast<FLAG_T>(bcpModeOPFlg);
}

/*************************************************************************
*
*   Function             : DBA_BcpModePerfStorageFlg
*
*   Description          : This function returns if the bulk copy mode is set.
*                          This information is given by an environment variable
*                          which concerns the all application
*
*   Arguments            : none
*
*   Return               : FLAG_T
*
*   Creation             : PMSTA15781 - DDV - 130301
*
*************************************************************************/
FLAG_T DBA_BcpModePerfStorageFlg()
{
    static int bcpModePerfStorageFlg = -1;

    if (bcpModePerfStorageFlg == -1)
    {
        bool bcpMode = SYS_GetEnvBoolOrDefValue("AAABCPMOD", false) ? TRUE : FALSE;
        if (EV_RdbmsVendor == Sybase || EV_RdbmsVendor == Oracle)
        {
            bcpModePerfStorageFlg = SYS_GetEnvBoolOrDefValue("AAAPERFSTORAGEBCP", bcpMode) ? TRUE : FALSE;
        }
    }

    return static_cast<FLAG_T>(bcpModePerfStorageFlg);
}

/*************************************************************************
*
*   Function             : DBA_BcpModeRepFlg
*
*   Description          : This function returns if the bulk copy mode is set.
*                          This information is given by an environment variable
*                          which concerns the all application
*
*   Arguments            : none
*
*   Return               : FLAG_T
*
*   Creation             : PMSTA15781 - DDV - 130301
*
*************************************************************************/
FLAG_T DBA_BcpModeRepFlg()
{
    static int bcpModeRepFlg = -1;

    if (bcpModeRepFlg == -1)
    {
        bcpModeRepFlg = SYS_GetEnvBoolOrDefValue("AAAREPBCP", true) ? TRUE : FALSE;
    }

    return static_cast<FLAG_T>(bcpModeRepFlg);
}

/*************************************************************************
*
*   Function             : SYB_BcpInitEntity
*
*   Description          : This function initializes the bulk copy structure
*                          for a given entity.
*                          Currently the insert options insOptions are treated like:
*                          - UNUSED, SYB_BCP_INS_ID: It's the same, id is always inserted
*                          - SYB_BCP_INS_UD_FLD: insert in "ud" table
*
*                          Remark:
*                          For insOptions = UNUSED (which should not insert id) code
*                          needs to be adapted. For ex. use function blk_props,
*                          which sets insert properties and treats insert id option.
*
*   Arguments            : object       OBJECT_ENUM
*                          dynStrEnum   DBA_DYNST_ENUM
*                          insOptions   UNUSED, SYB_BCP_INS_ID, SYB_BCP_INS_UD_FLD
*                          connectNo    connection number
*                          blkdef       pointer on bulk definition structure
*
*   Return               : RET_SUCCEED
*                          RET_DBA_ERR_INITSYBCTX
*
*   Modification         : REF8798 - YST - 030320
*                          PMSTA-32214 - 030818 - PMO : User loses FSP between 2 calls to PTCC
*
*************************************************************************/
RET_CODE DBA_BcpInitEntity(OBJECT_ENUM      object,
    DBA_DYNST_ENUM   dynStrEnum,
    int              insOptions,     /* REF8798 - YST - 030320 */
    int              connectNo,
    void             **blkdef)
{
    DbiConnection * dbiConn = DBA_GetDbiConnFromConnectNo(connectNo);

    if (dbiConn == nullptr) {
        return RET_DBA_ERR_CONNOTFOUND;
    }

    return DBA_BcpInitEntity(object,
                             dynStrEnum,
                             insOptions,     /* REF8798 - YST - 030320 */
                             *dbiConn,
                             blkdef);
}


RET_CODE DBA_BcpInitEntity(OBJECT_ENUM      object,
                            DBA_DYNST_ENUM   dynStrEnum,
                            int              insOptions,     /* REF8798 - YST - 030320 */
                            DbiConnection&   dbiConn,
                            void             **blkdef)
{
    MemoryPool mp;

    int     colNb = 0, fldNbr = 0, rowSize = 0, aaaBcpCount = 0, firstFld = 0;   /* REF8798 - YST - 030320 */
    LONGSYSNAME_T  tableName;

    /* REF8798 - YST - 030320 - add test "ud" table */
    if ((insOptions & DBA_BCP_INS_UD_FLD) == DBA_BCP_INS_UD_FLD)
    {
        firstFld = DBA_GetFirstCustFld(object);
        fldNbr = GET_FLD_NBR(dynStrEnum);
        strcpy(tableName, DBA_GetDictEntityUdSqlName(object)); /* REF10392 - LJE - 040624 */
    }
    /* insOption = UNUSED or SYB_BCP_INS_ID, see function description for further explanations */
    else
    {
        fldNbr = DBA_GetFirstCustFld(object);
        strcpy(tableName, DBA_GetDictEntitySqlName(object));
    }

    char *          szaaaBcpCount   = nullptr;
    DICT_ATTRIB_STP attribStPtr     = nullptr;
    SYSNAME_T     * colNameTab      = static_cast<SYSNAME_T *>(mp.calloc(FILEINFO, (fldNbr - firstFld), sizeof(SYSNAME_T)));
    DATATYPE_ENUM * colTypesTab     = static_cast<DATATYPE_ENUM *>(mp.calloc(FILEINFO, (fldNbr - firstFld), sizeof(DATATYPE_ENUM)));

    if (colTypesTab == nullptr || colNameTab == nullptr)
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    /* fill up the array of field datatypes */
    /* which allows bulk copy to bind dynamic structure with the entity columns */
    for (int i = firstFld; i < fldNbr; i++)
    {
        if (IS_DBFLD(dynStrEnum, i) == TRUE                                            && /* REF8844 - LJE - 030408 */
            (attribStPtr = DBA_GetDictAttribSt(object, i)) != nullptr &&
            attribStPtr->isPhysicalAttribute()) /* PMSTA-18593 - LJE - 150625 */           /* PMSTA-29879 - LJE - 180705 */
        {
            colTypesTab[colNb] = attribStPtr->dataTpProgN;
            strcpy(colNameTab[colNb], attribStPtr->sqlName);

            /* REF8798 - YST - 030327 - code moved here */
            /* Max row size evaluation, to determine how many rows can be inserted at a time */
            /* according to the given megabite amount aaaBcpCount   */
            rowSize += GET_FLD_MAXLEN(dynStrEnum, i);      /* REF10392 - LJE - 040622 */
            colNb++;
        }
    }

    /* Get the number of megabites that should be inserted at a time */
    if ((szaaaBcpCount = SYS_GetEnv("AAABCPBUF")) != nullptr) /*PPA 991008*/
    {
        if (strspn(szaaaBcpCount, "0123456789") == strlen(szaaaBcpCount))
            aaaBcpCount = atoi(szaaaBcpCount);
    }

    if (aaaBcpCount < 1 || aaaBcpCount > 500)
        aaaBcpCount = 1;

    /* REF8798 - YST - 030327 - code moved up */
    int blkRows = rowSize > 0 ? (aaaBcpCount * 1000000) / rowSize : (aaaBcpCount * 1000000);

    /* REF8798 - YST - 030327 - exception for insert "ud" tables */
    if ((insOptions & DBA_BCP_INS_UD_FLD) == DBA_BCP_INS_UD_FLD && blkRows > 100000)
    {
        blkRows = 99999;
    }

    /* prepare the bulk copy by allocating and setting the blkdef structure */
    RET_CODE ret = DBA_BcpInInit(dbiConn,
                                 tableName,          /* REF8798 - YST - 030327 */
                                 colNameTab,
                                 colTypesTab,
                                 colNb,
                                 firstFld,           /* REF8798 - YST - 030327 */
                                 blkRows,
                                 blkdef);

    if (RET_SUCCEED != ret)
    {
        MSG_SendMesg(RET_DBA_ERR_INSERT_FAILED, 2, FILEINFO, SYS_Stringer(tableName, " Error:", ret).c_str());  /* PMSTA-32214 - 030818 - PMO */
        ret = RET_DBA_ERR_INITSYBCTX;
    }

    return ret;
}

/* End                    */
/* REF2421 - OCE - 980825 */

/*************************************************************************
*
*   Function             : DBA_GetBcpBlockSize
*
*   Description          : This function returns the size of elt buffer
*
*   Arguments            : pointer on SYB_BLKDEF_ST struct
*
*   Return               : int
*
*   Created              : REF10281 - CHU - 040507
*
*   Modification         : PMSTA-23981 - 070716 - PMO : Financial server crash when launching report
*
*************************************************************************/
int DBA_GetBcpBlockSize(void * blkdef)
{
    return (DBI_GetBcpBlockSize(static_cast<DBI_BLKDEF_STP>(blkdef)));              /* PMSTA-23981 - 070716 - PMO */
}

/************************************************************************
**      END          dbabcp.c                                   
*************************************************************************/


/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef DDLGENFROMFILE_H
#define DDLGENFROMFILE_H

/************************************************************************
**      Constant & Macro definitions
*************************************************************************/

/************************************************************************
**      Structures & typedef definitions
*************************************************************************/

/************************************************************************
**      External definitions attached to : ddlgenfromfile.cpp
*************************************************************************/
#ifdef  EXTERN
#undef	EXTERN
#endif
#ifdef  DDLGENFROMFILE_CPP
#define	EXTERN
#else
#define EXTERN extern
#endif

#include       "ddlgendbi.h"
#include     "ddlgensproc.h"
#include      "ddlgenview.h"
#include   "ddlgentrigger.h"
#include            "date.h"

enum class OnErrorRuleEn
{
    Log,
    Exit,
    Hide
};

class DdlGenDataField
{
public:
    DdlGenDataField()
        : dataType(NullDataType)
        , bNullValue(false)
    {
    }

    virtual ~DdlGenDataField()
    {
    }

    DdlGenDataField(const DdlGenDataField& ref)
    {
        *this = ref;
    }

    bool operator == (const std::string& sqlName) const
    {
        return (strcasecmp(sqlName.c_str(), this->m_sqlName.c_str()) == 0);
    }

    void setSqlName(const std::string& sqlName)
    {
        this->m_sqlName = sqlName;
    }

    const std::string& getSqlName()
    {
        return this->m_sqlName;
    }

    DdlGenDataField& operator = (const std::string& sqlName)
    {
        this->m_sqlName = sqlName;
        return *this;
    }

    DdlGenDataField& operator = (const DdlGenDataField& toCopy)
    {
        this->m_sqlName = toCopy.m_sqlName;
        this->value = toCopy.value;
        this->dataType = toCopy.dataType;
        this->bNullValue = toCopy.bNullValue;

        return *this;
    }

    std::string   value;
    DATATYPE_ENUM dataType;
    bool          bNullValue;

protected:
    std::string   m_sqlName;
};


class DdlGenData
{
public:
    DdlGenData()
    {
    }

    virtual ~DdlGenData()
    {
    }

    DdlGenData(const DdlGenData &ref)
    {
        *this = ref;
    }

    DdlGenData&   operator = (const DdlGenData &toCopy)
    {
        for (size_t i = 0; i < toCopy.m_resultSetDataVec.size(); ++i)
        {
            for (size_t j = 0; j < toCopy.m_resultSetDataVec[i].size(); ++j)
            {
                this->addResultSetData(i, j, toCopy.m_resultSetDataVec[i][j], 0);
            }
        }

        return *this;
    }

    void addResultSetData(size_t            resultSetIdx,
                          size_t            recordIdx,
                          DBA_DYNFLD_STP    recordStp,
                          FIELD_IDX_T       recordStpSize);

    void addResultSetData(size_t resultSetIdx, size_t recordIdx, std::vector<DdlGenDataField> &ddlGenDataFieldVector);

    size_t getResultSetNbr()
    {
        if (this->m_resultSetDataVec.empty())
        {
            return this->m_ddlGenDataFieldVector.size();
        }
        return this->m_resultSetDataVec.size();
    }

    size_t getResultSetDataNbr(size_t resultSetIdx)
    {
        if (this->m_resultSetDataVec.size() > resultSetIdx)
        {
            return this->m_resultSetDataVec[resultSetIdx].size();
        }

        if (this->m_ddlGenDataFieldVector.size() > resultSetIdx)
        {
            return this->m_ddlGenDataFieldVector[resultSetIdx].size();
        }

        return 0;
    }

    bool getResultSetData(DBA_DYNFLD_STP &recordStp, size_t resultSetIdx, size_t recordIdx)
    {
        if (this->m_resultSetDataVec.size() > resultSetIdx &&
            this->m_resultSetDataVec[resultSetIdx].size() > recordIdx)
        {
            recordStp = this->m_resultSetDataVec[resultSetIdx][recordIdx];
            return true;
        }

        recordStp = nullptr;
        return false;
    }

    bool getResultSetData(std::vector<DdlGenDataField> &ddlGenDataFieldVector, size_t resultSetIdx, size_t recordIdx)
    {
        if (this->m_ddlGenDataFieldVector.size() > resultSetIdx &&
            this->m_ddlGenDataFieldVector[resultSetIdx].size() > recordIdx)
        {
            ddlGenDataFieldVector = this->m_ddlGenDataFieldVector[resultSetIdx][recordIdx];
            return true;
        }

        return false;
    }

protected:
    MemoryPool mp;
    std::vector<std::vector<DBA_DYNFLD_STP>>                 m_resultSetDataVec;
    std::vector<std::vector<std::vector<DdlGenDataField>>>   m_ddlGenDataFieldVector;
};

class DdlGenTagInfo
{
public:

    // Constructors
    DdlGenTagInfo():
        name(std::string()),
        lineNbr(0),
        readLinePos(0),
        tagNatEn(TagSql_None),
        nextTagNatEn(TagSql_None)
    {
    }

    DdlGenTagInfo(const DdlGenTagInfo &refTag)
    {
        this->name         = refTag.name;
        this->lineNbr      = refTag.lineNbr;
        this->readLinePos  = refTag.readLinePos;
        this->tagNatEn     = refTag.tagNatEn;
        this->nextTagNatEn = refTag.nextTagNatEn;
    }

    // Destructor
    virtual ~DdlGenTagInfo()
    {
    }

    // Method
    DdlGenTagInfo&   operator = (const DdlGenTagInfo &refTag)
    {
        this->name = refTag.name;
        this->lineNbr = refTag.lineNbr;
        this->readLinePos = refTag.readLinePos;
        this->tagNatEn = refTag.tagNatEn;
        this->nextTagNatEn = refTag.nextTagNatEn;
        return *this;
    }

    std::string      name;
    int              lineNbr;
    int              readLinePos;
    DDL_TAG_NAT_ENUM tagNatEn;
    DDL_TAG_NAT_ENUM nextTagNatEn;
};

typedef std::string(DdlGen_ConvertSimpleFuncPtr)(DdlGenContext *);
typedef std::string(DdlGen_ConvertFuncPtr)(std::string &, std::string::size_type, DdlGenContext *, DdlGenVarHelper *, DdlGen *);                                /* PMSTA-26108 - LJE - 171004 */
typedef std::string(DdlGen_ReplaceFuncPtr)(DdlGenContext *, DdlGenVarHelper *, std::vector<std::vector<std::string>>&keywordParamList);

class DdlGenFromFileContext : public AAAObject
{

public:

    // Constructors
    DdlGenFromFileContext();
    DdlGenFromFileContext(const DdlGenFromFileContext& context);

    // Destructor
    virtual ~DdlGenFromFileContext();

    // Method
    DdlGenFromFileContext&   operator = (const DdlGenFromFileContext&) = delete;
    void                     reset();

    std::string              currLineStr;
    std::string              currLineStrLTrim;

    std::vector<std::string> currBlockVector;
    bool                     bInitCurrLineIt;
    bool                     bUpdateIndent;
    std::vector<std::string>::iterator currLineIt;
    int                      lineNb;
    int                      blockLineBeginNb;

    DDL_TAG_NAT_ENUM         currTagNat;
    std::string              currTag;
    DdlGen                  *currDdlGen;

    DDL_TAG_NAT_ENUM         parentTagNat;

    DdlGen                  *outDdlGenPtr;

    std::string              parentPreIndent;

    bool                     bIfIgnored;

    DdlGenFromFileContext   *parentContextPtr;     /* PMSTA-26250 - LJE - 170419 */

    DDL_VIEW_ENUM            forcedViewEn;
    bool                     bForceOwnerBusinessEntity;     /* PMSTA-36919 - LJE - 191112 */

    std::stringstream        pscStream;

    enum class Position
    {
        None,
        If,
        Then,
        ElseIf,
        Else
    };

    Position                 m_position;
    int                      m_elseResultsSetPos;
    bool                     m_bInBlock;
    bool                     m_singleCmd;
    bool                     m_bForceSingleCmd;

    std::vector<DictSprocReturnsClass>                 m_ifResultsSetVector;
    std::vector<std::map<FIELD_IDX_T, DbiInOutData*>>  m_paramVectorVector;
    DICT_T                                             m_parentDictEntity;
};

typedef std::unique_ptr<DdlGenFromFileContext> DdlGenFromFileContextPtr;

class DdlGenHintInfo
{
public:

    // Constructors
    DdlGenHintInfo(DDL_OBJ_ENUM ddlObjEn, const std::string &ddlObjSqlName, const std::string &hintFileName)
        : m_ddlObjEn(ddlObjEn)
        , m_ddlObjSqlName(ddlObjSqlName)
        , m_hintFileName(hintFileName)
        , m_hintAction(HintAction::Search)
        , m_bInComment(false)
    {
    };

    DdlGenHintInfo(const DdlGenHintInfo& ref)
        : m_ddlObjEn(ref.m_ddlObjEn)
        , m_ddlObjSqlName(ref.m_ddlObjSqlName)
        , m_hintFileName(ref.m_hintFileName)
        , m_hintAction(ref.m_hintAction)
        , m_searchVector(ref.m_searchVector)
        , m_replacementVector(ref.m_replacementVector)
        , m_beforeVector(ref.m_beforeVector)
        , m_afterVector(ref.m_afterVector)
        , m_bInComment(ref.m_bInComment)
    {
    };

    // Destructor
    virtual ~DdlGenHintInfo()
    {
    };

    // Method
    DdlGenHintInfo&   operator = (const DdlGenHintInfo &ref)
    {
        this->m_ddlObjEn          = ref.m_ddlObjEn;
        this->m_ddlObjSqlName     = ref.m_ddlObjSqlName;
        this->m_hintFileName      = ref.m_hintFileName;
        this->m_hintAction        = ref.m_hintAction;
        this->m_searchVector      = ref.m_searchVector;
        this->m_replacementVector = ref.m_replacementVector;
        this->m_beforeVector      = ref.m_beforeVector;
        this->m_afterVector       = ref.m_afterVector;
        this->m_bInComment        = ref.m_bInComment;

        return *this;
    };

    enum class HintAction
    {
        Search,
        Replacement,
        Before,
        After
    };

    DdlGenHintInfo &operator<<(const std::string& ref)
    {
        switch (this->m_hintAction)
        {
            case HintAction::Search:
            {
                std::stringstream currLineStream;
                DdlGenMsg::checkComments(ref, this->m_bInComment, currLineStream, true, true);

                if (this->m_bInComment == false &&
                    currLineStream.str().empty() == false)
                {
                    this->m_searchVector.push_back(currLineStream.str());
                }
                break;
            }
            case HintAction::Replacement:
                this->m_replacementVector.push_back(ref);
                break;

            case HintAction::Before:
                this->m_beforeVector.push_back(ref);
                break;

            case HintAction::After:
                this->m_afterVector.push_back(ref);
                break;
        }

        return *this;
    }

    void setHintStrreamPos(HintAction hintAction)
    {
        this->m_hintAction = hintAction;
    };

    const std::string &getFileName() const
    {
        return this->m_hintFileName;
    };

    std::string getSearchPattern()
    {
        std::stringstream stream;
        for (auto it = this->m_searchVector.begin(); it != this->m_searchVector.end(); ++it)
        {
            stream << (*it) << std::endl;
        }

        return stream.str();
    }

    bool replace(const std::string &currLine, size_t &matchPos, size_t &startPos, std::vector<std::string> &blockVector);

protected:

    DDL_OBJ_ENUM             m_ddlObjEn;
    std::string              m_ddlObjSqlName;
    std::string              m_hintFileName;
    HintAction               m_hintAction;

    std::vector<std::string> m_searchVector;
    std::vector<std::string> m_replacementVector;
    std::vector<std::string> m_beforeVector;
    std::vector<std::string> m_afterVector;

private:
    bool                     m_bInComment;
};

class DdlGenFromFile:public DdlGenMsg
{

    friend class DdlGen;

public:

    // Constructors
    DdlGenFromFile(DdlGenContext                &paramDdlGenContext);
    DdlGenFromFile(const DDL_OBJ_FROM_FILE_ENUM  paramDdlObjFromFileEn,
                   OBJECT_ENUM                   paramObjectEn,
                   DdlGenContext                &paramDdlGenContext,
                   DdlGenEntity                 *paramDdlGenEntityPtr,
                   DdlGen                       *paramParentDdlGen,
                   bool                          paramBAppendFile = false,
                   DdlGenVarHelper              *paramDdlGenVarHelperPtr = NULL,
                   DdlGenFile                   *paramFileHelperPtr = NULL);

    DdlGenFromFile(const DdlGenFromFile&) = delete;
    // Destructor
    virtual ~DdlGenFromFile();

    // Static Methods

    // Methods
    DdlGenFromFile&           operator = (const DdlGenFromFile&) = delete;
    virtual RET_CODE          build();
    RET_CODE                  buildBlock(DDL_OBJ_ENUM paramOutDdlObjEn = DdlObj_None);
    std::string               buildScript(const std::string &scriptStr, DDL_OBJ_ENUM paramOutDdlObjEn = DdlObj_SubDdlObj, int level = 0);
    void                      manageTempTable(std::string&, bool );
    std::string               getFinSrvCall();
    bool                      isInBlock();
    void                      setInBlock(bool bNewInBlock);

    void                      setTriggerInfo(TRIGGER_POS_ENUM paramTrgPosEn, DML_EVENT_ENUM paramDmlEventEn, const std::string &atReturnStr);
    void                      clearTriggerInfo();

    void                      init(OBJECT_ENUM objectEn);

    OBJECT_ENUM               getObjectEn() const;
    void                      setObjectEn(OBJECT_ENUM locObjectEnum);

    DDL_OBJ_ENUM              getOutDdlObjEn();

    void                      setAvoidSecurity(bool bAvoidSecurity);

    virtual void              printMsg(RET_CODE retCode,
                                       const std::string &paramMsg,
                                       bool isNewLine = true,
                                       int sprocLine = -1);

    void                      setResultSetDataPtr(DdlGenData *);
    DdlGenData               *getResultSetDataPtr();
    void                      addResultSetData(size_t resultSetIdx, size_t recordIdx, DBA_DYNFLD_STP recordStp, FIELD_IDX_T recordStpSize);
    void                      addResultSetData(size_t resultSetIdx, size_t recordIdx, std::vector<DdlGenDataField> &ddlGenDataFieldVector);
    void                      freeResultSetData();

    bool                      bPrintRowCount;
    bool                      bServerOutput;
    bool                      bAutoCommit;
    bool                      bEndTransaction;
    bool                      bKeepConnection;
    bool                      bKeepData;
    bool                      bKeepResultSetData;
    int                       optimLevel;
    int                       maxScale;
    int                       rowCount;
    size_t                    m_dataIdx;
    bool                      m_bSkipNextBloc;

    OnErrorRuleEn             onErrorRuleEn;

    bool                      bPrintUserAssgn;

    DdlGenVarHelper          *varHelperPtr;

    DATE_STYLE_ENUM           inDateTimeStyleEn;
    DATE_STYLE_ENUM           outDateTimeStyleEn;
    DDL_TAG_NAT_ENUM          parentScriptTagNat;

    DdlGenFromFileContext    *context;
    DICT_T                    dictEntityDictId;

    bool                      m_bSendRequestWithProc;
    std::string               m_lastPhysicalTable;

protected:

    std::ifstream     *genSqlFile;

    void              loadHintUsrFile();
    void              replaceUsrHint();

    RET_CODE          createSProcHeader();
    RET_CODE          createSProcStdHeader();
    RET_CODE          createSProcCall();
    RET_CODE          createSProcSelect();
    RET_CODE          createSProcSelectCheck();
    RET_CODE          createSProcInsert();
    RET_CODE          createSProcUpdate();
    RET_CODE          createSProcDelete();
    RET_CODE          createSProcTruncate(bool bForce);
    RET_CODE          createSProcCreate();
    RET_CODE          createSProcDrop();
    RET_CODE          createSProcRename();
    RET_CODE          createSProcCursor(); /* PMSTA-13109 - LJE - 111205 */
    RET_CODE          createSProcForSelect(); /* PMSTA-nuodb - LJE - 190809 */
    RET_CODE          createSProcDeclare();
    RET_CODE          createSProcAssignSelect();
    RET_CODE          createSProcAssign();
    RET_CODE          createSProcExec();
    RET_CODE          createSProcExecSql();
    RET_CODE          createSProcIfExists();
    RET_CODE          createSProcIf();
    RET_CODE          createSProcWhile();
    RET_CODE          createSProcSetRowcount();
    RET_CODE          createSProcSetDatefirst();
    RET_CODE          createSProcSetForcePlan();
    RET_CODE          createSProcGetUpdateCount();
    RET_CODE          createSProcReturn();
    RET_CODE          createSProcUse();
    RET_CODE          createSProcBeginTran();
    RET_CODE          createSProcCommit();
    RET_CODE          createSProcRollback();
    RET_CODE          createSProcCheck();
    RET_CODE          createSProcApplRaisError();
    RET_CODE          createSProcPrint();
    RET_CODE          createSProcCallReturnStatus();
    RET_CODE          createSProcIdentityIncrement();
    RET_CODE          createSProcReserveIdentity();
    RET_CODE          createSProcDlmCheck(DdlGen *ddlGenPtr); /* PMSTA-24026 - DDV - 161109 - Add new generator feature for data lifecycle management */
    RET_CODE          createStdSProc();

    RET_CODE          createSprocExternalEntity();
    DICT_ENTITY_STP   createVirtualEntity(const std::string &fullSqlName);

    RET_CODE          createSProcGenLoop();
    RET_CODE          createSProcGenIf();

    RET_CODE          createGetResultSetData();

    RET_CODE          createSProcGet();
    RET_CODE          createSProcSet();

    /* PMSTA-16194 - LJE - 130522 */
    RET_CODE          createViewHeader();

    bool              getGenSqlLine(bool bFromFile = false, bool bRemoveComment = false, int *readCptPtr = NULL);

    RET_CODE          getEntityInfo(std::string &, DICT_ENTITY_STP &, OBJECT_ENUM &, DBA_DYNTYPE_ENUM &, DBA_ACTION_ENUM, bool = true);

    bool              readNextCurrBlock();
    void              resetNextCurrBlock(int prevLineNbr);

    bool              treatGenSqlLine(std::string *paramCurrLineStr = nullptr);
    bool              getIndentGenSqlLine();

    int               tokenize(std::vector<std::string>& tokens,
                               const std::string& delimiters,
                               bool          bAppend = false,
                               int           bracketOpen = 0,
                               bool          bIsInBracket = false);

    RET_CODE          errorStdSProc(RET_CODE ret);

    bool              isTag(const char *tagName, bool bUpdCurTag=false, bool bCheckTag=true);
    std::string::size_type posTag(const std::string& lineStr, const char *tagName);
    bool              isNewBlockTag(const std::string &endBlock);

    DdlGenTagInfo        getTag();
    DdlGenTagInfo        getNextTag(DdlGenTagInfo &tagInfo, int level = 0);

    bool                 isRdbmsScript(const std::string &lineStr, std::vector<std::string> &allRdbmsInScope, bool isEndTag = false);

    void                 treatBody();
    RET_CODE             managePartialSpecialization();
    RET_CODE             checkInsertSelectList(DdlGen *locDdlGenPtr);

    bool                 manageNestedTag(std::stringstream  & outStream, const std::string& endBlock = std::string("END"), const std::string& parIndentStr = std::string());

    bool                 contains(const std::string& findStr);

    DBA_DYNTYPE_ENUM     getDynType(const std::string& dynType);

    RET_CODE             setSProcExtraParam(DictSprocClass &dictSprocStp, const std::vector<std::string>&  tokens);
    RET_CODE             getSProcExtraParam(DictSprocClass &dictSprocStp);
    RET_CODE             setSProcTechParam(DictSprocClass &dictSprocStp);

    void                 extractFromPart(DdlGen *ddlGenPtr, ENTITY_SECURITY_LEVEL_ENUM locSecuLevelEn);
    void                 extractWherePart(DdlGen *ddlGenPtr, bool& bTagEnd, std::string& unionStr);

    void                 replaceTag(std::string & lineToTreat, const char *tagToReplace, const std::string &replaceStr);
    void                 replaceTag(std::string& lineToTreat, const char* tagToReplace, DdlGen_ConvertSimpleFuncPtr* replaceFct);
    void                 replaceStrTag(std::string & lineToTreat, const char *tagToReplace, const std::string &replaceStr);
    void                 replaceDbTag(std::string & lineToTreat, const char *tagToReplace, const std::string &replaceStr);
    void                 replaceTagByFct(std::string & lineToTreat, const char *tagToReplace, DdlGen_ConvertFuncPtr *replaceFct);
    void                 replaceFunctions(std::string & lineToTreat);
    void                 replaceFunction(std::string & lineToTreat, const std::string &tagFunction);
    void                 replaceFunctionByFct(std::string & lineToTreat, const std::string &tagFunction, DdlGen_ReplaceFuncPtr *replaceFct);

    void                  setStdProc();
    void                  extractKeywordParam(const std::string &tagStr, 
                                              unsigned fixedParam, 
                                              std::vector<std::vector<std::string>> &keywordParamList, 
                                              bool        bWithBracket, 
                                              bool        bOneLevel = false,
                                              std::string nextRecordDelimiter = ",(0123456789@+-':\"");
    DICT_ENTITY_STP       getDictEntityStp();

    std::string           printSubQuery(std::stringstream& inputStream);

    DDL_OBJ_FROM_FILE_ENUM ddlObjFromFileEn;
    DDL_OBJ_ENUM           outDdlObjEn;
    std::string            genSqlFileStr;

    int                    readLineNb;

    bool                  bLocalVarHelper;

    DdlGenFile           *fileHelperPtr;
    DdlGen               *m_parentDdlGenPtr;

    DdlGenSqlBlock        finSrvCallSqlBlock;

    TRIGGER_POS_ENUM      trgPosEn;
    DML_EVENT_ENUM        dmlEventEn;
    std::stringstream     m_atReturnStream;

    std::list<DdlSelectElt> insertList;

    DdlGenData           *resultSetData;

    /* PMSTA-43500 - LJE - 210316 */
    std::map<std::string, std::vector<DdlGenHintInfo>> m_hintInfoMap;

private:
    RET_CODE                    initAllStdSProc();
    RET_CODE                    createAllStdSProc();
    void                        removeFromStdProcs(const std::string &sprocSqlName);
    RET_CODE                    createStandardView();
    RET_CODE                    manageFromFileTriggers();
    RET_CODE                    createStandardTriggers();
    void                        newOutDdlGen();
    void                        deleteOutDdlGen();

    void                        setDefaultIfNull(std::string &lineStr, const std::string &defaultValue = "''");

    DdlGenSProc                *outDdlGenSprocPtr;
    DdlGenView                 *outDdlGenViewPtr;
    DdlGenTrigger              *outDdlGenTriggerPtr;
    DdlGen                     *outDdlGenPtr;

    OBJECT_ENUM	                objectEn;

    std::list<DictSprocClass>   stdDictSprocList;
    bool                        allStdProcToDo;

    std::map<std::string, bool> stdViewMap;

    std::string                 fileExtStr;

    bool                        bAppendFile;

    DdlGenEntity               *ddlGenEntityPtr;

    bool                        bAllowEmptyBlock;

    bool                        bInManualTrg;
    bool                        bApplRaiseError;
    bool                        m_bNewLine;
};

typedef std::unique_ptr<DdlGenFromFile> DdlGenFromFilePtr;

#endif	                               /* ifndef DDLGENFROMFILE_H */
/************************************************************************
**      END       ddlgenfromfile.h                                   Odyssey
*************************************************************************/

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DBAGENDDL_CPP

/************************************************************************
**      Include files
*************************************************************************/
#ifdef NTWIN
#pragma warning (push)
#endif

#include         "unidef.h"     /* Mandatory */
#include            "gen.h"
#include  "dbiconnection.h"
#include            "dba.h"
#include      "ddlgendbi.h"
#include     "ddlgenfile.h"
#include      "ddlgenvar.h"
#include         "ddlgen.h"
#include "ddlgenfromfile.h"
#include      "conexcept.h"
#include           "json.h"

#include     <climits>

#include "QSettings"
#include "QFileInfo"

#ifdef NTWIN
#include <direct.h>
#else
#include <sys/stat.h>
#endif

#ifdef NTWIN
#pragma warning (pop)
#endif

/************************************************************************
**      External entry points
**
*************************************************************************/
extern bool                 EV_UseAlternativeDataSource;

extern std::string          EV_SourceApplOwner;
extern DdlGenCfgFile       *EV_SourceCfgFile;
extern DBA_RDBMS_ENUM       EV_SourceRdbmsVendor;

extern std::string          EV_TargetApplOwner;
extern DdlGenCfgFile       *EV_TargetCfgFile;
extern DBA_RDBMS_ENUM       EV_TargetRdbmsVendor;


/************************************************************************
**      Local functions
**
*************************************************************************/

/************************************************************************
**      Static definitions & data
**
*************************************************************************/

DBA_RDBMS_ENUM EV_RdbmsDdlGen = Sybase; /* */


/************************************************************************
**      FONCTIONS
**
************************************************************************/



extern DdlGenContext*       EV_SourceContext;
DDL_CONTEXT_ST EV_GenDdlContext;
static MULTI_ENTITY_LEVEL_ENUM  SV_MultitEntityLevel = MultiEntityLevel_None;
static std::string              SV_MasterBusinessEntityCd;
static std::string              SV_MasterBusinessEntityId;

/************************************************************************
**
**  Function    :   DdlGenSqlBlock::empty()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26108 - LJE - 170815
**
*************************************************************************/
bool DdlGenSqlBlock::empty()
{
    return (this->str().empty() || DdlGen::find_first_not_of(this->str(), " \t\n") == std::string::npos);
}

/************************************************************************
**
**  Function    :   DdlGenContext()
**
**  Description :   Constructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 141022
**
*************************************************************************/
DdlGenContext::DdlGenContext(DBA_RDBMS_ENUM rdbmsEn, bool bLightContext)
    : DdlGenMsg(nullptr)
    , m_parentContext(this)
    , m_parentFileHeper(nullptr)
    , m_bMultiThreadMode(false)
    , m_bLightContext(bLightContext)
    , m_rdbmsEn(rdbmsEn)
    , cfgFileHelper(*this, CfgFileType_InstallCfg)
    , propFileHelper(*this, CfgFileType_Properties)
    , templateFileHelper(*this, CfgFileType_Template)
    , upgradeFileHelper(*this, CfgFileType_Upgrade)
    , upgDoneCpt(0)
    , upgToDoCpt(0)
    , scriptControlXdEntId(ZERO_ID)
    , bSendInDb(true)
    , bCheck(false)
    , bBuildDbi(false)
    , bGenFromDbi(false)
    , bSimulation(false)
    , bForceReBuild(false)
    , bIgnoreCheck(false)
    , bDisable(false)
    , m_bHasUnknownCall(false)
    , m_ddlGenContextForConn(nullptr)
    , templateDdlGenEntity(nullptr)
    , m_dbiConn(nullptr)
    , m_dbiConnForDdl(nullptr)
    , m_requestHelper(nullptr)
    , m_extDbiConn(nullptr)
    , enableMultiTascLoginVal(-1)
    , enableAdditionalDSPVal(-1)
    , enableSecuOnFkView(-1)
    , templateVersionVal(-1)
    , m_silentMode(99)
    , m_rwLock(nullptr)
    , m_sourceCharSetEn(CurrentCharsetCode_IsNull)
    , m_ddlGenDbaAccessPtr(nullptr)
    , m_maxDbLenRule(MaxDbLenCreationRule::None)
{
    this->ddlGenContextPtr                 = this;
    this->migrationMode                    = MigrationMode::None;
    this->optimLevelEn                     = OptimLevel::None;
    this->bUniqueOnly                      = false;
    this->bWriteFile                       = true;
    this->optimMask                        = (SYS_IsSqlMode() ? 0 : 0xFFFF);
    this->bLanguage                        = false;
    this->m_ddlGenMode                     = DdlGenMode_Standard;
    this->fileHelper                       = nullptr;
    this->m_viewEn                         = View_None;
    this->bInTran                          = false;
    this->m_bIgnoreDepends                 = false;
    this->m_bOutputMessage                 = false;   /* PMSTA-37366 - LJE - 191002 */
    this->bForceTableName                  = false; /* PMSTA-26108 - LJE - 171009 */
    this->bForceUdTable                    = false;   /* PMSTA-28591 - LJE - 171009 */
    this->manageNullLevel                  = MAX_USHORT;
    this->identityCacheSize                = 1000;    /* PMSTA-30219 - LJE - 180319 */
    this->ddlBuildModeEn                   = DdlBuildMode_Standard;
    this->callerEn                         = DdlGenCaller_Unknown;
    this->bPartialSpecialization           = false;                    /* PMSTA-32145 - LJE - 180720 */
    this->m_useAlternativeDataServer       = false;                    /* PMSTA-37374 - LJE - 210409 */
    this->m_bIsInstallFromScratch          = false;
    this->m_bDatAll                        = false;                    /* PMSTA-58084 - LJE - 240729 */
    this->m_bHaveMultiEntityCateg          = false;                    /* PMSTA-49178 - LJE - 220907 */
    this->iNoOpCpt                         = 0;
    this->bWarning                         = false;
    this->m_bOnCatch                       = false;                    /* PMSTA-49375 - LJE - 220602 */
    this->m_bBcpMode                       = false;
    this->m_buildBindOptionPtr             = nullptr;
    this->m_shDictSporcStp                 = nullptr;
    this->m_logStreamPtr                   = nullptr;
    this->bUseClusterIdx                   = false;
    this->bCreatePK                        = true;
    this->ddlDestDbName                    = this->getMainDbName();

    this->buildDate.reset();

    if (this->m_bLightContext)
    {
        this->setDdlObjEn(DdlObj_Sql);
    }

    this->setDefDdlDestDbName();

    this->resetContext(std::string());

    if (this->m_rdbmsEn == Sqlite)
    {
        this->ddlGenAction.m_bUseNativeQuery = true;
    }
}

/************************************************************************
**
**  Function    :   DdlGenContext()
**
**  Description :   Constructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37366 - LJE - 200304
**
*************************************************************************/
DdlGenContext::DdlGenContext(const DdlGenContext &ref)
    : DdlGenContext(ref.m_rdbmsEn, ref.m_bLightContext)
{

    this->m_parentContext         = ref.m_parentContext;        /* PMSTA-45830 - LJE - 220323 */
    assert(this->m_parentContext == this->m_parentContext->m_parentContext);

    this->bForceReBuild           = ref.bForceReBuild;
    this->bCheck                  = ref.bCheck;
    this->bUniqueOnly             = ref.bUniqueOnly;
    this->bSimulation             = ref.bIgnoreCheck;
    this->bIgnoreCheck            = ref.bIgnoreCheck;
    this->bBuildDbi               = ref.bBuildDbi;
    this->bGenFromDbi             = ref.bGenFromDbi;
    this->bSimulation             = ref.bSimulation;
    this->migrationMode           = ref.migrationMode;
    this->optimLevelEn            = ref.optimLevelEn;
    this->optimMask               = ref.optimMask;
    this->ddlGenAction            = ref.ddlGenAction;
    this->bSendInDb               = ref.bSendInDb;
    this->identityCacheSize       = ref.identityCacheSize;
    this->m_bIsInstallFromScratch = ref.m_bIsInstallFromScratch;
    this->m_bDatAll               = ref.m_bDatAll;
    this->ddlDestDbName           = ref.ddlDestDbName;
    this->defDdlDestDbName        = ref.defDdlDestDbName;
    this->m_forceTbSeg            = ref.m_forceTbSeg;
    this->m_forceTbSegSqlName     = ref.m_forceTbSegSqlName;
    this->m_forceTbDbSqlName      = ref.m_forceTbDbSqlName;
    this->m_forceIdxSeg           = ref.m_forceIdxSeg;
    this->m_forceIdxSegSqlName    = ref.m_forceIdxSegSqlName;
    this->m_forceIdxDbSqlName     = ref.m_forceIdxDbSqlName;
    this->tablesFromSrcSysMap     = ref.tablesFromSrcSysMap;
    this->m_ddlGenDbaAccessPtr    = ref.m_parentContext->m_ddlGenDbaAccessPtr;
}

/************************************************************************
**
**  Function    :   ~DdlGenContext()
**
**  Description :   Destructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 141022
**
*************************************************************************/
DdlGenContext::~DdlGenContext()
{
    if (this->m_dbiConnForDdl != nullptr &&
        this->m_dbiConnForDdl != this->m_dbiConn)
    {
        if (this->bSendInDb)
        {
            this->setDdlDestDbName(this->getMainDbName(), nullptr);
            this->setDdlDestUser(std::string());
            this->applyContext(true);
        }

        DBA_EndConnection(&(this->m_dbiConnForDdl), RET_GET_LEVEL(this->lastErrRetCode) == RET_LEV_ERROR);
    }

    this->endConnection();

    FREE(this->m_parentContext->m_rwLock);
}

/************************************************************************
**
**  Function    :   syncContext()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37366 - LJE - 200320
**
*************************************************************************/
void DdlGenContext::syncContext(const DdlGenContext &ref)
{
    this->writeLock();
    for (auto it = ref.m_validDdlObjMap.begin(); it != ref.m_validDdlObjMap.end(); ++it)
    {
        this->m_validDdlObjMap.insert(std::make_pair(it->first, it->second));
    }

    for (auto it = ref.m_ddlGenEntitiesMap.begin(); it != ref.m_ddlGenEntitiesMap.end(); ++it)
    {
        this->m_ddlGenEntitiesMap.insert(std::make_pair(it->first, it->second));
    }

    for (auto it = ref.depEntityPscSqlNameSet.begin(); it != ref.depEntityPscSqlNameSet.end(); ++it)
    {
        this->depEntityPscSqlNameSet.insert(*it);
    }

    for (auto it = ref.depSprocSqlNameSet.begin(); it != ref.depSprocSqlNameSet.end(); ++it)
    {
        this->depSprocSqlNameSet.insert(*it);
    }

    this->writeUnlock();
}

/************************************************************************
**
**  Function    :   setDdlGenActionInfoOnAllEntities()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37366 - LJE - 200320
**
*************************************************************************/
void DdlGenContext::setDdlGenActionInfoOnAllEntities()
{
    for (auto it = this->m_ddlGenEntitiesMap.begin(); it != this->m_ddlGenEntitiesMap.end(); ++it)
    {
        it->second->setDdlGenActionInfo(this->ddlGenAction);
    }
}


/************************************************************************
**
**  Function    :   DBA_ManageSegment()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 211108
**
*************************************************************************/
RET_CODE DdlGenContext::manageSegment()
{
    DdlGenMsg       ddlGenMsg(this);

    DBA_DYNFLD_STP* shDictSegmentTab = NULL, * shDictDatabaseTab = NULL;
    int             shDictSegmentNbr = 0, shDictDatabaseNbr = 0;
    MemoryPool      mp;

    RET_CODE ret = DBA_Select2(DictSegment,
                               UNUSED,
                               NullDynSt,
                               NULL,
                               S_DictSegment,
                               &shDictSegmentTab,
                               UNUSED,
                               UNUSED,
                               &shDictSegmentNbr,
                               this->getDbiConn());

    if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
    {
        ret = DBA_Select2(DictDatabase,
                          UNUSED,
                          NullDynSt,
                          NULL,
                          S_DictDatabase,
                          &shDictDatabaseTab,
                          UNUSED,
                          UNUSED,
                          &shDictDatabaseNbr,
                          this->getDbiConn());
    }

    if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
    {
        std::map<std::string, DBA_DYNFLD_STP> dictDatabaseMap;

        for (int i = 0; i < shDictDatabaseNbr; i++)
        {
            dictDatabaseMap.insert(std::make_pair(GET_SYSNAME(shDictDatabaseTab[i], S_DictDatabase_Code), shDictDatabaseTab[i]));
        }

        for (std::map<std::string, CFG_DB_SECTION_ST>::iterator dbSectionIt = this->getCfgFileHelper().dbSectionMap.begin(); dbSectionIt != this->getCfgFileHelper().dbSectionMap.end(); ++dbSectionIt)
        {
            auto           dictDatabaseIt = dictDatabaseMap.find(dbSectionIt->second.dbFct);
            DBA_DYNFLD_STP dictDatabaseStp = (dictDatabaseIt != dictDatabaseMap.end() ? dictDatabaseIt->second : nullptr);

            if (EV_UseAlternativeDataSource == false)
            {
                if (dictDatabaseStp == nullptr)
                {
                    DdlGenConnGuard     ddlGenConnGuard(*this);
                    DbiConnectionHelper dbiConnHelper(&ddlGenConnGuard.getDbiConn(), false);
                    DdlGenRequestHelper requestHelper(dbiConnHelper, *this);

                    dictDatabaseStp = requestHelper.allocDynSt(FILEINFO, A_DictDatabase);
                    SET_SYSNAME(dictDatabaseStp, A_DictDatabase_Code, dbSectionIt->second.dbFct.c_str());
                    SET_SYSNAME(dictDatabaseStp, A_DictDatabase_SqlName, dbSectionIt->second.dbSqlName.c_str());

                    requestHelper.dbaCall(Insert,
                                          DictDatabase,
                                          UNUSED,
                                          dictDatabaseStp);

                    DBA_DYNFLD_STP shDictDatabase = mp.allocDynst(FILEINFO, S_DictDatabase);

                    COPY_DYNFLD(shDictDatabase, S_DictDatabase, S_DictDatabase_DictId, dictDatabaseStp, A_DictDatabase, A_DictDatabase_DictId);
                    SET_SYSNAME(shDictDatabase, S_DictDatabase_Code, dbSectionIt->second.dbFct.c_str());
                    SET_SYSNAME(shDictDatabase, S_DictDatabase_SqlName, dbSectionIt->second.dbSqlName.c_str());

                    dictDatabaseMap.insert(std::make_pair(GET_SYSNAME(shDictDatabase, S_DictDatabase_Code), shDictDatabase));
                }

                if (dictDatabaseStp != nullptr)
                {
                    if (strcasecmp(dbSectionIt->second.dbSqlName.c_str(), GET_SYSNAME(dictDatabaseStp, S_DictDatabase_SqlName)) != 0)
                    {
                        ddlGenMsg.printMsg(RET_DBA_ERR_INVDATA,
                                           "Mismatch database definition for function " + dbSectionIt->second.dbFct +
                                           ", define " + dbSectionIt->second.dbSqlName +
                                           " instead of " + GET_SYSNAME(dictDatabaseStp, S_DictDatabase_SqlName) +
                                           " in dict_database table");
                    }
                    dbSectionIt->second.dbDictId = GET_DICT(dictDatabaseStp, S_DictDatabase_DictId);
                }
            }
        }

        DBA_DYNFLD_STP aDictSegmentStp = ALLOC_DYNST(A_DictSegment);
        for (std::map<std::string, CFG_SEG_SECTION_ST>::iterator segSectionIt = this->getCfgFileHelper().segSectionMap.begin(); segSectionIt != this->getCfgFileHelper().segSectionMap.end(); ++segSectionIt)
        {
            bool bUpdate = false;

            for (int i = 0; i < shDictSegmentNbr; i++)
            {
                if (segSectionIt->second.segFct.compare(GET_SYSNAME(shDictSegmentTab[i], S_DictSegment_Code)) == 0)
                {
                    segSectionIt->second.segDictId = GET_DICT(shDictSegmentTab[i], S_DictSegment_DictId);

                    if (segSectionIt->second.segSqlName.compare(GET_SYSNAME(shDictSegmentTab[i], S_DictSegment_SqlName)) != 0)
                    {
                        bUpdate = true;
                    }
                    break;
                }
            }

            auto           dictDatabaseIt = dictDatabaseMap.find(segSectionIt->second.dbFct);
            DBA_DYNFLD_STP dictDatabaseStp = (dictDatabaseIt != dictDatabaseMap.end() ? dictDatabaseIt->second : nullptr);

            if (dictDatabaseStp != nullptr)
            {
                segSectionIt->second.dbDictId = GET_DICT(dictDatabaseStp, S_DictDatabase_DictId);
                segSectionIt->second.dbSqlName = GET_SYSNAME(dictDatabaseStp, S_DictDatabase_SqlName);
            }

            if (segSectionIt->second.segDictId == 0 &&
                segSectionIt->second.dbDictId != 0)
            {
                SET_NULL_ID(aDictSegmentStp, A_DictSegment_DictId);
                SET_CODE(aDictSegmentStp, A_DictSegment_Code, segSectionIt->second.segFct.c_str());
                SET_SYSNAME(aDictSegmentStp, A_DictSegment_SqlName, segSectionIt->second.segSqlName.c_str());
                SET_DICT(aDictSegmentStp, A_DictSegment_DbDictId, segSectionIt->second.dbDictId);

                ret = DBA_Insert2(DictSegment,
                                  UNUSED,
                                  A_DictSegment,
                                  aDictSegmentStp,
                                  UNUSED,
                                  this->getDbiConn(),
                                  UNUSED);

                segSectionIt->second.segDictId = GET_DICT(aDictSegmentStp, S_DictSegment_DictId);
            }
            else if (bUpdate)
            {
                SET_DICT(aDictSegmentStp, A_DictSegment_DictId, segSectionIt->second.segDictId);
                SET_CODE(aDictSegmentStp, A_DictSegment_Code, segSectionIt->second.segFct.c_str());
                SET_SYSNAME(aDictSegmentStp, A_DictSegment_SqlName, segSectionIt->second.segSqlName.c_str());
                SET_DICT(aDictSegmentStp, A_DictSegment_DbDictId, segSectionIt->second.dbDictId);

                ret = DBA_Update2(DictSegment,
                                  UNUSED,
                                  A_DictSegment,
                                  aDictSegmentStp,
                                  UNUSED,
                                  this->getDbiConn(),
                                  UNUSED);

            }
        }

        FREE_DYNST(aDictSegmentStp, A_DictSegment);
        DBA_FreeDynStTab(shDictSegmentTab, shDictSegmentNbr, S_DictSegment);
        DBA_FreeDynStTab(shDictDatabaseTab, shDictDatabaseNbr, S_DictDatabase);
    }

    return RET_SUCCEED;
}


/************************************************************************
**
**  Function    :   loadMetaDictData()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
RET_CODE DdlGenContext::loadMetaDictData()
{
    return this->getDdlGenDbaAccess().loadMetaDict();
}

/************************************************************************
**
**  Function    :   loadExtendedData()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
RET_CODE DdlGenContext::loadExtendedData()
{
    return this->getDdlGenDbaAccess().loadExtended();
}

/************************************************************************
**
**  Function    :   importAllData()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
RET_CODE DdlGenContext::importAllData()
{
    return this->getDdlGenDbaAccess().importAllMetaDict();
}

/************************************************************************
**
**  Function    :   DdlGenContext::getDdlGenDbaAccessPtr()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
DdlGenDbaAccess &DdlGenContext::getDdlGenDbaAccess()
{
    if (this->m_parentContext->m_ddlGenDbaAccessPtr == nullptr)
    {
        if (this->m_parentContext->m_extDbiConn != nullptr &&
            this->m_parentContext->m_extDbiConn->getDdlGenDbaAccessPtr() != nullptr)
        {
            this->m_parentContext->m_ddlGenDbaAccessPtr = this->m_parentContext->m_extDbiConn->getDdlGenDbaAccessPtr();
        }
        else
        {
            this->m_parentContext->m_ddlGenDbaAccessPtr = new DdlGenDbaAccess(*this->m_parentContext);
            this->m_parentContext->m_mp.ownerObject(this->m_parentContext->m_ddlGenDbaAccessPtr);
        }
    }
    return *this->m_parentContext->m_ddlGenDbaAccessPtr;
}

/************************************************************************
**
**  Function    :   DdlGenContext::isMetaDictLoaded()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
bool DdlGenContext::isMetaDictLoaded()
{
    return this->getDdlGenDbaAccess().isMetaDictLoaded();
}

/************************************************************************
**
**  Function    :   DdlGenContext::isExtendedLoaded()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210610
**
*************************************************************************/
bool DdlGenContext::isExtendedLoaded()
{
    return this->getDdlGenDbaAccess().isExtendedLoaded();
}


/************************************************************************
**
**  Function    :   DdlGenContext::getDefDdlDestDbName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
std::string DdlGenContext::getDefDdlDestDbName()
{
    return this->defDdlDestDbName;
}

/************************************************************************
**
**  Function    :   DdlGenContext::setDefDdlDestDbName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
void DdlGenContext::setDefDdlDestDbName(const std::string &newDdlDestDbName)
{
    if (newDdlDestDbName.empty())
    {
        /* WEALTH-9627 - LJE - 240625 */
        if (this->defDdlDestDbName.empty() ||
            this->ddlGenAction.m_execModeEn != DbObjExecMod_BuildFromTemplate)
        {
            this->defDdlDestDbName = this->getMainDbName();
        }
    }
    else
    {
        this->defDdlDestDbName = newDdlDestDbName;
    }

    if (this->bGenFromDbi == false && EV_UseAlternativeDataSource == false)
    {
        this->setDdlDestDbName(this->defDdlDestDbName, nullptr);
    }
}

/************************************************************************
**
**  Function    :   DdlGenContext::getDdlDestDbName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
std::string DdlGenContext::getDdlDestDbName()
{
    if (this->ddlDestDbName.empty())
    {
        this->ddlDestDbName = this->defDdlDestDbName;
    }
    return this->ddlDestDbName;
}

/************************************************************************
**
**  Function    :   DdlGenContext::setDdlDestDbName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
void DdlGenContext::setDdlDestDbName(std::string newDdlDestDbName, DdlGenDbi* ddlGenDbi)
{
    if (newDdlDestDbName.empty() &&
        this->defDdlDestDbName.empty() == false)
    {
        return this->setDdlDestDbName(this->defDdlDestDbName, ddlGenDbi);
    }

     DdlGenDbi::standardize(newDdlDestDbName, this);

     if (this->bGenFromDbi)
     {
         this->getConvertValue(newDdlDestDbName);
     }

    if (this->ddlDestDbName.compare((newDdlDestDbName.empty() ? this->getDefDdlDestDbName() : newDdlDestDbName)) != 0)
    {
        this->ddlDestDbName = newDdlDestDbName.empty() ? this->getDefDdlDestDbName() : newDdlDestDbName;

        if (this->getDefDdlDestDbName().empty())
        {
            this->setDefDdlDestDbName(this->ddlDestDbName);
        }

        if (this->bGenFromDbi &&
            this->ddlDestDbName.compare(this->getMainDbName()) != 0 &&
            ddlGenDbi        != nullptr &&
            this->fileHelper != nullptr)
        {
            (*this->fileHelper)
                << ddlGenDbi->getCmdPrintMsg("Using database " + this->ddlDestDbName, false) << "\n"
                << ddlGenDbi->getCmdUseDb(this->ddlDestDbName, this->m_rdbmsEn) << ddlGenDbi->endOfCmd()
                << ddlGenDbi->getCmdGo() << "\n";
            this->fileHelper->flush();
        }
    }
}

/************************************************************************
**
**  Function    :   DdlGenContext::getDbiConnPtrIfExists()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45830 - LJE - 220824
**
*************************************************************************/
DbiConnection* DdlGenContext::getDbiConnPtrIfExists(bool bForDdl)
{
    return this->hasDbiConn(bForDdl) ? (bForDdl ? &this->getDbiConnForDdl() : &this->getDbiConn()) : nullptr;
}

/************************************************************************
**
**  Function    :   DdlGenContext::getDbiConn()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 150624
**
*************************************************************************/
DbiConnection& DdlGenContext::getDbiConn()
{
    if (this->m_parentContext->m_extDbiConn != nullptr &&
        this->isMultiThreadMode() == false)
    {
        this->applyContext(false);

        return *this->m_parentContext->m_extDbiConn;
    }

    if (this->m_dbiConn == nullptr)
    {
        AAAConnectionDescription desc(SqlServer, DBI_GetSqlServerNameByRdbms(EV_SourceRdbmsVendor, false), ROLE_ADMIN, EV_SourceRdbmsVendor);

        if (EV_UseAlternativeDataSource &&
            EV_SourceContext != nullptr)
        {
            desc.setDatabase(EV_SourceContext->getMainDbName());
            desc.setUser(EV_SourceApplOwner);
        }

        this->m_dbiConn = DBA_GetDbiConnection(desc);

        if (this->m_dbiConn != nullptr)
        {
            if (this->bInTran)
            {
                if (RET_GET_LEVEL(this->m_dbiConn->beginTransaction()) == RET_LEV_ERROR)
                {
                    this->rollback();
                }
            }
        }

        if (this->m_dbiConn == nullptr)
        {
            throw AAACannotConnectException("Connection error for user " + desc.getUser() + " to server " + desc.getServerName(),
                                            desc,
                                            0);
        }
    }

    this->applyContext(false);

    /* PMSTA-45413 - LJE - 210617 */
    if (this->m_parentContext->m_ddlGenDbaAccessPtr != nullptr &&
        this->m_parentContext->m_ddlGenDbaAccessPtr->isLoaded(NullEntity))
    {
        this->m_dbiConn->setDdlGenDbaAccessPtr(this->m_parentContext->m_ddlGenDbaAccessPtr);
    }

    return (*this->m_dbiConn);
}

/************************************************************************
**
**  Function    :   DdlGenContext::getDbiConnForDdl()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 150624
**
*************************************************************************/
DbiConnection& DdlGenContext::getDbiConnForDdl()
{
    /* PMSTA-37366 - LJE - 210208 */
    if (this->m_parentContext->m_extDbiConn != nullptr && 
        this->isMultiThreadMode() == false)
    {
        this->applyContext(true);

        return *this->m_parentContext->m_extDbiConn;
    }

    /* PMSTA-37366 - LJE - 191004 */
    if (this->m_dbiConn != nullptr &&
        this->m_dbiConn->isDdlGenOnTran() == true &&
        EV_UseAlternativeDataSource == false)
    {
        this->m_dbiConnForDdl = this->m_dbiConn;
    }
    else if (this->m_dbiConnForDdl == nullptr)
    {
        /* PMSTA-37366 - LJE - 191224 - To use always the same connection */
        if (this->isMultiThreadMode() == false &&
            this->m_dbiConn == nullptr)
        {
            (void)this->getDbiConn();
        }

        if ((this->m_dbiConn != nullptr && this->m_dbiConn->isDdlGenOnTran() == false) ||
            this->isMultiThreadMode() ||
            EV_UseAlternativeDataSource == true)
        {
            AAAConnectionDescription desc(SqlServer, DBI_GetSqlServerNameByRdbms(EV_TargetRdbmsVendor, true), ROLE_ADMIN, EV_TargetRdbmsVendor);

            /* PMSTA-37366 - LJE - 191121 */
            if (EV_UseAlternativeDataSource == true)
            {
                desc.setUser(EV_TargetApplOwner);
            }

            this->m_dbiConnForDdl = DBA_GetDbiConnection(desc);
            if (this->m_dbiConnForDdl == nullptr)
            {
                throw AAACannotConnectException("Connection error for user " + desc.getUser() + " to server " + desc.getServerName(),
                                                desc,
                                                0);
            }
        }
        else
        {
            this->m_dbiConnForDdl = this->m_dbiConn;
        }
    }

    this->applyContext(true);

    return (*this->m_dbiConnForDdl);
}

/************************************************************************
**
**  Function    :   DdlGenContext::hasDbiConn()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 150624
**
*************************************************************************/
bool DdlGenContext::hasDbiConn(bool bForDdl)
{
    if (bForDdl)
    {
        if (this->m_dbiConnForDdl == nullptr)
        {
            return false;
        }
    }
    else
    {
        if (this->m_dbiConn == nullptr &&
            (this->m_parentContext->m_extDbiConn == nullptr || this->m_ddlGenContextForConn == nullptr || this->m_ddlGenContextForConn->m_bMultiThreadMode))
        {
            return false;
        }
    }

    return true;
}

/************************************************************************
**
**  Function    :   DdlGenContext::isInsertIdentityOn()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 150624
**
*************************************************************************/
bool DdlGenContext::isInsertIdentityOn()
{
    if (this->m_dbiConnForDdl == nullptr &&
        this->m_dbiConn       == nullptr &&
        this->m_parentContext->m_parentContext->m_extDbiConn    == nullptr)
    {
        return false;
    }

    if (this->m_dbiConnForDdl != nullptr)
    {
        return this->m_dbiConnForDdl->m_insertIdentityOn;
    }

    if (this->m_dbiConn != nullptr)
    {
        return this->m_dbiConn->m_insertIdentityOn;
    }

    if (this->m_parentContext->m_extDbiConn != nullptr)
    {
        return this->m_parentContext->m_extDbiConn->m_insertIdentityOn;
    }
    return true;
}

/************************************************************************
**
**  Function    :   DdlGenContext::checkTargetDbConnection()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-34344 - LJE - 201112
**
*************************************************************************/
bool DdlGenContext::checkSourceDbConnection()
{
    try
    {
        this->mainDbSqlName.clear();

        auto& dbiConn = this->getDbiConn();

        CURRENTCHARSETCODE_ENUM currentCharsetCode = CurrentCharsetCode_IsNull;
        GEN_GetApplInfo(ApplCurrentCharsetCodeEnum, &currentCharsetCode);

        if (this->m_parentContext == this)
        {
            std::string defaultCharset = dbiConn.getDefaultCharset();
            GEN_SetCurCharset(defaultCharset.c_str(), CharsetCodeType_Rdbms, CharsetCodeNoCtx, dbiConn.getDbaRDBMS());
            GEN_GetApplInfo(ApplCurrentCharsetCodeEnum, &this->m_sourceCharSetEn);
        }
        else
        {
            this->m_sourceCharSetEn = this->m_parentContext->m_sourceCharSetEn;
        }

        if (currentCharsetCode != this->m_sourceCharSetEn)
        {
            if (migrationMode != DdlGenContext::MigrationMode::None)
            {
                GEN_SetApplInfo(ApplCurrentCharsetCodeEnum, &currentCharsetCode);
            }

            if (this->m_sourceCharSetEn != dbiConn.getCurrCharsetEn())
            {
                dbiConn.endTransaction(TRUE);
                dbiConn.setCurrCharsetEn(this->m_sourceCharSetEn);
                dbiConn.setDbCommCharsetEn(this->m_sourceCharSetEn);
            }
        }

        dbiConn.reconnect(); /* Refresh connection all times to avoid errors dues to disconnection after long time insertion... */

        if (dbiConn.isValid() == true &&
            this->m_sourceCharSetEn != CurrentCharsetCode_IsNull)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    catch (std::exception e)
    {
        this->printMsg(RET_DBA_ERR_CANNOTCONNECT, e.what());
    }

    return false;
}

/************************************************************************
**
**  Function    :   DdlGenContext::cleanDbiConnMsg()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37366 - LJE - 200619
**
*************************************************************************/
void DdlGenContext::cleanDbiConnMsg()
{
    if (this->m_dbiConn != nullptr)
    {
        this->m_dbiConn->clearMsg();
    }
    if (this->m_dbiConnForDdl != nullptr)
    {
        this->m_dbiConnForDdl->clearMsg();
    }
    if (this->m_parentContext->m_extDbiConn != nullptr)
    {
        this->m_parentContext->m_extDbiConn->clearMsg();
    }
}

/************************************************************************
**
**  Function    :   DdlGenContext::getRequestHelper()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210707
**
*************************************************************************/
DdlGenRequestHelper* DdlGenContext::getRequestHelper()
{
    return this->m_parentContext->m_requestHelper;
}

/************************************************************************
**
**  Function    :   DdlGenContext::startBatchMulti()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210707
**
*************************************************************************/
void DdlGenContext::startBatchMulti()
{
    this->m_parentContext->m_requestHelper = new DdlGenRequestHelper(&this->getDbiConn(), *this);

    if (this->ddlGenAction.m_bUseNativeQuery ||
        this->m_rdbmsEn == PostgreSQL)
    {
        this->m_parentContext->m_requestHelper->useNativeQueryForBatch();
    }
}

/************************************************************************
**
**  Function    :   DdlGenContext::finishBatchMulti()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210707
**
*************************************************************************/
RET_CODE DdlGenContext::finishBatchMulti()
{
    RET_CODE  ret = RET_SUCCEED;

    if (this->m_parentContext->m_requestHelper != nullptr)
    {
        ret = this->m_parentContext->m_requestHelper->executeBatchMulti(false);
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenContext::closeBatchMulti()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210707
**
*************************************************************************/
void DdlGenContext::closeBatchMulti()
{
    if (this->m_parentContext->m_requestHelper != nullptr)
    {
        delete this->m_parentContext->m_requestHelper;
        this->m_parentContext->m_requestHelper = nullptr;
    }
}

/************************************************************************
**
**  Function    :   DdlGenContext::setExtDbiConn()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37366 - LJE - 210208
**
*************************************************************************/
void DdlGenContext::setExtDbiConn(DbiConnection *extDbiConn)
{
    if (this->m_parentContext->m_extDbiConn != extDbiConn)
    {
        if (extDbiConn != nullptr)
        {
            this->m_ddlGenDbaAccessPtr = extDbiConn->getDdlGenDbaAccessPtr();
        }
        this->m_parentContext->m_extDbiConn = extDbiConn;
    }
}

/************************************************************************
**
**  Function    :   DdlGenContext::initConnection()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 150624
**
*************************************************************************/
RET_CODE DdlGenContext::initConnection(DdlGenFile *paramFileHelper, bool paramBInTran)
{
    RET_CODE ret = RET_SUCCEED;

    if (this->hasDbiConn(false) &&
        this->getDbiConn().isInTransaction() == true)
    {
        this->printMsg(RET_DBA_INFO_EXIST, "Initializing connection on active transaction, rollback is done!!!");
        this->ddlGenContextPtr->rollback();
        /* Get new connection */
        (void)this->getDbiConn();
    }

    this->bInTran    = paramBInTran;

    if (this->bWriteFile)
    {
        this->fileHelper = paramFileHelper;
    }
    else
    {
        this->fileHelper = nullptr;
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenContext::finishConnection()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 150624
**
*************************************************************************/
RET_CODE DdlGenContext::endConnection()
{
    RET_CODE ret = RET_SUCCEED;

    if (this->m_dbiConnForDdl == this->m_dbiConn)
    {
        this->currUser.clear();
        this->m_dbiConnForDdl = nullptr;
    }

    if (this->m_dbiConn != nullptr)
    {
        if (this->bInTran)
        {
            this->printMsg(RET_DBA_INFO_EXIST, "End connection with active transaction, rollback is done!!!");
            this->m_dbiConn->endTransaction(FALSE);
            this->bInTran = false;
        }

        ret = DBA_EndConnection(&(this->m_dbiConn), false);
    }

    if (this->m_dbiConnForDdl != nullptr)
    {
        this->currUser.clear();
        ret = DBA_EndConnection(&(this->m_dbiConnForDdl), false);
    }

    if (this->m_parentContext->m_extDbiConn != nullptr &&
        this->m_parentContext->m_extDbiConn->getDdlGenDbaAccessPtr() == nullptr)
    {
        this->m_parentContext->m_extDbiConn = nullptr;
    }
    this->fileHelper = nullptr;

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenContext::commit()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 120106
**
*************************************************************************/
RET_CODE DdlGenContext::commit()
{
    RET_CODE ret = RET_SUCCEED;
    if (this->bInTran && this->m_dbiConn != nullptr)
    {
        ret = this->m_dbiConn->endTransaction(TRUE);
    }
    this->bInTran = false;

    if (this->m_dbiConnForDdl != nullptr &&
        this->m_dbiConnForDdl != this->m_dbiConn &&
        this->m_dbiConnForDdl->isInTransaction())
    {
        ret = this->m_dbiConnForDdl->endTransaction(TRUE);
    }

    this->endConnection();
    return (ret);
}

/************************************************************************
**
**  Function    :   DdlGenContext::rollback()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 120106
**
*************************************************************************/
RET_CODE DdlGenContext::rollback()
{
    RET_CODE ret = RET_SUCCEED;
    if (this->bInTran && this->m_dbiConn != nullptr)
    {
        ret = this->m_dbiConn->endTransaction(FALSE);
        this->bInTran = false;
    }

    if (this->m_dbiConnForDdl != nullptr &&
        this->m_dbiConnForDdl != this->m_dbiConn &&
        this->m_dbiConnForDdl->isInTransaction())
    {
        ret = this->m_dbiConnForDdl->endTransaction(FALSE);
    }

    this->endConnection();
    return (ret);
}


/************************************************************************
**
**  Function    :   DdlGenContext::setDdlGenMode()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26250 - LJE - 170327
**
*************************************************************************/
void DdlGenContext::setDdlGenMode(DDL_GEN_MODE_ENUM ddlGenMode)
{
    if (ddlGenMode == DdlGenMode_Shadow)
    {
        this->iCursorCpt = 0;
    }

    this->m_ddlGenMode = ddlGenMode;
}

/************************************************************************
**
**  Function    :   DdlGenContext::getDdlGenMode()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26250 - LJE - 170327
**
*************************************************************************/
DDL_GEN_MODE_ENUM DdlGenContext::getDdlGenMode()
{
    return this->m_ddlGenMode;
}

/************************************************************************
**
**  Function    :   DdlGenContext::getMaxDbLenRule()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-47414 - LJE - 220119
**
*************************************************************************/
DdlGenContext::MaxDbLenCreationRule DdlGenContext::getMaxDbLenRule()
{
    if (this->m_parentContext != this)
    {
        return this->m_parentContext->getMaxDbLenRule();
    }

    if (this->m_bLightContext)
    {
        return DdlGenContext::MaxDbLenCreationRule::AlwaysDataType;
    }

    if (this->m_maxDbLenRule == DdlGenContext::MaxDbLenCreationRule::None)
    {
        this->m_maxDbLenRule = static_cast<DdlGenContext::MaxDbLenCreationRule>(this->getCfgFileHelper().getPropertyUnsignedOrDefValue("MAX_DB_LEN_RULE", 0));
    }

    return this->m_maxDbLenRule;
}

/************************************************************************
**
**  Function    :   DdlGenContext::getDdlGenModeStr()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26250 - LJE - 170327
**
*************************************************************************/
std::string DdlGenContext::getDdlGenModeStr()
{
    switch (this->getDdlGenMode())
    {
        case DdlGenMode_Shadow:
            return "Shadow";
            break;

        case DdlGenMode_MultiEntity:
            return "Multi-Entity";
            break;

        case DdlGenMode_Standard:
        default:
            return "Standard";
            break;
    }
}

/************************************************************************
**
**  Function    :   DdlGenContext::getMultiEntityLevel()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26108 - LJE - 170811
**
*************************************************************************/
MULTI_ENTITY_LEVEL_ENUM DdlGenContext::getMultiEntityLevel()
{
    if (this->m_parentContext != nullptr &&
        this->m_parentContext != this)
    {
        return this->m_parentContext->getMultiEntityLevel();
    }

    if (this->ddlGenAction.m_installLevel >= 9 ||
        this->bGenFromDbi ||
        this->ddlGenContextPtr->bAvoidMultiEntity == true ||
        this->getMasterBusinessEntityCd().compare("NONE") == 0)
    {
        if (this->m_bHaveMultiEntityCateg &&
            (this->ddlGenAction.m_paramEntitySqlnameStr == "init" || 
             this->migrationMode != MigrationMode::None)  &&
            this->cfgFileHelper.getProperty("MASTER_BUSINESS_ENTITY") != "NONE")
        {
            SV_MultitEntityLevel = MultiEntityLevel_Active;
            SV_MasterBusinessEntityCd = this->cfgFileHelper.getProperty("MASTER_BUSINESS_ENTITY");
            SV_MasterBusinessEntityId = "1";

            return SV_MultitEntityLevel;
        }
        return MultiEntityLevel_None;
    }
    else
    {
        return SV_MultitEntityLevel;
    }
}


/************************************************************************
**
**  Function    :   DdlGenContext::getMultiEntityLevel()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26108 - LJE - 170811
**
*************************************************************************/
bool DdlGenContext::isEntityMtmFirstLevel(DICT_T entityDictId)
{
    if (this->m_parentContext != nullptr &&
        this->m_parentContext != this)
    {
        return this->m_parentContext->isEntityMtmFirstLevel(entityDictId);
    }

    if (this->m_entityMtmFirstLevel.empty())
    {
        this->m_entityMtmFirstLevel.insert(InvalidEntity);

        DdlGenEntity *meDataOrgaPtr = nullptr;
        std::string   realSqlName;

        if (this->ddlGenAction.m_installLevel < 9 &&
            (meDataOrgaPtr = this->getDdlGenEntityPtr("me_data_orga")) != nullptr &&
            meDataOrgaPtr->getSysXdEntityStp(realSqlName) != nullptr)
        {
            DdlGenDbi ddlGenDbi(DdlObj_Sql, *this, nullptr, nullptr, TargetTable_Main);

            std::string request("select distinct entity_dict_id "
                           "from me_data_orga "
                           "where data_scope_e = 0 "
                           "and status_e = 2 "
                           "and build_date_d is not null");

            if (this->getMultiEntityLevel() != MultiEntityLevel_Active)
            {
                request += " and action_e = 2";
            }

            ddlGenDbi.getIdFromRequest(request, this->m_entityMtmFirstLevel, true);
        }
    }

    if (this->m_entityMtmFirstLevel.size() == 1) /* Not managed by me_data_orga */
    {
        return true;
    }

    return (this->m_entityMtmFirstLevel.find(entityDictId) != this->m_entityMtmFirstLevel.end());
}


/************************************************************************
**
**  Function    :   DdlGenContext::getMasterBusinessEntityCd()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
const std::string& DdlGenContext::getMasterBusinessEntityCd(DbiConnection* dbiConnPtr)
{
    static bool masterBusinessEntityLoaded = false;

    if (masterBusinessEntityLoaded == false)
    {
        masterBusinessEntityLoaded = true;

        if (GEN_IsMultiEntity() == false)
        {
            if (this->ddlGenAction.m_installLevel > 0)
            {
                DdlGenEntity* businessEntityPtr = nullptr;
                DdlGenContext ddlGenContext(*this);

                std::string realSqlName;
                if (this->ddlGenAction.m_installLevel >= 9 ||              /* PMSTA-32665 - LJE - 180830 */
                    (businessEntityPtr = ddlGenContext.getDdlGenEntityPtr("business_entity")) == nullptr ||
                    businessEntityPtr->getSysXdEntityStp(realSqlName) == nullptr ||
                    businessEntityPtr->getSysXdAttribStp(TargetTable_Main, "multi_entity_role_e") == nullptr)
                {
                    SV_MultitEntityLevel      = MultiEntityLevel_None;
                    SV_MasterBusinessEntityCd = "NONE";
                }
                else
                {
                    DdlGenDbi ddlGenDbi(DdlObj_Sql, *this, nullptr, nullptr, TargetTable_Main);
                    ddlGenDbi.getMasterBusinessEntityInfo((dbiConnPtr == nullptr ? &this->getDbiConn() : dbiConnPtr));

                    if (EV_MasterBusinessEntity.empty())
                    {
                        SV_MultitEntityLevel      = MultiEntityLevel_None;
                        SV_MasterBusinessEntityCd = "NONE";
                    }
                    else
                    {
                        std::stringstream mbeStream;
                        mbeStream << EV_MasterBusinessEntityId;

                        SV_MasterBusinessEntityId = mbeStream.str();

                        SV_MultitEntityLevel      = MultiEntityLevel_Active;
                        SV_MasterBusinessEntityCd = EV_MasterBusinessEntity;
                    }
                }

                if (SV_MultitEntityLevel == MultiEntityLevel_Active)
                {
                    std::string cfgMasterBusinessEntity = this->cfgFileHelper.getProperty("MASTER_BUSINESS_ENTITY");
                    if (cfgMasterBusinessEntity.empty() || cfgMasterBusinessEntity[0] == '$' || cfgMasterBusinessEntity.compare("NONE") == 0)
                    {
                        SV_MultitEntityLevel = MultiEntityLevel_NoActive;
                    }
                    else if (SV_MasterBusinessEntityCd.compare(cfgMasterBusinessEntity) != 0 && cfgMasterBusinessEntity.compare("YES") != 0)
                    {
                        this->printMsg(RET_DBA_ERR_INVDATA, "The master business entity defined in the file aaa_install.cfg (" +
                                       SV_MasterBusinessEntityCd +
                                       ") is not the real master (" +
                                       cfgMasterBusinessEntity +
                                       "), the multi-entity behavior is unactivated !");

                        SV_MultitEntityLevel      = MultiEntityLevel_None;
                        SV_MasterBusinessEntityCd = "NONE";
                        SV_MasterBusinessEntityId = "";
                    }
                }
            }
            else
            {
                SV_MultitEntityLevel      = MultiEntityLevel_None;
                SV_MasterBusinessEntityId = "";
                SV_MasterBusinessEntityCd = "NONE";
            }
        }
        else
        {
            std::stringstream mbeStream;
            mbeStream << EV_MasterBusinessEntityId;

            SV_MasterBusinessEntityId = mbeStream.str();
            SV_MasterBusinessEntityCd = EV_MasterBusinessEntity;
            SV_MultitEntityLevel      = MultiEntityLevel_Active;
        }
    }
    return SV_MasterBusinessEntityCd;
}

/************************************************************************
**
**  Function    :   DdlGenContext::getMasterBusinessEntityId()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
const std::string &DdlGenContext::getMasterBusinessEntityId()
{
    if (this->m_parentContext != nullptr &&
        this->m_parentContext != this)
    {
        return this->m_parentContext->getMasterBusinessEntityId();
    }

    if (SV_MasterBusinessEntityId.empty())
    {
        this->getMasterBusinessEntityCd();
    }

    return SV_MasterBusinessEntityId;
}

/************************************************************************
**
**  Function    :   DdlGenContext::getDependsDictEntityMap()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-28698 - LJE - 180709
**
*************************************************************************/
void DdlGenContext::getDependsDictEntityMap(const std::string &ddlObjectSqlName, std::map<std::string, DICT_ENTITY_STP> &depDictEntityMap)
{
    auto validObjIt = this->m_validDdlObjMap.find(DdlObjDefKey(this->m_rdbmsEn, 
                                                               DdlObj_Table, 
                                                               this->getMainDbName(), 
                                                               ddlObjectSqlName,
                                                               ddlObjectSqlName,
                                                               ddlObjectSqlName));
    if (validObjIt != this->m_validDdlObjMap.end())
    {
        for (auto it = validObjIt->second.m_dependsEntityMap.begin(); it != validObjIt->second.m_dependsEntityMap.end(); ++it)
        {
            depDictEntityMap.insert(std::make_pair(it->first, it->second));
        }
    }
    else if (this->ddlGenAction.m_installLevel < 5)
    {
        DdlGenConnGuard     ddlGenConnGuard(*this);
        DbiConnectionHelper dbiConnHelper(&ddlGenConnGuard.getDbiConn(), false);
        MemoryPool          mp;
        DBA_DYNFLD_STP      shDictDepends = mp.allocDynst(FILEINFO, S_DictDepends);
        DBA_DYNFLD_STP     *allDictDependsTab = nullptr;
        int                 allDictDependsNbr = 0;

        SET_SYSNAME(shDictDepends, S_DictDepends_SqlName, ddlObjectSqlName.c_str());
        dbiConnHelper.dbaSelect(DictDepends, UNUSED, shDictDepends, A_DictDepends, &allDictDependsTab, &allDictDependsNbr);

        for (int i = 0; i < allDictDependsNbr; ++i)
        {
            DICT_ENTITY_STP depDictEntityStp = DBA_GetEntityBySqlName(GET_SYSNAME(allDictDependsTab[i], A_DictDepends_DepSqlName));

            if (depDictEntityStp)
            {
                depDictEntityMap.insert(std::make_pair(depDictEntityStp->mdSqlName, depDictEntityStp));
            }
        }
        this->m_mp.ownerDynStpTab(allDictDependsTab, allDictDependsNbr);
    }
}


/************************************************************************
**
**  Function    :   DdlGen::resetStoredProcInfo()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-nuodb - LJE - 190814
**
*************************************************************************/
void DdlGenContext::resetStoredProcInfo(DICT_T entity_dict_id)
{
    if (this->m_shDictSporcStp == nullptr)
    {
        this->m_shDictSporcStp = this->m_mp.allocDynst(FILEINFO, S_DictSproc);
    }

    DdlGenConnGuard     ddlGenConnGuard(*this);
    DbiConnectionHelper dbiConnHelper(&ddlGenConnGuard.getDbiConn(), false);

    if (entity_dict_id != 0)
    {
        SET_DICT(this->m_shDictSporcStp, S_DictSproc_EntityDictId, entity_dict_id);
    }
    else
    {
        SET_NULL_DICT(this->m_shDictSporcStp, S_DictSproc_EntityDictId);
    }

    dbiConnHelper.dbaUpdate(DictSproc, DBA_ROLE_UDT, this->m_shDictSporcStp);

}


/************************************************************************
**
**  Function    :   DdlGen::getStoredProcInfo()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-nuodb - LJE - 190814
**
*************************************************************************/
bool DdlGenContext::getStoredProcInfo(const std::string &sprocSqlName, DictSprocClass *&dictSprocStp, const std::string &dbSqlName)
{
    bool bFound = false;

    dictSprocStp = nullptr;

    std::string searchDbSqlName = dbSqlName;
    if (searchDbSqlName.empty())
    {
        searchDbSqlName = this->getDdlDestDbName();
    }

    auto objDefIt = this->m_validDdlObjMap.find(DdlObjDefKey(this->m_rdbmsEn, 
                                                             DdlObj_SProc, 
                                                             searchDbSqlName,
                                                             std::string(),
                                                             std::string(),
                                                             sprocSqlName));
    if (objDefIt == this->m_validDdlObjMap.end())
    {
        this->readLock();

        objDefIt = this->m_parentContext->m_validDdlObjMap.find(DdlObjDefKey(this->m_rdbmsEn, 
                                                                             DdlObj_SProc,
                                                                             searchDbSqlName,
                                                                             std::string(),
                                                                             std::string(),
                                                                             sprocSqlName));
        if (objDefIt != this->m_parentContext->m_validDdlObjMap.end())
        {
            bFound = true;
            dictSprocStp = &objDefIt->second.m_dictSprocSt;
        }

        this->readUnlock();
    }
    else
    {
        bFound = true;
        dictSprocStp = &objDefIt->second.m_dictSprocSt;
    }

    if (dictSprocStp == nullptr && strcasecmp(sprocSqlName.c_str(), this->m_dictSprocSt.sqlName.c_str()) == 0)
    {
        bFound = true;
        dictSprocStp = &this->m_dictSprocSt;
    }

    if (dictSprocStp == nullptr && 
        this->ddlGenContextPtr->ddlGenAction.m_installLevel < 5)
    {
        DdlObjDefKey searchSproc(this->m_rdbmsEn, DdlObj_SProc, searchDbSqlName, std::string(), std::string(), sprocSqlName);

        auto dictSprocIt = this->m_dictSprocMap.find(searchSproc);

        if (dictSprocIt == this->m_dictSprocMap.end())
        {
            DictSprocClass &dictSprocSt = this->m_dictSprocMap[searchSproc];

            DdlGenConnGuard     ddlGenConnGuard(*this);
            DbiConnectionHelper   dbiConnHelper(&ddlGenConnGuard.getDbiConn(), false);
            DBA_DYNFLD_STP       *data[] = { NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR };
            int                   rows[] = { 0, 0, 0 };

            DBA_DYNFLD_STP sSprocStp = ALLOC_DYNST(S_DictSproc);

            SET_SYSNAME(sSprocStp, S_DictSproc_SqlName, searchSproc.getObjName().c_str());
            SET_SYSNAME(sSprocStp, S_DictSproc_Database, searchSproc.getDbDbName().c_str());

            if (dbiConnHelper.dbaMultiSelect(DictSproc, UNUSED, sSprocStp, data, rows) == RET_SUCCEED)
            {
                if (rows[0] == 1)
                {
                    bFound = true;

                    dictSprocSt.sqlName         = GET_SYSNAME(data[0][0], A_DictSproc_SqlName);
                    dictSprocSt.dbName          = GET_SYSNAME(data[0][0], A_DictSproc_Database);
                    dictSprocSt.procActionEn    = static_cast<DBA_ACTION_ENUM>(GET_ENUM(data[0][0], A_DictSproc_ActionEn));
                    dictSprocSt.procAccessEn    = static_cast<DBA_PROC_ACCESS_ENUM>(GET_ENUM(data[0][0], A_DictSproc_AccessEn));
                    dictSprocSt.setObjectEn(DBA_GetObjectEnum(GET_DICT(data[0][0], A_DictSproc_EntityDictId)));
                    dictSprocSt.inputObjectEn   = DBA_GetObjectEnum(GET_DICT(data[0][0], A_DictSproc_InputEntityDictId));
                    dictSprocSt.outputObjectEn  = DBA_GetObjectEnum(GET_DICT(data[0][0], A_DictSproc_OutputEntityDictId));
                    dictSprocSt.outputDynTypeEn = static_cast<DBA_DYNTYPE_ENUM>GET_ENUM(data[0][0], A_DictSproc_OutputDynTypeEn);
                    
                    dictSprocSt.m_paramProcAttribVector.resize(rows[1]);

                    for (int i = 0; i < rows[1]; i++)
                    {
                        DictSprocParamClass &dictSprocParamIt = dictSprocSt.m_paramProcAttribVector[GET_SMALLINT(data[1][i], A_DictSprocParam_Rank)];

                        dictSprocParamIt.m_sqlName       = GET_SYSNAME(data[1][i], A_DictSprocParam_SqlName);
                        dictSprocParamIt.defaultValueC = (IS_NULLFLD(data[1][i], A_DictSprocParam_Default) == TRUE ? "null" : GET_NAME(data[1][i], A_DictSprocParam_Default));
                        dictSprocParamIt.rank          = GET_SMALLINT(data[1][i], A_DictSprocParam_Rank);
                        dictSprocParamIt.inputFlg      = GET_FLAG(data[1][i], A_DictSprocParam_InputFlg);
                        dictSprocParamIt.outputFlg     = GET_FLAG(data[1][i], A_DictSprocParam_OutputFlg);

                        dictSprocParamIt.setDataType(GET_DICT(data[1][i], A_DictSprocParam_DataTpDictId));
                    }

                    for (int i = 0; i < rows[2]; i++)
                    {
                        std::list<DdlSelectElt> selectList;
                        dictSprocSt.m_dictSprocReturnsVector.push_back(DictSprocReturnsClass(GET_SYSNAME(data[2][i], A_DictSprocReturns_SqlName),
                                                                                             selectList,
                                                                                             GET_SMALLINT(data[2][i], A_DictSprocReturns_Rank),
                                                                                             static_cast<DBA_DYNTYPE_ENUM>(GET_ENUM(data[2][i], A_DictSprocReturns_DynNatEn)),
                                                                                             NullDynSt));

                        if (IS_NULLFLD(data[2][i], A_DictSprocReturns_SelectListT) == FALSE)
                        {
                            dictSprocSt.m_dictSprocReturnsVector.back().m_selectListStr = GET_TEXT(data[2][i], A_DictSprocReturns_SelectListT);
                        }
                    }

                    DBA_FreeDynStTab(data[0], rows[0], A_DictSproc);
                    DBA_FreeDynStTab(data[1], rows[1], A_DictSprocParam);
                    DBA_FreeDynStTab(data[2], rows[2], A_DictSprocReturns);
                }
            }

            FREE_DYNST(sSprocStp, S_DictSproc);

            dictSprocStp = &dictSprocSt;
        }
        else
        {
            dictSprocStp = &dictSprocIt->second;

            if (dictSprocStp->sqlName.empty() == false)
            {
                bFound = true;
            }
        }
    }

    if (bFound == false && dbSqlName.empty())
    {
        if (strcasecmp(searchDbSqlName.c_str(), this->getMainDbName().c_str()) == 0)
        {
            searchDbSqlName = this->getLoginDbName();
        }
        else
        {
            searchDbSqlName = this->getMainDbName();
        }
        return getStoredProcInfo(sprocSqlName, dictSprocStp, searchDbSqlName);
    }

    if (bFound)
    {
        return true;
    }

    if (sprocSqlName[0] != '@') /* Don't check Sybase dynamic SQL calls */
    {
        this->m_bHasUnknownCall = true;

        if (this->getDdlObjEn() != DdlObj_Sql &&
            this->ddlGenContextPtr->ddlGenAction.m_installLevel < 5)
        {
            this->printMsg(RET_DBA_ERR_PROCNOTFOUND, "Unknown stored procedure call: " + sprocSqlName);
        }
    }

    return false;
}


/************************************************************************
**
**  Function    :   DdlGen::saveStoredProcInfo()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-nuodb - LJE - 190814
**
*************************************************************************/
RET_CODE DdlGenContext::saveStoredProcInfo(bool bBatchMode)
{
    if (this->ddlGenAction.m_installLevel > 5 ||
        this->ddlGenContextPtr->bGenFromDbi == true)
    {
        /* Nothing to do */
        return RET_SUCCEED;
    }

    std::string                 currProcessStr = std::string("Saving");
    DdlGenMsg              ddlGenMsg(this);

    ddlGenMsg.setMsgObjType("Stored Proc. Info.");

    ddlGenMsg.printMsg(RET_SRV_INFO_RUNNING, currProcessStr);

    DdlGenConnGuard     ddlGenConnGuard(*this);
    DbiConnectionHelper dbiConnHelper(&ddlGenConnGuard.getDbiConn(), false);
    DdlGenRequestHelper requestHelper(dbiConnHelper, *this);

    if (bBatchMode == false)
    {
        requestHelper.setTransactionMode(RequestHelper::TransactionMode::MostAsPossible);
        requestHelper.setBatchMode(DbiConnection::BatchMode::RowByRow);
    }

    if (this->getDdlGenDbaAccess().isLoaded(NullEntity) == false)
    {
        dbiConnHelper.beginTransaction();
    }

    std::vector<DBA_DYNFLD_STP>       newSprocVector;
    MemoryPool                        mp;

    for (auto ddlObjIt = this->m_validDdlObjMap.begin(); ddlObjIt != this->m_validDdlObjMap.end(); ++ddlObjIt)
    {
        if (ddlObjIt->second.m_bSaved)
        {
            continue;
        }

        DICT_ENTITY_STP dictEntityStp = DBA_GetEntityBySqlName(ddlObjIt->second.getEntitySqlName());
        DBA_DYNFLD_STP  tstDictSprocStp = mp.allocDynst(FILEINFO, S_DictSproc);

        if (ddlObjIt->second.getDdlObjEn() == DdlObj_SProc ||
            ddlObjIt->second.getDdlObjEn() == DdlObj_SpecSProc ||
            ddlObjIt->second.getDdlObjEn() == DdlObj_Func)
        {
            if (dictEntityStp == nullptr)
            {
                this->printMsg(RET_DBA_ERR_INVDATA, "Unknown entity: " + ddlObjIt->second.getEntitySqlName() + " for procedure/function: " + ddlObjIt->second.getObjName());
                continue;
            }

            std::string               objName = ddlObjIt->second.getObjName();
            std::string                dbName = ddlObjIt->second.getDbName();
            std::string               objType = DdlGenDbi::getStdDdlObjType(ddlObjIt->second.getDdlObjEn());
            std::string            depObjType = DdlGenDbi::getStdDdlObjType(DdlObj_Table);

            SET_DICT(tstDictSprocStp, S_DictSproc_EntityDictId, dictEntityStp->entDictId);
            SET_SYSNAME(tstDictSprocStp, S_DictSproc_SqlName, objName.c_str());
            SET_SYSNAME(tstDictSprocStp, S_DictSproc_Database, dbName.c_str());

            DBA_DYNFLD_STP aDictSprocStp = nullptr;
            if (requestHelper.dbaGet(DictSproc, UNUSED, tstDictSprocStp, aDictSprocStp) != RET_SUCCEED ||
                aDictSprocStp == nullptr)
            {
                aDictSprocStp = requestHelper.allocDynSt(FILEINFO, A_DictSproc);

                SET_DICT(aDictSprocStp, A_DictSproc_EntityDictId, dictEntityStp->entDictId);
                SET_SYSNAME(aDictSprocStp, A_DictSproc_SqlName, objName.c_str());
                SET_SYSNAME(aDictSprocStp, A_DictSproc_Database, dbName.c_str());
            }
            newSprocVector.push_back(aDictSprocStp);

            SET_DICT(aDictSprocStp, A_DictSproc_InputEntityDictId, dictEntityStp->entDictId);
            SET_DICT(aDictSprocStp, A_DictSproc_OutputEntityDictId, dictEntityStp->entDictId);

            SET_ENUM(aDictSprocStp, A_DictSproc_ActionEn, ddlObjIt->second.m_dictSprocSt.procActionEn);

            SET_ENUM(aDictSprocStp, A_DictSproc_AccessEn, DictSprocAccessEn::None);
            SET_ENUM(aDictSprocStp, A_DictSproc_InputDynTypeEn, 0);
            SET_ENUM(aDictSprocStp, A_DictSproc_OutputDynTypeEn, 0);

            SET_A_DictSproc_XdActionEn(aDictSprocStp, XdEntityXdActionEn::None);
            SET_A_DictSproc_XdStatusEn(aDictSprocStp, XdEntityXdStatusEn::Inserted);

            if (IS_NULLFLD(aDictSprocStp, A_DictSproc_DictId) == TRUE)
            {
                SET_DATETIME(aDictSprocStp, A_DictSproc_LastBuildDate, this->getBuildDate());

                requestHelper.dbaCall(Insert,
                                      DictSproc,
                                      DBA_ROLE_UDT,
                                      aDictSprocStp,
                                      10);
            }
            else
            {
                if (ddlObjIt->second.m_bSendIntoDb)
                {
                    SET_DATETIME(aDictSprocStp, A_DictSproc_LastBuildDate, this->getBuildDate());
                }

                requestHelper.dbaCall(Update,
                                      DictSproc,
                                      DBA_ROLE_UDT,
                                      aDictSprocStp,
                                      10);
                requestHelper.dbaCall(Delete,
                                      DictSprocParam,
                                      UNUSED,
                                      aDictSprocStp,
                                      11);
                requestHelper.dbaCall(Delete,
                                      DictSprocReturns,
                                      UNUSED,
                                      aDictSprocStp,
                                      12);
            }

            for (auto paramIt = ddlObjIt->second.m_dictSprocSt.m_paramProcAttribVector.begin(); paramIt != ddlObjIt->second.m_dictSprocSt.m_paramProcAttribVector.end(); ++paramIt)
            {
                DBA_DYNFLD_STP   aDictSprocParamStp = requestHelper.allocDynSt(FILEINFO, A_DictSprocParam);

                SET_DICT(aDictSprocParamStp, A_DictSprocParam_SprocDictId, GET_DICT(aDictSprocStp, A_DictSproc_DictId));
                SET_SMALLINT(aDictSprocParamStp, A_DictSprocParam_Rank, paramIt->rank);
                SET_FLAG(aDictSprocParamStp, A_DictSprocParam_InputFlg, paramIt->inputFlg);
                SET_FLAG(aDictSprocParamStp, A_DictSprocParam_OutputFlg, paramIt->outputFlg);
                SET_FLAG_TRUE(aDictSprocParamStp, A_DictSprocParam_MandatoryFlg);
                SET_SYSNAME(aDictSprocParamStp, A_DictSprocParam_SqlName, paramIt->m_sqlName.c_str());
                SET_NAME(aDictSprocParamStp, A_DictSprocParam_Default, paramIt->defaultValueC.c_str());
                SET_DICT(aDictSprocParamStp, A_DictSprocParam_DataTpDictId, paramIt->getDataTypeDictId());

                requestHelper.dbaCall(Insert,
                                      DictSprocParam,
                                      UNUSED,
                                      aDictSprocParamStp,
                                      20,
                                      aDictSprocStp);
            }

            for (auto returnsIt = ddlObjIt->second.m_dictSprocSt.m_dictSprocReturnsVector.begin(); returnsIt != ddlObjIt->second.m_dictSprocSt.m_dictSprocReturnsVector.end(); ++returnsIt)
            {
                DBA_DYNFLD_STP   aDictSprocReturnsStp = requestHelper.allocDynSt(FILEINFO, A_DictSprocReturns);

                SET_DICT(aDictSprocReturnsStp, A_DictSprocReturns_SprocDictId, GET_DICT(aDictSprocStp, A_DictSproc_DictId));
                SET_SYSNAME(aDictSprocReturnsStp, A_DictSprocReturns_SqlName, returnsIt->m_returnsSqlName.c_str());
                SET_SMALLINT(aDictSprocReturnsStp, A_DictSprocReturns_Rank, static_cast<SMALLINT_T>(returnsIt->m_pos));
                SET_TEXT(aDictSprocReturnsStp, A_DictSprocReturns_SelectListT, returnsIt->m_selectListStr.c_str());

                OBJECT_ENUM       objEn       = GET_OBJ_DYNST(returnsIt->m_dynStEn);
                DBA_DYNTYPE_ENUM  dynStTypeEn = DynType_Other;

                if (objEn != NullEntity)
                {
                    auto retDictEntityStp = DBA_GetDictEntitySt(objEn);
                    if (retDictEntityStp != nullptr)
                    {
                        SET_SYSNAME(aDictSprocReturnsStp, A_DictSprocReturns_EntitySqlName, retDictEntityStp->mdSqlName);
                    }

                    if (GET_EDITGUIST(objEn) == returnsIt->m_dynStEn)
                    {
                        dynStTypeEn = DynType_All;
                    }
                    else
                    {
                        dynStTypeEn = DynType_Short;
                    }
                }
                SET_ENUM(aDictSprocReturnsStp, A_DictSprocReturns_DynNatEn, dynStTypeEn);

                requestHelper.dbaCall(Insert,
                                      DictSprocReturns,
                                      UNUSED,
                                      aDictSprocReturnsStp,
                                      21,
                                      aDictSprocStp);
            }
        }
    }

    if (this->getDdlGenDbaAccess().isLoaded(NullEntity) == false)
    {
        (void)requestHelper.executeBatchMulti();

        if (RET_GET_LEVEL(requestHelper.getLastRetCode()) != RET_LEV_ERROR)
        {
            for (auto ddlObjIt = this->m_validDdlObjMap.begin(); ddlObjIt != this->m_validDdlObjMap.end(); ++ddlObjIt)
            {
                if (ddlObjIt->second.m_bSaved)
                {
                    continue;
                }
                ddlObjIt->second.m_bSaved = true;
            }

            dbiConnHelper.commit();
            ddlGenMsg.printMsg(RET_SUCCEED, currProcessStr.append(" done!"));
        }
        else
        {
            if (bBatchMode == false)
            {
                dbiConnHelper.commit();

                for (auto it = newSprocVector.begin(); it != newSprocVector.end(); ++it)
                {
                    if (IS_NULLFLD((*it), A_DictSproc_DictId) == TRUE)
                    {
                        std::string msg("Unable to insert into dict_sproc the procedure: ");
                        msg += GET_SYSNAME((*it), A_DictSproc_SqlName);

                        ddlGenMsg.printMsg(RET_DBA_ERR_INSERT_FAILED, msg);
                    }
                }
            }
            else
            {
                dbiConnHelper.rollback();
            }

            ddlGenMsg.printMsg(requestHelper.getLastRetCode(), currProcessStr.append(" failed!"));
        }
    }

    return requestHelper.getLastRetCode();
}

/************************************************************************
**
**  Function    :   DdlGenContext::insertSprocDepends()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-34402 - LJE - 190125
**
*************************************************************************/
void DdlGenContext::insertSprocDepends(DdlObjDef &ddlObjDef, const DdlObjDef &depSprocDdlObjDef, std::set<DdlObjDefKey> &treatedSProc)
{
    DdlObjDefKey sprocToSearch(this->m_rdbmsEn,
                               DdlObj_SProc, 
                               this->getMainDbName(),
                               std::string(),
                               std::string(),
                               ddlObjDef.getObjName());

    if (treatedSProc.find(sprocToSearch) == treatedSProc.end())
    {
        treatedSProc.insert(sprocToSearch);

        for (auto sprocDepIt = depSprocDdlObjDef.m_dependsEntityMap.begin(); sprocDepIt != depSprocDdlObjDef.m_dependsEntityMap.end(); ++sprocDepIt)
        {
            ddlObjDef.m_dependsEntityMap.insert(std::make_pair(sprocDepIt->first, sprocDepIt->second));
        }
        for (auto sprocDepIt = depSprocDdlObjDef.m_dependsAccessSet.begin(); sprocDepIt != depSprocDdlObjDef.m_dependsAccessSet.end(); ++sprocDepIt)
        {
            ddlObjDef.m_dependsAccessSet.insert(*sprocDepIt);
        }
        for (auto depIt = depSprocDdlObjDef.m_dependsSprocSet.begin(); depIt != depSprocDdlObjDef.m_dependsSprocSet.end(); ++depIt)
        {
            auto depSprocIt = this->m_validDdlObjMap.find(DdlObjDefKey(this->m_rdbmsEn, DdlObj_SProc, this->getMainDbName(), std::string(), std::string(), depIt->getSqlName()));
            if (depSprocIt != this->m_validDdlObjMap.end())
            {
                this->insertSprocDepends(ddlObjDef, depSprocIt->second, treatedSProc);
            }
        }
    }
}

/************************************************************************
**
**  Function    :   DdlGenContext::saveDependenciesInDB()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26108 - LJE - 171002
**
*************************************************************************/
RET_CODE DdlGenContext::saveDependenciesInDB()
{
    if (this->bGenFromDbi ||
        this->ddlGenAction.m_installLevel > 5 ||
        this->ddlGenContextPtr->bSimulation)
    {
        return RET_SUCCEED;
    }

    RET_CODE               ret = RET_SUCCEED, gblRet = RET_SUCCEED;
    std::string            currProcessStr = std::string("Saving");
    DdlGenMsg              ddlGenMsg(this);

    ddlGenMsg.setMsgObjType("Dependencies");
    ddlGenMsg.setMsgSqlName("<All>");
    ddlGenMsg.setMsgEntitySqlName("<All>");

    ddlGenMsg.printMsg(RET_SRV_INFO_RUNNING, currProcessStr);

    if (this->initConnection(nullptr, true) != RET_SUCCEED)
    {
        this->printMsg(RET_DBA_INFO_NODATA, currProcessStr);
        return RET_DBA_INFO_NODATA;
    }

    DbiConnectionHelper dbiConnHelper(&this->getDbiConn(), false);

    try
    {
        /* PMSTA-26108 - LJE - 171002 - Save dict_depends */
        DdlGenRequestHelper requestHelper(dbiConnHelper, *this);
        DICT_T              entDictId;

        DBA_GetDictId(DictEntity, &entDictId);

        for (auto ddlObjIt = this->m_validDdlObjMap.begin(); ddlObjIt != this->m_validDdlObjMap.end(); ++ddlObjIt)
        {
            std::set<DdlObjDefKey> treatedSProc;

            for (auto depIt = ddlObjIt->second.m_dependsSprocSet.begin(); depIt != ddlObjIt->second.m_dependsSprocSet.end(); ++depIt)
            {
                auto depSprocIt = this->m_validDdlObjMap.find(DdlObjDefKey(this->m_rdbmsEn, DdlObj_SProc, this->getMainDbName(), std::string(), std::string(), depIt->getSqlName()));
                if (depSprocIt != this->m_validDdlObjMap.end())
                {
                    this->insertSprocDepends(ddlObjIt->second, depSprocIt->second, treatedSProc);
                }
            }

            treatedSProc.insert(ddlObjIt->first);
        }

        /* PMSTA-34200 - LJE - 190114 - Check dml access */
        bool bUpdated = true;
        while (bUpdated)
        {
            bUpdated = false;
            for (auto ddlObjIt = this->m_validDdlObjMap.begin(); ddlObjIt != this->m_validDdlObjMap.end(); ++ddlObjIt)
            {
                for (auto depIt = ddlObjIt->second.m_dependsSprocSet.begin(); depIt != ddlObjIt->second.m_dependsSprocSet.end(); ++depIt)
                {
                    auto depSprocIt = this->m_validDdlObjMap.find(DdlObjDefKey(this->m_rdbmsEn, DdlObj_SProc, this->getMainDbName(), std::string(), std::string(), depIt->getSqlName()));
                    if (depSprocIt != this->m_validDdlObjMap.end())
                    {
                        if (ddlObjIt->second.m_dictSprocSt.dmlAccess != depSprocIt->second.m_dictSprocSt.dmlAccess &&
                            ddlObjIt->second.m_dictSprocSt.m_storedProcAccessVector.empty() == true &&
                            (ddlObjIt->second.m_dictSprocSt.dmlAccess == ReadOnly ||
                             ddlObjIt->second.m_dictSprocSt.dmlAccess == WriteTempTable && depSprocIt->second.m_dictSprocSt.dmlAccess == WriteTable))
                        {
                            bUpdated = true;
                            ddlObjIt->second.m_dictSprocSt.dmlAccess = depSprocIt->second.m_dictSprocSt.dmlAccess;
                        }
                    }
                }
            }
        }

        for (auto ddlObjIt = this->m_validDdlObjMap.begin(); ddlObjIt != this->m_validDdlObjMap.end(); ++ddlObjIt)
        {
            std::string objName    = ddlObjIt->second.getObjName();
            std::string dbName     = ddlObjIt->second.getDbName();
            std::string objType    = DdlGenDbi::getStdDdlObjType(ddlObjIt->second.getDdlObjEn());
            std::string depObjType = DdlGenDbi::getStdDdlObjType(DdlObj_Table);

            DBA_DYNFLD_STP  shDictDepends = requestHelper.allocDynSt(FILEINFO, S_DictDepends);

            if (objName.size() > LONGSYSNAME_T_LEN)
            {
                ddlGenMsg.printMsg(RET_DBA_ERR_HIER_WARN, "DDL Object name too long: " + objName);

                SET_SYSNAME(shDictDepends, S_DictDepends_SqlName, objName.substr(0, SYSNAME_T_LEN).c_str());
            }
            else
            {
                SET_SYSNAME(shDictDepends, S_DictDepends_SqlName, objName.c_str());
            }

            requestHelper.dbaCall(Delete, DictDepends, UNUSED, shDictDepends, 10);

            for (auto depIt = ddlObjIt->second.m_dependsEntityMap.begin(); depIt != ddlObjIt->second.m_dependsEntityMap.end(); ++depIt)
            {
                DBA_DYNFLD_STP  allDictDepends = requestHelper.allocDynSt(FILEINFO, A_DictDepends);
                DBA_SetDfltEntityFld(DictDepends, A_DictDepends, allDictDepends);
                SET_DATETIME(allDictDepends, A_DictDepends_BuildDate, this->getBuildDate());

                DICT_ENTITY_STP depDictEntityStp = DBA_GetEntityBySqlName(ddlObjIt->second.getEntitySqlName());
                if (depDictEntityStp)
                {
                    SET_DICT(allDictDepends, A_DictDepends_ObjDictId, depDictEntityStp->entDictId);
                }

                SET_ENUM(allDictDepends, A_DictDepends_GenDdlObjEn, ddlObjIt->second.getDdlObjEn());
                SET_SYSNAME(allDictDepends, A_DictDepends_GenEntityName, ddlObjIt->second.getEntitySqlName().c_str());

                SET_SYSNAME(allDictDepends, A_DictDepends_SqlName, objName.c_str());
                SET_SYSNAME(allDictDepends, A_DictDepends_Database, dbName.c_str());
                SET_SYSNAME(allDictDepends, A_DictDepends_ObjType, objType.c_str());
                SET_DICT(allDictDepends, A_DictDepends_EntityDictId, entDictId);

                SET_SYSNAME(allDictDepends, A_DictDepends_DepSqlName, depIt->second->mdSqlName);
                SET_SYSNAME(allDictDepends, A_DictDepends_DepObjType, depObjType.c_str());
                SET_DICT(allDictDepends, A_DictDepends_DepEntityDictId, entDictId);

                if (depIt->second->isMetaDict())
                {
                    SET_DICT(allDictDepends, A_DictDepends_DepObjDictId, depIt->second->entDictId);
                }
                else
                {
                    SET_NULL_DICT(allDictDepends, A_DictDepends_DepObjDictId);
                }
                SET_ENUM(allDictDepends, A_DictDepends_AccessEn, DictDependsAccessEn::Access);
                SET_ENUM(allDictDepends, A_DictDepends_DynNatEn, DynType_Null);

                requestHelper.dbaCall(Insert, DictDepends, UNUSED, allDictDepends, 11);
            }

            for (auto depIt = ddlObjIt->second.m_dependsAccessSet.begin(); depIt != ddlObjIt->second.m_dependsAccessSet.end(); ++depIt)
            {
                DBA_DYNFLD_STP  allDictDepends = requestHelper.allocDynSt(FILEINFO, A_DictDepends);
                DBA_SetDfltEntityFld(DictDepends, A_DictDepends, allDictDepends);
                SET_DATETIME(allDictDepends, A_DictDepends_BuildDate, this->getBuildDate());

                DICT_ENTITY_STP depDictEntityStp = DBA_GetEntityBySqlName(ddlObjIt->second.getEntitySqlName());
                if (depDictEntityStp)
                {
                    SET_DICT(allDictDepends, A_DictDepends_ObjDictId, depDictEntityStp->entDictId);
                }

                SET_ENUM(allDictDepends, A_DictDepends_GenDdlObjEn, ddlObjIt->second.getDdlObjEn());
                SET_SYSNAME(allDictDepends, A_DictDepends_GenEntityName, ddlObjIt->second.getEntitySqlName().c_str());

                SET_SYSNAME(allDictDepends, A_DictDepends_SqlName, objName.c_str());
                SET_SYSNAME(allDictDepends, A_DictDepends_Database, dbName.c_str());
                SET_SYSNAME(allDictDepends, A_DictDepends_ObjType, objType.c_str());
                SET_DICT(allDictDepends, A_DictDepends_EntityDictId, entDictId);

                if (depIt->getDictId() == 0)
                {
                    SET_NULL_DICT(allDictDepends, A_DictDepends_DepEntityDictId);
                    SET_NULL_DICT(allDictDepends, A_DictDepends_DepObjDictId);
                }
                else
                {
                    SET_DICT(allDictDepends, A_DictDepends_DepEntityDictId, entDictId);
                    SET_DICT(allDictDepends, A_DictDepends_DepObjDictId, depIt->getDictId());
                }
                SET_SYSNAME(allDictDepends, A_DictDepends_DepSqlName, depIt->getSqlName().c_str());
                SET_SYSNAME(allDictDepends, A_DictDepends_DepObjType, depObjType.c_str());
                SET_ENUM(allDictDepends, A_DictDepends_AccessEn, depIt->getAccessEn());
                SET_ENUM(allDictDepends, A_DictDepends_DynNatEn, depIt->getDynTypeEn());

                requestHelper.dbaCall(Insert, DictDepends, UNUSED, allDictDepends, 12);
            }

            depObjType = DdlGenDbi::getStdDdlObjType(DdlObj_SProc);

            for (auto depIt = ddlObjIt->second.m_dependsSprocSet.begin(); depIt != ddlObjIt->second.m_dependsSprocSet.end(); ++depIt)
            {
                DBA_DYNFLD_STP  allDictDepends = requestHelper.allocDynSt(FILEINFO, A_DictDepends);
                DBA_SetDfltEntityFld(DictDepends, A_DictDepends, allDictDepends);
                SET_DATETIME(allDictDepends, A_DictDepends_BuildDate, this->getBuildDate());

                DICT_ENTITY_STP depDictEntityStp = DBA_GetEntityBySqlName(ddlObjIt->second.getEntitySqlName());
                if (depDictEntityStp)
                {
                    SET_DICT(allDictDepends, A_DictDepends_ObjDictId, depDictEntityStp->entDictId);
                }

                SET_ENUM(allDictDepends, A_DictDepends_GenDdlObjEn, ddlObjIt->second.getDdlObjEn());
                SET_SYSNAME(allDictDepends, A_DictDepends_GenEntityName, ddlObjIt->second.getEntitySqlName().c_str());

                SET_SYSNAME(allDictDepends, A_DictDepends_SqlName, objName.c_str());
                SET_SYSNAME(allDictDepends, A_DictDepends_Database, dbName.c_str());
                SET_SYSNAME(allDictDepends, A_DictDepends_ObjType, objType.c_str());
                SET_DICT(allDictDepends, A_DictDepends_EntityDictId, entDictId);

                SET_SYSNAME(allDictDepends, A_DictDepends_DepSqlName, depIt->getSqlName().c_str());
                SET_SYSNAME(allDictDepends, A_DictDepends_DepObjType, depObjType.c_str());
                SET_ENUM(allDictDepends, A_DictDepends_AccessEn, depIt->getAccessEn());
                SET_ENUM(allDictDepends, A_DictDepends_DynNatEn, depIt->getDynTypeEn());

                requestHelper.dbaCall(Insert, DictDepends, UNUSED, allDictDepends, 13);

                /* PMSTA-34200 - LJE - 190114 - Check dml access */
                auto depSprocIt = this->m_validDdlObjMap.find(DdlObjDefKey(this->m_rdbmsEn, DdlObj_SProc, this->getMainDbName(), std::string(), std::string(), depIt->getSqlName()));
                if (depSprocIt != this->m_validDdlObjMap.end())
                {
                    if (ddlObjIt->second.m_dictSprocSt.dmlAccess != depSprocIt->second.m_dictSprocSt.dmlAccess &&
                        ddlObjIt->second.m_dictSprocSt.dmlAccess == ReadOnly &&
                        ddlObjIt->second.m_dictSprocSt.m_storedProcAccessVector.empty() == false)
                    {
                        std::stringstream msg;
                        msg << "Mismatch DML access definition between the stored procedure ("
                            << ddlObjIt->second.m_dictSprocSt.sqlName << " - " << DictSprocClass::getDmlAccessStr(ddlObjIt->second.m_dictSprocSt.dmlAccess) << ")"
                            << " and the called stored procedure ("
                            << depSprocIt->second.m_dictSprocSt.sqlName << " - " << DictSprocClass::getDmlAccessStr(depSprocIt->second.m_dictSprocSt.dmlAccess) << ") connection information in DBA procedure structure.";
                        gblRet = RET_DBA_ERR_NODATA;

                        this->printMsg(ret, msg.str());
                    }
                }
            }
        }

        gblRet = requestHelper.getLastResultRetCode();
    }
    catch (std::exception &e)
    {
        gblRet = RET_DBA_ERR_DBPROBLEM;
        this->printCatchMsg(FILEINFO, e.what());
    }

    if (RET_GET_LEVEL(gblRet) != RET_LEV_ERROR)
    {
        this->commit();
        ddlGenMsg.printMsg(RET_SUCCEED, currProcessStr.append(" done!"));
    }
    else
    {
        this->rollback();
        ddlGenMsg.printMsg(gblRet, currProcessStr.append(" failed!"));
    }

    this->endConnection();

    ddlGenMsg.setMsgObjType(std::string());
    ddlGenMsg.setMsgSqlName(std::string());

    return gblRet;
}

/************************************************************************
**
**  Function    :   DdlGenContext::getMainDbName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
std::string DdlGenContext::getMainDbName(bool bForceRealDbName)
{
    if (this->bGenFromDbi && bForceRealDbName == false)
    {
        return "$AAAMAIN_DB";
    }

    if (this->mainDbSqlName.empty() || EV_UseAlternativeDataSource || bForceRealDbName)
    {
        std::string mainDb;
        GEN_GetApplInfo(ApplSqlDbName, mainDb);
        DdlGenDbi::standardize(mainDb, this);
        this->mainDbSqlName = mainDb;
    }
    return this->mainDbSqlName;
}


/************************************************************************
**
**  Function    :   DdlGenContext::getLoginDbName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14556 - LJE - 120705
**
*************************************************************************/
std::string DdlGenContext::getLoginDbName()
{
    if (this->bGenFromDbi)
    {
        return "$AAALOGIN_DB";
    }

    if (this->loginDbSqlName.empty())
    {
        this->loginDbSqlName = SYS_GetLoginDb();
        DdlGenDbi::standardize(this->loginDbSqlName, this);
    }
    return this->loginDbSqlName;
}


/************************************************************************
**
**  Function    :   DdlGenContext::getRepDbName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
std::string DdlGenContext::getRepDbName()
{
    if (this->bGenFromDbi)
    {
        return "$AAAREP_DB";
    }

    if (this->repDbSqlName.empty())
    {
        std::string repDb;
        GEN_GetApplInfo(ApplSqrDbName, repDb);
        DdlGenDbi::standardize(repDb, this);
        this->repDbSqlName = repDb;
    }
    return this->repDbSqlName;
}


/************************************************************************
**
**  Function    :   DdlGenContext::getPermTslDbName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
std::string DdlGenContext::getPermTslDbName()
{
    if (this->bGenFromDbi)
    {
        return "$TSL_PERM_DB";
    }

    if (this->permTslDbSqlName.empty())
    {
        std::string permTslDb;
        GEN_GetApplInfo(ApplPermTslDbName, permTslDb);
        DdlGenDbi::standardize(permTslDb, this);
        this->permTslDbSqlName = permTslDb;
    }
    return this->permTslDbSqlName;
}


/************************************************************************
**
**  Function    :   DdlGenContext::getTempTslDbName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
std::string DdlGenContext::getTempTslDbName()
{
    if (this->bGenFromDbi)
    {
        return "$TSL_TEMP_DB";
    }

    if (this->tempTslDbSqlName.empty())
    {
        std::string tempTslDb;
        GEN_GetApplInfo(ApplTempTslDbName, tempTslDb);
        DdlGenDbi::standardize(tempTslDb, this);
        this->tempTslDbSqlName = tempTslDb;
    }
    return this->tempTslDbSqlName;
}


/************************************************************************
**
**  Function    :   DdlGenContext::setAaaHomePath()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37366 - LJE - 200824
**
*************************************************************************/
void DdlGenContext::setAaaHomePath(const std::string &aaaHomePath)
{
    this->m_aaaHomePath = aaaHomePath;
}

/************************************************************************
**
**  Function    :   DdlGenContext::getAaaHomePath()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-25088 - LJE - 161103
**
*************************************************************************/
const std::string &DdlGenContext::getAaaHomePath()
{
    if (this->m_aaaHomePath.empty())
    {
        char *tmp = SYS_GetEnv("AAAHOME");
        if (tmp != NULL)
        {
            this->m_aaaHomePath = std::string(tmp);
        }
    }
    return this->m_aaaHomePath;
}

/************************************************************************
**
**  Function    :   DdlGenContext::getDdlGenPath()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-25088 - LJE - 161103
**
*************************************************************************/
const std::string &DdlGenContext::getDdlGenPath()
{
    if (this->ddlPath.empty())
    {
        char *tmp = SYS_GetEnv("AAADDLPATH");
        if (tmp != NULL)
        {
            this->ddlPath = std::string(tmp);
        }
        else
        {
            std::string aaaHome = this->getAaaHomePath();
            if (aaaHome.empty() == false)
            {
                this->ddlPath = aaaHome + FILE_SEPARATOR + "ddl";
            }
        }
    }
    return this->ddlPath;
}

/************************************************************************
**
**  Function    :   DdlGenContext::getCorePath()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-24007 - LJE - 161213
**
*************************************************************************/
const std::string &DdlGenContext::getCorePath()
{
    if (this->corePath.empty())
    {
        const char* coreDir = GEN_GetPath(Coredir);

        /* CCM_PROJECT_PATH must be defined to point work area path */
        if (coreDir == NULL || coreDir[0] == 0)
        {
            this->printMsg(RET_GEN_ERR_INVARG, "CCM_PROJECT_PATH must be defined to point work area path");
        }
        else
        {
            this->corePath = std::string(coreDir);
        }
    }
    return this->corePath;
}

/************************************************************************
**
**  Function    :   DdlGenContext::getAdminPath()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-24564 - LJE - 170117
**
*************************************************************************/
const std::string &DdlGenContext::getAdminPath()
{
    if (this->adminPath.empty())
    {
        char *tmp = SYS_GetEnv("AAA_ADMIN_DIR");
        if (tmp != NULL)
        {
            this->adminPath = std::string(tmp);
        }
        else
        {
            std::string aaaHome = this->getAaaHomePath();
            if (aaaHome.empty() == false)
            {
                this->adminPath = aaaHome + FILE_SEPARATOR + "std_admin";
            }
        }
    }
    return this->adminPath;
}

/************************************************************************
**
**  Function    :   DdlGenContext::getSilentMode()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37366 - LJE - 200210
**
*************************************************************************/
bool DdlGenContext::getSilentMode()
{
    if (this->m_silentMode == 99)
    {
        if (this->m_bLightContext == false)
        {
            this->m_silentMode = SYS_GetEnvUnsignedOrDefValue("AAAGENSILENTMODE", 1);
        }
        else
        {
            this->m_silentMode = 1;
        }
    }

    return this->m_silentMode == 1;
}

/************************************************************************
**
**  Function    :   DdlGenContext::isEnableMultiTascLogin()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-25088 - LJE - 161103
**
*************************************************************************/
bool DdlGenContext::isEnableMultiTascLogin()
{
    if (this->enableMultiTascLoginVal < 0)
    {
        this->enableMultiTascLoginVal = this->cfgFileHelper.getPropertyUnsignedOrDefValue("ENABLE_MULTI_TASC_LOGIN", 1);
    }
    return this->enableMultiTascLoginVal != 0 ? true : false;
}

/************************************************************************
**
**  Function    :   DdlGenContext::isEnableAdditionalDSP()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-25088 - LJE - 161103
**
*************************************************************************/
bool DdlGenContext::isEnableAdditionalDSP()
{
    if (this->enableAdditionalDSPVal < 0)
    {
        this->enableAdditionalDSPVal = this->cfgFileHelper.getPropertyUnsignedOrDefValue("ENABLE_ADDITIONAL_DSP", 1);
    }
    return this->enableAdditionalDSPVal != 0 ? true : false;
}

/************************************************************************
**
**  Function    :   DdlGenContext::isEnableSecuOnFkView()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-43625 - LJE - 210308
**
*************************************************************************/
bool DdlGenContext::isEnableSecuOnFkView()
{
    if (this->enableSecuOnFkView < 0)
    {
        this->enableSecuOnFkView = this->cfgFileHelper.getPropertyUnsignedOrDefValue("ENABLE_SECU_ON_FK_VIEW", true);
    }
    return this->enableSecuOnFkView != 0 ? true : false;
}

/************************************************************************
**
**  Function    :   DdlGenContext::getTemplateVersion()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-25088 - LJE - 161103
**
*************************************************************************/
unsigned DdlGenContext::getTemplateVersion()
{
    if (this->templateVersionVal < 0)
    {
        this->templateVersionVal = this->cfgFileHelper.getPropertyUnsignedOrDefValue("AAATEMPLATEVERSION", 1);
    }
    return this->templateVersionVal;
}

/************************************************************************
**
**  Function    :   DdlGenContext::isMultiThreadMode()
**
**  Description :
**
**  Arguments   :   
**
**  Return      :
**
**  Creation  	:   PMSTA-46681 - LJE - 240125
**
*************************************************************************/
bool DdlGenContext::isMultiThreadMode() const
{
    return this->m_bMultiThreadMode || (this->m_ddlGenContextForConn != nullptr && this->m_ddlGenContextForConn->m_bMultiThreadMode);
}

/************************************************************************
**
**  Function    :   DdlGenContext::applyContext()
**
**  Description :
**
**  Arguments   :   
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 150703
**
*************************************************************************/
RET_CODE DdlGenContext::applyContext(bool bForDdl)
{
    RET_CODE ret = RET_SUCCEED;

    AAALogger::CorrelationIdGenerator corrId; /*  PMSTA-38939 - FME - 20200210 */

    DbiConnection *locDbiConn       = (this->m_parentContext->m_extDbiConn != nullptr && this->isMultiThreadMode() == false ? this->m_parentContext->m_extDbiConn : (bForDdl ? this->m_dbiConnForDdl : this->m_dbiConn));

    if (locDbiConn != nullptr)
    {
        if (bForDdl)
        {
            std::string dbName                  = this->ddlDestDbName;
            std::string user                    = this->ddlDestUser;
            bool   bDeferredNameResolution = locDbiConn->getConnSessionProperties().isDeferredNameResolution();

            if (dbName.empty())
            {
                dbName = this->getMainDbName();
            }

            if (locDbiConn->getTargetSessionProperties().getDbName().compare(dbName) != 0)
            {
                locDbiConn->setDbName(dbName);

                if (this->fileHelper != nullptr)
                {
                    *this->fileHelper << DdlGenDbi::getCmdUseDb(dbName, locDbiConn->m_connectToRDBMS) << "\n";
                    *this->fileHelper << DdlGenDbi::getCmdGo(locDbiConn->m_connectToRDBMS) << "\n";
                    this->fileHelper->flush();
                }
            }

            const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
            if (this->currUser.compare(user) != 0)
            {
                std::string              buffer = DdlGenDbi::setUserCmd(user, locDbiConn->m_connectToRDBMS);
                DBI_INT             status = 0;

                if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
                {
                    auto &sqlTrace = locDbiConn->getSqlTrace();
                    sqlTrace.m_procedure = "DynSql.applyContext";
                }
                ret = locDbiConn->sqlExecSt(buffer.c_str(), &status);

                if (ret != RET_SUCCEED)
                {
                    if (ret != RET_GEN_INFO_NOACTION)
                    {
                        locDbiConn->sendAllMsg();
                        this->printMsg(RET_DBA_ERR_SETPARAM, "Error in while setting user (" + user + ")");
                    }
                }
                else if (this->fileHelper != nullptr)
                {
                    *this->fileHelper << buffer << "\n";
                    *this->fileHelper << DdlGenDbi::getCmdGo(locDbiConn->m_connectToRDBMS) << "\n";
                    this->fileHelper->flush();
                }

                this->currUser = user;
            }

            if (locDbiConn->m_tempTablesMask == 0)
            {
                DBA_CreateTempTables(*locDbiConn, ALL_TEMP_TABLES);
            }

            if (locDbiConn->m_connectToRDBMS == Sybase)
            {
                if (locDbiConn->m_bSettingsForDdl != bDeferredNameResolution)
                {
                    DBI_INT status = 0;

                    std::string buffer = "set deferred_name_resolution ";

                    buffer += (bDeferredNameResolution ? "on" : "off");

                    if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
                    {
                        auto &sqlTrace = locDbiConn->getSqlTrace();
                        sqlTrace.m_procedure = "DynSql.applyContext";
                    }
                    ret = locDbiConn->sqlExecSt(buffer.c_str(), &status);

                    if (ret != RET_SUCCEED)
                    {
                        locDbiConn->sendAllMsg();
                        this->printMsg(RET_DBA_ERR_SETPARAM, "Error in while setting deferred name resolution");
                    }
                    else if (this->fileHelper != nullptr)
                    {
                        *this->fileHelper << buffer << "\n";
                        *this->fileHelper << DdlGenDbi::getCmdGo(locDbiConn->m_connectToRDBMS) << "\n";
                        this->fileHelper->flush();
                    }

                    locDbiConn->m_bSettingsForDdl = bDeferredNameResolution;
                }
            }
            else if (locDbiConn->m_connectToRDBMS == Oracle)
            {
                if (locDbiConn->m_bSettingsForDdl == false)
                {
                    DBI_INT status = 0;

                    std::string buffer = "ALTER SESSION SET ddl_lock_timeout=10800"; /* Wait 3 hours ... */

                    if (EV_sqlFile != nullptr || sqlTraceLog.isWarnEnabled())
                    {
                        auto &sqlTrace = locDbiConn->getSqlTrace();
                        sqlTrace.m_procedure = "DynSql.applyContext";
                    }
                    ret = locDbiConn->sqlExecSt(buffer.c_str(), &status);

                    if (ret != RET_SUCCEED)
                    {
                        locDbiConn->sendAllMsg();
                        this->printMsg(RET_DBA_ERR_SETPARAM, "Error in while altering session");
                    }
                    else if (this->fileHelper != nullptr)
                    {
                        *this->fileHelper << buffer << "\n";
                        *this->fileHelper << DdlGenDbi::getCmdGo(locDbiConn->m_connectToRDBMS) << "\n";
                        this->fileHelper->flush();
                    }
                    locDbiConn->m_bSettingsForDdl = true;
                }
            }
        }
        else if (EV_UseAlternativeDataSource == false)
        {
            std::string dbName = this->getMainDbName(true);
            if (locDbiConn->getActualDbName().compare(dbName) != 0)
            {
                locDbiConn->setDbName(dbName);
            }
        }

        /* PMSTA-45830 - LJE - 220321 */
        if (locDbiConn->m_connectToRDBMS == Sqlite)
        {
            if (this->ddlGenAction.m_mainDdlObjNatEn == DbObjDdlObjNat_Table &&
                this->ddlObjSqlName.empty() == false)
            {
                if (this->ddlObjSqlName != locDbiConn->m_dbNameOption)
                {
                    locDbiConn->m_dbNameOption = this->ddlObjSqlName;
                }
            }
            else if (this->ddlGenAction.m_targetSqlnameStr != locDbiConn->m_dbNameOption)
            {
                locDbiConn->m_dbNameOption = this->ddlGenAction.m_targetSqlnameStr;
            }
            else if (this->ddlGenAction.m_entitySqlnameStr != locDbiConn->m_dbNameOption)
            {
                locDbiConn->m_dbNameOption = this->ddlGenAction.m_entitySqlnameStr;
            }
        }
    }
    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenContext::getAllDbSet()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210727
**
*************************************************************************/
std::set<std::string> &DdlGenContext::getAllDbSet()
{
    if (this->m_allDbSet.empty())
    {
        if (EV_UseAlternativeDataSource && EV_TargetCfgFile != nullptr)
        {
            std::string    toSchemaName;

            for (std::map<std::string, CFG_DB_SECTION_ST>::iterator dbSectionIt = EV_TargetCfgFile->dbSectionMap.begin(); dbSectionIt != EV_TargetCfgFile->dbSectionMap.end(); ++dbSectionIt)
            {
                toSchemaName = dbSectionIt->second.dbSqlName;
                DdlGenDbi::standardize(toSchemaName, this->m_rdbmsEn);
                this->m_allDbSet.insert(toSchemaName);
            }
        }
        else
        {
            std::string locDbName(SYS_GetLoginDb());

            DdlGenDbi::standardize(locDbName, this->m_rdbmsEn);
            this->m_allDbSet.insert(locDbName);

            GEN_GetApplInfo(ApplSqlDbName, locDbName);
            DdlGenDbi::standardize(locDbName, this->m_rdbmsEn);
            this->m_allDbSet.insert(locDbName);

            GEN_GetApplInfo(ApplSqrDbName, locDbName);
            if (locDbName.empty())
            {
                auto dbSectionIt = this->getCfgFileHelper().dbSectionMap.find("AAAREP_DB");
                if (dbSectionIt != this->getCfgFileHelper().dbSectionMap.end())
                {
                    locDbName = dbSectionIt->second.dbSqlName;
                    DdlGenDbi::standardize(locDbName, this->m_rdbmsEn);
                    GEN_SetApplInfo(ApplSqrDbName, locDbName);
                }
            }
            DdlGenDbi::standardize(locDbName, this->m_rdbmsEn);
            this->m_allDbSet.insert(locDbName);
            this->getPropFileHelper().setProperty("AAAREP_DB", locDbName, false);
            this->getPropFileHelper().setProperty("AAAREPDB", locDbName, false);

            GEN_GetApplInfo(ApplPermTslDbName, locDbName);
            if (locDbName.empty())
            {
                auto dbSectionIt = this->getCfgFileHelper().dbSectionMap.find("TSL_PERM_DB");
                if (dbSectionIt != this->getCfgFileHelper().dbSectionMap.end())
                {
                    locDbName = dbSectionIt->second.dbSqlName;
                    DdlGenDbi::standardize(locDbName, this->m_rdbmsEn);
                    GEN_SetApplInfo(ApplPermTslDbName, locDbName);
                }
            }
            DdlGenDbi::standardize(locDbName, this->m_rdbmsEn);
            this->m_allDbSet.insert(locDbName);
            this->getPropFileHelper().setProperty("TSL_PERM_DB", locDbName, false);
            this->getPropFileHelper().setProperty("TSLPERM_DB", locDbName, false);
            this->getPropFileHelper().setProperty("TSLPERMDB", locDbName, false);

            GEN_GetApplInfo(ApplTempTslDbName, locDbName);
            if (locDbName.empty())
            {
                auto dbSectionIt = this->getCfgFileHelper().dbSectionMap.find("TSL_TEMP_DB");
                if (dbSectionIt != this->getCfgFileHelper().dbSectionMap.end())
                {
                    locDbName = dbSectionIt->second.dbSqlName;
                    DdlGenDbi::standardize(locDbName, this->m_rdbmsEn);
                    GEN_SetApplInfo(ApplTempTslDbName, locDbName);
                }
            }
            DdlGenDbi::standardize(locDbName, this->m_rdbmsEn);
            this->m_allDbSet.insert(locDbName);
            this->getPropFileHelper().setProperty("TSL_TEMP_DB", locDbName, false);
            this->getPropFileHelper().setProperty("TSLTEMP_DB", locDbName, false);
            this->getPropFileHelper().setProperty("TSLTEMPDB", locDbName, false);

            if (this->bGenFromDbi)
            {
                std::set<std::string> allDbSet;
                for (auto it = this->m_allDbSet.begin(); it != this->m_allDbSet.end(); ++it)
                {
                    std::string db = (*it);
                    this->getConvertValue(db);
                    allDbSet.insert(db);

                }
                this->m_allDbSet = allDbSet;
            }
        }
    }

    return this->m_allDbSet;
}

/************************************************************************
**
**  Function    :   DdlGenContext::resetContext()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 150703
**
*************************************************************************/
RET_CODE DdlGenContext::resetContext(std::string newDllObjSqlName)
{
    RET_CODE ret = RET_SUCCEED;

    this->setDefDdlDestDbName();    /* WEALTH-9627 - LJE - 240625 */
    this->setDdlDestUser();

    this->bLanguage             = false;
    this->bUserId               = false;
    this->bAvoidUserPrint       = false;
    this->bLanguagePrinted      = false;
    this->bMainDLMMax           = false;         /* PMSTA-24026 - DDV - 161122 - Data framework */
    this->bMainDLMMaxPrinted    = false;  /* PMSTA-24026 - DDV - 161122 - Data framework */
    this->bAddDLMMax            = false;          /* PMSTA-24026 - DDV - 161122 - Data framework */
    this->bAddDLMMaxPrinted     = false;   /* PMSTA-24026 - DDV - 161122 - Data framework */
    this->bRootEntityManagement = false;

    this->ddlObjSqlName.clear();

    this->dmlEventEn             = DmlEvent_None;
    this->m_lastCreateInvalid    = false;
    /* PMSTA-23226 - LJE - 160518 */
    this->bAvoidSecured          = false;
    this->bSecurityDone          = false;   /* PMSTA-43626 - LJE - 210311 */
    this->bAvoidMultiEntity      = false;
    this->bForceConnEntity       = false;    /* PMSTA-29982 - LJE - 180209 */
    this->bAutonomousTransaction = false;  /* PMSTA-20494 - TEB - 160808 */
    this->bDisableChangeSet      = false;
    this->bIfNotExists           = false;
    this->m_bCodif               = false;
    this->iCursorCpt             = 0;
    this->m_lastUnkownObjDefPos  = MAX_SHORT;

    /* PMSTA-26250 - LJE - 170330 */
    this->m_dependsEntityMap.clear();
    this->m_dropDdlParamTab.clear();
    this->m_dropDdlStrTab.clear();
    this->m_loadedDdlObjStream.clear();
    this->m_loadedDdlObjStream.str(std::string());
    this->m_ddlObjLoaded.clear();

    this->m_dependsSprocSet.clear();
    this->m_dependsAccessSet.clear();

    this->m_tmpTableCreatedMap.clear();
    this->m_createTmpTableStream.clear();
    this->m_createTmpTableStream.str(std::string());

    this->m_initSqlBlock.clear();       /* PMSTA-26250 - LJE - 170410 */

    this->setMsgSqlName(newDllObjSqlName);

    this->bStdIinsObjectModifStat = false;   /* PMSTA-32982 - LJE - 181016 */
    this->bForceNewReturnsDef     = true;    /* PMSTA-37366 - LJE - 200128 */
    this->bPartialSpecialization  = false;   /* PMSTA-32145 - LJE - 180720 */
    this->iNoOpCpt                = 0;
    this->bForceTableName         = false;
    this->m_bOutputMessage        = false;  /* PMSTA-37366 - LJE - 191120 */
    this->bWarning                = false;

    this->m_bHasUnknownCall       = false;

    this->m_additionalGenInfo.clear();       /* PMSTA-43500 - LJE - 210318 */
    this->m_addDeclareMap.clear();        /* PMSTA-58084 - LJE - 240729 */
    
    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenContext::getTemplateXdAttrib()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-24007 - LJE - 170717
**
*************************************************************************/
DdlGenEntity *DdlGenContext::getTemplateDdlGenEntityPtr()
{
    if (this->templateDdlGenEntity == nullptr)
    {
        this->templateDdlGenEntity = this->getDdlGenEntityPtr("dict_attribute_template", std::string(), true, true);
    }
    return this->templateDdlGenEntity;
}

/************************************************************************
**
**  Function    :   DdlGenContext::getDdlGenEntityPtr()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-28916 - LJE - 171223
**
*************************************************************************/
DdlGenEntity *DdlGenContext::getDdlGenEntityPtr(const char *entitySqlName)
{
    std::string mdEntitySqlName(entitySqlName);
    std::string dbEntitySqlName("check_" + mdEntitySqlName);

    return this->getDdlGenEntityPtr(mdEntitySqlName, dbEntitySqlName, true, true);
}

/************************************************************************
**
**  Function    :   DdlGenContext::getDdlGenEntityPtr()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-28916 - LJE - 171223
**
*************************************************************************/
DdlGenEntity *DdlGenContext::getDdlGenEntityPtr(const std::string &mdEntitySqlName, std::string targetEntitySqlName, bool bLoadData, bool bCheckOnly)
{
    if (targetEntitySqlName.empty())
    {
        targetEntitySqlName = mdEntitySqlName;
    }

    this->readLock();

    auto &ddlGenEntitiesMap = this->m_parentContext->m_ddlGenEntitiesMap;

    auto ddlGenEntityIt = ddlGenEntitiesMap.find(targetEntitySqlName);
    if (ddlGenEntityIt != ddlGenEntitiesMap.end())
    {
        this->readUnlock();
        return ddlGenEntityIt->second;
    }

    this->readUnlock();
    this->writeLock();

    DdlGenEntity *newDdlGenEntityPtr = new DdlGenEntity(mdEntitySqlName, *this->m_parentContext);
    newDdlGenEntityPtr->setTargetSqlName(targetEntitySqlName);

    ddlGenEntitiesMap.insert(std::make_pair(targetEntitySqlName, newDdlGenEntityPtr));
    this->m_parentContext->m_mp.ownerObject(newDdlGenEntityPtr);

    if (bLoadData)
    {
        const RET_CODE ret = newDdlGenEntityPtr->loadExdEntityInfo(false);
        if (ret != RET_SUCCEED)
        {
            if (bCheckOnly == false)
            {
                this->printMsg(ret, "Impossible to load " + mdEntitySqlName + " entity");
            }
        }
        else
        {
            this->setXdEntitySqlNameById(GET_ID(newDdlGenEntityPtr->getXdEntityStp(), A_XdEntity_Id), mdEntitySqlName);
        }
    }

    this->writeUnlock();

    return newDdlGenEntityPtr;
}

/************************************************************************
**
**  Function    :   DdlGenContext::getUniqueIndexMap()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-31672 - LJE - 180607
**
*************************************************************************/
void DdlGenContext::getUniqueIndexMap(const std::string &entitySqlName, std::map<std::string, std::map<std::string, bool>> &uniqueIdxMap)
{
    DdlGenEntity *ddlGenEntityPtr = this->getDdlGenEntityPtr(entitySqlName, entitySqlName, true);

    auto &idxVector = ddlGenEntityPtr->getXdIndexVector();

    for (auto idxIt = idxVector.begin(); idxIt != idxVector.end(); ++idxIt)
    {
        if (GET_FLAG((*idxIt), A_XdIndex_UniqueFlg) == TRUE &&
            (GET_A_XdIndex_IdxFctEn((*idxIt)) == XdIndexIdxFctEn::BusinessKey ||
             GET_A_XdIndex_IdxFctEn((*idxIt)) == XdIndexIdxFctEn::PrimaryKey ||
             GET_A_XdIndex_IdxFctEn((*idxIt)) == XdIndexIdxFctEn::Standard ||
             GET_A_XdIndex_IdxFctEn((*idxIt)) == XdIndexIdxFctEn::ModelBank ||
             GET_A_XdIndex_IdxFctEn((*idxIt)) == XdIndexIdxFctEn::Custom))
            {
            auto idxAttribMap = ddlGenEntityPtr->getXdIndexAttribVector(*idxIt);

            std::map<std::string, bool> uniqueIdxAttribMap;

            for (auto idxAttribIt = idxAttribMap.begin(); idxAttribIt != idxAttribMap.end(); ++idxAttribIt)
            {
                uniqueIdxAttribMap.insert(std::make_pair(GET_SYSNAME((*idxAttribIt), A_XdIndexAttrib_XdAttribSqlName), false));
            }
            uniqueIdxMap.insert(std::make_pair(GET_SYSNAME((*idxIt), A_XdIndex_SqlName), uniqueIdxAttribMap));
        }
    }
}

/************************************************************************
**
**  Function    :   DdlGenContext::setXdEntitySqlNameById()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-28916 - LJE - 171223
**
*************************************************************************/
void DdlGenContext::setXdEntitySqlNameById(ID_T entityId, std::string entitySqlName)
{
    this->m_xdEntitySqlNameByIdMap.insert(std::make_pair(entityId, entitySqlName));
    this->m_parentContext->m_xdEntitySqlNameByIdMap.insert(std::make_pair(entityId, entitySqlName));
}

/************************************************************************
**
**  Function    :   DdlGenContext::getDdlGenEntityPtrById()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-28916 - LJE - 171223
**
*************************************************************************/
const std::string &DdlGenContext::getXdEntitySqlNameById(ID_T entityId)
{
    auto xdEntityIt = this->m_xdEntitySqlNameByIdMap.find(entityId);

    if (xdEntityIt == this->m_xdEntitySqlNameByIdMap.end())
    {
        DdlGenDbaAccess &ddlGenDbaAccess = this->getDdlGenDbaAccess();

        std::string         sqlName;

        if (ddlGenDbaAccess.isLoaded(NullEntity))
        {
            auto xdEntityStp = ddlGenDbaAccess.getXdEntityById(entityId);

            if (xdEntityStp != nullptr)
            {
                sqlName = GET_SYSNAME(xdEntityStp, A_XdEntity_SqlName);
            }
        }
        else
        {
            DBA_DYNFLD_STP shXdEntityStp = this->m_mp.allocDynst(FILEINFO, S_XdEntity);

            SET_ID(shXdEntityStp, S_XdEntity_Id, entityId);

            if (DBA_Get2(XdEntity,
                         UNUSED,
                         S_XdEntity,
                         shXdEntityStp,
                         S_XdEntity,
                         &shXdEntityStp,
                         DBA_SET_CONN | DBA_NO_CLOSE,
                         this->getDbiConn(),
                         UNUSED) != RET_SUCCEED)
            {
                MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, "xd_entity", entityId);
            }
            else
            {
                sqlName = GET_SYSNAME(shXdEntityStp, S_XdEntity_SqlName);
            }
        }

        this->setXdEntitySqlNameById(entityId, sqlName);

        xdEntityIt = this->m_xdEntitySqlNameByIdMap.find(entityId);
    }

    return xdEntityIt->second;
}

/************************************************************************
**
**  Function    :   DdlGenContext::setDdlDestUser()
**
**  Description :
**
**  Arguments   :   database name, if empty, use the main database
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 150106
**
*************************************************************************/
RET_CODE DdlGenContext::setDdlDestUser(std::string user)
{
    this->ddlDestUser = user;

    return RET_SUCCEED;
}

/************************************************************************
**
**  Function    :   DdlGenContext::getDdlDestUser()
**
**  Description :
**
**  Arguments   :   database name, if empty, use the main database
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 150106
**
*************************************************************************/
std::string DdlGenContext::getDdlDestUser()
{
    return this->ddlDestUser;
}

/************************************************************************
**
**  Function    :   DdlGenContext::getCfgFileHelper()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37366 - LJE - 200326
**
*************************************************************************/
DdlGenCfgFile &DdlGenContext::getCfgFileHelper(bool bLoadFile)
{
    if (bLoadFile && (this->m_parentContext == this || this->ddlGenAction.m_multiThreadSize == 0))
    {
        this->cfgFileHelper.loadCfgFile();
    }
    return this->m_parentContext->cfgFileHelper;
}

/************************************************************************
**
**  Function    :   DdlGenContext::getPropFileHelper()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37366 - LJE - 200326
**
*************************************************************************/
DdlGenCfgFile &DdlGenContext::getPropFileHelper()
{
    if (this->m_parentContext == this || this->ddlGenAction.m_multiThreadSize == 0)
    {
        this->propFileHelper.loadCfgFile();
    }
    return this->m_parentContext->propFileHelper;
}

/************************************************************************
**
**  Function    :   DdlGenContext::getTemplateFileHelper()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37366 - LJE - 200326
**
*************************************************************************/
DdlGenCfgFile &DdlGenContext::getTemplateFileHelper()
{
    if (this->m_parentContext == this || this->ddlGenAction.m_multiThreadSize == 0)
    {
        this->templateFileHelper.loadCfgFile();
    }

    return this->m_parentContext->templateFileHelper;
}

/************************************************************************
**
**  Function    :   DdlGenContext::getUpgradeFileHelper()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37366 - LJE - 200326
**
*************************************************************************/
DdlGenCfgFile &DdlGenContext::getUpgradeFileHelper()
{
    if (this->m_parentContext == this || this->ddlGenAction.m_multiThreadSize == 0)
    {
        this->upgradeFileHelper.loadCfgFile();
    }

    return this->m_parentContext->upgradeFileHelper;
}

/************************************************************************
**
**  Function    :   DdlGenContext::addMessage()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
void DdlGenContext::addMessage(RET_CODE retCode, DDLGEN_MESSAGE_LEVEL_ENUM messageLevelEn, const std::string &message)
{
    this->m_messagesVector.push_back(DdlGenMessage(retCode, messageLevelEn, message));

    if (messageLevelEn == DdlgenMessageLevel_Error ||
        messageLevelEn == DdlgenMessageLevel_FatalError)
    {
        this->m_errorMessagesVector.push_back(DdlGenMessage(retCode, messageLevelEn, message));
    }
}

/************************************************************************
**
**  Function    :   DdlGenContext::setViewEn()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-32145 - LJE - 180720
**
*************************************************************************/
void DdlGenContext::setViewEn(DDL_VIEW_ENUM viewEn)
{
    this->m_viewEn = viewEn;
}
/************************************************************************
**
**  Function    :   DdlGenContext::getViewEn()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14556 - LJE - 120705
**
*************************************************************************/
DDL_VIEW_ENUM DdlGenContext::getViewEn()
{
    return this->m_viewEn;
}

/************************************************************************
**
**  Function    :   DdlGenContext::setDictStp()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26250 - LJE - 170426
**
*************************************************************************/
void DdlGenContext::setDictSprocSt(DictSprocClass *dictSprocStp)
{
    if (dictSprocStp == nullptr)
    {
        this->m_dictSprocSt.reset();
    }
    else
    {
        this->m_dictSprocSt = *dictSprocStp;
    }
}

/************************************************************************
**
**  Function    :   DdlGenContext::getDictSprocStp()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26250 - LJE - 170426
**
*************************************************************************/
DictSprocClass &DdlGenContext::getDictSprocSt()
{
    return this->m_dictSprocSt;
}

/************************************************************************
**
**  Function    :   DdlGenContext::getDictSprocStp()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26250 - LJE - 170426
**
*************************************************************************/
void DdlGenContext::getConvertValue(std::string &strToConvert)
{
    if (this->m_parentContext->m_convertMap.empty())
    {
        if (EV_UseAlternativeDataSource == false)
        {
            DBA_RDBMS_ENUM rdbmsDdlGen = EV_RdbmsDdlGen;

            std::string locDbName = SYS_GetLoginDb();
            DdlGenDbi::standardize(locDbName, rdbmsDdlGen);
            this->m_convertMap.insert(std::pair<std::string, std::string>(locDbName, "$AAALOGIN_DB"));
            GEN_GetApplInfo(ApplSqlDbName, locDbName);
            DdlGenDbi::standardize(locDbName, rdbmsDdlGen);
            this->m_convertMap.insert(std::pair<std::string, std::string>(locDbName, "$AAAMAIN_DB"));
            GEN_GetApplInfo(ApplSqrDbName, locDbName);
            DdlGenDbi::standardize(locDbName, rdbmsDdlGen);
            this->m_convertMap.insert(std::pair<std::string, std::string>(locDbName, "$AAAREP_DB"));
            GEN_GetApplInfo(ApplPermTslDbName, locDbName);
            DdlGenDbi::standardize(locDbName, rdbmsDdlGen);
            this->m_convertMap.insert(std::pair<std::string, std::string>(locDbName, "$TSLPERMDB"));
            GEN_GetApplInfo(ApplTempTslDbName, locDbName);
            DdlGenDbi::standardize(locDbName, rdbmsDdlGen);
            this->m_convertMap.insert(std::pair<std::string, std::string>(locDbName, "$TSLTEMPDB"));
        }
        else if (this->m_useAlternativeDataServer == true && EV_SourceCfgFile != nullptr && EV_TargetCfgFile != nullptr)
        {
            this->mainDbSqlName.clear();
            this->loginDbSqlName.clear();
            this->defDdlDestDbName.clear();
            this->defDdlDestDbName.clear();

            for (auto it = EV_SourceCfgFile->dbSectionMap.begin(); it != EV_SourceCfgFile->dbSectionMap.end(); ++it)
            {
                auto targetDb = EV_TargetCfgFile->dbSectionMap.find(it->first);

                if (targetDb != EV_TargetCfgFile->dbSectionMap.end())
                {
                    std::string sourceDbName;
                    if (this->m_rdbmsEn == Sqlite)
                    {
                        sourceDbName = targetDb->second.dbFct;
                        this->m_parentContext->m_convertMap.insert(std::pair<std::string, std::string>(it->second.dbSqlName, sourceDbName));
                    }
                    else
                    {
                        sourceDbName = it->second.dbSqlName;
                        DdlGenDbi::standardize(sourceDbName, EV_SourceRdbmsVendor);
                    }
                    std::string targetDbName = targetDb->second.dbSqlName;
                    DdlGenDbi::standardize(targetDbName, EV_TargetRdbmsVendor);

                    this->m_parentContext->m_convertMap.insert(std::pair<std::string, std::string>(targetDbName, sourceDbName));
                    this->m_parentContext->m_convertMap.insert(std::pair<std::string, std::string>(targetDb->second.dbSqlName, sourceDbName));
                }
            }
        }
        else if (this->m_rdbmsEn == Sqlite)
        {
            for (auto it = EV_SourceCfgFile->dbSectionMap.begin(); it != EV_SourceCfgFile->dbSectionMap.end(); ++it)
            {
                if (EV_TargetCfgFile != nullptr)
                {
                    auto targetDb = EV_TargetCfgFile->dbSectionMap.find(it->first);

                    if (targetDb != EV_TargetCfgFile->dbSectionMap.end())
                    {
                        this->m_parentContext->m_convertMap.insert(std::pair<std::string, std::string>(targetDb->second.dbSqlName, targetDb->second.dbFct));
                    }
                }
                else
                {
                    this->m_parentContext->m_convertMap.insert(std::pair<std::string, std::string>(it->second.dbSqlName, it->second.dbFct));
                }
            }
        }
    }

    auto convIter = this->m_parentContext->m_convertMap.find(strToConvert);
    if (convIter != this->m_parentContext->m_convertMap.end())
    {
        strToConvert = convIter->second;
    }
}

/************************************************************************
**
**  Function    :   DdlGenContext::fillDictEntityFromXdIdMap()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37366 - LJE - 200324
**
*************************************************************************/
void DdlGenContext::fillDictEntityFromXdIdMap()
{
    for (auto it = DICT_GetDictEntityVector().begin(); it != DICT_GetDictEntityVector().end(); ++it)
    {
        if ((*it)->xdEntityId != 0)
        {
            this->m_parentContext->m_entityXdDictIdMap.insert(std::make_pair((*it)->xdEntityId, *it));
        }
    }
}

/************************************************************************
**
**  Function    :   DdlGenContext::fillForcedSegment()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37366 - LJE - 200324
**
*************************************************************************/
void DdlGenContext::fillForcedSegment()
{
    if (this->m_forceTbSeg.empty() == false ||
        this->m_forceIdxSeg.empty() == false)
    {
        MemoryPool          mp;
        DbiConnectionHelper dbiConnHelper(&this->ddlGenContextPtr->getDbiConn());
        DBA_DYNFLD_STP aDictSegmentStp = mp.allocDynst(FILEINFO, A_DictSegment);
        DBA_DYNFLD_STP aDictDatabaseStp = mp.allocDynst(FILEINFO, A_DictDatabase);

        if (this->m_forceTbSeg.empty() == false)
        {
            SET_CODE(aDictSegmentStp, A_DictSegment_Code, this->m_forceTbSeg.c_str());
            if (dbiConnHelper.dbaGet(DictSegment, UNUSED, aDictSegmentStp, &aDictSegmentStp) == RET_SUCCEED)
            {
                this->ddlGenContextPtr->m_forceTbSegSqlName = GET_SYSNAME(aDictSegmentStp, A_DictSegment_SqlName);

                SET_DICT(aDictDatabaseStp, A_DictDatabase_DictId, GET_DICT(aDictSegmentStp, A_DictSegment_DbDictId));
                if (dbiConnHelper.dbaGet(DictDatabase, UNUSED, aDictDatabaseStp, &aDictDatabaseStp) == RET_SUCCEED)
                {
                    this->ddlGenContextPtr->m_forceTbDbSqlName = GET_SYSNAME(aDictDatabaseStp, A_DictDatabase_SqlName);
                }
            }
        }

        if (this->m_forceIdxSeg.empty() == false)
        {
            SET_CODE(aDictSegmentStp, A_DictSegment_Code, this->m_forceIdxSeg.c_str());
            if (dbiConnHelper.dbaGet(DictSegment, UNUSED, aDictSegmentStp, &aDictSegmentStp) == RET_SUCCEED)
            {
                this->ddlGenContextPtr->m_forceIdxSegSqlName = GET_SYSNAME(aDictSegmentStp, A_DictSegment_SqlName);

                SET_DICT(aDictDatabaseStp, A_DictDatabase_DictId, GET_DICT(aDictSegmentStp, A_DictSegment_DbDictId));
                if (dbiConnHelper.dbaGet(DictDatabase, UNUSED, aDictDatabaseStp, &aDictDatabaseStp) == RET_SUCCEED)
                {
                    this->ddlGenContextPtr->m_forceIdxDbSqlName = GET_SYSNAME(aDictDatabaseStp, A_DictDatabase_SqlName);
                }
            }
        }
    }
}

/************************************************************************
**
**  Function    :   DdlGenContext::addDictEntityByXdId()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37366 - LJE - 200324
**
*************************************************************************/
void DdlGenContext::addDictEntityByXdId(ID_T xdId, DICT_ENTITY_STP dictEntityStp)
{
    if (xdId != 0)
    {
        this->m_parentContext->m_entityXdDictIdMap.insert(std::make_pair(xdId, dictEntityStp));
    }
}

/************************************************************************
**
**  Function    :   DdlGenContext::getDictEntityFromXdId()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37366 - LJE - 200324
**
*************************************************************************/
DICT_ENTITY_STP DdlGenContext::getDictEntityFromXdId(ID_T xdId)
{
    auto entIt = this->m_parentContext->m_entityXdDictIdMap.find(xdId);

    if (entIt != this->m_parentContext->m_entityXdDictIdMap.end())
    {
        return entIt->second;
    }

    return nullptr;
}

/************************************************************************
**
**  Function    :   DdlGenContext::addDictAttribFromXdIdMap()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37366 - LJE - 200324
**
*************************************************************************/
void DdlGenContext::addDictAttribFromXdId(ID_T xdId, DICT_ATTRIB_STP dictAttribStp)
{
    if (xdId != 0)
    {
        this->m_parentContext->m_attribXdDictIdMap.insert(std::make_pair(xdId, dictAttribStp));
    }
}

/************************************************************************
**
**  Function    :   DdlGenContext::getDictAttribFromXdId()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37366 - LJE - 200324
**
*************************************************************************/
DICT_ATTRIB_STP DdlGenContext::getDictAttribFromXdId(ID_T xdId)
{
    auto entIt = this->m_parentContext->m_attribXdDictIdMap.find(xdId);

    if (entIt != this->m_parentContext->m_attribXdDictIdMap.end())
    {
        return entIt->second;
    }

    return nullptr;
}


/************************************************************************
**
**  Function    :   DdlGenContext::initFromIniFile()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-52689 - LJE - 230411
**
*************************************************************************/
void DdlGenContext::initFromIniFile()
{
    if (EV_GenDdlContext.inputPtr != nullptr)
    {
        const QString iniFile(EV_GenDdlContext.inputPtr);
        QFileInfo file(iniFile);

        if (file.exists())
        { // found
            auto configFileName = file.canonicalFilePath();

            this->printMsg(RET_DBA_INFO_EXIST, SYS_Stringer("Using config file: ", std::string(configFileName.toLocal8Bit().data())));

            QSettings  settings(iniFile, QSettings::IniFormat);

            {
                settings.beginGroup("filter");
                const QStringList childKeys = settings.childKeys();
                foreach(const QString & childKey, childKeys)
                    this->m_migFilterMap[childKey.toStdString()] = settings.value(childKey).toString().toLocal8Bit().constData();
                settings.endGroup();
            }
            {
                settings.beginGroup("database");
                const QStringList childKeys = settings.childKeys();
                foreach(const QString & childKey, childKeys)
                    this->m_migDatabaseMap[childKey.toStdString()] = settings.value(childKey).toString().toLocal8Bit().constData();
                settings.endGroup();
            }
            {
                settings.beginGroup("table");
                const QStringList childKeys = settings.childKeys();
                foreach(const QString & childKey, childKeys)
                    this->m_migTableMap[childKey.toStdString()] = settings.value(childKey).toString().toLocal8Bit().constData();
                settings.endGroup();
            }
            {
                settings.beginGroup("column");
                const QStringList childKeys = settings.childKeys();
                foreach(const QString & childKey, childKeys)
                {
                    std::vector<std::string> tokens;
                    DdlGen::tokenizeStr(tokens, childKey.toStdString(), ".");

                    if (tokens.size() == 2)
                    {
                        this->m_migColumnMap[tokens[0]][tokens[1]] = settings.value(childKey).toString().toLocal8Bit().constData();
                    }
                }
                settings.endGroup();
            }
        }
        else
        {
            std::ostringstream errorMessage;
            errorMessage << "Cannot find config file " << qPrintable(iniFile);
            this->printMsg(RET_FILE_ERR_IO, errorMessage.str());
        }
    }
}

/************************************************************************
**
**  Function    :   DdlGenContext::initEntityToMigrate()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37374 - LJE - 210416
**
*************************************************************************/
void DdlGenContext::initEntityToMigrate()
{
    if (this->m_parentContext->m_migSkippedEntities.empty())
    {
        auto allIt = this->m_migTableMap.find("all");
        if (allIt == this->m_migTableMap.end() ||
            allIt->second == "std")
        {
            if (this->m_rdbmsEn != Sqlite)
            {
                this->m_parentContext->m_migSkippedEntities.insert("dict_user");
                this->m_parentContext->m_migSkippedEntities.insert("dict_database");
                this->m_parentContext->m_migSkippedEntities.insert("dict_segment");
            }

            this->m_parentContext->m_migSkippedEntities.insert("dict_depends");
            this->m_parentContext->m_migSkippedEntities.insert("dict_sproc");
            this->m_parentContext->m_migSkippedEntities.insert("dict_sproc_param");
            this->m_parentContext->m_migSkippedEntities.insert("dict_sproc_returns");
            this->m_parentContext->m_migSkippedEntities.insert("dict_view");
            this->m_parentContext->m_migSkippedEntities.insert("dict_datatype");

            this->m_parentContext->m_migSkippedEntities.insert("tasc_job");
            this->m_parentContext->m_migSkippedEntities.insert("tasc_job_table");
            this->m_parentContext->m_migSkippedEntities.insert("tasc_prec_execution");
            this->m_parentContext->m_migSkippedEntities.insert("tasc_prec_modif_stat");
            this->m_parentContext->m_migSkippedEntities.insert("tasc_logger");
            this->m_parentContext->m_migSkippedEntities.insert("tasc_validity");
            this->m_parentContext->m_migSkippedEntities.insert("tasc_invalidation");
            this->m_parentContext->m_migSkippedEntities.insert("tasc_global_recomp_obj");
            this->m_parentContext->m_migSkippedEntities.insert("tasc_entity_recomp_obj");
            this->m_parentContext->m_migSkippedEntities.insert("tasc_search_recomp_obj");

            this->m_parentContext->m_migSkippedEntities.insert("jobl_event");
            this->m_parentContext->m_migSkippedEntities.insert("jobl_job_instance");
            this->m_parentContext->m_migSkippedEntities.insert("jobl_job_chunk");
            this->m_parentContext->m_migSkippedEntities.insert("jobl_job_instance_params");
            this->m_parentContext->m_migSkippedEntities.insert("jobl_step");
            this->m_parentContext->m_migSkippedEntities.insert("otf_monitoring");
            this->m_parentContext->m_migSkippedEntities.insert("jobl_id");
            this->m_parentContext->m_migSkippedEntities.insert("tsl_table_cache");
            this->m_parentContext->m_migSkippedEntities.insert("tasc_irl_recomp_obj");

            this->m_parentContext->m_migSkippedEntities.insert("alert_def_obj");

            this->m_parentContext->m_migSkippedEntities.insert("notif_instance");
            this->m_parentContext->m_migSkippedEntities.insert("notif_subject_body");
            this->m_parentContext->m_migSkippedEntities.insert("notif_recipient");

            this->m_parentContext->m_migSkippedEntities.insert("instrument_recomm_level");

            this->m_parentContext->m_migSkippedEntities.insert("audit");
            this->m_parentContext->m_migSkippedEntities.insert("event");

            this->m_parentContext->m_migSkippedEntities.insert("appl_session");
            this->m_parentContext->m_migSkippedEntities.insert("appl_session_histo");

            this->m_parentContext->m_migSkippedEntities.insert("login_history");
            this->m_parentContext->m_migSkippedEntities.insert("login_failed");

            this->m_parentContext->m_migSkippedEntities.insert("server_running");
        }
        else if (allIt->second == "no")
        {
            for (OBJECT_ENUM currObj = 0; currObj <= LASTENTITYOBJECT; currObj++)
            {
                DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(currObj);

                if (dictEntityStp != nullptr && dictEntityStp->mdSqlName[0] != 0)
                {
                    this->m_parentContext->m_migSkippedEntities.insert(dictEntityStp->mdSqlName);
                }
            }

            for (auto dbIt = this->m_parentContext->tablesFromSrcSysMap.begin(); dbIt != this->m_parentContext->tablesFromSrcSysMap.end(); ++dbIt)
            {
                for (auto tbIt = dbIt->second.begin(); tbIt != dbIt->second.end(); ++tbIt)
                {
                    this->m_parentContext->m_migSkippedEntities.insert(tbIt->first);
                }
            }
        }

        for (auto it = this->m_parentContext->m_migTableMap.begin(); it != this->m_parentContext->m_migTableMap.end(); ++it)
        {
            if (it->second == "no")
            {
                this->m_parentContext->m_migSkippedEntities.insert(it->first);
            }
            else if (it->second == "yes")
            {
                this->m_parentContext->m_migSkippedEntities.erase(it->first);
            }
        }

        this->m_parentContext->m_migDatabaseMap.insert(std::make_pair("AAALOGIN_DB", "yes"));
        this->m_parentContext->m_migDatabaseMap.insert(std::make_pair("AAAMAIN_DB", "yes"));
        this->m_parentContext->m_migDatabaseMap.insert(std::make_pair("AAAREP_DB", "no"));
        this->m_parentContext->m_migDatabaseMap.insert(std::make_pair("TSL_PERM_DB", "no"));
        this->m_parentContext->m_migDatabaseMap.insert(std::make_pair("TSL_TEMP_DB", "no"));

        if (EV_TargetCfgFile != nullptr)
        {
            for (auto it = EV_TargetCfgFile->dbSectionMap.begin(); it != EV_TargetCfgFile->dbSectionMap.end(); ++it)
            {
                auto dbIt = this->m_parentContext->m_migDatabaseMap.find(it->first);
                if (dbIt != this->m_parentContext->m_migDatabaseMap.end())
                {
                    this->m_parentContext->m_migDatabaseMap.insert(std::make_pair(it->second.dbSqlName, dbIt->second));
                }
            }
        }
    }
}

/************************************************************************
**
**  Function    :   DdlGenContext::isEntityToMigrate()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37374 - LJE - 210416
**
*************************************************************************/
bool DdlGenContext::isEntityToMigrate(DICT_ENTITY_STP sourceDictEntityStp, DICT_ENTITY_STP targetDictEntityStp, TARGET_TABLE_ENUM targetTableEn)
{
    if (targetDictEntityStp == nullptr ||
        targetDictEntityStp->dbRuleEn == DbRule_NotInDatabase ||
        (targetDictEntityStp->dbRuleEn == DbRule_NotMainTable && targetTableEn == TargetTable_Main) ||
        (targetDictEntityStp->dbRuleEn == DbRule_OnlyMainTable && targetTableEn == TargetTable_UserDefinedFields) ||
        targetDictEntityStp->entNatEn == EntityNat_TempTable)
    {
        return false;
    }
    auto databaseName = targetDictEntityStp->databaseName;

    if (targetDictEntityStp->dbRuleEn == DbRule_TableBasedOnView &&
        sourceDictEntityStp != nullptr &&
        sourceDictEntityStp->dbRuleEn != DbRule_TableBasedOnView)
    {
        databaseName = sourceDictEntityStp->databaseName;

        if (EV_SourceCfgFile != nullptr)
        {
            for (auto it = EV_SourceCfgFile->dbSectionMap.begin(); it != EV_SourceCfgFile->dbSectionMap.end(); ++it)
            {
                if (it->second.dbSqlName == databaseName)
                {
                    databaseName = it->first;
                    break;
                }
            }
        }
    }

    if (databaseName.empty())
    {
        return false;
    }

    if (targetTableEn != TargetTable_Precomp &&
        this->m_parentContext->ddlGenAction.m_bSingleEntity &&
        this->m_parentContext->ddlGenAction.m_entitySqlnameStr.empty() == false)
    {
        return true;
    }

    if (targetTableEn == TargetTable_Precomp ||
        targetDictEntityStp->entNatEn == EntityNat_SearchFmt ||
        targetDictEntityStp->entNatEn == EntityNat_PersistedFmt)
    {
        auto dbIt = this->m_parentContext->m_migDatabaseMap.find("TSL_PERM_DB");
        if (dbIt == this->m_parentContext->m_migDatabaseMap.end() ||
            dbIt->second == "no")
        {
            return false;
        }
    }

    if (targetTableEn == TargetTable_Main)
    {
        auto dbIt = this->m_parentContext->m_migDatabaseMap.find(databaseName);
        if (dbIt == this->m_parentContext->m_migDatabaseMap.end() ||
            dbIt->second == "no")
        {
            return false;
        }
    }

    if (targetDictEntityStp->entNatEn == EntityNat_ReportFmt)
    {
        auto dbIt = this->m_parentContext->m_migDatabaseMap.find("AAAREP_DB");
        if (dbIt == this->m_parentContext->m_migDatabaseMap.end() ||
            dbIt->second == "no")
        {
            return false;
        }
    }

    if (strstr(targetDictEntityStp->mdSqlName, "QRTZ_") == targetDictEntityStp->mdSqlName ||
        targetDictEntityStp->dbRuleEn == DbRule_VolatileTable)
    {
        return false;
    }

    if (targetDictEntityStp->bIsInitEntity && this->isEntityToMigrate("dict") == false)
    {
        return false;
    }

    return this->isEntityToMigrate(targetDictEntityStp->mdSqlName);
}

/************************************************************************
**
**  Function    :   DdlGenContext::isEntityToMigrate()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-52689 - LJE - 210416
**
*************************************************************************/
bool DdlGenContext::isEntityToMigrate(const std::string &sqlName)
{
    return this->m_parentContext->m_migSkippedEntities.find(sqlName) == this->m_parentContext->m_migSkippedEntities.end();
}

/************************************************************************
**
**  Function    :   DdlGenContext::getFilterScript()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-52689 - LJE - 210416
**
*************************************************************************/
std::string DdlGenContext::getFilterScript(DICT_ENTITY_STP dictEntityStp)
{
    auto filterIt = this->m_parentContext->m_migFilterMap.find(dictEntityStp->mdSqlName);

    if (filterIt != this->m_parentContext->m_migFilterMap.end())
    {
        return filterIt->second;
    }

    return std::string();
}

/************************************************************************
**
**  Function    :   DdlGenContext::getColumnScript()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-52689 - LJE - 210416
**
*************************************************************************/
std::map<std::string, std::string> DdlGenContext::getColumnScript(const std::string &sqlName)
{
    auto columnsIt = this->m_parentContext->m_migColumnMap.find(sqlName);

    if (columnsIt != this->m_parentContext->m_migColumnMap.end())
    {
        return columnsIt->second;
    }

    std::map<std::string, std::string> emptyMap;
    return emptyMap;
}

/************************************************************************
**
**  Function    :   DdlGenContext::readLock()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37366 - LJE - 200326
**
*************************************************************************/
void DdlGenContext::readLock()
{
    if (this->m_parentContext != this)
    {
        if (this->m_parentContext->m_rwLock == nullptr)
        {
            this->m_parentContext->m_rwLock = SYS_CreateRWLock(FILEINFO);
        }

        SYS_LockRW_Read(this->m_parentContext->m_rwLock, FILEINFO);
    }
}

/************************************************************************
**
**  Function    :   DdlGenContext::readUnlock()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37366 - LJE - 200326
**
*************************************************************************/
void DdlGenContext::readUnlock()
{
    if (this->m_parentContext != this && this->m_parentContext->m_rwLock != nullptr)
    {
        SYS_UnLockRW_Read(this->m_parentContext->m_rwLock, FILEINFO);
    }
}

/************************************************************************
**
**  Function    :   DdlGenContext::writeLock()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37366 - LJE - 200326
**
*************************************************************************/
void DdlGenContext::writeLock()
{
    if (this->m_parentContext != this)
    {
        if (this->m_parentContext->m_rwLock == nullptr)
        {
            this->m_parentContext->m_rwLock = SYS_CreateRWLock(FILEINFO);
        }

        SYS_LockRW_Write(this->m_parentContext->m_rwLock, FILEINFO);
    }
}

/************************************************************************
**
**  Function    :   DdlGenContext::writeUnlock()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37366 - LJE - 200326
**
*************************************************************************/
void DdlGenContext::writeUnlock()
{
    if (this->m_parentContext != this && this->m_parentContext->m_rwLock != nullptr)
    {
        SYS_UnLockRW_Write(this->m_parentContext->m_rwLock, FILEINFO);
    }
}

/************************************************************************
**
**  Function    :   DdlGenContext::isProcToGenerate()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45560 - LJE - 210622
**
*************************************************************************/
bool DdlGenContext::isProcToGenerate(const std::string &procSqlName, const std::string &procEntitySqlName)
{
    this->readLock();

    bool bToDo = true;

    if (this->m_parentContext != nullptr &&
        this->m_parentContext->depSprocSqlNameSet.empty() == false &&
        this->m_parentContext->depSprocSqlNameSet.find(procSqlName) == this->m_parentContext->depSprocSqlNameSet.end())
    {
        bToDo = false;
    }

    if (bToDo == false)
    {
        if (this->m_parentContext != nullptr &&
            this->m_parentContext->toInsertEntitySqlNameSet.empty() == false &&
            this->m_parentContext->toInsertEntitySqlNameSet.find(procEntitySqlName) != this->m_parentContext->toInsertEntitySqlNameSet.end())
        {
            bToDo = true;
        }
    }

    this->readUnlock();

    return bToDo;
}

/************************************************************************
**
**  Function    :   DdlGenContext::getBuildDate()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-33077 - LJE - 181025
**
*************************************************************************/
DATETIME_T DdlGenContext::getBuildDate()
{
    if (this->buildDate.date == 0)
    {
        DBA_GetDbDate(&this->buildDate);
    }

    return this->buildDate;
}

/************************************************************************
**
**  Function    :   DdlGenConnGuard::DdlGenConnGuard()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-49178 - LJE - 221128
**
*************************************************************************/
DdlGenConnGuard::DdlGenConnGuard(DdlGenContext& ddlGenContext)
    : m_ddlGenContext(ddlGenContext)
    , m_isConnInit(ddlGenContext.m_dbiConn != nullptr)
    , m_isConnForDdlInit(ddlGenContext.m_dbiConnForDdl != nullptr)
    , m_extDbiConn(ddlGenContext.m_parentContext->m_extDbiConn)
{
}

/************************************************************************
**
**  Function    :   DdlGenConnGuard::~DdlGenConnGuard()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-49178 - LJE - 221128
**
*************************************************************************/
DdlGenConnGuard::~DdlGenConnGuard()
{
    if (this->m_isConnForDdlInit == false &&
        this->m_ddlGenContext.m_dbiConnForDdl != nullptr &&
        (this->m_ddlGenContext.m_dbiConn == nullptr ||
         this->m_ddlGenContext.m_dbiConn != this->m_ddlGenContext.m_dbiConnForDdl))
    {
        DBA_EndConnection(&(this->m_ddlGenContext.m_dbiConnForDdl), false);
    }

    if (this->m_isConnInit == false &&
        this->m_ddlGenContext.m_dbiConn != nullptr)
    {
        this->m_ddlGenContext.endConnection();
    }

    if (this->m_ddlGenContext.isMultiThreadMode() == false)
    {
        this->m_ddlGenContext.m_parentContext->m_extDbiConn = this->m_extDbiConn;
    }
}

/************************************************************************
**
**  Function    :   DdlGenConnGuard::getDbiConn()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-49178 - LJE - 221128
**
*************************************************************************/
DbiConnection& DdlGenConnGuard::getDbiConn()
{
    return this->m_ddlGenContext.getDbiConn();
}

/************************************************************************
**
**  Function    :   DdlGenConnGuard::getDbiConnForDdl()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-49178 - LJE - 221128
**
*************************************************************************/
DbiConnection& DdlGenConnGuard::getDbiConnForDdl()
{
    return this->m_ddlGenContext.getDbiConnForDdl();
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccessGuard::DdlGenDbaAccessGuard()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-49178 - LJE - 221128
**
*************************************************************************/
DdlGenDbaAccessGuard::DdlGenDbaAccessGuard(DdlGenContext& ddlGenContext)
    : m_ddlGenContext(ddlGenContext)
{
    this->m_ddlGenContext.getDdlGenDbaAccess().m_lock.lock();
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccessGuard::~DdlGenDbaAccessGuard()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-49178 - LJE - 221128
**
*************************************************************************/
DdlGenDbaAccessGuard::~DdlGenDbaAccessGuard()
{
    this->m_ddlGenContext.getDdlGenDbaAccess().m_lock.unlock();
}

/************************************************************************
**
**  Function    :   DdlGenDbaAccessGuard::getDdlGenDbaAccessPtr()
**
**  Description :
**
**
**  Return      :
**
**  Creation  	:   PMSTA-49178 - LJE - 221128
**
*************************************************************************/
DdlGenDbaAccess& DdlGenDbaAccessGuard::getDdlGenDbaAccess()
{
    return this->m_ddlGenContext.getDdlGenDbaAccess();
}

/************************************************************************
**
**  Function    :   DdlGenBatchMultiGuard::DdlGenBatchMultiGuard()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-46681 - LJE - 240423
**
*************************************************************************/
DdlGenBatchMultiGuard::DdlGenBatchMultiGuard(DdlGenContext& ddlGenContext)
    : m_ddlGenContext(ddlGenContext)
{
    this->m_ddlGenContext.startBatchMulti();
}

/************************************************************************
**
**  Function    :   DdlGenBatchMultiGuard::~DdlGenBatchMultiGuard()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-46681 - LJE - 240423
**
*************************************************************************/
DdlGenBatchMultiGuard::~DdlGenBatchMultiGuard()
{
    this->m_ddlGenContext.closeBatchMulti();
}

/************************************************************************
**
**  Function    :   DdlGenJoin()
**
**  Description :   Constructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
DdlGenJoin::DdlGenJoin()
{
    this->joinDictEntityStp = NULL;
    this->firstIdPos = 0;
    this->isNullFirstId = true;
    this->secondIdPos = 0;
    this->isNullSecondId = true;
    this->securityLevelEn = EntSecuLevel_NoSecured;
    this->codifFlg = 0;
    this->mandatoryFlg = 0;
    this->parentEntDictId = 0;
    this->objectEn = NullEntity;
    this->sortJoin = 0;
    this->parentJoinStp = NULL;
    this->joinTypeEn = DDlJoinType_None;
    this->dictAttribStp = NULL;
}

DdlGenJoin::DdlGenJoin(const DdlGenJoin& toCopy)
{
    this->joinDictEntityStp = toCopy.joinDictEntityStp;
    this->joinEntitySqlName = toCopy.joinEntitySqlName;
    this->joinSqlName       = toCopy.joinSqlName;
    this->dictAttribStp     = toCopy.dictAttribStp;
    this->firstIdPos        = toCopy.firstIdPos;
    this->isNullFirstId     = toCopy.isNullFirstId;
    this->secondIdPos       = toCopy.secondIdPos;
    this->isNullSecondId    = toCopy.isNullSecondId;
    this->securityLevelEn   = toCopy.securityLevelEn;
    this->codifFlg          = toCopy.codifFlg;
    this->mandatoryFlg      = toCopy.mandatoryFlg;
    this->parentEntDictId   = toCopy.parentEntDictId;
    this->objectEn          = toCopy.objectEn;
    this->sortJoin          = toCopy.sortJoin;
    this->parentJoinStp     = toCopy.parentJoinStp;
    this->joinTypeEn        = toCopy.joinTypeEn;
    this->addJoinInfoStr    = toCopy.addJoinInfoStr;
}


/************************************************************************
**
**  Function    :   ~DdlGenJoin()
**
**  Description :   Destructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
DdlGenJoin::~DdlGenJoin()
{
}

DdlGenJoin& DdlGenJoin::operator= (const DdlGenJoin& toCopy)
{
    this->joinDictEntityStp = toCopy.joinDictEntityStp;
    this->joinEntitySqlName = toCopy.joinEntitySqlName;
    this->joinSqlName = toCopy.joinSqlName;
    this->dictAttribStp = toCopy.dictAttribStp;
    this->firstIdPos = toCopy.firstIdPos;
    this->isNullFirstId = toCopy.isNullFirstId;
    this->secondIdPos = toCopy.secondIdPos;
    this->isNullSecondId = toCopy.isNullSecondId;
    this->securityLevelEn = toCopy.securityLevelEn;
    this->codifFlg = toCopy.codifFlg;
    this->mandatoryFlg = toCopy.mandatoryFlg;
    this->parentEntDictId = toCopy.parentEntDictId;
    this->objectEn = toCopy.objectEn;
    this->sortJoin = toCopy.sortJoin;
    this->parentJoinStp = toCopy.parentJoinStp;
    this->joinTypeEn = toCopy.joinTypeEn;
    this->addJoinInfoStr = toCopy.addJoinInfoStr;
    return *this;
}

/************************************************************************
**
**  Function    :   operator<()
**
**  Description :   operator
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14607 - LJE - 120720
**
*************************************************************************/
bool DdlGenJoin::operator< (const DdlGenJoin & a) const
{
    return this->sortJoin < a.sortJoin;
}

/************************************************************************
**
**  Function    :   DdlGen()
**
**  Description :   Constructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
DdlGen::DdlGen(OBJECT_ENUM         paramObjectEn,
               DDL_OBJ_ENUM        paramDdlObjEn,
               DdlGenContext      &paramDdlGenContext,
               DdlGenVarHelper    *paramVarHelperPtr,
               DdlGenEntity       *paramDdlGenEntityPtr,
               DdlGenFile         *paramFileHelper,
               TARGET_TABLE_ENUM   paramTargetTableEn):DdlGenDbi(paramDdlObjEn, paramDdlGenContext, paramVarHelperPtr, paramFileHelper, paramTargetTableEn)
{
    this->securityLevelEn = EntSecuLevel_NoSecured;
    /* OCS-39654 - LJE - 120213 */
    this->thirdSecuredFlg = FALSE;
    this->thirdCompoSecuredFlg = FALSE;

    this->secuMandatoryFlg = TRUE; /* OCS-38989 - LJE - 110927 */
    this->translateFlg = FALSE;

    this->denomFlg = FALSE;
    this->labelFlg = FALSE;

    this->custFlg             = FALSE;
    this->precompFlg          = FALSE;
    this->bHidePrecomp        = false;
    this->onlyPhysicalFlg     = FALSE;
    this->bShadowAccess       = false;       /* PMSTA-26250 - LJE - 170327 */
    this->mulitEntityAccessEn = MultiEntityAccess_None;    /* PMSTA-32145 - LJE - 180718 */

    this->setAlias(std::string("E"));

    this->m_bWherePrinted    = false;
    this->bOnJoin          = false;
    this->m_joinCpt        = 0;
    this->bSelectPrinted   = false;
    this->bUserJoinPrint   = false;

    this->bKeepRealObject = false;
    this->realObjectEn = NullEntity;
    this->realDictEntityStp = NULL;

    this->bAppendFile = false;

    this->m_outputViewEn = View_FullAllSecured;
    this->m_ddlGenFromFileContextPtr = nullptr; /* PMSTA-26108 - LJE - 171106 */

    this->bManageAuthFlg       = false;    /* PMSTA-14607 - LJE - 120712 */
    this->bUserSecured         = false;    /* PMSTA-14607 - LJE - 120712 */
    this->bForceDPInAppContext = false;    /* OCS-41131 - LJE - 120723 */
    this->bForceDPInSuserName  = false;    /* PMSTA-14785 - LJE - 120829 */
    this->bOrderBy             = false;    /* PMSTA-14607 - LJE - 120712 */
    this->bJoinOnFromTag       = false;
    this->bReplaceFromTag      = false;    /* PMSTA-37366 - LJE - 200130 */

    this->bNoIndentReset = false;

    /* PMSTA-26252 - LJE - 170227 */
    this->rowCountVarPtr = nullptr;
    this->errorVarPtr = nullptr;

    /* PMSTA-nuodb - LJE - 190417 */
    this->bPkWhereAccess      = false;
    this->bBkWhereAccess      = false;
    this->outputDynNatEn      = DynType_Null;
    this->m_bAddFieldOnSelect = false;

    this->invalidDictEntitySt.objectEn   = InvalidEntity;
    this->m_dictEntityStp                = &invalidDictEntitySt;
    this->objectEn                       = InvalidEntity;
    this->m_srcDictEntityStp             = nullptr;

    this->cmdType = DDlCmdType_None;

    this->ddlGenEntityPtr = paramDdlGenEntityPtr;

    this->setObjectEn(paramObjectEn);
    this->setDdlObjEn(paramDdlObjEn);

    if (this->ddlGenContextPtr != NULL)
    {
        this->setMsgSqlName(this->ddlGenContextPtr->msgSqlName);

        this->scriptDdlGen = new DdlGenFromFile(DdlObjFromFile_Custom,
                                                this->getObjectEn(),
                                                *this->ddlGenContextPtr,
                                                this->ddlGenEntityPtr,
                                                this,
                                                true,
                                                this->varHelperPtr,
                                                this->fileHelper);

        this->scriptDdlGen->bPrintUserAssgn = false;
    }
    else
    {
        this->scriptDdlGen = NULL;
    }

    this->securityTemplate = nullptr; /* PMSTA-24007 - LJE - 161229 */

    /* PMSTA-26108 - LJE - 171103 */
    this->bSubDdlGenObj = false;
}

/************************************************************************
**
**  Function    :   DdlGen()
**
**  Description :   Constructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
DdlGen::DdlGen(OBJECT_ENUM                 paramObjectEn,
               DDL_OBJ_ENUM                paramDdlObjEn,
               DBA_DYNTYPE_ENUM            paramOutputDynNatEn,
               FLAG_T                      paramCustFlg,
               FLAG_T                      paramprecompFlg,
               FLAG_T                      paramOnlyPhysicalFlg,
               ENTITY_SECURITY_LEVEL_ENUM  paramSecuLevelEn,
               FLAG_T                      paramTranslateFlg,
               DdlGenContext              &paramDdlGenContext,
               DdlGenVarHelper            *paramVarHelperPtr,
               DdlGenEntity               *paramDdlGenEntityPtr,
               DdlGenFile                 *paramFileHelper,
               TARGET_TABLE_ENUM           paramTargetTableEn)
    : DdlGen(paramObjectEn, paramDdlObjEn, paramDdlGenContext, paramVarHelperPtr, paramDdlGenEntityPtr, paramFileHelper, paramTargetTableEn)
{
    this->init(paramObjectEn,
               paramOutputDynNatEn,
               paramCustFlg,
               paramprecompFlg,
               paramOnlyPhysicalFlg,
               paramSecuLevelEn,
               paramTranslateFlg);

}

/************************************************************************
**
**  Function    :   DdlGen()
**
**  Description :   Constructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26250 - LJE - 170410
**
*************************************************************************/
DdlGen::DdlGen(OBJECT_ENUM     paramObjectEn,
               const DdlGen   &paramDdlGen)
    : DdlGen(paramObjectEn,
             paramDdlGen.m_ddlObjEn,
             *paramDdlGen.ddlGenContextPtr,
             paramDdlGen.varHelperPtr,
             paramDdlGen.ddlGenEntityPtr,
             paramDdlGen.fileHelper,
             paramDdlGen.targetTableEn)
{
    this->bSubDdlGenObj = true;
}

/************************************************************************
**
**  Function    :   DdlGen()
**
**  Description :   Constructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26250 - LJE - 170410
**
*************************************************************************/
DdlGen::DdlGen(OBJECT_ENUM        paramObjectEn,
               TARGET_TABLE_ENUM  paramTargetTableEn,
               DdlGenFromFile    &paramDdlGenFromFile):DdlGen(paramObjectEn,
                                                              paramDdlGenFromFile.outDdlObjEn,
                                                              *paramDdlGenFromFile.ddlGenContextPtr,
                                                              paramDdlGenFromFile.varHelperPtr,
                                                              paramDdlGenFromFile.ddlGenEntityPtr,
                                                              paramDdlGenFromFile.fileHelperPtr,
                                                              paramTargetTableEn)
{
    this->bSubDdlGenObj              = false;
    this->m_ddlGenFromFileContextPtr = paramDdlGenFromFile.context;         /* PMSTA-26108 - LJE - 171106 */
}

/************************************************************************
**
**  Function    :   ~DdlGen()
**
**  Description :   Destructor
**
**  Arguments   :
**
**  Return      :>	aaa_sql64.custom.exe!DdlGen::DdlGen(int paramObjectEn, TARGET_TABLE_ENUM paramTargetTableEn, DdlGenFromFile & paramDdlGenFromFile) Line 4297	C++

**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
DdlGen::~DdlGen()
{
    delete this->scriptDdlGen;

    if (this->ddlGenContextPtr != nullptr &&
        this->bSubDdlGenObj == false &&
        (this->getDdlObjEn() == DdlObj_Table ||
         this->getDdlObjEn() == DdlObj_Index ||
         this->getDdlObjEn() == DdlObj_Constraint ||
         this->getDdlObjEn() == DdlObj_PrimaryKey ||
         this->getDdlObjEn() == DdlObj_ForeignKey))
    {
        this->ddlGenContextPtr->resetContext(std::string());
    }
}

/************************************************************************
**
**  Function    :   DdlGen::init()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
void DdlGen::init(OBJECT_ENUM				    paramObjectEn,
                  DBA_DYNTYPE_ENUM		     	paramOutputDynNatEn,
                  FLAG_T						paramCustFlg,
                  FLAG_T						paramprecompFlg,
                  FLAG_T						paramOnlyPhysicalFlg,
                  ENTITY_SECURITY_LEVEL_ENUM    paramSecuLevelEn,
                  FLAG_T						paramTranslateFlg)
{
    this->outputDynNatEn      = paramOutputDynNatEn;
    this->m_bAddFieldOnSelect = false;
    this->securityLevelEn     = paramSecuLevelEn;
    this->secuMandatoryFlg    = TRUE;
    this->custFlg             = paramCustFlg;
    this->precompFlg          = paramprecompFlg;
    this->onlyPhysicalFlg     = paramOnlyPhysicalFlg;
    this->translateFlg        = paramTranslateFlg;

    this->setObjectEn(paramObjectEn);

    if (paramOutputDynNatEn == DynType_UdOnly ||
        paramOutputDynNatEn == DynType_UdMeSpecOnly)
    {
        this->onlyPhysicalFlg = TRUE;
        this->precompFlg      = FALSE;
        this->custFlg         = TRUE;
    }
    else if (paramOutputDynNatEn == DynType_PrecompOnly)
    {
        this->onlyPhysicalFlg = TRUE;
        this->precompFlg      = TRUE;
        this->custFlg         = FALSE;
    }

    this->initRequest();
}

/************************************************************************
**
**  Function    :   DdlGen::copy()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-29879 - LJE - 180712
**
*************************************************************************/
void DdlGen::copy(const DdlGen &ref)
{
    this->bManageAuthFlg       = ref.bManageAuthFlg;
    this->bNestedRequest       = ref.bNestedRequest;
    this->bUnion               = ref.bUnion;
    this->m_authAlias          = ref.m_authAlias;
    this->targetTableEn        = ref.targetTableEn;
    this->bForceDPInAppContext = ref.bForceDPInAppContext; /* PRO-12675 - LJE - 191204 */

    this->setAlias(ref.getAlias(true));
    this->setPreIndent(ref.getPreIndent());
    this->setIndent(ref.getIndentNbr());

    this->setDdlObjSqlName(ref.getDdlObjSqlName());
    this->setMsgObjType(ref.getMsgObjType());
    this->setMsgEntitySqlName(ref.getMsgEntitySqlName());
    this->setMsgSqlName(ref.getMsgSqlName());
}

/************************************************************************
**
**  Function    :   DdlGen::setDefaultContext()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 150706
**
*************************************************************************/
void DdlGen::setDefaultContext()
{
    if (this->ddlGenContextPtr != nullptr)
    {
        if (this->objectEn != NullEntity &&
            (this->getDdlObjEn() == DdlObj_Table ||
             this->getDdlObjEn() == DdlObj_Index ||
             this->getDdlObjEn() == DdlObj_Constraint ||
             this->getDdlObjEn() == DdlObj_PrimaryKey ||
             this->getDdlObjEn() == DdlObj_ForeignKey))
        {
            if (this->realDbName.empty() == false)
            {
                this->ddlGenContextPtr->setDdlDestDbName(this->realDbName, this);
            }
            if (this->targetTableEn == TargetTable_Precomp)
            {
                this->ddlGenContextPtr->setDdlDestDbName(this->getDictEntityStp()->precompDbName, this);
            }
            else if (this->targetTableEn == TargetTable_UserDefinedFields)
            {
                this->ddlGenContextPtr->setDdlDestDbName(this->getDictEntityStp()->custDbName, this);
            }
            else
            {
                this->ddlGenContextPtr->setDdlDestDbName(this->getDictEntityStp()->databaseName, this);
            }
        }
        else
        {
            this->ddlGenContextPtr->resetContext(this->msgSqlName);
            this->setDdlObjEn(this->getDdlObjEn());
        }
    }
}

/************************************************************************
**
**  Function    :   DdlGen::grant()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-16194 - LJE - 130522
**
*************************************************************************/
RET_CODE DdlGen::grant()
{
    RET_CODE ret = RET_SUCCEED;

    this->cmdType = DDlCmdType_Grant;

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGen::drop()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-16194 - LJE - 130522
**
*************************************************************************/
RET_CODE DdlGen::drop()
{
    RET_CODE ret = RET_SUCCEED;
    return ret;
}

/************************************************************************
*   Function             : DdlGen::find_first_not_of()
*
*   Description          :
*
*   Arguments            :
*
*   Functions call       :
*
*   Return               :
*
*   Creation Date        :
*   Last Modif.          :
*
*************************************************************************/
std::string::size_type DdlGen::find_first_not_of(const std::string &str, const std::string& delimiters, std::string::size_type startPos)
{
    return DdlGen::find_first_of(str, delimiters, startPos, true);
}

/************************************************************************
*   Function             : DdlGen::find_first_of()
*
*   Description          :
*
*   Arguments            :
*
*   Functions call       :
*
*   Return               :
*
*   Creation Date        :
*   Last Modif.          :
*
*************************************************************************/
std::string::size_type DdlGen::find_first_of(const std::string &str, const std::string& delimiters, std::string::size_type startPos, bool bNotOf, bool bAvoidInBracket)
{
    bool bSearchQuote = delimiters.find("'") != std::string::npos;
    bool bSearchDblQuote = delimiters.find("\"") != std::string::npos;

    if (startPos == std::string::npos)
    {
        return startPos;
    }

    std::string::size_type pos, length = str.length();

    for (pos = startPos; pos < length; pos++)
    {
        if (bNotOf && bSearchQuote == false && str[pos] == '\'')
        {
            return pos;
        }

        if (bAvoidInBracket && str[pos] == '(')
        {
            int bracketNbr = 0;
            while (++pos < length)
            {
                if (str[pos] == '(')
                {
                    bracketNbr++;
                }
                if (str[pos] == ')')
                {
                    if (bracketNbr == 0)
                    {
                        break;
                    }
                    bracketNbr--;
                }
            }
            continue;
        }

        if (str[pos] == '\'' && (bSearchQuote == false || (pos + 1 < length && str[pos + 1] == '\'')))
        {
            pos++;

            while (pos < length)
            {
                if (str[pos] == '\'')
                {
                    if ((pos + 1) >= length)
                    {
                        break;
                    }
                    else if (str[pos + 1] != '\'')
                    {
                        break;
                    }
                    else
                    {
                        pos++;
                    }
                }
                pos++;
            }
        }
        else if (str[pos] == '"' && (bSearchDblQuote == false || (pos + 1 < length && str[pos + 1] == '"')))
        {
            pos++;

            while (pos < length)
            {
                if (str[pos] == '"')
                {
                    if ((pos + 1) >= length)
                    {
                        break;
                    }
                    else if (str[pos + 1] != '\\')
                    {
                        break;
                    }
                    else
                    {
                        pos++;
                    }
                }
                pos++;
            }
        }
        else if ((pos + 1) < length)
        {
            if (str[pos] == '-' && str[pos + 1] == '-' && delimiters.compare("-") != 0)
            {
                while (pos < length)
                {
                    if (str[pos] == '\n')
                    {
                        break;
                    }
                    pos++;
                }
            }
            else if (str[pos] == '/' && str[pos + 1] == '*')
            {
                while (pos < length)
                {
                    if ((pos + 1) < length && str[pos] == '*' && str[pos + 1] == '/')
                    {
                        pos += 2;

                        if (pos >= length)
                        {
                            return std::string::npos;
                        }
                        break;
                    }
                    pos++;
                }
            }
        }

        if (delimiters.find(str[pos]) != std::string::npos)
        {
            if (bNotOf == false)
            {
                return pos;
            }
        }
        else if (bNotOf)
        {
            return pos;
        }
    }

    if (pos >= length)
    {
        pos = std::string::npos;
    }

    return pos;
}

/************************************************************************
*   Function             : DdlGen::find_word()
*
*   Description          :
*
*   Arguments            :
*
*   Functions call       :
*
*   Return               :
*
*   Creation Date        :
*   Last Modif.          :
*
*************************************************************************/
std::string::size_type DdlGen::find_word(const std::string      &str,
                                    const std::string      &findStr,
                                    std::string::size_type  startPos,
                                    std::string::size_type  endPos,
                                    const std::string &specWordDelimiter,
                                    bool               bAvoidInBracket)
{
    const static std::string stdWordDelimiter = " \t\n().,;[]";

    const std::string &wordDelimiter = specWordDelimiter.empty() ? stdWordDelimiter : specWordDelimiter;

    if (startPos == std::string::npos)
    {
        return startPos;
    }

    std::string::size_type pos;

    if (endPos == std::string::npos)
    {
        endPos = str.length();
    }

    for (pos = startPos; pos <= endPos; pos++)
    {
        if (bAvoidInBracket && str[pos] == '(')
        {
            int bracketNbr = 0;
            while (++pos < endPos)
            {
                if (str[pos] == '(')
                {
                    bracketNbr++;
                }
                else if (str[pos] == ')')
                {
                    if (bracketNbr == 0)
                    {
                        break;
                    }
                    bracketNbr--;
                }
            }
            continue;
        }

        if ((findStr[0] == str[pos] || (toupper(findStr[0]) == toupper(str[pos]))) &&
            (pos == 0 || wordDelimiter.find(str[pos - 1]) != std::string::npos))
        {
            std::string::size_type findPos = 1, seekPos = pos + 1;
            while (seekPos <= endPos &&
                   findPos < findStr.length() &&
                   (findStr[findPos] == str[seekPos] || (toupper(findStr[findPos]) == toupper(str[seekPos]))))
            {
                seekPos++;
                findPos++;
            }
            if (findPos == findStr.length() &&
                (seekPos >= endPos || wordDelimiter.find(str[seekPos]) != std::string::npos))
            {
                return pos;
            }
        }

        if (str[pos] == '\'')
        {
            pos++;
            while (pos <= endPos)
            {
                if (str[pos] == '\'')
                {
                    if ((pos + 1) <= endPos && str[pos + 1] == '\'')
                    {
                        pos++;
                    }
                    else
                    {
                        break;
                    }
                }
                pos++;
            }
        }
        else if ((pos + 1) <= endPos)
        {
            if (str[pos] == '-' && str[pos + 1] == '-')
            {
                if (findStr == "--")
                {
                    break;
                }

                while (pos <= endPos)
                {
                    if (str[pos] == '\n')
                    {
                        break;
                    }
                    pos++;
                }
            }
            else if (str[pos] == '/' && str[pos + 1] == '*')
            {
                while (pos <= endPos)
                {
                    if ((pos + 1) <= endPos && str[pos] == '*' && str[pos + 1] == '/')
                    {
                        break;
                    }
                    pos++;
                }
            }
        }
    }

    if (pos > endPos)
    {
        pos = std::string::npos;
    }

    return pos;
}

/************************************************************************
*   Function             : DdlGen::getNextKeyWord()
*
*   Description          :
*
*   Arguments            :
*
*   Functions call       :
*
*   Return               :
*
*   Creation Date        :
*   Last Modif.          :
*
************************************************************************/
std::string DdlGen::getNextKeyWord(const std::string &str, std::string::size_type &startPos)
{
    std::string keyWordStr;
    if (startPos > 0)
    {
        startPos = DdlGen::find_first_of(str, " \t\n()", startPos);
    }

    startPos = DdlGen::find_first_not_of(str, " \t\n()", startPos);
    if (startPos != std::string::npos)
    {
        std::string::size_type endPos = DdlGen::find_first_of(str, " \t\n();", startPos);
        keyWordStr = str.substr(startPos, endPos - startPos);
    }

    return keyWordStr;
}

/************************************************************************
*   Function             : DdlGen::getBracketPos()
*
*   Description          :
*
*   Arguments            :
*
*   Functions call       :
*
*   Return               :
*
*   Creation Date        :
*   Last Modif.          :
*
*************************************************************************/
void DdlGen::getBracketPos(const std::string &str, std::string::size_type &endPos, std::string::size_type &startPos, const std::string &openStr, const std::string &closeStr)
{
    std::string::size_type pos = DdlGen::find_first_of(str, openStr, startPos);

    if (pos != std::string::npos)
    {
        std::string::size_type nextOpenPos = DdlGen::find_first_of(str, openStr, pos + 1);
        std::string::size_type nextEndPos = DdlGen::find_first_of(str, closeStr, pos);

        startPos = pos;

        if (nextEndPos < nextOpenPos)
        {
            endPos = nextEndPos + 1;
            return;
        }

        nextOpenPos--;
        DdlGen::getBracketPos(str, pos, nextOpenPos, openStr, closeStr);

        pos = DdlGen::find_first_of(str, closeStr, pos) + 1;
    }

    endPos = pos;
}

/************************************************************************
*   Function             : DdlGen::tokenizeStr()
*
*   Description          : strtok for C++
*
*   Arguments            :
*
*   Functions call       :
*
*   Return               :
*
*   Creation Date        : PMSTA-11505 - LJE - 110413
*   Last Modif.          :
*
*************************************************************************/
int DdlGen::tokenizeStr(std::vector<std::string>& tokens,
                        std::string          tokenStr,
                        const std::string&   delimiters,
                        bool            bAppend,
                        int             bracketOpen,
                        bool            bIsInBracket,
                        size_t         *endPosPtr)
{
    // Skip delimiters at beginning.
    std::string::size_type lastPos, lastTokenPos;
    // Find first "non-delimiter".
    std::string::size_type pos;
    bool              bSingleDelimiter = (delimiters.size() == 1);

    if (bAppend && tokens.size() > 0)
    {
        std::vector<std::string>::iterator tokenIter = tokens.end();
        tokenIter--;
        tokenStr = *tokenIter + " " + tokenStr;
        tokens.erase(tokenIter);
        bracketOpen = 0;
    }

    pos = 0;
    if (bIsInBracket == true && bracketOpen == 0)
    {
        while (pos < tokenStr.length() && tokenStr[pos++] != '(')
        {
        }
    }

    while (pos < tokenStr.length() &&
           delimiters.find(tokenStr[pos]) != std::string::npos)
    {
        if (bSingleDelimiter == true)
        {
            tokens.push_back(std::string());
        }
        DdlGenMsg::incPosWOComment(tokenStr, pos);
    }

    lastPos = pos;
    lastTokenPos = pos;
    while (lastPos < tokenStr.length())
    {
        if (bracketOpen > 0 || tokenStr[lastPos] == '(')
        {
            do
            {
                if (tokenStr[lastPos] == '(')
                {
                    bracketOpen++;
                }
                else if (tokenStr[lastPos] == ')')
                {
                    bracketOpen--;
                }
            } while (bracketOpen && ++lastPos < tokenStr.length());
        }
        else if (bIsInBracket == true && tokenStr[lastPos] == ')')
        {
            if (lastPos - pos > 0)
            {
                tokens.push_back(tokenStr.substr(pos, lastPos - pos));
            }

            if (endPosPtr != nullptr)
            {
                *endPosPtr = lastPos;
            }

            return bracketOpen;
        }
        else if (bracketOpen == 0 && (tokenStr[lastPos] == '\'' || tokenStr[lastPos] == '"'))
        {
            char quoteEnd = tokenStr[lastPos];

            bool bQuoted = true;

            auto begPos = lastPos;
            if (quoteEnd == '"')
            {
                tokenStr[lastPos] = '\'';
            }

            while (bQuoted && ++lastPos < tokenStr.length())
            {
                if (quoteEnd == '"' && tokenStr[lastPos] == '\'')
                {
                    tokenStr.replace(lastPos, 1, "''");
                    lastPos++;
                }

                if (tokenStr[lastPos] == quoteEnd)
                {
                    if (lastPos + 1 == tokenStr.length() || tokenStr[lastPos + 1] != quoteEnd)
                    {
                        bQuoted = false;
                    }
                    else
                    {
                        lastPos++;
                    }
                }
            }

            if (quoteEnd == '"')
            {
                if (bQuoted)
                {
                    tokenStr[begPos] = '"';
                }
                else
                {
                    tokenStr[lastPos] = '\'';
                }
            }
        }

        if (lastPos >= tokenStr.length())
        {
            lastPos--;
        }

        if (delimiters.find(tokenStr[lastPos]) != std::string::npos ||
            (lastPos + 1) == tokenStr.length())
        {
            if ((lastPos + 1) == tokenStr.length() &&
                (delimiters.find(tokenStr[lastPos]) == std::string::npos || bracketOpen != 0))
            {
                lastPos++;
            }
            std::string newToken = tokenStr.substr(pos, lastPos - pos);
            if (newToken.find("/*") == 0)
            {
                lastPos = tokenStr.find("*/", pos);
                if (lastPos != std::string::npos)
                {
                    lastPos += 2;
                    tokens.back().append(tokenStr.substr(lastTokenPos, lastPos - lastTokenPos));
                }
                else
                {
                    tokens.back().append(tokenStr.substr(lastTokenPos));
                }
            }
            else if (newToken.find("--") == 0)
            {
                tokens.back().append(tokenStr.substr(lastTokenPos));
            }
            else
            {
                lastTokenPos = lastPos;
                tokens.push_back(newToken);
            }

            if (lastPos == tokenStr.length() - 1 && delimiters.compare(",") == 0 && bracketOpen == 0)
            {
                tokens.push_back(std::string());
                lastPos = std::string::npos;
            }
            else
            {
                pos = lastPos;
                while (lastPos < tokenStr.length() &&
                       delimiters.find(tokenStr[lastPos]) != std::string::npos)
                {
                    if (bSingleDelimiter == true && lastPos > pos)
                        tokens.push_back(std::string());

                    DdlGenMsg::incPosWOComment(tokenStr, lastPos);
                }
                pos = lastPos;
            }
        }
        else
        {
            DdlGenMsg::incPosWOComment(tokenStr, lastPos);
        }
    }

    if (endPosPtr != nullptr)
    {
        *endPosPtr = lastPos;
    }

    if (bIsInBracket == true && bracketOpen == 0)
    {
        bracketOpen++;
    }

    return bracketOpen;
}

/************************************************************************
**
**  Function    :   DdlGen::isSecuredLevel()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
bool DdlGen::isSecuredLevel(ENTITY_SECURITY_LEVEL_ENUM testSecuredLevel)
{
    if (testSecuredLevel == EntSecuLevel_Secured ||
        testSecuredLevel == EntSecuLevel_Secured2ndLevel)
    {
        return true;
    }
    return false;
}


/************************************************************************
**
**  Function    :   DdlGen::getViewName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-34344 - LJE - 201008
**
*************************************************************************/
std::string DdlGen::getViewName(DdlGenContext *ddlGenContextPtr, DdlGenVarHelper *, std::vector<std::vector<std::string>>&keywordParamList)
{
    DICT_ENTITY_STP      dictEntityStp = DBA_GetEntityBySqlName(trim(keywordParamList[0][0]));

    if (dictEntityStp != nullptr)
    {
        DdlGenContext        ddlGenContext(ddlGenContextPtr->m_rdbmsEn, true);
        bool                 uvwExist = false;
        DDL_VIEW_ENUM        viewEn = View_FullAllSecured;

        uvwExist = GET_BIT(dictEntityStp->automaticMask, Automatic_ViewFullAll);

        if (dictEntityStp->changeSetAuthEn == FeatureAuth_Enable &&
            DBA_GetApplSessionChangeSetId() != 0)
        {
            ddlGenContext.setDdlGenMode(DdlGenMode_Shadow);
        }

		static bool SV_DisableDboUvwOpti = SYS_GetEnvBoolOrDefValue("AAADISABLEDBOUVWOPTI", false);
		
        if(keywordParamList.size() > 2 &&
            trim(keywordParamList[2][0]).compare("1") == 0)
        {
            viewEn = View_Export; /* PMSTA-52258 - JBC - 230308 */
        }
        else if (SV_DisableDboUvwOpti == false &&
            trim(keywordParamList[1][0]).compare("1") == 0 &&
            uvwExist == true &&
            SYS_GetThreadUseProxyUser() == false)
        {
            viewEn = View_FullAll;
        }

        DdlGenView genDdl(dictEntityStp->objectEn, viewEn, ddlGenContext, nullptr, nullptr, TargetTable_Main);

        return genDdl.getDdlObjFullSqlName();
    }

    return std::string();
}

/************************************************************************
**
**  Function    :   DdlGen::getUdIdSqlName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14452 - LJE - 121105
**
*************************************************************************/
std::string DdlGen::getUdIdSqlName()
{
    return (std::string("ud_id"));
}

/************************************************************************
**
**  Function    :   DdlGen::getXIdSqlName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37366 - LJE - 200204
**
*************************************************************************/
std::string DdlGen::getXIdSqlName()
{
    return (std::string("x_id"));
}

/************************************************************************
**
**  Function    :   DdlGen::getScriptControlSqlName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14452 - LJE - 121105
**
*************************************************************************/
std::string DdlGen::getScriptControlSqlName()
{
    return (std::string("script_control"));
}

/************************************************************************
**
**  Function    :   DdlGen::isSecuredWithAddDSP()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-16575 - LJE - 130626
**
*************************************************************************/
bool DdlGen::isSecuredWithAddDSP(ENTITY_SECURITY_LEVEL_ENUM testSecuredLevel)
{
    if (this->getDefSecuredLevel() == EntSecuLevel_Secured2ndLevel &&
        testSecuredLevel == EntSecuLevel_Secured2ndLevel)
    {
        return true;
    }
    return false;
}

/************************************************************************
**
**  Function    :   DdlGen::getDefSecuredLevel()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-16575 - LJE - 130626
**
*************************************************************************/
ENTITY_SECURITY_LEVEL_ENUM DdlGen::getDefSecuredLevel()
{
    return this->ddlGenContextPtr == nullptr || 
        this->ddlGenContextPtr->ddlBuildModeEn != DdlBuildMode_Standard ||
        this->ddlGenContextPtr->isEnableAdditionalDSP() ? EntSecuLevel_Secured2ndLevel : EntSecuLevel_Secured;
}

/************************************************************************
**
**  Function    :   getWhereOrAnd()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
std::string DdlGen::getWhereOrAnd()
{
    std::stringstream locStream;

    if (this->m_bWherePrinted)
    {
        locStream << newLine() << " and ( ";
    }
    else if (this->bOnJoin)
    {
        this->m_bWherePrinted = true;
        locStream << newLine() << this->getCmdJoinOn() << " ((";
    }
    else
    {
        this->m_bWherePrinted = true;
        locStream << newLine() << "where ((";
    }

    return locStream.str();
}

/************************************************************************
**
**  Function    :   DdlGen::setOnJoin()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
void DdlGen::setOnJoin(bool paramOnJoin)
{
    this->m_bWherePrinted = false;
    this->bOnJoin = paramOnJoin;
}

/************************************************************************
**
**  Function    :   DdlGen::flush()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGen::flush(const std::string &message)
{
    RET_CODE            ret = RET_SUCCEED;

    this->lastErrRetCode = ret;

    this->ddlGenStream.clear();
    this->ddlGenStream.str(std::string());

    if (this->cmdType == DDlCmdType_CleanUpView)
    {
        this->ddlGenStream << DdlGenDbi::beginOfBlock(this->ddlGenContextPtr->m_rdbmsEn);
    }

    std::string bodyStr =
        this->headerStream.str() +
        this->headerDeclareStream.str() +
        this->bodySqlBlock.str() +
        this->selListStream.str() +
        this->m_mainFromStream.str() +
        this->addFromStream.str() +
        this->m_fromStream.str() +
        this->whereStream.str() +
        this->orderStream.str() +
        this->limitStream.str() +
        this->cursorStream.str() +
        this->footerStream.str();

    this->treateAllVariable(bodyStr, true);
    this->ddlGenStream << bodyStr;

    if (this->cmdType == DDlCmdType_CleanUpView)
    {
        this->ddlGenStream << DdlGenDbi::endOfBlock(this->ddlGenContextPtr->m_rdbmsEn);
    }

    if (this->ddlGenStream.str().empty() == false)
    {
        if (message.empty() == false)
        {
            this->printMsg(RET_SRV_INFO_RUNNING, message + "...");
        }

#ifdef AAADEBUGMSG
        if (this->cmdType == DDlCmdType_None)
        {
            this->printMsg(RET_DBA_INFO_NODATA, "Unknown command type: " + this->ddlGenStream.str());
        }
#endif
        ret = this->executeFlush();

        if (message.empty() == false)
        {
            std::string msg(message);
            if (ret == RET_SUCCEED)
            {
                msg += " done";
            }
            else
            {
                msg += " failed";

            }
            this->printMsg(ret, msg);
        }
    }

    this->cmdType = DDlCmdType_None;
    return ret;
}

/************************************************************************
**
**  Function    :   DdlGen::executeFlush()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGen::executeFlush()
{
    RET_CODE            ret = RET_SUCCEED, gblRet = RET_SUCCEED;
    bool                bToSendInDb = this->ddlGenContextPtr->bSendInDb;
    bool                bDdlObj = false;
    bool                bOptim = (GET_BIT(this->ddlGenContextPtr->optimMask, DDL_OPTIM_LIGHT_COMPILE_BIT));
    std::stringstream        chkStream;

    this->removeComments(this->ddlGenStream, chkStream);

    this->clear();

    if (((this->cmdType == DDlCmdType_Drop || this->cmdType == DDlCmdType_Create) &&
        (this->getDdlObjEn() == DdlObj_SProc ||
         this->getDdlObjEn() == DdlObj_SpecSProc ||
         this->getDdlObjEn() == DdlObj_Func ||
         this->getDdlObjEn() == DdlObj_Trigger ||
         this->getDdlObjEn() == DdlObj_TriggerUdField ||
         this->getDdlObjEn() == DdlObj_Table ||
         this->getDdlObjEn() == DdlObj_Index ||
         this->getDdlObjEn() == DdlObj_View)))
    {
        this->ddlGenContextPtr->m_lastCreateInvalid = false;
        bDdlObj = true;
    }

    if (bDdlObj == false ||
        (this->getDdlObjEn() != DdlObj_SProc &&
         this->getDdlObjEn() != DdlObj_SpecSProc &&
         this->getDdlObjEn() != DdlObj_Func &&
         this->getDdlObjEn() != DdlObj_Trigger &&
         this->getDdlObjEn() != DdlObj_TriggerUdField &&
         this->getDdlObjEn() != DdlObj_View))
    {
        bOptim = false;
    }

    if ((bOptim || this->ddlGenContextPtr->bCheck) &&
        bDdlObj &&
        this->ddlGenContextPtr->bForceReBuild == false &&
        this->ddlGenContextPtr->m_ddlObjLoaded.compare(this->getDdlObjSqlName()) != 0)
    {
        this->ddlGenContextPtr->m_ddlObjLoaded = this->getDdlObjSqlName();
        this->getDdlObjFromDb(this->ddlGenContextPtr->m_loadedDdlObjStream);

        if (this->ddlGenContextPtr->bCheck &&
            this->ddlGenContextPtr->m_loadedDdlObjMap.find(this->getDdlObjFullSqlName()) == this->ddlGenContextPtr->m_loadedDdlObjMap.end())
        {
            this->ddlGenContextPtr->m_loadedDdlObjMap[this->getDdlObjFullSqlName()] = this->ddlGenContextPtr->m_loadedDdlObjStream.str();
        }
    }

    /* PMSTA-45413 - LJE - 211115 */
    if (this->ddlGenContextPtr->m_bHasUnknownCall &&
        this->getDdlObjEn() != DdlObj_Trigger &&
        (this->ddlGenContextPtr->ddlGenAction.isBootStrapLevel() ||
         (this->ddlGenContextPtr->optimLevelEn == DdlGenContext::OptimLevel::Full && this->ddlGenContextPtr->m_loadedDdlObjStream.str().empty() == false) ||
         this->ddlGenContextPtr->m_rdbmsEn != PostgreSQL))
    {
        bToSendInDb = false;
    }

    if (bOptim)
    {
        if (this->cmdType == DDlCmdType_Create)
        {
            if (this->ddlGenContextPtr->bForceReBuild == false)
            {
                if (this->ddlGenContextPtr->m_loadedDdlObjStream.str().empty())
                {
                    this->getDdlObjFromDb(this->ddlGenContextPtr->m_loadedDdlObjStream);
                }

                if (this->ddlGenContextPtr->m_loadedDdlObjStream.str().empty() == false)
                {
                    if (this->ddlGenContextPtr->bIfNotExists)
                    {
                        bToSendInDb = false;
                        this->lastErrRetCode = RET_GEN_INFO_NOACTION;
                    }
                    else
                    {
                        std::string keyStr = (this->getDdlObjEn() == DdlObj_View ? "select" : this->ddlGenContextPtr->m_ddlObjLoaded);
                        size_t posNew = DdlGen::find_word(chkStream.str(), keyStr);
                        if (posNew == std::string::npos)
                        {
                            posNew = 0;
                        }
                        posNew = chkStream.str().find_first_of(" \t\n(", posNew);
                        posNew = chkStream.str().find_first_not_of(" \t\n", posNew);

                        size_t posDb = DdlGen::find_word(this->ddlGenContextPtr->m_loadedDdlObjStream.str(), keyStr);
                        if (posDb == std::string::npos)
                        {
                            posDb = 0;
                        }
                        posDb = this->ddlGenContextPtr->m_loadedDdlObjStream.str().find_first_of(" \t\n(", posDb);
                        posDb = this->ddlGenContextPtr->m_loadedDdlObjStream.str().find_first_not_of(" \t\n", posDb);

                        if (posDb != std::string::npos && posNew != std::string::npos &&
                            this->compareString(chkStream.str().substr(posNew), this->ddlGenContextPtr->m_loadedDdlObjStream.str().substr(posDb)))
                        {
                            DdlObjDef checkDdlObjDef(this->ddlGenContextPtr->m_rdbmsEn, 
                                                     this->getDdlObjEn(),
                                                     this->ddlGenContextPtr->getDdlDestDbName(), 
                                                     this->getDictEntityStp()->mdSqlName,
                                                     this->getDictEntityStp()->dbSqlName, 
                                                     this->getDdlObjSqlName());

                            ret = this->checkDdlObj(checkDdlObjDef);

                            if (ret == RET_SUCCEED)
                            {
                                bToSendInDb = false;
                                this->lastErrRetCode = RET_GEN_INFO_NOACTION;
                            }
                        }
                    }
                }
            }

            if (bToSendInDb)
            {
                size_t dropNb = 0;
                GUARD_VALUE(DDL_CMD_TYPE_ENUM, cmdType, DDlCmdType_Drop)

                for (auto &it : this->ddlGenContextPtr->m_dropDdlStrTab)
                {
                    this->m_paramVector = this->ddlGenContextPtr->m_dropDdlParamTab[dropNb];
                    if ((ret = this->sqlExec(it)) != RET_SUCCEED)
                    {
                        gblRet = ret;
                    }
                    dropNb++;
                }
            }
        }
        else if (this->cmdType == DDlCmdType_Drop)
        {
            if (bToSendInDb && this->ddlGenStream.str().empty() == false)
            {
                this->ddlGenContextPtr->m_dropDdlStrTab.push_back(this->ddlGenStream.str());
                this->ddlGenContextPtr->m_dropDdlParamTab.push_back(this->m_paramVector);
                this->m_paramVector.clear();
            }
            bToSendInDb = false;
        }
    }

    if (bToSendInDb &&
        this->ddlGenStream.str().empty() == false &&
        chkStream.str().empty() == false &&
        RET_GET_LEVEL(this->lastErrRetCode) != RET_LEV_ERROR) /* PMSTA-13109 - LJE - 111117 */
    {
        bOptim = false;
        ret = this->sqlExec(this->ddlGenStream.str());
    }

    if (bDdlObj &&
        this->cmdType == DDlCmdType_Create &&
        SYS_IsSqlMode() == false)
    {
        if (ret == RET_SUCCEED &&
            this->lastErrRetCode == RET_GEN_INFO_NOACTION)
        {
            DdlObjDef checkDdlObjDef(this->ddlGenContextPtr->m_rdbmsEn, 
                                     this->getDdlObjEn(),
                                     this->ddlGenContextPtr->getDdlDestDbName(),
                                     this->getDictEntityStp()->mdSqlName,
                                     this->getDictEntityStp()->dbSqlName,
                                     this->getDdlObjSqlName());

            ret = this->checkDdlObj(checkDdlObjDef);
        }
        else if (bToSendInDb && RET_GET_LEVEL(ret) != RET_LEV_ERROR)
        {
            DdlGenDbaAccessGuard ddlGenDbaAccessGuard(*this->ddlGenContextPtr);
            auto& dbaAccessSt = ddlGenDbaAccessGuard.getDdlGenDbaAccess();

            if (dbaAccessSt.isLoaded(this->getDdlObjEn()))
            {
                DdlObjDef ddlObjDef(this->ddlGenContextPtr->m_rdbmsEn, 
                                    this->getDdlObjEn(),
                                    this->ddlGenContextPtr->getDdlDestDbName(),
                                    this->getDictEntityStp()->mdSqlName, 
                                    this->getDictEntityStp()->dbSqlName,
                                    this->getDdlObjSqlName());

                dbaAccessSt.addDdlObjDef(ddlObjDef);
            }
        }

        if (RET_GET_LEVEL(ret) == RET_LEV_ERROR ||
            ret == RET_GEN_INFO_NODATA ||
            ret == RET_DBA_INFO_EXIST ||                            /* RET_GEN_INFO_NODATA or RET_DBA_INFO_EXIST means "success with info" */
            this->ddlGenContextPtr->m_bHasUnknownCall == true)      /* PMSTA-37366 - LJE - 200219 */
        {
            auto it = this->ddlGenContextPtr->m_invalidDdlObjMap.insert(std::make_pair(DdlObjDefKey(this->ddlGenContextPtr->m_rdbmsEn, 
                                                                                                    this->getDdlObjEn(), 
                                                                                                    this->ddlGenContextPtr->getDdlDestDbName(), 
                                                                                                    this->getDictEntityStp()->mdSqlName,
                                                                                                    this->getDictEntityStp()->dbSqlName,
                                                                                                    this->getDdlObjSqlName()),
                                                                                  DdlObjDef(this->ddlGenContextPtr->m_rdbmsEn, 
                                                                                            this->getDdlObjEn(), 
                                                                                            this->ddlGenContextPtr->getDdlDestDbName(), 
                                                                                            this->getDictEntityStp()->mdSqlName, 
                                                                                            this->getDictEntityStp()->dbSqlName,
                                                                                            this->getDdlObjSqlName())));

            it.first->second.m_ddlUser          = this->ddlGenContextPtr->getDdlDestUser();
            it.first->second.m_bodyStr          = this->ddlGenStream.str();
            it.first->second.m_dropCmdTab       = this->ddlGenContextPtr->m_dropDdlStrTab;
            it.first->second.m_dropParamTab     = this->ddlGenContextPtr->m_dropDdlParamTab;
            it.first->second.m_dictSprocSt      = this->ddlGenContextPtr->getDictSprocSt();
            it.first->second.m_dependsEntityMap = this->ddlGenContextPtr->m_dependsEntityMap;
            it.first->second.m_dependsSprocSet  = this->ddlGenContextPtr->m_dependsSprocSet;
            it.first->second.m_dependsAccessSet = this->ddlGenContextPtr->m_dependsAccessSet;
            it.first->second.m_bSendIntoDb      = bToSendInDb;
            if (this->fileHelper != nullptr)
            {
                it.first->second.m_outputFileStr  = this->fileHelper->outputFileStr;
                it.first->second.m_outFileLinePos = this->fileHelper->outFileLinePos;
            }

            this->ddlGenContextPtr->m_lastCreateInvalid = true;
        }
        else
        {
            auto it = this->ddlGenContextPtr->m_validDdlObjMap.insert(std::make_pair(DdlObjDefKey(this->ddlGenContextPtr->m_rdbmsEn, 
                                                                                                  this->getDdlObjEn(),
                                                                                                  this->ddlGenContextPtr->getDdlDestDbName(), 
                                                                                                  this->getDictEntityStp()->mdSqlName,
                                                                                                  this->getDictEntityStp()->dbSqlName,
                                                                                                  this->getDdlObjSqlName()),
                                                                                DdlObjDef(this->ddlGenContextPtr->m_rdbmsEn, 
                                                                                          this->getDdlObjEn(), 
                                                                                          this->ddlGenContextPtr->getDdlDestDbName(), 
                                                                                          this->getDictEntityStp()->mdSqlName, 
                                                                                          this->getDictEntityStp()->dbSqlName,
                                                                                          this->getDdlObjSqlName())));

            it.first->second.m_ddlUser          = this->ddlGenContextPtr->getDdlDestUser();
            it.first->second.m_dropCmdTab       = this->ddlGenContextPtr->m_dropDdlStrTab;
            it.first->second.m_dropParamTab     = this->ddlGenContextPtr->m_dropDdlParamTab;
            it.first->second.m_dictSprocSt      = this->ddlGenContextPtr->getDictSprocSt();
            it.first->second.m_dependsEntityMap = this->ddlGenContextPtr->m_dependsEntityMap;
            it.first->second.m_dependsSprocSet  = this->ddlGenContextPtr->m_dependsSprocSet;
            it.first->second.m_dependsAccessSet = this->ddlGenContextPtr->m_dependsAccessSet;
            it.first->second.m_bSendIntoDb      = bToSendInDb;
            if (this->fileHelper != nullptr)
            {
                it.first->second.m_outputFileStr  = this->fileHelper->outputFileStr;
                it.first->second.m_outFileLinePos = this->fileHelper->outFileLinePos;
            }
        }
        this->ddlGenContextPtr->m_dropDdlStrTab.clear();
        this->ddlGenContextPtr->m_dropDdlParamTab.clear();
        this->ddlGenContextPtr->m_dependsEntityMap.clear();
        this->ddlGenContextPtr->m_dependsSprocSet.clear();
        this->ddlGenContextPtr->m_dependsAccessSet.clear();

        this->ddlGenContextPtr->m_ddlObjLoaded.clear();
    }

    if (ret != RET_SUCCEED)
    {
        gblRet = ret;
    }
    else if (bToSendInDb == false)
    {
        gblRet = RET_DBA_INFO_EXIST;
    }

    if (this->ddlGenStream.str().length() != 0 && /* PMSTA-13109 - LJE - 111117 */
        this->fileHelper != nullptr)
    {
        std::string lineStr;

        if (this->ddlGenContextPtr->bGenFromDbi == false && this->cmdType == DDlCmdType_Create)
        {
            *this->fileHelper << "---- Line:" << this->fileHelper->outFileLinePos << " (" << this->printDateInfo() << ") ----" << "\n";
            if (bToSendInDb == false)
            {
                *this->fileHelper << "---- Not rebuild ----" << "\n";

                if (this->ddlGenContextPtr->m_bHasUnknownCall)
                {
                    *this->fileHelper << "---- Has call to unknown stored procedure ----" << "\n";
                }
                this->fileHelper->flush();
            }
        }

        *this->fileHelper << this->ddlGenStream;

        this->printEndBlockToFile();

        if (this->cmdType == DDlCmdType_Create)
        {
            if (this->ddlGenContextPtr->bCheck == true &&
                (this->ddlGenContextPtr->ddlGenAction.m_installLevel < 5 || this->ddlGenContextPtr->m_bHasUnknownCall == false) &&
                bToSendInDb == true)
            {
                std::stringstream  fileStream;
                std::stringstream  chkStream1;
                std::stringstream  chkStream2;

                this->removeComments(this->ddlGenStream, chkStream2);
                chkStream1 << this->ddlGenContextPtr->m_loadedDdlObjMap[this->getDdlObjFullSqlName()];

                if (chkStream1.str().empty() == false &&
                    chkStream2.str().empty() == false &&
                    chkStream2.str().compare(chkStream1.str()) != 0)
                {
                    this->getDdlObjFromDb(this->ddlGenContextPtr->m_loadedDdlObjStream);

                    chkStream2.clear();
                    chkStream2.str(std::string());
                    chkStream2 << this->ddlGenContextPtr->m_loadedDdlObjStream.str();
                }

                if (chkStream1.str().compare(chkStream2.str()) != 0)
                {
                    if (this->fileHelper->procDiffFile.is_open() == false)
                    {
                        std::ios_base::openmode openMode;
                        openMode = std::ios_base::out;
                        if (this->bAppendFile)
                            openMode |= std::ios_base::app;

                        this->fileHelper->chkFile1.open(this->fileHelper->chk1Str.c_str(), openMode);
                        this->fileHelper->chkFile2.open(this->fileHelper->chk2Str.c_str(), openMode);
                        this->fileHelper->procDiffFile.open(this->fileHelper->toChkStr.c_str(), openMode);
                    }

                    this->fileHelper->chkFile1 << chkStream1.str() << std::endl;
                    this->fileHelper->chkFile2 << chkStream2.str() << std::endl;
                    this->fileHelper->procDiffFile << this->getDdlObjSqlName();

                    if (chkStream1.str().empty())
                    {
                        this->fileHelper->procDiffFile << "(was empty)";
                    }
                    if (chkStream2.str().empty())
                    {
                        this->fileHelper->procDiffFile << "(now empty)";
                    }
                    this->fileHelper->procDiffFile << std::endl;
                }
            }
            this->ddlGenContextPtr->m_loadedDdlObjStream.clear();
            this->ddlGenContextPtr->m_loadedDdlObjStream.str(std::string());

        }
    }

    return gblRet;
}

/************************************************************************
**
**  Function    :   DdlGen::printUserInfoAccess()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGen::printUserInfoAccess()
{
    RET_CODE    ret = RET_SUCCEED;
    ENTITY_SECURITY_LEVEL_ENUM  locSecurityLevelEn = this->securityLevelEn;

    if (this->isProcedureBehavior() == false &&
        this->isSecuredLevel(locSecurityLevelEn) &&
        this->joinTab.size() > 0)
    {
        for (std::vector<DdlGenJoin>::const_iterator it = this->joinTab.begin(); it != this->joinTab.end(); ++it)
        {
            if (this->isSecuredLevel(it->securityLevelEn))
            {
                locSecurityLevelEn = it->securityLevelEn;
                break;
            }
        }
    }

    if (this->isProcedureBehavior() ||
        locSecurityLevelEn == EntSecuLevel_NoSecured)
    {
        return ret;
    }

    /* Data profile access */
    this->m_fromStream << "," << newLine() << " (select ";

    this->m_fromStream << DdlGenDbi::getCmdSelectList(
        "coalesce (" + DdlGenDbi::getCmdDataProfileId() +
        ", (select curr_usr.data_profile_id from " + this->getEntityFullSqlName("appl_user") + " curr_usr where curr_usr.id = " + this->getCmdUserId() + "))", "data_profile_id");

    this->m_fromStream << ") ap";

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGen::clear()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
void DdlGen::clear()
{
    this->selListStream.clear();
    this->selListStream.str(std::string());

    this->varListStream.clear();
    this->varListStream.str(std::string());

    this->headerStream.clear();
    this->headerStream.str(std::string());

    this->headerDeclareStream.clear();
    this->headerDeclareStream.str(std::string());

    this->footerStream.clear();
    this->footerStream.str(std::string());

    this->m_mainFromStream.clear();
    this->m_mainFromStream.str(std::string());

    this->m_fromStream.clear();
    this->m_fromStream.str(std::string());

    this->addFromStream.clear();
    this->addFromStream.str(std::string());

    this->whereStream.clear();
    this->whereStream.str(std::string());

    this->pscFromStr.clear();
    this->pscWhereStr.clear();

    this->orderStream.clear();
    this->orderStream.str(std::string());

    this->limitStream.clear();
    this->limitStream.str(std::string());

    this->cursorStream.clear();
    this->cursorStream.str(std::string());

    this->bodySqlBlock.clear();

    this->overloadStream.clear();
    this->overloadStream.str(std::string());

    this->m_bWherePrinted = false;
    this->bSelectPrinted = false;
    this->bUserJoinPrint = false;

    this->fromAddStr = std::string();

    this->joinTab.clear(); /* PMSTA-14607 - LJE - 120720 */

    this->denomFlg = FALSE;
    this->labelFlg = FALSE;

    if (this->bNoIndentReset == false)
    {
        this->setPreIndent(std::string());
    }

    this->bOrderBy        = false;
    this->bJoinOnFromTag  = false;
    this->bReplaceFromTag = false;    /* PMSTA-37366 - LJE - 200130 */

    if (this->bKeepRealObject == false)
    {
        this->realObjectEn = NullEntity;
        this->realDictEntityStp = NULL;
        this->realSqlName.clear();
    }

    this->setAlias(std::string("E"));
}

/************************************************************************
**
**  Function    :   DdlGen::setSecurityLevel()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 150831
**
*************************************************************************/
void DdlGen::setSecurityLevel(ENTITY_SECURITY_LEVEL_ENUM	newSecurityLevelEn)
{
    DICT_ENTITY_STP locEntityDictStp = this->realDictEntityStp;

    if (locEntityDictStp == NULL)
    {
        locEntityDictStp = this->getDictEntityStp();
    }

    this->securityLevelEn = newSecurityLevelEn;

    if (this->isSecuredLevel(this->securityLevelEn) &&
        this->isSecuredLevel(locEntityDictStp->securityLevelEn) == false)
    {
        this->securityLevelEn = EntSecuLevel_NoSecured;
    }

    if (this->ddlGenContextPtr->m_bLightContext == false)
    {
        if (this->securityLevelEn == EntSecuLevel_Secured2ndLevel && /* PMSTA-14607 - LJE - 120710 */
            this->isSecuredWithAddDSP(locEntityDictStp->securityLevelEn) == false)
        {
            this->securityLevelEn = EntSecuLevel_Secured;
        }
    }
}

/************************************************************************
**
**  Function    :   DdlGen::initRequest()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGen::initRequest()
{
    RET_CODE          ret = RET_SUCCEED;

    this->clear();

    if (this->objectEn == NullEntity)
        return RET_SUCCEED;

    this->setObjectEn(this->objectEn);

    this->setSecurityLevel(this->securityLevelEn);

    if (this->custFlg == TRUE &&
        (this->getDictEntityStp()->custAuthFlg == FALSE || this->udTableName.empty()) &&
        this->getDictEntityStp()->dbRuleEn != DbRule_PartialSpecialization)
    {
        this->custFlg = FALSE;
    }

    if (this->precompFlg == TRUE &&
        (this->getDictEntityStp()->usePrecompFlg == FALSE || this->getDictEntityStp()->precompSqlName[0] == 0))
    {
        this->precompFlg = FALSE;
    }

    if (this->objectEn == Empty)
    {
        this->infoCriterMap = nullptr;
    }
    else if (this->outputDynNatEn == DynType_Short)
    {
        this->infoCriterMap = &(this->getDictEntityStp()->shortDictCriteriaMap);

        if (this->infoCriterMap->size() == 0 && this->getDictEntityStp()->logicalFlg == FALSE)
            this->printMsg(RET_GEN_ERR_INVARG, "Missing short attributes in dict_criteria (entity: " + this->getEntityMdName() + ")");
    }
    else if (this->outputDynNatEn == DynType_All ||
             this->outputDynNatEn == DynType_AllDb ||
             this->outputDynNatEn == DynType_Full ||            /* PMSTA-nuodb - LJE - 190528 */
             this->outputDynNatEn == DynType_FullDb ||          /* PMSTA-49178 - LJE - 220908 */
             this->outputDynNatEn == DynType_AllDbWithUd ||     /* PMSTA-36158 - LJE - 190627 */
             this->outputDynNatEn == DynType_MeSpecOnly ||      /* PMSTA-33420 - LJE - 181026 */
             this->outputDynNatEn == DynType_UdOnly ||
             this->outputDynNatEn == DynType_UdMeSpecOnly ||    /* PMSTA-33420 - LJE - 181026 */
             this->outputDynNatEn == DynType_PrecompOnly)
    {
        this->infoCriterMap = &(this->getDictEntityStp()->allDictCriteriaMap);

        if (this->infoCriterMap->size() == 0 &&
            this->getDictEntityStp()->logicalFlg == FALSE &&
            this->getDictEntityStp()->entNatEn != EntityNat_Internal)
        {
            this->printMsg(RET_GEN_ERR_INVARG, "Missing attributes in dict_attribute (entity: " + this->getEntityMdName() + ")");
        }
    }
    else if (this->outputDynNatEn == DynType_ShortAllDb)
    {
        this->infoCriterMap = &(this->getDictEntityStp()->shortAllDbDictCriteriaMap);
    }
    else
    {
        this->infoCriterMap = nullptr;
    }

    this->joinTab.clear(); /* PMSTA-14607 - LJE - 120720 */

    if (this->bNoIndentReset == false)
    {
        this->setPreIndent(std::string());
        this->setIndent(1);
    }

    if (this->ddlGenContextPtr->m_bLightContext == false &&
        (this->getDdlObjEn() == DdlObj_SProc || this->getDdlObjEn() == DdlObj_View))
    {
        DdlGenCfgTemplateKey cfgKey(CfgTemplate_Security,
                                    this->ddlGenContextPtr->m_rdbmsEn,
                                    this->ddlGenContextPtr->getTemplateVersion(),
                                    this->ddlGenContextPtr->isEnableAdditionalDSP(),
                                    this->ddlGenContextPtr->isEnableMultiTascLogin(),
                                    this->securityLevelEn,
                                    this->getDdlObjEn(),
                                    std::string(),
                                    this->ddlGenContextPtr->getViewEn());
        this->securityTemplate = this->ddlGenContextPtr->getTemplateFileHelper().getCfgTemplate(cfgKey);
    }
    else
    {
        this->securityTemplate = nullptr;
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGen::getJoinAlias()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14607 - LJE - 120717
**
*************************************************************************/
std::string DdlGen::getJoinAlias(const DdlGenJoin &joinSt, bool bInFrom)
{
    if (bInFrom)
    {
        /* Remove the . in the end */
        if (joinSt.joinSqlName.empty() == false)
        {
            return joinSt.joinSqlName.substr(0, joinSt.joinSqlName.find_first_of("."));
        }
    }
    return joinSt.joinSqlName;
}

/************************************************************************
**
**  Function    :   DdlGen::getCriteriaAlias()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
std::string DdlGen::getCriteriaAlias(DICT_CRITER_STP joinCriteriaStp)
{
    return joinCriteriaStp->joinSqlName[0] == 0 ? this->getAlias() : joinCriteriaStp->joinSqlName;
}

/* This class is only used in the following function but AIX compiler doesn't
 * let me define it in the function itself (PMSTA-20211) */
class OverloadLine
{
public:

    OverloadLine()
        : bTreated(false)
    {
    };

    OverloadLine(const OverloadLine & src)
    {
        lineStr = src.lineStr;
        bTreated = src.bTreated;
    }

    OverloadLine & operator=(const OverloadLine & src)
    {
        lineStr = src.lineStr;
        bTreated = src.bTreated;

        return *this;
    }

    std::string lineStr;
    bool   bTreated;
};

/************************************************************************
**
**  Function    :   DdlGen::printSelListRequest()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGen::printSelListRequest(SEL_LIST_ENUM selListEn)
{
    RET_CODE          ret = RET_SUCCEED;
    int               maxSortRk = 0, minSortRk = 9999;
    const std::string      mainAlias = this->getAlias();

    FLAG_T            printAttribFlg,
        printNullFlg,
        printDefValFlg,
        printLabelFlg,
        printDenomFlg,
        printCodifFlg,
        printDefValIfIsNullFlg,
        overriddenFlg,
        printDenormEnumFlg;
    DICT_T            entityDictId;
    bool              bManageLogFk;
    bool              bForceRemove;
    bool              bForceKeep, bSetNullAll;
    bool              bAuthPrinted = false;
    bool              bAssignValue = false;

    std::vector<OverloadLine>               overloadVector;
    std::map<INT_T, DictCriterClass*>  localInfoCriterMap;

    DDL_VIEW_ENUM     outputViewEn = View_ShortSecured;

    if (this->isSecuredLevel(this->securityLevelEn))
    {
        this->secuMandatoryFlg = TRUE;

        DICT_ATTRIB_STP secuAttribStp = DBA_GetAttributeBySqlName(this->objectEn, "data_secu_prof_id");
        if (secuAttribStp != nullptr)
        {
            this->secuMandatoryFlg = secuAttribStp->dbMandatoryFlg;
        }
    }

    if (this->ddlGenContextPtr->ddlBuildModeEn == DdlBuildMode_ViewOnly)
    {
        switch (this->outputDynNatEn)
        {
            case DynType_Short:
            case DynType_ShortAllDb:
                this->m_outputViewEn = View_ShortSecured;
                break;

            case  DynType_All:
            case  DynType_AllDb:
            case  DynType_AllDbWithUd:  /* PMSTA-36158 - LJE - 190627 */
            case  DynType_Full:         /* PMSTA-nuodb - LJE - 190528 */
            case  DynType_FullDb:        /* PMSTA-49178 - LJE - 220908 */
            case  DynType_MeSpecOnly:   /* PMSTA-33420 - LJE - 181026 */
            case  DynType_UdOnly:
            case  DynType_UdMeSpecOnly: /* PMSTA-33420 - LJE - 181026 */
            case  DynType_PrecompOnly:
            case  DynType_Other:
            case  DynType_FieldList:
            default:
                this->m_outputViewEn = View_FullAllSecured;
                break;
        }
    }

    /* PMSTA-36919 - LJE - 191210 */
    bool bRequestManageJoin = true;
    switch (this->ddlGenContextPtr->getViewEn())
    {
        case View_MainTable:
        case View_LightAll:
            bRequestManageJoin = false;
        break;

        default:
            break;
    }

    if (this->overloadStream.str().empty() == false)
    {
        std::string            getLineStr;
        OverloadLine      overLine;
        int               iOpen = 0, iClose = 0;
        std::string::size_type pos;

        overLine.bTreated = false;

        this->overloadStream.clear();
        this->overloadStream.seekg(0, std::ios::beg);
        while (getline(this->overloadStream, getLineStr))
        {
            if (getLineStr.empty())
            {
                continue;
            }

            if ((pos = this->find_first_not_of(getLineStr, " \t")) == std::string::npos)
            {
                continue;
            }

            overLine.lineStr += getLineStr;

            std::string::size_type bracePos = 0;
            while ((bracePos = this->find_first_of(getLineStr, "(", bracePos)) != std::string::npos)
            {
                this->setIndent(1);
                iOpen++;
                bracePos++;
            }
            bracePos = 0;
            while ((bracePos = this->find_first_of(getLineStr, ")", bracePos)) != std::string::npos)
            {
                this->setIndent(-1);
                iClose++;
                bracePos++;
            }

            if (iOpen == iClose)
            {
                this->extractAndFixDependsEntity(overLine.lineStr);
                overloadVector.push_back(overLine);
                overLine.lineStr.clear();
            }
            else
            {
                overLine.lineStr += this->newLine();
            }
        }

        if (overLine.lineStr.empty() == false)
        {
            this->printMsg(RET_GEN_ERR_INVARG, "Syntax error in script, unmatched couple of '(' and ')'");
        }
    }

    ENTITY_SECURITY_LEVEL_ENUM	entitySecurityLevelEn;

    DBA_GetDictId(DictEntity, &entityDictId);

    this->bOrderBy = false;

    selectList.clear();

    /* PMSTA-14785 - LJE - 120829 */
    if ((this->infoCriterMap == nullptr || this->infoCriterMap->size() == 0) &&
        this->getDdlObjEn() != DdlObj_View)
    {
        if (this->isSecuredWithAddDSP(this->securityLevelEn) == false)
        {
            this->bManageAuthFlg = true;
        }

        if (overloadVector.empty() == false && selListEn == SelList_Select)
        {
            int i = 0;
            for (auto it = overloadVector.begin(); it != overloadVector.end(); ++it, ++i)
            {
                std::vector<std::string>   tokens;
                this->tokenizeStr(tokens, it->lineStr);

                if (tokens.size() == 3 && tokens[2].compare("="))
                {
                    const DICT_ATTRIB_STP mdAttributeStp = DBA_GetAttributeBySqlName(this->objectEn, tokens[2].c_str(), TRUE);

                    if (mdAttributeStp != nullptr)
                    {
                        DICT_CRITER_STP mdCriteriaStp = this->m_dictEntityStp->getDictCriteria(DynType_All, mdAttributeStp->progN);

                        if (mdCriteriaStp != nullptr)
                        {
                            auto newCriteriaStp = new DictCriterClass(*mdCriteriaStp);
                            this->m_mp.ownerObject(newCriteriaStp);
                            localInfoCriterMap.insert(std::make_pair(i, newCriteriaStp));

                            if (tokens[0][0] != '@')
                            {
                                strcpy(newCriteriaStp->sqlName, tokens[0].c_str());
                            }
                        }
                    }
                }
            }

            this->infoCriterMap = &localInfoCriterMap;
        }
    }

    bSetNullAll = false;

    DICT_ENTITY_STP currDictEntityStp = this->realDictEntityStp != nullptr ? this->realDictEntityStp : this->m_dictEntityStp;

    if (this->infoCriterMap != nullptr)
    {
        for (auto criterIt = this->infoCriterMap->begin(); criterIt != this->infoCriterMap->end(); ++criterIt)
        {
            DICT_CRITER_STP   dictCriterStp      = criterIt->second;
            DICT_ATTRIB_STP   dictAttribStp      = dictCriterStp->attrPtr;
            DICT_ATTRIB_STP   entDictAttribStp   = dictCriterStp->entAttrPtr;
            DICT_ENTITY_STP   attrDictEntityStp  = DBA_GetDictEntitySt(dictCriterStp->attrEntObj);
            XdEntityFeatureFeatureEn      attribFeatureEn = (entDictAttribStp != nullptr ? entDictAttribStp->featureEn : dictAttribStp ? dictAttribStp->featureEn : XdEntityFeatureFeatureEn::None);                    /* PMSTA-29879 - LJE - 180711 */
            SubFeature        attribSubFeatureEn = (entDictAttribStp != nullptr ? entDictAttribStp->subFeatureEn : dictAttribStp ? dictAttribStp->subFeatureEn : SubFeature::None);           /* PMSTA-29879 - LJE - 180711 */
            bool              bAuthCase = (this->bManageAuthFlg == true && entDictAttribStp != nullptr && entDictAttribStp->featureEn == XdEntityFeatureFeatureEn::AccessRightManagement); /* PMSTA-29879 - LJE - 180703 */;
            std::string            defaultValueStr    = (entDictAttribStp != nullptr ? entDictAttribStp->dfltVal : dictAttribStp ? dictAttribStp->dfltVal : std::string());                            /* PMSTA-29879 - LJE - 180711 */
            bool              bTranslate         = this->translateFlg == TRUE;
            bool              bManageJoin        = bRequestManageJoin;                                                                                                            /* PMSTA-37366 - LJE - 191210 */
            bool              bConvert           = (selListEn == SelList_Select || selListEn == SelList_SelectDistinct);

            std::string            colSqlName(dictCriterStp->sqlName);

            DdlSelectElt      currSelectEltSt;
            std::stringstream      locStream;

            this->setAlias(mainAlias);               /* PMSTA-36158 - LJE - 190627 */

            if (dictAttribStp == nullptr || attrDictEntityStp == nullptr)
            {
                std::stringstream msgStream;
                ret = RET_DBA_ERR_INVDATA;
                msgStream << "Invalid dict_criteria record: " << this->m_dictEntityStp->mdSqlName << "." << colSqlName;
                this->printMsg(ret, msgStream.str());
                return ret;
            }

            std::string            attribSqlName(dictAttribStp->sqlName);

            currSelectEltSt.datatype = dictAttribStp->dataTpProgN;
            currSelectEltSt.bOutput = false;
            currSelectEltSt.bMandatory = dictAttribStp->dbMandatoryFlg == TRUE;  /* PMSTA-26250 - LJE - 170327 */
            currSelectEltSt.attribStp = entDictAttribStp;                       /* PMSTA-32145 - LJE - 180720 */

            if (currSelectEltSt.bMandatory)
            {
                currSelectEltSt.defaultValueStr = defaultValueStr;
            }

            printAttribFlg = FALSE;
            printNullFlg = FALSE;
            printDefValFlg = FALSE;
            printDefValIfIsNullFlg = FALSE;
            printLabelFlg = FALSE;
            printDenomFlg = FALSE;
            printCodifFlg = FALSE;
            printDenormEnumFlg = FALSE;
            entitySecurityLevelEn = this->securityLevelEn; /* PMSTA-14607 - LJE - 120719 */
            bManageLogFk = false; /* OCS-43062 - LJE - 130913 */

            if (dictCriterStp->toPrintFlg == FALSE && dictCriterStp->isNullParent1ProgN == true)
            {
                continue;
            }

            if (entDictAttribStp != nullptr)
            {
                /* PMSTA-26250 - LJE - 170421 */
                if (attribFeatureEn == XdEntityFeatureFeatureEn::ShadowEntity &&
                    (this->ddlGenContextPtr->getDdlGenMode() == DdlGenMode_Shadow ||
                     this->bShadowAccess ||
                     this->m_dictEntityStp->dbRuleEn == DbRule_ShadowTable ||
                     (this->realDictEntityStp && this->realDictEntityStp->dbRuleEn == DbRule_ShadowTable)))
                {
                    currSelectEltSt.bShadowAttrib = true;
                }

                if (entDictAttribStp->logicalFlg == FALSE &&
                    entDictAttribStp->multiLanguageFlg == FALSE &&
                    (entDictAttribStp->isPhysicalAttribute() || entDictAttribStp->calcEn == DictAttr_Denorm) &&
                    (this->custFlg == TRUE || entDictAttribStp->custFlg == FALSE) &&
                    (this->precompFlg == TRUE || entDictAttribStp->precompFlg == FALSE))
                {
                    printAttribFlg = TRUE;
                }
                else if (entDictAttribStp->calcEn == DictAttr_Calculated && (this->getDdlObjEn() != DdlObj_View || (this->bShadowAccess && currSelectEltSt.bShadowAttrib)))
                {
                    printAttribFlg = TRUE;
                    if (selListEn != SelList_SelectVar &&
                        currSelectEltSt.bShadowAttrib == false) /* PMSTA-26250 - LJE - 170421 */
                    {
                        /* PMSTA-26250 - LJE - 170517 */
                        if ((dictAttribStp->dataTpProgN == FlagType ||
                             dictAttribStp->dataTpProgN == EnumType ||
                             dictAttribStp->dataTpProgN == EnumMaskType) &&
                            dictAttribStp->dfltVal.empty() == false)
                        {
                            printDefValFlg = TRUE;
                        }
                        else
                        {
                            printNullFlg = TRUE;
                        }
                    }
                }

                if ((this->outputDynNatEn == DynType_AllDb && entDictAttribStp->isPhysicalAttribute() == false) ||
                    (this->outputDynNatEn == DynType_UdOnly && entDictAttribStp->isPhysicalUDAttribute() == false) ||
                    (this->outputDynNatEn == DynType_AllDbWithUd && entDictAttribStp->isPhysicalUDAttribute() == false && entDictAttribStp->isPhysicalAttribute() == false) ||              /* PMSTA-36158 - LJE - 190627 */
                    (this->outputDynNatEn == DynType_PrecompOnly && entDictAttribStp->precompFlg == FALSE) ||
                    (this->outputDynNatEn == DynType_UdMeSpecOnly && (entDictAttribStp->custFlg == FALSE || entDictAttribStp->meSpecialisationEn != MeSpecialisation_Applied)) ||
                    (this->outputDynNatEn == DynType_MeSpecOnly && (entDictAttribStp->isPhysicalAttribute() == false || entDictAttribStp->meSpecialisationEn != MeSpecialisation_Applied)) || /* PMSTA-33420 - LJE - 181026 */
                    ((this->outputDynNatEn == DynType_Full || this->outputDynNatEn == DynType_FullDb) && (entDictAttribStp->isPhysicalAttribute() == false ||
                                                              (attrDictEntityStp->optimisticLockingAttrStp == entDictAttribStp && 
                                                               this->getOptimisticLockingRule(entDictAttribStp) == OptimisticLocking_DbAttrib &&
                                                               this->ddlGenContextPtr->m_bBcpMode == false))))
                {
                    if (this->outputDynNatEn == DynType_UdOnly ||
                        (currSelectEltSt.bShadowAttrib == false &&
                         (dictAttribStp->subFeatureEn != SubFeature::MeRecordLocation ||
                          (this->bShadowAccess && (this->ddlGenContextPtr->getViewEn() != View_Shadow || 
                                                   currDictEntityStp->multiEntityCateg.isUseMeViewAsTable() == false)))))
                    {
                        printAttribFlg = FALSE;
                    }
                }

                if (bTranslate &&
                    this->outputDynNatEn == DynType_ShortAllDb &&
                    entDictAttribStp->isNullShortIdx == true)
                {
                    bTranslate = false;
                }
            }
            else
            {
                printAttribFlg = TRUE;
            }

            if ((selListEn == SelList_Call ||
                 selListEn == SelList_SelectCall ||
                 selListEn == SelList_Insert ||
                 selListEn == SelList_Update ||
                 selListEn == SelList_InsertCall ||
                 selListEn == SelList_SelectCursor ||
                 selListEn == SelList_SelectDistinctCursor ||
                 selListEn == SelList_ForSelect ||
                 selListEn == SelList_ForSelectDistinct ||
                 selListEn == SelList_InsertSelect ||
                 selListEn == SelList_InsertSelectDistinct) &&
                this->isInsUpdParam(dictCriterStp, this->outputDynNatEn) == false)
            {
                printAttribFlg = FALSE;
            }

            if (selListEn != SelList_Call && selListEn != SelList_InsertCall && this->ddlGenContextPtr->ddlBuildModeEn != DdlBuildMode_ViewOnly)
            {
                /* If no join information, set NULL */
                if ((dictCriterStp->attrEntDictId != dictCriterStp->entDictId ||
                     dictAttribStp->calcEn == DictAttr_Denorm) &&
                    dictCriterStp->joinSqlName[0] == 0 &&
                    dictAttribStp->precompFlg == FALSE)
                {
                    /* PMSTA-14212 - LJE - 120621 */
                    if (dictAttribStp->dataTpProgN == EnumType &&
                        dictAttribStp->linkedAttrDictStp != NULL &&
                        dictAttribStp->permValMap.size())
                    {
                        printDenormEnumFlg = TRUE;
                    }
                    else if ((dictAttribStp->dataTpProgN == FlagType ||
                              dictAttribStp->dataTpProgN == EnumType ||
                              dictAttribStp->dataTpProgN == EnumMaskType) &&
                             dictAttribStp->dfltVal.empty() == false)
                    {
                        printDefValFlg = TRUE;
                    }
                    else
                    {
                        printNullFlg = TRUE;
                    }
                }
            }

            if (this->bHidePrecomp && dictAttribStp->precompFlg == TRUE)
            {
                printNullFlg = TRUE;
            }

            /* PMSTA-49400 - LJE - 220603 */
            if (this->ddlGenContextPtr->ddlBuildModeEn == DdlBuildMode_ViewOnly)
            {
                bManageJoin = false;
            }
            else if (selListEn != SelList_List &&
                     selListEn != SelList_Insert &&
                     selListEn != SelList_Update)
            {
                if (dictAttribStp->custFlg == TRUE)
                {
                    if ((this->getDdlObjEn() != DdlObj_View && currDictEntityStp->dbRuleEn == DbRule_ShadowTable) ||

                        ((this->m_dictEntityStp->multiEntityCateg.isUseMeViewAsTable() == false ||
                         this->ddlGenContextPtr->getDdlGenMode() == DdlGenMode_MultiEntity ||         /* PMSTA-32145 - LJE - 180718 */
                         this->ddlGenContextPtr->bAvoidMultiEntity == true) &&

                        this->m_bCustInView == false &&

                        this->m_dictEntityStp->dbRuleEn != DbRule_PartialSpecialization &&

                        (this->ddlGenContextPtr->getDdlGenMode() != DdlGenMode_Shadow ||
                         this->m_dictEntityStp->changeSetAuthEn != FeatureAuth_Enable ||
                         this->m_dictEntityStp->dbRuleEn == DbRule_ShadowTable ||
                         this->ddlGenContextPtr->bForceUdTable)))
                    {
                        this->setAlias(std::string("ud"));
                    }
                    /* PMSTA-49175 - LJE - 220721 */

                    if (dictAttribStp->dbMandatoryFlg == FALSE &&
                        dictAttribStp->mandatoryFlg == TRUE &&
                        defaultValueStr.empty() == false && (this->ddlGenContextPtr->getCfgFileHelper().getPropertyBoolOrDefValue("ENABLE_UD_FIELD_NVL_FLAG", 1)) == true) 	  /* PMSTA-62080 - SRN - 20241219 */
                    {
                        printDefValIfIsNullFlg = TRUE;
                    }
                }
                else if (dictAttribStp->precompFlg == TRUE)
                {
                    this->setAlias(std::string("x"));

                    if (dictAttribStp->dataTpProgN == FlagType ||
                        dictAttribStp->dataTpProgN == EnumType ||
                        dictAttribStp->dataTpProgN == EnumMaskType)
                    {
                        printDefValIfIsNullFlg = TRUE;
                    }
                }
                else if (dictCriterStp->joinSqlName[0] != 0)
                {
                    if (bManageJoin)
                    {
                        /* PMSTA-28141 - LJE - 171117 - Manage the id reference on the same entity (questionnaire_histo.answer_object_id) */
                        /* PMSTA-49400 - LJE - 220603 */
                        if (dictCriterStp->isNullParent1ProgN == false &&
                            dictCriterStp->parentCriteria1Stp != nullptr &&
                            dictCriterStp->parentCriteria1Stp->entDictId == dictCriterStp->entDictId &&
                            dictCriterStp->attrPtr != nullptr &&
                            dictCriterStp->attrPtr->entDictId == dictCriterStp->entDictId &&
                            this->m_dictEntityStp->primKeyNbr == 1 &&
                            dictCriterStp->parentCriteria1Stp->attrDictId == this->m_dictEntityStp->primKeyTab[0]->attrDictId &&
                            (dictAttribStp->linkedAttrDictStp == nullptr || /* object_id */
                             dictAttribStp->linkedAttrDictStp->linkedAttrDictStp == nullptr)) /* entity_dict_id */
                        {
                            bManageJoin = false;
                        }
                        else
                        {
                            this->setAlias(dictCriterStp->joinSqlName);
                        }
                    }
                    else
                    {
                        printNullFlg = TRUE;
                    }
                }
                else
                {
                    this->setAlias(mainAlias);
                }
            }

            if (selListEn == SelList_Update &&
                ((this->targetTableEn == TargetTable_Main && dictAttribStp->primFlg == TRUE) ||
                (this->targetTableEn == TargetTable_UserDefinedFields && this->getUdIdSqlName().compare(colSqlName) == 0) ||    /* PMSTA-32145 - LJE - 180724 */
                 attribFeatureEn == XdEntityFeatureFeatureEn::MultiBusinessEntityManagement)) /* PMSTA-26108 - LJE - 170818 */
            {
                printAttribFlg = FALSE;
            }

            if (this->onlyPhysicalFlg == TRUE)
            {
                if (dictAttribStp->isPhysicalAttribute() == false ||
                    /* PMSTA-17439 - LJE - 140110 */
                    (selListEn != SelList_Call &&
                     selListEn != SelList_SelectInVar &&
                     selListEn != SelList_SelectCursor &&           /* PMSTA-23385 - LJE - 160714 */
                     selListEn != SelList_SelectDistinctCursor &&   /* PMSTA-26554 - LJE - 181101 */
                     selListEn != SelList_ForSelectDistinct &&      /* PMSTA-nuodb - LJE - 190812 */
                     selListEn != SelList_ForSelect &&              /* PMSTA-nuodb - LJE - 190812 */
                     selListEn != SelList_Select &&                 /* PMSTA-26554 - LJE - 181101 */
                     selListEn != SelList_InsertFull &&             /* PMSTA-nuodb - LJE - 190528 */
                     selListEn != SelList_InsertFullCall &&         /* PMSTA-nuodb - LJE - 190528 */
                     selListEn != SelList_SelectDistinct &&         /* PMSTA-26554 - LJE - 181101 */
                     (dictAttribStp->setBySpecProcFlg == TRUE ||
                      (dictAttribStp->primFlg == TRUE && this->m_dictEntityStp->pkRuleEn == PkRule_Identity))) ||
                    dictAttribStp->entDictId != dictCriterStp->entDictId ||
                    /* PMSTA-49178 - LJE - 220908 */
                    (selListEn == SelList_InsertFull || selListEn == SelList_InsertFullCall) &&
                    this->outputDynNatEn == DynType_FullDb &&
                    (dictAttribStp->primFlg == TRUE && this->m_dictEntityStp->pkRuleEn == PkRule_Identity))
                {
                    printAttribFlg = FALSE;
                }
            }

            /* ORACLE - LJE - 140630 */
            currSelectEltSt.tblAlias = this->getAlias();
            currSelectEltSt.sqlName = colSqlName;
            currSelectEltSt.mdSqlName = colSqlName;

            /* PMSTA-27525 - LJE - 170613 */
            if (dictAttribStp->primFlg == TRUE &&
                dictAttribStp->entDictId == this->m_dictEntityStp->entDictId)
            {
                currSelectEltSt.bPrimaryKey = true;
            }

            /* Special cases when a script come from a file */
            overriddenFlg = FALSE;
            bForceRemove = false;
            bForceKeep = false;

            if (overloadVector.size())
            {
                std::string::size_type begPos = 0, sepPos = 0;
                std::string            overloadStr;

                for (std::vector<OverloadLine>::iterator lineIt = overloadVector.begin(); lineIt != overloadVector.end(); lineIt++)
                {
                    if (lineIt->bTreated)
                        continue;

                    std::string lineStr = lineIt->lineStr;
                    std::string attrStr, valueStr, tmp;

                    if (lineStr.find("--") == 0)
                    {
                        lineStr.clear();
                        continue;
                    }

                    if (lineStr[0] == '-')
                    {
                        bForceRemove = true;
                        begPos = 1;

                        if (lineStr.compare("-all") == 0)
                        {
                            lineIt->bTreated = true;
                            bSetNullAll = true;
                            continue;
                        }
                    }
                    else if (lineStr[0] == '!')
                    {
                        begPos = 1;
                    }
                    else
                    {
                        begPos = 0;
                    }

                    sepPos = this->find_first_of(lineStr, "=\t ");
                    attrStr = lineStr.substr(begPos, sepPos);
                    trim(attrStr);

                    if (sepPos != std::string::npos)
                    {
                        std::string::size_type eqPos = this->find_first_not_of(lineStr, "\t ", sepPos);
                        if (eqPos != std::string::npos && lineStr[eqPos] == '=')
                        {
                            sepPos = eqPos + 1;
                        }

                        if (eqPos != std::string::npos)
                        {
                            tmp = lineStr.substr(sepPos);
                            trim(tmp);
                            if (tmp.empty() == false)
                            {
                                valueStr = tmp;
                            }
                        }
                        else
                        {
                            bForceKeep = true;
                        }
                    }
                    else
                    {
                        bForceKeep = true;
                    }

                    /* PMSTA-26250 - LJE - 170509 */
                    if ((lineStr.compare("+bk") == 0 && dictAttribStp->busKeyFlg == TRUE) ||
                        (lineStr.compare("+pk") == 0 && dictAttribStp->primFlg == TRUE))
                    {
                        lineIt->bTreated = true;
                        printAttribFlg = TRUE;
                        overriddenFlg = FALSE;
                        bForceKeep = true;
                        break;
                    }
                    else if ((lineStr.compare("-bk") == 0 && dictAttribStp->busKeyFlg == TRUE) ||
                        (lineStr.compare("-pk") == 0 &&
                             (this->targetTableEn == TargetTable_Main && dictAttribStp->primFlg == TRUE) ||
                         (this->targetTableEn == TargetTable_UserDefinedFields && this->getUdIdSqlName().compare(colSqlName) == 0)))
                    {
                        lineIt->bTreated = true;
                        bForceRemove = true;
                        bForceKeep = false;
                        overriddenFlg = TRUE;
                        break;
                    }
                    else if (attrStr.compare(colSqlName) != 0 &&
                             valueStr.compare(colSqlName) != 0)
                    {
                        bForceRemove = false;
                        bForceKeep = false;
                        overriddenFlg = FALSE;
                        lineStr.clear();
                        continue;
                    }

                    if (attrStr[0] == '@')
                    {
                        currSelectEltSt.varName = attrStr;
                        bAssignValue = true;
                    }

                    lineIt->bTreated = true;

                    /* PMSTA-14607 - LJE - 120719 - Special security case */
                    if (attribFeatureEn == XdEntityFeatureFeatureEn::AccessRightManagement &&    /* PMSTA-29879 - LJE - 180709 */
                        dictCriterStp->joinSqlName[0] == 0)
                    {
                        std::vector<std::string> tokens;
                        this->tokenizeStr(tokens, lineStr, " \t=.");

                        if (tokens.size() >= 3)
                        {
                            for (size_t joinPos = 0; joinPos < this->addedJoinTab.size(); joinPos++)
                            {
                                const DdlGenJoin &el = this->addedJoinTab[joinPos];
                                if (tokens[1].compare(this->getJoinAlias(el, true)) == 0)
                                {
                                    this->setAlias(tokens[1]);
                                    printDefValFlg = FALSE;
                                    bAuthCase = true;
                                    this->bManageAuthFlg = true;
                                    if (el.joinDictEntityStp != NULL)
                                    {
                                        entitySecurityLevelEn = el.joinDictEntityStp->securityLevelEn;
                                    }
                                    break;
                                }
                            }
                        }
                        break;
                    }

                    lineStr.clear();

                    if (bForceKeep)
                    {
                        printAttribFlg = TRUE;
                        overriddenFlg = FALSE;
                    }
                    else
                    {
                        overriddenFlg = TRUE;
                    }

                    /* Remove attribute or force keeping */
                    if (bForceRemove ||
                        bForceKeep ||
                        sepPos == std::string::npos ||
                        valueStr.empty())
                        break;

                    if (selListEn == SelList_List ||
                        selListEn == SelList_SelectCall ||
                        selListEn == SelList_Update ||
                        selListEn == SelList_SelectInVar ||
                        selListEn == SelList_Call ||
                        selListEn == SelList_Insert ||
                        selListEn == SelList_InsertCall)
                    {
                        if (selListEn == SelList_Call ||
                            selListEn == SelList_SelectCall ||
                            selListEn == SelList_Update ||
                            selListEn == SelList_SelectInVar)
                        {
                            if (mainAlias.empty() || valueStr.find_first_of("@$'0123456789") == 0 || strncasecmp(valueStr.c_str(), "null", 4) == 0)
                            {
                                locStream << valueStr;
                            }
                            else
                            {
                                currSelectEltSt.tblAlias = mainAlias;
                            }
                        }
                        else
                        {
                            locStream << valueStr;
                        }
                    }
                    else
                    {
                        std::string::size_type aliasPos;

                        while ((aliasPos = valueStr.find("#ALIAS.")) != std::string::npos)
                        {
                            valueStr.replace(aliasPos, strlen("#ALIAS."), this->getAlias());
                        }
                        locStream << valueStr;
                    }

                    /* PMSTA-24007 - LJE - 170723 */
                    if (bManageJoin &&
                        dictCriterStp->joinSqlName[0] != 0 &&
                        (this->find_word(valueStr, this->getAlias(true)) == std::string::npos && bAssignValue == false))
                    {
                        bManageJoin = false;
                    }

                    break;
                }
            }

            if ((selListEn == SelList_InsertFull ||
                 selListEn == SelList_InsertFullCall) &&
                dictAttribStp->primFlg == TRUE &&
                dictAttribStp->dictEntityStp->pkRuleEn == PkRule_Identity &&
                this->ddlGenContextPtr->isInsertIdentityOn() == false)
            {
                continue;
            }

            /* PMSTA-53383 - LJE - 240109 */
            if (bForceRemove         == false &&
                overriddenFlg        == FALSE &&
                selListEn            == SelList_Select &&
                this->outputDynNatEn == DynType_Short &&
                dictCriterStp->index >= 0)
            {
                bool bManageCustoAdmin = (printAttribFlg == FALSE && (dictAttribStp->custFlg || dictAttribStp->precompFlg == TRUE));

                if (bManageCustoAdmin == false && 
                    dictCriterStp->parentCriteria1Stp != nullptr)
                {
                    auto parentCriteria1Stp = dictCriterStp->parentCriteria1Stp;

                    if (parentCriteria1Stp->attrPtr != nullptr &&
                        (parentCriteria1Stp->attrPtr->custFlg == TRUE ||
                         parentCriteria1Stp->attrPtr->precompFlg == TRUE))
                    {
                        bManageCustoAdmin = true;
                    }
                    else if (bAuthCase == false &&
                             strcmp(dictCriterStp->joinSqlName, "up.") != 0)
                    {
                        auto cFieldStp = DBA_GetCFielBySqlName(GET_ADMINGUIST(this->m_dictEntityStp->objectEn), dictCriterStp->sqlName, nullptr);

                        if (cFieldStp == nullptr ||
                            cFieldStp->bRealCField == false)
                        {
                            bManageCustoAdmin = true;
                        }
                    }
                }

                if (bManageCustoAdmin)
                {
                    if (this->bManageAuthFlg &&
                        this->getDdlObjEn() == DdlObj_SProc &&
                        this->ddlGenContextPtr->getDictSprocSt().procActionEn == Select)
                    {
                        if (dictAttribStp->custFlg == TRUE)
                        {
                            this->custFlg = TRUE;
                        }
                        if (dictAttribStp->precompFlg == TRUE)
                        {
                            this->precompFlg = TRUE;
                        }
                    }
                    else if (this->ddlGenContextPtr->ddlBuildModeEn != DdlBuildMode_ViewOnly)
                    {
                        printNullFlg = TRUE;
                    }

                    printAttribFlg = TRUE;
                }
            }

            if (overriddenFlg == FALSE && (printAttribFlg == FALSE || bForceRemove))
            {
                continue;
            }

            if (this->ddlGenContextPtr->m_rdbmsEn == PostgreSQL &&
                overriddenFlg == TRUE &&
                (locStream.str().find_first_of("$'0123456789") == 0 || strncasecmp(locStream.str().c_str(), "null", 4) == 0))
            {
                bConvert = true;
            }

            if (bSetNullAll && bForceKeep == false)
            {
                printNullFlg = TRUE;
            }

            /* PMSTA-45027 - LJE - 210525 */
            if (overriddenFlg == FALSE &&
                this->realDictEntityStp != nullptr &&
                (this->outputDynNatEn != DynType_UdOnly || this->ddlGenContextPtr->m_useAlternativeDataServer))
            {
                DICT_ATTRIB_STP realDictAttribStp = this->realDictEntityStp->getDictAttribBySqlName(currSelectEltSt.sqlName);

                /* report_dataset case */
                if (realDictAttribStp == nullptr &&
                    this->ddlGenContextPtr->m_useAlternativeDataServer &&
                    dictAttribStp->primFlg == TRUE &&
                    this->realDictEntityStp->primKeyNbr == 1)
                {
                    realDictAttribStp = this->realDictEntityStp->primKeyTab[0];
                    attribSqlName = realDictAttribStp->sqlName;
                }

                /* PMSTA-45027 - LJE - 210525 */
                if (this->realDictEntityStp->entNatEn != EntityNat_DerivedEntity &&
                    (this->realObjectEn == NullEntity ||
                     this->realObjectEn == Empty ||
                     realDictAttribStp == nullptr ||
                     realDictAttribStp->isPhysicalAttribute() == false))
                {
                    bManageJoin = false;
                    this->setAlias(mainAlias);

                    bool bSysNotFound = true;
                    if (this->ddlGenContextPtr->m_parentContext->tablesFromSrcSysMap.empty() == false)
                    {
                        auto &srcSysTable = this->ddlGenContextPtr->m_parentContext->tablesFromSrcSysMap[this->realDictEntityStp->databaseName][this->realDictEntityStp->dbSqlName];
                        if (srcSysTable.find(currSelectEltSt.sqlName) != srcSysTable.end())
                        {
                            bSysNotFound = false;
                        }
                    }

                    if (bSysNotFound)
                    {
                        if (dictAttribStp->dfltVal.empty())
                        {
                            printNullFlg = TRUE;
                        }
                        else
                        {
                            printDefValFlg = TRUE;

                            if (dictAttribStp->dfltVal[0] == '{')
                            {
                                dictAttribStp->dfltVal.erase(0, 1);
                                dictAttribStp->dfltVal.erase(dictAttribStp->dfltVal.size() - 1, 1);
                            }
                        }
                    }
                }
                /* PMSTA-30346 - LJE - 180301 */
                /* Manage the case when the attribute is denormalized on the output entity but physical on the real entity */
                else if (entDictAttribStp != nullptr &&
                         entDictAttribStp->calcEn == DictAttr_Denorm &&
                         realDictAttribStp != nullptr &&
                         realDictAttribStp->isPhysicalAttribute())
                {
                    dictAttribStp      = realDictAttribStp;
                    attribSqlName      = realDictAttribStp->sqlName;
                    printDenormEnumFlg = FALSE;
                    printDefValFlg     = FALSE;
                    printNullFlg       = FALSE;
                    bManageJoin        = false;
                    this->setAlias(mainAlias);
                }
                /* PMSTA-48207 - LJE - 220302 - Manage mandatory attribute on migration case */
                else if (realDictAttribStp != nullptr &&
                         dictAttribStp->dbMandatoryFlg == TRUE &&
                         realDictAttribStp->dbMandatoryFlg == FALSE &&
                         dictAttribStp->dfltVal.empty() == false)
                {
                    printDefValIfIsNullFlg = TRUE;

                    if (dictAttribStp->dfltVal[0] == '{')
                    {
                        dictAttribStp->dfltVal.erase(0, 1);
                        dictAttribStp->dfltVal.erase(dictAttribStp->dfltVal.size() - 1, 1);
                    }
                }
            }

            if (this->ddlGenContextPtr->ddlBuildModeEn != DdlBuildMode_ViewOnly)
            {
                if (overriddenFlg == FALSE)
                {
                    /* PMSTA-26108 - LJE - 170828 - Print default value in case of "insert ... values" */
                    if (selListEn == SelList_InsertCall || selListEn == SelList_Call || selListEn == SelList_InsertFullCall)
                    {
                        if (this->varHelperPtr->getVariable(currSelectEltSt.sqlName, false) == nullptr)
                        {
                            if (this->ddlGenContextPtr->getDdlObjEn() == DdlObj_Sql ||
                                this->ddlGenContextPtr->getDdlObjEn() == DdlObj_RuntimeSql)
                            {
                                locStream << "?";

                                overriddenFlg = TRUE;
                            }
                            else if (dictAttribStp->dfltVal.empty() == false)
                            {
                                printDefValFlg = TRUE;
                            }
                            else
                            {
                                printNullFlg = TRUE;
                            }
                        }
                    }
                }

                /* Case of join with dict_label */
                if (dictCriterStp->attrEntObj == DictLabel &&
                    strcmp(attribSqlName.c_str(), "name") == 0 &&
                    dictCriterStp->isNullParent1ProgN == false)
                {
                    if (bTranslate)
                    {
                        this->ddlGenContextPtr->bLanguage = true;
                        this->labelFlg = TRUE;
                        printLabelFlg = TRUE;
                    }
                    else
                    {
                        bManageJoin = false;
                        this->setAlias(mainAlias);
                    }
                }

                /* Case of join with denomination */
                if (bTranslate &&
                    strcmp(attribSqlName.c_str(), "denom") == 0 &&
                    this->m_dictEntityStp->primKeyNbr == 1) /* PMSTA-14311 - LJE - 120618 */
                {
                    DdlGenJoin newJoin; /* PMSTA-14607 - LJE - 120720 */

                    this->ddlGenContextPtr->bLanguage = true;
                    this->denomFlg = TRUE;
                    printDenomFlg = TRUE;

                    newJoin.joinDictEntityStp = DBA_GetDictEntitySt(Denom);
                    newJoin.joinSqlName = std::string("d.");
                    if (dictCriterStp->dynNatEn == DynType_All)
                        newJoin.firstIdPos = this->m_dictEntityStp->primKeyTab[0]->progN;
                    else
                        newJoin.firstIdPos = this->m_dictEntityStp->primKeyTab[0]->shortIdx;

                    newJoin.isNullFirstId   = false;
                    newJoin.secondIdPos     = 0;
                    newJoin.isNullSecondId  = true;
                    newJoin.securityLevelEn = EntSecuLevel_NoSecured;
                    newJoin.codifFlg        = FALSE;
                    newJoin.parentEntDictId = attrDictEntityStp->entDictId;
                    newJoin.mandatoryFlg    = FALSE;
                    newJoin.objectEn        = Denom;

                    joinTab.push_back(newJoin);
                }

                /* Case of join with codification */
                if (this->ddlGenContextPtr->m_bCodif &&
                    this->m_dictEntityStp->synonFlg == TRUE &&
                    strcmp(attribSqlName.c_str(), "code") == 0 &&
                    dictCriterStp->isNullParent1ProgN)
                {
                    printCodifFlg = TRUE;
                }

                if (strcmp(dictCriterStp->joinSqlName, "up.") == 0)
                {
                    bManageJoin = false;
                    bAuthCase = true;    /* OCS-38989 - LJE - 110927 */

                    if (this->bManageAuthFlg == false) /* PMSTA-14607 - LJE - 120712 */
                    {
                        /* If we don't use the auth_* flag, return the meta-dict default value */
                        printDefValFlg = TRUE;
                        printNullFlg = FALSE;
                        bAuthCase = false;
                    }
                    else if (entitySecurityLevelEn == EntSecuLevel_NoSecured)
                    {
                        printDefValFlg = TRUE;
                        printNullFlg = FALSE;
                    }

                    /* PMSTA-29879 - LJE - 180709 - Special security case */
                    if (attribFeatureEn == XdEntityFeatureFeatureEn::AccessRightManagement && this->m_authAlias.empty() == false)
                    {
                        auto joinIt = this->addedJoinTab.begin();
                        for (; joinIt != this->addedJoinTab.end(); ++joinIt)
                        {
                            if (this->m_authAlias.compare(this->getJoinAlias(*joinIt, true)) == 0)
                            {
                                this->setAlias(this->m_authAlias);

                                printDefValFlg = FALSE;
                                bAuthCase = true;
                                this->bManageAuthFlg = true;
                                if (joinIt->joinDictEntityStp != NULL)
                                {
                                    entitySecurityLevelEn = joinIt->joinDictEntityStp->securityLevelEn;
                                }
                                break;
                            }
                        }

                        if (joinIt == this->addedJoinTab.end())
                        {
                            ret = RET_DBA_ERR_INVDATA;
                            this->printMsg(ret, "Unknown alias ( " + this->m_authAlias + " ) for right authorization on attribute " + colSqlName);
                        }
                    }
                    else if (this->isSecuredWithAddDSP(entitySecurityLevelEn) || this->secuMandatoryFlg == FALSE)
                    {
                        this->setAlias(mainAlias);
                    }
                }
            }
            else if (this->m_outputViewEn == View_Custom)
            {
                if (outputViewEn == View_ShortSecured &&
                    dictAttribStp->isNullShortIdx)
                {
                    outputViewEn = View_FullAllSecured;
                }
            }

            if (bAssignValue || (overriddenFlg == FALSE && dictCriterStp->toPrintFlg == TRUE))
            {
                locStream.clear();
                locStream.str(std::string());

                if (printNullFlg == TRUE)
                {
                    bConvert = false;

                    if (printDenomFlg == TRUE)
                    {
                        locStream << "d.denom";
                    }
                    else if (printCodifFlg == TRUE)
                    {
                        locStream << "sy.code";
                    }
                    else if (this->getDdlObjEn() != DdlObj_View == false &&
                             strcmp(this->m_dictEntityStp->mdSqlName, "list") == 0 &&
                             strcmp(attribSqlName.c_str(), "query_definition") == 0)
                    {
                        locStream << "case when " << this->getAlias()
                            << "nature_e in(2, 6) then " << this->getDbo() << "get_list_definition(" << this->getAlias() << "id) else null end";
                    }
                    else if (selListEn == SelList_Call)
                    {
                        locStream << "null";
                    }
                    else
                    {
                        bManageJoin = false;
                        bConvert    = true;
                        locStream << "null";
                    }
                }
                else if (printLabelFlg == TRUE &&
                         dictCriterStp->isNullParent1ProgN == false)
                {
                    auto parentDictCriteria = dictCriterStp->parentCriteria1Stp;

                    if (parentDictCriteria->attrPtr->refEntDictId != 0)
                    {
                        locStream << DdlGenDbi::getCmdIsNull() << "(" << "L" << this->getAlias().substr(1) << attribSqlName << ", " <<
                            this->getAlias() << attribSqlName << ")";
                    }
                    else
                    {
                        locStream << DdlGenDbi::getCmdIsNull() << "(" << this->getAlias() << attribSqlName << ", "
                            << this->getCriteriaAlias(parentDictCriteria) << parentDictCriteria->attrPtr->sqlName << ")";
                    }
                }
                else if (printDenomFlg == TRUE)
                {
                    bConvert = false;
                    locStream << DdlGenDbi::getCmdIsNull() << "(d.denom, " << this->getAlias()
                        << attribSqlName << ")";
                }
                else if (printCodifFlg == TRUE)
                {
                    bConvert = false;
                    locStream << DdlGenDbi::getCmdIsNull() << "(sy.code, " << this->getAlias()
                        << attribSqlName << ")";
                }
                else if (bAuthCase == true)
                {
                    if (attribSubFeatureEn == SubFeature::RightReason)
                    {
                        if (this->isSecuredLevel(entitySecurityLevelEn))
                        {
                            locStream << (int)RightReason_Security;
                        }
                        else
                        {
                            locStream << (int)RightReason_NotSecured;
                        }
                    }
                    else if (printDefValFlg)
                    {
                        /* If the entity isn't secured, the default value of the auth_*_f attribute is 1 */
                        locStream << (this->isSecuredLevel(entitySecurityLevelEn) ? defaultValueStr : "1");
                    }
                    else if (this->securityTemplate)
                    {
                        bConvert = false;

                        this->setIndent(2);
                        auto toPrintIt = this->securityTemplate->selectMap.find(colSqlName);
                        if (toPrintIt != this->securityTemplate->selectMap.end())
                        {
                            locStream << toPrintIt->second;
                        }
                        else
                        {
                            ret = RET_DBA_ERR_INVDATA;
                            this->printMsg(ret, "Unknown template attribute definition for attribute: " + colSqlName);
                        }
                        this->setIndent(-2);
                    }
                    else if (this->isSecuredWithAddDSP(entitySecurityLevelEn))
                    {
                        this->setIndent(2);

                        locStream
                            << "coalesce("
                            << "(select dpc1." << attribSqlName << this->newLine()
                            << "  from " << this->getEntityFullSqlName("data_prof_compo") << " dpc1" << this->newLine()
                            << " where ((dpc1.data_profile_id = " << this->getDataProfile() << ")" << this->newLine()
                            << "   and (" << this->getAlias() << "data_secu_prof_id  = dpc1.data_secu_prof_id)"
                            << "   and (dpc1." << attribSqlName << " = 1)))," << this->newLine()
                            << "(select dpc1." << attribSqlName << this->newLine()
                            << "  from " << this->getEntityFullSqlName("data_prof_compo") << " dpc1" << this->newLine()
                            << " where ((dpc1.data_profile_id = " << this->getDataProfile() << ")" << this->newLine()
                            << "   and (" << this->getAlias() << "data_secu_prof2_id = dpc1.data_secu_prof_id)"
                            << "   and (dpc1." << attribSqlName << " = 1))),";

                        if (this->ddlGenContextPtr->m_rdbmsEn == PostgreSQL)
                        {
                            bConvert = false;
                            locStream
                                << "   " << this->convert(FlagType, "0") << ")";
                        }
                        else
                        {
                            locStream
                                << "   0)";
                        }
                            
                        this->setIndent(-2);
                    }
                    else if (entitySecurityLevelEn == EntSecuLevel_Secured)
                    {
                        bConvert = false;

                        this->setIndent(2);
                        if (mainAlias.compare(this->getAlias()) != 0 && this->getAlias().compare("up.") != 0)
                        {
                            if (this->ddlGenContextPtr->m_rdbmsEn == Nuodb)
                            {
                                locStream << this->getAlias() << attribSqlName;
                            }
                            else
                            {
                                locStream << this->getAlias(true) << "_" << "up." << attribSqlName;
                            }
                        }
                        else
                        {
                            locStream << "up." << attribSqlName;
                        }

                        this->setIndent(-2);
                    }
                    else
                    {
                        if (this->isSecuredLevel(entitySecurityLevelEn))
                        {
                            locStream << (int)RightReason_Security;
                        }
                        else
                        {
                            locStream << (int)RightReason_NotSecured;
                        }
                    }
                }
                else if (dictAttribStp->subFeatureEn == SubFeature::MeRecordLocation)
                {
                    if (currDictEntityStp->multiEntityCateg.isPartialSpecialzed() == true &&
                        this->ddlGenContextPtr->getMultiEntityLevel() == MultiEntityLevel_Active)
                    {
                        if (this->ddlGenContextPtr->getDdlGenMode() == DdlGenMode_MultiEntity &&
                            currDictEntityStp->udPKNbr != 0)
                        {
                            if (this->mulitEntityAccessEn == MultiEntityAccess_PartialSpecialization)
                            {
                                locStream
                                    << "(case when " << this->getAlias(true) + "_be." << currDictEntityStp->dbPKTab[0]->sqlName << " is null"
                                    << " then " << (int)MeRecordLocation_Master
                                    << " else " << (int)MeRecordLocation_Partial
                                    << " end)";
                            }
                            else
                            {
                                locStream << (int)MeRecordLocation_Local;
                            }
                        }
                        else if (this->ddlGenContextPtr->getViewEn() == View_Tech &&
                                 currDictEntityStp->multiEntityCateg.isUseMeViewAsTable() == false)
                        {
                            locStream << (int)MeRecordLocation_Master;
                        }
                        else if (currDictEntityStp->dbRuleEn == DbRule_ShadowTable)
                        {
                            locStream
                                << "(case " << this->getAlias() << currDictEntityStp->ownerBusinessEntAttrStp->sqlName
                                << " when " << this->ddlGenContextPtr->getMasterBusinessEntityId()
                                << " then (case " <<  this->getConnBusinessEntityId() << this->newLine()
                                << " when " << this->ddlGenContextPtr->getMasterBusinessEntityId()
                                << " then " << (int)MeRecordLocation_Master << this->newLine()
                                << " else " << (int)MeRecordLocation_Partial << this->newLine()
                                << " end)"
                                << " else " << (int)MeRecordLocation_Local << this->newLine()
                                << " end)";
                        }
                        else
                        {
                            locStream << this->getAlias() << colSqlName;
                        }
                    }
                    else if (currDictEntityStp->ownerBusinessEntAttrStp != nullptr &&
                             this->ddlGenContextPtr->getMultiEntityLevel() == MultiEntityLevel_Active)
                    {
                        if (currDictEntityStp->multiEntityCateg.isAllowedOnlyInMaster())
                        {
                            locStream << (int)MeRecordLocation_Master;
                        }
                        else if (this->ddlGenContextPtr->ddlBuildModeEn == DdlBuildMode_ViewOnly) /* KNI - PMSTA-41545 - 30102020 */
                        {
                            locStream << this->getAlias() << colSqlName;
                        }
                        else
                        {
                            locStream
                                << "(case " << this->getAlias() << currDictEntityStp->ownerBusinessEntAttrStp->sqlName
                                << " when " << this->ddlGenContextPtr->getMasterBusinessEntityId()
                                << " then " << (int)MeRecordLocation_Master
                                << " else " << (int)MeRecordLocation_Local
                                << " end)";
                        }
                    }
                    else
                    {
                        locStream << (int)MeRecordLocation_None;
                    }
                }
                /* PMSTA-50496 - LJE - 230111 */
                else if (selListEn != SelList_List &&
                         selListEn != SelList_Insert &&
                         selListEn != SelList_Update &&
                         this->ddlGenContextPtr->ddlBuildModeEn != DdlBuildMode_ViewOnly &&
                         entDictAttribStp != nullptr &&
                         entDictAttribStp->featureEn == XdEntityFeatureFeatureEn::AccessRightManagement)
                {
                    if (attribSubFeatureEn == SubFeature::RightReason)
                    {
                        if (this->isSecuredLevel(currDictEntityStp->securityLevelEn))
                        {
                            locStream << (int)RightReason_None;
                        }
                        else
                        {
                            locStream << (int)RightReason_NotSecured;
                        }
                    }
                    else
                    {
                        locStream << (this->isSecuredLevel(currDictEntityStp->securityLevelEn) ? "0" : "1");
                    }
                }
                else if (printDefValFlg == TRUE)
                {
                    bManageJoin = false;
                    if (selListEn == SelList_Call)
                    {
                        bConvert = false;
                        locStream << dictAttribStp->dfltVal;
                    }
                    else if (IS_STRING_TYPE(dictAttribStp->dataTpProgN) == TRUE)
                    {
                        locStream << "'" << dictAttribStp->dfltVal << "'";
                    }
                    else
                    {
                        locStream << dictAttribStp->dfltVal;
                    }
                }
                else if (printDefValIfIsNullFlg == TRUE)
                {
                    locStream << DdlGenDbi::getCmdIsNull() << "(" << this->getAlias() << attribSqlName << ", ";

                    if (this->ddlGenContextPtr->m_rdbmsEn == PostgreSQL)
                    {
                        locStream
                            << this->convert(dictAttribStp->dataTpProgN, (dictAttribStp->dfltVal.empty() ? "0" : dictAttribStp->dfltVal))
                            << ")";
                    }
                    else
                    {
                        locStream
                            << (dictAttribStp->dfltVal.empty() ? "0" : dictAttribStp->dfltVal) << ")";
                    }
                }
                else if (dictAttribStp->primFlg == TRUE &&
                         dictAttribStp->entDictId != this->m_dictEntityStp->entDictId &&
                         dictCriterStp->isNullParent1ProgN == false &&
                         dictCriterStp->parentCriteria1Stp &&
                         dictCriterStp->parentCriteria1Stp->attrPtr->refEntDictId == entityDictId &&
                         dictCriterStp->isNullParent2ProgN == false)
                {
                    locStream << "case when "
                        << mainAlias << dictCriterStp->parent1SqlName
                        << " = " << dictCriterStp->attrEntDictId
                        << " then " << mainAlias << dictCriterStp->parent2SqlName
                        << " else null end";
                }
                else if (printDenormEnumFlg == TRUE)
                {
                    bool bOneEnum = false;
                    std::stringstream enumValueStream;

                    enumValueStream << "case " << mainAlias << dictAttribStp->linkedAttrDictStp->sqlName;

                    for (auto permValIt = dictAttribStp->permValMap.begin(); permValIt != dictAttribStp->permValMap.end(); ++permValIt)
                    {
                        if (permValIt->second.refEntityDictId != 0)
                        {
                            enumValueStream << " when " << permValIt->second.refEntityDictId
                                << " then " << CAST_INT(permValIt->second.permVal);
                            bOneEnum = true;
                        }
                    }
                    if (bOneEnum == false)
                    {
                        /* Invalid case! */
                        std::stringstream msgStream;
                        msgStream << "Invalid denorm. enumerate definition: " << this->m_dictEntityStp->mdSqlName << "." << attribSqlName;
                        this->printMsg(RET_DBA_ERR_NODATA, msgStream.str());
                    }
                    enumValueStream << " end";
                    locStream << enumValueStream.str();
                }
                /* PMSTA-16775 - LJE - 130903 - Manage logical references */
                else if (dictCriterStp->isNullParent1ProgN == false &&
                         dictAttribStp->entDictId == this->m_dictEntityStp->entDictId &&
                         dictCriterStp->parentCriteria1Stp &&
                         dictCriterStp->parentCriteria1Stp->attrPtr->primFlg == TRUE &&
                         dictAttribStp->linkedAttrDictStp != NULL &&                  /* object_id */
                         dictAttribStp->linkedAttrDictStp->linkedAttrDictStp != NULL) /* entity_dict_id */
                {
                    OBJECT_ENUM linkObjEn;
                    DICT_ENTITY_STP linkDictEntityStp;

                    bConvert = false;
                    bManageLogFk = true;
                    DBA_GetObjectEnum(dictAttribStp->linkedAttrDictStp->entDictId, &linkObjEn);

                    if ((linkDictEntityStp = DBA_GetDictEntitySt(linkObjEn)) != NULL &&
                        linkDictEntityStp->primKeyNbr == 1)
                    {
                        locStream << this->getAlias() << linkDictEntityStp->primKeyTab[0]->sqlName;
                    }
                    else
                    {
                        locStream << this->getAlias() << "/* Invalid logical reference */";
                    }
                }
                /* PMSTA-26252 - LJE - 170215 */
                else if (selListEn != SelList_InsertCall &&
                    (DdlGenDbi::getOptimisticLockingRule(dictAttribStp) == OptimisticLocking_RowScn ||
                     DdlGenDbi::getOptimisticLockingRule(dictAttribStp) == OptimisticLocking_RowVersion))
                {
                    bConvert = false;

                    currSelectEltSt.sqlName = DdlGenDbi::getOptimisticLockingSqlName(this->m_dictEntityStp);

                    if (selListEn != SelList_Update)
                    {
                        locStream << this->getAlias() << currSelectEltSt.sqlName;
                    }
                }
                else if (selListEn == SelList_Update && dictAttribStp->calcEn == DictAttr_ExternalSeqNo)
                {
                    DdlSprocParam *extSeqNoParam = this->varHelperPtr->getParameter(attribSqlName);
                    if (extSeqNoParam)
                    {
                        bConvert = false;
                        locStream << "(case when " << extSeqNoParam->printSqlName() << " is null then " << this->getAlias() << attribSqlName << " else " << extSeqNoParam->printSqlName() << " end)";
                    }
                    else
                    {
                        locStream << this->getAlias() << attribSqlName;
                    }
                }
                /* PMSTA-26108 - LJE - 170818 */
                else if (attribFeatureEn == XdEntityFeatureFeatureEn::MultiBusinessEntityManagement &&
                    (selListEn == SelList_Select || selListEn == SelList_InsertSelect) &&
                    this->getDdlObjEn() != DdlObj_View &&
                    this->bNestedRequest == true &&
                    this->ddlGenContextPtr->getMultiEntityLevel() == MultiEntityLevel_Active)
                {
                    bConvert = false;
                    locStream << this->getConnBusinessEntityId();
                }
                else if (this->ddlGenContextPtr->ddlBuildModeEn == DdlBuildMode_ViewOnly)
                {
                    locStream << mainAlias << colSqlName;
                }
                else
                {
                    bConvert = false;
                    locStream << this->getAlias() << attribSqlName;
                }

                /* PMSTA-27463 - LJE - 170608 */
                if (bAuthCase == true && attribSubFeatureEn != SubFeature::UpdateSecuRight && attribSubFeatureEn != SubFeature::DeleteSecuRight)
                {
                    bAuthPrinted = true;

                    if (this->getDictEntityStp()->changeSetAuthEn == FeatureAuth_Enable || this->m_dictEntityStp->ownerBusinessEntAttrStp != nullptr)
                    {
                        std::string attrStr = locStream.str();
                        locStream.clear();
                        locStream.str(std::string());

                        bool bMultiEntityClause = false;
                        if (this->m_dictEntityStp->ownerBusinessEntAttrStp != nullptr &&
                            (this->realDictEntityStp == nullptr || this->realDictEntityStp->ownerBusinessEntAttrStp != nullptr) &&
                            this->ddlGenContextPtr->bAvoidMultiEntity == false &&
                            (this->m_dictEntityStp->multiEntityCateg.isMultiEntityVisibility() == true || this->m_dictEntityStp->multiEntityCateg.isPartialSpecialzed()))
                        {
                            if (this->m_dictEntityStp->multiEntityCateg.isMultiEntityVisibility() == true)
                            {
                                bMultiEntityClause = true;
                                if (attribSubFeatureEn == SubFeature::RightReason)
                                {
                                    locStream
                                        << "(case when " << mainAlias << this->m_dictEntityStp->ownerBusinessEntAttrStp->sqlName << " <> " << this->getConnBusinessEntityId() << " then " << (int)RightReason_MultiEntityRestrict << " else ";
                                }
                                else
                                {
                                    locStream
                                        << "(case when " << mainAlias << this->m_dictEntityStp->ownerBusinessEntAttrStp->sqlName << " <> " << this->getConnBusinessEntityId() << " then 0 else ";
                                }
                            }
                            else if (attribSubFeatureEn == SubFeature::DeleteRight &&
                                     this->m_dictEntityStp->multiEntityCateg.isPartialSpecialzed())
                            {
                                bMultiEntityClause = true;

                                if (currDictEntityStp->dbRuleEn == DbRule_ShadowTable)
                                {
                                    locStream
                                        << "(case when " << this->getAlias() << currDictEntityStp->ownerBusinessEntAttrStp->sqlName << " = " << (int)MeRecordLocation_Master
                                        << " and " << this->getConnBusinessEntityId() << " <> " << this->ddlGenContextPtr->getMasterBusinessEntityId()
                                        << " then 0 else ";
                                }
                                else
                                {
                                    locStream
                                        << "(case when " << mainAlias << "me_record_location_e = " << (int)MeRecordLocation_Master
                                        << " and " << this->getConnBusinessEntityId() << " <> " << this->ddlGenContextPtr->getMasterBusinessEntityId()
                                        << " then 0 else ";
                                }
                            }
                        }

                        if (this->getDictEntityStp()->changeSetAuthEn == FeatureAuth_Enable)
                        {
                            if (this->ddlGenContextPtr->getDdlGenMode() == DdlGenMode_Shadow)
                            {
                                if (attribSubFeatureEn == SubFeature::DeleteRight)
                                {
                                    locStream
                                        << "(case when " << mainAlias << "sh_action_e > " << (int)ShadActionEnum_None << " /* None */ then " << attrStr << " else 0 end)";
                                }
                                else if (attribSubFeatureEn == SubFeature::UpdateRight)
                                {
                                    locStream
                                        << "(case when pk.obj_status_e = " << (int)ObjStatus_Validated << " /* Validated */ "
                                        << "or " << mainAlias << "sh_action_e > " << (int)ShadActionEnum_None << " /* None */ then " << attrStr << " else 0 end)";
                                }
                                else if (attribSubFeatureEn == SubFeature::RightReason)
                                {
                                    locStream
                                        << "(case when pk.obj_status_e = " << (int)ObjStatus_Validated << " /* Validated */ "
                                        << "or " << mainAlias << "sh_action_e > " << (int)ShadActionEnum_None << " /* None */ then " << attrStr << " else " << (int)RightReason_ActiveChangeSet << " end)";
                                }
                                else
                                {
                                    SYS_BreakOnDebug();
                                }
                            }
                            else
                            {
                                if (attribSubFeatureEn == SubFeature::RightReason)
                                {
                                    locStream
                                        << "(case when pk.obj_status_e = " << (int)ObjStatus_Validated << " /* Validated */ then " << attrStr << " else " << (int)RightReason_ActiveChangeSet << " end)";
                                }
                                else
                                {
                                    locStream << "(case pk.obj_status_e when " << (int)ObjStatus_Validated << " /* Validated */ then " << attrStr << " else 0 end)";
                                }
                            }
                        }
                        else
                        {
                            locStream << attrStr;
                        }

                        if (bMultiEntityClause)
                        {
                            locStream << " end)";
                        }

                        bConvert = true;
                    }
                }
                else if (bAuthCase == true &&
                    (attribSubFeatureEn == SubFeature::UpdateSecuRight || attribSubFeatureEn == SubFeature::DeleteSecuRight) &&
                         this->getDictEntityStp()->changeSetAuthEn != FeatureAuth_Enable &&
                         (currDictEntityStp->ownerBusinessEntAttrStp == nullptr || currDictEntityStp->multiEntityCateg.isMultiEntityVisibility() == false))
                {
                    bConvert = true;

                    locStream.clear();
                    locStream.str(std::string());
                    locStream << "0";
                }
            }

            if (locStream.str().empty() == false)
            {
                std::string::size_type pos;
                if ((pos = locStream.str().find(".")) < this->find_first_of(locStream.str(), " \t="))
                {
                    bConvert = false;
                    currSelectEltSt.tblAlias = locStream.str().substr(0, pos + 1);
                }
                else if (locStream.str().find("@") == 0)
                {
                    bConvert = false;
                    currSelectEltSt.tblAlias.clear();
                }
                else if (DdlGen::find_word(locStream.str(), "#CONVERT") == 0)
                {
                    bConvert = false;
                }

                if (bConvert && locStream.str().empty() == false)
                {
                    std::string convertStr = this->convert(dictAttribStp->dataTpProgN, locStream.str(), dictAttribStp->dbMandatoryFlg == FALSE);
                    locStream.clear();
                    locStream.str(convertStr);
                }

                currSelectEltSt.value = locStream.str();

                std::string::size_type outputPos = this->posKey(currSelectEltSt.value, "output");
                if (outputPos != std::string::npos)
                {
                    currSelectEltSt.value = currSelectEltSt.value.substr(0, outputPos);
                    trim(currSelectEltSt.value);
                    currSelectEltSt.bOutput = true;
                }
                selectList.push_back(currSelectEltSt);
            }

            if (dictCriterStp->sortRank > 0 && selListEn == SelList_Select)
            {
                this->bOrderBy = true;
                if (maxSortRk < dictCriterStp->sortRank)
                    maxSortRk = dictCriterStp->sortRank;
                if (minSortRk > dictCriterStp->sortRank)
                    minSortRk = dictCriterStp->sortRank;
            }

            if ((dictAttribStp->primFlg == FALSE ||
                 dictAttribStp->entDictId == this->m_dictEntityStp->entDictId) && /* PMSTA-14311 - LJE - 120620 */
                dictCriterStp->isNullParent1ProgN == false &&
                bManageJoin) /* PMSTA-14607 - LJE - 120719 */
            {
                if (overriddenFlg == FALSE ||
                    currSelectEltSt.value.find(this->getAlias()) != std::string::npos ||
                    currSelectEltSt.tblAlias.compare(this->getAlias()) == 0)
                {
                    auto            it = this->joinTab.begin();
                    DICT_CRITER_STP parentDictCriteria = dictCriterStp->parentCriteria1Stp;

                    while (it != this->joinTab.end() &&
                           this->getAlias() != it->joinSqlName.c_str())
                    {
                        ++it;
                    }
                    bool bDoNewJoin = (it == this->joinTab.end());

                    auto labelIt = this->joinTab.begin();
                    if (printLabelFlg == TRUE &&
                        bDoNewJoin    == false)
                    {
                        std::string labelJoin = it->joinSqlName;
                        labelJoin[0] = 'L';

                        while (labelIt != this->joinTab.end() &&
                               labelJoin.compare(labelIt->joinSqlName) != 0)
                        {
                            ++labelIt;
                        }
                    }
                    bool bDoLabelJoin = (labelIt == this->joinTab.end());

                    if (bDoNewJoin || bDoLabelJoin)
                    {
                        DdlGenJoin newJoin; /* PMSTA-14607 - LJE - 120720 */

                        if (dictCriterStp->parent1ProgN >= (FIELD_IDX_T)this->infoCriterMap->size() ||
                            dictCriterStp == parentDictCriteria)
                        {
                            this->printMsg(RET_GEN_ERR_INVARG, "wrong parent reference in dict_criteria");
                            return RET_GEN_ERR_INVARG;
                        }

                        if (printLabelFlg == TRUE)
                        {
                            newJoin.mandatoryFlg = FALSE;
                        }
                        else
                        {
                            newJoin.mandatoryFlg = TRUE;
                        }
                        newJoin.sortJoin = dictCriterStp->progN; /* PMSTA-13122 - LJE - 120619 */

                        if (bManageLogFk)
                        {
                            OBJECT_ENUM refObjEn;
                            DBA_GetObjectEnum(dictAttribStp->refEntDictId, &refObjEn);
                            newJoin.joinDictEntityStp = attrDictEntityStp = DBA_GetDictEntitySt(refObjEn);
                            newJoin.dictAttribStp     = dictAttribStp;
                            newJoin.joinTypeEn        = DDlJoinType_LogicalFkJoin;
                            newJoin.mandatoryFlg      = dictAttribStp->dbMandatoryFlg; /* PMSTA-34418 - LJE - 190130 */
                        }
                        else
                        {
                            newJoin.joinDictEntityStp = attrDictEntityStp;
                        }
                        newJoin.joinSqlName    = this->getCriteriaAlias(dictCriterStp);
                        newJoin.firstIdPos     = dictCriterStp->parent1ProgN;
                        newJoin.isNullFirstId  = dictCriterStp->isNullParent1ProgN;
                        newJoin.secondIdPos    = dictCriterStp->parent2ProgN;
                        newJoin.isNullSecondId = dictCriterStp->isNullParent2ProgN;
                        if (this->ddlGenContextPtr->bAvoidSecured)
                        {
                            newJoin.securityLevelEn = EntSecuLevel_NoSecured;
                        }
                        else
                        {
                            newJoin.securityLevelEn = attrDictEntityStp->securityLevelEn;
                        }
                        newJoin.codifFlg = FALSE;
                        newJoin.parentEntDictId = parentDictCriteria->attrEntDictId;

                        /* Reset loop test */
                        for (auto criterIt2 = this->infoCriterMap->begin(); criterIt2 != this->infoCriterMap->end(); criterIt2++)
                        {
                            criterIt2->second->bLoopTest = false;
                        }

                        /* Set the mandatory flag until the main object */
                        while (parentDictCriteria != NULL &&
                               newJoin.mandatoryFlg == TRUE)
                        {
                            if (parentDictCriteria->attrPtr != NULL)
                            {
                                newJoin.mandatoryFlg = parentDictCriteria->attrPtr->dbMandatoryFlg; /* PMSTA-34418 - LJE - 190130 */
                            }

                            if (parentDictCriteria->isNullParent1ProgN == false)
                            {
                                if (parentDictCriteria->bLoopTest ||
                                    parentDictCriteria->parent1ProgN >= (FIELD_IDX_T)this->infoCriterMap->size() ||
                                    parentDictCriteria->parentCriteria1Stp == nullptr ||
                                    parentDictCriteria == parentDictCriteria->parentCriteria1Stp)
                                {
                                    this->printMsg(RET_GEN_ERR_INVARG, "wrong parent reference in dict_criteria");
                                    return RET_GEN_ERR_INVARG;
                                }
                                parentDictCriteria->bLoopTest = true;
                                parentDictCriteria = parentDictCriteria->parentCriteria1Stp;
                            }
                            else
                            {
                                parentDictCriteria = NULL;
                            }
                        }
                        newJoin.objectEn = dictCriterStp->attrEntObj;

                        if (printLabelFlg == TRUE &&
                            parentDictCriteria->joinSqlName[0] == 0 &&
                            parentDictCriteria->attrPtr->refEntDictId != 0)
                        {
                            newJoin.joinSqlName[0] = 'L';
                            newJoin.parentEntDictId = parentDictCriteria->attrPtr->refEntDictId;

                            if (bDoNewJoin)
                            {
                                this->joinTab.push_back(newJoin);
                                newJoin.joinSqlName[0] = 'J';

	                            newJoin.parentEntDictId = parentDictCriteria->attrEntDictId;
	                            DBA_GetObjectEnum(parentDictCriteria->attrPtr->refEntDictId, &newJoin.objectEn);
	                            newJoin.joinDictEntityStp = DBA_GetDictEntitySt(newJoin.objectEn);
	                            newJoin.mandatoryFlg = parentDictCriteria->attrPtr->dbMandatoryFlg;
	                     	}
                        }

                        this->joinTab.push_back(newJoin);
                    }
                }
            }
        }
    }

    this->setAlias(mainAlias);

    /* Add extra attribute... */
    if (this->overloadStream.str().empty() == false)
    {
        std::string::size_type pos, dotPos;
        bool                        bOnlySpecAttr = true;
        std::list<std::string>      msgList;

        for (auto lineIt = overloadVector.begin(); lineIt != overloadVector.end(); ++lineIt)
        {
            if (lineIt->bTreated)
                continue;

            /* PMSTA-37366 - LJE - 191002 */
            if (this->outputDynNatEn != DynType_Null &&
                this->getDdlObjEn() == DdlObj_SProc &&
                selListEn != SelList_Insert &&
                selListEn != SelList_InsertCall &&
                selListEn != SelList_Update)
            {
                if (this->ddlGenContextPtr->getDictSprocSt().m_storedProcAccessVector.empty() == false)
                {
                    bool bWarning = false;
                    for (auto sprocIt = this->ddlGenContextPtr->getDictSprocSt().m_storedProcAccessVector.begin(); sprocIt != this->ddlGenContextPtr->getDictSprocSt().m_storedProcAccessVector.end(); ++sprocIt)
                    {
                        if ((*sprocIt)->outputDynStPtr == nullptr ||
                            GET_DYNST_TYPE((*(*sprocIt)->outputDynStPtr)) != DynType_Other)
                        {
                            bWarning = true;
                            break;
                        }
                    }

                    if (bWarning)
                    {
                        this->printMsg(RET_DBA_INFO_NODATA, "It's not allowed to write an output select having custom fields (" + lineIt->lineStr + ")");
                    }
                }
                this->m_bAddFieldOnSelect = true;
            }

            std::string lineStr = lineIt->lineStr;
            std::string newStr;
            DdlSelectElt currSelectEltSt;

            currSelectEltSt.datatype = NullDataType;
            currSelectEltSt.bOutput = false;

            /* To add attribute, put "+" at the beginning */
            pos = lineStr.find_last_of("+");

            if (this->infoCriterMap &&
                this->infoCriterMap->size() != 0 &&
                localInfoCriterMap.empty())
            {
                if (pos != 0)
                {
                    this->printMsg(RET_GEN_ERR_INVARG, "Untreated line '" + lineStr + "'");
                    lineIt->bTreated = true;
                    lineStr.clear();
                    continue;
                }
            }

            if (pos == 0)
            {
                pos++;
            }
            else
            {
                pos = 0;
            }
            newStr = lineStr.substr(pos);

            if (newStr[0] == '@')
            {
                std::string::size_type subPos, assignPos;

                assignPos = newStr.find("=");
                if (assignPos != std::string::npos)
                {
                    currSelectEltSt.value = newStr.substr(assignPos + 1, newStr.length());
                    if ((subPos = currSelectEltSt.value.find_first_not_of(" \t")) != std::string::npos)
                    {
                        currSelectEltSt.value = currSelectEltSt.value.substr(subPos);
                        if (this->getDictAttribOnRequest(currSelectEltSt.value, currSelectEltSt.colAlias) == nullptr || 
                            currSelectEltSt.colAlias.compare("@") == 0)
                        {
                            currSelectEltSt.colAlias.clear();
                        }
                    }

                    currSelectEltSt.varName = newStr.substr(1, assignPos - 1);
                    if ((subPos = this->find_first_of(currSelectEltSt.varName, " \t")) != std::string::npos)
                    {
                        currSelectEltSt.varName = currSelectEltSt.varName.substr(0, subPos);
                    }
                    currSelectEltSt.sqlName = std::string();
                }
                else
                {
                    currSelectEltSt.value = newStr;
                    currSelectEltSt.sqlName = std::string();
                }
            }
            else
            {
                std::string::size_type eqPos = this->find_first_of(newStr, "=");
                std::string::size_type fctPos = std::string::npos;
                std::string::size_type firstBracePos = newStr.find("(", 0);

                if (eqPos == std::string::npos)
                {
                    if ((dotPos = this->find_first_of(newStr, ".")) != std::string::npos &&
                        ((fctPos = this->find_first_of(newStr, "(")) == std::string::npos ||
                         fctPos > dotPos))
                    {
                        fctPos = std::string::npos;
                        currSelectEltSt.colAlias = newStr.substr(0, dotPos);
                        currSelectEltSt.value = newStr;

                        newStr = newStr.substr(dotPos + 1);
                    }
                    else
                    {
                        this->removeComments(newStr);
                        currSelectEltSt.value = trim(newStr);

                        DICT_ATTRIB_STP dictAttribStp = this->getDictAttribOnRequest(currSelectEltSt.value, currSelectEltSt.colAlias);

                        if (dictAttribStp == NULL || currSelectEltSt.colAlias.compare("@") == 0)
                        {
                            currSelectEltSt.colAlias.clear();
                        }

                        if (dictAttribStp != nullptr)
                        {
                            currSelectEltSt.datatype = dictAttribStp->dataTpProgN;
                        }
                    }

                    if (fctPos == std::string::npos && this->infoCriterMap != nullptr && this->infoCriterMap->size() > 0)
                    {
                        currSelectEltSt.sqlName = newStr;
                    }
                }
                else if (eqPos < firstBracePos)
                {
                    currSelectEltSt.sqlName = newStr.substr(0, eqPos);

                    std::string::size_type dataTypePos = this->find_first_of(currSelectEltSt.sqlName, "[");
                    if (dataTypePos != std::string::npos)
                    {
                        std::string::size_type endDataTypePos = this->find_first_of(currSelectEltSt.sqlName, "]", dataTypePos);
                        if (endDataTypePos == std::string::npos)
                        {
                            ret = RET_GEN_ERR_INVARG;
                            this->printMsg(RET_GEN_ERR_INVARG, "Wrong data-type definition in line '" + lineStr + "'");
                        }
                        else
                        {
                            currSelectEltSt.datatype = DBA_ConvUniDataTypeToDataType(DBA_GetDatatypeEnumByCode(currSelectEltSt.sqlName.substr(dataTypePos + 1, endDataTypePos - dataTypePos - 1).c_str()));
                            if (currSelectEltSt.datatype == NullDataType)
                            {
                                ret = RET_GEN_ERR_INVARG;
                                this->printMsg(RET_GEN_ERR_INVARG, "Wrong data-type definition in line '" + lineStr + "'");
                            }

                            currSelectEltSt.sqlName.erase(dataTypePos, endDataTypePos - dataTypePos + 1);
                        }
                    }

                    if ((dotPos = this->find_first_of(currSelectEltSt.sqlName, ".")) != std::string::npos)
                    {
                        currSelectEltSt.colAlias = currSelectEltSt.sqlName.substr(0, dotPos);
                        currSelectEltSt.sqlName  = currSelectEltSt.sqlName.substr(dotPos + 1);
                    }
                    trim(currSelectEltSt.sqlName);

                    currSelectEltSt.value = newStr.substr(eqPos + 1);
                    this->removeComments(currSelectEltSt.value);
                    trim(currSelectEltSt.value);

                    if (this->insertList.empty())
                    {
                        DICT_ATTRIB_STP dictAttribStp = DBA_GetAttributeBySqlName(currDictEntityStp->objectEn, currSelectEltSt.sqlName.c_str(), TRUE);

                        if (dictAttribStp == nullptr)
                        {
                            auto aliasPos = currSelectEltSt.value.find(".");
                            auto varPos = currSelectEltSt.value.find("@");

                            if (aliasPos != std::string::npos)
                            {
                                OBJECT_ENUM joinObjEn = NullEntity;

                                std::string          joinAlias     = currSelectEltSt.value.substr(0, aliasPos + 1);
                                std::string          joinName      = currSelectEltSt.value.substr(aliasPos + 1);
                                DICT_ENTITY_STP joinEntityStp = currDictEntityStp;

                                while (joinAlias.find("(") != std::string::npos)
                                {
                                    joinAlias.erase(0, joinAlias.find("(") + 1);
                                    trim(joinAlias);
                                }

                                auto joinEndPos = joinName.find_first_of(",)");
                                if (joinEndPos != std::string::npos)
                                {
                                    joinName.erase(joinEndPos);
                                }
                                if (this->getAlias()    == joinAlias ||
                                    this->getNewAlias() == joinAlias ||
                                    this->getOldAlias() == joinAlias)
                                {
                                    joinObjEn = currDictEntityStp->objectEn;
                                }

                                auto it = this->addedJoinTab.begin();
                                while (joinObjEn == NullEntity && it != this->addedJoinTab.end())
                                {
                                    if (it->joinSqlName == joinAlias && it->joinDictEntityStp != nullptr)
                                    {
                                        joinEntityStp = it->joinDictEntityStp;
                                        joinObjEn = it->joinDictEntityStp->objectEn;
                                    }
                                    ++it;
                                }

                                it = this->joinTab.begin();
                                while (joinObjEn == NullEntity && it != this->joinTab.end())
                                {
                                    if (it->joinSqlName == joinAlias && it->joinDictEntityStp != nullptr)
                                    {
                                        joinEntityStp = it->joinDictEntityStp;
                                        joinObjEn = it->joinDictEntityStp->objectEn;
                                    }
                                    ++it;
                                }

                                dictAttribStp = DBA_GetAttributeBySqlName(joinObjEn, joinName.c_str(), TRUE);

                                if (dictAttribStp == nullptr &&
                                    joinName == this->getOptimisticLockingSqlName(joinEntityStp))
                                {
                                    currSelectEltSt.datatype = TimeStampType;
                                }
                            }
                            else if (varPos != std::string::npos)
                            {
                                DdlGenVar* var = this->varHelperPtr->getVariable(currSelectEltSt.value, false);
                                if (var != nullptr)
                                {
                                    currSelectEltSt.datatype = var->getDataType();
                                }
                            }
                            else
                            {
                                dictAttribStp = DBA_GetAttributeBySqlName(currDictEntityStp->objectEn, currSelectEltSt.value.c_str(), TRUE);
                            }
                        }

                        if (dictAttribStp != nullptr)
                        {
                            currSelectEltSt.datatype   = dictAttribStp->dataTpProgN;
                            currSelectEltSt.bMandatory = dictAttribStp->dbMandatoryFlg;
                        }
                    }
                    else
                    {
                        for (auto it = this->insertList.begin(); it != this->insertList.end(); ++it)
                        {
                            if (DdlGen::find_word(it->value, currSelectEltSt.sqlName) == 0)
                            {
                                currSelectEltSt.datatype   = it->datatype;
                                currSelectEltSt.bMandatory = it->bMandatory;
                                break;
                            }
                        }
                    }

                    if (currSelectEltSt.datatype == NullDataType &&
                        this->getDdlObjEn() != DdlObj_Sql &&
                        this->getDdlObjEn() != DdlObj_RuntimeSql &&
                        this->getDdlObjEn() != DdlObj_SubSql &&
                        this->getDdlObjEn() != DdlObj_SubQuery)
                    {
                        ret = RET_GEN_ERR_INVARG;
                        this->printMsg(RET_GEN_ERR_INVARG, "Unknown data-type of attribute " + currSelectEltSt.sqlName + " in line '" + lineStr + "'");
                    }
                }
                else
                {
                    currSelectEltSt.value = newStr;
                }

                if (this->ddlGenContextPtr->m_rdbmsEn == PostgreSQL &&
                    currSelectEltSt.datatype != NullDataType &&
                    (strcasecmp(currSelectEltSt.value.c_str(), "null") == 0 ||
                     currSelectEltSt.value.find_first_not_of("0123456789") == std::string::npos))
                {
                    currSelectEltSt.value = this->convert(currSelectEltSt.datatype, currSelectEltSt.value, currSelectEltSt.bMandatory == FALSE);
                }
            }

            

            /* PMSTA-21110 - LJE - 150825 - Check if the attribute is allowed */
            DICT_ATTRIB_STP dictAttrStp = nullptr;
            if (currSelectEltSt.sqlName.empty() == false &&
                (dictAttrStp = DBA_GetAttributeBySqlName(this->objectEn, currSelectEltSt.sqlName.c_str(), TRUE)) != nullptr)
            {
                if (currSelectEltSt.datatype == NullDataType)
                {
                    currSelectEltSt.datatype = dictAttrStp->dataTpProgN;
                }
                else if (currSelectEltSt.datatype != dictAttrStp->dataTpProgN)
                {
                    msgList.push_back("Mismatch data-type for attribute " + std::string(this->m_dictEntityStp->mdSqlName) + "." + currSelectEltSt.sqlName + ", " + DBA_GetDataTypeSQLNameC(currSelectEltSt.datatype) + " instead of " + DBA_GetDataTypeSQLNameC(dictAttrStp->dataTpProgN));
                }

                if (this->getDdlObjEn() != DdlObj_TriggerBody &&
                    this->getDdlObjEn() != DdlObj_RuntimeSql)
                {
                    if (dictAttrStp->calcEn == DictAttr_CreationManagment || dictAttrStp->calcEn == DictAttr_LastModifManagment || dictAttrStp->calcEn == DictAttr_PhysSpecUpd)
                    {
                        if (dictAttrStp->calcEn == DictAttr_CreationManagment || dictAttrStp->calcEn == DictAttr_LastModifManagment)
                        {
                            msgList.push_back("It's not allowed to add an attribute (" + currSelectEltSt.sqlName + ") having calculation enum set to creation or last modif management, entity: " + this->m_dictEntityStp->mdSqlName);
                        }
                    }
                    else
                    {
                        bOnlySpecAttr = false;
                    }
                }
            }

            if (currSelectEltSt.value.empty())
            {
                currSelectEltSt.value = currSelectEltSt.sqlName;
            }

            std::string::size_type outputPos = this->posKey(currSelectEltSt.value, "output");
            if (outputPos != std::string::npos)
            {
                currSelectEltSt.value = currSelectEltSt.value.substr(0, this->find_first_of(currSelectEltSt.value, " \t"));
                currSelectEltSt.bOutput = true;
            }

            selectList.push_back(currSelectEltSt);
            lineIt->bTreated = true;
        }

        if (bOnlySpecAttr == false && msgList.size() != 0)
        {
            for (std::list<std::string>::iterator it = msgList.begin(); it != msgList.end(); it++)
            {
                this->printMsg(RET_GEN_ERR_INVARG, *it);
            }
            ret = RET_GEN_ERR_INVARG;
        }

        for (std::vector<OverloadLine>::iterator lineIt = overloadVector.begin(); lineIt != overloadVector.end(); lineIt++)
        {
            if (lineIt->bTreated == false)
            {
                ret = RET_GEN_ERR_INVARG;
                this->printMsg(ret, "Untreated line '" + lineIt->lineStr + "'");
            }
        }
    }

    if (selListEn != SelList_Update || this->selectList.size())
    {
        this->printSelectList(selListEn);

        if (this->getDdlObjEn() != DdlObj_View && this->bOrderBy == true && this->infoCriterMap)
        {
            FLAG_T           firstFlg = TRUE;
            this->orderStream << this->newLine() << "order by ";

            for (auto criterIt = this->infoCriterMap->begin(); criterIt != this->infoCriterMap->end(); ++criterIt)
            {
                DICT_CRITER_STP dictCriterStp = criterIt->second;

                if (dictCriterStp->sortRank > 0)
                {
                    if (dictCriterStp->sortRank == minSortRk)
                    {
                        minSortRk++;

                        if (firstFlg == FALSE)
                        {
                            this->orderStream << ", ";
                        }
                        firstFlg = FALSE;

                        this->orderStream << dictCriterStp->sqlName << DdlGenDbi::getOrderSortRule(dictCriterStp->sortRule);  /* PMSTA-30450 - LJE - 180305 */

                        criterIt = this->infoCriterMap->begin();
                    }
                    if (minSortRk > maxSortRk)
                    {
                        break;
                    }
                }
            }
            this->orderStream << std::endl;
        }

        this->bOrderBy = false;

        this->replaceTagAlias(this->selListStream);
    }
    else /* PMSTA-26250 - LJE - 170502 */
    {
        ret = RET_DBA_INFO_NODATA;
    }

    if (this->m_outputViewEn == View_Custom)
    {
        this->m_outputViewEn = outputViewEn;
    }

    /* PMSTA-27352 - LJE - 170606 */
    if (this->bManageAuthFlg && bAuthPrinted == false)
    {
        this->bManageAuthFlg = false;
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGen::printSelectList()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 140630
**
*************************************************************************/
RET_CODE DdlGen::printSelectList(SEL_LIST_ENUM selListEn)
{
    RET_CODE          ret = RET_SUCCEED;
    std::stringstream      finalStream;
    std::string            firstMandatory;

    this->initStream.clear();
    this->initStream.str(std::string());

    /* PMSTA-37366 - LJE - 200619 */
    if (this->selectList.empty() &&
        selListEn == SelList_Select &&
        (this->outputDynNatEn == DynType_All || this->outputDynNatEn == DynType_AllDb) &&
        this->m_dictEntityStp->entNatEn == EntityNat_Internal)
    {
        DdlSelectElt currSelectEltSt;
        currSelectEltSt.datatype = NullDataType;
        currSelectEltSt.bOutput = false;
        currSelectEltSt.value = "*";

        this->selectList.push_back(currSelectEltSt);
    }

    for (std::list<DdlSelectElt>::iterator it = this->selectList.begin(); it != this->selectList.end(); ++it)
    {
        if (it->datatype == NullDataType && it->sqlName.empty() == false)
        {
            DICT_ATTRIB_STP dictAttribStp = DBA_GetAttributeBySqlName(this->getObjectEn(), it->sqlName.c_str());
            if (dictAttribStp)
            {
                it->datatype = dictAttribStp->dataTpProgN;
            }
        }
    }

    std::string newLine(" ");
    if (this->getDdlObjEn() != DdlObj_RuntimeSql)
    {
        newLine = this->newLine();
    }

    for (auto it = this->selectList.begin(); it != this->selectList.end(); ++it)
    {
        if (firstMandatory.empty() && it->bMandatory)
        {
            firstMandatory = it->sqlName;
        }

        if (selListEn != SelList_Assign)
        {
            if (this->bSelectPrinted == false)
            {
                this->bSelectPrinted = true;
                if (selListEn == SelList_Update)
                {
                    if (it->sqlName.find("help") != 0) /* PMSTA-37366 - LJE - 191008 - NuoDB Work-around https://support.nuodb.com/hc/en-us/requests/10389 */
                    {
                        this->selListStream << newLine;
                    }
                }
                else if (selListEn == SelList_SelectCall ||
                         selListEn == SelList_Call ||
                         selListEn == SelList_InsertCall ||
                         selListEn == SelList_InsertFullCall)
                {
                    this->selListStream << newLine;
                }
                else if (selListEn == SelList_List ||
                         selListEn == SelList_Insert ||
                         selListEn == SelList_InsertFull)
                {
                    if (it->sqlName.find("help") != 0) /* PMSTA-37366 - LJE - 191008 - NuoDB Work-around https://support.nuodb.com/hc/en-us/requests/10389 */
                    {
                        this->selListStream << this->getIndent();
                    }
                }
                else
                {
                    if ((this->isProcedureBehavior() ||
                         (this->getDdlGenFromFileContextPtr() != nullptr && this->getDdlGenFromFileContextPtr()->m_bInBlock) ||
                         this->varHelperPtr->getVariableNbr() > 0) &&
                        this->bNestedRequest == false &&
                        selListEn != SelList_SelectInVar &&
                        selListEn != SelList_SelectCursor &&
                        selListEn != SelList_SelectDistinctCursor &&
                        selListEn != SelList_ForSelect &&
                        selListEn != SelList_ForSelectDistinct &&
                        (it->varName.empty()))
                    {
                        this->ddlGenContextPtr->m_dependsAccessSet.insert(DdlGenDependKey(this->getDictEntityStp()->entDictId,
                                                                                          this->getDictEntityStp()->mdSqlName,
                                                                                          DictDependsAccessEn::Returns,
                                                                                          this->outputDynNatEn));

                        this->selListStream << this->prepareResultSet(this->cursorStream, *this);
                    }
                    this->selListStream << this->getIndent() << "select ";

                    if (selListEn == SelList_SelectDistinct || selListEn == SelList_SelectDistinctCursor || selListEn == SelList_InsertSelectDistinct || selListEn == SelList_ForSelectDistinct)
                    {
                        this->selListStream << "distinct ";
                    }

                    /* PMSTA-18593 - LJE - 150924 - Put first comment to able Oracle hint */
                    if (this->overloadStream.str().find("/*") == 0)
                    {
                        std::string::size_type endComment = this->overloadStream.str().find("*/");
                        if (endComment != std::string::npos)
                        {
                            this->selListStream << this->overloadStream.str().substr(0, endComment + 2);
                        }
                    }

                    if (it->sqlName.find("help") != 0) /* PMSTA-37366 - LJE - 191008 - NuoDB Work-around https://support.nuodb.com/hc/en-us/requests/10389 */
                    {
                        this->selListStream << newLine;
                    }
                }
            }
            else
            {
                if (this->ddlGenContextPtr->m_rdbmsEn == PostgreSQL &&
                    selListEn == SelList_InsertFull &&
                    it->sqlName == "user")
                {
                    it->value += "_c";
                }

                if (selListEn != SelList_Call)
                {
                    this->selListStream << ",";

                    if (it->sqlName.find("help") != 0) /* PMSTA-37366 - LJE - 191008 - NuoDB Work-around https://support.nuodb.com/hc/en-us/requests/10389 */
                    {
                        this->selListStream << newLine;
                    }
                }
                else
                {
                    this->selListStream << newLine;
                }

                if (this->varListStream.str().empty() == false)
                {
                    this->varListStream << "," << newLine;
                }
            }
        }

        this->replaceTagConvert(it->value, it->datatype);

        if (selListEn == SelList_List || selListEn == SelList_Insert || selListEn == SelList_InsertFull)
        {
            if (it->value.empty())
            {
                this->selListStream << this->getAlias() << it->sqlName;
            }
            else
            {
                this->selListStream << it->value;
            }
        }
        else if (selListEn == SelList_Call)
        {
            this->selListStream << "@" << it->sqlName << " = ";

            if (it->value.empty() || it->sqlName.compare(it->value) == 0)
            {
                this->selListStream << "@" << it->sqlName;
            }
            else
            {
                this->selListStream << it->value;
            }

            if (it->bOutput)
            {
                /* PMSTA-49178 - LJE - 220909 */
                DdlGenVar* variable = this->varHelperPtr->getVariable(it->value.empty() ? it->sqlName : it->value);
                if (variable != nullptr)
                {
                    variable->setOut(true);
                }

                this->selListStream << DdlGenDbi::getCallOutput();
            }
        }
        else if (selListEn == SelList_Assign)
        {
            this->selListStream << newLine
                << this->getAlias(false) << it->sqlName << DdlGenDbi::getVarAssign() << it->value << this->endOfCmd();
        }
        else if (selListEn == SelList_SelectCall || selListEn == SelList_Update)
        {
            if (it->colAlias.empty() == false &&
                this->ddlGenContextPtr->m_rdbmsEn != PostgreSQL)
            {
                this->selListStream << it->colAlias << ".";
            }
            this->selListStream << it->sqlName << " = ";

            if (it->value.compare(it->sqlName) == 0 ||
                it->value.compare(this->getAlias() + it->sqlName) == 0)
            {
                DdlGenVar *currVar = this->varHelperPtr->getVariable(it->sqlName);
                if (currVar != NULL)
                {
                    this->selListStream << currVar->printSqlName();
                }
                else if (this->getDdlObjEn() == DdlObj_RuntimeSql)
                {
                    this->selListStream << "?";
                    this->ddlGenContextPtr->m_inputVariableVector.push_back(DbiInputParam(it->sqlName, it->datatype));
                }
            }
            else
            {
                this->selListStream << it->value;
            }
        }
        else if (selListEn == SelList_SelectInVar)
        {
            this->selListStream << this->getCmdAssignOnSelect(*this->varHelperPtr->getNewVariable(it->sqlName, it->datatype), it->value, finalStream, initStream);
        }
        else if (selListEn == SelList_SelectVar)
        {
            DdlGenVar *currVar = this->varHelperPtr->getVariable(it->value, false);

            if (currVar)
            {
                this->selListStream << DdlGenDbi::getCmdSelectList(currVar->printSqlName(), it->sqlName);
            }
            else
            {
                this->selListStream << DdlGenDbi::getCmdSelectList(this->convert(it->datatype, "null", false), it->sqlName);
            }
        }
        else if (selListEn == SelList_InsertCall || selListEn == SelList_InsertFullCall)
        {
            if (this->getDdlObjEn() == DdlObj_RuntimeSql)
            {
                this->selListStream << "?";
                this->ddlGenContextPtr->m_inputVariableVector.push_back(DbiInputParam(it->sqlName, it->datatype));
            }
            else if (it->sqlName.compare(it->value) == 0)
            {
                DdlGenVar *currVar = this->varHelperPtr->getVariable(it->value);
                if (currVar != NULL)
                {
                    this->selListStream << currVar->printSqlName();
                }
            }
            else
            {
                this->selListStream << it->value;
            }
        }
        else if (selListEn == SelList_SelectCursor || selListEn == SelList_SelectDistinctCursor)
        {
            if (it->varName.empty())
            {
                it->varName = SYS_Stringer("c", this->ddlGenContextPtr->iCursorCpt, "_", it->sqlName);
            }

            if (it->varName.empty() == false)
            {
                DdlGenVar *cursorVar = this->varHelperPtr->getNewVariable(it->varName, it->datatype);

                this->varHelperPtr->setModify(*cursorVar);
                this->varListStream << "\t" << cursorVar->printSqlName();
                this->selListStream << it->value;
            }
        }
        else if (selListEn == SelList_ForSelect || selListEn == SelList_ForSelectDistinct)
        {
            if (it->varName.empty())
            {
                it->varName = SYS_Stringer("c", this->ddlGenContextPtr->iCursorCpt, "_", it->sqlName);
            }

            if (it->varName.empty() == false)
            {
                DdlGenVar *cursorVar = this->varHelperPtr->getNewVariable(it->varName, it->datatype);

                this->varHelperPtr->setAlias(*cursorVar);
                this->selListStream << DdlGenDbi::getCmdSelectList(it->value, it->varName);
                this->varHelperPtr->setCursorName(*cursorVar);  /* PMSTA-49178 - LJE - 220909 */
            }
        }
        else if (it->varName.empty() == false && it->value.empty() == false)
        {
            this->selListStream << this->getCmdAssignOnSelect(*this->varHelperPtr->getNewVariable(it->varName, ""), it->value, finalStream, this->initStream);
        }
        else if (it->sqlName.empty() == false && it->value.empty())
        {
            this->selListStream << it->sqlName;
        }
        else if (it->sqlName.empty() && it->value.empty() == false)
        {
            this->selListStream << it->value;
        }
        else if (it->varName.empty() == false && it->value.empty())
        {
            this->selListStream << this->varHelperPtr->getNewVariable(it->varName, "")->printSqlName();
        }
        else if (this->bShadowAccess)
        {
            std::string shAlias("sh"), eAlias(this->getAlias(true));

            if (it->tblAlias.compare("ud.") == 0)
            {
                firstMandatory = "ud_id";
            }
            std::string value;
            if (it->bPrimaryKey)
            {
                value = "pk." + it->sqlName;
            }
            else if (it->bShadowAttrib)
            {
                if (it->bMandatory && it->defaultValueStr.empty() == false)
                {
                    value = DdlGenDbi::getCmdIsNull() + "(" + shAlias + "." + it->sqlName + "," + it->defaultValueStr + ")";
                }
                else
                {
                    value = "" + shAlias + "." + it->sqlName;
                }
            }
            else if (it->bMandatory)
            {
                value = DdlGenDbi::getCmdIsNull() + "(" + shAlias + "." + it->sqlName + "," + eAlias + "." + it->sqlName + ")";
            }
            else
            {
                value = "case when " + shAlias + "." + firstMandatory + " is null then " + eAlias + "." + it->sqlName + " else " + shAlias + "." + it->sqlName + " end";

                if (it->bPrintDefValIfNull)
                {
                    value = DdlGenDbi::getCmdIsNull() + "(" + value + ", " + it->defaultValueStr + ")";
                }
            }
            this->selListStream << DdlGenDbi::getCmdSelectList(value, it->sqlName);
        }
        else if (this->mulitEntityAccessEn == MultiEntityAccess_PartialSpecialization &&
                 it->attribStp != nullptr &&
                 it->attribStp->meSpecialisationEn == MeSpecialisation_Applied)
        {
            std::string beAlias(this->getAlias(true) + "_be"), eAlias(this->getAlias(true));

            if (it->tblAlias.compare("ud.") == 0)
            {
                eAlias = "ud";
            }
            std::string value;
            if (it->bMandatory)
            {
                value = DdlGenDbi::getCmdIsNull() + "(" + beAlias + "." + it->sqlName + "," + eAlias + "." + it->sqlName + ")";
            }
            else
            {
                value = "case when " + beAlias + "." + firstMandatory + " is null then " + eAlias + "." + it->sqlName + " else " + beAlias + "." + it->sqlName + " end";
            }
            this->selListStream << DdlGenDbi::getCmdSelectList(value, it->sqlName);
        }
        else if (this->m_outputViewEn != View_None &&
                 this->ddlGenContextPtr->m_rdbmsEn == PostgreSQL &&
                 (it->tblAlias + it->sqlName) == it->value)
        {
            this->selListStream << it->value;
        }
        else
        {
            this->selListStream << DdlGenDbi::getCmdSelectList(it->value, it->sqlName);
        }
    }

    this->selListStream << finalStream.str();
    return ret;
}

/************************************************************************
**
**  Function    :   DdlGen::getCmdCurUsrDataProfile()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 150728
**
*************************************************************************/
std::string DdlGen::getCmdCurUsrDataProfile()
{
    if (this->ddlGenContextPtr->m_rdbmsEn == Oracle)
    {
        return "(select curr_usr.data_profile_id from " + this->getEntityFullSqlName("appl_user") + " curr_usr where curr_usr.id = " + this->getCmdUserId() + ")";
    }
    else
    {
        this->printUserJoin();
        return "curr_usr.data_profile_id";
    }
}

/************************************************************************
**
**  Function    :   DdlGen::getDataProfile()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14607 - LJE - 120712
**
*************************************************************************/
std::string DdlGen::getDataProfile()
{
    if (this->isProcedureBehavior())
    {
        DdlGenVar *dataProfVarPtr = this->varHelperPtr->getNewVariable("data_profile_id", "id_t");

        if (dataProfVarPtr->m_bModify == false && dataProfVarPtr->strDefault.empty() == false)
        {
            this->varHelperPtr->setModify(*dataProfVarPtr);
        }

        return dataProfVarPtr->printSqlName();
    }
    else
    {
        return "coalesce( " + DdlGenDbi::getCmdDataProfileId() + ", " + this->getCmdCurUsrDataProfile() + ")";
    }
}

/************************************************************************
**
**  Function    :   DdlGen::getDataProfileUser()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14607 - LJE - 120712
**
*************************************************************************/
std::string DdlGen::getDataProfileUser()
{
    if (this->isProcedureBehavior())
    {
        return this->varHelperPtr->getNewVariable("data_profile_id_user", "id_t")->printSqlName();
    }
    else
    {
        return this->getCmdCurUsrDataProfile();
    }
}

/************************************************************************
**
**  Function    :   DdlGen::getCodif()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 141006
**
*************************************************************************/
std::string DdlGen::getCodif()
{
    if (this->isProcedureBehavior())
    {
        return this->varHelperPtr->getNewVariable("codif_id", "id_t")->printSqlName();
    }
    else
    {
        return "codif_id";
    }
}

/************************************************************************
**
**  Function    :   DdlGen::getLanguage()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 141006
**
*************************************************************************/
std::string DdlGen::getLanguage()
{
    if (this->isProcedureBehavior())
    {
        return this->varHelperPtr->getNewVariable("language_dict_id", "dict_t")->printSqlName();
    }
    else
    {
        return "language_dict_id";
    }
}

/************************************************************************
**
**  Function    :   DdlGen::printUserJoin()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14607 - LJE - 120712
**
*************************************************************************/
void DdlGen::printUserJoin()
{
    if (this->isProcedureBehavior() == false)
    {
        if (this->bUserJoinPrint == false && this->ddlGenContextPtr->bSecurityDone == false) /* PMSTA-43626 - LJE - 210311 */
        {
            this->bUserJoinPrint = true;

            this->addFromStream << " " << this->getCmdInnerJoin() << this->getEntityFullSqlName("appl_user") << " curr_usr on ((curr_usr.id = " << this->getCmdUserId() << "))";

            if (this->ddlGenContextPtr->m_rdbmsEn == PostgreSQL)
            {
                this->addFromStream << ")";
            }
        }
    }
}

/************************************************************************
**
**  Function    :   DdlGen::getCmdUserId()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 141027
**
*************************************************************************/
std::string DdlGen::getCmdUserId(bool bVariable)
{
    if (this->isProcedureBehavior() == false || bVariable == false)
    {
        return this->getCmdApplUserId();
    }
    else
    {
        std::string tmpStr;
        return DdlGen::getReplaceUserId(tmpStr, 0, this->ddlGenContextPtr, this->varHelperPtr, this);
    }
}

/************************************************************************
**
**  Function    :   DdlGen::getConnBusinessEntityId()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26108 - LJE - 170818
**
*************************************************************************/
std::string DdlGen::getConnBusinessEntityId()
{
    if (this->isProcedureBehavior())
    {
        return this->varHelperPtr->getNewVariable("connected_business_entity_id", "id_t")->printSqlName();
    }
    else
    {
        return this->getCmdConnBusinessEntityId();
    }
}

/************************************************************************
**
**  Function    :   DdlGen::replaceTagAlias()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 141027
**
*************************************************************************/
void DdlGen::replaceTagAlias(std::stringstream &inOutStream)
{
    std::string::size_type aliasPos;
    std::string            strToTreat = inOutStream.str();

    while ((aliasPos = strToTreat.find("#ALIAS.")) != std::string::npos)
    {
        strToTreat.replace(aliasPos, strlen("#ALIAS."), this->getAlias());
    }

    inOutStream.clear();
    inOutStream.str(std::string());
    inOutStream << strToTreat;
}

/************************************************************************
**
**  Function    :   DdlGen::getApplOwner()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 151014
**
*************************************************************************/
std::string DdlGen::getApplOwner(std::string&, std::string::size_type, DdlGenContext* currDdlGenContextPtr, DdlGenVarHelper*, DdlGen*)
{
    return currDdlGenContextPtr->getCfgFileHelper().getProperty("APPL_OWNER");
}

/************************************************************************
**
**  Function    :   DdlGen::getReplaceUserId()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 151014
**
*************************************************************************/
std::string DdlGen::getReplaceUserId(std::string &, std::string::size_type, DdlGenContext *currDdlGenContextPtr, DdlGenVarHelper *varHelperPtr, DdlGen *)
{
    varHelperPtr->getNewVariable("user_id", IdType);
    currDdlGenContextPtr->bUserId = true;
    return "@user_id";
}

/************************************************************************
**
**  Function    :   DdlGen::getReplaceLanguageDictId()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-29879 - LJE - 180710
**
*************************************************************************/
std::string DdlGen::getReplaceLanguageDictId(std::string &, std::string::size_type, DdlGenContext *currDdlGenContextPtr, DdlGenVarHelper *varHelperPtr, DdlGen *)
{
    varHelperPtr->getNewVariable("language_dict_id", IdType);
    currDdlGenContextPtr->bLanguage = true;
    return "@language_dict_id";
}

/************************************************************************
**
**  Function    :   DdlGen::getJsonGetId()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45027 - LJE - 210521
**
*************************************************************************/
std::string DdlGen::getJsonGetId(DdlGenContext *ddlGenContextPtr, DdlGenVarHelper *varHelperPtr, std::vector<std::vector<std::string>>&keywordParamList)
{
    if (keywordParamList.empty() == false &&
        keywordParamList[0].empty() == false)
    {
        std::stringstream jsonUkStream;

        std::string::size_type pos = 0;
        if ((pos = keywordParamList[0][0].find_first_not_of("'\" \t")) != 0)
        {
            keywordParamList[0][0].erase(0, pos);

            pos = keywordParamList[0][0].size();
            while (keywordParamList[0][0][--pos] == '\'' ||
                   keywordParamList[0][0][pos] == '"' ||
                   keywordParamList[0][0][pos] == ' ' ||
                   keywordParamList[0][0][pos] == '\t')
            {
                keywordParamList[0][0].erase(pos, 1);
            }
        }

        if (keywordParamList[0][0][0] == '@' ||
            keywordParamList[0][0].find(DdlGenDbi::getVarPrefix(ddlGenContextPtr->m_rdbmsEn)) == 0)
        {
            if (keywordParamList[0][0][0] == '@')
            {
                keywordParamList[0][0].erase(0, 1);
            }
            else
            {
                keywordParamList[0][0].erase(0, DdlGenDbi::getVarPrefix(ddlGenContextPtr->m_rdbmsEn).size());
            }

            DdlGenVar *jsonVar = varHelperPtr->getVariable(keywordParamList[0][0]);

            if (jsonVar != nullptr)
            {
                keywordParamList[0][0] = jsonVar->getValue();
            }
        }

        if (keywordParamList.size() > 1)
        {
            while ((pos = keywordParamList[1][0].find_first_of("'\" \t")) != std::string::npos)
            {
                keywordParamList[1][0].erase(pos, 1);
            }

            jsonUkStream << "[ { \"" << keywordParamList[1][0] << "\" : [ " << keywordParamList[0][0] << " ] } ] ";
        }
        else if (keywordParamList.empty() == false)
        {
            jsonUkStream << keywordParamList[0][0];
        }

        if (jsonUkStream.str().empty() == false)
        {
            DdlGenConnGuard     ddlGenConnGuard(*ddlGenContextPtr);
            MemoryPool mp;
            std::vector<DBA_DYNFLD_STP>  outputDynStpVector;
            BuildBindOption              buildBindOption;

            if (DBA_GetDynStpFromJSonString(jsonUkStream.str(),
                                            outputDynStpVector,
                                            buildBindOption,
                                            mp,
                                            ddlGenConnGuard.getDbiConn(),
                                            true) == RET_SUCCEED &&
                outputDynStpVector.empty() == false &&
                outputDynStpVector[0] != nullptr)
            {
                DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(GET_OBJ_DYNST(GET_DYNSTENUM(outputDynStpVector[0])));
                if (dictEntityStp != nullptr &&
                    dictEntityStp->primKeyTab != nullptr &&
                    (dictEntityStp->primKeyTab[0]->dataTpProgN == IdType ||
                     dictEntityStp->primKeyTab[0]->dataTpProgN == DictType) &&
                    IS_NULLFLD(outputDynStpVector[0], dictEntityStp->primKeyTab[0]->progN) == false)
                {
                    return SYS_Stringer(GET_ID(outputDynStpVector[0], dictEntityStp->primKeyTab[0]->progN));
                }
            }
        }
    }
    return "null";
}


/************************************************************************
**
**  Function    :   DdlGen::getJsonGetKey()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45027 - LJE - 210521
**
*************************************************************************/
std::string DdlGen::getJsonGetKey(DdlGenContext *ddlGenContextPtr, DdlGenVarHelper *varHelperPtr, std::vector<std::vector<std::string>>&keywordParamList)
{
    if (keywordParamList.size() == 2)
    {
        keywordParamList[0][0] = trim(keywordParamList[0][0]);
        keywordParamList[1][0] = trim(keywordParamList[1][0]);

        if (keywordParamList[0][0][0] == '@' ||
            keywordParamList[0][0].find(DdlGenDbi::getVarPrefix(ddlGenContextPtr->m_rdbmsEn)) == 0)
        {
            if (keywordParamList[0][0][0] == '@')
            {
                keywordParamList[0][0].erase(0, 1);
            }
            else
            {
                keywordParamList[0][0].erase(0, DdlGenDbi::getVarPrefix(ddlGenContextPtr->m_rdbmsEn).size());
            }

            DdlGenVar *jsonVar = varHelperPtr->getVariable(keywordParamList[0][0]);

            if (jsonVar != nullptr)
            {
                keywordParamList[0][0] = jsonVar->getValue();
            }
        }

        DICT_ENTITY_STP dictEntityStp = nullptr;

        if (keywordParamList[1][0][0] == '@' ||
            keywordParamList[1][0].find(DdlGenDbi::getVarPrefix(ddlGenContextPtr->m_rdbmsEn)) == 0)
        {
            if (keywordParamList[1][0][0] == '@')
            {
                keywordParamList[1][0].erase(0, 1);
            }
            else
            {
                keywordParamList[1][0].erase(0, DdlGenDbi::getVarPrefix(ddlGenContextPtr->m_rdbmsEn).size());
            }

            DdlGenVar *jsonVar = varHelperPtr->getVariable(keywordParamList[1][0]);

            if (jsonVar != nullptr)
            {
                keywordParamList[1][0] = jsonVar->getValue();
            }
        }
        else if (keywordParamList[1][0][0] == '\'')
        {
            dictEntityStp = DBA_GetEntityBySqlName(keywordParamList[1][0].substr(1, keywordParamList[1].size() - 2));
        }

        if (dictEntityStp == nullptr)
        {
            dictEntityStp = DBA_GetDictEntityByDictId(atol(keywordParamList[1][0].c_str()));
        }

        if (dictEntityStp != nullptr && dictEntityStp->isId())
        {
            MemoryPool mp;
            DdlGenConnGuard     ddlGenConnGuard(*ddlGenContextPtr);

            std::vector<DBA_DYNFLD_STP>  inputDynStpVector;
            std::string                  outputString;
            DBA_DYNFLD_STP               inputRecordStp = nullptr;
            DbiConnectionHelper          dbiConnHelper(&ddlGenConnGuard.getDbiConn());
            BuildBindOption              buildBindOption(BuildBindOption::Categ::BusinessKeyOnlyShort);

            if (DBA_GetRecordById(dictEntityStp->objectEn,
                                  atoll(keywordParamList[0][0].c_str()),
                                  GET_EDITGUIST(dictEntityStp->objectEn),
                                  &inputRecordStp,
                                  mp,
                                  &dbiConnHelper) == RET_SUCCEED)
            {
                inputDynStpVector.push_back(inputRecordStp);

                if (DBA_GetJSonStringFromDynStp(inputDynStpVector,
                                                outputString,
                                                buildBindOption,
                                                ddlGenConnGuard.getDbiConn()) == RET_SUCCEED)
                {
                    return "'" + outputString + "'";
                }
            }
        }
    }

    return "null";
}

/************************************************************************
**
**  Function    :   DdlGen::manageValueTag()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 151014
**
*************************************************************************/
std::string DdlGen::manageValueTag(DdlGenContext*, DdlGenVarHelper* currDdlGenVarHelperPtr, std::vector<std::vector<std::string>>& keywordParamList)
{
    if (keywordParamList.size() == 1)
    {
        auto currVarPtr = currDdlGenVarHelperPtr->getVariable(keywordParamList[0][0]);
        if (currVarPtr != nullptr)
        {
            return currVarPtr->getValue();
        }
    }

    return std::string();
}

/************************************************************************
**
**  Function    :   DdlGen::manageLastReturnStatusTag()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-55251 - LJE - 240306
**
*************************************************************************/
std::string DdlGen::manageLastReturnStatusTag(std::string&, std::string::size_type, DdlGenContext* ddlGenContextPtr, DdlGenVarHelper*, DdlGen*)
{
    return SYS_Stringer(ddlGenContextPtr->lastErrRetCode);
}

/************************************************************************
**
**  Function    :   DdlGen::getCollate()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-58084 - LJE - 240729
**
*************************************************************************/
std::string DdlGen::getCollate(std::string&, std::string::size_type, DdlGenContext* ddlGenContextPtr, DdlGenVarHelper*, DdlGen*)
{
    if (ddlGenContextPtr->m_rdbmsEn == MSSql)
    {
        return "COLLATE DATABASE_DEFAULT";
    }

    return std::string();
}

/************************************************************************
**
**  Function    :   DdlGen::getReplaceApplSessionCd()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 151014
**
*************************************************************************/
std::string DdlGen::getReplaceApplSessionCd(std::string &, std::string::size_type, DdlGenContext *, DdlGenVarHelper *varHelperPtr, DdlGen *)
{
    varHelperPtr->getNewVariable("session_cd", CodeType);
    return "@session_cd";
}

/************************************************************************
**
**  Function    :   DdlGen::getMasterBusinessEntityId()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**  Creation  	:   PMSTA-26108 - LJE - 171004
**
*************************************************************************/
std::string DdlGen::getMasterBusinessEntityId(std::string &, std::string::size_type, DdlGenContext *currDdlGenContextPtr, DdlGenVarHelper *, DdlGen *)
{
    return currDdlGenContextPtr->getMasterBusinessEntityId();
}

/************************************************************************
**
**  Function    :   DdlGen::getMasterBusinessEntityCd()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26108 - LJE - 171004
**
*************************************************************************/
std::string DdlGen::getMasterBusinessEntityCd(std::string &, std::string::size_type, DdlGenContext *currDdlGenContextPtr, DdlGenVarHelper *, DdlGen *)
{
    return currDdlGenContextPtr->getMasterBusinessEntityCd();
}

/************************************************************************
**
**  Function    :   DdlGen::getConnBusinessEntityId()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26108 - LJE - 171004
**
*************************************************************************/
std::string DdlGen::getConnBusinessEntityId(std::string &, std::string::size_type, DdlGenContext *, DdlGenVarHelper *, DdlGen *ddlGen)
{
    return ddlGen->getConnBusinessEntityId();
}

/************************************************************************
**
**  Function    :   DdlGen::getDboCmd()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-34402 - LJE - 190125
**
*************************************************************************/
std::string DdlGen::getDboCmd(std::string &lineToTreat, std::string::size_type replacePos, DdlGenContext *currDdlGenContextPtr, DdlGenVarHelper *, DdlGen *ddlGen)
{
    std::string::size_type startPos = DdlGen::find_first_of(lineToTreat, ".", replacePos);

    if (startPos != std::string::npos)
    {
        startPos++;
        std::string funcName = lineToTreat.substr(startPos, DdlGen::find_first_of(lineToTreat, " \t(", startPos) - startPos);

        currDdlGenContextPtr->m_dependsSprocSet.insert(DdlGenDependKey(0, funcName, DictDependsAccessEn::Call, DynType_Null));

        lineToTreat.erase(startPos - 1, 1);

        if (currDdlGenContextPtr->m_rdbmsEn == PostgreSQL &&
            lineToTreat.find("(", startPos) == std::string::npos)
        {
            lineToTreat.replace(startPos + funcName.length() - 1, 0, "()");
        }
    }

    return ddlGen->getDbo();
}

/************************************************************************
**
**  Function    :   DdlGen::manageUniqueTag()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
std::string DdlGen::manageUniqueTag(DdlGenContext *, DdlGenVarHelper *, std::vector<std::vector<std::string>>&keywordParamList)
{
    if (keywordParamList.size() > 0)
    {
        DICT_ENTITY_STP      dictEntityStp = DBA_GetEntityBySqlName(trim(keywordParamList[0][0]));

        if (dictEntityStp != nullptr)
        {
            std::string uniqueKeyStr;
            std::string aliasStr;

            if (keywordParamList.size() > 1)
            {
                aliasStr = trim(keywordParamList[1][0]) + ".";
            }

            int              keyNbr = 0;
            DICT_ATTRIB_STP *keyTab = NULL;

            if (dictEntityStp->dbPKNbr)
            {
                keyNbr = dictEntityStp->dbPKNbr;
                keyTab = dictEntityStp->dbPKTab;
            }
            else if (dictEntityStp->bkAttrNbr)
            {
                keyNbr = dictEntityStp->bkAttrNbr;
                keyTab = dictEntityStp->bkAttr;
            }

            for (int i = 0; i < keyNbr; i++)
            {
                if (i > 0)
                {
                    uniqueKeyStr += ", ";
                }
                uniqueKeyStr += aliasStr + keyTab[i]->sqlName;
            }

            return uniqueKeyStr;
        }
    }

    return std::string();
}

/************************************************************************
**
**  Function    :   DdlGen::printSecurityOnFrom()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14270 - LJE - 120531
**
*************************************************************************/
RET_CODE DdlGen::printSecurityOnFrom(ENTITY_SECURITY_LEVEL_ENUM paramSecuLevelEn,
                                     bool                       bMainEntity,
                                     bool                       bMandatoryJoin,
                                     const std::string              &entityAlias,
                                     const std::string              &joinAlias,
                                     std::stringstream         &fromStream,
                                     int                       &joinCpt,
                                     std::stringstream         &closeFromStream)
{
    RET_CODE    ret         = RET_GEN_INFO_NOACTION;
    bool        bSaveOnJoin = this->bOnJoin;

    if (bMainEntity &&
        this->getDictEntityStp()->changeSetAuthEn == FeatureAuth_Enable &&
        this->bManageAuthFlg &&
        this->getDictEntityStp()->pkEntityStp)
    {
        fromStream
            << this->newLine() << this->getCmdInnerJoin() 
            << this->getEntityFullSqlName(this->getDictEntityStp()->pkEntityStp) << " pk on ((" 
            << this->getPkAccessWhere(this->getDictEntityStp()->pkEntityStp, nullptr, "pk", entityAlias, false) << "))";

        if (this->ddlGenContextPtr->m_rdbmsEn == PostgreSQL)
        {
            this->m_joinCpt++;
            fromStream << ")";
        }
    }

    if (this->isSecuredLevel(paramSecuLevelEn) == false ||
        this->ddlGenContextPtr->bAvoidSecured == true)
        return ret;

    if (this->bUserSecured)
    {
        bool bInnerJoin = true;
        this->setOnJoin(true);

        if (this->secuMandatoryFlg == TRUE)
        {
            fromStream
                << this->newLine() << this->getCmdInnerJoin();

            if (this->ddlGenContextPtr->m_rdbmsEn == PostgreSQL)
            {
                this->m_joinCpt++;
                fromStream << ")";
            }
        }
        else
        {
            bInnerJoin = false;
            fromStream
                << this->newLine() << this->getCmdLeftJoin();
        }

        /* Data profile access */
        if (this->isProcedureBehavior() == false)
        {
            fromStream
                << "" << this->getEntityFullSqlName("data_prof_compo") << " " << joinAlias << "up ";
            if (bInnerJoin)
            {
                fromStream
                    << " on ((" << entityAlias << ".data_secu_prof_id = " << joinAlias << "up.data_secu_prof_id)) ";
            }
            fromStream
                << this->getCmdInnerJoin() << this->getEntityFullSqlName("appl_user") << joinAlias << "ap on ((" << joinAlias << "ap.id = " << this->getCmdUserId() << " and " << joinAlias << "ap.data_profile_id = " << joinAlias << "up.data_profile_id))";
            if (bInnerJoin == false)
            {
                fromStream
                    << " on ((" << entityAlias << ".data_secu_prof_id = " << joinAlias << "up.data_secu_prof_id))";
            }
        }
        else
        {
            fromStream
                << " " << this->getEntityFullSqlName("data_prof_compo") << " " << joinAlias << "up "
                << "on ((" << this->getCmdCurUsrDataProfile() << " = " << joinAlias << "up.data_profile_id and "
                << entityAlias << ".data_secu_prof_id = " << joinAlias << "up.data_secu_prof_id)) ";
        }

        ret = RET_SUCCEED;
        this->setOnJoin(bSaveOnJoin);
    }
    else if (paramSecuLevelEn == EntSecuLevel_Secured &&
             this->bForceDPInAppContext == false &&
             (this->secuMandatoryFlg == FALSE || this->ddlGenContextPtr->isEnableMultiTascLogin() == false || this->bManageAuthFlg))
    {
        bool bInnerJoin = true;
        this->setOnJoin(true);

        if (this->secuMandatoryFlg == TRUE)
        {
            fromStream
                << this->newLine() << this->getCmdInnerJoin();
        }
        else
        {
            bInnerJoin = false;
            fromStream
                << this->newLine() << this->getCmdLeftJoin();
        }

        if (this->ddlGenContextPtr->isEnableMultiTascLogin() == false && this->bForceDPInSuserName == false && this->isProcedureBehavior() == false)
        {
            fromStream
                << this->getEntityFullSqlName("data_prof_compo") << " " << joinAlias << "up ";
            if (bInnerJoin)
            {
                fromStream
                    << " on ((" << entityAlias << ".data_secu_prof_id = " << joinAlias << "up.data_secu_prof_id)) ";

                if (this->ddlGenContextPtr->m_rdbmsEn == PostgreSQL)
                {
                    if (bMandatoryJoin)
                    {
                        this->m_joinCpt++;
                    }
                    else
                    {
                        joinCpt++;
                    }
                    closeFromStream << ")";
                }
            }
            fromStream
                << this->getCmdInnerJoin() << " (select coalesce (" << DdlGenDbi::getCmdDataProfileId() << ", "
                << "(select curr_usr.data_profile_id from " << this->getEntityFullSqlName("appl_user") << " curr_usr"
                << " where (curr_usr.id = " << this->getCmdUserId() << "))) as data_profile_id " << DdlGenDbi::getEmptyFrom() << ") " << joinAlias << "ap on ((" << joinAlias << "ap.data_profile_id = " << joinAlias << "up.data_profile_id))";

            if (bInnerJoin == false)
            {
                fromStream
                    << " on ((" << entityAlias << ".data_secu_prof_id = " << joinAlias << "up.data_secu_prof_id))";

                if (this->ddlGenContextPtr->m_rdbmsEn == PostgreSQL)
                {
                    this->m_joinCpt++;
                    fromStream << ")";
                }
            }

            if (this->ddlGenContextPtr->m_rdbmsEn == PostgreSQL)
            {
                if (bMandatoryJoin)
                {
                    this->m_joinCpt++;
                }
                else
                {
                    joinCpt++;
                }
                closeFromStream << ")";
            }
        }
        else if (this->ddlGenContextPtr->isEnableMultiTascLogin() == false)
        {
            fromStream
                << this->getEntityFullSqlName("data_prof_compo") << " " << joinAlias << "up on ((" << joinAlias << "up.data_profile_id = " << this->getDataProfile()
                << ") and (" << entityAlias << ".data_secu_prof_id  = " << joinAlias << "up.data_secu_prof_id))";
        }
        else if (this->bForceDPInSuserName == false)
        {
            fromStream
                << this->newLine() << "(select dpc1.data_secu_prof_id, dpc1.auth_update_f, dpc1.auth_delete_f"
                << this->newLine() << "  from " << this->getEntityFullSqlName("data_prof_compo") << " dpc1 inner join " << this->getEntityFullSqlName("data_prof_compo") << " dpc2 on ((dpc1.data_secu_prof_id = dpc2.data_secu_prof_id))"
                << this->newLine() << " where (";
            if (this->isProcedureBehavior())
            {
                fromStream << "(" << this->getDataProfile() << " <> " << this->getDataProfileUser()
                    << this->newLine() << ") and (dpc1.data_profile_id = " << this->getDataProfile() << ")";
            }
            else
            {
                fromStream << "(" << DdlGenDbi::getCmdDataProfileId(false) << " is not null)"
                    << this->newLine() << "   and (dpc1.data_profile_id = "
                    << DdlGenDbi::getCmdDataProfileId() << ")";
            }
            fromStream << this->newLine() << "   and (dpc2.data_profile_id = ";

            if (this->isProcedureBehavior())
            {
                fromStream << this->getDataProfileUser();
            }
            else
            {
                fromStream << "(select curr_usr.data_profile_id from " << this->getEntityFullSqlName("appl_user") << " curr_usr where (curr_usr.id = " << this->getCmdUserId() << "))";
            }
            fromStream << "))";

            fromStream
                << this->newLine() << " union "
                << this->newLine() << " select dpc1.data_secu_prof_id, dpc1.auth_update_f, dpc1.auth_delete_f"
                << this->newLine() << "  from " << this->getEntityFullSqlName("data_prof_compo") << " dpc1"
                << this->newLine() << " where ((";

            if (this->isProcedureBehavior())
            {
                fromStream << this->getDataProfile() << " = " << this->getDataProfileUser();
            }
            else
            {
                fromStream << DdlGenDbi::getCmdDataProfileId(false) << " is null";
            }
            fromStream << ")";

            fromStream << this->newLine() << "   and (dpc1.data_profile_id = ";

            if (this->isProcedureBehavior())
            {
                fromStream << this->getDataProfile();
            }
            else
            {
                fromStream << "(select curr_usr.data_profile_id from " << this->getEntityFullSqlName("appl_user") << " curr_usr where curr_usr.id = " << this->getCmdUserId() << ")";
            }
            fromStream << "))) " << joinAlias << "up on " << entityAlias << ".data_secu_prof_id  = " << joinAlias << "up.data_secu_prof_id";
        }
        else
        {
            fromStream
                << this->getEntityFullSqlName("data_prof_compo") << " "
                << joinAlias << "up on ((" << joinAlias << "up.data_profile_id = " << this->getCmdCurUsrDataProfile() << ") and ("
                << entityAlias << ".data_secu_prof_id  = " << joinAlias << "up.data_secu_prof_id))";
        }

        if (bMainEntity == false && this->ddlGenContextPtr->m_rdbmsEn == Nuodb)
        {
            std::string fromStr(fromStream.str());
            fromStream.str(std::string());
            fromStream.clear();

            fromStream
                << this->newLine() << "(select " << entityAlias << ".*, " << joinAlias << "up.auth_update_f, " << joinAlias << "up.auth_delete_f from "
                << fromStr
                << ") " << entityAlias;

            this->setOnJoin(true);
        }
        else
        {
            this->m_bWherePrinted = true;
        }

        ret = RET_SUCCEED;
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGen::printSecurityOnWhere()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14270 - LJE - 120531
**
*************************************************************************/
RET_CODE DdlGen::printSecurityOnWhere(ENTITY_SECURITY_LEVEL_ENUM paramSecuLevelEn,
                                      bool                       bSecurityToDo,     /* PMSTA-26108 - LJE - 170816 */
                                      const std::string         &entityAlias,
                                      std::stringstream&         outputStream)
{
    RET_CODE          ret = RET_SUCCEED;
    std::stringstream      locStream;

    if (this->isSecuredLevel(paramSecuLevelEn) == false ||
        bSecurityToDo == false ||
        this->ddlGenContextPtr->bAvoidSecured == true)
    {
        return RET_GEN_INFO_NOACTION;
    }

    if (this->bUserSecured)
    {
        if (this->secuMandatoryFlg == FALSE)
        {
            outputStream << this->getWhereOrAnd();

            outputStream << entityAlias << "data_secu_prof_id is null) or (up.data_secu_prof_id is not null))";
            return ret;
        }
        else
        {
            return RET_GEN_INFO_NOACTION;
        }
    }

    if (this->secuMandatoryFlg == FALSE)
    {
        locStream << "((" << entityAlias << "data_secu_prof_id is null) or ";
    }

    if (this->bForceDPInAppContext && this->ddlGenContextPtr->isEnableMultiTascLogin() == false)
    {
        ret = RET_DBA_INFO_EXIST;
        locStream
            << "(exists ( select 1 from " << this->getEntityFullSqlName("data_prof_compo") << " dpc1" << this->newLine();

        if (this->isProcedureBehavior() == false)
        {
            locStream
                << "       where ((dpc1.data_profile_id = " << DdlGenDbi::getCmdDataProfileId() << ")" << this->newLine();
        }
        else
        {
            locStream
                << "       where ((dpc1.data_profile_id = " << this->getDataProfile() << ")" << this->newLine();
        }

        if (this->isSecuredWithAddDSP(paramSecuLevelEn))
        {
            locStream << this->getSecuOnBothDSP(entityAlias);
        }
        else
        {
            locStream
                << "         and (" << entityAlias << "data_secu_prof_id  = dpc1.data_secu_prof_id)";
        }
        locStream << "))))";
    }
    else if (this->bForceDPInAppContext)    /* OCS-41131 - LJE - 120723 */
    {
        ret = RET_DBA_INFO_EXIST;
        locStream
            << "(exists ( select 1 from " << this->getEntityFullSqlName("data_prof_compo") << " dpc1, " << this->getEntityFullSqlName("data_prof_compo") << " dpc2" << this->newLine();

        if (this->isProcedureBehavior() == false)
        {
            locStream
                << "       where ((dpc1.data_profile_id = " << DdlGenDbi::getCmdDataProfileId() << ")" << this->newLine()
                << "         and (dpc2.data_profile_id = " << this->getCmdCurUsrDataProfile() << ")" << this->newLine();
        }
        else
        {
            locStream
                << "       where ((dpc1.data_profile_id = " << this->getDataProfile() << ")" << this->newLine()
                << "         and (dpc2.data_profile_id = " << this->getDataProfileUser() << ")" << this->newLine();
        }

        locStream
            << "         and (dpc1.data_secu_prof_id = dpc2.data_secu_prof_id)" << this->newLine();

        if (this->isSecuredWithAddDSP(paramSecuLevelEn))
        {
            locStream << this->getSecuOnBothDSP(entityAlias);
        }
        else
        {
            locStream
                << "         and (" << entityAlias << "data_secu_prof_id  = dpc1.data_secu_prof_id)";
        }
        locStream << "))))";
    }
    else if (this->bForceDPInSuserName)    /* PMSTA-14607 - LJE - 120829 */
    {
        ret = RET_DBA_INFO_EXIST;
        locStream
            << "(exists ( select 1 from " << this->getEntityFullSqlName("data_prof_compo") << " dpc1" << this->newLine();

        if (this->isProcedureBehavior() == false)
        {
            locStream
                << "       where ((dpc1.data_profile_id = " << this->getCmdCurUsrDataProfile() << ")" << this->newLine();
        }
        else
        {
            locStream
                << "       where ((dpc1.data_profile_id = " << this->getDataProfileUser() << ")" << this->newLine();
        }

        locStream << this->getSecuOnBothDSP(entityAlias);
        locStream << "))))";
    }
    else
    {
        if (this->ddlGenContextPtr->isEnableMultiTascLogin()) /* PMSTA-14452 - LJE - 130626 */
        {
            if (this->isProcedureBehavior() == false)
            {
                locStream
                    << "((" << DdlGenDbi::getCmdDataProfileId(false) << " is null) and " << this->newLine();
            }
            else
            {
                locStream
                    << "((" << this->getDataProfile() << " = " << this->getDataProfileUser() << ") and " << this->newLine();
            }

            ret = RET_DBA_INFO_EXIST;
            locStream
                << "    exists ( select 1 from " << this->getEntityFullSqlName("data_prof_compo") << " dpc1" << this->newLine();

            if (this->isProcedureBehavior() == false)
            {
                locStream
                    << "       where ((dpc1.data_profile_id = " << this->getCmdCurUsrDataProfile() << ")" << this->newLine();
            }
            else
            {
                locStream
                    << "       where ((dpc1.data_profile_id = " << this->getDataProfileUser() << ")" << this->newLine();
            }

            if (this->isSecuredWithAddDSP(paramSecuLevelEn))
            {
                locStream << this->getSecuOnBothDSP(entityAlias);
            }
            else
            {
                locStream
                    << "         and (" << entityAlias << "data_secu_prof_id  = dpc1.data_secu_prof_id)";
            }

            locStream
                << ")))" << this->newLine()
                << "     or" << this->newLine();

            if (this->isProcedureBehavior() == false)
            {
                locStream
                    << "((" << DdlGenDbi::getCmdDataProfileId(false) << " is not null) and " << this->newLine();
            }
            else
            {
                locStream
                    << "((" << this->getDataProfile() << " <> " << this->getDataProfileUser() << ") and " << this->newLine();
            }

            ret = RET_DBA_INFO_EXIST;
            locStream
                << "     exists ( select 1 from " << this->getEntityFullSqlName("data_prof_compo") << " dpc1, " << this->getEntityFullSqlName("data_prof_compo") << " dpc2" << this->newLine();

            if (this->isProcedureBehavior() == false)
            {
                locStream
                    << "       where ((dpc1.data_profile_id = " << DdlGenDbi::getCmdDataProfileId() << ")" << this->newLine()
                    << "         and (dpc2.data_profile_id = " << this->getCmdCurUsrDataProfile() << ")" << this->newLine();
            }
            else
            {
                locStream
                    << "       where ((dpc1.data_profile_id = " << this->getDataProfile() << ")" << this->newLine()
                    << "         and (dpc2.data_profile_id = " << this->getDataProfileUser() << ")" << this->newLine();
            }

            locStream
                << "         and (dpc1.data_secu_prof_id = dpc2.data_secu_prof_id)" << this->newLine();

            if (this->isSecuredWithAddDSP(paramSecuLevelEn))
            {
                locStream << this->getSecuOnBothDSP(entityAlias);
            }
            else
            {
                locStream
                    << "         and (" << entityAlias << "data_secu_prof_id  = dpc1.data_secu_prof_id)";
            }

            locStream << ")" << this->newLine();
            locStream << ")))";
        }
        else if (this->isSecuredWithAddDSP(paramSecuLevelEn))
        {
            ret = RET_DBA_INFO_EXIST;
            locStream
                << "(exists ( select 1 from " << this->getEntityFullSqlName("data_prof_compo") << " dpc1" << this->newLine();
            if (this->isProcedureBehavior() == false)
            {
                locStream
                    << "       where ((dpc1.data_profile_id = coalesce (" << DdlGenDbi::getCmdDataProfileId() << ", " << this->getCmdCurUsrDataProfile() << "))" << this->newLine();
            }
            else
            {
                locStream
                    << "       where ((dpc1.data_profile_id = " << this->getDataProfile() << ")" << this->newLine();
            }

            locStream << this->getSecuOnBothDSP(entityAlias);
            locStream << "))))";
        }
        else if (this->secuMandatoryFlg == FALSE)
        {
            locStream
                << "(up.data_secu_prof_id is not null))";
        }
    }

    if (this->secuMandatoryFlg == FALSE)
    {
        locStream << ")";
    }

    if (locStream.str().empty() == false)
    {
        outputStream << this->getWhereOrAnd() << locStream.str();

    }
    return ret;
}


/************************************************************************
**
**  Function    :   DdlGen::printMultiEntityManagement()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26108 - LJE - 170829
**
*************************************************************************/
size_t DdlGen::printMultiEntityManagement(DICT_ENTITY_STP   currDictEntityStp,
                                          const std::string     &entityAlias,
                                          bool              bPrintWhere,
                                          bool              bWhereRequest,
                                          std::stringstream     &outputStream)
{
    if (this->ddlGenContextPtr->ddlGenAction.isBootStrapLevel() ||
        this->ddlGenContextPtr->bAvoidMultiEntity ||
        this->ddlGenContextPtr->getViewEn()    == View_Shadow ||
        this->ddlGenContextPtr->getMultiEntityLevel() != MultiEntityLevel_Active ||
        this->ddlGenContextPtr->ddlBuildModeEn == DdlBuildMode_ViewOnly ||
        currDictEntityStp                      == nullptr ||
        currDictEntityStp->entNatEn            == EntityNat_TempTable)
    {
        return 0;
    }

    std::stringstream    meClauseStream;
    std::string          fullEntityAlias = (entityAlias.empty() == false ? entityAlias.find(".") == std::string::npos ? entityAlias + "." : entityAlias : "");

    if (fullEntityAlias.empty() && bWhereRequest)
    {
        fullEntityAlias = "#ALIAS.";
    }

    DICT_ATTRIB_STP connBusinessEntAttrStp = this->getConnBusinessEntAttrStp(currDictEntityStp);
    if (connBusinessEntAttrStp != nullptr)
    {
        if (this->ddlGenContextPtr->getViewEn() == View_MultiEntitySpec)
        {
            if (currDictEntityStp->multiEntityCateg.isPartialSpecialzed() == true)
            {
                if (this->mulitEntityAccessEn == MultiEntityAccess_None)
                {
                    meClauseStream << (bPrintWhere ? this->getWhereOrAnd() : "(") << fullEntityAlias << connBusinessEntAttrStp->sqlName << " <> " << this->ddlGenContextPtr->getMasterBusinessEntityId() << ")"
                        << " and (" << fullEntityAlias << connBusinessEntAttrStp->sqlName << " = " << this->getConnBusinessEntityId() << ")";

                }
                else if (currDictEntityStp->multiEntityCateg.isMasterVisibility())
                {
                    meClauseStream << (bPrintWhere ? this->getWhereOrAnd() : "(") << fullEntityAlias << connBusinessEntAttrStp->sqlName << " = " << this->ddlGenContextPtr->getMasterBusinessEntityId() << ")";
                }
                else
                {
                    meClauseStream << (bPrintWhere ? this->getWhereOrAnd() : "(") << fullEntityAlias << connBusinessEntAttrStp->sqlName << " = " << this->getConnBusinessEntityId() << ")";
                }
            }
            else
            {
                if (this->mulitEntityAccessEn == MultiEntityAccess_None ||
                    (currDictEntityStp->linkedEntityStp != nullptr && currDictEntityStp->linkedEntityStp->multiEntityCateg.isPartialSpecialzed() == true))
                {
                    meClauseStream << (bPrintWhere ? this->getWhereOrAnd() : "(") << fullEntityAlias << connBusinessEntAttrStp->sqlName << " = " << this->getConnBusinessEntityId() << ")";
                }
                else
                {
                    meClauseStream << (bPrintWhere ? this->getWhereOrAnd() : "(") << fullEntityAlias << connBusinessEntAttrStp->sqlName << " = " << this->ddlGenContextPtr->getMasterBusinessEntityId() << ")";
                }
            }
        }
        else if (currDictEntityStp->multiEntityCateg.isPartialSpecialzed() == false)
        {
            if (currDictEntityStp->multiEntityCateg.isBusinessEntityIsolated() || this->ddlGenContextPtr->bForceConnEntity)    /* PMSTA-29982 - LJE - 180209 */
            {
                meClauseStream << (bPrintWhere ? this->getWhereOrAnd() : "(") << fullEntityAlias << connBusinessEntAttrStp->sqlName
                    << " = " << this->getConnBusinessEntityId() << ")";
            }
            else if (currDictEntityStp->multiEntityCateg.isOptionalLocalization() || currDictEntityStp->multiEntityCateg.isFullOptionalLocalization()) /* PMSTA-38290 - HLA - 200204 */
            {
                if (this->m_ddlGenFromFileContextPtr != nullptr &&
                    (this->m_ddlGenFromFileContextPtr->currTagNat == TagSql_Delete || this->m_ddlGenFromFileContextPtr->currTagNat == TagSql_Update))
                {
                    meClauseStream << (bPrintWhere ? this->getWhereOrAnd() : "(") << fullEntityAlias << connBusinessEntAttrStp->sqlName
                        << " = " << this->getConnBusinessEntityId() << ")";
                }
                else
                {
                    meClauseStream << (bPrintWhere ? this->getWhereOrAnd() : "(") << fullEntityAlias << connBusinessEntAttrStp->sqlName
                        << " in (" << this->getConnBusinessEntityId() << ", " << this->ddlGenContextPtr->getMasterBusinessEntityId() << "))";
                }
            }
            else if (currDictEntityStp->multiEntityCateg.isInsUpdOnLocalBe())
            {
                if (this->m_ddlGenFromFileContextPtr != nullptr &&
                    (this->m_ddlGenFromFileContextPtr->currTagNat == TagSql_Delete || this->m_ddlGenFromFileContextPtr->currTagNat == TagSql_Update))
                {
                    meClauseStream << (bPrintWhere ? this->getWhereOrAnd() : "(") << fullEntityAlias << connBusinessEntAttrStp->sqlName
                        << " = " << this->getConnBusinessEntityId() << ")";
                }
            }
        }
        else if (this->ddlGenContextPtr->bForceConnEntity == true)
        {
            meClauseStream << (bPrintWhere ? this->getWhereOrAnd() : "(") << "(" << fullEntityAlias << connBusinessEntAttrStp->sqlName << " = " << this->getConnBusinessEntityId()
                << " or " << fullEntityAlias << "me_record_location_e = " << (int)MeRecordLocation_Partial << "))";
        }
        outputStream << meClauseStream.str();
    }

    return meClauseStream.str().length();
}

/************************************************************************
**
**  Function    :   DdlGen::getConnBusinessEntAttrStp()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26108 - LJE - 170829
**
*************************************************************************/
DICT_ATTRIB_STP DdlGen::getConnBusinessEntAttrStp(DICT_ENTITY_STP   currDictEntityStp)
{
    DICT_ATTRIB_STP connBusinessEntAttrStp = nullptr;

    if (currDictEntityStp == nullptr)
    {
        currDictEntityStp = this->m_dictEntityStp;
    }

    if (currDictEntityStp != nullptr &&
        currDictEntityStp->ownerBusinessEntAttrStp != nullptr)
    {
        if (this->targetTableEn == TargetTable_Main &&
            currDictEntityStp->ownerBusinessEntAttrStp->isPhysicalAttribute())       /* PMSTA-30152 - LJE - 180509 */
        {
            connBusinessEntAttrStp = currDictEntityStp->ownerBusinessEntAttrStp;
        }
        else if (this->targetTableEn == TargetTable_UserDefinedFields &&
                 currDictEntityStp->ownerBusinessEntAttrStp->isPhysicalAttribute())       /* PMSTA-30152 - LJE - 180509 */
        {
            connBusinessEntAttrStp = currDictEntityStp->udOwnerBusinessEntAttrStp;
        }
        else if (this->targetTableEn == TargetTable_Precomp)
        {
            connBusinessEntAttrStp = currDictEntityStp->extOwnerBusinessEntAttrStp;
        }
    }
    return connBusinessEntAttrStp;
}


/************************************************************************
**
**  Function    :   DdlGen::printFromRequest()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGen::printFromRequest()
{
    RET_CODE          ret = RET_SUCCEED;
    DICT_T            entityDictId;
    DICT_ENTITY_STP   locDictEntityStp = this->m_dictEntityStp;
    std::stringstream      mainFromStream;
    
    this->m_joinCpt = 0;
    this->ddlGenContextPtr->bSecurityDone = false;  /* PMSTA-43626 - LJE - 210311 */

    this->m_mainFromStream << this->newLine() << "/* security_level_e = " << (int)this->securityLevelEn << " */" << this->newLine();

    if (this->realObjectEn != NullEntity && this->realDictEntityStp)
    {
        locDictEntityStp = this->realDictEntityStp;
    }

    DBA_GetDictId(DictEntity, &entityDictId);

    if ((this->getEntityMdName().compare("empty") == 0 && this->realSqlName.empty()) || this->realSqlName.compare("empty") == 0)
    {
        this->m_mainFromStream << DdlGenDbi::getEmptyFrom();
    }
    else if (this->ddlGenContextPtr->ddlBuildModeEn == DdlBuildMode_ViewOnly &&
             locDictEntityStp->entNatEn != EntityNat_Internal &&
             locDictEntityStp->entNatEn != EntityNat_TempTable)         /* PMSTA-45830 - LJE - 211015 */
    {
        this->m_mainFromStream << this->getCmdFrom() << this->getEntityFullSqlName(nullptr, TargetTable_View) << " " << this->getAlias(true);
    }
    else
    {
        this->m_mainFromStream << this->getCmdFrom();

        /* from clause */
        if (this->m_dictEntityStp->logicalFlg == FALSE || 
            this->m_dictEntityStp->entNatEn == EntityNat_Questionnaire ||
            this->realSqlName.empty() == false)
        {
            int    joinCpt = 0;
            std::string udAlias = this->getAlias(false);

            /* PMSTA-18382 - LJE - 141024 */
            if (this->bJoinOnFromTag)
            {
                std::vector<std::string>   tokens;
                DdlGen::tokenizeStr(tokens, this->fromAddStr, " \t");

                if (tokens.size() > 2 &&
                    this->fromAddStr.find(tokens[1] + ".id") != std::string::npos)
                {
                    udAlias = tokens[1] + ".";
                }
            }
            else if (this->bReplaceFromTag)
            {
                std::vector<std::string>   tokens;
                DdlGen::tokenizeStr(tokens, this->fromAddStr, " \t");

                if (tokens.size() > 1)
                {
                    DICT_ENTITY_STP replaceDictEntityStp = DBA_GetEntityBySqlName(tokens[0]);

                    if (replaceDictEntityStp != nullptr)
                    {
                        mainFromStream << this->getEntityFullSqlName(replaceDictEntityStp);
                        bool isTable = false;
                        for(size_t i=1;i<tokens.size();i++)
                        {
                            if(isTable)
                            {
                                replaceDictEntityStp = DBA_GetEntityBySqlName(tokens[i]);
                                mainFromStream << " " << this->getEntityFullSqlName(replaceDictEntityStp);
                                isTable=false;
                            }
                            else
                            {
                                isTable = tokens[i] == "join";                                
                                mainFromStream << " " << tokens[i];
                            }
                        }
                    }
                    else
                    {
                        this->printMsg(RET_GEN_ERR_INVARG, "Invalid #FROM argument using \"replace\" option: unknown entity \"" + tokens[0] + "\"");
                    }
                }
                else
                {
                    this->printMsg(RET_GEN_ERR_INVARG, "Invalid #FROM argument using \"replace\" option: 2 parameters expected");
                }

                this->fromAddStr.clear();
            }
            else if (this->outputDynNatEn != DynType_UdOnly)
            {
                if (this->mulitEntityAccessEn != MultiEntityAccess_None) /* PMSTA-26108 - LJE - 170905 */
                {
                    mainFromStream << this->getEntityFullSqlName() << " " << this->getAlias(true);
                }
                else if (this->bShadowAccess)
                {
                    this->m_fromStream
                        << newLine() << this->getEntityFullSqlName(locDictEntityStp->pkEntityStp) << " pk"
                        << newLine() << this->getCmdLeftJoin() << this->getEntityFullSqlName(nullptr, TargetTable_TechView) << " " << this->getAlias(true);

                    this->m_fromStream
                        << " on " << this->getPkAccessWhere(locDictEntityStp, nullptr, "pk", this->getAlias(true), false)
                        << newLine() << this->getCmdLeftJoin() << this->getEntityFullSqlName(locDictEntityStp->shadowEntityStp, TargetTable_TechView) << " sh";

                    this->m_fromStream
                        << " on " << this->getPkAccessWhere(locDictEntityStp, nullptr, "pk", "sh", false)
                        << " and sh.change_set_promotion_id = " << this->getChangeSetId();
                }
                else
                {
                    mainFromStream << this->getEntityFullSqlName(nullptr, TargetTable_Undefined, true) << " " << this->getAlias(true);
                }
            }

            if (this->fromAddStr.empty() == false)
            {
                mainFromStream << " " << this->fromAddStr;
            }

            this->setIndent(1);

            /* Ud field access */
            if (this->custFlg == TRUE &&
                this->m_bCustInView == false &&
                locDictEntityStp->primKeyNbr == 1 &&
                this->bShadowAccess == false &&
                this->m_dictEntityStp->dbRuleEn != DbRule_PartialSpecialization &&

                (this->ddlGenContextPtr->getDdlGenMode() == DdlGenMode_MultiEntity ||
                 locDictEntityStp->multiEntityCateg.isUseMeViewAsTable() == false ||       /* PMSTA-32145 - LJE - 180718 */
                 this->ddlGenContextPtr->bAvoidMultiEntity == true) &&                     /* PMSTA-nuodb - LJE - 190603 */

                 (this->ddlGenContextPtr->getDdlGenMode() != DdlGenMode_Shadow ||
                  this->m_dictEntityStp->changeSetAuthEn != FeatureAuth_Enable ||
                  this->m_dictEntityStp->dbRuleEn == DbRule_ShadowTable ||
                  this->ddlGenContextPtr->bForceUdTable))
            {
                std::string locUdTableName = this->getEntityFullSqlName(this->getDictEntityStp(), TargetTable_UserDefinedFields);

                if (this->realObjectEn != NullEntity && this->realDictEntityStp)
                {
                    std::string realUdTable = this->getEntityFullSqlName(this->realDictEntityStp, TargetTable_UserDefinedFields);
                    if (realUdTable.empty() == false)
                    {
                        locUdTableName = realUdTable;
                    }
                }

                if (this->outputDynNatEn != DynType_UdOnly)
                {
                    this->m_fromStream << newLine() << this->getCmdInnerJoin()
                        << locUdTableName << " ud " << this->getCmdJoinOn()
                        << "((" << udAlias << locDictEntityStp->primKeyTab[0]->sqlName << " = ud.ud_id)";

                    /* PMSTA-26108 - LJE - 170818 */
                    if (locDictEntityStp->udOwnerBusinessEntAttrStp && locDictEntityStp->ownerBusinessEntAttrStp && this->ddlGenContextPtr->bAvoidMultiEntity == false)
                    {
                        this->m_fromStream << " and (" << this->getAlias() << locDictEntityStp->ownerBusinessEntAttrStp->sqlName << " = ud." << locDictEntityStp->udOwnerBusinessEntAttrStp->sqlName << ")";
                    }

                    this->m_fromStream << ")";

                    if (this->ddlGenContextPtr->m_rdbmsEn == PostgreSQL)
                    {
                        this->m_joinCpt++;
                        this->m_fromStream << ")";
                    }
                }
                else
                {
                    this->m_fromStream << locUdTableName << " ud ";
                }
            }

            /* Extension access */
            if (this->precompFlg == TRUE && 
                locDictEntityStp->primKeyNbr == 1 && 
                this->bHidePrecomp == false) /* PMSTA-19204 - LJE - 150107 */
            {
                this->m_fromStream << newLine() << this->getCmdLeftJoin()
                    << this->getEntityFullSqlName(locDictEntityStp, TargetTable_Precomp)
                    << " x " << this->getCmdJoinOn()
                    << "((" << udAlias << locDictEntityStp->primKeyTab[0]->sqlName << " = x.x_id)";

                /* PMSTA-26108 - LJE - 170818 */
                if (locDictEntityStp->extOwnerBusinessEntAttrStp != nullptr && this->ddlGenContextPtr->bAvoidMultiEntity == false)
                {
                    this->m_fromStream << " and (x." << locDictEntityStp->extOwnerBusinessEntAttrStp->sqlName << " = " << this->getConnBusinessEntityId() << ")";
                }
                this->m_fromStream << ")";

                if (this->ddlGenContextPtr->m_rdbmsEn == PostgreSQL)
                {
                    this->m_joinCpt++;
                    this->m_fromStream << ")";
                }
            }

            /* Codification access */
            if (this->ddlGenContextPtr->m_bCodif && locDictEntityStp->primKeyNbr == 1)
            {
                this->m_fromStream << newLine()
                    << this->getCmdLeftJoin() << DdlGenDbi::getSynonymSqlName() << " sy on ((sy.entity_dict_id = " << locDictEntityStp->entDictId << ") and ("
                    << this->getAlias() << locDictEntityStp->primKeyTab[0]->sqlName << " = sy.object_id and sy.codification_id = " << this->getCodif() << "))";

                if (this->ddlGenContextPtr->m_rdbmsEn == PostgreSQL)
                {
                    this->m_joinCpt++;
                    this->m_fromStream << ")";
                }
            }

            if (this->ddlGenContextPtr->bSecurityDone == false) /* PMSTA-43626 - LJE - 210311 */
            {
                /* Add entity security */
                this->printSecurityOnFrom(this->securityLevelEn,
                                          true,
                                          true,
                                          this->getAlias(true),
                                          std::string(),
                                          this->m_fromStream,
                                          joinCpt,
                                          this->m_fromStream);
            }

            /* PMSTA-32145 - LJE - 180718 */
            if (this->mulitEntityAccessEn == MultiEntityAccess_PartialSpecialization &&
                locDictEntityStp->multiEntityCateg.isPartialSpecialzed())
            {
                this->setOnJoin(true);

                std::string beAlias = this->getAlias(true) + "_be";
                this->m_fromStream
                    << newLine() << this->getCmdLeftJoin() << this->getEntityFullSqlName(locDictEntityStp->beEntityStp) << " " << beAlias
                    << this->getWhereOrAnd() << this->getPkAccessWhere(locDictEntityStp, nullptr, beAlias, this->getAlias(true), false) << ")";

                this->printMultiEntityManagement(locDictEntityStp->beEntityStp, beAlias, true, false, this->m_fromStream);

                this->m_fromStream << ")";

                if (this->ddlGenContextPtr->m_rdbmsEn == PostgreSQL)
                {
                    this->m_joinCpt++;
                    this->m_fromStream << ")";
                }
            }

            this->setIndent(-1);
        }
    }

    /* Sort the joins */
    std::sort(this->joinTab.begin(), this->joinTab.end());

    int sortJoin = 0;
    for (auto it = this->joinTab.begin(); it != this->joinTab.end(); it++)
    {
        it->parentJoinStp = NULL;
        if (locDictEntityStp->entDictId == it->parentEntDictId)
        {
            it->sortJoin = sortJoin++;
        }
        else
        {
            it->sortJoin = -1;
        }
    }

    for (auto it = this->joinTab.begin(); it != this->joinTab.end(); it++)
    {
        if (it->sortJoin >= 0)
        {
            bool bNewParent = false;
            for (auto it2 = this->joinTab.begin(); it2 != this->joinTab.end(); it2++)
            {
                DICT_CRITER_STP joinDictCriteriaStp = this->getDictCriteriaStp(it2->firstIdPos);
                if (it2->parentJoinStp == NULL &&
                    joinDictCriteriaStp != nullptr &&
                    it->joinSqlName.compare(joinDictCriteriaStp->joinSqlName) == 0)
                {
                    const DdlGenJoin &joinStp = *it;

                    it2->parentJoinStp = &joinStp;
                    it2->sortJoin = sortJoin++;
                    bNewParent = true;
                }
            }
            if (bNewParent)
            {
                it = this->joinTab.begin();
            }
        }
    }

    std::sort(this->joinTab.begin(), this->joinTab.end());

    /* Join clause */
    for (auto it = this->joinTab.begin(); it != this->joinTab.end(); it++)
    {
        int    joinCpt = 0;
        std::string joinAlias = this->getJoinAlias(*it, true);
        bool   bMandatoryJoin = false;

        if (it->addJoinInfoStr.empty() == false)
        {
            this->m_fromStream << this->newLine();
            if (it->joinTypeEn == DDlJoinType_LeftOuterJoin)
            {
                this->m_fromStream << "   " << this->getCmdLeftJoin();
            }
            else if (it->joinTypeEn == DDlJoinType_RightOuterJoin)
            {
                this->m_fromStream << "   " << this->getCmdRightJoin();
            }
            else if (it->joinTypeEn == DDlJoinType_InnerJoin)
            {
                bMandatoryJoin = true;
                this->m_fromStream << "   " << this->getCmdInnerJoin();
            }
            else if (it->joinTypeEn != DDlJoinType_None)
            {
                this->m_fromStream << "  , ";
            }

            std::stringstream addJoinStream;

            addJoinStream
                << it->joinEntitySqlName
                << " " << joinAlias;

            /* Add entity security */
            this->printSecurityOnFrom(it->securityLevelEn, false, bMandatoryJoin, joinAlias, joinAlias + "_", addJoinStream, joinCpt, addJoinStream);

            addJoinStream << " " << it->addJoinInfoStr;
            this->m_bWherePrinted = true;

            /* PMSTA-nuodb - LJE - 190705 */
            this->printMultiEntityManagement(it->joinDictEntityStp, joinAlias, true, false, addJoinStream);

            /* Add entity security */
            this->printSecurityOnWhere(it->securityLevelEn,
                                       true,
                                       it->joinSqlName,
                                       addJoinStream);

            this->m_fromStream << addJoinStream.str();
        }
        else
        {
            bool mandatoryJoin = false;
            DICT_CRITER_STP dictCriteriaStp = this->getDictCriteriaStp(it->firstIdPos);

            if (dictCriteriaStp != nullptr)
            {
                if (it->isNullFirstId == false &&
                    it->mandatoryFlg == TRUE &&
                    dictCriteriaStp->attrPtr->mandatoryFlg == TRUE &&
                    dictCriteriaStp->attrPtr->refEntDictId != entityDictId &&
                    (dictCriteriaStp->attrPtr->refEntDictId != 0 || dictCriteriaStp->attrPtr->linkedAttrDictId != 0))               /* PMSTA-27272 - LJE - 180604 - Manage the case of table how share the id */
                {
                    mandatoryJoin = true;
                }

                this->m_fromStream << this->newLine() << "\t";

                this->setOnJoin(true);

                if (mandatoryJoin)
                {
                    this->m_fromStream << " " << this->getCmdInnerJoin();
                }
                else
                {
                    this->m_fromStream << " " << this->getCmdLeftJoin();
                }

                if (it->objectEn == DictLabel)
                {
                    std::stringstream addJoinStream;

                    addJoinStream
                        << this->getEntityFullSqlName(it->joinDictEntityStp) << " " << joinAlias
                        << this->getWhereOrAnd() << it->joinSqlName << "entity_dict_id = " << it->parentEntDictId
                        << ") and (" << it->joinSqlName << "object_dict_id"
                        << " = " << this->getAlias(false);

                    if (dictCriteriaStp->attrEntDictId == dictCriteriaStp->entDictId)
                    {
                        addJoinStream << dictCriteriaStp->sqlName;
                    }
                    else if (dictCriteriaStp->isNullParent1ProgN == false)
                    {
                        addJoinStream << dictCriteriaStp->parent1SqlName;
                    }

                    addJoinStream
                        << ") and (" << it->joinSqlName << "language_dict_id = ";

                    if (this->isProcedureBehavior() == false)
                    {
                        this->printUserJoin();
                        addJoinStream
                            << "coalesce (" << DdlGenDbi::getCmdLanguageDictId() << ", curr_usr.language_dict_id)";
                    }
                    else
                    {
                        this->ddlGenContextPtr->bLanguage = true;
                        addJoinStream << "" << this->getLanguage();
                    }

                    addJoinStream << "))";
                    this->m_fromStream << addJoinStream.str();
                    continue;
                }
                else if (it->objectEn == Denom)
                {
                    std::stringstream addJoinStream;

                    addJoinStream
                        << this->getEntityFullSqlName(it->joinDictEntityStp) << " " << joinAlias
                        << " on (((" << it->joinSqlName << "entity_dict_id = " << it->parentEntDictId
                        << ") and (" << this->getAlias(false) << dictCriteriaStp->attrPtr->sqlName
                        << " = " << it->joinSqlName << "object_id) and (" << it->joinSqlName << "language_dict_id = ";

                    if (this->isProcedureBehavior() == false)
                    {
                        this->printUserJoin();
                        addJoinStream
                            << "coalesce (" << DdlGenDbi::getCmdLanguageDictId() << ", curr_usr.language_dict_id)";
                    }
                    else
                    {
                        this->ddlGenContextPtr->bLanguage = true;
                        addJoinStream << "" << this->getLanguage();
                    }
                    addJoinStream << ")))";

                    if (this->ddlGenContextPtr->m_rdbmsEn == PostgreSQL)
                    {
                        this->m_joinCpt++;
                        addJoinStream << ")";
                    }

                    this->m_fromStream << addJoinStream.str();
                    continue;
                }
                /* OCS-43062 - LJE - 130913 */
                else if (it->joinTypeEn == DDlJoinType_LogicalFkJoin)
                {
                    std::stringstream addJoinStream;

                    DICT_CRITER_STP keyDictCriterStp;
                    DICT_ATTRIB_STP dictAttribStp = it->dictAttribStp;

                    keyDictCriterStp = this->getDictCriteriaStp(it->firstIdPos);

                    addJoinStream << this->getEntityFullSqlName(it->joinDictEntityStp) << " " << joinAlias
                        << this->getWhereOrAnd();

                    addJoinStream << it->joinSqlName << dictAttribStp->linkedAttrDictStp->linkedAttrDictStp->sqlName
                        << " = " << dictAttribStp->entDictId << ")" << this->getWhereOrAnd();

                    addJoinStream << it->joinSqlName << dictAttribStp->linkedAttrDictStp->sqlName
                        << " = "
                        << this->getCriteriaAlias(keyDictCriterStp) << keyDictCriterStp->attrPtr->sqlName << ")";

                    /* PMSTA-nuodb - LJE - 190705 */
                    this->printMultiEntityManagement(it->joinDictEntityStp, joinAlias, true, false, addJoinStream);

                    this->printSecurityOnWhere(it->securityLevelEn,
                                               this->isSecuredWithAddDSP(it->securityLevelEn),
                                               it->joinSqlName,
                                               addJoinStream);

                    addJoinStream << ")";

                    if (this->ddlGenContextPtr->m_rdbmsEn == PostgreSQL)
                    {
                        this->m_joinCpt++;
                        addJoinStream << ")";
                    }

                    this->m_fromStream << addJoinStream.str();
                }
                else if (it->joinDictEntityStp != nullptr)
                {
                    std::stringstream addJoinStream;

                    DICT_CRITER_STP keyDictCriterStp[2];
                    int             keyPos = 0;

                    keyDictCriterStp[0] = this->getDictCriteriaStp(it->firstIdPos);
                    keyDictCriterStp[1] = (it->isNullSecondId ? nullptr : this->getDictCriteriaStp(it->secondIdPos));

                    for (auto attribIt = it->joinDictEntityStp->attr.begin(); attribIt != it->joinDictEntityStp->attr.end() && keyPos < it->joinDictEntityStp->primKeyNbr; ++attribIt)
                    {
                        DICT_ATTRIB_STP dictAttribStp = (*attribIt);

                        if (dictAttribStp->primFlg == FALSE)
                            continue;

                        if (keyPos == 0)
                        {
                            addJoinStream << this->getEntityFullSqlName(it->joinDictEntityStp) << " " << joinAlias;

                            if (this->ddlGenContextPtr->m_rdbmsEn == Nuodb ||
                                mandatoryJoin == false)
                            {
                                /* Add entity security */
                                this->printSecurityOnFrom(it->securityLevelEn, false, mandatoryJoin, joinAlias, joinAlias + "_", addJoinStream, joinCpt, addJoinStream);
                                this->m_bWherePrinted = false;
                            }
                        }

                        if (keyDictCriterStp[keyPos]->attrPtr == NULL)
                        {
                            MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "Wrong join attribute", it->joinDictEntityStp->mdSqlName);
                            return RET_GEN_ERR_INVARG;
                        }

                        if (keyDictCriterStp[0]->attrPtr->refEntDictId == entityDictId &&
                            it->isNullSecondId == false)
                        {
                            addJoinStream << this->getWhereOrAnd() << this->getAlias(false) << keyDictCriterStp[0]->attrPtr->sqlName
                                << " = " << it->joinDictEntityStp->entDictId << ")";
                            keyPos++;
                        }

                        addJoinStream << this->getWhereOrAnd() << this->getCriteriaAlias(keyDictCriterStp[keyPos]) << keyDictCriterStp[keyPos]->attrPtr->sqlName
                            << " = "
                            << it->joinSqlName << dictAttribStp->sqlName << ")";

                        /* PMSTA-36919 - LJE - 191209 */
                        this->printMultiEntityManagement(it->joinDictEntityStp, joinAlias, true, false, addJoinStream);

                        if (keyPos == 0)
                        {
                            /* Add entity security */
                            if (this->printSecurityOnWhere(it->securityLevelEn,
                                                           true,
                                                           it->joinSqlName,
                                                           addJoinStream) == RET_DBA_INFO_EXIST &&
                                this->ddlGenContextPtr->m_rdbmsEn == PostgreSQL)
                            {
                                std::string addJoinStr = addJoinStream.str();

                                auto onPos = addJoinStr.find(this->getCmdJoinOn());

                                if (onPos != std::string::npos)
                                {
                                    addJoinStr.replace(onPos + this->getCmdJoinOn().length() + 1, 0, "(");
                                    addJoinStr += ")";

                                    addJoinStream.clear();
                                    addJoinStream.str(std::string());

                                    addJoinStream << addJoinStr;
                                }
                            }
                        }

                        keyPos++;
                    }

                    addJoinStream << ")";

                    if (this->ddlGenContextPtr->m_rdbmsEn == PostgreSQL)
                    {
                        this->m_joinCpt++;
                        addJoinStream << ")";
                    }

                    if (this->ddlGenContextPtr->m_rdbmsEn != Nuodb && mandatoryJoin == true)
                    {
                        /* Add entity security */
                        this->printSecurityOnFrom(it->securityLevelEn, false, mandatoryJoin, joinAlias, joinAlias + "_", addJoinStream, joinCpt, addJoinStream);
                    }

                    for (int i = 0; i < joinCpt; i++)
                    {
                        this->m_fromStream << "(";
                    }

                    this->m_fromStream << addJoinStream.str();
                }

                if (it->codifFlg == TRUE)
                {
                    this->m_fromStream << DdlGenDbi::getSynonymSqlName() << " sy" << joinAlias;
                }
            }
        }
    }
    this->setOnJoin(false);

    /* Put customize join table in the from clause */
    for (auto addedJoinIt = this->addedJoinTab.begin(); addedJoinIt != this->addedJoinTab.end(); ++addedJoinIt)
    {
        int    joinCpt = 0;
        std::string joinAlias = this->getJoinAlias(*addedJoinIt, true);
        bool   bLocOnJoin = true;
        bool   bMandatoryJoin = false;
        bool   bPostgreSQLUpd = false;

        this->setOnJoin(true);

        this->m_fromStream << this->newLine();
        if (addedJoinIt->joinTypeEn == DDlJoinType_LeftOuterJoin)
        {
            this->m_fromStream << "   " << this->getCmdLeftJoin();
        }
        else if (addedJoinIt->joinTypeEn == DDlJoinType_RightOuterJoin)
        {
            this->m_fromStream << "   " << this->getCmdRightJoin();
        }
        else if (addedJoinIt->joinTypeEn == DDlJoinType_InnerJoin)
        {
            bMandatoryJoin = true;

            if (this->ddlGenContextPtr->m_rdbmsEn == PostgreSQL &&
                this->getDdlGenFromFileContextPtr() != nullptr &&
                this->getDdlGenFromFileContextPtr()->currTagNat == TagSql_Update && 
                addedJoinIt == this->addedJoinTab.begin())
            {
                bPostgreSQLUpd = true;
            }
            else
            {
                this->m_fromStream << "   " << this->getCmdInnerJoin();
            }
        }
        else
        {
            bLocOnJoin = false;
            this->setOnJoin(false);

            if (addedJoinIt->joinTypeEn != DDlJoinType_None)
            {
                this->m_fromStream << "  , ";
            }
        }

        std::stringstream addJoinStream;
        std::stringstream closeJoinStream;

        addJoinStream
            << addedJoinIt->joinEntitySqlName
            << " " << joinAlias;

        size_t addFromPos = std::string::npos;

        /* Add entity security */
        if (bLocOnJoin &&
            this->printSecurityOnFrom(addedJoinIt->securityLevelEn, false, bMandatoryJoin, joinAlias, joinAlias + "_", addJoinStream, joinCpt, closeJoinStream) == RET_SUCCEED)
        {
            this->m_bWherePrinted = false;
        }

        if (addedJoinIt->addJoinInfoStr.empty() == false)
        {
            if (bLocOnJoin)
            {
                addFromPos = this->find_word(addedJoinIt->addJoinInfoStr, "on");
                if (addFromPos != 0)
                {
                    size_t joinPos = this->find_word(addedJoinIt->addJoinInfoStr, "inner");
                    if (joinPos < addFromPos)
                    {
                        addFromPos = joinPos;
                    }
                    joinPos = this->find_word(addedJoinIt->addJoinInfoStr, "left");
                    if (joinPos < addFromPos)
                    {
                        addFromPos = joinPos;
                    }
                    joinPos = this->find_word(addedJoinIt->addJoinInfoStr, "right");
                    if (joinPos < addFromPos)
                    {
                        addFromPos = joinPos;
                    }

                    if (addFromPos == 0)
                    {
                        addFromPos = std::string::npos;
                        addJoinStream << " " << addedJoinIt->addJoinInfoStr;
                    }
                }
            }
            else
            {
                addJoinStream << " " << addedJoinIt->addJoinInfoStr;
            }
        }

        if (bLocOnJoin)
        {
            if (addFromPos != std::string::npos && addedJoinIt->joinTypeEn == DDlJoinType_InnerJoin && addedJoinIt->addJoinInfoStr.empty() == false)
            {
                if (bPostgreSQLUpd)
                {
                    AAAValueGuard<bool> boolGuard(this->m_bWherePrinted);

                    this->whereStream << " where (" << addedJoinIt->addJoinInfoStr.substr(addFromPos + 3);
                    this->m_bWherePrinted = true;
                    this->printMultiEntityManagement(addedJoinIt->joinDictEntityStp, joinAlias, true, false, this->whereStream);
                }
                else
                {
                    auto addFromStr = addedJoinIt->addJoinInfoStr.substr(addFromPos + 3);

                    /* PMSTA-58084 - LJE - 240729 */
                    if (this->ddlGenContextPtr->m_rdbmsEn == MSSql)
                    {
                        auto joinTblSpec = DdlGenDbi::getTempTableSpec(this->ddlGenContextPtr->m_rdbmsEn, addedJoinIt->joinDictEntityStp);
                        auto locTblSpec = DdlGenDbi::getTempTableSpec(this->ddlGenContextPtr->m_rdbmsEn, locDictEntityStp);

                        if ((joinTblSpec == DdlGenDbi::TempTableSpec::MemoryOptimzed ||
                             locTblSpec == DdlGenDbi::TempTableSpec::MemoryOptimzed ||
                             joinTblSpec == DdlGenDbi::TempTableSpec::Type ||
                             locTblSpec == DdlGenDbi::TempTableSpec::Type) &&
                            (addedJoinIt->joinDictEntityStp == nullptr ||
                             addedJoinIt->joinDictEntityStp->entNatEn != locDictEntityStp->entNatEn))
                        {
                            auto fixDictEntityStp = (locDictEntityStp->entNatEn == EntityNat_TempTable ? locDictEntityStp : addedJoinIt->joinDictEntityStp);
                            auto joinName = (locDictEntityStp->entNatEn == EntityNat_TempTable ? this->getAlias(false) : addedJoinIt->joinSqlName);
                            for (auto& attribIt : fixDictEntityStp->attr)
                            {
                                if (attribIt->isPhysicalAttribute() &&
                                    IS_STRING_TYPE(attribIt->dataTpProgN) == TRUE)
                                {
                                    auto searchStr = joinName + attribIt->sqlName;
                                    size_t pos = 0;
                                    while ((pos = addFromStr.find(searchStr, pos)) != std::string::npos)
                                    {
                                        addFromStr.replace(pos + searchStr.length(), 0, " COLLATE Latin1_General_100_CI_AS_SC ");
                                        pos += searchStr.length();
                                    }
                                }
                            }
                        }
                    }

                    addJoinStream << this->getWhereOrAnd() << addFromStr;
                    this->printMultiEntityManagement(addedJoinIt->joinDictEntityStp, joinAlias, true, false, addJoinStream);
                }
            }

            if (addFromPos != std::string::npos && addedJoinIt->joinTypeEn != DDlJoinType_InnerJoin && addedJoinIt->addJoinInfoStr.empty() == false)
            {
                if (bPostgreSQLUpd)
                {
                    SYS_BreakOnDebug();
                }

                addJoinStream << this->getWhereOrAnd() << addedJoinIt->addJoinInfoStr.substr(addFromPos + 3);

                /* PMSTA-nuodb - LJE - 190705 */
                this->printMultiEntityManagement(addedJoinIt->joinDictEntityStp, joinAlias, true, false, addJoinStream);
            }

            if (addedJoinIt->joinDictEntityStp != nullptr)
            {
                /* Add entity security */
                this->printSecurityOnWhere(addedJoinIt->securityLevelEn,
                                           true,
                                           addedJoinIt->joinSqlName,
                                           addJoinStream);
            }

            addJoinStream << closeJoinStream.str();

            if (addFromPos != std::string::npos)
            {
                if (bPostgreSQLUpd)
                {
                    this->whereStream << ")";
                }
                else
                {
                    addJoinStream << ")";
                }
            }
        }
        else
        {
            this->printMultiEntityManagement(addedJoinIt->joinDictEntityStp, joinAlias, true, false, this->whereStream);

            /* Add entity security */
            this->printSecurityOnFrom(addedJoinIt->securityLevelEn, false, bMandatoryJoin, joinAlias, joinAlias + "_", addJoinStream, joinCpt, addJoinStream);

            if (this->m_bWherePrinted)
            {
                this->whereStream << ")";
            }
        }

        this->m_fromStream << addJoinStream.str();

        if (this->m_bWherePrinted && bLocOnJoin)
        {
            this->m_fromStream << ")";
        }
    }

    if (this->bOnJoin)
    {
        this->setOnJoin(false);
    }

    /* OCS-39654 - LJE - 120213 */
    /* Portfolio Third Compo Secured access */
    if (this->thirdCompoSecuredFlg == TRUE)
    {
        this->m_fromStream << newLine()
            << "   inner join portfolio_third_compo ptc on ptc.portfolio_id = E.id and ptc.third_id = " << DdlGenDbi::getCmdThirdPartyId();

        if (this->ddlGenContextPtr->m_rdbmsEn == PostgreSQL)
        {
            this->m_joinCpt++;
            this->m_fromStream << ")";
        }
    }

    if (this->m_joinCpt > 0)
    {
        for (int i = 0; i < this->m_joinCpt; ++i)
        {
            this->m_mainFromStream << "(";
        }
        this->m_mainFromStream << mainFromStream.str();
        this->m_joinCpt = 0;
    }
    else
    {
        this->m_mainFromStream << mainFromStream.str();
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGen::extractAndFixDependsEntity()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26250 - LJE - 170403
**
*************************************************************************/
bool DdlGen::extractAndFixDependsEntity(std::string &lineStr)
{
    bool                bUpdated = false;
    const static std::string wordDelimiter = " \t\n(~";
    const static std::string fromDelimiter = " \t\n,";

    std::string::size_type selPos = this->find_word(lineStr, "select", 0, std::string::npos, wordDelimiter);

    while (selPos != std::string::npos)
    {
        bool              bToTreat = true;
        std::string::size_type fromPos = this->find_word(lineStr, "from", selPos);
        bool              bBracket = false;
        std::string::size_type pos = selPos ? selPos - 1 : 0;

        while (pos && wordDelimiter.find(lineStr[pos]) != std::string::npos)
        {
            if (lineStr[pos] == '(')
            {
                bBracket = true;

                if ((pos + 1) < lineStr.length() &&
                    lineStr[pos + 1] == '~')
                {
                    bToTreat = false;
                    lineStr.erase(pos + 1, 1);
                    selPos--;
                }
                break;
            }
            pos--;
        }
        std::string::size_type endPos = lineStr.length() - 1;

        if (bBracket)
        {
            int nbBracket = 0;
            endPos = fromPos;
            while (endPos < lineStr.length())
            {
                if (lineStr[endPos] == '(')
                {
                    nbBracket++;
                }
                else if (lineStr[endPos] == ')')
                {
                    if (nbBracket)
                    {
                        nbBracket--;
                    }
                    else
                    {
                        break;
                    }
                }
                endPos++;
            }
        }

        if (bToTreat)
        {
            std::vector<std::string>      tokens;
            std::map<std::string, std::string> toReplaceMap;
            std::map<std::string, std::string> entitiesMap;
            std::string              lastEntitySqlName;
            std::string::size_type   wherePos = this->find_word(lineStr, "where", fromPos);

            if (wherePos == std::string::npos)
            {
                wherePos = endPos;
            }

            this->tokenizeStr(tokens, lineStr.substr(fromPos + 4, wherePos - fromPos - 4), fromDelimiter);
            bool bSkip = false;

            for (auto it = tokens.begin(); it != tokens.end(); it++)
            {
                std::string::size_type subPos = it->find_last_of(".");
                bool              bEntity = false;

                if ((*it)[0] == '(')
                {
                    std::string recurseStr = *it;
                    this->extractAndFixDependsEntity(recurseStr);
                    toReplaceMap.insert(std::make_pair(*it, recurseStr));

                    if (lastEntitySqlName.empty())
                    {
                        lastEntitySqlName = *it;
                    }
                    continue;
                }

                if (this->find_word(*it, "join") != std::string::npos)
                {
                    bSkip = false;

                    if (lastEntitySqlName.empty() == false)
                    {
                        entitiesMap.insert(std::make_pair(lastEntitySqlName, lastEntitySqlName));
                        lastEntitySqlName.clear();
                    }
                    continue;
                }

                if (this->find_word(*it, "on") != std::string::npos)
                {
                    bSkip = true;
                    continue;
                }

                if (bSkip ||
                    this->find_word(*it, "inner") != std::string::npos ||
                    this->find_word(*it, "left") != std::string::npos ||
                    this->find_word(*it, "right") != std::string::npos ||
                    this->find_word(*it, "outer") != std::string::npos ||
                    this->find_word(*it, "or") != std::string::npos ||
                    this->find_word(*it, "and") != std::string::npos ||
                    this->find_word(*it, ")") == 0 ||
                    this->find_word(*it, "exists") != std::string::npos ||
                    this->find_word(*it, "#INDEX") != std::string::npos ||
                    *it == "\"" ||
                    *it == "+" ||
                    (*it)[0] == '@')
                {
                    if (lastEntitySqlName.empty() == false)
                    {
                        entitiesMap.insert(std::make_pair(lastEntitySqlName, lastEntitySqlName));
                        lastEntitySqlName.clear();
                    }
                    continue;
                }

                if (this->find_word(*it, "where") != std::string::npos)
                {
                    break;
                }

                if (this->find_word(*it, "group") != std::string::npos)
                {
                    break;
                }

                if (lastEntitySqlName.empty())
                {
                    bEntity = true;

                    if ((subPos == std::string::npos && (*it)[0] == '$') ||
                        (subPos != std::string::npos && (*it)[subPos + 1] == '$'))
                    {
                        lastEntitySqlName = this->ddlGenContextPtr->getPropFileHelper().getProperty(it->substr(1));
                    }
                    else
                    {
                        lastEntitySqlName = (subPos == std::string::npos ? *it : it->substr(subPos + 1));
                    }

                    DICT_ENTITY_STP selDictEntityStp = DBA_GetEntityBySqlName(lastEntitySqlName);

                    if (selDictEntityStp != nullptr)
                    {
                        std::string fullSqlName = this->getEntityFullSqlName(selDictEntityStp);
                        toReplaceMap.insert(std::make_pair(*it, fullSqlName));
                    }
                    else
                    {
                        lastEntitySqlName = lastEntitySqlName.substr(0, lastEntitySqlName.find_first_of(")"));
                        selDictEntityStp = DBA_GetEntityBySqlName(lastEntitySqlName);

                        if (selDictEntityStp != nullptr)
                        {
                            std::string fullSqlName = this->getEntityFullSqlName(selDictEntityStp);
                            toReplaceMap.insert(std::make_pair(lastEntitySqlName, fullSqlName));
                        }
                        else if (this->isSystemTable(lastEntitySqlName) == false &&
                                 this->isSystemTable(*it) == false &&
                                 DBA_GetEntityBySqlName(lastEntitySqlName.substr(0, lastEntitySqlName.find_last_of("_"))) == nullptr)
                        {
                            if (this->ddlGenContextPtr->ddlGenAction.isBootStrapLevel())
                            {
                                lineStr.clear();
                                return true;
                            }

                            std::stringstream msg;
                            msg << "Unknown entity \"" << lastEntitySqlName << "\"";
                            this->printMsg(RET_GEN_ERR_INVARG, msg.str());
                        }
                    }
                }

                if (bEntity == false)
                {
                    entitiesMap.insert(std::make_pair(*it, lastEntitySqlName));
                    lastEntitySqlName.clear();
                }
            }

            if (lastEntitySqlName.empty() == false)
            {
                entitiesMap.insert(std::make_pair(lastEntitySqlName, lastEntitySqlName));
                lastEntitySqlName.clear();
            }

            for (auto it = entitiesMap.begin(); it != entitiesMap.end(); it++)
            {
                DICT_ENTITY_STP selDictEntityStp = DBA_GetEntityBySqlName(it->second);

                if (selDictEntityStp != nullptr && this->getConnBusinessEntAttrStp(selDictEntityStp))
                {
                    std::string::size_type aliasPos = fromPos;
                    std::stringstream      whereClauseAddStream;
                    std::string            aliasStr = (it->first == it->second ? "" : it->first);

                    size_t meEndPos = this->printMultiEntityManagement(selDictEntityStp, aliasStr, false, false, whereClauseAddStream);

                    if (meEndPos > 0)
                    {
                        if ((aliasPos = this->find_word(lineStr, it->first, fromPos)) != std::string::npos)
                        {
                            std::string::size_type subOnPos    = this->find_word(lineStr, "on", aliasPos);
                            std::string::size_type subWherePos = this->find_word(lineStr, "where", aliasPos);

                            if (subOnPos != std::string::npos && subOnPos < subWherePos)
                            {
                                whereClauseAddStream << " and ";
                                lineStr.replace(subOnPos + 3, 0, whereClauseAddStream.str());
                            }
                            else if (subWherePos != std::string::npos)
                            {
                                whereClauseAddStream << " and ";
                                lineStr.replace(subWherePos + 6, 0, whereClauseAddStream.str());
                            }
                            else
                            {
                                lineStr.replace(endPos, 0, " where " + whereClauseAddStream.str());
                            }

                            endPos += meEndPos;
                        }
                        else
                        {
                            std::stringstream msg;
                            msg << "Multi-entity patch failed: Unknown entity search \"" << it->first << "\"";
                            this->printMsg(RET_GEN_ERR_INVARG, msg.str());
                        }
                    }
                }
            }

            for (auto it = toReplaceMap.begin(); it != toReplaceMap.end(); it++)
            {
                if (it->first.compare(it->second) != 0)
                {
                    std::string::size_type replacePos = fromPos;
                    while ((replacePos = this->find_word(lineStr, it->first, replacePos, endPos)) != std::string::npos)
                    {
                        lineStr.replace(replacePos, it->first.length(), it->second);
                        replacePos += it->second.length();
                        if (endPos != std::string::npos)
                        {
                            endPos += it->second.length() - it->first.length();
                        }
                    }

                    bUpdated = true;
                }
            }
        }

        selPos = this->find_word(lineStr, "select", endPos);
    }

    return bUpdated;
}

/************************************************************************
**
**  Function    :   DdlGen::printNatureAttribClause()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45027 - LJE - 210521
**
*************************************************************************/
void DdlGen::printNatureAttribClause(DICT_ATTRIB_STP   natAttribStp)
{
    std::stringstream  nonePermValueStream;
    std::stringstream  allPermValueStream;

    allPermValueStream << "(@" << natAttribStp->sqlName << " = ";
    if (natAttribStp->isPhysicalAttribute())
    {
        allPermValueStream << this->getAlias() << natAttribStp->sqlName;
    }
    else /* PMSTA-34445 - LJE - 190325 */
    {
        for (auto it = this->selectList.begin(); it != this->selectList.end(); ++it)
        {
            if (it->sqlName.compare(natAttribStp->sqlName) == 0)
            {
                allPermValueStream << this->getAlias() << it->value;
            }
        }
    }

    for (auto permValIt = natAttribStp->permValMap.begin(); permValIt != natAttribStp->permValMap.end(); ++permValIt)
    {
        if (permValIt->second.permValRuleEn == PermValRule_All)
        {
            allPermValueStream << " or @" << natAttribStp->sqlName << " = " << CAST_INT(permValIt->second.permVal);
        }
        else if (permValIt->second.permValRuleEn == PermValRule_None)
        {
            nonePermValueStream << " and @" << natAttribStp->sqlName << " <> " << CAST_INT(permValIt->second.permVal);
        }
    }
    allPermValueStream << ")";

    this->whereStream << this->getWhereOrAnd() << allPermValueStream.str() << nonePermValueStream.str() << ")";
}

/************************************************************************
**
**  Function    :   DdlGen::printWhereRequest()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGen::printWhereRequest()
{
    RET_CODE          ret = RET_SUCCEED;
    DICT_ENTITY_STP   locDictEntityStp = this->m_dictEntityStp;
    std::string            parentAlias;

    if (this->m_ddlGenFromFileContextPtr != nullptr &&
        this->m_ddlGenFromFileContextPtr->parentContextPtr != nullptr &&
        this->m_ddlGenFromFileContextPtr->parentContextPtr->currDdlGen != nullptr)
    {
        parentAlias = this->m_ddlGenFromFileContextPtr->parentContextPtr->currDdlGen->getAlias();
    }

    if (this->realObjectEn != NullEntity && this->realDictEntityStp)
    {
        locDictEntityStp = this->realDictEntityStp;
    }

    std::set<std::string>  pkMappedSet;
    std::set<std::string>  bkMappedSet;

    this->bPkWhereAccess = false;
    this->bBkWhereAccess = false;

    if (this->whereStream.str().empty() == false)
    {
        this->m_bWherePrinted = true;
    }
    bool bWherePrinted = this->m_bWherePrinted;

    /* PMSTA-26108 - LJE - 170905 : View_MultiEntitySpec */
    if (this->mulitEntityAccessEn == MultiEntityAccess_OptionalLocalization)
    {
        if (locDictEntityStp->ownerBusinessEntAttrStp != nullptr)
        {
            std::string chkAlias = this->getAlias(true) + "_me";

            this->whereStream << this->getWhereOrAnd() << "("
                << this->getCmdIsNull() << "(" << this->getConnBusinessEntityId() << ", 0)"
                << " <> " << this->ddlGenContextPtr->getMasterBusinessEntityId()
                << this->newLine() << " and "
                << "not exists (select '1' from " << this->getEntityFullSqlName(locDictEntityStp) << " " << chkAlias << " where (("
                << chkAlias << "." << locDictEntityStp->ownerBusinessEntAttrStp->sqlName << " = " << this->getConnBusinessEntityId() << ")";

            for (auto& dictAttribStp : locDictEntityStp->attr)
            {
                if (dictAttribStp->precompFlg == FALSE &&
                    dictAttribStp->custFlg == FALSE &&
                    dictAttribStp->meSpecialisationEn == MeSpecialisation_Key)
                {
                    this->whereStream << this->getWhereOrAnd()
                        << this->getWhereComp(
                            this->getAlias() + dictAttribStp->sqlName,
                            dictAttribStp,
                            chkAlias + "." + dictAttribStp->sqlName,
                            dictAttribStp,
                            "=",
                            false) << ")";
                }
            }

            this->whereStream << "))))";
        }
        else
        {
            std::stringstream msg;
            msg << "Unsupported multi-entity specialized entity: " << locDictEntityStp->mdSqlName << " (no multi-entity attribute)";
            this->printMsg(RET_GEN_ERR_INVARG, msg.str());
        }
    }
    else if (this->bShadowAccess)
    {
        DICT_ATTRIB_STP  mandAttribStp = nullptr;
        DICT_ATTRIB_STP *attribTab = locDictEntityStp->primKeyTab;
        int              attribNbr = locDictEntityStp->primKeyNbr;

        if (attribNbr == 0)
        {
            attribTab = locDictEntityStp->bkAttr;
            attribNbr = locDictEntityStp->bkAttrNbr;
        }

        /* Search mandatory attribute on primary/business key */
        for (int i = 0; i < attribNbr; i++)
        {
            if (attribTab[i]->dbMandatoryFlg == TRUE)
            {
                mandAttribStp = attribTab[i];
                break;
            }
        }

        if (mandAttribStp == nullptr)
        {
            /* Search mandatory attribute on all attributes */
            for (auto& dictAttribStp : locDictEntityStp->attr)
            {
                if (dictAttribStp->precompFlg == FALSE &&
                    dictAttribStp->custFlg == FALSE &&
                    dictAttribStp->dbMandatoryFlg == TRUE)
                {
                    mandAttribStp = dictAttribStp;
                    break;
                }
            }
        }

        if (mandAttribStp)
        {
            this->whereStream << this->getWhereOrAnd() 
                << DdlGenDbi::getCmdIsNull() << "(sh." << mandAttribStp->sqlName << ", " << this->getAlias() << mandAttribStp->sqlName
                << ") is not null )"
                << "and (" << DdlGenDbi::getCmdIsNull() << "(sh.sh_action_e, 0) != 3) /* ToDelete */";
        }
        else
        {
            std::stringstream msg;
            msg << "Unsupported shadow entity :" << locDictEntityStp->mdSqlName << " (no mandatory attribute)";
            this->printMsg(RET_GEN_ERR_INVARG, msg.str());
        }
    }

    /* Put customize join table in the where clause */
    /* and custom where clause */
    if (this->overloadStream.str().empty() == false)
    {
        std::string lineStr, readLineStr;
        int iOpen = 0, iClose = 0;
        std::string::size_type pos = 0;
        MemoryPool        mp;

        this->overloadStream.clear();
        this->overloadStream.seekg(0, std::ios::beg);
        while (getline(this->overloadStream, readLineStr))
        {
            pos = 0;
            while ((pos = this->find_first_of(readLineStr, "(", pos)) != std::string::npos)
            {
                this->setIndent(1);
                iOpen++;
                pos++;
            }
            pos = 0;
            while ((pos = this->find_first_of(readLineStr, ")", pos)) != std::string::npos)
            {
                this->setIndent(-1);
                iClose++;
                pos++;
            }

            lineStr += readLineStr;

            if (iOpen == iClose)
            {
                std::string subLineStr = lineStr, newLineStr;
                if (iOpen)
                {
                    this->extractAndFixDependsEntity(lineStr);
                }

                pos = 0;
                iOpen = 0;
                iClose = 0;

                while (subLineStr.empty() == false)
                {
                    std::string leftStr, rightStr, operStr, sepStr, tempStr;

                    while (subLineStr[0] == '(')
                    {
                        newLineStr += subLineStr[0];
                        pos = this->find_first_not_of(subLineStr, " \t\n", 1);
                        if (pos == std::string::npos)
                        {
                            newLineStr.clear();
                            break;
                        }

                        subLineStr = subLineStr.substr(pos);
                    }

                    pos = this->find_first_of(subLineStr, " \t<>=\n");
                    if (pos == std::string::npos)
                    {
                        int              keyNbr = 0;
                        DICT_ATTRIB_STP *keyTab = NULL;

                        if (subLineStr.compare("bk") == 0)
                        {
                            this->bBkWhereAccess = true;
                            keyNbr = locDictEntityStp->bkAttrNbr;
                            keyTab = locDictEntityStp->bkAttr;
                        }
                        else if (subLineStr.compare("pk") == 0)
                        {
                            if (this->targetTableEn == TargetTable_UserDefinedFields &&
                                locDictEntityStp->udPKNbr > 0)
                            {
                                this->bPkWhereAccess = true;
                                keyNbr = locDictEntityStp->udPKNbr;
                                keyTab = locDictEntityStp->udPKTab;
                            }
                            else
                            {
                                this->bPkWhereAccess = true;
                                keyNbr = locDictEntityStp->dbPKNbr;
                                keyTab = locDictEntityStp->dbPKTab;
                            }
                        }
                        else if (subLineStr.compare("db_bk") == 0)
                        {
                            keyNbr = locDictEntityStp->dbBKNbr;
                            keyTab = locDictEntityStp->dbBKTab;
                        }
                        else if (subLineStr.compare("log_pk") == 0)
                        {
                            keyNbr = locDictEntityStp->primKeyNbr;
                            keyTab = locDictEntityStp->primKeyTab;
                        }
                        else if (subLineStr.compare("unique") == 0) /* PMSTA-26250 - LJE - 170412 */
                        {
                            if (this->targetTableEn == TargetTable_UserDefinedFields &&
                                locDictEntityStp->udPKNbr > 0)
                            {
                                this->bPkWhereAccess = true;
                                keyNbr = locDictEntityStp->udPKNbr;
                                keyTab = locDictEntityStp->udPKTab;
                            }
                            else if (locDictEntityStp->dbPKNbr)
                            {
                                this->bPkWhereAccess = true;
                                keyNbr = locDictEntityStp->dbPKNbr;
                                keyTab = locDictEntityStp->dbPKTab;
                            }
                            else if (locDictEntityStp->bkAttrNbr)
                            {
                                this->bBkWhereAccess = true;
                                keyNbr = locDictEntityStp->bkAttrNbr;
                                keyTab = locDictEntityStp->bkAttr;
                            }
                        }
                        else if (subLineStr.compare("param") == 0) /* PMSTA-26108 - LJE - 171106 */
                        {
                            if (this->varHelperPtr->getParamNbr() > 0)
                            {
                                keyTab = static_cast<DICT_ATTRIB_STP *>(mp.calloc(FILEINFO, this->varHelperPtr->getParamNbr(), sizeof(DICT_ATTRIB_STP)));
                                keyNbr = 0;
                                for (auto it = this->varHelperPtr->getParamList()->begin(); it != this->varHelperPtr->getParamList()->end(); ++it)
                                {
                                    if ((keyTab[keyNbr] = locDictEntityStp->getDictAttribBySqlName((*it)->sqlName)) != nullptr)
                                    {
                                        keyNbr++;
                                    }
                                }
                            }
                        }
                        else if (subLineStr.compare("full") == 0) /* PMSTA-26250 - LJE - 170331 */
                        {
                            lineStr.clear();
                        }
                        else if (subLineStr.compare("parent") == 0) /* PMSTA-26250 - LJE - 170331 */
                        {
                            /* PMSTA-45027 - LJE - 210521 */
                            if (locDictEntityStp->isNullNatIndex == false &&
                                (locDictEntityStp->tpNatEn == Typing || locDictEntityStp->tpNatEn == SubTyping))
                            {
                                keyNbr = 2;
                                keyTab = static_cast<DICT_ATTRIB_STP *>(mp.calloc(FILEINFO, keyNbr, sizeof(DICT_ATTRIB_STP)));
                                keyTab[0] = locDictEntityStp->parentAttrStp;
                                keyTab[1] = locDictEntityStp->attr[locDictEntityStp->natIndex];
                            }
                            else
                            {
                                keyTab = &(locDictEntityStp->parentAttrStp);
                                keyNbr = 1;
                            }
                        }
                        newLineStr.clear();

                        if (keyNbr > 0)
                        {
                            lineStr.clear();

                            std::string eqAlias;

                            if (parentAlias.empty())
                            {
                                if (this->ddlGenContextPtr->dmlEventEn == DmlEvent_Insert ||
                                    this->ddlGenContextPtr->dmlEventEn == DmlEvent_Update)
                                {
                                    eqAlias = "#NEW.";
                                }
                                else if (this->ddlGenContextPtr->dmlEventEn == DmlEvent_Delete)
                                {
                                    eqAlias = "#OLD.";
                                }
                            }
                            else
                            {
                                eqAlias = parentAlias;
                            }

                            for (int i = 0; i < keyNbr; i++)
                            {
                                std::string eqName;
                                if (eqAlias.empty())
                                {
                                    DdlGenVar *var;
                                    if (this->targetTableEn == TargetTable_UserDefinedFields && locDictEntityStp->udPKNbr == 0)  /* PMSTA-32145 - LJE - 180721 - Partial specialization special case */
                                    {
                                        var = this->varHelperPtr->getVariable(DdlGen::getUdIdSqlName(), (keyTab[i]->featureEn != XdEntityFeatureFeatureEn::MultiBusinessEntityManagement));
                                    }
                                    else
                                    {
                                        var = this->varHelperPtr->getVariable(keyTab[i]->sqlName, false);

                                        if (var == nullptr)
                                        {
                                            var = this->varHelperPtr->getVariable(DdlGen::getUdIdSqlName(), false);
                                        }

                                        if (var == nullptr)
                                        {
                                            var = this->varHelperPtr->getVariable(keyTab[i]->sqlName, (keyTab[i]->featureEn != XdEntityFeatureFeatureEn::MultiBusinessEntityManagement));
                                        }
                                    }

                                    if (var)
                                    {
                                        /* PMSTA-45027 - LJE - 210521 */
                                        if (locDictEntityStp->isNullNatIndex == false &&
                                            locDictEntityStp->natIndex == keyTab[i]->progN)
                                        {
                                            this->printNatureAttribClause(locDictEntityStp->attr[locDictEntityStp->natIndex]);
                                        }
                                        else
                                        {
                                            eqName = var->printSqlName();
                                        }
                                    }
                                }
                                else
                                {
                                    eqName = eqAlias + keyTab[i]->sqlName;
                                }

                                if (eqName.empty() && this->getDdlObjEn() == DdlObj_RuntimeSql)
                                {
                                    eqName = '?';
                                    this->ddlGenContextPtr->m_inputVariableVector.push_back(DbiInputParam(keyTab[i]->sqlName, keyTab[i]->dataTpProgN));
                                }

                                if (eqName.empty() == false)
                                {
                                    std::string attrAlias(this->getAlias());

                                    /* PMSTA-43367 - LJE - 210427 - Manage denormalized attributes */
                                    if (keyTab[i]->calcEn == DictAttr_Denorm)
                                    {
                                        for (auto criterIt = this->infoCriterMap->begin(); criterIt != this->infoCriterMap->end(); ++criterIt)
                                        {
                                            if (strcmp(criterIt->second->sqlName, keyTab[i]->sqlName) == 0)
                                            {
                                                attrAlias = criterIt->second->joinSqlName;
                                                break;
                                            }
                                        }
                                    }

                                    this->whereStream << this->getWhereOrAnd()
                                        << this->getWhereComp(attrAlias + keyTab[i]->sqlName, keyTab[i], eqName, keyTab[i], "=", false) << ")";
                                }
                            }
                        }
                        else if (subLineStr.compare("nature") == 0) /* PMSTA-26108 - LJE - 170811 */
                        {
                            this->printNatureAttribClause(locDictEntityStp->attr[locDictEntityStp->natIndex]);

                            lineStr.clear();
                        }

                        break;
                    }

                    leftStr = subLineStr.substr(0, pos);
                    subLineStr = subLineStr.substr(pos);
                    pos = this->find_first_not_of(subLineStr, " \t\n");
                    if (pos == std::string::npos)
                    {
                        newLineStr.clear();
                        break;
                    }
                    subLineStr = subLineStr.substr(pos);

                    pos = this->find_first_of(subLineStr, "<>=");
                    if (pos != 0)
                    {
                        if (strcasecmp(subLineStr.c_str(), "is null") == 0 ||
                            strcasecmp(subLineStr.c_str(), "is not null") == 0)
                        {
                            operStr = subLineStr;
                        }
                        else
                        {
                            newLineStr.clear();
                            break;
                        }
                    }

                    if (operStr.empty())
                    {
                        pos = this->find_first_not_of(subLineStr, "<>=");
                        if (pos == std::string::npos)
                        {
                            newLineStr.clear();
                            break;
                        }

                        operStr = subLineStr.substr(0, pos);
                        subLineStr = subLineStr.substr(operStr.size());
                        pos = this->find_first_not_of(subLineStr, " \t\n)");
                        if (pos == std::string::npos)
                        {
                            newLineStr.clear();
                            break;
                        }
                        subLineStr = subLineStr.substr(pos);

                        pos = this->find_first_of(subLineStr, " \t\n)");
                        rightStr = subLineStr.substr(0, pos);
                        if (rightStr.find("(") != std::string::npos)
                        {
                            pos++;
                            rightStr += ")";
                        }
                        tempStr = rightStr;
                        if (upper(tempStr).compare("NULL") == 0)
                        {
                            std::stringstream msg;
                            msg << "Unsupported \" = NULL \" where line: " << lineStr;
                            this->printMsg(RET_GEN_ERR_INVARG, msg.str());
                        }
                    }

                    std::string leftAlias, rightAlias;
                    DICT_ATTRIB_STP leftDictAttribStp = this->getDictAttribOnRequest(leftStr, leftAlias);
                    DICT_ATTRIB_STP rightDictAttribStp = this->getDictAttribOnRequest(rightStr, rightAlias);

                    bool bForceNotNull = false;
                    if (this->m_ddlGenFromFileContextPtr->m_paramVectorVector.empty() == false &&
                        this->m_ddlGenFromFileContextPtr->m_paramVectorVector.back().empty() == false)
                    {
                        if (leftStr == "?" || rightStr == "?")
                        {
                            bForceNotNull = (this->m_ddlGenFromFileContextPtr->m_paramVectorVector.back()[0]->isNull() == false);
                            this->m_ddlGenFromFileContextPtr->m_paramVectorVector.back().erase(this->m_ddlGenFromFileContextPtr->m_paramVectorVector.back().begin());

                        }
                        else if (leftStr.find("?") == 0 || rightStr.find("?") == 0)
                        {
                            std::string paramPos;
                            if (leftStr.find("?") == 0)
                            {
                                paramPos = leftStr.substr(1);
                            }
                            else
                            {
                                paramPos = rightStr.substr(1);
                            }

                            auto parmPos = std::stoi(paramPos);
                            bForceNotNull = (this->m_ddlGenFromFileContextPtr->m_paramVectorVector.back()[parmPos]->isNull() == false);
                        }
                    }

                    newLineStr.append(this->getWhereComp(leftStr,
                                                         leftDictAttribStp,
                                                         rightStr,
                                                         rightDictAttribStp,
                                                         operStr,
                                                         bForceNotNull));

                    /* PMSTA-26108 - LJE - 171103 */
                    if (operStr.compare("=") == 0)
                    {
                        if (leftDictAttribStp)
                        {
                            if (locDictEntityStp->isPrimaryKey(leftStr))
                            {
                                pkMappedSet.insert(leftStr);
                            }
                            if (locDictEntityStp->isBusinessKey(leftStr))
                            {
                                bkMappedSet.insert(leftStr);
                            }
                        }
                        if (rightDictAttribStp)
                        {
                            if (locDictEntityStp->isPrimaryKey(rightStr))
                            {
                                pkMappedSet.insert(rightStr);
                            }
                            if (locDictEntityStp->isBusinessKey(rightStr))
                            {
                                bkMappedSet.insert(rightStr);
                            }
                        }
                    }

                    if (pos == std::string::npos || subLineStr.size() <= pos)
                    {
                        break;
                    }
                    subLineStr = subLineStr.substr(pos);

                    while (subLineStr[0] == ')' ||
                           subLineStr[0] == ' ' ||
                           subLineStr[0] == '\t' ||
                           subLineStr[0] == '\n')
                    {
                        newLineStr += subLineStr[0];
                        subLineStr = subLineStr.substr(1);

                        if (subLineStr.empty())
                        {
                            break;
                        }
                    }

                    sepStr.clear();
                    if (subLineStr.empty())
                    {
                        break;
                    }

                    if (subLineStr[0] == 'o' ||
                        subLineStr[0] == 'O')
                    {
                        sepStr = "or";
                    }
                    else if (subLineStr[0] == 'a' ||
                             subLineStr[0] == 'A')
                    {
                        sepStr = "and";
                    }

                    if (sepStr.empty() == false)
                    {
                        newLineStr.append(" " + sepStr + " ");
                        subLineStr = subLineStr.substr(sepStr.size());

                        pos = this->find_first_not_of(subLineStr, " \t\n");
                        if (pos == std::string::npos)
                        {
                            newLineStr.clear();
                            break;
                        }

                        subLineStr = subLineStr.substr(pos);
                    }

                    if (subLineStr.find("--") == 0)
                    {
                        pos = subLineStr.find("\n");
                        if (pos != std::string::npos)
                        {
                            newLineStr.append(" " + subLineStr.substr(0, pos));
                            subLineStr = subLineStr.substr(pos);
                        }
                        else
                        {
                            newLineStr.append(" " + subLineStr);
                            break;
                        }
                    }

                    while (subLineStr.find("/*") == 0)
                    {
                        if ((pos = subLineStr.find("*/")) != std::string::npos)
                        {
                            newLineStr.append(" " + subLineStr.substr(0, pos + 2));
                            subLineStr = subLineStr.substr(pos + 2);

                            if ((pos = this->find_first_not_of(subLineStr, " \t\n")) == std::string::npos)
                            {
                                subLineStr.clear();
                            }
                            else
                            {
                                subLineStr = subLineStr.substr(pos);
                            }
                        }
                        else
                        {
                            newLineStr.append(" " + subLineStr);
                            break;
                        }
                    }
                }

                if (newLineStr.empty() == false)
                {
                    lineStr = newLineStr;
                }

                while ((pos = lineStr.find("&")) != std::string::npos)
                {
                    std::string::size_type posEnd = this->find_first_of(lineStr, " \t", pos);
                    if (posEnd == std::string::npos)
                    {
                        posEnd = lineStr.size();
                    }
                    std::string locName = lineStr.substr(pos + 1, posEnd - pos - 1);

                    if (this->infoCriterMap)
                    {
                        auto criterIt = this->infoCriterMap->begin();
                        for (; criterIt != this->infoCriterMap->end(); ++criterIt)
                        {
                            DICT_CRITER_STP dictCriterStp = criterIt->second;

                            if (dictCriterStp->attrPtr != NULL &&
                                locName.compare(dictCriterStp->sqlName) == 0)
                            {
                                std::stringstream newNameStream;
                                newNameStream << dictCriterStp->joinSqlName << dictCriterStp->attrPtr->sqlName;
                                lineStr.replace(pos, posEnd - pos, newNameStream.str());
                                break;
                            }
                        }

                        if (criterIt == this->infoCriterMap->end())
                        {
                            std::stringstream msg;
                            msg << "Unknown attribute referenced by & (entity: " << this->m_dictEntityStp->mdSqlName << ", attr: " << locName;
                            this->printMsg(RET_GEN_ERR_INVARG, msg.str());
                            lineStr.erase(pos, 1);
                        }
                    }
                }

                if (lineStr.empty() == false)
                {
                    size_t commentPos = this->find_word(lineStr, "--");
                    if (commentPos != std::string::npos)
                    {
                        lineStr.replace(commentPos - 1, 0, ")");
                    }
                    else
                    {
                        lineStr += ")";
                    }
                    this->whereStream << this->getWhereOrAnd() << lineStr;
                    lineStr.clear();
                }
            }
            else
            {
                lineStr += this->newLine();
            }
        }

        if (iOpen != iClose)
        {
            ret = RET_GEN_ERR_INVARG;
            this->printMsg(ret, "Unmatched brackets \"(\" with \")\" in the where clause !");
        }
    }

    if (locDictEntityStp->primKeyNbr &&
        (int)pkMappedSet.size() == locDictEntityStp->primKeyNbr)
    {
        this->bPkWhereAccess = true;
    }
    if (locDictEntityStp->bkAttrNbr &&
        (int)bkMappedSet.size() == locDictEntityStp->bkAttrNbr)
    {
        this->bBkWhereAccess = true;
    }

    /* PMSTA-nuodb - LJE - 190705 */
    this->printMultiEntityManagement(locDictEntityStp, this->getAlias(), true, true, this->whereStream);

    if (this->ddlGenContextPtr->bSecurityDone == false) /* PMSTA-43626 - LJE - 210311 */
    {
        this->printSecurityOnWhere(this->securityLevelEn,
                                   this->isSecuredLevel(this->securityLevelEn),
                                   this->getAlias(),
                                   this->whereStream);
    }

    if (this->thirdCompoSecuredFlg == FALSE && this->thirdSecuredFlg == TRUE)
    {
        if (this->getObjectEn() == Third)
        {
            this->whereStream << this->getWhereOrAnd() << getAlias() << "id";
            this->whereStream << " = " << DdlGenDbi::getCmdThirdPartyId() << ")";
        }
        else
        {
            if (DBA_GetAttributeBySqlName(this->getObjectEn(), "third_id") != NULL)
            {
                this->whereStream << this->getWhereOrAnd() << getAlias() << "third_id";
                this->whereStream << " = " << DdlGenDbi::getCmdThirdPartyId() << ")";
            }
            else if (DBA_GetAttributeBySqlName(this->getObjectEn(), "portfolio_id") != NULL)
            {
                this->whereStream << this->getWhereOrAnd() << this->getAlias() << "portfolio_id is null )" << this->newLine() <<
                    "or exists (select 'x' from " << this->getEntityFullSqlName("portfolio") << "_tvw p where p.id = " << this->getAlias() << "portfolio_id and "
                    " (p.third_id = " << DdlGenDbi::getCmdThirdPartyId() << this->newLine() <<
                    "or exists (select 'x' from " << this->getEntityFullSqlName("portfolio_third_compo") << " ptc, " << this->getEntityFullSqlName("portfolio") << "_tvw p where p.id = ptc.portfolio_id and "
                    " ptc.third_id = " << DdlGenDbi::getCmdThirdPartyId() <<
                    " and " << this->getAlias() << "portfolio_id = ptc.portfolio_id))))";
            }
        }
    }

    if (bWherePrinted == false && this->m_bWherePrinted)
    {
        size_t commentPos = this->find_word(this->whereStream.str(), "--");
        if (commentPos != std::string::npos)
        {
            std::string whereStr = this->whereStream.str();
            whereStr.replace(commentPos - 1, 0, ")");

            this->whereStream.clear();
            this->whereStream.str(whereStr);
        }
        else
        {
            this->whereStream << ")";
        }
    }

    this->printRowLimitOnWhere(this->limitStream);

    if (this->ddlGenContextPtr->m_rdbmsEn == PostgreSQL &&
        this->bUserJoinPrint)
    {
        std::string mainFromStr = this->m_mainFromStream.str();
        auto fromPos = mainFromStr.find(this->getCmdFrom());
        if (fromPos != std::string::npos)
        {
            mainFromStr.replace(fromPos + this->getCmdFrom().size(), 0, "(");
        }
        this->m_mainFromStream.clear();
        this->m_mainFromStream.str(mainFromStr);
    }


    return ret;
}

/************************************************************************
**
**  Function    :   DdlGen::build()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGen::build()
{
    if (this->m_dictEntityStp == NULL ||
        this->m_dictEntityStp->objectEn == InvalidEntity)
    {
        return RET_GEN_ERR_INVARG;
    }

    this->setDefaultContext();

    return RET_SUCCEED;
}

/************************************************************************
**
**  Function    :   DdlGen::printHeader()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14452 - LJE - 130114
**
**  Modif       :
**
*************************************************************************/
RET_CODE DdlGen::printHeader()
{
    RET_CODE          ret = RET_SUCCEED;

    this->headerStream << std::endl << this->getGenInfo(true); /* PMSTA-14452-EFE-130208*/

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGen::printFooter()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14452 - LJE - 130114
**
**  Modif       :
**
*************************************************************************/
RET_CODE DdlGen::printFooter()
{
    RET_CODE          ret = RET_SUCCEED;

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGen::getDictAttribOnRequest()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
DICT_ATTRIB_STP DdlGen::getDictAttribOnRequest(std::string &paramAttribStr, std::string &paramAlias)
{
    if (paramAttribStr.empty())
    {
        return nullptr;
    }

    DICT_ATTRIB_STP locDictAttribStp = nullptr;
    std::string::size_type pos, fctPos;
    OBJECT_ENUM       locObjectEn = this->realObjectEn != NullEntity ? this->realObjectEn : this->objectEn;
    std::string            attribStr(paramAttribStr);
    bool              bUpdateAttrib = true;

    trim(attribStr);

    paramAlias.clear();

    if ((pos = attribStr.find(".")) != std::string::npos &&
        ((fctPos = this->find_first_of(attribStr, "(")) == std::string::npos ||
         fctPos > pos))
    {
        paramAlias = attribStr.substr(0, pos);
        std::string attrib = attribStr.substr(pos + 1);

        if (paramAlias.compare(this->getNewAlias()) == 0 ||
            paramAlias.compare(this->getOldAlias()) == 0)
        {
            if (this->ddlGenEntityPtr != NULL)
            {
                locObjectEn = this->ddlGenEntityPtr->getDictEntityStp()->objectEn;
            }
        }

        if (paramAlias.compare(this->getAlias(true)) == 0 ||
            paramAlias.compare(this->getNewAlias()) == 0 ||
            paramAlias.compare(this->getOldAlias()) == 0)
        {
            locDictAttribStp = DBA_GetAttributeBySqlName(locObjectEn, attrib.c_str(), TRUE);
        }
        else
        {
            if (this->joinTab.size() > 0)
            {
                for (std::vector<DdlGenJoin>::iterator joinInfo = this->joinTab.begin(); joinInfo != this->joinTab.end(); joinInfo++)
                {
                    if (joinInfo->joinDictEntityStp != nullptr &&
                        joinInfo->joinSqlName.compare(paramAlias + ".") == 0)
                    {
                        locDictAttribStp = DBA_GetAttributeBySqlName(joinInfo->joinDictEntityStp->objectEn, attrib.c_str(), TRUE);
                    }
                }
            }
            if (locDictAttribStp == nullptr && this->addedJoinTab.size() > 0)
            {
                for (std::vector<DdlGenJoin>::iterator joinInfo = this->addedJoinTab.begin(); joinInfo != this->addedJoinTab.end(); joinInfo++)
                {
                    if (joinInfo->joinDictEntityStp != nullptr &&
                        joinInfo->joinSqlName.compare(paramAlias + ".") == 0)
                    {
                        locDictAttribStp = DBA_GetAttributeBySqlName(joinInfo->joinDictEntityStp->objectEn, attrib.c_str(), TRUE);
                    }
                }
            }
        }

    }
    else if (this->find_first_of(attribStr, " \t\n(@+-/*'") == std::string::npos)
    {
        locDictAttribStp = DBA_GetAttributeBySqlName(locObjectEn, attribStr.c_str(), TRUE);
    }
    else if (attribStr.find(this->getNewPrefix()) == 0 ||
             attribStr.find(this->getOldPrefix()) == 0)
    {
        bUpdateAttrib = false;
        paramAlias = "@";
        if (this->ddlGenEntityPtr != NULL)
        {
            locObjectEn = this->ddlGenEntityPtr->getDictEntityStp()->objectEn;
        }
        locDictAttribStp = DBA_GetAttributeBySqlName(locObjectEn, attribStr.substr(3).c_str(), TRUE);

    }
    else if ((attribStr.find("t_i_") == 0 || attribStr.find("t_d_") == 0) &&
        (pos = attribStr.find("(")) != std::string::npos)

    {
        bUpdateAttrib = false;
        if (this->ddlGenEntityPtr != NULL)
        {
            locObjectEn = this->ddlGenEntityPtr->getDictEntityStp()->objectEn;
        }
        locDictAttribStp = DBA_GetAttributeBySqlName(locObjectEn, attribStr.substr(4, pos - 4).c_str(), TRUE);
    }

    if (bUpdateAttrib && locDictAttribStp && paramAlias.empty() && this->getAlias().empty() == false)
    {
        paramAlias = this->getAlias(true);
        paramAttribStr = this->getAlias() + attribStr;
    }

    return locDictAttribStp;
}

/************************************************************************
**
**  Function    :   DdlGen::setObjectEn()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
void DdlGen::setObjectEn(OBJECT_ENUM locObjectEn)
{
    char *tableName;

    if (this->objectEn != locObjectEn)
    {
        this->objectEn = locObjectEn;

        this->m_dictEntityStp = &invalidDictEntitySt;
        if (this->objectEn == NullEntity)
        {
            return;
        }
        else if (this->objectEn > LASTENTITYOBJECT)
        {
            std::stringstream locStream;
            locStream << "Invalid Object enum " << this->objectEn;
            this->printMsg(RET_DBA_ERR_INVDATA, locStream.str());
            return;
        }

        this->m_dictEntityStp = DBA_GetDictEntitySt(this->objectEn);

        if (this->m_dictEntityStp != NULL)
        {
            if (this->m_dictEntityStp->entNatEn == EntityNat_TempTable)
            {
                this->setDdlObjFullSqlName(this->m_dictEntityStp->databaseName, 
                                           this->getEntityDbSqlName(this->m_dictEntityStp, this->m_dictEntityStp->mdSqlName));
            }
            else
            {
                this->setDdlObjFullSqlName(this->m_dictEntityStp->databaseName, this->getEntitySqlName());
            }
            this->setMsgSqlName(this->m_dictEntityStp->mdSqlName);
            this->setMsgEntitySqlName(this->m_dictEntityStp->mdSqlName);

            tableName = this->m_dictEntityStp->custSqlName;
            if (tableName != NULL)
            {
                this->udTableName = tableName;
            }
            else if (!this->udTableName.empty())
            {
                this->udTableName = std::string();
            }

            if (this->custFlg == TRUE &&
                (this->m_dictEntityStp->custAuthFlg == FALSE || this->udTableName.empty()))
            {
                this->custFlg = FALSE;
            }

            if (this->precompFlg == TRUE &&
                (this->m_dictEntityStp->precompFlg == FALSE ||
                 this->m_dictEntityStp->usePrecompFlg == FALSE ||
                 this->m_dictEntityStp->precompSqlName[0] == 0))
            {
                this->precompFlg = FALSE;
            }

            this->setDdlObjEn(this->getDdlObjEn());
        }
        else
        {
            this->m_dictEntityStp = &invalidDictEntitySt;
        }
    }
}

/************************************************************************
**
**  Function    :   DdlGen::getObjectEn()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
OBJECT_ENUM DdlGen::getObjectEn() const
{
    return this->objectEn;
}

/************************************************************************
**
**  Function    :   DdlGen::setDdlObjEn()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
void DdlGen::setDdlObjEn(DDL_OBJ_ENUM paramDdlObjEn)
{
    if (paramDdlObjEn == DdlObj_Index &&
        this->m_dictEntityStp != NULL &&
        this->m_dictEntityStp->entNatEn == EntityNat_TempTable)
    {
        paramDdlObjEn = DdlObj_TempTableIndex;
    }
    else if (paramDdlObjEn == DdlObj_Table &&
             this->m_dictEntityStp != NULL &&
             this->m_dictEntityStp->entNatEn == EntityNat_TempTable)
    {
        paramDdlObjEn = DdlObj_TempTable;
    }

    DdlGenMsg::setDdlObjEn(paramDdlObjEn);

    this->m_ddlObjBaseName = this->m_dictEntityStp->mdSqlName;

    switch (this->getDdlObjEn())
    {
        case DdlObj_Func:
        case DdlObj_SProc:
        case DdlObj_SpecSProc:
            if (this->m_dictEntityStp->shortSqlname[0] != 0)
            {
                this->m_ddlObjBaseName = this->m_dictEntityStp->shortSqlname;
            }
        case DdlObj_None:
        case DdlObj_TriggerBody:
            break;

        case DdlObj_View:
            this->m_ddlObjBaseName = DdlGenView::getBaseSqlName(this->m_dictEntityStp);
            if (this->ddlGenContextPtr != NULL)
            {
                this->ddlGenContextPtr->setDefDdlDestDbName();
            }
            break;

        case DdlObj_Sql:
        case DdlObj_RuntimeSql:
            break;

        case DdlObj_Index:
        case DdlObj_TempTableIndex:
        case DdlObj_Table:
        case DdlObj_TempTable:
        case DdlObj_Trigger:
        case DdlObj_PrimaryKey:
        case DdlObj_Constraint:
        case DdlObj_ForeignKey:
            if (this->ddlGenContextPtr != NULL)
            {
                this->ddlGenContextPtr->setDefDdlDestDbName(this->targetTableEn == TargetTable_Precomp ? this->m_dictEntityStp->precompDbName : this->m_dictEntityStp->databaseName);
            }
            break;

        default:
            break;
    }
}

/************************************************************************
**
**  Function    :   DdlGen::getDictEntityStp()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 111124
**
*************************************************************************/
DICT_ENTITY_STP DdlGen::getDictEntityStp(bool bSource)
{
#ifdef AAADEBUGMSG
    if (this->m_dictEntityStp->objectEn == InvalidEntity)
    {
        SYS_BreakOnDebug();
    }
#endif

    if (bSource && EV_UseAlternativeDataSource)
    {
        if (this->m_srcDictEntityStp == nullptr)
        {
            this->m_srcDictEntityStp = DBA_GetEntityBySqlName(this->m_dictEntityStp->mdSqlName, true, true);

            if (this->m_srcDictEntityStp == nullptr)
            {
                std::string altSqlName;
                if (this->m_dictEntityStp->linkedEntityStp != nullptr)
                {
                    altSqlName = this->m_dictEntityStp->linkedEntityStp->mdSqlName;
                }

                bool  bForceTarget = false;
                this->m_srcDictEntityStp = this->buildDictEntityFromSys(this->m_dictEntityStp->mdSqlName, altSqlName, bForceTarget);
            }
        }
        return this->m_srcDictEntityStp;
    }

    return this->m_dictEntityStp;
}

/************************************************************************
**
**  Function    :   DdlGen::setTableNamePatern()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-30453 - LJE - 180409
**
*************************************************************************/
void DdlGen::setTableNamePatern(const std::string &tablePaternStr)
{
    this->realSqlName = tablePaternStr;
    this->m_ddlObjBaseName = this->realSqlName;
    this->realDictEntityStp = this->getDictEntityStp();

    /* PMSTA-36919 - LJE - 191113 */
    if (this->realDictEntityStp != nullptr)
    {
        this->realObjectEn = this->realDictEntityStp->objectEn;
    }

    this->setMsgEntitySqlName(this->m_ddlObjBaseName);
}


/************************************************************************
**
**  Function    :   DdlGen::getEntityFullSqlName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14556 - LJE - 120705
**
*************************************************************************/
std::string DdlGen::getEntityFullSqlName(const std::string &entitySqlName, TARGET_TABLE_ENUM locTargetTableEn)
{
    DICT_ENTITY_STP locDictEntityStp = DBA_GetEntityBySqlName(entitySqlName);

    return this->getEntityFullSqlName(locDictEntityStp, locTargetTableEn);
}

/************************************************************************
**
**  Function    :   DdlGen::getEntityFullSqlName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14556 - LJE - 120705
**
*************************************************************************/
std::string DdlGen::getEntityFullSqlName(DICT_ENTITY_STP paramDictEntityStp, TARGET_TABLE_ENUM paramTargetTableEn, bool bTryToSecure)
{
    std::string realEntitySqlName;

    if (paramTargetTableEn == TargetTable_Undefined &&
        this->ddlGenContextPtr->ddlBuildModeEn == DdlBuildMode_ViewOnly)
    {
        paramTargetTableEn = TargetTable_View;
    }

    if (paramDictEntityStp == NULL)
    {
        if (this->realDictEntityStp != NULL)
        {
            if (this->m_dictEntityStp == this->realDictEntityStp && this->realSqlName.empty() == false)
            {
                realEntitySqlName = this->realSqlName;
            }

            paramDictEntityStp = this->realDictEntityStp;
        }
        else
        {
            paramDictEntityStp = this->m_dictEntityStp;
        }
    }

    if (paramDictEntityStp != NULL)
    {
        return  DdlGenDbi::getEntityFullSqlName(paramDictEntityStp, paramTargetTableEn, realEntitySqlName, this->m_outputViewEn, bTryToSecure);
    }

    return "Unknown";
}

/************************************************************************
**
**  Function    :   DdlGen::getEntitySqlName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14556 - LJE - 120705
**
*************************************************************************/
std::string DdlGen::getEntitySqlName(DICT_ENTITY_STP paramDictEntityStp, TARGET_TABLE_ENUM paramTargetTableEn, bool bMdSqlName)
{
    if (paramDictEntityStp == NULL)
    {
        if (this->realDictEntityStp != NULL)
        {
            if (this->m_dictEntityStp == this->realDictEntityStp && this->realSqlName.empty() == false)
            {
                return this->realSqlName;
            }

            paramDictEntityStp = this->realDictEntityStp;
        }
        else
        {
            paramDictEntityStp = this->m_dictEntityStp;
        }
    }

    if (paramDictEntityStp != NULL)
    {
        return  DdlGenDbi::getEntitySqlName(paramDictEntityStp, paramTargetTableEn, bMdSqlName);
    }

    return "Unknown";
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getEntityMdName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26250 - LJE - 170407
**
*************************************************************************/
std::string DdlGen::getEntityMdName(DICT_ENTITY_STP paramDictEntityStp, TARGET_TABLE_ENUM paramTargetTableEn)
{
    return (this->getEntitySqlName(paramDictEntityStp, paramTargetTableEn, true));
}

/************************************************************************
**
**  Function    :   DdlGen::printDeclareVar()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26250 - LJE - 170410
**
*************************************************************************/
void DdlGen::printDeclareVar(DdlGenSqlBlock &sqlBlock, const std::string &varName, const std::string &valueStr)
{
    bool            bPrintIf = false, bIdent = false;
    std::stringstream    assignStream;

    if (this->isDeclareVarPrinted(sqlBlock, varName))
        return;

    DdlGenVar  var = *this->varHelperPtr->getNewVariable(varName, IdType);

    if (this->getIndent().empty())
    {
        bIdent = true;
        this->setIndent(1);
    }

    if (var.varType != VarType_Variable && strcasecmp(var.strDefault.c_str(), "NULL") == 0)
    {
        this->setIndent(1);
        bPrintIf = true;
    }

    if ((var.varType == VarType_Variable || bPrintIf) && valueStr.empty() == false)
    {
        assignStream << this->getCmdAssignBySelect(var, valueStr, std::string()) << std::endl;

    }

    if (bPrintIf == true)
    {
        this->setIndent(-1);
        sqlBlock.initStream() << std::endl << this->getCmdIfThen(var.printSqlName() + " is null\n", assignStream.str()) << std::endl;
    }
    else
    {
        sqlBlock.initStream() << assignStream.str();
    }

    if (bIdent)
    {
        this->setIndent(-1);
    }

    this->varHelperPtr->getVariable(varName)->bIsPrinted = true;

    sqlBlock.m_varDeclarePrintedSet.insert(varName);
}

/************************************************************************
**
**  Function    :   DdlGen::isUserPrinted()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-17309 - LJE - 131129
**
*************************************************************************/
bool DdlGen::isDeclareVarPrinted(DdlGenSqlBlock &sqlBlock, const std::string &varName)
{
    return sqlBlock.m_varDeclarePrintedSet.find(varName) != sqlBlock.m_varDeclarePrintedSet.end();
}

/************************************************************************
**
**  Function    :   DdlGen::printDeclareUser()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-17309 - LJE - 131129
**
*************************************************************************/
void DdlGen::printDeclareUser(DdlGenSqlBlock &sqlBlock, bool bForceDeclare)
{
    if (this->ddlGenContextPtr->bAvoidUserPrint == false)
    {
        std::string varName("user_id");

        if ((bForceDeclare || this->ddlGenContextPtr->bUserId || this->varHelperPtr->getVariable(varName, false) != nullptr) &&
            this->isDeclareVarPrinted(sqlBlock, varName) == false)
        {
            this->printDeclareVar(sqlBlock, varName, this->getCmdUserId(false));
        }
    }
}

/************************************************************************
**
**  Function    :   DdlGen::isUserPrinted()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-17309 - LJE - 131129
**
*************************************************************************/
bool DdlGen::isDeclareUserPrinted(DdlGenSqlBlock &sqlBlock)
{
    return this->isDeclareVarPrinted(sqlBlock, "user_id");
}

/************************************************************************
**
**  Function    :   DdlGen::printDeclareDataProfile()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
void DdlGen::printDeclareDataProfile(DdlGenSqlBlock &sqlBlock)
{
    bool            bPrintIf = false, bIndent = false;
    std::stringstream    assignStream;

    if (this->ddlGenContextPtr->bAvoidUserPrint)
        return;

    std::string varName("data_profile_id");
    DdlGenVar  *dataProfileVar = this->varHelperPtr->getVariable(varName, false);

    std::string     varUsrName("data_profile_id_user");
    DdlGenVar *dataProfileUserVar = this->varHelperPtr->getVariable(varUsrName, false);

    if (this->getIndent().empty())
    {
        bIndent = true;
        this->setIndent(1);
    }

    if (dataProfileUserVar != nullptr)
    {
        this->printDeclareVar(sqlBlock, varUsrName, DdlGenDbi::getCmdDataProfileIdUser());
    }

    if (dataProfileVar != nullptr)
    {
        if (dataProfileVar->varType != VarType_Variable && strcasecmp(dataProfileVar->strDefault.c_str(), "NULL") == 0)
        {
            bPrintIf = true;
        }

        if (dataProfileVar->varType == VarType_Variable || bPrintIf)
        {
            if (bPrintIf)
            {
                this->setIndent(1);
            }
            assignStream << this->getCmdAssignBySelect(*dataProfileVar,
                                                       "coalesce (" + DdlGenDbi::getCmdDataProfileId() + ", " +
                                                       (dataProfileUserVar == nullptr ? DdlGenDbi::getCmdDataProfileIdUser() : dataProfileUserVar->printSqlName()) + ")",
                                                       std::string()) << std::endl;

            sqlBlock.m_varDeclarePrintedSet.insert(varName);

            if (bPrintIf)
            {
                this->setIndent(-1);
            }
        }

        if (bIndent)
        {
            this->setIndent(-1);
        }

        if (bPrintIf == true)
        {
            this->setIndent(1);
            sqlBlock.initStream() << std::endl << this->getCmdIfThen(dataProfileVar->printSqlName() + " is null\n", assignStream.str()) << std::endl;
            this->setIndent(-1);
        }
        else
        {
            sqlBlock.initStream() << assignStream.str();
        }
    }
}

/************************************************************************
**
**  Function    :   DdlGen::printDeclareChangeSetPromotion()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
void DdlGen::printDeclareChangeSetPromotion(DdlGenSqlBlock &sqlBlock)
{
    this->ddlGenContextPtr->setDdlGenMode(DdlGenMode_ValidateShadow);

    const std::string &varName("tmp_change_set_promotion_id");

    std::stringstream    assignStream;

    if (this->isDeclareVarPrinted(sqlBlock, varName))
        return;

    DdlGenVar  var = *this->varHelperPtr->getNewVariable(varName, IdType);

    sqlBlock.initStream() << std::endl << this->getCmdAssignBySelect(var, this->getChangeSetId(), std::string())
        << this->newLine() << this->rmChangeSetId()
        << this->newLine() << this->setChangeSetId("change_set_promotion_id") << std::endl << std::endl;


    sqlBlock.releaseStream()
        << this->newLine() << this->rmChangeSetId()
        << std::endl << this->getCmdIfThen("@" + varName + " is not null", this->getIndent() + "\t" + this->setChangeSetId(varName) + "\n");

    this->varHelperPtr->getVariable(varName)->bIsPrinted = true;
    sqlBlock.m_varDeclarePrintedSet.insert(varName);

}

/************************************************************************
**
**  Function    :   DdlGen::printDeclareChangeSet()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
void DdlGen::printDeclareChangeSet(DdlGenSqlBlock &sqlBlock)
{
    this->printDeclareVar(sqlBlock, "change_set_id", this->getChangeSetId());
}

/************************************************************************
**
**  Function    :   DdlGen::printDeclareLanguage()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
void DdlGen::printDeclareLanguage(DdlGenSqlBlock &sqlBlock)
{
    bool            bPrintIf = false, bIndent = false;
    std::stringstream    assignStream;
    DdlGenVar      *languageVar;

    if (this->ddlGenContextPtr->bLanguagePrinted)
        return;

    languageVar = this->varHelperPtr->getNewVariable("language_dict_id", "id_t");

    if (this->getIndent().empty())
    {
        bIndent = true;
        this->setIndent(1);
    }

    if (bIndent == false)
    {
        this->setIndent(1);
    }

    if (this->ddlGenContextPtr->ddlGenAction.m_installLevel < 9)
    {
        if (languageVar->varType != VarType_Variable && strcasecmp(languageVar->strDefault.c_str(), "NULL") == 0)
        {
            bPrintIf = true;
        }

        if (languageVar->varType == VarType_Variable || bPrintIf)
        {
            if (bPrintIf)
            {
                this->setIndent(1);
            }
            assignStream << this->getCmdAssignBySelect(*languageVar,
                                                       "coalesce (" + DdlGenDbi::getCmdLanguageDictId() + ", "
                                                       + this->newLine() + "\t(select lang_usr.language_dict_id from " + this->getEntityFullSqlName("appl_user") + " lang_usr where lang_usr.id = " + this->getCmdUserId(false) + "))",
                                                       std::string()) << std::endl;
            if (bPrintIf)
            {
                this->setIndent(-1);
            }
        }

        this->setIndent(-1);

        if (bPrintIf == true)
        {
            this->setIndent(1);
            sqlBlock.initStream() << std::endl << this->getCmdIfThen(languageVar->printSqlName() + " is null\n", assignStream.str()) << std::endl;
            this->setIndent(-1);
        }
        else
        {
            sqlBlock.initStream() << assignStream.str();
        }
    }
    else
    {
        sqlBlock.initStream() << assignStream.str();
    }

    this->ddlGenContextPtr->bLanguagePrinted = true;
}

/************************************************************************
**
**  Function    :   DdlGen::printDeclareMainDLMMax()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-24026 - DDV - 161118
**
*************************************************************************/
void DdlGen::printDeclareMainDLMMax(DdlGenSqlBlock &sqlBlock)
{
    bool            bIndent = false;
    std::stringstream    assignStream;
    DdlGenVar      *mainDLMMAxVar;

    if (this->ddlGenContextPtr->bMainDLMMaxPrinted)
        return;

    if (this->getIndent().empty())
    {
        bIndent = true;
        this->setIndent(1);
    }


    mainDLMMAxVar = this->varHelperPtr->getNewVariable("main_dlm_e_max", "enum_t");

    sqlBlock.initStream() << this->getCmdAssignBySelect(*mainDLMMAxVar, DdlGenDbi::geCmdMainDlmEMax(), std::string()) << std::endl;

    if (bIndent)
    {
        this->setIndent(-1);
    }

    this->ddlGenContextPtr->bMainDLMMaxPrinted = true;
}

/************************************************************************
**
**  Function    :   DdlGen::printDeclareAddDLMMax()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-24026 - DDV - 161118
**
*************************************************************************/
void DdlGen::printDeclareAddDLMMax(DdlGenSqlBlock &sqlBlock)
{
    bool            bIndent = false;
    std::stringstream    assignStream;
    DdlGenVar      *addDLMMAxVar;

    if (this->ddlGenContextPtr->bAddDLMMaxPrinted)
        return;

    if (this->getIndent().empty())
    {
        bIndent = true;
        this->setIndent(1);
    }


    addDLMMAxVar = this->varHelperPtr->getNewVariable("add_dlm_e_max", "enum_t");

    sqlBlock.initStream() << this->getCmdAssignBySelect(*addDLMMAxVar, DdlGenDbi::geCmdAddDlmEMax(), std::string()) << std::endl;

    if (bIndent)
    {
        this->setIndent(-1);
    }

    this->ddlGenContextPtr->bAddDLMMaxPrinted = true;
}

/************************************************************************
**
**  Function    :   DdlGen::printDeclareConnBusinessEntity()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26108 - LJE - 170818
**
*************************************************************************/
void DdlGen::printDeclareConnBusinessEntity(DdlGenSqlBlock &sqlBlock)
{
    std::string varName("connected_business_entity_id");

    if (this->varHelperPtr->getVariable(varName, false) != nullptr)
    {
        this->printDeclareVar(sqlBlock, varName, this->getCmdConnBusinessEntityId());
    }
}

/************************************************************************
**
**  Function    :   DdlGen::printDeclareApplSession()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26108 - LJE - 170818
**
*************************************************************************/
void DdlGen::printDeclareApplSession(DdlGenSqlBlock &sqlBlock)
{
    std::string varName("session_cd");

    if (this->varHelperPtr->getVariable(varName, false) != nullptr)
    {
        this->printDeclareVar(sqlBlock, varName, this->getCmdApplSessionCd());
    }
}

/************************************************************************
**
**  Function    :   DdlGen::printDeclareVariables()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26108 - LJE - 171107
**
*************************************************************************/
void DdlGen::printDeclareVariables(DdlGenSqlBlock &sqlBlock)
{
    /* PMSTA-58084 - LJE - 240729 */
    if (this->ddlGenContextPtr->m_addDeclareMap.empty() == false)
    {
        this->setIndent(1);
        sqlBlock.initStream() << std::endl;
        for (auto& it : this->ddlGenContextPtr->m_addDeclareMap)
        {
            sqlBlock.initStream() << this->getIndent() << it.second << std::endl;
        }
        sqlBlock.initStream() << std::endl;
        this->setIndent(-1);
    }

    /* Print declare variable in header if needed */
    if (this->ddlGenContextPtr->bLanguage == true)
    {
        this->printDeclareLanguage(sqlBlock);
    }
    if (this->ddlGenContextPtr->bUserId == true)
    {
        this->printDeclareUser(sqlBlock);
    }

    this->printDeclareDataProfile(sqlBlock);
    this->printDeclareApplSession(sqlBlock);

    /* PMSTA-24026 - DDV - 161122 - Data framework */
    if (this->ddlGenContextPtr->bMainDLMMax == true)
    {
        this->printDeclareMainDLMMax(sqlBlock);
    }
    if (this->ddlGenContextPtr->bAddDLMMax == true)
    {
        this->printDeclareAddDLMMax(sqlBlock);
    }

    /* PMSTA-26108 - LJE - 170818 */
    this->printDeclareConnBusinessEntity(sqlBlock);
}

/************************************************************************
**
**  Function    :   DdlGen::isInsUpdParam()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 150424
**
*************************************************************************/
bool DdlGen::isInsUpdParam(DICT_CRITER_STP dictCriterStp, DBA_DYNTYPE_ENUM  outputDynNatEn)
{
    DICT_ATTRIB_STP dictAttribStp = dictCriterStp->attrPtr;

    if (dictAttribStp == NULL)
    {
        return false;
    }

    if (dictAttribStp->logicalFlg == FALSE &&
        dictAttribStp->multiLanguageFlg == FALSE &&
        dictAttribStp->isPhysicalAttribute() &&
        strcmp(dictAttribStp->sqlName, dictCriterStp->sqlName) == 0 &&  /* PMSTA-19243 - DDV - 150505 - Don't' add param for denomalized attribute on same entity */
        dictAttribStp->entDictId == dictCriterStp->entDictId)
    {
        if ((outputDynNatEn == DynType_UdOnly && dictAttribStp->custFlg == FALSE) ||
            (outputDynNatEn == DynType_UdMeSpecOnly && (dictAttribStp->custFlg == FALSE || dictAttribStp->meSpecialisationEn != MeSpecialisation_Applied)) ||
            (outputDynNatEn == DynType_PrecompOnly && dictAttribStp->precompFlg == FALSE) ||
            (outputDynNatEn != DynType_UdOnly && outputDynNatEn != DynType_UdMeSpecOnly && outputDynNatEn != DynType_AllDbWithUd && dictAttribStp->custFlg == TRUE) ||
            (outputDynNatEn != DynType_PrecompOnly && dictAttribStp->precompFlg == TRUE))
        {
            return false;
        }

        return true;
    }

    return false;
}

/************************************************************************
**
**  Function    :  DdlGen::posKey()
**
**  Description :  Check if a key in parameter is in the std::string
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-11505 - LJE - 110404
**
*************************************************************************/
std::string::size_type DdlGen::posKey(const std::string& lineStr, const char *keyName)
{
    std::string::size_type pos = lineStr.find(keyName);

    if (pos == std::string::npos)
    {
        return std::string::npos;
    }

    std::string currTag = lineStr.substr(pos);
    std::string::size_type endPos = this->find_first_of(currTag, " \t().-,");
    std::string::size_type tagLen = strlen(keyName);

    if (endPos == tagLen ||
        (endPos == std::string::npos && currTag.size() == tagLen))
        return pos;

    return std::string::npos;
}

/************************************************************************
**
**  Function    :   DdlGen::getPkAccessWhere()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13122 - LJE - 120515
**
*************************************************************************/
std::string DdlGen::getPkAccessWhere(DICT_ENTITY_STP    refDictEntityStp,
                                     DICT_ATTRIB_STP    refAttribStp,
                                     const std::string& entityAlias,
                                     const std::string& refAlias,
                                     bool               bOnTag,
                                     DICT_ATTRIB_STP    linkedAttribStp,
                                     DICT_ENTITY_STP    paramDictEntityStp)
{
    std::stringstream      pkAccessStream;
    DICT_ATTRIB_STP        primKeyTabAttribStp = NULL, localRefAttribStp = linkedAttribStp == NULL ? refAttribStp : linkedAttribStp;
    DICT_ENTITY_STP        dictEntityStp = (paramDictEntityStp == nullptr ? this->getDictEntityStp() : paramDictEntityStp);

    int               accessAttrNbr;
    DICT_ATTRIB_STP  *accessAttrTab;

    std::string            andString, toPrintEntityAlias = entityAlias, toPrintRefAlias = refAlias;

    DICT_T entityDictId, attrDictId;

    DBA_GetDictId(DictEntity, &entityDictId);
    DBA_GetDictId(DictAttr, &attrDictId);

    if (bOnTag)
    {
        andString = this->newLine();
    }
    else
    {
        andString = " and ";
    }

    if (dictEntityStp->dbPKNbr == 0 || dictEntityStp->dbPKTab == NULL)
    {
        accessAttrNbr = dictEntityStp->bkAttrNbr;
        accessAttrTab = dictEntityStp->bkAttr;
    }
    else
    {
        accessAttrNbr = dictEntityStp->dbPKNbr;
        accessAttrTab = dictEntityStp->dbPKTab;
    }

    if (refAlias.empty() == false && refAlias.compare("@") != 0)
    {
        toPrintRefAlias.append(".");
    }
    if (entityAlias.empty() == false && entityAlias.compare("@") != 0)
    {
        toPrintEntityAlias.append(".");
    }

    if (accessAttrTab == NULL)
    {
        this->printMsg(RET_DBA_ERR_INVDATA, "Unable to create where clause without primary/business key - entity '" + std::string(dictEntityStp->mdSqlName) + "'");
        return std::string();
    }

    if (localRefAttribStp != nullptr &&
        localRefAttribStp->linkedAttrDictStp != nullptr)
    {
        pkAccessStream << this->getPkAccessWhere(refDictEntityStp,
                                                 refAttribStp,
                                                 entityAlias,
                                                 refAlias,
                                                 bOnTag,
                                                 localRefAttribStp->linkedAttrDictStp);
    }

    if (refAttribStp == NULL)
    {
        int i;
        for (i = 0; i < accessAttrNbr; i++)
        {
            primKeyTabAttribStp = accessAttrTab[i];

            if (i != 0)
            {
                pkAccessStream << andString;
            }

            pkAccessStream << this->getWhereComp(toPrintEntityAlias + primKeyTabAttribStp->sqlName,
                                                 primKeyTabAttribStp,
                                                 toPrintRefAlias + primKeyTabAttribStp->sqlName,
                                                 primKeyTabAttribStp,
                                                 "=",
                                                 false);
        }
    }
    else if (linkedAttribStp != NULL || refAttribStp->logicalFlg == FALSE)
    {
        if (pkAccessStream.str().empty() == false)
        {
            pkAccessStream << andString;
        }

        if (linkedAttribStp != nullptr &&
            linkedAttribStp != refAttribStp &&
            localRefAttribStp->refEntDictId == entityDictId &&
            (refAttribStp->logicalFlg == FALSE ||
             linkedAttribStp->linkedAttrDictStp != nullptr ||
             linkedAttribStp != refAttribStp->linkedAttrDictStp))
        {
            pkAccessStream
                << toPrintEntityAlias << localRefAttribStp->sqlName
                << " = " << (dictEntityStp->entNatEn == EntityNat_DerivedEntity ? dictEntityStp->linkedEntityDictId : dictEntityStp->entDictId); /* PMSTA-26250 - LJE - 170324 */
        }
        else if (linkedAttribStp != nullptr &&
                 linkedAttribStp != refAttribStp &&
                 localRefAttribStp->refEntDictId == attrDictId &&
                 (refAttribStp->logicalFlg == FALSE ||
                  linkedAttribStp->linkedAttrDictStp != nullptr ||
                  linkedAttribStp != refAttribStp->linkedAttrDictStp))
        {
            if (dictEntityStp->entNatEn == EntityNat_DerivedEntity)
            {
                OBJECT_ENUM     derivedObjEn;
                DBA_GetObjectEnum(dictEntityStp->linkedEntityDictId, &derivedObjEn);

                auto derivedAttribStp = DBA_GetAttributeBySqlName(derivedObjEn, refAttribStp->sqlName);

                if (derivedAttribStp != nullptr)
                {
                    pkAccessStream
                        << toPrintEntityAlias << localRefAttribStp->sqlName
                        << " = " << (derivedAttribStp->parAttrDictId != 0 ? derivedAttribStp->parAttrDictId : derivedAttribStp->attrDictId);
                }
                else
                {
                    pkAccessStream << "1 = 0";
                    this->printMsg(RET_DBA_ERR_INVDATA, "Unknown derived attribute to create where clause '" + std::string(refAttribStp->sqlName) + "'");
                }
            }
            else
            {
                pkAccessStream
                    << toPrintEntityAlias << localRefAttribStp->sqlName
                    << " = " << (refAttribStp->parAttrDictId != 0 ? refAttribStp->parAttrDictId : refAttribStp->attrDictId);
            }
        }
        else if (accessAttrNbr == 1 ||
            (accessAttrNbr == 2 && accessAttrTab[1]->featureEn == XdEntityFeatureFeatureEn::MultiBusinessEntityManagement && dictEntityStp->ownerBusinessEntAttrStp))
        {
            primKeyTabAttribStp = accessAttrTab[0];

            if (dictEntityStp->entDictId == localRefAttribStp->refEntDictId ||
                (dictEntityStp->entNatEn == EntityNat_DerivedEntity && dictEntityStp->linkedEntityDictId == localRefAttribStp->refEntDictId) || /* PMSTA-26250 - LJE - 170324 */
                (localRefAttribStp->refEntDictId == 0 && localRefAttribStp->linkedAttrDictStp != NULL))
            {
                pkAccessStream
                    << toPrintEntityAlias << localRefAttribStp->sqlName
                    << " = " << toPrintRefAlias << primKeyTabAttribStp->sqlName;

                if (accessAttrNbr == 2)
                {
                    pkAccessStream
                        << " and "
                        << toPrintEntityAlias << dictEntityStp->ownerBusinessEntAttrStp->sqlName
                        << " = " << toPrintRefAlias << accessAttrTab[1]->sqlName;
                }
            }
            else
            {
                this->printMsg(RET_DBA_ERR_INVDATA, "Wrong reference entity to create where clause '" + std::string(refAttribStp->sqlName) + "'");
            }

        }
        else
        {
            this->printMsg(RET_DBA_ERR_INVDATA, "Unable to create where clause '" + std::string(refAttribStp->sqlName) + "'");
        }
    }

    if (pkAccessStream.str().empty())
    {
        pkAccessStream << "1 = 0";
        this->printMsg(RET_DBA_ERR_INVDATA, "Empty reference entity to create where clause '" + (refAttribStp ? std::string(refAttribStp->sqlName) : std::string()) + "'");
    }

    return pkAccessStream.str();
}

/************************************************************************
**
**  Function    :   DdlGen::printOptimisticLockingClause()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
void DdlGen::printOptimisticLockingClause(DdlGen &locGenDdl, DICT_ENTITY_STP locDictEntityStp, DdlGenFromFile &paramScriptDdlGen)
{
    std::stringstream pkWhereStream, initAfterStream, checkAfterStream, optimisticLockingClause;

    DdlSprocParam   *optimisticLockinParamPtr = nullptr, *externalSeqNoParam = nullptr;
    DICT_ATTRIB_STP  connBusinessEntAttrStp = nullptr;

    if (this->targetTableEn == TargetTable_Main &&
        locDictEntityStp->optimisticLockingAttrStp != nullptr &&
        locDictEntityStp->objectEn == this->objectEn)
    {
        optimisticLockinParamPtr = locGenDdl.varHelperPtr->getParameter(locDictEntityStp->optimisticLockingAttrStp->sqlName);

        if (optimisticLockinParamPtr != nullptr)
        {
            if (paramScriptDdlGen.context->currTagNat != TagSql_Delete)
            {
                optimisticLockinParamPtr->setOut(true);
            }

            if (paramScriptDdlGen.context->currTagNat != TagSql_Insert)
            {
                optimisticLockingClause << locGenDdl.getAlias() << DdlGenDbi::getOptimisticLockingSqlName(locDictEntityStp)
                    << " = @" << locDictEntityStp->optimisticLockingAttrStp->sqlName;

                locGenDdl.whereStream << locGenDdl.getWhereOrAnd() << optimisticLockingClause.str() << ")";
            }
        }
    }

    if (this->targetTableEn == TargetTable_Main &&
        locDictEntityStp->externalSeqNoAttrStp &&
        locDictEntityStp->objectEn == this->objectEn &&
        paramScriptDdlGen.context->currTagNat != TagSql_Insert)
    {
        externalSeqNoParam = locGenDdl.varHelperPtr->getParameter(locDictEntityStp->externalSeqNoAttrStp->sqlName);

        if (externalSeqNoParam)
        {
            std::stringstream externalSeqNoClause;
            externalSeqNoClause
                << "(" << locGenDdl.getAlias() << locDictEntityStp->externalSeqNoAttrStp->sqlName << " <= @" << locDictEntityStp->externalSeqNoAttrStp->sqlName
                << " or " << locGenDdl.getAlias() << locDictEntityStp->externalSeqNoAttrStp->sqlName
                << " is null or @" << locDictEntityStp->externalSeqNoAttrStp->sqlName << " is null)";

            locGenDdl.whereStream << locGenDdl.getWhereOrAnd() << externalSeqNoClause.str() << ")";
        }
    }

    if (this->targetTableEn == TargetTable_Main &&
        locDictEntityStp->objectEn == this->objectEn &&
        paramScriptDdlGen.context->currTagNat == TagSql_Update &&
        paramScriptDdlGen.outDdlObjEn != DdlObj_TriggerBody &&
        this->ddlGenContextPtr->bAvoidMultiEntity == false &&
        locDictEntityStp->ownerBusinessEntAttrStp &&
        (locDictEntityStp->multiEntityCateg.isOptionalLocalization()) &&
        this->ddlGenContextPtr->getMultiEntityLevel() == MultiEntityLevel_Active &&
        locGenDdl.pscWhereStr.empty() == false)
    {
        connBusinessEntAttrStp = this->getConnBusinessEntAttrStp(locDictEntityStp);
    }

    if (externalSeqNoParam || optimisticLockinParamPtr || connBusinessEntAttrStp)
    {
        if (locGenDdl.overloadStream.str().empty() == false &&
            paramScriptDdlGen.context->currTagNat != TagSql_Insert)   /* PMSTA-29954 - LJE - 180222 */
        {
            std::string readLineStr;
            locGenDdl.overloadStream.clear();
            locGenDdl.overloadStream.seekg(0, std::ios::beg);
            while (getline(locGenDdl.overloadStream, readLineStr))
            {
                pkWhereStream << locGenDdl.newLine() << readLineStr;
            }
        }
        else
        {
            int              keyNbr = locDictEntityStp->dbPKNbr;
            DICT_ATTRIB_STP *keyTab = locDictEntityStp->dbPKTab;

            if (keyNbr == 0)
            {
                keyNbr = locDictEntityStp->bkAttrNbr;
                keyTab = locDictEntityStp->bkAttr;
            }

            for (int i = 0; i < keyNbr; i++)
            {
                if (this->varHelperPtr->getVariable(keyTab[i]->sqlName, false) != nullptr)
                {
                    pkWhereStream << locGenDdl.newLine() << keyTab[i]->sqlName << " = @" << keyTab[i]->sqlName;
                }
            }
        }

        /* PMSTA-26252 - LJE - 170228 */
        checkAfterStream
            << locGenDdl.newLine() << "#NO_SECURED";

        if (optimisticLockinParamPtr)
        {
            checkAfterStream
                << locGenDdl.newLine() << "#DECLARE @new_time_stamp timestamp_t,"
                << locGenDdl.newLine() << "         @cur_new_time_stamp timestamp_t"
                << locGenDdl.newLine() << "         @old_time_stamp timestamp_t"
                << locGenDdl.newLine() << "#ASSIGN  @old_time_stamp = @" << locDictEntityStp->optimisticLockingAttrStp->sqlName;
        }

        if (paramScriptDdlGen.context->currTagNat != TagSql_Insert)
        {
            checkAfterStream
                << locGenDdl.newLine() << "#IF (";

            if (locGenDdl.rowCountVarPtr == nullptr)
            {
                locGenDdl.rowCountVarPtr = this->varHelperPtr->getNewVariable("@row_count", IntType);
            }
            checkAfterStream << "@" << locGenDdl.rowCountVarPtr->sqlName << " = 0";

            if (locGenDdl.errorVarPtr)
            {
                checkAfterStream << " and @" << locGenDdl.errorVarPtr->sqlName << " = 0";
            }
            checkAfterStream << ")";

            checkAfterStream
                << locGenDdl.newLine() << "#{";

            locGenDdl.setIndent(1);

            if (externalSeqNoParam)
            {
                checkAfterStream
                    << locGenDdl.newLine() << "#DECLARE @loc_external_seq_no longint_t";
            }
            checkAfterStream
                << locGenDdl.newLine() << "#DECLARE @entity_code	code_t,"
                << locGenDdl.newLine() << "         @cur_id_varchar     code_t";

            if (connBusinessEntAttrStp)
            {
                checkAfterStream << ","
                    << locGenDdl.newLine() << "@loc_conn_business_entity_id	id_t";
            }

            checkAfterStream
                << locGenDdl.newLine() << "#SELECT_CURSOR " << locDictEntityStp->mdSqlName << " null " << locGenDdl.getAlias(true);

            if (locDictEntityStp->bkAttrNbr == 1 && locDictEntityStp->bkAttr[0]->dataTpProgN == CodeType)
            {
                checkAfterStream
                    << locGenDdl.newLine() << "@entity_code = " << locGenDdl.getAlias() << locDictEntityStp->bkAttr[0]->sqlName;
            }
            else
            {
                checkAfterStream
                    << locGenDdl.newLine() << "@entity_code = 'Unknown'";
            }
            if (optimisticLockinParamPtr)
            {
                checkAfterStream
                    << locGenDdl.newLine() << "@cur_new_time_stamp = " << locGenDdl.getAlias() << DdlGenDbi::getOptimisticLockingSqlName(locDictEntityStp);
            }
            if (externalSeqNoParam)
            {
                checkAfterStream
                    << locGenDdl.newLine() << "@loc_external_seq_no = " << locGenDdl.getAlias() << locDictEntityStp->externalSeqNoAttrStp->sqlName;
            }

            if (connBusinessEntAttrStp)
            {
                checkAfterStream
                    << locGenDdl.newLine() << "@loc_conn_business_entity_id	= " << locGenDdl.getAlias() << connBusinessEntAttrStp->sqlName;
            }

            if (locDictEntityStp->primKeyNbr == 1 && locDictEntityStp->primKeyTab[0]->dataTpProgN == IdType)
            {
                checkAfterStream
                    << locGenDdl.newLine() << "@cur_id_varchar = #CONVERT(code_t, " << locGenDdl.getAlias() << locDictEntityStp->primKeyTab[0]->sqlName << ")";
            }
            else
            {
                checkAfterStream
                    << locGenDdl.newLine() << "@cur_id_varchar = 'Unknown'";
            }

            checkAfterStream
                << locGenDdl.newLine() << (locGenDdl.pscFromStr.empty() ? "#FROM" : locGenDdl.pscFromStr)
                << locGenDdl.newLine() << "#WHERE " << pkWhereStream.str()
                << locGenDdl.newLine() << "#ISOLATION read uncommitted"
                << locGenDdl.newLine() << "#FETCH_CURSOR";

            if (optimisticLockinParamPtr)
            {
                checkAfterStream
                    << locGenDdl.newLine() << "#IF (@cur_new_time_stamp is not null and  @cur_new_time_stamp " << " != @" << locDictEntityStp->optimisticLockingAttrStp->sqlName << ")"
                    << locGenDdl.newLine() << "#{";
                locGenDdl.setIndent(1);

                checkAfterStream
                    << locGenDdl.newLine() << "#APPL_RAISERROR 20220, " << locGenDdl.getDdlObjSqlName() << ", @cur_id_varchar, '" << locDictEntityStp->mdSqlName << "'"
                    << locGenDdl.newLine() << "#RETURN (-1)";

                locGenDdl.setIndent(-1);
                checkAfterStream
                    << locGenDdl.newLine() << "#}";


                if (externalSeqNoParam)
                {
                    checkAfterStream
                        << locGenDdl.newLine() << "#ELSE"
                        << locGenDdl.newLine() << "#{";

                    locGenDdl.setIndent(1);
                }
            }
            if (externalSeqNoParam)
            {
                checkAfterStream
                    << locGenDdl.newLine()
                    << locGenDdl.newLine() << "#IF (@loc_external_seq_no > @" << locDictEntityStp->externalSeqNoAttrStp->sqlName
                    << " and @loc_external_seq_no is not null and @" << locDictEntityStp->externalSeqNoAttrStp->sqlName << " is not null)"
                    << locGenDdl.newLine() << "#{";
                locGenDdl.setIndent(1);

                checkAfterStream
                    << locGenDdl.newLine() << "#APPL_RAISERROR " << MSG_INFO_EXTERNAL_SEQ << ", " << locGenDdl.getDdlObjSqlName() << ", '" << locGenDdl.getDictEntityStp()->mdSqlName << "', @entity_code"
                    << locGenDdl.newLine() << "#RETURN (-1)";

                locGenDdl.setIndent(-1);
                checkAfterStream
                    << locGenDdl.newLine() << "#}";

                if (optimisticLockinParamPtr)
                {
                    locGenDdl.setIndent(-1);
                    checkAfterStream
                        << locGenDdl.newLine() << "#}";
                }
            }

            if (connBusinessEntAttrStp)
            {
                checkAfterStream
                    << locGenDdl.newLine() << "#IF (@loc_conn_business_entity_id != " << this->getConnBusinessEntityId() << " or " << this->getConnBusinessEntityId() << " is null)"
                    << locGenDdl.newLine() << "#{";
                locGenDdl.setIndent(1);

                checkAfterStream
                    << locGenDdl.newLine() << "#APPL_RAISERROR 20571, 'update', " << this->getDdlObjSqlName()
                    << locGenDdl.newLine() << "#RETURN (-1)";

                locGenDdl.setIndent(-1);
                checkAfterStream
                    << locGenDdl.newLine() << "#}";
            }
            locGenDdl.setIndent(-1);

            checkAfterStream
                << locGenDdl.newLine() << "#END_CURSOR"
                << locGenDdl.newLine() << "#}";
        }

        if (optimisticLockinParamPtr && optimisticLockinParamPtr->isOut())
        {
            if (locGenDdl.errorVarPtr)
            {
                if (paramScriptDdlGen.context->currTagNat != TagSql_Insert)
                {
                    checkAfterStream
                        << locGenDdl.newLine() << "#ELSE_IF (@" << locGenDdl.errorVarPtr->sqlName << " = 0)";
                }
                else
                {
                    checkAfterStream
                        << locGenDdl.newLine() << "#IF (@" << locGenDdl.errorVarPtr->sqlName << " = 0)";
                }
            }
            else if (paramScriptDdlGen.context->currTagNat != TagSql_Insert)
            {
                checkAfterStream
                    << locGenDdl.newLine() << "#ELSE";
            }

            if (paramScriptDdlGen.context->currTagNat != TagSql_Insert || locGenDdl.errorVarPtr)
            {
                checkAfterStream
                    << locGenDdl.newLine() << "#{";
                locGenDdl.setIndent(1);
            }

            checkAfterStream
                << locGenDdl.newLine() << "#SELECT " << locDictEntityStp->mdSqlName << " null"
                << locGenDdl.newLine() << "@new_time_stamp = " << locGenDdl.getAlias() << DdlGenDbi::getOptimisticLockingSqlName(locDictEntityStp)
                << locGenDdl.newLine() << "#FROM"
                << locGenDdl.newLine() << "#WHERE " << pkWhereStream.str()
                << locGenDdl.newLine() << "#ISOLATION read uncommitted"
                << locGenDdl.newLine() << "#END";

            checkAfterStream
                << locGenDdl.newLine() << "#ASSIGN @" << optimisticLockinParamPtr->sqlName << " = @new_time_stamp";

            if (paramScriptDdlGen.context->currTagNat != TagSql_Insert || locGenDdl.errorVarPtr)
            {
                locGenDdl.setIndent(-1);
                checkAfterStream
                    << locGenDdl.newLine() << "#}";
            }
        }

        checkAfterStream
            << locGenDdl.newLine() << "#SECURED";
    }

	if (locGenDdl.rowCountVarPtr)
    {
        initAfterStream 
            << locGenDdl.newLine() << locGenDdl.getCmdAssignUpdateCount(locGenDdl.rowCountVarPtr->sqlName);
    }


    /* PMSTA-26252 - LJE - 170227 */
    if (locGenDdl.errorVarPtr != nullptr)
    {
        if (DdlGenDbi::getDbError(this->ddlGenContextPtr) != "0")
        {
            initAfterStream
                << locGenDdl.newLine() << "#ASSIGN @" << locGenDdl.errorVarPtr->sqlName << " = " << DdlGenDbi::getDbError(this->ddlGenContextPtr);
        }
    }
    if (initAfterStream.str().empty() == false)
    {
        locGenDdl.footerStream << paramScriptDdlGen.buildScript(initAfterStream.str());
    }
    if (checkAfterStream.str().empty() == false)
    {
        locGenDdl.footerStream << paramScriptDdlGen.buildScript(checkAfterStream.str());
    }
}

/************************************************************************
**
**  Function    :   DdlGen::printShadowManagement()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
void DdlGen::printShadowManagement(DdlGen &locGenDdl, DdlGenFromFile &paramScriptDdlGen)
{
    if (locGenDdl.getDictEntityStp()->changeSetAuthEn == FeatureAuth_Enable)
    {
        AAAValueGuard<DdlGen *>          parentDdlGenGuard(paramScriptDdlGen.m_parentDdlGenPtr);
        AAAValueGuard<DDL_TAG_NAT_ENUM>  parentScriptTagNatGuard(paramScriptDdlGen.parentScriptTagNat);

        paramScriptDdlGen.parentScriptTagNat = paramScriptDdlGen.context->currTagNat;
        paramScriptDdlGen.m_parentDdlGenPtr = &locGenDdl;

        if (this->ddlGenContextPtr->getDdlGenMode() == DdlGenMode_Shadow &&
            locGenDdl.getDictEntityStp()->dbRuleEn == DbRule_ShadowTable &&
            locGenDdl.targetTableEn == TargetTable_Main)
        {
            std::string       tmplKeyStr = "manage_shadow_";

            switch (paramScriptDdlGen.context->currTagNat)
            {
                case TagSql_Update:
                    tmplKeyStr.append("upd");
                    break;
                case TagSql_Delete:
                    tmplKeyStr.append("del");
                    break;
                case TagSql_Insert:
                    tmplKeyStr.append("ins");
                    break;

                default:
                    tmplKeyStr.clear();
            }

            if (tmplKeyStr.empty() == false)
            {
                const std::string &shadStr = this->getTemplateBody(CfgTemplate_Shadow, tmplKeyStr);

                if (shadStr.empty() == false)
                {
                    this->ddlGenContextPtr->setDdlGenMode(DdlGenMode_Standard);
                    std::string shadowStr = paramScriptDdlGen.buildScript(shadStr);
                    locGenDdl.bodySqlBlock.clear();
                    locGenDdl.bodySqlBlock << shadowStr;
                    this->ddlGenContextPtr->setDdlGenMode(DdlGenMode_Shadow);
                }
            }
        }
        else if (this->ddlGenContextPtr->getDdlGenMode() == DdlGenMode_Standard &&
                 locGenDdl.getDictEntityStp()->dbRuleEn != DbRule_ShadowTable)
        {
            const std::string &ousStr = this->getTemplateBody(CfgTemplate_Shadow, "check_write");

            if (ousStr.empty() == false)
            {
                std::stringstream ousStream;
                ousStream << paramScriptDdlGen.buildScript(ousStr) << locGenDdl.bodySqlBlock.str();
                locGenDdl.bodySqlBlock.clear();

                locGenDdl.bodySqlBlock << ousStream.str();
            }
        }
    }
}

/************************************************************************
**
**  Function    :  DdlGen::getDictCriteriaStp()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation    :  PMSTA-26250 - LJE - 170330
**
*************************************************************************/
DICT_CRITER_STP  DdlGen::getDictCriteriaStp(INT_T critProgN)
{
    DICT_CRITER_STP dictCriteriaStp = nullptr;

    if (this->infoCriterMap != nullptr)
    {
        auto it = this->infoCriterMap->find(critProgN);
        if (it != this->infoCriterMap->end())
        {
            dictCriteriaStp = it->second;
        }
    }

    return dictCriteriaStp;
}

/************************************************************************
**
**  Function    :   DdlGen::discardAllTriggers()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
void DdlGen::disableAllTriggers(const std::string &fullSqlName)
{
    DdlGen locDdlGen(this->objectEn, *this);

    std::vector<std::string> allTriggersReqVector;
    this->getDisableAllTriggersCmd((fullSqlName.empty() ? this->getDdlObjFullSqlName() :fullSqlName), allTriggersReqVector);
    for (auto &it : allTriggersReqVector)
    {
        locDdlGen.bodySqlBlock << it;
        locDdlGen.cmdType = DDlCmdType_DbProcess;
        locDdlGen.flush();
    }
}

/************************************************************************
**
**  Function    :   DdlGen::enableAllTriggers()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
void DdlGen::enableAllTriggers(const std::string &fullSqlName)
{
    DdlGen locDdlGen(this->objectEn, *this);
    std::vector<std::string> allTriggersReqVector;

    this->getEnableAllTriggersCmd((fullSqlName.empty() ? this->getDdlObjFullSqlName() : fullSqlName), allTriggersReqVector);
    for (auto &it : allTriggersReqVector)
    {
        locDdlGen.bodySqlBlock << it;

        locDdlGen.cmdType = DDlCmdType_DbProcess;
        locDdlGen.flush();
    }
}

/************************************************************************
**
**  Function    :   DdlGen::checkAttributeNotNullOnRecords()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
bool DdlGen::checkAttributeNotNullOnRecords()
{
    return false;
}

/************************************************************************
**
**  Function    :   DdlGen::getOrderClause()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
void DdlGen::getOrderClause(DICT_ENTITY_STP     paramDictEntityStp, 
                            std::stringstream & paramFromStream, 
                            std::stringstream & paramOrderStream,
                            bool                bMandatory,
                            int                 level)
{
    std::map<SMALLINT_T, std::string> sortingMap;
    bool                   bCompleteWithBk = false;
    std::set<std::string>  bkPrintedSet;

    auto dictCriteriaMapPtr = &(paramDictEntityStp->allDictCriteriaMap);

    std::string levelStr;
    if (level > 0)
    {
        levelStr = SYS_Stringer("l", level);
    }

    /* Sorting according the short structure */
    while (sortingMap.empty())
    {
        std::map<std::string, std::stringstream> joinMap;
        std::map<std::string, int>          joinSort;

        int joinSortRank = 0;
        for (auto &it : *dictCriteriaMapPtr)
        {
            if (it.second->sortRank > 0)
            {
                if (it.second->entAttrPtr == nullptr)
                {
                    if (it.second->parentCriteria1Stp != nullptr)
                    {
                        if (this->manageOrderJoin(*it.second, joinMap, joinSort, sortingMap, joinSortRank, bMandatory, levelStr))
                        {
                            std::stringstream locOrderStream;
                            locOrderStream
                                << levelStr
                                << it.second->joinSqlName
                                << it.second->attrPtr->sqlName
                                << this->getOrderSortRule(it.second->sortRule);
                            sortingMap[it.second->sortRank] = locOrderStream.str();
                        }
                    }
                    else if (it.second->parentCriteria2Stp != nullptr &&
                             this->m_ddlGenFromFileContextPtr != nullptr &&
                             this->m_ddlGenFromFileContextPtr->m_parentDictEntity != 0)
                    {
                        DictCriterClass dynDictCriteria = *it.second;
                        DictCriterClass parentDictCriteria = *(it.second->parentCriteria2Stp);

                        dynDictCriteria.attrEntDictId = this->m_ddlGenFromFileContextPtr->m_parentDictEntity;

                        OBJECT_ENUM objEn = NullEntity;
                        DBA_GetObjectEnum(dynDictCriteria.attrEntDictId, &objEn);
                        dynDictCriteria.attrPtr = DBA_GetAttributeBySqlName(objEn, dynDictCriteria.attrPtr->sqlName);

                        sprintf(dynDictCriteria.joinSqlName, "%sJ%03d%04d.", levelStr.c_str(), dynDictCriteria.parent2ProgN, CAST_INT(dynDictCriteria.attrEntDictId));

                        dynDictCriteria.parentCriteria1Stp = &parentDictCriteria;

                        dynDictCriteria.parentCriteria2Stp = nullptr;
                        dynDictCriteria.parent2ProgN       = 0;
                        dynDictCriteria.parent2SqlName[0]  = 0;
                        dynDictCriteria.isNullParent2ProgN = true;

                        if (this->manageOrderJoin(dynDictCriteria, joinMap, joinSort, sortingMap, joinSortRank, bMandatory, levelStr))
                        {
                            std::stringstream locOrderStream;
                            locOrderStream
                                << levelStr
                                << dynDictCriteria.joinSqlName
                                << it.second->attrPtr->sqlName
                                << this->getOrderSortRule(it.second->sortRule);
                            sortingMap[it.second->sortRank] = locOrderStream.str();
                        }
                    }
                    else
                    {
                        bCompleteWithBk = true;
                    }
                }
                else
                {
                    if (it.second->entAttrPtr->busKeyFlg == TRUE)
                    {
                        bkPrintedSet.insert(it.second->entAttrPtr->sqlName);
                    }

                    std::stringstream locOrderStream;
                    locOrderStream
                        << this->getAlias()
                        << it.second->sqlName
                        << this->getOrderSortRule(it.second->sortRule);
                    sortingMap[it.second->sortRank] = locOrderStream.str();
                }
            }
        }

        for (int i = 0; i < joinSortRank; ++i)
        {
            for (auto &it : joinSort)
            {
                if (it.second == i)
                {
                    paramFromStream << std::endl << joinMap[it.first].str();
                }
            }
        }

        if (dictCriteriaMapPtr == &(paramDictEntityStp->shortDictCriteriaMap))
        {
            break;
        }

        dictCriteriaMapPtr = &(paramDictEntityStp->shortDictCriteriaMap);
    }

    if (sortingMap.empty() || bCompleteWithBk)
    {
        for (int i = 0; i < paramDictEntityStp->bkAttrNbr; i++)
        {
            auto bkAttribStp = paramDictEntityStp->bkAttr[i];

            if (bkPrintedSet.find(bkAttribStp->sqlName) == bkPrintedSet.end())
            {
                if (bkAttribStp->dataTpProgN == IdType &&
                    bkAttribStp->refDictEntityStp != nullptr &&
                    (paramDictEntityStp->parentAttrStp == nullptr ||
                     bkAttribStp->attrDictId != paramDictEntityStp->parentAttrStp->attrDictId))
                {
                    for (auto& it : sortingMap)
                    {
                        if (paramOrderStream.str().empty() == false)
                        {
                            paramOrderStream << ", ";
                        }
                        paramOrderStream << it.second;
                    }
                    sortingMap.clear();

                    auto tmpAlias = this->getAlias(true);
                    auto locAlias = levelStr + tmpAlias + bkAttribStp->refDictEntityStp->aliasSqlname;

                    paramFromStream << std::endl;
                    if (bkAttribStp->dbMandatoryFlg == TRUE && bMandatory)
                    {
                        paramFromStream << " inner join ";
                    }
                    else
                    {
                        bMandatory = false;
                        paramFromStream << " left outer join ";
                    }

                    paramFromStream
                        << this->getEntityFullSqlName(bkAttribStp->refDictEntityStp)
                        << " " << locAlias << " on "
                        << locAlias << "." << bkAttribStp->refDictEntityStp->primKeyTab[0]->sqlName
                        << " = "
                        << this->getAlias() << bkAttribStp->sqlName;

                    this->setAlias(locAlias);
                    this->getOrderClause(bkAttribStp->refDictEntityStp,
                                         paramFromStream,
                                         paramOrderStream,
                                         bMandatory,
                                         level + 1);

                    this->setAlias(tmpAlias);
                }
                else if (bkAttribStp->allDictCriteriaStp != nullptr)
                {
                    std::stringstream locOrderStream;
                    locOrderStream
                        << this->getAlias() << bkAttribStp->sqlName
                        << this->getOrderSortRule(bkAttribStp->allDictCriteriaStp->dictId < 0 ?
                                                  SortRule_Ascending :
                                                  bkAttribStp->allDictCriteriaStp->sortRule);

                    sortingMap[bkAttribStp->progBkN + 1000] = locOrderStream.str();
                }
                else
                {
                    sortingMap[bkAttribStp->progBkN + 1000] = this->getAlias() + bkAttribStp->sqlName;
                }
            }
        }
    }

    if (sortingMap.empty() == false ||
        (level == 0 && paramOrderStream.str().empty() == false))
    {
        bool bFirst = paramOrderStream.str().empty();
        if (level == 0)
        {
            std::string orderStr;
            if (paramOrderStream.str().empty() == false)
            {
                orderStr = paramOrderStream.str();
                paramOrderStream.clear();
                paramOrderStream.str(std::string());
            }
            paramOrderStream << " order by " << orderStr;
        }
        
        for (auto &it : sortingMap)
        {
            if (bFirst == false)
            {
                paramOrderStream << ", ";
            }
            else
            {
                bFirst = false;
            }
            paramOrderStream << it.second;
        }
        if (level == 0)
        {
            paramOrderStream << std::endl;
        }
    }
}

/************************************************************************
**
**  Function    :   DdlGen::manageOrderJoin()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
bool DdlGen::manageOrderJoin(DictCriterClass                          &dictCriteria, 
                             std::map<std::string, std::stringstream> &joinMap, 
                             std::map<std::string, int>               &joinSort, 
                             std::map<SMALLINT_T, std::string>         &sortingMap,
                             int                                      &joinSortRank,
                             bool                                      bMandatory,
                             std::string                               levelstr)
{
    if (dictCriteria.attrPtr != nullptr)
    {
        auto joinSqlname = SYS_Stringer(levelstr, dictCriteria.joinSqlName);

        auto &joinCmd = joinMap[joinSqlname];
        if (joinCmd.str().empty())
        {
            if (dictCriteria.attrPtr != nullptr &&
                dictCriteria.attrPtr->dictEntityStp->objectEn == DictLabel &&
                dictCriteria.parentCriteria1Stp != nullptr &&
                dictCriteria.parentCriteria1Stp->attrEntObj != dictCriteria.attrPtr->dictEntityStp->objectEn &&
                dictCriteria.parentCriteria1Stp->parentCriteria1Stp == nullptr)
            {
                auto parentCriteriaStp = dictCriteria.parentCriteria1Stp;

                if (parentCriteriaStp->attrPtr->dbMandatoryFlg == TRUE && bMandatory)
                {
                    joinCmd << " inner join ";
                }
                else
                {
                    bMandatory = false;
                    joinCmd << " left outer join ";
                }
                std::string locAlias(joinSqlname);
                locAlias.erase(locAlias.size() - 1);

                joinCmd
                    << this->getEntityFullSqlName(parentCriteriaStp->attrPtr->refDictEntityStp)
                    << " " << locAlias << " on "
                    << joinSqlname << parentCriteriaStp->attrPtr->refDictEntityStp->primKeyTab[0]->sqlName << " = "
                    << this->getAlias() << parentCriteriaStp->sqlName;

                joinSort.insert(std::make_pair(joinSqlname, joinSortRank++));
            }
            else
            {
                std::string locAlias(joinSqlname);
                locAlias.erase(locAlias.size() - 1);

                auto parentCriteriaStp = dictCriteria.parentCriteria1Stp;
                while (parentCriteriaStp != nullptr)
                {
                    if (parentCriteriaStp == dictCriteria.parentCriteria1Stp)
                    {
                        if (parentCriteriaStp->attrPtr->dbMandatoryFlg == TRUE && bMandatory)
                        {
                            joinCmd << " inner join ";
                        }
                        else
                        {
                            bMandatory = false;
                            joinCmd << " left outer join ";
                        }

                        joinCmd
                            << this->getEntityFullSqlName(dictCriteria.attrPtr->dictEntityStp)
                            << " " << locAlias << " on ";
                    }
                    else
                    {
                        joinCmd << " and ";
                    }

                    int keyPos = 0;
                    if (dictCriteria.attrPtr->dictEntityStp->primKeyNbr > 1)
                    {
                        if (dictCriteria.attrPtr->dictEntityStp->objectEn == DictLabel)
                        {
                            for (; keyPos < dictCriteria.attrPtr->dictEntityStp->primKeyNbr; ++keyPos)
                            {
                                if (dictCriteria.attrPtr->dictEntityStp->primKeyTab[keyPos]->refDictEntityStp != nullptr)
                                {
                                    if (dictCriteria.attrPtr->dictEntityStp->primKeyTab[keyPos]->refDictEntityStp->objectEn == DictLang)
                                    {
                                        joinCmd << joinSqlname
                                            << dictCriteria.attrPtr->dictEntityStp->primKeyTab[keyPos]->sqlName
                                            << " = 1 and ";
                                    }
                                    else if (parentCriteriaStp->attrPtr->refDictEntityStp != nullptr)
                                    {
                                        joinCmd << joinSqlname
                                            << dictCriteria.attrPtr->dictEntityStp->primKeyTab[keyPos]->sqlName
                                            << " = " << parentCriteriaStp->attrPtr->refDictEntityStp->entDictId << " and ";
                                    }
                                }
                                else
                                {
                                    break;
                                }
                            }
                        }
                        else
                        {
                            for (; keyPos < dictCriteria.attrPtr->dictEntityStp->primKeyNbr; ++keyPos)
                            {
                                if (dictCriteria.attrPtr->dictEntityStp->primKeyTab[keyPos]->refDictEntityStp != nullptr &&
                                    dictCriteria.attrPtr->dictEntityStp->primKeyTab[keyPos]->refDictEntityStp->entDictId ==
                                    parentCriteriaStp->attrPtr->refDictEntityStp->entDictId)
                                {
                                    break;
                                }
                            }
                        }
                    }

                    joinCmd << joinSqlname << dictCriteria.attrPtr->dictEntityStp->primKeyTab[keyPos]->sqlName << " = ";

                    if (parentCriteriaStp->joinSqlName[0] == 0)
                    {
                        joinCmd << this->getAlias() << parentCriteriaStp->sqlName;
                    }
                    else
                    {
                        this->manageOrderJoin(*parentCriteriaStp, joinMap, joinSort, sortingMap, joinSortRank, bMandatory, levelstr);

                        /* Manage dict_label case (the short attribute link is defined on the name ) */
                        if (dictCriteria.attrPtr->dictEntityStp->primKeyTab[keyPos]->dataTpProgN != parentCriteriaStp->attrPtr->dataTpProgN &&
                            (dictCriteria.attrPtr->dictEntityStp->primKeyTab[keyPos]->dataTpProgN == IdType ||
                             dictCriteria.attrPtr->dictEntityStp->primKeyTab[keyPos]->dataTpProgN == DictType) &&
                            parentCriteriaStp->attrPtr->dictEntityStp->isId())
                        {
                            joinCmd << levelstr << parentCriteriaStp->joinSqlName << parentCriteriaStp->attrPtr->dictEntityStp->primKeyTab[0]->sqlName;
                        }
                        else
                        {
                            joinCmd << levelstr << parentCriteriaStp->joinSqlName << parentCriteriaStp->attrPtr->sqlName;
                        }
                    }

                    if (parentCriteriaStp == dictCriteria.parentCriteria1Stp)
                    {
                        parentCriteriaStp = dictCriteria.parentCriteria2Stp;
                    }
                    else
                    {
                        parentCriteriaStp = nullptr;
                    }

//                    locAlias += "p";
                }

                joinSort.insert(std::make_pair(joinSqlname, joinSortRank++));
            }
            return true;
        }
    }
    return false;
}

/*************************************************************************
**   END  dbagenddl.cpp                                        Odyssey **
*************************************************************************/


/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef DBAPERF_H
#define DBAPERF_H

/* Everything else goes here */
#include <fin.h>
#include <srvperfcalcres.h>
/************************************************************************
**      BEGIN : Global definitions attached to dbaperf.c
*************************************************************************/

/*--------------------------------------------------------------------*/
/* Common functions called by portfolio storage and benchmark storage */
/*--------------------------------------------------------------------*/

extern RET_CODE DBA_InsSecondSynthDataPrep(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DATETIME_T, DATETIME_T, FLAG_T, DBA_INSPAEXTRA_STP, PA_DATEINFO_STP);

extern RET_CODE DBA_InsPtfFreqDataPrep(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DATETIME_T, DATETIME_T, DBA_INSPAEXTRA_STP);

extern RET_CODE DBA_InsStratSynthDataPrep(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DATETIME_T, DATETIME_T,DBA_INSPAEXTRA_STP); /* PMSTA08736 - LJE - 100125 */ /* PMSTA08736 - LJE - 100412 */

extern RET_CODE DBA_InsInstrFreqDataPrep(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DATETIME_T, DATETIME_T, DBA_INSPAEXTRA_STP);

extern RET_CODE DBA_DeletePaAndExtRaData(DBA_DYNFLD_STP, DBA_DYNFLD_STP*, OBJECT_ENUM, int, DBA_HIER_HEAD_STP);

extern RET_CODE DBA_InsPtfSynthDataPrep(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP **, int *,
                                        DBA_DYNFLD_STP **, int *),
                DBA_InsESEinPADataPrep(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP,
                                        DBA_DYNFLD_STP **, int *),
                DBA_InsESEinExtRADataPrep(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP,
                                        DBA_DYNFLD_STP **, int *),
                DBA_InsertPaAndExtRaData(DBA_DYNFLD_STP, DBA_INSPAEXTRA_STP, int),
                DBA_UpdatePAandExtRAData(DBA_DYNFLD_STP, OBJECT_ENUM,
                                        DBA_DYNST_ENUM, DBA_DYNFLD_STP *, int, char *);

extern RET_CODE DBA_SelectPSP(DBA_DYNFLD_STP ,int*,DBA_DYNFLD_STP**,int*),				/* REF9125 - MCA - 030826 */
				DBA_FilterPSP(DBA_DYNFLD_STP , DBA_HIER_HEAD_STP,DBA_DYNFLD_STP* ,int ,OBJECT_ENUM, DBA_DYNFLD_STP*,int );

extern RET_CODE DBA_PSPInfoOrLogSrvMesg(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DICT_FCT_STP, OBJECT_ENUM, const char*, ID_T, DBA_DYNFLD_STP, char*);	/* PMSTA-15184 - 151012 - PMO / REF9125 - RAK - 030923 */

extern RET_CODE DBA_UpdDomainWithPSPInfo(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP);

extern RET_CODE DBA_ValidatePerfData(DBA_DYNFLD_STP);

#endif

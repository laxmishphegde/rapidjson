/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DBIDICT_C

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define TIME_H
#define STDLIB_H
#define STRING_H

#include "unidef.h"     /* Mandatory */

#include "gen.h"
#include "date.h"
#include "dba.h"
#include "dbi.h"
#include "msg.h"
#include "syb.h"
#include "oralib.h"
#include "syslib.h"     /* PMO - Rename our sys.h to syslib.h and use it */
#include "ddlgen.h"     /* PMSTA-46681 - LJE - 230123 */

extern TIMER_ST        EV_ExtractFileTimer;
extern int             EV_AAAInstallLevel;
extern DBA_RDBMS_ENUM  EV_RdbmsDdlGen;
extern std::string     EV_SourceApplOwner;
extern DdlGenContext*  EV_SourceContext;
extern std::string     EV_TargetDataSource;

using namespace std;

/********************************************************************************
** FUNCTIONS USED TO LOAD THE META-DICTIONARY
*********************************************************************************/

/************************************************************************
**      Static definitions & data
*************************************************************************/
typedef struct DBI_ENTITY
{
    DICT_T           *entDictId;          /* unique identifier determined by dvp          */
    char             *name;               /* conceptual name                              */
    char             *label;              /* label in user language                       */ /* PMSTA-19243 - DDV - 150427 - Change label datatype from name_t to note_t */
    UChar            *uniLabel;          /* unicode label in user language               */ /* PMSTA-19243 - DDV - 150427 - Change label datatype from name_t to note_t */

    char             *sqlName;            /* physical name                                */

    char             *dbName;             /* database name                                */
    char             *custDbName;         /* ud table database name                       */ /* PMSTA-11505 - LJE - 110315 */
    char             *precompDbName;      /* TSL extension database name                  */ /* PMSTA-11505 - LJE - 110315 */

    FLAG_T          *refAuthFlg;         /* may be referenced by a custom field          */
    FLAG_T          *custAuthFlg;        /* custom fields may be added                   */
    FLAG_T          *mainFlg;            /* principal entity or not                      */
    ENUM_T          *tpNatEn;            /* 0 -> no typing associated,
                                        ** 1 -> parent type only
                                        ** 2 -> parent type or subtype                  */
    FLAG_T          *entDictIdFlg;       /* contains one attribute referring to
                                        ** dict_entity                                  */
    FLAG_T          *synonFlg;           /* may be referenced by a codification          */
    FLAG_T          *listFlg;            /* may be referenced by a set                   */
    FLAG_T          *qSearchFlg;         /* entity have one attribute with a
                                        ** significant quick search mask                 */
    FLAG_T          *logicalFlg;         /* logical entity or not                        */
    ENUM_T          *interf;             /* interface enum                               */
    TINYINT_T       *natIndex;           /* nature index                                 */     /* DVP338 */
    DBI_SMALLINT    *natIndexNF;         /* nature index Null Info CS_NULLDATA or CS_GOODDATA */
    TINYINT_T       *parIndex;           /* parent index                                 */     /* DVP338 */
    DBI_SMALLINT    *parIndexNF;         /* parent index Null Info CS_NULLDATA or CS_GOODDATA */

    FLAG_T          *precompFlg;         /* TLS precomputed flag */      /* PMSTA-11505 - LJE - 110315 */
    FLAG_T          *usePrecompFlg;      /* TLS uses precomputed flag */ /* PMSTA-11505 - LJE - 110315 */
    ID_T            *precompStdFormatId; /* TLS standard format */       /* PMSTA-11505 - LJE - 110315 */
    ID_T            *precompUsrFormatId; /* TLS user format */           /* PMSTA-11505 - LJE - 110315 */

    DATETIME64_STP   lastModifDate;      /* Last structure modification date */ /* PMSTA-11505 - LJE - 110315 */
    SMALLINT_T      *precompRankN;       /* */                                 /* PMSTA-11505 - LJE - 110315 */
    char            *shortSqlname;       /* Short sqlname */                   /* PMSTA-11505 - LJE - 110315 */
    char            *aliasSqlname;       /* Default alias uses */              /* PMSTA-11505 - LJE - 110315 */

    INT_T           *criterNbr;          /* criteria number for the entity               */
    INT_T           *attrNbr;            /* attribute number for the entity              */
    FLAG_T          *useScreenFlg;       /* use screen or not                            */
    FLAG_T          *inputCtrlFlg;       /* has a logical input control attrib - DVP587  */
    FLAG_T          *notepadFlg;         /* has a logical notepad attribute              */

    FLAG_T          *dictLabelFlg;       /* Define if exists informations in dict_label  */
    ENUM_T          *entNatEn;
    ENUM_T          *securityLevelEn;
    MASK_T          *automaticMask;
    ID_T            *adminFctDictId;
    ENUM_T          *pkRuleEn;
    ENUM_T          *deleteRuleEn;
    ENUM_T          *objModifStatEn;
    ENUM_T          *tableModifStatEn;
    ENUM_T          *lastModifEn;

    char            *dbSqlName;
    ENUM_T          *dbRuleEn;
    ID_T            *linkedEntityDictId;
    ID_T            *physicalEntityDictId;

    ENUM_T          *auditAuthEn;            /* audit enum                                   */
    ENUM_T          *activeAuthEn;           /* Active flag authorization management          */
    ENUM_T          *updFctAuthEn;           /* Update function authorization management      */
    ENUM_T          *externalSeqAuthEn;      /* External sequencing authorization management  */

    ENUM_T          *loadDictRuleEn;
    ENUM_T          *copyRightEn;
    ENUM_T          *dmlModifTrackEn;
    ENUM_T          *partAuthEn;            /* Partitioning authorization */ /* PMSTA-24563 - LJE - 160921 */
    ENUM_T          *dlmAuthEn;             /* Data life management authorization */ /* PMSTA-24563 - LJE - 160921 */
    ENUM_T          *multiEntityCategEn;    /* Multi-Entity management */ /* PMSTA-26108 - LJE - 170727 */

    ENUM_T          *xdStatusEn;
    ID_T            *xdEntityId;

} DBI_ENTITY_ST, *DBI_ENTITY_STP;

typedef struct DBI_ATTRIB
{
    DICT_T              *attrDictId;         /* attribute identifier                */
    char                *name;               /* conceptual name                     */
    char                *label;              /* label in user language              */ /* PMSTA-19243 - DDV - 150427 - Change label datatype from name_t to note_t */
    UChar               *uniLabel;           /* unicode label in user language      */ /* PMSTA-19243 - DDV - 150427 - Change label datatype from name_t to note_t */
    DICT_T              *entDictId;          /* entity identifier                   */
    ENUM_T              *dataTpProgN;        /* datatype position                   */
    DICT_T              *dataTpDictId;       /* datatype identifier                 */
    DICT_T              *refEntDictId;       /* parent entity (for foreign key)     */
    DICT_T              *parAttrDictId;      /* parent attr (for permitted value)   */
    char                *sqlName;            /* physical name                       */
    INT_T               *progN;              /* unique identifier determined by dvp */ /* REF8844 - LJE - 030327 */
    INT_T               *dbProgN;            /* progN set in database, the progN can be changed in the meta dict load */ /* PMSTA-13109 - LJE - 111123 */
    SMALLINT_T          *progPkN;            /* index on Get_Arg structure          */
    short               *nullProgPkN;
    SMALLINT_T          *dispRank;           /* display order                       */
    FLAG_T              *primFlg;            /* attribute is a primary key          */
    FLAG_T              *mandatoryFlg;       /* attribute is allowed to be null     */
    FLAG_T              *dbMandatoryFlg;     /* attr is allowed to be null in db    */
    char                *dfltVal;            /* default when attribute isn't filled */
    FLAG_T              *permValFlg;         /* permitted value flag                */
    FLAG_T              *busKeyFlg;          /* attribute is an business key        */
    FLAG_T              *logicalFlg;         /* logical attribute added for Sql     */
    FLAG_T              *custFlg;            /* customized field                    */
    FLAG_T              *precompFlg;         /* TSL extension field                 */ /* PMSTA-11505 - LJE - 110315 */
    ENUM_T              *calcEn;             /* calculated, virtual or attribute    */
    ENUM_T              *permAuthEn;         /* permitted values adding is allowed  */
    TINYINT_T           *editionEn;          /* edition flag                        */ /* DVP039 - RAK - 960508 */ /* ROI - 970421 */
    MASK_T              *qSearchMask;        /* in which subtype an attribute is    */
    /* usable in quick search screen       */
    MASK_T              *searchMask;         /* in which subtype an attribute is    */
    /* usable in simple search screen      */
    MASK_T              *subTypeMask;        /* to which subtype an attribute is    */
    /* attached. (edition screen)          */
    /* use flag perm_val_f                 */
    DICT_T              *parAttrEntDictId;   /* parent attribute entity           */
    INT_T               *parAttrProgN;       /* parent attribute progN              */
    SMALLINT_T          *shortIdx;           /* index in short structure            */
    DBI_SMALLINT        *nullShortIdx;       /* REF8844 - LJE - 030305 : -1 if the attribute isn't in short struct */
    ENUM_T	            *securityLevelEn;
    char                *keyCharC;
    ENUM_T              *widgetEn;		    /* usable for date-time widget         */ /* MRA - 000119 - RFE4115 -- DLA - REF7264 - 020508*/
    SMALLINT_T          *maxDbLenN;			/* DLA - PMSTA09887 - 101104 */
    SMALLINT_T          *defaultDisplayLenN; /* DLA - PMSTA09887 - 101104 */

    ENUM_T              *tascViewEn;                /* TSL informations... */ /* PMSTA-11505 - LJE - 110615 */
    char                *objectAttribute;           /* TSL informations... */ /* PMSTA-11505 - LJE - 110615 */
    char                *entityAttribute;           /* TSL informations... */ /* PMSTA-11505 - LJE - 110615 */
    char                *enumAttribute;             /* TSL informations... */ /* PMSTA-11505 - LJE - 110615 */
    ENUM_T              *enumValueEn;               /* TSL informations... */ /* PMSTA-11505 - LJE - 110615 */
    DICT_T              *refEntityAttributeDictId;  /* TSL informations... */ /* PMSTA-11505 - LJE - 110615 */
    ENUM_T              *fkPresentationEn;          /* TSL informations... */ /* PMSTA-11505 - LJE - 110615 */
    DICT_T              *denomLanguageDictId;       /* TSL informations... */ /* PMSTA-11505 - LJE - 110615 */
    FLAG_T              *verticalSearchFlg;         /* TSL informations... */ /* PMSTA-11505 - LJE - 110615 */
    FLAG_T              *verticalPatternFlg;        /* TSL informations... */ /* PMSTA-11505 - LJE - 110615 */
    FLAG_T              *multiLanguageFlg;          /* TSL informations... */ /* PMSTA-11505 - LJE - 110615 */
    ID_T                *linkedAttrDictId;
    ENUM_T              *xdStatusEn;
    ENUM_T              *refDeleteRuleEn;
    ENUM_T              *refSecurityRuleEn;
    ENUM_T              *objModifStatEn;
    ENUM_T              *refCheckRuleEn;

    /* PMSTA-21717 - LJE - 160119 */
    SMALLINT_T          *progBkN;
    DBI_SMALLINT        *nullProgBkN;
    ENUM_T              *exportEn;
    ENUM_T              *featureEn;
    ENUM_T              *modelBankEn; /* PMSTA-27352 - LJE - 170606 */
    ENUM_T              *meSpecialisationEn; /* PMSTA-26108 - LJE - 170830 */
    ENUM_T              *outboxPublishEn; /* PMSTA-45305 -Lalby- 210528 */

} DBI_ATTRIB_ST, *DBI_ATTRIB_STP;

typedef struct DBI_CRITER
{
    DICT_T           *dictId;                /* criteria identifier       */
    DICT_T           *entDictId;             /* criteria entity identifier       */
    DICT_T           *attrDictId;            /* attribute identifier             */
    ENUM_T           *dynNatEn;              /* Nature of the dynamic structure that the dict criteria explains */ /* PMSTA-11505 - LJE - 110325 */
    char             *sqlName;               /* sql name uses by the view or proc generator */ /* PMSTA-11505 - LJE - 110316 */
    DICT_T           *attrEntDictId;         /* attribute entity identifier      */
    INT_T            *progN;                 /* criteria progN (index for short) */ /* PMSTA-11505 - LJE - 110624 */
    char             *name;                  /* criteria name                    */ /* REF9303 - LJE - 030915 */
    char             *label;                 /* criteria label                   */ /* PMSTA-19243 - DDV - 150427 - Change label datatype from name_t to note_t */
    UChar            *uniLabel;              /* unicode label in user language   */ /* PMSTA-19243 - DDV - 150427 - Change label datatype from name_t to note_t */
    TINYINT_T        *sortRank;              /* sorting rank                     */
    ENUM_T           *sortRule;              /* sorting rule                     */
    TINYINT_T        *fkIndex;               /* fk index                         */	/* DVP338 */ /* PMSTA-11505 - LJE - 110624 */
    DBI_SMALLINT     *fkIndexNF;             /* fk index Null field              */ /* PMSTA-14452 - LJE - 130213 */
    SMALLINT_T       *index;                 /* index                            */ /* PMSTA-11505 - LJE - 110315 */
    DBI_SMALLINT     *indexNF;               /* index Null Field                 */ /* PMSTA-11505 - LJE - 110315 */
    SMALLINT_T       *parent1ProgN;          /* 1st parent criteria index (1st fk) */ /* PMSTA-11505 - LJE - 110316 */
    DBI_SMALLINT     *parent1ProgNNF;        /* 1st parent criteria index (1st fk) */ /* PMSTA-11505 - LJE - 110316 */
    SMALLINT_T       *parent2ProgN;          /* 2nd parent criteria index (2nd fk) */ /* PMSTA-11505 - LJE - 110316 */
    DBI_SMALLINT     *parent2ProgNNF;        /* 2nd parent criteria index (2nd fk) */ /* PMSTA-11505 - LJE - 110316 */
} DBI_CRITER_ST, *DBI_CRITER_STP;

typedef struct DBI_PERM_VAL
{
    DICT_T              *dictId;
    DICT_T              *entDictId;  /* entity identifier                    */
    DICT_T              *attDictId;  /* unique attrib id. determined by dvp  */
    ENUM_T              *permVal;    /* permitted value itself (numeric)     */
    char                *name;       /* permitted value name                 */
    char                *label;      /* label in user language               */
    UChar               *uniLabel;   /* unicode label in user language      */
    SMALLINT_T          *rank;       /* display order of permitted value     */
    DICT_T              *refEntityDictId;
    ENUM_T              *permValRuleEn;
    ENUM_T              *dbRuleEn;
    XD_STATUS_ENUM      *xdStatusEn;
} DBI_PERM_VAL_ST, *DBI_PERM_VAL_STP;

typedef struct
{
    DICT_T          *dictId;
    char            *code;
    char            *name;
    char            *denom;
    char            *sqlName;
    char            *thousSep;
    char            *decimSep;
    char            *dateFmt;
    FLAG_T          *tslMultilingualFlg;
    char            *label;
    UChar           *uniLabel;
} DBI_LANG_ST, *DBI_LANG_STP;

typedef struct
{
    DICT_T          *dictId;
    char            *name;
    char            *label;
    UChar           *uniLabel;
    char            *sqlName;
    char            *equivType;
    char            *equivTypeSyb;
    char            *equivTypeOra;
    char            *equivTypeNuoDB;
    char            *equivTypeMsSql;
    char            *equivTypePgs;
    SMALLINT_T      *progN;
    FLAG_T          *custAuthFlg;
    SMALLINT_T      *defMaxDbLenN;
    SMALLINT_T      *defDefaultDisplayLenN;
} DBI_DATATP_ST, *DBI_DATATP_STP;

typedef struct
{
    DICT_T				*dictId;
    char 			    *name;
    char        	    *label;
    UChar               *uniLabel;
    char     			*procName;
    DICT_T				*parFctDictId;
    DICT_T              *entDictId;
    DICT_T              *orderEntryFctDictId;
    ENUM_T				*natEn;
    ID_T                *typeId;
    ID_T                *subtypeId;
    DICT_T				*refFctDictId;
    char    			*helpNode;
    char     			*iconName;
    SMALLINT_T			*rank;
    ID_T				*funcSecuProfId;
    DICT_T				*entityDictId;
    ENUM_T				*minOpStatus;
    ENUM_T				*maxOpStatus;
    ENUM_T				*securityLevel;
    FLAG_T				*createFlag;
    FLAG_T				*updateFlag;
    FLAG_T				*deleteFlag;
    FLAG_T				*riskViewFlag;
    FLAG_T				*realTimeFlag;
    FLAG_T				*viewFlag;
    FLAG_T				*visibleFlag;
    ENUM_T              *licenseKeyEn;
    ENUM_T              *accesStatus;


} DBI_FCT_ST, *DBI_FCT_STP;

STATIC int DBI_BindDictEntity(RequestHelper &, DBI_ENTITY_STP, bool);
STATIC int DBI_ReadDictEntity(RequestHelper &, DBI_ENTITY_STP);
STATIC void DBI_CopyToDictEntity(DICT_ENTITY_STP, DBI_ENTITY_STP);

STATIC int DBI_BindDictAttrib(RequestHelper &, DBI_ATTRIB_STP, bool);
STATIC int DBI_ReadDictAttrib(RequestHelper &, DBI_ATTRIB_STP);
STATIC void DBI_CopyToDictAttribute(DICT_ATTRIB_STP, DBI_ATTRIB_STP);

STATIC int DBI_BindDictCriteria(RequestHelper &, DBI_CRITER_STP, bool);
STATIC int DBI_ReadDictCriteria(RequestHelper &, DBI_CRITER_STP);
STATIC void DBI_CopyToDictCriteria(DICT_CRITER_STP, DBI_CRITER_STP);

STATIC int DBI_BindDictPermVal(RequestHelper &, DBI_PERM_VAL_STP, bool);
STATIC int DBI_ReadDictPermVal(RequestHelper &, DBI_PERM_VAL_STP);
STATIC void DBI_CopyToDictPermVal(DICT_PERM_VAL_STP, DBI_PERM_VAL_STP);

STATIC int DBI_BindDictLang(RequestHelper &, DBI_LANG_STP, bool);
STATIC int DBI_ReadDictLang(RequestHelper &, std::vector<DICT_LANG_ST> &, DBI_LANG_STP);

STATIC int DBI_BindDictFct(RequestHelper &, DBI_FCT_STP);
STATIC int DBI_ReadDictFct(RequestHelper &, std::vector<DICT_FCT_ST> &, DBI_FCT_STP);

STATIC int DBI_BindDictDataTp(RequestHelper &, DBI_DATATP_STP, bool);
STATIC int DBI_ReadDictDataTp(RequestHelper &, std::vector<DICT_DATATP_ST> &, DBI_DATATP_STP);


STATIC int DBI_BindDictEntityForMig(RequestHelper &, DBI_ENTITY_STP);
STATIC int DBI_BindDictAttribForMig(RequestHelper &, DBI_ATTRIB_STP);
STATIC int DBI_BindDictPermValForMig(RequestHelper &, DBI_PERM_VAL_STP);

/********************************************************************************
** FUNCTIONS USED TO LOAD THE META-DICTIONARY
*********************************************************************************/

/************************************************************************
*  Function             : DBI_LoadDictForGen()
*
*  Description          : Send the MD (Meta Dictionary) load request to
*                         the server and retrieve all informations in 5
*                         different result sets :
*
*                         - informations about all entities
*                         - informations about all entities attributes
*                         - informations about all attributes criteria
*                         - informations about all attributes permitted values
*                         - informations about all languages
*                         - informations about all functions
*                         - informations about all datatypes
*
*  Arguments            : None
*
*  Return               : RET_SUCCEED             : if ok
*                         RET_DBA_ERR_DBPROBLEM   : if problem with DB
*                         RET_DBA_ERR_SYBBIND     : if error while
*                                                   binding fields
*                         RET_DBA_ERR_SETPARAM    : if error while setting
*                                                   proc parameters.
*                         RET_DBA_ERR_MD          : if meta-dictionary
*                                                   is inconsistent
*                         RET_DBA_ERR_CONNOTFOUND : if no conn. found
*                         RET_MEM_ERR_ALLOC       : if memory alloc. failed
*
*  Creation date        : 
*  Last modification    : 
*
*************************************************************************/
RET_CODE DBI_LoadDictForGen(std::vector<DICT_LANG_ST>     &loadDictLangTab,
                            std::vector<DICT_DATATP_ST>& loadDictDataTpTab)
{
    DBI_ENTITY_ST    dbiEntityBindSt;
    DBI_ATTRIB_ST    dbiAttribBindSt;
    DBI_CRITER_ST    dbiCriterBindSt;
    DBI_LANG_ST      dictLangBind;
    DBI_DATATP_ST    dictDataTpBind;
    DBI_PERM_VAL_ST  dictPermValBindSt;

    SYS_Bzero(&dbiEntityBindSt, sizeof(DBI_ENTITY_ST));
    SYS_Bzero(&dbiAttribBindSt, sizeof(DBI_ATTRIB_ST));
    SYS_Bzero(&dbiCriterBindSt, sizeof(DBI_CRITER_ST));
    SYS_Bzero(&dictLangBind, sizeof(DBI_LANG_ST));
    SYS_Bzero(&dictDataTpBind, sizeof(DBI_DATATP_ST));
    SYS_Bzero(&dictPermValBindSt, sizeof(DBI_PERM_VAL_ST));

    DBA_RDBMS_ENUM            rdbmsEn = EV_TargetRdbmsVendor;
    bool                      bUseSourceEnv = false;

    if (EV_TargetDataSource.empty() || EV_GenDdlContext.bExtractData)
    {
        bUseSourceEnv = true;
        rdbmsEn = EV_SourceRdbmsVendor;
    }

    AAAConnectionDescription  desc(SqlServer, DBI_GetSqlServerNameByRdbms(rdbmsEn, bUseSourceEnv == false), ROLE_INIT, rdbmsEn);

    if (bUseSourceEnv &&
        EV_SourceApplOwner.empty() == false)
    {
        desc.setUser(EV_SourceApplOwner);
    }

    /* Get a free connection */
    DbiConnection* dbiConn = DBA_GetDbiConnection(desc);

    if (dbiConn == nullptr)
    {
        MSG_RETURN(RET_DBA_ERR_DBPROBLEM);
    }

    DbiConnectionHelper dbiConnHelper(dbiConn, true);

    if (dbiConnHelper.isValidAndInit() == false)
    {
        MSG_RETURN(RET_DBA_ERR_DBPROBLEM);
    }

    const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
    if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
    {
        auto &sqlTrace = dbiConnHelper.getConnection()->getSqlTrace();
        sqlTrace.m_procedure = "DynSql.LoadMetaDict";
        sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
    }

    {
        RequestHelper requestHelper(dbiConnHelper);
        requestHelper.setReadOnly(true);

        requestHelper.setCommand("select dict_id, name, sqlname_c, database_c, ref_auth_f, cust_auth_f, main_f, typing_nat, dict_entity_f, synonym_f, list_f, "
                                 "quick_search_f, logical_f, interface_e, audit_e, nature_index_n, parent_index_n, cust_database_c, "
                                 "precomp_database_c, precomp_f, use_precomp_f, precomp_std_format_id, precomp_usr_format_id, precomp_rank_n, "
                                 "short_sqlname_c, alias_sqlname_c, nature_e, last_modif_d, xd_status_e, security_level_e, automatic_mask, admin_fct_dict_id, "
                                 "pk_rule_e, delete_rule_e, last_modif_e, table_modif_stat_e, obj_modif_stat_e, db_sqlname_c, db_rule_e, "
                                 "linked_entity_dict_id, physical_entity_dict_id, load_dict_rule_e, copy_right_e, external_seq_auth_e, upd_fct_auth_e, active_auth_e, "
                                 "dml_modif_track_e, part_auth_e, dlm_auth_e, multi_entity_category_e from dict_entity e order by e.dict_id");

        /* Bind the DICT_ENTITY structure with the first result set */
        if (DBI_BindDictEntity(requestHelper, &dbiEntityBindSt, true) != TRUE)
        {
            MSG_RETURN(RET_DBA_ERR_SYBBIND);
        }

        if (RET_GET_LEVEL(requestHelper.sendCommandForFetch()) == RET_LEV_ERROR)
        {
            MSG_RETURN(RET_DBA_ERR_DBPROBLEM);
        }

        int readNbr = DBI_ReadDictEntity(requestHelper, &dbiEntityBindSt);

        if (readNbr == 0)
        {
            return(RET_DBA_ERR_MD);
        }
    }

    {
        RequestHelper requestHelper(dbiConnHelper);
        requestHelper.setReadOnly(true);
        requestHelper.setExternalMsgManagement(true);

        requestHelper.setCommand("select id, entity_dict_id from xd_entity e");

        requestHelper.addNewOutputData(IdType);
        requestHelper.getBindVariablePtr(dbiEntityBindSt.xdEntityId);
        requestHelper.addNewOutputData(DictType);
        requestHelper.getBindVariablePtr(dbiEntityBindSt.entDictId);

        if (RET_GET_LEVEL(requestHelper.sendCommandForFetch()) != RET_LEV_ERROR)
        {
            while (requestHelper.fetch() == RET_SUCCEED)
            {
                DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntityByDictId(*dbiEntityBindSt.entDictId);
                if (dictEntityStp != nullptr)
                {
                    dictEntityStp->xdEntityId = *dbiEntityBindSt.xdEntityId;
                }
            }
        }
    }

    {
        RequestHelper requestHelper(dbiConnHelper);
        requestHelper.setReadOnly(true);

        requestHelper.setCommand("select dict_id, name, entity_dict_id, datatype_dict_id, ref_entity_dict_id, parent_attribute_dict_id, sqlname_c, prog_n, prog_pk_n, "
                                 "disp_rank_n, primary_f, mandatory_f, db_mandatory_f, default_c, perm_val_f, business_key_f, logical_f, custom_f, calculated_e, "
                                 "perm_auth_f, edit_e, subtype_mask, quick_search_mask, search_mask, short_index_n, security_level_e, key_char_c, widget_e, "
                                 "max_db_len_n, default_display_len_n, tasc_view_e, object_attribute, entity_attribute, enum_attribute, enum_value, ref_entity_attribute_dict_id, "
                                 "fk_presentation_e, denom_language_dict_id, precomputed_f, vertical_search_f, vertical_pattern_f, multi_language_f, linked_attribute_dict_id, "
                                 "xd_status_e, ref_delete_rule_e, ref_security_rule_e, ref_check_rule_e, prog_bk_n, export_e, obj_modif_stat_e, feature_e, "
                                 "model_bank_e, me_specialisation_e, outbox_publish_e "
                                 "from dict_attribute a order by a.entity_dict_id, a.prog_n");

        /* Bind the DICT_ATTRIB structure with the second result set */
        if (DBI_BindDictAttrib(requestHelper, &dbiAttribBindSt, true) != TRUE)
        {
            MSG_RETURN(RET_DBA_ERR_SYBBIND);
        }

        if (RET_GET_LEVEL(requestHelper.sendCommandForFetch()) == RET_LEV_ERROR)
        {
            MSG_RETURN(RET_DBA_ERR_DBPROBLEM);
        }

        int readNbr = DBI_ReadDictAttrib(requestHelper, &dbiAttribBindSt);
        if (readNbr == 0)
        {
            return(RET_DBA_ERR_MD);
        }
    }

    {
        RequestHelper requestHelper(dbiConnHelper);
        requestHelper.setReadOnly(true);

        requestHelper.setCommand("select c.dict_id, c.entity_dict_id, c.dyn_nat_e, c.sqlname_c, c.attribute_dict_id, c.prog_n, "
                                 "c.sorting_rank_n, c.sorting_rule_e, c.fk_index_n, c.index_n, c.parent1_prog_n, c.parent2_prog_n "
                                 "from dict_criteria c inner join dict_entity e on e.dict_id = c.entity_dict_id order by e.dict_id, c.dict_id");

        /* Bind the DICT_CRITER structure with the third result set */
        if (DBI_BindDictCriteria(requestHelper, &dbiCriterBindSt, true) != TRUE)
        {
            return(RET_DBA_ERR_SYBBIND);
        }

        if (RET_GET_LEVEL(requestHelper.sendCommandForFetch()) == RET_LEV_ERROR)
        {
            MSG_RETURN(RET_DBA_ERR_DBPROBLEM);
        }

        int readNbr = DBI_ReadDictCriteria(requestHelper, &dbiCriterBindSt);
        if (readNbr == 0)
        {
            return(RET_DBA_ERR_MD);
        }
    }

    {
        RequestHelper requestHelper(dbiConnHelper);
        requestHelper.setReadOnly(true);

        requestHelper.setCommand("select p.dict_id, p.attribute_dict_id, p.perm_val_nat_e, p.name, p.rank_n, p.ref_entity_dict_id, p.perm_val_rule_e, p.xd_status_e, p.db_rule_e, a.entity_dict_id "
                                 "from dict_perm_value p inner join dict_attribute a on a.dict_id = p.attribute_dict_id "
                                 "inner join dict_entity e on e.dict_id = a.entity_dict_id order by e.dict_id, a.dict_id, p.rank_n");

        /* Bind the DICT_PERM_VAL structure with the forth result set */
        if (DBI_BindDictPermVal(requestHelper, &dictPermValBindSt, true) != TRUE)
        {
            return(RET_DBA_ERR_SYBBIND);
        }

        if (RET_GET_LEVEL(requestHelper.sendCommandForFetch()) == RET_LEV_ERROR)
        {
            MSG_RETURN(RET_DBA_ERR_DBPROBLEM);
        }

        int readNbr = DBI_ReadDictPermVal(requestHelper, &dictPermValBindSt);
        if (readNbr == 0)
        {
            return(RET_DBA_ERR_MD);
        }
    }

    {
        RequestHelper requestHelper(dbiConnHelper);
        requestHelper.setReadOnly(true);

        requestHelper.setCommand("select * from dict_language l order by l.dict_id");

        /* Bind the DICT_LANGUAGE structure with the fifth result set */
        if (DBI_BindDictLang(requestHelper, &dictLangBind, true) != TRUE)
        {
            return(RET_DBA_ERR_SYBBIND);
        }

        if (RET_GET_LEVEL(requestHelper.sendCommandForFetch()) == RET_LEV_ERROR)
        {
            MSG_RETURN(RET_DBA_ERR_DBPROBLEM);
        }

        (void)DBI_ReadDictLang(requestHelper, loadDictLangTab, &dictLangBind);
    }

    {
        RequestHelper requestHelper(dbiConnHelper);
        requestHelper.setReadOnly(true);

        requestHelper.setCommand("select dict_id, name, sqlname_c, "
                                 "equiv_type_c, equiv_type_syb_c, equiv_type_ora_c, equiv_type_nuodb_c, equiv_type_mssql_c, equiv_type_pgs_c, "
                                 "prog_n, cust_auth_f, def_max_db_len_n, def_default_display_len_n "
                                 "from dict_datatype d order by d.dict_id");

        /* Bind the DICT_DATATP structure with the 6th result set */
        if (DBI_BindDictDataTp(requestHelper, &dictDataTpBind, true) != TRUE)
        {
            return(RET_DBA_ERR_SYBBIND);
        }

        if (RET_GET_LEVEL(requestHelper.sendCommandForFetch()) == RET_LEV_ERROR)
        {
            MSG_RETURN(RET_DBA_ERR_DBPROBLEM);
        }

        int readNbr = DBI_ReadDictDataTp(requestHelper, loadDictDataTpTab, &dictDataTpBind);

        if (readNbr == 0)
        {
            return(RET_DBA_ERR_MD);
        }

        if (EV_TargetRdbmsVendor == Sqlite)
        {
            for (auto it = loadDictDataTpTab.begin(); it != loadDictDataTpTab.end(); ++it)
            {
                if (DATATYPE_DICT_TO_ENUM(it->dictId) == DictType ||
                    DATATYPE_DICT_TO_ENUM(it->dictId) == IdType)
                {
                    strcpy(it->equivType, "integer");
                }
            }
        }
    }

    if (EV_ExtractFile)
    {
        DATE_ResetTimer(&EV_ExtractFileTimer, TIMER_MASK_GEN);
        DATE_StartTimer(&EV_ExtractFileTimer, TIMER_MASK_GEN);
    }

    return(RET_SUCCEED);
}

/************************************************************************
*  Function             : DBI_LoadDict()
*
*  Description          : Send the MD (Meta Dictionary) load request to
*                         the server and retrieve all informations in 5
*                         different result sets :
*
*                         - informations about all entities
*                         - informations about all entities attributes
*                         - informations about all attributes criteria
*                         - informations about all attributes permitted values
*                         - informations about all languages
*                         - informations about all functions
*                         - informations about all datatypes
*
*  Arguments            : None
*
*  Global var. modified : (*loadDictEntityTabPtr) and (*&loadDictEntityRows)
*                         (*loadDictAttribTabPtr) and (*loadDictAttribRowsPtr)
*                         (*loadDictCriterTabPtr) and (*loadDictCriterRowsPtr)
*                         (*loadDictPermValTabPtr) and (*loadDictPermValRowsPtr)
*                         (*loadDictLangTabPtr) and (*loadDictLangRowsPtr)
*                         (*loadDictDataTpTabPtr) and (*loadDictDataTpRowsPtr)
*                         EV_DictFctTab and EV_DictFctRows
*
*  Return               : RET_SUCCEED             : if ok
*                         RET_DBA_ERR_DBPROBLEM   : if problem with DB
*                         RET_DBA_ERR_SYBBIND     : if error while
*                                                   binding fields
*                         RET_DBA_ERR_SETPARAM    : if error while setting
*                                                   proc parameters.
*                         RET_DBA_ERR_MD          : if meta-dictionary
*                                                   is inconsistent
*                         RET_DBA_ERR_CONNOTFOUND : if no conn. found
*                         RET_MEM_ERR_ALLOC       : if memory alloc. failed
*
*  Creation date        : June 94  - PEC
*  Last modification    : Sept 94  - PEC - Now load dict_language table
*                         31.8.95  - PEC - Added correct Return codes
*                         20.10.95 - RAK - Added load functions and datatypes
*                         ROI - 961112 - DVP245
*                         ROI - 970221 - DVP033
*                         PMSTA-16293 - 210513 - PMO : Update source code - fix build
*                         PMSTA-17334 - 101213 - PMO : Installation from scratch of CIP_RHEL failed
*
*************************************************************************/
RET_CODE DBI_LoadDict(std::vector<DICT_LANG_ST>& loadDictLangTab,
                      std::vector<DICT_DATATP_ST>& loadDictDataTpTab)
{

    if (SYS_IsDdlGenMode() == TRUE)
    {
        if (EV_GenDdlContext.infoPtr != nullptr &&
            strcmp(EV_GenDdlContext.infoPtr, "c") == 0)
        {
            return RET_SUCCEED;
        }
        return DBI_LoadDictForGen(loadDictLangTab, loadDictDataTpTab);
    }

    DBI_ENTITY_ST    dbiEntityBindSt;
    DBI_ATTRIB_ST    dbiAttribBindSt;
    DBI_CRITER_ST    dbiCriterBindSt;
    DBI_LANG_ST      dictLangBind;
    DBI_DATATP_ST    dictDataTpBind;
    DBI_PERM_VAL_ST  dictPermValBindSt;

    int				 retCode = 0;

    SYS_Bzero(&dbiEntityBindSt, sizeof(DBI_ENTITY_ST));
    SYS_Bzero(&dbiAttribBindSt, sizeof(DBI_ATTRIB_ST));
    SYS_Bzero(&dbiCriterBindSt, sizeof(DBI_CRITER_ST));
    SYS_Bzero(&dictLangBind, sizeof(DBI_LANG_ST));
    SYS_Bzero(&dictDataTpBind, sizeof(DBI_DATATP_ST));
    SYS_Bzero(&dictPermValBindSt, sizeof(DBI_PERM_VAL_ST));

    /* Get a free connection */
    DbiConnectionHelper dbiConnHelper(AAATransactionEnum::NotTransactionnal, DBA_SERVER_TYPE_ENUM::SqlServer, ROLE_INIT);

    if (dbiConnHelper.isValidAndInit() == false)
    {
        MSG_RETURN(RET_DBA_ERR_DBPROBLEM);
    }

    RequestHelper requestHelper(dbiConnHelper);
    requestHelper.setReadOnly(true);

    const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
    if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
    {
        auto& sqlTrace = dbiConnHelper.getConnection()->getSqlTrace();
        sqlTrace.m_procedure = "DynSql.LoadMetaDict";
        sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
    }

    requestHelper.setCommand("#EXEC load_meta_dict ?");

    if (EV_AAAInstallLevel)
    {
        if (SYS_IsDdlGenMode() == TRUE)
        {
            requestHelper.addNewParamCharPtr("generator", SysnameType);
        }
        else
        {
            requestHelper.addNewParamCharPtr("run_aaa_install", SysnameType);
        }
    }
    else
    {
        requestHelper.addNewParamCharPtr("", SysnameType);
    }

    /* Bind the DICT_ENTITY structure with the first result set */
    if (DBI_BindDictEntity(requestHelper, &dbiEntityBindSt, false) != TRUE)
    {
        MSG_RETURN(RET_DBA_ERR_SYBBIND);
    }

    /* Bind the DICT_ATTRIB structure with the second result set */
    if (DBI_BindDictAttrib(requestHelper, &dbiAttribBindSt, false) != TRUE)
    {
        MSG_RETURN(RET_DBA_ERR_SYBBIND);
    }

    /* Bind the DICT_CRITER structure with the third result set */
    if (DBI_BindDictCriteria(requestHelper, &dbiCriterBindSt, false) != TRUE)
    {
        return(RET_DBA_ERR_SYBBIND);
    }

    /* Bind the DICT_PERM_VAL structure with the forth result set */
    if (DBI_BindDictPermVal(requestHelper, &dictPermValBindSt, false) != TRUE)
    {
        return(RET_DBA_ERR_SYBBIND);
    }

    /* Bind the DICT_LANGUAGE structure with the fifth result set */
    if (DBI_BindDictLang(requestHelper, &dictLangBind, false) != TRUE)
    {
        return(RET_DBA_ERR_SYBBIND);
    }

    /* Bind the DICT_DATATP structure with the 6th result set */
    if (DBI_BindDictDataTp(requestHelper, &dictDataTpBind, false) != TRUE)
    {
        return(RET_DBA_ERR_SYBBIND);
    }

    if (requestHelper.sendCommandForFetch() != RET_SUCCEED)
    {
        MSG_RETURN(RET_DBA_ERR_DBPROBLEM);
    }

    retCode = DBI_ReadDictEntity(requestHelper, &dbiEntityBindSt);

    if (retCode == 0)
    {
        return(RET_DBA_ERR_MD);
    }

    /******************************************************************/
    /* Verify the attribute result set */
    if (requestHelper.getLastResultType() != DBI_ROW_RESULT)
    {
        MSG_RETURN(RET_DBA_ERR_DBPROBLEM);
    }

    retCode = DBI_ReadDictAttrib(requestHelper, &dbiAttribBindSt);
    if (retCode == 0)
    {
        return(RET_DBA_ERR_MD);
    }

    /******************************************************************/
    /* Verify the criteria result set */
    if (requestHelper.getLastResultType() != DBI_ROW_RESULT)
    {
        MSG_RETURN(RET_DBA_ERR_DBPROBLEM);
    }

    retCode = DBI_ReadDictCriteria(requestHelper, &dbiCriterBindSt);
    if (retCode == 0)
    {
        return(RET_DBA_ERR_MD);
    }

    /* Verify the language result set */
    if (requestHelper.getLastResultType() != DBI_ROW_RESULT)
    {
        MSG_RETURN(RET_DBA_ERR_DBPROBLEM);
    }

    /******************************************************************/
    /* Verify the permitted values result set */
    if (requestHelper.getLastResultType() != DBI_ROW_RESULT)
    {
        MSG_RETURN(RET_DBA_ERR_DBPROBLEM);
    }

    retCode = DBI_ReadDictPermVal(requestHelper, &dictPermValBindSt);
    if (retCode == 0)
    {
        return(RET_DBA_ERR_MD);
    }

    /******************************************************************/
    /* Verify the language result set */
    if (requestHelper.getLastResultType() != DBI_ROW_RESULT)
    {
        MSG_RETURN(RET_DBA_ERR_DBPROBLEM);
    }

    retCode = DBI_ReadDictLang(requestHelper, loadDictLangTab, &dictLangBind);
    if (retCode == 0)
    {
        return(RET_DBA_ERR_MD);
    }

    /******************************************************************/
    /* Verify the data types result set */
    if (requestHelper.getLastResultType() != DBI_ROW_RESULT)
    {
        MSG_RETURN(RET_DBA_ERR_DBPROBLEM);
    }

    retCode = DBI_ReadDictDataTp(requestHelper, loadDictDataTpTab, &dictDataTpBind);

    if (retCode == 0)
    {
        return(RET_DBA_ERR_MD);
    }

    if (EV_ExtractFile)
    {
        DATE_ResetTimer(&EV_ExtractFileTimer, TIMER_MASK_GEN);
        DATE_StartTimer(&EV_ExtractFileTimer, TIMER_MASK_GEN);
    }

    return(RET_SUCCEED);
}

/************************************************************************
*  Function             : DBI_LoadDictForSql()
*
*  Description          : Send the MD (Meta Dictionary) load request to
*                         the server and retrieve all informations in 5
*                         different result sets :
*
*                         - informations about all entities
*                         - informations about all entities attributes
*                         - informations about all attributes criteria
*                         - informations about all attributes permitted values
*                         - informations about all languages
*                         - informations about all functions
*                         - informations about all datatypes
*
*  Arguments            : None
*
*  Global var. modified : (*loadDictEntityTabPtr) and (*&loadDictEntityRows)
*                         (*loadDictAttribTabPtr) and (*loadDictAttribRowsPtr)
*                         (*loadDictCriterTabPtr) and (*loadDictCriterRowsPtr)
*                         (*loadDictPermValTabPtr) and (*loadDictPermValRowsPtr)
*                         (*loadDictLangTabPtr) and (*loadDictLangRowsPtr)
*                         (*loadDictDataTpTabPtr) and (*loadDictDataTpRowsPtr)
*                         EV_DictFctTab and EV_DictFctRows
*
*  Return               : RET_SUCCEED             : if ok
*                         RET_DBA_ERR_DBPROBLEM   : if problem with DB
*                         RET_DBA_ERR_SYBBIND     : if error while
*                                                   binding fields
*                         RET_DBA_ERR_SETPARAM    : if error while setting
*                                                   proc parameters.
*                         RET_DBA_ERR_MD          : if meta-dictionary
*                                                   is inconsistent
*                         RET_DBA_ERR_CONNOTFOUND : if no conn. found
*                         RET_MEM_ERR_ALLOC       : if memory alloc. failed
*
*  Creation date        : June 94  - PEC
*  Last modification    : Sept 94  - PEC - Now load dict_language table
*                         31.8.95  - PEC - Added correct Return codes
*                         20.10.95 - RAK - Added load functions and datatypes
*                         ROI - 961112 - DVP245
*                         ROI - 970221 - DVP033
*                         PMSTA-16293 - 210513 - PMO : Update source code - fix build
*                         PMSTA-17334 - 101213 - PMO : Installation from scratch of CIP_RHEL failed
*
*************************************************************************/
RET_CODE DBI_LoadDictForSql(std::vector<DICT_LANG_ST>     &loadDictLangTab,
                            std::vector<DICT_DATATP_ST>   &loadDictDataTpTab)
{
    DBI_ENTITY_ST    oraEntityBindSt;
    DBI_ATTRIB_ST    oraAttribBindSt;
    DBI_CRITER_ST    oraCriterBindSt;
    DBI_LANG_ST      dictLangBind;
    DBI_DATATP_ST    dictDataTpBind;
    int				 retCode = 0;

    SYS_Bzero(&oraEntityBindSt, sizeof(DBI_ENTITY_ST));
    SYS_Bzero(&oraAttribBindSt, sizeof(DBI_ATTRIB_ST));
    SYS_Bzero(&oraCriterBindSt, sizeof(DBI_CRITER_ST));
    SYS_Bzero(&dictLangBind, sizeof(DBI_LANG_ST));
    SYS_Bzero(&dictDataTpBind, sizeof(DBI_DATATP_ST));

    /* Get a free connection */
    DbiConnectionHelper dbiConnHelper(AAATransactionEnum::NotTransactionnal, DBA_SERVER_TYPE_ENUM::SqlServer, ROLE_INIT);

    if (dbiConnHelper.isValidAndInit() == false)
    {
        MSG_RETURN(RET_DBA_ERR_DBPROBLEM);
    }

    RequestHelper requestHelper(dbiConnHelper);
    requestHelper.setReadOnly(true);

    const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
    if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
    {
        auto &sqlTrace = dbiConnHelper.getConnection()->getSqlTrace();
        sqlTrace.m_procedure = "DynSql.LoadDictForSql";
        sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
    }

    requestHelper.setCommand("#EXEC load_meta_dict_for_sql");

    /* Bind the DICT_ENTITY structure with the first result set */
    if (DBI_BindDictEntity(requestHelper, &oraEntityBindSt, false) != TRUE)
    {
        MSG_RETURN(RET_DBA_ERR_SYBBIND);
    }

    /* Bind the DICT_ATTRIB structure with the second result set */
    if (DBI_BindDictAttrib(requestHelper, &oraAttribBindSt, false) != TRUE)
    {
        MSG_RETURN(RET_DBA_ERR_SYBBIND);
    }

    /* Bind the DICT_CRITER structure with the third result set */
    if (DBI_BindDictCriteria(requestHelper, &oraCriterBindSt, false) != TRUE)
    {
        return(RET_DBA_ERR_SYBBIND);
    }

    /* Bind the DICT_LANGUAGE structure with the fifth result set */
    if (DBI_BindDictLang(requestHelper, &dictLangBind, false) != TRUE)
    {
        return(RET_DBA_ERR_SYBBIND);
    }

    /* Bind the DICT_DATATP structure with the 6th result set */
    if (DBI_BindDictDataTp(requestHelper, &dictDataTpBind, false) != TRUE)
    {
        return(RET_DBA_ERR_SYBBIND);
    }

    if (requestHelper.sendCommandForFetch() != RET_SUCCEED)
    {
        MSG_RETURN(RET_DBA_ERR_DBPROBLEM);
    }

    retCode = DBI_ReadDictEntity(requestHelper, &oraEntityBindSt);

    if (retCode == 0)
    {
        return(RET_DBA_ERR_MD);
    }

    /******************************************************************/
    /* Verify the attribute result set */
    if (requestHelper.getLastResultType() != DBI_ROW_RESULT)
    {
        MSG_RETURN(RET_DBA_ERR_DBPROBLEM);
    }

    retCode = DBI_ReadDictAttrib(requestHelper, &oraAttribBindSt);
    if (retCode == 0)
    {
        return(RET_DBA_ERR_MD);
    }

    /******************************************************************/
    /* Verify the criteria result set */
    if (requestHelper.getLastResultType() != DBI_ROW_RESULT)
    {
        MSG_RETURN(RET_DBA_ERR_DBPROBLEM);
    }

    retCode = DBI_ReadDictCriteria(requestHelper, &oraCriterBindSt);
    if (retCode == 0)
    {
        return(RET_DBA_ERR_MD);
    }

    /* Verify the language result set */
    if (requestHelper.getLastResultType() != DBI_ROW_RESULT)
    {
        MSG_RETURN(RET_DBA_ERR_DBPROBLEM);
    }

    retCode = DBI_ReadDictLang(requestHelper, loadDictLangTab, &dictLangBind);
    if (retCode == 0)
    {
        return(RET_DBA_ERR_MD);
    }

    /*****************************************************************/
    /* Verify the data-type result set */
    if (requestHelper.getLastResultType() != DBI_ROW_RESULT)
    {
        MSG_RETURN(RET_DBA_ERR_DBPROBLEM);
    }

    retCode = DBI_ReadDictDataTp(requestHelper, loadDictDataTpTab, &dictDataTpBind);

    if (retCode == 0)
    {
        return(RET_DBA_ERR_MD);
    }

    return(RET_SUCCEED);
}

/************************************************************************
*  Function             : DBI_LoadDictForMig()
*
*  Description          : Send the MD (Meta Dictionary) load request to
*                         the server and retrieve all informations in 5
*                         different result sets :
*
*                         - informations about all entities
*                         - informations about all entities attributes
*                         - informations about all attributes permitted values
*                         - informations about all datatypes
*
*  Arguments            : None
*
*  Global var. modified : (*loadDictEntityTabPtr) and (*&loadDictEntityRows)
*                         (*loadDictAttribTabPtr) and (*loadDictAttribRowsPtr)
*                         (*loadDictPermValTabPtr) and (*loadDictPermValRowsPtr)
*                         (*loadDictDataTpTabPtr) and (*loadDictDataTpRowsPtr)
*
*  Return               : RET_SUCCEED             : if ok
*                         RET_DBA_ERR_DBPROBLEM   : if problem with DB
*                         RET_DBA_ERR_SYBBIND     : if error while
*                                                   binding fields
*                         RET_DBA_ERR_SETPARAM    : if error while setting
*                                                   proc parameters.
*                         RET_DBA_ERR_MD          : if meta-dictionary
*                                                   is inconsistent
*                         RET_DBA_ERR_CONNOTFOUND : if no conn. found
*                         RET_MEM_ERR_ALLOC       : if memory alloc. failed
*
*  Creation date        : PMSTA-37374 - LJE - 210408
*  Last modification    :
*
*************************************************************************/
RET_CODE DBI_LoadDictForMig()
{
    DBI_ENTITY_ST    dbiEntityBindSt;
    DBI_ATTRIB_ST    dbiAttribBindSt;
    DBI_DATATP_ST    dictDataTpBind;
    DBI_PERM_VAL_ST  dictPermValBindSt;

    int				 retCode = 0;

    SYS_Bzero(&dbiEntityBindSt, sizeof(DBI_ENTITY_ST));
    SYS_Bzero(&dbiAttribBindSt, sizeof(DBI_ATTRIB_ST));
    SYS_Bzero(&dictDataTpBind, sizeof(DBI_DATATP_ST));
    SYS_Bzero(&dictPermValBindSt, sizeof(DBI_PERM_VAL_ST));

    DBA_RDBMS_ENUM            rdbmsEn = EV_SourceRdbmsVendor;
    AAAConnectionDescription  desc(SqlServer, DBI_GetSqlServerNameByRdbms(rdbmsEn, false), ROLE_INIT, rdbmsEn);

    if (EV_SourceContext != nullptr)
    {
        desc.setDatabase(EV_SourceContext->getMainDbName());
    }

    if (EV_SourceApplOwner.empty() == false)
    {
        desc.setUser(EV_SourceApplOwner);
    }

    /* Get a free connection */
    DbiConnection            *dbiConn = DBA_GetDbiConnection(desc);

    if (dbiConn == nullptr)
    {
        MSG_RETURN(RET_DBA_ERR_DBPROBLEM);
    }

    DbiConnectionHelper dbiConnHelper(dbiConn, true);

    if (dbiConnHelper.isValidAndInit() == false)
    {
        MSG_RETURN(RET_DBA_ERR_DBPROBLEM);
    }

    RequestHelper requestHelper(dbiConnHelper);
    requestHelper.setReadOnly(true);

    const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
    if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
    {
        auto &sqlTrace = dbiConnHelper.getConnection()->getSqlTrace();
        sqlTrace.m_procedure = "DynSql.LoadMetaDictForMig";
        sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
    }

    requestHelper.setCommand("select dict_id, sqlname_c, sqlname_c, nature_e, cust_auth_f, database_c, precomp_f, use_precomp_f from dict_entity order by dict_id");

    /* Bind the DICT_ENTITY structure with the first result set */
    if (DBI_BindDictEntityForMig(requestHelper, &dbiEntityBindSt) != TRUE)
    {
        MSG_RETURN(RET_DBA_ERR_SYBBIND);
    }

    if (requestHelper.sendCommandForFetch() != RET_SUCCEED)
    {
        MSG_RETURN(RET_DBA_ERR_DBPROBLEM);
    }

    retCode = DBI_ReadDictEntity(requestHelper, &dbiEntityBindSt);

    if (retCode == 0)
    {
        return(RET_DBA_ERR_MD);
    }

    requestHelper.finishRequest();

    if (rdbmsEn == Sqlite)
    {
        map<string, string> databaseConvertMap;

        for (auto &it : AaaMetaDict::getDictEntityVector())
        {
            if (it->entDictId == 100)
            {
                databaseConvertMap[it->databaseName] = "AAAMAIN_DB";
            }
            else if (it->entDictId == 112)
            {
                databaseConvertMap[it->databaseName] = "AAALOGIN_DB";
            }
            else if (it->entDictId == 2508)
            {
                databaseConvertMap[it->databaseName] = "TSL_PERM_DB";
            }
            else if (it->entNatEn == EntityNat_ReportFmt)
            {
                databaseConvertMap[it->databaseName] = "AAAREP_DB";
            }
        }

        for (auto& it : AaaMetaDict::getDictEntityVector())
        {
            it->databaseName  = databaseConvertMap[it->databaseName];
        }
    }

    requestHelper.setCommand("select dict_id, entity_dict_id, datatype_dict_id , sqlname_c, prog_n, prog_pk_n, primary_f, business_key_f, db_mandatory_f, default_c, logical_f, custom_f, calculated_e, max_db_len_n, precomputed_f "
                             "from dict_attribute order by entity_dict_id, prog_n");

    /* Bind the DICT_ATTRIB structure with the second result set */
    if (DBI_BindDictAttribForMig(requestHelper, &dbiAttribBindSt) != TRUE)
    {
        MSG_RETURN(RET_DBA_ERR_SYBBIND);
    }

    if (requestHelper.sendCommandForFetch() != RET_SUCCEED)
    {
        MSG_RETURN(RET_DBA_ERR_DBPROBLEM);
    }

    retCode = DBI_ReadDictAttrib(requestHelper, &dbiAttribBindSt);
    if (retCode == 0)
    {
        return(RET_DBA_ERR_MD);
    }

    requestHelper.finishRequest();

    requestHelper.setCommand("select dpv.dict_id, dpv.attribute_dict_id, dpv.perm_val_nat_e, dpv.rank_n, da.entity_dict_id "
                             "from dict_perm_value dpv inner join dict_attribute da on da.dict_id = dpv.attribute_dict_id "
                             "order by da.entity_dict_id, da.prog_n, dpv.rank_n");

    /* Bind the DICT_PERM_VAL structure with the forth result set */
    if (DBI_BindDictPermValForMig(requestHelper, &dictPermValBindSt) != TRUE)
    {
        return(RET_DBA_ERR_SYBBIND);
    }

    if (requestHelper.sendCommandForFetch() != RET_SUCCEED)
    {
        MSG_RETURN(RET_DBA_ERR_DBPROBLEM);
    }

    /******************************************************************/
    retCode = DBI_ReadDictPermVal(requestHelper, &dictPermValBindSt);
    if (retCode == 0)
    {
        return(RET_DBA_ERR_MD);
    }

    DBA_MoveDictEntityToSource();

    return(RET_SUCCEED);
}

/************************************************************************
*  Function             : DBI_LoadDictFct()
*
*  Description          : Load dict function block from database
*
*  Arguments            : None
*
*
*  Return               : RET_SUCCEED             : if ok
*                         RET_DBA_ERR_DBPROBLEM   : if problem with DB
*                         RET_DBA_ERR_SYBBIND     : if error while
*                                                   binding fields
*                         RET_DBA_ERR_SETPARAM    : if error while setting
*                                                   proc parameters.
*                         RET_DBA_ERR_MD          : if meta-dictionary
*                                                   is inconsistant
*                         RET_DBA_ERR_CONNOTFOUND : if no conn. found
*                         RET_MEM_ERR_ALLOC       : if memory alloc. failed
*
*************************************************************************/
RET_CODE DBI_LoadDictFct()
{
    DBI_FCT_ST       dictFctBind;
    int              retCode = RET_SUCCEED;

    SYS_Bzero(&dictFctBind, sizeof(DBI_FCT_ST));

    /* Get a free connection */
    DbiConnectionHelper dbiConnHelper(AAATransactionEnum::NotTransactionnal, DBA_SERVER_TYPE_ENUM::SqlServer, ROLE_INIT);

    if (dbiConnHelper.isValidAndInit() == false)
    {
        MSG_RETURN(RET_DBA_ERR_DBPROBLEM);
    }

    RequestHelper requestHelper(dbiConnHelper);
    requestHelper.setReadOnly(true);

    const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
    if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
    {
        auto &sqlTrace = dbiConnHelper.getConnection()->getSqlTrace();
        sqlTrace.m_procedure = "DynSql.LoadDictFct";
        sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
    }

    requestHelper.setCommand("#EXEC dump_dict_function");

    /*****************************************************************/
    /* Verify the entity result set */
    /* Bind the DICT_FCT structure with the result set */
    if (DBI_BindDictFct(requestHelper, &dictFctBind) != TRUE)
    {
        return(RET_DBA_ERR_SYBBIND);
    }

    retCode = requestHelper.sendCommandForFetch();
    if (retCode != RET_SUCCEED)
    {
        return(RET_DBA_ERR_MD);
    }

    if (DBI_ReadDictFct(requestHelper, EV_DictFctTab, &dictFctBind) == 0)
    {
        return(RET_DBA_ERR_MD);
    }

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   DBI_ConvertToASCII()
**
**  Description : Call ICU4AAA_ConvertToDefaultCharSet
**
**  Argument : source
**                  target
**                  capacity
**                  written
**
**  Return : None
**
**  Last modif. : PMSTA - 16326 - 080513 - PMO : Missing French translations in the Triple'A GUI domain screen on UNICODE environment.
**
*************************************************************************/
STATIC void DBI_ConvertToASCII(const UChar *source, char *target, unsigned int capacity)
{
    char *text = NULL;

    if (ICU4AAA_ConvertToDefaultCharSet(source, -1, &text, NULL) == 0)
    { /* Ok */
        if (SYS_StrLen(text) < capacity)
        { /* Ok */
            strcpy(target, text);
        }
        else
        { /* Error */
            target[0] = 0;
        }

        FREE(text);
    }
    else
    { /* Error */
        target[0] = 0;
    }
}

/************************************************************************
**
**  Function    :   DBI_ConvertFromASCII()
**
**  Description :   Like ICU4AAA_ConvertFromASCII but with static handle, only
**                  for load meta-dict
**
**  Argument    :   source
**                  length
**                  target
**                  capacity
**                  written
**
**  Return      :   0 on success, -1 elsewhere
**
**
*************************************************************************/
STATIC int DBI_ConvertFromASCII(const char *source, int length, UChar *target, int capacity, int *written)
{
    static UConverter *handle = NULL;

    UErrorCode
        status = U_ZERO_ERROR;

    int  size;
    int count;

    if (handle == NULL)
    {
        if ((handle = ucnv_open("ASCII", &status)) == NULL || U_FAILURE(status))
            return -1;
    }

    if (capacity == 0 && length != 0)
    {
        if (written != NULL)
            *written = 0;

        return -1;
    }

    if (length == -1)
    {
        size =
            (int)strlen(source);

        capacity--;
    }
    else
        size = length;

    ucnv_setFromUCallBack(handle,
                          UCNV_FROM_U_CALLBACK_STOP,
                          NULL,
                          NULL,
                          NULL,
                          &status);
    count =
        ucnv_toUChars(
            handle, target, capacity,
            source, size, &status);

    if (U_FAILURE(status))
    {
        if (written != NULL)
            *written = 0;
        target[0] = 0;

        return -1;
    }

    if (length == -1)
        target[count++] = 0;

    if (written != NULL)
        *written = count;

    return 0;
}

/************************************************************************
*   Function             : DBI_BindDictEntity()
*
*   Description          : Bind all columns of the first result set
*                          (dict_entity) with the DICT_ENTITY structure
*
*   Arguments            : connectNo : the connection number in the connection
*                                      list.
*                          bindStEn    : the DICT_ENTITY structure used to bind
*                                      result set columns.
*
*   Global var. modified : None
*
*   Return               : TRUE if ok
*                          FALSE if problem
*
*
*************************************************************************/
STATIC int DBI_BindDictEntity(RequestHelper &requestHelper, DBI_ENTITY_STP bindStp, bool bSingleRequest)
{
    requestHelper.addNewOutputData(DictType);
    requestHelper.getBindVariablePtr(bindStp->entDictId);
    requestHelper.addNewOutputData(NameType);
    requestHelper.getBindVariablePtr(bindStp->name);
    requestHelper.addNewOutputData(SysnameType);
    requestHelper.getBindVariablePtr(bindStp->sqlName);
    requestHelper.addNewOutputData(SysnameType);
    requestHelper.getBindVariablePtr(bindStp->dbName);
    requestHelper.addNewOutputData(FlagType);
    requestHelper.getBindVariablePtr(bindStp->refAuthFlg);
    requestHelper.addNewOutputData(FlagType);
    requestHelper.getBindVariablePtr(bindStp->custAuthFlg);
    requestHelper.addNewOutputData(FlagType);
    requestHelper.getBindVariablePtr(bindStp->mainFlg);
    requestHelper.addNewOutputData(FlagType);
    requestHelper.getBindVariablePtr(bindStp->tpNatEn);
    requestHelper.addNewOutputData(FlagType);
    requestHelper.getBindVariablePtr(bindStp->entDictIdFlg);
    requestHelper.addNewOutputData(FlagType);
    requestHelper.getBindVariablePtr(bindStp->synonFlg);
    requestHelper.addNewOutputData(FlagType);
    requestHelper.getBindVariablePtr(bindStp->listFlg);
    requestHelper.addNewOutputData(FlagType);
    requestHelper.getBindVariablePtr(bindStp->qSearchFlg);
    requestHelper.addNewOutputData(FlagType);
    requestHelper.getBindVariablePtr(bindStp->logicalFlg);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->interf);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->auditAuthEn);
    requestHelper.addNewOutputData(TinyintType);
    requestHelper.getBindVariablePtr(bindStp->natIndex, bindStp->natIndexNF);
    requestHelper.addNewOutputData(TinyintType);
    requestHelper.getBindVariablePtr(bindStp->parIndex, bindStp->parIndexNF);
    requestHelper.addNewOutputData(SysnameType);
    requestHelper.getBindVariablePtr(bindStp->custDbName);
    requestHelper.addNewOutputData(SysnameType);
    requestHelper.getBindVariablePtr(bindStp->precompDbName);
    requestHelper.addNewOutputData(FlagType);
    requestHelper.getBindVariablePtr(bindStp->precompFlg);
    requestHelper.addNewOutputData(FlagType);
    requestHelper.getBindVariablePtr(bindStp->usePrecompFlg);
    requestHelper.addNewOutputData(IdType);
    requestHelper.getBindVariablePtr(bindStp->precompStdFormatId);
    requestHelper.addNewOutputData(IdType);
    requestHelper.getBindVariablePtr(bindStp->precompUsrFormatId);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->precompRankN);
    requestHelper.addNewOutputData(SysnameType);
    requestHelper.getBindVariablePtr(bindStp->shortSqlname);
    requestHelper.addNewOutputData(SysnameType);
    requestHelper.getBindVariablePtr(bindStp->aliasSqlname);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->entNatEn);
    requestHelper.addNewOutputData(DatetimeType);
    requestHelper.getBindVariablePtr(bindStp->lastModifDate);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->xdStatusEn);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->securityLevelEn);
    requestHelper.addNewOutputData(IntType);
    requestHelper.getBindVariablePtr(bindStp->automaticMask);
    requestHelper.addNewOutputData(DictType);
    requestHelper.getBindVariablePtr(bindStp->adminFctDictId);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->pkRuleEn);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->deleteRuleEn);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->lastModifEn);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->tableModifStatEn);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->objModifStatEn);
    requestHelper.addNewOutputData(SysnameType);
    requestHelper.getBindVariablePtr(bindStp->dbSqlName);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->dbRuleEn);
    requestHelper.addNewOutputData(IdType);
    requestHelper.getBindVariablePtr(bindStp->linkedEntityDictId);
    requestHelper.addNewOutputData(IdType);
    requestHelper.getBindVariablePtr(bindStp->physicalEntityDictId);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->loadDictRuleEn);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->copyRightEn);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->externalSeqAuthEn);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->updFctAuthEn);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->activeAuthEn);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->dmlModifTrackEn);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->partAuthEn);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->dlmAuthEn);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->multiEntityCategEn);

    if (bSingleRequest == false)
    {
        requestHelper.addNewOutputData(IdType);
        requestHelper.getBindVariablePtr(bindStp->xdEntityId);

        if (ICU4AAA_SQLServerUTF8)
        {
            requestHelper.addNewOutputData(UniString1000Type);
            requestHelper.getBindVariablePtr(bindStp->uniLabel);
        }
        else
        {
            requestHelper.addNewOutputData(String1000Type);
            requestHelper.getBindVariablePtr(bindStp->label);
        }
    }
    return(TRUE);
}

/************************************************************************
*   Function             : DBI_BindDictEntityForMig()
*
*   Description          : Bind all columns of the first result set
*                          (dict_entity) with the DICT_ENTITY structure
*
*   Arguments            : connectNo : the connection number in the connection
*                                      list.
*                          bindStEn    : the DICT_ENTITY structure used to bind
*                                      result set columns.
*
*   Global var. modified : None
*
*   Return               : TRUE if ok
*                          FALSE if problem
*
*
*************************************************************************/
STATIC int DBI_BindDictEntityForMig(RequestHelper &requestHelper, DBI_ENTITY_STP bindStp)
{
    requestHelper.addNewOutputData(DictType);
    requestHelper.getBindVariablePtr(bindStp->entDictId);

    requestHelper.addNewOutputData(SysnameType);
    requestHelper.getBindVariablePtr(bindStp->sqlName);

    requestHelper.addNewOutputData(SysnameType);
    requestHelper.getBindVariablePtr(bindStp->dbSqlName);

    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->entNatEn);

    requestHelper.addNewOutputData(FlagType);
    requestHelper.getBindVariablePtr(bindStp->custAuthFlg);

    requestHelper.addNewOutputData(SysnameType);
    requestHelper.getBindVariablePtr(bindStp->dbName);

    requestHelper.addNewOutputData(FlagType);
    requestHelper.getBindVariablePtr(bindStp->precompFlg);

    requestHelper.addNewOutputData(FlagType);
    requestHelper.getBindVariablePtr(bindStp->usePrecompFlg);

    return(TRUE);
}

/************************************************************************
*   Function             : DBI_ReadDictEntity()
*
*   Description          : Read all columns of the first result set
*
*   Arguments            : connectNo     : the connection number in the
*                                          connection list.
*                          dictEntityPtr : pointer on a DICT_ENTITY structure
*                          dictEntityMax : Maximum entries into the array dictEntityPtr
*                          bindStEn        : the DICT_ENTITY structure used
*                                          to bind result set columns.
*
*   Global var. modified : None
*
*   Return               : TRUE if ok
*
*
*************************************************************************/
STATIC int DBI_ReadDictEntity(RequestHelper &requestHelper, DBI_ENTITY_STP bindStp)
{
    OBJECT_ENUM objectEn = static_cast<OBJECT_ENUM>(AaaMetaDict::getDictEntityVector().size());
    while (requestHelper.fetch() == RET_SUCCEED)
    {
        DICT_ENTITY_ST &dictEntitySt = DICT_AddNewDictEntity(*bindStp->entDictId, objectEn++, bindStp->sqlName, bindStp->dbSqlName);
        DBI_CopyToDictEntity(&dictEntitySt, bindStp);
    }
    return((int)DICT_GetDictEntityVector().size());
}

/************************************************************************
*   Function             : DBI_CopyToDictEntity()
*
*   Description          : Copy the binding structure (SYB_ENTITY) to the DICT_ENTITY structure
*
*   Arguments            : dictEntityStp : the DICT_ENTITY_STP structure.
*                          bindStEn        : the SYB_ENTITY_STP structure used to bind result set columns.
*
*   Global var. modified : None
*
*   Return               : TRUE if ok
*                          FALSE if problem
*
*   Creation Date        :
*   Last Modif.          :
*
*************************************************************************/
STATIC void DBI_CopyToDictEntity(DICT_ENTITY_STP dictEntityStp, DBI_ENTITY_STP bindStp)
{
    dictEntityStp->entDictId = *bindStp->entDictId;
    strcpy(dictEntityStp->mdSqlName, bindStp->sqlName);

    if (bindStp->dbName != nullptr)
    {
        dictEntityStp->databaseName = bindStp->dbName;
    }

    if (bindStp->name != nullptr)
    {
        dictEntityStp->nameStr = bindStp->name;
    }

    if (bindStp->label != nullptr)
    {
        dictEntityStp->labelStr = bindStp->label;
    }
    if (bindStp->uniLabel != nullptr)
    {
        dictEntityStp->uniLabelStr = bindStp->uniLabel;
    }

    if (dictEntityStp->labelStr.empty())
    {
        if (dictEntityStp->uniLabelStr.isEmpty())
        {
            dictEntityStp->labelStr = dictEntityStp->nameStr;
        }
        else
        {
            STRING1000_T label;
            DBI_ConvertToASCII(dictEntityStp->uniLabelStr.getTerminatedBuffer(), label, GET_MAXDATALEN(String1000Type));

            dictEntityStp->labelStr = label;
        }
    }
    if (dictEntityStp->uniLabelStr.isEmpty())
    {
        dictEntityStp->uniLabelStr = dictEntityStp->labelStr.c_str();
    }

    dictEntityStp->entNatEn      = static_cast<DBA_ENTITY_NAT_ENUM>(*bindStp->entNatEn);
    dictEntityStp->custAuthFlg   = *bindStp->custAuthFlg;
    dictEntityStp->precompFlg    = *bindStp->precompFlg;
    dictEntityStp->usePrecompFlg = *bindStp->usePrecompFlg;

    if (bindStp->mainFlg != nullptr)
    {
        dictEntityStp->mainFlg       = *bindStp->mainFlg;
        dictEntityStp->refAuthFlg    = *bindStp->refAuthFlg;
        dictEntityStp->entDictIdFlg  = *bindStp->entDictIdFlg;
        dictEntityStp->synonFlg      = *bindStp->synonFlg;
        dictEntityStp->listFlg       = *bindStp->listFlg;
        dictEntityStp->tpNatEn       = static_cast<TYPINGNAT_ENUM>(*bindStp->tpNatEn);
        dictEntityStp->logicalFlg    = *bindStp->logicalFlg;
        dictEntityStp->activeAuthEn  = static_cast<FEATURE_AUTH_ENUM>(*bindStp->activeAuthEn);
        dictEntityStp->qSearchFlg    = *bindStp->qSearchFlg;
        dictEntityStp->interf        = *bindStp->interf;
        dictEntityStp->auditAuthEn   = static_cast<FEATURE_AUTH_ENUM>(*bindStp->auditAuthEn);

        if (*bindStp->natIndexNF == DBI_NULLDATA)
        {
            dictEntityStp->natIndex = 255;
            dictEntityStp->isNullNatIndex = true;
        }
        else
        {
            dictEntityStp->natIndex = *bindStp->natIndex;
            dictEntityStp->isNullNatIndex = false;
        }

        if (*bindStp->parIndexNF == DBI_NULLDATA)
        {
            dictEntityStp->parIndex = 255;
            dictEntityStp->isNullParIndex = true;
        }
        else
        {
            dictEntityStp->parIndex = *bindStp->parIndex;
            dictEntityStp->isNullParIndex = false;
        }

        dictEntityStp->custDbName         = bindStp->custDbName;
        strcpy(dictEntityStp->precompDbName, bindStp->precompDbName);
        dictEntityStp->lastModifDate      = bindStp->lastModifDate->dateTime();
        dictEntityStp->precompStdFormatId = *bindStp->precompStdFormatId;
        dictEntityStp->precompUsrFormatId = *bindStp->precompUsrFormatId;
        dictEntityStp->precompRankN       = *bindStp->precompRankN;
        strcpy(dictEntityStp->shortSqlname, bindStp->shortSqlname);
        strcpy(dictEntityStp->aliasSqlname, bindStp->aliasSqlname);
        dictEntityStp->entNatEn           = static_cast<DBA_ENTITY_NAT_ENUM>(*bindStp->entNatEn);
        dictEntityStp->securityLevelEn    = static_cast<ENTITY_SECURITY_LEVEL_ENUM>(*bindStp->securityLevelEn);
        dictEntityStp->automaticMask      = *bindStp->automaticMask;
        dictEntityStp->adminFctDictId     = *bindStp->adminFctDictId;
        dictEntityStp->pkRuleEn           = static_cast<PK_RULE_ENUM>(*bindStp->pkRuleEn);
        dictEntityStp->objModifStatEn     = static_cast<LAST_MODIF_ENUM>(*bindStp->objModifStatEn);
        dictEntityStp->tableModifStatEn   = static_cast<LAST_MODIF_ENUM>(*bindStp->tableModifStatEn);
        dictEntityStp->deleteRuleEn       = static_cast<DELETE_RULE_ENUM>(*bindStp->deleteRuleEn);
        dictEntityStp->lastModifEn        = static_cast<LAST_MODIF_ENUM>(*bindStp->lastModifEn);
        dictEntityStp->xdStatusEn         = static_cast<XD_STATUS_ENUM>(*bindStp->xdStatusEn);

        if (bindStp->xdEntityId != nullptr)
        {
            dictEntityStp->xdEntityId = *bindStp->xdEntityId;
        }

        /* PMSTA-21717 - LJE - 160119 */
        if (bindStp->dbSqlName[0] != 0)
        {
            strcpy(dictEntityStp->dbSqlName, bindStp->dbSqlName);
        }
        else
        {
            strcpy(dictEntityStp->dbSqlName, bindStp->sqlName);
        }
        dictEntityStp->dbRuleEn             = static_cast<DB_RULE_ENUM>(*bindStp->dbRuleEn);
        dictEntityStp->linkedEntityDictId   = *bindStp->linkedEntityDictId;
        dictEntityStp->physicalEntityDictId = *bindStp->physicalEntityDictId;

        /* PMSTA-23385 - LJE - 160706 */
        dictEntityStp->copyRightEn       = static_cast<DICT_ATTRCOPY_ENUM>(*bindStp->copyRightEn);
        dictEntityStp->activeAuthEn      = static_cast<FEATURE_AUTH_ENUM>(*bindStp->activeAuthEn);
        dictEntityStp->updFctAuthEn      = static_cast<FEATURE_AUTH_ENUM>(*bindStp->updFctAuthEn);
        dictEntityStp->externalSeqAuthEn = static_cast<FEATURE_AUTH_ENUM>(*bindStp->externalSeqAuthEn);
        dictEntityStp->loadDictRuleEn    = static_cast<LOAD_DICT_RULE_ENUM>(*bindStp->loadDictRuleEn);
        dictEntityStp->dmlModifTrackEn   = static_cast<DML_MODIF_TRACK_ENUM>(*bindStp->dmlModifTrackEn);
        dictEntityStp->partAuthEn        = static_cast<FEATURE_AUTH_ENUM>(*bindStp->partAuthEn);                 /* PMSTA-24007 - LJE - 160921 */
        dictEntityStp->dlmAuthEn         = static_cast<FEATURE_AUTH_ENUM>(*bindStp->dlmAuthEn);                   /* PMSTA-24007 - LJE - 160921 */
        dictEntityStp->multiEntityCateg.set(static_cast<MULTI_ENTITY_CATEGORY_ENUM>(*bindStp->multiEntityCategEn));  /* PMSTA-24007 - LJE - 160921 */
    }
    else
    {
        dictEntityStp->xdStatusEn = XdStatus_Inserted;
        SET_BIT(dictEntityStp->automaticMask, Automatic_SProc, TRUE);
    }
}

/************************************************************************
*   Function             : DBI_BindDictAttrib()
*
*   Description          : Bind all columns of the second result set
*                          (dict_attribute) with the DICT_ATTRIB structure
*
*   Arguments            :
*                          bindStEn    : the DICT_ATTRIB structure used to bind
*                                      result set columns.
*
*   Global var. modified : None
*
*   Return               : TRUE if ok
*
*************************************************************************/
STATIC int DBI_BindDictAttrib(RequestHelper &requestHelper, DBI_ATTRIB_STP bindStp, bool bSingleRequest)
{
    if (bSingleRequest == false)
    {
        requestHelper.addNewResultSet();
    }

    requestHelper.addNewOutputData(DictType);
    requestHelper.getBindVariablePtr(bindStp->attrDictId);
    requestHelper.addNewOutputData(NameType);
    requestHelper.getBindVariablePtr(bindStp->name);
    requestHelper.addNewOutputData(DictType);
    requestHelper.getBindVariablePtr(bindStp->entDictId);
    requestHelper.addNewOutputData(DictType);
    requestHelper.getBindVariablePtr(bindStp->dataTpDictId);
    requestHelper.addNewOutputData(DictType);
    requestHelper.getBindVariablePtr(bindStp->refEntDictId);
    requestHelper.addNewOutputData(DictType);
    requestHelper.getBindVariablePtr(bindStp->parAttrDictId);
    requestHelper.addNewOutputData(SysnameType);
    requestHelper.getBindVariablePtr(bindStp->sqlName);
    requestHelper.addNewOutputData(IntType);
    requestHelper.getBindVariablePtr(bindStp->progN);
    requestHelper.addNewOutputData(SmallintType);
    requestHelper.getBindVariablePtr(bindStp->progPkN, bindStp->nullProgPkN);
    requestHelper.addNewOutputData(SmallintType);
    requestHelper.getBindVariablePtr(bindStp->dispRank);
    requestHelper.addNewOutputData(FlagType);
    requestHelper.getBindVariablePtr(bindStp->primFlg);
    requestHelper.addNewOutputData(FlagType);
    requestHelper.getBindVariablePtr(bindStp->mandatoryFlg);
    requestHelper.addNewOutputData(FlagType);
    requestHelper.getBindVariablePtr(bindStp->dbMandatoryFlg);
    requestHelper.addNewOutputData(NameType);
    requestHelper.getBindVariablePtr(bindStp->dfltVal);
    requestHelper.addNewOutputData(FlagType);
    requestHelper.getBindVariablePtr(bindStp->permValFlg);
    requestHelper.addNewOutputData(FlagType);
    requestHelper.getBindVariablePtr(bindStp->busKeyFlg);
    requestHelper.addNewOutputData(FlagType);
    requestHelper.getBindVariablePtr(bindStp->logicalFlg);
    requestHelper.addNewOutputData(FlagType);
    requestHelper.getBindVariablePtr(bindStp->custFlg);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->calcEn);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->permAuthEn);
    requestHelper.addNewOutputData(TinyintType);
    requestHelper.getBindVariablePtr(bindStp->editionEn);
    requestHelper.addNewOutputData(MaskType);
    requestHelper.getBindVariablePtr(bindStp->subTypeMask);
    requestHelper.addNewOutputData(MaskType);
    requestHelper.getBindVariablePtr(bindStp->qSearchMask);
    requestHelper.addNewOutputData(MaskType);
    requestHelper.getBindVariablePtr(bindStp->searchMask);
    requestHelper.addNewOutputData(SmallintType);
    requestHelper.getBindVariablePtr(bindStp->shortIdx, bindStp->nullShortIdx);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->securityLevelEn);
    requestHelper.addNewOutputData(NameType);
    requestHelper.getBindVariablePtr(bindStp->keyCharC);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->widgetEn);
    requestHelper.addNewOutputData(SmallintType);
    requestHelper.getBindVariablePtr(bindStp->maxDbLenN);
    requestHelper.addNewOutputData(SmallintType);
    requestHelper.getBindVariablePtr(bindStp->defaultDisplayLenN);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->tascViewEn);
    requestHelper.addNewOutputData(SysnameType);
    requestHelper.getBindVariablePtr(bindStp->objectAttribute);
    requestHelper.addNewOutputData(SysnameType);
    requestHelper.getBindVariablePtr(bindStp->entityAttribute);
    requestHelper.addNewOutputData(SysnameType);
    requestHelper.getBindVariablePtr(bindStp->enumAttribute);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->enumValueEn);
    requestHelper.addNewOutputData(DictType);
    requestHelper.getBindVariablePtr(bindStp->refEntityAttributeDictId);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->fkPresentationEn);
    requestHelper.addNewOutputData(DictType);
    requestHelper.getBindVariablePtr(bindStp->denomLanguageDictId);
    requestHelper.addNewOutputData(FlagType);
    requestHelper.getBindVariablePtr(bindStp->precompFlg);
    requestHelper.addNewOutputData(FlagType);
    requestHelper.getBindVariablePtr(bindStp->verticalSearchFlg);
    requestHelper.addNewOutputData(FlagType);
    requestHelper.getBindVariablePtr(bindStp->verticalPatternFlg);
    requestHelper.addNewOutputData(FlagType);
    requestHelper.getBindVariablePtr(bindStp->multiLanguageFlg);
    requestHelper.addNewOutputData(DictType);
    requestHelper.getBindVariablePtr(bindStp->linkedAttrDictId);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->xdStatusEn);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->refDeleteRuleEn);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->refSecurityRuleEn);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->refCheckRuleEn);
    requestHelper.addNewOutputData(SmallintType);
    requestHelper.getBindVariablePtr(bindStp->progBkN, bindStp->nullProgBkN);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->exportEn);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->objModifStatEn);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->featureEn);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->modelBankEn);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->meSpecialisationEn);
    requestHelper.addNewOutputData(EnumType);                                      /* PMSTA-45305 -Lalby- 210528 */
    requestHelper.getBindVariablePtr(bindStp->outboxPublishEn);

    if (bSingleRequest == false)
    {
        if (ICU4AAA_SQLServerUTF8)
        {
            requestHelper.addNewOutputData(UniString1000Type);
            requestHelper.getBindVariablePtr(bindStp->uniLabel);
        }
        else
        {
            requestHelper.addNewOutputData(String1000Type);
            requestHelper.getBindVariablePtr(bindStp->label);
        }
    }
    return(TRUE);
}

/************************************************************************
*   Function             : DBI_BindDictAttrib()
*
*   Description          : Bind all columns of the second result set
*                          (dict_attribute) with the DICT_ATTRIB structure
*
*   Arguments            :
*                          bindStEn    : the DICT_ATTRIB structure used to bind
*                                      result set columns.
*
*   Global var. modified : None
*
*   Return               : TRUE if ok
*
*************************************************************************/
STATIC int DBI_BindDictAttribForMig(RequestHelper &requestHelper, DBI_ATTRIB_STP bindStp)
{
    requestHelper.addNewOutputData(DictType);
    requestHelper.getBindVariablePtr(bindStp->attrDictId);
    requestHelper.addNewOutputData(DictType);
    requestHelper.getBindVariablePtr(bindStp->entDictId);
    requestHelper.addNewOutputData(DictType);
    requestHelper.getBindVariablePtr(bindStp->dataTpDictId);
    requestHelper.addNewOutputData(SysnameType);
    requestHelper.getBindVariablePtr(bindStp->sqlName);
    requestHelper.addNewOutputData(IntType);
    requestHelper.getBindVariablePtr(bindStp->progN);
    requestHelper.addNewOutputData(SmallintType);
    requestHelper.getBindVariablePtr(bindStp->progPkN, bindStp->nullProgPkN);
    requestHelper.addNewOutputData(FlagType);
    requestHelper.getBindVariablePtr(bindStp->primFlg);
    requestHelper.addNewOutputData(FlagType);
    requestHelper.getBindVariablePtr(bindStp->busKeyFlg);
    requestHelper.addNewOutputData(FlagType);
    requestHelper.getBindVariablePtr(bindStp->dbMandatoryFlg);
    requestHelper.addNewOutputData(NameType);
    requestHelper.getBindVariablePtr(bindStp->dfltVal);
    requestHelper.addNewOutputData(FlagType);
    requestHelper.getBindVariablePtr(bindStp->logicalFlg);
    requestHelper.addNewOutputData(FlagType);
    requestHelper.getBindVariablePtr(bindStp->custFlg);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->calcEn);
    requestHelper.addNewOutputData(SmallintType);
    requestHelper.getBindVariablePtr(bindStp->maxDbLenN);
    requestHelper.addNewOutputData(FlagType);
    requestHelper.getBindVariablePtr(bindStp->precompFlg);

    return(TRUE);
}

/************************************************************************
*   Function             : DBI_ReadDictAttrib()
*
*   Description          : Read all columns of the second result set
*
*   Arguments            : callStp       : the oracle statement
*                          dictAttribPtr : a pointer on a DICT_ATTRIB
*                                          structure
*                          dictAttribMax : Maximum entries into the array dictAttribPtr
*                          bindStEn        : the DICT_ATTRIB structure used
*                                          to bind result set columns.
*
*   Global var. modified : None
*
*   Return               : TRUE if ok
*
*   Creation Date        : July  94 - PEC
*
*   Last Modif.          : PMSTA-17334 - 101213 - PMO : Installation from scratch of CIP_RHEL failed
*
*************************************************************************/
int DBI_ReadDictAttrib(RequestHelper &requestHelper, DBI_ATTRIB_STP bindStp)      /* PMSTA-17334 - 101213 - PMO */
{
    DICT_ENTITY_STP     dictEntityStp = nullptr; /* PMSTA-26108 - LJE - 170918 */

    int i = 0;

    while (requestHelper.fetch() == RET_SUCCEED)
    {
        if (dictEntityStp == nullptr || dictEntityStp->entDictId != *bindStp->entDictId)
        {
            dictEntityStp = DBA_GetDictEntityByDictId(*bindStp->entDictId);
        }

        if (dictEntityStp == nullptr)
        { /* Format and log an error message */

            char messageStr[1024];/* Buffer for an error message */

            (void)snprintf(messageStr,
                           sizeof(messageStr) / sizeof(messageStr[0]),
                           "Unknown DictAttrib record N°:%d, entity:%" szFormatId " attr:%" szFormatId ", label:%s",
                           i,
                           *bindStp->entDictId,
                           *bindStp->attrDictId,
                           bindStp->label);

            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, messageStr);
        }
        else
        {
            FIELD_IDX_T idx = (FIELD_IDX_T)dictEntityStp->attribMap.size();
            DictAttribClass &dictAttrbSt = dictEntityStp->addDictAttrib(*bindStp->attrDictId, idx++, bindStp->sqlName);
            DBI_CopyToDictAttribute(&dictAttrbSt, bindStp);

            if (dictAttrbSt.custFlg == TRUE)
            {
                if (dictAttrbSt.logicalFlg == FALSE)
                {
                    dictEntityStp->custNbr++;
                }
                else
                {
                    dictAttrbSt.custFlg = FALSE;
                }
            }
            if (dictAttrbSt.precompFlg == TRUE)
            {
                dictEntityStp->precompNbr++;
            }
        }
        i++;
    }

    return(i);
}

/************************************************************************
*   Function             : DBI_CopyToDictAttribute()
*
*   Description          : Copy the binding structure (DBI_ATTRIB) to the DICT_ATTRIB structure
*
*   Arguments            : dictAttribStp : the DICT_ATTRIB_STP structure.
*                          bindStEn        : the DBI_ATTRIB_STP structure used to bind result set columns.
*
*   Global var. modified : None
*
*   Return               : TRUE if ok
*                          FALSE if problem
*
*   Creation Date        :
*   Last Modif.          :
*
*************************************************************************/
void DBI_CopyToDictAttribute(DICT_ATTRIB_STP dictAttribStp, DBI_ATTRIB_STP bindStp)
{
    dictAttribStp->attrDictId = *bindStp->attrDictId;
    dictAttribStp->entDictId = *bindStp->entDictId;

    if (bindStp->name != nullptr)
    {
        strcpy(dictAttribStp->name, bindStp->name);
    }

    if (bindStp->label != nullptr)
    {
        dictAttribStp->SET_daLabel(bindStp->label);

        if (dictAttribStp->GET_daLabel()[0] == 0)
        {
            dictAttribStp->SET_daLabel(bindStp->name);
        }

        UNI_STRING1000_T uniLabel;
        DBI_ConvertFromASCII(dictAttribStp->GET_daLabel(), -1, uniLabel, GET_MAXDATALEN(UniString1000Type), NULL);

        dictAttribStp->SET_daUniLabel(uniLabel);
    }
    else if (bindStp->uniLabel != nullptr)
    {
        dictAttribStp->SET_daUniLabel(bindStp->uniLabel);

        if (dictAttribStp->GET_daUniLabel()[0] == 0)
        {
            UNI_STRING1000_T uniLabel;
            DBI_ConvertFromASCII(bindStp->name, -1, uniLabel, GET_MAXDATALEN(UniString1000Type), NULL);

            dictAttribStp->SET_daUniLabel(uniLabel);
        }

        STRING1000_T label;
        DBI_ConvertToASCII(dictAttribStp->GET_daUniLabel(), label, GET_MAXDATALEN(String1000Type));
        dictAttribStp->SET_daLabel(label);
    }

    dictAttribStp->dataTpProgN = DATATYPE_DICT_TO_ENUM(*bindStp->dataTpDictId);

    if (ICU4AAA_SQLServerUTF8 == 0 && 
        (SYS_IsDdlGenMode() == TRUE || 
         (SYS_IsGuiMode() == TRUE && EV_RdbmsVendor == QtHttp)))
    {
        DATATYPE_ENUM newFieldType = DBA_ConvUniDataTypeToDataType(dictAttribStp->dataTpProgN);
        if (dictAttribStp->dataTpProgN != newFieldType)
        {
            dictAttribStp->dataTpProgN = newFieldType;
        }
    }

    if (bindStp->refEntDictId != nullptr)
    {
        dictAttribStp->refEntDictId = *bindStp->refEntDictId;
        dictAttribStp->parAttrDictId = *bindStp->parAttrDictId;
        strcpy(dictAttribStp->sqlName, bindStp->sqlName);
        dictAttribStp->progN = *bindStp->progN;
        dictAttribStp->dbProgN = *bindStp->progN;

        if (*bindStp->nullProgPkN == DBI_NULLDATA)
        {
            dictAttribStp->progPkN = 0;
            dictAttribStp->isNullProgPkN = true;
        }
        else
        {
            dictAttribStp->progPkN = *bindStp->progPkN;
            dictAttribStp->isNullProgPkN = false;
        }

        dictAttribStp->dispRank       = *bindStp->dispRank;
        dictAttribStp->primFlg        = *bindStp->primFlg;
        dictAttribStp->mandatoryFlg   = *bindStp->mandatoryFlg;
        dictAttribStp->dbMandatoryFlg = *bindStp->dbMandatoryFlg;
        dictAttribStp->dfltVal        = bindStp->dfltVal;
        dictAttribStp->busKeyFlg      = *bindStp->busKeyFlg;
        dictAttribStp->logicalFlg     = *bindStp->logicalFlg;
        dictAttribStp->custFlg        = *bindStp->custFlg;
        dictAttribStp->calcEn         = static_cast<DICTATTR_ENUM>(*bindStp->calcEn);
        dictAttribStp->permAuthEn     = static_cast<DBA_PERMAUTH_ENUM>(*bindStp->permAuthEn);
        dictAttribStp->editionEn      = static_cast<DICTATTRIBEDIT_ENUM>(*bindStp->editionEn);
        dictAttribStp->qSearchMask    = *bindStp->qSearchMask;
        dictAttribStp->searchMask     = *bindStp->searchMask;
        dictAttribStp->subTypeMask    = *bindStp->subTypeMask;
        if (*bindStp->nullShortIdx    == DBI_NULLDATA)
        {
            dictAttribStp->shortIdx = 0;
            dictAttribStp->isNullShortIdx = true;
        }
        else
        {
            dictAttribStp->shortIdx = *bindStp->shortIdx;
            dictAttribStp->isNullShortIdx = false;
        }
        dictAttribStp->securityLevelEn          = *bindStp->securityLevelEn;
        strcpy(dictAttribStp->keyCharC, bindStp->keyCharC);
        dictAttribStp->widgetEn                 = static_cast<DICTATTRIBWGT_ENUM>(*bindStp->widgetEn);
        dictAttribStp->maxDbLenN                = *bindStp->maxDbLenN;
        dictAttribStp->defaultDisplayLenN       = *bindStp->defaultDisplayLenN;
        dictAttribStp->tascViewEn               = *bindStp->tascViewEn;
        strcpy(dictAttribStp->objectAttribute, bindStp->objectAttribute);
        strcpy(dictAttribStp->entityAttribute, bindStp->entityAttribute);
        strcpy(dictAttribStp->enumAttribute, bindStp->enumAttribute);
        dictAttribStp->enumValueEn              = *bindStp->enumValueEn;
        dictAttribStp->refEntityAttributeDictId = *bindStp->refEntityAttributeDictId;
        dictAttribStp->fkPresentationEn         = *bindStp->fkPresentationEn;
        dictAttribStp->denomLanguageDictId      = *bindStp->denomLanguageDictId;
        dictAttribStp->precompFlg               = *bindStp->precompFlg;
        dictAttribStp->verticalSearchFlg        = *bindStp->verticalSearchFlg;
        dictAttribStp->verticalPatternFlg       = *bindStp->verticalPatternFlg;
        dictAttribStp->multiLanguageFlg         = *bindStp->multiLanguageFlg;
        dictAttribStp->linkedAttrDictId         = *bindStp->linkedAttrDictId;
        dictAttribStp->xdStatusEn               = static_cast<XD_STATUS_ENUM> (*bindStp->xdStatusEn);
        dictAttribStp->refDeleteRuleEn          = static_cast<REF_DELETE_RULE_ENUM> (*bindStp->refDeleteRuleEn);
        dictAttribStp->refSecurityRuleEn        = static_cast<REF_SECURITY_RULE_ENUM> (*bindStp->refSecurityRuleEn);
        dictAttribStp->refCheckRuleEn           = static_cast<REF_CHECK_RULE_ENUM> (*bindStp->refCheckRuleEn);
        dictAttribStp->objModifStatEn           = static_cast<LAST_MODIF_ENUM> (*bindStp->objModifStatEn);

        if (*bindStp->nullProgBkN == DBI_NULLDATA)
        {
            dictAttribStp->progBkN = 0;
            dictAttribStp->isNullProgBkN = true;
        }
        else
        {
            dictAttribStp->progBkN = *bindStp->progBkN;
            dictAttribStp->isNullProgBkN = false;
        }

        dictAttribStp->exportEn           = static_cast<EXPORT_ENUM>(*bindStp->exportEn);
        dictAttribStp->featureEn          = static_cast<XdEntityFeatureFeatureEn>(*bindStp->featureEn);
        dictAttribStp->modelBankEn        = static_cast<MODEL_BANK_ENUM>(*bindStp->modelBankEn); /* PMSTA-27352 - LJE - 170606 */
        dictAttribStp->meSpecialisationEn = static_cast<ME_SPECIALISATION_ENUM>(*bindStp->meSpecialisationEn);  /* PMSTA-26108 - LJE - 170830 */
        dictAttribStp->outboxPublishEn    = static_cast<OUTBOX_PUBLISH_ENUM>(*bindStp->outboxPublishEn);   /* PMSTA-45305 -Lalby- 210528 */
    }
    else
    {
        dictAttribStp->progN   = *bindStp->progN;
        dictAttribStp->dbProgN = *bindStp->progN;

        if (*bindStp->nullProgPkN == DBI_NULLDATA)
        {
            dictAttribStp->progPkN = 0;
            dictAttribStp->isNullProgPkN = true;
        }
        else
        {
            dictAttribStp->progPkN = *bindStp->progPkN;
            dictAttribStp->isNullProgPkN = false;
        }
        dictAttribStp->primFlg        = *bindStp->primFlg;
        dictAttribStp->busKeyFlg      = *bindStp->busKeyFlg;
        dictAttribStp->dbMandatoryFlg = *bindStp->dbMandatoryFlg;
        dictAttribStp->dfltVal        = bindStp->dfltVal;
        dictAttribStp->logicalFlg     = *bindStp->logicalFlg;
        dictAttribStp->custFlg        = *bindStp->custFlg;
        dictAttribStp->calcEn         = static_cast<DICTATTR_ENUM>(*bindStp->calcEn);
        dictAttribStp->maxDbLenN      = *bindStp->maxDbLenN;
        dictAttribStp->precompFlg     = *bindStp->precompFlg;
        dictAttribStp->xdStatusEn     = XdStatus_Inserted;
    }
}


/************************************************************************
*   Function             : DBI_BindDictCriteria()
*
*   Description          : Bind all columns of the third result set
*                          (dict_Criter) with the DICT_CRITER structure
*
*   Arguments            : callStp   : the oracle call statement.
*                          bindStEn    : the DICT_CRITER structure used to bind
*                                      result set columns.
*
*   Global var. modified : None
*
*   Return               : TRUE if ok
*
*************************************************************************/
int DBI_BindDictCriteria(RequestHelper& requestHelper, DBI_CRITER_STP bindStp, bool bSingleRequest)
{
    if (bSingleRequest == false)
    {
        requestHelper.addNewResultSet();
    }

    requestHelper.addNewOutputData(DictType);
    requestHelper.getBindVariablePtr(bindStp->dictId);
    requestHelper.addNewOutputData(DictType);
    requestHelper.getBindVariablePtr(bindStp->entDictId);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->dynNatEn);
    requestHelper.addNewOutputData(SysnameType);
    requestHelper.getBindVariablePtr(bindStp->sqlName);
    requestHelper.addNewOutputData(DictType);
    requestHelper.getBindVariablePtr(bindStp->attrDictId);
    requestHelper.addNewOutputData(IntType);
    requestHelper.getBindVariablePtr(bindStp->progN);
    requestHelper.addNewOutputData(TinyintType);
    requestHelper.getBindVariablePtr(bindStp->sortRank);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->sortRule);
    requestHelper.addNewOutputData(TinyintType);
    requestHelper.getBindVariablePtr(bindStp->fkIndex, bindStp->fkIndexNF);
    requestHelper.addNewOutputData(SmallintType);
    requestHelper.getBindVariablePtr(bindStp->index, bindStp->indexNF);
    requestHelper.addNewOutputData(SmallintType);
    requestHelper.getBindVariablePtr(bindStp->parent1ProgN, bindStp->parent1ProgNNF);
    requestHelper.addNewOutputData(SmallintType);
    requestHelper.getBindVariablePtr(bindStp->parent2ProgN, bindStp->parent2ProgNNF);

    if (bSingleRequest == false)
    {
        requestHelper.addNewOutputData(DictType);
        requestHelper.getBindVariablePtr(bindStp->attrEntDictId);
        requestHelper.addNewOutputData(NameType);
        requestHelper.getBindVariablePtr(bindStp->name);

        if (ICU4AAA_SQLServerUTF8)
        {
            requestHelper.addNewOutputData(UniString1000Type);
            requestHelper.getBindVariablePtr(bindStp->uniLabel);
        }
        else
        {
            requestHelper.addNewOutputData(String1000Type);
            requestHelper.getBindVariablePtr(bindStp->label);
        }
    }

    return(TRUE);
}

/************************************************************************
*   Function             : DBI_ReadDictCriteria()
*
*   Description          : Read all columns of the third result set
*
*   Arguments            : callStp       : the oracle call statement.
*                          dictCriterPtr : a pointer on a DICT_CRITER struct.
*                          dictCriterMax : Maximum entries into the array dictCriterPtr
*                          bindStEn        : the DICT_CRITER structure used
*                                          to bind result set columns.
*
*   Global var. modified : None
*
*   Return               : TRUE if ok
*                          FALSE if problem
*
*************************************************************************/
int DBI_ReadDictCriteria(RequestHelper &requestHelper, DBI_CRITER_STP bindStp)
{
    DICT_ENTITY_STP     dictEntityStp = nullptr; /* PMSTA-26108 - LJE - 170918 */
    int                 i = 0;

    while (requestHelper.fetch() == RET_SUCCEED)
    {
        if (dictEntityStp == nullptr || dictEntityStp->entDictId != *bindStp->entDictId)
        {
            dictEntityStp = DBA_GetDictEntityByDictId(*bindStp->entDictId);
        }

        if (dictEntityStp == nullptr)
        { /* Format and log an error message */

            char messageStr[1024];/* Buffer for an error message */

            (void)snprintf(messageStr,
                           sizeof(messageStr) / sizeof(messageStr[0]),
                           "Unknown DictCriteria record N°:%d, entity:%" szFormatId " attr:%" szFormatId ", label:%s",
                           i,
                           *bindStp->entDictId,
                           *bindStp->attrDictId,
                           bindStp->label);

            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, messageStr);
        }
        else
        {
            DictCriterClass *dictCriteriaStp = dictEntityStp->addDictCriteria((DBA_DYNTYPE_ENUM)*bindStp->dynNatEn, *bindStp->progN);
            DBI_CopyToDictCriteria(dictCriteriaStp, bindStp);
        }
        i++;
    }

    return i;
}

/************************************************************************
*   Function             : DBI_CopyToDictCriteria()
*
*   Description          : Copy the binding structure (DBI_CRITER) to the DICT_CRITER structure
*
*   Arguments            : dictCriterStp : the DICT_CRITER_STP structure.
*                          bindStEn        : the DBI_CRITER_STP structure used to bind result set columns.
*
*   Global var. modified : None
*
*   Return               : TRUE if ok
*                          FALSE if problem
*
*   Creation Date        :
*   Last Modif.          :
*
*************************************************************************/
void DBI_CopyToDictCriteria(DICT_CRITER_STP dictCriterStp, DBI_CRITER_STP bindStp)
{
    dictCriterStp->dictId        = *bindStp->dictId;
    dictCriterStp->entDictId     = *bindStp->entDictId;
    dictCriterStp->attrDictId    = *bindStp->attrDictId;

    if (bindStp->attrEntDictId != nullptr)
    {
        dictCriterStp->attrEntDictId = *bindStp->attrEntDictId;
    }
    else
    {
        dictCriterStp->attrEntDictId = DBA_GetAttributeById(dictCriterStp->attrDictId)->entDictId;
    }

    dictCriterStp->dynNatEn      = static_cast<DBA_DYNTYPE_ENUM>(*bindStp->dynNatEn);

    strcpy(dictCriterStp->sqlName, bindStp->sqlName);

    if (bindStp->name != nullptr)
    {
        strcpy(dictCriterStp->name, bindStp->name);
    }

    if (bindStp->label != nullptr)
    {
        dictCriterStp->SET_dcLabel(bindStp->label);

        if (dictCriterStp->GET_dcLabel()[0] == 0)
        {
            dictCriterStp->SET_dcLabel(bindStp->name);
        }

        UNI_STRING1000_T uniLabel;
        DBI_ConvertFromASCII(dictCriterStp->GET_dcLabel(), -1, uniLabel, GET_MAXDATALEN(UniString1000Type), NULL);

        dictCriterStp->SET_dcUniLabel(uniLabel);
    }
    else if (bindStp->uniLabel)
    {
        dictCriterStp->SET_dcUniLabel(bindStp->uniLabel);

        if (dictCriterStp->GET_dcUniLabel()[0] == 0)
        {
            UNI_STRING1000_T uniLabel;
            DBI_ConvertFromASCII(bindStp->name, -1, uniLabel, GET_MAXDATALEN(UniString1000Type), NULL);

            dictCriterStp->SET_dcUniLabel(uniLabel);
        }

        STRING1000_T label;
        DBI_ConvertToASCII(dictCriterStp->GET_dcUniLabel(), label, GET_MAXDATALEN(String1000Type));
        dictCriterStp->SET_dcLabel(label);
    }

    dictCriterStp->progN    = *bindStp->progN;
    dictCriterStp->sortRank = *bindStp->sortRank;
    dictCriterStp->sortRule = static_cast<SORTRULE_ENUM>(*bindStp->sortRule);

    if (*bindStp->indexNF == DBI_NULLDATA)
    {
        dictCriterStp->index = 0;
        dictCriterStp->isNullIndex = true;
    }
    else
    {
        dictCriterStp->index = *bindStp->index;
        dictCriterStp->isNullIndex = false;
    }

    if (*bindStp->fkIndexNF == DBI_NULLDATA)
    {
        dictCriterStp->fkIndex = 0;
        dictCriterStp->isNullFkIndex = true;
    }
    else
    {
        dictCriterStp->fkIndex = *bindStp->fkIndex;
        dictCriterStp->isNullFkIndex = false;
    }

    if (*bindStp->parent1ProgNNF == DBI_NULLDATA)
    {
        dictCriterStp->parent1ProgN = 0;
        dictCriterStp->isNullParent1ProgN = true;
    }
    else
    {
        dictCriterStp->parent1ProgN = *bindStp->parent1ProgN;
        dictCriterStp->isNullParent1ProgN = false;
    }

    if (*bindStp->parent2ProgNNF == DBI_NULLDATA)
    {
        dictCriterStp->parent2ProgN = 0;
        dictCriterStp->isNullParent2ProgN = true;
    }
    else
    {
        dictCriterStp->parent2ProgN = *bindStp->parent2ProgN;
        dictCriterStp->isNullParent2ProgN = false;
    }
}

/************************************************************************
*   Function             : DBI_BindDictPermVal()
*
*   Description          : Bind all columns of the forth result set
*                          (dict_perm_value) with the DICT_PERM_VAL structure
*
*   Arguments            : callStp       : the oracle call statement.
*                          bindStEn    : the DICT_PERM_VAL structure used to bind
*                                      result set columns.
*
*   Global var. modified : None
*
*   Return               : TRUE if ok
*                          FALSE if problem
*
*   Creation Date        :
*   Last Modif.          :
*************************************************************************/
int DBI_BindDictPermVal(RequestHelper &requestHelper, DBI_PERM_VAL_STP bindStp, bool bSingleRequest)
{
    if (bSingleRequest == false)
    {
        requestHelper.addNewResultSet();
    }

    requestHelper.addNewOutputData(DictType);
    requestHelper.getBindVariablePtr(bindStp->dictId);
    requestHelper.addNewOutputData(DictType);
    requestHelper.getBindVariablePtr(bindStp->attDictId);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->permVal);
    requestHelper.addNewOutputData(NameType);
    requestHelper.getBindVariablePtr(bindStp->name);
    requestHelper.addNewOutputData(SmallintType);
    requestHelper.getBindVariablePtr(bindStp->rank);
    requestHelper.addNewOutputData(DictType);
    requestHelper.getBindVariablePtr(bindStp->refEntityDictId);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->permValRuleEn);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->xdStatusEn);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->dbRuleEn);
    requestHelper.addNewOutputData(DictType);
    requestHelper.getBindVariablePtr(bindStp->entDictId);

    if (bSingleRequest == false)
    {
        if (ICU4AAA_SQLServerUTF8)
        {
            requestHelper.addNewOutputData(UniString1000Type);
            requestHelper.getBindVariablePtr(bindStp->uniLabel);
        }
        else
        {
            requestHelper.addNewOutputData(String1000Type);
            requestHelper.getBindVariablePtr(bindStp->label);
        }
    }
    return(TRUE);
}

/************************************************************************
*   Function             : DBI_BindDictPermValForMig()
*
*   Description          : Bind all columns of the forth result set
*                          (dict_perm_value) with the DICT_PERM_VAL structure
*
*   Arguments            : callStp       : the oracle call statement.
*                          bindStEn    : the DICT_PERM_VAL structure used to bind
*                                      result set columns.
*
*   Global var. modified : None
*
*   Return               : TRUE if ok
*                          FALSE if problem
*
*   Creation Date        :
*   Last Modif.          :
*************************************************************************/
int DBI_BindDictPermValForMig(RequestHelper &requestHelper, DBI_PERM_VAL_STP bindStp)
{
    requestHelper.addNewOutputData(DictType);
    requestHelper.getBindVariablePtr(bindStp->dictId);
    requestHelper.addNewOutputData(DictType);
    requestHelper.getBindVariablePtr(bindStp->attDictId);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->permVal);
    requestHelper.addNewOutputData(SmallintType);
    requestHelper.getBindVariablePtr(bindStp->rank);
    requestHelper.addNewOutputData(DictType);
    requestHelper.getBindVariablePtr(bindStp->entDictId);

    return(TRUE);
}

/************************************************************************
*   Function             : DBI_ReadDictPermVal()
*
*   Description          : Read all columns of the forth result set
*
*   Arguments            : callStp       : the oracle call statement.
*                          dictPermValPtr : a pointer on a DICT_PERM_VAL_ST
*                                           structure
*                          dictPermMax    : Maximum entries into the array dictPermValPtr
*                          bindStEn         : the DICT_PERM_VAL structure
*                                           used to bind result set columns.
*
*   Global var. modified : None
*
*   Return               : TRUE if ok
*                          FALSE if problem
*
*  Last modif.           : PMSTA-30941 - 200418 - PMO : Fix gcc 8 compilations warnings related to the stabilization
*
*************************************************************************/
int DBI_ReadDictPermVal(RequestHelper &requestHelper, DBI_PERM_VAL_STP bindStp)
{
    DICT_ENTITY_STP     dictEntityStp = nullptr; /* PMSTA-26108 - LJE - 170918 */
    DICT_ATTRIB_STP     dictAttribStp = nullptr; /* PMSTA-26108 - LJE - 170918 */
    int                 i = 0;

    while (requestHelper.fetch() == RET_SUCCEED)
    {
        if (dictEntityStp == nullptr || dictEntityStp->entDictId != *bindStp->entDictId)
        {
            dictEntityStp = DBA_GetDictEntityByDictId(*bindStp->entDictId);
        }

        if (dictEntityStp && (dictAttribStp == nullptr || dictAttribStp->attrDictId != *bindStp->attDictId))
        {
            dictAttribStp = dictEntityStp->attribMap[*bindStp->attDictId];
        }

        if (dictAttribStp == nullptr)
        { /* Format and log an error message */

            char messageStr[1024];/* Buffer for an error message */

            (void)snprintf(messageStr,
                           sizeof(messageStr) / sizeof(messageStr[0]),
                           "Unknown DictPermVal record N°:%d, entity:%" szFormatId " attr:%" szFormatId ", label:%s",
                           i,
                           *bindStp->entDictId,
                           *bindStp->attDictId,
                           bindStp->label);

            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, messageStr);
        }
        else
        {
            DictPermValClass &dictPermValSt = dictAttribStp->getDictPermValByRank((*bindStp->rank));
            DBI_CopyToDictPermVal(&dictPermValSt, bindStp);
        }
        i++;
    }

    return(i);
}

/************************************************************************
*   Function             : DBI_CopyToDictPermVal()
*
*   Description          : Copy the binding structure (SYB_CRITER) to the DICT_CRITER structure
*
*   Arguments            : dictCriterStp : the DICT_CRITER_STP structure.
*                          bindStEn        : the SYB_CRITER_STP structure used to bind result set columns.
*
*   Global var. modified : None
*
*   Return               : TRUE if ok
*                          FALSE if problem
*
*   Creation Date        :
*   Last Modif.          :
*
*************************************************************************/
STATIC void DBI_CopyToDictPermVal(DICT_PERM_VAL_STP dictPermValPtr, DBI_PERM_VAL_STP bindStp)
{
    dictPermValPtr->dictId          = *bindStp->dictId;
    dictPermValPtr->entDictId       = *bindStp->entDictId;
    dictPermValPtr->attDictId       = *bindStp->attDictId;
    dictPermValPtr->permVal         = *bindStp->permVal;
    dictPermValPtr->rank            = *bindStp->rank;

    if (bindStp->refEntityDictId != nullptr)
    {
        dictPermValPtr->refEntityDictId = *bindStp->refEntityDictId;
        dictPermValPtr->permValRuleEn   = static_cast<PERM_VAL_RULE_ENUM>(*bindStp->permValRuleEn);
        dictPermValPtr->dbRuleEn        = static_cast<PERM_VAL_DB_RULE_ENUM>(*bindStp->dbRuleEn);
        dictPermValPtr->xdStatusEn      = *bindStp->xdStatusEn;
        dictPermValPtr->nameStr         = bindStp->name;

        if (bindStp->label)
        {
            dictPermValPtr->labelStr = bindStp->label;

            if (dictPermValPtr->labelStr.empty())
            {
                dictPermValPtr->labelStr = bindStp->name;
            }

            UNI_STRING1000_T uniLabel;
            DBI_ConvertFromASCII(dictPermValPtr->labelStr.c_str(), -1, uniLabel, GET_MAXDATALEN(UniString1000Type), NULL);

            dictPermValPtr->uniLabelStr = uniLabel;
        }
        else if (bindStp->uniLabel)
        {
            dictPermValPtr->uniLabelStr = bindStp->uniLabel;

            if (dictPermValPtr->uniLabelStr.isEmpty())
            {
                UNI_STRING1000_T uniLabel;
                DBI_ConvertFromASCII(bindStp->name, -1, uniLabel, GET_MAXDATALEN(UniString1000Type), NULL);

                dictPermValPtr->uniLabelStr = uniLabel;
            }

            STRING1000_T label;
            DBI_ConvertToASCII(dictPermValPtr->uniLabelStr.getTerminatedBuffer(), label, GET_MAXDATALEN(String1000Type));
            dictPermValPtr->labelStr = label;
        }
    }
}

/************************************************************************
*   Function             : DBI_BindDictLang()
*
*   Description          : Bind all columns of the fifth result set
*                          (dict_language) with the DICT_LANG_ST structure
*
*   Arguments            : callStp       : the oracle call statement.
*                          bindStEn    : the DICT_LANG_ST structure used to bind
*                                      result set columns.
*
*   Global var. modified : None
*
*   Return               : TRUE if ok
*                          FALSE if problem
*
*   Creation Date        :
*   Last Modif.          :
*************************************************************************/
int DBI_BindDictLang(RequestHelper &requestHelper, DBI_LANG_STP bindStp, bool bSingleRequest)
{
    if (bSingleRequest == false)
    {
        requestHelper.addNewResultSet();
    }

    requestHelper.addNewOutputData(DictType);
    requestHelper.getBindVariablePtr(bindStp->dictId);
    requestHelper.addNewOutputData(CodeType);
    requestHelper.getBindVariablePtr(bindStp->code);
    requestHelper.addNewOutputData(NameType);
    requestHelper.getBindVariablePtr(bindStp->name);
    requestHelper.addNewOutputData(InfoType);
    requestHelper.getBindVariablePtr(bindStp->denom);
    requestHelper.addNewOutputData(SysnameType);
    requestHelper.getBindVariablePtr(bindStp->sqlName);
    requestHelper.addNewOutputData(CodeType);
    requestHelper.getBindVariablePtr(bindStp->thousSep);
    requestHelper.addNewOutputData(CodeType);
    requestHelper.getBindVariablePtr(bindStp->decimSep);
    requestHelper.addNewOutputData(CodeType);
    requestHelper.getBindVariablePtr(bindStp->dateFmt);
    requestHelper.addNewOutputData(FlagType);
    requestHelper.getBindVariablePtr(bindStp->tslMultilingualFlg);

    if (bSingleRequest == false)
    {
        if (ICU4AAA_SQLServerUTF8)
        {
            requestHelper.addNewOutputData(UniNameType);
            requestHelper.getBindVariablePtr(bindStp->uniLabel);
        }
        else
        {
            requestHelper.addNewOutputData(NameType);
            requestHelper.getBindVariablePtr(bindStp->label);
        }
    }

    return(TRUE);
}

/************************************************************************
*   Function             : DBI_ReadDictLang()
*
*   Description          : Read all columns of the fifth result set, the
*                          dict_language records
*
*   Arguments            : callStp       : the oracle call statement.
*                          dictPermValPtr : a pointer on a DICT_LANG_ST
*                                           structure
*                          dictLangMax    : Maximum entries into the array dictPermValPtr
*                          bindStEn         : the DICT_PERM_VAL structure
*                                           used to bind result set columns.
*
*   Global var. modified : None
*
*   Return               : TRUE if ok
*                          FALSE if problem
*
*   Creation Date        :
*   Last Modif.          :
*************************************************************************/
int DBI_ReadDictLang(RequestHelper &requestHelper, std::vector<DICT_LANG_ST> &dictLangTab, DBI_LANG_STP bindStp)
{
    int i = 0;
    DICT_LANG_ST tplDictLangSt;
    SYS_Bzero(&tplDictLangSt, sizeof(tplDictLangSt));

    dictLangTab.reserve(21);
    while (requestHelper.fetch() == RET_SUCCEED)
    {
        dictLangTab.push_back(tplDictLangSt);
        DICT_LANG_ST &dictLangSt = dictLangTab.back();

        dictLangSt.dictId = *bindStp->dictId;

        strcpy(dictLangSt.code, bindStp->code);
        strcpy(dictLangSt.name, bindStp->name);
        strcpy(dictLangSt.denom, bindStp->denom);
        strcpy(dictLangSt.sqlName, bindStp->sqlName);
        strcpy(dictLangSt.thousSep, bindStp->thousSep);
        strcpy(dictLangSt.decimSep, bindStp->decimSep);
        strcpy(dictLangSt.dateFmt, bindStp->dateFmt);

        dictLangSt.tslMultilingualFlg = *bindStp->tslMultilingualFlg;

        if (bindStp->label)
        {
            strcpy(dictLangSt.label, bindStp->label);

            if (dictLangSt.label[0] == 0)
            {
                strcpy(dictLangSt.label, dictLangSt.name);
            }

            UNI_STRING1000_T uniLabel;
            DBI_ConvertFromASCII(dictLangSt.label, -1, uniLabel, GET_MAXDATALEN(UniString1000Type), NULL);

            u_strcpy(dictLangSt.uniLabel, uniLabel);
        }
        else if (bindStp->uniLabel)
        {
            u_strcpy(dictLangSt.uniLabel, bindStp->uniLabel);

            if (dictLangSt.uniLabel[0] == 0)
            {
                UNI_STRING1000_T uniLabel;
                DBI_ConvertFromASCII(bindStp->name, -1, uniLabel, GET_MAXDATALEN(UniString1000Type), NULL);

                u_strcpy(dictLangSt.uniLabel, uniLabel);
            }

            STRING1000_T label;
            DBI_ConvertToASCII(dictLangSt.uniLabel, label, GET_MAXDATALEN(String1000Type));
            strcpy(dictLangSt.label, label);
        }
        i++;
    }

    return(i);
}

/************************************************************************
*   Function             : DBI_BindDictFct()
*
*   Description          : Bind all columns of the 6th result set
*                          (dict_function) with the DICT_FCT_ST structure
*
*   Arguments            : callStp       : the oracle call statement.
*                          bindStEn    : the DICT_FCT_ST structure used to bind
*                                      result set columns.
*
*   Global var. modified : None
*
*   Return               : TRUE if ok
*                          FALSE if problem
*
*************************************************************************/
int DBI_BindDictFct(RequestHelper &requestHelper, DBI_FCT_STP bindStp)
{
    requestHelper.addNewOutputData(DictType);
    requestHelper.getBindVariablePtr(bindStp->dictId);
    requestHelper.addNewOutputData(NameType);
    requestHelper.getBindVariablePtr(bindStp->name);
    if (ICU4AAA_SQLServerUTF8)
    {
        requestHelper.addNewOutputData(UniString1000Type);
        requestHelper.getBindVariablePtr(bindStp->uniLabel);
    }
    else
    {
        requestHelper.addNewOutputData(String1000Type);
        requestHelper.getBindVariablePtr(bindStp->label);
    }

    requestHelper.addNewOutputData(SysnameType);
    requestHelper.getBindVariablePtr(bindStp->procName);
    requestHelper.addNewOutputData(DictType);
    requestHelper.getBindVariablePtr(bindStp->parFctDictId);
    requestHelper.addNewOutputData(DictType);
    requestHelper.getBindVariablePtr(bindStp->entDictId);
    requestHelper.addNewOutputData(DictType);
    requestHelper.getBindVariablePtr(bindStp->orderEntryFctDictId);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->natEn);
    requestHelper.addNewOutputData(SysnameType);
    requestHelper.getBindVariablePtr(bindStp->helpNode);
    requestHelper.addNewOutputData(SysnameType);
    requestHelper.getBindVariablePtr(bindStp->iconName);
    requestHelper.addNewOutputData(SmallintType);
    requestHelper.getBindVariablePtr(bindStp->rank);
    requestHelper.addNewOutputData(IdType);
    requestHelper.getBindVariablePtr(bindStp->funcSecuProfId);
    requestHelper.addNewOutputData(DictType);
    requestHelper.getBindVariablePtr(bindStp->entityDictId);
    requestHelper.addNewOutputData(IdType);
    requestHelper.getBindVariablePtr(bindStp->typeId);
    requestHelper.addNewOutputData(IdType);
    requestHelper.getBindVariablePtr(bindStp->subtypeId);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->minOpStatus);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->maxOpStatus);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->securityLevel);
    requestHelper.addNewOutputData(FlagType);
    requestHelper.getBindVariablePtr(bindStp->createFlag);
    requestHelper.addNewOutputData(FlagType);
    requestHelper.getBindVariablePtr(bindStp->updateFlag);
    requestHelper.addNewOutputData(FlagType);
    requestHelper.getBindVariablePtr(bindStp->deleteFlag);
    requestHelper.addNewOutputData(FlagType);
    requestHelper.getBindVariablePtr(bindStp->riskViewFlag);
    requestHelper.addNewOutputData(FlagType);
    requestHelper.getBindVariablePtr(bindStp->realTimeFlag);
    requestHelper.addNewOutputData(FlagType);
    requestHelper.getBindVariablePtr(bindStp->viewFlag);
    requestHelper.addNewOutputData(FlagType);
    requestHelper.getBindVariablePtr(bindStp->visibleFlag);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->licenseKeyEn);
    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(bindStp->accesStatus);

    return(TRUE);
}

/************************************************************************
*   Function             : DBI_ReadDictFct()
*
*   Description          : Read all columns of the 6th result set, the
*                          dict_function records
*
*   Arguments            : callStp       : the oracle call statement.
*                          dictFctPtr     : a pointer on a DICT_FCT_ST
*                                           structure
*                          dictFctMax     : Maximum entries into the array dictFctPtr
*                          bindStEn         : the DICT_FCT structure
*                                           used to bind result set columns.
*
*   Global var. modified : None
*
*   Return               : TRUE if ok
*                          FALSE if problem
*
*************************************************************************/
int DBI_ReadDictFct(RequestHelper &requestHelper, std::vector<DICT_FCT_ST> &dictFctTab, DBI_FCT_STP bindStp)
{
    int i = 0;
    DICT_FCT_ST tplDictFctSt;
    SYS_Bzero(&tplDictFctSt, sizeof(tplDictFctSt));

    dictFctTab.reserve(300);

    while (requestHelper.fetch() == RET_SUCCEED)
    {
        dictFctTab.push_back(tplDictFctSt);
        DICT_FCT_ST &dictFctSt = dictFctTab.back();

        dictFctSt.dictId              = *bindStp->dictId;
        strcpy(dictFctSt.name, bindStp->name);
        strcpy(dictFctSt.procName, bindStp->procName);
        dictFctSt.parFctDictId        = *bindStp->parFctDictId;
        dictFctSt.entDictId           = *bindStp->entDictId;
        dictFctSt.orderEntryFctDictId = *bindStp->orderEntryFctDictId;
        dictFctSt.natEn               = *bindStp->natEn;
        strcpy(dictFctSt.helpNode, bindStp->helpNode);
        strcpy(dictFctSt.iconName, bindStp->iconName);
        dictFctSt.rank                = *bindStp->rank;
        dictFctSt.funcSecuProfId      = *bindStp->funcSecuProfId;
        dictFctSt.entityDictId        = *bindStp->entityDictId;
        dictFctSt.typeId              = *bindStp->typeId;
        dictFctSt.subtypeId           = *bindStp->subtypeId;
        dictFctSt.minOpStatus         = *bindStp->minOpStatus;
        dictFctSt.maxOpStatus         = *bindStp->maxOpStatus;
        dictFctSt.securityLevel       = *bindStp->securityLevel;
        dictFctSt.createFlag          = *bindStp->createFlag;
        dictFctSt.updateFlag          = *bindStp->updateFlag;
        dictFctSt.deleteFlag          = *bindStp->deleteFlag;
        dictFctSt.riskViewFlag        = *bindStp->riskViewFlag;
        dictFctSt.realTimeFlag        = *bindStp->realTimeFlag;
        dictFctSt.viewFlag            = *bindStp->viewFlag;
        dictFctSt.visibleFlag         = *bindStp->visibleFlag;
        dictFctSt.licenseKeyEn        = static_cast<DICT_LICENSEKEY_ENUM>(*bindStp->licenseKeyEn);
        dictFctSt.accesStatus         = static_cast<DICT_FCTAUTH_ENUM>(*bindStp->accesStatus);

        if (bindStp->label)
        {
            strcpy(dictFctSt.label, bindStp->label);

            if (dictFctSt.label[0] == 0)
            {
                strcpy(dictFctSt.label, dictFctSt.name);
            }

            UNI_STRING1000_T uniLabel;
            DBI_ConvertFromASCII(dictFctSt.label, -1, uniLabel, GET_MAXDATALEN(UniString1000Type), NULL);

            u_strcpy(dictFctSt.uniLabel, uniLabel);
        }
        else if (bindStp->uniLabel)
        {
            u_strcpy(dictFctSt.uniLabel, bindStp->uniLabel);

            if (dictFctSt.uniLabel[0] == 0)
            {
                UNI_STRING1000_T uniLabel;
                DBI_ConvertFromASCII(bindStp->name, -1, uniLabel, GET_MAXDATALEN(UniString1000Type), NULL);

                u_strcpy(dictFctSt.uniLabel, uniLabel);
            }

            STRING1000_T label;
            DBI_ConvertToASCII(dictFctSt.uniLabel, label, GET_MAXDATALEN(String1000Type));
            strcpy(dictFctSt.label, label);
        }

        i++;
    }

    return(i);
}

/************************************************************************
*   Function             : DBI_BindDictDataTp()
*
*   Description          : Bind all columns of the 7th result set
*                          (dict_datatype) with the DICT_DATATP_ST structure
*
*   Arguments            : callStp       : the oracle call statement.
*                          bindStEn    : the DICT_DATATP_ST structure used to
*                                      bind result set columns.
*
*   Global var. modified : None
*
*   Return               : TRUE if ok
*                          FALSE if problem
*
*   Creation Date        :
*   Last Modif.          :
*************************************************************************/
int DBI_BindDictDataTp(RequestHelper &requestHelper, DBI_DATATP_STP bindStp, bool bSingleRequest)
{
    if (bSingleRequest == false)
    {
        requestHelper.addNewResultSet();
    }

    requestHelper.addNewOutputData(DictType);
    requestHelper.getBindVariablePtr(bindStp->dictId);
    requestHelper.addNewOutputData(NameType);
    requestHelper.getBindVariablePtr(bindStp->name);
    requestHelper.addNewOutputData(SysnameType);
    requestHelper.getBindVariablePtr(bindStp->sqlName);
    requestHelper.addNewOutputData(NameType);
    requestHelper.getBindVariablePtr(bindStp->equivType);
    requestHelper.addNewOutputData(NameType);
    requestHelper.getBindVariablePtr(bindStp->equivTypeSyb);
    requestHelper.addNewOutputData(NameType);
    requestHelper.getBindVariablePtr(bindStp->equivTypeOra);
    requestHelper.addNewOutputData(NameType);
    requestHelper.getBindVariablePtr(bindStp->equivTypeNuoDB);
    requestHelper.addNewOutputData(NameType);
    requestHelper.getBindVariablePtr(bindStp->equivTypeMsSql);
    requestHelper.addNewOutputData(NameType);
    requestHelper.getBindVariablePtr(bindStp->equivTypePgs);
    requestHelper.addNewOutputData(SmallintType);
    requestHelper.getBindVariablePtr(bindStp->progN);
    requestHelper.addNewOutputData(FlagType);
    requestHelper.getBindVariablePtr(bindStp->custAuthFlg);
    requestHelper.addNewOutputData(SmallintType);
    requestHelper.getBindVariablePtr(bindStp->defMaxDbLenN);
    requestHelper.addNewOutputData(SmallintType);
    requestHelper.getBindVariablePtr(bindStp->defDefaultDisplayLenN);

    if (bSingleRequest == false)
    {
        if (ICU4AAA_SQLServerUTF8)
        {
            requestHelper.addNewOutputData(UniString1000Type);
            requestHelper.getBindVariablePtr(bindStp->uniLabel);
        }
        else
        {
            requestHelper.addNewOutputData(String1000Type);
            requestHelper.getBindVariablePtr(bindStp->label);
        }
    }

    return(TRUE);
}

/************************************************************************
*   Function             : DBI_ReadDictDataTp()
*
*   Description          : Read all columns of the 7th result set, the
*                          dict_datatype records
*
*   Arguments            : callStp       : the oracle call statement.
*                          dictDataTpPtr  : a pointer on a DICT_DATATP_ST
*                                           structure
*                          dictDataTpMax  : Maximum entries into the array dictDataTpPtr
*                          bindStEn         : the DICT_DATATP structure
*                                           used to bind result set columns.
*
*   Global var. modified : None
*
*   Return               : TRUE if ok
*                          FALSE if problem
*
*************************************************************************/
int DBI_ReadDictDataTp(RequestHelper &requestHelper, std::vector<DICT_DATATP_ST> &dictDataTpTab, DBI_DATATP_STP bindStp)
{
    int            i = 0;
    DICT_DATATP_ST tplDictDataTpSt;
    SYS_Bzero(&tplDictDataTpSt, sizeof(tplDictDataTpSt));

    dictDataTpTab.reserve(55);
    while (requestHelper.fetch() == RET_SUCCEED)
    {
        dictDataTpTab.push_back(tplDictDataTpSt);
        DICT_DATATP_ST &dictDataTp = dictDataTpTab.back();

        dictDataTp.dictId = *bindStp->dictId;
        if (bindStp->name != nullptr)
        {
            strcpy(dictDataTp.name, bindStp->name);
        }
        strcpy(dictDataTp.sqlName, bindStp->sqlName);
        strcpy(dictDataTp.equivType, bindStp->equivType);
        strcpy(dictDataTp.equivTypeSyb, bindStp->equivTypeSyb);
        strcpy(dictDataTp.equivTypeOra, bindStp->equivTypeOra);
        strcpy(dictDataTp.equivTypeNuoDB, bindStp->equivTypeNuoDB);
        strcpy(dictDataTp.equivTypeMsSql, bindStp->equivTypeMsSql);
        strcpy(dictDataTp.equivTypePgs, bindStp->equivTypePgs);
        dictDataTp.progN = *bindStp->progN;

        if (bindStp->custAuthFlg != nullptr)
        {
            dictDataTp.custAuthFlg           = *bindStp->custAuthFlg;
            dictDataTp.defDefaultDisplayLenN = *bindStp->defDefaultDisplayLenN;
        }
        dictDataTp.defMaxDbLenN = *bindStp->defMaxDbLenN;

        if (bindStp->label != nullptr)
        {
            strcpy(dictDataTp.label, bindStp->label);

            if (dictDataTp.label[0] == 0)
            {
                strcpy(dictDataTp.label, dictDataTp.name);
            }

            UNI_STRING1000_T uniLabel;
            DBI_ConvertFromASCII(dictDataTp.label, -1, uniLabel, GET_MAXDATALEN(UniString1000Type), NULL);

            u_strcpy(dictDataTp.uniLabel, uniLabel);
        }
        else if (bindStp->uniLabel != nullptr)
        {
            u_strcpy(dictDataTp.uniLabel, bindStp->uniLabel);

            if (dictDataTp.uniLabel[0] == 0)
            {
                UNI_STRING1000_T uniLabel;
                DBI_ConvertFromASCII(bindStp->name, -1, uniLabel, GET_MAXDATALEN(UniString1000Type), NULL);

                u_strcpy(dictDataTp.uniLabel, uniLabel);
            }

            STRING1000_T label;
            DBI_ConvertToASCII(dictDataTp.uniLabel, label, GET_MAXDATALEN(String1000Type));
            strcpy(dictDataTp.label, label);
        }

        switch (EV_RdbmsDdlGen)
        {
            case Sybase:
                strcpy(dictDataTp.equivType, dictDataTp.equivTypeSyb);
                break;
            case Oracle:
                strcpy(dictDataTp.equivType, dictDataTp.equivTypeOra);
                break;
            case Nuodb:
                strcpy(dictDataTp.equivType, dictDataTp.equivTypeNuoDB);
                break;
            case MSSql:
                strcpy(dictDataTp.equivType, dictDataTp.equivTypeMsSql);
                break;
            case PostgreSQL:
                strcpy(dictDataTp.equivType, dictDataTp.equivTypePgs);
                break;

        }
        i++;
    }
    return(i);
}

/************************************************************************
**
**  Function        :   DBI_LoadDictFctByUserId
**
**  Description     :   Suppress, modify loaded meta dictionary according to
**
**  Arguments       :
**
**  Return          :   RET_CODE
**
**  Creation        :   FPL-REF11314-060508
**
**  Last modif.     :
**
************************************************************************/
RET_CODE DBI_LoadDictFctByUserId(ID_T userId, std::vector<DICT_FCT_ST> &fctTab)
{
    DBA_DYNFLD_STP  inputArg = NULL;
    RET_CODE        ret = RET_SUCCEED;
    DbiConnectionHelper dbiConnHlp;
    DBA_DYNFLD_STP *outputTab = (DBA_DYNFLD_STP*)NULL;
    int             outputNbr = 0;

    /*  test for security   */
    if (userId <= 0)
    {
        MSG_LogSrvMesg(UNUSED, UNUSED, "DBI_LoadDictFctByUserId(level -3) returns RET_GEN_ERR_INVARG as userId==%1", IdType, userId); /* PMSTA-32214 - CHU - 180726  */
        return RET_GEN_ERR_INVARG;
    }

    if ((inputArg = ALLOC_DYNST(S_ApplUser)) == NULL)
    {
        MSG_LogSrvMesg(UNUSED, UNUSED, "DBI_LoadDictFctByUserId(level -3) returns RET_MEM_ERR_ALLOC as inputArg is NULL"); /* PMSTA-32214 - CHU - 180726  */
        return(RET_MEM_ERR_ALLOC);
    }

    SET_ID(inputArg, S_ApplUser_Id, userId);

    if ((ret = DBA_Select2(DictFct, UNUSED, S_ApplUser, inputArg,
        E_DictFct, &outputTab, UNUSED, &outputNbr, dbiConnHlp)) != RET_SUCCEED)
    {
        MSG_LogSrvMesg(UNUSED, UNUSED, "DBI_LoadDictFctByUserId(level -3) returns RET_DBA_ERR_NODATA as DBA_Select2() returned %1", IntType, ret); /* PMSTA-32214 - CHU - 180726  */
        FREE_DYNST(inputArg, S_ApplUser);
        MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "appl_user");
        return(RET_DBA_ERR_NODATA);
    }
    FREE_DYNST(inputArg, S_ApplUser);

    if (outputNbr == 0)
    {
        MSG_LogSrvMesg(UNUSED, UNUSED, "DBI_LoadDictFctByUserId(level -3) returns RET_DBA_ERR_NODATA as outputNbr == 0", IntType, ret); /* PMSTA-32214 - CHU - 180726  */
        DBA_FreeDynStTab(outputTab, outputNbr, E_DictFct);
        MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "appl_user");
        return(RET_DBA_ERR_NODATA);
    }

    /* Allocate the fctTab */
    fctTab.resize(outputNbr);

    for (int i = 0; i < outputNbr; i++)
    {
        /* populate the fctTab */
        fctTab[i].dictId = GET_DICT(outputTab[i], E_DictFct_DictId);
        strcpy(fctTab[i].name, GET_NAME(outputTab[i], E_DictFct_Name));
        if (ICU4AAA_SQLServerUTF8)
        {
            if (IS_NULLFLD(outputTab[i], E_DictFct_Label) == FALSE)
                u_strcpy(fctTab[i].uniLabel, GET_USTRING(outputTab[i], E_DictFct_Label));
        }
        else if (IS_NULLFLD(outputTab[i], E_DictFct_Label) == FALSE)
            strcpy(fctTab[i].label, GET_VARSTRING1000(outputTab[i], E_DictFct_Label));
        if (IS_NULLFLD(outputTab[i], E_DictFct_ProcName) == FALSE)
            strcpy(fctTab[i].procName, GET_SYSNAME(outputTab[i], E_DictFct_ProcName));
        fctTab[i].parFctDictId        = GET_DICT(outputTab[i], E_DictFct_ParFctDictId);
        fctTab[i].entDictId           = GET_DICT(outputTab[i], E_DictFct_EntDictId);
        fctTab[i].orderEntryFctDictId = GET_DICT(outputTab[i], E_DictFct_OrderEntryFctDictId);
        fctTab[i].natEn               = GET_ENUM(outputTab[i], E_DictFct_NatEn);
        fctTab[i].typeId              = GET_ID(outputTab[i], E_DictFct_TypeId);
        fctTab[i].subtypeId           = GET_ID(outputTab[i], E_DictFct_SubTypeId);
        fctTab[i].refFctDictId        = GET_DICT(outputTab[i], E_DictFct_EntDictId);
        if (IS_NULLFLD(outputTab[i], E_DictFct_HelpNode) == FALSE)
            strcpy(fctTab[i].helpNode, GET_SYSNAME(outputTab[i], E_DictFct_HelpNode));
        if (IS_NULLFLD(outputTab[i], E_DictFct_IconName) == FALSE)
            strcpy(fctTab[i].iconName, GET_INFO(outputTab[i], E_DictFct_IconName));
        fctTab[i].rank           = GET_SMALLINT(outputTab[i], E_DictFct_Rank);
        fctTab[i].funcSecuProfId = GET_ID(outputTab[i], E_DictFct_FuncSecuProfId);
        fctTab[i].entityDictId = GET_DICT(outputTab[i], E_DictFct_EntityDictId);
        fctTab[i].minOpStatus = GET_ENUM(outputTab[i], E_DictFct_MinOpStatus);
        fctTab[i].maxOpStatus = GET_ENUM(outputTab[i], E_DictFct_MaxOpStatus);
        fctTab[i].securityLevel = GET_ENUM(outputTab[i], E_DictFct_SecurityLevel);
        fctTab[i].createFlag = GET_FLAG(outputTab[i], E_DictFct_CreateFlg);
        fctTab[i].updateFlag = GET_FLAG(outputTab[i], E_DictFct_UpdateFlg);
        fctTab[i].deleteFlag = GET_FLAG(outputTab[i], E_DictFct_DeleteFlg);
        fctTab[i].riskViewFlag = GET_FLAG(outputTab[i], E_DictFct_RiskViewFlg);
        fctTab[i].realTimeFlag = GET_FLAG(outputTab[i], E_DictFct_RealTimeFlg);
        fctTab[i].viewFlag = GET_FLAG(outputTab[i], E_DictFct_ViewFlg);
        fctTab[i].visibleFlag = GET_FLAG(outputTab[i], E_DictFct_VisibleFlg);
        fctTab[i].licenseKeyEn = (DICT_LICENSEKEY_ENUM) GET_ENUM(outputTab[i], E_DictFct_LicenseKeyEn);
        fctTab[i].accesStatus = (DICT_FCTAUTH_ENUM) GET_ENUM(outputTab[i], E_DictFct_AccessStatus);
    }

    DBA_FreeDynStTab(outputTab, outputNbr, E_DictFct);

    /*  Update accessibility for function linked to license     */      /*  HFI-PMSTA-35838-190515  */
    DBA_CheckLicenseInfoFunction(fctTab);

    return ret;
}

/************************************************************************
**   END  dbidict.c                                                    **
*************************************************************************/

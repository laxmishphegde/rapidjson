/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DBALIB05_C

/************************************************************************
*	Local Functions
*
* DBA_Check                       : Send a CHECK (stored procedure begining wich "chk_..." request to the server and retrieve
*                                   returned status.
* DBA_Notif                       : Send a NOTIF request to the server and retrieve returned status.
* DBA_Notif2                      : Send a NOTIF request to the server and retrieve returned status.
* DBA_Cancel                      : Set the connection state to Free, free all allocated arrays and cancel all pending results
*                                   for the command.
* DBA_MultiFree                   : Free all allocated dynamic structures, e.g. after a call to DBA_MultiSelect.
* DBA_Get2                        : Send a GET request to the server and retrieve returned row (if any).
* DBA_Select2                     : Send a SELECT request to the server and retrieve returned data.
* DBA_MultiSelect2                : Send a MULTI SELECT request to the server and retrieve returned data sets.
* DBA_Insert2                     : Send a INSERT request to the server and retrieve returned status.
* DBA_Update2                     : Send a UPDATE request to the server and retrieve returned status.
* DBA_Delete2                     : Send a DELETE request to the server and retrieve returned status.
* DBA_Copy                        : Send a COPY request to the server and retrieve returned status.
* DBA_InsUpd                      : Send a INSERT/UPDATE request to the server and retrieve returned status.
*************************************************************************/

/************************************************************************
**      Include files
*************************************************************************/
#include <assert.h>

#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H

#include "unidef.h"     /* Mandatory */
#include "gen.h"
#include "dba.h"
#include "date.h"
#include "cmp.h"

#ifndef TLS_H
#include "tls.h"
#endif

#include "hier.h"
#include "scptyl.h"
#include "rpclib.h"

#ifndef OPE_H
#include "ope.h"
#endif

#ifndef SCPT_H
#include "scpt.h"
#endif

#include "conlocprovider.h"
#include "conexcept.h"

#ifdef AAAPROFILER
#include "Tracy.hpp"
#endif
/**********************************
**      Static definitions & data
***********************************/

extern FLAG_T       EV_IsSubscriptionActive;             /* REF4204 */
extern	GUI_OPTI_STATUS_ENUM	EV_GuiCheckOptiStatus;

extern char EV_SetProcParametersFlg;
extern TIMER_STP EV_ExtractFileTimerPtr;    /* REF7264 - PMO */
extern bool EV_LogFSPSecuCheck; /* PMSTA-32214 - CHU - 180731 */

#define ITER_NBR_FOR_DEADLOCK       4    /* Ref.: DVP251 */

/************************************************************************
*   Function             : DBI_ConvDynFldToSybData()
*
*   Description          :
*
*   Arguments            :
*                               fldPtr (may be NULL)
*
*   Functions call       :
*
*   Global var. modified :
*
*   Return               : RET_CODE
*************************************************************************/
RET_CODE DBA_SendMesgForProcResType(const char *procName, int resultType)
{
    switch (resultType)
    {
        case DBI_CMD_DONE:
            MSG_SendMesg(RET_DBA_ERR_DBPROBLEM, 1, FILEINFO, procName, "done result type");
            break;
        case DBI_CMD_FAIL:
            MSG_SendMesg(RET_DBA_ERR_DBPROBLEM, 1, FILEINFO, procName, "fail result type");
            break;
        case DBI_CMD_SUCCEED:
            MSG_SendMesg(RET_DBA_ERR_DBPROBLEM, 1, FILEINFO, procName, "succeed result type");
            break;
        case DBI_COMPUTE_RESULT:
            MSG_SendMesg(RET_DBA_ERR_DBPROBLEM, 1, FILEINFO, procName, "compute result type");
            break;
        case DBI_CURSOR_RESULT:
            MSG_SendMesg(RET_DBA_ERR_DBPROBLEM, 1, FILEINFO, procName, "cursor result type");
            break;
        case DBI_PARAM_RESULT:
            MSG_SendMesg(RET_DBA_ERR_DBPROBLEM, 1, FILEINFO, procName, "parameter result type");
            break;
        case DBI_STATUS_RESULT:
            MSG_SendMesg(RET_DBA_ERR_DBPROBLEM, 1, FILEINFO, procName, "status result type");
            break;
        case DBI_COMPUTEFMT_RESULT:
            MSG_SendMesg(RET_DBA_ERR_DBPROBLEM, 1, FILEINFO, procName, "compute info. result type");
            break;
        case DBI_ROWFMT_RESULT:
            MSG_SendMesg(RET_DBA_ERR_DBPROBLEM, 1, FILEINFO, procName, "row format result type");
            break;
        case DBI_MSG_RESULT:
            MSG_SendMesg(RET_DBA_ERR_DBPROBLEM, 1, FILEINFO, procName, "message result type");
            break;
        case DBI_DESCRIBE_RESULT:
            MSG_SendMesg(RET_DBA_ERR_DBPROBLEM, 1, FILEINFO, procName, "dynamic SQL descr. result type");
            break;
    }

    return(RET_SUCCEED);
}


/************************************************************************
*   Function             : DBA_LogMesgProcedureNotFound()
*
*   Description          : Log the message: Procedure not found in internal list .....
*                          And provide why we didn't find the procedure
*
*   Arguments            : action           : the action to execute (Get, Select,...)
*                          object           : the request corresponding object
*                          role             : role used for the selection
*                          inputSt          : the input dynamic struct. format
*                          inputData        : the pointer on the input dynamic struct.
*                          outputSt         : the output dynamic struct. format
*                          dbAccess         : kind of database access Get, Insert, ...
*                          objString        : the request corresponding object has string
*                          entitySqlNameIn  : the input  dynamic struct name has string
*                          entitySqlNameOut : the output dynamic struct name has string
*
*   Return               : None
*
*   Creation Date        : PMSTA-24985 - 111016 - PMO : Connection crash
*
*   Last Modification    :
*
*************************************************************************/
void DBA_LogMesgProcedureNotFound(  DBA_ACTION_ENUM action,
                                    OBJECT_ENUM     object,
                                    int             role,
                                    DBA_DYNST_ENUM  inputSt,
                                    DBA_DYNFLD_STP  inputData,
                                    DBA_DYNST_ENUM  outputSt,
                                    bool            bTryToAvoidInteralProc,
                                    const char *    dbAccess,
                                    const char *    objString,
                                    const char *    entitySqlNameIn,
                                    const char *    entitySqlNameOut)
{
    std::string explanation;

    (void)DBA_GetStoredProcs(action, object, role, inputSt, inputData, outputSt, bTryToAvoidInteralProc, &explanation);

    (void)MSG_LogMesg(RET_DBA_ERR_PROCNOTFOUND, 4, FILEINFO, dbAccess, objString, role, entitySqlNameIn, entitySqlNameOut, explanation.c_str());

    SYS_BreakOnDebug(); /* DLA 040224 */
}


/************************************************************************
*   Function             : DBA_SetTimeout()
*
*   Description          : Optional setting of the timestamp
*
*   Arguments            : object       : the request corresponding object
*                          dbiConn      : Connection Helper
*
*   Functions call       : None
*
*   Return               : None
*
*   Creation Date        : PMSTA-25090 - 191016 - PMO : Fusion not completing with HttpConnectionHandler problem
*
*   Last Modification    : PMSTA-25644 - 141216 - PMO : When dispatch Server configuration change (host or port) => need to restart all fin & fusion servers
*
*************************************************************************/
void DBA_SetTimeout(DBA_PROC_STP procedure, DbiConnection * dbiConn)
{
    if (nullptr != procedure && FinServer == procedure->server && nullptr != dbiConn)   /* PMSTA-25644 - 141216 - PMO */
    {
        RpcProperties       rpcProperties;
        const std::string   rpcName (procedure->procName);

        if (true == DBI_GetRpcParamInfoStp(rpcName, rpcProperties))
        {
            const RpcTimeOut * rpcTimeOut = rpcProperties.getRpcTimeOut();

            if (nullptr != rpcTimeOut && true == rpcTimeOut->isEnable())
            {
                const unsigned timeOut = rpcTimeOut->getTimeOutMiliSec();
                if (timeOut > 0)
                {
                    dbiConn->setTimeOutMiliSec(timeOut);
                }
            }
        }
    }
}


/************************************************************************
*   Function             : DBA_Notif()
*
*   Description          : Send a NOTIF request to the server and retrieve
*                          returned status
*
*   Arguments            : object       : the request corresponding object
*                          inputSt      : the input dynamic struct. format
*                          inputData    : the pointer on the input dynamic struct.
*                          notifStatus  : indicate if the Notif result
*
*   Functions call       : DBA_GetConnection
*                          DBA_GetStoredProcs
*                          DBI_SetProcParameters
*                          DBA_EndConnection
*
*   Return               : TRUE if ok
*                          FALSE if problem
*                          DBA_CONN_NOT_FOUND if no connection found
*
*   Creation Date        : Dec.  94 - PEC
*   Last Modification    : 03.11.95 - PEC - Added call to function DBA_FilterMsgInfos
*                          12.12.96 - PEC - Ref.: DVP307
*                          06.05.98 - GRD - REF1472.
*                          12.11.98 - GRD - Ref.: REF3016.
*                          27.09.99 - GRD - Ref.: REF3847.
*                          REF7264 - 0201225 - PMO : Compilation errors and warnings with C++ compiler
*                          PMSTA-18094 - 130514 - PMO : Avoid extracting the user credentials from the GUI running on Windows (via dump, etc.)
*                          PMSTA-24985 - 111016 - PMO : Connection crash
*
*************************************************************************/
RET_CODE DBA_Notif(OBJECT_ENUM    object,
                   int            role,
                   DBA_DYNST_ENUM inputSt,
                   DBA_DYNFLD_STP inputData,
                   int            *allocConn,
                   int            notifOptions)
{
    RET_CODE        retCode   = RET_SUCCEED;
    DbiConnection*  dbiConn   = nullptr;

    /* Retrieve a procedure in the object procedures list */
    DBA_PROC_STP procedure = DBA_GetStoredProcs(Notif, object, role, inputSt, inputData, NullDynSt);

    /* If no procedure */
    if (procedure == NULL)
    {
        if ((notifOptions & DBA_NO_PROC_ERROR) == 0) /* PMSTA-13946 - LJE - 120328 */
        {
            char    objString[40];
            const char *sqlName = DBA_GetDictEntitySqlName(object);
            OBJECT_ENUM objEn;                  /* REF2697 - SSO - 000510 */
            const char        *entitySqlNameIn = NULL;  /* REF2697 - SSO - 000510 */
            char        entityStrIn[13];        /* REF2697 - SSO - 000510 */

            if (sqlName != NULL)
            {
                strcpy(objString, sqlName);
            }
            else
            {
                sprintf(objString, "unknown(" szFormatObj ")", object);/* REF2697 - SSO - 000510 */
            }

            DBA_GetObjectEnumByDynSt(inputSt, &objEn);  /* REF2697 - SSO - 000510 */
            entitySqlNameIn = DBA_GetDictEntitySqlName(objEn);
            if (entitySqlNameIn == NULL)
            {
                entitySqlNameIn = DBA_GetDynStCName(inputSt);
            }
            if (entitySqlNameIn == NULL)
            {
                sprintf(entityStrIn, "unknown(%d)", inputSt);
                entitySqlNameIn = entityStrIn;
            }

            DBA_LogMesgProcedureNotFound(Notif, object, role, inputSt, inputData, NullDynSt, false, "Notif", objString, entitySqlNameIn, "none"); /* PMSTA-24985 - 111016 - PMO */
        }
        return(RET_DBA_ERR_PROCNOTFOUND);
    }

    if (allocConn != NULL && ((notifOptions & DBA_SET_CONN) == DBA_SET_CONN) && DBA_GetConnServerType(*allocConn) != procedure->server)
    {
        notifOptions &= ~(DBA_SET_CONN | DBA_NO_CLOSE);
    }
    /* PMSTA-14972 - JPP - 20121005 >*/

    /* If no connection number is given */
    if ((notifOptions & DBA_SET_CONN) != DBA_SET_CONN)
    {
        /* Get a free connection in the connection list */
        if ((dbiConn = DBA_GetDbiConnection(procedure->server)) == nullptr)
        {
            return(DBA_CONN_NOT_FOUND);
        }
    }
    else
    {
        /* If a connection number is given */
        if (allocConn != UNUSED)
        {
            dbiConn = DBA_GetDbiConnFromConnectNo(*allocConn);
            if (dbiConn == nullptr) {
                return RET_DBA_ERR_CONNOTFOUND;
            }
        }
        else
        {
#ifdef AAADEBUGMSG
            MSG_SendMesg(RET_DBA_ERR_ARGNOMATCH, 0, FILEINFO);
#endif
            return(FALSE); /* Input Argument error */
        }
    }

    retCode = DBA_Notif(object,
                        role,
                        inputSt,
                        inputData,
                        *dbiConn,
                        notifOptions);

    bool isInError = (retCode == RET_DBA_ERR_DIALOG);
    if (isInError)
    {
        dbiConn->setValidConnection(false);
    }
    if ((notifOptions & DBA_NO_CLOSE) != DBA_NO_CLOSE)
    {
        DBA_EndConnection(&dbiConn, isInError);
    }

    return retCode;
}


/************************************************************************
*   Function             : DBA_Notif()
*
*   Description          : Call DBA_Notif with a Connection Helper
*
*   Arguments            : object       : the request corresponding object
*                          inputSt      : the input dynamic struct. format
*                          inputData    : the pointer on the input dynamic struct.
*                          dbiConn      : Connection Helper
*
*   Functions call       : DBA_Notif
*
*   Return               : Result of DBA_Notif
*
*   Creation Date        : PMSTA-21215 - 271015 - PMO : RPC with code has input parameters
*
*   Last Modification    : PMSTA-24985 - 111016 - PMO : Connection crash
*                          PMSTA-25090 - 191016 - PMO : Fusion not completing with HttpConnectionHandler problem
*
*************************************************************************/
RET_CODE DBA_Notif(OBJECT_ENUM             object,
                   int                     role,
                   DBA_DYNST_ENUM          inputSt,
                   DBA_DYNFLD_STP          inputData,
                   DbiConnectionHelper &   dbiConn)
{
    return DBA_Notif(object, role, inputSt, inputData, *dbiConn.getConnection(), DBA_SET_CONN | DBA_NO_CLOSE);
}


STATIC RET_CODE DBA_NotifCore(OBJECT_ENUM    object,
                              int            role,
                              DBA_DYNST_ENUM inputSt,
                              DBA_DYNFLD_STP inputData,
                              DbiConnection  &dbiConn,
                              int            notifOptions,
                              bool &         dialogError)
{
#ifdef AAAPROFILER
    ZoneScopedNS("DBA_NotifCore", 5);
#endif

    DBI_INT         resultType  = DBI_STATUS_RESULT;
    DBI_INT         status      = UNUSED;        /* BUG452 - 970826 - XMT: initialize local variable */
    RET_CODE        finalResult = RET_SUCCEED;

    dialogError = false;

    /* Retrieve a procedure in the object procedures list */
    DBA_PROC_STP procedure =  DBA_GetStoredProcs(Notif, object, role, inputSt, inputData, NullDynSt);

    /* If no procedure */
    if (procedure == NULL)
    {
		if ((notifOptions & DBA_NO_PROC_ERROR) == 0) /* PMSTA-13946 - LJE - 120328 */
		{
            char            objString[40];
            OBJECT_ENUM     objEn;                      /* REF2697 - SSO - 000510 */
            const char *    entitySqlNameIn = NULL;     /* REF2697 - SSO - 000510 */
            char            entityStrIn[13];            /* REF2697 - SSO - 000510 */
            const char     *sqlName = DBA_GetDictEntitySqlName(object);

            if (sqlName != NULL)
            {
                strcpy(objString, sqlName);
            }
            else
            {
                sprintf(objString, "unknown(" szFormatObj ")",object);/* REF2697 - SSO - 000510 */
            }

            DBA_GetObjectEnumByDynSt(inputSt, &objEn);  /* REF2697 - SSO - 000510 */
            entitySqlNameIn = DBA_GetDictEntitySqlName(objEn);
	        if (entitySqlNameIn == NULL)
	        {
			    entitySqlNameIn = DBA_GetDynStCName(inputSt);
		    }
            if (entitySqlNameIn == NULL)
            {
                sprintf(entityStrIn,"unknown(%d)",inputSt);
                entitySqlNameIn = entityStrIn;
            }

            DBA_LogMesgProcedureNotFound(Notif, object, role, inputSt, inputData, NullDynSt, false, "Notif", objString, entitySqlNameIn, "none"); /* PMSTA-24985 - 111016 - PMO */
		}
        return(RET_DBA_ERR_PROCNOTFOUND);
    }
    /*< PMSTA-14972 - JPP - 20121005 */

    if (USE_NEW_ACCESS_API(&dbiConn))
    {
        RequestHelper requestHelper(&dbiConn);

        if (requestHelper.startProcedureCall(procedure, inputData) == false)
        {
            return(requestHelper.getLastResultRetCode());
        }
        status = requestHelper.getLastStatus();
    }
    else
    {
        /* Optional setting of the timestamp PMSTA-25090 - 191016 - PMO */
        DBA_SetTimeout(procedure, &dbiConn);
        dbiConn.setReadOnly(procedure);             /* PMSTA-37366 - LJE - 200702 */

        bool localTranFlg = false;
        if (dbiConn.isReadOnly() == false &&
            dbiConn.isInTransaction() == false &&
            dbiConn.isAutoCommit() == false &&
            procedure->server == SqlServer)
        {
            localTranFlg = true;
            dbiConn.beginTransaction(true);
        }

        /* Retrieve and memorize parameters names and types in the meta dictionary tables */
        if (DBI_SetProcParameters(dbiConn, inputSt, inputData, procedure) != RET_SUCCEED)
        {
            FLAG_T        isReconnectSucceeded = FALSE;    /* REF3016 */
            dbiConn.releaseCommand();
            if (dbiConn.getDescription().getType() == FinServer)
            {
                if (AAALocalConnectionProvider::get().reconnect(dbiConn) == true &&
                    DBI_SetProcParameters(dbiConn, inputSt, inputData, procedure) == RET_SUCCEED)
                {
                    isReconnectSucceeded = TRUE;
                }
            }

            if (isReconnectSucceeded == FALSE)    /* REF3016 */
            {
                MSG_SendMesg(RET_DBA_ERR_SETPARAM, 0, FILEINFO);
                dialogError = true;     /* PMSTA-25644 - 141216 - PMO */
                return RET_DBA_ERR_SETPARAM;
            }
        }

        /* Send the request to the server */
        if (dbiConn.sendRequest(&resultType) != RET_SUCCEED)
        {
            dbiConn.processAllResults(&status); /* PMSTA-23385 - LJE - 160630 */
            dbiConn.filterMsgInfos(&finalResult); /* PMSTA14726 - DDV - 120809 - Empty list of all error raised */

            /* PMSTA-46404 - DDV - 211013 - Try to reconnect only for connection on financial server. As it is describe in REF3016 */
            if (dbiConn.getDescription().getType() == FinServer)
            {
                AAALocalConnectionProvider::get().reconnect(dbiConn);
                if (dbiConn.isValid() == false || dbiConn.isConnected() == false)
                {
                    dialogError = true;     /* PMSTA-25644 - 141216 - PMO */
                    return RET_DBA_ERR_CONNLOST;
                }

                if (DBI_SetProcParameters(dbiConn, inputSt, inputData, procedure) != RET_SUCCEED)
                {
                    MSG_SendMesg(RET_DBA_ERR_SETPARAM, 0, FILEINFO);
                    return(RET_DBA_ERR_SETPARAM);
                }

                if (dbiConn.sendRequest(&resultType) != RET_SUCCEED)
                {
                    dbiConn.processAllResults(&status); /* PMSTA-23385 - LJE - 160630 */
                    dbiConn.filterMsgInfos(&finalResult); /* PMSTA14726 - DDV - 120809 - Empty list of all error raised */
                    MSG_SendMesg(RET_DBA_ERR_DIALOG, 0, FILEINFO);
                    return(RET_DBA_ERR_DIALOG);
                }
            }
            else
            {
                MSG_SendMesg(RET_DBA_ERR_DIALOG, 0, FILEINFO);
                return(RET_DBA_ERR_DIALOG);
            }
        }

        /* PMSTA-24510 - 220816 - PMO */
        const bool ignoreEmptyHttpResult = DBI_ROW_RESULT == resultType && NullDynSt == *procedure->outputDynStPtr;

        if (resultType != DBI_STATUS_RESULT && resultType != DBI_CMD_SUCCEED && false == ignoreEmptyHttpResult)
        {
            /* REF3955 - SSO - 000107 added DBA_FilterMsgInfos + test */
            DBA_FilterMsgInfos(dbiConn, &finalResult);
            if (finalResult == RET_SRV_LIB_ERR_INV_PARAM_VALUE)
            {
                dbiConn.setValidConnection(false);
            }
            else
            {
                dbiConn.processAllResults(&status); /* PMSTA-23385 - LJE - 160630 */
                dbiConn.filterMsgInfos(&finalResult); /* PMSTA14726 - DDV - 120809 - Empty list of all error raised */
            }

            if (localTranFlg)
            {
                dbiConn.endTransaction(FALSE);
            }
            MSG_SendMesg(RET_DBA_ERR_DBPROBLEM, 0, FILEINFO);
            return(RET_DBA_ERR_DBPROBLEM);
        }

        dbiConn.processAllResults(&status); /* PMSTA-23385 - LJE - 160630 */
        dbiConn.filterMsgInfos(&finalResult); /* PMSTA14726 - DDV - 120809 - Empty list of all error raised */

        if (localTranFlg)
        {
            dbiConn.endTransaction(finalResult == RET_SUCCEED ? TRUE : FALSE);
        }
    }

    if(EV_ExtractFile && EV_SetProcParametersFlg)
    {
        DATE_ResetTimer(EV_ExtractFileTimerPtr, TIMER_MASK_GEN);
        DATE_StartTimer(EV_ExtractFileTimerPtr, TIMER_MASK_GEN);
        EV_SetProcParametersFlg = FALSE;
    }

    return(finalResult);
}


/************************************************************************
*   Function             : DBA_Notif()
*
*   Description          : Handling the configuration change when DBA_NotifCore call failed
*
*   Arguments            : object       : the request corresponding object
*                          inputSt      : the input dynamic struct. format
*                          inputData    : the pointer on the input dynamic struct.
*                          dbiConn      : Connection Helper
*
*   Functions call       : DBA_NotifCore
*
*   Return               : Result of DBA_NotifCore
*
*   Creation Date        :
*
*   Last Modification    : PMSTA-25644 - 141216 - PMO : When dispatch Server configuration change (host or port) => need to restart all fin & fusion servers
*
*************************************************************************/
RET_CODE DBA_Notif(OBJECT_ENUM    object,
                   int            role,
                   DBA_DYNST_ENUM inputSt,
                   DBA_DYNFLD_STP inputData,
                   DbiConnection & dbiConn,
                   int            notifOptions)
{
    RET_CODE            ret         = RET_SUCCEED;
    bool                dialogError = false;
    DbiConnectionHelper dbiConnHelper(&dbiConn, false);

    for (int retry = 0 ; retry < 3; retry++ )
    {
        try
        {
            if (dbiConnHelper.isValidAndInit() &&
                nullptr != dbiConnHelper.getConnection())
            {
                ret = DBA_NotifCore(object, role, inputSt, inputData, *dbiConnHelper.getConnection(), notifOptions, dialogError);
            }

            if (RET_SUCCEED != ret && true == dialogError && (FinServer == dbiConnHelper.getDescription().getType() || DispatchServer == dbiConnHelper.getDescription().getType()))
            { // Maybe the configuration has changed
                ClientConfig                clientConfig;
                const ServerClientConfig &  serverClientConfig = clientConfig.getServerClientConfig(dbiConnHelper.getDescription().getServerName());

                if (0 != dbiConnHelper.getDescription().getUrl().compare(serverClientConfig.getUrl()))
                { // Configuration has changed
                    dbiConnHelper.reloadDescription();
                    dbiConnHelper.reopen();
                }
            }

            if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
            { // Ok
                break;
            }
        }
        catch (AAACannotConnectDbException& e)
        {
            MSG_SendExceptionMesg(FILEINFO, e.getCallStack(), e.what());                        /* PMSTA-21907 - 281215 - PMO */
            ret = RET_DBA_ERR_DBPROBLEM;
        }

    }

    return ret;
}


/************************************************************************
*   Function             : DBA_Notif2()
*
*   Description          : Send a NOTIF request to the server and retrieve
*                          returned status
*
*   Arguments            : object       : the request corresponding object
*                          role         :
*                          inputSt      : the input dynamic struct. format
*                          inputData    : the pointer on the input dynamic struct.
*                          notifOptions : can be DBA_SET_CONN, DBA_NO_CLOSE
*                          allocConn    : a connection number pointer
*                          msgStructPtr : message structure pointer
*
*   Return               : RET_SUCCEED              : if ok
*                          RET_DBA_ERR_ARGNOMATCH   : if input arg. problem
*                          RET_DBA_ERR_PROCNOTFOUND : if no procedure founded
*                          RET_DBA_ERR_SETPARAM     : if problem while setting proc. parameters
*                          RET_DBA_ERR_CONNOTFOUND  : if no connection founded
*                          RET_DBA_ERR_DBPROBLEM    : if DB/connection problem
*                          RET_DBA_ERR_SYBBIND      : if poblem while binding received fields
*                          RET_MEM_ERR_ALLOC        : if allocation failed
*                          RET_DBA_ERR_READ_DATA    : if problem while reading received data
*                          RET_GEN_ERR_INVARG       : if problem while setting function params.
*                          a RET_CODE               : if a message has been received
*
*   Creation Date        : Dec.  94 - PEC
*   Last Modification    : 03.11.95 - PEC - Added call to function DBA_FilterMsgInfos
*                          12.11.98 - GRD - Ref.: REF3016.
*                          27.09.99 - GRD - Ref.: REF3847.
*                          REF7264 - 0201225 - PMO : Compilation errors and warnings with C++ compiler
*                          PMSTA-18094 - 130514 - PMO : Avoid extracting the user credentials from the GUI running on Windows (via dump, etc.)
*                          PMSTA-24985 - 111016 - PMO : Connection crash
*
*************************************************************************/
RET_CODE DBA_Notif2(OBJECT_ENUM    object,
                    int             role,
                    DBA_DYNST_ENUM  inputSt,
                    DBA_DYNFLD_STP  inputData,
                    int             notifOptions,
                    int             *allocConn,
                    DBA_ERRMSG_INFOS_STP msgStructPtr)
{
    RET_CODE              retCode    = RET_SUCCEED;
    DbiConnectionHelper * dbiConnHelper = nullptr;

    /* Retrieve a procedure in the object procedures list */
    DBA_PROC_STP procedure = DBA_GetStoredProcs(Notif, object, role, inputSt, inputData, NullDynSt);

    /* If no procedure */
    if (procedure == NULL)
    {
        if ((notifOptions & DBA_NO_PROC_ERROR) == 0) /* PMSTA-13946 - LJE - 120328 */
        {
            char    objString[40];
            const char *sqlName = DBA_GetDictEntitySqlName(object);
            OBJECT_ENUM objEn;                  /* REF2697 - SSO - 000510 */
            const char        *entitySqlNameIn = NULL;  /* REF2697 - SSO - 000510 */
            char        entityStrIn[13];        /* REF2697 - SSO - 000510 */

            if (sqlName != NULL)
            {
                strcpy(objString, sqlName);
            }
            else
            {
                sprintf(objString, "unknown(" szFormatObj ")", object);/* REF2697 - SSO - 000510 */
            }

            DBA_GetObjectEnumByDynSt(inputSt, &objEn);  /* REF2697 - SSO - 000510 */
            entitySqlNameIn = DBA_GetDictEntitySqlName(objEn);
            if (entitySqlNameIn == NULL)
            {
                entitySqlNameIn = DBA_GetDynStCName(inputSt);
            }
            if (entitySqlNameIn == NULL)
            {
                sprintf(entityStrIn, "unknown(%d)", inputSt);
                entitySqlNameIn = entityStrIn;
            }

            DBA_LogMesgProcedureNotFound(Notif, object, role, inputSt, inputData, NullDynSt, false, "Notif", objString, entitySqlNameIn, "none"); /* PMSTA-24985 - 111016 - PMO */
        }
        return(RET_DBA_ERR_PROCNOTFOUND);
    }


    /* If no connection number is given */
    if ((notifOptions & DBA_SET_CONN) != DBA_SET_CONN)
    {
        /* Get a free connection */

        if ((dbiConnHelper = new DbiConnectionHelper(procedure->server)) == nullptr)
        {
            return(RET_DBA_ERR_CONNOTFOUND);
        }
    }
    else
    {
        /* If a connection number is given */
        if (allocConn != NULL) /*   FPL-PMSTA06305-080508   */
        {
            dbiConnHelper = new DbiConnectionHelper(DBA_GetDbiConnFromConnectNo(*allocConn), (notifOptions & DBA_NO_CLOSE) != DBA_NO_CLOSE);
            if (dbiConnHelper == nullptr)
            {
                return RET_DBA_ERR_CONNOTFOUND;
            }
        }
        else
        {
            return(RET_DBA_ERR_ARGNOMATCH);
        }
    }

    retCode = DBA_Notif2(object,
                         role,
                         inputSt,
                         inputData,
                         notifOptions,
                         *dbiConnHelper,
                         msgStructPtr);

    const bool isInError = (retCode == RET_DBA_ERR_DIALOG);
    if (isInError)
    {
        dbiConnHelper->getConnection()->setValidConnection(false);
    }

    delete dbiConnHelper;
    return retCode;
}

/************************************************************************
*   Function             : DBA_Notif2()
*
*   Description          : Call DBA_Notif2 with a Connection Helper
*
*   Arguments            : object       : the request corresponding object
*                          role         : role
*                          inputSt      : the input dynamic struct. format
*                          inputData    : the pointer on the input dynamic struct.
*                          dbiConn      : Connection
"                          notifStatus  : Return status of the notification
"                          msgStructPtr : Errors....
*
*   Functions call       : DBA_Notif
*
*   Return               : Result of DBA_Notif
*
*   Creation Date        : PMSTA-21215 - 271015 - PMO : RPC with code has input parameters
*
*   Last Modification    : DLA - PMSTA20062 - 160115
*                          PMSTA-24510 - 220816 - PMO : Fusion & Dispatcher in HTTP
*
*************************************************************************/
RET_CODE DBA_Notif2(OBJECT_ENUM          object,
                    int                  role,
                    DBA_DYNST_ENUM       inputSt,
                    DBA_DYNFLD_STP       inputData,
                    int                  notifOptions,
                    DbiConnection&       dbiConn,
                    DBA_ERRMSG_INFOS_STP msgStructPtr)
{
    DbiConnectionHelper dbiConnHelper(&dbiConn, false);
    dbiConnHelper.dbaSetOptions(notifOptions | DBA_SET_CONN | DBA_NO_CLOSE);
    dbiConnHelper.reopenHttpOnThreadChange();    /* PMSTA-24510 - 220816 - PMO */

    return DBA_Notif2(object, role, inputSt, inputData, dbiConnHelper);
}

/************************************************************************
*   Function             : DBA_Notif2()
*
*   Description          : Call DBA_Notif2 with a Connection Helper
*
*   Arguments            : object       : the request corresponding object
*                          role         : role
*                          inputSt      : the input dynamic struct. format
*                          inputData    : the pointer on the input dynamic struct.
*                          dbiConn      : Connection Helper
"                          notifStatus  : Return status of the notification
"                          msgStructPtr : Errors....
*
*   Functions call       : DBA_Notif
*
*   Return               : Result of DBA_Notif
*
*   Creation Date        : PMSTA-21215 - 271015 - PMO : RPC with code has input parameters
*
*   Last Modification    : DLA - PMSTA20062 - 160115
*
*************************************************************************/
RET_CODE DBA_Notif2(OBJECT_ENUM         object,
                    int                  role,
                    DBA_DYNST_ENUM       inputSt,
                    DBA_DYNFLD_STP       inputData,
                    int                  notifOptions,
                    DbiConnectionHelper& dbiConnHelper,
                    DBA_ERRMSG_INFOS_STP msgStructPtr)
{
    RET_CODE ret = RET_SUCCEED;
    dbiConnHelper.dbaSetOptions(notifOptions | DBA_SET_CONN | DBA_NO_CLOSE);
    ret =  DBA_Notif2( object,
                       role,
                       inputSt,
                       inputData,
                       dbiConnHelper);
    return ret;
}


/************************************************************************
*   Function             : DBA_Notif2()
*
*   Description          : Call DBA_Notif2 with a Connection Helper
*
*   Arguments            : object       : the request corresponding object
*                          role         : role
*                          inputSt      : the input dynamic struct. format
*                          inputData    : the pointer on the input dynamic struct.
*                          dbiConn      : Connection Helper
"                          notifStatus  : Return status of the notification
"                          msgStructPtr : Errors....
*
*   Functions call       : DBA_Notif
*
*   Return               : Result of DBA_Notif
*
*   Creation Date        : PMSTA-21215 - 271015 - PMO : RPC with code has input parameters
*
*   Last Modification    : DLA - PMSTA20062 - 160115
*                          PMSTA-24510 - 220816 - PMO : Fusion & Dispatcher in HTTP
*                          PMSTA-24985 - 111016 - PMO : Connection crash
*                          PMSTA-25090 - 191016 - PMO : Fusion not completing with HttpConnectionHandler problem
*
*************************************************************************/
RET_CODE DBA_Notif2(OBJECT_ENUM         object,
                   int                  role,
                   DBA_DYNST_ENUM       inputSt,
                   DBA_DYNFLD_STP       inputData,
                   DbiConnectionHelper& dbiConnHelper)
{
#ifdef AAAPROFILER
    ZoneScopedNS("DBA_Notif2", 5);
#endif

    DbaCallGuard dbaCallGuard(dbiConnHelper); /* PMSTA-45413 - LJE - 210804 */

    DBI_INT         resultType, status;
	RET_CODE        finalResult=RET_SUCCEED;
	FLAG_T			outputParamF = FALSE;

    /* Retrieve a procedure in the object procedures list */
    DBA_PROC_STP procedure = DBA_GetStoredProcs(Notif, object, role, inputSt, inputData, NullDynSt);
    const int notifOptions = dbiConnHelper.dbaGetOptions();

    /* If no procedure */
    if (procedure == NULL)
    {
        if ((notifOptions & DBA_NO_PROC_ERROR) == 0) /* PMSTA-13946 - LJE - 120328 */
        {
            char	    objString[40];
            OBJECT_ENUM objEn;		            /* REF2697 - SSO - 000510 */
            const char *entitySqlNameIn = NULL; /* REF2697 - SSO - 000510 */
            char	    entityStrIn[13];	    /* REF2697 - SSO - 000510 */
            const char *sqlName         = DBA_GetDictEntitySqlName(object);

            if (sqlName != NULL)
            {
                strcpy(objString, sqlName);
            }
            else
            {
                sprintf(objString, "unknown(" szFormatObj ")", object);/* REF2697 - SSO - 000510 */
            }

            DBA_GetObjectEnumByDynSt(inputSt, &objEn);  /* REF2697 - SSO - 000510 */
            entitySqlNameIn = DBA_GetDictEntitySqlName(objEn);
            if (entitySqlNameIn == NULL)
            {
                entitySqlNameIn = DBA_GetDynStCName(inputSt);
            }
            if (entitySqlNameIn == NULL)
            {
                sprintf(entityStrIn, "unknown(%d)", inputSt);
                entitySqlNameIn = entityStrIn;
            }

            DBA_LogMesgProcedureNotFound(Notif, object, role, inputSt, inputData, NullDynSt, false, "Notif", objString, entitySqlNameIn, "none"); /* PMSTA-24985 - 111016 - PMO */
        }
        return(RET_DBA_ERR_PROCNOTFOUND);
    }
    dbiConnHelper.setCurrProcedure(procedure);  /* PMSTA-45413 - LJE - 210804 */

    if (dbiConnHelper.isValidAndInit() == false)
    {
        return(RET_DBA_ERR_CONNOTFOUND);
    }

    if (USE_NEW_ACCESS_API(dbiConnHelper.getConnection()))
    {
        RequestHelper requestHelper(dbiConnHelper);

        if (requestHelper.startProcedureCall(procedure, inputData) == false)
        {
            return(requestHelper.getLastResultRetCode());
        }
        status      = requestHelper.getLastStatus();
    }
    else
    {
        DbiConnection * dbiConn = dbiConnHelper.getConnection();

        /* Optional setting of the timestamp PMSTA-25090 - 191016 - PMO */
        DBA_SetTimeout(procedure, dbiConn);
        dbiConn->setReadOnly(procedure);             /* PMSTA-37366 - LJE - 200702 */

        bool localTranFlg = false;
        if (dbiConn->isReadOnly() == false &&
            dbiConn->isInTransaction() == false &&
            dbiConn->isAutoCommit() == false &&
            procedure->server == SqlServer)
        {
            localTranFlg = true;
            dbiConn->beginTransaction(true);
        }

        /* Retrieve and memorize parameters names and types in the meta dictionary tables */
        if (DBI_SetProcParameters(*dbiConn, inputSt, inputData, procedure) != RET_SUCCEED)
        {
            FLAG_T		isReconnectSucceeded = FALSE;	/* REF3016 */
            dbiConn->releaseCommand();
            if (dbiConn->getDescription().getType() == FinServer)
            {
                if (AAALocalConnectionProvider::get().reconnect(*dbiConn) == true &&
                    DBI_SetProcParameters(*dbiConn, inputSt, inputData, procedure) == RET_SUCCEED)
                {
                    isReconnectSucceeded = TRUE;
                }
            }

            if (isReconnectSucceeded == FALSE)	/* REF3016 */
            {
                if (localTranFlg)
                {
                    dbiConn->endTransaction(FALSE);
                }

                return(RET_DBA_ERR_SETPARAM);
            }
        }

        /* Send the request to the server */
        if (dbiConn->sendRequest(&resultType) != RET_SUCCEED)
        {
            dbiConn->processAllResults(&status); /* PMSTA-23385 - LJE - 160630 */
            dbiConn->filterMsgInfos(&finalResult); /* PMSTA14726 - DDV - 120809 - Get all error raised */

            if (localTranFlg)
            {
                dbiConn->endTransaction(FALSE);
            }

            if(dbiConnHelper.getSilentMode())    /* PMSTA-45390 - JBC - 210607 */
            {
                return RET_DBA_ERR_DBPROBLEM;
            }
			
            /* PMSTA-18593 - LJE - 150617 */
            if (dbiConn->emptyMsg() == false && SYS_IsBatchMode())
            {
                dbiConn->sendAllMsg();
                return RET_DBA_ERR_DBPROBLEM;
            }         
            else
            {
                MSG_RETURN(RET_DBA_ERR_DBPROBLEM);
            }
        }

        /* PMSTA-24510 - 220816 - PMO */
        const bool ignoreEmptyHttpResult = DBI_ROW_RESULT == resultType && NullDynSt == *procedure->outputDynStPtr;

        if (resultType != DBI_STATUS_RESULT && resultType != DBI_PARAM_RESULT && resultType != DBI_CMD_SUCCEED && false == ignoreEmptyHttpResult)   /* DLA - PMSTA09887 - 101206 */
        {
            dbiConn->processAllResults(&status); /* PMSTA-23385 - LJE - 160630 */
            dbiConn->filterMsgInfos(&finalResult); /* PMSTA14726 - DDV - 120809 - Get all error raised */
            MSG_RETURN(RET_DBA_ERR_DBPROBLEM);
        }

        DBA_PROCPARAM_STP procParam = procedure->procParamDefPtr;

        while (procParam != NULL && procParam->paramName[0] != END_OF_STRING && outputParamF == FALSE)
        {
            outputParamF = procParam->procParamTypeEn >= ProcParamType_Output ? TRUE : FALSE;
            procParam++;
        }

        if (outputParamF == TRUE)
        {
            dbiConn->processAllResults(&status, GET_OBJ_DYNST(*procedure->inputDynStPtr), *procedure->inputDynStPtr, inputData, procedure);
        }
        else
        {
            dbiConn->processAllResults(&status); /* PMSTA-23385 - LJE - 160630 */
        }
        /* Call to function which will filter received messages during Get operation */
        dbiConn->filterMsgInfos(&finalResult);

        if (localTranFlg)
        {
            dbiConn->endTransaction(finalResult == RET_SUCCEED ? TRUE : FALSE);
        }
    }

	/* Free the connection if it must be closed */

	if (finalResult != RET_SUCCEED)
	{
		return(finalResult);
	}

	if(EV_ExtractFile && EV_SetProcParametersFlg)
	{
		EV_SetProcParametersFlg = FALSE;
	}

	return(RET_SUCCEED);
}

/************************************************************************
*   Function               : DBA_Cancel()
*
*   Description            : Set the connection state to Free, free all
*                            allocated arrays and cancel all pending
*                            results for the command
*
*   Arguments              : connectNo : the connection number in the list
*
*   Functions call         : DBA_EndConnection
*
*   Global var. modified   : SV_ConnectionList
*
*   Return                 : RET_SUCCEED            : if ok
*                            RET_DBA_ERR_ARGNOMATCH : if problem with argument
*
*   Creation date          : Aug. 94 - PEC
*   Last moditication date : 29.8.95 - PEC
*************************************************************************/
RET_CODE DBA_Cancel(DbiConnection& dbiConn)
{
    DBI_INT status;

	dbiConn.processAllResults(&status); /* PMSTA-23385 - LJE - 160630 */
	DbiConnection *dbiConnPtr = &dbiConn;
    if (DBA_EndConnection(&dbiConnPtr) != RET_SUCCEED)
    {
        MSG_RETURN(RET_DBA_ERR_ARGNOMATCH);
    }
    return(RET_SUCCEED);
}

/************************************************************************
*   Function             : DBA_MultiFree()
*
*   Description          : Free all allocated dynamic structures, e.g. after a call
*                          to DBA_MultiSelect.
*
*   Arguments            : data      : pointer on a DBA_DYNFLD_STP pointer array
*                          dynStLst  : the format of dynamic structure contained in
*                                      each data set.
*                          dataRows  : the dynamic structure number for each set
*                          setNumber : the set number
*
*
*   Functions call       : DBA_Free
*
*   Return               : RET_SUCCEED            : if ok
*                          RET_DBA_ERR_ARGNOMATCH : if problem with input argument
*
*   Creation Date        : Nov.  94 - PEC
*   Last Modification    : REF7264 - 0201225 - PMO : Compilation errors and warnings with C++ compiler
*************************************************************************/
RET_CODE DBA_MultiFree(DBA_DYNFLD_STP **data, const DBA_DYNST_ENUM **dynStLst, int *dataRows, int setNumber)
{
    int i;

	if (!dynStLst)
		MSG_RETURN(RET_DBA_ERR_ARGNOMATCH);

	if (!dataRows)
		MSG_RETURN(RET_DBA_ERR_ARGNOMATCH);

    for (i=0 ; i<setNumber ; i++)
    {
        DBA_FreeDynStTab(data[i], dataRows[i], *(dynStLst[i])); /* REF8844 - LJE - 030415 */
    }

    return(RET_SUCCEED);
}

/************************************************************************
*   Function             : DBA_Get2()
*
*   Description          : Send a GET request to the server and retrieve
*                          returned row (if any)
*
*   Arguments            : object       : the request corresponding object
*                          role         : the role of the request
*                          inputSt      : the input dynamic struct. format
*                          inputData    : the pointer on the input dynamic struct.
*                          outputSt     : the output dynamic struct. format
*                          outputData   : the pointer on the output dyn. struct. array
*                          getOptions   : can be DBA_SET_CONN, DBA_NO_CLOSE
*                          allocConn    : 1. pointer which will contain the connectNo
*                                            used for the request if getOptions is
*                                            DBA_NO_CLOSE.
*                                         2. pointer which contain a connection number
*                                            if getOptions is DBA_SET_CONN.
*                          msgStructPtr : pointer on a structure which will contain
*                                         recieved messages informations.
*
*   Return               : RET_SUCCEED              : if no problem was detected
*                          RET_DBA_ERR_ARGNOMATCH   : if input arg. problem
*                          RET_DBA_ERR_PROCNOTFOUND : if no procedure founded
*                          RET_DBA_INFO_NODATA      : if no data founded
*                          RET_DBA_ERR_SETPARAM     : if problem while setting proc. parameters
*                          RET_DBA_ERR_CONNOTFOUND  : if no connection founded
*                          RET_DBA_ERR_DBPROBLEM    : if DB/connection problem
*                          RET_DBA_ERR_SYBBIND      : if poblem while binding received fields
*                          RET_MEM_ERR_ALLOC        : if allocation failed
*                          RET_DBA_ERR_READ_DATA    : if problem while reading received data
*                          RET_GEN_ERR_INVARG       : if problem while setting function params.
*                          a RET_CODE               : if a message has been received
*
*   Last modification    : 16.09.95 - PEC - Added the test on InternalProc
*                          28.12.95 - PEC - Added arguments getOptions, allocConn
*                                           msgStructPtr.
*                                           Function now return a RET_CODE.
*                          12.12.96 - PEC - Ref.: DVP307.
*                          06.05.98 - GRD - Ref.: REF1472.
*                          12.11.98 - GRD - Ref.: REF3016.
*                          27.09.99 - GRD - Ref.: REF3847.
*                          REF7264 - 0201225 - PMO : Compilation errors and warnings with C++ compiler
*                          REF9108 - YST - 030703
*                          PMSTA-18094 - 130514 - PMO : Avoid extracting the user credentials from the GUI running on Windows (via dump, etc.)
*                          PMSTA-24985 - 111016 - PMO : Connection crash
*
*************************************************************************/
RET_CODE DBA_Get2(OBJECT_ENUM          object,
                  int                  role,
                  DBA_DYNST_ENUM       inputSt,
                  DBA_DYNFLD_STP       inputData,
                  DBA_DYNST_ENUM       outputSt,
                  DBA_DYNFLD_STP       *outputData,
                  int                  getOptions,
                  int                  *allocConn,
                  DBA_ERRMSG_INFOS_STP msgStructPtr)
{
    if (outputData == nullptr || *outputData == nullptr)
        return(RET_DBA_ERR_ARGNOMATCH);

    DbiConnectionHelper *   dbiConnHelper  = nullptr;
    DBA_PROC_STP            procedure      = DBA_GetStoredProcs(Get, object, role, inputSt, inputData, outputSt);

	/* If no procedure was found */
	if (procedure == NULL)
	{
		if ((getOptions & DBA_NO_PROC_ERROR) == 0) /* PMSTA-13946 - LJE - 120328 */
		{
			char	objString[40];
            const char	*sqlName = DBA_GetDictEntitySqlName(object);
			OBJECT_ENUM objEn;		    /* REF2697 - SSO - 000510 */
			const char	    *entitySqlNameIn = NULL, *entitySqlNameOut = NULL;  /* REF2697 - SSO - 000510 */
			char	    entityStrIn[13];	    /* REF2697 - SSO - 000510 */
			char	    entityStrOut[13];	    /* REF2697 - SSO - 000510 */

			if (sqlName != NULL)
			{
				strcpy(objString, sqlName);
			}
			else
			{
				sprintf(objString, "unknown(" szFormatObj ")", object);/* REF2697 - SSO - 000510 */
			}

			DBA_GetObjectEnumByDynSt(inputSt, &objEn);  /* REF2697 - SSO - 000510 */
			entitySqlNameIn = DBA_GetDictEntitySqlName(objEn);
			/* PMSTA-13122 - LJE - 120420 */
			if (entitySqlNameIn == NULL)
			{
				entitySqlNameIn = DBA_GetDynStCName(inputSt);
			}
			if (entitySqlNameIn == NULL)
			{
				sprintf(entityStrIn, "unknown(%d)", inputSt);
				entitySqlNameIn = entityStrIn;
			}
			DBA_GetObjectEnumByDynSt(outputSt, &objEn);  /* REF2697 - SSO - 000510 */
			entitySqlNameOut = DBA_GetDictEntitySqlName(objEn);
			if (entitySqlNameOut == NULL)
			{
				sprintf(entityStrOut, "unknown(%d)", outputSt);
				entitySqlNameOut = entityStrOut;
			}

            DBA_LogMesgProcedureNotFound(Get, object, role, inputSt, inputData, outputSt, false, "Get", objString, entitySqlNameIn, entitySqlNameOut);  /* PMSTA-24985 - 111016 - PMO */
		}
		return(RET_DBA_ERR_PROCNOTFOUND);
	}

	/* If no connection number is given */
	if ((getOptions & DBA_SET_CONN) != DBA_SET_CONN)
	{
		/* Get a free connection */

        if ((dbiConnHelper = new DbiConnectionHelper(procedure->server)) == nullptr)
		{
			return(RET_DBA_ERR_CONNOTFOUND);
		}
	}
	else
	{
		/* If a connection number is given */
		if (allocConn != NULL)
		{
            dbiConnHelper = new DbiConnectionHelper(DBA_GetDbiConnFromConnectNo(*allocConn),(getOptions & DBA_NO_CLOSE) != DBA_NO_CLOSE);
			if (dbiConnHelper == nullptr)
            {
				return RET_DBA_ERR_CONNOTFOUND;
			}
		}
		else
		{
			return(RET_DBA_ERR_ARGNOMATCH);
		}
	}

    RET_CODE retCode = dbiConnHelper->dbaGet(object, role, inputData, outputData);

    dbiConnHelper->sendAllMsg();

    const bool isInError = (retCode == RET_DBA_ERR_DIALOG);
    if (isInError)
    {
        dbiConnHelper->getConnection()->setValidConnection(false);
    }

    delete dbiConnHelper;
	return retCode;
}


/************************************************************************
*   Function             : DBA_Get2()
*
*   Description          : Call DBA_Get2 with a Connection Helper
*
*   Arguments            : object       : the request corresponding object
*                          inputSt      : the input dynamic struct. format
*                          inputData    : the pointer on the input dynamic struct.
*                          dbiConn      : Connection Helper
*
*   Functions call       : DBA_Notif
*
*   Return               : Result of DBA_Notif
*
*   Creation Date        : PMSTA-21215 - 271015 - PMO : RPC with code has input parameters
*
*   Last Modification    : PMSTA-24985 - 111016 - PMO : Connection crash
*                          PMSTA-25587 - 21.0.08 - Test case PerformanceAnalysis/KRA_PPDA_TEST_01 is blocked: Importation process is not triggered
*                          PMSTA-32315 - 260718 - PMO : Improve error message "WUI User does not have Data Security Access..."
*
*************************************************************************/
RET_CODE DBA_Get2(OBJECT_ENUM              object,
                    int                    role,
                    DBA_DYNST_ENUM         inputSt,
                    DBA_DYNFLD_STP         inputData,
                    DBA_DYNST_ENUM         outputSt,
                    DBA_DYNFLD_STP *       outputData,
                    int                    getOptions,
                    DbiConnection &        dbiConn,
                    DBA_ERRMSG_INFOS_STP   msgStructPtr,
                    DBA_ERRMSG_HEADER_STP  dbaErrMsgHeaderStp) /* PMSTA-49780- BSV- 040722 */
{
    DbiConnectionHelper dbiConnHelper(&dbiConn, false);

    dbiConnHelper.dbaSetOptions(dbiConnHelper.dbaGetOptions() | getOptions);

    RET_CODE ret = dbiConnHelper.dbaGet(object, role, inputData, outputData);

    dbiConn.sendAllMsg();

    /* PMSTA-49780- BSV- 040722 */
    //dbaErrMsgHeaderStp is default argument. if it's nullptr don't copy objects.
    if (dbaErrMsgHeaderStp != nullptr)
        dbaErrMsgHeaderStp->copyDbaErrMsgHeaderClassObject(*dbiConnHelper.dbaGetMsgStructHeader());

    return(ret);
}

/************************************************************************
*   Function             : DBA_Get2()
*
*   Description          : Call DBA_Get2 with a Connection Helper
*
*   Arguments            : object       : the request corresponding object
*                          inputSt      : the input dynamic struct. format
*                          inputData    : the pointer on the input dynamic struct.
*                          dbiConn      : Connection Helper
*
*   Functions call       : DBA_Notif
*
*   Return               : Result of DBA_Notif
*
*   Creation Date        : PMSTA-21215 - 271015 - PMO : RPC with code has input parameters
*
*   Last Modification    : PMSTA-24985 - 111016 - PMO : Connection crash
*                          PMSTA-25587 - 21.0.08 - Test case PerformanceAnalysis/KRA_PPDA_TEST_01 is blocked: Importation process is not triggered
*                          PMSTA-32315 - 260718 - PMO : Improve error message "WUI User does not have Data Security Access..."
*
*************************************************************************/
RET_CODE DBA_Get2(OBJECT_ENUM            object,
                  int                    role,
                  DBA_DYNFLD_STP         inputData,
                  DBA_DYNFLD_STP *       outputData,
                  DbiConnection  *       dbiConn)
{
    DbiConnectionHelper dbiConnHelper(dbiConn);

    RET_CODE ret = dbiConnHelper.dbaGet(object, role, inputData, outputData);

    return(ret);
}

/************************************************************************
*   Function             : DBA_Select2()
*
*   Description          : Send a SELECT request to the server and retrieve
*                          returned data
*
*   Arguments            : object       : the request corresponding object
*                          role         : the role of the request
*                          inputSt      : the input dynamic struct. format
*                          inputData    : the pointer on the input dynamic struct.
*                          outputSt     : the output dynamic struct. format
*                          outputData   : the pointer on the output dyn. struct.
*                                         array pointer
*                          SelOptions   : indicate many info about the request (ALLOC,
*                                         FETCH, ...).
*                          maxRows      : pointer which contain the desirated (if any)
*                                         or result rows number.
*                          resultRows   : the returned row number, if specified
*                          allocConn    : the connection number allocated
*                          msgStructPtr : message structure pointer
*
*   Return               : RET_SUCCEED              : if no problem was detected
*                          RET_DBA_ERR_ARGNOMATCH   : if input arg. problem
*                          RET_DBA_ERR_PROCNOTFOUND : if no procedure founded
*                          RET_DBA_INFO_NODATA      : if no data founded
*                          RET_DBA_ERR_SETPARAM     : if problem while setting proc. parameters
*                          RET_DBA_ERR_CONNOTFOUND  : if no connection founded
*                          RET_DBA_ERR_DBPROBLEM    : if DB/connection problem
*                          RET_DBA_ERR_SYBBIND      : if poblem while binding received fields
*                          RET_MEM_ERR_ALLOC        : if allocation failed
*                          RET_DBA_ERR_READ_DATA    : if problem while reading received data
*                          RET_GEN_ERR_INVARG       : if problem while setting function params.
*                          a RET_CODE               : if a message has been received
*
*   Creation Date        : 06.05.96 - PEC
*   Last Modification    : 19.11.96 - PEC - Ref.: DVP255
*                          21.11.96 - PEC - Ref.: DVP262
*                          12.12.96 - PEC - Ref.: DVP307
*                          06.05.98 - GRD - Ref.: REF1472
*                          REF7264 - 0201225 - PMO : Compilation errors and warnings with C++ compiler
*                          REF8500 - 040510 - PMO : Add a draft_order_id in extended operation to distinguish the id from extended orders and the one from extended operation
*                          PMSTA-24985 - 111016 - PMO : Connection crash
*
*************************************************************************/
RET_CODE DBA_Select2(OBJECT_ENUM          object,
                     int                  role,
                     DBA_DYNST_ENUM       inputSt, DBA_DYNFLD_STP inputData,
                     DBA_DYNST_ENUM       outputSt, DBA_DYNFLD_STP **outputData,
                     int                  selOptions,
                     int                  maxRows,
                     int *resultRows,
                     int *allocConn,
                     DBA_ERRMSG_INFOS_STP msgStructPtr)
{
	 RET_CODE               retCode    = RET_SUCCEED;
	 DbiConnectionHelper*	dbiConnHelper = nullptr;

	 /* Choose a procedure in the object procedures list and store the necessary parameter */
	 DBA_PROC_STP procedure = DBA_GetStoredProcs(Select, object, role, inputSt, inputData, outputSt);

	 /* If no procedure was found */
	 if (procedure == NULL)
	 {
		 if ((selOptions & DBA_NO_PROC_ERROR) == 0) /* PMSTA-13946 - LJE - 120328 */
		 {
			 char	objString[40];
             const char	*sqlName = DBA_GetDictEntitySqlName(object);
			 OBJECT_ENUM objEn;		    /* REF2697 - SSO - 000510 */
			 const char	    *entitySqlNameIn = NULL, *entitySqlNameOut = NULL;  /* REF2697 - SSO - 000510 */
			 char	    entityStrIn[13];	    /* REF2697 - SSO - 000510 */
			 char	    entityStrOut[13];	    /* REF2697 - SSO - 000510 */

			 if (sqlName != NULL)
			 {
				 strcpy(objString, sqlName);
			 }
			 else
			 {
				 sprintf(objString, "unknown(" szFormatObj ")", object);/* REF2697 - SSO - 000510 */
			 }

			 if (inputSt == NullDynSt) /* PMSTA-13109 - LJE - 111128 */
			 {
				 sprintf(entityStrIn, "None");
				 entitySqlNameIn = entityStrIn;
			 }
			 else
			 {
				 DBA_GetObjectEnumByDynSt(inputSt, &objEn);  /* REF2697 - SSO - 000510 */
				 entitySqlNameIn = DBA_GetDictEntitySqlName(objEn);
				 /* PMSTA-13122 - LJE - 120420 */
				 if (entitySqlNameIn == NULL)
				 {
					 entitySqlNameIn = DBA_GetDynStCName(inputSt);
				 }
				 if (entitySqlNameIn == NULL)
				 {
					 sprintf(entityStrIn, "unknown(%d)", inputSt);
					 entitySqlNameIn = entityStrIn;
				 }
			 }

			 DBA_GetObjectEnumByDynSt(outputSt, &objEn);  /* REF2697 - SSO - 000510 */
			 entitySqlNameOut = DBA_GetDictEntitySqlName(objEn);
			 if (entitySqlNameOut == NULL)
			 {
				 sprintf(entityStrOut, "unknown(%d)", outputSt);
				 entitySqlNameOut = entityStrOut;
			 }

             DBA_LogMesgProcedureNotFound(Select, object, role, inputSt, inputData, outputSt, false, "Select", objString, entitySqlNameIn, entitySqlNameOut);  /* PMSTA-24985 - 111016 - PMO */
		 }
		 return(RET_DBA_ERR_PROCNOTFOUND);
	 }

	 /* If no connection number is given */
	 if ((selOptions & DBA_SET_CONN) != DBA_SET_CONN)
	 {
		 /* Get a free connection */
		 if ((dbiConnHelper = new DbiConnectionHelper(procedure->server)) == nullptr)
		 {
			 return(RET_DBA_ERR_CONNOTFOUND);
		 }
	 }
	 else
	 {
		 /* If a connection number is given */
		 if (allocConn != NULL) /*   FPL-PMSTA06305-080508   */
		 {
             if ((dbiConnHelper = new DbiConnectionHelper(DBA_GetDbiConnFromConnectNo(*allocConn), (selOptions & DBA_NO_CLOSE) != DBA_NO_CLOSE)) == nullptr)
			 {
				 return RET_DBA_ERR_CONNOTFOUND;
			 }
             dbiConnHelper->dbaSetOptions(selOptions | DBA_SET_CONN | DBA_NO_CLOSE);            /*  DDV-PMSTA-45454-210610  */
		 }
		 else
		 {
			 return(RET_DBA_ERR_ARGNOMATCH);
		 }
	 }

     retCode = DBA_Select2(object,
                           role,
                           inputSt, inputData,
                           outputSt, outputData,
                           maxRows,
                           resultRows,
                           *dbiConnHelper);

     bool isInError = (retCode == RET_DBA_ERR_DIALOG);
     if (isInError)
     {
         dbiConnHelper->getConnection()->setValidConnection(false);
     }
     delete dbiConnHelper;
	 return retCode;
}

RET_CODE DBA_Select2(OBJECT_ENUM          object,
                     int                  role,
                     DBA_DYNST_ENUM       inputSt, DBA_DYNFLD_STP inputData,
                     DBA_DYNST_ENUM       outputSt, DBA_DYNFLD_STP **outputData,
                     int                  selOptions,
                     int                  maxRows,
                     int                  *resultRows,
                     DbiConnection&       dbiConn,
                     DBA_ERRMSG_INFOS_STP msgStructPtr,
                     DBA_ERRMSG_HEADER_STP dbaErrMsgHeaderStp) /* PMSTA-49780- BSV- 040722 */
{
    RET_CODE        ret;
    DbiConnectionHelper dbiConnHelper(&dbiConn, false);
    dbiConnHelper.dbaSetOptions(selOptions | DBA_SET_CONN | DBA_NO_CLOSE);

    ret =  DBA_Select2(object,
                       role,
                       inputSt,
                       inputData,
                       outputSt,
                       outputData,
                       maxRows,
                       resultRows,
                       dbiConnHelper);

    dbiConn.sendAllMsg();
    /* PMSTA-49780- BSV- 040722 */
    //dbaErrMsgHeaderStp is default argument.Check for NULL before copying objects.
    if (dbaErrMsgHeaderStp != nullptr)
        dbaErrMsgHeaderStp->copyDbaErrMsgHeaderClassObject(*dbiConnHelper.dbaGetMsgStructHeader());

    return(ret);
}

RET_CODE DBA_Select2(OBJECT_ENUM          object,
                     int                  role,
                     DBA_DYNST_ENUM       inputSt,  DBA_DYNFLD_STP inputData,
                     DBA_DYNST_ENUM       outputSt, DBA_DYNFLD_STP **outputData,
                     int                  maxRows,
                     int                  *resultRows,
                     DbiConnectionHelper& dbiConnHelper)
{
#ifdef AAAPROFILER
    ZoneScopedNS("DBA_Select2", 5);
#endif

    DbaCallGuard dbaCallGuard(dbiConnHelper); /* PMSTA-45413 - LJE - 210804 */

	DBA_DYNFLD_STP  bindSt=NULL;
	DBA_DYNFLD_STP  savedInputData = NULL;
    int             rowsNbr = 0;
    DBI_INT         resultType = 0, status = 0;
	RET_CODE        retCode;
	RET_CODE        finalResult;
    int             posIndexLocal= -1,posIndexGlobal= -1;
    OBJECT_ENUM     objectEn = NullEntity;

	/* Initialize the result row number to 0 */
	if (resultRows != UNUSED)
	{
		*resultRows = 0;
	}

	/* Choose a procedure in the object procedures list and store the necessary parameter */
	DBA_PROC_STP procedure =  DBA_GetStoredProcs(Select, object, role, inputSt, inputData, outputSt);

	/* If no procedure was found */
	if (procedure == NULL)
	{
		if ((dbiConnHelper.dbaGetOptions() & DBA_NO_PROC_ERROR) == 0) /* PMSTA-13946 - LJE - 120328 */
		{
		    char	objString[40];
            const char	*sqlName = DBA_GetDictEntitySqlName(object);
		    OBJECT_ENUM objEn;		    /* REF2697 - SSO - 000510 */
		    const char	    *entitySqlNameIn=NULL, *entitySqlNameOut=NULL;  /* REF2697 - SSO - 000510 */
		    char	    entityStrIn[13];	    /* REF2697 - SSO - 000510 */
		    char	    entityStrOut[13];	    /* REF2697 - SSO - 000510 */

		    if (sqlName != NULL)
		    {
			    strcpy(objString, sqlName);
		    }
		    else
		    {
			    sprintf(objString, "unknown(" szFormatObj ")",object);/* REF2697 - SSO - 000510 */
		    }

            if (inputSt == NullDynSt) /* PMSTA-13109 - LJE - 111128 */
            {
                sprintf(entityStrIn,"None");
		        entitySqlNameIn = entityStrIn;
            }
            else
            {
                DBA_GetObjectEnumByDynSt(inputSt, &objEn);  /* REF2697 - SSO - 000510 */
		        entitySqlNameIn = DBA_GetDictEntitySqlName(objEn);
			    /* PMSTA-13122 - LJE - 120420 */
		        if (entitySqlNameIn == NULL)
		        {
				    entitySqlNameIn = DBA_GetDynStCName(inputSt);
			    }
		        if (entitySqlNameIn == NULL)
		        {
		            sprintf(entityStrIn,"unknown(%d)",inputSt);
		            entitySqlNameIn = entityStrIn;
		        }
            }

            DBA_GetObjectEnumByDynSt(outputSt, &objEn);  /* REF2697 - SSO - 000510 */
		    entitySqlNameOut = DBA_GetDictEntitySqlName(objEn);
		    if (entitySqlNameOut == NULL)
		    {
		        sprintf(entityStrOut,"unknown(%d)",outputSt);
		        entitySqlNameOut = entityStrOut;
		    }

            DBA_LogMesgProcedureNotFound(Select, object, role, inputSt, inputData, outputSt, false, "Select", objString, entitySqlNameIn, entitySqlNameOut);  /* PMSTA-24985 - 111016 - PMO */
		}
		return(RET_DBA_ERR_PROCNOTFOUND);
	}
    dbiConnHelper.setCurrProcedure(procedure);  /* PMSTA-45413 - LJE - 210804 */

	/* DVP262 */
	if (procedure->server == InternalProc)
	{
		/* Procedure is optimised and we are in server mode */
		if ( procedure->optiIdx != NullOpti && OPTIMEM_MODE() == TRUE)
		{
			DBA_DYNFLD_STP *resultData=NULL;
			DBA_DYNFLD_STP *tempData=NULL;
			DBA_DYNFLD_STP selectResTab=NULL;
			RET_CODE       ret;
			int            j = 0, eltNbr=0;

			selectResTab = ALLOC_DYNST(Select_Res_Tab);

			ret = DBA_ReadOpti(procedure,
			                   Opti_LocalGlobal,
			                   inputData,
			                   selectResTab,
			                   NULL,
                               &posIndexLocal, &posIndexGlobal);

			switch (ret)
			{
			case RET_SUCCEED:

				eltNbr  = GET_EXTENSION_NBR(selectResTab, Select_Res_Tab_DataTab);

				if (eltNbr != 0)
				{
					resultData = GET_EXTENSION_PTR(selectResTab, Select_Res_Tab_DataTab);

					/* Allocate an array */
					tempData = (DBA_DYNFLD_STP*) CALLOC(eltNbr, sizeof(DBA_DYNFLD_STP));    /* REF7264 - PMO */

					/* Store the structure in the array */
					for (j=0 ; j<eltNbr ; j++)
					{
						tempData[j] = ALLOC_DYNST(*(procedure->outputDynStPtr));

						COPY_DYNST(tempData[j], resultData[j], *(procedure->outputDynStPtr));
					}

					*outputData = tempData;
				}

				if (resultRows != UNUSED)
					*resultRows = eltNbr;

				/* REF1036 - RAK - 981104                  */
				/* EXTENSION is used like a "bidouille" -> */
				/* FREE_DYNST don't have to free extPtr    */
				SET_NULL_EXTENSION(selectResTab, Select_Res_Tab_DataTab);

				FREE_DYNST(selectResTab, Select_Res_Tab);

				return(RET_SUCCEED);

			case RET_DBA_INFO_NODATA:

				if (resultRows != UNUSED)
					*resultRows = 0;

				FREE_DYNST(selectResTab, Select_Res_Tab);

				return(RET_SUCCEED);

			default:
				break;
			}

			FREE_DYNST(selectResTab, Select_Res_Tab);
		}

		/* REF10488 - DDV - 041018 - If the internal function is optimised, backup input arg.
		   If the internal function modified the input args, there is no effect on optimisation */
		if(procedure->optiIdx != NullOpti && OPTIMEM_MODE() == TRUE)
		{
			savedInputData = ALLOC_DYNST(inputSt);
			COPY_DYNST_FLAG_NO_IMPACT(savedInputData, inputData, inputSt);
		}

        if (dbiConnHelper.isValidAndInit() == false)
        {
            return RET_DBA_ERR_CANNOTCONNECT;
        }

        retCode = procedure->fctDefSt.selFct(object, inputData, outputData, &rowsNbr, dbiConnHelper);

		switch (retCode)
		{
		case RET_SUCCEED:
			if(procedure->optiIdx != NullOpti && OPTIMEM_MODE() == TRUE)
			{
				if (rowsNbr > 0)
				{
					DBA_DYNFLD_STP selectResTab=ALLOC_DYNST(Select_Res_Tab);

					SET_EXTENSION(selectResTab,
					              Select_Res_Tab_DataTab,
					              *outputData,
					              *(procedure->outputDynStPtr),
					              rowsNbr);

					DBA_WriteOpti(procedure,
					              Opti_GlobalLocal,
					              savedInputData,
					              selectResTab,
					              FALSE,
                                  posIndexLocal, posIndexGlobal);

					/* REF1036 - RAK - 981104                  */
					/* EXTENSION is used like a "bidouille" -> */
					/* FREE_DYNST don't have to free extPtr    */
					SET_NULL_EXTENSION(selectResTab, Select_Res_Tab_DataTab);

					FREE_DYNST(selectResTab, Select_Res_Tab);
				}
				else
					DBA_WriteOpti(procedure,
					              Opti_GlobalLocal,
					              savedInputData,
					              NULL,
					              FALSE,
                                  posIndexLocal, posIndexGlobal);
			}

			if (resultRows != UNUSED)
				*resultRows = rowsNbr;

			if(savedInputData != NULL)
			{
				FREE_DYNST(savedInputData, inputSt);
			}

			return(RET_SUCCEED);

        case RET_DBA_INFO_NO_MORE_DATA:
            retCode = RET_SUCCEED;

        default:
            if (resultRows != UNUSED)
            {
                *resultRows = 0;
            }

			if(savedInputData != NULL)
			{
				FREE_DYNST(savedInputData, inputSt);
			}
			return(retCode);
		}
	}
	/* DVP262 */

    /* PMSTA-46681 - LJE - 231106 */
    if (dbiConnHelper.isDbaAccess(Select))
    {
        return DBA_SelXdObject(object, inputData, outputData, resultRows, dbiConnHelper);
    }

    /* PMSTA-37366 - LJE - 200625 */
    if (dbiConnHelper.getDescription().getType() != procedure->server)
    {
        DbiConnectionHelper localDbiConnHelper(procedure->server);
        return DBA_Select2(object, role, inputSt, inputData, outputSt, outputData, maxRows, resultRows, localDbiConnHelper);
    }

	/* DVP255 */
	if (procedure->optiIdx != NullOpti && OPTIMEM_MODE() == TRUE)
	{
		DBA_DYNFLD_STP *resultData=NULL;
		DBA_DYNFLD_STP *tempData=NULL;
		DBA_DYNFLD_STP selectResTab=NULL;
		RET_CODE       ret;
		int            j, eltNbr=0;

		selectResTab = ALLOC_DYNST(Select_Res_Tab);
		ret = DBA_ReadOpti(procedure,
		                   Opti_LocalGlobal,
		                   inputData,
		                   selectResTab,
		                   NULL,
                           &posIndexLocal, &posIndexGlobal);

		switch (ret)
		{
		case RET_SUCCEED:

			eltNbr  = GET_EXTENSION_NBR(selectResTab, Select_Res_Tab_DataTab);

            if (true == EV_LogFSPSecuCheck) /* PMSTA-32214 - CHU - 180731 */
            {
                MSG_LogSrvMesg(UNUSED, UNUSED, "DBA_ReadOpti(level -1) Opti_Sel_E_DictFct_ByUid has read %1 rows from cache", IntType, eltNbr); /* PMSTA-32214 - CHU - 180726  */
            }

			if (eltNbr != 0)
			{
				resultData = GET_EXTENSION_PTR(selectResTab, Select_Res_Tab_DataTab);

				/* Allocate an array */
				tempData = (DBA_DYNFLD_STP*) CALLOC(eltNbr, sizeof(DBA_DYNFLD_STP)); /* REF7264 - PMO */

				/* Store the structure in the array */
				for (j=0 ; j<eltNbr ; j++)
				{
					tempData[j] = ALLOC_DYNST(*(procedure->outputDynStPtr));

					COPY_DYNST(tempData[j], resultData[j], *(procedure->outputDynStPtr));
				}

				*outputData = tempData;
			}

			if (resultRows != UNUSED)
				*resultRows = eltNbr;

			/* REF1036 - RAK - 981104                  */
			/* EXTENSION is used like a "bidouille" -> */
			/* FREE_DYNST don't have to free extPtr    */
			SET_NULL_EXTENSION(selectResTab, Select_Res_Tab_DataTab);

			FREE_DYNST(selectResTab, Select_Res_Tab);
			return(RET_SUCCEED);

		case RET_DBA_INFO_NODATA:
            if (true == EV_LogFSPSecuCheck) /* PMSTA-32214 - CHU - 180731 */
            {
                MSG_LogSrvMesg(UNUSED, UNUSED, "DBA_ReadOpti(level -1) returned RET_DBA_INFO_NODATA for Opti_Sel_E_DictFct_ByUid"); /* PMSTA-32214 - CHU - 180726  */
            }
			if (resultRows != UNUSED)
				*resultRows = 0;

			FREE_DYNST(selectResTab, Select_Res_Tab);
			return(RET_SUCCEED);

		default:
			break;
		}

		FREE_DYNST(selectResTab, Select_Res_Tab);
	}
	/* DVP255 */

    if (dbiConnHelper.isValidAndInit() == false)
    {
        return(RET_DBA_ERR_CONNOTFOUND);
    }

    if (USE_NEW_ACCESS_API(dbiConnHelper.getConnection()))
    {
        RequestHelper requestHelper(dbiConnHelper);

        if (requestHelper.startProcedureCall(procedure, inputData) == false)
        {
            return(requestHelper.getLastResultRetCode());
        }

        requestHelper.setDynStOutputData(outputSt);

        /* Retrieve all rows in the result set */
        retCode = requestHelper.readAllRecord(&rowsNbr, outputData);
    }
    else
    {
        DbiConnection& dbiConn = *dbiConnHelper.getConnection();

        dbiConn.setReadOnly(procedure); /* PMSTA-29027 - LJE - 190111 */

        /* PMSTA-46110 - FME - 20211122  Always set the max row, even unlimitted*/
        DBA_SetConnMaxRows(dbiConn, maxRows);

        /* Memorize the necessary parameters for the request in the command structure */
        if (DBI_SetProcParameters(dbiConn, inputSt, inputData, procedure) != RET_SUCCEED)
        {
            MSG_LogMesg(RET_DBA_ERR_SETPARAM, 0, FILEINFO);
            dbiConn.releaseCommand();
            return(RET_DBA_ERR_SETPARAM);
        }

        if (dbiConn.sendRequest(&resultType) != RET_SUCCEED)
        {
            dbiConn.releaseCommand();

            if ((dbiConnHelper.dbaGetOptions() & DBA_SET_CONN) == DBA_SET_CONN)
            {
                MSG_SendMesg(RET_DBA_ERR_DIALOG, 0, FILEINFO);
                return(RET_DBA_ERR_DIALOG);
            }

            AAALocalConnectionProvider::get().reconnect(dbiConn);

            if (!dbiConn.isConnected() || !dbiConn.isValid())
            {
                if (savedInputData != NULL)
                {
                    FREE_DYNST(savedInputData, inputSt);
                }
                if (dbiConnHelper.emptyMsg() == false)
                {
                    dbiConnHelper.sendAllMsg();
                    return RET_DBA_ERR_DBPROBLEM;
                }
                else
                {
                    MSG_RETURN(RET_DBA_ERR_DBPROBLEM);
                }
            }

            if (DBI_SetProcParameters(dbiConn, inputSt, inputData, procedure) != RET_SUCCEED)
            {
                dbiConn.releaseCommand();
                MSG_LogMesg(RET_DBA_ERR_SETPARAM, 0, FILEINFO);
                return(RET_DBA_ERR_SETPARAM);
            }

            if (dbiConn.sendRequest(&resultType) != RET_SUCCEED)
            {
                dbiConn.releaseCommand();
                MSG_SendMesg(RET_DBA_ERR_DIALOG, 0, FILEINFO);
                if (dbiConnHelper.emptyMsg() == false)
                {
                    dbiConnHelper.sendAllMsg();
                    return RET_DBA_ERR_DBPROBLEM;
                }
                else
                {
                    MSG_RETURN(RET_DBA_ERR_DBPROBLEM);
                }
            }
        }

        /* Call to function which will filter received messages during
           select operation */
        dbiConn.filterMsgInfos(&finalResult);

        if (finalResult != RET_SUCCEED)
        {
            /* REF3955 - SSO - 000107 */
            if (finalResult == RET_SRV_LIB_ERR_INV_PARAM_VALUE)
            {
                dbiConn.setValidConnection(false);
            }
            dbiConn.releaseCommand();
            return(finalResult);
        }

        switch (resultType)
        {
            case DBI_STATUS_RESULT:

                dbiConn.processAllResults(&status); /* PMSTA-23385 - LJE - 160630 */
                dbiConn.filterMsgInfos(&finalResult); /* PMSTA14726 - DDV - 120809 - Get all error raised */
                DBA_SendMesgForProcResType(procedure->procName, resultType);
                if (status < 0)
                    return(RET_DBA_ERR_DBPROBLEM);
                else
                    return(RET_SUCCEED);

            case DBI_ROW_RESULT:

                break;

            default:

                dbiConn.releaseCommand();
                return(FALSE);
        }

        /* Allocate memory for the bind structure */
        if ((bindSt = ALLOC_DYNST(outputSt)) == NULL)
        {
            dbiConn.releaseCommand();
            return(RET_MEM_ERR_ALLOC);
        }

        /* PMSTA-17490 - DDV - 140124 - Set and keep default_c on fields not returned by database */
        objectEn = GET_DYNST_ENTITY(outputSt);

        if (objectEn != NullEntity)
            DBA_SetDfltEntityFld(objectEn, outputSt, bindSt);

        /* Bind result columns with an application bind structure */
        if (dbiConn.bindRecvDynSt(outputSt, bindSt) != RET_SUCCEED)
        {
            FREE_DYNST(bindSt, outputSt);

            dbiConn.releaseCommand();
            return(RET_DBA_ERR_SYBBIND);
        }

        /* Retrieve all rows in the result set */
        if ((retCode = dbiConn.readObjectData(outputSt, bindSt, &rowsNbr, outputData)) != RET_SUCCEED)
        {
            FREE_DYNST(bindSt, outputSt);
            dbiConn.releaseCommand();
            MSG_SendMesg(retCode, 0, FILEINFO);
            return(RET_DBA_ERR_DBPROBLEM);
        }

        /* Free the memory allocation reserved for bind structure */
        FREE_DYNST(bindSt, outputSt);
        dbiConn.processAllResults(&status); /* PMSTA-23385 - LJE - 160630 */
        dbiConn.filterMsgInfos(&finalResult); /* PMSTA14726 - DDV - 120809 - Get all error raised */
    }

    /* Memorize the number of retrieved rows from the result set if the arg. is specified */
    if (resultRows != UNUSED)
        *resultRows = rowsNbr;

    /* If all rows are retrieved and a connection parameter (allocConn) is specified, this
       parameter is set to DBA_CONN_NOT_FOUND to avoid the bad intentioned programmer to
       retrieve the conn. number reserved for the request
    */

    /* Free the pointer array allocated in SYB_ReadObjectData() if no row was returned by the request */
    if (rowsNbr == 0)
    {
        FREE(*outputData);
    }

    /* DVP255 */
	if (procedure->optiIdx != NullOpti && OPTIMEM_MODE() == TRUE)
	{
		DBA_DYNFLD_STP selectResTab=NULL;

		if (*resultRows > 0)
		{
			selectResTab=ALLOC_DYNST(Select_Res_Tab);

			SET_EXTENSION(selectResTab,
			              Select_Res_Tab_DataTab,
			              *outputData,
			              *(procedure->outputDynStPtr),
			              *resultRows);

			DBA_WriteOpti(procedure,
			              Opti_GlobalLocal,
			              inputData,
			              selectResTab,
			              FALSE,
                          posIndexLocal, posIndexGlobal);

			/* REF1036 - RAK - 981104                  */
			/* EXTENSION is used like a "bidouille" -> */
			/* FREE_DYNST don't have to free extPtr    */
			SET_NULL_EXTENSION(selectResTab, Select_Res_Tab_DataTab);

			FREE_DYNST(selectResTab, Select_Res_Tab);
		}
		else
			DBA_WriteOpti(procedure,
			              Opti_GlobalLocal,
			              inputData,
			              NULL,
			              FALSE,
                          posIndexLocal, posIndexGlobal);

        if (true == EV_LogFSPSecuCheck) /* PMSTA-32214 - CHU - 180731 */
        {
            MSG_LogSrvMesg(UNUSED, UNUSED, "DBA_WriteOpti(level -1) Opti_Sel_E_DictFct_ByUid written %1 rows to cache", IntType, rowsNbr); /* PMSTA-32214 - CHU - 180726  */
        }
	}
	/* DVP255 */

	if(EV_ExtractFile && EV_SetProcParametersFlg)
	{
		DATE_ResetTimer(EV_ExtractFileTimerPtr, TIMER_MASK_GEN);
		DATE_StartTimer(EV_ExtractFileTimerPtr, TIMER_MASK_GEN);
		EV_SetProcParametersFlg = FALSE;
	}

	return(RET_SUCCEED);
}

/************************************************************************
*   Function             : DBA_MultiSelect2()
*
*   Description          : Send a MULTI SELECT request to the server and retrieve
*                          returned data sets
*
*   Arguments            : object     : the request corresponding object
*                          role       : the role of the request
*                          inputSt    : the input dynamic struct. format
*                          inputData  : the pointer on the input dynamic struct.
*                          outputSt   : the output dynamic struct. format list
*                          outputData : the pointer on the output dyn. struct.
*                                       array pointer
*                          SelOptions : indicate many info about the request (ALLOC,
*                                       FETCH, ...).
*                          maxRows    : pointer which contain the desirated (if any)
*                                       or result rows number.
*                          resultRows : the returned row number, if specified, for each set
*                          allocConn  : the connection number allocated
*                          msgStructPtr : message structure pointer
*
*   Return               : RET_SUCCEED              : if no problem was detected
*                          RET_DBA_ERR_ARGNOMATCH   : if input arg. problem
*                          RET_DBA_ERR_PROCNOTFOUND : if no procedure founded
*                          RET_DBA_INFO_NODATA      : if no data founded
*                          RET_DBA_ERR_SETPARAM     : if problem while setting proc. parameters
*                          RET_DBA_ERR_CONNOTFOUND  : if no connection founded
*                          RET_DBA_ERR_DBPROBLEM    : if DB/connection problem
*                          RET_DBA_ERR_SYBBIND      : if poblem while binding received fields
*                          RET_MEM_ERR_ALLOC        : if allocation failed
*                          RET_DBA_ERR_READ_DATA    : if problem while reading received data
*                          RET_GEN_ERR_INVARG       : if problem while setting function params.
*                          a RET_CODE               : if a message has been received
*
*   Creation Date        : 06.05.96 - PEC
*   Last Modification    : 22.01.97 - PEC - Ref.: DVP331.
*                          19.02.97 - PEC - Ref.: DVP346.
*                          04.08.97 - GRD - Ref.: BUG451.
*                          18.05.99 - GRD - Ref.: REF3685.
*                          REF7264 - 0201225 - PMO : Compilation errors and warnings with C++ compiler
*                          REF8500 - 040510 - PMO : Add a draft_order_id in extended operation to distinguish the id from extended orders and the one from extended operation
*                          PMSTA-24985 - 111016 - PMO : Connection crash
*
*************************************************************************/
RET_CODE DBA_MultiSelect2(OBJECT_ENUM            object,
    int                  role,
    DBA_DYNST_ENUM       inputSt,
    DBA_DYNFLD_STP       inputData,
    const DBA_DYNST_ENUM **outputStLstPtr,
    DBA_DYNFLD_STP       **outputDataLst,
    int                  selOptions,
    int                  maxRows,
    int                  *resultRows,
    int                  *allocConn,
    DBA_ERRMSG_INFOS_STP msgStructPtr)
{
    RET_CODE        retCode;
    DbiConnection * dbiConn = nullptr;

    /* Choose a procedure in the object procedures list and store the necessary parameter */
    DBA_PROC_STP procedure = DBA_GetStoredProcs(MultiSelect, object, role, inputSt, inputData, NullDynSt);

    /* If no procedure was found */
    if (procedure == NULL)
    {
        if ((selOptions & DBA_NO_PROC_ERROR) == 0) /* PMSTA-13946 - LJE - 120328 */
        {
            char    objString[40];
            const char *sqlName = DBA_GetDictEntitySqlName(object);
            OBJECT_ENUM objEn;                  /* REF2697 - SSO - 000510 */
            const char  *entitySqlNameIn = NULL;  /* REF2697 - SSO - 000510 */
            char        entityStrIn[13];        /* REF2697 - SSO - 000510 */

            if (sqlName != NULL)
            {
                strcpy(objString, sqlName);
            }
            else
            {
                sprintf(objString, "unknown(" szFormatObj ")", object);/* REF2697 - SSO - 000510 */
            }

            DBA_GetObjectEnumByDynSt(inputSt, &objEn);  /* REF2697 - SSO - 000510 */
            entitySqlNameIn = DBA_GetDictEntitySqlName(objEn);
            /* PMSTA-13122 - LJE - 120420 */
            if (entitySqlNameIn == NULL)
            {
                entitySqlNameIn = DBA_GetDynStCName(inputSt);
            }
            if (entitySqlNameIn == NULL)
            {
                sprintf(entityStrIn, "unknown(%d)", inputSt);
                entitySqlNameIn = entityStrIn;
            }

            DBA_LogMesgProcedureNotFound(MultiSelect, object, role, inputSt, inputData, NullDynSt, false, "MultiSelect", objString, entitySqlNameIn, "none");   /* PMSTA-24985 - 111016 - PMO */
        }
        return(RET_DBA_ERR_PROCNOTFOUND);
    }

    /* If no connection number is given */
    if ((selOptions & DBA_SET_CONN) != DBA_SET_CONN)
    {
        /* Get a free connection in the connection list */
        if ((dbiConn = DBA_GetDbiConnection(procedure->server)) == nullptr)
        {
#ifdef AAADEBUGMSG
            MSG_LogMesg(RET_DBA_ERR_CONNOTFOUND, 0, FILEINFO);
#endif
            return(RET_DBA_ERR_CONNOTFOUND);
        }
    }
    else
    {
        /* If a connection number is given */
        if (allocConn != NULL) /* FPL-PMSTA06305-080508 */
        {
            dbiConn = DBA_GetDbiConnFromConnectNo(*allocConn);
            if (dbiConn == nullptr) {
                return RET_DBA_ERR_CONNOTFOUND;
            }
        }
        else
        {
#ifdef AAADEBUGMSG
            MSG_LogMesg(RET_DBA_ERR_ARGNOMATCH, 0, FILEINFO);
#endif
            return(RET_DBA_ERR_ARGNOMATCH); /* Input Argument error */
        }
    }
    retCode =  DBA_MultiSelect2(object,
                                role,
                                inputSt,
                                inputData,
                                outputStLstPtr,
                                outputDataLst,
                                selOptions,
                                maxRows,
                                resultRows,
                                *dbiConn,
                                msgStructPtr);

    bool isInError = (retCode == RET_DBA_ERR_DIALOG);
    if (isInError)
    {
        dbiConn->setValidConnection(false);
    }
    if ((selOptions & DBA_NO_CLOSE) != DBA_NO_CLOSE)
    {
        DBA_EndConnection(&dbiConn, isInError);
    }
    return retCode;
}
RET_CODE DBA_MultiSelect2(OBJECT_ENUM            object,
                          int                  role,
                          DBA_DYNST_ENUM       inputSt,
                          DBA_DYNFLD_STP       inputData,
                          const DBA_DYNST_ENUM **outputStLstPtr,
                          DBA_DYNFLD_STP       **outputDataLst,
                          int                  selOptions,
                          int                  maxRows,
                          int                  *resultRows,
                          DbiConnection&       dbiConn,
                          DBA_ERRMSG_INFOS_STP msgStructPtr)
{
    DbiConnectionHelper dbiConnHelper(&dbiConn, false);

    return  DBA_MultiSelect2(object,
                             role,
                             inputSt,
                             inputData,
                             outputStLstPtr,
                             outputDataLst,
                             selOptions,
                             maxRows,
                             resultRows,
                             dbiConnHelper,
                             msgStructPtr);

}
RET_CODE DBA_MultiSelect2(OBJECT_ENUM            object,
                            int                  role,
                            DBA_DYNST_ENUM       inputSt,
                            DBA_DYNFLD_STP       inputData,
                            const DBA_DYNST_ENUM **outputStLstPtr,
                            DBA_DYNFLD_STP       **outputDataLst,
                            int                  selOptions,
                            int                  maxRows,
                            int                  *resultRows,
                            DbiConnectionHelper& dbiConnHelper,
                            DBA_ERRMSG_INFOS_STP msgStructPtr)
{
#ifdef AAAPROFILER
    ZoneScopedNS("DBA_MultiSelect2", 5);
#endif

    DbaCallGuard dbaCallGuard(dbiConnHelper); /* PMSTA-45413 - LJE - 210804 */

    DBA_DYNFLD_STP  bindData=NULL;
    int             endFlg, idx;
    DBI_INT         resultType, status;
    RET_CODE        retCode;
    RET_CODE        finalResult=RET_SUCCEED;
    OBJECT_ENUM     objectEn;
    DBA_DYNST_ENUM  dynStEn;

#ifdef AAATIMER
	char *commentStr=(char *) CALLOC(2028, sizeof(char));
#endif

    /* Initialize the result row number to 0 */
    if (resultRows != UNUSED)
    {
        *resultRows = 0;
    }

    /* Choose a procedure in the object procedures list and store the necessary parameter */
    DBA_PROC_STP procedure = DBA_GetStoredProcs(MultiSelect, object, role, inputSt, inputData, NullDynSt);

    /* If no procedure was found */
    if (procedure == NULL)
    {
		if ((selOptions & DBA_NO_PROC_ERROR) == 0) /* PMSTA-13946 - LJE - 120328 */
		{
            char    objString[40];
            const char *sqlName = DBA_GetDictEntitySqlName(object);
            OBJECT_ENUM objEn;                  /* REF2697 - SSO - 000510 */
            const char  *entitySqlNameIn=NULL;  /* REF2697 - SSO - 000510 */
            char        entityStrIn[13];        /* REF2697 - SSO - 000510 */

            if (sqlName != NULL)
            {
                strcpy(objString, sqlName);
            }
            else
            {
                sprintf(objString, "unknown(" szFormatObj ")",object);/* REF2697 - SSO - 000510 */
            }

            DBA_GetObjectEnumByDynSt(inputSt, &objEn);  /* REF2697 - SSO - 000510 */
            entitySqlNameIn = DBA_GetDictEntitySqlName(objEn);
		    /* PMSTA-13122 - LJE - 120420 */
	        if (entitySqlNameIn == NULL)
	        {
			    entitySqlNameIn = DBA_GetDynStCName(inputSt);
		    }
            if (entitySqlNameIn == NULL)
            {
                sprintf(entityStrIn,"unknown(%d)",inputSt);
                entitySqlNameIn = entityStrIn;
            }

            DBA_LogMesgProcedureNotFound(MultiSelect, object, role, inputSt, inputData, NullDynSt, false, "MultiSelect", objString, entitySqlNameIn, "none");  /* PMSTA-24985 - 111016 - PMO */
		}
        return(RET_DBA_ERR_PROCNOTFOUND);
    }
    dbiConnHelper.setCurrProcedure(procedure);  /* PMSTA-45413 - LJE - 210804 */

    /* PMSTA-37366 - LJE - 200625 */
    if (dbiConnHelper.getDescription().getType() != procedure->server)
    {
        DbiConnectionHelper localDbiConnHelper(procedure->server);
        return DBA_MultiSelect2(object,
                                role,
                                inputSt,
                                inputData,
                                outputStLstPtr,
                                outputDataLst,
                                selOptions,
                                maxRows,
                                resultRows,
                                dbiConnHelper,
                                msgStructPtr);
    }

    if (dbiConnHelper.isValidAndInit() == false)
    {
        return(RET_DBA_ERR_CONNOTFOUND);
    }

    if (USE_NEW_ACCESS_API(dbiConnHelper.getConnection()))
    {
        return dbiConnHelper.dbaMultiSelect(object, role, inputData, outputDataLst, resultRows);
    }

    DbiConnection * dbiConn = dbiConnHelper.getConnection();

    dbiConn->setReadOnly(procedure); /* PMSTA-29027 - LJE - 190111 */

    /* PMSTA-46110 - FME - 20211122  Always set the max row, even unlimitted */
    DBA_SetConnMaxRows(*dbiConn, maxRows);

	dbiConn->setCurrentAction(MultiSelect);

    /* Memorize the necessary parameters for the request in the command structure */
    if (DBI_SetProcParameters(*dbiConn, inputSt, inputData, procedure) != RET_SUCCEED)
    {
		dbiConn->releaseCommand();
        return(RET_DBA_ERR_SETPARAM);
    }

    /* Send the request to the server */
	if (dbiConn->sendRequest(&resultType) != RET_SUCCEED)
    {
		dbiConn->releaseCommand();

        /* PMSTA-18593 - LJE - 150617 */
        if (msgStructPtr != NULL && msgStructPtr->emptyString() == false && SYS_IsBatchMode())
        {
            MSG_LogMesgWithMsgStruct(RET_DBA_ERR_INVDATA, msgStructPtr, FILEINFO);
            return RET_DBA_ERR_DBPROBLEM;
        }
        else
        {
            MSG_RETURN(RET_DBA_ERR_DBPROBLEM);
        }
    }


    if (resultType != DBI_ROW_RESULT)
    {
        /* Call to function which will filter received messages during Multi Select operation */
        dbiConn->filterMsgInfos(&finalResult);

        if (finalResult != RET_SUCCEED)
        {
			dbiConn->releaseCommand();
            return(finalResult);
        }

        DBA_SendMesgForProcResType(procedure->procName, resultType);
		dbiConn->releaseCommand();
        return(RET_DBA_ERR_DBPROBLEM);
    }

    idx = 0;
    endFlg = FALSE;
    do
    {
#ifdef AAATIMER
		commentStr[0]=END_OF_STRING;
		sprintf(commentStr, "DBA_MultiSelect - %s[%s]", procedure->procName, DYN_V2N(*(outputStLstPtr[idx])));

        DATE_RESET_TIMER(10, TIMER_MASK_XDI);
        DATE_START_TIMER(10, TIMER_MASK_XDI);
#endif
		/* PMSTA-17490 - DDV - 140124 - Set and keep default_c on fields not returned by database */
        dynStEn = *(outputStLstPtr[idx]);

        if (dynStEn > InvalidDynSt)
            objectEn = GET_DYNST_ENTITY(dynStEn);
        else
            objectEn = NullEntity;

        if ((bindData = ALLOC_DYNST(dynStEn)) == NULL) /* REF7264 - PMO */
        {
			dbiConn->releaseCommand();
            return(RET_MEM_ERR_ALLOC);
        }

		/* PMSTA-17490 - DDV - 140124 - Set and keep default_c on fields not returned by database */
        if (objectEn != NullEntity)
            DBA_SetDfltEntityFld(objectEn, dynStEn, bindData);

        /* Bind a dynamic struct. whith a result set */
        if (dbiConn->bindRecvDynSt(dynStEn, bindData) != RET_SUCCEED) /* REF7264 - PMO */
        {
            FREE_DYNST(bindData, *(outputStLstPtr[idx]));
			dbiConn->releaseCommand();
            return(RET_DBA_ERR_SYBBIND);
        }

        /* Retrieve all rows in the result set */
        retCode = dbiConn->readObjectData(dynStEn,
                                          bindData,
                                          &(resultRows[idx]),
                                          &(outputDataLst[idx]));

        /* If memory problem in SYB_ReadObjectData() */
        if (retCode != RET_SUCCEED)
        {
            FREE_DYNST(bindData, dynStEn);
			dbiConn->releaseCommand();
            MSG_SendMesg(RET_DBA_ERR_READ_DATA, 0, FILEINFO); /* DVP346 */
            return(RET_DBA_ERR_DBPROBLEM);
        }

        /**** BEGIN DVP331 ****/
        if (resultRows[idx] == 0)
        {
            FREE(outputDataLst[idx]);
        }
        /**** END   DVP331 ****/

        FREE_DYNST(bindData, dynStEn);

        /* Free arrays allocated for Null fields and fields length */
        DBA_FreeNullFlagsAndLength(*dbiConn);

        endFlg = dbiConn->getNextResultSet() == RET_SUCCEED ? FALSE : TRUE;

#ifdef AAATIMER
		DATE_STOP_TIMER(10, TIMER_MASK_XDI);
		sprintf(commentStr+strlen(commentStr)," - %d rows ", resultRows[idx]);
		DATE_DISPLAY_TIMER(10, TIMER_MASK_XDI, commentStr);
#endif
        idx++;
    }
    while (endFlg == FALSE);

    dbiConn->processAllResults(&status); /* PMSTA-23385 - LJE - 160630 */

    /* Call to function which will filter received messages during select operation */
    dbiConn->filterMsgInfos(&finalResult);

    if (finalResult != RET_SUCCEED)
    {
		return(finalResult);
    }

    if(EV_ExtractFile && EV_SetProcParametersFlg)
    {
        DATE_ResetTimer(EV_ExtractFileTimerPtr, TIMER_MASK_GEN);
        DATE_StartTimer(EV_ExtractFileTimerPtr, TIMER_MASK_GEN);
        EV_SetProcParametersFlg = FALSE;
    }

    return(RET_SUCCEED);
}

/************************************************************************
*   Function             : DBA_SetFieldTimeStamp()
*
*   Description          : Fill the timestamp field regarding the type of structure
*
*   Arguments            : inputSt      : the input dynamic struct. format
*                          inputData    : the pointer on the input dynamic struct.
*                          timeStamp    : Value of the timestamp
*
*   Return               : none
*
*   Last Modification    : REF11780 - 100406 - PMO : Implementation of the Sybase timestamp field
*
*************************************************************************/
void DBA_SetFieldTimeStamp(const DBA_DYNST_ENUM  inputSt,
                           DBA_DYNFLD_STP        inputData,
                           const TIMESTAMP_T     timeStamp)
{
    if(inputSt == ExtOp)
    {
        SET_TIMESTAMP(inputData, ExtOp_TimeStampNew, timeStamp);
    }

    if(inputSt == Sql_Result)
    {
        SET_TIMESTAMP(inputData, Sql_Result_TimeStamp, timeStamp);
    }
}


/************************************************************************
*   Function             : DBA_SetFieldId()
*
*   Description          : Fill the id field regarding the type of structure
*
*   Arguments            : inputSt      : the input dynamic struct. format
*                          inputData    : the pointer on the input dynamic struct.
*                          id           : Value of the id
*
*   Return               : none
*
*   Last Modification    : REF11780 - 100406 - PMO : Implementation of the Sybase timestamp field
*
*************************************************************************/
STATIC void DBA_SetFieldId(const DBA_DYNST_ENUM  inputSt,
                           DBA_DYNFLD_STP        inputData,
                           const ID_T            id)
{
    if(inputSt == Sql_Result)
    {
        SET_ID(inputData, Sql_Result_Id, id);
    }
}


/************************************************************************
*   Function             : DBA_ReadSqlBlockResult()
*
*   Description          : Read the result's block from the sybase procedure.
*                          This block contain the id and the timestamp
*                          The timestamp field is filled regarding the type of structure
*
*   Arguments            : connectNo    : Connection number
*                          inputSt      : the input dynamic struct. format
*                          inputData    : the pointer on the input dynamic struct.
*
*   Return               : none
*
*   Last Modification    : REF11780 - 100406 - PMO : Implementation of the Sybase timestamp field
*                          PMSTA-22575 - 020316 - PMO : Error �Unable to insert nor update record - no message available� is thrown when importing bus_entity_third_compo
*
*************************************************************************/
int DBA_ReadSqlBlockResult(DbiConnection&        dbiConn,
                           const DBA_DYNST_ENUM  inputSt,
                           DBA_DYNFLD_STP        inputData)
{
    DBA_DYNFLD_STP  resultBindSt;
    int             fatalError  = FALSE;

	/* Allocate memory for the bind structure */
	if ((resultBindSt = ALLOC_DYNST(Sql_Result)) != NULL)
    { /* Ok */
		/* Bind result columns with output data dynamic struct.   */
        if (dbiConn.bindRecvDynSt(Sql_Result, resultBindSt) == RET_SUCCEED)
		{
		    /* Retrieve the row in the result set */
            if (RET_SUCCEED == dbiConn.fetch())
            {
		        /* Update the NULL flag for each field of the result struct */
				DBI_CopyNullFlagsAndLengthDynSt(dbiConn, resultBindSt, Sql_Result);

                /* Set all fields */
                DBA_SetFieldTimeStamp(inputSt, inputData, GET_TIMESTAMP(resultBindSt, Sql_Result_TimeStamp));
                DBA_SetFieldId(inputSt,        inputData, GET_ID(resultBindSt,        Sql_Result_Id));

                while (dbiConn.fetch() == RET_SUCCEED);
            }
            else
            { /* Error */
                MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Unable to fetch fields for the ID, timestamps SQL block");               /* PMSTA-22575 - 020316 - PMO */
                fatalError = TRUE;
            }
        }
        else
        { /* Error */
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Unable to bind fields for the ID, timestamps SQL block");                    /* PMSTA-22575 - 020316 - PMO */
            fatalError = TRUE;
        }

        FREE_DYNST(resultBindSt, Sql_Result);
    }
    else
    { /* Error */
        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Unable to allocate memory for the ID, timestamps SQL block");                    /* PMSTA-22575 - 020316 - PMO */
        fatalError = TRUE;
    }

    return fatalError;
}

/************************************************************************
*   Function             : DBA_CallHttp()
*
*   Description          : 
*
*   Arguments            : 
*
*   Return               : 
*
*   Last Modification    : PMSTA-34344 - LJE - 201222
*
*************************************************************************/
STATIC RET_CODE DBA_CallHttp(DbiConnectionHelper &dbiConnHelper, 
                             DBA_ACTION_ENUM      actionEn, 
                             OBJECT_ENUM          objectEn,
                             INT_T                role, 
                             DBA_DYNST_ENUM       inputSt,
                             DBA_DYNFLD_STP       inputDataStp)
{
    MemoryPool mp;
    DBA_DYNFLD_STP callRequestStp = mp.allocDynst(FILEINFO, CallRequest);
    SET_ENUM(callRequestStp, CallRequest_ActionEn, actionEn);
    SET_SYSNAME(callRequestStp, CallRequest_EntitySqlName, DBA_GetDictEntitySqlName(objectEn));
    SET_INT(callRequestStp, CallRequest_ObjectEn, objectEn);
    SET_INT(callRequestStp, CallRequest_Role, role);

    SET_EXTENSION_ONE(callRequestStp, CallRequest_InputData, inputDataStp);

    SCPT_AUTOCREATE_HEADER_STP autocreateHeader = SCPT_GetAutocreateHeader();

    if (autocreateHeader != nullptr && autocreateHeader->asgnRecCount > 0)
    {
        DBA_DYNFLD_STP * autoCreateExtPtr = static_cast<DBA_DYNFLD_STP*>(CALLOC(autocreateHeader->asgnRecCount, sizeof(DBA_DYNFLD_STP)));

        SCPT_AUTOCREATE_STP currEltStp = autocreateHeader->asgnRecHead;

        int activeAutoCreateNbr = 0;
        while (currEltStp != nullptr)
        {
            if (inputDataStp == currEltStp->mainRec)
            {
                DBA_DYNFLD_STP autoCreateItemStp = mp.allocDynst(FILEINFO, AutoCreateItem);
                autoCreateExtPtr[activeAutoCreateNbr] = autoCreateItemStp;

                SET_SYSNAME(autoCreateItemStp, AutoCreateItem_MainObject, DBA_GetObjectCName(currEltStp->mainObject));
                SET_INT(autoCreateItemStp, AutoCreateItem_MainFKeyFldIndex, currEltStp->mainFKeyFldIndex);
                SET_ID(autoCreateItemStp, AutoCreateItem_OldMainFKeyId, currEltStp->oldMainFKeyId);
                SET_SYSNAME(autoCreateItemStp, AutoCreateItem_RefObject, DBA_GetObjectCName(currEltStp->refObject));
                SET_EXTENSION_ONE(autoCreateItemStp, AutoCreateItem_RefRec, currEltStp->refRec);
                SET_INT(autoCreateItemStp, AutoCreateItem_RefFKeyFldIndex, currEltStp->refFKeyFldIndex);
                SET_ID(autoCreateItemStp, AutoCreateItem_RefId, currEltStp->refId);
                SET_ENUM(autoCreateItemStp, AutoCreateItem_Action, currEltStp->action);
                SET_FLAG(autoCreateItemStp, AutoCreateItem_insertFlg, currEltStp->insertFlg);

                activeAutoCreateNbr++;
            }
            currEltStp = currEltStp->nextElt;
        }
        
        if (activeAutoCreateNbr > 0)
        {
            SET_EXTENSION(callRequestStp, CallRequest_AutocreateItems, autoCreateExtPtr, AutoCreateItem, activeAutoCreateNbr);
        }
    }

    DBA_DYNFLD_STP ioExtStp = mp.allocDynst(FILEINFO, Io_Ext);
    SET_EXTENSION_ONE(ioExtStp, Io_Ext_Ext, callRequestStp);

    DBA_PROC_STP procedure = DBA_GetStoredProcs(Notif, Technical, UNUSED, Io_Ext, ioExtStp, NullDynSt);
    RequestHelper requestHelper(dbiConnHelper);

    if (requestHelper.startProcedureCall(procedure, ioExtStp) == false)
    {
        DBA_RestoreAutocreateContext(inputDataStp, inputSt);
    }

    if (requestHelper.getLastResultRetCode() == RET_SUCCEED && SYS_IsGuiMode() == TRUE && (SYS_GetProgramState() <= ProgramState::Running))
    {
        DBA_ForceVerifOptiTab(&dbiConnHelper);
    }

    return(requestHelper.getLastResultRetCode());
}


/************************************************************************
*   Function             : DBA_Insert2()
*
*   Description          : Send a INSERT request to the server and retrieve
*                          returned status
*
*   Arguments            : object       : the request corresponding object
*                          inputSt      : the input dynamic struct. format
*                          inputData    : the pointer on the input dynamic struct.
*                          insOptions   : can be DBA_SET_CONN, DBA_NO_CLOSE, DBA_INS_ID
*                          allocConn    : 1. pointer which will contain the connectNo
*                                            used for the request if insOptions is
*                                            DBA_NO_CLOSE.
*                                         2. pointer which contain a connection number
*                                            if insOptions is DBA_SET_CONN.
*                          msgStructPtr : pointer on a structure which will contain
*                                         recieved messages informations.
*
*   Functions call       : DBA_GetConnection
*                          DBA_GetStoredProcs
*                          SYB_SetInsUpdParameters
*                          DBA_EndConnection
*
*   Return               : RET_SUCCEED              : if no problem was detected
*                          RET_DBA_ERR_ARGNOMATCH   : if input arg. problem
*                          RET_DBA_ERR_PROCNOTFOUND : if no procedure founded
*                          RET_DBA_ERR_SETPARAM     : if problem while setting proc. parameters
*                          RET_DBA_ERR_CONNOTFOUND  : if no connection founded
*                          RET_DBA_ERR_DBPROBLEM    : if DB/connection problem
*                          RET_DBA_ERR_SYBBIND      : if poblem while binding received fields
*                          RET_MEM_ERR_ALLOC        : if allocation failed
*                          RET_DBA_ERR_READ_DATA    : if problem while reading received data
*                          RET_GEN_ERR_INVARG       : if problem while setting function params.
*                          a RET_CODE               : if a message has been received
*
*   Last Modification    : 19.12.95 - PEC - Added arguments insOptions, allocConn
*                                           msgStructPtr and suppressed argument
*                                           insStatus.
*                                           Function now return a RET_CODE.
*                          12.04.96 - PEC - Ref.: DVP029+
*                          26.08.96 - PEC - Ref.: DVP178  -> Deadlock handling
*                          18.09.96 - PEC - Ref.: DVP178+ -> Deadlock handling
*                          16.10.96 - PEC - Ref.: DVP178+ -> waitfor delay 00:00:0x
*                          17.10.96 - PEC - Ref.: BUG186.
*                          21.03.97 - PEC - Ref.: DVP400.
*                          03.06.97 - PEC - Ref.: DVP483.
*                          10.06.97 - PEC - Ref.: DVP499.
*                          25.02.98 - GRD - Ref.: REF1081.
*                          29.10.98 - GRD - Ref.: REF2644.
*                          07.02.00 - GRD - Ref.: REF4204.
*                          09.04.01 - GRD - Ref.: REF5037.
*                          REF7264 - 0201225 - PMO : Compilation errors and warnings with C++ compiler
*                          REF8623 - TEB - 030813 : Correction of transaction for Customer Data
*                          REF9538 - 031007 - PMO : Update of a record and udfields is not alway in the same transaction
*                          REF8500 - 040510 - PMO : Add a draft_order_id in extended operation to distinguish the id from extended orders and the one from extended operation
*                          REF11780 - 100406 - PMO : Implementation of the Sybase timestamp field
*************************************************************************/
RET_CODE DBA_Insert2(OBJECT_ENUM            object,
    int                    role,           /* Ref.: DVP029 */
    DBA_DYNST_ENUM         inputSt,
    DBA_DYNFLD_STP         inputData,
    int                    insOptions,
    int *                  allocConn,
    DBA_ERRMSG_INFOS_STP   msgStructPtr)
{
    DbiConnection*  dbiConn = nullptr;

    /* If no connection number is given */
    if ((insOptions & DBA_SET_CONN) != DBA_SET_CONN)
    {
        /* Get a free connection */
        if ((dbiConn = DBA_GetDbiConnection(SqlServer)) == nullptr)
        {
            MSG_RETURN(RET_DBA_ERR_CONNOTFOUND);
        }
    }
    else
    {
        /* If a connection number is given */
        if (allocConn != NULL)
        {
            dbiConn = DBA_GetDbiConnFromConnectNo(*allocConn);
            if (dbiConn == nullptr) {
                return RET_DBA_ERR_CONNOTFOUND;
            }
        }
        else
        {
            MSG_RETURN(RET_DBA_ERR_ARGNOMATCH);
        }
    }
    RET_CODE retCode = DBA_Insert2(object,
                                    role,           /* Ref.: DVP029 */
                                    inputSt,
                                    inputData,
                                    insOptions,
                                    *dbiConn,
                                    msgStructPtr);

    bool isInError = (retCode == RET_DBA_ERR_DIALOG);
    if (isInError)
    {
        dbiConn->setValidConnection(false);
    }
    if ((insOptions & DBA_NO_CLOSE) != DBA_NO_CLOSE)
    {
        DBA_EndConnection(&dbiConn, isInError);
    }
    return retCode;
}

RET_CODE DBA_Insert2(OBJECT_ENUM            object,
                     int                    role,
					 DBA_DYNST_ENUM         inputSt,
					 DBA_DYNFLD_STP         inputData,
                     int                    insOptions,
                     DbiConnection&         dbiConn,
                     DBA_ERRMSG_INFOS_STP   msgStructPtr,
                     DBA_ERRMSG_HEADER_STP  dbaErrMsgHeaderStp)
{
    DbiConnectionHelper dbiConnHelper(&dbiConn, false);
    dbiConnHelper.dbaSetOptions(insOptions | DBA_SET_CONN | DBA_NO_CLOSE);

    RET_CODE ret = DBA_Insert2(object, role, inputSt, inputData, dbiConnHelper);

    /* PMSTA-49780- BSV- 040722 */
    //dbaErrMsgHeaderStp is default argument.Check for NULL before copying objects.
    if (dbaErrMsgHeaderStp != nullptr)
        dbaErrMsgHeaderStp->copyDbaErrMsgHeaderClassObject(*dbiConnHelper.dbaGetMsgStructHeader());
    return(ret);
}

RET_CODE DBA_Insert2(OBJECT_ENUM          object,
                     int                  role,
					 DBA_DYNST_ENUM       inputSt,
					 DBA_DYNFLD_STP       inputData,
                     DbiConnectionHelper& dbiConnHelper)
{
#ifdef AAAPROFILER
    ZoneScopedNS("DBA_Insert2", 5);
#endif

    DbaCallGuard dbaCallGuard(dbiConnHelper); /* PMSTA-45413 - LJE - 210804 */

    int             cpt = 0;
    DBI_INT         resultType = 0, status = 0;
	RET_CODE        retCode     = RET_SUCCEED;
    RET_CODE        finalResult = RET_SUCCEED;
	char            tranCount=0;
    FLAG_T          internalProcedureFlg = FALSE; /* PMSTA-35191 - JPR - 190319 */
	FLAG_T          localTranFlg=FALSE;
	DBA_DYNFLD_STP	*outSubscriptionTab = NULL;
	DBA_DYNFLD_STP	inSubscriptionSt = NULL;
	int				outSubscriptionNbr = 0;
    FLAG_T          localEventFlg = FALSE;
    int             fatalError = FALSE;
    static          QUESTIONNAIRE_LICENSEE_ENUM questLevelEn = QuestionnaireLicensee_NoValue; /* PMSTA-24776 - DDV - 161011 */

    /* PMSTA-24776 - DDV - 161011 */
    if (questLevelEn == QuestionnaireLicensee_NoValue)
    {
        GEN_GetApplInfo(ApplQuestionnaireLicence, &questLevelEn);
    }

	/* Retrieve a procedure in the object procedures list */
    DBA_PROC_STP procedure = DBA_GetStoredProcs(Insert, object, role, inputSt, inputData, NullDynSt);

	/* If no procedure */
	if (procedure == NULL)
	{
		if ((dbiConnHelper.dbaGetOptions() & DBA_NO_PROC_ERROR) == 0) /* PMSTA-13946 - LJE - 120328 */
		{
		    char	     objString[40];
            const char  *sqlName = DBA_GetDictEntitySqlName(object);
		    OBJECT_ENUM  objEn;
		    const char	*entitySqlNameIn=NULL;
		    char	     entityStrIn[13];

		    if (sqlName != NULL)
		    {
			    strcpy(objString, sqlName);
		    }
		    else
		    {
			    sprintf(objString, "unknown(" szFormatObj ")",object);
		    }

            DBA_GetObjectEnumByDynSt(inputSt, &objEn);
   		    entitySqlNameIn = DBA_GetDictEntitySqlName(objEn);

	        if (entitySqlNameIn == NULL)
	        {
			    entitySqlNameIn = DBA_GetDynStCName(inputSt);
		    }
		    if (entitySqlNameIn == NULL)
		    {
		        sprintf(entityStrIn,"unknown(%d)",inputSt);
		        entitySqlNameIn = entityStrIn;
		    }

            DBA_LogMesgProcedureNotFound(Insert, object, role, inputSt, inputData, NullDynSt, false, "Insert", objString, entitySqlNameIn, "none");  /* PMSTA-24985 - 111016 - PMO */
		}
		return(RET_DBA_ERR_PROCNOTFOUND);
	}
    dbiConnHelper.setCurrProcedure(procedure);  /* PMSTA-45413 - LJE - 210804 */

    /* PMSTA-24771 - DDV - 161011 - If license is not active refuse insertion into questionnaire histo and all tables with nature questionnaire */
    if (questLevelEn < QuestionnaireLicensee_Level1 &&
        (object == QuestHisto ||
         (DBA_GetDictEntityStSafe(object))->entNatEn == EntityNat_Questionnaire)
       )
    {
        MSG_SendMesg(RET_ENV_ERR_WRONGLICENSEKEY, 1, FILEINFO, "Suitability and Investment profiling");
        return(RET_ENV_ERR_WRONGLICENSEKEY);
    }

    /* PMSTA-35191 - JPR - 190319 */
    if (procedure->server == InternalProc)
    {
        internalProcedureFlg = TRUE;
    }
    else
    {
        /* PMSTA-46681 - LJE - 231106 */
        if (dbiConnHelper.isDbaAccess(Insert))
        {
            return DBA_InsXdObject(object, inputData->getDynStEn(), inputData, dbiConnHelper);
        }

        if ((dbiConnHelper.isHttp()) &&
            (dbiConnHelper.isBlockMode() == false))
        {
            return DBA_CallHttp(dbiConnHelper,
                                Insert,
                                object,
                                role,
                                inputSt,
                                inputData);
        }

        internalProcedureFlg = FALSE;
    }

    if (dbiConnHelper.isValidAndInit() == false)
    {
        return(RET_DBA_ERR_CONNOTFOUND);
    }

    DbiConnection& dbiConn = *dbiConnHelper.getConnection();

    dbiConn.setReadOnly(procedure); /* PMSTA-29027 - LJE - 190111 */

    /* REF8623 - TEB - 030813 - Begin */
    /* Open a transaction if we have some customers data */
	/* or Oracle database*/
    /* PMSTA-18473 - DDV - 141001 - Don't open transaction when preparing data for MultiAccess */
    if ((dbiConn.getConnStructPtr()->blockMode == FALSE) &&
        (dbiConn.isDbTransactionRequired() || DBA_GetCustFldNbr(object) > 1))
	{
		if (dbiConn.isInTransaction() == false &&  /* DLA - REF9468 - 030915 */
            procedure->server == SqlServer)        /* PMSTA-45413 - LJE - 210729 - Do not create transaction for internal proc. */
		{
			dbiConn.beginTransaction();
            localTranFlg = TRUE;
		}
    }
    /* REF8623 - TEB - 030813 - End */

	/* DLA - PMSTA09887 - 110303 */
    DBA_TruncateDynStStringToMDLength(inputData);

	/*
	 * Is there any valid subscription for this entity?
	 */

	if ((procedure == NULL || (procedure->procMask & PROCMASK_DISABLE_SUBSCRIPTION) != PROCMASK_DISABLE_SUBSCRIPTION) &&  /* DLA - REF10507 - 041210 / REF10845 - 050118 - PMO */
        (role != DBA_ROLE_UPD_UD_FIELDS) &&
        ((DBA_IsSubscriptionActive(object) == TRUE) && /* PMSTA15199 - DDV - 121128 - Replace DBA_IsTrustedObject by DBA_IsSubscriptionActive */
        (role != DBA_ROLE_UPDSTATUS_NOSUBSCRIPTION) &&
        (procedure->server != InternalProc) && (EV_IsSubscriptionActive == TRUE) &&
		(object != EOp) && (dbiConn.getConnStructPtr()->blockMode == FALSE) &&
        ((dbiConnHelper.dbaGetOptions() & DBA_NO_SUBS_AUDIT) !=  DBA_NO_SUBS_AUDIT) && /* DLA - PMSTA06808 - 081114 */
        (DBA_GetDictEntitySt(object) != nullptr)))
	{
		if ((inSubscriptionSt = ALLOC_DYNST(A_Subscription)) == NULL)
		{
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		SET_DICT(inSubscriptionSt, A_Subscription_EntityDictId, (DBA_GetDictEntityStSafe(object))->entDictId);
		SET_ENUM(inSubscriptionSt, A_Subscription_ActionEn, Subscription_Action_Insert);
		SET_ENUM(inSubscriptionSt, A_Subscription_ModuleEn, dbiConn.getSubscriptionModuleEn());

		DBA_Select2(Subscription,
					DBA_ROLE_SEL_SUBSCRIPTIONS,
					A_Subscription,
					inSubscriptionSt,
					A_Subscription,
					&outSubscriptionTab,
					DBA_SET_CONN | DBA_NO_CLOSE,
					UNUSED,
					&outSubscriptionNbr,
					dbiConn);

		FREE_DYNST(inSubscriptionSt, A_Subscription);

		/*
		 * Verify if there are entities to be audited.
		 * If so, we have to load and keep the current DYNFLDST from database
		 * BEFORE modifying it.
		 */

        if (outSubscriptionNbr > 0)
		{
            localEventFlg = TRUE;
		}
	}

	/*
	 * Some entity attributes could contain fields of type TextType, this is why we MUST be sure
	 * that a transaction is opened to allow data integrity.
	 * Same if we have subscriptions to insert.
	 * REF4204.
	 */

    if (localEventFlg == TRUE)
	{
		if (dbiConn.isInTransaction() == false) /* DLA - REF9468 - 030915 */
		{
			dbiConn.beginTransaction();
            localTranFlg = TRUE;
		}
	}

    if(SYS_IsGuiMode() == TRUE)
    {
        EV_GuiCheckOptiStatus = NoCheck_GuiOptiStatus;
    }

	tranCount = dbiConn.m_transactCpt;   /* BUG186 */

    SCPT_AUTOCREATE_HEADER_STP autocreateHeader = SCPT_GetAutocreateHeader();

	/**** BEGIN DVP483  ****/ /* REF7291 - LJE - 020730 */
    if ((retCode == RET_SUCCEED) &&     /*  HFI-PMSTA-14997-120914  */
        DictSprocClass::isRoleBatchAllowed(role) &&
        (autocreateHeader != nullptr && autocreateHeader->asgnRecCount > 0))
	{
		if (!((dbiConnHelper.dbaGetOptions() & DBA_NO_MAIN_LEVEL) == DBA_NO_MAIN_LEVEL))
		{
            if (dbiConn.isInTransaction() == false) /* DLA - REF9468 - 030915 */
			{
				dbiConn.beginTransaction();
				localTranFlg = TRUE;
			}

			retCode = DBA_HandleAutocreateStack(inputData, dbiConn, FALSE, internalProcedureFlg); /* PMSTA-35191 - JPR - 190319 */

			if (retCode != RET_SUCCEED)
			{
				if (localTranFlg == TRUE)
				{
					dbiConn.endTransaction(FALSE);
				}
                DBA_RestoreAutocreateContext(inputData, inputSt); /* REF9112 - LJE - 030516 */
				DBA_FreeDynStTab(outSubscriptionTab, outSubscriptionNbr, A_Subscription);
				return(retCode);
			}
		}
	}
	/**** END   DVP483  ****/

	/**** BEGIN DVP029+ ****/
	/* If Procedure is an internal proc, call a C function, not a stored procedure */
	if (internalProcedureFlg == TRUE)
	{
		do
		{
			cpt++;


			retCode = procedure->fctDefSt.insFct(object, inputSt, inputData, dbiConnHelper);
			if (retCode == RET_SRV_LIB_ERR_DEADLOCK && tranCount == (char)0 &&
				SYS_GetEnv("AAASHOWDEADLOCK") == NULL)  /* BUG186 */
			{
				switch (cpt)
				{
				case 1:
					/* DBA_SqlExec("waitfor delay \"0:00:01\"", *dbiConn); */
					SYS_MilliSleep(1000); /* PMSTA-20159 - TEB - 150624  */
					break;

				case 2:

					/* DBA_SqlExec("waitfor delay \"0:00:02\"", *dbiConn); */
					SYS_MilliSleep(2000); /* PMSTA-20159 - TEB - 150624  */
					break;

				case 3:

					/* DBA_SqlExec("waitfor delay \"0:00:05\"", *dbiConn); */
					SYS_MilliSleep(5000); /* PMSTA-20159 - TEB - 150624  */
					break;
				}

				dbiConn.m_transactCpt = 0;  /* BUG186 */
			}
		}
		while (retCode   == RET_SRV_LIB_ERR_DEADLOCK &&
			    tranCount == (char)0                  &&   /* BUG186 */
			    cpt<ITER_NBR_FOR_DEADLOCK &&
			    SYS_GetEnv("AAASHOWDEADLOCK") == NULL);

		/* If deadlock still occurs after 3 tries and if we were in the main transaction */
		if (retCode == RET_SRV_LIB_ERR_DEADLOCK && tranCount == (char)0)  /* BUG186 */
		{
			MSG_SendMesg(RET_SRV_LIB_ERR_DEADLOCK, 1, FILEINFO, procedure->procName);
		}

        /* PMSTA18182 - DDV - 140528 - Manage autocreate */
        if ((retCode == RET_SUCCEED) &&
            DictSprocClass::isRoleBatchAllowed(role) &&
            (autocreateHeader != nullptr && autocreateHeader->asgnRecCount > 0))
		{
			if (!((dbiConnHelper.dbaGetOptions() & DBA_NO_MAIN_LEVEL) == DBA_NO_MAIN_LEVEL))
			{
                if (dbiConn.isInTransaction() == false)
				{
					dbiConn.beginTransaction();
					localTranFlg = TRUE;
				}

				retCode = DBA_HandleAutocreateStack(inputData, dbiConn, TRUE, internalProcedureFlg); /* PMSTA-35191 - JPR - 190319 */

				if (retCode != RET_SUCCEED)
				{
					DBA_RestoreAutocreateContext(inputData, inputSt);
				}
			}
		}
		/**** BEGIN DVP483  ****/
			    /*if ((retCode != RET_SUCCEED) && commented out SSO - 000315 , moved in DBA_EndTransaction param */
		if  (localTranFlg == TRUE)
		{
			dbiConn.endTransaction (retCode == RET_SUCCEED? 1 : 0);			/* Rollback data. */
		}
		/**** END  DVP483  ****/

        if (retCode == RET_SUCCEED && /* DLA  - PMSTA-22833 - 170122 */
            SYS_IsGuiMode() == TRUE && !((dbiConnHelper.dbaGetOptions() & DBA_NO_MAIN_LEVEL) == DBA_NO_MAIN_LEVEL) &&
            (dbiConn.isInTransaction() == false))
		{
            DBA_ForceVerifOptiTab(&dbiConnHelper);
		}

        if (retCode != RET_SUCCEED)
        {
		    DBA_RestoreAutocreateContext(inputData, inputSt); /* REF9112 - LJE - 030516 */
        }

		DBA_FreeDynStTab(outSubscriptionTab, outSubscriptionNbr, A_Subscription);
		return(retCode);
	}
	/**** END DVP029+ ****/


	/*** BEGIN DVP178 ***/
	do
	{
		cpt++;

        if (USE_NEW_ACCESS_API(dbiConnHelper.getConnection()))
        {
            RequestHelper requestHelper(dbiConnHelper);
            if (requestHelper.startProcedureCall(procedure, inputData) == false)
            {
                if (localTranFlg == TRUE)
                {
                    dbiConn.endTransaction(FALSE);
                }

                DBA_RestoreAutocreateContext(inputData, inputSt); /* REF9112 - LJE - 030516 */
                DBA_FreeDynStTab(outSubscriptionTab, outSubscriptionNbr, A_Subscription);

                return(requestHelper.getLastResultRetCode());
            }
        }
        else
        {

            /* Retrieve and memorize parameters names and types in the meta dictionary tables */
            if (DBI_SetProcParameters(dbiConn, inputSt, inputData, procedure, object, 0) != TRUE)	/* REF2644 */
            {
                /**** BEGIN DVP483  ****/
                if (localTranFlg == TRUE)
                {
                    dbiConn.endTransaction(FALSE);
                }
                /**** END  DVP483  ****/
                dbiConn.releaseCommand();
                DBA_RestoreAutocreateContext(inputData, inputSt); /* REF9112 - LJE - 030516 */
                DBA_FreeDynStTab(outSubscriptionTab, outSubscriptionNbr, A_Subscription);
                MSG_RETURN(RET_DBA_ERR_SETPARAM);
            }

            /* Send the request to the server */
            if (dbiConn.sendRequest(&resultType) != RET_SUCCEED)
            {
                dbiConn.releaseCommand();

                if (localTranFlg == TRUE)
                {
                    dbiConn.endTransaction(FALSE);
                }

                DBA_RestoreAutocreateContext(inputData, inputSt); /* REF9112 - LJE - 030516 */
                DBA_FreeDynStTab(outSubscriptionTab, outSubscriptionNbr, A_Subscription);

                /* PMSTA-18593 - LJE - 150617 */
                if (dbiConnHelper.emptyMsg() == false)
                {
                    dbiConnHelper.sendAllMsg();
                    return dbiConn.m_lastResultRetCode;
                }
                else
                {
                    MSG_RETURN(RET_DBA_ERR_DBPROBLEM);
                }
            }

            /* Check if the insert has returned a block of datas (id and timestamp field) */
            /* DLA - PMSTA08801 - 091117 - Check if the proc return output parameters.  */
            if (RET_SUCCEED == retCode
                && (DBI_ROW_RESULT == resultType || DBI_PARAM_RESULT == resultType))               /* PMSTA-21215 - 271015 - PMO / REF11780 - 100406 - PMO */
            { /* Yes */
                fatalError = DBA_ReadSqlBlockResult(dbiConn, inputSt, inputData);
            }

            /*** Temporary allow a resultType equal to DBI_CMD_SUCCEED **/
            /* REF11780 - 100406 - PMO */
            switch (resultType)
            {
                case DBI_STATUS_RESULT:
                case DBI_CMD_SUCCEED:
                case DBI_ROW_RESULT:
                case DBI_PARAM_RESULT: /* DLA - PMSTA08801 - 091117 */
                    break;

                default:
                    fatalError = TRUE;
                    break;
            }

            if (TRUE == fatalError)  /* REF11780 - 100406 - PMO */
            {
                dbiConn.releaseCommand();
                /**** BEGIN DVP483  ****/
                if (localTranFlg == TRUE)
                {
                    dbiConn.endTransaction(FALSE);
                }
                /**** END  DVP483  ****/

                DBA_RestoreAutocreateContext(inputData, inputSt); /* REF9112 - LJE - 030516 */
                DBA_FreeDynStTab(outSubscriptionTab, outSubscriptionNbr, A_Subscription);
                MSG_RETURN(RET_DBA_ERR_DBPROBLEM);
            }

            dbiConn.processAllResults(&status, object, inputSt, inputData, procedure); /* PMSTA08801 - DDV - 091211 - Add new parameters to read output parameters */
            /* Call to function which will filter received messages during insert operation */
            dbiConn.filterMsgInfos(&finalResult);
        }

        /**** DVP178+ - 16.10.1996 ****/
        if (finalResult == RET_SRV_LIB_ERR_DEADLOCK && tranCount == (char)0 &&
            SYS_GetEnv("AAASHOWDEADLOCK") == NULL)    /* BUG186 */
        {
            switch (cpt)
            {
                case 1:
                    SYS_MilliSleep(1000); /* PMSTA-20159 - TEB - 150624  */
                    break;
                case 2:
                    SYS_MilliSleep(2000); /* PMSTA-20159 - TEB - 150624  */
                    break;
                case 3:
                    SYS_MilliSleep(5000); /* PMSTA-20159 - TEB - 150624  */
                    break;
            }
            dbiConn.m_transactCpt = 0;       /* BUG186 */
        }
        /**** DVP178+ - 16.10.1996 ****/
    }
	while (finalResult == RET_SRV_LIB_ERR_DEADLOCK &&
	       tranCount   == (char)0                  &&            /* BUG186 */
	       cpt<ITER_NBR_FOR_DEADLOCK &&
	       SYS_GetEnv("AAASHOWDEADLOCK") == NULL);
	/*** END  DVP178 ***/

	/*** BEGIN DVP178+ ***/
	/* If deadlock still occurs after 3 tries and if we were in the main transaction */
	if (finalResult == RET_SRV_LIB_ERR_DEADLOCK && tranCount == (char)0)    /* BUG186 */
	{
		MSG_SendMesg(RET_SRV_LIB_ERR_DEADLOCK, 1, FILEINFO, procedure->procName);
		dbiConn.releaseCommand();
        DBA_RestoreAutocreateContext(inputData, inputSt); /* REF9112 - LJE - 030516 */
		DBA_FreeDynStTab(outSubscriptionTab, outSubscriptionNbr, A_Subscription);
		return(RET_SRV_LIB_ERR_DEADLOCK);
	}
	/*** END   DVP178+ ***/

	/*** BEGIN REF1081. ***/
	if (finalResult == RET_SRV_LIB_ERR_DB_OVERFLOW)
	{
        /* REF8844 - LJE - 030415 */
		if (object == EPos)
        {

			MSG_SendMesg(RET_SRV_LIB_ERR_DB_OVERFLOW, 1, FILEINFO,
					 "inserting ExtPos",
					 GET_CODE(inputData, ExtPos_OpenOpCd),
					 GET_ID(inputData  , ExtPos_PtfId),
					 GET_ENUM(inputData, ExtPos_NatEn));

        }
        else if (object == EOp)
        {

			MSG_SendMesg(RET_SRV_LIB_ERR_DB_OVERFLOW, 1, FILEINFO,
					 "inserting ExtOp",
					 GET_CODE(inputData, ExtOp_Cd),
					 GET_ID(inputData  , ExtOp_PtfId),
					 GET_ENUM(inputData, ExtOp_NatureEn));

        }
        else if (object == Pos)
        {

			MSG_SendMesg(RET_SRV_LIB_ERR_DB_OVERFLOW, 1, FILEINFO,
					 "inserting Position",
					 GET_CODE(inputData, A_Pos_OpenOpCd),
					 GET_ID(inputData  , A_Pos_PtfId),
					 GET_ENUM(inputData, A_Pos_OpenOpNatEn));

        }
        else if (object == BalPos)
        {

			MSG_SendMesg(RET_SRV_LIB_ERR_DB_OVERFLOW, 1, FILEINFO,
					 "inserting BalPos",
					 GET_CODE(inputData, A_BalPos_OpenOpCd),
					 GET_ID(inputData  , A_BalPos_PtfId),
					 GET_ENUM(inputData, A_BalPos_OpenOpNatEn));

        }
	}
	/*** END REF1081. ***/

	/* Memorize the record id in the input data structure after a successfull insertion */
	if ((status > 0 || USE_NEW_ACCESS_API(dbiConnHelper.getConnection())) && /* PMSTA-45507 - DDV - 210622 - status is not used with new API */
        finalResult == RET_SUCCEED && (dbiConnHelper.dbaGetOptions() & DBA_INS_ID) != DBA_INS_ID)
	{
	    /* REF7291 - LJE - 020411 : BEGIN */
        if ((retCode == RET_SUCCEED) &&     /*  HFI-PMSTA-14997-120914  */
            DictSprocClass::isRoleBatchAllowed(role) &&
            (autocreateHeader != nullptr && autocreateHeader->asgnRecCount > 0))
		{
			if (!((dbiConnHelper.dbaGetOptions() & DBA_NO_MAIN_LEVEL) == DBA_NO_MAIN_LEVEL))
			{
                if (dbiConn.isInTransaction() == false) /* DLA - REF9468 - 030915 */
				{
					dbiConn.beginTransaction();
					localTranFlg = TRUE;
				}

				retCode = DBA_HandleAutocreateStack(inputData, dbiConn, TRUE, internalProcedureFlg); /* PMSTA-35191 - JPR - 190319 */

				if (retCode != RET_SUCCEED)
				{
					if (localTranFlg == TRUE)
					{
						dbiConn.endTransaction(FALSE);
					}
                    DBA_RestoreAutocreateContext(inputData, inputSt); /* REF9112 - LJE - 030516 */
					DBA_FreeDynStTab(outSubscriptionTab, outSubscriptionNbr, A_Subscription);
					return(retCode);
				}
			}
		}
	}

	if (finalResult == RET_SUCCEED &&                       /* REF8623 - TEB - 030813 */
        (status > 0 || USE_NEW_ACCESS_API(dbiConnHelper.getConnection())) && /* PMSTA-45507 - DDV - 210622 - status is not used with new API */
        DBA_GetCustFldNbr(object) > 1)
	{
	    const int idIdx = (procedure->remapIdIdxPtr != nullptr ? *(procedure->remapIdIdxPtr) : 0);
		const int udIdIdx = DBA_GetFirstCustFld(object);
        SET_ID(inputData, udIdIdx, GET_ID(inputData, idIdx));

        if ((finalResult = DBA_Update2(object,       /* REF8623 - TEB - 030813 */
                                       DBA_ROLE_UPD_UD_FIELDS,
                                       inputSt,
                                       inputData,
                                       DBA_SET_CONN | DBA_NO_CLOSE | DBA_NO_MAIN_LEVEL,
                                       dbiConn)) != RET_SUCCEED)  /* REF8623 - TEB - 030813 */
        {/* REF8623 - TEB - 030813 */
            MSG_FillMsgStruct(dbiConnHelper.getNewErrMsgInfoStp(FILEINFO),
                              RET_SRV_LIB_ERR_TRIGGER_MSG,
                              MSG_BuildMesg(UNUSED, NULL, "Error occurring while updating UDFields"),
                              ServerHandler, /* REF7264 - PMO */
                              RET_LEV_BUSINESS_ERROR,
                              FALSE,
                              NULL,
                              NULL,
                              0);

        }
	}

	switch(finalResult)
	{
	case RET_SUCCEED:
		if (finalResult == RET_SUCCEED)
		{
			/*
		 	 * Insert was successful, verify if events has to be raised for this Entity.
		 	 * REF4204 - 000207 - GRD.
		 	 */

			if (localEventFlg == TRUE)
			{
				finalResult = DBA_LogSubscriptionEvents(object,         /* REF5037 */
						                                Subscription_Action_Insert,
						                                inputSt,
						                                inputData,
                                                        NULL,
						                                dbiConn,
						                                outSubscriptionTab,
						                                outSubscriptionNbr);
			}
        }

		if (localTranFlg == TRUE)        /* COMMIT/ROLLBACK transaction */
		{
			dbiConn.endTransaction(finalResult == RET_SUCCEED ? TRUE : FALSE);
		}

		break;

	default:
		/**** BEGIN DVP483  ****/        /* ROLLBACK transaction */ /* SSO 991011: if deadlock, -1 -> OK, no rollback*/
		if (localTranFlg == TRUE)
		{
			dbiConn.endTransaction(FALSE);
		}
		/**** END  DVP483  ****/

		break;
	}

    if (retCode == RET_SUCCEED && /* DLA  - PMSTA-22833 - 170122 */
        finalResult == RET_SUCCEED &&   /* DLA  - PMSTA-22833 - 170215 */
        SYS_IsGuiMode() == TRUE && !((dbiConnHelper.dbaGetOptions() & DBA_NO_MAIN_LEVEL) == DBA_NO_MAIN_LEVEL) &&
        (dbiConn.isInTransaction() == false))
	{
        DBA_ForceVerifOptiTab(&dbiConnHelper);
	}

	DBA_FreeDynStTab(outSubscriptionTab, outSubscriptionNbr, A_Subscription);
	dbiConn.releaseCommand();

	if (finalResult != RET_SUCCEED)
	{
        DBA_RestoreAutocreateContext(inputData, inputSt); /* REF9112 - LJE - 030516 */

		return(finalResult);
	}

	if(EV_ExtractFile && EV_SetProcParametersFlg)
	{
		DATE_ResetTimer(EV_ExtractFileTimerPtr, TIMER_MASK_GEN);
		DATE_StartTimer(EV_ExtractFileTimerPtr, TIMER_MASK_GEN);
		EV_SetProcParametersFlg = FALSE;
	}

	return(RET_SUCCEED);
}

/************************************************************************
*   Function             : DBA_Update2()
*
*   Description          : Send a UPDATE request to the server and retrieve
*                          returned status
*
*   Arguments            : object       : the request corresponding object
*	       (new)       role         : always UNUSED (excecpt for UD_FIELDS)
*                          inputSt      : the input dynamic struct. format
*                          inputData    : the pointer on the input dynamic struct.
*                          updOptions   : can be DBA_SET_CONN, DBA_NO_CLOSE
*                          allocConn    : 1. pointer which will contain the dbiConn->getId()
*                                            used for the request if updOptions is
*                                            DBA_NO_CLOSE.
*                                         2. pointer which contain a connection number
*                                            if updOptions is DBA_SET_CONN.
*                          msgStructPtr : pointer on a structure which will contain
*                                         recieved messages informations.
*
*   Functions call       : DBA_GetConnection
*                          DBA_GetStoredProcs
*                          SYB_SetInsUpdParameters
*                          DBA_EndConnection
*
*   Return               : RET_SUCCEED              : if no problem was detected
*                          RET_DBA_ERR_ARGNOMATCH   : if input arg. problem
*                          RET_DBA_ERR_PROCNOTFOUND : if no procedure founded
*                          RET_DBA_ERR_SETPARAM     : if problem while setting proc. parameters
*                          RET_DBA_ERR_CONNOTFOUND  : if no connection founded
*                          RET_DBA_ERR_DBPROBLEM    : if DB/connection problem
*                          RET_DBA_ERR_SYBBIND      : if problem while binding received fields
*                          RET_MEM_ERR_ALLOC        : if allocation failed
*                          RET_DBA_ERR_READ_DATA    : if problem while reading received data
*                          RET_GEN_ERR_INVARG       : if problem while setting function params.
*                          a RET_CODE               : if a message has been received
*
*   Last Modification    : 19.12.95 - PEC - Added arguments updOptions, allocConn
*                                           msgStructPtr and suppressed argument
*                                           updateStatus.
*                                           Function now return a RET_CODE.
*                          18.04.96 - PEC - Ref.: DVP029+
*                          26.08.96 - PEC - Ref.: DVP178  -> Deadlock handling
*                          18.09.96 - PEC - Ref.: DVP178+ -> Deadlock handling
*                          16.10.96 - PEC - Ref.: DVP178+ -> Deadlock handling : waitfor delay 00:00:0x
*                          17.10.96 - PEC - Ref.: BUG186.
*                          03.06.97 - PEC - Ref.: DVP483.
*                          10.06.97 - PEC - Ref.: DVP499.
*                          25.02.98 - GRD - Ref.: REF1081.
*                          29.10.98 - GRD - Ref.: REF2644.
*                          09.03.00 - GRD - Ref.: REF4204. Subscription.
*                          20.07.00 - GRD - Ref.: REF4946.
*                          09.04.01 - GRD - Ref.: REF5037.
*                          REF7264 - 0201225 - PMO : Compilation errors and warnings with C++ compiler
*                          REF8623 - TEB - 030813 : Correction of transaction for Customer Data
*                          REF9538 - 031007 - PMO : Update of a record and udfields is not alway in the same transaction
*                          REF8500 - 040510 - PMO : Add a draft_order_id in extended operation to distinguish the id from extended orders and the one from extended operation
*                          REF11780 - 100406 - PMO : Implementation of the Sybase timestamp field
*************************************************************************/
RET_CODE DBA_Update2(OBJECT_ENUM         object,
    int                  role,
    DBA_DYNST_ENUM       inputSt,
    DBA_DYNFLD_STP       inputData,
    int                  updOptions,
    int                  *allocConn,
    DBA_ERRMSG_INFOS_STP msgStructPtr)
{
    DbiConnection * dbiConn = nullptr;
    RET_CODE        retCode = RET_SUCCEED;

    /* If no connection number is given */
    if ((updOptions & DBA_SET_CONN) != DBA_SET_CONN)
    {
        /* Get a free connection */
        if ((dbiConn = DBA_GetDbiConnection(SqlServer)) == nullptr)
        {
            MSG_RETURN(RET_DBA_ERR_CONNOTFOUND);
        }
    }
    else
    {
        /* If a connection number is given */
        if (allocConn != NULL) /* FPL-PMSTA06305-080508 */
        {
            if (DBA_CheckConnectNbCoherence(*allocConn) != RET_SUCCEED) /* FPL-PMSTA06305-080508 */
            {
                SYS_BreakOnDebug();
                return (RET_DBA_ERR_ARGNOMATCH);
            }
            dbiConn = DBA_GetDbiConnFromConnectNo(*allocConn);
            if (dbiConn == nullptr) {
                return RET_DBA_ERR_CONNOTFOUND;
            }
        }
        else
        {
            MSG_RETURN(RET_DBA_ERR_ARGNOMATCH);
        }
    }

    retCode = DBA_Update2(object,
                          role,
                          inputSt,
                          inputData,
                          updOptions,
                          *dbiConn,
                          msgStructPtr);

    bool isInError = (retCode == RET_DBA_ERR_DIALOG);
    if (isInError)
    {
        dbiConn->setValidConnection(false);
    }
    if ((updOptions & DBA_NO_CLOSE) != DBA_NO_CLOSE)
    {
        DBA_EndConnection(&dbiConn, isInError);
    }
    return retCode;
}

RET_CODE DBA_Update2(OBJECT_ENUM         object,
                    int                  role,
                    DBA_DYNST_ENUM       inputSt,
                    DBA_DYNFLD_STP       inputData,
                    int                  updOptions,
                    DbiConnection&       dbiConn,
                    DBA_ERRMSG_INFOS_STP msgStructPtr,
                    DBA_ERRMSG_HEADER_STP  dbaErrMsgHeaderStp)  /* PMSTA-49780- BSV- 040722 */
{
    DbiConnectionHelper dbiConnHelper(&dbiConn, false);
    dbiConnHelper.dbaSetOptions(updOptions | DBA_SET_CONN | DBA_NO_CLOSE);

    const RET_CODE ret = DBA_Update2(object, role, inputSt, inputData, dbiConnHelper);

    dbiConn.sendAllMsg();

    /* PMSTA-49780- BSV- 040722 */
    //dbaErrMsgHeaderStp is default argument.Check for NULL before copying objects.
    if (dbaErrMsgHeaderStp != nullptr)
        dbaErrMsgHeaderStp->copyDbaErrMsgHeaderClassObject(*dbiConnHelper.dbaGetMsgStructHeader());

    return(ret);
}



/************************************************************************
*   Function             : DBA_Update2()
*
*   Description          : Send a UPDATE request to the server and retrieve
*                          returned status
*
*   Arguments            : object       : the request corresponding object
*	                       role         : always UNUSED (excecpt for UD_FIELDS)
*                          inputSt      : the input dynamic struct. format
*                          inputData    : the pointer on the input dynamic struct.
*                          dbiConnHelper
*
*   Functions call       : DBA_GetConnection
*                          DBA_GetStoredProcs
*                          SYB_SetInsUpdParameters
*                          DBA_EndConnection
*
*   Return               : RET_SUCCEED              : if no problem was detected
*                          RET_DBA_ERR_ARGNOMATCH   : if input arg. problem
*                          RET_DBA_ERR_PROCNOTFOUND : if no procedure founded
*                          RET_DBA_ERR_SETPARAM     : if problem while setting proc. parameters
*                          RET_DBA_ERR_CONNOTFOUND  : if no connection founded
*                          RET_DBA_ERR_DBPROBLEM    : if DB/connection problem
*                          RET_DBA_ERR_SYBBIND      : if problem while binding received fields
*                          RET_MEM_ERR_ALLOC        : if allocation failed
*                          RET_DBA_ERR_READ_DATA    : if problem while reading received data
*                          RET_GEN_ERR_INVARG       : if problem while setting function params.
*                          a RET_CODE               : if a message has been received
*
*   Last Modification    : PMSTA-24207 - 020816 - PMO : Regression: cannot update operation + fusion failure while running automator basic entry test
*
*************************************************************************/
RET_CODE DBA_Update2(OBJECT_ENUM         object,
                    int                  role,
                    DBA_DYNST_ENUM       inputSt,
                    DBA_DYNFLD_STP       inputData,
                    DbiConnectionHelper& dbiConnHelper)
{
#ifdef AAAPROFILER
    ZoneScopedNS("DBA_Update2", 5);
#endif

    DbaCallGuard dbaCallGuard(dbiConnHelper); /* PMSTA-45413 - LJE - 210804 */

    DBI_INT         status = 0;
	int             cpt = 0, i = 0;
    DBI_INT         resultType = 0;
	RET_CODE        finalResult = RET_SUCCEED,
                    retCode = RET_SUCCEED;
	char			udFlg = 0;
    FLAG_T          internalProcedureFlg = FALSE; /* PMSTA-35191 - JPR - 190319 */
	FLAG_T          localTranFlg = FALSE,       /* DVP483 */
                    localEventFlg = FALSE,      /* REF4204 */
                    localAuditFlg = FALSE;      /* REF4204 */
	DBA_DYNFLD_STP	*outSubscriptionTab = NULL, /* REF4204 */
					inSubscriptionSt = NULL,    /* REF4204 */
                    inAuditData = NULL;         /* REF4204 */
	int             outSubscriptionNbr = 0;	    /* REF4204 */
    int             fatalError = FALSE;

   	DBA_PROC_STP procedure = DBA_GetStoredProcs(Update, object, role, inputSt, inputData, NullDynSt);

	/* If no procedure */
	if (procedure == NULL)
	{
		if ((dbiConnHelper.dbaGetOptions() & DBA_NO_PROC_ERROR) == 0) /* PMSTA-13946 - LJE - 120328 */
		{
		    char	objString[40];
            const char	*sqlName = DBA_GetDictEntitySqlName(object);
		    OBJECT_ENUM objEn;		    /* REF2697 - SSO - 000510 */
		    const char	    *entitySqlNameIn=NULL;  /* REF2697 - SSO - 000510 */
		    char	    entityStrIn[13];	    /* REF2697 - SSO - 000510 */

		    if (sqlName != NULL)
		    {
			    strcpy(objString, sqlName);
		    }
		    else
		    {
			    sprintf(objString, "unknown(" szFormatObj ")",object);/* REF2697 - SSO - 000510 */
		    }

            DBA_GetObjectEnumByDynSt(inputSt, &objEn);  /* REF2697 - SSO - 000510 */
		    entitySqlNameIn = DBA_GetDictEntitySqlName(objEn);

	        if (entitySqlNameIn == NULL)
	        {
			    entitySqlNameIn = DBA_GetDynStCName(inputSt);
		    }
		    if (entitySqlNameIn == NULL)
		    {
		        sprintf(entityStrIn,"unknown(%d)",inputSt);
		        entitySqlNameIn = entityStrIn;
		    }

            DBA_LogMesgProcedureNotFound(Update, object, role, inputSt, inputData, NullDynSt, false, "Update", objString, entitySqlNameIn, "none");  /* PMSTA-24985 - 111016 - PMO */
		}
		return(RET_DBA_ERR_PROCNOTFOUND);
	}
    dbiConnHelper.setCurrProcedure(procedure);  /* PMSTA-45413 - LJE - 210804 */

    /* PMSTA-35191 - JPR - 190319 */
    if (procedure->server == InternalProc)
    {
        internalProcedureFlg = TRUE;
    }
    else
    {
        /* PMSTA-46681 - LJE - 231106 */
        if (dbiConnHelper.isDbaAccess(Update))
        {
            return DBA_UpdXdObject(object, inputData->getDynStEn(), inputData, dbiConnHelper);
        }

        if ((dbiConnHelper.isHttp()) &&
            (dbiConnHelper.isBlockMode() == false))
        {
            return DBA_CallHttp(dbiConnHelper,
                                Update,
                                object,
                                role,
                                inputSt,
                                inputData);
        }

        internalProcedureFlg = FALSE;
    }

    if (dbiConnHelper.isValidAndInit() == false)
    {
        return(RET_DBA_ERR_CONNOTFOUND);
    }

    DbiConnection& dbiConn = *dbiConnHelper.getConnection();

    dbiConn.setReadOnly(procedure); /* PMSTA-29027 - LJE - 190111 */

    /* REF8623 - TEB - 030813 - Begin */
    /* Open a transaction if we have some customers data */
	if ((finalResult == RET_SUCCEED &&
        inputSt == GET_EDITGUIST(object) &&  /* PMSTA-18469 - DDV - 141001 - Update ud fields only when input structure is the A_ entity's structure */
	    role != DBA_ROLE_UPD_UD_FIELDS &&
        role != DBA_ROLE_EXECUTIONS_SKIP_UPD_UD_FIELDS &&
        role != DBA_ROLE_PTFSYNTH_ALL && /* REF9359 - DDV - 030917 */
        role != DBA_ROLE_PERF_ATTRIB_RA && /* REF9359 - DDV - 030917 */
        status >= 0 &&
		DBA_GetCustFldNbr(object) > 1) || dbiConn.isDbTransactionRequired() )
	{
		if (dbiConn.isInTransaction() == false &&  /* DLA - REF9468 - 030915 */
            procedure->server == SqlServer)        /* PMSTA-45413 - LJE - 210729 - Do not create transaction for internal proc. */
		{
            dbiConn.beginTransaction();
            localTranFlg = TRUE;
		}
    }
    /* REF8623 - TEB - 030813 - End */

	/* DLA - PMSTA09887 - 110303 */
    DBA_TruncateDynStStringToMDLength(inputData);

	/*
	 * Is there any valid subscription for this entity?
	 */
    DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(object);

	if ((procedure == NULL || (procedure->procMask & PROCMASK_DISABLE_SUBSCRIPTION) != PROCMASK_DISABLE_SUBSCRIPTION) &&  /* DLA - REF10507 - 041210 / REF10845 - 050118 - PMO */
        (role != DBA_ROLE_UPD_UD_FIELDS) &&
        ((DBA_IsSubscriptionActive(object) == TRUE) && /* PMSTA15199 - DDV - 121128 - Replace DBA_IsTrustedObject by DBA_IsSubscriptionActive */
        (role != DBA_ROLE_UPDSTATUS_NOSUBSCRIPTION) &&
        (procedure->server != InternalProc) && (EV_IsSubscriptionActive == TRUE) &&
		(object != EOp) && (dbiConn.getConnStructPtr()->blockMode == FALSE) &&
        ((dbiConnHelper.dbaGetOptions() & DBA_NO_SUBS_AUDIT) !=  DBA_NO_SUBS_AUDIT ) && /* DLA - PMSTA06808 - 081114 */
        dictEntityStp != nullptr))
	{
		if ((inSubscriptionSt = ALLOC_DYNST(A_Subscription)) == NULL)
		{
    		MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		SET_DICT(inSubscriptionSt, A_Subscription_EntityDictId, dictEntityStp->entDictId);
		SET_ENUM(inSubscriptionSt, A_Subscription_ActionEn, Subscription_Action_Update);
		SET_ENUM(inSubscriptionSt, A_Subscription_ModuleEn, dbiConn.getSubscriptionModuleEn());

        /* Is there any subscription for this entity. */
		DBA_Select2(Subscription,
                    DBA_ROLE_SEL_SUBSCRIPTIONS,
                    A_Subscription,
                    inSubscriptionSt,
                    A_Subscription,
                    &outSubscriptionTab,
                    DBA_SET_CONN | DBA_NO_CLOSE,
                    UNUSED,
                    &outSubscriptionNbr,
                    dbiConn);

		FREE_DYNST(inSubscriptionSt, A_Subscription);

		/*
		 * Verify if there are entities to be audited.
		 * If so, we have to load and keep the current DYNFLDST from database
		 * BEFORE modifying it.
		 */

        i = 0;
		if (i<outSubscriptionNbr)
		{
            localEventFlg = TRUE;
            localAuditFlg = TRUE;
	        /*
	         * Get the old value for the given entity.
	         * REF4204 - GRD - 000323. (Audit purpose).
             * DLA - REF10731 - 050701 Always get the old value for OLD keyword
	         */
            if ((retCode = DBA_GetOldDataForAudit(object, inputSt, inputData, dbiConn, FALSE)) != RET_SUCCEED)
            {
			    if (localTranFlg == TRUE)			/* REF4204 */
			    {
					dbiConn.endTransaction(FALSE);
			    }
			    DBA_FreeDynStTab(outSubscriptionTab, outSubscriptionNbr, A_Subscription);
			    MSG_RETURN(retCode);
		    }
            inAuditData = dbiConn.getConnStructPtr()->subscriptionElem.auditRecStp;
            dbiConn.getConnStructPtr()->subscriptionElem.auditRecStp = NULL;
		}
	}

	/*
	 * Some entity attributes could contain fields of type TextType, this is why we MUST be sure
	 * that a transaction is opened to allow data integrity.
	 * Same if we have subscriptions to insert.
	 * REF4204.
	 */

    if (localEventFlg == TRUE)
	{
        if (dbiConn.isInTransaction() == false) /* DLA - REF9468 - 030915 */
		{
			dbiConn.beginTransaction();
            localTranFlg = TRUE;
		}
	}

    if(SYS_IsGuiMode() == TRUE)
    {
        EV_GuiCheckOptiStatus = NoCheck_GuiOptiStatus;
    }

	char tranCount = dbiConn.m_transactCpt;   /* BUG186 */

    SCPT_AUTOCREATE_HEADER_STP autocreateHeader = SCPT_GetAutocreateHeader();

	/**** BEGIN DVP483  ****/
    if ((retCode == RET_SUCCEED) &&     /*  HFI-PMSTA-14997-120914  */
        DictSprocClass::isRoleBatchAllowed(role) &&
        (autocreateHeader != nullptr && autocreateHeader->asgnRecCount > 0))
	{
		if (!((dbiConnHelper.dbaGetOptions() & DBA_NO_MAIN_LEVEL) == DBA_NO_MAIN_LEVEL))
		{
            if (dbiConn.isInTransaction() == false)
			{
				dbiConn.beginTransaction();
				localTranFlg = TRUE;
			}

			retCode = DBA_HandleAutocreateStack(inputData, dbiConn, FALSE, internalProcedureFlg); /* PMSTA-35191 - JPR - 190319 */

			if (retCode != RET_SUCCEED)
			{
				if (localTranFlg == TRUE)
				{
					dbiConn.endTransaction(FALSE);
				}
                DBA_RestoreAutocreateContext(inputData, inputSt); /* REF9112 - LJE - 030516 */
				DBA_FreeDynStTab(outSubscriptionTab, outSubscriptionNbr, A_Subscription);

                if (localAuditFlg == TRUE)
                {
                    FREE_DYNST(inAuditData, GET_EDITGUIST(object));
                }

				return(retCode);
			}
		}
	}

	/* If Procedure is an internal proc, call a C function, not a stored procedure */
	if (internalProcedureFlg == TRUE)
	{
		do
		{
			cpt++;

			retCode = procedure->fctDefSt.updFct(object, inputSt, inputData, dbiConnHelper);

			if (retCode == RET_SRV_LIB_ERR_DEADLOCK && tranCount == (char)0 &&
				SYS_GetEnv("AAASHOWDEADLOCK") == NULL)
			{
				switch (cpt)
				{
				case 1:
					SYS_MilliSleep(1000); /* PMSTA-20159 - TEB - 150624  */
					break;

				case 2:
					SYS_MilliSleep(2000); /* PMSTA-20159 - TEB - 150624  */
					break;

				case 3:
					SYS_MilliSleep(5000); /* PMSTA-20159 - TEB - 150624  */
					break;
				}

				dbiConn.m_transactCpt = 0;
			}
		}
		while (retCode   == RET_SRV_LIB_ERR_DEADLOCK &&
			    tranCount == (char)0                  &&
			    cpt<ITER_NBR_FOR_DEADLOCK &&
			    SYS_GetEnv("AAASHOWDEADLOCK") == NULL);

		/* If deadlock still occurs after 3 tries and if we are in the main transaction */
		if (retCode == RET_SRV_LIB_ERR_DEADLOCK && tranCount == (char)0)
		{
			MSG_SendMesg(RET_SRV_LIB_ERR_DEADLOCK, 1, FILEINFO, procedure->procName);
		}

		/*< PMSTA-10271 - LJE - 100723 */
        if ((retCode == RET_SUCCEED) &&     /*  HFI-PMSTA-14997-120914  */
            DictSprocClass::isRoleBatchAllowed(role) &&
            (autocreateHeader != nullptr && autocreateHeader->asgnRecCount > 0))
		{
			if (!((dbiConnHelper.dbaGetOptions() & DBA_NO_MAIN_LEVEL) == DBA_NO_MAIN_LEVEL))
			{
                if (dbiConn.isInTransaction() == false) /* DLA - REF9468 - 030915 */
				{
					dbiConn.beginTransaction();
					localTranFlg = TRUE;
				}

				retCode = DBA_HandleAutocreateStack(inputData, dbiConn, TRUE, internalProcedureFlg); /* PMSTA-35191 - JPR - 190319 */

				if (retCode != RET_SUCCEED)
				{
					if (localTranFlg == TRUE)
					{
						dbiConn.endTransaction(FALSE);
					}
					DBA_RestoreAutocreateContext(inputData, inputSt);
					DBA_FreeDynStTab(outSubscriptionTab, outSubscriptionNbr, A_Subscription);

					return(retCode);
				}
			}
		}
		/* PMSTA-10271 - LJE - 100723 >*/

		if (localTranFlg == TRUE)
		{
			dbiConn.endTransaction(retCode == RET_SUCCEED ? 1 : 0);
		}
		/**** END  DVP483  ****/

        if (retCode == RET_SUCCEED && /* DLA  - PMSTA-22833 - 170122 */
            SYS_IsGuiMode() == TRUE && !((dbiConnHelper.dbaGetOptions() & DBA_NO_MAIN_LEVEL) == DBA_NO_MAIN_LEVEL) &&
            (dbiConn.isInTransaction() == false))
		{
            DBA_ForceVerifOptiTab(&dbiConnHelper);
		}

        if (localAuditFlg == TRUE)
        {
            FREE_DYNST(inAuditData, GET_EDITGUIST(object));
        }

        if (retCode != RET_SUCCEED)
        {
            DBA_RestoreAutocreateContext(inputData, inputSt); /* REF9112 - LJE - 030516 */
        }

		return(retCode);
	}
	/**** END DVP029+ ****/

	if (role == DBA_ROLE_UPD_UD_FIELDS)
	{
		udFlg = 1;
	}
	else
	{
		udFlg = 0;
	}

	do
	{
		cpt++;

        if (USE_NEW_ACCESS_API(dbiConnHelper.getConnection()))
        {
            RequestHelper requestHelper(dbiConnHelper);
            if (requestHelper.startProcedureCall(procedure, inputData) == false)
            {
                /* PMSTA-42605 - DDV - 201202 - If local transaction is used, do a rollback */
                if (localTranFlg == TRUE)
                {
                    dbiConn.endTransaction(FALSE);
                }
                return(requestHelper.getLastResultRetCode());
            }
        }
        else
        {

            /* Retrieve and memorize parameters names and types in the meta dictionary tables */
            if (procedure->procParamDefPtr != UNUSED && false == DBA_IsInOutStoredProc(procedure))             /* PMSTA-24207 - 020816 - PMO */  /* PMSTA-24434 - TEB - 160923 */
            {
                if (DBI_SetProcParameters(dbiConn, inputSt, inputData, procedure) != RET_SUCCEED)
                {
                    if (localTranFlg == TRUE)
                    {
                        dbiConn.endTransaction(FALSE);
                    }
                    DBA_RestoreAutocreateContext(inputData, inputSt); /* REF9112 - LJE - 030516 */
                    DBA_FreeDynStTab(outSubscriptionTab, outSubscriptionNbr, A_Subscription);

                    if (localAuditFlg == TRUE)
                    {
                        FREE_DYNST(inAuditData, GET_EDITGUIST(object));
                    }

                    MSG_RETURN(RET_DBA_ERR_SETPARAM);
                }
            }
            else
            {
                if (DBI_SetProcParameters(dbiConn, inputSt, inputData, procedure, object, udFlg) != TRUE)	/* REF2644 */
                {
                    if (localTranFlg == TRUE)
                    {
                        dbiConn.endTransaction(FALSE);
                    }
                    dbiConn.releaseCommand();
                    DBA_RestoreAutocreateContext(inputData, inputSt); /* REF9112 - LJE - 030516 */
                    DBA_FreeDynStTab(outSubscriptionTab, outSubscriptionNbr, A_Subscription);

                    if (localAuditFlg == TRUE)
                    {
                        FREE_DYNST(inAuditData, GET_EDITGUIST(object));
                    }

                    MSG_RETURN(RET_DBA_ERR_SETPARAM);
                }
            }

            /* Send the update request to the server */
            if (dbiConn.sendRequest(&resultType) != RET_SUCCEED)
            {
                dbiConn.cancelDbRequest(COMMAND_LEVEL, CANCEL_ALL);
                dbiConn.cancelDbRequest(COMMAND_LEVEL, CANCEL_ALL);

                if (localTranFlg == TRUE)
                {
                    dbiConn.endTransaction(FALSE);
                }

                dbiConn.releaseCommand();
                DBA_RestoreAutocreateContext(inputData, inputSt); /* REF9112 - LJE - 030516 */
                DBA_FreeDynStTab(outSubscriptionTab, outSubscriptionNbr, A_Subscription);

                if (localAuditFlg == TRUE)
                {
                    FREE_DYNST(inAuditData, GET_EDITGUIST(object));
                }

                /* PMSTA-18593 - LJE - 150617 */
                if (dbiConn.emptyMsg() == false)
                {
                    dbiConn.sendAllMsg();
                    return dbiConn.m_lastResultRetCode;
                }
                else
                {
                    MSG_RETURN(RET_DBA_ERR_DBPROBLEM);
                }
            }

            /* Check if the insert has returned a block of datas (id and timestamp field) */
            if (DBI_ROW_RESULT == resultType && RET_SUCCEED == retCode) /* REF11780 - 100406 - PMO */
            { /* Yes */
                fatalError = DBA_ReadSqlBlockResult(dbiConn, inputSt, inputData);
            }

            /*** Temporary allow a resultType equal to DBI_CMD_SUCCEED **/
            /* REF11780 - 100406 - PMO */
            switch (resultType)
            {
                case DBI_STATUS_RESULT:
                case DBI_CMD_SUCCEED:
                case DBI_ROW_RESULT:
                    break;

                default:
                    fatalError = TRUE;
                    break;
            }

            if (TRUE == fatalError)  /* REF11780 - 100406 - PMO */
            {
                dbiConn.releaseCommand();

                if (localTranFlg == TRUE)
                {
                    dbiConn.endTransaction(FALSE);
                }
                DBA_RestoreAutocreateContext(inputData, inputSt); /* REF9112 - LJE - 030516 */
                DBA_FreeDynStTab(outSubscriptionTab, outSubscriptionNbr, A_Subscription);

                if (localAuditFlg == TRUE)
                {
                    FREE_DYNST(inAuditData, GET_EDITGUIST(object));
                }

                MSG_RETURN(RET_DBA_ERR_DBPROBLEM);
            }

            dbiConn.processAllResults(&status, object, inputSt, inputData, procedure); /* PMSTA08801 - DDV - 091211 - Add new parameters to read output parameters */
            /* Call to function which will filter received messages during insert operation */
            dbiConn.filterMsgInfos(&finalResult);
        }

		/**** DVP178+ - 16.10.1996 ****/
		if (finalResult == RET_SRV_LIB_ERR_DEADLOCK && tranCount == (char)0 &&
		    SYS_GetEnv("AAASHOWDEADLOCK") == NULL)
		{
			switch (cpt)
			{
			case 1:
				/* DBA_SqlExec("waitfor delay \"0:00:01\"", *dbiConn); */
				SYS_MilliSleep(1000); /* PMSTA-20159 - TEB - 150624  */
				break;
			case 2:
				/* DBA_SqlExec("waitfor delay \"0:00:02\"", *dbiConn); */
				SYS_MilliSleep(2000); /* PMSTA-20159 - TEB - 150624  */
				break;
			case 3:
				/* DBA_SqlExec("waitfor delay \"0:00:05\"", *dbiConn); */
				SYS_MilliSleep(5000); /* PMSTA-20159 - TEB - 150624  */
				break;
			}

			dbiConn.m_transactCpt = 0;
		}
		/**** DVP178+ - 16.10.1996 ****/
	}
	while (finalResult == RET_SRV_LIB_ERR_DEADLOCK &&
	       tranCount   == (char)0                  &&
	       cpt<ITER_NBR_FOR_DEADLOCK &&
	       SYS_GetEnv("AAASHOWDEADLOCK") == NULL);                                       /* BUG186 */
	/*** END  DVP178 ***/

	/*** BEGIN DVP178+ ***/
	/* If deadlock still occurs after 3 tries */
	if (finalResult == RET_SRV_LIB_ERR_DEADLOCK && tranCount == (char)0)   /* BUG186 */
	{
		MSG_SendMesg(RET_SRV_LIB_ERR_DEADLOCK, 1, FILEINFO, procedure->procName);
		dbiConn.releaseCommand();

		if (localTranFlg == TRUE)
		{
			     dbiConn.endTransaction(FALSE);
		}
        DBA_RestoreAutocreateContext(inputData, inputSt); /* REF9112 - LJE - 030516 */
		DBA_FreeDynStTab(outSubscriptionTab, outSubscriptionNbr, A_Subscription);

        if (localAuditFlg == TRUE)
        {
            FREE_DYNST(inAuditData, GET_EDITGUIST(object));
        }

		return(RET_SRV_LIB_ERR_DEADLOCK);
	}
	/*** END   DVP178+ ***/

	/*** BEGIN REF1081. ***/
	if (finalResult == RET_SRV_LIB_ERR_DB_OVERFLOW)
	{
        /* REF8844 - LJE - 030415 */
		if (object == EPos)
        {

			MSG_SendMesg(RET_SRV_LIB_ERR_DB_OVERFLOW, 1, FILEINFO,
					 "updating ExtPos",
					 GET_CODE(inputData, ExtPos_OpenOpCd),
					 GET_ID(inputData  , ExtPos_PtfId),
					 GET_ENUM(inputData, ExtPos_NatEn));

        }
        else if (object == EOp)
        {

			MSG_SendMesg(RET_SRV_LIB_ERR_DB_OVERFLOW, 1, FILEINFO,
					 "updating ExtOp",
					 GET_CODE(inputData, ExtOp_Cd),
					 GET_ID(inputData  , ExtOp_PtfId),
					 GET_ENUM(inputData, ExtOp_NatureEn));

        }
        else if (object == Pos)
        {

			MSG_SendMesg(RET_SRV_LIB_ERR_DB_OVERFLOW, 1, FILEINFO,
					 "updating Position",
					 GET_CODE(inputData, A_Pos_OpenOpCd),
					 GET_ID(inputData  , A_Pos_PtfId),
					 GET_ENUM(inputData, A_Pos_OpenOpNatEn));

        }
        else if (object == BalPos)
        {

			MSG_SendMesg(RET_SRV_LIB_ERR_DB_OVERFLOW, 1, FILEINFO,
					 "updating BalPos",
					 GET_CODE(inputData, A_BalPos_OpenOpCd),
					 GET_ID(inputData  , A_BalPos_PtfId),
					 GET_ENUM(inputData, A_BalPos_OpenOpNatEn));

        }
	}
	/*** END REF1081. ***/

	/* REF7291 - LJE - 020411 : BEGIN */
    if ((retCode == RET_SUCCEED) &&     /*  HFI-PMSTA-14997-120914  */
        DictSprocClass::isRoleBatchAllowed(role) &&
        (autocreateHeader != nullptr && autocreateHeader->asgnRecCount > 0))
	{
		if (!((dbiConnHelper.dbaGetOptions() & DBA_NO_MAIN_LEVEL) == DBA_NO_MAIN_LEVEL))
		{
            if (dbiConn.isInTransaction() == false) /* DLA - REF9468 - 030915 */
			{
				dbiConn.beginTransaction();
				localTranFlg = TRUE;
			}

			retCode = DBA_HandleAutocreateStack(inputData, dbiConn, TRUE, internalProcedureFlg); /* PMSTA-35191 - JPR - 190319 */

			if (retCode != RET_SUCCEED)
			{
				if (localTranFlg == TRUE)
				{
					     dbiConn.endTransaction(FALSE);
				}
                DBA_RestoreAutocreateContext(inputData, inputSt); /* REF9112 - LJE - 030516 */
				DBA_FreeDynStTab(outSubscriptionTab, outSubscriptionNbr, A_Subscription);

				return(retCode);
			}
		}
	}
	/* REF7291 - LJE - 020411 : END */

	if (finalResult == RET_SUCCEED &&                       /* REF8623 - TEB - 030813 */
        inputSt == GET_EDITGUIST(object) &&  /* PMSTA-18469 - DDV - 141001 - Update ud fields only when input structure is the A_ entity's structure */
	    (role != DBA_ROLE_UPD_UD_FIELDS) &&
        (role != DBA_ROLE_EXECUTIONS_SKIP_UPD_UD_FIELDS) && /* PMO - REF8116 - 021023 */
        (role != DBA_ROLE_PTFSYNTH_ALL) && /* REF9359 - DDV - 030917 */
        (role != DBA_ROLE_PERF_ATTRIB_RA) && /* REF9359 - DDV - 030917 */
        (role != DBA_ROLE_GUI_CONTEXT) &&  /* DLA - SUPPORT-7386 - 161223 */
        status >= 0 &&
        DBA_GetCustFldNbr(object) > 1) /* DLA - REF 7560 - 020612 */
	{
        const int idIdx = (procedure->remapIdIdxPtr != nullptr ? *(procedure->remapIdIdxPtr) : 0);
        const int udIdIdx = DBA_GetFirstCustFld(object);
        SET_ID(inputData, udIdIdx, GET_ID(inputData, idIdx));

        if ((finalResult = DBA_Update2(object,
                                       DBA_ROLE_UPD_UD_FIELDS,
                                       inputSt,
                                       inputData,
                                       DBA_SET_CONN | DBA_NO_CLOSE | DBA_NO_MAIN_LEVEL,
                                       dbiConn)) != RET_SUCCEED)
        {
            MSG_FillMsgStruct(dbiConnHelper.getNewErrMsgInfoStp(FILEINFO),
                              RET_SRV_LIB_ERR_TRIGGER_MSG,
                              "Error occurring while updating UDFields",
                              ServerHandler, /* REF7264 - PMO */
                              RET_LEV_BUSINESS_ERROR,
                              FALSE,
                              NULL,
                              NULL,
                              0);
        }
	}


	switch(finalResult)
	{
	case RET_SUCCEED:
		/*
		 	* Update was successful, verify if events have to be raised for this Entity.
		 	* REF4204 - 000207 - GRD.
		 	*/

		if (localEventFlg == TRUE)
		{
			finalResult = DBA_LogSubscriptionEvents(object,         /* REF5037 */
						                            Subscription_Action_Update,
						                            inputSt,
						                            inputData,
                                                    (localAuditFlg == TRUE) ? inAuditData : NULL,
													dbiConn,
						                            outSubscriptionTab,
						                            outSubscriptionNbr);
		}

		if (localTranFlg == TRUE)        /* COMMIT/ROLLBACK transaction */
		{
			dbiConn.endTransaction(finalResult == RET_SUCCEED ? TRUE : FALSE);
		}
		break;

	default:
		if (localTranFlg == TRUE)
		{
			dbiConn.endTransaction(FALSE);

		}
		break;
	}

	DBA_FreeDynStTab(outSubscriptionTab, outSubscriptionNbr, A_Subscription);
	dbiConn.releaseCommand();
    if (localAuditFlg == TRUE)
    {
        FREE_DYNST(inAuditData, GET_EDITGUIST(object));
    }

    if (retCode == RET_SUCCEED && /* DLA  - PMSTA-22833 - 170122 */
        finalResult == RET_SUCCEED &&   /* DLA  - PMSTA-22833 - 170215 */
        SYS_IsGuiMode() == TRUE && !((dbiConnHelper.dbaGetOptions() & DBA_NO_MAIN_LEVEL) == DBA_NO_MAIN_LEVEL) &&
        (dbiConn.isInTransaction() == false) &&
        role != DBA_ROLE_SET_APPL_SESSION &&
        role != DBA_ROLE_MANAGE_APPL_SESSION)
	{
        DBA_ForceVerifOptiTab(&dbiConnHelper);
	}

	if (finalResult != RET_SUCCEED)
	{
        DBA_RestoreAutocreateContext(inputData, inputSt); /* REF9112 - LJE - 030516 */

		return(finalResult);
	}

	return(RET_SUCCEED);
}

/************************************************************************
*   Function             : DBA_Delete2()
*
*   Description          : Send a DELETE request to the server and retrieve
*                          returned status
*
*   Arguments            : object       : the request corresponding object
*                          inputSt      : the input dynamic struct. format
*                          inputData    : the pointer on the input dynamic struct.
*                          delOptions   : can be DBA_SET_CONN, DBA_NO_CLOSE
*                          allocConn    : 1. pointer which will contain the connectNo
*                                            used for the request if delOptions is
*                                            DBA_NO_CLOSE.
*                                         2. pointer which contain a connection number
*                                            if delOptions is DBA_SET_CONN.
*                          msgStructPtr : pointer on a structure which will contain
*                                         recieved messages informations.
*
*   Functions call       : DBA_GetConnection
*                          DBA_GetStoredProcs
*                          DBI_SetProcParameters
*                          DBA_EndConnection
*
*   Return               : RET_SUCCEED              : if no problem was detected
*                          RET_DBA_ERR_ARGNOMATCH   : if input arg. problem
*                          RET_DBA_ERR_PROCNOTFOUND : if no procedure founded
*                          RET_DBA_ERR_SETPARAM     : if problem while setting proc. parameters
*                          RET_DBA_ERR_CONNOTFOUND  : if no connection founded
*                          RET_DBA_ERR_DBPROBLEM    : if DB/connection problem
*                          RET_DBA_ERR_SYBBIND      : if poblem while binding received fields
*                          RET_MEM_ERR_ALLOC        : if allocation failed
*                          RET_DBA_ERR_READ_DATA    : if problem while reading received data
*                          RET_GEN_ERR_INVARG       : if problem while setting function params.
*                          a RET_CODE               : if a message has been received
*
*   Last Modification    : 19.12.95 - PEC - Added arguments delOptions, allocConn
*                                           msgStructPtr and suppressed argument
*                                           deleteStatus.
*                                           Function now return a RET_CODE.
*                          26.08.96 - PEC - Ref.: DVP178  -> Deadlock handling
*                          11.09.96 - PEC - Ref.: DVP202  -> Test InternalProc
*                          18.09.96 - PEC - Ref.: DVP178+ -> Deadlock handling
*                          16.10.96 - PEC - Ref.: DVP178+ -> Deadlock handling : waitfor delay 00:00:0x
*                          25.02.98 - GRD - Ref.: REF1081
*                          07.02.00 - GRD - Ref.: REF4204. Subscription.
*                          23.03.01 - GRD - Ref.: REF5844.
*                          09.04.01 - GRD - Ref.: REF5037.
*                          REF7264 - 0201225 - PMO : Compilation errors and warnings with C++ compiler
*                          REF8500 - 040510 - PMO : Add a draft_order_id in extended operation to distinguish the id from extended orders and the one from extended operation
*************************************************************************/
RET_CODE DBA_Delete2(OBJECT_ENUM          object,
    int                  role,
    DBA_DYNST_ENUM       inputSt,
    DBA_DYNFLD_STP       inputData,
    int                  delOptions,
    int                  *allocConn,
    DBA_ERRMSG_INFOS_STP msgStructPtr)
{
    DbiConnection * dbiConn = nullptr;
    RET_CODE        retCode = RET_SUCCEED;

    /* If no connection number is given */
    if ((delOptions & DBA_SET_CONN) != DBA_SET_CONN)
    {
        /* Get a free connection */
        if ((dbiConn = DBA_GetDbiConnection(SqlServer)) == nullptr)
        {
            MSG_RETURN(RET_DBA_ERR_CONNOTFOUND);
        }
    }
    else
    {
        /* If a connection number is given */
        if (allocConn != NULL) /* FPL-PMSTA06305-080508 */
        {
            dbiConn = DBA_GetDbiConnFromConnectNo(*allocConn);
        }
        else
        {
            MSG_RETURN(RET_DBA_ERR_ARGNOMATCH);
        }
    }

    retCode = DBA_Delete2(object,
                          role,
                          inputSt,
                          inputData,
                          delOptions,
                          *dbiConn,
                          msgStructPtr);

    bool isInError = (retCode == RET_DBA_ERR_DIALOG);
    if (isInError)
    {
        dbiConn->setValidConnection(false);
    }
    if ((delOptions & DBA_NO_CLOSE) != DBA_NO_CLOSE)
    {
        DBA_EndConnection(&dbiConn, isInError);
    }
    return retCode;
}

RET_CODE DBA_Delete2(OBJECT_ENUM          object,
                     int                  role,
    	             DBA_DYNST_ENUM       inputSt,
	                 DBA_DYNFLD_STP       inputData,
                     int                  delOptions,
                     DbiConnection&       dbiConn,
                     DBA_ERRMSG_INFOS_STP msgStructPtr,
                     DBA_ERRMSG_HEADER_STP	dbaErrMsgHeaderStp)
{
    RET_CODE        ret;
    DbiConnectionHelper dbiConnHelper(&dbiConn, false);
    dbiConnHelper.dbaSetOptions(delOptions | DBA_SET_CONN | DBA_NO_CLOSE);

    ret=DBA_Delete2(object, role, inputSt, inputData, dbiConnHelper);

    dbiConn.sendAllMsg();

    /* PMSTA-49780- BSV- 040722 */
    //dbaErrMsgHeaderStp is default argument.Check for NULL before copying objects.
    if (dbaErrMsgHeaderStp != nullptr)
        dbaErrMsgHeaderStp->copyDbaErrMsgHeaderClassObject(*dbiConnHelper.dbaGetMsgStructHeader());

    return(ret);
}

RET_CODE DBA_Delete2(OBJECT_ENUM          object,
                     int                  role,
    	             DBA_DYNST_ENUM       inputSt,
	                 DBA_DYNFLD_STP       inputData,
                     DbiConnectionHelper& dbiConnHelper)
{
#ifdef AAAPROFILER
    ZoneScopedNS("DBA_Delete2", 5);
#endif

    DbaCallGuard dbaCallGuard(dbiConnHelper); /* PMSTA-45413 - LJE - 210804 */

    int             cpt = 0;
    DBI_INT         status, resultType;
    RET_CODE        retCode = RET_SUCCEED,       /* DLA - PMSTA-27088 - 170503 */
                    finalResult = RET_SUCCEED;   /* DLA - PMSTA-27088 - 170503 */
	char            tranCount=0;                /* BUG186  */
	DBA_DYNFLD_STP	*outSubscriptionTab = NULL, /* REF4204 */
					inSubscriptionSt = NULL,    /* REF4204 */
                    inAuditData = NULL;         /* REF4204 */
	int             outSubscriptionNbr = 0;     /* REF4204 */
	FLAG_T          localTranFlg = FALSE,       /* REF4204 */
                    localEventFlg = FALSE,      /* REF4204 */
                    localAuditFlg = FALSE;      /* REF4204 */

	/* Retrieve a procedure in the object procedures list */
	DBA_PROC_STP procedure = DBA_GetStoredProcs(Delete, object, role, inputSt, inputData, NullDynSt);

	/* If no procedure */
	if (procedure == NULL)
	{
		if ((dbiConnHelper.dbaGetOptions() & DBA_NO_PROC_ERROR) == 0) /* PMSTA-13946 - LJE - 120328 */
		{
		    char	     objString[40];
            const char	    *sqlName = DBA_GetDictEntitySqlName(object);
		    OBJECT_ENUM  objEn;		    /* REF2697 - SSO - 000510 */
		    const char	*entitySqlNameIn=NULL;  /* REF2697 - SSO - 000510 */
		    char	     entityStrIn[13];	    /* REF2697 - SSO - 000510 */

		    if (sqlName != NULL)
		    {
			    strcpy(objString, sqlName);
		    }
		    else
		    {
			    sprintf(objString, "unknown(" szFormatObj ")",object);/* REF2697 - SSO - 000510 */
		    }

            DBA_GetObjectEnumByDynSt(inputSt, &objEn);  /* REF2697 - SSO - 000510 */
		    entitySqlNameIn = DBA_GetDictEntitySqlName(objEn);

	        if (entitySqlNameIn == NULL)
	        {
			    entitySqlNameIn = DBA_GetDynStCName(inputSt);
		    }
		    if (entitySqlNameIn == NULL)
		    {
		        sprintf(entityStrIn,"unknown(%d)",inputSt);
		        entitySqlNameIn = entityStrIn;
		    }

            DBA_LogMesgProcedureNotFound(Delete, object, role, inputSt, inputData, NullDynSt, false, "Delete", objString, entitySqlNameIn, "none");  /* PMSTA-24985 - 111016 - PMO */
        }
		return(RET_DBA_ERR_PROCNOTFOUND);
	}
    dbiConnHelper.setCurrProcedure(procedure);  /* PMSTA-45413 - LJE - 210804 */

    if (dbiConnHelper.isValidAndInit() == false)
    {
        return(RET_DBA_ERR_CONNOTFOUND);
    }

    DbiConnection& dbiConn = *dbiConnHelper.getConnection();

    dbiConn.setReadOnly(procedure); /* PMSTA-29027 - LJE - 190111 */

    /* REF8623 - TEB - 030813 - Begin */
    /* Open a transaction if we have some customers data */
    /* or Oracle database*/
    /* PMSTA-18473 - DDV - 141001 - Don't open transaction when preparing data for MultiAccess */
    if ((dbiConn.getConnStructPtr()->blockMode == FALSE) &&
        (dbiConn.isDbTransactionRequired() ||
        DBA_GetCustFldNbr(object) > 1))
    {
        if (dbiConn.isInTransaction() == false &&
            procedure->server == SqlServer)        /* PMSTA-45413 - LJE - 210729 - Do not create transaction for internal proc. */
        {
            dbiConn.beginTransaction();
            localTranFlg = TRUE;
        }
    }

	/* DLA - PMSTA09887 - 110303 */
    DBA_TruncateDynStStringToMDLength(inputData);

	/*
	 * Is there any valid subscription for this entity?
     * DLA - REF10497 - 040726
	 */
  	if ((procedure == NULL || (procedure->procMask & PROCMASK_DISABLE_SUBSCRIPTION) != PROCMASK_DISABLE_SUBSCRIPTION) &&  /* DLA - REF10507 - 041210 / REF10845 - 050118 - PMO */
        (DBA_IsSubscriptionActive(object) == TRUE) && (procedure->server != InternalProc) && /* PMSTA15199 - DDV - 121128 - Replace DBA_IsTrustedObject by DBA_IsSubscriptionActive */
		(object != EOp) && (dbiConn.getConnStructPtr()->blockMode == FALSE) &&
        (DBA_GetDictEntitySt(object) != NULL) && (EV_IsSubscriptionActive == TRUE) &&
        ( role != DBA_ROLE_NO_SUBSCRIPTION ) && /* DLA - REF10497 - 040917 */
        ((dbiConnHelper.dbaGetOptions() & DBA_NO_SUBS_AUDIT) !=  DBA_NO_SUBS_AUDIT ) && /* DLA - PMSTA06808 - 081114 */
        ( role != DBA_ROLE_DEL_LIST_COMPO_BY_DT)) /* DLA - REF10459 - 060413 exeption for BuildListCompo*/
    {
	    if ((inSubscriptionSt = ALLOC_DYNST(A_Subscription)) == NULL)
	    {
		    MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }

	    SET_DICT(inSubscriptionSt, A_Subscription_EntityDictId,
    		    (DBA_GetDictEntityStSafe(object))->entDictId);
	    SET_ENUM(inSubscriptionSt, A_Subscription_ActionEn, Subscription_Action_Delete);
	    SET_ENUM(inSubscriptionSt, A_Subscription_ModuleEn, dbiConn.getSubscriptionModuleEn());

	    DBA_Select2(Subscription,
				    DBA_ROLE_SEL_SUBSCRIPTIONS,
				    A_Subscription,
				    inSubscriptionSt,
				    A_Subscription,
				    &outSubscriptionTab,
	                DBA_SET_CONN | DBA_NO_CLOSE,
				    UNUSED,
				    &outSubscriptionNbr,
				    dbiConn);

        FREE_DYNST(inSubscriptionSt, A_Subscription);

		/*
		 * Verify if there are entities to be audited.
		 * If so, we have to load and keep the current DYNFLDST from database
		 * BEFORE modifying it.
		 */
        if (outSubscriptionNbr > 0)
        {
            localEventFlg = TRUE;
		    if (dbiConn.isInTransaction() == false)
		    {
				dbiConn.beginTransaction();
                localTranFlg = TRUE;
                if(SYS_IsGuiMode() == TRUE)
                {
                    EV_GuiCheckOptiStatus = NoCheck_GuiOptiStatus;
                }
            }

            /*
             * In the case no audit has been requested, we should behave the same way
             * if a 'Delete' action is being requested for 'event'.
             * GRD - 010323 - REF5844.
             */
            localAuditFlg = TRUE;

	        /*
	         * Get the old value for the given entity.
	         * REF4204 - GRD - 000323. (Audit purpose).
	         */
            if ((retCode = DBA_GetOldDataForAudit(object, inputSt, inputData, dbiConn, FALSE)) != RET_SUCCEED)
            {
                if ( !((dbiConnHelper.dbaGetOptions() & DBA_NO_OLD_DATA_AUDIT) == DBA_NO_OLD_DATA_AUDIT && retCode == RET_GEN_INFO_NODATA )) /* DLA - REF9952 - 041021 */
                {
			        if (localTranFlg == TRUE)			/* REF4204 */
			        {
				         dbiConn.endTransaction(FALSE);
			        }
			        DBA_FreeDynStTab(outSubscriptionTab, outSubscriptionNbr, A_Subscription);

			        MSG_RETURN(retCode);
                }
		    }

            inAuditData = dbiConn.getConnStructPtr()->subscriptionElem.auditRecStp;
            dbiConn.getConnStructPtr()->subscriptionElem.auditRecStp = NULL;
        }
    }

	tranCount = dbiConn.m_transactCpt;   /* BUG186 */

	/**** BEGIN DVP202 ****/
	/* If Procedure is an internal proc, call a C function, not a stored procedure */
	if (procedure->server == InternalProc)
	{
		do
		{
			cpt++;

			retCode = procedure->fctDefSt.delFct(object, inputSt, inputData, dbiConnHelper);

			if (retCode == RET_SRV_LIB_ERR_DEADLOCK && tranCount == (char)0 &&
				SYS_GetEnv("AAASHOWDEADLOCK") == NULL) /* BUG186 */
			{
				switch (cpt)
				{
				case 1:
					/* DBA_SqlExec("waitfor delay \"0:00:01\"", *dbiConn); */
					SYS_MilliSleep(1000); /* PMSTA-20159 - TEB - 150624  */
					break;

				case 2:
					/* DBA_SqlExec("waitfor delay \"0:00:02\"", *dbiConn); */
					SYS_MilliSleep(2000); /* PMSTA-20159 - TEB - 150624  */
					break;

				case 3:
					/* DBA_SqlExec("waitfor delay \"0:00:05\"", *dbiConn); */
					SYS_MilliSleep(5000); /* PMSTA-20159 - TEB - 150624  */
					break;
				}

				dbiConn.m_transactCpt = 0; /* BUG186 */
			}
		}
		while (retCode   == RET_SRV_LIB_ERR_DEADLOCK &&
			    tranCount == (char)0                  &&  /* BUG186 */
			    cpt<ITER_NBR_FOR_DEADLOCK &&
			    SYS_GetEnv("AAASHOWDEADLOCK") == NULL);

		/* If deadlock still occurs after 3 tries and if we were in the main transaction */
		if (retCode == RET_SRV_LIB_ERR_DEADLOCK && tranCount == (char)0) /* BUG186 */
			MSG_SendMesg(RET_SRV_LIB_ERR_DEADLOCK, 1, FILEINFO, procedure->procName);

		/**** BEGIN DVP483  ****/
			    /*if ((retCode != RET_SUCCEED) && commented out SSO - 000315 , moved in DBA_EndTransaction param */
		if (localTranFlg == TRUE)
		{
			dbiConn.endTransaction (retCode == RET_SUCCEED ? 1 : 0);
		}

        if (retCode == RET_SUCCEED && /* DLA  - PMSTA-22833 - 170122 */
            (SYS_IsGuiMode() == TRUE) && (dbiConn.isInTransaction() == false))
		{
            DBA_ForceVerifOptiTab(&dbiConnHelper);
		}
        if (localAuditFlg == TRUE)
        {
            FREE_DYNST(inAuditData, GET_EDITGUIST(object));
        }

		return(retCode);
	}
	/**** END  DVP202 ****/

    /* PMSTA-46681 - LJE - 231106 */
    if (dbiConnHelper.isDbaAccess(Delete))
    {
        return DBA_DelXdObject(object, inputData->getDynStEn(), inputData, dbiConnHelper);
    }

    if ((dbiConnHelper.isHttp()) &&
        (dbiConnHelper.isBlockMode() == false))
    {
        return DBA_CallHttp(dbiConnHelper,
                            Delete,
                            object,
                            role,
                            inputSt,
                            inputData);
    }

	/*** BEGIN DVP178 ***/
	do
	{
		cpt++;

        if (USE_NEW_ACCESS_API(dbiConnHelper.getConnection()))
        {
            RequestHelper requestHelper(dbiConnHelper);
            if (requestHelper.startProcedureCall(procedure, inputData) == false)
            {
                /* PMSTA-42605 - DDV - 201202 - If local transaction is used, do a rollback */
                if (localTranFlg == TRUE)
                {
                    dbiConn.endTransaction(FALSE);
                }
                return(requestHelper.getLastResultRetCode());
            }
        }
        else
        {
            /* Retrieve and memorize parameters names and types in the meta dictionary tables */
            if (DBI_SetProcParameters(dbiConn, inputSt, inputData, procedure) != RET_SUCCEED)
            {
                if (localTranFlg == TRUE)
                {
                    dbiConn.endTransaction(FALSE);
                }
                dbiConn.releaseCommand();

                if (localAuditFlg == TRUE)
                {
                    FREE_DYNST(inAuditData, GET_EDITGUIST(object));
                }

                DBA_FreeDynStTab(outSubscriptionTab, outSubscriptionNbr, A_Subscription);

                MSG_RETURN(RET_DBA_ERR_SETPARAM);
            }

            /* Send the request to the server */
            if (dbiConn.sendRequest(&resultType) != RET_SUCCEED)
            {
                dbiConn.cancelDbRequest(COMMAND_LEVEL, CANCEL_ALL);
                dbiConn.cancelDbRequest(COMMAND_LEVEL, CANCEL_ALL);

                if (localTranFlg == TRUE)
                {
                    dbiConn.endTransaction(FALSE);
                }
                dbiConn.releaseCommand();

                if (localAuditFlg == TRUE)
                {
                    FREE_DYNST(inAuditData, GET_EDITGUIST(object));
                }

                DBA_FreeDynStTab(outSubscriptionTab, outSubscriptionNbr, A_Subscription);

                /* PMSTA-18593 - LJE - 150617 */
                if (dbiConnHelper.emptyMsg() == false)
                {
                    dbiConnHelper.sendAllMsg();
                    return RET_DBA_ERR_DBPROBLEM;
                }
                else
                {
                    MSG_RETURN(RET_DBA_ERR_DBPROBLEM);
                }
            }

            /*** Temporary allow a resultType equal to DBI_CMD_SUCCEED **/
            if (resultType != DBI_STATUS_RESULT && resultType != DBI_CMD_SUCCEED)
            {
                dbiConn.releaseCommand();
                if (localTranFlg == TRUE)
                {
                    dbiConn.endTransaction(FALSE);
                }

                if (localAuditFlg == TRUE)
                {
                    FREE_DYNST(inAuditData, GET_EDITGUIST(object));
                }

                DBA_FreeDynStTab(outSubscriptionTab, outSubscriptionNbr, A_Subscription);

                MSG_RETURN(RET_DBA_ERR_DBPROBLEM);
            }

            dbiConn.processAllResults(&status); /* PMSTA-23385 - LJE - 160630 */

            /* Call to function which will filter received messages during
               insert operation */
            dbiConn.filterMsgInfos(&finalResult);
        }

		/**** DVP178+ - 16.10.1996 ****/
		if (finalResult == RET_SRV_LIB_ERR_DEADLOCK && tranCount == (char)0 &&
		    SYS_GetEnv("AAASHOWDEADLOCK") == NULL)
		{
			switch (cpt)
			{
			case 1:
				/* DBA_SqlExec("waitfor delay \"0:00:01\"", *dbiConn); */
				SYS_MilliSleep(1000); /* PMSTA-20159 - TEB - 150624  */
				break;

			case 2:
				/* DBA_SqlExec("waitfor delay \"0:00:02\"", *dbiConn); */
				SYS_MilliSleep(2000); /* PMSTA-20159 - TEB - 150624  */
				break;
			case 3:
				/* DBA_SqlExec("waitfor delay \"0:00:05\"", *dbiConn); */
				SYS_MilliSleep(5000); /* PMSTA-20159 - TEB - 150624  */
				break;
			}

			dbiConn.m_transactCpt = 0; /* BUG186 */
		}
		/**** DVP178+ - 16.10.1996 ****/
	}
	while (finalResult == RET_SRV_LIB_ERR_DEADLOCK &&
	       tranCount   == (char)0                  &&    /* BUG186 */
	       cpt<ITER_NBR_FOR_DEADLOCK &&
	       SYS_GetEnv("AAASHOWDEADLOCK") == NULL);
	/*** END   DVP178 ***/

	/*** BEGIN DVP178+ ***/
	/* If deadlock still occurs after 3 tries */
	if (finalResult == RET_SRV_LIB_ERR_DEADLOCK && tranCount == (char)0) /* BUG186 */
	{
		MSG_SendMesg(RET_SRV_LIB_ERR_DEADLOCK, 1, FILEINFO, procedure->procName);
		dbiConn.releaseCommand();
		if (localTranFlg == TRUE)
		{
		     dbiConn.endTransaction(FALSE);
		}

        if (localAuditFlg == TRUE)
        {
            FREE_DYNST(inAuditData, GET_EDITGUIST(object));
        }

		DBA_FreeDynStTab(outSubscriptionTab, outSubscriptionNbr, A_Subscription);

		return(RET_SRV_LIB_ERR_DEADLOCK);
	}
	/*** END   DVP178+ ***/

	/*** BEGIN REF1081. ***/
	if (finalResult == RET_SRV_LIB_ERR_DB_OVERFLOW)
	{
        /* REF8844 - LJE - 030415 */
		if (object == EPos)
        {

			MSG_SendMesg(RET_SRV_LIB_ERR_DB_OVERFLOW, 1, FILEINFO,
					 "deleting ExtPos",
					 GET_CODE(inputData, ExtPos_OpenOpCd),
					 GET_ID(inputData  , ExtPos_PtfId),
					 GET_ENUM(inputData, ExtPos_NatEn));

        }
        else if (object == EOp)
        {

			MSG_SendMesg(RET_SRV_LIB_ERR_DB_OVERFLOW, 1, FILEINFO,
					 "deleting ExtOp",
					 GET_CODE(inputData, ExtOp_Cd),
					 GET_ID(inputData  , ExtOp_PtfId),
					 GET_ENUM(inputData, ExtOp_NatureEn));

        }
        else if (object == Pos)
        {

			MSG_SendMesg(RET_SRV_LIB_ERR_DB_OVERFLOW, 1, FILEINFO,
					 "deleting Position",
					 GET_CODE(inputData, A_Pos_OpenOpCd),
					 GET_ID(inputData  , A_Pos_PtfId),
					 GET_ENUM(inputData, A_Pos_OpenOpNatEn));

        }
        else if (object == BalPos)
        {

			MSG_SendMesg(RET_SRV_LIB_ERR_DB_OVERFLOW, 1, FILEINFO,
					 "deleting BalPos",
					 GET_CODE(inputData, A_BalPos_OpenOpCd),
					 GET_ID(inputData  , A_BalPos_PtfId),
					 GET_ENUM(inputData, A_BalPos_OpenOpNatEn));

        }
	}
    dbiConn.releaseCommand();
	/*** END REF1081. ***/
	if (finalResult == RET_SUCCEED)
	{
		/*
	 	 * Insert was successfull, verify if events has to be raised for this Entity.
	 	 * REF4204 - 000207 - GRD.
	 	 */

		if (localEventFlg == TRUE)
		{
			finalResult = DBA_LogSubscriptionEvents(object,             /* REF5037 */
					  				                Subscription_Action_Delete,
					  				                inputSt,
					  				                (localAuditFlg == TRUE) ? inAuditData : inputData, /* DLA - REF9441 - 030916 */
                                                    (localAuditFlg == TRUE) ? inAuditData : NULL,
													dbiConn,
					  				                outSubscriptionTab,
					  				                outSubscriptionNbr);
		}
	}

	/*  Check that the deleted object if part of a package composition          */  /*  HFI-PMSTA-41842-200916  */
	if ((finalResult == RET_SUCCEED) &&
        (role != DBA_ROLE_NO_SUBSCRIPTION))
	{
        DICT_ENTITY_STP     pdictent = DBA_GetDictEntitySt(object);
        if ((pdictent != nullptr) &&
            (pdictent->enIsPackage == DictEntityClass::IsPackageEn::Record) &&
            (pdictent->primKeyTab != nullptr) &&
            ((inputSt == GET_ADMINGUIST(object)) || (inputSt == GET_EDITGUIST(object))))
		{
            DBA_DYNFLD_STP  pdbadynShortPackCompo = ALLOC_DYNST(S_PackageComposition);
            SET_DICT(pdbadynShortPackCompo, S_PackageComposition_EntityDictId, pdictent->entDictId);
            if (inputSt == GET_ADMINGUIST(object))
            {
                COPY_DYNFLD(pdbadynShortPackCompo, S_PackageComposition, S_PackageComposition_ObjId, inputData, inputSt, pdictent->primKeyTab[0]->shortIdx);
            }
            else if (inputSt == GET_EDITGUIST(object))
            {
                COPY_DYNFLD(pdbadynShortPackCompo, S_PackageComposition, S_PackageComposition_ObjId, inputData, inputSt, pdictent->primKeyTab[0]->progN);
            }
            if ((IS_NULLFLD(pdbadynShortPackCompo, S_PackageComposition_ObjId) == FALSE) && 
                ((DBA_Check(PackageComposition,
                            UNUSED,
                            S_PackageComposition,
                            pdbadynShortPackCompo,
                            UNUSED,
							dbiConn,
                            UNUSED) != RET_SUCCEED) ||
                (GET_INT(pdbadynShortPackCompo, S_PackageComposition_ReturnStatus) < 0))) /* PMSTA-46404 - DDV - 211005 */
            {
                finalResult = RET_DBA_INFO_EXIST;
            }
            FREE_DYNST(pdbadynShortPackCompo, S_PackageComposition);
		}
	}

	if (localTranFlg == TRUE)        /* COMMIT transaction */
	{
		dbiConn.endTransaction (finalResult == RET_SUCCEED ? TRUE : FALSE);
	}

    if (localAuditFlg == TRUE)
    {
        FREE_DYNST(inAuditData, GET_EDITGUIST(object));
    }

    if (retCode == RET_SUCCEED && /* DLA  - PMSTA-22833 - 170122 */
        finalResult == RET_SUCCEED &&   /* DLA  - PMSTA-22833 - 170215 */
        (SYS_IsGuiMode() == TRUE) && (dbiConn.isInTransaction() == false))
	{
        DBA_ForceVerifOptiTab(&dbiConnHelper);
	}

	DBA_FreeDynStTab(outSubscriptionTab, outSubscriptionNbr, A_Subscription);

	if (finalResult != RET_SUCCEED)
	{
		return(finalResult);
	}

	if(EV_ExtractFile && EV_SetProcParametersFlg)
	{
		DATE_ResetTimer(EV_ExtractFileTimerPtr, TIMER_MASK_GEN);
		DATE_StartTimer(EV_ExtractFileTimerPtr, TIMER_MASK_GEN);
		EV_SetProcParametersFlg = FALSE;
	}

	return(RET_SUCCEED);
}


/************************************************************************
**
**  Function    :   DBA_CopyAddRecord
**
**  Description :   Add new record to the collection
**
**  Arguments   :   OBJECT_ENUM     enEntity    : Entity of the enw record
**                  ID_T            idFrom      : id of the copied record
**                  ID_T            idTo        : id of the new record
**                  DBA_DYNFLD_STP  pdbadyn     : Logical entity to copy
**
**  Return      :   RET_CODE
**
**  Creation    :   HFI-PMSTA-41842-200916
**
*************************************************************************/
RET_CODE DBA_CopyAddRecord (DBA_COPY_OBJ_STP **pcpobjtab, int *piNbObj, DICT_ENTITY_STP pdictent, ID_T idFrom, ID_T idTo, DBA_DYNFLD_STP pdbadyn)
{
    DBA_COPY_OBJ_STP pcopyobjNew;

    if (*piNbObj == 0)
    {
        *pcpobjtab = (DBA_COPY_OBJ_STP*) CALLOC(1 , sizeof(DBA_COPY_OBJ_STP));
    }
    else
    {
        *pcpobjtab = (DBA_COPY_OBJ_STP*) REALLOC(*pcpobjtab,((*piNbObj) + 1) * sizeof(DBA_COPY_OBJ_STP));
    }

    if (pcpobjtab == nullptr)
        MSG_RETURN(RET_MEM_ERR_ALLOC);
 
    pcopyobjNew = (DBA_COPY_OBJ_STP) CALLOC(1 , sizeof(DBA_COPY_OBJ_ST));
    pcopyobjNew->pdictent = pdictent;
    pcopyobjNew->idFrom = idFrom;
    pcopyobjNew->idTo = idTo;
    pcopyobjNew->pdbadyn = pdbadyn;

    (*pcpobjtab)[(*piNbObj)] = pcopyobjNew;
    (*piNbObj)++;

    return RET_SUCCEED;
}


/************************************************************************
**
**  Function    :   DBA_CheckCopyCascadeRights
**
**  Description :   Check if a copy if possible at entity level
**
**  Arguments   :   OBJECT_ENUM     enFromEntity    : From entity
**                  OBJECT_ENUM     enFromEntity    : To entity
**                  DICT_ENTITY_STP pdictentLogical : Logical entity to copy
**
**  Return      :   RET_CODE
**
**  Creation    :   HFI-PMSTA-41842-200916
**
*************************************************************************/
STATIC  FLAG_T DBA_CheckCopyCascadeRights (DICT_ENTITY_STP pdictentLogical, OBJECT_ENUM enFromEntity, OBJECT_ENUM enToEntity)
{
    FLAG_T  flagCheck = FALSE;

    /*  Check that the logical entity to copy has (or not) sub logical entities */
    int iNbLogicalToCopy = 0;
    for (auto subAttribItFrom = pdictentLogical->attr.begin(); subAttribItFrom != pdictentLogical->attr.end(); ++subAttribItFrom)
    {
        DICT_ATTRIB_STP pdictattrSubFrom = (*subAttribItFrom);
        if ((pdictattrSubFrom->logicalFlg == TRUE) &&
            (pdictattrSubFrom->copyRightEn == DictAttrCopyNat_Copy))
        {
            iNbLogicalToCopy++;
        }
    }

    /*  New copy mode : beginning with xd entities ... to be generalized    */
    if ((iNbLogicalToCopy != 0) &&
        (pdictentLogical->dbPKTab != nullptr) &&
        (pdictentLogical->dbPKNbr == 1) &&
        (pdictentLogical->parentAttrStp != nullptr) &&
        (enFromEntity == enToEntity))
    {
        switch (GET_OBJECT_CST(pdictentLogical->objectEn))
        {
            case XdEntityCst:
            case XdAttribCst:
            case XdPermValCst:
            case XdEntityFeatureCst:
            case XdLabelCst:
            case XdIndexCst:
                flagCheck = TRUE;
                break;
        }
    }
    return flagCheck;
}


/************************************************************************
**
**  Function    :   DBA_CopyObjectCheckRights
**
**  Description :   Copy logical attributes from an entity to another
**
**  Arguments   :   DICT_ENTITY_STP pdictent            : entity to be copied
**                  DBA_DYNFLD_STP  pdbadynShort        : object to copy
**                  FLAG_T          flagCompleteListCopy: TRUE complete list copy, FALSE individual copy
**
**  Return      :   RET_CODE
**
**  Creation    :   HFI-PMSTA-41842-200916
**
*************************************************************************/
FLAG_T DBA_CopyObjectCheckRights (DICT_ENTITY_STP pdictent, DBA_DYNFLD_STP pdbadynShort, FLAG_T flagCompleteListCopy)
{
    FLAG_T  flagCheck = TRUE;

    if (pdictent->objectEn == XdAttrib)
    {
        if (((IS_NULLFLD(pdbadynShort, S_XdAttrib_SqlName) == FALSE) &&
             ((strcmp("ud_id",GET_SYSNAME(pdbadynShort, S_XdAttrib_SqlName)) == 0) ||
              (strcmp("script_control",GET_SYSNAME(pdbadynShort, S_XdAttrib_SqlName)) == 0)) ||
              ((flagCompleteListCopy == FALSE) &&
               (strcmp("id",GET_SYSNAME(pdbadynShort, S_XdAttrib_SqlName)) == 0))) ||
            ((IS_NULLFLD(pdbadynShort, S_XdAttrib_PrecompFlg) == FALSE) &&
             (TRUE == GET_FLAG(pdbadynShort, S_XdAttrib_PrecompFlg))) ||
            ((IS_NULLFLD(pdbadynShort, S_XdAttrib_FeatureEn) == FALSE) &&
             (XdEntityFeatureFeatureEn::None != static_cast <XdEntityFeatureFeatureEn> (GET_ENUM(pdbadynShort, S_XdAttrib_FeatureEn)))))
        {
            flagCheck = FALSE;
        }
    }
    return flagCheck;
}


/************************************************************************
**
**  Function    :   DBA_CopyCascadeManageCrossRefOneRecord
**
**  Description :   manage cross reference between the newly copied records
**
**  Arguments   :   DBA_COPY_OBJ_STP**      pcopytab        : table of copied records to manage cross reference
**                  int*                    piNbObj         : size of the table
**                  DBA_DYNFLD_STP          pdbadyn         : record
**                  DICT_ENTITY_STP         pdictent        : Parent entity
**                  DbiConnectionHelper&    dbiConnHelper   : Connection structure
**
**  Return      :   RET_CODE
**
**  Creation    :   HFI-PMSTA-41842-200916 
**
*************************************************************************/
RET_CODE DBA_CopyCascadeManageCrossRefOneRecord (DBA_COPY_OBJ_STP *pcopytab, int iNbObj, DBA_DYNFLD_STP pdbadyn, DICT_ENTITY_STP pdictent, DbiConnectionHelper& dbiConnHelper)
{
    RET_CODE            retCode = RET_SUCCEED;

    if (pdictent == nullptr)
    {
        MSG_RETURN(RET_GEN_ERR_INVARG);
    }
    else
    {
        FLAG_T              *pflagEvalDV = nullptr;
        for (auto attribIt = pdictent->attr.begin(); attribIt != pdictent->attr.end() && retCode == RET_SUCCEED; ++attribIt)
        {
            DICT_ATTRIB_STP pdictattr = (*attribIt);

            if ((pdictattr->dataTpProgN == IdType) &&
                (pdictattr->refDictEntityStp != nullptr) &&
                (pdictattr->refDictEntityStp->dbPKTab != nullptr) &&
                (pdictattr->primFlg == FALSE) &&
                (pdictattr->logicalFlg == FALSE) &&
                (IS_NULLFLD(pdbadyn, pdictattr->progN) == FALSE))
            {
                ID_T    idFrom = GET_ID(pdbadyn, pdictattr->progN),
                        idTo = 0;
                for (int i = 0; (i < iNbObj) && (idTo == 0); i++)
                {
                    if ((pcopytab[i]->pdictent->entDictId == pdictattr->refDictEntityStp->entDictId) &&
                        (pcopytab[i]->idFrom == idFrom))
                    {
                        idTo = pcopytab[i]->idTo;
                    }
                }
                if (idTo != 0)
                {
                    SET_ID(pdbadyn, pdictattr->progN, idTo);
                    if (pflagEvalDV  == nullptr)
                    {
                        pflagEvalDV = (FLAG_T*) CALLOC(pdictent->attr.size(),sizeof(FLAG_T));
                    }
                    if (pflagEvalDV == nullptr)
                    {
                        MSG_RETURN(RET_MEM_ERR_ALLOC);
                    }
                    else
                    {
                        pflagEvalDV[pdictattr->progN] = TRUE;
                    }
                }
            }
        }
        if (pflagEvalDV != nullptr)
        {
            SCPT_ComputeScreenDV (  pdictent->objectEn,
                                    DictFct_0,
                                    pflagEvalDV,
                                    NULL,
                                    pdbadyn,
                                    NULL,
                                    nullptr,
                                    NULLDYNST,
                                    TRUE,
                                    TRUE,
                                    EvalType_DefVal,
                                    -1,
                                    UNUSED,
                                    NULL,
                                    NULL,
                                    0,
                                    DictScreen,
                                    NULL,
                                    NULL,
                                    NULL,
                                    NULL,
                                    NULL,
                                    NullEntity,
                                    FALSE,
                                    FALSE,
                                    0);

            retCode = DBA_Update2(  pdictent->objectEn,
                                    UNUSED,
                                    GET_EDITGUIST(pdictent->objectEn),
                                    pdbadyn,
                                    dbiConnHelper);

            FREE(pflagEvalDV);
        }
    }
    return retCode;
}


/************************************************************************
**
**  Function    :   DBA_CopyCascadeManageCrossRef
**
**  Description :   manage cross reference between the newly copied records
**
**  Arguments   :   DBA_COPY_OBJ_STP**      pcopytab        : table of copied records to manage cross reference
**                  int*                    piNbObj         : size of the table
**                  DBA_DYNFLD_STP          pdbadynOrigin   : origin record
**                  OBJECT_ENUM             enOriEntity     : object enum of the orign record
**                  DbiConnectionHelper&    dbiConnHelper   : Connection structure
**
**  Return      :   RET_CODE
**
**  Creation    :   HFI-PMSTA-41842-200916 
**
*************************************************************************/
RET_CODE DBA_CopyCascadeManageCrossRef (DBA_COPY_OBJ_STP *pcopytab, int iNbObj, DBA_DYNFLD_STP pdbadynOrigin, OBJECT_ENUM enOriEntity, DbiConnectionHelper& dbiConnHelper)
{
    RET_CODE            retCode = RET_SUCCEED;
  
    /*  Manage cross reference between copied sub records               */
    for (int i = 0; (i < iNbObj) && (retCode == RET_SUCCEED); i++)
    {
        DBA_CopyCascadeManageCrossRefOneRecord(pcopytab,iNbObj, pcopytab[i]->pdbadyn, pcopytab[i]->pdictent, dbiConnHelper);
    }
    /*  Manage cross reference for the main record                      */
    if ((retCode == RET_SUCCEED) &&
        (pdbadynOrigin != nullptr))
    {
        DICT_ENTITY_STP pdictent = DBA_GetDictEntitySt(enOriEntity);
        DBA_CopyCascadeManageCrossRefOneRecord(pcopytab,iNbObj, pdbadynOrigin, pdictent, dbiConnHelper);
    }
    return retCode;
}


/************************************************************************
**
**  Function    :   DBA_CopyCascade
**
**  Description :   Copy logical attributes from an entity to another
**
**  Arguments   :   DBA_COPY_OBJ_STP**      pcopytab        : table of copied records to manage cross reference
**                  int*                    piNbObj         : size of the table
**                  DICT_ENTITY_STP         dictentEntity   : Parent entity
**                  DICT_ENTITY_STP         pdictentLogical : Logical entity to copy
**                  ID_T                    idFrom          : From object id
**                  ID_T                    idTo            : To object id
**                  DbiConnectionHelper&    dbiConnHelper   : Connection structure
**
**  Return      :   RET_CODE
**
**  Creation    :   HFI-PMSTA-41842-200916 
**                  HFI-PMSTA-51611-2022-12-21  call DBA_CopyOneEntity to simplify and unify code
**
*************************************************************************/
STATIC  RET_CODE DBA_CopyCascade (DBA_COPY_OBJ_STP **pcopytab, int *piNbObj, DICT_ENTITY_STP dictentEntity, DICT_ENTITY_STP pdictentLogical, ID_T idFrom, ID_T idTo, DbiConnectionHelper& dbiConnHelper)
{
	DBA_DYNFLD_STP			pdbadynAdmArg,
                            *pdbadybtabShort;
	DBA_ERRMSG_INFOS_ST		msgStruct(FILEINFO);
    RET_CODE				retCode = RET_SUCCEED;
    int                     iNbRecord = 0;
    int                     i;

    /*  Security test                                                   */
    if ((pdictentLogical == nullptr) ||
        (pdictentLogical->dbPKTab == nullptr) ||
        (pdictentLogical->parentAttrStp == nullptr))
    {
        MSG_RETURN(RET_GEN_ERR_INVARG);
    }
    /*  Select objects to be copied                                     */
    if ((pdbadynAdmArg = ALLOC_DYNST(Adm_Arg)) == nullptr)
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }
    /*  Fill Select input parameter                                     */
    SET_ID(pdbadynAdmArg, Adm_Arg_Id, idFrom);
    SET_ID(pdbadynAdmArg, Adm_Arg_EntDictId, dictentEntity->entDictId);

    /*  Select records to be copied                                     */
	retCode = DBA_Select2 ( pdictentLogical->objectEn,
                            UNUSED,
                            Adm_Arg,
                            pdbadynAdmArg,
                            GET_ADMINGUIST(pdictentLogical->objectEn),
                            &pdbadybtabShort,
                            UNUSED,
                            &iNbRecord,
                            dbiConnHelper);

    FREE_DYNST(pdbadynAdmArg, Adm_Arg);

    if ((retCode == RET_SUCCEED) &&
        (iNbRecord  > 0))
    {
        for (i = 0; (i < iNbRecord) && (retCode == RET_SUCCEED) ; i++)
        {
            if (DBA_CopyObjectCheckRights(pdictentLogical, pdbadybtabShort[i], TRUE) == TRUE)
            {
    	        DBA_DYNFLD_STP			pdbadynAll;
                FLAG_T                  *pflagEvalDV;

                if (((pdbadynAll = ALLOC_DYNST(GET_EDITGUIST(pdictentLogical->objectEn))) == nullptr) ||
                    ((pflagEvalDV = (FLAG_T*) CALLOC(pdictentLogical->attr.size(),sizeof(FLAG_T))) == nullptr))
                    MSG_RETURN(RET_MEM_ERR_ALLOC);

                retCode = dbiConnHelper.dbaGet( pdictentLogical->objectEn,
                                                UNUSED,
                                                pdbadybtabShort[i],
                                                &pdbadynAll);

                if ((retCode == RET_SUCCEED) &&
                    (IS_NULLFLD(pdbadynAll,pdictentLogical->dbPKTab[0]->progN) == FALSE))
                {
                    ID_T    idSubFrom = GET_ID(pdbadynAll,pdictentLogical->dbPKTab[0]->progN);

                    SET_ID(pdbadynAll,pdictentLogical->parentAttrStp->progN, idTo);
                    DBA_SetNullAttribWhileCopying(pdbadynAll, pdictentLogical->objectEn, &pflagEvalDV,FALSE);
                    SET_NULL_ID(pdbadynAll,pdictentLogical->dbPKTab[0]->progN);

                    SCPT_ComputeScreenDV (  pdictentLogical->objectEn,
                                            DictFct_0,
                                            pflagEvalDV,
                                            NULL,
                                            pdbadynAll,
                                            NULL,
                                            nullptr,
                                            NULLDYNST,
                                            TRUE,
                                            TRUE,
                                            EvalType_DefVal,
                                            -1,
                                            UNUSED,
                                            NULL,
                                            NULL,
                                            0,
                                            DictScreen,
                                            NULL,
                                            NULL,
                                            NULL,
                                            NULL,
                                            NULL,
                                            NullEntity,
                                            FALSE,
                                            FALSE,
                                            0);

                    retCode = DBA_Insert2(  pdictentLogical->objectEn,
                                            UNUSED,
                                            GET_EDITGUIST(pdictentLogical->objectEn),
                                            pdbadynAll,
                                            dbiConnHelper);

                    if ((retCode == RET_SUCCEED) &&
                        (IS_NULLFLD(pdbadybtabShort[i],pdictentLogical->dbPKTab[0]->progN) == FALSE))
                    {
                        ID_T    idSubTo = GET_ID(pdbadynAll,pdictentLogical->dbPKTab[0]->progN);

                        retCode = DBA_CopyAddRecord(pcopytab, piNbObj, pdictentLogical, idSubFrom, idSubTo, pdbadynAll);

                        /*  Loop on From attributes                 */
                        for (auto attribItlog = pdictentLogical->attr.begin(); attribItlog != pdictentLogical->attr.end() && retCode == RET_SUCCEED; ++attribItlog)
                        {
                            DICT_ATTRIB_STP pdictattrSubLog = (*attribItlog);
                            /*  Copy only logical attributes linked to an entity authorized to the copy */
                            if ((pdictattrSubLog->logicalFlg == TRUE) &&
                                (pdictattrSubLog->copyRightEn == DictAttrCopyNat_Copy))
                            {
                                retCode = DBA_CopyOneEntity (pcopytab, piNbObj, pdictentLogical, pdictentLogical, pdictattrSubLog, idSubFrom, idSubTo, pdbadynAll, dbiConnHelper);
                            }
                        }
                    }        
                }
                if (retCode != RET_SUCCEED)
                {
                    FREE_DYNST(pdbadynAll, GET_EDITGUIST(pdictentLogical->objectEn));
                    FREE_DYNST(pdbadybtabShort[i], GET_ADMINGUIST(pdictentLogical->objectEn));
                }
                FREE(pflagEvalDV);
            }
        }
        if (retCode != RET_SUCCEED)
        {
            for (; i < iNbRecord; i++)
            {
                FREE_DYNST(pdbadybtabShort[i], GET_ADMINGUIST(pdictentLogical->objectEn));
            }
        }
        FREE(pdbadybtabShort);
    }
    return retCode;
}


/************************************************************************
**
**  Function    :   DBA_CopyCheckRights
**
**  Description :   Check if the copy makes sense
**                  1. entity managed by nature: the logical attribute to copy makes no sense in the target record
**                  2. reference format element could not be copied in a format without reference format.
**
**  Arguments   :   DICT_ENTITY_STP         pdictentTo          : target parent entity
**                  DICT_ATTRIB_STP         pdictattrFrom       : Logical attribute to copy
**                  DBA_DYNFLD_STP          pdbadynTo           : Target record for the copy
**
**  Return      :   FLAG_T                                      : TRUE copy authorised
**                                                              : FALSE copy forbidden
**
**  Creation    :   HFI-PMSTA-51611-2022-12-21
**
*************************************************************************/
STATIC FLAG_T DBA_CopyCheckRights (DICT_ENTITY_STP pdictentFrom, DICT_ENTITY_STP pdictentTo, DICT_ATTRIB_STP pdictattrFrom, DICT_ENTITY_STP pdictentLogical, DBA_DYNFLD_STP pdbadynTo)
{
    FLAG_T  flagRights = TRUE;

    if ((pdictentFrom != nullptr) &&
        (pdictattrFrom != nullptr) &&
        (pdbadynTo != nullptr))
    {
        if ((pdictentFrom->objectEn == Fmt) &&
            (pdictentLogical->objectEn == ReferenceFormatElement) &&
            (IS_NULLFLD(pdbadynTo, A_Fmt_ReferenceFmtId) == TRUE))
        {
            flagRights = FALSE;
        }
        if ((pdictentFrom->objectEn == pdictentTo->objectEn) &&
            (pdictentFrom->tpNatEn != NoTyping) &&
            (IS_NULLFLD(pdbadynTo, pdictentFrom->natIndex) == FALSE))
        {
            ENUM_T  enNature = GET_ENUM(pdbadynTo, pdictentFrom->natIndex);
            if (CHECK_BITMASK(pdictattrFrom->subTypeMask, enNature) == FALSE)
            {
                flagRights = FALSE;
            }
        }
    }
    return flagRights;
}


/************************************************************************
**
**  Function    :   DBA_CopyOneEntity
**
**  Description :   Copy logical attributes from an entity to another
**
**  Arguments   :   DBA_COPY_OBJ_STP**      pcopytab            : table of copied records to manage cross reference
**                  int*                    piNbObj             : size of the table
**                  DICT_ENTITY_STP         pdictentFrom        : origin parent entity
**                  DICT_ENTITY_STP         pdictentTo          : target parent entity
**                  DICT_ATTRIB_STP         pdictattrFrom       : Logical attribute to copy
**                  ID_T                    idFrom              : From object id
**                  ID_T                    idTo                : To object id
**                  DBA_DYNFLD_STP          pdbadynTo           : Target record for the copy
**                  DbiConnectionHelper&    dbiConnHelper       : Connection structure
**
**  Return      :   RET_CODE
**
**  Creation    :   HFI-PMSTA-51611-2022-12-21  creation to avoid duplicate code in dbalib05.c and guicopy
**
*************************************************************************/
RET_CODE DBA_CopyOneEntity (DBA_COPY_OBJ_STP **pcopytab, int *piNbObj, DICT_ENTITY_STP pdictentFrom, DICT_ENTITY_STP pdictentTo, DICT_ATTRIB_STP pdictattrFrom, ID_T idFrom, ID_T idTo, DBA_DYNFLD_STP pdbadynTo, DbiConnectionHelper& dbiConnHelper)
{
    RET_CODE        retCode = RET_SUCCEED;

    /*  Security test                                                   */
    if (pdictattrFrom == nullptr)
    {
        MSG_RETURN(RET_GEN_ERR_INVARG);
    }
    DICT_ENTITY_STP pdictentLogical = DBA_GetDictEntityByDictId(pdictattrFrom->refEntDictId);
    if (pdictentLogical == nullptr)
    {
        MSG_RETURN(RET_GEN_ERR_INVARG);
    }

    /*  Check that the copy makes sense else nothing to do              */
    if (DBA_CopyCheckRights (pdictentFrom, pdictentTo, pdictattrFrom, pdictentLogical, pdbadynTo) == FALSE)
    {
        return RET_SUCCEED;
    }

    /*  Alloc copy variables                    */
    DBA_DYNFLD_STP			pdbadynCopyArg = ALLOC_DYNST(A_CopyArg);
    if (pdbadynCopyArg == nullptr)
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    /*  Init copy stucture                      */
    SET_ID(pdbadynCopyArg, A_CopyArg_FromId, idFrom);
    SET_ID(pdbadynCopyArg, A_CopyArg_ToId, idTo);     
    SET_DICT(pdbadynCopyArg, A_CopyArg_EntityDictId, pdictentFrom->entDictId);     
    SET_DICT(pdbadynCopyArg, A_CopyArg_ToEntityDictId, pdictentTo->entDictId);

	int     role = UNUSED;
    if ((pdictentFrom->objectEn == Strat) &&
        (pdictentLogical->objectEn == ComplianceChrono))
    {
        role = DBA_ROLE_COPY_COMPL_CHRONO_BY_STRAT;
    }
    /*  New role to manage the copy of business data compo while coming from business entity    */  /*  HFI-PMSTA-17559-140206  */
    else if ((pdictentFrom->objectEn == BusEntity) &&
             ((pdictentLogical->objectEn == BusEntityPtfCompo) ||
              (pdictentLogical->objectEn == BusEntityInstrCompo) ||
              (pdictentLogical->objectEn == BusEntityThirdCompo) ||
              (pdictentLogical->objectEn == BusEntityUserCompo)))
    {
        role = DBA_ROLE_BY_BUS_ENTITY;
    }

    if (pdictentFrom == pdictentTo)
    {
        SET_DICT(pdbadynCopyArg, A_CopyArg_AttribDictId, pdictattrFrom->attrDictId);
        SET_DICT(pdbadynCopyArg, A_CopyArg_ToAttribDictId, pdictattrFrom->attrDictId); 

        /*  if the copy procedure does not exist then the cascade copy procedure is applied         */
        DBA_PROC_STP procedure =  DBA_GetStoredProcs(Copy, pdictentLogical->objectEn, role, A_CopyArg, pdbadynCopyArg, NullDynSt);
        if ((DBA_CheckCopyCascadeRights(pdictentLogical, pdictentLogical->objectEn, pdictentLogical->objectEn) == TRUE) ||
            (procedure == nullptr))
        {
            retCode = DBA_CopyCascade(pcopytab, piNbObj, pdictentFrom, pdictentLogical, idFrom, idTo, dbiConnHelper);
        }
        else
        {
            /*  Call copy procedure                     */
            retCode = DBA_Copy( pdictentLogical->objectEn,
                                UNUSED,
                                A_CopyArg,
                                pdbadynCopyArg,
                                dbiConnHelper);
                
        }
    }
    else
    {
        /*  Detect the same attribute in the to entity  */
        FLAG_T  flagFound = FALSE;
        for (auto attribItTo = pdictentTo->attr.begin(); attribItTo != pdictentTo->attr.end() && flagFound == FALSE; ++attribItTo)
        {
            DICT_ATTRIB_STP pdictattrTo = (*attribItTo);

            if ((pdictattrTo->logicalFlg == TRUE) &&
                (pdictattrTo->refEntDictId == pdictattrFrom->refEntDictId) &&
                (strcmp(pdictattrFrom->sqlName, pdictattrTo->sqlName) == 0))
            {
                flagFound = TRUE;
                SET_DICT(pdbadynCopyArg,A_CopyArg_AttribDictId,pdictattrFrom->attrDictId);
                SET_DICT(pdbadynCopyArg,A_CopyArg_ToAttribDictId,pdictattrTo->attrDictId);

                /*  Call copy procedure                     */
                retCode = DBA_Copy( pdictentLogical->objectEn,
                                    role,
                                    A_CopyArg,
                                    pdbadynCopyArg,
                                    dbiConnHelper);
            }
        }
    }

    /*  Free allocation                         */
    FREE_DYNST(pdbadynCopyArg, A_CopyArg);

    return retCode;
}

/************************************************************************
**
**  Function    :   DBA_CopyAutomatic
**
**  Description :   Copy logical attributes from an entity to another
**
**  Arguments   :   OBJECT_ENUM             enFromEntity    : From entity    
**                  OBJECT_ENUM             enToEntity      : To entity
**                  ID_T                    idFrom          : From object id
**                  ID_T                    idTo            : To object id
**                  DBA_DYNFLD_STP          pdbadynTo       : Target record for copy
**                  DbiConnectionHelper&    dbiConnHelper   : Connection structure
**
**  Return      :   RET_CODE
**
**  Creation    :   HFI-PMSTA-38117-191209
**  Modif       :   HFI-PMSTA-38117-200128  move from guicopy to dbalib05 and provide connection
**  Creation    :   HFI-PMSTA-51611-2022-12-21  use of DbiConnectionHelper and call of DBA_CopyOneEntity
**
*************************************************************************/
RET_CODE DBA_CopyAutomatic (OBJECT_ENUM enFromEntity, OBJECT_ENUM enToEntity, ID_T idFrom, ID_T idTo, DBA_DYNFLD_STP pdbadynTo, DbiConnectionHelper& dbiConnHelper)
{
	DBA_ERRMSG_INFOS_ST		msgStruct(FILEINFO);
    RET_CODE				retCode = RET_SUCCEED;
    DBA_COPY_OBJ_STP        *pcopytab = nullptr;
    int                     iNbCopiedRecord = 0;

    /*  Test for security                       */
    if ((idFrom == 0) ||
        (idTo == 0) ||
        (idTo == idFrom))
        MSG_RETURN(RET_GEN_ERR_INVARG);

    /*  Init variables                          */
    DICT_ENTITY_STP pdictentFrom = DBA_GetDictEntitySt(enFromEntity);
    DICT_ENTITY_STP pdictentTo = DBA_GetDictEntitySt(enToEntity);

    /*  Test for security                       */
    if ((pdictentFrom == nullptr) ||
        (pdictentTo == nullptr))
        MSG_RETURN(RET_GEN_ERR_INVARG);

    /*  Loop on From attributes                 */
    for (auto attribItFrom = pdictentFrom->attr.begin(); attribItFrom != pdictentFrom->attr.end() && retCode == RET_SUCCEED; ++attribItFrom)
    {
        DICT_ATTRIB_STP pdictattrFrom = (*attribItFrom);

        /*  Copy only logical attributes linked to an entity authorized to the copy */
        if ((pdictattrFrom->logicalFlg == TRUE) &&
            (pdictattrFrom->copyRightEn == DictAttrCopyNat_Copy))
        {
            retCode = DBA_CopyOneEntity (&pcopytab, &iNbCopiedRecord, pdictentFrom, pdictentTo, pdictattrFrom, idFrom, idTo, pdbadynTo, dbiConnHelper);
        }
    }
    /*  manage cross reference between copied objects                   */
    if (iNbCopiedRecord != 0)
    {
        if (retCode == RET_SUCCEED)
        {
            retCode = DBA_CopyCascadeManageCrossRef(pcopytab, iNbCopiedRecord, pdbadynTo, GET_EDITGUIST(enToEntity), dbiConnHelper);
        }
        /*  free allocated memory                                           */
        /*  Free allocation                                             */
        for (int i = 0; i < iNbCopiedRecord; i++)
        {
            FREE_DYNST(pcopytab[i]->pdbadyn, GET_EDITGUIST(pcopytab[i]->pdictent->objectEn));
            FREE(pcopytab[i]);
        }
        FREE(pcopytab);
    }
    return retCode;
}


/************************************************************************
*   Function             : DBA_Copy()
*
*   Description          : Send a COPY request to the server and retrieve
*                          returned status
*
*   Arguments            : object       : the request corresponding object
*                          rule         : the rule to use
*                          inputSt      : the input dynamic struct. format
*                          inputData    : the pointer on the input dynamic struct.
*                          cpyOptions   : can be DBA_SET_CONN, DBA_NO_CLOSE
*                          allocConn    : 1. pointer which will contain the connectNo
*                                            used for the request if delOptions is
*                                            DBA_NO_CLOSE.
*                                         2. pointer which contain a connection number
*                                            if delOptions is DBA_SET_CONN.
*                          msgStructPtr : pointer on a structure which will contain
*                                         recieved messages informations.
*
*   Return               : RET_SUCCEED              : if no problem was detected
*                          RET_DBA_ERR_ARGNOMATCH   : if input arg. problem
*                          RET_DBA_ERR_PROCNOTFOUND : if no procedure founded
*                          RET_DBA_ERR_SETPARAM     : if problem while setting proc. parameters
*                          RET_DBA_ERR_CONNOTFOUND  : if no connection founded
*                          RET_DBA_ERR_DBPROBLEM    : if DB/connection problem
*                          RET_DBA_ERR_SYBBIND      : if poblem while binding received fields
*                          RET_MEM_ERR_ALLOC        : if allocation failed
*                          RET_DBA_ERR_READ_DATA    : if problem while reading received data
*                          RET_GEN_ERR_INVARG       : if problem while setting function params.
*                          a RET_CODE               : if a message has been received
*
*   Creation Date        : 25.04.96 - PEC - Ref.: DVP036.
*   Last Modification    : 28.06.97 - ROI - DVP524.
*                          17.08.00 - GRD - REF5133.
*                          REF7264 - 0201225 - PMO : Compilation errors and warnings with C++ compiler
*************************************************************************/
RET_CODE DBA_Copy(OBJECT_ENUM          object,
    int                  role,
    DBA_DYNST_ENUM       inputSt,
    DBA_DYNFLD_STP       inputData,
    int                  cpyOptions,
    int                  *allocConn,
    DBA_ERRMSG_INFOS_STP msgStructPtr)
{
    DbiConnection * dbiConn = nullptr;
    RET_CODE        retCode = RET_SUCCEED;

    /* If no connection number is given */
    if ((cpyOptions & DBA_SET_CONN) != DBA_SET_CONN)
    {
        /* Get a free connection */
        if ((dbiConn = DBA_GetDbiConnection(SqlServer)) == nullptr)
        {
            MSG_RETURN(RET_DBA_ERR_CONNOTFOUND);
        }
    }
    else
    {
        /* If a connection number is given */
        if (allocConn != NULL) /* FPL-PMSTA06305-080508 */
        {
            dbiConn = DBA_GetDbiConnFromConnectNo(*allocConn);
            if (dbiConn == nullptr) {
                return RET_DBA_ERR_CONNOTFOUND;
            }
        }
        else
        {
            MSG_RETURN(RET_DBA_ERR_ARGNOMATCH);
        }
    }

    retCode = DBA_Copy(object,
        role,
        inputSt,
        inputData,
        cpyOptions,
        *dbiConn,
        msgStructPtr);

    bool isInError = (retCode == RET_DBA_ERR_DIALOG);
    if (isInError)
    {
        dbiConn->setValidConnection(false);
    }
    if ((cpyOptions & DBA_NO_CLOSE) != DBA_NO_CLOSE)
    {
        DBA_EndConnection(&dbiConn, isInError);
    }
    return retCode;
}
RET_CODE DBA_Copy(OBJECT_ENUM          object,
                  int                  role,
	              DBA_DYNST_ENUM       inputSt,
	              DBA_DYNFLD_STP       inputData,
                  int                  cpyOptions,
                  DbiConnection&       dbiConn,
                  DBA_ERRMSG_INFOS_STP msgStructPtr)
{
    RET_CODE        ret;
    DbiConnectionHelper dbiConnHelper(&dbiConn, false);
    dbiConnHelper.dbaSetOptions(cpyOptions | DBA_SET_CONN | DBA_NO_CLOSE);

    ret=DBA_Copy(object, role, inputSt, inputData, dbiConnHelper);

    dbiConn.sendAllMsg();

    return(ret);
}

RET_CODE DBA_Copy(OBJECT_ENUM          object,
                  int                  role,
	              DBA_DYNST_ENUM       inputSt,
	              DBA_DYNFLD_STP       inputData,
                  DbiConnectionHelper& dbiConnHelper)
{
#ifdef AAAPROFILER
    ZoneScopedNS("DBA_Copy", 5);
#endif

    DbaCallGuard dbaCallGuard(dbiConnHelper); /* PMSTA-45413 - LJE - 210804 */

	RET_CODE        finalResult = RET_SUCCEED;

	/* Retrieve a procedure in the object procedures list */
	DBA_PROC_STP procedure =  DBA_GetStoredProcs(Copy, object, role, inputSt, inputData, NullDynSt);

	/* If no procedure */
	if (procedure == NULL)
	{
		if ((dbiConnHelper.dbaGetOptions() & DBA_NO_PROC_ERROR) == 0) /* PMSTA-13946 - LJE - 120328 */
		{
		    char	     objString[40];
            const char  *sqlName = DBA_GetDictEntitySqlName(object);
		    OBJECT_ENUM  objEn;		    /* REF2697 - SSO - 000510 */
		    const char	*entitySqlNameIn=NULL;  /* REF2697 - SSO - 000510 */
		    char	     entityStrIn[13];	    /* REF2697 - SSO - 000510 */

		    if (sqlName != NULL)
		    {
			    strcpy(objString, sqlName);
		    }
		    else
		    {
			    sprintf(objString, "unknown(" szFormatObj ")",object);/* REF2697 - SSO - 000510 */
		    }

            DBA_GetObjectEnumByDynSt(inputSt, &objEn);  /* REF2697 - SSO - 000510 */
		    entitySqlNameIn = DBA_GetDictEntitySqlName(objEn);

		    if (entitySqlNameIn == NULL)
	        {
			    entitySqlNameIn = DBA_GetDynStCName(inputSt);
		    }
		    if (entitySqlNameIn == NULL)
		    {
		        sprintf(entityStrIn,"unknown(%d)",inputSt);
		        entitySqlNameIn = entityStrIn;
		    }
            DBA_LogMesgProcedureNotFound(Copy, object, role, inputSt, inputData, NullDynSt, false, "Copy", objString, entitySqlNameIn, "none");  /* PMSTA-24985 - 111016 - PMO */
		}
		return(RET_DBA_ERR_PROCNOTFOUND);
	}
    dbiConnHelper.setCurrProcedure(procedure);  /* PMSTA-45413 - LJE - 210804 */

    if (dbiConnHelper.isValidAndInit() == false)
    {
        return(RET_DBA_ERR_CONNOTFOUND);
    }

    DbiConnection& dbiConn = *dbiConnHelper.getConnection();

    dbiConn.setReadOnly(procedure); /* PMSTA-29027 - LJE - 190111 */

	/* DLA - PMSTA09887 - 110303 */
    DBA_TruncateDynStStringToMDLength(inputData);

	/* If Procedure is an internal proc, call a C function, not a stored procedure */
	if (procedure->server == InternalProc)
	{
	    finalResult = procedure->fctDefSt.cpyFct(object, inputData, dbiConnHelper);
		return(finalResult);
	}
    else
    {
        if (USE_NEW_ACCESS_API(dbiConnHelper.getConnection()))
        {
            RequestHelper requestHelper(dbiConnHelper);
            if (requestHelper.startProcedureCall(procedure, inputData) == false)
            {
                return(requestHelper.getLastResultRetCode());
            }
        }
        else
        {
            
            DBI_INT         status, resultType;
            dbiConn.setReadOnly(procedure);             /* PMSTA-37366 - LJE - 200702 */

            /* Retrieve and memorize parameters names and types in the meta dictionary tables */
            if (DBI_SetProcParameters(dbiConn, inputSt, inputData, procedure) != RET_SUCCEED)
            {
                dbiConn.releaseCommand();
                MSG_RETURN(RET_DBA_ERR_SETPARAM);
            }

            /* Send the request to the server */
            if (dbiConn.sendRequest(&resultType) != RET_SUCCEED)
            {
                dbiConn.releaseCommand();

                /* PMSTA-18593 - LJE - 150617 */
                if (dbiConnHelper.emptyMsg() == false)
                {
                    dbiConnHelper.sendAllMsg();
                    return RET_DBA_ERR_DBPROBLEM;
                }
                else
                {
                    MSG_RETURN(RET_DBA_ERR_DBPROBLEM);
                }
            }

            /*** Temporary allow a resultType equal to DBI_CMD_SUCCEED **/
            if (resultType != DBI_STATUS_RESULT && resultType != DBI_CMD_SUCCEED)
            {
                dbiConn.releaseCommand();
                MSG_RETURN(RET_DBA_ERR_DBPROBLEM);
            }

            dbiConn.processAllResults(&status); /* PMSTA-23385 - LJE - 160630 */

            /* Call to function which will filter received messages during
               insert operation */
            dbiConn.filterMsgInfos(&finalResult);
        }
    }

	if(EV_ExtractFile && EV_SetProcParametersFlg)
	{
		DATE_ResetTimer(EV_ExtractFileTimerPtr, TIMER_MASK_GEN);
		DATE_StartTimer(EV_ExtractFileTimerPtr, TIMER_MASK_GEN);
		EV_SetProcParametersFlg = FALSE;
	}

	return(finalResult);
}

/************************************************************************
*   Function             : DBA_InsUpd()
*
*   Description          : Send a INSERT/UPDATE request to the server and retrieve
*                          returned status
*
*   Arguments            : object       : the request corresponding object
*                          inputSt      : the input dynamic struct. format
*                          inputData    : the pointer on the input dynamic struct.
*                          insOptions   : can be DBA_SET_CONN, DBA_NO_CLOSE, DBA_INS_ID
*                          allocConn    : 1. pointer which will contain the connectNo
*                                            used for the request if insOptions is
*                                            DBA_NO_CLOSE.
*                                         2. pointer which contain a connection number
*                                            if insOptions is DBA_SET_CONN.
*                          msgStructPtr : pointer on a structure which will contain
*                                         recieved messages informations.
*
*   Return               : RET_SUCCEED              : if no problem was detected
*                          RET_DBA_ERR_ARGNOMATCH   : if input arg. problem
*                          RET_DBA_ERR_PROCNOTFOUND : if no procedure founded
*                          RET_DBA_ERR_SETPARAM     : if problem while setting proc. parameters
*                          RET_DBA_ERR_CONNOTFOUND  : if no connection founded
*                          RET_DBA_ERR_DBPROBLEM    : if DB/connection problem
*                          RET_DBA_ERR_SYBBIND      : if poblem while binding received fields
*                          RET_MEM_ERR_ALLOC        : if allocation failed
*                          RET_DBA_ERR_READ_DATA    : if problem while reading received data
*                          RET_GEN_ERR_INVARG       : if problem while setting function params.
*                          a RET_CODE               : if a message has been received
*
*   Creation Date        : 02.12.96 - PEC - Ref.: DVP289
*   Last Modification    : 29.10.98 - GRD - Ref.: REF2644
*                          09.03.00 - GRD - Ref.: REF4204.
*                          09.04.01 - GRD - Ref.: REF5037.
*                          REF7264 - 0201225 - PMO : Compilation errors and warnings with C++ compiler
*************************************************************************/
RET_CODE DBA_InsUpd(OBJECT_ENUM          object,
    int                  role,
    DBA_DYNST_ENUM       inputSt,
    DBA_DYNFLD_STP       inputData,
    int                  insOptions,
    int                  *allocConn,
    DBA_ERRMSG_INFOS_STP msgStructPtr)
{
    DbiConnection * dbiConn = nullptr;
    RET_CODE        retCode = RET_SUCCEED;

    /* If no connection number is given */
    if ((insOptions & DBA_SET_CONN) != DBA_SET_CONN)
    {
        /* Get a free connection */
        if ((dbiConn = DBA_GetDbiConnection(SqlServer)) == nullptr)
        {
            MSG_RETURN(RET_DBA_ERR_CONNOTFOUND);
        }
    }
    else
    {
        /* If a connection number is given */
        if (allocConn != NULL) /* FPL-PMSTA06305-080508 */
        {
            dbiConn = DBA_GetDbiConnFromConnectNo(*allocConn);
            if (dbiConn == nullptr) {
                return RET_DBA_ERR_CONNOTFOUND;
            }
        }
        else
        {
            MSG_RETURN(RET_DBA_ERR_ARGNOMATCH);
        }
    }

    retCode = DBA_InsUpd(object,
                         role,
                         inputSt,
                         inputData,
                         insOptions,
                         *dbiConn,
                         msgStructPtr);

    bool isInError = (retCode == RET_DBA_ERR_DIALOG);
    if (isInError)
    {
        dbiConn->setValidConnection(false);
    }
    if ((insOptions & DBA_NO_CLOSE) != DBA_NO_CLOSE)
    {
        DBA_EndConnection(&dbiConn, isInError);
    }
    return retCode;
}
RET_CODE DBA_InsUpd(OBJECT_ENUM          object,
                    int                  role,
                    DBA_DYNST_ENUM       inputSt,
                    DBA_DYNFLD_STP       inputData,
                    int                  insOptions,
                    DbiConnection&       dbiConn,
                    DBA_ERRMSG_INFOS_STP msgStructPtr,
                    DBA_ERRMSG_HEADER_STP  dbaErrMsgHeaderStp)  /* PMSTA-49780- BSV- 040722 */
{
    RET_CODE        ret;
    DbiConnectionHelper dbiConnHelper(&dbiConn, false);
    dbiConnHelper.dbaSetOptions(insOptions | DBA_SET_CONN | DBA_NO_CLOSE);

    ret = DBA_InsUpd(object,
                     role,
                     inputSt,
                     inputData,
                     dbiConnHelper);

    dbiConn.sendAllMsg();

    /* PMSTA-49780- BSV- 040722 */
    //dbaErrMsgHeaderStp is default argument.Check for NULL before copying objects.
    if (dbaErrMsgHeaderStp != nullptr)
        dbaErrMsgHeaderStp->copyDbaErrMsgHeaderClassObject(*dbiConnHelper.dbaGetMsgStructHeader());

    return(ret);
}

RET_CODE DBA_InsUpd(OBJECT_ENUM          object,
                    int                  role,
                    DBA_DYNST_ENUM       inputSt,
                    DBA_DYNFLD_STP       inputData,
                    DbiConnectionHelper& dbiConnHelper)
{
#ifdef AAAPROFILER
    ZoneScopedNS("DBA_InsUpd", 5);
#endif

    DbaCallGuard    dbaCallGuard(dbiConnHelper); /* PMSTA-45413 - LJE - 210804 */
    int             cpt = 0;
    DBI_INT         status, resultType;
	RET_CODE        retCode, finalResult=RET_SUCCEED;
	char            tranCount=0;                             /* BUG186 */
	DBA_DYNFLD_STP	*outSubscriptionTab = NULL,		/* REF4204 */
					inSubscriptionSt = NULL;			/* REF4204 */
	int				outSubscriptionNbr = 0;			/* REF4204 */
	FLAG_T			localTranFlg = 0;			/* REF4204 */

    if (dbiConnHelper.isValidAndInit() == false)
    {
        return(RET_DBA_ERR_CONNOTFOUND);
    }

    DbiConnection& dbiConn = *dbiConnHelper.getConnection();

	/* Retrieve a procedure in the object procedures list */
	DBA_PROC_STP procedure = DBA_GetStoredProcs(InsUpd, object, role, inputSt, inputData, NullDynSt);

	/* If no procedure */
	if (procedure == NULL)
	{
		if ((dbiConnHelper.dbaGetOptions() & DBA_NO_PROC_ERROR) == 0) /* PMSTA-13946 - LJE - 120328 */
		{
		    char	objString[40];
            const char	*sqlName = DBA_GetDictEntitySqlName(object);
		    OBJECT_ENUM objEn;		    /* REF2697 - SSO - 000510 */
		    const char	    *entitySqlNameIn=NULL;  /* REF2697 - SSO - 000510 */
		    char	    entityStrIn[13];	    /* REF2697 - SSO - 000510 */

		    if (localTranFlg == TRUE)		/* REF4204 */
		    {
		         dbiConn.endTransaction(FALSE);
		    }
		    DBA_FreeDynStTab(outSubscriptionTab, outSubscriptionNbr, A_Subscription);

		    if (sqlName != NULL)
		    {
			    strcpy(objString, sqlName);
		    }
		    else
		    {
			    sprintf(objString, "unknown(" szFormatObj ")",object);/* REF2697 - SSO - 000510 */
		    }

            DBA_GetObjectEnumByDynSt(inputSt, &objEn);  /* REF2697 - SSO - 000510 */
		    entitySqlNameIn = DBA_GetDictEntitySqlName(objEn);

	        if (entitySqlNameIn == NULL)
	        {
			    entitySqlNameIn = DBA_GetDynStCName(inputSt);
		    }
		    if (entitySqlNameIn == NULL)
		    {
		        sprintf(entityStrIn,"unknown(%d)",inputSt);
		        entitySqlNameIn = entityStrIn;
		    }

            DBA_LogMesgProcedureNotFound(InsUpd, object, role, inputSt, inputData, NullDynSt, false, "InsertUpdate", objString, entitySqlNameIn, "none");  /* PMSTA-24985 - 111016 - PMO */
		}
		return(RET_DBA_ERR_PROCNOTFOUND);
	}

    dbiConnHelper.setCurrProcedure(procedure);  /* PMSTA-45413 - LJE - 210804 */

	/* DLA - PMSTA09887 - 110303 */
    DBA_TruncateDynStStringToMDLength(inputData);

    if (procedure->server != InternalProc &&
        dbiConnHelper.isHttp() &&
        dbiConnHelper.isBlockMode() == false)
    {
        return DBA_CallHttp(dbiConnHelper,
                            InsUpd,
                            object,
                            role,
                            inputSt,
                            inputData);
    }

	/*
	 * Is there any valid subscription for this entity?
	 */

    if ((procedure == NULL || (procedure->procMask & PROCMASK_DISABLE_SUBSCRIPTION) != PROCMASK_DISABLE_SUBSCRIPTION) &&  /* DLA - REF10507 - 041210 / REF10845 - 050118 - PMO */
        (EV_IsSubscriptionActive == TRUE) && (DBA_IsSubscriptionActive(object) == TRUE)) /* PMSTA15199 - DDV - 121128 - Replace DBA_IsTrustedObject by DBA_IsSubscriptionActive */
    {
	    if ((inSubscriptionSt = ALLOC_DYNST(A_Subscription)) == NULL)
	    {
		    MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }

	    SET_DICT(inSubscriptionSt, A_Subscription_EntityDictId,
		    (DBA_GetDictEntityStSafe(object))->entDictId);
	    SET_ENUM(inSubscriptionSt, A_Subscription_ActionEn, Subscription_Action_InsUpd);
        SET_ENUM(inSubscriptionSt, A_Subscription_ModuleEn, dbiConn.getSubscriptionModuleEn());

	    DBA_Select2(Subscription,
				    DBA_ROLE_SEL_SUBSCRIPTIONS,
				    A_Subscription,
				    inSubscriptionSt,
				    A_Subscription,
				    &outSubscriptionTab,
				    UNUSED,
				    &outSubscriptionNbr,
                    dbiConnHelper);

        FREE_DYNST(inSubscriptionSt, A_Subscription);
    }

	/*
	 * Some entity attributes could contain fields of type TextType, this is why we MUST be sure
	 * that a transaction is opened to allow data integrity.
	 * Same if we have subscriptions to insert.
	 * REF4204.
	 */

	if (outSubscriptionNbr > 0 || dbiConn.isDbTransactionRequired())
	{
		if (dbiConn.isInTransaction() == false)
		{
			dbiConn.beginTransaction();
			localTranFlg = TRUE;
		}
	}
	tranCount = dbiConn.m_transactCpt;   /* BUG186 */

	/**** BEGIN DVP029+ ****/
	/* If Procedure is an internal proc, call a C function, not a stored procedure */
	if (procedure->server == InternalProc)
	{
        do
        {
            cpt++;

            retCode = ((RET_CODE(*)(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, int, DBA_ERRMSG_INFOS_STP))    /* REF7264 - PMO */
                       procedure->procName)(object,
                                            inputSt,
                                            inputData,
                                            dbiConn.getId(),
                                            nullptr);

            if (retCode == RET_SRV_LIB_ERR_DEADLOCK && tranCount == (char)0 &&
                SYS_GetEnv("AAASHOWDEADLOCK") == NULL)  /* BUG186 */
            {
                switch (cpt)
                {
                    case 1:
                        /* DBA_SqlExec("waitfor delay \"0:00:01\"", *dbiConn); */
                        SYS_MilliSleep(1000); /* PMSTA-20159 - TEB - 150624  */
                        break;

                    case 2:

                        /* DBA_SqlExec("waitfor delay \"0:00:02\"", *dbiConn); */
                        SYS_MilliSleep(2000); /* PMSTA-20159 - TEB - 150624  */
                        break;

                    case 3:

                        /* DBA_SqlExec("waitfor delay \"0:00:05\"", *dbiConn); */
                        SYS_MilliSleep(5000); /* PMSTA-20159 - TEB - 150624  */
                        break;
                }

                dbiConn.m_transactCpt = 0;   /* BUG186 */
            }
        } while (retCode == RET_SRV_LIB_ERR_DEADLOCK &&
                 tranCount == (char)0 &&  /* BUG186 */
                 cpt < ITER_NBR_FOR_DEADLOCK &&
                 SYS_GetEnv("AAASHOWDEADLOCK") == NULL);

		/* If deadlock still occurs after 3 tries and if we were in the main transaction */
		if (retCode == RET_SRV_LIB_ERR_DEADLOCK && tranCount == (char)0)  /* BUG186 */
			MSG_SendMesg(RET_SRV_LIB_ERR_DEADLOCK, 1, FILEINFO, procedure->procName);

		if ((retCode == RET_SUCCEED) && (outSubscriptionNbr > 0))
		{
			retCode = DBA_LogSubscriptionEvents(object,
					  				            Subscription_Action_InsUpd,
					  				            inputSt,
					  				            inputData,
					  				            NULL,		/* No old value in case of insert. */
												dbiConn,
					  				            outSubscriptionTab,
					  				            outSubscriptionNbr);      /* REF5037 */
		}

		/**** BEGIN DVP483  ****/
			    /*if ((retCode != RET_SUCCEED) && commented out SSO - 000315 , moved in DBA_EndTransaction param */
		if (localTranFlg == TRUE)
		{
			dbiConn.endTransaction(finalResult == RET_SUCCEED ? TRUE : FALSE);		/* Rollback data. */
		}
		DBA_FreeDynStTab(outSubscriptionTab, outSubscriptionNbr, A_Subscription);
		return(retCode);
	}
	/**** END DVP029+ ****/

	/*** BEGIN DVP178 ***/
	do
	{
		cpt++;

        if (USE_NEW_ACCESS_API(&dbiConn))
        {
            RequestHelper requestHelper(&dbiConn);

            if (requestHelper.startProcedureCall(procedure, inputData) == false)
            {
                DBA_FreeDynStTab(outSubscriptionTab, outSubscriptionNbr, A_Subscription);
                return(requestHelper.getLastResultRetCode());
            }

            status = requestHelper.getLastStatus();
        }
        else
        {
            /* Retrieve and memorize parameters names and types in the meta dictionary tables */
            if (DBI_SetProcParameters(dbiConn, inputSt, inputData, procedure, object, 0) != TRUE)		/* REF2644 */
            {
                if (localTranFlg == TRUE)
                {
                    dbiConn.endTransaction(FALSE);
                }
                dbiConn.releaseCommand();
                DBA_FreeDynStTab(outSubscriptionTab, outSubscriptionNbr, A_Subscription);
                MSG_RETURN(RET_DBA_ERR_SETPARAM);
            }

            /* Send the request to the server */
            if (dbiConn.sendRequest(&resultType) != RET_SUCCEED)
            {
                dbiConn.releaseCommand();
                if (localTranFlg == TRUE)
                {
                    dbiConn.endTransaction(FALSE);
                }
                DBA_FreeDynStTab(outSubscriptionTab, outSubscriptionNbr, A_Subscription);

                /* PMSTA-18593 - LJE - 150617 */
                if (dbiConn.emptyMsg() == false && SYS_IsBatchMode())
                {
                    dbiConn.sendAllMsg();
                    return dbiConn.m_lastResultRetCode;
                }
                else
                {
                    MSG_RETURN(RET_DBA_ERR_DBPROBLEM);
                }
            }

            /*** Temporary allow a resultType equal to DBI_CMD_SUCCEED **/
            if (resultType != DBI_STATUS_RESULT && resultType != DBI_CMD_SUCCEED)
            {
                dbiConn.releaseCommand();
                if (localTranFlg == TRUE)
                {
                    dbiConn.endTransaction(FALSE);
                }

                DBA_FreeDynStTab(outSubscriptionTab, outSubscriptionNbr, A_Subscription);
                MSG_RETURN(RET_DBA_ERR_DBPROBLEM);
            }

            dbiConn.processAllResults(&status); /* PMSTA-23385 - LJE - 160630 */

            /* Call to function which will filter received messages during insert operation */
            dbiConn.filterMsgInfos(&finalResult);

        }

		if (finalResult == RET_SRV_LIB_ERR_DUPLICATEKEY)
		{
			/* In this case, the record already exists in DB and a message is received. This message
			   must be ignored by the function */
			finalResult = RET_SUCCEED;
		}

		/**** DVP178+ - 16.10.1996 ****/
		if (finalResult == RET_SRV_LIB_ERR_DEADLOCK && tranCount == (char)0 &&
		    SYS_GetEnv("AAASHOWDEADLOCK") == NULL)    /* BUG186 */
		{
			switch (cpt)
			{
			case 1:
				SYS_MilliSleep(1000); /* PMSTA-20159 - TEB - 150624  */
				break;
			case 2:
				SYS_MilliSleep(2000); /* PMSTA-20159 - TEB - 150624  */
				break;
			case 3:
				SYS_MilliSleep(5000); /* PMSTA-20159 - TEB - 150624  */
				break;
			}
			dbiConn.m_transactCpt = 0;       /* BUG186 */
		}
		/**** DVP178+ - 16.10.1996 ****/
	}
	while (finalResult == RET_SRV_LIB_ERR_DEADLOCK &&
	       tranCount   == (char)0                  &&            /* BUG186 */
	       cpt<ITER_NBR_FOR_DEADLOCK &&
	       SYS_GetEnv("AAASHOWDEADLOCK") == NULL);
	/*** END  DVP178 ***/

	/*** BEGIN DVP178+ ***/
	/* If deadlock still occurs after 3 tries and if we were in the main transaction */
	if (finalResult == RET_SRV_LIB_ERR_DEADLOCK && tranCount == (char)0)    /* BUG186 */
	{
		MSG_SendMesg(RET_SRV_LIB_ERR_DEADLOCK, 1, FILEINFO, procedure->procName);
		dbiConn.releaseCommand();
		if (localTranFlg == TRUE)
		{
            dbiConn.endTransaction(FALSE);
		}

        DBA_FreeDynStTab(outSubscriptionTab, outSubscriptionNbr, A_Subscription);
		return(RET_SRV_LIB_ERR_DEADLOCK);
	}
	/*** END   DVP178+ ***/

	/* Memorize the record id in the input data structure after a successful insertion */
	if (status > 0 && finalResult == RET_SUCCEED && (dbiConnHelper.dbaGetOptions() & DBA_INS_ID) != DBA_INS_ID)
	{
		/* DLA - PMSTA08801 - 100226 */
		if ( status > 1 ) /* Old ID management returned by status, normally impossible I let an assert */
		{
			SET_ID(inputData, 0, status);
			assert (157==8801);
		}
	}

	if (IS_NULLFLD(inputData, 0) == FALSE && DBA_GetCustFldNbr(object) > 1 && status >= 0)
	{
        const int idIdx = (procedure->remapIdIdxPtr != nullptr ? *(procedure->remapIdIdxPtr) : 0);
        const int udIdIdx = DBA_GetFirstCustFld(object);
        SET_ID(inputData, udIdIdx, GET_ID(inputData, idIdx));

		DBA_Update2(object, DBA_ROLE_UPD_UD_FIELDS, inputSt, inputData, dbiConnHelper);
	}

	switch(finalResult)
	{
	case RET_SUCCEED:
		/*
		 	* Insert was successful, verify if events has to be raised for this Entity.
		 	* REF4204 - 000207 - GRD.
		 	*/

		if (outSubscriptionNbr > 0)
		{
			finalResult = DBA_LogSubscriptionEvents(object,             /* REF5037 */
						  				            Subscription_Action_InsUpd,
						  				            inputSt,
						  				            inputData,
						  				            NULL,		/* No old value in case of insert. */
													dbiConn,
						  				            outSubscriptionTab,
						  				            outSubscriptionNbr);
        }

		if (localTranFlg == TRUE)
		{
			dbiConn.endTransaction(finalResult == RET_SUCCEED ? TRUE : FALSE);		/* Rollback data. */
		}

		break;

	default:
		/**** BEGIN DVP483  ****/        /* ROLLBACK transaction */ /* SSO 991011: if deadlock, -1 -> OK, no rollback*/
		if (localTranFlg == TRUE)
		{
			     dbiConn.endTransaction(FALSE);
		}
		/**** END  DVP483  ****/

		break;
	}
	dbiConn.releaseCommand();
	DBA_FreeDynStTab(outSubscriptionTab, outSubscriptionNbr, A_Subscription);

    return(finalResult);
}

/************************************************************************
*   Function               : DBA_Check()
*
*   Description            : Send a CHECK (call a stored procedure begining wich "chk_..."
*                            request to the server and retrieve returned status
*
*   Arguments              : object       : the request corresponding object
*                            role         : the role associated to the procedure
*                            inputSt      : the input dynamic struct. format
*                            inputData    : the pointer on the input dynamic struct.
*                            checkOptions : can be DBA_SET_CONN, DBA_NO_CLOSE
*                            allocConn    : a pointer on a connection number
*                            checkStatus  : indicate the Check result status
*                            msgStructPtr : pointer on a message structure
*
*   Return                 : RET_SUCCEED              : if ok
*                            RET_DBA_ERR_ARGNOMATCH   : if problem with arguments
*                            RET_DBA_ERR_CONNOTFOUND  : if no connection found
*                            RET_DBA_ERR_PROCNOTFOUND : if no proc. was found
*                            RET_DBA_ERR_SETPARAM     : if error while setting proc. param.
*                            RET_DBA_ERR_DBPROBLEM    : if connection/DB problem
*
*   Creation date          : Aug.  94 - PEC
*   Last moditication date : 29.08.95 - PEC
*                            03.10.96 - PEC - Ref.: DVP166 - Adaptation de la fonction aux normes 2
*                                                          - Refonte totale de la fonction
*                            PMSTA-46404 - DDV - 211005 - Remove checkStatus parameter
*************************************************************************/
RET_CODE DBA_Check( OBJECT_ENUM          object,
                    int                  role,
                    DBA_DYNST_ENUM       inputSt,
                    DBA_DYNFLD_STP       inputData,
                    int                  checkOptions,
                    int                  *allocConn,
                    DBA_ERRMSG_INFOS_STP msgStructPtr)
{
    RET_CODE              retCode  = RET_SUCCEED;
    DbiConnection *        dbiConn = nullptr;       /* PSMTA-30240 - DLA - 180221 */

    /* Retrieve a procedure in the object procedures list */
    DBA_PROC_STP procedure = DBA_GetStoredProcs(Check, object, role, inputSt, inputData, NullDynSt);

    /* If no procedure */
    if (procedure == NULL)
    {
        if ((checkOptions & DBA_NO_PROC_ERROR) == 0) /* PMSTA-13946 - LJE - 120328 */
        {
            char	objString[40];
            const char *sqlName = DBA_GetDictEntitySqlName(object);
            OBJECT_ENUM objEn;		    /* REF2697 - SSO - 000510 */
            const char	    *entitySqlNameIn = NULL;  /* REF2697 - SSO - 000510 */
            char	    entityStrIn[13];	    /* REF2697 - SSO - 000510 */

            if (sqlName != NULL)
            {
                strcpy(objString, sqlName);
            }
            else
            {
                sprintf(objString, "unknown(" szFormatObj ")", object);/* REF2697 - SSO - 000510 */
            }

            DBA_GetObjectEnumByDynSt(inputSt, &objEn);  /* REF2697 - SSO - 000510 */
            entitySqlNameIn = DBA_GetDictEntitySqlName(objEn);
            if (entitySqlNameIn == NULL)
            {
                entitySqlNameIn = DBA_GetDynStCName(inputSt);
            }
            if (entitySqlNameIn == NULL)
            {
                sprintf(entityStrIn, "unknown(%d)", inputSt);
                entitySqlNameIn = entityStrIn;
            }

            DBA_LogMesgProcedureNotFound(Check, object, role, inputSt, inputData, NullDynSt, false, "Check", objString, entitySqlNameIn, "none");  /* PMSTA-24985 - 111016 - PMO */
        }
        return(RET_DBA_ERR_PROCNOTFOUND);
    }

    /* If no connection number is given */
    if ((checkOptions & DBA_SET_CONN) != DBA_SET_CONN)
    {
        /* Get a free connection */
        /* PSMTA-30240 - DLA - 180221 */
        if ((dbiConn = DBA_GetDbiConnection(SqlServer)) == nullptr)
        {
            MSG_RETURN(RET_DBA_ERR_CONNOTFOUND);
        }
    }
    else
    {
        /* If a connection number is given */
        if (allocConn != NULL) /* FPL-PMSTA06305-080508 */
        {
            dbiConn = DBA_GetDbiConnFromConnectNo(*allocConn);
            if (dbiConn == nullptr) {
                return RET_DBA_ERR_CONNOTFOUND;
            }
        }
        else
        {
            MSG_RETURN(RET_DBA_ERR_ARGNOMATCH);
        }
    }

    retCode = DBA_Check(object,
                        role,
                        inputSt,
                        inputData,
                        checkOptions,
                        *dbiConn,
                        msgStructPtr);

    bool isInError = (retCode == RET_DBA_ERR_DIALOG);
    if (isInError)
    {
        dbiConn->setValidConnection(false);
    }

    if ((checkOptions & DBA_NO_CLOSE) != DBA_NO_CLOSE)
    {
        DBA_EndConnection(&dbiConn, isInError);
    }

    return retCode;
}

/************************************************************************
*   Function               : DBA_Check()
*
*   Description            : Send a CHECK (call a stored procedure begining wich "chk_..."
*                            request to the server and retrieve returned status
*
*   Arguments              : object       : the request corresponding object
*                            role         : the role associated to the procedure
*                            inputSt      : the input dynamic struct. format
*                            inputData    : the pointer on the input dynamic struct.
*                            checkOptions : can be DBA_SET_CONN, DBA_NO_CLOSE
*                            allocConn    : a reference on dbiConnection
*                            checkStatus  : indicate the Check result status
*                            msgStructPtr : pointer on a message structure
*
*   Return                 : RET_SUCCEED              : if ok
*                            RET_DBA_ERR_ARGNOMATCH   : if problem with arguments
*                            RET_DBA_ERR_CONNOTFOUND  : if no connection found
*                            RET_DBA_ERR_PROCNOTFOUND : if no proc. was found
*                            RET_DBA_ERR_SETPARAM     : if error while setting proc. param.
*                            RET_DBA_ERR_DBPROBLEM    : if connection/DB problem
*
*   Creation date          : Aug.  94 - PEC
*   Last moditication date : 29.08.95 - PEC
*                            03.10.96 - PEC - Ref.: DVP166 - Adaptation de la fonction aux normes 2
*                                                          - Refonte totale de la fonction
*                            PMSTA-46404 - DDV - 211005 - Remove checkStatus parameter
*************************************************************************/
RET_CODE DBA_Check(OBJECT_ENUM          object,
                   int                  role,
                   DBA_DYNST_ENUM       inputSt,
                   DBA_DYNFLD_STP       inputData,
                   int                  checkOptions,
                   DbiConnection&       dbiConn,
                   DBA_ERRMSG_INFOS_STP msgStructPtr)
{
    DbiConnectionHelper dbiConnHelper(&dbiConn, false);
    dbiConnHelper.dbaSetOptions(checkOptions | DBA_SET_CONN | DBA_NO_CLOSE);
    RET_CODE ret = DBA_Check(object,
                            role,
                            inputSt,
                            inputData,
                            dbiConnHelper);

    dbiConn.sendAllMsg();

    return ret;
}

/************************************************************************
*   Function               : DBA_Check()
*
*   Description            : Send a CHECK (call a stored procedure begining wich "chk_..."
*                            request to the server and retrieve returned status
*
*   Arguments              : object       : the request corresponding object
*                            role         : the role associated to the procedure
*                            inputSt      : the input dynamic struct. format
*                            inputData    : the pointer on the input dynamic struct.
*                            dbiConnHelper: a reference on a dbiConnectionHelper
*                            checkStatus  : indicate the Check result status
*
*   Return                 : RET_SUCCEED              : if ok
*                            RET_DBA_ERR_ARGNOMATCH   : if problem with arguments
*                            RET_DBA_ERR_CONNOTFOUND  : if no connection found
*                            RET_DBA_ERR_PROCNOTFOUND : if no proc. was found
*                            RET_DBA_ERR_SETPARAM     : if error while setting proc. param.
*                            RET_DBA_ERR_DBPROBLEM    : if connection/DB problem
*
*   Creation date          : Aug.  94 - PEC
*   Last moditication date : 29.08.95 - PEC
*                            03.10.96 - PEC - Ref.: DVP166 - Adaptation de la fonction aux normes 2
*                                                          - Refonte totale de la fonction
*                            PMSTA-24985 - 111016 - PMO : Connection crash
*                            PMSTA-31073 - 010518 - PMO : Cash portfolio fusion launching doesn't work on Oracle
*                            PMSTA-46404 - DDV - 211005 - Remove checkStatus parameter
*
*************************************************************************/
RET_CODE DBA_Check(OBJECT_ENUM           object,
                    int                  role,
                    DBA_DYNST_ENUM       inputSt,
                    DBA_DYNFLD_STP       inputData,
                    DbiConnectionHelper& dbiConnHelper)
{
#ifdef AAAPROFILER
    ZoneScopedNS("DBA_Check", 5);
#endif

    DbaCallGuard         dbaCallGuard(dbiConnHelper); /* PMSTA-45413 - LJE - 210804 */
    DBI_INT              resultType, status;
    RET_CODE             finalResult = RET_SUCCEED;

    /* Retrieve a procedure in the object procedures list */
    DBA_PROC_STP procedure = DBA_GetStoredProcs(Check, object, role, inputSt, inputData, NullDynSt);

    /* If no procedure */
    if (procedure == NULL)
    {
        const int checkOptions = dbiConnHelper.dbaGetOptions();

        if ((checkOptions & DBA_NO_PROC_ERROR) == 0) /* PMSTA-13946 - LJE - 120328 */
        {
            char	objString[40];
            const char	*sqlName = DBA_GetDictEntitySqlName(object);
            OBJECT_ENUM objEn;		    /* REF2697 - SSO - 000510 */
            const char	    *entitySqlNameIn = NULL;  /* REF2697 - SSO - 000510 */
            char	    entityStrIn[13];	    /* REF2697 - SSO - 000510 */

            if (sqlName != NULL)
            {
                strcpy(objString, sqlName);
            }
            else
            {
                sprintf(objString, "unknown(" szFormatObj ")", object);/* REF2697 - SSO - 000510 */
            }

            DBA_GetObjectEnumByDynSt(inputSt, &objEn);  /* REF2697 - SSO - 000510 */
            entitySqlNameIn = DBA_GetDictEntitySqlName(objEn);
            if (entitySqlNameIn == NULL)
            {
                entitySqlNameIn = DBA_GetDynStCName(inputSt);
            }
            if (entitySqlNameIn == NULL)
            {
                sprintf(entityStrIn, "unknown(%d)", inputSt);
                entitySqlNameIn = entityStrIn;
            }

            DBA_LogMesgProcedureNotFound(Check, object, role, inputSt, inputData, NullDynSt, false, "Check", objString, entitySqlNameIn, "none");  /* PMSTA-24985 - 111016 - PMO */
        }
        return(RET_DBA_ERR_PROCNOTFOUND);
    }
    dbiConnHelper.setCurrProcedure(procedure);  /* PMSTA-45413 - LJE - 210804 */

    if (dbiConnHelper.isValidAndInit() == false)
    {
        return(RET_DBA_ERR_CONNOTFOUND);
    }

    if (USE_NEW_ACCESS_API(dbiConnHelper.getConnection()))
    {
        RequestHelper requestHelper(dbiConnHelper);

        if (requestHelper.startProcedureCall(procedure, inputData) == false)
        {
            return(requestHelper.getLastResultRetCode());
        }

        status = requestHelper.getLastStatus();
    }
    else
    {
        /* DLA - PMSTA09887 - 110303 maybe useless*/
        DBA_TruncateDynStStringToMDLength(inputData);

        /* Retrieve and memorize parameters names and types in the meta dictionary tables */
        if (DBI_SetProcParameters(*dbiConnHelper.getConnection(), inputSt, inputData, procedure) != RET_SUCCEED)
        {
            dbiConnHelper.getConnection()->releaseCommand();
            MSG_RETURN(RET_DBA_ERR_SETPARAM);
        }

        /* Send the request to the server */
        if (dbiConnHelper.getConnection()->sendRequest(&resultType) != RET_SUCCEED)
        {
            dbiConnHelper.getConnection()->releaseCommand();
            dbiConnHelper.sendAllMsg();
            return RET_DBA_ERR_DBPROBLEM;
        }

        if (resultType != DBI_STATUS_RESULT && resultType != DBI_CMD_SUCCEED)
        {
            dbiConnHelper.getConnection()->releaseCommand();
            MSG_RETURN(RET_DBA_ERR_DBPROBLEM);
        }

        dbiConnHelper.getConnection()->processAllResults(&status, GET_OBJ_DYNST(inputSt), inputSt, inputData, procedure);
        dbiConnHelper.getConnection()->filterMsgInfos(&finalResult);
    }

    if (finalResult != RET_SUCCEED)
        return(finalResult);

    if (EV_ExtractFile && EV_SetProcParametersFlg)
    {
        DATE_ResetTimer(EV_ExtractFileTimerPtr, TIMER_MASK_GEN);
        DATE_StartTimer(EV_ExtractFileTimerPtr, TIMER_MASK_GEN);
        EV_SetProcParametersFlg = FALSE;
    }

    return(RET_SUCCEED);
}

/*************************************************************************
*   Function        :   DBA_ReconnectIfNeed()
*
*   Description     :   When a connection is down, drop the connection and open a new coneection
*
*   Arguments       :   connectNo       Number of the connection
*
*   Return          :   None
*
*   Creation Date   :   REF10883 - R.4.20 - Race condition when initializing the dispatcher
*   Last Modif.     :
*
*************************************************************************/
RET_CODE DBA_ReconnectIfNeed(DbiConnection& dbiConn)
{
	RET_CODE res = RET_SUCCEED;
	if (!dbiConn.isValid()) {
		if (AAALocalConnectionProvider::get().reconnect(dbiConn) == false) {
			res = RET_DBA_ERR_CONNLOST;
		}
	}
	return res ;
}


/************************************************************************
*   Function             : DBA_Purge()
*
*   Description          : Call DBA_Truncate or DBA_Delete
*                          returned status
*
*   Arguments            : object       : the request corresponding object
*                          role         :
*                          inputSt      : the input dynamic struct. format
*                          inputData    : the pointer on the input dynamic struct.
*                          notifOptions : can be DBA_SET_CONN, DBA_NO_CLOSE
*                          allocConn    : a connection number pointer
*                          msgStructPtr : message structure pointer
*
*   Return               : RET_SUCCEED              : if ok
*                          RET_DBA_ERR_ARGNOMATCH   : if input arg. problem
*                          RET_DBA_ERR_PROCNOTFOUND : if no procedure founded
*                          RET_DBA_ERR_SETPARAM     : if problem while setting proc. parameters
*                          RET_DBA_ERR_CONNOTFOUND  : if no connection founded
*                          RET_DBA_ERR_DBPROBLEM    : if DB/connection problem
*                          RET_DBA_ERR_SYBBIND      : if poblem while binding received fields
*                          RET_MEM_ERR_ALLOC        : if allocation failed
*                          RET_GEN_ERR_INVARG       : if problem while setting function params.
*                          a RET_CODE               : if a message has been received
*
*   Created              : PMSTA15008-JPP-20120920
*
*   Last modif.          : PMSTA-16124 - 250413 - PMO : Ensure coherence of printf / scanf formats with 32bits / 64 bits datatypes
*
*************************************************************************/
RET_CODE DBA_Purge(int                  role,
                   DBA_DYNST_ENUM       ,
                   DBA_DYNFLD_STP       inputData,
                   int                  purgeOptions,
                   int *                allocConn,
                   int *                purgeStatus,
                   DBA_ERRMSG_INFOS_STP msgStructPtr)
{

    OBJECT_ENUM         object=NullEntity;
    DICT_ENTITY_STP     dictEntity=NULL;

    /***********************
    ***  Get the entity  ***
    ***********************/
	dictEntity = DBA_GetEntityBySqlName(GET_SYSNAME(inputData, A_PurgeEntity_Sqlname));
	if  (dictEntity != NULL)
		DBA_GetObjectEnum( dictEntity->entDictId , &object);

    if (object==NullEntity)
	{
        char szError[300];
        sprintf(szError, "DBA_Purge() - Exit with error : entity unknow '%s'",GET_SYSNAME(inputData, A_PurgeEntity_Sqlname));
		MSG_LogSrvMesg(UNUSED, UNUSED, szError);
		return(RET_GEN_ERR_INVARG);
	}

    /***************************************************************************/
    /* DELETE command forbiden (filter not null or not empty)                  */
    /***************************************************************************/
    if (IS_NULLFLD(inputData, A_PurgeEntity_Filter) == FALSE)
    {
        char *  pszFilter = NULL;
        int     i=0;

        /* filter is empty ?*/
        pszFilter = GET_VARSTRING15000(inputData, A_PurgeEntity_Filter);
        i = SYS_StrLen(pszFilter);                                              /* PMSTA-16124 - 250413 - PMO */
        while ( --i != -1 && isspace( (int)pszFilter[i]));
        if ( i>0 )
        {
#define ERR_DBAPURGE "DBA_Purge() - DELETE command not yet implemented. Filter parameter forbiden '%s'"

            char szFilter[200];
            char szError[sizeof(szFilter) + sizeof(ERR_DBAPURGE)];

            /* filter not empty => error */
            strncpy(szFilter, pszFilter, sizeof(szFilter)-1);
            szFilter[sizeof(szFilter)-1]='\0';
            sprintf(szError, ERR_DBAPURGE, szFilter);
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, szError);
            return(RET_DBA_ERR_SETPARAM);
#undef ERR_DBAPURGE
        }
    }
    /***************************************************************************/
    /* Actually only call DBA_Truncate is managed */
    return (DBA_Truncate(object,
                         role,
                         purgeOptions,
                         allocConn,
                         purgeStatus,
                         msgStructPtr));
}


/************************************************************************
*   Function             : DBA_Truncate()
*
*   Description          : Send a Truncate request to the server and retrieve
*                          returned status
*
*   Arguments            : object       : the request corresponding object
*                          role         :
*                          inputSt      : the input dynamic struct. format
*                          inputData    : the pointer on the input dynamic struct.
*                          notifOptions : can be DBA_SET_CONN, DBA_NO_CLOSE
*                          allocConn    : a connection number pointer
*                          msgStructPtr : message structure pointer
*
*   Return               : RET_SUCCEED              : if ok
*                          RET_DBA_ERR_ARGNOMATCH   : if input arg. problem
*                          RET_DBA_ERR_PROCNOTFOUND : if no procedure founded
*                          RET_DBA_ERR_SETPARAM     : if problem while setting proc. parameters
*                          RET_DBA_ERR_CONNOTFOUND  : if no connection founded
*                          RET_DBA_ERR_DBPROBLEM    : if DB/connection problem
*                          RET_DBA_ERR_SYBBIND      : if poblem while binding received fields
*                          RET_MEM_ERR_ALLOC        : if allocation failed
*                          RET_GEN_ERR_INVARG       : if problem while setting function params.
*                          a RET_CODE               : if a message has been received
*
*  Last modif.           : PMSTA-24985 - 111016 - PMO : Connection crash
*
*************************************************************************/
RET_CODE DBA_Truncate(OBJECT_ENUM    object,
                   int             role,
                   int             truncateOptions,
                   int             *allocConn,
                   int             *truncateStatus,
                   DBA_ERRMSG_INFOS_STP msgStructPtr)
{
    /* Retrieve a procedure in the object procedures list */
    DBA_PROC_STP procedure =  DBA_GetStoredProcs(Truncate, object, role, NullDynSt, NULL, NullDynSt);

	/* If no procedure */
	if (procedure == NULL)
	{
        OBJECT_ENUM objEn;

		if ((truncateOptions & DBA_NO_PROC_ERROR) == 0)
		{
		    char	     objString[40];
            const char	    *sqlName = DBA_GetDictEntitySqlName(object);
		    const char	*entitySqlNameIn=NULL;
		    char	     entityStrIn[13];

		    if (sqlName != NULL)
		    {
			    strcpy(objString, sqlName);
		    }
		    else
		    {
			    sprintf(objString, "unknown(" szFormatObj ")",object);
		    }


            DBA_GetObjectEnumByDynSt(A_PurgeEntity, &objEn);
            entitySqlNameIn = DBA_GetDictEntitySqlName(objEn);
	        if (entitySqlNameIn == NULL)
	        {
			    entitySqlNameIn = DBA_GetDynStCName(A_PurgeEntity);
		    }
            if (entitySqlNameIn == NULL)
            {
                sprintf(entityStrIn,"unknown(%d)",A_PurgeEntity);
                entitySqlNameIn = entityStrIn;
            }

            DBA_LogMesgProcedureNotFound(Truncate, object, role, NullDynSt, nullptr, NullDynSt, false, "Truncate", objString, entitySqlNameIn, "none");  /* PMSTA-24985 - 111016 - PMO */
		}
        return(RET_DBA_ERR_PROCNOTFOUND);
	}

    DbiConnectionHelper dbiConnHelper;
    RequestHelper requestHelper(dbiConnHelper);

    requestHelper.startProcedureCall(procedure, nullptr);

    return(requestHelper.getLastResultRetCode());
}


/************************************************************************
**   END  dbalib05.c                                                   **
*************************************************************************/
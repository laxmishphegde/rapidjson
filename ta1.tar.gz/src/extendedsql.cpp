/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/*****************************************************************************
 ** **
 ** **  Function    :   All Member Functions
 ** **
 ** **  Description :   All Member Functions of
 ** **                      Class ExtendedSql and OraSqlLoader
 ** **
 ** **  Created     :   PMSTA-36178 - KNI - Load Service - 190716
 ** **
 ** *************************************************************************/

/*****************************************************************************
*  DEFINES
******************************************************************************/
#define EXTENDEDSQL_C


/*****************************************************************************
*  INCLUDES
******************************************************************************/
#ifdef NTWIN
#pragma warning (push)
#define popen _popen
#define pclose _pclose
#endif

#include <QDir>

#include "unidef.h"     /* Mandatory */
#include "dba.h"
#include "csrv.h"
#include "ddlgentable.h"
#include "ddlgenindex.h"
#include "ddlgenfromfile.h"
#include "ddlgencfgfile.h"

#include "extendedsql.h"
#include "crypto-openssl.h"
#include "tls.h"
#include "conv.h"
#include "aaatelemetry.h"

#ifdef NTWIN
#pragma warning (pop)
#endif

const std::string SET_STR     = "SET ";
const std::string REM_STR     = "REM ";
const std::string DIR_SEP     = "/";
const char        DECIMAL_SEP = '.';

/************************************************************************
**      External Data Definitions
*************************************************************************/

extern DBA_RDBMS_ENUM EV_RdbmsVendor;
extern char           SV_User[MAX_USERINFO_LEN + 1];

/*****************************************************************************
 ** **
 ** **  Function    :   ExtendedSql::ExtendedSql()
 ** **
 ** **  Description :   ExtendedSql Constructor
 ** **
 ** **  Created     :   PMSTA-36178 - KNI - Load Service - 190716
 ** **
 ** *************************************************************************/
ExtendedSql::ExtendedSql()
    : m_directPath(0)
    , m_parallelLoad(0)
    , m_datasetId(0)
{
}

/*****************************************************************************
 ** **
 ** **  Function    :   ExtendedSql::~ExtendedSql()
 ** **
 ** **  Description :   ExtendedSql Destructor
 ** **
 ** **  Created     :   PMSTA-36178 - KNI - Load Service - 190716
 ** **
 ** *************************************************************************/
ExtendedSql::~ExtendedSql()
{
}

/****************************************************************************
 ** **
 ** **  Function    :   ExtendedSql::usage()
 ** **
 ** **  Description :   Usage for ExtendedSql service.
 ** **
 ** **  Created     :   PMSTA-36178 - KNI - Load Service - 190716
 ** **
 ** *************************************************************************/
void ExtendedSql::usage(void)
{
    fprintf(stderr,
            "usage: aaa_sql loader -U <user> -P <password> [-C <controlfile>] [-L <log>] [-i <inputfile>]            \n"
            "               [-B <badfile>] [-D <discardfile>] [-d <direct>] [-p <parallel>] [-c <business entity>]   \n"
            "       with  <-U>       : SQL Server Username                                                           \n"
            "             <-P>       : SQL Server Password                                                           \n"
            "             <-C>       : Control file name, which describes the table.                                 \n"
            "             <-L>       : Log file name, which will have the logs                                       \n"
            "             <-B>       : Bad file name, which will have the records those created errors.              \n"
            "             <-D>       : Discard file name, which will have the discarded records.                     \n"
            "             <-d>       : Use Direct Path                                                               \n"
            "                           0 -> Conventional Path                                                       \n"
            "                           1 -> Direct Path                                                             \n"
            "                           2 -> Not SQL loader conventional                                             \n"
            "                           3 -> Not SQL loader index and triggers disabled                              \n"
            "                            ( Default is 0 )                                                            \n"
            "             <-i>       : Input file name, which holds the formatted data to be loaded.                 \n"
            "                           - Optional, if control file is provided                                      \n"
            "                             ( input file name should be specified in control file )                    \n"
            "             <-p>       : Use parallel Load                                                             \n"
            "                           0 -> Do not use Parallel Load                                                \n"
            "                           1 -> Do Parallel Load                                                        \n"
            "                           n -> Do on n Parallel Load (not for Oracle SQL loader)                       \n"
            "                            ( Default is 0 )                                                            \n"
            "             <-c>       : Business Entity (only use with multi-entity configuration)                    \n"
            "                          <business entity> : Business entity to use                                    \n"
    );
}


/*****************************************************************************
 ** **
 ** **  Function    :   ExtendedSql::setUser()
 ** **
 ** **  Description :   To set the User
 ** **
 ** **  Arguments   :   i_user ( Command Line argument )
 ** **
 ** **  Created     :   PMSTA-36178 - KNI - Load Service - 190716
 ** **
 ** *************************************************************************/
void ExtendedSql::setUser(const char * i_user)
{
    m_user = i_user;
}

/*****************************************************************************
 ** **
 ** **  Function    :   ExtendedSql::setPassword()
 ** **
 ** **  Description :   To set the User
 ** **
 ** **  Arguments   :   i_password ( Command Line argument or
 ** **                                fetched from the encrypted Password file )
 ** **
 ** **  Created     :   PMSTA-36178 - KNI - Load Service - 190716
 ** **
 ** *************************************************************************/
void ExtendedSql::setPassword(const char * i_password)
{
    m_password.setClearPassword(PasswordClear(i_password));
    GEN_SetUserInfo(UserPasswd, &m_password);
}

void ExtendedSql::setPassword(PasswordEncrypted *i_password)
{
    m_password = PasswordEncrypted(*i_password);
    GEN_SetUserInfo(UserPasswd, &m_password);
}

/*****************************************************************************
 ** **
 ** **  Function    :   ExtendedSql::getUser()
 ** **
 ** **  Description :   To get the User Code
 ** **
 ** **  Return      :   User Code in String format
 ** **
 ** **  Created     :   PMSTA-36178 - KNI - Load Service - 190716
 ** **
 ** *************************************************************************/
const std::string & ExtendedSql::getUser(void)
{
    return m_user;
}

/*****************************************************************************
 ** **
 ** **  Function    :   ExtendedSql::getPassword()
 ** **
 ** **  Description :   To get the Encrypted Password
 ** **
 ** **  Return      :   Password in PasswordEncrypted format
 ** **
 ** **  Created     :   PMSTA-36178 - KNI - Load Service - 190716
 ** **
 ** *************************************************************************/
const PasswordEncrypted & ExtendedSql::getPassword(void)
{
    return m_password;
}

/*****************************************************************************
 ** **
 ** **  Function    :   ExtendedSql::removeExtSqlArg()
 ** **
 ** **  Description :   To remove the first argument after the executable name
 ** **                     i.e. loader as this gives error in Windows
 ** **                     platform while using SYS_Getopt()
 ** **
 ** **  Arguments   :   argNbr, argv and argvNew( This will have the trimmed data )
 ** **
 ** **  Return      :   ExtendedSqlExitVal and the new data is sent with the pointer argvNew
 ** **
 ** **  Created     :   PMSTA-36178 - KNI - Load Service - 190716
 ** **
 ** *************************************************************************/
void ExtendedSql::removeExtSqlArg(int *argNbr, char **argv, std::vector<std::string> & argvNew)
{
    for (int i = 0; i < *argNbr; i++)
    {
        if (strcasecmp(argv[i], "loader") != 0)
        {
            argvNew.push_back(argv[i]);
        }
    }

    --(*argNbr); //decreasing count of arguments by one as one argument is already removed.
}

/************************************************************************
**
**  Function    :   ExtendedSql::startup()
**
**  Description :
**
**  Argument    :   user
**                  password
**
**  Return      :   ExtendedSqlExitVal
**
**  Last modif. :   PMSTA-55968 - LJE - 240712
**
*************************************************************************/
ExtendedSqlExitVal ExtendedSql::startup()
{
    ExtendedSqlExitVal retVal = ExtendedSqlExitVal::EXT_SQL_FAIL;

    if (CSRV_Init(false) == RET_SUCCEED)
    {
        if (GEN_AppLogin(this->getUser().c_str(), this->getPassword()) == RET_SUCCEED &&
            DBA_InitDictInfo() == RET_SUCCEED)
        {
            DBA_LoadAndCheckDbTimeZone(false);
            if (GEN_InitPoolConnectionFinal() == RET_SUCCEED)
            {
                retVal = ExtendedSqlExitVal::EXT_SQL_SUCCESS;
            }
        }
    }

    return retVal;
}


/*****************************************************************************
 ** **
 ** **  Function    :   ExtendedSql::mainIdentifyHostExec()
 ** **
 ** **  Description :   To identify which Extended Sql service is to be trigerred
 ** **                     As of now only OraSqlLoader is implemented.
 ** **                  If the HIDE_ARGS has been set then the arguments will be
 ** **                     retrieved from the AAA_STARTUP_PARAMS.
 ** **
 ** **  Arguments   :   argc and argv
 ** **
 ** **  Return      :   ExtendedSqlExitVal
 ** **
 ** **  Created     :   PMSTA-36178 - KNI - Load Service - 190716
 ** **
 ** *************************************************************************/
ExtendedSqlExitVal ExtendedSql::mainIdentifyExecExtSql(int argc, char **argv)
{
    ExtendedSqlExitVal retVal = ExtendedSqlExitVal::NOT_EXT_SQL_SERVICE;
    char *hideArgsFlg         = SYS_GetEnv("HIDE_ARGS");
    char *startupParam        = SYS_GetEnv("AAA_STARTUP_PARAMS");
    MemoryPool mp;

    std::vector<std::string> argTabNew;

    if (hideArgsFlg != nullptr && strcmp(hideArgsFlg, "1") == 0 &&
        startupParam != nullptr)
    {
        int    argNbr = 0;
        char **argTab = nullptr;

        if (GEN_TreatStartupParams(startupParam, argv, &argNbr, &argTab, mp) == FALSE)
        {
            return ExtendedSqlExitVal::NOT_EXT_SQL_SERVICE;
        }

        if (argNbr > 1)
        {
            if (strcasecmp(argTab[1], "loader") == 0)
            {
                removeExtSqlArg(&argNbr, argTab, argTabNew);
            }
        }
    }
    else
    {
        if (argc > 1)
        {
            if (strcasecmp(argv[1], "loader") == 0 ||
                (argc > 2 && strcasecmp(argv[2], "loader") == 0))
             {
                if (argv[1][0] == '-' && argv[1][1] == 'C')
                {
                    removeExtSqlArg(&argc, argv, argTabNew);

                    argTabNew.erase(argTabNew.begin() + 1);
                    SYS_LoadCfgFile(&argv[1][2]);
                }
                else
                {
                    removeExtSqlArg(&argc, argv, argTabNew);
                }
            }
        }
    }

    if (argTabNew.empty() == false)
    {
        if (SYS_InitLockTable() != TRUE)
        {
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "SYS_InitLockTable() failed");
            return ExtendedSqlExitVal::EXT_SQL_FAIL;
        }

        if (this->getOption(argTabNew) != ExtendedSqlExitVal::EXT_SQL_SUCCESS)
        {
            usage();
            return ExtendedSqlExitVal::EXT_SQL_FAIL;
        }

        AAALogger::Initializer loggerInitialiser;

        CURRENTCHARSETCODE_ENUM charsetCode = CurrentCharsetCode_UTF8;
        GEN_SetApplInfo(ApplCurrentCharsetCodeEnum, &charsetCode);

        SYSNAME_T initName = "";
        GEN_SetApplInfo(ApplSqrDbName, initName);
        GEN_SetApplInfo(ApplPermTslDbName, initName);
        GEN_SetApplInfo(ApplTempTslDbName, initName);

        EV_WarningMsg = FALSE;

        GEN_InitApplName();

        // Telemetry Init after appl name initialisation
        AAATelemetry::Initializer telemetryInitializer(/*startByDefault*/false);

        loggerInitialiser.configure(false /*startWatcherThread*/);
        telemetryInitializer.configure();

        if (GEN_Initial() != RET_SUCCEED)
        {
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "GEN_Initial() failed");
            return ExtendedSqlExitVal::EXT_SQL_FAIL;
        }

        DbiSqlLoader* sqlloaderPtr = nullptr;
        if (EV_RdbmsVendor == Oracle && this->getDirectPath() < 2)
        {
            sqlloaderPtr = new OraSqlLoader(*this);
        }
        else
        {
            sqlloaderPtr = new GenSqlLoader(*this);
        }
        mp.ownerObject(sqlloaderPtr);

        retVal = sqlloaderPtr->mainSqlLoad();
    }
    
    return retVal;
}

/*****************************************************************************
 ** **
 ** **  Function    :   ExtendedSql::validateInputs()
 ** **
 ** **  Description :   
 ** **
 ** **  Created     :   PMSTA-55968 - LJE - 240712
 ** **
 ** *************************************************************************/
ExtendedSqlExitVal ExtendedSql::validateInputs()
{
    if (this->getControlFile().empty() == false && SYS_Access(this->getControlFile().c_str()) == FALSE)
    {
        DdlGenContext  ddlGenContext(UnknownRdbms, true);
        DdlGenMsg      ddlGenMsg(&ddlGenContext);
        ddlGenMsg.printMsg(RET_DBA_ERR_DBPROBLEM, "Control File not found");
        return ExtendedSqlExitVal::EXT_SQL_FAIL;
    }

    if (this->getUser().empty())
    {
        return ExtendedSqlExitVal::EXT_SQL_USAGE_FAIL;
    }

    PasswordEncrypted * pE = nullptr;
    GEN_GetUserInfo(UserPasswd, &pE);
    if ((pE->isValidPassword() == false))
    {
        RET_CODE ret_code = SYS_AutoLogin(this->getUser().c_str(), *pE);

        if (ret_code == RET_SUCCEED)
            this->setPassword(pE);
        else
        {
            SYSNAME_T passwd;
            AUTO_PASSWORD_CLEAR(passwd, sizeof(passwd));
            SYS_GetPassword("Password", passwd, MAX_USERINFO_LEN + 1, 0);
            this->setPassword(passwd);
        }
    }
    else
    {
        this->setPassword(pE);
    }

    auto retVal = this->startup();

    return retVal;
}

/****************************************************************************
 ** **
 ** **  Function    :   OraSqlLoader::getOption()
 ** **
 ** **  Description :   reads the input values and sets those values.
 ** **
 ** **  Arguments   :   argc - Number of arguments
 ** **                  argv - the arguments ( first is the executable name )
 ** **
 ** **  Created     :   PMSTA-36178 - KNI - Load Service - 190716
 ** **
 ** *************************************************************************/
ExtendedSqlExitVal ExtendedSql::getOption(std::vector<std::string>& argv)
{
    MemoryPool mp;

    CURRENTCHARSETCODE_ENUM  charsetCode = CurrentCharsetCode_UTF8;

    GEN_SetApplInfo(ApplCurrentCharsetInputEnum, &charsetCode);
    GEN_SetApplInfo(ApplCurrentCharsetOutputEnum, &charsetCode);

    this->setUser(SV_User);

    std::vector<char*> arg;
    arg.reserve(argv.size());

    for (size_t i = 0; i < argv.size(); ++i)
    {
        arg.push_back(TLS_Strdup(argv[i].c_str(), mp));
    }

    int c = 0;
    while ((c = SYS_Getopt(static_cast<int>(arg.size()), arg.data(), "U:P:C:i:L:B:D:p:d:c:vVa:T:k:")) != EOF)
    {
        switch (c)
        {
            case 'U':
                setUser(SYS_GetoptArg());
                SYS_SetThreadUser(getUser().c_str());
                break;

            case 'P':
                setPassword(SYS_GetoptArg());
                break;

            case 'C':
                setControlFile(SYS_GetoptArg());
                break;

            case 'i':
                setInputFile(SYS_GetoptArg());
                break;

            case 'L':
                setLogFile(SYS_GetoptArg());
                break;

            case 'B':
                setBadFile(SYS_GetoptArg());
                break;

            case 'D':
                setDiscardFile(SYS_GetoptArg());
                break;

            case 'a':
                this->setAppendMode(SYS_GetoptArg());
                break;

            case 'k':
                this->setDatasetId(atoll(SYS_GetoptArg()));
                break;

            case 'T':
                this->setTableName(SYS_GetoptArg());
                break;

            case 'p':
                setParallelLoad(atoi(SYS_GetoptArg()));
                break;

            case 'd':
                setDirectPath(atoi(SYS_GetoptArg()));
                break;

            case 'V':
                GEN_AnalyseVersion((char)c);
                GEN_DisplayEnv();
                SYS_Shutdown(EXIT_SUCCESS);
                break;

            case 'v':
                GEN_AnalyseVersion((char)c);
                SYS_Shutdown(EXIT_SUCCESS);
                break;

            case 'c':
                SYS_GetThread().setCurrBusinessEntity(SYS_GetoptArg());
                break;

            default:
                return ExtendedSqlExitVal::EXT_SQL_USAGE_FAIL;
        }
    }

    return ExtendedSqlExitVal::EXT_SQL_SUCCESS;
}

/*****************************************************************************
 ** **
 ** **  Function    :   OraSqlLoader::setInputFile()
 ** **
 ** **  Description :   To set Input File
 ** **
 ** **  Arguments   :   i_inputFile ( Command Line argument )
 ** **
 ** **  Created     :   PMSTA-36178 - KNI - Load Service - 190716
 ** **
 ** *************************************************************************/
void ExtendedSql::setInputFile(const char * i_inputFile)
{
    m_inputFile = i_inputFile;
}

/*****************************************************************************
 ** **
 ** **  Function    :   OraSqlLoader::setControlFile()
 ** **
 ** **  Description :   To set Control File
 ** **
 ** **  Arguments   :   i_controlFile ( Command Line argument )
 ** **
 ** **  Created     :   PMSTA-36178 - KNI - Load Service - 190716
 ** **
 ** *************************************************************************/
void ExtendedSql::setControlFile(const char * i_controlFile)
{
    m_controlFile = i_controlFile;
}

/*****************************************************************************
 ** **
 ** **  Function    :   OraSqlLoader::setLogFile()
 ** **
 ** **  Description :   To set Log File
 ** **
 ** **  Arguments   :   i_logFile ( Command Line argument )
 ** **
 ** **  Created     :   PMSTA-36178 - KNI - Load Service - 190716
 ** **
 ** *************************************************************************/
void ExtendedSql::setLogFile(const char * i_logFile)
{
    m_logFile = i_logFile;
}

/*****************************************************************************
 ** **
 ** **  Function    :   OraSqlLoader::setBadFile()
 ** **
 ** **  Description :   To set Bad File
 ** **
 ** **  Arguments   :   i_badFile ( Command Line argument )
 ** **
 ** **  Created     :   PMSTA-36178 - KNI - Load Service - 190716
 ** **
 ** *************************************************************************/
void ExtendedSql::setBadFile(const char * i_badFile)
{
    m_badFile = i_badFile;
}

/*****************************************************************************
 ** **
 ** **  Function    :   OraSqlLoader::setDiscardFile()
 ** **
 ** **  Description :   To set Discard File
 ** **
 ** **  Arguments   :   i_discardFile ( Command Line argument )
 ** **
 ** **  Created     :   PMSTA-36178 - KNI - Load Service - 190716
 ** **
 ** *************************************************************************/
void ExtendedSql::setDiscardFile(const char * i_discardFile)
{
    m_discardFile = i_discardFile;
}

/*****************************************************************************
 ** **
 ** **  Function    :   OraSqlLoader::setDirectPath()
 ** **
 ** **  Description :   To set whether to use direct path or not
 ** **
 ** **  Arguments   :   i_directPath ( Command Line argument )
 ** **
 ** **  Created     :   PMSTA-36178 - KNI - Load Service - 190716
 ** **
 ** *************************************************************************/
void ExtendedSql::setDirectPath(const int i_directPath)
{
    m_directPath = i_directPath;
}

/*****************************************************************************
 ** **
 ** **  Function    :   OraSqlLoader::setParallelLoad()
 ** **
 ** **  Description :   To set Parallel Load or not
 ** **
 ** **  Arguments   :   i_parallelLoad ( Command Line argument )
 ** **
 ** **  Created     :   PMSTA-36178 - KNI - Load Service - 190716
 ** **
 ** *************************************************************************/
void ExtendedSql::setParallelLoad(const int i_parallelLoad)
{
    m_parallelLoad = i_parallelLoad;
}

/*****************************************************************************
 ** **
 ** **  Function    :   ExtendedSql::setParallelLoad()
 ** **
 ** **  Description :   To set AAAHOME path
 ** **
 ** **  Arguments   :   i_aaaHome ( Command Line argument )
 ** **
 ** **  Created     :   PMSTA-36178 - KNI - Load Service - 190716
 ** **
 ** *************************************************************************/
void ExtendedSql::setAaaHome(const char * i_aaaHome)
{
    m_aaaHome = i_aaaHome;
}

/*****************************************************************************
 ** **
 ** **  Function    :   ExtendedSql::setAppendMode()
 ** **
 ** **  Description :   To set the append mode
 ** **
 ** **  Arguments   :   appendMode ( Command Line argument )
 ** **
 ** **  Created     :   PMSTA-55968 - LJE - 240712
 ** **
 ** *************************************************************************/
void ExtendedSql::setAppendMode(const char* appendMode)
{
    this->m_appendMode = appendMode;
}

/*****************************************************************************
 ** **
 ** **  Function    :   ExtendedSql::setDatasetId()
 ** **
 ** **  Description :   To set the dataset id
 ** **
 ** **  Arguments   :   dataSetId ( Command Line argument )
 ** **
 ** **  Created     :   PMSTA-55968 - LJE - 240712
 ** **
 ** *************************************************************************/
void ExtendedSql::setDatasetId(ID_T dataSetId)
{
    this->m_datasetId = dataSetId;
}

/*****************************************************************************
 ** **
 ** **  Function    :   ExtendedSql::setTableName()
 ** **
 ** **  Description :   To set the table name
 ** **
 ** **  Arguments   :   i_aaaHome ( Command Line argument )
 ** **
 ** **  Created     :   PMSTA-36178 - KNI - Load Service - 190716
 ** **
 ** *************************************************************************/
void ExtendedSql::setTableName(const char* tableName)
{
    this->m_tableName = tableName;
}

/*****************************************************************************
 ** **
 ** **  Function    :   ExtendedSql::getInputFile()
 ** **
 ** **  Description :   To get the Input File Name.
 ** **
 ** **  Return      :   Input File Name in string format.
 ** **
 ** **  Created     :   PMSTA-36178 - KNI - Load Service - 190716
 ** **
 ** *************************************************************************/
const std::string& ExtendedSql::getInputFile(void)
{
    return m_inputFile;
}

/*****************************************************************************
 ** **
 ** **  Function    :   ExtendedSql::getControlFile()
 ** **
 ** **  Description :   To get the Control File Name.
 ** **
 ** **  Return      :   Control File Name in string format.
 ** **
 ** **  Created     :   PMSTA-36178 - KNI - Load Service - 190716
 ** **
 ** *************************************************************************/
const std::string & ExtendedSql::getControlFile(void)
{
    return m_controlFile;
}

/*****************************************************************************
 ** **
 ** **  Function    :   ExtendedSql::getLogFile()
 ** **
 ** **  Description :   To get the Log File Name.
 ** **
 ** **  Return      :   Log File Name in string format.
 ** **
 ** **  Created     :   PMSTA-36178 - KNI - Load Service - 190716
 ** **
 ** *************************************************************************/
const std::string & ExtendedSql::getLogFile(void)
{
    return m_logFile;
}

/*****************************************************************************
 ** **
 ** **  Function    :   ExtendedSql::getBadFile()
 ** **
 ** **  Description :   To get the Bad File Name.
 ** **
 ** **  Return      :   Bad File Name in string format.
 ** **
 ** **  Created     :   PMSTA-36178 - KNI - Load Service - 190716
 ** **
 ** *************************************************************************/
const std::string & ExtendedSql::getBadFile(void)
{
    return this->m_badFile;
}

/*****************************************************************************
 ** **
 ** **  Function    :   ExtendedSql::getDiscardFile()
 ** **
 ** **  Description :   To get the Discard File Name.
 ** **
 ** **  Return      :   Discard File Name in string format.
 ** **
 ** **  Created     :   PMSTA-36178 - KNI - Load Service - 190716
 ** **
 ** *************************************************************************/
const std::string & ExtendedSql::getDiscardFile(void)
{
    return m_discardFile;
}


/****************************************************************************
 ** **
 ** **  Function    :   ExtendedSql::getDiscardFile()
 ** **
 ** **  Description :   To get the Discard File Name.
 ** **
 ** **  Return      :   Discard File Name in string format.
 ** **
 ** **  Created     :   PMSTA-36178 - KNI - Load Service - 190716
 ** **
 ** *************************************************************************/
int ExtendedSql::getDirectPath(void)
{
    return m_directPath;
}

/****************************************************************************
 ** **
 ** **  Function    :   ExtendedSql::getParallelLoad()
 ** **
 ** **  Description :   To get the Parallel Load or not
 ** **
 ** **  Return      :   Is Parallel Load or not in boolean format
 ** **
 ** **  Created     :   PMSTA-36178 - KNI - Load Service - 190716
 ** **
 ** *************************************************************************/
int ExtendedSql::getParallelLoad(void)
{
    if (this->m_parallelLoad < 0)
    {
        this->m_parallelLoad = SYS_GetEnvIntOrDefValue("AAAPARALLELLOAD", 0);
    }

    return m_parallelLoad;
}

/****************************************************************************
 ** **
 ** **  Function    :   ExtendedSql::getAaaHome()
 ** **
 ** **  Description :   To get AAAHOME Path
 ** **
 ** **  Return      :   Append mode in string format
 ** **
 ** **  Created     :   PMSTA-36178 - KNI - Load Service - 190716
 ** **
 ** *************************************************************************/
const std::string& ExtendedSql::getAaaHome(void)
{
    if (this->m_aaaHome.empty())
    {
        this->m_aaaHome = SYS_GetEnvStringOrDefValue("AAAHOME");
    }
    return this->m_aaaHome;
}


/****************************************************************************
 ** **
 ** **  Function    :   ExtendedSql::getAppendMode()
 ** **
 ** **  Description :   To get AAAHOME Path
 ** **
 ** **  Return      :   
 ** **
 ** **  Created     :   PMSTA-55968 - LJE - 240711
 ** **
 ** *************************************************************************/
const std::string& ExtendedSql::getAppendMode(void)
{
    return this->m_appendMode;
}

/****************************************************************************
 ** **
 ** **  Function    :   ExtendedSql::getDatasetId()
 ** **
 ** **  Description :   To get AAAHOME Path
 ** **
 ** **  Return      :
 ** **
 ** **  Created     :   PMSTA-55968 - LJE - 240711
 ** **
 ** *************************************************************************/
ID_T ExtendedSql::getDatasetId(void)
{
    return this->m_datasetId;
}

/****************************************************************************
 ** **
 ** **  Function    :   ExtendedSql::getTableName()
 ** **
 ** **  Description :   To get table name
 ** **
 ** **  Return      :   
 ** **
 ** **  Created     :   PMSTA-55968 - LJE - 240711
 ** **
 ** *************************************************************************/
const std::string& ExtendedSql::getTableName(void)
{
    return this->m_tableName;
}

/****************************************************************************
 ** **
 ** **  Function    :   ExtendedSql::getTimeStamp()
 ** **
 ** **  Description :   To get the current Timestamp which will be used for
 ** **                     Parameter File creation. Gets latest Timestamp
                            only first time later it returns the same value.
 ** **
 ** **  Return      :   TimeStamp in string format
 ** **
 ** **  Created     :   PMSTA-36178 - KNI - Load Service - 190716
 ** **
 ** *************************************************************************/
const std::string& ExtendedSql::getTimeStamp(void)
{
    if (m_timeStamp.empty())
    {
        CurrentTime ct(CurrentTime::Kind::Current);
        m_timeStamp = ct.formatDDMMYYYYHMS();
    }
    return m_timeStamp;
}

/*****************************************************************************
 ** **
 ** **  Function    :   DbiSqlLoader::DbiSqlLoader()
 ** **
 ** **  Description :   DbiSqlLoader Constructor
 ** **
 ** **  Created     :
 ** **
 ** *************************************************************************/
DbiSqlLoader::DbiSqlLoader(ExtendedSql& extendedSql)
    : m_extendedSql(extendedSql)
    , m_ddlGenContext(EV_RdbmsVendor)
    , m_ctlFileHelper(m_ddlGenContext, CfgFileType_ControlFile)
    , m_excludeZeroQty(FALSE)
    , m_decimalSep(0)
{
}

/*****************************************************************************
 ** **
 ** **  Function    :   DbiSqlLoader::~DbiSqlLoader()
 ** **
 ** **  Description :   DbiSqlLoader Destructor
 ** **
 ** **  Created     :   PMSTA-55968 - LJE - 240711
 ** **
 ** *************************************************************************/
DbiSqlLoader::~DbiSqlLoader()
{
}

/****************************************************************************
 ** **
 ** **  Function    :   DbiSqlLoader::getCtlFileHelper()
 ** **
 ** **  Description :   To get control file helper
 ** **
 ** **  Return      :
 ** **
 ** **  Created     :   PMSTA-55968 - LJE - 240711
 ** **
 ** *************************************************************************/
DdlGenCfgFile& DbiSqlLoader::getCtlFileHelper()
{
    return this->m_ctlFileHelper;
}

/****************************************************************************
 ** **
 ** **  Function    :   DbiSqlLoader::getDdlGenContext()
 ** **
 ** **  Description :   To get control file helper
 ** **
 ** **  Return      :
 ** **
 ** **  Created     :   PMSTA-55968 - LJE - 240711
 ** **
 ** *************************************************************************/
DdlGenContext& DbiSqlLoader::getDdlGenContext()
{
    return this->m_ddlGenContext;
}


/****************************************************************************
 ** **
 ** **  Function    :   DbiSqlLoader::getProperty()
 ** **
 ** **  Description :   To get table name
 ** **
 ** **  Return      :
 ** **
 ** **  Created     :   PMSTA-55968 - LJE - 240711
 ** **
 ** *************************************************************************/
const std::string DbiSqlLoader::getProperty(const std::string& key)
{
    return this->m_ctlFileHelper.getProperty(key, true);
}

/****************************************************************************
 ** **
 ** **  Function    :   DbiSqlLoader::isEmptyLine()
 ** **
 ** **  Description :   To get table name
 ** **
 ** **  Return      :
 ** **
 ** **  Created     :   PMSTA-55968 - LJE - 240711
 ** **
 ** *************************************************************************/
bool DbiSqlLoader::isEmptyLine(const std::string& line)
{
    if (line.empty())
    {
        return true;
    }

    auto firstStr = line.substr(line.find_first_not_of(" \t"), 4);
    if (firstStr == SET_STR || firstStr == REM_STR)
    {
        return true;
    }

    return false;
}

/*****************************************************************************
 ** **
 ** **  Function    :   DbiSqlLoader::validateInputs()
 ** **
 ** **  Description :
 ** **
 ** **  Created     :   PMSTA-55968 - LJE - 240712
 ** **
 ** *************************************************************************/
ExtendedSqlExitVal DbiSqlLoader::validateInputs()
{
    if (this->m_extendedSql.validateInputs() != ExtendedSqlExitVal::EXT_SQL_SUCCESS)
        return ExtendedSqlExitVal::EXT_SQL_USAGE_FAIL;

    this->m_ctlFileHelper.setFileName(this->m_extendedSql.getControlFile());

    if (this->m_ctlFileHelper.loadCfgFile() != RET_SUCCEED)
    {
        this->m_ddlGenContext.printMsg(RET_FILE_ERR_NOTEXIST, "Unable to read the control file: " + this->m_extendedSql.getControlFile());
        return ExtendedSqlExitVal::EXT_SQL_USAGE_FAIL;
    }

    if (this->getInputFile().empty() == false && SYS_Access(this->getInputFile().c_str()) == FALSE)
    {
        this->m_ddlGenContext.printMsg(RET_DBA_ERR_DBPROBLEM, "Input File not found");
        return ExtendedSqlExitVal::EXT_SQL_FAIL;
    }

    GEN_GetApplInfo(ApplHCExcludeZeroQty, &this->m_excludeZeroQty);

    auto paralleLoadStr = this->getProperty("AAAPARALLELLOAD");
    if (paralleLoadStr.empty() == false)
    {
        this->m_extendedSql.setParallelLoad(atoi(paralleLoadStr.c_str()));
    }

    return ExtendedSqlExitVal::EXT_SQL_SUCCESS;
}

/*****************************************************************************
 ** **
 ** **  Function    :   DbiSqlLoader::getInputFile()
 ** **
 ** **  Description :   To get the Input File Name.
 ** **
 ** **  Return      :   Input File Name in string format.
 ** **
 ** **  Created     :   PMSTA-55968 - LJE - 240711
 ** **
 ** *************************************************************************/
const std::string& DbiSqlLoader::getInputFile(void)
{
    if (this->m_extendedSql.getInputFile().empty())
    {
        this->m_extendedSql.setInputFile(this->getProperty("INPUT_FILE").c_str());
    }

    return this->m_extendedSql.getInputFile();
}

/****************************************************************************
 ** **
 ** **  Function    :   DbiSqlLoader::getTableName()
 ** **
 ** **  Description :   To get table name
 ** **
 ** **  Return      :
 ** **
 ** **  Created     :   PMSTA-55968 - LJE - 240711
 ** **
 ** *************************************************************************/
const std::string& DbiSqlLoader::getTableName(void)
{
    if (this->m_extendedSql.getTableName().empty() &&
        this->m_ctlFileHelper.m_dictEntitStp != nullptr)
    {
        this->m_extendedSql.setTableName(this->m_ctlFileHelper.m_dictEntitStp->dbSqlName);
    }
    return this->m_extendedSql.getTableName();
}

/****************************************************************************
 ** **
 ** **  Function    :   DbiSqlLoader::getFullTableName()
 ** **
 ** **  Description :   To get table name
 ** **
 ** **  Return      :
 ** **
 ** **  Created     :   PMSTA-55968 - LJE - 240711
 ** **
 ** *************************************************************************/
const std::string DbiSqlLoader::getFullTableName(void)
{
    if (this->m_ctlFileHelper.m_dictEntitStp != nullptr)
    {
        return SYS_Stringer(this->m_ctlFileHelper.m_dictEntitStp->databaseName, ".", this->m_ctlFileHelper.m_dictEntitStp->dbSqlName);
    }
    return this->getTableName();
}

/****************************************************************************
 ** **
 ** **  Function    :   DbiSqlLoader::getFieldSep()
 ** **
 ** **  Description :   To field separator
 ** **
 ** **  Return      :
 ** **
 ** **  Created     :   PMSTA-55968 - LJE - 240711
 ** **
 ** *************************************************************************/
const std::string DbiSqlLoader::getFieldSep(void)
{
    if (this->m_fieldSep.empty())
    {
        this->m_fieldSep = this->getProperty("FIELD_SEPERATOR");
        if (this->m_fieldSep.empty())
        {
            this->m_fieldSep = "~";
        }
    }
    return this->m_fieldSep;
}


/****************************************************************************
 ** **
 ** **  Function    :   DbiSqlLoader::getEnclosedBy()
 ** **
 ** **  Description :   To enclosed by
 ** **
 ** **  Return      :
 ** **
 ** **  Created     :   PMSTA-55968 - LJE - 240711
 ** **
 ** *************************************************************************/
const std::string DbiSqlLoader::getEnclosedBy(void)
{
    if (this->m_enclosedBy.empty())
    {
        this->m_enclosedBy = this->getProperty("ENCLOSED_BY");
        if (this->m_enclosedBy.empty())
        {
            this->m_enclosedBy = "\"";
        }
    }
    return this->m_enclosedBy;
}

/****************************************************************************
 ** **
 ** **  Function    :   DbiSqlLoader::getDecimalSep()
 ** **
 ** **  Description :   Get decimal separator
 ** **
 ** **  Return      :
 ** **
 ** **  Created     :   PMSTA-55968 - LJE - 240711
 ** **
 ** *************************************************************************/
char DbiSqlLoader::getDecimalSep(void)
{
    if (this->m_decimalSep == 0)
    {
        auto decimalSep = this->getProperty("DECIMAL_SEPERATOR");
        if (decimalSep.empty())
        {
            if (CONV_GetDecimSep(&this->m_decimalSep) != RET_SUCCEED)
            {
                this->m_decimalSep = DECIMAL_SEP;
            }
        }
        else
        {
            this->m_decimalSep = decimalSep[0];
        }
    }
    return this->m_decimalSep;
}

/*****************************************************************************
 ** **
 ** **  Function    :   OraSqlLoader::OraSqlLoader()
 ** **
 ** **  Description :   OraSqlLoader Constructor
 ** **
 ** **  Created     :   PMSTA-36178 - KNI - Load Service - 190716
 ** **
 ** *************************************************************************/
OraSqlLoader::OraSqlLoader(ExtendedSql& extendedSql)
    : DbiSqlLoader(extendedSql)
    , m_delParam(false)
{
}

/*****************************************************************************
 ** **
 ** **  Function    :   OraSqlLoader::~OraSqlLoader()
 ** **
 ** **  Description :   OraSqlLoader Destructor
 ** **
 ** **  Created     :   PMSTA-36178 - KNI - Load Service - 190716
 ** **
 ** *************************************************************************/
OraSqlLoader::~OraSqlLoader()
{
}

/****************************************************************************
 ** **
 ** **  Function    :   OraSqlLoader::getOracleHome()
 ** **
 ** **  Description :   To get Oracle Home
 ** **
 ** **  Return      :   Oracle Home in string format
 ** **
 ** **  Created     :   PMSTA-36178 - KNI - Load Service - 190716
 ** **
 ** *************************************************************************/
const std::string & OraSqlLoader::getOracleHome(void)
{
    if (this->m_oracleHome.empty())
    {
        this->m_oracleHome = SYS_GetEnvStringOrDefValue("ORACLE_HOME");
    }
    return m_oracleHome;
}

/****************************************************************************
 ** **
 ** **  Function    :   OraSqlLoader::getOracleSID()
 ** **
 ** **  Description :   To get Oracle SID
 ** **
 ** **  Return      :   Oracle SID in string format
 ** **
 ** **  Created     :   PMSTA-36178 - KNI - Load Service - 190716
 ** **
 ** *************************************************************************/
const std::string & OraSqlLoader::getOracleSID(void)
{
    if (this->m_oracleSID.empty())
    {
        m_oracleSID = SYS_GetEnvStringOrDefValue("DSQUERY");
    }
    return m_oracleSID;
}

/****************************************************************************
 ** **
 ** **  Function    :   OraSqlLoader::getParameterFile()
 ** **
 ** **  Description :   To get the Parameter File Name using the timestamp.
 ** **                    Format of the file will be
 ** **                             parfile-TIMESTAMP.par
 ** **                         prefixed with path like AAAHOME/tmp
 ** **
 ** **  Return      :   Parameter File Name in string format
 ** **
 ** **  Created     :   PMSTA-36178 - KNI - Load Service - 190716
 ** **
 ** *************************************************************************/
const std::string & OraSqlLoader::getParameterFile(void)
{
    if (m_parameterFile.empty())
    {
        if (this->m_extendedSql.getAaaHome().empty())
        {
            this->m_extendedSql.setAaaHome(".");
        }

        m_parameterFile = SYS_Stringer(this->m_extendedSql.getAaaHome(),
                                       (this->m_extendedSql.getAaaHome().compare(".") == 0) ?
                                       SYS_Stringer(DIR_SEP, "parfile-") :
                                       SYS_Stringer(DIR_SEP
                                                    , "tmp"
                                                    , DIR_SEP
                                                    , "parfile-"
                                                    , this->m_extendedSql.getTimeStamp()
                                                    , ".par")
        );
    }
    return m_parameterFile;
}

/****************************************************************************
 ** **
 ** **  Function    :   OraSqlLoader::mainSqlLoad()
 ** **
 ** **  Description :   This is the main function for AAA sqlloader service.
 ** **                      Decides the sequence of execution.
 ** **
 ** **  Arguments   :   argc - Number of arguments
 ** **                  argv - the arguments ( first is the executable name )
 ** **
 ** **  Created     :   PMSTA-36178 - KNI - Load Service - 190716
 ** **
 ** *************************************************************************/
ExtendedSqlExitVal OraSqlLoader::mainSqlLoad()
{
    ExtendedSqlExitVal retCode = this->validateInputs();

    if (retCode == ExtendedSqlExitVal::EXT_SQL_USAGE_FAIL)
    {
        this->m_extendedSql.usage();
        return ExtendedSqlExitVal::EXT_SQL_FAIL;
    }
    else if (retCode != ExtendedSqlExitVal::EXT_SQL_SUCCESS)
        return ExtendedSqlExitVal::EXT_SQL_FAIL;

    retCode = loadSQL();

    if (retCode == ExtendedSqlExitVal::EXT_SQL_USAGE_FAIL)
    {
        this->m_extendedSql.usage();
        return ExtendedSqlExitVal::EXT_SQL_FAIL;
    }
    else if (retCode != ExtendedSqlExitVal::EXT_SQL_SUCCESS && retCode != ExtendedSqlExitVal::EXT_SQL_WARNING)
    {
        return ExtendedSqlExitVal::EXT_SQL_FAIL;
    }

    if (retCode == ExtendedSqlExitVal::EXT_SQL_SUCCESS)
    {
        this->m_ddlGenContext.printMsg(RET_SUCCEED, "Data Loaded successfully");

    }
    else if (retCode == ExtendedSqlExitVal::EXT_SQL_WARNING)
    {
        this->m_ddlGenContext.printMsg(RET_DBA_ERR_HIER_WARN, "Loader execution exited with EX_WARN, see logfile");
    }

    return ExtendedSqlExitVal::EXT_SQL_SUCCESS;
}

/****************************************************************************
 ** **
 ** **  Function    :   OraSqlLoader::loadSQL()
 ** **
 ** **  Description :   This function validates the inputs and then forms the
 ** **                     Parameter file which will be and input to sqlldr.
 ** **                     After that it will execute the Sql and Parallelly
 ** **                     deletes the Parameter file once sqlldr is triggered
 ** **                     for security purposes.
 ** **
 ** **  Return      :   ExtendedSqlExitVal
 ** **
 ** **  Created     :   PMSTA-36178 - KNI - Load Service - 190716
 ** **
 ** *************************************************************************/
ExtendedSqlExitVal OraSqlLoader::loadSQL()
{
    ExtendedSqlExitVal retExecSql = ExtendedSqlExitVal::EXT_SQL_SUCCESS;

    if (this->createDataFile()      == ExtendedSqlExitVal::EXT_SQL_SUCCESS &&
        this->createControlFile()   == ExtendedSqlExitVal::EXT_SQL_SUCCESS &&
        this->createParameterFile() == ExtendedSqlExitVal::EXT_SQL_SUCCESS)
    {
        retExecSql = executeSQL();

        if (retExecSql != ExtendedSqlExitVal::EXT_SQL_SUCCESS && 
            retExecSql != ExtendedSqlExitVal::EXT_SQL_WARNING)
        {
            this->m_ddlGenContext.printMsg(RET_DBA_ERR_DBPROBLEM, "Loader execution Failed. Check the Log File if generated by Loader service");
            preExit(getParameterFile());
            return ExtendedSqlExitVal::EXT_SQL_FAIL;
        }

        DdlGenContext&   ddlGenContext = this->getDdlGenContext();
        auto&            ctlFileHelper = this->getCtlFileHelper();
        auto             ddlGenEntityPtr = ddlGenContext.getDdlGenEntityPtr(ctlFileHelper.m_dictEntitStp->mdSqlName, std::string(), true);
        DdlGenIndex::Ptr ddlGenIndexPtr(new DdlGenIndex(ctlFileHelper.m_dictEntitStp->objectEn, std::string(), ddlGenContext, ddlGenEntityPtr, nullptr, TargetTable_Main));

        auto idxRet = ddlGenIndexPtr->build();

        if (RET_GET_LEVEL(idxRet) == RET_LEV_ERROR)
        {
            retExecSql = ExtendedSqlExitVal::EXT_SQL_FAIL;
        }

        preExit(getParameterFile()); // Making sure the Parameter File is deleted.
        return retExecSql;
    }
    else
    {
        this->m_ddlGenContext.printMsg(RET_DBA_ERR_DBPROBLEM, "Error while generating the Parameter File");
        preExit(getParameterFile()); // Making sure the Parameter File is deleted.
        return ExtendedSqlExitVal::EXT_SQL_FAIL;
    }
}

/****************************************************************************
 ** **
 ** **  Function    :   OraSqlLoader::executeSQL()
 ** **
 ** **  Description :   Executes the sqlldr command
 ** **
 ** **  Arguments   :   COMMAND ( This has the Command that has to be executed )
 ** **
 ** **  Return      :   ExtendedSqlExitVal
 ** **
 ** **  Created     :   PMSTA-36178 - KNI - Load Service - 190716
 ** **
 ** *************************************************************************/
ExtendedSqlExitVal OraSqlLoader::executeSQL()
{
    createCommand();

    int execRc = 0;

    FILE *fp = popen(m_command.c_str(), "w");

    if (!fp)
    {
        m_delParam = true;
        execRc = 1;
    }
    else
    {
        PasswordEncrypted* pE = nullptr;
        GEN_GetUserInfo(UserPasswd, &pE);

        m_delParam = true;
        fprintf(fp, "%s\n", pE->getClearPassword().getPassword());
        execRc = pclose(fp);
    }

    if (execRc != 0)
        execRc = execRc / 256;

    if (execRc == 0)
        return ExtendedSqlExitVal::EXT_SQL_SUCCESS;
    else if (execRc == 2)
        return ExtendedSqlExitVal::EXT_SQL_WARNING;
    else
        return ExtendedSqlExitVal::EXT_SQL_FAIL;
}


/****************************************************************************
 ** **
 ** **  Function    :   OraSqlLoader::getStringParFile()
 ** **
 ** **  Description :   To form conditional strings to put into Parameter File
 ** **
 ** **  Arguments   :   tag ( This is the tag that will be sent )
 ** **                  tagVal ( this will be the value for the above tag )
 ** **                  EntReq ( this denotes whether the string should end
 ** **                              with an enter or not. Default is false )
 ** **
 ** **  Return      :   generated string
 ** **
 ** **  Created     :   PMSTA-36178 - KNI - Load Service - 190716
 ** **
 ** *************************************************************************/
inline std::string OraSqlLoader::getStringParFile(const std::string & tag, const std::string & tagVal, bool EntReq = false)
{
    return SYS_Stringer(tag, "=", tagVal, (EntReq == true) ? "\n" : "");
}


/****************************************************************************
 ** **
 ** **  Function    :   OraSqlLoader::createParameterFile()
 ** **
 ** **  Description :   Creates the Parameter file to send it as an input to sqlldr.
 ** **
 ** **  Return      :   ExtendedSqlExitVal
 ** **
 ** **  Created     :   PMSTA-36178 - KNI - Load Service - 190716
 ** **
 ** *************************************************************************/
ExtendedSqlExitVal OraSqlLoader::createParameterFile(void)
{
    FILEDES parFile;
    RET_CODE parRc = SYS_OpenFile(getParameterFile().c_str(), OPEN_READ_MODE | OPEN_WRITE_MODE | OPEN_CREATE_FILE | OPEN_EXCLUSIVE_WRITE, &parFile);

    if (parRc == RET_SUCCEED)
    {
#ifdef UNIX
        chmod(getParameterFile().c_str(), S_IROTH | S_IWOTH | S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP);
#endif

        std::string parStr = SYS_Stringer(getStringParFile("userid", this->m_extendedSql.getUser().c_str())
                                          , "@"
                                          , getOracleSID()
                                          , "\n"
                                          , (getSqlldrControlFile().empty() == false) ? getStringParFile("control", getSqlldrControlFile(), true) : ""
                                          , (this->getDataFile().empty() == false) ? getStringParFile("data", this->getDataFile(), true) : ""
                                          , (this->m_extendedSql.getLogFile().empty() == false) ? getStringParFile("log", this->m_extendedSql.getLogFile(), true) : ""
                                          , (this->m_extendedSql.getBadFile().empty() == false) ? getStringParFile("bad", this->m_extendedSql.getBadFile(), true) : ""
                                          , (this->m_extendedSql.getDiscardFile().empty() == false) ? getStringParFile("discard", this->m_extendedSql.getDiscardFile(), true) : ""
                                          , getStringParFile("discardmax", "10000", true)
                                          , (this->m_extendedSql.getDirectPath() == 1) ? getStringParFile("DIRECT", "TRUE", true) : getStringParFile("DIRECT", "FALSE", true)
                                          , (this->m_extendedSql.getParallelLoad() > 0) ? getStringParFile("PARALLEL", "TRUE", true) : getStringParFile("PARALLEL", "FALSE", true));

        if (SYS_WriteFile(parFile, const_cast<char*>(parStr.c_str()), (int)parStr.size()) != RET_SUCCEED)
        {
            parRc = RET_FILE_ERR_IO;
        }

        SYS_CloseFile(parFile);
    }

    return (parRc == RET_SUCCEED) ? ExtendedSqlExitVal::EXT_SQL_SUCCESS : ExtendedSqlExitVal::EXT_SQL_FAIL;
}

/****************************************************************************
 ** **
 ** **  Function    :   OraSqlLoader::createControlFile()
 ** **
 ** **  Description :   Creates the SQL loader control file.
 ** **
 ** **  Return      :   ExtendedSqlExitVal
 ** **
 ** **  Created     :   PMSTA-55968 - LJE - 240715
 ** **
 ** *************************************************************************/
ExtendedSqlExitVal OraSqlLoader::createControlFile(void)
{
    FILEDES ctlFile;
    RET_CODE ctlRc = SYS_OpenFile(this->getSqlldrControlFile().c_str(), OPEN_READ_MODE | OPEN_WRITE_MODE | OPEN_CREATE_FILE | OPEN_EXCLUSIVE_WRITE, &ctlFile);

    if (ctlRc == RET_SUCCEED)
    {
#ifdef UNIX
        chmod(this->getSqlldrControlFile().c_str(), S_IROTH | S_IWOTH | S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP);
#endif
        std::stringstream ctlStr;


        ctlStr
            << "load data" << std::endl;

        if (this->m_extendedSql.getAppendMode().empty() ||
            strcasecmp(this->m_extendedSql.getAppendMode().c_str(), "append") == 0)
        {
            ctlStr
                << "append" << std::endl;

        }

        ctlStr
            << "into table " << this->getFullTableName() << std::endl
            << "fields terminated by \"" << this->getFieldSep() << "\"" << std::endl
            << "optionally enclosed by '" << this->getEnclosedBy() << "'" << std::endl
            << "trailing nullcols" << std::endl
            << "(" << std::endl;


        auto &ctlFileHelper = this->getCtlFileHelper();

        bool bFirst = true;
        for (auto& it : ctlFileHelper.m_tableDescVector)
        {
            if (bFirst)
            {
                bFirst = false;
            }
            else
            {
                ctlStr << ", " << std::endl;
            }

            ctlStr << it.first->sqlName;

            if (it.second.empty() == false)
            {
                ctlStr << " DATE '" << it.second << "'";
            }
        }

        if (SYS_GetThreadCurrBusinessEntityId() > 0)
        {
            ctlStr << ", " << std::endl << "owner_business_entity_id";
        }

        ctlStr << std::endl << ")";

        if (SYS_WriteFile(ctlFile, const_cast<char*>(ctlStr.str().c_str()), (int)ctlStr.str().size()) != RET_SUCCEED)
        {
            ctlRc = RET_FILE_ERR_IO;
        }

        SYS_CloseFile(ctlFile);
    }

    return (ctlRc == RET_SUCCEED) ? ExtendedSqlExitVal::EXT_SQL_SUCCESS : ExtendedSqlExitVal::EXT_SQL_FAIL;
}

/****************************************************************************
 ** **
 ** **  Function    :   OraSqlLoader::createDataFile()
 ** **
 ** **  Description :   Creates the data file to send it as an input to sqlldr.
 ** **
 ** **  Return      :   ExtendedSqlExitVal
 ** **
 ** **  Created     :   PMSTA-55968 - LJE - 240715
 ** **
 ** *************************************************************************/
ExtendedSqlExitVal OraSqlLoader::createDataFile(void)
{
    ExtendedSqlExitVal ret = ExtendedSqlExitVal::EXT_SQL_FAIL;

    std::ofstream  dataFile;
    std::fstream   inputFile;

    inputFile.open(this->getInputFile().c_str(), std::ifstream::in);
    dataFile.open(this->getDataFile().c_str(), std::ifstream::out | std::ifstream::binary);

    if (inputFile.fail() == false &&
        dataFile.fail() == false)
    {
        auto &ctlFileHelper = this->getCtlFileHelper();
        size_t quantityPos = 0;
        if (this->m_excludeZeroQty == TRUE && 
            (this->getTableName() == "hc_bo_position") || 
            this->getTableName() == "hc_bo_tax_lot")
        {
            for (auto& it : ctlFileHelper.m_tableDescVector)
            {
                if (strcmp(it.first->sqlName, "quantity_n") == 0)
                {
                    break;
                }

                if (strcmp(it.first->sqlName, "dataset_id") != 0)
                {
                    quantityPos++;
                }
            }
        }

        auto businessEntityId = SYS_GetThreadCurrBusinessEntityId();

        std::string fieldSep = this->getProperty("FIELD_SEPERATOR");
        std::string readDataLine;
        while (std::getline(inputFile, readDataLine))
        {
            if (this->isEmptyLine(readDataLine))
            {
                continue;
            }

            auto           tokenIt = readDataLine.begin();
            if (tokenIt == readDataLine.begin())
            {
                size_t startPos = readDataLine.find_first_not_of(" \t\"");
                if (startPos != 0)
                {
                    readDataLine.erase(0, startPos);
                    readDataLine.erase(readDataLine.size() - 1, 1);
                }
                tokenIt = readDataLine.begin();
            }

            bool           bSkipped = false;
            if (this->m_excludeZeroQty == TRUE)
            {
                std::string    valueStr;
                size_t         tokenPos = 0;
                while (this->getNextToken(readDataLine, tokenIt, valueStr, fieldSep[0], '\"'))
                {
                    if (this->m_excludeZeroQty == TRUE &&
                        tokenPos == quantityPos)
                    {
                        if (valueStr == "0")
                        {
                            bSkipped = true;
                        }
                        break;
                    }
                }
            }
            if (bSkipped)
            {
                continue;
            }

            if (this->m_extendedSql.getDatasetId() != 0)
            {
                dataFile << this->m_extendedSql.getDatasetId() << fieldSep;
            }
            dataFile << readDataLine;

            if (businessEntityId > 0)
            {
                dataFile << fieldSep << businessEntityId;
            }
            dataFile << "\n";
        }

        ret = ExtendedSqlExitVal::EXT_SQL_SUCCESS;
    }

    return ret;
}

/*****************************************************************************
 ** **
 ** **  Function    :   OraSqlLoader::getControlFile()
 ** **
 ** **  Description :   To get the Control File Name.
 ** **
 ** **  Return      :   Control File Name in string format.
 ** **
 ** **  Created     :   PMSTA-55968 - LJE - 240712
 ** **
 ** *************************************************************************/
const std::string& OraSqlLoader::getSqlldrControlFile(void)
{
    if (this->m_sqlldrControlFile.empty())
    {
        if (this->m_extendedSql.getAaaHome().empty())
        {
            this->m_extendedSql.setAaaHome(".");
        }

        this->m_sqlldrControlFile = SYS_Stringer(this->m_extendedSql.getAaaHome()
                                                 , DIR_SEP
                                                 , "tmp"
                                                 , DIR_SEP
                                                 , "loader"
                                                 , DIR_SEP
                                                 , "ldr_"
                                                 , this->m_extendedSql.getTimeStamp()
                                                 , "_"
                                                 , this->getTableName()
                                                 , ".ctl");
    }

    return this->m_sqlldrControlFile;
}


/*****************************************************************************
 ** **
 ** **  Function    :   OraSqlLoader::getDataFile()
 ** **
 ** **  Description :   To get the Data File Name.
 ** **
 ** **  Return      :   Control File Name in string format.
 ** **
 ** **  Created     :   PMSTA-55968 - LJE - 240712
 ** **
 ** *************************************************************************/
const std::string& OraSqlLoader::getDataFile(void)
{
    if (this->m_dataFile.empty())
    {
        if (this->m_extendedSql.getAaaHome().empty())
        {
            this->m_extendedSql.setAaaHome(".");
        }

        QFileInfo fileInfo(this->getInputFile().c_str());

        std::string baseName = fileInfo.baseName().toStdString();

        this->m_dataFile = SYS_Stringer(this->m_extendedSql.getAaaHome()
                                        , DIR_SEP
                                        , "tmp"
                                        , DIR_SEP
                                        , "loader"
                                        , DIR_SEP
                                        , "ldr_"
                                        , this->m_extendedSql.getTimeStamp()
                                        , "_"
                                        , baseName
                                        , ".dat");
    }

    return this->m_dataFile;
}


/****************************************************************************
 ** **
 ** **  Function    :   OraSqlLoader::createCommand()
 ** **
 ** **  Description :   creates the command to execute.
 ** **
 ** **  Created     :   PMSTA-36178 - KNI - Load Service - 190716
 ** **
 ** *************************************************************************/
void OraSqlLoader::createCommand(void)
{
    m_command = SYS_Stringer(getOracleHome().c_str()
        , DIR_SEP
        , "bin"
        , DIR_SEP
        , getStringParFile("sqlldr parfile", getParameterFile())
        , getStringParFile(" SILENT", "HEADER"));
}

/****************************************************************************
 ** **
 ** **  Function    :   OraSqlLoader::validateInputs()
 ** **
 ** **  Description :   This function validates the User Code and Password.
 ** **                  If the Password is not provided then it tries to
 ** **                      retrieve the same from encrypted password file.
 ** **
 ** **  Created     :   PMSTA-36178 - KNI - Load Service - 190716
 ** **
 ** *************************************************************************/
ExtendedSqlExitVal OraSqlLoader::validateInputs()
{
    if (DbiSqlLoader::validateInputs() != ExtendedSqlExitVal::EXT_SQL_SUCCESS)
        return ExtendedSqlExitVal::EXT_SQL_USAGE_FAIL;

    if (getOracleHome().empty())
    {
        this->m_ddlGenContext.printMsg(RET_DBA_ERR_DBPROBLEM, "ORACLE_HOME not set");
        return ExtendedSqlExitVal::EXT_SQL_FAIL;
    }

    if (getOracleSID().empty())
    {
        this->m_ddlGenContext.printMsg(RET_DBA_ERR_DBPROBLEM, "ORACLE_SID not set");
        return ExtendedSqlExitVal::EXT_SQL_FAIL;
    }

    return ExtendedSqlExitVal::EXT_SQL_SUCCESS;
}

/*****************************************************************************
 ** **
 ** **  Function    :   GenSqlLoader::GenSqlLoader()
 ** **
 ** **  Description :   GenSqlLoader Constructor
 ** **
 ** **  Created     :   
 ** **
 ** *************************************************************************/
GenSqlLoader::GenSqlLoader(ExtendedSql& extendedSql)
    : DbiSqlLoader(extendedSql)
{    
}

/*****************************************************************************
 ** **
 ** **  Function    :   GenSqlLoader::~GenSqlLoader()
 ** **
 ** **  Description :   GenSqlLoader Destructor
 ** **
 ** **  Created     :   PMSTA-55968 - LJE - 240711
 ** **
 ** *************************************************************************/
GenSqlLoader::~GenSqlLoader()
{
}

/*****************************************************************************
 ** **
 ** **  Function    :   GenSqlLoader::validateInputs()
 ** **
 ** **  Description :
 ** **
 ** **  Created     :   PMSTA-55968 - LJE - 240712
 ** **
 ** *************************************************************************/
ExtendedSqlExitVal GenSqlLoader::validateInputs()
{
    if (DbiSqlLoader::validateInputs() != ExtendedSqlExitVal::EXT_SQL_SUCCESS)
    {
        return ExtendedSqlExitVal::EXT_SQL_USAGE_FAIL;
    }

    if (this->m_extendedSql.getParallelLoad() == 1)
    {
        this->m_extendedSql.setParallelLoad(2);
    }

    return ExtendedSqlExitVal::EXT_SQL_SUCCESS;
}

/****************************************************************************
 ** **
 ** **  Function    :   GenSqlLoader::mainSqlLoad()
 ** **
 ** **  Description :   This is the main function for AAA sqlloader service.
 ** **                      Decides the sequence of execution.
 ** **
 ** **  Arguments   :   
 ** **
 ** **  Created     :   PMSTA-55968 - LJE - 240711
 ** **
 ** *************************************************************************/
ExtendedSqlExitVal GenSqlLoader::mainSqlLoad(void)
{
    if (this->validateInputs() != ExtendedSqlExitVal::EXT_SQL_SUCCESS)
    {
        return ExtendedSqlExitVal::EXT_SQL_USAGE_FAIL;
    }

    auto ret = this->treatDataFile();

    std::cout << std::endl;
    return ret;
}

/****************************************************************************
 ** **
 ** **  Function    :   GenSqlLoader::treatDataFile()
 ** **
 ** **  Description :   Treat the data file to send to the database 
 ** **
 ** **  Return      :   ExtendedSqlExitVal
 ** **
 ** **  Created     :   PMSTA-55968 - LJE - 240715
 ** **
 ** *************************************************************************/
ExtendedSqlExitVal GenSqlLoader::treatDataFile(void)
{
    RET_CODE ret = RET_DBA_ERR_INVDATA;

    std::fstream        inputFile;
    DbiConnectionHelper dbiConnHelper;
    std::string         readDataLine;
    int                 targetTotRows = 0;
    DdlGenContext&      ddlGenContext = this->getDdlGenContext();
    DdlGenMsg           ddlGenMsg(ddlGenContext);
    std::string         currProcessStr = "Loading data";
    std::ofstream       logStream;

    ddlGenMsg.setMsgObjType("Data Load");


    if (this->m_extendedSql.getLogFile().empty() == false)
    {
        ddlGenMsg.printMsg(RET_DBA_INFO_EXIST, SYS_Stringer("Log File: ", this->m_extendedSql.getLogFile()));
        logStream.open(this->m_extendedSql.getLogFile().c_str(), std::ifstream::out | std::ifstream::binary | std::ifstream::trunc);

        if (logStream.fail())
        {
            ddlGenMsg.printMsg(RET_FILE_ERR_OPEN, SYS_Stringer("Unable to open the log file: ", this->m_extendedSql.getLogFile()));
        }
        else
        {
            ddlGenContext.m_logStreamPtr = &logStream;
        }
    }

    ddlGenMsg.printMsg(RET_DBA_INFO_EXIST, SYS_Stringer("Input File: ", this->getInputFile()));
    inputFile.open(this->getInputFile().c_str(), std::ifstream::in);

    if (inputFile.fail() == false)
    {
        while (std::getline(inputFile, readDataLine))
        {
            if (this->isEmptyLine(readDataLine))
            {
                continue;
            }

            targetTotRows++;
        }
        inputFile.close();
        inputFile.open(this->getInputFile().c_str(), std::ifstream::in);
    }

    if (inputFile.fail() == false && dbiConnHelper.isValidAndInit())
    {
        auto& ctlFileHelper = this->getCtlFileHelper();
        size_t descSize = ctlFileHelper.m_tableDescVector.size();
        size_t quantityPos = 0;
        if (this->m_excludeZeroQty == TRUE &&
            (this->getTableName() == "hc_bo_position") ||
            this->getTableName() == "hc_bo_tax_lot")
        {
            for (auto& it : ctlFileHelper.m_tableDescVector)
            {
                if (strcmp(it.first->sqlName, "quantity_n") == 0)
                {
                    break;
                }

                if (strcmp(it.first->sqlName, "dataset_id") != 0)
                {
                    quantityPos++;
                }
            }
        }

        auto businessEntityId = SYS_GetThreadCurrBusinessEntityId();

        if (this->m_extendedSql.getDatasetId() > 0)
        {
            ddlGenMsg.printMsg(RET_DBA_INFO_EXIST, SYS_Stringer("Dataset: ", this->m_extendedSql.getDatasetId()));
            descSize--;
        }
        if (businessEntityId > 0)
        {
            ddlGenMsg.printMsg(RET_DBA_INFO_EXIST, SYS_Stringer("Business Entity: ", businessEntityId));
        }

        INT_T dataSetPos = 0;
        INT_T ownerBEPos = 0;
        for (auto& it : ctlFileHelper.m_tableDescVector)
        {
            if (strcmp(it.first->sqlName, "dataset_id") == 0)
            {
                dataSetPos = it.first->progN;
            }
            if (businessEntityId > 0 &&
                strcmp(it.first->sqlName, "owner_business_entity_id") == 0)
            {
                dataSetPos = it.first->progN;
            }
        }

        ddlGenContext.ddlGenAction.m_bOraNologgingHint = true;
        ddlGenContext.ddlGenAction.m_buildRuleEn = DdlGenBuildRule_DdlOnly;

        auto             ddlGenEntityPtr = ddlGenContext.getDdlGenEntityPtr(ctlFileHelper.m_dictEntitStp->mdSqlName, std::string(), true);
        DdlGenTable::Ptr ddlGenTablePtr(new DdlGenTable(ctlFileHelper.m_dictEntitStp->objectEn, TargetTable_Main, ddlGenContext, ddlGenEntityPtr, nullptr));
        DdlGenIndex::Ptr ddlGenIndexPtr(new DdlGenIndex(ctlFileHelper.m_dictEntitStp->objectEn, std::string(), ddlGenContext, ddlGenEntityPtr, nullptr, TargetTable_Main));

        ddlGenTablePtr->prepareDataMigration(ctlFileHelper.m_dictEntitStp, ctlFileHelper.m_dictEntitStp);
        if ((this->m_extendedSql.getDirectPath() & 1) == 1)
        {
            ddlGenMsg.printMsg(RET_DBA_INFO_EXIST, "Disable all triggers");
            ddlGenTablePtr->disableAllTriggers();
            ddlGenContext.bDisable = true;
            ddlGenEntityPtr->loadExdIndexInfo();
            ddlGenIndexPtr->build();
            ddlGenContext.bDisable = false;
        }

        MemoryPool mp;
        RequestHelper writeRequestHelper(dbiConnHelper.getConnection());

        writeRequestHelper.setBatchMode(this->m_extendedSql.getDirectPath() < 2 ? DbiConnection::BatchMode::TryBCP : DbiConnection::BatchMode::TryAndRetryRowByRow);
        writeRequestHelper.setTransactionMode(RequestHelper::TransactionMode::MostAsPossible);
        writeRequestHelper.optimDataAlloc();
        writeRequestHelper.setBatchInfo(ctlFileHelper.m_dictEntitStp->databaseName, ctlFileHelper.m_dictEntitStp->dbSqlName, ctlFileHelper.m_dictEntitStp->objectEn);
        writeRequestHelper.getScriptDdlGenPtr()->getDdlGenContextPtr()->ddlGenAction.m_bOraNologgingHint = ddlGenContext.ddlGenAction.m_bOraNologgingHint;
        writeRequestHelper.setBatchASync();
        writeRequestHelper.setParallel(this->m_extendedSql.getParallelLoad());
        writeRequestHelper.setTargetTable(TargetTable_Main);


        DBA_DYNST_ENUM  dynStEn = GET_EDITGUIST(ctlFileHelper.m_dictEntitStp->objectEn);
        
        int          readLineNbr      = 0;
        int          writeRowNbr      = 0;
        int          skippedLineNbr   = 0;
        double       blkWriteDuration = 0.0;
        int          batchRowNbr      = 0;
        double       percentDone      = 0;
        double       percentAdd       = 100;
        unsigned int lastDispProgress = 0;
        int          batchSize        = writeRequestHelper.getBatchBlockSize();
        double       totWriteDuration = 0.0;

        if (targetTotRows > batchSize)
        {
            percentAdd = 100. / (targetTotRows / batchSize);
        }

        ddlGenMsg.printMsg(RET_DBA_INFO_EXIST, SYS_Stringer("Batch size: ", batchSize, " (AAABATCHBLOCKSIZE)"));
        ddlGenMsg.printMsg(RET_DBA_INFO_EXIST, SYS_Stringer("Parallel processes: ", writeRequestHelper.getParallel()));
        ddlGenMsg.printMsg(RET_SRV_INFO_RUNNING, SYS_Stringer(currProcessStr, " (", targetTotRows, " rows)..."));

        auto startTime  = std::chrono::steady_clock::now();
        char fieldSep   = this->getFieldSep()[0];
        char enclosedBy = this->getEnclosedBy()[0];

        dbiConnHelper.getConnection()->setDelimiter(this->getFieldSep());

        auto writeStartTime = std::chrono::steady_clock::now();

        while (std::getline(inputFile, readDataLine))
        {
            if (this->isEmptyLine(readDataLine))
            {
                continue;
            }
            readLineNbr++;

            std::string    valueStr;
            auto           tokenIt   = readDataLine.begin();
            size_t         tokenPos  = 0;
            bool           bSkipped  = false;

            if (tokenIt == readDataLine.begin())
            {
                size_t startPos = readDataLine.find_first_not_of(" \t\"");
                if (startPos != 0)
                {
                    readDataLine.erase(0, startPos);
                    readDataLine.erase(readDataLine.size() - 1, 1);
                }
                tokenIt = readDataLine.begin();
            }

            DBA_DYNFLD_STP recordStp = nullptr;
            writeRequestHelper.getNewRecordForBatch(dynStEn, recordStp);
            DBA_SetDfltEntityFld(recordStp);

            auto descIt = ctlFileHelper.m_tableDescVector.begin();
            if (this->m_extendedSql.getDatasetId() > 0)
            {
                SET_ID(recordStp, descIt->first->progN, this->m_extendedSql.getDatasetId());
                ++descIt;
            }

            while (this->getNextToken(readDataLine, tokenIt, valueStr, fieldSep, enclosedBy))
            {
                if (this->m_excludeZeroQty == TRUE &&
                    tokenPos == quantityPos &&
                    (valueStr == "0" || valueStr.empty()))
                {
                    bSkipped = true;
                    skippedLineNbr++;
                    writeRequestHelper.removeLastRecordForBatch();
                    break;
                }

                if (valueStr.empty() == false)
                {
                    SET_NOTNULLFLG_T(recordStp, descIt->first->progN);

                    auto dataType = descIt->first->dataTpProgN;

                    batchRowNbr++;

                    if (IS_STRING_TYPE(dataType))
                    {
                        SET_STRING(recordStp, descIt->first->progN, valueStr.c_str());
                    }
                    else if (dataType == DatetimeType ||
                             dataType == DateType)
                    {
                        DATETIME_T tmpDateTime;
                        CONV_StrToData(valueStr.c_str(), dataType, descIt->second.c_str(), (PTR)&tmpDateTime, TRUE);
                        SET_DATETIME(recordStp, descIt->first->progN, tmpDateTime);
                    }
                    else
                    {
                        CONVFMT_ENUM  format = GET_DFLTCONVFMT(dataType);

                        CONV_StrToDataEx(valueStr.c_str(),
                                         dataType,
                                         GET_CONV_MASK(format),
                                         DBA_GetDataFromDynFldData(dataType, recordStp[descIt->first->progN].data),
                                         FALSE,
                                         this->getDecimalSep(),
                                         DictAttrib_WgtTypeDefault);
                    }
                }

                ++descIt;
                tokenPos++;
            }

            if (bSkipped)
            {
                continue;
            }

            if (businessEntityId > 0 &&
                descIt != ctlFileHelper.m_tableDescVector.end() &&
                descIt->first->progN == ownerBEPos)
            {
                SET_ID(recordStp, descIt->first->progN, businessEntityId);
            }

            writeRowNbr++;

            ret = this->executeBatch(false, writeRequestHelper, batchRowNbr, ddlGenMsg);

            if (ret != RET_GEN_INFO_NOACTION)
            {
                auto writeDuration = std::chrono::duration_cast<std::chrono::duration<double>>(std::chrono::steady_clock::now() - writeStartTime);
                blkWriteDuration += writeDuration.count();

                percentDone += percentAdd;

                unsigned int currProgress = static_cast<int>(percentDone);
                if (currProgress != lastDispProgress && currProgress != 100)
                {
                    lastDispProgress = currProgress;

                    std::stringstream msgStream;
                    msgStream << currProgress << "% (" << writeRowNbr << "/" << targetTotRows << ") " << std::fixed << std::setprecision(2) << " (w=" << blkWriteDuration << " sec)";

                    ddlGenMsg.printMsg(RET_DBA_INFO_EXIST, msgStream.str());

                    totWriteDuration += blkWriteDuration;
                    blkWriteDuration = 0.0;
                }

                batchRowNbr = 0;
                writeStartTime = std::chrono::steady_clock::now();
            }
        }

        if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
        {
            writeStartTime = std::chrono::steady_clock::now();
            ret = this->executeBatch(true, writeRequestHelper, batchRowNbr, ddlGenMsg);
            auto writeDuration = std::chrono::duration_cast<std::chrono::duration<double>>(std::chrono::steady_clock::now() - writeStartTime);
            blkWriteDuration += writeDuration.count();
            totWriteDuration += blkWriteDuration;
        }
        double totDuration = std::chrono::duration_cast<std::chrono::duration<double>>(std::chrono::steady_clock::now() - startTime).count();

        std::string migrationNbrStr;

        if (ret == RET_SUCCEED && writeRowNbr == (targetTotRows - skippedLineNbr))
        {
            std::stringstream msgStream;
            msgStream << 100 << std::fixed << std::setprecision(2) << "%( w=" << totWriteDuration << " sec)";

            ddlGenMsg.printMsg(RET_DBA_INFO_EXIST, msgStream.str());

            migrationNbrStr = SYS_Stringer(" (", writeRowNbr, " rows loaded in ", totDuration, " sec");

            if (skippedLineNbr > 0)
            {
                migrationNbrStr += SYS_Stringer(", ", skippedLineNbr, " rows skipped due to zero quantity");
            }
            migrationNbrStr += ")";

        }

        ddlGenTablePtr->releaseDataMigration(ctlFileHelper.m_dictEntitStp, ctlFileHelper.m_dictEntitStp);

        if ((this->m_extendedSql.getDirectPath() & 1) == 1)
        {
            ddlGenMsg.printMsg(RET_DBA_INFO_EXIST, "Enable all triggers");
            ddlGenTablePtr->enableAllTriggers();
            ddlGenEntityPtr->loadExdIndexFromSysInfo(true);
            ddlGenIndexPtr->m_duplicateManagment = DdlGenIndex::DuplicateManagment::Delete;
            auto idxRet = ddlGenIndexPtr->build();
            if (RET_GET_LEVEL(idxRet) == RET_LEV_ERROR)
            {
                ret = idxRet;
            }
        }

        if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
        {
            ret = RET_DBA_ERR_DBPROBLEM;
            migrationNbrStr = SYS_Stringer(" failed (", writeRowNbr - CAST_INT(writeRequestHelper.m_onErrorRequests.size()), " rows loaded), see $AAAHOME/msg/error.log file");
        }

        ret = RET_SUCCEED;

        ddlGenMsg.printMsg(ret, currProcessStr + migrationNbrStr);

        ddlGenMsg.setMsgObjType("Statistics");
        ddlGenMsg.printMsg(RET_DBA_INFO_EXIST, SYS_Stringer("INSERTED=", writeRowNbr));
        ddlGenMsg.printMsg(RET_DBA_INFO_EXIST, SYS_Stringer("SKIPPED=", skippedLineNbr));
        ddlGenMsg.printMsg(RET_DBA_INFO_EXIST, SYS_Stringer("FAILED=", CAST_INT(writeRequestHelper.m_onErrorRequests.size())));
    }

    if (logStream.good())
    {
        logStream << std::endl;
        logStream.close();
    }

    return (ret == RET_SUCCEED) ? ExtendedSqlExitVal::EXT_SQL_SUCCESS : ExtendedSqlExitVal::EXT_SQL_FAIL;
}


/************************************************************************
**
**  Function    :   DbiSqlLoader::getNextToken()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-48744 - LJE - 220414
**
*************************************************************************/
bool DbiSqlLoader::getNextToken(std::string&           dataLine, 
                                std::string::iterator& tokenIt, 
                                std::string&           token, 
                                char                   delimterStr,
                                char                   enclosedByStr)
{
    if (tokenIt == dataLine.end())
    {
        return false;
    }

    token.clear();
    bool bEnclosed = (*tokenIt == enclosedByStr);
    auto begIt     = tokenIt;

    while (tokenIt != dataLine.end())
    {
        if (*tokenIt == delimterStr)
        {
            if (tokenIt == begIt || (*(tokenIt - 1)) != '\\')
            {
                break;
            }
        }

        tokenIt++;
    }

    if (bEnclosed &&
        (*(tokenIt - 1)) == enclosedByStr)
    {
        token = std::string(begIt + 1, tokenIt - 1);
    }
    else
    {
        token = std::string(begIt, tokenIt);
    }

    if (tokenIt != dataLine.end())
    {
        tokenIt++;
    }

    return true;
}

/************************************************************************
**
**  Function    :   DdlGenTable::executeBatch()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-48744 - LJE - 220414
**
*************************************************************************/
RET_CODE GenSqlLoader::executeBatch(bool bForce, RequestHelper& writeRequestHelper, int batchRowNbr, DdlGenMsg& ddlGenMsg)
{
    RET_CODE ret = RET_SUCCEED;

    if (bForce)
    {
        ret = writeRequestHelper.executeBatch(&ddlGenMsg);
    }
    else
    {
        ret = writeRequestHelper.flushBatch(false, &ddlGenMsg);
    }

    writeRequestHelper.printErrorOnFile(this->m_extendedSql.getBadFile(), batchRowNbr, ddlGenMsg);

    return ret;
}


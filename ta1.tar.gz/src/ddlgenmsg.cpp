/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DDLGENMSG_CPP

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H

#include      "unidef.h"     /* Mandatory */
#include      "syslib.h"
#include      "gen.h"
#include      "dba.h"
#include      "ddlgenmsg.h"
#include      "ddlgen.h"

#include <iomanip>

using namespace std;

/************************************************************************
**      External entry points
**
*************************************************************************/


/************************************************************************
**      Local functions
**
*************************************************************************/

/************************************************************************
**      Static definitions & data
**
*************************************************************************/

const char* DDL_SPACE = " \t\n\r\f\v";

/************************************************************************
**      FONCTIONS
**
************************************************************************/
/************************************************************************
**
**  Function    :   DdlGenMsg()
**
**  Description :   Constructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14452 - LJE - 130206
**
*************************************************************************/
DdlGenMsg::DdlGenMsg(DdlGenContext *ddlGenContextPtr, bool bStandalone)
    : lastErrRetCode(RET_SUCCEED)
    , m_ddlObjEn(DdlObj_None)
    , ddlGenContextPtr(ddlGenContextPtr)
    , m_isStandalone(bStandalone)
    , m_bTimerStarted(false)
{
    if (this->ddlGenContextPtr != nullptr)
    {
        this->setMsgInfo(*this->ddlGenContextPtr);
    }
}

/************************************************************************
**
**  Function    :   ~DdlGenMsg()
**
**  Description :   Destructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14452 - LJE - 130206
**
*************************************************************************/
DdlGenMsg::~DdlGenMsg()
{
}


/************************************************************************
**
**  Function    :   DdlGenDbi::setDdlObjEn()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
void DdlGenMsg::setDdlObjEn(DDL_OBJ_ENUM paramDdlObjEn)
{
    if (this->m_ddlObjEn != paramDdlObjEn)
    {
        this->m_ddlObjEn = paramDdlObjEn;

        switch (this->m_ddlObjEn)
        {
            case DdlObj_SProc:
                this->msgObjTypeStr = "Stored Proc.";
                break;
            case DdlObj_Func:
                this->msgObjTypeStr = "Function";
                break;
            case DdlObj_SpecSProc:
                this->msgObjTypeStr = "Spec. Stored Proc.";
                break;
            case DdlObj_View:
                this->msgObjTypeStr = "View";
                break;
            case DdlObj_Trigger:
            case DdlObj_TriggerBody:
            case DdlObj_TriggerUdField:
            case DdlObj_TriggerUdFieldBody:
                this->msgObjTypeStr = "Trigger";
                break;
            case DdlObj_Table:
                this->msgObjTypeStr = "Table";
                break;
            case DdlObj_Type:
                this->msgObjTypeStr = "Type";
                break;
            case DdlObj_TempTable:
                this->msgObjTypeStr = "Temporary Table";
                break;
            case DdlObj_Index:
                this->msgObjTypeStr = "Index";
                break;
            case DdlObj_TempTableIndex:
                this->msgObjTypeStr = "Temporary Table Index";
                break;
            default:
                this->msgObjTypeStr = "Default";
        }
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getDdlObjEn()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 150123
**
*************************************************************************/
DDL_OBJ_ENUM DdlGenMsg::getDdlObjEn()
{
    return this->m_ddlObjEn;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getDdlObjEnStr()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 150123
**
*************************************************************************/
std::string DdlGenMsg::getDdlObjEnStr()
{
    return DdlGenMsg::getDdlObjEnStr(this->m_ddlObjEn);
}
 
/************************************************************************
**
**  Function    :   DdlGenDbi::getDdlObjEnStr()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 150123
**
*************************************************************************/
std::string DdlGenMsg::getDdlObjEnStr(DDL_OBJ_ENUM m_ddlObjEn)
{
    switch (m_ddlObjEn)
    {
        case DdlObj_None:
        case DdlObj_Sql:
            return "DdlObj_Sql";
            break;
        case DdlObj_Table:
            return "DdlObj_Table";
            break;
        case DdlObj_TempTable:
            return "DdlObj_TempTable";
            break;
        case DdlObj_View:
            return "DdlObj_View";
            break;
        case DdlObj_SProc:
            return "DdlObj_SProc";
            break;
        case DdlObj_SpecSProc:
            return "DdlObj_SpecSProc";
            break;
        case DdlObj_Func:
            return "DdlObj_Func";
            break;
        case DdlObj_Trigger:
            return "DdlObj_Trigger";
            break;
        case DdlObj_TriggerUdField:
            return "DdlObj_TriggerUdField";
            break;
        case DdlObj_Index:
            return "DdlObj_Index";
            break;
        case DdlObj_TempTableIndex:
            return "DdlObj_TempTableIndex";
            break;
        case DdlObj_PrimaryKey:
            return "DdlObj_PrimaryKey";
            break;
        case DdlObj_ForeignKey:
            return "DdlObj_ForeignKey";
            break;
        case DdlObj_Constraint:
            return "DdlObj_Constraint";
            break;
        default:
            return "Other";
            break;
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::isProcedureBehavior()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-46681 - LJE - 230126
**
*************************************************************************/
bool DdlGenMsg::isProcedureBehavior()
{
    return (this->getDdlObjEn() != DdlObj_View &&
            this->getDdlObjEn() != DdlObj_Sql &&
            this->getDdlObjEn() != DdlObj_RuntimeSql);
}


/************************************************************************
**
**  Function    :   DdlGenMsg::getViewEnFromStr()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-16194 - LJE - 130522
**
*************************************************************************/
DDL_VIEW_ENUM DdlGenMsg::getViewEnFromStr(const string &viewEnStr)
{
    DDL_VIEW_ENUM retViewEn = View_None;

    if (viewEnStr == "vw")
    {
        retViewEn = View_FullAllSecured;
    }
    else if (viewEnStr == "uvw")
    {
        retViewEn = View_FullAll;
    }
    else if (viewEnStr == "lvw")
    {
        retViewEn = View_LightAll;
    }
    else if (viewEnStr == "svw")
    {
        retViewEn = View_ShortSecured;
    }
    else if (viewEnStr == "usv")
    {
        retViewEn = View_Short;
    }
    else if (viewEnStr == "fkv")
    {
        retViewEn = View_FullAll4ForeignKey;
    }
    /* PMSTA-43625 - LJE - 210308 */
    else if (viewEnStr == "mvw")
    {
        retViewEn = View_AllSecured;
    }
    else if (viewEnStr == "ovw")
    {
        retViewEn = View_ForUpdateByTech;
    }
    /* PMSTA-29982 - LJE - 180209 */
    else if (viewEnStr == "me")
    {
        retViewEn = View_MultiEntitySpec;
    }
    else if (viewEnStr == "evw")
    {
        retViewEn = View_Export;
    }
    else if (viewEnStr == "tvw")
    {
        retViewEn = View_MainTable;
    }
    /* PMSTA-nuodb - LJE - 190617 */
    else if (viewEnStr == "xvw")
    {
        retViewEn = View_Tech;
    }
    else if (viewEnStr == "null")
    {
        retViewEn = View_Custom;
    }
    else if (viewEnStr == "user")
    {
        retViewEn = View_User;
    }

    return retViewEn;
}


/************************************************************************
**
**  Function    :   DdlGenMsg::getDdlObjEnFromStr()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-24007 - LJE - 170113
**
*************************************************************************/
DDL_OBJ_ENUM DdlGenMsg::getDdlObjEnFromStr(const string &ddlObjEnStr)
{
    DDL_OBJ_ENUM retDdlObjEn = DdlObj_None;

    if (DdlGenMsg::getViewEnFromStr(ddlObjEnStr) != View_None)
    {
        retDdlObjEn = DdlObj_View;
    }
    else if (ddlObjEnStr == "proc")
    {
        retDdlObjEn = DdlObj_SProc;
    }
    else if (ddlObjEnStr == "trigger")
    {
        retDdlObjEn = DdlObj_Trigger;
    }
    else if (ddlObjEnStr == "sql")
    {
        retDdlObjEn = DdlObj_Sql;
    }
    else if (ddlObjEnStr == "table")
    {
        retDdlObjEn = DdlObj_Table;
    }
    else if (ddlObjEnStr == "column")
    {
        retDdlObjEn = DdlObj_Column;
    }
    else if (ddlObjEnStr == "type")
    {
        retDdlObjEn = DdlObj_Type;
    }
    else if (ddlObjEnStr == "index")
    {
        retDdlObjEn = DdlObj_Index;
    }
    else if (ddlObjEnStr == "constraint")
    {
        retDdlObjEn = DdlObj_Constraint;
    }

    return retDdlObjEn;
}

/************************************************************************
**
**  Function    :   DdlGenMsg::setMsgInfo()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26250 - LJE - 170525
**
*************************************************************************/
void DdlGenMsg::setMsgInfo(const DdlGenMsg &copyDdlGenMsg)
{
    this->setMsgEntitySqlName(copyDdlGenMsg.msgEntitySqlName);
    this->setMsgSqlName(copyDdlGenMsg.msgEntitySqlName);
    this->setMsgObjType(copyDdlGenMsg.msgObjTypeStr);
}

/************************************************************************
**
**  Function    :   DdlGenMsg::setMsgEntitySqlName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26250 - LJE - 170525
**
*************************************************************************/
void DdlGenMsg::setMsgEntitySqlName(const string &entitySqlName)
{
    this->msgEntitySqlName = entitySqlName;
}

/************************************************************************
**
**  Function    :   DdlGenMsg::setMsgSqlName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-16729 - LJE - 140204
**
*************************************************************************/
void DdlGenMsg::setMsgSqlName(const string & sqlName)
{
    this->msgSqlName = sqlName;
}

/************************************************************************
**
**  Function    :   DdlGenMsg::setMsgObjType()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-16729 - LJE - 140204
**
*************************************************************************/
void DdlGenMsg::setMsgObjType(const string & objTypeStr)
{
    this->msgObjTypeStr = objTypeStr;
}

/************************************************************************
**
**  Function    :   DdlGenMsg::getSilentMode()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37366 - LJE - 200210
**
*************************************************************************/
bool DdlGenMsg::getSilentMode()
{
    if (this->ddlGenContextPtr != nullptr)
    {
        return this->ddlGenContextPtr->getSilentMode();
    }

    return 1;
}

/************************************************************************
**
**  Function    :   DdlGenMsg::setMsgEntitySqlName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26108 - LJE - 170823
**
*************************************************************************/
const string &DdlGenMsg::getMsgEntitySqlName() const
{
    return this->msgEntitySqlName;
}

/************************************************************************
**
**  Function    :   DdlGenMsg::setMsgSqlName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26108 - LJE - 170823
**
*************************************************************************/
const string &DdlGenMsg::getMsgSqlName() const
{
    return this->msgSqlName;
}

/************************************************************************
**
**  Function    :   DdlGenMsg::setMsgObjType()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26108 - LJE - 170823
**
*************************************************************************/
const string &DdlGenMsg::getMsgObjType() const
{
    return this->msgObjTypeStr;
}

/************************************************************************
**
**  Function    :  DdlGenMsg::printMsgData()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-14086 - LJE - 121005
**
*************************************************************************/
void DdlGenMsg::printMsgData(RET_CODE retCode, DBA_DYNFLD_STP dataStp)
{
    stringstream msgStream;
    OBJECT_ENUM object;
    DICT_ENTITY_STP dictEntityStp;
    bool bFirst = true;

    if (dataStp == NULL)
        return;

    switch (retCode)
    {
        case RET_DBA_ERR_INSERT_FAILED:
            msgStream << "On INSERT ";
            break;
        case RET_DBA_ERR_UPDATE_FAILED:
            msgStream << "On UPDATE ";
            break;
        case RET_DBA_ERR_DELETE_FAILED:
            msgStream << "On DELETE ";
            break;
        default:
            break;
    }

    object = GET_OBJ_DYNST(dataStp[0].dynStEnum);

    dictEntityStp = DBA_GetDictEntitySt(object);

    if (dictEntityStp != nullptr)
    {
        msgStream << "on entity \"" << dictEntityStp->mdSqlName << "\" : ";

        for (auto& dictAttribStp : dictEntityStp->attr)
        {
            if (dictAttribStp->logicalFlg == FALSE &&
                dictAttribStp->custFlg == FALSE &&
                dictAttribStp->precompFlg == FALSE &&
                dictAttribStp->progN < GET_FLD_NBR(dataStp[0].dynStEnum))
            {
                std::stringstream bufStream;
                if (bFirst)
                {
                    bFirst = false;
                }
                else
                {
                    msgStream << ", ";
                }
                DBA_DispFieldValue(bufStream, dataStp, dictAttribStp->progN);
                msgStream << "@" << dictAttribStp->sqlName << "=" << bufStream.str();
            }
        }
    }
    else
    {
        msgStream << "on structure \"" << DBA_GetDynStCName(dataStp[0].dynStEnum) << "\" : ";
    }

    this->printMsg(retCode, msgStream.str());
}

/************************************************************************
**
**  Function    :  DdlGenMsg::printConfig()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-14086 - LJE - 121005
**
*************************************************************************/
void DdlGenMsg::printConfig()
{
    if (this->ddlGenContextPtr->ddlGenAction.m_subRequest == false)
    {
        this->setMsgObjType("Configuration");
        this->setMsgSqlName(string());
        this->setMsgEntitySqlName(string());

        {
            stringstream msg;
            msg << "Target RDBMS        : " << DdlGenDbi::getRdbmsName(this->ddlGenContextPtr->m_rdbmsEn);
            this->printMsg(RET_DBA_INFO_EXIST, msg.str());
        }
        {
            stringstream msg;
            msg << "DDl Gen Version     : " << AAAVersion::getVersion().getfullVersionInfo();
            this->printMsg(RET_DBA_INFO_EXIST, msg.str());
        }
        {
            stringstream msg;
            CurrentTime now(CurrentTime::Kind::CurrentUs);    /* Get Date and Time informations */
            msg << "Start Date          : " << now.formatYYYYMMDDSPHMSUS();
            this->printMsg(RET_DBA_INFO_EXIST, msg.str());
        }
        {
            stringstream msg;
            msg << "Installation level  : " << this->ddlGenContextPtr->ddlGenAction.m_installLevel;
            this->printMsg(RET_DBA_INFO_EXIST, msg.str());
        }
        if (EV_GenDdlContext.infoPtr != nullptr)
        {
            stringstream msg;
            msg << "Generation type (-G): " << EV_GenDdlContext.infoPtr;
            this->printMsg(RET_DBA_INFO_EXIST, msg.str());
        }
        if (EV_GenDdlContext.objPtr != nullptr)
        {
            stringstream msg;
            msg << "Object (-o)         : " << EV_GenDdlContext.objPtr;
            this->printMsg(RET_DBA_INFO_EXIST, msg.str());
        }
        if (EV_GenDdlContext.optionPtr != nullptr)
        {
            stringstream msg;
            msg << "Option (-X)         : " << EV_GenDdlContext.optionPtr;
            this->printMsg(RET_DBA_INFO_EXIST, msg.str());
        }
        if (EV_GenDdlContext.inputPtr != nullptr)
        {
            stringstream msg;
            msg << "Input (-i)          : " << EV_GenDdlContext.inputPtr;
            this->printMsg(RET_DBA_INFO_EXIST, msg.str());
        }
        {
            stringstream msg;
            msg << "AAADDLGENMTSIZE=" << this->ddlGenContextPtr->ddlGenAction.m_multiThreadSize;
            this->printMsg(RET_DBA_INFO_EXIST, msg.str());
        }
        {
            RequestHelper requestHelper(nullptr, false);
            stringstream msg;
            msg << "AAABATCHBLOCKSIZE=" << requestHelper.getBatchBlockSize();
            this->printMsg(RET_DBA_INFO_EXIST, msg.str());
        }
        {
            stringstream msg;
            msg << "AAAPARALLELLOAD=" << this->ddlGenContextPtr->ddlGenAction.m_parallelLoad;
            this->printMsg(RET_DBA_INFO_EXIST, msg.str());
        }

        if (this->ddlGenContextPtr->m_rdbmsEn == Oracle)
        {
            {
                stringstream msg;
                msg << "ORACLE_CREATE_INDEX_HINT=" << this->ddlGenContextPtr->ddlGenAction.m_bOraCreateIdxHint;
                this->printMsg(RET_DBA_INFO_EXIST, msg.str());
            }
            {
                stringstream msg;
                msg << "ORACLE_NOLOGGING_HINT=" << this->ddlGenContextPtr->ddlGenAction.m_bOraNologgingHint;
                this->printMsg(RET_DBA_INFO_EXIST, msg.str());
            }
        }
        if (this->ddlGenContextPtr->m_rdbmsEn == MSSql)
        {
            /* PMSTA-58084 - LJE - 240729 */
            {
                stringstream msg;
                msg << "USE_MEMORY_OPTIMIZED_DATA=" << this->ddlGenContextPtr->ddlGenAction.m_useMemoryOptizedTempTable;
                this->printMsg(RET_DBA_INFO_EXIST, msg.str());
            }
            {
                stringstream msg;
                msg << "AAAUSECLUSTERIDX=" << this->ddlGenContextPtr->bUseClusterIdx;
                this->printMsg(RET_DBA_INFO_EXIST, msg.str());
            }
            {
                stringstream msg;
                msg << "AAACREATEPRIMARYKEY=" << this->ddlGenContextPtr->bCreatePK;
                this->printMsg(RET_DBA_INFO_EXIST, msg.str());
            }
        }
    }
}

/************************************************************************
**
**  Function    :  DdlGenMsg::printMsg()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-14086 - LJE - 121005
**
*************************************************************************/
void DdlGenMsg::printMsg(RET_CODE retCode, const std::string &paramMsg, bool isNewLine, int sprocLine)
{
    stringstream              msg, srvMsg, msgTypeStr;
    bool                      bPrintMsg = true;
    bool                      bPrintDuration = false;
    bool                      bPrintStdOut = (SYS_IsDdlGenMode() == TRUE || 
                                              SYS_IsSqlMode() == TRUE || 
                                              SYS_IsBatchMode() == TRUE ||
                                              EV_GenDdlContext.bCheck == true);
    bool                      bPrintTid = false;

    DDLGEN_MESSAGE_LEVEL_ENUM messageLevelEn = DdlgenMessageLevel_None; /* PMSTA-30453 - LJE - 180405 */

    msg << setiosflags(ios::left);

    if (isNewLine)
    {
        msg << endl;
    }

    if (this->ddlGenContextPtr != nullptr &&
        this->ddlGenContextPtr->m_buildBindOptionPtr != nullptr)
    {
        bPrintStdOut = false;
    }

    if (retCode == RET_DBA_ERR_HIER_WARN)
    {
        messageLevelEn = DdlgenMessageLevel_Warning;
        msgTypeStr << "WARNING";
    }
    else if (RET_GET_LEVEL(retCode) == RET_LEV_ERROR)
    {
        if (this->ddlGenContextPtr != nullptr &&
            this->ddlGenContextPtr->ddlGenAction.isBootStrapLevel() &&
            retCode != RET_ENV_ERR_WRONGCONFIG &&
            retCode != RET_DBA_ERR_DBPROBLEM &&
            retCode != RET_DBA_ERR_CANNOTCONNECT &&
            retCode != RET_DBA_ERR_MD)
        {
            this->ddlGenContextPtr->bWarning = true;

            messageLevelEn = DdlgenMessageLevel_Info;
            msgTypeStr << "INFO";
            bPrintMsg = false;
        }
        else
        {
            messageLevelEn = DdlgenMessageLevel_Error;
            msgTypeStr << "Msg ERROR";
        }
        this->lastErrRetCode = retCode;
    }
    else if (retCode == RET_SRV_INFO_RUNNING)
    {
        this->startTimer();
        bPrintTid = true;

        if (this->ddlGenContextPtr != nullptr &&
            this->m_isStandalone   == false)
        {
            this->ddlGenContextPtr->setMsgInfo(*this);
        }

        messageLevelEn = DdlgenMessageLevel_Process;
        msgTypeStr << "PROCESS";

        if (this->getSilentMode() == false)
        {
            cerr << ".";
        }
    }
    else if (retCode == RET_SRV_INFO_NO_POSITIONS)
    {
        messageLevelEn = DdlgenMessageLevel_Skipped;
        msgTypeStr << "SKIPPED";
    }
    else if (retCode == RET_GEN_INFO_NOACTION)
    {
        messageLevelEn = DdlgenMessageLevel_NoAction;
        msgTypeStr << "NOACTION";
    }
    else if (retCode == RET_SUCCEED)
    {
        if (this->m_bTimerStarted)
        {
            this->stopTimer();
            bPrintDuration = true;
        }
        bPrintTid = true;

        messageLevelEn = DdlgenMessageLevel_Success;
        msgTypeStr << "SUCCESS";
    }
    else if (retCode == RET_DBA_INFO_NODATA)
    {
        messageLevelEn = DdlgenMessageLevel_Warning;
        msgTypeStr << "WARNING";
    }
    else if (retCode == RET_SRV_INFO_DONE ||
             retCode == RET_DBA_INFO_NO_MORE_DATA)
    {
        if (this->m_bTimerStarted)
        {
            this->stopTimer();
            bPrintDuration = true;
        }

        msgTypeStr << "DONE";
        messageLevelEn = DdlgenMessageLevel_Process;
    }
    else if (RET_GET_LEVEL(retCode) == RET_LEV_INFO)
    {
        messageLevelEn = DdlgenMessageLevel_Info;
        msgTypeStr << "INFO";
    }
    else if (this->ddlGenContextPtr != nullptr &&
             this->ddlGenContextPtr->ddlGenAction.isBootStrapLevel())
    {
        messageLevelEn = DdlgenMessageLevel_Warning;
        msgTypeStr << "WARNING";
    }
    else
    {
        messageLevelEn = DdlgenMessageLevel_Warning;
        msgTypeStr << "Msg WARNING (0x0" << std::hex << retCode << ")";
    }

    msg << setw(10) << msgTypeStr.str().append(": ");


    if (this->msgObjTypeStr.empty() == false)
    {
        srvMsg << this->msgObjTypeStr << " ";
    }
    if (this->msgEntitySqlName.empty() == false)
    {
        if (sprocLine >= 0 && this->msgFileName.empty() == false)
        {
            srvMsg << this->msgEntitySqlName << " on file " << this->msgFileName << ":" << sprocLine << " ";
        }
        else
        {
            srvMsg << " on entity " << this->msgEntitySqlName << " ";
        }
    }
    else if (sprocLine >= 0 && this->msgFileName.empty() == false)
    {
        srvMsg << "File " << this->msgFileName << ":" << sprocLine << " ";
    }

    if (srvMsg.str().empty() == false)
    {
        srvMsg << "- ";
    }

    if (this->msgSqlName.empty() == false &&
        this->msgSqlName.compare(this->msgEntitySqlName) != 0)
    {
        srvMsg << this->msgSqlName << " creation: ";
    }
    srvMsg << paramMsg;

    if (this->msgObjTypeStr.empty() == false)
    {
        msg << setw(20) << this->msgObjTypeStr << " ";
    }
    if (this->msgEntitySqlName.empty() == false)
    {
        if (sprocLine >= 0 && this->msgFileName.empty() == false)
        {
            msg << setw(30) << this->msgEntitySqlName << " on file " << this->msgFileName << ":" << sprocLine << " ";
        }
        else
        {
            msg << " on entity " << setw(30) << this->msgEntitySqlName << " ";
        }
        msg << "- ";
    }
    else if (sprocLine >= 0 && this->msgFileName.empty() == false)
    {
        msg << "File " << this->msgFileName << ":" << sprocLine << " - ";
    }

    if (this->ddlGenContextPtr != nullptr)
    {
        if (this->ddlGenContextPtr->ddlGenAction.m_logLevel == 0 &&
            messageLevelEn != DdlgenMessageLevel_Error)
        {
            bPrintMsg = false;
        }

        if (messageLevelEn == DdlgenMessageLevel_Error)
        {
            this->ddlGenContextPtr->addMessage(retCode, messageLevelEn, paramMsg);
        }
    }

    if (bPrintMsg)
    {
        if (this->msgSqlName.empty() == false &&
            this->msgSqlName.compare(this->msgEntitySqlName) != 0)
        {
            msg << this->msgSqlName << ": ";
        }

        if (bPrintStdOut)
        {
            std::ostream &logStream = (this->ddlGenContextPtr != nullptr &&
                                       this->ddlGenContextPtr->m_logStreamPtr != nullptr &&
                                       this->ddlGenContextPtr->m_logStreamPtr->good() ?
                                       *this->ddlGenContextPtr->m_logStreamPtr :
                                       std::cout);

            if ((retCode & RET_LEV_ERROR) != 0)
            {
                EV_CheckErrorLevel = retCode;

                if (isNewLine == false)
                {
                    logStream << paramMsg;
                    logStream << endl;
                }

                msg << paramMsg;

                logStream << msg.str();
                logStream.flush();

                if (isNewLine == true && this->getSilentMode() == false)
                {
                    cerr << endl;
                }

                cerr << msg.str() << endl;

                if (this->getSilentMode() == false && this->m_ddlObjEn != DdlObj_Sql && this->m_ddlObjEn != DdlObj_RuntimeSql)
                {
                    cerr << ".";
                }

                cerr.flush();
            }
            else
            {
                msg << paramMsg;

                if (bPrintTid)
                {
                    msg << " (" << SYS_GetThreadDescriptionForLog() << ")";
                }

                if (isNewLine == false)
                {
                    msg.clear();
                    msg.str(string());
                    msg << paramMsg;
                }

                /* PMSTA-26108 - LJE - 170901 */
                if (bPrintDuration)
                {
                    msg << " (" << this->printTimer((retCode != RET_DBA_INFO_NO_MORE_DATA) && (retCode != RET_DBA_ERR_MD_INVALID_VALUE)) << ")";
                    this->resetTimer();
                }

                logStream << msg.str();
                logStream.flush();
            }
        }

        if (this->ddlGenContextPtr != nullptr &&
            this->ddlGenContextPtr->m_buildBindOptionPtr != nullptr)
        {
            ProcessingMessageNatEn importMessageNatEn(ProcessingMessageNatEn::None);

            switch (messageLevelEn)
            {
                   case DdlgenMessageLevel_Warning:
                       importMessageNatEn = ProcessingMessageNatEn::Warning;
                       break;

                   case DdlgenMessageLevel_Error:
                       importMessageNatEn = ProcessingMessageNatEn::Error;
                       break;

                   case DdlgenMessageLevel_FatalError:
                       importMessageNatEn = ProcessingMessageNatEn::Fail;
                       break;

                   case DdlgenMessageLevel_Success:
                       importMessageNatEn = ProcessingMessageNatEn::Success;
                       break;

                   case DdlgenMessageLevel_Info:
                   case DdlgenMessageLevel_Process:
                       importMessageNatEn = ProcessingMessageNatEn::Info;
                       break;

                   case DdlgenMessageLevel_Skipped:
                   case DdlgenMessageLevel_NoAction:
                       importMessageNatEn = ProcessingMessageNatEn::Debug;
                       break;
            }

            this->ddlGenContextPtr->m_buildBindOptionPtr->printMsg(importMessageNatEn, retCode, srvMsg.str());
        }
        else if (bPrintStdOut || SYS_IsDdlGenMode() == FALSE)
        {
            if (SYS_IsSrvMode())
            {
                srvMsg << " (" << msgTypeStr.str() << ")";
                MSG_LogSrvMesg(UNUSED, UNUSED, srvMsg.str().c_str(), NullDataType);
            }

            /* PMSTA-43738 - LJE - 210218 */
            if (messageLevelEn == DdlgenMessageLevel_Error && SYS_IsDdlGenMode() == FALSE)
            {
                MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, srvMsg.str().c_str());
            }

            if (retCode == RET_DBA_INFO_MD)
            {
                if (paramMsg.empty() == false)
                {
                    cerr << msg.str();
                }
                else
                {
                    cerr << endl;
                }
                cerr.flush();
            }
        }
        else if ((retCode & RET_LEV_ERROR) != 0)
        {
            MSG_SendMesg(RET_SCPT_ERR_SYNTAX, 3, FILEINFO, "in DDL generation", paramMsg.c_str());
        }
    }
}

/************************************************************************
**
**  Function    :  DdlGenMsg::printCatchMsg()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-26250 - LJE - 170501
**
*************************************************************************/
void DdlGenMsg::printCatchMsg(const char *file, const int line, const char *exeptMsg)
{
    if (exeptMsg != nullptr)
    {
        this->printMsg(RET_GEN_ERR_PERSONAL, exeptMsg);
    }

    this->printMsg(RET_GEN_ERR_PERSONAL, "Exception thrown, see log file ($AAAHOME/msg/log)");
    exceptionHandler(file, line, MSG_SendMesg);
}

/************************************************************************
**
**  Function    :   DdlGenMsg::startTimer()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
void DdlGenMsg::startTimer()
{
    this->m_bTimerStarted = true;
    this->m_startTime = std::chrono::steady_clock::now();
}

/************************************************************************
**
**  Function    :   DdlGenMsg::stopTimer()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
void DdlGenMsg::stopTimer()
{
    auto duration = std::chrono::duration_cast<std::chrono::duration<double>>(std::chrono::steady_clock::now() - this->m_startTime);
    this->m_bTimerStarted = false;

    this->m_totalDurationVector.push_back(duration.count());
}

/************************************************************************
**
**  Function    :   DdlGenMsg::resetTimer()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
void DdlGenMsg::resetTimer()
{
    this->m_bTimerStarted = false;
}

/************************************************************************
**
**  Function    :   DdlGenMsg::printTimer()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37366 - LJE - 200507
**
*************************************************************************/
const std::string DdlGenMsg::printTimer(bool bLastOnly)
{
    std::stringstream timerStream;
    double duration = 0;
    if (bLastOnly)
    {
        duration = this->m_totalDurationVector.back();
    }
    else
    {
        for (auto it = this->m_totalDurationVector.begin(); it != this->m_totalDurationVector.end(); ++it)
        {
            duration += (*it);
        }
    }

    timerStream << std::fixed << std::setprecision(4) << duration << " sec.";
    return timerStream.str();
}


/************************************************************************
**
**  Function    :   DdlGenMsg::removeComments()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
void DdlGenMsg::removeComments(stringstream& source, stringstream& target)
{
    string strLine;	//auxiliary string to store the read line
    bool flag = false;

    target.clear();
    target.str(string());

    source.clear();
    source.seekg(0, ios::beg);
    while (getline(source, strLine)) /* This loop is to get assure that the whole input file is read. */
    {
        /* checks comments for the read line */
        DdlGenMsg::checkComments(strLine, flag, target, false);
    }
    source.clear();
    source.seekg(0, ios::beg);
}

/************************************************************************
**
**  Function    :   DdlGenMsg::removeComments()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
void DdlGenMsg::removeComments(string& source)
{
    stringstream sourceSteam(source);
    stringstream targetStream;

    DdlGenMsg::removeComments(sourceSteam, targetStream);

    source = targetStream.str();
}

/************************************************************************
**
**  Function    :   DdlGenMsg::compareString()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-49178 - LJE - 221108
**
*************************************************************************/
bool DdlGenMsg::compareString(const std::string& source, const std::string& target)
{
    static const std::set<char> spaces = { ' ', '\t', '\n' };

    auto srcIt = source.begin();
    auto trgIt = target.begin();
    bool bSame = true;

    while (bSame)
    {
        while (srcIt != source.end() &&
               spaces.find(*srcIt) != spaces.end())
        {
            ++srcIt;
        }

        while (trgIt != target.end() &&
               spaces.find(*trgIt) != spaces.end())
        {
            ++trgIt;
        }

        if (srcIt == source.end() || trgIt == target.end())
        {
            if (srcIt != source.end() || trgIt != target.end())
            {
                bSame = false;
            }
            break;
        }

        if ((*srcIt) != (*trgIt) && toupper((*srcIt)) != toupper((*trgIt)))
        {
            bSame = false;
        }
        ++srcIt;
        ++trgIt;
    }

    return bSame;
}

/************************************************************************
**
**  Function    :   DdlGenMsg::checkComments()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
void DdlGenMsg::checkComments(const string& lineStr, bool& inComment, stringstream& target, bool bSingleLine, bool bTrim)
{
    string::size_type i;
    bool inQuote = false;
    bool inDubQuote = false;
    stringstream newLine;

    for (i = 0; i < lineStr.length(); i++)
    {
        /* Inside " or ', no comment detected */
        if ((inQuote    && lineStr[i] != '\'') ||
            (inDubQuote && lineStr[i] != '"'))
        {
            newLine << lineStr[i];
            continue;
        }

        if (!inComment)
        {
            /* Detect ' or " only if not in comment */
            if (lineStr[i] == '\'')
            {
                inQuote = !inQuote;
                newLine << lineStr[i];
                continue;
            }

            if (lineStr[i] == '"')
            {
                inDubQuote = !inDubQuote;
                newLine << lineStr[i];
                continue;
            }
        }

        if (inComment &&
            lineStr[i] == '*' && i + 1 < lineStr.length() && lineStr[i + 1] == '/')
        {
            /* No more in comment */
            inComment = false;
            i++;
            continue;
        }
        if (lineStr[i] == '/' && i + 1 < lineStr.length() && lineStr[i + 1] == '*')
        {
            /* Start comment */
            inComment = true;
            i++;
            continue;
        }
        else if (inComment == false && lineStr[i] == '-' && i + 1 < lineStr.length() && lineStr[i + 1] == '-')
        {
            break;
        }

        if (!inComment)
        {
            newLine << lineStr[i];
        }
    }

    if (!inComment &&
        newLine.str().find_first_not_of(" \t") != string::npos)
    {
        if (bTrim)
        {
            string newLineStr = newLine.str();
            target << trim(newLineStr);
        }
        else
        {
        	target << newLine.str();
        }
        
        if (bSingleLine == false)
        {
            target << endl;
        }
    }
}


/************************************************************************
**
**  Function    :   DdlGenMsg::incPosWOComment()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-24414 - LJE - 170203
**
*************************************************************************/
void DdlGenMsg::incPosWOComment(const std::string& lineStr, size_t& pos)
{
    if (lineStr[pos] == '/' &&
        pos + 1 < lineStr.length() &&
        lineStr[pos + 1] == '*')
    {
        pos = lineStr.find("*/", pos);
    }
    else if (lineStr[pos] == '-' &&
             pos + 1 < lineStr.length() &&
             lineStr[pos + 1] == '-')
    {
        pos = string::npos;
    }
    else
    {
        pos++;
    }
}

/************************************************************************
**
**  Function    :   DdlGenFullTable::copyDynFld()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210622
**
*************************************************************************/
void DdlGenMsg::copyDynFld(DBA_DYNFLD_STP   dest,
                           int              destFld,
                           DBA_DYNFLD_STP   src,
                           int              srcFld)
{
    COPY_DYNFLD(dest, dest->getDynStEn(), destFld, src, src->getDynStEn(), srcFld);
}


/*************************************************************************
**   END  ddlgenmsg.cpp                                        Odyssey **
*************************************************************************/


/************************************************************************
**
**              Copyright (C) Temenos Software Luxembourg SA 1995-2021.
**                       All Rights Reserved
**
**                   Portfolio Management System
**
*************************************************************************/
#ifndef DBAFMT_H
#define DBAFMT_H

/************************************************************************
**      External Structure definitions
*************************************************************************/
class DdlGenContext;

extern RET_CODE DBA_CopyFmtToXd(DBA_DYNFLD_STP, DdlGenContext &);                                /* PMSTA-22072 - LJE - 160108 */
extern RET_CODE DBA_GetXdFromFmt(DbiConnectionHelper &, const char *, DBA_DYNFLD_STP &, std::vector<DBA_DYNFLD_STP> &, MemoryPool &);
extern RET_CODE DBA_CreateXdAttribFromFmtElt(DbiConnectionHelper&, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, INT_T &, DBA_ACTION_ENUM);

extern RET_CODE DBA_CompleteXdModelForFmt(DBA_DYNFLD_STP, DdlGenContext &);                                       /* PMSTA-16528 - DDV - 140704 */ /* PMSTA-45413 - LJE - 210728 */
extern RET_CODE DBA_CreateAllXdModelForQuest(DdlGenContext &);
extern RET_CODE DBA_CreateXdModelForQuestByCd(const std::string&, DdlGenContext &);
extern RET_CODE DBA_GetQuestByCd(const std::string&, DdlGenContext&, DBA_DYNFLD_STP&, MemoryPool&);

/************************************************************************
**      Generate Format element             HFI-PMSTA-38117-200109
**      Generate Reference Format element   HFI-PMSTA-38206-201128
*************************************************************************/
extern RET_CODE DBA_CheckReferenceFormatElement(ID_T, DBA_DYNFLD_STP**, int*, FLAG_T*, FLAG_T*, DBA_DYNFLD_STP, DBA_ERRMSG_INFOS_STP);
extern RET_CODE DBA_GenerateReferenceFormatElement(ID_T, ID_T);
extern RET_CODE DBA_CheckGenerateReferenceFormatElement(ID_T, ID_T, char **);

/* PMSTA-45413 - LJE - 210616 - ddlgen */
extern RET_CODE DBA_GetXdObject(OBJECT_ENUM, DBA_DYNFLD_STP, DBA_DYNFLD_STP*, DbiConnectionHelper&);
extern RET_CODE DBA_InsXdObject(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper&);
extern RET_CODE DBA_UpdXdObject(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper&);

#endif
/* ifndef DBA_H */

/************************************************************************
**      END        dba.h
*************************************************************************/

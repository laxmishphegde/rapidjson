/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define FINSRV05_C

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H
#define MATH_H

#include "unidef.h"         /* Mandatory */
#include "gen.h"
#include "date.h"
#include "dba.h"
#include "hier.h"
#include "fin.h"
#include "finsrv.h"
#include "tls.h"
#include "scptyl.h"
#include "srvperf2.h"
#include "dbaperf.h" /* REF9125 - RAK - 030923 */
#include "srvperfa.h" /* PMSTA08736 - LJE - 100622 */
#include "srvperf4.h" /*PMSTA-48195 - Lalby - 020123*/
#include "ope.h"

/*#define FUNDSPLIT_MAXLEVEL   3
#define RISKDECOMPO_MAXLEVEL 4 */ /* REF7574 - YST - 021007 - defined in finsrv.h */

/* CSY - 000713 - REENG Return */
TIMER_ST SV_NewAnalysisReturnTimer;
TIMER_ST SV_ReturnDelPtfSynthTimer;
TIMER_ST SV_ReturnVerifPtfSynthTimer;
TIMER_ST SV_ReturnVerifPtfSynthGroupFreqTimer;
TIMER_ST SV_ReturnVerifPtfSynthGroupDetTimer;
TIMER_ST SV_ReturnVerifPtfSynthConvertTimer;
TIMER_ST SV_ReturnVerifPtfSynthGridEmptyMktTimer;
TIMER_ST SV_VerifPtfSynthFreqTimer;
TIMER_ST SV_ComputePtfSynthTimer;
TIMER_ST SV_ReturnProcessTimer;
TIMER_ST SV_ReturnProcessInitTimer;
TIMER_ST SV_ReturnProcessDecompPosTimer;
TIMER_ST SV_ReturnRefAmtAndValoTimer;
TIMER_ST SV_DateReturnProcessTimer;
TIMER_ST SV_SynthConsoStepTimer;
TIMER_ST SV_GlobalSynthConsoStepTimer;
TIMER_ST SV_RetCompLoadPtfSynthTimer;
TIMER_ST SV_GetPtfFreqInfoForSynthTimer;
TIMER_ST SV_GetPtfFreqInfoForPtfStoreTimer; /* REF7395 - YST - 020606 */
TIMER_ST SV_GetPtfFreqInfoForReturnTimer;
TIMER_ST SV_ReturnComputePtfSynthPeriodTimer;
TIMER_ST SV_ReturnComputePPSPtfSynthTimer;
TIMER_ST SV_ReturnComputePtfSynthTimer;
TIMER_ST SV_DbaInsPtfSynthTimer;
TIMER_ST SV_DbaLoadPosTimer;
TIMER_ST SV_ReturnSelPtfByDomainTimer;
TIMER_ST SV_ReturnInsPtfInHierTimer;
TIMER_ST SV_RetCompLoadMessTimer;
TIMER_ST SV_ReturnCreateIndexTimer;

/*  -------------------------------------------------------------------------------------------- **
**  RETURN FUNCTIONS
**  -----------------
**  FIN_AnalysisReturn() 	Compute performance measurement
**
**  FIN_AddSynthConso() 	Add synthetics consolidated by market segment or globaly
**  FIN_ClassifPtfSynth() 	Classify synthetics (update fields mktSegtId and gridId)
**  FIN_ComputePtfSynth() 	Compute synthetics according to received domain
**  FIN_ComputeUnrealGainLoss() Compute unrealised gain or loss (capital and currenc P&L, ...)
**  FIN_ConvertPtfSynthCurr() 	Convert portfolio synthetics to received currency
**  FIN_CreateBlankPtfSynth() 	Add blank portfolio synthetics
**  FIN_CreateZeroPtfSynth() 	Add consolidate portfolio synthetics with values 0.
**  FIN_CreatePtfSynth() 	Add portfolio synthetics for current period and instrument.
**  FIN_CumulPtfSynth() 	Cumul amounts from two synthetics
**  FIN_CumulPtfSynthFreq() 	Cumul amounts from two synthetics (freq by freq)
**  FIN_DateReturnProcess() 	Construct portfolio synthetic record for received positions
**  FIN_GetNextCrystalDate() 	Read crystallised dates for find the next after received date
**  FIN_GetPtfFreqInfoForSynthAdmin() 	Get current portfolio frequency and crystallised dates
**  FIN_GridInfoGrid() 		Determine grid list
**  FIN_GridInfoInstr() 	Determine for each instrument is market segment (depending on grid)
**  FIN_GlobalSynthConso() 	Consolidate synthetics by market segment or globaly
**  FIN_GroupPtfSynthByDetLvl() Group synthetics by domain detail level
**  FIN_GroupPtfSynthByFreq()   Consolidate synthetics by frequency
**  FIN_InsertCrystalDatePos()	Insert new position as stock of flow at crystallised date
**  FIN_MergePtfSynth() 	    Merge all portfolio synthetics
**  FIN_MergeHierPtfSynth() 	Merge hierarchy portfolio synthetics
**  FIN_GetCommonFreq() 	Determine frequency (reading portfolio(s))
**  FIN_SynthAdmin() Compute and load portfolio(s) synthetics
**  FIN_ReturnDelPtfSynth()	Delete portfolio(s) synthetics
**  FIN_ReturnProcess() 	Compute crystallised dates and add positions on each date
**  FIN_ReturnVerifPtfSynth()	Verify loaded synthetics, (compute missing data)
**  FIN_ReturnVerifPtfSynthCompHistory()	Verify loaded synthetics for compute history (compute missing data)
**  FIN_SearchFlowFlg() 	Determine if flow is already created on dateeach date
**  FIN_SynthConso() 		Consolidate synthetics depend on domain informations
**  FIN_UpdPtfSynthAmt() 	Update synthetic amounts with position amounts
**  FIN_UpdPtfSynthRealFlow() 	Compute synthetic ptf data depending on balance position nature
**  FIN_UpdPtfSynthRealPos() 	Compute synthetic ptf data depending on balance position nature
**  FIN_UpdPtfSynthUnrealFlow() Compute all unrealised synthetics for received position
**  FIN_UpdPtfSynthUnrealPL() 	Update synthetics (unrealised P&L)
**  FIN_UpdPtfSynthUnrealPos() 	Compute all unrealised synthetics for received position
**  FIN_VerifPtfFreqCommFreq()	Verify that ptf frequency and common frequency are compatible
**  FIN_VerifPtfSynthFreq() 	Verificate portfolio's synthetics for frequency (compute missing)
**  FIN_VerifZeroPtfSynth()	Update zeroTab with instrument or market which have a 0 final value.
**  FIN_AddSynthCompHist()  Set gridId for gloabal synthetic for Synth Admin - compute history.
**  FIN_AddSynthCompHistNew()  Set gridId for gloabal synthetic for Synth Admin - compute history.
**
**  -------------------------------------------------------------------------------------------- **
**  COMPARISONS FUNCTIONS
**  ---------------------
**  FIN_CmpDetReturnPos() 	Position table is sorted by ptf, instrument, nature and pos date
**  FIN_CmpGlobalPtfSynth() 	Synthetics sorted by portfolio, nature and date and mkt sgt
**  FIN_CmpMktSgtInstr()	Grid table is sorted by market segment
**  FIN_CmpPtfSynthConso() 	Synthetics sorted by portfolio, instrument, nature and date
**  FIN_CmpReturnPos() 		Position table is sorted by ptf, nature and position date
**  FIN_CmpReturnPtf() 		Portfolio sorted by identifier
**  FIN_CmpPtfSynthPtfDate() 	Synthetics sorted by portfolio id, date
**  FIN_CmpPtfSynthPtfDateNat() Synthetics sorted by portfolio id, date, nature
**  FIN_CmpPtfSynthPtfDateNatMktSgt() Synthetics sorted by portfolio id, date, nature, market sgt
**  FIN_CmpPtfSynthPtfNatDetailDate() Synthetics sorted by ptf, nature, market sgt, instr and date
**  FIN_CmpPtfSynthPtfNatDetailDate2() Synthetics sorted by ptf, nature, market sgt, instr and date
**  FIN_CmpPtfSynthNatDetailDate()  Synthetics sorted by nature, market sgt, instr and date
**  FIN_CmpPtfSynthPtfDateGlobal    Synthetics sorted by portfolio id, initial date, global
**  FIN_CmpSStratLnkByPtfIdNatPrio         Short strategy links sorted by ptfId, nature, priority
**  FIN_CmpPtfSynthPtfPspDate		Synthetics sorted by portfolio id, psp id, date
**
**  -------------------------------------------------------------------------------------------- **
**  FILTER FUNCTIONS
**  ----------------
**  FIN_FilterGlobalSynthCompHist()     Extract global synthetics for given portfolio
**  FIN_FilterGridSynthCompHist()       Extract grid synthetics for given portfolio which were retrieved from database
**	FIN_FilterSynthCompHist()			Extract grid synthetics for given portfolio
**  FIN_FilterPtfSynthByPSPGlob()		Extract Ptf Synth for a given PSP and global Ptf Synth
**
**-------------------------------------------------------------------------------------------- */
/************************************************************************
**      Static definitions & data
*************************************************************************/

/* REF3230 - Move #define PTFSYNTH_REFDATE in gen.h */



STATIC int
        FIN_PtfSynthInstrIndexCmp(DBA_DYNFLD_STP*, DBA_DYNFLD_STP*), /* REF7574 - YST - 021007 */
        FIN_CmpChildrenPtf(DBA_DYNFLD_STP*, DBA_DYNFLD_STP*),
        FIN_CmpMktSgtId(DBA_DYNFLD_STP*, DBA_DYNFLD_STP*),
        FIN_CmpMktSgtSynth(DBA_DYNFLD_STP*, DBA_DYNFLD_STP*),
		FIN_CmpPtfSynthNatDetailDate(DBA_DYNFLD_STP*, DBA_DYNFLD_STP*), 	/* DVP261 */
        FIN_CmpPtfSynthPtfNatDetailDate(DBA_DYNFLD_STP*, DBA_DYNFLD_STP*), 	/* DVP261 */
		FIN_CmpPtfSynthPtfNatDetailDate2(DBA_DYNFLD_STP*, DBA_DYNFLD_STP*), /* REF7785 - YST - 021025 */
		FIN_CmpPtfSynthPtfDateNat(DBA_DYNFLD_STP*, DBA_DYNFLD_STP*),		/* DVP261 */

		FIN_CmpReturnPtf(DBA_DYNFLD_STP*, DBA_DYNFLD_STP*),			/* DVP261 */
        FIN_CmpPtfSynthPtfDateGlobal(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *),    /* REF6912 - CSY - 010810 */
        /*FIN_CmpSStratLnkByPtfIdNatPrio(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *),*/    /* REF7395 - CSY - 021031 *//* REF8948 - YST - 030508 - code reeng */
		FIN_CmpPtfSynthPtfPspDate(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *),	/* REF9834 - TEB - 040909 */

        FIN_FilterChildrenPtf(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP), /* REF7264 - LJE - 020131 */
		FIN_FilterDetSynth(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP),			/* DVP261 */ /* REF7264 - LJE - 020131 */
        FIN_FilterPtfSynthParent(DBA_DYNFLD_STP,
			                        DBA_DYNST_ENUM,
                                    DBA_DYNFLD_STP),
        FIN_FilterPtfSynthChild(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP),
        FIN_FilterGlobalSynthCompHist(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP),  /* REF8354 - YST - 021206 */
        FIN_FilterGridSynthCompHist(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP),    /* REF8354 - YST - 021217 */
		FIN_FilterPtfPSP(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP),				/* REF9357 - RAK - 040205 */
		FIN_FilterParentPtfPSP(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP),			/* PMSTA02013 - RAK - 071112 */
		FIN_FilterPtfSynthByPSPGlob(DBA_DYNFLD_STP, DBA_DYNST_ENUM , DBA_DYNFLD_STP),	/* REF9834 - TEB - 041130 */
        FIN_FilterSynthCompHist(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP),		/* REF9834 - TEB - 041207 */
        FIN_FilterPtfSynthByPSPInfo(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);	/* PMSTA-19202 - LJE - 150109 */


STATIC RET_CODE
        /* CSY - 001011: split old function FIN_GetPtfFreqInfo (suppressed) for return and for synth admin */
		FIN_GetPtfFreqInfoForSynthAdmin(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, SMALLINT_T*, FREQUNIT_ENUM*,
				        FIN_RET_FREQ_STP, RETURN_ARG_STP),		/* DVP261 */
        FIN_InsPtfSynth(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP,
                        FIN_RET_FREQ_STP,  DBA_INSPTFSYNTH_STP, FLAG_T, int, int), /* REF5392 */

        FIN_SynthAdminComputeMsg(RET_CODE, int, int, DBA_DYNFLD_STP, FIN_RET_FREQ_STP, DICT_FCT_STP, FLAG_T),
		FIN_SynthComputePPSPtfSynth(DBA_DYNFLD_STP, DATETIME_T, DBA_DYNFLD_STP,
					                 FIN_RET_FREQ_STP, RETURN_ARG_STP,
                                     PA_INFO_STP,   /* REF7395 - CSY - 020410 */
                                     int,
					                 DBA_HIER_HEAD_STP), /* REF1402 */
		FIN_SynthComputePtfSynthPeriod(DBA_DYNFLD_STP, DBA_DYNFLD_STP, FIN_RET_FREQ_STP,
                                        RETURN_ARG_STP,
                                        PA_INFO_STP,    /* REF7395 - CSY - 020410 */
                                        int,            /* REF8566/REF7395 - YST - 021204 */
                                        DBA_HIER_HEAD_STP), /* REF1402 */
		FIN_ReturnDelPtfSynth(DBA_DYNFLD_STP), 					/* DVP261 */
		FIN_ReturnVerifPtfSynth(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP), 		/* DVP261 */
		FIN_ReturnVerifPtfSynthCompHistory(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP), 	/* REF9834 - TEB - 040617 */
        FIN_SynthComputePtfSynth(DBA_DYNFLD_STP, DATETIME_T, DBA_DYNFLD_STP,
                                      FIN_RET_FREQ_STP, RETURN_ARG_STP,
                                      PA_INFO_STP,  /* REF7395 - CSY - 020410 */
                                      int,
                                      DBA_HIER_HEAD_STP),
        FIN_AddSynthCompHist(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP),    /* REF8354 - YST - 021206 */
		FIN_AddSynthCompHistNew(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP,DBA_DYNFLD_STP*, int); /* REF9834 - TEB - 041130 */


STATIC RET_CODE FIN_GetGridMktSgtWithoutTotal(ID_T, DBA_DYNFLD_STP**, int*);

STATIC COMPA_FREQ_ENUM FIN_VerifPtfFreqCommFreq(FREQUNIT_ENUM, SMALLINT_T,
						FREQUNIT_ENUM, SMALLINT_T, PTFCONSRULE_ENUM);		/* DVP261 */

/* REF9357 - RAK - 040205 */
STATIC void FIN_MsgNoPSPforPtf(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DICT_FCT_STP, int, int, DBA_DYNFLD_STP);

/* REF9834 - RAK - 040218 */
STATIC RET_CODE FIN_GroupPtfSynthToDomGridDetLvl(DBA_DYNFLD_STP, DBA_DYNFLD_STP*, int, DBA_HIER_HEAD_STP, RETURN_GRID_INFO_STP);
STATIC RET_CODE FIN_GroupPtfSynthToGeneralFreq(DBA_DYNFLD_STP, DBA_DYNFLD_STP*, int, DBA_HIER_HEAD_STP, FIN_RET_FREQ_STP);
STATIC RET_CODE FIN_ConvertPtfSynthToDomCurr(DBA_DYNFLD_STP, DBA_DYNFLD_STP*, int, DBA_HIER_HEAD_STP);
STATIC RET_CODE FIN_MergePtfSynthHierPtf(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP);
STATIC RET_CODE FIN_PtfSynthForAllMktSgtOfGrid(DBA_DYNFLD_STP, RETURN_GRID_INFO_STP, DBA_HIER_HEAD_STP);
STATIC RET_CODE FIN_CompHistPerfFirstDate(DBA_DYNFLD_STP*, int, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP**, int*); /* REF9834 - TEB - 040617 */

STATIC FLAG_T FIN_VerifPtfSynthIsComplete(DBA_DYNFLD_STP*, int, DATETIME_T*, int); /* REF9834 - TEB - 051210 */


/************************************************************************
**  PMSTA-16124 - 250413 - PMO
**  UNUSED FUNCTION REMOVED BY: CMS 176466
**
**
**  Function    :   FIN_CompHistPerfLastFinalDate()
**
**  Description :   Don't use synthetics valid before PerfLastFinalDate for computation
**
**
**  Function    :   STATIC int FIN_FilterPtfHierPsp(DBA_DYNFLD_STP dynSt,
**                                                  DBA_DYNST_ENUM dynStTp,
**                                                  DBA_DYNFLD_STP ptfPtr)
**
**  Description :   Extract PSP for a given
**                  return TRUE  -> record must be extract
**                         FALSE -> record musn't be extract
**
*************************************************************************/


/************************************************************************
**
**  Function    :   FIN_NewAnalysisReturn()
**
**  Description :   Called for fct SynthAdmin and Return, use CompDataEn
**		    Depending on CompDataEn
**		    - compute synthetics and store in database
**		    - use filled synthHierHead and compute missing synthetics
**		    - delete stored synthetics
**
**  Arguments   :   domainPtr     domain structure pointer
**                  synthHierHead synthetics hierarchy pointer
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   DVP261 - RAK - 961121
**  Modif.      :   DVP279 - RAK - 970522
**  Modif.	:   REF3646 - RAK - 990506
**  Modif.	:   REF3621 - RAK - 990714
**              REF5313 - CSY - 001017: add index on ptfId
**              REF7395 - CSY - 020812: licensee management
**              REF9834 - TEB - 040617
**
*************************************************************************/
RET_CODE FIN_NewAnalysisReturn(DBA_DYNFLD_STP domainPtr, 
                               DBA_HIER_HEAD_STP            synthHierHead)
{				
	RET_CODE	ret;
    MemoryPool mp;

    PA_LICENSEE_ENUM		isPALicenseEn=PALicensee_No;    /* REF7395 - CSY - 020812	*/
    RA_LICENSEE_ENUM		isRALicenseEn=RALicensee_No;    /* REF7395 - CSY - 020812	*/

	/* CSY - 000714 - reeng. return: reset timers */
    DATE_ResetTimer(&SV_NewAnalysisReturnTimer, TIMER_MASK_ALL);
    DATE_ResetTimer(&SV_ReturnDelPtfSynthTimer, TIMER_MASK_ALL);
    DATE_ResetTimer(&SV_ReturnVerifPtfSynthTimer, TIMER_MASK_ALL);
    DATE_ResetTimer(&SV_ReturnCreateIndexTimer, TIMER_MASK_ALL);
    DATE_ResetTimer(&SV_ReturnVerifPtfSynthGroupFreqTimer, TIMER_MASK_ALL);
    DATE_ResetTimer(&SV_ReturnVerifPtfSynthGroupDetTimer, TIMER_MASK_ALL);
    DATE_ResetTimer(&SV_ReturnVerifPtfSynthConvertTimer, TIMER_MASK_ALL);
    DATE_ResetTimer(&SV_ReturnVerifPtfSynthGridEmptyMktTimer, TIMER_MASK_ALL);
    DATE_ResetTimer(&SV_VerifPtfSynthFreqTimer, TIMER_MASK_ALL);
    DATE_ResetTimer(&SV_ComputePtfSynthTimer, TIMER_MASK_ALL);
    DATE_ResetTimer(&SV_ReturnProcessTimer, TIMER_MASK_ALL);
    DATE_ResetTimer(&SV_ReturnProcessInitTimer, TIMER_MASK_ALL);
    DATE_ResetTimer(&SV_ReturnProcessDecompPosTimer, TIMER_MASK_ALL);
    DATE_ResetTimer(&SV_ReturnRefAmtAndValoTimer, TIMER_MASK_ALL);
    DATE_ResetTimer(&SV_DateReturnProcessTimer, TIMER_MASK_ALL);
    DATE_ResetTimer(&SV_SynthConsoStepTimer, TIMER_MASK_ALL);
    DATE_ResetTimer(&SV_GlobalSynthConsoStepTimer, TIMER_MASK_ALL);
    DATE_ResetTimer(&SV_GetPtfFreqInfoForSynthTimer, TIMER_MASK_ALL);
    DATE_ResetTimer(&SV_GetPtfFreqInfoForReturnTimer, TIMER_MASK_ALL);
    DATE_ResetTimer(&SV_RetCompLoadPtfSynthTimer, TIMER_MASK_ALL);
    DATE_ResetTimer(&SV_ReturnComputePtfSynthPeriodTimer, TIMER_MASK_ALL);
    DATE_ResetTimer(&SV_ReturnComputePPSPtfSynthTimer, TIMER_MASK_ALL);
    DATE_ResetTimer(&SV_ReturnComputePtfSynthTimer, TIMER_MASK_ALL);
    DATE_ResetTimer(&SV_DbaInsPtfSynthTimer, TIMER_MASK_ALL);
    DATE_ResetTimer(&SV_DbaLoadPosTimer, TIMER_MASK_ALL);
    DATE_ResetTimer(&SV_ReturnSelPtfByDomainTimer, TIMER_MASK_ALL);
    DATE_ResetTimer(&SV_ReturnInsPtfInHierTimer, TIMER_MASK_ALL);
    DATE_ResetTimer(&SV_RetCompLoadMessTimer, TIMER_MASK_ALL);

    DATE_StartTimer(&SV_NewAnalysisReturnTimer, TIMER_MASK_ALL);

    DBA_DYNFLD_STP tmpDomPtr = mp.allocDynst(FILEINFO,A_Domain);
	COPY_DYNST(tmpDomPtr, domainPtr, A_Domain);

	switch((COMPDATA_ENUM) GET_ENUM(tmpDomPtr, A_Domain_CompDataEn))
	{
	case CompData_NewPermanent :		/* REF1402 - RAK - 981005 */
	case CompData_NewNonPermanent :
	case CompData_ReplacePermanent :
	case CompData_ReplaceNonPermanent :
        DATE_StartTimer(&SV_RetCompLoadPtfSynthTimer, TIMER_MASK_ALL);
        ret = FIN_SynthAdmin(tmpDomPtr, synthHierHead, NULL);
        DATE_StopTimer(&SV_RetCompLoadPtfSynthTimer, TIMER_MASK_ALL);  
	    break;

    case CompData_CompHistory:  /* REF7395 - CSY - 020815 */
	case CompData_UseStored :
	    /* REF3646 - Stupid request ... */
	    if (DATETIME_CMP(GET_DATETIME(tmpDomPtr, A_Domain_InterpFromDate),
			     GET_DATETIME(tmpDomPtr, A_Domain_InterpTillDate)) == 0)
		return(RET_SUCCEED);

        DATE_StartTimer(&SV_ReturnVerifPtfSynthTimer, TIMER_MASK_ALL);

        /* REF7395 - CSY - 020812 */
        /* get licensee keys PA and RA */
        GEN_GetApplInfo(ApplPALicense, &isPALicenseEn);
	    GEN_GetApplInfo(ApplRALicense, &isRALicenseEn);
        /* if PA=0 and RA=0: force global ret_det_level in return analysis */
        if(isPALicenseEn == (PA_LICENSEE_ENUM)PALicensee_No
                            &&
            isRALicenseEn == (RA_LICENSEE_ENUM)RALicensee_No)
        {
            SET_ENUM(tmpDomPtr, A_Domain_RetDetLevelEn,
                                    (PTFRETDETLVL_ENUM)PtfRetDetLvl_Global);
        }

		/* REF9834 - TEB - 040617 */
		/* Use new function for CompData_CompHistory */
		if ((COMPDATA_ENUM) GET_ENUM(tmpDomPtr, A_Domain_CompDataEn)==CompData_CompHistory)
		{
			ret = FIN_ReturnVerifPtfSynthCompHistory(tmpDomPtr, synthHierHead);
		}
		else
		{
			ret = FIN_ReturnVerifPtfSynth(tmpDomPtr, synthHierHead);
		}

        DATE_StopTimer(&SV_ReturnVerifPtfSynthTimer, TIMER_MASK_ALL);

        DATE_StartTimer(&SV_ReturnCreateIndexTimer, TIMER_MASK_ALL);

	    /* REF3621 - RAK - 990714 */
	    /* Now that all synthetic are loaded or computed, index them by    */
	    /* instrument or market segment (depending on domain detail level) */
	    /* so select in mean cap computation will be better ...            */
	    if (ret == RET_SUCCEED)
	    {
		    if ((PTFRETDETLVL_ENUM) GET_ENUM(tmpDomPtr, A_Domain_RetDetLevelEn) == PtfRetDetLvl_Grid)
		    {
		        ret = DBA_NewHierIndex(synthHierHead, 
			                       A_PtfSynth, 
			                       A_PtfSynth_MktSegtId, 
					       FIN_PtfSynthMktSgtIndexCmp, TRUE); /* Define and build index */
		    }
		    else if ((PTFRETDETLVL_ENUM) GET_ENUM(tmpDomPtr, A_Domain_RetDetLevelEn) == PtfRetDetLvl_Instrument)
		    {
		         ret = DBA_NewHierIndex(synthHierHead, 
			                       A_PtfSynth, 
			                       A_PtfSynth_InstrId, 
					       FIN_PtfSynthInstrIndexCmp, TRUE); /* Define and build index */
		    }
            else /* REF5313 - CSY - 001017: index by ptfId also possible */
            {
                ret = DBA_NewHierIndex(synthHierHead, 
			                       A_PtfSynth, 
			                       A_PtfSynth_PtfId, 
					       FIN_PtfSynthPtfIndexCmp, TRUE); /* Define and build index */
            }
	    }
        DATE_StopTimer(&SV_ReturnCreateIndexTimer, TIMER_MASK_ALL);

	    break;

	case CompData_Delete :
        DATE_StartTimer(&SV_ReturnDelPtfSynthTimer, TIMER_MASK_ALL);
	    ret = FIN_ReturnDelPtfSynth(tmpDomPtr);
        DATE_StopTimer(&SV_ReturnDelPtfSynthTimer, TIMER_MASK_ALL);
	    break;

	default :
	    ret = RET_GEN_ERR_INVARG;
	}


	DATE_StopTimer(&SV_NewAnalysisReturnTimer, TIMER_MASK_ALL);

        switch((COMPDATA_ENUM) GET_ENUM(domainPtr, A_Domain_CompDataEn))
        {
        case CompData_NewPermanent :            /* REF1402 - RAK - 981005 */
        case CompData_NewNonPermanent :
        case CompData_ReplacePermanent :
        case CompData_ReplaceNonPermanent :
        /* CSY - 000714 - reeng. */
	    /*
            printf("\nFIN_NewAnalysisReturn           %5d.%03d", SV_NewAnalysisReturnTimer.cumul.tv_sec, SV_NewAnalysisReturnTimer.cumul.tv_usec/1000);
            printf("\nFIN_SynthAdmin                  %5d.%03d", SV_RetCompLoadPtfSynthTimer.cumul.tv_sec, SV_RetCompLoadPtfSynthTimer.cumul.tv_usec/1000);
            printf("\nDBA_SelPtfByDomain              %5d.%03d", SV_ReturnSelPtfByDomainTimer.cumul.tv_sec, SV_ReturnSelPtfByDomainTimer.cumul.tv_usec/1000);
            printf("\nFIN_SynthAdmin (ins Ptf hier)   %5d.%03d", SV_ReturnInsPtfInHierTimer.cumul.tv_sec, SV_ReturnInsPtfInHierTimer.cumul.tv_usec/1000);
            printf("\nFIN_SynthAdmin (messages)       %5d.%03d", SV_RetCompLoadMessTimer.cumul.tv_sec, SV_RetCompLoadMessTimer.cumul.tv_usec/1000);
            printf("\nFIN_GetPtfFreqInfoForSynth      %5d.%03d", SV_GetPtfFreqInfoForSynthTimer.cumul.tv_sec, SV_GetPtfFreqInfoForSynthTimer.cumul.tv_usec/1000);
            printf("\nFIN_SynthComputePtfSynthPeriod  %5d.%03d", SV_ReturnComputePtfSynthPeriodTimer.cumul.tv_sec, SV_ReturnComputePtfSynthPeriodTimer.cumul.tv_usec/1000);
            printf("\nFIN_ReturnComputePPSPtfSynth    %5d.%03d", SV_ReturnComputePPSPtfSynthTimer.cumul.tv_sec, SV_ReturnComputePPSPtfSynthTimer.cumul.tv_usec/1000);
            printf("\nDBA_InsPtfSynth                 %5d.%03d", SV_DbaInsPtfSynthTimer.cumul.tv_sec, SV_DbaInsPtfSynthTimer.cumul.tv_usec/1000);
            printf("\n\nFIN_ReturnComputePtfSynth     %5d.%03d", SV_ReturnComputePtfSynthTimer.cumul.tv_sec, SV_ReturnComputePtfSynthTimer.cumul.tv_usec/1000);
            printf("\nFIN_ComputePtfSynth             %5d.%03d", SV_ComputePtfSynthTimer.cumul.tv_sec, SV_ComputePtfSynthTimer.cumul.tv_usec/1000);
            printf("\nDBA_LoadPos                     %5d.%03d", SV_DbaLoadPosTimer.cumul.tv_sec, SV_DbaLoadPosTimer.cumul.tv_usec/1000);
            printf("\nFIN_ReturnProcess               %5d.%03d", SV_ReturnProcessTimer.cumul.tv_sec, SV_ReturnProcessTimer.cumul.tv_usec/1000);
            printf("\nFIN_ReturnProcess (init)        %5d.%03d", SV_ReturnProcessInitTimer.cumul.tv_sec, SV_ReturnProcessInitTimer.cumul.tv_usec/1000);
            printf("\nFIN_ReturnProcess (decomp pos)  %5d.%03d", SV_ReturnProcessDecompPosTimer.cumul.tv_sec, SV_ReturnProcessDecompPosTimer.cumul.tv_usec/1000);
            printf("\nFIN_ReturnRefAmtAndValo         %5d.%03d", SV_ReturnRefAmtAndValoTimer.cumul.tv_sec, SV_ReturnRefAmtAndValoTimer.cumul.tv_usec/1000);
            printf("\nFIN_DateReturnProcess           %5d.%03d", SV_DateReturnProcessTimer.cumul.tv_sec, SV_DateReturnProcessTimer.cumul.tv_usec/1000);
            printf("\nFIN_SynthConsoStep              %5d.%03d", SV_SynthConsoStepTimer.cumul.tv_sec, SV_SynthConsoStepTimer.cumul.tv_usec/1000);
            printf("\nFIN_GlobalSynthConsoStep        %5d.%03d", SV_GlobalSynthConsoStepTimer.cumul.tv_sec, SV_GlobalSynthConsoStepTimer.cumul.tv_usec/1000);
            break;

        case CompData_UseStored :
            printf("\nFIN_NewAnalysisReturn            %5d.%03d", SV_NewAnalysisReturnTimer.cumul.tv_sec, SV_NewAnalysisReturnTimer.cumul.tv_usec/1000);
            printf("\nFIN_ReturnVerifPtfSynth          %5d.%03d", SV_ReturnVerifPtfSynthTimer.cumul.tv_sec, SV_ReturnVerifPtfSynthTimer.cumul.tv_usec/1000);
            printf("\nReturn create index              %5d.%03d", SV_ReturnCreateIndexTimer.cumul.tv_sec, SV_ReturnCreateIndexTimer.cumul.tv_usec/1000);
            printf("\nDBA_SelPtfByDomain               %5d.%03d", SV_ReturnSelPtfByDomainTimer.cumul.tv_sec, SV_ReturnSelPtfByDomainTimer.cumul.tv_usec/1000);
            printf("\nFIN_VerifPtfSynthFreq            %5d.%03d", SV_VerifPtfSynthFreqTimer.cumul.tv_sec, SV_VerifPtfSynthFreqTimer.cumul.tv_usec/1000);
            printf("\nFIN_GetPtfFreqInfoForReturn      %5d.%03d", SV_GetPtfFreqInfoForReturnTimer.cumul.tv_sec, SV_GetPtfFreqInfoForReturnTimer.cumul.tv_usec/1000);
            printf("\nFIN_ComputePtfSynth              %5d.%03d", SV_ComputePtfSynthTimer.cumul.tv_sec, SV_ComputePtfSynthTimer.cumul.tv_usec/1000);
            printf("\nDBA_LoadPos                      %5d.%03d", SV_DbaLoadPosTimer.cumul.tv_sec, SV_DbaLoadPosTimer.cumul.tv_usec/1000);
            printf("\nFIN_ReturnProcess                %5d.%03d", SV_ReturnProcessTimer.cumul.tv_sec, SV_ReturnProcessTimer.cumul.tv_usec/1000);
            printf("\nFIN_ReturnProcess (init)         %5d.%03d", SV_ReturnProcessInitTimer.cumul.tv_sec, SV_ReturnProcessInitTimer.cumul.tv_usec/1000);
            printf("\nFIN_ReturnProcess (decomp pos)   %5d.%03d", SV_ReturnProcessDecompPosTimer.cumul.tv_sec, SV_ReturnProcessDecompPosTimer.cumul.tv_usec/1000);
            printf("\nFIN_ReturnRefAmtAndValo          %5d.%03d", SV_ReturnRefAmtAndValoTimer.cumul.tv_sec, SV_ReturnRefAmtAndValoTimer.cumul.tv_usec/1000);
            printf("\nFIN_DateReturnProcess            %5d.%03d", SV_DateReturnProcessTimer.cumul.tv_sec, SV_DateReturnProcessTimer.cumul.tv_usec/1000);
            printf("\nFIN_SynthConsoStep               %5d.%03d", SV_SynthConsoStepTimer.cumul.tv_sec, SV_SynthConsoStepTimer.cumul.tv_usec/1000);
            printf("\nFIN_GlobalSynthConsoStep         %5d.%03d", SV_GlobalSynthConsoStepTimer.cumul.tv_sec, SV_GlobalSynthConsoStepTimer.cumul.tv_usec/1000);
            printf("\nReturnVerifPtfSynth (group det ) %5d.%03d", SV_ReturnVerifPtfSynthGroupDetTimer.cumul.tv_sec, SV_ReturnVerifPtfSynthGroupDetTimer.cumul.tv_usec/1000);
            printf("\nReturnVerifPtfSynth (group freq) %5d.%03d", SV_ReturnVerifPtfSynthGroupFreqTimer.cumul.tv_sec, SV_ReturnVerifPtfSynthGroupFreqTimer.cumul.tv_usec/1000);
            printf("\nReturnVerifPtfSynth (convert)    %5d.%03d", SV_ReturnVerifPtfSynthConvertTimer.cumul.tv_sec, SV_ReturnVerifPtfSynthConvertTimer.cumul.tv_usec/1000);
            printf("\nReturnVerifPtfSynth (grid empty) %5d.%03d", SV_ReturnVerifPtfSynthGridEmptyMktTimer.cumul.tv_sec, SV_ReturnVerifPtfSynthGridEmptyMktTimer.cumul.tv_usec/1000);
	    */
            break;

        case CompData_Delete :
	/*
            printf("\nFIN_ReturnDelPtfSynth           %5d.%03d", SV_ReturnDelPtfSynthTimer.cumul.tv_sec, SV_ReturnDelPtfSynthTimer.cumul.tv_usec/1000);
            printf("\nDBA_SelPtfByDomain              %5d.%03d", SV_ReturnSelPtfByDomainTimer.cumul.tv_sec, SV_ReturnSelPtfByDomainTimer.cumul.tv_usec/1000);
	    */
            break;
        }
	return(ret);
}

/* REF5313 - CSY - 001017: index on ptfId */
int FIN_PtfSynthPtfIndexCmp(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
	return(CMP_DYNFLD(*ptr1, *ptr2,
	                  A_PtfSynth_PtfId, A_PtfSynth_PtfId, IdType));
}

int FIN_PtfSynthMktSgtIndexCmp(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
	int	cmp;

    if ((cmp = CMP_DYNFLD(*ptr1, *ptr2,
                      A_PtfSynth_MktSegtId, A_PtfSynth_MktSegtId, IdType)) != 0)
        return(cmp);

	return(CMP_DYNFLD(*ptr1, *ptr2,
	                  A_PtfSynth_PtfId, A_PtfSynth_PtfId, IdType));
}

STATIC int FIN_PtfSynthInstrIndexCmp(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    int	cmp;

    if ((cmp = CMP_DYNFLD(*ptr1, *ptr2,
                      A_PtfSynth_InstrId, A_PtfSynth_InstrId, IdType)) != 0)
        return(cmp);

	return(CMP_DYNFLD(*ptr1, *ptr2,
	                  A_PtfSynth_PtfId, A_PtfSynth_PtfId, IdType));
}

/************************************************************************
**
**  Function    :   FIN_GetPtfReturnInParentRule()
**
**  Description :   Get the return in parent rule for a portfolio
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   PMSTA02013 - RAK - 071112
**
*************************************************************************/
RETURNINPARENTPTFRULE_ENUM FIN_GetPtfReturnInParentRule(DBA_DYNFLD_STP domainPtr, DBA_DYNFLD_STP ptfStp)
{
	RETURNINPARENTPTFRULE_ENUM returnInParentPtfRuleEn=ReturnInParentPtfRule_Children;
	DBA_DYNFLD_STP parPtfPtr = NULL;

	if (GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None &&
		(PTFCONSRULE_ENUM) GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) != PtfConsRule_DetailedChildren &&
        ((static_cast<LOADHIERPTF_ENUM> GET_ENUM(domainPtr, A_Domain_LoadHierFlg) != LoadHierPtf_IntermediateHierarchy) ?
            true : FIN_IsPtfConsRuleValidForIntermediateHierarchy(domainPtr) == false))
	{
		GEN_GetApplInfo(ApplReturnInParentPtfRule, &returnInParentPtfRuleEn);

		if (returnInParentPtfRuleEn == ReturnInParentPtfRule_Children && nullptr == SYS_GetEnv("PMSTA02013"))  // WEALTH-15968 temp test
		{
			/* Force computing in the parent if the return frequency is TWR */
			if ((GET_ENUM(ptfStp, A_Ptf_RetFreqUnitEn) == FreqUnit_MonthGlobalTWR ||
				 GET_ENUM(ptfStp, A_Ptf_RetFreqUnitEn) == FreqUnit_MonthTWR) &&
				(GET_EXTENSION_PTR(ptfStp, A_Ptf_HierPtf_Ext) == NULL ||
				  (parPtfPtr = *(GET_EXTENSION_PTR(ptfStp, A_Ptf_HierPtf_Ext))) == NULLDYNST ||
				  GET_ENUM(parPtfPtr, A_Ptf_RetFreqUnitEn) == FreqUnit_MonthGlobalTWR ||
				  GET_ENUM(parPtfPtr, A_Ptf_RetFreqUnitEn) == FreqUnit_MonthTWR))
			{
				returnInParentPtfRuleEn = ReturnInParentPtfRule_Parent;
			}
		}
	}

	/* to simplify callers test */
	if (returnInParentPtfRuleEn == ReturnInParentPtfRule_ParentUsingHierPSP)
		returnInParentPtfRuleEn = ReturnInParentPtfRule_Parent;

	return returnInParentPtfRuleEn;
}

/************************************************************************
**
**  Function    :   FIN_RemoveChildrenPtfForHierPSP()
**
**  Description :   Remove unsued children portfolios when hierarchical PSP
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   PMSTA02013 - RAK - 071112
**
*************************************************************************/
STATIC RET_CODE FIN_RemoveChildrenPtfForHierPSP(DBA_HIER_HEAD_STP synthHierHead, DBA_DYNFLD_STP domainPtr, DBA_DYNFLD_STP** ptfTabPtr, int* ptfNbrPtr)
{
	int i, pspNbr=0;
	RET_CODE ret=RET_SUCCEED;

	if ((*ptfNbrPtr) > 0) /* PMSTA-10775 - LJE - 110110 */
	{
		/* Keep only the parents */
		DBA_DYNFLD_STP	    *tmpPtfTab=NULLDYNSTPTR;
		int		            tmpPtfNbr=0;

		if ((tmpPtfTab = (DBA_DYNFLD_STP *)CALLOC((*ptfNbrPtr), sizeof(DBA_DYNFLD_STP))) == NULL)
		{
			return(RET_MEM_ERR_ALLOC);
		}

		for (i=0; i<(*ptfNbrPtr); i++)
		{

			if (IS_NULLFLD((*ptfTabPtr)[i], A_Ptf_HierPortId) == FALSE)
            {
				ret = DBA_HierGetRecNbrWithFilterSt(synthHierHead, A_PerfStorageParam,
													FIN_FilterPtfPSP, (*ptfTabPtr)[i], &pspNbr, FALSE);

				if (ret == RET_SUCCEED && pspNbr == 0)
				{
					ret = DBA_HierGetRecNbrWithFilterSt(synthHierHead, A_PerfStorageParam,
														FIN_FilterParentPtfPSP, (*ptfTabPtr)[i], &pspNbr, FALSE);

					if (ret == RET_SUCCEED && pspNbr > 0)
					{
						continue; /* Don't keep children ptfs without PSP */
					}
				}
			}

			tmpPtfTab[tmpPtfNbr] = (*ptfTabPtr)[i];
			tmpPtfNbr++;
		}


		FREE((*ptfTabPtr));
		(*ptfTabPtr) = tmpPtfTab;
		(*ptfNbrPtr) = tmpPtfNbr;
	}

	return RET_SUCCEED;

}

/************************************************************************
**
**  Function    :  FIN_FilterAddedInParentFlg()
**
**  Description :  filter function to get records of A_PtfSynth_AddedInParentFlg
**
**  Arguments   :  portsynth record
**
**  Return      :  RET_SUCCEED or error code
**
**  Creation    : PMSTA-48195 -Performance IPS Level -Lalby-310123

*************************************************************************/

STATIC int FIN_FilterAddedInParentFlg(DBA_DYNFLD_STP  dynSt,
    DBA_DYNST_ENUM      dynStTp,
    DBA_DYNFLD_STP      unusedPtr)
{
    if (GET_FLAG(dynSt, A_PtfSynth_AddedInParentFlg) == TRUE)
        return(TRUE);
    else
        return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_FilterPortSynthWithPspId
**
**  Description :   filter with pspid
**
**  Arguments   :
**
**  Return      : true/false
**
**  Creation    :  PMSTA-48195 -Performance IPS Level -Lalby-310123
**
*************************************************************************/
STATIC int FIN_FilterPortSynthWithPspId(DBA_DYNFLD_STP hierPos, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP inEsl)
{
    if (CMP_DYNFLD(hierPos, inEsl, A_PtfSynth_PSPId, A_PerfStorageParam_Id, IdType) == 0)
    {
        return TRUE;
    }

    return FALSE;
}


/************************************************************************
**
**  Function    :   FIN_RemoveChildrenPtf()
**
**  Description :   Remove unsued children portfolios
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   PMSTA02013 - RAK - 071112
**
*************************************************************************/
STATIC RET_CODE FIN_RemoveChildrenPtf(DBA_HIER_HEAD_STP synthHierHead, DBA_DYNFLD_STP domainPtr, DBA_DYNFLD_STP** ptfTabPtr, int* ptfNbrPtr)
{
	int i, j, synthNbr=0;
	RET_CODE ret=RET_SUCCEED;
	DBA_DYNFLD_STP *synthTab=NULL;
    MemoryPool   mp;

    RETURNINPARENTPTFRULE_ENUM	returnInParentPtfRuleEn = ReturnInParentPtfRule_Children;
    if (static_cast<LOADHIERPTF_ENUM> GET_ENUM(domainPtr, A_Domain_LoadHierFlg) == LoadHierPtf_IntermediateHierarchy)
    {
        returnInParentPtfRuleEn = ReturnInParentPtfRule_Parent;
    }
    else
    {
        GEN_GetApplInfo(ApplReturnInParentPtfRule, &returnInParentPtfRuleEn);
    }

	if (GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None)
	{
		/* Keep only the parents */
        DBA_DYNFLD_STP	    *tmpPtfTab= (DBA_DYNFLD_STP *)mp.calloc((*ptfNbrPtr), sizeof(DBA_DYNFLD_STP));
		int		            tmpPtfNbr=0;

		synthNbr = 0;
		if (synthHierHead != (DBA_HIER_HEAD_STP)NULL)
		{
			if ((ret = DBA_ExtractHierEltRec(synthHierHead, A_PtfSynth,
							 FALSE, NULLFCT, FIN_CmpPtfSynthPtfDate,
							 &synthNbr, &synthTab)) != RET_SUCCEED)
            {
                FREE(synthTab);
                return(ret);
            }
            mp.ownerPtr(synthTab);
		}

		for (i=0, j=0; i<(*ptfNbrPtr); i++)
		{
			/* could be updated according to ptf specification */
			returnInParentPtfRuleEn = FIN_GetPtfReturnInParentRule(domainPtr, (*ptfTabPtr)[i]);

			if (IS_NULLFLD((*ptfTabPtr)[i], A_Ptf_HierPortId) == TRUE)
			{
				tmpPtfTab[tmpPtfNbr] = (*ptfTabPtr)[i];
				tmpPtfNbr++;
			}
			else
			{
				/* Force computing in the parent if the return frequency is TWR */
				if (returnInParentPtfRuleEn == ReturnInParentPtfRule_Children)
				{
					tmpPtfTab[tmpPtfNbr] = (*ptfTabPtr)[i];
					tmpPtfNbr++;
				}
			}

			if (returnInParentPtfRuleEn == ReturnInParentPtfRule_Parent)
			{
				/* Remove all obsolete portfolio synthetics */
				while (j<synthNbr && GET_ID(synthTab[j], A_PtfSynth_PtfId) <= GET_ID((*ptfTabPtr)[i], A_Ptf_Id))
				{
					if (GET_ID(synthTab[j], A_PtfSynth_PtfId) == GET_ID((*ptfTabPtr)[i], A_Ptf_Id) &&
						(IS_NULLFLD((*ptfTabPtr)[i], A_Ptf_HierPortId) == FALSE ||
						 GET_ENUM(synthTab[j], A_PtfSynth_PersistEn) == PersistNat_Persist ||
						 GET_ENUM(synthTab[j], A_PtfSynth_PersistEn) == PersistNat_NoPersist))
					{
						DBA_DelHierEltRec(synthHierHead, A_PtfSynth, synthTab[j]);
					}
					j++;
				}
			}
		}

		FREE((*ptfTabPtr));
		(*ptfTabPtr) = tmpPtfTab;
        mp.removePtr(tmpPtfTab);
		(*ptfNbrPtr) = tmpPtfNbr;
	}
	/* no load hier but new computation method -> don't used stored hierarchical */
	else if (returnInParentPtfRuleEn != ReturnInParentPtfRule_Children)
	{
		/* don't keep hierarchical synthetics */
		synthNbr = 0;
		if (synthHierHead != (DBA_HIER_HEAD_STP)NULL)
		{
			if ((ret = DBA_ExtractHierEltRec(synthHierHead, A_PtfSynth,
							 FALSE, NULLFCT, FIN_CmpPtfSynthPtfDate,
							 &synthNbr, &synthTab)) != RET_SUCCEED)
            {
                FREE(synthTab);
                return(ret);
            }
            mp.ownerPtr(synthTab);
		}

		/* Remove all obsolete portfolio synthetics */
		for (j=0; j<synthNbr; j++)
		{
			if (GET_ENUM(synthTab[j], A_PtfSynth_PersistEn) == PersistNat_HierarchicalPersist ||
				GET_ENUM(synthTab[j], A_PtfSynth_PersistEn) == PersistNat_HierarchicalNoPersist)
			{
				DBA_DelHierEltRec(synthHierHead, A_PtfSynth, synthTab[j]);
			}
		}
	}

	return RET_SUCCEED;
}

/************************************************************************
**
**  Function    :   FIN_GetPtfReturnInParentRuleUsingPSP
**
**  Description :   GetPtfReturnInParentRuleUsingPSP
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   WEALTH-10550 - Lalby - 22072024
**
*************************************************************************/
RETURNINPARENTPTFRULE_ENUM FIN_GetPtfReturnInParentRuleUsingPSP(DBA_DYNFLD_STP domainPtr, DBA_DYNFLD_STP ptfPtr, 
                                                                DBA_DYNFLD_STP  pspPtr)
{
    RETURNINPARENTPTFRULE_ENUM returnInParentPtfRuleEn = ReturnInParentPtfRule_Children;
    /* PMSTA02013 - RAK - 071112 : Check and test if we make portfolio synthetics on full hierarchy or on each portfolio */
    if (pspPtr == NULL)
    {
        /* Return Analysis Case */
        returnInParentPtfRuleEn = FIN_GetPtfReturnInParentRule(domainPtr, ptfPtr);
    }
    else
    {
        /* Portfolio storage case */
        /* Children     -> all PSP will be computed with old method */
        /* Parent       -> all PSP will be computed with new method (hierarchical) */
        /* UsingHierPSP -> hierarchical PSP will be computed with new method */
        GEN_GetApplInfo(ApplReturnInParentPtfRule, &returnInParentPtfRuleEn);

        /* PMSTA-16740 - LJE - 130730 - Use the information in the PSP, in all cases */
        if (GET_ENUM(pspPtr, A_PerfStorageParam_PerfAttribReturnEn) == PerfAttribRtnEn_Hierarchy)
        {
            returnInParentPtfRuleEn = ReturnInParentPtfRule_Parent;
        }
        else
        {
            returnInParentPtfRuleEn = ReturnInParentPtfRule_Children;
        }

        if (returnInParentPtfRuleEn == ReturnInParentPtfRule_Children &&
            GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None)
        {
            /* PMSTA08159 - LJE - 090514 - Force Parent in of List ptf with MergedTWR */
            /* WEALTH-4556 - DDV - 240220 - Adapt check. For One Ptf, virtual portfolio is no more use */
            if ((PTFCONSRULE_ENUM)GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) == PtfConsRule_MergedTWR &&
                (GET_ID(ptfPtr, A_Ptf_Id) < 0 ||
                 (GET_DICT(domainPtr, A_Domain_DimEntityDictId) == OneCst && GET_DICT(domainPtr, A_Domain_DimPtfDictId) == PtfCst)) /* WEALTH-4556 - DDV - 240209 - MergeTWR on one portfolio, no more use virtual Ptf */
                )
            {
                returnInParentPtfRuleEn = ReturnInParentPtfRule_Parent;
            }
        }
    }
    return returnInParentPtfRuleEn;
}

/************************************************************************
**
**  Function    :   FIN_FilterPerfCompPeriodForPtfMerged()
**
**  Description :   Return the Merged periods for the
**
**
**  Creation	:   WEALTH-10540 - Lalby - 05082024
**
*************************************************************************/
STATIC int FIN_FilterPerfCompPeriodForPtfMerged(DBA_DYNFLD_STP dynSt,
    DBA_DYNST_ENUM,
    DBA_DYNFLD_STP IoStp)
{
    if (static_cast<PerfCompPeriodTechNatEn>(GET_ENUM(dynSt, S_PerfComputationPeriod_TechNatEn)) == PerfCompPeriodTechNatEn::PtfMerged &&
        GET_ID(IoStp, Io_Id_Id) == GET_ID(dynSt, S_PerfComputationPeriod_PtfId))
    {
        return(TRUE);
    }
    return(FALSE);
}
/************************************************************************
**
**  Function    :  FIN_CmpCmputationPeriod()
**
**  Description :  computation period order by  begindate
**
**  Arguments   :  cmpuatationperios 1 and computationperiod 2
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  creation   :   WEALTH-11151-Lalby-19082024
*************************************************************************/
STATIC int FIN_CmpCmputationPeriod(DBA_DYNFLD_STP* cmp1, DBA_DYNFLD_STP* cmp2)
{
    return(DATETIME_CMP(GET_DATETIME((*cmp1), S_PerfComputationPeriod_BeginDate),
        GET_DATETIME((*cmp2), S_PerfComputationPeriod_BeginDate)));
}
/************************************************************************
**
**  Function    :   FIN_SynthAdmin()
**
**  Description :   Compute and load portfolio(s) synthetics
**
**  Arguments   :   domainPtr     domain structure pointer
**                  synthHierHead synthetics hierarchy pointer
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   DVP261 - RAK - 961203
**  Modif    	:   DVP261 - RAK - 961212
**  Modif    	:   DVP535 - RAK - 970707
**  Modif    	:   REF1465 - RAK - 980323
**  Modif    	:   REF2728 - RAK - 980917
**  Modif    	:   REF1402 - RAK - 980917
**		            REF4489 - SSO - 000315 memorize and return error.
**                  REF5244 - CSY - 001011: rename function FIN_ReturnCompLoadPtfSynth
**                                          in FIN_SynthAdmin
**  Modif.      :   REF5392 - RAK - 001121
**                  REF7395 - CSY - 020315 STATIC to EXTERN for use in portfolio storage
**                  REF7395 - CSY - 020809: licencee management
**                  REF7421 - YST - 020808 insert for portfolio storage
**                  REF7395 - CSY - 020930
**
*************************************************************************/
RET_CODE FIN_SynthAdmin(DBA_DYNFLD_STP    domainPtr,
				           DBA_HIER_HEAD_STP synthHierHead,
                           PA_INFO_STP   paInfoStp)
{
	DBA_DYNFLD_STP	*ptfTab=NULLDYNSTPTR;
	FIN_RET_FREQ_ST freqSt;
	int		        ptfNbr=0, paInfoIdx=0, loopNbr;
	char		    loop=0;
	SMALLINT_T	    oldFreq;
	FREQUNIT_ENUM	oldFreqUnit;
	DICT_T		    dictId;
	DATETIME_T	    crtDateTime, interpFromDate, interpTillDate, nullDateTime;
	RET_CODE	    ret = RET_SUCCEED, returnedRet = RET_SUCCEED,           /* REF4489 - SSO - 000315 */
                    ptfRet = RET_SUCCEED, insertRet = RET_SUCCEED;
	OPSTAT_ENUM	    minStatEn, maxStatEn;
    DBA_INSPTFSYNTH_ST  insPtfSynthSt;  /* REF5392 - RAK - 001121 */
    DBA_INSPAEXTRA_ST   insPaExtRaSt;   /* REF7421 - YST - 020808 */
    DICT_FCT_STP	    dictFctInfo;
	RETURN_ARG_ST	    retArg;	            /* REF2728 */
    PA_LICENSEE_ENUM		isPALicenseEn=PALicensee_No;    /* REF7395 - CSY - 020809 */
    RA_LICENSEE_ENUM		isRALicenseEn=RALicensee_No;    /* REF7395 - CSY - 020809 */
    COMPDATA_ENUM       saveCompDataEn = (COMPDATA_ENUM)GET_ENUM(domainPtr, A_Domain_CompDataEn);/* REF7758 - YST - 021029 */
    MemoryPool      mp;


    /* get licensee keys PA */
    GEN_GetApplInfo(ApplPALicense, &isPALicenseEn);
    GEN_GetApplInfo(ApplRALicense, &isRALicenseEn);

    memset(&nullDateTime, 0, sizeof(DATETIME_T));
    memset(&insPaExtRaSt, 0, sizeof(DBA_INSPAEXTRA_ST));
	memset(&insPtfSynthSt, 0, sizeof(DBA_INSPTFSYNTH_ST));
    insPtfSynthSt.startPtf = 1;

    DBA_GetDictFctInfo(GET_DICT(domainPtr, A_Domain_InitialFctDictId), DictFctInfo_Stp, &dictFctInfo);

    /* REF7395 - CSY - 020322 */
    if (GET_DICT(domainPtr, A_Domain_InitialFctDictId) == (DICT_FCT_ENUM)DictFct_PtfStorage)
    {
        /* force synth admin in case of portfolio storage, but after, test on A_Domain_InitialFctDictId
        to activate or not the insert of synthetics */
        SET_DICT(domainPtr, A_Domain_FctDictId, (DICT_FCT_ENUM)DictFct_SynthAdmin);
    }

    /* If we don't display the computed synthetics, delete synthetics after insertion */
    if (GET_FLAG(domainPtr, A_Domain_DispResultFlg) == FALSE)
        insPtfSynthSt.delSynthFlg = TRUE;

    memset(&retArg, 0, sizeof(RETURN_ARG_ST));
	retArg.domFromDate = GET_DATETIME(domainPtr, A_Domain_InterpFromDate);
	GEN_GetApplInfo(ApplReversalMethode, &retArg.reversalMethode);          /* REF4198 - 991208 - DED */

	returnedRet = RET_SUCCEED;  /* REF4489 - SSO - 000315 */

    DBA_DYNFLD_STP sPtfSynthPtr = mp.allocDynst(FILEINFO, S_PtfSynth);

	/* REF9882 - RAK - 040211 - Save default domain (received domain) */
    DBA_DYNFLD_STP savDomPtr = mp.allocDynst(FILEINFO, A_Domain);

	SET_DATETIME(sPtfSynthPtr, S_PtfSynth_InitialDate,
	    GET_DATETIME(domainPtr, A_Domain_InterpFromDate));

	SET_DATETIME(sPtfSynthPtr, S_PtfSynth_FinalDate,
	    GET_DATETIME(domainPtr, A_Domain_InterpTillDate));

    /* PMSTA-24945 - LJE - 161017 */
    DBA_HierAllIndexNoUpdate(synthHierHead, A_StandardPerf);
    DBA_HierAllIndexNoUpdate(synthHierHead, A_ExtRetAnalysis);
    DBA_HierAllIndexNoUpdate(synthHierHead, A_PerfAttrib);

	/* PMSTA06916 - LJE - 081007 - get portfolios from first load (PerfAnalysis) */
	if ((PTFCONSRULE_ENUM) GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) == PtfConsRule_MergedTWR &&
		GET_DICT(domainPtr, A_Domain_InitialFctDictId) == (DICT_FCT_ENUM)DictFct_PtfStorage)
	{
   		if ((ret = DBA_ExtractHierEltRec(synthHierHead, A_Ptf, FALSE,
										 NULLFCT, NULLFCT,
										 &ptfNbr, &ptfTab)) != RET_SUCCEED)
		{
            FREE(ptfTab);
			return(ret);
		}
        mp.ownerPtr(ptfTab);
	}
	else
	{
		/* REF9125 - RAK - 030918 - This function insert in hier the PSP of the portfolios  ! */
		DATE_StartTimer(&SV_ReturnSelPtfByDomainTimer, TIMER_MASK_ALL);
		/*PMSTA-44581 SSN 151221*/
		if (IS_NULLFLD(domainPtr, A_Domain_ChunkNumber) == FALSE)
		{
			DBA_GetDictId(QuickSearch, &dictId);
			SET_DICT(domainPtr, A_Domain_DimPtfDictId, dictId);
		}

        /* PMSTA-48195 -Performance IPS Level -Lalby-310123 */
        LOADHIERPTF_ENUM orgDomainEnum = static_cast<LOADHIERPTF_ENUM> GET_ENUM(domainPtr, A_Domain_LoadHierFlg);
        if (orgDomainEnum  == LoadHierPtf_IntermediateHierarchy)
        {
            if (FIN_IsPtfConsRuleValidForIntermediateHierarchy(domainPtr) == FALSE)
                return RET_SUCCEED; //log message if not controlled by Gui input control 

            /*To load all portfolio for intermediate PSP data store */
            if (IS_NULLFLD(domainPtr, A_Domain_OrigLoadHierFlg) == FALSE &&
                GET_ENUM(domainPtr, A_Domain_LoadHierFlg) != GET_ENUM(domainPtr, A_Domain_OrigLoadHierFlg)) /*WEALTH-5157-Lalby-08032024 */
            {
                SET_ENUM(domainPtr, A_Domain_LoadHierFlg, GET_ENUM(domainPtr, A_Domain_OrigLoadHierFlg));
            }
        }

		if ((ret = DBA_SelPtfByDomain(domainPtr, &ptfTab, &ptfNbr, synthHierHead)) != RET_SUCCEED || ptfNbr == 0) /* PMSTA-16367 - LJE - 130607 */
		{
            DBA_FreeDynStTab(ptfTab,ptfNbr,A_Ptf);
			DATE_StopTimer(&SV_ReturnSelPtfByDomainTimer, TIMER_MASK_ALL);
			return(ret);
		}

		DATE_StopTimer(&SV_ReturnSelPtfByDomainTimer, TIMER_MASK_ALL);

		DATE_StartTimer(&SV_ReturnInsPtfInHierTimer, TIMER_MASK_ALL);
		if ((ret = DBA_AddHierRecordList(synthHierHead, ptfTab, ptfNbr, A_Ptf, TRUE)) != RET_SUCCEED)
		{
            DBA_FreeDynStTab(ptfTab,ptfNbr,A_Ptf);
			DATE_StopTimer(&SV_ReturnInsPtfInHierTimer, TIMER_MASK_ALL);
			return(ret);
		}

        mp.ownerPtr(ptfTab);

		DATE_StopTimer(&SV_ReturnInsPtfInHierTimer, TIMER_MASK_ALL);

        if (orgDomainEnum == LoadHierPtf_IntermediateHierarchy)
        {
            /*changed for the intermediate , now revert back*/
            SET_ENUM(domainPtr, A_Domain_LoadHierFlg, LoadHierPtf_IntermediateHierarchy);
        }
	}

	DBA_DYNFLD_STP dummyPtf = nullptr;
    /* REF8701 - YST - 030129 - move code here */
    if(GET_DICT(domainPtr, A_Domain_InitialFctDictId) == (DICT_FCT_ENUM)DictFct_PtfStorage)
    {
        /*PMSTA-48195 -PerfIPSLevel -Lalby-180722*/
        /*-Build crystal dates that will be used for all portfolios.
         -Compute (using PSP of head portfolio) all portfolios in bottom-up order and cumulate at each level */
        if (static_cast<LOADHIERPTF_ENUM> GET_ENUM(domainPtr, A_Domain_LoadHierFlg) == LoadHierPtf_IntermediateHierarchy)
        {
            SET_ENUM(domainPtr, A_Domain_LoadHierFlg, GET_ENUM(domainPtr, A_Domain_OrigLoadHierFlg)); /*WEALTH-5157-Lalby-08032024 */
            /*Load positions for all portfolios*/
            if ((ret = FIN_LoadAllPositions(domainPtr, synthHierHead, ptfTab, ptfNbr)) != RET_SUCCEED)
            {
                SET_ENUM(domainPtr, A_Domain_LoadHierFlg, LoadHierPtf_IntermediateHierarchy);
                return(ret);
            }

            /*Get Ptf from the hiearchy - instead of passed one and update */
            mp.freePtr(ptfTab);

            if ((ret = DBA_ExtractHierEltRec(synthHierHead, A_Ptf, FALSE, NULLDYNST, NULLDYNST,
                &ptfNbr, &ptfTab)) != RET_SUCCEED)
            {
                FREE(ptfTab);
                SET_ENUM(domainPtr, A_Domain_LoadHierFlg, LoadHierPtf_IntermediateHierarchy);
                return(ret);
            }

            /*WEALTH-9420 - Lalby - 20062024 - Check port_link_history and add in hierarchy*/
            if (GET_FLAG(domainPtr, A_Domain_LoadDimPtfHistFlg) == TRUE || GET_FLAG(domainPtr, A_Domain_LoadHierHistFlg) == TRUE)
            {
                if ((ret = FIN_LoadPortLinkHistory(synthHierHead, domainPtr, ptfTab, ptfNbr)) != RET_SUCCEED)
                {
                    return ret;
                }
            }

             /*PMSTA-53952 - Lalby - 14112023 - Merged w/ detailed for list*/
            if (static_cast<PTFCONSRULE_ENUM>GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) == PtfConsRule_MergedTWR_Detail)
            {
                for (int i = 0; i < ptfNbr; ++i)
                {
                    if (GET_ID(ptfTab[i], A_Ptf_Id) < 0)
                    {
                        SET_SMALLINT(ptfTab[i], A_Ptf_Level, 0);
                        SET_ENUM(ptfTab[i], A_Ptf_RetDetLevelEn, GET_ENUM(domainPtr, A_Domain_RetDetLevelEn));
                        dummyPtf = ptfTab[i];
                        break;
                    }
                }

                if (dummyPtf == nullptr )
                {
                    return ret;
                }

                if (static_cast<LOADHIERPTF_ENUM>GET_ENUM(domainPtr, A_Domain_LoadHierFlg) == LoadHierPtf_None)
                {
                     for (int i = 0; i < ptfNbr; ++i)
                     {
                         if (GET_ID(dummyPtf, A_Ptf_Id) != GET_ID(ptfTab[i], A_Ptf_Id))
                         {
                             SET_ID(ptfTab[i], A_Ptf_ParentPortId, GET_ID(dummyPtf, A_Ptf_Id));
                             SET_ID(ptfTab[i], A_Ptf_HierPortId, GET_ID(dummyPtf, A_Ptf_Id));
                         }
                     }
                }
				else if (GET_FLAG(domainPtr, A_Domain_LoadDimPtfHistFlg) == TRUE || GET_FLAG(domainPtr, A_Domain_LoadHierHistFlg) == TRUE)
				{
					DBA_DYNFLD_STP* perfCompPeriodTab = NULLDYNSTPTR;
					int             perfCompPeriodNbr = 0;

					if ((ret = DBA_ExtractHierEltRec(synthHierHead, S_PerfComputationPeriod, FALSE, NULLDYNST, NULLDYNST,
						                             &perfCompPeriodNbr, &perfCompPeriodTab)) != RET_SUCCEED)
					{
						FREE(perfCompPeriodTab);
						return(ret);
					}
					mp.ownerPtr(perfCompPeriodTab);

					for (int i = 0; i < perfCompPeriodNbr; ++i)
					{
						if (IS_NULLFLD(perfCompPeriodTab[i], S_PerfComputationPeriod_ParentPortId) == TRUE)
						{
							SET_ID(perfCompPeriodTab[i], S_PerfComputationPeriod_ParentPortId, GET_ID(dummyPtf, A_Ptf_Id));
						}

						SET_ID(perfCompPeriodTab[i], S_PerfComputationPeriod_HierPortId, GET_ID(dummyPtf, A_Ptf_Id));
					}
				}
				else
				{
					for (int i = 0; i < ptfNbr; ++i)
					{
						if (GET_EXTENSION_PTR(ptfTab[i], A_Ptf_Parent_Ext) == NULL &&
							GET_ID(dummyPtf, A_Ptf_Id) != GET_ID(ptfTab[i], A_Ptf_Id))
						{
							SET_ID(ptfTab[i], A_Ptf_ParentPortId, GET_ID(dummyPtf, A_Ptf_Id));
						}
						if (GET_ID(dummyPtf, A_Ptf_Id) != GET_ID(ptfTab[i], A_Ptf_Id))
						{
							SET_ID(ptfTab[i], A_Ptf_HierPortId, GET_ID(dummyPtf, A_Ptf_Id));
						}
					}
				}
            }

            SET_ENUM(domainPtr, A_Domain_LoadHierFlg, LoadHierPtf_IntermediateHierarchy);

			/* WEALTH-16752 - DDV - 241120 - Use new link used for histiorical portfolio links */
			DBA_SetHierLnkUsed(synthHierHead, A_Ptf, A_Ptf_ParentHistoPCP_Ext);
			DBA_SetHierLnkUsed(synthHierHead, A_Ptf, A_Ptf_ChildrenHistoPCP_Ext);
			DBA_SetHierLnkUsed(synthHierHead, A_Ptf, A_Ptf_AllHierChildrenHistoPCP_Ext);
			DBA_SetHierLnkUsed(synthHierHead, S_PerfComputationPeriod, S_PerfComputationPeriod_Ptf_Ext);
			DBA_SetHierLnkUsed(synthHierHead, S_PerfComputationPeriod, S_PerfComputationPeriod_ParentPtf_Ext);
			DBA_SetHierLnkUsed(synthHierHead, S_PerfComputationPeriod, S_PerfComputationPeriod_HierPtf_Ext);
			DBA_MakeAllRecLinks(synthHierHead, A_Ptf);
			DBA_MakeAllRecLinks(synthHierHead, S_PerfComputationPeriod);

            /*WEALTH-9420 - Lalby - 20062024 - Check port_link_history and add in hierarchy*/
			if (GET_FLAG(domainPtr, A_Domain_LoadDimPtfHistFlg) == TRUE || GET_FLAG(domainPtr, A_Domain_LoadHierHistFlg) == TRUE)
			{
				FIN_SortPortfolioByLevelForHistorical(synthHierHead, domainPtr, ptfTab, ptfNbr, dummyPtf);
			}
			else
			{
				DBA_SetHierLnkUsed(synthHierHead, A_Ptf, A_Ptf_ChildrenPtf_Ext);
				DBA_SetHierLnkUsed(synthHierHead, A_Ptf, A_Ptf_Parent_Ext);
				DBA_SetHierLnkUsed(synthHierHead, A_Ptf, A_Ptf_HierPtf_Ext);
				DBA_SetHierLnkUsed(synthHierHead, A_Ptf, A_Ptf_HierChildrenPtf_Ext); /* WEALTH-8345 - lalby - 06062024 */

				DBA_MakeLinks(synthHierHead);

				FIN_SortPortfolioByLevel(synthHierHead, domainPtr, ptfTab, ptfNbr);
            }

            mp.ownerPtr(ptfTab);
 
            PTFCONSRULE_ENUM orgConsolidatedEn = static_cast<PTFCONSRULE_ENUM> GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn);
            SET_ENUM(domainPtr, A_Domain_PtfConsRuleEn, PtfConsRule_DetailedChildren);
            /* set paInfoStp (ptfId, pspId, delFromDate, delTillDate, crystalDates, ...) */
            if ((ret = FIN_SetPaDateInfoIPS(domainPtr, synthHierHead, ptfTab, ptfNbr, paInfoStp, orgConsolidatedEn)) != RET_SUCCEED)
            {
                SET_ENUM(domainPtr, A_Domain_LoadHierFlg, LoadHierPtf_IntermediateHierarchy);
                return(ret);
            }

            SET_ENUM(domainPtr, A_Domain_LoadHierFlg, LoadHierPtf_IntermediateHierarchy);
            SET_ENUM(domainPtr, A_Domain_PtfConsRuleEn, orgConsolidatedEn);

            if (static_cast<PTFCONSRULE_ENUM>GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) == PtfConsRule_MergedTWR_Detail )
            {
                FIN_UpdateDummyPtfWithPspInfo(domainPtr,synthHierHead);
            }
        }
        else
        {
            mp.removePtr(ptfTab);  // freed by  FIN_RemoveChildrenPtfForHierPSP
            FIN_RemoveChildrenPtfForHierPSP(synthHierHead, domainPtr, &ptfTab, &ptfNbr); /* PMSTA02013 - RAK - 071112 */
            mp.ownerPtr(ptfTab);

            /* REF8537 - YST - 030722 - set paInfoStp (ptfId, pspId, delFromDate, delTillDate, crystalDates, ...) */
            if ((ret = FIN_SetPaDateInfo(domainPtr, synthHierHead, ptfTab, ptfNbr, paInfoStp)) != RET_SUCCEED)
            {
                return(ret);
            }
        }
		loopNbr = paInfoStp->paDateInfoNbr;

        /*Dump hier for debug*/
        if (EV_TracePerf)
        {
            DBA_HierDump(synthHierHead, NullDynSt, FALSE, NULL);
        }

        for (int i = 0; i < ptfNbr; i++)
        {
            SET_NULL_DATETIME(ptfTab[i], A_Ptf_PerfLastFinalDate);
        }

        /* PMSTA08736 - LJE - 100622 - Laod full market structure with effect informations */
        ID_T *gridIdTab = (ID_T *)mp.calloc(paInfoStp->paDateInfoNbr + 1, sizeof(ID_T));
        int   gridNbr=0;

        for (int k=0; k<paInfoStp->paDateInfoNbr; k++)
        {
            if (IS_NULLFLD(paInfoStp->paDateInfoTab[k].pspPtr, A_PerfStorageParam_GridId) == TRUE)
			    continue;

		    /* Add grid id in gridIdTab (only if not allready done) */
            int j = 0;
		    for (j=0; j<gridNbr && GET_ID(paInfoStp->paDateInfoTab[k].pspPtr, A_PerfStorageParam_GridId)
                                                            != gridIdTab[j];j++); /* set j on same grid id or first free cell */

		    if (j == gridNbr)
            {
                gridIdTab[j] = GET_ID(paInfoStp->paDateInfoTab[k].pspPtr, A_PerfStorageParam_GridId);
                gridNbr++;
            }
        }

        if (gridNbr > 0)
        {
            if ((ret = DBA_LoadGridMktStruct(domainPtr, synthHierHead, gridIdTab, gridNbr)) != RET_SUCCEED)
            {
                return(ret);
            }
        }

        /* Set the "computeDuraFlg" */
        for (int k=0; k<paInfoStp->paDateInfoNbr; k++)
        {
            int             perfEffectLinkNbr;
            DBA_DYNFLD_STP *perfEffectLinkTab;

            paInfoStp->paDateInfoTab[k].computeDuraFlg = FALSE;

            if (GET_FLAG(paInfoStp->paDateInfoTab[k].pspPtr, A_PerfStorageParam_PerfAttribFlg) == TRUE &&
                IS_NULLFLD(paInfoStp->paDateInfoTab[k].pspPtr, A_PerfStorageParam_GridId) == FALSE)
            {
                ret = DBA_HierEltRecExtract(synthHierHead,
                                                 A_PerfEffectLink,
		                                         FALSE,
                                                 FIN_FilterEffectLinkByGridDura,
                                                 paInfoStp->paDateInfoTab[k].pspPtr,
                                                 NULL,
                                                 FALSE,
                                                 FALSE,
                                                 &perfEffectLinkNbr,
                                                 &perfEffectLinkTab);

                mp.ownerPtr(perfEffectLinkTab);

                if (ret == RET_SUCCEED &&
                     perfEffectLinkNbr != 0)
                {
                    paInfoStp->paDateInfoTab[k].computeDuraFlg = TRUE;
	            }
            }
        }
    }
	else
	{
		/* PMSTA02013 - RAK - 071112 : Remove children if needed */
        mp.removePtr(ptfTab);
		FIN_RemoveChildrenPtf(synthHierHead, domainPtr, &ptfTab, &ptfNbr);
        mp.ownerPtr(ptfTab);
		loopNbr = ptfNbr;
	}

	/* Compute synthetics portfolio by portfolio */
	DBA_GetDictId(Ptf, &dictId);
	SET_DICT(domainPtr, A_Domain_DimPtfDictId, dictId);

	/* Use appl_param minimum and maximum status */
	GEN_GetApplInfo(ApplSyntheticMaxStatus, &maxStatEn);
	GEN_GetApplInfo(ApplSyntheticMinStatus, &minStatEn);

	/* REF9883 - RAK - 040211 - If exist, use new system parameters PERF_DEF_MIN_STATUS and PERF_DEF_MAX_STATUS */
	if (GET_DICT(domainPtr, A_Domain_InitialFctDictId) == (DICT_FCT_ENUM)DictFct_PtfStorage)
	{
		OPSTAT_ENUM perfDefMaxStatEn, perfDefMinStatEn;

		GEN_GetApplInfo(ApplPerfDefMaxStatus, &perfDefMaxStatEn);
		GEN_GetApplInfo(ApplPerfDefMinStatus, &perfDefMinStatEn);

		if (perfDefMaxStatEn != OpStat_None)
			maxStatEn = perfDefMaxStatEn;

		if (perfDefMinStatEn != OpStat_None)
			minStatEn = perfDefMinStatEn;
	}

	SET_ENUM(domainPtr, A_Domain_MinStatEn, (ENUM_T) minStatEn);
	SET_ENUM(domainPtr, A_Domain_MaxStatEn, (ENUM_T) maxStatEn);

	/* REF1465 - Error on domain dates if frequencies are different in ptf list */
	interpFromDate = GET_DATETIME(domainPtr, A_Domain_InterpFromDate);
	interpTillDate = GET_DATETIME(domainPtr, A_Domain_InterpTillDate);

	memset(&freqSt, 0, sizeof(FIN_RET_FREQ_ST));

    /* REF5245 - RAK - 001114 */
    /* DVP DBA_SelectExchRateForPtfSynth() not used and suppressed */
    /* because of ioIdTab is replaced by ptfTab */

	/* REF3694 - keep most recent final date for update parameter SYNTHETIC_MAX_FINAL_DATE */
	/* memset(&lastFinalDate, 0, sizeof(DATETIME_T)); REF5260 - RAK - 001114 */
	DATE_CurrentDateTime(&crtDateTime);

	/* REF9882 - RAK - 040211 - Keep default domain (received domain) */
	/* Min status, Max status, PPS info, Fund split info, Strat Lnk info, ... */
	COPY_DYNST(savDomPtr, domainPtr, A_Domain);

    if (EV_TraceFinFctFile != NULL && EV_TraceFinFct >2 && synthHierHead != NULL)
    {
        DBA_HierDump(synthHierHead, NullDynSt, TRUE, EV_TraceFinFctFile);
    }

    /*WEALTH-10550 -  Lalby - 22072024 */
    /* For interediate hierarchy - make all ptfs padateInfo/crystal date to same for  valuation and cumul the data*/
    if (static_cast<LOADHIERPTF_ENUM> GET_ENUM(domainPtr, A_Domain_LoadHierFlg) == LoadHierPtf_IntermediateHierarchy)
    {
        std::set<DATETIME_T> dateTimeSet;
        for (int i = 0; i < paInfoStp->paDateInfoNbr; i++)
        {
            FLAG_T  allocFlg = FALSE;
            DBA_DYNFLD_STP ptfPtr = NULLDYNSTPTR;

            if ((ret=DBA_GetPtfById(paInfoStp->paDateInfoTab[i].ptfId, FALSE, &allocFlg,
                &ptfPtr, synthHierHead, UNUSED, UNUSED)) != RET_SUCCEED && ptfPtr == NULLDYNSTPTR)
            {
                return ret;
            }
            bool     bRecomputeFlowInfo = false;
            RETURNINPARENTPTFRULE_ENUM returnInParentPtfRuleEn = FIN_GetPtfReturnInParentRuleUsingPSP(domainPtr, ptfPtr, 
                                                                paInfoStp->paDateInfoTab[i].pspPtr);

            /* PMSTA03044 - LJE - 070829 */
            if ((static_cast<LOADHIERPTF_ENUM> GET_ENUM(domainPtr, A_Domain_LoadHierFlg) != LoadHierPtf_IntermediateHierarchy) &&
                (returnInParentPtfRuleEn == ReturnInParentPtfRule_Parent ||
                    (PTFCONSRULE_ENUM)GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) == PtfConsRule_MergedTWR)) /* PMSTA06916 - LJE - 081009 */
            {
                bRecomputeFlowInfo = true;
            }
            else if (GET_ENUM(domainPtr, A_Domain_CashFlowMgtEn) != CashFlowMgt_None) /* WEALTH-4688 - DDV - 240229 - As cash flow managamenet may generate new position, flow_info_e must be recompute */
            {
                bRecomputeFlowInfo = true;
            }

            char useRetFreqFlg = 0;
            FIN_RET_FREQ_STP returnFreqStp = NULLDYNSTPTR;
            DATETIME_T* crystalDates = NULL;
            int crystalNbr = 0;
            ret = FIN_CreateCrystaliseDate(synthHierHead, domainPtr, returnFreqStp, paInfoStp, i, &crystalDates, crystalNbr,
                                           useRetFreqFlg, bRecomputeFlowInfo, ptfPtr);

            for (int s = 0; s < crystalNbr; s++)
            {
                dateTimeSet.insert(crystalDates[s]);
            }
        }

        if (GET_FLAG(domainPtr, A_Domain_LoadDimPtfHistFlg) == TRUE || GET_FLAG(domainPtr, A_Domain_LoadHierHistFlg) == TRUE)
        {
            /*Update all paDates with same dates */
            for (int i = 0; i < paInfoStp->paDateInfoNbr; i++)
            {
                DBA_DYNFLD_STP     ptfIdDynSt = mp.allocDynst(FILEINFO, Io_Id);
                SET_ID(ptfIdDynSt, Io_Id_Id, paInfoStp->paDateInfoTab[i].ptfId);

                DBA_DYNFLD_STP* virtualCompPeriodTab = NULLDYNSTPTR;
                int                 virtualCompPeriodNb = 0;

                PA_DATETIME_STP paDateTab = static_cast<PA_DATETIME_STP>(CALLOC(paInfoStp->paDateInfoTab[i].paDatesNbr,
                                                                         sizeof(PA_DATETIME_ST)));

                /*WEALTH-12890 - Lalby - 03092022 - consider the entire range of computation period*/
                DatePeriod dateRangeObj(GET_DATETIME(domainPtr, A_Domain_OrigBeginDate),
                    GET_DATETIME(domainPtr, A_Domain_OrigEndDate));

                if ((ret = DBA_ExtractHierEltRecWithFilterSt(synthHierHead, S_PerfComputationPeriod, FALSE, FIN_FilterPerfCompPeriodForPtfMerged,
                    ptfIdDynSt, FIN_CmpCmputationPeriod, &virtualCompPeriodNb, &virtualCompPeriodTab)) == RET_SUCCEED && virtualCompPeriodNb > 0)
                {
                    if (IS_NULLFLD(virtualCompPeriodTab[0], S_PerfComputationPeriod_BeginDate) == FALSE &&
                        dateRangeObj.cmpBegin(GET_DATETIME(virtualCompPeriodTab[0], S_PerfComputationPeriod_BeginDate)) < 0)
                    {
                        dateRangeObj.setBegin(GET_DATETIME(virtualCompPeriodTab[0], S_PerfComputationPeriod_BeginDate));
                    }
                    if (IS_NULLFLD(virtualCompPeriodTab[0], S_PerfComputationPeriod_EndDate) == FALSE &&
                        dateRangeObj.cmpEnd(GET_DATETIME(virtualCompPeriodTab[0], S_PerfComputationPeriod_EndDate))>0)
                    {
                        dateRangeObj.setEnd(GET_DATETIME(virtualCompPeriodTab[0], S_PerfComputationPeriod_EndDate));
                    }

                    for (int k = 1; k < virtualCompPeriodNb; k++)
                    {
                        if (IS_NULLFLD(virtualCompPeriodTab[k], S_PerfComputationPeriod_BeginDate) == FALSE)
                        {
                            if (dateRangeObj.cmpBegin(GET_DATETIME(virtualCompPeriodTab[k], S_PerfComputationPeriod_BeginDate)) > 0)
                            {
                                dateRangeObj.setBegin(GET_DATETIME(virtualCompPeriodTab[k], S_PerfComputationPeriod_BeginDate));
                            }
                        }
                        if (IS_NULLFLD(virtualCompPeriodTab[k], S_PerfComputationPeriod_EndDate) == FALSE)
                        {
                            if (dateRangeObj.cmpEnd(GET_DATETIME(virtualCompPeriodTab[k], S_PerfComputationPeriod_EndDate)) < 0)
                            {
                                dateRangeObj.setEnd(GET_DATETIME(virtualCompPeriodTab[k], S_PerfComputationPeriod_EndDate));
                            }
                        }
                    }
                }

                if (EV_TracePerf)
                {
                         MSG_LogSrvMesg(UNUSED, 0, "ptf %1  compBegin: %2 compEnd  %3",
                                IdType, paInfoStp->paDateInfoTab[i].ptfId,
                                DatetimeType, dateRangeObj.getBegin(),
                                DatetimeType, dateRangeObj.getEnd());
                }
                else
                {
                    MSG_LogSrvMesg(UNUSED, 0, "computation period is not found for %1",
                        IdType, paInfoStp->paDateInfoTab[i].ptfId);
                }

                /* consider the paDates only in the range of computation period */
                int newIndx = 0;
                for (int k = 0; k < paInfoStp->paDateInfoTab[i].paDatesNbr; k++)
                {
                    if (DATETIME_CMP(paInfoStp->paDateInfoTab[i].paDates[k].dateTime, dateRangeObj.getBegin()) >= 0 &&
                        DATETIME_CMP(paInfoStp->paDateInfoTab[i].paDates[k].dateTime, dateRangeObj.getEnd()) <= 0)
                    {
                        paDateTab[newIndx++] = paInfoStp->paDateInfoTab[i].paDates[k];
                    }
                }
                /* check if any common dates is missing - For intermediate all ptfs should valuate in same crystal dates */
                DATETIME_T orgFromDate = GET_DATETIME(domainPtr, A_Domain_InterpFromDate);
                DATETIME_T orgTillDate = GET_DATETIME(domainPtr, A_Domain_InterpTillDate);
                SET_DATETIME(domainPtr, A_Domain_InterpFromDate, dateRangeObj.getBegin());
                SET_DATETIME(domainPtr, A_Domain_InterpTillDate, dateRangeObj.getEnd());

                for (auto const& dateTime : dateTimeSet)
                {
                    if (DATETIME_CMP(dateTime, dateRangeObj.getBegin()) >= 0 &&
                        DATETIME_CMP(dateTime, dateRangeObj.getEnd()) <= 0)
                    {
                        /* WEALTH-11502 - Lalby - 21092024 */
                        PA_DATETIME_ST   newPADate;
                        memset(&newPADate, 0, sizeof(PA_DATETIME_ST));
                        newPADate.dateTime = dateTime;
                        FIN_AddPADate(domainPtr, &newPADate, &(paDateTab), &newIndx);
                    }
                }
           
                SET_DATETIME(domainPtr, A_Domain_InterpFromDate, orgFromDate);
                SET_DATETIME(domainPtr, A_Domain_InterpTillDate, orgTillDate);

                FREE(paInfoStp->paDateInfoTab[i].paDates);
                paInfoStp->paDateInfoTab[i].paDates = paDateTab;
                paInfoStp->paDateInfoTab[i].paDatesNbr = newIndx;
            }
        }
        else
        {
            /*Update all paDates with same dates */
            for (int i = 0; i < paInfoStp->paDateInfoNbr; i++)
            {
                for (auto const& dateTime : dateTimeSet)
                {
                    /* WEALTH-11502 - Lalby - 21092024 */
                    PA_DATETIME_ST   newPADate;
                    memset(&newPADate, 0, sizeof(PA_DATETIME_ST));
                    newPADate.dateTime = dateTime;
                    FIN_AddPADate(domainPtr, &newPADate, &(paInfoStp->paDateInfoTab[i].paDates), &(paInfoStp->paDateInfoTab[i].paDatesNbr));
                }
            }
        }
    }

    if (EV_TracePerf)
    {
        msgLogPaDateInfo(paInfoStp->paDateInfoTab, paInfoStp->paDateInfoNbr);
    }
	/* REF9125 - YST - 030723 - loop on elements in paDateInfoTab - adjustement for i = ptf counter */
    int i =0;
	for (paInfoIdx=0, i=0, oldFreq=-1, oldFreqUnit=FreqUnit_None; paInfoIdx<loopNbr; paInfoIdx++ /*i<ptfNbr; i++*/)
	{
        if(EV_TracePerf)
        {
            MSG_LogSrvMesg(UNUSED, 0, "Loop -> paDateInfo: ptf %1 freq %2 indx %3",
                           IdType, paInfoStp->paDateInfoTab[paInfoIdx].ptfId,
                           EnumType, paInfoStp->paDateInfoTab[paInfoIdx].freqUnitEn,
                           IntType, paInfoIdx);
         }
		/* REF1465 - Error on domain dates if frequencies are different in ptf list */
		SET_DATETIME(domainPtr, A_Domain_InterpFromDate, interpFromDate);
		SET_DATETIME(domainPtr, A_Domain_InterpTillDate, interpTillDate);

		/* REF9836 - RAK - 040122 - move here the update of the domain so the date in the message will be correct ! */
		if ((DICT_FCT_ENUM) GET_DICT(domainPtr, A_Domain_InitialFctDictId) == DictFct_PtfStorage && paInfoStp != (PA_INFO_STP) NULL)
		{
			/* REF9882 - RAK - 040211 - Re-init domain, elsewhere last PPDA informations are keeped in case of no PPDA in following PSP */
			/* Min status, Max status, PPS info, Fund split info, Strat Lnk info, ... */
			COPY_DYNST(domainPtr, savDomPtr, A_Domain);

			DBA_UpdDomainWithPSPInfo(synthHierHead, domainPtr, paInfoStp->paDateInfoTab[paInfoIdx].pspPtr);

			/* REF9836 - RAK - 040126 - Update dates for message */
			SET_DATETIME(domainPtr, A_Domain_InterpFromDate, paInfoStp->paDateInfoTab[paInfoIdx].paDates[0].dateTime);
			SET_DATETIME(domainPtr, A_Domain_InterpTillDate, paInfoStp->paDateInfoTab[paInfoIdx].paDates[(paInfoStp->paDateInfoTab[paInfoIdx].paDatesNbr)-1].dateTime);
		}

		/* REF9125 - RAK - 030828 - set i on portfolio of the current PSP */
        if ((DICT_FCT_ENUM)GET_DICT(domainPtr, A_Domain_InitialFctDictId) == DictFct_SynthAdmin)
		{i = paInfoIdx;}
		else if (paInfoStp->paDateInfoTab[paInfoIdx].ptfId != GET_ID(ptfTab[i], A_Ptf_Id))
		{
			/* REF9688 - RAK - 031119 - Go to next portfolio (this is treated) */
			if (paInfoStp->paDateInfoTab[paInfoIdx].ptfId != GET_ID(ptfTab[i], A_Ptf_Id))
			{
				if (paInfoIdx == 0)
				{
					FIN_MsgNoPSPforPtf(synthHierHead, domainPtr, dictFctInfo, i, ptfNbr, ptfTab[i]);
				}
				i++;
			}

			while (i<ptfNbr && paInfoStp->paDateInfoTab[paInfoIdx].ptfId != GET_ID(ptfTab[i], A_Ptf_Id))
			{
				/* REF9688 - RAK - 031119 */
				if (paInfoStp->paDateInfoTab[paInfoIdx].ptfId != GET_ID(ptfTab[i], A_Ptf_Id))
				{
					FIN_MsgNoPSPforPtf(synthHierHead, domainPtr, dictFctInfo, i, ptfNbr, ptfTab[i]);
				}

				i++;
			}
		}

        /* REF9125 - RAK - 030923 - display PSP in message */
		if(GET_DICT(domainPtr, A_Domain_InitialFctDictId) == (DICT_FCT_ENUM)DictFct_PtfStorage)
		{
			/* PMSTA06916 - LJE - 081105 */
			if (paInfoStp->mergedTWRFlg == TRUE)
			{
				if (paInfoStp->mergedTWRObjStp != NULL &&
					GET_DYNSTENUM(paInfoStp->mergedTWRObjStp) == A_List)
				{
					MSG_LogSrvMesg(UNUSED, 0, "%1 : portfolio list merged TWR %2 started",
								   NameType, dictFctInfo->name, CodeType, GET_CODE(paInfoStp->mergedTWRObjStp, A_List_Cd));

					DBA_PSPInfoOrLogSrvMesg(synthHierHead, domainPtr, dictFctInfo, List, GET_CODE(paInfoStp->mergedTWRObjStp, A_List_Cd),
										    GET_ID(paInfoStp->paDateInfoTab[paInfoIdx].pspPtr, A_PerfStorageParam_Id),
										    paInfoStp->paDateInfoTab[paInfoIdx].pspPtr, NULL);

				}
				else if (paInfoStp->mergedTWRObjStp != NULL &&
					     GET_DYNSTENUM(paInfoStp->mergedTWRObjStp) == A_Third)
				{
					MSG_LogSrvMesg(UNUSED, 0, "%1 : third party merged TWR %2 started",
								   NameType, dictFctInfo->name, CodeType, GET_CODE(paInfoStp->mergedTWRObjStp, A_Third_Cd));

					DBA_PSPInfoOrLogSrvMesg(synthHierHead, domainPtr, dictFctInfo, Third, GET_CODE(paInfoStp->mergedTWRObjStp, A_Third_Cd),
										    GET_ID(paInfoStp->paDateInfoTab[paInfoIdx].pspPtr, A_PerfStorageParam_Id),
										    paInfoStp->paDateInfoTab[paInfoIdx].pspPtr, NULL);
				}
				else
				{
					MSG_LogSrvMesg(UNUSED, 0, "%1 : Quick Search merged TWR started",
								   NameType, dictFctInfo->name);

					DBA_PSPInfoOrLogSrvMesg(synthHierHead, domainPtr, dictFctInfo, QuickSearch, "",
										    GET_ID(paInfoStp->paDateInfoTab[paInfoIdx].pspPtr, A_PerfStorageParam_Id),
										    paInfoStp->paDateInfoTab[paInfoIdx].pspPtr, NULL);
				}
			}
			else
			{
				if (paInfoIdx == 0 ||
					paInfoStp->paDateInfoTab[paInfoIdx-1].ptfId != paInfoStp->paDateInfoTab[paInfoIdx].ptfId)
				{
					MSG_LogSrvMesg(UNUSED, 0, "%1 %2 of %3: portfolio %4 started",
							   NameType, dictFctInfo->name, IntType, i+1, IntType, ptfNbr,
							   CodeType, GET_CODE(ptfTab[i], A_Ptf_Cd));
				}

				/* REF9688 - RAK - 031120 */
				DBA_PSPInfoOrLogSrvMesg(synthHierHead, domainPtr, dictFctInfo, Ptf, GET_CODE(ptfTab[i], A_Ptf_Cd),  /* REF9770 - LJE - 040121 */
								  GET_ID(paInfoStp->paDateInfoTab[paInfoIdx].pspPtr, A_PerfStorageParam_Id),
								  paInfoStp->paDateInfoTab[paInfoIdx].pspPtr, NULL);
			}

		}
		else
		{
			MSG_LogSrvMesg(UNUSED, 0, "%1 %2 of %3: portfolio %4 started",
						   NameType, dictFctInfo->name, IntType, i+1, IntType, ptfNbr,
			               CodeType, GET_CODE(ptfTab[i], A_Ptf_Cd));
		}

        /* REF5245 - RAK - 001114 - Suppress Get2 on portfolio, use ptfTab[i] */

        /* REF7395 - YST - 020607 - call new function for ptf storage */
        if(GET_DICT(domainPtr, A_Domain_InitialFctDictId) == (DICT_FCT_ENUM)DictFct_PtfStorage)
        {
			ret = RET_SUCCEED;

            /* REF7758 - YST - 021029 - compute online */
            if ((COMPDATA_ENUM)GET_ENUM(domainPtr, A_Domain_CompDataEn) == CompData_OnLine)
            {
                saveCompDataEn = (COMPDATA_ENUM)GET_ENUM(domainPtr, A_Domain_CompDataEn);
                SET_ENUM(domainPtr, A_Domain_CompDataEn, CompData_NewNonPermanent);
            }
        }
        else
        {
		    /* Determine frequency informations (begin, end, crystallised dates) */
            DATE_StartTimer(&SV_GetPtfFreqInfoForSynthTimer, TIMER_MASK_ALL);
            ret = FIN_GetPtfFreqInfoForSynthAdmin(ptfTab[i], domainPtr, synthHierHead, &oldFreq, &oldFreqUnit, &freqSt, &retArg);
            DATE_StopTimer(&SV_GetPtfFreqInfoForSynthTimer, TIMER_MASK_ALL);
        }

		/*** COMPUTE SYNTHETICS ***/
		if (ret == RET_SUCCEED)
		{
		    /* Current portfolio */
		    SET_ID(domainPtr, A_Domain_PtfObjId, GET_ID(ptfTab[i], A_Ptf_Id));

			/* REF9125 - RAK - 030828 - use PSP information for PtfStorage */
			/* REF9836 - RAK - 040122 - Move update on the domain with PSP at the begin of the loop */
			if ((DICT_FCT_ENUM) GET_DICT(domainPtr, A_Domain_InitialFctDictId) != DictFct_PtfStorage)
			{
				/* Compute and load in ptf currency, with ptf detail level */
				SET_ENUM(domainPtr, A_Domain_RetDetLevelEn,
					GET_ENUM(ptfTab[i], A_Ptf_RetDetLevelEn));

				/* REF7395 - CSY - 020904: save original portfolio perf_detail_level
				because required in FIN_GridInfoGrid */
				SET_ENUM(domainPtr, A_Domain_PerfDetLevelEn,
					GET_ENUM(ptfTab[i], A_Ptf_PerfDetLevelEn));

				/* DVP535 - RAK - 970707 */
				/* REF2610 - RAK - 980814 - Synth data are always stored in ptf curr. */
				SET_ID(domainPtr, A_Domain_CurrId, GET_ID(ptfTab[i], A_Ptf_CurrId));

				SET_NULL_ID(domainPtr, A_Domain_GridId);

				/* RAK - 990217 - NO RISK (en plus ca marche mal ...) */
				/* SET_FLAG(domainPtr, A_Domain_RiskExpoFlg,
				GET_FLAG(ptfPtr, A_Ptf_RetRiskFlg)); */
			}

            /* REF5260 - RAK - 001114 */
            /* If portfolio A_Ptf_SynthLastFinalDate have change between  */
            /* DBA_SelPtfByDomain() and data loading, restart computation */
            /* with new portfolio information.                            */
            ret = RET_DBA_ERR_SYNTHRECALC;
            loop = 0;

            /* Stop the loop after 3 attempts (for security)  */
            /* or on RET_SUCCEED (or other error code) gived  */
            /* by FIN_SynthComputePtfSynth()                  */
            while (ret == RET_DBA_ERR_SYNTHRECALC && loop < 3)
            {
                if (ret == RET_DBA_ERR_SYNTHRECALC)
                {
                    /* after first loop, portfolio A_Ptf_SynthLastFinalDate  */
                    /* has changed, crystallized dates have to be recompute  */
                    if (loop != 0)
                    {
                        /* REF9125/8537 - YST - 030723 - not used anymore */
						/* REF7395 - YST - 020607 - call new function for ptf storage */

                        if ((DICT_FCT_ENUM)GET_DICT(domainPtr, A_Domain_InitialFctDictId) == DictFct_SynthAdmin)
                        {
                            MSG_LogSrvMesg(UNUSED, 0,
			                           "Synthetic Administration %1 of %2 : portfolio %3 synth_last_final_d modified, restarted ...",
			                           IntType, i+1, IntType, ptfNbr,
			                           CodeType, GET_CODE(ptfTab[i], A_Ptf_Cd));

                            /* Re-Determine frequency informations (begin, end, crystallised dates) */
		                    DATE_StartTimer(&SV_GetPtfFreqInfoForSynthTimer, TIMER_MASK_ALL);
                            ret = FIN_GetPtfFreqInfoForSynthAdmin(ptfTab[i], domainPtr, synthHierHead, /* PMSTA-50467 - JBC - 221112 */
                                                                  &oldFreq, &oldFreqUnit,
					                                              &freqSt, &retArg);
                            DATE_StopTimer(&SV_GetPtfFreqInfoForSynthTimer, TIMER_MASK_ALL);
                        }
                    }
                    else
                    {
                        /* on first loop, ret was initialised to RET_SUCCEED */
                        /* by first FIN_GetPtfFreqInfoForSynthAdmin() call.  */
                        ret = RET_SUCCEED;
                    }

                    if (ret == RET_SUCCEED)
                    {
                        /* REF9738 - RAK -040115 */
						/* License control for PtfStorage is done in insert function */
						/* DBA_InsSecondSynthDataPrep() and in FIN_CreateSecondSynth() */
						if (GET_DICT(domainPtr, A_Domain_InitialFctDictId) != (DICT_FCT_ENUM)DictFct_PtfStorage)
						{
							if (isPALicenseEn == (PA_LICENSEE_ENUM)PALicensee_No &&
								isRALicenseEn == (RA_LICENSEE_ENUM)RALicensee_No)
							{	/* REF7395 - CSY - 020809:
                                if licensee keys PA=0 and RA=0, force ret_detail_level to GLOBAL for the portfolio */
                                SET_ENUM(ptfTab[i], A_Ptf_RetDetLevelEn,
                                                    (PTFRETDETLVL_ENUM)PtfRetDetLvl_Global);
							}

                        }

                        ret = FIN_SynthComputePtfSynth(domainPtr, interpFromDate,
                                                        ptfTab[i], &freqSt, &retArg,
                                                        paInfoStp,  /* REF7395 - CSY - 020410 */
                                                        paInfoIdx,  /* REF7395 - YST - 020710 */
                                                        synthHierHead);

                        /* REF9770 - LJE - 040116 */
                        if(GET_DICT(domainPtr, A_Domain_InitialFctDictId) == (DICT_FCT_ENUM)DictFct_PtfStorage &&
                           saveCompDataEn == CompData_OnLine )
                        {
                            SET_ENUM(domainPtr, A_Domain_CompDataEn, saveCompDataEn);
                        }

                    }

                    ++loop;
                }
            }
        }

        /*PMSTA-48195 -PerfIPSLevel -Lalby-180722*/
        if (static_cast<LOADHIERPTF_ENUM> GET_ENUM(domainPtr, A_Domain_LoadHierFlg) == LoadHierPtf_IntermediateHierarchy)
        {
            /*cumulate the portsynth data with the parent , once done good to remove child ptfsynth
            if the positions are not exists for the child instrument position should be created in the
            parent segment
            */

            bool isIncludeCurrentLevel = true;   /* WEALTH-5157 - Lalby -11032024 */
            if (static_cast<PTFCONSRULE_ENUM> GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) == PtfConsRule_MergedTWR_Detail&&
            static_cast<LOADHIERPTF_ENUM>GET_ENUM(domainPtr, A_Domain_OrigLoadHierFlg) == LoadHierPtf_None &&
            GET_SMALLINT(ptfTab[i],A_Ptf_Level) > 0) /* Cumul only for the dummy Global Ptf */
            {
                 isIncludeCurrentLevel = false;
            }

            bool flagSynthCreated = false;

            if (isIncludeCurrentLevel && ((GET_ENUM(paInfoStp->paDateInfoTab[paInfoIdx].pspPtr,
                A_PerfStorageParam_PerfAttribReturnEn) == PerfAttribRtnEn_Hierarchy)) &&
                FIN_IsParentPtf(synthHierHead, domainPtr, ptfTab[i]) && /* WEALTH-9420 - lalby - 05072024 - Historical Group Perf*/
                paInfoStp->paDateInfoTab[paInfoIdx].headPspPtr != NULL)
            {
                FIN_CumulateChildSynth(synthHierHead, domainPtr,
                    ptfTab[i],
                    paInfoStp->paDateInfoTab[paInfoIdx], &flagSynthCreated);

                if (flagSynthCreated == true && ret != RET_MEM_ERR_ALLOC)
                {
                    /*if no position/portsynth found in parent and port synth created using child synth ,
                      these record should be processed for secondary synth */
                    ret = RET_SUCCEED;
                }
            }
        }

        bool isExcludeCurrentPtf = false; /*WEALTH -5157 -Lalby -08032024 */
        if (GET_ENUM(domainPtr, A_Domain_OrigLoadHierFlg) == LoadHierPtf_FromParent &&
            static_cast<PTFCONSRULE_ENUM> GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) == PtfConsRule_MergedTWR_Detail &&
            GET_SMALLINT(ptfTab[i], A_Ptf_Level) > 1)
        {
                isExcludeCurrentPtf = true;
        }
        /* Create secondary synthetics for portfolio storage */
        if (ret == RET_SUCCEED &&
			GET_DICT(domainPtr, A_Domain_InitialFctDictId) == (DICT_FCT_ENUM)DictFct_PtfStorage &&
            isExcludeCurrentPtf == false)
        {
			ret = FIN_CreateSecondSynthNew(domainPtr, synthHierHead, ptfTab[i], paInfoStp, paInfoIdx);
        }
        else if (ret == RET_SUCCEED && isExcludeCurrentPtf == false)
        {
            ret = FIN_CreateParentLinkSynthAndCheck(domainPtr, synthHierHead, ptfTab[i], paInfoStp, paInfoIdx);
        }

#if 0 /* WEALTH-8023 - DDV - 240702 - MktSeg adjust counter refactoring. 
		 This part is no more needed and function FIN_SetAdjustCounter has been removed */
        /* REF9743 - LJE - 040302 */
        /* adjustment */
        /* adjustment only in portfolio storage */
        if (ret == RET_SUCCEED && isExcludeCurrentPtf == false &&
            GET_DICT(domainPtr, A_Domain_InitialFctDictId) == (DICT_FCT_ENUM)DictFct_PtfStorage)
        {

            /* REF9743 - LJE - 040216 */
            if(paInfoStp != NULL                                    &&
               paInfoIdx < paInfoStp->paDateInfoNbr                 &&
               paInfoStp->paDateInfoTab[paInfoIdx].pspPtr != NULL   )
            {
				if (GET_FLAG(paInfoStp->paDateInfoTab[paInfoIdx].pspPtr, A_PerfStorageParam_InstrLevelFlg) == TRUE)
				{

                if((ret = FIN_SetAdjustCounter(domainPtr,
                                               synthHierHead,
                                               paInfoStp->paDateInfoTab[paInfoIdx].pspPtr,
                                               TRUE)) != RET_SUCCEED ||
                   (ret = FIN_SetAdjustCounter(domainPtr,
                                               synthHierHead,
                                               paInfoStp->paDateInfoTab[paInfoIdx].pspPtr,
                                               FALSE)) != RET_SUCCEED)
                {
                    return(ret);
                }
            }
        }
        }
#endif

        /* WEALTH-6363 - PtfAdjustCounter - Lalby - 17042022 */
        if ((GET_FLAG(domainPtr, A_Domain_LoadDimPtfHistFlg) == TRUE || GET_FLAG(domainPtr, A_Domain_LoadHierHistFlg) == TRUE))
        {
            FIN_SetAdjustCounterGroupHistCompo(domainPtr,
                                               synthHierHead,
                                               paInfoStp->paDateInfoTab[paInfoIdx]);
        }

        DATE_StartTimer(&SV_RetCompLoadMessTimer, TIMER_MASK_ALL);
		if (freqSt.crystDates != NULL || ret != RET_SUCCEED)
        {
			FLAG_T	printMsg=FALSE;
			if (GET_DICT(domainPtr, A_Domain_InitialFctDictId) == (DICT_FCT_ENUM)DictFct_PtfStorage)
			{
				/* last ptf or next ptf is different */
				if (paInfoIdx == loopNbr-1 ||
				    paInfoStp->paDateInfoTab[paInfoIdx+1].ptfId != paInfoStp->paDateInfoTab[paInfoIdx].ptfId)
				{
					printMsg = TRUE;
				}
			}
			else
				printMsg = TRUE;

            ptfRet = FIN_SynthAdminComputeMsg(ret, i+1, ptfNbr, ptfTab[i], &freqSt, dictFctInfo, printMsg);
        }
		else
		{
			ptfRet = RET_SUCCEED;
		}


        if (ptfRet != RET_SUCCEED)
            returnedRet = ptfRet;

        DATE_StopTimer(&SV_RetCompLoadMessTimer, TIMER_MASK_ALL);

		/*** INSERT IN DATABASE ***/
        /* REF5733 - RAK - 010307 - In case of RET_GEN_INFO_NODATA        */
        /* Go in FIN_InsPtfSynth() for delete of data and event-scheduler */
		if (ret == RET_SUCCEED || ret == RET_GEN_INFO_NODATA)
		{
            if(GET_DICT(domainPtr, A_Domain_InitialFctDictId) != (DICT_FCT_ENUM)DictFct_PtfStorage) /* REF7395 - CSY - 020315 */
            {
                insertRet = FIN_InsPtfSynth(synthHierHead, domainPtr, sPtfSynthPtr,
                                            ptfTab[i], &freqSt, &insPtfSynthSt, FALSE,
                                            ptfNbr, i);
                if (insertRet != RET_SUCCEED)
                    returnedRet = insertRet;
            }

            /* REF7421 - YST - 020808 - prepare insert secondary synthetics in database */
            if (GET_DICT(domainPtr, A_Domain_InitialFctDictId) == (DICT_FCT_ENUM)DictFct_PtfStorage &&
                (ret == RET_SUCCEED ||
                (ret == RET_GEN_INFO_NODATA &&
                 IS_NULLFLD(paInfoStp->paDateInfoTab[paInfoIdx].pspPtr, A_PerfStorageParam_StdPerfLastStoredDate) == FALSE)))
            {
				if (paInfoStp->mergedTWRFlg)
				{
					DICT_T entDictId;

					if (paInfoStp->mergedTWRObjStp != NULL)
					{
						OBJECT_ENUM objEn;

						DBA_GetObjectEnumByDynSt(GET_DYNSTENUM(paInfoStp->mergedTWRObjStp), &objEn);
						DBA_GetDictId(objEn, &entDictId);

						SET_DICT(paInfoStp->paDateInfoTab[paInfoIdx].pspPtr, A_PerfStorageParam_EntityDictId, entDictId);
						SET_ID(paInfoStp->paDateInfoTab[paInfoIdx].pspPtr, A_PerfStorageParam_ObjId,
							   GET_ID(paInfoStp->mergedTWRObjStp, 0));
					}
					else
					{
						DBA_GetDictId(QuickSearch, &entDictId);
						SET_DICT(paInfoStp->paDateInfoTab[paInfoIdx].pspPtr, A_PerfStorageParam_EntityDictId, entDictId);
						SET_NULL_ID(paInfoStp->paDateInfoTab[paInfoIdx].pspPtr, A_PerfStorageParam_ObjId);
					}
				}

				/* REF9836 - RAK - 040122 - Don't create performance synthetic for PSP created for SynthAdmin storage */
				/* call if synthAdminFlg is FALSE (OnLine, ...) or for PSP > 0 if synthAdminFlg is TRUE */
				insertRet = RET_SUCCEED;
 
                if ((static_cast<LOADHIERPTF_ENUM> GET_ENUM(domainPtr, A_Domain_LoadHierFlg) != LoadHierPtf_IntermediateHierarchy) ||
                    (GET_DICT(domainPtr, A_Domain_RpcFctDictId) == DictFct_PtfStorage && /*WEALTH-13657 - Lalby- 16092024 */
                     static_cast<LOADHIERPTF_ENUM> GET_ENUM(domainPtr, A_Domain_LoadHierFlg) == LoadHierPtf_IntermediateHierarchy &&
                     paInfoStp->paDateInfoTab[paInfoIdx].freqUnitEn == FreqUnit_Day && isExcludeCurrentPtf == false &&
                     paInfoStp->paDateInfoTab[paInfoIdx].pspId > 0)) /* ptf frequency check is ignored */
                {
                    if (paInfoStp->synthAdminFlg == FALSE ||
                        (paInfoStp->synthAdminFlg == TRUE && paInfoStp->paDateInfoTab[paInfoIdx].pspId > 0))
                    {
                        /* REF9125 - RAK - 030917 - get current PsP in paInfoStp and send it to function */
                        insertRet = FIN_InsertPaAndExtRaData(domainPtr, synthHierHead, synthHierHead, ptfTab[i],  /* PMSTA08736 - LJE - 100412 */
                            paInfoStp->paDateInfoTab[paInfoIdx].pspPtr,
                            paInfoStp->paDateInfoTab[paInfoIdx].delFromDate,
                            paInfoStp->paDateInfoTab[paInfoIdx].delTillDate,
                            paInfoStp->paDateInfoTab[paInfoIdx].eventSchedFlg,
                            FALSE, &insPaExtRaSt, &(paInfoStp->paDateInfoTab[paInfoIdx]));
                    }
                }
                else /*LoadHierPtf_IntermediateHierarchy*/
                {
                      /*For performance analysis - online check , process if pspId < 0 also
                      For storage pspId > 0 and the below case is for monthly storage -consider ptf frequency monthly twr/global twr */
                    if (isExcludeCurrentPtf == false && ((IS_NULLFLD(domainPtr, A_Domain_RpcFctDictId) == FALSE &&  
						GET_DICT(domainPtr, A_Domain_RpcFctDictId) == DictFct_PerformanceAnalysis && paInfoStp->synthAdminFlg == FALSE) ||
						(paInfoStp->paDateInfoTab[paInfoIdx].pspId > 0 && 
                        paInfoStp->paDateInfoTab[paInfoIdx].freqUnitEn == paInfoStp->paDateInfoTab[paInfoIdx].ptFfreqUnitEn))) 
                    {
                        /* REF9125 - RAK - 030917 - get current PsP in paInfoStp and send it to function */
                        insertRet = FIN_InsertPaAndExtRaData(domainPtr, synthHierHead, synthHierHead, ptfTab[i],  /* PMSTA08736 - LJE - 100412 */
                            paInfoStp->paDateInfoTab[paInfoIdx].pspPtr,
                            paInfoStp->paDateInfoTab[paInfoIdx].delFromDate,
                            paInfoStp->paDateInfoTab[paInfoIdx].delTillDate,
                            paInfoStp->paDateInfoTab[paInfoIdx].eventSchedFlg,
                            FALSE, &insPaExtRaSt, &(paInfoStp->paDateInfoTab[paInfoIdx]));
                    }
                }
                /* REF9836 - RAK - 040122 - Insert synthetic for PSP created for SynthAdmin storage only */
                if(paInfoStp->synthAdminFlg == TRUE &&
				   paInfoStp->paDateInfoTab[paInfoIdx].pspId < 0)
                {
					/* REF9836 - RAK - 040126 - set PSPId for parallel storage */
                    freqSt.parallelStorPSPId = paInfoStp->paDateInfoTab[paInfoIdx].pspId;

                    insPtfSynthSt.delSynthFlg = FALSE;          /* purify: no free of synthetic portfolios in hierarchy */
	                freqSt.periodNbr = 0;                       /* must be 0, because only one period must be deleted */
                    freqSt.eventSchedFlg = paInfoStp->paDateInfoTab[paInfoIdx].eventSchedFlg; /* copy eventSchedFlg */

                    /* if data has to be deleted, set deleteFlg and delete from and till date */
                    if (DATETIME_CMP(paInfoStp->paDateInfoTab[paInfoIdx].delFromDate, nullDateTime) > 0 &&
	                    DATETIME_CMP(paInfoStp->paDateInfoTab[paInfoIdx].delTillDate, nullDateTime) > 0 &&
                        DATETIME_CMP(paInfoStp->paDateInfoTab[paInfoIdx].delFromDate,
                                     paInfoStp->paDateInfoTab[paInfoIdx].delTillDate) < 0)
                    {
                        freqSt.deleteFlg = TRUE;
                        SET_DATETIME(sPtfSynthPtr, S_PtfSynth_InitialDate, paInfoStp->paDateInfoTab[paInfoIdx].delFromDate);
	                    SET_DATETIME(sPtfSynthPtr, S_PtfSynth_FinalDate, paInfoStp->paDateInfoTab[paInfoIdx].delTillDate);
                    }

                    insertRet = FIN_InsPtfSynth(synthHierHead, domainPtr, sPtfSynthPtr, ptfTab[i],
                                                &freqSt, &insPtfSynthSt, FALSE, ptfNbr, i);
                }

				/* REF9836 - RAK - 040126 */
				if (insertRet != RET_SUCCEED)
					returnedRet = insertRet;
            }
		}

		/* REF9737 - RAK - 040107 */
		/* If we won't display the result, suppress A_PtfSynth so the next portfolios treatment */
		/* won't be slow donw because of too much synthetics are in hier */
		/* only for PtfStorage because of A_PtfSynth of the hier are stored */
		/* in insPtfSynthSt and used in the last FIN_InsPtfSynth() just below */
		if (GET_DICT(domainPtr, A_Domain_InitialFctDictId) == (DICT_FCT_ENUM)DictFct_PtfStorage &&
		    GET_FLAG(domainPtr, A_Domain_DispResultFlg) == FALSE &&
            paInfoStp->synthAdminFlg == FALSE && /* REF9836 - LJE - 040305 */
            (EV_KeepPtfSynthInPA == 0 || EV_KeepPtfSynthInPA == 2)) /* PMSTA-51425 - DDV - 230126 */
		{
            /*PMSTA-48195 -PerfIPSLevel -Lalby-180722*/
            if (static_cast<LOADHIERPTF_ENUM> GET_ENUM(domainPtr, A_Domain_LoadHierFlg) == LoadHierPtf_IntermediateHierarchy)
            {
                if (paInfoStp->paDateInfoTab[paInfoIdx].headPspPtr != NULL)
                {
                    /*remove the data marked for good to remove in ptfsynth - port synth of child ,cumulated */
                    DBA_DelAndFreeHierEltRecWithFilter(synthHierHead,
                        A_PtfSynth,
                        FIN_FilterAddedInParentFlg,
                        NULLDYNST, NULL);
                }
                /*Remove current portfolio synth - not in hierarchical consideration*/
                else
                {
                    DBA_DelAndFreeHierEltRecWithFilter(synthHierHead,
                        A_PtfSynth,
                        FIN_FilterPortSynthWithPspId,
                        paInfoStp->paDateInfoTab[paInfoIdx].pspPtr, NULL);
                }

                if(EV_TracePerf) 
                {
                   DBA_DYNFLD_STP *tempTab = NULL;
                   int tempNbr = 0;
                   ret = DBA_ExtractHierEltRecWithFilterSt(synthHierHead, A_PtfSynth, FALSE,
                         NULL, NULL, NULL,
                         &tempNbr, &tempTab);

                   MSG_LogSrvMesg(UNUSED, 0,
                    "Number of synth Record in Hierarchy  - %1",
                    IntType, tempNbr);
                }
            }
            else
			DBA_FreeHierEltRecord(synthHierHead, A_PtfSynth);
		}

		/* PMSTA08391 - LJE - 090827 */
		if (paInfoStp != NULL)
		{
			FREE(paInfoStp->synthInstrTab);
			paInfoStp->synthInstrNbr = 0;
		}

	}

    /* REF5392 - RAK - 001121 */
    if(GET_DICT(domainPtr, A_Domain_InitialFctDictId) != (DICT_FCT_ENUM)DictFct_PtfStorage)   /* REF7395 - CSY - 020315 */
    {
        insertRet = FIN_InsPtfSynth(synthHierHead, domainPtr,
                                    NULLDYNST, NULLDYNST, NULL,
                                    &insPtfSynthSt,
                                    TRUE,             /* Just force insert */
                                    ptfNbr, -1);
        if (insertRet != RET_SUCCEED)
            returnedRet = insertRet;
    }

    /* REF7421 - YST - 020808 - force insert secondary synthetics in database */
    if(GET_DICT(domainPtr, A_Domain_InitialFctDictId) == (DICT_FCT_ENUM)DictFct_PtfStorage)
    {
		/* REF9836 - RAK - 040122 - Call always this function because it will just insert the prepared perfData */
		/* which aren't already inserted (the transformation on synthetic in perfData is only done during the loop) */
        insertRet = FIN_InsertPaAndExtRaData(domainPtr, synthHierHead, synthHierHead, NULLDYNST, NULL, /* PMSTA08736 - LJE - 100412 */
                                             nullDateTime, nullDateTime, FALSE, TRUE, &insPaExtRaSt, nullptr);

        if (insertRet != RET_SUCCEED)
            returnedRet = insertRet;
        
        /* REF7395 - YST - 020822 - parallel storage: store synthetics with level PS */
		/* REF9836 - RAK - 040122 - Call this function because it will just insert the prepared synthData */
        if(paInfoStp->synthAdminFlg == TRUE)
        {
			/* REF9836 - RAK - 040126 */
			/* Why don't insert Synth if PerfData aren't stored */
			/* (now we have fictitious PSP for SynthAdmin storage) */
            /*if (returnedRet == RET_SUCCEED) */
            insertRet = FIN_InsPtfSynth(synthHierHead, domainPtr, NULLDYNST, NULLDYNST, NULL,
                                        &insPtfSynthSt, TRUE, ptfNbr, -1);

			if (insertRet != RET_SUCCEED)
				returnedRet = insertRet;
        }
		SCPT_FreeScriptDV(NullEntity); /* PMSTA06772 - 080619 - DDV */
    }
   

    /* REF9688 - RAK - 031119 */

	if ((DICT_FCT_ENUM)GET_DICT(domainPtr, A_Domain_InitialFctDictId) == DictFct_PtfStorage)
	{
		if (loopNbr > 0)
		{
			while (i<ptfNbr)
			{
				if (paInfoStp->paDateInfoTab[paInfoIdx-1].ptfId != GET_ID(ptfTab[i], A_Ptf_Id))
				{
					FIN_MsgNoPSPforPtf(synthHierHead, domainPtr, dictFctInfo, i, ptfNbr, ptfTab[i]);
				}
				i++;
			}
		}
		if (loopNbr == 0 && ptfNbr == 1)
		{
			i=0;
			FIN_MsgNoPSPforPtf(synthHierHead, domainPtr, dictFctInfo, i, ptfNbr, ptfTab[i]);
		}
	}

	if (freqSt.periodNbr > 0)
	{
        /* REF9954 - DDV - 040310 - If same adresse for both array, free it only one time */
	    if (freqSt.periodCrystDates == freqSt.crystDates)
        {
            freqSt.periodCrystDates = NULL;
        }
        else
        {
    	    FREE(freqSt.periodCrystDates);
        }

	    FREE(freqSt.period);	    /* REFX - RAK - memory leak */
	    FREE(freqSt.crystDates);    /* REFX - RAK - memory leak */
	}
	else
	{ FREE(freqSt.crystDates); }

    if (GET_DICT(domainPtr, A_Domain_InitialFctDictId) == (DICT_FCT_ENUM)DictFct_PtfStorage &&
        GET_FLAG(domainPtr, A_Domain_DispResultFlg) == FALSE &&
        paInfoStp->synthAdminFlg == FALSE && 
		EV_KeepPtfSynthInPA != 1 && EV_KeepPtfSynthInPA != 3)
    {
        DBA_FreeHierEltRecord(synthHierHead, A_PtfSynth);
    }

	/* REF3694 - Update parameter SYNTHETIC_MAX_FINAL_DATE */
    /* REF5260 - RAK - 001114 - Update in fct DBA_InsPtfSynth(), for each    */
    /* portfolio, fields A_Ptf_SynthLastFinalDate and A_Ptf_SynthRecalcDate. */

	return(returnedRet);  /* REF4489 - SSO - 000315 */
}

/* REF9357 - RAK - 040205 - We saw "No PSP" and we don't understand because we found one or several in DB */
STATIC void FIN_MsgNoPSPforPtf(DBA_HIER_HEAD_STP synthHierHead,
							   DBA_DYNFLD_STP    domainPtr, /* PMSTA08286 - LJE - 090605 */
							   DICT_FCT_STP		 dictFctInfo,
							   int				 i,
							   int				 ptfNbr,
							   DBA_DYNFLD_STP	 ptfPtr)
{
	RET_CODE	ret;
	int			pspNbr=0;

	/* If there isn't PSP in paInfoStp->paDateInfoTab for ptf */
	/* but we have loaded PSP for ptf that's because PSP isn't (aren't) valid */
	ret = DBA_HierGetRecNbrWithFilterSt(synthHierHead, A_PerfStorageParam,
										FIN_FilterPtfPSP, ptfPtr, &pspNbr, FALSE);

	if (ret == RET_SUCCEED && pspNbr > 0)
	{
		/* PMSTA08286 - LJE - 090605 */
		if (CMP_DYNFLD(domainPtr, domainPtr, A_Domain_InterpFromDate, A_Domain_InterpTillDate, DatetimeType) == 0)
		{
			MSG_LogSrvMesg(UNUSED, 0, "%1 %2 of %3: all PSP of the portfolio %4 are up to date",
				   NameType, dictFctInfo->name, IntType, i+1, IntType, ptfNbr,
				   CodeType, GET_CODE(ptfPtr, A_Ptf_Cd));
		}
		else
		{
		MSG_LogSrvMesg(UNUSED, 0, "%1 %2 of %3: no valid PSP for portfolio %4",
			   NameType, dictFctInfo->name, IntType, i+1, IntType, ptfNbr,
			   CodeType, GET_CODE(ptfPtr, A_Ptf_Cd));
	}
	}
	else
	{
		MSG_LogSrvMesg(UNUSED, 0, "%1 %2 of %3: no PSP for portfolio %4",
			   NameType, dictFctInfo->name, IntType, i+1, IntType, ptfNbr,
			   CodeType, GET_CODE(ptfPtr, A_Ptf_Cd));
	}
}

/************************************************************************
**
**  Function    :   FIN_InsPtfSynth()
**
**  Description :   Insert portfolio synthetics
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED, RET_FIN_ERR_COMP_SYNTH_FAIL or error code
**
**  Creation    :   REF5392 - RAK - 001122
**
*************************************************************************/
STATIC RET_CODE FIN_InsPtfSynth(DBA_HIER_HEAD_STP   synthHierHead,
                                DBA_DYNFLD_STP      domainPtr,
                                DBA_DYNFLD_STP      sPtfSynthPtr,
                                DBA_DYNFLD_STP      ptfPtr,
                                FIN_RET_FREQ_STP    freqStp,
                                DBA_INSPTFSYNTH_STP insPtfSynthStp,
                                FLAG_T              forceInsertFlg,
                                int                 ptfNbr,
                                int                 ptfIdx)
{
    RET_CODE    ret=RET_SUCCEED, returnedRet=RET_SUCCEED;

    DATE_StartTimer(&SV_DbaInsPtfSynthTimer, TIMER_MASK_ALL);

    if (forceInsertFlg == FALSE)    /* sPtfSynthPtr and ptfPtr are NULL */
    {
        /* Update flag for insertion function */
	    /* TRUE : only one portfolio synthetics at each insertion */
	    /* FALSE : treated ptf synth are keeped in hier -> filter before */
	    if (ptfNbr == 1)
	    	insPtfSynthStp->onlyOnePtfFlg = TRUE;
	    else
	    {
		    if (ptfIdx == 0)		/* There is only first ptf synthetics */
			    insPtfSynthStp->onlyOnePtfFlg = TRUE;
		    else
		    {
                /* Keep treated ptf synthetics only in case of display */
                /* REF5392 - RAK - 001121 */
                /* keep synthetics because of insertion block by block */
                /* so 1 ptf at the begin of each block */
                /* if (GET_FLAG(domainPtr, A_Domain_DispResultFlg) == FALSE) */
                if (insPtfSynthStp->accessNbr == 0 &&
                    GET_FLAG(domainPtr, A_Domain_DispResultFlg) == FALSE)
				    insPtfSynthStp->onlyOnePtfFlg = TRUE;
			    else
				    insPtfSynthStp->onlyOnePtfFlg = FALSE;
		    }
	    }

	    SET_ID(sPtfSynthPtr, S_PtfSynth_PtfId, GET_ID(ptfPtr, A_Ptf_Id));
        insPtfSynthStp->crtPtf = ptfIdx+1;
    }

	ret = DBA_InsPtfSynth(domainPtr,			/* REF9836 - RAK - 040126 */
						  (PTR) synthHierHead, sPtfSynthPtr,
					      ptfPtr,              /* REF3903 - RAK - 000419 */
					      (PTR) freqStp,
                          insPtfSynthStp,      /* REF5392 - RAK - 001121 */
                          forceInsertFlg);

	if (ret != RET_SUCCEED &&	      /* REF4489 - SSO - 000315 */
		ret != RET_GEN_INFO_NODATA)	  /* REF4489 - SSO - 000412 */
	{
		returnedRet = RET_FIN_ERR_COMP_SYNTH_FAIL;
	}

	/* Keep treated ptf synthetics only in case of display */
    /* REF5392 - RAK - 001121 */
    /* if (GET_FLAG(domainPtr, A_Domain_DispResultFlg) == FALSE)
		DBA_FreeHierEltRecord(synthHierHead, A_PtfSynth);
    */
    DATE_StopTimer(&SV_DbaInsPtfSynthTimer, TIMER_MASK_ALL);

    return(returnedRet);
}

/************************************************************************
**
**  Function    :   FIN_SynthAdminComputeMsg()
**
**  Description :   Print message according to portfolio synthetics computation status
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED, RET_FIN_ERR_COMP_SYNTH_FAIL or error code
**
**  Creation    :   REF5392 - RAK - 001121
**  Modification:   REF7935 - YST - 020827 - add argument and new message
**
*************************************************************************/
STATIC RET_CODE FIN_SynthAdminComputeMsg(RET_CODE          ret,
                                         int               crtPtf,
                                         int               ptfNbr,
                                         DBA_DYNFLD_STP    ptfPtr,
                                         FIN_RET_FREQ_STP  freqStp,
                                         DICT_FCT_STP	   dictFctInfo,
										 FLAG_T			   printMsg)
{
    DATETIME_T  msgFromDate, msgTillDate;
    RET_CODE    returnedRet=RET_SUCCEED;

    msgFromDate.date = 0;
    msgFromDate.time = 0;
    msgTillDate.date = 0;
    msgTillDate.time = 0;

	if(ret == RET_SUCCEED && freqStp->periodNbr == 0 && freqStp->crystDatesNbr == 0)
	{
	    ret = RET_GEN_INFO_NODATA;
	}

	if (ret == RET_SUCCEED)
	{
		if (freqStp->periodNbr > 0)
		{
		    msgFromDate = freqStp->periodCrystDates[0];
		    msgTillDate = freqStp->periodCrystDates[(freqStp->periodCrystDatesNbr)-1];
		}
		else
		{
		    msgFromDate = freqStp->crystDates[0];
		    msgTillDate = freqStp->crystDates[(freqStp->crystDatesNbr)-1];
		}

		if (printMsg == TRUE)
		{
			MSG_LogSrvMesg(UNUSED, 0,
			    "%1 %2 of %3: portfolio %4 (from %5 till %6) synthetics computation successfully terminated",
				NameType, dictFctInfo->name, IntType, crtPtf, IntType, ptfNbr,
				CodeType, GET_CODE(ptfPtr, A_Ptf_Cd),
				DatetimeType, msgFromDate,
				DatetimeType, msgTillDate);
		}
	}
	else if (ret == RET_GEN_ERR_INVALIDATE)
	{
		if (printMsg == TRUE)
		{
			MSG_LogSrvMesg(UNUSED, 0,
			   "%1 %2 of %3: synthetics computation portfolio %4 terminated",
			   NameType, dictFctInfo->name, IntType, crtPtf, IntType, ptfNbr,
			   CodeType, GET_CODE(ptfPtr, A_Ptf_Cd));
		}
	}
	else if (ret == RET_GEN_INFO_NODATA)
	{
		if (printMsg == TRUE)
		{
			MSG_LogSrvMesg(UNUSED, 0,
			   "%1 %2 of %3: synthetics computation portfolio %4 terminated (no data)",
			   NameType, dictFctInfo->name, IntType, crtPtf, IntType, ptfNbr,
			   CodeType, GET_CODE(ptfPtr, A_Ptf_Cd));
		}
	}
    /* REF5245 - RAK - 001221 */
    else if (ret == RET_FIN_ERR_FUSLOCK)
    {
		if (printMsg == TRUE)
		{
			MSG_LogSrvMesg(UNUSED, 0,
	           "%1 %2 of %3: synthetics computation portfolio %4 terminated (not fusioned)",
	           NameType, dictFctInfo->name, IntType, crtPtf, IntType, ptfNbr,
	           CodeType, GET_CODE(ptfPtr, A_Ptf_Cd));
		}
    }
    /* REF7395 - YST - 020822 */
    else if (ret == RET_FIN_INFO_NOPARALSTOR)
    {
		if (printMsg == TRUE)
		{
			MSG_LogSrvMesg(UNUSED, 0,
	           "Portfolio Storage %1 of %2 : synthetics computation for portfolio %3 terminated (no data for parallel storage)",
	           IntType, crtPtf, IntType, ptfNbr,
	           CodeType, GET_CODE(ptfPtr, A_Ptf_Cd));
		}
        returnedRet = RET_SUCCEED;
    }
	else
	{
		if (printMsg == TRUE)
		{
			MSG_LogSrvMesg(UNUSED, 0,
			   "%1 %2 of %3: synthetics computation for portfolio %4 terminated on error (see log file)",
			   NameType, dictFctInfo->name, IntType, crtPtf, IntType, ptfNbr,
			   CodeType, GET_CODE(ptfPtr, A_Ptf_Cd));
		}
		returnedRet = RET_FIN_ERR_COMP_SYNTH_FAIL; /* REF4489 - SSO - 000315 */
	}

    return(returnedRet);
}

/************************************************************************
**
**  Function    :   FIN_SynthComputePtfSynth()
**
**  Description :   Compute and load portfolio and PPS portfolio(s) synthetics
**
**  Arguments   :   domainPtr       domain structure pointer
**                  interFromDate   fromDate
**                  ptfPtr          portfolio structure pointer
**                  freqStp
**                  retArgStp
**                  synthHierHead   synthetic hierarchy pointer
**
**  Return      :   RET_SUCCEED, RET_DBA_ERR_SYNTHRECALC or error code
**
**  Creation    :   REF5260 - RAK - 001114
**  Modif       :   REF7395 - CSY - 020410 new argument for perf attrib: paDateInfoStp
**                  REF7395 - YST - 020710
**                  REF8106 - CSY - 021022: 4.0 beta:  don't take PPS into account in portfolio storage
**
**
*************************************************************************/
STATIC RET_CODE FIN_SynthComputePtfSynth(DBA_DYNFLD_STP     domainPtr,
                                          DATETIME_T        interpFromDate,
                                          DBA_DYNFLD_STP    ptfPtr,
                                          FIN_RET_FREQ_STP  freqStp,
                                          RETURN_ARG_STP    retArgStp,
                                          PA_INFO_STP       paInfoStp,  /* REF7395 - CSY - 020410 */
                                          int               paInfoIdx,  /* REF7395 - YST - 020710 */
                                          DBA_HIER_HEAD_STP synthHierHead)
{
    RET_CODE ret=RET_SUCCEED;

	/* REF1402 - RAK - 990205 - Because of PPS treatment */
    DATE_StartTimer(&SV_ReturnComputePtfSynthPeriodTimer, TIMER_MASK_ALL);
	ret = FIN_SynthComputePtfSynthPeriod(domainPtr, ptfPtr, freqStp, retArgStp,
                                            paInfoStp,  /* REF5885 - CSY - 010330 */
                                            paInfoIdx,  /* REF8566/REF7395 - YST - 021204 */
							             synthHierHead);
    DATE_StopTimer(&SV_ReturnComputePtfSynthPeriodTimer, TIMER_MASK_ALL);

    /* REF1402 - RAK - 990205 - New PPS treatment */
    if (ret == RET_SUCCEED && GET_FLAG(ptfPtr, A_Ptf_PortSetFlg) == TRUE
                                &&
        /* REF8106 - CSY - 021022: to avoid duplicate key during insertion of standard_perf_data,
        we don't take PPS into account in portfolio storage (TA 4.0 beta) -
        REF8566/REF7495 - YST - 021204 - if PPS treatment is enabled for Ptf Storage then check if paInfoStp and paInfoIdx are ok */
        GET_DICT(domainPtr, A_Domain_InitialFctDictId) != DictFct_PtfStorage)
	{
        DATE_StartTimer(&SV_ReturnComputePPSPtfSynthTimer, TIMER_MASK_ALL);
	    ret = FIN_SynthComputePPSPtfSynth(domainPtr, interpFromDate, ptfPtr,
							                   freqStp, retArgStp,
                                               paInfoStp,   /* REF7395 - CSY - 020410 */
                                               paInfoIdx,   /* REF7395 - YST - 020710 */
                                               synthHierHead);
        DATE_StopTimer(&SV_ReturnComputePPSPtfSynthTimer, TIMER_MASK_ALL);
	}

    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_SynthComputePPSPtfSynth()
**
**  Description :   Compute and load PPS portfolio(s) synthetics
**
**                  Attention:
**                  Function FIN_SynthComputePPSPtfSynth() (=PPS fct) is currently not called for ptf storage.
**                  But we added paInfoStp and paInfoIdx as arguments and used it also as arguments for
**                  other functions called in PPS fct.
**                  If one day PPS fct is called for ptf storage
**                  test if paInfoStp and paInfoIdx are used in the right sense.
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED, RET_DBA_ERR_SYNTHRECALC or error code
**
**  Creation    :   REF1402 - RAK - 980917
**  Modif       :   REF7395 - CSY - 020410: new argument paDateInfoStp for perf attrib
**              :   REF7395 - YST - 020710
**              :   REF8566/REF7395 - YST - 021204 - add paInfoIdx
**
*************************************************************************/
STATIC RET_CODE FIN_SynthComputePPSPtfSynth(DBA_DYNFLD_STP      domainPtr,
					                         DATETIME_T	        interpFromDate,
					                         DBA_DYNFLD_STP     ptfPtr,
					                         FIN_RET_FREQ_STP   freqStp,
					                         RETURN_ARG_STP     retArgStp,
                                             PA_INFO_STP        paInfoStp,  /* REF7395 - CSY - 020410 */
                                             int                paInfoIdx,  /* REF7395 - YST - 020710 */
					                         DBA_HIER_HEAD_STP  synthHierHead)
{
	DBA_DYNFLD_STP 	*PPSTab=NULLDYNSTPTR, admArgPtr=NULLDYNST;
	int 		    PPSNbr=0, j;
	char		    newPPSFreqFlg=FALSE, ptfNoDataFlg=FALSE;
	DBA_DYNFLD_STP	firstPtfSynth=NULLDYNST;
	DATETIME_T	    ptfFromDate;
	FIN_RET_FREQ_ST  newPPSFreqSt;
	FIN_RET_FREQ_STP PPSFreqStp;
	SMALLINT_T	    oldFreq=-1;
	FREQUNIT_ENUM	oldFreqUnit=FreqUnit_None;
	COMPDATA_ENUM 	svCompDataEn=(COMPDATA_ENUM) GET_ENUM(domainPtr, A_Domain_CompDataEn);
	DATETIME_T	    svFromDate=GET_DATETIME(domainPtr, A_Domain_InterpFromDate);
    FLAG_T          PPSAddInHierFlg=FALSE;
	RET_CODE	    ret, retFirst;

	memset(&ptfFromDate, 0, sizeof(DATETIME_T));
	memset(&newPPSFreqSt, 0, sizeof(FIN_RET_FREQ_ST));

	if ((admArgPtr = ALLOC_DYNST(Adm_Arg)) == NULLDYNST)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

	SET_ID(admArgPtr, Adm_Arg_Id, GET_ID(ptfPtr, A_Ptf_Id));

	ret = DBA_Select2(PtfPosSet, UNUSED, Adm_Arg, admArgPtr,
			          A_PtfPosSet, &PPSTab, UNUSED, UNUSED,
			          &PPSNbr, UNUSED, UNUSED);

    /* REF4307 - RAK - 000126 - Add in hierarchy so Get2() will be saved. */
    if (ret == RET_SUCCEED)
    {
        if (DBA_AddHierRecordList(synthHierHead, PPSTab, PPSNbr,
	       	                      A_PtfPosSet, TRUE) == RET_SUCCEED)
            PPSAddInHierFlg = TRUE;
    }

	for (j=0; j<PPSNbr && ret==RET_SUCCEED; j++)
	{
	    if (GET_FLAG(PPSTab[j], A_PtfPosSet_PtfSynthFlg) == TRUE)
	    {
		    /* Get first synthetic date for portfolio */
		    if (firstPtfSynth == NULLDYNST)
		    {
	    		if ((firstPtfSynth = ALLOC_DYNST(S_PtfSynth)) == NULLDYNST)
			    {
				    /* REF4307 */
                    if (PPSAddInHierFlg == FALSE)
                    { DBA_FreeDynStTab(PPSTab, PPSNbr, A_PtfPosSet); }
                    else
                    { FREE(PPSTab); }
				    FREE_DYNST(admArgPtr, Adm_Arg);
				    MSG_RETURN(RET_MEM_ERR_ALLOC);
			    }

			    SET_ID(firstPtfSynth,       S_PtfSynth_PtfId, GET_ID(ptfPtr, A_Ptf_Id));
			    SET_DATETIME(firstPtfSynth, S_PtfSynth_InitialDate, interpFromDate);

			    retFirst = DBA_Get2(PtfSynth, UNUSED, S_PtfSynth, firstPtfSynth,
			                        S_PtfSynth, &firstPtfSynth, UNUSED, UNUSED, UNUSED);

			    if (retFirst == RET_SUCCEED)
			    {
				    ptfFromDate = GET_DATETIME(firstPtfSynth, S_PtfSynth_InitialDate);
			    }
			    else if (retFirst == RET_DBA_INFO_NODATA)
			    {
				    ptfNoDataFlg = TRUE;
			    }
		    }

		    /* In case of a new PPS (without synthetic data), create all synthetic data. */
		    if (ptfFromDate.date != 0 || ptfNoDataFlg == TRUE)
		    {
		        if (ptfFromDate.date != 0)
		        {
		            SET_NULL_DYNST(firstPtfSynth, S_PtfSynth);

		            SET_ID(firstPtfSynth,       S_PtfSynth_PtfId, GET_ID(ptfPtr, A_Ptf_Id));
		            SET_DATETIME(firstPtfSynth, S_PtfSynth_InitialDate, interpFromDate);
		            SET_ID(firstPtfSynth, S_PtfSynth_PtfPosSetId,
			        GET_ID(PPSTab[j], A_PtfPosSet_Id));

		            retFirst = DBA_Get2(PtfSynth, UNUSED, S_PtfSynth, firstPtfSynth,
			                            S_PtfSynth, &firstPtfSynth, UNUSED, UNUSED, UNUSED);

		            /* If no synthetic for current pps, get all crystalisation dates */
		            /* and compute synthetic from the first ptf crystalisation date. */
		            if (retFirst == RET_DBA_INFO_NODATA)
		            {
			            /* Do that only one time (all PPS have same dates than portfolio) */
			            if (newPPSFreqFlg == FALSE)
			            {
			                if (svCompDataEn == CompData_NewPermanent)
			                { SET_ENUM(domainPtr, A_Domain_CompDataEn,
						                            (ENUM_T) CompData_ReplacePermanent); }
			                else if (svCompDataEn == CompData_NewNonPermanent)
			                { SET_ENUM(domainPtr, A_Domain_CompDataEn,
						                            (ENUM_T) CompData_ReplaceNonPermanent); }

			                SET_DATETIME(domainPtr, A_Domain_InterpFromDate, ptfFromDate);

                            /* REF9125/REF8537 - YST - 030723 - don't use FIN_GetPaInfoForPtfStorage anymore */
							/* REF7395 - YST - 020607 - call new function for ptf storage *
                            if(GET_DICT(domainPtr, A_Domain_InitialFctDictId) == (DICT_FCT_ENUM)DictFct_PtfStorage)
                            {
                                * Determine necessary informations (begin, end, benchmark dates) *
                                DATE_StartTimer(&SV_GetPtfFreqInfoForPtfStoreTimer, TIMER_MASK_ALL);
                                ret = FIN_GetPaInfoForPtfStorage(domainPtr, ptfPtr, synthHierHead, paInfoStp, paInfoIdx);
                                DATE_StopTimer(&SV_GetPtfFreqInfoForPtfStoreTimer, TIMER_MASK_ALL);
                            }
                            else
                            {*/
                            DATE_StartTimer(&SV_GetPtfFreqInfoForSynthTimer, TIMER_MASK_ALL);
			                ret = FIN_GetPtfFreqInfoForSynthAdmin(ptfPtr, domainPtr, synthHierHead, &oldFreq, &oldFreqUnit,
					                                 &newPPSFreqSt, retArgStp);
                            DATE_StopTimer(&SV_GetPtfFreqInfoForSynthTimer, TIMER_MASK_ALL);

			                newPPSFreqFlg = TRUE;
		                }

			            PPSFreqStp = &newPPSFreqSt;
		            }
		            else
		            {
			            PPSFreqStp = freqStp;
		            }
		        }
		        else
			        PPSFreqStp = freqStp;

		        if (ret == RET_SUCCEED)
		        {
		            /* Update domain with PPS values */
		            SET_ID(domainPtr, A_Domain_CurrId,       GET_ID(PPSTab[j], A_PtfPosSet_CurrId));
		            SET_ID(domainPtr, A_Domain_ConsPtfId,    GET_ID(PPSTab[j], A_PtfPosSet_ConsPtfId));
		            SET_ID(domainPtr, A_Domain_PortPosSetId, GET_ID(PPSTab[j], A_PtfPosSet_TpId));
		            SET_ENUM(domainPtr, A_Domain_PpsLoadEn,  (ENUM_T) Domain_PpsLoadEn_LoadPps);

                    DATE_StartTimer(&SV_ReturnComputePtfSynthPeriodTimer, TIMER_MASK_ALL);
		            ret = FIN_SynthComputePtfSynthPeriod(domainPtr, ptfPtr, PPSFreqStp,
						                                  retArgStp,
                                                          paInfoStp,    /* REF7395 - CSY - 020410 */
                                                          paInfoIdx,    /* /REF8566/REF7395 - YST - 021204 */
                                                          synthHierHead);
                    DATE_StopTimer(&SV_ReturnComputePtfSynthPeriodTimer, TIMER_MASK_ALL);

		            SET_ENUM(domainPtr,     A_Domain_CompDataEn,     (ENUM_T)svCompDataEn);
		            SET_DATETIME(domainPtr, A_Domain_InterpFromDate, svFromDate);
		        }
	        }
	    }
	}

	if (PPSNbr> 0)
	{
		SET_ENUM(domainPtr, A_Domain_PpsLoadEn, (ENUM_T) Domain_PpsLoadEn_NoPps);
		SET_ID(domainPtr,   A_Domain_CurrId,    GET_ID(ptfPtr, A_Ptf_CurrId));
		SET_NULL_ID(domainPtr, A_Domain_PortPosSetId);
		SET_NULL_ID(domainPtr, A_Domain_ConsPtfId);
	}

	if (firstPtfSynth != NULLDYNST)
	{ FREE_DYNST(firstPtfSynth, S_PtfSynth); }

	/* REF4307 */
    if (PPSAddInHierFlg == FALSE)
    { DBA_FreeDynStTab(PPSTab, PPSNbr, A_PtfPosSet); }
    else
    { FREE(PPSTab); }

	FREE_DYNST(admArgPtr, Adm_Arg);

	if (newPPSFreqSt.periodNbr > 0)
	{ FREE(newPPSFreqSt.periodCrystDates); }
	else
	{ FREE(newPPSFreqSt.crystDates); }

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_SynthComputePtfSynthPeriod()
**
**  Description :   Compute portfolio(s) synthetics (with or without PPS)
**		    according to freqStp informations.
**
**  Arguments   :   domainPtr     domain structure pointer
**                  synthHierHead synthetics hierarchy pointer
**
**  Return      :   RET_SUCCEED, RET_DBA_ERR_SYNTHRECALC or error code
**
**  Creation    :   REF1402 - RAK - 990201
**  Modif           REF5885 - CSY - 010330: globalPosNbr
**  Modif       :   REF7395 - CSY - 020410 new argument paDateInfoStp for perf attrib
**  Modif       :   REF8566/REF7395 - YST - 021204
**
*************************************************************************/
STATIC RET_CODE FIN_SynthComputePtfSynthPeriod(DBA_DYNFLD_STP       domainPtr,
                                                DBA_DYNFLD_STP      ptfPtr,
					                            FIN_RET_FREQ_STP    freqStp,
					                            RETURN_ARG_STP	    retArgStp,
                                                PA_INFO_STP         paInfoStp,  /* REF7395 - CSY - 020410 */
                                                int                 paInfoIdx,  /* REF8566/REF7395 - YST - 021204 */
				                                DBA_HIER_HEAD_STP   synthHierHead)
{
	RET_CODE	ret;
    int         globalPosNbr = 0;   /* REF5885 - CSY - 010330 */

	/* REF1402 - Could have several different periods */
	if (freqStp->periodNbr > 0)
	{
		int 		j, begIdx;
		DATETIME_T	*saveCrystDates;
		int		saveCrystDatesNbr;
		char		saveEndPeriodFlg;

		saveCrystDates    = freqStp->crystDates;
		saveCrystDatesNbr = freqStp->crystDatesNbr;
		saveEndPeriodFlg  = freqStp->endPeriodFlg;

		for (j=0, ret=RET_SUCCEED; j<freqStp->periodNbr && ret==RET_SUCCEED; j++)
		{
			begIdx = freqStp->period[j].beg;
			freqStp->crystDates   = &(freqStp->periodCrystDates[begIdx]);
			freqStp->crystDatesNbr = freqStp->period[j].end - freqStp->period[j].beg;

			/* This flag is valid only for the last period */
			if (j+1 == freqStp->periodNbr &&
			    saveCrystDates[saveCrystDatesNbr-1].date ==
			    freqStp->crystDates[(freqStp->crystDatesNbr)-1].date)
				freqStp->endPeriodFlg = saveEndPeriodFlg;
			else
				freqStp->endPeriodFlg = TRUE;

            /* REF5260 - RAK - 001114 - Suppress fct FIN_ReturnComputePtfSynth() */
            /* ret = FIN_ReturnComputePtfSynth(domainPtr, ptfPtr, freqStp, retArgStp,
                                               synthHierHead);
            */

            /* Current dates */
            DATE_StartTimer(&SV_ReturnComputePtfSynthTimer, TIMER_MASK_ALL);
	        SET_DATETIME(domainPtr, A_Domain_InterpFromDate, freqStp->crystDates[0]);
	        SET_DATETIME(domainPtr, A_Domain_InterpTillDate,
				                    freqStp->crystDates[(freqStp->crystDatesNbr)-1]);

	        /*** COMPUTE SYNTHETICS ***/
	        /* REF1402 - Update function dict_id ->                */
	        /*           do position load (and not synthetic load) */
	        SET_DICT(domainPtr, A_Domain_FctDictId, (DICT_T) DictFct_Return);

            ret = FIN_ComputePtfSynth(domainPtr, ptfPtr, synthHierHead,
			                          freqStp, (RETURN_GRID_INFO_STP)NULL, retArgStp,
                                      &globalPosNbr,			/* REF5885 - CSY - 010330 */
                                      paInfoStp, paInfoIdx		/* REF7395 - CSY - 020410 */
                                      );
            DATE_StopTimer(&SV_ReturnComputePtfSynthTimer, TIMER_MASK_ALL);
		}

		freqStp->crystDates    = saveCrystDates;
		freqStp->crystDatesNbr = saveCrystDatesNbr;
		freqStp->endPeriodFlg  = saveEndPeriodFlg;
	}
	else
	{
        /* REF5260 - RAK - 001114 - Suppress fct FIN_ReturnComputePtfSynth() */
		/* ret = FIN_ReturnComputePtfSynth(domainPtr, ptfPtr, freqStp, retArgStp,
                                                synthHierHead);
        */

        /* Current dates */
        DATE_StartTimer(&SV_ReturnComputePtfSynthTimer, TIMER_MASK_ALL);

        if(freqStp->crystDates != NULL) /* REF7395 - CSY - 020531 */
        {
	        SET_DATETIME(domainPtr, A_Domain_InterpFromDate, freqStp->crystDates[0]);
	        SET_DATETIME(domainPtr, A_Domain_InterpTillDate, freqStp->crystDates[(freqStp->crystDatesNbr)-1]);
        }
        else if (paInfoStp != NULL)     /* REF8566/REF7395 - YST - 021204 */
        {
            SET_DATETIME(domainPtr, A_Domain_InterpFromDate,
                        paInfoStp->paDateInfoTab[paInfoIdx].paDates[0].dateTime);
	        SET_DATETIME(domainPtr, A_Domain_InterpTillDate,
				        paInfoStp->paDateInfoTab[paInfoIdx].paDates[(paInfoStp->paDateInfoTab[paInfoIdx].paDatesNbr)-1].dateTime);
            retArgStp->domFromDate = GET_DATETIME(domainPtr, A_Domain_InterpFromDate); /* REF9055 - YST - 030508 */
        }

	    /*** COMPUTE SYNTHETICS ***/
	    /* REF1402 - Update function dict_id ->                */
	    /*           do position load (and not synthetic load) */
	    SET_DICT(domainPtr, A_Domain_FctDictId, (DICT_T) DictFct_Return);

        ret = FIN_ComputePtfSynth(domainPtr, ptfPtr, synthHierHead,
			                      freqStp, (RETURN_GRID_INFO_STP)NULL, retArgStp,
                                  &globalPosNbr,			/* REF5885 - CSY - 010330 */
                                  paInfoStp, paInfoIdx);	/* REF5885 - CSY - 010330 */
        DATE_StopTimer(&SV_ReturnComputePtfSynthTimer, TIMER_MASK_ALL);
	}

    /* REF5885 - CSY - 010330 */
    if (globalPosNbr == 0)
        return(RET_GEN_INFO_NODATA);


	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_ReturnDelPtfSynth()
**
**  Description :   Delete portfolio(s) synthetics
**
**  Arguments   :   domainPtr     domain structure pointer
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   DVP261 - RAK - 961205
**  Modification:   REF3542 - AKO - 990416 : purify -> free memory no more used
**  Modif.      :   REF5392 - RAK - 001228 - Delete with MultiAccess and upd ptf by dynamic sql
**
*************************************************************************/
STATIC RET_CODE FIN_ReturnDelPtfSynth(DBA_DYNFLD_STP domainPtr)
{
	RET_CODE 	        ret;
	DBA_DYNFLD_STP	    *ptfTab=NULLDYNSTPTR;
	int		            i, blockSz=100, lastBlockIdx, ptfNbr=0;

    /* REF3637 - RAK - 000308 - Manage load hierarchy flag ! */
    /* REF5245 - RAK - 001114 */
    /* new function DBA_SelPtfByDomain() return A_Ptf table */
    /* if ((ret = DBA_SelectPtfIdByDomain(domainPtr, &ioIdTab, &ioIdNbr)) == RET_SUCCEED) */
    DATE_StartTimer(&SV_ReturnSelPtfByDomainTimer, TIMER_MASK_ALL);
    if ((ret = DBA_SelPtfByDomain(domainPtr, &ptfTab, &ptfNbr, NULL)) == RET_SUCCEED)
	{
        DATE_StopTimer(&SV_ReturnSelPtfByDomainTimer, TIMER_MASK_ALL);

	    for (i=0; i<ptfNbr; i+=blockSz)
	    {
            /* min(ptfNbr, i+blockSz) */
            if (ptfNbr < i+blockSz)
		        lastBlockIdx = ptfNbr-1;
            else
                lastBlockIdx = i+blockSz-1;

            /* REF5392 - RAK - 001228 */
            ret = DBA_DelPtfSynth(GET_DATETIME(domainPtr, A_Domain_InterpFromDate),
                                  GET_DATETIME(domainPtr, A_Domain_InterpTillDate),
                                  ptfTab, i, lastBlockIdx, ptfNbr);

            if (ret == RET_DBA_INFO_NODATA)
                ret = RET_SUCCEED;
	    }

	    DBA_FreeDynStTab(ptfTab, ptfNbr, A_Ptf);
	}
    DATE_StopTimer(&SV_ReturnSelPtfByDomainTimer, TIMER_MASK_ALL);

	return(ret);
}

RET_CODE FIN_ReturnDelPtfSynthOld(DBA_DYNFLD_STP domainPtr)
{
	RET_CODE 	        ret;
	DBA_DYNFLD_STP	    *ptfTab=NULLDYNSTPTR, sPtfSynthPtr=NULLDYNST;
	int		            i, ptfNbr=0;

	if ((sPtfSynthPtr = ALLOC_DYNST(S_PtfSynth)) == NULLDYNST)
	{ MSG_RETURN(RET_MEM_ERR_ALLOC); }

	SET_DATETIME(sPtfSynthPtr, S_PtfSynth_InitialDate,
	    GET_DATETIME(domainPtr, A_Domain_InterpFromDate));

	SET_DATETIME(sPtfSynthPtr, S_PtfSynth_FinalDate,
	    GET_DATETIME(domainPtr, A_Domain_InterpTillDate));

    /* REF3637 - RAK - 000308 - Manage load hierarchy flag ! */
    /* REF5245 - RAK - 001114 */
    /* new function DBA_SelPtfByDomain() return A_Ptf table */
    /* if ((ret = DBA_SelectPtfIdByDomain(domainPtr, &ioIdTab, &ioIdNbr)) == RET_SUCCEED) */
    DATE_StartTimer(&SV_ReturnSelPtfByDomainTimer, TIMER_MASK_ALL);
    if ((ret = DBA_SelPtfByDomain(domainPtr, &ptfTab, &ptfNbr, NULL)) == RET_SUCCEED)
	{
        DATE_StopTimer(&SV_ReturnSelPtfByDomainTimer, TIMER_MASK_ALL);
	    for (i=0; i<ptfNbr; i++)
	    {
		    SET_ID(sPtfSynthPtr, S_PtfSynth_PtfId, GET_ID(ptfTab[i], A_Ptf_Id));

            /* ret = DBA_DelPtfSynth(sPtfSynthPtr, ptfTab[i]); */

            if (ret == RET_DBA_INFO_NODATA)
                ret = RET_SUCCEED;

            /* REF5245 - RAK - 001114 - Add message */
            if (ret == RET_SUCCEED)
            {
                MSG_LogSrvMesg(UNUSED, 0,
		                       "Synthetic Administration %1 of %2 : portfolio %3 deleted",
		                       IntType, i+1, IntType, ptfNbr,
		                       CodeType, GET_CODE(ptfTab[i], A_Ptf_Cd));
            }
            else
            {
                MSG_LogSrvMesg(UNUSED, 0,
		                       "Synthetic Administration %1 of %2 : portfolio %3 not deleted (see log file)",
		                       IntType, i+1, IntType, ptfNbr,
		                       CodeType, GET_CODE(ptfTab[i], A_Ptf_Cd));
            }
	    }

	    DBA_FreeDynStTab(ptfTab, ptfNbr, A_Ptf);
	}
    DATE_StopTimer(&SV_ReturnSelPtfByDomainTimer, TIMER_MASK_ALL);

	FREE_DYNST(sPtfSynthPtr, S_PtfSynth);	/* REF3542 - AKO - 990416 */
	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_ReturnVerifPtfSynth()
**
**  Description :   Verify loaded synthetics depend on ptf frequency,
**		    and compute missing data
**
**  Arguments   :   domainPtr     domain structure pointer
**                  synthHierHead synthetic hierarchy pointer
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   DVP261 - RAK - 961121
**  Modif    	:   DVP261 - RAK - 961212
**  Modif    	:   BUG234 - RAK - 961219
**  Modif    	:   DVP535 - RAK - 970707
**  Modif    	:   REF2728 - RAK - 980917
**		    REF2832 - SSO - 980925
**          REF5582 - CSY - 010216 call FIN_GetCommonFreq for merged lists only
**          REF5582 - CSY - 010308: delete tests on PtfConsRuleMerge
**          REF5885 - CSY - 010330: globalPosNbr
**          REF6912 - CSY - 010809  global lines P&L counters
**          REF8354 - YST - 021107/021206  synth admin - comp history
**          REF9834 - TEB - 040617 : Rem : on n'utilise plus cette fonction
**                  avec CompData_CompHistory. Mais je laisse le vieux code pour l'instant.
**
*************************************************************************/
STATIC RET_CODE FIN_ReturnVerifPtfSynth(DBA_DYNFLD_STP     domainPtr,
			                            DBA_HIER_HEAD_STP  synthHierHead)
{
	DBA_DYNFLD_STP	    *ptfTab=NULLDYNSTPTR, *synthTab=NULLDYNSTPTR, missDomainPtr=NULLDYNST;
	int		            ptfNbr, synthNbr, i, j, begin, ptfSynthNbr;
	char		        diffFreq = FALSE;
	SMALLINT_T	        oldFreq;
	DICT_T		        ptfDict;
	FREQUNIT_ENUM 	    oldFreqUnit;
	PTFRETDETLVL_ENUM   domRetDetLevelEn = (PTFRETDETLVL_ENUM) GET_ENUM(domainPtr, A_Domain_RetDetLevelEn);
    /*PTFRETDETLVL_ENUM   perfDetLevelEn=PtfRetDetLvl_Instrument;*/ /* REF7395 - YST - 021007 */
	FIN_RET_FREQ_ST	    ptfFreqSt, commFreqSt, crtPtfFreqSt;
	RETURN_GRID_INFO_ST gridInfoSt;
	RET_CODE 	        ret, retSynth;
	RETURN_ARG_ST	    retArg;	/* REF2728 */
    SMALLINT_T          savFreqPtf = 0;    /* REF5582 - CSY - 010216 */
    FREQUNIT_ENUM       savFreqUnitPtf = FreqUnit_None; /* REF5582 - CSY - 010216 */ /* REF7264 - LJE - 020131 */
    FLAG_T              notUsedFlg = FALSE, /* REF7244 - YST - 020430 - argument added to function call, not used here */
                        synthAdminCompHistFlg = FALSE;  /* REF8354 - YST - 021107/021206 */
    /* REF6912 - CSY - 010809 */
    DATETIME_T  crtDateTime, fromDate, tillDate, savDomFromDate, savDomTillDate, nullDateTime;

	DICT_FCT_STP	    dictFctInfo; /* REF10964 - CHU - 050531 */
    MemoryPool          mp;	
	DBA_GetDictFctInfo((DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId), DictFctInfo_Stp, &dictFctInfo);

    crtDateTime.date = 0;
    crtDateTime.time = 0;

	memset(&retArg, 0, sizeof(RETURN_ARG_ST));
	retArg.domFromDate = GET_DATETIME(domainPtr, A_Domain_InterpFromDate);
	GEN_GetApplInfo(ApplReversalMethode, &retArg.reversalMethode);          /* REF4198 - 991208 - DED */

    /* REF8354 - YST - 021107/021206 - flag is TRUE only for Synth admin - compute history */
    if(GET_DICT(domainPtr, A_Domain_InitialFctDictId) == (DICT_FCT_ENUM)DictFct_SynthAdmin &&
       GET_ENUM(domainPtr, A_Domain_CompDataEn) == (COMPDATA_ENUM)CompData_CompHistory)
        synthAdminCompHistFlg = TRUE;

	memset(&gridInfoSt, 0, sizeof(RETURN_GRID_INFO_ST));
	/* BUG234 */
	memset(&ptfFreqSt, 0, sizeof(FIN_RET_FREQ_ST));
	memset(&commFreqSt, 0, sizeof(FIN_RET_FREQ_ST));
    /* REF8354 - YST - 021107 */
    memset(&fromDate, 0, sizeof(DATETIME_T));
    memset(&tillDate, 0, sizeof(DATETIME_T));
    memset(&nullDateTime, 0, sizeof(DATETIME_T));
    savDomFromDate = GET_DATETIME(domainPtr, A_Domain_InterpFromDate);
    savDomTillDate = GET_DATETIME(domainPtr, A_Domain_InterpTillDate);

	DBA_GetDictId(Ptf, &ptfDict);

	if ((ret = DBA_ExtractHierEltRec(synthHierHead, A_Ptf, FALSE, NULLFCT,
			                         FIN_CmpReturnPtf, &ptfNbr, &ptfTab)) != RET_SUCCEED)
    {
        FREE(ptfTab);
        return(ret);
    }

	if (ptfNbr == 0)
	{
        FREE(ptfTab);
	    ptfTab = NULLDYNSTPTR;

        /* REF5245 - RAK - 001114 */
		/* ret = DBA_SelectPtfIdByDomain(domainPtr, &ioIdTab, &ioIdNbr); */
        /* new function DBA_SelPtfByDomain() return A_Ptf table */
        DBA_SetTascJobPtfDim(domainPtr,NULL); /* OCS-49362 - TEB - 170508 */

        DATE_StartTimer(&SV_ReturnSelPtfByDomainTimer, TIMER_MASK_ALL);
        ret = DBA_SelPtfByDomain(domainPtr, &ptfTab, &ptfNbr, synthHierHead);
        DATE_StopTimer(&SV_ReturnSelPtfByDomainTimer, TIMER_MASK_ALL);

        DBA_RestorePtfDim(domainPtr);

	    if (ret != RET_SUCCEED || ptfNbr == 0)
	    {
	      	return(ret);
	    }

		/* In case of Compute History don't add ptf in hier, they are already */
		ret = DBA_AddHierRecordList(synthHierHead, ptfTab, ptfNbr, A_Ptf, TRUE);

	    FREE(ptfTab);
        ptfNbr = 0;

		/* REF10388 - RAK - 050406 - Update hierarchy links */
		if ((ret = DBA_SetHierLnkUsed(synthHierHead, A_Ptf,
									  A_Ptf_HierPtf_Ext)) != RET_SUCCEED)
		{
			return(ret);
		}

		if ((ret = DBA_SetHierLnkUsed(synthHierHead, A_Ptf,
			                          A_Ptf_ChildrenPtf_Ext)) != RET_SUCCEED)
		{
			return(ret);
		}

		if ((ret = DBA_MakeAllRecLinks(synthHierHead, A_Ptf)) != RET_SUCCEED)
		{
			return(ret);
		}

	    if ((ret = DBA_ExtractHierEltRec(synthHierHead, A_Ptf, FALSE, NULLFCT,
			                             FIN_CmpReturnPtf, &ptfNbr, &ptfTab)) != RET_SUCCEED)
	    {
		    return(ret);
	    }
	}

	/* PMSTA02013 - RAK - 071112 */
	FIN_RemoveChildrenPtf(synthHierHead, domainPtr, &ptfTab, &ptfNbr);
    mp.ownerPtr(ptfTab);

		/*** ----------------------------------------------------- ***/
	/*** Read loaded data (synthetics and portfolio(s))        ***/
	/*** ----------------------------------------------------- ***/
	synthNbr = 0;
	if (synthHierHead != (DBA_HIER_HEAD_STP)NULL)
	{
	    if ((ret = DBA_ExtractHierEltRec(synthHierHead, A_PtfSynth,
					     FALSE, NULLFCT, FIN_CmpPtfSynthPtfDate,
					     &synthNbr, &synthTab)) != RET_SUCCEED)
        {
            FREE(synthTab);
            return(ret);
        }
        mp.ownerPtr(synthTab);
	}
	else
	    return(RET_DBA_ERR_HIER);
    /* REF8354 - YST - 021107 - don't use synthetics valid before PerfLastFinalDate for computation */
    if(synthAdminCompHistFlg == TRUE)
    {
		/* REF9834 - RAK - 040219 - New treatment for compute history */
		FLAG_T	verifFlg = TRUE;	/* we want to verify if one (or several in case of ReturnGridLnk) */
									/* of the PSP could be used to store synthetics as perf data */


		/* REF9834 - RAK - 040219 - New treatment for compute history */
		/* Choose good PSP (or create one) for each ptf */
		/* modification of FIN_CreatePSPForSynthAdmin() which is now FIN_VerifCreatePSPForSynthAdmin() */
		/* so in case of parrallel storage we will be able to use existant PSP instead to create fictitious one (best performance) */
		for (i=0; i<ptfNbr; i++)
		{
			if ((ret = FIN_VerifCreatePSPForSynthAdmin(domainPtr, ptfTab[i], verifFlg, synthHierHead, (PA_INFO_STP)NULL)) != RET_SUCCEED) /* REF9834 - TEB - 041202 */
			{
				return(ret);
			}
		}
    }
    /* REF8354 - YST - 021206 - don't get grid id here but in function FIN_ReturnProcess() */
    else
    {
        /*** --------------------------------- ***/
	    /*** Get grid informations from domain ***/
	    /*** (dimension ptf, third, list)      ***/
	    /*** --------------------------------- ***/
        /* REF7395 - YST - 021007/021015 - add new arguments (not used in this call) */
	    if ((ret = FIN_GridInfoGrid(&gridInfoSt,
                                    (RETURN_GRID_INFO_STP)NULL, &notUsedFlg, PtfRetDetLvl_Global, /* REF7395 - YST - 021007/021015 */
                                    domainPtr)) != RET_SUCCEED)
	    {
	        return(ret);
	    }
    }

    if (ptfNbr > 1 /* &&GET_ENUM(domainPtr,A_Domain_PtfConsRuleEn)==PtfConsRule_Merged */)  /* REF5582 - CSY - 010215 */
    {
        FIN_GetCommonFreq(ptfTab, ptfNbr, &(commFreqSt.freq),
						  &(commFreqSt.freqUnit), &diffFreq);   /* REF5582 - CSY - 010215 */
    }

	if (synthNbr == 0)
	{
	    /*** --------------------------------------------------------- ***/
	    /*** No received synthetics (comput each portfolio synthetics) ***/
	    /*** --------------------------------------------------------- ***/
	    for (i=0, oldFreq=-1, oldFreqUnit=FreqUnit_None; i<ptfNbr; i++)
	    {
	        /* Get current portfolio frequency and crystallised dates */
	        /* ------------------------------------------------------ */
			DATE_StartTimer(&SV_GetPtfFreqInfoForReturnTimer, TIMER_MASK_ALL);

			if (ptfNbr > 1 /* &&GET_ENUM(domainPtr,A_Domain_PtfConsRuleEn)==PtfConsRule_Merged */)  /* REF5582 - CSY - 010215 */
			{
				savFreqPtf = (TINYINT_T) GET_SMALLINT(ptfTab[i], A_Ptf_RetFreq);
				savFreqUnitPtf =  (FREQUNIT_ENUM)GET_ENUM(ptfTab[i], A_Ptf_RetFreqUnitEn); /* REF7264 - LJE - 020131 */
				SET_SMALLINT(ptfTab[i], A_Ptf_RetFreq, commFreqSt.freq);
				SET_ENUM(ptfTab[i], A_Ptf_RetFreqUnitEn, commFreqSt.freqUnit);
			}

			/* REF8354 - YST - 021107/021206 - compute from and till date for each portfolio like for ptf storage */
			retSynth = RET_SUCCEED;
			if (synthAdminCompHistFlg == TRUE)
			{
                if ((retSynth = FIN_GetPeriodPerfAttrib(domainPtr, nullptr, ptfTab[i], Ptf, NULL, &fromDate, &tillDate, &nullDateTime, &nullDateTime, /* PMSTA-26435 - LJE - 170316 */
														&notUsedFlg, &notUsedFlg, NULL)) == RET_SUCCEED)
				{
					retArg.domFromDate = fromDate;
					SET_DATETIME(domainPtr, A_Domain_InterpFromDate, fromDate);
					SET_DATETIME(domainPtr, A_Domain_InterpTillDate, tillDate);
					SET_ENUM(domainPtr, A_Domain_RetDetLevelEn, GET_ENUM(ptfTab[i], A_Ptf_RetDetLevelEn));
				}
				else
				{
					retArg.domFromDate = savDomFromDate;
					SET_DATETIME(domainPtr, A_Domain_InterpFromDate, savDomFromDate);
					SET_DATETIME(domainPtr, A_Domain_InterpTillDate, savDomTillDate);
					SET_ENUM(domainPtr, A_Domain_RetDetLevelEn, domRetDetLevelEn);
				}
			}

			/* REF8354 - For compute history, if FIN_GetPeriodPerfAttrib isn't succeed, don't do computation */
			if (retSynth == RET_SUCCEED)
			{
				if ((ret = FIN_GetPtfFreqInfoForReturn(ptfTab[i], domainPtr, synthHierHead, &oldFreq, &oldFreqUnit,
													   &ptfFreqSt, (RETURN_ARG_STP)NULL)) != RET_SUCCEED)
				{
					if (ptfNbr > 1 /* && GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn)== PtfConsRule_Merged */)  /* REF5582 - CSY - 010215 */
					{
						SET_SMALLINT(ptfTab[i], A_Ptf_RetFreq, savFreqPtf);
						SET_ENUM(ptfTab[i], A_Ptf_RetFreqUnitEn, savFreqUnitPtf);
					}

                    mp.freeDynStp(missDomainPtr);
                    missDomainPtr = NULLDYNST;

					FREE_GRIDINFO(gridInfoSt);
					DATE_StopTimer(&SV_GetPtfFreqInfoForReturnTimer, TIMER_MASK_ALL);
					return(ret);
				}
				DATE_StopTimer(&SV_GetPtfFreqInfoForReturnTimer, TIMER_MASK_ALL);

				if (ptfNbr > 1)
				{
					SET_SMALLINT(ptfTab[i], A_Ptf_RetFreq, savFreqPtf);
					SET_ENUM(ptfTab[i], A_Ptf_RetFreqUnitEn, savFreqUnitPtf);
				}

				if (missDomainPtr == NULLDYNST)
				{
                     missDomainPtr = mp.allocDynst(FILEINFO,A_Domain);

					COPY_DYNST(missDomainPtr, domainPtr, A_Domain);

					SET_DICT(missDomainPtr, A_Domain_FctDictId,    (DICT_T) DictFct_Return);
					SET_DICT(missDomainPtr, A_Domain_DimPtfDictId, ptfDict);
				}

				SET_ID(missDomainPtr, A_Domain_PtfObjId, GET_ID(ptfTab[i], A_Ptf_Id));
				/* REF2832 - SSO - 980925: restore the initial from date (modified in FIN_ReturnProcess) */
				SET_DATETIME(missDomainPtr, A_Domain_InterpFromDate, retArg.domFromDate);

				/* REF8354 - YST - 021107/021206 - compute from and till date for each portfolio like for ptf storage */
				if(synthAdminCompHistFlg == TRUE)
				{
					SET_DATETIME(missDomainPtr, A_Domain_InterpFromDate, fromDate);
					SET_DATETIME(missDomainPtr, A_Domain_InterpTillDate, tillDate);
					SET_ENUM(domainPtr, A_Domain_RetDetLevelEn, GET_ENUM(ptfTab[i], A_Ptf_RetDetLevelEn));
				}


				DATE_StartTimer(&SV_ComputePtfSynthTimer, TIMER_MASK_ALL);
	    	    ret = FIN_ComputePtfSynth(missDomainPtr, ptfTab[i], synthHierHead,
										  &ptfFreqSt, &gridInfoSt, &retArg,
										  NULL,			/* REF5885 - CSY - 010330: globalPosNbr  */
										  NULL, 0);		/* REF5885 - CSY - 010330 */
                DATE_StopTimer(&SV_ComputePtfSynthTimer, TIMER_MASK_ALL);

				/* REF10964 - CHU - 050531 : log msg when Synth data computed */
				FIN_SynthAdminComputeMsg(ret, i+1, ptfNbr, ptfTab[i], &ptfFreqSt, dictFctInfo, TRUE);
            }
        }

        /* REF9725 - LJE - 041209 -> Verify selected synthetics : compute missing */
        if(GET_DICT(domainPtr, A_Domain_InitialFctDictId) == (DICT_FCT_ENUM)DictFct_Return)
        {
            if ((ret = DBA_ExtractHierEltRec(synthHierHead, A_PtfSynth,
					     FALSE, NULLFCT, FIN_CmpPtfSynthPtfDate,
					     &synthNbr, &synthTab)) != RET_SUCCEED)
           {
                FREE(synthTab);
                return(ret);
            }
            mp.ownerPtr(synthTab);
        }

	}

    /* REF9725 - LJE - 041209 */
	if (synthNbr > 0)
	{
        /* REF11269 - LJE - 051221 : Memory leek */
        mp.freeDynStp(missDomainPtr);
        missDomainPtr = NULLDYNST;

	    /*** ----------------------------------------------------- ***/
	    /*** Verify received synthetics (each portfolio frequency) ***/
	    /*** ----------------------------------------------------- ***/
	    for (i=0, j=0, oldFreq=-1, oldFreqUnit=FreqUnit_None, missDomainPtr=NULLDYNST;
		     i<ptfNbr && j<synthNbr; i++)
	    {
	        /* Get current portfolio frequency and crystallised dates */
	        /* ------------------------------------------------------ */
            if (ptfNbr > 1 /* && GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn)
                == PtfConsRule_Merged */)  /* REF5582 - CSY - 010215 */
            {
                savFreqPtf = (TINYINT_T) GET_SMALLINT(ptfTab[i], A_Ptf_RetFreq);
                savFreqUnitPtf =  (FREQUNIT_ENUM)GET_ENUM(ptfTab[i], A_Ptf_RetFreqUnitEn); /* REF7264 - LJE - 020131 */
                SET_SMALLINT(ptfTab[i], A_Ptf_RetFreq, commFreqSt.freq);
	            SET_ENUM(ptfTab[i], A_Ptf_RetFreqUnitEn, commFreqSt.freqUnit);
            }

            /* REF8354 - YST - 021107/021206 - compute from and till date for each portfolio like for ptf storage */
            retSynth = RET_SUCCEED;
            if(synthAdminCompHistFlg == TRUE)
            {
                if ((retSynth = FIN_GetPeriodPerfAttrib(domainPtr, nullptr, ptfTab[i], Ptf, NULL, &fromDate, &tillDate, &nullDateTime, &nullDateTime, /* PMSTA-26435 - LJE - 170316 */
                                                        &notUsedFlg, &notUsedFlg, NULL)) == RET_SUCCEED)
                {
                    retArg.domFromDate = fromDate;
                    SET_DATETIME(domainPtr, A_Domain_InterpFromDate, fromDate);
                    SET_DATETIME(domainPtr, A_Domain_InterpTillDate, tillDate);
                    SET_ENUM(domainPtr, A_Domain_RetDetLevelEn, GET_ENUM(ptfTab[i], A_Ptf_RetDetLevelEn));
                }
                else
                {
                    retArg.domFromDate = savDomFromDate;
                    SET_DATETIME(domainPtr, A_Domain_InterpFromDate, savDomFromDate);
                    SET_DATETIME(domainPtr, A_Domain_InterpTillDate, savDomTillDate);
                    SET_ENUM(domainPtr, A_Domain_RetDetLevelEn, domRetDetLevelEn);
                }
            }

			/* REF8354 - For compute history, if FIN_GetPeriodPerfAttrib isn't succeed, don't do computation */
            if (retSynth == RET_SUCCEED)
            {
				DATE_StartTimer(&SV_GetPtfFreqInfoForReturnTimer, TIMER_MASK_ALL);
				if ((ret = FIN_GetPtfFreqInfoForReturn(ptfTab[i], domainPtr, synthHierHead, &oldFreq, &oldFreqUnit,
								                       &ptfFreqSt, (RETURN_ARG_STP)NULL)) != RET_SUCCEED)
				{
					if (ptfNbr > 1 /* && GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn)
						== PtfConsRule_Merged */)  /* REF5582 - CSY - 010215 */
					{
						SET_SMALLINT(ptfTab[i], A_Ptf_RetFreq, savFreqPtf);
						SET_ENUM(ptfTab[i], A_Ptf_RetFreqUnitEn, savFreqUnitPtf);
					}

                    mp.freeDynStp(missDomainPtr);
                    missDomainPtr = NULLDYNST;
					FREE_GRIDINFO(gridInfoSt);
					DATE_StopTimer(&SV_GetPtfFreqInfoForReturnTimer, TIMER_MASK_ALL);
					return(ret);
				}
				DATE_StopTimer(&SV_GetPtfFreqInfoForReturnTimer, TIMER_MASK_ALL);

				if (ptfNbr > 1 /*&&GET_ENUM(domainPtr,A_Domain_PtfConsRuleEn)== PtfConsRule_Merged*/)  /* REF5582 - CSY - 010215 */
				{
					SET_SMALLINT(ptfTab[i], A_Ptf_RetFreq, savFreqPtf);
					SET_ENUM(ptfTab[i], A_Ptf_RetFreqUnitEn, savFreqUnitPtf);
				}

				/* Select current portfolio's synthetics */
				/* ------------------------------------- */
				ptfSynthNbr = 0;
				begin = -1;

				/* j is on first position of next portfolio (0 at first time) */
				while (j<synthNbr && GET_ID(synthTab[j], A_PtfSynth_PtfId) <= GET_ID(ptfTab[i], A_Ptf_Id))
				{
					if (GET_ID(synthTab[j], A_PtfSynth_PtfId) == GET_ID(ptfTab[i], A_Ptf_Id))
					{
						if (begin == -1)
						begin = j;
						ptfSynthNbr++;
					}
					j++;
				}

				/* Verify current portfolio's synthetics */
				/* ------------------------------------- */
				if (begin == -1 || ptfSynthNbr == 0)
				{
					/* No data for portfolio : compute all */
					if (missDomainPtr == NULLDYNST)
					{
                        missDomainPtr = mp.allocDynst(FILEINFO,A_Domain);

						COPY_DYNST(missDomainPtr, domainPtr, A_Domain);
						SET_DICT(missDomainPtr, A_Domain_FctDictId,    (DICT_T) DictFct_Return);
						SET_DICT(missDomainPtr, A_Domain_DimPtfDictId, ptfDict);
					}

					SET_ID(missDomainPtr, A_Domain_PtfObjId, GET_ID(ptfTab[i], A_Ptf_Id));
					/* REF2832 - SSO - 980925: restore the initial from date (modified in FIN_ReturnProcess) */
					SET_DATETIME(missDomainPtr, A_Domain_InterpFromDate, retArg.domFromDate);

					/* REF8354 - YST - 021107/021206 - compute from and till date for each portfolio like for ptf storage */
					if(synthAdminCompHistFlg == TRUE)
					{
						SET_DATETIME(missDomainPtr, A_Domain_InterpFromDate, fromDate);
						SET_DATETIME(missDomainPtr, A_Domain_InterpTillDate, tillDate);
						SET_ENUM(domainPtr, A_Domain_RetDetLevelEn, GET_ENUM(ptfTab[i], A_Ptf_RetDetLevelEn));
					}

					DATE_StartTimer(&SV_ComputePtfSynthTimer, TIMER_MASK_ALL);

					/* PMSTA00521 - RAK - 060926 */
					/* Create a new ptfFreqSt (because crystDates are updated */
					/* in FIN_ComputePtfSynth for TWR methods) */

					/* COPY record information ... but realloc the two pointer crystDates and periodCrystDates */
					memcpy(&crtPtfFreqSt, &ptfFreqSt, sizeof(FIN_RET_FREQ_ST));
					if (crtPtfFreqSt.crystDatesNbr > 0 && crtPtfFreqSt.crystDates != nullptr)
					{
						crtPtfFreqSt.crystDates = nullptr;
						crtPtfFreqSt.crystDates = (DATETIME_T*) CALLOC(crtPtfFreqSt.crystDatesNbr, sizeof(DATETIME_T));
						if (crtPtfFreqSt.crystDates != nullptr)
							memcpy(crtPtfFreqSt.crystDates, ptfFreqSt.crystDates,
							       sizeof(DATETIME_T) * crtPtfFreqSt.crystDatesNbr);
					}

					if (crtPtfFreqSt.periodCrystDatesNbr > 0 && crtPtfFreqSt.periodCrystDates != nullptr)
					{
						crtPtfFreqSt.periodCrystDates = nullptr;
						crtPtfFreqSt.periodCrystDates = (DATETIME_T*) CALLOC(crtPtfFreqSt.periodCrystDatesNbr, sizeof(DATETIME_T));
						if (crtPtfFreqSt.periodCrystDates != nullptr)
							memcpy(crtPtfFreqSt.periodCrystDates, ptfFreqSt.periodCrystDates,
							       sizeof(DATETIME_T) * crtPtfFreqSt.periodCrystDatesNbr);
					}

					/* send crtPtfFreqSt instead of ptfFreqSt */
	    			ret = FIN_ComputePtfSynth(missDomainPtr, ptfTab[i], synthHierHead, &crtPtfFreqSt,
											  &gridInfoSt, &retArg,
											  NULL,			/* REF5885 - CSY - 010330: globalPosNbr */
											  NULL, 0);		/* REF7395 - CSY - 020410 */

					DATE_StopTimer(&SV_ComputePtfSynthTimer, TIMER_MASK_ALL);

					/* REF10964 - CHU - 050531 : log msg when Synth data computed */
					/* PMSTA00521 - RAK - 060926 - Send crtPtfFreqSt and Free */
					FIN_SynthAdminComputeMsg(ret, i+1, ptfNbr, ptfTab[i], &crtPtfFreqSt, dictFctInfo, TRUE);
					if (crtPtfFreqSt.periodCrystDates != nullptr && crtPtfFreqSt.periodCrystDates != crtPtfFreqSt.crystDates)
					{ FREE(crtPtfFreqSt.periodCrystDates);
					  crtPtfFreqSt.periodCrystDatesNbr = 0; }

					if (crtPtfFreqSt.crystDates != nullptr)
					{ FREE(crtPtfFreqSt.crystDates);
					  crtPtfFreqSt.crystDatesNbr = 0; }
				}
				else
				{
					/* Verify selected synthetics : compute missing */
					DATE_StartTimer(&SV_VerifPtfSynthFreqTimer, TIMER_MASK_ALL);
					ret = FIN_VerifPtfSynthFreq(domainPtr, synthHierHead,
												ptfDict, ptfTab[i],
												&(synthTab[begin]), ptfSynthNbr,
												ptfFreqSt.crystDates, ptfFreqSt.crystDatesNbr,
												&gridInfoSt, &retArg,
												NULL, 0);  /* REF9834 - TEB - 041101 */
					DATE_StopTimer(&SV_VerifPtfSynthFreqTimer, TIMER_MASK_ALL);

					/* REF8354 - YST - 021206/021217 - synth admin, comp hist and retDetLevel = Grid:
					set gridId for global line retrieved in database and compute totaliser */
					if(synthAdminCompHistFlg == TRUE &&
                       ((PTFRETDETLVL_ENUM)GET_ENUM(ptfTab[i], A_Ptf_RetDetLevelEn) == PtfRetDetLvl_Grid ||
                       GET_FLAG(domainPtr, A_Domain_SubGridFlg) == TRUE))
					{
						if ((ret = FIN_AddSynthCompHist(synthHierHead, domainPtr, ptfTab[i])) != RET_SUCCEED)
						{
		    				FREE_GRIDINFO(gridInfoSt);
							return(ret);
						}
					}
				}
            }
	    }

	    /* Missing all synthetics for some portfolios (out because of ptfSynthNbr) */
	    while (i < ptfNbr)
	    {
	        /* Get current portfolio frequency and crystallised dates */
	        /* ------------------------------------------------------ */
            if (ptfNbr > 1 /* && GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn)== PtfConsRule_Merged */)  /* REF5582 - CSY - 010215 */
            {
                savFreqPtf = (TINYINT_T) GET_SMALLINT(ptfTab[i], A_Ptf_RetFreq);
                savFreqUnitPtf =  (FREQUNIT_ENUM)GET_ENUM(ptfTab[i], A_Ptf_RetFreqUnitEn); /* REF7264 - LJE - 020131 */
                SET_SMALLINT(ptfTab[i], A_Ptf_RetFreq, commFreqSt.freq);
	            SET_ENUM(ptfTab[i], A_Ptf_RetFreqUnitEn, commFreqSt.freqUnit);
            }

            /* REF8354 - YST - 021107/021206 - compute from and till date for each portfolio like for ptf storage */
            retSynth = RET_SUCCEED;
            if(synthAdminCompHistFlg == TRUE)
            {
                if ((retSynth = FIN_GetPeriodPerfAttrib(domainPtr, nullptr, ptfTab[i], Ptf, NULL, &fromDate, &tillDate, &nullDateTime, &nullDateTime, /* PMSTA-26435 - LJE - 170316 */
                                                        &notUsedFlg, &notUsedFlg, NULL)) == RET_SUCCEED)
                {
                    retArg.domFromDate = fromDate;
                    SET_DATETIME(domainPtr, A_Domain_InterpFromDate, fromDate);
                    SET_DATETIME(domainPtr, A_Domain_InterpTillDate, tillDate);
                    SET_ENUM(domainPtr, A_Domain_RetDetLevelEn, GET_ENUM(ptfTab[i], A_Ptf_RetDetLevelEn));
                }
                else
                {
                    retArg.domFromDate = savDomFromDate;
                    SET_DATETIME(domainPtr, A_Domain_InterpFromDate, savDomFromDate);
                    SET_DATETIME(domainPtr, A_Domain_InterpTillDate, savDomTillDate);
                    SET_ENUM(domainPtr, A_Domain_RetDetLevelEn, domRetDetLevelEn);
                }
            }

			/* REF8354 - For compute history, if FIN_GetPeriodPerfAttrib isn't succeed, don't do computation */
            if (retSynth == RET_SUCCEED)
            {
				DATE_StartTimer(&SV_GetPtfFreqInfoForReturnTimer, TIMER_MASK_ALL);
				if ((ret = FIN_GetPtfFreqInfoForReturn(ptfTab[i], domainPtr, synthHierHead, &oldFreq, &oldFreqUnit,
														&ptfFreqSt, (RETURN_ARG_STP)NULL)) != RET_SUCCEED)
				{
					if (ptfNbr > 1 /*&&GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn)==PtfConsRule_Merged */)  /* REF5582 - CSY - 010215 */
					{
						SET_SMALLINT(ptfTab[i], A_Ptf_RetFreq, savFreqPtf);
						SET_ENUM(ptfTab[i], A_Ptf_RetFreqUnitEn, savFreqUnitPtf);
					}
                    mp.freeDynStp(missDomainPtr);
                    missDomainPtr = NULLDYNST;

					FREE_GRIDINFO(gridInfoSt);
					DATE_StopTimer(&SV_GetPtfFreqInfoForReturnTimer, TIMER_MASK_ALL);
					return(ret);
				}
				DATE_StopTimer(&SV_GetPtfFreqInfoForReturnTimer, TIMER_MASK_ALL);

				if (ptfNbr > 1 /*&&GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn)== PtfConsRule_Merged*/)  /* REF5582 - CSY - 010215 */
				{
					SET_SMALLINT(ptfTab[i], A_Ptf_RetFreq, savFreqPtf);
					SET_ENUM(ptfTab[i], A_Ptf_RetFreqUnitEn, savFreqUnitPtf);
				}

				if (missDomainPtr == NULLDYNST)
				{
                     missDomainPtr = mp.allocDynst(FILEINFO,A_Domain);

					COPY_DYNST(missDomainPtr, domainPtr, A_Domain);
					SET_DICT(missDomainPtr, A_Domain_FctDictId,    (DICT_T) DictFct_Return);
					SET_DICT(missDomainPtr, A_Domain_DimPtfDictId, ptfDict);
				}

				SET_ID(missDomainPtr, A_Domain_PtfObjId, GET_ID(ptfTab[i], A_Ptf_Id));
				/* REF2832 - SSO - 980925: restore the initial from date (modified in FIN_ReturnProcess) */
				SET_DATETIME(missDomainPtr, A_Domain_InterpFromDate, retArg.domFromDate);

				/* REF8354 - YST - 021107/021206 - compute from and till date for each portfolio like for ptf storage */
				if(synthAdminCompHistFlg == TRUE)
				{
					SET_DATETIME(missDomainPtr, A_Domain_InterpFromDate, fromDate);
					SET_DATETIME(missDomainPtr, A_Domain_InterpTillDate, tillDate);
					SET_ENUM(domainPtr, A_Domain_RetDetLevelEn, GET_ENUM(ptfTab[i], A_Ptf_RetDetLevelEn));

				}

				DATE_StartTimer(&SV_ComputePtfSynthTimer, TIMER_MASK_ALL);
	    		ret = FIN_ComputePtfSynth(missDomainPtr, ptfTab[i], synthHierHead,
										  &ptfFreqSt, &gridInfoSt, &retArg,
										  NULL,			/* REF5585 - CSY - 010330: globalPosNbr */
										  NULL, 0);		/* REF5885 - CSY - 010330 */
				DATE_StopTimer(&SV_ComputePtfSynthTimer, TIMER_MASK_ALL);

				/* REF10964 - CHU - 050531 : log msg when Synth data computed */
				FIN_SynthAdminComputeMsg(ret, i+1, ptfNbr, ptfTab[i], &ptfFreqSt, dictFctInfo, TRUE);

				i++;	/* next portfolio */
            }
	    }
	}

	if (ptfFreqSt.crystDates != nullptr)
	{ FREE(ptfFreqSt.crystDates);
	  ptfFreqSt.crystDatesNbr = 0; }

    /* REF8354 - YST - 021107/021206 - synth admin, comp hist: reset domain */
    if(synthAdminCompHistFlg == TRUE)
    {
        SET_DATETIME(domainPtr, A_Domain_InterpFromDate, savDomFromDate);
        SET_DATETIME(domainPtr, A_Domain_InterpTillDate, savDomTillDate);
        SET_ENUM(domainPtr, A_Domain_RetDetLevelEn, domRetDetLevelEn);
    }
    /* REF8354 - YST - 021211 - For synth admin, comp hist: following treatments are not necessary */
    else
    {
		/*** --------------------------------------- ***/
		/*** Group synthetics to domain detail level ***/
		/*** (if domain detail level is set to grid) ***/
		/*** --------------------------------------- ***/
		DATE_StartTimer(&SV_ReturnVerifPtfSynthGroupDetTimer, TIMER_MASK_ALL);
        if ((PTFRETDETLVL_ENUM)GET_ENUM(domainPtr, A_Domain_RetDetLevelEn) == PtfRetDetLvl_Grid ||
            GET_FLAG(domainPtr, A_Domain_SubGridFlg) == TRUE)
		{
			/* REF9834 - RAK - 040218 - Create new sub-function FIN_GroupPtfSynthToDomGridDetLvl() */
			if ((ret = FIN_GroupPtfSynthToDomGridDetLvl(domainPtr, ptfTab, ptfNbr, synthHierHead, &gridInfoSt)) != RET_SUCCEED)
			{
				FREE_GRIDINFO(gridInfoSt);
				DATE_StopTimer(&SV_ReturnVerifPtfSynthGroupDetTimer, TIMER_MASK_ALL);
				return(ret);
			}
		}
		DATE_StopTimer(&SV_ReturnVerifPtfSynthGroupDetTimer, TIMER_MASK_ALL);

		/*** ------------------------------------- ***/
		/*** Group synthetics to general frequency ***/
		/*** ------------------------------------- ***/
		DATE_StartTimer(&SV_ReturnVerifPtfSynthGroupFreqTimer, TIMER_MASK_ALL);
		if (ptfNbr > 1)/* Necessary only if more than one portfolio */
		{
			if (GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) == PtfConsRule_Merged ||
				(GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) == PtfConsRule_Detailed && diffFreq == TRUE))   /* REF5582 - CSY - 010309 */
			{
				/* REF9834 - RAK - 040218 - Create new sub-function FIN_GroupPtfSynthToGeneralFreq() */
				ret = FIN_GroupPtfSynthToGeneralFreq(domainPtr, ptfTab, ptfNbr, synthHierHead, &commFreqSt);
				mp.owner(commFreqSt.crystDates);
			}
		}
		DATE_StopTimer(&SV_ReturnVerifPtfSynthGroupFreqTimer, TIMER_MASK_ALL);

		/* REF5205 - RAK - 000927                          */
		/* Move convertion before merge because            */
		/* of merge doesn't work with different currencies */
		/* Rem : now we have two ptfNbr > 1                */
		/*** ----------------------------------------------------------------- ***/
		/*** Convert portfolio synthetics (in ptf currency) to domain currency ***/
		/*** ----------------------------------------------------------------- ***/
		DATE_StartTimer(&SV_ReturnVerifPtfSynthConvertTimer, TIMER_MASK_ALL);
		synthNbr = 0;
		synthTab = NULLDYNSTPTR;
		/* REF6220 - LJE - 020319 : Nothing to do if the def curr flag is "Default" */
		if (domainPtr != NULL && GET_FLAG(domainPtr, A_Domain_DefCurrFlg) == FALSE)
		{
			/* REF9834 - RAK - 040218 - Create new sub-function FIN_ConvertPtfSynthToDomCurr() */
			if ((ret = FIN_ConvertPtfSynthToDomCurr(domainPtr, ptfTab, ptfNbr, synthHierHead)) != RET_SUCCEED)
			{
				FREE_GRIDINFO(gridInfoSt);
				DATE_StopTimer(&SV_ReturnVerifPtfSynthConvertTimer, TIMER_MASK_ALL);
				return(ret);
			}
		}
		DATE_StopTimer(&SV_ReturnVerifPtfSynthConvertTimer, TIMER_MASK_ALL);

		/* REF5205 - RAK - 000927 */
		DATE_StartTimer(&SV_ReturnVerifPtfSynthGroupFreqTimer, TIMER_MASK_ALL);
		if (ptfNbr > 1)
		{
            if (GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None &&
                (PTFCONSRULE_ENUM)GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) != PtfConsRule_DetailedChildren && /* PMSTA02013 - RAK - 071112 */
                (PTFCONSRULE_ENUM)GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) != PtfConsRule_Merged &&
                ((static_cast<LOADHIERPTF_ENUM> GET_ENUM(domainPtr, A_Domain_LoadHierFlg) != LoadHierPtf_IntermediateHierarchy) ?
                    true : FIN_IsPtfConsRuleValidForIntermediateHierarchy(domainPtr) == false))
			{
				ret = FIN_MergePtfSynthHierPtf(domainPtr, synthHierHead);
			}

			if ((PTFCONSRULE_ENUM) GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) == PtfConsRule_Merged)
			{
				synthNbr = 0;
				if ((ret = DBA_ExtractHierEltRec(synthHierHead, A_PtfSynth,
												 FALSE, NULLFCT, FIN_CmpPtfSynthNatDetailDate,
												 &synthNbr, &synthTab)) != RET_SUCCEED)
				{
                    FREE(synthTab);
					DATE_StopTimer(&SV_ReturnVerifPtfSynthGroupFreqTimer, TIMER_MASK_ALL);
					return(ret);
				}

                mp.ownerPtr(synthTab);

				ret = FIN_MergePtfSynth(synthHierHead, synthTab, synthNbr);
			}
		}
		DATE_StopTimer(&SV_ReturnVerifPtfSynthGroupFreqTimer, TIMER_MASK_ALL);

		/* REF5205 - RAK - 000927                          */
		/* Move convertion before merge because            */
		/* of merge doesn't work with different currencies */

		/* REF4263 - RAK - 000309 */
		/* Verify that for each date we have all market segment of a grid */
		DATE_StartTimer(&SV_ReturnVerifPtfSynthGridEmptyMktTimer, TIMER_MASK_ALL);
        if ((PTFRETDETLVL_ENUM)GET_ENUM(domainPtr, A_Domain_RetDetLevelEn) == PtfRetDetLvl_Grid ||
            GET_FLAG(domainPtr, A_Domain_SubGridFlg) == TRUE)
		{
			if (gridInfoSt.gridNbr == 1)
			{
				/* REF9834 - RAK - 040218 - create new sub-function FIN_PtfSynthForAllMktSgtOfGrid() */
				if ((ret = FIN_PtfSynthForAllMktSgtOfGrid(domainPtr, &gridInfoSt, synthHierHead)) != RET_SUCCEED)
				{
					FREE_GRIDINFO(gridInfoSt);
					DATE_StopTimer(&SV_ReturnVerifPtfSynthGridEmptyMktTimer, TIMER_MASK_ALL);
					return(ret);
				}
			}
		}
    }/* REF8354 - YST - 021211 - end treatments which are not necessary for synth admin, comp hist */

    /* REF7395 - CSY - 020614: second synth also used in return and synth admin (with comp_data_en ==
    compude history) only for portfolios with ret_freq_unit = Month TWR or Month global TWR */
	/* PMSTA08680 - LJE - 090918 - Loop over all ptfs */
	for (i=0; i<ptfNbr; i++)
	{
		if((ret = FIN_CreateSecondSynthNew(domainPtr, synthHierHead, ptfTab[i], NULL, 0)) != RET_SUCCEED)
		{
			return(ret);
		}
	}

    /* REF7395 - CSY - 020815: in synth admin, with mode  comp_data_e == compute history
    use secondary synthetics to insert into perf attrib table and extended return analysis table */
    if(synthAdminCompHistFlg == TRUE)
    {
        RET_CODE            insertRet = RET_SUCCEED;
        FLAG_T              eventSchedFlg = FALSE;
        DBA_INSPAEXTRA_ST   insPaExtRaSt;   /* REF7421 - YST - 020808 */

        memset(&insPaExtRaSt, 0, sizeof(DBA_INSPAEXTRA_ST));

        for(i=0; i < ptfNbr; i++)
        {
            eventSchedFlg = FALSE;
            notUsedFlg = FALSE;
            /* Get delete from and till date and eventSchedFlg */
            ret = FIN_GetPeriodPerfAttrib(domainPtr, nullptr, ptfTab[i], Ptf, NULL, &nullDateTime, &nullDateTime, &fromDate, &tillDate, /* PMSTA-26435 - LJE - 170316 */
                                          &notUsedFlg, &eventSchedFlg, NULL);
            
            /* prepare insert performance data in database */
            if (ret == RET_SUCCEED)
            {
                insertRet = FIN_InsertPaAndExtRaData(domainPtr, synthHierHead, synthHierHead, ptfTab[i], NULL,
                                            fromDate,
                                            tillDate,
                                            eventSchedFlg,  /* delEventSchedFlg */
                                            FALSE,          /* forceInsertFlg */
                                            &insPaExtRaSt, nullptr);
            }
            /* REF8348 - YST - 021105 - avoid server dialog error *
            else if (ret == RET_GEN_ERR_INVALIDATE)
            {ret = RET_SUCCEED;}*/
        }

        /* force insert performance data in database */
        ret = FIN_InsertPaAndExtRaData(domainPtr,
                                        synthHierHead,
                                        synthHierHead,  /* PMSTA08736 - LJE - 100412 */
                                        NULLDYNST,  NULL,
                                        nullDateTime,
                                        nullDateTime,
                                        FALSE, /* delEventSchedFlg */
                                        TRUE,   /* forceInsertFlg */
                                        &insPaExtRaSt, nullptr);

		SCPT_FreeScriptDV(NullEntity); /* PMSTA06772 - 080619 - DDV */
    }

    DATE_StopTimer(&SV_ReturnVerifPtfSynthGridEmptyMktTimer, TIMER_MASK_ALL);

	FREE_GRIDINFO(gridInfoSt);

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_ReturnVerifPtfSynthCompHistory()
**
**  Description :   Verify loaded synthetics depend on ptf frequency,
**		            and compute missing data for compute history
**
**  Arguments   :   domainPtr     domain structure pointer
**                  synthHierHead synthetic hierarchy pointer
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   REF9834 - TEB - 040617
**
*************************************************************************/
STATIC RET_CODE FIN_ReturnVerifPtfSynthCompHistory(DBA_DYNFLD_STP     domainPtr,
			                                       DBA_HIER_HEAD_STP  synthHierHead)
{
    PA_INFO_ST          paInfoSt;
	DBA_DYNFLD_STP	    *ptfTab=NULLDYNSTPTR,
						*synthTab=NULLDYNSTPTR,
						*synthPSPTab=NULLDYNSTPTR,
						*gloSynthTab=NULLDYNSTPTR,
						savDomPtr=NULLDYNST;
	int		            ptfNbr,
						synthNbr, gloSynthNbr=0, i, delNb,
						synthPSPNbr=0,
						paInfoIdx=0,
						ptfIdx=0;
    DBA_INSPAEXTRA_ST   insPaExtRaSt;
	RET_CODE 	        ret, insertRet;
	RETURN_ARG_ST	    retArg;
	DICT_T		        ptfDict;
	RETURN_GRID_INFO_ST gridInfoSt;
    DATETIME_T			nullDateTime,
						*crystalDates;
	FLAG_T				allPtfSynthFlg=FALSE;

    if (synthHierHead == (DBA_HIER_HEAD_STP)NULL)
    {
        return(RET_DBA_ERR_HIER);
    }

    int                 currPspPos, pspNbr;
    DBA_DYNFLD_STP     *pspTab = NULL, currPtf;
    DBA_HIER_HEAD_STP   pspSynthHierHead = DBA_CreateHier();

	/*** ----------------------------------------------------- ***/
    /*** Initializations                                       ***/
	/*** ----------------------------------------------------- ***/
    memset(&paInfoSt, 0, sizeof(PA_INFO_ST));
    paInfoSt.paDateInfoTab = NULL;
    paInfoSt.paDateInfoNbr = 0;
    paInfoSt.synthAdminFlg = TRUE;


	if ((savDomPtr = ALLOC_DYNST(A_Domain)) == NULLDYNST)
	{
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}
	COPY_DYNST(savDomPtr, domainPtr, A_Domain);

	memset(&insPaExtRaSt, 0, sizeof(DBA_INSPAEXTRA_ST));

	memset(&retArg, 0, sizeof(RETURN_ARG_ST));
	retArg.domFromDate = GET_DATETIME(domainPtr, A_Domain_InterpFromDate);
	GEN_GetApplInfo(ApplReversalMethode, &retArg.reversalMethode);

	memset(&gridInfoSt, 0, sizeof(RETURN_GRID_INFO_ST));

    memset(&nullDateTime, 0, sizeof(DATETIME_T));

	DBA_GetDictId(Ptf, &ptfDict);

	synthNbr = 0;

	/*** ----------------------------------------------------- ***/
    /*** Read loaded data (perf_storage_param (s))             ***/
	/*** ----------------------------------------------------- ***/
    if ((ret = DBA_ExtractHierEltRec(synthHierHead, A_PerfStorageParam, TRUE, NULLFCT,
                                     NULL, &pspNbr, &pspTab)) != RET_SUCCEED)
	{
		FREE_DYNST(savDomPtr, A_Domain);
        return(ret);
    }

    DBA_HierEltShare(pspSynthHierHead, A_Ptf, synthHierHead, A_Ptf);
    currPtf = NULL;

    for (currPspPos = 0; currPspPos < pspNbr; currPspPos++)
    {
        if ((currPtf == NULL || GET_ID(currPtf, A_Ptf_Id) != GET_ID(pspTab[currPspPos], A_PerfStorageParam_ObjId)) &&
            DBA_GetRecPtrFromHierById(synthHierHead, GET_ID(pspTab[currPspPos], A_PerfStorageParam_ObjId), A_Ptf, &currPtf) != RET_SUCCEED)
        {
            continue;
	}
        ptfTab = &currPtf;
        ptfNbr = 1;

        if ((ret = DBA_ExtractHierEltRecWithFilterSt(synthHierHead, A_PtfSynth,
            TRUE,
            FIN_FilterPtfSynthByPSPInfo,
            pspTab[currPspPos],
            FIN_CmpPtfSynthPtfDate,
            &synthNbr, &synthTab)) != RET_SUCCEED)

	{
		FREE_DYNST(savDomPtr, A_Domain);
            FREE(pspTab);
		return(ret);
	}

        if (synthNbr == 0)
        {
            FREE_DYNST(pspTab[currPspPos], A_PerfStorageParam);
            continue;
        }

		if (((PTFRETDETLVL_ENUM)GET_ENUM(currPtf, A_Ptf_RetDetLevelEn) == PtfRetDetLvl_Grid && (GET_FLAG(pspTab[currPspPos], A_PerfStorageParam_InstrLevelFlg) == FALSE)) ||
			((PTFRETDETLVL_ENUM)GET_ENUM(currPtf, A_Ptf_RetDetLevelEn) == PtfRetDetLvl_Instrument && (GET_FLAG(pspTab[currPspPos], A_PerfStorageParam_InstrLevelFlg) == TRUE)
			))
		{
				SET_DATETIME(domainPtr, A_Domain_InterpFromDate, GET_DATETIME(synthTab[0], A_PtfSynth_InitialDate));
		}
		else
		{
			i = synthNbr - 1;
			while (i > 0 &&
               CMP_DYNFLD(synthTab[i - 1], synthTab[i], A_PtfSynth_FinalDate, A_PtfSynth_InitialDate, DatetimeType) == 0)
			{
				i--;
			}

				SET_DATETIME(domainPtr, A_Domain_InterpFromDate, GET_DATETIME(synthTab[i], A_PtfSynth_InitialDate));

			while (i > 0)
				{
				i--;
				FREE_DYNST(synthTab[i], A_PtfSynth);
				}
		}
        SET_DATETIME(domainPtr, A_Domain_InterpTillDate, GET_DATETIME(synthTab[synthNbr-1], A_PtfSynth_FinalDate));

        DBA_AddHierRecord(pspSynthHierHead, pspTab[currPspPos], A_PerfStorageParam, FALSE, HierAddRec_NoLnk);
        DBA_AddHierRecordList(pspSynthHierHead, synthTab, synthNbr, A_PtfSynth, FALSE);

        FREE(synthTab);
        synthNbr = 0;

	/*** ----------------------------------------------------- ***/
	/*** Compute Crist date, set PSP id on ptfSynth, etc...    ***/
	/*** ----------------------------------------------------- ***/
        if ((ret = FIN_SetPaDateInfo(domainPtr, pspSynthHierHead, ptfTab, ptfNbr, &paInfoSt)) != RET_SUCCEED)
    {
		FREE_DYNST(savDomPtr, A_Domain);
            FREE(pspTab);
        return(ret);
    }

	/*** ----------------------------------------------------- ***/
	/*** Read loaded data (synthetics)                         ***/
	/*** ----------------------------------------------------- ***/
        if ((ret = DBA_ExtractHierEltRec(pspSynthHierHead, A_PtfSynth,
									 FALSE, NULLFCT, FIN_CmpPtfSynthPtfDate,
									 &synthNbr, &synthTab)) != RET_SUCCEED)
	{
		FREE_DYNST(savDomPtr, A_Domain);
            FREE(pspTab);
		return(ret);
	}

	/*** ----------------------------------------------------- ***/
	/*** Loop on PSP                                           ***/
	/*** ----------------------------------------------------- ***/
        for (paInfoIdx = 0; paInfoIdx < paInfoSt.paDateInfoNbr; paInfoIdx++)
	{
		/* Point ptfIdx to the right Ptf  */
		/* ------------------------------ */
            ptfIdx = 0;

            while (ptfIdx < ptfNbr && CMP_ID(paInfoSt.paDateInfoTab[paInfoIdx].ptfId, GET_ID(ptfTab[ptfIdx], A_Ptf_Id)) != 0)
		{
			ptfIdx++;
		}

		/* Suppress synt data for which we still have performed the computation */
		/* -------------------------------------------------------------------- */
		if ((ret = FIN_CompHistPerfFirstDate(&(paInfoSt.paDateInfoTab[paInfoIdx].pspPtr),
											 1,
                pspSynthHierHead,
											 &synthTab,
											 &synthNbr)) != RET_SUCCEED)
		{
			FREE_DYNST(savDomPtr, A_Domain);
			FREE(ptfTab);
			FREE(synthTab);
			return(ret);
	    }

		/* If no synth data, don't compute */
		/* ------------------------------- */
		if (synthNbr == 0)
		{
                continue;
		}
		else
		{
			/* We have the calcFrom and calcTill date on each PSP info (set in FIN_SetPaDateInfo) */
			/* ---------------------------------------------------------------------------------- */
            retArg.domFromDate = paInfoSt.paDateInfoTab[paInfoIdx].calcFromDate;
            SET_DATETIME(domainPtr, A_Domain_InterpFromDate, paInfoSt.paDateInfoTab[paInfoIdx].calcFromDate);
            SET_DATETIME(domainPtr, A_Domain_InterpTillDate, paInfoSt.paDateInfoTab[paInfoIdx].calcTillDate);
            SET_ENUM(domainPtr, A_Domain_RetDetLevelEn, GET_ENUM(ptfTab[ptfIdx], A_Ptf_RetDetLevelEn));

			/* Select current PSP's synthetics       */
			/* ------------------------------------- */
			FREE(synthTab);
                synthNbr = 0;

                if ((ret = DBA_ExtractHierEltRecWithFilterSt(pspSynthHierHead, A_PtfSynth,
			    										FALSE,
														FIN_FilterPtfSynthByPSPGlob, paInfoSt.paDateInfoTab[paInfoIdx].pspPtr,
														FIN_CmpPtfSynthPtfDate /*FIN_CmpPtfSynthPtfPspDate*/, /* REF9834 - TEB - 041210 */
				    									&synthNbr, &synthTab)) != RET_SUCCEED)

			{
				FREE_DYNST(savDomPtr, A_Domain);
				FREE(ptfTab);
				return(ret);
			}

                synthPSPNbr = 0;
                if ((ret = DBA_ExtractHierEltRecWithFilterSt(pspSynthHierHead, A_PtfSynth,
			    										FALSE,
														FIN_FilterPtfSynthByPSP, paInfoSt.paDateInfoTab[paInfoIdx].pspPtr,
														FIN_CmpPtfSynthPtfPspDate,
				    									&synthPSPNbr, &synthPSPTab)) != RET_SUCCEED)
			{
				FREE_DYNST(savDomPtr, A_Domain);
				FREE(ptfTab);
				return(ret);
			}
			FREE(synthPSPTab);

			/* Verify current PSP's synthetics       */
			/* If no data, don't compute             */
			/* ------------------------------------- */
			if (synthPSPNbr > 0)
			{
				/* Take crystal dates from the PSP paInfo */
				/* -------------------------------------- */
                    if ((crystalDates = (DATETIME_T*)CALLOC(paInfoSt.paDateInfoTab[paInfoIdx].paDatesNbr, sizeof(DATETIME_T))) == NULL)
				{
					FREE_DYNST(savDomPtr, A_Domain);
					FREE(ptfTab);
					FREE(synthTab);
					MSG_RETURN(RET_MEM_ERR_ALLOC);
				}

                    for (i = 0; i < paInfoSt.paDateInfoTab[paInfoIdx].paDatesNbr; i++)
				{
					crystalDates[i].date = paInfoSt.paDateInfoTab[paInfoIdx].paDates[i].dateTime.date;
				}

				allPtfSynthFlg = FIN_VerifPtfSynthIsComplete(synthTab,
															 synthNbr,
															 crystalDates,
															 paInfoSt.paDateInfoTab[paInfoIdx].paDatesNbr);
				FREE(crystalDates);

				if (allPtfSynthFlg == TRUE)
				{
					/* If retDetLevel = Grid: set gridId for global line retrieved in database and compute totaliser */
					/* --------------------------------------------------------------------------------------------- */
                        if ((PTFRETDETLVL_ENUM)GET_ENUM(ptfTab[ptfIdx], A_Ptf_RetDetLevelEn) == PtfRetDetLvl_Grid ||
						((PTFRETDETLVL_ENUM)GET_ENUM(ptfTab[ptfIdx], A_Ptf_RetDetLevelEn) == PtfRetDetLvl_Instrument &&	/* REF9834 - TEB - 041207 */
                            IS_NULLFLD(paInfoSt.paDateInfoTab[paInfoIdx].pspPtr, A_PerfStorageParam_GridId) == FALSE))	/* REF9834 - TEB - 041207 */
					{
						/* REF9834 - TEB - 041130 */
						gloSynthNbr = 0;

                            /* Extract all global synthetics for the given portfolio */
                            if ((ret = DBA_ExtractHierEltRecWithFilterSt(pspSynthHierHead,
																	 A_PtfSynth,
																	 TRUE,
																	 FIN_FilterGlobalSynthCompHist, ptfTab[ptfIdx],
																	 NULL,
																	 &gloSynthNbr,
																	 &gloSynthTab)) != RET_SUCCEED)
						{
							FREE_DYNST(savDomPtr, A_Domain);
							FREE(ptfTab);
							FREE(synthTab);
							FREE_GRIDINFO(gridInfoSt);
							return(ret);
						}

                            /* Delete the global synthetics for the given portfolio from hierarchy */
                            if ((ret = DBA_DelHierEltRecWithFilter(pspSynthHierHead,
															   A_PtfSynth,
															   FIN_FilterGlobalSynthCompHist,
															   ptfTab[ptfIdx],
                                &delNb)) != RET_SUCCEED)
						{
							FREE_DYNST(savDomPtr, A_Domain);
                                if (gloSynthNbr > 0)
							{
                                    for (i = 0; i < gloSynthNbr; i++)
									FREE_DYNST(gloSynthTab[i], A_PtfSynth);
								FREE(gloSynthTab);
							}
							FREE(ptfTab);
							FREE(synthTab);
							FREE_GRIDINFO(gridInfoSt);
							return(ret);
						}

						/* Compute totaliser */
                            if ((ret = FIN_AddSynthCompHistNew(pspSynthHierHead,
														   domainPtr,
														   ptfTab[ptfIdx],
														   paInfoSt.paDateInfoTab[paInfoIdx].pspPtr,
														   gloSynthTab,
														   gloSynthNbr)
							) != RET_SUCCEED)
						{
                                if (gloSynthNbr > 0)
							{
                                    for (i = 0; i < gloSynthNbr; i++)
									FREE_DYNST(gloSynthTab[i], A_PtfSynth);
								FREE(gloSynthTab);
							}
							FREE_DYNST(savDomPtr, A_Domain);
							FREE(ptfTab);
							FREE(synthTab);
		    				FREE_GRIDINFO(gridInfoSt);
							return(ret);
						}

                            if (gloSynthNbr > 0)
						{
                                for (i = 0; i < gloSynthNbr; i++)
								FREE_DYNST(gloSynthTab[i], A_PtfSynth);
							FREE(gloSynthTab);
						}
					}


					/* Create secondary synthetics */
					/* --------------------------- */
                        if ((ret = FIN_CreateSecondSynthNew(domainPtr, pspSynthHierHead, ptfTab[ptfIdx], &paInfoSt, paInfoIdx)) != RET_SUCCEED)
					{
						FREE_DYNST(savDomPtr, A_Domain);
						FREE(ptfTab);
						FREE(synthTab);
						FREE_GRIDINFO(gridInfoSt);
						return(ret);
					}

					/* Prepare insert performance data in database */
					/* ------------------------------------------- */
                        insertRet = FIN_InsertPaAndExtRaData(domainPtr, pspSynthHierHead, pspSynthHierHead, ptfTab[ptfIdx],  /* PMSTA08736 - LJE - 100412 */
														 paInfoSt.paDateInfoTab[paInfoIdx].pspPtr,
														 paInfoSt.paDateInfoTab[paInfoIdx].delFromDate,
														 paInfoSt.paDateInfoTab[paInfoIdx].delTillDate,
														 paInfoSt.paDateInfoTab[paInfoIdx].eventSchedFlg,
														 FALSE,
														 &insPaExtRaSt, nullptr);
				}
			}
		}

		FREE_GRIDINFO(gridInfoSt);

	}

    /* Insert the prepared perfData */
	/* ---------------------------- */
    ret = FIN_InsertPaAndExtRaData(domainPtr,
                                       pspSynthHierHead,
                                       pspSynthHierHead, /* PMSTA08736 - LJE - 100412 */
                                   NULLDYNST,  NULL,
                                   nullDateTime,
                                   nullDateTime,
                                   FALSE,  /* delEventSchedFlg */
                                   TRUE,   /* forceInsertFlg   */
                                   &insPaExtRaSt, nullptr);

    /* Memory free */
	/* ----------- */
        for (i = 0; i < paInfoSt.paDateInfoNbr; i++)
    {
        FREE((paInfoSt.paDateInfoTab[i]).paDates);
    }
    FREE(paInfoSt.paDateInfoTab);

	/* PMSTA08391 - LJE - 090713 */
	FREE(paInfoSt.synthInstrTab);
	paInfoSt.synthInstrNbr = 0;

        DBA_FreeHierAllEltRecord(pspSynthHierHead);
        synthNbr = 0;
        FREE(synthTab);
    }

    DBA_FreeHier(pspSynthHierHead);
	FREE_DYNST(savDomPtr, A_Domain);
    FREE(pspTab);
	return(RET_SUCCEED);
}


/************************************************************************
**
**  Function    :   FIN_VerifPtfSynthIsComplete()
**
**  Description :   Verificate portfolio's synthetics are complete acording
**		            the crystallised dates
**
**  Arguments   :   synthTab 	    synthetics array
**		            synthNbr	    synthetics number
**		            crystalDates    crystallised dates array
**		            crystalDatesNbr crystallised dates number
**
**  Return      :   TRUE or FALSE
**
**  Creation    :   REF9834 - TEB - 041210
**
*************************************************************************/
STATIC FLAG_T FIN_VerifPtfSynthIsComplete(DBA_DYNFLD_STP        *synthTab,
										  int                   synthNbr,
										  DATETIME_T	        *crystalDates,
										  int		            crystalDatesNbr)
{
	int  		i, j, dateCmp;
	FLAG_T		completeFlg = TRUE;

	i=j=0;

	while (i<synthNbr && j<crystalDatesNbr && completeFlg == TRUE)
	{
		if ((dateCmp = DATETIME_CMP(GET_DATETIME(synthTab[i],A_PtfSynth_InitialDate),
									crystalDates[j])) > 0)
	    {
			completeFlg = FALSE;
	    }
	    else if (dateCmp == 0)
			j++;

	    while (i+1 != synthNbr &&
			   DATETIME_CMP(GET_DATETIME(synthTab[i+1], A_PtfSynth_InitialDate),
							GET_DATETIME(synthTab[i],   A_PtfSynth_InitialDate)) == 0)
	    {
		    i++;
	    }

	    i++;
	}

	return(completeFlg);
}

/************************************************************************
**
**  Function    :   FIN_PtfSynthForAllMktSgtOfGrid()
**
**  Description :
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   REF9834 - RAK - 040218
**
*************************************************************************/
STATIC RET_CODE FIN_PtfSynthForAllMktSgtOfGrid(DBA_DYNFLD_STP	    domainPtr,
											   RETURN_GRID_INFO_STP gridInfoStp,
											   DBA_HIER_HEAD_STP    synthHierHead)
{
	RET_CODE		ret=RET_SUCCEED;
	DBA_DYNFLD_STP  *mktSgtTab=NULLDYNSTPTR, *synthTab=NULLDYNSTPTR;
	int             i=0, j=0, mktSgtNbr=0, mktIdx=0, synthNbr=0;

	/* Order synthetics by portfolio, date and market segments */
	/* but with global synthetic at the end of each date ! */
	if ((ret = DBA_ExtractHierEltRec(synthHierHead, A_PtfSynth,
									 FALSE, NULLFCT, FIN_CmpMktSgtSynth,
									 &synthNbr, &synthTab)) != RET_SUCCEED)
	{
		return(ret);
	}

	/* REF4263 - RAK - 000414 */
	if ((ret = FIN_GetGridMktSgtWithoutTotal(gridInfoStp->gridTab[0],
											 &mktSgtTab, &mktSgtNbr)) != RET_SUCCEED)
	{
		FREE(synthTab);
		return(ret);
	}

	if (mktSgtNbr > 0 && synthNbr > 0)
	{
		if(mktSgtNbr > 1)
		{
			TLS_Sort((char*) mktSgtTab, mktSgtNbr, sizeof(DBA_DYNFLD_STP), (TLS_CMPFCT *)FIN_CmpMktSgtId, /* REF7264 - LJE - 020131 */
					 (PTR**)NULL, SortRtnTp_None);
		}

		mktIdx = 0;
		i = 0;
		while (i<synthNbr)
		{
			/* Same -> next synthetics, next market segment, no problem */
			if (mktIdx < mktSgtNbr &&
				GET_ID(synthTab[i], A_PtfSynth_MktSegtId) ==
				GET_ID(mktSgtTab[mktIdx], S_MktSegt_Id))
			{
				mktIdx++;
				i++;
			}
			/* Global : normaly end of market segments list, (mktIdx can be mktSgtNbr) */
			/* elsewhere create a synth for each missing mktSgt */
			else if (IS_NULLFLD(synthTab[i], A_PtfSynth_MktSegtId) == TRUE)
			{
				for (j=mktIdx; j<mktSgtNbr; j++)
				{
					FIN_CreateEmptyMktSgtPtfSynth(synthHierHead, synthTab, i, synthNbr, /* REF9049 - LJE - 030512 */
												  gridInfoStp->gridTab[0],
												  GET_ID(mktSgtTab[j], S_MktSegt_Id),
                                                  NULL); /* REF9743 - LJE - 040302 */
				}
				mktIdx = 0; /* begin of market segments list */
				i++;
			}
			/* Missing market segment(s) */
			else
			{
				while (mktIdx < mktSgtNbr &&
					   GET_ID(mktSgtTab[mktIdx], S_MktSegt_Id) >
					   GET_ID(synthTab[i], A_PtfSynth_MktSegtId))
				{
					FIN_CreateEmptyMktSgtPtfSynth(synthHierHead, synthTab, i, synthNbr, /* REF9049 - LJE - 030512 */
												 gridInfoStp->gridTab[0],
												 GET_ID(mktSgtTab[mktIdx], S_MktSegt_Id),
                                                 NULL); /* REF9743 - LJE - 040302 */
					mktIdx++;
				}

				/* now GET_ID(mktSgtTab[mktIdx], S_MktSegt_Id) ==  */
				/*     GET_ID(synthTab[i], A_PtfSynth_MktSegtId)   */
				/* so go to next synthetic and mkt sgt for next verification */
				mktIdx++;
				i++;
			}
		}
	}

	FREE(synthTab);
	DBA_FreeDynStTab(mktSgtTab, mktSgtNbr, S_MktSegt);

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_FilterPtfSynthEmpty()
**
**  Description :   Extract synthetics of parent portfolio
**                  Used by hierarchy tools function DBA_ExtractHierEltRecWithFilterSt()
**                  return TRUE  -> record must be extract
**                         FALSE -> record mustn't be extract
**
**  Arguments   :   dynSt      dynamic structure pointer
**                  dynStTp    dynamic structure definition
**		            ptfPtr  parameter dynamic structure pointer
**
**  Return      :   TRUE or FALSE
**
**  Creation	:   PMSTA-11730 - LJE - 110421
**  Modification:
**
*************************************************************************/
STATIC int FIN_FilterPtfSynthEmpty(DBA_DYNFLD_STP dynSt,
			                       DBA_DYNST_ENUM dynStTp,
                                   DBA_DYNFLD_STP ptfPtr)
{
    return(GET_ENUM(dynSt, A_PtfSynth_ToInsertEn) == PtfSynthAction_Insert); /* PMSTA-18006 - LJE - 140430 */
}


/************************************************************************
**
**  Function    :   FIN_ConvertPtfSynthToDomCurr()
**
**  Description :
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   REF9834 - RAK - 040218
**
*************************************************************************/
STATIC RET_CODE FIN_MergePtfSynthHierPtf(DBA_DYNFLD_STP	 domainPtr,
										 DBA_HIER_HEAD_STP synthHierHead)
{
	RET_CODE		ret=RET_SUCCEED;
	int             i, j, synthNbr=0, tmpSynthNbr=0, childNbr=0;
	DBA_DYNFLD_STP  *synthTab = NULLDYNSTPTR, parPtfPtr=NULLDYNST, *tmpSynthTab=NULLDYNSTPTR, *childTab=NULLDYNSTPTR;
	DBA_DYNFLD_STP  parIdPtr = NULLDYNST;
	ID_T            defaultId = -1;
    int             delNbr;

	/* extract all portfolio which have a HierPtfId and sort by parent ptf */
	if ((ret = DBA_ExtractHierEltRec(synthHierHead, A_Ptf,
									 FALSE, FIN_FilterChildrenPtf, FIN_CmpChildrenPtf,
									 &childNbr, &childTab)) != RET_SUCCEED)
	{
		return(ret);
	}

    /* PMSTA-11730 - LJE - 110421 */
	if ((ret = DBA_DelHierEltRecWithFilter(synthHierHead,
										   A_PtfSynth,
										   FIN_FilterPtfSynthEmpty,
										   NULL,
										   &delNbr)) != RET_SUCCEED)
    {
        return(ret);
    }

	if (childNbr > 0)
	{
		if ((parIdPtr = ALLOC_DYNST(Io_Id)) == NULLDYNST)
		{
			FREE(childTab);
			return(RET_MEM_ERR_ALLOC);
		}

		SET_ID(parIdPtr, Io_Id_Id, defaultId);

		/* extract all synthetic of each children portfolios and parent portfolio */
		for (i=0; i<childNbr; i++)
		{
			if (GET_EXTENSION_PTR(childTab[i], A_Ptf_HierPtf_Ext) != NULL &&
				(parPtfPtr = *(GET_EXTENSION_PTR(childTab[i], A_Ptf_HierPtf_Ext))) != NULLDYNST)
			{
				/* Extract port_synthetics of parent portfolio */
				if (GET_ID(parIdPtr, Io_Id_Id) != GET_ID(parPtfPtr, A_Ptf_Id))
				{
					/* For filter and test */
					SET_ID(parIdPtr, Io_Id_Id, GET_ID(parPtfPtr, A_Ptf_Id));

					if ((ret = DBA_ExtractHierEltRecWithFilterSt(synthHierHead, A_PtfSynth,
																 FALSE, FIN_FilterPtfSynthParent,
																 parIdPtr, NULLFCT,
																 &tmpSynthNbr, &tmpSynthTab)) != RET_SUCCEED)
					{
						FREE(childTab);
						FREE_DYNST(parIdPtr, Io_Id);
						return(ret);
					}

					/* REF11087 - RAK - 050407 - in case of synthNbr+tmpSynthNbr == 0      */
					/* REALLOC return a NULL pointer and we go out which isn't a good idea */
					if (tmpSynthNbr > 0)
					{
						if ((synthTab = (DBA_DYNFLD_STP*) REALLOC(synthTab,
										(synthNbr+tmpSynthNbr)*sizeof(DBA_DYNFLD_STP)))== NULL)
						{
							FREE(tmpSynthTab);
							FREE(synthTab);
							FREE(childTab);
							FREE_DYNST(parIdPtr, Io_Id);
							return(ret);
						}

						for (j=0; j<tmpSynthNbr; j++)
						{
							/* keep parent synthetics in array */
							synthTab[synthNbr] = tmpSynthTab[j];
							++synthNbr;
						}

						FREE(tmpSynthTab);
					}
				}

				/* extract all synthetic of each portfolio (with HierPtfId) */
				if ((ret = DBA_ExtractHierEltRecWithFilterSt(synthHierHead, A_PtfSynth,
															FALSE, FIN_FilterPtfSynthChild,
															childTab[i], NULLFCT,
															&tmpSynthNbr, &tmpSynthTab)) != RET_SUCCEED)
				{
					FREE(synthTab);
					FREE(childTab);
					FREE_DYNST(parIdPtr, Io_Id);
					return(ret);
				}

				/* REF11087 - RAK - 050407 - in case of synthNbr+tmpSynthNbr == 0      */
				/* REALLOC return a NULL pointer and we go out which isn't a good idea */
				if (tmpSynthNbr > 0)
				{
					if ((synthTab = (DBA_DYNFLD_STP*) REALLOC(synthTab,
						(synthNbr+tmpSynthNbr)*sizeof(DBA_DYNFLD_STP)))== NULL)
					{
						FREE(synthTab);
						FREE(childTab);
						FREE_DYNST(parIdPtr, Io_Id);
						return(ret);
					}

					for (j=0; j<tmpSynthNbr; j++)
					{
                        /* replace Ptfid in synthetic by HierPtfId */
                        SET_ID(tmpSynthTab[j], A_PtfSynth_PtfId, GET_ID(parPtfPtr, A_Ptf_Id));

                        /* keep modified synthetics in array */
                        synthTab[synthNbr] = tmpSynthTab[j];
                        ++synthNbr;
					}

					FREE(tmpSynthTab);
				}
			}
		}

		FREE_DYNST(parIdPtr, Io_Id);
	}

	FREE(childTab);

	/* merge */
	if (synthTab != NULLDYNSTPTR && synthNbr > 0)
	{
		if(synthNbr > 1)
		{
			/* REF7785 - YST - 021025 - new filter FIN_CmpPtfSynthPtfNatDetailDate2 created */
			TLS_Sort((char*) synthTab, synthNbr, sizeof(DBA_DYNFLD_STP),
					 (TLS_CMPFCT *)FIN_CmpPtfSynthPtfNatDetailDate2 /*FIN_CmpPtfSynthNatDetailDate*/, /* REF7264 - LJE - 020131 */
					 (PTR**)NULL, SortRtnTp_None);
		}

		ret = FIN_MergeHierPtfSynth(synthHierHead, synthTab, synthNbr);
		FREE(synthTab);
	}

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_ConvertPtfSynthToDomCurr()
**
**  Description :
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   REF9834 - RAK - 040218
**
*************************************************************************/
STATIC RET_CODE FIN_ConvertPtfSynthToDomCurr(DBA_DYNFLD_STP	 domainPtr,
											 DBA_DYNFLD_STP	 *ptfTab,
											 int				 ptfNbr,
											 DBA_HIER_HEAD_STP synthHierHead)
{
	DBA_DYNFLD_STP	*synthTab = NULLDYNSTPTR;
	int				i, j, j0=0, synthNbr = 0;
	RET_CODE		ret=RET_SUCCEED;

	for (i=0, j=0, synthNbr=0; i<ptfNbr; i++)
	{
		if (GET_ID(ptfTab[i], A_Ptf_CurrId) != GET_ID(domainPtr, A_Domain_CurrId))
		{
			if (synthTab == NULLDYNSTPTR && synthNbr == 0)
			{
				/* Extract all portfolios */
				if ((ret = DBA_ExtractHierEltRec(synthHierHead, A_PtfSynth,
												FALSE, NULLFCT,
												/* REF6912 - CSY - 010810: sort also by global lines */
												FIN_CmpPtfSynthPtfDateGlobal,
												&synthNbr, &synthTab)) != RET_SUCCEED)
				{
						return(ret);
				}
			}

			/* j is on first position of next portfolio (0 at first time) */
			while (j<synthNbr &&
				   GET_ID(synthTab[j], A_PtfSynth_PtfId) <= GET_ID(ptfTab[i], A_Ptf_Id))
			{
				if (GET_ID(synthTab[j], A_PtfSynth_PtfId) == GET_ID(ptfTab[i], A_Ptf_Id) &&
					GET_ID(synthTab[j], A_PtfSynth_CurrId) != GET_ID(domainPtr,A_Domain_CurrId))
				{
					/* REF6912 - CSY - 010809 */
					if(IS_NULLFLD(synthTab[j], A_PtfSynth_MktSegtId) == TRUE
													&&
					IS_NULLFLD(synthTab[j], A_PtfSynth_InstrId) == TRUE)
					{
						/* memorize position of the global line:
						   update cumuls of currency real/unreal P&L amounts */
						j0 = j;
					}

					/* REF6912 - CSY - 010810: manage return code */
					if ((ret = FIN_ConvertPtfSynthCurr(synthTab[j],
													   GET_ID(domainPtr, A_Domain_CurrId))) != RET_SUCCEED)
					{
						FREE(synthTab);
						return (ret);
					}

					if(IS_NULLFLD(synthTab[j], A_PtfSynth_MktSegtId) == FALSE   /* detail line */
													||
					   IS_NULLFLD(synthTab[j], A_PtfSynth_InstrId) == FALSE)
					{
						if (j == j0+1)  /* there must be at least one detail line to reset the cumul */
						{
							/* reset 4 currency counters of the global line to zero */
							FIN_CumulPtfSynthCurrField(synthTab[j0], synthTab[j], TRUE);
						}

						if (j > j0) /* do not call this function if synthTab[j] is a global synth. (j==j0) */
						{
							/* cumul detail lines currency field amounts (j) in global line (j0) */
							FIN_CumulPtfSynthCurrField(synthTab[j0], synthTab[j], FALSE);
						}
					}
				}
				j++;
			}
		}
	}

	FREE(synthTab);
	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_GroupPtfSynthToGeneralFreq()
**
**  Description :
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   REF9834 - RAK - 040218
**
*************************************************************************/
STATIC RET_CODE FIN_GroupPtfSynthToGeneralFreq(DBA_DYNFLD_STP	 domainPtr,
											   DBA_DYNFLD_STP	 *ptfTab,
											   int				 ptfNbr,
											   DBA_HIER_HEAD_STP synthHierHead,
											   FIN_RET_FREQ_STP  commFreqStp)
{
	RET_CODE			ret=RET_SUCCEED;
	int					i, j, synthNbr=0, ptfSynthNbr, begin;
	DBA_DYNFLD_STP		*synthTab=NULLDYNSTPTR;
	COMPA_FREQ_ENUM     compaFreqEn;
	SMALLINT_T			ptfFreq;
	FREQUNIT_ENUM		ptfFreqUnit;

	/* Read loaded, computed and groupped synthetics */
	if ((ret = DBA_ExtractHierEltRec(synthHierHead, A_PtfSynth,
									 FALSE, NULLFCT,
									 FIN_CmpPtfSynthPtfNatDetailDate,
									&synthNbr, &synthTab)) != RET_SUCCEED)
	{
		return(ret);
	}

	if ((ret = DATE_CrystalDates(GET_DATETIME(domainPtr, A_Domain_InterpFromDate),
								 GET_DATETIME(domainPtr, A_Domain_InterpTillDate),
								 (TINYINT_T) commFreqStp->freq, commFreqStp->freqUnit, FALSE,
								 &(commFreqStp->crystDates),
								 &(commFreqStp->crystDatesNbr), NULL, NULL,
								 (DATE_POSI_ENUM)EndOf,         /* REF5358 - CSY - 010131: new arg EndOf */
								 nullptr, nullptr)) != RET_SUCCEED) 
	{
		FREE(synthTab);
		return(ret);
	}

	for (i=0, j=0; i<ptfNbr && j<synthNbr; i++)
	{
		ptfFreq     = GET_SMALLINT(ptfTab[i], A_Ptf_RetFreq);
		ptfFreqUnit = (FREQUNIT_ENUM) GET_ENUM(ptfTab[i], A_Ptf_RetFreqUnitEn);

	    /* Select current portfolio's synthetics and construct array */
	    ptfSynthNbr = 0;
	    begin = -1;

	    /* j is on first position of next portfolio (0 at first time) */
	    while (j<synthNbr &&
		       GET_ID(synthTab[j], A_PtfSynth_PtfId) <= GET_ID(ptfTab[i], A_Ptf_Id))
	    {
			if (GET_ID(synthTab[j], A_PtfSynth_PtfId) == GET_ID(ptfTab[i],A_Ptf_Id))
			{
				if (begin == -1)
					begin = j;
		        ptfSynthNbr++;
			}
		    j++;
	    }

	    if (begin > -1 && ptfSynthNbr > 0)
		{
			ret = RET_SUCCEED;

			/* REF8347 - YST - 021106 - add ptfConsRule */
            compaFreqEn = FIN_VerifPtfFreqCommFreq(ptfFreqUnit, ptfFreq,
									               commFreqStp->freqUnit, commFreqStp->freq,
                                                   (PTFCONSRULE_ENUM)GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn));

			if (compaFreqEn == compaFreq_Group ||
                (compaFreqEn == compaFreq_Ok && GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) == PtfConsRule_Merged))
			{
	    		/* Replace portfolio's synthetics by common frequency synthetics */
			    ret = FIN_GroupPtfSynthByFreq(synthHierHead, commFreqStp, &(synthTab[begin]), ptfSynthNbr);
			}
			else if (compaFreqEn == compaFreq_Impossible)
				ret = RET_GEN_ERR_INVARG;
		 }
	}

	FREE(synthTab);
	return(ret);
}


/************************************************************************
**
**  Function    :   FIN_CompHistPerfFirstDate()
**
**  Description :   Don't use synthetics valid after PerfFirstStroredDate for computation
**
**  Arguments   :   pspTab			Array of PSP
**					pspNbr			Number of elements in pspTab
**					synthHierHead	Hierarchy
**					synthTab		Array of filtered Ptf Synth (returned)
**					synthNbr		Number of filtered synthTab elements (returned)
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   REF9834 - TEB - 040617
**
**  Modification:
**
*************************************************************************/
STATIC RET_CODE FIN_CompHistPerfFirstDate(DBA_DYNFLD_STP	*pspTab,
										  int				pspNbr,
										  DBA_HIER_HEAD_STP synthHierHead,
										  DBA_DYNFLD_STP	**synthTab,
										  int				*synthNbr)
{
	int				i, j, delPtfSynthTotNbr=0, synthSortNbr=0;
	RET_CODE		ret=RET_SUCCEED;
	DBA_DYNFLD_STP	*synthSortTab=NULLDYNSTPTR;

	/*
	 * Use an other array, sorted by ptf, psp and date
	 * Overvhise the loop won t work.
	 * ------------------------------------------------- */
	if ((ret = DBA_ExtractHierEltRec(synthHierHead, A_PtfSynth,
									 FALSE, NULLFCT, FIN_CmpPtfSynthPtfPspDate,
									 &synthSortNbr, &synthSortTab)) != RET_SUCCEED)
	{
		return(ret);
	}

    for (i=0; i<pspNbr; i++)
    {
        if (synthSortNbr > 0)
        {
			j = 0;

			/* Match PtfSynth with PSP on id */
			/* ----------------------------- */
			while (j < synthSortNbr && CMP_DYNFLD(synthSortTab[j], pspTab[i],
												 A_PtfSynth_PSPId, A_PerfStorageParam_Id, IdType) != 0)
				j++;

			/*
			 * Use the std perf first stored date from psp
             * Don't use synthetics valid after PerfFirstStoredDate for computation
			 * -------------------------------------------------------------------- */
            while (j < synthSortNbr)
			{
				if (CMP_DYNFLD(synthSortTab[j], pspTab[i],
							   A_PtfSynth_PSPId, A_PerfStorageParam_Id, IdType) == 0 &&
                   IS_NULLFLD(pspTab[i], A_PerfStorageParam_StdPerfFirstStoredDate) == FALSE &&
                   DATETIME_CMP(GET_DATETIME(synthSortTab[j], A_PtfSynth_FinalDate), GET_DATETIME(pspTab[i], A_PerfStorageParam_StdPerfFirstStoredDate)) > 0)
				{
					/* Delete synthetic data in hierarchy */
					/* ---------------------------------- */
					if ((ret = DBA_DelAndFreeHierEltRec(synthHierHead, A_PtfSynth, synthSortTab[j])) != RET_SUCCEED)
					{
						FREE(synthSortTab);
						return(ret);
					}

					delPtfSynthTotNbr++;
				}
                j++;
            }
		}
	}

	/* If synthetic data was deleted then extract again */
	/* ------------------------------------------------ */
    if (delPtfSynthTotNbr > 0)
    {
		FREE((*synthTab));

        if ((ret = DBA_ExtractHierEltRec(synthHierHead, A_PtfSynth,
			    						 FALSE, NULLFCT, FIN_CmpPtfSynthPtfDate,
				    					 synthNbr, synthTab)) != RET_SUCCEED)
        {
			FREE(synthSortTab);
			return(ret);
	    }
	}

	FREE(synthSortTab);
	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_GroupPtfSynthToDomGridDetLvl()
**
**  Description :
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   REF9834 - RAK - 040218
**
*************************************************************************/
STATIC RET_CODE FIN_GroupPtfSynthToDomGridDetLvl(DBA_DYNFLD_STP	domainPtr,
											 DBA_DYNFLD_STP	*ptfTab,
											 int			ptfNbr,
											 DBA_HIER_HEAD_STP synthHierHead,
											 RETURN_GRID_INFO_STP gridInfoStp)
{
	RET_CODE			ret=RET_SUCCEED;
	PTFRETDETLVL_ENUM   domRetDetLevelEn=PtfRetDetLvl_Grid;	/* because this fct is only called if A_Domain_RetDetLevelEn is Grid */
	int					i, j, synthNbr=0, ptfSynthNbr, begin;
	DBA_DYNFLD_STP		*synthTab=NULLDYNSTPTR;

	/* Read loaded and computed instruments synthetics (no global) */
	if ((ret = DBA_ExtractHierEltRec(synthHierHead, A_PtfSynth, FALSE,
									 FIN_FilterDetSynth, FIN_CmpPtfSynthPtfDateNat,
									 &synthNbr, &synthTab)) != RET_SUCCEED)
	{
		return(ret);
	}

	for (i=0, j=0; i<ptfNbr && j<synthNbr; i++)
	{
		/* Group portfolio's synthetics to domain detail level */
		if (domRetDetLevelEn != GET_ENUM(ptfTab[i], A_Ptf_RetDetLevelEn))
		{
			/* Select current portfolio's synthetics and construct array */
			ptfSynthNbr = 0;
			begin = -1;

			/* j is on first position of next portfolio (0 at first time) */
			while (j<synthNbr &&
				   GET_ID(synthTab[j], A_PtfSynth_PtfId) <= GET_ID(ptfTab[i], A_Ptf_Id))
			{
				if (GET_ID(synthTab[j], A_PtfSynth_PtfId) == GET_ID(ptfTab[i], A_Ptf_Id))
				{
					if (begin == -1)
						begin = j;
					ptfSynthNbr++;
				}
				j++;
			}

			if (begin > -1 && ptfSynthNbr > 0)
			{
				ret = FIN_GroupPtfSynthByDetLvl(domainPtr, synthHierHead,
							(PTFRETDETLVL_ENUM)GET_ENUM(ptfTab[i], A_Ptf_RetDetLevelEn), /* REF7264 - LJE - 020131 */
							domRetDetLevelEn,  &(synthTab[begin]), ptfSynthNbr, gridInfoStp, (PA_INFO_STP)NULL); /* REF9834 - TEB - 041202 */
			}
		}
	}

	FREE(synthTab);
	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_GetGridMktSgtWithoutTotal()
**
**  Description :   Return market segment for received grid (except total)
**
**  Arguments   :   gridId      grid identifier
**                  mktSgtTab   market segment tab pointer (to fill)
**                  mktSgtNbr   market segment number pointer (to fill)
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   REF4263 - RAK - 000414
**
*************************************************************************/
STATIC RET_CODE FIN_GetGridMktSgtWithoutTotal(ID_T           gridId,
                                              DBA_DYNFLD_STP **mktSgtTab,
                                              int            *mktSgtNbr)
{
    RET_CODE        ret=RET_SUCCEED;
    DBA_DYNFLD_STP  admArg=NULLDYNST, *tmpMktSgtTab=NULLDYNSTPTR;
    int             i, tmpMktSgtNbr=0;
    FLAG_T          dimGrid;

    *mktSgtNbr = 0;
    *mktSgtTab = NULLDYNSTPTR;

    if ((admArg = ALLOC_DYNST(Adm_Arg)) == NULLDYNST)
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    /* Extract all grid market segments and sort them */
    SET_ID(admArg, Adm_Arg_Id, gridId);

    ret = DBA_Select2(MktSegt, UNUSED, Adm_Arg, admArg,
			          S_MktSegt, &tmpMktSgtTab, UNUSED, UNUSED,
			          &tmpMktSgtNbr, UNUSED, UNUSED);

    FREE_DYNST(admArg, Adm_Arg);

    if (tmpMktSgtNbr > 0 && ret == RET_SUCCEED)
    {
        if (((*mktSgtTab) = (DBA_DYNFLD_STP*)
                            CALLOC(tmpMktSgtNbr, sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR)
        {
            DBA_FreeDynStTab(tmpMktSgtTab, tmpMktSgtNbr, S_MktSegt);
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        for (i=0, dimGrid=1; i<tmpMktSgtNbr && dimGrid==1; i++)
        {
	        if (IS_NULLFLD(tmpMktSgtTab[i], S_MktSegt_AbcissaListId) == FALSE &&
			    IS_NULLFLD(tmpMktSgtTab[i], S_MktSegt_OrdinateListId) == FALSE)
            {
		        dimGrid=2;
            }
        }

        for (i=0; i<tmpMktSgtNbr; i++)
        {
            /* TOTAL -> just free and don't return */
            if ((dimGrid==1 && IS_NULLFLD(tmpMktSgtTab[i], S_MktSegt_AbcissaListId)==TRUE) ||
			    (dimGrid==2 && (IS_NULLFLD(tmpMktSgtTab[i], S_MktSegt_AbcissaListId)==TRUE  ||
                            IS_NULLFLD(tmpMktSgtTab[i], S_MktSegt_OrdinateListId)==TRUE)))
            {
                FREE_DYNST(tmpMktSgtTab[i], S_MktSegt);
            }
            else
            {
                (*mktSgtTab)[(*mktSgtNbr)] = tmpMktSgtTab[i];
                (*mktSgtNbr)++;
            }
        }

        FREE(tmpMktSgtTab);
    }

    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_GetPtfFreqInfoForSynthAdmin()
**
**  Description :   Get current portfolio frequency and crystallised dates
**
**  Arguments   :   ptfPtr     	   portfolio structure pointer
**  		    domainPtr	   domain structure pointer
**                  oldFreqPtr	   pointer on last frequency
**                  oldFreqUnitPtr pointer on last frequency unit
**		    ptfFreqStp 	   pointer on portfolio frequency informations
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   DVP261 - RAK - 961206
**  Modif    	:   DVP261 - RAK - 961212
**  Modif    	:   DVP479 - RAK - 970521
**  Modif    	:   REF1465 - RAK - 980323
**  Modif    	:   REF1402 - RAK - 981007
**  Modif    	:   REF5077 - CSY - 000926
**  Modif    	:   REF5244 - CSY - 000926: improve management of event sched,
**                                          manage deleteFlg
**                  REF5244 - CSY - 001011: suppress FIN_GetPtfFreqInfo, create
**                                          FIN_GetPtfFreqInfoForSynthAdmin, FIN_GetPtfFreqInfoForReturn
**                  REF11363 - TEB - 050823
**
*************************************************************************/
STATIC RET_CODE FIN_GetPtfFreqInfoForSynthAdmin(DBA_DYNFLD_STP	ptfPtr,
			                                   DBA_DYNFLD_STP 	domainPtr,
                                               DBA_HIER_HEAD_STP hierHead,   /* PMSTA-50467 - JBC - 221112 */
			                                   SMALLINT_T		*oldFreqPtr,
			                                   FREQUNIT_ENUM	*oldFreqUnitPtr,
			                                   FIN_RET_FREQ_STP	ptfFreqStp, /* CSY - 001011: synthAdminFlg suppressed */
				                               RETURN_ARG_STP   retArgStp)
{
	DATETIME_T	    fromDate, tillDate, synthLastFinalDate, recalcDate;;
	RET_CODE 	    ret=RET_SUCCEED;
	COMPDATA_ENUM 	compDataEn=(COMPDATA_ENUM) GET_ENUM(domainPtr, A_Domain_CompDataEn);
	DBA_DYNFLD_STP  *synthTab=NULLDYNSTPTR, lastPtfSynth=NULLDYNST;
	int		        ptfSynthNbr=0;
    char            adjustEndOfMonthFlg; /* REF5244 - CSY - 001011: used only in synth admin,
                                 true when need to adjust the variable fromDate, set to false
                                 when fromDate is adjusted to end of month */
    DBA_DYNFLD_STP 	/*lastPtfSynth=NULLDYNST, REF5260 - RAK - 001114*/ firstPtfSynth=NULLDYNST,
			        getEventSched=NULLDYNST, eventSchedPtr=NULLDYNST;
	DICT_T	        ptfEntDictId;
	RET_CODE		retLast=RET_DBA_ERR_NODATA, /* REF5244 - CSY - 000927 */
                    retFirst=RET_SUCCEED;

	/* Get current portfolio frequency and crystallised dates */
	ptfFreqStp->freq     = (TINYINT_T) GET_SMALLINT(ptfPtr, A_Ptf_RetFreq);
	ptfFreqStp->freqUnit = (FREQUNIT_ENUM) GET_ENUM(ptfPtr, A_Ptf_RetFreqUnitEn);

	/* DVP479 - RAK - 970521 */
	fromDate = GET_DATETIME(domainPtr, A_Domain_InterpFromDate);
	tillDate = GET_DATETIME(domainPtr, A_Domain_InterpTillDate);

    adjustEndOfMonthFlg = TRUE;

	memset(&(ptfFreqStp->replaceDate), 0, sizeof(DATETIME_T));
	ptfFreqStp->eventSchedFlg = FALSE;
    ptfFreqStp->deleteFlg = TRUE; /* REF5244 - CSY - 001004: initialisation to TRUE */

	/* PMSTA02013 - RAK - 071112 */
	RETURNINPARENTPTFRULE_ENUM	returnInParPtfRuleEn=ReturnInParentPtfRule_Children;

    if (static_cast<LOADHIERPTF_ENUM> GET_ENUM(domainPtr, A_Domain_LoadHierFlg) == LoadHierPtf_IntermediateHierarchy)
    {
        returnInParPtfRuleEn = ReturnInParentPtfRule_Parent;
    }
    else
    {
        GEN_GetApplInfo(ApplReturnInParentPtfRule, &returnInParPtfRuleEn);
    }

	memset(&synthLastFinalDate, 0, sizeof(DATETIME_T));
	memset(&recalcDate, 0, sizeof(DATETIME_T));

    if ((lastPtfSynth = ALLOC_DYNST(S_PtfSynth)) == NULLDYNST)
	{MSG_RETURN(RET_MEM_ERR_ALLOC);}

	if ((firstPtfSynth = ALLOC_DYNST(S_PtfSynth)) == NULLDYNST)
	{
		FREE_DYNST(lastPtfSynth, S_PtfSynth);
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

    /* REF5077 - CSY - 000926: event scheduler management */
    /* ---------------------- */
	/* VERIFY EVENT SCHEDULER */
	/* ---------------------- */
	if ((getEventSched = ALLOC_DYNST(S_EventSched)) == NULLDYNST)
	{
		FREE_DYNST(lastPtfSynth, S_PtfSynth);
		FREE_DYNST(firstPtfSynth, S_PtfSynth);
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	if ((eventSchedPtr = ALLOC_DYNST(A_EventSched)) == NULLDYNST)
	{
		FREE_DYNST(lastPtfSynth, S_PtfSynth);
		FREE_DYNST(firstPtfSynth, S_PtfSynth);
		FREE_DYNST(getEventSched, S_EventSched);
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	DBA_GetDictId(Ptf, &ptfEntDictId);
	SET_DICT(getEventSched, S_EventSched_EntityDictId, ptfEntDictId);
	SET_ID(getEventSched,   S_EventSched_ObjId, GET_ID(ptfPtr, A_Ptf_Id));
	SET_ENUM(getEventSched, S_EventSched_NatEn,    (ENUM_T) EventSchedNat_SynthAdmin);

	ret = DBA_Get2(EventSched, UNUSED, S_EventSched,
	    	    getEventSched, A_EventSched, &eventSchedPtr,
			    UNUSED, UNUSED, UNUSED);

	if (ret == RET_SUCCEED)
	{
		ptfFreqStp->eventSchedFlg = TRUE;
        /* REF5244 - CSY - 001004:
        deleteFlg must equals TRUE if event sched exists
        (already initialised to true) */
    }

	/* REF1402 */
	if (DATETIME_CMP(GET_DATETIME(domainPtr, A_Domain_InterpFromDate),
			         GET_DATETIME(domainPtr, A_Domain_InterpTillDate)) == 0)
	{
        /* If no last synthetic (so no synthetic), A_Ptf_SynthLastFinalDate is NULL */
        /* update retLast because it is used several times in following code. */
        if (IS_NULLFLD(ptfPtr, A_Ptf_SynthLastFinalDate) == FALSE)
            retLast = RET_SUCCEED;
        else
            retLast = RET_DBA_ERR_NODATA;

        if (retLast == RET_SUCCEED)
	    {
 			/* PMSTA02013 - RAK - 071112- For children verify the synthetic last date. */
			/* We don't know if the stored A_PtfSynthLastFinalDate is the parent final  */
			/* date or children final date  (we update it to the last computation for   */
			/* the maintenance of event_sched by proc)                                  */
			synthLastFinalDate = GET_DATETIME(ptfPtr, A_Ptf_SynthLastFinalDate);
			recalcDate         = GET_DATETIME(ptfPtr, A_Ptf_SynthRecalcDate);

			if ((returnInParPtfRuleEn == ReturnInParentPtfRule_Parent ||
				 returnInParPtfRuleEn == ReturnInParentPtfRule_ParentUsingHierPSP) &&
				IS_NULLFLD(ptfPtr, A_Ptf_ParentPortId) == FALSE)
			{
				SET_ID(lastPtfSynth, S_PtfSynth_PtfId, GET_ID(ptfPtr, A_Ptf_Id));

				retLast = DBA_Get2(PtfSynth, DBA_ROLE_PTFSYNTH_ALL, S_PtfSynth, lastPtfSynth,
								   S_PtfSynth, &lastPtfSynth, UNUSED, UNUSED, UNUSED);

				if (RET_GET_LEVEL(retLast) == RET_LEV_ERROR)
				{
					SYSNAME_T entSqlName;
	    			FREE_DYNST(lastPtfSynth, S_PtfSynth);
	    			FREE_DYNST(firstPtfSynth, S_PtfSynth);
					FREE_DYNST(getEventSched, S_EventSched);
					FREE_DYNST(eventSchedPtr, A_EventSched);
					strcpy(entSqlName, DBA_GetDictEntitySqlName(PtfSynth));
					MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO,
						 entSqlName, GET_ID(ptfPtr, A_Ptf_Id));
					return(RET_DBA_ERR_NODATA);
				}
				else if (retLast == RET_DBA_INFO_NODATA)
				{
					retLast = RET_DBA_ERR_NODATA;
				}

				/* re-init LastFinalDate and recalc date */
				if (retLast != RET_DBA_ERR_NODATA)	/* perhaps children haven't synthetics */
				{
					synthLastFinalDate = GET_DATETIME(lastPtfSynth, S_PtfSynth_FinalDate);

					if (GET_ENUM(lastPtfSynth, S_PtfSynth_PersistEn) == PersistNat_Persist)
					{
						recalcDate = GET_DATETIME(lastPtfSynth, S_PtfSynth_FinalDate);
					}
					else
					{
						recalcDate = GET_DATETIME(lastPtfSynth, S_PtfSynth_InitialDate);
					}
				}
			}

			if (retLast == RET_SUCCEED)
			{
				if (ptfFreqStp->eventSchedFlg == TRUE &&
					(DATETIME_CMP(GET_DATETIME(eventSchedPtr, A_EventSched_FromDate),
                                  synthLastFinalDate)>0)&&
					(DATETIME_CMP(GET_DATETIME(eventSchedPtr, A_EventSched_FromDate),
                                  GET_DATETIME(domainPtr, A_Domain_InterpTillDate))<0))
				{
					ret = DBA_Delete2(EventSched, UNUSED, S_EventSched, getEventSched, UNUSED, UNUSED, UNUSED);

					ptfFreqStp->eventSchedFlg = FALSE;
				}

				if ((DATETIME_CMP(synthLastFinalDate, GET_DATETIME(ptfPtr, A_Ptf_SynthRecalcDate)) == 0) &&
					(ptfFreqStp->eventSchedFlg == FALSE
					||
					(ptfFreqStp->eventSchedFlg == TRUE &&
					(DATETIME_CMP(GET_DATETIME(eventSchedPtr, A_EventSched_FromDate), synthLastFinalDate)>0))))
				{
					ptfFreqStp->deleteFlg = FALSE;
				}

				if ((DATETIME_CMP(GET_DATETIME(domainPtr, A_Domain_InterpTillDate), synthLastFinalDate) <= 0) &&
					(ptfFreqStp->eventSchedFlg == FALSE))
				{
	    			FREE_DYNST(firstPtfSynth, S_PtfSynth);
					FREE_DYNST(lastPtfSynth, S_PtfSynth);
	    			FREE_DYNST(getEventSched, S_EventSched);
					FREE_DYNST(eventSchedPtr, A_EventSched);
	    			return(RET_GEN_ERR_INVALIDATE);
				}

				fromDate = recalcDate;

				adjustEndOfMonthFlg = FALSE;	/* We already have last crystalisation date ... */
				ret = RET_SUCCEED;
			}
	    }
	    else
	    {
            ptfFreqStp->deleteFlg = FALSE; /* REF5244 - CSY - 001005 */
		    fromDate.date = DATE_Move(fromDate.date, -1, Year);	 /* REF2876 */
		    ret = RET_SUCCEED;
	    }
	}

   if (ptfFreqStp->eventSchedFlg == TRUE
        &&
        /* REF5244 - CSY - 000926 if domain from and till dates are equal,
        do nothing
            - if event sched is after lastPtfSynth final_d
            - or if lastPtfSynth has not been found */
        !(  /* watch out the "!" */
            (DATETIME_CMP(GET_DATETIME(domainPtr, A_Domain_InterpFromDate),
			              GET_DATETIME(domainPtr, A_Domain_InterpTillDate)) == 0) &&
            (
                (
                    /* REF5245 - RAK - 001114 */
                    /* lastPtfSynth is replace by A_Ptf_SynthLastFinalDate and A_Ptf_SynthRecalcDate */
                    retLast == RET_SUCCEED &&
                    (DATETIME_CMP(GET_DATETIME(eventSchedPtr, A_EventSched_FromDate),
								  synthLastFinalDate) > 0))
                ||
                /* no lastPtfSynth means there is no synth at all
                (if there were at least one, there would be a last one) */
                retLast != RET_SUCCEED)))
    {
	    SET_ID(firstPtfSynth, S_PtfSynth_PtfId, GET_ID(ptfPtr, A_Ptf_Id));

		/* REF1402 - RAK - 990205 - WRONG
		SET_ID(firstPtfSynth, S_PtfSynth_PtfPosSetId,
		    GET_ID(domainPtr, A_Domain_PortPosSetId)); */
		SET_DATETIME(firstPtfSynth, S_PtfSynth_InitialDate,
		    GET_DATETIME(eventSchedPtr, A_EventSched_FromDate));

		retFirst = DBA_Get2(PtfSynth, UNUSED, S_PtfSynth, firstPtfSynth,
			            S_PtfSynth, &firstPtfSynth, UNUSED, UNUSED, UNUSED);

		if (retFirst == RET_SUCCEED)
		{
            /* REF5244 - CSY - 000927: comparison done with the firstPtfSynth  */
		    /* Get first date between domain from date and first synthetic date */
			if (DATETIME_CMP(GET_DATETIME(firstPtfSynth, S_PtfSynth_InitialDate), fromDate) <= 0)
			{
				fromDate = GET_DATETIME(firstPtfSynth, S_PtfSynth_InitialDate);
				adjustEndOfMonthFlg = FALSE;

				if (compDataEn == CompData_NewPermanent)
			    		compDataEn = CompData_ReplacePermanent;
		    		else if (compDataEn == CompData_NewNonPermanent)
			   		 compDataEn = CompData_ReplaceNonPermanent;
			}
			else if (DATETIME_CMP(GET_DATETIME(firstPtfSynth, S_PtfSynth_InitialDate),
				GET_DATETIME(domainPtr, A_Domain_InterpTillDate)) < 0 && (compDataEn == CompData_NewPermanent ||
			    		compDataEn == CompData_NewNonPermanent))
			{
				if (DATETIME_CMP(GET_DATETIME(eventSchedPtr, A_EventSched_FromDate),
						GET_DATETIME(domainPtr, A_Domain_InterpFromDate)) >= 0)
					ptfFreqStp->replaceDate = GET_DATETIME(firstPtfSynth, S_PtfSynth_InitialDate);
				else  /* event sched avant from (mais firstPtfSynth apres from) */
				{
					if (compDataEn == CompData_NewPermanent)
			    			compDataEn = CompData_ReplacePermanent;
		    		else if (compDataEn == CompData_NewNonPermanent)
			   		 	    compDataEn = CompData_ReplaceNonPermanent;
				}
			}

            /* look for the last only
                - if we found the first !
                - and if first.initial_d <= domain.till_d */
            /* SET_NULL_DYNST(firstPtfSynth, S_PtfSynth); REF5245 - RAK - 001114 */

	        /* Get last synthetic date and recompute all synthetic until this date */
	        if (DATETIME_CMP(GET_DATETIME(firstPtfSynth, S_PtfSynth_InitialDate),
				GET_DATETIME(domainPtr, A_Domain_InterpTillDate)) < 0)
            {
		        /* if domain from and till date are equal, get lastPtfSynth is already done */
		        if (DATETIME_CMP(GET_DATETIME(domainPtr, A_Domain_InterpFromDate),
		            GET_DATETIME(domainPtr, A_Domain_InterpTillDate)) != 0)
		        {
                    /* If no last synthetic (so no synthetic), A_Ptf_SynthLastFinalDate is NULL */
                    /* update retLast because it is used several times in following code. */
                    if (IS_NULLFLD(ptfPtr, A_Ptf_SynthLastFinalDate) == FALSE)
                        retLast = RET_SUCCEED;
                    else
                        retLast = RET_DBA_ERR_NODATA;
		        }

                /* REF5260 - RAK - 001114 */
                /* lastPtfSynth is replace by A_Ptf_SynthLastFinalDate and A_Ptf_SynthRecalcDate */
	            if (retLast == RET_SUCCEED &&
                    DATETIME_CMP(synthLastFinalDate, tillDate) > 0)
	            {
                    tillDate = synthLastFinalDate;

                    /* REF5260 - RAK - 001114 */
                    /* lastPtfSynth is replace by A_Ptf_SynthLastFinalDate and A_Ptf_SynthRecalcDate */
                    /* if these two dates are same, the last synthetic is persistent */
		            /* if (GET_ENUM(lastPtfSynth, S_PtfSynth_PersistEn) == PersistNat_NoPersist) */
                    if (DATETIME_CMP(synthLastFinalDate, recalcDate) != 0)
               		{
			            if (compDataEn == CompData_NewPermanent)
				            compDataEn = CompData_NewNonPermanent;
			            else if (compDataEn == CompData_ReplacePermanent)
				            compDataEn = CompData_ReplaceNonPermanent;
		            }
		            else 						/* Persist */
		            {
			            if (compDataEn == CompData_NewNonPermanent)
				            compDataEn = CompData_NewPermanent;
			            else if (compDataEn == CompData_ReplaceNonPermanent)
				            compDataEn = CompData_ReplacePermanent;
		            }

		            /* Update because of FIN_ReturnProcess() function test */
		            SET_ENUM(domainPtr, A_Domain_CompDataEn, (ENUM_T) compDataEn);
	            }
            }
		}
        else if (compDataEn == CompData_NewPermanent ||
            compDataEn == CompData_NewNonPermanent) /* REF5244 - CSY - 001005 */
            /* if first synth which final_d >= event_sched.from_d is not found,
            there is no synthetic to delete (and replace) if compute data parameter is  "New" */
            {ptfFreqStp->deleteFlg = FALSE;}
        else if (DATETIME_CMP(fromDate,
            GET_DATETIME(eventSchedPtr, A_EventSched_FromDate)) >= 0)
        /* first synth which final_d >= event_sched.from_d not found
           and replace mode */
            {ptfFreqStp->deleteFlg = FALSE;}

    } /* end if event sched */

	/* In case of replace mode, set from date to current synthetic from date */
	/* and till date to currency synthetic till date */
	if (ptfFreqStp->freqUnit != FreqUnit_Day &&
	(compDataEn == CompData_ReplaceNonPermanent ||
	 compDataEn == CompData_ReplacePermanent) &&
     (ptfFreqStp->eventSchedFlg == FALSE)) /* CSY - 000926: dates already adjusted if event sched */
	{
        SET_NULL_DYNST(firstPtfSynth, S_PtfSynth); /* REF5245 - RAK - 001114 */
	    SET_ID(firstPtfSynth,       S_PtfSynth_PtfId,       GET_ID(ptfPtr, A_Ptf_Id));
		SET_DATETIME(firstPtfSynth, S_PtfSynth_InitialDate, fromDate);
		/* REF1402 - RAK - 990205 - WRONG
		SET_ID(firstPtfSynth, S_PtfSynth_PtfPosSetId,
		    GET_ID(domainPtr, A_Domain_PortPosSetId)); */

		retFirst = DBA_Get2(PtfSynth, UNUSED, S_PtfSynth, firstPtfSynth,
			       	    S_PtfSynth, &firstPtfSynth, UNUSED, UNUSED, UNUSED);

        /* REF5244 - CSY - 001005: if no firstPtfSynth found,
        that means there is nothing after fromDate */
        if (retFirst != RET_SUCCEED)
            ptfFreqStp->deleteFlg = FALSE;

		if (RET_GET_LEVEL(retFirst) == RET_LEV_ERROR)
	    {
		    SYSNAME_T entSqlName;
	    	FREE_DYNST(lastPtfSynth, S_PtfSynth);
	    	FREE_DYNST(firstPtfSynth, S_PtfSynth);
	    	FREE_DYNST(getEventSched, S_EventSched);
	    	FREE_DYNST(eventSchedPtr, A_EventSched);
		    strcpy(entSqlName, DBA_GetDictEntitySqlName(PtfSynth));
		    MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO,
				 entSqlName, GET_ID(ptfPtr, A_Ptf_Id));
		    return(RET_DBA_ERR_NODATA);
		}

		if (retFirst == RET_SUCCEED &&
		    DATETIME_CMP(GET_DATETIME(firstPtfSynth, S_PtfSynth_InitialDate), fromDate) < 0 &&
		    DATETIME_CMP(GET_DATETIME(firstPtfSynth, S_PtfSynth_FinalDate), fromDate) > 0)
        {
			fromDate = GET_DATETIME(firstPtfSynth, S_PtfSynth_InitialDate);
            adjustEndOfMonthFlg = FALSE;
        }

		if (retFirst == RET_SUCCEED &&
		    IS_NULLFLD(firstPtfSynth, S_PtfSynth_FinalDate) == FALSE &&
		    DATETIME_CMP(tillDate, GET_DATETIME(firstPtfSynth, S_PtfSynth_FinalDate)) > 0)
		{
		    SET_NULL_DYNST(firstPtfSynth, S_PtfSynth);

	        SET_ID(firstPtfSynth,       S_PtfSynth_PtfId,       GET_ID(ptfPtr, A_Ptf_Id));
		    SET_DATETIME(firstPtfSynth, S_PtfSynth_InitialDate, tillDate);
		    /* REF1402 - RAK - 990205 - WRONG
		    SET_ID(firstPtfSynth, S_PtfSynth_PtfPosSetId,
		        GET_ID(domainPtr, A_Domain_PortPosSetId)); */

		    retFirst = DBA_Get2(PtfSynth, UNUSED, S_PtfSynth, firstPtfSynth,
			       	        S_PtfSynth, &firstPtfSynth, UNUSED, UNUSED, UNUSED);

		    if (RET_GET_LEVEL(retFirst) == RET_LEV_ERROR)
	       	{
		        SYSNAME_T entSqlName;
	    	    FREE_DYNST(lastPtfSynth, S_PtfSynth);
	    	    FREE_DYNST(firstPtfSynth, S_PtfSynth);
	    	    FREE_DYNST(getEventSched, S_EventSched);
	    	    FREE_DYNST(eventSchedPtr, A_EventSched);
		        strcpy(entSqlName, DBA_GetDictEntitySqlName(PtfSynth));
		        MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO,
				             entSqlName, GET_ID(ptfPtr, A_Ptf_Id));
		        return(RET_DBA_ERR_NODATA);
		    }
		}

		if (retFirst == RET_SUCCEED &&
		        DATETIME_CMP(GET_DATETIME(firstPtfSynth, S_PtfSynth_InitialDate), tillDate) < 0 &&
		        DATETIME_CMP(GET_DATETIME(firstPtfSynth, S_PtfSynth_FinalDate), tillDate) > 0)
			tillDate = GET_DATETIME(firstPtfSynth, S_PtfSynth_FinalDate);
	}

	FREE_DYNST(lastPtfSynth, S_PtfSynth);
	FREE_DYNST(firstPtfSynth, S_PtfSynth);

	/* ----------------------------- */
	/* VERIFY FUSION EVENT SCHEDULER */
	/* ----------------------------- */
	SET_ENUM(getEventSched, S_EventSched_NatEn, (ENUM_T) EventSchedNat_Fusion);

	ret = DBA_Get2(EventSched, DBA_ROLE_EVENT_SCHED_PERF_DATA, S_EventSched,
	    	       getEventSched, A_EventSched, &eventSchedPtr, UNUSED, UNUSED, UNUSED);

	if (ret == RET_SUCCEED)
	{
	    DATE_T 		crtDate=DATE_CurrentDate();
	    DATETIME_T 	eventDate=GET_DATETIME(eventSchedPtr, A_EventSched_EventDate);

	    /* RAK - 990301 - In some case event date can be in future, */
	    /*                don't verify this kind of event ...       */
	    if (crtDate >= eventDate.date)
	    {
	    	    /* Do nothing in case of one fusion perform during period */
		    if (DATETIME_CMP(tillDate, GET_DATETIME(eventSchedPtr, A_EventSched_FromDate)) >= 0)
		    {
	    	    FREE_DYNST(getEventSched, S_EventSched);
	    	    FREE_DYNST(eventSchedPtr, A_EventSched);
		        return(RET_FIN_ERR_FUSLOCK);    /* REF5245 - RAK - 001221 */
		    }
	    }
	}
	else
	ret = RET_SUCCEED;

	FREE_DYNST(getEventSched, S_EventSched);
	FREE_DYNST(eventSchedPtr, A_EventSched);

    /* REF7395 - CSY - 020531: don't build dates from existing synthetics in perf attrib when
    portfolio storage, comp new */
    if(GET_DICT(domainPtr, A_Domain_InitialFctDictId) == (DICT_FCT_ENUM)DictFct_PtfStorage &&
        GET_ENUM(domainPtr, A_Domain_CompDataEn) == (COMPDATA_ENUM)CompData_NewNonPermanent)
    {
        return(ret);
    }

    /* WEALTH-6600 - JBC - 20240503 */
    DatePeriodVec compPeriods;
    (void)FIN_LimitByPtfCompPeriods(domainPtr, hierHead, ptfPtr, &fromDate,&tillDate,compPeriods);

	if(compPeriods.empty())
	{
	    MSG_LogSrvMesg(RET_DBA_ERR_NODATA, UNUSED, "Failed to find valid Portfolio Computation Dates in Storage/Analysis for : %1.",
                       CodeType, GET_CODE(ptfPtr, A_Ptf_Cd));

        return(ret);
	}


	if (ptfFreqStp->freq != *oldFreqPtr || ptfFreqStp->freqUnit != *oldFreqUnitPtr ||
	    (ptfFreqStp->crystDates != nullptr && ptfFreqStp->crystDatesNbr > 0 &&
	     (DATETIME_CMP(ptfFreqStp->crystDates[0], fromDate) != 0 ||
	      DATETIME_CMP(ptfFreqStp->crystDates[(ptfFreqStp->crystDatesNbr)-1], tillDate) != 0)))
	{
        /* REF11016 - LJE - 050329 : Avoid crash in periodCrystDates freezing (below) */
	    if (ptfFreqStp->periodCrystDatesNbr > 0 &&
            ptfFreqStp->periodCrystDates == ptfFreqStp->crystDates)
	    {
            ptfFreqStp->periodCrystDatesNbr = 0;
            ptfFreqStp->periodCrystDates    = NULL;
        }

	    FREE(ptfFreqStp->crystDates);
	    ptfFreqStp->crystDatesNbr = 0;


        for(size_t perIdx=0;perIdx<compPeriods.size();perIdx++)
        {	          
            DATETIME_T * tmpCrystDates = nullptr;
			int			tmpCrystDatesNbr = 0;
			char		tmpEndPeriodFlg = FALSE;
			DATETIME_T  tmpEndPeriodDate;

            if((ret = DATE_CrystalDates(fromDate, tillDate,
			            (TINYINT_T) ptfFreqStp->freq, ptfFreqStp->freqUnit,
			            adjustEndOfMonthFlg, &tmpCrystDates,
			            &tmpCrystDatesNbr,
			            &tmpEndPeriodFlg, &tmpEndPeriodDate,
                        (DATE_POSI_ENUM)EndOf,              /* REF5358 - CSY - 010131 new arg EndOf */
                        nullptr, nullptr)
				) != RET_SUCCEED)
			{
			    break;
			}

		    if(perIdx==0)
            {
                ptfFreqStp->crystDates = tmpCrystDates;
                ptfFreqStp->crystDatesNbr = tmpCrystDatesNbr;
            }
            else
            {                        
                // realloc and copy;
                ptfFreqStp->crystDates = (DATETIME_T *)REALLOC(ptfFreqStp->crystDates,(ptfFreqStp->crystDatesNbr+tmpCrystDatesNbr) * sizeof(DATETIME_T));
                memcpy(ptfFreqStp->crystDates+ptfFreqStp->crystDatesNbr,tmpCrystDates,(tmpCrystDatesNbr) * sizeof(DATETIME_T));
                ptfFreqStp->crystDatesNbr += tmpCrystDatesNbr;
                FREE(tmpCrystDates);
            }

			if(perIdx == compPeriods.size()-1)
			{
			    ptfFreqStp->endPeriodFlg = tmpEndPeriodFlg;
				ptfFreqStp->endPeriodDate = tmpEndPeriodDate;
			}
		}

	    *oldFreqPtr     = ptfFreqStp->freq;
	    *oldFreqUnitPtr = ptfFreqStp->freqUnit;
	}

	/* REF1402 */
	if (retArgStp != NULL && ptfFreqStp->crystDatesNbr > 0)
		retArgStp->domFromDate = ptfFreqStp->crystDates[0];

	if (ptfFreqStp->periodNbr > 0)
	{
		FREE(ptfFreqStp->period);
		ptfFreqStp->periodNbr = 0;
	}

	if (ptfFreqStp->periodCrystDatesNbr > 0)
	{
		/* REF10333 - REF9954 - DDV - RAK - 040601 - If same adresse for both array, don't free it */
	    if (ptfFreqStp->periodCrystDates != ptfFreqStp->crystDates)
        {
            FREE(ptfFreqStp->periodCrystDates);
			ptfFreqStp->periodCrystDatesNbr = 0;
		}
	}

	/* REF1402 - Don't verify synthetics in case of from and till date are same, */
	/*           we are computed a new period. (so select will found 0 data)     */
	if (ptfFreqStp->crystDatesNbr >= 1 &&
	    (ptfFreqStp->eventSchedFlg == TRUE ||
	     (ptfFreqStp->eventSchedFlg == FALSE &&
	      DATETIME_CMP(GET_DATETIME(domainPtr, A_Domain_InterpFromDate),
			   GET_DATETIME(domainPtr, A_Domain_InterpTillDate)))) != 0)
	{
	    /* Don't read stored synthetics in case of daily mode and replace mode */
	    /* -> irregular synthetic doesn't exist in daily mode. Each synthetic  */
	    /* must be replace (or compute if it don't exist)                      */
	    if ((compDataEn == CompData_ReplacePermanent ||
	         compDataEn == CompData_ReplaceNonPermanent) &&
	        (ptfFreqStp->freq == 1 && ptfFreqStp->freqUnit == FreqUnit_Day))
	    {
		    ptfSynthNbr = 0;
	    }
	    else
	    {
	    	DBA_DYNFLD_STP	selPtfSynth=NULLDYNST;
		    DATETIME_T	selTillDate;
		    int		j, intermIdx=-1;

	        if ((selPtfSynth = ALLOC_DYNST(S_PtfSynth)) == NULLDYNST)
	    	{ MSG_RETURN(RET_MEM_ERR_ALLOC); }

	    	SET_ID(selPtfSynth, S_PtfSynth_PtfId,       GET_ID(ptfPtr, A_Ptf_Id));
	    	SET_DATETIME(selPtfSynth, S_PtfSynth_InitialDate, (ptfFreqStp->crystDates)[0]);

		/* If till date isn't an end of month -> select until end of month */
		/* If an synthetic exist at end of month, (and no persistant exist at till date) */
		/* suppress till date */
		selTillDate = ptfFreqStp->crystDates[(ptfFreqStp->crystDatesNbr)-1];
		if (ptfFreqStp->endPeriodFlg == FALSE)
			selTillDate = ptfFreqStp->endPeriodDate;

	    	SET_DATETIME(selPtfSynth, S_PtfSynth_FinalDate, selTillDate);

	    	ret = DBA_Select2(PtfSynth, UNUSED, S_PtfSynth, selPtfSynth,
			          S_PtfSynth, &synthTab, UNUSED, UNUSED,
			          &ptfSynthNbr, UNUSED, UNUSED);

	        FREE_DYNST(selPtfSynth, S_PtfSynth);

		selTillDate = ptfFreqStp->crystDates[(ptfFreqStp->crystDatesNbr)-1];

		/* In case of returned synthetics aren't in asked period, suppress them */
		if (ptfFreqStp->endPeriodFlg == FALSE && ptfSynthNbr > 0)
		{
			if (DATETIME_CMP(GET_DATETIME(synthTab[0], S_PtfSynth_InitialDate),
					 selTillDate) > 0)
			{
				DBA_FreeDynStTab(synthTab, ptfSynthNbr, S_PtfSynth);
				ptfSynthNbr = 0;
			}
		}

		if (ptfFreqStp->endPeriodFlg == FALSE &&
		    ptfSynthNbr > 0 &&
		    DATETIME_CMP(GET_DATETIME(synthTab[ptfSynthNbr-1], S_PtfSynth_FinalDate),
				 selTillDate) > 0)
		{
			for (j=ptfSynthNbr-1, intermIdx=-1;
			     j>=0 && DATETIME_CMP(GET_DATETIME(synthTab[j], S_PtfSynth_FinalDate),
						  selTillDate) >= 0; j--)
			{/* SSO 990412: missing "{ }" */
				if (DATETIME_CMP(GET_DATETIME(synthTab[j], S_PtfSynth_FinalDate),
						 selTillDate) == 0)
					intermIdx = j;
			}

			/* One after and final intermediate date found */
			/* -> synthetic until intermediate date.       */
			if (intermIdx != -1)
			{
				/* SSO 990412:  bad free
					    DBA_FreeDynStTab(&synthTab[intermIdx+1],
							     ptfSynthNbr-intermIdx-1, S_PtfSynth);
				*/

				for (j=intermIdx+1; j<ptfSynthNbr-intermIdx; j++)
				{
				    FREE_DYNST(synthTab[j], S_PtfSynth);
				}

				ptfSynthNbr = intermIdx + 1;
			}
			/* One after and final intermediate date not found         */
			/* -> synthetic until last date before intermediate date   */
			/*    and crystal until last date before intermediate date */
			else
			{
				(ptfFreqStp->crystDatesNbr) -=1;
				selTillDate = ptfFreqStp->crystDates[(ptfFreqStp->crystDatesNbr)-1];

				for (j=ptfSynthNbr-1;
				     j>=0 && DATETIME_CMP(GET_DATETIME(synthTab[j], S_PtfSynth_FinalDate),
							  selTillDate) > 0; j--)
				{
				    FREE_DYNST(synthTab[j], S_PtfSynth);
				}
				/* SSO 990412:  bad free
					    DBA_FreeDynStTab(&synthTab[j+1],
							     ptfSynthNbr-j-1, S_PtfSynth);
				*/

				ptfSynthNbr = j+1;
			}
		}
	    }

	    if (ptfSynthNbr > 0)
	    {
		DATETIME_T	*newCrystDates=nullptr;
		int 		newCrystDatesNbr=0;

		/* CONSTRUCT NEW CRYSTALISATION DATES */
		if ((ret = FIN_NewCrystDates(synthTab, ptfSynthNbr, GET_DATETIME(domainPtr, A_Domain_InterpFromDate),
				 	     ptfFreqStp->crystDates, ptfFreqStp->crystDatesNbr,
					     &newCrystDates, &newCrystDatesNbr)) != RET_SUCCEED)
		{
			DBA_FreeDynStTab(synthTab, ptfSynthNbr, S_PtfSynth);
			FREE((ptfFreqStp->crystDates));
		    	ptfFreqStp->crystDatesNbr = 0;
			return(ret);
		}

		if (compDataEn == CompData_NewPermanent ||
		    compDataEn == CompData_NewNonPermanent)
		{
		    ret = FIN_PeriodCrystDates(synthTab, ptfSynthNbr,
					       newCrystDates, newCrystDatesNbr,
					       ptfFreqStp);

            /* REF5244 - CSY - 001012: in mode "New", if there is no event scheduler,
            don't delete anything if the last synthetic is persistent */
            if (ptfFreqStp->eventSchedFlg == FALSE)
            {
                int i = 0;
                char noPersistFlg = FALSE;

                /* try to find if a non persistent data exists
                (only the last one may be non persistent) */
                while (i < ptfSynthNbr && noPersistFlg == FALSE)
                {
                    if (GET_ENUM(synthTab[i], S_PtfSynth_PersistEn) ==
                           (ENUM_T) PersistNat_NoPersist ||
						GET_ENUM(synthTab[i], S_PtfSynth_PersistEn) == /* PMSTA02013 - RAK - 071112 */
                            (ENUM_T) PersistNat_HierarchicalNoPersist)
                        noPersistFlg = TRUE;
                    i++;
                }

                /* REF5244 - CSY - 001012: in mode "New", if there is no non persistent
                synthetic, there is nothing to delete (all datas in synthTab are persistent) */
                ptfFreqStp->deleteFlg = noPersistFlg;
            }

		    if (ret != RET_SUCCEED && ret != RET_GEN_ERR_INVALIDATE)
		    {
			    FREE(newCrystDates);
			    DBA_FreeDynStTab(synthTab, ptfSynthNbr, S_PtfSynth);
			    FREE((ptfFreqStp->crystDates));
		    	    ptfFreqStp->crystDatesNbr = 0;
			    return(ret);
		    }

		    FREE(newCrystDates);
		}
		else
		{
			/* Keep crystalisation date just before domain from date */
			int i=0;
			if (ptfFreqStp->eventSchedFlg == FALSE)
			{
			    while (i<newCrystDatesNbr &&
			           DATETIME_CMP(newCrystDates[i],
					        GET_DATETIME(domainPtr, A_Domain_InterpFromDate)) < 0)
			       i++;
			}

			if (i-1>=0)
			{
				i--;	/* Go on last date just before domain from date */

				ptfFreqStp->periodCrystDatesNbr = newCrystDatesNbr - i;
				if ((ptfFreqStp->periodCrystDates = (DATETIME_T*)
						 CALLOC(ptfFreqStp->periodCrystDatesNbr,
				                        sizeof(DATETIME_T)))==nullptr)
				{
					FREE(newCrystDates);
					DBA_FreeDynStTab(synthTab, ptfSynthNbr, S_PtfSynth);
					FREE((ptfFreqStp->crystDates));
		    			ptfFreqStp->crystDatesNbr = 0;
					MSG_RETURN(RET_MEM_ERR_ALLOC);
				}

				/* Save crystalisation dates */
				memcpy(ptfFreqStp->periodCrystDates, newCrystDates+i,
	       		               ptfFreqStp->periodCrystDatesNbr * sizeof(DATETIME_T));

				FREE(newCrystDates);
			}
			else
			{
				/* Only one period (which is newCrystDates) */
				ptfFreqStp->periodCrystDates    = newCrystDates;
				ptfFreqStp->periodCrystDatesNbr = newCrystDatesNbr;
			}

			ptfFreqStp->periodNbr = 1;

			ptfFreqStp->period = (FIN_RET_CRYSTPER_STP)
					     CALLOC((ptfFreqStp->periodNbr), sizeof(FIN_RET_CRYSTPER_ST));

			if (ptfFreqStp->period == (FIN_RET_CRYSTPER_STP) NULL)
			{
               	/* REF11016 - LJE - 050329 : Avoid crash in crystDates freezing */
	            if (ptfFreqStp->periodCrystDates != ptfFreqStp->crystDates)
                {
    				FREE(ptfFreqStp->periodCrystDates);
                }
				ptfFreqStp->periodCrystDatesNbr = 0;
				DBA_FreeDynStTab(synthTab, ptfSynthNbr, S_PtfSynth);
				FREE((ptfFreqStp->crystDates));
		    		ptfFreqStp->crystDatesNbr = 0;
				MSG_RETURN(RET_MEM_ERR_ALLOC);
			}

			ptfFreqStp->period[0].beg = 0;
			ptfFreqStp->period[0].end = ptfFreqStp->periodCrystDatesNbr;
		}

	    	DBA_FreeDynStTab(synthTab, ptfSynthNbr, S_PtfSynth);
	    }
        else /* REF5244 - CSY - 001013: ptfSynthNbr == 0 */
        {
            if (!((compDataEn == CompData_ReplacePermanent ||
	                compDataEn == CompData_ReplaceNonPermanent) &&
	                (ptfFreqStp->freq == 1 && ptfFreqStp->freqUnit == FreqUnit_Day)))
                ptfFreqStp->deleteFlg = FALSE;
        }


	    /* Update end period flag and dates because of till date could be modified ... */
	    if (ptfFreqStp->periodNbr > 0)
		DATE_EndOfPeriodFlg(ptfFreqStp->periodCrystDates[(ptfFreqStp->periodCrystDatesNbr)-1],
				    (TINYINT_T) ptfFreqStp->freq, ptfFreqStp->freqUnit,
				    &(ptfFreqStp->endPeriodFlg), &(ptfFreqStp->endPeriodDate));
	    else
		DATE_EndOfPeriodFlg(ptfFreqStp->crystDates[(ptfFreqStp->crystDatesNbr)-1],
				    (TINYINT_T) ptfFreqStp->freq, ptfFreqStp->freqUnit,
				    &(ptfFreqStp->endPeriodFlg), &(ptfFreqStp->endPeriodDate));
	}

	/* REF1465 - Don't work without crystalisation date */
	if (ret == RET_SUCCEED)
	{
	    if ((ptfFreqStp->periodNbr > 0 && ptfFreqStp->periodCrystDatesNbr <= 1) ||
	        (ptfFreqStp->crystDatesNbr <= 1))
		    return(RET_GEN_ERR_INVALIDATE);
	    else
		    return(ret);
	}
	else
	    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_VerifPtfFreqCommFreq()
**
**  Description :   Group synthetics by common frequency
**
**  Arguments   :   synthHierHead   	synthetics hierarchy header pointer
**  		    ptfFreq		portfolio frequency
**  		    ptfFreqUnit		portfolio frequency unit
**		    commFreqstp 	common freq info (frequency and crystal dates)
**		    synthTab 	    	synthetics array
**		    synthNbr	    	synthetics number
**
**  Return      :   COMPA_FREQ_ENUM (compaFreq_Ok, compaFreq_Impossible, compaFreq_Group)
**
**  Creation	:   DVP261 - RAK - 961212
**  Modification:   REF8347 - YST - 021106
**
*************************************************************************/
STATIC COMPA_FREQ_ENUM	FIN_VerifPtfFreqCommFreq(FREQUNIT_ENUM      ptfFreqUnit,
                                                SMALLINT_T          ptfFreq,
                                                FREQUNIT_ENUM       commFreqUnit,
                                                SMALLINT_T          commFreq,
                                                PTFCONSRULE_ENUM    ptfConsRuleEn)
{
	COMPA_FREQ_ENUM compaFreqEn;
    FLAG_T          ptfFreqTWRFlg = FALSE;

	if (commFreqUnit == FreqUnit_BusDay || ptfFreqUnit == FreqUnit_BusDay)
	{
	    MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
			 "FIN_VerifPtfFreqCommFreq", "frequencies");
	    return(compaFreq_Impossible);
	}
    /* REF8347 - YST - 021106 - change TWR frequency to monthly */
    if ((ptfFreqUnit == FreqUnit_MonthGlobalTWR || ptfFreqUnit == FreqUnit_MonthTWR) && ptfConsRuleEn == PtfConsRule_Merged)
    {
        ptfFreqUnit = FreqUnit_Month;
        ptfFreqTWRFlg = TRUE;               /* TWR and "merge" Ok: set always compaFreq_Group */
    }

	/* Verify if frequencies are compatible */
	if (commFreqUnit == ptfFreqUnit)
	{
	    if (ptfFreq == commFreq && ptfFreqTWRFlg != TRUE)   /* 2 month to 2 month : OK if not TWR *//* REF8347 - YST - 021106 */
        {
            compaFreqEn = compaFreq_Ok;
        }
	    else
	    {
		    if (ptfFreq > commFreq)
			    compaFreqEn = compaFreq_Impossible;	/* 2 days to 1 day : NO */
		    else
		        compaFreqEn = compaFreq_Group;		/* 1 day to 2 days : YES or 2 month to 2 month if TWR *//* REF8347 - YST - 021106 */
	    }
	}
	else
	{
	    switch (ptfFreqUnit)
	    {
	    case FreqUnit_Day :
	        switch (commFreqUnit)
	        {
	        case FreqUnit_Week :
		    if (ptfFreq == 7)
		        compaFreqEn = compaFreq_Ok;		/* 7 days = 1 week  : OK */
		    else
		    {
		        if (7 % ptfFreq != 0)
			    compaFreqEn = compaFreq_Impossible;	/* 8 days -> 1 week : NO */
		        else
			    compaFreqEn = compaFreq_Group;	/* 7 days = 1 week  : YES */
		    }
	    	    break;

	        case FreqUnit_Month :
	        case FreqUnit_Quarter :
	        case FreqUnit_Semester :
	        case FreqUnit_Year :
		    if (ptfFreq != 1)
		        compaFreqEn = compaFreq_Impossible;	/* 10 days -> 1 month : NO */
		    else
		        compaFreqEn = compaFreq_Group;		/* 1 day -> 1 month : YES */
		    break;

	        default :
		    compaFreqEn = compaFreq_Impossible;
	        }
	        break;

	    case FreqUnit_Week :
		compaFreqEn = compaFreq_Impossible;		/* week -> nothing */
		break;

	    case FreqUnit_Month :
	    case FreqUnit_Quarter :
	    case FreqUnit_Semester :
	    case FreqUnit_Year :
		case FreqUnit_MonthGlobalTWR :    /* REF10333 - RAK - 041125 */
		case FreqUnit_MonthTWR :
	    {
		    SMALLINT_T months;

	        if (ptfFreqUnit == FreqUnit_Quarter)
		    ptfFreq *= 3;

	        if (ptfFreqUnit == FreqUnit_Semester)
		    ptfFreq *= 6;

	        if (ptfFreqUnit == FreqUnit_Year)
		    ptfFreq *= 12;

		    compaFreqEn = compaFreq_Group;

	        switch (commFreqUnit)
	        {
	        case FreqUnit_Quarter :
		        months = 3;
		        break;
	        case FreqUnit_Semester :
		        months = 6;
		        break;
	        case FreqUnit_Year :
	    	    months = 12;
		        break;
			case FreqUnit_Month :	/* REF10333 - RAK - 041125 */
	    	    months = 1;
		        break;
	        default :
		        compaFreqEn = compaFreq_Impossible;
		        months = -1;
	        }

	        if (compaFreqEn != compaFreq_Impossible)
		    {
		        if (ptfFreq == months && ptfFreqTWRFlg != TRUE) /* 3 months = 1 quarter if not TWR */  /* REF8347 - YST - 021106 */
                {                                               /* 6 months = 1 semester if not TWR */
		            compaFreqEn = compaFreq_Ok;		            /* -> nothing to do       */
		        }
		        else
		        {
		            if (months % ptfFreq != 0)		        /* 12 months from 5 months */
		    	        compaFreqEn = compaFreq_Impossible;	/* -> impossible           */
		            else
			            compaFreqEn = compaFreq_Group;	    /* 3 months = 1 quarter if TWR: group */
		        }
		    }
	        break;
	    }

	    default :
		compaFreqEn = compaFreq_Impossible;
	    }
	}

	if (compaFreqEn == compaFreq_Impossible)
	{
	    MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
			 "FIN_VerifPtfFreqCommFreq", "frequencies");
	}

	return(compaFreqEn);
}

/************************************************************************
**
**  Function    :   FIN_AddSynthCompHist()
**
**  Description :   For Synth Admin - Compute history and retDetLevel = Grid:
**                  In order to store synthetics as for Portfolio Storage
**                  some synthetics need to be updated or created:
**
**                  1. Set gridId for global synthetics which were retrieved
**                  from database (i.e. gridId = NULL).
**
**                  2. For each period "grid level" synthetics were retrieved
**                  from database (A_PtfSynth_Id > 0) compute totaliser.
**
**                  Remark: If synthetics are computed online for Synth Admin - comphist
**                  gridId is set and totaliser is computed during online computation (as for Ptf storage).
**
**  Arguments   :   synthHierHead   synthetics hierarchy header pointer
**  		        domainPtr       pointer on domain
**  		        ptfPtr          pointer on portfolio
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation	:   REF8354 - YST - 021206/021217
**                  REF9956 - 040330 - PMO : FlexeLint message
**
*************************************************************************/
STATIC RET_CODE FIN_AddSynthCompHist(DBA_HIER_HEAD_STP  synthHierHead,
                                        DBA_DYNFLD_STP  domainPtr,
                                        DBA_DYNFLD_STP  ptfPtr)
{
    RET_CODE            ret = RET_SUCCEED;
    DBA_DYNFLD_STP      sGridLnk = NULLDYNST, *gridLnkTab = NULLDYNSTPTR, sGridPtr = NULLDYNST, aGridPtr = NULLDYNST,
                        *selSynthTab = NULLDYNSTPTR, *newGlobalSynth = NULLDYNSTPTR;
    PA_LICENSEE_ENUM	isPALicenseEn = PALicensee_No;
    RA_LICENSEE_ENUM	isRALicenseEn = RALicensee_No;
    DATETIME_T          oldDate;
    DICT_T              entDictId;
    ID_T                gridId[10];
    int                 i = 0, j = 0, newIdx = 0, gridNbr = 0, gridLnkNbr = 0, selSynthNbr = 0;

    memset(&gridId,0, sizeof(gridId));  /* REF9956 - PMO */

    /* get licensee keys PA and RA */
    GEN_GetApplInfo(ApplPALicense, &isPALicenseEn);
	GEN_GetApplInfo(ApplRALicense, &isRALicenseEn);

    if ((sGridLnk = ALLOC_DYNST(S_ReturnGridLnk)) == NULLDYNST)
	    MSG_RETURN(RET_MEM_ERR_ALLOC);

    DBA_GetDictId(Ptf, &entDictId);
    SET_DICT(sGridLnk, S_ReturnGridLnk_EntDictId, entDictId);
    SET_ID(sGridLnk,   S_ReturnGridLnk_ObjId, GET_ID(ptfPtr, A_Ptf_Id));

    if ((ret = DBA_Select2(ReturnGridLnk, UNUSED, S_ReturnGridLnk, sGridLnk,
				          A_ReturnGridLnk, &gridLnkTab, UNUSED, UNUSED,
				          &gridLnkNbr, UNUSED, UNUSED)) != RET_SUCCEED || gridLnkNbr == 0)
    {
        FREE(sGridLnk);
        return(ret);
    }
    FREE(sGridLnk);

    /* Take gridId's of return_grid_link of nature port_synth */
    for(i=0; i<gridLnkNbr; i++)
    {
        if((RETURN_GRID_LNK_NAT_ENUM)GET_ENUM(gridLnkTab[i], A_ReturnGridLnk_NatEn) == ReturnGridLnk_PtfSynth)
        {
            gridId[gridNbr++] = GET_ID(gridLnkTab[i], A_ReturnGridLnk_GridId);
        }
    }
    DBA_FreeDynStTab(gridLnkTab, gridLnkNbr, A_ReturnGridLnk);

    if (gridNbr == 0)
        return(RET_SUCCEED);

    /* Extract all global synthetics for the given porfolio sorted by initial date */
    if ((ret = DBA_ExtractHierEltRecWithFilterSt(synthHierHead, A_PtfSynth, FALSE,
                                FIN_FilterGlobalSynthCompHist, ptfPtr, NULL,
			                    &selSynthNbr, &selSynthTab)) != RET_SUCCEED)
    {
        return(ret);
    }

    /* If more than one gridId was found allocate memory for new global synthetics */
    if (gridNbr > 1 && selSynthNbr > 0)
    {
        if ((newGlobalSynth = (DBA_DYNFLD_STP*)CALLOC((gridNbr-1)*selSynthNbr, sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR)
        {
            FREE(selSynthTab);
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }
    }

    /* Set gridId in global synthetics and create new synthetics if more than one gridId was found */
    for (i=0; i<selSynthNbr; i++)
    {
        SET_ID(selSynthTab[i], A_PtfSynth_GridId, gridId[0]);
        j = 1;
        while (j < gridNbr)
        {
            if ((newGlobalSynth[newIdx] = ALLOC_DYNST(A_PtfSynth)) == NULLDYNST)
            {
                FREE(selSynthTab);
                FREE(newGlobalSynth);
			    MSG_RETURN(RET_MEM_ERR_ALLOC);
            }
            COPY_DYNST(newGlobalSynth[newIdx], selSynthTab[i], A_PtfSynth);
            SET_ID(newGlobalSynth[newIdx], A_PtfSynth_GridId, gridId[j]);
            SET_NULL_ID(newGlobalSynth[newIdx], A_PtfSynth_Id);
            newIdx++;
            j++;
        }
    }

    /* Add new global synthetics to hierarchy */
    ret = DBA_AddHierRecordList(synthHierHead, newGlobalSynth, newIdx, A_PtfSynth, FALSE);
    FREE(newGlobalSynth);
    FREE(selSynthTab);

    /* Compute totaliser only if licensee PA=1 or (PA=0 and RA=2) */
    if(isPALicenseEn == PALicensee_Level1 || (isPALicenseEn == PALicensee_No && isRALicenseEn == RALicensee_Level2))
    {
        /* Extract all "grid level" synthetics retrieved from database for the given porfolio sorted by initial date  */
        selSynthNbr = 0;
        if ((ret = DBA_ExtractHierEltRecWithFilterSt(synthHierHead, A_PtfSynth, FALSE,
                                    FIN_FilterGridSynthCompHist, ptfPtr, FIN_CmpPtfSynthPtfDate,
			                        &selSynthNbr, &selSynthTab)) != RET_SUCCEED ||
                                    selSynthNbr == 0)
        {
            return(ret);
        }
        if ((sGridPtr = ALLOC_DYNST(S_Grid)) == NULLDYNST)
        {
            FREE(selSynthTab);
		    MSG_RETURN(RET_MEM_ERR_ALLOC);
        }
        if ((aGridPtr = ALLOC_DYNST(A_Grid)) == NULLDYNST)
        {
            FREE(selSynthTab);
            FREE_DYNST(sGridPtr, S_Grid);
		    MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        for (i=0; i<gridNbr; i++)
        {
            /* get grid */
            SET_ID(sGridPtr, S_Grid_Id, gridId[i]);
            if ((ret = DBA_Get2(Grid, UNUSED, S_Grid, sGridPtr,
                                A_Grid, &aGridPtr, UNUSED, UNUSED, UNUSED)) != RET_SUCCEED)
            {
                FREE(selSynthTab);
                FREE_DYNST(sGridPtr, S_Grid);
		        FREE_DYNST(aGridPtr, A_Grid);
		        return(ret);
            }
            oldDate = GET_DATETIME(selSynthTab[0], A_PtfSynth_FinalDate);

            /* compute totaliser for each period a "grid level" ptf synth was found in database */
            for (j=0; j<selSynthNbr; j++)
            {
                if (DATETIME_CMP(oldDate, GET_DATETIME(selSynthTab[j], A_PtfSynth_InitialDate)) != 0)
                {
                    if((ret = FIN_ComputeMktStructCumul(synthHierHead, domainPtr, aGridPtr,
                                                    GET_DATETIME(selSynthTab[j], A_PtfSynth_InitialDate),
                                                    GET_DATETIME(selSynthTab[j], A_PtfSynth_FinalDate),
                                                    GET_ID(selSynthTab[j], A_PtfSynth_PSPId))) != RET_SUCCEED) /* REF9738 - LJE - 040305 */
                    {
                        FREE(selSynthTab);
                        FREE_DYNST(sGridPtr, S_Grid);
		                FREE_DYNST(aGridPtr, A_Grid);
                        return(ret);
                    }
                    oldDate = GET_DATETIME(selSynthTab[j], A_PtfSynth_InitialDate);
                }
            }
        }
        FREE_DYNST(sGridPtr, S_Grid);
        FREE_DYNST(aGridPtr, A_Grid);
        FREE(selSynthTab);
    }

    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_AddSynthCompHistnew()
**
**  Description :   For Synth Admin - Compute history and retDetLevel = Grid:
**                  In order to store synthetics as for Portfolio Storage
**                  some synthetics need to be updated or created:
**
**                  1. Set gridId for global synthetics (i.e. gridId = NULL).
**
**                  2. For each period "grid level" synthetics were retrieved
**                  from database (A_PtfSynth_Id > 0) compute totaliser.
**
**                  Remark: If synthetics are computed online for Synth Admin - comphist
**                  gridId is set and totaliser is computed during online computation (as for Ptf storage).
**
**  Arguments   :   synthHierHead   synthetics hierarchy header pointer
**  		        domainPtr       pointer on domain
**  		        ptfPtr          pointer on portfolio
**                  pspPtr			pointer on psp
**					selSynthTab     pointer on ptf synth tab
**                  selSynthNb      number of elements in tab
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation	:   REF9834 - TEB - 041130
**
*************************************************************************/
STATIC RET_CODE FIN_AddSynthCompHistNew(DBA_HIER_HEAD_STP	synthHierHead,
                                        DBA_DYNFLD_STP		domainPtr,
										DBA_DYNFLD_STP		ptfPtr,
                                        DBA_DYNFLD_STP		pspPtr,
										DBA_DYNFLD_STP	    *selSynthTab,
										int					selSynthNbr)
{
    RET_CODE            ret = RET_SUCCEED;
    DBA_DYNFLD_STP      sGridPtr = NULLDYNST, aGridPtr = NULLDYNST,
                        *totSynthTab = NULLDYNSTPTR, *newGlobalSynth = NULLDYNSTPTR;
    PA_LICENSEE_ENUM	isPALicenseEn = PALicensee_No;
    RA_LICENSEE_ENUM	isRALicenseEn = RALicensee_No;
    DATETIME_T          oldDate;
    int                 i = 0, j = 0, totSynthNbr = 0;


	ID_T gridId, pspId;

	if (IS_NULLFLD(pspPtr, A_PerfStorageParam_GridId) == TRUE)
	{
		return(RET_SUCCEED);
	}

	gridId = GET_ID(pspPtr, A_PerfStorageParam_GridId);
	pspId  = GET_ID(pspPtr, A_PerfStorageParam_Id);


    /* get licensee keys PA and RA */
    GEN_GetApplInfo(ApplPALicense, &isPALicenseEn);
	GEN_GetApplInfo(ApplRALicense, &isRALicenseEn);

    /* If more than one gridId was found allocate memory for new global synthetics */
    if (selSynthNbr > 0)
    {
        if ((newGlobalSynth = (DBA_DYNFLD_STP*)CALLOC(selSynthNbr, sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR)
        {
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }
    }

    /* Set gridId in global synthetics and create new synthetics if more than one gridId was found */
    for (i=0; i<selSynthNbr; i++)
    {
        if ((newGlobalSynth[i] = ALLOC_DYNST(A_PtfSynth)) == NULLDYNST)
        {
            FREE(newGlobalSynth);
			MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        COPY_DYNST(newGlobalSynth[i], selSynthTab[i],    A_PtfSynth);
        SET_ID(newGlobalSynth[i],	  A_PtfSynth_GridId, gridId);
        SET_ID(newGlobalSynth[i],     A_PtfSynth_PSPId,  pspId);
        SET_NULL_ID(newGlobalSynth[i], A_PtfSynth_Id);
	}

    /* Add new global synthetics to hierarchy */
    ret = DBA_AddHierRecordList(synthHierHead,
                                newGlobalSynth, selSynthNbr,
								A_PtfSynth, FALSE);
    FREE(newGlobalSynth);

    /* Compute totaliser only if licensee PA=1 or (PA=0 and RA=2) */
    if(isPALicenseEn == PALicensee_Level1 || (isPALicenseEn == PALicensee_No && isRALicenseEn == RALicensee_Level2))
    {
        /* Extract all "grid level" synthetics retrieved from database for the given porfolio sorted by initial date  */
        totSynthNbr = 0;
        if ((ret = DBA_ExtractHierEltRecWithFilterSt(synthHierHead,
													 A_PtfSynth,
													 FALSE,
													 FIN_FilterSynthCompHist/*FIN_FilterGridSynthCompHist*/, ptfPtr,
													 FIN_CmpPtfSynthPtfDate,
													 &totSynthNbr,
													 &totSynthTab)) != RET_SUCCEED ||
             totSynthNbr == 0)
        {
            return(ret);
        }
        if ((sGridPtr = ALLOC_DYNST(S_Grid)) == NULLDYNST)
        {
            FREE(totSynthTab);
		    MSG_RETURN(RET_MEM_ERR_ALLOC);
        }
        if ((aGridPtr = ALLOC_DYNST(A_Grid)) == NULLDYNST)
        {
            FREE(totSynthTab);
            FREE_DYNST(sGridPtr, S_Grid);
		    MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        /* get grid */
        SET_ID(sGridPtr, S_Grid_Id, gridId);
        if ((ret = DBA_Get2(Grid, UNUSED, S_Grid, sGridPtr,
                            A_Grid, &aGridPtr, UNUSED, UNUSED, UNUSED)) != RET_SUCCEED)
        {
            FREE(totSynthTab);
            FREE_DYNST(sGridPtr, S_Grid);
		    FREE_DYNST(aGridPtr, A_Grid);
		    return(ret);
        }
        oldDate = GET_DATETIME(totSynthTab[0], A_PtfSynth_FinalDate);

        /* compute totaliser for each period a "grid level" ptf synth was found in database */
        for (j=0; j<totSynthNbr; j++)
        {
            if (GET_ID(totSynthTab[j], A_PtfSynth_PSPId) == pspId &&		/* REF9834 - TEB - 041207 */
				DATETIME_CMP(oldDate, GET_DATETIME(totSynthTab[j], A_PtfSynth_InitialDate)) != 0)
            {
                if((ret = FIN_ComputeMktStructCumul(synthHierHead, domainPtr, aGridPtr,
                                                GET_DATETIME(totSynthTab[j], A_PtfSynth_InitialDate),
                                                GET_DATETIME(totSynthTab[j], A_PtfSynth_FinalDate),
                                                GET_ID(totSynthTab[j], A_PtfSynth_PSPId))) != RET_SUCCEED)
                {
                    FREE(totSynthTab);
                    FREE_DYNST(sGridPtr, S_Grid);
		            FREE_DYNST(aGridPtr, A_Grid);
                    return(ret);
                }
                oldDate = GET_DATETIME(totSynthTab[j], A_PtfSynth_InitialDate);
            }
        }

        FREE_DYNST(sGridPtr, S_Grid);
        FREE_DYNST(aGridPtr, A_Grid);
        FREE(totSynthTab);
    }

    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_CmpMktSgtId()
**
**  Description :   Market segment sorted by identifier
**
**  Arguments   :   ptr1   pointer on dynamic structure type ExtPos
**                  ptr2   pointer on dynamic structure type ExtPos
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation  	:   REF4263 - RAK - 000309
**
*************************************************************************/
STATIC int FIN_CmpMktSgtId(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    return(CMP_ID(GET_ID((*ptr2), S_MktSegt_Id) , GET_ID((*ptr1), S_MktSegt_Id))); /* DLA - REF9089 - 030508 */
}

/************************************************************************
**
**  Function    :   FIN_CmpMktSgtSynth()
**
**  Description :   Sort by portfolio, date and market segment identifier
**
**  Arguments   :   ptr1   pointer on dynamic structure type ExtPos
**                  ptr2   pointer on dynamic structure type ExtPos
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation  	:   REF4263 - RAK - 000309
**
*************************************************************************/
STATIC int FIN_CmpMktSgtSynth(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    if (GET_ID((*ptr1), A_PtfSynth_PtfId) == GET_ID((*ptr2), A_PtfSynth_PtfId))
    {
        if (DATETIME_CMP(GET_DATETIME((*ptr1), A_PtfSynth_InitialDate),
                         GET_DATETIME((*ptr2), A_PtfSynth_InitialDate)) == 0)
        {
            /* global at the end ! */
            return(CMP_ID(GET_ID((*ptr2), A_PtfSynth_MktSegtId) ,
                   GET_ID((*ptr1), A_PtfSynth_MktSegtId))); /* DLA - REF9089 - 030508 */
        }
        else
            return(DATETIME_CMP(GET_DATETIME((*ptr1), A_PtfSynth_InitialDate),
                                GET_DATETIME((*ptr2), A_PtfSynth_InitialDate)));
    }
    else
        return(CMP_ID(GET_ID((*ptr1), A_PtfSynth_PtfId) ,
               GET_ID((*ptr2), A_PtfSynth_PtfId))); /* DLA - REF9089 - 030508 */
}

/************************************************************************
**
**  Function    :   FIN_CmpChildrenPtf()
**
**  Description :   Portfolio sorted by hiearchy portfolio, ...
**
**  Arguments   :   ptr1   pointer on dynamic structure type ExtPos
**                  ptr2   pointer on dynamic structure type ExtPos
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation  	:   REF3637 - RAK - 000309
**
*************************************************************************/
STATIC int FIN_CmpChildrenPtf(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    return(CMP_ID(GET_ID((*ptr1), A_Ptf_HierPortId) , GET_ID((*ptr2), A_Ptf_HierPortId))); /* DLA - REF9089 - 030508 */
}

/************************************************************************
**
**  Function    :   FIN_CmpReturnPtf()
**
**  Description :   Portfolio sorted by identifier
**
**  Arguments   :   ptr1   pointer on dynamic structure type ExtPos
**                  ptr2   pointer on dynamic structure type ExtPos
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation  	:   DVP261 - RAK - 961121
**
*************************************************************************/
STATIC int FIN_CmpReturnPtf(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
	return(CMP_ID(GET_ID((*ptr1), A_Ptf_Id) , GET_ID((*ptr2), A_Ptf_Id)));/* DLA - REF9089 - 030508 */
}

/************************************************************************
**
**  Function    :   FIN_CmpPtfSynthPtfDateNat()
**
**  Description :   Synthetics sorted by portfolio id, date, nature
**
**  Arguments   :   ptr1   pointer on dynamic structure type ExtPos
**                  ptr2   pointer on dynamic structure type ExtPos
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation  	:   DVP261 - RAK - 961121
**
*************************************************************************/
STATIC int FIN_CmpPtfSynthPtfDateNat(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
	/* Portfolio */
	if (GET_ID((*ptr1), A_PtfSynth_PtfId) == GET_ID((*ptr2), A_PtfSynth_PtfId))
	{
	    /* Date */
	    if (DATETIME_CMP(GET_DATETIME((*ptr1), A_PtfSynth_InitialDate),
			     GET_DATETIME((*ptr2), A_PtfSynth_InitialDate)) == 0)
	    {
		/* Risk nature */
	    	return(GET_ENUM((*ptr1), A_PtfSynth_RiskNatEn) -
		       GET_ENUM((*ptr2), A_PtfSynth_RiskNatEn));
	    }
	    else
	        return(DATETIME_CMP(GET_DATETIME((*ptr1), A_PtfSynth_InitialDate),
		                    GET_DATETIME((*ptr2), A_PtfSynth_InitialDate)));
	}
	else
	{
	    return(CMP_ID(GET_ID((*ptr1), A_PtfSynth_PtfId) , GET_ID((*ptr2), A_PtfSynth_PtfId)));
	}
}

/************************************************************************
**
**  Function    :   FIN_CmpPtfSynthPtfNatDetailDate()
**
**  Description :   Synthetics sorted by ptf, date, nature, market sgt and instr
**
**  Arguments   :   ptr1   pointer on dynamic structure type ExtPos
**                  ptr2   pointer on dynamic structure type ExtPos
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation  	:   DVP261 - RAK - 961121
**
*************************************************************************/
STATIC int FIN_CmpPtfSynthPtfNatDetailDate(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
	/* Portfolio */
	if (GET_ID((*ptr1), A_PtfSynth_PtfId) == GET_ID((*ptr2), A_PtfSynth_PtfId))
	{
	    /* Risk nature */
	    if (GET_ENUM((*ptr1), A_PtfSynth_RiskNatEn) == GET_ENUM((*ptr2), A_PtfSynth_RiskNatEn))
	    {
		/* Grid */
	 	if (GET_ID((*ptr1), A_PtfSynth_GridId) == GET_ID((*ptr2), A_PtfSynth_GridId))
		{
		    /* Market segment */
	 	    if (GET_ID((*ptr1), A_PtfSynth_MktSegtId) ==
			GET_ID((*ptr2), A_PtfSynth_MktSegtId))
		    {
		        /* Instrument */
		        if (GET_ID((*ptr1), A_PtfSynth_InstrId) ==
			    GET_ID((*ptr2), A_PtfSynth_InstrId))
		        {
	    		    /* Date */
	    		    return(DATETIME_CMP(GET_DATETIME((*ptr1), A_PtfSynth_InitialDate),
			                        GET_DATETIME((*ptr2), A_PtfSynth_InitialDate)));
		        }
		        else
		        {
		            return(CMP_ID(GET_ID((*ptr1), A_PtfSynth_InstrId) ,
			           GET_ID((*ptr2), A_PtfSynth_InstrId)));
		        }
		    }
		    else
		    {
		        return(CMP_ID(GET_ID((*ptr1), A_PtfSynth_MktSegtId) ,
			       GET_ID((*ptr2), A_PtfSynth_MktSegtId))); /* DLA - REF9089 - 030508 */
		    }
		}
		else
		{
		    return(CMP_ID(GET_ID((*ptr1), A_PtfSynth_GridId) ,
			   GET_ID((*ptr2), A_PtfSynth_GridId))); /* DLA - REF9089 - 030508 */
		}
	    }
	    else
	    {
		return(GET_ENUM((*ptr1), A_PtfSynth_RiskNatEn) -
		       GET_ENUM((*ptr2), A_PtfSynth_RiskNatEn));
	    }
	}
	else
	{
	    return(CMP_ID(GET_ID((*ptr1), A_PtfSynth_PtfId) , GET_ID((*ptr2), A_PtfSynth_PtfId))); /* DLA - REF9089 - 030508 */
	}
}

/************************************************************************
**
**  Function    :   FIN_CmpPtfSynthPtfNatDetailDate2()
**
**  Description :   Synthetics sorted by ptf, date, nature, market sgt and instr
**                  This filter is called for FIN_MergeHierPtfSynth().
**
**  Arguments   :   ptr1   pointer on dynamic structure type ExtPos
**                  ptr2   pointer on dynamic structure type ExtPos
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation  	:   REF7785 - RAK - 020904/YST - 021025
**
*************************************************************************/
STATIC int FIN_CmpPtfSynthPtfNatDetailDate2(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
	/* Sort on portfolio for FIN_MergeHierPtfSynth() - REF7785 - RAK - 020904 */
	if (GET_ID((*ptr1), A_PtfSynth_PtfId) == GET_ID((*ptr2), A_PtfSynth_PtfId))
	{
		/* Risk nature */
		if (GET_ENUM((*ptr1), A_PtfSynth_RiskNatEn) == GET_ENUM((*ptr2), A_PtfSynth_RiskNatEn))
		{
			/* Grid */
			if (GET_ID((*ptr1), A_PtfSynth_GridId) == GET_ID((*ptr2), A_PtfSynth_GridId))
			{
				/* Market segment */
				if (GET_ID((*ptr1), A_PtfSynth_MktSegtId) == GET_ID((*ptr2), A_PtfSynth_MktSegtId))
				{
					/* Instrument */
					if (GET_ID((*ptr1), A_PtfSynth_InstrId) == GET_ID((*ptr2), A_PtfSynth_InstrId))
					{
						/* Date */		/* BUG499 */
						/* PMSTA02479-CHU-070525 */
						if (DATETIME_CMP(GET_DATETIME((*ptr1), A_PtfSynth_FinalDate),
							GET_DATETIME((*ptr2), A_PtfSynth_FinalDate)) == 0)
						{
		 					if (DATETIME_CMP(GET_DATETIME((*ptr1), A_PtfSynth_InitialDate),
								GET_DATETIME((*ptr2), A_PtfSynth_InitialDate)) == 0)
							{
								return(CMP_ID(GET_ID((*ptr1), A_PtfSynth_Id) ,
											GET_ID((*ptr2), A_PtfSynth_Id)));							}
							else
							{
								return(DATETIME_CMP(GET_DATETIME((*ptr1), A_PtfSynth_InitialDate),
													GET_DATETIME((*ptr2), A_PtfSynth_InitialDate)));
							}
						}
						else
						{
		 					return(DATETIME_CMP(GET_DATETIME((*ptr1), A_PtfSynth_FinalDate),
												GET_DATETIME((*ptr2), A_PtfSynth_FinalDate)));
						}
					}
					else
					{
						return(CMP_ID(GET_ID((*ptr1), A_PtfSynth_InstrId) ,
								GET_ID((*ptr2), A_PtfSynth_InstrId))); /* DLA - REF9089 - 030508 */
					}
				}
				else
				{
					return(CMP_ID(GET_ID((*ptr1), A_PtfSynth_MktSegtId) ,
							GET_ID((*ptr2), A_PtfSynth_MktSegtId))); /* DLA - REF9089 - 030508 */
				}
			}
			else
			{
				return(CMP_ID(GET_ID((*ptr1), A_PtfSynth_GridId) ,
						GET_ID((*ptr2), A_PtfSynth_GridId))); /* DLA - REF9089 - 030508 */
			}
		}
		else
		{
			return(GET_ENUM((*ptr1), A_PtfSynth_RiskNatEn) -
					GET_ENUM((*ptr2), A_PtfSynth_RiskNatEn));
		}
	}
	else
	{
		return(CMP_ID(GET_ID((*ptr1), A_PtfSynth_PtfId) ,
				GET_ID((*ptr2), A_PtfSynth_PtfId))); /* DLA - REF9089 - 030508 */
	}
}

/************************************************************************
**
**  Function    :   FIN_CmpPtfSynthNatDetailDate()
**
**  Description :   Synthetics sorted by date, nature, market sgt and instr
**                  This filter is called for FIN_MergePtfSynth().
**
**  Arguments   :   ptr1   pointer on dynamic structure type ExtPos
**                  ptr2   pointer on dynamic structure type ExtPos
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation  	:   DVP261 - RAK - 961121
**
*************************************************************************/
STATIC int FIN_CmpPtfSynthNatDetailDate(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
	/* Risk nature */
	if (GET_ENUM((*ptr1), A_PtfSynth_RiskNatEn) == GET_ENUM((*ptr2), A_PtfSynth_RiskNatEn))
	{
		/* Grid */
		if (GET_ID((*ptr1), A_PtfSynth_GridId) == GET_ID((*ptr2), A_PtfSynth_GridId))
		{
			/* Market segment */
			if (GET_ID((*ptr1), A_PtfSynth_MktSegtId) == GET_ID((*ptr2), A_PtfSynth_MktSegtId))
			{
				/* Instrument */
				if (GET_ID((*ptr1), A_PtfSynth_InstrId) == GET_ID((*ptr2), A_PtfSynth_InstrId))
				{
					/* Date */		/* BUG499 */
		 			return(DATETIME_CMP(GET_DATETIME((*ptr1), A_PtfSynth_FinalDate),
										GET_DATETIME((*ptr2), A_PtfSynth_FinalDate)));
				}
				else
				{
					return(CMP_ID(GET_ID((*ptr1), A_PtfSynth_InstrId) ,
							GET_ID((*ptr2), A_PtfSynth_InstrId))); /* DLA - REF9089 - 030508 */
				}
			}
			else
			{
				return(CMP_ID(GET_ID((*ptr1), A_PtfSynth_MktSegtId) ,
						GET_ID((*ptr2), A_PtfSynth_MktSegtId))); /* DLA - REF9089 - 030508 */
			}
		}
		else
		{
			return(CMP_ID(GET_ID((*ptr1), A_PtfSynth_GridId) ,
					GET_ID((*ptr2), A_PtfSynth_GridId))); /* DLA - REF9089 - 030508 */
		}
	}
	else
	{
		return(GET_ENUM((*ptr1), A_PtfSynth_RiskNatEn) -
				GET_ENUM((*ptr2), A_PtfSynth_RiskNatEn));
	}
}


/************************************************************************
**
**  Function    :   FIN_CmpPtfSynthPtfDateGlobal()
**
**  Description :   Synthetics sorted by portfolio id, date, global lines
**                  (detail level)
**
**  Arguments   :   ptr1   pointer on dynamic structure type A_PtfSynth
**                  ptr2   pointer on dynamic structure type A_PtfSynth
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation  	:   REF6912 - CSY - 010810
**  Modification:   REF7395 - CSY - 020425: STATIC to EXTERN
**
*************************************************************************/
STATIC int FIN_CmpPtfSynthPtfDateGlobal(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
	/* Portfolio */
	if (GET_ID((*ptr1), A_PtfSynth_PtfId) == GET_ID((*ptr2), A_PtfSynth_PtfId))
	{
	    /* Date */
        if (DATETIME_CMP(GET_DATETIME((*ptr1), A_PtfSynth_InitialDate),
		                GET_DATETIME((*ptr2), A_PtfSynth_InitialDate)) == 0)
        {
            /* level global : A_PtfSynth_MktSegtId null and A_PtfSynth_InstrId null */
            if (IS_NULLFLD((*ptr1), A_PtfSynth_MktSegtId)
                && IS_NULLFLD((*ptr1), A_PtfSynth_InstrId) &&
                IS_NULLFLD((*ptr2), A_PtfSynth_MktSegtId)
                && IS_NULLFLD((*ptr2), A_PtfSynth_InstrId))
            {
                return (0);
            }
            else if (IS_NULLFLD((*ptr1), A_PtfSynth_MktSegtId)
                && IS_NULLFLD((*ptr1), A_PtfSynth_InstrId) &&
                (IS_NULLFLD((*ptr2), A_PtfSynth_MktSegtId) == FALSE
                || IS_NULLFLD((*ptr2), A_PtfSynth_InstrId) == FALSE))
            {
                /* put global lines before detail lines */
                return (-1);
            }
            else
            {
                return (1);
            }
        }
        else
        {
	        return(DATETIME_CMP(GET_DATETIME((*ptr1), A_PtfSynth_InitialDate),
		                GET_DATETIME((*ptr2), A_PtfSynth_InitialDate)));
        }
	}
	else
	{
	    return(CMP_ID(GET_ID((*ptr1), A_PtfSynth_PtfId) , GET_ID((*ptr2), A_PtfSynth_PtfId))); /* DLA - REF9089 - 030508 */
	}
}

/************************************************************************
**
**  Function    :   FIN_CmpPtfSynthPtfPspDate()
**
**  Description :   Synthetics sorted by portfolio id, psp id, date
**
**  Arguments   :   ptr1   pointer on dynamic structure type A_PtfSynth
**                  ptr2   pointer on dynamic structure type A_PtfSynth
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation  	:   REF9834 - TEB - 040909
**
*************************************************************************/
STATIC int FIN_CmpPtfSynthPtfPspDate(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
	/* Portfolio */
	if (GET_ID((*ptr1), A_PtfSynth_PtfId) == GET_ID((*ptr2), A_PtfSynth_PtfId))
	{
		/* PSP */
		if (GET_ID((*ptr1), A_PtfSynth_PSPId) == GET_ID((*ptr2), A_PtfSynth_PSPId))
		{
			/* Date */
			return(DATETIME_CMP(GET_DATETIME((*ptr1), A_PtfSynth_InitialDate),
							GET_DATETIME((*ptr2), A_PtfSynth_InitialDate)));
		}
		else
		{
			return(CMP_ID(GET_ID((*ptr1), A_PtfSynth_PSPId) , GET_ID((*ptr2), A_PtfSynth_PSPId)));
		}
	}
	else
	{
	    return(CMP_ID(GET_ID((*ptr1), A_PtfSynth_PtfId) , GET_ID((*ptr2), A_PtfSynth_PtfId)));
	}
}

/************************************************************************
**
**  Function    :   FIN_FilterPtfSynthChild()
**
**  Description :   Extract synthetics of children portfolios
**                  Used by hierarchy tools function DBA_ExtractHierEltRecWithFilterSt()
**                  return TRUE  -> record must be extract
**                         FALSE -> record musn't be extract
**
**  Arguments   :   dynSt      dynamic structure pointer
**                  dynStTp    dynamic structure definition
**		            ptfPtr  parameter dynamic structure pointer
**
**  Return      :   TRUE or FALSE
**
**  Creation	:   REF3637 - RAK - 000309
**
*************************************************************************/
STATIC int FIN_FilterPtfSynthChild(DBA_DYNFLD_STP dynSt,
			                       DBA_DYNST_ENUM dynStTp,
                                   DBA_DYNFLD_STP ptfPtr)
{
    if (GET_ID(dynSt, A_PtfSynth_PtfId) == GET_ID(ptfPtr, A_Ptf_Id))
        return(TRUE);

    return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_FilterDetSynth()
**
**  Description :   Extract detailled synthetics
**                  Used by hierarchy tools function DBA_ExtractHierEltRec()
**                  return TRUE  -> record must be extract
**                         FALSE -> record musn't be extract
**
**  Arguments   :   dynSt      dynamic structure pointer
**                  dynStTp    dynamic structure definition
**
**  Return      :   TRUE or FALSE
**
*************************************************************************/
STATIC int FIN_FilterDetSynth(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP notUse) /* REF7264 - LJE - 020131 */
{
    if (IS_NULLFLD(dynSt, A_PtfSynth_InstrId) == FALSE)
	return(TRUE);
    else
	return(FALSE); 	/* Don't extract synthetics whitout instrument id */
}

/************************************************************************
**
**  Function    :   FIN_FilterChildrenPtf()
**
**  Description :   Extract children portfolio
**                  Used by hierarchy tools function DBA_ExtractHierEltRecWithFilterSt()
**                  return TRUE  -> record must be extract
**                         FALSE -> record musn't be extract
**
**  Arguments   :   dynSt      dynamic structure pointer
**                  dynStTp    dynamic structure definition
**		            ptfPtr  parameter dynamic structure pointer
**
**  Return      :   TRUE or FALSE
**
**  Creation	:   REF3637 - RAK - 000309
**
*************************************************************************/
STATIC int FIN_FilterChildrenPtf(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP notUse) /* REF7264 - LJE - 020131 */
{
    /* return portfolio with a hierarchy parent */
    if (IS_NULLFLD(dynSt, A_Ptf_HierPortId) == FALSE)
        return(TRUE);
    else
        return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_FilterPtfSynthParent()
**
**  Description :   Extract synthetics of parent portfolio
**                  Used by hierarchy tools function DBA_ExtractHierEltRecWithFilterSt()
**                  return TRUE  -> record must be extract
**                         FALSE -> record musn't be extract
**
**  Arguments   :   dynSt      dynamic structure pointer
**                  dynStTp    dynamic structure definition
**		            ptfPtr  parameter dynamic structure pointer
**
**  Return      :   TRUE or FALSE
**
**  Creation	:   REF3637 - RAK - 000309
**  Modification:   REF7395 - CSY - 020416: STATIC to EXTERN
**
*************************************************************************/
STATIC int FIN_FilterPtfSynthParent(DBA_DYNFLD_STP dynSt,
			                        DBA_DYNST_ENUM dynStTp,
                                    DBA_DYNFLD_STP ptfPtr)
{
    if (GET_ID(dynSt, A_PtfSynth_PtfId) == GET_ID(ptfPtr, Io_Id_Id))
        return(TRUE);
    return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_FilterGlobalSynthCompHist()
**
**  Description :   Extract global synthetics for given portfolio id.
**                  Used by hierarchy tools function DBA_ExtractHierEltRecWithFilterSt()
**                  return TRUE  -> record must be extract
**                         FALSE -> record musn't be extract
**
**  Arguments   :   dynSt      dynamic structure pointer
**                  dynStTp    dynamic structure definition
**		            ptfPtr     parameter dynamic structure pointer
**
**  Return      :   TRUE or FALSE
**
**  Creation	:   REF8354 - YST - 021206
**
*************************************************************************/
STATIC int FIN_FilterGlobalSynthCompHist(DBA_DYNFLD_STP    dynSt,
                                    DBA_DYNST_ENUM      dynStTp,
                                    DBA_DYNFLD_STP      ptfPtr)
{
    if (GET_ID(dynSt, A_PtfSynth_PtfId) == GET_ID(ptfPtr, A_Ptf_Id) &&
        IS_NULLFLD(dynSt, A_PtfSynth_InstrId) == TRUE &&
        IS_NULLFLD(dynSt, A_PtfSynth_MktSegtId) == TRUE &&
        IS_NULLFLD(dynSt, A_PtfSynth_GridId) == TRUE)
        return(TRUE);
    else
        return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_FilterGridSynthCompHist()
**
**  Description :   Extract synthetics of grid level for given portfolio id
**                  which were retrieved from database (A_PtfSynth_Id > 0).
**                  Used by hierarchy tools function DBA_ExtractHierEltRecWithFilterSt()
**                  return TRUE  -> record must be extract
**                         FALSE -> record musn't be extract
**
**  Arguments   :   dynSt      dynamic structure pointer
**                  dynStTp    dynamic structure definition
**		            ptfPtr     parameter dynamic structure pointer
**
**  Return      :   TRUE or FALSE
**
**  Creation	:   REF8354 - YST - 021217
**
*************************************************************************/
STATIC int FIN_FilterGridSynthCompHist(DBA_DYNFLD_STP    dynSt,
                                    DBA_DYNST_ENUM      dynStTp,
                                    DBA_DYNFLD_STP      ptfPtr)
{
    if (GET_ID(dynSt, A_PtfSynth_PtfId) == GET_ID(ptfPtr, A_Ptf_Id) &&
        GET_ID(dynSt, A_PtfSynth_Id) > 0 &&
        IS_NULLFLD(dynSt, A_PtfSynth_InstrId) == TRUE &&
        IS_NULLFLD(dynSt, A_PtfSynth_MktSegtId) != TRUE)
        return(TRUE);
    else
        return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_FilterSynthCompHist()
**
**  Description :   Extract synthetics of grid level for given portfolio id
**                  Used by hierarchy tools function DBA_ExtractHierEltRecWithFilterSt()
**                  return TRUE  -> record must be extract
**                         FALSE -> record musn't be extract
**
**  Arguments   :   dynSt      dynamic structure pointer
**                  dynStTp    dynamic structure definition
**		            ptfPtr     parameter dynamic structure pointer
**
**  Return      :   TRUE or FALSE
**
**  Creation	:   REF9834 - TEB - 041207
**
*************************************************************************/
STATIC int FIN_FilterSynthCompHist(DBA_DYNFLD_STP      dynSt,
								   DBA_DYNST_ENUM      dynStTp,
								   DBA_DYNFLD_STP      ptfPtr)
{
    if (GET_ID(dynSt, A_PtfSynth_PtfId) == GET_ID(ptfPtr, A_Ptf_Id) &&
        IS_NULLFLD(dynSt, A_PtfSynth_InstrId) == TRUE &&
        IS_NULLFLD(dynSt, A_PtfSynth_MktSegtId) != TRUE)
        return(TRUE);
    else
        return(FALSE);
}


/************************************************************************
**
**  Function    :   FIN_FilterPtfPSP()
**
**  Description :   Extract PSP or received ptf
**                  return TRUE  -> record must be extract
**                         FALSE -> record musn't be extract
**
**  Arguments   :   dynSt      dynamic structure pointer
**                  dynStTp    dynamic structure definition
**		            ptfPtr     parameter dynamic structure pointer
**
**  Return      :   TRUE or FALSE
**
**  Creation	:   REF9357 - RAK - 040205
**
*************************************************************************/
STATIC int FIN_FilterPtfPSP(DBA_DYNFLD_STP    dynSt,
                            DBA_DYNST_ENUM    dynStTp,
                            DBA_DYNFLD_STP    ptfPtr)
{
    if (GET_ID(dynSt, A_PerfStorageParam_ObjId) == GET_ID(ptfPtr, A_Ptf_Id))
        return(TRUE);
    else
        return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_FilterParentPtfPSP()
**
**  Description :   Extract PSP or received ptf
**                  return TRUE  -> record must be extract
**                         FALSE -> record musn't be extract
**
**  Arguments   :   dynSt      dynamic structure pointer
**                  dynStTp    dynamic structure definition
**		            ptfPtr     parameter dynamic structure pointer
**
**  Return      :   TRUE or FALSE
**
**  Creation	:   PMSTA02013 - RAK - 071112
**
*************************************************************************/
STATIC int FIN_FilterParentPtfPSP(DBA_DYNFLD_STP    dynSt,
                            DBA_DYNST_ENUM    dynStTp,
                            DBA_DYNFLD_STP    ptfPtr)
{
    if (GET_ID(dynSt, A_PerfStorageParam_ObjId) == GET_ID(ptfPtr, A_Ptf_HierPortId))

        return(TRUE);
    else
        return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_VerifIntermSynth()
**
**  Description :   Extract children portfolio
**                  Used by hierarchy tools function DBA_ExtractHierEltRecWithFilterSt()
**                  return TRUE  -> record must be extract
**                         FALSE -> record musn't be extract
**
**  Arguments   :   synthTab        tab of synth
**                  synth number    number of synth
**
**
**  Return      :   TRUE or FALSE
**
**  Creation	:   REF??? - CSY - 010111
**
*************************************************************************/

/*
STATIC FLAG_T  FIN_VerifIntermSynth(DBA_DYNFLD_STP* synthTab, int synthNbr)
{
    return TRUE;
}*/

/************************************************************************
**
**  Function    :   FIN_FilterPtfSynthByPSPGlob()
**
**  Description :   Extract synthetics for given PSP id and global.
**                  Used by hierarchy tools function DBA_ExtractHierEltRecWithFilterSt()
**                  return TRUE  -> record must be extract
**                         FALSE -> record musn't be extract
**
**  Arguments   :   dynSt      dynamic structure pointer
**                  dynStTp    dynamic structure definition
**		            pspPtr     parameter dynamic structure pointer
**
**  Return      :   TRUE or FALSE
**
**  Creation	:   REF9834 - TEB - 041130
**
*************************************************************************/
STATIC int FIN_FilterPtfSynthByPSPGlob(DBA_DYNFLD_STP	dynSt,
									   DBA_DYNST_ENUM   dynStTp,
									   DBA_DYNFLD_STP   pspPtr)
{
	if (IS_NULLFLD(dynSt, A_PtfSynth_PSPId) == TRUE ||
		GET_ID(dynSt,  A_PtfSynth_PSPId) == GET_ID(pspPtr, A_PerfStorageParam_Id))
        return(TRUE);
    else
        return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_FilterPtfSynthByPSPInfo()
**
**  Description :   Extract synthetics for given PSP
**                  return TRUE  -> record must be extract
**                         FALSE -> record musn't be extract
**
**  Arguments   :   dynSt      dynamic structure pointer
**                  dynStTp    dynamic structure definition
**		            pspPtr     parameter dynamic structure pointer
**
**  Return      :   TRUE or FALSE
**
**  Creation	:   PMSTA-19202 - LJE - 150109
**
*************************************************************************/
STATIC int FIN_FilterPtfSynthByPSPInfo(DBA_DYNFLD_STP	dynSt,
                                       DBA_DYNST_ENUM   dynStTp,
                                       DBA_DYNFLD_STP   pspPtr)
{
    if (GET_ID(dynSt, A_PtfSynth_PtfId) == GET_ID(pspPtr, A_PerfStorageParam_ObjId) &&
        GET_ID(dynSt, A_PtfSynth_CurrId) == GET_ID(pspPtr, A_PerfStorageParam_CurrId))
    {
        if (IS_NULLFLD(pspPtr, A_PerfStorageParam_GridId) == TRUE && IS_NULLFLD(dynSt, A_PtfSynth_MktSegtId) == FALSE)
        {
            return(FALSE);
        }

		if (IS_NULLFLD(dynSt, A_PtfSynth_GridId) == FALSE &&
            (GET_ID(dynSt, A_PtfSynth_GridId) != GET_ID(pspPtr, A_PerfStorageParam_GridId)))
        {
            return(FALSE);
        }
        return(TRUE);
    }

    return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_FilterPtfFirstStoredCompPeriod()
**
**  Description :   Filter Portfolio first stored Comp Periods
**
**
**  Creation	:   PMSTA-50467 - JBC - 221222
**
*************************************************************************/
EXTERN int FIN_FilterPtfFirstStoredCompPeriod(DBA_DYNFLD_STP dynSt,
			                DBA_DYNST_ENUM dynStTp,
                            DBA_DYNFLD_STP ptfPtr)
{
    if (static_cast<PerfCompPeriodTechNatEn>(GET_ENUM(dynSt,S_PerfComputationPeriod_TechNatEn)) == PerfCompPeriodTechNatEn::PerfFirstStored
        && GET_ID(dynSt, S_PerfComputationPeriod_PtfId) == GET_ID(ptfPtr, A_Ptf_Id))
    {
        return(TRUE);
    }
    return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_FilterPtfFirstCompPeriod()
**
**  Description :   Filter Portfolio records for perf_first_op_d and psp std_perf_first_stored_d
**
**
**  Creation	:   PMSTA-50467 - JBC - 221222
**
*************************************************************************/
EXTERN int FIN_FilterPtfFirstCompPeriod(DBA_DYNFLD_STP dynSt,
			                DBA_DYNST_ENUM dynStTp,
                            DBA_DYNFLD_STP ptfPtr)
{
    if ((static_cast<PerfCompPeriodTechNatEn>(GET_ENUM(dynSt,S_PerfComputationPeriod_TechNatEn)) == PerfCompPeriodTechNatEn::PerfFirstOp
		|| static_cast<PerfCompPeriodTechNatEn>(GET_ENUM(dynSt,S_PerfComputationPeriod_TechNatEn)) == PerfCompPeriodTechNatEn::PerfFirstStored)
        && GET_ID(dynSt, S_PerfComputationPeriod_PtfId) == GET_ID(ptfPtr, A_Ptf_Id))
    {
        return(TRUE);
    }
    return(FALSE);
}


/************************************************************************
**
**  Function    :   FIN_FilterFirstCompPeriod()
**
**  Description :   Filter all first op or stored data Comp Periods
**
**
**  Creation	:   WEALTH-15270 - JBC - 20241023
**
*************************************************************************/
EXTERN int FIN_FilterFirstCompPeriod(DBA_DYNFLD_STP dynSt,
			                DBA_DYNST_ENUM,
                            DBA_DYNFLD_STP)
{
    if ((static_cast<PerfCompPeriodTechNatEn>(GET_ENUM(dynSt,S_PerfComputationPeriod_TechNatEn)) == PerfCompPeriodTechNatEn::PerfFirstOp
		|| static_cast<PerfCompPeriodTechNatEn>(GET_ENUM(dynSt,S_PerfComputationPeriod_TechNatEn)) == PerfCompPeriodTechNatEn::PerfFirstStored))
    {
        return(TRUE);
    }
    return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_FilterHierFirstOpCompPeriod()
**
**  Description :   Filter First Op dates for hierarchy
**
**
**  Creation	:   WEALTH-15270 - JBC - 20241023
**
*************************************************************************/
EXTERN int FIN_FilterHierFirstOpCompPeriod(DBA_DYNFLD_STP dynSt,
			                DBA_DYNST_ENUM dynStTp,
                            DBA_DYNFLD_STP ptfPtr)
{
    if (static_cast<PerfCompPeriodTechNatEn>(GET_ENUM(dynSt,S_PerfComputationPeriod_TechNatEn)) == PerfCompPeriodTechNatEn::PerfFirstOp
        && ((IS_NULLFLD(dynSt, S_PerfComputationPeriod_HierPortId) == false && GET_ID(dynSt, S_PerfComputationPeriod_HierPortId) == GET_ID(ptfPtr, A_Ptf_Id))
			|| GET_ID(dynSt, S_PerfComputationPeriod_PtfId) == GET_ID(ptfPtr, A_Ptf_Id))
		)
    {
        return(TRUE);
    }
    return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_FilterPtfDbCompPeriod()
**
**  Description :   Filter Portfolio db Comp Periods
**
**
**  Creation	:   PMSTA-50467 - JBC - 221222
**
*************************************************************************/
EXTERN int FIN_FilterPtfDbCompPeriod(DBA_DYNFLD_STP dynSt,
			                DBA_DYNST_ENUM dynStTp,
                            DBA_DYNFLD_STP ptfPtr)
{
    if (static_cast<PerfCompPeriodTechNatEn>(GET_ENUM(dynSt,S_PerfComputationPeriod_TechNatEn)) == PerfCompPeriodTechNatEn::Database 
        && GET_ID(dynSt, S_PerfComputationPeriod_PtfId) == GET_ID(ptfPtr, A_Ptf_Id))
    {
        return(TRUE);
    }
    return(FALSE);
}


/************************************************************************
**
**  Function    :   FIN_FilterDbCompPeriod()
**
**  Description :   Filter all db Perf Comp Periods
**
**
**  Creation	:   PMSTA-50467 - JBC - 221222
**
*************************************************************************/
EXTERN int FIN_FilterDbCompPeriod(DBA_DYNFLD_STP dynSt,
			                DBA_DYNST_ENUM dynStTp,
                            DBA_DYNFLD_STP unused)
{
    if (static_cast<PerfCompPeriodTechNatEn>(GET_ENUM(dynSt,S_PerfComputationPeriod_TechNatEn)) == PerfCompPeriodTechNatEn::Database)
    {
        return(TRUE);
    }
    return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_FilterPtfDomainCompPeriod()
**
**  Description :   Filter Portfolio Perf Comp Periods for domain based ranges
**
**
**  Creation	:   PMSTA-50467 - JBC - 221222
**
*************************************************************************/
EXTERN int FIN_FilterPtfDomainCompPeriod(DBA_DYNFLD_STP dynSt,
			                DBA_DYNST_ENUM dynStTp,
                            DBA_DYNFLD_STP ptfPtr)
{
    if (static_cast<PerfCompPeriodTechNatEn>(GET_ENUM(dynSt,S_PerfComputationPeriod_TechNatEn)) == PerfCompPeriodTechNatEn::Domain
        && GET_ID(dynSt, S_PerfComputationPeriod_PtfId) == GET_ID(ptfPtr, A_Ptf_Id))
    {
        return(TRUE);
    }
    return(FALSE);
}


/************************************************************************
**
**  Function    :   FIN_FilterDomainCompPeriod()
**
**  Description :   Filter all  Perf Comp Periods for domain based ranges
**
**
**  Creation	:   PMSTA-50467 - JBC - 221222
**
*************************************************************************/
EXTERN int FIN_FilterDomainCompPeriod(DBA_DYNFLD_STP dynSt,
			                DBA_DYNST_ENUM dynStTp,
                            DBA_DYNFLD_STP notUsed)
{
    if (static_cast<PerfCompPeriodTechNatEn>(GET_ENUM(dynSt,S_PerfComputationPeriod_TechNatEn)) == PerfCompPeriodTechNatEn::Domain)
    {
        return(TRUE);
    }
    return(FALSE);
}


/************************************************************************
**
**  Function    :   FIN_FilterPtfCombinedCompPeriod()
**
**  Description :   Return the Final Perf Comp Periods for a ptf
**
**
**  Creation	:   PMSTA-50467 - JBC - 221222
**
*************************************************************************/
EXTERN int FIN_FilterPtfPerfCompPeriod(DBA_DYNFLD_STP dynSt,
			                DBA_DYNST_ENUM dynStp,
                            DBA_DYNFLD_STP ptfPtr)
{
    if (static_cast<PerfCompPeriodTechNatEn>(GET_ENUM(dynSt,S_PerfComputationPeriod_TechNatEn)) == PerfCompPeriodTechNatEn::PtfMerged 
        && GET_ID(dynSt, S_PerfComputationPeriod_PtfId) == GET_ID(ptfPtr, A_Ptf_Id))
    {
        return(TRUE);
    }
    return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_FilterPerfCompPeriod()
**
**  Description :   Return the Final Merged Perf Comp Periods
**
**
**  Creation	:   PMSTA-50467 - JBC - 221222
**
*************************************************************************/
EXTERN int FIN_FilterPerfCompPeriod(DBA_DYNFLD_STP dynSt,
			                DBA_DYNST_ENUM,
                            DBA_DYNFLD_STP)
{
    if (static_cast<PerfCompPeriodTechNatEn>(GET_ENUM(dynSt,S_PerfComputationPeriod_TechNatEn)) == PerfCompPeriodTechNatEn::PtfMerged)
    {
        return(TRUE);
    }
    return(FALSE);
}


/************************************************************************
**
**  Function    :   FIN_FilterPerfCompPeriodForHier()
**
**  Description :   Return the Final periods for the entire hierarchy
**
**
**  Creation	:   PMSTA-50467 - JBC - 221222
**
*************************************************************************/
EXTERN int FIN_FilterPerfCompPeriodForHier(DBA_DYNFLD_STP dynSt,
			                DBA_DYNST_ENUM dynStp,
                            DBA_DYNFLD_STP ptfPtr)
{
     if (static_cast<PerfCompPeriodTechNatEn>(GET_ENUM(dynSt,S_PerfComputationPeriod_TechNatEn)) == PerfCompPeriodTechNatEn::PtfMerged 
        && (GET_ID(dynSt, S_PerfComputationPeriod_HierPortId) == GET_ID(ptfPtr, A_Ptf_Id)
			|| GET_ID(dynSt, S_PerfComputationPeriod_PtfId) == GET_ID(ptfPtr, A_Ptf_Id)))
    {
        return(TRUE);
    }
    return(FALSE);
}


/************************************************************************
**
**  Function    :   FIN_FilterPerfCompPeriodForVirtual()
**
**  Description :   Return the Merged periods for the 
**
**
**  Creation	:   PMSTA-50467 - JBC - 221222
**
*************************************************************************/
EXTERN int FIN_FilterPerfCompPeriodForVirtual(DBA_DYNFLD_STP dynSt,
			                DBA_DYNST_ENUM,
                            DBA_DYNFLD_STP)
{
     if (static_cast<PerfCompPeriodTechNatEn>(GET_ENUM(dynSt,S_PerfComputationPeriod_TechNatEn)) == PerfCompPeriodTechNatEn::PtfMerged)
    {
        return(TRUE);
    }
    return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_SortPtfByPerfCompBeginDate()
**
**  Description :   Sort portfolio in ascending order of perf comp begin d
**
**
**  Creation	:   PMSTA-50467 - JBC - 221222
**
*************************************************************************/
EXTERN int FIN_CmpCompPeriodBeginDate(DBA_DYNFLD_STP *pcp1, DBA_DYNFLD_STP *pcp2)
{
    /* ascending order of level */
    return(CMP_DYNFLD(*pcp1, *pcp2, S_PerfComputationPeriod_BeginDate, S_PerfComputationPeriod_BeginDate,
                             GET_FLD_TYPE(S_PerfComputationPeriod, S_PerfComputationPeriod_BeginDate)));
}

/************************************************************************
**
**  Function    :   FIN_CmpPtfDescPtfId()
**
**  Description :   Sort ptfs by desc ids (to put merge ptfs  id < 0 last)
**
**
**  Creation	:   PMSTA-50467 - JBC - 221222
**
*************************************************************************/
EXTERN int FIN_CmpPtfDescPtfId(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    return(CMP_ID(GET_ID((*ptr2), A_Ptf_Id), GET_ID((*ptr1), A_Ptf_Id)));
}


/************************************************************************
**
**  Function    :   FIN_GetPtfCompPeriods()
**
**  Description :   Compute the Perf Computation Dates for NIP Management
**
**  Arguments   :
**
**  Return      :   RET_CODE
**
**  Creation	:
**
*************************************************************************/
RET_CODE FIN_GetPtfCompPeriods(DBA_DYNFLD_STP   domainPtr,
	DBA_HIER_HEAD_STP hierHead,
	DBA_DYNFLD_STP   ptfPtr,
	DATETIME_T       fromDate,
	DATETIME_T       tillDate,
	DatePeriodVec & compPeriods)
{    

	compPeriods.clear();

	RET_CODE            ret = RET_SUCCEED;
    MemoryPool          mp;	
    OBJECT_ENUM         dimObject;
    DBA_GetObjectEnum(GET_DICT(domainPtr, A_Domain_DimPtfDictId), &dimObject);
         
    DBA_DYNFLD_STP *    mergedPeriodTab = NULLDYNSTPTR;
    int                 mergedPeriodNb = 0;

    /* check for merged comp periods  */
   	if (hierHead != nullptr && (ret = DBA_ExtractHierEltRecWithFilterSt(hierHead, 
                                    S_PerfComputationPeriod,
			                        FALSE, 
		                            FIN_FilterPtfPerfCompPeriod,
                                    ptfPtr,
                                    FIN_CmpCompPeriodBeginDate, 
                                    &mergedPeriodNb, &mergedPeriodTab)) != RET_SUCCEED)
	{
		return(ret);
	}

    mp.ownerPtr(mergedPeriodTab);

    /*
     * use all comp periods in range limited by domain
     */
	for(int i=0; i< mergedPeriodNb;i++)
	{
		DatePeriod compPeriod(GET_DATETIME(mergedPeriodTab[i],S_PerfComputationPeriod_BeginDate), GET_DATETIME(mergedPeriodTab[i],S_PerfComputationPeriod_EndDate));

		if(compPeriod.cmpBegin(tillDate) >= 0 || compPeriod.cmpEnd(fromDate) <= 0)
		{
			continue; // out of range
		}

		if(compPeriod.cmpBegin(fromDate) < 0)
        {
            compPeriod.setBegin(fromDate);
        }
		
        if(compPeriod.cmpEnd(tillDate) > 0)
        {
            compPeriod.setEnd(tillDate);
        }

		compPeriods.push_back(compPeriod);
	}

    if(compPeriods.empty())
	{
        DbiConnectionHelper  connHelper;
        /* check perf_first_op_d */
        if(IS_NULLFLD(ptfPtr, A_Ptf_PerfFirstOpDate))
        {
            DATETIME_T perfFirstOpDate;

            if(OPE_GetPtfPerfFirstOpDate(GET_ID(ptfPtr, A_Ptf_Id),perfFirstOpDate))
            {
				SET_DATETIME(ptfPtr,A_Ptf_PerfFirstOpDate,perfFirstOpDate);
            }   
        }
        
        // call get_ptf_inception_d        
        DBA_DYNFLD_STP  tmpDomainArg = mp.allocDynst(FILEINFO, A_Domain);
	    DBA_DYNFLD_STP  aCompPeriod = mp.allocDynst(FILEINFO, A_PerfComputationPeriod);	    

	    SET_ID(tmpDomainArg, A_Domain_PtfObjId, GET_ID(ptfPtr, A_Ptf_Id));
	    SET_FLAG(tmpDomainArg, A_Domain_LoadHierFlg, GET_FLAG(domainPtr, A_Domain_LoadHierFlg));
	    SET_FLAG(tmpDomainArg, A_Domain_LoadNonDiscretFlg, GET_FLAG(domainPtr, A_Domain_LoadNonDiscretFlg));
	    SET_FLAG(tmpDomainArg, A_Domain_LoadHierHistFlg, GET_FLAG(domainPtr, A_Domain_LoadNonDiscretFlg));
	    SET_DATETIME(tmpDomainArg, A_Domain_InterpFromDate, fromDate);

        if ((ret = connHelper.dbaGet(Ptf, UNUSED, tmpDomainArg, &aCompPeriod)) != RET_SUCCEED)
	    {
		    return (ret);
	    }

		if(IS_NULLFLD(aCompPeriod, A_PerfComputationPeriod_BeginDate) == FALSE)
		{
		    DatePeriod compPeriod(std::max(GET_DATETIME(aCompPeriod, A_PerfComputationPeriod_BeginDate),fromDate),tillDate);
		    compPeriods.push_back(compPeriod);
		}
    }

    if(compPeriods.isValid() == false)
	{
	    compPeriods.clear();
    }

	if(compPeriods.empty())
	{
	    return RET_DBA_INFO_NODATA;
	}

	return(ret);
}


/************************************************************************
**
**  Function    :   FIN_UsePtfCompPeriods()
**
**  Description :   Get single range of perf computation
**
**  Arguments   :
**
**  Return      :   RET_CODE
**
**  Creation	:
**
*************************************************************************/
bool FIN_LimitByPtfCompPeriods(DBA_DYNFLD_STP   domainPtr,
	DBA_HIER_HEAD_STP hierHead,
	DBA_DYNFLD_STP   ptfPtr,
	DATETIME_T       *fromDate,
	DATETIME_T       *tillDate,
	DatePeriodVec &  compPeriods)
{    
	bool datesChanged = false;
	
    if(FIN_GetPtfCompPeriods(domainPtr, hierHead, ptfPtr,(*fromDate),(*tillDate),compPeriods) == RET_SUCCEED
		&& compPeriods.empty() == false)
	{
	    if (compPeriods[0].cmpBegin((*fromDate)) > 0)
	    {
            *fromDate = compPeriods[0].getBegin();
            datesChanged = true;
	    }
		if (compPeriods[compPeriods.size()-1].cmpEnd((*tillDate)) < 0)
	    {
            *tillDate = compPeriods[compPeriods.size()-1].getEnd();
            datesChanged = true;		
	    }
	}	
    return datesChanged;
}

/************************************************************************
**      END  finsrv05.c                                          UNICIBLE
*************************************************************************/
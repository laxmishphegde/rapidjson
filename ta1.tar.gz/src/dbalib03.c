/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DBALIB03_C

/************************************************************************
**      Include files
*************************************************************************/
#ifdef AIX
#include <math.h>
#else
#include <cmath>
#endif

#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H

#include "unidef.h"     /* Mandatory */
#include "gen.h"
#include "dba.h"
#include "fin.h"
#include "cmp.h"
#include "ope.h"		/*  FIH-REF10606-040927 for function OPE_GetOpTableFromDynFld   */
#include "casemgt.h"	/* PMSTA10444-CHU-110504 */
#include "fmtlib01.h"   /*  HFI-PMSTA-16139-130328  */

#ifndef TLS_H
#include "tls.h"
#endif

#ifndef HIER_H
#include "hier.h"
#endif

#include "scptyl.h"

#ifdef NT
#include <crtdbg.h>
#endif

#include "dbisqlexecbyblock.h"

/************************************************************************
**      External entry points
**
** DBA_UpdThird()               Update a third_party.
** DBA_InsThirdId()             Create a new third_party.
** DBA_UpdApplComment()         Update a appl_comment.
** DBA_InsApplCommentById()     Create a new appl_comment.
** DBA_UpdDomain()              Update a domain.
** DBA_InsDomainById()          Create a new domain.
** DBA_CheckDynStNumbers()      Check infinity and not a real number error.
** DBA_SetMagicDate()           Set magic date to not mandatory date (but mandatory in db).
** DBA_HideMagicDate()          Set magic date to null.
** DBA_GroupScriptDef()         Group received script definition in one script definition string.
** DBA_InsApplUserById()        Create a new user.
** DBA_CheckDbAdminUser()       Verify that the given user is belonging to an administration group.
** DBA_ChangePasswd()           Change the password of the given user.
** DBA_InsPtfSynth()            Insert portfolio synthetics by block.
** DBA_DelPtfSynth()            Delete portfolio synthetics by block.
** DBA_SelExtStratElt()         Select current extended strategy element for received strategy.
** DBA_NewFctResult()           Create a new function result.
** DBA_CopyFtRate()             Copy logical attributes with ud fields.
** DBA_ScreenSelect             Returns the screen which must be used
** DBA_CheckDboUser()              Verify that the given user is a database owner
**
*************************************************************************/

extern bool EV_ForceOutboxInsert; /*PMSTA-49443-Lalby - 07062022- Ease outbox records generation testing: exclude schema validation check for testing purpose*/
/************************************************************************
**      Local functions
**
** DBA_GroupScriptDefCmp()	Comparison function used fro group script definitions.
** DBA_CmpPtfSynthPtf() 	Portfolio synthetics table is sort by portfolio identifier.
*************************************************************************/

/************************************************************************
**      Static definitions & data
*************************************************************************/
STATIC int 	DBA_GroupScriptDefCmp(DBA_DYNFLD_STP*,  DBA_DYNFLD_STP*);
STATIC int 	DBA_CmpPtfSynthPtf(DBA_DYNFLD_STP*, DBA_DYNFLD_STP*);
STATIC int  DBA_FilterCrtPtfSynth(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);
STATIC int  DBA_FilterPtfSynthParStor(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);

STATIC RET_CODE DBA_FamilyOrderCreateAccess(EXTOP_ACTION_ENUM, DBA_DYNFLD_STP*,
                                            int, int, DBA_ACCESS_STP*, int*,
                                            DBA_ACCESS_STP*, int*,
                                            DBA_DYNFLD_STP*,
                                            FLAG_T*,			/* REF4083 - SSO - 991027 */
											DBA_DYNFLD_STP,     /* REF7550 - CHU - 020527 */
	                                        FLAG_T*,            /*  FIH-REF10606-040930 */
	                                        DbiConnectionHelper &dbiConnHelper);  /*  PMSTA-44673 - DDV - 210426 */

STATIC void DBA_FamilyOrderOnError(DBA_DYNFLD_STP*, int, int, DBA_DYNFLD_STP*);

STATIC RET_CODE DBA_InsPtfSynthPrep(PTR, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP,
			                        PTR, DBA_INSPTFSYNTH_STP);	/* PMSTA02013 - RAK - 071112 */

STATIC RET_CODE DBA_FamilyOrderSaveCaseManagement(EXTOP_ACTION_ENUM, DBA_DYNFLD_STP*, int, DBA_ACCESS_STP, int, int*, DBA_DYNFLD_STP); /* PMSTA07121-CHU-081030 */
STATIC RET_CODE DBA_FamilyOrderAccess(EXTOP_ACTION_ENUM, DBA_ACCESS_STP, int, DBA_ACCESS_STP, int, DBA_DYNFLD_STP*, int, int*, int, FLAG_T, DBA_DYNFLD_STP);
STATIC RET_CODE DBA_UpdPtfSynthLastFinalDate(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DBA_INSPTFSYNTH_STP, int, int);	/* PMSTA02013 - RAK - 071112 */
STATIC RET_CODE DBA_InsertEvent(OBJECT_ENUM, DBA_DYNST_ENUM, DBA_DYNFLD_STP, DBA_DYNFLD_STP, SUBSCRIPTION_ACTION_ENUM, DBA_DYNFLD_STP, EVENT_NATURE_ENUM,
                                SubscriptionModuleEn, DbiConnection&, FLAG_T, CODE_T);
STATIC void FIN_LocCaseSplit(DBA_DYNFLD_STP,
                             DBA_DYNFLD_STP*,
                             int,
                             FLAG_T*,
                             DBA_DYNFLD_STP**,
                             int*,
                             FLAG_T**);

STATIC RET_CODE DBA_CreateAndPopulateNewSessionId(DBA_DYNFLD_STP,
                                                  DBA_DYNFLD_STP,
                                                  DBA_DYNFLD_STP,
                                                  int,
                                                  DBA_DYNFLD_STP**,
                                                  int,
                                                  DBA_DYNFLD_STP**,
                                                  int,
                                                  DBA_DYNFLD_STP**,
                                                  int,
                                                  DBA_DYNFLD_STP**,
                                                  int,
                                                  DBA_DYNFLD_STP**,
                                                  int*,
                                                  DBA_DYNFLD_STP**,
                                                  int*);

/************************************************************************
**      FONCTIONS
************************************************************************/


/************************************************************************
**  Function    :   DBA_UpdManager
**
**  Description :   Update an existing manager.
**
**  Arguments   :   object        Mgr.
**  		        inputSt 	  A_Mgr
**                  inputData     A_Mgr data.
**                  connectNo     Connection number.
**                  msgStructPtr  Kind of error message.
**
**  Return      :   RET_SUCCEED if success, or error code
**
**  Creation	:   HFI-PMSTA-26550-171120
**
*************************************************************************/
RET_CODE DBA_UpdManager(OBJECT_ENUM          ,
                        DBA_DYNST_ENUM       ,
                        DBA_DYNFLD_STP       inputData,
                        DbiConnectionHelper& dbiConnHelper)
{
    RET_CODE  retCode = RET_SUCCEED;
	DATETIME_T validDate, expirDate;
	MemoryPool mp;

	validDate.date = 0;
	validDate.time = 0;

	expirDate.date = 0;
	expirDate.time = 0;

	/* Check arguments */
	if (inputData == NULL)
	{
		MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_UpdManager", "inputData");
		retCode = RET_GEN_ERR_INVARG;
	}

	/***** UPDATE STANDARD PAR PROC STOCKEE SQL *****/
    if (retCode == RET_SUCCEED)
    {
        /* WEALTH-6877 - n.sathish - 20240419 */
        /*** Check if role modified ***/
        DBA_DYNFLD_STP sMgr = mp.allocDynst(FILEINFO, S_Mgr);
        DBA_DYNFLD_STP aMgr = mp.allocDynst(FILEINFO, A_Mgr);
        SET_CODE(sMgr, A_Mgr_Cd, GET_CODE(inputData, A_Mgr_Cd));
        if ((dbiConnHelper.dbaGet(Mgr, UNUSED, sMgr, &aMgr) == RET_SUCCEED)
            && (GET_ENUM(aMgr, A_Mgr_WuiRoleEn) != GET_ENUM(inputData, A_Mgr_WuiRoleEn)))
        {
            /* WEALTH-7602 - FME- 20240527 */
            AAALogger::get(AAALogger::Logger::UserAccess).prepareInfoT("Manager '{manager}' role modified to '{role}'", GET_CODE(inputData, A_Mgr_Cd) , DBA_GetPermValName(Mgr, A_Mgr_WuiRoleEn, GET_ENUM(inputData, A_Mgr_WuiRoleEn)))->tag("temn.log.type", "SIEM")->log();;
        }

    	retCode = dbiConnHelper.dbaUpdate(Mgr, DBA_ROLE_STANDARD_UPDATE, inputData);
    }

	/***** UPDATE THE PASSWORD if necessary     *****/
    if ((retCode == RET_SUCCEED) &&
        (IS_NULLFLD(inputData, A_Mgr_Password) == FALSE))
    {
    	/* PMSTA-30212 - RAK - 180216 - New table password */
		DBA_DYNFLD_STP userPwdStp = mp.allocDynst(FILEINFO, A_ApplUserPassword);

		SET_ID(userPwdStp,   A_ApplUserPassword_UserId,				GET_ID(inputData, A_Mgr_UserId));
		SET_INFO(userPwdStp, A_ApplUserPassword_CryptedPassword,	GET_INFO(inputData, A_Mgr_Password));
		SET_ID(userPwdStp,   A_ApplUserPassword_DataSecuProfId,		GET_ID(inputData, A_Mgr_DataSecuProfId));
		SET_ID(userPwdStp,   A_ApplUserPassword_DataSecuProf2Id,	GET_ID(inputData, A_Mgr_DataSecuProf2Id));

		retCode = dbiConnHelper.dbaUpdate(ApplUserPassword, DBA_ROLE_UPD_PASSWD, userPwdStp);
	}

	return retCode;
}


/************************************************************************
**  Function    :   DBA_InsManagerById
**
**  Description :   Create a new third party.
**
**  Arguments   :   object        Mgr.
**  		        inputSt 	  A_Mgr
**                  inputData     A_Mgr data.
**                  connectNo     Connection number.
**                  msgStructPtr  Kind of error message.
**
**  Return      :   RET_SUCCEED if success, or error code
**
**  Creation	:   HFI-PMSTA-26550-171120
**
*************************************************************************/
RET_CODE DBA_InsManagerById(OBJECT_ENUM          ,
                            DBA_DYNST_ENUM       ,
                            DBA_DYNFLD_STP       inputData,
                            DbiConnectionHelper& dbiConnHelper)
{
    RET_CODE  retCode = RET_SUCCEED;

	DATETIME_T validDate, expirDate;
	MemoryPool mp;

	validDate.date = 0;
	validDate.time = 0;

	expirDate.date = 0;
	expirDate.time = 0;

	/* Check arguments */
	if (inputData == NULL)
	{
		MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_InsManagerById", "inputData");
		retCode = RET_GEN_ERR_INVARG;
	}

	/***** INSERT STANDARD PAR PROC STOCKEE SQL *****/
    if (retCode == RET_SUCCEED)
    {
    	retCode = dbiConnHelper.dbaInsert(Mgr, DBA_ROLE_STANDARD_INSERT, inputData);
    }

	/***** UPDATE THE PASSWORD if necessary     *****/
    if ((retCode == RET_SUCCEED) &&
        (IS_NULLFLD(inputData, A_Mgr_Password) == FALSE))
    {
		/* PMSTA-30212 - RAK - 180216 - New table password */
		DBA_DYNFLD_STP userPwdStp = mp.allocDynst(FILEINFO, A_ApplUserPassword);

		SET_ID(userPwdStp, A_ApplUserPassword_UserId, GET_ID(inputData, A_Mgr_UserId));
		SET_INFO(userPwdStp, A_ApplUserPassword_CryptedPassword, GET_INFO(inputData, A_Mgr_Password));
		SET_ID(userPwdStp, A_ApplUserPassword_DataSecuProfId, GET_ID(inputData, A_Mgr_DataSecuProfId));
		SET_ID(userPwdStp, A_ApplUserPassword_DataSecuProf2Id, GET_ID(inputData, A_Mgr_DataSecuProf2Id));

		retCode = dbiConnHelper.dbaUpdate(ApplUserPassword, DBA_ROLE_UPD_PASSWD, userPwdStp);
    }

	return retCode;
}

/************************************************************************
**  Function    :   DBA_UpdThird
**
**  Description :   Update an existing third party.
**
**  Arguments   :   object        Third.
**  		        inputSt 	  A_Third
**                  inputData     A_Third data.
**                  connectNo     Connection number.
**                  msgStructPtr  Kind of error message.
**
**  Return      :   RET_SUCCEED if success, or error code
**
**  Creation	:   HFI-PMSTA-26550-171120
**
*************************************************************************/
RET_CODE DBA_UpdThird ( OBJECT_ENUM          ,
                        DBA_DYNST_ENUM       ,
                        DBA_DYNFLD_STP       inputData,
                        DbiConnectionHelper& dbiConnHelper)
{
    RET_CODE  retCode = RET_SUCCEED;
	DATETIME_T validDate, expirDate;
	MemoryPool mp;

	validDate.date = 0;
	validDate.time = 0;

	expirDate.date = 0;
	expirDate.time = 0;

	/* Check arguments */
	if (inputData == NULL)
	{
		MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_UpdThird", "inputData");
		retCode = RET_GEN_ERR_INVARG;
	}

	/***** UPDATE STANDARD PAR PROC STOCKEE SQL *****/
    if (retCode == RET_SUCCEED)
    {
    	retCode = dbiConnHelper.dbaUpdate(Third, DBA_ROLE_STANDARD_UPDATE, inputData);
    }

	/***** UPDATE THE PASSWORD if necessary     *****/
    if ((retCode == RET_SUCCEED) &&
        (IS_NULLFLD(inputData, A_Third_Password) == FALSE))
    {
		/* PMSTA-30212 - RAK - 180216 - New table password */
		DBA_DYNFLD_STP userPwdStp = mp.allocDynst(FILEINFO, A_ApplUserPassword);

		SET_ID(userPwdStp, A_ApplUserPassword_UserId, GET_ID(inputData, A_Third_UserId));
		SET_INFO(userPwdStp, A_ApplUserPassword_CryptedPassword, GET_INFO(inputData, A_Third_Password));
		SET_ID(userPwdStp, A_ApplUserPassword_DataSecuProfId, GET_ID(inputData, A_Third_DataSecuProfId));
		SET_ID(userPwdStp, A_ApplUserPassword_DataSecuProf2Id, GET_ID(inputData, A_Third_DataSecuProf2Id));

		retCode = dbiConnHelper.dbaUpdate(ApplUserPassword, DBA_ROLE_UPD_PASSWD, userPwdStp);
    }

	return retCode;
}


/************************************************************************
**  Function    :   DBA_InsThirdById
**
**  Description :   Create a new third party.
**
**  Arguments   :   object        Third.
**  		        inputSt 	  A_Third
**                  inputData     A_Third data.
**                  connectNo     Connection number.
**                  msgStructPtr  Kind of error message.
**
**  Return      :   RET_SUCCEED if success, or error code
**
**  Creation	:   HFI-PMSTA-26550-171120
**
*************************************************************************/
RET_CODE DBA_InsThirdById ( OBJECT_ENUM          ,
                            DBA_DYNST_ENUM       ,
                            DBA_DYNFLD_STP       inputData,
                            DbiConnectionHelper& dbiConnHelper)
{
    RET_CODE  retCode = RET_SUCCEED;
	DATETIME_T validDate, expirDate;
	MemoryPool mp;

	validDate.date = 0;
	validDate.time = 0;

	expirDate.date = 0;
	expirDate.time = 0;

	/* Check arguments */
	if (inputData == NULL)
	{
		MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_InsThirdById", "inputData");
		retCode = RET_GEN_ERR_INVARG;
	}

	/***** INSERT STANDARD PAR PROC STOCKEE SQL *****/
    if (retCode == RET_SUCCEED)
    {
    	retCode = dbiConnHelper.dbaInsert(Third, DBA_ROLE_STANDARD_INSERT, inputData);
    }

	/***** UPDATE THE PASSWORD if necessary     *****/
    if ((retCode == RET_SUCCEED) &&
        (IS_NULLFLD(inputData, A_Third_Password) == FALSE))
    {
		/* PMSTA-30212 - RAK - 180216 - New table password */
		DBA_DYNFLD_STP userPwdStp = mp.allocDynst(FILEINFO, A_ApplUserPassword);

		SET_ID(userPwdStp, A_ApplUserPassword_UserId, GET_ID(inputData, A_Third_UserId));
		SET_INFO(userPwdStp, A_ApplUserPassword_CryptedPassword, GET_INFO(inputData, A_Third_Password));
		SET_ID(userPwdStp, A_ApplUserPassword_DataSecuProfId, GET_ID(inputData, A_Third_DataSecuProfId));
		SET_ID(userPwdStp, A_ApplUserPassword_DataSecuProf2Id, GET_ID(inputData, A_Third_DataSecuProf2Id));

		/* PMSTA-30212- RAK - 180417 - reset password */
		retCode = dbiConnHelper.dbaUpdate(ApplUserPassword, DBA_ROLE_UPD_PASSWD, userPwdStp);
    }

	return retCode;
}

/************************************************************************
**  Function    :   DBA_UpdApplComment
**
**  Description :   Update a new appl_comment.
**
**  Arguments   :   object        The comment.
**  		        inputSt 	  A_ApplComment.
**                  inputData     A_ApplComment data.
**                  connectNo     Connection number.
**                  msgStructPtr  Kind of error message.
**
**  Return      :   RET_SUCCEED if success, or error code
**
**  Creation	:   OCS-37396 - TEB - 110310
**
*************************************************************************/
RET_CODE DBA_UpdApplComment(OBJECT_ENUM          ,
                            DBA_DYNST_ENUM       ,
                            DBA_DYNFLD_STP       inputData,
                            DbiConnectionHelper& dbiConnHelper)
{
	ID_T      userId  = ZERO_ID;
    RET_CODE  retCode = RET_SUCCEED;

	/* Check arguments */
	if (inputData == NULL)
	{
		MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_UpdApplComment", "inputData");
		return(RET_GEN_ERR_INVARG);
	}

	if(SYS_IsSrvMode() == TRUE)
	{
		if (DBA_GetUserInfo2(A_ApplUser_Id, (PTR) &userId, TRUE) == RET_SUCCEED)
        {
		    SET_ID(inputData, A_ApplComment_LastUserId, userId);
        }
        else
        {
		    SET_NULL_ID(inputData, A_ApplComment_LastUserId);
        }
	}

	/***** UPDATE STANDARD PAR PROC STOCKEE SQL *****/
    if (retCode == RET_SUCCEED)
    {
    	retCode = dbiConnHelper.dbaUpdate(ApplComment, DBA_ROLE_STANDARD_UPDATE, inputData);
    }

	return retCode;
}


/************************************************************************
**  Function    :   DBA_InsApplCommentById
**
**  Description :   Create a new domain.
**
**  Arguments   :   object        The comment.
**  		        inputSt 	  A_ApplComment.
**                  inputData     A_ApplComment data.
**                  connectNo     Connection number.
**                  msgStructPtr  Kind of error message.
**
**  Return      :   RET_SUCCEED if success, or error code
**
**  Creation	:   OCS-37396 - TEB - 110310
**
*************************************************************************/
RET_CODE DBA_InsApplCommentById(OBJECT_ENUM          ,
                                DBA_DYNST_ENUM       ,
                                DBA_DYNFLD_STP       inputData,
                                DbiConnectionHelper& dbiConnHelper)
{
	ID_T      userId  = ZERO_ID;
    RET_CODE  retCode = RET_SUCCEED;

	/* Check arguments */
	if (inputData == NULL)
	{
		MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_InsApplCommentById", "inputData");
		return(RET_GEN_ERR_INVARG);
	}

	if(SYS_IsSrvMode() == TRUE)
	{
		if (DBA_GetUserInfo2(A_ApplUser_Id, (PTR) &userId, TRUE) == RET_SUCCEED) {
			if (IS_NULLFLD(inputData, A_ApplComment_LastUserId) == TRUE)
			{
				SET_ID(inputData, A_ApplComment_LastUserId, userId);
			}
		}
	}

	/***** INSERT STANDARD PAR PROC STOCKEE SQL *****/
    if (retCode == RET_SUCCEED)
    {
    	retCode = dbiConnHelper.dbaInsert(ApplComment, DBA_ROLE_STANDARD_INSERT, inputData);
    }

	return retCode;
}

/************************************************************************
**  Function    :   DBA_UpdEventStatus
**
**  Description :   Update a event_status, and manage accepted/rejected request on orders
**
**  Arguments   :   object        The comment.
**  		        inputSt 	  A_EventStatus.
**                  inputData     A_EventStatust data.
**                  connectNo     Connection number.
**                  msgStructPtr  Kind of error message.
**
**  Return      :   RET_SUCCEED if success, or error code
**
**  Creation	:   PMSTA-17266 - DDV - 140127
**
*************************************************************************/
RET_CODE DBA_UpdEventStatus(OBJECT_ENUM          ,
                            DBA_DYNST_ENUM       inputSt,
                            DBA_DYNFLD_STP       inputData,
                            DbiConnectionHelper& dbiConnHelper)
{
    RET_CODE  retCode = RET_SUCCEED;
    FLAG_T    localTranFlg = FALSE, orderBackupRollbackFlg = FALSE;
    DbiConnection&       dbiConn = *dbiConnHelper.getConnection();

	/* Check arguments */
	if (inputData == NULL)
	{
		MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_UpdEventStatus", "inputData");
		return(RET_GEN_ERR_INVARG);
	}

    /* If event status reference a ext_order, manage accepted/rejected requests. */
    if (strcmp(GET_SYSNAME(inputData, A_EventStatus_EntitySqlName), "ext_operation") == 0)
    {
		if (dbiConn.isInTransaction() == false)
        {
            localTranFlg = TRUE;
			dbiConn.beginTransaction();
        }

        /* PMSTA-17985 - DDV - 140428 - Apply update_status_s id update_status is reached */
        if (IS_NULLFLD(inputData, A_EventStatus_UpdateStatus) == FALSE &&
            GET_ENUM(inputData, A_EventStatus_RequestStatusEn) == GET_ENUM(inputData, A_EventStatus_UpdateStateEn))
        {
    		if ((retCode = DBA_CreateTempTables(dbiConn, SUBD_DOM_OPE )) == RET_SUCCEED)
            {
                retCode = DBA_Update2(ExtOrder, DBA_ROLE_UPDATE_STATUS, A_EventStatus, inputData,
                                      DBA_SET_CONN|DBA_NO_CLOSE|DBA_NO_ERROR|DBA_NO_SUBS_AUDIT, dbiConn);
            }
        }

        if (retCode == RET_SUCCEED)
        {
            switch(GET_ENUM(inputData, A_EventStatus_ActionEn))
            {
                case Subscription_Action_Update:
                    /* PMSTA-17870 - DDV - 140429 */
	                GEN_GetApplInfo(ApplOrderBackupRollbackActivateFlg, &orderBackupRollbackFlg);

                    if (orderBackupRollbackFlg == TRUE)
                    {
                        switch(GET_ENUM(inputData, A_EventStatus_RequestStatusEn))
                        {
                            case EventRequestStatusEn_RequestAccepted:
                                /* delete backup record, store proc will do it only if no more recent request is pending */
                                retCode = DBA_Delete2(EOp, DBA_ROLE_UPDATE_REQUEST_STATUS, A_EventStatus, inputData,
									DBA_SET_CONN | DBA_NO_CLOSE | DBA_NO_ERROR | DBA_NO_SUBS_AUDIT, dbiConn);
                                break;
                            case EventRequestStatusEn_RequestRejected:
                                /* restore backup record */
                                retCode = DBA_Update2(EOp, DBA_ROLE_UPDATE_REQUEST_STATUS, A_EventStatus, inputData,
									DBA_SET_CONN | DBA_NO_CLOSE | DBA_NO_ERROR | DBA_NO_SUBS_AUDIT, dbiConn);
                                break;
                            default:
                                break;
                        }
                    }
                    break;

                case Subscription_Action_Cancel:
                    switch(GET_ENUM(inputData, A_EventStatus_RequestStatusEn))
                    {
                        case EventRequestStatusEn_RequestAccepted:
                            /* Update order's status to cancel */
                            /* create temp table SUBD_DOM_OPE (#dom_ope) */
                		    if ((retCode = DBA_CreateTempTables(dbiConn, SUBD_DOM_OPE )) == RET_SUCCEED)
                            {
                                retCode = DBA_Update2(ExtOrder, DBA_ROLE_CANCEL, A_EventStatus, inputData,
									DBA_SET_CONN | DBA_NO_CLOSE | DBA_NO_ERROR | DBA_NO_SUBS_AUDIT, dbiConn);
                            }
                            break;
                        case EventRequestStatusEn_RequestRejected:
                            /* nothing to do, record status has not been set to cancel. No backup record created for cancel action */
                            break;
                        default:
                            break;
                    }
                    break;
                default:
                    break;
            }
        }
    }

	/***** UPDATE STANDARD PAR PROC STOCKEE SQL *****/
    if (retCode == RET_SUCCEED)
    {
		retCode = DBA_Update2(EventStatus, DBA_ROLE_USESTOREDPROC, inputSt, inputData, DBA_SET_CONN | DBA_NO_CLOSE, dbiConn);
    }

    if (localTranFlg == TRUE)
    {
        dbiConn.endTransaction(retCode == RET_SUCCEED ? TRUE : FALSE);
    }

	return retCode;
}

/************************************************************************
**  Function    :   DBA_UpdDomain
**
**  Description :   Update a new domain.
**
**  Arguments   :   object        The domain.
**  		        inputSt 	  A_Domain.
**                  inputData     A_Domain data.
**                  connectNo     Connection number.
**                  msgStructPtr  Kind of error message.
**
**  Return      :   RET_SUCCEED if success, or error code
**
**  Creation	:   PMSTA-11273 - TEB - 110202
**
*************************************************************************/
RET_CODE DBA_UpdDomain(OBJECT_ENUM          ,
                       DBA_DYNST_ENUM       ,
                       DBA_DYNFLD_STP       inputData,
                       DbiConnectionHelper& dbiConnHelper)
{
	ID_T      userId  = ZERO_ID;
    RET_CODE  retCode = RET_SUCCEED;

	/* Check arguments */
	if (inputData == NULL)
	{
		MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_UpdDomain", "inputData");
		return(RET_GEN_ERR_INVARG);
	}

	if(SYS_IsSrvMode() == TRUE)
	{
		if (DBA_GetUserInfo2(A_ApplUser_Id, (PTR) &userId, TRUE) == RET_SUCCEED)
        {
		    SET_ID(inputData, A_Domain_LastUserId, userId);
        }
        else
        {
		    SET_NULL_ID(inputData, A_Domain_LastUserId);
        }
	}

	/***** UPDATE STANDARD PAR PROC STOCKEE SQL *****/
    if (retCode == RET_SUCCEED)
    {
		retCode = dbiConnHelper.dbaUpdate(Domain, DBA_ROLE_DOMAIN_UPD, inputData);
    }

	return retCode;
}


/************************************************************************
**  Function    :   DBA_InsDomainById
**
**  Description :   Create a new domain.
**
**  Arguments   :   object        The domain.
**  		        inputSt 	  A_Domain.
**                  inputData     A_Domain data.
**                  connectNo     Connection number.
**                  msgStructPtr  Kind of error message.
**
**  Return      :   RET_SUCCEED if success, or error code
**
**  Creation	:   OCS-36521 - TEB - 110111
**
*************************************************************************/
RET_CODE DBA_InsDomainById(OBJECT_ENUM          ,
                           DBA_DYNST_ENUM       ,
                     	   DBA_DYNFLD_STP       inputData,
                     	   DbiConnectionHelper& dbiConnHelper)
{
	ID_T      userId=0;
    RET_CODE  retCode = RET_SUCCEED;

	/* Check arguments */
	if (inputData == NULL)
	{
		MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_InsDomainById", "inputData");
		return(RET_GEN_ERR_INVARG);
	}

	if(SYS_IsSrvMode() == TRUE)
	{
		if (DBA_GetUserInfo2(A_ApplUser_Id, (PTR) &userId, TRUE) == RET_SUCCEED) {
			if (IS_NULLFLD(inputData, A_Domain_SessionCreationUserId) == TRUE)
			{
				SET_ID(inputData, A_Domain_SessionCreationUserId, userId);
			}

			/* PMSTA-11273 - TEB - 110202 */
			if (IS_NULLFLD(inputData, A_Domain_LastUserId) == TRUE)
			{
				SET_ID(inputData, A_Domain_LastUserId, userId);
			}
		}
	}

	/***** INSERT STANDARD PAR PROC STOCKEE SQL *****/
    if (retCode == RET_SUCCEED)
    {
		retCode = dbiConnHelper.dbaInsert(Domain, DBA_ROLE_DOMAIN_INSERT, inputData); /* OCS-36521 - TEB - 110124 */
    }

	return retCode;
}

/************************************************************************
*   Function             : DBA_CheckDynStNumbers()
*
*   Description          : Check infinity and not a real number error.
*
*   Arguments            : dynStEnum    dynamic structure
*                          rec          record
*                          errIdx       pointer to error index
*
*   Return               : RET_SUCCEED if no error, errIdx is filled
*
*   Last modif.          : PMSTA-25173 - 021116 - PMO : Linux: Importing specific number in quantity of operation raise NAN
*
*************************************************************************/
RET_CODE DBA_CheckDynStNumbers( DBA_DYNST_ENUM dynStEnum, DBA_DYNFLD_STP rec, int * errIdx)
{
    if(rec == nullptr || dynStEnum <= NullDynSt || dynStEnum > LASTDYNST)
    {
        return RET_GEN_ERR_INVARG;
    }

    if(nullptr != errIdx)
    {
        *errIdx = -1;
    }

    const int fldNbr = GET_FLD_NBR(dynStEnum);

    for(int i = 0 ; i < fldNbr ; i++)
    {
        if(IS_NULLFLD(rec, i) == FALSE && GET_CTYPE(GET_FLD_TYPE(dynStEnum, i)) == DoubleCType)
        {
            /* PMSTA-25173 - 021116 - PMO */
#ifdef AIX
            switch (fpclassify(GET_NUMBER(rec, i)))
#else
            switch (std::fpclassify(GET_NUMBER(rec, i)))
#endif
            {
                // Bad floating point value
                case FP_INFINITE:
                case FP_NAN:
                    *errIdx = i;
                    return RET_DBA_ERR_INVDATA;

                case FP_NORMAL:
                case FP_SUBNORMAL:
                case FP_ZERO:
                default:
                    break;
            }
        }
    }

    return RET_SUCCEED;
}

/************************************************************************
*   Function             : DBA_SetMagicDate()
*
*   Description          : Set magic date to not mandatory date (but mandatory
*                          in database)
*
*   Arguments            : rec       record pointer
*                          dynStType dynamic structure type
*                          object    structure object
*
*   Return               : RET_SUCCEED if no error
*
*************************************************************************/
RET_CODE DBA_SetMagicDate(DBA_DYNFLD_STP rec,
			              DBA_DYNST_ENUM dynStType,
			              OBJECT_ENUM    object)
{
    if (DBA_GetDictEntitySt(object) != NULL)   /* PMSTA-25848 - LJE - 170111 */
    {
        for (int i = 0; i < (int)GET_FLD_NBR(dynStType); i++)
        {
            switch (GET_FLD_TYPE(dynStType, i))
            {
                case DatetimeType:
                case DateType:
                    if (IS_NULLFLD(rec, i) == TRUE)
                    {
                        auto attribStP = DBA_GetDictAttribSt(object, i);
                        if (attribStP != nullptr &&
                            attribStP->mandatoryFlg == 0 &&
                            attribStP->dbMandatoryFlg == 1)
                        {
                            SET_DATE(rec, i, MAGIC_END_DATE);
                        }
                    }
                    else  /***** PEN 20/12/96 *****/
                    {
                        if (rec[i].data.datetime64St.date() == 0)
                        {
                            rec[i].data.datetime64St.setTime(0);
                            SET_NULL_DATETIME(rec, i);
                            auto attribStP = DBA_GetDictAttribSt(object, i);

                            if (attribStP != nullptr &&
                                attribStP->mandatoryFlg == 0 &&
                                attribStP->dbMandatoryFlg == 1)
                            {
                                SET_DATE(rec, i, MAGIC_END_DATE);
                            }
                        }
                    }
                    break;

                default:
                    break;

            }
        }
    }
	return(RET_SUCCEED);
}

/************************************************************************
*   Function             : DBA_HideMagicDate()
*
*   Description          : Set magic date to null
*
*   Arguments            : rec       record pointer
*                          dynStType dynamic structure type
*
*   Return               : RET_SUCCEED if no error
*
*************************************************************************/
RET_CODE DBA_HideMagicDate(DBA_DYNFLD_STP rec, DBA_DYNST_ENUM dynStType)
{
    const int nbFld = static_cast<int>(GET_FLD_NBR(dynStType));

	for(int i=0 ; i < nbFld ; i++)
	{
		switch(GET_FLD_TYPE(dynStType, i))
		{
		    case DatetimeType :
		    case DateType     :
			    if(GET_DATE(rec, i) == MAGIC_END_DATE)
				    SET_NULL_DATE(rec, i);
			    break;

            default:
			    break;
		}
	}
	return(RET_SUCCEED);
}

/************************************************************************
*   Function             : DBA_GroupScriptDef()
*
*   Description          : Group received script definition in one script
*                          definition string. (AttrDictId and ObjId are key)
*			   Group in first record(s) and free others.
*			   Update scriptDefNbrPtr with new script definition number
*
*   Arguments            : scriptDefTab     : script definition array
*                          scriptDefNbr     : script definition number
*                          sortOk           : TRUE = script definition array is sorted
*                          freeFlg          : TRUE = free "old" script definition step by step
*                          nScriptDefTab    : ptr on new script definition array (will be updated)
*			   nScriptDefNbrPtr : ptr on new script definition number (will be updated)
*
*   Return               : RET_SUCCEED, RET_GEN_INFO_NOACTION or error code
*
*   Creation		 : BUG165 - RAK - 961007
*   Modif.  		 : BUG284 - RAK - 970205
*   Modif.  		 : BUG288 - RAK - 970210
*   Modif.  		 : DVP432 - RAK - 970414
*
*************************************************************************/
RET_CODE DBA_GroupScriptDef(DBA_DYNFLD_STP *scriptDefTab,
			    int            scriptDefNbr,
			    char	   sortOk,
			    char           freeFlg,
			    DBA_DYNFLD_STP **nScriptDefTab,
			    int            *nScriptDefNbrPtr)
{
	int		i;
	DICT_T		attrDictId=0;
	ENUM_T		natEn=0;
	ID_T		objId=0;
	DBA_DYNFLD_STP	*newTab=NULL;
	char		*buffer=NULL;
    DBA_SCRIPT_DYN_ST scpt_DynStCfg;    /* PMSTA-28970 - CHU - 171215 */

	if (scriptDefTab == NULL || nScriptDefNbrPtr == NULL)
	{
	    MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_GroupScriptDef", "script pointers");
	    return(RET_GEN_ERR_INVARG);
	}

	*nScriptDefNbrPtr = 0;
	*nScriptDefTab    = NULL;

	if (scriptDefNbr <= 1)	/* Only 1 record, nothing to do */
	{
	    return(RET_GEN_INFO_NOACTION);	/* so calling function can use initial array */
	}

    DBA_SetScriptDynStConfig(GET_OBJ_DYNST(scriptDefTab[0]->dynStEnum), &scpt_DynStCfg); /* PMSTA-28970 - CHU - 171215 */

	if ((buffer = (char*) CALLOC(1, GET_MAXDATALEN(NoteType)*SCPTDEF_MAX_REC)) == NULL) /* PMSTA-33077 - DLA - 181011 */
		MSG_RETURN(RET_MEM_ERR_ALLOC);

	/* Allocate maximum number */
	if ((*nScriptDefTab = (DBA_DYNFLD_STP*) CALLOC(scriptDefNbr,
			         sizeof(DBA_DYNFLD_STP))) == NULL)
	{
	    FREE(buffer);
	    MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	newTab = *nScriptDefTab;

	/* Sort if necessary */
	if (sortOk == FALSE)
	{
	    TLS_Sort((char*) scriptDefTab, scriptDefNbr, sizeof(DBA_DYNFLD_STP),
		     (TLS_CMPFCT *)DBA_GroupScriptDefCmp, NULL, SortRtnTp_None); /* REF7264 - LJE - 020205 */
	}

	buffer[0] = END_OF_STRING;
	for (i=0, (*nScriptDefNbrPtr)=0; i<scriptDefNbr; i++)
	{
	    /* Save buffer */
	    if (i != 0 && /* objId, attrDictId and natEn are updated on first loop */
            (GET_DICT(scriptDefTab[i], scpt_DynStCfg.A_ScriptSt_AttrDictId  /* A_ScriptDef_AttrDictId */) != attrDictId || /* PMSTA-28970 - CHU - 171215 */
             GET_ID(scriptDefTab[i],   scpt_DynStCfg.A_ScriptSt_ObjId       /* A_ScriptDef_ObjId */) != objId || /* PMSTA-28970 - CHU - 171215 */
             GET_ENUM(scriptDefTab[i], scpt_DynStCfg.A_ScriptSt_NatEn       /* A_ScriptDef_NatEn */) != natEn)) /* PMSTA-28970 - CHU - 171215 */
	    {
		    /* Allocate new record */					/* BUG288 */
            if ((newTab[(*nScriptDefNbrPtr)] = ALLOC_DYNST(scpt_DynStCfg.all_inputStEn /* A_ScriptDef */)) == NULL) /* PMSTA-28970 - CHU - 171215 */
		    {
		        for (i=0; i<=(*nScriptDefNbrPtr); i++)
                    FREE_DYNST(newTab[i], scpt_DynStCfg.all_inputStEn /* A_ScriptDef */); /* PMSTA-28970 - CHU - 171215 */
		        FREE(newTab);
		        *nScriptDefNbrPtr=0;
	    	        FREE(buffer);
	    	        MSG_RETURN(RET_MEM_ERR_ALLOC);
		    }

		    /* Construct groupped record */
            SET_DICT(newTab[(*nScriptDefNbrPtr)],     scpt_DynStCfg.A_ScriptSt_AttrDictId /* A_ScriptDef_AttrDictId */, attrDictId);    /* PMSTA-28970 - CHU - 171215 */
            SET_ID(newTab[(*nScriptDefNbrPtr)],       scpt_DynStCfg.A_ScriptSt_ObjId      /* A_ScriptDef_ObjId */, objId);              /* PMSTA-28970 - CHU - 171215 */
            SET_ENUM(newTab[(*nScriptDefNbrPtr)],     scpt_DynStCfg.A_ScriptSt_NatEn      /* A_ScriptDef_NatEn */, natEn);              /* PMSTA-28970 - CHU - 171215 */
            SET_SMALLINT(newTab[(*nScriptDefNbrPtr)], scpt_DynStCfg.A_ScriptSt_Rank       /* A_ScriptDef_Rank */, 0);                   /* PMSTA-28970 - CHU - 171215 */
            SET_NOTE(newTab[(*nScriptDefNbrPtr)],     scpt_DynStCfg.A_ScriptSt_Def        /* A_ScriptDef_Def */, buffer);               /* PMSTA-28970 - CHU - 171215 */

		    /* Prepare next */
		    (*nScriptDefNbrPtr) += 1;
		    buffer[0] = END_OF_STRING;
	    }

	    /* Prepare groupped record */
        strcat(buffer, GET_NOTE(scriptDefTab[i], scpt_DynStCfg.A_ScriptSt_Def        /* A_ScriptDef_Def */));       /* PMSTA-28970 - CHU - 171215 */
        attrDictId  = GET_DICT(scriptDefTab[i],  scpt_DynStCfg.A_ScriptSt_AttrDictId /* A_ScriptDef_AttrDictId */); /* PMSTA-28970 - CHU - 171215 */
        objId       = GET_ID(scriptDefTab[i],    scpt_DynStCfg.A_ScriptSt_ObjId      /* A_ScriptDef_ObjId */);      /* PMSTA-28970 - CHU - 171215 */
	    natEn       = GET_ENUM(scriptDefTab[i],  scpt_DynStCfg.A_ScriptSt_NatEn      /* A_ScriptDef_NatEn */);      /* PMSTA-28970 - CHU - 171215 */

	    /* Free "old" script definition */
	    if (freeFlg == TRUE)
	    {
            FREE_DYNST(scriptDefTab[i], scpt_DynStCfg.all_inputStEn /* A_ScriptDef */); /* PMSTA-28970 - CHU - 171215 */
	    }
	}

	/* Allocate new record */					/* BUG288 */
    if ((newTab[(*nScriptDefNbrPtr)] = ALLOC_DYNST(scpt_DynStCfg.all_inputStEn /* A_ScriptDef */)) == NULL) /* PMSTA-28970 - CHU - 171215 */
	{
	    for (i=0; i<=(*nScriptDefNbrPtr); i++)
            FREE_DYNST(newTab[i], scpt_DynStCfg.all_inputStEn /* A_ScriptDef */); /* PMSTA-28970 - CHU - 171215 */
	    FREE(newTab);
	    *nScriptDefNbrPtr=0;
	    FREE(buffer);
	    MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	/* Construct groupped record */
	SET_DICT(newTab[(*nScriptDefNbrPtr)],     scpt_DynStCfg.A_ScriptSt_AttrDictId /* A_ScriptDef_AttrDictId */, attrDictId);    /* PMSTA-28970 - CHU - 171215 */
	SET_ID(newTab[(*nScriptDefNbrPtr)],       scpt_DynStCfg.A_ScriptSt_ObjId      /* A_ScriptDef_ObjId */,      objId);         /* PMSTA-28970 - CHU - 171215 */
	SET_ENUM(newTab[(*nScriptDefNbrPtr)],     scpt_DynStCfg.A_ScriptSt_NatEn      /* A_ScriptDef_NatEn */,      natEn);         /* PMSTA-28970 - CHU - 171215 */
	SET_SMALLINT(newTab[(*nScriptDefNbrPtr)], scpt_DynStCfg.A_ScriptSt_Rank       /* A_ScriptDef_Rank */,       0);             /* PMSTA-28970 - CHU - 171215 */
	SET_NOTE(newTab[(*nScriptDefNbrPtr)],     scpt_DynStCfg.A_ScriptSt_Def        /* A_ScriptDef_Def */,        buffer);        /* PMSTA-28970 - CHU - 171215 */

	/* script number */
	(*nScriptDefNbrPtr) += 1;

	if (freeFlg == TRUE)
		FREE(scriptDefTab);

	FREE(buffer);
	return(RET_SUCCEED);
}

/************************************************************************
*   Function             : DBA_GroupScriptDefCmp()
*
*   Description          : Comparison function used to group scrip definitions.
*
*   Arguments            : aPtr 	pointer to first dynamic structure
* 			   bPtr		pointer to second dynamic structure
*
*   Return               : sorting value
*
*************************************************************************/
STATIC int DBA_GroupScriptDefCmp(DBA_DYNFLD_STP *aPtr,  DBA_DYNFLD_STP *bPtr)
{
	DBA_DYNFLD_STP aDyn = *aPtr;
	DBA_DYNFLD_STP bDyn = *bPtr;
    DBA_SCRIPT_DYN_ST scpt_DynStCfg;    /* PMSTA-28970 - CHU - 171215 */

    DBA_SetScriptDynStConfig(GET_OBJ_DYNST(aDyn->dynStEnum), &scpt_DynStCfg); /* PMSTA-28970 - CHU - 171215 */

    if (GET_DICT(aDyn, scpt_DynStCfg.A_ScriptSt_AttrDictId /* A_ScriptDef_AttrDictId*/) ==
        GET_DICT(bDyn, scpt_DynStCfg.A_ScriptSt_AttrDictId /* A_ScriptDef_AttrDictId*/))
	{
        if (GET_ID(aDyn, scpt_DynStCfg.A_ScriptSt_ObjId /* A_ScriptDef_ObjId */) ==
            GET_ID(bDyn, scpt_DynStCfg.A_ScriptSt_ObjId /* A_ScriptDef_ObjId */))
	    {
            if (GET_ENUM(aDyn, scpt_DynStCfg.A_ScriptSt_NatEn /* A_ScriptDef_NatEn */) ==
                GET_ENUM(bDyn, scpt_DynStCfg.A_ScriptSt_NatEn /* A_ScriptDef_NatEn */))
		    {
                return(GET_SMALLINT(aDyn, scpt_DynStCfg.A_ScriptSt_Rank /* A_ScriptDef_Rank */) -
                       GET_SMALLINT(bDyn, scpt_DynStCfg.A_ScriptSt_Rank /* A_ScriptDef_Rank */));
		    }
		    else
		    {
                return(GET_ENUM(aDyn, scpt_DynStCfg.A_ScriptSt_NatEn /* A_ScriptDef_NatEn */) -
                       GET_ENUM(bDyn, scpt_DynStCfg.A_ScriptSt_NatEn /* A_ScriptDef_NatEn */));
		    }
	    }
	    else
	    {
            return(CMP_ID(GET_ID(aDyn, scpt_DynStCfg.A_ScriptSt_ObjId /* A_ScriptDef_ObjId */),
                          GET_ID(bDyn, scpt_DynStCfg.A_ScriptSt_ObjId /* A_ScriptDef_ObjId */))); /* DLA - REF9089 - 030508 */
	    }
	}
	else
	{
        return(CMP_ID(GET_DICT(aDyn, scpt_DynStCfg.A_ScriptSt_AttrDictId /* A_ScriptDef_AttrDictId*/),
                      GET_DICT(bDyn, scpt_DynStCfg.A_ScriptSt_AttrDictId /* A_ScriptDef_AttrDictId*/))); /* DLA - REF9089 - 030508 */
	}
}


/************************************************************************
**  Function    :   DBA_InsDictFunctionById
**
**  Description :   Create a new dict funtion.
**
**  Arguments   :   object          The dict function to insert.
**                  inputSt 	    A_DictFunction.
**                  inputData       A_DictFunction data.
**                  dbiConnHelper   Current connection
**
**  Return      :   RET_CODE
**
**  Creation    :   HFI-WEALTH-7636-2024-09-23
**
*************************************************************************/
RET_CODE    DBA_InsDictFunctionById(OBJECT_ENUM          object,
                                    DBA_DYNST_ENUM       inputSt,
                                    DBA_DYNFLD_STP       inputData,
                                    DbiConnectionHelper& dbiConnHelper)
{
    RET_CODE        ret;

    int             role = DBA_ROLE_FORCE_STORED_PROC;
    if (SYS_IsDdlGenMode() == TRUE)
    {
        role = DBA_ROLE_UDT;
    }
    else
    {

        if ((inputData != nullptr) &&
            (GET_A_DictFct_NatEn(inputData) == DictFctNatEn::UserDefinedSubFunction))
        {
            role = DBA_ROLE_INSUPD_DICTFCT_BY_IMP;
        }
    }
    ret = DBA_Insert2(object, role, inputSt, inputData, dbiConnHelper);

    return(ret);
}


/************************************************************************
**  Function    :   DBA_UpdDictFunctionById
**
**  Description :   Create a new dict funtion.
**
**  Arguments   :   object          The dict function to insert.
**                  inputSt 	    A_DictFunction.
**                  inputData       A_DictFunction data.
**                  dbiConnHelper   Current connection
**
**  Return      :   RET_CODE
**
**  Creation    :   HFI-WEALTH-7636-2024-09-23
**
*************************************************************************/
RET_CODE    DBA_UpdDictFunctionById(OBJECT_ENUM          object,
                                    DBA_DYNST_ENUM       inputSt,
                                    DBA_DYNFLD_STP       inputData,
                                    DbiConnectionHelper& dbiConnHelper)
{
    RET_CODE            ret;
    int                 role = DBA_ROLE_FORCE_STORED_PROC;

    if ((inputData != nullptr) &&
        (GET_A_DictFct_NatEn(inputData) == DictFctNatEn::UserDefinedSubFunction))
    {
        role = DBA_ROLE_INSUPD_DICTFCT_BY_IMP;
    }
    ret = DBA_Update2(object, role, inputSt, inputData, dbiConnHelper);

    return(ret);
}


/************************************************************************
**  Function    :   DBA_InsApplUserById
**
**  Description :   Create a new user.
**
**  Arguments   :   object        The user to check.
**  		    inputSt 	  A_ApplUser.
**                  inputData     A_ApplUser data.
**                  connectNo     Not used.
**                  msgStructPtr  Kind of error message.
**
**  Return      :   RET_SUCCEED                      If the user is DBO or SSO.
**                  RET_DBA_ERR_PASSWD_TOO_SHORT     If less than 6 characters.
**                  RET_GEN_ERR_INVARG               If no input data provided.
**
**  Creation    :   Unknown -
**  Modif.      :   ROI - 970130 - BUG273
**  Modif.      :   FIH-REF7020-010913      Transform use \"%... into use % and check DBA_SqlExec return
**  Modif.      :   FPL/BRO-REF7141-020807  Correct bug. If error on create user inserted occurances must be dropped
**                  PMSTA-18094 - 130514 - PMO : Avoid extracting the user credentials from the GUI running on Windows (via dump, etc.)
**
*************************************************************************/
RET_CODE DBA_InsApplUserById(OBJECT_ENUM          ,
                             DBA_DYNST_ENUM       ,
                             DBA_DYNFLD_STP       inputData,
                             DbiConnectionHelper& dbiConnHelper)
{
    RET_CODE             ret;
    DbiConnection&       dbiConn = *dbiConnHelper.getConnection();

	ret = DBI_InsApplUserById(inputData, dbiConn);

    return(ret);
}

/************************************************************************
**  Function    :   DBA_UpdApplUser
**
**  Description :   Update an existing user.
**                   Based on the value of A_ApplUser_LoginActionEn,
**                   we add or drop the syslogin ( ans sysusers )in sybase
**
**  Arguments   :   object        The user to check.
**  		    inputSt 	  A_ApplUser.
**                  inputData     A_ApplUser data.
**                  connectNo     Not used.
**                  msgStructPtr  Kind of error message.
**
**  Return      :   RET_SUCCEED                      If the user is DBO or SSO.
**                  RET_DBA_ERR_PASSWD_TOO_SHORT     If less than 6 characters.
**                  RET_GEN_ERR_INVARG               If no input data provided.
**
**  Creation    :   2012-06-08  - EFE - PMSTA-14286
**  Modif.      :
**
*************************************************************************/
RET_CODE DBA_UpdApplUser (OBJECT_ENUM          ,
                     	  DBA_DYNST_ENUM       ,
                     	  DBA_DYNFLD_STP       inputData,
                     	  DbiConnectionHelper& dbiConnHelper)
{
    RET_CODE            ret;
    DbiConnection&      dbiConn = *dbiConnHelper.getConnection();

	ret = DBI_UpdApplUser(inputData, dbiConn);

    return(ret);

}

/************************************************************************
**
**  Function    :   DBA_CheckDbAdminUser()
**
**  Description :   Verify that the given user is belonging to
**                  an administration group. (sso_role).
**                  The stored procedure also accepts:
**                      oper_role.
**                      dbo. (Database owner).
**                      sa_role.
**
**  Arguments   :   user        The user to check.
**                  passwd      His password.
**
**  Return      :   RET_SUCCEED                   If the user is DBO or SSO.
**                  RET_DBA_INFO_NOTADMINISTRATOR otherwise.
**                  RET_MEM_ERR_ALLOC             Memory allocation problems.
**                  RET_GEN_ERR_INVARG            No good input parameters.
**
**  Creation    :   DVP290 - GRD - 961202
**                  PMSTA-18081 - 021214 - PMO : Support Salted SHA256 password encryption
**
*************************************************************************/
RET_CODE DBA_CheckDbAdminUser(SYSNAME_T user, const PasswordEncrypted& passwd)
{
	DbiConnection * dbiConn = nullptr;
	RET_CODE        ret;

	if ((user == NULL))
	{
		return(RET_GEN_ERR_INVARG);
	}

	/*  HFI-PMSTA-17797-140314  sso user password was no more tested because of PMSTA-15895 */
	if ((ret = DBA_OpenConnForUser(user, passwd, &dbiConn, ROLE_DBSO)) != RET_SUCCEED)
	{
		return ret;
	}
	else
	{
		if (DBI_CheckUserRole(*dbiConn, "sso_role") == false)
		{
			ret = RET_DBA_INFO_NOTADMINISTRATOR;
		}
		DBA_EndConnection(&dbiConn);
	}

	return(ret);
}

/************************************************************************
**
**  Function    :   DBA_ChangePasswd()
**
**  Description :   Change the password of the given user.
**
**  Arguments   :   adminUser
**  		    adminPasswd
**  		    userCode
**  		    newPasswd
**
**  Return      :   RET_SUCCEED
**                  RET_GEN_ERR_INVARG               If no good parameters.
**                  RET_DBA_ERR_PASSWD_TOO_SHORT     If less than 6 characters.
**
**  Creation    :   DVP290 - GRD - 961202
**
**  Modif.      :   ROI - 961206 - DVP271
**  Modif.      :   ROI - 970130 - BUG273
**  Modif.      :   FIH-REF7036-010919  Test DBA_SlExec return.
**                  EFE-REF11663-060608 : validity date problem
**                  PMSTA-18094 - 130514 - PMO : Avoid extracting the user credentials from the GUI running on Windows (via dump, etc.)
**
*************************************************************************/
RET_CODE DBA_ChangePasswd(SYSNAME_T          adminUser,
                          PasswordEncrypted& adminPasswd,
                          SYSNAME_T          userCode, /* DLA - PMSTA09887 - 101115 */
                          PasswordEncrypted& newPasswd)
{
    RET_CODE            ret = RET_SUCCEED;

    ret = DBI_ChangePasswd(adminUser,
                           adminPasswd,
                           userCode,
                           newPasswd);
    return ret;
}

/************************************************************************
**
**  Function    :   DBA_ModifyUserPasswordByBatch
**
**  Description :
**
**  Arguments   :
**
**
**  Return      :  	void
**
**
**	Creation    :   DLA - PMSTA-10947 - 101123
*************************************************************************/
RET_CODE DBA_ModifyUserPasswordByBatch( OBJECT_ENUM				,
										DBA_DYNST_ENUM			,
										DBA_DYNFLD_STP			record,
										DbiConnectionHelper& dbiConnHelper)
{
    RET_CODE retCode = RET_SUCCEED;

    {
        PasswordEncrypted userPwd;

        {
            PasswordEncrypted suPwd;

            if (IS_NULLFLD(record, A_ApplUser_SuperUserLogin) == FALSE &&
                IS_NULLFLD(record, A_ApplUser_SuperUserPasswd) == FALSE)
            {
                suPwd.setClearPassword(PasswordClear(GET_SYSNAME(record, A_ApplUser_SuperUserPasswd)));
            }
            else
            {
                SET_SYSNAME(record, A_ApplUser_SuperUserLogin, dbiConnHelper.getConnection()->getSpecification().getCredentials().getUser().c_str());
                suPwd.setPassword(dbiConnHelper.getConnection()->getSpecification().getCredentials().getPassword().getPassword());
            }

            /* PMSTA-43741 - LJE - 210223 */
            userPwd.setClearPassword(PasswordClear(GET_INFO(record, A_ApplUser_UserPassword)));

            if (GET_FLAG(record, A_ApplUser_HasDbLoginFlg) == TRUE)
            {
                retCode = DBA_ChangePasswd(GET_SYSNAME(record, A_ApplUser_SuperUserLogin),
                                           suPwd,
                                           GET_SYSNAME(record, A_ApplUser_Cd),
                                           userPwd);
            }
        }

	    if (retCode == RET_SUCCEED)
        {
            retCode = DBA_InsertPasswdHistory(GET_SYSNAME(record, A_ApplUser_Cd), userPwd, dbiConnHelper);
        }
    }

	if (retCode == RET_SUCCEED)
	{
		retCode = dbiConnHelper.dbaUpdate(ApplUser, UNUSED, record);
	}

	return retCode;
}


/************************************************************************
**
**  Function    :   DBA_InsPtfSynthPrep()
**
**  Description :   Prepare current portfolio insert, update (ptf) and delete (event_sched)
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED 	or error code
**
**  Creation    :   REF5392 - RAK - 001121
**  Last modif. :   REF7264 - 0201225 - PMO : Compilation errors and warnings with C++ compiler
**                  REF7395 - YST - 020822 - parallel storage for ptf storage
**                  REF7395 - YST - 021028 - parallel storage for ptf storage
**
*************************************************************************/
STATIC RET_CODE DBA_InsPtfSynthPrep(PTR 		        hierHeadPtr,
									DBA_DYNFLD_STP		domainPtr,	/* PMSTA02013 - RAK - 071112 */
			                        DBA_DYNFLD_STP      sPtfSynthPtr,
			                        DBA_DYNFLD_STP      ptfPtr,
			                        PTR                 freqStp,
                                    DBA_INSPTFSYNTH_STP insPtfSynthStp)
{
	DBA_HIER_HEAD_STP 	    synthHierHead=(DBA_HIER_HEAD_STP) hierHeadPtr;  /* REF7264 - PMO */
	DBA_DYNFLD_STP		    *synthTab=NULL, lastPtfSynth=NULLDYNST,
				            sEventSched=NULL, crtPtfSynthPtr=NULL, *childrenPtfTab=NULLDYNSTPTR;
	int			            i, childIdx, ptfSynthNbr, size, lastInsSynthIdx=-1;
	FIN_RET_FREQ_STP	    ptfFreqStp=(FIN_RET_FREQ_STP)freqStp;   /* REF7264 - PMO */
	DICT_T	        	    ptfEntDictId;
    FLAG_T                  ptfUpdFlg=FALSE;
    RET_CODE		        ret=RET_SUCCEED, retLast;

	/* PMSTA02013 - RAK - 071112 */
	RETURNINPARENTPTFRULE_ENUM	returnInParPtfRuleEn=ReturnInParentPtfRule_Children;
 
    if (static_cast<LOADHIERPTF_ENUM> GET_ENUM(domainPtr, A_Domain_LoadHierFlg) == LoadHierPtf_IntermediateHierarchy)
    {  /*always- ReturnInParentPtfRule_Parent */
         returnInParPtfRuleEn = ReturnInParentPtfRule_Parent;
    }
    else
    {
         GEN_GetApplInfo(ApplReturnInParentPtfRule, &returnInParPtfRuleEn);
    }

    /* REF7395 - YST - 020822 - parallel storage: extract synthetics with level to PS */
	/* REF9836 - RAK - 040126 - use received PSP identifier (which replace flag) */
    if (ptfFreqStp->parallelStorPSPId < 0)
    {
		/* REF9836 - RAK - 040126 - I agree, it's a beautiful "bidouille" */
		SET_ID(sPtfSynthPtr, S_PtfSynth_Id, ptfFreqStp->parallelStorPSPId);
        ret = DBA_ExtractHierEltRecWithFilterSt(synthHierHead, A_PtfSynth,
			                                        FALSE, DBA_FilterPtfSynthParStor,
						                            sPtfSynthPtr, DBA_CmpPtfSynthPtf,
                                                    &ptfSynthNbr, &synthTab);

        /* return if no port synth found for parallel storage */
        if (ptfSynthNbr == 0)
            return(RET_SUCCEED);
    }
    else
    {
        if (insPtfSynthStp->onlyOnePtfFlg == TRUE)
        {
	        ret = DBA_ExtractHierEltRec(synthHierHead, A_PtfSynth,
					                    FALSE, NULLFCT, DBA_CmpPtfSynthPtf,
					                    &ptfSynthNbr, &synthTab);
        }
        else
        {
            /* or update index et extract by index key RE-ENGE ?*/
            ret = DBA_ExtractHierEltRecWithFilterSt(synthHierHead, A_PtfSynth,
			                                        FALSE, DBA_FilterCrtPtfSynth,
						                            sPtfSynthPtr, DBA_CmpPtfSynthPtf,
                                                    &ptfSynthNbr, &synthTab);
        }
    }

    if (ret != RET_SUCCEED)
    {
        return(ret);
    }

	if (ptfFreqStp->periodNbr > 0)	/* REF1402 - delete */
		size = ptfSynthNbr + ptfFreqStp->periodNbr;
	else
		size = ptfSynthNbr + 1;

	if (ptfFreqStp->eventSchedFlg == TRUE)
		size += 1;

    /* REF5392 - RAK - 010116 - Update portfolio */
    size += 1;

	/* PMSTA02013 - RAK - 071112 */
	if ((returnInParPtfRuleEn == ReturnInParentPtfRule_Parent ||
		 returnInParPtfRuleEn ==  ReturnInParentPtfRule_ParentUsingHierPSP) &&
		GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None &&
		GET_EXTENSION_NBR(ptfPtr, A_Ptf_HierChildrenPtf_Ext) > 0)
	{
		int	action=1;								/* Update portfolio */
		if (ptfFreqStp->eventSchedFlg == TRUE)		/* Delete event scheduler */
			action=2;

		size += (GET_EXTENSION_NBR(ptfPtr, A_Ptf_HierChildrenPtf_Ext) * action);
	}
    if ((insPtfSynthStp->accessStp) == NULL)
    {
        if (((insPtfSynthStp->accessStp) = (DBA_ACCESS_STP)
		                        CALLOC(size, sizeof(DBA_ACCESS_ST))) == NULL)
	    {
		    FREE(synthTab);
    	    MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }

        insPtfSynthStp->accessAllocSz += size;
    }
    else
    {
        if (((insPtfSynthStp->accessStp) = SYS_ReallocInit(insPtfSynthStp->accessStp,
                               (size_t) insPtfSynthStp->accessAllocSz, (size_t) size))==NULL)
        {
		    FREE(synthTab);
    	    MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }

        insPtfSynthStp->accessAllocSz += size;
    }

	/* Delete all synthetics for the portfolio between two dates */
    if (ptfFreqStp->deleteFlg == TRUE)
    {
        if ((crtPtfSynthPtr = ALLOC_DYNST(S_PtfSynth)) == NULL)
        {
            FREE(synthTab);
			FREE(insPtfSynthStp->accessStp);
            insPtfSynthStp->accessNbr = 0;
            insPtfSynthStp->accessAllocSz = 0;
            insPtfSynthStp->insertNbr = 0;
			MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        SET_ID(crtPtfSynthPtr, S_PtfSynth_PtfId,
            GET_ID(sPtfSynthPtr, S_PtfSynth_PtfId));

	    if (ptfFreqStp->periodNbr > 0)
	    {
            /* REF5244 - CSY - 001012: periods are computed in mode New.
            Only the last period may be to delete: if last synthetic is non permanent */
	        int begIdx, endIdx;

		    begIdx = ptfFreqStp->period[(ptfFreqStp->periodNbr)-1].beg;
		    endIdx = ptfFreqStp->period[(ptfFreqStp->periodNbr)-1].end - 1;

            SET_DATETIME(crtPtfSynthPtr, S_PtfSynth_InitialDate,
	            ptfFreqStp->periodCrystDates[begIdx]);
	        SET_DATETIME(crtPtfSynthPtr, S_PtfSynth_FinalDate,
	            ptfFreqStp->periodCrystDates[endIdx]);

            /* non permanent data must be deleted */
            insPtfSynthStp->accessStp[insPtfSynthStp->accessNbr].action = Delete;
	        insPtfSynthStp->accessStp[insPtfSynthStp->accessNbr].role   = DBA_ROLE_PTFSYNTH_ALL;
		    /* REF4489 - SSO - 000307 UNUSED -> DBA_ROLE_PTFSYNTH_ALL to call del_port_synthetic_by_pid */
	        insPtfSynthStp->accessStp[insPtfSynthStp->accessNbr].object = PtfSynth;
	        insPtfSynthStp->accessStp[insPtfSynthStp->accessNbr].entity = S_PtfSynth;
	        insPtfSynthStp->accessStp[insPtfSynthStp->accessNbr].data   = crtPtfSynthPtr;
	        ++(insPtfSynthStp->accessNbr);
            ptfUpdFlg = TRUE;
	    }
	    else
	    {
            /* DVP535 - date from the first record which will be insert */
            if (ptfSynthNbr > 0)    /* REF3903 - RAK - 000419 */
            {
                /* REF7395 - YST - 020822 - parallel storage: different management of delete period */
				/* REF9836 - RAK - 040126 - if PSP identifier is set to a negativ identifier, we are on case of parallel storage */
                if (ptfFreqStp->parallelStorPSPId < 0)
                {
                    SET_DATETIME(crtPtfSynthPtr, S_PtfSynth_InitialDate,
	                    GET_DATETIME(sPtfSynthPtr, S_PtfSynth_InitialDate));
	                SET_DATETIME(crtPtfSynthPtr, S_PtfSynth_FinalDate,
	                    GET_DATETIME(sPtfSynthPtr, S_PtfSynth_FinalDate));
                }
                else
                {
	                SET_DATETIME(crtPtfSynthPtr, S_PtfSynth_InitialDate,
	                    GET_DATETIME(synthTab[0], A_PtfSynth_InitialDate));
	                SET_DATETIME(crtPtfSynthPtr, S_PtfSynth_FinalDate,
	                    GET_DATETIME(synthTab[ptfSynthNbr-1], A_PtfSynth_FinalDate));
                }

                insPtfSynthStp->accessStp[insPtfSynthStp->accessNbr].action = Delete;
	            insPtfSynthStp->accessStp[insPtfSynthStp->accessNbr].role   = DBA_ROLE_PTFSYNTH_ALL;
		        /* REF4489 - SSO - 000307 UNUSED -> DBA_ROLE_PTFSYNTH_ALL to call del_port_synthetic_by_pid */
	            insPtfSynthStp->accessStp[insPtfSynthStp->accessNbr].object = PtfSynth;
	            insPtfSynthStp->accessStp[insPtfSynthStp->accessNbr].entity = S_PtfSynth;
	            insPtfSynthStp->accessStp[insPtfSynthStp->accessNbr].data   = crtPtfSynthPtr;
	            ++(insPtfSynthStp->accessNbr);
                ptfUpdFlg = TRUE;
            }
	    }
    }

	/* Insert new synthetics for portfolio */
	for (i=0; i<ptfSynthNbr; i++)
	{
		/* REF1511 - Don't insert blank : where final and initial market */
		/*           value is 0 and gross sales and purchases too.       */
        if (GET_FLAG(synthTab[i], A_PtfSynth_ToInsertEn) == FALSE) /* PMSTA-18006 - LJE - 140430 */
		    continue;

        /* REF7395 - YST - 021028 - parallel storage: set mkt segt id and grid id to NULL */
        /* REF9836 - RAK - 040126 - if PSP identifier is set to a negativ identifier, we are on case of parallel storage */
        if (ptfFreqStp->parallelStorPSPId < 0)
        {
			if ((PTFRETDETLVL_ENUM)GET_ENUM(ptfPtr, A_Ptf_RetDetLevelEn) == PtfRetDetLvl_Instrument)
            {
                SET_NULL_ID(synthTab[i], A_PtfSynth_MktSegtId);
            }
            if (IS_NULLFLD(synthTab[i], A_PtfSynth_MktSegtId) == TRUE &&
                IS_NULLFLD(synthTab[i], A_PtfSynth_InstrId) == TRUE)
            {
                SET_NULL_ID(synthTab[i], A_PtfSynth_GridId);
            }
        }

		insPtfSynthStp->accessStp[insPtfSynthStp->accessNbr].action = Insert;		/* New synthetic */
		insPtfSynthStp->accessStp[insPtfSynthStp->accessNbr].role   = UNUSED;
		insPtfSynthStp->accessStp[insPtfSynthStp->accessNbr].object = PtfSynth;
		insPtfSynthStp->accessStp[insPtfSynthStp->accessNbr].entity = A_PtfSynth;
		insPtfSynthStp->accessStp[insPtfSynthStp->accessNbr].data   = synthTab[i];

        lastInsSynthIdx = insPtfSynthStp->accessNbr;
        ptfUpdFlg = TRUE;

        ++(insPtfSynthStp->accessNbr);
        ++(insPtfSynthStp->insertNbr);  /* total insertion (for all ptf) */

		SET_NULL_ID(synthTab[i], A_PtfSynth_Id);
	}

	/* If an event scheduler exist, delete it (synthetics are recomputed) */
	if (ptfFreqStp->eventSchedFlg == TRUE)
	{
	  	if ((sEventSched = ALLOC_DYNST(S_EventSched)) == NULL)
		{
			FREE(synthTab);
			FREE(insPtfSynthStp->accessStp);
            insPtfSynthStp->accessNbr = 0;
            insPtfSynthStp->accessAllocSz = 0;
            insPtfSynthStp->insertNbr = 0;
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		if ((lastPtfSynth = ALLOC_DYNST(S_PtfSynth)) == NULLDYNST)
		{
			FREE(synthTab);
			FREE(insPtfSynthStp->accessStp);
            insPtfSynthStp->accessNbr = 0;
            insPtfSynthStp->accessAllocSz = 0;
            insPtfSynthStp->insertNbr = 0;
			FREE_DYNST(sEventSched, S_EventSched);
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}
	    DBA_GetDictId(Ptf, &ptfEntDictId);
	    SET_DICT(sEventSched,   S_EventSched_EntityDictId, ptfEntDictId); /* REF8844 - LJE - 030327 */
	    SET_ID(sEventSched,   S_EventSched_ObjId,     GET_ID(ptfPtr, A_Ptf_Id));
		SET_ENUM(sEventSched, S_EventSched_NatEn,        (ENUM_T) EventSchedNat_SynthAdmin);

	    insPtfSynthStp->accessStp[insPtfSynthStp->accessNbr].action = Delete;
	    insPtfSynthStp->accessStp[insPtfSynthStp->accessNbr].role   = UNUSED;
	    insPtfSynthStp->accessStp[insPtfSynthStp->accessNbr].object = EventSched;
	    insPtfSynthStp->accessStp[insPtfSynthStp->accessNbr].entity = S_EventSched;
	    insPtfSynthStp->accessStp[insPtfSynthStp->accessNbr].data   = sEventSched;
	    ++(insPtfSynthStp->accessNbr);

		/* PMSTA02013 - RAK - 071112 */
		/* Delete event scheduler of children ... if they haven't synth data ... */
		if ((returnInParPtfRuleEn == ReturnInParentPtfRule_Parent ||
			 returnInParPtfRuleEn ==  ReturnInParentPtfRule_ParentUsingHierPSP) &&
			GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None &&
			(childrenPtfTab = (DBA_DYNFLD_STP *)GET_EXTENSION_PTR(ptfPtr, A_Ptf_HierChildrenPtf_Ext)) != NULL)
		{
			/* for all children */
			for (childIdx=0; childIdx<GET_EXTENSION_NBR(ptfPtr, A_Ptf_HierChildrenPtf_Ext); childIdx++)
			{
				/* if child haven't synthetic */
				SET_ID(lastPtfSynth, S_PtfSynth_PtfId, GET_ID(childrenPtfTab[childIdx], A_Ptf_Id));

				retLast = DBA_Get2(PtfSynth, DBA_ROLE_PTFSYNTH_ALL, S_PtfSynth, lastPtfSynth,
			                       S_PtfSynth, &lastPtfSynth, UNUSED, UNUSED, UNUSED);

				if (RET_GET_LEVEL(retLast) == RET_LEV_ERROR)
				{
					FREE(synthTab);
					FREE(insPtfSynthStp->accessStp);
					insPtfSynthStp->accessNbr = 0;
					insPtfSynthStp->accessAllocSz = 0;
					insPtfSynthStp->insertNbr = 0;
					FREE_DYNST(lastPtfSynth, S_PtfSynth);
					MSG_RETURN(retLast);
				}
				else if (retLast == RET_DBA_INFO_NODATA)
				{
					if ((sEventSched = ALLOC_DYNST(S_EventSched)) == NULL)
					{
						FREE(synthTab);
						FREE(insPtfSynthStp->accessStp);
						insPtfSynthStp->accessNbr = 0;
						insPtfSynthStp->accessAllocSz = 0;
						insPtfSynthStp->insertNbr = 0;
						FREE_DYNST(lastPtfSynth, S_PtfSynth);
						MSG_RETURN(RET_MEM_ERR_ALLOC);
					}

					SET_DICT(sEventSched,   S_EventSched_EntityDictId, ptfEntDictId); /* REF8844 - LJE - 030327 */
					SET_ID(sEventSched,   S_EventSched_ObjId, GET_ID(childrenPtfTab[childIdx], A_Ptf_Id));
					SET_ENUM(sEventSched, S_EventSched_NatEn,    (ENUM_T) EventSchedNat_SynthAdmin);

					insPtfSynthStp->accessStp[insPtfSynthStp->accessNbr].action = Delete;
					insPtfSynthStp->accessStp[insPtfSynthStp->accessNbr].role   = UNUSED;
					insPtfSynthStp->accessStp[insPtfSynthStp->accessNbr].object = EventSched;
					insPtfSynthStp->accessStp[insPtfSynthStp->accessNbr].entity = S_EventSched;
					insPtfSynthStp->accessStp[insPtfSynthStp->accessNbr].data   = sEventSched;
					++(insPtfSynthStp->accessNbr);
				}
			}
		}

		FREE_DYNST(lastPtfSynth, S_PtfSynth);
	}

    /* REF5392 - RAK - 010116 */
    /* Update portfolio fields A_Ptf_SynthLastFinalDate and A_Ptf_SynthRecalcDate */
    /* with proc upd_portfolio_by_id_synth_d */
    if (ptfUpdFlg == TRUE)
    {
		/* PMSTA02013 - RAK - 071112 - Create a sub-function */
		if ((ret = DBA_UpdPtfSynthLastFinalDate(synthHierHead, ptfPtr,
												insPtfSynthStp, lastInsSynthIdx, ptfSynthNbr)) != RET_SUCCEED)
		{
			FREE(synthTab);
			FREE(insPtfSynthStp->accessStp);
            insPtfSynthStp->accessNbr = 0;
            insPtfSynthStp->accessAllocSz = 0;
            insPtfSynthStp->insertNbr = 0;
			return(ret);
		}

		/* PMSTA02013 - RAK - 071112 - And call it on children if necessary */
		if ((returnInParPtfRuleEn == ReturnInParentPtfRule_Parent ||
			 returnInParPtfRuleEn ==  ReturnInParentPtfRule_ParentUsingHierPSP) &&
			GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None &&
			(childrenPtfTab = (DBA_DYNFLD_STP *)GET_EXTENSION_PTR(ptfPtr, A_Ptf_HierChildrenPtf_Ext)) != NULL)
		{
			/* for all children */
			for (childIdx=0; childIdx<GET_EXTENSION_NBR(ptfPtr, A_Ptf_HierChildrenPtf_Ext); childIdx++)
			{
				if ((ret = DBA_UpdPtfSynthLastFinalDate(synthHierHead, childrenPtfTab[childIdx],
														insPtfSynthStp, lastInsSynthIdx, ptfSynthNbr)) != RET_SUCCEED)
				{
					FREE(synthTab);
					FREE(insPtfSynthStp->accessStp);
					insPtfSynthStp->accessNbr = 0;
					insPtfSynthStp->accessAllocSz = 0;
					insPtfSynthStp->insertNbr = 0;
					return(ret);
				}
			}
		}
    }

    FREE(synthTab);
    return(ret);
}

/************************************************************************
*   Function             : DBA_UpdPtfSynthLastFinalDate()
*
*   Description          :
*
*   Arguments            : PtfSynth to test
*
*
*   Return               : TRUE if the ptf synth
*
*   Creation             : PMSTA02013 - RAK - 071112
*
*************************************************************************/
STATIC RET_CODE DBA_UpdPtfSynthLastFinalDate(DBA_HIER_HEAD_STP   ,
											 DBA_DYNFLD_STP      ptfPtr,
											 DBA_INSPTFSYNTH_STP insPtfSynthStp,
											 int                 lastInsSynthIdx,
											 int				 ptfSynthNbr)
{
	DBA_DYNFLD_STP lastInsSynthPtr=NULL;

    if (lastInsSynthIdx != -1)
        lastInsSynthPtr = insPtfSynthStp->accessStp[lastInsSynthIdx].data;

    /* If new final date is after the stored A_Ptf_SynthLastFinalDate, update portfolio */
    if (lastInsSynthPtr != NULL &&
        DATETIME_CMP(GET_DATETIME(lastInsSynthPtr, A_PtfSynth_FinalDate),
                     GET_DATETIME(ptfPtr, A_Ptf_SynthLastFinalDate)) > 0)
    {
        /* REF5392 - RAK - 010116 - Update with new proc upd_portfolio_by_id_synth_d */
        SET_DATETIME(ptfPtr, A_Ptf_SynthLastFinalDate,
            GET_DATETIME(lastInsSynthPtr, A_PtfSynth_FinalDate));

        /* if last synthetic is persistent, recalculation date is */
        /* last final date elsewhere is last initial date.        */
        if (GET_ENUM(lastInsSynthPtr, A_PtfSynth_PersistEn) == PersistNat_Persist ||
			GET_ENUM(lastInsSynthPtr, A_PtfSynth_PersistEn) == PersistNat_HierarchicalPersist) /* PMSTA03044 - LJE - 070907 */
        {
            SET_DATETIME(ptfPtr, A_Ptf_SynthRecalcDate,
                GET_DATETIME(lastInsSynthPtr, A_PtfSynth_FinalDate));
        }
        else
        {
            SET_DATETIME(ptfPtr, A_Ptf_SynthRecalcDate,
                GET_DATETIME(lastInsSynthPtr, A_PtfSynth_InitialDate));
        }

		insPtfSynthStp->accessStp[insPtfSynthStp->accessNbr].action = Update;
	    insPtfSynthStp->accessStp[insPtfSynthStp->accessNbr].role   = DBA_ROLE_PTFSYNTH_ALL ; /* REF5616 */
	    insPtfSynthStp->accessStp[insPtfSynthStp->accessNbr].object = Ptf;
	    insPtfSynthStp->accessStp[insPtfSynthStp->accessNbr].entity = A_Ptf;
	    insPtfSynthStp->accessStp[insPtfSynthStp->accessNbr].data   = ptfPtr;
	    ++(insPtfSynthStp->accessNbr);
	}
    /* REF5733 - RAK - 010313 - Set dates to NULL */
    else if (ptfSynthNbr == 0)
    {
        /* REF5392 - RAK - 010116 - Update with new proc upd_portfolio_by_id_synth_d */
        SET_NULL_DATETIME(ptfPtr, A_Ptf_SynthLastFinalDate);
        SET_NULL_DATETIME(ptfPtr, A_Ptf_SynthRecalcDate);

	    insPtfSynthStp->accessStp[insPtfSynthStp->accessNbr].action = Update;
	    insPtfSynthStp->accessStp[insPtfSynthStp->accessNbr].role   = DBA_ROLE_PTFSYNTH_ALL ; /* REF5616 */
	    insPtfSynthStp->accessStp[insPtfSynthStp->accessNbr].object = Ptf;
	    insPtfSynthStp->accessStp[insPtfSynthStp->accessNbr].entity = A_Ptf;
	    insPtfSynthStp->accessStp[insPtfSynthStp->accessNbr].data   = ptfPtr;
	    ++(insPtfSynthStp->accessNbr);
    }

	return(RET_SUCCEED);
}

/************************************************************************
*   Function             : DBA_IsPtfSynthToInsert()
*
*   Description          : Determines whether the data must be taken
*                          into account for insertion in data base
*
*   Arguments            : PtfSynth to test
*
*
*   Return               : TRUE if the ptf synth
*
*   Creation             ; PMSTA-00886 - LJE - 061110
*   Modif                :
*
*************************************************************************/
FLAG_T DBA_IsPtfSynthToInsert(DBA_DYNFLD_STP ptfSynth)
{
    INT_T emptyPtfValidityPeriod=TRUE;

	if (FIN_IsEmptyPtfSynth(ptfSynth) == TRUE)
    {
        if (IS_NULLFLD(ptfSynth, A_PtfSynth_InstrId)   == TRUE &&
            IS_NULLFLD(ptfSynth, A_PtfSynth_MktSegtId) == TRUE)
        {
            GEN_GetApplInfo(ApplPerfEmptyPtfValidityPeriod, &emptyPtfValidityPeriod);

            if (emptyPtfValidityPeriod > 0 &&
                emptyPtfValidityPeriod >= (GET_INT(ptfSynth, A_PtfSynth_InitialNumDays) - GET_INT(ptfSynth, A_PtfSynth_LastFlowNumDays)))
            {

                return TRUE;
            }
        }

        return FALSE;
    }

    return TRUE;
}

/************************************************************************
*   Function             : DBA_InsPtfSynthCmp()
*
*   Description          : Comparison function used to sort synthetics insertion.
*
*   Arguments            : aPtr 	pointer to first access structure
* 			               bPtr		pointer to second access structure
*
*   Return               : sorting value
*
*************************************************************************/
STATIC int DBA_InsPtfSynthCmp(DBA_ACCESS_STP aPtr,  DBA_ACCESS_STP bPtr)
{
    /* Delete synthetics */
    if (aPtr->action == Delete && aPtr->entity == S_PtfSynth)
    {
        if (bPtr->action == Delete && bPtr->entity == S_PtfSynth)
        {
            return (CMP_ID(GET_ID((aPtr->data), S_PtfSynth_PtfId),
                    GET_ID((bPtr->data), S_PtfSynth_PtfId))); /* DLA - REF9089 - 030508 */
        }
        else
        {
            return(-1);
        }
    }
    /* Insert synthetics */
    else if (aPtr->action == Insert && aPtr->entity == A_PtfSynth)
    {
        if (bPtr->action == Insert && bPtr->entity == A_PtfSynth)
        {
            return (CMP_ID(GET_ID(aPtr->data, A_PtfSynth_PtfId),
                    GET_ID(bPtr->data, A_PtfSynth_PtfId))); /* DLA - REF9089 - 030508 */
        }
        else if (bPtr->action == Delete && bPtr->entity == S_PtfSynth)
        {
            return(1);
        }
        else
        {
            return(-1);
        }
    }
    /* Delete event scheduler */
    else if (aPtr->action == Delete && aPtr->entity == S_EventSched)
    {
        if (bPtr->action == Delete && bPtr->entity == S_EventSched)
        {
            return (CMP_ID(GET_ID(aPtr->data, A_Ptf_Id),
                    GET_ID(bPtr->data, A_Ptf_Id))); /* DLA - REF9089 - 030508 */
        }
        else if ((bPtr->action == Delete && bPtr->entity == S_PtfSynth) ||
                 (bPtr->action == Insert && bPtr->entity == A_PtfSynth))
        {
            return(1);
        }
        else
        {
            return(-1);
        }
    }
    /* Update portfolio */
    else if (aPtr->action == Update && aPtr->entity == A_Ptf)
    {
        if (bPtr->action == Update && bPtr->entity == A_Ptf)
        {
            return (CMP_ID(GET_ID(aPtr->data, A_Ptf_Id),
                    GET_ID(bPtr->data, A_Ptf_Id))); /* DLA - REF9089 - 030508 */
        }
        else
        {
            return(1);
        }
    }
    else
        return(1);
}

/************************************************************************
**
**  Function    :   DBA_InsPtfSynth()
**
**  Description :   Insert portfolio synthetics by block
**
**  Arguments   :   hierHeadPtr	  pointer on synthetics hierarchy header
**  		    ptfId	  portfolio identifier
**  		    onlyOnePtfFlg TRUE if only one ptf synthetics are in hierarchy
**  		    initialDate
**  		    finalDate
**
**  Return      :   RET_SUCCEED 	or error code
**
**  Creation    :   DVP261 - RAK - 961209
**  Modif.      :   DVP535 - RAK - 970707
**  Modif.      :   REF1511 - RAK - 980407
**		            REF4489 - SSO - 000307 - fixed delete for pps cases
**                  REF5244 - CSY - 001012: - manage deleteFlg (avoid useless deletes)
**                                            deleteFlg is set in FIN_GetPtfFreqInfoForSynthAdmin
**                  REF5260 - RAK - 001113 - Update portfolio fields
**                  REF5392 - RAK - 001121 - Insert by block, new function
**
*************************************************************************/
RET_CODE DBA_InsPtfSynth(DBA_DYNFLD_STP		 domainPtr,			/* REF9836 - RAK - 040126 */
						 PTR 		         hierHeadPtr,
			             DBA_DYNFLD_STP      sPtfSynthPtr,
			             DBA_DYNFLD_STP      ptfPtr,            /* REF3903 - RAK - 000419 */
			             PTR                 freqStp,
                         DBA_INSPTFSYNTH_STP insPtfSynthStp,
                         FLAG_T              forceInsertFlg)    /* REF5392 - RAK - 001121 */
{
	int			            size;
    RET_CODE		        ret=RET_SUCCEED;
	DbiConnection			*dbiConn = nullptr;

    /* Add current portfolio in access block only if function isn't call for the remaining insertion */
    if (forceInsertFlg == FALSE)
    {
        int oldNbr = insPtfSynthStp->accessNbr;
        ret = DBA_InsPtfSynthPrep(hierHeadPtr, domainPtr, sPtfSynthPtr, ptfPtr, freqStp, insPtfSynthStp);

        if (ret == RET_SUCCEED && oldNbr - insPtfSynthStp->accessNbr == 0)
            ret = RET_GEN_INFO_NODATA;
    }

    /* access block is >= 100 or function is call for the remaining insertion */
    if (ret == RET_SUCCEED &&
        ((forceInsertFlg == TRUE && insPtfSynthStp->accessNbr > 0) ||
         insPtfSynthStp->insertNbr >= 100))
    {
	    size = 200;

	    /* REF5040 - RAK - 000726 - block of 200 or block of access number if less than 200 */
        if (insPtfSynthStp->accessNbr < 200)
		    size = insPtfSynthStp->accessNbr;

        /* REF5392 - RAK - 001122 - Sort delete of synthetics, insert of synthetics, update ptf, delete eventSched */
        TLS_Sort((char*) insPtfSynthStp->accessStp, insPtfSynthStp->accessNbr, sizeof(DBA_ACCESS_ST),
		         (TLS_CMPFCT *)DBA_InsPtfSynthCmp, NULL, SortRtnTp_None); /* REF7264 - LJE - 020205 */

	    /* REF3528 - SSO - 990412 : DBA_NO_ERROR must be set to ensure integrity !
	    USE also a transaction... */

        if ((dbiConn = DBA_GetDbiConnection(SqlServer)) == nullptr)
	    {
	        MSG_SendMesg(RET_DBA_ERR_CONNOTFOUND, 0, FILEINFO);
       	    ret = RET_DBA_ERR_CONNOTFOUND;
	    }
	    else
	    {
	        /* be in a transaction */
			ret = dbiConn->beginTransaction();

	        if (ret != RET_SUCCEED)
	        {
				if (DBA_EndConnection(&dbiConn, TRUE) != RET_SUCCEED)
                {
                    MSG_SendMesg(RET_DBA_ERR_DISCONNECTED, 0, FILEINFO);
                }
           	    ret = RET_DBA_ERR_CONNOTFOUND;
	        }
	        else
	        {
                DbaMultiAccessHelper       multiAccessHelper(insPtfSynthStp->accessStp, insPtfSynthStp->accessNbr);

                /* REF3736 - SSO - 990608: added DBA_SET_CONN|DBA_NO_CLOSE */
		        ret = multiAccessHelper.callMultiAccess(size, DBA_SET_CONN|DBA_NO_CLOSE|DBA_NO_ERROR, *dbiConn, true);

                /* REF5040 - RAK - 000725 - Retry until succeed (3 times max) ... */
                if (ret == RET_SRV_LIB_ERR_FATAL_DEADLOCK || ret == RET_SRV_LIB_ERR_DEADLOCK)
                {
                    int deadlockCpt=0, ret2=RET_SUCCEED;

                    do
                    {
                        multiAccessHelper.sendAllMultiAccessMsg();

                        if (ret == RET_SRV_LIB_ERR_FATAL_DEADLOCK)
                        {
                            /* connection lost */
							DBA_EndConnection(&dbiConn, TRUE);
							dbiConn = DBA_GetDbiConnection(SqlServer);
							if (dbiConn != nullptr)
							{
								ret2 = RET_SUCCEED;
							}
                          //  ret2 = DBA_ReinitDeadConn(dbiConn->getId());
                        }
                        else
                        {
                            /* rollback */
		                    ret2 = dbiConn->endTransaction(FALSE);
                        }

                        if (ret2 == RET_SUCCEED)
                        {
                            switch (deadlockCpt)
					        {
						    case 0:
								SYS_MilliSleep(1000); /* PMSTA-20159 - TEB - 150624  */
							    break;

						    case 1:
								SYS_MilliSleep(3000); /* PMSTA-20159 - TEB - 150624  */
							    break;

						    case 2:
								SYS_MilliSleep(7000); /* PMSTA-20159 - TEB - 150624  */
							    break;
					        }

                            /* be in a transaction */
							ret2 = dbiConn->beginTransaction();

	                        if (ret2 == RET_SUCCEED)
	                        {
                                ret = multiAccessHelper.callMultiAccess(size, DBA_SET_CONN|DBA_NO_CLOSE|DBA_NO_ERROR, *dbiConn, true);
                            }
                        }

                        ++deadlockCpt;
                    }
                    while (ret != RET_SUCCEED && ret2 == RET_SUCCEED && deadlockCpt < 3);

                    /* Finally : succeed */
                    if (ret == RET_SUCCEED)
                    {
                        /* OK, commit transaction */
						dbiConn->endTransaction(TRUE);
                    }
                    else
                    {
                        multiAccessHelper.sendAllMultiAccessMsg();

                        if (ret == RET_SRV_LIB_ERR_FATAL_DEADLOCK)
                        {
                            /* connection lost */
							//ret = DBA_ReinitDeadConn(dbiConn->getId());
							DBA_EndConnection(&dbiConn, TRUE);
							dbiConn = DBA_GetDbiConnection(SqlServer);
                        }
                        else
                        {
                            /* rollback */
							ret = dbiConn->endTransaction(FALSE);
                        }

                        ret = RET_DBA_ERR_INSERT_FAILED;
                    }
                }
		        /* REF3528 - SSO - 990412 : added test on msgStructNbr to be sure no error is lost */
		        else if ( (ret != RET_SUCCEED) || (dbiConn->m_msgStructHeaderSt.empty() == false))
		        {
		            /* error: rollback */
					dbiConn->endTransaction(FALSE);
                    dbiConn->sendAllMsg();

                    ret = RET_DBA_ERR_INSERT_FAILED;
		        }
                else
		        {
		            /* OK, commit transaction */
					dbiConn->endTransaction(TRUE);
		        }
	        }

			if (DBA_EndConnection(&dbiConn) != RET_SUCCEED)
	        {
		        MSG_SendMesg(RET_DBA_ERR_DISCONNECTED, 0, FILEINFO);
	        }
	    }

        /* Free structures used for the delete of synthetics and the delete of event sched */
        for (int i=0; i<insPtfSynthStp->accessNbr; i++)
        {
            if (insPtfSynthStp->accessStp[i].entity == S_EventSched ||
                insPtfSynthStp->accessStp[i].entity == S_PtfSynth)
            {
                FREE_DYNST(insPtfSynthStp->accessStp[i].data, insPtfSynthStp->accessStp[i].entity);
            }
        }

        /* Free all synthetics keeped in hierarchy */
        if (insPtfSynthStp->delSynthFlg == TRUE)
            DBA_FreeHierEltRecord((DBA_HIER_HEAD_STP) hierHeadPtr, A_PtfSynth);

        /* Free block and update variable to 0 */
        FREE(insPtfSynthStp->accessStp);
        insPtfSynthStp->accessNbr     = 0;
        insPtfSynthStp->accessAllocSz = 0;
        insPtfSynthStp->insertNbr     = 0;

		/* REF9836 - RAK - 040126 - Good message for PtfStorage */
		if (GET_DICT(domainPtr, A_Domain_InitialFctDictId) == DictFct_PtfStorage)
		{
			if (ret == RET_SUCCEED)
			{
				MSG_LogSrvMesg(UNUSED, 0, "Portfolio Storage : synthetics successfully inserted");
			}
			else
			{
				MSG_LogSrvMesg(UNUSED, 0, "Portfolio Storage : synthetics unsuccessfully inserted (see log file)");
			}
		}
		else
		{
			if (ret == RET_SUCCEED)
			{
				/* REF5733 - RAK - 010307 - Change message */
				MSG_LogSrvMesg(UNUSED, 0,
					"Synthetic Administration %1 to %2 : synthetics successfully treated",
					IntType, insPtfSynthStp->startPtf,
					IntType, insPtfSynthStp->crtPtf);
			}
			else
			{
				/* REF5733 - RAK - 010307 - Change message */
				MSG_LogSrvMesg(UNUSED, 0,
				"Synthetic Administration %1 to %2 : synthetics unsuccessfully treated (see log file)",
				IntType, insPtfSynthStp->startPtf,
				IntType, insPtfSynthStp->crtPtf);
			}
		}

        insPtfSynthStp->startPtf = insPtfSynthStp->crtPtf+1;
    }

    return(ret);
}

/************************************************************************
**
**  Function    :   DBA_CmpPtfSynthPtf()
**
**  Description :   Portfolio synthetics table is sort by ptf
**
**  Arguments   :   ptr1   pointer on dynamic structure type ExtPos
**                  ptr2   pointer on dynamic structure type ExtPos
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation    :   DVP261 - RAK - 961205
**
*************************************************************************/
STATIC int DBA_CmpPtfSynthPtf(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
	/* Portfolio */
	if (GET_ID((*ptr1), A_PtfSynth_PtfId) ==
	    GET_ID((*ptr2), A_PtfSynth_PtfId))
	{
	    return(DATETIME_CMP(GET_DATETIME((*ptr1), A_PtfSynth_InitialDate),
				GET_DATETIME((*ptr2), A_PtfSynth_InitialDate)));
	}
	else
	    return(CMP_ID(GET_ID((*ptr1), A_PtfSynth_PtfId) , GET_ID((*ptr2), A_PtfSynth_PtfId))); /* DLA - REF9089 - 030508 */
}

/************************************************************************
**
**  Function    :   DBA_FilterCrtPtfSynth()
**
**  Description :   Filter current portfolio synthetics
**
**  Arguments   :   ptr1   pointer on dynamic structure type ExtPos
**                  ptr2   pointer on dynamic structure type ExtPos
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation    :   REF5293 - RAK - 001121
**
*************************************************************************/
STATIC int DBA_FilterCrtPtfSynth(DBA_DYNFLD_STP synthPtr,
                                 DBA_DYNST_ENUM ,
                                 DBA_DYNFLD_STP sPtfSynthPtr)

{
	/* Portfolio */
	if (GET_ID(synthPtr, A_PtfSynth_PtfId) == GET_ID(sPtfSynthPtr, S_PtfSynth_PtfId))
	    return(TRUE);
	else
	    return(FALSE);
}


/************************************************************************
**
**  Function    :   DBA_FilterSecondSynthPtf()
**
**  Description :   Extract synthetics for a given portfolio with level = PS
**                  for insert parallel storage.
**
**  Arguments   :   dynSt       dynamic structure pointer
**                  dynStTp     dynamic structure definition
**		            ptfPtr      parameter dynamic structure pointer
**
**  Return      :   TRUE or FALSE
**
**  Creation	:   REF7421 - YST - 020819
**
*************************************************************************/
STATIC int DBA_FilterPtfSynthParStor(DBA_DYNFLD_STP dynSt,
			                        DBA_DYNST_ENUM  ,
                                    DBA_DYNFLD_STP  sPtfSynthPtr)
{
    if (GET_ID(dynSt, A_PtfSynth_PtfId) == GET_ID(sPtfSynthPtr, S_PtfSynth_PtfId) &&			/* portfolio */
		(FLAG_T)GET_BIT((MASK_T)GET_TINYINT(dynSt, A_PtfSynth_Level), SynthLevel_PS) == TRUE &&	/* portfolio synthetics */
		/* REF9836 - RAK - 040126 - I agree, it's a beautiful "bidouille" (use S_PtfSynth_Id as PSPId) */
		GET_ID(dynSt, A_PtfSynth_PSPId) == GET_ID(sPtfSynthPtr, S_PtfSynth_Id))					/* PSP */
        return(TRUE);
    else
        return(FALSE);
}

/************************************************************************
**
**  Function    :   DBA_DelPtfSynth()
**
**  Description :   Delete portfolio synthetics by block
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED 	or error code
**
**  Creation    :   DVP261 - RAK - 961205
**  Modif       :   DVP535 - RAK - 970707
**  Modif       :   REF5260 - RAK - 001116
**  Modif       :   REF5392 - RAK - 001228 - Delete with MultiAccess and upd ptf by dynamic sql
**
*************************************************************************/
RET_CODE DBA_DelPtfSynth(DATETIME_T     fromDate,
                         DATETIME_T     tillDate,
                         DBA_DYNFLD_STP *ptfTab,
                         int            begIdx,
                         int            lastIdx,
                         int            ptfNbr)
{
	RET_CODE		        ret, retEvt=RET_SUCCEED, retLast=RET_SUCCEED;
	DBA_DYNFLD_STP	        getEventSched=NULL, eventSchedPtr=NULL, lastPtfSynth=NULL,
                            sPtfSynthPtr=NULL, sEventSched=NULL;
	DICT_T	                ptfEntDictId;
    DBA_ACCESS_STP		    accessStp=NULL;
    int                     i, accessNbr, size, allocSize;
	DbiConnection           *dbiConn = nullptr;

    /* Only one portfolio */
    if (lastIdx-begIdx == 0)
    {
        if ((sPtfSynthPtr = ALLOC_DYNST(S_PtfSynth)) == NULL)
	    { MSG_RETURN(RET_MEM_ERR_ALLOC); }

	    SET_DATETIME(sPtfSynthPtr, S_PtfSynth_InitialDate,  fromDate);
	    SET_DATETIME(sPtfSynthPtr, S_PtfSynth_FinalDate,    tillDate);

        SET_ID(sPtfSynthPtr, S_PtfSynth_PtfId, GET_ID(ptfTab[begIdx], A_Ptf_Id));

        ret = DBA_DelPtfSynthOnePtf(sPtfSynthPtr, ptfTab, begIdx, ptfNbr);

        FREE_DYNST(sPtfSynthPtr, S_PtfSynth);

        return(ret);
    }

    /* allocSize = portfolio number * 2 (delete synthetics, update event_sched and portfolio */
    allocSize = lastIdx - begIdx + 1;
    allocSize *= 2;

    if ((accessStp = (DBA_ACCESS_STP)
			         CALLOC(allocSize, sizeof(DBA_ACCESS_ST))) == NULL)
	{
    	MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

    accessNbr = 0;

    for (i=begIdx; i<=lastIdx; i++)
    {
        if ((sPtfSynthPtr = ALLOC_DYNST(S_PtfSynth)) == NULL)
	    {
            FREE(accessStp);
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

	    SET_DATETIME(sPtfSynthPtr, S_PtfSynth_InitialDate,  fromDate);
	    SET_DATETIME(sPtfSynthPtr, S_PtfSynth_FinalDate,    tillDate);
        SET_ID(sPtfSynthPtr,       S_PtfSynth_PtfId,        GET_ID(ptfTab[i], A_Ptf_Id));

        accessStp[accessNbr].action = Delete;
	    accessStp[accessNbr].role   = DBA_ROLE_PTFSYNTH_ALL; /* del_port_synthetic_by_pid */
	    accessStp[accessNbr].object = PtfSynth;
	    accessStp[accessNbr].entity = S_PtfSynth;
	    accessStp[accessNbr].data   = sPtfSynthPtr;
	    ++accessNbr;

        MSG_LogSrvMesg(UNUSED, 0,
		               "Synthetic Administration %1 of %2 : portfolio %3 added in delete block",
		               IntType, i+1, IntType, ptfNbr,
		               CodeType, GET_CODE(ptfTab[i], A_Ptf_Cd));
    }

    size = 100;
    if (accessNbr < 100)
		size = accessNbr;

    /* REF5758 - RAK - 010308 - Use transaction */
    if ((dbiConn = DBA_GetDbiConnection(SqlServer)) == nullptr)
	{
	    MSG_SendMesg(RET_DBA_ERR_CONNOTFOUND, 0, FILEINFO);
       	ret = RET_DBA_ERR_CONNOTFOUND;
	}
	else
	{
	    /* be in a transaction */
	    ret = dbiConn->beginTransaction();

	    if (ret != RET_SUCCEED)
	    {
			if (DBA_EndConnection(&dbiConn,TRUE) != RET_SUCCEED)
            {
                MSG_SendMesg(RET_DBA_ERR_DISCONNECTED, 0, FILEINFO);
            }
           	ret = RET_DBA_ERR_CONNOTFOUND;
	    }
	    else
	    {
            DbaMultiAccessHelper       multiAccessHelper(accessStp, accessNbr);

            ret = multiAccessHelper.callMultiAccess(size, DBA_SET_CONN|DBA_NO_CLOSE|DBA_NO_ERROR, *dbiConn, true);

            if (ret != RET_SUCCEED)
            {
                multiAccessHelper.sendAllMultiAccessMsg();
            }

            /* FREE data but keep accessStp for event_scheduler delete */
            for (i=0; i<accessNbr; i++)
            {
                FREE_DYNST(accessStp[i].data, accessStp[i].entity);
                memset(&(accessStp[i]), 0, sizeof(DBA_ACCESS_ST));
            }

	        if (ret == RET_SUCCEED)
	        {
                accessNbr = 0;

		        /* Verify event scheduler, if one exist and isn't valid, delete it */

                /* REF5260 - Get last synthetic for each portfolio */
                if ((lastPtfSynth = ALLOC_DYNST(S_PtfSynth)) == NULL)
	            {
                    /* rollback and end connection */
					dbiConn->endTransaction(FALSE);
					if (DBA_EndConnection(&dbiConn) != RET_SUCCEED)
	                { MSG_SendMesg(RET_DBA_ERR_DISCONNECTED, 0, FILEINFO);}

                    MSG_LogSrvMesg(UNUSED, 0,
		                "Synthetic Administration %1 to %2 : synthetics and event_schedulers not deleted (see log file)",
		                IntType, begIdx+1,
                        IntType, lastIdx+1);

                    FREE(accessStp);
                    MSG_RETURN(RET_MEM_ERR_ALLOC);
                }

                if ((getEventSched = ALLOC_DYNST(S_EventSched)) == NULL)
		        {
                    /* rollback and end connection */
					dbiConn->endTransaction(FALSE);
					if (DBA_EndConnection(&dbiConn) != RET_SUCCEED)
	                { MSG_SendMesg(RET_DBA_ERR_DISCONNECTED, 0, FILEINFO);}

                    MSG_LogSrvMesg(UNUSED, 0,
		                "Synthetic Administration %1 to %2 : synthetics and event_schedulers not deleted (see log file)",
		                IntType, begIdx+1,
                        IntType, lastIdx+1);

                    FREE(accessStp);
                    FREE_DYNST(lastPtfSynth, S_PtfSynth);
                    MSG_RETURN(RET_MEM_ERR_ALLOC);
                }

		        if ((eventSchedPtr = ALLOC_DYNST(A_EventSched)) == NULL)
		        {
                    /* rollback and end connection */
					dbiConn->endTransaction(FALSE);
					if (DBA_EndConnection(&dbiConn) != RET_SUCCEED)
	                { MSG_SendMesg(RET_DBA_ERR_DISCONNECTED, 0, FILEINFO);}

                    MSG_LogSrvMesg(UNUSED, 0,
		                "Synthetic Administration %1 to %2 : synthetics and event_schedulers not deleted (see log file)",
		                IntType, begIdx+1,
                        IntType, lastIdx+1);

                    FREE(accessStp);
                    FREE_DYNST(lastPtfSynth, S_PtfSynth);
			        FREE_DYNST(getEventSched, S_EventSched);
			        MSG_RETURN(RET_MEM_ERR_ALLOC);
		        }

                DBA_GetDictId(Ptf, &ptfEntDictId);

                SET_DICT(getEventSched,   S_EventSched_EntityDictId,  ptfEntDictId); /* REF8844 - LJE - 030327 */
                SET_ENUM(getEventSched, S_EventSched_NatEn,         (ENUM_T) EventSchedNat_SynthAdmin);

                for (i=begIdx; i<=lastIdx; i++)
                {
                    SET_NULL_DYNST(lastPtfSynth, S_PtfSynth);
	                SET_ID(lastPtfSynth,    S_PtfSynth_PtfId,       GET_ID(ptfTab[i], A_Ptf_Id));

                    SET_ID(getEventSched,   S_EventSched_ObjId,  GET_ID(ptfTab[i], A_Ptf_Id));

	                retLast = DBA_Get2(PtfSynth, DBA_ROLE_PTFSYNTH_ALL, S_PtfSynth, lastPtfSynth,
			                           S_PtfSynth, &lastPtfSynth,
									   DBA_SET_CONN | DBA_NO_CLOSE | DBA_NO_ERROR, *dbiConn, UNUSED);

		            retEvt = DBA_Get2(EventSched, UNUSED, S_EventSched,
	    	                       getEventSched, A_EventSched, &eventSchedPtr,
								   DBA_SET_CONN | DBA_NO_CLOSE | DBA_NO_ERROR, *dbiConn, UNUSED);

		            if (retEvt == RET_SUCCEED)
		            {
                        /* REF5260 - Move get lastPtfSynth before, it is necessary to do it each time */
                        /*           for A_Ptf_SynthLastFinalDate and A_Ptf_SynthRecalcDate update    */

		                /* event scheduler stay valid if there is synthetic after his date */
		                if (retLast == RET_DBA_INFO_NODATA ||
			                (retLast == RET_SUCCEED &&
                            DATETIME_CMP(GET_DATETIME(lastPtfSynth, S_PtfSynth_FinalDate),
							             GET_DATETIME(eventSchedPtr, A_EventSched_FromDate)) < 0))
		                {
                            if ((sEventSched = ALLOC_DYNST(S_EventSched)) == NULL)
		                    {
                                /* rollback and end connection */
								dbiConn->endTransaction(FALSE);
								if (DBA_EndConnection(&dbiConn) != RET_SUCCEED)
	                            { MSG_SendMesg(RET_DBA_ERR_DISCONNECTED, 0, FILEINFO);}

                                MSG_LogSrvMesg(UNUSED, 0,
		                            "Synthetic Administration %1 to %2 : synthetics and event_schedulers not deleted (see log file)",
		                            IntType, begIdx+1,
                                    IntType, lastIdx+1);

                                FREE(accessStp);
                                FREE_DYNST(lastPtfSynth, S_PtfSynth);
			                    FREE_DYNST(getEventSched, S_EventSched);
                                FREE_DYNST(eventSchedPtr, A_EventSched);
			                    MSG_RETURN(RET_MEM_ERR_ALLOC);
                            }

	                        SET_DICT(sEventSched,   S_EventSched_EntityDictId, ptfEntDictId); /* REF8844 - LJE - 030327 */
	                        SET_ID(sEventSched,   S_EventSched_ObjId,     GET_ID(ptfTab[i], A_Ptf_Id));
		                    SET_ENUM(sEventSched, S_EventSched_NatEn,        (ENUM_T) EventSchedNat_SynthAdmin);

	                        accessStp[accessNbr].action = Delete;
	                        accessStp[accessNbr].role   = UNUSED;
	                        accessStp[accessNbr].object = EventSched;
	                        accessStp[accessNbr].entity = S_EventSched;
	                        accessStp[accessNbr].data   = sEventSched;
	                        ++accessNbr;
		                }
		            }

                    /* REF5260 - Update A_Ptf_SynthLastFinalDate and A_Ptf_SynthRecalcDate       */
                    /* if A_Ptf_SynthLastFinalDate is initialised but there isn't any synthetics */
                    /* if A_Ptf_SynthLastFinalDate is initialised and is different from new last */
                    if ((retLast == RET_DBA_INFO_NODATA &&
                        IS_NULLFLD(ptfTab[i], A_Ptf_SynthLastFinalDate) == FALSE) ||
                        (retLast == RET_SUCCEED &&
                         DATETIME_CMP(GET_DATETIME(lastPtfSynth, S_PtfSynth_FinalDate),
                                      GET_DATETIME(ptfTab[i], A_Ptf_SynthLastFinalDate)) != 0))
                    {
                        if (retLast == RET_DBA_INFO_NODATA)
                        {
                            SET_NULL_DATETIME(ptfTab[i], A_Ptf_SynthLastFinalDate);
                            SET_NULL_DATETIME(ptfTab[i], A_Ptf_SynthRecalcDate);
                        }
                        else
                        {
                            SET_DATETIME(ptfTab[i], A_Ptf_SynthLastFinalDate,
                                GET_DATETIME(lastPtfSynth, S_PtfSynth_FinalDate));

                            if (GET_ENUM(lastPtfSynth, S_PtfSynth_PersistEn) == PersistNat_Persist ||
								GET_ENUM(lastPtfSynth, S_PtfSynth_PersistEn) == PersistNat_HierarchicalPersist) /* PMSTA02013 - RAK - 071112 */
                            {
                                SET_DATETIME(ptfTab[i], A_Ptf_SynthRecalcDate,
                                    GET_DATETIME(lastPtfSynth, S_PtfSynth_FinalDate));
                            }
                            else
                            {
                                SET_DATETIME(ptfTab[i], A_Ptf_SynthRecalcDate,
                                    GET_DATETIME(lastPtfSynth, S_PtfSynth_InitialDate));
                            }
                        }

                        accessStp[accessNbr].action = Update;
	                    accessStp[accessNbr].role   = DBA_ROLE_PTFSYNTH_ALL ; /* REF5616 */
	                    accessStp[accessNbr].object = Ptf;
	                    accessStp[accessNbr].entity = A_Ptf;
	                    accessStp[accessNbr].data   = ptfTab[i];
	                    ++accessNbr;
                    }
                }

                if (accessNbr > 0)
                {
                    DbaMultiAccessHelper       multiAccessHelperEvtSchedPtf(accessStp, accessNbr);

                    size = 100;
                    if (accessNbr < 100)
		                size = accessNbr;

                    ret = multiAccessHelperEvtSchedPtf.callMultiAccess(size, DBA_SET_CONN | DBA_NO_CLOSE | DBA_NO_ERROR, *dbiConn, true);

                    if (ret != RET_SUCCEED)
                    {
                        multiAccessHelperEvtSchedPtf.sendAllMultiAccessMsg();
                    }
                }

                FREE_DYNST(lastPtfSynth, S_PtfSynth);
                FREE_DYNST(getEventSched, S_EventSched);
                FREE_DYNST(eventSchedPtr, A_EventSched);
	        }

            if (ret == RET_SUCCEED)
            {
                /* OK, commit transaction */
				dbiConn->endTransaction(TRUE);

                 MSG_LogSrvMesg(UNUSED, 0,
			        "Synthetic Administration %1 to %2 : synthetics and event_schedulers successfully deleted",
			        IntType, begIdx+1,
                    IntType, lastIdx+1);
            }
            else
            {
                /* rollback */
				dbiConn->endTransaction(FALSE);

                MSG_LogSrvMesg(UNUSED, 0,
		            "Synthetic Administration %1 to %2 : synthetics and event_schedulers not deleted (see log file)",
		            IntType, begIdx+1,
                    IntType, lastIdx+1);
            }

            if (DBA_EndConnection(&dbiConn) != RET_SUCCEED)
	        {
                MSG_SendMesg(RET_DBA_ERR_DISCONNECTED, 0, FILEINFO);
	        }

            /* FREE accessStp */
            for (i=0; i<accessNbr; i++)
            {
                /* REF5392 - RAK - 010228 - Don't FREE A_Ptf, done in called function */
                if (accessStp[i].data != NULL && accessStp[i].entity != A_Ptf)
                { FREE_DYNST(accessStp[i].data, accessStp[i].entity); }
            }
            FREE(accessStp);
        }
    }

	return(ret);
}

/************************************************************************
**
**  Function    :   DBA_DelPtfSynthOnePtf()
**
**  Description :   Delete portfolio synthetics for one portfolio
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED         or error code
**
**  Creation    :   DVP261 - RAK - 961205
**  Modif       :   DVP535 - RAK - 970707
**  Modif       :   REF5260 - RAK - 001116
**  Modif       :   REF5392 - RAK - 001228 - Transform DBA_DelPtfSynth() in DBA_DelPtfSynthOnePtf()
**
*************************************************************************/
RET_CODE DBA_DelPtfSynthOnePtf(DBA_DYNFLD_STP sPtfSynthPtr, DBA_DYNFLD_STP *ptfTab, int ptfIdx, int ptfNbr)
{
        RET_CODE        ret, retLast=RET_SUCCEED;
        DBA_DYNFLD_STP  getEventSched=NULL, eventSchedPtr=NULL, lastPtfSynth=NULL;
        DICT_T          ptfEntDictId;
        /* REF5758 - RAK - 010308 - Use transaction */
        DbiConnection   *dbiConn = nullptr;

        if ((lastPtfSynth = ALLOC_DYNST(S_PtfSynth)) == NULL)
        { MSG_RETURN(RET_MEM_ERR_ALLOC); }

        if ((getEventSched = ALLOC_DYNST(S_EventSched)) == NULL)
        {
            FREE_DYNST(lastPtfSynth, S_PtfSynth);
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        if ((eventSchedPtr = ALLOC_DYNST(A_EventSched)) == NULL)
        {
            FREE_DYNST(lastPtfSynth, S_PtfSynth);
            FREE_DYNST(getEventSched, S_EventSched);
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        if ((dbiConn = DBA_GetDbiConnection(SqlServer)) == nullptr)
	    {
	        MSG_SendMesg(RET_DBA_ERR_CONNOTFOUND, 0, FILEINFO);
       	    ret = RET_DBA_ERR_CONNOTFOUND;
	    }
	    else
	    {
	        /* be in a transaction */
	        ret = dbiConn->beginTransaction();

	        if (ret != RET_SUCCEED)
	        {
				if (DBA_EndConnection(&dbiConn, TRUE) != RET_SUCCEED)
                {
                    MSG_SendMesg(RET_DBA_ERR_DISCONNECTED, 0, FILEINFO);
                }
           	    ret = RET_DBA_ERR_CONNOTFOUND;
	        }
	        else
	        {
                /* Delete all synthetics for the portfolio between two dates */
                ret = DBA_Delete2(PtfSynth, DBA_ROLE_PTFSYNTH_ALL,
                                  S_PtfSynth, sPtfSynthPtr,
								  DBA_SET_CONN | DBA_NO_CLOSE | DBA_NO_ERROR, *dbiConn, UNUSED);

                if (ret == RET_SUCCEED)     /* Verify event scheduler, if one exist and isn't valid, delete it */
                {
                    /* REF5260 - Get last synthetic for each portfolio */
                    SET_ID(lastPtfSynth, S_PtfSynth_PtfId, GET_ID(sPtfSynthPtr, S_PtfSynth_PtfId));

                    retLast = DBA_Get2(PtfSynth, DBA_ROLE_PTFSYNTH_ALL, S_PtfSynth, lastPtfSynth,
                                       S_PtfSynth, &lastPtfSynth,
									   DBA_SET_CONN | DBA_NO_CLOSE | DBA_NO_ERROR, *dbiConn, UNUSED);

                    DBA_GetDictId(Ptf, &ptfEntDictId);
                    SET_DICT(getEventSched,   S_EventSched_EntityDictId, ptfEntDictId); /* REF8844 - LJE - 030327 */
                    SET_ID(getEventSched,   S_EventSched_ObjId, GET_ID(sPtfSynthPtr, S_PtfSynth_PtfId));
                    SET_ENUM(getEventSched, S_EventSched_NatEn,    (ENUM_T) EventSchedNat_SynthAdmin);

                    ret = DBA_Get2(EventSched, UNUSED, S_EventSched,
                           getEventSched, A_EventSched, &eventSchedPtr,
						   DBA_SET_CONN | DBA_NO_CLOSE | DBA_NO_ERROR, *dbiConn, UNUSED);

                    if (ret == RET_SUCCEED)
                    {
                        /* REF5260 - Move get lastPtfSynth before, it is necessary to do it each time */
                        /*           for A_Ptf_SynthLastFinalDate and A_Ptf_SynthRecalcDate update    */
                        /* event scheduler stay valid if there is synthetic after his date */
                        if (retLast == RET_DBA_INFO_NODATA ||
                            (retLast == RET_SUCCEED &&
                            DATETIME_CMP(GET_DATETIME(lastPtfSynth, S_PtfSynth_FinalDate),
                                         GET_DATETIME(eventSchedPtr, A_EventSched_FromDate))< 0))
                        {
                            ret = DBA_Delete2(EventSched, UNUSED,
                                      S_EventSched, getEventSched,
									  DBA_SET_CONN | DBA_NO_CLOSE | DBA_NO_ERROR, *dbiConn, UNUSED);
                        }
                    }
                    else
                        ret = RET_SUCCEED;      /* no event sched to delete, do the next step */

                    /* REF5260 - Update A_Ptf_SynthLastFinalDate and A_Ptf_SynthRecalcDate       */
                    /* if A_Ptf_SynthLastFinalDate is initialised but there isn't any synthetics */
                    /* if A_Ptf_SynthLastFinalDate is initialised and is different from new last */
                    if (ret == RET_SUCCEED &&
                        (retLast == RET_DBA_INFO_NODATA &&
                        IS_NULLFLD(ptfTab[ptfIdx], A_Ptf_SynthLastFinalDate) == FALSE) ||
                        (retLast == RET_SUCCEED &&
                        DATETIME_CMP(GET_DATETIME(lastPtfSynth, S_PtfSynth_FinalDate),
                                     GET_DATETIME(ptfTab[ptfIdx], A_Ptf_SynthLastFinalDate)) != 0))
                    {
                        if (retLast == RET_DBA_INFO_NODATA)
                        {
                            SET_NULL_DATETIME(ptfTab[ptfIdx], A_Ptf_SynthLastFinalDate);
                            SET_NULL_DATETIME(ptfTab[ptfIdx], A_Ptf_SynthRecalcDate);
                        }
                        else
                        {
                            SET_DATETIME(ptfTab[ptfIdx], A_Ptf_SynthLastFinalDate,
                                GET_DATETIME(lastPtfSynth, S_PtfSynth_FinalDate));

                            if (GET_ENUM(lastPtfSynth, S_PtfSynth_PersistEn) == PersistNat_Persist ||
								GET_ENUM(lastPtfSynth, S_PtfSynth_PersistEn) == PersistNat_HierarchicalPersist) /* PMSTA02013 - RAK - 071112 */
                            {
                                SET_DATETIME(ptfTab[ptfIdx], A_Ptf_SynthRecalcDate,
                                    GET_DATETIME(lastPtfSynth, S_PtfSynth_FinalDate));
                            }
                            else
                            {
                                SET_DATETIME(ptfTab[ptfIdx], A_Ptf_SynthRecalcDate,
                                    GET_DATETIME(lastPtfSynth, S_PtfSynth_InitialDate));
                            }
                        }

                        ret = DBA_Update2(Ptf, DBA_ROLE_PTFSYNTH_ALL, A_Ptf, ptfTab[ptfIdx],
							DBA_SET_CONN | DBA_NO_CLOSE | DBA_NO_ERROR, *dbiConn, UNUSED);
                    }
                }

                if (ret == RET_SUCCEED)
                {
                    /* OK, commit transaction */
		            dbiConn->endTransaction(TRUE);

                    MSG_LogSrvMesg(UNUSED, 0,
	                    "Synthetic Administration %1 of %2 : portfolio %3 synthetics and event scheduler successfully deleted",
	                    IntType, ptfIdx+1, IntType, ptfNbr,
	                    CodeType, GET_CODE(ptfTab[ptfIdx], A_Ptf_Cd));
                }
                else
                {
                    /* rollback */
					dbiConn->endTransaction(FALSE);

                    MSG_LogSrvMesg(UNUSED, 0,
		               "Synthetic Administration %1 of %2 : portfolio %3 synthetics and event scheduler not deleted (see log file)",
		               IntType, ptfIdx+1, IntType, ptfNbr,
		               CodeType, GET_CODE(ptfTab[ptfIdx], A_Ptf_Cd));
                }
            }

            if (DBA_EndConnection(&dbiConn) != RET_SUCCEED)
	        {
		        MSG_SendMesg(RET_DBA_ERR_DISCONNECTED, 0, FILEINFO);
	        }
        }

        FREE_DYNST(lastPtfSynth, S_PtfSynth);
        FREE_DYNST(eventSchedPtr, A_EventSched);
        FREE_DYNST(getEventSched, S_EventSched);
        return(ret);
}

/************************************************************************
**
**  Function    :   DBA_SelExtStratElt()
**
**  Description :   Select current extended strategy element
**		    for received strategy
**
**  Arguments   :   stratId	strategy identifier
**		    mktSgtId	market segment identifier
**		    fctResId	function result identifier
**                  fmtEltNbr	format element number
**				add to GET_FLD_NBR() for allocate ExtStratElt
**		    ESETab	pointer on ExtStratElt array
**		    ESENbr	pointer on ExtStratElt number
**		    domainStp   pointer on current edited domain
**
**  Warning	:   a REALLOC is used
**		    (ESETab must be set to NULL and ESENbr must be set to 0 the first time)
**
**  Return      :   RET_SUCCEED or error code
**
**  Cr�ation	:   RAK - 970528 - DVP460
**  Modif.      :   ROI - 970617 - DVP471
**              :   FIH - 981109 - REF2962
**              :   CSY - 000118 - REF4236: stratHistPtr: pointer on A_StratHist instead
**                                          of S_StratHist for call of DBA_Get2
**
*************************************************************************/
RET_CODE DBA_SelExtStratElt(ID_T 		        stratId,
                            ID_T		        mktSgtId,
                            ID_T		        fctResId,
                            DBA_DYNFLD_STP      shMktSegStp,            /*  FPL-PMSTA05599-100122   */
                            DATETIME_T		    stratDateTime,
                            int 		        fmtEltNbr,
                            DBA_DYNFLD_STP *    retESETab,
                            int *               retESENbr,
                            DBA_DYNFLD_STP      domainStp)
{
	DBA_DYNFLD_STP			getArg=NULL, stratHistPtr=NULL, getInstr=NULL,
							*stratEltTab=NULL, ESEPtr=NULL, *ESETab=NULL, *newStratEltTab=NULL,
							instrPtr=NULL, ptr;
    SCPT_DFLTVAL_STP    	scptPtr=NULL;
	FLAG_T					*forcedFlgTab;
	int						i, stratEltNbr=0, newStratEltNbr=0, retCode, newESENbr=0, extSize, ESENbr=0;
	SCPT_CLASSIFSTACK_STP	classifStack=NULL;
	RET_CODE				ret;
	DOMORDERALLOCNAT_ENUM	domOrderAllocNatEn=DomOrderAllocNat_None;	/* PMSTA05316 - RAK - 080204 */
    FLAG_T                  isInListFlg;    /*  FPL-PMSTA05599-100122   */

	/* PMSTA05316 - RAK - 080205 */
	if (domainStp != NULL)
		domOrderAllocNatEn = (DOMORDERALLOCNAT_ENUM)GET_ENUM(domainStp, A_Domain_OrderAllocNatEn);

	if (*retESETab == NULL && *retESENbr != 0)
	{
	   	MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
			     "DBA_SelExtStratElt", "ESENbr and ESETab");
	   	return(RET_GEN_ERR_INVARG);
	}

	if (stratId == 0 && fctResId == 0)
	{
	   	MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
			     "DBA_SelExtStratElt", "strategy and function result id are NULL");
	   	return(RET_GEN_ERR_INVARG);
	}

	if (stratId != 0)
	{
	    /*** --------------- ***/
	    /* Load short StratElt */
	    /*** --------------- ***/
	    if ((getArg = ALLOC_DYNST(Adm_Arg)) == NULL)
	    { MSG_RETURN(RET_MEM_ERR_ALLOC); }

        /* REF4236 - CSY - 000118: replace S_StratHist with A_StratHist */
	    if ((stratHistPtr = ALLOC_DYNST(A_StratHist)) == NULL)
	    {
			FREE_DYNST(stratHistPtr, A_StratHist);
	   		MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }

	    SET_ID(getArg,       Adm_Arg_Id,   stratId);
	    SET_DATETIME(getArg, Adm_Arg_Date, stratDateTime);

        /* REF4236 - CSY - 000118: replace S_StratHist with A_StratHist */
	    if ((ret = DBA_Get2(StratHist, DBA_ROLE_GET_LAST_STRAT_HIST,
			        Adm_Arg, getArg, A_StratHist, &stratHistPtr,
	                        UNUSED, UNUSED)) != RET_SUCCEED)
	    {
			FREE_DYNST(getArg, Adm_Arg);
			FREE_DYNST(stratHistPtr, A_StratHist);
			return(ret);
	    }

        /* REF4236 - CSY - 000118: replace S_StratHist with A_StratHist */
	    SET_ID(getArg, Adm_Arg_Id, GET_ID(stratHistPtr, A_StratHist_Id));
	    FREE_DYNST(stratHistPtr, A_StratHist);

	    if ((ret = DBA_Select2(StratElt, UNUSED, Adm_Arg, getArg, S_StratElt, &stratEltTab,
			           UNUSED, UNUSED, &stratEltNbr, UNUSED)) != RET_SUCCEED)
	    {
			FREE_DYNST(getArg, Adm_Arg);
			return(ret);
	    }
	    FREE_DYNST(getArg, Adm_Arg);

	    if (stratEltNbr == 0)
			return(RET_SUCCEED);

		/* PMSTA05316 - RAK - 080205 - Remove some nature according to domain allocation nature */
		if (domOrderAllocNatEn == DomOrderAllocNat_SwitchInstr ||
			domOrderAllocNatEn == DomOrderAllocNat_CashResultPctPtf ||
			domOrderAllocNatEn == DomOrderAllocNat_MktSgtResultPctPtf)
		{
			newStratEltNbr = 0;

			if ((newStratEltTab=(DBA_DYNFLD_STP*)
			      CALLOC(stratEltNbr, sizeof(DBA_DYNFLD_STP)))==NULLDYNST)
			{
				DBA_FreeDynStTab(stratEltTab, stratEltNbr, S_StratElt);
				MSG_RETURN(RET_MEM_ERR_ALLOC);
			}

			for (i=0; i<stratEltNbr; i++)
			{
				if (domOrderAllocNatEn == DomOrderAllocNat_SwitchInstr)
				{
					if (GET_ENUM(stratEltTab[i], S_StratElt_RecomNatEn) != RecommNat_Keep &&
						GET_ENUM(stratEltTab[i], S_StratElt_RecomNatEn) != RecommNat_Neutral)
					{
						newStratEltTab[newStratEltNbr] = stratEltTab[i];
						newStratEltNbr++;
					}
					else
					{
						FREE_DYNST(stratEltTab[i], S_StratElt);
					}
				}
				else if (domOrderAllocNatEn == DomOrderAllocNat_CashResultPctPtf ||
						 domOrderAllocNatEn == DomOrderAllocNat_MktSgtResultPctPtf)
				{
					if (GET_ENUM(stratEltTab[i], S_StratElt_RecomNatEn) != RecommNat_Keep)
					{
						newStratEltTab[newStratEltNbr] = stratEltTab[i];
						newStratEltNbr++;
					}
					else
					{
						FREE_DYNST(stratEltTab[i], S_StratElt);
					}
				}
			}

			/* replace (because of some remove) */
			if (newStratEltNbr != stratEltNbr)
			{
				/* smaller */
				newStratEltTab = (DBA_DYNFLD_STP*) REALLOC((DBA_DYNFLD_STP*)newStratEltTab, newStratEltNbr * sizeof(DBA_DYNFLD_STP));

				FREE(stratEltTab);
				stratEltNbr = newStratEltNbr;
				stratEltTab = newStratEltTab;
			}
		}

	    if (mktSgtId == 0)
		{
			newESENbr = stratEltNbr;

		}
	    else
	    {
			/*** ------------------------------------------------ ***/
			/* Return only received market segment strategy element */
			/*** ------------------------------------------------ ***/
			if ((getInstr = ALLOC_DYNST(S_Instr)) == NULL)
	        {
				DBA_FreeDynStTab(stratEltTab, stratEltNbr, S_StratElt);
				MSG_RETURN(RET_MEM_ERR_ALLOC);
	        }

	        if ((instrPtr = ALLOC_DYNST(A_Instr)) == NULL)
	        {
				DBA_FreeDynStTab(stratEltTab, stratEltNbr, S_StratElt);
				FREE_DYNST(getInstr, S_Instr);
	   			MSG_RETURN(RET_MEM_ERR_ALLOC);
	        }

	        if ((classifStack=(SCPT_CLASSIFSTACK_STP)
			      CALLOC(20,sizeof(SCPT_CLASSIFSTACK_ST)))==NULL)
	        {
				DBA_FreeDynStTab(stratEltTab, stratEltNbr, S_StratElt);
				FREE_DYNST(getInstr, S_Instr);
				FREE_DYNST(instrPtr, A_Instr);
				MSG_RETURN(RET_MEM_ERR_ALLOC);
	        }

            for (i=0; i<stratEltNbr; i++)
            {
                SET_ID(getInstr, S_Instr_Id, GET_ID(stratEltTab[i], S_StratElt_InstrId));
                if ((ret = DBA_Get2(Instr, UNUSED, S_Instr, getInstr, A_Instr, &instrPtr,
                                    UNUSED, UNUSED)) != RET_SUCCEED)
                {
                    SYSNAME_T entSqlName;
                    strcpy(entSqlName, DBA_GetDictEntitySqlName(Instr));
                    MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO,
                                entSqlName, GET_ID(getInstr, S_Instr_Id));
                    DBA_FreeDynStTab(stratEltTab, stratEltNbr, S_StratElt);
                    FREE_DYNST(getInstr, S_Instr);
                    FREE_DYNST(instrPtr, A_Instr);
                    SCPT_FreeClassifStack(&classifStack);
                    return(RET_DBA_ERR_NODATA);
                }

		        /*  if ((     FPL-PMSTA05599-100120 test done down  */
                retCode = FIN_SearchInstrInMktSegt ( NULL, /* REF3678 - RAK - 990817 - Add hierHead ptr */
			                                         mktSgtId,
                                                     GET_ID(stratEltTab[i], S_StratElt_InstrId),
			                                         instrPtr,
                                                     0,
                                                     FALSE,
                                                     classifStack,
                                                     UNUSED,
                                                     UNUSED,
                                                     0,
                                                     NULL
                                                   );
                /*) == TRUE)*/ /* REF8834 - CHU - 031119 */ /* REF9715 - CHU - 041124 */
                if (retCode == TRUE)
		        {
                    ++newESENbr;
                }
		        else    /*  FPL-PMSTA05599-100125   */
		        {
                    if ((IS_NULLFLD(shMktSegStp, S_MktSegt_OrdinateListId) == TRUE) &&
                        ((retCode = FIN_IsInList ( NULL
                                                 , GET_ID(stratEltTab[i], S_StratElt_InstrId)
                                                 , NULLDYNST
                                                 , Instr
                                                 , GET_ID(shMktSegStp, S_MktSegt_AbcissaListId)
                                                 , NULLDYNSTPTR
                                                 , NULL
                                                 , FALSE
                                                 , NULL
                                                 , &isInListFlg)) == RET_SUCCEED) &&
                        (isInListFlg == TRUE))
                    {
                        ++newESENbr;
                    }
                    else
                        SET_FLAG(stratEltTab[i], S_StratElt_NoMktSgtFlg, TRUE);
	            }
            }
            FREE_DYNST(getInstr, S_Instr);
            FREE_DYNST(instrPtr, A_Instr);
            SCPT_FreeClassifStack(&classifStack);
	    }
	}
	else
	{
	    /*** ------------------- ***/
	    /* Load stored ExtStratElt */
	    /*** ------------------- ***/
	    if ((getArg = ALLOC_DYNST(Get_Arg)) == NULL)
	    { MSG_RETURN(RET_MEM_ERR_ALLOC); }

	    SET_ID(getArg,   Get_Arg_Id,   fctResId);
	    SET_FLAG(getArg, Get_Arg_Flag, TRUE);

	    /* Load ExtStratElt */
	    if (DBA_Select2(EStratElt, UNUSED, Get_Arg, getArg, ExtStratElt, &ESETab,
		            UNUSED, UNUSED, &ESENbr, UNUSED) != RET_SUCCEED)
	    {
			FREE_DYNST(getArg, Get_Arg);
			return(RET_DBA_ERR_NODATA);
	    }
	    FREE_DYNST(getArg, Get_Arg);
	    newESENbr = ESENbr;
	}

	if (newESENbr > 0)
	{
	    /*** ----------------------------- ***/
	    /* Reallocate bloc for returned data */
	    /*** ----------------------------- ***/
	    extSize = newESENbr * (GET_FLD_NBR(ExtStratElt)+fmtEltNbr);
        /* REF8844 - LJE - 030403 */
        if (((*retESETab) = REALLOC_DYNSTTAB_WITHOUTDEF((*retESETab), GET_FLD_NBR(ExtStratElt)+fmtEltNbr, newESENbr)) == NULL)
	    {
			if (stratId != 0)
			{	DBA_FreeDynStTab(stratEltTab, stratEltNbr, S_StratElt); }
			else
			{	DBA_FreeDynStTab(ESETab, ESENbr, ExtStratElt); }
			MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }

        /* FPL-REF8844-030530 */
        memset((*retESETab), 0, extSize*sizeof(DBA_DYNFLD_ST));

        /* REF8844 - LJE - 030403 */
        for (i=0; i<newESENbr; i++)
        {
            DICT_DynStDatatypeSet(&(*retESETab)[i*(GET_FLD_NBR(ExtStratElt)+fmtEltNbr)], ExtStratElt);
        }

	    if (stratId != 0)
	    {
			/*** ----------------------------------- ***/
			/* Transform short StratElt to ExtStratElt */
			/*** ----------------------------------- ***/
	        if ((forcedFlgTab = (FLAG_T *) CALLOC(GET_FLD_NBR(ExtStratElt),
					   sizeof(FLAG_T))) == NULL)   /* REF7264 - PMO */
	        {
	    	    FREE((*retESETab));
	            DBA_FreeDynStTab(stratEltTab, stratEltNbr, S_StratElt);
		        return(RET_MEM_ERR_ALLOC);
	        }

	        if ((ret = SCPT_InitEntityDefVal(EStratElt, &scptPtr, TRUE, 0)) != RET_SUCCEED)
	        {
		        FREE((*retESETab));
	            DBA_FreeDynStTab(stratEltTab, stratEltNbr, S_StratElt);
		        FREE(forcedFlgTab);
		        return(ret);
	        }

            /*  FIH-REF2962-981109 */
            if (domainStp != NULL)
            {
                SCPT_SetDomain(scptPtr, domainStp);
            }

	        if ((ESEPtr = ALLOC_DYNST(ExtStratElt)) == NULL)
	        {
		        FREE((*retESETab));
	            DBA_FreeDynStTab(stratEltTab, stratEltNbr, S_StratElt);
		        FREE(forcedFlgTab);
	            MSG_RETURN(RET_MEM_ERR_ALLOC);
	        }

	        for (i=0, ptr=*retESETab; i<stratEltNbr; i++)
	        {
	            if (GET_FLAG(stratEltTab[i], S_StratElt_NoMktSgtFlg) == FALSE)
	            {
					DBA_CopyDynFld(ESEPtr, ExtStratElt, ExtStratElt_Id, stratEltTab[i], S_StratElt, S_StratElt_Id);
					forcedFlgTab[ExtStratElt_Id] = TRUE;

					DBA_CopyDynFld(ESEPtr, ExtStratElt, ExtStratElt_InstrId, stratEltTab[i], S_StratElt, S_StratElt_InstrId);
					forcedFlgTab[ExtStratElt_InstrId] = TRUE;

					DBA_CopyDynFld(ESEPtr, ExtStratElt, ExtStratElt_StratId, stratEltTab[i], S_StratElt, S_StratElt_StratId);
					forcedFlgTab[ExtStratElt_StratId] = TRUE;

					DBA_CopyDynFld(ESEPtr, ExtStratElt, ExtStratElt_Denom, stratEltTab[i], S_StratElt, S_StratElt_Denom);
					forcedFlgTab[ExtStratElt_Denom] = TRUE;

					DBA_CopyDynFld(ESEPtr, ExtStratElt, ExtStratElt_MktSegtId, stratEltTab[i], S_StratElt, S_StratElt_MktSegId);
					forcedFlgTab[ExtStratElt_MktSegtId] = TRUE;

					DBA_CopyDynFld(ESEPtr, ExtStratElt, ExtStratElt_StratHistId, stratEltTab[i], S_StratElt, S_StratElt_StratHistId);
					forcedFlgTab[ExtStratElt_StratHistId] = TRUE;

					DBA_CopyDynFld(ESEPtr, ExtStratElt, ExtStratElt_Rank, stratEltTab[i], S_StratElt, S_StratElt_Rank);
					forcedFlgTab[ExtStratElt_Rank] = TRUE;

					DBA_CopyDynFld(ESEPtr, ExtStratElt, ExtStratElt_MaxWeightContrib, stratEltTab[i], S_StratElt, S_StratElt_Value);
					forcedFlgTab[ExtStratElt_MaxWeightContrib] = TRUE;

					DBA_CopyDynFld(ESEPtr, ExtStratElt, ExtStratElt_ObjWeightMarg, stratEltTab[i], S_StratElt, S_StratElt_FluctMargin);
					forcedFlgTab[ExtStratElt_ObjWeightMarg] = TRUE;

					DBA_CopyDynFld(ESEPtr, ExtStratElt, ExtStratElt_ObjConstrLimitNatEn, stratEltTab[i], S_StratElt, S_StratElt_LimitNatEn);
					forcedFlgTab[ExtStratElt_ObjConstrLimitNatEn] = TRUE;

					DBA_CopyDynFld(ESEPtr, ExtStratElt, ExtStratElt_RecomNatEn, stratEltTab[i], S_StratElt, S_StratElt_RecomNatEn);
					forcedFlgTab[ExtStratElt_RecomNatEn] = TRUE;

					/* PMSTA05316 - RAK - 080205 - Change some recommendation nature according to domain allocation nature */
					if (domOrderAllocNatEn == DomOrderAllocNat_SwitchInstr      ||
						domOrderAllocNatEn == DomOrderAllocNat_CashResultPctPtf ||
						domOrderAllocNatEn == DomOrderAllocNat_MktSgtResultPctPtf)
					{
						if (GET_ENUM(ESEPtr, ExtStratElt_RecomNatEn) == RecommNat_Reduce)
						{
							SET_ENUM(ESEPtr, ExtStratElt_RecomNatEn, RecommNat_Sell);
						}
						else if (GET_ENUM(ESEPtr, ExtStratElt_RecomNatEn) == RecommNat_Increase)
						{
							SET_ENUM(ESEPtr, ExtStratElt_RecomNatEn, RecommNat_Buy);
						}
					}

					/* Init the current dbaDynStp with default value */
					DBA_SetDfltEntityFld(EStratElt, ExtStratElt, ESEPtr);

					/* Init the current dbaDynStp with default value From ScriptDef */
					ret = SCPT_AnalyseEntityDefVal(scptPtr,
												   forcedFlgTab,
                                                   NULL,              /* HFI-PMSTA-25327-171023  Dedicated flag tab for filter    */
												   ESEPtr,
												   TRUE,
												   EvalType_DefVal, /* ROI - 000328 - REF4497 */    /*  FPL-REF9507-030930  Replace FALSE by EvalType_DefVal    */
												   NULL,    /*  FIH-REF7323-020620  */
												   NULL,    /*  FIH-REF7323-020620  */
												   FALSE    /*  FPL-REF9215-030811  */
												  );
					if (ret != RET_SUCCEED)
					{
						DBA_FreeDynStTab(stratEltTab, stratEltNbr, S_StratElt);
						FREE_DYNST(ESEPtr, ExtStratElt);
						FREE(forcedFlgTab);
						return(ret);
					}

					COPY_DYNST(ptr, ESEPtr, ExtStratElt);
					if (ptr != NULL)
					{
						SET_NULL_ID(ptr, ExtStratElt_ActRiskESEltId); /* PMSTA-19942 - CHU - 150213 */
						SET_NULL_ID(ptr, ExtStratElt_EffRiskESEltId); /* PMSTA-19942 - CHU - 150213 */
					}

					ptr = ptr + (GET_FLD_NBR(ExtStratElt)+fmtEltNbr);
	            }
	        }

	        FREE_DYNST(ESEPtr, ExtStratElt);
	        FREE(forcedFlgTab);
			DBA_FreeDynStTab(stratEltTab, stratEltNbr, S_StratElt);
	    }
	    else
	    {
	        for (i=0, ptr=*retESETab; i<ESENbr; i++)
	        {
		     COPY_DYNST(ptr, ESETab[i],  ExtStratElt);
			 if (ptr != NULL)
			 {
				 SET_NULL_ID(ptr, ExtStratElt_ActRiskESEltId); /* PMSTA-19942 - CHU - 150213 */
				 SET_NULL_ID(ptr, ExtStratElt_EffRiskESEltId); /* PMSTA-19942 - CHU - 150213 */
			 }

		     ptr = ptr + (GET_FLD_NBR(ExtStratElt)+fmtEltNbr);
		}
		DBA_FreeDynStTab(ESETab, ESENbr, ExtStratElt);
	    }
	}

	*retESENbr = newESENbr;
	return(RET_SUCCEED);
}




/************************************************************************
**
**  Function    :   DBA_SelHedgeRule()
**
**  Description :   Select Hedging Rule
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation	:   PMSTA-44959 - LIK - 210429
**
*************************************************************************/
RET_CODE DBA_SelHedgeRule(ID_T 		        hedgeId,
    ID_T		        fctResId,
    DBA_DYNFLD_STP      shMktSegStp,
    DATETIME_T		    stratDateTime,
    int 		        fmtEltNbr,
    DBA_DYNFLD_STP *    retHedgeTab,
    int *               retHedgeNbr,
    DBA_DYNFLD_STP      domainStp)
{
    DBA_DYNFLD_STP			getArg = NULL,
        *hedgeRulesTab = NULL, ptr;
    int						i, hedgeRuleNbr = 0, extSize;


    if (*retHedgeTab == NULL && *retHedgeNbr != 0)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
            "DBA_SelHedgeRule", "HedgeNumber and HedgeRuleTab");
        return(RET_GEN_ERR_INVARG);
    }

    if (hedgeId == 0 && fctResId == 0)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
            "DBA_SelHedgeRule", "hedgerule and function result id are NULL");
        return(RET_GEN_ERR_INVARG);
    }


    if ((getArg = ALLOC_DYNST(Get_Arg)) == NULL)
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }
    if (hedgeId != 0)
    {
        SET_ID(getArg, Get_Arg_Id, hedgeId);
        SET_FLAG(getArg, Get_Arg_Flag, TRUE);

    }
    else
    {

        SET_ID(getArg, Get_Arg_Id, fctResId);
        SET_FLAG(getArg, Get_Arg_Flag, FALSE);
    }


    if (DBA_Select2(HedgingRules, UNUSED, Get_Arg, getArg, A_HedgingRules, &hedgeRulesTab,
        UNUSED, UNUSED, &hedgeRuleNbr, UNUSED) != RET_SUCCEED)
    {
        FREE_DYNST(getArg, Get_Arg);
        return(RET_DBA_ERR_NODATA);
    }
    FREE_DYNST(getArg, Get_Arg);


    if (hedgeRuleNbr > 0)
    {
        /*** ----------------------------- ***/
        /* Reallocate bloc for returned data */
        /*** ----------------------------- ***/
        extSize = hedgeRuleNbr * (GET_FLD_NBR(A_HedgingRules) + fmtEltNbr);
        if (((*retHedgeTab) = REALLOC_DYNSTTAB_WITHOUTDEF((*retHedgeTab), GET_FLD_NBR(A_HedgingRules) + fmtEltNbr, hedgeRuleNbr)) == NULL)
        {
                DBA_FreeDynStTab(hedgeRulesTab, hedgeRuleNbr, A_HedgingRules);
        }

        memset((*retHedgeTab), 0, extSize * sizeof(DBA_DYNFLD_ST));

        for (i = 0; i < hedgeRuleNbr; i++)
        {
            DICT_DynStDatatypeSet(&(*retHedgeTab)[i*(GET_FLD_NBR(A_HedgingRules) + fmtEltNbr)], A_HedgingRules);
        }


        for (i = 0, ptr = *retHedgeTab; i < hedgeRuleNbr; i++)
        {
            COPY_DYNST(ptr, hedgeRulesTab[i], A_HedgingRules);
            ptr = ptr + (GET_FLD_NBR(A_HedgingRules) + fmtEltNbr);
        }
        DBA_FreeDynStTab(hedgeRulesTab, hedgeRuleNbr, A_HedgingRules);
    }


    *retHedgeNbr = hedgeRuleNbr;
    return(RET_SUCCEED);
}

/*  FPL-REF9507-030930  The fucntion DBA_NewFctResultOld2 is no more called */

/************************************************************************
*
*  Function          : DBA_SetTascJobPtfDim()
*
*  Description       : Set the entity or the ptf dimension for
*                      the case of use tasc job informations
*
*  Arguments         :
*
*  Creation date     : PMSTA08246 - LJE - 090722
*  Last modif.       : OCS-49362 - TEB - 170508
*************************************************************************/
/*STATIC*/ void DBA_SetTascJobPtfDim(DBA_DYNFLD_STP domainArg, int *connectNo)
{
	OBJECT_ENUM dimEntityObj=NullEntity, dimPtfObj=NullEntity;
	DICT_T      quickSearchEntityDictId;
	DBA_DYNFLD_STP  tascJobSt = NULL;               /* OCS-49362 - TEB - 170508 */
	DICT_T          thirdDictId;
	int			    dbaOptions;

	DBA_GetDictId(Third, &thirdDictId);			/* OCS-49362 - TEB - 170508 */

	/* PMSTA-30900 - RAK - 180518 - Yess we have a JobRef but as we are reloaded session don't use this processing */
	if (IS_NULLFLD(domainArg, A_Domain_JobReference) == TRUE ||
		((GET_DICT(domainArg, A_Domain_InitialFctDictId) == DictFct_OrderEntry ||
		  GET_DICT(domainArg, A_Domain_InitialFctDictId) == DictFct_SessionsMonitoring) && GET_ENUM(domainArg, A_Domain_OutputTpEn) == ClientModuleOutput))
	{
		SET_FLAG(domainArg, A_Domain_TSLPtfDimModifiedFlg, FALSE);
		return;
	}
	/* OCS-49362 - TEB - 170508 */
	else if (IS_NULLFLD(domainArg, A_Domain_ChunkNumber) == FALSE &&
		GET_INT(domainArg, A_Domain_ChunkNumber) > 0 &&
		IS_NULLFLD(domainArg, A_Domain_DimPtfDictId) == FALSE &&
		GET_DICT(domainArg, A_Domain_DimPtfDictId) == thirdDictId)
	{
		/* Check if the job is a entity precomp or financial precomp => switch to because... */
		if (connectNo != NULL)
			dbaOptions = DBA_SET_CONN | DBA_NO_CLOSE;
		else
			dbaOptions = UNUSED;


		if ((tascJobSt = ALLOC_DYNST(A_TascJob)) != NULL  &&
			 DBA_Get2(TascJob,
					  UNUSED,
					  A_Domain,
					  domainArg,
					  A_TascJob,
					  &tascJobSt,
					  dbaOptions,
					  connectNo,
					  UNUSED) == RET_SUCCEED  &&
			 tascJobSt != NULL &&
			 IS_NULLFLD(tascJobSt, A_TascJob_ModeEn) == FALSE &&
			 ((GET_ENUM(tascJobSt, A_TascJob_ModeEn) == TascJobMode_Reporting && GET_ENUM(tascJobSt, A_TascJob_AccessEn) == TascJobAccess_RepDb )
                 || GET_ENUM(tascJobSt, A_TascJob_ModeEn) == TascJobMode_PrecompGlobalFinancialCreate) &&  /* OCS-49362 - TEB - 170606 */
			 GET_DICT(tascJobSt, A_TascJob_EntityDictId) == thirdDictId
			)
		{
            /* PMSTA-45598 ,case when portfolio_dimension_e = ThirPaty List, the domain must not be modified */
            FREE_DYNST(tascJobSt, A_TascJob);
            return;
		}
		FREE_DYNST(tascJobSt, A_TascJob);
	} /* OCS-49362 - TEB - 170508 */


    /*  FPL-PMSTA11939-110707   */
    if (GET_ENUM(domainArg, A_Domain_OutputTpEn) == TSLDimPort)
    {
        return ;
    }

	DBA_GetObjectEnum(GET_DICT(domainArg, A_Domain_DimEntityDictId), &dimEntityObj);
	DBA_GetObjectEnum(GET_DICT(domainArg, A_Domain_DimPtfDictId),    &dimPtfObj);

	DBA_GetDictId(QuickSearch, &quickSearchEntityDictId);

	switch (GET_OBJECT_CST(dimEntityObj))
	{
	case ListCst:
    case OneCst: /* BM-287 - LJE - 120823 */
		/* SET_DICT(domainArg,           A_Domain_SavedDimEntityDictId,  GET_DICT(domainArg, A_Domain_DimEntityDictId));*/
		COPY_DYNFLD(domainArg, A_Domain, A_Domain_SavedDimEntityDictId, domainArg, A_Domain, A_Domain_DimEntityDictId); /* OCS37463-CHU-110413 */
		SET_DICT(domainArg, A_Domain_DimEntityDictId, quickSearchEntityDictId);
		SET_FLAG(domainArg, A_Domain_TSLPtfDimModifiedFlg, TRUE);
		break;
	case NullEntityCst:
	case EmptyCst:
		switch (GET_OBJECT_CST(dimPtfObj))
		{
		case ThirdCst:
		case ListCst:
		case PtfCst:	/* PMSTA12245-CHU-110705 */
		case InstrCst:	/* PMSTA12245-CHU-110705 */
		case StratCst:	/* PMSTA12245-CHU-110705 */
        case NullEntityCst:
        case EmptyCst:
			/* SET_DICT(domainArg,           A_Domain_SavedDimPtfDictId,  GET_DICT(domainArg, A_Domain_DimPtfDictId)); */
			COPY_DYNFLD(domainArg, A_Domain, A_Domain_SavedDimPtfDictId, domainArg, A_Domain, A_Domain_DimPtfDictId); /* OCS37463-CHU-110413 */
			SET_DICT(domainArg, A_Domain_DimPtfDictId, quickSearchEntityDictId);
			SET_FLAG(domainArg, A_Domain_TSLPtfDimModifiedFlg, TRUE);
			break;
		}
	}

	if (GET_FLAG(domainArg, A_Domain_TSLPtfDimModifiedFlg) == TRUE)
	{
		if (IS_NULLFLD(domainArg, A_Domain_PtfListDef) == FALSE)
		{
			/* SET_TEXT(domainArg, A_Domain_SavedPtfListDef, GET_TEXT(domainArg, A_Domain_PtfListDef)); */
			SET_STRING(domainArg, A_Domain_SavedPtfListDef, GET_TEXT(domainArg, A_Domain_PtfListDef)); /* PMSTA-17973 - CHU - 140416 */
		}
		SET_NULL_TEXT(domainArg, A_Domain_PtfListDef);

		/* SET_ID(domainArg,             A_Domain_SavedPtfObjId,    GET_ID(domainArg, A_Domain_PtfObjId)); */
		COPY_DYNFLD(domainArg, A_Domain, A_Domain_SavedPtfObjId, domainArg, A_Domain, A_Domain_PtfObjId); /* OCS37463-CHU-110413 */
		SET_NULL_ID(domainArg, A_Domain_PtfObjId);
	}
}

/************************************************************************
*
*  Function          : DBA_RestorePtfDim()
*
*  Description       :
*
*  Arguments         :
*
*  Creation date     : PMSTA08246 - LJE - 090722
*  Last modif.       :
*************************************************************************/
/*STATIC*/ void   DBA_RestorePtfDim(DBA_DYNFLD_STP domainArg)
{
    OBJECT_ENUM dimEntityObj = NullEntity, dimPtfObj = NullEntity;
    DICT_T      quickSearchEntityDictId;

    DBA_GetObjectEnum(GET_DICT(domainArg, A_Domain_DimEntityDictId), &dimEntityObj);
    DBA_GetObjectEnum(GET_DICT(domainArg, A_Domain_DimPtfDictId), &dimPtfObj);

    DBA_GetDictId(QuickSearch, &quickSearchEntityDictId);

	if (GET_FLAG(domainArg, A_Domain_TSLPtfDimModifiedFlg) == TRUE)
	{
        /* PMSTA09800 - DDV - 100511 - Restore values only if value is not NULL */
        if (IS_NULLFLD(domainArg, A_Domain_SavedDimEntityDictId) == FALSE)
		{
			/* SET_DICT(domainArg,           A_Domain_DimEntityDictId,  GET_DICT(domainArg, A_Domain_SavedDimEntityDictId)); */
			COPY_DYNFLD(domainArg, A_Domain, A_Domain_DimEntityDictId, domainArg, A_Domain, A_Domain_SavedDimEntityDictId); /* OCS37463-CHU-110413 */
			SET_NULL_DICT(domainArg, A_Domain_SavedDimEntityDictId);
		}

		if (IS_NULLFLD(domainArg, A_Domain_SavedDimPtfDictId) == FALSE)
		{
			/* SET_DICT(domainArg,           A_Domain_DimPtfDictId,  GET_DICT(domainArg, A_Domain_SavedDimPtfDictId)); */
			COPY_DYNFLD(domainArg, A_Domain, A_Domain_DimPtfDictId, domainArg, A_Domain, A_Domain_SavedDimPtfDictId); /* OCS37463-CHU-110413 */
			SET_NULL_DICT(domainArg, A_Domain_SavedDimPtfDictId);
		}

		if (IS_NULLFLD(domainArg, A_Domain_SavedPtfObjId) == FALSE)
		{
			/* SET_ID(domainArg,             A_Domain_PtfObjId,    GET_ID(domainArg, A_Domain_SavedPtfObjId)); */
			COPY_DYNFLD(domainArg, A_Domain, A_Domain_PtfObjId, domainArg, A_Domain, A_Domain_SavedPtfObjId); /* OCS37463-CHU-110413 */
			SET_NULL_ID(domainArg, A_Domain_SavedPtfObjId);
		}

		if (IS_NULLFLD(domainArg, A_Domain_SavedPtfListDef) == FALSE)
		{
			/* SET_TEXT(domainArg,    A_Domain_PtfListDef,  GET_TEXT(domainArg, A_Domain_SavedPtfListDef)); */
			/* COPY_DYNFLD(domainArg, A_Domain, A_Domain_PtfListDef, domainArg, A_Domain, A_Domain_SavedPtfListDef); */ /* OCS37463-CHU-110413 */ /* PMSTA-17973 - CHU - 140416 */
			SET_TEXT(domainArg,      A_Domain_PtfListDef,  GET_STRING(domainArg, A_Domain_SavedPtfListDef));	/* PMSTA-17973 - CHU - 140416 */
			SET_NULL_STRING(domainArg, A_Domain_SavedPtfListDef); /* PMSTA-17973 - CHU - 140416 */
		}
        else /* OCS-48062 - CHU - 160421... je sais, c'est sauvage...  */
        {
            if (GET_ENUM(domainArg, A_Domain_OutputTpEn) != TSLDimPort &&
                GET_DICT(domainArg, A_Domain_DimPtfDictId) == quickSearchEntityDictId)
            {
                SET_NULL_DICT(domainArg, A_Domain_DimPtfDictId);
            }
        }
	}
}

/************************************************************************
**
**  Function    :   DBA_NewFctResult()
**
**  Description :   Create a new function result.
**		    - Insert Domain
**		    - Allocate FctResult
**		    - Init with domain information
**		    - Save FctResult
**		    - Update FctResult identifier in domain
**
**  Arguments   :   DBA_DYNFLD_STP domainPtr	domain structure
**					DBA_DYNFLD_STP *fctResPtr	pointer on function result
**					int *connectNo
**					DBA_ERRMSG_INFOS_STP msgStructStp
**
**  Return      :   RET_SUCCEED or error code
**
**  Cr�ation    :   RAK - 970530 - DVP460
**  Modif.		:   ROI - 970602 - DVP471
**  		    :   ROI - 981021 - REF2644
**  		    :   RAK - 990311 - REF2644
**  		    :   RAK - 001107 - REF5222 - Now FctResult is a view of Domain, suppress update on it
**  		    :   ROI - 001115 - REF5222 - Now FctResult is a view of Domain, suppress update on it
**              :   MRA - 001120 - REF5222
**              :   REF7264 - 0201225 - PMO : Compilation errors and warnings with C++ compiler
**
*************************************************************************/
RET_CODE DBA_NewFctResult(DBA_DYNFLD_STP domainPtr, DBA_DYNFLD_STP *fctResPtr, int *connectNo)
{
	ID_T		fctResId, domId, userId;
	RET_CODE	ret = RET_SUCCEED;
	FLAG_T		existFlag, allocFlag, dispFlg, *scptFlagTab;
	int			dbaOptions;
    DICT_FCT_STP dictFctInfo; /* 31804 - CHU - 180621 */

	/* Test given arguments */
	if ((domainPtr == NULL) ||
		(fctResPtr == NULL)
	   ) MSG_RETURN(RET_GEN_ERR_INVARG);

	/* Init local variables */
	ret = RET_SUCCEED;
	existFlag = FALSE;
	allocFlag = FALSE;
	userId = 0;

	/* Setup dbaOptions if connectNo is given */
	if (connectNo != NULL)
	  dbaOptions = DBA_SET_CONN | DBA_NO_CLOSE;
	else
	  dbaOptions = UNUSED;

	/* Test if fctResPtr already exists */
	if ((*fctResPtr != NULL) &&
		(IS_NULLFLD((*fctResPtr), A_FctResult_Id) == FALSE) &&
		((fctResId = GET_ID((*fctResPtr), A_FctResult_Id)) > 0) &&
		(IS_NULLFLD(domainPtr, A_Domain_Id) == FALSE) &&
		((domId = GET_ID(domainPtr, A_Domain_Id)) > 0) &&
		(IS_NULLFLD((*fctResPtr), A_FctResult_DomainId) == FALSE) &&
		(domId == GET_ID((*fctResPtr), A_FctResult_DomainId)) &&
		(IS_NULLFLD(domainPtr, A_Domain_FctResultId) == FALSE) &&
		(fctResId == GET_ID(domainPtr, A_Domain_FctResultId))
	   ) existFlag = TRUE;

	/* Store an occurence in function_result table */
	if (*fctResPtr == NULL)
	{
		*fctResPtr = ALLOC_DYNST(A_FctResult);
		allocFlag = TRUE;
		DBA_SetDfltEntityFld(FctResult, A_FctResult, *fctResPtr);
	}

	if (*fctResPtr == NULL)
		return RET_GEN_ERR_INVARG;

	/* Construction d'un A_FctResult � partir du domaine courant */
	COPY_DYNFLD((*fctResPtr), A_FctResult, A_FctResult_Id,
				domainPtr,    A_Domain,    A_Domain_FctResultId);
	COPY_DYNFLD((*fctResPtr), A_FctResult, A_FctResult_Cd,
				domainPtr,    A_Domain,    A_Domain_FctResultCd);
	COPY_DYNFLD((*fctResPtr), A_FctResult, A_FctResult_FctDictId,
				domainPtr,    A_Domain,    A_Domain_FctDictId);
	COPY_DYNFLD((*fctResPtr), A_FctResult, A_FctResult_DomainId,
				domainPtr,    A_Domain,    A_Domain_Id);

	COPY_DYNFLD((*fctResPtr), A_FctResult, A_FctResult_UserId,
				domainPtr,    A_Domain,    A_Domain_UsrId);

/*	COPY_DYNFLD((*fctResPtr), A_FctResult, A_FctResult_ModifDate,
				domainPtr,    A_Domain,    ); */
	COPY_DYNFLD((*fctResPtr), A_FctResult, A_FctResult_CalcFromDate,
				domainPtr,    A_Domain,    A_Domain_InterpFromDate);
	COPY_DYNFLD((*fctResPtr), A_FctResult, A_FctResult_CalcTillDate,
				domainPtr,    A_Domain,    A_Domain_InterpTillDate);
	COPY_DYNFLD((*fctResPtr), A_FctResult, A_FctResult_CalcRefDate,
				domainPtr,    A_Domain,    A_Domain_CalcRefDate);
	COPY_DYNFLD((*fctResPtr), A_FctResult, A_FctResult_CalcStratDate,
				domainPtr,    A_Domain,    A_Domain_InterpStratDate);
	COPY_DYNFLD((*fctResPtr), A_FctResult, A_FctResult_CalcFreqDate,
				domainPtr,    A_Domain,    A_Domain_InterpFreqDate);
/*	COPY_DYNFLD((*fctResPtr), A_FctResult, A_FctResult_StatusEn,
				domainPtr,    A_Domain,    A_Domain_FctResultStatEn); */
	COPY_DYNFLD((*fctResPtr), A_FctResult, A_FctResult_DimPtfDictId,
				domainPtr,    A_Domain,    A_Domain_DimPtfDictId);
	COPY_DYNFLD((*fctResPtr), A_FctResult, A_FctResult_PtfObjId,
				domainPtr,    A_Domain,    A_Domain_PtfObjId);
	COPY_DYNFLD((*fctResPtr), A_FctResult, A_FctResult_DimInstrDictId,
				domainPtr,    A_Domain,    A_Domain_DimInstrDictId);
	COPY_DYNFLD((*fctResPtr), A_FctResult, A_FctResult_InstrObjId,
				domainPtr,    A_Domain,    A_Domain_InstrObjId);
	COPY_DYNFLD((*fctResPtr), A_FctResult, A_FctResult_DimStratDictId,
				domainPtr,    A_Domain,    A_Domain_DimStratDictId);
	COPY_DYNFLD((*fctResPtr), A_FctResult, A_FctResult_StratObjId,
				domainPtr,    A_Domain,    A_Domain_StratObjId);

	/* Appropriation du function result par le user courant */
	DBA_GetUserInfo2(A_ApplUser_Id, (PTR) &userId, TRUE); /* PMSTA09151-9264-CHU-100224 Use WUI user if exist */
	SET_ID((*fctResPtr), A_FctResult_UserId, userId);

	/* PMSTA06761 - RAK - 080818 - Use the user of the connection */
	if (IS_NULLFLD(domainPtr, A_Domain_UsrId) == TRUE)
	{
		SET_ID(domainPtr, A_Domain_UsrId, userId);
	}

	/* PMSTA06761 - RAK - 080818 - Store a Disp flag to TRUE */
	dispFlg = GET_FLAG(domainPtr, A_Domain_DispResultFlg);
	SET_FLAG(domainPtr, A_Domain_DispResultFlg, TRUE);

	/* D�finition du statut */
	/* REF2644 - RAK - 990311 */
	if (IS_NULLFLD((*fctResPtr), A_FctResult_StatusEn) == TRUE ||
        GET_ENUM((*fctResPtr), A_FctResult_StatusEn) == (ENUM_T)FctResultStatus_None)
    {
        if (((EVTGEN_ENUM)GET_ENUM(domainPtr, A_Domain_EvtGenNatEn) == EvtGen_CheckSplitAndPublish ||
            (EVTGEN_ENUM)GET_ENUM(domainPtr, A_Domain_EvtGenNatEn) == EvtGen_CheckCaseSplitAndPublish) && /* PMSTA-28596 - CHU - 170926 */
            IS_NULLFLD(domainPtr, A_Domain_FctResultStatEn) == FALSE &&
            GET_ENUM(domainPtr, A_Domain_FctResultStatEn) != FctResultStatus_None)
        {
            COPY_DYNFLD((*fctResPtr), A_FctResult, A_FctResult_StatusEn, domainPtr, A_Domain, A_Domain_FctResultStatEn);
        }
        else
        {
            SET_ENUM((*fctResPtr), A_FctResult_StatusEn, (ENUM_T)FctResultStatus_Draft);
        }
    }
	/*PMSTA-44456- VSW - 040721 - Code changes done to ensure that for the Events AUTOMATIC & AUTOMATIC_NO_SESSION.... */
	/* ......  the Function Result Status is assigned values of Final and NULL respectively */
	if ((EVTGEN_ENUM)GET_ENUM(domainPtr, A_Domain_EvtGenNatEn) == EvtGen_Automatic)
	{
		SET_ENUM((*fctResPtr), A_FctResult_StatusEn, (ENUM_T)FctResultStatus_InProgress);
	}
	else if ((EVTGEN_ENUM)GET_ENUM(domainPtr, A_Domain_EvtGenNatEn) == EvtGen_AutomaticNoSession)
	{
		SET_ENUM((*fctResPtr), A_FctResult_StatusEn, NULL);
	}


    COPY_DYNFLD(domainPtr,    A_Domain,    A_Domain_FctResultStatEn,
                (*fctResPtr), A_FctResult, A_FctResult_StatusEn);

	/* STORE THE FUNCTION_RESULT RECORD IN DOMAIN TABLE */
	if (existFlag == TRUE)
	{
		DBA_RestorePtfDim(domainPtr); /* PMSTA09899-CHU-100521 */
		ret = DBA_Update2(Domain,
						  UNUSED,
						  A_Domain,
						  domainPtr,
						  dbaOptions,
						  connectNo
					     );
		DBA_SetTascJobPtfDim(domainPtr, connectNo); /* PMSTA09899-CHU-100521 */  /* OCS-49362 - TEB - 170508 */
	}
	else
	{
        /* < PMSTA-31804 - CHU - 180621 : also use the domain record for DictFct_ManageSession */
        /* < PMSTA-30894 - CHU - 180711 : also use the domain record for DictFct_ManagePayout */
        DICT_T currFunctionDictId = DictFct_0;
        bool bIsRoboFullyAutoOffer = false;

        DBA_GetDictFctInfo(GET_DICT(domainPtr, A_Domain_FctDictId), DictFctInfo_Stp, &dictFctInfo);
        if(((DICT_FCT_ENUM)GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_ManageSession ||
           dictFctInfo->parFctDictId == DictFct_ManageSession) ||
           ((DICT_FCT_ENUM)GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_ManagePayout ||
           dictFctInfo->parFctDictId == DictFct_ManagePayout)) /* PMSTA-30894 - CHU - 180711 */
        {
            bIsRoboFullyAutoOffer = true; /* PMSTA-30894 - CHU - 180711 */
            currFunctionDictId = GET_DICT(domainPtr, A_Domain_FctDictId);
        }
        /* > PMSTA-31804 - CHU - 180621 */ /* > PMSTA-30894 - CHU - 180711 */

		/* OCS43091-CHU-130617 : PG - evaluate code on domain if trading a proposal */
		if (((DOMSESSIONNAT_ENUM)GET_ENUM(domainPtr, A_Domain_SessionNatureEn)  == DomSessionNat_Order &&
			 (PROPOSALNAT_ENUM)GET_ENUM(domainPtr, A_Domain_ProposalNatureEn) == ProposalNat_Trade)
			 || /* OCS-44627-CHU-140514 : PG - also evaluate code on domain if session nature is proposal */
			 ((DOMSESSIONNAT_ENUM)GET_ENUM(domainPtr, A_Domain_SessionNatureEn) == DomSessionNat_InvestmentProposal ||
			  (DOMSESSIONNAT_ENUM)GET_ENUM(domainPtr, A_Domain_SessionNatureEn) == DomSessionNat_InvestmentProposalClient) /* PMSTA-21262 - chandrak - 150923 */ /* PMSTA-31804 - CHU - 180621 : misplaced parenthesis... */
             ||
             (true == bIsRoboFullyAutoOffer)) /* PMSTA-31804 - CHU - 180621 */ /* PMSTA-30894 - CHU - 180711 */
		{
			/* Evaluation des valeurs par d�faut pour g�n�rer A_Domain_FctResultCd */
			if (IS_NULLFLD(domainPtr, A_Domain_FctResultCd) == TRUE)
			{
				scptFlagTab = (FLAG_T *) CALLOC(GET_FLD_NBR(A_Domain), sizeof(FLAG_T)); /* REF7264 - PMO */
				memset(scptFlagTab, 1, GET_FLD_NBR(A_Domain)*sizeof(FLAG_T));
				scptFlagTab[A_Domain_FctResultCd] = FALSE;

				/* Ex�cution des valeurs par d�fault */
                SCPT_ComputeScreenDV (  Domain,
                                        /* DictFct_0 */ currFunctionDictId,     /*  FIH-REF4258-000111  */ /* PMSTA-31804 - CHU - 180621 */
                                        scptFlagTab,
                                        NULL,              /* HFI-PMSTA-25327-171023  Dedicated flag tab for filter    */
                                        domainPtr,
                                        NULL,
                                        domainPtr,
                                        NULLDYNST,   /* PMSTA13283 - DDV - 120117 */
                                        TRUE,
                                        TRUE,
                                        EvalType_DefVal,       /*  FPL-REF9507-030930  Only Def val    */
                                        -1,
                                        connectNo,
                                        NULL,
                                        NULL,
                                        0,
                                        DictScreen,    /*  FIH-REF9789-040209  */
                                        NULL,
                                        NULL,
                                        NULL,
                                        NULL,
                                        NULL,
                                        NullEntity,
                                        FALSE,
                                        FALSE,
                                        0); /*  FPL-REF9215-030811  Flag Impact */
				FREE(scptFlagTab);

				if (IS_NULLFLD(domainPtr, A_Domain_FctResultCd) == FALSE)
					COPY_DYNFLD((*fctResPtr), A_FctResult, A_FctResult_Cd,
								domainPtr,    A_Domain,    A_Domain_FctResultCd);
			}
		}

        /* < PMSTA-25122 - CHU - 161019 : If no screen for WUI user on domain with above DV, func_result_code will stay NULL.
         *                                 Hence, execute DV on 'code' attribute of function_result entity.
		else
		{
        */
			/* Evaluation des valeurs par d�faut pour g�n�rer A_FctResult_Cd */
			if (IS_NULLFLD((*fctResPtr), A_FctResult_Cd) == TRUE)
			{
				scptFlagTab = (FLAG_T *) CALLOC(GET_FLD_NBR(A_FctResult), sizeof(FLAG_T)); /* REF7264 - PMO */
				memset(scptFlagTab, 1, GET_FLD_NBR(A_FctResult)*sizeof(FLAG_T));
				scptFlagTab[A_FctResult_Cd] = FALSE;

				/* Ex�cution des valeurs par d�fault */
				SCPT_ComputeScreenDV(FctResult,
									 /* DictFct_0 */ currFunctionDictId,     /*  FIH-REF4258-000111  */ /* PMSTA-31804 - CHU - 180621 */
									 scptFlagTab,
                                     NULL,              /* HFI-PMSTA-25327-171023  Dedicated flag tab for filter    */
									 (*fctResPtr),
									 NULL,
									 domainPtr,
									 NULLDYNST,   /* PMSTA13283 - DDV - 120117 */
									 TRUE,
									 TRUE,
									 EvalType_DefVal,       /*  FPL-REF9507-030930  Only Def val    */
									 -1,
									 connectNo,
									 NULL,
									 NULL,
									 0,
									 DictScreen,    /*  FIH-REF9789-040209  */
									 NULL,
									 NULL,
									 NULL,
									 NULL,
									 NULL,
									 NullEntity,
									 FALSE,
									 FALSE,
                                     0);        /*  FPL-REF9215-030811  Flag Impact */
				FREE(scptFlagTab);

				/* REF5222 - SSO - 001113:code readded.. */
				/* Setup A_Domain */
				if (IS_NULLFLD((*fctResPtr), A_FctResult_Cd) == FALSE)
					COPY_DYNFLD(domainPtr,    A_Domain,    A_Domain_FctResultCd,
								(*fctResPtr), A_FctResult, A_FctResult_Cd);
			}
        /*
		}
        */ /* > PMSTA-25122 - CHU - 161019 */

		/* RAK - 990324 - REF2644 */
		if (GET_ENUM(domainPtr, A_Domain_CompDataEn) == (ENUM_T) CompData_CompNew ||
		    GET_ENUM(domainPtr, A_Domain_CompDataEn) == (ENUM_T) CompData_OnLine)
			SET_ENUM(domainPtr, A_Domain_CompDataEn, CompData_ReplOld);

		DBA_RestorePtfDim(domainPtr); /* PMSTA09899-CHU-100521 */
		ret = DBA_Insert2(Domain,
						  UNUSED,
						  A_Domain,
						  domainPtr,
						  dbaOptions,
						  connectNo
					     );
		DBA_SetTascJobPtfDim(domainPtr, connectNo); /* PMSTA09899-CHU-100521 */ /* OCS-49362 - TEB - 170508 */

		if (ret != RET_SUCCEED)
		{
			if (allocFlag == TRUE)
				FREE_DYNST((*fctResPtr), A_FctResult);
			return ret;
		}

        SET_ID(domainPtr, A_Domain_FctResultId, GET_ID(domainPtr, A_Domain_Id));
	}

	/* A la fin, il faut remettre � jour le FctRes */
	/* ROI - 001115 - REF5222 */
	COPY_DYNFLD((*fctResPtr), A_FctResult, A_FctResult_Id,
				domainPtr,    A_Domain,    A_Domain_FctResultId);
	COPY_DYNFLD((*fctResPtr), A_FctResult, A_FctResult_DomainId,
				domainPtr,    A_Domain,    A_Domain_Id);
	COPY_DYNFLD((*fctResPtr), A_FctResult, A_FctResult_StatusEn,
				domainPtr,    A_Domain,    A_Domain_FctResultStatEn);

	/* PMSTA06761 - RAK - 080818 - Get saved Disp flag */
	SET_FLAG(domainPtr, A_Domain_DispResultFlg, dispFlg);

	return ret;
}

/************************************************************************
**
**  Function    :   DBA_CopyFtRate
**
**  Description :   Copy FTRate logical attributes with ud fields.
**
**  Arguments   :
**
**  Return      :   RET_CODE
**
**  Cr�ation    :   GRD - 980722 - REF1598.
**  Modif.	:
*************************************************************************/
RET_CODE DBA_CopyFtRate(OBJECT_ENUM		    ,
                        DBA_DYNFLD_STP		copyArg,
                        DbiConnectionHelper& dbiConnHelper)
{
	DBA_DYNFLD_STP	getIn = NULL,
			getOut = NULL,
			selIn = NULL,
			*selOut = NULL;
	RET_CODE	ret = RET_SUCCEED;
	int		selNbr = 0,
			i = 0;

	if ((getIn = ALLOC_DYNST(Adm_Arg)) == NULL)
	{
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "Adm_Arg");
		return(RET_MEM_ERR_ALLOC);
	}

	if ((getOut = ALLOC_DYNST(S_FTRateHist)) == NULL)
	{
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "S_FTRateHist");
		FREE_DYNST(getIn, Adm_Arg);
		return(RET_MEM_ERR_ALLOC);
	}

	SET_ID(getIn, Adm_Arg_Id, GET_ID(copyArg, A_CopyArg_FromId));

	if ((ret = dbiConnHelper.dbaGet(FTRateHist, UNUSED, getIn, &getOut)) != RET_SUCCEED)
	{
		FREE_DYNST(getIn, Adm_Arg);
		FREE_DYNST(getOut, S_FTRateHist);
		return(ret);
	}

	FREE_DYNST(getIn, Adm_Arg);

	if ((selIn = ALLOC_DYNST(S_FTRateHist)) == NULL)
	{
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "S_FTRateHist");
		FREE_DYNST(getOut, S_FTRateHist);
		return(RET_MEM_ERR_ALLOC);
	}

	SET_ID(selIn,       S_FTRateHist_FTConvId,  GET_ID(getOut,       S_FTRateHist_FTConvId));
	SET_DATETIME(selIn, S_FTRateHist_BeginDate, GET_DATETIME(getOut, S_FTRateHist_BeginDate));

	FREE_DYNST(getOut, S_FTRateHist);

	if ((ret = dbiConnHelper.dbaSelect(FTRate, UNUSED, selIn, A_FTRate, &selOut, &selNbr)) != RET_SUCCEED)
	{
		FREE_DYNST(selIn, S_FTRateHist);
		return(ret);
	}

	FREE_DYNST(selIn, S_FTRateHist);

	for (i = 0; i < selNbr; i++)
	{
		SET_ID(selOut[i], A_FTRate_FTRateHistId, GET_ID(copyArg, A_CopyArg_ToId));

		if ((ret = dbiConnHelper.dbaInsert(FTRate, UNUSED, selOut[i])) != RET_SUCCEED)
		{
			DBA_FreeDynStTab(selOut, selNbr, A_FTRate);
			return(ret);
		}
	}

	DBA_FreeDynStTab(selOut, selNbr, A_FTRate);

        return ret;
}

/************************************************************************
**
**  Function    :   DBA_ScreenSelectFillFoundTab
**
**  Description :   Fill foundTab for all screens in screen profile
**
**  Arguments   :   FLAG_T          *foundTab,
**                  DICT_T          functionDictId      : Current function
**                  DBA_DYNFLD_STP* dynTab              : Screen prof compo Table
**                  int             dynNb               : Size of Screen prof compo Table
**                  DBA_DYNFLD_STP  screenProfSelect    : Selected screen profile compo
**                  FLAG_T          flagCreateMode      : Given screen prof compo must also be test
**
**  Return      :   FLAG_T
**
**  Cr�ation   	:   MRA - 020730 - REF7733
**
*************************************************************************/
static  FLAG_T  DBA_ScreenSelectFillFoundTab (  FLAG_T          *foundTab,
                                                DICT_T          functionDictId,
                                                DBA_DYNFLD_STP  *dynTab,
                                                int             dynNb,
                                                DBA_DYNFLD_STP  screenProfSelect,
                                                FLAG_T          flagCreateMode)
{

    FLAG_T          found;
    ID_T            screenDictId;
    DBA_DYNFLD_STP  screenProf;
    int             j, s;


    screenDictId = GET_DICT(screenProfSelect,S_ScreenProfCompo_ScreenDictId);
    for (j = 0; j < dynNb; j++)
    {
        /* if same attribute foundTab[j] = true */
        screenProf = dynTab[j];
        if ((screenProf != screenProfSelect) &&
            (((functionDictId > 0) &&
              (IS_NULLFLD(screenProf, S_ScreenProfCompo_FctDictId) == FALSE) &&
              (functionDictId == GET_DICT(screenProf, S_ScreenProfCompo_FctDictId))) ||
             ((functionDictId <= 0) &&
              (IS_NULLFLD(screenProf, S_ScreenProfCompo_FctDictId) == TRUE))) &&
            (IS_NULLFLD(screenProf,S_ScreenProfCompo_ScreenDictId) == FALSE) &&
            (GET_ID(screenProf,S_ScreenProfCompo_ScreenDictId) == screenDictId) &&
            foundTab[j] == FALSE)
        {
            if (flagCreateMode == FALSE)
            {
                if ((DBA_CmpDynFld(screenProf, screenProfSelect, S_ScreenProfCompo_NatAttrDictId,
                                   S_ScreenProfCompo_NatAttrDictId, DictType, FALSE) == 0) &&
                    (DBA_CmpDynFld(screenProf, screenProfSelect, S_ScreenProfCompo_TpAttrDictId,
                                   S_ScreenProfCompo_TpAttrDictId, DictType, FALSE) == 0) &&
                    (DBA_CmpDynFld(screenProf, screenProfSelect, S_ScreenProfCompo_SubTpAttrDictId,
                                   S_ScreenProfCompo_SubTpAttrDictId, DictType, FALSE) == 0))
                    foundTab[j] = TRUE;
            }
            else
            {
                if (((DBA_CmpDynFld(screenProf, screenProfSelect, S_ScreenProfCompo_NatAttrDictId,
                                    S_ScreenProfCompo_NatAttrDictId, DictType, FALSE) == 0) &&
                     (IS_NULLFLD(screenProf, S_ScreenProfCompo_NatAttrDictId) == FALSE)) ||
                    ((DBA_CmpDynFld(screenProf, screenProfSelect, S_ScreenProfCompo_TpAttrDictId,
                                    S_ScreenProfCompo_TpAttrDictId, DictType, FALSE) == 0) &&
                     (IS_NULLFLD(screenProf, S_ScreenProfCompo_TpAttrDictId) == FALSE)) ||
                    ((DBA_CmpDynFld(screenProf, screenProfSelect, S_ScreenProfCompo_SubTpAttrDictId,
                                    S_ScreenProfCompo_SubTpAttrDictId, DictType, FALSE) == 0) &&
                     (IS_NULLFLD(screenProf, S_ScreenProfCompo_SubTpAttrDictId) == FALSE)))
                    foundTab[j] = TRUE;
            }
        }
    }
    found = TRUE;
    /* same function and same screen */
    for (s = 0; (s < dynNb) && (found == TRUE); s++)
    {
        screenProf = dynTab[s];
        if ((((functionDictId > 0) &&
              (IS_NULLFLD(screenProf, S_ScreenProfCompo_FctDictId) == FALSE) &&
              (functionDictId == GET_DICT(screenProf, S_ScreenProfCompo_FctDictId))) ||
             ((functionDictId <= 0) &&
              (IS_NULLFLD(screenProf, S_ScreenProfCompo_FctDictId) == TRUE))) &&
            (IS_NULLFLD(screenProf,S_ScreenProfCompo_ScreenDictId) == FALSE) &&
            (GET_ID(screenProf,S_ScreenProfCompo_ScreenDictId) == screenDictId))
        {
            found = foundTab[s];
        }
    }
    return found;
}



/************************************************************************
**
**  Function    :   DBA_ScreenSelectConfirmOne
**
**  Description :   Test if a selected screen is the right one (one record)
**
**  Arguments   :
**
**  Return      :
**
**  Cr�ation   	:   FPL-PMSTA09056-091126
**
*************************************************************************/
FLAG_T  DBA_ScreenSelectConfirmOne ( OBJECT_ENUM       entity
                                   , DICT_T            functionDictId
                                   , DBA_DYNFLD_STP    dynStp
                                   , DBA_DYNFLD_STP    screenProf
                                   , DBA_DYNFLD_STP    screenProfSelect
                                   , FLAG_T            flagCreateMode
                                   )
{

    ID_T            screenDictId;
    short           natureIdx,
                    typeIdx,
                    subTypeIdx;
    DICT_T          dictId;
    FLAG_T          found;

    found = FALSE ;
    screenDictId = GET_DICT(screenProfSelect,S_ScreenProfCompo_ScreenDictId);

    if (((screenProf != screenProfSelect) ||
         ((flagCreateMode == TRUE)/* &&*/               /*  FIH-REF7759-021209  */
          /*(dynStp != NULL)*/)) &&                     /*  FIH-REF7759-021209  */  /*  FPL-PMSTA09056-100112 not needed because tested down    */
        (((functionDictId > 0) &&
          (IS_NULLFLD(screenProf, S_ScreenProfCompo_FctDictId) == FALSE) &&
          (functionDictId == GET_DICT(screenProf, S_ScreenProfCompo_FctDictId))) ||
         ((functionDictId <= 0) &&
          (IS_NULLFLD(screenProf, S_ScreenProfCompo_FctDictId) == TRUE))) &&
        (IS_NULLFLD(screenProf,S_ScreenProfCompo_ScreenDictId) == FALSE) &&
        (GET_ID(screenProf,S_ScreenProfCompo_ScreenDictId) == screenDictId) &&
        (found == FALSE))
    {
        natureIdx = -1;
        if ((IS_NULLFLD(screenProf,S_ScreenProfCompo_NatAttrDictId) == FALSE) &&
            (IS_NULLFLD(screenProf, S_ScreenProfCompo_NatEn) == FALSE))
        {
            dictId = GET_DICT(screenProf, S_ScreenProfCompo_NatAttrDictId);
            DBA_GetDictAttribIdxByDictId(entity, dictId, &natureIdx);
        }

        typeIdx = -1;
        if ((IS_NULLFLD(screenProf,S_ScreenProfCompo_TpAttrDictId) == FALSE) &&
            (IS_NULLFLD(screenProf, S_ScreenProfCompo_TpId) == FALSE))
        {
            dictId = GET_DICT(screenProf, S_ScreenProfCompo_TpAttrDictId);
            DBA_GetDictAttribIdxByDictId(entity, dictId, &typeIdx);
        }

        subTypeIdx = -1;
        if ((IS_NULLFLD(screenProf,S_ScreenProfCompo_SubTpAttrDictId) == FALSE) &&
            (IS_NULLFLD(screenProf, S_ScreenProfCompo_SubTpId) == FALSE))
        {
            dictId = GET_DICT(screenProf, S_ScreenProfCompo_SubTpAttrDictId);
            DBA_GetDictAttribIdxByDictId(entity, dictId, &subTypeIdx);
        }

        if (((natureIdx == -1) ||
             (DBA_CmpDynFld(screenProf,dynStp,S_ScreenProfCompo_NatEn,natureIdx,EnumType,FALSE) == 0) ||
             ((flagCreateMode == TRUE) &&           /*  FIH-REF7759-021209  */
              (dynStp != NULL) &&
              (IS_NULLFLD(dynStp,natureIdx) == TRUE))) &&
            ((typeIdx == -1) ||
             (DBA_CmpDynFld(screenProf,dynStp,S_ScreenProfCompo_TpId,typeIdx,IdType,FALSE) == 0) ||
             ((flagCreateMode == TRUE) &&           /*  FIH-REF7759-021209  */
              (dynStp != NULL) &&
              (IS_NULLFLD(dynStp,typeIdx) == TRUE))) &&
            ((subTypeIdx == -1) ||
             (DBA_CmpDynFld(screenProf,dynStp,S_ScreenProfCompo_SubTpId,subTypeIdx,IdType,FALSE) == 0) ||
             ((flagCreateMode == TRUE) &&           /*  FIH-REF7759-021209  */
              (dynStp != NULL) &&
              (IS_NULLFLD(dynStp,subTypeIdx) == TRUE))))
        {
            /* MRA - 020730 - REF7733 */
            found = TRUE;
        }
    }

    return found ;
}


/************************************************************************
**
**  Function    :   DBA_ScreenSelectConfirm
**
**  Description :   Test if a selected screen is the right one
**
**  Arguments   :   OBJECT_ENUM     entity              : Entity dict_id
**                  DICT_T          functionDictId      : Current function
**                  DBA_DYNFLD_STP  dynStp              : Current data
**                  DBA_DYNFLD_STP* dynTab              : Screen prof compo Table
**                  int             dynNb               : Size of Screen prof compo Table
**                  DBA_DYNFLD_STP  screenProfSelect    : Selected screen profile compo
**                  FLAG_T          flagCreateMode      : Given screen prof compo must also be test
**
**  Return      :   RET_CODE
**
**  Cr�ation   	:   FIH - 990730 - REF3864
**
*************************************************************************/
FLAG_T  DBA_ScreenSelectConfirm (OBJECT_ENUM    entity,
                                 DICT_T         functionDictId,
                                 DBA_DYNFLD_STP dynStp,
                                 DBA_DYNFLD_STP *dynTab,
                                 int            dynNb,
                                 DBA_DYNFLD_STP screenProfSelect,
                                 FLAG_T         flagCreateMode)
{
    FLAG_T          found, *foundTab;
#ifdef PMSTA09056   /*  FPL-PMSTA09056-091126   */
    ID_T            screenDictId;
#endif
    DBA_DYNFLD_STP  screenProf;
    int             i;


    /*  FIH-REF7759-021209  */
    if (dynStp == NULL)
        return TRUE;

    /* MRA - 020730 - REF7733 */
    foundTab = (FLAG_T*)CALLOC(dynNb, sizeof(FLAG_T));
    /*  FIH-REF7759-021209  */
    if (flagCreateMode == FALSE)
    {
        for (i = 0; (i < dynNb) && (dynTab[i] != screenProfSelect); i++);
        if (i < dynNb)
            foundTab[i] = TRUE;
        found = DBA_ScreenSelectFillFoundTab(foundTab,functionDictId, dynTab, dynNb, screenProfSelect, flagCreateMode);
    }
    else
        found = FALSE;

#ifdef PMSTA09056   /*  FPL-PMSTA09056-091126   */
    screenDictId = GET_DICT(screenProfSelect,S_ScreenProfCompo_ScreenDictId);
#endif

    for (i = 0; (i < dynNb) && (found == FALSE); i++)
    {
        screenProf = dynTab[i];
#ifdef PMSTA09056   /*  FPL-PMSTA09056-091126   */
        if (((screenProf != screenProfSelect) ||
             ((flagCreateMode == TRUE) &&               /*  FIH-REF7759-021209  */
              (dynStp != NULL))) &&                     /*  FIH-REF7759-021209  */
            (((functionDictId > 0) &&
              (IS_NULLFLD(screenProf, S_ScreenProfCompo_FctDictId) == FALSE) &&
              (functionDictId == GET_DICT(screenProf, S_ScreenProfCompo_FctDictId))) ||
             ((functionDictId <= 0) &&
              (IS_NULLFLD(screenProf, S_ScreenProfCompo_FctDictId) == TRUE))) &&
            (IS_NULLFLD(screenProf,S_ScreenProfCompo_ScreenDictId) == FALSE) &&
            (GET_ID(screenProf,S_ScreenProfCompo_ScreenDictId) == screenDictId) &&
            (foundTab[i] == FALSE))
        {
            natureIdx = -1;
            if ((IS_NULLFLD(screenProf,S_ScreenProfCompo_NatAttrDictId) == FALSE) &&
                (IS_NULLFLD(screenProf, S_ScreenProfCompo_NatEn) == FALSE))
            {
                dictId = GET_DICT(screenProf, S_ScreenProfCompo_NatAttrDictId);
                DBA_GetDictAttribIdxByDictId(entity, dictId, &natureIdx);
            }

            typeIdx = -1;
            if ((IS_NULLFLD(screenProf,S_ScreenProfCompo_TpAttrDictId) == FALSE) &&
                (IS_NULLFLD(screenProf, S_ScreenProfCompo_TpId) == FALSE))
            {
                dictId = GET_DICT(screenProf, S_ScreenProfCompo_TpAttrDictId);
                DBA_GetDictAttribIdxByDictId(entity, dictId, &typeIdx);
            }

            subTypeIdx = -1;
            if ((IS_NULLFLD(screenProf,S_ScreenProfCompo_SubTpAttrDictId) == FALSE) &&
                (IS_NULLFLD(screenProf, S_ScreenProfCompo_SubTpId) == FALSE))
            {
                dictId = GET_DICT(screenProf, S_ScreenProfCompo_SubTpAttrDictId);
                DBA_GetDictAttribIdxByDictId(entity, dictId, &subTypeIdx);
            }

            if (((natureIdx == -1) ||
                 (DBA_CmpDynFld(screenProf,dynStp,S_ScreenProfCompo_NatEn,natureIdx,EnumType,FALSE) == 0) ||
                 ((flagCreateMode == TRUE) &&           /*  FIH-REF7759-021209  */
                  (dynStp != NULL) &&
                  (IS_NULLFLD(dynStp,natureIdx) == TRUE))) &&
                ((typeIdx == -1) ||
                 (DBA_CmpDynFld(screenProf,dynStp,S_ScreenProfCompo_TpId,typeIdx,IdType,FALSE) == 0) ||
                 ((flagCreateMode == TRUE) &&           /*  FIH-REF7759-021209  */
                  (dynStp != NULL) &&
                  (IS_NULLFLD(dynStp,typeIdx) == TRUE))) &&
                ((subTypeIdx == -1) ||
                 (DBA_CmpDynFld(screenProf,dynStp,S_ScreenProfCompo_SubTpId,subTypeIdx,IdType,FALSE) == 0) ||
                 ((flagCreateMode == TRUE) &&           /*  FIH-REF7759-021209  */
                  (dynStp != NULL) &&
                  (IS_NULLFLD(dynStp,subTypeIdx) == TRUE))))
#endif
        if (DBA_ScreenSelectConfirmOne (entity, functionDictId, dynStp, screenProf, screenProfSelect, flagCreateMode))  /*  FPL-PMSTA09056-091126   */
        {
            /* MRA - 020730 - REF7733 */
            foundTab[i] = TRUE;
            found = DBA_ScreenSelectFillFoundTab(foundTab,functionDictId, dynTab, dynNb, screenProf, flagCreateMode);
        }

    }
    FREE(foundTab);

    return found;
}


/*******************************************************************************
**
**  Function    :   DBA_MsgSendScreenMesg
**
**  Description :
**
**  Arguments   :   DBA_DYNFLD_STP  S_DictScreen
**
**  Return      :
**
**  Creation    :
**  Modif       :   HFI-PMSTA-14495-120619     : Manage flagtab
**  Modif       :   HFI-PMSTA-14495-120620     : Input change: dictFct instaed of fctProcName
**              :   PMSTA-25194 - 041116 - PMO : Stack overflow when DISPLAY > 29
**              :   HFI-PMSTA-35782-190507     : Rewrite based on new logger infrastrucuture
**
*******************************************************************************/
static int DBA_MsgSendScreenMesg (  DICT_T          dictScreenProf,
                                    DICT_T          dictFct,
                                    OBJECT_ENUM     entity,
                                    DBA_DYNFLD_STP  record,
                                    DBA_DYNFLD_STP  dbaDictScreenStp,
                                    DBA_DYNFLD_STP  *screenProfTab,
                                    int             screenProfNb)
{
    OBJECT_ENUM         objEn ;
    DICT_T              dictId ;
    short               natureIdx ;
    short               typeIdx ;
    short               subtypeIdx ;
    int                 iCpt ;
    DBA_DYNFLD_STP      dbadynShortScreenProf,
                        dbadynAllScreenProf,
                        sTp ,
                        aTp ;
    FLAG_T              *flagtab;               /*  HFI-PMSTA-14495-120619  */
    char                *pszFuncSqlName = NULL; /*  HFI-PMSTA-14495-120619  */
    const char          *pszAttr = NULL,        /*  HFI-PMSTA-14495-120619  */
                        *pszEnum = NULL,        /*  HFI-PMSTA-14495-120619  */
                        *pszEntity = NULL;

    /*
     * Initialization
     */
    std::stringstream logMessageStream;
    AAALogger screenLogger= AAALogger::get(AAALogger::Logger::ScriptTrace);
    if (!screenLogger.isDebugEnabled())
    {
        return TRUE;
    }

    logMessageStream << '\n';

    if (dictScreenProf > 0)
    {
        if ((dbadynShortScreenProf = ALLOC_DYNST(S_ScreenProf)) == NULL)
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        if ((dbadynAllScreenProf = ALLOC_DYNST(A_ScreenProf)) == NULL)
        {
            FREE_DYNST(dbadynShortScreenProf, S_ScreenProf);
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }
        SET_DICT(dbadynShortScreenProf, S_ScreenProf_Id, dictScreenProf);
        if ((DBA_Get2 ( ScreenProf
                        , UNUSED
                        , S_ScreenProf
                        , dbadynShortScreenProf
                        , A_ScreenProf
                        , &dbadynAllScreenProf
                        , UNUSED
                        , nullptr
                        , nullptr) == RET_SUCCEED) &&
            (IS_NULLFLD(dbadynAllScreenProf, A_ScreenProf_Cd) == FALSE))
        {
            logMessageStream << "SCREEN PROF : "<< GET_CODE(dbadynAllScreenProf, S_ScreenProf_Cd) << '\n';
        }
        else
        {
            logMessageStream << "SCREEN PROF : No Screen Profile" << '\n';
        }

        FREE_DYNST(dbadynShortScreenProf, S_ScreenProf);
        FREE_DYNST(dbadynAllScreenProf, A_ScreenProf);

    }
    else
    {
        logMessageStream << "SCREEN PROF : No Screen Profile" << '\n';
    }

    /*  Move this initialisation from DBA_Select    */                      /*  HFI-PMSTA-14495-120619  */
    DBA_GetDictFctInfo(dictFct, DictFctInfo_ProcName, &pszFuncSqlName);
    const char * pszEntitySqlName = DBA_GetDictEntitySqlName(entity);       /*  HFI-PMSTA-14495-120619  */

    if ((dbaDictScreenStp == NULL) ||
        (record == NULL) ||
        (screenProfTab == NULL))
    {
        logMessageStream << "IN_FUNCTION : "<< (pszFuncSqlName != nullptr ? pszFuncSqlName : "-") << '\n';
        logMessageStream << "IN_ENTITY   : "<< (pszEntitySqlName != nullptr ? pszEntitySqlName : "-") << '\n';
        logMessageStream << "NO_SCREEN   : "<< (screenProfTab == nullptr ? "No Screen Profile or No screen linked to the entity" : "No matching screen") << '\n';
    }
    else
    {
        /*  afficher le record in   */
        logMessageStream << "------------- Choosen screen compo ---------------\n";

        if (IS_NULLFLD(dbaDictScreenStp, S_ScreenProfCompo_ScreenName) == FALSE)
        {
            logMessageStream << "SCREEN_NAME : "<< GET_NAME(dbaDictScreenStp, S_ScreenProfCompo_ScreenName) << '\n';
        }
        else
        {
            logMessageStream << "SCREEN_NAME : "<< '-' << '\n';
        }

        if ((DBA_GetObjectEnum(GET_DICT(dbaDictScreenStp, S_ScreenProfCompo_EntDictId), &objEn) == TRUE) &&
            ((pszEntity = DBA_GetDictEntitySqlName(objEn)) != NULL))
        {
            logMessageStream << "ENTITY      : "<< pszEntity << '\n';
        }

        if (IS_NULLFLD(dbaDictScreenStp, S_ScreenProfCompo_FctName) == FALSE)
        {
            logMessageStream << "FUNCTION    : "<< GET_VNAME_ASCII(dbaDictScreenStp, S_ScreenProfCompo_FctName) << '\n';
        }
        else
        {
            logMessageStream << "FUNCTION    : "<< '-' << '\n';
        }

        if (IS_NULLFLD(dbaDictScreenStp, S_ScreenProfCompo_NatAttrDictId) == FALSE)
        {
            dictId = GET_DICT(dbaDictScreenStp, S_ScreenProfCompo_NatAttrDictId);
            DBA_GetDictAttribIdxByDictId(entity, dictId, &natureIdx);
            logMessageStream << "NAT_ATTR    : " << DBA_GetDictAttribSqlName(entity, natureIdx) << '\n';
            logMessageStream << "NAT         : " << (static_cast <int> GET_ENUM(dbaDictScreenStp, S_ScreenProfCompo_NatEn)) << ' ' << DBA_GetPermValPtr(entity,natureIdx,GET_ENUM(record, natureIdx)) << '\n';
        }
        else
        {
            logMessageStream << "NAT_ATTR    : "<< '-' << '\n';
            logMessageStream << "NAT         : "<< '0' << '\n';
        }

        if (IS_NULLFLD(dbaDictScreenStp, S_ScreenProfCompo_TpAttrDictId) == FALSE)
        {
            dictId = GET_DICT(dbaDictScreenStp, S_ScreenProfCompo_TpAttrDictId);
            DBA_GetDictAttribIdxByDictId(entity, dictId, &typeIdx);
            logMessageStream << "TYPE_ATTR   : "<< DBA_GetDictAttribSqlName(entity, typeIdx) << '\n';
        }
        else
        {
            logMessageStream << "TYPE_ATTR   : "<< '-' << '\n';
        }

        if (IS_NULLFLD(dbaDictScreenStp,S_ScreenProfCompo_TpCd) == FALSE)
        {
            logMessageStream << "TYPE        : "<< GET_CODE(dbaDictScreenStp,     S_ScreenProfCompo_TpCd) << '\n';
        }
        else
        {
            logMessageStream << "TYPE        : "<< '-' << '\n';
        }

        if (IS_NULLFLD(dbaDictScreenStp, S_ScreenProfCompo_SubTpAttrName) == FALSE)
        {
            logMessageStream << "SUBTYPE_ATTR: "<< GET_NAME(dbaDictScreenStp,     S_ScreenProfCompo_SubTpAttrName) << '\n';
        }
        else
        {
            logMessageStream << "SUBTYPE_ATTR: "<< '-' << '\n';
        }

        if (IS_NULLFLD(dbaDictScreenStp, S_ScreenProfCompo_SubTpCd) == FALSE)
        {
            logMessageStream << "SUBTYPE     : "<< GET_CODE(dbaDictScreenStp,     S_ScreenProfCompo_SubTpCd) << '\n';
        }
        else
        {
            logMessageStream << "SUBTYPE     : "<< '-' << '\n';
        }

        if (IS_NULLFLD(dbaDictScreenStp, S_ScreenProfCompo_ReportCd) == FALSE)
        {
            logMessageStream << "REPORT      : "<< GET_CODE(dbaDictScreenStp,     S_ScreenProfCompo_ReportCd) << '\n';
        }
        else
        {
            logMessageStream << "REPORT      : "<< '-' << '\n';
        }

        if (IS_NULLFLD(dbaDictScreenStp, S_ScreenProfCompo_Rank) == FALSE)
        {
            logMessageStream << "RANK        : "<< GET_SMALLINT(dbaDictScreenStp, S_ScreenProfCompo_Rank) << '\n';
        }
        else
        {
            logMessageStream << "RANK        : "<< '-' << '\n';
        }

        logMessageStream << "------------- Considered attribute --------------- \n";
        logMessageStream << "IN_FUNCTION : "<< (pszFuncSqlName != nullptr ? pszFuncSqlName : "-") << '\n';
        logMessageStream << "IN_ENTITY   : "<< (pszEntitySqlName != nullptr ? pszEntitySqlName : "-") << '\n';

        if ((sTp = ALLOC_DYNST(S_Tp)) == NULL)
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        if ((aTp = ALLOC_DYNST(A_Tp)) == NULL)
        {
            FREE_DYNST(sTp, S_Tp);
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        /*  Display IN_ATTR info only once      */  /*  HFI-PMSTA-14495-120619  */
        if ((flagtab = (FLAG_T*) CALLOC(GET_FLD_NBR(GET_EDITGUIST(entity)),sizeof(FLAG_T))) == NULL)
        {
            FREE_DYNST(sTp, S_Tp);
            FREE_DYNST(aTp, A_Tp);
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }
        for (iCpt = 0 ; iCpt < screenProfNb ; iCpt++)
        {
            natureIdx = 0 ;
            if (IS_NULLFLD(screenProfTab[iCpt], S_ScreenProfCompo_NatAttrDictId) == FALSE)
            {
                dictId = GET_DICT(screenProfTab[iCpt], S_ScreenProfCompo_NatAttrDictId);
                if ((DBA_GetDictAttribIdxByDictId(entity, dictId, &natureIdx) == RET_SUCCEED) &&
                    (flagtab[natureIdx] == FALSE))
                {
                    flagtab[natureIdx] = TRUE;
                    if (((pszAttr = DBA_GetDictAttribSqlName(entity, natureIdx)) != NULL) &&
                        ((pszEnum = DBA_GetPermValPtr(entity,natureIdx,GET_ENUM(record, natureIdx))) != NULL))
                    {
                        logMessageStream << "IN_ATTR     : "<< pszAttr << ' ' << (static_cast <int> GET_ENUM(record, natureIdx)) << ' ' << pszEnum << '\n';
                    }
                }
            }

            typeIdx = 0 ;
            if (IS_NULLFLD(screenProfTab[iCpt], S_ScreenProfCompo_TpAttrDictId) == FALSE)
            {
                dictId = GET_DICT(screenProfTab[iCpt], S_ScreenProfCompo_TpAttrDictId);
                if ((DBA_GetDictAttribIdxByDictId(entity, dictId, &typeIdx) == RET_SUCCEED)&&
                    (flagtab[typeIdx] == FALSE))
                {
                    flagtab[typeIdx] = TRUE;
                    if ((pszAttr = DBA_GetDictAttribSqlName(entity, typeIdx)) != NULL)
                    {
                        logMessageStream << "IN_ATTR     : "<< pszAttr << '\t';
                        if (IS_NULLFLD(record, typeIdx) == FALSE)
                        {
                            SET_ID(sTp, S_Tp_Id, GET_ID(record, typeIdx));
                            if ((DBA_Get2 ( Tp
                                          , UNUSED
                                          , S_Tp
                                          , sTp
                                          , A_Tp
                                          , &aTp
                                          , UNUSED
                                          , nullptr
                                          , nullptr) == RET_SUCCEED) &&
                                (IS_NULLFLD(aTp, A_Tp_Cd) == FALSE))
                            {
                                logMessageStream << GET_CODE(aTp, A_Tp_Cd) << '\n';
                            }
                            else
                            {
                                logMessageStream << "(error)\n";
                            }
                        }
                        else
                        {
                            logMessageStream << '\n';
                        }
                    }
                }
            }

            subtypeIdx = 0 ;
            if (IS_NULLFLD(screenProfTab[iCpt], S_ScreenProfCompo_SubTpAttrDictId) == FALSE)
            {
                dictId = GET_DICT(screenProfTab[iCpt], S_ScreenProfCompo_SubTpAttrDictId);
                if ((DBA_GetDictAttribIdxByDictId(entity, dictId, &subtypeIdx) == RET_SUCCEED) &&
                    (flagtab[subtypeIdx] == FALSE))
                {
                    flagtab[subtypeIdx] = TRUE;
                    if ((pszAttr = DBA_GetDictAttribSqlName(entity, subtypeIdx)) != NULL)
                    {
                        logMessageStream << "IN_ATTR     : "<< pszAttr << '\t';
                        if (IS_NULLFLD(record, subtypeIdx) == FALSE)
                        {
                            SET_ID(sTp, S_Tp_Id, GET_ID(record, subtypeIdx));
                            if ((DBA_Get2 ( Tp
                                          , UNUSED
                                          , S_Tp
                                          , sTp
                                          , A_Tp
                                          , &aTp
                                          , UNUSED
                                          , nullptr
                                          , nullptr) == RET_SUCCEED) &&
                                (IS_NULLFLD(aTp, A_Tp_Cd) == FALSE))
                            {
                                logMessageStream << GET_CODE(aTp, A_Tp_Cd) << '\n';
                            }
                            else
                            {
                                logMessageStream << "(error)\n";
                            }
                        }
                        else
                        {
                            logMessageStream << '\n';
                        }
                    }
                }
            }
        }

        FREE_DYNST(sTp, S_Tp);
        FREE_DYNST(aTp, A_Tp);
        FREE(flagtab);
    }

   /* Write end of message string */
    logMessageStream << "--------------------------------------------------";

    screenLogger.debug(logMessageStream.str());

    return(TRUE);
}


/************************************************************************
**
**  Function    :   DBA_ScreenSelectWithFunction
**
**  Description :   Find screen corresponding to an entity and an occurence
**
**  Arguments   :   OBJECT_ENUM     entity
**                  DBA_DYNFLD_STP  dynStp
**
**  Return      :   RET_CODE
**
**  Cr�ation   	:   FIH - 000111 - REF4258
**
*************************************************************************/
RET_CODE    DBA_ScreenSelectWithFunction (DICT_T         functionDictId,
                                          OBJECT_ENUM    entity,
                                          DICT_T         entityDictId,
                                          DBA_DYNFLD_STP dynStp,
                                          DBA_DYNFLD_STP *shScreenProfStp,
                                          DBA_DYNFLD_STP *dynTab,
                                          int            dynNb)
{
    DBA_DYNFLD_STP      screenProf;
    DICT_T              dictId;
    FLAG_T              found;
    short               natureIdx,
                        typeIdx,
                        subTypeIdx,
                        i;

    /* First test           */
    if (shScreenProfStp == NULL)
        return RET_GEN_ERR_INVARG;

    /* Init local variables */
    screenProf = NULL;
    found = FALSE;

    /*  Check first screen which match nature, type and subtype */
    for (i = 0; (i < dynNb) && (found == FALSE); i++)
    {
        screenProf = dynTab[i];
        if ((((functionDictId > 0) &&
              (IS_NULLFLD(screenProf, S_ScreenProfCompo_FctDictId) == FALSE) &&
              (functionDictId == GET_DICT(screenProf, S_ScreenProfCompo_FctDictId))) ||
             ((functionDictId <= 0) &&
              (IS_NULLFLD(screenProf, S_ScreenProfCompo_FctDictId) == TRUE))) &&
            (IS_NULLFLD(screenProf, S_ScreenProfCompo_EntDictId) == FALSE) &&
            (entityDictId == GET_DICT(screenProf, S_ScreenProfCompo_EntDictId)) &&
            (IS_NULLFLD(screenProf,S_ScreenProfCompo_NatAttrDictId) == FALSE) &&
            (IS_NULLFLD(screenProf,S_ScreenProfCompo_TpAttrDictId) == FALSE) &&
            (IS_NULLFLD(screenProf,S_ScreenProfCompo_SubTpAttrDictId) == FALSE))
        {
            dictId = GET_DICT(screenProf, S_ScreenProfCompo_NatAttrDictId);
            DBA_GetDictAttribIdxByDictId(entity, dictId, &natureIdx);
            dictId = GET_DICT(screenProf, S_ScreenProfCompo_TpAttrDictId);
            DBA_GetDictAttribIdxByDictId(entity, dictId, &typeIdx);
            dictId = GET_DICT(screenProf, S_ScreenProfCompo_SubTpAttrDictId);
            DBA_GetDictAttribIdxByDictId(entity, dictId, &subTypeIdx);
            if ((DBA_CmpDynFld(screenProf,dynStp,S_ScreenProfCompo_NatEn,natureIdx,EnumType,FALSE) == 0) &&
                (DBA_CmpDynFld(screenProf,dynStp,S_ScreenProfCompo_TpId,typeIdx,IdType,FALSE) == 0) &&
                (DBA_CmpDynFld(screenProf,dynStp,S_ScreenProfCompo_SubTpId,subTypeIdx,IdType,FALSE) == 0))
                found = DBA_ScreenSelectConfirm(entity,functionDictId,dynStp,dynTab,dynNb,screenProf,FALSE);
        }
    }

    /*  Check first screen which match nature, type     */
    for (i = 0; (i < dynNb) && (found == FALSE); i++)
    {
        screenProf = dynTab[i];
        if ((((functionDictId > 0) &&
              (IS_NULLFLD(screenProf, S_ScreenProfCompo_FctDictId) == FALSE) &&
              (functionDictId == GET_DICT(screenProf, S_ScreenProfCompo_FctDictId))) ||
             ((functionDictId <= 0) &&
              (IS_NULLFLD(screenProf, S_ScreenProfCompo_FctDictId) == TRUE))) &&
            (IS_NULLFLD(screenProf, S_ScreenProfCompo_EntDictId) == FALSE) &&
            (entityDictId == GET_DICT(screenProf, S_ScreenProfCompo_EntDictId)) &&
            (IS_NULLFLD(screenProf,S_ScreenProfCompo_NatAttrDictId) == FALSE) &&
            (IS_NULLFLD(screenProf,S_ScreenProfCompo_TpAttrDictId) == FALSE) &&
            (IS_NULLFLD(screenProf,S_ScreenProfCompo_SubTpAttrDictId) == TRUE))
        {
            dictId = GET_DICT(screenProf, S_ScreenProfCompo_NatAttrDictId);
            DBA_GetDictAttribIdxByDictId(entity, dictId, &natureIdx);
            dictId = GET_DICT(screenProf, S_ScreenProfCompo_TpAttrDictId);
            DBA_GetDictAttribIdxByDictId(entity, dictId, &typeIdx);
            if ((DBA_CmpDynFld(screenProf,dynStp,S_ScreenProfCompo_NatEn,natureIdx,EnumType,FALSE) == 0) &&
                (DBA_CmpDynFld(screenProf,dynStp,S_ScreenProfCompo_TpId,typeIdx,IdType,FALSE) == 0))
                found = DBA_ScreenSelectConfirm(entity,functionDictId,dynStp,dynTab,dynNb,screenProf,FALSE);
        }
    }

    /*  Check first screen which match nature           */
    for (i = 0; (i < dynNb) && (found == FALSE); i++)
    {
        screenProf = dynTab[i];
        if ((((functionDictId > 0) &&
              (IS_NULLFLD(screenProf, S_ScreenProfCompo_FctDictId) == FALSE) &&
              (functionDictId == GET_DICT(screenProf, S_ScreenProfCompo_FctDictId))) ||
             ((functionDictId <= 0) &&
              (IS_NULLFLD(screenProf, S_ScreenProfCompo_FctDictId) == TRUE))) &&
            (IS_NULLFLD(screenProf, S_ScreenProfCompo_EntDictId) == FALSE) &&
            (entityDictId == GET_DICT(screenProf, S_ScreenProfCompo_EntDictId)) &&
            (IS_NULLFLD(screenProf,S_ScreenProfCompo_NatAttrDictId) == FALSE) &&
            (IS_NULLFLD(screenProf,S_ScreenProfCompo_TpAttrDictId) == TRUE) &&
            (IS_NULLFLD(screenProf,S_ScreenProfCompo_SubTpAttrDictId) == TRUE))
        {
            dictId = GET_DICT(screenProf, S_ScreenProfCompo_NatAttrDictId);
            DBA_GetDictAttribIdxByDictId(entity, dictId, &natureIdx);
            if (DBA_CmpDynFld(screenProf,dynStp,S_ScreenProfCompo_NatEn,natureIdx,EnumType,FALSE) == 0)
                found = DBA_ScreenSelectConfirm(entity,functionDictId,dynStp,dynTab,dynNb,screenProf,FALSE);
        }
    }

    /*  Check first screen which match type and subtype */
    for (i = 0; (i < dynNb) && (found == FALSE); i++)
    {
        screenProf = dynTab[i];
        if ((((functionDictId > 0) &&
              (IS_NULLFLD(screenProf, S_ScreenProfCompo_FctDictId) == FALSE) &&
              (functionDictId == GET_DICT(screenProf, S_ScreenProfCompo_FctDictId))) ||
             ((functionDictId <= 0) &&
              (IS_NULLFLD(screenProf, S_ScreenProfCompo_FctDictId) == TRUE))) &&
            (IS_NULLFLD(screenProf, S_ScreenProfCompo_EntDictId) == FALSE) &&
            (entityDictId == GET_DICT(screenProf, S_ScreenProfCompo_EntDictId)) &&
            (IS_NULLFLD(screenProf,S_ScreenProfCompo_NatAttrDictId) == TRUE) &&
            (IS_NULLFLD(screenProf,S_ScreenProfCompo_TpAttrDictId) == FALSE) &&
            (IS_NULLFLD(screenProf,S_ScreenProfCompo_SubTpAttrDictId) == FALSE))
        {
            dictId = GET_DICT(screenProf, S_ScreenProfCompo_TpAttrDictId);
            DBA_GetDictAttribIdxByDictId(entity, dictId, &typeIdx);
            dictId = GET_DICT(screenProf, S_ScreenProfCompo_SubTpAttrDictId);
            DBA_GetDictAttribIdxByDictId(entity, dictId, &subTypeIdx);
            if ((DBA_CmpDynFld(screenProf,dynStp,S_ScreenProfCompo_TpId,typeIdx,IdType,FALSE) == 0) &&
                (DBA_CmpDynFld(screenProf,dynStp,S_ScreenProfCompo_SubTpId,subTypeIdx,IdType,FALSE) == 0))
                found = DBA_ScreenSelectConfirm(entity,functionDictId,dynStp,dynTab,dynNb,screenProf,FALSE);
        }
    }

    /*  Check first screen which match type             */
    for (i = 0; (i < dynNb) && (found == FALSE); i++)
    {
        screenProf = dynTab[i];
        if ((((functionDictId > 0) &&
              (IS_NULLFLD(screenProf, S_ScreenProfCompo_FctDictId) == FALSE) &&
              (functionDictId == GET_DICT(screenProf, S_ScreenProfCompo_FctDictId))) ||
             ((functionDictId <= 0) &&
              (IS_NULLFLD(screenProf, S_ScreenProfCompo_FctDictId) == TRUE))) &&
            (IS_NULLFLD(screenProf, S_ScreenProfCompo_EntDictId) == FALSE) &&
            (entityDictId == GET_DICT(screenProf, S_ScreenProfCompo_EntDictId)) &&
            (IS_NULLFLD(screenProf,S_ScreenProfCompo_NatAttrDictId) == TRUE) &&
            (IS_NULLFLD(screenProf,S_ScreenProfCompo_TpAttrDictId) == FALSE) &&
            (IS_NULLFLD(screenProf,S_ScreenProfCompo_SubTpAttrDictId) == TRUE))
        {
            dictId = GET_DICT(screenProf, S_ScreenProfCompo_TpAttrDictId);
            DBA_GetDictAttribIdxByDictId(entity, dictId, &typeIdx);
            if (DBA_CmpDynFld(screenProf,dynStp,S_ScreenProfCompo_TpId,typeIdx,IdType,FALSE) == 0)
                found = DBA_ScreenSelectConfirm(entity,functionDictId,dynStp,dynTab,dynNb,screenProf,FALSE);
        }
    }

    /*  Check first screen which match entity           */
    for (i = 0; (i < dynNb) && (found == FALSE); i++)
    {
        screenProf = dynTab[i];
        if ((((functionDictId > 0) &&
              (IS_NULLFLD(screenProf, S_ScreenProfCompo_FctDictId) == FALSE) &&
              (functionDictId == GET_DICT(screenProf, S_ScreenProfCompo_FctDictId))) ||
             ((functionDictId <= 0) &&
              (IS_NULLFLD(screenProf, S_ScreenProfCompo_FctDictId) == TRUE))) &&
            (IS_NULLFLD(screenProf, S_ScreenProfCompo_EntDictId) == FALSE) &&
            (entityDictId == GET_DICT(screenProf, S_ScreenProfCompo_EntDictId)) &&
            (IS_NULLFLD(screenProf,S_ScreenProfCompo_NatAttrDictId) == TRUE) &&
            (IS_NULLFLD(screenProf,S_ScreenProfCompo_TpAttrDictId) == TRUE) &&
            (IS_NULLFLD(screenProf,S_ScreenProfCompo_SubTpAttrDictId) == TRUE))
            found = TRUE;
    }

    if (found == TRUE)
        *shScreenProfStp = screenProf;

    return RET_SUCCEED;
}

/************************************************************************
**
**  Function    :   DBA_ScreenSelect
**
**  Description :   Find screen corresponding to an entity and an occurence
**
**  Arguments   :   OBJECT_ENUM     entity
**                  DBA_DYNFLD_STP  dynStp
**
**  Return      :   RET_CODE
**
**  Cr�ation   	:   FIH - 980922 - REF2644
**  Modif.      :   FIH - 990730 - REF3864
**
*************************************************************************/
RET_CODE    DBA_ScreenSelect (DICT_T         dictFunction,
                              OBJECT_ENUM    entity,
                              DBA_DYNFLD_STP dynStp,
                              DBA_DYNFLD_STP *shScreenProfStp,
                              DBA_DYNFLD_STP *dynTab,
                              int dynNb)
{
    DBA_DYNFLD_STP      admArg,
                        screenProf;
    DICT_T              dictScreenProf = 0,
                        dictEntity;
    FLAG_T              sFreeFlag;
    RET_CODE            retCode;
    DICT_T              dictFct ;       /*  FPL-PMSTA10126-100622   */
    DICT_ENTITY_STP     pdictent = DBA_GetDictEntitySt(entity);     /*  HFI-PMSTA-51777-2022-01-06  */

    /*  First Test  */
    if ((pdictent == nullptr) ||
        (shScreenProfStp == NULL) ||
        (dynStp == (DBA_DYNFLD_STP) NULL))
    {
	    MSG_RETURN(RET_GEN_ERR_INVARG);
    }
    
    /* Init local variables */
    retCode = RET_SUCCEED;
    screenProf = NULL;
    *shScreenProfStp = (DBA_DYNFLD_STP) NULL;
    DBA_GetDictId(entity, &dictEntity);

    /*  It makes no sense to check for a screen if it is not authorized to define a screen on the given entity  */  /*  HFI-PMSTA-51777-2022-01-06  */
    if (pdictent->bDictScreenRights == false)
    {
        return RET_SUCCEED;
    }

    /*  Select screen prof compo    */
    if ((dynTab == NULL) ||
        (dynNb == 0))
    {
        /*  Test if user has a screen profile   */
        /*  FIH-REF4138-991112  Replace TEST_RET by return  */
        if ((retCode = DBA_GetUserInfo2(A_ApplUser_ScreenProfileId, (PTR) &dictScreenProf, TRUE)) != RET_SUCCEED)          /*  FIH-REF11425-051027 Use DBA_GetUserInfo2 instead of DBA_GetUserInfo */
        {
            if (retCode == RET_DBA_INFO_NODATA)
            {
				DBA_MsgSendScreenMesg(dictScreenProf, dictFunction, entity, dynStp, NULL, NULL, 0);
                return RET_SUCCEED;
            }
            else
                return retCode;
        }

        /*  Alloc Get variables */
        if ((admArg = ALLOC_DYNST(Adm_Arg)) == NULL)
            MSG_RETURN(RET_MEM_ERR_ALLOC);

        /*  Init Get variables  */
        SET_DICT(admArg, Adm_Arg_Id, dictScreenProf);
        SET_DICT(admArg, Adm_Arg_EntDictId, dictEntity);

        /* Get screen list */
        retCode = DBA_Select2(ScreenProfCompo,
                              UNUSED,
                              Adm_Arg,
                              admArg,
                              S_ScreenProfCompo,
                              &dynTab,
                              UNUSED,
                              UNUSED,
                              &dynNb,
                              UNUSED);

        /*  Free Get variables  */
        FREE_DYNST(admArg, Adm_Arg);
        sFreeFlag = TRUE;
    }
    else
    {
        sFreeFlag = FALSE;
        if ((dynTab[0] != NULL) &&
            (IS_NULLFLD(dynTab[0],S_ScreenProfCompo_ScreenProfId) == FALSE))
            dictScreenProf = GET_DICT(dynTab[0],S_ScreenProfCompo_ScreenProfId);
    }

    /*  Manage GUI_DbaCall  */
    if ((retCode != RET_SUCCEED) ||
        (dynNb <= 0))
        return retCode;

    /*--------------------------------------------------------------*/
    /*  FIH-REF4258-000111                                          */
    /*  First loop S_ScreenProfCompo_FctDictId = funxtionDictId     */
    /*--------------------------------------------------------------*/
    screenProf = NULL;
    dictFct = DictFct_0 ;           /*  FPL-PMSTA10126-100622   */
    if (dictFunction > 0)
    {
        retCode = DBA_ScreenSelectWithFunction (dictFunction,
                                                entity,
                                                dictEntity,
                                                dynStp,
                                                &screenProf,
                                                dynTab,
                                                dynNb);
        dictFct = dictFunction;     /*  FPL-PMSTA10126-100622   */
    }
    /*--------------------------------------------------------------*/
    /*  FIH-REF4258-000111                                          */
    /*  Second loop S_ScreenProfCompo_FctDictId = NULL              */
    /*--------------------------------------------------------------*/
    if ((retCode == RET_SUCCEED) &&
        (screenProf == NULL))
        retCode = DBA_ScreenSelectWithFunction (DictFct_0,
                                                entity,
                                                dictEntity,
                                                dynStp,
                                                &screenProf,
                                                dynTab,
                                                dynNb);

    /*  Set the returned screen dict id */
    if ((screenProf != (DBA_DYNFLD_STP) NULL) &&
        (IS_NULLFLD(screenProf,S_ScreenProfCompo_ScreenDictId) == FALSE))
    {
        if ((*shScreenProfStp = ALLOC_DYNST(S_ScreenProfCompo)) == NULL)
        {
            if (sFreeFlag == TRUE)
                DBA_FreeDynStTab(dynTab, dynNb, S_ScreenProfCompo);
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }
        DBA_CopyDynSt(*shScreenProfStp, screenProf, S_ScreenProfCompo);
    }

    /*  FPL-PMSTA10126-100621   */
	DBA_MsgSendScreenMesg(dictScreenProf, dictFct, entity, dynStp, screenProf, dynTab, dynNb); /*  Change input: replace fctProcName by dictFct    HFI-PMSTA-14495-120619  */

    /*  Free list of screen prof compo  */
    if (sFreeFlag == TRUE)
        DBA_FreeDynStTab(dynTab, dynNb, S_ScreenProfCompo);

    return RET_SUCCEED;
}


/************************************************************************
**
**  Function    :   DBA_GetCalendarFromInstr
**
**  Description :   Get calendar identifier according to received instrument.
**                  - If instrument is swap leg then take calendarId defined in instrument.
**                  - Else the calendarId is taken from the reference currency.
**		            ! calendar id can be 0,
**		              if there isn't a calendar specified in currency.
**
**  Arguments   :   instrPtr 		instrument pointer
**		            calendarIdPtr	pointer on calendar identifier
**
**  Return      :   RET_CODE
**
**  Cr�ation    :   GRD - 981012 - REF1055.
**  Modif.	    :   REF5248 - RAK - 001005
**              :   REF5941 - YST - 020109 - swap mgmt extension
**              :   REF7264 - 0201225 - PMO : Compilation errors and warnings with C++ compiler
**
*************************************************************************/
RET_CODE DBA_GetCalendarFromInstr(DBA_DYNFLD_STP instrPtr,
                                  ID_T		 *calendarId)
{
	DBA_DYNFLD_STP	currOut = NULL;
    INSTRNAT_ENUM   instrNatEn=InstrNat_None;   /* REF7264 - PMO */
    SUBNAT_ENUM     instrSubNatEn=SubNat_None;  /* REF7264 - PMO */
	RET_CODE	    ret     = RET_SUCCEED;
    FLAG_T          freeFlag=FALSE;

	*calendarId = 0;

    /* REF5941 - YST - 020109 */
    /* if instr is a swap leg take calendarId of leg if defined */
    instrNatEn = (INSTRNAT_ENUM) GET_ENUM(instrPtr, A_Instr_NatEn);
    instrSubNatEn = (SUBNAT_ENUM)GET_ENUM(instrPtr, A_Instr_SubNatEn);
    if (InstrNat_Bond == instrNatEn &&
       (SubNat_PaidSwapFixedLeg == instrSubNatEn || SubNat_RecSwapFixedLeg == instrSubNatEn ||
        SubNat_PaidSwapFloatLeg == instrSubNatEn || SubNat_RecSwapFloatLeg == instrSubNatEn) &&
        (IS_NULLFLD(instrPtr, A_Instr_CalendarId) != TRUE))
    {
        *calendarId = GET_ID(instrPtr, A_Instr_CalendarId);
    }
	if ((*calendarId == 0) && (GET_ID(instrPtr, A_Instr_RefCurrId) != 0))
	{
        /* REF5248 - RAK - 001005 */
        /* Suppress DBA_Get2(Curr) and FREE_DYNST for currOut */
		/* PMSTA16847 - DDV - 130924 - Add freeFlag parameter */
        if ((ret = DBA_GetCurrById(GET_ID(instrPtr, A_Instr_RefCurrId),
                                          &currOut, &freeFlag)) != RET_SUCCEED)
		{
			return(ret);
		}

		*calendarId  = (ID_T)GET_ID(currOut, A_Curr_CalendarId);
        if (freeFlag == TRUE) {FREE_DYNST(currOut, A_Curr);}
	}

    return ret;
}

/************************************************************************
**
**  Function    :   DBA_SplitOrderFamily.
**
**  Description :   Splits whole bunch of ExtOps and Ops into :
**					1. parent ExtOps & Ops
**					2. child ExtOps & Ops
**
**  Arguments   :   ** Bunch of ExtOps / Ops & number **
**					DBA_ACCESS_STP      extOpAccessPtr
**					int                 extOpAccessNbr
**					DBA_ACCESS_STP      opAccessPtr
**					int                 opAccessNbr
**
**					** Parent ExtOps / Ops & number (to be allocated) **
**					DBA_ACCESS_STP      *extOpParentPtr
**					int                 *extOpParentNbr
**					DBA_ACCESS_STP      *opParentPtr
**					int                 *opParentNbr
**
**					** Child ExtOps / Ops & number (to be allocated) **
**					DBA_ACCESS_STP      *extOpChildPtr
**					int                 *extOpChildNbr
**					DBA_ACCESS_STP      *opChildPtr
**					int                 *opChildNbr
**
**
**  Return      :   RET_CODE.
**
**  Creation    :   REF7635 - CHU - 020618
**
*************************************************************************/
STATIC RET_CODE DBA_SplitOrderFamily(DBA_ACCESS_STP      extOpAccessPtr,
									 int                 extOpAccessNbr,
									 DBA_ACCESS_STP      opAccessPtr,
									 int                 opAccessNbr,
									 DBA_ACCESS_STP      *extOpParentPtr,
									 int                 *extOpParentNbr,
									 DBA_ACCESS_STP      *opParentPtr,
									 int                 *opParentNbr,
									 DBA_ACCESS_STP      *extOpChildPtr,
									 int                 *extOpChildNbr,
									 DBA_ACCESS_STP      *opChildPtr,
                                    int                 *opChildNbr,
                                    DBA_ACCESS_STP      *extOpHierParPtr,
                                    int                 *extOpHierParNbr,
                                    DBA_ACCESS_STP      *extOpHierChildPtr,
                                    int                 *extOpHierChildNbr,
                                    DBA_ACCESS_STP      *opHierParPtr,
                                    int                 *opHierParNbr,
                                    DBA_ACCESS_STP      *opHierChildPtr,
                                    int                 *opHierChildNbr
                                )
{
	int i;

	*extOpParentPtr	= NULL;
	*extOpParentNbr	= 0;

	*opParentPtr	= NULL;
	*opParentNbr	= 0;

	*extOpChildPtr	= NULL;
	*extOpChildNbr	= 0;

	*opChildPtr		= NULL;
	*opChildNbr		= 0;

    *extOpHierParPtr = NULL;
    *extOpHierChildPtr = NULL;
    *extOpHierChildNbr = 0;
    *extOpHierParNbr = 0;

    *opHierParPtr = NULL;
    *opHierChildPtr = NULL;
    *opHierChildNbr = 0;
    *opHierParNbr = 0;


    *opHierParPtr = NULL;
    *opHierParNbr = 0;
    *opHierChildPtr = NULL;
    *opHierChildNbr = 0;

	/* ********************** */
	/* Make space for Parents */
	/* ********************** */
	if (extOpAccessNbr > 0)
	{
		/* Allocate memory for parent extOps */
		if (((*extOpParentPtr) = (DBA_ACCESS_STP)CALLOC(extOpAccessNbr, sizeof(DBA_ACCESS_ST))) == NULL)
		{
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}
	}
	if (opAccessNbr > 0)
	{
		/* Allocate memory for parent Ops */
		if (((*opParentPtr) = (DBA_ACCESS_STP)CALLOC(opAccessNbr, sizeof(DBA_ACCESS_ST))) == NULL)
		{
			FREE((*extOpParentPtr));
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}
	}

	/* *********************** */
	/* Make space for Children */
	/* *********************** */
	if (extOpAccessNbr > 0)
	{
		/* Allocate memory for child extOps */
		if (((*extOpChildPtr) = (DBA_ACCESS_STP)CALLOC(extOpAccessNbr, sizeof(DBA_ACCESS_ST))) == NULL)
		{
			FREE((*extOpParentPtr));
			FREE((*opParentPtr));
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}
	}
	if (opAccessNbr > 0)
	{
		/* Allocate memory for child Ops */
		if (((*opChildPtr) = (DBA_ACCESS_STP)CALLOC(opAccessNbr, sizeof(DBA_ACCESS_ST))) == NULL)
		{
			FREE((*extOpParentPtr));
			FREE((*opParentPtr));
			FREE((*extOpChildPtr));
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}
	}


    if (extOpAccessNbr > 0)
    {
        /* Allocate memory for parent extOps */
        if (((*extOpHierParPtr) = (DBA_ACCESS_STP)CALLOC(extOpAccessNbr, sizeof(DBA_ACCESS_ST))) == NULL)
        {
            FREE((*extOpParentPtr));
            FREE((*opParentPtr));
            FREE((*extOpChildPtr));
            FREE((*opChildPtr));
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        /* Allocate memory for child extOps */
        if (((*extOpHierChildPtr) = (DBA_ACCESS_STP)CALLOC(extOpAccessNbr, sizeof(DBA_ACCESS_ST))) == NULL)
        {
            FREE((*extOpParentPtr));
            FREE((*opParentPtr));
            FREE((*extOpChildPtr));
            FREE((*opChildPtr));
            FREE((*extOpHierParPtr));
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }
    }


    if (opAccessNbr > 0)
    {
        /* Allocate memory for child Ops */
        if (((*opHierParPtr) = (DBA_ACCESS_STP)CALLOC(opAccessNbr, sizeof(DBA_ACCESS_ST))) == NULL)
        {
            FREE((*extOpParentPtr));
            FREE((*opParentPtr));
            FREE((*extOpChildPtr));
            FREE((*opChildPtr));
            FREE((*extOpHierParPtr));
            FREE((*extOpHierChildPtr));
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }
        if (((*opHierChildPtr) = (DBA_ACCESS_STP)CALLOC(opAccessNbr, sizeof(DBA_ACCESS_ST))) == NULL)
        {
            FREE((*extOpParentPtr));
            FREE((*opParentPtr));
            FREE((*extOpChildPtr));
            FREE((*opChildPtr));
            FREE((*extOpHierParPtr));
            FREE((*extOpHierChildPtr));
            FREE((*opHierParPtr));
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }
    }


	/* ********* */
	/* Split Ops */
	/* ********* */
	for (i=0; i < opAccessNbr; i++)
	{
		if (IS_NULLFLD(opAccessPtr[i].data, ExtOp_ParOpNatEn) == FALSE)
        {
			if ((GET_ENUM(extOpAccessPtr[i].data, ExtOp_ParOpNatEn) == ParOpNat_UnallocBlkOrder) ||
                (GET_ENUM(extOpAccessPtr[i].data, ExtOp_ParOpNatEn) == ParOpNat_BlockOrder) ||
                (GET_ENUM(extOpAccessPtr[i].data, ExtOp_ParOpNatEn) == ParOpNat_CombinedOrder)) /* PMSTA06760 - DDV - 086030 */
		    {
			    (*opParentPtr)[(*opParentNbr)] = opAccessPtr[i];
			    ++(*opParentNbr);
		    }
		    else if (IS_NULLFLD(extOpAccessPtr[i].data, ExtOp_HierOperNatEn) ||
                     (static_cast<HierOpNatEn>(GET_ENUM(extOpAccessPtr[i].data, ExtOp_HierOperNatEn)) == HierOpNatEn::HierOpNat_None) ||
                     (static_cast<HierOpNatEn>(GET_ENUM(extOpAccessPtr[i].data, ExtOp_HierOperNatEn))== HierOpNatEn::HierOpNat_BlockOrder &&
                     GET_ENUM(extOpAccessPtr[i].data, ExtOp_ParOpNatEn) == ParOpNat_ChildOrder))
            {
			    (*opChildPtr)[(*opChildNbr)] = opAccessPtr[i];
			    ++(*opChildNbr);
		    }

            /* hier pare and child */
            else if (IS_NULLFLD(opAccessPtr[i].data, ExtOp_HierOperNatEn) == FALSE)
            {
            if (HierOpNatEn::HierOpNat_BlockOrder == static_cast<HierOpNatEn>(GET_ENUM(extOpAccessPtr[i].data, ExtOp_HierOperNatEn)))
                {
                    (*opHierParPtr)[(*opHierParNbr)] = opAccessPtr[i];
                    ++(*opHierParNbr);
                }
            else if(HierOpNatEn::HierOpNat_ChildOrder == static_cast<HierOpNatEn>(GET_ENUM(extOpAccessPtr[i].data, ExtOp_HierOperNatEn)))
                {
                    (*opHierChildPtr)[(*opHierChildNbr)] = opAccessPtr[i];
                    ++(*opHierChildNbr);
                }
            }
    	}


	}

	/* ************ */
	/* Split extOps */
	/* ************ */
	for (i=0; i < extOpAccessNbr; i++)
	{
		if (IS_NULLFLD(extOpAccessPtr[i].data, ExtOp_ParOpNatEn) == FALSE)
        {
			if ((GET_ENUM(extOpAccessPtr[i].data, ExtOp_ParOpNatEn) == ParOpNat_UnallocBlkOrder) ||
                (GET_ENUM(extOpAccessPtr[i].data, ExtOp_ParOpNatEn) == ParOpNat_BlockOrder) ||
                (GET_ENUM(extOpAccessPtr[i].data, ExtOp_ParOpNatEn) == ParOpNat_CombinedOrder)) /* PMSTA06760 - DDV - 086030 */
		    {
			    (*extOpParentPtr)[(*extOpParentNbr)] = extOpAccessPtr[i];
			    ++(*extOpParentNbr);
		    }
		    else  if(IS_NULLFLD(extOpAccessPtr[i].data, ExtOp_HierOperNatEn) ||
                (static_cast<HierOpNatEn>(GET_ENUM(extOpAccessPtr[i].data, ExtOp_HierOperNatEn)) == HierOpNatEn::HierOpNat_None) ||
                (static_cast<HierOpNatEn>(GET_ENUM(extOpAccessPtr[i].data, ExtOp_HierOperNatEn)) == HierOpNatEn::HierOpNat_BlockOrder &&
                    GET_ENUM(extOpAccessPtr[i].data, ExtOp_ParOpNatEn) == ParOpNat_ChildOrder))
		    {
			    (*extOpChildPtr)[(*extOpChildNbr)] = extOpAccessPtr[i];
			    ++(*extOpChildNbr);
		    }

            else if (IS_NULLFLD(extOpAccessPtr[i].data, ExtOp_HierOperNatEn) == FALSE)
            {
            if (HierOpNatEn::HierOpNat_BlockOrder == static_cast<HierOpNatEn>(GET_ENUM(extOpAccessPtr[i].data, ExtOp_HierOperNatEn)))
                {
                    (*extOpHierParPtr)[(*extOpHierParNbr)] = extOpAccessPtr[i];
                    ++(*extOpHierParNbr);
                }
            else if (HierOpNatEn::HierOpNat_ChildOrder == static_cast<HierOpNatEn>(GET_ENUM(extOpAccessPtr[i].data, ExtOp_HierOperNatEn)))
                {
                    (*extOpHierChildPtr)[(*extOpHierChildNbr)] = extOpAccessPtr[i];
                    ++(*extOpHierChildNbr);
                }
            }
    	}
	}
	return(RET_SUCCEED);
}

/****************************************************************************
**
**  Function    :   DBA_DispatchOrderFamilyId
**
**  Description :   Dispatches Block Order ExtOps/Ops DBIds into its children
**
**  Arguments   :   DBA_ACCESS_STP	extOpChildPtr
**					int				extOpChildNbr
**					DBA_ACCESS_STP	opChildPtr
**					int				opChildNbr
**
**
**  Return      :   nothing
**
**  Cr�ation    :   REF7635 - CHU - 020618
**  Last modif. :   REF8500 - 040510 - PMO : Add a draft_order_id in extended operation to distinguish the id from extended orders and the one from extended operation
**
*****************************************************************************/
STATIC void DBA_DispatchOrderFamilyParentId(DBA_ACCESS_STP	extOpChildPtr,
											int				extOpChildNbr,
											DBA_ACCESS_STP	opChildPtr,
											int				opChildNbr)
{
	DBA_DYNFLD_STP	pdbadynParent;
	int				i;

	for (i=0; i < opChildNbr; i++)
	{
		/* Ajout du ExtOp_ParentId pour les ParOpNat_ChildOrder */
		if ((opChildPtr[i].data != NULL) &&
			(IS_NULLFLD(opChildPtr[i].data, ExtOp_ParOpNatEn) == FALSE) &&
			((GET_ENUM(opChildPtr[i].data, ExtOp_ParOpNatEn) == ParOpNat_ChildOrder) ||
			 (GET_ENUM(opChildPtr[i].data, ExtOp_ParOpNatEn) == ParOpNat_ChildCombinedOrder)) && /* PMSTA06760 - DDV - 080701 */
			(IS_NULLFLD(opChildPtr[i].data, ExtOp_ParentExtOpId) == TRUE) &&
			(IS_NULLFLD(opChildPtr[i].data, ExtOp_ParExtOp_Ext) == FALSE) &&
			(GET_EXTENSION_PTR(opChildPtr[i].data, ExtOp_ParExtOp_Ext) != NULL) &&
			((pdbadynParent = *(GET_EXTENSION_PTR(opChildPtr[i].data, ExtOp_ParExtOp_Ext))) != NULL) &&
			(IS_EXTOP_DATABASE_ID_PRESENT(pdbadynParent)))
		{
            /* REF8500 - 040510 - PMO */
            SET_ID(opChildPtr[i].data, ExtOp_ParentExtOpId, GET_EXTOP_DATABASE_ID(pdbadynParent));
		}

        if ((opChildPtr[i].data != NULL) &&
            (IS_NULLFLD(opChildPtr[i].data, ExtOp_HierOperNatEn) == FALSE) &&
            (HierOpNatEn::HierOpNat_ChildOrder == static_cast<HierOpNatEn>(GET_ENUM(opChildPtr[i].data, ExtOp_HierOperNatEn))) &&
            (IS_NULLFLD(opChildPtr[i].data, ExtOp_ParentExtOpId) == TRUE) &&
            (IS_NULLFLD(opChildPtr[i].data, ExtOp_ParExtOp_Ext) == FALSE) &&
            (GET_EXTENSION_PTR(opChildPtr[i].data, ExtOp_ParExtOp_Ext) != NULL) &&
            ((pdbadynParent = *(GET_EXTENSION_PTR(opChildPtr[i].data, ExtOp_ParExtOp_Ext))) != NULL) &&
            (IS_EXTOP_DATABASE_ID_PRESENT(pdbadynParent)))
        {
            SET_ID(opChildPtr[i].data, ExtOp_ParentHierExtOpId, GET_EXTOP_DATABASE_ID(pdbadynParent));
            SET_ID(opChildPtr[i].data, ExtOp_ParentExtOpId, GET_EXTOP_DATABASE_ID(pdbadynParent));
        }
	}

	for (i=0; i < extOpChildNbr; i++)
	{
		/* Ajout du ExtOp_ParentId pour les ParOpNat_ChildOrder */
		if ((extOpChildPtr[i].data != NULL) &&
			(IS_NULLFLD(extOpChildPtr[i].data, ExtOp_ParOpNatEn) == FALSE) &&
			((GET_ENUM(extOpChildPtr[i].data, ExtOp_ParOpNatEn) == ParOpNat_ChildOrder) ||
			 (GET_ENUM(extOpChildPtr[i].data, ExtOp_ParOpNatEn) == ParOpNat_ChildCombinedOrder)) && /* PMSTA06760 - DDV - 080701 */
			(IS_NULLFLD(extOpChildPtr[i].data, ExtOp_ParentExtOpId) == TRUE) &&
			(IS_NULLFLD(extOpChildPtr[i].data, ExtOp_ParExtOp_Ext) == FALSE) &&
			(GET_EXTENSION_PTR(extOpChildPtr[i].data, ExtOp_ParExtOp_Ext) != NULL) &&
			((pdbadynParent = *(GET_EXTENSION_PTR(extOpChildPtr[i].data, ExtOp_ParExtOp_Ext))) != NULL) &&
			(IS_EXTOP_DATABASE_ID_PRESENT(pdbadynParent)))
		{
            /* REF8500 - 040510 - PMO */
            SET_ID(extOpChildPtr[i].data, ExtOp_ParentExtOpId, GET_EXTOP_DATABASE_ID(pdbadynParent));
		}

        if ((extOpChildPtr[i].data != NULL) &&
            (IS_NULLFLD(extOpChildPtr[i].data, ExtOp_HierOperNatEn) == FALSE) &&
            (HierOpNatEn::HierOpNat_ChildOrder == static_cast<HierOpNatEn>(GET_ENUM(extOpChildPtr[i].data, ExtOp_HierOperNatEn))) &&
            (IS_NULLFLD(extOpChildPtr[i].data, ExtOp_ParentExtOpId) == TRUE) &&
            (IS_NULLFLD(extOpChildPtr[i].data, ExtOp_ParExtOp_Ext) == FALSE) &&
            (GET_EXTENSION_PTR(extOpChildPtr[i].data, ExtOp_ParExtOp_Ext) != NULL) &&
            ((pdbadynParent = *(GET_EXTENSION_PTR(extOpChildPtr[i].data, ExtOp_ParExtOp_Ext))) != NULL) &&
            (IS_EXTOP_DATABASE_ID_PRESENT(pdbadynParent)))
        {
            SET_ID(extOpChildPtr[i].data, ExtOp_ParentHierExtOpId, GET_EXTOP_DATABASE_ID(pdbadynParent));
            SET_ID(extOpChildPtr[i].data, ExtOp_ParentExtOpId, GET_EXTOP_DATABASE_ID(pdbadynParent));
        }
	}
}

/************************************************************************
*
*   Function      :   FIN_FilterESLCrtPtf()
*
*   Description   :   Return all ESE of the current portfolio
*
*                     return TRUE  -> record must be extract
*                            FALSE -> record musn't be extract
*
*   Arguments     :   dynSt   first element pointer
*                     prt2    second element pointer
*
*   Return        :   TRUE or FALSE
*
*   Creation Date :   RAK - 110825 - PMSTA-12639
*************************************************************************/
int FIN_FilterESLCrtPtf(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP ptfPtr)
{
    if (GET_ID(dynSt, ExtStratLnk_PtfId) == GET_ID(ptfPtr, A_Ptf_Id))
    {
        return(TRUE);
    }
    return(FALSE);
}

/************************************************************************
*
*   Function      :   FIN_FilterESECrtPtf()
*
*   Description   :   Return all ESE of the current portfolio
*
*                     return TRUE  -> record must be extract
*                            FALSE -> record musn't be extract
*
*   Arguments     :   dynSt   first element pointer
*                     prt2    second element pointer
*
*   Return        :   TRUE or FALSE
*
*   Creation Date :   RAK - 031127 - REF9147
*************************************************************************/
int FIN_FilterESECrtPtf(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP ptfPtr)
{
    if (GET_ID(dynSt, ExtStratElt_PtfId) == GET_ID(ptfPtr, A_Ptf_Id))
    {
        return(TRUE);
    }
    return(FALSE);
}

/************************************************************************
*
*   Function      :   FIN_FilterExtLinkMP()
*
*   Description   :   Return all MP ESL of the current portfolio
*
*                     return TRUE  -> record must be extract
*                            FALSE -> record musn't be extract
*
*   Arguments     :
*
*   Return        :   TRUE or FALSE
*
*   Creation Date :   PMSTA-38323 - 01102020 - SGO
*************************************************************************/
int FIN_FilterExtLinkMP(DBA_DYNFLD_STP dynSt,
	DBA_DYNST_ENUM dynStTp,
	DBA_DYNFLD_STP ptfIdDynSt)
{
	if (GET_ENUM(dynSt, ExtStratLnk_StratNatEn) == StratNat_ModelPtf &&
		GET_ID(dynSt, ExtStratLnk_PtfId) == GET_ID(ptfIdDynSt, 0) &&
		(GET_TINYINT(dynSt, ExtStratLnk_Level) == 1 || TRUE == GET_FLAG(dynSt, ExtStratLnk_SubModelFlg ) ) )
		return(TRUE);
	return(FALSE);
}

/************************************************************************
**
**  Function    : FIN_FilterESLStratIP(DBA_DYNFLD_STP dynSt,
()
**
**  Description : Filter InvestProfile strategy ESL
**                return TRUE  -> record must be extract
**                       FALSE -> record musn't be extract
**
**  Arguments   : dynSt    element pointer
**                dynStTp  element description enum
**
**  Return      : TRUE or FALSE
**
**  Creation    : PMSTA-42601 - SGO - 26112020
**
*************************************************************************/
int FIN_FilterESLStratIP(DBA_DYNFLD_STP dynSt,
                                DBA_DYNST_ENUM dynStTp,
                                DBA_DYNFLD_STP unused)
{
	if (GET_ENUM(dynSt, ExtStratLnk_StratNatEn) == StratNat_InvestProfile)
	{
		return(TRUE);
	}

	return(FALSE);
}

/************************************************************************
*
*   Function      :   FIN_SelectDataFromHier()
*
*   Description   :   Return all ESE of the current portfolio
*
*                     return TRUE  -> record must be extract
*                            FALSE -> record musn't be extract
*
*   Arguments     :   dynSt   first element pointer
*                     prt2    second element pointer
*
*   Return        :   TRUE or FALSE
*
*   Creation Date :   PMSTA-28596 - CHU - 171130
*
*   Modification  :   PMSTA-33666 - CHU - 181122 : rewritten to also search in ext_operation records if no ESL found
*************************************************************************/
STATIC RET_CODE FIN_SelectDataFromHier(PTR              argHierHead,
                                       DBA_DYNFLD_STP   **allPtfTab,
                                       int              *allPtfNbr,
                                       DBA_DYNFLD_STP   **ESLTabPtr,
                                       int              *ESLNbrPtr,
                                       DBA_DYNFLD_STP   **ESETabPtr,
                                       int              *ESENbrPtr,
                                       DBA_DYNFLD_STP   *extOpTab,  /* PMSTA-33666 - CHU - 181122 */
                                       int				extOpNbr,   /* PMSTA-33666 - CHU - 181122 */
                                       FLAG_T           **allocFlgTab)
{
    RET_CODE    ret = RET_SUCCEED;
    int         i = 0, j = 0;       /* PMSTA-30625 - CHU - 180321 */
    bool        foundFlg = false;   /* PMSTA-30625 - CHU - 180321 */

    DBA_DYNST_ENUM  searchDynstEn = NullDynSt;  /* PMSTA-33666 - CHU - 181122 */
    FIELD_IDX_T     fieldPtfIdx   = 0;          /* PMSTA-33666 - CHU - 181122 */
    DBA_DYNFLD_STP *searchDynTab  = NULL;       /* PMSTA-33666 - CHU - 181122 */
    int             searchDynNbr  = 0;          /* PMSTA-33666 - CHU - 181122 */

    if ((ret = DBA_ExtractHierEltRec((DBA_HIER_HEAD_STP)argHierHead,
                                     ExtStratLnk,
                                     FALSE,
                                     NULLFCT,
                                     NULLFCT,
                                     ESLNbrPtr,
                                     ESLTabPtr)) != RET_SUCCEED)
    {
        return(ret);
    }

    if ((ret = DBA_ExtractHierEltRec((DBA_HIER_HEAD_STP)argHierHead,
                                     ExtStratElt,
                                     FALSE,
                                     NULLFCT,
                                     NULLFCT,
                                     ESENbrPtr,
                                     ESETabPtr)) != RET_SUCCEED)
    {
        return(ret);
    }

    /* < PMSTA-33666 - CHU - 181122 */
    if (*ESLNbrPtr > 0)
    {
        searchDynstEn = ExtStratLnk;
        fieldPtfIdx   = ExtStratLnk_PtfId;
        searchDynTab  = *ESLTabPtr;
        searchDynNbr  = *ESLNbrPtr;
    }
    else if (extOpNbr > 0)
    {
        searchDynstEn = ExtOp;
        fieldPtfIdx   = ExtOp_PtfId;
        searchDynTab  = extOpTab;
        searchDynNbr  = extOpNbr;
    }
    /* > PMSTA-33666 - CHU - 181122 */

    *allPtfNbr = 0;

    for (i = 0; i < searchDynNbr; i++)
    {
        if (GET_ID(searchDynTab[i], fieldPtfIdx) > 0) /* PMSTA-33666 - CHU - 181122 */
        {
            if (searchDynstEn == ExtStratLnk &&
                (IS_NULLFLD(searchDynTab[i], ExtStratLnk_Level) == FALSE &&            /* PMSTA-33576 - BSG - 181204 */
                    GET_TINYINT(searchDynTab[i], ExtStratLnk_Level) != 1) ||           /* PMSTA-30625 - CHU - 180321 */
                IS_NULLFLD(searchDynTab[i], ExtStratLnk_ParExtStratLnkId) == FALSE)
            {
                continue;
            }

            /* < PMSTA-30625 - CHU - 180321 */
            foundFlg = false;
            for (j = 0; j < *allPtfNbr; j++)
            {
                if (CMP_ID(GET_ID(searchDynTab[i], fieldPtfIdx), GET_ID((*allPtfTab)[j], A_Ptf_Id)) == 0) /* PMSTA-33666 - CHU - 181122 */
                {
                    foundFlg = true;
                    break;
                }
            }

            if (true == foundFlg)
            {
                continue;
            }
            /* > PMSTA-30625 - CHU - 180321 */

            if (*allPtfNbr == 0)
            {
                if ((*allPtfTab = (DBA_DYNFLD_STP*)CALLOC(1, sizeof(DBA_DYNFLD_STP))) == NULL)
                {
                    ret = RET_MEM_ERR_ALLOC;
                    return(ret);
                }
                if ((*allocFlgTab = (FLAG_T*)CALLOC(1, sizeof(FLAG_T))) == NULL)
                {
                    ret = RET_MEM_ERR_ALLOC;
                    return(ret);
                }
            }
            else
            {
                if ((*allPtfTab = (DBA_DYNFLD_STP *)REALLOC(*allPtfTab, (*allPtfNbr + 1) * sizeof(DBA_DYNFLD_STP))) == NULL)
                {
                    ret = RET_MEM_ERR_ALLOC;
                    return(ret);
                }
                if ((*allocFlgTab = (FLAG_T *)REALLOC(*allocFlgTab, (*allPtfNbr + 1) * sizeof(FLAG_T))) == NULL)
                {
                    ret = RET_MEM_ERR_ALLOC;
                    return(ret);
                }
            }

            if ((ret = DBA_GetPtfById(GET_ID(searchDynTab[i], fieldPtfIdx), /* PMSTA-33666 - CHU - 181122 */
                TRUE,
                &((*allocFlgTab)[*allPtfNbr]),
                &((*allPtfTab)[*allPtfNbr]),
                argHierHead,
                UNUSED, UNUSED)) != RET_SUCCEED)
            {
                return(ret);
            }
            (*allPtfNbr)++;
        }
    }

    return(ret);
}

/************************************************************************
**
**  Function    :   DBA_NewSplitSession.
**
**  Description :   Create new draft session for rejected Orders in a session.
**
**  Arguments   :   extOp's, Cases, domain
**
**  Return      :   RET_CODE and newly created A_FctResult DynSt
**
**  Creation    :   PMSTA09118-CHU-100125
**
**  Modif.      :   PMSTA10444-CHU-110504 : rewrote to consider Cases and Ptf families
**
*************************************************************************/
RET_CODE DBA_NewSplitSession(DBA_DYNFLD_STP			**extOpTab,
                             int					*extOpNbr,
                             int					,
                             DBA_DYNFLD_STP			pdbadynDomain,
                             DBA_DYNFLD_STP			**caseMgtTab,
                             int					*caseMgtNbr,
                             DBA_DYNFLD_STP			*draftFctResPtr,
                             int					*connectNo,
                             PTR                    argHierHead) /* PMSTA-28596 - CHU - 171012 */
{
	RET_CODE ret = RET_SUCCEED;

	DBA_DYNFLD_STP		draftDomainPtr   = NULL,	localDraftFctRes = NULL,
                    *draftPtfTab   = NULL, *allPtfTab = NULL,
						*finalOrderTab   = NULL,	*draftOrderTab   = NULL,
						*finalCaseMgtTab = NULL,	*draftCaseMgtTab = NULL,
						*finalPtfTab	 = NULL,
						hierPtfPtr		 = NULL;

    int             draftPtfNbr = 0, allPtfNbr = 0,
                    finalPtfNbr = 0, allPtfIdx = 0,
                    finalOrderNbr = 0, draftOrderNbr = 0,
						finalCaseMgtNbr  = 0,		draftCaseMgtNbr  = 0,
                    i = 0, j = 0;

    FLAG_T              *allocFlgTab	= NULL,		*allocDraftFlgTab  = NULL,
						*allocFinalFlgTab = NULL,	allochierPtfFlg = FALSE,
						foundFlg		= TRUE,	applCaseActivationFlag = FALSE,
						draftPtfFound = FALSE;			/* PMSTA14136-CHU-120419 */
	ENUM_T				applStratBlockConstrCriticalness;
	ENUM_T				applSessionBlockCriticalness;
	CASEMANAGEMENTSTATUS_ENUM applCaseClarificationStatus = CaseManagementStatus_NotClarified; /* PMSTA-17573-CHU-140208 */
	ID_T				hierPtfId = (ID_T)-1;

    DBA_DYNFLD_STP  *ESLTab = NULL, *ESETab = NULL;  /* PMSTA-28596 - CHU - 171012 */
    int             ESLNbr = NULL, ESENbr = NULL;  /* PMSTA-28596 - CHU - 171012 */

    DBA_DYNFLD_STP	copyArgPtr = NULL;

	GEN_GetApplInfo(ApplCaseActivationFlag, &applCaseActivationFlag);

    if (extOpNbr == NULL || *extOpNbr == 0 || argHierHead == NULL)
		return(ret);

	if (applCaseActivationFlag == TRUE &&
		(caseMgtTab == NULL || *caseMgtNbr == 0))
	{
		return(ret);
	}

    if ((ret = FIN_SelectDataFromHier(argHierHead,
                                      &allPtfTab, &allPtfNbr,
                                      &ESLTab, &ESLNbr,
                                      &ESETab, &ESENbr,
                                      *extOpTab, *extOpNbr,
                                      &allocFlgTab)) != RET_SUCCEED)
	{
        if (allPtfNbr > 0)  FREE(allPtfTab);
        if (ESLNbr > 0)     FREE(ESLTab);
        if (ESENbr > 0)     FREE(ESETab);
		return(ret);
	}

    /* < PMSTA-33666 - CHU - 181115 : If nothing found in memory... well let's do... nothing! */
    if (allPtfNbr == 0)
    {
        FREE(allPtfTab);
        FREE(ESLTab);
        FREE(ESETab);
		ret = RET_DBA_ERR_KRANOTFOUND; /* PMSTA-14006-CHU-120402 : special retcode to tell above to keep session in Checked Status */
        return(ret);
    }
    /* > PMSTA-33666 - CHU - 181115 */

    if ((draftPtfTab = (DBA_DYNFLD_STP*)CALLOC(allPtfNbr, sizeof(DBA_DYNFLD_STP))) == NULL)
    {
        for (i = 0; i < allPtfNbr; i++)
	    {
            if (allocFlgTab[i] == TRUE) { FREE_DYNST(allPtfTab[i], A_Ptf); }
        }
		FREE(allPtfTab);
        FREE(ESLTab);
        FREE(ESETab);
		ret = RET_MEM_ERR_ALLOC;
        MSG_SendMesg(ret, 0, FILEINFO);
		return(ret);
	}

    if ((finalPtfTab = (DBA_DYNFLD_STP*)CALLOC(allPtfNbr, sizeof(DBA_DYNFLD_STP))) == NULL)
    {
        for (i = 0; i < allPtfNbr; i++)
	    {
            if (allocFlgTab[i] == TRUE) { FREE_DYNST(allPtfTab[i], A_Ptf); }
        }
		FREE(allPtfTab);
        FREE(ESLTab);
        FREE(ESETab);
		FREE(draftPtfTab);
		ret = RET_MEM_ERR_ALLOC;
        MSG_SendMesg(ret, 0, FILEINFO);
		return(ret);
	}

    if ((allocDraftFlgTab = (FLAG_T*)CALLOC(allPtfNbr, sizeof(FLAG_T))) == NULL)
    {
        for (i = 0; i < allPtfNbr; i++)
	    {
            if (allocFlgTab[i] == TRUE) { FREE_DYNST(allPtfTab[i], A_Ptf); }
        }
		FREE(allPtfTab);
        FREE(ESLTab);
        FREE(ESETab);
		FREE(draftPtfTab);
		FREE(finalPtfTab);
		ret = RET_MEM_ERR_ALLOC;
        MSG_SendMesg(ret, 0, FILEINFO);
		return(ret);
	}

    if ((allocFinalFlgTab = (FLAG_T*)CALLOC(allPtfNbr, sizeof(FLAG_T))) == NULL)
    {
        for (i = 0; i < allPtfNbr; i++)
	    {
            if (allocFlgTab[i] == TRUE) { FREE_DYNST(allPtfTab[i], A_Ptf); }
	    }
		FREE(allPtfTab);
        FREE(ESLTab);
        FREE(ESETab);
		FREE(draftPtfTab);
		FREE(finalPtfTab);
		FREE(allocDraftFlgTab);
		ret = RET_MEM_ERR_ALLOC;
        MSG_SendMesg(ret, 0, FILEINFO);
		return(ret);
	}

	GEN_GetApplInfo(ApplCaseActivationFlag, &applCaseActivationFlag);

    if ((EVTGEN_ENUM)GET_ENUM(pdbadynDomain, A_Domain_EvtGenNatEn) == EvtGen_CheckCaseSplitAndPublish && applCaseActivationFlag == TRUE)
    {
        ret = DBA_NewCaseSplitSession(&(*extOpTab), extOpNbr, &allPtfTab, allPtfNbr,
                                      &ESLTab, ESLNbr,
                                      &ESETab, ESENbr,
                                      &allocFlgTab,
                                      pdbadynDomain,
                                      &(*caseMgtTab),
                                      caseMgtNbr,
                                      connectNo,/* (int*)&dbiConn->getId() */
                                      argHierHead);
        FREE(allPtfTab);
        FREE(ESLTab);
        FREE(ESETab);
        FREE(draftPtfTab);
        FREE(finalPtfTab);
        FREE(allocDraftFlgTab);
        FREE(allocFinalFlgTab);
        return(ret);
    }
	else if (applCaseActivationFlag == TRUE) /* populate draftPtfTab based on blocking Cases */
	{
		GEN_GetApplInfo(ApplStratBlockConstrCriticalness, &applStratBlockConstrCriticalness);
		GEN_GetApplInfo(ApplSessionBlockCriticalness,     &applSessionBlockCriticalness);
		GEN_GetApplInfo(ApplCaseClarificationStatus,	  &applCaseClarificationStatus); /* PMSTA-17573-CHU-140208 */

		if (*caseMgtNbr > 0)
		{
            for (i = 0; i<*caseMgtNbr; i++)
			{
				foundFlg = FALSE;
				draftPtfFound = FALSE;

				if (IS_NULLFLD((*caseMgtTab)[i], A_CaseManagement_PtfId) == FALSE &&
					(((IS_NULLFLD((*caseMgtTab)[i], A_CaseManagement_CriticalnessEn) == FALSE) &&
                    (GET_ENUM((*caseMgtTab)[i], A_CaseManagement_CriticalnessEn) >= applSessionBlockCriticalness) &&
					  (FIN_CaseSessionBlockingCheckConfirmedFlag((*caseMgtTab)[i]) == TRUE))
					  ||
					 ((IS_NULLFLD((*caseMgtTab)[i], A_CaseManagement_CriticalnessEn) == FALSE) &&
                    (GET_ENUM((*caseMgtTab)[i], A_CaseManagement_CriticalnessEn) >= applStratBlockConstrCriticalness) &&
                    (GET_ENUM((*caseMgtTab)[i], A_CaseManagement_CriticalnessEn) > ConstrCriticalness_None) &&
					  (IS_NULLFLD((*caseMgtTab)[i], A_CaseManagement_StatusEn) == FALSE) &&
                    (GET_ENUM((*caseMgtTab)[i], A_CaseManagement_StatusEn) < applCaseClarificationStatus)))) /* PMSTA-17573-CHU-140208 */
				{
					/* PMSTA-14006-CHU-120402 check parent portfolio */
					DBA_GetPtfById(GET_ID((*caseMgtTab)[i], A_CaseManagement_PtfId), TRUE,
								   &allochierPtfFlg, &hierPtfPtr,
								   DBA_GetHierOptiPtr(), UNUSED, UNUSED);
					if (IS_NULLFLD(hierPtfPtr, A_Ptf_HierPortId) == FALSE)
					{
						hierPtfId = GET_ID(hierPtfPtr, A_Ptf_HierPortId);
					}
					else
					{
						hierPtfId = GET_ID(hierPtfPtr, A_Ptf_Id);
					}

					/* get the portfolio from allPtfTab */
                    for (j = 0; j < allPtfNbr; j++)
					{
						if (CMP_ID(GET_ID(allPtfTab[j], A_Ptf_HierPortId),	hierPtfId) == 0 ||
							CMP_ID(GET_ID(allPtfTab[j], A_Ptf_Id),			hierPtfId) == 0)
						{
								draftPtfFound = TRUE;
								allPtfIdx = j;
								break;
							}
						}

						if (draftPtfFound == TRUE)
						{
                        for (j = 0; j < draftPtfNbr; j++)
							{
								if (CMP_ID(GET_ID(draftPtfTab[j], A_Ptf_Id), GET_ID(allPtfTab[allPtfIdx], A_Ptf_Id)) == 0)
								{
									foundFlg = TRUE;
									break;
								}
							}

							if (foundFlg == FALSE)
						{
								draftPtfTab[draftPtfNbr]		= allPtfTab[allPtfIdx];
								allocDraftFlgTab[draftPtfNbr++]	= allocFlgTab[allPtfIdx];
						}
					}
                    if (allochierPtfFlg == TRUE) { FREE_DYNST(hierPtfPtr, A_Ptf); }
				}
			}
		}
	}
	else	/* populate draftPtfTab based on FALSE confirmed flags */
	{
        for (i = 0; i<*extOpNbr; i++)
		{
			if (GET_FLAG((*extOpTab)[i], ExtOp_ConfirmedFlg) == FALSE)
			{
				/* PMSTA-14006-CHU-120402 check parent portfolio */
				DBA_GetPtfById(GET_ID((*extOpTab)[i], ExtOp_PtfId), TRUE,
							   &allochierPtfFlg, &hierPtfPtr,
							   DBA_GetHierOptiPtr(), UNUSED, UNUSED);
				if (IS_NULLFLD(hierPtfPtr, A_Ptf_HierPortId) == FALSE)
				{
					hierPtfId = GET_ID(hierPtfPtr, A_Ptf_HierPortId);
				}
				else
				{
					hierPtfId = GET_ID(hierPtfPtr, A_Ptf_Id);
				}

				/* get the portfolio from allPtfTab */
                for (j = 0; j < allPtfNbr; j++)
				{
					if (CMP_ID(GET_ID(allPtfTab[j], A_Ptf_HierPortId),	hierPtfId) == 0 ||
						CMP_ID(GET_ID(allPtfTab[j], A_Ptf_Id),			hierPtfId) == 0)
					{
						draftPtfFound = TRUE;
						allPtfIdx = j;
						break;
					}
				}

				if (draftPtfFound == TRUE)
				{
                    for (j = 0; j < draftPtfNbr; j++)
					{
						if (CMP_ID(GET_ID(draftPtfTab[j], A_Ptf_Id), GET_ID(allPtfTab[allPtfIdx], A_Ptf_Id)) == 0)
						{
							foundFlg = TRUE;
							break;
						}
					}

					if (foundFlg == FALSE)
					{
						draftPtfTab[draftPtfNbr]		= allPtfTab[allPtfIdx];
						allocDraftFlgTab[draftPtfNbr++]	= allocFlgTab[allPtfIdx];
					}
				}
                if (allochierPtfFlg == TRUE) { FREE_DYNST(hierPtfPtr, A_Ptf); }
			}
		}
	}

    if (draftPtfNbr < allPtfNbr) /* arrays have to be split */
	{
        for (i = 0; i < allPtfNbr; i++)
		{
			draftPtfFound = FALSE;

            for (j = 0; j < draftPtfNbr; j++)
			{
				if (CMP_ID(GET_ID(allPtfTab[i], A_Ptf_Id), GET_ID(draftPtfTab[j], A_Ptf_Id)) == 0)
				{
					draftPtfFound = TRUE;
					allPtfIdx = j;
					break;
				}
			}

			if (draftPtfFound == FALSE)
			{
				finalPtfTab[finalPtfNbr]		= allPtfTab[i];
				allocFinalFlgTab[finalPtfNbr++]	= allocFlgTab[i];
			}
		}
	}
    	/* now, dispatch orders based on draftPtfTab */
    if ((finalOrderTab = (DBA_DYNFLD_STP*)CALLOC(*extOpNbr, sizeof(DBA_DYNFLD_STP))) == NULL)
	{
        for (i = 0; i < allPtfNbr; i++)
		{
            if (allocFlgTab[i] == TRUE) { FREE_DYNST(allPtfTab[i], A_Ptf); }
		}
        FREE(allPtfTab);
        FREE(ESLTab);
        FREE(ESETab);
		FREE(draftPtfTab);
		FREE(finalPtfTab);
		FREE(allocDraftFlgTab);
		FREE(allocFinalFlgTab);
		ret = RET_MEM_ERR_ALLOC;
        MSG_SendMesg(ret, 0, FILEINFO);
		return(ret);
	}

    if ((draftOrderTab = (DBA_DYNFLD_STP*)CALLOC(*extOpNbr, sizeof(DBA_DYNFLD_STP))) == NULL)
	{
        for (i = 0; i < allPtfNbr; i++)
		{
            if (allocFlgTab[i] == TRUE) { FREE_DYNST(allPtfTab[i], A_Ptf); }
		}
        FREE(allPtfTab);
        FREE(ESLTab);
        FREE(ESETab);
		FREE(draftPtfTab);
		FREE(finalPtfTab);
		FREE(allocDraftFlgTab);
		FREE(allocFinalFlgTab);
		ret = RET_MEM_ERR_ALLOC;
        MSG_SendMesg(ret, 0, FILEINFO);
		return(ret);
	}

    for (i = 0; i< finalPtfNbr; i++)
	{
        for (j = 0; j<*extOpNbr; j++)
		{
			if (CMP_ID(GET_ID((*extOpTab)[j], ExtOp_PtfId), GET_ID(finalPtfTab[i], A_Ptf_Id)) == 0) /* PMSTA13395-CHU-120216 misplaced parenthesis */
			{
				DBA_UpdExtOpBeginD((*extOpTab)[j], NULLDYNST, finalPtfTab[i]); /* PMSTA13395-CHU-120210 j was a bad index for allPtfTab */
				finalOrderTab[finalOrderNbr] = (*extOpTab)[j];
				finalOrderNbr++;
			}
		}
	}

    /*PMSTA-32251 - Ramadevi - Opening the final session in the Order List, the block orders are not retrieved*/
    /* Saving block orders for splitSession(final + draft) case */
    if (draftPtfNbr > 0 && finalOrderNbr > 0 &&
        (GET_ENUM(pdbadynDomain, A_Domain_GenGlobalOrderEn) == (ENUM_T)DomGenGlobalOrder_Yes &&
            IS_NULLFLD(pdbadynDomain, A_Domain_BookPtfId) == FALSE))
    {
        for (j = 0; j < *extOpNbr; j++)
        {
            if (GET_ENUM((*extOpTab)[j], ExtOp_ParOpNatEn) == ParOpNat_BlockOrder)
            {
                finalOrderTab[finalOrderNbr] = (*extOpTab)[j];
                finalOrderNbr++;
            }
        }
    }

    for (i = 0; i < draftPtfNbr; i++)
    {
        for (j = 0; j < *extOpNbr; j++)
        {
            if (CMP_ID(GET_ID((*extOpTab)[j], ExtOp_PtfId), GET_ID(draftPtfTab[i], A_Ptf_Id)) == 0) /* PMSTA13395-CHU-120216 misplaced parenthesis */
            {
                draftOrderTab[draftOrderNbr] = (*extOpTab)[j];
                draftOrderNbr++;
            }
        }
    }

	if (draftPtfNbr == 0)
	{
        if (GET_DICT(pdbadynDomain, A_Domain_InitialFctDictId) == DictFct_ManageSession)
        {
            /* PMSTA-30897 - for successful portfolios, update last_rebalancing info */
            if ((copyArgPtr = ALLOC_DYNST(A_CopyArg)) != NULL)
            {
                SET_ID(copyArgPtr, A_CopyArg_FromId, GET_ID(pdbadynDomain, A_Domain_FctResultId));
                SET_NULL_ID(copyArgPtr, A_CopyArg_ToId);
                for (i = 0; i < allPtfNbr; i++)
                {
                    SET_ID(copyArgPtr, A_CopyArg_ConsPortId, GET_ID(allPtfTab[i], A_Ptf_Id));
                    ret = DBA_Update2(FctResult,
                        DBA_ROLE_SPLIT_FCTRESULT,
                        A_CopyArg,
                        copyArgPtr,
                        DBA_SET_CONN | DBA_NO_CLOSE,
                        connectNo);
                }
                FREE_DYNST(copyArgPtr, A_CopyArg); /* PMSTA-31765 - CHU - 180613 */
            }
        }

        for (i = 0; i < allPtfNbr; i++)
		{
            if (allocFlgTab[i] == TRUE) { FREE_DYNST(allPtfTab[i], A_Ptf); }
		}
		FREE(allPtfTab);
        FREE(ESLTab);
        FREE(ESETab);
		FREE(draftPtfTab);
		FREE(finalPtfTab);
		FREE(allocDraftFlgTab);
		FREE(allocFinalFlgTab);
		return(ret);
	}

	/* et si tous les Ptf sont en erreur, on fait quoi ?
	 * on libere tout, on met NULL ou z�ro partout histoire d'�viter de sauver quoi que ce soit ?
	 * La session devrait rester en Status Checked, me semble-t'il...
	 * all portfolios are rejected - avoid saving anything */
	if (finalPtfNbr == 0)
	{
        if (GET_DICT(pdbadynDomain, A_Domain_InitialFctDictId) == DictFct_ManageSession)
        {
            /* PMSTA-30897 - for failed portfolios, update last_rebalancing info */
            /* PMSTA-31765 CHU - 180613 - same here */
            if ((copyArgPtr = ALLOC_DYNST(A_CopyArg)) != NULL)
            {
                SET_ID(copyArgPtr, A_CopyArg_FromId, GET_ID(pdbadynDomain, A_Domain_FctResultId));
                SET_NULL_ID(copyArgPtr, A_CopyArg_ToId);
                for (i = 0; i < allPtfNbr; i++)
                {
                    SET_ID(copyArgPtr, A_CopyArg_ConsPortId, GET_ID(allPtfTab[i], A_Ptf_Id));
                    ret = DBA_Update2(FctResult,
                        DBA_ROLE_SPLIT_FCTRESULT,
                        A_CopyArg,
                        copyArgPtr,
                        DBA_SET_CONN | DBA_NO_CLOSE,
                        connectNo);
                }
                FREE_DYNST(copyArgPtr, A_CopyArg);
            }
        }

        for (i = 0; i < allPtfNbr; i++)
		{
            if (allocFlgTab[i] == TRUE) { FREE_DYNST(allPtfTab[i], A_Ptf); }
		}
        FREE(allPtfTab);
        FREE(ESLTab);
        FREE(ESETab);
		FREE(draftPtfTab);
		FREE(finalPtfTab);
		FREE(allocDraftFlgTab);
		FREE(allocFinalFlgTab);
		FREE_DYNST(copyArgPtr, A_CopyArg);
		ret = RET_DBA_ERR_KRANOTFOUND; /* PMSTA-14006-CHU-120402 : special retcode to tell above to keep session in Checked Status */
		return(ret);
	}

    /* ************************************** */
    /* Create new session for rejected Orders */
    /* ************************************** */
    if ((draftDomainPtr = ALLOC_DYNST(A_Domain)) == NULL)
    {
        for (i = 0; i < allPtfNbr; i++)
        {
            if (allocFlgTab[i] == TRUE) { FREE_DYNST(allPtfTab[i], A_Ptf); }
        }
        FREE(allPtfTab);
        FREE(ESLTab);
        FREE(ESETab);
        FREE(draftPtfTab);
        FREE(finalPtfTab);
        FREE(allocDraftFlgTab);
        FREE(allocFinalFlgTab);

        MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
        return(RET_MEM_ERR_ALLOC);
	}
	COPY_DYNST(draftDomainPtr, pdbadynDomain, A_Domain);
    SET_NULL_ID(draftDomainPtr, A_Domain_Id);
	SET_NULL_ID(draftDomainPtr, A_Domain_FctResultId);
	SET_NULL_CODE(draftDomainPtr, A_Domain_FctResultCd);
	/* PMSTA-13395-CHU-120417 : restore initial function dict_id, instead of PretradeCheckStrat */
	/* PMSTA-14384-CHU-120612 : initial function dict_id may not be set... */
	if (IS_NULLFLD(draftDomainPtr, A_Domain_InitialFctDictId) == FALSE &&
		GET_DICT(draftDomainPtr, A_Domain_InitialFctDictId) > (DICT_T)0 &&
        GET_DICT(draftDomainPtr, A_Domain_InitialFctDictId) != DictFct_ManageSession) /* PMSTA-31795 - CHU - 180618 */
	{
		SET_DICT(draftDomainPtr, A_Domain_FctDictId, GET_DICT(draftDomainPtr, A_Domain_InitialFctDictId));
	}
    /* PMSTA-28596  - CHU - 170926 */
    SET_ID(draftDomainPtr, A_Domain_ParentSessionId, GET_ID(pdbadynDomain, A_Domain_FctResultId));
    /* PMSTA-30897 - CHU - 180504 : For DictFct_ManageSession, session status must be set to Failed */
    SET_ENUM(draftDomainPtr, A_Domain_FctResultStatEn, FctResultStatus_Draft);
    if ((EVTGEN_ENUM)GET_ENUM(pdbadynDomain, A_Domain_EvtGenNatEn) == EvtGen_CheckSplitAndPublish ||
        (EVTGEN_ENUM)GET_ENUM(pdbadynDomain, A_Domain_EvtGenNatEn) == EvtGen_CheckCaseSplitAndPublish)
    {
        SET_ENUM(draftDomainPtr, A_Domain_FctResultStatEn, (ENUM_T)FctResultStatus_Failed);
    }

    if ((ret = DBA_NewFctResult(draftDomainPtr, &localDraftFctRes, connectNo)) != RET_SUCCEED)
	{
        for (i = 0; i < allPtfNbr; i++)
		{
            if (allocFlgTab[i] == TRUE) { FREE_DYNST(allPtfTab[i], A_Ptf); }
		}
        FREE(allPtfTab);
        FREE(ESLTab);
        FREE(ESETab);
		FREE(draftPtfTab);
		FREE(finalPtfTab);
		FREE(allocDraftFlgTab);
		FREE(allocFinalFlgTab);

		return(ret);
	}
    SET_ID(pdbadynDomain, A_Domain_ChildSessionId, GET_ID(localDraftFctRes, A_FctResult_Id)); /* PMSTA-28596  - CHU - 170926 */
	if (draftFctResPtr != NULL) /* Called from the publish_session RPC */
	{
		*draftFctResPtr = localDraftFctRes;
	}
    /* *************************************** */
    /* New session for rejected Orders created */
    /* *************************************** */

	/* PMSTA13430-CHU-120323 select cases based on draft portfolios */
    for (i = 0; i < draftPtfNbr; i++)
	{
        for (j = 0; j < (*caseMgtNbr); j++)
		{
            if (CMP_ID(GET_ID(draftPtfTab[i], A_Ptf_Id), GET_ID((*caseMgtTab)[j], A_CaseManagement_PtfId)) == 0)
			{
				if (draftCaseMgtNbr == 0)
				{
                    if ((draftCaseMgtTab = (DBA_DYNFLD_STP*)CALLOC(*caseMgtNbr, sizeof(DBA_DYNFLD_STP))) == NULL)
					{
						if (draftFctResPtr == NULL)
						{
							FREE_DYNST(localDraftFctRes, A_FctResult); /* was allocated locally */
						}
                        for (i = 0; i < allPtfNbr; i++)
						{
                            if (allocFlgTab[i] == TRUE) { FREE_DYNST(allPtfTab[i], A_Ptf); }
						}
                        FREE(allPtfTab);
                        FREE(ESLTab);
                        FREE(ESETab);
						FREE(draftPtfTab);
						FREE(finalPtfTab);
						FREE(allocDraftFlgTab);
						FREE(allocFinalFlgTab);
                        FREE_DYNST(draftDomainPtr, A_Domain);
						ret = RET_MEM_ERR_ALLOC;
                        MSG_SendMesg(ret, 0, FILEINFO);
						return(ret);
					}
				}

				COPY_DYNFLD((*caseMgtTab)[j],	A_CaseManagement,	A_CaseManagement_SessionId,
							localDraftFctRes,	A_FctResult,		A_FctResult_Id);
                /* PMSTA-28596  - CHU - 170926 */
                if (GET_DICT((*caseMgtTab)[j],  A_CaseManagement_MainEntityDictId) == FctResultCst)
                {
				    COPY_DYNFLD((*caseMgtTab)[j],	A_CaseManagement,	A_CaseManagement_MainObjId,
							    localDraftFctRes,	A_FctResult,		A_FctResult_Id);
                }

				draftCaseMgtTab[draftCaseMgtNbr] = (*caseMgtTab)[j];
				draftCaseMgtNbr++;
			}
		}

        for (j = 0; j < (ESLNbr); j++)
        {
            if (CMP_ID(GET_ID(draftPtfTab[i], A_Ptf_Id), GET_ID(ESLTab[j], ExtStratLnk_PtfId)) == 0)
            {
                COPY_DYNFLD(ESLTab[j], ExtStratLnk, ExtStratLnk_FctResultId,
                            localDraftFctRes, A_FctResult, A_FctResult_Id);
            }
        }

        for (j = 0; j < (ESENbr); j++)
        {
            if (CMP_ID(GET_ID(draftPtfTab[i], A_Ptf_Id), GET_ID(ESETab[j], ExtStratElt_PtfId)) == 0)
            {
                COPY_DYNFLD(ESETab[j], ExtStratElt, ExtStratElt_FctResultId,
                            localDraftFctRes, A_FctResult, A_FctResult_Id);
            }
        }
    }

    /* Update related ext_operations with new function result id */
    for (i = 0; i<draftOrderNbr; i++)
    {
        COPY_DYNFLD(draftOrderTab[i], ExtOp, ExtOp_FctResultId, localDraftFctRes, A_FctResult, A_FctResult_Id);
	}

	/* Update original Case number and array */
	if (draftCaseMgtNbr > 0)
	{
        for (i = 0; i < *caseMgtNbr; i++)
		{
			FLAG_T foundFlag = FALSE;
            for (j = 0; j < draftCaseMgtNbr; j++)
			{
				if (CMP_ID(GET_ID((*caseMgtTab)[i], A_CaseManagement_Id),
					GET_ID((draftCaseMgtTab[j]), A_CaseManagement_Id)) == 0)
				{
					foundFlag = TRUE;
					break;
				}
			}

            if (foundFlag == FALSE)
			{
				if (finalCaseMgtNbr == 0)
				{
                    if ((finalCaseMgtTab = (DBA_DYNFLD_STP*)CALLOC(*caseMgtNbr, sizeof(DBA_DYNFLD_STP))) == NULL)
					{
						if (draftFctResPtr == NULL)
						{
							FREE_DYNST(localDraftFctRes, A_FctResult); /* was allocated locally */
						}
                        for (i = 0; i < allPtfNbr; i++)
						{
                            if (allocFlgTab[i] == TRUE) { FREE_DYNST(allPtfTab[i], A_Ptf); }
						}
                        FREE(allPtfTab);
                        FREE(ESLTab);
                        FREE(ESETab);
						FREE(draftPtfTab);
						FREE(finalPtfTab);
						FREE(allocDraftFlgTab);
						FREE(allocFinalFlgTab);
                        FREE_DYNST(draftDomainPtr, A_Domain);
                        FREE(draftCaseMgtTab);
						ret = RET_MEM_ERR_ALLOC;
                        MSG_SendMesg(ret, 0, FILEINFO);
						return(ret);
					}
				}
				finalCaseMgtTab[finalCaseMgtNbr] = (*caseMgtTab)[i];
				finalCaseMgtNbr++;
			}
		}
	}

	/* If all went well, update original Case number and array */
	if (finalCaseMgtNbr > 0)
	{
		FREE(*caseMgtTab);
		*caseMgtTab = finalCaseMgtTab;
		*caseMgtNbr = finalCaseMgtNbr;
	}
	else /* all Cases where transfered in new session */
	{
		FREE(finalCaseMgtTab);
		FREE(*caseMgtTab);
		*caseMgtNbr = 0;
	}

	/* If all went well, update original ExtOp number and array */
	if (finalOrderNbr > 0)
	{
		FREE(*extOpTab);
		*extOpTab = finalOrderTab;
		*extOpNbr = finalOrderNbr;
	}
	else /* all orders where rejected and transfered in new session */
	{
		FREE(finalOrderTab);
		FREE(*extOpTab);
		*extOpNbr = 0;
	}

    /* Update Records with new function_result into database */
    if ((copyArgPtr = ALLOC_DYNST(A_CopyArg)) == NULL)
	{
        for (i = 0; i < allPtfNbr; i++)
		{
            if (allocFlgTab[i] == TRUE) { FREE_DYNST(allPtfTab[i], A_Ptf); }
		}
        FREE(allPtfTab);
        FREE(ESLTab);
        FREE(ESETab);
		FREE(draftPtfTab);
		FREE(finalPtfTab);
		FREE(allocDraftFlgTab);
		FREE(allocFinalFlgTab);
        FREE_DYNST(draftDomainPtr, A_Domain);
        FREE(draftOrderTab);
        FREE(draftCaseMgtTab);
        FREE(finalOrderTab);
        FREE(finalCaseMgtTab);
        ret = RET_MEM_ERR_ALLOC;
        MSG_SendMesg(ret, 0, FILEINFO);
		return(ret);
	}

    /* PMSTA-30897 - transfer data to new session for portfolios in error + update last_rebalancing info */
    SET_ID(copyArgPtr, A_CopyArg_FromId, GET_ID(pdbadynDomain, A_Domain_FctResultId));
    SET_ID(copyArgPtr, A_CopyArg_ToId, GET_ID(pdbadynDomain, A_Domain_ChildSessionId));
    for (i = 0; i < draftPtfNbr; i++)
    {
        SET_ID(copyArgPtr, A_CopyArg_ConsPortId, GET_ID(draftPtfTab[i], A_Ptf_Id));
        ret = DBA_Update2(FctResult,
            DBA_ROLE_SPLIT_FCTRESULT,
            A_CopyArg,
            copyArgPtr,
            DBA_SET_CONN | DBA_NO_CLOSE,
            connectNo);
    }

    /* PMSTA-30897 - for succesful portfolios, update last_rebalancing info */
    SET_NULL_ID(copyArgPtr, A_CopyArg_ToId);
    for (i = 0; i < finalPtfNbr; i++)
    {
        SET_ID(copyArgPtr, A_CopyArg_ConsPortId, GET_ID(finalPtfTab[i], A_Ptf_Id));
        ret = DBA_Update2(FctResult,
            DBA_ROLE_SPLIT_FCTRESULT,
            A_CopyArg,
            copyArgPtr,
            DBA_SET_CONN | DBA_NO_CLOSE,
            connectNo);
    }


    if (draftFctResPtr == NULL)
    {
        FREE_DYNST(localDraftFctRes, A_FctResult); /* was allocated locally */
    }
    for (i = 0; i < allPtfNbr; i++)
    {
        if (allocFlgTab[i] == TRUE) { FREE_DYNST(allPtfTab[i], A_Ptf); }
    }
    FREE(allPtfTab);
    FREE(ESLTab);
    FREE(ESETab);
    FREE(draftPtfTab);
    FREE(finalPtfTab);
    FREE(allocDraftFlgTab);
    FREE(allocFinalFlgTab);
    FREE_DYNST(draftDomainPtr, A_Domain);
    FREE_DYNST(copyArgPtr, A_CopyArg);
    FREE(draftOrderTab);
    FREE(draftCaseMgtTab);
    return(ret);
}


/************************************************************************
**
**  Function    :   OPE_GenerateExtOpCodeForSaveDraft.
**
**  Description :   Generate code for ext_operation records if asked
**
**  Arguments   :   EXTOP_ACTION_ENUM		action
**					DICT_T                  dictidFunction
**                  DICT_T                  dictidScreen
**                  DBA_DYNFLD_STP          pdbadynOrder
**					DBA_DYNFLD_STP          pdbadynDomain
**                  DBA_HIER_HEAD_STP       phier
**
**  Return      :   RET_CODE
**
**  Creation    :   PMSTA-25183 - CHU - 161109
**
**  Modif.      :
**
*************************************************************************/
RET_CODE OPE_GenerateExtOpCodeForSaveDraft(DICT_T               fctDictId,
                                           DBA_ACCESS_STP       extOpAccessTab,
                                           int                  extOpAccessNbr,
                                           DBA_DYNFLD_STP       domainPtr)
{
    RET_CODE    retCode = RET_SUCCEED;

    if (!DBA_GetOrderCodeInSessionSysParam()) /* returns FALSE if DV must be evaluated */
    {
        FLAG_T      *pflag = NULL;
        int         i = 0;

        if ((pflag = (FLAG_T *)CALLOC(GET_FLD_NBR(ExtOp), sizeof(FLAG_T))) == NULL)
        {
            return(RET_MEM_ERR_ALLOC);
        }

        memset(pflag, (int)TRUE, GET_FLD_NBR(ExtOp)*sizeof(FLAG_T));
        pflag[ExtOp_Cd] = FALSE; /*  */

        for (i = 0; i < extOpAccessNbr; i++)
        {
            if (extOpAccessTab[i].data != NULL &&
                IS_NULLFLD(extOpAccessTab[i].data, ExtOp_Cd) == TRUE)
            {
                SCPT_ComputeScreenDV(EOp,
                    fctDictId,
                    pflag,
                    NULL,              /* HFI-PMSTA-25327-171023  Dedicated flag tab for filter    */
                    extOpAccessTab[i].data,
                    NULL,
                    domainPtr,
                    NULLDYNST,   /* PMSTA13283 - DDV - 120117 */
                    TRUE,				/* analyse type */
                    TRUE,				/* guiFlag */
                    EvalType_DefVal,   /* FPL-REF9507-030929  Only Def val    */
                    0,					/* attribIdx */
                    NULL,              /* connectNo */
                    NULL,				/* filterTab */
                    NULL,	            /* hierHead */
                    0,
                    DictScreen,        /*  FIH-REF9789-040209  */
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NullEntity,
                    FALSE,
                    FALSE,
                    0);        /*  FPL-REF9215-030811  Flag Impact */
            }
        }
        FREE(pflag);
    }
    return retCode;
}

/************************************************************************
**
**  Function    :   OPE_GenerateOrderCheckForSaveDraft.
**
**  Description :   Generate order_code_e for ext_operation records
**
**  Arguments   :  	DICT_T                  fctDictId
**                  DBA_ACCESS_STP          extOpAccessTab
**					int                     extOpAccessNbr
**                  DBA_DYNFLD_STP          domainPtr
**
**  Return      :   RET_CODE
**
**  Creation    :   PMSTA-38901 - sanand - 25022020
**
**  Modif.      :
**
*************************************************************************/
RET_CODE OPE_GenerateOrderCheckForSaveDraft(DICT_T               fctDictId,
                                           DBA_ACCESS_STP       extOpAccessTab,
                                           int                  extOpAccessNbr,
                                           DBA_DYNFLD_STP       domainPtr)
{
    RET_CODE    retCode = RET_SUCCEED;

    FLAG_T      *pflag = NULL;
    int         i = 0;

    if ((pflag = (FLAG_T *)CALLOC(GET_FLD_NBR(ExtOp), sizeof(FLAG_T))) == NULL)
    {
        return(RET_MEM_ERR_ALLOC);
    }

    memset(pflag, (int)TRUE, GET_FLD_NBR(ExtOp)*sizeof(FLAG_T));
    pflag[ExtOp_OrderCheckEn] = FALSE;

    for (i = 0; i < extOpAccessNbr; i++)
    {
        if (extOpAccessTab[i].data != NULL &&
            IS_NULLFLD(extOpAccessTab[i].data, ExtOp_OrderCheckEn) == TRUE )
        {
            SCPT_ComputeScreenDV(EOp,
                fctDictId,
                pflag,
                NULL,              /* Dedicated flag tab for filter    */
                extOpAccessTab[i].data,
                NULL,
                domainPtr,
                NULLDYNST,
                TRUE,				/* analyse type */
                TRUE,				/* guiFlag */
                EvalType_DefVal,   /*  Only Def val    */
                0,					/* attribIdx */
                NULL,              /* connectNo */
                NULL,				/* filterTab */
                NULL,	            /* hierHead */
                0,
                DictScreen,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NullEntity,
                FALSE,
                FALSE,
                0);        /*   Flag Impact */
        }
    }
    FREE(pflag);

    return retCode;
}


/************************************************************************
**
**  Function    :   publishTaxLotPicking.
**
**  Description :   Save simulated_tax_lot_picking to tax_lot_picking.
**
**  Arguments   :   extOpAccessTab - ext op tab
**                  extOpAccessNbr - ext op number
**                  dbiConn        - DBI connection
**
**  Return      :   RET_CODE.
**
**  Creation    :   PMSTA-35339 - 010419 - vkumar
**
**  Modif.      :   PMSTA-36008 - 230519 - vkumar
**
*************************************************************************/
RET_CODE publishTaxLotPicking(DBA_ACCESS_STP           extOpAccessTab,
                              int                      extOpAccessNbr,
                              DbiConnection &          dbiConn)
{
    RET_CODE          ret              = RET_SUCCEED;
    MemoryPool        mp;
    DBA_DYNFLD_STP    getArg           = mp.allocDynst(FILEINFO, Get_Arg);
    DBA_DYNFLD_STP  * taxLotPickingTab = nullptr;
    int               taxLotPickingNbr = 0;

    if (IS_NULLFLD(extOpAccessTab[0].data, ExtOp_FctResultId) == FALSE)
    {
        SET_ID(getArg, Get_Arg_Id, GET_ID(extOpAccessTab[0].data, ExtOp_FctResultId));

        /* get simulated_tax_lot_picking as tax_lot_picking records for function result */
        if((ret = DBA_Select2(SimulatedTaxLotPicking, UNUSED, Get_Arg, getArg, A_SimulatedTaxLotPicking, &taxLotPickingTab,
                                       DBA_SET_CONN | DBA_NO_CLOSE, UNUSED, &taxLotPickingNbr, dbiConn, UNUSED)) != RET_SUCCEED)
        {
            return ret;
        }

        for (int idx = 0; idx < taxLotPickingNbr; idx++)
        {
            for (int opTabIdx = 0; opTabIdx < extOpAccessNbr; opTabIdx++)
            {
                /* update DB ID of order to operation ID of tax_lot_picking */
                if (CMP_ID(GET_ID(taxLotPickingTab[idx], A_TaxLotPicking_OperationId),
                           GET_ID(extOpAccessTab[opTabIdx].data, ExtOp_Id)) == 0)
                {
                    SET_ID(taxLotPickingTab[idx], A_TaxLotPicking_OperationId, GET_ID(extOpAccessTab[opTabIdx].data, ExtOp_DbId));
                    break;
                }
            }

            if((ret = DBA_Insert2(TaxLotPicking, UNUSED, A_TaxLotPicking, taxLotPickingTab[idx],
                                        DBA_SET_CONN | DBA_NO_CLOSE, dbiConn, UNUSED)) != RET_SUCCEED)
            {
                break;
            }
        }
    }

    return ret;
}

/* Moved from dbapos.c - PMSTA-40170 - 130520 - vkumar */
/************************************************************************
*   Function             : DBA_LoadPosDropTempTables()
*
*   Description          : Send a Drop request to the server. Drop tempo-
*                          rary tables created for a financial function.
*
*   Arguments            : connectNo  : a connection number in the connection
*                                       list
*                          fctId      : dict_id corresponding to a financial
*                                       function (Valuation, etc...)
*
*   Functions call       :
*
*   Return               : TRUE if ok
*                          FALSE if problem
*
*   Creation date        : Oct.  94 - PEC
*   Last Modification    : Nov.  94 - PEC - Added @@spid in the language request
*                          12.11.96 - PEC - Ref.: DVP249
*                          09.12.96 - RAK - Ref.: DVP261
*                          24.03.97 - PEC - Ref.: DVP400 - Handling of multi-transactions
*                          REF5010 - SSO - 000828
*
*************************************************************************/
int DBA_LoadPosDropTempTables(DbiConnection& dbiConn, DICT_FCT_ENUM fctDictId)
{
    int retCode = RET_SUCCEED;

    /* Old code ***********
    strcpy(request, "drop table #dom_port "
                    "drop table #dom_position "
                    "drop table #dom_instr ");
    **********/

    /* REF3668 - SSO - 990903 : do not truncate if no table...  */
    if ((dbiConn.m_tempTablesMask & DOM_POSITION_INSTR_PORT) == DOM_POSITION_INSTR_PORT)
    {
        /* PMSTA-18593 - LJE - 151103 */
        if ((retCode = DBA_CreateTempTables(dbiConn, DOM_POSITION_INSTR_PORT)) != RET_SUCCEED)
            return(FALSE);
    }

    if ((dbiConn.m_tempTablesMask & TCT_VECTOR_ID) == TCT_VECTOR_ID)
    {
        if ((retCode = DBA_CreateTempTables(dbiConn, TCT_VECTOR_ID)) != RET_SUCCEED)
            return(FALSE);
    }

    if (fctDictId == DictFct_SynthAdmin || fctDictId == DictFct_Return)
    {
        if ((retCode = DBA_CreateTempTables(dbiConn, PORT_SYNTH)) != RET_SUCCEED)
            return(FALSE);
    }


    /* REF4306 - DDV - 000223 */
    if ((retCode = DBA_CreateTempTables(dbiConn, DOM_THIRD_CURR | DOM_LISTCOMPO)) != RET_SUCCEED)
        return(FALSE);

    return(TRUE);
}

/* Moved from servfin.c - PMSTA-40170 - 130520 - vkumar */
/************************************************************************
*   Function             : SERV_ListMgm()
*
*   Description          :
*
*   Arguments            : fct		    : mandatory	(see in serv.h)
*                          entDictId    : mandatory
*
*   Functions call       :
*
*   Return               :
*************************************************************************/
RET_CODE SERV_ListMgm(SERV_LISTMGMFCT_ENUM  fct,
                      DICT_T                entDictId,
                      ID_T                  listId,
                      char                 *scptDefParam,
                      DbiConnection        &dbiConn,
                      DBA_DYNFLD_STP        recordStp)
{
    DBI_INT        status = 0;
    DBA_DYNFLD_STP aList = ALLOC_DYNST(A_List);
    OBJECT_ENUM	   entObjectEnum;
    char	       buffer[1024];
    char          *scptDef = NULL;
    RET_CODE	   ret = RET_SUCCEED;/* REF3751 - SSO - 990623 more ret code tests */

    if (listId > 0)
    {
        SET_ID(aList, A_List_Id, listId);
        DBA_Get2(List, DBA_ROLE_NO_OPTI, A_List, aList, A_List, &aList, UNUSED, UNUSED, UNUSED); /* PMSTA-30476 - DDV - Disable optimisation to avoid several rebuild in the same RPC */
        DBA_CheckConstList(listId, aList, &status);
    }
    else /* REF0014 - DDV - 000330 - Quick Search in domain, no list in db rebuild it each time */
    {
        status = CHK_LIST_NON_PERIODIC;
        scptDef = scptDefParam;
    }

    DBA_GetObjectEnum(entDictId, &entObjectEnum);

    switch (fct)
    {
    case ListMgmFct_LoadPos:
    case ListMgmFct_LoadEvtGenInstr: /* REF125 - XDI - 971217 */

        if (listId <= 0 && (scptDef == NULL || scptDef[0] == END_OF_STRING))
            MSG_RETURN(RET_GEN_ERR_INVARG);

        /***** PROCESS ONLY FOR CONSTRAINT LIST *****/
        switch (status)
        {
        case CHK_LIST_NOT_CONST:
            /***** NOTHING TO DO *****/
            break;

        case CHK_LIST_MUST_BE_BUILT:
        case CHK_LIST_HIER_MUST_BE_BUILT: /* REF125 - XDI - 971218 - Add */
            /***** BUILD ENUM LIST FROM CONSTRAINT SCRIPT *****/
        {
            SetServerUserToOnGuard setServerUserToOn;          /* PMSTA-29656 - DDV - 180110 - This class set ServerUser to On and automatically set to Off when leaving the function */ /* PMSTA-33980 - LJE - 181206 */
            ret = SCPT_EvalCstList(CSTLIST_REBUILD_LIST_COMPO,
                listId,
                NULLSTR,
                entObjectEnum,
                0,
                NULL,
                NO_VALUE, /* REF3751 - SSO - 990623: 0 -> NO_VALUE */
                NULL,
                NULL,
                NULL,
                NULL,
                0,
                0); /* PMSTA07422 - DDV - 090520 - Add dataProfId parameter for sel_export_data */

/* REF3962 - SSO - 990910 */
            if (ret != RET_SUCCEED)
            {
                FREE_DYNST(aList, A_List);
                return(ret);
            }
        }
        /* Now insert in temp table */

        case CHK_LIST_ALREADY_BUILT:
            switch (GET_OBJECT_CST(entObjectEnum)) /* REF8844 - LJE - 030416 */
            {
            case PtfCst:
                /***** BUILD dom_port FROM  list_compo & portfolio *****/

                sprintf(buffer, "delete from #dom_port ");	/* DVP568 - 970827 - DED */
                ret = DBA_SqlExec(buffer, dbiConn);

                /* PMSTA-20159 - TEB - 150624 */
                if (RET_SUCCEED == ret)
                {
                    sprintf(buffer,
                        "insert into #dom_port (id,port_pos_set_id,hier_port_id,fusion_date_rule_e) "	/*REF10722-BRO-060922*/
                        "select lc.object_id, 0, null, 0 " /* MIGR R4.00 STEP6 - LJE - 020816 */
                        "from %s p, %s lc " /* PMSTA-32753 - DLA - 180903 */
                        "where lc.list_id=%" szFormatId" and p.id = lc.object_id and lc.validity_d is null ", /* DLA - PMSTA08801 - 100210 */
                        SCPT_GetViewName(Ptf, false).c_str(),  /* PMSTA-26250  -DDV - 170523 */ /* PMSTA-32753 - DLA - 180903 */
                        SCPT_GetViewName(ListCompo, false).c_str(), /* PMSTA-26250  -DDV - 170523 */    /* PMSTA-32753 - DLA - 180903 */
                        listId);     /* DVP568 - 970827 - DED */


                    sprintf(buffer + strlen(buffer), " and #MAIN_DLM_CHECK(p, portfolio)");

                    ret = DBA_SqlExec(buffer, dbiConn);
                }

                break;

            case InstrCst:
                /***** INSERT dom_instr FROM dom_position, list_compo & instrument *****/

                /* REF125 - XDI - 971217 */
                /* PMSTA-20159 - TEB - 150624 */
                sprintf(buffer, "delete from #dom_instr ");
                ret = DBA_SqlExec(buffer, dbiConn);

                if (RET_SUCCEED == ret)
                {
                    if (fct == ListMgmFct_LoadEvtGenInstr)
                    {
                        sprintf(buffer,
                            "insert into #dom_instr (id) select distinct lc.object_id "
                            "from %s lc "   /* PMSTA-32753 - DLA - 180903 */
                            "where lc.list_id=%" szFormatId" and lc.validity_d is null ", /* DLA - PMSTA08801 - 100210 */
                            SCPT_GetViewName(ListCompo, false).c_str(), listId); /* PMSTA-26250  -DDV - 170523 */   /* PMSTA-32753 - DLA - 180903 */
                        ret = DBA_SqlExec(buffer, dbiConn);
                    }
                    else
                    {
                        sprintf(buffer,
                            "insert into #dom_instr (id) select distinct lc.object_id "
                            "from %s i, %s lc , #dom_position dp "  /* PMSTA-32753 - DLA - 180903 */
                            "where lc.list_id=%" szFormatId" and lc.object_id = dp.instr_id " /* DLA - PMSTA08801 - 100210 */
                            "and i.id = lc.object_id and lc.validity_d is null ",
                            SCPT_GetViewName(Instr, false).c_str(),  /* PMSTA-26250  -DDV - 170523 */   /* PMSTA-32753 - DLA - 180903 */
                            SCPT_GetViewName(ListCompo, false).c_str(),  /* PMSTA-26250  -DDV - 170523 */   /* PMSTA-32753 - DLA - 180903 */
                            listId);
                        ret = DBA_SqlExec(buffer, dbiConn);
                    }
                }

                break;

            case CurrCst: /* REF4306 - DDV - 000301 */
                /***** BUILD dom_curr FROM  list_compo *****/
                /* PMSTA-20159 - TEB - 150624 */
                sprintf(buffer, "delete from #dom_curr ");
                ret = DBA_SqlExec(buffer, dbiConn);
                if (RET_SUCCEED == ret)
                {
                    sprintf(buffer,
                        "insert into #dom_curr (id) select lc.object_id "
                        "from %s lc "   /* PMSTA-32753 - DLA - 180903 */
                        "where lc.list_id=%" szFormatId" and lc.validity_d is null ", /* DLA - PMSTA08801 - 100210 */
                        SCPT_GetViewName(ListCompo, false).c_str(),  /* PMSTA-26250  -DDV - 170523 */   /* PMSTA-32753 - DLA - 180903 */
                        listId);    /* DVP568 - 970827 - DED */

                    ret = DBA_SqlExec(buffer, dbiConn);
                }
                break;

            case ThirdCst: /* REF4306 - DDV - 000301 */
                /***** BUILD dom_curr FROM  list_compo *****/
                /* PMSTA-20159 - TEB - 150624 */
                sprintf(buffer, "delete from #dom_third ");
                ret = DBA_SqlExec(buffer, dbiConn);
                if (RET_SUCCEED == ret)
                {
                    sprintf(buffer,
                        "insert into #dom_third (id) select lc.object_id "
                        "from %s lc "   /* PMSTA-32753 - DLA - 180903 */
                        "where lc.list_id=%" szFormatId" and lc.validity_d is null ", /* DLA - PMSTA08801 - 100210 */
                        SCPT_GetViewName(ListCompo, false).c_str(), /* PMSTA-26250  -DDV - 170523 */    /* PMSTA-32753 - DLA - 180903 */
                        listId);    /* DVP568 - 970827 - DED */

                    ret = DBA_SqlExec(buffer, dbiConn);
                }
                break;

                /* REF7758 - LJE - 020919 */
            case StratCst:
                /***** BUILD dom_strat FROM  list_compo & strategy *****/
                /* PMSTA-20159 - TEB - 150624 */
                sprintf(buffer, "delete from #dom_strat ");

                ret = DBA_SqlExec(buffer, dbiConn);
                if (RET_SUCCEED == ret)
                {
                    sprintf(buffer,
                        "insert into #dom_strat (id,code,nature_e) select lc.object_id, s.code, s.nature_e "
                        "from %s s, %s lc "
                        "where lc.list_id=%" szFormatId" and s.id = lc.object_id and lc.validity_d is null ", /* DLA - PMSTA08801 - 100210 */
                        SCPT_GetViewName(Strat, false).c_str(),  /* PMSTA-26250  -DDV - 170523 */   /* PMSTA-32753 - DLA - 180903 */
                        SCPT_GetViewName(ListCompo, false).c_str(), /* PMSTA-26250  -DDV - 170523 */    /* PMSTA-32753 - DLA - 180903 */
                        listId);

                    ret = DBA_SqlExec(buffer, dbiConn);
                }
                break;

            }
            break;

        case CHK_LIST_NON_PERIODIC:
        case CHK_LIST_HIER_NON_PERIODIC: /* REF125 - XDI - 971218 - Moved */
            /***** BUILD ENUM LIST IN dom_instr OR dom_port FROM CONSTRAINT SCRIPT *****/
            switch (GET_OBJECT_CST(entObjectEnum)) /* REF8844 - LJE - 030416 */
            {
                case PtfCst:
                    ret = SCPT_EvalCstList(CSTLIST_BUILD_DOM_PTF,
                                           listId,
                                           scptDef,
                                           entObjectEnum,
                                           0,
                                           NULL,
                                           dbiConn.getId(),
                                           NULL,
                                           NULL,
                                           NULL,
                                           NULL,
                                           0,
                                           0); /* PMSTA07422 - DDV - 090520 - Add dataProfId parameter for sel_export_data */
                    break;

                case InstrCst:
                    ret = SCPT_EvalCstList(CSTLIST_BUILD_DOM_INSTR,
                                           listId,
                                           scptDef,
                                           entObjectEnum,
                                           0,
                                           NULL,
                                           dbiConn.getId(),
                                           NULL,
                                           NULL,
                                           NULL,
                                           NULL,
                                           0,
                                           0); /* PMSTA07422 - DDV - 090520 - Add dataProfId parameter for sel_export_data */
                    break;
                case CurrCst: /* REF4306 - DDV - 000301 */
                    ret = SCPT_EvalCstList(CSTLIST_BUILD_DOM_CURR,
                                           listId,
                                           scptDef,
                                           entObjectEnum,
                                           0,
                                           NULL,
                                           dbiConn.getId(),
                                           NULL,
                                           NULL,
                                           NULL,
                                           NULL,
                                           0,
                                           0); /* PMSTA07422 - DDV - 090520 - Add dataProfId parameter for sel_export_data */
                    break;
                case ThirdCst: /* REF4306 - DDV - 000301 */
                    ret = SCPT_EvalCstList(CSTLIST_BUILD_DOM_THIRD,
                                           listId,
                                           scptDef,
                                           entObjectEnum,
                                           0,
                                           NULL,
                                           dbiConn.getId(),
                                           NULL,
                                           NULL,
                                           NULL,
                                           NULL,
                                           0,
                                           0); /* PMSTA07422 - DDV - 090520 - Add dataProfId parameter for sel_export_data */
                    break;
                case StratCst: /* REF7758 - LJE - 020919 */
                    ret = SCPT_EvalCstList(CSTLIST_BUILD_DOM_STRAT,
                                           listId,
                                           scptDef,
                                           entObjectEnum,
                                           0,
                                           NULL,
                                           dbiConn.getId(),
                                           NULL,
                                           NULL,
                                           NULL,
                                           NULL,
                                           0,
                                           0); /* PMSTA07422 - DDV - 090520 - Add dataProfId parameter for sel_export_data */
                    break;
                case ChangeSetCst: /* PMSTA_262520 - DDV - 170503 */
                    ret = SCPT_EvalCstList(CSTLIST_BUILD_VI_CHANGESET,
                                           listId,
                                           scptDef,
                                           entObjectEnum,
                                           0,
                                           NULL,
                                           dbiConn.getId(),
                                           NULL,
                                           NULL,
                                           NULL,
                                           NULL,
                                           0,
                                           0);
                    break;
            }
            break;
        }
        break;

    case ListMgmFct_LoadStratLnk:
        if (listId <= 0 && scptDef == NULL)  /* REF4611 - RAK - 000503 */
            MSG_RETURN(RET_GEN_ERR_INVARG);

        /***** PROCESS ONLY FOR CONSTRAINT LIST *****/
        switch (status)
        {
        case CHK_LIST_NOT_CONST:
            /***** NOTHING TO DO *****/
            break;

        case CHK_LIST_MUST_BE_BUILT:
            /***** BUILD ENUM LIST FROM CONSTRAINT SCRIPT *****/
        {
            SetServerUserToOnGuard setServerUserToOn;          /* PMSTA-29656 - DDV - 180110 - This class set ServerUser to On and automatically set to Off when leaving the function */ /* PMSTA-33980 - LJE - 181206 */
            ret = SCPT_EvalCstList(CSTLIST_REBUILD_LIST_COMPO,
                                   listId,
                                   NULLSTR,
                                   entObjectEnum,
                                   0,
                                   NULL,
                                   dbiConn.getId(),
                                   NULL,
                                   NULL,
                                   NULL,
                                   NULL,
                                   0,
                                   0); /* PMSTA07422 - DDV - 090520 - Add dataProfId parameter for sel_export_data */

/* REF3962 - SSO - 990910 */
            if (ret != RET_SUCCEED)
            {
                FREE_DYNST(aList, A_List);
                return(ret);
            }
        }
        /* Now insert in temp table */

        case CHK_LIST_ALREADY_BUILT:
            switch (GET_OBJECT_CST(entObjectEnum)) /* REF8844 - LJE - 030416 */
            {
            case PtfCst:
                /***** BUILD dom_port_strat FROM  list_compo & portfolio *****/
                /* PMSTA-20159 - TEB - 150624 */
                sprintf(buffer, "delete from #dom_port ");
                ret = DBA_SqlExec(buffer, dbiConn); /* REF3962 - SSO - 990910 */

                if (RET_SUCCEED == ret)
                {
                    if(recordStp != nullptr && GET_FLAG(recordStp,A_SearchLnk_LoadDimPortHistFlg) == TRUE)  /* WEALTH-7310 - JBC - 20240601 */
                    {   
                        std::string      begDateExp = "null";
                        std::string      endDateExp = "null";

                        if(IS_NULLFLD(recordStp,A_SearchLnk_BeginDate) == false)
                        {
                            char begDate[DATE_SQL_STRING_SIZE];
                            DATE_DateConvToddmmyyyy(GET_DATE(recordStp,A_SearchLnk_BeginDate),begDate);
                            begDateExp = SYS_Stringer("#TO_DATE('",begDate,"')");
                        }

                        if(IS_NULLFLD(recordStp,A_SearchLnk_EndDate) == false)
                        {
                            char endDate[DATE_SQL_STRING_SIZE];
                            DATE_DateConvToddmmyyyy(GET_DATE(recordStp,A_SearchLnk_EndDate),endDate);  
                            endDateExp = SYS_Stringer("#TO_DATE('",endDate,"')");
                        }

                         sprintf(buffer,
                            "insert into #dom_port (id,port_pos_set_id,hier_port_id,fusion_date_rule_e,begin_d,end_d) " /*REF10722-BRO-060922*/
                            "select lc.object_id, 0,null, 0, lc.validity_d,  " /* MIGR R4.00 STEP6 - LJE - 020816 */
                            " #ISNULL((select min(lc2.validity_d) from %s lc2 where lc.list_id = lc2.list_id and lc2.validity_d is not null and lc.validity_d < lc2.validity_d),#MAGIC_END_DATE) "  /* WEALTH-7310 - JBC - 20240601 */
                            "from %s p, %s lc " 
                            "where lc.list_id=%" szFormatId" and p.id = lc.object_id and lc.validity_d is not null  " /* DLA - PMSTA08801 - 100210 */
                            "and lc.validity_d >= #ISNULL((select max(lc3.validity_d) from %s lc3 where lc3.list_id = %" szFormatId
                            "                              and lc3.validity_d is not NULL and lc3.validity_d <= (%s)),(%s)) " /* WEALTH-7310 - JBC - 20240601 */
                            "and lc.validity_d < #ISNULL((%s),#MAGIC_END_DATE) ", /* WEALTH-7310 - JBC - 20240601 */
                            SCPT_GetViewName(ListCompo, false).c_str(),
                            SCPT_GetViewName(Ptf, false).c_str(),  /* PMSTA-26250  -DDV - 170523 */ /* PMSTA-32753 - DLA - 180903 */
                            SCPT_GetViewName(ListCompo, false).c_str(), /* PMSTA-26250  -DDV - 170523 */    /* PMSTA-32753 - DLA - 180903 */
                            listId,
                            SCPT_GetViewName(ListCompo, false).c_str(),
                            listId,
                            begDateExp.c_str(),
                            begDateExp.c_str(),
                            endDateExp.c_str());
                    }
                    else
                    {
                        sprintf(buffer,
                            "insert into #dom_port (id,port_pos_set_id,hier_port_id,fusion_date_rule_e) " /*REF10722-BRO-060922*/
                            "select lc.object_id, 0,null, 0 " /* MIGR R4.00 STEP6 - LJE - 020816 */
                            "from %s p, %s lc "
                            "where lc.list_id=%" szFormatId" and p.id = lc.object_id and lc.validity_d is null ", /* DLA - PMSTA08801 - 100210 */
                            SCPT_GetViewName(Ptf, false).c_str(),  /* PMSTA-26250  -DDV - 170523 */ /* PMSTA-32753 - DLA - 180903 */
                            SCPT_GetViewName(ListCompo, false).c_str(), /* PMSTA-26250  -DDV - 170523 */    /* PMSTA-32753 - DLA - 180903 */
                            listId);
                    }

                    sprintf(buffer + strlen(buffer), " and #MAIN_DLM_CHECK(p, portfolio)");

                    ret = DBA_SqlExec(buffer, dbiConn); /* REF3962 - SSO - 990910 */
                }
                break;

            case StratCst:
                /***** INSERT dom_strat FROM list_compo & strategy *****/
                /* REF7420 - RAK - 020604 add (id,code,nature) */
                /* PMSTA-20159 - TEB - 150624 */
                sprintf(buffer, "delete from #dom_strat ");
                ret = DBA_SqlExec(buffer, dbiConn);

                if (RET_SUCCEED == ret)
                {
                    sprintf(buffer,
                        "insert into #dom_strat (id,code,nature_e) select lc.object_id, s.code, s.nature_e "
                        "from %s s, %s lc "
                        "where lc.list_id=%" szFormatId" and s.id = lc.object_id and lc.validity_d is null ", /* DLA - PMSTA08801 - 100210 */
                        SCPT_GetViewName(Strat, false).c_str(),  /* PMSTA-26250  -DDV - 170523 */   /* PMSTA-32753 - DLA - 180903 */
                        SCPT_GetViewName(ListCompo, false).c_str(), /* PMSTA-26250  -DDV - 170523 */    /* PMSTA-32753 - DLA - 180903 */
                        listId);

                    ret = DBA_SqlExec(buffer, dbiConn);
                }
                break;
            }
            break;

        case CHK_LIST_NON_PERIODIC:
            /***** BUILD ENUM LIST IN dom_instr OR dom_port FROM CONSTRAINT SCRIPT *****/
            switch (GET_OBJECT_CST(entObjectEnum)) /* REF8844 - LJE - 030416 */
            {
                case PtfCst:
                    ret = SCPT_EvalCstList(CSTLIST_BUILD_DOM_PTF_STRAT,
                                           listId,
                                           scptDef, /* REF4611 - RAK - 000503 */
                                           entObjectEnum,
                                           0,
                                           NULL,
                                           dbiConn.getId(),
                                           NULL,
                                           NULL,
                                           NULL,
                                           NULL,
                                           0,
                                           0); /* PMSTA07422 - DDV - 090520 - Add dataProfId parameter for sel_export_data */
                    break;

                case StratCst:
                    ret = SCPT_EvalCstList(CSTLIST_BUILD_DOM_STRAT,
                                           listId,
                                           scptDef, /* REF7758 - DDV - 0201105 */
                                           entObjectEnum,
                                           0,
                                           NULL,
                                           dbiConn.getId(),
                                           NULL,
                                           NULL,
                                           NULL,
                                           NULL,
                                           0,
                                           0); /* PMSTA07422 - DDV - 090520 - Add dataProfId parameter for sel_export_data */
                    break;
            }
            break;
        }
        break;

    case ListMgmFct_Build:
        break;

    case ListMgmFct_SelId:
        break;

    case ListMgmFct_SelShort:
        break;

    case ListMgmFct_SelAll:
        break;

        /* PMSTA-34444 - LJE - 190205 */
    case ListMgmFct_ObjectList:
        ret = SCPT_EvalCstList(CSTLIST_BUILD_OBJECT_LIST,
                               0,
                               scptDef,
                               entObjectEnum,
                               GET_ID(recordStp, Get_Arg_Id),
                               NULL,
                               dbiConn.getId(),
                               NULL,
                               NULL,
                               NULL,
                               NULL,
                               0,
                               0);
        break;

        /* PMSTA-34445 - LJE - 190205 */
    case ListMgmFct_DataOrga:
    {
        int fetchNb = 0, matchNb = 0;
        ret = SCPT_EvalCstList(CSTLIST_BUILD_DATA_ORGA,
                               0,
                               scptDef,
                               entObjectEnum,
                               GET_ID(recordStp, Get_Arg_Id),
                               NULL,
                               dbiConn.getId(),
                               NULL,
                               NULL,
                               NULL,
                               NULL,
                               0,
                               0,
                               nullptr,
                               nullptr,
                               &fetchNb,
                               &matchNb);

        if (fetchNb)
        {
            MSG_LogSrvMesg(UNUSED, UNUSED, "Build result - fetched: %1 matched: %2",
                IntType, fetchNb,
                IntType, matchNb);
        }
    }
    break;
    }

    FREE_DYNST(aList, A_List);

    return(ret); /* REF3751 - SSO - 990623 */
}

/* Moved from dbapos.c - PMSTA-40170 - 130520 - vkumar */
/*******************************************************************************
**
**  Function    :  DBA_CleanPtfList()
**
**  Description :  Clean up ptf identifiers QuickSearch and List with LoadHierFlag==TRUE
**
**  Arguments	   ioIdTabPtr	pointer on array of Io_Id records
**				   ioIdNbrPtr	pointer on number of records in ioIdTabPtr
**
**  Return      :  RET_SUCCEED or error code
**
**  Creation    :  REF10011 - REF10365 - CHU - 040713
**
**  Modif       :  PMSTA16852-CHU-130828 Avoid Server Dialogue Error
**
*******************************************************************************/
RET_CODE DBA_CleanPtfList(DBA_DYNFLD_STP	**ioIdTabPtr,
                          int                *ioIdNbrPtr)
{
    DBA_DYNFLD_STP	*ptfTabPtr;
    int				ptfNbr = 0, i, j, ptfTabNbr = *ioIdNbrPtr;
    FLAG_T			*delPtfFlgTab, allocFlg = FALSE, squeezeArrayFlg = TRUE;
    RET_CODE		ret = RET_SUCCEED;

    /* < PMSTA16852-CHU-130828 */
    /* if no portfolio provided, no need to get through this piece of code */
    if (ioIdNbrPtr == NULL || *ioIdNbrPtr == 0)
    {
        return(ret);
    }
    /* > PMSTA16852-CHU-130828 */

    if ((ptfTabPtr = (DBA_DYNFLD_STP*)CALLOC(*ioIdNbrPtr, sizeof(DBA_DYNFLD_STP))) == NULL)
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, 1);
        return(RET_MEM_ERR_ALLOC);
    }

    if ((delPtfFlgTab = (FLAG_T*)CALLOC(*ioIdNbrPtr, sizeof(FLAG_T))) == NULL)
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, 1);
        FREE(ptfTabPtr);
        return(RET_MEM_ERR_ALLOC);
    }

    /* Get all A_Ptf dynamic structures */
    for (i = 0; i < *ioIdNbrPtr; i++)
    {
        if ((ret = DBA_GetPtfById(GET_ID((*ioIdTabPtr)[i], Io_Id_Id), FALSE,
            &allocFlg, &(ptfTabPtr[i]),
            NULL, UNUSED, UNUSED)) != RET_SUCCEED)
        {
            if (i > 0)
            {
                DBA_FreeDynStTab(ptfTabPtr, i, A_Ptf);
            }
            else
            {
                FREE(ptfTabPtr);
            }
            FREE(delPtfFlgTab);
            return(ret);
        }
        if (allocFlg == FALSE)
        { /* record comes from hierarchy, copy it so we can free all ptf table later */
            DBA_DYNFLD_STP ptfPtr = NULL;
            if ((ptfPtr = ALLOC_DYNST(A_Ptf)) == NULL)
            {
                MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, 1);
                if (i > 0)
                {
                    DBA_FreeDynStTab(ptfTabPtr, i, A_Ptf);
                }
                else
                {
                    FREE(ptfTabPtr);
                }
                return(RET_MEM_ERR_ALLOC);
            }
            COPY_DYNST(ptfPtr, ptfTabPtr[i], A_Ptf);
            ptfTabPtr[i] = ptfPtr;
        }
        delPtfFlgTab[i] = FALSE;
    }

    /* Scan Ptf Array to eliminate :
     1. children with parent present in the list
     2. Parents who has a parent Ptf
    */
    for (i = 0; i < *ioIdNbrPtr; i++)
    {
        if (IS_NULLFLD(ptfTabPtr[i], A_Ptf_ParentPortId) == FALSE)
        {
            for (j = 0; j < *ioIdNbrPtr; j++)
            {
                if (CMP_ID(GET_ID(ptfTabPtr[i], A_Ptf_ParentPortId),
                    GET_ID(ptfTabPtr[j], A_Ptf_Id)) == 0)
                {
                    delPtfFlgTab[i] = TRUE;
                    squeezeArrayFlg = TRUE;
                    break;
                }
            }
        }
    }

    if (squeezeArrayFlg == TRUE)
    {
        /* Get rid of previous array */
        DBA_FreeDynStTab(*ioIdTabPtr, *ioIdNbrPtr, Io_Id);

        /* allocate space for a new fresh array */
        if (((*ioIdTabPtr) = (DBA_DYNFLD_STP*)
            CALLOC(*ioIdNbrPtr, sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR)
        {   /* PMSTA07185 - DDV - 081023 - Purify */
            DBA_FreeDynStTab(ptfTabPtr, ptfTabNbr, A_Ptf);
            *ioIdNbrPtr = 0;
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, 1);
            return(RET_MEM_ERR_ALLOC);
        }

        /* Keep only portfolios with a non-delete flag */
        for (i = 0; i < *ioIdNbrPtr; i++)
        {
            if (delPtfFlgTab[i] == FALSE)
            {
                if (((*ioIdTabPtr)[ptfNbr] = ALLOC_DYNST(Io_Id)) == NULLDYNST)
                {
                    if (ptfNbr > 0)
                        DBA_FreeDynStTab(*ioIdTabPtr, ptfNbr, Io_Id);
                    else
                    {
                        FREE(*ioIdTabPtr);
                    }
                    /* PMSTA07185 - DDV - 081023 - Purify */
                    DBA_FreeDynStTab(ptfTabPtr, ptfTabNbr, A_Ptf);
                    FREE(delPtfFlgTab);
                    *ioIdNbrPtr = 0;
                    MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "Io_Id");
                    return(RET_MEM_ERR_ALLOC);
                }
                SET_ID((*ioIdTabPtr)[ptfNbr], Io_Id_Id, GET_ID(ptfTabPtr[i], A_Ptf_Id));
                ptfNbr++;
            }
        }
        *ioIdNbrPtr = ptfNbr;
    }

    DBA_FreeDynStTab(ptfTabPtr, ptfTabNbr, A_Ptf); /* PMSTA07185 - DDV - 081023 - Purify */
    FREE(delPtfFlgTab);

    return (ret);
}

/* Moved from dbapos.c - PMSTA-40170 - 130520 - vkumar */
/*******************************************************************************
**
**  Function    :  DBA_SelectPtfIdByDomain()
**
**  Description :  Select ptf identifiers depending on domain informations
**
**  Arguments   :  domainPtr	pointer on domain structure
**		   ioIdTabPtr	pointer on array of Io_Id records
**		   ioIdNbrPtr	pointer on number of records in ioIdTabPtr
**
**  Return      :  RET_SUCCEED or error code
**
**  Creation    :  DVP261 - RAK - 961127
**
**                 REF5010 - SSO - 000828
*******************************************************************************/
RET_CODE DBA_SelectPtfIdByDomain(DBA_DYNFLD_STP domainPtr,
    DBA_DYNFLD_STP **ioIdTabPtr,
    int *ioIdNbrPtr)
{
    DBA_DYNFLD_STP	inputPtr = NULLDYNST, *ioIdTab = NULLDYNSTPTR, *ptfList = NULLDYNSTPTR, tascJobSt = NULL; /* PMSTA08246 - LJE - 090619 */
    OBJECT_ENUM	object;
    int		i;
    RET_CODE	ret = RET_SUCCEED;
    FLAG_T		cleanPtfListFlg = FALSE; /* REF10011 - REF10365 - CHU - 040713 */

    *ioIdNbrPtr = 0;
    *ioIdTabPtr = NULLDYNSTPTR;

    if (DBA_GetObjectEnum(GET_DICT(domainPtr, A_Domain_DimPtfDictId), &object) != TRUE)
    {
        MSG_RETURN(RET_DBA_ERR_MD);
    }

    /* REF10011 - REF10365 - CHU - 040713 */
    if ((object == QuickSearch || object == List || object == DomainPtfCompo) &&
        GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None)
    {
        cleanPtfListFlg = TRUE;
    }

    switch (GET_OBJECT_CST(object)) /* REF8844 - LJE - 030416 */
    {
    case PtfCst:
        /* Allocation memory of pointer array */
        if (((*ioIdTabPtr) = (DBA_DYNFLD_STP*)
            CALLOC(1, sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR)
        {
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, 1);
            return(RET_MEM_ERR_ALLOC);
        }

        ioIdTab = *ioIdTabPtr;
        /* Allocate memory */
        if ((ioIdTab[0] = ALLOC_DYNST(Io_Id)) == NULLDYNST)
        {
            FREE((*ioIdTabPtr));
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "Io_Id");
            return(RET_MEM_ERR_ALLOC);
        }

        /* Set values in Id-structure */
        COPY_DYNFLD(ioIdTab[0], Io_Id, Io_Id_Id, domainPtr, A_Domain, A_Domain_PtfObjId);
        *ioIdNbrPtr = 1;

        break;

    case ListCst:
        /* Memory allocation of an Adm_Arg structure */
        if ((inputPtr = ALLOC_DYNST(Adm_Arg)) == NULLDYNST)
        {
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "Adm_Arg");
            return(RET_MEM_ERR_ALLOC);
        }

        /* Retrieve portfolio id's in list */
        ret = DBA_SelectByListId(GET_ID(domainPtr, A_Domain_PtfObjId),
            Ptf, UNUSED, Adm_Arg, inputPtr,
            Io_Id, ioIdTabPtr, UNUSED, UNUSED, ioIdNbrPtr, NULL);

        /* Free memory allocation */
        FREE_DYNST(inputPtr, Adm_Arg);

        if (ret != RET_SUCCEED)
        {
            MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, "Portfolio List",
                GET_ID(domainPtr, A_Domain_PtfObjId));
            return(RET_DBA_ERR_NODATA);
        }
        /* PMSTA-29302 - CHU - 180126 */
        /* In case of PTCC Replace Old mode (not selective), call del_session_data_for_ptf_chunk
        * to only delete session data related to the current chunk
        */
        if (IS_NULLFLD(domainPtr, A_Domain_PtfListDef) == TRUE &&
            IS_NULLFLD(domainPtr, A_Domain_JobReference) == FALSE &&
            IS_NULLFLD(domainPtr, A_Domain_ChunkNumber) == FALSE &&
            GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_PreTradeCheckStrat &&
            IS_NULLFLD(domainPtr, A_Domain_FctResultId) == FALSE &&
            GET_ENUM(domainPtr, A_Domain_CompDataEn) == CompData_ReplOld)
        {
            RET_CODE       ret2 = RET_SUCCEED;
            DbiConnection * dbiConn = nullptr;
            DBA_DYNFLD_STP argument = ALLOC_DYNST(Arg_Test);

            if (argument != NULL)
            {
                SET_ID(argument, Arg_Test_Id, GET_ID(domainPtr, A_Domain_FctResultId));
                MSG_LogSrvMesg(UNUSED, UNUSED, "Pre-Trade Compliance Check : Deleting %1 session content for chunk number %2",
                    CodeType, GET_CODE(domainPtr, A_Domain_FctResultCd),
                    IntType, GET_INT(domainPtr, A_Domain_ChunkNumber));

                if ((dbiConn = DBA_GetDbiConnection(SqlServer)) == nullptr)
                {
                    MSG_SendMesg(RET_DBA_ERR_CONNOTFOUND, 0, FILEINFO);
                    return(RET_SRV_LIB_ERR_COMMAND_ABORTED);
                }

                if ((ret2 = dbiConn->beginTransaction()) != RET_SUCCEED)
                {
                    DBA_EndConnection(&dbiConn);
                    return(RET_SRV_LIB_ERR_COMMAND_ABORTED);
                }

                /* del_session_data_for_ptf_chunk */
                /* ESL/ESE/RSE/RSEC/CM/LC */
                if ((ret2 = DBA_Delete2(FctResult,
                    UNUSED,
                    Arg_Test, argument,
                    UNUSED, (int*)&dbiConn->getId())) != RET_SUCCEED)
                {
                    FREE_DYNST(argument, Arg_Test);
                    dbiConn->endTransaction(FALSE);
                    DBA_EndConnection(&dbiConn);
                    return(RET_SRV_LIB_ERR_COMMAND_ABORTED);
                }

                dbiConn->endTransaction(TRUE);
                DBA_EndConnection(&dbiConn);
            }
            FREE_DYNST(argument, Arg_Test);
        }
        break;

        /* REF4611 - RAK - 000504 */
        /* Use "synthetic" load because of it do exactly */
        /* that we need (update of dom_port and select) */
    case QuickSearchCst:
    {
        DbiConnection * dbiConn = nullptr;
        DICT_T  entDictId;
        DBA_GetDictId(Ptf, &entDictId);

        /* Get a free connection in the connection list */
        if ((dbiConn = DBA_GetDbiConnection(SqlServer)) == nullptr)
        {
            MSG_SendMesg(RET_DBA_ERR_CONNOTFOUND, 0, FILEINFO);
            return(DBA_CONN_NOT_FOUND);
        }

        /* Create #dom_position, #dom_instr, #dom_port */
        DATE_START_TIMER(2, TIMER_MASK_SQLC);

        ret = DBA_CreateTempTables(*dbiConn, DOM_POSITION_INSTR_PORT | TCT_VECTOR_ID);

        if (ret != RET_SUCCEED)
        {
            return ret;
        }
        DATE_STOP_TIMER(2, TIMER_MASK_SQLC);


        /* PMSTA08246 - LJE - 090615 */
        if (IS_NULLFLD(domainPtr, A_Domain_PtfListDef) == TRUE &&
            IS_NULLFLD(domainPtr, A_Domain_JobReference) == FALSE)
        {
            if ((tascJobSt = ALLOC_DYNST(A_TascJob)) != NULL &&
                DBA_Get2(TascJob,
                    UNUSED,
                    A_Domain,
                    domainPtr,
                    A_TascJob,
                    &tascJobSt,
                    DBA_SET_CONN | DBA_NO_CLOSE,
                    (int*)&dbiConn->getId(),
                    UNUSED) == RET_SUCCEED &&
                tascJobSt != NULL &&
                IS_NULLFLD(tascJobSt, A_TascJob_PortfoliosetTbName) == FALSE)
            {
                DBA_DYNFLD_STP argument = ALLOC_DYNST(Arg_Test);

                if (argument != NULL)
                {
                    SET_ID(argument, Arg_Test_Id, GET_ID(tascJobSt, A_TascJob_Id)); /* PMSTA-11505 - LJE - 110713 */
                    if (IS_NULLFLD(domainPtr, A_Domain_ChunkNumber) == FALSE)
                        SET_INT(argument, Arg_Test_Int, GET_INT(domainPtr, A_Domain_ChunkNumber));

                    SET_ENUM(argument, Arg_Test_Enum, TslJobPtfCompNat_Untreated); /* PMSTA13876 - DDV - 130905 */

                    if ((ret = DBA_Notif2(TascJob,
                        UNUSED,
                        Arg_Test,
                        argument,
                        DBA_SET_CONN | DBA_NO_CLOSE,
                        (int*)&dbiConn->getId(),
                        UNUSED)) != RET_SUCCEED)
                    {
                        FREE_DYNST(argument, Arg_Test);
                        FREE_DYNST(tascJobSt, A_TascJob);
                        DBA_LoadPosDropTempTables(*dbiConn, (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
                        DBA_EndConnection(&dbiConn);
                        return(ret);
                    }
                    FREE_DYNST(argument, Arg_Test); /* PMSTA14453 - DDV - 120712 - Purify */
                }
            }

            FREE_DYNST(tascJobSt, A_TascJob);
        }
        else
        {
            /* Insert portfolios Ids from the Quick Search List into #dom_port */
            if ((ret = SERV_ListMgm(ListMgmFct_LoadPos,
                                    entDictId,
                                    0,
                                    GET_STRING(domainPtr, A_Domain_PtfListDef),
                                    *dbiConn,
                                    nullptr)) != RET_SUCCEED)
            {
                /* REF3751 - SSO - 990623 more ret code tests */
                DBA_LoadPosDropTempTables(*dbiConn, (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
                DBA_EndConnection(&dbiConn);
                return(ret);
            }
        }

        /* Call select */
        ret = DBA_Select2(Ptf, UNUSED, A_Domain, domainPtr,
            Io_Id, ioIdTabPtr,
            DBA_SET_CONN | DBA_NO_CLOSE, UNUSED,
            ioIdNbrPtr, (int*)&dbiConn->getId(), UNUSED);

        /* PMSTA-29302 - CHU - 180126 */
        /* In case of PTCC Replace Old mode (not selective), call del_session_data_for_ptf_chunk
        * to only delete session data related to the current chunk
        */
        if (IS_NULLFLD(domainPtr, A_Domain_PtfListDef) == TRUE &&
            IS_NULLFLD(domainPtr, A_Domain_JobReference) == FALSE &&
            IS_NULLFLD(domainPtr, A_Domain_ChunkNumber) == FALSE &&
            GET_DICT(domainPtr, A_Domain_FctDictId) == DictFct_PreTradeCheckStrat &&
            IS_NULLFLD(domainPtr, A_Domain_FctResultId) == FALSE &&
            GET_ENUM(domainPtr, A_Domain_CompDataEn) == CompData_ReplOld)
        {
            DBA_DYNFLD_STP argument = ALLOC_DYNST(Arg_Test);
            RET_CODE ret2 = RET_SUCCEED;

            if (argument != NULL)
            {
                SET_ID(argument, Arg_Test_Id, GET_ID(domainPtr, A_Domain_FctResultId));
                MSG_LogSrvMesg(UNUSED, UNUSED, "Pre-Trade Compliance Check : Deleting %1 session content for chunk number %2",
                    CodeType, GET_CODE(domainPtr, A_Domain_FctResultCd),
                    IntType, GET_INT(domainPtr, A_Domain_ChunkNumber));
                /* del_session_data_for_ptf_chunk */
                /* ESL/ESE/RSE/RSEC/CM/LC */
                ret2 = DBA_Delete2(FctResult,
                    UNUSED,
                    Arg_Test, argument,
                    DBA_SET_CONN | DBA_NO_CLOSE, (int*)&dbiConn->getId(), UNUSED);
            }
            FREE_DYNST(argument, Arg_Test);
        }

        /* Remove temporary table and stop connection */
        DBA_LoadPosDropTempTables(*dbiConn, (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
        DBA_EndConnection(&dbiConn);
        break;
    }

    /* REF7371 - RAK - 020515 */
    case ThirdCst:

        /* call proc sel_all_portfolio_by_tid which return A_Ptf owned by third */
        /* rem : proc return A_Ptf because it could be used in an other context (synthAdmin, ...) */


        /* PMSTA-12529 - RAK - 110815 - Use domain to put the two new famous parameters */
        /* A_Domain_OwnershipRuleEn and A_Domain_ThirdCompoEn */
        /* if ((inputPtr = ALLOC_DYNST(Get_Arg)) == NULLDYNST)
        {
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "Get_Arg");
            return(RET_MEM_ERR_ALLOC);
        }

        SET_ID(inputPtr, Get_Arg_Id, GET_ID(domainPtr, A_Domain_PtfObjId)); */

        /* PMSTA-12672 - KPV - JourJ : en m?me temps c'est rigolo */
        /* in case of merged mode, fill an empty ioIdTab to allow computation on all portfolios in one */
        if ((PTFCONSRULE_ENUM)GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) == PtfConsRule_Merged)
        {
            *ioIdNbrPtr = 1;

            if (((*ioIdTabPtr) = (DBA_DYNFLD_STP *)
                CALLOC(*ioIdNbrPtr, sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR)
            {
                DBA_FreeDynStTab(ptfList, *ioIdNbrPtr, A_Ptf);
                MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, 1);
                return(RET_MEM_ERR_ALLOC);
            }

            ioIdTab = *ioIdTabPtr;

            /* Allocate memory */
            if ((ioIdTab[0] = ALLOC_DYNST(Io_Id)) == NULLDYNST)
            {
                MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "Io_Id");
                return(RET_MEM_ERR_ALLOC);
            }

            /* keep the IO empty */
        }
        else
        {
            ret = DBA_Select2(Ptf, DBA_ROLE_LOAD_STRAT_LNK, /* PMSTA-12529 - RAK - 110815 - use role */
                A_Domain, domainPtr, A_Ptf, &ptfList,
                UNUSED, UNUSED, ioIdNbrPtr, UNUSED, UNUSED);

            /* PMSTA-12529 - RAK - 110815 -  FREE_DYNST(inputPtr, Get_Arg); */
            if (ret != RET_SUCCEED
                || (*ioIdNbrPtr) == 0) /* PMSTA16046-CHU-130313 : pas de bras, pas de chokolats... sympa comme date ! */
            {
                MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "Portfolio");
                return(RET_DBA_ERR_NODATA);
            }

            /* Store and return only the identifier */
            if (((*ioIdTabPtr) = (DBA_DYNFLD_STP *)
                CALLOC(*ioIdNbrPtr, sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR)
            {
                DBA_FreeDynStTab(ptfList, *ioIdNbrPtr, A_Ptf);
                MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, 1);
                return(RET_MEM_ERR_ALLOC);
            }

            ioIdTab = *ioIdTabPtr;

            /* Copy portfolio infos into Io_Id structure */
            for (i = 0; i < (*ioIdNbrPtr); i++)
            {
                /* Allocate memory */
                if ((ioIdTab[i] = ALLOC_DYNST(Io_Id)) == NULLDYNST)
                {
                    DBA_FreeDynStTab((*ioIdTabPtr), i, Io_Id);
                    DBA_FreeDynStTab(ptfList, *ioIdNbrPtr, A_Ptf);
                    MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "Io_Id");
                    return(RET_MEM_ERR_ALLOC);
                }

                /* Set values in Id-structure */
                COPY_DYNFLD(ioIdTab[i], Io_Id, Io_Id_Id, ptfList[i], A_Ptf, A_Ptf_Id);
            }

            /* Free memory allocation */
            DBA_FreeDynStTab(ptfList, *ioIdNbrPtr, A_Ptf);
        }

        break;

    case NullEntityCst:
        /* Memory allocation of an Fus_Arg structure */
        if ((inputPtr = ALLOC_DYNST(Fus_Arg)) == NULLDYNST)
        {
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "Adm_Arg");
            return(RET_MEM_ERR_ALLOC);
        }

        ret = DBA_Select2(Ptf, UNUSED, Fus_Arg, inputPtr, S_Ptf, &ptfList,
            UNUSED, UNUSED, ioIdNbrPtr, UNUSED, UNUSED);

        /* Free memory allocation */
        FREE_DYNST(inputPtr, Fus_Arg);

        if (ret != RET_SUCCEED)
        {
            MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "Portfolio");
            return(RET_DBA_ERR_NODATA);
        }

        /* Allocation memory of pointer array */
        if (((*ioIdTabPtr) = (DBA_DYNFLD_STP *)
            CALLOC(*ioIdNbrPtr, sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR)
        {
            DBA_FreeDynStTab(ptfList, *ioIdNbrPtr, S_Ptf);
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, 1);
            return(RET_MEM_ERR_ALLOC);
        }

        ioIdTab = *ioIdTabPtr;

        /* Copy portfolio infos into Io_Id structure */
        for (i = 0; i < (*ioIdNbrPtr); i++)
        {
            /* Allocate memory */
            if ((ioIdTab[i] = ALLOC_DYNST(Io_Id)) == NULLDYNST)
            {
                DBA_FreeDynStTab((*ioIdTabPtr), i, Io_Id);
                DBA_FreeDynStTab(ptfList, *ioIdNbrPtr, S_Ptf);
                MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "Io_Id");
                return(RET_MEM_ERR_ALLOC);
            }

            /* Set values in Id-structure */
            COPY_DYNFLD(ioIdTab[i], Io_Id, Io_Id_Id, ptfList[i], S_Ptf, S_Ptf_Id);
        }

        /* Free memory allocation */
        DBA_FreeDynStTab(ptfList, *ioIdNbrPtr, S_Ptf);

        break;

        /* PMSTA-36175 - PM Profile Phase1 changes - Kramadevi - 02072019*/
    case DomainPtfCompoCst:
        DbiConnection * dbiConn = nullptr;

        /* Get a free connection in the connection list */
        if ((dbiConn = DBA_GetDbiConnection(SqlServer)) == nullptr)
        {
            MSG_SendMesg(RET_DBA_ERR_CONNOTFOUND, 0, FILEINFO);
            return(DBA_CONN_NOT_FOUND);
        }

        /*create temp tables*/
        ret = DBA_CreateTempTables(*dbiConn, DOM_POSITION_INSTR_PORT);
        if (ret != RET_SUCCEED)
        {
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_CreateTempTables failed");
            return(ret);
        }

        if (IS_NULLFLD(domainPtr, A_Domain_JobReference) == FALSE)
        {
            if ((tascJobSt = ALLOC_DYNST(A_TascJob)) != NULL &&
                DBA_Get2(TascJob,
                         UNUSED,
                         A_Domain,
                         domainPtr,
                         A_TascJob,
                         &tascJobSt,
                         DBA_SET_CONN | DBA_NO_CLOSE,
                         (int*)&dbiConn->getId(),
                         UNUSED) == RET_SUCCEED &&
                tascJobSt != NULL &&
                IS_NULLFLD(tascJobSt, A_TascJob_PortfoliosetTbName) == FALSE)
            {
                DBA_DYNFLD_STP argument = ALLOC_DYNST(Arg_Test);

                if (argument != NULL)
                {
                    SET_ID(argument, Arg_Test_Id, GET_ID(tascJobSt, A_TascJob_Id));
                    if (IS_NULLFLD(domainPtr, A_Domain_ChunkNumber) == FALSE)
                        SET_INT(argument, Arg_Test_Int, GET_INT(domainPtr, A_Domain_ChunkNumber));
                    SET_ENUM(argument, Arg_Test_Enum, TslJobPtfCompNat_Untreated);

                    if ((ret = DBA_Notif2(TascJob,
                                          UNUSED,
                                          Arg_Test,
                                          argument,
                                          DBA_SET_CONN | DBA_NO_CLOSE,
                                          (int*)&dbiConn->getId(),
                                          UNUSED)) != RET_SUCCEED)
                    {
                        FREE_DYNST(argument, Arg_Test);
                        FREE_DYNST(tascJobSt, A_TascJob);
                        DBA_LoadPosDropTempTables(*dbiConn, (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
                        DBA_EndConnection(&dbiConn);
                        return(ret);
                    }
                    FREE_DYNST(argument, Arg_Test);
                }
            }
            FREE_DYNST(tascJobSt, A_TascJob);
        }
		else
		{
			char *buffer = NULL;
			if ((buffer = (char *)CALLOC(1, 2048)) != NULL)
			{
				sprintf(buffer, "delete from #dom_port ");
				ret = DBA_SqlExec(buffer, *dbiConn);

				if (ret == RET_SUCCEED)
				{
					sprintf(buffer,
						"insert into #dom_port (id,port_pos_set_id,hier_port_id,fusion_date_rule_e) "
						"select dpc.portfolio_id, 0, null, 0 "
						"from %s dpc, %s p "
						"where dpc.function_result_id=%" szFormatId" and p.id = dpc.portfolio_id ",
						SCPT_GetViewName(DomainPtfCompo, false).c_str(),
						SCPT_GetViewName(Ptf, false).c_str(),
						GET_ID(domainPtr, A_Domain_FctResultId));

					sprintf(buffer + strlen(buffer), " and #MAIN_DLM_CHECK(p, portfolio)");

					if (DBA_SqlExec(buffer, *dbiConn) != RET_SUCCEED)
					{
						FREE(buffer);
						DBA_LoadPosDropTempTables(*dbiConn, (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
						if (DBA_CreateTempTables(*dbiConn, DOM_STRAT) != RET_SUCCEED)
							MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_CreateTempTables failed");
						return(ret);
					}
				}
				FREE(buffer);
			}
		}

        /* Call select */
        ret = DBA_Select2(Ptf, UNUSED, A_Domain, domainPtr,
            Io_Id, ioIdTabPtr,
            DBA_SET_CONN | DBA_NO_CLOSE, UNUSED,
            ioIdNbrPtr, (int*)&dbiConn->getId(), UNUSED);

        /* Remove temporary table and stop connection */
        DBA_LoadPosDropTempTables(*dbiConn, (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
        DBA_EndConnection(&dbiConn);
        break;
    }

    /* PMSTA-15109 - TGU - 121121 - check if there is no entry in "ioIdTabPtr" */
    if ((cleanPtfListFlg == TRUE) && (*ioIdNbrPtr) > 0)
    {
        ret = DBA_CleanPtfList(ioIdTabPtr, ioIdNbrPtr);
    }
    return(ret);
}

/************************************************************************
**
**  Function    :   DBA_HeadPtfHasChildren()
**
**  Description :   Check if Head portfolio provided has any
**                         child portfolios
**
**  Arguments   :   ptfTab  - portfolio tab
**                  ptfNbr  - total no. of portfolios
**                  headPtf - head portfolio pointer
**
**  Return      :   true -  if it has child portfolio
**                  false - if none.
**
**  Creation    :   PMSTA-40170 - 130520 - vkumar
**
**
*************************************************************************/
STATIC bool DBA_HeadPtfHasChildren(const DBA_DYNFLD_STP * ptfTab, const int ptfNbr, const DBA_DYNFLD_STP & headPtf)
{
    for (int idx = 0; idx < ptfNbr; ++idx)
    {
        if (CMP_DYNFLD(headPtf, ptfTab[idx], A_Ptf_Id, A_Ptf_ParentPortId, IdType) == 0)
            return true;
    }
    return false;
}

/************************************************************************
**
**  Function    :   DBA_UpdateFwdRollOverDetails()
**
**  Description :   update status in the cash plan execution date
**
**
**
**  Arguments   :   domainPtr - domain pointer
**
**  Return      :   RET_CODE.
**
**  Creation    :   WEALTH-4125	 Vishnu 01012024
**
**
*************************************************************************/
RET_CODE DBA_UpdateFwdRollOverDetails(DBA_DYNFLD_STP     domainPtr,
                                      DbiConnection&     dbiConn,
                                      DBA_DYNFLD_STP     extOpPtr)
{
    RET_CODE ret = RET_SUCCEED;
    MemoryPool mp;

    DbiConnectionHelper dbiConnHelper(&dbiConn, false);

    DBA_DYNFLD_STP fwdInput = mp.allocDynst(FILEINFO, Chk_Arg);

    COPY_DYNFLD(fwdInput, Chk_Arg, Chk_Arg_Id , extOpPtr, ExtOp, ExtOp_Id);
    COPY_DYNFLD(fwdInput, Chk_Arg, Chk_Arg_Cd, extOpPtr, ExtOp, ExtOp_Cd);


    ret = dbiConnHelper.dbaUpdate(FwdRollover, UNUSED, fwdInput);


    return ret;
}


/************************************************************************
**
**  Function    :   DBA_UpdatePtfStatusForOverlay()
**
**  Description :   update status in the cash plan execution date
**
**
**
**  Arguments   :   domainPtr - domain pointer
**
**  Return      :   RET_CODE.
**
**  Creation    :   PMSTA-45727 Autocash Vishnu 27072021
**
**
*************************************************************************/
RET_CODE DBA_createWithDrReqForCashPlan(DBA_DYNFLD_STP      domainPtr,
                                        DbiConnection      &dbiConn,
                                        DBA_DYNFLD_STP     extOpPtr)
{
    RET_CODE ret = RET_SUCCEED;

    DBA_DYNFLD_STP withDrReq = NULL;

    if (NULL == (withDrReq = ALLOC_DYNST(A_WithdrawalRequest)))
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "A_WithdrawalRequest");
        return ret;
    }


    SET_ENUM(withDrReq, A_WithdrawalRequest_NatEn, WithdrawalRequestNaEn_PartialWithdrawalCashMgmtPlan);
    SET_ENUM(withDrReq, A_WithdrawalRequest_StatusEn, WithdrawalRequestStatusEn_PendingOrdersSentToMarket);
    SET_ENUM(withDrReq, A_WithdrawalRequest_FailureReasonEn, WithdrawalRequestFailureReasonEn_None);
    SET_ENUM(withDrReq, A_WithdrawalRequest_FullLiquidationBehaviorEn, WithdrawalRequestFullLiquidationBehavior_NoAction);
    SET_ENUM(withDrReq, A_WithdrawalRequest_CashRealignMethodEn, 0);
    SET_ENUM(withDrReq, A_WithdrawalRequest_RealignEn, 0);

    COPY_DYNFLD(withDrReq, A_WithdrawalRequest, A_WithdrawalRequest_WithdrawalAmount, extOpPtr, ExtOp, ExtOp_Qty);
    COPY_DYNFLD(withDrReq, A_WithdrawalRequest, A_WithdrawalRequest_PtfId, extOpPtr, ExtOp, ExtOp_PtfId);
    COPY_DYNFLD(withDrReq, A_WithdrawalRequest, A_WithdrawalRequest_WithdrawalCurrId, extOpPtr, ExtOp, ExtOp_OpCurrId);
    COPY_DYNFLD(withDrReq, A_WithdrawalRequest, A_WithdrawalRequest_PlanDefinitionId, extOpPtr, ExtOp, ExtOp_CashPlanId);
    COPY_DYNFLD(withDrReq, A_WithdrawalRequest, A_WithdrawalRequest_CounterpartAccount, extOpPtr, ExtOp, ExtOp_CounterpartAccount);

    COPY_DYNFLD(withDrReq, A_WithdrawalRequest, A_WithdrawalRequest_CounterpartCcyId, extOpPtr, ExtOp, ExtOp_CounterpartCurrencyId);

    COPY_DYNFLD(withDrReq, A_WithdrawalRequest, A_WithdrawalRequest_SessionId, domainPtr, A_Domain, A_Domain_FctResultId);
    COPY_DYNFLD(withDrReq, A_WithdrawalRequest, A_WithdrawalRequest_BeginDate, domainPtr, A_Domain, A_Domain_InterpFromDate);
    COPY_DYNFLD(withDrReq, A_WithdrawalRequest, A_WithdrawalRequest_PlanExecDate, domainPtr, A_Domain, A_Domain_InterpFromDate);


    DbiConnectionHelper dbiConnHelper(&dbiConn, false);


    ret = dbiConnHelper.dbaInsert(WithdrawalRequest, UNUSED, withDrReq);

    if (ret != RET_SUCCEED)
    {
        /*if insert fails try update*/
        ret = dbiConnHelper.dbaUpdate(WithdrawalRequest, UNUSED, withDrReq);
    }
    FREE(withDrReq);

    /*update extop status to external pos*/
    OPSTAT_ENUM     extTrenStatus;
    GEN_GetApplInfo(ApplExternalPosStatus, &extTrenStatus);

    SET_ENUM(extOpPtr, ExtOp_StatusEn, extTrenStatus);

    DBA_DYNFLD_STP dummyextOp = NULL;

    if (NULL == (dummyextOp = ALLOC_DYNST(ExtOp)))
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtOp");
        return ret;
    }

    COPY_DYNFLD(dummyextOp, ExtOp, ExtOp_DbId, extOpPtr, ExtOp, ExtOp_DbId);

    ret = dbiConnHelper.dbaUpdate(ExtOrder, DBA_ROLE_UPDATE_STATUS, dummyextOp);

    FREE_DYNST(dummyextOp, ExtOp);
    return ret;
}



/************************************************************************
**
**  Function    :   DBA_UpdatePtfStatusForOverlay()
**
**  Description :   update status in the cash plan execution date
**
**
**
**  Arguments   :   domainPtr - domain pointer
**
**  Return      :   RET_CODE.
**
**  Creation    :   PMSTA-42402 Autocash Vishnu 12012021
**
**
*************************************************************************/
RET_CODE DBA_UpdatePtfStatusForExecutionDate(DBA_DYNFLD_STP      domainPtr,
                                             DbiConnection      &dbiConn)
{
    RET_CODE        ret = RET_SUCCEED;


    /*need to set status only if session is final
     for check and publish code flow will come here only if order  is not having any error so ignore the status
    */
    if ((GET_ENUM(domainPtr, A_Domain_FctResultStatEn) != FctResultStatus_Final) && (
        (EVTGEN_ENUM)GET_ENUM(domainPtr, A_Domain_EvtGenNatEn) != EvtGen_CheckAndPublish  &&
        (EVTGEN_ENUM)GET_ENUM(domainPtr, A_Domain_EvtGenNatEn) != EvtGen_CheckSplitAndPublish &&
        (EVTGEN_ENUM)GET_ENUM(domainPtr, A_Domain_EvtGenNatEn) != EvtGen_CheckCaseSplitAndPublish) )
        return ret;

    MemoryPool      mp;


    DbiConnectionHelper dbiConnHelper(&dbiConn, false);

    /*Check if there are any cash plan execution record for the func_result_id*/
    DBA_DYNFLD_STP selArgStp = mp.allocDynst(FILEINFO, Get_Arg);

    SET_ID(selArgStp, Get_Arg_Id, GET_ID(domainPtr, A_Domain_FctResultId) );

    DBA_DYNFLD_STP     *dbCashPlanDateTab = nullptr;
    int                 dbCashPlanDateNbr = 0;

    ret = dbiConnHelper.dbaSelect(CashPlanExecDate, DBA_ROLE_ORDER_SESSION, selArgStp, A_CashPlanExecDate, &dbCashPlanDateTab, &dbCashPlanDateNbr);


    for (int i = 0; i < dbCashPlanDateNbr; i++)
    {
        if (static_cast<CashPlanExecDateStatusEn>GET_ENUM(dbCashPlanDateTab[i], A_CashPlanExecDate_StatusEn) == CashPlanExecDateStatusEn::Success)
            continue;

        SET_ENUM(dbCashPlanDateTab[i], A_CashPlanExecDate_StatusEn, CashPlanExecDateStatusEn::Success);

        ret = dbiConnHelper.dbaUpdate(CashPlanExecDate, UNUSED, dbCashPlanDateTab[i]);

        if (ret != RET_SUCCEED)
            return ret;
    }


    return ret;
}


/************************************************************************
**
**  Function    :   DBA_UpdatePtfStatusForOverlay()
**
**  Description :   Update overlay status of all portfolio in Overlay
**                  structure based on the domain portfolio dimension
**                  and rebalance method
**
**  Arguments   :   domainPtr - domain pointer
**
**  Return      :   RET_CODE.
**
**  Creation    :   PMSTA-40170 - 130520 - vkumar
**
**
*************************************************************************/
RET_CODE DBA_UpdatePtfStatusForOverlay(DBA_DYNFLD_STP      domainPtr,
                                   DbiConnection &     dbiConn)
{
    RET_CODE         ret        = RET_SUCCEED;
    DBA_DYNFLD_STP	*ptfIdTab   = NULL,
                    *ptfTab     = NULL;
    int				 ptfIdNbr   = 0,
                     ptfNbr     = 0;
    MemoryPool       mp;

    /* 1. Fetch all portfolio (parent and children) based on domain portfolio dimension and ID
       2. Fetch strategy for head portfolio
       3. Update overlay status based on rebal method
       4. Update to DB
    */

    if ((ret = DBA_SelectPtfIdByDomain(domainPtr, &ptfIdTab, &ptfIdNbr)) != RET_SUCCEED)
    {
        return ret;
    }

    if (ptfIdNbr > 0)
    {
        DbiConnectionHelper dbiConnHelper(&dbiConn, false);

        dbiConnHelper.isValidAndInit();

        if (!dbiConnHelper.dbaCreateTempTables(DOM_POSITION_INSTR_PORT))
        {
            MSG_SendMesg(FILEINFO, "updatePtfStatusForOverlay : DBA_CreateTempTables failed");
            return ret;
        }

		/* PMSTA-51847 - SRN - 31012023*/
		int MaxNoOfSqlInsert = 0, min_limit = 0,
			max_limit = (ptfIdNbr >= MAX_NUMBER_EXP_IN_LIST) ? MAX_NUMBER_EXP_IN_LIST : ptfIdNbr;	/* Maximum limit for portfolio. If ptfIdNbr is greater, then maxlimit will be 999 else maxlimit is ptfIdNbr. */
		MaxNoOfSqlInsert = ptfIdNbr / MAX_NUMBER_EXP_IN_LIST;										/* Maximum number of iteration to execute a loop. */
		MaxNoOfSqlInsert = MaxNoOfSqlInsert + 1;													/* Default to iterate once, if the potrfolio count is less than 1000 or it exceeds 1000. */

		while (MaxNoOfSqlInsert > 0)
		{
			char *buff = static_cast<char *>(mp.calloc(1, 2048));
			int   buffLen = 0;

			/* init #dom_port according to give ptf ids */
			sprintf(buff, "insert into #dom_port (id,port_pos_set_id,hier_port_id,fusion_date_rule_e) select id, 0, null, 0 "
				"from portfolio_vw where id in (");

			buffLen = SYS_StrLen(buff);
			char sep = ' ';

			buff = static_cast<char *>(mp.realloc(buff, (buffLen + ptfIdNbr * (ID_T_LEN + 1) + 2) * sizeof(char)));
			for (int ptf = min_limit; ptf < max_limit; ptf++)	/* changed the initial value of for loop to min_limit and end value to max_limit */
			{
				sprintf(buff + buffLen, "%c%*" szFormatId, sep, ID_T_LEN, GET_ID(ptfIdTab[ptf], Io_Id_Id));
				buffLen += ID_T_LEN + 1;
				sep = ',';
			}
			sprintf(buff + buffLen, ")");

			if ((ret = dbiConnHelper.dbaSqlExec(buff)) != RET_SUCCEED)
			{
				MSG_SendMesg(FILEINFO, "updatePtfStatusForOverlay : Temp table execution error");
				return(RET_GEN_ERR_NOACTION);
			}

			/* PMSTA-51847 - SRN - 31012023*/
			MaxNoOfSqlInsert--;				/* Decrement this value to found next iteration. */
			if (MaxNoOfSqlInsert == 1)		/* If it was last insertion, */
			{
				min_limit = max_limit;	/* change the max limit to min. */
				max_limit = ptfIdNbr;	/* ptfIdNbr to max. */
			}
			else
			{
				min_limit = max_limit;					/* If the MaxNoOfSqlInsert is greater than 1, change the max limit to min and */
				max_limit += MAX_NUMBER_EXP_IN_LIST;	/* max limit will be addition of 999, for every iteration. */
			}
		}

        if ((ret = dbiConnHelper.dbaSelect(Ptf, DBA_ROLE_TOPHIERPTF, nullptr, A_Ptf, &ptfTab, &ptfNbr)) != RET_SUCCEED)
        {
            FREE(ptfIdTab);
            return ret;
        }

        REBAL_METHOD_ENUM  rebalMethod = static_cast<REBAL_METHOD_ENUM>GET_ENUM(domainPtr, A_Domain_RebalMethodEn);
        PtfOverlayStatusEn status      = (REBAL_METHOD_ENUM::Inter_All_Assets == rebalMethod ||
                                          REBAL_METHOD_ENUM::Inter_Cash_Only == rebalMethod) ?
                                         PtfOverlayStatusEn::IntraRealignmentPending :
                                         PtfOverlayStatusEn::NoPendingChange;

        for (int idx = 0; idx < ptfNbr; ++idx)
        {
            if (IS_NULLFLD(ptfTab[idx], A_Ptf_ParentPortId) &&
                false == DBA_HeadPtfHasChildren(ptfTab, ptfNbr, ptfTab[idx]))
            {
                /* unset overlay status and flag for head portfolio which are removed from overlay structure */
                SET_ENUM(ptfTab[idx], A_Ptf_OverlayStatusEn, PtfOverlayStatusEn::NoPendingChange);
                SET_FLAG(ptfTab[idx], A_Ptf_OverlayFlg, FALSE);
            }
            else
            {
                SET_ENUM(ptfTab[idx], A_Ptf_OverlayStatusEn, status);
            }

            /* mark portfolio for update */
            if ((ret == dbiConnHelper.dbaUpdate(Ptf, UNUSED, ptfTab[idx])) != RET_SUCCEED)
            {
                MSG_SendMesg(FILEINFO, "updatePtfStatusForOverlay: DB Update failed");
                FREE(ptfTab);
                return ret;
            }
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DBA_FamilyOrder.
**
**  Description :   Allow to insert/update orders using DBA_MultiAccess.
**
**  Arguments   :   EXTOP_ACTION_ENUM		action
**					DBA_DYNFLD_STP          *extOpTab
**					int                     extOpNbr
**					int                     colNbr
**					RETCODEFCT              *fct
**					PTR                     dataPtr
**					int                     options
**					DBA_ERRMSG_HEADER_STP   msgErrHaderStp
**					DICT_T                  dictidFunction
**					DBA_DYNFLD_STP          pdbadynDomain
**
**  Return      :   RET_CODE.
**
**  Cr�ation    :   RAK - 990705 - REF3742.
**  Modif.      :   ROI - 990804 - REF3742
**              :   FIH - 991027 - REF4083
**  	        :   REF4083 - SSO - 991027   saving extop for error handling
**			    :	MRA - 991206 - REF4126 + condition (extOpNbr > 0) pour CALLOC et FREE.
**			    :	MRA - 000218 - REF4217 add options parameter.
**              :   GRD - 000727 - REF5046.
**              :   REF7264 - 0201225 - PMO : Compilation errors and warnings with C++ compiler
**				:	REF7635 - CHU - 020621 : Allow Parent Orders DBIds to be reported into Child Orders
**              :   REF10469 - 040721 - PMO : Impossible to save a session generated by Reconcile Strategy if you have Constraint Breach records (problem with DBA_FamilyOrder)
**              :   REF10513 - 040802 - PMO : Saving an Order Session causes a memory corruption
**              :   REF11780 - 100406 - PMO : Implementation of the Sybase timestamp field
*************************************************************************/
RET_CODE DBA_FamilyOrder(EXTOP_ACTION_ENUM      action,
                         DBA_DYNFLD_STP         *extOpTab,
                         int                    extOpNbr,
                         int                    colNbr,
                         RET_CODE               (*fct)(FLAG_T, EXTOP_ACTION_ENUM, DBA_DYNFLD_STP *, int, int, int *, PTR), /* REF7264 - PMO */
                         PTR                    dataPtr,
                         int                    options,
                         DbiConnectionHelper    &dbiConnHelper, /* DLA - PMSTA-27575 - 170628 */
                         DICT_T                 dictidFunction,
                         DBA_DYNFLD_STP         pdbadynDomain,
						 DBA_DYNFLD_STP			*caseMgtTab, /* PMSTA07121-CHU-081030 */
						 int					caseMgtNbr,  /* PMSTA07121-CHU-081118 */
						 DBA_DYNFLD_STP			*draftFctResPtr, /* PMSTA09118-CHU-100121 - draft FctRes */
                         PTR                    argHierHead,     /* PMSTA-28596 - CHU - 171012 */
                         bool                   splitSessionPerformedFlg) /* PMSTA-31673 - CHU - 180607 : to know if session splitting was already performed */
{
    DBA_ACCESS_STP      extOpAccessTab=NULL, opAccessTab=NULL;
    int                 extOpAccessNbr=0, opAccessNbr=0;
    RET_CODE            ret = RET_SUCCEED, specialRetCode = RET_SUCCEED;
    DBA_DYNFLD_STP*     saveExtOpTab= NULL; /* REF4083 - SSO - 991027 */
    FLAG_T              launchFusion = FALSE,   /* REF5055 - SSO - 000802 */
                        *pflagScpt = NULL;
    int                 i;
    DBA_DYNFLD_STP      pdbadynParent;
    DICT_T              dictParFct;
    FLAG_T              flagGenerateCode = FALSE;           /*  FIH-REF9037-030515  */
    FLAG_T              flagMemoDraftId;                    /*  FIH-REF10606-040930 */
    bool                closeTransaction = true;            /* PMSTA-26888 - DLA - 170630 */
    DBA_HIER_HEAD_STP   localHierHead = (DBA_HIER_HEAD_STP)NULL;
    MemoryPool          mp;
    DBA_DYNFLD_STP*     extOpTabCopy = NULL;
    FLAG_T AdjustOpeFlag = FALSE;


	SESSION_EXCEPTION_HANDLING_ENUM applSessionExceptionHandling;	/* PMSTA09118-CHU-100121 */

	GEN_GetApplInfo(ApplSessionExceptionHandling, &applSessionExceptionHandling);
    if (applSessionExceptionHandling >= SessionExceptionHandling_Last)
	{
		applSessionExceptionHandling = SessionExceptionHandling_UniqueSession;
	}

    flagMemoDraftId = FALSE;                                /*  FIH-REF10606-040930 */

    if (dbiConnHelper.isValidAndInit() == false) /* PMSTA-26888 - CHU - 170629 */
    {
        return(RET_DBA_ERR_CONNOTFOUND);
    }

    /* PMSTA-26888 - DLA - 170630 */
    if (dbiConnHelper.isInTransaction() == true)
    {
        closeTransaction = false;
    }

	/* PMSTA08500-CHU-090806 : restore portfolio Id's */
	if (pdbadynDomain != NULL												&&
		GET_ENUM(pdbadynDomain, A_Domain_LoadHierFlg) == LoadHierPtf_Full	&&
		action == Action_SaveDraftAfterPreTradeComplCheck					&&
		extOpNbr > 0)
	{
		for (i=0; i<extOpNbr; i++)
		{
			if (IS_NULLFLD(extOpTab[i], ExtOp_ChildPtfId) == FALSE &&
				CMP_ID(GET_ID(extOpTab[i], ExtOp_PtfId), GET_ID(extOpTab[i], ExtOp_ChildPtfId)) != 0)
			{
				/* restore ptfId */
				SET_ID(extOpTab[i], ExtOp_PtfId, GET_ID(extOpTab[i], ExtOp_ChildPtfId));
				/* reset child ptfId */
				SET_NULL_ID(extOpTab[i], ExtOp_ChildPtfId);
			}
		}
	}

	/* OCS-44118-CHU-140131 : Manage target_nature_e for block orders (improvement of PMSTA-15221) */
	for (i=0; i<extOpNbr; i++)
	{
        /* PMSTA-24244 - CHU - 161101 */
        if (action != Action_SaveOp && /* PMSTA-26267 - CHU - 170209 */
            (IS_NULLFLD(extOpTab[i], ExtOp_InSessionFlg) == TRUE || GET_FLAG(extOpTab[i], ExtOp_InSessionFlg) == FALSE))
            SET_FLAG_TRUE(extOpTab[i], ExtOp_InSessionFlg);

		if (GET_ENUM(extOpTab[i], ExtOp_ParOpNatEn) == ParOpNat_BlockOrder &&
			IS_NULLFLD(extOpTab[i], ExtOp_TargetNatureEn) == FALSE)
		{
			if (GET_ENUM(extOpTab[i], ExtOp_TargetNatureEn) == (ENUM_T)OpTargetNat_Quantity)
			{
				SET_AMOUNT(extOpTab[i], ExtOp_TargetNumber,
					GET_AMOUNT(extOpTab[i], ExtOp_Qty));
			}
			else if ((GET_ENUM(extOpTab[i], ExtOp_TargetNatureEn) == (ENUM_T)OpTargetNat_Amount) &&
				((pdbadynDomain != NULL) && (GET_DICT(pdbadynDomain, A_Domain_InitialFctDictId) == DictFct_AllocateOrder)))
			{                                                                     /* PMSTA-22467-cashwini-021615*/
				SET_AMOUNT(extOpTab[i], ExtOp_TargetAmount,
					GET_AMOUNT(extOpTab[i], ExtOp_OpGrossAmt));
			}
		}
	}

    /* REF4083 - SSO - 991027 */
	if(extOpNbr > 0)
    {
        /*  FIH-REF9037-030515  Particular test : reverse   action  */
        /*  See test made in DBA_FamilyOrderCreateAccess            */
        flagGenerateCode = TRUE;
        dictParFct = NullDictFct;
        if ((pdbadynDomain != NULL) &&                                                                                                              /*  FIH-PMSTA10702-101202   Final error when call from the WUI  */
            (DBA_GetDictFctInfo((DICT_FCT_ENUM) GET_DICT(pdbadynDomain, A_Domain_FctDictId),DictFctInfo_ParDictId,&dictParFct) == RET_SUCCEED) &&   /*  FIH-PMSTA10702-101202                                       */
            (dictParFct == DictFct_OrderList) &&
            (extOpNbr == 1) &&
            (DBA_GetOpIdFromExtOp(extOpTab[0]) > 0) &&
            (GET_ENUM(extOpTab[0], ExtOp_DbStatusEn) == (ENUM_T) ExtOpDbStatus_ToInsert) &&
            (GET_FLAG(extOpTab[0], ExtOp_ConfirmedFlg) == TRUE))
        {
            flagGenerateCode = FALSE;
        }

		/* PMSTA09118-CHU-100121 : Generate draft session with rejected orders */
		/* extOpTab and caseMgtTab may be updated */
		if (action == Action_SaveOp	&&
            pdbadynDomain != NULL	&&
            splitSessionPerformedFlg == false &&                                                      /* PMSTA-31673 - CHU - 180607 : to know if session splitting was already performed */
			(((EVTGEN_ENUM)GET_ENUM(pdbadynDomain, A_Domain_EvtGenNatEn) == EvtGen_CheckAndPublish && /* PMSTA-14384-CHU-120613 */
			applSessionExceptionHandling == SessionExceptionHandling_SplitSession)
            ||
            (EVTGEN_ENUM)GET_ENUM(pdbadynDomain, A_Domain_EvtGenNatEn) == EvtGen_CheckSplitAndPublish
            || (EVTGEN_ENUM)GET_ENUM(pdbadynDomain, A_Domain_EvtGenNatEn) == EvtGen_CheckCaseSplitAndPublish)) /* PMSTA-28596 - CHU - 170926 */
		{
            /* < PMSTA-28596  - CHU - 170926 */
            bool closeLocalTransaction = false;
            if (dbiConnHelper.isInTransaction() == false)
            {
                closeLocalTransaction = true;
                dbiConnHelper.beginTransaction();
            }
            /* > PMSTA-28596  - CHU - 170926 */
			if ((ret=DBA_NewSplitSession(&extOpTab, &extOpNbr,
										 options,
										 pdbadynDomain,
										 &caseMgtTab, &caseMgtNbr,
										 draftFctResPtr,
                                         &dbiConnHelper.getId(),
                                         argHierHead)) != RET_SUCCEED)     /* PMSTA-28596 - CHU - 171012 */
			{
				/* PMSTA-14006-CHU-120402 : Special retcode to keep session in Checked status */
				if (ret == RET_DBA_ERR_KRANOTFOUND)
				{
					specialRetCode = RET_DBA_ERR_KRANOTFOUND;
					action = Action_SaveDraft;
				}
				else
				{
                    if (closeTransaction || closeLocalTransaction) /* PMSTA-28596  - CHU - 170926 */
                    {
                        dbiConnHelper.endTransaction(false); /* Rollback */
                    }
					/* dbiConn->endTransaction(FALSE);
					DBA_EndConnection(&dbiConn);
                    */
					return(ret);
				}
			}

            /* < PMSTA-28596  - CHU - 170926 */
            if (closeLocalTransaction == true)
            {
                dbiConnHelper.endTransaction(true); /* Commit */
            }
            /* > PMSTA-28596  - CHU - 170926 */
		}

		/* PMSTA09118-CHU-100121 : extOp number could have been reduced by DBA_NewDraftSession() */
		if (extOpNbr > 0)
		{
			if ((saveExtOpTab = (DBA_DYNFLD_STP*) CALLOC(extOpNbr, sizeof(DBA_DYNFLD_STP))) == NULL)
			{
                if (closeTransaction)
                {
                    dbiConnHelper.endTransaction(false); /* Rollback */
                }

                /* dbiConn->endTransaction(FALSE);
                DBA_EndConnection(&dbiConn);
                */
                MSG_RETURN(RET_MEM_ERR_ALLOC);
			}

			/* Reading extOpTab element and action, extOpAccessTab */
			/* and opAccessTab will be allocated and initialised.  */
			if ((ret = DBA_FamilyOrderCreateAccess (action, extOpTab, extOpNbr, colNbr,
													&extOpAccessTab, &extOpAccessNbr,
													&opAccessTab, &opAccessNbr,
										   			saveExtOpTab,
													&launchFusion,				        /* REF4083 - SSO - 991027 */
													pdbadynDomain,                      /* REF7550 - CHU - 020527 */
				                                    &flagMemoDraftId,                   /* FIH-REF10606.040930 */
				                                    dbiConnHelper)) != RET_SUCCEED)     /* PMSTA-44673 - DDV - 210426 */
			{
				DBA_FreeDynStTab(saveExtOpTab, extOpNbr, ExtOp); /* REF4083 - SSO - 991027 */
                if (closeTransaction) /* PMSTA-28596  - CHU - 170926 */
                {
                    dbiConnHelper.endTransaction(false); /* Rollback */
                }
				return(ret);
			}
			else if (action == Action_SaveDraftOrderAllocation)
				action = Action_SaveDraft;
		}
    }

    /*  FIH-REF7414-020503  Manage parent code attribute    */
    if ((action == Action_SaveOp) &&
        (opAccessNbr > 0) &&
        (flagGenerateCode == TRUE))     /*  FIH-REF9037-030515  Particular test : reverse   action  */
    {
		if ((pflagScpt = (FLAG_T*) CALLOC(GET_FLD_NBR(ExtOp),sizeof(FLAG_T))) == NULL)      /*  FIH-REF9037-030515  Code moved to avoid unfreed memory  */
		{
            if (closeTransaction) /* PMSTA-28596  - CHU - 170926 */
            {
                dbiConnHelper.endTransaction(false); /* Rollback */
            }
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

	    memset(pflagScpt, 1, GET_FLD_NBR(ExtOp)*sizeof(FLAG_T));
	    pflagScpt[ExtOp_Cd] = 0;                    /* Seul le code est analys� */

        /* PMSTA-54624 - SRS - 240118   Changes done to handle PMSTA-37840 */
        /* When the user creates a session, */
        /* the adjustment order is first recorded in the database with the default method of setting an order code* */
        /* and the order code of the adjustment order is suffixed with –A and stored as the order code for the Buy order.*/
        /* Example: If the order code set for the ‘adjustment’ operation is AAAPORTABC0001.The order code for the Buy order will be ‘AAAPORTABC0001 - A’. */
        /* Hier was dumped and link was created between buy and respective adjustemnt and later used in keyword to fetch code and return the same */

        if ((localHierHead = DBA_CreateHier()) == (DBA_HIER_HEAD_STP)NULL)
        {
            return(RET_DBA_ERR_HIER);
        }

        for (i = 0; i < opAccessNbr; i++)
        {
            if ((IS_NULLFLD(extOpTab[i], ExtOp_Cd) == TRUE) && (GET_ENUM(extOpTab[i], ExtOp_NatureEn) == OpNat_Adjust))
            {
                AdjustOpeFlag = TRUE;
                break;
            }
        }
        if (AdjustOpeFlag == TRUE)
        {
            if ((extOpTabCopy = (DBA_DYNFLD_STP*)CALLOC(opAccessNbr, sizeof(DBA_DYNFLD_STP))) == NULL)
            {
                MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "DBA_DYNFLD_STP");
            }
            for (i = 0; i < opAccessNbr; i++)
            {
                /* Allocate memory for extended operation record */
                if (((extOpTabCopy)[i] = ALLOC_DYNST(ExtOp)) == NULL)
                {
                    MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtOp");
                }
                COPY_DYNST(extOpTabCopy[i], extOpTab[i], ExtOp);
                DBA_AddHierRecord(localHierHead, extOpTabCopy[i], ExtOp, FALSE, HierAddRec_NoLnk);
            }
            DBA_SetHierLnkUsed(localHierHead, ExtOp, ExtOp_ParAdjExtOp_Ext);
            DBA_MakeSpecRecLinks(localHierHead, ExtOp, ExtOp_ParAdjExtOp_Ext);
            mp.ownerPtr(extOpTabCopy);
        }
        /* PMSTA-54624 - SRS - 240118 */

        /* G�n�ration automatique du ExtOp_Cd pour les ordres globaux */
        for (i=0; i < opAccessNbr; i++)
        {
			/* REF7635 - CHU - 020814
            SET_NULL_ID(opAccessTab[i].data, ExtOp_ExecOpId);
			*/

            if ((opAccessTab[i].data != NULL) &&
                (IS_NULLFLD(opAccessTab[i].data, ExtOp_Cd) == TRUE) &&
                (IS_NULLFLD(opAccessTab[i].data, ExtOp_ParOpNatEn) == FALSE))
                SCPT_ComputeScreenDV(EOp,
                                     dictidFunction,
                                     pflagScpt,
                                     NULL,              /* HFI-PMSTA-25327-171023  Dedicated flag tab for filter    */
                                     opAccessTab[i].data,
                                     NULL,
                                     pdbadynDomain,
                                     NULLDYNST,   /* PMSTA13283 - DDV - 120117 */
                                     TRUE,				/* analyse type */
                                     TRUE,				/* guiFlag */
                                     EvalType_DefVal,   /* FPL-REF9507-030929  Only Def val    */
                                     0,					/* attribIdx */
                                     &(dbiConnHelper.getId()), /* connectNo */ /* PMSTA-28940 - CHU - 171107 */
                                     NULL,				/* filterTab */
                                     localHierHead,	            /* hierHead */ /* PMSTA-54624 - SRS - 240118 */
                                     0,
                                     DictScreen,        /*  FIH-REF9789-040209  */
                                     NULL,
                                     NULL,
                                     NULL,
                                     NULL,
                                     NULL,
                                     NullEntity,
                                     FALSE,
                                     FALSE,
                                     0);        /*  FPL-REF9215-030811  Flag Impact */
        } 
        /* PMSTA-54624 - SRS - 240118 */
        if (AdjustOpeFlag == TRUE)
        {
            for (i = 0; i < opAccessNbr; i++)
            {
                if (IS_NULLFLD(opAccessTab[i].data, ExtOp_Cd) == FALSE)
                {
                    COPY_DYNFLD(extOpTabCopy[i], ExtOp, ExtOp_Cd, extOpTab[i], ExtOp, ExtOp_Cd);
                }
            }
            DBA_SetHierLnkUsed(localHierHead, ExtOp, ExtOp_ParAdjExtOp_Ext);
            DBA_MakeSpecRecLinks(localHierHead, ExtOp, ExtOp_ParAdjExtOp_Ext);

            for (i = 0; i < opAccessNbr; i++)
            {
                if ((opAccessTab[i].data != NULL) &&
                    (IS_NULLFLD(opAccessTab[i].data, ExtOp_Cd) == TRUE) &&
                    (IS_NULLFLD(opAccessTab[i].data, ExtOp_ParOpNatEn) == FALSE) &&
                    ((GET_ENUM(opAccessTab[i].data, ExtOp_NatureEn) == OpNat_Buy) || (GET_ENUM(opAccessTab[i].data, ExtOp_NatureEn) == OpNat_Sell)))
                    SCPT_ComputeScreenDV(EOp,
                        dictidFunction,
                        pflagScpt,
                        NULL,              /* HFI-PMSTA-25327-171023  Dedicated flag tab for filter    */
                        opAccessTab[i].data,
                        NULL,
                        pdbadynDomain,
                        NULLDYNST,   /* PMSTA13283 - DDV - 120117 */
                        TRUE,				/* analyse type */
                        TRUE,				/* guiFlag */
                        EvalType_DefVal,   /* FPL-REF9507-030929  Only Def val    */
                        0,					/* attribIdx */
                        &(dbiConnHelper.getId()), /* connectNo */ /* PMSTA-28940 - CHU - 171107 */
                        NULL,				/* filterTab */
                        localHierHead,
                        0,
                        DictScreen,        /*  FIH-REF9789-040209  */
                        NULL,
                        NULL,
                        NULL,
                        NULL,
                        NULL,
                        NullEntity,
                        FALSE,
                        FALSE,
                        0);        /*  FPL-REF9215-030811  Flag Impact */
            }
        }
        /* Managing child extOp */
        for (i=0; i < opAccessNbr; i++)
        {
            /* Ajout du ExtOp_ParOpCd pour les ParOpNat_ChildOrder */
            if ((opAccessTab[i].data != NULL) &&
                (IS_NULLFLD(opAccessTab[i].data, ExtOp_ParOpNatEn) == FALSE) &&
                ((GET_ENUM(opAccessTab[i].data, ExtOp_ParOpNatEn) == ParOpNat_ChildOrder) ||
                 (GET_ENUM(opAccessTab[i].data, ExtOp_ParOpNatEn) == ParOpNat_ChildCombinedOrder)) && /* PMSTA06760 - DDV - 080630 */
                (IS_NULLFLD(opAccessTab[i].data, ExtOp_ParOpCd) == TRUE) &&
                (IS_NULLFLD(opAccessTab[i].data, ExtOp_ParExtOp_Ext) == FALSE) &&
				(GET_EXTENSION_PTR(opAccessTab[i].data, ExtOp_ParExtOp_Ext) != NULL) &&
                ((pdbadynParent = *(GET_EXTENSION_PTR(opAccessTab[i].data, ExtOp_ParExtOp_Ext))) != NULL) &&
                (IS_NULLFLD(pdbadynParent, ExtOp_Cd) == FALSE))
            {
                COPY_DYNFLD(opAccessTab[i].data, ExtOp, ExtOp_ParOpCd, pdbadynParent, ExtOp, ExtOp_Cd);
                /*  Marche pas sans ca : means do not update its parent (AXS historical big bidouille de merde) */
                SET_ENUM(opAccessTab[i].data, ExtOp_CheckParentEn, CheckParent_Disable);
            }

            /* hier group check  */
            if ((opAccessTab[i].data != NULL) &&
                (IS_NULLFLD(opAccessTab[i].data, ExtOp_HierOperNatEn) == FALSE) &&
                (HierOpNatEn::HierOpNat_ChildOrder == static_cast<HierOpNatEn>(GET_ENUM(opAccessTab[i].data, ExtOp_HierOperNatEn))) &&
                (IS_NULLFLD(opAccessTab[i].data, ExtOp_HierOperationCd) == TRUE) &&
                (IS_NULLFLD(opAccessTab[i].data, ExtOp_ParExtOp_Ext) == FALSE) &&
                (GET_EXTENSION_PTR(opAccessTab[i].data, ExtOp_ParExtOp_Ext) != NULL) &&
                ((pdbadynParent = *(GET_EXTENSION_PTR(opAccessTab[i].data, ExtOp_ParExtOp_Ext))) != NULL) &&
                (IS_NULLFLD(pdbadynParent, ExtOp_Cd) == FALSE))
            {

                COPY_DYNFLD(opAccessTab[i].data, ExtOp, ExtOp_HierOperationCd, pdbadynParent, ExtOp, ExtOp_Cd);
                SET_ENUM(opAccessTab[i].data, ExtOp_CheckParentEn, CheckParent_Disable);
            }

			/* < OCS41071-CHU-120723 : treat check_parent_e for NoGrouping orders as well */
            if ((opAccessTab[i].data != NULL) &&
                (IS_NULLFLD(opAccessTab[i].data, ExtOp_ParOpNatEn) == FALSE) &&
                (GET_ENUM(opAccessTab[i].data, ExtOp_ParOpNatEn) == ParOpNat_NoGrouping))
            {
                /*  Marche pas sans ca : means do not update its parent (AXS historical big bidouille de merde) */
                SET_ENUM(opAccessTab[i].data, ExtOp_CheckParentEn, CheckParent_Disable);
            }
			/* > OCS41071-CHU-120723 */
        }
        FREE(pflagScpt);
    }
    else /* < PMSTA-25183 - CHU - 161129 */
    {
        if (!DBA_GetOrderCodeInSessionSysParam() &&
            (action == Action_SaveDraft ||
            action == Action_SaveDraftAfterPreTradeComplCheck) &&
            (extOpAccessNbr > 0) &&
            (flagGenerateCode == TRUE))
        {
		    if ((pflagScpt = (FLAG_T*) CALLOC(GET_FLD_NBR(ExtOp),sizeof(FLAG_T))) == NULL)      /*  FIH-REF9037-030515  Code moved to avoid unfreed memory  */
		    {
                if (closeTransaction) /* PMSTA-28596  - CHU - 170926 */
                {
                    dbiConnHelper.endTransaction(false); /* Rollback */
                }
			    MSG_RETURN(RET_MEM_ERR_ALLOC);
		    }

	        memset(pflagScpt, 1, GET_FLD_NBR(ExtOp)*sizeof(FLAG_T));
	        pflagScpt[ExtOp_Cd] = 0;                    /* Seul le code est analys� */

            /* G�n�ration automatique du ExtOp_Cd pour les ordres globaux */
            for (i = 0; i < extOpAccessNbr; i++)
            {
                if ((extOpAccessTab[i].data != NULL) &&
                    (IS_NULLFLD(extOpAccessTab[i].data, ExtOp_Cd) == TRUE) &&
                    (IS_NULLFLD(extOpAccessTab[i].data, ExtOp_ParOpNatEn) == FALSE))
                    SCPT_ComputeScreenDV(EOp,
                                         dictidFunction,
                                         pflagScpt,
                                         NULL,              /* HFI-PMSTA-25327-171023  Dedicated flag tab for filter    */
                                         extOpAccessTab[i].data,
                                         NULL,
                                         pdbadynDomain,
                                         NULLDYNST,   /* PMSTA13283 - DDV - 120117 */
                                         TRUE,				/* analyse type */
                                         TRUE,				/* guiFlag */
                                         EvalType_DefVal,   /* FPL-REF9507-030929  Only Def val    */
                                         0,					/* attribIdx */
                                         &(dbiConnHelper.getId()), /* connectNo */ /* PMSTA-28940 - CHU - 171107 */
                                         NULL,				/* filterTab */
                                         NULL,	            /* hierHead */
                                         0,
                                         DictScreen,        /*  FIH-REF9789-040209  */
                                         NULL,
                                         NULL,
                                         NULL,
                                         NULL,
                                         NULL,
                                         NullEntity,
                                         FALSE,
                                         FALSE,
                                         0);        /*  FPL-REF9215-030811  Flag Impact */
            }
            /* Managing child extOp */
            for (i = 0; i < extOpAccessNbr; i++)
            {
                /* Ajout du ExtOp_ParOpCd pour les ParOpNat_ChildOrder */
                if ((extOpAccessTab[i].data != NULL) &&
                    (IS_NULLFLD(extOpAccessTab[i].data, ExtOp_ParOpNatEn) == FALSE) &&
                    ((GET_ENUM(extOpAccessTab[i].data, ExtOp_ParOpNatEn) == ParOpNat_ChildOrder) ||
                    (GET_ENUM(extOpAccessTab[i].data, ExtOp_ParOpNatEn) == ParOpNat_ChildCombinedOrder)) && /* PMSTA06760 - DDV - 080630 */
                    (IS_NULLFLD(extOpAccessTab[i].data, ExtOp_ParOpCd) == TRUE) &&
                    (IS_NULLFLD(extOpAccessTab[i].data, ExtOp_ParExtOp_Ext) == FALSE) &&
                    (GET_EXTENSION_PTR(extOpAccessTab[i].data, ExtOp_ParExtOp_Ext) != NULL) &&
                    ((pdbadynParent = *(GET_EXTENSION_PTR(extOpAccessTab[i].data, ExtOp_ParExtOp_Ext))) != NULL) &&
                    (IS_NULLFLD(pdbadynParent, ExtOp_Cd) == FALSE))
                {
                    COPY_DYNFLD(extOpAccessTab[i].data, ExtOp, ExtOp_ParOpCd, pdbadynParent, ExtOp, ExtOp_Cd);
                    /*  Marche pas sans ca : means do not update its parent (AXS historical big bidouille de merde) */
                    SET_ENUM(extOpAccessTab[i].data, ExtOp_CheckParentEn, CheckParent_Disable);
                }

                /* hier group check   */
                if ((extOpAccessTab[i].data != NULL) &&
                    (IS_NULLFLD(extOpAccessTab[i].data, ExtOp_HierOperNatEn) == FALSE) &&
                    (HierOpNatEn::HierOpNat_ChildOrder == static_cast<HierOpNatEn>(GET_ENUM(extOpAccessTab[i].data, ExtOp_HierOperNatEn))) &&
                    (IS_NULLFLD(extOpAccessTab[i].data, ExtOp_HierOperationCd) == TRUE) &&
                    (IS_NULLFLD(extOpAccessTab[i].data, ExtOp_ParExtOp_Ext) == FALSE) &&
                    (GET_EXTENSION_PTR(extOpAccessTab[i].data, ExtOp_ParExtOp_Ext) != NULL) &&
                    ((pdbadynParent = *(GET_EXTENSION_PTR(extOpAccessTab[i].data, ExtOp_ParExtOp_Ext))) != NULL) &&
                    (IS_NULLFLD(pdbadynParent, ExtOp_Cd) == FALSE))
                {
                    COPY_DYNFLD(extOpAccessTab[i].data, ExtOp, ExtOp_HierOperationCd, pdbadynParent, ExtOp, ExtOp_Cd);
                    SET_ENUM(extOpAccessTab[i].data, ExtOp_CheckParentEn, CheckParent_Disable);

                }

			    /* < OCS41071-CHU-120723 : treat check_parent_e for NoGrouping orders as well */
                if ((extOpAccessTab[i].data != NULL) &&
                    (IS_NULLFLD(extOpAccessTab[i].data, ExtOp_ParOpNatEn) == FALSE) &&
                    (GET_ENUM(extOpAccessTab[i].data, ExtOp_ParOpNatEn) == ParOpNat_NoGrouping))
                {
                    /*  Marche pas sans ca : means do not update its parent (AXS historical big bidouille de merde) */
                    SET_ENUM(extOpAccessTab[i].data, ExtOp_CheckParentEn, CheckParent_Disable);
                }
			    /* > OCS41071-CHU-120723 */
            }
            FREE(pflagScpt);
        }
    } /* > PMSTA-25183 - CHU - 161129 */

    /* Appel d'une fonction fournie en param�tres avant les appels BD */
    /* Mais dans la m�me transaction */
    if (fct != NULL && ret == RET_SUCCEED)  /* REF7264 - PMO */
    {
        /* Before loop. */
        if ((ret = fct(FALSE, action, extOpTab, extOpNbr, colNbr, &(dbiConnHelper.getId()), dataPtr)) != RET_SUCCEED)
        {
            if (dbiConnHelper.emptyMsg())
            {
                char error[100];
                sprintf((char*)&error,"Unable to complete action (error %d without associated message). You have to retry.", ret);
                MSG_SendMesg(RET_SRV_LIB_ERR_GENERAL, 0, FILEINFO, (char*)&error);

                MSG_FillMsgStruct(dbiConnHelper.getNewErrMsgInfoStp(FILEINFO),
                                  RET_SRV_LIB_ERR_GENERAL,
                                  error,
                                  NullHandler,
                                  RET_LEV_TECH_C_ERROR,
                                  TRUE,
                                  NULL,
                                  NULL,
                                  0);
            }
        }
    }

    if (ret != RET_SUCCEED)
    {
        if (closeTransaction)
        {
            dbiConnHelper.endTransaction(false); /* Rollback */
        }
    }
	else
	{
		/* REF11338 - CHU - 051011 : take care of extop confirmed flag ! */
        if ((action == Action_SaveOp) && (pdbadynDomain != NULL))
        {
            dictParFct = NullDictFct;
            DBA_GetDictFctInfo(GET_DICT(pdbadynDomain, A_Domain_FctDictId),DictFctInfo_ParDictId,&dictParFct);  /*  FPL-PMSTA08801-100714 cast  */
            if (/* (dictParFct == DictFct_EventGeneration) ||	*/	/* REF11338 to be done for this fct ??? */
                /* (dictParFct == DictFct_OrderAllocation) ||   */	/* REF11338 to be done for this fct ??? */
				(dictParFct == DictFct_OrderEntry) ||
                (dictParFct == DictFct_ReconcStrat) ||
                (dictParFct == DictFct_AllocateOrder) ||
                (dictParFct == DictFct_ManageSession) || /* PMSTA-31804 - CHU - 180625 */
                (dictParFct == DictFct_ManagePayout)     /* PMSTA-30894 - CHU - 180711 */
				/* PMSTA-22284 : Undo Check&Publish fix as not in line with business
                ||
				((dictParFct == DictFct_PreTradeCheckStrat) &&	 /-*PMSTA-22284- cashwini -160202*-/
				  ((EVTGEN_ENUM)GET_ENUM(pdbadynDomain, A_Domain_EvtGenNatEn) == EvtGen_CheckAndPublish)) */   /* PMSTA-22284 - CHU - 160204 : ceinture/bretelles... et bien align�es pour �viter une nuit blanche � HFI... zut, mince, crotte, flute, l� je me rend compte que mon commentaire commence s�rieusement � d�passer les pauvres quatre-vingt carat�res affichables par son �cran ant�diluvien */
				)
            {
                dbiConnHelper.getConnection()->getConnStructPtr()->preserveConfirmedFlg = TRUE;
            }
        }

		/* < REF7635 - CHU - 020618 */
		/* Split extop tables in case of SaveDraft and dispatch parent ids to children */
		/* REF7768 - RAK - 021009 - New action Action_SaveDraftAfterPreTradeComplCheck */
		if ((action == Action_SaveDraft ||
			 action == Action_SaveDraftAfterPreTradeComplCheck) && (extOpNbr > 0))
		{
			DBA_ACCESS_STP	extOpChildTab	= NULL;
			DBA_ACCESS_STP	opChildTab		= NULL;
			DBA_ACCESS_STP	extOpParentTab	= NULL;
			DBA_ACCESS_STP	opParentTab		= NULL;
            DBA_ACCESS_STP	extOpHierParTab = NULL;
            DBA_ACCESS_STP	extOpHierChildTab = NULL;
            DBA_ACCESS_STP	opHierParTab = NULL;
            DBA_ACCESS_STP	opHierChildTab = NULL;

			int				extOpChildNbr	= 0;
			int				opChildNbr		= 0;
			int				extOpParentNbr	= 0;
			int				opParentNbr		= 0;
            int				extOpHierChildNbr = 0;
            int				extOpHierParNbr = 0;
            int				opHierChildNbr = 0;
            int				opHierParNbr = 0;

			/* Split the bunch of extOps and Ops into Parent & Child */
			/* Function allocates new arrays, records are not duplicated */
			if ((ret = DBA_SplitOrderFamily(extOpAccessTab,
											extOpAccessNbr,
											opAccessTab,
											opAccessNbr,
											&extOpParentTab,
											&extOpParentNbr,
											&opParentTab,
											&opParentNbr,
											&extOpChildTab,
											&extOpChildNbr,
											&opChildTab,
                                            &opChildNbr,
                                            &extOpHierParTab,
                                            &extOpHierParNbr,
                                            &extOpHierChildTab,
                                            &extOpHierChildNbr,
                                            &opHierParTab,
                                            &opHierParNbr,
                                            &opHierChildTab,
                                            &opHierChildNbr)) == RET_SUCCEED)
			{
				/* Save [Parent] extOps and Ops first to get their Ids */
                OPE_GenerateExtOpCodeForSaveDraft(dictidFunction, extOpParentTab, extOpParentNbr, pdbadynDomain); /* PMSTA-25183 - CHU - 161109 */
				/* REF7768 - RAK - 021009 - new param action */
				if ((ret = DBA_FamilyOrderAccess(action, extOpParentTab, extOpParentNbr,
												 opParentTab, opParentNbr,
												 NULL,	0,	/* PMSTA07121-CHU-081030 - Cases are associated to a session */
                                                 &(dbiConnHelper.getId()),
												 options,
                                                 flagMemoDraftId,           /*  FIH-REF10606-040930 */
                                                 pdbadynDomain)) == RET_SUCCEED)             /* PMSTA31563-JPR-180531 */
				{
					/* Update Children with Parent Ids */
					DBA_DispatchOrderFamilyParentId(extOpChildTab,	extOpChildNbr,
													opChildTab,		opChildNbr);

					/* Then, save [Children] extOps and Ops */
                    OPE_GenerateExtOpCodeForSaveDraft(dictidFunction, extOpChildTab, extOpChildNbr, pdbadynDomain); /* PMSTA-25183 - CHU - 161109 */
                    OPE_GenerateOrderCheckForSaveDraft(dictidFunction, extOpChildTab, extOpChildNbr, pdbadynDomain); /* PMSTA-38901 - sanand - 25022020 */
                    /* REF7768 - RAK - 021009 - new param action */
					ret = DBA_FamilyOrderAccess(action, extOpChildTab,extOpChildNbr,
												opChildTab, opChildNbr,
												caseMgtTab,	caseMgtNbr,	/* PMSTA07121-CHU-081030 */
                                                &(dbiConnHelper.getId()),
												options,
                                                flagMemoDraftId,           /*  FIH-REF10606-040930 */
                                                pdbadynDomain);             /* PMSTA31563-JPR-180531 */

				}

                if (ret == RET_SUCCEED)
                {
                    /* process hier parent - child */
                    /* Save [Parent] extOps and Ops first to get their Ids */
                    OPE_GenerateExtOpCodeForSaveDraft(dictidFunction, extOpHierParTab, extOpHierParNbr, pdbadynDomain); /* PMSTA-25183 - CHU - 161109 */
                    /* REF7768 - RAK - 021009 - new param action */
                    if ((ret = DBA_FamilyOrderAccess(action, extOpHierParTab, extOpHierParNbr,
                                                     opHierParTab, opHierParNbr,
                                                     NULL, 0,	/* PMSTA07121-CHU-081030 - Cases are associated to a session */
                                                     &(dbiConnHelper.getId()),
                                                     options,
                                                     flagMemoDraftId,           /*  FIH-REF10606-040930 */
                                                     pdbadynDomain)) == RET_SUCCEED)             /* PMSTA31563-JPR-180531 */
                    {
                        /* Update Children with Parent Ids */
                        DBA_DispatchOrderFamilyParentId(extOpHierChildTab, extOpHierChildNbr,
                                                        opHierChildTab, opHierChildNbr);

                        /* Then, save [Children] extOps and Ops */
                        OPE_GenerateExtOpCodeForSaveDraft(dictidFunction, extOpHierChildTab, extOpHierChildNbr, pdbadynDomain); /* PMSTA-25183 - CHU - 161109 */
                        OPE_GenerateOrderCheckForSaveDraft(dictidFunction, extOpHierChildTab, extOpHierChildNbr, pdbadynDomain); /* PMSTA-38901 - sanand - 25022020 */
                        /* REF7768 - RAK - 021009 - new param action */
                        ret = DBA_FamilyOrderAccess(action, extOpHierChildTab, extOpHierChildNbr,
                                                    opHierChildTab, opHierChildNbr,
                                                    caseMgtTab, caseMgtNbr,	/* PMSTA07121-CHU-081030 */
                                                    &(dbiConnHelper.getId()),
                                                    options,
                                                    flagMemoDraftId,           /*  FIH-REF10606-040930 */
                                                    pdbadynDomain);             /* PMSTA31563-JPR-180531 */

                    }
                }

				FREE(extOpParentTab);
				FREE(opParentTab);
				FREE(extOpChildTab);
				FREE(opChildTab);
                FREE(extOpHierParTab);
                FREE(opHierParTab);
                FREE(extOpHierChildTab);
                FREE(opHierChildTab);
			}
		}
		else /* REF7635 - CHU - 020618 > */
		{
            /* PMSTA-25183 - CHU - 161109 : most probably not needed here as extOp's already got a code during SaveDraft */
            /* OPE_GenerateExtOpCodeForSaveDraft(dictidFunction, extOpAccessTab, extOpAccessNbr, pdbadynDomain); */
			/* REF7768 - RAK - 021009 - new param action */
			ret = DBA_FamilyOrderAccess(action, extOpAccessTab,	extOpAccessNbr,
										opAccessTab, opAccessNbr,
										caseMgtTab,	caseMgtNbr,	/* PMSTA07121-CHU-081030 */
                                        &(dbiConnHelper.getId()),
                                        options,
                                        flagMemoDraftId,            /*  FIH-REF10606-040930 */
                                        pdbadynDomain);             /* PMSTA31563-JPR-180531 */
        }

		/* REF4126 */
		if (fct != NULL && ret == RET_SUCCEED) /* REF7264 - PMO */
        {
            /* After loop. */
            if ((ret = fct(TRUE, action, extOpTab, extOpNbr, colNbr, &(dbiConnHelper.getId()), dataPtr)) != RET_SUCCEED)
            {
                if (dbiConnHelper.emptyMsg())
                {
                    char error[100];
                    sprintf((char*)&error,"Unable to complete action (error %d without associated message). You have to retry.", ret);
                    MSG_SendMesg(RET_SRV_LIB_ERR_GENERAL, 0, FILEINFO, (char*)&error);

                    MSG_FillMsgStruct(dbiConnHelper.getNewErrMsgInfoStp(FILEINFO),
                                      RET_SRV_LIB_ERR_GENERAL,
                                      error,
                                      NullHandler,
                                      RET_LEV_TECH_C_ERROR,
                                      TRUE,
                                      NULL,
                                      NULL,
                                      0);
                }
            }
        }

		if (ret != RET_SUCCEED)
		{
            if (closeTransaction)
            {
                dbiConnHelper.endTransaction(false); /* Rollback */
            }
        }
		else
        {
            if (closeTransaction)
            {
                dbiConnHelper.endTransaction(TRUE);            /* Commit. */
            }

			/* Call fusion All Ptf/New Op if any extended operations inserted */
            if (opAccessNbr > 0 && launchFusion == TRUE)  /* REF5055 - SSO - 000802 */
			{
                if (DBA_FusionRequestAllPtfNewOp(UNUSED, NO_VALUE) != RET_SUCCEED) /* PMSTA-26267 - CHU - 170301 */
                {
					MSG_SendMesg(RET_FIN_ERR_FUSIONFAILED, 5, FILEINFO, "DBA_FamilyOrder");
                }
			}
		}
    }

    /*  FIH-REF8032-021008  After a successful save session conformed flag must be set to TRUE  */
    if (ret == RET_SUCCEED)
    {
        if ((action == Action_SaveOp) &&
            (pdbadynDomain != NULL))
        {
            dictParFct = NullDictFct;
            DBA_GetDictFctInfo(GET_DICT(pdbadynDomain, A_Domain_FctDictId),DictFctInfo_ParDictId,&dictParFct);  /*  FPL-PMSTA08801-100714 cast  */
            if ((dictParFct == DictFct_EventGeneration) ||			/* REF11338 to be avoided for this fct ??? */
				(dictParFct == DictFct_OrderAllocation) /* || */	/* REF11338 to be avoided for this fct ??? */
                /* (dictParFct == DictFct_OrderEntry) || */			/* REF11338 - CHU - 051011 */
                /* (dictParFct == DictFct_ReconcStrat) || */		/* REF11338 - CHU - 051011 */
                /* (dictParFct == DictFct_AllocateOrder)*/ )		/* REF11338 - CHU - 051011 */
            {
                for (i=0; i < opAccessNbr; i++)
                    SET_FLAG(opAccessTab[i].data,ExtOp_ConfirmedFlg,TRUE);
            }
        }
        /*  FIH-REF10739-041026  Refresh Operation Last modif date      */
        for (i = 0; i < opAccessNbr; i++)
            if (IS_NULLFLD(opAccessTab[i].data, ExtOp_AudModifDate) == FALSE)
                DBA_ExtOpUpdateTimeStamp(opAccessTab[i].data); /* PMSTA-26252 - LJE - 170303 */
    }

	if(extOpNbr > 0)
	{
		FREE(opAccessTab);
		FREE(extOpAccessTab);
	}
    /* PMSTA-54624 - SRS - 240118 */
    if (localHierHead != (DBA_HIER_HEAD_STP)NULL) {
        DBA_FreeHier(localHierHead);
    }

    if ((ret != RET_SUCCEED) && (extOpNbr > 0)) /* REF4083 - SSO - 991027 */
    {
		DBA_FamilyOrderOnError(extOpTab, extOpNbr, colNbr, saveExtOpTab);
    }

    if(extOpNbr > 0)
    {
		DBA_FreeDynStTab(saveExtOpTab, extOpNbr, ExtOp); /* REF4083 - SSO - 991027 */
    }   

	if (specialRetCode == RET_DBA_ERR_KRANOTFOUND)
		return (specialRetCode);

    return(ret);
}

/************************************************************************
**
**  Function    :   DBA_FamilyOrderCreateAccess.
**
**  Description :   According to an EXCEL tab, create ExtOp access table and
**                  Op access table (if necessary).
**
**  Arguments   :   action          current action (depending on fin. function)
**                  extOpTab        ExtOp table
**                  extOpNbr        ExtOp number
**                  extOpAccessPtr  pointer on ExtOp access table
**                  extOpAccessNbr  pointer on ExtOp access number
**                  opAccessPtr     pointer on Op access table
**                  opAccessNbr     pointer on Op access number
**
**  Return      :   RET_CODE.
**
**  Cr�ation    :   RAK - 990705 - REF3742.
**  Modif.		:   ROI - 990823 - REF3742.
**		    REF4083 - SSO - 991027   saving extop for error handling
**          REF5055 - SSO - 000802 added launchFusion parameter
**          REF8500 - 040510 - PMO : Add a draft_order_id in extended operation to distinguish the id from extended orders and the one from extended operation
*************************************************************************/
STATIC RET_CODE DBA_FamilyOrderCreateAccess(EXTOP_ACTION_ENUM   action,
                                            DBA_DYNFLD_STP      *extOpTab,
                                            int                 extOpNbr,
                                            int                 colNbr,
                                            DBA_ACCESS_STP      *extOpAccessPtr,
                                            int                 *extOpAccessNbr,
                                            DBA_ACCESS_STP      *opAccessPtr,
                                            int                 *opAccessNbr,
                                            DBA_DYNFLD_STP      *saveExtOpTab,
                                            FLAG_T              *launchFusion,	    /* REF4083 - SSO - 991027 */
											DBA_DYNFLD_STP      domainPtr,		    /* REF7550 - CHU - 020527 */
	                                        FLAG_T              *pflagMemoDraftId,  /* FIH-REF10606-040930 */
	                                        DbiConnectionHelper &dbiConnHelper)     /* PMSTA-44673 - DDV - 210426 */
{
    int		    i=0;
    RET_CODE	    ret=RET_SUCCEED;
    DBA_DYNFLD_STP  extOpPtr=NULL, dynTab;
    DBA_DYNFLD_STP  saveExtOpPtr=NULL;      /* REF4083 - SSO - 991027 */
    DBA_DYNFLD_STP  ptfPtr=NULLDYNST;
    OPSTAT_ENUM     accountingStatus;       /* REF5055 - SSO - 000802 */
    DICT_T          dictParFct;
    FLAG_T          allocFlg = FALSE;


    *extOpAccessPtr = NULL;
    *extOpAccessNbr = 0;
    *opAccessPtr    = NULL;
    *opAccessNbr    = 0;
    GEN_GetApplInfo(ApplAccountingStatus, &accountingStatus);           /* REF5055 - SSO - 000802 */

    if (((*extOpAccessPtr) = (DBA_ACCESS_STP)CALLOC(extOpNbr, sizeof(DBA_ACCESS_ST))) == NULL)
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    if (action == Action_SaveOp)
    {
        if (((*opAccessPtr) = (DBA_ACCESS_STP)CALLOC(extOpNbr, sizeof(DBA_ACCESS_ST))) == NULL)
        {
            FREE((*extOpAccessPtr));
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }
    }

    /*  FIH-REF7560-020924  */
    dictParFct = NullDictFct;
    if (domainPtr != NULL)
        DBA_GetDictFctInfo(GET_DICT(domainPtr, A_Domain_FctDictId),DictFctInfo_ParDictId,&dictParFct);  /*  FPL-PMSTA08801-100714 cast  */

    /*  Order entry already saved op (draft)    */  /*  FIH-REF10606-040925 */
    if (pflagMemoDraftId != NULL)
        *pflagMemoDraftId = FALSE;

    for (i=0; i<extOpNbr; i++)
    {
        /* In case of array is not a real dynamic structure array (GUI) */
        if (colNbr == 0)
            extOpPtr = extOpTab[i];
        else
        {
            /* in fact, in that case we don't receive a DBA_DYNFLD_STP * (cast by GUI) */
            dynTab = (DBA_DYNFLD_STP) extOpTab;
            extOpPtr = &(dynTab[i*colNbr]);
        }

        /* PMSTA09451 - DDV - 100308 - Update begin_d of ExtOperation. It is used to load orders for FinFct */
		allocFlg = FALSE;	/* PMSTA-10241 - RAK - 110509 - In case of a mix between op with link on ptf and not -> crash */
        if ((GET_EXTENSION_PTR(extOpPtr , ExtOp_A_Ptf_Ext)) != NULL)
        {
            ptfPtr = *(GET_EXTENSION_PTR(extOpPtr, ExtOp_A_Ptf_Ext));
        }

        if (ptfPtr == NULL)
        {
            DBA_GetPtfById(GET_ID(extOpPtr, ExtOp_PtfId), TRUE, &allocFlg, &ptfPtr,
                                  DBA_GetHierOptiPtr(), UNUSED, UNUSED);
        }

        DBA_UpdExtOpBeginD(extOpPtr, NULLDYNST, ptfPtr);

        if (allocFlg == TRUE)
            {FREE_DYNST(ptfPtr, A_Ptf);}

        /* REF4083 - SSO - 991027 copy for error cases... */
        if ((saveExtOpPtr = ALLOC_DYNST(ExtOp)) == NULL)
        {
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }
        COPY_DYNST(saveExtOpPtr, extOpPtr, ExtOp);
        saveExtOpTab[i] = saveExtOpPtr;

        switch(action)
        {
            case Action_SaveOp :
            {
                /* < PMSTA-25183 - CHU - 161110 */
                DBA_DYNFLD_STP  copiedExtOpPtr = NULL;
                DBA_DYNFLD_STP  extOrderPtr    = NULL;
                FLAG_T          useExtOrderFlg = FALSE;
                FLAG_T          noExternalPosInExtOpFlg = FALSE;
                ORDER_CODE_PERSISTENCE_ENUM orderCodePersistence;
                OPSTAT_ENUM		applExternalPosStatus = OpStat_Cancelled; /* PMSTA-29145 - CHU - 171116 */

                GEN_GetApplInfo(ApplOrderCodePersistence, &orderCodePersistence);
                GEN_GetApplInfo(ApplExternalPosStatus, &applExternalPosStatus);/* PMSTA-29145 - CHU - 171116 */

                if (IS_NULLFLD(extOpPtr, ExtOp_Cd) == FALSE                 &&
                    !DBA_GetOrderCodeInSessionSysParam()                    && /* returns FALSE if code generation is enabled on ext_operation */
                    orderCodePersistence != OrderCodePersistence_Enabled    && /* Save Session : ext_order code must be re-generated if orderCodePersistence is not enabled */
                    DBA_IsRejectedOrder(extOpPtr) == FALSE)                    /* PMSTA-25573 - CHU - 170502 */
                {
                    if ((copiedExtOpPtr = ALLOC_DYNST(ExtOp)) == NULL)
                    {
                        MSG_RETURN(RET_MEM_ERR_ALLOC);
                    }
                    COPY_DYNST(copiedExtOpPtr, extOpPtr, ExtOp);
                    SET_NULL_CODE(copiedExtOpPtr, ExtOp_Cd);
                    extOrderPtr = copiedExtOpPtr;
                    useExtOrderFlg = TRUE;
                }
                else
                {
                    extOrderPtr = extOpPtr;
                }
                /* > PMSTA-25183 - CHU - 161110 */

                /* < PMSTA-29145 - CHU - 171116 */
                if (applExternalPosStatus > OpStat_Cancelled &&
                    applExternalPosStatus == (OPSTAT_ENUM)GET_ENUM(extOpPtr, ExtOp_StatusEn))
                {
                    noExternalPosInExtOpFlg = TRUE;
                }
                /* > PMSTA-29145 - CHU - 171116 */

                switch (dictParFct)
                {
                    case DictFct_EventGeneration :
                    case DictFct_OrderList :
					case DictFct_OrderGrouping :	/* REF11764 - RAK - 060406 */
					case DictFct_UpdateField :	    /*  HFI-PMSTA-35324-190328  */
					case DictFct_UpdateData :	    /*  HFI-PMSTA-35324-190328  */
                    case DictFct_OrderSwitching:    /*  PMSTA-37086 - Silpakal - 190905 */
                    case DictFct_OrderNetting:    /* PMSTA - 38314 - adarsh - 27012020 */
                    case DictFct_HierarchyGrouping:    /* PMSTA - 40208 - sanand - 24092020 */
                    case DictFct_OrderSequencing:
                        if ((DBA_GetOpIdFromExtOp(extOpPtr) <= 0) &&
                            ((GET_ENUM(extOpPtr, ExtOp_DbStatusEn) == (ENUM_T) ExtOpDbStatus_SimulToInsert) ||
                             (GET_ENUM(extOpPtr, ExtOp_DbStatusEn) == (ENUM_T) ExtOpDbStatus_ToInsert)) &&
                            (GET_FLAG(extOpPtr, ExtOp_ConfirmedFlg) == TRUE) &&
                            DBA_IsRejectedOrder(extOpPtr) == FALSE) /* PMSTA-25573 - CHU - 170502 */
                        {
                            (*opAccessPtr)[(*opAccessNbr)].action = Insert;
                            (*opAccessPtr)[(*opAccessNbr)].role   = UNUSED;
                            (*opAccessPtr)[(*opAccessNbr)].object = EOp;
                            (*opAccessPtr)[(*opAccessNbr)].entity = ExtOp;

                            /* REF5055 - SSO - 000802 */
                            if ((GET_ENUM(extOpPtr, ExtOp_StatusEn) >= accountingStatus) ||
                                (GET_ENUM(extOpPtr, ExtOp_ExecOpNatEn) != ExecNat_None))
                            {
                                *launchFusion = TRUE;
                            }

                            SET_ENUM(extOpPtr, ExtOp_DbStatusEn, (ENUM_T)ExtOpDbStatus_UpToDate);

                            /* < PMSTA-25183 - CHU - 161110 : same for ext_order */
                            if (TRUE == useExtOrderFlg)
                            {
                                SET_ENUM(extOrderPtr, ExtOp_DbStatusEn, (ENUM_T)ExtOpDbStatus_UpToDate);
                                (*opAccessPtr)[(*opAccessNbr)].data = extOrderPtr; /* PMSTA-25183 - CHU - 161110 */
                            }
                            else
                            {
                                (*opAccessPtr)[(*opAccessNbr)].data = extOpPtr;
                            }
                            ++(*opAccessNbr);
                            /* > PMSTA-25183 - CHU - 161110 */
                        }
                        /* only for reverse function */
                        else if ((DBA_GetOpIdFromExtOp(extOpPtr) != 0) &&
                                 (GET_ENUM(extOpPtr, ExtOp_DbStatusEn) == (ENUM_T) ExtOpDbStatus_ToInsert) &&
                                 (GET_FLAG(extOpPtr, ExtOp_ConfirmedFlg) == TRUE) &&
                                 DBA_IsRejectedOrder(extOpPtr) == FALSE) /* PMSTA-25573 - CHU - 170502 */
                        {
                            (*opAccessPtr)[(*opAccessNbr)].action = Insert;
                            (*opAccessPtr)[(*opAccessNbr)].role   = UNUSED;
                            (*opAccessPtr)[(*opAccessNbr)].object = EOp;
                            (*opAccessPtr)[(*opAccessNbr)].entity = ExtOp;

                            /* REF5055 - SSO - 000802 */
                            if ((GET_ENUM(extOpPtr, ExtOp_StatusEn) >= accountingStatus) ||
                                (GET_ENUM(extOpPtr, ExtOp_ExecOpNatEn) != ExecNat_None))
                            {
                                *launchFusion = TRUE;
                            }

                            SET_ENUM(extOpPtr, ExtOp_DbStatusEn, (ENUM_T)ExtOpDbStatus_UpToDate);

                            /* < PMSTA-25183 - CHU - 161110 : same for ext_order */
                            if (TRUE == useExtOrderFlg)
                            {
                                SET_ENUM(extOrderPtr, ExtOp_DbStatusEn, (ENUM_T)ExtOpDbStatus_UpToDate);
                                (*opAccessPtr)[(*opAccessNbr)].data = extOrderPtr;
                            }
                            else
                            {
                                (*opAccessPtr)[(*opAccessNbr)].data = extOpPtr;
                            }
                            ++(*opAccessNbr);
                            /* > PMSTA-25183 - CHU - 161110 */
                        }
                        /* EVENT GENERATION (update) + ORDER LIST */
                        else if ((DBA_GetOpIdFromExtOp(extOpPtr) > 0) &&
                                 (GET_ENUM(extOpPtr, ExtOp_DbStatusEn) == (ENUM_T) ExtOpDbStatus_ToUpdate) &&
                                 (GET_FLAG(extOpPtr, ExtOp_ConfirmedFlg) == TRUE) &&
                                 DBA_IsRejectedOrder(extOpPtr) == FALSE) /* PMSTA-25573 - CHU - 170502 */
                        {
                            (*opAccessPtr)[(*opAccessNbr)].action = Update;
                            (*opAccessPtr)[(*opAccessNbr)].role   = UNUSED;
                            (*opAccessPtr)[(*opAccessNbr)].object = EOp;
                            (*opAccessPtr)[(*opAccessNbr)].entity = ExtOp;
                            (*opAccessPtr)[(*opAccessNbr)].data   = extOpPtr;
                            ++(*opAccessNbr);

                            /* REF5055 - SSO - 000802 */
                            if ((GET_ENUM(extOpPtr, ExtOp_StatusEn) >= accountingStatus) ||
                                (GET_ENUM(extOpPtr, ExtOp_ExecOpNatEn) != ExecNat_None))
                            {
                                *launchFusion = TRUE;
                            }

                            SET_ENUM(extOpPtr, ExtOp_DbStatusEn, (ENUM_T) ExtOpDbStatus_UpToDate);
				            SET_FLAG(extOpPtr, ExtOp_ConfirmedFlg, FALSE);			/* MRA - 010406 - REF5118 */
                        }
                        /* EVENT GENERATION (insert) */
                        else if ((DBA_GetOpIdFromExtOp(extOpPtr) <= 0) &&
                                 (GET_ENUM(extOpPtr, ExtOp_DbStatusEn) == (ENUM_T) ExtOpDbStatus_ToInsert) &&
                                 (GET_FLAG(extOpPtr, ExtOp_ConfirmedFlg) == TRUE) &&
                                 DBA_IsRejectedOrder(extOpPtr) == FALSE) /* PMSTA-25573 - CHU - 170502 */
                        {
                            (*opAccessPtr)[(*opAccessNbr)].action = Insert;
                            (*opAccessPtr)[(*opAccessNbr)].role   = UNUSED;
                            (*opAccessPtr)[(*opAccessNbr)].object = EOp;
                            (*opAccessPtr)[(*opAccessNbr)].entity = ExtOp;

                            /* REF5055 - SSO - 000802 */
                            if ((GET_ENUM(extOpPtr, ExtOp_StatusEn) >= accountingStatus) ||
                                (GET_ENUM(extOpPtr, ExtOp_ExecOpNatEn) != ExecNat_None))
                            {
                                *launchFusion = TRUE;
                            }

                            SET_ENUM(extOpPtr, ExtOp_DbStatusEn, (ENUM_T)ExtOpDbStatus_UpToDate);

                            /* < PMSTA-25183 - CHU - 161110 : same for ext_order */
                            if (TRUE == useExtOrderFlg)
                            {
                                SET_ENUM(extOrderPtr, ExtOp_DbStatusEn, (ENUM_T)ExtOpDbStatus_UpToDate);
                                (*opAccessPtr)[(*opAccessNbr)].data = extOrderPtr;
                            }
                            else
                            {
                                (*opAccessPtr)[(*opAccessNbr)].data = extOpPtr;
                            }
                            ++(*opAccessNbr);
                            /* > PMSTA-25183 - CHU - 161110 */
                        }
                        break;

                    default :
						/* REF8376 - CHU - 040609 : Ignore zero quantities for semi-auto order alloc method */
        				if ((domainPtr != NULL) &&          /*  FIH-PMSTA10702-101202   */
						    (GET_ENUM(domainPtr, A_Domain_QtyAllocNatEn) == QtyAllocNat_UnspecifiedQty) &&
							(CMP_NUMBER(GET_NUMBER(extOpPtr, ExtOp_Qty), 0.0)==0))
						{
							SET_ENUM(extOpPtr, ExtOp_DbStatusEn, ExtOpDbStatus_SimulToInsert);

                            /* < PMSTA-25183 - CHU - 161110 : same for ext_order - probably not useful here */
                            if (TRUE == useExtOrderFlg)
                            {
                                SET_ENUM(extOrderPtr, ExtOp_DbStatusEn, ExtOpDbStatus_SimulToInsert);
                            }
                            /* > PMSTA-25183 - CHU - 161110 */
							break;
						}

                        if (IS_EXTOP_DATABASE_ID_MISSING (extOpPtr) &&
                            (GET_ENUM(extOpPtr, ExtOp_DbStatusEn) == (ENUM_T) ExtOpDbStatus_SimulToInsert ||
							GET_ENUM(extOpPtr, ExtOp_DbStatusEn) == (ENUM_T) ExtOpDbStatus_ToInsert) &&
                            GET_FLAG(extOpPtr, ExtOp_ConfirmedFlg) == TRUE &&
                            (IS_NULLFLD(extOpPtr, ExtOp_OpId) == TRUE ||
                            GET_ID(extOpPtr, ExtOp_OpId) < 0) &&
                            DBA_IsRejectedOrder(extOpPtr) == FALSE) /* PMSTA-25573 - CHU - 170502 */
                        {
                            if (noExternalPosInExtOpFlg == FALSE) /* PMSTA-29145 - CHU - 171116 */
                            {
                                (*extOpAccessPtr)[(*extOpAccessNbr)].action = Insert;
                                (*extOpAccessPtr)[(*extOpAccessNbr)].role   = DBA_ROLE_RECONCILE_STRATEGY;
                                (*extOpAccessPtr)[(*extOpAccessNbr)].object = EOp;
                                (*extOpAccessPtr)[(*extOpAccessNbr)].entity = ExtOp;
                                (*extOpAccessPtr)[(*extOpAccessNbr)].data   = extOpPtr;
                                ++(*extOpAccessNbr);
                            }

                            SET_ENUM(extOpPtr, ExtOp_DbStatusEn, (ENUM_T)ExtOpDbStatus_SimulUpToDate);
                            SET_FLAG(extOpPtr, ExtOp_NoCheckImpactFlg, TRUE);		 /* ROI - 990823 - REF3742 */
                            /* REF5055 - SSO - 000802 */
                            if ((GET_ENUM(extOpPtr, ExtOp_StatusEn) >= accountingStatus) ||
                                (GET_ENUM(extOpPtr, ExtOp_ExecOpNatEn) != ExecNat_None))
                            {
                                *launchFusion = TRUE;
                            }

                            (*opAccessPtr)[(*opAccessNbr)].action = Insert;
                            (*opAccessPtr)[(*opAccessNbr)].role   = UNUSED;
                            (*opAccessPtr)[(*opAccessNbr)].object = EOp;
                            (*opAccessPtr)[(*opAccessNbr)].entity = ExtOp;

                            /* < PMSTA-25183 - CHU - 161110 : same for ext_order */
                            if (TRUE == useExtOrderFlg)
                            {
                                SET_ENUM(extOrderPtr, ExtOp_DbStatusEn, (ENUM_T)ExtOpDbStatus_SimulUpToDate);
                                SET_FLAG(extOrderPtr, ExtOp_NoCheckImpactFlg, TRUE);		 /* ROI - 990823 - REF3742 */
                                (*opAccessPtr)[(*opAccessNbr)].data = extOrderPtr;
                            }
                            else
                            {
                                (*opAccessPtr)[(*opAccessNbr)].data = extOpPtr;
                            }
                            ++(*opAccessNbr);
                            /* > PMSTA-25183 - CHU - 161110 */
                        }
                        else if (IS_EXTOP_DATABASE_ID_PRESENT(extOpPtr) &&
                            (IS_NULLFLD(extOpPtr, ExtOp_OpId) == TRUE ||
                            GET_ID(extOpPtr, ExtOp_OpId) < 0))
                        {
                            if (GET_FLAG(extOpPtr, ExtOp_ConfirmedFlg) == TRUE &&
                                (GET_ENUM(extOpPtr, ExtOp_DbStatusEn) == (ENUM_T) ExtOpDbStatus_UpToDate ||
                                GET_ENUM(extOpPtr, ExtOp_DbStatusEn) == (ENUM_T)ExtOpDbStatus_SimulUpToDate) &&
                                DBA_IsRejectedOrder(extOpPtr) == FALSE) /* PMSTA-25573 - CHU - 170502 */
                            {
                                SET_FLAG(extOpPtr, ExtOp_NoCheckImpactFlg, TRUE);		 /* ROI - 990823 - REF3742 */

                                (*opAccessPtr)[(*opAccessNbr)].action = Insert;
                                (*opAccessPtr)[(*opAccessNbr)].role   = UNUSED;
                                (*opAccessPtr)[(*opAccessNbr)].object = EOp;
                                (*opAccessPtr)[(*opAccessNbr)].entity = ExtOp;

                                if (noExternalPosInExtOpFlg == FALSE) /* PMSTA-29145 - CHU - 171116 */
                                {
                                    /*  Order entry already saved op (draft)    */  /*  FIH-REF10606-040925 */
                                    if (OPE_GetOpTableFromDynFld(extOpPtr,EOp) == OpTable_Draft)
                                    {
                                        (*extOpAccessPtr)[(*extOpAccessNbr)].action = Update;
                                        (*extOpAccessPtr)[(*extOpAccessNbr)].role   = DBA_ROLE_RECONCILE_STRATEGY;
                                        (*extOpAccessPtr)[(*extOpAccessNbr)].object = EOp;
                                        (*extOpAccessPtr)[(*extOpAccessNbr)].entity = ExtOp;
                                        (*extOpAccessPtr)[(*extOpAccessNbr)].data   = extOpPtr;
                                        ++(*extOpAccessNbr);
                                        if (pflagMemoDraftId != NULL)
                                            *pflagMemoDraftId = TRUE;
                                    }
                                }

                                /* REF5055 - SSO - 000802 */
                                if ((GET_ENUM(extOpPtr, ExtOp_StatusEn) >= accountingStatus) ||
                                    (GET_ENUM(extOpPtr, ExtOp_ExecOpNatEn) != ExecNat_None))
                                {
                                    *launchFusion = TRUE;
                                }

                                /* < PMSTA-25183 - CHU - 161110 : same for ext_order */
                                if (TRUE == useExtOrderFlg)
                                {
                                    SET_FLAG(extOrderPtr, ExtOp_NoCheckImpactFlg, TRUE);		 /* ROI - 990823 - REF3742 */
                                    (*opAccessPtr)[(*opAccessNbr)].data = extOrderPtr;
                                }
                                else
                                {
                                    (*opAccessPtr)[(*opAccessNbr)].data = extOpPtr;
                                }
                                ++(*opAccessNbr);
                                /* > PMSTA-25183 - CHU - 161110 */
                            }
                            else if (GET_ENUM(extOpPtr, ExtOp_DbStatusEn) == (ENUM_T) ExtOpDbStatus_SimulToUpdate)
                            {
                                if (noExternalPosInExtOpFlg == FALSE) /* PMSTA-29145 - CHU - 171116 */
                                {
                                    (*extOpAccessPtr)[(*extOpAccessNbr)].action = Update;
                                    (*extOpAccessPtr)[(*extOpAccessNbr)].role   = DBA_ROLE_RECONCILE_STRATEGY;
                                    (*extOpAccessPtr)[(*extOpAccessNbr)].object = EOp;
                                    (*extOpAccessPtr)[(*extOpAccessNbr)].entity = ExtOp;
                                    (*extOpAccessPtr)[(*extOpAccessNbr)].data   = extOpPtr;
                                    ++(*extOpAccessNbr);
                                }

                                SET_ENUM(extOpPtr, ExtOp_DbStatusEn, (ENUM_T) ExtOpDbStatus_SimulUpToDate);
                                SET_FLAG(extOpPtr, ExtOp_NoCheckImpactFlg, TRUE);		 /* ROI - 990823 - REF3742 */

                                if (GET_FLAG(extOpPtr, ExtOp_ConfirmedFlg) == TRUE &&
                                    DBA_IsRejectedOrder(extOpPtr) == FALSE) /* PMSTA-25573 - CHU - 170502 */
                                {
                                    (*opAccessPtr)[(*opAccessNbr)].action = Insert;
                                    (*opAccessPtr)[(*opAccessNbr)].role   = UNUSED;
                                    (*opAccessPtr)[(*opAccessNbr)].object = EOp;
                                    (*opAccessPtr)[(*opAccessNbr)].entity = ExtOp;

                                    /* REF5055 - SSO - 000802 */
                                    if ((GET_ENUM(extOpPtr, ExtOp_StatusEn) >= accountingStatus) ||
                                        (GET_ENUM(extOpPtr, ExtOp_ExecOpNatEn) != ExecNat_None))
                                    {
                                        *launchFusion = TRUE;
                                    }

                                    /* < PMSTA-25183 - CHU - 161110 : same for ext_order */
                                    if (TRUE == useExtOrderFlg)
                                    {
                                        SET_ENUM(extOrderPtr, ExtOp_DbStatusEn, (ENUM_T)ExtOpDbStatus_SimulUpToDate);
                                        SET_FLAG(extOrderPtr, ExtOp_NoCheckImpactFlg, TRUE);		 /* ROI - 990823 - REF3742 */
                                        (*opAccessPtr)[(*opAccessNbr)].data = extOrderPtr;
                                    }
                                    else
                                    {
                                        (*opAccessPtr)[(*opAccessNbr)].data = extOpPtr;
                                    }
                                    ++(*opAccessNbr); /* PMSTA-26434 - RAK/CHU - 170219 : misplaced */
                                    /* > PMSTA-25183 - CHU - 161110 */
                                }
                            }
                        }
                        /* EVENT GENERATION (insert) */
                        else if ((DBA_GetOpIdFromExtOp(extOpPtr) > 0) &&
                                 (GET_ENUM(extOpPtr, ExtOp_DbStatusEn) == (ENUM_T) ExtOpDbStatus_ToInsert) &&
                                 (GET_FLAG(extOpPtr, ExtOp_ConfirmedFlg) == TRUE) &&
                                 DBA_IsRejectedOrder(extOpPtr) == FALSE) /* PMSTA-25573 - CHU - 170502 */
                        {
				            if ((domainPtr != NULL) &&
					            (dictParFct != DictFct_EventGeneration) &&
					            (GET_ENUM(domainPtr, A_Domain_EvtGenNatEn) == EvtGen_Automatic))
				            {
                                if (noExternalPosInExtOpFlg == FALSE) /* PMSTA-29145 - CHU - 171116 */
                                {
					                (*extOpAccessPtr)[(*extOpAccessNbr)].action = Insert;
					                (*extOpAccessPtr)[(*extOpAccessNbr)].role   = DBA_ROLE_RECONCILE_STRATEGY;
					                (*extOpAccessPtr)[(*extOpAccessNbr)].object = EOp;
					                (*extOpAccessPtr)[(*extOpAccessNbr)].entity = ExtOp;
					                (*extOpAccessPtr)[(*extOpAccessNbr)].data   = extOpPtr;
					                ++(*extOpAccessNbr);
                                }

					            SET_FLAG(extOpPtr, ExtOp_NoCheckImpactFlg, TRUE);		 /* ROI - 990823 - REF3742 */
                                /* < PMSTA-25183 - CHU - 161110 : same for ext_order */
                                if (TRUE == useExtOrderFlg)
                                {
                                    SET_FLAG(extOrderPtr, ExtOp_NoCheckImpactFlg, TRUE);		 /* ROI - 990823 - REF3742 */
                                }
                                /* > PMSTA-25183 - CHU - 161110 */

				            }
                            (*opAccessPtr)[(*opAccessNbr)].action = Insert;
                            (*opAccessPtr)[(*opAccessNbr)].role   = UNUSED;
                            (*opAccessPtr)[(*opAccessNbr)].object = EOp;
                            (*opAccessPtr)[(*opAccessNbr)].entity = ExtOp;

                            /* REF5055 - SSO - 000802 */
                            if ((GET_ENUM(extOpPtr, ExtOp_StatusEn) >= accountingStatus) ||
                                (GET_ENUM(extOpPtr, ExtOp_ExecOpNatEn) != ExecNat_None))
                            {
                                *launchFusion = TRUE;
                            }

                            SET_ENUM(extOpPtr, ExtOp_DbStatusEn, (ENUM_T)ExtOpDbStatus_UpToDate);

                            /* < PMSTA-25183 - CHU - 161110 : same for ext_order */
                            if (TRUE == useExtOrderFlg)
                            {
                                SET_ENUM(extOrderPtr, ExtOp_DbStatusEn, (ENUM_T)ExtOpDbStatus_UpToDate);
                                (*opAccessPtr)[(*opAccessNbr)].data = extOrderPtr;
                            }
                            else
                            {
                                (*opAccessPtr)[(*opAccessNbr)].data = extOpPtr;
                            }
                            ++(*opAccessNbr); /* PMSTA-26434 - RAK/CHU - 170219 : misplaced */
                            /* > PMSTA-25183 - CHU - 161110 */
                        }
                        break;
                }
                break;
            }

            /*  FIH-REF7728-020715  Suppress test on ExtOp_OpId */
            case Action_SaveDraftOrderAllocation :
            {
                if (IS_EXTOP_DATABASE_ID_MISSING(extOpPtr) &&
                    GET_ENUM(extOpPtr, ExtOp_DbStatusEn) == (ENUM_T) ExtOpDbStatus_SimulToInsert &&
                    (GET_FLAG(extOpPtr, ExtOp_ConfirmedFlg) == TRUE ||
                    GET_FLAG(extOpPtr, ExtOp_ConfirmedFlg) == FALSE))
                {
                    (*extOpAccessPtr)[(*extOpAccessNbr)].action = Insert;
                    (*extOpAccessPtr)[(*extOpAccessNbr)].role   = DBA_ROLE_RECONCILE_STRATEGY;
                    (*extOpAccessPtr)[(*extOpAccessNbr)].object = EOp;
                    (*extOpAccessPtr)[(*extOpAccessNbr)].entity = ExtOp;
                    (*extOpAccessPtr)[(*extOpAccessNbr)].data   = extOpPtr;
                    ++(*extOpAccessNbr);

                    SET_ENUM(extOpPtr, ExtOp_DbStatusEn, (ENUM_T) ExtOpDbStatus_SimulUpToDate);
                }
                break;
            }

			/* REF7768 - RAK - 021009 - New action Action_SaveDraftAfterPreTradeComplCheck */
            case Action_SaveDraft :
			case Action_SaveDraftAfterPreTradeComplCheck :
            {
				/* REF8376 - CHU - 040609 : Ignore zero quantities for semi-auto order alloc method */
				if ((domainPtr != NULL) &&          /*  FIH-PMSTA10702-101202   */
				    (GET_ENUM(domainPtr, A_Domain_QtyAllocNatEn) == QtyAllocNat_UnspecifiedQty) &&
					(CMP_NUMBER(GET_NUMBER(extOpPtr, ExtOp_Qty), 0.0)==0) &&
                    /* < PMSTA-24542 - CHU - 170117 */
                    !(GET_DICT(domainPtr, A_Domain_FctDictId) == (ENUM_T)DictFct_OrderAllocation &&
                        GET_ENUM(domainPtr, A_Domain_SessionNatureEn) == (ENUM_T)DomSessionNat_OrderAllocation)
                    /* > PMSTA-24542 - CHU - 170117 */
                   )
				{
					SET_ENUM(extOpPtr, ExtOp_DbStatusEn, ExtOpDbStatus_SimulToInsert);
					break;
				}

                /* Add the test with the field ExtOp_DraftOrderId REF8500 - 040510 - PMO */
                if (IS_EXTOP_DATABASE_ID_MISSING(extOpPtr) &&
                    GET_ENUM(extOpPtr, ExtOp_DbStatusEn) == (ENUM_T) ExtOpDbStatus_SimulToInsert &&
                    (GET_FLAG(extOpPtr, ExtOp_ConfirmedFlg) == TRUE ||
                    GET_FLAG(extOpPtr, ExtOp_ConfirmedFlg) == FALSE) &&
                    (IS_NULLFLD(extOpPtr, ExtOp_OpId) == TRUE ||
                    GET_ID(extOpPtr, ExtOp_OpId) < 0))
                {
                    (*extOpAccessPtr)[(*extOpAccessNbr)].action = Insert;
                    (*extOpAccessPtr)[(*extOpAccessNbr)].role   = DBA_ROLE_RECONCILE_STRATEGY;
                    (*extOpAccessPtr)[(*extOpAccessNbr)].object = EOp;
                    (*extOpAccessPtr)[(*extOpAccessNbr)].entity = ExtOp;
                    (*extOpAccessPtr)[(*extOpAccessNbr)].data   = extOpPtr;
                    ++(*extOpAccessNbr);

                    SET_ENUM(extOpPtr, ExtOp_DbStatusEn, (ENUM_T) ExtOpDbStatus_SimulUpToDate);
                }
                else if (IS_EXTOP_DATABASE_ID_PRESENT(extOpPtr) &&
                    GET_ENUM(extOpPtr, ExtOp_DbStatusEn) == (ENUM_T) ExtOpDbStatus_SimulToUpdate &&
                    (GET_FLAG(extOpPtr, ExtOp_ConfirmedFlg) == TRUE ||
                    GET_FLAG(extOpPtr, ExtOp_ConfirmedFlg) == FALSE) &&
                    (IS_NULLFLD(extOpPtr, ExtOp_OpId) == TRUE ||
                    GET_ID(extOpPtr, ExtOp_OpId) < 0))
                {
                    (*extOpAccessPtr)[(*extOpAccessNbr)].action = Update;
                    (*extOpAccessPtr)[(*extOpAccessNbr)].role   = DBA_ROLE_RECONCILE_STRATEGY;
                    (*extOpAccessPtr)[(*extOpAccessNbr)].object = EOp;
                    (*extOpAccessPtr)[(*extOpAccessNbr)].entity = ExtOp;
                    (*extOpAccessPtr)[(*extOpAccessNbr)].data   = extOpPtr;
                    ++(*extOpAccessNbr);

                    SET_ENUM(extOpPtr, ExtOp_DbStatusEn, (ENUM_T) ExtOpDbStatus_SimulUpToDate);
                }
		        /* < REF7550 - CHU - 020603 */
		        /* When called from StratReconc : replaces treatments done previously in FIN_ExtOpSave(), */
		        /* fct that was replaced by DBA_FamilyOrder() */
		        else if (IS_EXTOP_DATABASE_ID_MISSING(extOpPtr) &&
                    GET_ENUM(extOpPtr, ExtOp_DbStatusEn) == (ENUM_T) ExtOpDbStatus_ToInsert &&
                    (GET_FLAG(extOpPtr, ExtOp_ConfirmedFlg) == TRUE ||
                    GET_FLAG(extOpPtr, ExtOp_ConfirmedFlg) == FALSE) &&
                    (IS_NULLFLD(extOpPtr, ExtOp_OpId) == TRUE ||
                    GET_ID(extOpPtr, ExtOp_OpId) < 0))
                {
                    (*extOpAccessPtr)[(*extOpAccessNbr)].action = Insert;
                    (*extOpAccessPtr)[(*extOpAccessNbr)].role   = DBA_ROLE_RECONCILE_STRATEGY;
                    (*extOpAccessPtr)[(*extOpAccessNbr)].object = EOp;
                    (*extOpAccessPtr)[(*extOpAccessNbr)].entity = ExtOp;
                    (*extOpAccessPtr)[(*extOpAccessNbr)].data   = extOpPtr;
                    ++(*extOpAccessNbr);

                    SET_ENUM(extOpPtr, ExtOp_DbStatusEn, (ENUM_T) ExtOpDbStatus_UpToDate);
                }
                else if (IS_EXTOP_DATABASE_ID_PRESENT(extOpPtr) &&
                    GET_ENUM(extOpPtr, ExtOp_DbStatusEn) == (ENUM_T) ExtOpDbStatus_ToUpdate &&
                    (GET_FLAG(extOpPtr, ExtOp_ConfirmedFlg) == TRUE ||
                    GET_FLAG(extOpPtr, ExtOp_ConfirmedFlg) == FALSE) &&
                    (IS_NULLFLD(extOpPtr, ExtOp_OpId) == TRUE ||
                    GET_ID(extOpPtr, ExtOp_OpId) < 0))
                {
                    (*extOpAccessPtr)[(*extOpAccessNbr)].action = Update;
                    (*extOpAccessPtr)[(*extOpAccessNbr)].role   = DBA_ROLE_RECONCILE_STRATEGY;
                    (*extOpAccessPtr)[(*extOpAccessNbr)].object = EOp;
                    (*extOpAccessPtr)[(*extOpAccessNbr)].entity = ExtOp;
                    (*extOpAccessPtr)[(*extOpAccessNbr)].data   = extOpPtr;
                    ++(*extOpAccessNbr);

                    SET_ENUM(extOpPtr, ExtOp_DbStatusEn, (ENUM_T) ExtOpDbStatus_UpToDate);
                }/* REF7550 - CHU 020603 > */
				/* PMSTA-9133 - RAK - 100107 */
				else if (IS_EXTOP_DATABASE_ID_PRESENT(extOpPtr) &&
                    GET_ENUM(extOpPtr, ExtOp_DbStatusEn) == (ENUM_T) ExtOpDbStatus_ToDelete &&
                    (GET_FLAG(extOpPtr, ExtOp_ConfirmedFlg) == TRUE ||
                    GET_FLAG(extOpPtr, ExtOp_ConfirmedFlg) == FALSE) &&
                    (IS_NULLFLD(extOpPtr, ExtOp_OpId) == TRUE ||
                    GET_ID(extOpPtr, ExtOp_OpId) < 0))
                {
					(*extOpAccessPtr)[(*extOpAccessNbr)].action = Delete;
                    (*extOpAccessPtr)[(*extOpAccessNbr)].role   = UNUSED;
                    (*extOpAccessPtr)[(*extOpAccessNbr)].object = EOp;
                    (*extOpAccessPtr)[(*extOpAccessNbr)].entity = ExtOp;
                    (*extOpAccessPtr)[(*extOpAccessNbr)].data   = extOpPtr;
                    ++(*extOpAccessNbr);

                    SET_ENUM(extOpPtr, ExtOp_DbStatusEn, (ENUM_T) ExtOpDbStatus_UpToDate);
				}
                break;
            }

            case Action_Simulation :
            {
                if (IS_EXTOP_DATABASE_ID_PRESENT(extOpPtr) &&
                    GET_ENUM(extOpPtr, ExtOp_DbStatusEn) == (ENUM_T) ExtOpDbStatus_SimulToUpdate &&
                    (GET_FLAG(extOpPtr, ExtOp_ConfirmedFlg) == TRUE ||
                    GET_FLAG(extOpPtr, ExtOp_ConfirmedFlg) == FALSE) &&
                    (IS_NULLFLD(extOpPtr, ExtOp_OpId) == TRUE ||
                    GET_ID(extOpPtr, ExtOp_OpId) < 0))
                {
                    (*extOpAccessPtr)[(*extOpAccessNbr)].action = Update;
                    (*extOpAccessPtr)[(*extOpAccessNbr)].role   = DBA_ROLE_RECONCILE_STRATEGY;
                    (*extOpAccessPtr)[(*extOpAccessNbr)].object = EOp;
                    (*extOpAccessPtr)[(*extOpAccessNbr)].entity = ExtOp;
                    (*extOpAccessPtr)[(*extOpAccessNbr)].data   = extOpPtr;
                    ++(*extOpAccessNbr);

                    SET_ENUM(extOpPtr, ExtOp_DbStatusEn, (ENUM_T) ExtOpDbStatus_SimulUpToDate);
                }
                break;
            }

            default :
                MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBA_InsUpdExtOpAndOpAccess", "action type");
                return(RET_GEN_ERR_INVARG);
        }
    }

	/* < PMSTA-29302 - CHU - 180220 : Check inserted/modified/deleted orders for Selective Replace Old */
    if (action == Action_SaveDraft &&
        domainPtr != NULL &&
        IS_NULLFLD(domainPtr, A_Domain_FctResultId) == FALSE &&
        *extOpAccessNbr < extOpNbr)
    {
        ID_T *ptfIdTab = (ID_T *)CALLOC(extOpNbr, sizeof(ID_T));
        int j = 0, ptfIdx = 0;
        bool foundFlg = false;
        ID_T fctResultId = GET_ID(domainPtr, A_Domain_FctResultId);
        DBA_DYNFLD_STP getArg = NULL;

        /* create an array of ptf id's */
        for (i = 0; i < *extOpAccessNbr; i++)
        {
            if (i == 0)
            {
                ptfIdTab[ptfIdx++] = GET_ID((*extOpAccessPtr)[i].data, ExtOp_PtfId);
            }
            else
            {
                foundFlg = false;
                for (j = 0; j < ptfIdx; j++)
                {
                    if (CMP_ID(GET_ID((*extOpAccessPtr)[i].data, ExtOp_PtfId), ptfIdTab[j])==0)
                    {
                        foundFlg = true;
                        break;
                    }
                }
                if (foundFlg == false)
                {
                    ptfIdTab[ptfIdx++] = GET_ID((*extOpAccessPtr)[i].data, ExtOp_PtfId);
                }
            }
        }

        /* now, for every related portfolio, set calculated_e of */
        /* Ptf Header ESL to StratCalc_SelectiveReload (99) */
        if ((getArg = ALLOC_DYNST(Get_Arg)) != NULLDYNST)
        {
            SET_ID(getArg, Get_Arg_Id, fctResultId);

            for (i = 0; i < ptfIdx; i++)
            {
                SET_ID(getArg, Get_Arg_PtfId, ptfIdTab[i]);

				/* call init_selreplold_esl_by_fid_pid */ /* PMSTA-44673 - DDV - 210426 */
				if (dbiConnHelper.dbaNotif(StratLnk, DBA_ROLE_LOAD_STRAT_LNK, getArg) != TRUE)
                {
                    MSG_LogSrvMesg(UNUSED, UNUSED, "DBA_FamilyOrderCreateAccess: unable to update ESL for PTCC Selective Replace Old");
                }
            }
        }
        FREE_DYNST(getArg, Get_Arg);
        FREE(ptfIdTab); /* PMSTA-39191 - CHU - 200330 */
    }
    /* > PMSTA-29302 - CHU - 180220 */

    return(ret);
}

/************************************************************************
**
**  Function    :   DBA_UpdateStatusForSleeveOperations
**
**  Description :   Update status to "Accounted" for ext_operation records
**                  having parent or child portfolio as a sleeve ptf.
**
**  Arguments   :   extOpAccessTab - ext op tab
**                  extOpAccessNbr - ext op number
**                  dbiConn        - DBI connection
**
**  Return      :   RET_CODE
**
**  Creation    :   PMSTA-41525 - 03092020 - sanand
**
**  Modif.      :
**
*************************************************************************/
RET_CODE DBA_UpdateStatusForSleeveOperations(DBA_ACCESS_STP           extOpAccessTab,
                                             int                      extOpAccessNbr,
                                             DbiConnection &          dbiConn)
{
    ID_T             ptfId = ZERO_ID     ,  boPtfId = ZERO_ID,
                    targetPtfId = ZERO_ID , targetBoPtfId = ZERO_ID;
    FIELD_IDX_T       targetPtfIdx, targetBoPtfIdx;
    OPSTAT_ENUM     accountingStatus;

    GEN_GetApplInfo(ApplAccountingStatus, &accountingStatus);

    for (int extOpIdx = 0; extOpIdx < extOpAccessNbr; extOpIdx++)
    {
        DBA_DYNFLD_STP extOpElt = extOpAccessTab[extOpIdx].data;
        if (NULLDYNST != extOpElt)
        {
            if (OPNAT_ENUM::OpNat_PtfTransf ==
                static_cast<OPNAT_ENUM>(GET_ENUM(extOpElt, ExtOp_NatureEn)) ||
                ((OPNAT_ENUM::OpNat_Sell ==
                    static_cast<OPNAT_ENUM>(GET_ENUM(extOpElt, ExtOp_NatureEn))) &&
                    FALSE == IS_NULLFLD(extOpElt, ExtOp_CashPtfId)))
            {
                if (OPNAT_ENUM::OpNat_PtfTransf ==
                    static_cast<OPNAT_ENUM>(GET_ENUM(extOpElt, ExtOp_NatureEn)))
                {
                    targetPtfIdx = ExtOp_AdjPtfId;
                    targetBoPtfIdx = ExtOp_AdjBoPtfId;
                }
                else
                {
                    targetPtfIdx = ExtOp_CashPtfId;
                    targetBoPtfIdx = ExtOp_BoCashPtfId;
                }
                ptfId         = GET_ID(extOpElt, ExtOp_PtfId);
                boPtfId       = GET_ID(extOpElt, ExtOp_BoPtfId);
                targetPtfId   = GET_ID(extOpElt, targetPtfIdx);
                targetBoPtfId = GET_ID(extOpElt, targetBoPtfIdx);

                if( ( boPtfId > 0 && targetBoPtfId > 0 &&
                      CMP_ID(boPtfId,targetBoPtfId) == 0 ) ||
                    ( CMP_ID(ptfId, targetBoPtfId) == 0 ) ||
                    ( CMP_ID(boPtfId, targetPtfId) == 0 ) )
                {
                    SET_ENUM(extOpElt, ExtOp_StatusEn, accountingStatus); /* PMSTA-66011 - Deepthi - 20250214 */
                }
            }
        }
    }
    return RET_SUCCEED;
}

/************************************************************************
**
**  Function    :   DBA_FamilyOrderAccess.
**
**  Description :   Allow to insert/update orders using DBA_MultiAccess.
**
**  Arguments   :   extOpAccessTab  ExtOp access table
**                  extOpAccessNbr  ExtOp access number
**                  opAccessTab     Op access table
**                  opAccessNbr     Op access number
**					options
**                  flagMemoDraftId If TRUE Draft id must be memorized before saving op
**                  msgErrHeaderStp erreur message table
**
**  Return      :   RET_CODE.
**
**  Cr�ation    :   GRD - 990616 - REF3742.
**  Modif.      :   RAK - 990708 - REF3742.
**  Modif.      :   FIH - 991027 - REF4083
**              :   SSO - 991130 - REF4116.
**              :   GRD - 991207 - REF4116.
**				:	MRA - 000218 - REF4217. add options parameter.
**                  REF8500 - 040510 - PMO : Add a draft_order_id in extended operation to distinguish
**                                           the id from extended orders and the one from extended operation
*************************************************************************/
STATIC RET_CODE  DBA_FamilyOrderAccess (EXTOP_ACTION_ENUM		action,		        /* REF7768 - RAK - 021009 */
                                        DBA_ACCESS_STP           extOpAccessTab,
                                        int                      extOpAccessNbr,
                                        DBA_ACCESS_STP           opAccessTab,
                                        int                      opAccessNbr,
                                        DBA_DYNFLD_STP		    *caseMgtTab,	    /* PMSTA07121-CHU-081030 */
                                        int						caseMgtNbr,	        /* PMSTA07121-CHU-081030 */
                                        int                      *allocConn,
                                        int						options,
                                        FLAG_T                   flagMemoDraftId,    /*  FIH-REF10606-040930 */
                                        DBA_DYNFLD_STP          pdbadynDomain)      /* PMSTA31563-JPR-180531 */
{
    RET_CODE        ret = RET_SUCCEED;
    FLAG_T          transFlg = FALSE, applCaseActivationFlag = FALSE; /* PMSTA07121-CHU-090305 */
    int             i = 0;
    int             commitSz=0;
    ID_T            *pidDraftOrder;
	DbiConnection   *dbiConn = nullptr;
	DBA_DYNFLD_STP  *aNotepadTab = NULL, *commTab = NULL;   /*PMSTA-28772-NRAO-171017*/
	int              nbNotepad = 0, commNbr = 0;            /*PMSTA-28772-NRAO-171017*/

    OPSTAT_ENUM     accountingStatus;
    GEN_GetApplInfo(ApplAccountingStatus, &accountingStatus);

    if (/* extOpAccessTab == NULL || - PMSTA08915 - DDV - 091112 - Continue event if array is null, to save cases even when no operations are given */
        (extOpAccessNbr == 0 && opAccessNbr == 0 && caseMgtNbr == 0)
       )
    {
        return(RET_SUCCEED);
    }

    if (allocConn == NULL)
    {
        if ((dbiConn = DBA_GetDbiConnection(SqlServer)) == nullptr)
        {
            return(RET_DBA_ERR_CONNOTFOUND);
        }
    }
    else
    {
		dbiConn = DBA_GetDbiConnFromConnectNo(*allocConn);
		if (dbiConn == nullptr) {
			return RET_DBA_ERR_CONNOTFOUND;
		}
    }

	if (dbiConn->isInTransaction() == false)
    {
        dbiConn->beginTransaction();
        transFlg = TRUE;
    }

    GEN_GetApplInfo(ApplCommitBlockSize, &commitSz);

	GEN_GetApplInfo(ApplCaseActivationFlag, &applCaseActivationFlag); /* PMSTA07121-CHU-090305 */


    /*  FIH-REF10606-040930 Draft order id must be memorized nefore saving operation    */
    pidDraftOrder = NULL;
    if ((flagMemoDraftId == TRUE) &&
        (opAccessTab != NULL) &&
        (extOpAccessTab != NULL) &&
        (opAccessNbr > 0) &&
        (extOpAccessNbr > 0))
    {
        pidDraftOrder = (ID_T *) CALLOC(extOpAccessNbr, sizeof(ID_T));
        for (i = 0; i < extOpAccessNbr; i++)
        {
            if ((extOpAccessTab[i].data != NULL) &&
                (IS_NULLFLD(extOpAccessTab[i].data,ExtOp_DraftOrderId) == FALSE))
                pidDraftOrder[i] = GET_ID(extOpAccessTab[i].data,ExtOp_DraftOrderId);
        }
    }

    /* PMSTA-41525 - sanand - 05092020
       Overlay - Portfolio/Cash Transfer for Sleeve status update during publish */
    if (Action_SaveOp == action &&
        (REBAL_METHOD_ENUM::InterIntra_All_Assets ==
         static_cast<REBAL_METHOD_ENUM>GET_ENUM(pdbadynDomain, A_Domain_RebalMethodEn) ||
			REBAL_METHOD_ENUM::InterIntra_Cash_Only ==
			static_cast<REBAL_METHOD_ENUM>GET_ENUM(pdbadynDomain, A_Domain_RebalMethodEn) ||
			REBAL_METHOD_ENUM::Inter_All_Assets ==
			static_cast<REBAL_METHOD_ENUM>GET_ENUM(pdbadynDomain, A_Domain_RebalMethodEn) ||
			REBAL_METHOD_ENUM::Inter_Cash_Only ==
			static_cast<REBAL_METHOD_ENUM>GET_ENUM(pdbadynDomain, A_Domain_RebalMethodEn))
		)
    {
        if((ret = DBA_UpdateStatusForSleeveOperations(extOpAccessTab, extOpAccessNbr, *dbiConn)) != RET_SUCCEED)
        {
            MSG_SendMesg(FILEINFO, "DBA_FamilyOrderAccess: Unable to set status for Sleeve operations");
            return ret;
        }
    }

    ret = RET_SUCCEED;
    /* It's important to insert operation before extended operation because of operation code */
    if (opAccessTab != NULL && opAccessNbr > 0)
    {
		/* Save extOp identifier, so keep link on constraint breach */
		for (i=0; i<opAccessNbr; i++)
		{
            /* REF8500 - 040510 - PMO */
			SET_ID(opAccessTab[i].data, ExtOp_Id, GET_EXTOP_DATABASE_ID(opAccessTab[i].data));
		}

        ret = DBA_HandleOperTabByBlock (*dbiConn, opAccessTab, 0, 100, opAccessNbr,
										((options & DBA_NO_ERROR) == DBA_NO_ERROR)
										? DBA_SET_CONN|DBA_NO_CLOSE|DBA_OP_BLOCK|DBA_NO_ERROR
										: DBA_SET_CONN|DBA_NO_CLOSE|DBA_OP_BLOCK);

		if (ret == RET_SUCCEED)
		{
			/*PMSTA-28772-NRAO-171017 - Link Notepad/Communication to opAccessTab from extOpAccessTab*/
			if ((extOpAccessTab != NULL) &&
				(opAccessTab != NULL) &&
				(extOpAccessNbr > 0) &&
				(extOpAccessNbr == opAccessNbr))
			{
				for (i = 0; i < extOpAccessNbr; i++)
				{
					if (extOpAccessTab[i].data != NULL && opAccessTab[i].data != NULL)
					{
						if ((ret = DBA_SelectAllNotepad(extOpAccessTab[i].data, &aNotepadTab, &nbNotepad, extOpAccessTab[i].object, *dbiConn)) == RET_SUCCEED &&
							nbNotepad > 0)
						{
							ret = DBA_SetAllNotepadToNewOp(opAccessTab[i].data, aNotepadTab, nbNotepad, *dbiConn);
							if (aNotepadTab != NULL)
							{
								(void)DBA_FreeDynStTab(aNotepadTab, nbNotepad, A_Notepad);
								nbNotepad = 0;
							}
						}

						if ((ret = DBA_SelectAllCommunication(extOpAccessTab[i].data, &commTab, &commNbr, extOpAccessTab[i].object, *dbiConn)) == RET_SUCCEED &&
							commNbr > 0)
						{
							ret = DBA_SetAllCommunicationToNewOp(opAccessTab[i].data, commTab, commNbr, *dbiConn);
							if (commTab != NULL)
							{
								(void)DBA_FreeDynStTab(commTab, commNbr, A_Communication);
								commNbr = 0;
							}
						}

					}

				}
			}

            if (action == Action_SaveOp &&
                extOpAccessNbr > 0 &&
                extOpAccessTab != NULL)
            {
                /* Publish of Tax Lot Picking */                                                                 /*  PMSTA - 35339 - 010419 - vkumar */
                TAX_LOT_ACCOUNTING    taxLotAccounting = TAX_LOT_ACCOUNTING::NoTaxLot;
                GEN_GetApplInfo(ApplTaxLotAccountingEn, &taxLotAccounting);

                if (TAX_LOT_ACCOUNTING::TaxLotByBackOffice == taxLotAccounting)
                {
                    ret = publishTaxLotPicking(extOpAccessTab, extOpAccessNbr, *dbiConn);
                }

                /* Overlay Portfolio Status update during publish */                                             /* PMSTA-40170 - 130520 - vkumar */
                if ((GET_DICT(pdbadynDomain, A_Domain_FctDictId) == DictFct_ReconcStrat ||
					GET_DICT(pdbadynDomain, A_Domain_InitialFctDictId) == DictFct_ManageSession)  &&
                    REBAL_METHOD_ENUM::Default !=
                    static_cast<REBAL_METHOD_ENUM>GET_ENUM(pdbadynDomain, A_Domain_RebalMethodEn))
                {
                    ret = DBA_UpdatePtfStatusForOverlay(pdbadynDomain, *dbiConn);
                }

                bool cashPlanAvilable = false;
                /*Create withdrawal request for overlay cash plan */
                for (i = 0; i < extOpAccessNbr; i++)
                {
                    if (IS_NULLFLD(extOpAccessTab[i].data, ExtOp_CashPlanId) == FALSE)
                    {
                        cashPlanAvilable = true;
                        /*for each withdrwal operation with cash plan id create withdrwal request*/
                        if (GET_ENUM(extOpAccessTab[i].data, ExtOp_NatureEn) == OpNat_Withdr &&
                                GET_ENUM(extOpAccessTab[i].data, ExtOp_StatusEn) !=accountingStatus )
                        {
                            ret = DBA_createWithDrReqForCashPlan(pdbadynDomain, *dbiConn, extOpAccessTab[i].data);
                        }
                    }
                }

                ///* Update execution date status during publish */                                             /*PMSTA-42402 Autocash Vishnu 12012021*/
                if(cashPlanAvilable ||
                    static_cast<complianceMethodEn> GET_ENUM(pdbadynDomain, A_Domain_ComplianceMethodEn) == complianceMethodEn::CashPlanCompliance)
                {
                    ret = DBA_UpdatePtfStatusForExecutionDate(pdbadynDomain, *dbiConn);
                }

                for (i = 0; i < extOpAccessNbr; i++)
                {
                    /*WEALTH-4125	 Vishnu 01012024*/
                    /* set forward eligibility as no when publising */
                    ret = DBA_UpdateFwdRollOverDetails(pdbadynDomain, *dbiConn, extOpAccessTab[i].data);
                }

            }
		}
		else
		{
            if (ret == RET_SRV_LIB_ERR_FATAL_DEADLOCK)
            {
                dbiConn->sendAllMsg();

                MSG_SendMesg(RET_SRV_LIB_ERR_FATAL_DEADLOCK, 1, FILEINFO, dbiConn->getId());
				DBA_EndConnection(&dbiConn, TRUE);
				dbiConn = DBA_GetDbiConnection(SqlServer);
				if (allocConn != NULL)
				{
					*allocConn = dbiConn->getId();
				}
			}
            else
            {
                if (transFlg == TRUE)
                {
					dbiConn->endTransaction(FALSE);       /* Rollback. */
                }
            }

            if (allocConn == NULL)
            {
                DBA_EndConnection(&dbiConn);               /* No need any more. */
            }

			/* PMSTA-17716 - CHU - 140312 : Purify */
			if (flagMemoDraftId == TRUE && pidDraftOrder != NULL)
				FREE(pidDraftOrder);
            return(ret);
        }

        /* Save data. */
        if (transFlg == TRUE)
        {
			dbiConn->endTransaction(TRUE);                /* Commit. */
            dbiConn->beginTransaction() ;
        }
    }

    /*  FIH-REF10606-040930 Draft order id must be reinit before saving ext_operation   */
    if ((flagMemoDraftId == TRUE) &&
        (pidDraftOrder != NULL))
    {
        for (i = 0; i < extOpAccessNbr; i++)
        {
            if ((pidDraftOrder[i] != 0) &&
                (extOpAccessTab[i].data != NULL))
            {
                SET_ID(extOpAccessTab[i].data, ExtOp_ExtOrderId, GET_ID(opAccessTab[i].data, ExtOp_DbId));  /* WEALTH-2617 - KKM - 20082024 */
                SET_ID(extOpAccessTab[i].data,ExtOp_DraftOrderId,pidDraftOrder[i]);
                SET_NULL_ID(extOpAccessTab[i].data,ExtOp_OpId);
                SET_NULL_ID(extOpAccessTab[i].data,ExtOp_DbId);
            }
        }
        FREE(pidDraftOrder);
    }

    if (extOpAccessNbr > 0)
    {
        DbaMultiAccessHelper       multiAccessHelper(extOpAccessTab, extOpAccessNbr);

        ret = multiAccessHelper.callMultiAccess(commitSz, DBA_SET_CONN|DBA_NO_CLOSE|DBA_OP_BLOCK|DBA_NO_ERROR, *dbiConn, true);

        if (ret != RET_SUCCEED)
        {
            if (ret == RET_SRV_LIB_ERR_FATAL_DEADLOCK)
            {
                multiAccessHelper.sendAllMultiAccessMsg();

                MSG_SendMesg(RET_SRV_LIB_ERR_FATAL_DEADLOCK, 1, FILEINFO, dbiConn->getId());

                DBA_EndConnection(&dbiConn, TRUE);
                dbiConn = DBA_GetDbiConnection(SqlServer);
                if (allocConn != NULL)
                {
                    *allocConn = dbiConn->getId();
                }
            }
            else
            {
                if (transFlg == TRUE)
                {
                    dbiConn->endTransaction(FALSE);       /* Rollback. */
                }
            }

            if (allocConn == NULL)
            {
                DBA_EndConnection(&dbiConn);                   /* No need any more. */
            }
            return(ret);
        }
    }

	 /* < PMSTA07121-CHU-081205 : Save Cases and Case linked objects */
    if (applCaseActivationFlag == TRUE && caseMgtNbr > 0) /* PMSTA07121-CHU-090305 */
    {
        ret = DBA_FamilyOrderSaveCaseManagement(action,
                                                caseMgtTab, caseMgtNbr,
                                                extOpAccessTab, extOpAccessNbr,
                                                (int*)&dbiConn->getId(), pdbadynDomain); /* PMSTA31563-JPR-180531 */

		if (ret != RET_SUCCEED)
		{
			if (ret == RET_SRV_LIB_ERR_FATAL_DEADLOCK)
			{
                dbiConn->sendAllMsg();

                MSG_SendMesg(RET_SRV_LIB_ERR_FATAL_DEADLOCK, 1, FILEINFO, dbiConn->getId());

                DBA_EndConnection(&dbiConn, TRUE);
                dbiConn = DBA_GetDbiConnection(SqlServer);
                if (allocConn != NULL)
                {
                    *allocConn = dbiConn->getId();
                }

                //DBA_ReinitDeadConn(dbiConn->getId());
            }
            else
            {
                if (transFlg == TRUE)
                {
                    dbiConn->endTransaction(FALSE);       /* Rollback. */
                }
            }

            if (allocConn == NULL)
            {
                DBA_EndConnection(&dbiConn);               /* No need any more. */
            }

            return(ret);
        }
    }

    /* > PMSTA07121-CHU-081205 : Save Cases and Case linked objects */

    /* Save data. */
    if (transFlg == TRUE)
    {
        dbiConn->endTransaction(TRUE);                    /* Commit. */
    }

    if (allocConn == NULL)
    {
        DBA_EndConnection(&dbiConn);                           /* No need any more. */
    }

    return (ret);
}

/************************************************************************
**
**  Function    :   DBA_TabulaRasa()
**
**  Description :   Tabule rasa... (call del_case_management_by_session_id)
**                  CaseLinks associated to each Case will be deleted with a trigger
**
**  Arguments   :   session identifier
**
**  Return      :
**
**  Creation    :   PMSTA07121-CHU-081105 Yes, the day Obama was elected!
**
**  Modif       :   FPL-PMSTA10166-100701 Add parameter nature
**              :   if given nature >= CaseManagementNat_Last , we delete all cases
**                  except CaseManagementNat_InputCtrl. In other cases
**                  we delete case of given nature
**                  parameter of proc "nature" is not mendatory, if
**                  CaseManagementNat_Last we set it to null
**                  PMSTA-17133 - 051113 - PMO : Many compilation warnings in C code especially " Converting a 64-bit type value to "int" causes truncation."
**
*************************************************************************/
RET_CODE DBA_TabulaRasa(ID_T				sessionId,
                        CASEMANAGEMENTNAT_ENUM  caseMgtNatEn,
						int					*connectNo)
{
	RET_CODE		ret=RET_SUCCEED;
	DBA_DYNFLD_STP	sCaseMgtPtr=NULLDYNST;
	DBA_ACCESS_STP	delCaseMgtAccess=NULL;
	int				commitSz=0;

	if (sessionId != ZERO_ID)    /* PMSTA-17133 - 051113 - PMO */
	{
		GEN_GetApplInfo(ApplCommitBlockSize, &commitSz);

		if ((sCaseMgtPtr = ALLOC_DYNST(S_CaseManagement)) == NULLDYNST)
		{
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		if ((delCaseMgtAccess = (DBA_ACCESS_STP)CALLOC(1, sizeof(DBA_ACCESS_ST))) == NULL)
		{
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		SET_ID(sCaseMgtPtr, S_CaseManagement_SessionId, sessionId);

        if ((caseMgtNatEn >= CaseManagementNat_None) &&
            (caseMgtNatEn < CaseManagementNat_Last))
		{
            SET_ENUM(sCaseMgtPtr, S_CaseManagement_NatEn, caseMgtNatEn);    /*  FPL-PMSTA10166-100701   */
		}
		else
		{
			SET_ENUM(sCaseMgtPtr, S_CaseManagement_NatEn, CaseManagementNat_None);
		}

		delCaseMgtAccess[0].action = Delete;
		delCaseMgtAccess[0].role   = UNUSED;
		delCaseMgtAccess[0].object = CaseManagement;
		delCaseMgtAccess[0].entity = S_CaseManagement;
		delCaseMgtAccess[0].data   = sCaseMgtPtr;

        {
            DbaMultiAccessHelper       multiAccessHelper(delCaseMgtAccess, 1);

            /* call del_case_management_by_session_id */
		    ret = multiAccessHelper.callMultiAccess(commitSz, DBA_SET_CONN|DBA_NO_CLOSE|DBA_NO_ERROR, connectNo, true);
            if (ret != RET_SUCCEED)
            {
                multiAccessHelper.sendAllMultiAccessMsg();
            }
        }

		FREE_DYNST(sCaseMgtPtr, S_CaseManagement);
		FREE(delCaseMgtAccess);
	}

	return(ret);
}

/************************************************************************
**
**  Function    :   DBA_FamilyOrderSaveCaseManagement()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation    :   PMSTA07121-CHU-081030
**
*************************************************************************/
STATIC RET_CODE DBA_FamilyOrderSaveCaseManagement(EXTOP_ACTION_ENUM		action,
												  DBA_DYNFLD_STP        *caseMgtTab,
												  int				    caseMgtNbr,
												  DBA_ACCESS_STP		extOpAccessTab,
												  int					extOpAccessNbr,
												  int					*connectNo,
                                                  DBA_DYNFLD_STP		pdbadynDomain)  /* PMSTA31563-JPR-180531 */
{
	RET_CODE				ret=RET_SUCCEED;
	DBA_DYNFLD_STP		    *caseLnkTab = NULL, *tmpCaseLnkTab = NULL;
	DBA_DYNFLD_STP			*copyCaseMgtTab = NULL, *copyCaseLnkTab = NULL;
	DBA_DYNFLD_STP			*caseClarifTab = NULL, *copyCaseClarifTab = NULL;
	int						caseLnkNbr=0, tmpCaseLnkNbr=0, copyCaseMgtNbr=0, copyCaseLnkNbr=0;
	int						caseClarifNbr=0, copyCaseClarifNbr=0;
	int						i, j, k, accessNbr=0;
	DBA_ACCESS_STP			caseMgtAccess=NULL, caseLnkAccess=NULL, caseClarifAccess=NULL;
	int						commitSz=0;
	OBJECT_ENUM				entity = NullEntity;
	int						negativeCaseNbr = 0, positiveCaseNbr = 0;	/* PMSTA100274-CHU-100727 */
	FLAG_T					foundFlg=FALSE;								/* PMSTA15563-CHU-121205 */
    FLAG_T                  purgeChunkCasesFlg = FALSE;         /* PMSTA31563-JPR-180531 */
    MemoryPool              mp;
        
    /* WEALTH-4101 - Ravindra - 110124: Avoid deleting cases for CompData_SelectiveReplOld */
    FLAG_T purgeCaseFlg = (IS_NULLFLD(pdbadynDomain, A_Domain_OrigCompDataEn) == FALSE
        && GET_ENUM(pdbadynDomain, A_Domain_OrigCompDataEn) == CompData_SelectiveReplOld) ? FALSE : TRUE ;

	/* In case of GUI Simulation don't update cases */
	if (action == Action_Simulation)
		return(RET_SUCCEED);

	/* In case of GUI SaveDraft don't update cases */
	/* but insert them when the server the draft (creation of the cases) */
	if (caseMgtNbr > 0 &&
		(action == Action_SaveDraft || action == Action_SaveDraftAfterPreTradeComplCheck))
	{
		for (i=0; i<caseMgtNbr; i++)
		{
			if (GET_ID(caseMgtTab[i], A_CaseManagement_Id) > 0)
			{
				positiveCaseNbr++;
			}
			else
			{
				negativeCaseNbr++;
			}
		}

		/* PMSTA100274-CHU-100727 */
		if (/* if no fresh cases, do nothing (no TabulaRasa, no insert) */
			(positiveCaseNbr > 0 && negativeCaseNbr == 0) ||
			/* if mixed fresh and old cases - TabulaRasa was already performed but insert fresh cases */
			(positiveCaseNbr > 0 && negativeCaseNbr  > 0))
		{
			purgeCaseFlg = FALSE;
		}
		/* else if only fresh cases : do as usual, TabulaRasa + insert */
	}

	GEN_GetApplInfo(ApplCommitBlockSize, &commitSz);

    /* PMSTA31563-JPR-180531 */
    /* For call from WUI, the deletion logic is bypassed, as the case_management
    table has already been cleared based on the chunk number earlier in the
    function DBA_SelectPtfIdByDomain. Also, for creation of new cases (save draft), no need
    to delete the old cases from the table as all cases will be newly inserted with new session id.*/
    
    /* WEALTH-233 - Deepthi - 20230504 - Cases should be retained and not purged */
    if (GET_ENUM(pdbadynDomain, A_Domain_CompDataEn) != CompData_DeleteESEAndRetainCases) 
    {
        purgeChunkCasesFlg = IS_NULLFLD(pdbadynDomain, A_Domain_JobReference) == FALSE &&
            IS_NULLFLD(pdbadynDomain, A_Domain_ChunkNumber) == FALSE &&
            ((GET_DICT(pdbadynDomain, A_Domain_FctDictId) == DictFct_PreTradeCheckStrat &&
                IS_NULLFLD(pdbadynDomain, A_Domain_FctResultId) == FALSE &&
                GET_ENUM(pdbadynDomain, A_Domain_CompDataEn) == CompData_ReplOld) ||
                (action == Action_SaveDraft));

        if (purgeChunkCasesFlg == FALSE) /* PMSTA31563-JPR-180531 : Old cases are not deleted. So, need to delete.*/
        {
            /* Delete old cases for this function result */
            if (caseMgtNbr > 0 &&
                (action == Action_SaveDraft || action == Action_SaveDraftAfterPreTradeComplCheck) &&
                purgeCaseFlg == TRUE ) /* PMSTA100274-CHU-100727 : see explanation above */
            {
                ret = DBA_TabulaRasa(GET_ID(caseMgtTab[0], A_CaseManagement_SessionId),
                    CaseManagementNat_Last,            /*  FPL-PMSTA10166-100701   */
                    connectNo);
            }
        }
    }
	if (action != Action_SaveOp)
	{
		if (caseMgtNbr > 0)
		{
			if ((caseMgtAccess = (DBA_ACCESS_STP)CALLOC(caseMgtNbr, sizeof(DBA_ACCESS_ST))) == NULL)
			{
				MSG_RETURN(RET_MEM_ERR_ALLOC);
			}
		}

		for (i=0; i<caseMgtNbr; i++)
		{
			/* PMSTA100274-CHU-100727 - do not save old cases again, see explanation above */
			if (GET_ID(caseMgtTab[i], A_CaseManagement_Id) < 0)
			{
				caseMgtAccess[accessNbr].action = Insert;
				caseMgtAccess[accessNbr].role   = UNUSED;
				caseMgtAccess[accessNbr].object = CaseManagement;
				caseMgtAccess[accessNbr].entity = A_CaseManagement;
				caseMgtAccess[accessNbr].data   = caseMgtTab[i];
				++accessNbr;
			}
		}

        if (accessNbr > 0)
		{
            DbaMultiAccessHelper       multiAccessHelper(caseMgtAccess, accessNbr);

            ret = multiAccessHelper.callMultiAccess(commitSz, DBA_SET_CONN|DBA_NO_CLOSE|DBA_NO_ERROR, connectNo, true);
		    if (ret != RET_SUCCEED)
            {
                multiAccessHelper.sendAllMultiAccessMsg();
            }
        }

        if (ret == RET_SUCCEED)
        {
            /* Now, retrieve CaseLinks, update CaseId and construct caseLnkAccess */
			for (i=0; i<caseMgtNbr; i++)
			{
				if (/* GET_ID(caseMgtTab[i], A_CaseManagement_Id) < 0 &&*/  /* PMSTA100274-CHU-100727 : only for fresh Cases */
					GET_EXTENSION_PTR(caseMgtTab[i], A_CaseManagement_A_CaseLink_Ext) != NULL &&
					(tmpCaseLnkTab = GET_EXTENSION_PTR(caseMgtTab[i], A_CaseManagement_A_CaseLink_Ext)) != NULL)
				{
					tmpCaseLnkNbr = GET_EXTENSION_NBR(caseMgtTab[i], A_CaseManagement_A_CaseLink_Ext);

					if (tmpCaseLnkNbr > 0)
					{
						if (caseLnkNbr == 0)
						{
							caseLnkTab = (DBA_DYNFLD_STP *)mp.calloc(tmpCaseLnkNbr, sizeof(DBA_DYNFLD_STP));
						}
						else
						{
							caseLnkTab = (DBA_DYNFLD_STP *)mp.realloc(caseLnkTab, (caseLnkNbr + tmpCaseLnkNbr) * sizeof(DBA_DYNFLD_STP));
						}

						if (caseLnkTab == NULL)
						{
							FREE(caseMgtAccess); /* PMSTA15705 - DDV - 121226 - Purify */
							FREE(caseLnkAccess); /* PMSTA15705 - DDV - 121226 - Purify */
							FREE(caseClarifAccess); /* PMSTA15705 - DDV - 121226 - Purify */
							DBA_FreeDynStTab(copyCaseMgtTab, copyCaseMgtNbr, A_CaseManagement); /* PMSTA15705 - DDV - 121226 - Purify */
							DBA_FreeDynStTab(copyCaseLnkTab, copyCaseLnkNbr, A_CaseLink); /* PMSTA15705 - DDV - 121226 - Purify */
							DBA_FreeDynStTab(copyCaseClarifTab, copyCaseClarifNbr, A_CaseClarification); /* PMSTA15705 - DDV - 121226 - Purify */
							MSG_RETURN(RET_MEM_ERR_ALLOC);
						}

						for (j = 0; j < tmpCaseLnkNbr; j++)
						{
							if (GET_ID(tmpCaseLnkTab[j], A_CaseLink_Id) > 0)
							{
								continue;
							}

							caseLnkTab[caseLnkNbr] = tmpCaseLnkTab[j];
							SET_ID(caseLnkTab[caseLnkNbr], A_CaseLink_CaseId, GET_ID(caseMgtTab[i], A_CaseManagement_Id));

							/* retrieve database id of extop for further use in Save Session */
							DBA_GetObjectEnum(GET_DICT(caseLnkTab[caseLnkNbr], A_CaseLink_EntDictId),  &entity);
							if (entity == EOp)
							{
								for (k=0; k < extOpAccessNbr; k++)
								{
									if (CMP_ID(GET_ID(caseLnkTab[caseLnkNbr], A_CaseLink_ObjId), GET_ID(extOpAccessTab[k].data, ExtOp_OpId))==0)
									{
										SET_ID(caseLnkTab[caseLnkNbr], A_CaseLink_ObjId, GET_EXTOP_DATABASE_ID(extOpAccessTab[k].data));
									}
								}
							}
							caseLnkNbr++;
						}
					}
				}
			}

			if (caseLnkNbr > 0)
			{
				if ((caseLnkAccess = (DBA_ACCESS_STP)CALLOC(caseLnkNbr, sizeof(DBA_ACCESS_ST))) == NULL)
				{
					FREE(caseMgtAccess); /* PMSTA15705 - DDV - 121226 - Purify */
					FREE(caseLnkAccess); /* PMSTA15705 - DDV - 121226 - Purify */
					FREE(caseClarifAccess); /* PMSTA15705 - DDV - 121226 - Purify */
					DBA_FreeDynStTab(copyCaseMgtTab, copyCaseMgtNbr, A_CaseManagement); /* PMSTA15705 - DDV - 121226 - Purify */
					DBA_FreeDynStTab(copyCaseLnkTab, copyCaseLnkNbr, A_CaseLink); /* PMSTA15705 - DDV - 121226 - Purify */
					DBA_FreeDynStTab(copyCaseClarifTab, copyCaseClarifNbr, A_CaseClarification); /* PMSTA15705 - DDV - 121226 - Purify */
					MSG_RETURN(RET_MEM_ERR_ALLOC);
				}

				accessNbr=0;
				for (i=0; i<caseLnkNbr; i++)
				{
					caseLnkAccess[accessNbr].action = Insert;
					caseLnkAccess[accessNbr].role   = UNUSED;
					caseLnkAccess[accessNbr].object = CaseLink;
					caseLnkAccess[accessNbr].entity = A_CaseLink;
					caseLnkAccess[accessNbr].data   = caseLnkTab[i];
					++accessNbr;
				}

				if (accessNbr > 0)
				{
                    DbaMultiAccessHelper       multiAccessHelper(caseLnkAccess, accessNbr);

                    ret = multiAccessHelper.callMultiAccess(commitSz, DBA_SET_CONN|DBA_NO_CLOSE|DBA_NO_ERROR, connectNo, true);
                    if (ret != RET_SUCCEED)
                    {
                        multiAccessHelper.sendAllMultiAccessMsg();
                    }
                }

			}
		}
	}
	else /* action == Action_SaveOp */
	{
		if (caseMgtNbr > 0)
		{
			/* update existing Cases */
			if ((caseMgtAccess = (DBA_ACCESS_STP)CALLOC(caseMgtNbr, sizeof(DBA_ACCESS_ST))) == NULL)
			{
				MSG_RETURN(RET_MEM_ERR_ALLOC);
			}

			accessNbr=0;
			for (i=0; i<caseMgtNbr; i++)
			{
				caseMgtAccess[accessNbr].action = Update;
				caseMgtAccess[accessNbr].role   = UNUSED;
				caseMgtAccess[accessNbr].object = CaseManagement;
				caseMgtAccess[accessNbr].entity = A_CaseManagement;
				caseMgtAccess[accessNbr].data   = caseMgtTab[i];
				++accessNbr;
			}

			if (accessNbr > 0)
			{
                DbaMultiAccessHelper       multiAccessHelper(caseMgtAccess, accessNbr);

                ret = multiAccessHelper.callMultiAccess(commitSz, DBA_SET_CONN|DBA_NO_CLOSE|DBA_NO_ERROR, connectNo, true);
                if (ret != RET_SUCCEED)
                {
                    multiAccessHelper.sendAllMultiAccessMsg();
                }
            }

			FREE(caseMgtAccess);
			accessNbr=0;

			/* duplicate and save Cases with an extOp linked object */
			if ((copyCaseMgtTab = (DBA_DYNFLD_STP *)CALLOC(caseMgtNbr, sizeof(DBA_DYNFLD_STP)))==NULL)
			{
				MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "CopyCaseMgt");
			}

			for (j=0; j<caseMgtNbr; j++)
			{
				/* retrieve caselinks for current Case */
				if ((ret = DBA_Select2(CaseLink, UNUSED, A_CaseManagement, caseMgtTab[j],
								  A_CaseLink, &caseLnkTab, UNUSED, UNUSED, &caseLnkNbr,
								  UNUSED, UNUSED)) != RET_SUCCEED)
				{
					FREE(caseMgtAccess); /* PMSTA15705 - DDV - 121226 - Purify */
					DBA_FreeDynStTab(copyCaseMgtTab, copyCaseMgtNbr, A_CaseManagement); /* PMSTA15705 - DDV - 121226 - Purify */
					return(ret);
				}

				for (k=0; k<caseLnkNbr; k++)
				{
					DBA_GetObjectEnum(GET_DICT(caseLnkTab[k], A_CaseLink_EntDictId),  &entity);
					if (entity == EOp)
					{
						/* found an ExtOp, case links must be copied */
						if (copyCaseLnkNbr == 0)
						{
							if ((copyCaseLnkTab = (DBA_DYNFLD_STP *)CALLOC(caseLnkNbr, sizeof(DBA_DYNFLD_STP)))==NULL)
							{
								MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "CopyCaseLink");
							}
						}
						else
						{
							if ((copyCaseLnkTab = (DBA_DYNFLD_STP *)REALLOC(copyCaseLnkTab, (caseLnkNbr + copyCaseLnkNbr) * sizeof(DBA_DYNFLD_STP)))==NULL)
							{
								MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "CopyCaseLink");
							}
						}

						foundFlg=FALSE;
						for (i=0; i<extOpAccessNbr && foundFlg==FALSE; i++)
						{
							/*
							if (CMP_ID(GET_EXTOP_DATABASE_ID(extOpAccessTab[i].data),GET_ID(caseLnkTab[k], A_CaseLink_ObjId))==0)
							*/
							if (CMP_ID(GET_ID(extOpAccessTab[i].data, ExtOp_Id),GET_ID(caseLnkTab[k], A_CaseLink_ObjId))==0) /* PMSTA-17345-CHU131211 */
							{
								/* Find and duplicate associated Case */
								int		dupIdx = 0;
								int		curCaseIdx = j;

								foundFlg=TRUE; /* found related ExtOp */

								if((copyCaseMgtTab[copyCaseMgtNbr] = ALLOC_DYNST(A_CaseManagement)) == NULLDYNST)
								{
									MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "CopyCaseMgt");
									FREE(caseMgtAccess); /* PMSTA15705 - DDV - 121226 - Purify */
									DBA_FreeDynStTab(copyCaseMgtTab, copyCaseMgtNbr, A_CaseManagement); /* PMSTA15705 - DDV - 121226 - Purify */
									DBA_FreeDynStTab(copyCaseLnkTab, copyCaseLnkNbr, A_CaseLink); /* PMSTA15705 - DDV - 121226 - Purify */
									return(RET_MEM_ERR_ALLOC);
								}

								COPY_DYNST(copyCaseMgtTab[copyCaseMgtNbr], caseMgtTab[curCaseIdx], A_CaseManagement);
								SET_ID(copyCaseMgtTab[copyCaseMgtNbr], A_CaseManagement_OldId, GET_ID(caseMgtTab[curCaseIdx], A_CaseManagement_Id));
								SET_NULL_ID(copyCaseMgtTab[copyCaseMgtNbr], A_CaseManagement_Id);
								SET_NULL_ID(copyCaseMgtTab[copyCaseMgtNbr], A_CaseManagement_SessionId);
								SET_NULL_CODE(copyCaseMgtTab[copyCaseMgtNbr], A_CaseManagement_Cd);
								copyCaseMgtNbr++;

								/* Now duplicate Case Links */
								for (dupIdx=0; dupIdx < caseLnkNbr; dupIdx++)
								{
                                    /* OCS-43991 - DDV - 131224 - Skip it to avoid null object_id, temporary solution (because case link will miss) */
									/*
									if (entity == EOp && GET_ID(extOpAccessTab[i].data, ExtOp_DbId) <=0)
                                        continue;
									*/

									if((copyCaseLnkTab[copyCaseLnkNbr] = ALLOC_DYNST(A_CaseLink)) == NULLDYNST)
									{
										MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "CopyCaseLink");
										FREE(caseMgtAccess); /* PMSTA15705 - DDV - 121226 - Purify */
										DBA_FreeDynStTab(copyCaseMgtTab, copyCaseMgtNbr, A_CaseManagement); /* PMSTA15705 - DDV - 121226 - Purify */
										DBA_FreeDynStTab(copyCaseLnkTab, copyCaseLnkNbr, A_CaseLink); /* PMSTA15705 - DDV - 121226 - Purify */
										return(RET_MEM_ERR_ALLOC);
									}
									COPY_DYNST(copyCaseLnkTab[copyCaseLnkNbr], caseLnkTab[dupIdx], A_CaseLink);

									/* Remember old Case Id */
									SET_ID(copyCaseLnkTab[copyCaseLnkNbr], A_CaseLink_OldCaseId, GET_ID(caseMgtTab[curCaseIdx], A_CaseManagement_Id));

									SET_NULL_ID(copyCaseLnkTab[copyCaseLnkNbr], A_CaseLink_Id);
									SET_NULL_ID(copyCaseLnkTab[copyCaseLnkNbr], A_CaseLink_CaseId);

									DBA_GetObjectEnum(GET_DICT(caseLnkTab[dupIdx], A_CaseLink_EntDictId),  &entity);
									if (entity == EOp)
									{
										/* PMSTA-17349 : Update on OCS-43991 code change
										   case_link and clarification well duplicated and saved
										   I did not see any issue on case_management, case_link or case_clarification id's...
										   Ben non, c'est pas l'beuzier...
										*/
										if (IS_NULLFLD(extOpAccessTab[i].data, ExtOp_DbId) == TRUE)
										{
                                            /* WEALTH-2617 - KKM - 20082024 */
                                            if (IS_NULLFLD(extOpAccessTab[i].data, ExtOp_ExtOrderId) == FALSE)
                                            {
                                                const DICT_T operationDictId = (DBA_GetDictEntityStSafe(Op))->entDictId;
                                                SET_DICT(copyCaseLnkTab[copyCaseLnkNbr], A_CaseLink_EntDictId, operationDictId);
                                                SET_ID(copyCaseLnkTab[copyCaseLnkNbr], A_CaseLink_ObjId, GET_ID(extOpAccessTab[i].data, ExtOp_ExtOrderId));
                                            }
                                            else
                                            {
                                                SET_ID(copyCaseLnkTab[copyCaseLnkNbr], A_CaseLink_ObjId, GET_ID(extOpAccessTab[i].data, ExtOp_Id)); /* PMSTA16077-CHU-130607 */
                                            }
										}
										else
										{
											/* PMSTA13206-CHU-130218 */ /* PMSTA16077-CHU-130313 */
											const DICT_T operationDictId = (DBA_GetDictEntityStSafe(Op))->entDictId;
											/* PMSTA13206-CHU-130218 */ /* PMSTA16077-CHU-130313 */
											SET_DICT(copyCaseLnkTab[copyCaseLnkNbr], A_CaseLink_EntDictId, operationDictId);
											SET_ID(copyCaseLnkTab[copyCaseLnkNbr], A_CaseLink_ObjId, GET_ID(extOpAccessTab[i].data, ExtOp_DbId)); /* PMSTA-17345-CHU131211 */
										}
									}
									copyCaseLnkNbr++;
								} /* for (dupIdx=0; dupIdx < caseLnkNbr; dupIdx++) */

								/* retrieve case clarifications and duplicate them too */
								if ((ret = DBA_Select2(CaseClarification, UNUSED, A_CaseManagement, caseMgtTab[curCaseIdx],
													   A_CaseClarification, &caseClarifTab, UNUSED, UNUSED, &caseClarifNbr,
													   UNUSED, UNUSED)) == RET_SUCCEED && caseClarifNbr > 0)
								{
									if (copyCaseClarifNbr == 0)
									{
										if ((copyCaseClarifTab = (DBA_DYNFLD_STP *)CALLOC(caseClarifNbr, sizeof(DBA_DYNFLD_STP)))==NULL)
										{
											MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "CopyCaseClarif");
										}
									}
									else
									{
										if ((copyCaseClarifTab = (DBA_DYNFLD_STP *)REALLOC(copyCaseClarifTab, (caseClarifNbr + copyCaseClarifNbr) * sizeof(DBA_DYNFLD_STP)))==NULL)
										{
											MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "CopyCaseClarif");
										}
									}

									for (dupIdx=0; dupIdx < caseClarifNbr; dupIdx++)
									{
										if((copyCaseClarifTab[copyCaseClarifNbr] = ALLOC_DYNST(A_CaseClarification)) == NULLDYNST)
										{
											MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "CopyCaseCaseClarification");
											FREE(caseMgtAccess); /* PMSTA15705 - DDV - 121226 - Purify */
											DBA_FreeDynStTab(copyCaseMgtTab, copyCaseMgtNbr, A_CaseManagement); /* PMSTA15705 - DDV - 121226 - Purify */
											DBA_FreeDynStTab(copyCaseLnkTab, copyCaseLnkNbr, A_CaseLink); /* PMSTA15705 - DDV - 121226 - Purify */
											DBA_FreeDynStTab(copyCaseClarifTab, copyCaseClarifNbr, A_CaseClarification); /* PMSTA15705 - DDV - 121226 - Purify */
											return(RET_MEM_ERR_ALLOC);
										}
										COPY_DYNST(copyCaseClarifTab[copyCaseClarifNbr], caseClarifTab[dupIdx], A_CaseClarification);

										/* Remember old Case Id */
										SET_ID(copyCaseClarifTab[copyCaseClarifNbr], A_CaseClarification_OldCaseId, GET_ID(caseMgtTab[curCaseIdx], A_CaseManagement_Id));
										SET_NULL_ID(copyCaseClarifTab[copyCaseClarifNbr], A_CaseClarification_Id);
										SET_NULL_ID(copyCaseClarifTab[copyCaseClarifNbr], A_CaseClarification_CaseId);
										copyCaseClarifNbr++;
									} /* for (dupIdx=0; dupIdx < caseLnkNbr; dupIdx++) */
								} /* if ((ret = DBA_Select2(CaseClarification */

								if (caseClarifNbr > 0)
								{
									DBA_FreeDynStTab(caseClarifTab, caseClarifNbr, A_CaseClarification);
								}
							} /* ExtOp_OpId == A_CaseLink_ObjId */
						} /* for (i=0; i<extOpAccessNbr; i++) */
					} /* if (entity == EOp) */
				} /* for (k=0; k<caseLnkNbr; k++) */
				if (caseLnkNbr > 0)
				{
					DBA_FreeDynStTab(caseLnkTab, caseLnkNbr, A_CaseLink);
				}
			} /* for (j=0; j<caseMgtNbr; j++) */

			if (copyCaseMgtNbr > 0)
			{
				FLAG_T				*scptFlagTab=NULL;

				if ((caseMgtAccess = (DBA_ACCESS_STP)CALLOC(copyCaseMgtNbr, sizeof(DBA_ACCESS_ST))) == NULL)
				{
					FREE(caseMgtAccess); /* PMSTA15705 - DDV - 121226 - Purify */
					DBA_FreeDynStTab(copyCaseMgtTab, copyCaseMgtNbr, A_CaseManagement); /* PMSTA15705 - DDV - 121226 - Purify */
					DBA_FreeDynStTab(copyCaseLnkTab, copyCaseLnkNbr, A_CaseLink); /* PMSTA15705 - DDV - 121226 - Purify */
					DBA_FreeDynStTab(copyCaseClarifTab, copyCaseClarifNbr, A_CaseClarification); /* PMSTA15705 - DDV - 121226 - Purify */
					MSG_RETURN(RET_MEM_ERR_ALLOC);
				}

				if ((scptFlagTab = (FLAG_T *)CALLOC(GET_FLD_NBR(A_CaseManagement), sizeof(FLAG_T))) == NULL)
				{
					FREE(caseMgtAccess); /* PMSTA15705 - DDV - 121226 - Purify */
					DBA_FreeDynStTab(copyCaseMgtTab, copyCaseMgtNbr, A_CaseManagement); /* PMSTA15705 - DDV - 121226 - Purify */
					DBA_FreeDynStTab(copyCaseLnkTab, copyCaseLnkNbr, A_CaseLink); /* PMSTA15705 - DDV - 121226 - Purify */
					DBA_FreeDynStTab(copyCaseClarifTab, copyCaseClarifNbr, A_CaseClarification); /* PMSTA15705 - DDV - 121226 - Purify */
					return(RET_MEM_ERR_ALLOC);
				}

				memset(scptFlagTab, (int)TRUE, GET_FLD_NBR(A_CaseManagement));
				scptFlagTab[A_CaseManagement_Cd] = FALSE;

				accessNbr=0;
				for (i=0; i<copyCaseMgtNbr; i++)
				{
					/* recompute Case Code */ /* PMSTA08614-CHU-090831 : give connectNo parameter */
					if (SCPT_ComputeDV(CaseManagement, scptFlagTab, copyCaseMgtTab[i], TRUE, TRUE, connectNo) != 0)
					{
						MSG_SendMesg(RET_SCPT_ERR_SYNTAX, 0, FILEINFO);
					}

					caseMgtAccess[accessNbr].action = Insert;
					caseMgtAccess[accessNbr].role   = UNUSED;
					caseMgtAccess[accessNbr].object = CaseManagement;
					caseMgtAccess[accessNbr].entity = A_CaseManagement;
					caseMgtAccess[accessNbr].data   = copyCaseMgtTab[i];
					++accessNbr;
				}

				FREE(scptFlagTab);

				if (accessNbr > 0)
				{
                    DbaMultiAccessHelper       multiAccessHelper(caseMgtAccess, accessNbr);

                    ret = multiAccessHelper.callMultiAccess(commitSz, DBA_SET_CONN|DBA_NO_CLOSE|DBA_NO_ERROR, connectNo, true);

                    if (ret != RET_SUCCEED)
                    {
                        multiAccessHelper.sendAllMultiAccessMsg();
                    }
                }

                /* now update caselinks with new case id's */
                if (copyCaseLnkNbr > 0) /* OCS-43991 - DDV - 140106 */
                {
				    if ((caseLnkAccess = (DBA_ACCESS_STP)CALLOC(copyCaseLnkNbr, sizeof(DBA_ACCESS_ST))) == NULL)
				    {
					    FREE(caseMgtAccess); /* PMSTA15705 - DDV - 121226 - Purify */
					    FREE(caseLnkAccess); /* PMSTA15705 - DDV - 121226 - Purify */
					    DBA_FreeDynStTab(copyCaseMgtTab, copyCaseMgtNbr, A_CaseManagement); /* PMSTA15705 - DDV - 121226 - Purify */
					    DBA_FreeDynStTab(copyCaseLnkTab, copyCaseLnkNbr, A_CaseLink); /* PMSTA15705 - DDV - 121226 - Purify */
					    DBA_FreeDynStTab(copyCaseClarifTab, copyCaseClarifNbr, A_CaseClarification); /* PMSTA15705 - DDV - 121226 - Purify */
					    MSG_RETURN(RET_MEM_ERR_ALLOC);
				    }
				}

				accessNbr=0;
				for (i=0; i<copyCaseMgtNbr; i++)
				{
					for (j=0; j<copyCaseLnkNbr; j++)
					{
						if (CMP_ID(GET_ID(copyCaseMgtTab[i], A_CaseManagement_OldId),
								   GET_ID(copyCaseLnkTab[j], A_CaseLink_OldCaseId))==0)
						{
							caseLnkAccess[accessNbr].action = Insert;
							caseLnkAccess[accessNbr].role   = UNUSED;
							caseLnkAccess[accessNbr].object = CaseLink;
							caseLnkAccess[accessNbr].entity = A_CaseLink;
							caseLnkAccess[accessNbr].data   = copyCaseLnkTab[j];

							SET_ID(copyCaseLnkTab[j], A_CaseLink_CaseId, GET_ID(copyCaseMgtTab[i], A_CaseManagement_Id));

							++accessNbr;
						}
					}
				}

				if (accessNbr > 0)
				{
                    DbaMultiAccessHelper       multiAccessHelper(caseLnkAccess, accessNbr);

					ret = multiAccessHelper.callMultiAccess(commitSz, DBA_SET_CONN|DBA_NO_CLOSE|DBA_NO_ERROR, connectNo, true);

                    if (ret != RET_SUCCEED)
                    {
                        multiAccessHelper.sendAllMultiAccessMsg();
                    }
                }

                if (copyCaseClarifNbr > 0 ) /*  FPL-PMSTA09806-100511   */
                {
				    /* now update caseclarifications with new case id's */
				    if ((caseClarifAccess = (DBA_ACCESS_STP)CALLOC(copyCaseClarifNbr, sizeof(DBA_ACCESS_ST))) == NULL)
				    {
						FREE(caseMgtAccess); /* PMSTA15705 - DDV - 121226 - Purify */
						FREE(caseLnkAccess); /* PMSTA15705 - DDV - 121226 - Purify */
						FREE(caseClarifAccess); /* PMSTA15705 - DDV - 121226 - Purify */
						DBA_FreeDynStTab(copyCaseMgtTab, copyCaseMgtNbr, A_CaseManagement); /* PMSTA15705 - DDV - 121226 - Purify */
						DBA_FreeDynStTab(copyCaseLnkTab, copyCaseLnkNbr, A_CaseLink); /* PMSTA15705 - DDV - 121226 - Purify */
						DBA_FreeDynStTab(copyCaseClarifTab, copyCaseClarifNbr, A_CaseClarification); /* PMSTA15705 - DDV - 121226 - Purify */
					    MSG_RETURN(RET_MEM_ERR_ALLOC);
				    }

				    if ((scptFlagTab = (FLAG_T *)CALLOC(GET_FLD_NBR(A_CaseClarification), sizeof(FLAG_T))) == NULL)
				    {
						FREE(caseMgtAccess); /* PMSTA15705 - DDV - 121226 - Purify */
						FREE(caseLnkAccess); /* PMSTA15705 - DDV - 121226 - Purify */
						FREE(caseClarifAccess); /* PMSTA15705 - DDV - 121226 - Purify */
						DBA_FreeDynStTab(copyCaseMgtTab, copyCaseMgtNbr, A_CaseManagement); /* PMSTA15705 - DDV - 121226 - Purify */
						DBA_FreeDynStTab(copyCaseLnkTab, copyCaseLnkNbr, A_CaseLink); /* PMSTA15705 - DDV - 121226 - Purify */
						DBA_FreeDynStTab(copyCaseClarifTab, copyCaseClarifNbr, A_CaseClarification); /* PMSTA15705 - DDV - 121226 - Purify */
					    return(RET_MEM_ERR_ALLOC);
				    }
				    memset(scptFlagTab, (int)TRUE, GET_FLD_NBR(A_CaseClarification));
				    scptFlagTab[A_CaseClarification_Cd] = FALSE;

				    accessNbr=0;
				    for (i=0; i<copyCaseMgtNbr; i++)
				    {
					    for (j=0; j<copyCaseClarifNbr; j++)
					    {
						    if (CMP_ID(GET_ID(copyCaseMgtTab[i], A_CaseManagement_OldId),
								       GET_ID(copyCaseClarifTab[j], A_CaseClarification_OldCaseId))==0)
						    {
							    SET_ID(copyCaseClarifTab[j], A_CaseClarification_CaseId, GET_ID(copyCaseMgtTab[i], A_CaseManagement_Id));

							    /* recompute CaseClarification Code */ /* PMSTA08614-CHU-090831 : give connectNo parameter */
							    if (SCPT_ComputeDV(CaseClarification, scptFlagTab, copyCaseClarifTab[j], TRUE, TRUE, connectNo) != 0)
							    {
								    MSG_SendMesg(RET_SCPT_ERR_SYNTAX, 0, FILEINFO);
							    }

							    caseClarifAccess[accessNbr].action = Insert;
							    caseClarifAccess[accessNbr].role   = UNUSED;
							    caseClarifAccess[accessNbr].object = CaseClarification;
							    caseClarifAccess[accessNbr].entity = A_CaseClarification;
							    caseClarifAccess[accessNbr].data   = copyCaseClarifTab[j];

							    ++accessNbr;
						    }
					    }
				    }

                    FREE(scptFlagTab);

				    if (accessNbr > 0)
				    {
                        DbaMultiAccessHelper       multiAccessHelper(caseClarifAccess, accessNbr);

                        ret = multiAccessHelper.callMultiAccess(commitSz, DBA_SET_CONN|DBA_NO_CLOSE|DBA_NO_ERROR, connectNo, true);

                        if (ret != RET_SUCCEED)
                        {
                            multiAccessHelper.sendAllMultiAccessMsg();
                        }
                    }
                }
			} /* if (copyCaseMgtNbr > 0) - Save All copies */
		} /* if (caseMgtNbr > 0) */
	}

	DBA_FreeDynStTab(copyCaseMgtTab, copyCaseMgtNbr, A_CaseManagement); /* PMSTA15705 - DDV - 121226 - Purify */
	DBA_FreeDynStTab(copyCaseLnkTab, copyCaseLnkNbr, A_CaseLink); /* PMSTA15705 - DDV - 121226 - Purify */
	DBA_FreeDynStTab(copyCaseClarifTab, copyCaseClarifNbr, A_CaseClarification); /* PMSTA15705 - DDV - 121226 - Purify */
	/* FREE(caseLnkTab); */ /* PMSTA15812-CHU-130122 : ptr is NULL or already freed above */
	FREE(caseMgtAccess);
	FREE(caseLnkAccess);
    FREE(caseClarifAccess);

	return(ret);
}

/************************************************************************
**
**  Function    :   DBA_FamilyOrderOnError.
**
**  Description :   In case of error in DBA_FamilyOrder, this function modify the extOpTab extops
**		       to be in the same state than before call to DBA_FamilyOrder (a kind of logical rollback)
**
**  Arguments   :
**                                      DBA_DYNFLD_STP*  extOpTab,
**                                      int              extOpNbr,
**                                      int              colNbr,
**					saveExtOpTab
**
**  Return      :   RET_CODE.
**
**  Cr�ation    :   REF4083 - SSO - 991027   error handling: extop must be "logically rollbacked"
**
**  Last modif. :   REF10469 - 040721 - PMO : Impossible to save a session generated by Reconcile Strategy if you have Constraint Breach records (problem with DBA_FamilyOrder)
**
*************************************************************************/
STATIC void DBA_FamilyOrderOnError(DBA_DYNFLD_STP* extOpTab,
                                   int extOpNbr,
                                   int colNbr,
                                   DBA_DYNFLD_STP* saveExtOpTab)
{
	DBA_DYNFLD_STP	extOpPtr, dynTab;
    int				i;

    for (i=0; i < extOpNbr; i++)
    {
        /* In case of array is not a real dynamic structure array (GUI) */
        if (colNbr == 0)
            extOpPtr = extOpTab[i];
        else
        {
            /* in fact, in that case we don't receive a DBA_DYNFLD_STP * (cast by GUI) */
            dynTab = (DBA_DYNFLD_STP) extOpTab;
            extOpPtr = &(dynTab[i*colNbr]);
        }

		if (saveExtOpTab[i] != NULL)
		{
			COPY_DYNST(extOpPtr, saveExtOpTab[i], ExtOp);
		}
    }
}

/************************************************************************
**
**  Function    :   DBA_LogSubscriptionEvents.
**
**  Description :
**
**  Arguments   :
**
**  Return      :   RET_CODE.
**
**  Cr�ation    :   REF4204 - GRD - 000204.
**
**  Modif.      :   REF5396 - GRD - 001107. Beware of database connections when using transaction.
*************************************************************************/
RET_CODE DBA_LogSubscriptionEvents(OBJECT_ENUM				object,
								   SUBSCRIPTION_ACTION_ENUM	action,
								   DBA_DYNST_ENUM			inputSt,
								   DBA_DYNFLD_STP			inputData,
								   DBA_DYNFLD_STP			inputDataOld,
								   DbiConnection&           dbiConn,
								   DBA_DYNFLD_STP		   *outSubscription,
								   int						outSubscriptionNbr)
{
	int			  i = 0;
	RET_CODE	  retCode = RET_SUCCEED;
    DATETIME_T    begDateTime, endDataTime, curDateTime, creation_d; /* DLA - REF6935 - 020211 */
    FLAG_T        resultFlg = FALSE, insGroupingFlg = FALSE, orderBackupRollbackFlg = FALSE, flagActivateDES = FALSE;
    CODE_T        groupingCode;
    ENUM_T        accountingStatus=0;
    auto          modifCurDisableSubEnum = MODIFCUR_DISABLE_SUB_ENUM::KeepSubscription;          /* PMSTA-41376 - MSS - 100820 */

    groupingCode[0]=END_OF_STRING;

    DATE_CurrentDateTime(&curDateTime);

    /* DLA - REF6935 - 020211 first input*/
    if ((dbiConn.getConnStructPtr()->subscriptionElem.accessNbr == 0 && dbiConn.getConnStructPtr()->blockMode == TRUE) ||
        (dbiConn.getConnStructPtr()->blockMode == FALSE)) /* DLA - REF6935 - 020729 FIX ! */
    {
        if (DBA_GetDbDate(&creation_d) != RET_SUCCEED)
        {
            memset(&creation_d, 0, sizeof(DATETIME_ST));
        }
        dbiConn.getConnStructPtr()->subscriptionElem.creation_d = creation_d;
    }

    /* PMSTA-17870 - DDV - 140429 */
	GEN_GetApplInfo(ApplOrderBackupRollbackActivateFlg, &orderBackupRollbackFlg);
	GEN_GetApplInfo(ApplAccountingStatus, &accountingStatus);
    GEN_GetApplInfo(ApplModifCurDisableSubEnum, &modifCurDisableSubEnum);  /*PMSTA - 41376 - MSS - 100820 */
    GEN_GetApplInfo(ApplDesFlag, &flagActivateDES);         /*PMSTA - 45305 - Likh- 210505 */

    OutboxEventModeEn applOutboxEventModeEn = OutboxEventModeEn::None;
    GEN_GetApplInfo(ApplOutboxEventModeEnum, &applOutboxEventModeEn);

    /*PMSTA-49443 -Lalby-07062022- Ease outbox records generation testing: exclude schema validation check and ApplDesFlag for testing purpose*/
    if (EV_ForceOutboxInsert)
    {
        flagActivateDES = TRUE;
    }

	for (i = 0; i < outSubscriptionNbr; i++)
	{
        if (SubscriptionNatEn::Outbox == GET_A_Subscription_NatEn(outSubscription[i])
            && FALSE == flagActivateDES)
        {
            continue;
        }

        if (SubscriptionNatEn::OutboxEvent == GET_A_Subscription_NatEn(outSubscription[i]))
        {
            if (applOutboxEventModeEn == OutboxEventModeEn::Subscription)
            {
                if (IS_NOTNULL(outSubscription[i], A_Subscription_ParentEntityDictId))
                {
                    auto parentObjectEn = inputData->getDictEntityStp()->getParentObjectEn(inputData);
                    auto parentDictEntityStp = DBA_GetDictEntitySt(parentObjectEn);
                    if (parentDictEntityStp == nullptr ||
                        parentDictEntityStp->entDictId != GET_DICT(outSubscription[i], A_Subscription_ParentEntityDictId))
                    {
                        continue;
                    }
                }
            }
            else
            {
                continue;
            }
        }

		/* If the domain is to be watched, verify the function dict_id. */
		if (object == Domain)
		{
			if ((IS_NULLFLD(outSubscription[i], A_Subscription_FctDictId) == FALSE) &&
			    (GET_DICT(outSubscription[i], A_Subscription_FctDictId) != GET_DICT(inputData, A_Domain_FctDictId)))
			{
				continue;
			}
		}

		/* Action could be:
		 *	- Subscription_Action_Insert.
		 *	- Subscription_Action_Update.
		 *	- Subscription_Action_Delete.
		 *	- Subscription_Action_AllDbAccess. (Means the 3 above).
		 */

		if ((IS_NULLFLD(outSubscription[i], A_Subscription_ActionEn) == FALSE) &&
		    (GET_ENUM(outSubscription[i],   A_Subscription_ActionEn) != Subscription_Action_None))
		{
			if ((GET_ENUM(outSubscription[i], A_Subscription_ActionEn) == Subscription_Action_AllDbAccess) &&
			    ((action != Subscription_Action_Insert) &&
			     (action != Subscription_Action_Update) &&
			     (action != Subscription_Action_Delete)))
			{
				continue;
			}

			if ((GET_ENUM(outSubscription[i], A_Subscription_ActionEn) != Subscription_Action_AllDbAccess) &&
			    (GET_ENUM(outSubscription[i], A_Subscription_ActionEn) != action))
			{
				continue;
			}
		}

		/* Event nature can be:
		 *	- Event_Nature_None.			Means all kind of event nature.
		 *	- Event_Nature_Order.
		 *	- Event_Nature_Admin.
		 *	- Event_Nature_Other.
		 */

		if ((IS_NULLFLD(outSubscription[i], A_Subscription_EventNatEn) == FALSE) &&
		    (GET_ENUM(outSubscription[i],   A_Subscription_EventNatEn) != Event_Nature_None) &&
			dbiConn.getConnStructPtr()->subscriptionElem.eventNat != Event_Nature_None)
		{
			if (GET_ENUM(outSubscription[i], A_Subscription_EventNatEn) != dbiConn.getConnStructPtr()->subscriptionElem.eventNat)
			{
				continue;
			}
		}

        /*
         * Check min and max update status.
         */

        /* PMSTA-55863 - AAKASH - 19042024 : Min and Max Status check for Outbox Subscription */
        if ((GET_DICT(outSubscription[i], A_Subscription_EntityDictId) == (DBA_GetDictEntityStSafe(EOp))->entDictId) &&
            (GET_A_Subscription_NatEn(outSubscription[i]) == SubscriptionNatEn::Event ||
                GET_A_Subscription_NatEn(outSubscription[i]) == SubscriptionNatEn::Outbox) &&
            (IS_NULLFLD(outSubscription[i], A_Subscription_MinOperStatusEn) == FALSE) &&
            (IS_NULLFLD(outSubscription[i], A_Subscription_MaxOperStatusEn) == FALSE))
        {
            if (GET_ENUM(outSubscription[i], A_Subscription_MinOperStatusEn) > GET_ENUM(inputData, ExtOp_StatusEn) ||
                GET_ENUM(outSubscription[i], A_Subscription_MaxOperStatusEn) < GET_ENUM(inputData, ExtOp_StatusEn))
            {
                continue;
            }
        }

         /*
        * PMSTA-41376 - MSS - 100820
        * Is this subscription from modif currency? If MODIF_CUR_DISABLE_ENUM is set, subcription event is disabled.
        */
        DBA_PROC_STP currModifProcLstStp = nullptr;
        if (SYS_GetRpcName().empty() == false
            && modifCurDisableSubEnum == MODIFCUR_DISABLE_SUB_ENUM::DisableSubEvent
            && (currModifProcLstStp = AaaMetaDict::getObjProcLstStp(CurrModif)) != nullptr)
        {
            bool skipSub = false;
            for (int idx = 0; currModifProcLstStp[idx].action != NullAction; idx++)
            {
                if(SYS_GetRpcName() == currModifProcLstStp[idx].procName)
                {
                    skipSub = true;
                    break;
                }
            }
            if(skipSub)
            {
                continue;
            }
        }

        /*
         * Is this subscription still valid?
         */

        begDateTime = GET_DATETIME(outSubscription[i], A_Subscription_BeginDate);

        if (DATETIME_CMP(begDateTime, curDateTime) > 0)
        {
            continue;
        }

        if (IS_NULLFLD(outSubscription[i], A_Subscription_EndDate) == FALSE)
        {
            endDataTime = GET_DATETIME(outSubscription[i], A_Subscription_EndDate);

            if (DATETIME_CMP(endDataTime, curDateTime) < 0)
            {
                continue;
            }
        }

		/*
		 * Call the script to validate the subscription.
		 */

        if ((retCode = SCPT_CheckSubscriptionScript(outSubscription[i],
                                                    inputData,
                                                    inputDataOld, /* DLA - REF10731 - 041101 */
                                                    &resultFlg,
                                                    dbiConn)) != RET_SUCCEED)
        {
            return (retCode);
        }

        if (resultFlg == FALSE)         /* Subscription is not valid for this entity. */
        {
            continue;
        }

		/*
		 * This entity has to be inserted into event or audit table.
		 */

        switch (GET_ENUM(outSubscription[i], A_Subscription_EventGroupingEn))
        {
            case EventGrouping_Record:
                insGroupingFlg = TRUE;
                break;
            default:
                insGroupingFlg = FALSE;
                break;
        }

		if ((retCode = DBA_InsertEvent( object,
                                        inputSt,
                                        inputData,
                                        inputDataOld,
                                        action,
                                        outSubscription[i],
										dbiConn.getConnStructPtr()->subscriptionElem.eventNat,
                                        (SYS_IsGuiMode() == TRUE)   ? SubscriptionModuleEn::Gui :
                                        (SYS_IsSrvMode() == TRUE)   ? SubscriptionModuleEn::Server :
                                        (SYS_IsBatchMode() == TRUE) ? SubscriptionModuleEn::Import :
                                                                      SubscriptionModuleEn::Other,
                                        dbiConn,
                                        insGroupingFlg,
                                        groupingCode)) != RET_SUCCEED) /* DLA - REF10512 - 040802 */
        {
            return (retCode);
        }

        /* PMSTA-17764 - DDV - 140306 - Backup old order */
        if (action == Subscription_Action_Update &&
            orderBackupRollbackFlg == TRUE &&  /* PMSTA-17870 - DDV - 140429 */
            GET_FLAG(outSubscription[i], A_Subscription_EventStatusFlg) == TRUE &&
            object == EOp &&
            GET_ENUM(inputData, ExtOp_EventActionEn) != Subscription_Action_Cancel &&
            inputDataOld != NULLDYNSTPTR &&
            GET_ENUM(inputData,    ExtOp_StatusEn) < accountingStatus &&    /* PMSTA-17870 - DDV - 140430 - Backup/roolback is not possible on accounted operations */
            GET_ENUM(inputDataOld, ExtOp_StatusEn) < accountingStatus)      /* No backup when add to order  PMSTA-22637 - 030316 - PMO */
        {
            /* PMSTA-22226 - 220116 - PMO
             * This is a workaround client is in production and need a quick solution.
             * The only case found where the end_d is null is when the operation is accounted and treated by the fusion engine
             */
            if (IS_NULLFLD(inputDataOld, ExtOp_EndDate) == TRUE)
            {
                DATETIME_T magicEndDateTime;

                magicEndDateTime.time = 0;
                magicEndDateTime.date = MAGIC_END_DATE;
                SET_DATETIME(inputDataOld, ExtOp_EndDate, magicEndDateTime);
            }

            /*PMSTA-32386-NRAO-181114-Using DBA_Notif2 instead of DBA_Insert2 for this special case*/
            /*PMSTA-36267 - 190619 - SRIDHARA
            * using DBA_Insert2 to insert the whole inputDataOld instead only id.
            * To achieve the order roll back function need to save all the attributes of ext_order_bck
            */
            if ((retCode = DBA_Insert2(object, DBA_ROLE_BACKUP, inputSt,  inputDataOld, DBA_SET_CONN|DBA_NO_CLOSE|DBA_IN_TRAN, dbiConn, UNUSED)) != RET_SUCCEED)
            {
                return(retCode);
            }
        }
	}

	return(retCode);
}

/************************************************************************
**
**  Function    :   DBA_GetObjectBusEntity.
**
**  Description :   Return the business entity id to set into the event using subscription's business_entity_election_e
**
**
**  Arguments   :
**
**  Return      :   RET_CODE.
**
**  Cr�ation    :   PMSTA17089 - DDV - 131205
**
**  Modif.      :   PMSTA-17593 - DDV - 140212 - change bus_entity_id to bus_entity_cd
**
*************************************************************************/
RET_CODE DBA_GetObjectBusEntity(OBJECT_ENUM                object,
                                DBA_DYNST_ENUM             ,
                                DBA_DYNFLD_STP             inputData,
                                DBA_DYNFLD_STP             inputDataOld,
                                DBA_DYNFLD_STP             outSubscription,
                                DbiConnection&             dbiConn,
                                CODE_T                     businessEntityCd)
{
    DICT_ATTRIB_STP dictAttrPtr=NULL;
    RET_CODE        retCode=RET_SUCCEED;
    FLAG_T          allocFlg=FALSE;
    DBA_DYNFLD_STP  ptfPtr=NULLDYNST;
    ID_T            businessEntityId=0;
    DBA_DYNFLD_STP  admArg=NULLDYNST;
    DBA_DYNFLD_STP  sBusEntity=NULLDYNST;
    ID_T            codifId=0;

    businessEntityCd[0] = END_OF_STRING;

    switch(GET_ENUM(outSubscription, A_Subscription_BusEntitySelectionEn))
    {
        case EventBusEntitySelectEn_Main:
            switch (GET_OBJECT_CST(object))
            {
                case EOpCst:
                    if (DBA_GetPtfById(GET_ID(inputData, ExtOp_PtfId), TRUE, &allocFlg, &ptfPtr, NULL,
                                       DBA_SET_CONN | DBA_NO_CLOSE, (int*)&dbiConn.getId()) == RET_SUCCEED)
                    {
                        if (IS_NULLFLD(ptfPtr, A_Ptf_MainBusEntityId) == FALSE)
                        {
                            businessEntityId = GET_ID(ptfPtr, A_Ptf_MainBusEntityId);
                        }

                        if (allocFlg == TRUE) {FREE_DYNST(ptfPtr, A_Ptf);}
                    }
                    break;
                default:
                    dictAttrPtr = DBA_GetDictEntityStSafe(object)->ownerBusinessEntAttrStp;
                    if (dictAttrPtr != NULL &&
                        IS_NULLFLD(inputData, dictAttrPtr->progN) == FALSE &&
                        dictAttrPtr->dataTpProgN == IdType)
                    {
                        businessEntityId = GET_ID(inputData, dictAttrPtr->progN);
                    }
                    break;
            }
            break;
        case EventBusEntitySelectEn_Script:
            if ((retCode = SCPT_ExecSubscriptionBusEntityScript(outSubscription,
                                                                inputData,
                                                                inputDataOld,
                                                                &businessEntityId,
                                                                dbiConn)) != RET_SUCCEED)
            {
                return (retCode);
            }

            break;

        case EventBusEntitySelectEn_MultiEnt: /* DLA - PMSTA-28564 - 170925 */
            switch (GET_OBJECT_CST(object))
            {
            case EOpCst:
                if (DBA_GetPtfById(GET_ID(inputData, ExtOp_PtfId), TRUE, &allocFlg, &ptfPtr, NULL,
                    DBA_SET_CONN | DBA_NO_CLOSE, (int*)&dbiConn.getId()) == RET_SUCCEED)
                {
                    dictAttrPtr = DBA_GetDictEntityStSafe(Ptf)->ownerBusinessEntAttrStp;
                    if (dictAttrPtr != NULL &&
                        IS_NULLFLD(ptfPtr, dictAttrPtr->progN) == FALSE &&
                        dictAttrPtr->dataTpProgN == IdType)
                    {
                        businessEntityId = GET_ID(ptfPtr, dictAttrPtr->progN);
                    }

                    if (allocFlg == TRUE) { FREE_DYNST(ptfPtr, A_Ptf); }
                }
                break;
            default:
                dictAttrPtr = DBA_GetDictEntityStSafe(object)->ownerBusinessEntAttrStp;
                if (dictAttrPtr != NULL &&
                    IS_NULLFLD(inputData, dictAttrPtr->progN) == FALSE &&
                    dictAttrPtr->dataTpProgN == IdType)
                {
                    businessEntityId = GET_ID(inputData, dictAttrPtr->progN);
                }
                break;
            }
            break;

        default:
            break;
    }

    if (businessEntityId > 0)
    {
        /* PMSTS-17593 - DDV - 140211 - Get business_entity's code or sysnonym */
        if ((admArg = ALLOC_DYNST(Adm_Arg)) == NULLDYNSTPTR)
        {
            return(RET_MEM_ERR_ALLOC);
        }

        if ((sBusEntity = ALLOC_DYNST(S_BusEntity)) == NULLDYNSTPTR)
        {
            FREE_DYNST(admArg, Adm_Arg);
            return(RET_MEM_ERR_ALLOC);
        }

        SET_ID(admArg, Adm_Arg_Id, businessEntityId);

        if (DBA_GetSubsCodif(BusEntityCst, &codifId, dbiConn) == TRUE)
            SET_ID(admArg, Adm_Arg_CodifId, codifId);

        if ((retCode = DBA_Get2(BusEntity, UNUSED, Adm_Arg, admArg, S_BusEntity, &sBusEntity,
                                DBA_SET_CONN | DBA_NO_CLOSE, dbiConn)) != RET_SUCCEED)
        {
            FREE_DYNST(admArg, Adm_Arg);
            FREE_DYNST(sBusEntity, S_BusEntity);
            return(RET_DBA_ERR_NODATA);
        }

        strcpy(businessEntityCd, GET_STRING(sBusEntity, A_BusEntity_Cd));

        FREE_DYNST(admArg, Adm_Arg);
        FREE_DYNST(sBusEntity, S_BusEntity);
    }

    return(RET_SUCCEED);
}

int DBA_BuildStrWithFormat(
	OBJECT_ENUM object, DBA_DYNFLD_STP aFmtStp, DBA_DYNFLD_STP aDynSt,
	char ** totalBuff, DbiConnection &dbiConn,FLAG_T);


/************************************************************************
**
**  Function    :   DBA_InsertEvent.
**
**  Description :   Insert an event into table 'audit' or 'event'.
**
**
**  Arguments   :
**
**  Return      :   RET_CODE.
**
**  Cr�ation    :   REF4204 - GRD - 000204.
**
**  Modif.      :   REF4942 - GRD - 000630.
**                  REF5309 - DLA - 001122.
**                  REF5309 - GRD - 001213.
**                  REF7264 - 0201225 - PMO : Compilation errors and warnings with C++ compiler
**                  PMSTA-16124 - 250413 - PMO : Ensure coherence of printf / scanf formats with 32bits / 64 bits datatypes
**
*************************************************************************/
STATIC RET_CODE DBA_InsertEvent(OBJECT_ENUM                object,
                                DBA_DYNST_ENUM             inputSt,
                                DBA_DYNFLD_STP             inputData,
                                DBA_DYNFLD_STP             inputDataOld,			/* For audit purpose. */
                                SUBSCRIPTION_ACTION_ENUM   actionEn,
                                DBA_DYNFLD_STP             outSubscription,
                                EVENT_NATURE_ENUM          evtNatureEn,
                                SubscriptionModuleEn       moduleEn,
                                DbiConnection&             dbiConn,
                                FLAG_T                     insGroupingFlg,
                                CODE_T                     groupingCode)
{
    RET_CODE             retCode = RET_SUCCEED;

    if (GET_A_Subscription_NatEn(outSubscription) == SubscriptionNatEn::OutboxEvent)
    {
        DBA_ACTION_ENUM dbaActionEn = NullAction;
        switch (actionEn)
        {
            case Subscription_Action_Insert:
                dbaActionEn = Insert;
                break;

            case Subscription_Action_Update:
                dbaActionEn = Update;
                break;

            case Subscription_Action_Delete:
                dbaActionEn = Delete;
                break;
        }
        dbiConn.getOutboxManager().addRecord(inputData, dbaActionEn, OutboxEventModeEn::Subscription);

        return RET_SUCCEED;
    }

    RET_CODE             retCode2 = RET_SUCCEED;
	DICT_ENTITY_STP	     dictEntityStp = NULL;
    DICT_ATTRIB_STP      attribute;
//	char				 *buffer = NULL;
	char				 *outputDataBuf = NULL,
		    			 *outputDataBufOld = NULL,
			    		 *outputDataBufAudit = NULL;
    char                 *txtOld = NULL; /* DLA - REF8712 - 031114 */
    DBA_DYNFLD_STP       *outSubsCompo = NULL;
	SYSNAME_T			 hostname;
	SYSNAME_T			 entityCd;
    char                 userCode[MAX_USERINFO_LEN +1];
	EVENT_STATUS_ENUM	 evtStsEn = Event_Status_Untreated;
	DATETIME_ST			 creationDate;
	char				 *mapStorage = NULL;
    int                  outSubsNmb = 0;
    CODE_T               businessEntityCd;
	int					 count;
	DBA_CONNECT_INFO_STP connInfo = dbiConn.getConnStructPtr();
	DICT_ATTRIB_STP * attributes;

     memset (businessEntityCd, 0, GET_MAXDATALEN(CodeType) * sizeof(char)); /* PMSTA-33077 - DLA - 181011 */

 	*hostname         = END_OF_STRING;
	*entityCd         = END_OF_STRING;

    DBA_DYNFLD_STP*  sOutboxSchemaTab = nullptr;
    DBA_DYNFLD_STP sOutboxSchema = nullptr;
    int sOutboxSchemaNbr = 0;
    MemoryPool mp;

	dictEntityStp = DBA_GetDictEntitySt(object);
	strcpy(entityCd, dictEntityStp->mdSqlName);				/* Set entity name. */
	SYS_GetHostName(hostname, GET_MAXDATALEN(SysnameType));				/* Set hostname.      */    /* PMSTA-33077 - DLA - 181011 */


	/* ACB - REF11825 - 060524 > */
	if(SYS_IsSrvMode() == TRUE)
	{
		DBA_GetUserInfo2(A_ApplUser_Cd, userCode, TRUE);
	}
	else
	{
		DBA_GetUserInfo(A_ApplUser_Cd, userCode);
	}
	/* < ACB - REF11825 - 060524 */

    creationDate= connInfo->subscriptionElem.creation_d; /* DLA - REF6935 - 020207 */

	/*
	 * 2 kinds of possible subscriptions:
	 *	- Event.
	 *	- Audit.
	 */

    SubscriptionNatEn subscriptionEn = GET_A_Subscription_NatEn(outSubscription);

    if (SubscriptionNatEn::Outbox == subscriptionEn)
    {
        if ((retCode = DBA_Select2(OutboxSchema,
            UNUSED,
            A_Subscription,
            outSubscription,
            S_OutboxSchema,
            &sOutboxSchemaTab,
            DBA_SET_CONN | DBA_NO_CLOSE,
            UNUSED,
            &sOutboxSchemaNbr,
            dbiConn)) != RET_SUCCEED 
            || (0 == sOutboxSchemaNbr && EV_ForceOutboxInsert == false))
        {
                 char buffer[250];
                 snprintf(buffer, sizeof(buffer)-1,
                     "Schema is not found for outbox subscription: %s",
                     GET_CODE(outSubscription, A_Subscription_Cd)
                 );

                 MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, buffer);
 
            return  RET_SUCCEED; /* process remaining subscriptions */
        }

		mp.owner(sOutboxSchemaTab);

		/* PMSTA-49936 -Lalby - 28072022 -Notepad entity have multiple schema*/
		/*Find the schema for the linked entity : notepad-portfolio, notepad-instrument ...*/
		if (IS_NULLFLD(outSubscription, A_Subscription_EntityDictId) == FALSE &&
			GET_DICT(outSubscription, A_Subscription_EntityDictId)== NotepadCst &&
			inputData != nullptr && GET_DYNSTENUM(inputData) == A_Notepad)
		{
			for (int i = 0; i < sOutboxSchemaNbr; ++i)
			{
				/* schema linked entity id should be present in the outbox_schema table for the Notepad*/
				if (IS_NULLFLD(sOutboxSchemaTab[i], S_OutboxSchema_LnkEntityDictId) == FALSE &&
					IS_NULLFLD(inputData, A_Notepad_EntDictId) == FALSE &&
					CMP_DYNFLD(sOutboxSchemaTab[i], inputData, S_OutboxSchema_LnkEntityDictId, A_Notepad_EntDictId,DictType) == 0)
				{
					sOutboxSchema = sOutboxSchemaTab[i];
					break;
				}
			}

			if (sOutboxSchema == nullptr && EV_ForceOutboxInsert == false)
			{
                 char buffer[250];
                 snprintf(buffer, sizeof(buffer)-1,
                     "Linked entity is not found for Notepad Schema subscription:%s",
                     GET_CODE(outSubscription, A_Subscription_Cd)
                 );

                 MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, buffer);

				return  RET_SUCCEED; /* process remaining subscriptions */
			}
		}
		else if(sOutboxSchemaNbr > 0)
		{
			sOutboxSchema = sOutboxSchemaTab[0];
		} 
    }

    /*
     * We have to know if this subscription is linked with a codifications list.
     */

    DBA_DYNFLD_STP inputAdmData = mp.allocDynst(FILEINFO,Adm_Arg);

    SET_ID(inputAdmData, Adm_Arg_Id, GET_ID(outSubscription, A_Subscription_Id));

	if((retCode = DBA_Select2(SubscriptionCodifCompo,
                          UNUSED,
                          Adm_Arg,
                          inputAdmData,
                          S_SubscriptionCodifCompo,
                          &outSubsCompo,
                          DBA_SET_CONN | DBA_NO_CLOSE,
                          UNUSED,
                          &outSubsNmb,
                          dbiConn)) != RET_SUCCEED)
    {
        DBA_FreeDynStTab(outSubsCompo,outSubsNmb,S_SubscriptionCodifCompo);
        return(retCode);
    }

    mp.ownerDynStpTab(outSubsCompo,outSubsNmb);

    connInfo->subscriptionElem.subscripCodifCompoStp = outSubsCompo;
	connInfo->subscriptionElem.subscripCodifCompoNmb = outSubsNmb;

    /* PMSTA-17089 - DDV - 131205 - Set event's business_entity_id */ /* PMSTA-17593 - DDV - 140212 - Moved to have codification info available */
    if (GET_ENUM(outSubscription, A_Subscription_BusEntitySelectionEn) != EventBusEntitySelectEn_None)
    {
        DBA_GetObjectBusEntity(object, inputSt, inputData, inputDataOld, outSubscription, dbiConn, businessEntityCd);
    }

    /*
     *  REF5309 - DLA - 001122. : we dont't need to resolve the foreign keys if we have a
     *                            format for an event subscription.
     */

    if ( ((subscriptionEn == SubscriptionNatEn::Event) ||
          SubscriptionNatEn::Outbox == subscriptionEn) &&
         (IS_NULLFLD(outSubscription, A_Subscription_FmtId) == FALSE))

    {
        DBA_DYNFLD_STP             sFmtStp = mp.allocDynst(FILEINFO,S_Fmt);
        DBA_DYNFLD_STP             aFmtStp = mp.allocDynst(FILEINFO,A_Fmt);

        SET_ID(sFmtStp, S_Fmt_Id, GET_ID(outSubscription, A_Subscription_FmtId));
        if ((retCode = DBA_Get2(Fmt, UNUSED, S_Fmt, sFmtStp, A_Fmt, &aFmtStp, DBA_SET_CONN | DBA_NO_CLOSE, dbiConn)) != RET_SUCCEED)
        {
            connInfo->subscriptionElem.subscripCodifCompoNmb = 0;
            return(retCode);
        }

        /* PMSTA-34383 - DDV - 190307 - Build string for record if needed */
        char *recBuff = NULL;

        //if ((GET_ENUM(aFmtStp, A_Fmt_NatEn) == FmtNat_SubscriptionEnrichment || object == EOp) &&
            if ((retCode = DBA_ConvertDynStToString2(object,
                                                 inputSt,
                                                 (actionEn == Subscription_Action_Delete) ? inputDataOld : inputData,
                                                 0,
                                                 FALSE,
                                                 NULL,
                                                 &recBuff,
                                                 DBA_SET_CONN | DBA_NO_CLOSE,
                                                 0,
                                                 TRUE,                           /*  FIH-REF10666-041005 Save virtual fileds */
                                                 dbiConn,
                                                 TRUE,
                                                 GET_ENUM(aFmtStp, A_Fmt_NatEn) != FmtNat_SubscriptionEnrichment,
                                                 FALSE,
                                                 subscriptionEn)) != RET_SUCCEED)
	    {
			connInfo->subscriptionElem.subscripCodifCompoNmb = 0;
            return(retCode);
	    }

        mp.ownerPtr(recBuff);
        /* PMSTA-34383 - DDV - 190307 - Build string based on format */
        char *fmtBuff = NULL;

        if (DBA_BuildStrWithFormat(object,
                                   aFmtStp,
                                   (actionEn == Subscription_Action_Delete) ? inputDataOld : inputData,
                                   &fmtBuff,
                                   dbiConn,
                                   ((subscriptionEn == SubscriptionNatEn::Outbox) ? TRUE :FALSE)) != TRUE)
	    {
			connInfo->subscriptionElem.subscripCodifCompoNmb = 0;
            return(RET_DBA_ERR_INVDATA);
	    }

         mp.ownerPtr(fmtBuff);

        //if ((GET_ENUM(aFmtStp, A_Fmt_NatEn) == FmtNat_SubscriptionEnrichment || object == EOp) &&
        if (recBuff != NULL)
        {
            outputDataBuf = (char *)mp.calloc(GET_MAXDATALEN(TextType), sizeof(char));

            /*PMSTA-52148 - GAD - 20240320 - fmtBuff should not be NULL */
            if (fmtBuff == NULL)
                fmtBuff = "";

            if (strlen(recBuff) + strlen(fmtBuff) + 1 > GET_MAXDATALEN(TextType))
            {
                connInfo->subscriptionElem.subscripCodifCompoNmb = 0;
                return(RET_GEN_ERR_LENGTH);
            }
            snprintf(outputDataBuf, GET_MAXDATALEN(TextType), "%s%s", recBuff, fmtBuff);
        }
        else
        {
            outputDataBuf = fmtBuff;
        }

        if (ICU4AAA_SQLServerUTF8 != 0)
        { /* Unicode processing */
            UChar * ucharTmpBufPtr = (UChar *)mp.calloc(GET_MAXDATALEN(UniTextType), sizeof(UChar));                            /* PMSTA-33077 - DLA - 181011 */

            if (SYS_IsSrvMode())
            {
                /* Some encoded unicode fields can exist */
                if (0 == ICU4AAA_ConvertFromUTF8(outputDataBuf, -1, ucharTmpBufPtr, GET_MAXCHARLEN(TextType), NULL))        /* PMSTA-33077 - DLA - 181011 */
                { /* Conversion ok */

                    /* Conversion of all characters (not only unicode fields) */
                    if (-1 == ICU4AAA_ConvertToHTML(ucharTmpBufPtr, -1, outputDataBuf, GET_MAXDATALEN(TextType), NULL))     /* PMSTA-33077 - DLA - 181011 */
                    { /* Error */
                        MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Error while converting to XML");
                    }
                }
                else
                { /* Error */
                    MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Error while converting from UTF8");
                }
            }
            else
            {
                /* Some encoded unicode fields can exist */
                if (0 == ICU4AAA_ConvertFromHTML(outputDataBuf, -1, ucharTmpBufPtr, GET_MAXCHARLEN(TextType), NULL))        /* PMSTA-33077 - DLA - 181011 */
                { /* Conversion ok */

                    /* Conversion of all characters (not only unicode fields) */
                    if (-1 == ICU4AAA_ConvertToHTML(ucharTmpBufPtr, -1, outputDataBuf, GET_MAXDATALEN(TextType), NULL))     /* PMSTA-33077 - DLA - 181011 */
                    { /* Error */
                        MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Error while converting to XML");
                    }
                }
                else
                { /* Error */
                    MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "Error while converting from XML");
                }
            }
        }
    }
    else
    {
	    /*
	     * Foreign keys of the given entity has to be solved.
	     * The returned buffer follows two kinds of format possible:
	     *	- Event.
	     *	- Audit.
	     */

         /* outbox validity check */
         /*PMSTA-49443-Lalby-07062022-exclude schema validation check for testing purpose-EV_ForceOutboxInsert*/
         if (SubscriptionNatEn::Outbox == subscriptionEn && (EV_ForceOutboxInsert == false))
         {
             DICT_ENTITY_STP dictEntStp = DBA_GetDictEntityByDictId(GET_DICT(outSubscription, A_Subscription_EntityDictId));
             if (dictEntityStp == nullptr ||
                 (DATETIME_CMP(dictEntStp->lastModifDate,
                 (GET_DATETIME(sOutboxSchema, S_OutboxSchema_EndDate)))) == 1)
             {
                 char buffer[250];
                 snprintf(buffer, sizeof(buffer)-1,
                     "last modify date of dict entity is greater than schema modify date for %s",
                     GET_CODE(sOutboxSchema, S_OutboxSchema_Recid)
                 );

                 MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, buffer);
                 return  RET_SUCCEED; /*process remaining subscriptions*/
             }
         }

	    switch (actionEn)
	    {
		    case Subscription_Action_Update:
                if ((retCode = DBA_ConvertDynStToString2(object,
                                                        inputSt,
                                                        inputData,
                                                        0,
                                                        FALSE,
                                                        NULL,
                                                        &outputDataBuf,
                                                        DBA_SET_CONN | DBA_NO_CLOSE,
                                                        0,
                                                        TRUE,                           /*  FIH-REF10666-041005 Save virtual fileds */
                                                        dbiConn,
														TRUE,
                                                        FALSE,
                                                        FALSE,
                                                        subscriptionEn)) != RET_SUCCEED)
			    {
					connInfo->subscriptionElem.subscripCodifCompoNmb = 0;
    			    return(retCode);
			    }

                mp.ownerPtr(outputDataBuf);

			    if (subscriptionEn == SubscriptionNatEn::Audit)
			    {
                    if ((retCode = DBA_ConvertDynStToString2(object,
                                                            inputSt,
                                                            inputDataOld,
                                                            0,
                                                            FALSE,
                                                            NULL,
                                                            &txtOld,
                                                            DBA_SET_CONN | DBA_NO_CLOSE,
                                                            0,
                                                            TRUE,                           /*  FIH-REF10666-041005 Save virtual fileds */
                                                            dbiConn,
															TRUE,
                                                            FALSE,
                                                            FALSE)) != RET_SUCCEED)
                    {
						connInfo->subscriptionElem.subscripCodifCompoNmb = 0;
                        return(retCode);
                    }

                    retCode = DBA_ConcatString(txtOld, outputDataBuf, actionEn, &outputDataBufAudit);
                    mp.ownerPtr(txtOld); /* DLA - REF8712 - 031114 */
                    mp.ownerPtr(outputDataBufAudit);
			    }
			    break;

		    case Subscription_Action_Insert:
                if ((retCode = DBA_ConvertDynStToString2(object,
                                                        inputSt,
                                                        inputData,
                                                        0,
                                                        FALSE,
                                                        NULL,
                                                        &outputDataBuf,
                                                        DBA_SET_CONN | DBA_NO_CLOSE,
                                                        0,
                                                        TRUE,                           /*  FIH-REF10666-041005 Save virtual fileds */
                                                        dbiConn,
														TRUE,
                                                        FALSE,
                                                        FALSE,
                                                        subscriptionEn)) != RET_SUCCEED)
			    {
					connInfo->subscriptionElem.subscripCodifCompoNmb = 0;
				    return(retCode);
			    }

                mp.ownerPtr(outputDataBuf);
			    if (subscriptionEn == SubscriptionNatEn::Audit)
			    {
				    retCode = DBA_ConcatString(outputDataBuf, outputDataBuf, actionEn, &outputDataBufAudit);
                    mp.ownerPtr(outputDataBufAudit);
			    }
			    break;

		    case Subscription_Action_Delete:
			    if ((retCode2 = DBA_ConvertDynStToString2(object,
								                         inputSt,
								                         inputDataOld,
								                         0,
                                                         FALSE,
								                         NULL,
								                         &outputDataBufOld,
								                         DBA_SET_CONN | DBA_NO_CLOSE,
								                         0,
                                                         TRUE,                          /*  FIH-REF10666-041005 Save virtual fileds */
								                         dbiConn,
														 TRUE,
                                                         FALSE,
                                                         FALSE,
                                                         subscriptionEn)) != RET_SUCCEED)
			    {
					connInfo->subscriptionElem.subscripCodifCompoNmb = 0;
				    return(retCode2);
			    }

                mp.ownerPtr(outputDataBufOld);

			    if (subscriptionEn == SubscriptionNatEn::Audit)
			    {
				    retCode = DBA_ConcatString(outputDataBufOld, outputDataBufOld, actionEn, &outputDataBufAudit);
				    mp.ownerPtr(outputDataBufAudit);
			    }
			    else
			    {
				    outputDataBuf = outputDataBufOld;
			    }

			    break;

		    default:
			    break;
	    }
    } /*endif REF5309 - DLA - 001122.*/

    /* freed in mem pool */
	connInfo->subscriptionElem.subscripCodifCompoStp = NULL;
	connInfo->subscriptionElem.subscripCodifCompoNmb = 0;
    /* ensure in pool */
	mp.ownerPtr(outputDataBuf);

    if (subscriptionEn == SubscriptionNatEn::Event)
    {
        DBA_DYNFLD_STP eventStp = mp.allocDynst(FILEINFO, A_Event);
        /*
         * If a map is linked to this event, we have to get its name and location.
         */

        if (IS_NULLFLD(outSubscription, A_Subscription_MapId) == FALSE)
        {
            DBA_DYNFLD_STP		inMap = mp.allocDynst(FILEINFO,A_Map);
            DBA_DYNFLD_STP		outMap = mp.allocDynst(FILEINFO,A_Map);;
            
            SET_ID(inMap, A_Map_Id, GET_ID(outSubscription, A_Subscription_MapId));

            if ((retCode = DBA_Get2(Map,
                UNUSED,
                A_Map,
                inMap,
                A_Map,
                &outMap,
                UNUSED,
                UNUSED,
                UNUSED)) != RET_SUCCEED)
            {
                return(retCode);
            }

            mapStorage = (char *)mp.calloc(GET_MAXDATALEN(NoteType), sizeof(char));

            strcpy(mapStorage, GET_NOTE(outMap, A_Map_Storage));
        }
        
        /*
         * Optimize calls to Sybase.
         */

        if (insGroupingFlg == TRUE && groupingCode != NULL && groupingCode[0] == END_OF_STRING)
        {
            DBA_GetEventGroupingCode(groupingCode);
        }

        /* PMSTA-17875 - DDV - 140403 - Fix error on initil status setting */
        if (GET_ENUM(outSubscription, A_Subscription_EventInitStatusEn) == Event_Status_Deferred)
        {
            evtStsEn = Event_Status_Deferred;
        }
        else
        {
            evtStsEn = Event_Status_Untreated;
        }


        if (object == EOp)
        {
            SET_ID(eventStp, A_Event_FunctionResultId, GET_ID(inputData, ExtOp_FctResultId));
            SET_CODE(eventStp, A_Event_OperationCd, GET_CODE(inputData, ExtOp_Cd));
            /* DLA - PMSTA05995 - 080407 */
            if (!IS_NULLFLD(inputData, ExtOp_TimeStampNew))
            {
                SET_TIMESTAMP(eventStp, A_Event_OpTimeStamp, GET_TIMESTAMP(inputData, ExtOp_TimeStampNew));
            }
            else
            {
                if (!IS_NULLFLD(inputData, ExtOp_TimeStamp))
                {
                    SET_TIMESTAMP(eventStp, A_Event_OpTimeStamp, GET_TIMESTAMP(inputData, ExtOp_TimeStamp));
                }
            }

            /* PMSTA-17266 - DDV - 131217 - If it is a cancel request, change event's action_e */
            if (GET_ENUM(inputData, ExtOp_EventActionEn) == Subscription_Action_Cancel)
            {
                actionEn = Subscription_Action_Cancel;
            }
        }
        else
        {
            if (DBA_SearchAttribSqlName(object, "code", &attribute) == RET_SUCCEED)
            {
                if (attribute->busKeyFlg == TRUE && IS_NULLFLD(inputData, attribute->progN) == FALSE)
                {
                    DBA_GetBusinessAttrib(object, &count, &attributes);

                    if (count == 1)
                    {
                        SET_CODE(eventStp, A_Event_OperationCd, GET_CODE(inputData, attribute->progN));
                    }
                }
            }
        }

        SET_SYSNAME(eventStp, A_Event_Hostname, hostname);
        SET_CODE(eventStp, A_Event_User, userCode);
        SET_ENUM(eventStp, A_Event_StatusEn, evtStsEn);
        SET_ENUM(eventStp, A_Event_NatureEn, evtNatureEn);
        SET_CODE(eventStp, A_Event_EntSqlName, entityCd);
        SET_ENUM(eventStp, A_Event_ActionEn, actionEn);
        SET_ENUM(eventStp, A_Event_ModuleEn, moduleEn);
        SET_DATETIME(eventStp, A_Event_CreationDate, creationDate);
        if (object == EOp && IS_NULLFLD(inputData, ExtOp_StatusEn) == FALSE)
        {
            SET_ENUM(eventStp, A_Event_OperationStatusEn, GET_ENUM(inputData, ExtOp_StatusEn));
        }
        else
        {
            SET_ENUM(eventStp, A_Event_OperationStatusEn, OpStat_Cancelled);
        }
        if (IS_NULLFLD(outSubscription, A_Subscription_UpdateStatus) == FALSE)
        {  /* PMSTA-20159 - TEB - 150624 */
            SET_NAME(eventStp, A_Event_UpdateStsName, GET_NAME(outSubscription, A_Subscription_UpdateStatus));
        }

        if (mapStorage != NULL)
        { /* PMSTA-20159 - TEB - 150624 */
            SET_CODE(eventStp, A_Event_MapStorage, mapStorage);
        }

        /* Use of format if any. REF5309 */
        if (IS_NULLFLD(outSubscription, A_Subscription_FmtId) == FALSE)
        {
            SET_ID(eventStp, A_Event_FormatId, GET_ID(outSubscription, A_Subscription_FmtId)); /* DLA - PMSTA08801 - 100209 */
        }

        /* DLA - REF10247 - 050712 */
        if (IS_NULLFLD(outSubscription, A_Subscription_Destination) == FALSE)
        { /* PMSTA-20159 - TEB - 150624 */
            SET_CODE(eventStp, A_Event_DestinationCd, GET_CODE(outSubscription, A_Subscription_Destination));
        }

        /* DLA - REF10247 - 050713 */
        if (IS_NULLFLD(outSubscription, A_Subscription_Priority) == FALSE)
        {
            SET_DOUBLE(eventStp, A_Event_Priority, GET_DOUBLE(outSubscription, A_Subscription_Priority));
        }

        SET_CODE(eventStp, A_Event_SubscriptionCd, GET_CODE(outSubscription, A_Subscription_Cd));

        SET_STRING(eventStp, A_Event_Data, outputDataBuf);

        if (businessEntityCd != NULL && businessEntityCd[0] != END_OF_STRING)
        { /* PMSTA-20159 - TEB - 150624 */
            SET_CODE(eventStp, A_Event_BusEntityCd, businessEntityCd);
        }

        /* PMSTA-17266 - DDV - 131217 - Add request_status and event_status_f */
        SET_ENUM(eventStp, A_Event_RequestStatusEn, GET_ENUM(outSubscription, A_Subscription_RequestStatusEn));
        SET_FLAG(eventStp, A_Event_EventStatusFlg, GET_FLAG(outSubscription, A_Subscription_EventStatusFlg));

        /* PMSTA-17793 - DDV - 140319 */
        if (insGroupingFlg == TRUE && groupingCode != NULL && groupingCode[0] != END_OF_STRING )
        { /* PMSTA-20159 - TEB - 150624 */
            SET_CODE(eventStp, A_Event_GroupingCode, groupingCode);
        }

        if (connInfo->blockMode == FALSE)
        {
            retCode = DBA_Insert2(Event,
                UNUSED,
                A_Event,
                eventStp,
                DBA_SET_CONN | DBA_NO_CLOSE,
                dbiConn);

            if (retCode != RET_SUCCEED)
            {
                dbiConn.sendAllMsg();
            }
        }
        else
        {
            if (((connInfo->subscriptionElem.accessStp) = SYS_ReallocInit((DBA_ACCESS_ST *) (connInfo->subscriptionElem.accessStp),
                (size_t) (connInfo->subscriptionElem.accessNbr), (size_t) 1)) == NULL)
            {
                MSG_RETURN(RET_MEM_ERR_ALLOC);
            }
            connInfo->subscriptionElem.accessNbr++;

            connInfo->subscriptionElem.accessStp[connInfo->subscriptionElem.accessNbr - 1].action = Insert;
            connInfo->subscriptionElem.accessStp[connInfo->subscriptionElem.accessNbr - 1].role   = UNUSED;
            connInfo->subscriptionElem.accessStp[connInfo->subscriptionElem.accessNbr - 1].object = Event;
            connInfo->subscriptionElem.accessStp[connInfo->subscriptionElem.accessNbr - 1].entity = A_Event;
            connInfo->subscriptionElem.accessStp[connInfo->subscriptionElem.accessNbr - 1].data = eventStp;

            mp.removeDynStp(eventStp);
        }
	}
    else if (subscriptionEn == SubscriptionNatEn::Outbox)
    {
        DBA_DYNFLD_STP aOutboxData = mp.allocDynst(FILEINFO,A_Outbox);

        if(sOutboxSchema != nullptr)
        {
            COPY_DYNFLD(aOutboxData, A_Outbox, A_Outbox_Partition, sOutboxSchema, S_OutboxSchema, S_OutboxSchema_Partition);
            COPY_DYNFLD(aOutboxData, A_Outbox, A_Outbox_SchemaId, sOutboxSchema, S_OutboxSchema, S_OutboxSchema_Id);
            COPY_DYNFLD(aOutboxData, A_Outbox, A_Outbox_ContextCd, sOutboxSchema, S_OutboxSchema, S_OutboxSchema_Recid);
        }
        SET_DATETIME(aOutboxData, A_Outbox_CreationDate, creationDate);
        SET_TEXT(aOutboxData, A_Outbox_DataT, outputDataBuf);

        if (connInfo->blockMode == FALSE)
        {
            retCode = DBA_Insert2(Outbox,
                UNUSED,
                A_Outbox,
                aOutboxData,
                DBA_SET_CONN | DBA_NO_CLOSE,
                dbiConn);

            if (retCode != RET_SUCCEED)
            {
                dbiConn.sendAllMsg();
            }
        }
        else
        {
            if (((connInfo->subscriptionElem.accessStp) = SYS_ReallocInit((DBA_ACCESS_ST *)(connInfo->subscriptionElem.accessStp),
                (size_t)(connInfo->subscriptionElem.accessNbr), (size_t)1)) == NULL)
            {
                MSG_RETURN(RET_MEM_ERR_ALLOC);
            }
            connInfo->subscriptionElem.accessNbr++;

            connInfo->subscriptionElem.accessStp[connInfo->subscriptionElem.accessNbr - 1].action = Insert;
            connInfo->subscriptionElem.accessStp[connInfo->subscriptionElem.accessNbr - 1].role = UNUSED;
            connInfo->subscriptionElem.accessStp[connInfo->subscriptionElem.accessNbr - 1].object = Outbox;
            connInfo->subscriptionElem.accessStp[connInfo->subscriptionElem.accessNbr - 1].entity = A_Outbox;
            connInfo->subscriptionElem.accessStp[connInfo->subscriptionElem.accessNbr - 1].data = aOutboxData;

            mp.removeDynStp(aOutboxData);
        }
    }
	else
	{
        DBA_DYNFLD_STP auditStp = mp.allocDynst(FILEINFO,A_Audit);

        SET_SYSNAME(auditStp, A_Audit_Hostname, hostname);
        SET_CODE(auditStp, A_Audit_User, userCode);

        if (IS_NULLFLD(outSubscription, A_Subscription_EntityDictId) == FALSE)
        {
            SET_DICT(auditStp, A_Audit_EntityDictId, GET_DICT(outSubscription, A_Subscription_EntityDictId));
        }

        if (IS_NULLFLD(outSubscription, A_Subscription_FctDictId) == FALSE)
        {
            SET_DICT(auditStp, A_Audit_FctDictId, GET_DICT(outSubscription, A_Subscription_FctDictId));
        }
        SET_ENUM(auditStp, A_Audit_ActionEn, actionEn);
        SET_ENUM(auditStp, A_Audit_ModuleEn, moduleEn);
        SET_ENUM(auditStp, A_Audit_EntityNatEn, 0);
        SET_DATETIME(auditStp, A_Audit_CreationDate, creationDate);

        if (IS_NULLFLD(outSubscription, A_Subscription_MapId) == FALSE)
        {
            SET_ID(auditStp, A_Audit_MapId, GET_ID(outSubscription, A_Subscription_MapId));
        }
        else
        {
            SET_NULL_ID(auditStp, A_Audit_MapId);
        }

        SET_STRING(auditStp, A_Audit_Data, outputDataBufAudit);

        if (connInfo->blockMode == FALSE)
        {
            retCode = DBA_Insert2(Audit,
                UNUSED,
                A_Audit,
                auditStp,
                DBA_SET_CONN | DBA_NO_CLOSE,
                dbiConn);

            if (retCode != RET_SUCCEED)
            {
                dbiConn.sendAllMsg();
            }
        }
        else
        {
            if (((connInfo->subscriptionElem.accessStp) = SYS_ReallocInit(connInfo->subscriptionElem.accessStp,
                (size_t) connInfo->subscriptionElem.accessNbr, (size_t) 1)) == NULL)
            {
                MSG_RETURN(RET_MEM_ERR_ALLOC);
            }
            connInfo->subscriptionElem.accessNbr++;

            connInfo->subscriptionElem.accessStp[connInfo->subscriptionElem.accessNbr - 1].action = Insert;
            connInfo->subscriptionElem.accessStp[connInfo->subscriptionElem.accessNbr - 1].role   = UNUSED;
            connInfo->subscriptionElem.accessStp[connInfo->subscriptionElem.accessNbr - 1].object = Audit;
            connInfo->subscriptionElem.accessStp[connInfo->subscriptionElem.accessNbr - 1].entity = A_Audit;
            connInfo->subscriptionElem.accessStp[connInfo->subscriptionElem.accessNbr - 1].data   = auditStp;

            mp.removeDynStp(auditStp);
        }

    }

	return(retCode);
}

/************************************************************************
**
**  Function    :   DBA_StratUpdateModel
**
**  Description :   Allow a user to update the grid of a Model Portfolio.
**
**  Arguments   :
**
**  Return      :   RET_CODE
**
**  Cr�ation    :   REF4888 - 000613 - SKE
**
*************************************************************************/
RET_CODE DBA_StratUpdateModel(OBJECT_ENUM          object,
                     	      DBA_DYNST_ENUM       inputSt,
                     	      DBA_DYNFLD_STP       stratPtr,
                     	      DbiConnectionHelper& dbiConnHelper)

{
    RET_CODE            ret             = RET_SUCCEED;
    DBA_DYNFLD_STP      admArgPtr       = NULL;
    DBA_DYNFLD_STP*     stratHistTab    = NULL;
    int				    stratHistNbr    = 0;
    int                 dbaOptions;
    DbiConnection&      dbiConn = *dbiConnHelper.getConnection();

    /* Extract all strategy history records */
    admArgPtr = ALLOC_DYNST(Adm_Arg);
    if (admArgPtr == NULL)
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "Adm_Arg");
		return(RET_MEM_ERR_ALLOC);
    }

    SET_ID(admArgPtr, Adm_Arg_Id, GET_ID(stratPtr, A_Strat_Id));
    /*
        REM : Do not use the connectNo
        because the select into statement
        is incompatible with a transactional mode.
    */
    ret = DBA_Select2(StratHist,
                      UNUSED,
			          Adm_Arg,
                      admArgPtr,
			          S_StratHist,
                      &stratHistTab,
                      UNUSED,
                      UNUSED,
			          &stratHistNbr,
                      UNUSED);

    if (ret != RET_SUCCEED)
    {
        FREE_DYNST(admArgPtr, Adm_Arg);
        return(ret);

    }
    FREE_DYNST(admArgPtr, Adm_Arg);

    /* Create temporary tables before opening transactional mode */
    ret = DBA_CreateTempTables(dbiConn, DOM_STRAT | GRID_VECTOR | STRAT_MARKET | DOM_PARENT_STRAT | TMP_STRAT_HIST | STRATEGY );

        /* Open transaction mode */
    if ((ret = dbiConn.beginTransaction()) != RET_SUCCEED)
    {
        return(ret);
    }

    dbaOptions = DBA_SET_CONN|DBA_NO_CLOSE|DBA_IN_TRAN;
    ret = DBA_Update2(object,
                      UNUSED,
                      inputSt,
                      stratPtr,
                      dbaOptions,
                      dbiConn);

    if (ret != RET_SUCCEED)
    {
        DBA_FreeDynStTab(stratHistTab, stratHistNbr, S_StratHist);
        dbiConn.endTransaction(FALSE);
        return(ret);
    }

    ret = FIN_UpdateGridModel(stratPtr,
                              stratHistTab,
                              stratHistNbr,
                              dbaOptions,
							  (int*)&dbiConn.getId());

    if (ret != RET_SUCCEED)
    {
        DBA_FreeDynStTab(stratHistTab, stratHistNbr, S_StratHist);
		dbiConn.endTransaction(FALSE);
        return(ret);
    }
    DBA_FreeDynStTab(stratHistTab, stratHistNbr, S_StratHist);

    /* Close transaction */
	dbiConn.endTransaction(TRUE);

    return(ret);
}

/************************************************************************
**  Function    :   DBA_GetSubsCodif.
**
**  Description :
**
**  Arguments   :
**
**
**  Return      :
**
**  Cr�ation    :   REF4204 - GRD - 000310.
**
**  Modif.	:
**
*************************************************************************/
EXTERN FLAG_T DBA_GetSubsCodif(DICT_T         entityId,
                               ID_T           *codifId,
                               DbiConnection& dbiConn)
{
    int     i = 0;
	DBA_CONNECT_INFO_STP connInfo = dbiConn.getConnStructPtr();

    *codifId = 0;

    for (i = 0; i < connInfo->subscriptionElem.subscripCodifCompoNmb; i++)
    {
		if (GET_DICT(connInfo->subscriptionElem.subscripCodifCompoStp[i],
                     S_SubscriptionCodifCompo_SynEntityDictId) == entityId)
        {
			*codifId = GET_ID(connInfo->subscriptionElem.subscripCodifCompoStp[i],
                              S_SubscriptionCodifCompo_CodificationId);
            return(TRUE);
        }
    }

    return(FALSE);
}

/************************************************************************
**  Function    :   DBA_GetSubsCodif.
**
**  Description :   Update (using direct sql command) the last event gen date
**                  for all standing instruction of the array
**                  with A_StandInstruct_UpdGenDateFlg set to TRUE
**
**  Arguments   :   hierHead
**
**
**  Return      :
**
**  Cr�ation    :   PMSTA06761 - DDV - 080807
**
**  Modif.	:
**
*************************************************************************/
EXTERN RET_CODE DBA_UpdStandInstructLastEventGenDate(DBA_DYNFLD_STP *standInstructTab,
                                                     int             standInstructNbr)
{
    int      i = 0, updlen=150;
    char     *buffer;
	DbiSqlExecByBlock sqlBlock(100);		/* PMSTA-20159 - TEB - 151110 */

	if ((buffer = (char*) CALLOC(1, updlen)) == NULL)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

    buffer[0]=END_OF_STRING;

    for (i=0; i < standInstructNbr; i++)
    {
        if (GET_FLAG(standInstructTab[i], A_StandInstruct_UpdGenDateFlg) == TRUE)
        {  
			if (DBA_IsDboUser() == true) /*Only Triplea owner has rights to update view, triplea and tasc_tech group have only select rights but no update priviledge wrt views.Hence skip updating view for other users except owner*/ /* PMSTA-40643 - GRA- 120123 */
			{ /* PMSTA-20159 - TEB - 151110 */
				sprintf(buffer, "update %s set last_event_generate_d = #CONVERT(datetime_t,#CONVERT(code_t,#GETDATE)) where id = %" szFormatId"\n", SCPT_GetViewName(StandInstruct, false).c_str(), GET_ID(standInstructTab[i], A_StandInstruct_Id)); /* DLA - PMSTA08801 - 100209 */ /* PMSTA-26250  -DDV - 170523 */ /* PMSTA-32753 - DLA - 180903 */
				sqlBlock.addSql(buffer);
			}
			else
			{
				FREE(buffer);
				return(RET_SUCCEED);
			}
        }
    }

	sqlBlock.execSqlExecByBloc(); 			/* PMSTA-20159 - TEB - 151110 */

    FREE(buffer);
    return(RET_SUCCEED);
}

/************************************************************************
**  Function    :   DBA_GetEventGroupingCode.
**
**  Description :   Get a grouping Id
**
**  Arguments   :
**
**
**  Return      :
**
**  Cr�ation    :   PMSTA-17793 - DDV - 140318
**
**  Modif.	:
**
*************************************************************************/
EXTERN RET_CODE DBA_GetEventGroupingCode(CODE_T groupingCode)
{
    DBA_DYNFLD_STP  aEventGroupingId;
    RET_CODE        ret=RET_SUCCEED;

    groupingCode[0]=END_OF_STRING;

    if ((aEventGroupingId = ALLOC_DYNST(A_EventGroupingId)) == NULL)
    {
		MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    if ((ret = DBA_Insert2(EventGroupingId, UNUSED, A_EventGroupingId, aEventGroupingId, UNUSED, UNUSED, UNUSED)) == RET_SUCCEED)
    {
        sprintf(groupingCode, "%" szFormatId, GET_ID(aEventGroupingId, A_EventGroupingId_Id));
    }

    FREE_DYNST(aEventGroupingId, A_EventGroupingId);

    return(ret);
}

/************************************************************************
**  Function    :   DBA_GetQuestionnaireScreen.
**
**  Description :   Get best screen link to questionnaire
**
**  Arguments   :   entSqlname            questionnaire entity's sqlname_c
**
**
**  Return      :
**
**  Creation    :   PMSTA-19243 - DDV - 150427
**
**  Modif.      :   HFI-PMSTA-55081-2023-11-27  Take in account questionnaire definition revision 
**
*************************************************************************/
DICT_T DBA_GetQuestionnaireScreen (DICT_ENTITY_STP   pdictent)
{
    DICT_T          screenDictId = 0;
    MemoryPool      mp;

    if (pdictent != nullptr)
    {
        DBA_DYNFLD_STP getArgSt = mp.allocDynst(FILEINFO, Get_Arg);
        DBA_DYNFLD_STP dictScreenStp = mp.allocDynst(FILEINFO, S_DictScreen);

        if ((getArgSt != nullptr) && (dictScreenStp != nullptr))
        {
            SET_DICT(getArgSt, Get_Arg_Id, pdictent->entDictId);
			if (DBA_Get2(QuestScreenHisto, UNUSED, Get_Arg, getArgSt, S_DictScreen, &dictScreenStp, UNUSED, UNUSED, UNUSED) == RET_SUCCEED)
            {
                /*  return screen only if entity match */
                if (GET_DICT(dictScreenStp, S_DictScreen_EntDictId) == pdictent->entDictId)
                {
                    screenDictId = GET_DICT(dictScreenStp, S_DictScreen_DictId);
                }
            }
        }
    }
    return(screenDictId);
}

/**********************************************************
**  Function    : DBA_GetOrderCodeInSessionSysParam
**
**  Description : Determine management of Code Generation on ext_operation
**
**  Arguments   : None
**
**  Return      : EVALATTRIB_ENUM
**
**  Cr�ation : PMSTA-25183 - CHU - 161108
**
**  Modif. :
**
*************************************************************************/
FLAG_T DBA_GetOrderCodeInSessionSysParam()
{
    ORDER_CODE_IN_SESSION_ENUM OrderCodeInSessionValue = OrderCodeInSession_NotSet;

    GEN_GetApplInfo(ApplOrderCodeInSession, &OrderCodeInSessionValue);

    if (OrderCodeInSessionValue == OrderCodeInSession_NotSet ||
        OrderCodeInSessionValue == OrderCodeInSession_Disabled)
    {
        return(TRUE); /* Do not apply DV : previous behaviour */
    }

    if (OrderCodeInSessionValue == OrderCodeInSession_Enabled)
    {
            return(FALSE); /* Apply DV */
    }

    return (TRUE); /* Other value : Do not apply DV in other cases at the time being... */
}

/**********************************************************
**  Function    : DBA_GetConnAllowedBusEntity
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation    : PMSTA-26108 - LJE - 170828
**
**  Modif. :
**
*************************************************************************/
void DBA_GetConnAllowedBusEntity(DbiConnectionHelper &connHelper, DBA_DYNFLD_STP **busEntityCompoTab, int *busEntityCompoNbr)
{
    MemoryPool mp;
    DBA_DYNFLD_STP shBusEntityCompo = mp.allocDynst(FILEINFO, S_BusEntityUserCompo);

    SET_ENUM(shBusEntityCompo, S_BusEntityUserCompo_RoleEn, BusEntCompoRule_ApplUser);

    connHelper.dbaSelect(BusEntityUserCompo, UNUSED, shBusEntityCompo, S_BusEntityUserCompo, busEntityCompoTab, busEntityCompoNbr);
}

/**********************************************************
**  Function    : DBA_GetDefConnBusEntity
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation    : PMSTA-26108 - LJE - 170828
**
**  Modif. :
**
*************************************************************************/
void DBA_GetDefConnBusEntity(DbiConnectionHelper &connHelper, std::string &defBusEntityStr)
{
    DBA_DYNFLD_STP *busEntityCompoTab;
    int             busEntityCompoNbr;

    DBA_GetConnAllowedBusEntity(connHelper, &busEntityCompoTab, &busEntityCompoNbr);

    defBusEntityStr.clear();
    for (int i = 0; i < busEntityCompoNbr; i++)
    {
        if (GET_FLAG(busEntityCompoTab[i], S_BusEntityUserCompo_DefaultLoginFlg) == TRUE)
        {
            defBusEntityStr = GET_CODE(busEntityCompoTab[i], S_BusEntityUserCompo_BusEntityCd);
            break;
        }
    }

    DBA_FreeDynStTab(busEntityCompoTab, busEntityCompoNbr, S_BusEntityUserCompo);
}

/************************************************************************
**
**  Function    :   DBA_UpdatePtfLastRebalancingInfo()
**
**  Description :   Update last_rebalancing_d & last_rebalancing_status attributes of portfolios if initial fct is Rebalancing
**
**  Arguments   :   domainPtr       domain structure pointer
**                  stratHierHead   strategy hierarchy header pointer
**
**  Return      :   RET_SUCCEED	or error code
**
**  Creation    :   PMSTA-30897 - CHU - 180504
**
*************************************************************************/
RET_CODE DBA_UpdatePtfLastRebalancingInfo(DBA_DYNFLD_STP        domainPtr,
                                          DBA_HIER_HEAD_STP     stratHierPtr,
                                          DbiConnectionHelper   &dbiConnHelper)
{
    RET_CODE ret = RET_SUCCEED;
    DBA_DYNFLD_STP      *ptfTab     = NULLDYNSTPTR;
	DBA_DYNFLD_STP		admArgPtr   = NULLDYNST;
    int					i, j, ptfNbr= 0;
    bool                closeTransaction = true;
    int                 connectNo;
    bool                isManageSessionfct = (GET_DICT(domainPtr, A_Domain_InitialFctDictId) == DictFct_ManageSession);

    i = j = 0;
    connectNo = DBA_CONN_NOT_FOUND;

    if (true == isManageSessionfct)
    {
        if (dbiConnHelper.isValidAndInit() == false)
        {
            return(RET_DBA_ERR_CONNOTFOUND);
        }

        if (dbiConnHelper.isInTransaction() == true)
        {
            closeTransaction = false;
        }

        /* Get all portfolios */
        if ((ret = DBA_ExtractHierEltRec(stratHierPtr,
                                         A_Ptf,
                                         FALSE,
                                         NULLFCT,
                                         NULLFCT,
                                         &ptfNbr,
                                         &ptfTab)) == RET_SUCCEED && ptfNbr > 0)
        {
            bool closeLocalTransaction = false;
            if (dbiConnHelper.isInTransaction() == false)
            {
                closeLocalTransaction = true;
                dbiConnHelper.beginTransaction();
            }

            DBA_DYNFLD_STP	copyArgPtr = NULL;
            if ((copyArgPtr = ALLOC_DYNST(A_CopyArg)) != NULL)
            {
                SET_ID(copyArgPtr, A_CopyArg_FromId, GET_ID(domainPtr, A_Domain_FctResultId));
                SET_NULL_ID(copyArgPtr, A_CopyArg_ToId);
                for (i = 0; i < ptfNbr && ret == RET_SUCCEED; i++)
                {
                    SET_ID(copyArgPtr, A_CopyArg_ConsPortId, GET_ID(ptfTab[i], A_Ptf_Id));
                    ret = DBA_Update2(FctResult,
                                      DBA_ROLE_SPLIT_FCTRESULT,
                                      A_CopyArg,
                                      copyArgPtr,
                                      dbiConnHelper);
                }
                FREE_DYNST(copyArgPtr, A_CopyArg); /* PMSTA-31765 - CHU - 180613 */
            }

            if (ret != RET_SUCCEED)
            {
                if (closeTransaction || closeLocalTransaction) /* PMSTA-28596  - CHU - 170926 */
                {
                    dbiConnHelper.endTransaction(false); /* Rollback */
                }
            }
            else
            {
                if (closeLocalTransaction == true)
                {
                    dbiConnHelper.endTransaction(true); /* Commit */
                }
            }
            FREE(ptfTab);
            FREE_DYNST(admArgPtr, Adm_Arg);
        }
    }

    return(ret);
}

/************************************************************************
**
**  Code moved from subdlib
**
*************************************************************************/

#include <conv.h>
#include <str.h>


typedef struct {
	int                     number;
	DATATYPE_ENUM*			datatypes;
	DBA_DYNFLD_STP			output;
	SCPT_ARG_STP*           contexts;
	SCPT_FMTDATADEF_STP		definitions;
} DBA_RESULT_EVAL_TREE_ST, *DBA_RESULT_EVAL_TREE_STP;

typedef struct {
	ID_T                       formatId;
	DBA_RESULT_EVAL_TREE_STP   resultEvalTreePtr;
}DBA_RESULT_EVAL_ST, *DBA_RESULT_EVAL_STP;

void DBA_FreeOneTree(DBA_RESULT_EVAL_TREE_STP);

class SubsFmtEvalCache
{
public:
    SubsFmtEvalCache();
    ~SubsFmtEvalCache();

    void purge();
    void *get(ID_T id);
    void store(ID_T id, void *pointer);

private:
    std::map<ID_T, void *> map;
};

SubsFmtEvalCache::SubsFmtEvalCache()
{
}

SubsFmtEvalCache::~SubsFmtEvalCache()
{
    purge();
}

void SubsFmtEvalCache::purge()
{
    for (auto iterator = map.begin(); iterator != map.end(); iterator++)
    {
        DBA_FreeOneTree(
            static_cast<DBA_RESULT_EVAL_TREE_STP>(iterator->second));
    }

    map.clear();
}

void *SubsFmtEvalCache::get(ID_T id)
{
    if (map.find(id) != map.end())
        return map[id];  // map.at() is unknown form IBM compiler

    return NULL;
}

void SubsFmtEvalCache::store(ID_T id, void *pointer)
{
    map[id] = pointer;
}

SubsFmtEvalCache &DBA_GetSubsFmtEvalCache()
{
    SubsFmtEvalCache
        *pSubsFmtEvalCache =
        static_cast<SubsFmtEvalCache *>(
            SYS_GetThreadDataCtxGeneric()->getSubsFmtEvalCache());

    if (pSubsFmtEvalCache == nullptr)
        SYS_GetThreadDataCtxGeneric()->setSubsFmtEvalCache(
            pSubsFmtEvalCache = new SubsFmtEvalCache());

    return *pSubsFmtEvalCache;
}

void DBA_FreeSubsFmtEvalCache(void *pointer)
{
    SubsFmtEvalCache
        *pSubsFmtEvalCache =
        static_cast<SubsFmtEvalCache *>(pointer);

    delete pSubsFmtEvalCache;
}

/************************************************************************
**
**  Function    :   DBA_FreeOneTree()
**
**  Description :
**
**  Arguments   :
**
**  Cr�ation	:
**
*************************************************************************/
void DBA_FreeOneTree(DBA_RESULT_EVAL_TREE_STP tree)
{
    for (int n = 0; n < tree->number; n++)
    {
        SCPT_FreeScptTree(tree->contexts[n]);
        FREE_DYNST(
            tree->definitions->sumFmtEltTab[n], Sum_FmtElt);

        CTYPE_ENUM
            cType = GET_CTYPE(tree->datatypes[n]);

        if ((cType == CharPtrCType    || cType == TextPtrCType   ) &&
            GET_STRING(tree->output, n) != NULL)
            FREE_STRFLD(tree->output[n]);
        if ((cType == UniCharPtrCType || cType == UniTextPtrCType) &&
            GET_USTRING(tree->output, n) != NULL)
            FREE_USTRFLD(tree->output[n]);
    }

    FREE(
        tree->definitions->dataDefTab  );
    FREE(
        tree->definitions->sumFmtEltTab);

    FREE(tree->definitions);
    FREE(tree->contexts   );
    FREE(tree->datatypes  );
    FREE(tree->output     );

    tree->number = 0;
}

/************************************************************************
**
**  Function    :   DBA_EvalFmt()
**
**  Description :   Evaluate format.
**
**  Arguments   :   object, format, connection
**
**  Cr�ation	:   GRD - 002211 - REF5309.
**
*************************************************************************/
DBA_RESULT_EVAL_TREE_STP DBA_EvalFmt(
	OBJECT_ENUM objectEn, ID_T formatId, DICT_T entityDictId, DBA_DYNFLD_STP inputRec, DbiConnection &dbiConn)
{
	DBA_DYNFLD_STP	        getArg = (DBA_DYNFLD_STP)NULL;
	const DBA_DYNST_ENUM *outputStLst[] = { &Sum_FmtElt, &A_ScriptDef };
	DBA_DYNFLD_STP          *dataTab[2] = { NULLDYNSTPTR, NULLDYNSTPTR };
	DBA_DYNFLD_STP          *sumFmtEltTab = NULL;
	int		                lastIdx = 0;
	int                     rowTab[2] = { 0,0 };
	char                    *scptBuf = (char *)NULL;
	char                    *script = (char *)NULL;
	int                     i = 0, j = 0;
	RET_CODE                ret = RET_SUCCEED;
	DATATYPE_ENUM           dataType = NullDataType;
	int                     fmtEltNb = 0;
	ID_T                    fmtEltId = 0;
	DICT_ATTRIB_STP         attribSt;

	/*
	 * First of all, look into the cache for the Tree.
	 */

	DBA_RESULT_EVAL_TREE_STP resultEvalTreeStp = NULL;

	if ((resultEvalTreeStp = (DBA_RESULT_EVAL_TREE_STP)DBA_GetSubsFmtEvalCache().get(formatId)) == (DBA_RESULT_EVAL_TREE_STP)NULL)
	{
		if (DBA_SearchAttribSqlName(FmtElt, "script_definition", &attribSt) != RET_SUCCEED)
		{
			return (DBA_RESULT_EVAL_TREE_STP)NULL;
		}

		/*
		 * Nothing in the cache, we have to evaluate and store the Tree.
		 */

		getArg = ALLOC_DYNST(Get_Arg);

		SET_ID(getArg, Get_Arg_Id, formatId);
		SET_ID(getArg, Get_Arg_AttribDictId, attribSt->attrDictId);

		if (DBA_MultiSelect2(FmtElt, UNUSED,
			Get_Arg, getArg,
			outputStLst, dataTab,
			UNUSED, UNUSED,
			rowTab, UNUSED,
			UNUSED) != RET_SUCCEED)
		{
			FREE_DYNST(getArg, Get_Arg);
			return (DBA_RESULT_EVAL_TREE_STP)NULL;
		}

		FREE_DYNST(getArg, Get_Arg);

		sumFmtEltTab = dataTab[0];
		fmtEltNb = rowTab[0];

		scptBuf = (char *)CALLOC(GET_MAXDATALEN(NoteType), SCPTDEF_MAX_REC);

		for (i = 0; i < fmtEltNb; i++)
		{
			/***** PRESUME THE SAME "ORDER BY" for data[0] (fmt_elt) & data[1] (script) *****/
			fmtEltId = GET_ID(sumFmtEltTab[i], Sum_FmtElt_Id);

			for (j = lastIdx; j < rowTab[1] && GET_ID(dataTab[1][j], A_ScriptDef_ObjId) != fmtEltId; j++);

			/***** IF DEFINITION FOUND FOR CURRENT FORMAT_ELEMENT *****/
			if (j < rowTab[1])
			{
				int     cpt = 0;

				scptBuf[0] = END_OF_STRING;

				/***** CONCAT ALL DEFINITION RECORDS FOR THIS FMT_ELT *****/
				while (j < rowTab[1] && GET_ID(dataTab[1][j], A_ScriptDef_ObjId) == fmtEltId)
				{
					cpt++;

					if (cpt < SCPTDEF_MAX_REC)
					{
						strcat(scptBuf, GET_STRING(dataTab[1][j], A_ScriptDef_Def));
					}

					j++;
				}

				SET_STRING(sumFmtEltTab[i], Sum_FmtElt_Definition, scptBuf);
				lastIdx = j;
			}
		}

		DBA_FreeDynStTab(
			dataTab[1], rowTab[1], A_ScriptDef);

		FREE(scptBuf);

		/*
		 * Generate Tree and store it.
		 */

		resultEvalTreeStp =
		(DBA_RESULT_EVAL_TREE_ST *)CALLOC(1, sizeof(DBA_RESULT_EVAL_TREE_ST));

		SCPT_FMTDATADEF_STP definitions =
			(SCPT_FMTDATADEF_STP)CALLOC(1, sizeof(SCPT_FMTDATADEF_ST));

		definitions->nbCol = fmtEltNb;
		definitions->fmtId = formatId;
		definitions->fmtFilterColIndex = -1;

        /*PMSTA-52148 - GAD - 20240320 */
        if (fmtEltNb == 0)
        {
            MSG_SendMesg(RET_GEN_ERR_FMTELT, 0, FILEINFO);               /* Update Log with error message */
            return(resultEvalTreeStp);
        }

		definitions->dataDefTab =
			(DBA_DATADEF_STP)CALLOC(fmtEltNb, sizeof(DBA_DATADEF_ST));
		definitions->sumFmtEltTab =
			(DBA_DYNFLD_STP*)CALLOC(fmtEltNb, sizeof(DBA_DYNFLD_STP));

		SCPT_ARG_STP *contexts =
			(SCPT_ARG_STP *)CALLOC(fmtEltNb, sizeof(SCPT_ARG_STP));

		DATATYPE_ENUM *datatypes =
			(DATATYPE_ENUM *)CALLOC(fmtEltNb, sizeof(DATATYPE_ENUM));

		for (i = 0; i < fmtEltNb; i++)
		{
			definitions->dataDefTab[i].colNum = i;
			definitions->dataDefTab[i].dataType = DATATYPE_DICT_TO_ENUM(GET_DICT(sumFmtEltTab[i], Sum_FmtElt_DataTpDictId));
			definitions->dataDefTab[i].refKeyIndex = 0;
			definitions->dataDefTab[i].refKeyNbr = 0;
			definitions->dataDefTab[i].refKeyEntDictId = 0;
			definitions->dataDefTab[i].fmtEntDictId = entityDictId;
			definitions->dataDefTab[i].classifId = 0;
			definitions->dataDefTab[i].sortCol = 0;

			definitions->dataDefTab[i].scptDef =
				(char *)CALLOC(GET_MAXDATALEN(NoteType) * SCPTDEF_MAX_REC, sizeof(char));

            /*PMSTA-50948 - lalby - 04112022 */
            definitions->dataDefTab[i].scptDef[0] = '\0';

            if (IS_NULLFLD(sumFmtEltTab[i], Sum_FmtElt_Definition) == FALSE)
            {
                strcpy(definitions->dataDefTab[i].scptDef, GET_STRING(sumFmtEltTab[i], Sum_FmtElt_Definition));
            }
			definitions->dataDefTab[i].zoomFlg = 0;

			definitions->dataDefTab[i].fmtId = formatId;
			definitions->dataDefTab[i].colTotFlg = FALSE;
			definitions->dataDefTab[i].fmtEltNb = fmtEltNb;
			definitions->dataDefTab[i].eltStartFmt = 0;

			definitions->sumFmtEltTab[i] = ALLOC_DYNST(Sum_FmtElt);
			COPY_DYNST(
				definitions->sumFmtEltTab[i], sumFmtEltTab[i], Sum_FmtElt);
			SET_INT(definitions->sumFmtEltTab[i], Sum_FmtElt_ColNb, i + 1);

			script = GET_STRING(sumFmtEltTab[i], Sum_FmtElt_Definition);

			dataType = DATATYPE_DICT_TO_ENUM(GET_DICT(sumFmtEltTab[i], Sum_FmtElt_DataTpDictId));

			contexts[i] = (SCPT_ARG_ST *)CALLOC(1, sizeof(SCPT_ARG_ST));

			datatypes[i] = dataType;

			if ((ret = SCPT_GenerateScptTree(script,
				objectEn,
				InternalSMode,
				dataType,
				&(contexts[i]))) != RET_SUCCEED)
			{
				// TODO: FREE MEMORY
				return(DBA_RESULT_EVAL_TREE_STP)NULL;
			}

			SET_INT((&(contexts[i]->connectNoFld)), 0, dbiConn.getId());
		}

		DBA_DYNFLD_STP output = ALLOC_DYNST_WITHOUTDEF(fmtEltNb);

		resultEvalTreeStp->number = fmtEltNb;
		resultEvalTreeStp->datatypes = datatypes;
		resultEvalTreeStp->contexts = contexts;
		resultEvalTreeStp->definitions = definitions;

		resultEvalTreeStp->output = output;

		DBA_FreeDynStTab(
			dataTab[0], rowTab[0], Sum_FmtElt);

        DBA_GetSubsFmtEvalCache().store(formatId, resultEvalTreeStp);
	}

	return(resultEvalTreeStp);
}

/************************************************************************
**
**  Function    :   DBA_ExecFmt()
**
**  Description :   Evaluate format.
**
**  Arguments   :   ID
**
**  Cr�ation	:   GRD - 002211 - REF5309.
**
*************************************************************************/
RET_CODE DBA_ExecFmt(DBA_RESULT_EVAL_TREE_STP   resultEvalTreePtr,
	DBA_DYNFLD_STP             *resultBaseValPtr,
	DBA_DYNST_ENUM              inputSt,
	DBA_DYNFLD_STP              inputData)
{
	RET_CODE		retCode = RET_SUCCEED;
	int             i = 0;
	DBA_DYNFLD_STP  resultBaseValTmp = (DBA_DYNFLD_STP)NULL;
	DATATYPE_ENUM   dataType = NullDataType;
	DICT_T          dataTypeDictId;

	if (resultEvalTreePtr == (DBA_RESULT_EVAL_TREE_STP)NULL)
	{
		return RET_SUCCEED;
	}

	if (inputData == (DBA_DYNFLD_STP)NULL)
	{
		return RET_SUCCEED;
	}

    if (resultEvalTreePtr->number != 0)             /*PMSTA-52148 - GAD - 20240320 */
	resultBaseValTmp = (DBA_DYNFLD_STP)CALLOC(resultEvalTreePtr->number, sizeof(DBA_DYNFLD_ST));

	DBA_VerifOptiTab();		/* Update the cache. */

	for (i = 0; i < resultEvalTreePtr->number; i++)
	{
		dataTypeDictId = GET_DICT(resultEvalTreePtr->definitions->sumFmtEltTab[i], Sum_FmtElt_DataTpDictId);
		dataType = DATATYPE_DICT_TO_ENUM(dataTypeDictId);

		if ((retCode = SCPT_ExecScptTreeSpec(
			resultEvalTreePtr->contexts[i],		// SCPT_ARG_STP			generalContext,
			NULL,								// DBA_DYNFLD_STP		NULL,
			NULL,								// DBA_HIER_HEAD_STP	NULL,
			inputData,							// DBA_DYNFLD_STP		inputRec,
			resultEvalTreePtr->datatypes[i],	// DATATYPE_ENUM		fldDataType,
			resultEvalTreePtr->output,			// DBA_DYNFLD_STP		outputRec,
			i,									// int					outputIdx,
			resultEvalTreePtr->output,			// DBA_DYNFLD_STP	    dataFldTab,
			resultEvalTreePtr->definitions,		// SCPT_FMTDATADEF_STP	definitions,
			TRUE,
			FALSE)) != RET_SUCCEED)
		{
			return -1;
		}
	}

	*resultBaseValPtr = resultEvalTreePtr->output;

	return RET_SUCCEED;
}

/************************************************************************
**
**  Function    :   DBA_PrintFmtToString
**
**  Description :   Print all columns of a format to a string
**
**  Arguments   :
**
**  Return      :
**
**  Cr�ation	:   VST - 002012 - REF5309.
**
*************************************************************************/

void DBA_PrintFmtToString(
	const char *formatName,
		DBA_RESULT_EVAL_TREE_STP resultEvalTreePtr,
			DBA_DYNFLD_STP resultBaseValPtr, char **string,FLAG_T isDesFlow)
{
	int     i = 0;
	DICT_T                  dataTypeDictId;
	PTR                     valPtr = NULL;
	char                    tmpDataBuf[500];
	char                    tmpString[500];
	DATATYPE_ENUM           dataType = NullDataType;
	DBA_DYNFLD_STP          dynStpTmp;
	const char		    *dataTypeSqlname;
	char					*formatEltName;

	unsigned char           currSeparator = SV_CharUnitSeparator;
	unsigned char           recordSeparator = SV_CharRecordSeparator;


	if (!(*string) && resultEvalTreePtr->number != 0)                     /*PMSTA-52148 - GAD - 20240320 */
		*string = (char *)CALLOC(256 * resultEvalTreePtr->number, sizeof(char));
	else
		*string = (char *)REALLOC(*string, 256 * resultEvalTreePtr->number * sizeof(char));

    if (*string == NULL)
        return;

    (*string)[0] = END_OF_STRING;

	for (i = 0; i < resultEvalTreePtr->number; i++)
	{
		dataTypeDictId = GET_DICT(resultEvalTreePtr->definitions->sumFmtEltTab[i], Sum_FmtElt_DataTpDictId);
		dataType = DATATYPE_DICT_TO_ENUM(dataTypeDictId);
		dynStpTmp = &resultBaseValPtr[i];
		valPtr = GET_FLDPTR_BY_DTP(dataType, dynStpTmp, 0);
		CONV_DataToStr(tmpDataBuf, sizeof(tmpDataBuf),
			dataType,
			GET_CONV_MASK(GET_DFLTCONVFMT(dataType)),
			(PTR)valPtr,
			TRUE, ICU4AAA_SQLServerUTF8 == TRUE ? TextConversion_Utf8 : TextConversion_Xml);

		/* trim illegal characters */

		STRING_Trim(tmpDataBuf);

		dataTypeSqlname = DBA_GetDataTypeSQLNameC(dataType);
		formatEltName = GET_NAME(resultEvalTreePtr->definitions->sumFmtEltTab[i], Sum_FmtElt_Name);

		CTYPE_ENUM cType = GET_CTYPE(dataType);

        if (IS_NULLFLD(resultBaseValPtr, i) ||
            ((dataType == DateType || dataType == DatetimeType) && GET_DATE(resultBaseValPtr, i) == MAGIC_END_DATE))
            {

            if(isDesFlow)
                sprintf(tmpString,
                    "%s=%s%c ",
                    formatEltName,
                    "NULL",
                    recordSeparator);
            else
            sprintf(tmpString,
                "%s:%s:%s=%s%c ",
                formatName,
                formatEltName,
				dataTypeSqlname,
                "NULL",
                recordSeparator);
        }
        else if (cType == CharPtrCType || cType == TextPtrCType || cType == UniCharPtrCType || cType == UniTextPtrCType)
		{
            if(isDesFlow)
                sprintf(tmpString,
                    "%s=%c%s%c%c ",
                    formatEltName,
                    currSeparator,
                    tmpDataBuf,
                    currSeparator,
                    recordSeparator);
            else
			sprintf(tmpString,
				"%s:%s:%s=%c%s%c%c ",
				formatName,
				formatEltName,
				dataTypeSqlname,
				currSeparator,
				tmpDataBuf,
				currSeparator,
				recordSeparator);
		}
		else
		{
            if(isDesFlow)
                sprintf(tmpString,
                    "%s=%s%c ",
                    formatEltName,
                    tmpDataBuf,
                    recordSeparator);
            else
            sprintf(tmpString,
                "%s:%s:%s=%s%c ",
                formatName,
                formatEltName,
				dataTypeSqlname,
                tmpDataBuf,
                recordSeparator);
 		}

		strcat(*string, tmpString);
	}
}

/************************************************************************
**
**  Function    :   DBA_BuildStrWithFormat()
**
**  Description :   Build a string
**
**  Argument    :   object, format, record, buffer, connection
**
** Return codes:   TRUE, FALSE
**
*************************************************************************/
int DBA_BuildStrWithFormat(
	OBJECT_ENUM object, DBA_DYNFLD_STP aFmtStp, DBA_DYNFLD_STP aDynSt,
		char ** totalBuff, DbiConnection &dbiConn,FLAG_T isDesFlow )
{
	DBA_DYNFLD_STP          resultBaseValPtr = (DBA_DYNFLD_STP)NULL;
	DBA_RESULT_EVAL_TREE_STP   resultEvalTreePtr = (DBA_RESULT_EVAL_TREE_STP)NULL;

	const char *formatName =
		IS_NULLFLD(aFmtStp, A_Fmt_Name) ? "NULL" : GET_NAME(aFmtStp, A_Fmt_Name);


	if ((resultEvalTreePtr =
			DBA_EvalFmt(
				object, GET_ID(aFmtStp, A_Fmt_Id), GET_DICT(aFmtStp, A_Fmt_EntityDictId),
					aDynSt, dbiConn)) == (DBA_RESULT_EVAL_TREE_STP)NULL)
	{
		return FALSE;
	}

	if (DBA_ExecFmt(resultEvalTreePtr, &resultBaseValPtr, GET_EDITGUIST(object), aDynSt) != RET_SUCCEED)
	{
		return FALSE;
	}

	DBA_PrintFmtToString(formatName, resultEvalTreePtr, resultBaseValPtr, totalBuff, isDesFlow);

	return TRUE;
}

/************************************************************************
**
**  Function    :   DBA_NewCaseSplitSession.
**
**  Description :   Create new sessions for rejected Orders in a during Rebalancing.
**
**  Arguments   :
**
**  Return      :
**
**  Creation    :   PMSTA-35921 - Kramadevi - 14062019
**
**  Modif.      :
**
*************************************************************************/
RET_CODE DBA_NewCaseSplitSession(DBA_DYNFLD_STP			**extOpTab,
                                 int					*extOpNbr,
                                 DBA_DYNFLD_STP         **allPtfTab,
                                 int                    allPtfNbr,
                                 DBA_DYNFLD_STP         **ESLTab,
                                 int                    ESLNbr,
                                 DBA_DYNFLD_STP         **ESETab,
                                 int                    ESENbr,
                                 FLAG_T                **allocFlgTab,
                                 DBA_DYNFLD_STP			pdbadynDomain,
                                 DBA_DYNFLD_STP			**caseMgtTab,
                                 int					*caseMgtNbr,
                                 int					*connectNo,
                                 PTR                    argHierHead)
{
    RET_CODE            ret = RET_SUCCEED;

    DBA_DYNFLD_STP		failedDomainPtr = NULL,
                        toValidateDomainPtr = NULL,
                        *finalOrderTab = NULL, *failedOrderTab = NULL,
                        *finalCaseMgtTab = NULL, *failedCaseMgtTab = NULL,
                        *finalPtfTab = NULL, *toValidateCaseMgtTab = NULL,
                        *toValidatePtfTab = NULL, *failedPtfTab = NULL, *toValidateOrderTab = NULL;

    int                 finalPtfNbr = 0, i = 0, j = 0,
                        finalOrderNbr = 0, toValidateCaseMgtNbr = 0,
                        finalCaseMgtNbr = 0, failedCaseMgtNbr = 0,
                        toValidatePtfNbr = 0, failedPtfNbr = 0,
                        toValidateOrderNbr = 0, failedOrderNbr = 0;

    FLAG_T              *allocFailedFlgTab = NULL, foundFlg = TRUE,
                        *allocFinalFlgTab = NULL, *allocToValidateFlgTab = NULL;

    ENUM_T				applStratBlockConstrCriticalness, applSessionBlockCriticalness;

    CASEMANAGEMENTSTATUS_ENUM applCaseClarificationStatus = CaseManagementStatus_NotClarified;

    DBA_DYNFLD_STP	    copyArgPtr = NULL;

    if ((toValidatePtfTab = (DBA_DYNFLD_STP*)CALLOC(allPtfNbr, sizeof(DBA_DYNFLD_STP))) == NULL)
    {
        for (i = 0; i < allPtfNbr; i++)
        {
            if ((*allocFlgTab)[i] == TRUE) { FREE_DYNST((*allPtfTab)[i], A_Ptf); }
        }
        ret = RET_MEM_ERR_ALLOC;
        MSG_SendMesg(ret, 0, FILEINFO);
        return(ret);
    }

    if ((failedPtfTab = (DBA_DYNFLD_STP*)CALLOC(allPtfNbr, sizeof(DBA_DYNFLD_STP))) == NULL)
    {
        for (i = 0; i < allPtfNbr; i++)
        {
            if ((*allocFlgTab)[i] == TRUE) { FREE_DYNST((*allPtfTab)[i], A_Ptf); }
        }
        FREE(toValidatePtfTab);
        ret = RET_MEM_ERR_ALLOC;
        MSG_SendMesg(ret, 0, FILEINFO);
        return(ret);
    }

    if ((finalPtfTab = (DBA_DYNFLD_STP*)CALLOC(allPtfNbr, sizeof(DBA_DYNFLD_STP))) == NULL)
    {
        for (i = 0; i < allPtfNbr; i++)
        {
            if ((*allocFlgTab)[i] == TRUE) { FREE_DYNST((*allPtfTab)[i], A_Ptf); }
        }
        FREE(failedPtfTab);
        FREE(toValidatePtfTab);
        ret = RET_MEM_ERR_ALLOC;
        MSG_SendMesg(ret, 0, FILEINFO);
        return(ret);
    }

    if ((allocToValidateFlgTab = (FLAG_T*)CALLOC(allPtfNbr, sizeof(FLAG_T))) == NULL)
    {
        for (i = 0; i < allPtfNbr; i++)
        {
            if ((*allocFlgTab)[i] == TRUE) { FREE_DYNST((*allPtfTab)[i], A_Ptf); }
        }
        FREE(toValidatePtfTab)
        FREE(failedPtfTab);
        FREE(finalPtfTab);
        ret = RET_MEM_ERR_ALLOC;
        MSG_SendMesg(ret, 0, FILEINFO);
        return(ret);
    }

    if ((allocFailedFlgTab = (FLAG_T*)CALLOC(allPtfNbr, sizeof(FLAG_T))) == NULL)
    {
        for (i = 0; i < allPtfNbr; i++)
        {
            if ((*allocFlgTab)[i] == TRUE) { FREE_DYNST((*allPtfTab)[i], A_Ptf); }
        }
        FREE(toValidatePtfTab)
        FREE(failedPtfTab);
        FREE(finalPtfTab);
        FREE(allocToValidateFlgTab);
        ret = RET_MEM_ERR_ALLOC;
        MSG_SendMesg(ret, 0, FILEINFO);
        return(ret);
    }

    if ((allocFinalFlgTab = (FLAG_T*)CALLOC(allPtfNbr, sizeof(FLAG_T))) == NULL)
    {
        for (i = 0; i < allPtfNbr; i++)
        {
            if ((*allocFlgTab)[i] == TRUE) { FREE_DYNST((*allPtfTab)[i], A_Ptf); }
        }
        FREE(toValidatePtfTab);
        FREE(failedPtfTab);
        FREE(finalPtfTab);
        FREE(allocFailedFlgTab);
        FREE(allocToValidateFlgTab);
        ret = RET_MEM_ERR_ALLOC;
        MSG_SendMesg(ret, 0, FILEINFO);
        return(ret);
    }

    GEN_GetApplInfo(ApplStratBlockConstrCriticalness, &applStratBlockConstrCriticalness);
    GEN_GetApplInfo(ApplSessionBlockCriticalness, &applSessionBlockCriticalness);
    GEN_GetApplInfo(ApplCaseClarificationStatus, &applCaseClarificationStatus);

    if ((*caseMgtNbr) > 0)
    {
        for (i = 0; i < (*caseMgtNbr); i++)
        {
            if (IS_NULLFLD((*caseMgtTab)[i], A_CaseManagement_PtfId) == FALSE &&
                IS_NULLFLD((*caseMgtTab)[i], A_CaseManagement_CriticalnessEn) == FALSE &&
                GET_ENUM((*caseMgtTab)[i], A_CaseManagement_CriticalnessEn) >= applSessionBlockCriticalness)
            {
                /*derive the failed cases*/
                FIN_LocCaseSplit((*caseMgtTab)[i],
                                  *allPtfTab,
                                  allPtfNbr,
                                  *allocFlgTab,
                                  &failedPtfTab,
                                  &failedPtfNbr,
                                  &allocFailedFlgTab);

            }
            else if (IS_NULLFLD((*caseMgtTab)[i], A_CaseManagement_CriticalnessEn) == FALSE &&
                     GET_ENUM((*caseMgtTab)[i], A_CaseManagement_CriticalnessEn) >= applStratBlockConstrCriticalness &&
                     IS_NULLFLD((*caseMgtTab)[i], A_CaseManagement_StatusEn) == FALSE &&
                     GET_ENUM((*caseMgtTab)[i], A_CaseManagement_StatusEn) < applCaseClarificationStatus)
            {
                /*derive toValidate cases*/
                FIN_LocCaseSplit((*caseMgtTab)[i],
                                  *allPtfTab,
                                  allPtfNbr,
                                  *allocFlgTab,
                                  &toValidatePtfTab,
                                  &toValidatePtfNbr,
                                  &allocToValidateFlgTab);
            }
        }
    }

    /* populating finalPtfTab*/
    if (!(failedPtfNbr == allPtfNbr || toValidatePtfNbr == allPtfNbr) &&
        failedPtfNbr < allPtfNbr || toValidatePtfNbr < allPtfNbr)
    {
        for (i = 0; i < allPtfNbr; i++)
        {
            foundFlg = FALSE;

            for (j = 0; j < failedPtfNbr; j++)
            {
                if (CMP_ID(GET_ID((*allPtfTab)[i], A_Ptf_Id), GET_ID(failedPtfTab[j], A_Ptf_Id)) == 0)
                {
                    foundFlg = TRUE;
                    break;
                }
            }
            if (foundFlg == FALSE)
            {
                for (int k = 0; k < toValidatePtfNbr; k++)
                {
                    if (CMP_ID(GET_ID((*allPtfTab)[i], A_Ptf_Id), GET_ID(toValidatePtfTab[k], A_Ptf_Id)) == 0)
                    {
                        foundFlg = TRUE;
                        break;
                    }
                }
            }

            if (foundFlg == FALSE)
            {
                finalPtfTab[finalPtfNbr] = (*allPtfTab)[i];
                allocFinalFlgTab[finalPtfNbr++] = (*allocFlgTab)[i];
            }
        }
    }

    /* populate order details */
    if ((finalOrderTab = (DBA_DYNFLD_STP*)CALLOC(*extOpNbr, sizeof(DBA_DYNFLD_STP))) == NULL)
    {
        for (i = 0; i < allPtfNbr; i++)
        {
            if ((*allocFlgTab)[i] == TRUE) { FREE_DYNST((*allPtfTab)[i], A_Ptf); }
        }
        FREE(failedPtfTab);
        FREE(toValidatePtfTab);
        FREE(finalPtfTab);
        FREE(allocFailedFlgTab);
        FREE(allocToValidateFlgTab);
        FREE(allocFinalFlgTab);
        ret = RET_MEM_ERR_ALLOC;
        MSG_SendMesg(ret, 0, FILEINFO);
        return(ret);
    }

    if ((toValidateOrderTab = (DBA_DYNFLD_STP*)CALLOC(*extOpNbr, sizeof(DBA_DYNFLD_STP))) == NULL)
    {
        for (i = 0; i < allPtfNbr; i++)
        {
            if ((*allocFlgTab)[i] == TRUE) { FREE_DYNST((*allPtfTab)[i], A_Ptf); }
        }
        FREE(failedPtfTab);
        FREE(toValidatePtfTab);
        FREE(finalPtfTab);
        FREE(allocFailedFlgTab);
        FREE(allocToValidateFlgTab);
        FREE(allocFinalFlgTab);
        FREE(finalOrderTab);
        ret = RET_MEM_ERR_ALLOC;
        MSG_SendMesg(ret, 0, FILEINFO);
        return(ret);
    }

    if ((failedOrderTab = (DBA_DYNFLD_STP*)CALLOC(*extOpNbr, sizeof(DBA_DYNFLD_STP))) == NULL)
    {
        for (i = 0; i < allPtfNbr; i++)
        {
            if ((*allocFlgTab)[i] == TRUE) { FREE_DYNST((*allPtfTab)[i], A_Ptf); }
        }
        FREE(failedPtfTab);
        FREE(toValidatePtfTab);
        FREE(finalPtfTab);
        FREE(allocFailedFlgTab);
        FREE(allocToValidateFlgTab);
        FREE(allocFinalFlgTab);
        FREE(finalOrderTab);
        FREE(toValidateOrderTab);
        ret = RET_MEM_ERR_ALLOC;
        MSG_SendMesg(ret, 0, FILEINFO);
        return(ret);
    }

    for (i = 0; i < finalPtfNbr; i++)
    {
        for (j = 0; j < *extOpNbr; j++)
        {
            if (CMP_ID(GET_ID((*extOpTab)[j], ExtOp_PtfId), GET_ID(finalPtfTab[i], A_Ptf_Id)) == 0)
            {
                DBA_UpdExtOpBeginD((*extOpTab)[j], NULLDYNST, finalPtfTab[i]);
                finalOrderTab[finalOrderNbr] = (*extOpTab)[j];
                finalOrderNbr++;
            }
        }
    }

    /* Opening the final session in the Order List, the block orders are not retrieved*/
    /* Saving block orders for splitSession(final + draft) case */
    if ((failedPtfNbr > 0 || toValidatePtfNbr > 0) && finalOrderNbr > 0 &&
        (GET_ENUM(pdbadynDomain, A_Domain_GenGlobalOrderEn) == (ENUM_T)DomGenGlobalOrder_Yes &&
            IS_NULLFLD(pdbadynDomain, A_Domain_BookPtfId) == FALSE))
    {
        for (j = 0; j < *extOpNbr; j++)
        {
            if (GET_ENUM((*extOpTab)[j], ExtOp_ParOpNatEn) == ParOpNat_BlockOrder)
            {
                finalOrderTab[finalOrderNbr] = (*extOpTab)[j];
                finalOrderNbr++;
            }
        }
    }

    for (i = 0; i < failedPtfNbr; i++)
    {
        for (j = 0; j < *extOpNbr; j++)
        {
            if (CMP_ID(GET_ID((*extOpTab)[j], ExtOp_PtfId), GET_ID(failedPtfTab[i], A_Ptf_Id)) == 0)
            {
                failedOrderTab[failedOrderNbr] = (*extOpTab)[j];
                failedOrderNbr++;
            }
        }
    }
    for (i = 0; i < toValidatePtfNbr; i++)
    {
        for (j = 0; j < *extOpNbr; j++)
        {
            if (CMP_ID(GET_ID((*extOpTab)[j], ExtOp_PtfId), GET_ID(toValidatePtfTab[i], A_Ptf_Id)) == 0)
            {
                toValidateOrderTab[toValidateOrderNbr] = (*extOpTab)[j];
                toValidateOrderNbr++;
            }
        }
    }

    if ((copyArgPtr = ALLOC_DYNST(A_CopyArg)) == NULL)
    {
        for (i = 0; i < allPtfNbr; i++)
        {
            if ((*allocFlgTab)[i] == TRUE) { FREE_DYNST((*allPtfTab)[i], A_Ptf); }
        }
        FREE(failedPtfTab);
        FREE(finalPtfTab);
        FREE(toValidatePtfTab);
        FREE(allocFailedFlgTab);
        FREE(allocFinalFlgTab);
        FREE(allocToValidateFlgTab);
        FREE(failedOrderTab);
        FREE(toValidateOrderTab);
        FREE(finalOrderTab);
        ret = RET_MEM_ERR_ALLOC;
        MSG_SendMesg(ret, 0, FILEINFO);
        return(ret);
    }
    else
    {
        SET_ID(copyArgPtr, A_CopyArg_FromId, GET_ID(pdbadynDomain, A_Domain_FctResultId));
    }

    if (toValidatePtfNbr == 0 && failedPtfNbr == 0)
    {
        if (GET_DICT(pdbadynDomain, A_Domain_InitialFctDictId) == DictFct_ManageSession)
        {
            /* for successful portfolios, update last_rebalancing info */
            SET_NULL_ID(copyArgPtr, A_CopyArg_ToId);
            SET_ENUM(pdbadynDomain, A_Domain_FctResultStatEn, FctResultStatus_Final);
            for (i = 0; i < allPtfNbr; i++)
            {
                SET_ID(copyArgPtr, A_CopyArg_ConsPortId, GET_ID((*allPtfTab)[i], A_Ptf_Id));
                ret = DBA_Update2(FctResult,
                                  DBA_ROLE_SPLIT_FCTRESULT,
                                  A_CopyArg,
                                  copyArgPtr,
                                  DBA_SET_CONN | DBA_NO_CLOSE,
                                  connectNo);
            }
        }

        for (i = 0; i < allPtfNbr; i++)
        {
            if ((*allocFlgTab)[i] == TRUE) { FREE_DYNST((*allPtfTab)[i], A_Ptf); }
        }
        FREE_DYNST(copyArgPtr, A_CopyArg);
        FREE(failedPtfTab);
        FREE(toValidatePtfTab);
        FREE(finalPtfTab);
        FREE(allocFailedFlgTab);
        FREE(allocToValidateFlgTab);
        FREE(allocFinalFlgTab);
        FREE(finalOrderTab);
        FREE(toValidateOrderTab);
        FREE(failedOrderTab);
        return(ret);
    }

    if (finalPtfNbr == 0 && (failedPtfNbr == 0 || toValidatePtfNbr == 0))
    {
        if (GET_DICT(pdbadynDomain, A_Domain_InitialFctDictId) == DictFct_ManageSession)
        {
            SET_ENUM(pdbadynDomain, A_Domain_FctResultStatEn, (ENUM_T)FctResultStatus_CheckedSession);
            if (failedPtfNbr > 0)
            {
                /* set the failed orders session status to Failed */
                SET_ENUM(pdbadynDomain, A_Domain_FctResultStatEn, (ENUM_T)FctResultStatus_Failed);
            }
            /* for failed portfolios, update last_rebalancing info */
             SET_NULL_ID(copyArgPtr, A_CopyArg_ToId);
             for (i = 0; i < allPtfNbr; i++)
             {
                 SET_ID(copyArgPtr, A_CopyArg_ConsPortId, GET_ID((*allPtfTab)[i], A_Ptf_Id));
                 ret = DBA_Update2(FctResult,
                                   DBA_ROLE_SPLIT_FCTRESULT,
                                   A_CopyArg,
                                   copyArgPtr,
                                   DBA_SET_CONN | DBA_NO_CLOSE,
                                   connectNo);
             }
             DBA_Update2(Domain, UNUSED, A_Domain, pdbadynDomain, DBA_SET_CONN | DBA_NO_CLOSE, connectNo, UNUSED);
        }

        for (i = 0; i < allPtfNbr; i++)
        {
            if ((*allocFlgTab)[i] == TRUE) { FREE_DYNST((*allPtfTab)[i], A_Ptf); }
        }
        FREE_DYNST(copyArgPtr, A_CopyArg);
        FREE(failedPtfTab);
        FREE(toValidatePtfTab);
        FREE(finalPtfTab);
        FREE(allocFailedFlgTab);
        FREE(allocToValidateFlgTab);
        FREE(allocFinalFlgTab);
        FREE(finalOrderTab);
        FREE(toValidateOrderTab);
        FREE(failedOrderTab);
        ret = RET_DBA_ERR_KRANOTFOUND;
        return(ret);
    }

    /* ************************************** */
    /* Create new session for rejected Orders */
    /* ************************************** */
    if (failedPtfNbr > 0)
    {
        failedDomainPtr = ALLOC_DYNST(A_Domain);
        failedCaseMgtTab = (DBA_DYNFLD_STP*)CALLOC(*caseMgtNbr, sizeof(DBA_DYNFLD_STP));
        if (failedDomainPtr != NULL && failedCaseMgtTab != NULL)
        {
            COPY_DYNST(failedDomainPtr, pdbadynDomain, A_Domain);
            SET_NULL_ID(failedDomainPtr, A_Domain_Id);
            SET_NULL_ID(failedDomainPtr, A_Domain_FctResultId);
            SET_NULL_CODE(failedDomainPtr, A_Domain_FctResultCd);

            SET_ID(failedDomainPtr, A_Domain_ParentSessionId, GET_ID(pdbadynDomain, A_Domain_FctResultId));

            /* set the failed orders session status to Failed */
            SET_ENUM(failedDomainPtr, A_Domain_FctResultStatEn, (ENUM_T)FctResultStatus_Failed);
            ret = DBA_CreateAndPopulateNewSessionId(failedDomainPtr,
                                                pdbadynDomain,
                                                copyArgPtr,
                                                failedPtfNbr,
                                                &failedPtfTab,
                                                failedOrderNbr,
                                                &failedOrderTab,
                                                ESLNbr,
                                                &(*ESLTab),
                                                ESENbr,
                                                &(*ESETab),
                                                *caseMgtNbr,
                                                &(*caseMgtTab),
                                                &failedCaseMgtNbr,
                                                &failedCaseMgtTab,
                                                connectNo);
        }

        if (failedDomainPtr == NULLDYNST || failedCaseMgtTab == NULL || ret != RET_SUCCEED)
        {
            for (i = 0; i < allPtfNbr; i++)
            {
                if ((*allocFlgTab)[i] == TRUE) { FREE_DYNST((*allPtfTab)[i], A_Ptf); }
            }
            FREE_DYNST(copyArgPtr, A_CopyArg);
            FREE_DYNST(failedDomainPtr, A_Domain);
            FREE(failedPtfTab);
            FREE(toValidatePtfTab);
            FREE(finalPtfTab);
            FREE(allocFailedFlgTab);
            FREE(allocToValidateFlgTab);
            FREE(allocFinalFlgTab);
            FREE(finalOrderTab);
            FREE(toValidateOrderTab);
            FREE(failedOrderTab);
            if (failedCaseMgtTab != NULL)
                FREE(failedCaseMgtTab);
            if (ret != RET_SUCCEED)
                return(ret);

            ret = RET_MEM_ERR_ALLOC;
            MSG_SendMesg(ret, 0, FILEINFO);
            return(ret);
        }
    }

    /* Create new session for to be validated orders*/
    if (toValidatePtfNbr > 0)
    {
        toValidateDomainPtr = ALLOC_DYNST(A_Domain);
        toValidateCaseMgtTab = (DBA_DYNFLD_STP*)CALLOC((*caseMgtNbr), sizeof(DBA_DYNFLD_STP));

        if (toValidateDomainPtr != NULL && toValidateCaseMgtTab != NULL)
        {
            COPY_DYNST(toValidateDomainPtr, pdbadynDomain, A_Domain);
            SET_NULL_ID(toValidateDomainPtr, A_Domain_Id);
            SET_NULL_ID(toValidateDomainPtr, A_Domain_FctResultId);
            SET_NULL_CODE(toValidateDomainPtr, A_Domain_FctResultCd);

            SET_ID(toValidateDomainPtr, A_Domain_ParentSessionId, GET_ID(pdbadynDomain, A_Domain_FctResultId));

            /* set the to be validated orders session status to checked session */
            SET_ENUM(toValidateDomainPtr, A_Domain_FctResultStatEn, (ENUM_T)FctResultStatus_CheckedSession);
            ret = DBA_CreateAndPopulateNewSessionId(toValidateDomainPtr,
                                                pdbadynDomain,
                                                copyArgPtr,
                                                toValidatePtfNbr,
                                                &toValidatePtfTab,
                                                toValidateOrderNbr,
                                                &toValidateOrderTab,
                                                ESLNbr,
                                                &(*ESLTab),
                                                ESENbr,
                                                &(*ESETab),
                                                *caseMgtNbr,
                                                &(*caseMgtTab),
                                                &toValidateCaseMgtNbr,
                                                &toValidateCaseMgtTab,
                                                connectNo);
        }
        if (toValidateDomainPtr == NULLDYNST || toValidateCaseMgtTab == NULL || ret != RET_SUCCEED)
        {
            for (i = 0; i < allPtfNbr; i++)
            {
                if ((*allocFlgTab)[i] == TRUE) { FREE_DYNST((*allPtfTab)[i], A_Ptf); }
            }
            FREE_DYNST(copyArgPtr, A_CopyArg);
            FREE_DYNST(failedDomainPtr, A_Domain);
            FREE_DYNST(toValidateDomainPtr, A_Domain);
            FREE(failedPtfTab);
            FREE(toValidatePtfTab);
            FREE(finalPtfTab);
            FREE(allocFailedFlgTab);
            FREE(allocToValidateFlgTab);
            FREE(allocFinalFlgTab);
            FREE(finalOrderTab);
            FREE(toValidateOrderTab);
            FREE(failedOrderTab);
            FREE(failedCaseMgtTab);
            if(toValidateCaseMgtTab != NULL)
                FREE(toValidateCaseMgtTab);
            if (ret != RET_SUCCEED)
                return(ret);

            ret = RET_MEM_ERR_ALLOC;
            MSG_SendMesg(ret, 0, FILEINFO);
            return(ret);
        }
    }

    /* Update original Case number and array */
    if (toValidateCaseMgtNbr > 0 || failedCaseMgtNbr > 0)
    {
        for (i = 0; i < (*caseMgtNbr); i++)
        {
            FLAG_T foundFlag = FALSE;
            for (j = 0; j < toValidateCaseMgtNbr; j++)
            {
                if (CMP_ID(GET_ID((*caseMgtTab)[i], A_CaseManagement_Id),
                    GET_ID((toValidateCaseMgtTab[j]), A_CaseManagement_Id)) == 0)
                {
                    foundFlag = TRUE;
                    break;
                }
            }

            if (foundFlag == FALSE)
            {
                for (j = 0; j < failedCaseMgtNbr; j++)
                {
                    if (CMP_ID(GET_ID((*caseMgtTab)[i], A_CaseManagement_Id),
                        GET_ID((failedCaseMgtTab[j]), A_CaseManagement_Id)) == 0)
                    {
                        foundFlag = TRUE;
                        break;
                    }
                }
            }

            if (foundFlag == FALSE)
            {
                if (finalCaseMgtNbr == 0)
                {
                    if ((finalCaseMgtTab = (DBA_DYNFLD_STP*)CALLOC((*caseMgtNbr), sizeof(DBA_DYNFLD_STP))) == NULL)
                    {
                        for (i = 0; i < allPtfNbr; i++)
                        {
                            if ((*allocFlgTab)[i] == TRUE) { FREE_DYNST((*allPtfTab)[i], A_Ptf); }
                        }
                        FREE_DYNST(copyArgPtr, A_CopyArg);
                        FREE_DYNST(failedDomainPtr, A_Domain);
                        FREE_DYNST(toValidateDomainPtr, A_Domain);
                        FREE(failedPtfTab);
                        FREE(finalPtfTab);
                        FREE(toValidatePtfTab);
                        FREE(allocFailedFlgTab);
                        FREE(allocFinalFlgTab);
                        FREE(allocToValidateFlgTab);
                        FREE(finalOrderTab);
                        FREE(failedOrderTab);
                        FREE(toValidateOrderTab);
                        FREE(failedCaseMgtTab);
                        FREE(toValidateCaseMgtTab);
                        ret = RET_MEM_ERR_ALLOC;
                        MSG_SendMesg(ret, 0, FILEINFO);
                        return(ret);
                    }
                }
                finalCaseMgtTab[finalCaseMgtNbr] = (*caseMgtTab)[i];
                finalCaseMgtNbr++;
            }
        }
        FREE(toValidateCaseMgtTab);
        FREE(failedCaseMgtTab);
    }

    /* If all went well, update original Case number and array */
    if (finalCaseMgtNbr > 0)
    {
        FREE(*caseMgtTab);
        *caseMgtTab = finalCaseMgtTab;
        *caseMgtNbr = finalCaseMgtNbr;
    }
    else /* all Cases where transfered in new session */
    {
        FREE(finalCaseMgtTab);
        FREE(*caseMgtTab);
        *caseMgtNbr = 0;
    }

    /* If all went well, update original ExtOp number and array */
    if (finalOrderNbr > 0)
    {
        FREE(*extOpTab);
        *extOpTab = finalOrderTab;
        *extOpNbr = finalOrderNbr;
    }
    else /* all orders where rejected and transfered in new session */
    {
        FREE(finalOrderTab);
        FREE(*extOpTab);
        *extOpNbr = 0;
    }

    /* for succesful portfolios, update last_rebalancing info */
    SET_NULL_ID(copyArgPtr, A_CopyArg_ToId);
    SET_ENUM(pdbadynDomain, A_Domain_FctResultStatEn, FctResultStatus_Final);
    for (i = 0; i < finalPtfNbr; i++)
    {
        SET_ID(copyArgPtr, A_CopyArg_ConsPortId, GET_ID(finalPtfTab[i], A_Ptf_Id));
        ret = DBA_Update2(FctResult,
            DBA_ROLE_SPLIT_FCTRESULT,
            A_CopyArg,
            copyArgPtr,
            DBA_SET_CONN | DBA_NO_CLOSE,
            connectNo);
    }

    for (i = 0; i < allPtfNbr; i++)
    {
        if ((*allocFlgTab)[i] == TRUE) { FREE_DYNST((*allPtfTab)[i], A_Ptf); }
    }
    FREE_DYNST(failedDomainPtr, A_Domain);
    FREE_DYNST(toValidateDomainPtr, A_Domain);
    FREE(failedPtfTab);
    FREE(finalPtfTab);
    FREE(toValidatePtfTab);
    FREE(allocFailedFlgTab);
    FREE(allocFinalFlgTab);
    FREE(allocToValidateFlgTab);
    FREE(failedOrderTab);
    FREE(toValidateOrderTab);
    FREE(failedCaseMgtTab);;
    FREE(toValidateCaseMgtTab);
    FREE_DYNST(copyArgPtr, A_CopyArg);
    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_LocCaseSplit()
**
**  Description :   Derive failed/toValidate cases from caseMgtTab.
**
**  Arguments   :
**
**  Return      :
**
**  Creation    :   PMSTA-35921 - Kramadevi - 14062019
**
**  Modif.      :
**
*************************************************************************/
STATIC void FIN_LocCaseSplit(DBA_DYNFLD_STP   caseMgtRec,
                             DBA_DYNFLD_STP   *allPtfTab,
                             int              allPtfNbr,
                             FLAG_T           *allocFlgTab,
                             DBA_DYNFLD_STP   **casePtfTab,
                             int              *casePtfNbr,
                             FLAG_T           **allocCaseFlgTab)
{
    DBA_DYNFLD_STP hierPtfPtr = NULL;
    int            allPtfIdx = 0,   j = 0;
    FLAG_T         allochierPtfFlg = FALSE,
                   foundFlg = FALSE,
                   casePtfFoundFlg = FALSE;
    ID_T           hierPtfId = (ID_T)-1;

    DBA_GetPtfById(GET_ID(caseMgtRec, A_CaseManagement_PtfId), TRUE,
                   &allochierPtfFlg, &hierPtfPtr,
                   DBA_GetHierOptiPtr(), UNUSED, UNUSED);

    /*PMSTA-41947 - Kramadevi - 24092020*/
    if (hierPtfPtr != NULLDYNST)
    {
        if (IS_NULLFLD(hierPtfPtr, A_Ptf_HierPortId) == FALSE)
        {
            hierPtfId = GET_ID(hierPtfPtr, A_Ptf_HierPortId);
        }
        else
        {
            hierPtfId = GET_ID(hierPtfPtr, A_Ptf_Id);
        }
    }
    else
    {
        if (allochierPtfFlg == TRUE) { FREE_DYNST(hierPtfPtr, A_Ptf); }
        return;
    }

    /* get the portfolio from allPtfTab */
    for (j = 0; j < allPtfNbr; j++)
    {
        if (CMP_ID(GET_ID(allPtfTab[j], A_Ptf_HierPortId), hierPtfId) == 0 ||
            CMP_ID(GET_ID(allPtfTab[j], A_Ptf_Id), hierPtfId) == 0)
        {
            casePtfFoundFlg = TRUE;
            allPtfIdx = j;
            break;
        }
    }

    if (casePtfFoundFlg == TRUE)
    {
        for (j = 0; j < *casePtfNbr; j++)
        {
            if (CMP_ID(GET_ID((*casePtfTab)[j], A_Ptf_Id), GET_ID(allPtfTab[allPtfIdx], A_Ptf_Id)) == 0)
            {
                foundFlg = TRUE;
                break;
            }
        }

        if (foundFlg == FALSE)
        {
            (*casePtfTab)[*casePtfNbr] = allPtfTab[allPtfIdx];
            (*allocCaseFlgTab)[(*casePtfNbr)++] = allocFlgTab[allPtfIdx];
        }
    }
    if (allochierPtfFlg == TRUE) { FREE_DYNST(hierPtfPtr, A_Ptf); }
}

/************************************************************************
**
**  Function    :   DBA_CreateAndPopulateNewSessionId.
**
**  Description :   Create a new function result id for the failed/toValidate
                    case portfolios and assign the same to corresponding ext_op,
                    ESE, ESL and case management records.
**
**  Arguments   :
**
**  Return      :
**
**  Creation    :   PMSTA-35921 - Kramadevi - 14062019
**
**  Modif.      :
**
*************************************************************************/
STATIC RET_CODE DBA_CreateAndPopulateNewSessionId(DBA_DYNFLD_STP		caseDomainPtr,
                                                  DBA_DYNFLD_STP		pdbadynDomain,
                                                  DBA_DYNFLD_STP	    copyArgPtr,
                                                  int					casePtfNbr,
                                                  DBA_DYNFLD_STP		**casePtfTab,
                                                  int					orderNbr,
                                                  DBA_DYNFLD_STP		**orderTab,
                                                  int					ESLNbr,
                                                  DBA_DYNFLD_STP		**ESLTab,
                                                  int					ESENbr,
                                                  DBA_DYNFLD_STP		**ESETab,
                                                  int					orgCaseMgtNbr,
                                                  DBA_DYNFLD_STP      **orgCaseMgtTab,
                                                  int                  *caseMgtNbr,
                                                  DBA_DYNFLD_STP 		**caseMgtTab,
                                                  int					*connectNo)
{
    DBA_DYNFLD_STP localFctRes = NULL;
    RET_CODE ret=RET_SUCCEED, i = 0,j = 0;

    if ((ret = DBA_NewFctResult(caseDomainPtr, &localFctRes, connectNo)) == RET_SUCCEED)
    {

        SET_ID(copyArgPtr, A_CopyArg_ToId, GET_ID(localFctRes, A_FctResult_Id));

        for (i = 0; i < casePtfNbr; i++)
        {
            SET_ID(copyArgPtr, A_CopyArg_ConsPortId, GET_ID((*casePtfTab)[i], A_Ptf_Id));
            ret = DBA_Update2(FctResult,
                DBA_ROLE_SPLIT_FCTRESULT,
                A_CopyArg,
                copyArgPtr,
                DBA_SET_CONN | DBA_NO_CLOSE,
                connectNo);
        }

        /* Update related ext_operations with new function result id */
        for (i = 0; i < orderNbr; i++)
        {
            COPY_DYNFLD((*orderTab)[i], ExtOp, ExtOp_FctResultId, localFctRes, A_FctResult, A_FctResult_Id);
        }

        for (i = 0; i < casePtfNbr; i++)
        {
            for (j = 0; j < ESLNbr; j++)
            {
                if (CMP_ID(GET_ID((*casePtfTab)[i], A_Ptf_Id), GET_ID((*ESLTab)[j], ExtStratLnk_PtfId)) == 0)
                {
                    COPY_DYNFLD((*ESLTab)[j], ExtStratLnk, ExtStratLnk_FctResultId,
                        localFctRes, A_FctResult, A_FctResult_Id);
                }
            }

            for (j = 0; j < ESENbr; j++)
            {
                if (CMP_ID(GET_ID((*casePtfTab)[i], A_Ptf_Id), GET_ID((*ESETab)[j], ExtStratElt_PtfId)) == 0)
                {
                    COPY_DYNFLD((*ESETab)[j], ExtStratElt, ExtStratElt_FctResultId,
                        localFctRes, A_FctResult, A_FctResult_Id);
                }
            }

            /* select cases based on failed portfolios */
            for (j = 0; j < orgCaseMgtNbr; j++)
            {
                if (CMP_ID(GET_ID((*casePtfTab)[i], A_Ptf_Id), GET_ID((*orgCaseMgtTab)[j], A_CaseManagement_PtfId)) == 0)
                {
                    COPY_DYNFLD((*orgCaseMgtTab)[j], A_CaseManagement, A_CaseManagement_SessionId,
                        localFctRes, A_FctResult, A_FctResult_Id);

                    /* PMSTA-28596  - CHU - 170926 */
                    if (GET_DICT((*orgCaseMgtTab)[j], A_CaseManagement_MainEntityDictId) == FctResultCst)
                    {
                        COPY_DYNFLD((*orgCaseMgtTab)[j], A_CaseManagement, A_CaseManagement_MainObjId,
                            localFctRes, A_FctResult, A_FctResult_Id);
                    }

                    (*caseMgtTab)[*caseMgtNbr] = (*orgCaseMgtTab)[j];
                    (*caseMgtNbr)++;
                }
            }
        }
    }
    return(ret);
}

/************************************************************************
**
**  Function    :   DBA_LoadPerfCalcDef()
**
**  Description :   Load all perf_cal_def records with perf_computation_rule and perf_fess_taxes_rule in extension
**
**
**  Arguments   :   input:
**                  hierHead            hierarchy header pointer
**
**                  output:
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   PMSTA-47578 - DDV - 220131
**
*************************************************************************/
RET_CODE DBA_LoadPerfCalcDef(DBA_HIER_HEAD_STP   hierHead,
                             DBA_DYNFLD_STP      **perfCalcDefTab,
                             int                 *perfCalcDefNbr)
{
    DBA_DYNFLD_STP      *hierPerfCalcDefTab = NULLDYNSTPTR;
    int                  hierPerfCalcDefNbr = 0;
    RET_CODE             ret = RET_SUCCEED;

    /* extract from hierarchy */
    DBA_ExtractHierEltRec(hierHead, A_PerfCalcDef, FALSE, NULLFCT, NULLFCT, &hierPerfCalcDefNbr, &hierPerfCalcDefTab);

    *perfCalcDefTab = NULLDYNSTPTR;
    *perfCalcDefNbr = 0;

    /* If nothing in hierarchy load data from database */
    if (hierPerfCalcDefNbr == 0)
    {
        int                    outputBlkNb = 2;
        int                    rows[] = { 0,0 };
        DBA_DYNFLD_STP        *outputData[] = { 0,0 };
        const DBA_DYNST_ENUM  *outputStLst[] = { &A_PerfCalcDef,
                                                 &A_PerfFeesTaxesRule};

        DbiConnectionHelper   connHelper;

        if (connHelper.dbaMultiSelect(PerfCalcDef, UNUSED, nullptr, outputData, rows) == RET_SUCCEED)
        {
            if (rows[0] > 0)
            {
                /* Distribute loaded data (if creation is ok) */
                for (int i = 0; i < outputBlkNb && ret == RET_SUCCEED; i++)
                {
                    if (ret == RET_SUCCEED)
                    {
                        ret = DBA_AddHierRecordList(hierHead, outputData[i], rows[i], *(outputStLst[i]), TRUE);
                    }
                }

                for (int i = 0; i < outputBlkNb; i++)
                {
                    FREE(outputData[i]);
                }

                if ((ret = DBA_SetHierLnkUsed(hierHead, A_PerfCalcDef, A_PerfCalcDef_PerfFeesTaxesRule_Ext)) != RET_SUCCEED)
                {
                    return(ret);
                }

                DBA_MakeAllRecLinks(hierHead, A_PerfCalcDef);

                DBA_ExtractHierEltRec(hierHead, A_PerfCalcDef, FALSE, NULLFCT, NULLFCT, perfCalcDefNbr, perfCalcDefTab);

                return(RET_SUCCEED);
            }
            else
            {
                /* If nothing exist, add an empty record element in hierachy */
                DBA_DYNFLD_STP     emptyPerfCalDef = ALLOC_DYNST(A_PerfCalcDef);

                DBA_AddHierRecord(hierHead, emptyPerfCalDef, A_PerfCalcDef, FALSE, HierAddRec_NoLnk);
                return(RET_SUCCEED);
            }
        }
    }
    else if (hierPerfCalcDefNbr == 1 && GET_ID(hierPerfCalcDefTab[0], A_PerfCalcDef_Id) < 0)
    {
        FREE(hierPerfCalcDefTab);
		hierPerfCalcDefNbr = 0;
        return(RET_SUCCEED);
    }

    *perfCalcDefTab = hierPerfCalcDefTab;
    *perfCalcDefNbr = hierPerfCalcDefNbr;

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   DBA_LoadPerfCalcDefByProfileId()
**
**  Description :   Load perf_cal_def records with perf_computation_rule and perf_fess_taxes_rule in extension
**                  for given profile.
**
**
**  Arguments   :   input:
**                  hierHead            hierarchy header pointer
**
**                  output:
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   PMSTA-51082 - SenthilKumar - 042423
**
*************************************************************************/
RET_CODE DBA_LoadPerfCalcDefByProfileId(DBA_HIER_HEAD_STP   hierHead,
	                                    ID_T                perfCalcDefProfileId,
	                                    DBA_DYNFLD_STP    **perfCalcDefTab,
	                                    int                *perfCalcDefNbr,
                                        DBA_DYNFLD_STP     *perfCalcDefProfilePtr) /* WEALTH-5865 - DDV - 240429 - Add and manage perf_calc_def_profile.keep_portfolio_perf_freq_f */
{
	DBA_DYNFLD_STP       perfCalcDefProfileSt = NULLDYNST;
	RET_CODE             ret = RET_SUCCEED;

	/* extract from hierarchy */
	DBA_GetRecPtrFromHierById(hierHead, perfCalcDefProfileId, A_PerfCalcDefProfile, &perfCalcDefProfileSt);

	*perfCalcDefTab = NULLDYNSTPTR;
	*perfCalcDefNbr = 0;

	/* If nothing in hierarchy load data from database */
	if (perfCalcDefProfileSt == NULLDYNST)
	{
		int                    outputBlkNb = 4;
		int                    rows[] = { 0,0,0,0 };
		DBA_DYNFLD_STP        *outputData[] = { 0,0,0,0 };
		const DBA_DYNST_ENUM  *outputStLst[] = { &A_PerfCalcDefProfileCompo,
                                                 &A_PerfCalcDefProfile,
                                                 &A_PerfCalcDef,
												 &A_PerfFeesTaxesRule };
		MemoryPool            mp;
		DBA_DYNFLD_STP        admArgStp = mp.allocDynst(FILEINFO, Adm_Arg);
		DbiConnectionHelper   connHelper;
		SET_ID(admArgStp, Adm_Arg_Id, perfCalcDefProfileId);

		if (connHelper.dbaMultiSelect(PerfCalcDef, UNUSED, admArgStp, outputData, rows) == RET_SUCCEED)
		{
			if (rows[0] > 0)
			{
				/* Distribute loaded data (if creation is ok) */
				for (int i = 0; i < outputBlkNb && ret == RET_SUCCEED; i++)
				{
					if (ret == RET_SUCCEED)
					{
						DBA_DYNFLD_STP   dynStp;
						int dynfldidx;
						dynfldidx = -1;
						if (*outputStLst[i] == A_PerfCalcDef)
						{
							dynfldidx = A_PerfCalcDef_Id;
						}
						else if (*outputStLst[i] == A_PerfFeesTaxesRule)
						{
							dynfldidx = A_PerfFeesTaxesRule_Id;
						}
						else if (*outputStLst[i] == A_PerfCalcDefProfileCompo)
						{
							dynfldidx = A_PerfCalcDefProfileCompo_Id;
						}
						else if (*outputStLst[i] == A_PerfCalcDefProfile)
						{
							dynfldidx = A_PerfCalcDefProfile_Id;
                            perfCalcDefProfileSt = outputData[i][0];
						}

						for (int j = 0; j < rows[i]; j++)
						{
							ret = DBA_GetRecPtrFromHierById(hierHead,
								GET_ID(outputData[i][j], dynfldidx),
								*outputStLst[i],
								&dynStp);
							if (dynStp != NULL)
							{
								FREE_DYNST(outputData[i][j], *outputStLst[i]);
							}
						}
						ret = DBA_AddHierRecordList(hierHead, outputData[i], rows[i], *(outputStLst[i]), TRUE);
					}
				}

				for (int i = 0; i < outputBlkNb; i++)
				{
					FREE(outputData[i]);
				}

				if ((ret = DBA_SetHierLnkUsed(hierHead, A_PerfCalcDef, A_PerfCalcDef_PerfFeesTaxesRule_Ext)) != RET_SUCCEED)
				{
					return(ret);
				}

				DBA_MakeAllRecLinks(hierHead, A_PerfCalcDef);

				if ((ret = DBA_SetHierLnkUsed(hierHead, A_PerfCalcDefProfile, A_PerfCalcDefProfile_PerfCalcDefProfileCompo_Ext)) != RET_SUCCEED)
				{
					return(ret);
				}

				DBA_MakeSpecRecLinks(hierHead, A_PerfCalcDefProfile, A_PerfCalcDefProfile_PerfCalcDefProfileCompo_Ext);

				if ((ret = DBA_SetHierLnkUsed(hierHead, A_PerfCalcDefProfileCompo, A_PerfCalcDefProfileCompo_PerfCalcDef_Ext)) != RET_SUCCEED)
				{
					return(ret);
				}

				DBA_MakeSpecRecLinks(hierHead, A_PerfCalcDefProfileCompo, A_PerfCalcDefProfileCompo_PerfCalcDef_Ext);
			}
			else
			{
                DBA_MultiFree(outputData,outputStLst,rows,outputBlkNb); /* PMSTA-54581 - JBC - 231030 */
				/* If nothing exist, add an empty record element in hierachy */
				DBA_DYNFLD_STP     emptyPerfCalDef = ALLOC_DYNST(A_PerfCalcDef);

				DBA_AddHierRecord(hierHead, emptyPerfCalDef, A_PerfCalcDef, FALSE, HierAddRec_NoLnk);
				return(RET_SUCCEED);
			}
		}
	}

    if (perfCalcDefProfileSt != NULLDYNST)
    {
        DBA_DYNFLD_STP   *perfCalcDefProfCompoPtr = GET_EXTENSION_PTR(perfCalcDefProfileSt, A_PerfCalcDefProfile_PerfCalcDefProfileCompo_Ext);
        int               perfCalcDefProfCompoNbr = GET_EXTENSION_NBR(perfCalcDefProfileSt, A_PerfCalcDefProfile_PerfCalcDefProfileCompo_Ext);

        if (perfCalcDefProfCompoNbr > 0 && perfCalcDefProfCompoPtr != nullptr)
        {
            DBA_DYNFLD_STP* perfCalcDefProfCompoTab = (DBA_DYNFLD_STP*)CALLOC(perfCalcDefProfCompoNbr, sizeof(DBA_DYNFLD_STP));

            if (perfCalcDefProfCompoTab == NULLDYNSTPTR)
            {
                MSG_RETURN(RET_MEM_ERR_ALLOC);
            }

            for (int i = 0, idx = 0; i < perfCalcDefProfCompoNbr; i++)
            {
                perfCalcDefProfCompoTab[idx++] = *GET_EXTENSION_PTR(perfCalcDefProfCompoPtr[i], A_PerfCalcDefProfileCompo_PerfCalcDef_Ext);
            }
            *perfCalcDefTab = perfCalcDefProfCompoTab;
            *perfCalcDefNbr = perfCalcDefProfCompoNbr;

            if (perfCalcDefProfilePtr != NULLDYNSTPTR)
            {
                *perfCalcDefProfilePtr = perfCalcDefProfileSt;
            }
        }
    }

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   DBA_SelPerfCalcDefCompoByProfileId()
**
**  Description :   Load all perf_calc_def_compo records for given profile
**
**
**  Arguments   :   input:
**                  hierHead            hierarchy header pointer
**
**                  output:
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   PMSTA-54529 - DDV - 231005 
**
*************************************************************************/
RET_CODE DBA_SelPerfCalcDefCompoByProfileId(DBA_HIER_HEAD_STP   hierHead,
                                            ID_T                perfCalcDefProfileId,
                                            DBA_DYNFLD_STP    **perfCalcDefCompoTab,
                                            int                *perfCalcDefCompoNbr,
                                            MemoryPool         &mpParam)
{
    DBA_DYNFLD_STP      perfCalcDefProfileSt = NULLDYNST;

    /* extract from hierarchy */
    DBA_GetRecPtrFromHierById(hierHead, perfCalcDefProfileId, A_PerfCalcDefProfile, &perfCalcDefProfileSt);

    *perfCalcDefCompoTab = NULLDYNSTPTR;
    *perfCalcDefCompoNbr = 0;
    DBA_DYNFLD_STP* compoTab = NULLDYNSTPTR;
    int             compoNbr = 0;

    if (perfCalcDefProfileSt != NULLDYNST && compoNbr > 0 && compoTab != nullptr)
    {
        compoTab = GET_EXTENSION_PTR(perfCalcDefProfileSt, A_PerfCalcDefProfile_PerfCalcDefProfileCompo_Ext);
        compoNbr = GET_EXTENSION_NBR(perfCalcDefProfileSt, A_PerfCalcDefProfile_PerfCalcDefProfileCompo_Ext);
    }

    /* If nothing in hierarchy load data from database */
    if (compoNbr > 0 &&  compoTab != nullptr)
    {
        DBA_DYNFLD_STP* perfCalcDefProfCompoTab = (DBA_DYNFLD_STP*) mpParam.calloc(compoNbr, sizeof(DBA_DYNFLD_STP));

        if (perfCalcDefProfCompoTab == NULLDYNSTPTR)
        {
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        for (int i = 0, idx = 0; i < compoNbr; i++)
        {
            perfCalcDefProfCompoTab[idx++] = compoTab[i];
        }

        *perfCalcDefCompoTab = perfCalcDefProfCompoTab;
        *perfCalcDefCompoNbr = compoNbr;
    }
    else
    {
        /* Perf Calc Def Profile not found in hierarchy, load its composition from database */
        MemoryPool          mp;
        DBA_DYNFLD_STP      admArgStp = mp.allocDynst(FILEINFO, Adm_Arg);

        if (admArgStp != NULLDYNST)
        {
            DbiConnectionHelper   connHelper;

            SET_ID(admArgStp, Adm_Arg_Id, perfCalcDefProfileId);

            if (connHelper.dbaSelect(PerfCalcDefProfileCompo, UNUSED, admArgStp, A_PerfCalcDefProfileCompo, perfCalcDefCompoTab, perfCalcDefCompoNbr) == RET_SUCCEED)
            {
                mpParam.ownerDynStpTab(*perfCalcDefCompoTab, *perfCalcDefCompoNbr);
            }
        }
    }

    return(RET_SUCCEED);
}

/*******************************************************************************
**
**  Function    :  DBA_FillDomPortByDomain()
**
**  Description :  Store in dom_port ptf identifiers depending on domain informations
**
**  Arguments   :  domainPtr	pointer on domain structure
**
**  Return      :  RET_SUCCEED or error code
**
**  Creation    :  PMSTA-54517 - DDV - 230928 - Code extracted from DBA_SelPtfByDomain to be used foer since inception
**
**  Modif       :  
*******************************************************************************/
EXTERN RET_CODE DBA_FillDomPortByDomain(DBA_DYNFLD_STP        domainPtr,
                                        bool                  bAllowRebuild,
                                        bool                  bManageEnumList,
                                        DbiConnectionHelper&  dbiConnHelper)
{
    DBI_INT 			status = 0;
    ID_T				listId;
    OBJECT_ENUM			dimObject, listObject;
    DICT_T				listEntDictId, dimEntityDictId = OneCst, dimPtfDictId = NullEntity;
    char*               buffer = NULL;
    RET_CODE			ret = RET_SUCCEED, dbRet;

    if (dbiConnHelper.isValidAndInit() == false)
    {
        MSG_SendMesg(RET_DBA_ERR_CONNOTFOUND, 0, FILEINFO);
        return(RET_DBA_ERR_CONNOTFOUND);
    }


    if (IS_NULLFLD(domainPtr, A_Domain_DimEntityDictId) == FALSE)
    {
        dimEntityDictId = GET_DICT(domainPtr, A_Domain_DimEntityDictId);
    }

    dimPtfDictId = GET_DICT(domainPtr, A_Domain_DimPtfDictId);

    if (dimEntityDictId == ListCst ||
        dimEntityDictId == QuickSearchCst)
    {
        if (dimPtfDictId == PtfCst)
        {
            dimPtfDictId = dimEntityDictId;
        }
    }

    /* Retrieve Domain Portfolio Dimension */
    if (dimPtfDictId == 0)
        dimObject = NullEntity;
    else
        DBA_GetObjectEnum(dimPtfDictId, &dimObject);

    /* Error if load_hier_flg and 'all' portfolio */		/* REF399 - 971020 - DED */
    if (dimObject == NullEntity && GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None)
    {
        if ((GET_DICT(domainPtr, A_Domain_FctDictId) != DictFct_OrderEntry ||
            GET_DICT(domainPtr, A_Domain_FctDictId) != DictFct_SessionsMonitoring) &&	/* PMSTA-30900 - RAK - 180514 */
            GET_ENUM(domainPtr, A_Domain_LoadHierFlg) == LoadHierPtf_Full) /* Uniquement pour le bottom-up approach */
        {
            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO,
                "Portfolio dimension 'All Portfolios' and 'Load Hierarchy' not allowed !");
        }
    }

    DATE_START_TIMER(2, TIMER_MASK_SQLC);
    /* REF9125 - RAK - 030916 - add DOM_STRAT */
    ret = DBA_CreateTempTables(*dbiConnHelper.getConnection(), DOM_STRAT | DOM_POSITION_INSTR_PORT | TCT_VECTOR_ID);

    if (ret != RET_SUCCEED)
    {
        /* SME REF2137 */
/*	    DBA_FilterMsgInfos2(connectNo, &ret,NULL); REF5010 - SSO - 000828 */
        return ret;
    }
    DATE_STOP_TIMER(2, TIMER_MASK_SQLC);

	/* If PORTFOLIO DIMENSION is a list */
	if (dimObject == List)
	{
		DBA_DYNFLD_STP aList = ALLOC_DYNST(A_List);

		/* Verify memory allocation */
		if (aList == NULL)
		{
            DBA_LoadPosDropTempTables(*dbiConnHelper.getConnection(), DictFct_Valo); /* because we wont drop #port_synth */
            if (DBA_CreateTempTables(*dbiConnHelper.getConnection(), DOM_STRAT) != RET_SUCCEED) /* REF9125 - RAK - 030916 - DOM_STRAT is added */
   			    MSG_LogMesg(
                    RET_GEN_ERR_PERSONAL, 1, FILEINFO,
					    "DBA_CreateTempTables failed");
			return(RET_MEM_ERR_ALLOC);
		}

        listId = GET_ID(domainPtr, A_Domain_PtfObjId);
        SET_ID(aList, A_List_Id, listId);

		/* Get the list record */
        if ((ret = DBA_Get2(List, UNUSED, A_List, aList, A_List, &aList,
                            UNUSED, UNUSED, UNUSED)) != RET_SUCCEED)
		{
			FREE_DYNST(aList, A_List);
            DBA_LoadPosDropTempTables(*dbiConnHelper.getConnection(), DictFct_Valo); /* because we wont drop #port_synth */
            if (DBA_CreateTempTables(*dbiConnHelper.getConnection(), DOM_STRAT) != RET_SUCCEED) /* REF9125 - RAK - 030916 - DOM_STRAT is added */
   			    MSG_LogMesg(
                    RET_GEN_ERR_PERSONAL, 1, FILEINFO,
					    "DBA_CreateTempTables failed");
			return(ret);
		}

		/* If the portfolio list is a constraint list, search list or hierarchical list */
        LISTNAT_ENUM	nature = static_cast <LISTNAT_ENUM> GET_ENUM(aList, A_List_NatEn);
        bool            bUseListCompoTable = true;

		if (nature == ListNat_Constr || nature == ListNat_Search || nature == ListNat_Hierarch)
		{
	        if ((listEntDictId = GET_DICT(aList, A_List_EntityDictId)) == 0)
    		    listObject = NullEntity;
	        else
                DBA_GetObjectEnum(listEntDictId, &listObject);

			/* Insert portfolioes Ids from the Constraint List into #dom_port_synth */
            DBA_CheckConstList(listId, aList, &status);

            switch(status)
            {
                case CHK_LIST_NOT_CONST :
                    /***** NOTHING TO DO *****/
                    break;

                case CHK_LIST_NON_PERIODIC :
				case CHK_LIST_HIER_NON_PERIODIC : /* REF7397 - LJE - 020228 - Add */
                case CHK_LIST_MUST_BE_BUILT :       /* REF7397 - LJE - 020228 - Add */
                case CHK_LIST_HIER_MUST_BE_BUILT : /* REF125 - XDI - 971218 - Add */
                    if (bAllowRebuild)
                    {
                        SetServerUserToOnGuard setServerUserToOn;          /* PMSTA-29656 - DDV - 180110 - This class set ServerUser to On and automatically set to Off when leaving the function */ /* PMSTA-33980 - LJE - 181206 */

                        /***** BUILD ENUM LIST FROM CONSTRAINT SCRIPT *****/
                        ret = SCPT_EvalCstList(CSTLIST_REBUILD_LIST_COMPO,
                                               listId,
                                               NULLSTR,
                                               listObject,
                                               0,
                                               NULLDYNST,
                                               dbiConnHelper.getConnection()->getId(),
                                               (FLAG_T*)NULL,
                                               (DBA_DYNFLD_STP**)NULL,
                                               (int *)NULL,
                                               (DATETIME_STP)NULL,
                                               0,
                                               0); /* PMSTA07422 - DDV - 090520 - Add dataProfId parameter for sel_export_data */

                        /* REF3962 - SSO - 990910 */
                        if (ret != RET_SUCCEED)
                        {
                            FREE_DYNST(aList, A_List);
                            DBA_LoadPosDropTempTables(*dbiConnHelper.getConnection(), DictFct_Valo); /* because we wont drop #port_synth */
                            if (DBA_CreateTempTables(*dbiConnHelper.getConnection(), DOM_STRAT) != RET_SUCCEED) /* REF9125 - RAK - 030916 - DOM_STRAT is added */
                                MSG_LogMesg(
                                    RET_GEN_ERR_PERSONAL, 1, FILEINFO,
                                    "DBA_CreateTempTables failed");
                            return(ret);
                        }

                        /* NO BREAK because of insert is necessary ... */
                    }

                case CHK_LIST_ALREADY_BUILT :

                    bUseListCompoTable = true;
#if 0
                    /***** BUILD dom_port FROM  list_compo & portfolio *****/
                    if ((buffer = (char *)CALLOC(1,2048)) == NULL) /* REF7264 - LJE - 020131 */
                    {
                        FREE_DYNST(aList, A_List);
                        DBA_LoadPosDropTempTables(*dbiConnHelper.getConnection(), DictFct_Valo); /* because we wont drop #port_synth */
                        if (DBA_CreateTempTables(*dbiConnHelper.getConnection(), DOM_STRAT) != RET_SUCCEED) /* REF9125 - RAK - 030916 - DOM_STRAT is added */
   			                MSG_LogMesg(
                                RET_GEN_ERR_PERSONAL, 1, FILEINFO,
					                "DBA_CreateTempTables failed");
                        MSG_RETURN(RET_MEM_ERR_ALLOC);
                    }

                    sprintf(buffer,
                            "insert into #dom_port (id,port_pos_set_id,hier_port_id,fusion_date_rule_e) "  /* PMSTA-20159 - TEB - 150624 */ /*REF10722-BRO-060922*/
							"select lc.object_id, 0, null, 0 " /* MIGR R4.00 STEP6 - LJE - 020816 */
                            "from %s p, %s lc " /* PMSTA-32753 - DLA - 180903 */
                            "where lc.list_id=%" szFormatId" and p.id = lc.object_id and lc.validity_d is null and #MAIN_DLM_CHECK(p, portfolio) ", /* DLA - PMSTA08801 - 100209 */ /* PMSTA-24026 - DDV - 161122 */
                            SCPT_GetViewName(Ptf, false).c_str(),  /* PMSTA-26250  -DDV - 170523 */ /* PMSTA-32753 - DLA - 180903 */
                            SCPT_GetViewName(ListCompo, false).c_str(),  /* PMSTA-26250  -DDV - 170523 */   /* PMSTA-32753 - DLA - 180903 */
                            listId);

	                 dbRet = DBA_SqlExec(buffer, *dbiConnHelper.getConnection());

                    FREE(buffer);
#endif
                    break;
            }
	    }
        else if (nature == ListNat_Enum && bManageEnumList)
        {
            bUseListCompoTable = true;
        }

        if (bUseListCompoTable == true)
        {
            /***** BUILD dom_port FROM  list_compo & portfolio *****/
            if ((buffer = (char *)CALLOC(1,2048)) == NULL) /* REF7264 - LJE - 020131 */
            {
                FREE_DYNST(aList, A_List);
                DBA_LoadPosDropTempTables(*dbiConnHelper.getConnection(), DictFct_Valo); /* because we wont drop #port_synth */
                if (DBA_CreateTempTables(*dbiConnHelper.getConnection(), DOM_STRAT) != RET_SUCCEED) /* REF9125 - RAK - 030916 - DOM_STRAT is added */
   			        MSG_LogMesg(
                        RET_GEN_ERR_PERSONAL, 1, FILEINFO,
					        "DBA_CreateTempTables failed");
                MSG_RETURN(RET_MEM_ERR_ALLOC);
            }

            sprintf(buffer,
                    "insert into #dom_port (id,port_pos_set_id,hier_port_id,fusion_date_rule_e) "  /* PMSTA-20159 - TEB - 150624 */ /*REF10722-BRO-060922*/
					"select lc.object_id, 0, null, 0 " /* MIGR R4.00 STEP6 - LJE - 020816 */
                    "from %s p, %s lc " /* PMSTA-32753 - DLA - 180903 */
                    "where lc.list_id=%" szFormatId" and p.id = lc.object_id and lc.validity_d is null and #MAIN_DLM_CHECK(p, portfolio) ", /* DLA - PMSTA08801 - 100209 */ /* PMSTA-24026 - DDV - 161122 */
                    SCPT_GetViewName(Ptf, false).c_str(),  /* PMSTA-26250  -DDV - 170523 */ /* PMSTA-32753 - DLA - 180903 */
                    SCPT_GetViewName(ListCompo, false).c_str(),  /* PMSTA-26250  -DDV - 170523 */   /* PMSTA-32753 - DLA - 180903 */
                    listId);

	            dbRet = DBA_SqlExec(buffer, *dbiConnHelper.getConnection());

            FREE(buffer);
        }

        FREE_DYNST(aList, A_List);
    }
    else if (dimObject == QuickSearch) /* REF4611 - RAK - 000501 - Quick search in Domain */
    {
		DBA_DYNFLD_STP      tascJobSt=NULL; /* PMSTA08246 - LJE - 090624 */
        DICT_T  entDictId;
        DBA_GetDictId(Ptf, &entDictId);

		/* PMSTA08246 - LJE - 090615 */
		if (IS_NULLFLD(domainPtr, A_Domain_PtfListDef)   == TRUE  &&
			IS_NULLFLD(domainPtr, A_Domain_JobReference) == FALSE)
		{
			if ((tascJobSt = ALLOC_DYNST(A_TascJob)) != NULL  &&
                dbiConnHelper.dbaGet(TascJob, UNUSED, domainPtr, &tascJobSt) == RET_SUCCEED  && /* PMSTA-34200 - LJE - 190111 */
				tascJobSt != NULL                &&
				IS_NULLFLD(tascJobSt, A_TascJob_PortfoliosetTbName) == FALSE)
			{
                DBA_DYNFLD_STP argument =  ALLOC_DYNST(Arg_Test);

                if (argument != NULL)
                {
                    SET_ID(argument, Arg_Test_Id, GET_ID(tascJobSt, A_TascJob_Id)); /* PMSTA-11505 - LJE - 110713 */
                    if (IS_NULLFLD(domainPtr, A_Domain_ChunkNumber) == FALSE)
                        SET_INT(argument, Arg_Test_Int, GET_INT(domainPtr, A_Domain_ChunkNumber));

					SET_ENUM(argument, Arg_Test_Enum, TslJobPtfCompNat_Untreated); /* PMSTA13876 - DDV - 130905 */

				    if ((ret = DBA_Notif2(TascJob,
									    UNUSED,
									    Arg_Test,
									    argument,
									    DBA_SET_CONN|DBA_NO_CLOSE,
										dbiConnHelper,
									    UNUSED)) != RET_SUCCEED)
				    {
            			FREE_DYNST(argument, Arg_Test);
					    FREE_DYNST(tascJobSt, A_TascJob);
                        DBA_LoadPosDropTempTables(*dbiConnHelper.getConnection(), (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
                        if (DBA_CreateTempTables(*dbiConnHelper.getConnection(), DOM_STRAT) != RET_SUCCEED)
   						    MSG_LogMesg(
							    RET_GEN_ERR_PERSONAL, 1, FILEINFO,
								    "DBA_CreateTempTables failed");
					    return(ret);
				    }
                }
			}

			FREE_DYNST(tascJobSt, A_TascJob);
		}
		else
		{
			/* Insert portfolioes Ids from the Quick Search List into #dom_port */
			if ((ret = SERV_ListMgm(ListMgmFct_LoadPos,
									entDictId,
									0,
									GET_STRING(domainPtr, A_Domain_PtfListDef),
                                    *dbiConnHelper.getConnection(),
									nullptr)) != RET_SUCCEED)
			{
				/* REF3751 - SSO - 990623 more ret code tests */
                DBA_LoadPosDropTempTables(*dbiConnHelper.getConnection(), (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
                if (DBA_CreateTempTables(*dbiConnHelper.getConnection(), DOM_STRAT) != RET_SUCCEED) /* REF9125 - RAK - 030916 - DOM_STRAT is added */
   					MSG_LogMesg(
						RET_GEN_ERR_PERSONAL, 1, FILEINFO,
							"DBA_CreateTempTables failed");
				return(ret);
			}
		}
    }
	else if (dimObject == DomainPtfCompo && domainPtr != NULL) /* PMSTA-36175 - PM Profile Phase1 changes - Kramadevi - 02072019*/
	{
        DBA_DYNFLD_STP      tascJobSt = NULL;

        if (GET_ENUM(domainPtr, A_Domain_OutputTpEn) != TSLDimPort &&
            IS_NULLFLD(domainPtr, A_Domain_JobReference) == FALSE)
        {
            if ((tascJobSt = ALLOC_DYNST(A_TascJob)) != NULL &&
                dbiConnHelper.dbaGet(TascJob, UNUSED, domainPtr, &tascJobSt) == RET_SUCCEED &&
                tascJobSt != NULL &&
                IS_NULLFLD(tascJobSt, A_TascJob_PortfoliosetTbName) == FALSE)
            {
                DBA_DYNFLD_STP argument = ALLOC_DYNST(Arg_Test);

                if (argument != NULL)
                {
                    SET_ID(argument, Arg_Test_Id, GET_ID(tascJobSt, A_TascJob_Id));
                    if (IS_NULLFLD(domainPtr, A_Domain_ChunkNumber) == FALSE)
                        SET_INT(argument, Arg_Test_Int, GET_INT(domainPtr, A_Domain_ChunkNumber));
                    SET_ENUM(argument, Arg_Test_Enum, TslJobPtfCompNat_Untreated);

                    if ((ret = DBA_Notif2(TascJob,
                                          UNUSED,
                                          Arg_Test,
                                          argument,
                                          DBA_SET_CONN | DBA_NO_CLOSE,
                                          dbiConnHelper,
                                          UNUSED)) != RET_SUCCEED)
                    {
                        FREE_DYNST(argument, Arg_Test);
                        FREE_DYNST(tascJobSt, A_TascJob);
                        DBA_LoadPosDropTempTables(*dbiConnHelper.getConnection(), (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
                        if (DBA_CreateTempTables(*dbiConnHelper.getConnection(), DOM_STRAT) != RET_SUCCEED)
                            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_CreateTempTables failed");
                        return(ret);
                    }
                    FREE_DYNST(argument, Arg_Test);
                }
            }
            FREE_DYNST(tascJobSt, A_TascJob);
        }
        else
        {
            if ((buffer = (char *)CALLOC(1, 2048)) != NULL)
            {
                sprintf(buffer, "delete from #dom_port ");
                ret = DBA_SqlExec(buffer, *dbiConnHelper.getConnection());

                if (ret == RET_SUCCEED)
                {
                    sprintf(buffer,
                            "insert into #dom_port (id,port_pos_set_id,hier_port_id,fusion_date_rule_e) "
                            "select dpc.portfolio_id, 0, null, 0 "
                            "from %s dpc, %s p "
                            "where dpc.function_result_id=%" szFormatId" and p.id = dpc.portfolio_id ",
                            SCPT_GetViewName(DomainPtfCompo, false).c_str(),
                            SCPT_GetViewName(Ptf, false).c_str(),
                            GET_ID(domainPtr, A_Domain_FctResultId));

                    sprintf(buffer + strlen(buffer), " and #MAIN_DLM_CHECK(p, portfolio)");

                    if ((ret = DBA_SqlExec(buffer, *dbiConnHelper.getConnection())) != RET_SUCCEED)
                    {
                        FREE(buffer);
                        DBA_LoadPosDropTempTables(*dbiConnHelper.getConnection(), (DICT_FCT_ENUM)GET_ID(domainPtr, A_Domain_FctDictId));
                        if (DBA_CreateTempTables(*dbiConnHelper.getConnection(), DOM_STRAT) != RET_SUCCEED)
                            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_CreateTempTables failed");
                        return(ret);
                    }
                }
                FREE(buffer);
            }
        }
	}

    return(ret);
}

/************************************************************************
**   END  dbalib03.c                                           Odyssey **
*************************************************************************/

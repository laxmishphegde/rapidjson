/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef FINLIB13_H
#define FINLIB13_H

#include "scptyl.h"  /* PMSTA-40208 - sanand - 29092020 */

/************************************************************************
**      BEGIN : Global variables & external definitions attached to finlib13.c
*************************************************************************/
#ifdef  EXTERN
#undef  EXTERN
#endif
#ifdef  FINLIB13_C
#define	EXTERN
#else
#define EXTERN extern
#endif

EXTERN RET_CODE   FIN_InsUpdModelConstrData(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP,DBA_DYNFLD_STP, DBA_ACTION_ENUM, int, RETCODEFCT*, PTR, FLAG_T*);
EXTERN RET_CODE   FIN_MceGetMceHist(DBA_HIER_HEAD_STP , DBA_DYNFLD_STP* );
EXTERN RET_CODE   FIN_MceNewMceHist(DBA_HIER_HEAD_STP    stratHierPtr, DBA_DYNFLD_STP       modMCPtr);
EXTERN RET_CODE   FIN_SelDispModelConstrElt(DBA_HIER_HEAD_STP , DBA_DYNFLD_STP**, int*);
EXTERN RET_CODE   FIN_StratInsDbModelConstrElt(PTR ,DBA_DYNFLD_STP ,DBA_DYNST_ENUM,OBJECT_ENUM ,int ,int*, DBA_ERRMSG_INFOS_STP);
EXTERN RET_CODE   FIN_AccountingRuleCompoLookup(ID_T instrumentId, ID_T portfolioId, DATE_T date, DBA_DYNFLD_STP* result);
EXTERN bool       FIN_IsTradableInstrument(DBA_HIER_HEAD_STP, ID_T); /* PMSTA-32131 - DLA - 180731 */

/* PMSTA - 38314 - sanand - 29012020 */
EXTERN RET_CODE FIN_GetMininumTradingQty(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, NUMBER_T*, AMOUNT_T);
EXTERN RET_CODE FIN_NetOrders(int, DBA_DYNFLD_STP *, DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, int);
EXTERN RET_CODE FIN_SortExtOperationByInsrtIdAndQty(DBA_DYNFLD_STP*, DBA_DYNFLD_STP*);
/* PMSTA-40208 - sanand - 27092020 */
EXTERN RET_CODE FIN_GroupOrdersByHierarchy(int, DBA_DYNFLD_STP *, DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, int , DICT_FCT_STP, DICT_FCT_STP , SCPT_FMTDATADEF_STP);
RET_CODE FIN_autoHierGroupOrder(DBA_HIER_HEAD_STP hierHead, DBA_DYNFLD_STP  domainPtr, DICT_T intitialFctDictId, DICT_FCT_STP pdictfctOrigin,
    DBA_DYNFLD_STP	*caseMgtTab, int caseMgtNbr, EXTOP_ACTION_ENUM	actionEn, bool  splitSessionFlag);

EXTERN RET_CODE createHierExecution(OBJECT_ENUM object, DBA_DYNST_ENUM inputSt, DBA_DYNFLD_STP aExecution, DbiConnectionHelper& dbiConnHelper);

#endif /* FINLIB13_H */

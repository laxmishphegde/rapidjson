/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DDLGENDBI_CPP

/************************************************************************
**      Include files
*************************************************************************/
#include           <string.h>

#include           "unidef.h"     /* Mandatory */
#include              "gen.h"
#include              "dba.h"
#include              "syb.h"
#include        "ddlgendbi.h"
#include       "ddlgenfile.h"
#include           "ddlgen.h"
#include        "ddlgenvar.h"
#include      "ddlgentable.h"
#include   "ddlgenfromfile.h"
#include    "dbiconnection.h"
#include          <algorithm>
#include                <set>
#include            <iomanip>

#define TAG_CONVERT           "CONVERT"

using namespace std;

/************************************************************************
**      External entry points
**
*************************************************************************/
extern bool                 EV_UseAlternativeDataSource;
extern DdlGenCfgFile       *EV_TargetCfgFile;
extern DdlGenCfgFile       *EV_SourceCfgFile;

/************************************************************************
**      Local functions
**
*************************************************************************/

/************************************************************************
**      Static definitions & data
**
*************************************************************************/
static string isNotFirstSqlName = "'0123456789";

/************************************************************************
**      METHODS
**
************************************************************************/

/************************************************************************
**
**  Function    :   DdlObjDefKey::DdlObjDefKey()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
DdlObjDefKey::DdlObjDefKey(DBA_RDBMS_ENUM rdbmsEn)
    : m_rdbmsEn(rdbmsEn)
    , m_ddlObjEn(DdlObj_None)
    , m_dictEntityStp(nullptr)

{
}

/************************************************************************
**
**  Function    :   DdlObjDefKey::DdlObjDefKey()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
DdlObjDefKey::DdlObjDefKey(DBA_RDBMS_ENUM      rdbmsEn,
                           DDL_OBJ_ENUM        ddlObjEn,
                           const std::string& dbName,
                           const std::string& entity,
                           const std::string& table,
                           const std::string& objName)
    : DdlObjDefKey(rdbmsEn)
{
    this->m_ddlObjEn  = (ddlObjEn == DdlObj_SpecSProc ? DdlObj_SProc : ddlObjEn);
    this->m_dbName    = dbName;
    this->m_dbDbName  = dbName;
    this->m_objName   = objName;
    this->m_dbObjName = objName;
    this->m_entity    = entity;
    this->m_table     = table;

    if (this->m_table.empty() && this->m_entity.empty() == false)
    {
        this->m_dictEntityStp = DBA_GetEntityBySqlName(this->m_entity);

        if (this->m_dictEntityStp != nullptr)
        {
            this->m_table = this->m_dictEntityStp->dbSqlName;
        }
        else
        {
            this->m_table = this->m_entity;
        }
    }

    if (this->m_ddlObjEn == DdlObj_SProc ||
        this->m_ddlObjEn == DdlObj_Func ||
        this->m_ddlObjEn == DdlObj_View)
    {
        this->m_table.clear();
    }

    DdlGenDbi::standardize(this->m_dbObjName, rdbmsEn);
    DdlGenDbi::standardize(this->m_table, rdbmsEn);
    DdlGenDbi::standardize(this->m_dbDbName, rdbmsEn);
}

/************************************************************************
**
**  Function    :   DdlObjDefKey::DdlObjDefKey()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
DdlObjDefKey::DdlObjDefKey(DBA_RDBMS_ENUM      rdbmsEn,
                           DDL_OBJ_ENUM        ddlObjEn,
                           DICT_ENTITY_STP     dictEntityStp,
                           const std::string&  objName)
    : DdlObjDefKey(rdbmsEn)
{
    this->m_ddlObjEn      = (ddlObjEn == DdlObj_SpecSProc ? DdlObj_SProc : ddlObjEn);
    this->m_dictEntityStp = dictEntityStp;

    if (this->m_dictEntityStp != nullptr)
    {
        this->m_dbName   = this->m_dictEntityStp->databaseName;
        this->m_dbDbName = this->m_dbName;
        this->m_entity   = this->m_dictEntityStp->mdSqlName;
        this->m_table    = this->m_dictEntityStp->dbSqlName;
    }
    this->m_objName   = objName;
    this->m_dbObjName = objName;

    if (this->m_ddlObjEn == DdlObj_SProc || 
        this->m_ddlObjEn == DdlObj_Func ||
        this->m_ddlObjEn == DdlObj_View)
    {
        this->m_entity.clear();
    }

    DdlGenDbi::standardize(this->m_dbObjName, rdbmsEn);
    DdlGenDbi::standardize(this->m_table, rdbmsEn);
    DdlGenDbi::standardize(this->m_dbDbName, rdbmsEn);
}

/************************************************************************
**
**  Function    :   DdlObjDefKey::DdlObjDefKey()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
DdlObjDefKey::~DdlObjDefKey()
{
}

/************************************************************************
**
**  Function    :   DdlObjDefKey::DdlObjDefKey()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
DdlObjDefKey::DdlObjDefKey(const DdlObjDefKey& ref)
{
    *this = ref;
}

/************************************************************************
**
**  Function    :   DdlObjDefKey::operator=()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
DdlObjDefKey& DdlObjDefKey::operator=(const DdlObjDefKey& toCopy)
{
    this->m_rdbmsEn       = toCopy.m_rdbmsEn;
    this->m_ddlObjEn      = toCopy.m_ddlObjEn;
    this->m_dbName        = toCopy.m_dbName;
    this->m_dbDbName      = toCopy.m_dbDbName;
    this->m_entity        = toCopy.m_entity;
    this->m_table         = toCopy.m_table;
    this->m_objName       = toCopy.m_objName;
    this->m_dbObjName     = toCopy.m_dbObjName;
    this->m_dictEntityStp = toCopy.m_dictEntityStp;

    return *this;
}

/************************************************************************
**
**  Function    :   DdlObjDefKey::operator==()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
bool DdlObjDefKey::operator==(const DdlObjDefKey& a) const
{
    if (this->m_ddlObjEn != a.m_ddlObjEn)
    {
        return false;
    }

    if (strcasecmp(this->m_dbName.c_str(), a.m_dbName.c_str()) != 0)
    {
        return false;
    }

    switch (this->m_ddlObjEn)
    {
        case DdlObj_Table:
        case DdlObj_TempTable:
        case DdlObj_PrimaryKey:
            return strcasecmp(this->m_table.c_str(), a.m_table.c_str()) == 0;

        default:
            return strcasecmp(this->m_objName.c_str(), a.m_objName.c_str()) == 0;

    }
}

/************************************************************************
**
**  Function    :   DdlObjDefKey::operator<
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
bool DdlObjDefKey::operator<(const DdlObjDefKey& a) const
{
    if (this->m_ddlObjEn < a.m_ddlObjEn)
    {
        return true;
    }

    if (this->m_ddlObjEn > a.m_ddlObjEn)
    {
        return false;
    }

    int cmp = strcasecmp(this->m_dbName.c_str(), a.m_dbName.c_str());
    if (cmp < 0)
    {
        return true;
    }

    if (cmp > 0)
    {
        return false;
    }

    switch (this->m_ddlObjEn)
    {
        case DdlObj_Table:
        case DdlObj_TempTable:
        case DdlObj_PrimaryKey:
            cmp = strcasecmp(this->m_table.c_str(), a.m_table.c_str());
            if (cmp < 0)
            {
                return true;
            }

            if (cmp > 0)
            {
                return false;
            }
            break;

        default:
            cmp = strcasecmp(this->m_objName.c_str(), a.m_objName.c_str());
            if (cmp < 0)
            {
                return true;
            }

            if (cmp > 0)
            {
                return false;
            }
            break;

    }

    return false;
}

/************************************************************************
**
**  Function    :   DdlObjDefKey::getDdlObjEn()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
DDL_OBJ_ENUM DdlObjDefKey::getDdlObjEn() const
{
    return this->m_ddlObjEn;
}

/************************************************************************
**
**  Function    :   DdlObjDefKey::getDbName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
const std::string& DdlObjDefKey::getDbName() const
{
    return this->m_dbName;
}

/************************************************************************
**
**  Function    :   DdlObjDefKey::getDbDbName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
const std::string& DdlObjDefKey::getDbDbName() const
{
    return this->m_dbDbName;
}

/************************************************************************
**
**  Function    :   DdlObjDefKey::getObjName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
const std::string& DdlObjDefKey::getObjName() const
{
    return this->m_objName;
}

/************************************************************************
**
**  Function    :   DdlObjDef::getEntitySqlName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
const std::string& DdlObjDefKey::getEntitySqlName() const
{
    return this->m_entity;
}

/************************************************************************
**
**  Function    :   DdlObjDefKey::getTableSqlName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
const std::string& DdlObjDefKey::getTableSqlName() const
{
    return this->m_table;
}


/************************************************************************
**
**  Function    :   DdlObjDefKey::getDbObjName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
const std::string& DdlObjDefKey::getDbObjName() const
{
    return this->m_dbObjName;
}

/************************************************************************
**
**  Function    :   DdlObjDefKey::getDictEntityStp()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
DICT_ENTITY_STP DdlObjDefKey::getDictEntityStp()
{
    if (this->m_dictEntityStp == nullptr)
    {
        this->m_dictEntityStp = DBA_GetEntityBySqlName(this->getEntitySqlName());

        if (this->m_dictEntityStp == nullptr)
        {
            this->m_dictEntityStp = DBA_GetEntityBySqlName(this->getTableSqlName());

            if (this->m_dictEntityStp == nullptr)
            {
                this->m_dictEntityStp = DBA_GetEntityBySqlName(this->getObjName());

                if (this->m_dictEntityStp == nullptr)
                {
                    this->m_dictEntityStp = DBA_GetEntityBySqlName(this->getDbObjName());

                    if (this->m_dictEntityStp == nullptr)
                    {
                        this->m_dictEntityStp = DICT_GetDictEntityVector()[static_cast<unsigned int>(InvalidEntity)];
                    }
                }
            }
        }
    }
    return this->m_dictEntityStp;
}

/************************************************************************
**
**  Function    :   DdlObjDef::DdlObjDef()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
DdlObjDef::DdlObjDef(DBA_RDBMS_ENUM      rdbmsEn,
                     DDL_OBJ_ENUM        ddlObjEn,
                     const std::string& dbName,
                     const std::string& entity,
                     const std::string& table,
                     const std::string& objName)
    : DdlObjDefKey(rdbmsEn, ddlObjEn, dbName, entity, table, objName)
    , m_refDeleteRuleEn(RefDelRule_None)
    , m_bValidated(true)
    , m_bTreated(false)
    , m_isPrimary(false)
    , m_isClustered(false)
    , m_outFileLinePos(0)
    , m_bSendIntoDb(false)
    , m_bSaved(false)
    , m_ddlgenObjectStp(nullptr)
{
}

/************************************************************************
**
**  Function    :   DdlObjDef::DdlObjDef()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
DdlObjDef::DdlObjDef(DBA_RDBMS_ENUM      rdbmsEn,
                     DDL_OBJ_ENUM        ddlObjEn,
                     DICT_ENTITY_STP     dictEntityStp,
                     const std::string& objName)
    : DdlObjDefKey(rdbmsEn, ddlObjEn, dictEntityStp, objName)
    , m_refDeleteRuleEn(RefDelRule_None)
    , m_bValidated(true)
    , m_bTreated(false)
    , m_isPrimary(false)
    , m_isClustered(false)
    , m_outFileLinePos(0)
    , m_bSendIntoDb(false)
    , m_bSaved(false)
    , m_ddlgenObjectStp(nullptr)
{
}

/************************************************************************
**
**  Function    :   DdlObjDef::DdlObjDef()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
DdlObjDef::~DdlObjDef()
{
}

/************************************************************************
**
**  Function    :   DdlObjDef::DdlObjDef()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
DdlObjDef::DdlObjDef(const DdlObjDef& ref)
    : DdlObjDef(ref.m_rdbmsEn, ref.getDdlObjEn(), ref.getDbName(), ref.getEntitySqlName(), ref.getTableSqlName(), ref.getObjName())
{
    *this = ref;
}

/************************************************************************
**
**  Function    :   DdlObjDef::operator=()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
DdlObjDef& DdlObjDef::operator=(const DdlObjDef& toCopy)
{
    DdlObjDefKey::operator=(toCopy);

    this->m_refEntity        = toCopy.m_refEntity;
    this->m_refAttributeTab  = toCopy.m_refAttributeTab;
    this->m_searchCondition  = toCopy.m_searchCondition;
    this->m_refDeleteRuleEn  = toCopy.m_refDeleteRuleEn;
    this->m_bValidated       = toCopy.m_bValidated;
    this->m_bTreated         = toCopy.m_bTreated;
    this->m_dropCmdTab       = toCopy.m_dropCmdTab;
    this->m_dropParamTab     = toCopy.m_dropParamTab;
    this->m_bodyStr          = toCopy.m_bodyStr;
    this->m_grantCmdTab      = toCopy.m_grantCmdTab;
    this->m_dictSprocSt      = toCopy.m_dictSprocSt;
    this->m_dependsEntityMap = toCopy.m_dependsEntityMap;
    this->m_dependsSprocSet  = toCopy.m_dependsSprocSet;
    this->m_dependsAccessSet = toCopy.m_dependsAccessSet;
    this->m_outputFileStr    = toCopy.m_outputFileStr;
    this->m_outFileLinePos   = toCopy.m_outFileLinePos;
    this->m_bSaved           = toCopy.m_bSaved;
    this->m_ddlgenObjectStp  = toCopy.m_ddlgenObjectStp;

    return *this;
}

/************************************************************************
**
**  Function    :   DdlObjDef::check()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
bool DdlObjDef::check()
{
    switch (this->getDdlObjEn())
    {
        case DdlObj_PrimaryKey:
        {
            if (this->getDictEntityStp()->dbPKNbr == static_cast<int>(this->m_refAttributeTab.size()))
            {
                for (int i = 0; i < this->getDictEntityStp()->dbPKNbr; i++)
                {
                    if (strcasecmp(this->m_refAttributeTab[i].c_str(), this->getDictEntityStp()->dbPKTab[i]->sqlName) != 0)
                    {
                        return false;
                    }
                }
                return true;
            }
            /* PMSTA-36158 - LJE - 190627 */
            else if (this->getDictEntityStp()->objectEn == InvalidEntity &&
                     this->m_refAttributeTab.size() == 1 &&
                     (this->m_refAttributeTab[0].compare(DdlGen::getUdIdSqlName()) == 0 ||
                      this->m_refAttributeTab[0].compare(DdlGen::getXIdSqlName()) == 0))
            {
                return true;
            }
            return false;
        }
        break;

        default:
            return true;
    }
}

/************************************************************************
**
**  Function    :   DdlObjDef::getDdlgenObjectStp()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
DBA_DYNFLD_STP DdlObjDef::getDdlgenObjectStp()
{
    if (this->m_ddlgenObjectStp == nullptr)
    {
        this->m_ddlgenObjectStp = this->m_mp.allocDynst(FILEINFO, A_DdlgenObject);
    }

    SET_NULL_DYNST(this->m_ddlgenObjectStp, A_DdlgenObject);
    SET_SYSNAME(this->m_ddlgenObjectStp, A_DdlgenObject_SqlName, this->getObjName().c_str());
    SET_ENUM(this->m_ddlgenObjectStp, A_DdlgenObject_DdlObjEn, this->getDdlObjEn());
    SET_SYSNAME(this->m_ddlgenObjectStp, A_DdlgenObject_Database, this->getDbName().c_str());
    SET_SYSNAME(this->m_ddlgenObjectStp, A_DdlgenObject_Entity, this->getEntitySqlName().c_str());

    return this->m_ddlgenObjectStp;
}

/************************************************************************
**
**  Function    :   DdlGenDependKey::DdlGenDependKey()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
DdlGenDependKey::DdlGenDependKey(DICT_T dictId, std::string sqlName, DictDependsAccessEn accessEn, DBA_DYNTYPE_ENUM dynTypeEn)
    : m_dictId(dictId)
    , m_sqlName(sqlName)
    , m_accessEn(accessEn)
    , m_dynTypeEn(dynTypeEn)
    , m_objectEn(InvalidEntity)
    , m_dynStEn(InvalidDynSt)
{
    if (dynTypeEn >= DynType_NotMD)
    {
        SYS_BreakOnDebug();
    }

    DBA_GetObjectEnum(this->m_dictId, &this->m_objectEn);

    if (this->m_objectEn != NullEntity)
    {
        if (this->m_accessEn == DictDependsAccessEn::Returns)
        {
            if (this->m_dynTypeEn == DynType_All)
            {
                this->m_dynStEn = GET_EDITGUIST(this->m_objectEn);
            }
            else if (this->m_dynTypeEn == DynType_Short)
            {
                this->m_dynStEn = GET_ADMINGUIST(this->m_objectEn);
            }
            else
            {
                this->m_dynTypeEn = DynType_Other;
                this->m_dynStEn = NullDynSt;
            }
        }
    }
    else
    {
        this->m_objectEn = InvalidEntity;
    }
}

/************************************************************************
**
**  Function    :   DdlGenWhereDep::DdlGenWhereDep()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
DdlGenWhereDep::DdlGenWhereDep(const std::string& paramLeftStr,
                               const DICT_ATTRIB_STP paramLeftAttribStp,
                               const std::string& paramRightStr,
                               const DICT_ATTRIB_STP paramRightAttribStp,
                               const std::string& paramOperStr,
                               DdlGenDbi& refDdlGenDbi)
    : leftStr(paramLeftStr)
    , leftAttribStp(paramLeftAttribStp)
    , rightStr(paramRightStr)
    , rightAttribStp(paramRightAttribStp)
    , operStr(paramOperStr)
    , mainObjAttribStp(nullptr)
    , m_refDdlGenDbi(refDdlGenDbi)
{
    if (this->leftAttribStp != NULL)
    {
        size_t pos = this->leftStr.find(".");
        if (pos != string::npos)
        {
            this->leftAliasStr = this->leftStr.substr(0, pos);
        }
        if (this->leftStr.find(this->m_refDdlGenDbi.getNewPrefix()) == 0 ||
            this->leftStr.find(this->m_refDdlGenDbi.getOldPrefix()) == 0)
        {
            this->mainObjAttribStp = this->leftAttribStp;
        }
    }
    if (this->rightAttribStp != NULL)
    {
        size_t pos = this->rightStr.find(".");
        if (pos != string::npos)
        {
            this->rightAliasStr = this->rightStr.substr(0, pos);
        }
        if (this->rightStr.find(this->m_refDdlGenDbi.getNewPrefix()) == 0 ||
            this->rightStr.find(this->m_refDdlGenDbi.getOldPrefix()) == 0)
        {
            this->mainObjAttribStp = this->rightAttribStp;
        }
    }
}

/************************************************************************
**
**  Function    :   DdlGenWhereDep::DdlGenWhereDep()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
DdlGenWhereDep::DdlGenWhereDep(const DdlGenWhereDep& paramDdlGenWhereDep) :DdlGenWhereDep(paramDdlGenWhereDep.leftStr,
                                                                                          paramDdlGenWhereDep.leftAttribStp,
                                                                                          paramDdlGenWhereDep.rightStr,
                                                                                          paramDdlGenWhereDep.rightAttribStp,
                                                                                          paramDdlGenWhereDep.operStr,
                                                                                          paramDdlGenWhereDep.m_refDdlGenDbi)
{
}

/************************************************************************
**
**  Function    :   DdlGenDbi::DdlGenDbi()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
DdlGenDbi::DdlGenDbi(DDL_OBJ_ENUM       paramDdlObjEn,
                     DdlGenContext& paramDdlGenContext,
                     DdlGenVarHelper* paramVarHelperPtr,
                     DdlGenFile* paramFileHelper,
                     TARGET_TABLE_ENUM  paramTargetTableEn)
    : DdlGenMsg(&paramDdlGenContext)
    , bNestedRequest(false)
    , bUnion(false)
    , bLocalVarHelper(false)
    , varHelperPtr(paramVarHelperPtr)
    , fileHelper(nullptr)
    , targetTableEn(paramTargetTableEn)
    , recurseEndCpt(0)
    , cmdType(DDlCmdType_None)
    , m_startValue(0)
    , m_bCustInView(false)
{
    if (paramDdlGenContext.bWriteFile)
    {
        this->fileHelper = paramFileHelper;
    }
    this->indentNbr = 0;
    this->m_ddlObjEn = DdlObj_None;
    this->elseIfCpt = 0;

    this->setDdlObjEn(paramDdlObjEn);

    if (this->varHelperPtr == nullptr)
    {
        this->varHelperPtr = new DdlGenVarHelper(this, nullptr);
        this->bLocalVarHelper = true;
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::~DdlGenDbi()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
DdlGenDbi::~DdlGenDbi()
{
    if (this->bLocalVarHelper)
    {
        delete this->varHelperPtr;
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getIndent()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
string DdlGenDbi::getIndent()
{
    return this->indentStr;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getIndentNbr()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
int DdlGenDbi::getIndentNbr() const
{
    return this->indentNbr;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getIndent()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
string DdlGenDbi::getIndented(std::stringstream& streamToIdent)
{
    std::stringstream outStream;
    std::string       strLine;

    streamToIdent.clear();
    streamToIdent.seekg(0, ios::beg);

    while (std::getline(streamToIdent, strLine))
    {
        outStream << this->getIndent() << strLine << std::endl;
    }
    return outStream.str();
}

/************************************************************************
**
**  Function    :   DdlGenDbi::newLine()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
string DdlGenDbi::newLine()
{
    return "\n" + this->indentStr;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::clearIndent()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
void DdlGenDbi::clearIndent()
{
    this->indentNbr = 0;
    this->indentStr = this->preIndentStr;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::setIndent()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
void DdlGenDbi::setIndent(int offset)
{
    this->indentNbr += offset;
    if (this->indentNbr < 0)
        this->indentNbr = 0;

    this->indentStr = this->preIndentStr;

    for (int i = 0; i < this->indentNbr; i++)
    {
        this->indentStr.append("    ");
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::setPreIndent()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
void DdlGenDbi::setPreIndent(string preIndent)
{
    this->preIndentStr = preIndent;
    this->clearIndent();
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getPreIndent()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
std::string DdlGenDbi::getPreIndent() const
{
    return this->preIndentStr;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::setAlias()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
void DdlGenDbi::setAlias(const char* newAlias)
{
    this->setAlias(std::string(newAlias));
}

/************************************************************************
**
**  Function    :   DdlGenDbi::setAlias()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
void DdlGenDbi::setAlias(const string& newAlias)
{
    this->alias = newAlias;

    if (!this->alias.empty() &&
        this->alias.at(this->alias.size() - 1) != '.')
    {
        this->alias.append(".");
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getAlias()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
string DdlGenDbi::getAlias(bool bInFrom) const
{
    if (bInFrom)
    {
        /* Remove the . in the end */
        if (this->alias.empty() == false)
        {
            return this->alias.substr(0, this->alias.find_first_of("."));
        }
    }
    return this->alias;
}

/************************************************************************
**
**  Function    : DdlGenDbi::convertDateVar()
**
**  Description : date conversion functions for oracle and nuodb if sybase style number
**               is included in #CONVERT function
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::convertDateVar(DATATYPE_ENUM outDataTypeEn, string toConvertStr, string styleStr)
{
    int styleEnum = atoi(styleStr.c_str());
    const bool bToString = IS_STRING_TYPE(outDataTypeEn);
    string funcPrefix;

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case MSSql:
            /* handled already */
            break;

        case Oracle:
            funcPrefix = bToString ? "TO_CHAR(" : "TO_DATE(";
            switch (styleEnum)
            {
                case DateStyle_MmDdYy:
                    return funcPrefix + toConvertStr + ", 'mm/dd/yyyy')";
                case DateStyle_DdMmYy:
                    return funcPrefix + toConvertStr + ", 'dd/mm/yyyy')";
                case DateStyle_DdMmYyyyDash:
                    return funcPrefix + toConvertStr + ", 'dd-mm-yyyy')";
                case DateStyle_DdMonYyyy:
                    return funcPrefix + toConvertStr + ", 'dd mon yyyy')";
                case DateStyle_YyyyMmDd:
                    return funcPrefix + toConvertStr + ", 'yyyy/mm/dd')";
                default:
                    if (bToString)
                    {
                        return funcPrefix + toConvertStr + ")";
                    }
                    break;
            }
        case Nuodb:
            funcPrefix = bToString ? "DATE_TO_STR(" : "DATE_FROM_STR(";
            switch (styleEnum)
            {
                case DateStyle_MmDdYy:
                    return funcPrefix + toConvertStr + ", 'MM/dd/yyyy')";
                case DateStyle_DdMmYy:
                    return funcPrefix + toConvertStr + ", 'dd/MM/yyyy')";
                case DateStyle_DdMmYyyyDash:
                    return funcPrefix + toConvertStr + ", 'dd-MM-yyyy')";
                case DateStyle_DdMonYyyy:
                    return funcPrefix + toConvertStr + ", 'dd MMM yyyy')";
                case DateStyle_YyyyMmDd:
                    return funcPrefix + toConvertStr + ", 'yyyy/MM/dd')";
                default:
                    return this->convert(outDataTypeEn, toConvertStr, false);
            }

        case PostgreSQL:
            funcPrefix = bToString ? "to_char(" : "to_date(";
            switch (styleEnum)
            {
                case DateStyle_MmDdYy:
                    return funcPrefix + toConvertStr + ", 'MM/DD/YYYY')";
                case DateStyle_DdMmYy:
                    return funcPrefix + toConvertStr + ", 'DD/MM/YYYY')";
                case DateStyle_DdMmYyyyDash:
                    return funcPrefix + toConvertStr + ", 'DD-MM-YYYY')";
                case DateStyle_DdMonYyyy:
                    return funcPrefix + toConvertStr + ", 'DD Mon YYYY')";
                case DateStyle_YyyyMmDd:
                    return funcPrefix + toConvertStr + ", 'YYYY/MM/DD')";
                default:
                    if (bToString)
                    {
                        return funcPrefix + toConvertStr + ")";
                    }
                    break;
            }

        default:
            SYS_BreakOnDebug();
    }
    return toConvertStr;
}

/************************************************************************
**
**  Function    : DdlGenDbi::convertVar()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::convertVar(DATATYPE_ENUM outDataTypeEn, string toConvertStr, string styleStr)
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case MSSql:
        {
            stringstream outStream;
            outStream << "convert(" << this->getDataTypeSqlName(outDataTypeEn) << ", " << toConvertStr << (styleStr.empty() ? "" : ", " + styleStr) << ")";
            return outStream.str();
        }

        case Oracle:
            if (IS_STRING_TYPE(outDataTypeEn) && styleStr.empty())
            {
                return "TO_CHAR(" + toConvertStr + ")";
            }
            if ((outDataTypeEn == DateType || outDataTypeEn == DatetimeType || IS_STRING_TYPE(outDataTypeEn)) && styleStr.empty() == false)
            {
                return convertDateVar(outDataTypeEn, toConvertStr, styleStr);
            }
            break;

        case Nuodb:
            if ((outDataTypeEn == DateType || outDataTypeEn == DatetimeType || IS_STRING_TYPE(outDataTypeEn)) && styleStr.empty() == false)
            {
                return convertDateVar(outDataTypeEn, toConvertStr, styleStr);
            }
            return this->convert(outDataTypeEn, toConvertStr, false);

        case PostgreSQL:
            if ((outDataTypeEn == DateType || outDataTypeEn == DatetimeType || IS_STRING_TYPE(outDataTypeEn)) && styleStr.empty() == false)
            {
                return convertDateVar(outDataTypeEn, toConvertStr, styleStr);
            }
            return this->convert(outDataTypeEn, toConvertStr, false);

        default:
            SYS_BreakOnDebug();

    }

    return toConvertStr;
}

/************************************************************************
**
**  Function    : DdlGenDbi::Convert()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::convert(DATATYPE_ENUM outDataTypeEn, const std::string& toConvertStr, DBA_RDBMS_ENUM rdbmsEn, DDL_OBJ_ENUM ddlObjEn, bool bNull)
{
    stringstream outStream;

    switch (rdbmsEn)
    {
        case Sybase:
            outStream << "convert(" << DdlGenDbi::getDataTypeSqlName(outDataTypeEn, rdbmsEn) << (bNull ? " null" : "") << ", " << toConvertStr << ")";
            return outStream.str();
            break;

        case Oracle:
        case Nuodb:
        case Sqlite:
            if (ddlObjEn != DdlObj_RuntimeSql ||
                outDataTypeEn != TextType ||
                toConvertStr != "null")
            {
                outStream << "cast(" << toConvertStr << " as " << DdlGenDbi::getDataTypeSqlName(outDataTypeEn, rdbmsEn) << ")";
            }
            else
            {
                outStream << toConvertStr;
            }
            return outStream.str();
            break;

        case MSSql:
            outStream << "convert(" << DdlGenDbi::getDataTypeSqlName(outDataTypeEn, rdbmsEn) << ", " << toConvertStr << ")";
            return outStream.str();
            break;

        case PostgreSQL:

            if (strcasecmp(toConvertStr.c_str(), "null") == 0)
            {
                outStream << "NULL::" << DdlGenDbi::getDataTypeSqlName(outDataTypeEn, rdbmsEn);
            }
            else if (ddlObjEn != DdlObj_RuntimeSql ||
                outDataTypeEn != TextType)
            {
                outStream << "(" << toConvertStr << ")::" << DdlGenDbi::getDataTypeSqlName(outDataTypeEn, rdbmsEn);
            }
            else
            {
                outStream << toConvertStr;
            }
            return outStream.str();
            break;

        case QtHttp:
            break;
        default:
            SYS_BreakOnDebug();
    }

    return string();
}

/************************************************************************
**
**  Function    : DdlGenDbi::Convert()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::convert(DATATYPE_ENUM outDataTypeEn, const std::string& toConvertStr, bool bNull)
{
    return DdlGenDbi::convert(outDataTypeEn, toConvertStr, this->ddlGenContextPtr->m_rdbmsEn, this->getDdlObjEn(), bNull);
}

/************************************************************************
**
**  Function    : DdlGenDbi::getCmdDataProfileId()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdDataProfileId(bool bConvert)
{
    if (bConvert)
    {
        return this->convert(IdType, this->getCmdGetAppContext("TASC_CONTEXT", "data_profile_id"), true);
    }
    return this->getCmdGetAppContext("TASC_CONTEXT", "data_profile_id");
}

/************************************************************************
**
**  Function    : DdlGenDbi::getCmdDataProfileIdUser()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdDataProfileIdUser()
{
    return this->convert(IdType, this->getCmdGetAppContext("TASC_CONTEXT", "data_profile_id_user"), true);
}

/************************************************************************
**
**  Function    : DdlGenDbi::getCmdLanguageDictId()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdLanguageDictId()
{
    return this->convert(IdType, this->getCmdGetAppContext("TASC_CONTEXT", "language_dict_id"), true);
}

/************************************************************************
**
**  Function    : DdlGenDbi::getCmdThirdPartyId()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdThirdPartyId()
{
    return this->convert(IdType, this->getCmdGetAppContext("TASC_CONTEXT", "third_party_id"), true);
}

/************************************************************************
**
**  Function    :   DdlGen::getCurrentBusinessEntity()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-32233 - LJE - 180726
**
*************************************************************************/
const std::string DdlGenDbi::getCurrentBusinessEntity()
{
    return this->getDbo() + "get_default_business_entity()";
}

/************************************************************************
**
**  Function    : DdlGenDbi::getCmdConnBusinessEntityId()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
const string DdlGenDbi::getCmdConnBusinessEntityId()
{
    if (this->ddlGenContextPtr->getMultiEntityLevel() > MultiEntityLevel_NoActive)
    {
        if (this->ddlGenContextPtr->getDdlGenMode() == DdlGenMode_MultiEntity)
        {
            return this->convert(IdType, this->getCmdGetAppContext("TASC_CONTEXT", "connected_business_entity_id"), true);
        }
        else
        {
            return "coalesce(" + this->convert(IdType, this->getCmdGetAppContext("TASC_CONTEXT", "connected_business_entity_id"), true) + ", " + this->getCurrentBusinessEntity() + ")";
        }
    }
    else
    {
        return this->ddlGenContextPtr->getMasterBusinessEntityId();
    }
}

/************************************************************************
**
**  Function    : DdlGenDbi::getChangeSetId()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getChangeSetId(bool bConvert)
{
    if (bConvert)
    {
        return this->convert(IdType, this->getCmdGetAppContext("TASC_CONTEXT", "change_set_id"), true);
    }
    return this->getCmdGetAppContext("TASC_CONTEXT", "change_set_id");
}

/************************************************************************
**
**  Function    :  DdlGenDbi::rmChangeSetId()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :
**
*************************************************************************/
string DdlGenDbi::rmChangeSetId()
{
    return this->getCmdRmAppContext("TASC_CONTEXT", "change_set_id");
}

/************************************************************************
**
**  Function    :  DdlGenDbi::setChangeSetId()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :
**
*************************************************************************/
string DdlGenDbi::setChangeSetId(const string& varName)
{
    return this->getCmdSetAppContext("TASC_CONTEXT", "change_set_id", "@" + varName);
}

/************************************************************************
**
**  Function    :  DdlGenDbi::getCollation()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :
**
*************************************************************************/
string DdlGenDbi::getCollation(DATATYPE_ENUM dataTypeEn)
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case Oracle:
        case Nuodb:
        case MSSql:
        case QtHttp:
        case Sqlite:
            break;

        case PostgreSQL:
            if (GET_CTYPE(dataTypeEn) == CharPtrCType ||
                GET_CTYPE(dataTypeEn) == CharPtrCType)
            {
                return "default"; // "C.utf8";
            }
            break;

        default:
            SYS_BreakOnDebug();
    }

    return string();
}

/************************************************************************
**
**  Function    :  DdlGenDbi::rmRootEntity()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-21197 - LJE - 160415
**
*************************************************************************/
string DdlGenDbi::rmRootEntity()
{
    return this->getCmdRmAppContext("TASC_CONTEXT", "root_entity");
}

/************************************************************************
**
**  Function    :  DdlGenDbi::setRootEntity()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-21197 - LJE - 160415
**
*************************************************************************/
string DdlGenDbi::setRootEntity(DICT_T entDictId)
{
    char dictIdStr[22];

    sprintf(dictIdStr, "%" szFormatId, entDictId);

    return this->getCmdSetAppContext("TASC_CONTEXT", "root_entity", dictIdStr);
}

/************************************************************************
**
**  Function    :  DdlGenDbi::geCmdAddDlmEMax()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-21197 - LJE - 160415
**
*************************************************************************/
string DdlGenDbi::geCmdAddDlmEMax()
{
    return "coalesce (" + this->convert(EnumType, this->getCmdGetAppContext("TASC_CONTEXT", "add_dlm_e_max"), true) + ", " + MAX_DLME_STR + ")";
}

/************************************************************************
**
**  Function    :  DdlGenDbi::geCmdMainDlmEMax()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-21197 - LJE - 160415
**
*************************************************************************/
string DdlGenDbi::geCmdMainDlmEMax()
{
    return "coalesce (" + this->convert(EnumType, this->getCmdGetAppContext("TASC_CONTEXT", "main_dlm_e_max"), true) + ", " + MAX_DLME_STR + ")";
}

/************************************************************************
**
**  Function    : DdlGenDbi::getCmdGetAppContext()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdGetAppContext(const string& contextName, const string& attributeName)
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
            return "get_appcontext('" + contextName + "', '" + attributeName + "')";
            break;
        case Oracle:
            return "SYS_CONTEXT('" + contextName + "', '" + attributeName + "')";
            break;
        case Nuodb:
            return "get_appcontext('" + contextName + "', '" + attributeName + "')";
            break;
        case MSSql:
            return this->getDbo() + "get_appcontext('" + contextName + "', '" + attributeName + "')";
            break;
        case PostgreSQL:
            return this->getDbo() + "get_appcontext('" + contextName + "'::character varying, '" + attributeName + "'::character varying)";
            break;
        default:
            SYS_BreakOnDebug();

    }

    return string();
}

/************************************************************************
**
**  Function    : DdlGenDbi::setCmdSetAppContext()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdSetAppContext(const string& contextName, const string& attributeName, const string& value)
{
    varHelperPtr->addVariable("result_", IntType);

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
            if (value[0] == '@')
            {
                return "select @result_ = set_appcontext('" + contextName + "', '" + attributeName + "', " + convert(CodeType, value, false) + ")";
            }
            return "select @result_ = set_appcontext('" + contextName + "', '" + attributeName + "', '" + value + "')";
            break;

        case Oracle:
            if (value[0] == '@')
            {
                return "select set_appcontext('" + contextName + "', '" + attributeName + "', " + convert(CodeType, value, false) + ") into v_result_ from dual;";
            }
            return "select set_appcontext('" + contextName + "', '" + attributeName + "', '" + value + "') into v_result_ from dual;";
            break;

        case Nuodb:
            if (value[0] == '@')
            {
                return "v_result_ = (select set_appcontext('" + contextName + "', '" + attributeName + "', " + convert(CodeType, value, false) + ") from dual);";
            }
            return "v_result_ = (select set_appcontext('" + contextName + "', '" + attributeName + "', '" + value + "') from dual);";
            break;

        case MSSql:
            if (value[0] == '@')
            {
                return "select @result_ = " + this->getDbo() + "set_appcontext('" + contextName + "', '" + attributeName + "', " + convert(CodeType, value, false) + ")";
            }
            return "select @result_ = " + this->getDbo() + "set_appcontext('" + contextName + "', '" + attributeName + "', '" + value + "')";
            break;

        case PostgreSQL:
            if (value[0] == '@')
            {
                return "select " + this->getDbo() + "set_appcontext('" + contextName + "', '" + attributeName + "', " + convert(CodeType, value, false) + ") into v_result_;";
            }
            return "select " + this->getDbo() + "set_appcontext('" + contextName + "', '" + attributeName + "', '" + value + "') into v_result_;";
            break;

        default:
            SYS_BreakOnDebug();

    }

    return string();
}

/************************************************************************
**
**  Function    : DdlGenDbi::rmCmdGetAppContext()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdRmAppContext(const string& contextName, const string& attributeName)
{
    varHelperPtr->addVariable("result_", IntType);

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {

        case Sybase:
            return "select @result_ = rm_appcontext('" + contextName + "', '" + attributeName + "')";
            break;

        case Oracle:
            return "select rm_appcontext('" + contextName + "', '" + attributeName + "') into v_result_ from dual;";
            break;

        case Nuodb:
            return "v_result_ = (select rm_appcontext('" + contextName + "', '" + attributeName + "') from dual);";
            break;

        case MSSql:
            return "select @result_ = " + this->getDbo() + "rm_appcontext('" + contextName + "', '" + attributeName + "')";
            break;

        case PostgreSQL:
            return "select " + this->getDbo() + "rm_appcontext('" + contextName + "', '" + attributeName + "') into v_result_;";
            break;

        default:
            SYS_BreakOnDebug();

    }

    return string();
}

/************************************************************************
**
**  Function    : DdlGenDbi::getTemplateCmd()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
const string& DdlGenDbi::getTemplateBody(CFG_TEMPLATE_ENUM feature, const std::string& keyStr)
{
    DdlGenCfgTemplateKey cfgKey(feature,
                                this->ddlGenContextPtr->getTemplateVersion(),
                                this->getDdlObjEn(),
                                keyStr);

    DdlGenCfgTemplate* cfgTpl = this->ddlGenContextPtr->getTemplateFileHelper().getCfgTemplate(cfgKey);

    if (cfgTpl)
    {
        return cfgTpl->bodyStr;
    }
    return this->emtpyStr;
}

/************************************************************************
**
**  Function    : DdlGenDbi::checkXdIndexStp()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
bool DdlGenDbi::checkXdIndexStp(DBA_DYNFLD_STP xdIndexStp, DBA_DYNFLD_STP sysXdIndexStp)
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
            return (CMP_DYNFLD(xdIndexStp,
                               sysXdIndexStp,
                               A_XdIndex_ClusteredFlg, A_XdIndex_ClusteredFlg, FlagType) == 0 ||
                    (GET_FLAG(xdIndexStp, A_XdIndex_ClusteredFlg) == FALSE && GET_FLAG(sysXdIndexStp, A_XdIndex_ClusteredFlg) == TRUE));

            break;
        case Oracle:
            return (CMP_DYNFLD(xdIndexStp,
                               sysXdIndexStp,
                               A_XdIndex_ReverseFlg, A_XdIndex_ReverseFlg, FlagType) == 0);
            break;
    }

    return true;
}

/************************************************************************
**
**  Function    :   DdlGen::setDdlGenFromFileContextPtr()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37366 - LJE - 191118
**
*************************************************************************/
void DdlGenDbi::setDdlGenFromFileContextPtr(DdlGenFromFileContext* ddlGenFromFileContextPtr)
{
    this->m_ddlGenFromFileContextPtr = ddlGenFromFileContextPtr;
}

/************************************************************************
**
**  Function    :   DdlGen::getDdlGenFromFileContextPtr()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37366 - LJE - 191118
**
*************************************************************************/
DdlGenFromFileContext* DdlGenDbi::getDdlGenFromFileContextPtr() const
{
    return this->m_ddlGenFromFileContextPtr;
}


/************************************************************************
**
**  Function    : DdlGenDbi::getCmdApplUserId()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdApplUserId()
{
    if (this->ddlGenContextPtr->ddlGenAction.m_bInitEntityOnly &&
        this->ddlGenContextPtr->ddlGenAction.isBootStrapLevel())
    {
        return "1";
    }
    return this->getDbo() + "get_connected_appl_user_id()";
}

/************************************************************************
**
**  Function    : DdlGenDbi::getCmdApplSessionCd()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdApplSessionCd()
{
    return this->getCmdGetAppContext("TASC_CONTEXT", "session_cd");
}

/************************************************************************
**
**  Function    : DdlGenDbi::getCmdSUserName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdUserName()
{
    return this->getDbo() + "get_connected_user_name()";
}

/************************************************************************
**
**  Function    : DdlGenDbi::stringLiteralMaxValue()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
unsigned int DdlGenDbi::stringLiteralMaxValue(DBA_RDBMS_ENUM rdbmsEn)
{
    switch (rdbmsEn)
    {
        case Sybase:
            return 16384;
            break;

        case Oracle:
            return 4000;
            break;

        case MSSql:
            return 4000;
            break;
    }

    return MAX_SHORT;
}

/************************************************************************
**
**  Function    : DdlGenDbi::returnInSProcAvailable()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
bool DdlGenDbi::returnInSProcAvailable()
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case MSSql:
            return true;
            break;

        case Oracle:
        case Nuodb:
        case PostgreSQL:
            return false;
            break;
    }

    return true;
}

/************************************************************************
**
**  Function    : DdlGenDbi::beginTranInSProcAvailable()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
bool DdlGenDbi::beginTranInSProcAvailable()
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case MSSql:
            return true;
            break;

        case Oracle:
        case Nuodb:
        case PostgreSQL:
            return false;
            break;
    }

    return true;
}

/************************************************************************
**
**  Function    : DdlGenDbi::commitInSProcAvailable()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
bool DdlGenDbi::commitInSProcAvailable()
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case Oracle:
        case MSSql:
            return true;
            break;

        case PostgreSQL:
        case Nuodb:
            return false;
            break;
    }

    return true;
}

/************************************************************************
**
**  Function    : DdlGenDbi::getCmdReturnFunction()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
RET_CODE DdlGenDbi::getCmdReturnFunction(DATATYPE_ENUM dataTpProgN, std::stringstream& outStream)
{
    outStream << endl;
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case Nuodb:
        case MSSql:
            outStream << "returns " << this->getDataTypeSqlName(dataTpProgN, false);
            break;

        case PostgreSQL:
            outStream << " RETURNS " << this->getDataTypeSqlName(dataTpProgN, false) << endl
                      << " LANGUAGE plpgsql";
            break;

        case Oracle:
            outStream << "return " << this->getDataTypeSqlName(dataTpProgN, false);
            break;
    }

    return RET_SUCCEED;
}

/************************************************************************
**
**  Function    : DdlGenDbi::getCmdReturnProcedure()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	: PMSTA-37366 - LJE - 200128
**
*************************************************************************/
RET_CODE DdlGenDbi::getCmdReturnProcedure(DictSprocClass& sprocClass, std::stringstream& outStream)
{
    RET_CODE ret = RET_SUCCEED;

    auto& dictSprocReturnsVector = this->ddlGenContextPtr->getDictSprocSt().m_dictSprocReturnsVector;

    if (this->ddlGenContextPtr->ddlGenAction.m_installLevel < 5 || this->ddlGenContextPtr->m_bHasUnknownCall == false)
    {
        for (auto storedProcAccess = this->ddlGenContextPtr->getDictSprocSt().m_storedProcAccessVector.begin(); storedProcAccess != this->ddlGenContextPtr->getDictSprocSt().m_storedProcAccessVector.end(); ++storedProcAccess)
        {
            if ((*storedProcAccess)->subObj != DBA_ROLE_EXTERNAL_USE &&
                this->ddlGenContextPtr->ddlGenAction.isBootStrapLevel() == false)
            {
                if ((*storedProcAccess)->multiOutputDynStPtr != nullptr)
                {
                    size_t outputResNbr = 0;
                    while ((*(*storedProcAccess)->multiOutputDynStPtr[outputResNbr]) != InvalidDynSt)
                    {
                        outputResNbr++;
                    }
                    if (outputResNbr != dictSprocReturnsVector.size())
                    {
                        ret = RET_GEN_ERR_INVARG;
                        this->printMsg(ret, "Unmatched output result-set description");
                    }
                }
                else if ((*storedProcAccess)->outputDynStPtr != nullptr &&
                         *((*storedProcAccess)->outputDynStPtr) != NullDynSt &&
                         dictSprocReturnsVector.size() != 1)
                {
                    ret = RET_GEN_ERR_INVARG;
                    this->printMsg(ret, "Unmatched output result-set description (only one is expected)");
                }
                else if (dictSprocReturnsVector.empty() == false &&
                         ((*storedProcAccess)->outputDynStPtr == nullptr || *((*storedProcAccess)->outputDynStPtr) == NullDynSt))
                {
                    ret = RET_GEN_ERR_INVARG;
                    this->printMsg(ret, "Output result-set description is missing");
                }
                else if (dictSprocReturnsVector.empty() &&
                         (*storedProcAccess)->outputDynStPtr != nullptr &&
                         *((*storedProcAccess)->outputDynStPtr) != NullDynSt)
                {
                    ret = RET_GEN_ERR_INVARG;
                    this->printMsg(ret, "Unmatched output result-set description");
                }
            }
        }
    }

    std::stringstream localStream;

    if (this->ddlGenContextPtr->m_bOutputMessage)
    {
        std::list<DdlSelectElt> selectList;
        DdlSelectElt            selectEltSt;

        selectEltSt.sqlName = "prompt_message";

        if (nullptr == SYS_GetEnv("AAADDLNUOPRINTSTRING"))
        {   /* clob */
            selectEltSt.datatype = TextType;
        }
        else
        {   /* can be made a string for debugging outside aaasql */
            selectEltSt.datatype = String15000Type;
        }
        selectList.push_back(selectEltSt);
        dictSprocReturnsVector.push_back(DictSprocReturnsClass("output_message", selectList, 0, DynType_Other, NullDynSt));
    }

    if (dictSprocReturnsVector.empty() == false)
    {
        localStream << endl;

        DBA_DYNST_ENUM dynStEn = NullDynSt;
        int resultSetNbr = 0;
        for (auto returnsIt = dictSprocReturnsVector.begin(); returnsIt != dictSprocReturnsVector.end(); ++returnsIt, ++resultSetNbr)
        {
            OBJECT_ENUM objEn = GET_OBJ_DYNST(returnsIt->m_dynStEn);
            DICT_T      entityDictId = 0;
            auto        dictEntityStp = DBA_GetDictEntitySt(objEn);

            DBA_GetDictId(objEn, &entityDictId);

            this->ddlGenContextPtr->m_dependsAccessSet.insert(DdlGenDependKey(entityDictId,
                                                                              (dictEntityStp != nullptr ? dictEntityStp->mdSqlName : "unknown"),
                                                                              DictDependsAccessEn::Returns,
                                                                              returnsIt->m_outputDynNatEn));

            if (resultSetNbr == 0)
            {
                localStream << endl << "returns ";
            }
            else
            {
                localStream << ", ";
            }

            localStream << returnsIt->geReturnsSqlName() << "(";
            if (returnsIt->m_selectListStr.empty())
            {
                stringstream resultsStream;
                for (auto attribIt = returnsIt->m_selectList.begin(); attribIt != returnsIt->m_selectList.end(); ++attribIt)
                {
                    if (attribIt != returnsIt->m_selectList.begin())
                    {
                        resultsStream << ", ";
                    }

                    if (attribIt->datatype == NullDataType)
                    {
                        if (dynStEn == NullDynSt)
                        {
                            for (auto it = sprocClass.m_storedProcAccessVector.begin(); it != sprocClass.m_storedProcAccessVector.end(); ++it)
                            {
                                if (*((*it)->outputDynStPtr) != NullDynSt)
                                {
                                    dynStEn = *((*it)->outputDynStPtr);
                                    break;
                                }
                                else if ((*it)->multiOutputDynStPtr != nullptr)
                                {
                                    for (int i = 0; i < resultSetNbr; i++)
                                    {
                                        if (*(*it)->multiOutputDynStPtr[i] == NullDynSt)
                                        {
                                            ret = RET_GEN_ERR_INVARG;
                                            this->printMsg(RET_GEN_ERR_INVARG, "Unknown output results (" + returnsIt->m_returnsSqlName + ", position " + SYS_Stringer(resultSetNbr) + " ) for multi-select");
                                            break;
                                        }
                                    }
                                    dynStEn = *(*it)->multiOutputDynStPtr[resultSetNbr];
                                }
                            }
                        }
                        if (dynStEn != NullDynSt)
                        {
                            FLAG_T allocFlg = FALSE;
                            DBA_CFIELDDEF_STP cFieldStp = DBA_GetCFielBySqlName(dynStEn, attribIt->sqlName.c_str(), &allocFlg);
                            if (cFieldStp)
                            {
                                attribIt->datatype = cFieldStp->dataTypeEnum;

                                if (allocFlg == TRUE)
                                {
                                    FREE(cFieldStp);
                                }
                            }
                        }
                    }

                    if (attribIt->datatype == NullDataType)
                    {
                        ret = RET_GEN_ERR_INVARG;
                        this->printMsg(RET_GEN_ERR_INVARG, "Unknown data-type for output results '" + attribIt->sqlName + "', please use [<data-type>] to define it");
                    }

                    resultsStream << attribIt->sqlName << " " << this->getDataTypeSqlName(attribIt->datatype, true);
                }
                returnsIt->m_selectListStr = resultsStream.str();
            }

            localStream
                << returnsIt->m_selectListStr
                << ")" << endl;
        }
    }

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case Oracle:
        case MSSql:
            break;
        case Nuodb:
            outStream << localStream.str();
            break;
        case PostgreSQL:
            if (dictSprocReturnsVector.empty() == false)
            {
                outStream << endl << " RETURNS SETOF refcursor";
            }
            else
            {
                auto& paramVector = this->ddlGenContextPtr->getDictSprocSt().m_paramProcAttribVector;
                DictSprocParamClass* outputParamPtr = nullptr;

                for (auto it = paramVector.begin(); it != paramVector.end(); ++it)
                {
                    if (it->outputFlg == TRUE)
                    {
                        if (outputParamPtr == nullptr)
                        {
                            outputParamPtr = &(*it);
                        }
                        else
                        {
                            outStream 
                                << endl << " RETURNS record" 
                                << endl << " LANGUAGE plpgsql";
                            return ret;
                        }
                    }
                }

                if (outputParamPtr != nullptr)
                {
                    outStream << endl << " RETURNS " << this->getDataTypeSqlName(outputParamPtr->getDataTypeEn(), true);
                }
                else
                {
                    outStream << endl << " RETURNS void";
                }
            }
            outStream << endl << " LANGUAGE plpgsql";
    }

    return ret;
}

/************************************************************************
**
**  Function    : DdlGenDbi::execApplRaisError()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::execApplRaisError(int numberError, string errDdlObjSqlName, string errInfo1, DdlGenVar errVar2, string errInfo3)
{
    return execApplRaisError(numberError, "'" + errDdlObjSqlName + "'", "'" + errInfo1 + "'", errVar2.printSqlName(), errInfo3.empty() ? errInfo3 : "'" + errInfo3 + "'", false);
}

/************************************************************************
**
**  Function    : DdlGenDbi::execApplRaisError()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::execApplRaisError(int numberError, string errDdlObjSqlName, string errInfo1, string errInfo2, string errInfo3, bool toQuote)
{
    stringstream outStream;
    string       quote;

    if (toQuote)
    {
        quote = "'";
    }

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case MSSql:
            outStream << this->getExecMainDbCall("appl_raiserror") << " " << numberError << ", " << quote << errDdlObjSqlName << quote;
            if (errInfo1.empty() == false)
            {
                outStream << ", " << quote << errInfo1 << quote;
            }
            if (errInfo2.empty() == false)
            {
                outStream << ", " << quote << errInfo2 << quote;
            }
            if (errInfo3.empty() == false)
            {
                outStream << ", " << quote << errInfo3 << quote;
            }
            outStream << this->getCmdEndOfCmd();
            return outStream.str();
            break;
        case Oracle:
            outStream << this->getExecMainDbCall("appl_raiserror") << " (" << numberError << ", " << quote << errDdlObjSqlName << quote;
            if (errInfo1.empty() == false)
            {
                outStream << ", " << quote << errInfo1 << quote;
            }
            if (errInfo2.empty() == false)
            {
                outStream << ", " << quote << errInfo2 << quote;
            }
            if (errInfo3.empty() == false)
            {
                outStream << ", " << quote << errInfo3 << quote;
            }
            outStream << ")" << this->getCmdEndOfCmd();
            return outStream.str();
            break;
    }

    return string();
}

/************************************************************************
**
**  Function    : DdlGenDbi::getCmdExecSProc()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdExecSProc(const std::string& databaseName, 
                                  const string&      sProcName, 
                                  const string&      sProcParam,
                                  const string&      returnVar,
                                  vector<string>&    outputVariables,
                                  vector<string>&    outputParams,
                                  DictSprocClass*    dictSprocStp)
{
    bool           bWithBracket = false;
    vector<string> returnsTableVector;

    if (this->m_ddlObjEn == DdlObj_SProc)
    {
        if (dictSprocStp != nullptr &&
            dictSprocStp->m_dictSprocReturnsVector.empty() == false)
        {
            auto& dictSprocReturnsVector = this->ddlGenContextPtr->getDictSprocSt().m_dictSprocReturnsVector;

            size_t resPos = dictSprocReturnsVector.size();
            bool   bNewResultSet = (resPos == 0 || dictSprocReturnsVector.size() < dictSprocStp->m_dictSprocReturnsVector.size());

            if (bNewResultSet == false)
            {
                resPos -= dictSprocStp->m_dictSprocReturnsVector.size();

                for (auto returnsIt = dictSprocStp->m_dictSprocReturnsVector.begin(); returnsIt != dictSprocStp->m_dictSprocReturnsVector.end() && bNewResultSet == false; ++returnsIt, ++resPos)
                {
                    string returnsSqlName;

                    if (this->ddlGenContextPtr->m_rdbmsEn == PostgreSQL)
                    {
                        returnsSqlName = SYS_Stringer(this->ddlGenContextPtr->getDictSprocSt().sqlName,
                                                      "_",
                                                      this->ddlGenContextPtr->getDictSprocSt().getDictEntityStp()->shortSqlname);
                    }
                    else
                    {
                        returnsSqlName = returnsIt->m_returnsSqlName;
                    }

                    if (dictSprocReturnsVector[resPos].m_returnsSqlName != returnsSqlName)
                    {
                        bNewResultSet = true;
                    }
                }
                if (bNewResultSet == false)
                {
                    resPos -= dictSprocStp->m_dictSprocReturnsVector.size();
                }
                else
                {
                    resPos = dictSprocReturnsVector.size();
                }
            }

            for (auto returnsIt = dictSprocStp->m_dictSprocReturnsVector.begin(); returnsIt != dictSprocStp->m_dictSprocReturnsVector.end(); ++returnsIt, ++resPos)
            {
                string returnsSqlName;

                if (this->ddlGenContextPtr->m_rdbmsEn == PostgreSQL)
                {
                    returnsSqlName = SYS_Stringer(this->ddlGenContextPtr->getDictSprocSt().sqlName,
                                                  "_",
                                                  this->ddlGenContextPtr->getDictSprocSt().getDictEntityStp()->shortSqlname);
                }
                else
                {
                    returnsSqlName = returnsIt->m_returnsSqlName;
                }

                if (bNewResultSet)
                {
                    dictSprocReturnsVector.push_back(DictSprocReturnsClass(returnsSqlName,
                                                                           returnsIt->m_selectList,
                                                                           resPos + 1,
                                                                           returnsIt->m_outputDynNatEn,
                                                                           returnsIt->m_dynStEn));
                    dictSprocReturnsVector.back().m_selectListStr = returnsIt->m_selectListStr;
                }

                returnsTableVector.push_back(dictSprocReturnsVector[resPos].geReturnsSqlName());
            }
        }
    }

    stringstream outStream; 
    outStream << this->getExecCmd(returnVar, returnsTableVector, dictSprocStp, outputVariables.empty() == false);

    stringstream outputClause;
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
            if (databaseName.empty() == false)
            {
                outStream << databaseName;
                outStream << "..";
            }
            break;

        case Oracle:
            if (databaseName.empty() == false)
            {
                outStream << databaseName;
                outStream << ".";
            }
            bWithBracket = true;
            break;

        case Nuodb:
            if (databaseName.empty() == false)
            {
                outStream << databaseName;
                outStream << ".";
            }
            bWithBracket = true;
            break;

        case MSSql:
            if (databaseName.empty() == false)
            {
                outStream << databaseName;
                outStream << ".";
            }
            else if (this->getTargetDBName().empty() == false)
            {
                outStream << this->getTargetDBName() + ".";
            }
            break;

        case PostgreSQL:
            bWithBracket = true;

            if (outputVariables.empty() && 
                returnVar.empty() == false &&
                dictSprocStp != nullptr && 
                dictSprocStp->functionFlg == TRUE)
            {
                outputClause << " into " << returnVar;
            }
            else if (outputVariables.empty() == false)
            {
                string procAlias("proc");
                for (auto it = outputParams.begin(); it != outputParams.end(); ++it)
                {
                    if (it != outputParams.begin())
                    {
                        outStream << ", ";
                    }
                    outStream << procAlias << "." << (*it);
                }

                for (auto it = outputVariables.begin(); it != outputVariables.end(); ++it)
                {
                    if (it == outputVariables.begin())
                    {
                        outStream << " into ";
                    }
                    else
                    {
                        outStream << ", ";
                    }
                    outStream << (*it);
                }
                outStream << " from ";
                outputClause << " " << procAlias;
            }

            if (databaseName.empty() == false)
            {
                outStream << databaseName;
                outStream << ".";
            }
            else if (this->getTargetDBName().empty() == false)
            {
                outStream << this->getTargetDBName() + ".";
            }

            if (returnsTableVector.empty() == false)
            {
                auto fromFileContextPtr = this->getDdlGenFromFileContextPtr();
                if (fromFileContextPtr != nullptr &&
                    fromFileContextPtr->m_position != DdlGenFromFileContext::Position::Then)
                {
                    fromFileContextPtr = nullptr;
                }

                stringstream decalrePartStr;
                stringstream fetchStream;

                auto& dictSprocReturnsVector = dictSprocStp->m_dictSprocReturnsVector;
                auto& currentDictSprocReturnsVector = this->ddlGenContextPtr->getDictSprocSt().m_dictSprocReturnsVector;

                auto retIt = dictSprocReturnsVector.begin();
                auto currIt = currentDictSprocReturnsVector.begin();
                for (auto it = returnsTableVector.begin(); it != returnsTableVector.end(); ++it, ++retIt, ++currIt)
                {
                    fetchStream << this->endOfCmd() << this->newLine();

                    DdlGenVar cursorVar(*this);
                    cursorVar.sqlName = (*it);
                    cursorVar.setDataType(SysRefCursorType);
                    cursorVar.strDefault = "'" + (*it) + "'";

                    if (this->m_ddlObjEn == DdlObj_Sql || this->m_ddlObjEn == DdlObj_RuntimeSql)
                    {
                        decalrePartStr << cursorVar.getInDeclareCmd() + this->newLine();
                    }
                    else
                    {
                        this->varHelperPtr->addVariable(cursorVar);
                    }

                    fetchStream << "open " << cursorVar.printSqlName() << " for" << this->newLine();
                    fetchStream << "fetch all \"" + retIt->geReturnsSqlName() + "\";";
                    fetchStream << this->newLine() << "return next " << cursorVar.printSqlName();

                    if (fromFileContextPtr != nullptr)
                    {
                        fromFileContextPtr->m_ifResultsSetVector.push_back(*retIt);
                        fromFileContextPtr->m_ifResultsSetVector.back().m_returnsSqlName = currIt->m_returnsSqlName;
                    }
                }
                outputClause << fetchStream.str();

                if (decalrePartStr.str().empty() == false)
                {
                    string cmd = outStream.str();
                    outStream.str(string());
                    outStream.clear();

                    outStream << "declare " << decalrePartStr.str() << this->newLine() << "begin" << this->newLine() << cmd;
                    outputClause << "end";
                }
            }
            break;
    }

    outStream << sProcName << (bWithBracket ? "(" : " ") << sProcParam + (bWithBracket ? ")" : "") << outputClause.str() << this->endOfCmd();
    return outStream.str();
}

/************************************************************************
**
**  Function    : DdlGenDbi::getCmdExecSProc()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdExecSProc(const std::string& databaseName, const string& sProcName, vector<string>& sProcParam, DictSprocClass* dictSprocStp)
{
    stringstream   outStream;

    for (vector<string>::iterator it = sProcParam.begin(); it != sProcParam.end(); ++it)
    {
        if (it != sProcParam.begin())
        {
            outStream << ",";
        }
        outStream << *it;
    }

    vector<string> emptyVector;
    return this->getCmdExecSProc(databaseName, sProcName, outStream.str(), string(), emptyVector, emptyVector, dictSprocStp);
}

/************************************************************************
**
**  Function    : DdlGenDbi::getCmdCreateTempTable()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdCreateTempTable(DICT_ENTITY_STP  tmpTblDictEntityStp)
{
    OBJECT_ENUM  locObjectEn;
    string       outStr;

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case Nuodb:
        case MSSql:
        case PostgreSQL:

            /* PMSTA-58084 - LJE - 240729 */
            if (DdlGenDbi::getTempTableSpec(this->ddlGenContextPtr->m_rdbmsEn, tmpTblDictEntityStp) == DdlGenDbi::TempTableSpec::MemoryOptimzed)
            {
                outStr = this->getDeleteRequest(tmpTblDictEntityStp->dbSqlName);
            }
            else
            {
                DBA_GetObjectEnum(tmpTblDictEntityStp->entDictId, &locObjectEn);

                DdlGenTable   locGenDdl(locObjectEn, TargetTable_Main, *this->ddlGenContextPtr, NULL, NULL);

                locGenDdl.setPreIndent(this->getPreIndent());
                locGenDdl.setIndent(this->getIndentNbr());
                locGenDdl.bNoIndentReset = true;

                outStr = locGenDdl.getCreateCmd(false) + this->endOfCmd();
            }
            break;

        case Oracle:
            outStr = this->getDeleteRequest(tmpTblDictEntityStp->dbSqlName);
            break;

        default:
            SYS_BreakOnDebug();
    }

    return outStr;
}

/************************************************************************
**
**  Function    : DdlGenDbi::getTempTableSpec()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	: PMSTA-58084 - LJE - 240729
**
*************************************************************************/
DdlGenDbi::TempTableSpec DdlGenDbi::getTempTableSpec(DBA_RDBMS_ENUM rdbmsEn, DICT_ENTITY_STP dictEntityStp)
{
    if (dictEntityStp == nullptr ||
        dictEntityStp->entNatEn != EntityNat_TempTable)
    {
        return DdlGenDbi::TempTableSpec::None;
    }

    switch (rdbmsEn)
    {
        case Oracle:
        case QtHttp:
            return DdlGenDbi::TempTableSpec::Global;
            break;

        case MSSql:
            if (dictEntityStp != nullptr &&
                dictEntityStp->dbRuleEn == DbRule_TypeTable)
            {
                return DdlGenDbi::TempTableSpec::Type;
            }

            if ((dictEntityStp == nullptr || 
                 dictEntityStp->dbRuleEn != DbRule_VolatileTable))
            {
                return DdlGenDbi::TempTableSpec::MemoryOptimzed;
            }
            return DdlGenDbi::TempTableSpec::Session;
            break;

        case Sybase:
        case Nuodb:
        case PostgreSQL:
        default:
            return DdlGenDbi::TempTableSpec::Session;
            break;
    }
}

/************************************************************************
**
**  Function    : DdlGenDbi::getTempTableSpec()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	: PMSTA-58084 - LJE - 240729
**
*************************************************************************/
DdlGenDbi::TempTableSpec DdlGenDbi::getTempTableSpec(DBA_RDBMS_ENUM rdbmsEn, DBA_DYNFLD_STP xdEntityStp)
{
    if (xdEntityStp == nullptr ||
        GET_ENUM(xdEntityStp, A_XdEntity_NatEn) != EntityNat_TempTable)
    {
        return DdlGenDbi::TempTableSpec::None;
    }

    switch (rdbmsEn)
    {
        case Oracle:
        case QtHttp:
            return DdlGenDbi::TempTableSpec::Global;
            break;

        case MSSql:
            if (xdEntityStp != nullptr &&
                GET_ENUM(xdEntityStp, A_XdEntity_DbRuleEn) == DbRule_TypeTable)
            {
                return DdlGenDbi::TempTableSpec::Type;
            }

            if ((xdEntityStp == nullptr ||
                 GET_ENUM(xdEntityStp, A_XdEntity_DbRuleEn) != DbRule_VolatileTable))
            {
                return DdlGenDbi::TempTableSpec::MemoryOptimzed;
            }
            return DdlGenDbi::TempTableSpec::Session;
            break;

        case Sybase:
        case Nuodb:
        case PostgreSQL:
        default:
            return DdlGenDbi::TempTableSpec::Session;
            break;
    }
}

/************************************************************************
**
**  Function    : DdlGenDbi::isTempTableLocalStoredProc()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
bool DdlGenDbi::isTempTableLocalStoredProc(DBA_RDBMS_ENUM rdbmsEn, DICT_ENTITY_STP dictEntityStp)
{
    switch (rdbmsEn)
    {
        case Oracle:
        case QtHttp:
        case Nuodb:
        case PostgreSQL:
        default:
            return false;
            break;

        case Sybase:
            return true;
            break;

        case MSSql:
            /* PMSTA-58084 - LJE - 240729 */
            return DdlGenDbi::getTempTableSpec(rdbmsEn, dictEntityStp) == DdlGenDbi::TempTableSpec::Session;
            break;
    }
}

/************************************************************************
**
**  Function    : DdlGenDbi::getCmdTruncateTable()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdTruncateTable(DICT_ENTITY_STP  truncDictEntityStp, bool bForce, bool bInBlock)
{
    string       outStr, tableName;

    if (this->ddlGenContextPtr->getDdlDestDbName().compare(truncDictEntityStp->databaseName) != 0)
    {
        tableName = this->getEntityFullSqlName(truncDictEntityStp, TargetTable_Undefined, string(), View_None);
    }
    else
    {
        tableName = this->getEntitySqlName(truncDictEntityStp);
    }

    if (bForce)
    {
        switch (this->ddlGenContextPtr->m_rdbmsEn)
        {
            case Sybase:
                outStr = this->getTruncateRequest(tableName);
                break;

            case MSSql:
                if (DdlGenDbi::getTempTableSpec(this->ddlGenContextPtr->m_rdbmsEn, truncDictEntityStp) == DdlGenDbi::TempTableSpec::MemoryOptimzed)
                {
                    outStr = this->getDeleteRequest(tableName);
                }
                else
                {
                    outStr = this->getTruncateRequest(tableName);
                }
                break;

            case PostgreSQL:
                if (bInBlock)
                {
                    outStr = this->getTruncateRequest(tableName) + this->endOfCmd();
                }
                else
                {
                    outStr = this->getTruncateRequest(tableName);
                }
                break;

            case Oracle:
                if (bInBlock)
                {
                    outStr = this->getDdlModif(this->getTruncateRequest(tableName));
                }
                else
                {
                    outStr = this->getTruncateRequest(tableName);
                }
                break;
            case Nuodb:
                if (bInBlock)
                {
                    outStr = this->getDdlModif(this->getTruncateRequest(tableName));
                }
                else
                {
                    outStr = this->getTruncateRequest(tableName);
                }
                break;

            default:
                SYS_BreakOnDebug();
        }
    }
    else
    {
        switch (this->ddlGenContextPtr->m_rdbmsEn)
        {
            case Sybase:
                outStr =
                    "if @@trancount > 0"
                    + this->newLine() + "begin"
                    + this->newLine() + "    delete " + tableName
                    + this->newLine() + "end"
                    + this->newLine() + "else begin"
                    + this->newLine() + "    " + this->getTruncateRequest(tableName)
                    + this->newLine() + "end";
                break;

            case MSSql:
                /* PMSTA-58084 - LJE - 240729 */
                if (DdlGenDbi::getTempTableSpec(this->ddlGenContextPtr->m_rdbmsEn, truncDictEntityStp) == DdlGenDbi::TempTableSpec::MemoryOptimzed ||
                    DdlGenDbi::getTempTableSpec(this->ddlGenContextPtr->m_rdbmsEn, truncDictEntityStp) == DdlGenDbi::TempTableSpec::Type)
                {
                    outStr = this->getDeleteRequest(tableName);
                }
                else
                {
                    outStr =
                        "if @@trancount > 0"
                        + this->newLine() + "begin"
                        + this->newLine() + "\tdelete " + tableName
                        + this->newLine() + "end"
                        + this->newLine() + "else begin"
                        + this->newLine() + "\t" + this->getTruncateRequest(tableName)
                        + this->newLine() + "end";
                }
                break;

            case Oracle:
                if (truncDictEntityStp->entNatEn == EntityNat_TempTable)
                {
                    outStr = this->getDeleteRequest(tableName);
                }
                else
                {
                    if (bInBlock)
                    {
                        outStr = this->getDdlModif(this->getTruncateRequest(tableName));
                    }
                    else
                    {
                        outStr = this->getTruncateRequest(tableName);
                    }
                }
                break;

            case Nuodb:
                outStr = this->getDdlModif(this->getTruncateRequest(tableName));
                break;

            case PostgreSQL:
                if (truncDictEntityStp->entNatEn == EntityNat_TempTable)
                {
                    outStr = this->getDeleteRequest(tableName);
                }
                else
                {
                    if (bInBlock)
                    {
                        outStr = this->getTruncateRequest(tableName) + this->endOfCmd();
                    }
                    else
                    {
                        outStr = this->getTruncateRequest(tableName);
                    }

                }
                break;

            default:
                SYS_BreakOnDebug();
        }
    }

    return outStr;
}

/************************************************************************
**
**  Function    : this->standardize()
**
**  Description : Standardize ddl object
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
void DdlGenDbi::standardize(string& ddlObject)
{
    this->standardize(ddlObject, this->ddlGenContextPtr);
}

/************************************************************************
**
**  Function    : this->standardize()
**
**  Description : Standardize ddl object
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
void DdlGenDbi::standardize(string& ddlObject, DdlGenContext* ddlGenContextPtr)
{
    if (ddlGenContextPtr != nullptr && ddlObject.empty() == false && ddlObject[0] != '$')
    {
        if (EV_UseAlternativeDataSource && 
            ddlGenContextPtr->m_useAlternativeDataServer)
        {
            ddlGenContextPtr->getConvertValue(ddlObject);
        }

        switch (ddlGenContextPtr->m_rdbmsEn)
        {
            case Sybase:
            case MSSql:
            case QtHttp:
                break;

            case Oracle:
            case Nuodb:
                ddlObject = upper(ddlObject);
                break;

            case PostgreSQL:
                ddlObject = lower(ddlObject);
                break;

            case Sqlite:
                ddlGenContextPtr->getConvertValue(ddlObject);
                break;
        }
    }
}

/************************************************************************
**
**  Function    : this->standardize()
**
**  Description : Standardize ddl object
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
void DdlGenDbi::standardize(string& ddlObject, DBA_RDBMS_ENUM rdbmsEn)
{
    switch (rdbmsEn)
    {
        case Sybase:
        case MSSql:
            break;

        case Oracle:
        case Nuodb:
            ddlObject = upper(ddlObject);
            break;

        case PostgreSQL:
            ddlObject = lower(ddlObject);
            break;
    }
}

/************************************************************************
**
**  Function    : DdlGenDbi::getCmdSelectList()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdSelectList(const string& value, const string& paramAlias)
{
    string outStr;
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
            outStr = paramAlias + " = " + value;
            break;

        case PostgreSQL:
            outStr = value + " AS " + paramAlias;
            break;

        case Oracle:
        case MSSql:
        default:
            outStr = value + " as " + paramAlias;
            break;
    }
    return outStr;
}

/************************************************************************
**
**  Function    : DdlGenDbi::getDdlModif()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getDdlModif(const string& ddlModif)
{
    return this->getCmdExecSql(ddlModif);
}

/************************************************************************
**
**  Function    : DdlGenDbi::getCmdExecSql()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdExecSql(const string& sqlToDo, const std::string& quote)
{
    string dynSqlToDo = sqlToDo;

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
            return ("execute (" + quote + dynSqlToDo + quote + ")");
            break;

        case MSSql:
            if (quote.compare("'") == 0)
            {
                /* Handling of single quotes present in dynamic sql
                   -> can be done for others rdbms as well if required.
                   -> Current scenario: when called for ddl statement execution,
                       segment names are in single quotes for create table statement
                */
                string::size_type pos;

                if (dynSqlToDo.find("''") == string::npos)
                {
                    while ((pos = dynSqlToDo.find("'")) != string::npos)
                    {
                        dynSqlToDo.replace(pos, 1, "<q>");
                    }

                    while ((pos = dynSqlToDo.find("<q>")) != string::npos)
                    {
                        dynSqlToDo.replace(pos, 3, "''");
                    }
                }
            }
            return ("execute (" + quote + dynSqlToDo + quote + ")");
            break;

        case Oracle:
            return ("execute immediate " + quote + dynSqlToDo + quote + ";");
            break;

        case Nuodb:
            return ("execute immediate " + quote + dynSqlToDo + quote + ";");
            break;

        case PostgreSQL:
            return ("execute " + quote + dynSqlToDo + quote + ";");
            break;
    }

    return string();
}

/************************************************************************
**
**  Function    : DdlGenDbi::getExecuteAs()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getExecuteAs(DBA_EXECUTE_AS_ENUM executeAsEn)
{
    if (executeAsEn != ExecuteAs_Private &&
        executeAsEn != ExecuteAs_LoginManager &&
        executeAsEn != ExecuteAs_WmTech)
    {
        switch (this->ddlGenContextPtr->m_rdbmsEn)
        {
            case Sybase:
            case MSSql:
            {
                string outStr = " with execute as ";

                switch (executeAsEn)
                {
                    case ExecuteAs_Owner:
                        outStr += "owner";
                        break;
                    case ExecuteAs_Caller:
                        outStr += "caller";
                        break;

                    default:
                        outStr.clear();
                        break;
                }
                return outStr;
            }
            break;

            case Oracle:
            {
                string outStr = " AUTHID ";

                switch (executeAsEn)
                {
                    case ExecuteAs_Owner:
                        outStr += "DEFINER";
                        break;

                    case ExecuteAs_Caller:
                        outStr += "CURRENT_USER";
                        break;

                    default:
                        outStr.clear();
                        break;
                }
                return outStr;
            }
            break;

            case Nuodb:
            case PostgreSQL:
            {
                string outStr = " SECURITY ";

                switch (executeAsEn)
                {
                    case ExecuteAs_None:
                    case ExecuteAs_Owner:
                        outStr += "DEFINER";
                        break;

                    case ExecuteAs_Caller:
                        outStr += "INVOKER";
                        break;

                    default:
                        outStr.clear();
                        break;
                }
                return outStr;
            }
            break;
        }
    }
    return string();
}

/************************************************************************
**
**  Function    : DdlGenDbi::getDeterministic()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getDeterministic(bool bDeterministic)
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
            break;

        case Oracle:
            break;

        case MSSql:
            break;

        case Nuodb:
        {
            string outStr = bDeterministic ? "" : "NOT ";
            outStr += "DETERMINISTIC";
            return outStr;
        }
        break;

        case PostgreSQL:
        {
            if (bDeterministic)
            {
                string outStr = " STABLE";
                return outStr;
            }
        }
        break;
    }
    return string();
}

/************************************************************************
**
**  Function    : DdlGenDbi::getWithRecomplie()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getWithRecomplie()
{
    string outStr;

    switch (EV_RdbmsDdlGen)
    {
        case Sybase:
            outStr = " with recompile ";
            break;
        default:
            break;
    }

    return outStr;
}

/************************************************************************
**
**  Function    : DdlGenDbi::getAutonomousTransaction()
**
**  Description :  Generates for Oracle a pragma for having AUTONOMOUS TRANSACTION
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	: PMSTA-20494 - TEB - 160808
**
*************************************************************************/
string DdlGenDbi::getAutonomousTransaction()
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
            /* Nothing */
            break;

        case Oracle:
            return (" PRAGMA AUTONOMOUS_TRANSACTION ;");
            break;
    }
    return string();
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getTableFullDbName()
**
**  Description :  Builds a string matching to current DB syntax for the
**                 given db, user and table
**
**  Arguments   :  databaseName
**                 userName
**                 tableName
**
**  Return      :
**
**  Creation  	: PMSTA-20159 - TEB - 150624
**
************************************************************************/
string DdlGenDbi::getTableFullDbName(const string& databaseName, const string& userName, const string& tableName, DBA_RDBMS_ENUM rdbmsEn)
{
    if (tableName.find(".") == std::string::npos)
    {
        string cmd;

        switch (rdbmsEn)
        {
            case Sybase:
                if (databaseName.empty() == false)
                {
                    cmd = databaseName;

                    if (userName.empty() == false)
                    {
                        cmd += "." + userName + ".";
                    }
                    else
                    {
                        cmd += "..";
                    }
                }
                break;

            case Oracle:
            case Nuodb:
            case MSSql:
            case PostgreSQL:
                if (databaseName.empty() == false)
                {
                    cmd = databaseName + ".";
                }
                break;

            case Sqlite:
            case QtHttp:
                break;

            default:
                SYS_BreakOnDebug();

        }

        return cmd + tableName;
    }

    return tableName;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getTableFullDbName()
**
**  Description :  Builds a string matching to current DB syntax for the
**                 given db, user and table
**
**  Arguments   :  databaseName
**                 userName
**                 tableName
**
**  Return      :
**
**  Creation  	: PMSTA-20159 - TEB - 150624
**
************************************************************************/
string DdlGenDbi::getTableFullDbName(const string& databaseName, const string& userName, const string& tableName)
{
    string stdTableName(tableName);

    if (this->ddlGenContextPtr->m_rdbmsEn == PostgreSQL)
    {
        this->standardize(stdTableName);

        if (this->isProcedureBehavior() == false &&
            this->ddlGenContextPtr->ddlGenAction.m_execModeEn != DbObjExecMod_BuildFromTemplate &&
            (databaseName.empty() || this->ddlGenContextPtr->getDefDdlDestDbName() == databaseName))
        {
            return stdTableName;
        }
    }
    else if (this->ddlGenContextPtr->m_rdbmsEn == Sqlite)
    {
        string stdDatabaseName(databaseName);

        this->standardize(stdDatabaseName);

        if (this->ddlGenContextPtr->getDdlDestDbName() != stdDatabaseName)
        {
            this->ddlGenContextPtr->setDdlDestDbName(stdDatabaseName, this);
        }
    }
    return DdlGenDbi::getTableFullDbName(databaseName, userName, stdTableName, this->ddlGenContextPtr->m_rdbmsEn);
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getEntityFullSqlName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14556 - LJE - 120705
**
*************************************************************************/
string DdlGenDbi::getEntityFullSqlName(DICT_ENTITY_STP    locDictEntityStp,
                                       TARGET_TABLE_ENUM  locTargetTableEn,
                                       const std::string& realEntitySqlName,
                                       DDL_VIEW_ENUM      outputViewEn,
                                       bool               bTryToSecure)
{
    /* PMSTA-26250 - LJE - 170331 */

    string fullEntitySqlName;
    string entitySqlName(realEntitySqlName);
    string entityDbName;
    string dbName;

    if (locTargetTableEn == TargetTable_Undefined)
    {
        locTargetTableEn = this->targetTableEn;
    }

    /* PMSTA-28698 - LJE - 180511 */
    if (entitySqlName.empty())
    {
        entitySqlName = this->getEntitySqlName(locDictEntityStp, locTargetTableEn);
    }
    else if (locDictEntityStp->bIsInitEntity)
    {
        return realEntitySqlName;
    }

    if (this->ddlGenContextPtr != nullptr)
    {
        /* PMSTA-31849 - LJE - 180716 */
        if ((locTargetTableEn == TargetTable_View ||
             locTargetTableEn == TargetTable_TechView ||
             locTargetTableEn == TargetTable_SecuView) &&
            locDictEntityStp->entNatEn != EntityNat_Internal &&
            locDictEntityStp->entNatEn != EntityNat_TempTable) /* PMSTA-46681 - LJE - 240129 */
        {
            dbName = this->ddlGenContextPtr->getMainDbName();
            entitySqlName = DdlGenView::getName(locDictEntityStp, (locTargetTableEn == TargetTable_TechView ? View_Tech : locTargetTableEn == TargetTable_SecuView ? View_LightAll : outputViewEn), DdlGenMode_Standard);

            this->ddlGenContextPtr->getDependsDictEntityMap(entitySqlName, this->ddlGenContextPtr->m_dependsEntityMap);
        }
        else
        {
            entityDbName = this->getEntityDbName(locDictEntityStp);
            if (locTargetTableEn == TargetTable_Precomp)
            {
                if (locDictEntityStp->precompDbName[0])
                {
                    dbName = locDictEntityStp->precompDbName;
                }
                else if (locDictEntityStp->linkedEntityStp)
                {
                    dbName = locDictEntityStp->linkedEntityStp->precompDbName;
                }
            }
            else if (entityDbName.empty() == false && strcasecmp(this->ddlGenContextPtr->getDdlDestDbName().c_str(), entityDbName.c_str()) != 0)
            {
                dbName = entityDbName;
            }
        }
    }

    if (dbName.empty())
    {
        dbName = locDictEntityStp->databaseName;

        /* PMSTA-36158 - LJE - 190627 */
        if (dbName.empty() && locDictEntityStp->physicalEntityStp != nullptr)
        {
            dbName = locDictEntityStp->physicalEntityStp->databaseName;
        }
    }

    this->standardize(dbName);

    if (this->ddlGenContextPtr->bGenFromDbi)
    {
        this->ddlGenContextPtr->getConvertValue(dbName);
    }

    if (bTryToSecure)
    {
        fullEntitySqlName = this->getTableWithSecurity(locDictEntityStp, locTargetTableEn, dbName, entitySqlName);
    }
    else
    {
        fullEntitySqlName = this->getTableFullDbName(dbName, string(), entitySqlName);
    }

    return (fullEntitySqlName);
}

/************************************************************************
**
**  Function    :   DdlGenDbi::buildDictEntityFromSys()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14556 - LJE - 120705
**
*************************************************************************/
DICT_ENTITY_STP DdlGenDbi::buildDictEntityFromSys(const std::string &sqlName, const std::string &altSqlName, bool &bForceTarget)
{
    DICT_ENTITY_STP newDictEntityStp = nullptr;

    if (EV_UseAlternativeDataSource &&
        EV_SourceCfgFile != nullptr &&
        EV_TargetCfgFile != nullptr)
    {
        if (EV_SourceRdbmsVendor == Sybase)
        {
            auto objIt = EV_SourceCfgFile->objSectionMap.find(sqlName);

            if (objIt == EV_SourceCfgFile->objSectionMap.end() &&
                altSqlName.empty() == false)
            {
                objIt = EV_SourceCfgFile->objSectionMap.find(altSqlName);
            }

            if (objIt == EV_SourceCfgFile->objSectionMap.end())
            {
                if (this->ddlGenContextPtr->ddlGenAction.m_bSingleEntity)
                {
                    for (objIt = EV_SourceCfgFile->objSectionMap.begin(); objIt != EV_SourceCfgFile->objSectionMap.end(); ++objIt)
                    {
                        if (objIt->second.objectName == "dict_entity")
                        {
                            break;
                        }
                    }
                }
            }
            else
            {
                auto targetObjIt = EV_TargetCfgFile->objSectionMap.find(objIt->second.objectName);
                if (targetObjIt == EV_TargetCfgFile->objSectionMap.end())
                {
                    objIt = EV_SourceCfgFile->objSectionMap.end();
                }
            }

            if (objIt != EV_SourceCfgFile->objSectionMap.end())
            {
                auto dbSectionIt = EV_SourceCfgFile->dbSectionMap.find(objIt->second.dbFct);

                if (dbSectionIt != EV_SourceCfgFile->dbSectionMap.end())
                {
                    OBJECT_ENUM locObjectEn = NullEntity;

                    DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);
                    DbiConnection* dbiConn = &ddlGenConnGuard.getDbiConn();

                    DICT_CreateVirtualEntity(&locObjectEn,
                                             sqlName.c_str(),
                                             sqlName.c_str(),
                                             sqlName.c_str(),
                                             nullptr,
                                             false,
                                             dbiConn,
                                             bForceTarget == false);

                    newDictEntityStp = DBA_GetDictEntitySt(locObjectEn);

                    newDictEntityStp->databaseName = dbSectionIt->second.dbSqlName;
                    newDictEntityStp->xdStatusEn = XdStatus_Untreated;
                    newDictEntityStp->entNatEn = EntityNat_Internal;

                    RequestHelper  requestHelper(dbiConn);
                    requestHelper.setReadOnly(true);
                    requestHelper.m_useAlternativeDataServer = true;

                    stringstream requestStream;

                    requestStream
                        << "select sc.name,	datatype_dict_id=(select min(dd.dict_id) "
                        << "from dict_datatype dd "
                        << "where dd.equiv_type_c = (case when st.usertype >= 100 then (select "
                        << "case st.type "
                        << "when 39	then ltrim(d.type_name) + '(' + cast(sc.length as varchar(30)) + ')' "
                        << "when 155 then ltrim(d.type_name) + '(' + cast(sc.length / 2 as varchar(30)) + ')' "
                        << "else "
                        << "case sc.prec when null then ltrim(d.type_name) "
                        << "else ltrim(d.type_name) + '(' + (cast(sc.prec as varchar(30)) + ',' + cast(sc.scale as varchar(30))) + ')' end "
                        << "                                                           end "
                        << "from sybsystemprocs.dbo.spt_datatype_info d "
                        << "where st.type = d.ss_dtype) "
                        << "else "
                        << "case st.length when (select st.length from systypes st where st.usertype = 1) "
                        << "then ltrim(st.name) + '(' + cast(case st.type when 155 then sc.length / 2 else sc.length end as varchar(30)) + ')' "
                        << "else "
                        << "case sc.prec when null then ltrim(st.name) else ltrim(st.name) + '(' + (cast(sc.prec as varchar(30)) + ',' + cast(sc.scale as varchar(30))) + ')' end "
                        << "                     end "
                        << "                     end "
                        << "                     )) "
                        << "from " << newDictEntityStp->databaseName << "..sysobjects so "
                        << "inner join " << newDictEntityStp->databaseName << "..syscolumns sc on so.id = sc.id "
                        << "inner join " << newDictEntityStp->databaseName << "..systypes st on sc.usertype = st.usertype "
                        << "where so.type = 'U' and so.name = '" << newDictEntityStp->dbSqlName << "' "
                        << "order by sc.colid";

                    requestHelper.setCommand(requestStream.str());

                    char   *attribName = nullptr;
                    DICT_T *datatypeDictId = nullptr;

                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(attribName);
                    requestHelper.addNewOutputData(DictType);
                    requestHelper.getBindVariablePtr(datatypeDictId);

                    INT_T progN = 0;
                    if (requestHelper.sendCommandForFetch() == RET_SUCCEED)
                    {
                        while (requestHelper.fetch() == RET_SUCCEED)
                        {
                            DICT_T attrDictId = (newDictEntityStp->entDictId * 1000) - (progN + 1);
                            auto &newDictAttribSt = newDictEntityStp->addDictAttrib(attrDictId, progN, attribName);
                            newDictAttribSt.dataTpProgN = DATATYPE_DICT_TO_ENUM(*datatypeDictId);

                            if (progN == 0 &&
                                (newDictAttribSt.dataTpProgN == DictType ||
                                 newDictAttribSt.dataTpProgN == IdType))
                            {
                                newDictAttribSt.primFlg = TRUE;
                                newDictAttribSt.progPkN = 0;
                            }

                            newDictEntityStp->attr.push_back(&newDictAttribSt);
                            progN++;
                        }
                    }
                }
            }
        }

        if (newDictEntityStp == nullptr)
        {
            DdlGenConnGuard  ddlGenConnGuard(*this->ddlGenContextPtr);
            DbiConnection*   dbiConn = &ddlGenConnGuard.getDbiConn();
            RequestHelper    requestHelper(dbiConn);
            requestHelper.setReadOnly(true);
            requestHelper.m_useAlternativeDataServer = true;
            requestHelper.setDbNameOption("dict_entity");

            stringstream requestStream;
            requestStream
                << "select da.sqlname_c, da.datatype_dict_id, de.database_c from dict_entity de "
                << "inner join dict_attribute da on de.dict_id = da.entity_dict_id "
                << "where de.sqlname_c = '" << sqlName << "' and da.logical_f = 0 and da.calculated_e in (0, 4, 5, 6, 10, 11) "
                << "order by da.prog_n";

            requestHelper.setCommand(requestStream.str());

            char   *attribName = nullptr;
            char   *dbSqlName = nullptr;
            DICT_T *datatypeDictId = nullptr;

            requestHelper.addNewOutputData(LongSysnameType);
            requestHelper.getBindVariablePtr(attribName);
            requestHelper.addNewOutputData(DictType);
            requestHelper.getBindVariablePtr(datatypeDictId);
            requestHelper.addNewOutputData(LongSysnameType);
            requestHelper.getBindVariablePtr(dbSqlName);

            INT_T           progN = 0;

            if (requestHelper.sendCommandForFetch() == RET_SUCCEED)
            {
                while (requestHelper.fetch() == RET_SUCCEED)
                {
                    if (newDictEntityStp == nullptr)
                    {
                        OBJECT_ENUM locObjectEn = NullEntity;

                        bForceTarget = true;
                        DICT_CreateVirtualEntity(&locObjectEn,
                                                 sqlName.c_str(),
                                                 sqlName.c_str(),
                                                 sqlName.c_str(),
                                                 nullptr,
                                                 false,
                                                 dbiConn,
                                                 false);

                        newDictEntityStp = DBA_GetDictEntitySt(locObjectEn);
                        if (newDictEntityStp != nullptr)
                        {
                            newDictEntityStp->xdStatusEn = XdStatus_Inserted;
                            newDictEntityStp->entNatEn = EntityNat_Internal;
                        }
                    }

                    DICT_T attrDictId = (newDictEntityStp->entDictId * 1000) - (progN + 1);
                    auto &newDictAttribSt = newDictEntityStp->addDictAttrib(attrDictId, progN, attribName);
                    newDictAttribSt.dataTpProgN = DATATYPE_DICT_TO_ENUM(*datatypeDictId);
                    newDictEntityStp->attr.push_back(&newDictAttribSt);
                    progN++;
                }
            }
        }
    }

    if (newDictEntityStp != nullptr)
    {
        if (bForceTarget)
        {
            for (auto dbSectionIt = EV_SourceCfgFile->dbSectionMap.begin(); dbSectionIt != EV_SourceCfgFile->dbSectionMap.end(); ++dbSectionIt)
            {
                if (dbSectionIt->second.dbSqlName == newDictEntityStp->databaseName)
                {
                    auto targetDbSectionIt = EV_TargetCfgFile->dbSectionMap.find(dbSectionIt->second.dbFct);
                    if (targetDbSectionIt != EV_TargetCfgFile->dbSectionMap.end())
                    {
                        newDictEntityStp->databaseName = targetDbSectionIt->second.dbSqlName;
                        break;
                    }
                }
            }

            DBA_UpdDictCriteria(newDictEntityStp->objectEn, false);
            DBA_CreateDynStDef(newDictEntityStp->objectEn);
            DBA_GenerateAllAttrib(newDictEntityStp->objectEn);
        }

        newDictEntityStp->init(true);

        if (newDictEntityStp->attribMap.empty() == false)
        {
            newDictEntityStp->xdStatusEn = XdStatus_Inserted;
        }
    }

    return newDictEntityStp;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getAllTablesFromSys()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14556 - LJE - 120705
**
*************************************************************************/
std::map<std::string, std::map<std::string, std::set<std::string>>> DdlGenDbi::getAllTablesFromSys()
{
    std::map<std::string, std::map<std::string, std::set<std::string>>> allTablesMap;

    if (EV_UseAlternativeDataSource &&
        EV_SourceCfgFile != nullptr &&
        EV_SourceRdbmsVendor == Sybase)
    {
        for (auto dbSectionIt = EV_SourceCfgFile->dbSectionMap.begin(); dbSectionIt != EV_SourceCfgFile->dbSectionMap.end(); ++dbSectionIt)
        {
            if (dbSectionIt->first == "AAALOGIN_DB" ||
                dbSectionIt->first == "AAAMAIN_DB")
            {
                DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);
                DbiConnection *dbiConn = &ddlGenConnGuard.getDbiConn();
                RequestHelper  requestHelper(dbiConn);
                requestHelper.setReadOnly(true);
                requestHelper.m_useAlternativeDataServer = true;

                stringstream requestStream;

                requestStream
                    << "select so.name, sc.name from " << dbSectionIt->second.dbSqlName << "..sysobjects so "
                    << "inner join " << dbSectionIt->second.dbSqlName << "..syscolumns sc on sc.id = so.id "
                    << "where so.type = 'U'";

                requestHelper.setCommand(requestStream.str());

                char *tableName = nullptr;
                char *colName = nullptr;

                requestHelper.addNewOutputData(LongSysnameType);
                requestHelper.getBindVariablePtr(tableName);
                requestHelper.addNewOutputData(LongSysnameType);
                requestHelper.getBindVariablePtr(colName);

                auto &tablesSet = allTablesMap[dbSectionIt->second.dbSqlName];

                if (requestHelper.sendCommandForFetch() == RET_SUCCEED)
                {
                    while (requestHelper.fetch() == RET_SUCCEED)
                    {
                        tablesSet[tableName].insert(colName);
                    }
                }
            }
        }
    }

    return allTablesMap;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::printSecurityOnFrom()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-43626 - LJE - 210309
**
*************************************************************************/
std::string DdlGenDbi::getTableWithSecurity(DICT_ENTITY_STP locDictEntityStp, TARGET_TABLE_ENUM locTargetTableEn, const string& databaseName, const string& tableName)
{
    if (this->ddlGenContextPtr->m_rdbmsEn == Nuodb &&
        this->ddlGenContextPtr->getViewEn() == View_FullAll4ForeignKey &&
        locTargetTableEn == TargetTable_Main &&
        this->ddlGenContextPtr->isEnableSecuOnFkView() == true)
    {
        stringstream fromStream, whereStream, queryStream;

        this->printSecurityOnFrom(locDictEntityStp->securityLevelEn,
                                  true,
                                  true,
                                  this->getAlias(true),
                                  string(),
                                  fromStream);

        if (fromStream.str().empty())
        {
            fromStream << this->getTableFullDbName(databaseName, string(), tableName) << " " << this->getAlias(true);
        }

        queryStream
            << this->newLine() << "(select "
            << this->newLine() << "/*+no_merge*/ "
            << this->newLine() << this->getAlias() << "*"
            << this->newLine() << "from "
            << this->newLine() << fromStream.str();

        /* Add entity security */
        this->printSecurityOnWhere(locDictEntityStp->securityLevelEn,
                                   locDictEntityStp,
                                   true,
                                   this->getAlias(),
                                   whereStream);

        queryStream << this->addFromStream.str()
            << this->newLine() << whereStream.str();

        this->addFromStream.clear();
        this->addFromStream.str(string());

        this->ddlGenContextPtr->bSecurityDone = true;

        queryStream << ")";

        return queryStream.str();
    }
    else
    {
        return this->getTableFullDbName(databaseName, string(), tableName);
    }
}


/************************************************************************
**
**  Function    :   DdlGenDbi::printSecurityOnFrom()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:  PMSTA-43626 - LJE - 210309
**
*************************************************************************/
std::string  DdlGenDbi::getSecuOnBothDSP(std::string entityAlias)
{
    stringstream locStream;

    if (this->ddlGenContextPtr->m_rdbmsEn == Nuodb)
    {
        locStream
            << "         and (dpc1.data_secu_prof_id in (" << entityAlias << "data_secu_prof_id, " << entityAlias << "data_secu_prof2_id))";
    }
    else
    {
        locStream
            << "         and ((" << entityAlias << "data_secu_prof_id  = dpc1.data_secu_prof_id)  or" << this->newLine()
            << "              (" << entityAlias << "data_secu_prof2_id = dpc1.data_secu_prof_id))";
    }

    return locStream.str();
}



/************************************************************************
**
**  Function    :   DdlGenTable::getTargetDBName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37366 - LJE - 200204
**
*************************************************************************/
std::string DdlGenDbi::getTargetDBName()
{
    return this->getDdlGenContextPtr()->getDdlDestDbName();
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getEntitySqlName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26250 - LJE - 170407
**
*************************************************************************/
string DdlGenDbi::getEntitySqlName(DICT_ENTITY_STP locDictEntityStp, TARGET_TABLE_ENUM locTargetTableEn, bool bMdSqlName)
{
    string entitySqlName;

    if (locTargetTableEn == TargetTable_Undefined)
    {
        locTargetTableEn = this->targetTableEn;
    }

    if (locTargetTableEn == TargetTable_UserDefinedFields)
    {
        entitySqlName = locDictEntityStp->custSqlName;
    }
    else if (locTargetTableEn == TargetTable_Precomp)
    {
        entitySqlName = locDictEntityStp->precompSqlName;
    }
    else if (bMdSqlName)
    {
        entitySqlName = locDictEntityStp->mdSqlName;
    }
    else
    {
        entitySqlName = this->getEntityDbSqlName(locDictEntityStp, locDictEntityStp->mdSqlName);
    }

    if (entitySqlName.empty() &&
        locDictEntityStp->linkedEntityStp != nullptr)
    {
        if (locTargetTableEn == TargetTable_UserDefinedFields)
        {
            entitySqlName = locDictEntityStp->linkedEntityStp->custSqlName;
        }
        else if (locTargetTableEn == TargetTable_Precomp)
        {
            entitySqlName = locDictEntityStp->linkedEntityStp->precompSqlName;
        }
        else if (bMdSqlName || locTargetTableEn == TargetTable_LocalBusinessEntity)
        {
            entitySqlName = locDictEntityStp->linkedEntityStp->mdSqlName;
        }
        else
        {
            entitySqlName = this->getEntityDbSqlName(locDictEntityStp->linkedEntityStp, 
                                                     locDictEntityStp->linkedEntityStp->mdSqlName);
        }
    }

    this->m_bCustInView = false;

    if (this->ddlGenContextPtr != nullptr)
    {
        /* PMSTA-26108 - LJE - 170904 */
        if (locDictEntityStp->multiEntityCateg.isUseMeViewAsTable() &&
            locTargetTableEn == TargetTable_Main &&
            this->m_ddlObjEn != DdlObj_Table &&
            this->m_ddlObjEn != DdlObj_TempTable &&
            this->m_ddlObjEn != DdlObj_Constraint &&
            this->m_ddlObjEn != DdlObj_ForeignKey &&
            this->m_ddlObjEn != DdlObj_PrimaryKey &&
            this->m_ddlObjEn != DdlObj_Trigger &&
            this->m_ddlObjEn != DdlObj_TriggerUdField &&
            this->m_ddlObjEn != DdlObj_Index &&
            (this->ddlGenContextPtr->getDdlGenMode() != DdlGenMode_Shadow || locDictEntityStp->shadowEntityStp == nullptr) &&
            (this->ddlGenContextPtr->getViewEn() == View_Tech ||
             (this->ddlGenContextPtr->getDdlGenMode() != DdlGenMode_MultiEntity &&
              this->ddlGenContextPtr->bAvoidMultiEntity == false &&
              this->ddlGenContextPtr->bForceTableName == false)))
        {
            this->m_bCustInView = true;
            entitySqlName.append("_me");
        }
        else if (locTargetTableEn == TargetTable_LocalBusinessEntity)
        {
            if (locDictEntityStp->beEntityStp != nullptr)
            {
                entitySqlName = this->getEntityDbSqlName(locDictEntityStp->beEntityStp,
                                                         locDictEntityStp->beEntityStp->mdSqlName);
            }
            else if (locDictEntityStp->linkedEntityStp != nullptr &&
                     locDictEntityStp->linkedEntityStp->beEntityStp != nullptr)
            {
                if (locDictEntityStp->dbRuleEn == DbRule_ShadowTable &&
                    locDictEntityStp->linkedEntityStp->beEntityStp->shadowEntityStp != nullptr)
                {
                    entitySqlName = this->getEntityDbSqlName(locDictEntityStp->linkedEntityStp->beEntityStp->shadowEntityStp,
                                                             locDictEntityStp->linkedEntityStp->beEntityStp->shadowEntityStp->mdSqlName);
                }
                else
                {
                    entitySqlName = this->getEntityDbSqlName(locDictEntityStp->linkedEntityStp->beEntityStp,
                                                             locDictEntityStp->linkedEntityStp->beEntityStp->mdSqlName);
                }
            }
        }

        if (this->ddlGenContextPtr->getDdlGenMode() == DdlGenMode_Shadow &&
            locDictEntityStp->changeSetAuthEn == FeatureAuth_Enable &&
            locTargetTableEn != TargetTable_Precomp &&
            locDictEntityStp->dbRuleEn != DbRule_ShadowTable)
        {
            entitySqlName.append("_");
        }
        else if (this->ddlGenContextPtr->ddlGenAction.m_targetSqlnameStr.empty() == false)
        {
            entitySqlName = this->ddlGenContextPtr->ddlGenAction.m_targetSqlnameStr;
        }
        else if (this->ddlGenContextPtr->m_bLightContext == false && this->ddlGenContextPtr->m_bIgnoreDepends == false)
        {
            this->ddlGenContextPtr->m_dependsEntityMap.insert(make_pair(locDictEntityStp->mdSqlName, locDictEntityStp));
        }
    }

    return (entitySqlName);
}

/************************************************************************
**
**  Function    : DdlGenDbi::printPkSecuInfo()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation    :
**
**  Last modif. : PMSTA-32315 - 260718 - PMO : Improve error message "WUI User does not have Data Security Access..."
**
*************************************************************************/
void DdlGenDbi::printPkSecuInfo(const DictSprocClass& procSt, stringstream& outStream)
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:

            outStream << endl
                << newLine() << "if @@rowcount = 0 "
                << newLine() << "and exists (select id from " << this->getEntityFullSqlName(procSt.getDictEntityStp(), TargetTable_Undefined, string(), View_None) << " where id = @id)"
                << newLine() << "begin";

            this->setIndent(1);
            outStream << newLine() << "declare @obj_code	code_t,"
                << newLine() << "        @user_code	code_t,"
                << newLine() << "        @data_profile_code code_t,"
                << newLine() << "        @dp_id_from_appctx id_t"
                << newLine() << "select @obj_code = code from " << this->getEntityFullSqlName(procSt.getDictEntityStp(), TargetTable_Undefined, string(), View_None) << " where id = @id"
                << newLine() << "select @dp_id_from_appctx = " << DdlGenDbi::getCmdDataProfileId()
                << newLine() << "if ( @dp_id_from_appctx is null ) "
                << newLine() << "begin "
                << newLine() << "	select @obj_code = code from " << this->getEntityFullSqlName(procSt.getDictEntityStp(), TargetTable_Undefined, string(), View_None) << " where id = @id"
                << newLine() << "	select @user_code = " << this->getCmdUserName()
                << newLine() << "	select @data_profile_code = code from data_profile where id = @data_profile_id"
                << newLine() << "	" << this->getExecMainDbCall("appl_raiserror") << " 20128, " << this->getDdlObjSqlName() << ", @user_code, @data_profile_code, @obj_code, '"
                << this->getEntityFullSqlName(procSt.getDictEntityStp(), TargetTable_Undefined, string(), View_None) << "'"
                << newLine() << "end"
                << newLine() << "else"
                << newLine() << "begin"
                << newLine() << "	select @data_profile_code = code from data_profile where id = @dp_id_from_appctx "
                << newLine() << "	select @user_code = 'WUI User'"
                << newLine() << "	" << this->getExecMainDbCall("appl_raiserror") << " " << RET_WUI_USER_DOES_NOT_HAVE_DATA_SECURITY_ACCESS << ", " << this->getDdlObjSqlName() << ", @user_code, @data_profile_code, @obj_code, '"    /* PMSTA-32315 - 260718 - PMO */
                << this->getEntityFullSqlName(procSt.getDictEntityStp(), TargetTable_Undefined, string(), View_None) << "'"
                << newLine() << "end" << this->getCmdEndOfCmd();

            this->setIndent(-1);

            outStream << newLine() << "end" << this->getCmdEndOfCmd() << endl;
            break;

        case Oracle:
            break;
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdIfThenElse()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdIfThenElse(const string& condition, const string& thenPart, const string& elsePart, bool bElseIf, bool bToContinue)
{
    stringstream      outStream;
    string            ifStr = "if ";
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
            if (bElseIf)
            {
                ifStr = "else if ";
            }
            outStream
                << this->getIndent() << ifStr << condition;
            if (condition.length() == 0 ||
                condition.at(condition.length() - 1) != '\n')
            {
                outStream << "\n";
            }
            outStream
                << this->getIndent() << "begin";
            this->setIndent(1);
            outStream
                << endl << thenPart;
            if (thenPart.length() == 0 ||
                thenPart.at(thenPart.length() - 1) != '\n')
            {
                outStream << "\n";
            }
            this->setIndent(-1);
            outStream
                << this->getIndent() << "end";

            if (elsePart.empty() == false)
            {
                outStream
                    << this->newLine() << "else"
                    << this->newLine() << "begin";
                this->setIndent(1);
                outStream
                    << endl << elsePart;
                if (elsePart.length() == 0 ||
                    elsePart.at(elsePart.length() - 1) != '\n')
                {
                    outStream << "\n";
                }
                this->setIndent(-1);
                outStream
                    << this->getIndent() << "end";
            }
            break;

        case Oracle:
            if (bElseIf)
            {
                ifStr = "elsif ";
            }
            outStream
                << this->getIndent() << ifStr << condition;
            if (condition.length() == 0 ||
                condition.at(condition.length() - 1) != '\n')
            {
                outStream << "\n";
            }
            outStream
                << this->getIndent() << "then";
            this->setIndent(1);
            outStream
                << endl << thenPart;
            this->setIndent(-1);

            if (elsePart.empty() == false)
            {
                outStream
                    << this->newLine() << "else";
                this->setIndent(1);
                outStream
                    << endl << elsePart;
                if (elsePart.length() == 0 ||
                    elsePart.at(elsePart.length() - 1) != '\n')
                {
                    outStream << "\n";
                }
                this->setIndent(-1);
            }

            if (bToContinue == false)
            {
                outStream << this->getEndIf();
            }
            break;

        case Nuodb:
            if (bElseIf)
            {
                ifStr = "else if ";
            }
            outStream
                << this->getIndent() << ifStr << "(" << condition << this->getIndent() << ")";
            if (condition.length() == 0 ||
                condition.at(condition.length() - 1) != '\n')
            {
                outStream << "\n";
            }
            this->setIndent(1);
            outStream
                << endl << thenPart;
            if (thenPart.length() == 0 ||
                thenPart.at(thenPart.length() - 1) != '\n')
            {
                outStream << "\n";
            }
            this->setIndent(-1);
            if (elsePart.empty() == false)
            {
                outStream
                    << this->newLine() << "else";
                this->setIndent(1);
                outStream
                    << endl << elsePart;
                if (elsePart.length() == 0 ||
                    elsePart.at(elsePart.length() - 1) != '\n')
                {
                    outStream << "\n";
                }
                this->setIndent(-1);
            }

            this->elseIfCpt++;
            if (bToContinue == false)
            {
                while (this->elseIfCpt)
                {
                    outStream
                        << this->getIndent() << "end_if;";
                    this->elseIfCpt--;
                }
            }
            break;

        case MSSql:
            if (bElseIf)
            {
                ifStr = "else if ";
            }
            outStream
                << this->getIndent() << ifStr << condition;
            if (condition.length() == 0 ||
                condition.at(condition.length() - 1) != '\n')
            {
                outStream << "\n";
            }
            outStream
                << this->getIndent() << "begin";
            this->setIndent(1);
            outStream
                << endl << thenPart;
            if (thenPart.length() == 0 ||
                thenPart.at(thenPart.length() - 1) != '\n')
            {
                outStream << "\n";
            }
            this->setIndent(-1);
            outStream
                << this->getIndent() << "end;";

            if (elsePart.empty() == false)
            {
                outStream
                    << this->newLine() << "else"
                    << this->newLine() << "begin";
                this->setIndent(1);
                outStream
                    << endl << elsePart;
                if (elsePart.length() == 0 ||
                    elsePart.at(elsePart.length() - 1) != '\n')
                {
                    outStream << "\n";
                }
                this->setIndent(-1);
                outStream
                    << this->getIndent() << "end;";
            }
            break;

        case PostgreSQL:
            if (bElseIf)
            {
                ifStr = "elsif ";
            }
            outStream
                << this->getIndent() << ifStr << condition;
            if (condition.length() == 0 ||
                condition.at(condition.length() - 1) != '\n')
            {
                outStream << "\n";
            }
            outStream
                << this->getIndent() << "then";
            this->setIndent(1);
            outStream
                << endl << thenPart;
            this->setIndent(-1);

            if (elsePart.empty() == false)
            {
                outStream
                    << this->newLine() << "else";
                this->setIndent(1);
                outStream
                    << endl << elsePart;
                if (elsePart.length() == 0 ||
                    elsePart.at(elsePart.length() - 1) != '\n')
                {
                    outStream << "\n";
                }
                this->setIndent(-1);
            }

            if (bToContinue == false)
            {
                outStream << this->getEndIf();
            }
            break;



        default:
            SYS_BreakOnDebug();
    }

    return outStream.str();
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getEndIf()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getEndIf(bool bEndIfExists)
{
    stringstream      outStream;

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case MSSql:
            break;

        case Oracle:
            if (bEndIfExists)
            {
                outStream
                    << this->getIndent() << "end" << this->getCmdEndOfCmd();
            }
            else
            {
                outStream
                    << this->getIndent() << "end if" << this->getCmdEndOfCmd();
            }
            break;

        case Nuodb:
            outStream
                << this->getIndent() << "end_if" << this->getCmdEndOfCmd();
            break;

        case PostgreSQL:
            if (bEndIfExists == false)
            {
                outStream
                    << this->getIndent() << "end if" << this->getCmdEndOfCmd();
            }
            break;

        default:
            SYS_BreakOnDebug();
    }

    return outStream.str();
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdIfThen()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdIfThen(const string& condition, const string& thenPart, bool bNot)
{
    string newCondition;
    if (bNot)
    {
        newCondition = "not (" + condition + ")";
    }
    return getCmdIfThenElse((newCondition.empty() ? condition : newCondition), thenPart, string());
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdIfExsists()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdIfExsists(const string& selectRequest, const string& ifExistsCmd, const string& ifNotExistsCmd, bool bNotExists)
{
    return getCmdIfExsists(string(), selectRequest, ifExistsCmd, ifNotExistsCmd, bNotExists);
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdIfExsists()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdIfExsists(const string& test, const string& selectRequest, const string& ifExistsCmd, const string& ifNotExistsCmd, bool bNotExists, bool bToContinue)
{
    stringstream      bodyStream;

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
            bodyStream << this->newLine() << "if " << test << (test.empty() ? "" : " ");
            if (selectRequest.empty() == false)
            {
                bodyStream << (bNotExists ? "not " : "") << "exists (" << selectRequest << ")" << endl;
            }

            bodyStream << this->getIndent() << "begin";
            this->setIndent(1);
            bodyStream << endl << ifExistsCmd;
            this->setIndent(-1);
            bodyStream << this->newLine() << "end" << endl;
            if (ifNotExistsCmd.empty() == false)
            {
                bodyStream << this->getIndent() << "else";
                bodyStream << this->newLine() << "begin";
                this->setIndent(1);
                bodyStream << endl << ifNotExistsCmd;
                this->setIndent(-1);
                bodyStream << this->newLine() << "end" << endl;
            }
            break;

        case Oracle:
            bodyStream << this->newLine() << "declare";
            this->setIndent(1);
            bodyStream << this->newLine() << "o_exst number(1);";
            this->setIndent(-1);
            bodyStream << this->newLine() << "begin";
            this->setIndent(1);
            bodyStream << this->newLine() << "select case";
            bodyStream << this->newLine() << "when " << test << (test.empty() ? "" : " ");
            if (selectRequest.empty() == false)
            {
                bodyStream << (bNotExists ? "not " : "") << "exists (" << selectRequest << ")" << endl;
            }
            bodyStream << this->newLine() << "then 1";
            bodyStream << this->newLine() << "else 0";
            bodyStream << this->newLine() << "end into o_exst from dual;" << endl;

            bodyStream << this->newLine() << "if o_exst = 1";
            bodyStream << this->newLine() << "then";
            this->setIndent(1);
            bodyStream << endl << ifExistsCmd;
            this->setIndent(-1);
            if (ifNotExistsCmd.empty() == false)
            {
                bodyStream << this->newLine() << "else";
                this->setIndent(1);
                bodyStream << endl << ifNotExistsCmd;
                this->setIndent(-1);
            }

            if (bToContinue == false)
            {
                bodyStream << this->getEndIfExists();
            }
            else
            {
                this->recurseEndCpt++;
            }
            break;

        case Nuodb:
        {
            string newTest;

            bodyStream << this->newLine() << "if (" << (newTest.empty() == false ? newTest : test) << (test.empty() ? "" : " ");
            if (selectRequest.empty() == false)
            {
                bodyStream << (bNotExists ? "(not " : "") << "exists (" << selectRequest << ")" << (bNotExists ? ")" : "") << this->newLine();
            }
            bodyStream << this->getIndent() << ")";

            this->setIndent(1);
            bodyStream << endl << ifExistsCmd;
            this->setIndent(-1);
            if (ifNotExistsCmd.empty() == false)
            {
                bodyStream << this->newLine() << "else";
                this->setIndent(1);
                bodyStream << endl << ifNotExistsCmd;
                this->setIndent(-1);
            }
            if (bToContinue == false)
            {
                bodyStream << this->newLine() << "end_if;" << endl;
            }
            else
            {
                this->recurseEndCpt++;
            }
        }
        break;

        case MSSql:
            bodyStream << this->newLine() << "if " << test << (test.empty() ? "" : " ");
            if (selectRequest.empty() == false)
            {
                bodyStream << (bNotExists ? "not " : "") << "exists (" << selectRequest << ")" << endl;
            }

            bodyStream << this->getIndent() << "begin";
            this->setIndent(1);
            bodyStream << endl << ifExistsCmd;
            this->setIndent(-1);
            bodyStream << this->newLine() << "end;" << endl;
            if (ifNotExistsCmd.empty() == false)
            {
                bodyStream << this->getIndent() << "else";
                bodyStream << this->newLine() << "begin";
                this->setIndent(1);
                bodyStream << endl << ifNotExistsCmd;
                this->setIndent(-1);
                bodyStream << this->newLine() << "end;" << endl;
            }
            break;

        case PostgreSQL:
            bodyStream << this->newLine() << "if " << test << (test.empty() ? "" : " ");
            if (selectRequest.empty() == false)
            {
                bodyStream << (bNotExists ? "not " : "") << "exists (" << selectRequest << ")" << endl;
            }

            bodyStream << this->getIndent() << "then";
            this->setIndent(1);
            bodyStream << endl << ifExistsCmd;
            this->setIndent(-1);
            if (ifNotExistsCmd.empty() == false)
            {
                bodyStream << this->newLine() << "else";
                this->setIndent(1);
                bodyStream << endl << ifNotExistsCmd;
                this->setIndent(-1);
            }
            if (bToContinue == false)
            {
                bodyStream << this->newLine() << "end if;" << endl;
            }
            else
            {
                this->recurseEndCpt++;
            }
            break;

        default:
            SYS_BreakOnDebug();

    }

    return bodyStream.str();
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdExists()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
std::string DdlGenDbi::getCmdExists(bool bNot, std::string &closeCmd)
{
    stringstream      bodyStream;
    closeCmd.clear();

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case Oracle:
        case MSSql:
        case PostgreSQL:
            if (bNot)
            {
                bodyStream << "not ";
            }
            bodyStream << "exists";
            break;

        case Nuodb:
            if (bNot)
            {
                bodyStream << "(not exists";
                closeCmd = this->getIndent() + ") ";
            }
            else
            {
                bodyStream << "exists";
            }
            break;

        default:
            SYS_BreakOnDebug();
    }

    return bodyStream.str();
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getEndIfExists()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getEndIfExists()
{
    stringstream      bodyStream;

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case MSSql:
            break;

        case Oracle:
            bodyStream << this->newLine() << "end if;";
            this->setIndent(-1);
            bodyStream << this->newLine() << "end;" << endl;
            break;

        case Nuodb:
            bodyStream << this->newLine() << "end_if;";
            this->setIndent(-1);
            break;

        case PostgreSQL:
            bodyStream << this->newLine() << "end if;";
            break;

        default:
            SYS_BreakOnDebug();
    }

    return bodyStream.str();
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdWhile()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdWhile(string test, string whileRequest)
{
    stringstream      bodyStream;
    string::iterator itEndStr = test.end() - 1;

    if (*itEndStr == '\n')
    {
        test.erase(itEndStr);
    }

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
            bodyStream
                << this->newLine() << "while " << test
                << this->newLine() << "begin"
                << this->newLine() << whileRequest
                << this->newLine() << "end";
            break;

        case Oracle:
        case PostgreSQL:
            bodyStream
                << this->newLine() << "while " << test
                << this->newLine() << "loop"
                << this->newLine() << whileRequest
                << this->newLine() << "end loop";
            break;

        case Nuodb:
            bodyStream
                << this->newLine() << "while (" << test << ")"
                << this->newLine() << whileRequest
                << this->newLine() << "end_while";
            break;

        case MSSql:
            bodyStream
                << this->newLine() << "while " << test
                << this->newLine() << "begin"
                << this->newLine() << whileRequest
                << this->newLine() << "end;";
            break;

        default:
            SYS_BreakOnDebug();

    }
    bodyStream << this->getCmdEndOfCmd();

    return bodyStream.str();
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getSetRowcount()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getSetRowcount()
{
    stringstream outStream;

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
            if (this->varHelperPtr->rowCount.empty() == false)
            {
                outStream << this->getIndent() << "set rowcount " << this->varHelperPtr->rowCount;
            }
            break;

        case Oracle:
        case Nuodb:
        case PostgreSQL:
            break;

        case MSSql:
            if (this->ddlGenContextPtr->getDdlObjEn() != DdlObj_Func && this->varHelperPtr->rowCount.empty() == false)
            {
                /* set rowcount is not allowed inside a function in Sql Server.
                   See printRowLimitOnWhere
                */
                outStream << this->getIndent() << "set rowcount " << this->varHelperPtr->rowCount;
            }
            break;
        default:
            SYS_BreakOnDebug();
    }
    return outStream.str();
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getSetDateFirst()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getSetDateFirst()
{
    stringstream outStream;

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case MSSql:
            outStream << this->getIndent() << "set datefirst " << this->varHelperPtr->dateFirstEn;
            break;

        case Oracle:
        case Nuodb:
        case PostgreSQL:
            break;

        default:
            SYS_BreakOnDebug();
    }
    return outStream.str();
}
/************************************************************************
**
**  Function    :   DdlGenDbi::getRowLimitOnWhere()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
void DdlGenDbi::printRowLimitOnWhere(stringstream& limitStream)
{
    if (this->varHelperPtr->rowCount.empty() == false)
    {
        stringstream outStream;

        switch (this->ddlGenContextPtr->m_rdbmsEn)
        {
            case Sybase:
                break;

            case Oracle:
            case PostgreSQL:
                if (atoi(this->varHelperPtr->rowCount.c_str()) != 0 ||
                    this->varHelperPtr->rowCount.at(0) == '@')
                {
                    limitStream << this->newLine() << "fetch first " << this->varHelperPtr->rowCount << " rows only";
                }
                break;

            case Nuodb:
                if (atoi(this->varHelperPtr->rowCount.c_str()) != 0 ||
                    this->varHelperPtr->rowCount.at(0) == '@')
                {
                    limitStream << this->newLine() << "LIMIT " << this->varHelperPtr->rowCount;
                }
                break;

            case MSSql:
                if (this->ddlGenContextPtr->getDdlObjEn() == DdlObj_Func &&
                    (atoi(this->varHelperPtr->rowCount.c_str()) != 0 ||
                     this->varHelperPtr->rowCount.at(0) == '@'))
                {
                    /* set rowcount is not allowed inside a function in Sql Server.
                       Mandatory to have ORDER BY clause in the query, to use this method.
                    */
                    limitStream << this->newLine() << "offset 0 row fetch first " << this->varHelperPtr->rowCount << " rows only";;
                }
                break;

            default:
                SYS_BreakOnDebug();
        }
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdAssignBySelect()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdAssignBySelect(DdlGenVar& variable, string assignValue, string fromWhere)
{
    stringstream   outStream;
    stringstream   finalAssignStream, initAssignStream, emptyStream;

    outStream << this->getIndent() << "select ";
    outStream << this->getCmdAssignOnSelect(variable,
                                            assignValue, 
                                            finalAssignStream, 
                                            initAssignStream, 
                                            fromWhere.empty(), 
                                            (variable.varType != VarType_OverParameter));

    outStream << finalAssignStream.str() << " " << (fromWhere.empty() == false ? fromWhere : "");

    if (this->ddlGenContextPtr->m_rdbmsEn == Oracle && fromWhere.empty() == false)
    {
        emptyStream << "    " << variable.printSqlName() << " := NULL" << this->endOfCmd();
    }

    return getCmdSelect(outStream.str(), string(), initAssignStream.str());
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdAssignOnSelect()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdAssignOnSelect(DdlGenVar& variable, string assignValue, stringstream& finalAssignStream, stringstream& initAssignStream, bool bLastAssign, bool bModify)
{
    stringstream      outStream;

    if (this->getDdlGenFromFileContextPtr() != nullptr)
    {
        this->getDdlGenFromFileContextPtr()->m_bInBlock = true;
    }

    if (bModify)
    {
        this->varHelperPtr->setModify(variable);
    }

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case MSSql:
            outStream << variable.printSqlName(DdlGenVar::KindOfPrint::Assign) << " = " << assignValue;
            break;

        case Oracle:
            outStream << assignValue;
            if (finalAssignStream.str().empty())
            {
                finalAssignStream << " into ";
            }
            else
            {
                finalAssignStream << ", ";
            }
            finalAssignStream << variable.printSqlName(DdlGenVar::KindOfPrint::Assign);

            if (bLastAssign)
            {
                finalAssignStream << " from dual";
            }
            break;

        case Nuodb:
            if (initAssignStream.str().empty() == false)
            {
                initAssignStream << ", ";
            }
            initAssignStream << variable.printSqlName(DdlGenVar::KindOfPrint::Assign);
            outStream << assignValue;

            if (bLastAssign)
            {
                finalAssignStream << " from dual";
            }
            break;

        case PostgreSQL:
            outStream << assignValue;
            if (finalAssignStream.str().empty())
            {
                finalAssignStream << " into ";
            }
            else
            {
                finalAssignStream << ", ";
            }
            finalAssignStream << variable.printSqlName(DdlGenVar::KindOfPrint::Assign);
            break;

        default:
            SYS_BreakOnDebug();
    }

    return outStream.str();
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdSelect()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdSelect(const string& selectStr, const string& cursorStr, const std::string& initStr)
{
    stringstream   outStream;

    if (initStr.empty() == false)
    {
        outStream << this->getIndent() << initStr << " = (" << endl;
    }

    if (cursorStr.empty())
    {
        switch (this->ddlGenContextPtr->m_rdbmsEn)
        {
            case Sybase:
            case Nuodb:
            case MSSql:
            case Sqlite:
            case PostgreSQL:
            case QtHttp:
                break;

            case Oracle:
                if (this->bUnion == false && 
                    (this->getDdlGenFromFileContextPtr() == nullptr || this->getDdlGenFromFileContextPtr()->m_bInBlock))
                {
                    outStream << this->getIndent() << this->getExceptionBegin() << "\t";
                }
                break;

            default:
                SYS_BreakOnDebug();
        }
    }
    outStream << selectStr;

    if (cursorStr.empty())
    {
        switch (this->ddlGenContextPtr->m_rdbmsEn)
        {
            case Sybase:
            case MSSql:
            case Sqlite:
            case QtHttp:
                break;

            case Oracle:
                if (this->bUnion == false &&
                    (this->getDdlGenFromFileContextPtr() == nullptr || this->getDdlGenFromFileContextPtr()->m_bInBlock))
                {
                    outStream
                        << this->getCmdEndOfCmd()
                        << this->getIndent() << this->getException()
                        << this->newLine() << "\tNULL;"
                        << this->getIndent() << this->getExceptionEnd();
                }
                break;

            case Nuodb:
                if (this->bUnion == false)
                {
                    if (initStr.empty())
                    {
                        outStream << this->getIndent() << this->getCmdEndOfCmd();
                    }
                    else
                    {
                        outStream << this->getIndent() << ")" << this->getCmdEndOfCmd();
                    }
                }
                break;

            case PostgreSQL:
                if (this->bUnion == false && this->getDdlObjEn() != DdlObj_RuntimeSql)
                {
                    outStream << this->getIndent() << this->getCmdEndOfCmd();
                }
                break;

            default:
                SYS_BreakOnDebug();
        }
    }
    else if (this->bUnion == false)
    {
        outStream << this->getCmdEndOfCmd() << cursorStr;
    }

    return outStream.str();
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdInsert()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdInsert(const string &insertStr, const string &onDupKeyStr)
{
    stringstream   outStream;

    if (onDupKeyStr.empty() == false)
    {
        switch (this->ddlGenContextPtr->m_rdbmsEn)
        {
            case Sybase:
            case Sqlite:
            case QtHttp:
                break;

            case MSSql:
            case Oracle:
            case Nuodb:
            case PostgreSQL:
                outStream << this->getIndent() << this->getExceptionBegin() << "    ";
                break;
        }
    }
    outStream << insertStr;
    if (onDupKeyStr.empty() == false)
    {
        switch (this->ddlGenContextPtr->m_rdbmsEn)
        {
            case Sybase:
                outStream
                    << this->getIndent() << "if @@error = 2601 /* Duplicate key */"
                    << this->newLine() << "begin"
                    << this->newLine() << "\traiserror 99999 '2601'"
                    << this->newLine() << "\t" << onDupKeyStr
                    << this->getIndent() << "end";
                break;

            case MSSql:
            {
                  outStream
                    << this->getIndent() << this->getException("ERROR_NUMBER() = 2601 /* Duplicate key */")
                    << this->newLine() << "\t" << onDupKeyStr
                    << this->getIndent() << this->getExceptionEnd();
                break;
            }

            case Oracle:
                outStream
                    << this->getIndent() << this->getException("dup_val_on_index")
                    << this->newLine() << "\t" << onDupKeyStr
                    << this->getIndent() << this->getExceptionEnd();
                break;

            case Nuodb:
                outStream
                    << this->getIndent() << this->getException("error")
                    << this->newLine() << "\t" << onDupKeyStr
                    << this->getIndent() << this->getExceptionEnd();
                break;

            case Sqlite:
            case QtHttp:
                break;

            case PostgreSQL:
                outStream
                    << this->getIndent() << this->getException("unique_violation ")
                    << this->newLine() << "    " << onDupKeyStr
                    << this->getIndent() << this->getExceptionEnd();
                break;

            default:
                SYS_BreakOnDebug();
        }
    }
    return outStream.str();
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdRename()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdRename(const string& fromSqlName, const string& toSqlName, DDL_OBJ_ENUM ddlObjType)
{
    stringstream   outStream;

    if (ddlObjType == DdlObj_Table)
    {
        switch (this->ddlGenContextPtr->m_rdbmsEn)
        {
            case Sybase:
                outStream
                    << this->getIndent() << "sp_rename " << fromSqlName << ", " << toSqlName;
                break;
            case MSSql:
                outStream
                    << this->getIndent() << "sp_rename \'" << this->getTargetDBName() << "." << fromSqlName << "\', " << toSqlName;
                break;
            case Oracle:
            case PostgreSQL:
                outStream
                    << this->getIndent() << this->getIndent() << "alter table " << fromSqlName << " rename to " << toSqlName;
                break;
            case Nuodb:
                outStream
                    << this->getIndent() << this->getIndent() << "rename table " << fromSqlName << " to " << toSqlName;
                break;
            default:
                SYS_BreakOnDebug();
        }
    }
    else if (ddlObjType == DdlObj_Column)
    {
        vector<string>  tokens;
        DdlGen::tokenizeStr(tokens, fromSqlName, ".");

        if (tokens.size() == 2)
        {
            switch (this->ddlGenContextPtr->m_rdbmsEn)
            {
                case Sybase:
                    outStream
                        << this->getIndent() << "sp_rename '" << fromSqlName << "', '" << toSqlName << "', 'column'";
                    break;
                case MSSql:
                    outStream
                        << this->getIndent() << "sp_rename \'" << this->getTargetDBName() << "." << fromSqlName << "\', " << toSqlName << ", 'COLUMN'";
                    break;
                case Oracle:
                case PostgreSQL:
                    outStream
                        << this->getIndent() << this->getIndent() << "alter table " << tokens[0] << " rename column " << tokens[1] << " to " << toSqlName;
                    break;
                case Nuodb:
                    outStream
                        << this->getIndent() << this->getIndent() << "alter table " << tokens[0] << " change column " << tokens[1] << " " << toSqlName;
                    break;
                default:
                    SYS_BreakOnDebug();
            }
        }
    }

    if (this->m_ddlObjEn == DdlObj_Migration)
    {
        return outStream.str();
    }
    return this->getDdlModif(outStream.str());
}

/************************************************************************
**
**  Function    :   DdlGenDbi::isOneRequestByAlter()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
bool DdlGenDbi::isOneRequestByAlter()
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Nuodb:
        case PostgreSQL:
            return true;
            break;

        case Sybase:
        case Oracle:
        default:
            return false;
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdAlterSepartor()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
std::string DdlGenDbi::getCmdAlterSepartor(bool bFirst)
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case Oracle:
        case MSSql:
            break;

        case PostgreSQL:
        case Nuodb:
            if (bFirst == false)
            {
                return ", ";
            }
            break;

        default:
            SYS_BreakOnDebug();
    }

    return string();
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdColAlterSepartor()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
std::string DdlGenDbi::getCmdColAlterSepartor(bool bFirst, bool bAddNewCol)
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case Oracle:
            break;

        case MSSql:
            if (bFirst == false && bAddNewCol == true)
            {
                return ", ";
            }
            break;

        case PostgreSQL:
        case Nuodb:
            if (bFirst == false)
            {
                return ", ";
            }
            break;

        default:
            SYS_BreakOnDebug();
    }

    return string();
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdModifyColumn()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
std::string DdlGenDbi::getCmdModifyColumn()
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case Oracle:
            return " modify ";
            break;

        case Nuodb:
        case PostgreSQL:
        case MSSql:
            return " alter column ";
            break;

        default:
            SYS_BreakOnDebug();
    }

    return string();
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdModifyDataType()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
std::string DdlGenDbi::getCmdModifyDataType()
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case Oracle:
        case MSSql:
            break;

        case Nuodb:
        case PostgreSQL:
            return " set data type";
            break;

        default:
            SYS_BreakOnDebug();
    }

    return string();
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdNoOp()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdNoOp(DdlGenFromFile* ddlGenFromFilePtr)
{
    stringstream noOpStream;
    switch (ddlGenFromFilePtr->getDdlGenContextPtr()->m_rdbmsEn)
    {
        case Sybase:
        case MSSql:
            noOpStream << "noop_" << ddlGenFromFilePtr->getDdlGenContextPtr()->iNoOpCpt++ << ": -- " << ddlGenFromFilePtr->context->currTag;
            break;
        case Oracle:
            noOpStream << "null; -- " << ddlGenFromFilePtr->context->currTag;
            break;
        case Nuodb:
            noOpStream << "-- " << ddlGenFromFilePtr->context->currTag;
            break;
        case PostgreSQL:
            noOpStream << "-- " << ddlGenFromFilePtr->context->currTag;
            break;
        default:
            SYS_BreakOnDebug();
    }
    return noOpStream.str();
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdAssignByValue()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdAssignByValue(DdlGenVar& variable, string assignValue)
{
    stringstream      outStream;

    this->varHelperPtr->setModify(variable);

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case MSSql:
            outStream << "set " << variable.printSqlName(DdlGenVar::KindOfPrint::Assign) << " = " << assignValue << this->getCmdEndOfCmd();
            break;

        case Oracle:
        case Nuodb:
            outStream << variable.printSqlName(DdlGenVar::KindOfPrint::Assign) << DdlGenDbi::getVarAssign(this->ddlGenContextPtr->m_rdbmsEn) << assignValue << this->getCmdEndOfCmd();
            break;

        case PostgreSQL:
            outStream << variable.printSqlName(DdlGenVar::KindOfPrint::Assign) << DdlGenDbi::getVarAssign(this->ddlGenContextPtr->m_rdbmsEn) << assignValue << this->getCmdEndOfCmd();
            break;

        default:
            SYS_BreakOnDebug();
    }

    if (variable.m_bModify == false &&
        variable.m_bAlias &&
        variable.varType == VarType_Variable &&
        variable.getCursorName().empty() == false &&
        variable.getDataType() != RecordType &&
        variable.getDataType() != TriggerType)
    {
        this->printMsg(RET_GEN_ERR_INVARG, "Unable to assign the cursor variable " + variable.sqlName + ", please use an additional variable");
    }

    return outStream.str();
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getTblFullName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getDdlFullName(string database, string ddlObjSqlName)
{
    string cmd;

    this->standardize(database);
    this->standardize(ddlObjSqlName);

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
            if (database.empty() == false)
            {
                cmd = database + "..";
            }
            cmd += ddlObjSqlName;
            break;

        case Oracle:
        case Nuodb:
        case MSSql:
        case PostgreSQL:
            if (database.empty() == false)
            {
                cmd = database + ".";
            }
            cmd += ddlObjSqlName;
            break;

        case Sqlite:
        case QtHttp:
            cmd = ddlObjSqlName;
            break;

        default:
            SYS_BreakOnDebug();
    }

    return cmd;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getEntityDbSqlName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getEntityDbSqlName(DICT_ENTITY_STP dictEntityStp, const char *sqlName)
{
    string entityDbSqlName;

    if (dictEntityStp != nullptr &&
        dictEntityStp->entNatEn == EntityNat_TempTable)
    {
        bool bForceTable = true;
        if (DdlGenDbi::getTempTableSpec(this->ddlGenContextPtr->m_rdbmsEn, dictEntityStp) == DdlGenDbi::TempTableSpec::Type &&
            (this->m_ddlObjEn == DdlObj_SProc || this->m_ddlObjEn == DdlObj_Trigger))
        {
            bForceTable = false;
            this->ddlGenContextPtr->m_addDeclareMap.insert(std::make_pair(dictEntityStp->mdSqlName,
                                                                          SYS_Stringer("declare @", dictEntityStp->mdSqlName, " dbo.t_", dictEntityStp->mdSqlName, ";")));
        }
        entityDbSqlName = DdlGenDbi::getTempTablePrefix(this->ddlGenContextPtr->m_rdbmsEn, dictEntityStp, bForceTable) + sqlName;
    }
    else
    {
        entityDbSqlName = sqlName;

        switch (this->ddlGenContextPtr->m_rdbmsEn)
        {
            case Oracle:
                if (entityDbSqlName.compare("synonym") == 0)
                {
                    entityDbSqlName = getSynonymSqlName();
                }
                else if (entityDbSqlName.compare("audit") == 0)
                {
                    entityDbSqlName = "audits";
                }
                break;

            case Nuodb:
                if (entityDbSqlName.compare("position") == 0)
                {
                    entityDbSqlName = "positions";
                }
                break;

            case Sybase:
            case MSSql:
            default:
                break;
        }
    }
    return entityDbSqlName;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getOptimisticLockingRule()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
OPTIMISTIC_LOCKING_ENUM DdlGenDbi::getOptimisticLockingRule(DICT_ATTRIB_STP dictAttribStp, DBA_RDBMS_ENUM rdbmsEn)
{
    static unsigned defOptimLockingRule = OptimisticLocking_None;

    if (dictAttribStp->dataTpProgN == TimeStampType &&
        dictAttribStp->isPhysicalAttribute())
    {
        switch (rdbmsEn)
        {
            case Sybase:
            case MSSql:
                return OptimisticLocking_DbAttrib;

            case Oracle:
                if (defOptimLockingRule == OptimisticLocking_None)
                {
                    defOptimLockingRule = SYS_GetEnvUnsignedOrDefValue("AAAOPTIMLOCKRULE", OptimisticLocking_RowVersion);
                }
                return (OPTIMISTIC_LOCKING_ENUM)defOptimLockingRule;

            case Nuodb:
            case Sqlite:
            case PostgreSQL:
            case QtHttp:
                return OptimisticLocking_RowVersion;

            default:
                SYS_BreakOnDebug();
        }
    }
    return OptimisticLocking_None;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getOptimisticLockingRule()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
OPTIMISTIC_LOCKING_ENUM DdlGenDbi::getOptimisticLockingRule(DICT_ATTRIB_STP dictAttribStp)
{
    return this->getOptimisticLockingRule(dictAttribStp, this->ddlGenContextPtr->m_rdbmsEn);
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getOptimisticLockingSqlName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getOptimisticLockingSqlName(DICT_ENTITY_STP locDictEntityStp)
{
    if (locDictEntityStp->optimisticLockingAttrStp != NULL)
    {
        OPTIMISTIC_LOCKING_ENUM optimLockingRuleEn = DdlGenDbi::getOptimisticLockingRule(locDictEntityStp->optimisticLockingAttrStp);

        if (optimLockingRuleEn == OptimisticLocking_RowScn)
        {
            return "ora_rowscn";
        }
        else if (optimLockingRuleEn == OptimisticLocking_RowVersion)
        {
            return "row_version";
        }
        else
        {
            return locDictEntityStp->optimisticLockingAttrStp->sqlName;
        }
    }
    return "";
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdDrop()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdDrop(string        database,
                             string        tableSqlName,
                             string        ddlObjSqlName,
                             DDL_OBJ_ENUM  ddlObjType,
                             DdlObjDef*    ddlObjDef,
                             string        refTableSqlName,
                             string        refAttribSqlName,
                             const string& userName)
{
    string cmd;

    this->standardize(database);
    this->standardize(tableSqlName);
    this->standardize(ddlObjSqlName);
    this->standardize(refTableSqlName);
    this->standardize(refAttribSqlName);

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
            switch (ddlObjType)
            {
                case DdlObj_TempTable:
                    cmd = "drop table " + ddlObjSqlName;
                    break;

                case DdlObj_Table:
                    cmd = "drop table " + database + "." + userName + "." + ddlObjSqlName;
                    break;

                case DdlObj_Trigger:
                case DdlObj_TriggerUdField:
                    cmd = "drop trigger " + ddlObjSqlName;
                    break;

                case DdlObj_View:
                    cmd = "drop view " + ddlObjSqlName;
                    break;

                case DdlObj_Index:
                case DdlObj_TempTableIndex:
                    cmd = "drop index " + tableSqlName + "." + ddlObjSqlName;
                    break;

                case DdlObj_Constraint:
                    cmd = "alter table " + database + "." + userName + "." + tableSqlName + " drop constraint " + ddlObjSqlName;
                    break;

                case DdlObj_SProc:
                case DdlObj_SpecSProc:
                    cmd = "drop procedure " + ddlObjSqlName;
                    break;

                case DdlObj_Func:
                    cmd = "drop function " + ddlObjSqlName;
                    break;

                case DdlObj_PrimaryKey:
                    cmd = "exec sp_dropkey primary, " + tableSqlName;
                    break;

                case DdlObj_ForeignKey:
                    cmd = "exec sp_dropkey foreign, " + tableSqlName + ", " + refTableSqlName;
                    break;

                case DdlObj_ReversedForeignKey:
                    break;

                    /* PMSTA-26056 - LJE - 170209 */
                case DdlObj_Column:
                    cmd = "alter table " + database + ".." + tableSqlName + " drop " + ddlObjSqlName;
                    break;

                default:
                    /* Nothing to do */
                    break;
            }
            break;

        case Oracle:
            switch (ddlObjType)
            {
                case DdlObj_Table:
                case DdlObj_TempTable:
                    cmd = "drop table " + database + "." + ddlObjSqlName + " cascade constraints purge";
                    break;

                case DdlObj_Trigger:
                case DdlObj_TriggerUdField:
                    cmd = "drop trigger " + database + "." + ddlObjSqlName;
                    break;

                case DdlObj_View:
                    cmd = "drop view " + database + "." + ddlObjSqlName;
                    break;

                case DdlObj_Index:
                case DdlObj_TempTableIndex:
                    cmd = "drop index " + database + "." + ddlObjSqlName;
                    break;

                case DdlObj_Constraint:
                    cmd = "alter table " + database + "." + tableSqlName + " drop constraint " + ddlObjSqlName + " cascade";
                    break;

                case DdlObj_SProc:
                case DdlObj_SpecSProc:
                    cmd = "drop procedure " + database + "." + ddlObjSqlName;
                    break;

                case DdlObj_Func:
                    cmd = "drop function " + database + "." + ddlObjSqlName;
                    break;

                case DdlObj_PrimaryKey:
                    cmd = "alter table " + database + "." + tableSqlName + " drop primary key cascade";
                    break;

                case DdlObj_ForeignKey:
                    cmd = "alter table " + database + "." + tableSqlName + " drop constraint " + ddlObjSqlName + " cascade";
                    break;

                case DdlObj_ReversedForeignKey:
                    cmd = "alter table " + database + "." + tableSqlName + " drop constraint " + ddlObjSqlName;
                    break;

                    /* PMSTA-26056 - LJE - 170209 */
                case DdlObj_Column:
                    cmd = "alter table " + database + "." + tableSqlName + " drop (" + ddlObjSqlName + ")";
                    break;

                default:
                    /* Nothing to do */
                    break;
            }
            break;

        case Nuodb:
            switch (ddlObjType)
            {
                case DdlObj_Table:
                    cmd = "drop table " + database + "." + ddlObjSqlName;
                    break;

                case DdlObj_TempTable:
                    cmd = "drop table " + ddlObjSqlName;
                    break;

                case DdlObj_Trigger:
                case DdlObj_TriggerUdField:
                    cmd = "drop trigger " + database + "." + ddlObjSqlName;
                    break;

                case DdlObj_View:
                    cmd = "drop view " + database + "." + ddlObjSqlName;
                    break;

                case DdlObj_Index:
                case DdlObj_TempTableIndex:
                    cmd = "drop index " + database + "." + ddlObjSqlName;
                    break;

                case DdlObj_Constraint:
                    cmd = "alter table " + database + "." + tableSqlName + " drop constraint " + ddlObjSqlName;
                    break;

                case DdlObj_SProc:
                case DdlObj_SpecSProc:
                    cmd = "drop procedure " + database + "." + ddlObjSqlName;
                    break;

                case DdlObj_Func:
                    cmd = "drop function " + database + "." + ddlObjSqlName;
                    break;

                case DdlObj_PrimaryKey:
                    cmd = "drop index " + database + ".\"" + tableSqlName + "..PRIMARY_KEY\"";
                    break;

                case DdlObj_ForeignKey:
                    cmd = "alter table " + database + "." + tableSqlName + " drop constraint " + ddlObjSqlName;
                    break;

                case DdlObj_ReversedForeignKey:
                    cmd = "alter table " + database + "." + tableSqlName + " drop constraint " + ddlObjSqlName;
                    break;

                    /* PMSTA-26056 - LJE - 170209 */
                case DdlObj_Column:
                    cmd = "alter table " + database + "." + tableSqlName + " drop (" + ddlObjSqlName + ")";
                    break;

                default:
                    /* Nothing to do */
                    break;
            }
            break;

        case MSSql:
            switch (ddlObjType)
            {
                case DdlObj_Table:
                    cmd = "drop table if exists " + database + "." + ddlObjSqlName;
                    break;

                case DdlObj_TempTable:
                    cmd = "drop table if exists " + ddlObjSqlName;
                    break;

                case DdlObj_Type:
                    cmd = "drop type if exists " + ddlObjSqlName;
                    break;

                case DdlObj_Trigger:
                case DdlObj_TriggerUdField:
                    cmd = "drop trigger " + database + "." + ddlObjSqlName;
                    break;

                case DdlObj_View:
                    cmd = "drop view " + database + "." + ddlObjSqlName;
                    break;

                case DdlObj_Index:
                case DdlObj_TempTableIndex:
                    cmd = "drop index " + ddlObjSqlName + " on " + database + "." + tableSqlName;
                    break;

                case DdlObj_Constraint:
                    cmd = "alter table " + database + "." + tableSqlName + " drop constraint " + ddlObjSqlName;
                    break;

                case DdlObj_SProc:
                case DdlObj_SpecSProc:
                    cmd = "drop procedure " + database + "." + ddlObjSqlName;
                    break;

                case DdlObj_Func:
                    cmd = "drop function " + database + "." + ddlObjSqlName;
                    break;

                case DdlObj_PrimaryKey:
                    cmd = "alter table " + database + "." + tableSqlName + " drop constraint " + ddlObjSqlName;
                    break;

                case DdlObj_ForeignKey:
                    cmd = "alter table " + database + "." + tableSqlName + " drop constraint " + ddlObjSqlName;
                    break;

                case DdlObj_ReversedForeignKey:
                    break;

                    /* PMSTA-26056 - LJE - 170209 */
                case DdlObj_Column:
                    cmd = "alter table " + database + "." + tableSqlName + " drop column " + ddlObjSqlName;
                    break;

                default:
                    /* Nothing to do */
                    break;
            }
            break;

        case Sqlite:
            switch (ddlObjType)
            {
                case DdlObj_Table:
                    cmd = "drop table if exists " + ddlObjSqlName;
                    break;
                case DdlObj_TempTable:
                    cmd = "drop table if exists " + ddlObjSqlName;
                    break;

                case DdlObj_Trigger:
                case DdlObj_TriggerUdField:
                    cmd = "drop trigger if exists " + ddlObjSqlName;
                    break;

                case DdlObj_View:
                    cmd = "drop view if exists " + ddlObjSqlName;
                    break;

                case DdlObj_Index:
                case DdlObj_TempTableIndex:
                    cmd = "drop index " + ddlObjSqlName + " on " + tableSqlName;
                    break;

                case DdlObj_Constraint:
                    cmd = "alter table " + tableSqlName + " drop constraint " + ddlObjSqlName;
                    break;

                case DdlObj_SProc:
                case DdlObj_SpecSProc:
                    break;

                case DdlObj_Func:
                    break;

                case DdlObj_PrimaryKey:
                    cmd = "alter table " + tableSqlName + " drop constraint " + ddlObjSqlName;
                    break;

                case DdlObj_ForeignKey:
                    cmd = "alter table " + tableSqlName + " drop constraint " + ddlObjSqlName;
                    break;

                case DdlObj_ReversedForeignKey:
                    break;

                case DdlObj_Column:
                    cmd = "alter table " + tableSqlName + " drop column " + ddlObjSqlName;
                    break;

                default:
                    /* Nothing to do */
                    break;
            }
            break;

        case PostgreSQL:
            switch (ddlObjType)
            {
                case DdlObj_Table:
                    cmd = "drop table if exists " + database + "." + ddlObjSqlName + " cascade";
                    break;
                case DdlObj_TempTable:
                    cmd = "drop table if exists " + ddlObjSqlName;
                    break;

                case DdlObj_Trigger:
                case DdlObj_TriggerUdField:
                    cmd = "drop trigger if exists " + ddlObjSqlName + " on " + database + "." + tableSqlName;
                    break;

                case DdlObj_View:
                    cmd = "drop view if exists " + database + "." + ddlObjSqlName + " cascade";
                    break;

                case DdlObj_Index:
                case DdlObj_TempTableIndex:
                    if (ddlObjDef != nullptr && ddlObjDef->m_isPrimary)
                    {
                        cmd = "alter table " + database + "." + tableSqlName + "  drop constraint if exists " + ddlObjSqlName + " cascade";
                    }
                    else
                    {
                        cmd = "drop index if exists " + database + "." + ddlObjSqlName + " cascade";
                    }
                    break;

                case DdlObj_Constraint:
                    cmd = "alter table " + database + "." + tableSqlName + " drop constraint " + ddlObjSqlName;
                    break;

                case DdlObj_SProc:
                case DdlObj_SpecSProc:
                case DdlObj_Func:
                    cmd = "drop function if exists " + database + "." + ddlObjSqlName + " cascade";
                    break;

                case DdlObj_PrimaryKey:
                    cmd = "alter table " + database + "." + tableSqlName + " drop constraint " + ddlObjSqlName;
                    break;

                case DdlObj_ForeignKey:
                    cmd = "alter table " + database + "." + tableSqlName + " drop constraint " + ddlObjSqlName;
                    break;

                case DdlObj_ReversedForeignKey:
                    break;

                case DdlObj_Column:
                    cmd = "alter table " + database + "." + tableSqlName + " drop column " + ddlObjSqlName + " cascade";
                    break;

                default:
                    /* Nothing to do */
                    break;
            }
            break;
    }

    return cmd;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::isIfExistsClause()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
bool DdlGenDbi::isIfExistsClause(DDL_OBJ_ENUM ddlObjEn)
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case PostgreSQL:
            switch (ddlObjEn)
            {
                case DdlObj_Table:
                case DdlObj_Column:
                case DdlObj_SProc:
                case DdlObj_Func:
                case DdlObj_SpecSProc:
                case DdlObj_Trigger:
                case DdlObj_View:
                    return true;
            }

        case Sqlite:
            switch (ddlObjEn)
            {
                case DdlObj_Table:
                case DdlObj_Column:
                case DdlObj_Trigger:
                case DdlObj_View:
                    return true;
            }
    }

    return false;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getIfExistsClause()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
std::string DdlGenDbi::getIfExistsClause(DDL_OBJ_ENUM ddlObjEn, bool bNot)
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case PostgreSQL:
        case Sqlite:
            switch (ddlObjEn)
            {
                case DdlObj_Table:
                case DdlObj_View:
                case DdlObj_Column:
                    return string("if ") + (bNot ? "not " : "") + "exists ";

                default:
                    return string();
            }

        default:
            return string();
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdChangeState()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdChangeState(string       database,
                                    string       tableSqlName,
                                    string       ddlObjSqlName,
                                    DDL_OBJ_ENUM ddlObjType,
                                    bool         bDisable)
{
    string cmd;
    string disableStr = bDisable ? "disable" : "enable validate";

    this->standardize(database);
    this->standardize(tableSqlName);
    this->standardize(ddlObjSqlName);

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
            switch (ddlObjType)
            {
                case DdlObj_Index:
                    if (bDisable)
                    {
                        cmd = "drop index " + tableSqlName + "." + ddlObjSqlName;
                    }
                    break;

                case DdlObj_TempTable:
                case DdlObj_Table:
                case DdlObj_Trigger:
                case DdlObj_View:
                case DdlObj_TempTableIndex:
                case DdlObj_Constraint:
                case DdlObj_SProc:
                case DdlObj_SpecSProc:
                case DdlObj_Func:
                case DdlObj_PrimaryKey:
                case DdlObj_ForeignKey:
                case DdlObj_ReversedForeignKey:
                case DdlObj_Column:
                default:
                    /* Nothing to do */
                    break;
            }
            break;

        case MSSql:
            switch (ddlObjType)
            {
                case DdlObj_Index:
                    cmd = "alter index " + ddlObjSqlName + " on " + database + "." + tableSqlName + " ";

                    if (bDisable)
                    {
                        cmd += "disable";
                    }
                    else
                    {
                        cmd += "rebuild";
                    }
                    break;

                case DdlObj_TempTable:
                case DdlObj_Table:
                case DdlObj_Trigger:
                case DdlObj_View:
                case DdlObj_TempTableIndex:
                case DdlObj_Constraint:
                case DdlObj_SProc:
                case DdlObj_SpecSProc:
                case DdlObj_Func:
                case DdlObj_PrimaryKey:
                case DdlObj_ForeignKey:
                case DdlObj_ReversedForeignKey:
                case DdlObj_Column:
                default:
                    /* Nothing to do */
                    break;
            }
            break;

        case Oracle:
            switch (ddlObjType)
            {
                case DdlObj_PrimaryKey:
                    cmd = "alter table " + database + "." + tableSqlName + " " + disableStr + " primary key " + (bDisable ? "cascade" : "");
                    break;

                case DdlObj_Constraint:
                case DdlObj_ForeignKey:
                case DdlObj_ReversedForeignKey:
                    cmd = "alter table " + database + "." + tableSqlName + "  " + disableStr + " constraint " + ddlObjSqlName;
                    break;

                case DdlObj_Index:
                    if (bDisable)
                    {
                        cmd = "drop index " + database + "." + ddlObjSqlName;
                    }
                    else
                    {
                        cmd = "alter index " + database + "." + ddlObjSqlName + " rebuild";

                        if (this->ddlGenContextPtr->ddlGenAction.m_bOraCreateIdxHint)
                        {
                            cmd += " parallel";
                        }
                    }
                    break;

                case DdlObj_Table:
                case DdlObj_TempTable:
                case DdlObj_Trigger:
                case DdlObj_View:
                case DdlObj_TempTableIndex:
                case DdlObj_SProc:
                case DdlObj_SpecSProc:
                case DdlObj_Func:
                case DdlObj_Column:
                default:
                    /* Nothing to do */
                    break;
            }
            break;

        case Nuodb:
            switch (ddlObjType)
            {
                case DdlObj_TempTable:
                case DdlObj_Table:
                case DdlObj_Trigger:
                case DdlObj_View:
                case DdlObj_Index:
                case DdlObj_TempTableIndex:
                case DdlObj_Constraint:
                case DdlObj_SProc:
                case DdlObj_Func:
                case DdlObj_SpecSProc:
                case DdlObj_PrimaryKey:
                case DdlObj_ForeignKey:
                case DdlObj_ReversedForeignKey:
                case DdlObj_Column:
                default:
                    /* Nothing to do */
                    break;
            }
            break;

        case PostgreSQL:
            switch (ddlObjType)
            {
                case DdlObj_Index:
                    if (bDisable)
                    {
                        cmd = "drop index " + database + "." + ddlObjSqlName;
                    }
                    break;

                case DdlObj_TempTable:
                case DdlObj_Table:
                case DdlObj_Trigger:
                case DdlObj_View:
                case DdlObj_TempTableIndex:
                case DdlObj_Constraint:
                case DdlObj_SProc:
                case DdlObj_SpecSProc:
                case DdlObj_Func:
                case DdlObj_PrimaryKey:
                case DdlObj_ForeignKey:
                case DdlObj_ReversedForeignKey:
                case DdlObj_Column:
                default:
                    /* Nothing to do */
                    break;
            }
            break;

    }

    return cmd;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdCreate()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdCreate(string        database,
                               string        tableSqlName,
                               string        ddlObjSqlName,
                               DDL_OBJ_ENUM  ddlObjType,
                               const string &refTableSqlName,
                               const string &refAttribSqlName,
                               bool          bFirst)
{
    string cmd;

    this->standardize(database);
    this->standardize(tableSqlName);
    this->standardize(ddlObjSqlName);

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
            switch (ddlObjType)
            {
                case DdlObj_TempTable:
                    cmd = "create table " + ddlObjSqlName;
                    break;

                case DdlObj_Table:
                    cmd = "create table " + database + ".." + ddlObjSqlName;
                    break;

                case DdlObj_Constraint:
                    cmd = "alter table " + database + ".." + tableSqlName + " add constraint " + ddlObjSqlName;
                    break;

                case DdlObj_SProc:
                case DdlObj_SpecSProc:
                    this->ddlGenContextPtr->setDdlDestDbName(database, this);
                    cmd = "create procedure " + ddlObjSqlName;
                    break;

                case DdlObj_Func:
                    this->ddlGenContextPtr->setDdlDestDbName(database, this);
                    cmd = "create function " + ddlObjSqlName;
                    break;

                case DdlObj_View:
                    this->ddlGenContextPtr->setDdlDestDbName(database, this);
                    cmd = "create view " + ddlObjSqlName;
                    break;

                case DdlObj_Trigger:
                    this->ddlGenContextPtr->setDdlDestDbName(database, this);
                    cmd = "create trigger " + ddlObjSqlName;
                    break;

                case DdlObj_PrimaryKey:
                    this->ddlGenContextPtr->setDdlDestDbName(database, this);
                    cmd = "exec sp_primarykey " + tableSqlName + ", " + refAttribSqlName;
                    break;

                case DdlObj_ForeignKey:
                    this->ddlGenContextPtr->setDdlDestDbName(database, this);
                    cmd = "exec sp_foreignkey " + tableSqlName + ", " + refTableSqlName + ", " + refAttribSqlName;
                    break;

                default:
                    /* Nothing to do */
                    break;
            }
            break;

        case Oracle:
            switch (ddlObjType)
            {
                case DdlObj_Table:
                    cmd = "create table " + database + "." + tableSqlName;
                    break;

                case DdlObj_TempTable:
                    cmd = "create global temporary table " + this->ddlGenContextPtr->getMainDbName() + "." + tableSqlName;
                    break;

                case DdlObj_Constraint:
                    if (bFirst)
                    {
                        cmd = "alter table " + database + "." + tableSqlName;
                    }
                    else
                    {
                        cmd = " ";
                    }
                    cmd += " add constraint " + ddlObjSqlName;
                    break;

                case DdlObj_ForeignKey:
                    if (bFirst)
                    {
                        cmd = "alter table " + database + "." + tableSqlName;
                    }
                    else
                    {
                        cmd = " ";
                    }
                    cmd += " add constraint " + ddlObjSqlName + " foreign key (" + refAttribSqlName + ")";
                    break;

                case DdlObj_SProc:
                case DdlObj_SpecSProc:
                    cmd = "create or replace procedure " + ddlObjSqlName;
                    break;

                case DdlObj_Func:
                    cmd = "create or replace function " + ddlObjSqlName;
                    break;

                case DdlObj_View:
                    cmd = "create or replace view " + database + "." + ddlObjSqlName;
                    break;

                case DdlObj_Trigger:
                    cmd = "create or replace trigger " + database + "." + ddlObjSqlName;
                    break;

                case DdlObj_PrimaryKey:
                    cmd = "alter table " + database + "." + tableSqlName + " add constraint " + ddlObjSqlName + " primary key (" + refAttribSqlName + ")";
                    break;

                default:
                    /* Nothing to do */
                    break;
            }
            break;

        case Nuodb:
            switch (ddlObjType)
            {
                case DdlObj_Table:
                    cmd = "create table " + database + "." + tableSqlName;
                    break;

                case DdlObj_TempTable:
                    cmd = "create temporary table if not exists " + tableSqlName;
                    break;

                case DdlObj_Constraint:
                    cmd = "alter table " + database + "." + tableSqlName + " add constraint " + ddlObjSqlName;
                    break;

                case DdlObj_ForeignKey:
                    cmd = "alter table " + database + "." + tableSqlName + " add constraint " + ddlObjSqlName + " foreign key (" + refAttribSqlName + ") references " + refTableSqlName;;
                    break;

                case DdlObj_SProc:
                case DdlObj_SpecSProc:
                    cmd = "create or replace procedure " + database + "." + ddlObjSqlName;
                    break;

                case DdlObj_Func:
                    cmd = "create or replace function " + database + "." + ddlObjSqlName;
                    break;

                case DdlObj_View:
                    cmd = "create or replace view " + database + "." + ddlObjSqlName;
                    break;

                case DdlObj_Trigger:
                    cmd = "create or replace trigger " + ddlObjSqlName;
                    break;

                case DdlObj_PrimaryKey:
                    cmd = "alter table " + database + "." + tableSqlName + " add primary key (" + refAttribSqlName + ")";
                    break;

                default:
                    /* Nothing to do */
                    break;
            }
            break;

        case MSSql:
            switch (ddlObjType)
            {
                case DdlObj_Table:
                    cmd = "create table " + database + "." + tableSqlName;
                    break;

                case DdlObj_TempTable:
                    cmd = "create table " + ddlObjSqlName;
                    break;


                case DdlObj_Type:
                    cmd = "create type dbo." + ddlObjSqlName + " as table";
                    break;
                case DdlObj_Constraint:
                    cmd = "alter table " + database + "." + tableSqlName + " add constraint " + ddlObjSqlName;
                    break;

                case DdlObj_ForeignKey:
                    cmd = "alter table " + database + "." + tableSqlName + " add constraint " + ddlObjSqlName + " foreign key (" + refAttribSqlName + ") references " + database + "." + refTableSqlName;
                    break;

                case DdlObj_SProc:
                case DdlObj_SpecSProc:
                    cmd = "create procedure " + database + "." + ddlObjSqlName;
                    break;

                case DdlObj_Func:
                    cmd = "create function " + database + "." + ddlObjSqlName;
                    break;

                case DdlObj_View:
                    cmd = "create view " + database + "." + ddlObjSqlName;
                    break;

                case DdlObj_Trigger:
                    this->ddlGenContextPtr->setDdlDestDbName(database, this);
                    cmd = "create trigger " + database + "." + ddlObjSqlName;
                    break;

                case DdlObj_PrimaryKey:
                    cmd = "alter table " + database + "." + tableSqlName + " add constraint " + ddlObjSqlName + " primary key " + this->getCmdClustered(this->ddlGenContextPtr->m_parentContext->bUseClusterIdx) + "(" + refAttribSqlName + ")";
                    break;

                default:
                    /* Nothing to do */
                    break;
            }
            break;

        case Sqlite:
            switch (ddlObjType)
            {
                case DdlObj_Table:
                    cmd = "create table if not exists " + tableSqlName;
                    break;

                case DdlObj_TempTable:
                    cmd = "create temp table if not exists " + ddlObjSqlName;
                    break;

                case DdlObj_Constraint:
                    cmd = "alter table " + tableSqlName + " add constraint " + ddlObjSqlName;
                    break;

                case DdlObj_ForeignKey:
                    cmd = "alter table " + tableSqlName + " add constraint " + ddlObjSqlName + " foreign key (" + refAttribSqlName + ") references " + refTableSqlName;
                    break;

                case DdlObj_SProc:
                case DdlObj_SpecSProc:
                case DdlObj_Func:
                    break;

                case DdlObj_View:
                    cmd = "create view " + ddlObjSqlName;
                    break;

                case DdlObj_Trigger:
                    cmd = "create trigger " + ddlObjSqlName;
                    break;

                case DdlObj_PrimaryKey:
                    cmd = "alter table " + tableSqlName + " add constraint " + ddlObjSqlName + " primary key (" + refAttribSqlName + ")";
                    break;

                default:
                    /* Nothing to do */
                    break;
            }
            break;

        case PostgreSQL:
            switch (ddlObjType)
            {
                case DdlObj_Table:
                    cmd = "create table if not exists " + database + "." + tableSqlName;
                    break;

                case DdlObj_TempTable:
                    cmd = "create temp table if not exists " + ddlObjSqlName;
                    break;

                case DdlObj_Constraint:
                    if (bFirst)
                    {
                        cmd = "alter table " + database + "." + tableSqlName;
                    }
                    else
                    {
                        cmd += ",";
                    }
                    cmd += " add constraint " + ddlObjSqlName;
                    break;

                case DdlObj_ForeignKey:
                    if (bFirst)
                    {
                        cmd = "alter table " + database + "." + tableSqlName;
                    }
                    else
                    {
                        cmd += ",";
                    }
                    cmd += " add constraint " + ddlObjSqlName + " foreign key (" + refAttribSqlName + ")";
                    break;

                case DdlObj_SProc:
                case DdlObj_SpecSProc:
                case DdlObj_Func:
                    cmd = "CREATE OR REPLACE FUNCTION " + database + "." + ddlObjSqlName;
                    break;

                case DdlObj_View:
                    cmd = "CREATE OR REPLACE VIEW " + database + "." + ddlObjSqlName;
                    break;

                case DdlObj_Trigger:
                    cmd = "CREATE TRIGGER " + ddlObjSqlName;
                    break;

                case DdlObj_PrimaryKey:
                    cmd = "alter table " + database + "." + tableSqlName + " add constraint " + ddlObjSqlName + " primary key (" + refAttribSqlName + ")";
                    break;

                default:
                    /* Nothing to do */
                    break;
            }
            break;
    }
    return cmd;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdCreateIndex()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdCreateIndex(std::string database, std::string tableSqlName, std::string ddlObjSqlName, bool bUnique, bool bCluster)
{
    stringstream cmd;

    this->standardize(database);
    this->standardize(tableSqlName);
    this->standardize(ddlObjSqlName);

    cmd << "create ";

    if (this->ddlGenContextPtr->ddlGenAction.m_bOraCreateIdxHint &&
        this->ddlGenContextPtr->m_rdbmsEn == Oracle && 
        this->getDdlObjEn() != DdlObj_TempTableIndex) /* PMSTA-48555 - JBC - 220323 */
    {
        cmd << "/*+ parallel */ ";
    }

    if (bUnique)
    {
        cmd << "unique ";
    }

    if (this->getDdlObjEn() != DdlObj_TempTableIndex)
    {
        cmd << DdlGenDbi::getCmdClustered(bCluster);
    }

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Oracle:
            cmd << "index " << database << "." << ddlObjSqlName << endl
                << "on " << database << "." << tableSqlName;
            break;

        case MSSql:
            cmd << "index " << ddlObjSqlName << endl
                << "on " << database << "." << tableSqlName;
            break;

        default:
            cmd << "index " << ddlObjSqlName << endl
                << "on " << tableSqlName;
            break;
    }

    return cmd.str();
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdCreateIndexFinal()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdCreateIndexFinal(DBA_DYNFLD_STP xdIndexStp, DdlGenEntity* ddlGenEntityPtr)
{
    stringstream cmd;

    cmd << " )";

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Oracle:
            if (this->ddlGenContextPtr->ddlGenAction.m_bOraNologgingHint &&
                ddlGenEntityPtr->getDictEntityStp()->entNatEn != EntityNat_TempTable)
            {
                cmd << " nologging";
            }
            break;
        case Nuodb:
        {
            if (GET_FLAG(xdIndexStp, A_XdIndex_UniqueFlg) == TRUE)
            {
                auto& indexAttribMap = ddlGenEntityPtr->getXdIndexAttribVector(xdIndexStp);
                bool bNoMantatory = false;
                for (auto it = indexAttribMap.begin(); it != indexAttribMap.end() && bNoMantatory == false; ++it)
                {
                    DBA_DYNFLD_STP xdAttribStp = ddlGenEntityPtr->getXdAttribById(GET_ID((*it), A_XdIndexAttrib_XdAttribId));
                    if (xdAttribStp != nullptr)
                    {
                        if (GET_FLAG(xdAttribStp, A_XdAttrib_DbMandatoryFlg) == FALSE)
                        {
                            bNoMantatory = true;
                        }
                    }
                }

                if (bNoMantatory)
                {
                    cmd << " WITH (NULLS NOT DISTINCT)";
                }
            }
            break;
        }
    }

    return cmd.str();
}


/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdModify()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdModify(string database,
                               string tableSqlName,
                               string ddlObjSqlName,
                               DDL_OBJ_ENUM ddlObjType)
{
    string cmd;

    this->standardize(database);
    this->standardize(tableSqlName);
    this->standardize(ddlObjSqlName);

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
            switch (ddlObjType)
            {
                case DdlObj_TempTable:
                case DdlObj_Table:
                case DdlObj_Trigger:
                case DdlObj_View:
                case DdlObj_Index:
                case DdlObj_TempTableIndex:
                case DdlObj_Constraint:
                case DdlObj_SProc:
                case DdlObj_SpecSProc:
                case DdlObj_Func:
                case DdlObj_PrimaryKey:
                case DdlObj_ForeignKey:
                case DdlObj_ReversedForeignKey:
                case DdlObj_Column:
                    break;

                default:
                    /* Nothing to do */
                    break;
            }
            break;

        case Oracle:
            switch (ddlObjType)
            {
                case DdlObj_PrimaryKey:
                    cmd = "alter table " + database + "." + tableSqlName + " modify primary key using index " + database + "." + ddlObjSqlName;
                    break;

                case DdlObj_TempTable:
                case DdlObj_Table:
                case DdlObj_Trigger:
                case DdlObj_View:
                case DdlObj_Index:
                case DdlObj_TempTableIndex:
                case DdlObj_Constraint:
                case DdlObj_SProc:
                case DdlObj_SpecSProc:
                case DdlObj_Func:
                case DdlObj_ForeignKey:
                case DdlObj_ReversedForeignKey:
                case DdlObj_Column:
                    break;

                default:
                    /* Nothing to do */
                    break;
            }
            break;
    }

    return cmd;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdCreateTrigger()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
void DdlGenDbi::getCmdCreateTrigger(std::stringstream& headerStream,
                                    std::stringstream& footerStream,
                                    DICT_ENTITY_STP    dictEntityStp,
                                    string             ddlObjSqlName,
                                    string             genInfoStr,
                                    DML_EVENT_ENUM     paramDmlEvent,
                                    EVENT_POS_ENUM     paramEventPos,
                                    TRIGGER_POS_ENUM   paramTriggerPos)
{
    string updStr, delStr, dmlEventStr;

    switch (paramDmlEvent)
    {
        case DmlEvent_Insert:
            dmlEventStr = "insert";
            break;

        case DmlEvent_Update:
            dmlEventStr = "update";
            break;

        case DmlEvent_Delete:
            dmlEventStr = "delete";
            break;

        default:
            break;
    }

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
            headerStream << this->getCmdCreate(dictEntityStp->databaseName,
                                               this->getEntitySqlName(dictEntityStp),
                                               ddlObjSqlName,
                                               DdlObj_Trigger);
            headerStream
                << endl << genInfoStr
                << this->newLine()
                << "on " << this->getEntitySqlName(dictEntityStp) << endl
                << "for " << dmlEventStr << endl
                << "as " << endl << "begin";

            this->setIndent(1);
            headerStream << this->newLine()
                << "/* Return if no rows affected    */" << this->newLine()
                << "if @@rowcount = 0" << this->newLine()
                << "	return" << endl << endl;
            this->setIndent(-1);

            footerStream << endl << "end" << this->getCmdEndOfCmd() << endl;
            break;

        case Oracle:
            headerStream << this->getCmdCreate(dictEntityStp->databaseName,
                                               this->getEntitySqlName(dictEntityStp),
                                               ddlObjSqlName,
                                               DdlObj_Trigger);
            headerStream
                << this->newLine()
                << "for " << dmlEventStr << endl
                << "on " << this->getEntityFullSqlName(dictEntityStp, TargetTable_Undefined, string(), View_None) << endl
                << "compound trigger" << endl
                << genInfoStr << endl;

            footerStream << endl << "end" << this->getCmdEndOfCmd() << endl;
            break;

        case Nuodb:
            headerStream << this->getCmdCreate(dictEntityStp->databaseName,
                                               this->getEntitySqlName(dictEntityStp),
                                               ddlObjSqlName,
                                               DdlObj_Trigger);
            headerStream
                << endl << genInfoStr
                << this->newLine()
                << "for " << this->getEntitySqlName(dictEntityStp) << endl
                << (paramEventPos == EventPos_Before ? "before " : "after ") << dmlEventStr << endl
                << "as ";

            footerStream << endl << "end_trigger" << this->getCmdEndOfCmd() << endl;
            break;

        case MSSql:
            headerStream << this->getCmdCreate(dictEntityStp->databaseName,
                                               this->getEntitySqlName(dictEntityStp),
                                               ddlObjSqlName,
                                               DdlObj_Trigger);
            headerStream
                << endl << genInfoStr
                << this->newLine()
                << "on " << this->getEntityFullSqlName(dictEntityStp, TargetTable_Undefined, string(), View_None) << endl
                << "for " << dmlEventStr << endl
                << "as " << endl << "begin";

            this->setIndent(1);
            headerStream << this->newLine()
                << "/* Return if no rows affected    */" << this->newLine()
                << "if @@rowcount = 0" << this->newLine()
                << "	return" << endl << endl;
            this->setIndent(-1);

            footerStream << endl << "end;" << this->getCmdEndOfCmd() << endl;
            break;

        case PostgreSQL:
            headerStream << this->getCmdCreate(dictEntityStp->databaseName,
                                               this->getEntitySqlName(dictEntityStp),
                                               ddlObjSqlName,
                                               DdlObj_Trigger);

            headerStream
                << endl << genInfoStr
                << this->newLine()
                << ((paramTriggerPos == TriggerPos_Before || paramTriggerPos == TriggerPos_BeforeEachRow) ? "before" : "after") << " " << dmlEventStr << endl
                << "on " << this->getEntityFullSqlName(dictEntityStp, TargetTable_Undefined, string(), View_None) << endl
                << "for each " << ((paramTriggerPos == TriggerPos_AfterEachRow || paramTriggerPos == TriggerPos_BeforeEachRow) ? "row" : "statement") << endl
                << "execute function " << ddlObjSqlName << "()";

            footerStream << this->getCmdEndOfCmd() << endl;
            break;

        default:
            SYS_BreakOnDebug();

    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::printGrant()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
void DdlGenDbi::printGrant(stringstream& outStream,
                           string              database,
                           string              tableSqlName,
                           string              ddlObjSqlName,
                           DDL_OBJ_ENUM        ddlObjType,
                           DBA_EXECUTE_AS_ENUM executeAsEn)
{
    this->standardize(database);
    this->standardize(tableSqlName);
    this->standardize(ddlObjSqlName);

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
            switch (ddlObjType)
            {
                case DdlObj_Table:
                case DdlObj_TempTable:
                    /* Treated in method printGrantTable*/
                    break;

                case DdlObj_SProc:
                case DdlObj_SpecSProc:
                case DdlObj_Func:
                    if (executeAsEn == ExecuteAs_LoginManager)
                    {
                        string loginManagerStr;
                        loginManagerStr = this->ddlGenContextPtr->getPropFileHelper().getProperty("AAA_LOGIN_MANAGER");

                        if (loginManagerStr.empty())
                        {
                            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "AAA_LOGIN_MANAGER is not define");
                        }
                        else
                        {
                            outStream << "grant execute on " << ddlObjSqlName << " to " << this->getCmdUser(loginManagerStr) << this->getCmdEndDDLObj();
                        }
                    }

                    if (executeAsEn == ExecuteAs_WmTech)
                    {
                        return; /* wm_tech role exist only on Oracle */
                    }
                    else
                    {
                        outStream << "grant execute on " << ddlObjSqlName << " to triplea, tasc_tech" << this->getCmdEndDDLObj();;
                    }
                    break;

                case DdlObj_View:
                    break;

                default:
                    /* Nothing to do */
                    break;
            }
            break;

        case Oracle:
            switch (ddlObjType)
            {
                case DdlObj_Table:
                case DdlObj_TempTable:
                    /* Treated in method printGrantTable*/
                    break;

                case DdlObj_SProc:
                case DdlObj_SpecSProc:
                case DdlObj_Func:
                    if (executeAsEn == ExecuteAs_LoginManager)
                    {
                        string loginManagerStr;
                        loginManagerStr = this->ddlGenContextPtr->getPropFileHelper().getProperty("AAA_LOGIN_MANAGER");

                        if (loginManagerStr.empty())
                        {
                            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "AAA_LOGIN_MANAGER is not define");
                        }
                        else
                        {
                            outStream << "grant execute on " << database << "." << ddlObjSqlName << " to " << this->getCmdUser(loginManagerStr) << this->getCmdEndDDLObj();
                        }
                    }

                    if (executeAsEn == ExecuteAs_WmTech)
                    {
                        outStream << "grant execute on " << database << "." << ddlObjSqlName << " to wm_tech" << this->getCmdEndDDLObj();
                    }
                    else
                    {
                        outStream << "grant execute on " << database << "." << ddlObjSqlName << " to triplea, tasc_tech" << this->getCmdEndDDLObj();
                    }

                    this->printGrantToAllSchema(outStream, database, "grant execute on " + database + "." + ddlObjSqlName, string());
                    break;

                case DdlObj_View:
                    break;

                default:
                    /* Nothing to do */
                    break;
            }
            break;

        case Nuodb:
        {
            string grantStr;

            switch (ddlObjType)
            {
                case DdlObj_Table:
                case DdlObj_TempTable:
                    /* Treated in method printGrantTable*/
                    break;

                case DdlObj_SProc:
                case DdlObj_SpecSProc:
                    grantStr = "grant execute on procedure ";
                    break;

                case DdlObj_Func:
                    grantStr = "grant execute on function ";
                    break;

                case DdlObj_View:
                    break;

                default:
                    /* Nothing to do */
                    break;
            }

            if (grantStr.empty() == false)
            {
                if (executeAsEn == ExecuteAs_LoginManager)
                {
                    string loginManagerStr;
                    loginManagerStr = this->ddlGenContextPtr->getPropFileHelper().getProperty("AAA_LOGIN_MANAGER");

                    if (loginManagerStr.empty())
                    {
                        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "AAA_LOGIN_MANAGER is not define");
                    }
                    else
                    {
                        outStream << grantStr << database << "." << ddlObjSqlName << " to " << this->getCmdUser(loginManagerStr) << this->getCmdEndDDLObj();
                    }
                }

                if (executeAsEn == ExecuteAs_WmTech)
                {
                    return;  /* wm_tech role exist only on Oracle */
                }
                else
                {
                    outStream << grantStr << database << "." << ddlObjSqlName << " to " << this->getCmdRole("triplea") << ", " << this->getCmdRole("tasc_tech") << this->getCmdEndDDLObj();
                }
            }
        }
        break;

        case MSSql:
            switch (ddlObjType)
            {
                case DdlObj_Table:
                case DdlObj_TempTable:
                    /* Treated in method printGrantTable*/
                    break;

                case DdlObj_SProc:
                case DdlObj_SpecSProc:
                case DdlObj_Func:
                    if (executeAsEn == ExecuteAs_LoginManager)
                    {
                        string loginManagerStr;
                        loginManagerStr = this->ddlGenContextPtr->getPropFileHelper().getProperty("AAA_LOGIN_MANAGER");

                        if (loginManagerStr.empty())
                        {
                            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "AAA_LOGIN_MANAGER is not define");
                        }
                        else
                        {
                            outStream << "grant execute on " << database << "." << ddlObjSqlName << " to " << this->getCmdUser(loginManagerStr) << this->getCmdEndDDLObj();
                        }
                    }

                    if (executeAsEn == ExecuteAs_WmTech)
                    {
                        return;  /* wm_tech role exist only on Oracle */
                    }
                    else
                    {
                        outStream << "grant execute on " << database << "." << ddlObjSqlName << " to triplea, tasc_tech" << this->getCmdEndDDLObj();
                    }
                    break;

                case DdlObj_View:
                    break;

                default:
                    /* Nothing to do */
                    break;
            }
            break;

        case PostgreSQL:
        {
            string grantStr;

            switch (ddlObjType)
            {
                case DdlObj_Table:
                case DdlObj_TempTable:
                    /* Treated in method printGrantTable*/
                    break;

                case DdlObj_SProc:
                case DdlObj_SpecSProc:
                case DdlObj_Func:
                    grantStr = "grant execute on function ";
                    break;

                case DdlObj_View:
                    break;

                default:
                    /* Nothing to do */
                    break;
            }

            if (grantStr.empty() == false)
            {
                if (executeAsEn == ExecuteAs_LoginManager)
                {
                    string loginManagerStr;
                    loginManagerStr = this->ddlGenContextPtr->getPropFileHelper().getProperty("AAA_LOGIN_MANAGER");

                    if (loginManagerStr.empty())
                    {
                        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "AAA_LOGIN_MANAGER is not define");
                    }
                    else
                    {
                        outStream << grantStr << database << "." << ddlObjSqlName << " to " << this->getCmdUser(loginManagerStr) << this->getCmdEndDDLObj();
                    }
                }

                if (executeAsEn == ExecuteAs_WmTech)
                {
                    return;  /* wm_tech role exist only on Oracle */
                }
                else
                {
                    outStream << grantStr << database << "." << ddlObjSqlName << " to " << this->getCmdRole("triplea") << ", " << this->getCmdRole("tasc_tech") << this->getCmdEndDDLObj();
                }
            }
        }
        break;

    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdRole()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
std::string DdlGenDbi::getCmdRole(const std::string& role)
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case Oracle:
        case MSSql:
            break;

        case Nuodb:
            /* PMSTA-37374 - LJE - 201113 */
            string mainDbName = this->ddlGenContextPtr->getMainDbName();
            if (mainDbName.empty() &&
                EV_UseAlternativeDataSource &&
                EV_TargetCfgFile != nullptr)
            {
                mainDbName = EV_TargetCfgFile->dbSectionMap["AAAMAIN_DB"].dbSqlName;
            }
            return "role " + mainDbName + "." + role;
    }

    return role;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdUser()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	: PMSTA-36209 - DDV - 191112
**
*************************************************************************/
std::string DdlGenDbi::getCmdUser(const std::string& user)
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case Oracle:
        case MSSql:
            break;

        case Nuodb:
            return "user " + user;
    }

    return user;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::printGrantToALlSchema()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
void DdlGenDbi::printGrantToAllSchema(std::stringstream& outStream,
                                      const std::string& currDatabase,
                                      const std::string& grant,
                                      const std::string& option)
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
            break;

        case Oracle:
        {
            auto& allSchemaList = this->ddlGenContextPtr->getAllDbSet();

            for (auto it = allSchemaList.begin(); it != allSchemaList.end(); ++it)
            {
                if (currDatabase.compare(*it) != 0)
                {
                    outStream << grant << " to " << *it << " " << option << this->getCmdEndDDLObj();
                }
            }
        }
        break;
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getStdDdlObjType()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getStdDdlObjType(DDL_OBJ_ENUM ddlObjType)
{
    string typeStr;
    switch (ddlObjType)
    {
        case DdlObj_None:
            typeStr = "none";
            break;
        case DdlObj_View:
            typeStr = "view";
            break;
        case DdlObj_SProc:
            typeStr = "procedure";
            break;
        case DdlObj_Func:
            typeStr = "function";
            break;
        case DdlObj_Trigger:
            typeStr = "trigger";
            break;
        case DdlObj_TriggerUdField:
            typeStr = "trigger_ud";
            break;
        case DdlObj_Index:
            typeStr = "index";
            break;
        case DdlObj_TempTableIndex:
            typeStr = "index_temp_table";
            break;
        case DdlObj_Table:
            typeStr = "table";
            break;
        case DdlObj_TempTable:
            typeStr = "temp_table";
            break;
        case DdlObj_SpecSProc:
            typeStr = "special_procedure";
            break;
        case DdlObj_Constraint:
            typeStr = "constraint";
            break;
        case DdlObj_ViewLegacy:
            typeStr = "view_legacy";
            break;
        case DdlObj_PrimaryKey:
            typeStr = "primary_key";
            break;
        case DdlObj_ForeignKey:
            typeStr = "foreign_key";
            break;
        case DdlObj_Column:
            typeStr = "column";
            break;
        case DdlObj_Sql:
            typeStr = "sql";
            break;
        case DdlObj_SubSql:
            typeStr = "sub_sql";
            break;
        case DdlObj_RuntimeSql:
            typeStr = "runtime_sql";
            break;
        case DdlObj_SubDdlObj:
            typeStr = "sub_ddl_object";
            break;
        case DdlObj_Migration:
            typeStr = "migration";
            break;
    }
    return typeStr;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getDdlObjType()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getDdlObjType(DDL_OBJ_ENUM ddlObjType)
{
    string typeStr;

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
            switch (ddlObjType)
            {
                case DdlObj_Table:
                case DdlObj_TempTable:
                case DdlObj_Column:
                case DdlObj_PrimaryKey:
                    typeStr = "U";
                    break;

                case DdlObj_View:
                case DdlObj_ViewLegacy:
                    typeStr = "V";
                    break;

                case DdlObj_Constraint:
                    typeStr = "R";
                    break;

                case DdlObj_ForeignKey:
                    typeStr = "RI";
                    break;

                case DdlObj_SProc:
                case DdlObj_SpecSProc:
                    typeStr = "P";
                    break;

                case DdlObj_Func:
                    typeStr = "SF";
                    break;

                case DdlObj_Trigger:
                case DdlObj_TriggerUdField:
                    typeStr = "TR";
                    break;

                default:
                    /* Nothing to do */
                    break;
            }
            break;

        case Oracle:
            switch (ddlObjType)
            {
                case DdlObj_Table:
                case DdlObj_TempTable:
                    typeStr = "TABLE";
                    break;

                case DdlObj_Trigger:
                case DdlObj_TriggerUdField:
                    typeStr = "TRIGGER";
                    break;

                case DdlObj_View:
                case DdlObj_ViewLegacy:
                    typeStr = "VIEW";
                    break;

                case DdlObj_Constraint:
                    break;

                case DdlObj_SProc:
                case DdlObj_SpecSProc:
                    typeStr = "PROCEDURE";
                    break;

                case DdlObj_Func:
                    typeStr = "FUNCTION";
                    break;

                default:
                    /* Nothing to do */
                    break;
            }
            break;

        case Nuodb:
            switch (ddlObjType)
            {
                case DdlObj_Table:
                    typeStr = "TABLE";
                    break;

                case DdlObj_TempTable:
                    typeStr = "LOCAL TEMP TABLE";
                    break;

                case DdlObj_Trigger:
                case DdlObj_TriggerUdField:
                    typeStr = "TRIGGER";
                    break;

                case DdlObj_View:
                case DdlObj_ViewLegacy:
                    typeStr = "VIEW";
                    break;

                case DdlObj_Constraint:
                    break;

                case DdlObj_SProc:
                case DdlObj_SpecSProc:
                    typeStr = "PROCEDURE";
                    break;

                case DdlObj_Func:
                    typeStr = "FUNCTION";
                    break;

                default:
                    /* Nothing to do */
                    break;
            }
            break;

        case MSSql:
            switch (ddlObjType)
            {
                case DdlObj_Table:
                case DdlObj_TempTable:
                case DdlObj_Column:
                    typeStr = "U";
                    break;

                case DdlObj_View:
                case DdlObj_ViewLegacy:
                    typeStr = "V";
                    break;

                case DdlObj_Constraint:
                    typeStr = "C";
                    break;

                case DdlObj_SProc:
                case DdlObj_SpecSProc:
                    typeStr = "P";
                    break;

                case DdlObj_Func:
                    typeStr = "FN";
                    break;

                case DdlObj_Trigger:
                case DdlObj_TriggerUdField:
                    typeStr = "TR";
                    break;

                default:
                    /* Nothing to do */
                    break;
            }
            break;

    }

    return typeStr;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdSelObjInDb()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdSelObjInDb(const string& database,
                                   const string& tableSqlName,
                                   const string& ddlObjSqlName,
                                   DDL_OBJ_ENUM ddlObjType,
                                   string userName,
                                   string refTableSqlName,
                                   string refAttribSqlName)
{
    bool bUseBindVar = (this->ddlGenContextPtr->m_rdbmsEn == Oracle &&
                        this->ddlGenContextPtr->bGenFromDbi == false &&
                        SYS_IsSqlMode() == FALSE);

    string cmd;
    string toSearchDatabase;
    string toSearchTableSqlName;
    string toSearchDdlObjSqlName;

    if (bUseBindVar == true)
    {
        toSearchDatabase = database;
        toSearchTableSqlName = tableSqlName;
        toSearchDdlObjSqlName = ddlObjSqlName;

        this->standardize(toSearchDatabase);
        this->standardize(toSearchTableSqlName);
        this->standardize(toSearchDdlObjSqlName);
    }
    else
    {
        if (database.empty() == false && database[0] != '@')
        {
            toSearchDatabase = "'" + database + "'";
            this->standardize(toSearchDatabase);
        }
        else
        {
            toSearchDatabase = database;
        }
        if (tableSqlName.empty() == false && tableSqlName[0] != '@')
        {
            toSearchTableSqlName = "'" + tableSqlName + "'";
            this->standardize(toSearchTableSqlName);
        }
        else
        {
            toSearchTableSqlName = tableSqlName;
        }
        if (ddlObjSqlName.empty() == false && ddlObjSqlName[0] != '@')
        {
            toSearchDdlObjSqlName = "'" + ddlObjSqlName + "'";
            this->standardize(toSearchDdlObjSqlName);
        }
        else
        {
            toSearchDdlObjSqlName = ddlObjSqlName;
        }
    }
    this->standardize(refTableSqlName);
    this->standardize(refAttribSqlName);


    string typeStr = DdlGenDbi::getDdlObjType(ddlObjType);

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        {
            string targetDatabase;

            if (userName.empty())
            {
                userName = "dbo";
            }

            if (this->ddlGenContextPtr->bGenFromDbi == false)
            {
                targetDatabase = database + "..";
            }

            switch (ddlObjType)
            {
                case DdlObj_Constraint:
                    cmd = "select '1' from " + targetDatabase + "sysobjects so "
                        "inner join " + targetDatabase + "sysconstraints constr on so.id = constr.constrid "
                        "inner join " + targetDatabase + "sysobjects tb on tb.id = constr.tableid "
                        "inner join " + targetDatabase + "sysusers su on su.uid = so.uid "
                        "where so.type = '" + typeStr + "' and so.name = " + toSearchDdlObjSqlName +
                        " and tb.name = " + toSearchTableSqlName +
                        " and su.name = '" + userName + "'";
                    break;

                case DdlObj_Column:
                    cmd = "select '1' from " + targetDatabase + "sysobjects so "
                        "inner join " + targetDatabase + "syscolumns sc on so.id = sc.id "
                        "inner join " + targetDatabase + "sysusers su on su.uid = so.uid "
                        "where so.type = '" + typeStr + "' and so.name = " + toSearchTableSqlName + " and sc.name = " + toSearchDdlObjSqlName +
                        " and su.name = '" + userName + "'";
                    break;

                case DdlObj_Trigger:
                case DdlObj_SProc:
                case DdlObj_SpecSProc:
                case DdlObj_Func:
                    cmd = "select '1' from " + targetDatabase + "sysobjects so "
                        "inner join " + targetDatabase + "sysusers su on su.uid = so.uid "
                        "where so.type = '" + typeStr + "' and so.name = " + toSearchDdlObjSqlName +
                        " and su.name = '" + userName + "'";
                    break;

                case DdlObj_Table:
                    cmd = "select '1' from " + targetDatabase + "sysobjects so "
                        "inner join " + targetDatabase + "sysusers su on su.uid = so.uid "
                        "where so.type = '" + typeStr + "' and so.name = " + toSearchTableSqlName +
                        " and su.name = '" + userName + "'";
                    break;

                case DdlObj_View:
                    cmd = "select '1' from " + targetDatabase + "sysobjects so "
                        "inner join " + targetDatabase + "sysusers su on su.uid = so.uid "
                        "where so.type = '" + typeStr + "' and so.name = " + toSearchDdlObjSqlName +
                        " and su.name = '" + userName + "'";
                    break;

                case DdlObj_ViewLegacy:
                    cmd = "select '1' from " + targetDatabase + "sysobjects so, " + targetDatabase + "sysusers su where so.type = '" +
                        typeStr + "' and so.name = " + toSearchDdlObjSqlName +
                        " and so.uid = su.uid and su.name = '" + userName + "'";
                    break;

                case DdlObj_TempTable:
                    cmd = "object_id(" + toSearchDdlObjSqlName + ") is not null";
                    break;

                case DdlObj_TempTableIndex:
                    cmd = "object_id(" + toSearchDdlObjSqlName + ") is not null";
                    break;

                case DdlObj_Index:
                    cmd = "select '1' from " + targetDatabase + "sysindexes where name = " + toSearchDdlObjSqlName;
                    break;

                case DdlObj_PrimaryKey:
                    cmd = "select '1' from " + targetDatabase + "sysobjects so1, " + targetDatabase + "syscolumns sc1, " + targetDatabase + "syskeys sk"
                        " where so1.id=sc1.id and so1.id=sk.id and sc1.colid=sk.key1 and so1.type='U' and sk.type = 1"
                        " and so1.name= " + toSearchTableSqlName +
                        " and su.name = " + userName;
                    break;

                case DdlObj_ForeignKey:
                    cmd = "select '1' from " + targetDatabase + "sysobjects so1, " + targetDatabase + "syscolumns sc1, " + targetDatabase + "syskeys sk, " + targetDatabase + "sysobjects so2"
                        " where so1.id = sc1.id"
                        " and so1.id = sk.id"
                        " and sc1.colid = sk.key1"
                        " and so1.name = " + toSearchTableSqlName +
                        " and sc1.name = '" + refAttribSqlName + "'"
                        " and so1.type = 'U'"
                        " and sk.type = 2"
                        " and sk.depid = so2.id"
                        " and so2.name = '" + refTableSqlName + "'";
                    break;

                default:
                    /* Nothing to do */
                    break;
            }
        }
        break;

        case Oracle:
            if (bUseBindVar == false)
            {
                switch (ddlObjType)
                {
                    case DdlObj_Table:
                    case DdlObj_TempTable:
                        cmd = "select '1' from all_objects where object_type = '" + typeStr + "'"
                            " and object_name = " + toSearchTableSqlName +
                            " and owner = " + toSearchDatabase;
                        break;

                    case DdlObj_Trigger:
                    case DdlObj_SProc:
                    case DdlObj_SpecSProc:
                    case DdlObj_Func:
                        cmd = "select '1' from all_objects where object_type = '" + typeStr + "'"
                            " and object_name = " + toSearchDdlObjSqlName +
                            " and owner = " + toSearchDatabase;
                        break;

                    case DdlObj_Column:
                        cmd = "select '1' from all_tab_cols where table_name = " + toSearchTableSqlName + " and column_name = " + toSearchDdlObjSqlName + " and owner = " + toSearchDatabase;
                        break;

                    case DdlObj_View:
                        cmd = "select '1' from all_objects where object_type = '" + typeStr + "'"
                            " and object_name = " + toSearchDdlObjSqlName +
                            " and owner = '" + this->ddlGenContextPtr->getDdlDestDbName() + "'";
                        break;

                    case DdlObj_Constraint:
                        cmd = "select '1' from all_constraints where table_name = " + toSearchTableSqlName +
                            " and owner = " + toSearchDatabase +
                            " and constraint_name = " + toSearchDdlObjSqlName;
                        break;

                    case DdlObj_Index:
                    case DdlObj_TempTableIndex:
                        cmd = "select '1' from all_indexes where index_name = " + toSearchDdlObjSqlName +
                            " and owner = " + toSearchDatabase;
                        break;

                    case DdlObj_PrimaryKey:
                        cmd = "select '1' from all_constraints where owner = " +
                            toSearchDatabase + " and table_name = " + toSearchTableSqlName + " and constraint_type = 'P'";
                        break;

                    case DdlObj_ForeignKey:
                        if (refAttribSqlName.empty())
                        {
                            cmd = "select '1' from all_constraints "
                                " where owner = " + toSearchDatabase +
                                " and constraint_name = " + toSearchDdlObjSqlName;
                        }
                        else
                        {
                            cmd = "select '1' from all_constraints const, all_cons_columns sk, all_constraints r_const"
                                " where const.owner = " + toSearchDatabase +
                                " and const.table_name = " + toSearchTableSqlName +
                                " and const.constraint_type = 'R'"
                                " and sk.owner = " + toSearchDatabase +
                                " and sk.constraint_name = const.constraint_name"
                                " and sk.column_name = '" + refAttribSqlName + "'"
                                " and r_const.owner = " + toSearchDatabase +
                                " and r_const.constraint_name = const.r_constraint_name"
                                " and r_const.table_name = '" + refTableSqlName + "'";
                        }
                        break;

                    default:
                        /* Nothing to do */
                        break;
                }
            }
            else
            {
                stringstream cmdStream;

                switch (ddlObjType)
                {
                    case DdlObj_Table:
                    case DdlObj_TempTable:
                    case DdlObj_Trigger:
                    case DdlObj_SProc:
                    case DdlObj_SpecSProc:
                    case DdlObj_Func:
                        this->m_paramVector.push_back(typeStr);
                        this->m_paramVector.push_back(toSearchDdlObjSqlName);
                        this->m_paramVector.push_back(toSearchDatabase);

                        cmdStream << "select '1' from all_objects where object_type = ? and object_name = ? and owner = ?";
                        break;

                    case DdlObj_Column:
                        this->m_paramVector.push_back(toSearchTableSqlName);
                        this->m_paramVector.push_back(toSearchDdlObjSqlName);
                        this->m_paramVector.push_back(toSearchDatabase);

                        cmdStream << "select '1' from all_tab_cols where table_name = ? and column_name = ? and owner = ?";
                        break;

                    case DdlObj_View:
                        this->m_paramVector.push_back(typeStr);
                        this->m_paramVector.push_back(toSearchDdlObjSqlName);
                        this->m_paramVector.push_back(toSearchDatabase);

                        cmdStream << "select '1' from all_objects where object_type = ? and object_name = ? and owner = ?";
                        break;

                    case DdlObj_Constraint:
                        this->m_paramVector.push_back(toSearchTableSqlName);
                        this->m_paramVector.push_back(toSearchDatabase);
                        this->m_paramVector.push_back(toSearchDdlObjSqlName);

                        cmdStream << "select '1' from all_constraints where table_name = ? and owner = ? and constraint_name = ?";
                        break;

                    case DdlObj_Index:
                    case DdlObj_TempTableIndex:
                        this->m_paramVector.push_back(toSearchDdlObjSqlName);
                        this->m_paramVector.push_back(toSearchDatabase);

                        cmdStream << "select '1' from all_indexes where index_name = ? and owner = ?";
                        break;

                    case DdlObj_PrimaryKey:
                        this->m_paramVector.push_back(toSearchDatabase);
                        this->m_paramVector.push_back(toSearchTableSqlName);

                        cmdStream << "select '1' from all_constraints where owner = ? and table_name = ? and constraint_type = 'P'";
                        break;

                    case DdlObj_ForeignKey:
                        if (refAttribSqlName.empty())
                        {
                            this->m_paramVector.push_back(toSearchDatabase);
                            this->m_paramVector.push_back(toSearchDdlObjSqlName);

                            cmdStream << "select '1' from all_constraints where owner = ? and constraint_name = ?";
                        }
                        else
                        {
                            this->m_paramVector.push_back(toSearchDatabase);
                            this->m_paramVector.push_back(toSearchTableSqlName);
                            this->m_paramVector.push_back(refAttribSqlName);
                            this->m_paramVector.push_back(refTableSqlName);

                            cmdStream << "select '1' from all_constraints const, all_cons_columns sk, all_constraints r_const"
                                << " where const.owner = ?"
                                << " and const.table_name = ?"
                                << " and const.constraint_type = 'R'"
                                << " and sk.owner = const.owner"
                                << " and sk.constraint_name = const.constraint_name"
                                << " and sk.column_name = ?"
                                << " and r_const.owner = const.owner"
                                << " and r_const.constraint_name = const.r_constraint_name"
                                << " and r_const.table_name = ?";
                        }
                        break;

                    default:
                        /* Nothing to do */
                        break;
                }
                cmd = cmdStream.str();
            }
            break;

        case Nuodb:

            switch (ddlObjType)
            {
                case DdlObj_Table:
                case DdlObj_View:
                    cmd = "select '1' from system.tables where tablename = " + toSearchTableSqlName + " and schema = " + toSearchDatabase + " and type = '" + typeStr + "'";
                    break;

                case DdlObj_TempTable:
                    cmd = "select '1' from system.temptables where tablename = " + toSearchDdlObjSqlName + " and schema like 'NUO_TEMP_%' and type = '" + typeStr + "'";
                    break;

                case DdlObj_Trigger:
                    cmd = "select '1' from system.triggers where schema = " + toSearchDatabase + " and  triggername = " + toSearchDdlObjSqlName;
                    break;

                case DdlObj_SProc:
                case DdlObj_SpecSProc:
                    cmd = "select '1' from system.procedures where schema = " + toSearchDatabase + " and  procedurename = " + toSearchDdlObjSqlName;
                    break;

                case DdlObj_Func:
                    cmd = "select '1' from system.functions where schema = " + toSearchDatabase + " and  functionname = " + toSearchDdlObjSqlName;
                    break;

                case DdlObj_Column:
                    cmd = "select '1' from system.fields where schema = " + toSearchDatabase + " and tablename = " + toSearchTableSqlName + " and field = " + toSearchDdlObjSqlName;
                    break;

                case DdlObj_Constraint:
                    cmd = "select '1' from system.tableconstraints where tablename = " + toSearchTableSqlName +
                        " and schema = " + toSearchDatabase +
                        " and constraintname = " + toSearchDdlObjSqlName;
                    break;

                case DdlObj_Index:
                case DdlObj_TempTableIndex:
                    cmd = "select '1' from system.indexes where schema = " + toSearchDatabase + " and tablename = " + toSearchTableSqlName + " and indexname = " + toSearchDdlObjSqlName;
                    break;

                case DdlObj_PrimaryKey:
                    cmd = "select '1' from system.indexes where schema = " + toSearchDatabase + " and tablename = " + toSearchTableSqlName + " and indextype = 0";
                    break;

                case DdlObj_ForeignKey:
                    if (refAttribSqlName.empty())
                    {
                        cmd = "select '1' from system.tableconstraints "
                            " where schema = " + toSearchDatabase +
                            " and constraintname = " + toSearchDdlObjSqlName;
                    }
                    else
                    {
                        cmd = "select '1' "
                            " from system.foreignkeys fk"
                            " inner join system.tables pt on pt.tableid = fk.primarytableid"
                            " inner join system.tables ft on ft.tableid = fk.foreigntableid and pt.schema = ft.schema"
                            " inner join system.fields fa on fa.tablename = ft.tablename and fa.schema = ft.schema and fa.fieldid = fk.foreignfieldid"
                            " where pt.schema = " + toSearchDatabase +
                            " and ft.tablename = " + toSearchTableSqlName +
                            " and pt.tablename = '" + refTableSqlName + "'"
                            " and fa.field = '" + refAttribSqlName + "'";
                    }
                    break;

                default:
                    /* Nothing to do */
                    break;
            }
            break;

        case MSSql:
            switch (ddlObjType)
            {
                case DdlObj_Constraint:
                    cmd = "select '1' from sys.objects so"
                        " inner join sys.schemas sch on so.schema_id = sch.schema_id and sch.name = " + toSearchDatabase +
                        " inner join sys.check_constraints constr on so.object_id = constr.parent_object_id"
                        " where so.type = 'U' and so.name = " + toSearchTableSqlName +
                        " and constr.name = " + toSearchDdlObjSqlName;
                    break;

                case DdlObj_Column:
                    cmd = "select '1' from sys.objects so, sys.columns sc, sys.schemas sch"
                        " where so.type = '" + typeStr + "' and so.object_id = sc.object_id and so.schema_id = sch.schema_id"
                        " and so.name = " + toSearchTableSqlName + " and sc.name = " + toSearchDdlObjSqlName + " and sch.name = " + toSearchDatabase;
                    break;

                case DdlObj_Trigger:
                case DdlObj_SProc:
                case DdlObj_SpecSProc:
                case DdlObj_Func:
                    cmd = "select '1' from sys.objects so, sys.schemas sch where so.type = '" + typeStr + "' and so.name = " + toSearchDdlObjSqlName +
                        " and so.schema_id = sch.schema_id and sch.name = " + toSearchDatabase;
                    break;

                case DdlObj_Table:
                    cmd = "select '1' from sys.objects so, sys.schemas sch where so.type = '" + typeStr + "' and so.name = " + toSearchTableSqlName +
                        " and so.schema_id = sch.schema_id and sch.name = " + toSearchDatabase;
                    break;

                case DdlObj_View:
                    cmd = "select '1' from sys.objects so, sys.schemas sch where so.type = '" + typeStr + "' and so.name = " + toSearchDdlObjSqlName +
                        " and so.schema_id = sch.schema_id and sch.name = " + toSearchDatabase;
                    break;

                case DdlObj_TempTable:
                    cmd = "object_id('""tempdb.." + ddlObjSqlName + "') is not null";
                    break;

                case DdlObj_TempTableIndex:
                    cmd = "object_id('" + database + "." + ddlObjSqlName + "') is not null";
                    break;

                case DdlObj_Index:
                    cmd = "select '1' from sys.indexes idx where idx.name = " + toSearchDdlObjSqlName;
                    break;

                case DdlObj_PrimaryKey:
                    cmd = "select '1' from sys.key_constraints pkc, sys.schemas sch, sys.objects so "
                        " where so.object_id = pkc.parent_object_id and sch.schema_id = pkc.schema_id "
                        " and so.name= " + toSearchTableSqlName + " and sch.name = " + toSearchDatabase;
                    break;

                case DdlObj_ForeignKey:
                    if (refAttribSqlName.empty())
                    {
                        cmd = "select '1' from sys.foreign_keys fk, sys.schemas sch "
                            " where fk.schema_id = sch.schema_id and fk.name = " + toSearchDdlObjSqlName +
                            " and sch.name = " + toSearchDatabase;
                    }
                    else
                    {
                        cmd = "select '1' from sys.foreign_keys fk, sys.foreign_key_columns fkc, sys.columns sc, sys.objects fkt, sys.objects pkt, sys.schemas sch "
                            " where fk.parent_object_id = fkt.object_id and fk.object_id = fkc.constraint_object_id"
                            " and fkc.referenced_object_id = pkt.object_id"
                            " and fkt.schema_id = sch.schema_id"
                            " and fkt.object_id = sc.object_id and fkc.parent_column_id = sc.column_id"
                            " and fkt.name = " + toSearchTableSqlName +
                            " and sch.name = " + toSearchDatabase +
                            " and sc.name  = '" + refAttribSqlName + "'"
                            " and pkt.name = '" + refTableSqlName + "'";
                    }
                    break;

                default:
                    /* Nothing to do */
                    break;
            }
            break;

        case PostgreSQL:

            this->standardize(toSearchDdlObjSqlName);

            switch (ddlObjType)
            {
                case DdlObj_Table:
                    cmd = "select '1' from pg_catalog.pg_tables pt where pt.schemaname = " + toSearchDatabase + " and pt.tablename = " + toSearchTableSqlName;
                    break;

                case DdlObj_TempTable:
                    cmd = "select '1' from pg_catalog.pg_tables pt where pt.schemaname like 'pg_temp_% and pt.tablename = " + toSearchTableSqlName;
                    break;

                case DdlObj_View:
                    cmd = "select '1' from pg_catalog.pg_views pv where pv.schemaname = " + toSearchDatabase + " and pv.viewname = " + toSearchDdlObjSqlName;
                    break;

                case DdlObj_Trigger:
                    cmd = "select '1' from pg_catalog.pg_trigger pt where pt.tgname = " + toSearchDdlObjSqlName;
                    break;

                case DdlObj_SProc:
                case DdlObj_SpecSProc:
                case DdlObj_Func:
                    cmd = "select '1' from pg_proc p inner join pg_namespace n on n.oid = p.pronamespace where n.nspname = " + toSearchDatabase + " and proname = " + toSearchDdlObjSqlName;
                    break;

                case DdlObj_Column:
                    cmd = "select '1' from information_schema.columns sc where sc.table_catalog = current_catalog"
                        " and sc.table_schema = " + toSearchDatabase + 
                        " and sc.table_name = lower(" + toSearchTableSqlName + ")"
                        " and sc.column_name = " + toSearchDdlObjSqlName;
                    break;

                case DdlObj_ForeignKey:
                    if (refAttribSqlName.empty())
                    {
                        cmd = "select '1' from information_schema.table_constraints as tc join information_schema.key_column_usage as kcu "
                            "on tc.constraint_name = kcu.constraint_name "
                            "and tc.table_schema = kcu.table_schema "
                            "join information_schema.constraint_column_usage as ccu "
                            "on ccu.constraint_name = tc.constraint_name "
                            "and ccu.table_schema = tc.table_schema "
                            "where tc.constraint_type = 'FOREIGN KEY' "
                            "and tc.constraint_name = " + toSearchDdlObjSqlName;
                    }
                    else
                    {
                        cmd = "select '1' from information_schema.table_constraints as tc join information_schema.key_column_usage as kcu "
                            "on tc.constraint_name = kcu.constraint_name and tc.table_schema = kcu.table_schema "
                            "join information_schema.constraint_column_usage as ccu on ccu.constraint_name = tc.constraint_name and ccu.table_schema = tc.table_schema "
                            "where tc.constraint_type = 'FOREIGN KEY' "
                            "and tc.table_schema " + toSearchDatabase +
                            "and tc.table_name = lower(" + toSearchTableSqlName + ")"
                            "and ccu.column_name = lower(" + refAttribSqlName + ")"
                            "and ccu.table_name = lower(" + refTableSqlName + ")";
                    }
                    break;

                case DdlObj_Constraint:
                case DdlObj_Index:
                case DdlObj_TempTableIndex:
                case DdlObj_PrimaryKey:
                default:
                    SYS_BreakOnDebug();
                    break;
            }
            break;

        case Sqlite:

            this->standardize(toSearchDdlObjSqlName);

            switch (ddlObjType)
            {
                case DdlObj_Table:
                    cmd = "select tbl_name from sqlite_master where type='table' and tbl_name = " + toSearchTableSqlName;
                    break;

                case DdlObj_TempTable:
                    break;

                case DdlObj_View:
                    cmd = "select tbl_name from sqlite_master where type='view' and name = " + toSearchTableSqlName;
                    break;

                case DdlObj_Trigger:
                    break;

                case DdlObj_SProc:
                case DdlObj_SpecSProc:
                case DdlObj_Func:
                    break;

                case DdlObj_Column:
                    break;

                case DdlObj_ForeignKey:
                    break;

                case DdlObj_Constraint:
                case DdlObj_Index:
                case DdlObj_TempTableIndex:
                case DdlObj_PrimaryKey:
                default:
                    SYS_BreakOnDebug();
                    break;
            }
            break;

        default:
            SYS_BreakOnDebug();


    }
    return cmd;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getIdFromRequest
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
void DdlGenDbi::getIdFromRequest(const std::string& request, std::set<ID_T>& idSet, bool bSource, bool bAutonom)
{
    ID_T* idValuePtr = nullptr;

    DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);
    DbiConnection* dbiConn = (bAutonom ? nullptr : (bSource ? &ddlGenConnGuard.getDbiConn() : &ddlGenConnGuard.getDbiConnForDdl()));
    RequestHelper  requestHelper(dbiConn);
    requestHelper.setReadOnly(true);

    if (bSource)
    {
        requestHelper.m_useAlternativeDataServer = true;
    }

    requestHelper.setCommand(request);

    requestHelper.addNewOutputData(IdType);
    requestHelper.getBindVariablePtr(idValuePtr);

    if (requestHelper.sendCommandForFetch() == RET_SUCCEED)
    {
        while (requestHelper.fetch() == RET_SUCCEED)
        {
            idSet.insert(*idValuePtr);
        }
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getMaxId()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
ID_T DdlGenDbi::getMaxId(DICT_ENTITY_STP dictEntityStp, bool bSource)
{
    if (dictEntityStp->primKeyNbr == 1 &&
        (dictEntityStp->primKeyTab[0]->dataTpProgN == IdType ||
         dictEntityStp->primKeyTab[0]->dataTpProgN == DictType) &&
         dictEntityStp->xdStatusEn                 == XdStatus_Inserted &&
         dictEntityStp->entNatEn                   != EntityNat_TempTable)
    {
        stringstream  maxIdStream;
        string        idAttrStr = dictEntityStp->primKeyTab[0]->sqlName;

        maxIdStream
            << this->newLine() << "#NO_MULTI_ENTITY"
            << this->newLine() << "#NO_SECURED"
            << this->newLine() << "#DISABLE_CHANGE_SET"
            << this->newLine() << "#SELECT " << dictEntityStp->mdSqlName << " null std " << (this->tmpTableSqlName.empty() ? "" : this->tmpTableSqlName)
            << this->newLine() << "id = max(" << idAttrStr << ")"
            << this->newLine() << "#FROM"
            << this->newLine() << "#WHERE"
            << this->newLine() << "#END";

        std::set<ID_T> linkedIdSet;
        this->getIdFromRequest(maxIdStream.str(), linkedIdSet, bSource);

        if (linkedIdSet.empty() == false)
        {
            return *(linkedIdSet.begin());
        }
    }

    return 0;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getIdentityStartValue()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
ID_T DdlGenDbi::getIdentityStartValue(DICT_ENTITY_STP dictEntityStp, DdlGenEntity* ddlGenEntityPtr, bool bForce)
{
    if (dictEntityStp != nullptr &&
        dictEntityStp->entNatEn != EntityNat_TempTable &&
        (bForce ||
         this->ddlGenContextPtr->m_rdbmsEn == Oracle ||
         this->ddlGenContextPtr->m_rdbmsEn == Nuodb ||
         this->ddlGenContextPtr->m_rdbmsEn == PostgreSQL) &&
        this->ddlGenContextPtr->bSimulation == false &&
        this->m_ddlObjEn == DdlObj_Table &&
        this->ddlGenContextPtr->m_bIsInstallFromScratch == false &&
        this->ddlGenContextPtr->ddlGenAction.m_execModeEn != DbObjExecMod_BuildFromTemplate)
    {
        DICT_ENTITY_STP refEntityDictStp = nullptr;
        bool            bSource = (ddlGenEntityPtr == nullptr);
        std::string     realSqlName;

        if (dictEntityStp->dbRuleEn == DbRule_PrimaryKeyTable)
        {
            if (dictEntityStp->linkedEntityStp &&
                dictEntityStp->linkedEntityStp->primKeyNbr == 1)
            {
                refEntityDictStp = dictEntityStp->linkedEntityStp;
            }
        }
        else if (dictEntityStp->entNatEn != EntityNat_TempTable &&
                 (ddlGenEntityPtr == nullptr || ddlGenEntityPtr->getSysXdEntityStp(realSqlName) != nullptr))
        {
            refEntityDictStp = dictEntityStp;
        }

        this->m_startValue = this->getMaxId((refEntityDictStp == nullptr ? dictEntityStp : refEntityDictStp), bSource);

        if (refEntityDictStp != nullptr &&
            refEntityDictStp->xdStatusEn == XdStatus_Inserted &&
            refEntityDictStp->primKeyNbr &&
            refEntityDictStp->primKeyTab[0]->xdStatusEn != XdStatus_Untreated)
        {
            /* PMSTA-29925 - LJE - 180206 */
            if (refEntityDictStp->linkEntitiesMap.empty() == false)
            {
                for (auto it = refEntityDictStp->linkEntitiesMap.begin(); it != refEntityDictStp->linkEntitiesMap.end(); ++it)
                {
                    if (it->second->dbRuleEn == DbRule_Standard &&
                        it->second->entNatEn == refEntityDictStp->entNatEn &&
                        it->second->logicalFlg == FALSE &&
                        (refEntityDictStp->pkRuleEn == PkRule_NoIdentity || it->second->pkRuleEn == PkRule_NoIdentity) &&
                        it->second->xdStatusEn == XdStatus_Inserted &&
                        it->second->primKeyNbr > 0 &&
                        it->second->primKeyTab[0]->xdStatusEn != XdStatus_Untreated)
                    {
                        ID_T lnkStartValue = this->getMaxId(it->second, bSource);

                        if (lnkStartValue > this->m_startValue)
                        {
                            this->m_startValue = lnkStartValue;
                        }
                    }
                }
            }

            if (refEntityDictStp->physicalEntitiesMap.empty() == false)
            {
                for (auto it = refEntityDictStp->physicalEntitiesMap.begin(); it != refEntityDictStp->physicalEntitiesMap.end(); ++it)
                {
                    if (it->second->dbRuleEn == DbRule_Standard &&
                        it->second->entNatEn == refEntityDictStp->entNatEn &&
                        it->second->logicalFlg == FALSE &&
                        it->second->pkRuleEn != PkRule_NoIdentity &&
                        it->second->xdStatusEn == XdStatus_Inserted &&
                        it->second->primKeyNbr > 0 &&
                        it->second->primKeyTab[0]->xdStatusEn != XdStatus_Untreated)
                    {
                        ID_T lnkStartValue = this->getMaxId(it->second, bSource);

                        if (lnkStartValue > this->m_startValue)
                        {
                            this->m_startValue = lnkStartValue;
                        }
                    }
                }
            }
        }
    }

    return ++this->m_startValue;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::setIdentityStartValue()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
void DdlGenDbi::setIdentityStartValue(DICT_ENTITY_STP dictEntityStp, ID_T newStartValue)
{
    if (dictEntityStp->pkRuleEn == PkRule_Identity)
    {
        stringstream alterStream;

        switch (this->ddlGenContextPtr->m_rdbmsEn)
        {
            case Sybase:
                alterStream << "sp_chgattribute '" << dictEntityStp->dbSqlName << "', 'identity_burn_max', 0, '" << newStartValue << "'";
                break;

            case Oracle:
                alterStream << "ALTER TABLE " << dictEntityStp->dbSqlName << " MODIFY " << dictEntityStp->primKeyTab[0]->sqlName << " GENERATED BY DEFAULT ON NULL AS IDENTITY(START WITH " << newStartValue << ")";
                break;

            case Nuodb:
            {
                string sequenceName = this->getIdentitySequencName(dictEntityStp, dictEntityStp->dbSqlName);

                if (sequenceName.empty() == false)
                {
                    alterStream << "ALTER SEQUENCE " << sequenceName << " START WITH " << newStartValue;
                }
                break;
            }

            case MSSql:
                alterStream << "DBCC CHECKIDENT ('" << dictEntityStp->dbSqlName << "', RESEED, " << newStartValue << ")";
                break;

            case PostgreSQL:
                alterStream
                    << "select setval(pg_get_serial_sequence('"
                    << dictEntityStp->databaseName << "." << dictEntityStp->dbSqlName << "', '"
                    << dictEntityStp->primKeyTab[0]->sqlName << "'), " << newStartValue << ");";
                break;

            default:
                SYS_BreakOnDebug();

        }

        if (alterStream.str().empty() == false)
        {
            DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);
            RequestHelper requestHelper(&ddlGenConnGuard.getDbiConnForDdl());
            requestHelper.setCommand(alterStream.str());
            requestHelper.sendAndGetCommand();
        }
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::disableIdentity()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
void DdlGenDbi::disableIdentity(DICT_ENTITY_STP sourceDictEntityStp, DICT_ENTITY_STP targetDictEntityStp)
{
    if (this->targetTableEn == TargetTable_Main &&
        targetDictEntityStp->pkRuleEn == PkRule_Identity &&
        (sourceDictEntityStp->pkRuleEn == PkRule_Identity ||
         (sourceDictEntityStp->primKeyNbr == 1 && (sourceDictEntityStp->primKeyTab[0]->dataTpProgN == IdType ||
                                                   sourceDictEntityStp->primKeyTab[0]->dataTpProgN == DictType)) ||
         sourceDictEntityStp->sortedAttr.find(targetDictEntityStp->primKeyTab[0]->sqlName) != sourceDictEntityStp->sortedAttr.end()))
    {
        DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);
        DbiConnection& dbiConn = ddlGenConnGuard.getDbiConnForDdl();
        dbiConn.disableIdentity(this->getTargetDBName(), this->getEntityDbSqlName(targetDictEntityStp, targetDictEntityStp->mdSqlName));
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::enableIdentity()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
void DdlGenDbi::enableIdentity(DICT_ENTITY_STP sourceDictEntityStp, DICT_ENTITY_STP targetDictEntityStp)
{
    if (this->targetTableEn == TargetTable_Main &&
        targetDictEntityStp->pkRuleEn == PkRule_Identity)
    {
        DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);
        DbiConnection& dbiConn = ddlGenConnGuard.getDbiConnForDdl();
        if (dbiConn.m_insertIdentityOn)
        {
            dbiConn.enableIdentity(this->getTargetDBName(), this->getEntityDbSqlName(targetDictEntityStp, targetDictEntityStp->mdSqlName));
        }
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getIdByCode()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
ID_T DdlGenDbi::getIdByBk(DICT_ENTITY_STP dictEntityStp, const string& code)
{
    ID_T          idValue = 0;
    stringstream  requestStream;

    if (code.find_first_not_of(DDLGEN_NUMERIC) == string::npos)
    {
        idValue = ATOLL(code.c_str());
    }
    else if (dictEntityStp->xdStatusEn == XdStatus_Inserted &&
             dictEntityStp->primKeyNbr == 1 &&
             dictEntityStp->bkAttrNbr == 1 &&
             (dictEntityStp->primKeyTab[0]->dataTpProgN == IdType || dictEntityStp->primKeyTab[0]->dataTpProgN == DictType) &&
             (dictEntityStp->bkAttr[0]->dataTpProgN == CodeType || dictEntityStp->bkAttr[0]->dataTpProgN == SysnameType))
    {
        this->ddlGenContextPtr->writeLock();
        auto& entityIt = this->ddlGenContextPtr->m_parentContext->m_pkByBkMap[dictEntityStp->mdSqlName];
        this->ddlGenContextPtr->writeUnlock();

        auto& codeIt = entityIt[code];

        if (codeIt != 0)
        {
            idValue = codeIt;
        }
        else if (dictEntityStp->entNatEn == EntityNat_System)
        {
            DdlGenDbaAccessGuard ddlGenDbaAccessGuard(*this->ddlGenContextPtr);
            auto recordStp = ddlGenDbaAccessGuard.getDdlGenDbaAccess().getRecordByCode(dictEntityStp->objectEn, code);
            if (recordStp != nullptr)
            {
                idValue = GET_DICT(recordStp, dictEntityStp->primKeyTab[0]->progN);
                codeIt = idValue;
            }
        }
        else
        {
            this->ddlGenContextPtr->bForceTableName = true;
            requestStream
                << "select " << dictEntityStp->primKeyTab[0]->sqlName
                << " from " << this->getEntityFullSqlName(dictEntityStp, TargetTable_Undefined, string(), View_None)
                << " where " << dictEntityStp->bkAttr[0]->sqlName << " = ";

            if (code[0] == '\'')
            {
                requestStream << code;
            }
            else
            {
                requestStream << "'" << code << "'";
            }

            std::set<ID_T> idSet;
            this->getIdFromRequest(requestStream.str(), idSet, false);
            if (idSet.empty() == false)
            {
                idValue = *(idSet.begin());
            }

            /* Save the value in the this->ddlGenContextPtr->m_pkByBkMap */
            codeIt = idValue;
            this->ddlGenContextPtr->bForceTableName = false;
        }
    }
    else if (dictEntityStp->xdStatusEn == XdStatus_Inserted)
    {
        this->printMsg(RET_DBA_ERR_INVDATA, "Unsupported entity to find id from code (" + string(dictEntityStp->mdSqlName) + ")");
    }

    return idValue;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getIdsByQuery()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
void DdlGenDbi::getIdsByQuery(DICT_ENTITY_STP dictEntityStp, const std::string& query, std::set<ID_T>& idSet)
{
    if (dictEntityStp->xdStatusEn == XdStatus_Inserted &&
        dictEntityStp->primKeyNbr == 1 &&
        dictEntityStp->bkAttrNbr == 1 &&
        (dictEntityStp->primKeyTab[0]->dataTpProgN == IdType || dictEntityStp->primKeyTab[0]->dataTpProgN == DictType))
    {
        stringstream  requestStream;

        this->ddlGenContextPtr->bForceTableName = true;
        requestStream
            << "select " << dictEntityStp->primKeyTab[0]->sqlName
            << " from " << this->getEntityFullSqlName(dictEntityStp, TargetTable_Undefined, string(), View_None)
            << " where " << query;

        this->getIdFromRequest(requestStream.str(), idSet, false);

        this->ddlGenContextPtr->bForceTableName = false;
    }
    else if (dictEntityStp->xdStatusEn == XdStatus_Inserted)
    {
        this->printMsg(RET_DBA_ERR_INVDATA, "Unsupported entity to find id from code (" + string(dictEntityStp->mdSqlName) + ")");
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCountRecord()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
void DdlGenDbi::getCountRecord(DICT_ENTITY_STP dictEntityStp, const std::string& query, const std::string& realSqlName, ID_T& countNbr, bool bSource, bool bAutonom)
{
    countNbr = 0;

    if (dictEntityStp->xdStatusEn == XdStatus_Inserted)
    {
        stringstream  countStream;
        string        targetSqlName;

        this->ddlGenContextPtr->bForceTableName = true;

        TARGET_TABLE_ENUM  currTargetTableEn = this->targetTableEn;
        if (dictEntityStp->dbRuleEn == DbRule_NotMainTable)
        {
            currTargetTableEn = TargetTable_UserDefinedFields;
        }

        string filterScript;
        if (currTargetTableEn == TargetTable_Main || 
            currTargetTableEn == TargetTable_UserDefinedFields ||
            currTargetTableEn == TargetTable_Undefined)
        {
            filterScript = this->ddlGenContextPtr->getFilterScript(dictEntityStp);
        }

        countStream
            << this->newLine() << "#NO_MULTI_ENTITY"
            << this->newLine() << "#NO_SECURED"
            << this->newLine() << "#DISABLE_CHANGE_SET";

        if ((filterScript.empty() == false || query.empty() == false) &&
            currTargetTableEn == TargetTable_UserDefinedFields)
        {
            countStream
                << this->newLine() << "#SELECT " << dictEntityStp->custSqlName << " null ud"
                << this->newLine() << "record_nbr = #COUNT_BIG(1)"
                << this->newLine() << "#FROM"
                << this->newLine() << "inner join " << dictEntityStp->mdSqlName << " E on E.id = ud.ud_id"
                << this->newLine() << "#WHERE";
        }
        else
        {
            countStream
                << this->newLine() << "#SELECT " << (currTargetTableEn == TargetTable_UserDefinedFields ? dictEntityStp->custSqlName : dictEntityStp->mdSqlName) << " null E " << realSqlName
                << this->newLine() << "record_nbr = #COUNT_BIG(1)"
                << this->newLine() << "#FROM"
                << this->newLine() << "#WHERE";
        }

        if (filterScript.empty() == false)
        {
            countStream << this->newLine() << filterScript;
        }
        if (query.empty() == false)
        {
            countStream << this->newLine() << query;
        }
        countStream
            << this->newLine() << "#END";

        std::set<ID_T> idSet;
        this->getIdFromRequest(countStream.str(), idSet, bSource, bAutonom);

        if (idSet.empty() == false)
        {
            countNbr = *(idSet.begin());
        }

        this->ddlGenContextPtr->bForceTableName = false;
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getMasterBusinessEntityInfo()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
void DdlGenDbi::getMasterBusinessEntityInfo(DbiConnection* dbiConnPtr)
{
    try
    {
        char* codeValue = nullptr;
        ID_T* idValuePtr = nullptr;

        DbiConnectionHelper connHelper(dbiConnPtr, false);
        RequestHelper requestHelper(connHelper);
        requestHelper.setReadOnly(true);

        stringstream        requestStream;
        requestStream << "select id, code from business_entity" << (SYS_IsDdlGenMode() ? "" : "_bootstrap") << " where multi_entity_role_e = 1";
        requestHelper.setCommand(requestStream.str());

        requestHelper.addNewOutputData(IdType);
        requestHelper.getBindVariablePtr(idValuePtr);
        requestHelper.addNewOutputData(CodeType);
        requestHelper.getBindVariablePtr(codeValue);

        const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
        if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
        {
            auto& sqlTrace = dbiConnPtr->getSqlTrace();
            sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
            sqlTrace.m_procedure = "DynSql.GetMasterBE";
        }

        if (requestHelper.sendAndGetCommand() == RET_SUCCEED)
        {
            EV_MasterBusinessEntityId = *idValuePtr;
            EV_MasterBusinessEntity   = codeValue;
        }
    }
    catch (exception&)
    {
        EV_MasterBusinessEntityId = 0;
        EV_MasterBusinessEntity.clear();
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdIdentity()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdIdentity(bool bUpdate, ID_T startValue, int increment, DICT_ENTITY_STP sourceDictEntityStp)
{
    stringstream cmd;

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
            if (bUpdate == false &&
                (this->ddlGenContextPtr->migrationMode == DdlGenContext::MigrationMode::None ||
                 sourceDictEntityStp->pkRuleEn != PkRule_Identity))
            {
                cmd << "identity";
            }
            break;

        case Oracle:
            if (bUpdate)
            {
                cmd << "GENERATED BY DEFAULT ON NULL AS IDENTITY (INCREMENT BY " << increment << " CACHE " << this->ddlGenContextPtr->identityCacheSize << ")";
            }
            else
            {
                cmd << "GENERATED BY DEFAULT ON NULL AS IDENTITY INCREMENT BY " << increment << " MAXVALUE 99999999999999 MINVALUE " << startValue << " CACHE " << this->ddlGenContextPtr->identityCacheSize;
            }
            break;

        case Nuodb:
            cmd << "GENERATED BY DEFAULT AS IDENTITY";
            break;

        case MSSql:
            if (bUpdate == false)
            {
                cmd << "identity(" << startValue << "," << increment << ")";
            }
            break;

        case Sqlite:
            if (this->ddlGenContextPtr->migrationMode == DdlGenContext::MigrationMode::None ||
                sourceDictEntityStp == nullptr ||
                (sourceDictEntityStp->pkRuleEn != PkRule_Identity &&
                 (sourceDictEntityStp->primKeyNbr != 1 || (sourceDictEntityStp->primKeyTab[0]->dataTpProgN != IdType &&
                                                           sourceDictEntityStp->primKeyTab[0]->dataTpProgN != DictType))))
            {
                cmd << "primary key autoincrement";
            }
            break;

        case PostgreSQL:
            cmd << "generated by default as identity";
            break;

        case QtHttp:
            break;

        default:
            SYS_BreakOnDebug();
    }
    return cmd.str();
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdIdentityIncrement()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdIdentityIncrement(DdlGenVar* varDest, string databaseStr, string entityStr)
{
    stringstream outStream;

    this->standardize(databaseStr);
    this->standardize(entityStr);

    this->varHelperPtr->setModify(*varDest);

    outStream << this->newLine();

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
            outStream <<
                "select " << varDest->printSqlName() << " = "
                "convert(int, s1.value2) from master..syscurconfigs s1, master..sysconfigures s2 where s1.config = s2.config and s2.name = 'identity reservation size'";
            break;

        case Oracle:
            outStream <<
                "select seq.increment_by into " << varDest->printSqlName() <<
                " from all_tab_identity_cols id_col inner join all_sequences seq on id_col.owner = seq.sequence_owner and id_col.sequence_name = seq.sequence_name"
                " where owner = '" << databaseStr << "' and table_name = '" << entityStr << "'" << this->endOfCmd();
            break;

        case Nuodb:
            outStream << varDest->printSqlName() << " = 1" << this->endOfCmd();
            break;

        case MSSql:
            outStream <<
                "select " << varDest->printSqlName() << " = convert(int, id_col.increment_value) "
                "from sys.identity_columns id_col, sys.objects so "
                "where id_col.object_id = so.object_id and so.type = 'U' and so.name = '" << entityStr << "'" << this->endOfCmd();
            break;

        case PostgreSQL:
            outStream << varDest->printSqlName() << " = 1" << this->endOfCmd();
            break;

        default:
            SYS_BreakOnDebug();

    }
    return outStream.str();
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getIdentitySequencName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getIdentitySequencName(DICT_ENTITY_STP dictEntityStp, std::string tableName)
{
    string databaseName(this->m_dbSqlName.empty() ? dictEntityStp->databaseName : this->m_dbSqlName);

    this->standardize(databaseName);
    this->standardize(tableName);

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case MSSql:
            break;

        case Oracle:
        {
            DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);
            RequestHelper  requestHelper(&ddlGenConnGuard.getDbiConnForDdl());
            requestHelper.setReadOnly(true);

            char* seqName = nullptr;

            const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
            if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
            {
                auto& sqlTrace = ddlGenConnGuard.getDbiConnForDdl().getSqlTrace();
                sqlTrace.m_procedure = "DynSql.GetSequenceName";
                sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
            }

            requestHelper.addNewParamString(databaseName, String1000Type);
            requestHelper.addNewParamString(tableName, String1000Type);
            requestHelper.setCommand("select sequence_name from all_tab_identity_cols where  owner = ? and table_name = ?");
            requestHelper.addNewOutputData(LongSysnameType);
            requestHelper.getBindVariablePtr(seqName);

            if (requestHelper.sendAndGetCommand() == RET_SUCCEED)
            {
                return seqName;
            }

            break;
        }

        case Nuodb:
        {
            DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);
            RequestHelper  requestHelper(&ddlGenConnGuard.getDbiConnForDdl());
            requestHelper.setReadOnly(true);

            char* seqName = nullptr;

            const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
            if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
            {
                auto& sqlTrace = ddlGenConnGuard.getDbiConnForDdl().getSqlTrace();
                sqlTrace.m_procedure = "DynSql.GetSequenceName";
                sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
            }

            if (dictEntityStp->primKeyNbr == 1)
            {
                requestHelper.addNewParamString(databaseName, String1000Type);
                requestHelper.addNewParamString(tableName, String1000Type);
                requestHelper.addNewParamString(dictEntityStp->primKeyTab[0]->sqlName, String1000Type);
                requestHelper.setCommand("select generator_sequence from system.fields where schema = ? and tablename = ? and field = upper(?)");
                requestHelper.addNewOutputData(LongSysnameType);
                requestHelper.getBindVariablePtr(seqName);
            }

            if (requestHelper.sendAndGetCommand() == RET_SUCCEED)
            {
                return seqName;
            }
            break;
        }

        case PostgreSQL:
        {
            DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);
            RequestHelper  requestHelper(&ddlGenConnGuard.getDbiConnForDdl());
            requestHelper.setReadOnly(true);

            char* seqName = nullptr;

            const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
            if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
            {
                auto& sqlTrace = ddlGenConnGuard.getDbiConnForDdl().getSqlTrace();
                sqlTrace.m_procedure = "DynSql.GetSequenceName";
                sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
            }

            requestHelper.addNewParamString(tableName, String1000Type);
            requestHelper.addNewParamString(lower(dictEntityStp->primKeyTab[0]->sqlName), String1000Type);
            requestHelper.setCommand("select pg_get_serial_sequence(?,  ?)");
            requestHelper.addNewOutputData(LongSysnameType);
            requestHelper.getBindVariablePtr(seqName);

            if (requestHelper.sendAndGetCommand() == RET_SUCCEED)
            {
                return seqName;
            }

            break;
        }

        default:
            SYS_BreakOnDebug();
    }

    return string();
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdReserveIdentity()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdReserveIdentity(DdlGenVar*          varDest, 
                                        DICT_ENTITY_STP     dictEntityStp, 
                                        const string&       entityStr, 
                                        const string&       resNbrStr, 
                                        DdlGenFromFile *    ddlGenfromFilePtr)
{
    stringstream outStream;

    string sequenceName = this->getIdentitySequencName(dictEntityStp, entityStr);

    if (varDest != nullptr)
    {
        this->varHelperPtr->setModify(*varDest);
    }

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
            outStream << this->newLine() <<
                "select " << (varDest != nullptr ? (varDest->printSqlName() + " = ") : "") <<
                "convert(numeric, reserve_identity('" << entityStr << "', " << resNbrStr << "))";
            break;


        case Oracle:
        {
            outStream.clear();
            outStream.str(string());

            outStream << this->newLine()
                << (varDest != nullptr ? (varDest->printSqlName() + " := ") : "") << sequenceName << ".nextval";

            if (varDest != nullptr)
            {
                outStream << this->endOfCmd();
            }
            break;
        }

        case PostgreSQL:
        {
            outStream.clear();
            outStream.str(string());

            outStream << this->newLine()
                << (varDest != nullptr ? (varDest->printSqlName() + " := ") : "") << "nextval('" << sequenceName << "')";

            if (varDest != nullptr)
            {
                outStream << this->endOfCmd();
            }
            break;
        }

        case Nuodb:
        {
            outStream.clear();
            outStream.str(string());

            outStream << this->newLine() <<
                (varDest != nullptr ? (varDest->printSqlName() + " = ") : "") << "(select next value for " << sequenceName << " from dual)";

            if (varDest != nullptr)
            {
                outStream << this->endOfCmd();
            }
            break;
        }

        case MSSql:
            /* PMSTA-55474 vpr 20240719 */
            if(ddlGenfromFilePtr != NULL)
            {
                stringstream    insertStatement;

                insertStatement
                    << this->newLine() << "#INSERT " << dictEntityStp->mdSqlName << " all_db"
                    << this->newLine() << "#VALUES";
                insertStatement
                    << this->newLine() << "obj_status_e = " << (int)ObjStatus_Validated << " /* Validated */";
                
                insertStatement
                    << this->newLine() 
                    << "#IDENTITY " << varDest->printSqlName();

                insertStatement
                    << this->newLine() << "#END";

                outStream << ddlGenfromFilePtr->buildScript(insertStatement.str());

            }
            break;

        default:
            SYS_BreakOnDebug();
    }
    return outStream.str();
}

/************************************************************************
**
**  Function    :   DdlGenDbi::sqlExec()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-24564 - LJE - 161130
**
*************************************************************************/
RET_CODE DdlGenDbi::sqlExec(const DdlObjDef& ddlGenObjDef)
{
    RET_CODE            ret;
    DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);
    RequestHelper       requestHelper(&ddlGenConnGuard.getDbiConnForDdl());
    requestHelper.setDdlGen();
    requestHelper.useDb(this->ddlGenContextPtr->getDdlDestDbName());

    this->ddlGenContextPtr->m_ddlObjStatMap[this->m_ddlObjEn][this->cmdType]++;

    SYS_SetThreadCallStackGeneration(false);
    requestHelper.setExternalMsgManagement(true);

    requestHelper.setCommand(ddlGenObjDef.m_bodyStr);
    ret = requestHelper.sendAndGetCommand();

    if (ret != RET_SUCCEED)
    {
        int firstErrLine = 0;
        string errorMsg = this->getErrorMessages(ret,
                                                 requestHelper.getMsgStructHeader(),
                                                 ddlGenObjDef.getDdlObjEn(),
                                                 ddlGenObjDef.getObjName(),
                                                 ddlGenObjDef.m_bodyStr,
                                                 firstErrLine);

        if (errorMsg.empty() == false)
        {
            MSG_LogMesg(RET_GEN_ERR_PERSONAL,
                        1,
                        ddlGenObjDef.m_outputFileStr.c_str(),
                        ddlGenObjDef.m_outFileLinePos + firstErrLine,
                        errorMsg.c_str());
        }
    }
    else /* Flush warning messages */
    {
        requestHelper.setExternalMsgManagement(true);
        requestHelper.printMsg();
    }

    SYS_SetThreadCallStackGeneration(true);

    this->m_paramVector.clear();

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::sqlExec()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-24564 - LJE - 161130
**
*************************************************************************/
RET_CODE DdlGenDbi::sqlExec(const std::string& strToSend)
{
    RET_CODE            ret;

    DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);
    RequestHelper       requestHelper(&ddlGenConnGuard.getDbiConnForDdl());
    if (this->cmdType != DDlCmdType_DML)
    {
        requestHelper.setDdlGen();
    }
    else
    {
        requestHelper.setReadOnly(false);
    }
    requestHelper.useDb(this->ddlGenContextPtr->getDdlDestDbName());

    this->ddlGenContextPtr->m_ddlObjStatMap[this->m_ddlObjEn][this->cmdType]++;

    for (auto it = this->m_paramVector.begin(); it != this->m_paramVector.end(); ++it)
    {
        requestHelper.addNewParamString(*it, String1000Type);
    }

    SYS_SetThreadCallStackGeneration(false);
    requestHelper.setExternalMsgManagement(true);

    const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
    if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
    {
        auto& sqlTrace = ddlGenConnGuard.getDbiConnForDdl().getSqlTrace();
        sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
        sqlTrace.m_procedure = "DdlGen.";
        sqlTrace.m_procedure += this->getDdlObjEnStr();
    }

    requestHelper.setCommand(strToSend);
    ret = requestHelper.sendAndGetCommand();

    if (ret != RET_SUCCEED)
    {
        int firstErrLine = 0;
        string errorMsg = this->getErrorMessages(ret,
                                                 requestHelper.getMsgStructHeader(),
                                                 this->m_ddlObjEn,
                                                 this->getDdlObjSqlName(),
                                                 strToSend,
                                                 firstErrLine);

        if (errorMsg.empty() == false)
        {
            if (this->fileHelper)
            {
                MSG_LogMesg(RET_GEN_ERR_PERSONAL,
                            1,
                            this->fileHelper->outputFileStr.c_str(),
                            this->fileHelper->outFileLinePos + firstErrLine,
                            errorMsg.c_str());
            }
            else
            {
                MSG_LogMesg(RET_GEN_ERR_PERSONAL,
                            1,
                            this->getMsgSqlName().c_str(),
                            0,
                            errorMsg.c_str());
            }
        }
    }
    else /* Flush warning messages */
    {
        requestHelper.printMsg();

        for (auto &msgStructIt : requestHelper.getMsgStructHeader().msgStructTab)
        {
            string textStr;

            msgStructIt.isAlreadyWritedInLog = true;

            if (msgStructIt.rdbmsMsgString.empty() == false)
            {
                textStr = msgStructIt.rdbmsMsgString;
            }
            else
            {
                if (msgStructIt.msgString.empty() == false)
                {
                    textStr = msgStructIt.msgString;
                }
            }

            if (textStr.empty() == false)
            {
                if (this->fileHelper)
                {
                    MSG_LogMesg(RET_GEN_ERR_PERSONAL,
                                1,
                                this->fileHelper->outputFileStr.c_str(),
                                this->fileHelper->outFileLinePos,
                                textStr.c_str());
                }
                else
                {
                    MSG_LogMesg(RET_GEN_ERR_PERSONAL,
                                1,
                                this->getMsgSqlName().c_str(),
                                0,
                                textStr.c_str());
                }
            }
        }
    }
    SYS_SetThreadCallStackGeneration(true);

    this->m_paramVector.clear();

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getErrorMessages()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getErrorMessages(RET_CODE& sqlExecRet,
                                   DBA_ERRMSG_HEADER_ST& msgStructHeaderSt,
                                   DDL_OBJ_ENUM          ddlObjType,
                                   const std::string& ddlSqlName,
                                   const string& ddlGenStr,
                                   int& firstErrLine)
{
    stringstream        outStream;
    string              newLine;
    std::string         database(this->ddlGenContextPtr->getDdlDestDbName());
    bool                bHideError = false;
    DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);

    if ((this->m_ddlObjEn == DdlObj_SProc || this->m_ddlObjEn == DdlObj_Func) &&
        ddlGenConnGuard.getDbiConnForDdl().getConnSessionProperties().isDeferredNameResolution())
    {
        bHideError = true;
    }

    auto msgStructTab = msgStructHeaderSt.msgStructTab;
    for (auto &errMsgStructIt : msgStructTab)
    {
        errMsgStructIt.isAlreadyWritedInLog = true;

        string textStr;
        char  unknown[] = "Unknown message ";
        if (errMsgStructIt.rdbmsMsgString.empty() == false)
        {
            textStr = errMsgStructIt.rdbmsMsgString;
        }
        else
        {
            if (errMsgStructIt.msgString.empty() == false)
            {
                textStr = errMsgStructIt.msgString;
            }
            else
            {
                textStr = (char*)&unknown;
            }
        }

        switch (this->ddlGenContextPtr->m_rdbmsEn)
        {
            case Sybase:
                if (ddlGenConnGuard.getDbiConnForDdl().isWarningMsgToHide(errMsgStructIt) == false)
                {
                    if (bHideError == false)
                    {
                        outStream
                            << newLine
                            << textStr.substr(0, 150) << endl
                            << "SYBASE ERROR: " << errMsgStructIt.rdbmsMsgNb << "\t" << endl
                            << "LEVEL       : 0x" << std::hex << errMsgStructIt.gravity << std::dec << endl
                            << "DDL OBJECT  : " << errMsgStructIt.procedure << ":" << errMsgStructIt.line << endl;

                        firstErrLine = errMsgStructIt.line;
                    }
                    else
                    {
                        sqlExecRet = RET_GEN_INFO_NODATA;
                    }
                }
                else
                {
                    sqlExecRet = RET_SUCCEED;
                }
                break;

            case Oracle:

                if (bHideError &&
                    errMsgStructIt.rdbmsMsgNb == 24344) /* ORA-24344: success with compilation error */
                {
                    sqlExecRet = RET_DBA_INFO_EXIST;
                }
                /* Test to call alter table existing table */
                else if (errMsgStructIt.rdbmsMsgNb == 1440)    /* ORA-01440: column to be modified must be empty to decrease precision or scale */
                {
                    sqlExecRet = RET_DBA_INFO_NODATA;
                }
                else
                {
                    string              typeStr = DdlGenDbi::getDdlObjType(ddlObjType);

                    outStream << newLine;

                    if (typeStr.empty() == false && EV_UseAlternativeDataSource == false)
                    {
                        outStream << textStr.substr(0, 150);

                        stringstream getErrStream;

                        RequestHelper requestHelper(&ddlGenConnGuard.getDbiConn());
                        requestHelper.setReadOnly(true);
                        requestHelper.addNewParamString(upper(database), String1000Type);
                        requestHelper.addNewParamString(typeStr, String1000Type);
                        requestHelper.addNewParamString(upper(ddlSqlName), String1000Type);
                        requestHelper.setCommand("select line, position, text from all_errors where owner = ? and type = ? and name = ?");

                        char* text = nullptr;
                        INT_T* linePtr = nullptr;
                        INT_T* positionPtr = nullptr;

                        requestHelper.addNewOutputData(IntType);
                        requestHelper.getBindVariablePtr(linePtr);
                        requestHelper.addNewOutputData(IntType);
                        requestHelper.getBindVariablePtr(positionPtr);
                        requestHelper.addNewOutputData(String4000Type);
                        requestHelper.getBindVariablePtr(text);

                        if (requestHelper.sendCommandForFetch() == RET_SUCCEED)
                        {
                            while (requestHelper.fetch() == RET_SUCCEED)
                            {
                                if (firstErrLine == -1)
                                {
                                    firstErrLine = *linePtr;
                                }
                                outStream << "              Error(" << *linePtr << "," << *positionPtr << "): " << text << endl;
                            }
                        }
                        outStream
                            << "DDL OBJECT  : " << ddlSqlName << ":" << firstErrLine << endl;

                        firstErrLine = errMsgStructIt.line;
                    }
                    else
                    {
                        outStream << textStr;
                    }
                }
                break;

            case Nuodb:
                if (bHideError &&
                    /* An error has occurred during compilation of the SQL statement */
                    (errMsgStructIt.rdbmsMsgNb == -4 ||
                     errMsgStructIt.rdbmsMsgNb == -1))
                {
                    sqlExecRet = RET_GEN_INFO_NODATA;
                }
                else
                {
                    outStream << newLine << textStr;
                }
                break;

            case MSSql:
            case PostgreSQL:
                if (bHideError)
                {
                    sqlExecRet = RET_GEN_INFO_NODATA;
                }
                else
                {
                    outStream << newLine << textStr;
                }
                break;
        }

        if (newLine.empty())
        {
            newLine = "\n--------------------------------------------------\n";
        }
    }

    if (outStream.str().empty() == false)
    {
        outStream << endl << ddlGenStr.substr(0, 500) << endl;
    }

    this->lastErrRetCode = sqlExecRet;

    return outStream.str();
}

/************************************************************************
**
**  Function    :   DdlGenDbi::compileDdlObj()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
RET_CODE DdlGenDbi::compileDdlObj(const DdlObjDef& ddlGenObjDef)
{
    RET_CODE ret = RET_SUCCEED;

    if (this->ddlGenContextPtr->m_rdbmsEn == Oracle)
    {
        if (ddlGenObjDef.m_bodyStr.empty() == false)
        {
            ret = this->sqlExec(ddlGenObjDef);
        }
        else
        {
            ret = RET_DBA_ERR_INVDATA;
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::checkDdlObj()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
RET_CODE DdlGenDbi::checkDdlObj(const DdlObjDef& ddlGenObjDef)
{
    RET_CODE ret = RET_DBA_ERR_INVDATA;

    if (this->ddlGenContextPtr->m_rdbmsEn == Oracle)
    {
        string              typeStr = DdlGenDbi::getDdlObjType(ddlGenObjDef.getDdlObjEn());

        if (typeStr.empty() == false)
        {
            DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);
            RequestHelper requestHelper(&ddlGenConnGuard.getDbiConn());
            requestHelper.setReadOnly(true);

            const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
            if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
            {
                auto& sqlTrace = ddlGenConnGuard.getDbiConn().getSqlTrace();
                sqlTrace.m_procedure = "DynSql.CheckDDlObj";
                sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
            }

            requestHelper.addNewParamString(upper(ddlGenObjDef.getDbName()), String1000Type);
            requestHelper.addNewParamString(typeStr, String1000Type);
            requestHelper.addNewParamString(upper(ddlGenObjDef.getObjName()), String1000Type);
            requestHelper.setCommand("select status from all_objects where owner = ? and object_type = ? and object_name = ?");

            requestHelper.addNewOutputData(LongSysnameType);
            char* text;
            requestHelper.getBindVariablePtr(text);
            if (requestHelper.sendAndGetCommand() == RET_SUCCEED &&
                strcmp(text, "VALID") == 0)
            {
                ret = RET_SUCCEED;
            }
        }
    }
    else
    {
        ret = RET_SUCCEED;
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdIsNull()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdIsNull(DBA_RDBMS_ENUM rdbmsEn)
{
    string cmd;

    switch (rdbmsEn)
    {
        case Sybase:
        case MSSql:
            cmd = "isnull";
            break;
        case Oracle:
            cmd = "NVL";
            break;
        case Sqlite:
            cmd = "ifnull";
            break;
        case Nuodb:
            cmd = "IFNULL";
            break;
        case PostgreSQL:
            cmd = "COALESCE";
            break;
        case QtHttp:
            break;
        default:
            SYS_BreakOnDebug();

    }
    return cmd;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdIsNull()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdIsNull()
{
    return DdlGenDbi::getCmdIsNull(this->ddlGenContextPtr->m_rdbmsEn);
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdChar()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdChar()
{
    string cmd;

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case PostgreSQL:
        case Oracle:
            cmd = "chr";
            break;

        case Sybase:
        case Nuodb:
        case MSSql:
        case Sqlite:
            cmd = "char";
            break;

        case QtHttp:
            break;

        default:
            SYS_BreakOnDebug();
    }
    return cmd;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdAscii()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdAscii()
{
    string cmd;

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case Oracle:
        case MSSql:
        case PostgreSQL:
        case QtHttp:
            cmd = "ascii";
            break;
        case Nuodb:
        case Sqlite:
            cmd = "unicode";
            break;
        default:
            SYS_BreakOnDebug();

    }
    return cmd;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getAllTriggers()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getAllTriggers()
{
    string cmd;

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Oracle:
            cmd = "all triggers";
            break;
        case MSSql:
            cmd = "trigger all";
            break;
        case Sybase:
        case PostgreSQL:
        case Nuodb:
        case Sqlite:
        case QtHttp:
            cmd = "trigger";
            break;
        default:
            SYS_BreakOnDebug();
    }
    return cmd;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getAllTriggersCmd()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
void DdlGenDbi::getAllTriggersCmd(const std::string& fullSqlName, bool bEnable, std::vector<std::string>& allTriggersReqVector)
{
    vector<string>  tokens;
    DdlGen::tokenizeStr(tokens, fullSqlName, ".");

    string      tableSqlName;
    string      dbName;

    if (tokens.size() == 1)
    {
        dbName = this->getDdlGenContextPtr()->getDdlDestDbName();
        tableSqlName = tokens.at(0);
    }
    else
    {
        dbName = tokens.at(0);
        tableSqlName = tokens.at(tokens.size() - 1);
    }
    tableSqlName = this->getEntityDbSqlName(nullptr, tableSqlName.c_str());

    if (this->ddlGenContextPtr->m_rdbmsEn == Nuodb)
    {
        map<DdlObjDefKey, DdlObjDef> triggersDefMap;

        this->getAllDdlObjListFromDb(triggersDefMap,
                                     dbName,
                                     tableSqlName,
                                     string(),
                                     DdlObj_Trigger);
        for (auto it = triggersDefMap.begin(); it != triggersDefMap.end(); ++it)
        {
            stringstream cmd;
            cmd << "alter trigger " << it->second.getDbObjName() << " for " << this->getDdlFullName(dbName, tableSqlName) << (bEnable ? " active" : " inactive");
            allTriggersReqVector.push_back(cmd.str());
        }
    }
    if (this->ddlGenContextPtr->m_rdbmsEn == PostgreSQL)
    {
        map<DdlObjDefKey, DdlObjDef> triggersDefMap;

        this->getAllDdlObjListFromDb(triggersDefMap,
                                     dbName,
                                     tableSqlName,
                                     string(),
                                     DdlObj_Trigger);
        for (auto it = triggersDefMap.begin(); it != triggersDefMap.end(); ++it)
        {
            stringstream cmd;
            cmd << "alter table " << this->getDdlFullName(dbName, tableSqlName) << (bEnable ? " enable " : " disable ") << " trigger " << it->second.getDbObjName();
            allTriggersReqVector.push_back(cmd.str());
        }
    }
    else
    {
        stringstream cmd;
        cmd << "alter table " << this->getDdlFullName(dbName, tableSqlName) << (bEnable ? " enable " : " disable ") << this->getAllTriggers();
        allTriggersReqVector.push_back(cmd.str());
    }
}


/************************************************************************
**
**  Function    :   DdlGenDbi::getDisableAllTriggersCmd()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
void DdlGenDbi::getDisableAllTriggersCmd(const std::string& fullSqlName, std::vector<std::string>& allTriggersReqVector)
{
    this->getAllTriggersCmd(fullSqlName, false, allTriggersReqVector);
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getEnableAllTriggersCmd()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
void DdlGenDbi::getEnableAllTriggersCmd(const std::string& fullSqlName, std::vector<std::string>& allTriggersReqVector)
{
    this->getAllTriggersCmd(fullSqlName, true, allTriggersReqVector);
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdGetDate()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdGetDate()
{
    string cmd;

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case QtHttp:
            cmd = "getdate()";
            break;

        case Oracle:
            cmd = "sysdate";
            break;

        case Nuodb:
            cmd = "now()";
            break;

        case MSSql:
            cmd = "getdate()";
            break;

        case PostgreSQL:
            cmd = "localtimestamp";
            break;

        case Sqlite:
            cmd = "datetime()";
            break;

        default:
            SYS_BreakOnDebug();

    }
    return cmd;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdGetDateTime()
**
**  Description :   Need millisecond precision for DateTime on Oracle
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:  PMSTA-25331 - TEB - 20171018
**
*************************************************************************/
string DdlGenDbi::getCmdGetDateTime()
{
    string cmd;

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case QtHttp:
            cmd = "getdate()";
            break;

        case Oracle:
            cmd = "systimestamp";
            break;

        case Nuodb:
            cmd = "now()";
            break;

        case MSSql:
            cmd = "getdate()";
            break;

        case PostgreSQL:
            cmd = "localtimestamp";
            break;

        case Sqlite:
            cmd = "(STRFTIME('%Y-%m-%d %H:%M:%f', 'NOW'))";
            break;

        default:
            SYS_BreakOnDebug();
    }
    return cmd;
}


/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdMagicBeginDate()
**
**  Description :   SYB_BEGIN_DATE constant
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdMagicBeginDate()
{
    string cmd;

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
            cmd = "'jan 01 1753 12:00:00AM'";
            break;
        case Oracle:
            cmd = "TO_DATE('01-01-1753', 'dd-mm-yyyy')";
            break;
        case Nuodb:
        case QtHttp:
            cmd = "'1753/01/01'";
            break;
        case MSSql:
            cmd = "CONVERT(datetime, '1753-01-01 00:00:00',120)";
			break;
    }
    return cmd;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdMagicEndDate()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdMagicEndDate()
{
    string cmd;

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
            cmd = "'dec 31 9999 12:00:00AM'";
            break;

        case Oracle:
            cmd = "TO_DATE('31-12-9999', 'dd-mm-yyyy')";
            break;

        case Nuodb:
        case QtHttp:
            cmd = "'9999/12/31'";
            break;

        case MSSql:
            cmd = "CONVERT(datetime, '9999-12-31 00:00:00',120)";
            break;

        case PostgreSQL:
            cmd = "to_date('31-12-9999', 'DD/MM/YYYY')";
            break;

        case Sqlite:
            cmd = "date('9999-12-31')";
            break;

        default:
            SYS_BreakOnDebug();
    }
    return cmd;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdUpdateCount()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdUpdateCount(DdlGenContext* ddlGenContextPtr)
{
    ddlGenContextPtr->printMsg(RET_GEN_ERR_INVARG, SYS_Stringer("#UPDATE_COUNT must be put inside #INSERT or #UPDATE keyword or use #GET_UPDATE_COUNT"));
    return string();
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdAssignUpdateCount()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdAssignUpdateCount(const std::string& varSqlName)
{
    stringstream assignStream;

    DdlGenVar* countVar = this->varHelperPtr->getVariable(varSqlName);

    if (countVar != nullptr)
    {
        if (countVar->getDataType() != IntType)
        {
            this->printMsg(RET_DBA_ERR_INVDATA, "Invalid data-type for #UPDATE_COUNT variable '" + countVar->sqlName + "', must be int_t");
        }

        switch (ddlGenContextPtr->m_rdbmsEn)
        {
            case Sybase:
            case MSSql:
            case Oracle:
            case Nuodb:
            {
                string cmd;
                switch (this->ddlGenContextPtr->m_rdbmsEn)
                {
                    case Sybase:
                    case MSSql:
                        cmd = "@@rowcount";
                        break;
                    case Oracle:
                        cmd = "sql%rowcount";
                        break;
                    case Nuodb:
                        cmd = "getupdatecount()";
                        break;
                }
                assignStream
                    << "#ASSIGN @" << countVar->sqlName << " = " << cmd;
                break;
            }

            case PostgreSQL:
                assignStream
                    << "GET DIAGNOSTICS @" << countVar->sqlName << " = ROW_COUNT;";
                break;

            default:
                SYS_BreakOnDebug();
        }
    }
    else
    {
        this->printMsg(RET_DBA_ERR_INVDATA, "Unknown #UPDATE_COUNT variable '" + varSqlName + "'");
    }
    return assignStream.str();
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdModifStatMask()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdModifStatMask()
{
    string cmd = this->getDbo() + "get_modif_stat_mask()";

    return cmd;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdBootTime()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdBootTime()
{
    string cmd;

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
            cmd = "@@boottime";
            break;
        case Oracle:
            cmd = "(select startup_time from sys.v_$instance)";
            break;
        case MSSql:
            cmd = "select sqlserver_start_time from sys.dm_os_sys_info";
            break;
        case PostgreSQL:
            cmd = "pg_postmaster_start_time()";
            break;
    }
    return cmd;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdCountBig()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdCountBig()
{
    string cmd;

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case MSSql:
            cmd = "count_big";
            break;
        case Oracle:
        case Nuodb:
        case PostgreSQL:
        default:
            cmd = "count";
            break;
    }
    return cmd;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdTranscount()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdTranscount()
{
    string cmd;

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case MSSql:
            cmd = "@@trancount";
            break;

        case Nuodb:
        case Oracle:
        default:
            cmd = "1";
            break;
    }
    return cmd;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdTranstate()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdTranstate()
{
    string cmd;

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
            cmd = "@@transtate";
            break;

        case Oracle:
        case PostgreSQL:
            cmd = "get_trans_state()";
            break;

        case MSSql:
            cmd = "(case xact_state() when 0 then 1 when -1 then 2 else 0 end)";
            break;

        case Nuodb:
            cmd = "1";
            break;
    }
    return cmd;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdSpid()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdSpid()
{
    string cmd;

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case MSSql:
            cmd = "@@spid";
            break;
        case Oracle:
            cmd = "userenv('sessionid')";
            break;
        case Nuodb:
            cmd = "GETCONNECTIONID()"; /* TODO - DDV - 191114 -Is it the right function to use? */
            break;
        case PostgreSQL:
            cmd = "pg_backend_pid()";
            break;
    }
    return cmd;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdHostName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdHostName()
{
    string cmd;

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case MSSql:
            cmd = "host_Name()";
            break;
        case Oracle:
            cmd = "SYS_CONTEXT('USERENV', 'SERVER_HOST')";
            break;
        case PostgreSQL:
            cmd = "inet_server_addr()";
            break;
    }
    return cmd;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getUpdating()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getUpdating()
{
    string cmd;

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case MSSql:
            cmd = "update";
            break;
        case Oracle:
            cmd = "updating";
            break;
    }
    return cmd;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::manageHintIndexTag()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 151014
**
*************************************************************************/
string DdlGenDbi::manageHintIndexTag(DdlGenContext* ddlGenContextPtr, DdlGenVarHelper*, std::vector<std::vector<std::string>>& keywordParamList)
{
    string toReplace;

    switch (ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
            if (ddlGenContextPtr->getMultiEntityLevel() == MultiEntityLevel_None &&
                keywordParamList.size() == 1 &&
                ddlGenContextPtr->getDdlGenMode() == DdlGenMode_Standard)
            {
                toReplace = "(index " + keywordParamList[0][0] + ")";
            }
            break;

        case Oracle:
            break;

        case Nuodb:
            break;
    }

    return toReplace;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::manageHintTag()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37366 - LJE - 191008
**
*************************************************************************/
string DdlGenDbi::manageHintTag(DdlGenContext* ddlGenContextPtr, DdlGenVarHelper*, std::vector<std::vector<std::string>>& keywordParamList)
{
    string toReplace;

    if (keywordParamList.size() < 2)
    {
        return string();
    }

    if (ddlGenContextPtr->getDdlGenMode() == DdlGenMode_Standard)
    {
        bool   bTreat = false;
        string  rdbmsNameStr;
        switch (ddlGenContextPtr->m_rdbmsEn)
        {
            case Sybase:
                rdbmsNameStr = "sybase";
                break;

            case Oracle:
                rdbmsNameStr = "oracle";
                break;

            case Nuodb:
                rdbmsNameStr = "nuodb";
                break;

            case MSSql:
                rdbmsNameStr = "mssql";
                break;

            case PostgreSQL:
                rdbmsNameStr = "postgresql";
                break;
        }

        for (auto it = keywordParamList.begin() + 1; it != keywordParamList.end(); ++it)
        {
            if (strcasecmp((*it)[0].c_str(), rdbmsNameStr.c_str()) == 0)
            {
                bTreat = true;
            }
        }

        if (bTreat)
        {
            switch (ddlGenContextPtr->m_rdbmsEn)
            {
                case Sybase:
                    break;

                case Oracle:
                    toReplace = "/*+ " + keywordParamList[0][0] + " */";
                    break;

                case Nuodb:
                    break;

                case MSSql:
                    break;

                case PostgreSQL:
                    break;
            }
        }
    }
    return toReplace;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::manageStrReplace()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-46681 - LJE - 230301
**
*************************************************************************/
string DdlGenDbi::manageStrReplace(DdlGenContext* ddlGenContextPtr, DdlGenVarHelper*, std::vector<std::vector<std::string>>& keywordParamList)
{
    if (keywordParamList.size() != 3)
    {
        ddlGenContextPtr->printMsg(RET_GEN_ERR_INVARG, "#STR_REPLACE keyword must have 3 parameters");
    }
    stringstream outputStream;
    outputStream << DdlGenDbi::getCmdStrReplace(ddlGenContextPtr->m_rdbmsEn) << "(";

    switch (ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        {
            int paramNbr = 0;
            for (auto it = keywordParamList.begin(); it != keywordParamList.end(); ++it, ++paramNbr)
            {
                if (paramNbr != 0)
                {
                    outputStream << ", ";
                }
                if (paramNbr == 2)
                {
                    outputStream << "(case " << (*it)[0] << " when '' then null else " << (*it)[0] << " end)";
                }
                else
                {
                    outputStream << (*it)[0];
                }
            }
            break;
        }

        default:
            for (auto it = keywordParamList.begin(); it != keywordParamList.end(); ++it)
            {
                if (it != keywordParamList.begin())
                {
                    outputStream << ", ";
                }
                outputStream << (*it)[0];
            }
            break;
    }
    outputStream << ")";

    return outputStream.str();
}

/************************************************************************
**
**  Function    :   DdlGenDbi::manageAppendingReplace()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-46681 - LJE - 230301
**
*************************************************************************/
string DdlGenDbi::manageAppendingReplace(DdlGenContext* ddlGenContextPtr, DdlGenVarHelper*, std::vector<std::vector<std::string>>& keywordParamList)
{
    stringstream outputStream;

    switch (ddlGenContextPtr->m_rdbmsEn)
    {
        case PostgreSQL:
            for (auto& it : keywordParamList)
            {
                outputStream 
                    << DdlGenDbi::appendCharter(ddlGenContextPtr->m_rdbmsEn) 
                    << DdlGenDbi::getCmdIsNull(ddlGenContextPtr->m_rdbmsEn) << "("
                    << it[0]
                    << ", '')";
            }
            break;

        default:
            for (auto &it : keywordParamList)
            {
                outputStream 
                    << DdlGenDbi::appendCharter(ddlGenContextPtr->m_rdbmsEn) 
                    << it[0];
            }
            break;
    }

    return outputStream.str();
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getDiscardTrigger()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getDiscardTrigger(std::string&, std::string::size_type, DdlGenContext* ddlGenContextPtr, DdlGenVarHelper* varHelperPtr, DdlGen*)
{
    string cmd;

    switch (ddlGenContextPtr->m_rdbmsEn)
    {
        case Nuodb:
        case Sybase:
        case MSSql:
        case PostgreSQL:
            cmd = "#RETURN";
            break;

        case Oracle:
        {
            DdlGenVar* discTrgVar = varHelperPtr->getNewVariable("discard_trigger_flg", FlagType);
            discTrgVar->strDefault = "0";
            cmd = "#ASSIGN @discard_trigger_flg = 1";
            break;
        }

        default:
            SYS_BreakOnDebug();
    }
    return cmd;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getReleaseTrigger()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getReleaseTrigger(std::string&, std::string::size_type, DdlGenContext* ddlGenContextPtr, DdlGenVarHelper* varHelperPtr, DdlGen* ddlGen)
{
    return ddlGen->getIndented(ddlGenContextPtr->m_releaseTriggerStream);
}

/************************************************************************
**
**  Function    :   DdlGenDbi::isRootLevel()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::isRootLevel(std::string&, std::string::size_type, DdlGenContext* ddlGenContextPtr, DdlGenVarHelper*, DdlGen*)
{
    ddlGenContextPtr->bRootEntityManagement = true;
    return "(@is_root_level_ = 1)";
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getRootEntity()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getRootEntity(std::string&, std::string::size_type, DdlGenContext* ddlGenContextPtr, DdlGenVarHelper*, DdlGen* ddlGenPtr)
{
    ddlGenContextPtr->bRootEntityManagement = true;
    return ddlGenPtr->getCmdGetAppContext("TASC_CONTEXT", "root_entity");
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdCharindex()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdCharindex()
{
    string cmd;

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case MSSql:
            cmd = "charindex";
            break;

        case Oracle:
            cmd = "instr";
            break;

        case Nuodb:
            cmd = "locate";
            break;

        case PostgreSQL:
            cmd = "position";
            break;

        default:
            SYS_BreakOnDebug();

    }
    return cmd;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getSynonymSqlName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getSynonymSqlName()
{
    string cmd;

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Oracle:
            cmd = "synonyms";
            break;

        default:
            cmd = "synonym";
            break;
    }
    return cmd;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdNullable()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdNullable(bool bNullable, bool bAlter)
{
    string cmd;

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case PostgreSQL:
            if (bAlter)
            {
                if (bNullable)
                {
                    cmd = " drop";
                }
                else
                {
                    cmd = " set";
                }
                cmd += " not null";
            }
            else
            {
                if (bNullable)
                {
                    cmd = " null";
                }
                else
                {
                    cmd = " not null";
                }
            }
            break;

        case Sybase:
        case Oracle:
        case Nuodb:
        case MSSql:
        default:
            if (bNullable)
            {
                cmd = " null";
            }
            else
            {
                cmd = " not null";
            }
            break;
    }
    return cmd;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdAddColumn()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdAddColumn(bool bFirst)
{
    string cmd;

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case Oracle:
            cmd = "add ";
            break;
        case MSSql:
            if (bFirst)
            {
                cmd = "add ";
            }
            break;
        case Nuodb:
            if (bFirst)
            {
                cmd = "add column (";
            }
            break;

        case PostgreSQL:
            cmd = "add column ";
            break;

        default:
            SYS_BreakOnDebug();
    }
    return cmd;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdEndAddColumn()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdEndAddColumn()
{
    string cmd;

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case Oracle:
        case MSSql:
        case PostgreSQL:
            break;

        case Nuodb:
            cmd = ")";
            break;

        default:
            SYS_BreakOnDebug();
    }
    return cmd;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdClustered()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdClustered(bool bClustered)
{
    string cmd;

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case MSSql:
            if (bClustered)
            {
                cmd = "clustered ";
            }
            else
            {
                cmd = "nonclustered ";
            }
            break;
        case Oracle:
        case Nuodb:
        case PostgreSQL:
            break;
    }
    return cmd;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::isClusteredIdxAllowed()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
bool DdlGenDbi::isClusteredIdxAllowed()
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case MSSql:
            return true;
            break;
    }
    return false;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::isCreateAsSelectBehavior()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
bool DdlGenDbi::isCreateAsSelectBehavior()
{
    bool isBehavior = false;
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case MSSql:
            isBehavior = false;
            break;

        case Oracle:
        case Nuodb:
        case PostgreSQL:
            isBehavior = true;
            break;
    }
    return isBehavior;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::isReplaceAllowed()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
bool DdlGenDbi::isReplaceAllowed(DDL_OBJ_ENUM ddlObjType)
{
    bool isBehavior = false;
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case MSSql:
            break;

        case Oracle:
            switch (ddlObjType)
            {
                case DdlObj_SProc:
                case DdlObj_SpecSProc:
                case DdlObj_Trigger:
                case DdlObj_View:
                case DdlObj_Func:
                    isBehavior = true;
                    break;
            }
            break;

        case Nuodb:
            switch (ddlObjType)
            {
                case DdlObj_SProc:
                case DdlObj_SpecSProc:
                case DdlObj_Trigger:
                case DdlObj_View:
                    /* case DdlObj_Func: - NuoDB allow several function having different parameters */
                    isBehavior = true;
                    break;
            }
            break;

        case PostgreSQL:
            switch (ddlObjType)
            {
                //case DdlObj_SProc:
                // case DdlObj_View:

                case DdlObj_Func:
                case DdlObj_SpecSProc:
                    isBehavior = true;
                    break;
            }
            break;

    }
    return isBehavior;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::isReplaceAllowed()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
bool DdlGenDbi::isFunctionEqProc()
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case PostgreSQL:
            return true;

        case Sybase:
        case MSSql:
        case Oracle:
        case Nuodb:
        default:
            return false;

    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::isAddIdentityAllowed()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
bool DdlGenDbi::isAddIdentityAllowed()
{
    bool isBehavior = false;
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case MSSql:
            isBehavior = true;
            break;

        case Oracle:
        case Nuodb:
        default:
            isBehavior = false;
            break;
    }
    return isBehavior;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::isModifyIdentityAllowed()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
bool DdlGenDbi::isModifyIdentityAllowed()
{
    bool isBehavior = false;
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Oracle:
            isBehavior = true;
            break;

        case Sybase:
        case Nuodb:
        case MSSql:
        default:
            isBehavior = false;
            break;
    }
    return isBehavior;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::isCascadeNullOnString()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
bool DdlGenDbi::prepareDataMigration(DICT_ENTITY_STP sourceDictEntityStp, DICT_ENTITY_STP targetDictEntityStp)
{
    vector<string> cmdVector;

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Oracle:
            if (this->ddlGenContextPtr->ddlGenAction.m_bOraNologgingHint)
            {
                stringstream cmdStream;
                cmdStream << "alter table " << this->getDdlObjFullSqlName() << " nologging";
                cmdVector.push_back(cmdStream.str());

                this->printMsg(RET_DBA_INFO_EXIST, SYS_Stringer("Alter table ", this->getDdlObjFullSqlName() , " to no logging"));
                break;
            }

        case PostgreSQL:
            if (this->ddlGenContextPtr->ddlGenAction.m_bOraNologgingHint)
            {
                stringstream cmdStream;
                cmdStream << "alter table " << this->getDdlObjFullSqlName() << " SET UNLOGGED";
                cmdVector.push_back(cmdStream.str());

                this->printMsg(RET_DBA_INFO_EXIST, SYS_Stringer("Alter table ", this->getDdlObjFullSqlName(), " to unlogged"));
                break;
            }

        case Sybase:
        case Nuodb:
        case MSSql:
        default:
            break;
    }

    if (cmdVector.empty() == false)
    {
        DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);
        DbiConnection& dbiConn = ddlGenConnGuard.getDbiConnForDdl();
        for (auto &it : cmdVector)
        {
            RequestHelper  requestHelper(&dbiConn);
            requestHelper.setCommand(it);

            if (requestHelper.sendAndGetCommand() != RET_SUCCEED)
            {
                return false;
            }
        }
    }

    this->disableIdentity(sourceDictEntityStp, targetDictEntityStp);

    return true;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::releaseDataMigration()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
bool DdlGenDbi::releaseDataMigration(DICT_ENTITY_STP sourceDictEntityStp, DICT_ENTITY_STP targetDictEntityStp)
{
    vector<string> cmdVector;

    this->enableIdentity(sourceDictEntityStp, targetDictEntityStp);

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Oracle:
            if (this->ddlGenContextPtr->ddlGenAction.m_bOraNologgingHint)
            {
                stringstream cmdStream;
                cmdStream << "alter table " << this->getDdlObjFullSqlName() << " logging";
                cmdVector.push_back(cmdStream.str());

                this->printMsg(RET_DBA_INFO_EXIST, SYS_Stringer("Alter table ", this->getDdlObjFullSqlName(), " to logging"));
                break;
            }

        case PostgreSQL:
            if (this->ddlGenContextPtr->ddlGenAction.m_bOraNologgingHint)
            {
                stringstream cmdStream;
                cmdStream << "alter table " << this->getDdlObjFullSqlName() << " SET LOGGED";
                cmdVector.push_back(cmdStream.str());

                this->printMsg(RET_DBA_INFO_EXIST, SYS_Stringer("Alter table ", this->getDdlObjFullSqlName(), " to logged"));
                break;
            }

        case Sybase:
            cmdVector.push_back(this->getCmdCheckpoint());
            break;

        case Nuodb:
        case MSSql:
        default:
            break;
    }

    if (cmdVector.empty() == false)
    {
        DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);
        DbiConnection& dbiConn = ddlGenConnGuard.getDbiConnForDdl();
        for (auto &it : cmdVector)
        {
            RequestHelper  requestHelper(&dbiConn);
            requestHelper.setCommand(it);

            if (requestHelper.sendAndGetCommand() != RET_SUCCEED)
            {
                return false;
            }
        }
    }

    return true;

}

/************************************************************************
**
**  Function    :   DdlGenDbi::isCascadeNullOnString()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
bool DdlGenDbi::isCascadeNullOnString(DBA_RDBMS_ENUM rdbmsEn)
{
    switch (rdbmsEn)
    {
        case Nuodb:
        case MSSql:
            return true;
            break;

        case Sybase:
        case Oracle:
        default:
            return false;
            break;
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getParamPrefix()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getParamPrefix(DBA_RDBMS_ENUM rdbmsEn)
{
    string cmd;

    switch (rdbmsEn)
    {
        case Sybase:
        case MSSql:
            cmd = "@";
            break;

        case Oracle:
        case Nuodb:
        case PostgreSQL:
            cmd = "p_";
            break;
    }
    return cmd;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getParamPrefix()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getParamPrefix()
{
    return this->getParamPrefix(this->ddlGenContextPtr->m_rdbmsEn);
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getParamAssign()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getParamAssign(const std::string& paramSqlName)
{
    string cmd;

    if (paramSqlName.empty() == false)
    {
        switch (this->ddlGenContextPtr->m_rdbmsEn)
        {
            case Sybase:
            case MSSql:
                if (paramSqlName[0] != '@')
                {
                    cmd = DdlGenDbi::getParamPrefix();
                }
                cmd += paramSqlName + " = ";
                break;

            case Oracle:
                cmd = DdlGenDbi::getParamPrefix() + paramSqlName + " => ";
                break;

            case Nuodb:
                break;
        }
    }
    return cmd;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getVarPrefix()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getVarPrefix(DBA_RDBMS_ENUM rdbmsEn)
{
    string cmd;

    switch (rdbmsEn)
    {
        case Sybase:
        case MSSql:
            cmd = '@';
            break;
        case Oracle:
        case Nuodb:
        case PostgreSQL:
            cmd = "v_";
            break;
    }
    return cmd;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getVarPrefix()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getVarPrefix()
{
    return this->getVarPrefix(this->ddlGenContextPtr->m_rdbmsEn);
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getTempTablePrefix()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getTempTablePrefix(DBA_RDBMS_ENUM rdbmsEn, DICT_ENTITY_STP dictEntityStp, bool forTableName)
{
    string cmd;

    switch (rdbmsEn)
    {
        case Sybase:
            cmd = "#";
            break;

        case MSSql:
            /* PMSTA-58084 - LJE - 240729 */
            if (DdlGenDbi::getTempTableSpec(rdbmsEn, dictEntityStp) == DdlGenDbi::TempTableSpec::MemoryOptimzed)
            {
                cmd = "tt_";
            }
            else if (DdlGenDbi::getTempTableSpec(rdbmsEn, dictEntityStp) == DdlGenDbi::TempTableSpec::Type)
            {
                if (forTableName)
                {
                    cmd = "t_";
                }
                else
                {
                    cmd = "@";
                }
            }
            else if (dictEntityStp == nullptr)
            {
                cmd = "tt_";
            }
            else
            {
                cmd = "#";
            }
            break;

        case Oracle:
        case Nuodb:
            cmd = "tt_";
            break;
    }
    return cmd;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getTempTablePrefix()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getTempTablePrefix(DBA_RDBMS_ENUM rdbmsEn, DBA_DYNFLD_STP xdEntityStp)
{
    string cmd;

    switch (rdbmsEn)
    {
        case MSSql:
            /* PMSTA-58084 - LJE - 240729 */
            if (GET_ENUM(xdEntityStp, A_XdEntity_DbRuleEn) == DbRule_VolatileTable)
            {
                cmd = "#";
            }
            else if (GET_ENUM(xdEntityStp, A_XdEntity_DbRuleEn) == DbRule_TypeTable)
            {
                cmd = "t_";
            }
            else
            {
                cmd = "tt_";
            }
            break;

        default:
            cmd = getTempTablePrefix(rdbmsEn);
            break;
    }
    return cmd;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getEmptyFrom()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getEmptyFrom(DBA_RDBMS_ENUM rdbmsEn)
{
    string cmd;

    switch (rdbmsEn)
    {
        case Sybase:
        case MSSql:
        case PostgreSQL:
        case QtHttp:
            break;

        case Oracle:
        case Nuodb:
            cmd = " from dual";
            break;
    }
    return cmd;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getEmptyFrom()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getEmptyFrom()
{
    return this->getEmptyFrom(this->ddlGenContextPtr->m_rdbmsEn);
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getReturnStatusName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getReturnStatusName(bool bPrintSqlName)
{
    DdlGenVar* returnStatusVar = this->varHelperPtr->getNewVariable("return_status", "int_t");

    if (bPrintSqlName)
    {
        return returnStatusVar->printSqlName();
    }
    else
    {
        return "@" + returnStatusVar->sqlName;
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getReturnStatus()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getReturnReturnStatus()
{
    stringstream stream;

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case MSSql:
            stream << this->newLine() << "if ( " + this->getReturnStatusName() + " != 0 )";
            this->setIndent(1);
            stream << this->newLine() << "return 0";
            this->setIndent(-1);
            stream << this->newLine() << "else";
            this->setIndent(1);
            stream << this->newLine() << "return 1";
            this->setIndent(-1);
            break;

        case PostgreSQL:
        case Oracle:
        case QtHttp:
            break;
    }
    return stream.str();
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getReturnStatusOnError()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getReturnStatusOnError()
{
    stringstream stream;

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case MSSql:
            stream << this->getIndent() << "if " + this->getReturnStatusName() + " = -1";
            this->setIndent(1);
            stream << this->newLine() << "return -1";
            this->setIndent(-1);
            break;

        case Oracle:
        case PostgreSQL:
            break;
    }
    return stream.str();
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getIdentityValue()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getIdentityValue()
{
    string cmd;

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
            cmd = "@@identity";
            break;
        case Oracle:
            cmd = this->getMainDbCall() + "triplea_pkg.get_identity";
            break;
        case Nuodb:
            cmd = "LAST_INSERT_ID()";
            break;
        case MSSql:
            cmd = "SCOPE_IDENTITY()";
            break;
        default:
            SYS_BreakOnDebug();
    }
    return cmd;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdReturnIdentityValue()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
void DdlGenDbi::getCmdReturnIdentityValue(DICT_ATTRIB_STP idAttribParamStp, DdlGenVar *variable, string& inInsertStr, string& afterInsertStr)
{
    stringstream outStream;

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case Nuodb:
        case MSSql:
            if (variable != nullptr)
            {
                afterInsertStr = this->getCmdAssignByValue(*variable, this->getIdentityValue());
            }
            break;

        case Oracle:
            outStream << " returning " << idAttribParamStp->sqlName;

            if (variable != nullptr)
            {
                outStream << " into " << variable->printSqlName();
            }
            inInsertStr = outStream.str();
            break;

        case PostgreSQL:
            outStream << " returning " << idAttribParamStp->sqlName;

            if (variable != nullptr)
            {
                outStream << " into " << variable->printSqlName();
            }
            inInsertStr = outStream.str();
            break;

        case Sqlite:
        case QtHttp:
            break;

        default:
            SYS_BreakOnDebug();
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdEndOfCmd()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdEndOfCmd(bool bForceEnd)
{
    string newLine;
    if (this->getDdlObjEn() != DdlObj_RuntimeSql)
    {
        newLine = "\n";
    }

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case QtHttp:
            break;

        case Oracle:
        case Nuodb:
        case MSSql:
        case PostgreSQL:
        case Sqlite:

            if (bForceEnd || this->bNestedRequest == false)
            {
                return (";" + newLine);
            }
            break;

        default:
            SYS_BreakOnDebug();
    }
    return (newLine);
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdFrom()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdFrom()
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case MSSql:
        case Oracle:
        case Sqlite:
        case QtHttp:
        default:
            return ("from ");

        case PostgreSQL:
            return ("FROM ");
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdInnerJoin()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdInnerJoin()
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case MSSql:
        case Oracle:
        case Sqlite:
        case QtHttp:
        default:
            return ("inner join ");

        case PostgreSQL:
            return ("JOIN ");
    }
}


/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdLeftJoin()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdLeftJoin()
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case MSSql:
        case Oracle:
        case Sqlite:
        case QtHttp:
        default:
            return ("left outer join ");

        case PostgreSQL:
            return ("LEFT JOIN ");
    }
}


/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdRightJoin()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdRightJoin()
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case MSSql:
        case Oracle:
        case Sqlite:
        case QtHttp:
        default:
            return ("right outer join ");

        case PostgreSQL:
            return ("RIGHT JOIN ");
    }
}


/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdJoinOn()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdJoinOn()
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case MSSql:
        case Oracle:
        case Sqlite:
        default:
            return ("on ");

        case PostgreSQL:
            return ("ON ");
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdEndSProc()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdEndSProc()
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case MSSql:
            return ("end");

        case Oracle:
            return ("end;");

        case Nuodb:
            return ("end_procedure;");

        case PostgreSQL:
            return ("end $function$");

        default:
            SYS_BreakOnDebug();
    }
    return (string());
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdEndFunc()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdEndFunc()
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
            return ("end");

        case Oracle:
            return ("end;");

        case Nuodb:
            return ("end_function;");

        case MSSql:
            return ("end;");

        case PostgreSQL:
            return ("end $function$");

        default:
            SYS_BreakOnDebug();
    }
    return (string());
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdEndTrigger()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdEndTrigger()
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case MSSql:
            return ("end");

        case Oracle:
            return ("end;");
    
        case Nuodb:
            return ("end_trigger;");

        case PostgreSQL:
            break;

        default:
            SYS_BreakOnDebug();
    }
    return (string());
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getNewAlias()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**  Modif       :   FIH-PMSTA-PMSTA-47965-221017    Add QtHttp to avoid assert
**
*************************************************************************/
string DdlGenDbi::getNewAlias() const
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case QtHttp:
        case Sybase:
        case MSSql:
            return ("");

        case Oracle:
            return (":NEW");

        case Nuodb:
        case Sqlite:
        case PostgreSQL:
            return ("NEW");

        default:
            SYS_BreakOnDebug();

    }

    return (string());
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getOldAlias()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**  Modif       :   FIH-PMSTA-PMSTA-47965-221017    Add QtHttp to avoid assert
**
*************************************************************************/
string DdlGenDbi::getOldAlias() const
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case QtHttp:
        case Sybase:
        case MSSql:
            return ("");

        case Oracle:
            return (":OLD");

        case Nuodb:
        case Sqlite:
        case PostgreSQL:
            return ("OLD");

        default:
            SYS_BreakOnDebug();
    }

    return (string());
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getNewPrefix()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**  Modif       :   FIH-PMSTA-PMSTA-47965-221017    Add QtHttp to avoid assert
**
*************************************************************************/
string DdlGenDbi::getNewPrefix() const
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case QtHttp:
        case Sybase:
        case MSSql:
            return ("@i_");

        case Oracle:
            return (this->getNewAlias() + ".");

        case Nuodb:
        case Sqlite:
        case PostgreSQL:
            return (this->getNewAlias() + ".");

        default:
            SYS_BreakOnDebug();

    }

    return (string());
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getOldPrefix()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**  Modif       :   FIH-PMSTA-PMSTA-47965-221017    Add QtHttp to avoid assert
**
*************************************************************************/
string DdlGenDbi::getOldPrefix() const
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case QtHttp:
        case Sybase:
        case MSSql:
            return ("@d_");

        case Oracle:
            return (this->getOldAlias() + ".");

        case Nuodb:
        case Sqlite:
        case PostgreSQL:
            return (this->getOldAlias() + ".");

        default:
            SYS_BreakOnDebug();

    }

    return (string());
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdEndDDLObj()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdEndDDLObj()
{
    if (this->ddlGenContextPtr->bSimulation ||
        this->ddlGenContextPtr->m_rdbmsEn == PostgreSQL)
    {
        return this->getCmdEndOfCmd(true);
    }
    else
    {
        return "\n";
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::appendCharter()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::appendCharter(DBA_RDBMS_ENUM rdbmsEn)
{
    switch (rdbmsEn)
    {
        case Sybase:
        case MSSql:
            return (string("+"));

        case Oracle:
        case Nuodb:
        case PostgreSQL:
        case Sqlite:
        default:
            return (string("||"));
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::appendCharter()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::appendCharter()
{
    return DdlGenDbi::appendCharter(this->ddlGenContextPtr->m_rdbmsEn);
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdDbAccess()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdDbAccess(DBA_RDBMS_ENUM rdbmsEn)
{
    switch (rdbmsEn)
    {
        case Sybase:
            return (string(".."));

        case Oracle:
        case Nuodb:
        case MSSql:
        case PostgreSQL:
            return (string("."));
    }
    return (string());
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdDbAccess()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdDbAccess()
{
    return DdlGenDbi::getCmdDbAccess(this->ddlGenContextPtr->m_rdbmsEn);
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getDbo()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getDbo()
{
    string cmd = this->ddlGenContextPtr->getMainDbName() + ".";

    this->standardize(cmd);

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
            cmd.append("dbo.");
            break;

        case Oracle:
        case Nuodb:
        case MSSql:
        case Sqlite:
            break;

        case PostgreSQL:
            if (this->isProcedureBehavior() == false &&
                this->ddlGenContextPtr->getMainDbName() == this->ddlGenContextPtr->getDdlDestDbName())
            {
                cmd.clear();
            }
            break;
    }
    return (cmd);
}

/************************************************************************
**
**  Function    :   DdlGenDbi::length()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::length()
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case Nuodb:
        case PostgreSQL:
            return (string("char_length"));

        case Sqlite:
        case Oracle:
        case QtHttp:
            return (string("length"));

        case MSSql:
            return (string("len"));

        default:
            SYS_BreakOnDebug();

    }
    return (string());
}

/************************************************************************
**
**  Function    :   DdlGenDbi::substring()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::substring()
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case Nuodb:
        case MSSql:
        case PostgreSQL:
        case Sqlite:
        case QtHttp:
            return (string("substring"));

        case Oracle:
            return (string("substr"));

        default:
            SYS_BreakOnDebug();
    }
    return (string());
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdAppContext()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdAppContext(const std::string& cmdTypeStr)
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case Oracle:
        case Nuodb:
            return (string(cmdTypeStr + "_appcontext"));

        case PostgreSQL:
        case MSSql:
            return (string(this->getDbo() + cmdTypeStr + "_appcontext"));

        case Sqlite:
        case QtHttp:
            break;

        default:
            SYS_BreakOnDebug();
    }
    return (string());
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdStrReplace()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdStrReplace(DBA_RDBMS_ENUM rdbmsEn)
{
    switch (rdbmsEn)
    {
        case Sybase:
            return ("str_replace");

        case Oracle:
        case Nuodb:
        case MSSql:
        case PostgreSQL:
        case Sqlite:
        case QtHttp:
            return ("replace");

        default:
            SYS_BreakOnDebug();
    }
    return (string());
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdStrReplace()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdStrReplace()
{
    return DdlGenDbi::getCmdStrReplace(this->ddlGenContextPtr->m_rdbmsEn);
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getRdbmsShortName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getRdbmsShortName(DBA_RDBMS_ENUM rdbmsEn)
{
    switch (rdbmsEn)
    {
        case Sybase:
            return ("syb");

        case Oracle:
            return ("ora");

        case Nuodb:
            return ("nuo");

        case MSSql:
            return ("mss");

        case Sqlite:
            return ("sli");

        case PostgreSQL:
            return ("pgs");

        default:
            SYS_BreakOnDebug();

    }
    return (string());
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getRdbmsShortName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getRdbmsShortName()
{
    return DdlGenDbi::getRdbmsShortName(this->ddlGenContextPtr->m_rdbmsEn);
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getRdbmsName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getRdbmsName()
{
    return DdlGenDbi::getRdbmsName(this->ddlGenContextPtr->m_rdbmsEn);
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getRdbmsName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getRdbmsName(DBA_RDBMS_ENUM rdbmsEn)
{
    switch (rdbmsEn)
    {
        case Sybase:
            return ("Sybase");

        case Oracle:
            return ("Oracle");

        case Nuodb:
            return ("NuoDB");

        case MSSql:
            return ("MSSql");

        case Sqlite:
            return ("Sqlite");

        case PostgreSQL:
            return ("PostgreSQL");

        default:
            SYS_BreakOnDebug();
    }
    return (string());
}

/************************************************************************
**
**  Function    :   DdlGenDbi::endOfCmd()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::endOfCmd()
{
    return  DdlGenDbi::endOfCmd(this->ddlGenContextPtr->m_rdbmsEn);
}

/************************************************************************
**
**  Function    :   DdlGenDbi::endOfCmd()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::endOfCmd(DBA_RDBMS_ENUM rdbmsEn)
{
    switch (rdbmsEn)
    {
        case Sybase:
        case QtHttp:
            break;

        case Oracle:
        case Nuodb:
        case MSSql:
        case Sqlite:
        case PostgreSQL:
            return (";");

        default:
            SYS_BreakOnDebug();
    }
    return ("");
}

/************************************************************************
**
**  Function    :   DdlGenDbi::beginOfBlock()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::beginOfBlock(DBA_RDBMS_ENUM rdbmsEn)
{
    switch (rdbmsEn)
    {
        case Sybase:
        case Oracle:
        case Nuodb:
        case MSSql:
        case Sqlite:
        case QtHttp:
            break;

        case PostgreSQL:
            return ("\ndo $$\nbegin\n");

        default:
            SYS_BreakOnDebug();
    }
    return ("");
}

/************************************************************************
**
**  Function    :   DdlGenDbi::endOfBlock()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::endOfBlock(DBA_RDBMS_ENUM rdbmsEn)
{
    switch (rdbmsEn)
    {
        case Sybase:
        case Oracle:
        case Nuodb:
        case MSSql:
        case Sqlite:
        case QtHttp:
            break;

        case PostgreSQL:
            return ("\nend $$;\n");
    }
    return ("");
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdGo()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdGo(DBA_RDBMS_ENUM rdbmsEn)
{
    string cmd;

    switch (rdbmsEn)
    {
        case Sybase:
        case Nuodb:
        case MSSql:
        case Sqlite:
            cmd = "\ngo\n";
            break;

        case Oracle:
        case PostgreSQL:
        case QtHttp:
            cmd = "\n";
            break;

        default:
            SYS_BreakOnDebug();
    }
    return cmd;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdGo()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdGo()
{
    return this->getCmdGo(this->ddlGenContextPtr->m_rdbmsEn);
}

/************************************************************************
**
**  Function    :   DdlGenDbi::printGrantTable()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
void DdlGenDbi::printGrantTable(stringstream& outStream, DICT_ENTITY_STP dictEntityStp)
{
    DBA_ENTITY_NAT_ENUM  entNatEn(dictEntityStp->entNatEn);
    ENTITY_SECURITY_LEVEL_ENUM securityLevelEn(dictEntityStp->securityLevelEn);

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case MSSql:
            if (entNatEn == EntityNat_Tsl ||
                entNatEn == EntityNat_SearchFmt ||
                entNatEn == EntityNat_Internal ||
                this->targetTableEn == TargetTable_Precomp)
            {
                outStream << "grant all on " << this->m_ddlObjFullSqlName
                    << " to tasc_tech" << this->getCmdEndDDLObj();
            }
            else if (entNatEn == EntityNat_ReportFmt ||
                     /* PMSTA-58084 - LJE - 240729 */
                     DdlGenDbi::getTempTableSpec(this->ddlGenContextPtr->m_rdbmsEn, dictEntityStp) == DdlGenDbi::TempTableSpec::MemoryOptimzed)
            {
                outStream << "grant select, insert, update, delete on " << this->m_ddlObjFullSqlName
                    << " to triplea, tasc_tech" << this->getCmdEndDDLObj();
            }

            if (securityLevelEn == EntSecuLevel_InsertAllowed)
            {
                outStream << "grant insert on " << this->m_ddlObjFullSqlName
                    << " to triplea, tasc_tech" << this->getCmdEndDDLObj();
            }

            if (securityLevelEn == EntSecuLevel_InsertDeleteAllowed)
            {
                outStream << "grant insert, delete on " << this->m_ddlObjFullSqlName
                    << " to triplea, tasc_tech" << this->getCmdEndDDLObj();
            }

            if (this->ddlGenContextPtr->getDdlDestUser().empty() == false)
            {
                outStream << "grant all on " << this->m_ddlObjFullSqlName
                    << " to dbo" << this->getCmdEndDDLObj();
            }

            break;

        case Oracle:
            this->printGrantToAllSchema(outStream, this->m_dbSqlName, "grant all on " + this->m_ddlObjFullSqlName, "with grant option");

            if (entNatEn == EntityNat_Tsl ||
                entNatEn == EntityNat_SearchFmt ||
                entNatEn == EntityNat_Internal ||
                this->targetTableEn == TargetTable_Precomp)
            {
                outStream << "grant all on " << this->m_ddlObjFullSqlName
                    << " to tasc_tech" << this->getCmdEndDDLObj();
            }
            else if (entNatEn == EntityNat_ReportFmt)
            {
                outStream << "grant select, insert, update, delete on " << this->m_ddlObjFullSqlName
                    << " to triplea, tasc_tech" << this->getCmdEndDDLObj();
            }
            else if (entNatEn == EntityNat_TempTable)
            {
                outStream << "grant all on " << this->m_ddlObjFullSqlName << " to triplea, tasc_tech";
            }

            if (securityLevelEn == EntSecuLevel_InsertAllowed)
            {
                outStream << "grant insert on " << this->m_ddlObjFullSqlName
                    << " to triplea, tasc_tech" << this->getCmdEndDDLObj();
            }

            if (securityLevelEn == EntSecuLevel_InsertDeleteAllowed)
            {
                outStream << "grant insert, delete on " << this->m_ddlObjFullSqlName
                    << " to triplea, tasc_tech" << this->getCmdEndDDLObj();
            }

            break;

        case Nuodb:
            if (entNatEn == EntityNat_Tsl ||
                entNatEn == EntityNat_SearchFmt ||
                entNatEn == EntityNat_Internal ||
                this->targetTableEn == TargetTable_Precomp)
            {
                outStream << "grant all on " << this->m_ddlObjFullSqlName
                    << " to " << this->getCmdRole("tasc_tech") << this->getCmdEndDDLObj();

                if (dictEntityStp->pkRuleEn == PkRule_Identity &&
                    this->targetTableEn != TargetTable_Precomp)
                {
                    string sequenceName = this->getIdentitySequencName(dictEntityStp, this->m_dbDdlObjSqlName);

                    outStream << "grant all on sequence " << sequenceName
                        << " to " << this->getCmdRole("tasc_tech") << this->getCmdEndDDLObj();
                }
            }
            else if (entNatEn == EntityNat_ReportFmt)
            {
                outStream << "grant select, insert, update, delete on " << this->m_ddlObjFullSqlName
                    << " to " << this->getCmdRole("triplea") << ", " << this->getCmdRole("tasc_tech") << this->getCmdEndDDLObj();
            }

            if (securityLevelEn == EntSecuLevel_InsertAllowed)
            {
                outStream << "grant insert on " << this->m_ddlObjFullSqlName
                    << " to " << this->getCmdRole("triplea") << ", " << this->getCmdRole("tasc_tech") << this->getCmdEndDDLObj();
            }

            if (securityLevelEn == EntSecuLevel_InsertDeleteAllowed)
            {
                outStream << "grant insert, delete on " << this->m_ddlObjFullSqlName
                    << " to " << this->getCmdRole("triplea") << ", " << this->getCmdRole("tasc_tech") << this->getCmdEndDDLObj();
            }
            break;

        case PostgreSQL:

            if (entNatEn != EntityNat_TempTable)
            {
                outStream << "revoke all on " << this->m_ddlObjFullSqlName
                    << " from public" << this->getCmdEndDDLObj();
            }

            if (entNatEn == EntityNat_Tsl ||
                entNatEn == EntityNat_SearchFmt ||
                entNatEn == EntityNat_Internal ||
                this->targetTableEn == TargetTable_Precomp)
            {
                outStream << "grant all on " << this->m_ddlObjFullSqlName
                    << " to tasc_tech" << this->getCmdEndDDLObj();
            }
            else if (entNatEn == EntityNat_ReportFmt)
            {
                outStream << "grant select, insert, update, delete on " << this->m_ddlObjFullSqlName
                    << " to triplea, tasc_tech" << this->getCmdEndDDLObj();
            }

            if (securityLevelEn == EntSecuLevel_InsertAllowed)
            {
                outStream << "grant insert on " << this->m_ddlObjFullSqlName
                    << " to triplea, tasc_tech" << this->getCmdEndDDLObj();
            }

            if (securityLevelEn == EntSecuLevel_InsertDeleteAllowed)
            {
                outStream << "grant insert, delete on " << this->m_ddlObjFullSqlName
                    << " to triplea, tasc_tech" << this->getCmdEndDDLObj();
            }

            if (this->ddlGenContextPtr->getDdlDestUser().empty() == false)
            {
                outStream << "grant all on " << this->m_ddlObjFullSqlName
                    << " to dbo" << this->getCmdEndDDLObj();
            }

            break;

    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::printEndBlockToFile()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
void DdlGenDbi::printEndBlockToFile()
{
    if (this->fileHelper != nullptr)
    {
        stringstream goStream;

        switch (this->ddlGenContextPtr->m_rdbmsEn)
        {
            case Sybase:
            case Nuodb:
            case MSSql:
            case PostgreSQL:
                goStream << DdlGenDbi::getCmdGo();
                break;

            case Oracle:
                goStream
                    << endl
                    << "/" << endl
                    << "show errors" << endl;
                break;
        }
        *this->fileHelper << goStream;

        this->fileHelper->flush();
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::printEndBlockToFile()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
void DdlGenDbi::printEndBlockToFile(DdlGenSqlBlock& outStream)
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case Nuodb:
        case MSSql:
        case PostgreSQL:
            break;

        case Oracle:
            outStream
                << endl
                << "/" << endl
                << "show errors" << endl;
            break;
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdCheckpoint()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
std::string DdlGenDbi::getCmdCheckpoint()
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
            return "checkpoint";

        case Oracle:
        case Nuodb:
        case PostgreSQL:
        case MSSql:  /* XXXXXXXXXXXx TO CHECK IF NEEDED. */
            break;
    }

    return string();
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdUseDb()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdUseDb(const string& databaseName, DBA_RDBMS_ENUM rdbmsEn)
{
    string cmd;

    switch (rdbmsEn)
    {
        case Sybase:
        case Nuodb:
            cmd = "use " + databaseName;
            break;

        case Oracle:
            cmd = "ALTER SESSION SET CURRENT_SCHEMA = " + upper(databaseName);
            break;

        case MSSql:
            if (databaseName.compare("master") == 0 ||
                databaseName.compare("model") == 0 ||
                databaseName.compare("tempdb") == 0)
            {
                cmd = "use " + databaseName;
            }
            break;

        case PostgreSQL:
            cmd = "SET search_path TO " + databaseName + ";";
            break;

        case Sqlite:
            break;

        case QtHttp:
            break;

        default:
            SYS_BreakOnDebug();

    }
    return cmd;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdPrintMsg()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdPrintMsg(const string& msg, bool bOnProcedure, DdlGenContext* ddlGenContextPtr)
{
    string cmd;

    switch (ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case MSSql:
            cmd = "print '" + msg + "'";
            break;

        case Oracle:
            if (bOnProcedure)
            {
                cmd = "DBMS_OUTPUT.put_line('" + msg + "');";
            }
            else
            {
                cmd = "PROMPT " + msg;
            }
            break;

        case Nuodb:
            if (bOnProcedure)
            {
                ddlGenContextPtr->m_bOutputMessage = true;
                cmd = "insert into output_message ";
            }
            cmd += "select '" + msg + "' as prompt_message from dual;";
            break;

        case PostgreSQL:
            cmd = "raise notice '" + msg + "';";
            break;
    }
    return cmd;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdPrintMsg()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdPrintMsg(const string& msg, bool bOnProcedure)
{
    return DdlGenDbi::getCmdPrintMsg(msg, bOnProcedure, this->ddlGenContextPtr);
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdPrintMsg()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdPrintMsg(vector<string>& printList)
{
    stringstream outStream;

    if (printList.size() == 0)
    {
        return outStream.str();
    }

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
            for (vector<string>::iterator it = printList.begin(); it != printList.end(); it++)
            {
                if (it == printList.begin())
                {
                    outStream << "print ";
                    outStream << *it;
                }
                else
                {
                    outStream << ", " << *it;
                }
            }
            break;

        case Oracle:
        {
            int cpt = 0;
            outStream << "DBMS_OUTPUT.put_line(";

            for (vector<string>::iterator it = printList.begin() + 1; it != printList.end(); it++)
            {
                outStream << "REPLACE(";
            }
            outStream << printList.at(0);
            for (vector<string>::iterator it = printList.begin() + 1; it != printList.end(); it++)
            {
                cpt++;
                outStream << ", '%" << cpt << "!', " << *it << ")";
            }

            outStream << ");";
        }
        break;

        case Nuodb:
        {
            int cpt = 0;
            this->ddlGenContextPtr->m_bOutputMessage = true;

            outStream << "insert into output_message ";
            outStream << "select ";

            if (printList.at(0).find("%1!") == string::npos)
            {
                outStream << "cast(";
                for (auto it = printList.begin(); it != printList.end(); ++it)
                {
                    outStream << *it;
                }
                if (nullptr == SYS_GetEnv("AAADDLNUOPRINTSTRING"))
                {   /* clob */
                    outStream << " as text)";
                }
                else
                {   /* can be made a string for debugging outside aaasql */
                    outStream << " as character(16000))";
                }
            }
            else
            {
                for (vector<string>::iterator it = printList.begin() + 1; it != printList.end(); it++)
                {
                    outStream << "replace(";
                }
                outStream << printList.at(0);
                for (vector<string>::iterator it = printList.begin() + 1; it != printList.end(); it++)
                {
                    cpt++;
                    outStream << ", '%" << cpt << "!', " << *it << ")";
                }
            }

            outStream << " as prompt_message from dual;";
        }
        break;

        case MSSql:
        {
            int cpt = 0;
            outStream << "PRINT (";

            for (vector<string>::iterator it = printList.begin() + 1; it != printList.end(); it++)
            {
                outStream << "REPLACE(";
            }
            outStream << printList.at(0);
            for (vector<string>::iterator it = printList.begin() + 1; it != printList.end(); it++)
            {
                cpt++;
                outStream << ", '%" << cpt << "!', " << DdlGenDbi::getCmdIsNull() << "(" << convert(String1000Type, *it) << ", 'null'))";
            }

            outStream << ");";
        }
        break;

        case PostgreSQL:
        {
            for (vector<string>::iterator it = printList.begin(); it != printList.end(); it++)
            {
                if (it == printList.begin())
                {
                    outStream << "raise notice ";
                    string message(*it);

                    if (printList.size() == 1 && (*it)[0] == '@')
                    {
                        outStream << "'%', ";
                    }
                    else
                    {
                        int paramNbr = 1;
                        string paramStr("%1!");
                        size_t pos = 0;
                        while ((pos = message.find(paramStr)) != string::npos)
                        {
                            message.replace(pos, 3, "%");
                            paramNbr++;
                            paramStr = SYS_Stringer("%", paramNbr, "!");
                        }
                    }

                    outStream << message;
                }
                else
                {
                    outStream << ", " << *it;
                }
            }

            outStream << ";";
        }
        break;
    }
    return outStream.str();
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getExecCmd()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getExecCmd(const string& resultVar, std::vector<std::string>& resultTableVector, DictSprocClass* dictSprocStp, bool bHasOutput)
{
    stringstream cmd;

    if (resultVar.empty() == false &&
        this->returnInSProcAvailable() == false)
    {
        DdlGenVar* statusVar = this->varHelperPtr->getNewVariable(resultVar, "int_t");
        if (statusVar->strDefault.empty())
        {
            cmd << this->getCmdAssignByValue(*statusVar, "0") << this->newLine();
        }
    }

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case MSSql:
            cmd << "execute ";
            if (resultVar.empty() == false)
            {
                cmd << this->varHelperPtr->getNewVariable(resultVar, "int_t")->printSqlName() << " = ";
            }
            break;

        case Oracle:
            break;

        case Nuodb:
        {
            stringstream returnsTable;
            if (resultTableVector.empty() == false)
            {
                for (auto it = resultTableVector.begin(); it != resultTableVector.end(); ++it)
                {
                    if (it != resultTableVector.begin())
                    {
                        returnsTable << ", ";
                    }
                    returnsTable << (*it);
                }
                returnsTable << " = ";
            }

            cmd << returnsTable.str() << "call ";
            break;
        }

        case PostgreSQL:
            if (dictSprocStp != nullptr &&
                dictSprocStp->functionFlg == FALSE &&
                bHasOutput == false &&
                ((this->m_ddlObjEn != DdlObj_Sql && 
                  dictSprocStp->m_dictSprocReturnsVector.empty()) ||
                 (this->m_ddlGenFromFileContextPtr != nullptr && 
                  this->m_ddlGenFromFileContextPtr->m_bInBlock && 
                  this->m_ddlGenFromFileContextPtr->m_singleCmd == false)))
            {
                cmd << "perform ";
            }
            else
            {
                if (this->m_ddlObjEn == DdlObj_Sql && 
                    this->m_ddlGenFromFileContextPtr != nullptr && 
                    bHasOutput == false)
                {
                    this->m_ddlGenFromFileContextPtr->m_bInBlock = false;
                }
                cmd << "select ";
            }
            break;

        default:
            SYS_BreakOnDebug();

    }

    return cmd.str();
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdCreatePhysicalProperties()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdCreatePhysicalProperties(string               physicalSegProperties, 
                                                 DBA_DYNFLD_STP       currRecordStp,
                                                 std::map<SMALLINT_T, 
                                                 DBA_DYNFLD_STP>*     currRecordCompoMapPtr, 
                                                 DdlGenEntity&        ddlGenEntity,
                                                 bool                 bInString)
{
    stringstream cmd;
    DDL_OBJ_ENUM ddlObjType = this->getDdlObjEn();
    string targetCmd;

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case MSSql:
            targetCmd = " on ";
            break;

        case Oracle:
            targetCmd = " tablespace ";
            break;
    }

    this->standardize(physicalSegProperties);

    /*
    Partition part:

    Oracle:

    PARTITION BY LIST(dlm_e)
    SUBPARTITION BY   LIST  (nature_e)
    (
    PARTITION P_LIVE values (0)      TABLESPACE aaamaindb_data_seg1,
    (
        SUBPARTITION  sp_std VALUES   ( 1 )  TABLESPACE part1,
        SUBPARTITION  sp_other VALUES   ( default )  TABLESPACE part2
    )
    PARTITION P_HIST_RW values (1,2) TABLESPACE aaamaindb_d_hst_rw1,
    PARTITION P_HIST_RO values (3)   TABLESPACE aaamaindb_d_hst_ro1
    )

    Sybase:

    partition by list (dlm_e)
    (P_LIVE    values(0)   on aaamaindb_data_seg1,
    P_HIST_RW values(1,2) on aaamaindb_d_hst_rw1,
    P_HIST_RO values(3)   on aaamaindb_d_hst_ro1
    )

    */
    if (ddlGenEntity.getDictEntityStp()->partAuthEn == FeatureAuth_Enable && 
        ddlGenEntity.getXdPartitionNbr() > 0)
    {
        stringstream                       partitionCmdStream;

        if (ddlObjType == DdlObj_Table)
        {
            int                                partitionNbr = ddlGenEntity.getXdPartitionNbr();
            DBA_DYNFLD_STP* partitionTab = ddlGenEntity.getXdPartitionTab();
            int                                i;

            map<SMALLINT_T, string>            partDefinitionMap;
            map<SMALLINT_T, ID_T>              partIdMap;
            map<SMALLINT_T, string>            partitionMap;
            map<ID_T, map<SMALLINT_T, string>> subPartitionMap;

            for (i = 0; i < partitionNbr; i++)
            {
                if (GET_ENUM(partitionTab[i], A_XdPartition_XdActionEn) != XdAction_ToInsert)
                {
                    continue;
                }

                string partitionStr;
                if (IS_NULLFLD(partitionTab[i], A_XdPartition_ParentXdPartitionId) == TRUE)
                {
                    partitionStr = "partition ";
                }
                else
                {
                    partitionStr = "subpartition ";
                }

                string partitionDefStr = partitionStr + " by ";
                string operatorStr;
                string partitionCompoStr;

                switch (this->ddlGenContextPtr->m_rdbmsEn)
                {
                    case Sybase:
                        break;

                    case Oracle:
                        partitionCompoStr = partitionStr;
                        break;
                }

                switch ((PART_TYPE_ENUM)GET_ENUM(partitionTab[i], A_XdPartition_PartTypeEn))
                {
                    case   PartType_Range:
                        partitionDefStr += "range";
                        operatorStr = " values less than ";
                        break;
                    case   PartType_List:
                        partitionDefStr += "list";
                        operatorStr = " values";
                        break;
                    case   PartType_Hash:
                        partitionDefStr += "hash";
                        operatorStr = " ";
                        break;
                    case   PartType_Interval:
                        partitionDefStr += "interval";
                        operatorStr = " ";
                        break;
                    case   PartType_Reference:
                        partitionDefStr += "reference";
                        operatorStr = " ";
                        break;
                    case   PartType_Virtual_Column:
                        partitionDefStr += "virtual column";
                        operatorStr = " ";
                        break;
                }

                partitionDefStr += " (";

                DBA_DYNFLD_STP attribStp = ddlGenEntity.getXdAttribById(GET_ID(partitionTab[i], A_XdPartition_XdAttrib1Id));

                if (attribStp)
                {
                    partitionDefStr += GET_SYSNAME(attribStp, A_XdAttrib_SqlName);
                }

                partitionDefStr += ")";

                partitionCompoStr += GET_SYSNAME(partitionTab[i], A_XdPartition_SqlName);
                partitionCompoStr += operatorStr + "(" + GET_STRING(partitionTab[i], A_XdPartition_Expression) + ")";
                partitionCompoStr += targetCmd + GET_SYSNAME(partitionTab[i], A_XdPartition_Segment);

                if (IS_NULLFLD(partitionTab[i], A_XdPartition_ParentXdPartitionId) == TRUE)
                {
                    partDefinitionMap[0] = partitionDefStr;

                    partIdMap[GET_SMALLINT(partitionTab[i], A_XdPartition_Rank)] = GET_ID(partitionTab[i], A_XdPartition_Id);
                    partitionMap[GET_SMALLINT(partitionTab[i], A_XdPartition_Rank)] = partitionCompoStr;
                }
                else
                {
                    partDefinitionMap[1] = partitionDefStr;

                    subPartitionMap[GET_ID(partitionTab[i], A_XdPartition_ParentXdPartitionId)][GET_SMALLINT(partitionTab[i], A_XdPartition_Rank)] = partitionCompoStr;
                }
            }

            partitionCmdStream << endl;
            for (auto it = partDefinitionMap.begin(); it != partDefinitionMap.end(); it++)
            {
                partitionCmdStream << it->second << endl;
            }

            partitionCmdStream << "(" << endl;
            for (auto it = partitionMap.begin(); it != partitionMap.end(); it++)
            {
                if (it != partitionMap.begin())
                {
                    partitionCmdStream << ",";
                }
                partitionCmdStream << it->second << endl;

                auto subPart = subPartitionMap.find(partIdMap.find(it->first)->second);
                if (subPart != subPartitionMap.end())
                {
                    partitionCmdStream << "(" << endl;
                    for (auto subPartIt = subPart->second.begin(); subPartIt != subPart->second.end(); subPartIt++)
                    {
                        if (subPartIt != subPart->second.begin())
                        {
                            partitionCmdStream << ",";
                        }
                        partitionCmdStream << "    " << subPartIt->second << endl;
                    }
                    partitionCmdStream << ")" << endl;
                }
            }
            partitionCmdStream << ")" << endl;

            switch (this->ddlGenContextPtr->m_rdbmsEn)
            {
                case Sybase:
                case MSSql:
                    break;

                case Oracle:
                    partitionCmdStream << "enable row movement" << endl;
                    break;
            }
        }
        else if (ddlObjType == DdlObj_Index)
        {
            /*
            local (
            partition p_live tablespace aaamaindb_data_seg1
            ,partition p_hist_rw tablespace aaamain_db_d_hst_rw_seg1
            ,partition p_hist_ro tablespace aaamain_db_d_hst_rw_seg1);

            */
            int                                partitionNbr = ddlGenEntity.getXdPartitionNbr();
            DBA_DYNFLD_STP* partitionTab = ddlGenEntity.getXdPartitionTab();
            bool                               bPartition = false;

            if (GET_FLAG(currRecordStp, A_XdIndex_UniqueFlg) == FALSE)
            {
                bPartition = true;
            }

            if (bPartition == false)
            {
                for (int i = 0; i < partitionNbr && bPartition == false; i++)
                {
                    if (GET_ENUM(partitionTab[i], A_XdPartition_XdStatusEn) != XdStatus_Inserted)
                    {
                        continue;
                    }

                    for (auto it = currRecordCompoMapPtr->begin(); it != currRecordCompoMapPtr->end() && bPartition == false; ++it)
                    {
                        if (GET_ENUM(it->second, A_XdIndexAttrib_XdActionEn) != XdAction_ToInsert)
                        {
                            continue;
                        }

                        if (GET_ID(it->second, A_XdIndexAttrib_XdAttribId) == GET_ID(partitionTab[i], A_XdPartition_XdAttrib1Id))
                        {
                            bPartition = true;
                        }
                    }
                }
            }

            if (bPartition)
            {
                map<SMALLINT_T, ID_T>              partIdMap;
                map<SMALLINT_T, string>            partitionMap;
                map<ID_T, map<SMALLINT_T, string>> subPartitionMap;

                switch (this->ddlGenContextPtr->m_rdbmsEn)
                {
                    case Sybase:
                        partitionCmdStream << "local index ";
                        break;

                    case Oracle:
                        partitionCmdStream << "local (";
                        break;
                }
                partitionCmdStream << endl;

                for (int i = 0; i < partitionNbr; i++)
                {
                    if (GET_ENUM(partitionTab[i], A_XdPartition_XdStatusEn) != XdStatus_Inserted)
                    {
                        continue;
                    }

                    string partitionStr;

                    switch (this->ddlGenContextPtr->m_rdbmsEn)
                    {
                        case Sybase:
                            break;

                        case Oracle:
                            if (IS_NULLFLD(partitionTab[i], A_XdPartition_ParentXdPartitionId) == TRUE)
                            {
                                partitionStr = "partition ";
                            }
                            else
                            {
                                partitionStr = "subpartition ";
                            }
                            break;
                    }

                    partitionStr += GET_SYSNAME(partitionTab[i], A_XdPartition_SqlName) + targetCmd;
                    if (IS_NULLFLD(partitionTab[i], A_XdPartition_IdxSegment) == FALSE &&
                        GET_SYSNAME(partitionTab[i], A_XdPartition_IdxSegment)[0] != 0)
                    {
                        partitionStr += GET_SYSNAME(partitionTab[i], A_XdPartition_IdxSegment);
                    }
                    else
                    {
                        partitionStr += GET_SYSNAME(partitionTab[i], A_XdPartition_Segment);
                    }

                    if (IS_NULLFLD(partitionTab[i], A_XdPartition_ParentXdPartitionId) == TRUE)
                    {
                        partIdMap[GET_SMALLINT(partitionTab[i], A_XdPartition_Rank)] = GET_ID(partitionTab[i], A_XdPartition_Id);
                        partitionMap[GET_SMALLINT(partitionTab[i], A_XdPartition_Rank)] = partitionStr;
                    }
                    else
                    {
                        subPartitionMap[GET_ID(partitionTab[i], A_XdPartition_ParentXdPartitionId)][GET_SMALLINT(partitionTab[i], A_XdPartition_Rank)] = partitionStr;
                    }
                }

                for (auto it = partitionMap.begin(); it != partitionMap.end(); it++)
                {
                    if (it != partitionMap.begin())
                    {
                        partitionCmdStream << ",";
                    }
                    partitionCmdStream << it->second << endl;

                    auto subPart = subPartitionMap.find(partIdMap.find(it->first)->second);
                    if (subPart != subPartitionMap.end())
                    {
                        partitionCmdStream << "(" << endl;
                        for (auto subPartIt = subPart->second.begin(); subPartIt != subPart->second.end(); subPartIt++)
                        {
                            if (subPartIt != subPart->second.begin())
                            {
                                partitionCmdStream << ",";
                            }
                            partitionCmdStream << "    " << subPartIt->second << endl;
                        }
                        partitionCmdStream << ")" << endl;
                    }
                }

                switch (this->ddlGenContextPtr->m_rdbmsEn)
                {
                    case Sybase:
                        break;

                    case Oracle:
                        partitionCmdStream << endl << ")";
                        break;
                }
            }
        }
        return partitionCmdStream.str();
    }
    else if (physicalSegProperties.empty() &&
             ddlGenEntity.getDictEntityStp()->entNatEn != EntityNat_TempTable)
    {
        stringstream  partitionCmdStream;
        switch (this->ddlGenContextPtr->m_rdbmsEn)
        {
            case Sybase:
                partitionCmdStream << " unpartition";
                break;

            case Oracle:
                break;
        }
        return partitionCmdStream.str();
    }
    else
    {
        switch (this->ddlGenContextPtr->m_rdbmsEn)
        {
            case Sybase:
                switch (ddlObjType)
                {
                    case DdlObj_Table:
                        cmd << " lock datarows" << targetCmd << "'";
                        if (bInString)
                        {
                            cmd << "'";
                        }
                        cmd << physicalSegProperties << "'";
                        if (bInString)
                        {
                            cmd << "'";
                        }
                        break;

                    case DdlObj_Index:
                        cmd << targetCmd << "'";
                        if (bInString)
                        {
                            cmd << "'";
                        }
                        cmd << physicalSegProperties << "'";
                        if (bInString)
                        {
                            cmd << "'";
                        }
                        break;

                    default:
                        /* Nothing to do */
                        break;
                }

                break;

            case Oracle:
                switch (ddlObjType)
                {
                    case DdlObj_Table:
                        cmd << targetCmd << physicalSegProperties;
                        break;

                    case DdlObj_Index:
                        cmd << targetCmd << physicalSegProperties;
                        if (GET_FLAG(currRecordStp, A_XdIndex_ReverseFlg) == TRUE)
                        {
                            cmd << " reverse";
                        }

                        if (IS_NULLFLD(currRecordStp, A_XdIndex_Initrans) == FALSE && GET_INT(currRecordStp, A_XdIndex_Initrans) > 1)
                        {
                            cmd << " initrans " << GET_INT(currRecordStp, A_XdIndex_Initrans);
                        }
                        break;

                    case DdlObj_TempTable:
                        cmd << "on commit preserve rows";
                        break;

                    default:
                        /* Nothing to do */
                        break;
                }
                break;

            case MSSql:
                switch (ddlObjType)
                {
                    case DdlObj_Table:
                    case DdlObj_Index:
                        cmd << targetCmd << "'";
                        if (bInString)
                        {
                            cmd << "'";
                        }
                        cmd << physicalSegProperties << "'";
                        if (bInString)
                        {
                            cmd << "'";
                        }
                        break;

                    default:
                        /* Nothing to do */
                        break;
                }
                break;
        }
    }

    return cmd.str();
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdInsertIntoOptim()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCmdInsertIntoOptim(const string& insertCmd, const string& selectCmd, const string& restrictCmd)
{
    stringstream insStream, bodyStream;

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
            insStream << insertCmd << endl
                << selectCmd << endl;

            if (selectCmd.empty() == false)
            {
                insStream << "where not exists (" << restrictCmd << ")" << endl;

                bodyStream << "set rowcount 100000" << endl << endl
                    << insStream.str() << endl
                    << "while @@rowcount != 0" << endl << "begin" << endl
                    << insStream.str() << endl
                    << "end" << endl
                    << "set rowcount 0" << endl;
            }
            break;

        case Oracle:
        case Nuodb:
        case MSSql:
        case PostgreSQL:
            bodyStream << insertCmd << endl
                << selectCmd << endl;
            break;

        default:
            SYS_BreakOnDebug();

    }
    return bodyStream.str();
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getDataTypeSqlName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getDataTypeSqlName(DATATYPE_ENUM dataTpProgN, bool bWithPrecision, unsigned int maxDbLenN)
{
    return DdlGenDbi::getDataTypeSqlName(dataTpProgN, this->ddlGenContextPtr->m_rdbmsEn, bWithPrecision, maxDbLenN);
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getDataTypeSqlName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getDataTypeSqlName(DATATYPE_ENUM dataTpProgN, DBA_RDBMS_ENUM rdbmsEn, bool bWithPrecision, unsigned int maxDbLenN)
{
    string cmd;
    if (dataTpProgN == NullDataType)
    {
        return string();
    }

    if (EV_GenDdlContext.bSqlFileOnly)
    {
        switch (dataTpProgN)
        {
            case UniCodeType:
                cmd = "$VAR_CODE_T";
                break;
            case UniInfoType:
                cmd = "$VAR_INFO_T";
                break;
            case UniLongnameType:
                cmd = "$VAR_LONGNAME_T";
                break;
            case UniNameType:
                cmd = "$VAR_NAME_T";
                break;
            case UniNoteType:
                cmd = "$VAR_NOTE_T";
                break;
            case UniPhoneType:
                cmd = "$VAR_PHONE_T";
                break;
            case UniSysnameType:
                cmd = "$VAR_SYSNAME_T";
                break;
            case UniShortinfoType:
                cmd = "$VAR_SHORTINFO_T";
                break;
            case UniTextType:
                cmd = "$VAR_TEXT_T";
                break;
            case UniUrlType:
                cmd = "$VAR_URL_T";
                break;
            case UniString1000Type:
                cmd = "$VAR_STRING1000_T";
                break;
            case UniString2000Type:
                cmd = "$VAR_STRING2000_T";
                break;
            case UniString3000Type:
                cmd = "$VAR_STRING3000_T";
                break;
            case UniString4000Type:
                cmd = "$VAR_STRING4000_T";
                break;
            case UniString7000Type:
                cmd = "$VAR_STRING7000_T";
                break;
            case UniString15000Type:
                cmd = "$VAR_STRING15000_T";
                break;

            default:
                /* Nothing to do */
                break;
        }
    }

    if (cmd.empty())
    {
        switch (rdbmsEn)
        {
            case Oracle:
                if (dataTpProgN == SysRefCursorType)
                {
                    cmd = "SYS_REFCURSOR";
                }
                else
                {
                    cmd = DBA_GetAttribEquivDataType(dataTpProgN, rdbmsEn, maxDbLenN);  /* PMSTA-38801 - JJN - 200202 */
                }

                if (bWithPrecision == false)
                {
                    /* Keep only the primary datatype, remove the precision */
                    cmd = cmd.substr(0, cmd.find_first_of("("));
                }
                break;

            case PostgreSQL:
                if (dataTpProgN == SysRefCursorType)
                {
                    cmd = "refcursor";
                }
                else if (dataTpProgN == RecordType)
                {
                    cmd = "record";
                }
                else if (dataTpProgN == TriggerType)
                {
                    cmd = "trigger";
                }
                else
                {
                    cmd = DBA_GetAttribEquivDataType(dataTpProgN, rdbmsEn, maxDbLenN);

                    if (bWithPrecision == false)
                    {
                        if (cmd.find("varchar") == 0)
                        {
                            cmd = "character varying";
                        }
                        else
                        {
                            /* Keep only the primary datatype, remove the precision */
                            cmd = cmd.substr(0, cmd.find_first_of("("));
                        }
                    }
                }
                break;

            case Sybase:
            case Nuodb:
            case MSSql:
            default:
                cmd = DBA_GetAttribEquivDataType(dataTpProgN, rdbmsEn, maxDbLenN);  /* PMSTA-38801 - JJN - 200202 */
                break;
        }
    }

    return cmd;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getParamInit()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getParamInit()
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case PostgreSQL:
            return (string("("));

        case Sybase:
        case Nuodb:
        case MSSql:
        case Oracle:
        default:
            return (string(" (\n\t "));
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getParamClose()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getParamClose(bool bEmpty)
{
    if (bEmpty)
    {
        switch (this->ddlGenContextPtr->m_rdbmsEn)
        {
            case Nuodb:
            case PostgreSQL:
                return (string("()"));
                break;

            case MSSql:
                if (this->ddlGenContextPtr->getDdlObjEn() == DdlObj_Func)
                    return (string("()"));
                else
                    return (string());
                break;

            case Sybase:
            case Oracle:
            default:
                return (string());
                break;
        }
    }
    return (string(")"));
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getParamSepartor()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getParamSepartor()
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case PostgreSQL:
            return (",");

        case Sybase:
        case Nuodb:
        case MSSql:
        case Oracle:
        default:
            return (",\n\t");
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getVarSepartor()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getVarSepartor()
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case Nuodb:
        case MSSql:
            return (string(","));
            break;
        case PostgreSQL:
            return (string(";"));
            break;
        case Oracle:
            break;
        default:
            SYS_BreakOnDebug();

    }
    return (string());
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getVarEnd()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getVarEnd()
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Nuodb:
        case MSSql:
        case PostgreSQL:
            return (string(";"));
            break;
        case Sybase:
        case Oracle:
            break;
        default:
            SYS_BreakOnDebug();
    }
    return (string());
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getProcDeclare()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getProcDeclare()
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case MSSql:
        case PostgreSQL:
            return ("declare ");
            break;
        case Oracle:
            break;
        case Nuodb:
            return ("VAR ");
            break;
        default:
            SYS_BreakOnDebug();
    }
    return (string());
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getSqlDeclare()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getSqlDeclare()
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case Oracle:
        case MSSql:
        case PostgreSQL:
            return (string("declare "));
            break;
        case Nuodb:
            return (string("VAR "));
            break;
        default:
            SYS_BreakOnDebug();
    }
    return (string());
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getParamDefaultAssign()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getParamDefaultAssign(DBA_RDBMS_ENUM rdbmsEn)
{
    switch (rdbmsEn)
    {
        case Sybase:
        case MSSql:
            return (string(" = "));
            break;
        case Oracle:
        case Nuodb:
        case PostgreSQL:
            return (string(" DEFAULT "));
            break;
        default:
            SYS_BreakOnDebug();
    }
    return (string());
}

/************************************************************************
**
**  Function    :   DdlGenDbi::isAssingBySelect()
**
**  Description : Return true if the assignment is mandatory by select
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
bool DdlGenDbi::isAssingBySelect()
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
            return false;
            break;
        case Oracle:
            return false;
            break;
        case Nuodb:
            return false;
            break;
        case MSSql:
            return false;
            break;
        case PostgreSQL:
            return false;
            break;
    }
    return true;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::isDropTableOnBootStrap()
**
**  Description : Return true the tables are dropped on bootstrap installation instead of truncate
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
bool DdlGenDbi::isDropTableOnBootStrap()
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
            return true;
            break;

        case Oracle:
            return true;
            break;

        case Nuodb:
            return false;
            break;

        case MSSql:
            return false;
            break;

        case PostgreSQL:
            return true;
            break;
    }
    return true;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::isReadOnlyParam()
**
**  Description : Return true if the assignment is mandatory by select
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
bool DdlGenDbi::isReadOnlyParam(DBA_RDBMS_ENUM rdbmsEn)
{
    switch (rdbmsEn)
    {
        case Sybase:
        case Nuodb:
        case MSSql:
        case PostgreSQL:
            return false;
            break;

        case Oracle:
            return true;
            break;
    }
    return true;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::isReadOnlyCursorVar()
**
**  Description : Return true if the assignment is mandatory by select
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
bool DdlGenDbi::isReadOnlyCursorVar(DBA_RDBMS_ENUM rdbmsEn)
{
    switch (rdbmsEn)
    {
        case Sybase:
        case MSSql:
        case Oracle:
            return false;
            break;

        case Nuodb:
        case PostgreSQL:
            return true;
            break;
    }
    return true;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getVarAssign()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getVarAssign(DBA_RDBMS_ENUM rdbmsEn)
{
    switch (rdbmsEn)
    {
        case Sybase:
        case Nuodb:
        case MSSql:
            return (string(" = "));
            break;

        case PostgreSQL:
        case Oracle:
            return (string(" := "));
            break;
    }
    return (string());
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getVarAssign()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getVarAssign()
{
    return this->getVarAssign(this->ddlGenContextPtr->m_rdbmsEn);
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getVarAssignCmd()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getVarAssignCmd(DBA_RDBMS_ENUM rdbmsEn)
{
    switch (rdbmsEn)
    {
        case Sybase:
        case MSSql:
            return (string("select "));
            break;
        case Nuodb:
        case Oracle:
            break;
        case PostgreSQL:
            return (string(" = "));
            break;
    }
    return (string());
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getVarAssignCmd()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getVarAssignCmd()
{
    return this->getVarAssignCmd(this->ddlGenContextPtr->m_rdbmsEn);
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getWhereComp()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getWhereComp(const string    &leftStr,
                               DICT_ATTRIB_STP  leftAttribStp,
                               const string    &rightStr,
                               DICT_ATTRIB_STP  rightAttribStp,
                               const string    &operStr,
                               bool             bForceNotNull)
{
    bool bStdCase = true;

    DdlGenWhereDep whereDep(leftStr, leftAttribStp, rightStr, rightAttribStp, operStr, *this);

    this->whereDepList.push_back(whereDep);

    if ((operStr.compare("=") == 0 || operStr.compare("<>") == 0 || operStr.compare("!=") == 0) &&
        ((leftAttribStp != NULL && leftAttribStp->dbMandatoryFlg == FALSE && leftAttribStp->refCheckRuleEn != RefChkRule_CheckedZeroAllowed) ||
         (rightAttribStp != NULL && rightAttribStp->dbMandatoryFlg == FALSE && rightAttribStp->refCheckRuleEn != RefChkRule_CheckedZeroAllowed)) &&
        ((rightAttribStp == NULL || rightAttribStp->dbMandatoryFlg == FALSE) && (leftAttribStp == NULL || leftAttribStp->dbMandatoryFlg == FALSE)))
    {
        bStdCase = bForceNotNull;

        switch (this->ddlGenContextPtr->m_rdbmsEn)
        {
            case Sybase:
                if (leftAttribStp == NULL || rightAttribStp == NULL ||
                    leftStr[0] == '@' || rightStr[0] == '@')
                {
                    bStdCase = true;
                }

                break;

            case Oracle:

                if (bStdCase == false &&
                    leftAttribStp == NULL &&
                    leftStr[0] == '@')
                {
                    DdlGenVar *locVar = this->varHelperPtr->getVariable(leftStr.substr(1));
                    if (locVar && locVar->bNullable == false)
                    {
                        bStdCase = true;
                    }
                }

                if (bStdCase == false &&
                    rightAttribStp == NULL &&
                    rightStr[0] == '@')
                {
                    DdlGenVar *locVar = this->varHelperPtr->getVariable(rightStr.substr(1));
                    if (locVar && locVar->bNullable == false)
                    {
                        bStdCase = true;
                    }
                }

                if (bStdCase == false)
                {
                    if ((rightAttribStp == nullptr && rightStr[0] != '?' && rightStr.find_first_of(isNotFirstSqlName) == 0) ||
                        (leftAttribStp == nullptr && leftStr[0] != '?' && leftStr.find_first_of(isNotFirstSqlName) == 0))
                    {
                        bStdCase = true;
                    }
                }

                if (bStdCase == false)
                {
                    return "SYS_OP_MAP_NONNULL(" + leftStr + ") " + operStr + " SYS_OP_MAP_NONNULL(" + rightStr + ")";
                }
                break;

            case MSSql:
            case PostgreSQL:
                if (leftAttribStp == NULL && leftStr[0] == '@')
                {
                    DdlGenVar *locVar = this->varHelperPtr->getVariable(leftStr.substr(1));
                    if (locVar && locVar->bNullable == false)
                    {
                        bStdCase = true;
                    }
                }

                if (rightAttribStp == NULL && rightStr[0] == '@')
                {
                    DdlGenVar *locVar = this->varHelperPtr->getVariable(rightStr.substr(1));
                    if (locVar && locVar->bNullable == false)
                    {
                        bStdCase = true;
                    }
                }

                if ((rightAttribStp == NULL && rightStr[0] != '?' && rightStr.find_first_of(isNotFirstSqlName) != string::npos) ||
                    (leftAttribStp == NULL && leftStr[0] != '?' && leftStr.find_first_of(isNotFirstSqlName) != string::npos))
                {
                    bStdCase = true;
                }
                break;
        }

        if (bStdCase == false)
        {
            if (operStr.compare("=") == 0)
            {
                return "(" + leftStr + " " + operStr + " " + rightStr + " or (" + leftStr + " is null and " + rightStr + " is null))";
            }
            return "(" + leftStr + " " + operStr + " " + rightStr + " or (" + leftStr + " is null and " + rightStr + " is not null)" + " or (" + leftStr + " is not null and " + rightStr + " is null))";
        }
    }

    return leftStr + " " + operStr + " " + rightStr;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getExceptionBegin()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getExceptionBegin()
{
    string outStr;

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
            break;

        case MSSql:
            outStr = this->newLine() + string("begin try\n");
            this->setIndent(1);
            break;

        case Oracle:
        case PostgreSQL:
            outStr = this->newLine() + string("begin\n");
            this->setIndent(1);
            break;

        case Nuodb:
            outStr = this->newLine() + string("try\n");
            this->setIndent(1);
            break;
    }
    return outStr;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getException()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getException(string exceptionClauseStr)
{
    stringstream outStr;

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
            break;

        case MSSql:
            outStr
                << this->newLine() << "end try "
                << this->newLine() << "begin catch" 
                << this->newLine() << "if " << exceptionClauseStr
                << this->newLine() << "begin";
            break;

        case Oracle:
        case PostgreSQL:
            outStr << this->getIndent() << "exception when " + exceptionClauseStr << " then";
            break;

        case Nuodb:
            outStr << this->getIndent() << "catch (" << exceptionClauseStr << ")";
            break;
    }
    return outStr.str();
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getExceptionEnd()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getExceptionEnd()
{
    stringstream outStr;

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
            break;

        case MSSql:
            this->setIndent(-1);
            outStr
                << this->newLine() << "end"
                << this->newLine() << "else"
                << this->newLine() << "begin";
            this->setIndent(1);
            outStr
                << this->newLine() << "declare @catched_error int,"
                << this->newLine() << "        @catched_state int,"
                << this->newLine() << "        @catched_msg   nvarchar(4000);"
                << this->newLine() << "set @catched_error = ERROR_NUMBER() + 50000;"
                << this->newLine() << "set @catched_state = ERROR_STATE();"
                << this->newLine() << "set @catched_msg   = ERROR_MESSAGE();"
                << this->newLine() << "throw @catched_error, @catched_msg, @catched_state;";
                this->setIndent(-1);
            outStr
                << this->newLine() << "end"
                << this->newLine() << "end catch" << endl;
            break;

        case Oracle:
        case PostgreSQL:
            this->setIndent(-1);
            outStr << this->newLine() << "end;\n";
            break;

        case Nuodb:
            this->setIndent(-1);
            outStr << this->newLine() << "end_try;\n";
            break;
    }
    return outStr.str();
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getDbError()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getDbError(DdlGenContext* ddlGenContextPtr)
{
    switch (ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
            return (string("@@error"));
            break;

        case MSSql:
            if (ddlGenContextPtr->m_bOnCatch)
            {
                return (string("ERROR_NUMBER()"));
            }
            return (string("@@error"));
            break;

        case Oracle:
            return (string("SQLCODE"));
            break;

        case PostgreSQL:
            if (ddlGenContextPtr->m_bOnCatch)
            {
                return (string("SQLSTATE"));
            }
            break;

        case Nuodb:
            if (ddlGenContextPtr->m_bOnCatch)
            {
                return (string("1"));
            }
            break;
    }
    return (string("0"));
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCallOutput()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCallOutput()
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case MSSql:
            return (" output");
            break;

        case Oracle:
        case Nuodb:
        case PostgreSQL:
            break;

        default:
            SYS_BreakOnDebug();
    }
    return (string());
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getReturnInProc()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getReturnInProc(const string& value)
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case MSSql:
            return ("return (" + value + ")");
            break;

        case Oracle:
        case Nuodb:
        case PostgreSQL:
            return ("return;");
            break;

        default:
            SYS_BreakOnDebug();
    }
    return (string());
}

/************************************************************************
**
**  Function    :   DdlGenDbi::prepareResultSet()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::prepareResultSet(stringstream& outStream, DdlGen& refDdlGen)
{
    string       returnsSqlName;

    auto& dictSprocReturnsVector = this->ddlGenContextPtr->getDictSprocSt().m_dictSprocReturnsVector;
    auto fromFileContextPtr = refDdlGen.getDdlGenFromFileContextPtr();

    if (this->m_ddlObjEn != DdlObj_Sql &&
        this->m_ddlObjEn != DdlObj_SubSql &&
        this->m_ddlObjEn != DdlObj_RuntimeSql &&
        this->bUnion == false)
    {
        if (this->ddlGenContextPtr->m_rdbmsEn == PostgreSQL)
        {
            returnsSqlName = SYS_Stringer(this->ddlGenContextPtr->getDictSprocSt().sqlName,
                                          "_",
                                          refDdlGen.getDictEntityStp()->shortSqlname);
        }
        else
        {
            returnsSqlName = SYS_Stringer(refDdlGen.getDictEntityStp()->mdSqlName,
                                          "_",
                                          (refDdlGen.outputDynNatEn == DynType_All || refDdlGen.outputDynNatEn == DynType_AllDb ? "all"
                                           : refDdlGen.outputDynNatEn == DynType_Short ? "short"
                                           : "custom"));
        }

        bool bNewReturns = (dictSprocReturnsVector.size() == 0 ? true : false);

        /* Assume first level as new result set */
        if (bNewReturns == false &&
            fromFileContextPtr != nullptr &&
            (fromFileContextPtr->parentTagNat == TagSql_Body || this->ddlGenContextPtr->bForceNewReturnsDef == true))
        {
            bNewReturns = true;
        }

        /* PMSTA-42424 - LJE - 201105 */
        DictSprocReturnsClass* dictSprocReturnsPtr = nullptr;

        if (bNewReturns && fromFileContextPtr != nullptr)
        {
            if (fromFileContextPtr->m_position == DdlGenFromFileContext::Position::None)
            {
                if (fromFileContextPtr->parentTagNat == TagSql_Body)
                {
                    this->ddlGenContextPtr->bForceNewReturnsDef = true;
                }
                else
                {
                    this->ddlGenContextPtr->bForceNewReturnsDef = false;
                }
            }
            else if (fromFileContextPtr->m_position != DdlGenFromFileContext::Position::Then)
            {
                if (fromFileContextPtr->m_elseResultsSetPos < static_cast<int>(fromFileContextPtr->m_ifResultsSetVector.size()))
                {
                    dictSprocReturnsPtr = &fromFileContextPtr->m_ifResultsSetVector[fromFileContextPtr->m_elseResultsSetPos];
                    fromFileContextPtr->m_elseResultsSetPos++;
                    bNewReturns = false;
                }
                else
                {
                    this->printMsg(RET_GEN_ERR_INVARG, "Mismatch output result-set description");
                }
            }
        }

        if (bNewReturns)
        {
            DBA_DYNST_ENUM returnDynStEn = ((refDdlGen.outputDynNatEn == DynType_All || refDdlGen.outputDynNatEn == DynType_AllDb) ? GET_EDITGUIST(refDdlGen.getDictEntityStp()->objectEn)
                                            : refDdlGen.outputDynNatEn == DynType_Short ? GET_ADMINGUIST(refDdlGen.getDictEntityStp()->objectEn) : A_Empty);

            dictSprocReturnsVector.push_back(DictSprocReturnsClass(returnsSqlName,
                                                                   refDdlGen.selectList,
                                                                   dictSprocReturnsVector.size() + 1,
                                                                   refDdlGen.outputDynNatEn,
                                                                   returnDynStEn));

            if (fromFileContextPtr != nullptr &&
                fromFileContextPtr->m_position == DdlGenFromFileContext::Position::Then)
            {
                fromFileContextPtr->m_ifResultsSetVector.push_back(dictSprocReturnsVector.back());
            }
        }

        if (dictSprocReturnsPtr == nullptr)
        {
            returnsSqlName = dictSprocReturnsVector.back().geReturnsSqlName();
        }
        else
        {
            returnsSqlName = dictSprocReturnsPtr->geReturnsSqlName();
        }
    }

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case MSSql:
            break;

        case Oracle:
        {
            DdlGenVar cursorVar(*this);
            cursorVar.sqlName = "cursor";
            cursorVar.setDataType(SysRefCursorType);

            outStream << this->newLine() << "DBMS_SQL.RETURN_RESULT(" + cursorVar.printSqlName() + ");";
            if (this->m_ddlObjEn == DdlObj_Sql || this->m_ddlObjEn == DdlObj_RuntimeSql)
            {
                outStream << this->newLine() << "end;";
            }
            outStream << endl;

            if (this->bUnion == false)
            {
                string decalrePartStr;
                if (this->m_ddlObjEn == DdlObj_Sql || this->m_ddlObjEn == DdlObj_RuntimeSql)
                {
                    decalrePartStr = "declare " + cursorVar.getInDeclareCmd() + this->newLine() + "begin" + this->newLine();
                }
                else
                {
                    refDdlGen.varHelperPtr->addVariable(cursorVar);
                }

                return(this->getIndent() + decalrePartStr.append("OPEN " + cursorVar.printSqlName() + " FOR") + this->newLine());
            }
        }
        break;

        case Nuodb:
            if (returnsSqlName.empty() == false)
            {
                stringstream resultSetStream;
                resultSetStream << this->getIndent() << "insert into " << returnsSqlName << " ";
                return resultSetStream.str();
            }
            break;

        case PostgreSQL:
            if (returnsSqlName.empty() && this->bUnion && this->m_ddlObjEn != DdlObj_Sql)
            {
                returnsSqlName = dictSprocReturnsVector.back().geReturnsSqlName();
            }

            if (returnsSqlName.empty() == false)
            {
                DdlGenVar cursorVar(*this);
                cursorVar.sqlName = returnsSqlName;
                cursorVar.setDataType(SysRefCursorType);
                cursorVar.strDefault = "'" + returnsSqlName + "'";

                outStream << this->newLine() << "return next " << cursorVar.printSqlName() << ";";

                if (this->m_ddlObjEn == DdlObj_Sql || this->m_ddlObjEn == DdlObj_RuntimeSql)
                {
                    outStream << this->newLine() << "end;";
                }
                outStream << endl;

                if (this->bUnion == false)
                {
                    string decalrePartStr;
                    if (this->m_ddlObjEn == DdlObj_Sql || this->m_ddlObjEn == DdlObj_RuntimeSql)
                    {
                        decalrePartStr = "declare " + cursorVar.getInDeclareCmd() + this->newLine() + "begin" + this->newLine();
                    }
                    else
                    {
                        refDdlGen.varHelperPtr->addVariable(cursorVar);
                    }

                    stringstream resultSetStream;
                    resultSetStream << this->getIndent() << decalrePartStr << "open " << cursorVar.printSqlName() << " for" << this->newLine();

                    return(resultSetStream.str());
                }
            }
            else if ((this->m_ddlObjEn == DdlObj_Sql || this->m_ddlObjEn == DdlObj_SubSql) &&
                     this->bUnion == false &&
                     (this->m_ddlObjEn == DdlObj_SubSql ||
                      (this->m_ddlGenFromFileContextPtr != nullptr && this->m_ddlGenFromFileContextPtr->m_bInBlock) ||
                      this->varHelperPtr->getVariableList()->empty() == false))
            {

                this->getDdlGenFromFileContextPtr()->m_bInBlock = true;

                returnsSqlName = "_result_set";
                dictSprocReturnsVector.push_back(DictSprocReturnsClass(returnsSqlName,
                                                                       refDdlGen.selectList,
                                                                       dictSprocReturnsVector.size() + 1,
                                                                       refDdlGen.outputDynNatEn,
                                                                       A_Empty));
                returnsSqlName = dictSprocReturnsVector.back().geReturnsSqlName();

                stringstream resultSetStream;
                
                resultSetStream
                    << this->getIndent() << "raise notice '~SQLCMD~select * from " << returnsSqlName << "';"
                    << this->newLine() << "create temporary table " << returnsSqlName << " on commit drop as"
                    << this->newLine();

                return(resultSetStream.str());
            }
            break;

        default:
            SYS_BreakOnDebug();

    }
    this->bUnion = false;

    return (string());
}

/************************************************************************
**
**  Function    :   DdlGenDbi::printDateInfo()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
std::string  DdlGenDbi::printDateInfo()
{
    YEAR_T      y;
    MONTH_T     mo;
    DAY_T       d;
    HOUR_T      h;
    MINUTE_T    mi;
    SECOND_T    sec;

    if (TRUE == SYS_CurrentTime(&y, &mo, &d, &h, &mi, &sec))
    { /* Ok */
        char dateFmt[25];
        sprintf(dateFmt, "%02d/%02d/%04d %02d:%02d:%02d",
                d, mo, 1900 + y, h, mi, sec);

        return dateFmt;
    }
    else
    { /* Error */
        return "Time error";
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::setGenInfo()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14452 - EFE - 121128
**
*************************************************************************/
void  DdlGenDbi::setGenInfo()
{
    /* CMT-12245-FME-190430 Git Version Management*/
    this->genInfoStream 
        << endl << "    generator_version       : " << AAAVersion::getVersion().getComercialNameAndVersion() << " ( Build : " << AAAVersion::getVersion().getfullVersionInfo() << ")"
        << endl << "    generation_date         : " << this->printDateInfo()
        << endl;

    if (this->ddlGenContextPtr != nullptr)
    {
        if (this->ddlGenContextPtr->m_genFileName.empty() == false)
        {
            this->genInfoStream 
                << endl << "    file                    : " << this->ddlGenContextPtr->m_genFileName;
        }
        for (auto it = this->ddlGenContextPtr->m_additionalGenInfo.begin(); it != this->ddlGenContextPtr->m_additionalGenInfo.end(); ++it)
        {
            this->genInfoStream
                << endl << "    " << (*it);
        }

        this->genInfoStream
            << endl << "    ENABLE_ADDITIONAL_DSP   : " << (this->ddlGenContextPtr->isEnableAdditionalDSP() ? "1" : "0")
            << endl << "    ENABLE_MULTI_TASC_LOGIN : " << (this->ddlGenContextPtr->isEnableMultiTascLogin() ? "1" : "0")
            << endl;
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getGenInfo()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14452 - EFE - 130208
**
*************************************************************************/
string   DdlGenDbi::getGenInfo(bool inComment)
{
    stringstream locStream;

    if (this->ddlGenContextPtr->bGenFromDbi == false)
    {
        if (this->genInfoStream.str().length() == 0)
        {
            this->setGenInfo();
        }

        if (inComment == true)
        {
            locStream << "/*" << endl << this->genInfoStream.str() << "*/" << endl;
            return locStream.str();
        }
    }

    return this->genInfoStream.str();
}

/************************************************************************
**
**  Function    :   DdlGenDbi::printBeginProc()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
void DdlGenDbi::printBeginProc(stringstream& outStream, DdlGenVarHelper* ddlGenVarHelper)
{
    stringstream emptyStream;

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case MSSql:
            outStream 
                << this->getGenInfo(true)
                << endl << "as" << endl
                << "begin" << endl;
            this->setIndent(1);
            if (ddlGenVarHelper != nullptr)
            {
                ddlGenVarHelper->printVarList(*this, outStream, emptyStream, true, this->newLine());
            }
            this->setIndent(-1);
            break;

        case Oracle:
            outStream
                << this->getGenInfo(true)
                << endl << "as" << endl;
            this->setIndent(1);

            /* PMSTA-20494 - TEB - 160808 */
            if (this->ddlGenContextPtr->bAutonomousTransaction)
            {
                outStream << this->getAutonomousTransaction() << endl;
            }

            if (ddlGenVarHelper != nullptr)
            {
                ddlGenVarHelper->printVarList(*this, outStream, emptyStream, true, this->newLine());
            }
            this->setIndent(-1);
            outStream << "begin" << endl;
            break;

        case Nuodb:
            outStream
                << this->getGenInfo(true)
                << endl << "as" << endl;
            this->setIndent(1);
            ddlGenVarHelper->printVarList(*this, outStream, emptyStream, true, this->newLine());
            this->setIndent(-1);
            break;

        case PostgreSQL:
            outStream << endl << "AS $function$" << endl << this->getGenInfo(true);
            this->setIndent(1);
            ddlGenVarHelper->printVarList(*this, outStream, emptyStream, true, this->newLine());
            this->setIndent(-1);
            outStream << "begin" << endl;
            break;

        default:
            SYS_BreakOnDebug();

    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::convertSqlBlock()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
void DdlGenDbi::convertSqlBlock(string& scptToTreat, DdlGenFromFile* scriptDdlGenPtr)
{
    /* PMSTA-55251 - LJE - 240130 */
    if (scptToTreat.find("#EXEC ") != 0)
    {
        string::size_type pos = 0;
        int paramNbr = 0;
        while ((pos = DdlGen::find_word(scptToTreat, "?", pos)) != string::npos)
        {
            scptToTreat.replace(pos, 1, SYS_Stringer("?", paramNbr++));
        }
    }

    scptToTreat = scriptDdlGenPtr->buildScript(scptToTreat, DdlObj_RuntimeSql);
}

/************************************************************************
**
**  Function    :   DdlGenDbi::finishSqlBlock()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
void DdlGenDbi::finishSqlBlock(DdlGenSqlBlock& sqlBlock, DBA_RDBMS_ENUM rdbmsEn, DDL_OBJ_ENUM ddlObjEn)
{
    stringstream sqlCmdStream;

    switch (rdbmsEn)
    {
        case Sybase:
        case Nuodb:
        case MSSql:
            break;

        case Oracle:
            if (ddlObjEn == DdlObj_RuntimeSql)
            {
                sqlBlock.declareStream() << "begin ";
                sqlBlock.releaseStream() << " end;";
            }
            else
            {
                sqlBlock.declareStream() << endl << "begin" << endl;
                sqlBlock.releaseStream() << endl << "end;" << endl;
            }
            break;

        case PostgreSQL:

            if (ddlObjEn == DdlObj_RuntimeSql)
            {
                sqlBlock.prepareStream() << "do $$ ";
                sqlBlock.declareStream() << "begin ";
                sqlBlock.releaseStream() << " end $$";
            }
            else if (ddlObjEn != DdlObj_TempTable)
            {
                sqlBlock.prepareStream() << endl << "do $$ " << endl;
                sqlBlock.declareStream() << endl << "begin" << endl;
                sqlBlock.releaseStream() << endl << "end $$" << endl;
            }
            break;
    }
}
/************************************************************************
**
**  Function    :  DdlGen::replaceTagConvert()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  ORACLE - LJE - 140707
**
*************************************************************************/
void DdlGenDbi::replaceTagConvert(string& lineToTreat,
                                  DATATYPE_ENUM   dataType,
                                  DATE_STYLE_ENUM dateTimeStyleEn)
{
    string            tagToReplace = "#", replaceStr;
    string::size_type replacePos, lastPos = string::npos;

    tagToReplace += TAG_CONVERT;

    while (lineToTreat.empty() == false &&
           (replacePos = lineToTreat.find(tagToReplace)) != string::npos &&
           lastPos != replacePos)
    {
        DdlGenVar convertVar(*this);
        string typeStr, toConvStr, styleStr;
        string::size_type pos = lineToTreat.find_first_not_of(" (,", replacePos + tagToReplace.length() + 1);
        string::size_type endPos = pos;

        int braketNbr = 0;
        bool bEnd = false;

        lastPos = replacePos;

        while (endPos < lineToTreat.length() && bEnd == false)
        {
            if (lineToTreat[endPos] == '(')
            {
                braketNbr++;
            }
            else if (braketNbr == 0 && (lineToTreat[endPos] == ',' || lineToTreat[endPos] == ')'))
            {
                if (typeStr.empty())
                {
                    typeStr = lineToTreat.substr(pos, endPos - pos);
                }
                else if (toConvStr.empty())
                {
                    toConvStr = lineToTreat.substr(pos, endPos - pos);
                    trim(toConvStr);
                }
                else if (styleStr.empty())
                {
                    styleStr = lineToTreat.substr(pos, endPos - pos);
                }

                if (lineToTreat[endPos] == ')')
                {
                    bEnd = true;
                }
                else
                {
                    pos = endPos + 1;
                }
            }

            if (lineToTreat[endPos] == ')')
            {
                if (braketNbr == 0)
                {
                    bEnd = true;
                }
                else
                {
                    braketNbr--;
                }
            }

            endPos++;
        }

        convertVar.setDataTypeSqlName(typeStr);

        if (convertVar.getDataType() == NullDataType)
        {
            this->printMsg(RET_GEN_ERR_INVARG, "CONVERT error : " + lineToTreat.substr(replacePos, endPos - replacePos) + ", Unknown data-type " + typeStr);
        }
        else
        {
            string toReplace = this->convertVar(convertVar.getDataType(), toConvStr, styleStr);
            lineToTreat.replace(replacePos, endPos - replacePos, toReplace);
        }
    }

    if ((dataType == DateType || dataType == DatetimeType) &&
        lineToTreat[0] == '\'')
    {
        switch (this->ddlGenContextPtr->m_rdbmsEn)
        {
            case Nuodb:
                switch (dateTimeStyleEn)
                {
                    case DateStyle_DdMmYy:
                    case DateStyle_DdMmYyyy:
                        lineToTreat = "DATE_FROM_STR(" + lineToTreat + ", 'dd/MM/yyyy')";
                        break;

                    case DateStyle_DdMonYyyy:
                        lineToTreat = "DATE_FROM_STR(" + lineToTreat + ", 'd MMMM yyyy')";
                        break;

                    default:
                        if (lineToTreat.find(" ") != string::npos &&
                            isalpha(lineToTreat[lineToTreat.find(" ") + 1]))
                        {
                            lineToTreat = "DATE_FROM_STR(" + lineToTreat + ", 'd MMMM yyyy')";
                        }
                }
                break;

            case PostgreSQL:
                switch (dateTimeStyleEn)
                {
                    case DateStyle_DdMmYy:
                    case DateStyle_DdMmYyyy:
                        lineToTreat = "to_date(" + lineToTreat + ", 'DD/MM/YYYY')";
                        break;

                    case DateStyle_DdMonYyyy:
                        lineToTreat = "to_date(" + lineToTreat + ", 'DD Mon YYYY')";
                        break;

                    default:
                        if (lineToTreat.find(" ") != string::npos &&
                            isalpha(lineToTreat[lineToTreat.find(" ") + 1]))
                        {
                            lineToTreat = "to_date(" + lineToTreat + ", 'DD Mon YYYY')";
                        }
                }
                break;
        }
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::treatCurrLine()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
void DdlGenDbi::treateAllVariable(string& currLine, bool bFullBlock)
{
    if (this->getVarPrefix() == "@" && bFullBlock)
    {
        return;
    }

    this->replaceTagConvert(currLine);

    string::size_type varMarkPos, varEndPos;
    string      varSqlName;
    DdlGenVar* variablePtr;
    bool        bInQuote = false, bInComment1 = false, bInComment2 = false;

    for (string::size_type pos = 0; pos < currLine.size(); pos++)
    {
        if (bInQuote)
        {
            if (currLine[pos] == '\'')
                bInQuote = false;

            continue;
        }

        if (bInComment1 && currLine[pos] != '\n')
        {
            continue;
        }
        bInComment1 = false;

        if (bInComment2 && (currLine[pos] != '*' || pos + 1 > currLine.size() || currLine[pos + 1] != '/'))
        {
            continue;
        }
        bInComment2 = false;

        if (currLine[pos] == '\'')
        {
            bInQuote = true;
        }
        else if (currLine[pos] == '-' && pos + 1 < currLine.size() && currLine[pos + 1] == '-')
        {
            bInComment1 = true;
        }
        else if (currLine[pos] == '/' && pos + 1 < currLine.size() && currLine[pos + 1] == '*')
        {
            bInComment2 = true;
        }
        else if (currLine[pos] == '@')
        {
            varMarkPos = pos;
            varSqlName = currLine.substr(varMarkPos + 1);

            varEndPos = varSqlName.find_first_of(DDLGEN_NO_ALPHA);

            if (varEndPos != 0)
            {
                if (varEndPos != string::npos)
                {
                    varSqlName.erase(varEndPos);
                }
                variablePtr = this->varHelperPtr->getVariable(varSqlName, false);

                if (variablePtr != NULL)
                {
                    string value = variablePtr->printSqlName(DdlGenVar::KindOfPrint::Use, bFullBlock);
                    currLine.replace(varMarkPos, varSqlName.length() + 1, value);
                    pos = varMarkPos + value.length();
                }
                else
                {
                    currLine.replace(varMarkPos, 1, DdlGenDbi::getVarPrefix());
                    pos = varMarkPos + varSqlName.length() + DdlGenDbi::getVarPrefix().length();
                }
            }
            else
            {
                pos++;
            }
        }
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::treatProperty()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
void DdlGenDbi::treatProperty(string& propertyStr)
{
    treatProperty(propertyStr, this->ddlGenContextPtr->m_rdbmsEn);
}

/************************************************************************
**
**  Function    :   DdlGenDbi::treatProperty()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
void DdlGenDbi::treatProperty(string& propertyStr, DBA_RDBMS_ENUM rdbmsEn)
{
    switch (rdbmsEn)
    {
        case Sybase:
            break;

        case MSSql:
            break;

        case Oracle:
        case Nuodb:
        case PostgreSQL:
        case Sqlite:
            if (propertyStr[0] == '#')
            {
                propertyStr.replace(0, 1, DdlGenDbi::getTempTablePrefix(rdbmsEn));
            }
            break;

        default:
            SYS_BreakOnDebug();
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::isSystemTable()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
bool DdlGenDbi::isSystemTable(const string& tableName)
{
    if (tableName.find("(") == string::npos &&
        (this->ddlGenContextPtr->ddlGenAction.m_installLevel < 10 || this->ddlGenContextPtr->ddlGenAction.isBootStrapLevel()))
    {
        static string allSysTables[] = {
                                  "all_objects",
                                  "all_tab_columns",
                                  "all_constraints",
                                  "all_tables",
                                  "all_tab_cols",
                                  "all_cons_columns",
                                  "all_tab_partitions",
                                  "all_tab_subpartitions",
                                  "all_part_tables",
                                  "all_part_key_columns",
                                  "all_subpart_key_columns",
                                  "all_indexes",
                                  "all_ind_columns",
                                  "all_ind_expressions",
                                  "all_part_indexes",
                                  "all_ind_partitions",
                                  "all_ind_subpartitions",
                                  "all_users",
                                  "all_tab_identity_cols",
                                  "all_sequences",
                                  "all_tab_identity_cols",
                                  "all_sequences",
                                  "v$reserved_words",
                                  "gv$session",

                                  "master..sysservers",
                                  "master..sysprocesses",
                                  "sqr_database",
                                  "systypes",
                                  "spt_datatype_info",
                                  "sysdatabases",
                                  "sysobjects",
                                  "syscolumns",
                                  "sysindexes",
                                  "syspartitionkeys",
                                  "syscurconfigs",
                                  "sysconfigures",
                                  "syscomments",
                                  "syssegments",
                                  "spt_values",
                                  "syslogins",
                                  "sysusers",

                                  "system.schemas",
                                  "system.fields",
                                  "system.tables",
                                  "system.indexes",
                                  "system.indexfields",
                                  "system.connections",
                                  "system.userroles",
                                  "system.users",
                                  "system.allsystemfields",

                                  "sys.types",
                                  "sys.objects",
                                  "sys.columns",
                                  "sys.identity_columns",
                                  "sys.indexes",
                                  "sys.index_columns",
                                  "sys.foreign_keys",
                                  "sys.key_constraints",
                                  "sys.check_constraints",
                                  "sys.foreign_key_columns",
                                  "sys.schemas",
                                  "sys.database_files",
                                  "sys.dm_exec_connections",
                                  "sys.dm_exec_sessions",
                                  "sys.database_principals",
                                  "sys.sysprocesses",
                                  "sys.triggers",
                                  "sys.trigger_events",
                                  "sys.syslanguages",
                                  "sys.filegroups",
                                  "sys.data_spaces",
                                  "sys.partitions",
                                  "sys.partition_schemes",

                                  "information_schema.tables",
                                  "information_schema.columns",
                                  "information_schema.table_constraints",
                                  "information_schema.constraint_column_usage",
                                  "pg_tables",
                                  "pg_attribute",
                                  "pg_views",
                                  "pg_index",
                                  "pg_namespace",
                                  "pg_proc",
                                  "pg_class",
                                  "pg_roles",

                                  "empty",
                                  "" };
        int    i = 0;

        while (allSysTables[i].compare("") != 0)
        {
            if (tableName.compare(allSysTables[i]) == 0)
            {
                return true;
            }
            i++;
        }
        return false;
    }
    else
    {
        return true;
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getEntityDbName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 150211
**
*************************************************************************/
string DdlGenDbi::getEntityDbName(DICT_ENTITY_STP paramDictEntityStp)
{
    /* PMSTA-37366 - LJE - 200312 */
    if (this->realDbName.empty() == false)
    {
        return this->realDbName;
    }

    string entityDbName = paramDictEntityStp->databaseName;

    if (EV_GenDdlContext.bSqlFileOnly)
    {
        std::string dbName;
        GEN_GetApplInfo(ApplSqlDbName, dbName);

        if (entityDbName.compare(dbName) == 0)
        {
            entityDbName = "$AAAMAIN_DB";
        }
        else
        {
            entityDbName = "$AAALOGIN_DB";
        }
    }

    return entityDbName;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::setDdlObjSqlName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
void DdlGenDbi::setDdlObjSqlName(const string& ddlObjSqlName)
{
    this->setDdlObjFullSqlName(this->m_dbSqlName, ddlObjSqlName);
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getDdlObjSqlName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14452 - LJE - 130114
**
*************************************************************************/
const string& DdlGenDbi::getDdlObjSqlName() const
{
    return this->m_ddlObjSqlName;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getDbDdlObjSqlName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14452 - LJE - 130114
**
*************************************************************************/
const string& DdlGenDbi::getDbDdlObjSqlName() const
{
    return this->m_dbDdlObjSqlName;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::setDdlObjFullSqlName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26250 - LJE - 170427
**
*************************************************************************/
void DdlGenDbi::setDdlObjFullSqlName(const std::string& dbSqlName, const std::string& ddlObjSqlName)
{
    this->m_ddlObjSqlName = ddlObjSqlName;
    this->m_dbDdlObjSqlName = ddlObjSqlName;

    this->setMsgSqlName(this->m_ddlObjSqlName);
    this->standardize(this->m_dbDdlObjSqlName);

    if (dbSqlName.empty() == false)
    {
        this->m_dbSqlName = dbSqlName;
        this->standardize(this->m_dbSqlName);
    }
    else
    {
        this->m_dbSqlName = this->ddlGenContextPtr->getDdlDestDbName();
    }

    this->m_ddlObjFullSqlName = this->getDdlFullName(this->m_dbSqlName, this->m_dbDdlObjSqlName);
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getDdlObjFullSqlName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26250 - LJE - 170427
**
*************************************************************************/
const string& DdlGenDbi::getDdlObjFullSqlName()
{
    if (this->m_ddlObjFullSqlName.empty())
    {
        this->m_ddlObjFullSqlName = this->getDdlFullName(this->ddlGenContextPtr->getDdlDestDbName(), this->m_dbDdlObjSqlName);
    }
    return this->m_ddlObjFullSqlName;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getExecMainDbCall()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14556 - LJE - 120705
**
*************************************************************************/
string DdlGenDbi::getExecMainDbCall(string procName, string returnValue)
{
    vector<string> resultTableVector;
    string outString = this->getExecCmd(returnValue, resultTableVector);

    outString += this->getMainDbCall() + procName;
    return outString;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getMainDbCall()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:  PMSTA-18593 - LJE - 150501
**
*************************************************************************/
string DdlGenDbi::getMainDbCall()
{
    string outString;

    if (strcasecmp(this->ddlGenContextPtr->getMainDbName().c_str(), this->ddlGenContextPtr->getDdlDestDbName().c_str()) != 0)
    {
        outString = this->ddlGenContextPtr->getMainDbName();
        this->standardize(outString);

        switch (this->ddlGenContextPtr->m_rdbmsEn)
        {
            case Sybase:
                outString += "..";
                break;

            case Oracle:
            case Nuodb:
            case MSSql:
            case PostgreSQL:
                outString += ".";
                break;
        }
    }

    return outString;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::setUserCmd()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::setUserCmd(string userName, DBA_RDBMS_ENUM rdbmsEn)
{
    string cmd;

    switch (rdbmsEn)
    {
        case Sybase:
        case MSSql:
            if (userName.empty())
            {
                cmd = "setuser ";
            }
            else
            {
                cmd = "setuser '" + userName + "'";
            }
            break;

        case Nuodb:
        case Oracle:
            break;
    }
    return cmd;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::setUserCmd()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::setUserCmd(string userName)
{
    return this->setUserCmd(userName, this->ddlGenContextPtr->m_rdbmsEn);
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getUpdateRequest()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getUpdateRequest(const string& fullEntitySqlName,
                                   const string& setStr,
                                   const string& mainFromStr,
                                   const string& addFromStr,
                                   const string& fromStr,
                                   const string& whereStr)
{
    stringstream  updStream;

    try
    {
        updStream << this->getIndent() << "update ";

        if (fromStr.empty())
        {
            string newSetStr, sep = "";
            vector<string> updAttribs;
            bool bLeftValue = false;

            switch (this->ddlGenContextPtr->m_rdbmsEn)
            {
                case Oracle:
                case Nuodb:
                case Sqlite:
                case PostgreSQL:
                    updStream
                        << fullEntitySqlName << " " << this->getAlias(true)
                        << this->newLine() << "set"
                        << setStr
                        << whereStr;
                    break;

                case MSSql:
                    DdlGen::tokenizeStr(updAttribs, setStr, "=,\n");

                    for (auto it = updAttribs.begin(); it != updAttribs.end(); it++)
                    {
                        if (bLeftValue)
                        {
                            bLeftValue = false;
                            newSetStr += " = " + *it;
                        }
                        else
                        {
                            bLeftValue = true;
                            vector<string> updAttrib;
                            DdlGen::tokenizeStr(updAttrib, *it, ".");
                            if (updAttrib.size() == 2)
                            {
                                newSetStr += sep + this->newLine() + updAttrib.at(1);
                            }
                            else
                            {
                                newSetStr += sep + this->newLine() + *it;
                            }
                            sep = ",";
                        }
                    }
                    updStream
                        << fullEntitySqlName
                        << this->newLine() << "set"
                        << newSetStr;

                    if (this->getAlias(true).empty() == false)
                    {
                        updStream
                            << this->newLine() << "from " << fullEntitySqlName << " " << this->getAlias(true);
                    }

                    updStream << whereStr;
                    break;

                case Sybase:
                default:
                    updStream
                        << fullEntitySqlName
                        << this->newLine() << "set"
                        << setStr;

                    if (this->getAlias(true).empty() == false)
                    {
                        updStream
                            << this->newLine() << "from " << fullEntitySqlName << " " << this->getAlias(true);
                    }

                    updStream << whereStr;
                    break;
            }
        }
        else
        {
            bool             bKeyPreserve = false;
            string           mainAlias = this->getAlias(true);
            size_t           pos, endPos;

            if ((pos = fullEntitySqlName.find_last_of(".")) == string::npos)
            {
                pos = 0;
            }
            else
            {
                ++pos;
            }

            string entitySqlName = fullEntitySqlName.substr(pos);
            if (entitySqlName.find("ud_") == 0)
            {
                entitySqlName.erase(0, 3);
            }
            DICT_ENTITY_STP mainEntityStp = DBA_GetEntityBySqlName(entitySqlName);

            if (mainEntityStp == nullptr)
            {
                this->printMsg(RET_GEN_ERR_INVARG, "Unknown entity " + fullEntitySqlName);
            }
            else
            {
                if (mainAlias.empty())
                {
                    this->printMsg(RET_GEN_ERR_INVARG, "Alias on main entity is mandatory on #UPDATE keyword with join information !");
                }

                vector<string> updAttribs;
                DdlGen::tokenizeStr(updAttribs, setStr, "= \t,\n");

                bool bOnlyConstantAssign = (mainEntityStp->primKeyNbr > 0);

                if (this->ddlGenContextPtr->m_rdbmsEn == PostgreSQL)
                {
                    bOnlyConstantAssign = false;
                }
                else
                {
                    string lastIt;
                    for (auto it = updAttribs.begin(); it != updAttribs.end() && bOnlyConstantAssign == true; ++it)
                    {
                        if (lastIt.empty())
                        {
                            lastIt = *it;
                            continue;
                        }

                        if (it->at(0) != '@' &&
                            it->find_first_of(isNotFirstSqlName) != 0 &&
                            strcasecmp(it->c_str(), "null") != 0)
                        {
                            bOnlyConstantAssign = false;
                        }

                        lastIt.clear();
                    }
                }

                if (bOnlyConstantAssign)
                {
                    updStream << fullEntitySqlName
                        << this->newLine() << "set";

                    for (auto it = updAttribs.begin(); it != updAttribs.end(); ++it)
                    {
                        if (it != updAttribs.begin())
                        {
                            updStream << ",";
                        }

                        updStream
                            << this->newLine() << it->substr(it->find(".") + 1) << " = ";
                        ++it;

                        if (it != updAttribs.end())
                        {
                            updStream << *it;
                        }
                    }

                    updStream
                        << this->newLine() << "where (";

                    stringstream pkAccessStream;

                    for (int i = 0; i < mainEntityStp->primKeyNbr; i++)
                    {
                        if (i)
                        {
                            updStream << ",";
                            pkAccessStream << ",";
                        }

                        updStream << mainEntityStp->primKeyTab[i]->sqlName;
                        pkAccessStream << mainAlias + "." + mainEntityStp->primKeyTab[i]->sqlName;
                    }

                    updStream
                        << " ) in (select " << pkAccessStream.str() << mainFromStr << fromStr << whereStr << ")";
                }
                else
                {
                    vector<string> fromEntities;
                    DdlGen::tokenizeStr(fromEntities, fromStr, " \t,\n");

                    vector<string> whereClauses;
                    DdlGen::tokenizeStr(whereClauses, whereStr, " \t\n");

                    if (whereClauses.empty() == false)
                    {
                        whereClauses.erase(whereClauses.begin());
                    }

                    map<string, map<string, map<string, bool>>>  entityAccesMap; /* entity / unique index / index attribute / used */
                    map<string, DICT_ENTITY_STP>                 entityMap;

                    entityMap.insert(make_pair(mainAlias, mainEntityStp));

                    bool             bJoin = false;
                    bool             bOn = false;
                    DICT_ENTITY_STP  subEntityStp = nullptr;

                    string lastIt;
                    for (auto it = fromEntities.begin(); it != fromEntities.end(); ++it)
                    {
                        if (strcasecmp(it->c_str(), "inner") == 0 ||
                            strcasecmp(it->c_str(), "left") == 0 ||
                            strcasecmp(it->c_str(), "right") == 0 ||
                            strcasecmp(it->c_str(), "outer") == 0 ||
                            strcasecmp(it->c_str(), "join") == 0)
                        {
                            bJoin = true;
                            bOn = false;
                        }
                        else if (strcasecmp(it->c_str(), "on") == 0)
                        {
                            bOn = true;

                            if (subEntityStp != nullptr)
                            {
                                this->printMsg(RET_GEN_ERR_INVARG, "Aliases are mandatory on #UPDATE keyword with join information !");
                                subEntityStp = nullptr;
                            }
                        }
                        else if (subEntityStp != nullptr)
                        {
                            if (this->ddlGenContextPtr->ddlGenAction.m_installLevel < 9)
                            {
                                map<string, map<string, bool>>  uniqueIdxMap;

                                this->ddlGenContextPtr->getUniqueIndexMap(subEntityStp->mdSqlName, uniqueIdxMap);
                                entityAccesMap.insert(make_pair(*it, uniqueIdxMap));
                            }

                            entityMap.insert(make_pair(*it, subEntityStp));
                            subEntityStp = nullptr;
                        }
                        else if (it->compare("=") == 0)
                        {
                            whereClauses.push_back(lastIt);
                            whereClauses.push_back(*it);
                            ++it;
                            if (it != fromEntities.end())
                            {
                                whereClauses.push_back(*it);
                            }
                        }
                        else if (bOn == false)
                        {
                            if ((pos = it->find_last_of(".")) == string::npos)
                            {
                                pos = 0;
                            }
                            else
                            {
                                ++pos;
                            }

                            string subEntitySqlName = it->substr(pos);

                            if (subEntitySqlName.find("ud_") == 0)
                            {
                                subEntitySqlName.erase(0, 3);
                            }
                            else if (it->length() > 0 && it->at(it->length() - 1) == '_') /* Shadow management */
                            {
                                subEntitySqlName.erase(subEntitySqlName.length() - 1);
                            }
                            else if (subEntitySqlName.find("_me") == subEntitySqlName.length() - 3)
                            {
                                subEntitySqlName.erase(subEntitySqlName.length() - 3);
                            }
                            else if (subEntitySqlName.find("_vw") == subEntitySqlName.length() - 3)
                            {
                                subEntitySqlName.erase(subEntitySqlName.length() - 3);
                            }
                            subEntityStp = DBA_GetEntityBySqlName(subEntitySqlName);

                            if (subEntityStp == nullptr && it->find("#INDEX") == string::npos)
                            {
                                this->printMsg(RET_GEN_ERR_INVARG, "Unknown ""from"" information (" + *it + ") on #UPDATE keyword!");
                            }
                            else
                            {
                                bJoin = false;
                            }
                        }

                        lastIt = *it;
                    }

                    if (whereClauses.empty() == false && entityAccesMap.empty() == false)
                    {
                        string       operatorPart;
                        list<string> cmpPartList;

                        for (vector<string>::iterator whereIt = whereClauses.begin(); whereIt != whereClauses.end(); ++whereIt)
                        {
                            if (cmpPartList.empty())
                            {
                                cmpPartList.push_back(*whereIt);
                            }
                            else if (operatorPart.empty())
                            {
                                operatorPart = *whereIt;
                            }
                            else
                            {
                                if (operatorPart.compare("=") == 0)
                                {
                                    cmpPartList.push_back(*whereIt);

                                    for (auto it = cmpPartList.begin(); it != cmpPartList.end(); ++it)
                                    {
                                        vector<string> whereAttrib;
                                        DdlGen::tokenizeStr(whereAttrib, *it, ".");

                                        if (whereAttrib.size() == 2 && whereAttrib.at(0).compare(mainAlias) != 0)
                                        {
                                            auto entityAccessIt = entityAccesMap.find(whereAttrib.at(0));
                                            auto entityIt = entityMap.find(whereAttrib.at(0));

                                            if (entityAccessIt == entityAccesMap.end() || entityIt == entityMap.end())
                                            {
                                                this->printMsg(RET_GEN_ERR_INVARG, "Unknown alias information (" + *it + ") on #UPDATE keyword");
                                            }
                                            else
                                            {
                                                DICT_ATTRIB_STP dictAttribStp = entityIt->second->getDictAttribBySqlName(whereAttrib.at(1));

                                                if (dictAttribStp == nullptr)
                                                {
                                                    this->printMsg(RET_GEN_ERR_INVARG, "Unknown attribute (" + *it + ") on #UPDATE keyword");
                                                }
                                                else
                                                {
                                                    for (auto idxIt = entityAccessIt->second.begin(); idxIt != entityAccessIt->second.end(); ++idxIt)
                                                    {
                                                        for (auto idxAttribIt = idxIt->second.begin(); idxAttribIt != idxIt->second.end(); ++idxAttribIt)
                                                        {
                                                            if (idxAttribIt->first.compare(dictAttribStp->sqlName) == 0)
                                                            {
                                                                idxAttribIt->second = true;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                operatorPart.clear();
                                cmpPartList.clear();
                            }
                        }

                        bKeyPreserve = (this->ddlGenContextPtr->m_rdbmsEn == Oracle);
                        for (auto entityIt = entityAccesMap.begin(); entityIt != entityAccesMap.end() && bKeyPreserve == true; ++entityIt)
                        {
                            bool bFound = false;
                            for (auto idxIt = entityIt->second.begin(); idxIt != entityIt->second.end() && bFound == false; ++idxIt)
                            {
                                bFound = true;
                                for (auto idxAttribIt = idxIt->second.begin(); idxAttribIt != idxIt->second.end() && bFound == true; ++idxAttribIt)
                                {
                                    if (idxAttribIt->second == false)
                                    {
                                        bFound = false;
                                    }
                                }
                            }

                            if (bFound == false)
                            {
                                bKeyPreserve = false;
                            }
                        }
                    }

                    if (bKeyPreserve)
                    {
                        string      selListStr, newSetStr;
                        bool        bLeftValue = false, bRightValue = false;
                        set<string> selAttribSet;
                        int         colNbr = 0;

                        for (auto it = updAttribs.begin(); it != updAttribs.end(); it++)
                        {
                            vector<string> updAttrib;
                            stringstream   selAttrib;

                            DdlGen::tokenizeStr(updAttrib, *it, ".");

                            if (updAttrib.size() == 2)
                            {
                                selAttrib << updAttrib.at(0) << "_" << updAttrib.at(1);

                                if (bRightValue)
                                {
                                    bLeftValue = false;
                                    bRightValue = false;
                                    newSetStr += ", ";
                                }
                                if (bLeftValue)
                                {
                                    bRightValue = true;
                                    newSetStr += " = ";
                                }
                                else
                                {
                                    bLeftValue = true;
                                }
                                newSetStr += selAttrib.str();
                            }
                            else if (bLeftValue)
                            {
                                selAttrib << "col_" << ++colNbr;
                                newSetStr += " = " + selAttrib.str();
                                bRightValue = true;
                                bLeftValue = false;
                            }
                            else
                            {
                                this->printMsg(RET_GEN_ERR_INVARG, "Wrong \"set\" definition in #UPDATE keyword (the alias must be specified on each argument of the 'set' clause)!");
                            }

                            if (selAttrib.str().empty() == false &&
                                selAttribSet.find(selAttrib.str()) == selAttribSet.end())
                            {
                                selListStr += this->newLine();
                                if (it != updAttribs.begin())
                                {
                                    selListStr += ", ";
                                }
                                else
                                {
                                    selListStr += "  ";
                                }

                                selAttribSet.insert(selAttrib.str());
                                selListStr += *it + " as " + selAttrib.str();
                            }
                        }
                        selListStr += "\n";

                        updStream << this->newLine()
                            << "(select " << selListStr
                            << this->getIndent()
                            << "from " << fullEntitySqlName << " " << this->getAlias(true)
                            << fromStr
                            << whereStr << ")" << this->newLine()
                            << "set " << newSetStr;
                    }
                    else if (this->ddlGenContextPtr->m_rdbmsEn == Sybase)
                    {
                        updStream << fullEntitySqlName
                            << this->newLine()
                            << "set"
                            << setStr
                            << (mainFromStr.empty() ? this->newLine() + "from " + fullEntitySqlName + " " + this->getAlias(true) : mainFromStr)
                            << addFromStr
                            << fromStr
                            << whereStr;
                    }
                    else if (this->ddlGenContextPtr->m_rdbmsEn == MSSql)
                    {
                        string newSetStr, sep = "";
                        bool   bLeftValue = false;
                        for (auto it = updAttribs.begin(); it != updAttribs.end(); it++)
                        {
                            if (bLeftValue)
                            {
                                bLeftValue = false;
                                newSetStr += " = " + *it;
                            }
                            else
                            {
                                bLeftValue = true;
                                vector<string> updAttrib;
                                DdlGen::tokenizeStr(updAttrib, *it, ".");
                                if (updAttrib.size() == 2)
                                {
                                    newSetStr += sep + this->newLine() + updAttrib.at(1);
                                }
                                else
                                {
                                    newSetStr += sep + this->newLine() + *it;
                                }
                                sep = ",";
                            }
                        }
                        updStream << this->getAlias(true)
                            << this->newLine()
                            << "set"
                            << newSetStr
                            << (mainFromStr.empty() ? this->newLine() + "from " + fullEntitySqlName + " " + this->getAlias(true) : mainFromStr)
                            << addFromStr
                            << fromStr
                            << whereStr;
                    }
                    else if (this->ddlGenContextPtr->m_rdbmsEn == Nuodb)
                    {
                        string locMainFromStr(mainFromStr);

                        if (locMainFromStr.empty() == false)
                        {
                            string::size_type fromPos = DdlGen::find_word(locMainFromStr, "from");
                            if (fromPos != string::npos)
                            {
                                locMainFromStr.erase(fromPos, 5);
                            }
                        }
                        updStream
                            << this->newLine()
                            << (locMainFromStr.empty() ? fullEntitySqlName + " " + this->getAlias(true) : locMainFromStr)
                            << fromStr
                            << addFromStr
                            << this->newLine()
                            << "set"
                            << setStr
                            << whereStr;
                    }
                    else if (this->ddlGenContextPtr->m_rdbmsEn == PostgreSQL)
                    {
                        string updEntity = fullEntitySqlName + " " + this->getAlias(true);
                        string localMainFromStr   = mainFromStr;
                        string localFromStr = fromStr;
                        size_t entityPos = localMainFromStr.find(updEntity);
                        
                        if (entityPos == string::npos)
                        {
                            updEntity = fullEntitySqlName + "_vw " + this->getAlias(true);
                            entityPos = localMainFromStr.find(updEntity);

                            if (entityPos == string::npos)
                            {
                                updEntity = fullEntitySqlName + "_uvw " + this->getAlias(true);
                                entityPos = localMainFromStr.find(updEntity);
                            }

                            if (entityPos == string::npos)
                            {
                                updEntity = fullEntitySqlName + "_me " + this->getAlias(true);
                                entityPos = localMainFromStr.find(updEntity);
                            }
                        }
    
                        if (entityPos != string::npos)
                        {
                            localMainFromStr.erase(entityPos, updEntity.size());

                            size_t commaPos = localFromStr.find(",");
                            if (localFromStr.find_first_not_of(" \t\n") <= commaPos)
                            {
                                localFromStr.erase(0, commaPos + 1);
                            }
                        }

                        if (addFromStr.empty() == false)
                        {
                            SYS_BreakOnDebug();
                        }

                        updStream << updEntity << this->newLine()
                            << "set"
                            << setStr << this->newLine()
                            << localMainFromStr
                            << addFromStr
                            << localFromStr
                            << whereStr;
                    }
                    else
                    {
                        bool          bSet = true;
                        stringstream  setStream, selectStream, fromWhereStream;
                        string        updWhereStr = whereStr, updFromPartStr, addWhereStr, tmpStr;

                        setStream << "set (";

                        if ((pos = fromStr.find("inner join")) != string::npos && (pos == 0 || fromStr.at(pos - 1) == ' ' || fromStr.at(pos - 1) == '\t'))
                        {
                            updFromPartStr = fromStr.substr(pos + strlen("inner join"));
                            pos = DdlGen::find_word(updFromPartStr, "on");
                            if (pos != string::npos)
                            {
                                if ((endPos = updFromPartStr.find("inner join", pos)) != string::npos ||
                                    (endPos = updFromPartStr.find("left outer join", pos)) != string::npos ||
                                    (endPos = updFromPartStr.find("right outer join", pos)) != string::npos)
                                {
                                    tmpStr = updFromPartStr.substr(endPos - 1);

                                    addWhereStr = updFromPartStr.substr(pos + 3, endPos - pos - 3);
                                }
                                else
                                {
                                    addWhereStr = updFromPartStr.substr(pos + 3);
                                }
                                if (updWhereStr.empty())
                                {
                                    updWhereStr = this->newLine() + "where " + addWhereStr;
                                }
                                else
                                {
                                    addWhereStr += " and (";
                                    updWhereStr.replace(updWhereStr.find("where ") + 6, 0, addWhereStr);
                                    updWhereStr += ")";
                                }
                                updFromPartStr = updFromPartStr.substr(0, pos) + tmpStr;
                            }
                        }
                        else
                        {
                            updFromPartStr = fromStr.substr(fromStr.find_first_not_of(" \t\n,"));
                        }

                        fromWhereStream << this->newLine() << " from " << addFromStr << updFromPartStr << updWhereStr;

                        for (vector<string>::iterator it = updAttribs.begin(); it != updAttribs.end(); it++)
                        {
                            if (bSet)
                            {
                                vector<string> updAttrib;
                                DdlGen::tokenizeStr(updAttrib, *it, ".");

                                if (it != updAttribs.begin())
                                {
                                    setStream << ", ";
                                }

                                bSet = false;
                                setStream << updAttrib.at(updAttrib.size() - 1);
                            }
                            else
                            {
                                if (selectStream.str().empty() == false)
                                {
                                    selectStream << ", ";
                                }

                                bSet = true;
                                selectStream << *it;
                            }
                        }
                        setStream << ")";

                        updStream << fullEntitySqlName << " " << mainAlias
                            << this->newLine() << setStream.str() << " = "
                            << this->newLine() << "(select " << selectStream.str() << fromWhereStream.str() << ")"
                            << this->newLine() << "where exists (select 1" << fromWhereStream.str() << ")";
                    }
                }
            }
        }

        updStream << endl;
    }
    catch (exception& e)
    {
        this->printCatchMsg(FILEINFO, e.what());
    }

    return updStream.str();
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getDeleteRequest()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getDeleteRequest(const string& entitySqlName,
                                   bool          bOnDdlObj)
{
    string empty;
    vector<string> pkList;

    return this->getDeleteRequest(entitySqlName, empty, empty, empty, empty, empty, pkList, bOnDdlObj);
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getDeleteRequest()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getDeleteRequest(const string& entitySqlName,
                                   const string& reqAlias,
                                   const string& mainFromStr,
                                   const string& addFromStr,
                                   const string& fromStr,
                                   const string& whereStr,
                                   vector<string>& pkList,
                                   bool            bOnDdlObj)
{
    stringstream  delStream;

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
            delStream << this->getIndent() << "delete " << entitySqlName;

            if (mainFromStr.empty() == false)
            {
                delStream << this->newLine() << mainFromStr;
            }

            if (reqAlias.empty() == false && fromStr.empty() && mainFromStr.empty())
            {
                delStream
                    << this->newLine() << "from " << entitySqlName << " " << reqAlias;
            }
            delStream << addFromStr;

            if (fromStr.empty() == false)
            {
                delStream << this->newLine() << fromStr;
            }

            delStream << whereStr;
            break;

        case Oracle:
        {
            bool bDeleteBySubSel = (addFromStr.empty() == false || fromStr.empty() == false || reqAlias.empty() == false)
                && mainFromStr.empty() == false && pkList.size() > 0;

            delStream << this->getIndent() << "delete " << entitySqlName;

            if (bDeleteBySubSel)
            {
                delStream
                    << this->newLine() << "where (";
                vector<string>::iterator last = pkList.end() - 1;
                for (vector<string>::iterator it = pkList.begin(); it != pkList.end(); it++)
                {
                    delStream << *it;
                    if (it != last)
                    {
                        delStream << ", ";
                    }
                }

                delStream << ")"
                    << this->newLine() << " in (select ";

                for (vector<string>::iterator it = pkList.begin(); it != pkList.end(); it++)
                {
                    if (reqAlias.empty() == false)
                    {
                        delStream << reqAlias << ".";
                    }

                    delStream << *it;
                    if (it != last)
                    {
                        delStream << ", ";
                    }
                }

                delStream
                    << this->newLine() << mainFromStr;
            }
            else if (reqAlias.empty() == false)
            {
                delStream << " " << reqAlias;
            }

            delStream
                << addFromStr
                << fromStr
                << whereStr;

            if (bDeleteBySubSel)
            {
                delStream << ")";
            }

            if (bOnDdlObj)
            {
                delStream << this->endOfCmd();
            }
        }
        break;

        case Nuodb:
        case Sqlite:
        {
            bool bDeleteBySubSel = (addFromStr.find(',') != std::string::npos || fromStr.find(',') != std::string::npos)
                && mainFromStr.empty() == false && pkList.size() == 1;

            delStream << this->getIndent() << "delete ";

            if (reqAlias.empty() && fromStr.empty() && mainFromStr.empty() && addFromStr.empty())
            {
                delStream << "from " << entitySqlName;
            }

            if (bDeleteBySubSel)
            {
                delStream << "from " << entitySqlName;

                delStream
                    << this->newLine() << "where (";
                vector<string>::iterator last = pkList.end() - 1;
                for (vector<string>::iterator it = pkList.begin(); it != pkList.end(); it++)
                {
                    delStream << *it;
                    if (it != last)
                    {
                        delStream << ", ";
                    }
                }

                delStream << ")"
                    << this->newLine() << " in (select ";

                for (vector<string>::iterator it = pkList.begin(); it != pkList.end(); it++)
                {
                    if (reqAlias.empty() == false)
                    {
                        delStream << reqAlias << ".";
                    }

                    delStream << *it;
                    if (it != last)
                    {
                        delStream << ", ";
                    }
                }
            }

            if (mainFromStr.empty() == false)
            {
                delStream << this->newLine() << mainFromStr;
            }

            if (reqAlias.empty() == false && fromStr.empty() && mainFromStr.empty())
            {
                delStream
                    << this->newLine() << "from " << entitySqlName << " " << reqAlias;
            }

            if (addFromStr.empty() == false)
            {
                delStream << addFromStr;
            }

            if (fromStr.empty() == false)
            {
                delStream << this->newLine() << fromStr;
            }

            delStream << whereStr;

            if (bDeleteBySubSel)
            {
                delStream << ")";
            }

            if (bOnDdlObj)
            {
                delStream << this->endOfCmd();
            }
        }
        break;

        case MSSql:
            delStream << this->getIndent() << "delete " << entitySqlName;

            if (mainFromStr.empty() == false)
            {
                delStream << this->newLine() << mainFromStr;
            }

            if (reqAlias.empty() == false && fromStr.empty() && mainFromStr.empty())
            {
                delStream
                    << this->newLine() << "from " << entitySqlName << " " << reqAlias;
            }
            delStream << addFromStr;

            if (fromStr.empty() == false)
            {
                delStream << this->newLine() << fromStr;
            }

            delStream << whereStr;
            break;

        case PostgreSQL:
        {
            bool bDeleteBySubSel = (addFromStr.empty() == false || fromStr.empty() == false || reqAlias.empty() == false)
                && mainFromStr.empty() == false && pkList.size() > 0;

            delStream << this->getIndent() << "delete from " << entitySqlName;

            if (bDeleteBySubSel)
            {
                delStream
                    << this->newLine() << "where (";
                vector<string>::iterator last = pkList.end() - 1;
                for (vector<string>::iterator it = pkList.begin(); it != pkList.end(); it++)
                {
                    delStream << *it;
                    if (it != last)
                    {
                        delStream << ", ";
                    }
                }

                delStream << ")"
                    << this->newLine() << " in (select ";

                for (vector<string>::iterator it = pkList.begin(); it != pkList.end(); it++)
                {
                    if (reqAlias.empty() == false)
                    {
                        delStream << reqAlias << ".";
                    }

                    delStream << *it;
                    if (it != last)
                    {
                        delStream << ", ";
                    }
                }

                delStream
                    << this->newLine() << mainFromStr;
            }
            else if (reqAlias.empty() == false)
            {
                delStream << " " << reqAlias;
            }

            delStream
                << addFromStr
                << fromStr
                << whereStr;

            if (bDeleteBySubSel)
            {
                delStream << ")";
            }

            if (bOnDdlObj)
            {
                delStream << this->endOfCmd();
            }
        }
        break;

        default:
            SYS_BreakOnDebug();
    }
    delStream << endl;

    return delStream.str();
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCursorRequest()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCursorRequest(const string& cursorNameStr,
                                   const string& cursorSelectStr,
                                   const string& cursorVarStr,
                                   const string& cursorBodyStr)
{
    stringstream  curStream;

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
            curStream << this->getIndent() << "declare " << cursorNameStr << " cursor"
                << this->newLine() << "for"
                << endl << cursorSelectStr
                << this->newLine() << "open " << cursorNameStr
                << this->newLine() << "fetch " << cursorNameStr << " into"
                << this->newLine() << cursorVarStr
                << this->newLine() << "while (@@sqlstatus = 0)"
                << this->newLine() << "begin"
                << endl << cursorBodyStr
                << this->newLine() << "fetch " << cursorNameStr << " into"
                << this->newLine() << cursorVarStr
                << this->newLine() << "end"
                << this->getCloseCursor(cursorNameStr);
            break;

        case Oracle:
            curStream << this->getIndent() << "declare"
                << this->newLine() << "cursor " << cursorNameStr
                << this->newLine() << "is "
                << endl << cursorSelectStr << this->endOfCmd()
                << this->newLine() << "begin"
                << this->newLine() << "open " << cursorNameStr << this->endOfCmd()
                << this->newLine() << "loop"
                << this->newLine() << "fetch " << cursorNameStr << " into"
                << this->newLine() << cursorVarStr << this->endOfCmd()
                << this->newLine() << "exit when " << cursorNameStr << "%notfound" << this->endOfCmd()
                << endl << cursorBodyStr
                << this->newLine() << "end loop" << this->endOfCmd()
                << this->getCloseCursor(cursorNameStr)
                << this->newLine() << "end" << this->endOfCmd() << endl;
            break;

        case Nuodb:
            if (this->isUseForSelectInsteadOfCursor())
            {
                curStream
                    << this->newLine() << "for"
                    << endl << cursorSelectStr << this->endOfCmd()
                    << endl << cursorBodyStr
                    << this->newLine() << "end_for" << this->endOfCmd() << endl;
            }
            else
            {
                curStream << this->getIndent() << "declare " << cursorNameStr << " cursor"
                    << this->newLine() << "for"
                    << endl << cursorSelectStr << this->endOfCmd()
                    << this->newLine() << "open " << cursorNameStr << this->endOfCmd()
                    << this->newLine() << "fetch " << cursorNameStr << " into"
                    << this->newLine() << cursorVarStr << this->endOfCmd()
                    << this->newLine() << "while (fetch_status() = 0)"
                    << endl << cursorBodyStr
                    << this->newLine() << "fetch " << cursorNameStr << " into"
                    << this->newLine() << cursorVarStr << this->endOfCmd()
                    << this->newLine() << "end_while" << this->endOfCmd()
                    << this->getCloseCursor(cursorNameStr) << endl;
            }
            break;

        case MSSql:
            curStream << this->getIndent() << "declare " << cursorNameStr << " cursor local"
                << this->newLine() << "for"
                << endl << cursorSelectStr
                << this->newLine() << "open " << cursorNameStr
                << this->newLine() << "fetch next from " << cursorNameStr << " into"
                << this->newLine() << cursorVarStr
                << this->newLine() << "while (@@fetch_status = 0)"
                << this->newLine() << "begin"
                << endl << cursorBodyStr
                << this->newLine() << "fetch next from " << cursorNameStr << " into"
                << this->newLine() << cursorVarStr
                << this->newLine() << "end;"
                << this->getCloseCursor(cursorNameStr);
            break;

        case PostgreSQL:
        {
            DdlGenVar* varPtr = this->varHelperPtr->getNewVariable(cursorNameStr, RecordType);

            curStream
                << this->newLine() << "for " << varPtr->printSqlName() << " in"
                << endl << cursorSelectStr
                << this->newLine() << "loop"
                << endl << cursorBodyStr
                << this->newLine() << "end loop" << this->endOfCmd() << endl;
            break;
        }

        default:
            SYS_BreakOnDebug();
    }

    return curStream.str();
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCloseCursor()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCloseCursor(const string& cursorNameStr)
{
    stringstream  curStream;

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
            curStream << this->newLine() << "close " << cursorNameStr
                << this->newLine() << "deallocate cursor " << cursorNameStr << endl;
            break;

        case Oracle:
            curStream << this->newLine() << "close " << cursorNameStr << this->endOfCmd();
            break;

        case Nuodb:
        case PostgreSQL:
            if (this->isUseForSelectInsteadOfCursor() == false)
            {
                curStream << this->newLine() << "close " << cursorNameStr << this->endOfCmd();
            }
            break;

        case MSSql:
            curStream << this->newLine() << "close " << cursorNameStr
                << this->newLine() << "deallocate " << cursorNameStr << endl;
            break;

        default:
            SYS_BreakOnDebug();
    }

    return curStream.str();
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getTruncateRequest()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getTruncateRequest(const string& entitySqlName)
{
    stringstream cmdStream;

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case Oracle:
        case Nuodb:
        case MSSql:
        case PostgreSQL:
        case Sqlite:
        default:
            cmdStream << "truncate table " << entitySqlName;
            break;
    }

    return cmdStream.str();
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCleanStatRequest()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:
**
*************************************************************************/
string DdlGenDbi::getCleanStatRequest(const string& entitySqlName)
{
    stringstream cmdStream;

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
            cmdStream << endl << "exec " << this->ddlGenContextPtr->getMainDbName() << "..cleanup_temp_table '" << entitySqlName << "' " << endl;
            break;

        case Oracle:
        case Nuodb:
        case PostgreSQL:
        case MSSql:
        default:
            break;
    }

    return cmdStream.str();
}

/************************************************************************
**
**  Function    :   DdlGenDbi::isTempTableRuntime()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 141016
**
*************************************************************************/
bool DdlGenDbi::isTempTableRuntime(DBA_RDBMS_ENUM rdbmsEn, DICT_ENTITY_STP dictEntityStp)
{
    switch (rdbmsEn)
    {
        case Oracle:
            return false;
            break;

        case MSSql:
            /* PMSTA-58084 - LJE - 240729 */
            if (DdlGenDbi::getTempTableSpec(rdbmsEn, dictEntityStp) == DdlGenDbi::TempTableSpec::Session)
            {
                return true;
            }
            return false;

        case QtHttp:
            /* PMSTA-34344 - TEB - 190319 */
            return false;
            break;

        case Sybase:
        case Nuodb:
        case PostgreSQL:
        default:
            return true;
            break;
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::isReferenceOnFk()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 150105
**
*************************************************************************/
bool DdlGenDbi::isReferenceOnFk()
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Oracle:
        case PostgreSQL:
            return true;
            break;

        case Sybase:
        case Nuodb:
        case MSSql:
        default:
            return false;
            break;
    }
}


/************************************************************************
**
**  Function    :   DdlGenDbi::isFKApplied()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation    :   PMSTA-42197 - JJN - 201212
**
*************************************************************************/
bool DdlGenDbi::isFkApplied()
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Oracle:
        case Sybase:
        case Nuodb:
        case PostgreSQL:
            return true;
            break;

        case MSSql:
        default:
            return false;
            break;
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::isCascadeAllowed()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation    :   PMSTA-46681 - LJE - 230124
**
*************************************************************************/
bool DdlGenDbi::isCascadeAllowed(DDL_OBJ_ENUM ddlObjType)
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case PostgreSQL:
            switch (ddlObjType)
            {
                case DdlObj_Table:
                    return true;

                default:
                    return false;
                    break;
            }
            break;

        case Oracle:
        case Sybase:
        case Nuodb:
        case MSSql:
        default:
            return false;
            break;
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::isDefaultInListPartition()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-34418 - LJE - 190207
**
*************************************************************************/
bool DdlGenDbi::isDefaultInListPartition()
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Oracle:
            return true;
            break;

        case Sybase:
        default:
            return false;
            break;
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::isPartitionsByAlter()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-24007 - LJE - 170717
**
*************************************************************************/
bool DdlGenDbi::isPartitionsByAlter(FEATURE_AUTH_ENUM partAuthEn)
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Oracle:
            return false;
            break;

        case Sybase:
            if (partAuthEn != FeatureAuth_Enable)
            {
                return false;
            }

        default:
            return true;
            break;
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::isDescAllInAlterTable()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 150105
**
*************************************************************************/
bool DdlGenDbi::isDescAllInAlterTable()
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Oracle:
        case PostgreSQL:
            return false;
            break;

        case Sybase:
        case Nuodb:
        case MSSql:
        default:
            return true;
            break;
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::isModifyDefaultByReplace()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26108 - LJE - 170815
**
*************************************************************************/
bool DdlGenDbi::isModifyDefaultByReplace()
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Oracle:
        case Nuodb:
        case PostgreSQL:
            return false;
            break;

        case Sybase:
        case MSSql:
        default:
            return true;
            break;
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getCmdModifyDefault
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-49178 - LJE - 221018
**
*************************************************************************/
std::string  DdlGenDbi::getCmdModifyDefault(bool bNewAttrib)
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Nuodb:
        case PostgreSQL:
            if (bNewAttrib)
            {
                return " default ";
            }
            return " set default ";
            break;

        case Oracle:
        case Sybase:
        case MSSql:
        default:
            return " default ";
            break;
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::isSysMdFullAccessiblity()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-34200 - LJE - 190110
**
*************************************************************************/
bool DdlGenDbi::isSysMdFullAccessiblity()
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Oracle:
        case Nuodb:
        case PostgreSQL:
            return true;
            break;

        case Sybase:
        case MSSql:
        default:
            return false;
            break;
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::isIndexDefinedOnPK()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-34600 - LJE - 190402
**
*************************************************************************/
bool DdlGenDbi::isIndexDefinedOnPK()
{
    if (this->isPKToDo())
    {
        switch (this->ddlGenContextPtr->m_rdbmsEn)
        {
            case Oracle:
            case Nuodb:
            case PostgreSQL:
                return true;

            case Sybase:
            case MSSql:
            default:
                return false;
        }
    }
    return false;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::isAutoIndexOnPK()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-nuodb - LJE - 190923
**
*************************************************************************/
bool DdlGenDbi::isAutoIndexOnPK()
{
    if (this->isPKToDo())
    {
        switch (this->ddlGenContextPtr->m_rdbmsEn)
        {
            case Nuodb:
            case MSSql:
            case PostgreSQL:
                return true;

            case Oracle:
            case Sybase:
            default:
                return false;
        }
    }
    return false;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::isPKToDo()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   
**
*************************************************************************/
bool DdlGenDbi::isPKToDo()
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Nuodb:
        case PostgreSQL:
        case Oracle:
        case Sybase:
        case MSSql:
        default:
            return this->ddlGenContextPtr->m_parentContext->bCreatePK;
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::isAllowModifNewRecord()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-nuodb - LJE - 190923
**
*************************************************************************/
bool DdlGenDbi::isAllowModifNewRecord() 
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Nuodb:
        case Oracle:
            return true;

        case Sybase:
        case MSSql:
        default:
            return false;
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::isAllowMultiAlterTable()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-48744 - LJE - 220425
**
*************************************************************************/
bool DdlGenDbi::isAllowMultiAlterTable()
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Oracle:
        case PostgreSQL:
            return true;

        case Nuodb:
        case Sybase:
        case MSSql:
        default:
            return false;
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::isTagInBlock()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-49178 - LJE - 220928
**
*************************************************************************/
bool DdlGenDbi::isTagInBlock(DDL_TAG_NAT_ENUM tagNatEn)
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Oracle:
            switch (tagNatEn)
            {
                case TagSql_Secured:
                    return false;
            }
            return true;

        case PostgreSQL:
            switch (tagNatEn)
            {
                case TagSql_If:
                case TagSql_IfExists:
                case TagSql_While:
                case TagSql_SetVar:
                case TagSql_GenIf:
                case TagSql_Print:
                case TagSql_Select:
                case TagSql_SelectDistinct:
                    return true;

                case TagSql_Exec:
                    if (this->getDdlObjEn() != DdlObj_RuntimeSql)
                    {
                        return true;
                    }
            }
            return false;

        case Nuodb:
        case Sybase:
        case MSSql:
        default:
            return false;
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::isOptionalParamAllowed()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-nuodb - LJE - 190423
**
*************************************************************************/
bool DdlGenDbi::isOptionalParamAllowed()
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Nuodb:
            return false;

        case Oracle:
        case Sybase:
        case MSSql:
        case PostgreSQL:
        default:
            return true;
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::isUseForSelectInsteadOfCursor()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-nuodb - LJE - 190423
**
*************************************************************************/
bool DdlGenDbi::isUseForSelectInsteadOfCursor()
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Nuodb:
        case PostgreSQL:
            return true;

        case Oracle:
        case Sybase:
        case MSSql:
        default:
            return false;
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::isUpdateOnTriggerByAssign()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-nuodb - LJE - 190423
**
*************************************************************************/
bool DdlGenDbi::isUpdateOnTriggerByAssign()
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case MSSql:
            return false;

        case Nuodb:
        case Oracle:
        default:
            return true;
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::isRollbackOnTriggerAllowed()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-nuodb - LJE - 190423
**
*************************************************************************/
bool DdlGenDbi::isRollbackOnTriggerAllowed()
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case MSSql:
            return true;

        case Nuodb:
        case Oracle:
        default:
            return false;
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::isReturnOnTriggerNeeded()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-nuodb - LJE - 190423
**
*************************************************************************/
bool DdlGenDbi::isReturnOnTriggerNeeded()
{
    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        case MSSql:
        case PostgreSQL:
            return true;

        case Nuodb:
        case Oracle:
        default:
            return false;
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getMaxDDLObjLength()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 150105
**
*************************************************************************/
string::size_type DdlGenDbi::getMaxDDLObjLength(DBA_RDBMS_ENUM rdbmsEn)
{
    switch (rdbmsEn)
    {
        case MSSql:
            return 128;
            break;

        case Oracle:
            return 255;
            break;

        case Sybase:
        case PostgreSQL:
        default:
            return 255;
            break;
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getMaxDDLObjLength()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 150105
**
*************************************************************************/
string::size_type DdlGenDbi::getMaxDDLObjLength()
{
    return this->getMaxDDLObjLength(this->ddlGenContextPtr->m_rdbmsEn);
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getOrderSortRule()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-30450 - LJE - 180305
**
*************************************************************************/
const std::string DdlGenDbi::getOrderSortRule(SORTRULE_ENUM sortRuleEn, DBA_RDBMS_ENUM rdbmsEn)
{
    string orderSortRuleStr;
    switch (sortRuleEn)
    {
        case SortRule_Descending:
            orderSortRuleStr = " desc";
            if (rdbmsEn == Oracle)
            {
                orderSortRuleStr += " nulls last";
            }
            break;

        case SortRule_Ascending:
        default:
            orderSortRuleStr = " asc";
            if (rdbmsEn == Oracle)
            {
                orderSortRuleStr += " nulls first";
            }
    }

    return orderSortRuleStr;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getOrderSortRule()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-30450 - LJE - 180305
**
*************************************************************************/
const std::string DdlGenDbi::getOrderSortRule(SORTRULE_ENUM sortRuleEn)
{
    return this->getOrderSortRule(sortRuleEn, this->ddlGenContextPtr->m_rdbmsEn);
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getOrderSortRule()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-30450 - LJE - 180305
**
*************************************************************************/
const std::string DdlGenDbi::getOrderSortRule(const std::string &sortRuleStr)
{
    SORTRULE_ENUM sortRuleEn = SortRule_Ascending;

    if (sortRuleStr.empty() == false && strcasecmp("desc", sortRuleStr.c_str()) == 0)
    {
        sortRuleEn = SortRule_Descending;
    }

    return this->getOrderSortRule(sortRuleEn);
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getDdlObjFromDb()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
FLAG_T DdlGenDbi::getDdlObjFromDb(stringstream& chkStream, DDL_OBJ_ENUM paramDdlObjEn)
{
    stringstream     ddlObjText;
    stringstream     cmd;

    DDL_OBJ_ENUM     reqDdlObjEn = paramDdlObjEn == DdlObj_None ? this->m_ddlObjEn : paramDdlObjEn;

    chkStream.clear();
    chkStream.str(std::string());

    string dbName = this->ddlGenContextPtr->getDdlDestDbName();

    DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);
    RequestHelper requestHelper(&ddlGenConnGuard.getDbiConnForDdl());
    requestHelper.setReadOnly(true);

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
    {
        string  typeStr;
        switch (reqDdlObjEn)
        {
            case DdlObj_SProc:
            case DdlObj_SpecSProc:
                typeStr = "P";
                break;

            case DdlObj_Func:
                typeStr = "SF";
                break;

            case DdlObj_Trigger:
            case DdlObj_TriggerUdField:
                typeStr = "TR";
                break;

            case DdlObj_View:
                typeStr = "V";
                break;

            case DdlObj_Constraint:
                typeStr = "C";
                break;
        }

        if (typeStr.compare("C") == 0)
        {
            cmd << "select comm.text from " << dbName << "..sysconstraints const, " << dbName << "..syscomments comm, " << dbName << "..sysobjects obj "
                << "where const.status = 128 and const.constrid = comm.id and obj.id = const.constrid "
                << "and obj.name = '" << this->getDdlObjSqlName() << "'";
        }
        else
        {
            cmd << "select sc.text from " << dbName << "..syscomments sc, " << dbName << "..sysobjects so where so.name = '"
                << this->getDdlObjSqlName()
                << "' and so.id = sc.id and so.type = '" << typeStr << "' order by sc.colid";
        }

        if (cmd.str().empty() == false)
        {
            requestHelper.setCommand(cmd.str());
            auto bindVar = requestHelper.addNewOutputData(InfoType);

            if (requestHelper.sendCommandForFetch() == RET_SUCCEED)
            {
                while (requestHelper.fetch() == RET_SUCCEED)
                {
                    ddlObjText << bindVar->getCharPtr();
                }
            }
            else
            {
                this->printMsg(RET_DBA_ERR_DBPROBLEM, "Unable to get DDL text for object: " + this->getDdlObjSqlName());
                return FALSE;
            }

            if (typeStr.compare("C") == 0 && ddlObjText.str().empty() == false)
            {
                string checkStr = ddlObjText.str();
                size_t pos = checkStr.find("CHECK");

                if (pos != string::npos)
                {
                    ddlObjText.clear();
                    ddlObjText.str(string());

                    ddlObjText << checkStr.substr(pos + 6);
                }
            }
        }
                break;
        }

        case Oracle:
    {
        switch (reqDdlObjEn)
        {
            case DdlObj_SProc:
            case DdlObj_SpecSProc:
            case DdlObj_Func:
            case DdlObj_Trigger:
            case DdlObj_TriggerUdField:
                requestHelper.addNewParamString(upper(dbName), String1000Type);
                requestHelper.addNewParamString(upper(this->getDdlObjSqlName()), String1000Type);
                    requestHelper.setCommand("select text from all_source where owner = ? and name = ? order by line");
                    break;

                case DdlObj_View:
                    requestHelper.addNewParamString(upper(dbName), String1000Type);
                    requestHelper.addNewParamString(upper(this->getDdlObjSqlName()), String1000Type);
                    requestHelper.setCommand("select text from all_views where owner = ? and view_name = ?");
                    break;

                case DdlObj_Constraint:
                    requestHelper.addNewParamString(upper(dbName), String1000Type);
                    requestHelper.addNewParamString(upper(this->getDdlObjSqlName()), String1000Type);
                    requestHelper.setCommand("select search_condition from all_constraints where owner = ? and constraint_name = ? and constraint_type = 'C' and generated = 'USER NAME'");
                    break;
            }

            auto bindVar = requestHelper.addNewOutputData(TextType);

            if (requestHelper.sendCommandForFetch() == RET_SUCCEED)
            {
                while (requestHelper.fetch() == RET_SUCCEED)
                {
                    ddlObjText << bindVar->getCharPtr();
                }
            }
            break;
        }

        case Nuodb:
        {
            switch (reqDdlObjEn)
            {
                case DdlObj_SProc:
                case DdlObj_SpecSProc:
                    requestHelper.addNewParamString(upper(dbName), String1000Type);
                    requestHelper.addNewParamString(upper(this->getDdlObjSqlName()), String1000Type);
                    requestHelper.setCommand("select proceduretext from system.procedures where schema = ? and procedurename = ?");
                    break;

                case DdlObj_Func:
                    requestHelper.addNewParamString(upper(dbName), String1000Type);
                    requestHelper.addNewParamString(upper(this->getDdlObjSqlName()), String1000Type);
                    requestHelper.setCommand("select functiontext from system.functions where schema = ? and functionname = ?");
                    break;

                case DdlObj_View:
                    requestHelper.addNewParamString(upper(dbName), String1000Type);
                    requestHelper.addNewParamString(upper(this->getDdlObjSqlName()), String1000Type);
                    requestHelper.setCommand("select viewdefinition from system.tables where schema = ? and tablename = ?");
                    break;

                case DdlObj_Trigger:
                case DdlObj_TriggerUdField:
                    requestHelper.addNewParamString(upper(dbName), String1000Type);
                    requestHelper.addNewParamString(upper(this->getDdlObjSqlName()), String1000Type);
                    requestHelper.setCommand("select trigger_text from system.triggers where schema = ? and triggername = ?");
                    break;

                case DdlObj_Constraint:
                    requestHelper.addNewParamString(upper(dbName), String1000Type);
                    requestHelper.addNewParamString(upper(this->getDdlObjSqlName()), String1000Type);
                    requestHelper.setCommand("select constrainttext from system.tableconstraints where schema = ? and constraintname = ?");
                    break;
            }

            auto bindVar = requestHelper.addNewOutputData(TextType);

            if (requestHelper.sendCommandForFetch() == RET_SUCCEED)
            {
                if (reqDdlObjEn == DdlObj_View)
                {
                    stringstream source;

                    while (requestHelper.fetch() == RET_SUCCEED)
                    {
                        source << bindVar->getCharPtr();
                    }

                    source.clear();
                    source.seekg(0, ios::beg);

                    string strLine;
                    bool bFirst = true;
                    while (getline(source, strLine))
                    {
                        if (bFirst == false)
                        {
                            ddlObjText << strLine << endl;
                        }
                        bFirst = false;
                    }
                }
                else
                {
                    while (requestHelper.fetch() == RET_SUCCEED)
                    {
                        ddlObjText << bindVar->getCharPtr();
                    }
                }
            }
            break;
        }

        case MSSql:
        {
            string  typeStr;
            switch (reqDdlObjEn)
            {
                case DdlObj_SProc:
                case DdlObj_SpecSProc:
                    typeStr = "P";
                    break;

                case DdlObj_Func:
                    typeStr = "FN";
                    break;

                case DdlObj_Trigger:
                case DdlObj_TriggerUdField:
                    typeStr = "TR";
                    break;

                case DdlObj_View:
                    typeStr = "V";
                    break;

                case DdlObj_Constraint:
                    typeStr = "C";
                    break;
            }

            if (typeStr.compare("C") == 0)
            {
                cmd << "select const.definition from sys.check_constraints const, sys.schemas sch "
                    << "where sch.schema_id = const.schema_id and const.name = '" << this->getDdlObjSqlName() << "' "
                    << "and sch.name = '" << dbName << "'";
            }
            else
            {
                cmd << "select src.definition from sys.sql_modules src, sys.objects so, sys.schemas sch where so.name = '"
                    << this->getDdlObjSqlName()
                    << "' and so.object_id = src.object_id and so.schema_id = sch.schema_id and so.type = '" << typeStr << "'"
                    << "  and sch.name = '" << dbName << "'";
            }

            if (cmd.str().empty() == false)
            {
                requestHelper.setCommand(cmd.str());
                auto bindVar = requestHelper.addNewOutputData(TextType);

                if (requestHelper.sendAndGetCommand() == RET_SUCCEED)
                {
                    ddlObjText << bindVar->getCharPtr();
                }
                else
                {
                    this->printMsg(RET_DBA_ERR_DBPROBLEM, "Unable to get DDL text for object: " + this->getDdlObjSqlName());
                    return FALSE;
                }

                if (typeStr.compare("C") == 0 && ddlObjText.str().empty() == false)
                {
                    string checkStr = ddlObjText.str();
                    size_t pos = checkStr.find("CHECK");

                    if (pos != string::npos)
                    {
                        ddlObjText.clear();
                        ddlObjText.str(string());

                        ddlObjText << checkStr.substr(pos + 6);
                    }
                }
            }
            break;
        }

        case PostgreSQL:
        {
            switch (reqDdlObjEn)
            {
                case DdlObj_SProc:
                case DdlObj_SpecSProc:
                case DdlObj_Func:
                    requestHelper.addNewParamString(dbName, String1000Type);
                    requestHelper.addNewParamString(this->getDdlObjSqlName(), String1000Type);
                    requestHelper.setCommand("select pg_get_functiondef(pp.oid) from pg_catalog.pg_proc pp "
                                             "inner join pg_roles pr on pr.oid = pp.proowner "
                                             "inner join pg_catalog.pg_namespace pn on pp.pronamespace = pn.oid "
                                             "where pr.rolname = current_user and pn.nspname = ? and pp.proname = ?");
                    break;

                case DdlObj_Trigger:
                case DdlObj_TriggerUdField:
                    break;

                case DdlObj_View:
                    requestHelper.addNewParamString(dbName, String1000Type);
                    requestHelper.addNewParamString(this->getDdlObjSqlName(), String1000Type);
                    requestHelper.setCommand("select definition from pg_catalog.pg_views pv where pv.schemaname = ? and pv.viewowner = current_user and pv.viewname = ?");
                    break;

                case DdlObj_Constraint:
                    requestHelper.addNewParamString(dbName, String1000Type);
                    requestHelper.addNewParamString(this->getDdlObjSqlName(), String1000Type);
                    requestHelper.setCommand("select pg_get_constraintdef(pc.oid) from pg_catalog.pg_constraint pc "
                                             "inner join pg_catalog.pg_namespace pn on pc.connamespace = pn.oid "
                                             "inner join pg_catalog.pg_class pc2 on pc2.oid = pc.conrelid "
                                             "where pn.nspname = ? and pc.conname = ?");
                    break;
            }

            auto bindVar = requestHelper.addNewOutputData(TextType);

            if (requestHelper.sendCommandForFetch() == RET_SUCCEED)
            {
                while (requestHelper.fetch() == RET_SUCCEED)
                {
                    ddlObjText << bindVar->getCharPtr();
                }
            }
            break;
        }
    }

    this->removeComments(ddlObjText, chkStream);

    return TRUE;
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getDependsViewMap()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-49178 - LJE - 221109
**
*************************************************************************/
void DdlGenDbi::getDependsViewMap(const std::string& databaseStr, 
                                  const std::string& tableStr, 
                                  const std::string& columnStr, 
                                  std::map<std::string, std::set<std::string>>& depViewMap)
{

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case PostgreSQL:
        {
            DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);
            RequestHelper requestHelper(&ddlGenConnGuard.getDbiConn());
            requestHelper.setReadOnly(true);

            stringstream cmd;
            cmd << "SELECT " << endl
                << " dependent_view.relname as dependent_view" << endl
                << ",  dependent_ns.nspname as dependent_schema" << endl
                << "FROM pg_depend" << endl
                << "JOIN pg_rewrite ON pg_depend.objid = pg_rewrite.oid" << endl
                << "JOIN pg_class as dependent_view ON pg_rewrite.ev_class = dependent_view.oid" << endl
                << "JOIN pg_class as source_table ON pg_depend.refobjid = source_table.oid" << endl
                << "JOIN pg_attribute ON pg_depend.refobjid = pg_attribute.attrelid" << endl
                << "AND pg_depend.refobjsubid = pg_attribute.attnum" << endl
                << "JOIN pg_namespace dependent_ns ON dependent_ns.oid = dependent_view.relnamespace" << endl
                << "JOIN pg_namespace source_ns ON source_ns.oid = source_table.relnamespace" << endl
                << "WHERE" << endl
                << "source_ns.nspname = ?" << endl
                << "AND source_table.relname = ?" << endl
                << "AND pg_attribute.attnum > 0" << endl
                << "AND pg_attribute.attname = ?" << endl
                << "ORDER BY 1, 2;" << endl;

            requestHelper.addNewParamString(lower(databaseStr), String1000Type);
            requestHelper.addNewParamString(lower(tableStr), String1000Type);
            requestHelper.addNewParamString(lower(columnStr), String1000Type);

            requestHelper.setCommand(cmd.str());

            char* dbName = nullptr;
            char* viewName = nullptr;

            requestHelper.addNewOutputData(LongSysnameType);
            requestHelper.getBindVariablePtr(viewName);
            requestHelper.addNewOutputData(LongSysnameType);
            requestHelper.getBindVariablePtr(dbName);

            if (requestHelper.sendCommandForFetch() == RET_SUCCEED)
            {
                while (requestHelper.fetch() == RET_SUCCEED)
                {
                    depViewMap[dbName].insert(viewName);
                }
            }
            break;
        }

        default:
            break;
    }

}

/************************************************************************
**
**  Function    :   DdlGenDbi::getDependsConstraintMap()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-51581 - LJE - 221109
**
*************************************************************************/
void DdlGenDbi::getDropConstraintSet(const std::string& databaseStr,
                                     const std::string& tableStr,
                                     const std::string& columnStr,
                                     std::set<std::string>& dropConstrSet)
{

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case MSSql:
        {
            DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);
            RequestHelper requestHelper(&ddlGenConnGuard.getDbiConnForDdl());
            requestHelper.setReadOnly(true);

            stringstream cmd;
            cmd << "select dc.name "
                << "from sys.default_constraints dc "
                << "inner join sys.columns c on c.default_object_id = dc.object_id "
                << "inner join sys.objects so on so.object_id = dc.parent_object_id "
                << "inner join sys.schemas sch on so.schema_id = sch.schema_id "
                << "where so.name = ? "
                << "and c.name = ? "
                << "and sch.name = ?";

            requestHelper.addNewParamString(lower(tableStr), String1000Type);
            requestHelper.addNewParamString(lower(columnStr), String1000Type);
            requestHelper.addNewParamString(lower(databaseStr), String1000Type);

            requestHelper.setCommand(cmd.str());

            char* constrName = nullptr;

            requestHelper.addNewOutputData(LongSysnameType);
            requestHelper.getBindVariablePtr(constrName);

            if (requestHelper.sendCommandForFetch() == RET_SUCCEED)
            {
                while (requestHelper.fetch() == RET_SUCCEED)
                {
                    dropConstrSet.insert(constrName);
                }
            }
            break;
        }

        default:
            break;
    }

}

/************************************************************************
**
**  Function    :   DdlGenDbi::getAllDdlObjListFromDb()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
void DdlGenDbi::getAllDdlObjListFromDb(map<DdlObjDefKey, DdlObjDef>& ddlObjDefMap,
                                       std::string     database,
                                       std::string     tableSqlName,
                                       std::string     ddlObjSqlName,
                                       DDL_OBJ_ENUM    ddlObjType,
                                       std::string     refTableSqlName,
                                       std::string     refAttribSqlName)
{
    if (this->ddlGenContextPtr->bGenFromDbi)
    {
        return;
    }

    stringstream ddlObjText;
    stringstream cmd;
    DDL_OBJ_ENUM reqDdlObjEn     = (ddlObjType == DdlObj_None ? this->m_ddlObjEn : ddlObjType);
    string       typeStr         = DdlGenDbi::getDdlObjType(ddlObjType);
    char        *tableName       = nullptr;
    char        *objName         = nullptr;
    char        *colName         = nullptr;
    char        *searchCondition = nullptr;
    char        *refAttribute    = nullptr;
    char        *refEntity       = nullptr;

    DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);
    RequestHelper requestHelper(&ddlGenConnGuard.getDbiConnForDdl());
    requestHelper.setReadOnly(true);

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case Sybase:
        {
            switch (reqDdlObjEn)
            {
                case DdlObj_Constraint:
                    cmd << "select tb.name, so.name, comm.text "
                        << "from sysobjects so "
                        << "inner join sysconstraints constr on so.id = constr.constrid "
                        << "inner join sysobjects tb on tb.id = constr.tableid "
                        << "inner join syscomments comm on constr.constrid = comm.id "
                        << "where so.type = '" << typeStr << "' and tb.name = '" << tableSqlName << "'";

                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(tableName);
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(objName);
                    requestHelper.addNewOutputData(String1000Type);
                    requestHelper.getBindVariablePtr(searchCondition);

                    break;

                case DdlObj_PrimaryKey:
                    cmd << "select so1.name, sc1.name from sysobjects so1, syscolumns sc1, syskeys sk"
                        << " where so1.id=sc1.id and so1.id=sk.id and sc1.colid=sk.key1 and so1.type='" << typeStr << "' and sk.type = 1";

                    if (tableSqlName.empty() == false)
                    {
                        cmd << " and so1.name='" << tableSqlName << "'";
                    }

                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(tableName);
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(colName);

                    break;

                case DdlObj_ForeignKey:
                    cmd << "select "
                        << "so.name, related_object = rso.name, object_keys = sc1.name "
                        << "from sysobjects so, syskeys k, master.dbo.spt_values v, sysobjects rso, syscolumns sc1, syscolumns rsc1 "
                        << "where k.type = v.number and v.type = 'K' "
                        << "and k.id = so.id "
                        << "and so.name = '" << tableSqlName << "' "
                        << "and rso.id = k.depid "
                        << "and sc1.id = so.id and sc1.colid = k.key1 "
                        << "and rsc1.id = rso.id and rsc1.colid = k.depkey1";

                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(tableName);
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(objName);
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(colName);
                    break;

                case DdlObj_ReversedForeignKey:
                    break;

                case DdlObj_SProc:
                case DdlObj_SpecSProc:
                case DdlObj_Func:
                case DdlObj_View:
                    cmd << "select so.name from sysobjects so where so.type = '" + typeStr + "'";

                    if (ddlObjSqlName.empty() == false)
                    {
                        cmd << " and so.name='" << ddlObjSqlName << "'";
                    }

                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(objName);
                    break;

                case DdlObj_Table:
                    cmd << "select so.name from sysobjects so where so.type = '" + typeStr + "'";

                    if (tableSqlName.empty() == false)
                    {
                        cmd << " and so.name='" << tableSqlName << "'";
                    }

                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(tableName);
                    break;

                case DdlObj_Trigger:
                case DdlObj_TriggerUdField:
                    cmd << "select tb.name, tr.name from sysobjects tr inner join sysobjects tb on tr.deltrig = tb.id where tr.type = 'TR'";

                    if (tableSqlName.empty() == false)
                    {
                        cmd << " and tb.name='" << tableSqlName << "'";
                    }
                    else if (reqDdlObjEn == DdlObj_TriggerUdField)
                    {
                        cmd << " and tb.name like = 'ud\\_'";
                    }
                    else
                    {
                        cmd << " and tb.name not like = 'ud\\_'";
                    }

                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(tableName);
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(objName);
                    break;

                case DdlObj_Index:
                    cmd << "select so.name, si.name from sysindexes si inner join sysobjects so on so.type='U' and so.id = si.id where si.indid > 0 and si.indid < 255";

                    if (tableSqlName.empty() == false)
                    {
                        cmd << " and so.name = '" << tableSqlName << "'";
                    }

                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(tableName);
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(objName);
                    break;

                default:
                    SYS_BreakOnDebug();
                    break;
            }

            if (cmd.str().empty() == false)
            {
                requestHelper.useDb(database);
                requestHelper.setCommand(cmd.str());

                if (requestHelper.sendCommandForFetch() == RET_SUCCEED)
                {
                    while (requestHelper.fetch() == RET_SUCCEED)
                    {
                        DdlObjDef ddlObjDef(this->ddlGenContextPtr->m_rdbmsEn, 
                                            reqDdlObjEn,
                                            database,
                                            (tableName != nullptr ? tableName : string()), 
                                            string(),
                                            (objName != nullptr ? objName : tableName));

                        auto it = ddlObjDefMap.insert(make_pair(ddlObjDef, ddlObjDef));

                        if (colName != nullptr)
                        {
                            it.first->second.m_refAttributeTab.push_back(colName);
                        }
                        if (searchCondition != nullptr)
                        {
                            it.first->second.m_searchCondition = searchCondition;
                        }
                    }
                }
                else
                {
                    char buffer[100];
                    sprintf(buffer, "Unable to get DDL text (type %s) for table: %s", typeStr.c_str(), tableSqlName.c_str());
                    MSG_DispMsgText(RET_SUCCEED, buffer);
                    return;
                }
            }
            break;
        }

        case Oracle:
        {
            char *validated     = nullptr;
            char *status        = nullptr;
            char* refDeleteRule = nullptr;

            switch (reqDdlObjEn)
            {
                case DdlObj_Constraint:
                    requestHelper.addNewParamString(upper(database), String1000Type);
                    requestHelper.addNewParamString(upper(tableSqlName), String1000Type);

                    requestHelper.setCommand(
                        "select lower(c1.table_name), lower(c1.constraint_name), lower(cc1.column_name), c1.search_condition, c1.validated"
                        " from all_constraints c1"
                        " inner join all_cons_columns cc1 on cc1.owner = cc1.owner and c1.constraint_name = cc1.constraint_name"
                        " where c1.owner = ?"
                        " and c1.table_name = ?"
                        " and c1.constraint_type = 'C'"
                        " and c1.generated = 'USER NAME'"
                        " order by c1.constraint_name, cc1.position");

                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(tableName);
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(objName);
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(refAttribute);
                    requestHelper.addNewOutputData(String4000Type);
                    requestHelper.getBindVariablePtr(searchCondition);
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(validated);

                    break;

                case DdlObj_PrimaryKey:
                    requestHelper.addNewParamString(upper(database), String1000Type);

                    cmd << "select c1.table_name, lower(cc1.column_name), c1.validated"
                        " from all_constraints c1"
                        " inner join all_cons_columns cc1 on cc1.owner = cc1.owner and c1.constraint_name = cc1.constraint_name"
                        " where c1.owner = ?";

                    if (tableSqlName.empty() == false)
                    {
                        requestHelper.addNewParamString(upper(tableSqlName), String1000Type);
                        cmd << " and c1.table_name = ?";
                    }

                    cmd << " and c1.constraint_type = 'P'"
                        " order by c1.constraint_name, cc1.position";

                    requestHelper.setCommand(cmd.str());

                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(tableName);
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(refAttribute);
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(validated);
                    break;

                case DdlObj_ForeignKey:
                    requestHelper.addNewParamString(upper(database), String1000Type);
                    requestHelper.addNewParamString(upper(tableSqlName), String1000Type);

                    requestHelper.setCommand(
                        "select lower(c1.table_name), lower(c1.constraint_name), lower(c2.table_name), lower(cc1.column_name), c1.delete_rule, c1.validated"
                        " from all_constraints c1"
                        " inner join all_constraints c2 on c1.r_owner = c2.owner and c1.r_constraint_name = c2.constraint_name"
                        " inner join all_cons_columns cc1 on cc1.owner = cc1.owner and c1.constraint_name = cc1.constraint_name"
                        " where c1.owner = ?"
                        " and c1.table_name = ?"
                        " and c1.constraint_type = 'R'"
                        " and c1.generated = 'USER NAME'"
                        " order by c1.constraint_name, cc1.position");

                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(tableName);
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(objName);
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(refEntity);
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(refAttribute);
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(refDeleteRule);
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(validated);
                    break;

                case DdlObj_ReversedForeignKey:
                    requestHelper.addNewParamString(upper(database), String1000Type);
                    requestHelper.addNewParamString(upper(tableSqlName), String1000Type);

                    requestHelper.setCommand(
                        "select lower(contr_p.table_name), lower(constr_fk.constraint_name), lower(constr_fk.table_name), constr_fk.delete_rule, constr_fk.validated"
                        " from all_constraints contr_p"
                        " inner join all_constraints constr_fk on contr_p.constraint_name = constr_fk.r_constraint_name and contr_p.owner = constr_fk.owner and constr_fk.constraint_type = 'R'"
                        " where contr_p.owner = ? and contr_p.table_name = ? and contr_p.constraint_type = 'P'");

                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(tableName);
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(objName);
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(refEntity);
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(refDeleteRule);
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(validated);
                    break;

                case DdlObj_Trigger:
                case DdlObj_TriggerUdField:
                    requestHelper.addNewParamString(upper(database), String1000Type);

                    cmd << "select lower(table_name), trigger_name from all_triggers where table_owner = ?";

                    if (tableSqlName.empty() == false)
                    {
                        requestHelper.addNewParamString(upper(tableSqlName), String1000Type);
                        cmd << " and table_name = ?";
                    }
                    else if (reqDdlObjEn == DdlObj_TriggerUdField)
                    {
                        cmd << " and table_name like 'ud\\_'";
                    }
                    else
                    {
                        cmd << " and table_name not like 'ud\\_'";
                    }
                    requestHelper.setCommand(cmd.str());

                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(tableName);
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(objName);
                    break;

                case DdlObj_Table:
                    requestHelper.addNewParamString(upper(database), String1000Type);
                    requestHelper.addNewParamString(typeStr, String1000Type);

                    cmd << "select lower(object_name)  from all_objects where owner = ? and object_type = ?";

                    if (tableSqlName.empty() == false)
                    {
                        requestHelper.addNewParamString(upper(tableSqlName), String1000Type);
                        cmd << " and object_name = ?";
                    }

                    requestHelper.setCommand(cmd.str());

                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(tableName);
                    break;

                case DdlObj_Index:
                    requestHelper.addNewParamString(upper(database), String1000Type);
                    requestHelper.addNewParamString(typeStr, String1000Type);

                    cmd << "select aic.table_name, aic.index_name from all_ind_columns aic where aic.table_owner = ?";

                    if (tableSqlName.empty() == false)
                    {
                        requestHelper.addNewParamString(upper(tableSqlName), String1000Type);
                        cmd << " and aic.table_name = ?";
                    }

                    requestHelper.setCommand(cmd.str());

                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(tableName);
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(objName);
                    break;

                case DdlObj_SProc:
                case DdlObj_SpecSProc:
                case DdlObj_Func:
                case DdlObj_View:
                    requestHelper.addNewParamString(upper(database), String1000Type);
                    requestHelper.addNewParamString(typeStr, String1000Type);

                    cmd << "select lower(object_name), status from all_objects where owner = ? and object_type = ?";

                    if (ddlObjSqlName.empty() == false)
                    {
                        requestHelper.addNewParamString(upper(ddlObjSqlName), String1000Type);
                        cmd << " and object_name = ?";
                    }

                    requestHelper.setCommand(cmd.str());

                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(objName);
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(status);
                    break;

                default:
                    SYS_BreakOnDebug();
                    break;
            }

            if (requestHelper.sendCommandForFetch() == RET_SUCCEED)
            {
                while (requestHelper.fetch() == RET_SUCCEED)
                {
                    DdlObjDef ddlObjDef(this->ddlGenContextPtr->m_rdbmsEn,
                                        reqDdlObjEn,
                                        database,
                                        (tableName != nullptr ? tableName : string()),
                                        string(),
                                        (objName != nullptr ? objName : tableName));

                    auto it = ddlObjDefMap.insert(make_pair(ddlObjDef, ddlObjDef));

                    if (refEntity != nullptr && refEntity[0] != 0)
                    {
                        it.first->second.m_refEntity = refEntity;
                    }
                    if (refAttribute != nullptr && refAttribute[0] != 0)
                    {
                        it.first->second.m_refAttributeTab.push_back(refAttribute);
                    }
                    if (refDeleteRule != nullptr)
                    {
                        if (strcmp(refDeleteRule, "CASCADE") == 0)
                        {
                            it.first->second.m_refDeleteRuleEn = RefDelRule_CascadeDelete;
                        }
                        else if (strcmp(refDeleteRule, "SET NULL") == 0)
                        {
                            it.first->second.m_refDeleteRuleEn = RefDelRule_SetNULL;
                        }
                        else
                        {
                            it.first->second.m_refDeleteRuleEn = RefDelRule_Restrict;
                        }
                    }
                    if (searchCondition != nullptr)
                    {
                        it.first->second.m_searchCondition = searchCondition;
                    }
                    if (validated != nullptr)
                    {
                        if (strcmp(validated, "VALIDATED") == 0)
                        {
                            it.first->second.m_bValidated = true;
                        }
                        else
                        {
                            it.first->second.m_bValidated = false;
                        }
                    }
                    if (status != nullptr)
                    {
                        if (strcmp(status, "VALID") == 0)
                        {
                            it.first->second.m_bValidated = true;
                        }
                        else
                        {
                            it.first->second.m_bValidated = false;
                        }
                    }
                }
            }
            break;
        }

        case Nuodb:
        {
            SMALLINT_T* validated     = nullptr;
            char*       refDeleteRule = nullptr;


            switch (reqDdlObjEn)
            {
                case DdlObj_Constraint:
                    requestHelper.addNewParamString(upper(database), String1000Type);
                    requestHelper.addNewParamString(upper(tableSqlName), String1000Type);

                    requestHelper.setCommand(
                        "select lower(c1.tablename), lower(c1.constraintname), c1.constrainttext"
                        " from system.tableconstraints c1"
                        " where c1.schema = ?"
                        " and c1.tablename = ?"
                        " order by c1.constraintname");

                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(tableName);
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(objName);
                    requestHelper.addNewOutputData(TextType);
                    requestHelper.getBindVariablePtr(searchCondition);
                    break;

                case DdlObj_PrimaryKey:
                    requestHelper.addNewParamString(upper(database), String1000Type);

                    cmd << "select lower(c1.tablename), lower(cc1.field)"
                        " from system.indexes c1"
                        " inner join system.indexfields cc1 on cc1.schema = cc1.schema and c1.tablename = cc1.tablename and c1.indexname = cc1.indexname"
                        " where c1.schema = ?";

                    if (tableSqlName.empty() == false)
                    {
                        requestHelper.addNewParamString(upper(tableSqlName), String1000Type);
                        cmd << " and c1.tablename = ?";
                    }

                    cmd << " and c1.indextype = 0"
                        " order by cc1.position";

                    requestHelper.setCommand(cmd.str());

                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(tableName);
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(refAttribute);
                    break;

                case DdlObj_ForeignKey:
                    requestHelper.addNewParamString(upper(database), String1000Type);
                    requestHelper.addNewParamString(upper(tableSqlName), String1000Type);

                    requestHelper.setCommand(
                        "select lower(ft.tablename), lower(fk.foreignkeyname), lower(pt.tablename), lower(fa.field), fk.deleterule"
                        " from system.foreignkeys fk"
                        " inner join system.tables pt on pt.tableid = fk.primarytableid"
                        " inner join system.tables ft on ft.tableid = fk.foreigntableid and pt.schema = ft.schema"
                        " inner join system.fields fa on fa.tablename = ft.tablename and fa.schema = ft.schema and fa.fieldid = fk.foreignfieldid"
                        " where ft.schema = ?"
                        " and ft.tablename = ?"
                        " order by fk.foreignkeyname, fk.position");

                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(tableName);
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(objName);
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(refEntity);
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(refAttribute);
                    requestHelper.addNewOutputData(SmallintType);
                    requestHelper.getBindVariablePtr(refDeleteRule);
                    break;

                case DdlObj_ReversedForeignKey:
                    requestHelper.addNewParamString(upper(database), String1000Type);
                    requestHelper.addNewParamString(upper(tableSqlName), String1000Type);

                    requestHelper.setCommand(
                        "");

                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(objName);
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(refEntity);
                    requestHelper.addNewOutputData(SmallintType);
                    requestHelper.getBindVariablePtr(refDeleteRule);
                    break;

                case DdlObj_Trigger:
                case DdlObj_TriggerUdField:

                    requestHelper.addNewParamString(upper(database), String1000Type);
                    cmd << "select lower(trg.tablename), trg.triggername, trg.active from system.triggers trg where trg.schema = ?";

                    if (tableSqlName.empty() == false)
                    {
                        requestHelper.addNewParamString(upper(tableSqlName), String1000Type);
                        cmd << "  and trg.tablename = ?";
                    }
                    else if (reqDdlObjEn == DdlObj_TriggerUdField)
                    {
                        cmd << "  and trg.tablename like 'ud\\_'";
                    }
                    else
                    {
                        cmd << "  and trg.tablename not like 'ud\\_'";
                    }

                    requestHelper.setCommand(cmd.str());
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(tableName);
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(objName);
                    requestHelper.addNewOutputData(IntType);
                    requestHelper.getBindVariablePtr(validated);
                    break;

                case DdlObj_Table:
                    requestHelper.addNewParamString(upper(database), String1000Type);
                    requestHelper.addNewParamString(typeStr, String1000Type);

                    cmd << "select lower(tb.tablename) from system.tables tb where tb.schema = ? and tb.type = ?";

                    if (tableSqlName.empty() == false)
                    {
                        requestHelper.addNewParamString(upper(tableSqlName), String1000Type);
                        cmd << " and tb.tablename = ?";
                    }

                    requestHelper.setCommand(cmd.str());

                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(tableName);
                    break;

                case DdlObj_View:
                    requestHelper.addNewParamString(upper(database), String1000Type);
                    requestHelper.addNewParamString(typeStr, String1000Type);

                    cmd << "select lower(tb.tablename) from system.tables tb where tb.schema = ? and tb.type = ?";

                    if (ddlObjSqlName.empty() == false)
                    {
                        requestHelper.addNewParamString(upper(ddlObjSqlName), String1000Type);
                        cmd << " and tb.tablename = ?";
                    }

                    requestHelper.setCommand(cmd.str());

                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(objName);
                    break;

                case DdlObj_Index:
                    requestHelper.addNewParamString(upper(database), String1000Type);
                    requestHelper.addNewParamString(typeStr, String1000Type);

                    cmd << "select lower(so.tablename), lower(si.name) from sys.indexes si "
                        "inner join sys.objects so on so.type = 'U' and so.object_id = si.object_id "
                        "inner join sys.schemas sch on so.schema_id = sch.schema_id "
                        "where si.index_id > 0 and si.index_id < 255 and sch.name = ?";

                    if (tableSqlName.empty() == false)
                    {
                        requestHelper.addNewParamString(upper(tableSqlName), String1000Type);
                        cmd << " and so.tablename = ?";
                    }

                    requestHelper.setCommand(cmd.str());

                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(tableName);
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(objName);
                    break;

                case DdlObj_SProc:
                case DdlObj_SpecSProc:
                    requestHelper.addNewParamString(upper(database), String1000Type);

                    cmd << "select procedurename from system.procedures where schema = ? ";

                    if (ddlObjSqlName.empty() == false)
                    {
                        requestHelper.addNewParamString(upper(ddlObjSqlName), String1000Type);
                        cmd << " and procedurename = ?";
                    }

                    requestHelper.setCommand(cmd.str());

                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(objName);
                    break;

                case DdlObj_Func:
                    requestHelper.addNewParamString(upper(database), String1000Type);

                    cmd << "select functionname from system.functions where schema = ? ";

                    if (ddlObjSqlName.empty() == false)
                    {
                        requestHelper.addNewParamString(upper(ddlObjSqlName), String1000Type);
                        cmd << " and functionname = ?";
                    }

                    requestHelper.setCommand(cmd.str());

                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(objName);
                    break;

                default:
                    SYS_BreakOnDebug();
                    break;
            }

            if (requestHelper.sendCommandForFetch() == RET_SUCCEED)
            {
                while (requestHelper.fetch() == RET_SUCCEED)
                {
                    DdlObjDef ddlObjDef(this->ddlGenContextPtr->m_rdbmsEn,
                                        reqDdlObjEn,
                                        database,
                                        (tableName != nullptr ? tableName : string()),
                                        string(),
                                        (objName != nullptr ? objName : tableName));

                    auto it = ddlObjDefMap.insert(make_pair(ddlObjDef, ddlObjDef));

                    if (refEntity != nullptr && refEntity[0] != 0)
                    {
                        it.first->second.m_refEntity = refEntity;
                    }
                    if (refAttribute && refAttribute[0])
                    {
                        it.first->second.m_refAttributeTab.push_back(refAttribute);
                    }
                    if (refDeleteRule != nullptr)
                    {
                        if (*refDeleteRule == 0)
                        {
                            it.first->second.m_refDeleteRuleEn = RefDelRule_CascadeDelete;
                        }
                        else if (*refDeleteRule == 2)
                        {
                            it.first->second.m_refDeleteRuleEn = RefDelRule_SetNULL;
                        }
                        else if (*refDeleteRule == 1)
                        {
                            it.first->second.m_refDeleteRuleEn = RefDelRule_Restrict;
                        }
                        else
                        {
                            it.first->second.m_refDeleteRuleEn = RefDelRule_NoAction;
                        }
                    }
                    if (searchCondition != nullptr)
                    {
                        it.first->second.m_searchCondition = searchCondition;
                    }
                    if (validated != nullptr)
                    {
                        if (*validated == 1)
                        {
                            it.first->second.m_bValidated = true;
                        }
                        else
                        {
                            it.first->second.m_bValidated = false;
                        }
                    }
                }
            }
            break;
        }

        case MSSql:
        {
            SMALLINT_T*  refDeleteRule = nullptr;
            char*        typeDescPtr   = nullptr;

            switch (reqDdlObjEn)
            {
                case DdlObj_Constraint:
                    requestHelper.addNewParamString(tableSqlName, String1000Type);

                    cmd << "select so.name, constr.name, constr.definition "
                        "from sys.objects so "
                        "inner join sys.check_constraints constr on so.object_id = constr.parent_object_id "
                        "where so.type = 'U' and so.name = ?  and schema_name(so.schema_id) = '" << database << "'";

                    requestHelper.setCommand(cmd.str());

                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(tableName);
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(objName);
                    requestHelper.addNewOutputData(TextType);
                    requestHelper.getBindVariablePtr(searchCondition);
                    break;

                case DdlObj_PrimaryKey:

                    cmd << "select so.name, sc.name, sk.name, idx.type_desc "
                        "from sys.key_constraints sk "
                        "inner join sys.objects so  on sk.parent_object_id = so.object_id "
                        "inner join sys.indexes idx on idx.object_id = so.object_id and idx.is_primary_key = 1 "
                        "inner join sys.index_columns idxc on idxc.object_id = idx.object_id and idxc.index_id = idx.index_id "
                        "inner join sys.columns sc  on sc.object_id = so.object_id and sc.column_id = idxc.column_id "
                        "where so.type = 'U' and sk.type = 'PK' and sk.parent_object_id = so.object_id and schema_name(so.schema_id) = '" << database << "'";

                    if (tableSqlName.empty() == false)
                    {
                        requestHelper.addNewParamString(tableSqlName, String1000Type);
                        cmd << "and so.name = ? ";
                    }

                    cmd << "order by idxc.key_ordinal";

                    requestHelper.setCommand(cmd.str());

                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(tableName);
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(refAttribute);
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(objName);
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(typeDescPtr);
                    break;

                case DdlObj_ForeignKey:

                    cmd << "select so.name, fk.name, so_ref.name, sc.name, fk.delete_referential_action from sys.objects so "
                        "inner join sys.foreign_keys fk on so.object_id = fk.parent_object_id "
                        "inner join sys.objects so_ref on so_ref.object_id = fk.referenced_object_id "
                        "inner join sys.foreign_key_columns fkc on fk.object_id = fkc.constraint_object_id "
                        "inner join sys.columns sc on sc.object_id = so.object_id and sc.column_id = fkc.parent_column_id "
                        "where so.type = 'U' and schema_name(so.schema_id) = '" << database << "'";

                    if (tableSqlName.empty() == false)
                    {
                        requestHelper.addNewParamString(tableSqlName, String1000Type);
                        cmd << "and so.name = ? ";
                    }

                    requestHelper.setCommand(cmd.str());

                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(tableName);
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(objName);
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(refEntity);
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(refAttribute);
                    requestHelper.addNewOutputData(SmallintType);
                    requestHelper.getBindVariablePtr(refDeleteRule);
                    break;

                case DdlObj_ReversedForeignKey:
                    break;

                case DdlObj_SProc:
                case DdlObj_SpecSProc:
                case DdlObj_Func:
                case DdlObj_View:
                    cmd << "select so.name from sys.objects so where so.type = '" << typeStr << "' and schema_name(so.schema_id) = '" << database << "'";

                    if (ddlObjSqlName.empty() == false)
                    {
                        cmd << " and so.name='" << ddlObjSqlName << "'";
                    }
                    
                    requestHelper.setCommand(cmd.str());

                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(objName);
                    break;

                case DdlObj_Table:
                    cmd << "select so.name from sys.objects so where so.type = '" << typeStr << "' and schema_name(so.schema_id) = '" << database << "'";

                    if (tableSqlName.empty() == false)
                    {
                        cmd << " and so.name='" << tableSqlName << "'";
                    }

                    requestHelper.setCommand(cmd.str());

                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(tableName);
                    break;

                case DdlObj_Trigger:
                case DdlObj_TriggerUdField:
                    cmd << "select tb.name, tr.name from sys.objects tr inner join sys.objects tb on tr.parent_object_id = tb.object_id where tr.type = 'TR' and schema_name(tr.schema_id) = '" << database << "'";

                    if (tableSqlName.empty() == false)
                    {
                        cmd << " and tb.name='" << tableSqlName << "'";
                    }
                    else if (reqDdlObjEn == DdlObj_TriggerUdField)
                    {
                        cmd << " and tb.name like = 'ud\\_'";
                    }
                    else
                    {
                        cmd << " and tb.name not like = 'ud\\_'";
                    }
                    
                    requestHelper.setCommand(cmd.str());

                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(tableName);
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(objName);
                    break;

                default:
                    SYS_BreakOnDebug();
                    break;
            }

            if (requestHelper.sendCommandForFetch() == RET_SUCCEED)
            {
                while (requestHelper.fetch() == RET_SUCCEED)
                {
                    DdlObjDef ddlObjDef(this->ddlGenContextPtr->m_rdbmsEn,
                                        reqDdlObjEn,
                                        database,
                                        (tableName != nullptr ? tableName : string()),
                                        string(),
                                        (objName != nullptr ? objName : tableName));

                    auto it = ddlObjDefMap.insert(make_pair(ddlObjDef, ddlObjDef));

                    if (refEntity != nullptr && refEntity[0] != 0)
                    {
                        it.first->second.m_refEntity = refEntity;
                    }
                    if (refAttribute && refAttribute[0])
                    {
                        it.first->second.m_refAttributeTab.push_back(refAttribute);
                    }
                    if (refDeleteRule != nullptr)
                    {
                        if (*refDeleteRule == 1)
                        {
                            it.first->second.m_refDeleteRuleEn = RefDelRule_CascadeDelete;
                        }
                        else if (*refDeleteRule == 2)
                        {
                            it.first->second.m_refDeleteRuleEn = RefDelRule_SetNULL;
                        }
                        else
                        {
                            it.first->second.m_refDeleteRuleEn = RefDelRule_NoAction;
                        }
                    }
                    if (searchCondition != nullptr)
                    {
                        it.first->second.m_searchCondition = searchCondition;
                    }
                    if (typeDescPtr != nullptr && strcmp(typeDescPtr, "CLUSTERED") == 0)
                    {
                        it.first->second.m_isClustered = true;
                    }
                }
            }
            break;
        }

        case PostgreSQL:
        {
            char* refDeleteRule = nullptr;
            SMALLINT_T* isPrimary = nullptr;

            switch (reqDdlObjEn)
            {
                case DdlObj_Constraint:
                    requestHelper.addNewParamString(lower(database), String1000Type);
                    requestHelper.addNewParamString(lower(tableSqlName), String1000Type);

                    requestHelper.setCommand(
                        "select pc2.relname, pc.conname, pg_get_constraintdef(pc.oid) "
                        "from pg_catalog.pg_constraint pc inner join pg_catalog.pg_namespace pn on pc.connamespace = pn.oid "
                        "inner join pg_catalog.pg_class pc2 on pc2.oid = pc.conrelid "
                        "where pn.nspname = ? and pc.contype = 'c' and pc2.relname = ?");

                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(tableName);
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(objName);
                    requestHelper.addNewOutputData(TextType);
                    requestHelper.getBindVariablePtr(searchCondition);
                    break;

                case DdlObj_PrimaryKey:

                    requestHelper.addNewParamString(lower(database), String1000Type);

                    cmd << "select "
                        "pt.relname, "
                        "pa.attname "
                        "from pg_index pix inner join pg_class pt on pt.oid = pix.indrelid "
                        "inner join pg_class pi on pi.oid = pix.indexrelid "
                        "inner join pg_namespace pn on pn.oid = pt.relnamespace "
                        "inner join pg_attribute pa on pa.attrelid = pt.oid and pa.attnum = any(pix.indkey) "
                        "where pn.nspname = ? "
                        "and pt.oid = pix.indrelid "
                        "and pi.oid = pix.indexrelid "
                        "and pix.indisprimary = true "
                        "and pt.relkind = 'r'";

                    if (tableSqlName.empty() == false)
                    {
                        requestHelper.addNewParamString(lower(tableSqlName), String1000Type);
                        cmd << " and pt.relname = ?";
                    }

                    requestHelper.setCommand(cmd.str());

                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(tableName);
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(refAttribute);
                    break;

                case DdlObj_ForeignKey:
                    requestHelper.addNewParamString(lower(database), String1000Type);
                    requestHelper.addNewParamString(lower(tableSqlName), String1000Type);

                    requestHelper.setCommand(
                        "select pc2.relname, pc.conname, pc3.relname, pa.attname, pc.confdeltype "
                        "from pg_catalog.pg_constraint pc "
                        "inner join pg_catalog.pg_namespace pn on pc.connamespace = pn.oid "
                        "inner join pg_catalog.pg_class pc2 on pc2.oid = pc.conrelid "
                        "inner join pg_catalog.pg_class pc3 on pc3.oid = pc.confrelid "
                        "inner join pg_attribute pa on pa.attrelid = pc.conrelid and pa.attnum = any(pc.conkey) "
                        "where pn.nspname = ? and pc.contype = 'f' and pc2.relname = ?");

                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(tableName);
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(objName);
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(refEntity);
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(refAttribute);
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(refDeleteRule);
                    break;

                case DdlObj_ReversedForeignKey:
                    break;

                case DdlObj_SProc:
                case DdlObj_SpecSProc:
                case DdlObj_Func:

                    if (reqDdlObjEn == DdlObj_SProc || ddlObjSqlName.empty() == false)
                    {
                        requestHelper.addNewParamString(lower(database), String1000Type);

                        cmd << "select pp.proname from pg_catalog.pg_proc pp inner join pg_roles pr on pr.oid = pp.proowner "
                            "inner join pg_catalog.pg_namespace pn on pp.pronamespace = pn.oid "
                            "where pr.rolname = current_user and pn.nspname = ?";

                        if (ddlObjSqlName.empty() == false)
                        {
                            requestHelper.addNewParamString(lower(ddlObjSqlName), String1000Type);
                            cmd << " and pp.proname = ?";
                        }

                        requestHelper.setCommand(cmd.str());

                        requestHelper.addNewOutputData(LongSysnameType);
                        requestHelper.getBindVariablePtr(objName);
                    }
                    break;

                case DdlObj_View:
                    requestHelper.addNewParamString(lower(database), String1000Type);

                    cmd << "select pv.viewname from pg_catalog.pg_views pv where pv.viewowner = current_user and pv.schemaname = ?";

                    if (ddlObjSqlName.empty() == false)
                    {
                        requestHelper.addNewParamString(lower(ddlObjSqlName), String1000Type);
                        cmd << " and pv.viewname = ?";
                    }

                    requestHelper.setCommand(cmd.str());

                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(objName);
                    break;

                case DdlObj_Table:
                    requestHelper.addNewParamString(lower(database), String1000Type);

                    cmd << "select pt.tablename from pg_catalog.pg_tables pt where pt.tableowner = current_user and pt.schemaname = ?";

                    if (tableSqlName.empty() == false)
                    {
                        requestHelper.addNewParamString(lower(tableSqlName), String1000Type);
                        cmd << " and pt.tablename = ?";
                    }

                    requestHelper.setCommand(cmd.str());

                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(tableName);
                    break;

                case DdlObj_Trigger:
                case DdlObj_TriggerUdField:
                    requestHelper.addNewParamString(lower(database), String1000Type);

                    cmd << "select event_object_table, trigger_name "
                        "from information_schema.triggers "
                        "where trigger_catalog = current_catalog "
                        "and trigger_schema = ? ";

                    if (tableSqlName.empty() == false)
                    {
                        requestHelper.addNewParamString(lower(tableSqlName), String1000Type);
                        cmd << "and event_object_table = ?";
                    }
                    else if (reqDdlObjEn == DdlObj_TriggerUdField)
                    {
                        cmd << " and event_object_table like 'ud\\_'";
                    }
                    else
                    {
                        cmd << " and event_object_table not like 'ud\\_'";
                    }

                    requestHelper.setCommand(cmd.str());

                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(tableName);
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(objName);
                    break;

                case DdlObj_Index:
                    requestHelper.addNewParamString(lower(database), String1000Type);

                    cmd << "select pt.relname, pi.relname, pix.indisprimary "
                        "from pg_index pix inner join pg_class pt on pt.oid = pix.indrelid "
                        "inner join pg_class pi on pi.oid = pix.indexrelid "
                        "inner join pg_namespace pn on pn.oid = pt.relnamespace "
                        "where pn.nspname = ? "
                        "and pt.oid = pix.indrelid "
                        "and pi.oid = pix.indexrelid "
                        "and pt.relkind = 'r'";

                    if (tableSqlName.empty() == false)
                    {
                        requestHelper.addNewParamString(lower(tableSqlName), String1000Type);
                        cmd << " and pt.relname = ?";
                    }

                    requestHelper.setCommand(cmd.str());

                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(tableName);
                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(objName);
                    requestHelper.addNewOutputData(FlagType);
                    requestHelper.getBindVariablePtr(isPrimary);
                    break;

                default:
                    SYS_BreakOnDebug();
                    break;
            }

            if (requestHelper.sendCommandForFetch() == RET_SUCCEED)
            {
                while (requestHelper.fetch() == RET_SUCCEED)
                {
                    DdlObjDef ddlObjDef(this->ddlGenContextPtr->m_rdbmsEn,
                                        reqDdlObjEn,
                                        database,
                                        (tableName != nullptr ? tableName : string()),
                                        string(),
                                        (objName != nullptr ? objName : tableName));

                    auto it = ddlObjDefMap.insert(make_pair(ddlObjDef, ddlObjDef));

                    if (refEntity != nullptr && refEntity[0] != 0)
                    {
                        it.first->second.m_refEntity = refEntity;
                    }
                    if (refAttribute && refAttribute[0])
                    {
                        it.first->second.m_refAttributeTab.push_back(refAttribute);
                    }
                    if (refDeleteRule != nullptr)
                    {
                        if (strcmp(refDeleteRule, "c") == 0)
                        {
                            it.first->second.m_refDeleteRuleEn = RefDelRule_CascadeDelete;
                        }
                        else if (strcmp(refDeleteRule, "n") == 0)
                        {
                            it.first->second.m_refDeleteRuleEn = RefDelRule_SetNULL;
                        }
                        else if (strcmp(refDeleteRule, "a") == 0)
                        {
                            it.first->second.m_refDeleteRuleEn = RefDelRule_NoAction;
                        }
                        else
                        {
                            it.first->second.m_refDeleteRuleEn = RefDelRule_Restrict;
                        }
                    }
                    if (searchCondition != nullptr)
                    {
                        it.first->second.m_searchCondition = searchCondition;

                        if (it.first->second.m_searchCondition.find("CHECK ((") == 0)
                        {
                            it.first->second.m_searchCondition.erase(0, 8);

                            size_t posStart = it.first->second.m_searchCondition.find(" = ANY (ARRAY[");
                            size_t posEnd = 0;
                            if (posStart != string::npos)
                            {
                                it.first->second.m_searchCondition.replace(posStart, 14, " in (");

                                posEnd = it.first->second.m_searchCondition.find("]");
                                it.first->second.m_searchCondition.erase(posEnd, 1);
                            }
                            else if ((posStart = it.first->second.m_searchCondition.find(">= 0")) != string::npos &&
                                     (posEnd = it.first->second.m_searchCondition.find("<= ")) != string::npos)
                            {
                                it.first->second.m_searchCondition.replace(posStart, posEnd - posStart + 3, "between 0 and ");
                                it.first->second.m_searchCondition.erase(0, 1);
                                it.first->second.m_searchCondition.erase(it.first->second.m_searchCondition.length() - 1, 1);
                            }

                            it.first->second.m_searchCondition.erase(it.first->second.m_searchCondition.find("))"), 2);
                        }
                    }
                    if (isPrimary != nullptr)
                    {
                        it.first->second.m_isPrimary = (*isPrimary == 0 ? false : true);
                    }
                }
            }
            break;
        }

        case Sqlite:
        {
            this->standardize(database);
            requestHelper.useDb(database);

            requestHelper.setDbNameOption(tableSqlName);

            switch (reqDdlObjEn)
            {
                case DdlObj_Constraint:
                    break;

                case DdlObj_PrimaryKey:
                    break;

                case DdlObj_ForeignKey:
                    break;

                case DdlObj_ReversedForeignKey:
                    break;

                case DdlObj_SProc:
                case DdlObj_SpecSProc:
                case DdlObj_Func:
                    break;

                case DdlObj_View:

                    cmd << "select tbl_name from sqlite_master where type='view'";

                    if (ddlObjSqlName.empty() == false)
                    {
                        requestHelper.addNewParamString(lower(ddlObjSqlName), String1000Type);
                        cmd << " and name = ?";
                    }

                    requestHelper.setCommand(cmd.str());

                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(objName);
                    break;

                case DdlObj_Table:

                    cmd << "select tbl_name from sqlite_master where type='table'";

                    if (tableSqlName.empty() == false)
                    {
                        requestHelper.addNewParamString(lower(tableSqlName), String1000Type);
                        cmd << " and tbl_name = ?";
                    }

                    requestHelper.setCommand(cmd.str());

                    requestHelper.addNewOutputData(LongSysnameType);
                    requestHelper.getBindVariablePtr(tableName);
                    break;

                case DdlObj_Trigger:
                case DdlObj_TriggerUdField:
                    break;

                case DdlObj_Index:
                    break;

                default:
                    SYS_BreakOnDebug();
                    break;
            }

            if (requestHelper.sendCommandForFetch() == RET_SUCCEED)
            {
                while (requestHelper.fetch() == RET_SUCCEED)
                {
                    DdlObjDef ddlObjDef(this->ddlGenContextPtr->m_rdbmsEn,
                                        reqDdlObjEn,
                                        database,
                                        (tableName != nullptr ? tableName : string()),
                                        string(),
                                        (objName != nullptr ? objName : tableName));

                    auto it = ddlObjDefMap.insert(make_pair(ddlObjDef, ddlObjDef));

                    if (refEntity != nullptr && refEntity[0] != 0)
                    {
                        it.first->second.m_refEntity = refEntity;
                    }
                    if (refAttribute && refAttribute[0])
                    {
                        it.first->second.m_refAttributeTab.push_back(refAttribute);
                    }
                }
            }
            break;
        }

        default:
            SYS_BreakOnDebug();

    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getIndexSqlName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-25954 - LJE - 170131
**
*************************************************************************/
void DdlGenDbi::getIndexSqlName(DBA_DYNFLD_STP xdAttribStp, std::string& sqlName, std::string& colExpr, DdlGenContext* ddlGenContextPtr)
{
    sqlName = GET_SYSNAME(xdAttribStp, A_XdAttrib_SqlName);

    switch (ddlGenContextPtr->m_rdbmsEn)
    {
        case Oracle:
            if (GET_FLAG(xdAttribStp, A_XdAttrib_DbMandatoryFlg) == FALSE)
            {
                colExpr = "SYS_OP_MAP_NONNULL(" + sqlName + ")";
                sqlName.clear();
            }
            break;

        default:
            break;
    }
}

/************************************************************************
**
**  Function    :   DdlGenDbi::getDefaultConstrName()
**
**  Description :   Get the Default constraint name for Sql Server.
**
**  Arguments   :   schema name, table name, column name
**
**  Return      :   Default constraint name.
**
**  Creation  	:   PMSTA-40978 - PRAJIN - 201104
**
*************************************************************************/
string DdlGenDbi::getDefaultConstrName(std::string     database,
                                       std::string     tableSqlName,
                                       std::string     attribSqlName)
{
    stringstream    ddlObjText;
    stringstream    cmd;

    switch (this->ddlGenContextPtr->m_rdbmsEn)
    {
        case MSSql:
        {
            cmd << "select dc.name from sys.default_constraints dc,sys.objects so,sys.schemas sch, sys.columns co where "
                << "dc.parent_object_id = so.object_id and so.schema_id = sch.schema_id and co.object_id = so.object_id and "
                << "co.column_id = dc.parent_column_id and so.name = '" << tableSqlName << "' and co.name = '"
                << attribSqlName << "' and sch.name = '" << database << "'";
            break;
        }
    }
    if (cmd.str().empty() == false)
    {
        DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);
        RequestHelper requestHelper(&ddlGenConnGuard.getDbiConn());
        requestHelper.setReadOnly(true);

        char* objName = nullptr;

        requestHelper.useDb(database);
        requestHelper.setCommand(cmd.str());
        requestHelper.addNewOutputData(LongSysnameType);
        requestHelper.getBindVariablePtr(objName);

        if (requestHelper.sendCommandForFetch() == RET_SUCCEED)
        {
            while (requestHelper.fetch() == RET_SUCCEED)
            {

                if (objName != nullptr)
                {
                    ddlObjText << objName;
                }
            }
        }
        else
        {
            char buffer[100];
            sprintf(buffer, "Unable to get Default Constraint (attribute %s) for table: %s", attribSqlName.c_str(), tableSqlName.c_str());
            MSG_DispMsgText(RET_SUCCEED, buffer);
            return string();
        }
    }

    return ddlObjText.str();
}

/*************************************************************************
**   END  ddlgendbi.cpp                                         Odyssey **
*************************************************************************/

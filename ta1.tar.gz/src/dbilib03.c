/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DBILIB03_C

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H

#include "unidef.h"
#include "gen.h"
#include "dba.h"
#include "oralib.h"
#include "syb.h"
#ifdef NUODB_ENABLE
    #include "nuodblib.h"
#endif
#ifdef MSDB_ENABLE
    #include "msdblib.h"
#endif
#ifdef POSTGRESQL_ENABLE
#include "pgslib.h"
#endif

#include "dbiconnection.h"
#include "conprovider.h"

#ifdef NT
#include <crtdbg.h>
#endif

extern DBA_RDBMS_ENUM EV_RdbmsVendor;

/************************************************************************
**  Function    :   DBI_InsApplUserDbLogin
**
**  Description :   Create a new user in database.
**
**  Arguments   :   object        The user to check.
**  		    	inputSt 	  A_ApplUser.
**                  inputData     A_ApplUser data.
**                  connectNo     Not used.
**                  msgStructPtr  Kind of error message.
**
**  Return      :   RET_SUCCEED                      If the user is DBO or SSO.
**                  RET_DBA_ERR_PASSWD_TOO_SHORT     If less than 6 characters.
**                  RET_GEN_ERR_INVARG               If no input data provided.
*************************************************************************/
RET_CODE DBI_InsApplUserDbLogin(DBA_DYNFLD_STP       inputData,
                             DbiConnection&       dbiConn)
{
    RET_CODE       retCode = RET_SUCCEED;

    /* Check arguments */
    if (inputData == NULL)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "SYB_InsApplUserById", "inputData");
        return(RET_GEN_ERR_INVARG);
    }

    switch (dbiConn.m_connectToRDBMS)
    {
        case Sybase:
            retCode = SYB_InsApplUserById(inputData, dbiConn);
            break;
        case Oracle:
            retCode = ORA_InsApplUserById(inputData, dbiConn);
            break;
#ifdef NUODB_ENABLE
        case Nuodb:
            retCode = NUODB_InsApplUserById(inputData, dbiConn);
            break;
#endif
#ifdef MSDB_ENABLE
        case MSSql:
            retCode = MSSQL_InsApplUserById(inputData, dbiConn);
            break;
#endif
#ifdef POSTGRESQL_ENABLE
        case PostgreSQL:
            retCode = PGS_InsApplUserById(inputData, dbiConn);
            break;
#endif
    }

    return retCode;
}


/************************************************************************
**  Function    :   DBI_InsApplUserById
**
**  Description :   Create a new user.
**
**  Arguments   :   object        The user to check.
**  		    	inputSt 	  A_ApplUser.
**                  inputData     A_ApplUser data.
**                  connectNo     Not used.
**                  msgStructPtr  Kind of error message.
**
**  Return      :   RET_SUCCEED                      If the user is DBO or SSO.
**                  RET_DBA_ERR_PASSWD_TOO_SHORT     If less than 6 characters.
**                  RET_GEN_ERR_INVARG               If no input data provided.
*************************************************************************/
RET_CODE DBI_InsApplUserById(DBA_DYNFLD_STP       inputData,
                             DbiConnection&       dbiConn)
{
    RET_CODE       retCode = RET_SUCCEED;

    /* Check arguments */
    if (inputData == NULL)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "SYB_InsApplUserById", "inputData");
        return(RET_GEN_ERR_INVARG);
    }

    MemoryPool mp;
    FLAG_T     lockActionFlg     = FALSE;
    FLAG_T     validityActionFlg = FALSE;
    FLAG_T     hasDbLoginFlg     = TRUE;

    if (IS_NULLFLD(inputData, A_ApplUser_LockActionFlg) == FALSE)
    {
        lockActionFlg = GET_FLAG(inputData, A_ApplUser_LockActionFlg);
    }

    if (IS_NULLFLD(inputData, A_ApplUser_ValidityActionFlg) == FALSE)
    {
        validityActionFlg = GET_FLAG(inputData, A_ApplUser_ValidityActionFlg);
    }

    /* PMSTA-43740 - LJE - 210219 */
    if (IS_NULLFLD(inputData, A_ApplUser_HasDbLoginFlg) == FALSE)
    {
        hasDbLoginFlg = GET_FLAG(inputData, A_ApplUser_HasDbLoginFlg);
    }

    retCode = DBI_InsApplUserDbLogin(inputData, dbiConn);

    if (retCode == RET_SUCCEED)
    {
        /* ins_appl_user_by_id */
        retCode = DBA_Insert2(ApplUser, DBA_ROLE_FORCE_STORED_PROC, A_ApplUser, inputData, DBA_SET_CONN | DBA_NO_CLOSE, dbiConn);

        /* upd_appl_user_active_f */
        if (retCode == RET_SUCCEED && TRUE == lockActionFlg)
            retCode = DBA_Update2(ApplUser, DBA_ROLE_UPD_ACTIVE_F, A_ApplUser, inputData, DBA_SET_CONN | DBA_NO_CLOSE, dbiConn);

        /* upd_appl_user_validity_d */
        if (retCode == RET_SUCCEED && TRUE == validityActionFlg)
            retCode = DBA_Update2(ApplUser, DBA_ROLE_UPD_VALIDITY_D, A_ApplUser, inputData, DBA_SET_CONN | DBA_NO_CLOSE, dbiConn);
    }

    /***** UPDATE THE PASSWORD if necessary     *****/
    if ((retCode == RET_SUCCEED) &&
        hasDbLoginFlg == FALSE &&
        (IS_NULLFLD(inputData, A_ApplUser_EncryptedPassword) == FALSE))
    {
        DbiConnectionHelper dbiConnHelper(&dbiConn);
        DBA_DYNFLD_STP      userPwdStp = mp.allocDynst(FILEINFO, A_ApplUserPassword);

        SET_ID(userPwdStp, A_ApplUserPassword_UserId, GET_ID(inputData, A_ApplUser_Id));
        SET_INFO(userPwdStp, A_ApplUserPassword_CryptedPassword, GET_INFO(inputData, A_ApplUser_EncryptedPassword));
        SET_ID(userPwdStp, A_ApplUserPassword_DataSecuProfId, GET_ID(inputData, A_ApplUser_DataSecuProfId));
        SET_ID(userPwdStp, A_ApplUserPassword_DataSecuProf2Id, GET_ID(inputData, A_ApplUser_DataSecuProf2Id));

        retCode = dbiConnHelper.dbaUpdate(ApplUserPassword, DBA_ROLE_UPD_PASSWD, userPwdStp);
    }

    /* WEALTH-6877 - n.sathish - 20240419 */
    if (retCode == RET_SUCCEED)
    {
        /* WEALTH-7602 - FME- 20240527 */
        AAALogger::get(AAALogger::Logger::UserAccess).prepareInfoT("Create User '{username}' successful", GET_CODE(inputData, A_ApplUser_Cd))->tag("temn.log.type", "SIEM")->log();
    }

    return retCode;
}

/************************************************************************
**  Function    :   DBI_UpdApplUser
**
**  Description :   Update a user.
**
**  Arguments   :   object        The user to check.
**  		    	inputSt 	  A_ApplUser.
**                  inputData     A_ApplUser data.
**                  connectNo     Not used.
**                  msgStructPtr  Kind of error message.
**
**  Return      :   RET_SUCCEED                      If the user is DBO or SSO.
**                  RET_DBA_ERR_PASSWD_TOO_SHORT     If less than 6 characters.
**                  RET_GEN_ERR_INVARG               If no input data provided.
*************************************************************************/
RET_CODE DBI_UpdApplUser(DBA_DYNFLD_STP       inputData,
						 DbiConnection&       dbiConn)
{
    RET_CODE       retCode = RET_SUCCEED;

    /* Check arguments */
    if (inputData == NULL)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBI_UpdApplUser", "inputData");
        return(RET_GEN_ERR_INVARG);
    }

    MemoryPool mp;
    SYBASE_LOGIN_ACTION_ENUM loginActionEn = LoginActionEn_Nothing;
    FLAG_T lockActionFlg                   = FALSE;
    FLAG_T validityActionFlg               = FALSE;
    FLAG_T hasDbLoginFlg                   = TRUE;

    if (IS_NULLFLD(inputData, A_ApplUser_LoginActionEn) == FALSE)
        loginActionEn = (SYBASE_LOGIN_ACTION_ENUM)GET_ENUM(inputData, A_ApplUser_LoginActionEn);
    if (IS_NULLFLD(inputData, A_ApplUser_LockActionFlg) == FALSE)
        lockActionFlg = GET_FLAG(inputData, A_ApplUser_LockActionFlg);
    if (IS_NULLFLD(inputData, A_ApplUser_ValidityActionFlg) == FALSE)
        validityActionFlg = GET_FLAG(inputData, A_ApplUser_ValidityActionFlg);

    /* PMSTA-43740 - LJE - 210219 */
    if (IS_NULLFLD(inputData, A_ApplUser_HasDbLoginFlg) == FALSE)
    {
        hasDbLoginFlg = GET_FLAG(inputData, A_ApplUser_HasDbLoginFlg);
    }
    
    if (LoginActionEn_Nothing != loginActionEn || FALSE != lockActionFlg)
    {
        retCode = DBI_InsApplUserDbLogin(inputData, dbiConn);
    }

    if (retCode == RET_SUCCEED)
    {
        /* upd_appl_user */
        retCode = DBA_Update2(ApplUser, DBA_ROLE_FORCE_STORED_PROC, A_ApplUser, inputData, DBA_SET_CONN | DBA_NO_CLOSE, dbiConn);

        /* upd_appl_user_active_f */
        if (retCode == RET_SUCCEED && TRUE == lockActionFlg)
            retCode = DBA_Update2(ApplUser, DBA_ROLE_UPD_ACTIVE_F, A_ApplUser, inputData, DBA_SET_CONN | DBA_NO_CLOSE, dbiConn);

        /* upd_appl_user_validity_d */
        if (retCode == RET_SUCCEED && TRUE == validityActionFlg)
            retCode = DBA_Update2(ApplUser, DBA_ROLE_UPD_VALIDITY_D, A_ApplUser, inputData, DBA_SET_CONN | DBA_NO_CLOSE, dbiConn);
    }

    /***** UPDATE THE PASSWORD if necessary     *****/
    if ((retCode == RET_SUCCEED) &&
        hasDbLoginFlg == FALSE &&
        (IS_NULLFLD(inputData, A_ApplUser_EncryptedPassword) == FALSE))
    {
        DbiConnectionHelper dbiConnHelper(&dbiConn);
        DBA_DYNFLD_STP      userPwdStp = mp.allocDynst(FILEINFO, A_ApplUserPassword);

        SET_ID(userPwdStp, A_ApplUserPassword_UserId, GET_ID(inputData, A_ApplUser_Id));
        SET_INFO(userPwdStp, A_ApplUserPassword_CryptedPassword, GET_INFO(inputData, A_ApplUser_EncryptedPassword));
        SET_ID(userPwdStp, A_ApplUserPassword_DataSecuProfId, GET_ID(inputData, A_ApplUser_DataSecuProfId));
        SET_ID(userPwdStp, A_ApplUserPassword_DataSecuProf2Id, GET_ID(inputData, A_ApplUser_DataSecuProf2Id));

        retCode = dbiConnHelper.dbaUpdate(ApplUserPassword, DBA_ROLE_UPD_PASSWD, userPwdStp);
    }

    return retCode;
}

/************************************************************************
**
**  Function    :    DBI_CheckMinPasswdLength()
**
**  Description :    Verify the minimum length of the user password.
**
**  Arguments   :    userPasswd      The password to verify.
**
**  Return      :    RET_SUCCEED     If the password have min length
**                   RET_DBA_ERR_PASSWD_TOO_SHORT      otherwise.
**
**  Creation    :    PMSTA-52601 - KOR - 2023-06-02
* *
*************************************************************************/
RET_CODE DBI_CheckMinPasswdLength(char*          userPasswd,
                                  DbiConnection& dbiConn)
{
    RET_CODE ret = RET_SUCCEED;
    bool     traditionalDBFlg = TRUE;

#ifdef MSDB_ENABLE
    if (dbiConn.getDbaRDBMS() == MSSql)
    {
        char*    envVar;
        /* Get preferred data model */
        MSSQL_getPrefDBUserModel(dbiConn);

        if ((envVar = SYS_GetEnv("USE_TRADITIONAL_USER_MODEL")) != NULL)
        {
            traditionalDBFlg = atoi(envVar);
        }
    }
#endif

    /* Test if password is long enough */
    if (userPasswd == NULL ||
        (traditionalDBFlg == FALSE && SYS_StrLen(userPasswd) < 8) ||
        (traditionalDBFlg == TRUE && SYS_StrLen(userPasswd) < 6))
        {
            auto &msgStructSt = dbiConn.m_msgStructHeaderSt.getNewErrMsgInfoSt(FILEINFO);
            msgStructSt.msgString = "The password entered is too short.";
            msgStructSt.techMsg = FALSE;

            ret = RET_DBA_ERR_PASSWD_TOO_SHORT;
        }

    return ret;
}

/************************************************************************
**
**  Function    :   DBI_ChangePasswd()
**
**  Description :   Change the password of the given user.
**
**  Arguments   :   adminUser
**      		    adminPasswd
**  	    	    userCode
**  		        newPasswd
**
**  Return      :   RET_SUCCEED
**                  RET_GEN_ERR_INVARG               If no good parameters.
**                  RET_DBA_ERR_PASSWD_TOO_SHORT     If less than 6 characters.
**
**  Creation    :   PMSTA-18593 - LJE - 150922
**
**  Modif.      :   PMSTA-21596 - DLA - 160518
**                  PMSTA-52601 - KOR - 2023-06-02 - Verify the minimum length of the user password.
**
*************************************************************************/
RET_CODE DBI_ChangePasswd(SYSNAME_T          adminUser,
                          PasswordEncrypted& adminPasswd,
                          SYSNAME_T          userCode,
                          PasswordEncrypted& newPasswd)
{
    RET_CODE              ret = RET_SUCCEED;
    DbiConnection *       dbiConn = nullptr;
    PasswordClear         newClearPasswd = newPasswd.getClearPassword();
    char*                 newClearPasswdStr = const_cast<char *>(newClearPasswd.getPassword());

    try
    {
        if (strcmp(adminUser, userCode) == 0)
        {
            ret = DBA_OpenConnForUser(adminUser, adminPasswd, &dbiConn, ROLE_USER);
            if (ret == RET_SUCCEED)
            {
                ret = DBI_CheckMinPasswdLength(newClearPasswdStr, *dbiConn);
                if (ret == RET_SUCCEED)
                {
                    if (AAALocalConnectionProvider::get().changePassword(*dbiConn, newPasswd) == false)
                    {
                        ret = RET_GEN_ERR_NOACTION;
                    }
                }
            }
        }
        else
        {
            ret = DBA_OpenConnForUser(adminUser, adminPasswd, &dbiConn, ROLE_DBSO);
            if (ret == RET_SUCCEED)
            {
                ret = DBI_CheckMinPasswdLength(newClearPasswdStr, *dbiConn);
                if (ret == RET_SUCCEED)
                {
                    if (AAALocalConnectionProvider::get().changePassword(*dbiConn, userCode, newPasswd) == false)
                    {
                        ret = RET_GEN_ERR_NOACTION;
                    }
                }
            }
        }
    }
    catch (std::exception &e)
    {
        MSG_SendMesg(FILEINFO,
                     SYS_Stringer("Unable to update the user password for user ",
                                  userCode,
                                  ", caused by: ",
                                  e.what()));
    }

    if (dbiConn != nullptr)
    {
        DBA_EndConnection(&dbiConn);
    }

    return ret;
}


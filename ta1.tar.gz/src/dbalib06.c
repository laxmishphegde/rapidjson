/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DBALIB06_C

/************************************************************************
**      Include files
*************************************************************************/
#ifdef NTWIN
#pragma warning (push)
#endif

#include "unidef.h"
#include "scptyl.h"
#include "conv.h"
#include "fmtorder.h"
#include "dbiconnection.h"

#ifdef NTWIN
#pragma warning (pop)
#endif

/************************************************************************
**      Functions Description
**
**      DBA_ParseATTLine
**      DBA_ProcessFields
**      DBA_ProcessEntities
**
**      SubFunctions
**
**      DBA_ParseField
**      DBA_DiscardFields
**      DBA_DiscardValues
**      DBA_DiscardCopies
**      DBA_DiscardEntities
**      DBA_ParseAttribute
**      DBA_GetChildEntity
**      DBA_AddChildEntity
**      DBA_CheckEntitiesChildSkip
**      DBA_ComputeDV
**      DBA_ComputeIC
**      DBA_CheckIC
**      DBA_CleanIC
**      DBA_GetSpaced
**      DBA_GetDelimited
**      DBA_GetFixed
**      DBA_GetDate
**      DBA_GetString
**      DBA_CheckSecuCheck
**
*************************************************************************/

/************************************************************************
**      Static definitions & data
*************************************************************************/
typedef struct DBA_ENTITY_ST* DBA_ENTITY_STP;
typedef struct DBA_ENTITY_ST
{
    DBA_ENTITY_STP     parent;
    int                index;  /* PMSTA08801 - DDV - 091126 */
    DBA_ENTITY_STP     next;
    DBA_ENTITY_STP     child;
    OBJECT_ENUM         object;
    FLAG_T              main;
    FLAG_T              skip;
    DBA_DYNFLD_STP      record;
} DBA_ENTITY_ST;



typedef struct DBA_FIELD_ST* DBA_FIELD_STP;
typedef struct DBA_FIELD_ST
{
    DBA_ENTITY_STP     entity;
    int                 index;  /* PMSTA08801 - DDV - 091126 */
    DATATYPE_ENUM       type;
    DICTATTRIBWGT_ENUM  time_e;
    int                 width;
    FLAG_T			    evalDV;
    DBA_FIELD_STP      next;
} DBA_FIELD_ST;




typedef struct DBA_COPY_ST* DBA_COPY_STP;
typedef struct DBA_COPY_ST
{
    DICT_T          id;
    OBJECT_ENUM object;
    DBA_COPY_STP next;
} DBA_COPY_ST;



typedef struct DBA_VALUE_ST* DBA_VALUE_STP;
typedef struct DBA_VALUE_ST
{
    DBA_ENTITY_STP entity;
    int            index; /* PMSTA08801 - DDV - 091126 */
    DATATYPE_ENUM   type;
    FLAG_T          null;
    union
    {
        ID_T        number; /* PMSTA08801 - DDV - 091126 */
        char* string;
        DATETIME_ST date;
    } value;
    DBA_VALUE_STP  next;
} DBA_VALUE_ST;


typedef struct DBA_CELL_ST* DBA_CELL_STP;
typedef struct DBA_CELL_ST
{
    DBA_ENTITY_STP    entity;
    int               index; /* PMSTA08801 - DDV - 091126 */
    DATATYPE_ENUM        type;
    DICTATTRIBWGT_ENUM time_e;
} DBA_CELL_ST;


typedef struct DBA_MESSAGE_ST* DBA_MESSAGE_STP;
typedef struct DBA_MESSAGE_ST
{
    DBA_DYNFLD_STP* vector;
    int               size;
} DBA_MESSAGE_ST;


typedef enum
{
    SpacedData,
    DelimitedData,
    FixedData,
    CountOfData
} DBA_DATA_ENUM;


typedef enum
{
    DMYDate,
    MDYDate,
    YMDDate,

    SDMYDate,
    SMDYDate,
    SYMDDate,

    CDMYDate,
    CMDYDate,
    CYMDDate,

    SCDMYDate,
    SCMDYDate,
    SCYMDDate,

    ADMYDate,
    AMDYDate,
    AYMDDate,

    SADMYDate,
    SAMDYDate,
    SAYMDDate,

    CADMYDate,
    CAMDYDate,
    CAYMDDate,

    SCADMYDate,
    SCAMDYDate,
    SCAYMDDate,

    DMYHDate,
    MDYHDate,
    YMDHDate,

    SDMYHDate,
    SMDYHDate,
    SYMDHDate,

    CDMYHDate,
    CMDYHDate,
    CYMDHDate,

    SCDMYHDate,
    SCMDYHDate,
    SCYMDHDate,

    ADMYHDate,
    AMDYHDate,
    AYMDHDate,

    SADMYHDate,
    SAMDYHDate,
    SAYMDHDate,

    CADMYHDate,
    CAMDYHDate,
    CAYMDHDate,

    SCADMYHDate,
    SCAMDYHDate,
    SCAYMDHDate,

    CountOfDate
} DBA_DATE_ENUM;



typedef struct DBA_CODIFICATION_ST* DBA_CODIFICATION_STP;
typedef struct DBA_CODIFICATION_ST
{
    OBJECT_ENUM         object;
    ID_T                    id;
    DBA_CODIFICATION_STP next;
} DBA_CODIFICATION_ST;



typedef struct DBA_AUTOMATIC_ST* DBA_AUTOMATIC_STP;
typedef struct DBA_AUTOMATIC_ST
{
    OBJECT_ENUM      object;
    FLAG_T           enable;
    DBA_AUTOMATIC_STP next;
} DBA_AUTOMATIC_ST;


typedef enum
{
    No_Action,
    InsertAction,
    UpdateAction,
    InsUpdAction,
    UpdInsAction,
    Delete_Action,
    Modify_Action,
    Copy_Action,
    UpdStatAction,
    CountOfAction
} DBA_ACTION_TYPE_ENUM;



typedef enum
{
    DV,
    IC
} DBA_HANDLER_ENUM;


typedef struct DBA_HANDLER_ST* DBA_HANDLER_STP;
typedef struct DBA_HANDLER_ST
{
    SCPT_DFLTVAL_STP  dvHandle;
    SCPT_ARG_STP      icHandle;
    DBA_HANDLER_STP   next;
    time_t            stamp;	/* PMSTA-9107 - 141209 - PMO */
    int               count;
    OBJECT_ENUM       object;
    DBA_HANDLER_ENUM nature;
} DBA_HANDLER_ST;


typedef unsigned char(*DBA_TRANSLATIONS_T)[256];



static struct
{
    const char* keyword;
    DBA_DATE_ENUM  date;
    const char* format;
}


SV_Date[] =
{
    { "DDMMYY", DMYDate, "DDMMYY" },
    { "MMDDYY", MDYDate, "MMDDYY" },
    { "YYMMDD", YMDDate, "YYMMDD" },

    { "DD-MM-YY", SDMYDate, "DD-MM-YY" },
    { "MM-DD-YY", SMDYDate, "MM-DD-YY" },
    { "YY-MM-DD", SYMDDate, "YY-MM-DD" },

    { "DDMMYYYY", CDMYDate, "DDMMYYYY" },
    { "MMDDYYYY", CMDYDate, "MMDDYYYY" },
    { "YYYYMMDD", CYMDDate, "YYYYMMDD" },

    { "DD-MM-YYYY", SCDMYDate, "DD-MM-YYYY" },
    { "MM-DD-YYYY", SCMDYDate, "MM-DD-YYYY" },
    { "YYYY-MM-DD", SCYMDDate, "YYYY-MM-DD" },

    { "DDMMMYY", ADMYDate, "DDMMMYY" },
    { "MMMDDYY", AMDYDate, "MMMDDYY" },
    { "YYMMMDD", AYMDDate, "YYMMMDD" },

    { "DD-MMM-YY", SADMYDate, "DD-MMM-YY" },
    { "MMM-DD-YY", SAMDYDate, "MMM-DD-YY" },
    { "YY-MMM-DD", SAYMDDate, "YY-MMM-DD" },

    { "DDMMMYYYY", CADMYDate, "DDMMMYYYY" },
    { "MMMDDYYYY", CAMDYDate, "MMMDDYYYY" },
    { "YYYYMMMDD", CAYMDDate, "YYYYMMMDD" },

    { "DD-MMM-YYYY", SCADMYDate, "DD-MMM-YYYY" },
    { "MMM-DD-YYYY", SCAMDYDate, "MMM-DD-YYYY" },
    { "YYYY-MMM-DD", SCAYMDDate, "YYYY-MMM-DD" },

    { "DMY", SDMYDate, "DD-MM-YY" },
    { "MDY", SMDYDate, "MM-DD-YY" },
    { "YMD", SYMDDate, "YY-MM-DD" },

    { "DDMMYY:HH:II:SS", DMYHDate, "DDMMYY:HH:II:SS" },
    { "MMDDYY:HH:II:SS", MDYHDate, "MMDDYY:HH:II:SS" },
    { "YYMMDD:HH:II:SS", YMDHDate, "YYMMDD:HH:II:SS" },

    { "DD-MM-YY:HH:II:SS", SDMYHDate, "DD-MM-YY:HH:II:SS" },
    { "MM-DD-YY:HH:II:SS", SMDYHDate, "MM-DD-YY:HH:II:SS" },
    { "YY-MM-DD:HH:II:SS", SYMDHDate, "YY-MM-DD:HH:II:SS" },

    { "DDMMYYYY:HH:II:SS", CDMYHDate, "DDMMYYYY:HH:II:SS" },
    { "MMDDYYYY:HH:II:SS", CMDYHDate, "MMDDYYYY:HH:II:SS" },
    { "YYYYMMDD:HH:II:SS", CYMDHDate, "YYYYMMDD:HH:II:SS" },

    { "DD-MM-YYYY:HH:II:SS", SCDMYHDate, "DD-MM-YYYY:HH:II:SS" },
    { "MM-DD-YYYY:HH:II:SS", SCMDYHDate, "MM-DD-YYYY:HH:II:SS" },
    { "YYYY-MM-DD:HH:II:SS", SCYMDHDate, "YYYY-MM-DD:HH:II:SS" },

    { "DDMMMYY:HH:II:SS", ADMYHDate, "DDMMMYY:HH:II:SS" },
    { "MMMDDYY:HH:II:SS", AMDYHDate, "MMMDDYY:HH:II:SS" },
    { "YYMMMDD:HH:II:SS", AYMDHDate, "YYMMMDD:HH:II:SS" },

    { "DD-MMM-YY:HH:II:SS", SADMYHDate, "DD-MMM-YY:HH:II:SS" },
    { "MMM-DD-YY:HH:II:SS", SAMDYHDate, "MMM-DD-YY:HH:II:SS" },
    { "YY-MMM-DD:HH:II:SS", SAYMDHDate, "YY-MMM-DD:HH:II:SS" },

    { "DDMMMYYYY:HH:II:SS", CADMYHDate, "DDMMMYYYY:HH:II:SS" },
    { "MMMDDYYYY:HH:II:SS", CAMDYHDate, "MMMDDYYYY:HH:II:SS" },
    { "YYYYMMMDD:HH:II:SS", CAYMDHDate, "YYYYMMMDD:HH:II:SS" },

    { "DD-MMM-YYYY:HH:II:SS", SCADMYHDate, "DD-MMM-YYYY:HH:II:SS" },
    { "MMM-DD-YYYY:HH:II:SS", SCAMDYHDate, "MMM-DD-YYYY:HH:II:SS" },
    { "YYYY-MMM-DD:HH:II:SS", SCAYMDHDate, "YYYY-MMM-DD:HH:II:SS" },

    { "DMYH", SDMYHDate, "DD-MM-YY:HH:II:SS" },
    { "MDYH", SMDYHDate, "MM-DD-YY:HH:II:SS" },
    { "YMDH", SYMDHDate, "YY-MM-DD:HH:II:SS" }
};



typedef struct
{
    DBA_DATA_ENUM           data;
    DBA_DATE_ENUM           date;
    char                    quote;
    char                    escape;
    char                    separator;
    char                    decimal;
    char                    thousand;
    DBA_TRANSLATIONS_T      translations;
    DBA_CODIFICATION_STP    codifications;
    DBA_AUTOMATIC_STP       automatics;
    DBA_ACTION_TYPE_ENUM    action;
    OBJECT_ENUM             object;
    DBA_FIELD_STP           fields;
    DBA_VALUE_STP           values;
    DBA_COPY_STP            copies;
    DBA_ENTITY_STP          source;
    DBA_ENTITY_STP          target;
    DBA_HANDLER_STP         handlers;
    FLAG_T* sf;
    FLAG_T* tf;
} DBA_STATE_ST, * DBA_STATE_STP;





static DBA_STATE_ST    SV_State;
static int              SV_Code;

#define DBA_GetAttributeByLIndex(object, index) ((DICT_ATTRIB_STP)DBA_GetDictAttribSt((object), (index)))

#define DBA_GetAttributeBySIndex(object, index) ((DICT_ATTRIB_STP)DBA_GetDictAttribStByShortIdx((object), (index)))

#define MAXHANDLE 24

#define STRDUP(x) strcpy((char *)CALLOC(1, strlen(x) + 1), x)


/************************************************************************
**
**  Function    :   DBA_GetChildEntity()
**
**  Description :
**
**  Argument    :   entity
**                  index
**
**  Return      :   pointer to entity on success, NULL elsewhere
**
*************************************************************************/
STATIC DBA_ENTITY_STP DBA_GetChildEntity(DBA_ENTITY_STP entity, int index) /* PMSTA08801 - DDV - 091126 */
{
    DBA_ENTITY_STP child = entity->child;

    while (child && child->index != index)
        child = child->next;

    return child;
}


/************************************************************************
**
**  Function    :   DBA_DiscardEntities()
**
**  Description :
**
**  Argument    :   entities
**
*************************************************************************/
STATIC void DBA_DiscardEntities(DBA_ENTITY_STP* entities)
{
    while (*entities != NULL)
    {
        DBA_ENTITY_STP next = (*entities)->next;

        DBA_DiscardEntities(&(*entities)->child);

        FREE_DYNST((*entities)->record, (*entities)->parent == NULL ?
                   GET_EDITGUIST((*entities)->object) :
                   GET_ADMINGUIST((*entities)->object));

        FREE(*entities);
        *entities = next;
    }
}



/************************************************************************
**
**  Function    :   DBA_DiscardCopies()
**
**  Description :
**
**  Argument    :   Copies
**
*************************************************************************/
STATIC void DBA_DiscardCopies(DBA_COPY_STP* copies)
{
    while (*copies != NULL)
    {
        DBA_COPY_STP next = (*copies)->next;

        FREE(*copies);
        *copies = next;
    }
}


/************************************************************************
**
**  Function    :   DBA_DiscardValues()
**
**  Description :
**
**  Argument    :   values
**
*************************************************************************/
STATIC void DBA_DiscardValues(DBA_VALUE_STP* values)
{
    while (*values != NULL)
    {
        DBA_VALUE_STP next = (*values)->next;

        if (GET_CTYPE((*values)->type) == CharPtrCType ||
            GET_CTYPE((*values)->type) == TextPtrCType)
            FREE((*values)->value.string);

        FREE(*values);
        *values = next;
    }
}



/************************************************************************
**
**  Function    :   DBA_DiscardFields()
**
**  Description :
**
**  Argument    :   fields
**
*************************************************************************/
STATIC void DBA_DiscardFields(DBA_FIELD_STP* fields)
{
    while (*fields != NULL)
    {
        DBA_FIELD_STP next = (*fields)->next;

        FREE(*fields);
        *fields = next;
    }
}



/************************************************************************
**
**  Function    :   DBA_AddChildEntity()
**
**  Description :
**
**  Argument    :   entity
**                  index
**
**  Return      :   pointer to entity on success, NULL elsewhere
**
*************************************************************************/
STATIC DBA_ENTITY_STP DBA_AddChildEntity(DBA_ENTITY_STP entity, int index) /* PMSTA08801 - DDV - 091126 */
{
    DBA_ENTITY_STP child, * cursorChild = &entity->child;

    OBJECT_ENUM object;

    char* scan = strrstr(entity->parent == NULL ?
                         DBA_GetAttributeByLIndex(entity->object, index)->sqlName :
                         DBA_GetAttributeBySIndex(entity->object, index)->sqlName,
                         "object_id");

    /* Allocating Child Entity */
    child = (DBA_ENTITY_STP)REALLOC(NULL, sizeof(DBA_ENTITY_ST));

    /* Initializing Child Entity */
    if (scan == NULL || scan[9])
    {
        DBA_GetObjectEnum(entity->parent == NULL ?
                          DBA_GetAttributeByLIndex(entity->object, index)->refEntDictId :
                          DBA_GetAttributeBySIndex(entity->object, index)->refEntDictId,
                          &object);
    }
    else
        object = SV_State.object;

    child->parent = entity;
    child->index = index;
    child->next = NULL;
    child->child = NULL;
    child->main = TRUE;
    child->skip = FALSE;
    child->object = object;
    child->record = ALLOC_DYNST(GET_ADMINGUIST(object));

    /* Appending Child Entity to Child List */
    while (*cursorChild)
        cursorChild = &(*cursorChild)->next;

    *cursorChild = child;

    /* Adding Value for Classification Object */
    if (object == Classif)
    {
        DBA_VALUE_STP value, * cursor = &SV_State.values;

        DICT_T id = 0;

        if (entity->object == Grid)
        {
            DBA_GetDictId(Instr, &id);

            /* Allocating Value */
            value = (DBA_VALUE_STP)REALLOC(NULL, sizeof(DBA_VALUE_ST));

            /* Initializing Value */
            value->entity = child;

            value->index = S_Classif_EntDictId;
            value->type = DictType;

            value->value.number = id;
            value->null = FALSE;

            value->next = NULL;

            /* Appending Value to Value List */
            while (*cursor)
                cursor = &(*cursor)->next;

            *cursor = value;
        }

        if (entity->object == ClassifCompo)
        {
            if (SV_State.object != -1)
                DBA_GetDictId(SV_State.object, &id);

            /* Allocating Value */
            value = (DBA_VALUE_STP)REALLOC(NULL, sizeof(DBA_VALUE_ST));

            /* Initializing Value */
            value->entity = child;

            value->index = S_Classif_EntDictId;
            value->type = DictType;

            value->value.number = id;
            value->null = FALSE;

            value->next = NULL;

            /* Appending Value to Value List */
            while (*cursor)
                cursor = &(*cursor)->next;

            *cursor = value;
        }
    }

    /* Adding Value for Codification Object */
    if (object == Codif)
    {
        DBA_VALUE_STP value, * cursor = &SV_State.values;

        DICT_T id = 0;

        if (entity->object == Rating ||
            entity->object == Sect ||
            entity->object == Synon)
        {
            DBA_GetDictId(entity->object, &id);

            /* Allocating Value */
            value = (DBA_VALUE_STP)REALLOC(NULL, sizeof(DBA_VALUE_ST));

            /* Initializing Value */
            value->entity = child;

            value->index = S_Codif_EntityDictId;
            value->type = DictType;

            value->value.number = id;
            value->null = FALSE;

            value->next = NULL;

            /* Appending Value to Value List */
            while (*cursor)
                cursor = &(*cursor)->next;

            *cursor = value;
        }

        if (entity->object == Synon)
        {
            if (SV_State.object != -1)
                DBA_GetDictId(SV_State.object, &id);

            /* Allocating Value */
            value = (DBA_VALUE_STP)REALLOC(NULL, sizeof(DBA_VALUE_ST));

            /* Initializing Value */
            value->entity = child;

            value->index = S_Codif_SynEntityDictId;
            value->type = DictType;

            value->value.number = id;
            value->null = FALSE;

            value->next = NULL;

            /* Appending Value to Value List */
            while (*cursor)
                cursor = &(*cursor)->next;

            *cursor = value;
        }
    }

    /* Adding Value for List Object */
    if (object == List)
    {
        DBA_VALUE_STP value, * cursor = &SV_State.values;

        DICT_T id;

        if (entity->object == MktSegt)
        {
            DBA_GetDictId(Instr, &id);

            /* Allocating Value */
            value = (DBA_VALUE_STP)REALLOC(NULL, sizeof(DBA_VALUE_ST));

            /* Initializing Value */
            value->entity = child;

            value->index = S_List_EntityDictId;
            value->type = DictType;

            value->value.number = id;
            value->null = FALSE;

            value->next = NULL;

            /* Appending Value to Value List */
            while (*cursor)
                cursor = &(*cursor)->next;

            *cursor = value;
        }

        if (entity->object == ListCompo ||
            entity->object == ClassifCompo)
        {
            if (SV_State.object != -1)
            {
                DBA_GetDictId(SV_State.object, &id);

                /* Allocating Value */
                value = (DBA_VALUE_STP)REALLOC(NULL, sizeof(DBA_VALUE_ST));

                /* Initializing Value */
                value->entity = child;

                value->index = S_List_EntityDictId;
                value->type = DictType;

                value->value.number = id;
                value->null = FALSE;

                value->next = NULL;

                /* Appending Value to Value List */
                while (*cursor)
                    cursor = &(*cursor)->next;

                *cursor = value;
            }
        }
    }

    /* Adding Value for Type Object */
    if (object == Tp)
    {
        DBA_VALUE_STP value, * cursor = &SV_State.values;

        DICT_ATTRIB_STP attribute =
            entity->parent == NULL ?
            DBA_GetAttributeByLIndex(entity->object, index) :
            DBA_GetAttributeBySIndex(entity->object, index);

        DICT_T id = attribute->parAttrDictId ?
            attribute->parAttrDictId : attribute->attrDictId;

        /* Allocating Value */
        value = (DBA_VALUE_STP)REALLOC(NULL, sizeof(DBA_VALUE_ST));

        /* Initializing Value */
        value->entity = child;

        value->index = S_Tp_AttribDictId;
        value->type = DictType;

        value->value.number = id;
        value->null = FALSE;

        value->next = NULL;

        /* Appending Value to Value List */
        while (*cursor)
            cursor = &(*cursor)->next;

        *cursor = value;
    }

    return child;
}



/************************************************************************
**
**  Function    :   DBA_ParseAttribute()
**
**  Description :
**
**  Argument    :   entity
**                  flags
**                  cell
**                  string
**
**  Return      :   0 on success, -1 elsewhere
**
*************************************************************************/
STATIC int DBA_ParseAttribute(DBA_ENTITY_STP entity, DBA_CELL_STP cell, char* string)
{
    DICT_ATTRIB_STP  attribute;
    int             status = 0;
    char* scan = string;

    if (isalpha(*scan) || /* PMSTA-26261 - DDV - 170214 - Allow uppercase char */
        *scan == '_')
    {
        do
            scan++;
        while (isalpha(*scan) || /* PMSTA-26261 - DDV - 170214 - Allow uppercase char */
               isdigit(*scan) ||
               *scan == '_');
    }

    if (scan != string)
    {
        char* name = (char*)REALLOC(NULL, scan - string + 1);

        memcpy(name, string, scan - string);
        name[scan - string] = '\0';

        if (DBA_SearchAttribSqlName(entity->object, name, &attribute) == RET_SUCCEED && !strcmp(name, attribute->sqlName))
        {
            int index = entity->parent == NULL ? attribute->progN : attribute->shortIdx; /* PMSTA08801 - DDV - 091126 */

            if (attribute->isPhysicalAttribute() ||
                entity->parent == NULL &&
                entity->object == ApplUser &&
                index == A_ApplUser_UserPassword ||
                entity->parent == NULL &&
                entity->object == Third &&
                index == A_Third_InputPassword ||
                entity->parent == NULL &&
                entity->object == Mgr &&
                index == A_Mgr_InputPassword)
            {
                char* cursor = strrstr(name, "object_id");

                if ((cursor != NULL && !cursor[9]) ||
                    (attribute->refEntDictId && !attribute->logicalFlg))
                {
                    if (*scan == '.')
                    {
                        if (entity->parent == NULL || attribute->busKeyFlg)
                        {
                            DBA_ENTITY_STP child = DBA_GetChildEntity(entity, index);

                            if (child == NULL)
                            {
                                child = DBA_AddChildEntity(entity, index);

                                if (DBA_ParseAttribute(child, cell, ++scan))
                                    status = -1;
                            }
                            else
                                if (DBA_ParseAttribute(child, cell, ++scan))
                                    status = -1;
                        }
                        else
                            status = -1;
                    }
                    else
                        status = -1;
                }
                else
                {
                    if (!attribute->refEntDictId)
                    {
                        if (!*scan)
                        {
                            if (entity->parent == NULL || attribute->busKeyFlg)
                            {
                                cell->entity = entity;
                                cell->index = index;
                                cell->type = attribute->dataTpProgN;
                                cell->time_e = attribute->widgetEn;
                            }
                            else
                                status = -1;
                        }
                        else
                            status = -1;
                    }
                    else
                        status = -1;
                }
            }
            else
                status = -1;
        }
        else
        {
            char* cursor;

            if ((cursor = strrstr(name, "_id")) == NULL || cursor[3])
            {
                char* expressionId;

                if (*scan)
                {
                    expressionId = (char*)REALLOC(NULL, strlen(name) + strlen(scan) + 4);

                    strcpy(expressionId, name);
                    strcat(expressionId, "_id");
                    strcat(expressionId, scan);
                }
                else
                {
                    expressionId = (char*)REALLOC(NULL, strlen(name) + 9);

                    strcpy(expressionId, name);
                    strcat(expressionId, "_id.code");
                }

                if (DBA_ParseAttribute(entity, cell, expressionId))
                {
                    char* cursorDictId;

                    if ((cursorDictId = strrstr(name, "_dict_id")) == NULL || cursorDictId[8])
                    {
                        char* expressionDictId;

                        if (*scan)
                        {
                            expressionDictId = (char*)REALLOC(NULL, strlen(name) + strlen(scan) + 9);

                            strcpy(expressionDictId, name);
                            strcat(expressionDictId, "_dict_id");
                            strcat(expressionDictId, scan);

                            if (DBA_ParseAttribute(entity, cell, expressionDictId))
                                status = -1;
                        }
                        else
                        {
                            expressionDictId = (char*)REALLOC(NULL, strlen(name) + 19);

                            strcpy(expressionDictId, name);
                            strcat(expressionDictId, "_dict_id.sqlname_c");

                            if (DBA_ParseAttribute(entity, cell, expressionDictId))
                            {
                                char* expressionDictIdCode = (char*)REALLOC(NULL, strlen(name) + 14);

                                strcpy(expressionDictIdCode, name);
                                strcat(expressionDictIdCode, "_dict_id.code");

                                if (DBA_ParseAttribute(entity, cell, expressionDictIdCode))
                                    status = -1;

                                FREE(expressionDictIdCode);
                            }
                        }

                        FREE(expressionDictId);
                    }
                    else
                        status = -1;
                }

                FREE(expressionId);
            }
            else
                status = -1;
        }

        FREE(name);
    }
    else
        return -1;

    if (status)
        return -1;

    return 0;
}


/************************************************************************
**
**  Function    :   DBA_ParseField()
**
**  Description :
**
**  Argument    :   field
**                  string
**
**  Return      :   0 on success, -1 elsewhere
**
*************************************************************************/
STATIC int DBA_ParseField(char* string)
{
    char* colon = strchr(string, ':');
    int     target = 0;

    SV_Code = -1;

    if (colon != NULL)
        *colon++ = '\0';

    switch (SV_State.data)
    {
        case DelimitedData:
            if (colon != NULL)
                SV_Code = 16;
            break;

    }

    if (SV_Code < 0)
    {
        DBA_CELL_ST cell;

        memset(&cell, 0, sizeof(DBA_CELL_ST));

        if (!strcasecmp(string, "DISCARD") || DBA_IsDeletedAttribute(SV_State.target->object, string) == TRUE) /* PMSTA-16528 - DDV - 140703 - Avoid error on deleted attribute (format_element.search_key_e) */
        {
            cell.entity = NULL;
            cell.index = -1;
            cell.type = NullDataType;
        }
        else
        {
            target = 1;

            if (DBA_ParseAttribute(SV_State.target, &cell, string))
                SV_Code = 18;
        }

        if (SV_Code < 0)
        {
            char* tail;
            int     width = 0;

            /* Initializing Width */
            switch (SV_State.data)
            {
                case SpacedData:
                case DelimitedData:
                    width = 0;
                    break;

                case FixedData:
                    tail = colon + strspn(colon, "0123456789");

                    if (!*tail)
                        width = atoi(colon);
                    else
                        SV_Code = 17;
                    break;

                default:
                    break;
            }

            if (SV_Code < 0)
            {
                DBA_FIELD_STP  field,
                    * cursor = &SV_State.fields;
                DBA_ENTITY_STP entity;
                int            index; /* PMSTA08801 - DDV - 091126 */

                /* Initializing Field */
                field = (DBA_FIELD_STP)REALLOC(NULL, sizeof(DBA_FIELD_ST));
                field->entity = cell.entity;
                field->index = cell.index;
                field->type = cell.type;
                field->time_e = cell.time_e;
                field->width = width;
                field->evalDV = FALSE;
                field->next = NULL;

                /* Updating Defaults Values Flag */
                if (field->entity != NULL)
                {
                    index = field->index;
                    entity = field->entity;

                    while (entity->parent != NULL)
                    {
                        index = entity->index;
                        entity = entity->parent;
                    }

                    if (!target)
                        SV_State.sf[index] = TRUE;
                    else
                        SV_State.tf[index] = TRUE;
                }

                /* Appending Field to Field List */
                while (*cursor != NULL)
                    cursor = &(*cursor)->next;

                *cursor = field;
            }
            else
                return -1;
        }
        else
            return -1;
    }
    else
        return -1;

    return 0;
}




/************************************************************************
**
**  Function    :   DBA_ParseATTLine()
**
**  Description :
**
**  Argument    :   context
**                  line
**                  cursor
**
*************************************************************************/
STATIC int DBA_ParseATTLine(char* cursor)
{
    int     status = 0;


    if (SV_State.action != No_Action)
    {
        cursor += strspn(cursor, " \t");

        if (*cursor)
        {

            do
            {
                char* scan = cursor + strcspn(cursor, " \t");
                char* string = (char*)REALLOC(NULL, scan - cursor + 1);

                memcpy(string, cursor, scan - cursor);
                string[scan - cursor] = '\0';

                status = DBA_ParseField(string);
                if (status)
                    printf("error");
                /*
                ITF1_Error(context, SV_Code, string);
                */
                FREE(string);

                cursor = scan + strspn(scan, " \t");
            } while (*cursor && !status);

            if (status)
            {
                SV_State.action = No_Action;
                SV_State.object = NullEntity;

                DBA_DiscardFields(&SV_State.fields);
                DBA_DiscardValues(&SV_State.values);
                DBA_DiscardCopies(&SV_State.copies);

                DBA_DiscardEntities(&SV_State.source);
                DBA_DiscardEntities(&SV_State.target);

                if (SV_State.sf != NULL)
                    FREE(SV_State.sf);
                if (SV_State.tf != NULL)
                    FREE(SV_State.tf);
            }
        }
        else
        {
            status = -1;
            /*ITF1_Error(context, 4);*/
        }
    }
    else
    {
        status = -1;
        /*ITF1_Error(context, 13);*/
    }

    return status;
}



/************************************************************************
**
**  Function    :   DBA_CheckEntitiesChildSkip()
**
**  Description :   case of PPS for example
**		    ptf -> curr -> Tp -> cons_ptf
**		                   |
**			DictAttr	DictEntity
**
**  Argument    :   entities
**
*************************************************************************/
STATIC void DBA_CheckEntitiesChildSkip(DBA_ENTITY_STP entities)
{
    FLAG_T          allChildSkipFlg = TRUE;
    DBA_ENTITY_STP	childEntity = entities->child;

    if (childEntity != NULL)
    {
        while (childEntity != NULL)
        {
            if (childEntity->skip == FALSE)
            {
                allChildSkipFlg = FALSE;
                break;
            }

            childEntity = childEntity->next;
        }

        entities->skip = allChildSkipFlg;
    }
}




/************************************************************************
**
**  Function    :   DBA_ComputeDV()
**
**  Description :
**
**  Argument    :   object
**                  flags
**                  record
**                  previous
**                  mode
**
**  Return      :   0 on success, -1 elsewhere
**
*************************************************************************/
STATIC int DBA_ComputeDV(OBJECT_ENUM object, FLAG_T* flags, DBA_DYNFLD_STP record, DBA_DYNFLD_STP previous, FLAG_T mode)
{
    DBA_HANDLER_STP    handlers = SV_State.handlers;
    int                 count = 0;
    int                 status = 0;
    DBA_HANDLER_STP    candidat = NULL;

    while (handlers != NULL)
    {
        if (handlers->object == object && handlers->nature == DV)
            break;

        count++;

        if (candidat == NULL || candidat->stamp > handlers->stamp)
            candidat = handlers;

        handlers = handlers->next;
    }

    if (handlers == NULL)
    {
        SCPT_DFLTVAL_STP handle;

        if (SCPT_InitEntityDefVal(object, &handle, FALSE, 0) == RET_SUCCEED)
        {
            if (count < MAXHANDLE)
            {
                candidat = (DBA_HANDLER_STP)CALLOC(1, sizeof(DBA_HANDLER_ST));

                candidat->next = SV_State.handlers;

                SV_State.handlers = candidat;
            }
            else
            {
                SCPT_FreeEntityDefVal(candidat->dvHandle);
                SCPT_FreeEntityControl(candidat->icHandle);
            }

            candidat->object = object;
            candidat->nature = DV;
            candidat->dvHandle = handle;

            candidat->count = 0;

            handlers = candidat;
        }
        else
            return -1;
    }

    handlers->stamp = time(NULL);
    handlers->count++;

    SCPT_SetOldRecord(handlers->dvHandle, previous);

    if (SCPT_AnalyseEntityDefVal(handlers->dvHandle, flags, NULL, record, mode, EvalType_DefVal, NULL, NULL, FALSE) != RET_SUCCEED)    /*  FPL-REF9215-030812  Add last parameter  */ /* HFI-PMSTA-25327-171023  Dedicated flag tab for filter    */
        status = -1;

    SCPT_SetOldRecord(handlers->dvHandle, NULL);

    if (status)
        return -1;

    return 0;
}



/************************************************************************
**
**  Function    :   DBA_ComputeIC()
**
**  Description :
**
**  Argument    :   object
**                  record
**                  previous
**                  message
**
**  Return      :   0 on success, -1 elsewhere
**
*************************************************************************/
STATIC int DBA_ComputeIC(OBJECT_ENUM object, DBA_DYNFLD_STP record, DBA_DYNFLD_STP previous, DBA_MESSAGE_STP message)
{
    DBA_HANDLER_STP    handlers = SV_State.handlers;
    int                 count = 0;
    int                 status = 0;
    DBA_HANDLER_STP    candidat = NULL;

    while (handlers != NULL)
    {
        if (handlers->object == object && handlers->nature == IC)
            break;

        count++;

        if (candidat == NULL || candidat->stamp > handlers->stamp)
            candidat = handlers;

        handlers = handlers->next;
    }

    if (handlers == NULL)
    {
        SCPT_ARG_STP handle;

        if (SCPT_InitEntityControl(object, &handle, FALSE, 0, NullDictFct, NullEntity, 0) == RET_SUCCEED)      /*  FIH-REF11144-050607 Add NullEntity  */
        {
            if (count < MAXHANDLE)
            {
                candidat = (DBA_HANDLER_STP)CALLOC(1, sizeof(DBA_HANDLER_ST));

                candidat->next = SV_State.handlers;

                SV_State.handlers = candidat;
            }
            else
            {
                SCPT_FreeEntityDefVal(candidat->dvHandle);
                SCPT_FreeEntityControl(candidat->icHandle);
            }

            candidat->object = object;
            candidat->nature = IC;
            candidat->icHandle = handle;

            candidat->count = 0;

            handlers = candidat;
        }
        else
            return -1;
    }

    handlers->stamp = time(NULL);
    handlers->count++;

    SCPT_SetOldRecordControl(handlers->icHandle, previous);

    if (SCPT_AnalyseEntityControl(handlers->icHandle, record, &message->vector, &message->size, NULL, ScptActionNone) != RET_SUCCEED) /*  FPL-PMSTA03122-PMSTA02138-070829 add parameter hier and icAction   */
        status = -1;

    SCPT_SetOldRecordControl(handlers->icHandle, NULL);

    if (status)
        return -1;

    return 0;
}



/************************************************************************
**
**  Function    :   DBA_CheckIC()
**
**  Description :
**
**  Argument    :   message
**
**  Return      :   0 on success, -1 elsewhere
**
*************************************************************************/
STATIC int DBA_CheckIC(DBA_MESSAGE_STP message)
{
    int n;

    for (n = 0; n < message->size; n++)
        if (GET_ENUM(message->vector[n], Msg_NatEn) == MsgNat_Error)
            return -1;

    return 0;
}

/************************************************************************
**
**  Function    :   DBA_CleanIC()
**
**  Description :
**
**  Argument    :   context
**                  message
**
**  Return      :   0 on success, -1 elsewhere
**
*************************************************************************/
STATIC void DBA_CleanIC(DBA_MESSAGE_STP message)
{
    if (message->vector != NULL)
        DBA_FreeDynStTab(message->vector, message->size, Msg);

    memset(message, 0, sizeof(DBA_MESSAGE_ST));
}


/************************************************************************
**
**  Function    :   DBA_ProcessEntities()
**
**  Description :
**
**  Argument    :   entities
**                  entity
**
**  Return      :   0 on success, -1 elsewhere
**
*************************************************************************/
STATIC int DBA_ProcessEntities(DBA_ENTITY_STP entities, DBA_ENTITY_STP* entity)
{
    int role = UNUSED;
    *entity = NULL;

    while (entities != NULL)
    {
        if (DBA_ProcessEntities(entities->child, entity))
            return -1;

        DBA_CheckEntitiesChildSkip(entities);

        if (entities->parent != NULL)
        {
            DBA_CODIFICATION_STP codification = SV_State.codifications;

            while (codification != NULL)
            {
                if (codification->object == entities->object)
                {
                    SET_ID(entities->record, GET_FLD_NBR(GET_ADMINGUIST(entities->object)) - 1, codification->id);
                }

                codification = codification->next;
            }

            if (entities->skip == FALSE)
            {
                if (entities->parent->object == Notepad && entities->object == Op)
                {
                    role = DBA_ROLE_GET_OPER_FOR_NOTEPAD;
                }
                else
                {
                    role = UNUSED;
                }
                if (DBA_Get2(entities->object
                             , role
                             , GET_ADMINGUIST(entities->object)
                             , entities->record
                             , GET_ADMINGUIST(entities->object)
                             , &entities->record
                             , UNUSED
                             , UNUSED
                             , UNUSED) != RET_SUCCEED)
                {
                    DBA_AUTOMATIC_STP automatic = SV_State.automatics;

                    while (automatic != NULL)
                    {
                        if (automatic->object == entities->object)
                            if (automatic->enable)
                                break;

                        automatic = automatic->next;
                    }

                    if (automatic != NULL)
                    {
                        DICT_ATTRIB_STP* attributes;
                        int             n,
                            count;
                        int             status = TRUE;
                        int             insert = TRUE;
                        void* pointer;
                        DBA_DYNFLD_STP  record = ALLOC_DYNST(GET_EDITGUIST(entities->object));
                        FLAG_T* flags = (FLAG_T*)CALLOC(GET_FLD_NBR(GET_EDITGUIST(entities->object)), sizeof(FLAG_T));

                        /*** Begin: Added until DV Updated ***/
                        /***                               ***/

                        DBA_SetDfltEntityFld(entities->object, GET_EDITGUIST(entities->object), record);

                        /***                               ***/
                        /*** End  : Added until DV Updated ***/

                        DBA_GetBusinessAttrib(entities->object, &count, &attributes);

                        for (n = 0; n < count; n++)
                        {
                            COPY_DYNFLD(record
                                        , GET_EDITGUIST(entities->object)
                                        , attributes[n]->progN
                                        , entities->record
                                        , GET_ADMINGUIST(entities->object)
                                        , attributes[n]->shortIdx
                            );

                            flags[attributes[n]->progN] = TRUE;
                        }

                        if ((pointer = DBA_GetAttributeBySqlName(entities->object, "autocreated_f")) != NULL)
                        {
                            DICT_ATTRIB_STP     attribute = (DICT_ATTRIB_STP)pointer;

                            SET_FLAG(record, attribute->progN, TRUE);

                            flags[attribute->progN] = TRUE;
                        }

                        if (entities->object == Tp)
                        {
                            DBA_ENTITY_STP parent = entities->parent;

                            DICT_ATTRIB_STP target = parent->parent == NULL ?
                                DBA_GetAttributeByLIndex(parent->object, entities->index) :
                                DBA_GetAttributeBySIndex(parent->object, entities->index);

                            if (parent->parent == NULL)
                            {
                                if (!strcmp(target->sqlName, "subtype_id"))
                                    switch (GET_OBJECT_CST(parent->object))
                                    {
                                        case InstrCst:
                                            if (IS_NULLFLD(parent->record, A_Instr_NatEn))
                                                insert = FALSE;
                                            else
                                            {
                                                SET_ENUM(record, A_Tp_InstrNatEn
                                                         , GET_ENUM(parent->record, A_Instr_NatEn));
                                                flags[A_Tp_InstrNatEn] = TRUE;
                                            }

                                            if (IS_NULLFLD(parent->record, A_Instr_TypeId))
                                                insert = FALSE;
                                            else
                                            {
                                                SET_ID(record, A_Tp_ParentTypeId
                                                       , GET_ID(parent->record, A_Instr_TypeId));
                                                flags[A_Tp_ParentTypeId] = TRUE;
                                            }
                                            break;

                                        case BuyOpEntCst:
                                            SET_ENUM(record, A_Tp_OperNatEn, OpNat_Buy);
                                            flags[A_Tp_OperNatEn] = TRUE;

                                            if (IS_NULLFLD(parent->record, BuyOp_TpId))
                                                insert = FALSE;
                                            else
                                            {
                                                SET_ID(record, A_Tp_ParentTypeId
                                                       , GET_ID(parent->record, BuyOp_TpId));
                                                flags[A_Tp_ParentTypeId] = TRUE;
                                            }
                                            break;

                                        case SellOpEntCst:
                                            SET_ENUM(record, A_Tp_OperNatEn, OpNat_Sell);
                                            flags[A_Tp_OperNatEn] = TRUE;

                                            if (IS_NULLFLD(parent->record, SellOp_TpId))
                                                insert = FALSE;
                                            else
                                            {
                                                SET_ID(record, A_Tp_ParentTypeId
                                                       , GET_ID(parent->record, SellOp_TpId));
                                                flags[A_Tp_ParentTypeId] = TRUE;
                                            }
                                            break;

                                        case InvestOpEntCst:
                                            SET_ENUM(record, A_Tp_OperNatEn, OpNat_Invest);
                                            flags[A_Tp_OperNatEn] = TRUE;

                                            if (IS_NULLFLD(parent->record, InvestOp_TpId))
                                                insert = FALSE;
                                            else
                                            {
                                                SET_ID(record, A_Tp_ParentTypeId
                                                       , GET_ID(parent->record, InvestOp_TpId));
                                                flags[A_Tp_ParentTypeId] = TRUE;
                                            }
                                            break;

                                        case WithdrOpEntCst:
                                            SET_ENUM(record, A_Tp_OperNatEn, OpNat_Withdr);
                                            flags[A_Tp_OperNatEn] = TRUE;

                                            if (IS_NULLFLD(parent->record, WithdrOp_TpId))
                                                insert = FALSE;
                                            else
                                            {
                                                SET_ID(record, A_Tp_ParentTypeId
                                                       , GET_ID(parent->record, WithdrOp_TpId));
                                                flags[A_Tp_ParentTypeId] = TRUE;
                                            }
                                            break;

                                        case IncOpEntCst:
                                            SET_ENUM(record, A_Tp_OperNatEn, OpNat_Income);
                                            flags[A_Tp_OperNatEn] = TRUE;

                                            if (IS_NULLFLD(parent->record, IncOp_TpId))
                                                insert = FALSE;
                                            else
                                            {
                                                SET_ID(record, A_Tp_ParentTypeId
                                                       , GET_ID(parent->record, IncOp_TpId));
                                                flags[A_Tp_ParentTypeId] = TRUE;
                                            }
                                            break;

                                        case ShareIssOpEntCst:
                                            SET_ENUM(record, A_Tp_OperNatEn, OpNat_ShareIss);
                                            flags[A_Tp_OperNatEn] = TRUE;

                                            if (IS_NULLFLD(parent->record, ShareIssOp_TpId))
                                                insert = FALSE;
                                            else
                                            {
                                                SET_ID(record, A_Tp_ParentTypeId
                                                       , GET_ID(parent->record, ShareIssOp_TpId));
                                                flags[A_Tp_ParentTypeId] = TRUE;
                                            }
                                            break;

                                        case ShareRedmOpEntCst:
                                            SET_ENUM(record, A_Tp_OperNatEn, OpNat_ShareRedm);
                                            flags[A_Tp_OperNatEn] = TRUE;

                                            if (IS_NULLFLD(parent->record, ShareRedmOp_TpId))
                                                insert = FALSE;
                                            else
                                            {
                                                SET_ID(record, A_Tp_ParentTypeId
                                                       , GET_ID(parent->record, ShareRedmOp_TpId));
                                                flags[A_Tp_ParentTypeId] = TRUE;
                                            }
                                            break;

                                        case TransfOpEntCst:
                                            SET_ENUM(record, A_Tp_OperNatEn, OpNat_Transf);
                                            flags[A_Tp_OperNatEn] = TRUE;

                                            if (IS_NULLFLD(parent->record, TransfOp_TpId))
                                                insert = FALSE;
                                            else
                                            {
                                                SET_ID(record, A_Tp_ParentTypeId
                                                       , GET_ID(parent->record, TransfOp_TpId));
                                                flags[A_Tp_ParentTypeId] = TRUE;
                                            }
                                            break;

                                        case BpTransfOpEntCst:
                                            SET_ENUM(record, A_Tp_OperNatEn, OpNat_BpTransf);
                                            flags[A_Tp_OperNatEn] = TRUE;

                                            if (IS_NULLFLD(parent->record, BpTransfOp_TpId))
                                                insert = FALSE;
                                            else
                                            {
                                                SET_ID(record, A_Tp_ParentTypeId
                                                       , GET_ID(parent->record, BpTransfOp_TpId));
                                                flags[A_Tp_ParentTypeId] = TRUE;
                                            }
                                            break;

                                        case AdjustOpEntCst:
                                            SET_ENUM(record, A_Tp_OperNatEn, OpNat_Adjust);
                                            flags[A_Tp_OperNatEn] = TRUE;

                                            if (IS_NULLFLD(parent->record, AdjustOp_TpId))
                                                insert = FALSE;
                                            else
                                            {
                                                SET_ID(record, A_Tp_ParentTypeId
                                                       , GET_ID(parent->record, AdjustOp_TpId));
                                                flags[A_Tp_ParentTypeId] = TRUE;
                                            }
                                            break;

                                        case FtOpEntCst:
                                            SET_ENUM(record, A_Tp_OperNatEn, OpNat_Fee);
                                            flags[A_Tp_OperNatEn] = TRUE;

                                            if (IS_NULLFLD(parent->record, FtOp_TpId))
                                                insert = FALSE;
                                            else
                                            {
                                                SET_ID(record, A_Tp_ParentTypeId
                                                       , GET_ID(parent->record, FtOp_TpId));
                                                flags[A_Tp_ParentTypeId] = TRUE;
                                            }
                                            break;

                                        case LockOpEntCst:
                                            SET_ENUM(record, A_Tp_OperNatEn, OpNat_Locking);
                                            flags[A_Tp_OperNatEn] = TRUE;

                                            if (IS_NULLFLD(parent->record, LockOp_TpId))
                                                insert = FALSE;
                                            else
                                            {
                                                SET_ID(record, A_Tp_ParentTypeId
                                                       , GET_ID(parent->record, LockOp_TpId));
                                                flags[A_Tp_ParentTypeId] = TRUE;
                                            }
                                            break;
                                        case InitOpEntCst:
                                            SET_ENUM(record, A_Tp_OperNatEn, OpNat_Init);
                                            flags[A_Tp_OperNatEn] = TRUE;

                                            if (IS_NULLFLD(parent->record, InitOp_TpId))
                                                insert = FALSE;
                                            else
                                            {
                                                SET_ID(record, A_Tp_ParentTypeId
                                                       , GET_ID(parent->record, InitOp_TpId));
                                                flags[A_Tp_ParentTypeId] = TRUE;
                                            }
                                            break;
                                    }
                                else
                                    if (!strcmp(target->sqlName, "type_id"))
                                        switch (GET_OBJECT_CST(parent->object))
                                        {
                                            case InstrCst:
                                                if (IS_NULLFLD(parent->record, A_Instr_NatEn))
                                                    insert = FALSE;
                                                else
                                                {
                                                    SET_ENUM(record, A_Tp_InstrNatEn
                                                             , GET_ENUM(parent->record, A_Instr_NatEn));
                                                    flags[A_Tp_InstrNatEn] = TRUE;
                                                }
                                                break;

                                            case BuyOpEntCst:
                                                SET_ENUM(record, A_Tp_OperNatEn, OpNat_Buy);
                                                flags[A_Tp_OperNatEn] = TRUE;
                                                break;

                                            case SellOpEntCst:
                                                SET_ENUM(record, A_Tp_OperNatEn, OpNat_Sell);
                                                flags[A_Tp_OperNatEn] = TRUE;
                                                break;

                                            case InvestOpEntCst:
                                                SET_ENUM(record, A_Tp_OperNatEn, OpNat_Invest);
                                                flags[A_Tp_OperNatEn] = TRUE;
                                                break;

                                            case WithdrOpEntCst:
                                                SET_ENUM(record, A_Tp_OperNatEn, OpNat_Withdr);
                                                flags[A_Tp_OperNatEn] = TRUE;
                                                break;

                                            case IncOpEntCst:
                                                SET_ENUM(record, A_Tp_OperNatEn, OpNat_Income);
                                                flags[A_Tp_OperNatEn] = TRUE;
                                                break;

                                            case ShareIssOpEntCst:
                                                SET_ENUM(record, A_Tp_OperNatEn, OpNat_ShareIss);
                                                flags[A_Tp_OperNatEn] = TRUE;
                                                break;

                                            case ShareRedmOpEntCst:
                                                SET_ENUM(record, A_Tp_OperNatEn, OpNat_ShareRedm);
                                                flags[A_Tp_OperNatEn] = TRUE;
                                                break;

                                            case TransfOpEntCst:
                                                SET_ENUM(record, A_Tp_OperNatEn, OpNat_Transf);
                                                flags[A_Tp_OperNatEn] = TRUE;
                                                break;

                                            case BpTransfOpEntCst:
                                                SET_ENUM(record, A_Tp_OperNatEn, OpNat_BpTransf);
                                                flags[A_Tp_OperNatEn] = TRUE;
                                                break;

                                            case AdjustOpEntCst:
                                                SET_ENUM(record, A_Tp_OperNatEn, OpNat_Adjust);
                                                flags[A_Tp_OperNatEn] = TRUE;
                                                break;

                                            case FtOpEntCst:
                                                SET_ENUM(record, A_Tp_OperNatEn, OpNat_Fee);
                                                flags[A_Tp_OperNatEn] = TRUE;
                                                break;

                                            case LockOpEntCst:
                                                SET_ENUM(record, A_Tp_OperNatEn, OpNat_Locking);
                                                flags[A_Tp_OperNatEn] = TRUE;
                                                break;
                                            case InitOpEntCst:
                                                SET_ENUM(record, A_Tp_OperNatEn, OpNat_Init);
                                                flags[A_Tp_OperNatEn] = TRUE;
                                                break;
                                        }
                            }
                        }

                        if (insert)
                        {
                            if (!DBA_ComputeDV(entities->object
                                               , flags
                                               , record
                                               , NULL
                                               , TRUE))
                            {
                                DBA_MESSAGE_ST message = { NULL, 0 };

                                if (!DBA_ComputeIC(entities->object
                                                   , record
                                                   , NULL
                                                   , &message))
                                {
                                    if (!DBA_CheckIC(&message))
                                    {
                                        if (DBA_Insert2(entities->object
                                                        , UNUSED
                                                        , GET_EDITGUIST(entities->object)
                                                        , record
                                                        , UNUSED
                                                        , UNUSED
                                                        , UNUSED
                                        ) != RET_SUCCEED)
                                            status = FALSE;
                                    }
                                    else
                                        status = FALSE;
                                }
                                else
                                    status = FALSE;

                                DBA_CleanIC(&message);
                            }
                            else
                                status = FALSE;
                        }
                        else
                            status = FALSE;

                        if (status == TRUE)
                        {
                            DBA_ENTITY_STP parent = entities->parent;

                            COPY_DYNFLD(parent->record
                                        , parent->parent == NULL ?
                                        GET_EDITGUIST(parent->object) :
                                        GET_ADMINGUIST(parent->object)
                                        , entities->index
                                        , record
                                        , GET_EDITGUIST(entities->object)
                                        , 0
                            );
                        }

                        FREE(flags);

                        FREE_DYNST(record, GET_EDITGUIST(entities->object));

                        if (status == FALSE)
                            *entity = entities;
                    }
                    else
                        *entity = entities;

                    if (*entity != NULL)
                        return -1;
                }
                else
                {
                    DBA_ENTITY_STP parent = entities->parent;

                    COPY_DYNFLD(parent->record
                                , parent->parent == NULL ?
                                GET_EDITGUIST(parent->object) :
                                GET_ADMINGUIST(parent->object)
                                , entities->index
                                , entities->record
                                , GET_ADMINGUIST(entities->object)
                                , 0
                    );
                }
            }
        }

        entities = entities->next;
    }

    return 0;
}




/************************************************************************
**
**  Function    :   DBA_GetSpaced()
**
**  Description :
**
**  Argument    :   cursor
**                  quote
**                  escape
**                  status
**
**  Return      :   pointer to string on success, NULL elsewhere
**                      *status <  0  : ERROR
**                              == 0  : NULL
**                              == 1  : UNQUOTED
**                              == 2  : QUOTED
**                              == 3  : NULL_DV (NULL but with DV evaluation)
**
*************************************************************************/
STATIC char* DBA_GetSpaced(char** cursor, char quote, char escape, int* status)
{
    unsigned    escaped = 0;
    char* head = *cursor;
    char* tail = *cursor;
    int         code = 0;
    unsigned    length = 0;
    char* field = NULL;

    if (status == NULL)
        status = &code;

    if (**cursor)
    {
        if (**cursor != quote)
        {
            while (*tail && (strchr(" \t", *tail) == NULL || escaped))
                escaped = *tail++ == escape && !escaped;

            if (!escaped)
            {
                *cursor = tail;
                while (**cursor && strchr(" \t", **cursor) != NULL)
                    (*cursor)++;

                *status = head == tail ? 0 : 1;
            }
            else
                *status = -1;
        }
        else
        {
            head++;
            tail++;

            while (*tail && (*tail != quote || escaped))
                escaped = *tail++ == escape && !escaped;

            if (!escaped)
            {
                *cursor = tail;
                if (*tail)
                {
                    (*cursor)++;
                    if (!*(tail + 1) || strchr(" \t", *(tail + 1)) != NULL)
                    {
                        while (**cursor && strchr(" \t", **cursor) != NULL)
                            (*cursor)++;

                        *status = head == tail ? 0 : 2;
                    }
                    else
                        *status = -1;
                }
                else
                    *status = -1;
            }
            else
                *status = -1;
        }
    }
    else
        *status = -1;


    if (*status < 0)
        return NULL;


    while (head != tail)
    {
        if (*head == escape && !escaped)
            escaped = !0;
        else
        {
            if (length % 16 == 0)
                field = (char*)REALLOC(field, length + 16);

            if (escaped)
            {
                switch (*head)
                {
                    case 'n':
                        field[length++] = '\n';
                        break;

                    case 'r':
                        field[length++] = '\r';
                        break;

                    case 't':
                        field[length++] = '\t';
                        break;

                    default:
                        field[length++] = *head;
                        break;
                }
            }
            else
                field[length++] = *head;

            escaped = 0;
        }

        head++;
    }

    if (length % 16 == 0)
        field = (char*)REALLOC(field, length + 16);

    field[length++] = 0;

    if (!strcasecmp(field, "NULL"))
        field = (char*)REALLOC(field, *status = 0);
    else if (!strcasecmp(field, "NULL_DV"))
        field = (char*)REALLOC(field, *status = 3);

    return field;
}





/************************************************************************
**
**  Function    :   DBA_GetFixed()
**
**  Description :
**
**  Argument    :   cursor
**                  width
**                  status
**
**  Return      :   pointer to string on success, NULL elsewhere
**                      *status <  0  : ERROR
**                              == 0  : NULL
**                              == 1  : UNQUOTED
**
*************************************************************************/
STATIC char* DBA_GetFixed(char** cursor, int width, int* status)
{
    char* head = *cursor;
    char* tail = *cursor + width - 1;
    int         code = 0;
    unsigned    length = 0;
    char* field = NULL;

    if (status == NULL)
        status = &code;

    if ((int)strlen(*cursor) >= width)
    {
        *cursor += width;

        while (*tail == ' ' && tail != head)
            tail--;
        while (*head == ' ' && head != tail)
            head++;

        if (*head != ' ')
            tail++;

        *status = head == tail ? 0 : 1;
    }
    else
        *status = -1;



    if (*status < 0)
        return NULL;


    while (head != tail)
    {
        if (length % 16 == 0)
            field = (char*)REALLOC(field, length + 16);

        field[length++] = *head++;
    }


    if (length % 16 == 0)
        field = (char*)REALLOC(field, length + 16);

    field[length++] = 0;

    if (!strcasecmp(field, "NULL"))
        field = (char*)REALLOC(field, *status = 0);
    else if (!strcasecmp(field, "NULL_DV"))
        field = (char*)REALLOC(field, *status = 3);

    return field;
}



/************************************************************************
**
**  Function    :   DBA_GetDelimited()
**
**  Description :
**
**  Argument    :   cursor
**                  separator
**                  quote
**                  escape
**                  status
**
**  Return      :   pointer to string on success, NULL elsewhere
**                      *status <  0  : ERROR
**                              == 0  : NULL
**                              == 1  : UNQUOTED
**                              == 2  : QUOTED
**
*************************************************************************/
STATIC char* DBA_GetDelimited(char** cursor,
                              char separator, char quote, char escape,
                              int* status)
{
    unsigned    escaped = 0;
    char* head = *cursor;
    char* tail = *cursor;
    int         code = 0;
    unsigned    length = 0;
    char* field = NULL;

    if (status == NULL)
        status = &code;

    if (**cursor)
    {
        if (**cursor != quote)
        {
            while (*tail && (*tail != separator || escaped))
                escaped = *tail++ == escape && !escaped;

            if (!escaped)
            {
                *cursor = tail;
                if (*tail)
                    (*cursor)++;

                *status = head == tail ? 0 : 1;
            }
            else
                *status = -1;
        }
        else
        {
            head++;
            tail++;

            while (*tail && (*tail != quote || escaped))
                escaped = *tail++ == escape && !escaped;

            if (!escaped)
            {
                *cursor = tail;
                if (*tail)
                {
                    (*cursor)++;
                    if (!*(tail + 1) || *(tail + 1) == separator)
                    {
                        if (*(tail + 1))
                            (*cursor)++;

                        *status = head == tail ? 0 : 2;
                    }
                    else
                        *status = -1;
                }
                else
                    *status = -1;
            }
            else
                *status = -1;
        }
    }
    else
        *status = -1;


    if (*status < 0)
        return NULL;


    while (head != tail)
    {
        if (*head == escape && !escaped)
            escaped = !0;
        else
        {
            if (length % 16 == 0)
                field = (char*)REALLOC(field, length + 16);

            if (escaped)
            {
                switch (*head)
                {
                    case 'n':
                        field[length++] = '\n';
                        break;

                    case 'r':
                        field[length++] = '\r';
                        break;

                    case 't':
                        field[length++] = '\t';
                        break;

                    default:
                        field[length++] = *head;
                        break;
                }
            }
            else
                field[length++] = *head;

            escaped = 0;
        }

        head++;
    }

    if (length % 16 == 0)
        field = (char*)REALLOC(field, length + 16);

    field[length++] = 0;

    if (!strcasecmp(field, "NULL"))
        field = (char*)REALLOC(field, *status = 0);
    else if (!strcasecmp(field, "NULL_DV"))
        field = (char*)REALLOC(field, *status = 3);

    return field;
}




/************************************************************************
**
**  Function    :   DBA_GetString()
**
**  Description :
**
**  Argument    :   cursor
**                  string
**                  null
**
**  Return      :   0 on success, -1 elsewhere
**
*************************************************************************/
STATIC int DBA_GetString(char** cursor, char** string, int* null, ...)
{
    va_list arg;

    char separator = SV_State.separator;
    char quote = SV_State.quote;
    char escape = SV_State.escape;

    char* field = NULL;

    int status = -1;

    va_start(arg, null);

    switch (SV_State.data)
    {
        case SpacedData:
            field = DBA_GetSpaced(cursor, quote, escape, &status);

            if (status < 0) return -1;

            switch (status)
            {
                case 0:
                    *null = 1;
                    return  0;

                case 1:
                case 2:
                    *null = 0;
                    break;

                case 3:
                    *null = 2;
                    return 0;

            }
            break;

        case DelimitedData:
            field = DBA_GetDelimited(cursor, separator, quote, escape, &status);

            if (status < 0) return -1;

            switch (status)
            {
                case 0:
                    *null = 1;
                    return  0;

                case 1:
                case 2:
                    *null = 0;
                    break;

                case 3:
                    *null = 2;
                    return 0;

            }
            break;

        case FixedData:
            field = DBA_GetFixed(cursor, va_arg(arg, int), &status);

            if (status < 0) return -1;

            switch (status)
            {
                case 0:
                    *null = 1;
                    return  0;

                case 1:
                    *null = 0;
                    break;

                case 3:
                    *null = 2;
                    return 0;

            }
            break;
    }

    va_end(arg);

    if (SV_State.translations != NULL)
    {
        char* scan = field;

        --scan;
        while (*++scan)
            *scan = (*SV_State.translations)[*scan];
    }

    *string = field;

    return 0;
}



/************************************************************************
**
**  Function    :   DBA_GetDate()
**
**  Description :
**
**  Argument    :   cursor
**                  date
**                  null
**
**  Return      :   0 on success, -1 elsewhere
**
*************************************************************************/
STATIC int DBA_GetDate(char** cursor, DATETIME_ST* date, int* null, int width, DICTATTRIBWGT_ENUM time_e)
{

    char    separator = SV_State.separator;
    char    quote = SV_State.quote;
    char    escape = SV_State.escape;
    char* field = NULL;
    int     status = -1;


    switch (SV_State.data)
    {
        case SpacedData:
            field = DBA_GetSpaced(cursor, quote, escape, &status);

            if (status < 0) return -1;

            switch (status)
            {
                case 0:
                    *null = 1;
                    return  0;

                case 1:
                case 2:
                    *null = 0;
                    break;

                case 3:
                    *null = 2;
                    return 0;

            }
            break;

        case DelimitedData:
            field = DBA_GetDelimited(cursor, separator, quote, escape, &status);

            if (status < 0) return -1;

            switch (status)
            {
                case 0:
                    *null = 1;
                    return  0;

                case 1:
                case 2:
                    *null = 0;
                    break;

                case 3:
                    *null = 2;
                    return 0;

            }
            break;

        case FixedData:
            field = DBA_GetFixed(cursor, width, &status);

            if (status < 0) return -1;

            switch (status)
            {
                case 0:
                    *null = 1;
                    return  0;

                case 1:
                    *null = 0;
                    break;

                case 3:
                    *null = 2;
                    return 0;

            }
            break;
    }


    date->date = DATE_CurrentDate();
    date->time = TIME_Put(0, 0, 0);

    status = TRUE;

    if (strcasecmp(field, "TODAY"))
    {
        if (!strcasecmp(field, "YESTERDAY"))
            date->date = DATE_Move(date->date, -1, Day);
        else
            if (!strcasecmp(field, "TOMORROW"))
                date->date = DATE_Move(date->date, 1, Day);
            else
            {
                const char* format = NULL;

                int n = 0;

                while (SV_State.date != SV_Date[n].date)
                    n++;

                format = SV_Date[n].format;

                status = -1;


                if (format != NULL)
                    status = CONV_StrToData(field, time_e > DictAttrib_WgtTypeDateTimeInGui ? DatetimeType : DateType,
                                            format, &date->date, FALSE) == NULL
                    || !date->date ? FALSE : TRUE;
            }
    }

    FREE(field);

    return status == TRUE ? 0 : -1;
}



/************************************************************************
**
**  Function    :   DBA_GetNumber()
**
**  Description :
**
**  Argument    :   cursor
**                  number
**                  null
**                       null == 1 NULL    value
**                       null == 2 NULL_DV value
**
**  Return      :   0 on success, -1 elsewhere
**
*************************************************************************/
STATIC int DBA_GetNumber(char** cursor, double* number, int* null, ...)
{
    va_list arg;

    char separator = SV_State.separator;
    char quote = SV_State.quote;
    char escape = SV_State.escape;

    char* tail;

    char* field = NULL;

    int status = -1;

    *number = 0;

    va_start(arg, null);

    switch (SV_State.data)
    {
        case SpacedData:
            field = DBA_GetSpaced(cursor, quote, escape, &status);

            if (status < 0) return -1;

            switch (status)
            {
                case 0:
                    *null = 1;
                    return 0;

                case 1:
                    *null = 0;
                    break;

                case 2:
                    FREE(field)
                        return -1;

                case 3:
                    *null = 2;
                    return 0;

            }
            break;

        case DelimitedData:
            field = DBA_GetDelimited(cursor, separator, quote, escape, &status);

            if (status < 0) return -1;

            switch (status)
            {
                case 0:
                    *null = 1;
                    return 0;

                case 1:
                    *null = 0;
                    break;

                case 2:
                    FREE(field)
                        return -1;

                case 3:
                    *null = 2;
                    return 0;

            }
            break;

        case FixedData:
            field = DBA_GetFixed(cursor, va_arg(arg, int), &status);

            if (status < 0) return -1;

            switch (status)
            {
                case 0:
                    *null = 1;
                    return  0;

                case 1:
                    *null = 0;
                    break;

                case 3:
                    *null = 2;
                    return 0;

            }
            break;
    }

    va_end(arg);

    if (SV_State.thousand != 0 ||
        SV_State.decimal != '.')
    {
        char* ascii = STRDUP(field);

        char* source = ascii;
        char* target = field;

        char thousand = SV_State.thousand;
        char decimal = SV_State.decimal;

        while (*source)
        {
            if (*source != thousand)
                if (*source == decimal)
                    *target++ = '.';
                else
                    *target++ = *source;

            source++;
        }

        *target = '\0';

        FREE(ascii);
    }

    *number = strtod(field, &tail);

    status = TRUE;
    if (*tail)
        status = FALSE;

    FREE(field);

    return status == TRUE ? 0 : -1;
}




/************************************************************************
**
**  Function    :   DBA_ProcessFields()
**
**  Description :
**
**  Argument    :   fields
**                  cursor
**                  count
**
**  Return      :   0 on success, -1 elsewhere
**
**  Last modif. :   PMSTA-15918 - 070213 - PMO : Fusion on portfolio [T_AI_PE_ST] failed ; upd_exd_position : Attempt to insert NULL value into column 'end_d', table position
**
*************************************************************************/
STATIC int DBA_ProcessFields(DBA_FIELD_STP fields, char* cursor, unsigned* count)
{
    while (fields != NULL)
    {
        double    number;
        char* string;
        DATETIME_ST date;

        int null;

        (*count)++;

        if (fields->type < 0)
        {
            char separator = SV_State.separator;
            char quote = SV_State.quote;
            char escape = SV_State.escape;

            int status = -1;

            char* discard = NULL;

            switch (SV_State.data)
            {
                case SpacedData:
                    discard = DBA_GetSpaced(&cursor, quote, escape, &status);

                    if (status < 0)
                        return -1;
                    break;

                case DelimitedData:
                    discard = DBA_GetDelimited(&cursor, separator, quote, escape, &status);

                    if (status < 0)
                        return -1;
                    break;

                case FixedData:
                    discard = DBA_GetFixed(&cursor, fields->width, &status);

                    if (status < 0)
                        return -1;
                    break;

                default:
                    return -1;
                    break;
            }

            if (discard != NULL)
                FREE(discard);

        }
        else
            switch (fields->type)
            {
                case DateType:
                case DatetimeType:
                    if (!DBA_GetDate(&cursor, &date, &null, fields->width, fields->time_e))
                    {
                        if (!null)
                        {
                            /* PMSTA-15918 - 070213 - PMO */
                            DBA_ConvertCTypeDataToFld(&date
                                                      , DateTimeStCType
                                                      , fields->entity->record
                                                      , fields->index
                                                      , fields->type
                            );
                        }
                        else
                        {
                            if (fields->entity->parent != NULL)
                                fields->entity->skip = TRUE;

                            SET_NOTNULLFLG_F(fields->entity->record, fields->index);

                            if (null == 2)
                                fields->evalDV = TRUE;
                            else
                                fields->evalDV = FALSE;
                        }
                    }
                    else
                        return -1;
                    break;

                default:
                    switch (GET_CTYPE(fields->type))
                    {
                        case UCharCType:
                        case ShortCType:
                        case UShortCType:
                        case IntCType:
                        case UIntCType:
                        case DoubleCType:
                        case LongLongCType:
                            if (!DBA_GetNumber(&cursor, &number, &null, fields->width))
                            {
                                if (!null &&
                                    (GET_CTYPE(fields->type) == UCharCType ||
                                     GET_CTYPE(fields->type) == ShortCType ||
                                     GET_CTYPE(fields->type) == UShortCType
                                     )
                                    )
                                {
                                    if (fields->entity->object != ScreenProfCompo &&
                                        fields->index != A_ScreenProfCompo_NatEn &&
                                        DBA_CheckPermVal(fields->entity->object, fields->index, (int)number) == FALSE)
                                        return -1;
                                }

                                if (!null)
                                    DBA_ConvertCTypeDataToFld(&number
                                                              , DoubleCType
                                                              , fields->entity->record
                                                              , fields->index
                                                              , fields->type
                                    );
                                else
                                {
                                    if (fields->entity->parent != NULL)
                                        fields->entity->skip = TRUE;

                                    SET_NOTNULLFLG_F(fields->entity->record, fields->index);

                                    if (null == 2)
                                        fields->evalDV = TRUE;
                                    else
                                        fields->evalDV = FALSE;

                                }
                            }
                            else
                                return -1;
                            break;

                        case CharPtrCType:
                        case TextPtrCType:
                            if (!DBA_GetString(&cursor, &string, &null, fields->width))
                            {
                                int status = 0;

                                if (!null)
                                {
                                    if (fields->type == NoteType)
                                    {
                                        DBA_ENTITY_STP entity = fields->entity;

                                        if (entity->parent == NULL && DBA_isScriptObject(entity->object))
                                        {
                                            size_t n = strlen(string);

                                            status = strcspn(string, "'") == n ? 0 : -1;
                                        }
                                        else
                                            status = DBA_CheckString(fields->type, string, fields->entity->record, (FIELD_IDX_T)fields->index);
                                    }
                                    else
                                        status = DBA_CheckString(fields->type, string, fields->entity->record, (FIELD_IDX_T)fields->index);

                                    if (!status)
                                    {
                                        DBA_ConvertCTypeDataToFld(string
                                                                  , GET_CTYPE(fields->type)
                                                                  , fields->entity->record
                                                                  , fields->index
                                                                  , fields->type
                                        );
                                    }

                                    FREE(string);
                                }
                                else
                                {
                                    if (fields->entity->parent != NULL)
                                        fields->entity->skip = TRUE;

                                    SET_NOTNULLFLG_F(fields->entity->record, fields->index);

                                    if (null == 2)
                                        fields->evalDV = TRUE;
                                    else
                                        fields->evalDV = FALSE;

                                }

                                if (status)
                                    return -1;
                            }
                            else
                                return -1;
                            break;

                        default:
                            break;
                    }
                    break;
            }

        fields = fields->next;
    }

    *count = 0;

    return 0;
}










/************************************************************************
**
**  Function    :   DBA_SetDomainObjId()
**
**  Description :   retrieve object Id of the entity attached to the
**                  port_object_id, instr_object_id or strat_object_id
**
**  Argument    :
**
**
**  Return      :
**
*************************************************************************/
RET_CODE DBA_SetDomainObjId(char* psz, DBA_DYNFLD_STP domain)
{
    char* pszTmp;
    char            pszAttr[100];   /*  Name of attribute where to save object_id */
    char            pszEnt[100];    /*  Name of entity of the object_id     */
    OBJECT_ENUM     subObjEnum;     /*  object enum for the object_id       */
    DBA_DYNST_ENUM  dynEnum;        /*  Type of entity for alloc dynObjStp  */
    DBA_DYNST_ENUM  shdynEnum;      /*  Type of entity for alloc dynObjStp  */
    int             iCode;          /*  index of the code                   */
    int             iShCode;        /*  index of the code                   */
    int             iIndexObj;      /*  index of the object_id              */
    int             iIndexDom;      /*  index of the object_id in the domain*/
    DBA_DYNFLD_STP  dbaDynObjStp;   /*  To get the id to insert into the object_id */
    DBA_DYNFLD_STP  shDbaDynTmpStp; /*  temporary DYNFLD to get the id      */
    DBA_DYNFLD_STP  allDbaDynTmpStp;/*  temporary DYNFLD to get the id      */
    RET_CODE        retCode;

    retCode = RET_SUCCEED;

    if ((psz == NULL) ||
        (domain == NULL))
        return RET_GEN_ERR_INVARG;

    /* get the name of attribute object_id */
    if ((pszTmp = strchr(psz + 1, '=')) != NULL)
    {
        strncpy(pszAttr, psz + 1, pszTmp - (psz + 1));
        pszAttr[pszTmp - (psz + 1)] = '\0';

        /* get the entity attached to the object_id */
        if ((psz = strchr(pszTmp + 1, '=')) != NULL)
        {
            strncpy(pszEnt, pszTmp + 1, psz - (pszTmp + 1));
            pszEnt[psz - (pszTmp + 1)] = '\0';

            /* get the OBJECT_ENUM of the entity */
            if (strcmp(pszEnt, "portfolio") == 0)
            {
                subObjEnum = Ptf;
                dynEnum = A_Ptf;
                shdynEnum = S_Ptf;
                iCode = A_Ptf_Cd;
                iShCode = S_Ptf_Cd;
                iIndexObj = A_Ptf_Id;
            }
            else if (strcmp(pszEnt, "instr") == 0)
            {
                subObjEnum = Instr;
                dynEnum = A_Instr;
                shdynEnum = S_Instr;
                iCode = A_Instr_Cd;
                iShCode = S_Instr_Cd;
                iIndexObj = A_Instr_Id;
            }
            else if (strcmp(pszEnt, "strat") == 0)
            {
                subObjEnum = Strat;
                dynEnum = A_Strat;
                shdynEnum = S_Strat;
                iCode = A_Strat_Cd;
                iShCode = S_Strat_Cd;
                iIndexObj = A_Strat_Id;
            }
            else if (strcmp(pszEnt, "list") == 0)
            {
                subObjEnum = List;
                dynEnum = A_List;
                shdynEnum = S_List;
                iCode = A_List_Cd;
                iShCode = S_List_Cd;
                iIndexObj = A_List_Id;
            }
            else
            {
                subObjEnum = NullEntity;
                dynEnum = NullDynSt;
                shdynEnum = NullDynSt;
                iCode = -1;
                iShCode = -1;
                iIndexObj = -1;
            }

            /* get the index of the attribute */
            if (strcmp(pszAttr, "port_object_id") == 0)
                iIndexDom = A_Domain_PtfObjId;
            else if (strcmp(pszAttr, "instr_object_id") == 0)
                iIndexDom = A_Domain_InstrObjId;
            else if (strcmp(pszAttr, "strat_object_id") == 0)
                iIndexDom = A_Domain_StratObjId;
            else
                iIndexDom = -1;

            if ((subObjEnum != NullEntity) &&
                (dynEnum != NullDynSt) &&
                (iIndexDom >= 0) &&
                (iIndexObj >= 0))
            {
                if (((retCode = DBA_GetDynStpFromString(subObjEnum, TRUE, psz, &(dbaDynObjStp))) == RET_SUCCEED) &&     /*  FIH-REF10666-041005 Add test on RET_SUCCEED */
                    (IS_NULLFLD(dbaDynObjStp, iCode) == FALSE))
                {

                    /* Test allocations */
                    if ((shDbaDynTmpStp = ALLOC_DYNST(shdynEnum)) == NULL)
                    {
                        FREE_DYNST(shDbaDynTmpStp, shdynEnum);
                        MSG_RETURN(RET_MEM_ERR_ALLOC);
                    }

                    /* Test allocations */
                    if ((allDbaDynTmpStp = ALLOC_DYNST(dynEnum)) == NULL)
                    {
                        FREE_DYNST(allDbaDynTmpStp, dynEnum);
                        MSG_RETURN(RET_MEM_ERR_ALLOC);
                    }

                    SET_CODE(shDbaDynTmpStp, iShCode, GET_CODE(dbaDynObjStp, iCode));

                    if ((subObjEnum == List) &&
                        (IS_NULLFLD(dbaDynObjStp, A_List_EntityDictId) == FALSE))
                        SET_ID(shDbaDynTmpStp, S_List_EntityDictId, GET_ID(dbaDynObjStp, A_List_EntityDictId))

                        if ((retCode = DBA_Get2(subObjEnum
                                                , UNUSED
                                                , shdynEnum
                                                , shDbaDynTmpStp
                                                , dynEnum
                                                , &allDbaDynTmpStp
                                                , UNUSED
                                                , UNUSED
                                                , (DBA_ERRMSG_INFOS_STP)NULL)) == RET_SUCCEED)
                        {
                            SET_ID(domain
                                   , iIndexDom
                                   , GET_ID(allDbaDynTmpStp, iIndexObj)
                            );

                        }

                    FREE_DYNST(shDbaDynTmpStp, shdynEnum);
                    FREE_DYNST(allDbaDynTmpStp, dynEnum);


                }

                FREE_DYNST(dbaDynObjStp, dynEnum);
            }

        }
    }

    return retCode;
}



/************************************************************************
**
**  Function    :   DBA_GetFirstAttDatFromStr()
**
**  Description :   retrive the first attribute and his value from given string
**                  DON'T FORGET TO FREE pszAttribute and pszValue AFTER USE
**
**  Argument    :
**
**
**  Return      :
**
**  Last modif. :   PMSTA-15334 - 091112 - PMO : Random GUI fatal errors after successful login into the application
**                  PMSTA-16124 - 250413 - PMO : Ensure coherence of printf / scanf formats with 32bits / 64 bits datatypes
**
*************************************************************************/
RET_CODE  DBA_GetFirstAttDatFromStr(char** pszInputStr, char** pszAttribute, char** pszValue)
{

    char* pszTmp;
    char* pszTmpAttr;
    char* pszTmpVal;
    char* pszAttrVal;    /* string formated : "attribute=value' */
    unsigned char           chSeparator;
    char                    recordSeparator[2];         /* FPL-REF9303-030916 ";"  */
    char                    szSeparator[2];
    char                    szRecordSeparator[3];       /* FPL-REF9303-030916 "; " */
    CURRENTCHARSETCODE_ENUM currCharset = CurrentCharsetCode_IsNull;



    pszTmpAttr = NULL;
    pszTmpVal = NULL;
    pszAttrVal = NULL;

    recordSeparator[0] = SV_CharRecordSeparator;    /* FPL-REF9303-031008 59 -> 30 */
    recordSeparator[1] = '\0';

    szRecordSeparator[0] = SV_CharRecordSeparator;  /* FPL-REF9303-031008 59 -> 30 */
    szRecordSeparator[1] = ' ';
    szRecordSeparator[2] = '\0';

    /* test for security */
    if (*pszInputStr == NULL)
        MSG_RETURN(RET_GEN_ERR_INVARG);

    /* FPL-REF9303-030916 */
    /*    if (ICU4AAA_SQLServerUTF8 != 0)   FPL-REF9303-031008 always the same separator
    {
    */
    chSeparator = SV_CharUnitSeparator;        /* caract�re US - Unit Separator   */
    /*        recordSeparator[0] = 30;*/    /* caract�re RS - Record Separator */

    /*        szRecordSeparator[0] = 30;*/
    /*
    }
    else
    {
    */
    /* get separator */
    /*        GEN_GetApplInfo(ApplCurrentCharsetCodeEnum, &currCharset);    FPL-REF9303-031008 always the same separator

    switch (currCharset)
    {
    case CurrentCharsetCode_Iso_1 :
    chSeparator = 164;
    break;

    case CurrentCharsetCode_Roman8:
    chSeparator = 186;
    break;

    default:
    chSeparator = 164;
    break;
    }
    }
    */
    szSeparator[0] = chSeparator;
    szSeparator[1] = '\0';



    /* get string contaning attribute and value */
    /*    pszTmp = strstr(*pszInputStr, recordSeparator);*/     /* FPL-REF9303-030916 ";" -> recordSeparator */             /* FPL-REF9303-031008 always the same separator */
    /*    if (pszTmp == NULL)   */  /* FPL-REF9303-030916 if separator not found in string, we use the other separator */   /* FPL-REF9303-031008 always the same separator */
    /*    {
    if (recordSeparator[0] == 59)
    {
    recordSeparator[0]   = 30 ;
    szRecordSeparator[0] = 30 ;
    chSeparator          = 31 ;
    }
    else
    {
    recordSeparator[0]   = 59 ;
    szRecordSeparator[0] = 59 ;


    GEN_GetApplInfo(ApplCurrentCharsetCodeEnum, &currCharset);

    switch (currCharset)
    {
    case CurrentCharsetCode_Iso_1 :
    chSeparator = 164;
    break;

    case CurrentCharsetCode_Roman8:
    chSeparator = 186;
    break;

    default:
    chSeparator = 164;
    break;
    }

    }

    szSeparator[0]       = chSeparator ;
    */
    pszTmp = strstr(*pszInputStr, recordSeparator);
    /*    }
    */

    /*** FPL-REF9303-031022 Fatal error when lunching old macro. We need to do this to keep compatibility ***/
    if (pszTmp == NULL)
    {
        if (recordSeparator[0] == 59)
        {
            recordSeparator[0] = SV_CharRecordSeparator;
            szRecordSeparator[0] = SV_CharRecordSeparator;
            chSeparator = SV_CharUnitSeparator;
        }
        else
        {
            recordSeparator[0] = 59;
            szRecordSeparator[0] = 59;


            GEN_GetApplInfo(ApplCurrentCharsetCodeEnum, &currCharset);

            switch (currCharset)
            {
                case CurrentCharsetCode_Iso_1:
                    chSeparator = 164;
                    break;

                case CurrentCharsetCode_Roman8:
                    chSeparator = 186;
                    break;

                default:
                    chSeparator = 164;
                    break;
            }

        }

        szSeparator[0] = chSeparator;

        pszTmp = strstr(*pszInputStr, recordSeparator);
    }
    /******/

    /* PMSTA-15334 - 091112 - PMO */
    if (NULL == pszTmp)
    { /* Parsing error */
        *pszAttribute = NULL;
        *pszValue = NULL;
        *pszInputStr = NULL;
        return RET_SUCCEED;
    }

    ptrdiff_t pPosition = pszTmp - *pszInputStr;                                                /* PMSTA-16124 - 250413 - PMO */
    if ((pszAttrVal = (char*)REALLOC(pszAttrVal, (pPosition + 1) * sizeof(char))) == NULL)
        MSG_RETURN(RET_MEM_ERR_ALLOC);

    strncpy(pszAttrVal, *pszInputStr, pPosition);
    pszAttrVal[pPosition] = '\0';

    /* get value */
    pszTmpVal = strstr(pszAttrVal, "=");
    pszTmpVal++;

    /* get attribute */
    pPosition = pszTmpVal - pszAttrVal - 1;                                                     /* PMSTA-16124 - 250413 - PMO */
    pszTmpAttr = pszAttrVal;
    pszTmpAttr[pPosition] = '\0';

    /* reformat value */
    if ((unsigned char)pszTmpVal[0] == chSeparator)
    {
        pszTmpVal++;
        pszTmp = strstr(pszTmpVal, szSeparator);
        pPosition = pszTmp - pszTmpVal;                                                         /* PMSTA-16124 - 250413 - PMO */
        pszTmpVal[pPosition] = '\0';
    }


    /* manage next attribute */
    *pszInputStr = strstr(*pszInputStr, szRecordSeparator) + 2; /* 1 for the ';' and 1 for ' ' */   /* FPL-REF9303-030916 "; " -> szRecordSeparator */

    if ((*pszInputStr[0] == 10) ||
        (*pszInputStr[0] == '\0'))
        *pszInputStr = NULL;

    if ((*pszAttribute = (char*)REALLOC(*pszAttribute, ((strlen(pszTmpAttr) + 1) * sizeof(char)))) == NULL)
        MSG_RETURN(RET_MEM_ERR_ALLOC);

    if ((*pszValue = (char*)REALLOC(*pszValue, ((strlen(pszTmpVal) + 1) * sizeof(char)))) == NULL)
        MSG_RETURN(RET_MEM_ERR_ALLOC);


    strcpy(*pszAttribute, pszTmpAttr);
    strcpy(*pszValue, pszTmpVal);

    FREE(pszAttrVal);

    return RET_SUCCEED;

}




/************************************************************************
**
**  Function    :   DBA_GetStringFromDynStp
**
**  Description :   Convert DynStp
**
**  Argument    :   dictEntity
**
**
**  Return      :   pointer to string
**
**  Last modif. :   PMSTA-30823 - 050418 - PMO : SCPT_FmtEltAnalyse: Source and destination overlap in mempcpy
**              :   HFI-PMSTA-41842-200916  replace DBA_ConvertDynStToString by DBA_ConvertDynStToString2 to manage onlyBusinessKeyFlg and add flagJSonSyntax
**
*************************************************************************/
char* DBA_GetStringFromDynStp(DBA_DYNFLD_STP dynStp, OBJECT_ENUM objectEnum, FLAG_T flagShortStruct, FLAG_T onlyBusinessKeyFlg, FLAG_T flagJSonSyntax)
{
    DbiConnectionHelper     dbiConnHelper;
    char* psz;
    char* pszTmp;
    char* pszCursor;
    char* pszCursorBeforeMove;
    char* pszAttribute = NULL;
    char* pszValue = NULL;
    DBA_DYNST_ENUM          enDbaDynst;             /*  FIH-REF9867-040121              */

    /* test for security */
    if (dynStp == NULL || !dbiConnHelper.isValidAndInit())
        return (char*)NULL;

    /*  FIH-REF9867-040121                  */
    if (flagShortStruct == FALSE)
        enDbaDynst = GET_EDITGUIST(objectEnum);
    else
        enDbaDynst = GET_ADMINGUIST(objectEnum);

    if (DBA_ConvertDynStToString2(objectEnum                       /* object enum          */
                                  , enDbaDynst                       /* all or short         */
                                  , dynStp                           /* structure            */
                                  , 0                                /* level of recursivity */
                                  , flagShortStruct                  /* FALSE=all,TRUE=short */  /*  FIH-REF9867-040121  Replace FALSE by flagShortStruct    */
                                  , NULL                             /* denom                */
                                  , &psz                             /* output string        */
                                  , UNUSED
                                  , FALSE
                                  , FALSE                            /*  FIH-REF10666-041005 Do not save virtual fields  */
                                  , *dbiConnHelper.getConnection()
                                  , FALSE	                        /* truncation DLA - PMSTA-12367 - 110719 */
                                  , onlyBusinessKeyFlg
                                  , flagJSonSyntax) == RET_SUCCEED)
    {
        /*  No need to remove the null value for JSon string        */  /*  HFI-PMSTA-41842-200916  */
        if (flagJSonSyntax == FALSE)
        {
            pszCursor = psz;

            /* eliminate NULL values from the string generated */
            while (pszCursor != NULL)
            {
                pszCursorBeforeMove = pszCursor;

                DBA_GetFirstAttDatFromStr(&pszCursor, &pszAttribute, &pszValue);
                if ((pszValue != nullptr) &&
                    (strcmp(pszValue, "NULL") == 0))
                {
                    if ((pszTmp = (char*)CALLOC((strlen(psz) + 1), sizeof(char))) == NULL)
                    {
                        FREE(pszAttribute);
                        FREE(pszValue);
                        return NULL;
                    }

                    strncpy(pszTmp, psz, (pszCursorBeforeMove - psz));

                    if (pszCursor != NULL)
                        strcat(pszTmp, pszCursor);      /* PMSTA-30823 - 050418 - PMO */

                    strcpy(psz, pszTmp);

                    if (pszCursor != NULL)
                        pszCursor = pszCursorBeforeMove;

                    FREE(pszTmp);

                }
                FREE(pszAttribute);
                FREE(pszValue);
            }
        }

        if ((psz = (char*)REALLOC(psz, (strlen(psz) + 1) * sizeof(char))) == NULL)
        {
            FREE(pszAttribute);
            FREE(pszValue);
            return NULL;
        }
        return psz;
    }
    return (char*)NULL;
}

/************************************************************************
**
**  Function    :   DBA_GetDynStpFromString()
**
**  Description :
**
**  Argument    :   entity
**                  index
**
**  Return      :
**
**  Last modif. :   PMSTA-15334 - 091112 - PMO : Random GUI fatal errors after successful login into the application
**                  PMSTA-30823 - 050418 - PMO : SCPT_FmtEltAnalyse: Source and destination overlap in mempcpy
**
*************************************************************************/
RET_CODE DBA_GetDynStpFromString(OBJECT_ENUM objectEnum, FLAG_T mainFlg, char* pszBrutString, DBA_DYNFLD_STP* pDynStp)
{
    char* pszAttLine;
    char* pszDatLine;
    char* pszAttribute = NULL;
    char* pszValue = NULL;


    /* some initialization */

    SV_State.quote = '\"'; /* = -1 */
    SV_State.escape = '\\'; /* = -1 */
    SV_State.separator = ';';
    SV_State.decimal = '.';
    SV_State.thousand = 0;    /* = -1 */
    SV_State.translations = NULL;
    SV_State.codifications = NULL;
    SV_State.automatics = NULL;
    SV_State.date = SDMYDate;
    SV_State.action = InsertAction;
    SV_State.fields = NULL;
    SV_State.values = NULL;
    SV_State.copies = NULL;
    SV_State.source = NULL;
    SV_State.target = (DBA_ENTITY_STP)REALLOC(NULL, sizeof(DBA_ENTITY_ST));
    SV_State.target->parent = NULL;
    SV_State.target->index = -1;
    SV_State.target->next = NULL;
    SV_State.target->child = NULL;
    SV_State.target->main = mainFlg;
    SV_State.target->skip = FALSE;
    SV_State.target->object = objectEnum;
    SV_State.target->record = ALLOC_DYNST(GET_EDITGUIST(objectEnum));
    SV_State.handlers = NULL;
    SV_State.sf = NULL;
    SV_State.tf = (FLAG_T*)CALLOC(GET_FLD_NBR(GET_EDITGUIST(objectEnum)), sizeof(FLAG_T));
    SV_State.data = DelimitedData;





    /* delete first '=' */
    if ((pszBrutString[1] == 10) || (pszBrutString[1] == '\0'))
        return RET_GEN_ERR_INVARG;
    else
        pszBrutString++;


    if ((pszAttLine = (char*)CALLOC(5, sizeof(char))) == NULL)
        MSG_RETURN(RET_MEM_ERR_ALLOC);

    if ((pszDatLine = (char*)CALLOC(5, sizeof(char))) == NULL)
        MSG_RETURN(RET_MEM_ERR_ALLOC);

    strcpy(pszAttLine, "ATT ");
    strcpy(pszDatLine, "DAT ");

    while (pszBrutString != NULL)
    {
        DBA_GetFirstAttDatFromStr(&pszBrutString, &pszAttribute, &pszValue);
        /* if value is not null, we  insert it into the dynFld / PMSTA-15334 - 091112 - PMO */
        if (NULL != pszValue && strcmp(pszValue, "NULL") != 0)
        {
            int iSize = SYS_StrLen(pszAttLine) + SYS_StrLen(pszAttribute) + 2;
            if ((pszAttLine = (char*)REALLOC(pszAttLine, iSize * sizeof(char))) == NULL)
                MSG_RETURN(RET_MEM_ERR_ALLOC);

            char* endBuffer1 = pszAttLine + strlen(pszAttLine);                             /* PMSTA-30823 - 050418 - PMO */
            sprintf(endBuffer1, "%s ", pszAttribute);

            iSize = SYS_StrLen(pszDatLine) + SYS_StrLen(pszValue) + 2;
            if ((pszDatLine = (char*)REALLOC(pszDatLine, iSize * sizeof(char))) == NULL)
                MSG_RETURN(RET_MEM_ERR_ALLOC);

            char* endBuffer2 = pszDatLine + strlen(pszDatLine);                             /* PMSTA-30823 - 050418 - PMO */
            sprintf(endBuffer2, "%s;", pszValue);
        }

        FREE(pszAttribute);
        FREE(pszValue);
    }





    if (DBA_ParseATTLine(pszAttLine + 4) == 0)  /* +4 to have string after the "ATT " */
    {
        unsigned        count = 0;
        DBA_ENTITY_STP  entity = NULL;

        if (DBA_ProcessFields(SV_State.fields, pszDatLine + 4, &count) == 0)
        {
            if ((DBA_ProcessEntities(SV_State.source, &entity) == 0) &&
                (DBA_ProcessEntities(SV_State.target, &entity) == 0))
            {
                if (SV_State.target != NULL)
                    *pDynStp = SV_State.target->record;
                else
                    return RET_LEV_ERROR;
            }
        }
    }
    else
        return RET_GUI_INFO_LOAD_DOMAIN;            /*  FIH-REF10666-041005 */

    return RET_SUCCEED;

}

/************************************************************************
**
**  Function    :   DBA_GetRightsOnDeleteExtOp()
**
**  Description :   Get acces on Delete for ExtOp considering the order context
**
**  Argument    :   inputExtOp      : extOp record
**                  secuCheck       : right access record
**
**  Return      :   FLAG_T - true if user has access rights, false otherwise
**
**  Created     :   PMSTA16676-CHU-130729
*************************************************************************/
STATIC RET_CODE DBA_GetRightsOnDeleteExtOp(DBA_DYNFLD_STP		inputExtOp,
                                           DBA_DYNFLD_STP		secuCheck,
                                           FLAG_T* rightsResult)
{
    RET_CODE ret = RET_SUCCEED;
    FLAG_T applOrderDeletionRightFlag = FALSE;

    GEN_GetApplInfo(ApplOrderDeletionRightFlag, &applOrderDeletionRightFlag);
    *rightsResult = GET_FLAG(secuCheck, SecuCheck_FctDelete);

    if (applOrderDeletionRightFlag != TRUE)
    {
        /* Keep previous behaviour */
        /* PMSTA14504 - DDV - 120814 - Exception for session's order, portoflio's update rigths is used to delete it */
        if (GET_FLAG(inputExtOp, ExtOp_InSessionFlg) == TRUE)
            *rightsResult = GET_FLAG(secuCheck, SecuCheck_FctUpdate);
    }
    else
    {
        DBA_DYNFLD_STP	tmpExtOp = NULL;
        DBA_DYNFLD_STP	sFctResultPtr = NULL, fctResStp = NULL;
        OPSTAT_ENUM     accountingStatus = OpStat_Cancelled;
        OPSTAT_ENUM		applExternalPosStatus = OpStat_Cancelled;

        /* If record not fully provided - check on ptf_id ? it's the case for ext_order ? */
        if (IS_NULLFLD(inputExtOp, ExtOp_PtfId) == TRUE)
        {
            ret = FMT_GetOrderRecord(NULL, &tmpExtOp,
                                     DBA_GetOpIdFromExtOp(inputExtOp),
                                     GET_FLAG(inputExtOp, ExtOp_InSessionFlg) == TRUE ? GET_CODE(inputExtOp, ExtOp_Cd) : GET_CODE(inputExtOp, S_Op_Cd),
                                     GET_FLAG(inputExtOp, ExtOp_InSessionFlg),
                                     FALSE);
        }
        else
            tmpExtOp = inputExtOp;

        GEN_GetApplInfo(ApplAccountingStatus, &accountingStatus);
        GEN_GetApplInfo(ApplExternalPosStatus, &applExternalPosStatus);

        if (IS_NULLFLD(tmpExtOp, ExtOp_StatusEn) == FALSE &&
            ((OPSTAT_ENUM)GET_ENUM(tmpExtOp, ExtOp_StatusEn) == applExternalPosStatus ||
             (OPSTAT_ENUM)GET_ENUM(tmpExtOp, ExtOp_StatusEn) < accountingStatus))
        {
            if ((sFctResultPtr = ALLOC_DYNST(S_FctResult)) == NULL)
            {
                MSG_RETURN(RET_MEM_ERR_ALLOC);
            }

            if ((fctResStp = ALLOC_DYNST(A_FctResult)) == NULL)
            {
                FREE_DYNST(sFctResultPtr, S_FctResult);
                MSG_RETURN(RET_MEM_ERR_ALLOC);
            }

            if (IS_NULLFLD(tmpExtOp, ExtOp_StatusEn) == FALSE)
            {
                SET_ID(sFctResultPtr, S_FctResult_Id, GET_ID(inputExtOp, ExtOp_FctResultId));

                if ((ret = DBA_Get2(FctResult, UNUSED, S_FctResult, sFctResultPtr,
                                    A_FctResult, &fctResStp, UNUSED, UNUSED, UNUSED)) != RET_SUCCEED)
                {
                    FREE_DYNST(sFctResultPtr, S_FctResult);
                    FREE_DYNST(fctResStp, A_FctResult);
                    return(RET_SRV_LIB_ERR_COMMAND_ABORTED);
                }
                FREE_DYNST(sFctResultPtr, S_FctResult);

                if (((FCTRESULTSTATUS_ENUM)GET_ENUM(fctResStp, A_FctResult_StatusEn) != /*FctResultStatus_Draft*/FctResultStatus_Final) &&
                    ((FCTRESULTSTATUS_ENUM)GET_ENUM(fctResStp, A_FctResult_StatusEn) != FctResultStatus_Failed))            /*  HFI-PMSTA-31893-180725  Failed session are managed as final session */
                {
                    *rightsResult = GET_FLAG(secuCheck, SecuCheck_FctUpdate);
                }
                FREE_DYNST(fctResStp, A_FctResult);
            }
        }
    }

    return(ret);
}

/************************************************************************
**
**  Function    :   DBA_CheckSecuCheck()
**
**  Description :   Checks the security rights/access for a user, function
**                  formed from existing code (previously) in scptfct1.c
**
**  Argument    :   domain          : current domain
**                  inputRec        : dynamic record
**                  adminRights     : rights being checked
**                  objectEnum      : entity ref'
**                  hierHeadPtr     : hierarchy head ptr
**                  checkDP         : flag; check data profile
**                  checkFSP        : flag; check function security porfile
**                  freeInputRecFlg : flag; whether to free inputRec before return
**
**  Return      : FLAG_T - true if user has access rights, false otherwise
**
*************************************************************************/
FLAG_T DBA_CheckSecuCheck(DBA_DYNFLD_STP    domain,
                          DBA_DYNFLD_STP    inputRec,
                          ADMIN_RIGHTS_ENUM adminRights,
                          OBJECT_ENUM       objectEnum,
                          PTR               hierHeadPtr,
                          FLAG_T            checkDP,
                          FLAG_T            checkFSP,
                          FLAG_T            freeInputRecFlg)
{
    DBA_DYNFLD_STP    secuCheck = NULL;
    DBA_HIER_HEAD_STP hierHead = (DBA_HIER_HEAD_STP)hierHeadPtr;
    FLAG_T            rightsResult = FALSE;
    FLAG_T            continueFlg = TRUE;
    int               result = 0;
    ID_T              connUserDpId = 0;
    ID_T              wuiUserDpId = 0;
    ID_T              checkId = 0;
    OBJECT_ENUM       checkObjectEnum = NullEntity;
    DBA_DYNFLD_STP    checkRec = NULL;
    DICT_T            dictFunction = DictFct_Admin;             /*  HFI-PMSTA-22333-160207  */
    MemoryPool        mp;

    /*  Check licence security                                          */  /*  HFI-PMSTA-35838-190515  */
    DICT_ENTITY_STP     pdictent = DBA_GetDictEntitySt(objectEnum);
    if ((pdictent != NULL) &&
        (pdictent->licenseKeyEn != DictLicenseKey_None) &&
        (pdictent->licenseAccessStatusEn != DictFctAuth_Ok))
        return FALSE;

    /*  ESE are not yet managed by DP or FSP                            */  /*  HFI-PMSTA-16826-130823  */
    /*  FUTURE MANAGEMENT:                                              */
    /*  - DP should be checked via sessionId (A_DictEntity_ParIndex ?)  */
    /*  - FSP via A_DictEntity_AdminFctDictId                           */
    if (objectEnum == EStratElt)
        return TRUE;

    /* ApplSession and ApplSessionHisto can not be managed directly     */
    /* through eval entity                                              */
    /* PMSTA-27037 - TEB - 170802                                       */
    if (objectEnum == ApplSession || objectEnum == ApplSessionHisto)
        return FALSE;

    if ((secuCheck = ALLOC_DYNST(SecuCheck)) == NULL)
    {
        if (freeInputRecFlg == TRUE) { FREE_DYNST(inputRec, GET_EDITGUIST(objectEnum)) };
        return FALSE;               /*  Replace RET_SUCCEED by FLASE    */  /*  HFI-PMSTA-16826-130823  */
    }

    if (checkDP != FALSE)
    {
        if (DBA_GetUserInfo2(A_ApplUser_DataProfileId, &connUserDpId, FALSE) == RET_SUCCEED &&
            DBA_GetUserInfo2(A_ApplUser_DataProfileId, &wuiUserDpId, TRUE) == RET_SUCCEED)
        {
            /* PMSTA14504 - DDV - 120814 - Treat exceptions (operation and orders data security is based on porfolio's rigths) */
            switch (GET_OBJECT_CST(objectEnum))
            {
                case EOpCst:
                    checkObjectEnum = Ptf;
                    checkId = GET_ID(inputRec, ExtOp_PtfId);
                    break;

                case OpCst:
                    checkObjectEnum = Ptf;
                    checkId = GET_ID(inputRec, A_Op_PtfId);
                    break;

                default:
                    checkObjectEnum = objectEnum;
                    checkRec = inputRec;
                    break;
            }

            /* PMSTA14504 - DDV - 120814 - If check record is NULL, it must be loaded */
            if (checkRec == NULL)
            {
                if (hierHead == NULL ||
                    DBA_GetRecPtrFromHierById(hierHead, checkId, GET_EDITGUIST(checkObjectEnum),
                                              &checkRec) != RET_SUCCEED ||
                    checkRec == NULL)
                {
                    DBA_GetRecordById(checkObjectEnum, checkId, GET_EDITGUIST(checkObjectEnum), &checkRec, mp);
                }
            }

            if (checkRec != NULL)
            {
                /* PMSTA14504 - DDV - 120814 - First check that connection usser has access to dp (multi tasc login) */
                if (connUserDpId == wuiUserDpId || FMT_CheckDP(checkObjectEnum, checkRec, connUserDpId, secuCheck) == RET_SUCCEED)
                {
                    result = FMT_CheckDP(checkObjectEnum, checkRec, wuiUserDpId, secuCheck);

                    switch (adminRights)
                    {
                        case AdminRights_View:
                            if (result == RET_SUCCEED)
                                rightsResult = TRUE;
                            else
                            {
                                rightsResult = FALSE;
                                continueFlg = FALSE;
                            }
                            break;

                        case AdminRights_Create: /* Data profile don't define rights for creation */
                            break;

                        case AdminRights_Update:
                            rightsResult = GET_FLAG(secuCheck, SecuCheck_FctUpdate);
                            if (rightsResult == FALSE)
                                continueFlg = FALSE;
                            break;

                        case AdminRights_Delete:
                            /* PMSTA16679-CHU-130729 : code replaced by call to DBA_GetRightsOnDeleteExtOp() */
                            /* PMSTA14504 - DDV - 120814 - Exception for session's order, portoflio's update rigths is used to delete it */
                            /* if (objectEnum == EOp && GET_FLAG(inputRec, ExtOp_InSessionFlg) == TRUE)
                            rightsResult = GET_FLAG(secuCheck ,SecuCheck_FctUpdate);
                            */
                            /* PMSTA16679-CHU-130729 */
                            if (objectEnum == EOp)
                                DBA_GetRightsOnDeleteExtOp(inputRec, secuCheck, &rightsResult);
                            else
                                rightsResult = GET_FLAG(secuCheck, SecuCheck_FctDelete);

                            if (rightsResult == FALSE)
                                continueFlg = FALSE;
                            break;
                    }
                }
            }
            /*  No record No rights                 */  /*  HFI-PMSTA-33341-181204  */
            else
            {
                rightsResult = FALSE;
                continueFlg = FALSE;
            }
        }
    }

    if (checkFSP != FALSE && continueFlg == TRUE)
    {
        if (inputRec != NULL)
        {
            /* TGU - PMSTA13889 - 120421 - Create a temp Hierarchy */
            DBA_HIER_HEAD_STP tmpHier = NULL;
            if ((tmpHier = DBA_CreateHier()) == NULL)
            {
                FREE_DYNST(secuCheck, SecuCheck);
                rightsResult = FALSE;
                return (rightsResult);
            }

            /*  Found the right administration function             */      /*  HFI-PMSTA-22333-160207  */
            DBA_GetAdmDictFct(objectEnum, NULL, &dictFunction);

            result = FMT_GetRightFunction(inputRec,                /* DBA_DYNFLD_STP       dynRecord */
                                          objectEnum,              /* OBJECT_ENUM          entityRef */         /*  FIH-PMSTA02031-070403   */
                                          domain,                  /* DBA_DYNFLD_STP       dynDomain */
                                          tmpHier,                 /* DBA_HIER_HEAD_STP    phier */				/* TGU - PMSTA13889 -120421*/
                                          (SCPT_FMTDATADEF_STP)NULL,/* SCPT_FMTDATADEF_STP  pscptFmtDataDef */
                                          objectEnum,              /* OBJECT_ENUM          entityRef */
                                          dictFunction,            /* DICT_T               dictFunction */      /*  Replace DictFct_Admin by dictFunction   */  /*  HFI-PMSTA-22333-160207  */
                                          NULL,                    /* DICT_FCT_STP         dictFctOri */
                                          ScriptDef_ActEn_None,    /* SCRIPTDEFACT_ENUM    actionEn */
                                          TRUE,                    /* FLAG_T               flagCheckFctSecu */
                                          FALSE,                   /* FLAG_T               flagCheckPtfSecu */
                                          FALSE,                   /* FLAG_T               flagCheckScriptSecu */
                                          TRUE,                    /* FLAG_T               addedEntityFlg */
                                          NULL,                    /* RET_CODE             (*pFctGetPtfFieldIndex)(PTR, DBA_DYNFLD_STP, int*) */
                                          NULL,                    /* int                  (*pFctGuiRights)(PTR, DICT_FCT_STP, DBA_DYNFLD_STP) */
                                          NULL,                    /* PTR                  pRupStp */
                                          secuCheck,               /* DBA_DYNFLD_STP       secuCheck */
                                          NULL);                   /* DBA_DYNFLD_STP       record */

            switch (adminRights)
            {
                case AdminRights_View: /* View action is not managed in FMT_GetRightsFunction, don't update it */
                    break;

                case AdminRights_Create:
                    rightsResult = GET_FLAG(secuCheck, SecuCheck_FctCreate);
                    break;

                case AdminRights_Update:
                    rightsResult = GET_FLAG(secuCheck, SecuCheck_FctUpdate);
                    break;

                case AdminRights_Delete:
                    rightsResult = GET_FLAG(secuCheck, SecuCheck_FctDelete);
                    break;
            }

            /* TGU - PMSTA13889 -120421 - deallocate memory from temp hierarchi */
            if (tmpHier != NULL)
            {
                DBA_FreeHier(tmpHier);
            }
        }
    }

    /*  Particular case checkFSP FALSE and checkDP TRUE: create rights is not managed   */  /*  HFI-PMSTA-14381-120604  */
    if ((checkFSP == FALSE) && (continueFlg == TRUE))
    {
        switch (adminRights)
        {
            case AdminRights_Create:
                rightsResult = TRUE;
                break;
        }
    }

    FREE_DYNST(secuCheck, SecuCheck);

    return(rightsResult);
}

/************************************************************************
**
**  Function    :   DBA_IsDeletedAttribute()
**
**  Description :
**
**  Argument    :   entity
**                  flags
**                  cell
**                  string
**
**  Return      :   0 on success, -1 elsewhere
**  Creation    :   PMSTA-16528 - DDV - 140703 - Avoid error on deleted attribute (format_element.search_key_e)
**
*************************************************************************/
FLAG_T DBA_IsDeletedAttribute(OBJECT_ENUM object, char* string)
{
    if ((object == FmtElt && !strcasecmp(string, "search_key_e")))
        return(TRUE);
    else
        return(FALSE);
}

/************************************************************************
*   Function             : DBA_SetDynFldFromString()
*
*   Description          :
*
*   Arguments            :
*
*   Functions call       :
*
*   Return               :
*
*   Last modif.          :
*
*************************************************************************/
RET_CODE DBA_SetDynFldFromString(DATE_STYLE_ENUM           inDateTimeStyleEn,
                                 const std::string& value,
                                 DBA_DYNFLD_STP            inputDataStp,
                                 const FIELD_IDX_T         field)
{
    RET_CODE ret = RET_SUCCEED;

    if (strcasecmp(value.c_str(), "NULL") != 0)
    {
        DATATYPE_ENUM dataType = GET_FLD_DTP(inputDataStp, field);

        if (dataType == DateType || dataType == DatetimeType)
        {
            DATETIME_T      datetime;

            DATE_FORMAT_ST  format;
            memset(&format, 0, sizeof(format));

            if (inDateTimeStyleEn != DateStyle_Iso)
            {
                size_t          pos = 0;
                format.ordre = Mdy;
                pos = value.find_first_of("/-");
                const char* sep = pos == std::string::npos ? " " : &value[pos];
                strncpy(format.yearSep, sep, 1);
                strncpy(format.monthSep, sep, 1);
                strncpy(format.daySep, sep, 1);

                std::string tmp(format.yearSep);
                tmp.append("0123456789 :");

                format.monthFormat = value.find_first_not_of(tmp) == std::string::npos ? 0 : 1;

                if (inDateTimeStyleEn != DateStyle_MmmDdYyyy12)
                {
                    switch (inDateTimeStyleEn)
                    {
                        case DateStyle_DdMmYyyy:
                            format.ordre = Dmy;
                            break;

                        case DateStyle_MmDdYyyy:
                            format.ordre = Mdy;
                            break;

                        case DateStyle_YyyyMmDd24:
                            if (pos == 4)
                                format.ordre = Ymd;
                            else
                                format.ordre = Iso;
                            break;
                    }
                }

                if (format.monthFormat == 1) /* Jan, feb...*/
                {
                    format.ordre = value[0] >= 48 && value[0] <= 57 ? Dmy : Mdy;    /* is first char a number ? if yes -> Dmy else Mdy */
                }
            }
            else
            {
                format.ordre = Iso;
            }
            format.yearFormat = 1;

            ret = DATETIME_FormatToDateTime(value.c_str(), datetime, &format);
            SET_DATETIME(inputDataStp, field, datetime);

            if (ret != RET_SUCCEED)
            {
                NOTE_T tmp2;
                std::string DATE_ORDRE_ENUM_TAB[] = { "Ymd", "Dmy", "Mdy", "Iso" };
                sprintf(tmp2, "Invalid date: string received:\"%s\", unable to convert with these settings: order=%s, sep=%s, YearLen=%s, monthFormat=%s", value.c_str(), DATE_ORDRE_ENUM_TAB[format.ordre].c_str(), format.monthSep, format.yearFormat == 0 ? "short(YY)" : "long(YYYY)", format.monthFormat == 0 ? "numeric(MM)" : "short(mmm)");
                MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DBI_SetDynFldFromString", tmp2);
            }
        }
        else
        {
            ret = DBA_StrToData(value.c_str(), inputDataStp, field) == TRUE ? RET_SUCCEED : RET_GEN_ERR_INVARG;
        }
    }
    else
    {
        SET_NULL_FLD(inputDataStp, field);
    }
    return ret;
}
/************************************************************************/
/*  End of File                                                         */
/************************************************************************/

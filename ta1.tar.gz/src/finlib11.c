/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define FINLIB11_C

#define STDIO_H
#define STRING_H
#define STDLIB_H

/************************************************************************
**      Includes
*************************************************************************/
#include "unidef.h"        /* Mandatory */
#include "gen.h"
#include "fin.h"
#include "scptyl.h"
#include "ope.h"

/************************************************************************
**
**      Functions Description
**      FIN_StratFilterParESE                       Get extended strategy element with bidouille.
**      FIN_StratFilterRefStratEltByStratId         Get extended strategy element which belong to
**                                                  benchmark strategy pointed by the bench_object_id.
**      FIN_ManageGlobalOrder                       Manage the interactive action on the order family
**                                                  from the GUI interface (Allocate Order,
**                                                  Strategy Reconciliation ...)
**      FIN_GetStratAdmAuth                         Check administration right on update
**                                                  the strategy, the associated grid and the current strategy level.
**		FIN_StratFilterCrtESL			            Get extended strategy link from received extended strategy element.
**		FIN_StratFilterDispESL			            Get extended strategy link with level != 0 (not parent strategy) .
**      FIN_CmpESENatInstrOrderRule                 Sort ESE by nature, instrument and order rule
**      FIN_FilterESEInstrPtfDetail                 Return only received instrument and nature ESE.
**      FIN_CheckPtfAuth                            Check the ptf authorization flag.
**      FIN_GlobalOrderCheckAuth                    Check the authorization flag on order parameter.
**      FIN_UpdateGridModel                         Main entry Function.
**                                                  Tool allowing a user to modify the grid attribute
**                                                  of a MODEL strategy.
**                                                  Main purpose : migrate old model definition to a
**                                                  new model based on a grid (break criteria) ...
**      FIN_StratNewModel                           Used by the "Update Grid" facility : replace the grid used
**                                                  by a model with another one.
**      FIN_DeleteAllBreakCriteriaByStratHistId     Delete all strategy elements except all those
**                                                  which define an instrument ( i.e break criteria and total)
**                                                  using the strategy id as criteria.
**
*************************************************************************/


/************************************************************************
**      Constants
*************************************************************************/

/************************************************************************
**      Macro Definitions
*************************************************************************/

/************************************************************************
**      Type  Definitions
*************************************************************************/

/************************************************************************
**      Global Functions
**
*************************************************************************/

/************************************************************************
**      Static Functions
**
*************************************************************************/



STATIC  RET_CODE FIN_DeleteAllBreakCriteriaByStratHistId(ID_T, int, int*, DBA_ERRMSG_INFOS_STP);





/************************************************************************
**
**  Function    :   FIN_StratFilterCrtESL()
**
**  Description :   Get extended strategy link from received extended strategy element.
**                  return TRUE  -> record must be extract
**                         FALSE -> record musn't be extract
**
**  Arguments   :   dynSt    element pointer
**                  dynStTp  element description enum
**
**  Return      : TRUE or FALSE
**
**  Creation Date : 19.07.99 - REF3729
**
*************************************************************************/
int FIN_StratFilterCrtESL(DBA_DYNFLD_STP dynSt,
		                         DBA_DYNST_ENUM dynStTp,
		                         DBA_DYNFLD_STP paramSt)
{
    if (GET_ID(dynSt, ExtStratLnk_Id) == GET_ID(paramSt, ExtStratElt_ExtStratLnkId))
    {
	    return(TRUE);
    }
    return(FALSE);
}


/************************************************************************
**
**  Function    :   FIN_StratFilterDispESL()
**
**  Description :   Get extended strategy link with level != 0 (not parent strategy) .
**                  return TRUE  -> record must be extract
**                         FALSE -> record musn't be extract
**
**  Arguments   :   dynSt    element pointer
**                  dynStTp  element description enum
**
**  Return      : TRUE or FALSE
**
**  Creation Date : 17.09.99 - REF3729
**
*************************************************************************/
int FIN_StratFilterDispESL(DBA_DYNFLD_STP dynSt,
                            DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP notUse) /* REF7264 - LJE - 020131 */
{
    if (GET_TINYINT(dynSt, ExtStratLnk_Level) != 0)
		return(TRUE);
    return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_StratFilterParESE()
**
**  Description :   Get extended strategy element with bidouille .
**                  return TRUE  -> record must be extract
**                         FALSE -> record musn't be extract
**
**  Arguments   :   dynSt    element pointer
**                  dynStTp  element description enum
**
**  Return      : TRUE or FALSE
**
**  Creation Date : 30.09.99 - REF3729
**
*************************************************************************/
int FIN_StratFilterParESE(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP notUse) /* REF7264 - LJE - 020131 */
{
	if (GET_ENUM(dynSt, ExtStratElt_CalcEn) == (ENUM_T) StratCalc_StratFocus)
		return(TRUE);
    return(FALSE);
}


/************************************************************************
**
**  Function    :   FIN_StratFilterRefStratEltByStratId()
**
**  Description :   Get extended strategy element which belong to
**                  benchmark strategy pointed by the bench_object_id
**                  (Load ratio facility).
**                  return TRUE  -> record must be extract
**                         FALSE -> record musn't be extract
**
**  Arguments   :   dynSt       element pointer
**                  dynStTp     element description enum
**                  paramSt     strategy pointer (with sub_nat_e == "Load ratio")
**
**  Return      :   TRUE or FALSE
**
**  Creation Date : SKE 000913 REF5192
**
*************************************************************************/
int FIN_StratFilterRefStratEltByStratId( DBA_DYNFLD_STP dynSt,
                                        DBA_DYNST_ENUM dynStTp,
		                                DBA_DYNFLD_STP paramSt)
{
    DICT_T  stratDictId;

    DBA_GetDictId(Strat, &stratDictId);

    if (IS_NULLFLD(dynSt, A_StratElt_BenchEntDictId) == FALSE       &&
        GET_DICT(dynSt, A_StratElt_BenchEntDictId) == stratDictId   &&
        GET_ID(dynSt, A_StratElt_BenchObjId) == GET_ID(paramSt, A_Strat_BenchObjId))
    {
		return(TRUE);
    }
    return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_GetStratAdmAuth()
**
**  Description :   Check administration right on update
**
**
**
**  Arguments   :   stratHierPtr : hierarchy header pointer
**                  ESEPtr       : current extended strategy element
**                  authFlg      : pointer on authorization flag
**                                 return TRUE if update is allowed
**                                 return FALSE elsewhere
**
**  Return      :   RET_SUCCEED or error code
**
**
**  Creation Date : REF4047 - 000119 - SKE
**
*************************************************************************/
RET_CODE FIN_GetStratAdmAuth(DBA_HIER_HEAD_STP  stratHierPtr,
                             DBA_DYNFLD_STP     ESEPtr,
                             FLAG_T            *authFlg)
{
    RET_CODE        ret         = RET_SUCCEED;
    DBA_DYNFLD_STP  aStratPtr   = NULLDYNST;

    /* Test given arguments */
	/* Test given arguments */
	if (stratHierPtr    == (DBA_HIER_HEAD_STP)NULL  ||
	    ESEPtr          == NULLDYNST                ||
	    authFlg         == (FLAG_T*)NULL)
	{
	    MSG_RETURN(RET_GEN_ERR_INVARG);
    }

    *authFlg = FALSE;

    /* search A_Strat */
    aStratPtr = DBA_SearchHierRecById(stratHierPtr,
		                              A_Strat,
				                      A_Strat_Id,
				                      GET_ID(ESEPtr, ExtStratElt_StratId));
    if (aStratPtr == NULLDYNST)
    {
        MSG_SendMesg(RET_DBA_ERR_NODATA, 7, FILEINFO, GET_ID(ESEPtr, ExtStratElt_StratId));
        return(RET_DBA_ERR_NODATA);
    }
    if (IS_NULLFLD(aStratPtr, GET_FLD_AUTH_UPD(A_Strat)) == FALSE   &&
        GET_FLAG(aStratPtr, GET_FLD_AUTH_UPD(A_Strat)) == TRUE)
    {
        *authFlg = TRUE;
    }

    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_ManageGlobalOrder()
**
**  Description :   Manage the interactive action on the order family
**                  from the GUI interface (Allocate Order, Strategy Reconciliation ...)
**
**  Arguments   :   stratHierPtr    : hierarchy header pointer
**                  extOpPtr        : current ext op.
**                  oldExtOpPtr     : original ext op before modification
**                  action          : action performed on ext op.
**                  fct             : pointer on function used to run dflt values
**                                    and refresh the GUI
**                  context         : fct parameter which contains GUI structures
**                  dfltValTab      : default values array
**					function		: function
**
**  Return      :   RET_SUCCEED or error code
**
**
**  Creation	: REF4418 - 000325 - SKE
**
**	Modif.		: MRA - 010202 - REF5118	Add function in parameters
**                REF7264 - 020129 - PMO : Compilation errors and warnings with C++ compiler
**
*************************************************************************/
RET_CODE FIN_ManageGlobalOrder(DBA_HIER_HEAD_STP    stratHierPtr,
                               DBA_DYNFLD_STP       extOpPtr,
                               DBA_DYNFLD_STP       oldExtOpPtr,
                               DBA_ACTION_ENUM      action,
                               RET_CODE             (*fct) (void * ,DBA_DYNFLD_STP),
                               PTR                  context,
                               FLAG_T              *dfltValTab,
							   DBA_DYNFLD_STP		domain)
{
    RET_CODE    ret = RET_SUCCEED;

    ret = OPE_OrderUpdHier(stratHierPtr,
                           extOpPtr,
                           oldExtOpPtr,
                           action,
                           fct,
                           context,
                           dfltValTab,
						   domain);	/* MRA - 010202 - REF5118 */

    if (ret != RET_SUCCEED)
    {
        return(ret);
    }

    /* < PMSTA-25183 - CHU - 170203 */
    if (!DBA_GetOrderCodeInSessionSysParam() &&
        domain != NULLDYNST &&
        extOpPtr != NULLDYNST &&
        OPE_OrderIsBlock(extOpPtr) == TRUE &&
        GET_EXTENSION_PTR(extOpPtr, ExtOp_ChildExtOp_Ext) != NULL &&
        GET_EXTENSION_NBR(extOpPtr, ExtOp_ChildExtOp_Ext) > 0 &&
        (oldExtOpPtr == NULL ||
        CMP_NUMBER(GET_NUMBER(oldExtOpPtr, ExtOp_Qty), GET_NUMBER(extOpPtr, ExtOp_Qty) != 0)))
    {
        FLAG_T *pflagtabVar = NULL;

        if ((pflagtabVar = (FLAG_T*)CALLOC(GET_FLD_NBR(ExtOp), sizeof(FLAG_T))) == NULL)
        {
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        memset(pflagtabVar, 0, GET_FLD_NBR(ExtOp)*sizeof(FLAG_T));
        pflagtabVar[ExtOp_Qty]          = TRUE;
        pflagtabVar[ExtOp_Cd]           = TRUE;
        pflagtabVar[ExtOp_ParOpNatEn]   = TRUE;
        pflagtabVar[ExtOp_InstrId]      = TRUE;
        pflagtabVar[ExtOp_NatureEn]     = TRUE;
        pflagtabVar[ExtOp_AcctCd]       = TRUE; /* same as in GUI */

		if ((OPSTAT_ENUM)GET_ENUM(extOpPtr, ExtOp_StatusEn) == OpStat_Cancelled)
		{
			pflagtabVar[ExtOp_StatusEn] = TRUE;/* PMSTA-28191 Smitha 20170904*/
		}

        SCPT_ComputeScreenDVCreate( EOp,
                                    GET_DICT(domain, A_Domain_InitialFctDictId),
                                    pflagtabVar,
                                    NULL,              /* HFI-PMSTA-25327-171023  Dedicated flag tab for filter    */
                                    extOpPtr,
                                    NULL,
                                    domain,
                                    FALSE,		/* PMSTA01091 - RAK - 061207 - Evaluate all fields (except them with a flag TRUE) */
                                    TRUE,		/* FIH-REF7838-020911 GUI mode because of we want to use GUI dflt */
                                    -1,
                                    (int *)NULL,
                                    NULL,
                                    stratHierPtr,
                                    0,
                                    NULL,
                                    NULL);

        FREE(pflagtabVar);                      /*  HFI-PMSTA-33396-181201  Free unreleased allocated memory    */
    } /* > PMSTA-25183 - CHU - 170203 */

    return(ret);
}


/************************************************************************
**
**  Function    :   FIN_CheckPtfAuth()
**
**  Description :   Check the ptf authorization flag.
**
**
**  Arguments   :   extOpPtr        : current ext op.
**                  admArgStp       :
**                  ptfPtr          :
**
**  Return      :   RET_SUCCEED or error code
**
**
**  Creation Date : REF4614 - 000502 - SKE
**
*************************************************************************/
RET_CODE FIN_CheckPtfAuth(DBA_DYNFLD_STP     extOpPtr,
                          DBA_DYNFLD_STP		admArgParamStp,
                          DBA_DYNFLD_STP     ptfParamPtr)
{
    RET_CODE        ret         = RET_SUCCEED;
    FLAG_T          allocFlg    = FALSE;
    DBA_DYNFLD_STP  admArgStp   = NULLDYNST;
    DBA_DYNFLD_STP  ptfPtr      = NULLDYNST;

    if (extOpPtr == NULLDYNST)
    {
        return(RET_GEN_ERR_INVARG);
    }

    if (admArgParamStp == NULLDYNST)
    {
        if ((admArgStp = ALLOC_DYNST(Adm_Arg)) == NULLDYNST)
        {
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "Adm_Arg");
            return(RET_MEM_ERR_ALLOC);
        }
        if ((ptfPtr = ALLOC_DYNST(S_Ptf)) == NULLDYNST)
        {
	        FREE_DYNST(admArgStp, Adm_Arg);
	        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "S_Ptf");
	        return(RET_MEM_ERR_ALLOC);
        }
        allocFlg = TRUE;
    }
    else
    {
        admArgStp = admArgParamStp;
        ptfPtr = ptfParamPtr;
    }

    /*  FPL-PMSTA11363-110203 test if id is given (total lines in gui don't have id)    */
    if (IS_NULLFLD(extOpPtr, ExtOp_PtfId) == TRUE)
        ret = RET_GUI_INFO_ACTIONCANCEL ;
    else
    {
        SET_ID(admArgStp, Adm_Arg_Id, GET_ID(extOpPtr, ExtOp_PtfId));
        if ((ret = DBA_Get2(Ptf,                        /* Entity */
	                        UNUSED,                     /* Role */
	                        Adm_Arg,                    /* Input Struct */
	                        admArgStp,                  /* Input Data */
	                        S_Ptf,                      /* Output Struct */
	                        (DBA_DYNFLD_STP*) &ptfPtr,  /* Output Data */
	                        UNUSED,
	                        UNUSED,
	                        UNUSED
	                        )) != RET_SUCCEED)
        {
            if (allocFlg == TRUE)
            {
                FREE_DYNST(ptfPtr, S_Ptf);
                FREE_DYNST(admArgStp, Adm_Arg);
            }
            return(ret);
        }
        if (GET_FLAG(ptfPtr, GET_FLD_AUTH_UPD(S_Ptf)) == FALSE)
        {
            ret = RET_GUI_INFO_ACTIONCANCEL;
        }
    }

    if (allocFlg == TRUE)
    {
        FREE_DYNST(ptfPtr, S_Ptf);
        FREE_DYNST(admArgStp, Adm_Arg);
    }

    return(ret);
}



/************************************************************************
**
**  Function    :   FIN_GlobalOrderCheckAuth()
**
**  Description :   Check the authorization flag on order parameter.
**
**
**  Arguments   :   stratHierPtr    : hierarchy header pointer
**                  extOpPtr        : current ext op.
**                  field           : modified field
**
**  Return      :   RET_SUCCEED or error code
**
**
**  Creation Date : REF4614 - 000502 - SKE
**
*************************************************************************/
RET_CODE FIN_GlobalOrderCheckAuth(DBA_HIER_HEAD_STP     stratHierPtr,
                                  DICT_T                dictfctEn,
                                  DICT_T                dictParFct,
                                  DBA_DYNFLD_STP        extOpPtr,
                                  int                   field)
{
    RET_CODE            ret             = RET_SUCCEED;
    FLAG_T              updFlg          = FALSE;
    DBA_DYNFLD_STP		admArgStp       = NULLDYNST;
    DBA_DYNFLD_STP      ptfPtr          = NULLDYNST;
    DBA_DYNFLD_STP     *childExtOpTab   = NULLDYNSTPTR;
    int                 childExtOpNbr   = 0;
    int                 i;

    if (stratHierPtr == (DBA_HIER_HEAD_STP)NULL ||
        dictfctEn == NullDictFct                ||
        extOpPtr == NULLDYNST)
    {
        return(RET_GEN_ERR_INVARG);
    }

    /**********************************
        1) Test Confirmed flag
    ***********************************/
    if (field != ExtOp_ConfirmedFlg)
    {
        if (GET_FLAG(extOpPtr, ExtOp_ConfirmedFlg) == FALSE)
        {
            /*
                Confirmed flag not check : no modification
                allowed.
            */
            return(RET_GUI_INFO_ACTIONCANCEL);
        }
    }
	/* MRA - 010409 - REF5857 */
	if ((OPE_OrderIsChild(extOpPtr) == TRUE) &&
		(field == ExtOp_StatusEn))
		return(RET_GUI_INFO_ACTIONCANCEL);

    /*********************************************
        2) Test Function Security Profile Compo
    **********************************************/
    if ((ret = DBA_GetDictFctAdmAuth(dictfctEn,
                                     EOp,
                                     DictFctInfo_UpdateFlag,
                                     &updFlg)) != RET_SUCCEED)
    {
        return(ret);
    }
    if (updFlg == FALSE)
    {
        return(RET_GUI_INFO_ACTIONCANCEL);
    }

    /***********************************************
        3) Test ptf authorization update flag
    ************************************************/
    if ((admArgStp = ALLOC_DYNST(Adm_Arg)) == NULLDYNST)
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "Adm_Arg");
        return(RET_MEM_ERR_ALLOC);
    }
    if ((ptfPtr = ALLOC_DYNST(S_Ptf)) == NULLDYNST)
    {
	    FREE_DYNST(admArgStp, Adm_Arg);
	    MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "S_Ptf");
	    return(RET_MEM_ERR_ALLOC);
    }
    if ((ret = FIN_CheckPtfAuth(extOpPtr,
                                admArgStp,
                                ptfPtr)) != RET_SUCCEED)
    {
        FREE_DYNST(ptfPtr, S_Ptf);
        FREE_DYNST(admArgStp, Adm_Arg);
        return(ret);
    }
    /* If the order is a block ... */
    if ((OPE_OrderIsBlock(extOpPtr) == TRUE) &&
        (dictParFct == DictFct_OrderList))      /*  FIH-REF7323-020425  */
    {
        /* ... check the rights on every child ptf */

        /* Extract children list */
	    if ((childExtOpNbr = GET_EXTENSION_NBR(extOpPtr, ExtOp_ChildExtOp_Ext)) > 0)
	    {
            if (IS_NULLFLD(extOpPtr, ExtOp_ChildExtOp_Ext) == TRUE    ||
                (childExtOpTab = GET_EXTENSION_PTR(extOpPtr, ExtOp_ChildExtOp_Ext)) == NULLDYNSTPTR)
            {
                FREE_DYNST(ptfPtr, S_Ptf);
                FREE_DYNST(admArgStp, Adm_Arg);
                MSG_SendMesg(RET_DBA_ERR_HIER,
                             6,
                             FILEINFO,
			                 "FIN_GlobalOrderCheckAuth",
                             ExtOp_ParExtOp_Ext);
                return(RET_DBA_ERR_HIER);
            }
	        for (i=0 ; i<childExtOpNbr ; i++)
	        {
                if ((ret = FIN_CheckPtfAuth(childExtOpTab[i],
                                            admArgStp,
                                            ptfPtr)) != RET_SUCCEED)
                {
                    FREE_DYNST(ptfPtr, S_Ptf);
                    FREE_DYNST(admArgStp, Adm_Arg);
                    return(ret);
                }
            }
        }
    }
    FREE_DYNST(ptfPtr, S_Ptf);
    FREE_DYNST(admArgStp, Adm_Arg);

    return(RET_SUCCEED);
}


/************************************************************************
**
**  Function    :   FIN_CmpESENatInstrOrderRule()
**
**  Description :   Sort extended strategy element by nature, instrument and order rule
**
**  Arguments   :   ptr1    first element pointer
**                  prt2    second element pointer
**
**  Return      :   TLS_Sort() comparison function return
**
*************************************************************************/
int FIN_CmpESENatInstrOrderRule(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
	ORDERALLOCRULE_ENUM 	orderAllocRuleEn;
	FUSDATERULE_ENUM	fusDateRuleEn;

	/* portfolio */
	if (GET_ID((*ptr1), ExtStratElt_PtfId) == GET_ID((*ptr2), ExtStratElt_PtfId))
	{
	    /* FIRST : ModelDetail and PtfDetail */
	    if (GET_ENUM((*ptr1), ExtStratElt_NatEn) == ExtStratEltNat_ModelDetail ||
	        GET_ENUM((*ptr1), ExtStratElt_NatEn) == ExtStratEltNat_AllocDetail ||
	        GET_ENUM((*ptr1), ExtStratElt_NatEn) == ExtStratEltNat_PtfDetail   ||
            /* REF4047 - 20000223 - SKE */
            GET_ENUM((*ptr1), ExtStratElt_NatEn) == ExtStratEltNat_RecommList)
	    {
	        if (GET_ENUM((*ptr2), ExtStratElt_NatEn) == ExtStratEltNat_ModelDetail ||
	            GET_ENUM((*ptr2), ExtStratElt_NatEn) == ExtStratEltNat_AllocDetail ||
	    	    GET_ENUM((*ptr2), ExtStratElt_NatEn) == ExtStratEltNat_PtfDetail   ||
                /* REF4047 - 20000223 - SKE */
                GET_ENUM((*ptr2), ExtStratElt_NatEn) == ExtStratEltNat_RecommList)
	        {
		    /* order by strategy identifier */
		    if (GET_ID((*ptr1), ExtStratElt_StratId) ==
		        GET_ID((*ptr2), ExtStratElt_StratId))
		    {
		        /* order by instrument identifier */
		        if (GET_ID((*ptr1), ExtStratElt_InstrId) ==
	                GET_ID((*ptr2), ExtStratElt_InstrId))
		        {
		            /* FIRST : "general" instrument extended strategy element */
	    	        if (GET_SMALLINT((*ptr1), ExtStratElt_ModelReading) == -1 &&
			            GET_SMALLINT((*ptr2), ExtStratElt_ModelReading) == -1)
	    	        {
						/* REF6168 - CHU - 010824 */
		    	        if (GET_SMALLINT((*ptr1), ExtStratElt_SellPriority) == GET_SMALLINT((*ptr2), ExtStratElt_SellPriority))
	    				{
							/* REF11039 - RAK - 050315 */
							/* In case of equality , add sort on qty (except for EffQty, add sort on date)  */
							int	ret=0;
				            /* FIRST : depend on order rule (FIFO, LIFO, High cost, Low cost) */
							/* PMSTA40055 - vmuthu - 040620 */
							/* order Allocation Rule is now handled in FIN_ExtStratEltAllocRuleUpd */
							/* WRT System level/ Domain level/ Portfolio level */
							orderAllocRuleEn = (ORDERALLOCRULE_ENUM)GET_ENUM((*ptr1), ExtStratElt_OrderAllocRulesEn);
							switch (orderAllocRuleEn)
							{
							case OrderAllocRule_LIFO :
								GEN_GetApplInfo(ApplFusDateRule, &fusDateRuleEn);
								switch (fusDateRuleEn)
								{
								case FusDateRule_OpDate :
									ret = DATETIME_CMP(GET_DATETIME((*ptr2), ExtStratElt_OpDate),
										                GET_DATETIME((*ptr1), ExtStratElt_OpDate));
									break;
								case FusDateRule_AcctDate :
									ret = DATETIME_CMP(GET_DATETIME((*ptr2), ExtStratElt_AcctDate),
										                GET_DATETIME((*ptr1), ExtStratElt_AcctDate));
									break;
								case FusDateRule_ValDate :
								default :
									ret = DATETIME_CMP(GET_DATETIME((*ptr2), ExtStratElt_ValueDate),
										               GET_DATETIME((*ptr1), ExtStratElt_ValueDate));
									break;
								}

								/* REF11039 - RAK - 050315 - In case of equality, add sort on qty */
								if (ret == 0)
								{
									ret = CMP_NUMBER(GET_NUMBER((*ptr2), ExtStratElt_EffQty),
									                 GET_NUMBER((*ptr1), ExtStratElt_EffQty));
								}
								break;

							case OrderAllocRule_HighCost :
								ret = CMP_PRICE(GET_PRICE((*ptr2), ExtStratElt_CostPrice),
									             GET_PRICE((*ptr1), ExtStratElt_CostPrice));

								/* REF11039 - RAK - 050315 - In case of equality, add sort on qty */
								if (ret == 0)
								{
									ret = CMP_NUMBER(GET_NUMBER((*ptr2), ExtStratElt_EffQty),
									                 GET_NUMBER((*ptr1), ExtStratElt_EffQty));
								}
								break;

							case OrderAllocRule_LowCost :
								ret = CMP_PRICE(GET_PRICE((*ptr1), ExtStratElt_CostPrice),
									             GET_PRICE((*ptr2), ExtStratElt_CostPrice));

								/* REF11039 - RAK - 050315 - In case of equality, add sort on qty */
								if (ret == 0)
								{
									ret = CMP_NUMBER(GET_NUMBER((*ptr2), ExtStratElt_EffQty),
									                 GET_NUMBER((*ptr1), ExtStratElt_EffQty));
								}
								break;

							/* REF4445 - RAK - 000215 */
							case OrderAllocRule_SubPosNat :
								ret = GET_ENUM((*ptr1), ExtStratElt_SubPosNatEn) -
									  GET_ENUM((*ptr2), ExtStratElt_SubPosNatEn);

								/* REF11039 - RAK - 050315 - In case of equality, add sort on qty */
								if (ret == 0)
								{
									ret = CMP_NUMBER(GET_NUMBER((*ptr2), ExtStratElt_EffQty),
									                 GET_NUMBER((*ptr1), ExtStratElt_EffQty));
								}
								break;

							/* REF6168 - CHU - 010824 */
							case OrderAllocRule_HighQuantity :
								ret = CMP_NUMBER(GET_NUMBER((*ptr2), ExtStratElt_EffQty),
									             GET_NUMBER((*ptr1), ExtStratElt_EffQty));

								/* REF11039 - RAK - 050315 - In case of equality, add sort on date (FIFO like default) */
								if (ret == 0)
								{
									GEN_GetApplInfo(ApplFusDateRule, &fusDateRuleEn);
									switch (fusDateRuleEn)
									{
									case FusDateRule_OpDate :
										ret = DATETIME_CMP(GET_DATETIME((*ptr1), ExtStratElt_OpDate),
														   GET_DATETIME((*ptr2), ExtStratElt_OpDate));
									break;
			    					case FusDateRule_AcctDate :
										ret = DATETIME_CMP(GET_DATETIME((*ptr1),ExtStratElt_AcctDate),
										                   GET_DATETIME((*ptr2),ExtStratElt_AcctDate));
									break;
									case FusDateRule_ValDate :
									default :
										ret = DATETIME_CMP(GET_DATETIME((*ptr1), ExtStratElt_ValueDate),
										                   GET_DATETIME((*ptr2), ExtStratElt_ValueDate));
									break;
									}
								}
								break;

							/* PMSTA40055 - vmuthu - 040620 */
							case OrderAllocRule_LowQuantity:
								ret = CMP_NUMBER(GET_NUMBER((*ptr1), ExtStratElt_EffQty),
									GET_NUMBER((*ptr2), ExtStratElt_EffQty));

								/* In case of equality, add sort on date (FIFO like default) */
								if (ret == 0)
								{
									GEN_GetApplInfo(ApplFusDateRule, &fusDateRuleEn);
									switch (fusDateRuleEn)
									{
									case FusDateRule_OpDate:
										ret = DATETIME_CMP(GET_DATETIME((*ptr1), ExtStratElt_OpDate),
											GET_DATETIME((*ptr2), ExtStratElt_OpDate));
										break;
									case FusDateRule_AcctDate:
										ret = DATETIME_CMP(GET_DATETIME((*ptr1), ExtStratElt_AcctDate),
											GET_DATETIME((*ptr2), ExtStratElt_AcctDate));
										break;
									case FusDateRule_ValDate:
									default:
										ret = DATETIME_CMP(GET_DATETIME((*ptr1), ExtStratElt_ValueDate),
											GET_DATETIME((*ptr2), ExtStratElt_ValueDate));
										break;
									}
								}
								break;

							/* PMSTA40055 - vmuthu - 040620 */
							case OrderAllocRule_HighestPercentage:
								ret = CMP_NUMBER(GET_NUMBER((*ptr2), ExtStratElt_AllocationRulePcnt),
									GET_NUMBER((*ptr1), ExtStratElt_AllocationRulePcnt));

								/* REF11039 - RAK - 050315 - In case of equality, add sort on date (FIFO like default) */
								if (ret == 0)
								{
									ret = CMP_NUMBER(GET_NUMBER((*ptr2), ExtStratElt_EffQty),
										GET_NUMBER((*ptr1), ExtStratElt_EffQty));
									if (ret == 0)
									{
										GEN_GetApplInfo(ApplFusDateRule, &fusDateRuleEn);
										switch (fusDateRuleEn)
										{
										case FusDateRule_OpDate:
											ret = DATETIME_CMP(GET_DATETIME((*ptr1), ExtStratElt_OpDate),
												GET_DATETIME((*ptr2), ExtStratElt_OpDate));
											break;
										case FusDateRule_AcctDate:
											ret = DATETIME_CMP(GET_DATETIME((*ptr1), ExtStratElt_AcctDate),
												GET_DATETIME((*ptr2), ExtStratElt_AcctDate));
											break;
										case FusDateRule_ValDate:
										default:
											ret = DATETIME_CMP(GET_DATETIME((*ptr1), ExtStratElt_ValueDate),
												GET_DATETIME((*ptr2), ExtStratElt_ValueDate));
											break;
										}
									}
								}
								break;

							/* PMSTA40055 - vmuthu - 040620 */
							case OrderAllocRule_LowestPercentage:
								ret = CMP_NUMBER(GET_NUMBER((*ptr1), ExtStratElt_AllocationRulePcnt),
									GET_NUMBER((*ptr2), ExtStratElt_AllocationRulePcnt));

								/* REF11039 - RAK - 050315 - In case of equality, add sort on date (FIFO like default) */
								if (ret == 0)
								{
									ret = CMP_NUMBER(GET_NUMBER((*ptr1), ExtStratElt_EffQty),
										GET_NUMBER((*ptr2), ExtStratElt_EffQty));
									if (ret == 0)
									{
										GEN_GetApplInfo(ApplFusDateRule, &fusDateRuleEn);
										switch (fusDateRuleEn)
										{
										case FusDateRule_OpDate:
											ret = DATETIME_CMP(GET_DATETIME((*ptr1), ExtStratElt_OpDate),
												GET_DATETIME((*ptr2), ExtStratElt_OpDate));
											break;
										case FusDateRule_AcctDate:
											ret = DATETIME_CMP(GET_DATETIME((*ptr1), ExtStratElt_AcctDate),
												GET_DATETIME((*ptr2), ExtStratElt_AcctDate));
											break;
										case FusDateRule_ValDate:
										default:
											ret = DATETIME_CMP(GET_DATETIME((*ptr1), ExtStratElt_ValueDate),
												GET_DATETIME((*ptr2), ExtStratElt_ValueDate));
											break;
										}
									}
								}
								break;

							/* REF4445 - RAK - 000215 - New default */
							case OrderAllocRule_FIFO :
							default :
								GEN_GetApplInfo(ApplFusDateRule, &fusDateRuleEn);
								switch (fusDateRuleEn)
								{
								case FusDateRule_OpDate :
									ret = DATETIME_CMP(GET_DATETIME((*ptr1), ExtStratElt_OpDate),
										               GET_DATETIME((*ptr2), ExtStratElt_OpDate));
									break;
			    				case FusDateRule_AcctDate :
									ret = DATETIME_CMP(GET_DATETIME((*ptr1),ExtStratElt_AcctDate),
										               GET_DATETIME((*ptr2),ExtStratElt_AcctDate));
									break;
								case FusDateRule_ValDate :
								default :
									ret = DATETIME_CMP(GET_DATETIME((*ptr1), ExtStratElt_ValueDate),
										               GET_DATETIME((*ptr2), ExtStratElt_ValueDate));
									break;
								}

								/* REF11039 - RAK - 050315 - In case of equality, add sort on qty */
								if (ret == 0)
								{
									ret = CMP_NUMBER(GET_NUMBER((*ptr2), ExtStratElt_EffQty),
									                 GET_NUMBER((*ptr1), ExtStratElt_EffQty));
								}
								break;
							}
							/* REF11039 - RAK - 050315 */
							/* In case of equality , add sort on qty (except for EffQty, add sort on date)  */
							return(ret);
						}
						else
						{   /* REF6168 - CHU - 010824 */
							return(GET_SMALLINT((*ptr1), ExtStratElt_SellPriority) -
								   GET_SMALLINT((*ptr2), ExtStratElt_SellPriority));
						}
					}
					else
					{
						if (GET_SMALLINT((*ptr1), ExtStratElt_ModelReading) == -1)
							return (1);
						else
							return (-1);
					}
		        }
		        else
		        {
	    	        return (CMP_ID(GET_ID((*ptr1), ExtStratElt_InstrId),
		    	            GET_ID((*ptr2), ExtStratElt_InstrId))); /* DLA - REF9089 - 030508 */
		        }
		    }
		    else
		    {
		        return (CMP_ID(GET_ID((*ptr1), ExtStratElt_StratId),
		                GET_ID((*ptr2), ExtStratElt_StratId))); /* DLA - REF9089 - 030508 */
		    }
	        }
	        else
		        return (-1);
	    }
	    else
	        return(1);
	}
	else
	{
	    return(CMP_ID(GET_ID((*ptr1), ExtStratElt_PtfId),
		       GET_ID((*ptr2), ExtStratElt_PtfId))); /* DLA - REF9089 - 030508 */
	}
}


/************************************************************************
*
*   Function      :   FIN_FilterESEInstrPtfDetail()
*
*   Description   :   Return only received instrument and nature ESE
*                     return TRUE  -> record must be extract
*                            FALSE -> record musn't be extract
*
**  Arguments     :   dynSt    element pointer
**                    dynStTp  element description enum
*
*   Return        :   TRUE or FALSE
*
*   Creation 	  :   REf3110 - RAK - 981214
*
*************************************************************************/
int FIN_FilterESEInstrPtfDetail(DBA_DYNFLD_STP  dynSt,
		                        DBA_DYNST_ENUM  dynStTp,
                                DBA_DYNFLD_STP  paramSt)
{
	if (GET_ID(dynSt, ExtStratElt_InstrId) == GET_ID(paramSt, Chk_Arg_Id) &&
	    GET_ENUM(dynSt, ExtStratElt_NatEn) == GET_ENUM(paramSt, Chk_Arg_NatEn) &&
	    /* REF3110 - RAK - 990212 - Only current strategy details ... */
	    GET_ID(dynSt, ExtStratElt_DispParExtStratEltId) == GET_ID(paramSt, Chk_Arg_ParId))
		return(TRUE);
	else
		return(FALSE);
}

/************************************************************************
*
*   Function      :   FIN_StratNewModel()
*
*   Description   :   Used by the "Update Grid" facility : replace
*                     the grid used by a model with another one.
*
*
*
*   Arguments     :
*
*
*   Return        :   TRUE or FALSE
*
*   Creation 	  :     SKE
*   Last modif.   :   REF7264 - 020129 - PMO : Compilation errors and warnings with C++ compiler
*
*************************************************************************/
RET_CODE FIN_StratNewModel(DBA_HIER_HEAD_STP     stratHierPtr,
                          int                   ESEFldNbr,
                          DBA_DYNFLD_STP        ESLPtr,
                          int                   selOptions,
                          int*                  connectNo)
{
    RET_CODE	            ret             = RET_SUCCEED;
    DBA_DYNFLD_STP          stratHistPtr    = NULLDYNST;
    DBA_DYNFLD_STP         *stratEltTab     = NULLDYNSTPTR;
    DBA_DYNFLD_STP         *stratEltExtTab  = NULLDYNSTPTR;
    DBA_DYNFLD_STP          targetESLPtr    = NULLDYNST;
    DBA_DYNFLD_STP          aInstrPtr       = NULLDYNST;
    DBA_DYNFLD_STP          ESEPtr          = NULLDYNST;
    SCPT_CLASSIFSTACK_STP   classifStack    = (SCPT_CLASSIFSTACK_STP)NULL;
    FLAG_T                  allocFlg        = FALSE;
    ID_T                    targetMktSegtId = 0;
    int				        stratEltNbr     = 0;
    int				        i;

    /* Read strategy element */
    if (GET_EXTENSION_PTR(ESLPtr, ExtStratLnk_A_StratHist_Ext) != NULL &&
	   (stratHistPtr = *(GET_EXTENSION_PTR(ESLPtr, ExtStratLnk_A_StratHist_Ext))) != NULLDYNST)
    {
		stratEltExtTab = GET_EXTENSION_PTR(stratHistPtr, A_StratHist_A_StratElt_Ext);
		stratEltNbr = GET_EXTENSION_NBR(stratHistPtr, A_StratHist_A_StratElt_Ext);

        if (stratEltNbr > 0)
        {
	        if ((stratEltTab = (DBA_DYNFLD_STP *) CALLOC(stratEltNbr, sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR)   /* REF7264 - PMO */
	        {
	            MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, stratEltNbr);
	            return(RET_MEM_ERR_ALLOC);
	        }
            for (i=0 ; i < stratEltNbr ; i++)
            {
				/* REF11559 - CHU - 051124 : check validity of Strategy element */
				if (GET_ID(stratEltExtTab[i], A_StratElt_Id) < (ID_T)0 &&
					IS_NULLFLD(stratEltExtTab[i], A_StratElt_PtfIdForMissingPM) == FALSE &&
					CMP_ID(GET_ID(ESLPtr, ExtStratLnk_PtfId), GET_ID(stratEltExtTab[i], A_StratElt_PtfIdForMissingPM))!=0)
				{
					continue;
				}

               stratEltTab[i] = stratEltExtTab[i];
            }
        }
    }

    if (IS_NULLFLD(ESLPtr, ExtStratLnk_GridId) == FALSE)
    {
        /*
            The instruments are dispatched only from the top strategy ie the
            strategy with level equal to 1.
        */
        if (GET_TINYINT(ESLPtr, ExtStratLnk_Level) != 1)
        {
            FREE(stratEltTab);
            return(ret);
        }

        if (stratEltNbr > 0)
	    {
	        if ((classifStack = (SCPT_CLASSIFSTACK_STP) CALLOC(20, sizeof(SCPT_CLASSIFSTACK_ST))) == (SCPT_CLASSIFSTACK_STP)NULL)
	        {
                FREE(stratEltTab);
                MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "classifStack");
	            return(RET_MEM_ERR_ALLOC);
	        }

		    for (i=0; i<stratEltNbr; i++)
		    {
                if (IS_NULLFLD(stratEltTab[i], A_StratElt_InstrId) == TRUE)
                {
                    continue;
                }

                if (ESEFldNbr > 0)
                {
    	            ESEPtr = ALLOC_DYNST_SUPPLFLD(ExtStratElt, ESEFldNbr);
	                if (ESEPtr == NULLDYNST)
	                {
                        FREE(stratEltTab);
	                    MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtStratElt suppl. fld");
	                    return(RET_MEM_ERR_ALLOC);
	                }
                }
                else
                {
	                ESEPtr = ALLOC_DYNST(ExtStratElt);
	                if (ESEPtr == NULLDYNST)
	                {
                        FREE(stratEltTab);
	                    MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtStratElt");
	                    return(RET_MEM_ERR_ALLOC);
	                }
                }

                /* Reset Market Sgt Id */
                SET_NULL_ID(stratEltTab[i], A_StratElt_MktSegtId);
                /* Update db Status */
                ret = DBA_UpdHierEltRec(stratHierPtr, A_StratElt, stratEltTab[i]);
	            if (ret != RET_SUCCEED)
                {
                    FREE(stratEltTab);
                    SCPT_FreeClassifStack(&classifStack);
	                return(ret);
                }

                targetESLPtr = NULLDYNST;
                targetMktSegtId = (ID_T)0;
                /* Extract the instrument */
                ret = DBA_GetInstrById(GET_ID(stratEltTab[i], A_StratElt_InstrId),
                                       FALSE,
                                       &allocFlg,
	                                   &aInstrPtr,
       			                       stratHierPtr,
                                       selOptions,
                                       connectNo);
                if (ret != RET_SUCCEED)
                {
                    FREE(stratEltTab);
                    SCPT_FreeClassifStack(&classifStack);
                    return(ret);
                }
                /*
                    Retrieve the market segment where the instrument
                    takes place.
                */
                targetESLPtr = FIN_SetInstrInStratHier(stratHierPtr,
                                                       NULLDYNST,
                                                       ESLPtr,
                                                       NULLDYNST,
                                                       aInstrPtr,
                                                       &targetMktSegtId,
                                                       classifStack,
                                                       selOptions,
                                                       connectNo,
													   0); /* REF8834 - CHU - 031119 */

				/* REF9545 - RAK - 031119 */
                if (targetMktSegtId != 0 && targetMktSegtId != -1 && targetESLPtr != NULLDYNST)
                {
                    SET_ID(stratEltTab[i], A_StratElt_MktSegtId, targetMktSegtId);
			        if ((ret = FIN_StratCreateESEModelDet(stratHierPtr,
                                                          ESEFldNbr,
							                              targetESLPtr,
                                                          stratEltTab[i],
                                                          ESEPtr,
                                                          ExtStratEltNat_ModelDetail)) != RET_SUCCEED)
                    {
						if (allocFlg == TRUE) FREE_DYNST(aInstrPtr, A_Instr);
                        FREE(stratEltTab);
                        SCPT_FreeClassifStack(&classifStack);
			            return(ret);
                    }
                    /* Update Weights ... */
                    ret = FIN_FieldStratUpdRecAndParent(stratHierPtr,
                                                        ESEPtr,
                                                        NULLDYNST,
                                                        Update,
                                                        ExtStratElt_ObjWeight,
                                                        selOptions,
                                                        connectNo,
                                                        NULL,  /* REF7264 - LJE - 020131 */
                                                        NULL,
                                                        (FLAG_T*)NULL,
                                                        FALSE); /* PMSTA-27076 - CHU - 170626*/
                    if (ret != RET_SUCCEED)
	                {
						if (allocFlg == TRUE) FREE_DYNST(aInstrPtr, A_Instr);
                        FREE(stratEltTab);
                        SCPT_FreeClassifStack(&classifStack);
		                return(ret);
	                }
                }
				else
				{

					if (allocFlg == TRUE) FREE_DYNST(aInstrPtr, A_Instr);
					return(RET_FIN_ERR_INSTR_CLASSIFY);

				}
            }
            SCPT_FreeClassifStack(&classifStack);
        }
    }
    else
    {
        ret = FIN_StratCreateESEModelTot(stratHierPtr, ESEFldNbr, ESLPtr, selOptions, connectNo);
        if (ret != RET_SUCCEED)
        {
            FREE(stratEltTab);
            return(ret);
        }

        if (stratEltNbr > 0)
	    {
		    /* Set total line at the begin ... */
		    TLS_Sort((char*) stratEltTab,
                     stratEltNbr,
                     sizeof(DBA_DYNFLD_STP),
				     (TLS_CMPFCT *)FIN_StratCmpEltNat, /* REF7264 - LJE - 020131 */
                     (PTR**)NULL,
                     SortRtnTp_None);

		    for (i=0; i<stratEltNbr; i++)
		    {
                if (ESEFldNbr > 0)
                {
    	            ESEPtr = ALLOC_DYNST_SUPPLFLD(ExtStratElt, ESEFldNbr);
	                if (ESEPtr == NULLDYNST)
	                {
                        FREE(stratEltTab);
	                    MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtStratElt suppl. fld");
	                    return(RET_MEM_ERR_ALLOC);
	                }
                }
                else
                {
	                ESEPtr = ALLOC_DYNST(ExtStratElt);
	                if (ESEPtr == NULLDYNST)
	                {
                        FREE(stratEltTab);
	                    MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtStratElt");
	                    return(RET_MEM_ERR_ALLOC);
	                }
                }

                if (IS_NULLFLD(stratEltTab[i], A_StratElt_MktSegtId) == FALSE)
                {
                    /* Reset Market Sgt Id */
                    SET_NULL_ID(stratEltTab[i], A_StratElt_MktSegtId);
                    /* Update db Status */
                    ret = DBA_UpdHierEltRec(stratHierPtr, A_StratElt, stratEltTab[i]);
	                if (ret != RET_SUCCEED)
                    {
                        FREE(stratEltTab);
	                    return(ret);
                    }
                }

			    if ((ret = FIN_StratCreateESEModelDet(stratHierPtr,
                                                      ESEFldNbr,
                                                      ESLPtr,
                                                      stratEltTab[i],
                                                      ESEPtr,
                                                      ExtStratEltNat_ModelDetail)) != RET_SUCCEED)
			    {
                    FREE(stratEltTab);
				    return(ret);
			    }
                /* Update Weights ... */
                ret = FIN_FieldStratUpdRecAndParent(stratHierPtr,
                                                    ESEPtr,
                                                    NULLDYNST,
                                                    Update,
                                                    ExtStratElt_ObjWeight,
                                                    selOptions,
                                                    connectNo,
                                                    NULL,  /* REF7264 - LJE - 020131 */
                                                    NULL,
                                                    (FLAG_T*)NULL,
                                                    FALSE); /* PMSTA-27076 - CHU - 170626*/
                if (ret != RET_SUCCEED)
	            {
                    FREE(stratEltTab);
		            return(ret);
	            }
		    }
        }
    }
    FREE(stratEltTab);

    return(ret);
}



/************************************************************************
**
**  Function    :   FIN_DeleteAllBreakCriteriaByStratHistId
**
**  Description :   Delete all strategy elements except all those
**                  which define an instrument ( i.e break criteria
**                  and total) using the strategy id as
**                  criteria.
**
**  Arguments   :   stratHistId     : strategy history id
**                  connectNo       : connection number
**                  msgStructPtr    : err msg structure
**
**
**
**  Return      :   RET_CODE
**
**	Cr�ation	:	SKE REF4888 000608
**
*************************************************************************/

STATIC  RET_CODE FIN_DeleteAllBreakCriteriaByStratHistId(ID_T                    stratHistId,
                                                         int                     delOptions,
                                                         int*                    connectNo,
                                                         DBA_ERRMSG_INFOS_STP    msgStructPtr)
{
    RET_CODE        ret         = RET_SUCCEED;
    DBA_DYNFLD_STP  admArgPtr   = NULLDYNST;

    admArgPtr = ALLOC_DYNST(Adm_Arg);
    if (admArgPtr == NULLDYNST)
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "Adm_Arg");
		return(RET_MEM_ERR_ALLOC);
    }
    SET_ID(admArgPtr, Adm_Arg_Id, stratHistId);

	ret = DBA_Delete2(StratElt,
                      DBA_ROLE_UPDATE_MODEL,
			          Adm_Arg,
                      admArgPtr,
                      delOptions,
                      connectNo,
                      msgStructPtr);
    if (ret != RET_SUCCEED)
    {
        FREE_DYNST(admArgPtr, Adm_Arg);
        return(ret);
    }
    FREE_DYNST(admArgPtr, Adm_Arg);

    return(ret);
}





/************************************************************************
**
**  Function    :   FIN_UpdateGridModel
**
**  Description :   Main entry Function.
**                  Tool allowing a user to modify the grid attribute
**                  of a MODEL strategy.
**                  Main purpose : migrate old model definition to a
**                  new model based on a grid (break criteria) ...
**
**
**  Arguments   :   stratPtr        : A_Strat pointer
**                  connectNo       : connection number
**                  msgStructPtr    : err msg structure
**
**
**
**  Return      :   RET_CODE
**
**	Cr�ation	:	SKE REF4888 000608
**
*************************************************************************/
RET_CODE FIN_UpdateGridModel(DBA_DYNFLD_STP         stratPtr,
                             DBA_DYNFLD_STP*        stratHistTab,
                             int                    stratHistNbr,
                             int                    selOptions,
                             int*                   connectNo)
{
    RET_CODE            ret             = RET_SUCCEED;
    DICT_T              stratDictId;
    DBA_HIER_HEAD_STP   hierStrat       = (DBA_HIER_HEAD_STP)NULL;
    DBA_HIER_UPDDB_ST	hierUpdDbSt     /*= {0}*/;  /* REF5200 - SSO - 000904 */
    DBA_DYNFLD_STP      searchLnkPtr    = NULLDYNST;
    int                 ESEFldNbr       = 0;

    /* <SKE REF5508 001207
    memset(&hierUpdDbSt, sizeof(DBA_HIER_UPDDB_ST), 0);   REF5200 - SSO - 000904
    */
    memset(&hierUpdDbSt, 0, sizeof(DBA_HIER_UPDDB_ST));
    /* SKE REF5508 001207> */

    /* Alloc search structure */
    searchLnkPtr = ALLOC_DYNST(A_SearchLnk);
    if (searchLnkPtr == NULLDYNST)
    {

        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "A_SearchLnk");
		return(RET_MEM_ERR_ALLOC);
    }

    /* Create strategy hierarchy */
    hierStrat = DBA_CreateHier();
    if (hierStrat == (DBA_HIER_HEAD_STP)NULL)
    {
        FREE_DYNST(searchLnkPtr, A_SearchLnk);
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    /* Init search structure */
    DBA_GetDictId(Strat, &stratDictId);
    SET_DICT(searchLnkPtr, A_SearchLnk_DimStratDictId, stratDictId);
    SET_ID(searchLnkPtr, A_SearchLnk_StratObjId, GET_ID(stratPtr, A_Strat_Id));

    SET_ENUM(searchLnkPtr, A_SearchLnk_ComplianceMethodEn, complianceMethodEn::Default);
    SET_FLAG(searchLnkPtr, A_SearchLnk_DynamicSeverityFlg, FALSE);
    SET_FLAG(searchLnkPtr, A_SearchLnk_LoadHierFlg, FALSE);
    SET_FLAG(searchLnkPtr, A_SearchLnk_CaseDurationFlg, FALSE);

    /* Main Loop : for each strategy history ... */
    for (int i=0 ; i < stratHistNbr ; i++)
    {

        /* Truncate temp tables */
        if (i > 0)
        {
            ret = DBA_CreateTempTables(connectNo, DOM_STRAT | GRID_VECTOR | STRAT_MARKET | DOM_PARENT_STRAT | TMP_STRAT_HIST | STRATEGY );
            if (ret != RET_SUCCEED)
            {
                FREE_DYNST(searchLnkPtr, A_SearchLnk);
                DBA_FreeHier(hierStrat);
                return(ret);
            }
        }

        /* Init search structure */
        COPY_DYNFLD(searchLnkPtr, A_SearchLnk, A_SearchLnk_BeginDate, stratHistTab[i], S_StratHist, S_StratHist_BegDate);
        SET_ID(searchLnkPtr, A_SearchLnk_StratHistId, GET_ID(stratHistTab[i], S_StratHist_Id));
        SET_ENUM(searchLnkPtr, A_SearchLnk_ComplianceMethodEn, complianceMethodEn::Default);
        SET_FLAG(searchLnkPtr, A_SearchLnk_DynamicSeverityFlg, FALSE);
        SET_FLAG(searchLnkPtr, A_SearchLnk_LoadHierFlg, FALSE);
        SET_FLAG(searchLnkPtr, A_SearchLnk_CaseDurationFlg, FALSE);
        

        /* Delete ALL strategy_element linked to a total or a break criteria */
        ret = FIN_DeleteAllBreakCriteriaByStratHistId(GET_ID(stratHistTab[i], S_StratHist_Id),
                                                      selOptions,
                                                      connectNo,
                                                      nullptr);
        if (ret != RET_SUCCEED)
        {
            FREE_DYNST(searchLnkPtr, A_SearchLnk);
            DBA_FreeHier(hierStrat);
            return(ret);
        }

        /* Rebuid Strategy */
	    ret = FIN_SelStratData(searchLnkPtr,
							   ESEFldNbr,
							   hierStrat,
							   &stratPtr,
							   1,
                               selOptions,
                               connectNo,
                               TRUE);
        if (ret != RET_SUCCEED)
        {
            FREE_DYNST(searchLnkPtr, A_SearchLnk);
            DBA_FreeHier(hierStrat);
            return(ret);
        }

        /* Update/Insert strategy_element into database */
        hierUpdDbSt.hierHead        = hierStrat;
	    hierUpdDbSt.hierDynStEn      = A_StratElt;  /* PMSTA-13295 - JPP - 20111219 */
	    hierUpdDbSt.entity          = StratElt;
	    hierUpdDbSt.type            = FALSE;
	    hierUpdDbSt.insFct          = FIN_StratInsDbStratElt;
	    hierUpdDbSt.transFlag       = FALSE;
        hierUpdDbSt.connectNo       = *connectNo;
        hierUpdDbSt.modifOptions    = selOptions;

        ret = DBA_HierUpdateDatabase(&hierUpdDbSt);
        if (ret != RET_SUCCEED)
        {
            DBA_FreeHier(hierStrat);
            return(ret);
        }

        /* Reset hierarchy */   /* REF5239 - RAK - 000922 - Use LASTDYNST and < instead of <= */
        for (DBA_DYNST_ENUM j = 0 ; j <= LASTDYNST ; j++)                  /* PMSTA-13295 - JPP - 20120404 */
        {
            DBA_FreeHierEltRecord(hierStrat, j);
        }

    }/* Main Loop : for each strategy history ... */

    FREE_DYNST(searchLnkPtr, A_SearchLnk);

    /* Free allocated structures */
    DBA_FreeHier(hierStrat);

    return(ret);
}


/************************************************************************
**      END  finlib11.c
*************************************************************************/

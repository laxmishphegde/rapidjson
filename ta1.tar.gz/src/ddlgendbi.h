/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef DDLGENDBI_H
#define DDLGENDBI_H

/************************************************************************
**      Constant & Macro definitions
*************************************************************************/

/************************************************************************
**      Structures & typedef definitions
*************************************************************************/

/************************************************************************
**      External definitions attached to : ddlgendbi.cpp
*************************************************************************/
#include <map>
#include <string>

#include       "ddlgenmsg.h"
#include   "ddlgencfgfile.h"

class DdlGenVar;
class DdlGenVarHelper;
class DdlGenFile;
class DdlGenContext;
class DdlGenDbi;
class DdlGen;
class DdlGenFromFile;
class DdlGenFromFileContext;
class DdlGenEntity;
class DdlGenSqlBlock;

typedef enum
{
    TagSql_None,
    TagSql_Body,
    TagSql_SProcBegin,
    TagSql_SProcStdBegin,
    TagSql_SProcEnd,
    TagSql_FuncBegin,
    TagSql_FuncEnd,
    TagSql_ExecBegin,
    TagSql_ExecEnd,
    TagSql_ViewBegin,
    TagSql_ViewEnd,
    TagSql_TriggerBegin,
    TagSql_TriggerEnd,
    TagSql_Select,
    TagSql_SelectDistinct,
    TagSql_SelectList,
    TagSql_SelectCall,
    TagSql_SelectCheck,
    TagSql_SelectInVar,
    TagSql_SelectVar,
    TagSql_Exec,
    TagSql_Language,
    TagSql_SetVar,
    TagSql_Secured,
    TagSql_StdProc,
    TagSql_Call,
    TagSql_CallStd,
    TagSql_InsertCall,
    TagSql_If,
    TagSql_IfExists,
    TagSql_Else,
    TagSql_ElseThen,
    TagSql_ElseIf,
    TagSql_Then,
    TagSql_Begin,
    TagSql_BeginIf,
    TagSql_BeginElse,
    TagSql_BeginBlk,
    TagSql_End,
    TagSql_EndIf,
    TagSql_EndBlk,
    TagSql_While,
    TagSql_GenIf,
    TagSql_SetRowcount,
    TagSql_SetDatefirst,
    TagSql_SetForcePlan,
    TagSql_GetUpdateCount,
    TagSql_Check,
    TagSql_BeginTran,
    TagSql_Commit,
    TagSql_Rollback,
    TagSql_RollbackTrigger,
    TagSql_Insert,
    TagSql_Update,
    TagSql_UpdateNew,
    TagSql_Delete,
    TagSql_Truncate,
    TagSql_Create,
    TagSql_Drop,
    TagSql_Rename,
    TagSql_Cursor,
    TagSql_ForSelect,
    TagSql_Custom,
    TagSql_MainDLMCheck, /* PMSTA-24026 - DDV - 161122 - Data framework */
    TagSql_AddDLMCheck,  /* PMSTA-24026 - DDV - 161122 - Data framework */
    TagSql_Print,
    TagSql_Last
} DDL_TAG_NAT_ENUM;

typedef enum
{
    DmlEvent_None = -1,
    DmlEvent_Insert = 0,
    DmlEvent_Update,
    DmlEvent_Delete,

    DmlEvent_All,

    DmlEvent_Last
} DML_EVENT_ENUM;

typedef enum
{
    EventPos_None = -1,
    EventPos_All = 0,
    EventPos_Before,
    EventPos_After,

    EventPos_Last
} EVENT_POS_ENUM;

typedef enum
{
    TriggerPos_None = -1,
    TriggerPos_BeforeStandard = 0,
    TriggerPos_AfterStandard,
    TriggerPos_Before,
    TriggerPos_BeforeEachRow,
    TriggerPos_AfterEachRow,
    TriggerPos_After,
    TriggerPos_Init,
    TriggerPos_Last
} TRIGGER_POS_ENUM;

typedef enum
{
    OptimisticLocking_None,
    OptimisticLocking_DbAttrib,
    OptimisticLocking_RowScn,
    OptimisticLocking_RowVersion
} OPTIMISTIC_LOCKING_ENUM;

typedef enum
{
    DDlCmdType_None,
    DDlCmdType_Create,
    DDlCmdType_Drop,
    DDlCmdType_DropAll,
    DDlCmdType_Grant,
    DDlCmdType_CleanUpView,
    DDlCmdType_Init,
    DDlCmdType_Exec,
    DDlCmdType_DbProcess,
    DDlCmdType_DML,
    DDlCmdType_AlterTable,
    DDlCmdType_AlterColumn

} DDL_CMD_TYPE_ENUM;

extern SYSNAME_T      EV_TascLoginUserCode;
extern DBA_RDBMS_ENUM EV_RdbmsDdlGen;

class DdlGenDependKey
{
public:
    DdlGenDependKey(DICT_T dictId, std::string sqlName, DictDependsAccessEn accessEn, DBA_DYNTYPE_ENUM dynTypeEn);

    DdlGenDependKey(const DdlGenDependKey &ref)
        : DdlGenDependKey(ref.m_dictId, ref.m_sqlName, ref.m_accessEn, ref.m_dynTypeEn)
    {
        *this = ref;
    }

    virtual ~DdlGenDependKey()
    {

    }

    DdlGenDependKey& operator=(const DdlGenDependKey &ref)
    {
        this->m_dictId     = ref.m_dictId;
        this->m_sqlName    = ref.m_sqlName;
        this->m_accessEn   = ref.m_accessEn;
        this->m_dynTypeEn  = ref.m_dynTypeEn;
        this->m_objectEn   = ref.m_objectEn;
        this->m_dynStEn    = ref.m_dynStEn;

        return *this;
    }

    bool operator<(const DdlGenDependKey &ref) const
    {
        int iCmp = this->m_sqlName.compare(ref.m_sqlName);
        if (iCmp < 0)
        {
            return true;
        }

        if (iCmp > 0)
        {
            return false;
        }

        if (this->m_accessEn < ref.m_accessEn)
        {
            return true;
        }

        return false;
    }

    bool operator==(const DdlGenDependKey &ref) const
    {
        if (this->m_sqlName.compare(ref.m_sqlName) != 0)
        {
            return false;
        }

        if (this->m_accessEn == ref.m_accessEn)
        {
            return false;
        }
        return true;
    }

    DICT_T             getDictId() const
    {
        return this->m_dictId;
    }

    const std::string  &getSqlName() const
    {
        return this->m_sqlName;
    }

    DictDependsAccessEn getAccessEn() const
    {
        return this->m_accessEn;
    }

    std::string getAccessStr() const
    {
        switch (this->m_accessEn)
        {
            case DictDependsAccessEn::Access:
                return "Access";

            case DictDependsAccessEn::Insert:
                return "Insert";

            case DictDependsAccessEn::Update:
                return "Update";

            case DictDependsAccessEn::Delete:
                return "Delete";

            case DictDependsAccessEn::Truncate:
                return "Truncate";

            case DictDependsAccessEn::Create:
                return "Create";

            case DictDependsAccessEn::Returns:
                return "Returns";

            case DictDependsAccessEn::Call:
                return "Call";

            case DictDependsAccessEn::CallParameter:
                return "CallParameter";

            case DictDependsAccessEn::Parameter:
                return "Parameter";

            case DictDependsAccessEn::None:
            default:
                return "None";
        }
    }

    DBA_DYNTYPE_ENUM getDynTypeEn() const
    {
        return this->m_dynTypeEn;
    }

    OBJECT_ENUM        getObjectEn() const
    {
        return this->m_objectEn;
    }

    DBA_DYNST_ENUM     getDynStEn() const
    {
        return this->m_dynStEn;
    }

private:

    DICT_T              m_dictId;
    std::string         m_sqlName;
    DictDependsAccessEn m_accessEn;
    DBA_DYNTYPE_ENUM    m_dynTypeEn;

    OBJECT_ENUM         m_objectEn;
    DBA_DYNST_ENUM      m_dynStEn;
};

class DdlObjDefKey
{
public:
    DdlObjDefKey(DBA_RDBMS_ENUM      rdbmsEn,
                 DDL_OBJ_ENUM        ddlObjEn,
                 const std::string  &dbName,
                 const std::string  &entity,
                 const std::string  &table,
                 const std::string  &objName);

    DdlObjDefKey(DBA_RDBMS_ENUM      rdbmsEn,
                 DDL_OBJ_ENUM        ddlObjEn,
                 DICT_ENTITY_STP     dictEntityStp,
                 const std::string& objName);

    DdlObjDefKey(const DdlObjDefKey& ref);

    ~DdlObjDefKey();

    DdlObjDefKey& operator=(const DdlObjDefKey& toCopy);
    bool operator== (const DdlObjDefKey & a) const;
    bool operator< (const DdlObjDefKey & a) const;

    DDL_OBJ_ENUM       getDdlObjEn() const;
    const std::string& getDbName() const;
    const std::string& getDbDbName() const;
    const std::string& getObjName() const;
    const std::string& getDbObjName() const;

    const std::string& getEntitySqlName() const;
    const std::string& getTableSqlName() const;

    DICT_ENTITY_STP                            getDictEntityStp();

    DBA_RDBMS_ENUM                             m_rdbmsEn;

protected:
    DICT_ENTITY_STP                            m_dictEntityStp;

    MemoryPool                                 m_mp;

private:
    DdlObjDefKey(DBA_RDBMS_ENUM rdbmsEn);

    DDL_OBJ_ENUM                               m_ddlObjEn;
    std::string                                m_dbName;
    std::string                                m_dbDbName;
    std::string                                m_entity;
    std::string                                m_table;
    std::string                                m_objName;
    std::string                                m_dbObjName;
};

class DdlObjDef : public DdlObjDefKey
{
public:
    DdlObjDef(DBA_RDBMS_ENUM      rdbmsEn,
              DDL_OBJ_ENUM        ddlObjEn,
              const std::string  &dbName,
              const std::string  &entity,
              const std::string  &table,
              const std::string  &objName);

    DdlObjDef(DBA_RDBMS_ENUM      rdbmsEn,
              DDL_OBJ_ENUM        ddlObjEn,
              DICT_ENTITY_STP     dictEntityStp,
              const std::string& objName);

    DdlObjDef(const DdlObjDef& ref);

    ~DdlObjDef();

    DdlObjDef& operator=(const DdlObjDef& toCopy);

    bool                                       check();

    DBA_DYNFLD_STP                             getDdlgenObjectStp();

    std::string                                m_ddlUser;
    std::string                                m_refEntity;

    std::vector<std::string>                   m_refAttributeTab;
    std::string                                m_searchCondition;
    REF_DELETE_RULE_ENUM                       m_refDeleteRuleEn;

    bool                                       m_bValidated;
    bool                                       m_bTreated;

    bool                                       m_isPrimary;
    bool                                       m_isClustered;

    std::vector<std::string>                   m_dropCmdTab;
    std::vector<std::vector<std::string>>      m_dropParamTab;
    std::string                                m_bodyStr;
    std::vector<std::string>                   m_grantCmdTab;
    DictSprocClass                             m_dictSprocSt;
    std::map<std::string, DICT_ENTITY_STP>     m_dependsEntityMap;
    std::set<DdlGenDependKey>                  m_dependsSprocSet;    /* PMSTA-29956 - LJE - 180125 */
    std::set<DdlGenDependKey>                  m_dependsAccessSet;   /* PMSTA-29956 - LJE - 180125 */
    std::string                                m_outputFileStr;
    unsigned                                   m_outFileLinePos;
    bool                                       m_bSendIntoDb;

    bool                                       m_bSaved;

private:
    DBA_DYNFLD_STP                             m_ddlgenObjectStp;
};

class DdlGenWhereDep
{
public:
    // Constructors
    DdlGenWhereDep(const std::string     &paramLeftStr,
                   const DICT_ATTRIB_STP  paramLeftAttribStp,
                   const std::string     &paramRightStr,
                   const DICT_ATTRIB_STP  paramRightAttribStp,
                   const std::string     &paramOperStr,
                   DdlGenDbi             &refDdlGenDbi);

    DdlGenWhereDep(const DdlGenWhereDep &paramDdlGenWhereDep);

    std::string      leftStr;
    DICT_ATTRIB_STP  leftAttribStp;
    std::string      rightStr;
    DICT_ATTRIB_STP  rightAttribStp;
    std::string      operStr;

    std::string      leftAliasStr;
    std::string      rightAliasStr;

    DICT_ATTRIB_STP  mainObjAttribStp;

private:
    DdlGenDbi       &m_refDdlGenDbi;
};

class DdlGenDbi:public DdlGenMsg
{
public:
    // Constructors
    DdlGenDbi(DDL_OBJ_ENUM       paramDdlObjEn,
              DdlGenContext     &paramDdlGenContext,
              DdlGenVarHelper   *paramVarHelperPtr,
              DdlGenFile        *paramFileHelper,
              TARGET_TABLE_ENUM  paramTargetTableEn);

    DdlGenDbi(const DdlGenDbi&) = delete;

    // Destructor
    virtual ~DdlGenDbi();

    DdlGenDbi& operator=(const DdlGenDbi&) = delete;

    // Static Methods
    static std::string getTableFullDbName(const std::string &databaseName, const std::string &userName, const std::string &tableName, DBA_RDBMS_ENUM rdbmsEn);
    static std::string endOfCmd(DBA_RDBMS_ENUM rdbmsEn);
    static std::string beginOfBlock(DBA_RDBMS_ENUM rdbmsEn);
    static std::string endOfBlock(DBA_RDBMS_ENUM rdbmsEn);
    static void        getMasterBusinessEntityInfo(DbiConnection *dbiConnPtr);
    static void        convertSqlBlock(std::string &scptToTreat, DdlGenFromFile *scriptDdlGenPtr);
    static void        finishSqlBlock(DdlGenSqlBlock &sqlBlock, DBA_RDBMS_ENUM rdbmsEn, DDL_OBJ_ENUM ddlObjEn);
    static std::string getDiscardTrigger(std::string &, std::string::size_type, DdlGenContext *currDdlGenContextPtr, DdlGenVarHelper *varHelperPtr, DdlGen *);
    static std::string getReleaseTrigger(std::string&, std::string::size_type, DdlGenContext* currDdlGenContextPtr, DdlGenVarHelper* varHelperPtr, DdlGen*);
    static std::string getRootEntity(std::string &, std::string::size_type, DdlGenContext *currDdlGenContextPtr, DdlGenVarHelper *varHelperPtr, DdlGen *);
    static std::string isRootLevel(std::string &, std::string::size_type, DdlGenContext *currDdlGenContextPtr, DdlGenVarHelper *varHelperPtr, DdlGen *);
    static void        getIndexSqlName(DBA_DYNFLD_STP xdAttribStp, std::string &sqlName, std::string &colExpr, DdlGenContext *ddlGenContextPtr);
    static std::string getCmdUseDb(const std::string &databaseName, DBA_RDBMS_ENUM rdbmsEn);
    static std::string getCmdGo(DBA_RDBMS_ENUM rdbmsEn);
    static std::string setUserCmd(std::string userName, DBA_RDBMS_ENUM rdbmsEn);
    static std::string getStdDdlObjType(DDL_OBJ_ENUM ddlObjType);
    static std::string getDataTypeSqlName(DATATYPE_ENUM dataTpProgN, DBA_RDBMS_ENUM rdbmsEn, bool bWithPrecision = true, unsigned int maxDbLenN = 0);
    static std::string getVarPrefix(DBA_RDBMS_ENUM rdbmsEn);
    static std::string getParamPrefix(DBA_RDBMS_ENUM rdbmsEn);
    static std::string::size_type getMaxDDLObjLength(DBA_RDBMS_ENUM rdbmsEn);
    static bool        isReadOnlyParam(DBA_RDBMS_ENUM rdbmsEn);
    static bool        isReadOnlyCursorVar(DBA_RDBMS_ENUM rdbmsEn);
    static std::string getVarAssign(DBA_RDBMS_ENUM rdbmsEn);
    static std::string getVarAssignCmd(DBA_RDBMS_ENUM rdbmsEn);
    static std::string getParamDefaultAssign(DBA_RDBMS_ENUM rdbmsEn);
    static std::string getEmptyFrom(DBA_RDBMS_ENUM rdbmsEn);
    static bool         isCascadeNullOnString(DBA_RDBMS_ENUM rdbmsEn);
    static std::string  convert(DATATYPE_ENUM outDataTypeEn, const std::string &toConvertStr, DBA_RDBMS_ENUM rdbmsEn, DDL_OBJ_ENUM ddlObjEn, bool bNull = false);
    static std::string  getCmdStrReplace(DBA_RDBMS_ENUM);
    std::string         getCmdStrReplace();

    /* replaceFunctionByFct functions */
    static std::string manageHintIndexTag(DdlGenContext*, DdlGenVarHelper*, std::vector<std::vector<std::string>>&);
    static std::string manageHintTag(DdlGenContext*, DdlGenVarHelper*, std::vector<std::vector<std::string>>&);
    static std::string manageStrReplace(DdlGenContext*, DdlGenVarHelper*, std::vector<std::vector<std::string>>&);   /* PMSTA-46681 - LJE - 230301 */
    static std::string manageAppendingReplace(DdlGenContext*, DdlGenVarHelper*, std::vector<std::vector<std::string>>&);   /* PMSTA-46681 - LJE - 230301 */

    static OPTIMISTIC_LOCKING_ENUM getOptimisticLockingRule(DICT_ATTRIB_STP dictAttribStp, DBA_RDBMS_ENUM rdbmsEn);

    // Temporary Table management
    enum class TempTableSpec
    {
        None,
        Session,
        Global,
        MemoryOptimzed,
        Type
    };


    static TempTableSpec getTempTableSpec(DBA_RDBMS_ENUM, DICT_ENTITY_STP);
    static TempTableSpec getTempTableSpec(DBA_RDBMS_ENUM, DBA_DYNFLD_STP);
    static bool          isTempTableLocalStoredProc(DBA_RDBMS_ENUM, DICT_ENTITY_STP);
    static bool          isTempTableRuntime(DBA_RDBMS_ENUM, DICT_ENTITY_STP);
    static std::string   getTempTablePrefix(DBA_RDBMS_ENUM, DICT_ENTITY_STP = nullptr, bool = false);
    static std::string   getTempTablePrefix(DBA_RDBMS_ENUM, DBA_DYNFLD_STP);


    // Methods
    std::string         getTableFullDbName(const std::string &databaseName, const std::string &userName, const std::string &tableName);
    virtual std::string getEntitySqlName(DICT_ENTITY_STP locDictEntityStp, TARGET_TABLE_ENUM locTargetTableEn = TargetTable_Undefined, bool bMdSqlName = false);
    virtual std::string getEntityFullSqlName(DICT_ENTITY_STP locDictEntityStp, TARGET_TABLE_ENUM locTargetTableEn, const std::string &realEntitySqlName, DDL_VIEW_ENUM outputViewEn, bool bTryToSecure = false);

    DICT_ENTITY_STP       buildDictEntityFromSys(const std::string &, const std::string &, bool &);
    std::map<std::string, std::map<std::string, std::set<std::string>>>   getAllTablesFromSys();

    std::string         getTableWithSecurity(DICT_ENTITY_STP locDictEntityStp, TARGET_TABLE_ENUM locTargetTableEn, const std::string &databaseName, const std::string &tableName);
    std::string         getSecuOnBothDSP(std::string entityAlias);

    std::string         getTargetDBName();

    std::string         execApplRaisError(int numberError, std::string errDdlObjSqlName, std::string errInfo1, std::string errInfo2, std::string errInfo3, bool toQuote=true);
    std::string         execApplRaisError(int numberError, std::string errDdlObjSqlName, std::string errInfo1, DdlGenVar errVar2, std::string errInfo3);

    std::string         getCmdIfExsists(const std::string &test, const std::string &selectRequest, const std::string &ifExistsCmd, const std::string &ifNotExistsCmd, bool bNotExists = false, bool bToContinue = false);
    std::string         getCmdIfExsists(const std::string &selectRequest, const std::string &ifExistsCmd, const std::string &ifNotExistsCmd = std::string(), bool bNotExists = false);
    std::string         getEndIfExists();
    std::string         getCmdExists(bool bNot, std::string &closeCmd);
    std::string         getCmdIfThen(const std::string &condition, const std::string &thenPart, bool bNot=false);
    std::string         getEndIf(bool bEndIfExists = false);
    std::string         getCmdIfThenElse(const std::string &condition, const std::string &thenPart, const std::string &elsePart, bool bElseIf = false, bool bToContinue = false);
    std::string         getCmdWhile(std::string test, std::string whileRequest);

    std::string         getCmdAssignBySelect(DdlGenVar &variable, std::string assignValue, std::string fromWhere);
    std::string         getCmdAssignByValue(DdlGenVar &variable, std::string assignValue);
    std::string         getCmdAssignOnSelect(DdlGenVar &variable, std::string assignValue, std::stringstream & finalAssignStream, std::stringstream & emptyAssignStream, bool bLastAssign = false, bool bModify = true);

    std::string         getCmdSelect(const std::string &selectStr, const std::string &cursorStr, const std::string &initStr);
    std::string         getCmdInsert(const std::string &, const std::string &);

    std::string         getCmdRename(const std::string &fromSqlName, const std::string &toSqlName, DDL_OBJ_ENUM ddlObjType);

    std::string         getExceptionBegin();
    std::string         getException(std::string exceptionClauseStr = "others");
    std::string         getExceptionEnd();

    std::string         getReturnReturnStatus();
    std::string         getReturnStatusOnError();

    std::string         getCmdExecSProc(const std::string &databaseName, 
                                        const std::string &sProcName, 
                                        const std::string &sProcParam, 
                                        const std::string &returnVar, 
                                        std::vector<std::string>& outputVariables,
                                        std::vector<std::string>& outputParams,
                                        DictSprocClass *dictSprocStp);
    std::string         getCmdExecSProc(const std::string &databaseName, 
                                        const std::string &sProcName, 
                                        std::vector<std::string> & sProcParam, 
                                        DictSprocClass *dictSprocStp);

    std::string         getCmdTruncateTable(DICT_ENTITY_STP  truncDictEntityStp, bool bForce, bool inBlock = true);
    std::string         getCmdCreateTempTable(DICT_ENTITY_STP  tmpTblDictEntityStp);

    void                printPkSecuInfo(const DictSprocClass &procSt, std::stringstream & outStream);

    std::string         getExecMainDbCall(std::string procName, std::string returnValue = ""); /* PMSTA-14556 - LJE - 120705 */
    std::string         getMainDbCall();

    std::string         getEntityDbName(DICT_ENTITY_STP paramDictEntityStp);

    std::string		    newLine();

    void                clearIndent();
    void                setIndent(int     offset);
    void                setPreIndent(std::string preIndent);
    std::string         getPreIndent() const;
    std::string         getIndent();
    int                 getIndentNbr() const;
    std::string         getIndented(std::stringstream &);

    void                setAlias(const char *newAlias);
    void                setAlias(const std::string &newAlias);
    std::string         getAlias(bool bInFrom = false) const;

    std::string         endOfCmd();
    std::string         getCmdEndOfCmd(bool bForceEnd=false);
    std::string         getCmdEndDDLObj();

    std::string         getCmdFrom();
    std::string         getCmdInnerJoin();
    std::string         getCmdLeftJoin();
    std::string         getCmdRightJoin();
    std::string         getCmdJoinOn();

    std::string         getCmdEndSProc();
    std::string         getCmdEndFunc();
    std::string         getCmdEndTrigger();
    std::string         getNewAlias() const;
    std::string         getOldAlias() const;
    std::string         getNewPrefix() const;
    std::string         getOldPrefix() const;

    std::string         setUserCmd(std::string userName);

    std::string         getReturnStatusName(bool bPrintSqlName = true);

    std::string         getSetRowcount();
    std::string         getSetDateFirst();

    static void            standardize(std::string &ddlObject, DdlGenContext *ddlGenContextPtr);
    static void            standardize(std::string &ddlObject, DBA_RDBMS_ENUM rdbmsEn);
    void                   standardize(std::string &ddlObject);

    void                   printRowLimitOnWhere(std::stringstream &whereStream);

    bool                   isFkApplied();
    bool                   isCascadeAllowed(DDL_OBJ_ENUM ddlObjType);
    bool                   isSystemTable(const std::string & tableName);
    bool                   isReferenceOnFk();
    bool                   isDefaultInListPartition();
    bool                   isPartitionsByAlter(FEATURE_AUTH_ENUM partAuthEn);
    bool                   isDescAllInAlterTable();
    bool                   isModifyDefaultByReplace();
    std::string::size_type getMaxDDLObjLength();
    bool                   isSysMdFullAccessiblity();
    bool                   isIndexDefinedOnPK();
    bool                   isAutoIndexOnPK();
    bool                   isPKToDo();
    bool                   isAllowModifNewRecord();
    bool                   isOptionalParamAllowed();
    bool                   isUseForSelectInsteadOfCursor();
    bool                   isUpdateOnTriggerByAssign();
    bool                   isRollbackOnTriggerAllowed();
    bool                   isReturnOnTriggerNeeded();
    bool                   isAllowMultiAlterTable();
    bool                   isOneRequestByAlter();
    bool                   isTagInBlock(DDL_TAG_NAT_ENUM);


    /* PMSTA-30450 - LJE - 180305 */
    const std::string getOrderSortRule(const std::string &sortRuleStr);

    static const std::string getOrderSortRule(SORTRULE_ENUM, DBA_RDBMS_ENUM);
    const std::string getOrderSortRule(SORTRULE_ENUM sortRuleEn);

    std::string convertDateVar(DATATYPE_ENUM outDataTypeEn, std::string toConvertStr, std::string styleStr); 
    std::string convertVar(DATATYPE_ENUM outDataTypeEn, std::string toConvertStr, std::string styleStr);
    std::string convert(DATATYPE_ENUM outDataTypeEn, const std::string &toConvertStr, bool bNull=false);

    static unsigned int stringLiteralMaxValue(DBA_RDBMS_ENUM);

    bool   returnInSProcAvailable();
    bool   beginTranInSProcAvailable();
    bool   commitInSProcAvailable();

    std::string getDdlModif(const std::string &ddlModif);
    std::string getCmdExecSql(const std::string &ddlModif, const std::string &quote="'");

    std::string getExecuteAs(DBA_EXECUTE_AS_ENUM executeAsEn);
    std::string getDeterministic(bool bDeterministic);

    static std::string getWithRecomplie();

	std::string getAutonomousTransaction();		/* PMSTA-20494 - TEB - 160808 */

    std::string getEntityDbSqlName(DICT_ENTITY_STP, const char*);
    std::string getDefaultConstrName(std::string database, std::string tableSqlName, std::string attribSqlName);

    OPTIMISTIC_LOCKING_ENUM getOptimisticLockingRule(DICT_ATTRIB_STP);
    std::string getOptimisticLockingSqlName(DICT_ENTITY_STP);

    std::string getDdlFullName(std::string database, std::string ddlObjSqlName);

    std::string getCmdCreate(std::string database, std::string tableSqlName, std::string ddlObjSqlName, DDL_OBJ_ENUM ddlObjType, const std::string &refTableSqlName = std::string(), const std::string &refAttribSqlName = std::string(), bool = true);
    std::string getCmdModify(std::string database, std::string tableSqlName, std::string ddlObjSqlName, DDL_OBJ_ENUM ddlObjType);
    std::string getCmdDrop(std::string  database, 
                           std::string  tableSqlName, 
                           std::string  ddlObjSqlName, 
                           DDL_OBJ_ENUM ddlObjType,
                           DdlObjDef    *ddlObjDef = nullptr,
                           std::string refTableSqlName = std::string(), 
                           std::string refAttribSqlName = std::string(), 
                           const std::string &userName = std::string());
    std::string getCmdChangeState(std::string database, std::string tableSqlName, std::string ddlObjSqlName, DDL_OBJ_ENUM ddlObjType, bool bDisable);

    std::string getCmdCreateIndex(std::string database, std::string tableSqlName, std::string locDdlObjSqlName, bool bUnique, bool bCluster);
    std::string getCmdCreateIndexFinal(DBA_DYNFLD_STP, DdlGenEntity *);

    bool        isIfExistsClause(DDL_OBJ_ENUM);
    std::string getIfExistsClause(DDL_OBJ_ENUM, bool);

    void printGrant(std::stringstream & outStream, std::string database, std::string tableSqlName, std::string locDdlObjSqlName, DDL_OBJ_ENUM ddlObjType, DBA_EXECUTE_AS_ENUM executeAsEn);
    std::string getCmdRole(const std::string &role);
    std::string getCmdUser(const std::string &user);
    void printGrantToAllSchema(std::stringstream & outStream, const std::string &currDatabase, const std::string &grant, const std::string &option);

    RET_CODE    getCmdReturnFunction(DATATYPE_ENUM dataTpProgN, std::stringstream &outStream);
    RET_CODE    getCmdReturnProcedure(DictSprocClass &sprocClass, std::stringstream &outStream);

    void        getCmdCreateTrigger(std::stringstream &headerStream,
                                    std::stringstream &footerStream,
                                    DICT_ENTITY_STP dictEntityStp,
                                    std::string locDdlObjSqlName,
                                    std::string genInfoStr,
                                    DML_EVENT_ENUM paramDmlEvent,
                                    EVENT_POS_ENUM paramEventPos,
                                    TRIGGER_POS_ENUM paramTriggerPos);

    std::string getDdlObjType(DDL_OBJ_ENUM ddlObjType);

    std::string getCmdSelObjInDb(const std::string &database, const std::string &tableSqlName, const std::string &ddlObjSqlName, DDL_OBJ_ENUM ddlObjType, std::string userName = std::string(), std::string refTableSqlName = std::string(), std::string refAttribSqlName = std::string());
    void        getIdFromRequest(const std::string &request, std::set<ID_T> &idSet, bool bSource, bool bAutonom = false);
    ID_T        getMaxId(DICT_ENTITY_STP dictEntityStp, bool bSource);
    ID_T        getIdentityStartValue(DICT_ENTITY_STP dictEntityStp, DdlGenEntity *ddlGenEntity, bool bForce);
    ID_T        getIdByBk(DICT_ENTITY_STP dictEntityStp, const std::string &code);
    void        getIdsByQuery(DICT_ENTITY_STP dictEntityStp, const std::string &query, std::set<ID_T> &idSet);
    void        getCountRecord(DICT_ENTITY_STP dictEntityStp, const std::string &query, const std::string& realSqlName, ID_T &countNbr, bool bSource, bool bAutonom = false);

    std::string getCmdIdentity(bool bUpdate, ID_T, int, DICT_ENTITY_STP);
    std::string getCmdIdentityIncrement(DdlGenVar *varDest, std::string databaseStr, std::string entityStr);
    std::string getCmdReserveIdentity(DdlGenVar *varDest, DICT_ENTITY_STP dictEntityStp, const std::string &entityStr, const std::string& resNbrStr, DdlGenFromFile * =NULL);
    std::string getIdentitySequencName(DICT_ENTITY_STP dictEntityStp, std::string);

    void        setIdentityStartValue(DICT_ENTITY_STP dictEntityStp, ID_T newStartValue);

    std::string getErrorMessages(RET_CODE             &sqlExecRet,
                                 DBA_ERRMSG_HEADER_ST &msgStructHeaderSt,
                                 DDL_OBJ_ENUM          ddlObjType,
                                 const std::string    &ddlSqlName,
                                 const std::string    &ddlGenStr,
                                 int                  &firstErrLine);

    RET_CODE    sqlExec(const std::string&);
    RET_CODE    sqlExec(const DdlObjDef &ddlGenObjDef);
    RET_CODE    compileDdlObj(const DdlObjDef &ddlGenObjDef);
    RET_CODE    checkDdlObj(const DdlObjDef &ddlGenObjDef);

    std::string getCmdAlterSepartor(bool bFirst);
    std::string getCmdColAlterSepartor(bool bFirst, bool bAddNewCol);
    std::string getCmdModifyColumn();
    std::string getCmdModifyDataType();
    std::string getCmdModifyDefault(bool);
    std::string getCmdNullable(bool bNullable, bool bAlter=false);
    std::string getCmdClustered(bool bClustered);
    std::string getCmdAddColumn(bool bFirst);
    std::string getCmdEndAddColumn();

    bool        isClusteredIdxAllowed();
    bool        isCreateAsSelectBehavior();
    bool        isReplaceAllowed(DDL_OBJ_ENUM ddlObjType);
    bool        isFunctionEqProc();
    bool        isAddIdentityAllowed();
    bool        isModifyIdentityAllowed();

    bool        prepareDataMigration(DICT_ENTITY_STP, DICT_ENTITY_STP);
    bool        releaseDataMigration(DICT_ENTITY_STP, DICT_ENTITY_STP);

	std::string getDataTypeSqlName(DATATYPE_ENUM dataTpProgN, bool bWithPrecision = true, unsigned int maxDbLenN = 0);

    std::string getCmdCreatePhysicalProperties(std::string physicalSegProperties, DBA_DYNFLD_STP currRecordStp, std::map<SMALLINT_T, DBA_DYNFLD_STP> *currRecordCompoMapPtr, DdlGenEntity &ddlGenEntity, bool bInString = false);

    std::string getCmdInsertIntoOptim(const std::string &insertCmd, const std::string &selectCmd, const std::string &restrictCmd);

    std::string getParamPrefix();
    std::string getParamAssign(const std::string &paramSqlName);
    std::string getVarPrefix();

    std::string getEmptyFrom();

    std::string getCmdSelectList(const std::string &value, const std::string &paramAlias);

    std::string getIdentityValue();
    void        getCmdReturnIdentityValue(DICT_ATTRIB_STP idAttribParamStp, DdlGenVar *variable, std::string &inInsertStr, std::string &afterInsertStr);

    static std::string getRdbmsShortName(DBA_RDBMS_ENUM rdbmsEn);
    std::string        getRdbmsShortName();
    static std::string getRdbmsName(DBA_RDBMS_ENUM rdbmsEn);
    std::string        getRdbmsName();

    std::string length();
    std::string substring();
    
    static std::string appendCharter(DBA_RDBMS_ENUM);
    std::string appendCharter();
    static std::string getCmdDbAccess(DBA_RDBMS_ENUM);
    std::string getCmdDbAccess();
    std::string getCmdGo();
    std::string getVarAssignCmd();
    std::string getVarAssign();

    std::string getDbo();
    std::string getCmdUserName();
    std::string getCmdApplUserId();
    std::string getCmdApplSessionCd();
    std::string getCmdAppContext(const std::string &cmdTypeStr);

    static std::string getCmdIsNull(DBA_RDBMS_ENUM);
    std::string getCmdIsNull();
    std::string getCmdChar();
    std::string getCmdAscii();
    std::string getAllTriggers();
    void        getAllTriggersCmd(const std::string &fullSqlName, bool bEnable, std::vector<std::string> &allTriggersReqVector);
    void        getDisableAllTriggersCmd(const std::string &fullSqlName, std::vector<std::string> &allTriggersReqVector);
    void        getEnableAllTriggersCmd(const std::string &fullSqlName, std::vector<std::string> &allTriggersReqVector);
    std::string getCmdGetDate();
    std::string getCmdGetDateTime(); /* PMSTA-25331 - TEB - 20171018 - Need millisecond precision for DateTime */
    std::string getCmdMagicBeginDate();
    std::string getCmdMagicEndDate();
    
    static std::string getCmdUpdateCount(DdlGenContext*);
    
    std::string getCmdAssignUpdateCount(const std::string&);
    std::string getCmdModifStatMask();
    std::string getCmdBootTime();
    std::string getCmdCountBig();
    std::string getCmdTranscount();
    std::string getCmdTranstate();
    std::string getCmdSpid();
    std::string getCmdHostName();
    std::string getUpdating();

    void        disableIdentity(DICT_ENTITY_STP, DICT_ENTITY_STP);
    void        enableIdentity(DICT_ENTITY_STP, DICT_ENTITY_STP);

    static std::string getCmdNoOp(DdlGenFromFile *ddlGenFromFilePtr);

    std::string getCmdCharindex();

    static std::string getCmdPrintMsg(const std::string &msg, bool bOnProcedure, DdlGenContext *ddlGenContextPtr);
    std::string        getCmdPrintMsg(const std::string &msg, bool bOnProcedure);
    std::string        getCmdPrintMsg(std::vector<std::string> &printList);

    std::string getExecCmd(const std::string &, std::vector<std::string>&, DictSprocClass* = nullptr, bool = false);

    std::string getVarSepartor();
    std::string getVarEnd();

    std::string getParamInit();
    std::string getParamClose(bool);
    std::string getParamSepartor();
    bool        isAssingBySelect();
    bool        isDropTableOnBootStrap();
    std::string getCallOutput();

    std::string getReturnInProc(const std::string & value);

    static std::string getDbError(DdlGenContext* ddlGenContextPtr);

    std::string getProcDeclare();
    std::string getSqlDeclare();

    static void treatProperty(std::string & currProperty, DBA_RDBMS_ENUM rdbmsEn);
    void        treatProperty(std::string & currProperty);

    std::string getWhereComp(const std::string &,
                             DICT_ATTRIB_STP,
                             const std::string &,
                             DICT_ATTRIB_STP,
                             const std::string &,
                             bool);

    void               treateAllVariable(std::string &, bool);

    void               replaceTagConvert(std::string & lineToTreat, DATATYPE_ENUM dataType = NullDataType, DATE_STYLE_ENUM dateTimeStyleEn = DateStyle_None);

    std::string        printDateInfo();
    void		       setGenInfo(); /* PMSTA-14452 - EFE - 130208 */
    std::string		   getGenInfo(bool inComment = true); /* PMSTA-14452 - EFE - 130208 */

    void               printBeginProc(std::stringstream & outStream, DdlGenVarHelper *ddlGenVarHelper);
    std::string        prepareResultSet(std::stringstream & outStream, DdlGen &refDdlGen);

    void               setDdlObjSqlName(const std::string &locDdlObjSqlName);
    const std::string &getDdlObjSqlName() const;
    const std::string &getDbDdlObjSqlName() const;
    void               setDdlObjFullSqlName(const std::string &locDbSqlName, const std::string &locDdlObjSqlName);
    const std::string &getDdlObjFullSqlName();

    std::string        getUpdateRequest(const std::string& fullEntitySqlName,
                                        const std::string& setStr,
                                        const std::string& mainFromStr,
                                        const std::string& addFromStr,
                                        const std::string& fromStr,
                                        const std::string& whereStr);

    std::string        getDeleteRequest(const std::string& entitySqlName,
                                        bool               bOnDdlObj = true);

    std::string        getDeleteRequest(const std::string& entitySqlName,
                                        const std::string& alias,
                                        const std::string& mainFromStr,
                                        const std::string& addFromStr,
                                        const std::string& fromStr,
                                        const std::string& whereStr,
                                        std::vector<std::string>& pkList,
                                        bool               bOnDdlObj = true);

    std::string        getCursorRequest(const std::string& cursorNameStr,
                                        const std::string& cursorSelectStr,
                                        const std::string& cursorVarStr,
                                        const std::string& cursorBodyStr);

    std::string        getCloseCursor(const std::string& cursorNameStr);

    std::string        getCleanStatRequest(const std::string& entitySqlName);

    void               printGrantTable(std::stringstream & outStream, DICT_ENTITY_STP dictEntityStp);
    void               printEndBlockToFile();
    void               printEndBlockToFile(DdlGenSqlBlock & outStream);

    std::string        getCmdCheckpoint();

    std::string        getCmdDataProfileId(bool bConvert = true);
    std::string        getCmdDataProfileIdUser();
    std::string        getCmdLanguageDictId();
    std::string        getCmdThirdPartyId();
    std::string        geCmdAddDlmEMax();
    std::string        geCmdMainDlmEMax();
    std::string        getChangeSetId(bool bConvert = true);
    std::string        setChangeSetId(const std::string &varName);
    std::string        rmChangeSetId();

    std::string        getCollation(DATATYPE_ENUM);

    const std::string  getCmdConnBusinessEntityId();
    const std::string  getCurrentBusinessEntity();

    std::string        setRootEntity(DICT_T entDictId);
    std::string        rmRootEntity();

    std::string        getCmdRmAppContext(const std::string &contextName, const std::string &attributeName);

    const std::string &getTemplateBody(CFG_TEMPLATE_ENUM feature, const std::string &keyStr);

    bool               checkXdIndexStp(DBA_DYNFLD_STP xdIndexStp, DBA_DYNFLD_STP sysXdIndexStp);

    void                   setDdlGenFromFileContextPtr(DdlGenFromFileContext* ddlGenFromFileContextPtr);       /* PMSTA-37366 - LJE - 191118 */
    DdlGenFromFileContext* getDdlGenFromFileContextPtr() const;                                                /* PMSTA-37366 - LJE - 191118 */

    bool                bNestedRequest;
    bool                bUnion;
    bool                bLocalVarHelper;
    DdlGenVarHelper    *varHelperPtr;
    DdlGenFile         *fileHelper;
    TARGET_TABLE_ENUM   targetTableEn;
    int                 recurseEndCpt;

    std::list<DdlGenWhereDep> whereDepList;

    std::string       tmpTableSqlName;
    std::string       realDbName;

    // ********************************************
    // TODO: Must be defined in the Meta-Dictionary
    std::string       getSynonymSqlName();

    void              getAllDdlObjListFromDb(std::map<DdlObjDefKey, DdlObjDef> &ddlObjDefMap,
                                             std::string database,
                                             std::string tableSqlName,
                                             std::string ddlObjSqlName,
                                             DDL_OBJ_ENUM ddlObjType,
                                             std::string refTableSqlName = std::string(),
                                             std::string refAttribSqlName = std::string());


    virtual RET_CODE  printSecurityOnFrom(ENTITY_SECURITY_LEVEL_ENUM   ,
                                          bool                         ,
                                          bool                         ,
                                          const std::string           &,
                                          const std::string           &,
                                          std::stringstream           &)
    {
        return RET_DBA_ERR_NODATA;
    };

    virtual RET_CODE  printSecurityOnWhere(ENTITY_SECURITY_LEVEL_ENUM  ,
                                           DICT_ENTITY_STP             ,
                                           bool                        ,
                                           const std::string          &,
                                           std::stringstream          &)
    {
        return RET_DBA_ERR_NODATA;
    };

    std::stringstream        addFromStream;
    DDL_CMD_TYPE_ENUM        cmdType;

protected:

    std::string               getTruncateRequest(const std::string& entitySqlName);

    FLAG_T                    getDdlObjFromDb(std::stringstream &chkStream, DDL_OBJ_ENUM paramDdlObjEn = DdlObj_None);
    void                      getDependsViewMap(const std::string&, const std::string&, const std::string&, std::map<std::string, std::set<std::string>>&);
    void                      getDropConstraintSet(const std::string&, const std::string&, const std::string&, std::set<std::string>&);

    DdlGenFromFileContext    *m_ddlGenFromFileContextPtr;

    std::vector<std::string>  m_paramVector; /* PMSTA-26000 - LJE - 170130 */
    ID_T                      m_startValue;   
    const std::string         emtpyStr;

    bool                      m_bCustInView;

private:

    std::string getCmdGetAppContext(const std::string &contextName, const std::string &attributeName);
    std::string getCmdSetAppContext(const std::string &contextName, const std::string &attributeName, const std::string &value);

    std::string            m_ddlObjSqlName;
    std::string            m_ddlObjFullSqlName;
    std::string            m_dbDdlObjSqlName;
    std::string            m_dbSqlName;

    int                    indentNbr;
    std::string            indentStr;
    std::string            preIndentStr;

    std::string            alias;

    int                    elseIfCpt;

    std::stringstream      genInfoStream;
};
typedef std::unique_ptr<DdlGenDbi> DdlGenDbiPtr;

#endif	                               /* ifndef DDLGENDDBI_H */
/************************************************************************
**      END       ddlgendbi.h                                   Odyssey
*************************************************************************/

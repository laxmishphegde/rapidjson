/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines      
*************************************************************************/
#define FINLIB12_C

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H
#define MATH_H

#include "unidef.h"         /* Mandatory */
#include "gen.h"
#include "date.h"
#include "dba.h"
#include "hier.h"
#include "fin.h"
#include "scelib.h"
#include "finlib03.h" /* REF6004 - AKO - 011116 */

/************************************************************************
**      External entry points
**
** FIN_BondNextCoupon()             Get next coupon payment date for received bond
** FIN_GenerateInstrFlows()         Retrieves all possible future flows of an instr
** FIN_GenerateInstrFlowsEvtGen()   Retrieves all possible future flows of an 
**                                  instr for event generation.
** FIN_InsertPosVal()               Special function to insert pos val 
** FIN_InstrFlow()                  Retrieve information about a specific flow 
** FIN_PeriodUnitNbr()              Compute events number in a year (in output unit)
** FIN_TreatCumOption()             Cum option are composed of ex bond and ex option(s).
** FIN_ManageGeneratedOperation()   Manage the interactive action on the operations 
**                                  from the Event Generation interface
** FIN_ManageGeneratedFlow()        Manage the interactive action on the flows 
**                                  from the Event Generation interface
**
*************************************************************************/

/************************************************************************
**      Local functions
**
** FIN_CmpFlows()                   Order no filtered flows by date
** FIN_BondFlows()                  Retrieves all possible future flows of a bond
** FIN_CashAcctFlows()              Retrieves all possible future flows of an account
** FIN_CreateBondFlow()             Generate a flow for bond depending on redemp event
** FIN_CreateStockFlow()            Generate a flow for stock depending on income event
** FIN_CreateExchangeFlow()         Generate a flow for all exchange event (REF1138 - 980310 - DDV)
** FIN_DebtFlows()                  Retrieves all possible future flows of a debt
** FIN_FilterFlows()                Use input flow nature or flow subnature
** FIN_ForwardFlows()               Retrieves all possible future flows of a forward
** FIN_FundShareFlows()             Retrieves all possible future flows of a fund share
** FIN_FutureFlows()                Retrieves all possible future flows of a future
** FIN_GetIoRFlowSubNat()           Get flow sub-nature (by issue or redemp nature)
** FIN_MoneyMktFlows()              Retrieves all possible future flows of a money mkt
** FIN_OptionFlows()                Retrieves all possible future flows of an option 
** FIN_StockFlows()                 Retrieves all possible future flows of a stock
** FIN_SwapFlows()                  Retrieves all possible future flows of a swap
** FIN_OtherFlows()                 Retrieves all echange flows for intruments of nature Other
** FIN_UpdateGeneratedOperation()   Manage the interactive update action on the 
**                                  operations from the Event Generation interface.
** FIN_UpdateGeneratedFlow()        Manage the interactive update action on the 
**                                  flows from the Event Generation interface.
**
** FIN_FilterPropAttribFlow()       Filter function on linked Flow with sub nature 
**                                  "Proportional Attribution".
**
**
*************************************************************************/

/************************************************************************
**      Static definitions & data
*************************************************************************/
#define FREE_FLOW(p,n) {unsigned char F_i;\
		        if (p != NULL)\
		        {for (F_i=0; F_i<(unsigned char)n; F_i++)\
				FREE_DYNST(p[F_i], Flow);\
		           FREE(p);} n=0;}

/* REF3990 - SSO - 000406 : do not stop in case on non-critical error in flow generation
    WARNING: for a flow nature, all checks must be done before flow allocation in flowTab, or
    in case of error already allocated flows must be removed  */
/* REF3990 - SSO - 000413: rewrote RET_GENFLOWS + added RET_DBA_ERR_INVDATA */
#define FATAL_FLOWSERROR(ret) (ret != RET_FIN_ERR_INVDATA && ret != RET_DBA_ERR_NODATA && ret != RET_DBA_ERR_INVDATA)
#define RET_GENFLOWS(ret)   if (FATAL_FLOWSERROR(ret) == FALSE) \
				{return(RET_SUCCEED);}\
			    else \
				{return(ret);}


STATIC RET_CODE FIN_FilterFlows(FLOWNAT_ENUM, FLOWSUBNAT_ENUM, DBA_DYNFLD_STP*,	int, int*),
		FIN_OptMultiNatExoticFlows(DATETIME_T, DATETIME_T, DATETIME_T, 
				                DBA_DYNFLD_STP, EVTDATERULE_ENUM, DBA_DYNFLD_STP**, int*, DBA_HIER_HEAD_STP),
		FIN_OptExoticPayOffFlows(DATETIME_T, DATETIME_T, DATETIME_T, 
				                DBA_DYNFLD_STP, EVTDATERULE_ENUM, DBA_DYNFLD_STP**, int*, DBA_HIER_HEAD_STP);
STATIC int FIN_CmpFlows(void*, void*),
           FIN_CmpFlowDateCurr(void*, void*);


STATIC RET_CODE FIN_UpdateGeneratedFlow(DBA_HIER_HEAD_STP,
                                        DBA_DYNFLD_STP,
                                        ID_T,
                                        FLAG_T);

STATIC RET_CODE FIN_UpdateGeneratedOperation(DBA_HIER_HEAD_STP,
                                             DBA_DYNFLD_STP);

STATIC int FIN_FilterPropAttribFlow(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);

/************************************************************************
**
**  Function    :   FIN_CmpFlowDateCurr()
**
**  Description :   Flow array is sorted by date and currency
**
**  Arguments   :   ptr1   pointer on dynamic structure type ExtPos
**                  ptr2   pointer on dynamic structure type ExtPos
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**                  DVP510 - XDI - 970626
**		    REF4526 - SSO - 000407 : sort was not enough precise for flow merging!
**          REF5580 - RAK - 010216 
**          REF9428 - TEB - 040610
**
*************************************************************************/
STATIC int FIN_CmpFlowDateCurr(void *arg1, void *arg2)
{
    DBA_DYNFLD_STP *ptr1 = (DBA_DYNFLD_STP*) arg1; 
    DBA_DYNFLD_STP *ptr2 = (DBA_DYNFLD_STP*) arg2;
    long date=0;
	int  currCmp=0;	  /* REF4526 - SSO - 000407 */

    if (*ptr1 == NULL && *ptr2 == NULL)
        return(0);
    else if (*ptr1 == NULL)
        return(1);
    else if (*ptr2 == NULL)
	    return(-1);

	/* REF4526 - SSO - 000407 Flow_OptimalValDate replaced by Flow_BegPayDate   */
    /* REF5580 - RAK - 010216 - Now we try Flow_OptimalDate which is used to    */
    /*                          create the Value Date of the future operation ! */
	if ((date = CMP_DYNFLD((*ptr1), (*ptr2), Flow_OptimalDate,
	                       Flow_OptimalDate, DatetimeType)) == 0)
	{
	    if ((currCmp = CMP_DYNFLD((*ptr1), (*ptr2), Flow_AmtCurrId, Flow_AmtCurrId, IdType)) == 0)
	    {
			/* REF4526 - SSO - 000407 added Flow_NatEn criterium */
			if ((currCmp = CMP_DYNFLD((*ptr1), (*ptr2), Flow_NatEn, Flow_NatEn, EnumType)) == 0) /* REF8712 - TEB - 031028 */
			{
				/* REF9428 - TEB - 040610 Add sort on Flow_SubNatEn */
				return(CMP_DYNFLD((*ptr1), (*ptr2), Flow_SubNatEn, Flow_SubNatEn, EnumType));
			}
			else
			{
				return(currCmp);	
			}
	    }
	    else
	    {
		    return(currCmp);	
	    }
	}
	else
	    return(date);
}

/************************************************************************
**
**  Function          : FIN_SwapFlows()
**
**  Description       : Retrieves all possible future flows of a swap.
**                 
**  Arguments         : fromDateTime   reference date
**                      tillDateTime   end date
**                      inputInstrPtr  pointer on instrument struct or NULL
**                      flowTab        pointer on flows array which will be 
**                                     allocated and filled up
**                                     (initialised to NULL by FIN_GenerateInstrFlows())
**                      flowNbr        pointer on flows number which will be
**                                     filled up
**                                     (initialised to 0 by FIN_GenerateInstrFlows())
**
**  Warning           : Calling function is FIN_GenerateInstrFlows()
**
**  Return            : RET_SUCCEED 
**                      RET_MEM_ERR_ALLOC
**                      RET_GEN_ERR_INVARG
**
**  Creation 	      : DVP455 - RAK - 970505
**  Creation (bis)    : DVP510 - XDI - 970625
**  Modification      : BUG435 - GRD - 970714
**  Modification      : DVP561 - RAK - 970818
**  Modification      : REF1048 - RAK - 971205
**		            	REF2580 - SSO - 980727
**			            REF3990 - SSO - 000406 : modified ERROR MANAGEMENT !!! be careful if further modification 
**                      REF7599 - YST - 020628 - flow event number
**                      REF7782 - YST - 020904
**						PMSTA01659 - TGU - 070312
**
*************************************************************************/
RET_CODE FIN_SwapFlows( DATETIME_T        fromDateTime,  
		                DATETIME_T        tillDateTime,
			            DATETIME_T        valDateTime,
						FLAG_T			  noRefDateFlg,		/* PMSTA-9032 - RAK - 091216 */
		                DBA_DYNFLD_STP    instrPtr,
                        EVTDATERULE_ENUM  evtDateRule,      /* REF4075 - CSY - 9910127 */
                        GENINSTRFLOW_ENUM genInstrFlowEn,   /* REF8866 - YST - 030311 */
			            DBA_DYNFLD_STP    **flowTab,
			            int               *flowNbr,
			            DBA_HIER_HEAD_STP hierHead)
{ 
	DBA_DYNFLD_STP	*instrTab=NULLDYNSTPTR, *tmpFlowTab=NULLDYNSTPTR, *firstFlow; 
	int		        i=0, j=0, k=0, instrNbr=0, initFlowNbr=0, tmpFlowNbr=0, idx=0, lastPeriod = 0,
                    fstFlowIdx = 0, fstFlowNbr = 0, fstEvtNbr = 0,  
                    secFlowIdx = 0, secFlowNbr = 0, secEvtNbr = 0;
	FLAG_T		    freeInstrFlg=FALSE;
	RET_CODE	    ret;
	/* REF5580 int             (*icmp) (); */
 	/* REF1055 - DBA_DYNFLD_STP  domainPtr=NULLDYNST; */

	/* BOUM because of instrTab = NULL and instrNbr = 2 */
	if ((ret = FIN_SwapLegInstr(instrPtr, hierHead, valDateTime, 
		&instrTab, &instrNbr, &freeInstrFlg)) != RET_SUCCEED)
	{
		FREE(instrTab); /* memory leaks - 000410 - SSO */
		RET_GENFLOWS(ret); /* REF3990 - SSO - 000406 if not instr, no flow generated at all */
	}

	initFlowNbr = *flowNbr;
	idx = *flowNbr;
	/* firstFlow = &(*flowTab)[initFlowNbr]; */	/* REF1048 - Dangerous */

    /* generate flows for all new instruments */
	for (i=0; i<instrNbr; i++)
	{
        /* REF5580 - RAK - 010213 - Call FIN_BondFlows in case of bonds are "regular" bonds */
        /* DVP561 - RAK - 970818 */
	    /* ret = FIN_SwapLegFlows(fromDateTime, tillDateTime, valDateTime, instrTab[i],
				&tmpFlowTab, &tmpFlowNbr, hierHead);
        */
        /* REF5938 - RAK - 010508 */
        /* Create new function FIN_NewBondFlows() and call it for bond and swap legs */
        ret = FIN_NewBondFlows(fromDateTime, tillDateTime, valDateTime,
						 noRefDateFlg,	 /* PMSTA-9032 - RAK - 091216 */
                         instrTab[i], evtDateRule, AccrRule_None, /* REF11218 - TEB - 050627 */
						 &tmpFlowTab, &tmpFlowNbr, &lastPeriod, hierHead);

	    /* REF3990 - SSO - 000406 : this return is NOT modified because it's a critical error */
        /* REF5530 - RAK - 010110 : If there isn't flow for first leg, do the second leg */
        /*                          (except in case of "important" error)                */
		/*
		 * REF9971 - CHU - 040303 : Consider that RET_FIN_ERR_SCE_ZEROFLOW is not an "important" error
		 * else, second leg of the swap may not be processed if treatment is stopped here
		 * (new error code introduced with REF7265 and returned by function SCE_GenrCflows())
		 */
	    if (ret != RET_SUCCEED &&
			ret != RET_FIN_ERR_SCE_FCT_FAIL &&
			ret != RET_FIN_ERR_SCE_ZEROFLOW)
	    {
		    FREE(instrTab); /* memory leaks - 000410 - SSO */
		    return(ret); /* REF2569 - AKO - 980818 */ 
	    }

        /* REF5958 - 010418 - DDV - Nothing to alloc if no flows */
        if (tmpFlowNbr > 0)
        {
            /* REF7599 - YST - 020628/020904 - get infos for event number in first and second swap leg */
            if (i == 0)
            {
                fstFlowIdx = (*flowNbr);
                fstFlowNbr = (*flowNbr) + tmpFlowNbr;
                fstEvtNbr  = lastPeriod;
            }
            else 
            {   
                secFlowIdx = (*flowNbr);
                secFlowNbr = (*flowNbr) + tmpFlowNbr;
                secEvtNbr  = lastPeriod;
            }

	        (*flowNbr) += tmpFlowNbr;
	        if (((*flowTab) = (DBA_DYNFLD_STP*) REALLOC((*flowTab), 
			      (*flowNbr)*sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR)
	        {
		        FREE(instrTab); /* memory leaks - 000410 - SSO */
		        DBA_FreeDynStTab(tmpFlowTab, tmpFlowNbr, Flow);
		        MSG_RETURN(RET_MEM_ERR_ALLOC);
	        }

	        for (j=0; j<tmpFlowNbr; j++)
	        {
		        COPY_DYNFLD(tmpFlowTab[j], Flow, Flow_InstrId, 
			            instrPtr, A_Instr, A_Instr_Id);	
				if ((static_cast<InstrMktConvMethodEn>GET_ENUM(instrPtr, A_Instr_MktConvMethodEn) == InstrMktConvMethodEn::None && static_cast<InstrMktConvMethodEn>GET_ENUM(instrPtr, A_Instr_PaidMktConvMethodEn) == InstrMktConvMethodEn::None))
				{
					SET_PRICE(tmpFlowTab[j], Flow_AmtUnit,
						CAST_PRICE(GET_PRICE(tmpFlowTab[j], Flow_AmtUnit) *   /* REF3288 - SSO - 990205 */
							GET_NUMBER(instrTab[i], A_Instr_CompoQuantity)));
				}
				else
				{
					SET_PRICE(tmpFlowTab[j], Flow_AmtUnit,
						GET_PRICE(tmpFlowTab[j], Flow_AmtUnit) *
						GET_NUMBER(instrTab[i], A_Instr_CompoQuantity));
				}

		        (*flowTab)[idx+j] = tmpFlowTab[j];
	        }

	        idx += tmpFlowNbr;
        }

        /* REF5580 - RAK - 010213 */
        tmpFlowNbr = 0;
        FREE(tmpFlowTab);
	}

	/* DVP510 - XDI - Tri et merge des Flow */
	if (initFlowNbr < idx)				/* REF1048 - Sort added part only */
	{
        /* REF7599 - YST - 020904 - ajust event number for leg with less flows */
        if (fstEvtNbr > secEvtNbr)
        {
            for (j=secFlowIdx; j<secFlowNbr; j++)
                SET_INT((*flowTab)[j], Flow_EvtNbr,  /* REF8844 - LJE - 030327 */
                            (GET_INT((*flowTab)[j], Flow_EvtNbr) + fstEvtNbr));
        }
        else
        {
            fstEvtNbr = secEvtNbr;
            for (j=fstFlowIdx; j<fstFlowNbr; j++)
                SET_INT((*flowTab)[j], Flow_EvtNbr, 
                            (GET_INT((*flowTab)[j], Flow_EvtNbr) + secEvtNbr)); /* REF8844 - LJE - 030327 */
        }

	    firstFlow = &(*flowTab)[initFlowNbr];

        /* REF5580 - RAK - 010216 - Use TLS_Sort() */
        /*    icmp = FIN_CmpFlowDateCurr;
            qsort(firstFlow, idx-initFlowNbr, sizeof(DBA_DYNFLD_STP), 
	          (int(*)(const void*, const void*))icmp); */

        TLS_Sort((char *) firstFlow, idx-initFlowNbr, sizeof(DBA_DYNFLD_STP),  
			     FIN_CmpFlowDateCurr, (PTR**) NULL, SortRtnTp_None);

	    for (i=initFlowNbr; i<idx-1; i++)
	    {    
		    /* REF1485 - Verify flow nature */
            /* REF5580 - Verify flow sub-nature and use Flow_OptimalDate      */
            /* which is used to create the Value Date of the future operation */
	        if (CMP_DYNFLD((*flowTab)[i], (*flowTab)[i+1], Flow_OptimalDate, Flow_OptimalDate, DatetimeType) == 0 &&
                CMP_DYNFLD((*flowTab)[i], (*flowTab)[i+1], Flow_AmtCurrId, Flow_AmtCurrId, IdType) == 0 &&		/* REF1485 */
                GET_ENUM((*flowTab)[i], Flow_NatEn) == GET_ENUM((*flowTab)[i+1], Flow_NatEn) 
                /* REF5980 - RAK - 010704 && GET_ENUM((*flowTab)[i], Flow_SubNatEn) == GET_ENUM((*flowTab)[i+1], Flow_SubNatEn)*/)
            {
                /* REF5980 - RAK - 010704 - For event generation, merge the two incomes even if sub-nature are different */
                /* REF6049 - RAK - 010705 */
                /* 2 seperates lines are created only for the flows generated */
                /* from a composed swap but not for a standard swap.          */
                FLAG_T          mergeFlowFlg=TRUE;

                /* REF8866 - YST - 030310 - merge for EG and InstrFlow, but not for Journal */
                if (genInstrFlowEn == GenInstrFlow_Journal &&
                    (SUBNAT_ENUM) GET_ENUM(instrPtr, A_Instr_SubNatEn) != SubNat_FixFloatStdSwap &&
	                (SUBNAT_ENUM) GET_ENUM(instrPtr, A_Instr_SubNatEn) != SubNat_FixFixStdSwap &&
	                (SUBNAT_ENUM) GET_ENUM(instrPtr, A_Instr_SubNatEn) != SubNat_FltFltStdSwap &&
                    (SUBNAT_ENUM) GET_ENUM(instrPtr, A_Instr_SubNatEn) != SubNat_FixFltSwapHedgFix && /* REF7782 - YST - 020904 */
                    GET_ENUM((*flowTab)[i], Flow_SubNatEn) != GET_ENUM((*flowTab)[i+1], Flow_SubNatEn))
                {    
                    mergeFlowFlg = FALSE;                    
                }

                if (mergeFlowFlg == TRUE)
                { 
                    FIELD_IDX_T fld2CopyNumber[]={Flow_DiscountFactor, 
                                                  Flow_CtdConvFact,
                                                  Flow_PaidAmtUnit,
                                                  Flow_ReceivedAmtUnit,
                                                  Flow_CtdConvFact,
                                                  Flow_DiscFactReceivedInstr,
                                                  Flow_DiscFactPaidInstr,
                                                  Flow_DiscFactReceivedFloat,
                                                  Flow_DiscFactPaidFloat,
                                                  Null_Dynfld};

                    FIELD_IDX_T fld2CopyPercent[]={Flow_AnnualReceivedRate, 
                                                   Flow_AnnualPaidRate,
                                                   Null_Dynfld};

                    /* Copy all fields from type NumberType */
                    for (k=0; fld2CopyNumber[k] != Null_Dynfld;k++)
					{
					    if(( IS_NULLFLD((*flowTab)[i+1], fld2CopyNumber[k]) == FALSE) &&
						    (IS_NULLFLD((*flowTab)[i], fld2CopyNumber[k]) == TRUE))
					    {
						    SET_NUMBER((*flowTab)[i], fld2CopyNumber[k],
                                        GET_NUMBER((*flowTab)[i+1], fld2CopyNumber[k]));
					    }
					}

                    /* Copy all fields from type PercentType */
                    for (k=0; fld2CopyPercent[k] != Null_Dynfld;k++)
					{
					    if(( IS_NULLFLD((*flowTab)[i+1], fld2CopyPercent[k]) == FALSE) &&
						    (IS_NULLFLD((*flowTab)[i], fld2CopyPercent[k]) == TRUE))
					{
						    SET_PERCENT((*flowTab)[i], fld2CopyPercent[k],
                                        GET_PERCENT((*flowTab)[i+1], fld2CopyPercent[k]));
					}
					}
					if ((static_cast<InstrMktConvMethodEn>GET_ENUM(instrPtr, A_Instr_MktConvMethodEn) == InstrMktConvMethodEn::None && static_cast<InstrMktConvMethodEn>GET_ENUM(instrPtr, A_Instr_PaidMktConvMethodEn) == InstrMktConvMethodEn::None))
					{
						SET_PRICE((*flowTab)[i], Flow_AmtUnit,
							CAST_PRICE(GET_PRICE((*flowTab)[i], Flow_AmtUnit) + /* REF3288 - SSO - 990205 */
								GET_PRICE((*flowTab)[i + 1], Flow_AmtUnit)));
					}
					else
					{
						SET_PRICE((*flowTab)[i], Flow_AmtUnit,
							(GET_PRICE((*flowTab)[i], Flow_AmtUnit) + /* REF3288 - SSO - 990205 */
								GET_PRICE((*flowTab)[i + 1], Flow_AmtUnit)));
					}

                    /* REF7599 - YST - 020628 - set right flow event number */ /* REF8844 - LJE - 030327 */
                    if (GET_INT((*flowTab)[i], Flow_EvtNbr) > GET_INT((*flowTab)[i+1], Flow_EvtNbr))
                        SET_INT((*flowTab)[i], Flow_EvtNbr, GET_INT((*flowTab)[i+1], Flow_EvtNbr));
                    fstFlowNbr = 0;
                
                    FREE_DYNST((*flowTab)[i+1], Flow);      /* DDV - 980619 */
		            /* REF1048 - Copy next records and free last */
                    for (j=i+1; j<idx-1; j++)
                    {
                       (*flowTab)[j] = (*flowTab)[j+1];

                        /* REF7599 - YST - 020904 - reajust flow event number */ /* REF8844 - LJE - 030327 */
                       if (GET_INT((*flowTab)[j], Flow_EvtNbr) > fstEvtNbr)
                           SET_INT((*flowTab)[j], Flow_EvtNbr, (++fstFlowNbr + fstEvtNbr));
                    }
                    /* FREE_DYNST((*flowTab)[idx-1], Flow); - DDV - 980619 */

		            idx--;
		            (*flowNbr)--;		/* REF1048 - Modify returned record number */
	            }
            }
	    }
	}

	FREE(instrTab); /* memory leaks - 000410 - SSO */
	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function          : FIN_ForexSwapFlows()
**
**  Description       : Retrieves all possible future flows of a forex swap.
**                 
**  Arguments         : fromDateTime   reference date
**                      tillDateTime   end date
**                      inputInstrPtr  pointer on instrument struct or NULL
**                      flowTab        pointer on flows array which will be 
**                                     allocated and filled up
**                                     (initialised to NULL by FIN_GenerateInstrFlows())
**                      flowNbr        pointer on flows number which will be
**                                     filled up
**                                     (initialised to 0 by FIN_GenerateInstrFlows())
**
**  Warning           : Calling function is FIN_GenerateInstrFlows()
**
**  Return            : RET_SUCCEED or error code
**
**  Creation 	      : REF053 - RAK - 980416
**
**  Modification      : REF2569 - AKO - 980818
**
*************************************************************************/
RET_CODE FIN_ForexSwapFlows(DATETIME_T        fromDateTime,  
		                   DATETIME_T        tillDateTime,
			           DATETIME_T        valDateTime,
		                   DBA_DYNFLD_STP    instrPtr,
			           DBA_DYNFLD_STP    **flowTab,
			           int               *flowNbr,
			           DBA_HIER_HEAD_STP hierHead)
{ 
	DBA_DYNFLD_STP	flow=NULLDYNST;
	DATETIME_T	date;

	*flowNbr = 1;

	if (((*flowTab) = (DBA_DYNFLD_STP*) 
                          CALLOC(*flowNbr, sizeof(DBA_DYNFLD_STP))) == (DBA_DYNFLD_STP*)NULL)
	{
		*flowNbr = 0;
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	if (((*flowTab)[0] = ALLOC_DYNST(Flow)) == NULLDYNST)
	{
		*flowNbr = 0;         /* REF2569 - AKO - 980818 */  /* correct */ 
		FREE((*flowTab));
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	flow = (*flowTab)[0];

	SET_ID(flow,            Flow_InstrId,        GET_ID(instrPtr, A_Instr_Id)); 
	SET_NULL_CODE(flow,     Flow_EvtCd);         
	SET_INT(flow,           Flow_EvtNbr,         1);         /* REF8844 - LJE - 030327 */
	SET_ENUM(flow,          Flow_NatEn,          FlowNat_Redm);
	SET_ENUM(flow,          Flow_SubNatEn,       FlowSubNat_FinalRedm);

	SET_FLAG(flow,          Flow_ConfirmedFlg,   TRUE);
	SET_PERIOD(flow,        Flow_SettlDays,      0);

	date.date = GET_DATE(instrPtr, A_Instr_EndDate);
	date.time = 0;

	SET_DATETIME(flow, Flow_OptimalValDate, date);
	SET_DATETIME(flow, Flow_BegPayDate,     date);
	SET_DATETIME(flow, Flow_EndPayDate,     date);
	SET_DATETIME(flow, Flow_OptimalDate,    date);

	SET_NULL_PERCENT(flow,  Flow_IoRPrct);
	SET_PRICE(flow,        Flow_Quote,       0.0);
	SET_NUMBER(flow,        Flow_RefQty,      1.0);
	SET_FLAG(flow,          Flow_ReplaceFlg,  TRUE);
	SET_PRICE(flow,        Flow_AmtUnit,     0.0);
	SET_ID(flow,            Flow_AmtCurrId,   GET_ID(instrPtr, A_Instr_RefCurrId));
	SET_NULL_ID(flow,       Flow_NewInstrId);
	SET_NULL_NUMBER(flow,   Flow_QtyUnit);
	SET_NULL_ENUM(flow,     Flow_OptClassEn);
	SET_NULL_ENUM(flow,     Flow_OptStyleEn);
	SET_PERCENT(flow,       Flow_Proba,       100.0);

	SET_NULL_TINYINT(flow,   Flow_Freq);
	SET_NULL_ENUM(flow,      Flow_FreqUnitEn);
	SET_NULL_DATE(flow,      Flow_ExDate);
	SET_NULL_EXCHANGE(flow,  Flow_FxdExchRate);
	SET_NULL_NUMBER(flow,    Flow_CtdConvFact);
	SET_NULL_NUMBER(flow,    Flow_CtdConvRatio);
	SET_NULL_ID(flow,        Flow_CtdInstrId);
	SET_FLAG(flow,           Flow_PhysicalFlg, FALSE);
	SET_NULL_TINYINT(flow,   Flow_Priority);
	SET_FLAG(flow,           Flow_EffectiveFlg, FALSE);

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function          : FIN_SwapLegFlows()
**
**  Description       : Retrieves all possible future flows of a swap leg.
**                 
**  Arguments         : fromDateTime   reference date
**                      tillDateTime   end date
**                      inputInstrPtr  pointer on instrument struct or NULL
**                      flowTab        pointer on flows array which will be 
**                                     allocated and filled up
**                                     (initialised to NULL by FIN_GenerateInstrFlows())
**                      flowNbr        pointer on flows number which will be
**                                     filled up
**                                     (initialised to 0 by FIN_GenerateInstrFlows())
**
**  Warning           : Calling function is FIN_SwapFlows()
**
**  Return            : RET_SUCCEED 
**                      RET_MEM_ERR_ALLOC
**                      RET_GEN_ERR_INVARG
**
**  Creation	      : DVP561 - RAK - 970818
**  Modification      : REF1048 - RAK - 971208
**                    : REF7599 - YST - 020627/020904
**
*************************************************************************/
RET_CODE FIN_SwapLegFlows(DATETIME_T       fromDateTime,  
		                 DATETIME_T        tillDateTime,
			             DATETIME_T        valDateTime,
		                 DBA_DYNFLD_STP    instrPtr,
			             DBA_DYNFLD_STP    **flowTab,
			             int               *flowNbr,
                         int               *lastPeriod, /* REF7599 - YST - 020904 */
			             DBA_HIER_HEAD_STP hierHead)
{
	int		i=0, currentPeriod=0;
	RET_CODE 	ret;

	/* Allocate flowTab (size flowNbr) and init fields :                                  */
	/* Flow_Quote (coupon), Flow_AmtUnit  (coupon/100.0)                                  */
	/* Flow_BegPayDate Flow_EndPayDate Flow_OptimalDate Flow_OptimalValDate (coupon date) */
    /* REF7599 - YST - 020627/020904 - add new argument */
	ret = SCE_GenrCflw(GET_ID(instrPtr, A_Instr_Id), instrPtr, hierHead,
			        fromDateTime, tillDateTime, valDateTime,
			        flowTab, flowNbr, &currentPeriod, lastPeriod);

	if (ret == RET_SUCCEED)
	{
	    for (i=0; i<*flowNbr; i++)
	    {
		/* REF1048 - Update Flow_AmtCurrId and Flow_EffectiveFlg */
		SET_ID((*flowTab)[i], Flow_InstrId,   GET_ID(instrPtr, A_Instr_Id));
		SET_ID((*flowTab)[i], Flow_AmtCurrId, GET_ID(instrPtr, A_Instr_RefCurrId));
		SET_INT((*flowTab)[i],Flow_EvtNbr,    currentPeriod+i); /* REF7599 - YST - 020627 */  /* REF8844 - LJE - 030327 */
		
        /* REF1485 - Updated in SCE_GenrCflw() (income or redemption) */
		/* SET_ENUM((*flowTab)[i],     Flow_NatEn,        (ENUM_T) FlowNat_Inc); */
        /* SET_ENUM((*flowTab)[i],     Flow_SubNatEn, */
		
        SET_FLAG((*flowTab)[i],     Flow_ConfirmedFlg, TRUE);
		SET_PERIOD((*flowTab)[i],   Flow_SettlDays,    0);
		SET_FLAG((*flowTab)[i],     Flow_PhysicalFlg,  FALSE);
		SET_FLAG((*flowTab)[i],     Flow_EffectiveFlg, FALSE);	
		SET_FLAG((*flowTab)[i],     Flow_ReplaceFlg,   FALSE);
		SET_PERCENT((*flowTab)[i],  Flow_Proba,        100.0);

		/* ?? */
		/* SET_CODE((*flowTab)[i],     Flow_EvtCd, */
		/* SET_NUMBER((*flowTab)[i],   Flow_RefQty, */
		
		/* SET_TINYINT((*flowTab)[i],  Flow_Freq, */
		/* SET_ENUM((*flowTab)[i],     Flow_FreqUnitEn, */
		/* SET_NUMBER((*flowTab)[i],   Flow_Yield, */

		SET_NULL_EXCHANGE((*flowTab)[i], Flow_FxdExchRate);
		SET_NULL_PERIOD((*flowTab)[i],   Flow_IoRPrct);
		SET_NULL_ID((*flowTab)[i],       Flow_NewInstrId);
		SET_NULL_NUMBER((*flowTab)[i],   Flow_QtyUnit);
		SET_NULL_ENUM((*flowTab)[i],     Flow_OptClassEn);
		SET_NULL_ENUM((*flowTab)[i],     Flow_OptStyleEn);
		SET_NULL_DATE((*flowTab)[i],     Flow_ExDate);
		SET_NULL_NUMBER((*flowTab)[i],   Flow_CtdConvFact);
		SET_NULL_NUMBER((*flowTab)[i],   Flow_CtdConvRatio); 
		SET_NULL_ID((*flowTab)[i],       Flow_CtdInstrId);
		SET_NULL_TINYINT((*flowTab)[i],  Flow_Priority);
	    }
	}

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_GetIoRFlowSubNat()
**
**  Description :   Get flow sub-nature depending on issue or redemption nature
**                 
**  Arguments   :   issue or redemption event nature
**
**  Return      :   flow subnature
**  Modif.      :   REF6007 - AKO - 020305 : add new iss/redm event nature
**
*************************************************************************/
FLOWSUBNAT_ENUM FIN_GetIoRFlowSubNat(ISSREDMNAT_ENUM evtNatEn)
{
	FLOWSUBNAT_ENUM flowSubNat = FlowSubNat_Any;

	switch (evtNatEn)
	{
	case IssRedmNat_TotalIssue :
		flowSubNat = FlowSubNat_FullyPaidIss;
		break;
	case IssRedmNat_PartialIssue :
		flowSubNat = FlowSubNat_PartialPaidIss;
		break;
	case IssRedmNat_FinalRedm :
		flowSubNat = FlowSubNat_FinalRedm;
		break;
	case IssRedmNat_CallRedm :
		flowSubNat = FlowSubNat_CallRedm;
		break;
	case IssRedmNat_PutRedm :
		flowSubNat = FlowSubNat_PutRedm;
		break;
	case IssRedmNat_Amort :
		flowSubNat = FlowSubNat_SinkingRedm;
		break;
	case IssRedmNat_CapRed :
		flowSubNat = FlowSubNat_CapReduc;
		break;
	case IssRedmNat_DebtProvi :
		flowSubNat =  FlowSubNat_ProviPlan;
		break;
	case IssRedmNat_DebtAmort :
		flowSubNat = FlowSubNat_DebtAmort;
		break;
    case IssRedmNat_CapitalToPay:   /* REF6007 - AKO - 020305 */
            flowSubNat =  FlowSubNat_RedemCapitalToPay;
        break;
    case IssRedmNat_CapitalToRec:
         flowSubNat =  FlowSubNat_RedemCapitalToRec; 
         break;
	case IssRedmNat_CapitalReturn: /*PMSTA-32106 -NRAO 180904*/
		flowSubNat = FlowSubNat_CapitalReturn;
		break;
	}

	return(flowSubNat);
}

/************************************************************************
**
**  Function    :   FIN_BondNextCoupon()
**
**  Description :   Get next coupon payment date for received bond
**                  Update nextDate and fill income structure
**                 
**  Arguments   :   bondPtr bond instrument structure pointer
**                  refDateTime  reference date 
**                  income       pointer on income structure (to fill)
**                  nextDate     pointer on next coupon payment date (to fill)
**
**  Return      :   RET_SUCCEED or error code
**
**  Modif.	:   BUG400 - RAK - 970613 
**
*************************************************************************/
RET_CODE FIN_BondNextCoupon(DBA_DYNFLD_STP bondPtr, 
	                        DATETIME_T     refDateTime, 
	                        DBA_DYNFLD_STP income, 
	                        DATETIME_T     *nextDate)
{
	DATE_T     begDate;
	DATETIME_T firstCoupDate;
	DAY_T      svBegD;
	char       endMFlg;
	double     freq;
	RET_CODE   ret;

	nextDate->date = 0;
	nextDate->time = 0;

	if (income == NULLDYNST)
	{
		ret = RET_GEN_ERR_INVARG;
	    	MSG_SendMesg(ret, 1, FILEINFO, 
			     "FIN_BondNextCoupon", "income pointer");
   		return(ret); 
	}

	if ((ret = DBA_GetIncEvt(bondPtr, refDateTime, income)) != RET_SUCCEED)
		return(ret);

	FIN_PeriodUnitNbr((FREQUNIT_ENUM) GET_ENUM(income, A_IncEvt_PayFreqUnitEn), 
	                  GET_TINYINT(income, A_IncEvt_PayFreq), FreqUnit_Month, &freq);

	/* Income event must finish after reference date */
	if (GET_DATE(income, A_IncEvt_LastPayDate) < refDateTime.date)
	{
		ret = RET_FIN_ERR_INVDATA;
		MSG_SendMesg(ret, 1, FILEINFO, "FIN_BondNextCoupon", 
			     GET_CODE(bondPtr, A_Instr_Cd), "income");
		return(ret);
	}

	firstCoupDate = GET_DATETIME(income, A_IncEvt_FirstCoupDate);

	begDate = GET_DATE(income, A_IncEvt_BeginDate);
	endMFlg = (char) DATE_IsLastInMonth(begDate);
	DATE_Get(begDate, (YEAR_T*)NULL, (MONTH_T*)NULL, &svBegD);

	while (begDate < refDateTime.date)
	{
		/* First coupon date can be 0 */
		if (firstCoupDate.date > begDate)
		{
			begDate = firstCoupDate.date;
			/* BUG400 - RAK - 970613 */
			endMFlg = (char) DATE_IsLastInMonth(begDate);
			DATE_Get(begDate, (YEAR_T*)NULL, (MONTH_T*)NULL, &svBegD);
		}
		else 
		{
		    if (freq == 0.)  /* No repetitive event */
			begDate = GET_DATE(income, A_IncEvt_LastPayDate);
		    else
		    {
			begDate = DATE_Move(begDate, (int)freq, Month);
			/* Short month can corrupt day number */
			DATE_VerifyEndMonth(&begDate, svBegD, endMFlg);
		    }
		}

		/* Force last payment date */
		if (IS_NULLFLD(income, A_IncEvt_LastPayDate) == FALSE &&
		    GET_DATE(income, A_IncEvt_LastPayDate) < begDate)
		{
			begDate = GET_DATE(income, A_IncEvt_LastPayDate);
		}
	}

	nextDate->date = begDate;

	return(RET_SUCCEED);
}

/************************************************************************
*   Function             : FIN_InsertPosVal()
*
*   Description          : Delete all PosVal existing in database with same date
*                          and portfolio, and insert new one.
*
*   Arguments            : ptfId     : portfolio Id.
*                          hierHead  : hierarchy with new ExtPos.
*                          date      : date for data insert.
*                          extPosNat : nature of ExtPos to insert (optional).
*
*   Return               : TRUE if ok
*                          FALSE if problem
*
*   Creation Date        : 28 march 96, XDI, DVP018
*   Last Modification    : 23.08.96 - PEC - Ref.: DVP179 (DBA_Insert() -> DBA_Insert2)
**  Modif.		 : REF2313 - RAK - 980910
**  Modif.		 :   REF2580 - SSO - 980727
*
*************************************************************************/
int FIN_InsertPosVal(ID_T           ptfId, 
                     PTR            hierHead,
                     DATETIME_T     date,
                     EXTPOSNAT_ENUM extPosNat)               
{

	DBA_DYNFLD_STP  admArgSt=NULLDYNST;
	int             posNbr, i;
	DBA_HIER_HEAD_STP posHierHead = (DBA_HIER_HEAD_STP) hierHead;
	DBA_DYNFLD_STP  *extractPos=(DBA_DYNFLD_STP*)NULL, posValPtr=NULLDYNST, ptfPtr=NULLDYNST;
	AMOUNT_T        tmpVal;
	ID_T            refCurrId, ptfCurrId;
	char            copyRecFlg;
	RET_CODE        ret;

	/* Delete all PosVal in database with same date and portfolio */
	if ((admArgSt = ALLOC_DYNST(Adm_Arg)) == NULLDYNST)
		return (RET_MEM_ERR_ALLOC);

	SET_ID(admArgSt,       Adm_Arg_Id,        ptfId);
	SET_DATETIME(admArgSt, Adm_Arg_Date,  date);

	if (DBA_Delete2(PVal, UNUSED, Adm_Arg, admArgSt, UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
	{
		FREE_DYNST(admArgSt, Adm_Arg);
		return(RET_GEN_INFO_NODATA);
	}

	FREE_DYNST(admArgSt, Adm_Arg);

	/* Insert new Pos Val in database */
	copyRecFlg = FALSE;
	if ((ret = DBA_ExtractHierEltRec(posHierHead, ExtPos, 
				         copyRecFlg, NULLFCT, NULLFCT, 
				         &posNbr, &extractPos)) != RET_SUCCEED)
		return(ret);

	if (posNbr == 0)
		return(RET_SUCCEED);

	for (i=0; i<posNbr; i++)
	{
		/* DVP172 */
		posValPtr = NULLDYNST;
		if ((GET_ID(extractPos[i], ExtPos_PtfId) == ptfId) &&
		    (DATETIME_CMP(GET_DATETIME(extractPos[i], ExtPos_ExtPosDate), date) == 0) &&
		    (GET_FLAG(extractPos[i], ExtPos_AcctFlg) == TRUE) &&
		    ((extPosNat != 0) && (GET_ENUM(extractPos[i], ExtPos_NatEn) == extPosNat)) &&
		    (GET_EXTENSION_PTR(extractPos[i], ExtPos_PosVal_Ext) != NULL) &&
		    ((posValPtr=*(GET_EXTENSION_PTR(extractPos[i], 
		                  ExtPos_PosVal_Ext)))!=NULLDYNST) &&
		    (GET_NUMBER(extractPos[i], ExtPos_Qty)!=0))
		{
           		/* If necessary, convert net value, clean value and */
           		/* accrued interest in instrument currency.         */
			/* DVP172 */
			ptfPtr = NULLDYNST;
			if(GET_EXTENSION_PTR(extractPos[i], ExtPos_A_Ptf_Ext) != NULL)
			    ptfPtr=*(GET_EXTENSION_PTR(extractPos[i], ExtPos_A_Ptf_Ext));

           	refCurrId = GET_ID(extractPos[i], ExtPos_RefCurrId);
           	ptfCurrId = GET_ID(ptfPtr, A_Ptf_CurrId);

           	if (refCurrId != ptfCurrId)
           	{
				/* REF2313 - Use new argumet structure */
    			FIN_EXCHARG_ST    exchArgSt;
    			memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));
				/*DBA_SetConnectNoToExchArg(&exchArgSt, DBA_GetConnectNoFromHier(posHierHead));*/ /* REF2580 - SSO - 980727 */
				DBA_InitConnectNoToExchArg(&exchArgSt, posHierHead); /* REF4213 - SSO - 991221 */

				exchArgSt.srcAmt = GET_AMOUNT(posValPtr, PosVal_RefMktValAmt);
                FIN_ExchAmt(date, refCurrId, ptfCurrId, 
					        0, NULLDYNST, extractPos[i], &exchArgSt,
                            (EXCHANGE_T*)NULL, &tmpVal, (EXCHANGE_T*)NULL);	/* PMSTA01649 - TGU - 070405 */
                SET_AMOUNT(posValPtr, PosVal_RefMktValAmt, tmpVal);

				exchArgSt.srcAmt = GET_AMOUNT(posValPtr, PosVal_RefAccrInterAmt);
                FIN_ExchAmt(date, refCurrId, ptfCurrId, 
				            0, NULLDYNST, extractPos[i], &exchArgSt,
                            (EXCHANGE_T*)NULL, &tmpVal, (EXCHANGE_T*)NULL);	/* PMSTA01649 - TGU - 070405 */
                SET_AMOUNT(posValPtr, PosVal_RefAccrInterAmt, tmpVal);

				exchArgSt.srcAmt = GET_AMOUNT(posValPtr, PosVal_RefNetAmt);
                FIN_ExchAmt(date, refCurrId, ptfCurrId, 
					        0, NULLDYNST, extractPos[i], &exchArgSt,
                            (EXCHANGE_T*)NULL, &tmpVal, (EXCHANGE_T*)NULL);	/* PMSTA01649 - TGU - 070405 */
                SET_AMOUNT(posValPtr, PosVal_RefNetAmt, tmpVal);
           	}

			/* insert PosVal into database */
			if (DBA_Insert2(PVal, UNUSED, PosVal, 
			    posValPtr, DBA_INS_ID, UNUSED, UNUSED) != RET_SUCCEED)
			{
		        FREE(extractPos);  /* Only array pointer */
				return(RET_DBA_ERR_DBPROBLEM);
			}
		}
	}

	FREE(extractPos);  /* Only array pointer */
	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_InstrFlow()
**
**  Description :   Retrieve information about a specific flow for an 
**                  instrument at a given date. 
**                 
**  Arguments   :   instrId       instrument identifier
**                  inputInstrPtr instrument structure pointer or NULLDYNST
**                  refDate       date from which the counting flows is required
**                  valDate       retrieved events must be valid at this date
**                  flowPosEn     First, Previous, Current, Next, Final
**                  flowCnt       Nbr used with flowPosEn to numerate the flows
**                                eg : one after the next (next +1)
**                  flowNatEn     whether one seeks
**                  flowSubNatEn  whether one seeks
**                  typeid        type Identifier
**                  sumflag       sum of quote required or not
**
**  Return      :   RET_SUCCEED or error code
**
**  Modif	:   BUG161  - RAK - 961004
**                  REF3217 - GRD - 990118. Get the debt flag from the domain.
**              REF4075 - CSY - 991109 new parameter  evtDateRuleEn enum.
**              REF7777 - YST - 020904 
**              REF11218 - TEB - 050627
**
*************************************************************************/
RET_CODE FIN_InstrFlow(ID_T            instrId,
                       DBA_DYNFLD_STP  inputInstrPtr,
                        DATETIME_T      refDate, 
                        DATETIME_T      valDate,
						FLAG_T			noRefDateFlg,	 /* PMSTA-9032 - RAK - 091216 */
                        TIMEDIM_ENUM    timeDimEn,
                        int             flowCnt,
                        FLOWNAT_ENUM    flowNatEn,
                        FLOWSUBNAT_ENUM flowSubNatEn,
                        EVTDATERULE_ENUM  evtDateRuleEn, /* REF4075 - CSY - 991109 */ 
                        DBA_DYNFLD_STP  outputFlow, 
                        DBA_HIER_HEAD_STP hierHead,
						ID_T              typeId,
						bool			  sumflg_f)
{
	DBA_DYNFLD_STP  instrPtr=NULLDYNST, 
		            flowArg=NULLDYNST, *flowTab=(DBA_DYNFLD_STP*)NULL;
	/*DBA_DYNFLD_STP  interCondPtr=NULLDYNST, *tmpInterCondTab=NULLDYNSTPTR;*/
	FLAG_T          allocOk = FALSE, found = FALSE;
	int             i = 0, filterFlowNbr = 0, flowNbr = 0, refDatePos = 0, pos = 0, def_none_type_index = -1;
	/*int             tmpInterCondNbr=0;*/
	RET_CODE        ret = RET_SUCCEED;
	DATETIME_T      begDate, endDate;
    ENUMMASK_T          mask = (ENUMMASK_T) 0;
 	DBA_DYNFLD_STP  domainPtr=NULLDYNST;
	FLAG_T          getDebtFlg = FALSE;
	/*FLAG_T          freeRecFlg=FALSE;*/
	PRICE_T quote_n = 0;
	FLAG_T			Firstrefdate_f = FALSE;
	DATETIME_T     Firstrefdate;
	Firstrefdate.date = 0;
	Firstrefdate.time = 0;

	if (outputFlow == NULLDYNST)
	{
		MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "FIN_InstrFlow", "output struct");
		return(RET_GEN_ERR_INVARG);
 	}

	if ((flowArg = ALLOC_DYNST(Flow_Arg)) == NULLDYNST)
		MSG_RETURN(RET_MEM_ERR_ALLOC);

	SET_ID(flowArg,       Flow_Arg_InstrId,  instrId);
	SET_DATE(flowArg,     Flow_Arg_RefDate,  refDate.date);      /* PMSTA-25331 - TEB - 20171018 */
	SET_DATE(flowArg,     Flow_Arg_ValDate,  valDate.date);      /* PMSTA-25331 - TEB - 20171018 */
	SET_ENUM(flowArg,     Flow_Arg_Pos,      timeDimEn);
	SET_INT(flowArg,      Flow_Arg_Cnt,      flowCnt);
	SET_ENUM(flowArg,     Flow_Arg_NatEn,    flowNatEn);
	SET_ENUM(flowArg,     Flow_Arg_SubNatEn, flowSubNatEn);
    SET_ENUM(flowArg,     Flow_Arg_EvtDateRule, evtDateRuleEn); /* REF7777 - YST - 020904 */

	ret = DBA_GetMemory(OptiFct, UNUSED, Flow_Arg, flowArg,
		            Flow, outputFlow, (DBA_DYNFLD_STP *) NULL, 
			        Opti_Local);

	/* BEGIN BUG030 960514 RAK */
	if (ret == RET_SUCCEED || ret == RET_DBA_INFO_NODATA)
	{
		FREE_DYNST(flowArg, Flow_Arg);
		return(ret);
	}
	/* END BUG030 960514 RAK */

        /* Get position instrument */
	if (inputInstrPtr == NULLDYNST)
    {
        /* REF3913 - 990819 - DDV */
        if (DBA_GetInstrById(instrId, FALSE, &allocOk, 
                             &instrPtr, NULL, UNUSED,UNUSED) != RET_SUCCEED)
        {
		    SYSNAME_T entSqlName;
		    strcpy(entSqlName, DBA_GetDictEntitySqlName(Instr));
		    MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, 
				     entSqlName, instrId);
		    FREE_DYNST(flowArg, Flow_Arg);
	   	    return(RET_DBA_ERR_NODATA);  /* ?? */
        }
    }
    else
    {
	    instrPtr = inputInstrPtr;
        allocOk = FALSE;
    }

	/* Control asked event nature validity (depending on instr nature) */

	/* Call journal instrument flows creation */
	AppIncDivAccrualPos applIncludeDivAccrualPos = AppIncDivAccrualPos::includeInCashPos;
	GEN_GetApplInfo(ApplIncludeDivAccrualPosEnum, &applIncludeDivAccrualPos);

	/* Treat dates */
	if (timeDimEn == TimeDim_First || timeDimEn == TimeDim_Previous)
	{
		/* Previous events */
		begDate.time = 0;
		if (IS_NULLFLD(instrPtr, A_Instr_BeginDate) == TRUE)
			begDate.date = DATE_Move(refDate.date, -10, Year);
		else
			begDate.date = GET_DATE(instrPtr, A_Instr_BeginDate);

		endDate = refDate;
		/* if (endDate.date < begDate.date) ?? */
	}
	else
	{	    
		/* Future events */
		begDate = refDate;

		endDate.time = 0;
		if (IS_NULLFLD(instrPtr, A_Instr_EndDate) == TRUE ||
		    GET_DATE(instrPtr, A_Instr_EndDate) == MAGIC_END_DATE)
        {
            if (refDate.date != MAGIC_END_DATE)
			    endDate.date = DATE_Move(refDate.date, +10, Year);
            else
                endDate.date = refDate.date;
        }
		else
			endDate.date = GET_DATE(instrPtr, A_Instr_EndDate);
		/* if (endDate.date < begDate.date) ?? */
	}

	flowNbr = 0;
	found   = FALSE;

    SET_BIT64(mask, FlowSubNat_Any, TRUE);
    
#if 0 /* PMSTA15898 - DDV - 130206 - Remove this optimisation because result is wrong when date cheanged from one call to another */
    /* PMSTA10314 - DDV - 101119 - Load all interCond to have a better performance */
    if ((interCondPtr = ALLOC_DYNST(A_InterCond)) == NULLDYNST)
    {
    	if (allocOk == TRUE) { FREE_DYNST(instrPtr, A_Instr); }
        FREE_DYNST(flowArg, Flow_Arg);
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }
	/* PMSTA-14028 - TGU - 120606 -(Code reporting from PMSTA-13650)we need to use parent instruemntID in case of negative instrID */
	if(GET_ID(instrPtr, A_Instr_Id)<=0 && IS_NULLFLD(instrPtr, A_Instr_ParentInstrId) != TRUE)
	{
		SET_ID(interCondPtr,   A_InterCond_InstrId,   GET_ID(instrPtr, A_Instr_ParentInstrId));
	}
	else
	{
		SET_ID(interCondPtr,   A_InterCond_InstrId,   GET_ID(instrPtr, A_Instr_Id));
	}
    SET_DATE(interCondPtr, A_InterCond_BeginDate,   begDate.date);
    SET_DATE(interCondPtr, A_InterCond_ValidDate, valDate.date);
    SET_DATE(interCondPtr, A_InterCond_EndDate,   endDate.date);

    if (DBA_SelAllInterCond(InterCond_ByDt, hierHead, instrPtr, interCondPtr, 
						   &tmpInterCondTab, &tmpInterCondNbr, &freeRecFlg) == RET_SUCCEED)
    {
        if (freeRecFlg == TRUE)
        {
		    if (DBA_AddHierRecordList(hierHead, tmpInterCondTab, tmpInterCondNbr,
				    				  A_InterCond, TRUE) != RET_SUCCEED)
            {
    	        DBA_FreeDynStTab(tmpInterCondTab, tmpInterCondNbr, A_InterCond);
            }
            else
                FREE(tmpInterCondTab);
        }
        else
            FREE(tmpInterCondTab);
    }
    FREE_DYNST(interCondPtr, A_InterCond);
#endif /* PMSTA15898 - DDV - 130206 - Remove this optimisation because result is wrong when date cheanged from one call to another */

	/*
	 * Get the debt flag from the domain.
	 * REF3217 - 990118 - GRD.
	 */

	if ((domainPtr = DBA_GetDomainPtr(DBA_GetConnectNoFromHier((DBA_HIER_HEAD_STP) hierHead))) != NULLDYNST)
	{
		getDebtFlg = GET_FLAG(domainPtr, A_Domain_DebtFlg);
	}

	if (applIncludeDivAccrualPos == AppIncDivAccrualPos::includeInStockPos &&
		GET_ENUM(instrPtr, A_Instr_NatEn) == (ENUM_T)InstrNat_Stock &&
		timeDimEn == TimeDim_Crt)
	{
		begDate.time = 0;
		if (IS_NULLFLD(instrPtr, A_Instr_BeginDate) == TRUE)
			begDate.date = refDate.date;
		else
			begDate.date = GET_DATE(instrPtr, A_Instr_BeginDate);

		endDate.time = 0;
		endDate.date = DATE_Move(refDate.date, +1, Year);

		ret = FIN_GenStockInstrFlow(begDate, endDate, valDate,
			instrPtr, evtDateRuleEn, &flowTab, &flowNbr, hierHead);
	}
	else
	{

		ret = FIN_GenerateInstrFlows(begDate, endDate, valDate,
			noRefDateFlg,	 /* PMSTA-9032 - RAK - 091216 */
			GET_ID(instrPtr, A_Instr_Id), instrPtr,
			mask, EvtGen_Automatic,
			evtDateRuleEn,             /* REF4075 - 991110 - CSY */
			getDebtFlg, 	            /* getDebtFlg, REF3217. */
			GenInstrFlow_InstrFlow,    /* REF8866 - YST - 030311 */
			(ACCRRULE_ENUM)AccrRule_None, /* REF11218 - TEB - 050627 */
			&flowTab, &flowNbr, hierHead);
	}

	if (ret == RET_SUCCEED && flowNbr > 0)
	{
	    /* If necessary, update Flow_FilterFlg for each record */
	    if (flowNatEn != FlowNat_Any || flowSubNatEn != FlowSubNat_Any)
	    {
	    	ret = FIN_FilterFlows(flowNatEn, flowSubNatEn, 
				                flowTab, flowNbr, &filterFlowNbr);
	    }
	    else
		    filterFlowNbr = flowNbr; /* Flow_FilterFlg is FALSE for all */

	    if (ret == RET_SUCCEED && filterFlowNbr > 0)
	    {
		    TLS_Sort((char *) flowTab, flowNbr, sizeof(DBA_DYNFLD_STP),  
			        FIN_CmpFlows, (PTR **) NULL, SortRtnTp_None);

	    	switch (timeDimEn)
	    	{
	    	case TimeDim_First :
		        pos = 0;  /* send the first flow */
		        break;

	    	case TimeDim_Previous :
	            /* Found current event, events are before reference date */
		        for(i=0, refDatePos=filterFlowNbr; 
			    i<filterFlowNbr && refDatePos==filterFlowNbr; i++)
		        {
			    if (DATETIME_CMP(
			          GET_DATETIME(flowTab[i], Flow_OptimalDate), 
			          refDate) >= 0)
				    refDatePos = i;
		        }

		        pos = refDatePos - flowCnt;    
		        break;

	    	case TimeDim_Crt :
				if (applIncludeDivAccrualPos == AppIncDivAccrualPos::includeInStockPos &&
					GET_ENUM(instrPtr, A_Instr_NatEn) == (ENUM_T)InstrNat_Stock)
				{
					for (i = 0, refDatePos = filterFlowNbr; i < filterFlowNbr&&refDatePos == filterFlowNbr; i++)
					{
						if (DATETIME_CMP(GET_DATETIME(flowTab[i], Flow_OptimalValDate), refDate) >= 0)
						{
							refDatePos = i;
							break;
						}
					}
					pos = refDatePos - flowCnt;
				}
				else
					pos = 0;
		        break;

	    	case TimeDim_Next :
		        /* Found next event */
			{
				DBA_DYNFLD_STP  itersTpPtr = NULL, iteraTpPtr = NULL, maxsTpPtr = NULL, maxaTpPtr = NULL;
				for (i = 0, refDatePos = -1;
					i < filterFlowNbr; i++)
				{
					if (itersTpPtr == NULL)
					{
						if ((itersTpPtr = ALLOC_DYNST(S_Tp)) == NULL)
						{
							MSG_RETURN(RET_MEM_ERR_ALLOC);
						}
					}
					if (maxsTpPtr == NULL)
					{
						if ((maxsTpPtr = ALLOC_DYNST(S_Tp)) == NULL)
						{
							FREE_DYNST(itersTpPtr, S_Tp);
							MSG_RETURN(RET_MEM_ERR_ALLOC);
						}
					}
					if (iteraTpPtr == NULL)
					{
						if ((iteraTpPtr = ALLOC_DYNST(A_Tp)) == NULL)
						{
							FREE_DYNST(itersTpPtr, S_Tp);
							FREE_DYNST(maxsTpPtr, S_Tp);
							MSG_RETURN(RET_MEM_ERR_ALLOC);
						}
					}
					if (maxaTpPtr == NULL)
					{
						if ((maxaTpPtr = ALLOC_DYNST(A_Tp)) == NULL)
						{
							FREE_DYNST(itersTpPtr, S_Tp);
							FREE_DYNST(maxsTpPtr, S_Tp);
							FREE_DYNST(iteraTpPtr, A_Tp);
							MSG_RETURN(RET_MEM_ERR_ALLOC);
						}
					}
					if (flowTab[i] != NULL && ((Firstrefdate_f == FALSE && (DATETIME_CMP(
						GET_DATETIME(flowTab[i], Flow_OptimalDate),
						refDate) > 0)) || (Firstrefdate_f == TRUE && (DATETIME_CMP(
							GET_DATETIME(flowTab[i], Flow_OptimalDate),
							Firstrefdate) == 0))))
					{
						if (Firstrefdate_f == FALSE && (typeId == -1 || (CMP_ID(typeId, GET_ID((flowTab)[i], Flow_TpId)) == 0)))
						{
							refDatePos = i;
							Firstrefdate_f = TRUE;
							Firstrefdate = GET_DATETIME(flowTab[i + flowCnt - 1], Flow_OptimalDate);
						}
						if (typeId == -1)
						{
							if (IS_NULLFLD(flowTab[i], Flow_TpId) == FALSE)
							{
								SET_ID(itersTpPtr, S_Tp_Id, GET_ID((flowTab)[i], Flow_TpId));
								if (DBA_Get2(Tp, UNUSED, S_Tp, itersTpPtr, A_Tp, &iteraTpPtr,
									UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
								{
									FREE_DYNST(itersTpPtr, S_Tp);
									FREE_DYNST(iteraTpPtr, S_Tp);
									FREE_DYNST(maxsTpPtr, S_Tp);
									FREE_DYNST(maxaTpPtr, S_Tp);
									return(RET_SUCCEED);
								}
								if (IS_NULLFLD(iteraTpPtr, A_Tp_Rank) == FALSE)
								{
									if (IS_NULLFLD(maxaTpPtr, A_Tp_Rank) == TRUE)
										SET_SMALLINT(maxaTpPtr, A_Tp_Rank, GET_SMALLINT(iteraTpPtr, A_Tp_Rank));

									if (CMP_DYNFLD(iteraTpPtr, maxaTpPtr, A_Tp_Rank, A_Tp_Rank, SmallintType) <= 0)
									{
										refDatePos = i;
										SET_SMALLINT(maxaTpPtr, A_Tp_Rank, GET_SMALLINT(iteraTpPtr, A_Tp_Rank));
									}
								}
							}
							if (IS_NULLFLD(flowTab[i], Flow_TpId) == TRUE)
							{
								def_none_type_index = i;
								refDatePos = i;
							}
						}
					}
					else if (CMP_ID(typeId, GET_ID((flowTab)[i], Flow_TpId)) == 0)
					{
						refDatePos = i;  /* next */
					}
				}
				if (def_none_type_index != -1 && def_none_type_index != refDatePos)
					refDatePos = def_none_type_index;
				pos = refDatePos + flowCnt - 1;    /* next = founded = -1 */
				if (itersTpPtr != NULL) FREE_DYNST(itersTpPtr, S_Tp);
				if (maxsTpPtr != NULL) FREE_DYNST(maxsTpPtr, S_Tp);
				if (iteraTpPtr != NULL) FREE_DYNST(iteraTpPtr, A_Tp);
				if (maxaTpPtr != NULL) FREE_DYNST(maxaTpPtr, A_Tp);
				break;
			}

	    	case TimeDim_Final :
	    	case TimeDim_Last  : /* ?? */
		        pos = filterFlowNbr-1; /* send the final flow */
		        break;
	        }

			if (pos >= 0 && pos < filterFlowNbr)
			{

				if (sumflg_f == TRUE)
				{
					FIN_EXCHARG_ST exchArgSt;
					memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));

					ID_T instr_curr_id;
					instr_curr_id = GET_ID(instrPtr, A_Instr_RefCurrId);
					EXCHANGE_T        exch;
					DATETIME_T ref_datetime;
					ref_datetime = GET_DATETIME(flowTab[pos], Flow_OptimalDate);
					for (i = 0; i < flowNbr; i++)
					{
						exch = 1.0;
						if ((DATETIME_CMP(
							GET_DATETIME(flowTab[i], Flow_OptimalDate),
							ref_datetime) == 0) && ((CMP_ID(typeId, GET_ID((flowTab)[i], Flow_TpId)) == 0) || typeId == -1))
						{
							if (CMP_ID(instr_curr_id,GET_ID((flowTab)[i], Flow_AmtCurrId))!=0)
							{
								exchArgSt.srcAmt = GET_PRICE((flowTab)[i], Flow_Quote);
								FIN_GetExchRate(begDate, GET_ID((flowTab)[i], Flow_AmtCurrId), instr_curr_id, (ID_T)0,
									NULLDYNST, NULL, &exchArgSt, &exch);
							}
							quote_n = quote_n + (GET_PRICE((flowTab)[i], Flow_Quote)*exch);
						}
					}
				}
				COPY_DYNST(outputFlow, flowTab[pos], Flow);
				if (sumflg_f == TRUE)
					SET_PRICE(outputFlow, Flow_Quote, (PRICE_T)quote_n);
				found = TRUE;
			}
	    }

	    DBA_FreeDynStTab(flowTab, flowNbr, Flow);

	    /* BEGIN BUG030 960514 RAK */
	    if (found == FALSE)
	    {
		    ret = RET_DBA_ERR_NODATA;
		    /*MSG_SendMesg(ret, 3, FILEINFO, "FIN_InstrFlow", 
			         GET_CODE(instrPtr, A_Instr_Cd), "filtered flow");*/
	    }
	    /* END BUG030 960514 RAK */
	}
	else	/* BUG161 */
	{
	    if (flowNbr > 0)
	        DBA_FreeDynStTab(flowTab, flowNbr, Flow);

	    ret = RET_DBA_ERR_NODATA; 
	    /*MSG_SendMesg(ret, 3, FILEINFO, "FIN_InstrFlow",
			 GET_CODE(instrPtr, A_Instr_Cd), "no flow");*/
	}

	/* Set if NULL too, -> don't test each time to determine flow */
	/* BEGIN BUG030 960514 RAK */
	if (found == TRUE)
	{
	    DBA_SetMemory(OptiFct, UNUSED, Flow_Arg, flowArg,
		          Flow, outputFlow, Opti_Local);
	}
	else
	{
	    DBA_SetMemory(OptiFct, UNUSED, Flow_Arg, flowArg,
		          Flow, NULLDYNST, Opti_Local);
	}
	/* END BUG030 960514 RAK */

	if (allocOk == TRUE) { FREE_DYNST(instrPtr, A_Instr); }
	FREE_DYNST(flowArg, Flow_Arg);

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_FilterFlows()
**
**  Description :   Use input flow nature or flow subnature, If both are 
**                  supplied, use the subnature filter.
**                  Update Flow_FilterFlg for each record
**                 
**  Arguments   :   flowNatEn      filter flow nature
**                  flowSubNatEn   filter flow subnature
**                  flowTab        pointer on flows 
**                  flowNbr        flows number
**
**  Return      :   RET_SUCCEED or error code
**
*************************************************************************/
STATIC RET_CODE FIN_FilterFlows(FLOWNAT_ENUM    flowNatEn,
 			                    FLOWSUBNAT_ENUM flowSubNatEn,
				                DBA_DYNFLD_STP  *flowTab,
                                int             flowNbr,
				                int             *filterFlowNbr)
{
	int  i; 

	for (i=0, *filterFlowNbr=0; i<flowNbr; i++)
	{
	    /* Use subnature if both are given */
	    if (flowSubNatEn != FlowSubNat_Any)
	    {
		if (flowSubNatEn != 
		    (FLOWSUBNAT_ENUM) GET_ENUM(flowTab[i], Flow_SubNatEn))
		{
			SET_FLAG(flowTab[i], Flow_FilterFlg, TRUE);
		}
		else
			++(*filterFlowNbr);
	    }
	    else
	    {
	        /* Only nature is given */
		if (flowNatEn != (FLOWNAT_ENUM)GET_ENUM(flowTab[i], Flow_NatEn))
		{
			SET_FLAG(flowTab[i], Flow_FilterFlg, TRUE);
		}
		else
			++(*filterFlowNbr);
	    }
	}

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_CmpFlows()
**
**  Description :   Order no filtered flows by date
**                 
**  Arguments   :   flow1 and flow2 for comparison
**
**  Return      :   
**     a negative value if first element < second element
**     a null value     if first element = second element
**     a positive value if first element > second element
**
*************************************************************************/
STATIC int FIN_CmpFlows(void *arg1, void *arg2)
{
    DBA_DYNFLD_STP  *flow1 = (DBA_DYNFLD_STP*) arg1;
	DBA_DYNFLD_STP  *flow2 = (DBA_DYNFLD_STP*) arg2;
	int diff;

	/* First all no filtered flows sorting by date */
	if (GET_FLAG((*flow2), Flow_FilterFlg) ==  
	    GET_FLAG((*flow1), Flow_FilterFlg))
	{
	    if (GET_FLAG((*flow2), Flow_FilterFlg) == FALSE)
	    {
		    if ((diff = DATETIME_CMP(
			           GET_DATETIME((*flow1), Flow_OptimalDate),
		                   GET_DATETIME((*flow2), Flow_OptimalDate))) == 0)
		    {
			    return(GET_ENUM((*flow1), Flow_SubNatEn) -
			           GET_ENUM((*flow2), Flow_SubNatEn));
		    }
		    else
			    return(diff);
	    }
	    else
		    return(1); 
	}
	else
	{
	    if (GET_FLAG((*flow1), Flow_FilterFlg) == FALSE)
		    return(-1);
	    else
		    return(1);
	}
}

/************************************************************************
**
**  Function    :   FIN_InterestCond()
**
**  Description :   Get exchange condition interest according to an instrument and a date
**                 
**  Arguments   :   aInterCond     input and output interest condition structure pointer
**                  inputInstrPtr  input instrument pointer : can be NULL
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation date : BUG387 - RAK - 970602
**  Modif.	:   REF3678 - RAK - 990819
**
*************************************************************************/
RET_CODE FIN_InterestCond(DBA_DYNFLD_STP    aInterCond, 
			              DBA_DYNFLD_STP    inputInstrPtr,
			              DBA_HIER_HEAD_STP hierHead) /* REF3678 */
{
	DBA_DYNFLD_STP		*aInterCondTab = NULLDYNSTPTR;
	DBA_DYNFLD_STP		aInstr = NULLDYNST;
	FLAG_T          foundFlg = FALSE, aInterCondFreeRecFlg=FALSE;
	int			    aInterCondTabNbr = 0;
	int			    i = 0;
	FLAG_T			allocOk=FALSE;
	RET_CODE		ret;

	if (inputInstrPtr == NULLDYNST)
	{
        /* REF3913 - 990819 - DDV */
        if (DBA_GetInstrById(GET_ID(aInterCond, A_InterCond_InstrId), FALSE, &allocOk, 
                             &aInstr, NULL, UNUSED,UNUSED) != RET_SUCCEED)
	    {
		    SYSNAME_T entSqlName;
		    strcpy(entSqlName, DBA_GetDictEntitySqlName(Instr));
	   	    MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, entSqlName, 
			         GET_ID(aInterCond, A_InterCond_InstrId));
		    return(RET_DBA_ERR_NODATA);
	    }
	}
	else
	    aInstr = inputInstrPtr;

	switch ((INTERCD_ENUM) GET_ENUM(aInstr, A_Instr_InterestCdEn))
	{
		case InterCd_Instr:

		    SET_DATE(aInterCond, A_InterCond_BeginDate,   GET_DATE(aInstr, A_Instr_BeginDate));
		    SET_DATE(aInterCond, A_InterCond_ValidDate, GET_DATE(aInstr, A_Instr_BeginDate));
		    SET_DATE(aInterCond, A_InterCond_EndDate,   GET_DATE(aInstr, A_Instr_EndDate));
		    SET_ID(aInterCond,   A_InterCond_InstrId,   GET_ID(aInstr, A_Instr_Id));

		    SET_ENUM(aInterCond, A_InterCond_IntCalcRuleEn, InterCalcRule_Fixed);
		    SET_PERCENT(aInterCond, A_InterCond_InterestRateP,
			GET_PERCENT(aInstr, A_Instr_InterestRateP));

		    foundFlg = TRUE;
		    break;

		case InterCd_Evt:

            /* PMSTA00824 - ACB - 061123 Do it only if nature not define */
            if (IS_NULLFLD(aInterCond, A_InterCond_NatEn) == TRUE)
            {
                /* REFx - YST - 021010 */
                SET_ENUM(aInterCond, A_InterCond_NatEn, InterCondNat_None);
            }

		    
			/* REF3678 - Call new interCond function ... */
		    if ((ret = DBA_SelAllInterCond(InterCond_ByDt, hierHead, aInstr, aInterCond, 
						   &aInterCondTab, &aInterCondTabNbr, &aInterCondFreeRecFlg)) != RET_SUCCEED)
		    {
			    if (allocOk == TRUE) { FREE_DYNST(aInstr, A_Instr); }
		   	    return(ret);
		    }	

		    /*
		     * If a list of Interest Cond has been found, take the first element.
			 * PMSTA16299 - DDV - 130503 - Don't return the first one but returns the more recent (higher begin_d)
		     */

		    if (aInterCondTabNbr > 0)
		    {
		        for (i=0; i<aInterCondTabNbr; i++)
				{
					if (i==0 || CMP_DYNFLD(aInterCondTab[i], aInterCond, A_InterCond_BeginDate, A_InterCond_BeginDate, DateType) > 0)
						DBA_CopyDynSt(aInterCond, aInterCondTab[i], A_InterCond);

				    if (aInterCondFreeRecFlg == TRUE)
			      	  { FREE_DYNST(aInterCondTab[i], A_InterCond); }
			    }

			    FREE(aInterCondTab);
		     	foundFlg = TRUE;
		    }
		    break;
	}

	if (allocOk == TRUE) { FREE_DYNST(aInstr, A_Instr); }

	if (foundFlg == TRUE)
		return(RET_SUCCEED);
	else
		return(RET_DBA_ERR_NODATA);
}

/************************************************************************
**
**  Function    :   FIN_ExtOpUpdGlobalOrderCd()
**
**  Description :   Verify if childEOPtr is child from globEOPtr
**		    Verify ParOpNatEn (ChildOrder for child, BlockOrder for global)
**		    Compare instrument, operation nature and date
**		    Use globLogicIdRule (Dflt, Basic, Depo, PosCurr, All) to decide it
**                 
**  Arguments   :   
**
**  Return      :   RET_SUCCEED, RET_GEN_INFO_NOACTION or error code
**
**  Creation	:	RAK - 970709 - DVP460
**  Modif.	:	ROI - 980320 - REF1335
**
*************************************************************************/
RET_CODE FIN_ExtOpUpdGlobalOrderCd( DBA_DYNFLD_STP      childEOPtr, 
				                    DBA_DYNFLD_STP      globEOPtr, 
                                    LOGICIDRULE_ENUM   *globLogicIdRulePtr)
{
    if (childEOPtr == NULLDYNST ||
	    globEOPtr == NULLDYNST)
	{
	    MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, 
                    "FIN_ExtOpUpdGlobalOrderCd", "extended operation pointer(s)");
	    return(RET_GEN_ERR_INVARG);
	}

	if (*globLogicIdRulePtr == LogicIdRule_Dflt)
	{
        GEN_GetApplInfo(ApplGlobalOrderLogicalIdRule, globLogicIdRulePtr);
    }

	/* ParOpNatEn and basic verification */ /* PMSTA06760 - DDV - 080701 - Keep old check and add new for combined order */
	if (GET_ENUM(childEOPtr, ExtOp_ParOpNatEn) != (ENUM_T) ParOpNat_ChildCombinedOrder)
	{
		if (GET_ENUM(childEOPtr, ExtOp_ParOpNatEn) != (ENUM_T) ParOpNat_ChildOrder          ||
			(GET_ENUM(globEOPtr,  ExtOp_ParOpNatEn) != (ENUM_T) ParOpNat_BlockOrder &&
			 GET_ENUM(globEOPtr,  ExtOp_ParOpNatEn) != (ENUM_T) ParOpNat_UnallocBlkOrder)   ||
			GET_ID(childEOPtr, ExtOp_InstrId) != GET_ID(globEOPtr, ExtOp_InstrId)           ||
			GET_ENUM(childEOPtr, ExtOp_NatureEn) != GET_ENUM(globEOPtr, ExtOp_NatureEn)     ||
			DATETIME_CMP(GET_DATETIME(childEOPtr, ExtOp_OpDate), GET_DATETIME(globEOPtr, ExtOp_OpDate)) != 0)
		{
			return(RET_GEN_INFO_NOACTION);
		}

		/* Verify deposit */
		if ((*globLogicIdRulePtr == LogicIdRule_Depo || *globLogicIdRulePtr == LogicIdRule_All) &&
			 GET_ID(childEOPtr, ExtOp_DepoId) != GET_ID(globEOPtr, ExtOp_DepoId))
		{
			return(RET_GEN_INFO_NOACTION);
		}

		/* Verify operation currency */
		if ((*globLogicIdRulePtr == LogicIdRule_PosCurr || *globLogicIdRulePtr == LogicIdRule_All) &&
			GET_ID(childEOPtr, ExtOp_OpCurrId) != GET_ID(globEOPtr, ExtOp_OpCurrId))
		{
			return(RET_GEN_INFO_NOACTION);
		}
	}
	else /* ParOpNat_ChildCombinedOrder */ /* PMSTA06760 - DDV - 080701 - New check for combined order */
	{
		if (GET_ENUM(globEOPtr,  ExtOp_ParOpNatEn) != (ENUM_T) ParOpNat_CombinedOrder ||
			DATETIME_CMP(GET_DATETIME(childEOPtr, ExtOp_OpDate), GET_DATETIME(globEOPtr, ExtOp_OpDate)) != 0)
		{
			return(RET_GEN_INFO_NOACTION);
		}
	}

	if (IS_NULLFLD(globEOPtr, ExtOp_Cd) == FALSE)
    {
        SET_CODE(childEOPtr, ExtOp_ParOpCd, GET_CODE(globEOPtr, ExtOp_Cd));
    }
    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_GetCouponRate()
**
**  Description :   Get the coupon rate for instrument at reference date
**
**  Arguments   :   instrId       instrument identifier
**                  inputInstrPtr ptr on instrument structure or NULL
**                  refDate       reference date
**                  rate          coupon rate
**
**  Return      :   RET_SUCCEED or retcode
**
**  Creation    :   REF222 - XDI - 971013
**
**  Modif       :   REF1058 - RAK - 971218
**  Modif       :   REF1079 - RAK - 971219
**  Modif	    :   REF3678 - RAK - 990819
**  Modif       :   REF11218 - TEB - 050627
**
*************************************************************************/
RET_CODE FIN_GetCouponRate(ID_T           instrId,
                           DBA_DYNFLD_STP inputInstrPtr,
                           DBA_DYNFLD_STP inputIncPtr,	/* REF1079 */
                           DATETIME_T     refDate,
                           DATETIME_T     validDate,	/* REF1058 */
						   ACCRRULE_ENUM  accrRule,		/* REF11218 - TEB - 050627 */
                           DBA_DYNFLD_STP uInterPtr,	/* REF1079 */
			               DBA_HIER_HEAD_STP hierHead)	/* REF3678 */
{           
    DBA_DYNFLD_STP  instrPtr=NULLDYNST, interCondPtr=NULLDYNST, 
			        incPtr=NULLDYNST;
    NUMBER_T	    rate=0.0;
    FLAG_T          allocOk, allocIncFlg=FALSE;
    RET_CODE        ret;
    PRICECALCRULE_ENUM priceCalc;
	NUMBER_T		digitalRate = GET_NUMBER(uInterPtr, UnitInter_UnitAccrInter);

	SET_NUMBER(uInterPtr, UnitInter_UnitAccrInter, rate);	/* REF1079 - Init to 0.0 */

    if (inputInstrPtr == NULLDYNST)
    {
        /* REF3913 - 990819 - DDV */
        if ((ret = DBA_GetInstrById(instrId, FALSE, &allocOk, 
                                    &instrPtr, NULL, UNUSED,UNUSED)) != RET_SUCCEED)
        {
            SYSNAME_T entSqlName;
            strcpy(entSqlName, DBA_GetDictEntitySqlName(Instr));
            MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO,
                         entSqlName, instrId);
            return(ret);
        }
    }
    else
    {
        instrPtr = inputInstrPtr;
        allocOk = FALSE;
    }

    if (GET_ID(instrPtr, A_Instr_Id) < 0)
    { instrId = GET_ID(instrPtr, A_Instr_ParentInstrId); }
    else
    { instrId = GET_ID(instrPtr, A_Instr_Id); }

	SET_ID(uInterPtr, UnitInter_CurrId, GET_ID(instrPtr, A_Instr_RefCurrId)); /* REF1079 */

    if ((interCondPtr = ALLOC_DYNST(A_InterCond)) == NULLDYNST)
    {
        if (allocOk == TRUE) { FREE_DYNST(instrPtr, A_Instr); }
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    SET_ID(interCondPtr,   A_InterCond_InstrId,   instrId);
    SET_DATE(interCondPtr, A_InterCond_BeginDate,   refDate.date);
    SET_DATE(interCondPtr, A_InterCond_ValidDate, validDate.date);	/* REF1058 */

    if ((ret = FIN_InterestCond(interCondPtr, instrPtr, hierHead)) == RET_SUCCEED)
    {
		/* PMSTA-21906 - SHR - 151218 - If the floating rate is higher or equal than the minimum rate, 
		the fixed rate value is applied Otherwise it is 0. */
		if (digitalRate == 0.0 && (INTERCALCRULE_ENUM)GET_ENUM(uInterPtr, UnitInter_InterCalcRuleEn) == InterCalcRule_Digital)
			rate = 0.0;
		else
			rate = GET_PERCENT(interCondPtr, A_InterCond_InterestRateP) / 100.0;

        if (GET_ENUM(interCondPtr, A_InterCond_IntCalcRuleEn)==InterCalcRule_Floating)
        {
            double freq;    /* Don't compute compound : to dvp */
            FIN_PeriodUnitNbr((FREQUNIT_ENUM) GET_ENUM(interCondPtr, A_InterCond_CompoundFreqUnitEn),
                              GET_TINYINT(interCondPtr, A_InterCond_CompoundFreq),
                              FreqUnit_Month, &freq);

			/* REF11218 - TEB - 050627 */
			if (accrRule == AccrRule_None)
			{
				FIN_ComputeInterFloatRate(instrPtr, refDate.date, refDate.date,
										  (PERIOD_T) freq,
										  (ACCRRULE_ENUM) GET_ENUM(instrPtr,A_Instr_AccrualRuleEn),
										  interCondPtr, &rate, NULL);
			}
			else
			{
				FIN_ComputeInterFloatRate(instrPtr, refDate.date, refDate.date,
										  (PERIOD_T) freq,
										  accrRule,
										  interCondPtr, &rate, NULL);
			}
            rate /= 100.0;
        }
    }

	/* REF1079 - Apply fixed exchange only if currency are different */
	if (inputIncPtr == NULLDYNST)
	{
	    if ((incPtr = ALLOC_DYNST(A_IncEvt)) == NULLDYNST)
		{
        	FREE_DYNST(interCondPtr, A_InterCond);
        	if (allocOk == TRUE) { FREE_DYNST(instrPtr, A_Instr); }
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		/* If no income event, rate isn't adapted with fixed exchange rate */
	    if ((ret = DBA_GetIncEvt(instrPtr, refDate, incPtr)) != RET_SUCCEED)
		{
			FREE_DYNST(incPtr, A_IncEvt);
			incPtr = NULLDYNST;
			allocIncFlg = FALSE;
	    }
		else
			allocIncFlg = TRUE;
	}
	else
	{
		incPtr = inputIncPtr;
		allocIncFlg = FALSE;
	}

	if (incPtr != NULLDYNST &&
	    GET_ID(incPtr, A_IncEvt_CurrId) != GET_ID(instrPtr, A_Instr_RefCurrId))
	{
		EXCHANGE_T 	fxdExch=0.0;
		FIN_EXCHARG_ST  exchArgSt;			/* REF2313 */

		fxdExch = GET_EXCHANGE(incPtr, A_IncEvt_FixedExchRate);
		memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));	/* REF2313 */

		if (CMP_NUMBER(fxdExch, 0.0) == 0) 
	   		FIN_GetExchRate(refDate, GET_ID(incPtr, A_IncEvt_CurrId), 
					        GET_ID(instrPtr, A_Instr_RefCurrId), 
					        0, NULLDYNST, NULLDYNST, &exchArgSt/*NULL*/, &fxdExch);/* REF2313 *//* REF4528 - YST - 030210 */ /* PMSTA01649 - TGU - 070402 */
		rate = rate / fxdExch;

		SET_ID(uInterPtr, UnitInter_CurrId, GET_ID(incPtr, A_IncEvt_CurrId));
	}

    /* REF4637 - RAK - 000501 */
    /* search correct unpaid percentage */
	priceCalc = (PRICECALCRULE_ENUM) GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn);

	if (priceCalc == PriceCalcRule_PartiallyPaidStocks ||
	    priceCalc == PriceCalcRule_PartiallyPaidBonds)
	{ 
        DBA_DYNFLD_STP  instrChrono=NULLDYNST, dimChronoPtr=NULLDYNST;
        ID_T            localInstrId;
		
        if ((instrChrono = ALLOC_DYNST(A_InstrChrono)) == NULLDYNST)
			MSG_RETURN(RET_MEM_ERR_ALLOC);

	    if (GET_ID(instrPtr, A_Instr_Id) < 0)
            localInstrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
	    else
            localInstrId = GET_ID(instrPtr, A_Instr_Id);

		if ((dimChronoPtr = ALLOC_DYNST(Dim_InstrChrono)) == NULLDYNST)
		{
			FREE_DYNST(instrChrono, A_InstrChrono);
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		SET_ID(dimChronoPtr,       Dim_InstrChrono_InstrId,     localInstrId);
		SET_DATETIME(dimChronoPtr, Dim_InstrChrono_RefDate,     refDate);
		SET_ENUM(dimChronoPtr,     Dim_InstrChrono_NatEn,       ChronoNat_UnpPrct);
		SET_FLAG(dimChronoPtr,     Dim_InstrChrono_ComputeFlg,  FALSE);

		ret = FIN_InstrChrono(dimChronoPtr, instrPtr, instrChrono, hierHead);

		FREE_DYNST(dimChronoPtr, Dim_InstrChrono);

		/* 
		** TGU-REF11704-060413-Use GET_LONGAMOUNT since data type for field 
		** instr_chrono.value_n has been changed from NUMBER to LONGAMOUNT. 
		*/	
		if (ret == RET_SUCCEED && 
            CMP_NUMBER(GET_LONGAMOUNT(instrChrono, A_InstrChrono_Val), 0.0) != 0)
		{	
            /* apply unpaid percentage if necessary */            
	        rate = rate * (100 - GET_LONGAMOUNT(instrChrono, A_InstrChrono_Val)) / 100; /* REF11704 - TGU - 060419 - Change datatype */
		}

		FREE_DYNST(instrChrono, A_InstrChrono);
	} 

	SET_NUMBER(uInterPtr, UnitInter_UnitAccrInter, CAST_NUMBER(rate)); /* REF3288 - SSO - 990205 */

    FREE_DYNST(interCondPtr, A_InterCond);
    if (allocOk == TRUE) { FREE_DYNST(instrPtr, A_Instr); }
	if (allocIncFlg == TRUE) { FREE_DYNST(incPtr, A_IncEvt); }

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_CreateExchangeFlows()
**
**  Description :   Create all flows using exchange events.
**
**  Arguments   :   instrId       instrument identifier
**                  inputInstrPtr ptr on instrument structure or NULL
**                  refDate       reference date
**                  rate          coupon rate
**
**  Return      :   RET_SUCCEED or retcode
**
**  Creation    :   REF1132 - 980310 - DDV
**
**  Modif.	:   REF2313 - RAK - 980910
**  Modif.      :   REF2569 - AKO - 980818
**  Modif.      :   REF4075 - CSY - 991027
**  Modif.      :   REF4075 - CSY - 991110 shift the till date if earliest
**
*************************************************************************/
EXTERN RET_CODE FIN_CreateExchangeFlows(DBA_DYNFLD_STP    instrPtr,
                                        DATETIME_T        fromDateTime,
                                        DATETIME_T        *tillDateTime,
                                        DATETIME_T        valDateTime,
                                        EVTDATERULE_ENUM  evtDateRule,
                                        int               *allocSz,
                                        int               *flowNbr, 
                                        DBA_DYNFLD_STP    **flowTab,
			                            DBA_HIER_HEAD_STP hierHead)
{
	RET_CODE         ret = RET_SUCCEED;
	DBA_DYNFLD_STP   flowPtr=NULLDYNST, 
			        newInstrPtr=NULLDYNST, 
		            *exchTab=(DBA_DYNFLD_STP*)NULL;
    int              exchNbr = 0, i = 0;
    ID_T             euroCurrId=(ID_T)0;
    EXCHANGE_T       exchInstrEuro = (EXCHANGE_T) 0;
    NUMBER_T         newInstrQty = (NUMBER_T) 0;
    FLAG_T           replace = FALSE, allocOk = FALSE;
    DATETIME_T       date;
    FLOWSUBNAT_ENUM  flowSubNat = FlowSubNat_Any;
	FIN_EXCHARG_ST   exchArgSt;			/* REF2313 */

	memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));	/* REF2313 */

    date.time=0;
    date.date=0;

    GEN_GetApplInfo(ApplEuroCurrId , &euroCurrId);

	/* Select all exchange event */
	ret = DBA_SelectExchEvt(instrPtr, fromDateTime, *tillDateTime, valDateTime,
                                &exchTab, &exchNbr, hierHead);

	if (exchNbr != 0)
	{
        *allocSz = exchNbr;
        if (((*flowTab) = (DBA_DYNFLD_STP *) 
             CALLOC(*allocSz, sizeof(DBA_DYNFLD_STP))) == (DBA_DYNFLD_STP*)NULL)
        {
            DBA_FreeDynStTab(exchTab, exchNbr, A_ExchEvt);
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }
    
        /* Exchange event are order by validity date */
        *flowNbr = 0;
        for (replace=FALSE, i=0; i<exchNbr && replace == FALSE; i++)
        {
            /* Don't generate flow for nature other */
            if (GET_ENUM(exchTab[i], A_ExchEvt_NatEn) == ExchNat_Other)
                continue;
  
            if (((*flowTab)[*flowNbr] = ALLOC_DYNST(Flow)) == NULLDYNST)
            {
                DBA_FreeDynStTab(exchTab, exchNbr, A_ExchEvt); /* REF2569 - AKO - 980818 */
                MSG_RETURN(RET_MEM_ERR_ALLOC);
            }
    
            flowPtr = (*flowTab)[*flowNbr];

 		    /* REF3913 - DDV - 991006 */
		    if ((ret = DBA_GetInstrById(GET_ID(exchTab[i], A_ExchEvt_NewInstrId), FALSE, 
					            &allocOk, &newInstrPtr, hierHead, UNUSED, UNUSED)) != RET_SUCCEED)
            {   /* REF5714 - AKO - 010223 */
                /*SYSNAME_T entSqlName;
                strcpy(entSqlName, DBA_GetDictEntitySqlName(Instr));
                MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, 
                             entSqlName, GET_ID(exchTab[i], A_ExchEvt_NewInstrId));*/ 

                /* REF5714 - AKO - 010223 */
                MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO,"FIN_CreateExchangeFlows",
                        GET_CODE(instrPtr, A_Instr_Cd),
                        "DBA_GetInstrById - The New Instrument in exchange table not found !");
                DBA_FreeDynStTab(exchTab, exchNbr, A_ExchEvt); /* REF8712 - YST - 030122 */

                return(RET_DBA_ERR_NODATA); 
            }

            SET_NULL_ID(flowPtr,      Flow_Id);
            COPY_DYNFLD(flowPtr,      Flow,                Flow_InstrId,
                        exchTab[i],   A_ExchEvt,           A_ExchEvt_InstrId);
            COPY_DYNFLD(flowPtr,      Flow,                Flow_EvtCd,
                        exchTab[i],   A_ExchEvt,           A_ExchEvt_Cd);
            SET_INT(flowPtr,          Flow_EvtNbr,         1); /* REF8844 - LJE - 030327 */
            SET_ENUM(flowPtr,         Flow_NatEn,          FlowNat_Exch);

            COPY_DYNFLD(flowPtr,      Flow,                Flow_BegPayDate,
                        exchTab[i],   A_ExchEvt,		   A_ExchEvt_BeginDate);

            COPY_DYNFLD(flowPtr,      Flow,                Flow_EndPayDate,
                        exchTab[i],   A_ExchEvt,           A_ExchEvt_EndDate);

		    /* REF1798 - DDV - 980422 */
            /* REF4075 - CSY - 991027 */
            if(GET_ENUM(exchTab[i], A_ExchEvt_EuroConvRuleEn) == EuroConvRule_None)
            {
                switch ((EXCHNAT_ENUM) GET_ENUM(exchTab[i], A_ExchEvt_NatEn))
                {
                    case ExchNat_Conv :
                        flowSubNat = FlowSubNat_ConvExch;
                        break;
                    case ExchNat_Split :
                        flowSubNat = FlowSubNat_SplitExch;
                        break;
                    case ExchNat_RevSplit :
                        flowSubNat = FlowSubNat_ReverseSplitExch;
                        break;
                    case ExchNat_Attrib :
                        flowSubNat = FlowSubNat_AttribStockExch;
                        break;
                    case ExchNat_IssuerDec :
                        flowSubNat = FlowSubNat_OptConvIssExch;
                        break;
                    case ExchNat_HolderDec :
                        flowSubNat = FlowSubNat_OptConvHoldExch;
                        break;
			        case ExchNat_PropAttrib :	/* REF3470 - AKO - 990629 */
				        flowSubNat = FlowSubNat_PropAttrib;
				        break;
                    case ExchNat_AttribTheoPrice :   /* REF3470 - AKO - 990629 */
                        flowSubNat = FlowSubNat_AttribTheoPrice;
                        break;
					case ExchNat_Bonus:              /* PMSTA-36248 - SGO - 290819 */
						flowSubNat = FlowSubNat_Bonus;
						break;
					case ExchNat_Demerger:
						flowSubNat = FlowSubNat_Demerger;
						break;
					case ExchNat_Consolidation:
						flowSubNat = FlowSubNat_Consolidation;
						break;
                    case ExchNat_Other :
                        flowSubNat = FlowSubNat_OtherExch;
                        break;
                }
                SET_ENUM(flowPtr,          Flow_SubNatEn,       flowSubNat);
            }

            if (IS_NULLFLD(exchTab[i], A_ExchEvt_EndDate) == TRUE ||
                                GET_DATE(exchTab[i], A_ExchEvt_EndDate) == MAGIC_END_DATE)
		    {
	            COPY_DYNFLD(flowPtr,      Flow,                Flow_OptimalDate,
       		                exchTab[i],   A_ExchEvt,           A_ExchEvt_BeginDate);
		    }
            else
            {
                COPY_DYNFLD(flowPtr,      Flow,                Flow_OptimalDate,
       		                exchTab[i],   A_ExchEvt,           A_ExchEvt_EndDate);

                if ((evtDateRule == EvtDateRule_Earliest) &&
                            ((flowSubNat == FlowSubNat_OptConvIssExch)||
                            (flowSubNat == FlowSubNat_OptConvHoldExch)))
                {
		            if (DATETIME_CMP(valDateTime, GET_DATETIME(exchTab[i], A_ExchEvt_BeginDate)) <= 0)
                    {
                        COPY_DYNFLD(flowPtr,      Flow,                Flow_OptimalDate,
       		                            exchTab[i],   A_ExchEvt,       A_ExchEvt_BeginDate);
                    }
                    else
                    {
                        SET_DATETIME(flowPtr, Flow_OptimalDate, valDateTime);	 
                    }
                }
            }
                /*date.date = DATE_Move(GET_DATE(flowPtr,       Flow_OptimalDate), 
                                      GET_PERIOD(flowPtr, Flow_SettlDays), Day);*/
		    date.date = GET_DATE(flowPtr, Flow_OptimalDate); /* REF1193 - DDV - 980319 */
            SET_DATETIME(flowPtr,    Flow_OptimalValDate, date);

            if (GET_FLAG(exchTab[i], A_ExchEvt_ReplaceFlg) == TRUE &&
                GET_ID(exchTab[i], A_ExchEvt_NewInstrId) != GET_ID(instrPtr, A_Instr_Id))
            {
                replace = TRUE;
                /* REF2092 - AKO - 980814 */ /* REF2092 - DDV - 980831 - Use optimal date not begin date */
               
                if ((IS_NULLFLD(flowPtr, Flow_OptimalDate) != TRUE) &&
                    (GET_DATE(flowPtr, Flow_OptimalDate) < tillDateTime->date) &&
                    /*REF4075 - CSY -991101: don't shif the till date for optional 
                    conversions with term rule, because we need to generate the redemption flow
                    to do a comparision to find the most interesting flow between exchange and redemption*/
                    ((!((GET_ENUM(exchTab[i], A_ExchEvt_NatEn) == ExchNat_IssuerDec)||  
                     (GET_ENUM(exchTab[i], A_ExchEvt_NatEn) == ExchNat_HolderDec)))||
                     /* REF4075 - CSY - 991110 if earliest rule, conversion is forced so we must shift the tillDate */
                     (evtDateRule == EvtDateRule_Earliest))
                    )
                        tillDateTime->date = GET_DATE(flowPtr, Flow_OptimalDate);
            }

            SET_PERIOD(flowPtr,       Flow_SettlDays,      GET_TINYINT(exchTab[i], A_ExchEvt_SettleDays));

            SET_NULL_PERCENT(flowPtr, Flow_IoRPrct);
            COPY_DYNFLD(flowPtr,      Flow,                Flow_AmtUnit,
                        exchTab[i],   A_ExchEvt,           A_ExchEvt_Price);
            COPY_DYNFLD(flowPtr,      Flow,                Flow_NewInstrId,
                        exchTab[i],   A_ExchEvt,           A_ExchEvt_NewInstrId);

            switch (GET_ENUM(exchTab[i], A_ExchEvt_NatEn))
            {
                case ExchNat_Conv :
                    SET_ENUM(flowPtr, Flow_OptClassEn, OptClass_None);
                    break;
                case ExchNat_IssuerDec :
                    SET_ENUM(flowPtr, Flow_OptClassEn, OptClass_Call);
                    break;
                case ExchNat_HolderDec :
                    SET_ENUM(flowPtr, Flow_OptClassEn, OptClass_Put);
                    break;
                default :
                    SET_ENUM(flowPtr, Flow_OptClassEn, OptClass_None);
                    break;
            }

            SET_NULL_ENUM(flowPtr,    Flow_OptStyleEn);
            SET_PERCENT(flowPtr,      Flow_Proba,          100.0);
            SET_NULL_NUMBER(flowPtr,  Flow_Yield);
            SET_NULL_TINYINT(flowPtr, Flow_Freq);
            SET_NULL_ENUM(flowPtr,    Flow_FreqUnitEn);
		    /* REF1920 - DDV - 980429 */
            COPY_DYNFLD(flowPtr,      Flow,                Flow_FxdExchRate,
                        exchTab[i],   A_ExchEvt,           A_ExchEvt_FixedExchRate);
            SET_NULL_NUMBER(flowPtr,  Flow_CtdConvFact);
            SET_NULL_NUMBER(flowPtr,  Flow_CtdConvRatio);
            SET_NULL_ID(flowPtr,      Flow_CtdInstrId);
            COPY_DYNFLD(flowPtr,      Flow,                Flow_PhysicalFlg,
                        exchTab[i],   A_ExchEvt,           A_ExchEvt_DeliveryFlg);

            /* REF2302 - AKO - 980817 */
            /* SET_NULL_TINYINT(flowPtr,  Flow_Priority); */
            SET_TINYINT(flowPtr,  Flow_Priority,
                        (TINYINT_T)(GET_SMALLINT(exchTab[i],A_ExchEvt_Priority)));

            COPY_DYNFLD(flowPtr,      Flow,                Flow_ReplaceFlg,
                        exchTab[i],   A_ExchEvt,           A_ExchEvt_ReplaceFlg);

            SET_FLAG(flowPtr,         Flow_ConfirmedFlg,   TRUE);
            SET_NULL_DATE(flowPtr,    Flow_ExDate);

            switch(GET_ENUM(exchTab[i], A_ExchEvt_EuroConvRuleEn))
            { 
            case EuroConvRule_None:
                COPY_DYNFLD(flowPtr,      Flow,                Flow_AmtCurrId,
                            exchTab[i],   A_ExchEvt,           A_ExchEvt_CurrId);
                COPY_DYNFLD(flowPtr,      Flow,                Flow_Quote,
                            exchTab[i],   A_ExchEvt,           A_ExchEvt_Quote);

                if (IS_NULLFLD(exchTab[i], A_ExchEvt_RefQty) == TRUE ||
                    GET_NUMBER(exchTab[i], A_ExchEvt_RefQty) == 0)
                {
                    SET_NUMBER(flowPtr, Flow_RefQty, 1);  
                }
                else
                {
                    /* REF2958 - DDV - 981201 SET_NUMBER(flowPtr, Flow_RefQty, 
                            GET_SMALLINT(exchTab[i], A_ExchEvt_RefQty));*/
                    COPY_DYNFLD(flowPtr,      Flow,                Flow_RefQty,
                                exchTab[i],   A_ExchEvt,           A_ExchEvt_RefQty);
                }

                COPY_DYNFLD(flowPtr,      Flow,                Flow_QtyUnit,
                            exchTab[i],   A_ExchEvt,           A_ExchEvt_NewInstrQty);

                COPY_DYNFLD(flowPtr,      Flow,                  Flow_EuroConvRuleEn,
                            exchTab[i],   A_ExchEvt,             A_ExchEvt_EuroConvRuleEn);
                COPY_DYNFLD(flowPtr,      Flow,                  Flow_RoundRuleEn,
                            exchTab[i],   A_ExchEvt,             A_ExchEvt_RoundRuleEn);
                COPY_DYNFLD(flowPtr,      Flow,                  Flow_NewInstrMinDenom,
                            exchTab[i],   A_ExchEvt,             A_ExchEvt_NewInstrMinDenom);
                COPY_DYNFLD(flowPtr,      Flow,                  Flow_OddLotCompEn,
                            exchTab[i],   A_ExchEvt,             A_ExchEvt_OddLotCompEn);
                COPY_DYNFLD(flowPtr,      Flow,                  Flow_RoundLevelEn,
                            exchTab[i],   A_ExchEvt,             A_ExchEvt_RoundLevelEn);

                break;

            case EuroConvRule_BottomUpOneCent:
                COPY_DYNFLD(flowPtr,      Flow,                Flow_AmtCurrId,
                            newInstrPtr,  A_Instr,             A_Instr_RefCurrId);
                SET_NULL_PRICE(flowPtr,  Flow_Quote);

                exchInstrEuro = (EXCHANGE_T) 0; 
                FIN_GetExchRate(GET_DATETIME(flowPtr, Flow_BegPayDate), 
                                euroCurrId, GET_ID(instrPtr, A_Instr_RefCurrId), /* REF1680 - DDV - 980416 */
                                (ID_T)0, NULLDYNST, NULLDYNST, &exchArgSt, &exchInstrEuro); /* REF2313 */ /* PMSTA01649 - TGU - 070402 */

                if (exchInstrEuro == (EXCHANGE_T) 0)
                {
                    SET_NUMBER(flowPtr, Flow_RefQty, 1);  
                }
                else
                {
                    SET_EXCHANGE(flowPtr, Flow_RefQty, exchInstrEuro);
                }

                SET_NUMBER(flowPtr,       Flow_QtyUnit,          1);

                SET_ENUM(flowPtr,         Flow_SubNatEn,         FlowSubNat_ConvExch);

                COPY_DYNFLD(flowPtr,      Flow,                  Flow_EuroConvRuleEn,
                            exchTab[i],   A_ExchEvt,             A_ExchEvt_EuroConvRuleEn);
                SET_ENUM(flowPtr,         Flow_RoundRuleEn,      RndRule_Nearest);
                SET_NUMBER(flowPtr,       Flow_NewInstrMinDenom, 0.01);
                SET_ENUM(flowPtr,         Flow_OddLotCompEn,     OddLotComp_Lost);
                SET_ENUM(flowPtr,         Flow_RoundLevelEn,     RndLevel_BottomUp);

                break;

            case EuroConvRule_BottomUpOneEuro:
                COPY_DYNFLD(flowPtr,      Flow,                Flow_AmtCurrId,
                            newInstrPtr,  A_Instr,             A_Instr_RefCurrId);
                SET_NULL_PRICE(flowPtr,  Flow_Quote);

                exchInstrEuro = (EXCHANGE_T) 0; 
                FIN_GetExchRate(GET_DATETIME(flowPtr, Flow_BegPayDate), 
                                euroCurrId, GET_ID(instrPtr, A_Instr_RefCurrId), /* REF1680 - DDV - 980416 */
                                (ID_T)0, NULLDYNST, NULLDYNST, &exchArgSt, &exchInstrEuro);	/* PMSTA01649 - TGU - 070402 */

                if (exchInstrEuro == (EXCHANGE_T) 0)
                {
                    SET_NUMBER(flowPtr, Flow_RefQty, 1);  
                }
                else
                {
                    SET_EXCHANGE(flowPtr, Flow_RefQty, exchInstrEuro);
                }

                SET_NUMBER(flowPtr,       Flow_QtyUnit,          1);

                SET_ENUM(flowPtr,         Flow_SubNatEn,         FlowSubNat_ConvExch);

                COPY_DYNFLD(flowPtr,      Flow,                  Flow_EuroConvRuleEn,
                            exchTab[i],   A_ExchEvt,             A_ExchEvt_EuroConvRuleEn);
                SET_ENUM(flowPtr,         Flow_RoundRuleEn,      RndRule_Down);
                SET_NUMBER(flowPtr,       Flow_NewInstrMinDenom, 1);
                SET_ENUM(flowPtr,         Flow_OddLotCompEn,     OddLotComp_CashCompensationNew);
                SET_ENUM(flowPtr,         Flow_RoundLevelEn,     RndLevel_BottomUp);

                break;

            case EuroConvRule_BottomUpMinDenom:
                COPY_DYNFLD(flowPtr,      Flow,                Flow_AmtCurrId,
                            newInstrPtr,  A_Instr,             A_Instr_RefCurrId);
                SET_NULL_PRICE(flowPtr,  Flow_Quote);

                exchInstrEuro = (EXCHANGE_T) 0; 
                FIN_GetExchRate(GET_DATETIME(flowPtr, Flow_BegPayDate), 
                                euroCurrId, GET_ID(instrPtr, A_Instr_RefCurrId), /* REF1680 - DDV - 980416 */
                                (ID_T)0, NULLDYNST, NULLDYNST, &exchArgSt, &exchInstrEuro);	/* PMSTA01649 - TGU - 070402 */

                if (exchInstrEuro == (EXCHANGE_T) 0)
                {
                    SET_NUMBER(flowPtr, Flow_RefQty, 1);  
                }
                else
                {
                    SET_EXCHANGE(flowPtr, Flow_RefQty, exchInstrEuro);
                }

                SET_NUMBER(flowPtr,       Flow_QtyUnit,          1);

                SET_ENUM(flowPtr,         Flow_SubNatEn,         FlowSubNat_ConvExch);

                COPY_DYNFLD(flowPtr,      Flow,                  Flow_EuroConvRuleEn,
                            exchTab[i],   A_ExchEvt,             A_ExchEvt_EuroConvRuleEn);
                SET_ENUM(flowPtr,         Flow_RoundRuleEn,      RndRule_Down);

                if (IS_NULLFLD(exchTab[i], A_ExchEvt_NewInstrMinDenom) ||
                    GET_NUMBER(exchTab[i], A_ExchEvt_NewInstrMinDenom) == 0)
                {
                    if (IS_NULLFLD(newInstrPtr, A_Instr_FaceValue) ||
                        GET_PRICE(newInstrPtr, A_Instr_FaceValue) == 0)
                    {
                        SET_NUMBER(flowPtr,       Flow_NewInstrMinDenom, 1);
                    }
                    else
                    {
                        COPY_DYNFLD(flowPtr,      Flow,                  Flow_NewInstrMinDenom,
                                    newInstrPtr,  A_Instr,               A_Instr_FaceValue);
                    }
                }
                else
                {
                    COPY_DYNFLD(flowPtr,      Flow,                  Flow_NewInstrMinDenom,
                                exchTab[i],   A_ExchEvt,             A_ExchEvt_NewInstrMinDenom);
                }

                SET_ENUM(flowPtr,         Flow_OddLotCompEn,     OddLotComp_CashCompensationNew);
                SET_ENUM(flowPtr,         Flow_RoundLevelEn,     RndLevel_BottomUp);

                break;

            case EuroConvRule_TopDownOneCent:
                COPY_DYNFLD(flowPtr,      Flow,                Flow_AmtCurrId,
                            newInstrPtr,  A_Instr,             A_Instr_RefCurrId);
                SET_NULL_PRICE(flowPtr,  Flow_Quote);

                if (IS_NULLFLD(instrPtr, A_Instr_FaceValue) == TRUE ||
                    GET_PRICE(instrPtr, A_Instr_FaceValue) == 0)
                {
                    SET_NUMBER(flowPtr, Flow_RefQty, 1);  
                }
                else
                {
                    COPY_DYNFLD(flowPtr,      Flow,                  Flow_RefQty,
                                instrPtr,     A_Instr,               A_Instr_FaceValue);
                }

                exchInstrEuro = (EXCHANGE_T) 0; 
                FIN_GetExchRate(GET_DATETIME(flowPtr, Flow_BegPayDate), 
                                euroCurrId, GET_ID(instrPtr, A_Instr_RefCurrId), /* REF1680 - DDV - 980416 */
                                (ID_T)0, NULLDYNST, NULLDYNST, &exchArgSt, &exchInstrEuro);	/* PMSTA01649 - TGU - 070402 */

                if (exchInstrEuro == (EXCHANGE_T) 0)
                {
                    newInstrQty = 1;
                }
                else
                {
                    /*newInstrQty = TLS_RoundEnum(GET_NUMBER(flowPtr, Flow_RefQty) / 
                                                exchInstrEuro,
                                                RndUnit_0_00001, RndRule_Down); - REF6131 - 010806 - DDV - Round must be done when creating operations */
                    newInstrQty = GET_NUMBER(flowPtr, Flow_RefQty) / exchInstrEuro;
                }

                SET_NUMBER(flowPtr,       Flow_QtyUnit,          newInstrQty);

                SET_ENUM(flowPtr,         Flow_SubNatEn,         FlowSubNat_ConvExch);

                COPY_DYNFLD(flowPtr,      Flow,                  Flow_EuroConvRuleEn,
                            exchTab[i],   A_ExchEvt,             A_ExchEvt_EuroConvRuleEn);
                SET_ENUM(flowPtr,         Flow_RoundRuleEn,      RndRule_Nearest);
                SET_NUMBER(flowPtr,       Flow_NewInstrMinDenom, 0.01);
                SET_ENUM(flowPtr,         Flow_OddLotCompEn,     OddLotComp_Lost);
                SET_ENUM(flowPtr,         Flow_RoundLevelEn,     RndLevel_TopDown);

                break;

            case EuroConvRule_TopDownOneEuro:
                COPY_DYNFLD(flowPtr,      Flow,                Flow_AmtCurrId,
                            newInstrPtr,  A_Instr,             A_Instr_RefCurrId);
                SET_NULL_PRICE(flowPtr,  Flow_Quote);

                if (IS_NULLFLD(instrPtr, A_Instr_FaceValue) == TRUE ||
                    GET_PRICE(instrPtr, A_Instr_FaceValue) == 0)
                {
                    SET_NUMBER(flowPtr, Flow_RefQty, 1);  
                }
                else
                {
                    COPY_DYNFLD(flowPtr,      Flow,                  Flow_RefQty,
                                instrPtr,     A_Instr,               A_Instr_FaceValue);
                }

                exchInstrEuro = (EXCHANGE_T) 0; 
                FIN_GetExchRate(GET_DATETIME(flowPtr, Flow_BegPayDate), 
                                euroCurrId, GET_ID(instrPtr, A_Instr_RefCurrId), /* REF1680 - DDV - 980416 */
                                (ID_T)0, NULLDYNST, NULLDYNST, &exchArgSt, &exchInstrEuro);	/* PMSTA01649 - TGU - 070402 */

                if (exchInstrEuro == (EXCHANGE_T) 0)
                {
                    newInstrQty = 1;
                }
                else
                {
                    /* newInstrQty = TLS_RoundEnum(GET_NUMBER(flowPtr, Flow_RefQty) / 
                                                exchInstrEuro,
                                                RndUnit_0_00001, RndRule_Down); - REF6131 - 010806 - DDV - Round must be done when creating operations */
                    newInstrQty = GET_NUMBER(flowPtr, Flow_RefQty) / exchInstrEuro;
                }

                SET_NUMBER(flowPtr,       Flow_QtyUnit,          newInstrQty);

                SET_ENUM(flowPtr,         Flow_SubNatEn,         FlowSubNat_ConvExch);

                COPY_DYNFLD(flowPtr,      Flow,                  Flow_EuroConvRuleEn,
                            exchTab[i],   A_ExchEvt,             A_ExchEvt_EuroConvRuleEn);
                SET_ENUM(flowPtr,         Flow_RoundRuleEn,      RndRule_Down);
                SET_NUMBER(flowPtr,       Flow_NewInstrMinDenom, 1);
                SET_ENUM(flowPtr,         Flow_OddLotCompEn,     OddLotComp_CashCompensationNew);
                SET_ENUM(flowPtr,         Flow_RoundLevelEn,     RndLevel_TopDown);

                break;

            case EuroConvRule_TopDownMinDenom:
                COPY_DYNFLD(flowPtr,      Flow,                Flow_AmtCurrId,
                            newInstrPtr,  A_Instr,             A_Instr_RefCurrId);
                SET_NULL_PRICE(flowPtr,  Flow_Quote);

                if (IS_NULLFLD(instrPtr, A_Instr_FaceValue) == TRUE || /* REF1903 - DDV - 980427 */
                    GET_PRICE(instrPtr, A_Instr_FaceValue) == 0)      /* REF1903 - DDV - 980427 */
                {
                    SET_NUMBER(flowPtr, Flow_RefQty, 1);  
                }
                else
                {
                    COPY_DYNFLD(flowPtr,      Flow,                  Flow_RefQty,
                                instrPtr,     A_Instr,               A_Instr_FaceValue); /* REF1903 - DDV - 980427 */
                }

                exchInstrEuro = (EXCHANGE_T) 0; 
                FIN_GetExchRate(GET_DATETIME(flowPtr, Flow_BegPayDate), 
                                euroCurrId, GET_ID(instrPtr, A_Instr_RefCurrId), /* REF1680 - DDV - 980416 */
                                (ID_T)0, NULLDYNST, NULLDYNST, &exchArgSt, &exchInstrEuro);	/* PMSTA01649 - TGU - 070402 */

                if (exchInstrEuro == (EXCHANGE_T) 0)
                {
                    newInstrQty = 1;
                }
                else
                {
                    newInstrQty = TLS_RoundEnum(GET_NUMBER(flowPtr, Flow_RefQty) / 
                                                exchInstrEuro,
                                                RndUnit_0_00001, RndRule_Down);
                }

                SET_NUMBER(flowPtr,       Flow_QtyUnit,          newInstrQty);

                SET_ENUM(flowPtr,         Flow_SubNatEn,         FlowSubNat_ConvExch);

                COPY_DYNFLD(flowPtr,      Flow,                  Flow_EuroConvRuleEn,
                            exchTab[i],   A_ExchEvt,             A_ExchEvt_EuroConvRuleEn);
                SET_ENUM(flowPtr,         Flow_RoundRuleEn,      RndRule_Down);

                if (IS_NULLFLD(exchTab[i], A_ExchEvt_NewInstrMinDenom) ||
                    GET_NUMBER(exchTab[i], A_ExchEvt_NewInstrMinDenom) == 0)
                {
                    if (IS_NULLFLD(newInstrPtr, A_Instr_FaceValue) ||
                        GET_PRICE(newInstrPtr, A_Instr_FaceValue) == 0)
                    {
                        SET_NUMBER(flowPtr,       Flow_NewInstrMinDenom, 1);
                    }
                    else
                    {
                        COPY_DYNFLD(flowPtr,      Flow,                  Flow_NewInstrMinDenom,
                                    newInstrPtr,  A_Instr,               A_Instr_FaceValue);
                    }
                    /* FREE_DYNST(newInstrPtr, A_Instr); */ /* REF8712 - YST - 030124 */
                }
                else
                {
                    COPY_DYNFLD(flowPtr,      Flow,                  Flow_NewInstrMinDenom,
                                exchTab[i],   A_ExchEvt,             A_ExchEvt_NewInstrMinDenom);
                }

                SET_ENUM(flowPtr,         Flow_OddLotCompEn,     OddLotComp_CashCompensationNew);
                SET_ENUM(flowPtr,         Flow_RoundLevelEn,     RndLevel_TopDown);

                break;

            case EuroConvRule_TopDownMinLot:
                COPY_DYNFLD(flowPtr,      Flow,                Flow_AmtCurrId,
                            newInstrPtr,  A_Instr,             A_Instr_RefCurrId);
                SET_NULL_PRICE(flowPtr,  Flow_Quote);

                if (IS_NULLFLD(instrPtr, A_Instr_FaceValue) == TRUE ||
                    GET_PRICE(instrPtr, A_Instr_FaceValue) == 0)
                {
                    SET_NUMBER(flowPtr, Flow_RefQty, 1);  
                }
                else
                {
                    COPY_DYNFLD(flowPtr,      Flow,                  Flow_RefQty,
                                instrPtr,     A_Instr,               A_Instr_FaceValue);
                }

                exchInstrEuro = (EXCHANGE_T) 0; 
                FIN_GetExchRate(GET_DATETIME(flowPtr, Flow_BegPayDate), 
                                euroCurrId, GET_ID(instrPtr, A_Instr_RefCurrId), /* REF1680 - DDV - 980416 */
                                (ID_T)0, NULLDYNST, NULLDYNST, &exchArgSt, &exchInstrEuro);	/* PMSTA01649 - TGU - 070402 */

                if (exchInstrEuro == (EXCHANGE_T) 0)
                {
                    newInstrQty = 1;
                }
                else
                {
                    newInstrQty = TLS_RoundEnum(GET_NUMBER(flowPtr, Flow_RefQty) / 
                                                exchInstrEuro,
                                                RndUnit_0_00001, RndRule_Down);
                }

                SET_NUMBER(flowPtr,       Flow_QtyUnit,          newInstrQty);

                SET_ENUM(flowPtr,         Flow_SubNatEn,         FlowSubNat_ConvExch);

                COPY_DYNFLD(flowPtr,      Flow,                  Flow_EuroConvRuleEn,
                            exchTab[i],   A_ExchEvt,             A_ExchEvt_EuroConvRuleEn);
                SET_ENUM(flowPtr,         Flow_RoundRuleEn,      RndRule_Nearest);
                SET_NUMBER(flowPtr,       Flow_NewInstrMinDenom, 0.01);
                SET_ENUM(flowPtr,         Flow_OddLotCompEn,     OddLotComp_Lost);
                SET_ENUM(flowPtr,         Flow_RoundLevelEn,     RndLevel_TopDown);

                break;

            case EuroConvRule_BottomUpOneEuroLost: /* REF2957 - DDV - 981103 */
                COPY_DYNFLD(flowPtr,      Flow,                Flow_AmtCurrId,
                            newInstrPtr,  A_Instr,             A_Instr_RefCurrId);
                SET_NULL_PRICE(flowPtr,  Flow_Quote);

                exchInstrEuro = (EXCHANGE_T) 0; 
                FIN_GetExchRate(GET_DATETIME(flowPtr, Flow_BegPayDate), 
                                euroCurrId, GET_ID(instrPtr, A_Instr_RefCurrId), /* REF1680 - DDV - 980416 */
                                (ID_T)0, NULLDYNST, NULLDYNST, &exchArgSt, &exchInstrEuro);	/* PMSTA01649 - TGU - 070402 */ 

                if (exchInstrEuro == (EXCHANGE_T) 0)
                {
                    SET_NUMBER(flowPtr, Flow_RefQty, 1);  
                }
                else
                {
                    SET_EXCHANGE(flowPtr, Flow_RefQty, exchInstrEuro);
                }

                SET_NUMBER(flowPtr,       Flow_QtyUnit,          1);

                SET_ENUM(flowPtr,         Flow_SubNatEn,         FlowSubNat_ConvExch);

                COPY_DYNFLD(flowPtr,      Flow,                  Flow_EuroConvRuleEn,
                            exchTab[i],   A_ExchEvt,             A_ExchEvt_EuroConvRuleEn);
                SET_ENUM(flowPtr,         Flow_RoundRuleEn,      RndRule_Up); /* REF2957 - DDV - 981103 */
                SET_NUMBER(flowPtr,       Flow_NewInstrMinDenom, 1); /* REF2957 - DDV - 981103 */
                SET_ENUM(flowPtr,         Flow_OddLotCompEn,     OddLotComp_Lost); /* REF2957 - DDV - 981103 */
                SET_ENUM(flowPtr,         Flow_RoundLevelEn,     RndLevel_BottomUp); /* REF2957 - DDV - 981103 */

                break;

            case EuroConvRule_BottomUpMinDenomOneEuro:   /* REF6187 - DDV - 010810 */
                COPY_DYNFLD(flowPtr,      Flow,                Flow_AmtCurrId,
                            newInstrPtr,  A_Instr,             A_Instr_RefCurrId);
                SET_NULL_PRICE(flowPtr,  Flow_Quote);

                exchInstrEuro = (EXCHANGE_T) 0; 
                FIN_GetExchRate(GET_DATETIME(flowPtr, Flow_BegPayDate), 
                                euroCurrId, GET_ID(instrPtr, A_Instr_RefCurrId),
                                (ID_T)0, NULLDYNST, NULLDYNST, &exchArgSt, &exchInstrEuro);	/* PMSTA01649 - TGU - 070402 */

                if (IS_NULLFLD(instrPtr, A_Instr_FaceValue) ||
                    GET_PRICE(instrPtr, A_Instr_FaceValue) == 0)
                {
                    SET_NUMBER(flowPtr,       Flow_RefQty, 1);
                }
                else
                {
                    COPY_DYNFLD(flowPtr,      Flow,                  Flow_RefQty,
                                instrPtr,     A_Instr,               A_Instr_FaceValue);
                }

                if (exchInstrEuro != (EXCHANGE_T) 0)
                {
                    SET_NUMBER(flowPtr, Flow_RefQty, GET_NUMBER(flowPtr , Flow_RefQty) / exchInstrEuro);
                }

                SET_NUMBER(flowPtr, Flow_RefQty,TLS_RoundEnum(GET_NUMBER(flowPtr, Flow_RefQty),
                                                RndUnit_0_00001, RndRule_Down));
                SET_NUMBER(flowPtr,       Flow_QtyUnit,          1);

                SET_ENUM(flowPtr,         Flow_SubNatEn,         FlowSubNat_ConvExch);

                COPY_DYNFLD(flowPtr,      Flow,                  Flow_EuroConvRuleEn,
                            exchTab[i],   A_ExchEvt,             A_ExchEvt_EuroConvRuleEn);
                SET_ENUM(flowPtr,         Flow_RoundRuleEn,      RndRule_Down);

                if (IS_NULLFLD(exchTab[i], A_ExchEvt_NewInstrMinDenom) ||
                    GET_NUMBER(exchTab[i], A_ExchEvt_NewInstrMinDenom) == 0)
                {
                    if (IS_NULLFLD(newInstrPtr, A_Instr_FaceValue) ||
                        GET_PRICE(newInstrPtr, A_Instr_FaceValue) == 0)
                    {
                        SET_NUMBER(flowPtr,       Flow_NewInstrMinDenom, 1);
                    }
                    else
                    {
                        COPY_DYNFLD(flowPtr,      Flow,                  Flow_NewInstrMinDenom,
                                    newInstrPtr,  A_Instr,               A_Instr_FaceValue);
                    }
                }
                else
                {
                    COPY_DYNFLD(flowPtr,      Flow,                  Flow_NewInstrMinDenom,
                                exchTab[i],   A_ExchEvt,             A_ExchEvt_NewInstrMinDenom);
                }

                SET_ENUM(flowPtr,         Flow_OddLotCompEn,     OddLotComp_CashCompensationNew);
                SET_ENUM(flowPtr,         Flow_RoundLevelEn,     RndLevel_BottomUp);

                break;

            case EuroConvRule_BottomUpMinDenomOneCent:   /* REF6187 - DDV - 010810 */
                COPY_DYNFLD(flowPtr,      Flow,                Flow_AmtCurrId,
                            newInstrPtr,  A_Instr,             A_Instr_RefCurrId);
                SET_NULL_PRICE(flowPtr,  Flow_Quote);

                exchInstrEuro = (EXCHANGE_T) 0; 
                FIN_GetExchRate(GET_DATETIME(flowPtr, Flow_BegPayDate), 
                                euroCurrId, GET_ID(instrPtr, A_Instr_RefCurrId),
                                (ID_T)0, NULLDYNST, NULLDYNST, &exchArgSt, &exchInstrEuro);	/* PMSTA01649 - TGU - 070402 */

                if (IS_NULLFLD(instrPtr, A_Instr_FaceValue) ||
                    GET_PRICE(instrPtr, A_Instr_FaceValue) == 0)
                {
                    SET_NUMBER(flowPtr,       Flow_RefQty, 1);
                }
                else
                {
                    COPY_DYNFLD(flowPtr,      Flow,                  Flow_RefQty,
                                instrPtr,     A_Instr,               A_Instr_FaceValue);
                }

                if (exchInstrEuro != (EXCHANGE_T) 0)
                {
                    SET_NUMBER(flowPtr, Flow_RefQty, GET_NUMBER(flowPtr , Flow_RefQty) / exchInstrEuro);
                }

                SET_NUMBER(flowPtr, Flow_RefQty,TLS_RoundEnum(GET_NUMBER(flowPtr, Flow_RefQty),
                                                RndUnit_0_01, RndRule_Nearest));
                SET_NUMBER(flowPtr,       Flow_QtyUnit,          1);

                SET_ENUM(flowPtr,         Flow_SubNatEn,         FlowSubNat_ConvExch);

                COPY_DYNFLD(flowPtr,      Flow,                  Flow_EuroConvRuleEn,
                            exchTab[i],   A_ExchEvt,             A_ExchEvt_EuroConvRuleEn);
                SET_ENUM(flowPtr,         Flow_RoundRuleEn,      RndRule_Down);

                if (IS_NULLFLD(exchTab[i], A_ExchEvt_NewInstrMinDenom) ||
                    GET_NUMBER(exchTab[i], A_ExchEvt_NewInstrMinDenom) == 0)
                {
                    if (IS_NULLFLD(newInstrPtr, A_Instr_FaceValue) ||
                        GET_PRICE(newInstrPtr, A_Instr_FaceValue) == 0)
                    {
                        SET_NUMBER(flowPtr,       Flow_NewInstrMinDenom, 1);
                    }
                    else
                    {
                        COPY_DYNFLD(flowPtr,      Flow,                  Flow_NewInstrMinDenom,
                                    newInstrPtr,  A_Instr,               A_Instr_FaceValue);
                    }
                }
                else
                {
                    COPY_DYNFLD(flowPtr,      Flow,                  Flow_NewInstrMinDenom,
                                exchTab[i],   A_ExchEvt,             A_ExchEvt_NewInstrMinDenom);
                }

                SET_ENUM(flowPtr,         Flow_OddLotCompEn,     OddLotComp_CashCompensationNew);
                SET_ENUM(flowPtr,         Flow_RoundLevelEn,     RndLevel_BottomUp);

                break;

            case EuroConvRule_BottomUpHolding25Cents:   /* REF6187 - DDV - 010810 */
                COPY_DYNFLD(flowPtr,      Flow,                Flow_AmtCurrId,
                            newInstrPtr,  A_Instr,             A_Instr_RefCurrId);
                SET_NULL_PRICE(flowPtr,  Flow_Quote);

                exchInstrEuro = (EXCHANGE_T) 0; 
                FIN_GetExchRate(GET_DATETIME(flowPtr, Flow_BegPayDate), 
                                euroCurrId, GET_ID(instrPtr, A_Instr_RefCurrId),
                                (ID_T)0, NULLDYNST, NULLDYNST, &exchArgSt, &exchInstrEuro);	/* PMSTA01649 - TGU - 070402 */

                if (exchInstrEuro != (EXCHANGE_T) 0)
                {
                    SET_NUMBER(flowPtr, Flow_RefQty, exchInstrEuro);
                }
                else
                {
                    SET_NUMBER(flowPtr,       Flow_RefQty, 1);
                }

                SET_NUMBER(flowPtr,       Flow_QtyUnit,          1);

                SET_ENUM(flowPtr,         Flow_SubNatEn,         FlowSubNat_ConvExch);

                COPY_DYNFLD(flowPtr,      Flow,                  Flow_EuroConvRuleEn,
                            exchTab[i],   A_ExchEvt,             A_ExchEvt_EuroConvRuleEn);
                SET_ENUM(flowPtr,         Flow_RoundRuleEn,      RndRule_Down);

                if (IS_NULLFLD(exchTab[i], A_ExchEvt_NewInstrMinDenom) ||
                    GET_NUMBER(exchTab[i], A_ExchEvt_NewInstrMinDenom) == 0)
                {
                    if (IS_NULLFLD(newInstrPtr, A_Instr_FaceValue) ||
                        GET_PRICE(newInstrPtr, A_Instr_FaceValue) == 0)
                    {
                        SET_NUMBER(flowPtr,       Flow_NewInstrMinDenom, 1);
                    }
                    else
                    {
                        COPY_DYNFLD(flowPtr,      Flow,                  Flow_NewInstrMinDenom,
                                    newInstrPtr,  A_Instr,               A_Instr_FaceValue);
                    }
                }
                else
                {
                    COPY_DYNFLD(flowPtr,      Flow,                  Flow_NewInstrMinDenom,
                                exchTab[i],   A_ExchEvt,             A_ExchEvt_NewInstrMinDenom);
                }

                SET_ENUM(flowPtr,         Flow_OddLotCompEn,     OddLotComp_CashCompensationNew);
                SET_ENUM(flowPtr,         Flow_RoundLevelEn,     RndLevel_BottomUp);

                break;                
            }
            if (allocOk == TRUE) {FREE_DYNST(newInstrPtr, A_Instr);}
            (*flowNbr)++;
        }
        DBA_FreeDynStTab(exchTab, exchNbr, A_ExchEvt);

	    /* DDV - 990512 - No flow generate, free tab */
	    if (*flowNbr == 0)
	        FREE(*flowTab);
    }
    /* BUG2569 - AKO - 7/30/1998 */
    return(ret);
}

/************************************************************************
* 
*   Function          : FIN_MostProbableEvt()
*       
*   Description       : compute the more probable event between conversion and redemption at term date.
*                       
*                  
*   Arguments         : inputInstrPtr pointer on instrument struct or NULL  
*                       flowTab       pointer on flows array which will be 
*                                     allocated and filled up
*                                     (initialised to NULL by FIN_GenerateInstrFlows())
*                       flowNbr       pointer on flows number which will be
*                                     filled up 
*                                     (initialised to 0 by FIN_GenerateInstrFlows())
*                       valDateTime   ref.date of the domain
*                       hierHead      pointer on hierarchy
* 
*   Warning           : Calling function is FIN_GenerateInstrFlows()
* 
*   Return            : RET_SUCCEED or error code
* 
*
*   Creation    :   REF4075 - 991108 - CSY
*   Modification:   REF4075 - 991217 - CSY: Holder/Issuer, call redemptions
*                   REF4075 - 991222 - CSY  rename function
*                   REF4075 - 991222 - CSY  case where comparision is not possible
*
*************************************************************************/

RET_CODE FIN_MostProbableEvt(
		            DBA_DYNFLD_STP    instrPtr,
			        DBA_DYNFLD_STP    **flowTab,
                    int *flowNbr,
                    DATETIME_T     valDateTime,
                    DBA_HIER_HEAD_STP hierHead
			        )
{
	DBA_DYNFLD_STP   flowExch=NULLDYNST, flowRedm=NULLDYNST;
	RET_CODE         ret = RET_SUCCEED;
	int              i=0, j=0, iConv=-1, iRedm=-1, iFlowToDelete=-1; 
    NUMBER_T convVal=0, redmVal=0;
    DBA_DYNFLD_STP   convPricePtr=NULLDYNST;
    EXCHANGE_T       fxdExch = 0.0;
    FIN_EXCHARG_ST   exchArgSt;	
    FLAG_T found = FALSE;
    DATETIME_T     exchDateTime;

    memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));
	
    
    /* find and retrieve the exchange flow and the redemption flow from the flow tab */
    for (i=0;i<*flowNbr;i++)
    {
         /* look for the exchange flow : holder or issuer optional conversion */
         if ((((FLOWSUBNAT_ENUM)GET_ENUM((*flowTab)[i], Flow_SubNatEn) == FlowSubNat_OptConvHoldExch) ||
            ((FLOWSUBNAT_ENUM)GET_ENUM((*flowTab)[i], Flow_SubNatEn) == FlowSubNat_OptConvIssExch)))
            
         {
            flowExch = (*flowTab)[i];
            iConv = i;
         }
         
         /* look for the redemption flow : final, call or put redemption */
         if (GET_ENUM((*flowTab)[i], Flow_SubNatEn) == FlowSubNat_FinalRedm ||
             /* REF4075 - CSY - 991217: also if call or put redemption */
             GET_ENUM((*flowTab)[i], Flow_SubNatEn) == FlowSubNat_CallRedm ||
             GET_ENUM((*flowTab)[i], Flow_SubNatEn) == FlowSubNat_PutRedm)
         {
            flowRedm = (*flowTab)[i];
            iRedm = i;
         }
         
         /* exit the for loop as soon as the two flows to compare are found */
         if (flowExch != NULLDYNST && flowRedm != NULLDYNST)
         {
             break;
         }
    }

    /* get the conversion value: ratio * price of the new instrument  */
    if (flowExch != NULLDYNST)
    {
        if ((convPricePtr = ALLOC_DYNST(A_InstrPrice)) == NULLDYNST)
           MSG_RETURN(RET_MEM_ERR_ALLOC); 
        /* get the new instrument price at the ref date of the domain */
        ret = FIN_InstrPrice(GET_ID(flowExch, Flow_NewInstrId), NULL, valDateTime,
				         NULLDYNST, (ID_T)0, NULL, NULLDYNST, 
				         NULLDYNST, hierHead, convPricePtr, FALSE); /* PMSTA14876 - DDV - 120911 - Add a new parameter, no impact for this call */

        if (ret == RET_SUCCEED)
        {
            if (GET_NUMBER(flowExch, Flow_RefQty) != 0)
                convVal = ((GET_NUMBER(flowExch, Flow_QtyUnit)/GET_NUMBER(flowExch, Flow_RefQty))*
                        GET_PRICE(convPricePtr, A_InstrPrice_Price)); 
            else
                convVal=0;
        }
        else if (ret == RET_FIN_INFO_NOPRICE)
            /* no price found: send warning to server log */
            MSG_SendMesg(RET_FIN_ERR_INVDATA, 2, FILEINFO, "Instrument price", GET_CODE(instrPtr, A_Instr_Cd));
    }
    
    /* compute the redemption value */
    if (flowRedm != NULLDYNST)
        redmVal = GET_PRICE(flowRedm, Flow_AmtUnit);

    /* compare the redemption value and the conversion value */
    if ((flowRedm != NULLDYNST)&&(flowExch != NULLDYNST)) 
    {
        
        if (GET_ID(convPricePtr,A_InstrPrice_CurrId) != GET_ID(flowRedm, Flow_AmtCurrId))
        {
            /* convert the conversion amount into redemption currency */
            exchArgSt.srcAmt = (AMOUNT_T)convVal;
            if (FIN_GetExchRate(valDateTime, GET_ID(convPricePtr,A_InstrPrice_CurrId), 
			    GET_ID(flowRedm, Flow_AmtCurrId), 
			    0, NULLDYNST, NULLDYNST, &exchArgSt, &fxdExch) == RET_SUCCEED)	/* PMSTA01649 - TGU - 070405 */
            convVal = convVal *  fxdExch;
        }

        /* REF4075 - CSY - 991217: optional conversion may be holder or issuer */
        if ((GET_ENUM(flowExch, Flow_SubNatEn) == FlowSubNat_OptConvHoldExch && CMP_NUMBER(redmVal, convVal) > 0)||
            (GET_ENUM(flowExch, Flow_SubNatEn) == FlowSubNat_OptConvIssExch && CMP_NUMBER(redmVal, convVal) < 0))
            /* it's more interesting to redempt */
            iFlowToDelete = iConv;
        else if ((GET_ENUM(flowExch, Flow_SubNatEn) == FlowSubNat_OptConvHoldExch && CMP_NUMBER(redmVal, convVal) <= 0)||
            (GET_ENUM(flowExch, Flow_SubNatEn) == FlowSubNat_OptConvIssExch && CMP_NUMBER(redmVal, convVal) >= 0))
            /* it's more interesting to exchange (even if equals) */
            iFlowToDelete = iRedm;

        for (i=0; i< *flowNbr && found == FALSE; i++)
        {
            if (i==iFlowToDelete)
            {
                found = TRUE;
                /* we delete the less interesting flow from the array */
                FREE_DYNST((*flowTab)[i], Flow);
                (*flowNbr)--;
                for (j=i; j<*flowNbr; j++)
                {
                    (*flowTab)[j] = (*flowTab)[j+1];
                }
                i--; /* array has been shifted to left */
            }
        }

        /* now, if the best is exchange, we must delete all flows after the exchange date*/
        if (iFlowToDelete == iRedm)
        {
            exchDateTime = GET_DATETIME(flowExch, Flow_OptimalDate);
            for (i=0; i < *flowNbr; i++)
            {
                if (DATETIME_CMP(GET_DATETIME((*flowTab)[i], Flow_OptimalDate), exchDateTime) > 0)
                {
                    FREE_DYNST((*flowTab)[i], Flow);
                    (*flowNbr)--;
                    for (j=i; j<*flowNbr; j++)
                    {
                        (*flowTab)[j] = (*flowTab)[j+1];
                    }
                    i--; /* array has been shifted to left */
                }
            }
        }
    }
    else if (flowExch != NULLDYNST && flowRedm == NULLDYNST)
    {
        /* REF4075 - CSY - 991223: if comparision is not possible, (for examble:
         flowRedm is not created when FlowSubNat is different from FlowSubNat_CallRedm,
         FlowSubNat_PutRedm or FlowSubNat_FinalRedm.
         (FlowSubNat_SinkingRedm for example)) we delete the optional conversion */
        for (i=0; i< *flowNbr && found == FALSE; i++)
        {
            if (i==iConv)
            {
                found = TRUE;
                /* we delete the less interesting flow from the array */
                FREE_DYNST((*flowTab)[i], Flow);
                (*flowNbr)--;
                for (j=i; j<*flowNbr; j++)
                {
                    (*flowTab)[j] = (*flowTab)[j+1];
                }
                i--; /* array has been shifted to left */
            }
        }
    }

    FREE_DYNST(convPricePtr, A_InstrPrice);
    return(ret);
}

/********************************************************************************************
**
**  Function    : FIN_FloatingRateNoteFlows()
**
**  Description : Retrieves all possible future flows of a floating Rate Notes.
**                 
**  Arguments   : fromDateTime   reference date
**                tillDateTime   end date
**                inputInstrPtr  pointer on instrument struct or NULL
**                accrRule       accrual rule given to ACCR_INTER
**                flowTab        pointer on flows array which will be 
**                               allocated and filled up
**                               (initialised to NULL by FIN_GenerateInstrFlows())
**                flowNbr        pointer on flows number which will be
**                               filled up
**                               (initialised to 0 by FIN_GenerateInstrFlows())
**
**  Warning     : Calling function is FIN_GenerateInstrFlows()
**
**  Return      : RET_SUCCEED 
**                RET_MEM_ERR_ALLOC
**                RET_GEN_ERR_INVARG
**
**  Creation    : REF1055 - AKO - 991122
**  Modif.      : REF3990 - SSO - 000406 : modified ERROR MANAGEMENT !!! be careful if further modification 
**  Modif.      : REF7599 - YST - 020627 - compute flow event number
**                REF11218 - TEB - 050627
**
**********************************************************************************************/
RET_CODE FIN_FloatingRateNoteFlows(DATETIME_T           fromDateTime,  
                                    DATETIME_T          tillDateTime,
                                    DATETIME_T          valDateTime,
                                    DBA_DYNFLD_STP      instrPtr,
                                    EVTDATERULE_ENUM    evtDateRule, /* REF4075 - CSY - 991027 */
									ACCRRULE_ENUM       accrRule,	 /* REF11218 - TEB - 050627 */
                                    DBA_DYNFLD_STP      **flowTab,
                                    int                 *flowNbr, 
                                    DBA_HIER_HEAD_STP    hierHead)
{
	int		    i = 0, currentPeriod = 0;
	RET_CODE 	ret;
	DATETIME_T  exchEvttillDateTime;
	int         allocSz=0;


	exchEvttillDateTime=tillDateTime;
    FIN_CreateExchangeFlows(instrPtr, fromDateTime, &exchEvttillDateTime, valDateTime, 
                            evtDateRule, &allocSz, flowNbr, flowTab, hierHead); 

	/* Allocate flowTab (size flowNbr) and init fields :                                  */
	/* Flow_Quote (coupon), Flow_AmtUnit  (coupon/100.0)                                  */
	/* Flow_BegPayDate Flow_EndPayDate Flow_OptimalDate Flow_OptimalValDate (coupon date) */
	/* REF7599 - YST - 020627 - add new argument */
	ret = SCE_CallFRN_GenrPeriod(GET_ID(instrPtr, A_Instr_Id), instrPtr, hierHead,
				                fromDateTime, exchEvttillDateTime, valDateTime, accrRule, /* REF11218 - TEB - 050627 */
								&allocSz, flowTab, flowNbr, &currentPeriod);

	if (ret == RET_SUCCEED)
	{
	    for (i=0; i<*flowNbr; i++)
	    {
		if ( (GET_ENUM((*flowTab)[i],Flow_NatEn) == FlowNat_Redm) || 
		    (GET_ENUM((*flowTab)[i],Flow_NatEn) == FlowNat_Inc))
		{
		    SET_ID((*flowTab)[i],		    Flow_InstrId,   GET_ID(instrPtr, A_Instr_Id));
		    SET_ID((*flowTab)[i],		    Flow_AmtCurrId, GET_ID(instrPtr, A_Instr_RefCurrId));
		    SET_INT((*flowTab)[i],	    	Flow_EvtNbr,    currentPeriod+i); /* REF7599 - YST - 020627 */ /* REF8844 - LJE - 030327 */
		    SET_FLAG((*flowTab)[i],		    Flow_ConfirmedFlg, TRUE);
		    SET_PERIOD((*flowTab)[i],		    Flow_SettlDays,    0);
		    SET_FLAG((*flowTab)[i],		    Flow_PhysicalFlg,  FALSE);
		    SET_FLAG((*flowTab)[i],		    Flow_EffectiveFlg, FALSE);	
		    SET_FLAG((*flowTab)[i],		    Flow_ReplaceFlg,   FALSE);
		    SET_PERCENT((*flowTab)[i],		    Flow_Proba,        100.0);
		    SET_NULL_EXCHANGE((*flowTab)[i],	    Flow_FxdExchRate);
		    SET_NULL_PERIOD((*flowTab)[i],	    Flow_IoRPrct);
		    SET_NULL_ID((*flowTab)[i],		    Flow_NewInstrId);
		    SET_NULL_NUMBER((*flowTab)[i],	    Flow_QtyUnit);
		    SET_NULL_ENUM((*flowTab)[i],	    Flow_OptClassEn);
		    SET_NULL_ENUM((*flowTab)[i],	    Flow_OptStyleEn);
		    SET_NULL_DATE((*flowTab)[i],	    Flow_ExDate);
		    SET_NULL_NUMBER((*flowTab)[i],	    Flow_CtdConvFact);
		    SET_NULL_NUMBER((*flowTab)[i],	    Flow_CtdConvRatio); 
		    SET_NULL_ID((*flowTab)[i],		    Flow_CtdInstrId);
		    SET_NULL_TINYINT((*flowTab)[i],	    Flow_Priority);
		}
	    }
	}

	RET_GENFLOWS(ret);    /* REF3990 - SSO - 000406 */
}

/****************************************************************************************
* 
*   Function          : FIN_ExoticOptionFlows FIN_OptionFlows()
*       
*   Description       : Retrieves all possible future flows of an exotic option.
*                       Use term contract events from the begin reference data
*                       to the ende reference date and fill flow structure.
*                  
*   Arguments         : fromDateTime  from date
*                       tillDateTime  end date
*                       valDateTime   
*                       inputInstrPtr pointer on instrument struct or NULL  
*                       evtDateRule   enum used in event generation domain 
*				      to specify the event operation date rule
*                       flowTab       pointer on flows array which will be 
*                                     allocated and filled up
*                                     (initialised to NULL by FIN_GenerateInstrFlows())
*                       flowNbr       pointer on flows number which will be
*                                     filled up 
*                                     (initialised to 0 by FIN_GenerateInstrFlows())
* 
*   Warning           : Calling function is FIN_GenerateInstrFlows()
* 
*   Return            : RET_SUCCEED or error code
*
*   modification      : REF1055 - AKO - 991125
*						New sub-nature need to be ignored - PMSTA-21039 - SHR - 153010
*  
*******************************************************************************************/
RET_CODE FIN_ExoticOptionFlows(DATETIME_T           fromDateTime,  
                                DATETIME_T		    tillDateTime,
                                DATETIME_T		    valDateTime,
                                DBA_DYNFLD_STP		instrPtr,
                                EVTDATERULE_ENUM	evtDateRule,
                                DBA_DYNFLD_STP		**flowTab,
                                int			        *flowNbr,
                                DBA_HIER_HEAD_STP	hierHead)
{
    RET_CODE        retCd=RET_SUCCEED;
    SUBNAT_ENUM     instrSubNat;

    instrSubNat = (SUBNAT_ENUM) GET_ENUM(instrPtr, A_Instr_SubNatEn);
    switch(instrSubNat)
    {
	case SubNat_Chooser:
	case SubNat_ForwardStart:
	case SubNat_StrikeLookback:
	case SubNat_RateLookback:
	case SubNat_AvrgStrikeAsian:
	case SubNat_AvrgRateAsian:
	case SubNat_Compound:
	case SubNat_Contingent:
	case SubNat_Accumulator:
	case SubNat_Decumulator:
	case SubNat_MiniFuturesTurbo:
	case SubNat_BasketOption:
	case SubNat_StructuredOption:
	case SubNat_DoubleKnockIn:
	case SubNat_KnockInKnockOut:
	case SubNat_PivotOption:
	case SubNat_DigitalPayOut:
	case SubNat_ParticipatingForward:
	case SubNat_TargetKnockOutForward:
	case SubNat_TargetKnockOutPivotNotes:
    case SubNat_DualCurrencyInvest:
    case SubNat_TripleCurrencyInvest:
	    retCd = FIN_OptMultiNatExoticFlows(fromDateTime, tillDateTime, valDateTime,
			      	                instrPtr, evtDateRule, flowTab, flowNbr, hierHead); 
	    break;
	case SubNat_OneTouchDigital:
    case SubNat_Barrier:
	case SubNat_Binary:
	case SubNat_DoubleKnockOut:
	    FIN_OptExoticPayOffFlows(fromDateTime, tillDateTime, valDateTime,
			      	    instrPtr, evtDateRule, flowTab, flowNbr, hierHead); 
	    break;
	case SubNat_None:
	default:
	    return(retCd);
    }
    return(retCd);
}

/****************************************************************************************
*
*   Function          : FIN_STNOptionBasedRiskCompoSortInstrEndD()
*
*   Description       : Sort instrument compo by dates
*
*   Arguments         : compo[0]
*                       compo[1]
*
*   Return            : -1 or 0 or 1
*
*   modification      : PMSTA-34288 - CHU - 190113
*
*******************************************************************************************/
STATIC int FIN_STNOptionBasedRiskCompoSortInstrEndD(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
	int diff = CMP_DYNFLD(*ptr1, *ptr2, A_InstrCompo_BeginDate, A_InstrCompo_BeginDate, DateType);
	if (diff == 0)
		diff = CMP_DYNFLD(*ptr1, *ptr2, A_InstrCompo_EndDate, A_InstrCompo_EndDate, DateType);
	return(diff);
}

/****************************************************************************************
*
*   Function          : FIN_STNOptionBasedCompoTermEvtInfo()
*
*   Description       : Retrieves all instrument compositions and term events of an exotic option.
*                       Sort Term events by date and filter based on domain dates.
*
*   Arguments         : hierHead                hierarchy pointer
*                       instrPtr                exotic option instrument pointer
*                       domainPtr               domain pointer
*                       compo[Tab|Nbr]          returned array of instrument composition
*                       termEvt[Tab|Nbr]        returned array of term events linked to instrument compositions
*                       cunderInstr[Tab|Nbr]    returned array of instrument record pointers from thei id's in compositions
*
*   Return            : RET_SUCCEED or error code
*
*   modification      : PMSTA-34288 - CHU - 190113
*
*******************************************************************************************/
RET_CODE FIN_STNOptionBasedCompoTermEvtInfo(DBA_HIER_HEAD_STP hierHead,
                                            DBA_DYNFLD_STP    instrPtr,
                                            DBA_DYNFLD_STP    domainPtr,
                                            DBA_DYNFLD_STP    **compoTab,
                                            int               *compoNbr,
                                            DBA_DYNFLD_STP    **termEvtTab,
                                            int               *termEvtNbr,
                                            DBA_DYNFLD_STP    **underInstrTab,
                                            int               *underInstrNbr)
{
    RET_CODE		ret = RET_SUCCEED;    
    NUMBER_T		lifeTime = 1.0;
    FLAG_T			allocFlg = FALSE;
    int				i, settlementNbr, lifeNbr, compo_size;
    double			freq = 0.0;
    DATE_T			prevSettlementDate, begDate;
    DATETIME_T      compoBegDate; /* PMSTA-34288 - CHU - 190202 */
    long			endBeg, endSet;
    MemoryPool      mp;

    if (InstrumentNature::isDualCurrencyInvestMoneyMarket(instrPtr) ||  /* PMSTA-34288 - CHU - 190202 */
        InstrumentNature::isTripleCurrencyInvestMoneyMarket(instrPtr))  /* PMSTA-34288 - CHU - 190202 */
    {
        compoBegDate = GET_DATETIME(instrPtr, A_Instr_BeginDate);

        /* < PMSTA-34885 - CHU - 190322 : if instrument begin date returns no compo, try with domain from date */
        if ((ret = DBA_SelectInstrCompo(GET_ID(instrPtr, A_Instr_Id), compoBegDate, compoTab, compoNbr)) != RET_SUCCEED)
        {
            return(ret);
        }

        if (*compoNbr == 0) 
        {
            compoBegDate = GET_DATETIME(domainPtr, A_Domain_InterpFromDate);
            if ((ret = DBA_SelectInstrCompo(GET_ID(instrPtr, A_Instr_Id), compoBegDate, compoTab, compoNbr)) != RET_SUCCEED)
            {
                return(ret);
            }
        }
        /* > PMSTA-34885 - CHU - 190322 */
    }
    else
    {
        compoBegDate = GET_DATETIME(domainPtr, A_Domain_InterpFromDate);
        if ((ret = DBA_SelectInstrCompo(GET_ID(instrPtr, A_Instr_Id), compoBegDate, compoTab, compoNbr)) != RET_SUCCEED)
        {
            return(ret);
        }
    }

    if ((InstrumentNature::isParticipatingForward(instrPtr)             ||
         InstrumentNature::isTargetKnockOutForward(instrPtr)            ||
         InstrumentNature::isDualCurrencyInvestMoneyMarket(instrPtr)    ||  /* PMSTA-34288 - CHU - 190202 */
         InstrumentNature::isTripleCurrencyInvestMoneyMarket(instrPtr)) &&  /* PMSTA-34288 - CHU - 190202 */
        *compoNbr == 0)
    {
        *termEvtNbr = 0;
        *underInstrNbr = 0;
        return(ret);
    }

    compo_size = MAX(*compoNbr, 1);

	TLS_Sort((char*)*compoTab, *compoNbr, sizeof(DBA_DYNFLD_STP), (TLS_CMPFCT *)FIN_STNOptionBasedRiskCompoSortInstrEndD, (PTR **)NULL, SortRtnTp_None);

    /* Start at end date of instrument */
    prevSettlementDate = GET_DATE(instrPtr, A_Instr_EndDate);
    begDate = prevSettlementDate;
    settlementNbr = 0;
    lifeNbr = 1;

    if (!InstrumentNature::isDualCurrencyInvestMoneyMarket(instrPtr) &&  /* PMSTA-34288 - CHU - 190202 */
        !InstrumentNature::isTripleCurrencyInvestMoneyMarket(instrPtr) &&
        !InstrumentNature::isAccumulator(instrPtr) &&
        !InstrumentNature::isDecumulator(instrPtr) &&  /* PMSTA-34288 - CHU - 190202 */
        IS_NULLFLD(instrPtr, A_Instr_PayFreq) == FALSE)
    {
        /* First know the current settlement date and compute settlement current number */
        FIN_PeriodUnitNbr((FREQUNIT_ENUM)GET_ENUM(instrPtr, A_Instr_PayFreqUnitEn),
            GET_TINYINT(instrPtr, A_Instr_PayFreq), FreqUnit_Month, &freq);

        if (GET_TINYINT(instrPtr, A_Instr_PayFreq) == Week) /* PMSTA-61236 - Deepthi - 20241028 */
        {
            freq = Week;
        }

        freq *= -1;

        while (prevSettlementDate > GET_DATE(domainPtr, A_Domain_InterpFromDate) && prevSettlementDate > GET_DATE(instrPtr, A_Instr_BeginDate))
        {
            if (GET_TINYINT(instrPtr, A_Instr_PayFreq) == Week) /* PMSTA-61236 - Deepthi - 20241028 */
            {
                begDate = DATE_Move(prevSettlementDate, (int)freq, Week);
            }
            else
                begDate = DATE_Move(prevSettlementDate, (int)freq, Month);

            prevSettlementDate = begDate;

            if (prevSettlementDate >= GET_DATE(domainPtr, A_Domain_InterpFromDate))
                prevSettlementDate++;
            lifeNbr++;
        }

        /* TO DO rem not sure of the settlementNbr as start at the end .... */
        settlementNbr = lifeNbr - settlementNbr;
    }

    *termEvtTab = (DBA_DYNFLD_STP *)CALLOC(compo_size, sizeof(DBA_DYNFLD_STP));
    *underInstrTab = (DBA_DYNFLD_STP *)CALLOC(compo_size, sizeof(DBA_DYNFLD_STP));

    DBA_DYNFLD_STP  getData = mp.allocDynst(FILEINFO, Evt_Arg);
    SET_DATE(getData, Evt_Arg_ValidDate, /* GET_DATE(domainPtr, A_Domain_InterpFromDate) */ compoBegDate.date);

	for (i = 0; i < compo_size; i++)
	{
        if (*compoNbr > 0)
        {
            if ((ret = DBA_GetInstrById(GET_ID((*compoTab)[i], A_InstrCompo_InstrId),
                TRUE, &allocFlg, &(*underInstrTab)[i], hierHead,	/* add in hier, no free */
                UNUSED, UNUSED)) != RET_SUCCEED)
            {
                return(ret);
            }
            (*underInstrNbr)++;
        }
        else
        {
            (*underInstrTab)[i] = instrPtr;

            /* PMSTA-34990 - CHU - 190325 : Get underlying prices */
            if (InstrumentNature::isAccumulator(instrPtr) ||
                InstrumentNature::isDecumulator(instrPtr))
            {
                DBA_SelectUnderlyingPrices(hierHead, domainPtr, (*underInstrTab)[i], nullptr, nullptr);	/* PMSTA-35262 - RAK - 190708 - Use default domain dates */
            }
        }

        if (InstrNat_MoneyMkt != (INSTRNAT_ENUM)GET_ENUM((*underInstrTab)[i], A_Instr_NatEn)) /* PMSTA-34288 - CHU - 190202 : term_event only for Options */
        {
            (*termEvtTab)[(*termEvtNbr)] = ALLOC_DYNST(A_TermEvt);

            if (GET_ID((*underInstrTab)[i], A_Instr_Id) < 0)
            {
                SET_ID(getData, Evt_Arg_InstrId, GET_ID((*underInstrTab)[i], A_Instr_ParentInstrId));
            }
            else
            {
                SET_ID(getData, Evt_Arg_InstrId, GET_ID((*underInstrTab)[i], A_Instr_Id));
            }

            if ((ret = DBA_Get2(TermEvt, UNUSED, Evt_Arg, getData, A_TermEvt, &(*termEvtTab)[(*termEvtNbr)], UNUSED, UNUSED, UNUSED)) != RET_SUCCEED)
            {
                /* < PMSTA-34885 - CHU - 190301 */
                if (((*termEvtTab)[(*termEvtNbr)] = ALLOC_DYNST(A_TermEvt)) == NULLDYNST)
                    MSG_RETURN(RET_MEM_ERR_ALLOC);
                if ((ret = DBA_GetTermEvt((*underInstrTab)[i], compoBegDate.date, (*termEvtTab)[(*termEvtNbr)])) != RET_SUCCEED)
                {
                    if (*compoNbr > 0)
                    {
                        for (i = 0; i < *compoNbr; i++) { FREE_DYNST((*compoTab)[i], A_InstrCompo); }
                        FREE(*compoTab);
                        *compoNbr = 0;
                    }
                    return(ret);
                }
                /* > PMSTA-34885 - CHU - 190301 */
            }

            if (IS_NULLFLD(instrPtr, A_Instr_PayFreq) == TRUE)
            {
                /* Start at end date of instrument */
                prevSettlementDate = GET_DATE(instrPtr, A_Instr_EndDate);
                begDate = prevSettlementDate;
                settlementNbr = 0;
                lifeNbr = 1;

                if (!InstrumentNature::isDualCurrencyInvestMoneyMarket(instrPtr) &&  /* PMSTA-34288 - CHU - 190202 */
                    !InstrumentNature::isTripleCurrencyInvestMoneyMarket(instrPtr) &&
                    !InstrumentNature::isAccumulator(instrPtr) &&
                    !InstrumentNature::isDecumulator(instrPtr))  /* PMSTA-34288 - CHU - 190202 */
                {
                    if (IS_NULLFLD((*underInstrTab)[i], A_Instr_PayFreq) == FALSE)
                    {
                        FIN_PeriodUnitNbr((FREQUNIT_ENUM)GET_ENUM((*underInstrTab)[i], A_Instr_PayFreqUnitEn),
                            GET_TINYINT((*underInstrTab)[i], A_Instr_PayFreq),
                            FreqUnit_Month, &freq);

                        if (GET_TINYINT((*underInstrTab)[i], A_Instr_PayFreq) == Week) /* PMSTA-61236 - Deepthi - 20241028 */
                            freq = Week * -1;
                    }
                    else if (IS_NULLFLD((*termEvtTab)[(*termEvtNbr)], A_TermEvt_Freq) == FALSE)
                    {
                        FIN_PeriodUnitNbr((FREQUNIT_ENUM)GET_ENUM((*termEvtTab)[(*termEvtNbr)], A_TermEvt_FreqUnitEn),
                            GET_TINYINT((*termEvtTab)[(*termEvtNbr)], A_TermEvt_Freq),
                            FreqUnit_Month, &freq);
                    }
                    else
                    {
                        freq = 1.0;
                    }

                    while (prevSettlementDate > GET_DATE(domainPtr, A_Domain_InterpFromDate) && prevSettlementDate > GET_DATE(instrPtr, A_Instr_BeginDate))
                    {
                        /* PMSTA-61236 - Deepthi - 20241028 */
                        if (GET_TINYINT((*underInstrTab)[i], A_Instr_PayFreq) == Week)
                        {
                            begDate = DATE_Move(prevSettlementDate, (int)freq, Week);
                        }
                        else
                            begDate = DATE_Move(prevSettlementDate, (int)freq, Month);

                        prevSettlementDate = begDate;

                        if (prevSettlementDate >= GET_DATE(domainPtr, A_Domain_InterpFromDate))
                            prevSettlementDate++;
                        lifeNbr++;
                    }

                    /* TO DO rem not sure of the settlementNbr as start at the end .... */
                    settlementNbr = lifeNbr - settlementNbr;
                }
            }

#if 0
/* Pr�matur�... let's not delete the Term Event right now */
            /* Knock-in purpose */
            if (!IS_NULLFLD((*termEvtTab)[(*termEvtNbr)], A_TermEvt_Barrier) &&
                !InstrumentNature::isDualCurrencyInvestMoneyMarket(instrPtr) &&  /* PMSTA-34288 - CHU - 190202 */
                !InstrumentNature::isTripleCurrencyInvestMoneyMarket(instrPtr))
            {
                if (IS_NULLFLD(instrPtr, A_Instr_KnockInDate)) /* not yet started */
                {
                    (*termEvtTab)[(*termEvtNbr)] = NULL; /* En gros, c'est �a... */
                    (*termEvtNbr)--;
                }
            }

            /* Knock-out purpose and knock-out date occurs before computation date */
            if (!IS_NULLFLD((*termEvtTab)[(*termEvtNbr)], A_TermEvt_UpperBarrier) &&
                !InstrumentNature::isDualCurrencyInvestMoneyMarket(instrPtr) &&  /* PMSTA-34288 - CHU - 190202 */
                !InstrumentNature::isTripleCurrencyInvestMoneyMarket(instrPtr))
            {
                if (!IS_NULLFLD(instrPtr, A_Instr_KnockOutDate) &&
                    GET_DATE(instrPtr, A_Instr_KnockOutDate) < GET_DATE((*termEvtTab)[i], A_TermEvt_EndDate)) /* expired */
                {
                    (*termEvtTab)[(*termEvtNbr)] = NULL; /* En gros, c'est �a... */
                    (*termEvtNbr)--;
                }
            }
#endif

            /* Quantity = If total_qty_n is  in term event use it, otherwise use the quantity of call/put instrument * no of settlement periods */
            if (*compoNbr > 0)
            {
                if (!IS_NULLFLD((*termEvtTab)[(*termEvtNbr)], A_TermEvt_TotalQty))
                {
                    SET_NUMBER((*compoTab)[i], A_InstrCompo_Quantity, GET_NUMBER((*termEvtTab)[(*termEvtNbr)], A_TermEvt_TotalQty));
                }
                else
                {
                    /* no previous settlement date -> 1 */
                    if (settlementNbr == 0) settlementNbr = 1;

                    SET_NUMBER((*compoTab)[i], A_InstrCompo_Quantity, GET_NUMBER((*underInstrTab)[i], A_Instr_UnderlyQty) * settlementNbr);
                }
            }

            /* Compute lifetime */
            /* settlement date is : previous settlement date of current date (or current date) or begin date of instrument */
            if (prevSettlementDate < GET_DATE((*underInstrTab)[i], A_Instr_BeginDate))
                lifeTime = 1.0;
            else
            {
                DATE_DaysBetween(GET_DATE((*underInstrTab)[i], A_Instr_EndDate), GET_DATE((*underInstrTab)[i], A_Instr_BeginDate), AccrRule_30E_360, &endBeg, 0);
                DATE_DaysBetween(GET_DATE((*underInstrTab)[i], A_Instr_EndDate), prevSettlementDate, AccrRule_30E_360, &endSet, 0);
                lifeTime = (double)endSet / (double)endBeg;
            }

            if (*compoNbr > 0)
            {
                SET_NUMBER((*compoTab)[i], A_InstrCompo_Quantity, lifeTime * GET_NUMBER((*compoTab)[i], A_InstrCompo_Quantity));

                /* Strange the quote is displayed and use to fill the price/quote ... so update this field (instead of use a new one) */
                SET_PRICE((*compoTab)[i], A_InstrCompo_BasketExerPrice, GET_PRICE((*termEvtTab)[(*termEvtNbr)], A_TermEvt_ExerQuote));

                /* short put : negativ */
                if (GET_ENUM((*termEvtTab)[(*termEvtNbr)], A_TermEvt_OptionClassEn) == OptClass_Put &&
                    GET_ENUM((*termEvtTab)[(*termEvtNbr)], A_TermEvt_PayOffNatEn) == TermEvt_Payoff_Short)
                {
                    SET_NUMBER((*compoTab)[i], A_InstrCompo_Quantity, -1.0 * GET_NUMBER((*compoTab)[i], A_InstrCompo_Quantity));
                }
            }

            /* PMSTA-34990 - CHU - 190327 : Get prices also for underlying instrument defined in the term event */
            if ((InstrumentNature::isAccumulator(instrPtr) ||
                InstrumentNature::isDecumulator(instrPtr)) &&
                IS_NULLFLD((*termEvtTab)[(*termEvtNbr)], A_TermEvt_UnderlyInstrId) == FALSE)
            {
                DBA_DYNFLD_STP termEvtUnderInstr;
                if ((ret = DBA_GetInstrById(GET_ID((*termEvtTab)[(*termEvtNbr)], A_TermEvt_UnderlyInstrId),
                                            TRUE, &allocFlg, &termEvtUnderInstr, hierHead,	/* add in hier, no free */
                    UNUSED, UNUSED)) != RET_SUCCEED)
                {
                    return(ret);
                }

				DBA_SelectUnderlyingPrices(hierHead, domainPtr, termEvtUnderInstr, nullptr, nullptr); /* PMSTA-35262 - RAK - 190708 - Use default domain dates */
            }

            (*termEvtNbr)++;
        }
	}

	return(ret);
}

/****************************************************************************************
*
*   Function          : FIN_ComputeFlowForPartFwdAndTarko()
*
*   Description       : Update flow with specific computation for Structured Product based on Exotic Options
*                       (Participating Forward & TARKO)
*
*   Arguments         : hierHead        hierarchy pointer
*                       currInstrPtr    instrument from compo related to main instrument
*                       termEvtSt       term_event related the the above instrument
*                       flowSt          current flow record to update
*                       begDate         computed begin date
*                       endDate         computed end date
*
*   Return            : RET_SUCCEED or Error
*
*   modification      : PMSTA-34288 - CHU - 190113
*
*******************************************************************************************/
STATIC RET_CODE FIN_ComputeFlowForPartFwdAndTarko(DBA_HIER_HEAD_STP    hierHead,
                                                  DBA_DYNFLD_STP       instrPtr,    /* PMSTA-35432- CHU - 190404 */
                                                  DBA_DYNFLD_STP       currInstrPtr,
                                                  DBA_DYNFLD_STP       termEvtSt,
                                                  DBA_DYNFLD_STP       flowSt,
                                                  DATETIME_T           begDate,
                                                  DATETIME_T           endDate,
                                                  bool                 *bDeleteFlow)
{
    RET_CODE ret = RET_SUCCEED;
    NUMBER_T flowFxdExchRate = 1.0;

    /*
    * Same computation for both Call/TermEvt_Payoff_Long && Put/TermEvt_Payoff_Short... !?
    */
    if ((OptClass_Call == GET_ENUM(termEvtSt, A_TermEvt_OptionClassEn) ||
        OptClass_Put == GET_ENUM(termEvtSt, A_TermEvt_OptionClassEn)) &&
        TermEvt_Payoff_Vanilla == GET_ENUM(termEvtSt, A_TermEvt_PayOffNatEn))
    {
        SET_PRICE(flowSt, Flow_AmtUnit, GET_PRICE(termEvtSt, A_TermEvt_ExerQuote));
        if (CMP_ID(GET_ID(termEvtSt, A_TermEvt_CurrId), GET_ID(termEvtSt, A_TermEvt_UnderlyInstrId)) != 0)
        {
            SET_ID(flowSt, Flow_AmtCurrId, GET_ID(termEvtSt, A_TermEvt_UnderlyInstrId));
            flowFxdExchRate = GET_EXCHANGE(currInstrPtr, A_Instr_RedempPrice);
        }
        SET_EXCHANGE(flowSt, Flow_FxdExchRate, flowFxdExchRate);
    }
    else
    {
        /* PMSTA-35500 - CHU - 190503 : Not for Vanilla */
        /* PMSTA-34288 - CHU - 190224 : F�roce le Rhino ! il pique les fonctions � RAK... */
        /* PMSTA-34140 - RAK - 190131 - Verify if we create flow (Knock-out and knock-in purpose) */
        if (FIN_STNKnockInStarted(endDate.date, termEvtSt, /* instrPtr */ currInstrPtr) == FALSE || /* PMSTA-35432- CHU - 190404 */ /* PMSTA-35432- CHU - 190415 */
            FIN_STNKnockOutExpired(endDate.date, termEvtSt, /* instrPtr */ currInstrPtr) == TRUE)   /* PMSTA-35432- CHU - 190404 */ /* PMSTA-35432- CHU - 190415 */
        {
            *bDeleteFlow = true;
            return(ret);
        }

        /*
        Quantity for each settlement day starting from the knock-in date to Final date
        (a) = Underlying quantity (underly_qty_n)
        Cash Flows (b) = (a) * exercise quote (exer_quote_n) * -1
        */
        /* < PMSTA-34885 - CHU - 190301 */
        if ((OptClass_Call == GET_ENUM(termEvtSt, A_TermEvt_OptionClassEn) ||
            TermEvt_Payoff_Long == GET_ENUM(termEvtSt, A_TermEvt_PayOffNatEn))
            ||
            (OptClass_Put == GET_ENUM(termEvtSt, A_TermEvt_OptionClassEn) ||
                TermEvt_Payoff_Short == GET_ENUM(termEvtSt, A_TermEvt_PayOffNatEn)))
        { /* > PMSTA-34885 - CHU - 190301 */
            SET_PRICE(flowSt, Flow_AmtUnit, GET_PRICE(termEvtSt, A_TermEvt_ExerQuote));
            if (CMP_ID(GET_ID(termEvtSt, A_TermEvt_CurrId), GET_ID(termEvtSt, A_TermEvt_UnderlyInstrId)) != 0)
            {
                SET_ID(flowSt, Flow_AmtCurrId, GET_ID(termEvtSt, A_TermEvt_UnderlyInstrId));
                flowFxdExchRate = GET_EXCHANGE(currInstrPtr, A_Instr_RedempPrice);
            }
            SET_EXCHANGE(flowSt, Flow_FxdExchRate, flowFxdExchRate);
        }
    }
    return (ret);
}

/****************************************************************************************
*
*   Function          : FIN_ComputeFlowForACDC()
*
*   Description       : Update flow with specific computation for Structured Product based on Exotic Options
*                       (Accumulator & Decumulator)
*
*   Arguments         : hierHead        hierarchy pointer
*                       currInstrPtr    instrument from compo related to main instrument
*                       termEvtSt       term_event related the the above instrument
*                       flowSt          current flow record to update
*                       begDate         computed begin date
*                       endDate         computed end date
*
*   Return            : RET_SUCCEED or Error
*
*   creation          : PMSTA-34288 - CHU - 190113
*
*   modification      : PMSTA-34990 - CHU - 190313 Rewrote dates management and computations
*
*******************************************************************************************/
STATIC RET_CODE FIN_ComputeFlowForACDC(DBA_HIER_HEAD_STP    hierHead,
                                       DBA_DYNFLD_STP       instrPtr,
                                       DBA_DYNFLD_STP       currInstrPtr,
                                       DBA_DYNFLD_STP       termEvtSt,
                                       DBA_DYNFLD_STP       flowSt,
                                       DATETIME_T           begDate,
                                       DATETIME_T           endDate,
                                       DATETIME_T           fixingBegDate,  /* PMSTA-35432- CHU - 190404 */
                                       DATETIME_T           fixingEndDate,  /* PMSTA-35432- CHU - 190404 */
                                       bool                 *bDeleteFlow,
                                       bool                 bCompoundFrequencyActivated, /* PMSTA-35455 - CHU - 190701 */
                                       DATETIME_T           compoundDate,   /* PMSTA-35455 - CHU - 190701 */
                                       double               compFreq,       /* PMSTA-35455 - CHU - 190702 */
                                       DATE_UNIT_ENUM       compDayUnit)   /* PMSTA-35455 - CHU - 190702 */
{
    RET_CODE            ret = RET_SUCCEED;
    DBA_DYNFLD_STP      pricePtr, underlyingInstrPtr;
    ID_T                calendarId = (ID_T)-1;
    DATETIME_T          knockInDate, knockOutDate, protectedDate, currentDate, getPriceDateTime, localCompoundDate;
    const SUBNAT_ENUM   subnatEn = (SUBNAT_ENUM)GET_ENUM(currInstrPtr, A_Instr_SubNatEn);

    bool                bKnockedIn = false,
                        bCurrentMonthKnockedIn = false,
                        bCurrentMonthKnockedOut = false,
                        bCurrentDateInPast = false,
                        bCurrentDateInBetween = false,
                        bCurrentDateInFuture = false;

    const NUMBER_T      underlyingQty = GET_NUMBER(termEvtSt, A_TermEvt_UnderlyQty);
    const PRICE_T      exercisePrice = GET_PRICE(termEvtSt, A_TermEvt_ExerQuote);
    const NUMBER_T      gearing = GET_NUMBER(termEvtSt, A_TermEvt_Leverage);

    long                nbTradingDaysWithGearing = 0,                           /* PMSTA-35384 - CHU - 190403 */
                        nbTradingDaysWithoutGearing = 0;                        /* PMSTA-35384 - CHU - 190403 */

    MemoryPool          mp;
    FLAG_T              allocOk = FALSE, isBusinessDateFlg = FALSE;

    bool                bDebugLog = false;

    if (DATE_Cmp(begDate.date, endDate.date) == 0)
    {
        *bDeleteFlow = true;
        return(ret);
    }

    currentDate.date = DATE_CurrentDate();
    knockInDate.date = knockOutDate.date = protectedDate.date = getPriceDateTime.date = 0;
    knockInDate.time = knockOutDate.time = protectedDate.time = currentDate.time = getPriceDateTime.time = 0;
    localCompoundDate = compoundDate;

    knockInDate.date = GET_DATE(currInstrPtr, A_Instr_KnockInDate);
    if (DATE_Cmp(knockInDate.date, endDate.date) <= 0)
    {
        bKnockedIn = true;
    }
    else
    {
        /* NOT YET KNOCKED-IN : destroy flow */
        *bDeleteFlow = true;
        if (bDebugLog)
        {
            MSG_LogSrvMesg(UNUSED, 0, "FIN_ComputeFlowForACDC() : NOT YET KNOCKED-IN : destroying flow");
        }
        return(ret);
    }

    if (DATE_Cmp(knockInDate.date, begDate.date) >= 0 &&
        DATE_Cmp(knockInDate.date, endDate.date) <= 0)
    {
        bCurrentMonthKnockedIn = true;
    }

    if (FALSE == IS_NULLFLD(currInstrPtr, A_Instr_KnockOutDate))
    {
        knockOutDate.date = GET_DATE(currInstrPtr, A_Instr_KnockOutDate);
        if (DATE_Cmp(begDate.date, knockOutDate.date) > 0 &&
            DATE_Cmp(endDate.date, knockOutDate.date) >= 0 &&
            DATE_Cmp(fixingEndDate.date, knockOutDate.date) >= 0) /* PMSTA-35461 - CHU - 190513 */ 
        {
            /* ALREADY KNOCKED OUT Before begin & End dates : destroy flow */
            *bDeleteFlow = true;
            if (bDebugLog)
            {
                MSG_LogSrvMesg(UNUSED, 0, "FIN_ComputeFlowForACDC() : ALREADY KNOCKED OUT Before begin & End dates : destroying flow");
            }
            return(ret);
        }

        if (DATE_Cmp(begDate.date, knockOutDate.date) <= 0 &&
            DATE_Cmp(knockOutDate.date, endDate.date) <= 0 &&
            DATE_Cmp(knockOutDate.date, fixingEndDate.date) <= 0) /* PMSTA-35461 - CHU - 190513 */
        {
            bCurrentMonthKnockedOut = true;
        }
    }

    if (TRUE == IS_NULLFLD(termEvtSt, A_TermEvt_UnderlyInstrId))
    {
        *bDeleteFlow = true;
        if (bDebugLog)
        {
            MSG_LogSrvMesg(UNUSED, 0, "FIN_ComputeFlowForACDC() : Underlying instrument not defined in term_event record : destroying flow");
        }
        return(ret);
    }
    DBA_GetInstrById(GET_ID(termEvtSt, A_TermEvt_UnderlyInstrId), FALSE, &allocOk, &underlyingInstrPtr, hierHead, UNUSED, UNUSED);
    if (allocOk == TRUE) { mp.owner(underlyingInstrPtr); }

    /* CHECK LOCATION OF CURRENT DATE */
    if (DATE_Cmp(begDate.date, currentDate.date) < 0 && /* both begin and end dates of this period are prior to current date */
        DATE_Cmp(endDate.date, currentDate.date) < 0)
    {
        bCurrentDateInFuture = true;
    }
    else if (DATE_Cmp(begDate.date, currentDate.date) <= 0 && /* current date is between begin and end dates */
        DATE_Cmp(endDate.date, currentDate.date) >= 0)
    {
        bCurrentDateInBetween = true;
    }
    else if (DATE_Cmp(currentDate.date, begDate.date) < 0) /* current date is in the past (before begin date) */
    {
        bCurrentDateInPast = true;
    }

    if ((DBA_GetCalendarFromInstr(currInstrPtr, &calendarId) != RET_SUCCEED) || (calendarId <= 0))
    {
        GEN_GetApplInfo(ApplSysCalendarId, &calendarId);
        if (calendarId <= 0)
        {
            *bDeleteFlow = true;
            if (bDebugLog)
            {
                MSG_LogSrvMesg(UNUSED, 0, "FIN_ComputeFlowForACDC() : No calendar defined : destroying flow");
            }
            return(ret);
        }
    }

    CALNEXTBUSDATERULE_ENUM	nextBusDateEn = CalNextBusDateRule_Next; /* PMSTA-35384 - CHU - 190403 : manage business dates for gearing processing */
    if (FALSE == IS_NULLFLD(underlyingInstrPtr, A_Instr_BusDayConvEn))
    {
        nextBusDateEn = (CALNEXTBUSDATERULE_ENUM)GET_ENUM(instrPtr, A_Instr_BusDayConvEn); /* REF7264 - CSY - 020130 */
    }

    pricePtr = mp.allocDynst(FILEINFO, A_InstrPrice);
    if (true == bKnockedIn || true == bCurrentMonthKnockedOut)
    {
        if (true == bCurrentMonthKnockedIn)
        {
            getPriceDateTime.date = knockInDate.date;
        }
        else
        {
            /* getPricefDateTime.date = begDate.date; */
            getPriceDateTime.date = fixingBegDate.date;
        }

        if (true == bCurrentMonthKnockedOut)
        {
            if (false == bCurrentMonthKnockedIn) /* PMSTA-35452 - CHU - 190416 : else, leave knock-in date unchanged */
            {
                getPriceDateTime.date = fixingBegDate.date;
            }
        }

        long nbdays;
        DATE_BusinessDaysBetween(fixingBegDate.date, fixingEndDate.date, calendarId, &nbdays);
        if (nbdays == 1 &&
            false == bCurrentMonthKnockedOut &&
            FALSE == IS_NULLFLD(termEvtSt, A_TermEvt_ProtectedDate))
        {
            fixingEndDate.date = fixingBegDate.date;
        }

        if (bDebugLog)
        {
            CODE_T date1, date2;

            strcpy(date1, DATE_DateConv(getPriceDateTime.date));
            strcpy(date2, DATE_DateConv(fixingEndDate.date));

            MSG_LogSrvMesg(UNUSED, 0, "FIN_ComputeFlowForACDC() : Checking prices for intrument %1 between %2 and %3",
                CodeType, GET_CODE(instrPtr, A_Instr_Cd),
                CodeType, date1,
                CodeType, date2);
        }
        /* < PMSTA-34990 - CHU - 190326 : Check for underlying prices against exercise price for gearing triggering */
        while (DATE_Cmp(getPriceDateTime.date, fixingEndDate.date) <= 0  &&  /* PMSTA-35432- CHU - 190404 */
               (knockOutDate.date == 0 || DATE_Cmp(getPriceDateTime.date, knockOutDate.date) < 0)) /* PMSTA-35858 - CHU - 190510 */
        {
            if ((ret = SCE_CldrIsBusinessDate(getPriceDateTime, calendarId, &isBusinessDateFlg)) != RET_SUCCEED)
            {
                *bDeleteFlow = true;
                if (bDebugLog)
                {
                    MSG_LogSrvMesg(UNUSED, 0, "FIN_ComputeFlowForACDC() : Unable to check if %1 is a business day : destroying flow",
                        CodeType, DATE_DateConv(getPriceDateTime.date));
                }
                return(ret);
            }

            if (DATE_Cmp(localCompoundDate.date, GET_DATE(instrPtr, A_Instr_BeginDate)) != 0)
            {
                while (DATE_Cmp(localCompoundDate.date, getPriceDateTime.date) < 0)
                {
                    localCompoundDate.date = DATE_Move(localCompoundDate.date, (int)compFreq, compDayUnit);
                }
            }

            if ((false == bCompoundFrequencyActivated && TRUE == isBusinessDateFlg) ||
                (false == bCompoundFrequencyActivated || (DATE_Cmp(getPriceDateTime.date, localCompoundDate.date) == 0 || /* PMSTA-35455 - CHU - 190701 */
                                                          (DATE_Cmp(localCompoundDate.date, GET_DATE(instrPtr, A_Instr_BeginDate)) == 0 &&
                                                           DATE_Cmp(compoundDate.date, GET_DATE(instrPtr, A_Instr_BeginDate)) == 0)))) /* PMSTA-35455 - CHU - 190704 */
            {
                if (bCurrentDateInPast ||
                    (true == bCurrentDateInBetween && DATE_Cmp(getPriceDateTime.date, currentDate.date) > 0))
                {
                    /* No gearing may occur as useless to check prices in the future */
                    nbTradingDaysWithoutGearing++;
                    localCompoundDate.date = DATE_Move(localCompoundDate.date, (int)compFreq, compDayUnit);
                }
                else
                {
                    ret = FIN_DefaultInstrPrice(underlyingInstrPtr, getPriceDateTime, FALSE, nullptr, nullptr, nullptr, hierHead, pricePtr, FALSE);
                    if ((SubNat_Accumulator == subnatEn && /* PMSTA-35508 - CHU - 190412 */
                         CMP_PRICE(GET_PRICE(pricePtr, A_InstrPrice_Price), exercisePrice) < 0) 
                        ||
                        (SubNat_Decumulator == subnatEn &&
                         CMP_PRICE(GET_PRICE(pricePtr, A_InstrPrice_Price), exercisePrice) > 0))
                    {
                        nbTradingDaysWithGearing++;
                        localCompoundDate.date = DATE_Move(localCompoundDate.date, (int)compFreq, compDayUnit);
                    }
                    else
                    {
                        nbTradingDaysWithoutGearing++;
                        localCompoundDate.date = DATE_Move(localCompoundDate.date, (int)compFreq, compDayUnit);
                    }
                }
            }
            getPriceDateTime.date = DATE_Move(getPriceDateTime.date, 1, Day);
        }
        if (bDebugLog)
        {
            MSG_LogSrvMesg(UNUSED, 0, "FIN_ComputeFlowForACDC() : nbTradingDaysWithoutGearing = %1 / nbTradingDaysWithGearing = %2",
                IntType, nbTradingDaysWithoutGearing,
                IntType, nbTradingDaysWithGearing);
        }
    }

    if (true == bCurrentMonthKnockedOut && /* Check Protected date */
        DATE_Cmp(fixingEndDate.date, knockOutDate.date) >= 0)
    {
        /* PMSTA-34990 - CHU - 190329 : Look for any protected date */
        if (FALSE == IS_NULLFLD(termEvtSt, A_TermEvt_ProtectedDate)) /* PMSTA-35461 - CHU - 190503 : Protected date should be in term_event and nowhere else */
        {
            protectedDate.date = GET_DATE(termEvtSt, A_TermEvt_ProtectedDate);
        }

        /* PMSTA-35462 - CHU - 190415 : well... no gearing should be applied between knock-out date +1 and protected date */
        if (protectedDate.date > 0 &&
            DATE_Cmp(begDate.date, protectedDate.date) <= 0 &&
            DATE_Cmp(knockOutDate.date, protectedDate.date) <= 0) /* PMSTA-35462 - CHU - 190412 : only if protected date defined */
        {
            long nbTradingDaysUntilProtectedDate = 0;
            DATE_T koPlus1 = DATE_Move(knockOutDate.date, 1, Day);

            if (false == bCompoundFrequencyActivated)
            {
                DATE_BusinessDaysBetween(koPlus1, protectedDate.date, calendarId, &nbTradingDaysUntilProtectedDate); /* PMSTA-35462 - CHU - 190415 */
            }
            else
            {
                getPriceDateTime.date = koPlus1;
                if (DATE_Cmp(localCompoundDate.date, koPlus1) < 0)
                {
                    localCompoundDate.date = DATE_Move(localCompoundDate.date, (int)compFreq, compDayUnit);
                }
                while (DATE_Cmp(getPriceDateTime.date, protectedDate.date) < 0)
                {
                    if (DATE_Cmp(getPriceDateTime.date, localCompoundDate.date) == 0)
                    {
                        nbTradingDaysUntilProtectedDate++;
                        localCompoundDate.date = DATE_Move(localCompoundDate.date, (int)compFreq, compDayUnit);
                    }
                    getPriceDateTime.date = DATE_Move(getPriceDateTime.date, 1, Day);
                }
            }
            nbTradingDaysWithoutGearing += nbTradingDaysUntilProtectedDate;
            if (bDebugLog)
            {
                MSG_LogSrvMesg(UNUSED, 0, "FIN_ComputeFlowForACDC() : Found Protected Date, adding %1 to nbTradingDaysWithoutGearing = %2",
                    IntType, nbTradingDaysUntilProtectedDate,
                    IntType, nbTradingDaysWithoutGearing);
            }
        }
    }

    if (true == bKnockedIn || true == bCurrentMonthKnockedOut)
    {
        if (true == bCurrentDateInFuture || true == bCurrentDateInBetween)
        {
            SET_NUMBER(flowSt, Flow_QtyUnit, (nbTradingDaysWithoutGearing * underlyingQty) + (nbTradingDaysWithGearing * underlyingQty * gearing));
            if (bDebugLog)
            {
                MSG_LogSrvMesg(UNUSED, 0, "FIN_ComputeFlowForACDC() : Computing (nbTradingDaysWithoutGearing * underlyingQty) + (nbTradingDaysWithGearing * underlyingQty * gearing)");
                MSG_LogSrvMesg(UNUSED, 0, "FIN_ComputeFlowForACDC() : Computing (%1 * %2) + (%3 * %4 * %5) = %6",
                    IntType, nbTradingDaysWithoutGearing,
                    NumberType, underlyingQty,
                    IntType, nbTradingDaysWithGearing,
                    NumberType, underlyingQty,
                    IntType, gearing,
                    NumberType, (nbTradingDaysWithoutGearing * underlyingQty) + (nbTradingDaysWithGearing * underlyingQty * gearing));
            }
        }
        else if (bCurrentDateInPast)
        {
            /* subsequent months until knock-out or final date  : do not consider any gearing*/
            SET_NUMBER(flowSt, Flow_QtyUnit, nbTradingDaysWithoutGearing * underlyingQty);
            if (bDebugLog)
            {
                MSG_LogSrvMesg(UNUSED, 0, "FIN_ComputeFlowForACDC() : Computing (nbTradingDaysWithoutGearing * underlyingQty) as current date is in the past (no gearing)");
                MSG_LogSrvMesg(UNUSED, 0, "FIN_ComputeFlowForACDC() : Computing (%1 * %2) = %3",
                    IntType, nbTradingDaysWithoutGearing,
                    NumberType, underlyingQty,
                    NumberType, (nbTradingDaysWithoutGearing * underlyingQty));
            }
        }
    }
    else
    {
        *bDeleteFlow = true;
        if (bDebugLog)
        {
            MSG_LogSrvMesg(UNUSED, 0, "FIN_ComputeFlowForACDC() : Not Knocked-in or already Knocked-out : destroying flow");
        }
        return(ret);
    }

    return(ret);
}

/****************************************************************************************
*
*   Function          : FIN_GetFrequenciesForACDC()
*
*   Description       : Retrieves all frequencies & frequency Units for current instrument
*
*   Arguments         : Instrument pointer and variables to be set
*
*   Return            : RET_SUCCEED or error code
*
*   Creation          : PMSTA-35452 / PMSTA-35455 - CHU - 190501
*
*******************************************************************************************/
STATIC RET_CODE FIN_GetFrequenciesForACDC(DBA_DYNFLD_STP    instrPtr,
                                          FREQUNIT_ENUM     *freqUnit,
                                          double            *freq,
                                          FREQUNIT_ENUM     *compFreqUnit,
                                          double            *compFreq,
                                          DATE_UNIT_ENUM    *dayUnit,
                                          DATE_UNIT_ENUM    *compDayUnit)
{
    RET_CODE ret = RET_SUCCEED;

    /* Frequency units can be one of those :
    FreqUnit_Day
    FreqUnit_BusDay
    FreqUnit_Week
    FreqUnit_Month
    FreqUnit_Quarter
    FreqUnit_Semester
    FreqUnit_Year
    */
    /* Day Units can be one of those :
    Day
    Week
    Month
    Quarter
    Semester
    Year
    */

    /* initialize to defaults */
    *freqUnit   = *compFreqUnit = FreqUnit_Month;
    *freq       = *compFreq     = 1.0;

    if (FALSE == IS_NULLFLD(instrPtr, A_Instr_PayFreq) && FALSE == IS_NULLFLD(instrPtr, A_Instr_PayFreqUnitEn))
    {
        *freq = (double)GET_TINYINT(instrPtr, A_Instr_PayFreq);
        *freqUnit = (FREQUNIT_ENUM)GET_ENUM(instrPtr, A_Instr_PayFreqUnitEn);
    }
    else
    {
        MSG_LogSrvMesg(UNUSED, 0, "FIN_GetFrequenciesForACDC() : No valid Payment frequency defined for intrument %1 - defaulting to 1 Month", CodeType, GET_CODE(instrPtr, A_Instr_Cd));
    }

    if (FALSE == IS_NULLFLD(instrPtr, A_Instr_CompFreq) && FALSE == IS_NULLFLD(instrPtr, A_Instr_CompFreqUnitEn))
    {
        *compFreq = (double)GET_TINYINT(instrPtr, A_Instr_CompFreq);
        *compFreqUnit = (FREQUNIT_ENUM)GET_ENUM(instrPtr, A_Instr_CompFreqUnitEn);
    }
    else
    {
        MSG_LogSrvMesg(UNUSED, 0, "%1: no valid Compound frequency - defaulting to 1 Month", CodeType, GET_CODE(instrPtr, A_Instr_Cd));
    }

    switch (*freqUnit)
    {
    case FreqUnit_Day:
        *dayUnit = Day;
        break;
    case FreqUnit_BusDay:
        *dayUnit = Day;
        break;
    case FreqUnit_Week:
        *dayUnit = Week;
        break;
    case FreqUnit_Month:
        *dayUnit = Month;
        break;
    case FreqUnit_Quarter:
        *dayUnit = Quarter;
        break;
    case FreqUnit_Semester:
        *dayUnit = Semester;
        break;
    case FreqUnit_Year:
        *dayUnit = Year;
        break;
    default:
        *dayUnit = Month;
        break;
    }

    switch (*compFreqUnit)
    {
    case FreqUnit_Day:
        *compDayUnit = Day;
        break;
    case FreqUnit_BusDay:
        *compDayUnit = Day;
        break;
    case FreqUnit_Week:
        *compDayUnit = Week;
        break;
    case FreqUnit_Month:
        *compDayUnit = Month;
        break;
    case FreqUnit_Quarter:
        *compDayUnit = Quarter;
        break;
    case FreqUnit_Semester:
        *compDayUnit = Semester;
        break;
    case FreqUnit_Year:
        *compDayUnit = Year;
        break;
    default:
        *compDayUnit = Month;
        break;
    }

    return(ret);
}

/****************************************************************************************
*
*   Function          : FIN_CheckFrequenciesForACDC()
*
*   Description       : Check Coumpond frequency vs Payment frequencyfor current instrument
*
*   Arguments         : Instrument pointer and variables to be checked
*
*   Return            : RET_SUCCEED or error code
*
*   Creation          : PMSTA-35455 - CHU - 190627
*
*******************************************************************************************/
STATIC RET_CODE FIN_CheckFrequenciesForACDC(DBA_DYNFLD_STP  instrPtr,
                                            FREQUNIT_ENUM   freqUnit,
                                            FREQUNIT_ENUM   compFreqUnit)
{
    RET_CODE ret = RET_SUCCEED;
    std::string compFreqUnitString;
    std::string freqUnitString;

    switch (freqUnit)
    {
    case FreqUnit_Day:
        freqUnitString = SYS_Stringer("Day");
        break;

    case FreqUnit_BusDay:
        freqUnitString = SYS_Stringer("Business Day");
        break;

    case FreqUnit_Week:
        freqUnitString = SYS_Stringer("Week");
        break;

    case FreqUnit_Month:
        freqUnitString = SYS_Stringer("Month");
        break;

    case FreqUnit_Quarter:
        freqUnitString = SYS_Stringer("Quarter");
        break;

    case FreqUnit_Semester:
        freqUnitString = SYS_Stringer("Semester");
        break;

    case FreqUnit_Year:
        freqUnitString = SYS_Stringer("Year");
        break;

    default:
    {
        if (freqUnit == FreqUnit_None)
            freqUnitString = SYS_Stringer("None");
        if (freqUnit == FreqUnit_MonthGlobalTWR)
            freqUnitString = SYS_Stringer("Global TWR");
        if (freqUnit == FreqUnit_MonthTWR)
            freqUnitString = SYS_Stringer("Monthly TWR");

        MSG_LogSrvMesg(UNUSED, 0, "%1: InValid Payment frequency (%2) - aborting computation",
            CodeType, GET_CODE(instrPtr, A_Instr_Cd),
            CodeType, freqUnitString.c_str());
        ret = RET_DBA_ERR_INVDATA;
    }
    break;

    }

    switch (compFreqUnit)
    {
    case FreqUnit_Day:
        compFreqUnitString = SYS_Stringer("Day");
        break;

    case FreqUnit_BusDay:
        compFreqUnitString = SYS_Stringer("Business Day");
        break;

    case FreqUnit_Week:
        compFreqUnitString = SYS_Stringer("Week");
        break;

    case FreqUnit_Month:
        compFreqUnitString = SYS_Stringer("Month");
        break;

    case FreqUnit_Quarter:
        compFreqUnitString = SYS_Stringer("Quarter");
        break;

    case FreqUnit_Semester:
        compFreqUnitString = SYS_Stringer("Semester");
        break;

    case FreqUnit_Year:
        compFreqUnitString = SYS_Stringer("Year");
        break;

    default:
    {
        if (compFreqUnit == FreqUnit_None)
            compFreqUnitString = SYS_Stringer("None");
        if (compFreqUnit == FreqUnit_MonthGlobalTWR)
            compFreqUnitString = SYS_Stringer("Global TWR");
        if (compFreqUnit == FreqUnit_MonthTWR)
            compFreqUnitString = SYS_Stringer("Monthly TWR");

        MSG_LogSrvMesg(UNUSED, 0, "%1: InValid Compound frequency (%2) - aborting computation",
            CodeType, GET_CODE(instrPtr, A_Instr_Cd),
            CodeType, compFreqUnitString.c_str());
        ret = RET_DBA_ERR_INVDATA;
    }
    break;

    }

    switch (compFreqUnit)
    {
        /*
    case FreqUnit_Day:
        *compDayUnit = Day;
        break;
    case FreqUnit_BusDay:
        *compDayUnit = Day;
        break;
        */
    case FreqUnit_Week:
        if (freqUnit == FreqUnit_Day    ||
            freqUnit == FreqUnit_BusDay)
        {
            ret = RET_DBA_ERR_INVDATA;
        }
        break;
    case FreqUnit_Month:
        if (freqUnit == FreqUnit_Day    ||
            freqUnit == FreqUnit_BusDay ||
            freqUnit == FreqUnit_Week)
        {
            ret = RET_DBA_ERR_INVDATA;
        }
        break;
    case FreqUnit_Quarter:
        if (freqUnit == FreqUnit_Day    ||
            freqUnit == FreqUnit_BusDay ||
            freqUnit == FreqUnit_Week   ||
            freqUnit == FreqUnit_Month)
        {
            ret = RET_DBA_ERR_INVDATA;
        }
        break;
    case FreqUnit_Semester:
        if (freqUnit == FreqUnit_Day    ||
            freqUnit == FreqUnit_BusDay ||
            freqUnit == FreqUnit_Week   ||
            freqUnit == FreqUnit_Month  ||
            freqUnit == FreqUnit_Quarter)
        {
            ret = RET_DBA_ERR_INVDATA;
        }
        break;
    case FreqUnit_Year:
        if (freqUnit == FreqUnit_Day    ||
            freqUnit == FreqUnit_BusDay ||
            freqUnit == FreqUnit_Week   ||
            freqUnit == FreqUnit_Month  ||
            freqUnit == FreqUnit_Quarter||
            freqUnit == FreqUnit_Semester)
        {
            ret = RET_DBA_ERR_INVDATA;
        }
        break;
    default:
        break;
    }

    if (ret != RET_SUCCEED)
    {
        MSG_LogSrvMesg(UNUSED, 0, "%1: Incompatible Compound frequency (%2) vs Payment frequency (%3) - aborting computation",
            CodeType, GET_CODE(instrPtr, A_Instr_Cd),
            CodeType, compFreqUnitString.c_str(),
            CodeType, freqUnitString.c_str());
    }

    return(ret);
}

/****************************************************************************************
* 
*   Function          : FIN_OptMultiNatExoticFlows()
*       
*   Description       : Retrieves all possible future flows of an chooser option.
*                       Use term contract events from the begin reference data
*                       to the ende reference date and fill flow structure.
*                  
*   Arguments         : fromDateTime  from date
*                       tillDateTime  end date
*                       valDateTime   
*                       inputInstrPtr pointer on instrument struct or NULL  
*                       evtDateRule   enum used in event generation domain 
*				      to specify the event operation date rule
*                       flowTab       pointer on flows array which will be 
*                                     allocated and filled up
*                                     (initialised to NULL by FIN_GenerateInstrFlows())
*                       flowNbr       pointer on flows number which will be
*                                     filled up 
*                                     (initialised to 0 by FIN_GenerateInstrFlows())
*
*   Warning           : Calling function is FIN_GenerateInstrFlows()
*
*   Return            : RET_SUCCEED or error code
*
*   modification      : REF1055 - AKO - 991125
*                       REF4075 - CSY - 991213 evtDateRule, freqManagement
*                       REF4075 - CSY - 991216 test on begDate if earliest date
*			            REF3990 - SSO - 000406 : modified ERROR MANAGEMENT !!! be careful if further modification
*                       PMSTA-34288 - CHU - 190113 : Participating Fwd & TARKO + AC/DC (Yeah! !m!.)
*                       PMSTA-34990 - CHU - 190313 : Rewrote dates management for AC/DC (Let's Rock! !m!)
*
*******************************************************************************************/
STATIC RET_CODE FIN_OptMultiNatExoticFlows(DATETIME_T		    fromDateTime,  
                                            DATETIME_T		    tillDateTime,
                                            DATETIME_T		    valDateTime,
                                            DBA_DYNFLD_STP		instrPtr,
                                            EVTDATERULE_ENUM	evtDateRule,
                                            DBA_DYNFLD_STP		**flowTab,
                                            int			        *flowNbr,
                                            DBA_HIER_HEAD_STP	hierHead)
{
	DBA_DYNFLD_STP   flowSt=NULLDYNST, termEvt=NULLDYNST;
	RET_CODE         ret;
	DAY_T            svEndD;
	char             endMFlg;
	int              allocSz=0, reallocSz=5, currPeriod; 
	/* double           freq; */
	DATETIME_T       begDate, endDate, date, fixingBegDate, fixingEndDate, compoundDate; /* PMSTA-34960 - CHU - 190329 */ /* PMSTA-35432- CHU - 190404 */ /* PMSTA-35455 - CHU - 190701 */
    DATETIME_T       savedBegDate, savedEndDate; /* PMSTA-35461 - CHU - 190516 */
	SUBNAT_ENUM	     subnatEn;
	FLAG_T		     freqManagement = FALSE; /* CSY 991213 : to keep the 3.40 behaviour */
	int		         oldFlows, i, iCount = 0;		/* REF3990 - SSO - 000406 */

	DBA_DYNFLD_STP  *compoTab = NULL, *termEvtTab = NULL, *underInstrTab = NULL;            /* PMSTA-34288 - CHU - 190113 */
	int             compoNbr = 0, termEvtNbr = 0, underInstrNbr = 0;                        /* PMSTA-34288 - CHU - 190113 */
    DBA_DYNFLD_STP  currInstrPtr = NULL;                                                    /* PMSTA-34288 - CHU - 190113 */
	DBA_DYNFLD_STP  currDomainPtr = DBA_GetDomainPtr(DBA_GetConnectNoFromHier(hierHead));   /* PMSTA-34288 - CHU - 190113 */
    DBA_DYNFLD_STP  instrForFixingDate = NULL;
    FREQUNIT_ENUM   freqUnit = FreqUnit_Month, compFreqUnit = FreqUnit_Month;   /* PMSTA-35452 / PMSTA-35455 - CHU - 190501 */
    bool            bCompoundFrequencyActivated = true;                         /* PMSTA-35455 - CHU - 190701 */
    double		    freq = 1.0, compFreq = 1.0;                                 /* PMSTA-35452 / PMSTA-35455 - CHU - 190501 */
    DATE_UNIT_ENUM  dayUnit = Month, compDayUnit = Month;                       /* PMSTA-35452 / PMSTA-35455 - CHU - 190501 */
    MemoryPool      mp;

    /* generate flows for exchange events */
    FIN_CreateExchangeFlows(instrPtr, fromDateTime, &tillDateTime, valDateTime, 
                           evtDateRule, &allocSz, flowNbr, flowTab, hierHead); 

	oldFlows = *flowNbr; /* REF3990 - SSO - 000406 memorize flows for free */

    /* < PMSTA-34288 - CHU - 190113 */
    if (InstrumentNature::isParticipatingForward(instrPtr)              ||
        InstrumentNature::isTargetKnockOutForward(instrPtr)             ||
        InstrumentNature::isAccumulator(instrPtr)                       ||
        InstrumentNature::isDecumulator(instrPtr))
	{
        if ((ret = FIN_STNOptionBasedCompoTermEvtInfo(hierHead, instrPtr, currDomainPtr,
                                                      &compoTab, &compoNbr,
                                                      &termEvtTab, &termEvtNbr,
                                                      &underInstrTab, &underInstrNbr)) != RET_SUCCEED)
        {
            RET_GENFLOWS(ret);
        }

        mp.ownerDynStpTab(compoTab,compoNbr);
        mp.ownerDynStpTab(termEvtTab,termEvtNbr);
        mp.ownerPtr(underInstrTab);  // instr from hierarchy

        if ((InstrumentNature::isParticipatingForward(instrPtr) ||
             InstrumentNature::isTargetKnockOutForward(instrPtr)) &&
             (compoNbr == 0 || !(compoNbr == termEvtNbr && compoNbr == underInstrNbr && termEvtNbr == underInstrNbr)))
        {
            /* incomplete use case */
            RET_GENFLOWS(ret);
        }

        if (InstrumentNature::isParticipatingForward(instrPtr)  || /* PMSTA-34960 - CHU - 190329 */
            InstrumentNature::isTargetKnockOutForward(instrPtr) || /* PMSTA-34960 - CHU - 190329 */
            InstrumentNature::isAccumulator(instrPtr)           ||
            InstrumentNature::isDecumulator(instrPtr))
        {
            freqManagement = TRUE; /* PMSTA-34288 - CHU - 190124 : after being false for almost 20 years, now activated ! */
        }
	}
	else /* > PMSTA-34288 - CHU - 190113 */
	{
		/* Read term event */
		termEvt = mp.allocDynst(FILEINFO, A_TermEvt);

		if ((ret = DBA_GetTermEvt(instrPtr, valDateTime.date, termEvt)) != RET_SUCCEED)
		{
			RET_GENFLOWS(ret); /* REF3990 - SSO - 000406 */
		}
		/* Payoff nature which are to be ignored - PMSTA-21039 - SHR - 153010*/
		if ((TERMEVT_PAYOFF_ENUM)GET_ENUM(termEvt, A_TermEvt_PayOffNatEn) == TermEvt_Payoff_Accumulator ||
			(TERMEVT_PAYOFF_ENUM)GET_ENUM(termEvt, A_TermEvt_PayOffNatEn) == TermEvt_Payoff_Decumulator ||
			(TERMEVT_PAYOFF_ENUM)GET_ENUM(termEvt, A_TermEvt_PayOffNatEn) == TermEvt_Payoff_Digital     ||
			(TERMEVT_PAYOFF_ENUM)GET_ENUM(termEvt, A_TermEvt_PayOffNatEn) == TermEvt_Payoff_Short       ||
			(TERMEVT_PAYOFF_ENUM)GET_ENUM(termEvt, A_TermEvt_PayOffNatEn) == TermEvt_Payoff_Long)
		{
            RET_GENFLOWS(ret); /* REF3990 - SSO - 000406 */
			/* return(RET_SUCCEED); */
        }

        /* < PMSTA-34288 - CHU - 190113 */
        termEvtTab = (DBA_DYNFLD_STP *)mp.calloc(1, sizeof(DBA_DYNFLD_STP));
        termEvtTab[0] = termEvt;
        termEvtNbr = 1;

        currInstrPtr = instrPtr;
        /* > PMSTA-34288 - CHU - 190113 */
    }

    for (int termEvtIdx = 0; termEvtIdx < termEvtNbr; termEvtIdx++) /* PMSTA-34288 - CHU - 190113 */
    {
        if (NULL == termEvtTab[termEvtIdx])
        {
            continue; /* as there may be holes in the array */
        }

        date.time = 0;
        begDate.time = 0;
        endDate.time = 0;
        compoundDate.time = 0; /* PMSTA-35455 - CHU - 190701 */

        /* < PMSTA-34288 - CHU - 190113 */
        if (compoNbr > 0)
        {
            /* PMSTA-34288 - CHU - 190203 : get instrument related to current term_event */
            for (int j = 0; j < underInstrNbr; j++)
            {
                if (CMP_ID(GET_ID(termEvtTab[termEvtIdx], A_TermEvt_InstrId), GET_ID(underInstrTab[j], A_Instr_Id)) == 0)
                {
                    currInstrPtr = underInstrTab[j];
                    break;
                }
            }
            if (NULL == currInstrPtr) /* instrument not found in composition */
            {
                currInstrPtr = instrPtr; /* let's keep the main instrument... */
            }
        }
        else
        {
            currInstrPtr = instrPtr;
        }
        /* > PMSTA-34288 - CHU - 190113 */

        if (InstrumentNature::isParticipatingForward(instrPtr) || /* PMSTA-34960 - CHU - 190329 */
            InstrumentNature::isTargetKnockOutForward(instrPtr) || /* PMSTA-34960 - CHU - 190329 */
            InstrumentNature::isAccumulator(instrPtr) ||
            InstrumentNature::isDecumulator(instrPtr))
        {
            /* NO KNOCK-IN Date = NOT YET KNOCKED-IN */
            if (TRUE == IS_NULLFLD(currInstrPtr, A_Instr_KnockInDate))
            {
                /* PMSTA-35972 - CHU - 190521 : Unless the Lower Barrier is not set (taken from FIN_STNKnockInStarted()) */
                if (!IS_NULLFLD(termEvtTab[termEvtIdx], A_TermEvt_LowerBarrierP) &&
                    GET_ENUM(termEvtTab[termEvtIdx], A_TermEvt_BarrierNatEn) != TermEvt_Barrier_None)
                {
                    continue;
                }
                /* PMSTA-35972 - CHU - 190521 : Knock-in date becomes the contract's begin date */
                COPY_DYNFLD(currInstrPtr, A_Instr, A_Instr_KnockInDate, currInstrPtr, A_Instr, A_Instr_BeginDate);
            }
        }

        /* < PMSTA-34288 - CHU - 190131 */
        if (TRUE == freqManagement &&
            (InstrumentNature::isParticipatingForward(instrPtr) || /* PMSTA-34960 - CHU - 190329 */
                InstrumentNature::isTargetKnockOutForward(instrPtr))      /* PMSTA-34960 - CHU - 190329 */
            &&
            IS_NULLFLD(termEvtTab[termEvtIdx], A_TermEvt_Freq) == TRUE &&
            IS_NULLFLD(currInstrPtr, A_Instr_PayFreq) == FALSE)
        {
            FIN_PeriodUnitNbr((FREQUNIT_ENUM)GET_ENUM(currInstrPtr, A_Instr_PayFreqUnitEn),
                GET_TINYINT(currInstrPtr, A_Instr_PayFreq),
                freqUnit, &freq);
        }
        else if (InstrumentNature::isAccumulator(instrPtr) ||
            InstrumentNature::isDecumulator(instrPtr))
        {
            /* PMSTA-35452 / PMSTA-35455 - CHU - 190501 */
            FIN_GetFrequenciesForACDC(instrPtr, &freqUnit, &freq, &compFreqUnit, &compFreq, &dayUnit, &compDayUnit);
            if (FIN_CheckFrequenciesForACDC(instrPtr, freqUnit, compFreqUnit) != RET_SUCCEED)
            {
                RET_GENFLOWS(ret); /* REF3990 - SSO - 000406 */
            }
            if (compFreqUnit == FreqUnit_Day)
                /*(compFreqUnit == FreqUnit_Day && (freqUnit == FreqUnit_Day || freqUnit == FreqUnit_BusDay) && freq == compFreq))*/
                /* || (freq == compFreq && freqUnit == compFreqUnit)) */
            {
                bCompoundFrequencyActivated = false;
            }
        }   
        else
        {
            FIN_PeriodUnitNbr((FREQUNIT_ENUM)GET_ENUM(termEvtTab[termEvtIdx], A_TermEvt_FreqUnitEn),
                GET_TINYINT(termEvtTab[termEvtIdx], A_TermEvt_Freq),
                freqUnit, &freq);
        }

        if (GET_DATE(termEvtTab[termEvtIdx], A_TermEvt_EndDate) < fromDateTime.date)
        {
            if (InstrumentNature::isParticipatingForward(instrPtr) ||
                InstrumentNature::isTargetKnockOutForward(instrPtr))
            {
                continue;
            }
            else
            {
                MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO,
                    "FIN_OptionFlows",
                    GET_CODE(currInstrPtr, A_Instr_Cd), "end date");
                return(RET_SUCCEED); /* REF3990 - SSO - 000406 RET_FIN_ERR_INVDATA->minor error */
            }
        }

        begDate.date = GET_DATE(termEvtTab[termEvtIdx], A_TermEvt_BeginDate);
        compoundDate.date = begDate.date;
        
        if (InstrumentNature::isParticipatingForward(instrPtr)  || /* PMSTA-34960 - CHU - 190329 */
            InstrumentNature::isTargetKnockOutForward(instrPtr) || /* PMSTA-34960 - CHU - 190329 */
            InstrumentNature::isAccumulator(instrPtr)           ||
            InstrumentNature::isDecumulator(instrPtr))
        {
            endDate.date = GET_DATE(termEvtTab[termEvtIdx], A_TermEvt_EndDate);
        }
        else
        {
            if ((freq == 0) || (freqManagement == FALSE)) /* CSY 991213: test on freqManagement */
                endDate.date = GET_DATE(termEvtTab[termEvtIdx], A_TermEvt_EndDate);
            else
                endDate.date = GET_DATE(termEvtTab[termEvtIdx], A_TermEvt_BeginDate);
        }

        /* Short month can corrupt day number */
        endMFlg = (char)DATE_IsLastInMonth(endDate.date);
        DATE_Get(endDate.date, (YEAR_T *)NULL, (MONTH_T *)NULL, &svEndD);

        if (endDate.date == BAD_DATE)
        {
            MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO,
                "FIN_OptionFlows",
                GET_CODE(currInstrPtr, A_Instr_Cd), "end date");
            return(RET_SUCCEED); /* REF3990 - SSO - 000406 RET_FIN_ERR_INVDATA->minor error */
        }

        if (InstrumentNature::isParticipatingForward(instrPtr)  || /* PMSTA-34960 - CHU - 190329 */
            InstrumentNature::isTargetKnockOutForward(instrPtr) || /* PMSTA-34960 - CHU - 190329 */
            InstrumentNature::isAccumulator(instrPtr)           ||
            InstrumentNature::isDecumulator(instrPtr))
        {
            /* PMSTA-35432- CHU - 190404 */
            currPeriod = 1;
            /* PMSTA-61236 - Deepthi - 20241028 */
            if (GET_TINYINT(currInstrPtr, A_Instr_PayFreq) == Week)
            {
                freq = Week;
                dayUnit = Week;
                endDate.date = DATE_Move(begDate.date, (int)freq, dayUnit);
            }
            else
            {
                endDate.date = DATE_Move(begDate.date, (int)freq, dayUnit);

                if (dayUnit != Day && dayUnit != Week) /* PMSTA-35452 - CHU - 190502 */
                {
                    /* Short month can corrupt day number */
                    endDate.date = DATE_Move(endDate.date, -1, Day);
                }
            }
#if 0
            /* PMSTA-35455 - CHU - 190701 : Compute next compounding date */
            if (bCompoundFrequencyActivated)
            {
                while (DATE_Cmp(compoundDate.date, begDate.date) < 0 &&
                       DATE_Cmp(compoundDate.date, endDate.date) < 0)
                {
                    compoundDate.date = DATE_Move(compoundDate.date, (int)compFreq, compDayUnit);
                }
            }
#endif

            savedBegDate = begDate;
            savedEndDate = endDate;

            fixingBegDate.date = begDate.date;
            fixingBegDate.time = 0;

            fixingEndDate.date = endDate.date;
            fixingEndDate.time = 0;

            YEAR_T      y1, y2;
            MONTH_T     m1, m2;
            DAY_T       d1, d2;

            bool bUpdateFixDates = true; /* PMSTA-35461 - CHU - 190426 */
            bool bProcessedKO = false;   /* PMSTA-35461 - CHU - 190514 */
            bool bProcessedKI = false;   /* PMSTA-35452 - CHU - 190520 */
            bool stop = false;

            /* For each period in current income event */
            /* (one in case of no repetitive event) */
            while (stop == false &&
                   endDate.date <= tillDateTime.date &&
                   (TRUE == IS_NULLFLD(currInstrPtr, A_Instr_KnockOutDate) ||
                    DATE_Cmp(begDate.date, GET_DATE(currInstrPtr, A_Instr_KnockOutDate)) <= 0)) /* PMSTA-35452 - CHU - 190503 */
            {
                if (TRUE == IS_NULLFLD(currInstrPtr, A_Instr_KnockOutDate) &&
                    DATE_Cmp(endDate.date, GET_DATE(currInstrPtr, A_Instr_EndDate)) > 0)
                {
                    endDate.date = GET_DATE(currInstrPtr, A_Instr_EndDate);
                    stop = true;
                }

                bool bDeleteFlow = false;

                if ((InstrumentNature::isAccumulator(instrPtr) ||
                    InstrumentNature::isDecumulator(instrPtr)) &&
                    freqUnit == FreqUnit_BusDay && dayUnit == Day)
                {
                    FLAG_T  isBusinessDateFlg = TRUE;
                    ID_T    calendarId = (ID_T)-1;

                    if ((DBA_GetCalendarFromInstr(instrPtr, &calendarId) != RET_SUCCEED) || (calendarId <= 0))
                    {
                        GEN_GetApplInfo(ApplSysCalendarId, &calendarId);
                        if (calendarId <= 0)
                        {
                            begDate = endDate;
                            endDate.date = DATE_Move(endDate.date, (int)freq, dayUnit);
                            if (dayUnit != Day && dayUnit != Week) /* PMSTA-35452 - CHU - 190502 */
                            {
                                endDate.date = DATE_Move(endDate.date, -1, Day);
                                /* Short month can corrupt day number */
                                DATE_VerifyEndMonth(&endDate.date, svEndD, endMFlg);
                            }
                            continue;
                        }
                    }
                    if (SCE_CldrIsBusinessDate(endDate, calendarId, &isBusinessDateFlg) == RET_SUCCEED &&
                        FALSE == isBusinessDateFlg)
                    {
                        begDate = endDate;
                        endDate.date = DATE_Move(endDate.date, (int)freq, dayUnit);
                        if (dayUnit != Day && dayUnit != Week) /* PMSTA-35452 - CHU - 190502 */
                        {
                            endDate.date = DATE_Move(endDate.date, -1, Day);
                            /* Short month can corrupt day number */
                            DATE_VerifyEndMonth(&endDate.date, svEndD, endMFlg);
                        }
                        continue;
                    }
                }

                if (allocSz == 0 || *flowNbr >= allocSz - 1)
                {
                    allocSz += reallocSz;
                    if (((*flowTab) = (DBA_DYNFLD_STP *)REALLOC((*flowTab), allocSz * sizeof(DBA_DYNFLD_STP))) == (DBA_DYNFLD_STP*)NULL)
                    {
                        MSG_RETURN(RET_MEM_ERR_ALLOC);
                    }
                }

                if (((*flowTab)[*flowNbr] = ALLOC_DYNST(Flow)) == NULLDYNST)
                {
                    MSG_RETURN(RET_MEM_ERR_ALLOC);
                }

                flowSt = (*flowTab)[*flowNbr];


                if (InstrumentNature::isParticipatingForward(instrPtr) || /* PMSTA-35500 - CHU - 190507 */
                    InstrumentNature::isTargetKnockOutForward(instrPtr))
                {
                    if (IS_NULLFLD(termEvtTab[termEvtIdx], A_TermEvt_UnderlyQty) == TRUE ||
                        GET_NUMBER(termEvtTab[termEvtIdx], A_TermEvt_UnderlyQty) == 0)
                    {
                        SET_NUMBER(flowSt, Flow_QtyUnit, 1);
                    }
                    else
                    {
                        SET_NUMBER(flowSt, Flow_QtyUnit, GET_NUMBER(termEvtTab[termEvtIdx], A_TermEvt_UnderlyQty));
                    }
                }

                /* PMSTA-35354 - CHU - 190401 : moved upper */
                SET_PRICE(flowSt, Flow_AmtUnit, GET_PRICE(termEvtTab[termEvtIdx], A_TermEvt_ExerPrice));
                SET_ID(flowSt, Flow_AmtCurrId, GET_ID(termEvtTab[termEvtIdx], A_TermEvt_CurrId));
                SET_EXCHANGE(flowSt, Flow_FxdExchRate, GET_EXCHANGE(termEvtTab[termEvtIdx], A_TermEvt_FixedExchRate));

                /* PMSTA-35432- CHU - 190404 */
                if (false == bProcessedKI)
                {
                    fixingBegDate.date = begDate.date;
                    fixingBegDate.time = 0;

                    fixingEndDate.date = endDate.date;
                    fixingEndDate.time = 0;
                }
                else
                {
                    bProcessedKI = false;
                }

                if (InstrumentNature::isParticipatingForward(instrPtr) || /* PMSTA-34960 - CHU - 190329 */
                    InstrumentNature::isTargetKnockOutForward(instrPtr))
                {
                    instrForFixingDate = currInstrPtr;
                } /* < PMSTA-35384 - CHU - 190402 */
                else if (InstrumentNature::isAccumulator(instrPtr) ||
                    InstrumentNature::isDecumulator(instrPtr))
                {
                    instrForFixingDate = instrPtr;
                } /* > PMSTA-35384 - CHU - 190402 */

                if (InstrumentNature::isAccumulator(instrPtr) ||
                    InstrumentNature::isDecumulator(instrPtr))
                {
                    /* < PMSTA-35384 - CHU - 190402 */
                    if (TRUE == IS_NULLFLD(instrForFixingDate, A_Instr_FixDate)) /* PMSTA-35461 - CHU - 190501 : Case where ko date must replace end date and fixing date is null */
                    {
                        if (FALSE == IS_NULLFLD(currInstrPtr, A_Instr_KnockOutDate) &&                      /* Knock-out is set */
                            DATE_Cmp(begDate.date, GET_DATE(currInstrPtr, A_Instr_KnockOutDate)) <= 0 &&    /* Knock_out in current period */
                            DATE_Cmp(GET_DATE(currInstrPtr, A_Instr_KnockOutDate), endDate.date) <= 0)      /* Knock_out in current period */
                        {
                            endDate.date = GET_DATE(currInstrPtr, A_Instr_KnockOutDate);
                            fixingEndDate.date = GET_DATE(currInstrPtr, A_Instr_KnockOutDate); /* PMSTA-35461 - CHU - 190503 */
                        }
                    }
                    else
                    {
                        if (true == bUpdateFixDates && false == bProcessedKO) /* PMSTA-35461 - CHU - 190426 */
                        {
                            if (dayUnit != Day && dayUnit != Week) /* PMSTA-35452 - CHU - 190502 */
                            {
                                /* PMSTA-35432- CHU - 190404 */
                                fixingBegDate.date = GET_DATE(instrForFixingDate, A_Instr_FixDate);

                                DATE_Get(begDate.date, &y1, &m1, &d1);
                                DATE_Get(fixingBegDate.date, &y2, &m2, &d2);

                                d1 = d2;
                                /* fixingBegDate.date = DATE_PUT(y1, m1, d2); */
                                fixingBegDate.date = DATE_Put(y2, m2, d2);
                                fixingBegDate.date = DATE_Move(fixingBegDate.date, 1, Day);
                                if (DATE_Check(y1, m1, d2) == FALSE)
                                {
                                    DATE_Get(fixingBegDate.date, (YEAR_T *)NULL, (MONTH_T *)NULL, &svEndD);
                                    /* Short month can corrupt day number */
                                    DATE_VerifyEndMonth(&fixingBegDate.date, svEndD, 1);
                                }

                                if (true == stop)
                                {
                                    fixingEndDate.date = GET_DATE(currInstrPtr, A_Instr_EndDate);
                                }
                                else
                                {
                                    fixingEndDate.date = GET_DATE(instrForFixingDate, A_Instr_FixDate);

                                    DATE_Get(endDate.date, &y1, &m1, &d1);
                                    DATE_Get(fixingEndDate.date, &y2, &m2, &d2);

                                    d1 = d2;
                                    fixingEndDate.date = DATE_Put(y1, m1, d2);
                                    if (DATE_Check(y1, m1, d2) == FALSE)
                                    {
                                        DATE_Get(fixingEndDate.date, (YEAR_T *)NULL, (MONTH_T *)NULL, &svEndD);
                                        /* Short month can corrupt day number */
                                        DATE_VerifyEndMonth(&fixingEndDate.date, svEndD, 1);
                                    }
                                }

                                /* < PMSTA-35452 - CHU - 190520 */
                                if (FALSE == IS_NULLFLD(currInstrPtr, A_Instr_KnockInDate) &&                           /* Knock-in is set */
                                    DATE_Cmp(begDate.date, GET_DATE(currInstrPtr, A_Instr_KnockInDate)) <= 0 &&         /* Knock_in in current fixing period */
                                    DATE_Cmp(GET_DATE(currInstrPtr, A_Instr_KnockInDate), endDate.date) <= 0) /* && */        /* Knock_in in current fixing period */
                                {
                                    /*
                                        Si KI dans la p�riode,
                                        Si Fix > KI
                                        envoyer 1�re p�riode ki -> Fix
                                        bProcessKI = true lancera la p�riode suivante apr�s calculs
                                    */
                                    if (true == bUpdateFixDates && false == bProcessedKO)
                                    {
                                        YEAR_T      y3;
                                        MONTH_T     m3;
                                        DAY_T       d3;

                                        DATE_T kiDate = GET_DATE(currInstrPtr, A_Instr_KnockInDate); /* 2017/01/20 */

                                        DATE_Get(kiDate, &y1, &m1, &d1); /* 2017/01/20 */
                                        DATE_Get(fixingBegDate.date, &y2, &m2, &d2); /* 2017/01/26 */
                                        DATE_Get(fixingEndDate.date, &y3, &m3, &d3); /* 2017/07/25 */

                                        if (y1 != y3 || m1 != m3)
                                        {
                                            savedBegDate.date = fixingBegDate.date; /* 2017/01/26 */
                                            savedEndDate.date = DATE_Move(savedBegDate.date, (int)freq, dayUnit);
                                            if (dayUnit != Day)
                                            {
                                                savedEndDate.date = DATE_Move(savedEndDate.date, -1, Day);
                                            }

                                            fixingBegDate.date = kiDate; /* 2017/01/20 */
                                            fixingEndDate.date = DATE_Put(y2, m2, d3); /* 2017/01/25 */
                                            /* fixingEndDate.date = savedEndDate.date; */ /* 2017/01/25 */

                                            bUpdateFixDates = false;
                                            bProcessedKI = true; /* will switch all dates to 1st period based on saved dates */
                                        }
                                    }
                                }

                                /* > PMSTA-35452 - CHU - 190520 */
                                if (FALSE == IS_NULLFLD(currInstrPtr, A_Instr_KnockOutDate) &&                          /* Knock-out is set */
                                    DATE_Cmp(begDate.date, GET_DATE(currInstrPtr, A_Instr_KnockOutDate)) <= 0 &&        /* Knock_out in current fixing period (begin/end has just been treated) */
                                    DATE_Cmp(GET_DATE(currInstrPtr, A_Instr_KnockOutDate), fixingEndDate.date) <= 0 &&  /* Knock_out in current fixing period (begin/end has just been treated) */
                                    false == bProcessedKI)
                                {
                                    if (DATE_Cmp(GET_DATE(currInstrPtr, A_Instr_KnockOutDate), fixingEndDate.date) <= 0)
                                    {
                                        fixingEndDate.date = GET_DATE(currInstrPtr, A_Instr_KnockOutDate);
                                        endDate.date = fixingEndDate.date;
                                    }
                                    else
                                    {
                                        savedBegDate = begDate;
                                        savedEndDate = endDate;
                                        endDate.date = GET_DATE(currInstrPtr, A_Instr_KnockOutDate);
                                        begDate.date = DATE_Move(fixingEndDate.date, 1, Day);
                                        fixingBegDate.date = begDate.date;
                                        fixingEndDate.date = endDate.date;
                                        bUpdateFixDates = false;
                                        bProcessedKO = true;
                                    }
                                }
                            }
                            else
                            {
                                if (FALSE == IS_NULLFLD(currInstrPtr, A_Instr_KnockInDate) &&                           /* Knock-in is set */
                                    DATE_Cmp(begDate.date, GET_DATE(currInstrPtr, A_Instr_KnockInDate)) <= 0 &&         /* Knock_in in current fixing period */
                                    DATE_Cmp(GET_DATE(currInstrPtr, A_Instr_KnockInDate), endDate.date) <= 0)
                                {
                                    begDate.date = fixingBegDate.date = GET_DATE(currInstrPtr, A_Instr_KnockInDate);
                                    endDate.date = fixingEndDate.date = DATE_Move(begDate.date, (int)freq, dayUnit);
                                }

                                if (dayUnit != Day)
                                {
                                    if (DATE_Cmp(begDate.date, GET_DATE(instrForFixingDate, A_Instr_FixDate)) <= 0 &&
                                        DATE_Cmp(GET_DATE(instrForFixingDate, A_Instr_FixDate), endDate.date) <= 0)
                                    {
                                        /* PMSTA-35452 - CHU - 190502 : Set fixing date only at the first related period */
                                        fixingEndDate.date = endDate.date = GET_DATE(instrForFixingDate, A_Instr_FixDate);

                                        DATE_Get(begDate.date, &y1, &m1, &d1);
                                        DATE_Get(fixingEndDate.date, &y2, &m2, &d2);

                                        if (y1 == y2 && m1 == m2) /* Month of Knock-in */
                                        {
                                            begDate.date = fixingBegDate.date = GET_DATE(currInstrPtr, A_Instr_KnockInDate);
                                        }
                                    }
                                }
                            }
                        }
                        else
                        {
                            if (dayUnit != Day && dayUnit != Week) /* PMSTA-35452 - CHU - 190502 */
                            {
                                if (FALSE == IS_NULLFLD(currInstrPtr, A_Instr_KnockOutDate) &&                          /* Knock-out is set */
                                    DATE_Cmp(begDate.date, GET_DATE(currInstrPtr, A_Instr_KnockOutDate)) <= 0 &&        /* Knock_out in current fixing period (begin/end has just been treated) */
                                    DATE_Cmp(GET_DATE(currInstrPtr, A_Instr_KnockOutDate), fixingEndDate.date) <= 0 &&  /* Knock_out in current fixing period (begin/end has just been treated) */
                                    false == bProcessedKI)
                                {
                                    if (DATE_Cmp(GET_DATE(currInstrPtr, A_Instr_KnockOutDate), fixingEndDate.date) <= 0)
                                    {
                                        fixingEndDate.date = GET_DATE(currInstrPtr, A_Instr_KnockOutDate);
                                        endDate.date = fixingEndDate.date;
                                    }
                                    else
                                    {
                                        savedBegDate = begDate;
                                        savedEndDate = endDate;
                                        endDate.date = GET_DATE(currInstrPtr, A_Instr_KnockOutDate);
                                        begDate.date = DATE_Move(fixingEndDate.date, 1, Day);
                                        fixingBegDate.date = begDate.date;
                                        fixingEndDate.date = endDate.date;
                                        bUpdateFixDates = false;
                                        bProcessedKO = true;
                                    }
                                }
                            }
                        }
                    }
                    /* > PMSTA-35384 - CHU - 190402 */
                }

                if (InstrumentNature::isParticipatingForward(instrPtr) || /* PMSTA-34960 - CHU - 190329 */
                    InstrumentNature::isTargetKnockOutForward(instrPtr))
                {
                    /* PMSTA-34288 - CHU - 190222 */ /* PMSTA-35432- CHU - 190404 */
                    ret = FIN_ComputeFlowForPartFwdAndTarko(hierHead, instrPtr, currInstrPtr, termEvtTab[termEvtIdx], flowSt, begDate, endDate, &bDeleteFlow); /* PMSTA-35388 - CHU - 190402 */
                }
                else
                {
                    if (FALSE == IS_NULLFLD(currInstrPtr, A_Instr_KnockOutDate) &&                          /* Knock-out is set */
                        DATE_Cmp(begDate.date, GET_DATE(currInstrPtr, A_Instr_KnockOutDate)) <= 0 &&        /* Knock_out in current period (begin/end has just been treated) */
                        DATE_Cmp(GET_DATE(currInstrPtr, A_Instr_KnockOutDate), endDate.date) <= 0 &&        /* Knock_out in current period (begin/end has just been treated) */
                        true == bUpdateFixDates)
                    {
                        if (dayUnit == Day && DATE_Cmp(fixingBegDate.date, GET_DATE(currInstrPtr, A_Instr_KnockOutDate)) == 0)
                        {
                            /* begin date == fixing date == knock_out date */
                            FREE_DYNST((*flowTab)[*flowNbr], Flow);
                            begDate = endDate;
                            endDate.date = DATE_Move(endDate.date, (int)freq, dayUnit);
                            if (dayUnit != Day && dayUnit != Week) /* PMSTA-35452 - CHU - 190502 */
                            {
                                endDate.date = DATE_Move(endDate.date, -1, Day);
                                /* Short month can corrupt day number */
                                DATE_VerifyEndMonth(&endDate.date, svEndD, endMFlg);
                            }
                            continue;
                        }

                        if (dayUnit == Week && DATE_Cmp(fixingEndDate.date, GET_DATE(currInstrPtr, A_Instr_KnockOutDate)) > 0)
                        {
                            /* fixing date is beyond knock_out date */
                            endDate.date = fixingEndDate.date = GET_DATE(currInstrPtr, A_Instr_KnockOutDate);
                        }
                    }

                    /* PMSTA-35455 - CHU - 190701 : Compute next compounding date */
                    if (true == bCompoundFrequencyActivated /* && dayUnit != compDayUnit */)
                    {
                        while (DATE_Cmp(compoundDate.date, begDate.date /* fixingBegDate.date */) < 0 &&
                               DATE_Cmp(compoundDate.date, endDate.date /* fixingEndDate.date */) < 0)
                        {
                            compoundDate.date = DATE_Move(compoundDate.date, (int)compFreq, compDayUnit);
                        }
                    }

                    /* PMSTA-35432- CHU - 190404 */
                    ret = FIN_ComputeFlowForACDC(hierHead, instrPtr, currInstrPtr, termEvtTab[termEvtIdx], flowSt,
                                                 begDate, endDate, fixingBegDate, fixingEndDate, &bDeleteFlow,
                                                 bCompoundFrequencyActivated, compoundDate, compFreq, compDayUnit); /* PMSTA-35455 - CHU - 190701 */
                    if (true == bProcessedKO)
                    {
                        iCount++;
                        if (iCount == 2)
                        {
                            begDate = savedBegDate;
                            endDate = savedEndDate;
                        }
                    }
                }

                if (true == bDeleteFlow)
                {
                    FREE_DYNST((*flowTab)[*flowNbr], Flow);
                    begDate = endDate;
                    /* WEALTH-10051 - Deepthi - 20240628 */
                    if (DATE_Cmp(begDate.date, GET_DATE(currInstrPtr, A_Instr_KnockOutDate)) >= 0)
                    {
                        break;
                    }
                    endDate.date = DATE_Move(endDate.date, (int)freq, dayUnit);
                    if (dayUnit != Day && dayUnit != Week) /* PMSTA-35452 - CHU - 190502 */
                    {
                        endDate.date = DATE_Move(endDate.date, -1, Day);
                        /* Short month can corrupt day number */
                        DATE_VerifyEndMonth(&endDate.date, svEndD, endMFlg);
                    }
                    continue;
                }
                else
                {
                    if (RET_SUCCEED == ret)
                    {
                        SET_DATETIME(flowSt, Flow_BegPayDate, fixingEndDate);

                        /* REF4075 - CSY991213 setting of optimal date according to evt date rule*/
                        if ((GET_ENUM(termEvtTab[termEvtIdx], A_TermEvt_OptStyleEn) == OptStyle_American) ||
                            (GET_ENUM(termEvtTab[termEvtIdx], A_TermEvt_OptStyleEn) == OptStyle_Bermudan))
                        {
                            switch (evtDateRule)
                            {
                            case EvtDateRule_Term:  /* present behaviour ("term"):
                                         optimal date = end date found in instrument flow */
                                SET_DATETIME(flowSt, Flow_OptimalDate, fixingEndDate);
                                break;
                            case EvtDateRule_Earliest: /* new behaviour ("next date") */
                                if (DATETIME_CMP(valDateTime, fixingEndDate) <= 0)
                                {
                                    SET_DATETIME(flowSt, Flow_OptimalDate, fixingEndDate);
                                }
                                else
                                {
                                    SET_DATETIME(flowSt, Flow_OptimalDate, valDateTime);
                                }
                                break;
                            }
                        }
                        else
                        {
                            SET_DATETIME(flowSt, Flow_OptimalDate, fixingEndDate);
                        }

                        SET_ID(flowSt, Flow_InstrId, GET_ID(currInstrPtr, A_Instr_Id));
                        SET_CODE(flowSt, Flow_EvtCd, GET_CODE(termEvtTab[termEvtIdx], A_TermEvt_Cd));
                        SET_INT(flowSt, Flow_EvtNbr, currPeriod); /* REF8844 - LJE - 030327 */
                        SET_ENUM(flowSt, Flow_NatEn, FlowNat_Term);
                        SET_FLAG(flowSt, Flow_ConfirmedFlg, TRUE);

                        SET_PERIOD(flowSt, Flow_SettlDays, GET_TINYINT(termEvtTab[termEvtIdx], A_TermEvt_SettleDays));
                        SET_DATETIME(flowSt, Flow_EndPayDate, endDate);

                        COPY_DYNFLD(flowSt, Flow, Flow_OptimalValDate, flowSt, Flow, Flow_OptimalDate);

                        SET_NULL_PERCENT(flowSt, Flow_IoRPrct);
                        SET_NUMBER(flowSt, Flow_RefQty, 1);

                        /* If end Date of term contract is equal to end date of  */
                        /* current period, we are on the last period of the term */
                        if (GET_DATE(termEvtTab[termEvtIdx], A_TermEvt_EndDate) == endDate.date)
                        {
                            SET_FLAG(flowSt, Flow_ReplaceFlg, TRUE);
                        }
                        else
                        {
                            SET_FLAG(flowSt, Flow_ReplaceFlg, FALSE);
                        }

                        SET_ID(flowSt, Flow_NewInstrId, GET_ID(termEvtTab[termEvtIdx], A_TermEvt_UnderlyInstrId));
                        SET_PRICE(flowSt, Flow_Quote, GET_PRICE(termEvtTab[termEvtIdx], A_TermEvt_ExerQuote));
                        SET_ENUM(flowSt, Flow_OptStyleEn, GET_ENUM(termEvtTab[termEvtIdx], A_TermEvt_OptStyleEn));
                        SET_ENUM(flowSt, Flow_OptClassEn, GET_ENUM(termEvtTab[termEvtIdx], A_TermEvt_OptionClassEn));
                        SET_PERCENT(flowSt, Flow_Proba, 100.0);

                        /* < PMSTA-34288 - CHU - 190131 */
                        if (IS_NULLFLD(termEvtTab[termEvtIdx], A_TermEvt_Freq) == TRUE)
                        {
                            if (IS_NULLFLD(currInstrPtr, A_Instr_PayFreq) == FALSE)
                            {
                                SET_TINYINT(flowSt, Flow_Freq, GET_TINYINT(currInstrPtr, A_Instr_PayFreq));
                                SET_ENUM(flowSt, Flow_FreqUnitEn, GET_ENUM(currInstrPtr, A_Instr_PayFreqUnitEn));
                            }
                            else
                            {
                                SET_TINYINT(flowSt, Flow_Freq, 1);
                                SET_ENUM(flowSt, Flow_FreqUnitEn, freqUnit);
                            }
                        }
                        else
                        {
                            SET_TINYINT(flowSt, Flow_Freq, GET_TINYINT(termEvtTab[termEvtIdx], A_TermEvt_Freq));
                            SET_ENUM(flowSt, Flow_FreqUnitEn, GET_ENUM(termEvtTab[termEvtIdx], A_TermEvt_FreqUnitEn));
                        }

                        SET_NUMBER(flowSt, Flow_CtdConvFact, GET_NUMBER(termEvtTab[termEvtIdx], A_TermEvt_CtdConvFact));
                        SET_NUMBER(flowSt, Flow_CtdConvRatio, GET_NUMBER(termEvtTab[termEvtIdx], A_TermEvt_CtdConvRatio));
                        SET_ID(flowSt, Flow_CtdInstrId, GET_ID(termEvtTab[termEvtIdx], A_TermEvt_CheapestInstrId));
                        SET_FLAG(flowSt, Flow_PhysicalFlg, GET_FLAG(termEvtTab[termEvtIdx], A_TermEvt_PhysicalFlg));
                        SET_ENUM(flowSt, Flow_SubNatEn, FlowSubNat_Term);

                        SET_NULL_DATE(flowSt, Flow_ExDate);
                        SET_NULL_TINYINT(flowSt, Flow_Priority);
                        SET_FLAG(flowSt, Flow_EffectiveFlg, FALSE);

                        (*flowNbr)++;
                        currPeriod++;
                        if (InstrumentNature::isAccumulator(instrPtr) ||
                            InstrumentNature::isDecumulator(instrPtr))
                        {
                            /* < PMSTA-35452 - CHU - 190520 */
                            if (true == bProcessedKI)
                            {
                                /*
                                    Si KI dans la p�riode, envoyer 2�me p�riode Fix - End
                                */
                                fixingBegDate = savedBegDate;
                                fixingEndDate = savedEndDate;
                                if (FALSE == IS_NULLFLD(currInstrPtr, A_Instr_KnockOutDate) &&                          /* Knock-out is set */
                                    DATE_Cmp(fixingBegDate.date, GET_DATE(currInstrPtr, A_Instr_KnockOutDate)) <= 0 &&        /* Knock_out in current period (begin/end has just been treated) */
                                    DATE_Cmp(GET_DATE(currInstrPtr, A_Instr_KnockOutDate), fixingEndDate.date) <= 0 &&        /* Knock_out in current period (begin/end has just been treated) */
                                    dayUnit != Day && dayUnit != Week)
                                {
                                    fixingEndDate.date = GET_DATE(currInstrPtr, A_Instr_KnockOutDate);
                                }
                                bUpdateFixDates = false;
                            }
                            else /* > PMSTA-35452 - CHU - 190520 */
                            {
                                /* < PMSTA-35461 - CHU - 190425 */
                                if (FALSE == IS_NULLFLD(currInstrPtr, A_Instr_KnockOutDate) &&                          /* Knock-out is set */
                                    DATE_Cmp(begDate.date, GET_DATE(currInstrPtr, A_Instr_KnockOutDate)) <= 0 &&        /* Knock_out in current period (begin/end has just been treated) */
                                    DATE_Cmp(GET_DATE(currInstrPtr, A_Instr_KnockOutDate), endDate.date) <= 0 &&        /* Knock_out in current period (begin/end has just been treated) */
                                    DATE_Cmp(fixingEndDate.date, GET_DATE(currInstrPtr, A_Instr_KnockOutDate)) < 0 &&
                                    dayUnit != Day && dayUnit != Week &&
                                    true == bUpdateFixDates)
                                {
                                    /* knock_out is after fixing end date */
                                    /* so we need to treat last period between fix end +1 to knock-out  */
                                    begDate.date = fixingEndDate.date;
                                    begDate.date = DATE_Move(begDate.date, (int)1, Day);
                                    bUpdateFixDates = false;
                                }
                                else /* > PMSTA-35461 - CHU - 190425 */
                                {
                                    if (false == bUpdateFixDates && true == bProcessedKO && iCount < 2)
                                    {
                                        /*
                                         In the case of this kind of use case:
                                         endDate.date == fixingBegDate == 26/05/2017
                                         begDate.date == fixingEndDate == 31/05/2017

                                         As computing of quantity has already been handled by FIN_ComputeFlowForACDC()
                                         between 25/05/2017 to 31/05/2017 (fixing date to knock-out date)

                                         Convert them to :
                                         begDate.date == fixingEndDate == 25/05/2017
                                         endDate.date == fixingBegDate == 26/04/2017
                                        */
                                        if (dayUnit != Day)
                                        {
                                            endDate.date = fixingEndDate.date = DATE_Move(begDate.date, -1, Day);
                                        }
                                        begDate.date = fixingBegDate.date = DATE_Move(begDate.date, (int)-freq, dayUnit);
                                    }
                                    else
                                    {
                                        bUpdateFixDates = true;
                                        bProcessedKO = false;

                                        begDate = fixingEndDate;
                                        endDate.date = DATE_Move(begDate.date, (int)freq, dayUnit);
                                        if (dayUnit != Day)
                                        {
                                            begDate.date = DATE_Move(begDate.date, 1, Day);
                                        }
                                        if (dayUnit != Day && dayUnit != Week) /* PMSTA-35452 - CHU - 190502 */
                                        {
                                            /* Short month can corrupt day number */
                                            DATE_VerifyEndMonth(&endDate.date, svEndD, endMFlg);
                                        }
                                    }
                                }
                            }
                        }
                        else
                        {
                            begDate = endDate;
                            if (dayUnit != Day)
                            {
                                endDate.date = DATE_Move(begDate.date, (int)freq, dayUnit); /* PMSTA-36794 - CHU - 190808 */
                                /* endDate.date = DATE_Move(endDate.date, -1, Day); */
                            }
                            if (dayUnit != Day && dayUnit != Week) /* PMSTA-35452 - CHU - 190502 */
                            {
                                /* Short month can corrupt day number */
                                DATE_VerifyEndMonth(&endDate.date, svEndD, endMFlg);
                            }
                        }
                    }
                    compoundDate.date = DATE_Move(compoundDate.date, (int)compFreq, compDayUnit);

                }
                if (ret != RET_SUCCEED) { break; }

            }
        }
        else
        {
            /* Advance in repetitive event until journal begin date */
            currPeriod = 1;
            while (endDate.date < fromDateTime.date)
            {
                begDate = endDate;
                endDate.date = DATE_Move(begDate.date, (int)freq, Month);
                /* Short month can corrupt day number */
                DATE_VerifyEndMonth(&endDate.date, svEndD, endMFlg);
                ++currPeriod;

                /* < PMSTA-34912 - CHU - 190228 */
                if (currPeriod >= 708) /* 59 years... */
                {
                    return(RET_DBA_ERR_KRANOTFOUND);
                }
                /* > PMSTA-34912 - CHU - 190228 */
            }

            /* For each period in current income event */
            /* (one in case of no repetitive event) */
            while (endDate.date <= GET_DATE(termEvtTab[termEvtIdx], A_TermEvt_EndDate) &&
                (endDate.date <= tillDateTime.date ||
                    /* REF4075 - CSY - 991216 : if earliest rule, test must be done on begDate
                    because the flow may occur at begDate */
                (begDate.date <= tillDateTime.date && evtDateRule == EvtDateRule_Earliest &&
                    (GET_ENUM(termEvtTab[termEvtIdx], A_TermEvt_OptStyleEn) == OptStyle_American ||
                        GET_ENUM(termEvtTab[termEvtIdx], A_TermEvt_OptStyleEn) == OptStyle_Bermudan)))
                )
            {
                if (allocSz == 0 || *flowNbr >= allocSz - 1)
                {
                    allocSz += reallocSz;
                    if (((*flowTab) = (DBA_DYNFLD_STP *)REALLOC((*flowTab), allocSz * sizeof(DBA_DYNFLD_STP))) == (DBA_DYNFLD_STP*)NULL)
                    {
                        MSG_RETURN(RET_MEM_ERR_ALLOC);
                    }
                }

                if (((*flowTab)[*flowNbr] = ALLOC_DYNST(Flow)) == NULLDYNST)
                {
                    MSG_RETURN(RET_MEM_ERR_ALLOC);
                }

                flowSt = (*flowTab)[*flowNbr];

                SET_ID(flowSt, Flow_InstrId, GET_ID(currInstrPtr, A_Instr_Id));
                SET_CODE(flowSt, Flow_EvtCd, GET_CODE(termEvtTab[termEvtIdx], A_TermEvt_Cd));
                SET_INT(flowSt, Flow_EvtNbr, currPeriod); /* REF8844 - LJE - 030327 */
                SET_ENUM(flowSt, Flow_NatEn, FlowNat_Term);
                SET_FLAG(flowSt, Flow_ConfirmedFlg, TRUE);

                SET_DATETIME(flowSt, Flow_BegPayDate, begDate);

                SET_PERIOD(flowSt, Flow_SettlDays, GET_TINYINT(termEvtTab[termEvtIdx], A_TermEvt_SettleDays));
                SET_DATETIME(flowSt, Flow_EndPayDate, endDate);
                SET_DATETIME(flowSt, Flow_OptimalDate, endDate);

                /* REF4075 - CSY991213 setting of optimal date according to evt date rule*/
                if ((GET_ENUM(termEvtTab[termEvtIdx], A_TermEvt_OptStyleEn) == OptStyle_American) ||
                    (GET_ENUM(termEvtTab[termEvtIdx], A_TermEvt_OptStyleEn) == OptStyle_Bermudan))
                {
                    switch (evtDateRule)
                    {
                    case EvtDateRule_Term:  /* present behaviour ("term"):
                                 optimal date = end date found in instrument flow */
                        SET_DATETIME(flowSt, Flow_OptimalDate, endDate);
                        break;
                    case EvtDateRule_Earliest: /* new behaviour ("next date") */
                        if (DATETIME_CMP(valDateTime, begDate) <= 0)
                        {
                            SET_DATETIME(flowSt, Flow_OptimalDate, begDate);
                        }
                        else
                        {
                            SET_DATETIME(flowSt, Flow_OptimalDate, valDateTime);
                        }
                        break;
                    }
                }
                COPY_DYNFLD(flowSt, Flow, Flow_OptimalValDate, flowSt, Flow, Flow_OptimalDate);

                SET_NULL_PERCENT(flowSt, Flow_IoRPrct);
                SET_NUMBER(flowSt, Flow_RefQty, 1);

                /* If end Date of term contract is equal to end date of  */
                /* current period, we are on the last period of the term */
                if (GET_DATE(termEvtTab[termEvtIdx], A_TermEvt_EndDate) == endDate.date)
                {
                    SET_FLAG(flowSt, Flow_ReplaceFlg, TRUE);
                }
                else
                {
                    SET_FLAG(flowSt, Flow_ReplaceFlg, FALSE);
                }

                SET_ID(flowSt, Flow_NewInstrId, GET_ID(termEvtTab[termEvtIdx], A_TermEvt_UnderlyInstrId));

                if (IS_NULLFLD(termEvtTab[termEvtIdx], A_TermEvt_UnderlyQty) == TRUE ||
                    /*		GET_ID(termEvt, A_TermEvt_UnderQty) == 0) */ /* REF9523 - TEB - 050323 */
                    GET_NUMBER(termEvtTab[termEvtIdx], A_TermEvt_UnderlyQty) == 0)
                {
                    SET_NUMBER(flowSt, Flow_QtyUnit, 1);
                }
                else
                {
                    SET_NUMBER(flowSt, Flow_QtyUnit, GET_NUMBER(termEvtTab[termEvtIdx], A_TermEvt_UnderlyQty));
                }

                SET_PRICE(flowSt, Flow_AmtUnit, GET_PRICE(termEvtTab[termEvtIdx], A_TermEvt_ExerPrice));
                SET_ID(flowSt, Flow_AmtCurrId, GET_ID(termEvtTab[termEvtIdx], A_TermEvt_CurrId));
                SET_PRICE(flowSt, Flow_Quote, GET_PRICE(termEvtTab[termEvtIdx], A_TermEvt_ExerQuote));
                SET_ENUM(flowSt, Flow_OptClassEn, GET_ENUM(termEvtTab[termEvtIdx], A_TermEvt_OptionClassEn));
                SET_EXCHANGE(flowSt, Flow_FxdExchRate, GET_EXCHANGE(termEvtTab[termEvtIdx], A_TermEvt_FixedExchRate));

                /* compute getting CALL or PUT */
                subnatEn = (SUBNAT_ENUM)GET_ENUM(instrPtr /* currInstrPtr */, A_Instr_SubNatEn);
                switch (subnatEn)
                {
                case SubNat_Chooser:
                {
                    if ((GET_ENUM(termEvtTab[termEvtIdx], A_TermEvt_OptionClassEn) == OptClass_None) ||
                        (fromDateTime.date <= GET_DATE(termEvtTab[termEvtIdx], A_TermEvt_FixDate)))
                    {
                        FIN_PRICEARG_ST	priceArgSt;
                        PRICE_T	quote = 0.0;
                        DBA_DYNFLD_STP  pricePtr = NULLDYNST;

                        pricePtr = mp.allocDynst(FILEINFO,A_InstrPrice);

                        memset(&priceArgSt, 0, sizeof(FIN_PRICEARG_ST));
                        if ((ret = FIN_InstrPrice(GET_ID(termEvtTab[termEvtIdx], A_TermEvt_UnderlyInstrId), NULLDYNST,
                            fromDateTime, NULLDYNST, (ID_T)0, &priceArgSt, NULLDYNST,
                            NULLDYNST, hierHead, pricePtr, FALSE)) == RET_SUCCEED) /* PMSTA14876 - DDV - 120911 - Add a new parameter, no impact for this call */
                        {
                            quote = GET_PRICE(pricePtr, A_InstrPrice_Quote);
                            if (CMP_PRICE(quote, GET_PRICE(termEvtTab[termEvtIdx], A_TermEvt_ExerQuote)) >= 0)
                            {
                                SET_ENUM(flowSt, Flow_OptClassEn, OptClass_Call);
                            }
                            else
                            {
                                SET_ENUM(flowSt, Flow_OptClassEn, OptClass_Put);
                            }
                        }
                        else { ret = RET_FIN_ERR_INVDATA; }
                    }
                }
                break;

                /* compute getting Strike price  */
                case SubNat_ForwardStart:
                {
                    if ((IS_NULLFLD(termEvtTab[termEvtIdx], A_TermEvt_ExerQuote) == TRUE) ||
                        (fromDateTime.date <= GET_DATE(termEvtTab[termEvtIdx], A_TermEvt_FixDate)))
                    {
                        FIN_PRICEARG_ST	priceArgSt;
                        DBA_DYNFLD_STP  pricePtr = NULLDYNST;

                        pricePtr = mp.allocDynst(FILEINFO,A_InstrPrice);

                        memset(&priceArgSt, 0, sizeof(FIN_PRICEARG_ST));
                        if ((ret = FIN_InstrPrice(GET_ID(termEvtTab[termEvtIdx], A_TermEvt_UnderlyInstrId), NULLDYNST,
                            fromDateTime, NULLDYNST, (ID_T)0, &priceArgSt, NULLDYNST,
                            NULLDYNST, hierHead, pricePtr, FALSE)) == RET_SUCCEED) /* PMSTA14876 - DDV - 120911 - Add a new parameter, no impact for this call */
                        {
                            NUMBER_T scaleFct = 0.0;
                            scaleFct = GET_NUMBER(termEvtTab[termEvtIdx], A_TermEvt_ScaleFactor);
                            if (IS_NULLFLD(termEvtTab[termEvtIdx], A_TermEvt_ScaleFactor) == TRUE)
                            {
                                scaleFct = 1.0;
                            }

                            if (IS_NULLFLD(pricePtr, A_InstrPrice_Quote) != TRUE)
                            {
                                SET_PRICE(flowSt, Flow_Quote, (GET_PRICE(pricePtr, A_InstrPrice_Quote)) * scaleFct);
                                SET_PRICE(flowSt, Flow_AmtUnit, (GET_PRICE(pricePtr, A_InstrPrice_Quote)) * scaleFct);

                            }
                            else { ret = RET_FIN_ERR_INVDATA; }
                        }
                    }
                }
                break;

                case SubNat_StrikeLookback:
                case SubNat_AvrgStrikeAsian:
                {
                    /* search instrChrono instrument */
                    DBA_DYNFLD_STP	instrChronoStp = NULLDYNST, dimChronoPtr = NULLDYNST;
                    NUMBER_T	chronoVal = 0.0;
                    instrChronoStp = mp.allocDynst(FILEINFO, A_InstrChrono);
                    dimChronoPtr = mp.allocDynst(FILEINFO, Dim_InstrChrono);

                    SET_ID(dimChronoPtr, Dim_InstrChrono_InstrId, GET_ID(currInstrPtr, A_Instr_Id));
                    SET_DATETIME(dimChronoPtr, Dim_InstrChrono_RefDate, fromDateTime);
                    if (subnatEn == SubNat_StrikeLookback)
                    {
                        SET_ENUM(dimChronoPtr, Dim_InstrChrono_NatEn, ChronoNat_LookbackCurrentExtreme);
                    }
                    else
                    {
                        SET_ENUM(dimChronoPtr, Dim_InstrChrono_NatEn, ChronoNat_AsianCurrentAverage);
                    }
                    SET_FLAG(dimChronoPtr, Dim_InstrChrono_ComputeFlg, FALSE);
                    if ((ret = FIN_InstrChrono(dimChronoPtr, currInstrPtr, instrChronoStp, hierHead)) == RET_SUCCEED)
                    {
                        if (IS_NULLFLD(instrChronoStp, A_InstrChrono_Val) != TRUE)
                            chronoVal = GET_LONGAMOUNT(instrChronoStp, A_InstrChrono_Val); /* REF11704 - TGU - 060419 - Change datatype */
                        else { ret = RET_FIN_ERR_INVDATA; }
                    }

                    if (RET_SUCCEED == ret)
                    {
                        SET_PRICE(flowSt, Flow_AmtUnit, CAST_PRICE(chronoVal));
                        SET_PRICE(flowSt, Flow_Quote, chronoVal);
                    }
                }
                break;
                case SubNat_Contingent:
                {
                    if (OptClass_Call == GET_ENUM(termEvtTab[termEvtIdx], A_TermEvt_OptionClassEn))
                    {
                        SET_PRICE(flowSt, Flow_AmtUnit,
                            (GET_PRICE(termEvtTab[termEvtIdx], A_TermEvt_ExerQuote) + GET_PRICE(termEvtTab[termEvtIdx], A_TermEvt_RebatePayoff)));
                    }
                    else if (OptClass_Put == GET_ENUM(termEvtTab[termEvtIdx], A_TermEvt_OptionClassEn))
                    { /* on sette le Strike plus cher, car on a une prime supplementaire */
                        AMOUNT_T    computedAmt = 0.0;
                        computedAmt = GET_PRICE(termEvtTab[termEvtIdx], A_TermEvt_ExerQuote) - GET_PRICE(termEvtTab[termEvtIdx], A_TermEvt_RebatePayoff);
                        if (computedAmt < 0)
                        {
                            computedAmt = 0.0;
                        }
                        SET_PRICE(flowSt, Flow_AmtUnit, CAST_PRICE(computedAmt));
                    }
                }
                break;

                default:
                    break;
                }

                if (RET_SUCCEED == ret)
                {
                    SET_ENUM(flowSt, Flow_OptStyleEn, GET_ENUM(termEvtTab[termEvtIdx], A_TermEvt_OptStyleEn));
                    SET_PERCENT(flowSt, Flow_Proba, 100.0);

                    /* < PMSTA-34288 - CHU - 190131 */
                    if (IS_NULLFLD(termEvtTab[termEvtIdx], A_TermEvt_Freq) == TRUE)
                    {
                        if (IS_NULLFLD(currInstrPtr, A_Instr_PayFreq) == FALSE)
                        {
                            SET_TINYINT(flowSt, Flow_Freq, GET_TINYINT(currInstrPtr, A_Instr_PayFreq));
                            SET_ENUM(flowSt, Flow_FreqUnitEn, GET_ENUM(currInstrPtr, A_Instr_PayFreqUnitEn));
                        }
                        else
                        {
                            SET_TINYINT(flowSt, Flow_Freq, 1);
                            SET_ENUM(flowSt, Flow_FreqUnitEn, FreqUnit_Month);
                        }
                    }
                    else
                    {
                        SET_TINYINT(flowSt, Flow_Freq, GET_TINYINT(termEvtTab[termEvtIdx], A_TermEvt_Freq));
                        SET_ENUM(flowSt, Flow_FreqUnitEn, GET_ENUM(termEvtTab[termEvtIdx], A_TermEvt_FreqUnitEn));
                    }

                    SET_NUMBER(flowSt, Flow_CtdConvFact, GET_NUMBER(termEvtTab[termEvtIdx], A_TermEvt_CtdConvFact));
                    SET_NUMBER(flowSt, Flow_CtdConvRatio, GET_NUMBER(termEvtTab[termEvtIdx], A_TermEvt_CtdConvRatio));
                    SET_ID(flowSt, Flow_CtdInstrId, GET_ID(termEvtTab[termEvtIdx], A_TermEvt_CheapestInstrId));
                    SET_FLAG(flowSt, Flow_PhysicalFlg, GET_FLAG(termEvtTab[termEvtIdx], A_TermEvt_PhysicalFlg));
                    SET_ENUM(flowSt, Flow_SubNatEn, FlowSubNat_Term);

                    SET_NULL_DATE(flowSt, Flow_ExDate);
                    SET_NULL_TINYINT(flowSt, Flow_Priority);
                    SET_FLAG(flowSt, Flow_EffectiveFlg, FALSE);

                    (*flowNbr)++;
                    currPeriod++;
                    begDate = endDate;

                    /* Get next period */
                    if (freq == 0. || /* No repetitive event, stop */
                        freqManagement == FALSE)  /*REF4075 - CSY - 991216 */
                        endDate.date = DATE_Move(endDate.date, 1, Day);
                    else
                    {
                        endDate.date = DATE_Move(begDate.date, (int)freq, Month);
                        /* Short month can corrupt day number */
                        DATE_VerifyEndMonth(&endDate.date, svEndD, endMFlg);
                    }
                }
                if (ret != RET_SUCCEED) { break; }
            }
        }
    }
	
	if (FATAL_FLOWSERROR(ret) == FALSE)
	{
	    /* REF3990 - SSO - 000406 : remove already added flows */
	    for (i=oldFlows; i<(*flowNbr); i++)
	    {
		    FREE_DYNST((*flowTab)[i], Flow);
	    }
	    (*flowNbr)=oldFlows;
	}
	/* REF3990 - SSO - 000406 return(RET_SUCCEED); was a bug!!!! -> replaced by (ret) */
	RET_GENFLOWS(ret);	  
}

/****************************************************************************************
* 
*   Function          : FIN_OptExoticPayOffFlows()
*       
*   Description       : Retrieves all possible future flows of an options.
*                       Use term contract events from the begin reference data
*                       to the ende reference date and fill flow structure.
*                  
*   Arguments         : fromDateTime  from date
*                       tillDateTime  end date
*                       valDateTime   
*                       inputInstrPtr pointer on instrument struct or NULL  
*                       evtDateRule   enum used in event generation domain 
*				      to specify the event operation date rule
*                       flowTab       pointer on flows array which will be 
*                                     allocated and filled up
*                                     (initialised to NULL by FIN_GenerateInstrFlows())
*                       flowNbr       pointer on flows number which will be
*                                     filled up 
*                                     (initialised to 0 by FIN_GenerateInstrFlows())
* 
*   Warning           : Calling function is FIN_GenerateInstrFlows()
* 
*   Return            : RET_SUCCEED or error code
*
*   modification      : REF1055 - AKO - 991125
*                       REF4075 - CSY - 991213 : evtDateRule and freqManagenent
*                       REF4075 - CSY - 991216 : earliest: test on begDate
*			REF3990 - SSO - 000406 : modified ERROR MANAGEMENT !!! be careful if further modification 
*  
*******************************************************************************************/
STATIC RET_CODE FIN_OptExoticPayOffFlows(DATETIME_T		    fromDateTime,  
                                        DATETIME_T		    tillDateTime,
                                        DATETIME_T		    valDateTime,
                                        DBA_DYNFLD_STP		instrPtr,
                                        EVTDATERULE_ENUM	evtDateRule,
                                        DBA_DYNFLD_STP		**flowTab,
                                        int			        *flowNbr,
                                        DBA_HIER_HEAD_STP	hierHead)
{
	DBA_DYNFLD_STP	flowSt=NULLDYNST, termEvt=NULLDYNST, pricePtr=NULLDYNST;
	RET_CODE	    ret;
	DAY_T		    svEndD;
	char		    endMFlg;
	int		        allocSz=0, reallocSz=5, currPeriod; 
	double		    freq;
	DATETIME_T	    begDate, endDate, date;
	SUBNAT_ENUM	    subnatEn;
	PRICE_T	    quote=0.0;
	NUMBER_T    computedAmt=0.0;
	FIN_PRICEARG_ST	priceArgSt;
	PAYOFFREBATE_ST	rebateSt;
	FLAG_T          freqManagement = FALSE; /* to keep the 3.40 behaviour for periodic events */
	int		        oldFlows, i;		/* REF3990 - SSO - 000406 */

    /* generate flows for exchange events */
    FIN_CreateExchangeFlows(instrPtr, fromDateTime, &tillDateTime, valDateTime, 
                           evtDateRule, &allocSz, flowNbr, flowTab, hierHead); 

	oldFlows = *flowNbr; /* REF3990 - SSO - 000406 memorize flows for free */

	/* Read term event */
	if ((termEvt = ALLOC_DYNST(A_TermEvt)) == NULLDYNST)
   		MSG_RETURN(RET_MEM_ERR_ALLOC);

	if ((ret = DBA_GetTermEvt(instrPtr, valDateTime.date, 
				  termEvt)) != RET_SUCCEED)
	{
	    FREE_DYNST(termEvt, A_TermEvt);
	    RET_GENFLOWS(ret); /* REF3990 - SSO - 000406 */
	}

	date.time = 0;
	begDate.time = 0;
	endDate.time = 0;

	FIN_PeriodUnitNbr((FREQUNIT_ENUM) GET_ENUM(termEvt, A_TermEvt_FreqUnitEn), 
		            GET_TINYINT(termEvt, A_TermEvt_Freq), 
			        FreqUnit_Month, &freq);

	if (GET_DATE(termEvt, A_TermEvt_EndDate) < fromDateTime.date)
	{
	    MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
			 "FIN_OptionFlows", 
			 GET_CODE(instrPtr, A_Instr_Cd), "end date");
	    FREE_DYNST(termEvt, A_TermEvt);
	    return(RET_SUCCEED); /* REF3990 - SSO - 000406 RET_FIN_ERR_INVDATA->minor error */ 
	}
	/* Payoff nature which are to be ignored - PMSTA-21039 - SHR - 153010*/
	if ((TERMEVT_PAYOFF_ENUM)GET_ENUM(termEvt, A_TermEvt_PayOffNatEn) == TermEvt_Payoff_Accumulator ||
		(TERMEVT_PAYOFF_ENUM)GET_ENUM(termEvt, A_TermEvt_PayOffNatEn) == TermEvt_Payoff_Decumulator ||
		(TERMEVT_PAYOFF_ENUM)GET_ENUM(termEvt, A_TermEvt_PayOffNatEn) == TermEvt_Payoff_Digital ||
		(TERMEVT_PAYOFF_ENUM)GET_ENUM(termEvt, A_TermEvt_PayOffNatEn) == TermEvt_Payoff_Short ||
		(TERMEVT_PAYOFF_ENUM)GET_ENUM(termEvt, A_TermEvt_PayOffNatEn) == TermEvt_Payoff_Long)
		{
			FREE_DYNST(termEvt, A_TermEvt);
			return(RET_SUCCEED);
		}
	begDate.date = GET_DATE(termEvt, A_TermEvt_BeginDate);
	if ((freq == 0)||(freqManagement == FALSE)) /* CSY - REF4075 - 991213: condition 
                                                on freqManagement flag */
		endDate.date = GET_DATE(termEvt, A_TermEvt_EndDate);
	else
	    endDate.date = GET_DATE(termEvt, A_TermEvt_BeginDate);

	/* Short month can corrupt day number */
	endMFlg = (char) DATE_IsLastInMonth(endDate.date);
	DATE_Get(endDate.date, (YEAR_T *) NULL, (MONTH_T *) NULL, &svEndD);

	if (endDate.date == BAD_DATE)
	{
	    FREE_DYNST(termEvt, A_TermEvt);
	    MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
			 "FIN_OptionFlows", 
			 GET_CODE(instrPtr, A_Instr_Cd), "end date");
	    return(RET_SUCCEED); /* REF3990 - SSO - 000406 RET_FIN_ERR_INVDATA->minor error */ 
	}

	/* Advance in repetitive event until journal begin date */
	currPeriod = 1;
	while (endDate.date < fromDateTime.date)
	{
	    begDate = endDate;
	    {
	        endDate.date = DATE_Move(begDate.date, (int)freq, Month);
	        /* Short month can corrupt day number */
	        DATE_VerifyEndMonth(&endDate.date, svEndD, endMFlg);
	    }
	    ++currPeriod;
	}

	/* For each period in current income event */
	/* (one in case of no repetitive event) */
	while (endDate.date <= GET_DATE(termEvt, A_TermEvt_EndDate) &&
	       (endDate.date <= tillDateTime.date ||
           /* REF4075 - CSY - 991216: if earliest rule: compare the begDate
           with tillDate  because flow may occur at begDate */
           (begDate.date <= tillDateTime.date && evtDateRule == EvtDateRule_Earliest &&
           (GET_ENUM(termEvt, A_TermEvt_OptStyleEn) == OptStyle_American || 
            GET_ENUM(termEvt, A_TermEvt_OptStyleEn) == OptStyle_Bermudan)))
           )
	{
	    if (allocSz == 0 || *flowNbr >= allocSz-1) 
	    {
		    allocSz+=reallocSz;
		    if (((*flowTab) = (DBA_DYNFLD_STP *) 
				      REALLOC((*flowTab), 
				      allocSz * sizeof(DBA_DYNFLD_STP))) 
				      == (DBA_DYNFLD_STP*)NULL)
		    {
		        FREE_DYNST(termEvt, A_TermEvt); 
		        MSG_RETURN(RET_MEM_ERR_ALLOC);
		    }
	    }

	    if (((*flowTab)[*flowNbr] = ALLOC_DYNST(Flow)) == NULLDYNST)
	    {
		    FREE_DYNST(termEvt, A_TermEvt); 
		    MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }

	    flowSt = (*flowTab)[*flowNbr];

	    SET_ID(flowSt,       Flow_InstrId,        GET_ID(instrPtr, A_Instr_Id));
	    SET_CODE(flowSt,     Flow_EvtCd,          GET_CODE(termEvt, A_TermEvt_Cd));
	    SET_INT(flowSt,      Flow_EvtNbr,         currPeriod); /* REF8844 - LJE - 030327 */
	    SET_ENUM(flowSt,     Flow_NatEn,          FlowNat_Term);
	    SET_FLAG(flowSt,     Flow_ConfirmedFlg, TRUE);
    
	    SET_DATETIME(flowSt, Flow_BegPayDate,     begDate);

	    SET_PERIOD(flowSt,   Flow_SettlDays,      GET_TINYINT(termEvt, A_TermEvt_SettleDays));
	    SET_DATETIME(flowSt, Flow_EndPayDate,     endDate);
	    SET_DATETIME(flowSt, Flow_OptimalDate,    endDate);

        /* REF4075 - CSY991213 setting of optimal date according to evt date rule*/
        if ((GET_ENUM(termEvt,A_TermEvt_OptStyleEn)== OptStyle_American)||
            (GET_ENUM(termEvt,A_TermEvt_OptStyleEn)== OptStyle_Bermudan))
        {
	        switch (evtDateRule)
	        {
	        case EvtDateRule_Term:  /* present behaviour ("term"): 
				         optimal date = end date found in instrument flow */
		        SET_DATETIME(flowSt, Flow_OptimalDate, endDate);
		        break;
	        case EvtDateRule_Earliest: /* new behaviour ("next date") */
		        if (DATETIME_CMP(valDateTime, begDate) <= 0) 
		        {
		            SET_DATETIME(flowSt, Flow_OptimalDate, begDate);
		        }
		        else
		        {
		            SET_DATETIME(flowSt, Flow_OptimalDate, valDateTime);
		        }
		        break;
	        }
        }
        
        COPY_DYNFLD(flowSt, Flow, Flow_OptimalValDate, flowSt, Flow, Flow_OptimalDate);
	    SET_NULL_PERCENT(flowSt,  Flow_IoRPrct);
	    SET_NUMBER(flowSt,        Flow_RefQty,         1);

	    /* If end Date of term contract is equal to end date of  */
	    /* current period, we are on the last period of the term */
	    if (GET_DATE(termEvt, A_TermEvt_EndDate) == endDate.date)
	    {	SET_FLAG(flowSt,        Flow_ReplaceFlg,        TRUE); }
	    else
	    {	SET_FLAG(flowSt,        Flow_ReplaceFlg,        FALSE); }

	    SET_ID(flowSt,       Flow_NewInstrId,
	           GET_ID(termEvt, A_TermEvt_UnderlyInstrId));

	    if (IS_NULLFLD(termEvt, A_TermEvt_UnderlyQty) == TRUE ||
/*	        GET_ID(termEvt, A_TermEvt_UnderQty) == 0) */	/* REF9523 - TEB - 050323 */
	        GET_NUMBER(termEvt, A_TermEvt_UnderlyQty) == 0)	/* REF9523 - TEB - 050323 */
	    {
	        SET_NUMBER(flowSt,   Flow_QtyUnit, 1);
	    }
	    else
	    {
	        SET_NUMBER(flowSt,   Flow_QtyUnit,
		           GET_NUMBER(termEvt, A_TermEvt_UnderlyQty));
	    }

	    SET_PRICE(flowSt, Flow_AmtUnit, 
		       GET_PRICE(termEvt, A_TermEvt_ExerPrice));
	    SET_ID(flowSt,            Flow_AmtCurrId,  GET_ID(termEvt, A_TermEvt_CurrId));
	    SET_PRICE(flowSt,        Flow_Quote,     GET_PRICE(termEvt, A_TermEvt_ExerQuote));
	    SET_ENUM(flowSt, Flow_OptClassEn, GET_ENUM(termEvt, A_TermEvt_OptionClassEn));
	    /* moved this from bottom to here */
	    SET_FLAG(flowSt,      Flow_PhysicalFlg, GET_FLAG(termEvt, A_TermEvt_PhysicalFlg));

	    if ((pricePtr = ALLOC_DYNST(A_InstrPrice)) == NULLDYNST)
	       MSG_RETURN(RET_MEM_ERR_ALLOC);   
	    memset(&priceArgSt, 0, sizeof(FIN_PRICEARG_ST));
	    if ((ret=FIN_InstrPrice(GET_ID(termEvt,A_TermEvt_UnderlyInstrId), NULLDYNST,
			                     valDateTime,NULLDYNST, (ID_T)0, &priceArgSt, NULLDYNST, 
			                     NULLDYNST, hierHead, pricePtr, FALSE))==RET_SUCCEED) /* PMSTA14876 - DDV - 120911 - Add a new parameter, no impact for this call */
	    {
	        quote = GET_PRICE(pricePtr, A_InstrPrice_Quote);
	    }
	    else
	    {
	        FREE_DYNST(termEvt, A_TermEvt);
	        FREE_DYNST(pricePtr, A_InstrPrice);

	        /* REF3990 - SSO - 000406 : remove already added flows and return */
	        for (i=oldFlows; i<(*flowNbr); i++)
	        {
		        FREE_DYNST((*flowTab)[i], Flow);
	        }
	        (*flowNbr)=oldFlows;
	        RET_GENFLOWS(ret); /* REF3990 - SSO - 000406 */
	    }

	    /* ------------------------------ */
	    /*  Step 1 : setting Flow_AmtUnit */
	    /*  whatever the subnature	      */
	    /* ------------------------------ */
	    switch(GET_ENUM(termEvt, A_TermEvt_PayOffNatEn))
	    {
	        case TermEvt_Payoff_Binary:
		        SET_PRICE(flowSt, Flow_AmtUnit, GET_NUMBER(termEvt, A_TermEvt_Gap));
		        break;

	        case TermEvt_Payoff_Vanilla:
		        SET_PRICE(flowSt, Flow_AmtUnit, GET_PRICE(termEvt, A_TermEvt_ExerQuote));
		        break;

	        case TermEvt_Payoff_Asseton:
		        SET_PRICE(flowSt, Flow_AmtUnit, quote * GET_NUMBER(termEvt, A_TermEvt_ScaleFactor));
		        break;

	        case TermEvt_Payoff_Gap:
		        if (OptClass_Call== GET_ENUM(termEvt, A_TermEvt_OptionClassEn))
		        {
		            SET_PRICE(flowSt, Flow_AmtUnit, (GET_PRICE(termEvt, A_TermEvt_ExerQuote) + 
						              GET_NUMBER(termEvt, A_TermEvt_Gap)));
		        }
		        else if (OptClass_Put== GET_ENUM(termEvt, A_TermEvt_OptionClassEn))
		        {
		            computedAmt = GET_PRICE(termEvt, A_TermEvt_ExerQuote) - GET_PRICE(termEvt, A_TermEvt_Gap);
		            if (computedAmt<0) {computedAmt=0;}
		            SET_PRICE(flowSt, Flow_AmtUnit, computedAmt);
		        }
		        else 
		        {
		            FREE_DYNST(pricePtr, A_InstrPrice);
		            FREE_DYNST(termEvt, A_TermEvt);

		            /* REF3990 - SSO - 000406 : remove already added flows and return */
		            for (i=oldFlows; i<(*flowNbr); i++)
		            {
			            FREE_DYNST((*flowTab)[i], Flow);
		            }
		            (*flowNbr)=oldFlows;
		            return(RET_SUCCEED); /* REF3990 - SSO - 000406 RET_FIN_ERR_INVDATA->minor error */ 
		        }
		        break;

	        default:
		    {
		        FREE_DYNST(pricePtr, A_InstrPrice);
		        FREE_DYNST(termEvt, A_TermEvt);

		        /* REF3990 - SSO - 000406 : remove already added flows and return */
		        for (i=oldFlows; i<(*flowNbr); i++)
		        {
			        FREE_DYNST((*flowTab)[i], Flow);
		        }
		        (*flowNbr)=oldFlows;
		        return(RET_SUCCEED); /* REF3990 - SSO - 000406 RET_FIN_ERR_INVDATA->minor error */ 
		    }
	    }

	    /* -------------------------------- */
	    /*  Step 2 : Flow_AmtUnit treatment */
	    /* -------------------------------- */
	    /* init return rebate structure */
    	memset(&rebateSt, 0, sizeof(PAYOFFREBATE_ST));
	    subnatEn = (SUBNAT_ENUM) GET_ENUM(instrPtr, A_Instr_SubNatEn);
	    if ((ret=FIN_GetDataRebateInTermEvt(instrPtr, &termEvt, valDateTime,tillDateTime, 
						                    &rebateSt, hierHead))==RET_SUCCEED)
	    {
		    switch (subnatEn)
		    {
		        case SubNat_Barrier:
			    {
			        if (rebateSt.payOffStatus == Std_Rebate)
			        {
				    SET_PRICE(flowSt, Flow_AmtUnit, rebateSt.payOffRebate);
			        }
			    }
			    break;
		        case SubNat_DoubleKnockOut:
			    {
			        if ((rebateSt.payOffStatus == Upper_Rebate) || (rebateSt.payOffStatus == Std_Rebate))
			        {
				    SET_PRICE(flowSt, Flow_AmtUnit, rebateSt.payOffRebate);
			        }
			    }
			    break;
		        case SubNat_OneTouchDigital:
			        if (rebateSt.payOffStatus == Std_Rebate)
			        {
			            SET_PRICE(flowSt, Flow_AmtUnit, rebateSt.payOffRebate);
			        }
                break;
		        case SubNat_Binary:
			    break;
		        default:
		        {
			        FREE_DYNST(pricePtr, A_InstrPrice);
			        FREE_DYNST(termEvt, A_TermEvt);

			        /* REF3990 - SSO - 000406 : remove already added flows and return */
			        for (i=oldFlows; i<(*flowNbr); i++)
			        {
			            FREE_DYNST((*flowTab)[i], Flow);
			        }
			        (*flowNbr)=oldFlows;
			        return(RET_SUCCEED); /* REF3990 - SSO - 000406 RET_FIN_ERR_INVDATA->minor error */ 
		        }
		    }

		    if ((rebateSt.payOffStatus == Upper_Rebate) || (rebateSt.payOffStatus == Std_Rebate))
		    {
		        SET_FLAG(flowSt,      Flow_PhysicalFlg, (FLAG_T)FALSE);
		    }

		    if ((rebateSt.payOffStatus == Std_Rebate) || 
		        ((rebateSt.payOffStatus == No_Rebate) && 
		        (subnatEn == SubNat_OneTouchDigital)))
		    {
		        if (GET_FLAG(termEvt, A_TermEvt_RebateAtHitFlg)==TRUE)
		        {
			        SET_DATETIME(flowSt, Flow_OptimalDate, valDateTime);
		        }
		    }
		    if (rebateSt.payOffStatus == Upper_Rebate)
		    {
		        if (GET_FLAG(termEvt, A_TermEvt_UpperRebateAtHitFlg)==TRUE)
		        {
			        SET_DATETIME(flowSt, Flow_OptimalDate, valDateTime);
		        }
		    }
	    }

	    if (RET_SUCCEED==ret)
	    {
		    SET_ENUM(flowSt,          Flow_OptStyleEn, GET_ENUM(termEvt, A_TermEvt_OptStyleEn));
		    SET_PERCENT(flowSt,       Flow_Proba,      100.0);

		    SET_TINYINT(flowSt,    Flow_Freq, 
		        GET_TINYINT(termEvt, A_TermEvt_Freq));
		    SET_ENUM(flowSt,      Flow_FreqUnitEn, 
		        GET_ENUM(termEvt, A_TermEvt_FreqUnitEn));
		    SET_EXCHANGE(flowSt,  Flow_FxdExchRate, 
		        GET_EXCHANGE(termEvt, A_TermEvt_FixedExchRate));
		    SET_NUMBER(flowSt,    Flow_CtdConvFact, 
		        GET_NUMBER(termEvt, A_TermEvt_CtdConvFact));
		    SET_NUMBER(flowSt,    Flow_CtdConvRatio,
		        GET_NUMBER(termEvt, A_TermEvt_CtdConvRatio));
		    SET_ID(flowSt,        Flow_CtdInstrId, 
		        GET_ID(termEvt, A_TermEvt_CheapestInstrId));
		    SET_ENUM(flowSt,      Flow_SubNatEn, FlowSubNat_Term);

		    SET_NULL_DATE(flowSt,      Flow_ExDate);
		    SET_NULL_TINYINT(flowSt,   Flow_Priority);
		    SET_FLAG(flowSt,           Flow_EffectiveFlg, FALSE);

		    (*flowNbr)++;
		    currPeriod++;
		    begDate = endDate;

		    /* Get next period */
		    if (freq == 0.||  /* No repetitive event, stop */
	                freqManagement == FALSE)  /* REF4075 - CSY - 991216 */     
			    endDate.date = DATE_Move(endDate.date, 1, Day); 
		    else
		    {
			    endDate.date = DATE_Move(begDate.date, (int)freq, Month);
			    /* Short month can corrupt day number */
			    DATE_VerifyEndMonth(&endDate.date, svEndD, endMFlg);
		    }
	    }
	    if (ret!=RET_SUCCEED) {break;} /* Attention : sortir du while */
	}

	/* Free allocated struct. */
	FREE_DYNST(pricePtr, A_InstrPrice);
	FREE_DYNST(termEvt, A_TermEvt);

	if (FATAL_FLOWSERROR(ret) == FALSE)
	{
	    /* REF3990 - SSO - 000406 : remove already added flows and return RET_SUCCEED */
	    for (i=oldFlows; i<(*flowNbr); i++)
	    {
		    FREE_DYNST((*flowTab)[i], Flow);
	    }
	    (*flowNbr)=oldFlows;
	}
	/* REF3990 - SSO - 000406 return(RET_SUCCEED); was a bug!!!! -> replaced by (ret) */
	RET_GENFLOWS(ret);	  
}

/**************************************************************************
* 
*   Function          : FIN_GetDataRebateInTermEvt()
*       
*   Description       : compute rebate amount/code for exoctic options
*                  
*   Arguments         : instrStp	:	pointer to option instrument
*			*termEvt	:	optionel termEvt if exist
*			valDateTime	:	begin date (domain) 
*			tillDateTime	:	closed Date (domain)
*			rebatePtr	:	payoff structure
*			hierHead	:	pointer on hierarchy
*
*   Return            : RET_SUCCEED or error code
*
*   modification      : REF1055 - AKO - 991125
*  
*****************************************************************************/
RET_CODE FIN_GetDataRebateInTermEvt(DBA_DYNFLD_STP	    instrStp,
				    DBA_DYNFLD_STP	    *termEvtPtr,
				    DATETIME_T		    valDateTime,
				    DATETIME_T		    tillDateTime,
				    PAYOFFREBATE_STP	    rebatePtr,
				    DBA_HIER_HEAD_STP	    hierHead)
{
    DBA_DYNFLD_STP	pricePtr=NULLDYNST, termEvt=NULLDYNST;
    SUBNAT_ENUM		subnatEn;
    RET_CODE		ret=RET_SUCCEED;
    FIN_PRICEARG_ST	priceArgSt;
    NUMBER_T		barrierAmt=0.0, upperBarrierAmt=0.0;
    PRICE_T		quote=0.0;
    FLAG_T		freeTermEvtFlg=FALSE;

    if (termEvtPtr == NULLDYNSTPTR) 
    {
	    if ((termEvt = ALLOC_DYNST(A_TermEvt)) == NULLDYNST)
	    {
   		    MSG_RETURN(RET_MEM_ERR_ALLOC);
	    }
	    if ((ret=DBA_GetTermEvt(instrStp, valDateTime.date, termEvt)) != RET_SUCCEED)
	    {
	        FREE_DYNST(termEvt, A_TermEvt);
	        return(ret);
	    }
	    freeTermEvtFlg=TRUE;
    }
    else
    {
	    freeTermEvtFlg=FALSE;
	    if ((*termEvtPtr) == NULLDYNST) 
	    {
	        if ((termEvt=ALLOC_DYNST(A_TermEvt)) == NULLDYNST)
	        {
   		        MSG_RETURN(RET_MEM_ERR_ALLOC);
	        }
	        if ((ret=DBA_GetTermEvt(instrStp, valDateTime.date, termEvt)) != RET_SUCCEED)
	        {
		        FREE_DYNST(termEvt, A_TermEvt);
		        return(ret);
	        }
	        else
	        {
		        (*termEvtPtr) = termEvt;
	        }
	    }
	    else 
	    {
	        termEvt=(*termEvtPtr);
	    }
    }
    
    barrierAmt	    = GET_NUMBER(termEvt, A_TermEvt_Barrier);
    upperBarrierAmt = GET_NUMBER(termEvt, A_TermEvt_UpperBarrier);
    if ((pricePtr = ALLOC_DYNST(A_InstrPrice)) == NULLDYNST)
    {
	    if (freeTermEvtFlg==TRUE) {FREE_DYNST(termEvt, A_TermEvt);}
	    MSG_RETURN(RET_MEM_ERR_ALLOC);   
    }
    memset(&priceArgSt, 0, sizeof(FIN_PRICEARG_ST));
    if ((ret=FIN_InstrPrice(GET_ID(termEvt,A_TermEvt_UnderlyInstrId), NULLDYNST,
			 valDateTime,NULLDYNST, (ID_T)0, &priceArgSt, NULLDYNST, 
			 NULLDYNST, hierHead, pricePtr, FALSE))==RET_SUCCEED) /* PMSTA14876 - DDV - 120911 - Add a new parameter, no impact for this call */
    {
	    quote = GET_PRICE(pricePtr, A_InstrPrice_Quote);
    }
    else
    {
	    FREE_DYNST(pricePtr, A_InstrPrice);
	    if (freeTermEvtFlg==TRUE) {FREE_DYNST(termEvt, A_TermEvt);}
	    return(ret);
    }
    /* init structre of payoff */
    rebatePtr->payOffRebate = 0.0;
    rebatePtr->payOffStatus = (char)0;
    subnatEn = (SUBNAT_ENUM) GET_ENUM(instrStp, A_Instr_SubNatEn);
    switch (subnatEn)
    {
	case SubNat_OneTouchDigital:
	case SubNat_Barrier:
	    {
		/* process */
		if ((IS_NULLFLD(termEvt, A_TermEvt_SeasonDate)==TRUE) ||
		    (GET_DATE(termEvt, A_TermEvt_SeasonDate) > valDateTime.date))
		{
		    switch(GET_ENUM(termEvt, A_TermEvt_BarrierNatEn))
		    {
			case TermEvt_Barrier_UpIn:
			    if (CMP_NUMBER(quote, barrierAmt) < 0)
			    {   /* feature lost */
				    rebatePtr->payOffStatus = (char)Std_Rebate;
			    }
			    break;

			case TermEvt_Barrier_UpOut:
			    if (CMP_NUMBER(quote, barrierAmt) >= 0)
			    {   /* forward-start feature lost */
				rebatePtr->payOffStatus = (char)Std_Rebate;
			    }
			    break;

			case TermEvt_Barrier_DownIn:
			    if (CMP_NUMBER(quote, barrierAmt) > 0)
			    {
				rebatePtr->payOffStatus = (char)Std_Rebate;
			    }
			    break;

			case TermEvt_Barrier_DownOut:
			    if (CMP_NUMBER(quote, barrierAmt) <= 0)
			    {
				rebatePtr->payOffStatus = (char)Std_Rebate;
			    }
			    break;
			case TermEvt_Barrier_None:
			default:
			    ret=RET_FIN_ERR_INVDATA;
			    break;
		    }

		    if (subnatEn == SubNat_Barrier)
			rebatePtr->payOffRebate = GET_NUMBER(termEvt, A_TermEvt_RebatePayoff);
		}
		else 
		{
		    rebatePtr->payOffStatus = (char)Std_Rebate;
		    if (subnatEn == SubNat_Barrier)
		    {
			    rebatePtr->payOffRebate = GET_NUMBER(termEvt, A_TermEvt_RebatePayoff);
		    }
		}

		FREE_DYNST(pricePtr,A_InstrPrice);
	    }
	    break;
    case SubNat_DoubleKnockOut:
	    {
		if (((IS_NULLFLD(termEvt, A_TermEvt_SeasonDate)==TRUE) ||
		     (GET_DATE(termEvt, A_TermEvt_SeasonDate) > valDateTime.date)) &&
		    ((IS_NULLFLD(termEvt, A_TermEvt_FixDate)==TRUE) || 
		     (GET_DATE(termEvt, A_TermEvt_FixDate) > valDateTime.date)))
		{
		    if (CMP_NUMBER(quote, upperBarrierAmt) >= 0)
		    {
		        rebatePtr->payOffStatus = (char)Upper_Rebate;
		        rebatePtr->payOffRebate = GET_NUMBER(termEvt, A_TermEvt_UpperRebate);
		    }
		    else if (CMP_NUMBER(quote, barrierAmt) <= 0)
		    {
			    rebatePtr->payOffStatus = (char)Std_Rebate;
			    rebatePtr->payOffRebate = GET_NUMBER(termEvt, A_TermEvt_RebatePayoff);
		    }
		    else
		    {
			    rebatePtr->payOffStatus = (char)No_Rebate;
			    rebatePtr->payOffRebate = 0.0;
		    }
		}
		else
		{
		    if ((IS_NULLFLD(termEvt, A_TermEvt_SeasonDate)!=TRUE) &&
			(GET_DATE(termEvt, A_TermEvt_SeasonDate) <= valDateTime.date))
		    {
			    rebatePtr->payOffStatus = (char)Std_Rebate;
			    rebatePtr->payOffRebate = GET_NUMBER(termEvt, A_TermEvt_RebatePayoff);
		    }
		    else if ((IS_NULLFLD(termEvt, A_TermEvt_FixDate)!=TRUE) && 
			    (GET_DATE(termEvt, A_TermEvt_FixDate) <= valDateTime.date))
		    {
			    rebatePtr->payOffStatus = (char)Upper_Rebate;
			    rebatePtr->payOffRebate = GET_NUMBER(termEvt, A_TermEvt_UpperRebate);
		    }
		}
	    }
	    break;
	case SubNat_Binary:
	    {
		    rebatePtr->payOffStatus = (char)No_Rebate;
		    rebatePtr->payOffRebate = 0.0;
	    }
	    break;

	default:
	    ret=RET_FIN_ERR_INVDATA;
	    break;
    }

    FREE_DYNST(pricePtr, A_InstrPrice);
    if (freeTermEvtFlg==TRUE) {FREE_DYNST(termEvt, A_TermEvt);}

    return(ret);
}


/**************************************************************************
* 
*   Function            : FIN_ManageGeneratedFlow()
*       
*   Description         : Manage the interactive action on the flows 
*                         from the Event Generation interface
*                  
*   Arguments           : 
*
*   Return              : RET_SUCCEED or error code
*
*   Creation date       : SKE - 000410 - REF3740
*  
*****************************************************************************/
RET_CODE FIN_ManageGeneratedFlow(DBA_HIER_HEAD_STP    hierPtr,
                                 DBA_DYNFLD_STP       flowPtr,
                                 DBA_DYNFLD_STP       oldFlowPtr,
                                 DBA_ACTION_ENUM      action,
                                 RETCODEFCT          *fct,
                                 PTR                  context,
                                 FLAG_T              *dfltValTab)
{
    RET_CODE ret = RET_SUCCEED;

    switch (action)
    {
        case Update:
            ret = FIN_UpdateGeneratedFlow(hierPtr,
                                          flowPtr,
                                          0,
                                          GET_FLAG(flowPtr, Flow_ConfirmedFlg));
            break;
        case Insert:
        case Delete:
            break;
    }

    return(ret);
}

/**************************************************************************
* 
*   Function            : FIN_ManageGeneratedOperation()
*       
*   Description         : Manage the interactive action on the operations 
*                         from the Event Generation interface
*                  
*   Arguments           : 
*
*   Return              : RET_SUCCEED or error code
*
*   Creation date       : SKE - 000410 - REF3740
*  
*****************************************************************************/
RET_CODE FIN_ManageGeneratedOperation(DBA_HIER_HEAD_STP    hierPtr,
                                      DBA_DYNFLD_STP       extOpPtr,
                                      DBA_DYNFLD_STP       oldExtOpPtr,
                                      DBA_ACTION_ENUM      action,
                                      RETCODEFCT          *fct,
                                      PTR                  context,
                                      FLAG_T              *dfltValTab)
{
    RET_CODE ret = RET_SUCCEED;

    switch (action)
    {
        case Update:
            ret = FIN_UpdateGeneratedOperation(hierPtr, extOpPtr);
            break;
        case Insert:
        case Delete:
            break;
    }
    
    return(ret);
}

/**************************************************************************
* 
*   Function            : FIN_UpdateGeneratedFlow()
*       
*   Description         : Manage the interactive update action on the 
*                         flows from the Event Generation interface
*                  
*   Arguments           : 
*
*   Return              : RET_SUCCEED or error code
*
*   Creation date       : SKE - 000410 - REF3740
*  
*****************************************************************************/
STATIC RET_CODE FIN_UpdateGeneratedFlow(DBA_HIER_HEAD_STP   hierPtr,
                                        DBA_DYNFLD_STP      newFlowPtr,
                                        ID_T                ptfId,
                                        FLAG_T              confirmedFlg)
{
    RET_CODE        ret                 = RET_SUCCEED;
    DBA_DYNFLD_STP *extOpTab            = NULLDYNSTPTR;
    DBA_DYNFLD_STP *flowTab             = NULLDYNSTPTR;
    FLAG_T          partialCheckedFlg   = FALSE;
    int             extOpNbr            = 0;
    int             flowNbr             = 0;
    int             i;
    int             j;

    /* Manage confirm flag */
    /* The flag is inherited by its constitutive operations */
    /*
        In case of a flow with a sub nature equals to "FlowSubNat_PropAttrib"
        all the related flows (and operations) inherite the confirm flag value.
    */
    if (GET_ENUM(newFlowPtr, Flow_SubNatEn) == FlowSubNat_PropAttrib)
    {
        ret = DBA_ExtractHierEltRecWithFilterSt(hierPtr,
			                                    Flow,
			                                    FALSE,
			                                    FIN_FilterPropAttribFlow,
                                                newFlowPtr,
			                                    NULLFCT,
                                                &flowNbr,
			                                    &flowTab);
        if (ret != RET_SUCCEED)
        {
            return(ret);
        }
        for (i=0 ; i < flowNbr ; i++)
        {
            SET_FLAG(flowTab[i], Flow_ConfirmedFlg, confirmedFlg);
        }
    }
    else
    {
        flowNbr = 1;
        flowTab = (DBA_DYNFLD_STP*) CALLOC(1, sizeof(DBA_DYNFLD_STP));
        if (flowTab == NULLDYNSTPTR)
        {
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }
        flowTab[0] = newFlowPtr;
    }

    for (i=0 ; i < flowNbr ; i++)
    {
        /* Extract extOp list */
	    if ((extOpNbr = GET_EXTENSION_NBR(flowTab[i], Flow_ExtOp_Ext)) == 0)
        {
            FREE(flowTab);
            MSG_SendMesg(RET_DBA_ERR_HIER,
                         6,
                         FILEINFO,
			             "FIN_UpdateGeneratedFlow",
                         Flow_ExtOp_Ext);
            return(RET_DBA_ERR_HIER);
        }

        if (IS_NULLFLD(flowTab[i], Flow_ExtOp_Ext) == TRUE    ||
            (extOpTab = GET_EXTENSION_PTR(flowTab[i], Flow_ExtOp_Ext)) == NULLDYNSTPTR)
        {
            FREE(flowTab);
            MSG_SendMesg(RET_DBA_ERR_HIER,
                         6,
                         FILEINFO,
			             "FIN_UpdateGeneratedFlow",
                         Flow_ExtOp_Ext);
            return(RET_DBA_ERR_HIER);
        }
        for (j = 0 ; j < extOpNbr ; j++)
        {
            if (ptfId == 0 ||
                GET_ID(extOpTab[j], ExtOp_PtfId) == ptfId)
            {
                SET_FLAG(extOpTab[j], ExtOp_ConfirmedFlg, confirmedFlg);
            }
            if (GET_FLAG(extOpTab[j], ExtOp_ConfirmedFlg) == TRUE)
            {
                partialCheckedFlg = TRUE;
            }
        }
        /* if at least one operation is checked the flow is also checked */
        SET_FLAG(flowTab[i], Flow_ConfirmedFlg, partialCheckedFlg);
    }

    FREE(flowTab);

    return(ret);
}


/**************************************************************************
* 
*   Function            : FIN_UpdateGeneratedOperation()
*       
*   Description         : Manage the interactive update action on the 
*                         operations from the Event Generation interface
*                  
*   Arguments           : 
*
*   Return              : RET_SUCCEED or error code
*
*   Creation date       : SKE - 000410 - REF3740
*  
*****************************************************************************/
STATIC RET_CODE FIN_UpdateGeneratedOperation(DBA_HIER_HEAD_STP    hierPtr,
                                             DBA_DYNFLD_STP       newExtOpPtr)
{
    RET_CODE        ret                 = RET_SUCCEED;
    DBA_DYNFLD_STP  flowPtr             = NULLDYNST;

    /* Manage confirm flag */
    /* The flag is inherited by the operations linked to the same flow and the same ptf */
    
    /* Extract linked flow ... */
	if (GET_EXTENSION_NBR(newExtOpPtr, ExtOp_A_Flow_Ext) != 1)
    {
        MSG_SendMesg(RET_DBA_ERR_HIER,
                     6,
                     FILEINFO,
			         "FIN_UpdateGeneratedOperation",
                     Flow_ExtOp_Ext);
        return(RET_DBA_ERR_HIER);
    }

    if (IS_NULLFLD(newExtOpPtr, ExtOp_A_Flow_Ext) == TRUE    ||
        (flowPtr = (*GET_EXTENSION_PTR(newExtOpPtr, ExtOp_A_Flow_Ext) ) ) == NULLDYNST)
    {
        MSG_SendMesg(RET_DBA_ERR_HIER,
                     6,
                     FILEINFO,
			         "FIN_UpdateGeneratedOperation",
                     ExtOp_A_Flow_Ext);
        return(RET_DBA_ERR_HIER);
    }

    ret = FIN_UpdateGeneratedFlow(hierPtr,
                                  flowPtr,
                                  GET_ID(newExtOpPtr, ExtOp_PtfId),
                                  GET_FLAG(newExtOpPtr, ExtOp_ConfirmedFlg));
    if (ret != RET_SUCCEED)
    {
        return(ret);
    }

    return(ret);
}


/**************************************************************************
* 
*   Function            : FIN_FilterPropAttribFlow()
*       
*   Description         : Filter function on linked Flow with sub nature 
*                         "Proportional Attribution"
*                         
*                         
*                  
*   Arguments           : 
*
*   Return              : RET_SUCCEED or error code
*
*   Creation date       : SKE - 000410 - REF3740
*  
*****************************************************************************/
STATIC int FIN_FilterPropAttribFlow(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP paramSt)
{
    /* Nature : Proportional Attribution */
    if (GET_ENUM(dynSt, Flow_SubNatEn) == FlowSubNat_PropAttrib         &&
        /* Same instr. */
        GET_ID(dynSt, Flow_InstrId) == GET_ID(paramSt, Flow_InstrId)    &&
        /* Same date */
        DATETIME_CMP(GET_DATETIME(dynSt ,Flow_OptimalDate), GET_DATETIME(paramSt ,Flow_OptimalDate)) == 0)
    {
        return(TRUE);
    }
    return(FALSE);
}

/************************************************************************
* 
*   Function          : FIN_OtherFlows()
* 
*   Description       : Retrieves all exchange flows for instrument of nature other
*                  
*   Arguments         : fromDateTime  from date
*                       tillDateTime  end date
*                       valDateTime
*                       inputInstrPtr pointer on instrument struct or NULL
*                       evtDateRule   enum for operation date rule in event generation domain
*                       flowTab       pointer on flows array which will be 
*                                     allocated and filled up
*                                     (initialised to NULL by FIN_GenerateInstrFlows())
*                       flowNbr       pointer on flows number which will be
*                                     filled up
*                                     (initialised to 0 by FIN_GenerateInstrFlows())
* 
*   Return            : 
* 
*   Creation date     : REF3140 - DDV - 000411
*   Last modification : 
*
*************************************************************************/
RET_CODE FIN_OtherFlows(DATETIME_T        fromDateTime, 
			                   DATETIME_T        tillDateTime,
			                   DATETIME_T        valDateTime,
		                       DBA_DYNFLD_STP    instrPtr,
                               EVTDATERULE_ENUM  evtDateRule,
			                   DBA_DYNFLD_STP    **flowTab,
			                   int               *flowNbr,
		                       DBA_HIER_HEAD_STP hierHead)
{
	int              allocSz=0;

	/************** EXCHANGE FLOWS ************/
	return(FIN_CreateExchangeFlows(instrPtr, fromDateTime, &tillDateTime, valDateTime, 
	                   			   evtDateRule, &allocSz, flowNbr, flowTab, hierHead));

}

/************************************************************************
* 
*   Function          : FIN_GenrFlowInstrCflw
* 
*   Description       : Retrieves all possible future flows of a flow instrument.
*                       Compute accrued interest
*                  
*   Arguments         : allocSz         - total memory size �allocated for flows
*                       fromDateTime    - from date
*                       tillDateTime    - end date
*                       valDateTime     - validate date
*                       instrPtr        - pointer on instrument struct
*                       evtDateRule     - enum for operation date rule in event generation domain
*                       flowTab         - pointer on flows array
*                       flowNbr         - pointer on flows number
*                       incEvtStp       - pointer on current income event structure       
*                       interRate       - interest rate data structure
*                       hierHead        - hierarchy pointer
* 
* 
*   Return            : retCode 
* 
*   Creation date     : REF6004 - AKO - 011031
*
*************************************************************************/
RET_CODE FIN_GenrFlowInstrCflw( int               *allocSz,
                                DATETIME_T        fromDateTime, 
                                DATETIME_T        tillDateTime,
                                DATETIME_T        valDateTime,
                                DBA_DYNFLD_STP    instrPtr,
                                EVTDATERULE_ENUM  evtDateRule,
                                DBA_DYNFLD_STP    **flowTab,
                                int               *flowNbr,
                                DBA_DYNFLD_STP    incEvtStp,
                                FIN_INTERRATE_ST  interRate,
                                DBA_HIER_HEAD_STP hierHead)
{
	DBA_DYNFLD_STP   flowPtr=NULLDYNST, yieldInstrPtr=NULLDYNST;
	RET_CODE         ret=RET_SUCCEED;
	int              j, currPeriod,  reallocSz=5, redPos=0, redNbr=0;
	double           freq;
	char             endMFlg, stop=FALSE;
	DAY_T            svEndD;
	DATETIME_T       begDate, endDate, date, tmpDateTime, busnessdate;
	PRICE_T          tmp;
	AMOUNT_T         qty;
	FLAG_T           found = FALSE,yieldInstrFreeFlg=FALSE;
    PERCENT_T       amort=1.0;
    CALNEXTBUSDATERULE_ENUM nextBusDateEn=CalNextBusDateRule_Default;
  
    memset(&tmpDateTime, 0, sizeof(DATETIME_T));
    memset(&endDate, 0, sizeof(DATETIME_T));
    memset(&begDate, 0, sizeof(DATETIME_T));
    memset(&busnessdate, 0, sizeof(DATETIME_T));

	FIN_PeriodUnitNbr((FREQUNIT_ENUM) GET_ENUM(incEvtStp, A_IncEvt_PayFreqUnitEn), 
				  GET_TINYINT(incEvtStp, A_IncEvt_PayFreq), 
				  FreqUnit_Month, &freq);

	endDate.date=begDate.date = GET_DATE(incEvtStp, A_IncEvt_BeginDate);

	/* Use first coupon date if specified */
	if (IS_NULLFLD(incEvtStp, A_IncEvt_FirstCoupDate) == FALSE)
    {endDate.date = GET_DATE(incEvtStp, A_IncEvt_FirstCoupDate);}
	else
    {endDate.date = GET_DATE(incEvtStp, A_IncEvt_BeginDate);}

	/* Short month can corrupt day number */
	endMFlg = (char) DATE_IsLastInMonth(endDate.date);
	DATE_Get(endDate.date, (YEAR_T*)NULL, (MONTH_T*)NULL, &svEndD);
	if (endDate.date == BAD_DATE)
	{
		MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
			     "FIN_GenrFlowInstrCflw", GET_CODE(instrPtr, A_Instr_Cd), "end date");
		return(RET_SUCCEED); 
	}

    /* ----------------------------- */
    /* Coupon � la begindate + freq. */
    /* ----------------------------- */
	endDate.date = DATE_Move(begDate.date, (int)freq, Month);
	DATE_VerifyEndMonth(&endDate.date, svEndD, endMFlg);
	

	/* Advance in repetitiv event until journal begin date */
	currPeriod = 1;
	while (endDate.date < fromDateTime.date)
	{
		begDate = endDate;
		if (freq == 0.)    /* No repetitive event (one period) */
        {endDate.date = GET_DATE(incEvtStp, A_IncEvt_LastPayDate);}
		else
		{
		    endDate.date = DATE_Move(begDate.date, (int)freq, Month);
		    DATE_VerifyEndMonth(&endDate.date, svEndD, endMFlg);
		}
		++currPeriod;
	}
	if (interRate.interRateNbr >= 1)
	{
  		j=0;
  		while (found == FALSE && j<interRate.interRateNbr)
		{
		    tmpDateTime.date = interRate.infoPtr[j].fromDate;
		    if (DATETIME_CMP(tmpDateTime, fromDateTime) <= 0)
		    {
			    tmpDateTime.date = interRate.infoPtr[j].tillDate;
			    if (DATETIME_CMP(tmpDateTime, fromDateTime) > 0)
			    { found = TRUE;}
		        else
                {j++;}
		    }
		    else
            {j++;}
		}
        if ( j < interRate.interRateNbr)
		{
		   qty = interRate.infoPtr[j].posRate;
		   tmp = qty / 100.0;
		}
		else
		{
		   qty = 0.0;
		   tmp = 0.0;
		}
	}
	else
	{
		qty = 0.0;
		tmp = 0.0;
	}

	/* FREE(interRate.infoPtr); AKO - 20020611 */
    amort   = 1.0;
    redPos  = 0;
  	redNbr = *flowNbr;

	/* For each period in current income event (one in case of no repetitive event) */
    if (GET_DATE(incEvtStp,A_IncEvt_LastPayDate)==MAGIC_END_DATE)
    {
		MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
			     "FIN_GenrFlowInstrCflw", GET_CODE(instrPtr, A_Instr_Cd), 
                 "Last pay date required to generate flows !");
		return(RET_FIN_ERR_INVDATA); 

    }

    /* Dividend */
    if (IS_NULLFLD(incEvtStp, A_IncEvt_Dividend)!=TRUE)
    {
        qty = GET_PRICE(incEvtStp, A_IncEvt_Dividend);
        tmp = qty;
        if ((INTERCD_ENUM)GET_ENUM(instrPtr, A_Instr_InterestCdEn) != InterCd_Instr)
        {
           tmp = qty/100;
        }
    }

	while ( (endDate.date <= tillDateTime.date) &&
	        (endDate.date <= GET_DATE(incEvtStp,A_IncEvt_LastPayDate)))
            /*(endDate.date < GET_DATE(incEvtStp,A_IncEvt_LastPayDate)))*/
	{
		if ( ((*allocSz) == 0) || ((*flowNbr) >= (*allocSz)-1)) 
		{
		    (*allocSz)+=reallocSz;
		    if (((*flowTab) = (DBA_DYNFLD_STP *) REALLOC((*flowTab), 
                (*allocSz) * sizeof(DBA_DYNFLD_STP))) == (DBA_DYNFLD_STP *) NULL)
		    {MSG_RETURN(RET_MEM_ERR_ALLOC);}
		}
   		if (((*flowTab)[*flowNbr] = ALLOC_DYNST(Flow)) == NULLDYNST)
		{MSG_RETURN(RET_MEM_ERR_ALLOC);}


        /* ------------------------------- */
        /* REF6004 - AKO - 020605          */
        /* take business date into account */
        /* ------------------------------- */
        if (IS_NULLFLD(instrPtr, A_Instr_BusDayConvEn)!=TRUE)
        {
            nextBusDateEn = (CALNEXTBUSDATERULE_ENUM)GET_ENUM(instrPtr, A_Instr_BusDayConvEn);
        }
        busnessdate.date = endDate.date;
        if (SCE_CldrNextBusinessDate(instrPtr, 
                                     0, 
                                     &nextBusDateEn, 
                                     endDate, 
                                     &busnessdate)==RET_SUCCEED)
        {
            endDate.date = busnessdate.date;
        }


		flowPtr = (*flowTab)[*flowNbr];
        SET_NUMBER(flowPtr,        Flow_RefQty, amort);/* gerer les amortissement */
		SET_ID(flowPtr,            Flow_InstrId,        GET_ID(incEvtStp, A_IncEvt_InstrId));
		SET_CODE(flowPtr,          Flow_EvtCd,          GET_CODE(incEvtStp, A_IncEvt_Cd));
		SET_INT(flowPtr,           Flow_EvtNbr,         currPeriod); /* REF8844 - LJE - 030327 */
		SET_ENUM(flowPtr,          Flow_NatEn,          FlowNat_Inc);
		SET_FLAG(flowPtr,          Flow_ConfirmedFlg,   TRUE);

		SET_DATETIME(flowPtr,      Flow_BegPayDate,     begDate);
		SET_DATETIME(flowPtr,      Flow_EndPayDate,     endDate);
		SET_PERIOD(flowPtr,        Flow_SettlDays,      0);
		SET_DATETIME(flowPtr,      Flow_OptimalDate,    endDate);
		date.date = GET_DATE(flowPtr, Flow_OptimalDate); 
	    SET_DATETIME(flowPtr, Flow_OptimalValDate, date);

/*

		SET_DATETIME(flowPtr,      Flow_BegPayDate,     begDate);
		SET_DATETIME(flowPtr,      Flow_EndPayDate,     endDate);
		SET_PERIOD(flowPtr,        Flow_SettlDays,      0);
		SET_DATETIME(flowPtr,      Flow_OptimalDate,    endDate);

  */
		SET_NULL_PERCENT(flowPtr,  Flow_IoRPrct);
		SET_PRICE(flowPtr,        Flow_Quote,          tmp);
		SET_FLAG(flowPtr,          Flow_ReplaceFlg,     FALSE); /* Niet c.f IRM */
		COPY_DYNFLD(flowPtr, Flow, Flow_AmtCurrId, incEvtStp,  A_IncEvt,  A_IncEvt_CurrId);
		SET_NULL_ID(flowPtr,       Flow_NewInstrId);
		SET_NULL_NUMBER(flowPtr,   Flow_QtyUnit);
		SET_NULL_ENUM(flowPtr,     Flow_OptClassEn);
		SET_NULL_ENUM(flowPtr,     Flow_OptStyleEn);
		SET_PERCENT(flowPtr,       Flow_Proba,          100.0);
		SET_TINYINT(flowPtr,       Flow_Freq, GET_TINYINT(incEvtStp, A_IncEvt_PayFreq));
		SET_ENUM(flowPtr,          Flow_FreqUnitEn, GET_ENUM(incEvtStp, A_IncEvt_PayFreqUnitEn));
		SET_EXCHANGE(flowPtr,      Flow_FxdExchRate, 
		GET_EXCHANGE(incEvtStp,    A_IncEvt_FixedExchRate));
		SET_NULL_DATE(flowPtr,     Flow_ExDate);
		SET_NULL_NUMBER(flowPtr,   Flow_CtdConvFact);
		SET_NULL_NUMBER(flowPtr,   Flow_CtdConvRatio);
		SET_NULL_ID(flowPtr,       Flow_CtdInstrId);
		SET_FLAG(flowPtr,          Flow_PhysicalFlg, FALSE);
		SET_NULL_TINYINT(flowPtr,  Flow_Priority);
		SET_FLAG(flowPtr,          Flow_EffectiveFlg, FALSE);
		SET_ENUM(flowPtr,          Flow_SubNatEn, FlowSubNat_FxdRate);
        /* ---------------- */
        /* new added fields */
        /* ---------------- */
        if (IS_NULLFLD(incEvtStp, A_IncEvt_YieldCurveInstrId) != TRUE)
        {SET_ID( flowPtr,  Flow_YieldCurveInstrId,GET_ID(incEvtStp, A_IncEvt_YieldCurveInstrId));}
        else
        {
		  if ((ret = DBA_GetInstrYieldCurve(instrPtr, &yieldInstrPtr, &yieldInstrFreeFlg, hierHead,0)) != RET_SUCCEED)
          {
	        MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
			 "FIN_GenrFlowInstrCflw", GET_CODE(instrPtr, A_Instr_Cd), 
			 "default yield curve is missing !");
          }
          else
          {
              if (IS_NULLFLD(yieldInstrPtr, A_Instr_Id) != TRUE)
              {SET_ID(flowPtr,  Flow_YieldCurveInstrId,GET_ID(yieldInstrPtr, A_Instr_Id));}
              else
              {
	             MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
			     "FIN_FlowInstrumentRedemptFlow", GET_CODE(yieldInstrPtr, A_Instr_Cd), 
			     "YieldCurveInstrId is missing");
              }
           }
        }
        /* nature of flow */
        SET_ENUM(flowPtr,     Flow_NatEn,        FlowNat_Inc); 	
        /* Sub_nature of flow */
        switch(GET_ENUM(incEvtStp, A_IncEvt_NatEn))
        {
            case    IncEvtNat_Paid:
                SET_ENUM(flowPtr,     Flow_SubNatEn,        FlowSubNat_IncCapitalToPay); 
                SET_PRICE(flowPtr,        Flow_AmtUnit,        -tmp);
                break;

            case IncEvtNat_Recev:
                SET_ENUM(flowPtr,     Flow_SubNatEn,        FlowSubNat_IncCapitalToRec); 
                SET_PRICE(flowPtr,        Flow_AmtUnit,        +tmp);
                break;

            default :
                SET_ENUM(flowPtr,     Flow_SubNatEn,        FlowSubNat_Any);
                SET_PRICE(flowPtr,        Flow_AmtUnit,        0);
                break;
        }
		/* Go on next period */
		(*flowNbr)++;
		currPeriod++;
		begDate = endDate;

        /* --------------------------------------------- */
		/* AKO - 020304 :Gerer les remboursement partiel */
        /* --------------------------------------------- */        
		for (stop=FALSE, j=redPos; j<redNbr && stop == FALSE; j++)
		{
		    if (DATETIME_CMP(endDate,GET_DATETIME((*flowTab)[j], Flow_EndPayDate)) >= 0)
		    {
                switch(GET_ENUM((*flowTab)[j],     Flow_SubNatEn))
                {
                    case    FlowSubNat_RedemCapitalToPay:
			            amort += (GET_PERCENT((*flowTab)[j], Flow_IoRPrct) / 100.0);
                        break;
                    case    FlowSubNat_RedemCapitalToRec:
			            amort -= (GET_PERCENT((*flowTab)[j], Flow_IoRPrct) / 100.0);
                        break;
                }
			    ++redPos;
		    }
		    else
			stop = TRUE;
		}
		if (freq == 0.)         /* No repetitive event, stop */
        { endDate.date = DATE_Move(endDate.date, 1, Day);}
		else
		{
		    endDate.date = DATE_Move(begDate.date, (int)freq, Month);
		    DATE_VerifyEndMonth(&endDate.date, svEndD, endMFlg);
		}
	}
    return(ret);
}


/************************************************************************
**
**  Function          : FIN_FlowInstrumentRedemptFlow()
**
**  Description       : Retrieves all possible future flows of a redemption.
**                 
**  Arguments         : allocSz       size of memory allocated
**                      fromDateTime  from date
**                      tillDateTime  end date
**                      inputInstrPtr pointer on instrument struct or NULL
**                      flowTab       pointer on flows array which will be 
**                                    allocated and filled up
**                      flowNbr       pointer on flows number which will be
**                                    filled up
**                                    (initialised to 0 )
**
**
**  Return            : RET_SUCCEED 
**                      RET_MEM_ERR_ALLOC
**                      RET_GEN_ERR_INVARG
**
**  Creation date     : REF7006 - AKO - 011126
**  Modif             : PMSTA00187 - BSA - 080215:The partial redemption price of an flow instrument is wrong in the Journal of liquidity
** 
*************************************************************************/
RET_CODE FIN_FlowInstrumentRedemptFlow(     int                *allocSz,
                                            DATETIME_T        fromDateTime,  
				                            DATETIME_T        tillDateTime,
				                            DATETIME_T        valDateTime,
				                            DBA_DYNFLD_STP    instrPtr,
				                            DBA_DYNFLD_STP    **flowTab,
				                            int               *flowNbr,
				                            DBA_HIER_HEAD_STP hierHead)
{
	DBA_DYNFLD_STP  flowSt=NULLDYNST, yieldInstrPtr=NULLDYNST,
		            *ioRTab=(DBA_DYNFLD_STP*) NULL;
	NUMBER_T        qty=1; /* ?? */
	DATETIME_T      date, begDate, endDate;
	DAY_T           svEndD;
	char            endMFlg;
	int             i, ioRNbr, currPeriod, reallocSz=5; 
	double          freq = 0.0, quotient=100.0; /* BSA - PMSTA00187 - 080215 */
	RET_CODE        ret=RET_SUCCEED;
	FLAG_T          proviPlanOrAmortFlg = FALSE, yieldInstrFreeFlg=FALSE;
    
    date.time = 0;
	begDate.time = 0;
	endDate.time = 0;


    if (  ((ret = DBA_SelectIOREvt(instrPtr, fromDateTime, tillDateTime, 
			               valDateTime, &ioRTab, &ioRNbr))!=RET_SUCCEED
          ) || (ioRNbr == 0 )
       )
	{
	    MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
			     "FIN_FlowInstrumentRedemptFlow", GET_CODE(instrPtr, A_Instr_Cd), 
			     "issue or redemption parameters");
	    return(RET_SUCCEED);
	}

	/* check if provi plan or amortisation event exist */
	for (*flowNbr=0, i=0; i<ioRNbr && proviPlanOrAmortFlg == FALSE; i++)
	{
	    if (GET_ENUM(ioRTab[i], A_IssueEvt_NatEn) == IssRedmNat_DebtProvi ||
		GET_ENUM(ioRTab[i], A_IssueEvt_NatEn) == IssRedmNat_DebtAmort)
		proviPlanOrAmortFlg = TRUE;
	}

	/* For each redemption event */
	for (*flowNbr=0, i=0; i<ioRNbr; i++)
	{
	    FIN_PeriodUnitNbr((FREQUNIT_ENUM) GET_ENUM(ioRTab[i], A_IssueEvt_FreqUnitEn), 
				     GET_TINYINT(ioRTab[i], A_IssueEvt_Freq), 
				     FreqUnit_Month, &freq);

	    if (GET_DATE(ioRTab[i], A_IssueEvt_EndDate) < fromDateTime.date)
		    continue;

	    begDate.date = GET_DATE(ioRTab[i], A_IssueEvt_BegDate);
	    endDate.date = GET_DATE(ioRTab[i], A_IssueEvt_BegDate);
	    endMFlg = (char) DATE_IsLastInMonth(endDate.date);
	    DATE_Get(endDate.date, (YEAR_T *) NULL, (MONTH_T *) NULL, &svEndD);

	    if (endDate.date == BAD_DATE)
	    {
		    DBA_FreeDynStTab(ioRTab, ioRNbr, A_IssueEvt);  
            MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, "FIN_FlowInstrumentRedemptFlow", 
				     GET_CODE(instrPtr, A_Instr_Cd), "end date");
		    return(RET_FIN_ERR_INVDATA); 
	    }

	    /* Advance in repetitiv event until journal begin date */
	    currPeriod = 1;
	    while (endDate.date < fromDateTime.date && freq > 0)
	    {
		    begDate = endDate;
		    endDate.date = DATE_Move(begDate.date, (int)freq, Month);
		    /* Short month can corrupt day number */
		    DATE_VerifyEndMonth(&endDate.date, svEndD, endMFlg);
		    ++currPeriod;
	    }

	    if (freq == 0.)    /* No repetitive event (one period) */
        {
            endDate.date = GET_DATE(ioRTab[i], A_IssueEvt_EndDate);
        }
	    else if (begDate.date == endDate.date) /* No income at begin date */
	    {
		    endDate.date = DATE_Move(begDate.date, (int)freq, Month);
		    DATE_VerifyEndMonth(&endDate.date, svEndD, endMFlg);
		    ++currPeriod;
	    }

	    /* For each period in current income event (one in case of no repetitive event) */
	    while ((endDate.date <= GET_DATE(ioRTab[i], A_IssueEvt_EndDate)) &&
		       (endDate.date <= tillDateTime.date) && (RET_SUCCEED==ret)
              )
	    {
		    if (((*allocSz) == 0) || ((*flowNbr) >= (*allocSz)-1))
		    {
			    (*allocSz)+=reallocSz;
			    if (((*flowTab) = (DBA_DYNFLD_STP *) REALLOC((*flowTab), 
						      (*allocSz)*sizeof(DBA_DYNFLD_STP))) == (DBA_DYNFLD_STP*)NULL)
		        {	
			        DBA_FreeDynStTab(ioRTab, ioRNbr, A_IssueEvt); 
			        MSG_RETURN(RET_MEM_ERR_ALLOC);
		        }
		    }

   		    if (((*flowTab)[*flowNbr] = ALLOC_DYNST(Flow)) == NULLDYNST)
		    {
		        DBA_FreeDynStTab(ioRTab, ioRNbr, A_IssueEvt);
    		        MSG_RETURN(RET_MEM_ERR_ALLOC);
		    }

		    flowSt = (*flowTab)[*flowNbr];

		    SET_PERCENT(flowSt,  Flow_IoRPrct,      GET_PERCENT(ioRTab[i], A_IssueEvt_ProporPrct));
		    SET_ID(flowSt,       Flow_InstrId,      GET_ID(ioRTab[i], A_IssueEvt_InstrId));
		    SET_CODE(flowSt,     Flow_EvtCd,        GET_CODE(ioRTab[i], A_IssueEvt_Cd));
		    SET_INT(flowSt,      Flow_EvtNbr,       currPeriod); /* REF8844 - LJE - 030327 */
		    SET_FLAG(flowSt,     Flow_ConfirmedFlg, TRUE);

		    SET_DATETIME(flowSt, Flow_BegPayDate,   begDate);
		    SET_DATETIME(flowSt, Flow_EndPayDate,   endDate);
		    SET_PERIOD(flowSt,   Flow_SettlDays,    GET_TINYINT(ioRTab[i], A_IssueEvt_SettlDays));
		    SET_DATETIME(flowSt, Flow_OptimalDate,  endDate);

		    date.date = GET_DATE(flowSt, Flow_OptimalDate); /* conversion ? */
		    SET_DATETIME(flowSt, Flow_OptimalValDate, date);

		    SET_PRICE(flowSt, Flow_Quote, CAST_PRICE(qty * (GET_PERCENT(ioRTab[i], A_IssueEvt_ProporPrct)/100.0)));

		    if (GET_ENUM(ioRTab[i], A_IssueEvt_NatEn) == IssRedmNat_FinalRedm)
		    {
		        if (proviPlanOrAmortFlg == TRUE)
		        {
				    SET_PRICE(flowSt, Flow_Quote, 0.0);
			        SET_PRICE(flowSt, Flow_AmtUnit, 0.0);
		        }
		        else
		        {SET_PRICE(flowSt, Flow_AmtUnit, 1.0);}
		    }
		    else if (GET_ENUM(ioRTab[i], A_IssueEvt_NatEn) == IssRedmNat_DebtAmort)
		    {
			    SET_PRICE(flowSt, Flow_Quote, 0.0);
		        SET_PRICE(flowSt, Flow_AmtUnit, 0.0);
		    }

		    SET_ID(flowSt,          Flow_AmtCurrId,   GET_ID(ioRTab[i], A_IssueEvt_CurrId));
		    SET_NULL_ID(flowSt,     Flow_NewInstrId);
		    SET_NULL_NUMBER(flowSt, Flow_QtyUnit);
		    SET_NULL_ENUM(flowSt,   Flow_OptClassEn);
		    SET_NULL_ENUM(flowSt,   Flow_OptStyleEn);
		    SET_PERCENT(flowSt,     Flow_Proba,       100.0);

		    SET_TINYINT(flowSt,   Flow_Freq, 
		        GET_TINYINT(ioRTab[i], A_IssueEvt_Freq));
		    SET_ENUM(flowSt,      Flow_FreqUnitEn, 
		        GET_ENUM(ioRTab[i], A_IssueEvt_FreqUnitEn));
		    SET_EXCHANGE(flowSt,  Flow_FxdExchRate, 
		        GET_EXCHANGE(ioRTab[i], A_IssueEvt_FxdExchRate));
		    if (DATETIME_CMP(GET_DATETIME(ioRTab[i], A_IssueEvt_EffectiveDate), fromDateTime) < 0)
		    {    SET_FLAG(flowSt, Flow_EffectiveFlg, TRUE);}
		        else
		    {    SET_FLAG(flowSt, Flow_EffectiveFlg, FALSE);}

		    SET_ENUM(flowSt,      Flow_SubNatEn, 
		        FIN_GetIoRFlowSubNat((ISSREDMNAT_ENUM) GET_ENUM(ioRTab[i], A_IssueEvt_NatEn)));

		    SET_NULL_DATE(flowSt,      Flow_ExDate);
		    SET_NULL_NUMBER(flowSt,    Flow_CtdConvFact);
		    SET_NULL_NUMBER(flowSt,    Flow_CtdConvRatio);
		    SET_NULL_ID(flowSt,        Flow_CtdInstrId);
		    SET_FLAG(flowSt,           Flow_PhysicalFlg, FALSE);
		    SET_NULL_TINYINT(flowSt,   Flow_Priority);

            /* ---------- */
            /* new fields */
            /* ---------- */
            if (IS_NULLFLD(ioRTab[i], A_IssueEvt_YieldCurveInstrId) != TRUE)
            { 
                SET_ID(flowSt,  Flow_YieldCurveInstrId, GET_ID(ioRTab[i], A_IssueEvt_YieldCurveInstrId));
            }
            else
            {
              /* default yield Curve */
		      if ((ret = DBA_GetInstrYieldCurve(instrPtr, &yieldInstrPtr, 
                                                &yieldInstrFreeFlg, hierHead, 0)) != RET_SUCCEED)
              {
	            MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
			     "FIN_FlowInstrumentRedemptFlow", GET_CODE(instrPtr, A_Instr_Cd), 
			     "default yield curve is missing !");
              }
              else
              {
                  if (IS_NULLFLD(yieldInstrPtr, A_Instr_Id) != TRUE)
                  {
                      SET_ID(   flowSt,  Flow_YieldCurveInstrId, 
                                GET_ID(yieldInstrPtr, A_Instr_Id));
                  }
                  else
                  {
	                 MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
			         "FIN_FlowInstrumentRedemptFlow", GET_CODE(yieldInstrPtr, A_Instr_Cd), 
			         "YieldCurveInstrId is missing");
                  }
              }
              if (yieldInstrFreeFlg==TRUE) FREE_DYNST(yieldInstrPtr, A_Instr); 
            }

            /* nature of flow */
            SET_ENUM(flowSt,     Flow_NatEn,        FlowNat_Redm); 

            /* Sub_nature of flow */
            switch(GET_ENUM(ioRTab[i], A_IssueEvt_NatEn))
            {
                case    IssRedmNat_CapitalToPay:
		                SET_PRICE(flowSt, Flow_AmtUnit,(-1)*CAST_PRICE(qty * 
                    (GET_PERCENT(ioRTab[i],A_IssueEvt_ProporPrct) / quotient )));

		                SET_PRICE(flowSt, Flow_Quote,  (-1)*CAST_PRICE(qty * 
                            (GET_PERCENT(ioRTab[i], A_IssueEvt_ProporPrct) / quotient )));
                        break;


                case IssRedmNat_FinalRedm:
                    /* REF6004 - AKO - 020218 : for these subnat - quote=0 amtUnit=0 */
                    if ((INSTRNAT_ENUM)GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_EquitySwap ||
                        ((INSTRNAT_ENUM)GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_NonVanillaSwap)
                       ) 
                    {
			            SET_PRICE(flowSt, Flow_Quote, 0.0);
		                SET_PRICE(flowSt, Flow_AmtUnit, 0.0);
                    }
                    else
                    {
		                 SET_PRICE(flowSt, Flow_AmtUnit,(+1)*CAST_PRICE(qty * (GET_PERCENT(ioRTab[i],
                                                        A_IssueEvt_ProporPrct) / quotient )));

		                 SET_PRICE(flowSt, Flow_Quote,(+1)*CAST_PRICE(qty * (GET_PERCENT(ioRTab[i],
                                                            A_IssueEvt_ProporPrct))));
                    }
                    break;

                case IssRedmNat_CapitalToRec:
		             SET_PRICE(flowSt, Flow_AmtUnit,(+1)*CAST_PRICE(qty * (GET_PERCENT(ioRTab[i],
                                                        A_IssueEvt_ProporPrct) / quotient)));
                    /* */
		             SET_PRICE(flowSt, Flow_Quote,(+1)*CAST_PRICE(qty * (GET_PERCENT(ioRTab[i],
                                                        A_IssueEvt_ProporPrct))));
                    break;

                default :
		             SET_PRICE(flowSt, Flow_AmtUnit,(+1)*CAST_PRICE(qty * (GET_PERCENT(ioRTab[i], 
                     A_IssueEvt_ProporPrct) / quotient)));

		             SET_PRICE(flowSt, Flow_Quote,(+1)*CAST_PRICE(qty * (GET_PERCENT(ioRTab[i], 
                     A_IssueEvt_ProporPrct) / quotient)));
                    break;
            }

		    /* Go on next period */
		    (*flowNbr)++;
		    currPeriod++;
		    begDate = endDate;

    	    if (freq == 0.)    /* No repetitive event (one period), stop */
            {endDate.date = DATE_Move(endDate.date, 1, Day);}
    	    else
		    {
		       endDate.date = DATE_Move(begDate.date, (int)freq, Month);
		       DATE_VerifyEndMonth(&endDate.date, svEndD, endMFlg);
		    }
	    }
	}
	DBA_FreeDynStTab(ioRTab, ioRNbr, A_IssueEvt);

	return(ret);
}

/********************************************************************************************
**
**  Function    : FIN_SCEBondFlows()
**
**  Description : Retrieves all possible future flows of a bond and assimilated and money market
**                with sub-nature different FRN.
**                Currently only called for bond with accrual rule equal AccrRule_Sce... 
**                and instrument nature = Bond, CumOption, ConvertBond and MoneyMarket.
**                 
**  Arguments   : fromDateTime  from date
**                tillDateTime  end date
**                valDateTime   reference date     
**                instrPtr      pointer on instrument struct
**                evtDateRule   �vent date rule
**                accrRule      accral rule given to ACCR_INTER
**                flowTab       pointer on flows array which will be 
**                              allocated and filled up
**                flowNbr       pointer on flows number which will be
**                              filled up
**                hierHead      pointer on hierarchy head
**
**  Return      : RET_SUCCEED 
**                RET_MEM_ERR_ALLOC ...
**
**  Creation    : REF9085 - YST - 030522
**
**  Modifi.     : REF11218 - TEB - 050627
**                PMSTA-9483 - RPO - 110127 - send flag to SCE_CallBond_GenrCflw saying whether we found an exchange with replacement flag
**                PMSTA-17422 - 130114 - PMO : Using the accrual rule ACTACT for sinking funds, the quantities of the operations are wrong in Event Generation and Journal of Liquidities
**
**********************************************************************************************/
RET_CODE FIN_SCEBondFlows(DATETIME_T        fromDateTime,  
                        DATETIME_T          tillDateTime,
                        DATETIME_T          valDateTime,
                        DBA_DYNFLD_STP      instrPtr,
                        EVTDATERULE_ENUM    evtDateRule,
						ACCRRULE_ENUM       accrRule,	 /* REF11218 - TEB - 050627 */
                        DBA_DYNFLD_STP      **flowTab,
                        int                 *flowNbr, 
                        DBA_HIER_HEAD_STP    hierHead)
{
	RET_CODE 	    ret = RET_SUCCEED;
    DBA_DYNFLD_STP  newInstrPtr = NULL; 
    FLAG_T          replaceExchangeFound = FALSE;
    int		        i = 0, currentPeriod = 0, allocSz = 0;
    MemoryPool      mp;
    /* < PMSTA-34288 - CHU - 190219 */
    ID_T                calendarId = (ID_T)-1;
    NUMBER_T            flowFxdExchRate = 1.0;
    DBA_DYNFLD_STP* compoTab = NULL, * termEvtTab = NULL, * underInstrTab = NULL, chosenOptionPtr = NULL;
    int					compoNbr = 0, termEvtNbr = 0, underInstrNbr = 0;
    DBA_DYNFLD_STP		currDomainPtr = DBA_GetDomainPtr(DBA_GetConnectNoFromHier(hierHead));
    /* > PMSTA-34288 - CHU - 190219 */

    /* Generate Exchange Flow for Bonds */
	ret = FIN_CreateExchangeFlows(instrPtr, fromDateTime, &tillDateTime, valDateTime, 
				                evtDateRule, &allocSz, flowNbr, flowTab, hierHead);

    if (ret == RET_SUCCEED)
    {
	    /* Replace cum option by ex bond */
	    if ((INSTRNAT_ENUM)GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_CumOption)
	    {
            DBA_DYNFLD_STP domainPtr = NULL;

	        newInstrPtr = mp.allocDynst(FILEINFO,A_Instr);

	        if ((ret = FIN_TreatCumOption(instrPtr, fromDateTime, newInstrPtr, hierHead)) != RET_SUCCEED)
	        {
		        return(ret);
	        }
	        else if ((domainPtr = DBA_GetDomainPtr(DBA_GetConnectNoFromHier(hierHead))) != NULLDYNST)
	        {
                DBA_DYNFLD_STP testInstrPtr = nullptr;
                DBA_GetRecPtrFromHierById(hierHead, GET_ID(newInstrPtr, A_Instr_Id), A_Instr, &testInstrPtr); /* PMSTA-41519  - LJE - 201207 - To avoid duplicate insert into hierarchy */

                if (testInstrPtr == nullptr)
                {
                    if((ret = DBA_AddHierRecord(hierHead, newInstrPtr, 
					                         A_Instr, FALSE, HierAddRec_TestMandatLnk)) != RET_SUCCEED)
                    {
		                return(ret);
                    }
                    mp.removeDynStp(newInstrPtr);
		        }
	        }
	    }
	    else
	    {
	        newInstrPtr = instrPtr;
	    }
 
		/* PMSTA-24645 - DDV - 160905 - Loop on flowTab to check if an exchange with replacmenet exists */
		for (i=0; i<(*flowNbr) && replaceExchangeFound == FALSE; i++)
		{
			if (GET_ENUM((*flowTab)[i], Flow_NatEn) == FlowNat_Exch &&
				GET_FLAG((*flowTab)[i], Flow_ReplaceFlg) == TRUE &&
				GET_ID((*flowTab)[i], Flow_InstrId) != GET_ID((*flowTab)[i], Flow_NewInstrId))
			{
            replaceExchangeFound = TRUE;
			}
		}

        /* Generate Income and Redemption flows for Bond */
	    ret = SCE_CallBond_GenrCflw(fromDateTime, tillDateTime, newInstrPtr, accrRule,	 /* REF11218 - TEB - 050627 */
				                flowTab, flowNbr, allocSz, &currentPeriod, (PTR)hierHead, replaceExchangeFound); /* PMSTA-9483 - RPO - 110127 - pass new flag */
    }

    if (InstrumentNature::isDualCurrencyInvestMoneyMarket(instrPtr) ||
        InstrumentNature::isTripleCurrencyInvestMoneyMarket(instrPtr))
    {
        if ((ret = FIN_STNOptionBasedCompoTermEvtInfo(hierHead, instrPtr, currDomainPtr,
            &compoTab, &compoNbr,
            &termEvtTab, &termEvtNbr,
            &underInstrTab, &underInstrNbr)) != RET_SUCCEED)
        {
            RET_GENFLOWS(ret);
        }

        if (underInstrNbr < 2 /* DCI */ || underInstrNbr > 3 /* TCI */)
        {
            RET_GENFLOWS(ret);
        }

        if ((DBA_GetCalendarFromInstr(instrPtr, &calendarId) != RET_SUCCEED) || (calendarId <= 0))
        {
            GEN_GetApplInfo(ApplSysCalendarId, &calendarId);
        }

        const int nbOption = underInstrNbr - 1;

        if (nbOption == 1) /* DCI - Double Currency Investment */
        {
            flowFxdExchRate = 1.0;
            /* get option instrument in composition */
            for (int j = 0; j < underInstrNbr; j++)
            {
                if (InstrNat_Option == (INSTRNAT_ENUM)GET_ENUM(underInstrTab[j], A_Instr_NatEn))
                {
                    /* Check between Option currency and instrument fixing currency */
                    /* if currencies differ, change Flow_FxdExchRate */
                    if (CMP_ID(GET_ID(instrPtr, A_Instr_FixingCurrId), GET_ID(instrPtr, A_Instr_RefCurrId)) != 0)
                    {
                        flowFxdExchRate = GET_EXCHANGE(underInstrTab[j], A_Instr_RedempPrice);
                    }
                    chosenOptionPtr = underInstrTab[j];
                    break;
                }
            }
        }
        else if (nbOption == 2) /* TCI - Triple Currency Investment */
        {
            flowFxdExchRate = 1.0;
            /* get option instrument in composition */
            for (int j = 0; j < underInstrNbr; j++)
            {
                if (InstrNat_Option == (INSTRNAT_ENUM)GET_ENUM(underInstrTab[j], A_Instr_NatEn))
                {
                    /* Look for same Option currency than instrument fixing currency amongst 2 available */
                    /* if currencies differ, change Flow_FxdExchRate */
                    if (CMP_ID(GET_ID(instrPtr, A_Instr_FixingCurrId), GET_ID(underInstrTab[j], A_Instr_UnderlyInstrId)) == 0)
                    {
                        if (CMP_ID(GET_ID(instrPtr, A_Instr_FixingCurrId), GET_ID(instrPtr, A_Instr_RefCurrId)) != 0)
                        {
                            flowFxdExchRate = GET_EXCHANGE(underInstrTab[j], A_Instr_RedempPrice);
                        }
                        chosenOptionPtr = underInstrTab[j];
                        break;
                    }
                }
            }
        }
    }
    /* > PMSTA-34288 - CHU - 190219 */

	if (ret == RET_SUCCEED)
	{
	    for (i=0; i<*flowNbr; i++)
	    {
            /* < PMSTA-34288 - CHU - 190219 */
            if (InstrumentNature::isDualCurrencyInvestMoneyMarket(instrPtr) ||
                InstrumentNature::isTripleCurrencyInvestMoneyMarket(instrPtr))
            {
                if (IS_NULLFLD(instrPtr, A_Instr_FixingCurrId) == FALSE)
                {
                    /* SET_ID(flow, Flow_NewInstrId, GET_ID(instrPtr, A_Instr_FixingCurrId)); */
                    if (CMP_ID(GET_ID(instrPtr, A_Instr_FixingCurrId), GET_ID(instrPtr, A_Instr_RefCurrId)) != 0)
                    {
                        SET_ID((*flowTab)[i], Flow_AmtCurrId, GET_ID(instrPtr, A_Instr_FixingCurrId));
                        SET_NUMBER((*flowTab)[i], Flow_AmtUnit, 1.0 / flowFxdExchRate);
                    }
                }

                SET_EXCHANGE((*flowTab)[i], Flow_FxdExchRate, flowFxdExchRate);
            }
            /* > PMSTA-34288 - CHU - 190219 */

		    if ( (GET_ENUM((*flowTab)[i],Flow_NatEn) == FlowNat_Redm) || 
		        (GET_ENUM((*flowTab)[i],Flow_NatEn) == FlowNat_Inc))
		    {
                /* PMSTA-17422 - 130114 - PMO */
                if ((FREQUNIT_ENUM)GET_ENUM((*flowTab)[i], Flow_FreqUnitEn) != FreqUnit_None &&
                    GET_NUMBER(             (*flowTab)[i], Flow_IoRPrct)     > 0.)
                {
                    SET_NUMBER((*flowTab)[i], Flow_RefQty, CAST_NUMBER(GET_PERCENT((*flowTab)[i], Flow_IoRPrct) / 100.0));
                }
                else
                {
                    SET_NUMBER((*flowTab)[i], Flow_RefQty, 1.);
                }

                /* PMSTA-17422 - 130114 - PMO */
                if (((FLOWNAT_ENUM)   GET_ENUM((*flowTab)[i], Flow_NatEn)    == FlowNat_Redm           &&
				    (FLOWSUBNAT_ENUM)GET_ENUM((*flowTab)[i], Flow_SubNatEn) == FlowSubNat_Amortisation  )
                    ||
                    ((FLOWNAT_ENUM)   GET_ENUM((*flowTab)[i], Flow_NatEn)    == FlowNat_Inc                    &&
				     (FLOWSUBNAT_ENUM)GET_ENUM((*flowTab)[i], Flow_SubNatEn) == FlowSubNat_AmortisationFxdRate  )
                    )
                {  
                    /* No code */
                }
                else
                {
		            SET_NULL_PERCENT((*flowTab)[i],Flow_IoRPrct);
                }
                if((CMP_ENUM(GET_ENUM(instrPtr, A_Instr_PaidMktConvMethodEn),static_cast<ENUM_T>(InstrMktConvMethodEn::None)!=0) || CMP_ENUM(GET_ENUM(instrPtr, A_Instr_MktConvMethodEn), static_cast<ENUM_T>(InstrMktConvMethodEn::None)) != 0) && (CMP_ENUM(GET_ENUM(instrPtr, A_Instr_SubNatEn), SUBNAT_ENUM::SubNat_PaidSwapFloatLeg)==0 || CMP_ENUM(GET_ENUM(instrPtr, A_Instr_SubNatEn), SUBNAT_ENUM::SubNat_PaidSwapFixedLeg) == 0))
				{
					SET_PRICE((*flowTab)[i], Flow_PaidAmtUnit, GET_PRICE((*flowTab)[i], Flow_AmtUnit));
				}
				else if ((CMP_ENUM(GET_ENUM(instrPtr, A_Instr_PaidMktConvMethodEn), static_cast<ENUM_T>(InstrMktConvMethodEn::None) != 0) || CMP_ENUM(GET_ENUM(instrPtr, A_Instr_MktConvMethodEn), static_cast<ENUM_T>(InstrMktConvMethodEn::None)) != 0) && (CMP_ENUM(GET_ENUM(instrPtr, A_Instr_SubNatEn), SUBNAT_ENUM::SubNat_RecSwapFloatLeg) == 0 || CMP_ENUM(GET_ENUM(instrPtr, A_Instr_SubNatEn), SUBNAT_ENUM::SubNat_RecSwapFixedLeg) == 0))
				{
					SET_PRICE((*flowTab)[i], Flow_ReceivedAmtUnit, GET_PRICE((*flowTab)[i], Flow_AmtUnit));
				}
		        SET_ID((*flowTab)[i],		        Flow_InstrId,   GET_ID(newInstrPtr, A_Instr_Id));
		        SET_ID((*flowTab)[i],		        Flow_AmtCurrId, GET_ID(newInstrPtr, A_Instr_RefCurrId));
		        SET_INT((*flowTab)[i],	    	    Flow_EvtNbr,    currentPeriod+i); 
		        SET_FLAG((*flowTab)[i],		        Flow_ConfirmedFlg, TRUE);
		        SET_PERIOD((*flowTab)[i],           Flow_SettlDays,    0);
		        SET_FLAG((*flowTab)[i],		        Flow_PhysicalFlg,  FALSE);
		        SET_FLAG((*flowTab)[i],		        Flow_EffectiveFlg, FALSE);	
		        SET_FLAG((*flowTab)[i],		        Flow_ReplaceFlg,   FALSE);
		        SET_PERCENT((*flowTab)[i],		    Flow_Proba,        100.0);
		        SET_NULL_ID((*flowTab)[i],		    Flow_NewInstrId);
		        SET_NULL_NUMBER((*flowTab)[i],	    Flow_QtyUnit);
		        SET_NULL_ENUM((*flowTab)[i],	    Flow_OptClassEn);
		        SET_NULL_ENUM((*flowTab)[i],	    Flow_OptStyleEn);
		        SET_NULL_DATE((*flowTab)[i],	    Flow_ExDate);
		        SET_NULL_NUMBER((*flowTab)[i],	    Flow_CtdConvFact);
		        SET_NULL_NUMBER((*flowTab)[i],	    Flow_CtdConvRatio); 
		        SET_NULL_ID((*flowTab)[i],		    Flow_CtdInstrId);
		        SET_NULL_TINYINT((*flowTab)[i],	    Flow_Priority);
		    }
	    }
	}

	RET_GENFLOWS(ret);    
}


/***********************************************************************
**
**  Function    :   FIN_PlanFutureValue ()
**
**  Description :   Estimate the futur value of a plan based on current mkt value and expected return
**
**  Arguments   :   
**                 planDefStp,
**                 hierHead           hierarchy pointer
**                 mktValue           mkt value
**                 mktValueDateParam  Market value's date
**                 expectedReturn     expected return 
**                 date               date at which future value must be estimate
**
**  Return      :   futureValueAmt  estimated future value of the plan
**
**  Return      :   RET_SUCCEED 	or error code
**
**  Creation    :   PMSTA-32209 - DDV - 181019 
**
*************************************************************************/
EXTERN RET_CODE FIN_PlanFutureValue(DBA_HIER_HEAD_STP 	hierHead,
                                    DBA_DYNFLD_STP		planDefStp,
                                    AMOUNT_T            mktValue,
                                    DATE_T              mktValueDateParam,
                                    NUMBER_T            expectedReturn,
                                    DATE_T              objectiveDate,
                                    AMOUNT_T            *futureValueAmt)
{
	DATE_T                     beginDate, endDate;
	DATE_T                     mktValueDate, nextBeginDate;
    double                     yearNbr;
    AMOUNT_T                   amt=0.0;
	int				           planObjectiveNbr=0, investParamNbr=0, freeDepoIdx=0, freeDepositNbr=0, i=0, objectiveIdx=0;
	DBA_DYNFLD_STP             *planObjectiveArray = NULLDYNSTPTR, *investParamArray = NULLDYNSTPTR, *freeDepositArray = NULLDYNSTPTR;
	RET_CODE                   ret = RET_SUCCEED;
	DATE_UNIT_ENUM		       dateFreqUnitE;
	FREQUNIT_ENUM		       targFreqUnitE;
	double                     investFreq, objectiveFreq;
    char                       endMFlg=FALSE;
   	DAY_T                      day, d;
   	MONTH_T                    m;
   	YEAR_T                     y;
    MemoryPool                 mp;
    ACCRRULE_ENUM              accrRule = AccrRule_30E_360;

    if (futureValueAmt == NULL)
    {
        return(RET_GEN_ERR_INVARG);
    }

    *futureValueAmt = 0.0;

    if (mktValueDateParam > 0)
    {
        mktValueDate = mktValueDateParam;
    }
    else
    {
        mktValueDate = DATE_CurrentDate();
    }

    amt = mktValue;

    if (planDefStp == NULLDYNST ||
        (GET_ENUM(planDefStp, A_PlanDefinition_Status) != PlanDefStatus_Validated &&
         GET_ENUM(planDefStp, A_PlanDefinition_Status) != PlanDefStatus_Suspended)
        )
    {
        yearNbr = DATE_Diff(mktValueDate, objectiveDate, Year, accrRule, ZERO_ID);
        amt = mktValue * pow(1+expectedReturn, yearNbr);
        *futureValueAmt = amt;

        return(RET_SUCCEED);
    }

    /* Load all objective hitory from mktValueDate to end date */
   	DBA_DYNFLD_STP selArgStp = mp.allocDynst(FILEINFO, Sel_Arg);

    SET_ID(selArgStp, Sel_Arg_Id1, GET_ID(planDefStp, A_PlanDefinition_Id));
    SET_DATE(selArgStp, Sel_Arg_FromDate, mktValueDate);
    SET_DATE(selArgStp, Sel_Arg_TillDate, objectiveDate);

    DbiConnectionHelper dbiConnHelper;

    if (GET_ENUM(planDefStp, A_PlanDefinition_Status) == PlanDefStatus_Validated)
    {
        dbiConnHelper.dbaSelect(PlanObjectiveHisto, UNUSED, selArgStp, A_PlanObjectiveHisto, &planObjectiveArray, &planObjectiveNbr);

        if (planObjectiveNbr == 0)
        {
            yearNbr = DATE_Diff(mktValueDate, objectiveDate, Year, accrRule, ZERO_ID);
            amt = mktValue * pow(1+expectedReturn, yearNbr);
            *futureValueAmt = amt;

            return(RET_SUCCEED);
        }

        /* Load all inverst param hitory from mktValueDate to end date */
        dbiConnHelper.dbaSelect(PlanInvestParamHisto, UNUSED, selArgStp, A_PlanInvestParamHisto, &investParamArray, &investParamNbr);
    }

    /* load all free deposit from mktValueDate to end date */
    dbiConnHelper.dbaSelect(FreeDepositHisto, UNUSED, selArgStp, A_FreeDepositHisto, &freeDepositArray, &freeDepositNbr);
         
    if (investParamNbr == 0)
    {
        if (freeDepositNbr == 0)
        {
            yearNbr = DATE_Diff(mktValueDate, objectiveDate, Year, accrRule, ZERO_ID);
            amt = mktValue * pow(1+expectedReturn, yearNbr);
        }
        else
        {
            beginDate = mktValueDate;
            for (i=0; i < freeDepositNbr; i++)
            {
                yearNbr = DATE_Diff(beginDate, GET_DATE(freeDepositArray[freeDepoIdx], A_FreeDepositHisto_InvestmentDate), Year, accrRule, ZERO_ID);

                amt *= pow(1+expectedReturn, yearNbr);
                amt += GET_AMOUNT(freeDepositArray[freeDepoIdx], A_FreeDepositHisto_Amount);

                beginDate = GET_DATE(freeDepositArray[freeDepoIdx], A_FreeDepositHisto_InvestmentDate);
            }
        }
    }

    for (i=0; i < investParamNbr; i++)
    {
		dateFreqUnitE = Month;	/* use for the DATE_Move() */
		targFreqUnitE = FreqUnit_Month;

		if ((FREQUNIT_ENUM)GET_ENUM(investParamArray[i], A_PlanInvestParamHisto_InvestFreqUnit) <= FreqUnit_Week)
		{
			dateFreqUnitE = Day; /* use for the DATE_Move() */
			targFreqUnitE = FreqUnit_Day;
		}
		
	    FIN_PeriodUnitNbr((FREQUNIT_ENUM)GET_ENUM(investParamArray[i], A_PlanInvestParamHisto_InvestFreqUnit),
				            GET_TINYINT(investParamArray[i], A_PlanInvestParamHisto_InvestFreq), 
							targFreqUnitE, &investFreq);

        if (investFreq == 0)
        {
	        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, 
			                "FIN_PlanFutureValue", "investment's frequency");

            DBA_FreeDynStTab(planObjectiveArray, planObjectiveNbr, A_PlanObjectiveHisto);
            DBA_FreeDynStTab(investParamArray, investParamNbr, A_PlanInvestParamHisto);
            DBA_FreeDynStTab(freeDepositArray, freeDepositNbr, A_FreeDepositHisto);
            return(RET_GEN_ERR_INVARG);
        }

        endDate = beginDate = GET_DATE(investParamArray[i], A_PlanInvestParamHisto_FirstInvestDate);

	    DATE_Get(beginDate, (YEAR_T*)NULL, (MONTH_T*)NULL, &day);

		if (dateFreqUnitE != Day)
		{
			switch (GET_ENUM(investParamArray[i], A_PlanInvestParamHisto_EndOfMonthConv))
			{
			case InstrEom_Last:
				endMFlg = (char)TRUE;
				break;
			case InstrEom_Same:
				endMFlg = (char)FALSE;
				break;
			case InstrEom_Last360:
				if (endMFlg == TRUE)
					day = 30;
				endMFlg = (char)FALSE;
				break;
			default:
				endMFlg = (char)DATE_IsLastInMonth(endDate);
				break;
			}
		}

        if (i < investParamNbr-1 &&
            GET_DATE(investParamArray[i + 1], A_PlanInvestParamHisto_BeginDate) < objectiveDate)
        {
            nextBeginDate = GET_DATE(investParamArray[i + 1], A_PlanInvestParamHisto_BeginDate);
        }
        else
        {
            nextBeginDate = MAGIC_END_DATE;
        }

	    while (endDate <= nextBeginDate && 
               beginDate < objectiveDate)
        {	
            if (endDate > mktValueDate)
            {
                if (beginDate < mktValueDate)
                {
                    beginDate = mktValueDate;
                }

                while (freeDepoIdx < freeDepositNbr && 
                       GET_DATE(freeDepositArray[freeDepoIdx], A_FreeDepositHisto_InvestmentDate) <= endDate && 
                       GET_DATE(freeDepositArray[freeDepoIdx], A_FreeDepositHisto_InvestmentDate) <= objectiveDate)
                {
                    if (GET_DATE(freeDepositArray[freeDepoIdx], A_FreeDepositHisto_InvestmentDate) >= beginDate)
                    {
                        yearNbr = DATE_Diff(beginDate, GET_DATE(freeDepositArray[freeDepoIdx], A_FreeDepositHisto_InvestmentDate), Year, accrRule, ZERO_ID);

                        amt *= pow(1+expectedReturn, yearNbr);
                        amt += GET_AMOUNT(freeDepositArray[freeDepoIdx], A_FreeDepositHisto_Amount);

                        beginDate = GET_DATE(freeDepositArray[freeDepoIdx], A_FreeDepositHisto_InvestmentDate);

                        amt=CAST_AMOUNT(amt, GET_ID(planObjectiveArray[objectiveIdx], A_PlanObjectiveHisto_CurrId));
                    }

                    freeDepoIdx++;
                }

                if (endDate <= objectiveDate)
                {
                    yearNbr = DATE_Diff(beginDate, endDate, Year, accrRule, ZERO_ID);
                    amt *= pow(1+expectedReturn, yearNbr);

                    /* compute amt to invest */
                    while(objectiveIdx < planObjectiveNbr-1 && 
                          GET_DATE(planObjectiveArray[objectiveIdx + 1], A_PlanObjectiveHisto_BeginDate) < endDate)
                    {
                        objectiveIdx++;
                    }

                    switch (GET_ENUM(planDefStp, A_PlanDefinition_ObjectiveNature))
                    {
                        case PlanDefObjectiveNat_InvestAmount:
                            amt += GET_AMOUNT(planObjectiveArray[objectiveIdx], A_PlanObjectiveHisto_MinAmount);
                            break;
                        case PlanDefObjectiveNat_PeriodAmount:
                            if (GET_ENUM(planObjectiveArray[objectiveIdx], A_PlanObjectiveHisto_PeriodFreqUnit) == GET_ENUM(investParamArray[i], A_PlanInvestParamHisto_InvestFreqUnit) &&
                                GET_TINYINT(planObjectiveArray[objectiveIdx], A_PlanObjectiveHisto_PeriodFreq) == GET_TINYINT(investParamArray[i], A_PlanInvestParamHisto_InvestFreq))
                            {
                                amt += GET_AMOUNT(planObjectiveArray[objectiveIdx], A_PlanObjectiveHisto_MinAmount);
                            }
                            else
                            {
                                FIN_PeriodUnitNbr((FREQUNIT_ENUM)GET_ENUM(planObjectiveArray[objectiveIdx], A_PlanObjectiveHisto_PeriodFreqUnit),
                                    GET_TINYINT(planObjectiveArray[objectiveIdx], A_PlanObjectiveHisto_PeriodFreq),
                                    targFreqUnitE, &objectiveFreq);

                                amt += GET_AMOUNT(planObjectiveArray[objectiveIdx], A_PlanObjectiveHisto_MinAmount) / objectiveFreq * investFreq;
                            }
                            break;

                        case PlanDefObjectiveNat_GlobalAmount:

                            objectiveFreq = DATE_Diff(GET_DATE(planDefStp, A_PlanDefinition_CreationDate), objectiveDate, DATE_FreqUnit2DateUnit(targFreqUnitE), accrRule, ZERO_ID);
                            amt += GET_AMOUNT(planObjectiveArray[objectiveIdx], A_PlanObjectiveHisto_MinAmount) / objectiveFreq * investFreq;
                            break;

                        case PlanDefObjectiveNat_FreeAmount:
                        default:
                            break;

                    }
                }
                else
                {
                    yearNbr = DATE_Diff(beginDate, objectiveDate, Year, accrRule, ZERO_ID);
                    amt *= pow(1+expectedReturn, yearNbr);
                }

                amt=CAST_AMOUNT(amt, GET_ID(planObjectiveArray[objectiveIdx], A_PlanObjectiveHisto_CurrId));
            }

            beginDate = endDate;
		    endDate = DATE_Move(beginDate, (int)investFreq, dateFreqUnitE);		/* PMSTA-32591 - RAK - 180822 - Use unit (Month or Day) */
			if (dateFreqUnitE != Day) 
			{
				DATE_VerifyEndMonth(&endDate, day, endMFlg);

				if (GET_ENUM(investParamArray[i], A_PlanInvestParamHisto_EndOfMonthConv) == InstrEom_Last360 && day == 30)
				{
					DATE_Get(endDate, &y, &m, &d);
					if (m == (MONTH_T)2 && d == (DAY_T)29)
					{
						endDate = DATE_Put(y, m, (DAY_T)28);
					}
				}
			}
	    }
	}

    DBA_FreeDynStTab(planObjectiveArray, planObjectiveNbr, A_PlanObjectiveHisto);
    DBA_FreeDynStTab(investParamArray, investParamNbr, A_PlanInvestParamHisto);
    DBA_FreeDynStTab(freeDepositArray, freeDepositNbr, A_FreeDepositHisto);
    *futureValueAmt = amt;

    return(ret);
}

/************************************************************************
**      END  finlib12.c
*************************************************************************/

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DBABUSEC_C

#include "unidef.h" /* Mandatory */
#include "dba.h"
#include "dbabusec.h"

/************************************************************************
**      Local functions
**
**
**
*************************************************************************/

STATIC RET_CODE DBA_BuildDataProfileCompoBusUnit(DBA_DYNFLD_STP, DbiConnection &, DBA_ACTION_ENUM);
STATIC RET_CODE DBA_BuildDataProfileCompo_BulBatchMode(DBA_ACTION_ENUM);
STATIC RET_CODE DBA_BuildDataProfileCompoBusUnitDotLink(DBA_DYNFLD_STP, DBA_DYNFLD_STP **, int, DBA_DYNFLD_STP *,
	int, DBA_DYNFLD_STP **, DBA_DYNFLD_STP **, int &, int &, std::map<ID_T, int>);
STATIC RET_CODE DBA_BuildDataProfileCompoBusUnitHierLink(DBA_DYNFLD_STP, DBA_DYNFLD_STP *, int, 
	DBA_DYNFLD_STP **, int, DBA_DYNFLD_STP &, std::map<ID_T, int>);
RET_CODE DBA_CallExecuteBatch(DBA_PROC_STP, RequestHelper &, const std::vector<DBA_DYNFLD_STP> &);
STATIC RET_CODE DBA_CallMultiSelectForAllocBusUnitData(DBA_DYNFLD_STP, int [], DBA_DYNFLD_STP*[], const DBA_DYNST_ENUM *outputStLst[],
	DBA_DYNFLD_STP **, DBA_DYNFLD_STP **,	DBA_DYNFLD_STP **, DBA_DYNFLD_STP **);
STATIC FLAG_T	DBA_CheckInDataProfCompoMap(ID_T, ID_T, std::map<ID_T, std::set<ID_T>>&);
STATIC FLAG_T	DBA_CheckInUserDspAuthFlgCompoMap(DBA_DYNFLD_STP, std::map<ID_T, std::pair<FLAG_T, FLAG_T>>&);
STATIC RET_CODE	DBA_buildFineGrainDpCompo(DBA_DYNFLD_STP &, DBA_DYNFLD_STP, DBA_DYNFLD_STP);
STATIC RET_CODE DBA_DeleteDataProfileCompoBusUnit(RequestHelper &, int, DBA_DYNFLD_STP *, std::map<ID_T, std::set<ID_T>>&);
STATIC RET_CODE DBA_DeleteDspFromDataProfCompo(ID_T, std::vector <DBA_DYNFLD_STP>&);


/************************************************************************
*   Function             : DBA_CallMultiSelectForAllocBusUnitData()
*
*   Description          : Selecting and initialising data from business
*						   unit and link data with its data profile compo
*
*   Arguments            :
*
*   Global var. modified : None
*
*   Return               :
*
*   Creation Date        :  PMSTA-48075 - Sathees - 270622
*
*************************************************************************/
RET_CODE DBA_CallMultiSelectForAllocBusUnitData(DBA_DYNFLD_STP businessUnitLinkPtr, int rows[], 
												DBA_DYNFLD_STP *data[], const DBA_DYNST_ENUM *outputStLst[],
												DBA_DYNFLD_STP **busUnitTab, DBA_DYNFLD_STP **busUnitLinkTab,
												DBA_DYNFLD_STP **dataProfCompTab, DBA_DYNFLD_STP **buLinkDpcTab
												)
{
	RET_CODE				retCode = RET_SUCCEED;
	DbiConnectionHelper		dbiConnHelper;

	int		            idxBusUnit = 0,
						idxBusUnitLink = 1,
						idxdataProfileCompo = 2,
						idxbuLinkDpc = 3;

	int					i=0,
						busUnitNbr = 0,
						busUnitLinkNbr = 0,
						dataProfileCompoNbr = 0,
						buLinkDpcNbr = 0;

	RequestHelper   requestHelper(dbiConnHelper);

	if ((retCode = DBA_MultiSelect2(BusinessUnit,
		UNUSED,
		NullDynSt,
		NULL,
		outputStLst,
		data,
		DBA_SET_CONN | DBA_NO_CLOSE, UNUSED,
		rows,
		dbiConnHelper,
		UNUSED)) != RET_SUCCEED)
	{
		MSG_SendMesg(RET_DBA_ERR_NODATA, 0, FILEINFO);
		if (rows[idxBusUnit] > 0)
			DBA_FreeDynStTab(data[idxBusUnit], rows[idxBusUnit], *(outputStLst[idxBusUnit]));

		if (rows[idxBusUnitLink] > 0)
			DBA_FreeDynStTab(data[idxBusUnitLink], rows[idxBusUnitLink], *(outputStLst[idxBusUnitLink]));

		if (rows[idxdataProfileCompo] > 0)
			DBA_FreeDynStTab(data[idxdataProfileCompo], rows[idxdataProfileCompo], *(outputStLst[idxdataProfileCompo]));

		if (rows[idxbuLinkDpc] > 0)
			DBA_FreeDynStTab(data[idxbuLinkDpc], rows[idxbuLinkDpc], *(outputStLst[idxbuLinkDpc]));

		return retCode;
	}

	MSG_LogSrvMesg(UNUSED, UNUSED, "DB_MultiSelect completed for BUL compo begin.");

	busUnitNbr = rows[idxBusUnit];
	busUnitLinkNbr = rows[idxBusUnitLink];
	dataProfileCompoNbr = rows[idxdataProfileCompo];
	buLinkDpcNbr = rows[idxbuLinkDpc];

	if (busUnitNbr == 0 || dataProfileCompoNbr == 0)
	{
		MSG_LogSrvMesg(UNUSED, UNUSED, "The Data Profile Composition failed due to insufficient data.");
		if (busUnitNbr > 0)
			DBA_FreeDynStTab(data[idxBusUnit], rows[idxBusUnit], *(outputStLst[idxBusUnit]));

		if (busUnitLinkNbr > 0)
			DBA_FreeDynStTab(data[idxBusUnitLink], rows[idxBusUnitLink], *(outputStLst[idxBusUnitLink]));

		if (dataProfileCompoNbr > 0)
			DBA_FreeDynStTab(data[idxdataProfileCompo], rows[idxdataProfileCompo], *(outputStLst[idxdataProfileCompo]));

		if (buLinkDpcNbr > 0)
			DBA_FreeDynStTab(data[idxbuLinkDpc], rows[idxbuLinkDpc], *(outputStLst[idxbuLinkDpc]));

		return retCode;
	}

	if (busUnitNbr > 0)
	{
		*busUnitTab = (DBA_DYNFLD_STP*)CALLOC(busUnitNbr, sizeof(DBA_DYNFLD_STP));
		for (i = 0; i < busUnitNbr; i++)
		{
			(*busUnitTab)[i] = data[idxBusUnit][i];
		}
	}

	if (busUnitLinkNbr > 0)
	{
		*busUnitLinkTab = (DBA_DYNFLD_STP*)CALLOC(busUnitLinkNbr, sizeof(DBA_DYNFLD_STP));
		for (i = 0; i < busUnitLinkNbr; i++)
		{
			(*busUnitLinkTab)[i] = data[idxBusUnitLink][i];
		}
	}

	if (dataProfileCompoNbr > 0)
	{
		*dataProfCompTab = (DBA_DYNFLD_STP*)CALLOC(dataProfileCompoNbr, sizeof(DBA_DYNFLD_STP));
		for (i = 0; i < dataProfileCompoNbr; i++)
		{
			(*dataProfCompTab)[i] = data[idxdataProfileCompo][i];
		}
	}

	if (buLinkDpcNbr > 0)
	{
		*buLinkDpcTab = (DBA_DYNFLD_STP*)CALLOC(buLinkDpcNbr, sizeof(DBA_DYNFLD_STP));
		for (i = 0; i < buLinkDpcNbr; i++)
		{
			(*buLinkDpcTab)[i] = data[idxbuLinkDpc][i];
		}
	}

	return retCode;
}

/************************************************************************
*   Function             : DBA_BuildDataProfileCompo_BulBatchMode()
*
*   Description          : DP compo generation for business unit link
*						   using batch
*
*   Arguments            :
*
*   Global var. modified : None
*
*   Return               :
*
*   Creation Date        :  PMSTA-48626 - Sathees - 090522
*
*************************************************************************/
RET_CODE DBA_BuildDataProfileCompo_BulBatchMode(DBA_ACTION_ENUM dbaAction)
{
	RET_CODE				retCode = RET_SUCCEED;
	DbiConnectionHelper		dbiConnHelper;

	int						busUnitNbr = 0,
							busUnitLinkNbr = 0,
							dataProfileCompoNbr = 0,
							buLinkDpcNbr = 0,
							bulIndex = 0,
							locBusUnitNbr = 0,
							publicHierBuNbr = 0,
							interUpwardBUNbr = 0,
							interDownWardBUNbr = 0,
							i = 0, k = 0, l = 0;

	DBA_DYNFLD_STP			*busUnitTab = NULLDYNSTPTR,
							*busUnitLinkTab = NULLDYNSTPTR,
							*dataProfCompTab = NULLDYNSTPTR,
							*buLinkDpcTab = NULLDYNSTPTR,
							*locBusUnitTab = NULLDYNSTPTR,
							*publicHierBuTab = NULLDYNSTPTR,
							*interUpwardBUTab = NULLDYNSTPTR,
							*interDownWardBUTab = NULLDYNSTPTR;

	DBA_DYNFLD_STP			srcBusUnit = NULLDYNST;

	int						idxBusUnit = 0,
							idxBusUnitLink = 1,
							idxdataProfileCompo = 2,
							idxbuLinkDpc = 3;

	FLAG_T              isExistsFlg = FALSE, sameBE = TRUE;

	std::map<ID_T, std::set<ID_T>> dataProfCompoMap;
	std::map<ID_T, std::set<ID_T>> currentBULinkDpcMap;
	std::map<ID_T, int> busUnitIdIndexMap;

	std::vector <DBA_DYNFLD_STP> dataProfileCompoTab;
	MemoryPool			mp;
	DBA_DYNFLD_STP newDataProfileCompoTab = NULLDYNST;

	const DBA_DYNST_ENUM *outputStLst[] = { &A_BusinessUnit,
											&A_BusinessUnitLink,
											&A_DataProfCompo, /* Business Unit Data prof compo */
											&A_DataProfCompo }; /* Business Unit Link related Data prof compo */

	DBA_DYNFLD_STP        *data[] = { NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR };
	int                    rows[] = { 0,0,0,0 };

	RequestHelper   requestHelper(dbiConnHelper);

	if ((retCode = DBA_CallMultiSelectForAllocBusUnitData(NULLDYNST, rows, data, outputStLst,
		&busUnitTab, &busUnitLinkTab, &dataProfCompTab, &buLinkDpcTab)) != RET_SUCCEED)
	{
		return retCode;
	}

	busUnitNbr = rows[idxBusUnit];
	busUnitLinkNbr = rows[idxBusUnitLink];
	dataProfileCompoNbr = rows[idxdataProfileCompo];
	buLinkDpcNbr = rows[idxbuLinkDpc];

	if (busUnitNbr == 0 || dataProfileCompoNbr == 0)
	{
		return retCode;
	}

	/* Inserting the existing Business Unit DB DPC values in dataProfCompoMap */
	if (dataProfileCompoNbr > 0)
	{
		for (i = 0; i < dataProfileCompoNbr; i++)
		{
			std::set<ID_T> dataSecProfs = dataProfCompoMap[GET_ID(dataProfCompTab[i], A_DataProfCompo_DataProfId)];
			dataSecProfs.insert(GET_ID(dataProfCompTab[i], A_DataProfCompo_DataSecuProfId));
			dataProfCompoMap[GET_ID(dataProfCompTab[i], A_DataProfCompo_DataProfId)] = dataSecProfs;
		}
	}

	/* PMSTA-51596 Public or Hierarchy privileged DSP access can propagate to all the BUs 
		even without business unit link presence, Hence it is simplified this way */
	MSG_LogSrvMesg(UNUSED, UNUSED, "Building Public or Hierarchy Priveleges in Business Units.");

	/* Identifying the Business Units which has Hierarchy or Public privilege */
	for (i = 0; i < busUnitNbr; i++)
	{
		if ( (GET_ID(busUnitTab[i], A_BusinessUnit_DspBuHierDataId) > 0) ||
			 (GET_ID(busUnitTab[i], A_BusinessUnit_DspPublicDataId) > 0) )
		{
			publicHierBuTab = (DBA_DYNFLD_STP*)REALLOC(publicHierBuTab, (publicHierBuNbr + 1) * sizeof(DBA_DYNFLD_STP));
			publicHierBuTab[publicHierBuNbr++] = busUnitTab[i];
		}
	}

	mp.owner(publicHierBuTab);
	
	for (i = 0; i < publicHierBuNbr; i++)
	{
		for (k = 0; k < busUnitNbr; k++)
		{
			if (CMP_ID(GET_ID(busUnitTab[k], A_BusinessUnit_Id), GET_ID(publicHierBuTab[i], A_BusinessUnit_Id)) == 0)
				continue;

			/* BU_Hierarchy Privilege */
			if ((GET_ID(publicHierBuTab[i], A_BusinessUnit_DspBuHierDataId) > 0) &&
				(CMP_ID(GET_ID(publicHierBuTab[i], A_BusinessUnit_BusUnitHierId), GET_ID(busUnitTab[k], A_BusinessUnit_BusUnitHierId)) == 0))
			{
				if (DBA_CheckInDataProfCompoMap(GET_ID(busUnitTab[k], A_BusinessUnit_DpId), GET_ID(publicHierBuTab[i], A_BusinessUnit_DspBuHierDataId), dataProfCompoMap))
				{
					newDataProfileCompoTab = mp.allocDynst(FILEINFO, A_DataProfCompo);
					SET_ID(newDataProfileCompoTab, A_DataProfCompo_DataProfId, GET_ID(busUnitTab[k], A_BusinessUnit_DpId));
					SET_ID(newDataProfileCompoTab, A_DataProfCompo_DataSecuProfId, GET_ID(publicHierBuTab[i], A_BusinessUnit_DspBuHierDataId));
					dataProfileCompoTab.push_back(newDataProfileCompoTab);
				}

				if (DBA_CheckInDataProfCompoMap(GET_ID(busUnitTab[k], A_BusinessUnit_DpNoSubId), GET_ID(publicHierBuTab[i], A_BusinessUnit_DspBuHierDataId), dataProfCompoMap))
				{
					newDataProfileCompoTab = mp.allocDynst(FILEINFO, A_DataProfCompo);
					SET_ID(newDataProfileCompoTab, A_DataProfCompo_DataProfId, GET_ID(busUnitTab[k], A_BusinessUnit_DpNoSubId));
					SET_ID(newDataProfileCompoTab, A_DataProfCompo_DataSecuProfId, GET_ID(publicHierBuTab[i], A_BusinessUnit_DspBuHierDataId));
					dataProfileCompoTab.push_back(newDataProfileCompoTab);
				}
			}

			/* Public Privilege */
			if (GET_ID(publicHierBuTab[i], A_BusinessUnit_DspPublicDataId) > 0)
			{
                if (GEN_IsMultiEntity())
                {
					sameBE = TRUE;
					if ((CMP_ID(GET_ID(publicHierBuTab[i], A_BusinessUnit_BusEntityId),
						EV_MasterBusinessEntityId) != 0) &&
						(CMP_ID(GET_ID(busUnitTab[k], A_BusinessUnit_BusEntityId),
							EV_MasterBusinessEntityId) != 0))
					{
						/* For MESI environment, Public scope is with in same Business Entity scope only */
						if (CMP_ID(GET_ID(publicHierBuTab[i], A_BusinessUnit_BusEntityId),
							GET_ID(busUnitTab[k], A_BusinessUnit_BusEntityId)) == 0)
						{
							sameBE = TRUE;
						}
						else
							sameBE = FALSE;
					}
                }

				if (sameBE)
				{
					if (DBA_CheckInDataProfCompoMap(GET_ID(busUnitTab[k], A_BusinessUnit_DpId), GET_ID(publicHierBuTab[i], A_BusinessUnit_DspPublicDataId), dataProfCompoMap))
					{
						newDataProfileCompoTab = mp.allocDynst(FILEINFO, A_DataProfCompo);
						SET_ID(newDataProfileCompoTab, A_DataProfCompo_DataProfId, GET_ID(busUnitTab[k], A_BusinessUnit_DpId));
						SET_ID(newDataProfileCompoTab, A_DataProfCompo_DataSecuProfId, GET_ID(publicHierBuTab[i], A_BusinessUnit_DspPublicDataId));
						dataProfileCompoTab.push_back(newDataProfileCompoTab);
					}

					if (DBA_CheckInDataProfCompoMap(GET_ID(busUnitTab[k], A_BusinessUnit_DpNoSubId), GET_ID(publicHierBuTab[i], A_BusinessUnit_DspPublicDataId), dataProfCompoMap))
					{
						newDataProfileCompoTab = mp.allocDynst(FILEINFO, A_DataProfCompo);
						SET_ID(newDataProfileCompoTab, A_DataProfCompo_DataProfId, GET_ID(busUnitTab[k], A_BusinessUnit_DpNoSubId));
						SET_ID(newDataProfileCompoTab, A_DataProfCompo_DataSecuProfId, GET_ID(publicHierBuTab[i], A_BusinessUnit_DspPublicDataId));
						dataProfileCompoTab.push_back(newDataProfileCompoTab);
					}
				}
			}
		}
	}

	locBusUnitTab = (DBA_DYNFLD_STP*)CALLOC(busUnitNbr, sizeof(DBA_DYNFLD_STP));

	/* Iterate over all the business unit link records for each business unit and keep only the matching business units for further processing*/
	for (i = 0; i < busUnitNbr; i++)
	{
		for (k = 0; k < busUnitLinkNbr; k++)
		{
			if (CMP_ID(GET_ID(busUnitLinkTab[k], A_BusinessUnitLink_BusUnitDestId), GET_ID(busUnitTab[i], A_BusinessUnit_Id)) == 0 ||
				CMP_ID(GET_ID(busUnitLinkTab[k], A_BusinessUnitLink_BusUnitSourceId), GET_ID(busUnitTab[i], A_BusinessUnit_Id)) == 0)
			{
				for (l = 0; l < locBusUnitNbr; l++)
				{
					if (CMP_ID(GET_ID(busUnitTab[i], A_BusinessUnit_Id), GET_ID(locBusUnitTab[l], A_BusinessUnit_Id)) == 0)
					{
						isExistsFlg = TRUE;
						break;
					}
				}
				if (isExistsFlg == FALSE)
				{
					locBusUnitTab[locBusUnitNbr] = busUnitTab[i];
					busUnitIdIndexMap[GET_ID(busUnitTab[i], A_BusinessUnit_Id)] = locBusUnitNbr;
					locBusUnitNbr++;
					break;
				}
				else
				{
					isExistsFlg = FALSE;
					break;
				}
			}
		}
	}

	locBusUnitTab = (DBA_DYNFLD_STP*)REALLOC(locBusUnitTab, locBusUnitNbr * sizeof(DBA_DYNFLD_STP));

	for (bulIndex = 0; bulIndex < busUnitLinkNbr; bulIndex++)
	{
		MSG_LogSrvMesg(UNUSED, UNUSED, "Building DP compo for Business Unit Link ID: %1", IntType, GET_ID(busUnitLinkTab[bulIndex], A_BusinessUnitLink_Id));

		if (static_cast<BusinessUnitLinkNatEn>GET_ENUM(busUnitLinkTab[bulIndex], A_BusinessUnitLink_NatEn) == BusinessUnitLinkNatEn::DottedLink)
		{
			/* DP composition for Dotted link + */
			retCode = DBA_BuildDataProfileCompoBusUnitDotLink(busUnitLinkTab[bulIndex],
				&locBusUnitTab, locBusUnitNbr, busUnitLinkTab, busUnitLinkNbr, &interUpwardBUTab, &interDownWardBUTab,
				interUpwardBUNbr, interDownWardBUNbr, busUnitIdIndexMap);

			mp.owner(interUpwardBUTab);
			mp.owner(interDownWardBUTab);

			/*Add shared DSP's between all parent business units from other hierarchy to all child business units*/
			for (i = 0; i < interUpwardBUNbr; i++)
			{
				for (k = 0; k < interDownWardBUNbr; k++)
				{
					if (GET_ID(interDownWardBUTab[k], A_BusinessUnit_DspSharedDataId) > 0)
					{
						if (DBA_CheckInDataProfCompoMap(GET_ID(interUpwardBUTab[i], A_BusinessUnit_DpId), 
							GET_ID(interDownWardBUTab[k], A_BusinessUnit_DspSharedDataId), dataProfCompoMap))
						{
							newDataProfileCompoTab = mp.allocDynst(FILEINFO, A_DataProfCompo);
							SET_ID(newDataProfileCompoTab, A_DataProfCompo_DataProfId, GET_ID(interUpwardBUTab[i], A_BusinessUnit_DpId));
							SET_ID(newDataProfileCompoTab, A_DataProfCompo_DataSecuProfId, GET_ID(interDownWardBUTab[k], A_BusinessUnit_DspSharedDataId));
							dataProfileCompoTab.push_back(newDataProfileCompoTab);
						}
						else
						{
							std::set<ID_T> dataSecProfs = currentBULinkDpcMap[GET_ID(interUpwardBUTab[i], A_BusinessUnit_DpId)];
							dataSecProfs.insert(GET_ID(interDownWardBUTab[k], A_BusinessUnit_DspSharedDataId));
							currentBULinkDpcMap[GET_ID(interUpwardBUTab[i], A_BusinessUnit_DpId)] = dataSecProfs;
						}
					}
					if (GET_ID(interUpwardBUTab[i], A_BusinessUnit_DspSharedDataId) > 0)
					{
						if (DBA_CheckInDataProfCompoMap(GET_ID(interDownWardBUTab[k], A_BusinessUnit_DpId), 
							GET_ID(interUpwardBUTab[i], A_BusinessUnit_DspSharedDataId), dataProfCompoMap))
						{
							newDataProfileCompoTab = mp.allocDynst(FILEINFO, A_DataProfCompo);
							SET_ID(newDataProfileCompoTab, A_DataProfCompo_DataProfId, GET_ID(interDownWardBUTab[k], A_BusinessUnit_DpId));
							SET_ID(newDataProfileCompoTab, A_DataProfCompo_DataSecuProfId, GET_ID(interUpwardBUTab[i], A_BusinessUnit_DspSharedDataId));
							dataProfileCompoTab.push_back(newDataProfileCompoTab);
						}
						else
						{
							std::set<ID_T> dataSecProfs = currentBULinkDpcMap[GET_ID(interDownWardBUTab[k], A_BusinessUnit_DpId)];
							dataSecProfs.insert(GET_ID(interUpwardBUTab[i], A_BusinessUnit_DspSharedDataId));
							currentBULinkDpcMap[GET_ID(interDownWardBUTab[k], A_BusinessUnit_DpId)] = dataSecProfs;
						}
					}
				}
			}
			/* DP composition for Dotted link - */
		}
		else
		{
			/* DP composition for Hierarchy link + */
			retCode = DBA_BuildDataProfileCompoBusUnitHierLink(busUnitLinkTab[bulIndex], busUnitLinkTab,
				busUnitLinkNbr, &locBusUnitTab, locBusUnitNbr, srcBusUnit, busUnitIdIndexMap);

			for (k = 0; k < locBusUnitNbr; k++)
			{
				if (CMP_ID(GET_ID(locBusUnitTab[k], A_BusinessUnit_Id), GET_ID(srcBusUnit, A_BusinessUnit_Id)) == 0)
					continue;

				/* Private Privilege */
				if (GET_ID(srcBusUnit, A_BusinessUnit_DspPrivateDataId) > 0 &&
					(static_cast<BusinessUnitUserLnkNatEn>GET_ENUM(locBusUnitTab[k], A_BusinessUnit_UserLnkNatEn) == BusinessUnitUserLnkNatEn::Direct))
				{
					if (DBA_CheckInDataProfCompoMap(GET_ID(locBusUnitTab[k], A_BusinessUnit_DpId), GET_ID(srcBusUnit, A_BusinessUnit_DspPrivateDataId), dataProfCompoMap))
					{
						newDataProfileCompoTab = mp.allocDynst(FILEINFO, A_DataProfCompo);
						SET_ID(newDataProfileCompoTab, A_DataProfCompo_DataProfId, GET_ID(locBusUnitTab[k], A_BusinessUnit_DpId));
						SET_ID(newDataProfileCompoTab, A_DataProfCompo_DataSecuProfId, GET_ID(srcBusUnit, A_BusinessUnit_DspPrivateDataId));
						dataProfileCompoTab.push_back(newDataProfileCompoTab);
					}
					else
					{
						std::set<ID_T> dataSecProfs = currentBULinkDpcMap[GET_ID(locBusUnitTab[k], A_BusinessUnit_DpId)];
						dataSecProfs.insert(GET_ID(srcBusUnit, A_BusinessUnit_DspPrivateDataId));
						currentBULinkDpcMap[GET_ID(locBusUnitTab[k], A_BusinessUnit_DpId)] = dataSecProfs;
					}
				}

				/* Shared Privilege */
				if (GET_ID(srcBusUnit, A_BusinessUnit_DspSharedDataId) > 0 &&
					static_cast<BusinessUnitUserLnkNatEn>GET_ENUM(locBusUnitTab[k], A_BusinessUnit_UserLnkNatEn) == BusinessUnitUserLnkNatEn::Direct)
				{
					if (DBA_CheckInDataProfCompoMap(GET_ID(locBusUnitTab[k], A_BusinessUnit_DpId), GET_ID(srcBusUnit, A_BusinessUnit_DspSharedDataId), dataProfCompoMap))
					{
						newDataProfileCompoTab = mp.allocDynst(FILEINFO, A_DataProfCompo);
						SET_ID(newDataProfileCompoTab, A_DataProfCompo_DataProfId, GET_ID(locBusUnitTab[k], A_BusinessUnit_DpId));
						SET_ID(newDataProfileCompoTab, A_DataProfCompo_DataSecuProfId, GET_ID(srcBusUnit, A_BusinessUnit_DspSharedDataId));
						dataProfileCompoTab.push_back(newDataProfileCompoTab);
					}
					else
					{
						std::set<ID_T> dataSecProfs = currentBULinkDpcMap[GET_ID(locBusUnitTab[k], A_BusinessUnit_DpId)];
						dataSecProfs.insert(GET_ID(srcBusUnit, A_BusinessUnit_DspSharedDataId));
						currentBULinkDpcMap[GET_ID(locBusUnitTab[k], A_BusinessUnit_DpId)] = dataSecProfs;
					}
				}
				if (GET_ID(locBusUnitTab[k], A_BusinessUnit_DspSharedDataId) > 0 &&
					static_cast<BusinessUnitUserLnkNatEn>GET_ENUM(locBusUnitTab[k], A_BusinessUnit_UserLnkNatEn) == BusinessUnitUserLnkNatEn::Direct)
				{
					if (DBA_CheckInDataProfCompoMap(GET_ID(srcBusUnit, A_BusinessUnit_DpId), GET_ID(locBusUnitTab[k], A_BusinessUnit_DspSharedDataId), dataProfCompoMap))
					{
						newDataProfileCompoTab = mp.allocDynst(FILEINFO, A_DataProfCompo);
						SET_ID(newDataProfileCompoTab, A_DataProfCompo_DataProfId, GET_ID(srcBusUnit, A_BusinessUnit_DpId));
						SET_ID(newDataProfileCompoTab, A_DataProfCompo_DataSecuProfId, GET_ID(locBusUnitTab[k], A_BusinessUnit_DspSharedDataId));
						dataProfileCompoTab.push_back(newDataProfileCompoTab);
					}
					else
					{
						std::set<ID_T> dataSecProfs = currentBULinkDpcMap[GET_ID(srcBusUnit, A_BusinessUnit_DpId)];
						dataSecProfs.insert(GET_ID(locBusUnitTab[k], A_BusinessUnit_DspSharedDataId));
						currentBULinkDpcMap[GET_ID(srcBusUnit, A_BusinessUnit_DpId)] = dataSecProfs;
					}
				}

				if (static_cast<BusinessUnitUserLnkNatEn>GET_ENUM(locBusUnitTab[k], A_BusinessUnit_UserLnkNatEn) == BusinessUnitUserLnkNatEn::Direct)
					SET_ENUM(locBusUnitTab[k], A_BusinessUnit_UserLnkNatEn, BusinessUnitUserLnkNatEn::None);
			}
			/* DP composition for Hierarchy link - */
		}
	}

	/* Batch InsUpd DataProfCompo of BusinessUnits to DB */
	if (dataProfileCompoTab.size() > 0)
	{
		MSG_LogSrvMesg(UNUSED, UNUSED, "Preparing BUL related DPComposition records to insert/update in DB in batch mode");
		DBA_PROC_STP procedure = DBA_GetStoredProcs(dbaAction, DataProfCompo, UNUSED, A_DataProfCompo, newDataProfileCompoTab, NullDynSt);
		retCode = DBA_CallExecuteBatch(procedure, requestHelper, dataProfileCompoTab);
		MSG_LogSrvMesg(UNUSED, UNUSED, "Batch execution for BUL related DPComposition is completed");
	}

	/* Delete scenario functionality using delta map comparison between buLinkDpcTab and currentBULinkDpcMap */
	if (buLinkDpcNbr > 0)
	{
		DBA_DeleteDataProfileCompoBusUnit(requestHelper, buLinkDpcNbr, buLinkDpcTab, currentBULinkDpcMap);
	}

	FREE(locBusUnitTab);
	FREE(dataProfCompTab);
	FREE(buLinkDpcTab);
	FREE(busUnitLinkTab);
	FREE(busUnitTab);

	DBA_FreeDynStTab(data[idxBusUnit], rows[idxBusUnit], *(outputStLst[idxBusUnit]));
	DBA_FreeDynStTab(data[idxBusUnitLink], rows[idxBusUnitLink], *(outputStLst[idxBusUnitLink]));
	DBA_FreeDynStTab(data[idxdataProfileCompo], rows[idxdataProfileCompo], *(outputStLst[idxdataProfileCompo]));
	DBA_FreeDynStTab(data[idxbuLinkDpc], rows[idxbuLinkDpc], *(outputStLst[idxbuLinkDpc]));

	return retCode;
}

/************************************************************************
*   Function             : DBA_BuildBusinessUnitDpCompo()
*
*   Description          : .
*
*   Arguments            :
*
*   Global var. modified : None
*
*   Return               :
*
*   Creation Date        :  PMSTA-51738 - Sathees - 230123
*
*************************************************************************/
RET_CODE DBA_BuildBusinessUnitDpCompo(DbiConnectionHelper& dbiConnHelper)
{
	RET_CODE		retCode = RET_SUCCEED;
	
	retCode = DBA_BuildDataProfileCompo_BulBatchMode(InsUpd);
	
	return retCode;
}

/************************************************************************
*   Function             : DBA_InsBuDpCompo()
*
*   Description          : .
*
*   Arguments            :
*
*   Global var. modified : None
*
*   Return               :
*
*   Creation Date        :  PMSTA-51738 - Sathees - 230123
*
*************************************************************************/
RET_CODE DBA_InsBuDpCompo(OBJECT_ENUM object, DBA_DYNST_ENUM inputSt, DBA_DYNFLD_STP inputData, DbiConnectionHelper& dbiConnHelper)
{
	RET_CODE		retCode = RET_SUCCEED;
	FLAG_T			activateorgsecurityFlg;
	
	MSG_LogSrvMesg(UNUSED, UNUSED, "Entry Build Data Profile Compo for BUL");

	GEN_GetApplInfo(ApplActivateOrgSecurityFlg, &activateorgsecurityFlg);
	if (activateorgsecurityFlg == TRUE)
	{
		retCode = DBA_BuildBusinessUnitDpCompo(dbiConnHelper);
		if (retCode != RET_SUCCEED)
		{
			MSG_LogSrvMesg(UNUSED, UNUSED, "Error while building DataProfCompo for BUL");
		}
		MSG_LogSrvMesg(UNUSED, UNUSED, "Exit Build Data Profile Compo for BUL");
	}

	return retCode;
}

/************************************************************************
*   Function             : DBA_BuildDataProfileCompo()
*
*   Description          : .
*
*   Arguments            :
*
*   Global var. modified : None
*
*   Return               :
*
*   Creation Date        :  PMSTA-45362 - SRIDHARA - 110621
*
*************************************************************************/
RET_CODE DBA_BuildDataProfileCompo(DBA_DYNFLD_STP InputDataPtr, DBA_ACTION_ENUM dbaAction, OBJECT_ENUM entityRef)
{
	RET_CODE		  retCode = RET_SUCCEED;
	DbiConnection		*dbiConn = nullptr;

	if (GET_DYNSTENUM(InputDataPtr) == A_BusinessUnit)
	{
		if ((retCode = DBA_BuildDataProfileCompoBusUnit(InputDataPtr, *dbiConn, dbaAction)) != RET_SUCCEED)
		{
			DBA_EndConnection(&dbiConn);
			return(retCode);
		}
	}

	else if (GET_DYNSTENUM(InputDataPtr) == A_ApplUser && entityRef == NullEntity)
	{
		DbiConnectionHelper  dbiConnectionHelper(dbiConn, false);
		if ((retCode = DBA_BuildDataProfileCompoApplUser(InputDataPtr, InsUpd, dbiConnectionHelper)) != RET_SUCCEED)
		{
			DBA_EndConnection(&dbiConn);
			return(retCode);
		}
	}

	return retCode;
}

/************************************************************************
*   Function             : DBA_InsUsrDSPInDataProf()
*
*   Description          : .
*
*   Arguments            :
*
*   Global var. modified : None
*
*   Return               :
*
*   Creation Date        :   PMSTA-46782 - SRIDHARA - 12112021
*
*************************************************************************/
RET_CODE DBA_InsUsrDSPInDataProf(DBA_DYNFLD_STP applUser, DBA_ACTION_ENUM dbaAction)
{
	DBA_PROC_STP	    procedure = NULL;
	DbiConnection		*dbiConn = nullptr;
	RET_CODE			retCode = RET_SUCCEED;
	MemoryPool			mp;
	DBA_DYNFLD_STP      aDataProfCompo = mp.allocDynst(FILEINFO, A_DataProfCompo);
	DBA_DYNFLD_STP      sDataProfCompo = mp.allocDynst(FILEINFO, S_DataProfCompo);


	SET_ID(sDataProfCompo, S_DataProfCompo_DataProfId, GET_ID(applUser, A_ApplUser_DataProfileId));
	SET_ID(sDataProfCompo, S_DataProfCompo_DataSecuProfId, GET_ID(applUser, A_ApplUser_DataSecuProfId));
	if ((retCode = DBA_Get2(DataProfCompo, UNUSED, S_DataProfCompo, sDataProfCompo, A_DataProfCompo, &aDataProfCompo,
		UNUSED, UNUSED, UNUSED)) != RET_SUCCEED)
	{
		/* Proceed for Insert as Data_Prof_Compo is not present */
		SET_ID(aDataProfCompo, A_DataProfCompo_DataProfId, GET_ID(applUser, A_ApplUser_DataProfileId));
		SET_ID(aDataProfCompo, A_DataProfCompo_DataSecuProfId, GET_ID(applUser, A_ApplUser_DataSecuProfId));
		SET_FLAG(aDataProfCompo, A_DataProfCompo_AuthUpdFlg, TRUE);

		RequestHelper   requestHelper(dbiConn);
		procedure = DBA_GetStoredProcs(dbaAction, DataProfCompo, UNUSED, A_DataProfCompo, aDataProfCompo, NullDynSt);  /* PMSTA-47339 - SRIDHARA - 071221 */
		requestHelper.startProcedureCallForBatch(procedure);
		requestHelper.setNewRecordForBatch(aDataProfCompo);
		requestHelper.executeBatch();
		DBA_EndConnection(&dbiConn);
		retCode = requestHelper.getLastRetCode();
	}

	return retCode;
}

/************************************************************************
*   Function             : DBA_BuildDataProfileCompoBusUnit()
*
*   Description          : .
*
*   Arguments            :
*
*   Global var. modified : None
*
*   Return               :
*
*   Creation Date        :  PMSTA-45362 - SRIDHARA - 110621
*
*************************************************************************/
STATIC RET_CODE DBA_BuildDataProfileCompoBusUnit(DBA_DYNFLD_STP businessUnit, DbiConnection &dbiConn, DBA_ACTION_ENUM dbaAction)
{
	int        dataSecProfNbr = 2, 
		totDataSecProfNbr = 0,
				l = 0;

	RET_CODE			retCode = RET_SUCCEED;

	std::vector <DBA_DYNFLD_STP> dataProfileCompoTab;

	if (CMP_ID(GET_ID(businessUnit, A_BusinessUnit_DspSharedDataId), 0) != 0)
		dataSecProfNbr++;

	if (CMP_ID(GET_ID(businessUnit, A_BusinessUnit_DspPublicDataId), 0) != 0)
		dataSecProfNbr++;

	if (CMP_ID(GET_ID(businessUnit, A_BusinessUnit_DspBuHierDataId), 0) != 0)
		dataSecProfNbr++;

	totDataSecProfNbr = dataSecProfNbr * 2;

	DBA_DYNFLD_STP *dataProfileCompo = (DBA_DYNFLD_STP*)CALLOC(totDataSecProfNbr, sizeof(DBA_DYNFLD_STP));
	for (int i = 0; i < totDataSecProfNbr; i++)
	{
		if ((dataProfileCompo[i] = ALLOC_DYNST(A_DataProfCompo)) == NULLDYNST)
		{
			DBA_FreeDynStTab(dataProfileCompo, totDataSecProfNbr, A_DataProfCompo);
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}
		SET_FLAG(dataProfileCompo[i], A_DataProfCompo_AuthUpdFlg, 0);
		SET_FLAG(dataProfileCompo[i], A_DataProfCompo_AuthDelFlg, 0);
	}

	if (CMP_ID(GET_ID(businessUnit, A_BusinessUnit_DspPrivateDataId), 0) != 0)
	{
		SET_ID(dataProfileCompo[l], A_DataProfCompo_DataProfId, GET_ID(businessUnit, A_BusinessUnit_DpId));
		SET_ID(dataProfileCompo[l], A_DataProfCompo_DataSecuProfId, GET_ID(businessUnit, A_BusinessUnit_DspPrivateDataId));
		dataProfileCompoTab.push_back(dataProfileCompo[l++]);
		SET_ID(dataProfileCompo[l], A_DataProfCompo_DataProfId, GET_ID(businessUnit, A_BusinessUnit_DpNoSubId));
		SET_ID(dataProfileCompo[l], A_DataProfCompo_DataSecuProfId, GET_ID(businessUnit, A_BusinessUnit_DspPrivateDataId));
		dataProfileCompoTab.push_back(dataProfileCompo[l++]);
	}

	if (CMP_ID(GET_ID(businessUnit, A_BusinessUnit_DspBuHierDataId), 0) != 0)
	{
		SET_ID(dataProfileCompo[l], A_DataProfCompo_DataProfId, GET_ID(businessUnit, A_BusinessUnit_DpId));
		SET_ID(dataProfileCompo[l], A_DataProfCompo_DataSecuProfId, GET_ID(businessUnit, A_BusinessUnit_DspBuHierDataId));
		dataProfileCompoTab.push_back(dataProfileCompo[l++]);
		SET_ID(dataProfileCompo[l], A_DataProfCompo_DataProfId, GET_ID(businessUnit, A_BusinessUnit_DpNoSubId));
		SET_ID(dataProfileCompo[l], A_DataProfCompo_DataSecuProfId, GET_ID(businessUnit, A_BusinessUnit_DspBuHierDataId));
		dataProfileCompoTab.push_back(dataProfileCompo[l++]);
	}

	if (CMP_ID(GET_ID(businessUnit, A_BusinessUnit_DspConfidDataId), 0) != 0)
	{
		SET_ID(dataProfileCompo[l], A_DataProfCompo_DataProfId, GET_ID(businessUnit, A_BusinessUnit_DpId));
		SET_ID(dataProfileCompo[l], A_DataProfCompo_DataSecuProfId, GET_ID(businessUnit, A_BusinessUnit_DspConfidDataId));
		dataProfileCompoTab.push_back(dataProfileCompo[l++]);
		SET_ID(dataProfileCompo[l], A_DataProfCompo_DataProfId, GET_ID(businessUnit, A_BusinessUnit_DpNoSubId));
		SET_ID(dataProfileCompo[l], A_DataProfCompo_DataSecuProfId, GET_ID(businessUnit, A_BusinessUnit_DspConfidDataId));
		dataProfileCompoTab.push_back(dataProfileCompo[l++]);
	}

	if (CMP_ID(GET_ID(businessUnit, A_BusinessUnit_DspSharedDataId), 0) != 0)
	{
		SET_ID(dataProfileCompo[l], A_DataProfCompo_DataProfId, GET_ID(businessUnit, A_BusinessUnit_DpId));
		SET_ID(dataProfileCompo[l], A_DataProfCompo_DataSecuProfId, GET_ID(businessUnit, A_BusinessUnit_DspSharedDataId));
		dataProfileCompoTab.push_back(dataProfileCompo[l++]);
		SET_ID(dataProfileCompo[l], A_DataProfCompo_DataProfId, GET_ID(businessUnit, A_BusinessUnit_DpNoSubId));
		SET_ID(dataProfileCompo[l], A_DataProfCompo_DataSecuProfId, GET_ID(businessUnit, A_BusinessUnit_DspSharedDataId));
		dataProfileCompoTab.push_back(dataProfileCompo[l++]);
	}

	if (CMP_ID(GET_ID(businessUnit, A_BusinessUnit_DspPublicDataId), 0) != 0)
	{
		SET_ID(dataProfileCompo[l], A_DataProfCompo_DataProfId, GET_ID(businessUnit, A_BusinessUnit_DpId));
		SET_ID(dataProfileCompo[l], A_DataProfCompo_DataSecuProfId, GET_ID(businessUnit, A_BusinessUnit_DspPublicDataId));
		dataProfileCompoTab.push_back(dataProfileCompo[l++]);
		SET_ID(dataProfileCompo[l], A_DataProfCompo_DataProfId, GET_ID(businessUnit, A_BusinessUnit_DpNoSubId));
		SET_ID(dataProfileCompo[l], A_DataProfCompo_DataSecuProfId, GET_ID(businessUnit, A_BusinessUnit_DspPublicDataId));
		dataProfileCompoTab.push_back(dataProfileCompo[l]);
	}

	RequestHelper   requestHelper(&dbiConn); // Create RequestHelper by using existing connection

	/* Retrieve a procedure in the object procedures list */
	DBA_PROC_STP procedure = DBA_GetStoredProcs(dbaAction, DataProfCompo, UNUSED, A_DataProfCompo, dataProfileCompo[0], NullDynSt);
	retCode = DBA_CallExecuteBatch(procedure, requestHelper, dataProfileCompoTab);

	DBA_FreeDynStTab(dataProfileCompo, totDataSecProfNbr, A_DataProfCompo);

	return retCode;
}

/************************************************************************
*   Function             : DBA_BuildDataProfileCompoApplUser()
*
*   Description          : .
*
*   Arguments            :
*
*   Global var. modified : None
*
*   Return               :
*
*   Creation Date        :  PMSTA-45362 - SRIDHARA - 110621
*
*************************************************************************/
RET_CODE DBA_BuildDataProfileCompoApplUser(DBA_DYNFLD_STP applUser, DBA_ACTION_ENUM dbaAction, DbiConnectionHelper &dbiConnHelper)
{
	RET_CODE			retCode = RET_SUCCEED;
	int					outputBlkNb = 2;
	int					m = 0, n = 0, i = 0, j = 0, k = 0, l = 0;
	CODE_T				dataProfCode;

	DBA_PROC_STP		procedure = NULL;

	DBA_DYNFLD_STP      aDataProfile = NULLDYNST;
	DBA_DYNFLD_STP      sDataProfile = NULLDYNST;

	ID_T                currDataProfId;

	FLAG_T              isUserDataProfCreated = FALSE;
	FLAG_T				pushToDelDpcTab = FALSE;
	FLAG_T				fgaRuleAdded = FALSE;

	std::map<ID_T, std::pair<FLAG_T, FLAG_T>>  userDpDspUpdDelMap;

	const DBA_DYNST_ENUM *outputStLst[] = { &A_BusinessUnit,
											&A_DataProfCompo,
											&A_DataProfCompo,
											&A_DataProfCompo };

	DBA_DYNFLD_STP        *data[] = { NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR };
	int                    rows[] = { 0,0,0,0 };

	int		busUnitNbr = 0, dataProfileCompoNbr = 0, fullAccessDataProfileCompoNbr = 0, userDpcNbr = 0;
	int		idxBusUnit = 0, idxdataProfileCompo = 1, idxFullAccessDataProfileCompo = 2, idxUserDpc = 3;


	const DBA_DYNST_ENUM *outputStLst1[] = { &A_UserEntityAccessRight,
											&UearEntity};

	DBA_DYNFLD_STP        *uearData[] = { NULLDYNSTPTR, NULLDYNSTPTR };
	int                    uearRows[] = { 0,0 };

	OBJECT_ENUM     objectEnum;
	MemoryPool mp;

	DBA_DYNFLD_STP aDataProfCompo = NULL;

	int		uearNbr = 0, entityNbr = 0;
	int		idxUear = 0, idxEntity = 1;
	int		uearIter = 0, entityIter = 0;

	std::vector <DBA_DYNFLD_STP> dataProfileCompoTab;
	std::vector <DBA_DYNFLD_STP> delDataProfileCompoTab;
	std::vector <DBA_DYNFLD_STP> fineGrainDataProfileCompoTab;

	FLAG_T entitlementServiceFlg = FALSE;
	GEN_GetApplInfo(ApplEntitlementServiceFlg, &entitlementServiceFlg);

	if ((retCode = DBA_MultiSelect2(ApplUser, UNUSED, A_ApplUser, applUser,
		outputStLst, data,
		DBA_SET_CONN | DBA_NO_CLOSE, UNUSED,
		rows, dbiConnHelper, UNUSED)) != RET_SUCCEED)
	{
		MSG_SendMesg(RET_DBA_ERR_NODATA, 0, FILEINFO);
		return retCode;
	}

	RequestHelper   requestHelper(dbiConnHelper); /* Create RequestHelper by using existing connection */

	busUnitNbr = rows[idxBusUnit];
	dataProfileCompoNbr = rows[idxdataProfileCompo];
	fullAccessDataProfileCompoNbr = rows[idxFullAccessDataProfileCompo];
	userDpcNbr = rows[idxUserDpc]; /* Existing DB values of an user DP compo */

	/* Building user DP's DSP and its <AuthUpdFlg,AuthDelFlg> values map if exist */
	for (n = 0; n < userDpcNbr; n++)
	{
		userDpDspUpdDelMap[GET_ID(data[idxUserDpc][n], A_DataProfCompo_DataSecuProfId)] = 
			std::make_pair(GET_FLAG(data[idxUserDpc][n], A_DataProfCompo_AuthUpdFlg),
							GET_FLAG(data[idxUserDpc][n], A_DataProfCompo_AuthDelFlg));
	}

	if ((busUnitNbr == 0 || dataProfileCompoNbr == 0) && (userDpcNbr == 0))
	{
		MSG_LogSrvMesg(UNUSED, UNUSED, "BuildDataProfileCompoApplUser : Atleast One entry of Membership entry must be exist for this user %1",
			CodeType, GET_CODE(applUser, A_ApplUser_Cd));
		return retCode;
	}

	currDataProfId = GET_ID(applUser, A_ApplUser_DataProfileId);

	if (busUnitNbr >= 1)
	{
		if ((aDataProfile = ALLOC_DYNST(A_DataProf)) == NULLDYNST)
		{
			DBA_MultiFree(data, outputStLst, rows, outputBlkNb);
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		if ((sDataProfile = ALLOC_DYNST(S_DataProf)) == NULLDYNST)
		{
			DBA_MultiFree(data, outputStLst, rows, outputBlkNb);
			FREE_DYNST(aDataProfile, A_DataProf);
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		strcpy(dataProfCode, GET_CODE(applUser, A_ApplUser_Cd));
		strcat(dataProfCode, "_DataProf");

		SET_CODE(sDataProfile, S_DataProf_Cd, dataProfCode);

		retCode = dbiConnHelper.dbaGet(DataProf, UNUSED, sDataProfile, &aDataProfile);

		if (IS_NULLFLD(aDataProfile, A_DataProf_Id) == TRUE && retCode != RET_SUCCEED)
		{
			SET_CODE(aDataProfile, A_DataProf_Cd, dataProfCode);
			SET_ID(aDataProfile, A_DataProf_ApplUserId, GET_ID(applUser, A_ApplUser_Id));

			/* PMSTA-47339 - SRIDHARA - 08122021 */
			procedure = DBA_GetStoredProcs(Insert, DataProf, UNUSED, A_DataProf, aDataProfile, NullDynSt);
			requestHelper.startProcedureCallForBatch(procedure);
			requestHelper.setNewRecordForBatch(aDataProfile);
			requestHelper.executeBatch();
			if ((retCode = requestHelper.getLastRetCode()) != RET_SUCCEED)
			{
				MSG_SendMesg(RET_DBA_ERR_NODATA, 0, FILEINFO);
				DBA_MultiFree(data, outputStLst, rows, outputBlkNb);
				FREE_DYNST(aDataProfile, A_DataProf);
				FREE_DYNST(sDataProfile, S_DataProf);
				return retCode;
			}
			isUserDataProfCreated = TRUE;
		}

		SET_CODE(sDataProfile, S_DataProf_Cd, GET_CODE(aDataProfile, A_DataProf_Cd));
		if (((isUserDataProfCreated == TRUE) &&
			(dbiConnHelper.dbaGet(DataProf, UNUSED, sDataProfile, &aDataProfile) != RET_SUCCEED)) ||
				(retCode != RET_SUCCEED))
		{
			MSG_SendMesg(RET_DBA_ERR_NODATA, 0, FILEINFO);
			DBA_MultiFree(data, outputStLst, rows, outputBlkNb);
			FREE_DYNST(aDataProfile, A_DataProf);
			FREE_DYNST(sDataProfile, S_DataProf);
			return retCode;
		}

		SET_ID(applUser, A_ApplUser_DataProfileId, GET_ID(aDataProfile, A_DataProf_Id));

		for (i = 0; i < dataProfileCompoNbr; i++)
		{
			for (j = i + 1; j < dataProfileCompoNbr; j++)
			{
				/* If any duplicate found */
				if (CMP_ID(GET_ID(data[idxdataProfileCompo][i], A_DataProfCompo_DataSecuProfId), GET_ID(data[idxdataProfileCompo][j], A_DataProfCompo_DataSecuProfId)) == 0)
				{
					/* Delete the current duplicate element */
					for (k = j; k < dataProfileCompoNbr - 1; k++)
					{
						SET_ID(data[idxdataProfileCompo][k], A_DataProfCompo_DataSecuProfId, GET_ID(data[idxdataProfileCompo][k + 1], A_DataProfCompo_DataSecuProfId));
					}

					/* Decrement size after removing duplicate element */
					dataProfileCompoNbr--;

					/* If shifting of elements occur then don't increment j */
					j--;
				}
			}
		}

		procedure = DBA_GetStoredProcs(dbaAction, DataProfCompo, UNUSED, A_DataProfCompo, data[idxdataProfileCompo][0], NullDynSt);
	}
	
	for (m = 0; m < dataProfileCompoNbr; m++)
	{
		SET_ID(data[idxdataProfileCompo][m], A_DataProfCompo_DataProfId, GET_ID(applUser, A_ApplUser_DataProfileId));
		
		for (n = 0; n < fullAccessDataProfileCompoNbr; n++)
		{
			if (CMP_ID(GET_ID(data[idxdataProfileCompo][m], A_DataProfCompo_DataSecuProfId),
				GET_ID(data[idxFullAccessDataProfileCompo][n], A_DataProfCompo_DataSecuProfId)) == 0)
			{
				/* PMSTA-45962 - SRIDHARA - 08102021 */
				for (l = 0; l < busUnitNbr; l++)
				{
					if ((CMP_ID(GET_ID(data[idxdataProfileCompo][m], A_DataProfCompo_DataSecuProfId),
						(GET_ID(data[idxBusUnit][l], A_BusinessUnit_DspPrivateDataId))) == 0) ||
						(CMP_ID(GET_ID(data[idxdataProfileCompo][m], A_DataProfCompo_DataSecuProfId),
						(GET_ID(data[idxBusUnit][l], A_BusinessUnit_DspBuHierDataId))) == 0) ||
							(CMP_ID(GET_ID(data[idxdataProfileCompo][m], A_DataProfCompo_DataSecuProfId),
						(GET_ID(data[idxBusUnit][l], A_BusinessUnit_DspConfidDataId))) == 0) ||
								(CMP_ID(GET_ID(data[idxdataProfileCompo][m], A_DataProfCompo_DataSecuProfId),
						(GET_ID(data[idxBusUnit][l], A_BusinessUnit_DspSharedDataId))) == 0) ||
									(CMP_ID(GET_ID(data[idxdataProfileCompo][m], A_DataProfCompo_DataSecuProfId),
						(GET_ID(data[idxBusUnit][l], A_BusinessUnit_DspPublicDataId))) == 0))
					{
						SET_FLAG(data[idxdataProfileCompo][m], A_DataProfCompo_AuthUpdFlg, TRUE);
						SET_FLAG(data[idxdataProfileCompo][m], A_DataProfCompo_AuthDelFlg, TRUE);
					}
				}
			}
		}

		/* Delta computation with existing DB values of an user DP compo to do Insert */
		if (DBA_CheckInUserDspAuthFlgCompoMap(data[idxdataProfileCompo][m], userDpDspUpdDelMap))
			dataProfileCompoTab.push_back(data[idxdataProfileCompo][m]);
	}

	/* FGA + */
	if ( (entitlementServiceFlg == FALSE) && (userDpcNbr > 0) )
	{
		if ((retCode = DBA_MultiSelect2(ApplUser, UNUSED, S_ApplUser, applUser,
			outputStLst1, uearData,
			DBA_SET_CONN | DBA_NO_CLOSE, UNUSED,
			uearRows, dbiConnHelper, UNUSED)) != RET_SUCCEED)
		{
			MSG_SendMesg(RET_DBA_ERR_NODATA, 0, FILEINFO);
			return retCode;
		}

		uearNbr = uearRows[idxUear];
		entityNbr = uearRows[idxEntity];
		
		/* If FGA rules existing for the user, then the loop will run atleast once */
		for (uearIter = 0; uearIter < uearNbr; uearIter++)
		{
			fgaRuleAdded = FALSE;
			/* Handle Access Deny scenario on prior so that delete will happen even if it was existing */
			if ( (UserEntityAccessRightAccessRightEn::Deny == 
				static_cast<UserEntityAccessRightAccessRightEn>GET_ENUM(uearData[idxUear][uearIter],
					A_UserEntityAccessRight_AccessRightEn)) &&
				(UserEntityAccessRightOverrideEn::Complete ==
				static_cast<UserEntityAccessRightOverrideEn>GET_ENUM(uearData[idxUear][uearIter],
					A_UserEntityAccessRight_OverrideEn)) )
			{
				/* This is for simple for "Complete" scenarios - Just ignore adding DSP2 in DP */
				continue;
			}

			DBA_GetObjectEnum(GET_DICT(uearData[idxUear][uearIter], A_UserEntityAccessRight_EntityDictId), &objectEnum);

			switch (GET_OBJECT_CST(objectEnum))
			{
			case DataSecuProfCst:
				/* This is for DSP - object addition */
				if (userDpDspUpdDelMap.find(
					GET_ID(uearData[idxUear][uearIter], A_UserEntityAccessRight_ObjId)) !=
					userDpDspUpdDelMap.end())
				{
					/* Same DSP already present in User DP */
					if ((UserEntityAccessRightOverrideEn::Complete ==
						static_cast<UserEntityAccessRightOverrideEn>GET_ENUM(uearData[idxUear][uearIter],
							A_UserEntityAccessRight_OverrideEn)) &&
						(userDpDspUpdDelMap[GET_ID(uearData[idxUear][uearIter],
							A_UserEntityAccessRight_ObjId)].first) &&
						(userDpDspUpdDelMap[GET_ID(uearData[idxUear][uearIter],
							A_UserEntityAccessRight_ObjId)].second))
					{
						/* It's with Complete mode. Nothing to do */
						break;
					}
					if ((UserEntityAccessRightOverrideEn::Override ==
						static_cast<UserEntityAccessRightOverrideEn>GET_ENUM(uearData[idxUear][uearIter],
							A_UserEntityAccessRight_OverrideEn)) &&
							(UserEntityAccessRightAccessRightEn::Deny ==
								static_cast<UserEntityAccessRightAccessRightEn>GET_ENUM(uearData[idxUear][uearIter],
									A_UserEntityAccessRight_AccessRightEn)))
					{
						/* Override Deny! - Remove DSP from User's DP */
						for (n = 0; n < userDpcNbr; n++)
						{
							if (GET_ID(data[idxUserDpc][n], A_DataProfCompo_DataSecuProfId) ==
								GET_ID(uearData[idxUear][uearIter], A_UserEntityAccessRight_ObjId))
							{
								delDataProfileCompoTab.push_back(data[idxUserDpc][n]);
								break;
							}
						}
						break;
					}
					/* Remove from the vector which it would have got added again from Coarse grain */
					if (dataProfileCompoTab.size() > 0)
					{
						DBA_DeleteDspFromDataProfCompo(GET_ID(uearData[idxUear][uearIter],
							A_UserEntityAccessRight_ObjId), dataProfileCompoTab);
					}
				}
				else
				{
					/* DSP not present in User's DP */
					if (UserEntityAccessRightAccessRightEn::Deny ==
								static_cast<UserEntityAccessRightAccessRightEn>GET_ENUM(uearData[idxUear][uearIter],
									A_UserEntityAccessRight_AccessRightEn))
					{
						/* Remove from the vector which it would have got added again from Coarse grain */
						if (dataProfileCompoTab.size() > 0)
						{
							DBA_DeleteDspFromDataProfCompo(GET_ID(uearData[idxUear][uearIter], 
								A_UserEntityAccessRight_ObjId),	dataProfileCompoTab);
						}
						break;
					}
				}
				aDataProfCompo = mp.allocDynst(FILEINFO, A_DataProfCompo);
				DBA_buildFineGrainDpCompo(aDataProfCompo, uearData[idxUear][uearIter], applUser);
				SET_ID(aDataProfCompo, A_DataProfCompo_DataSecuProfId, 
					GET_ID(uearData[idxUear][uearIter], A_UserEntityAccessRight_ObjId));
				fgaRuleAdded = TRUE;
				break;

			case PtfCst:
			case InstrCst:
			case ThirdCst:
				/* Find Ptf/Instr/Third_Party row and process DSPs */
				for (entityIter = 0; entityIter < entityNbr; entityIter++)
				{
					if (GET_DICT(uearData[idxUear][uearIter], A_UserEntityAccessRight_EntityDictId) ==
						GET_DICT(uearData[idxEntity][entityIter], UearEntity_DictId))
					{
						if ((GET_ID(uearData[idxEntity][entityIter], UearEntity_Id)) ==
							(GET_ID(uearData[idxUear][uearIter], A_UserEntityAccessRight_ObjId)))
							break;
					}
				}
				/* DSP2 not assigned for this object. Hence, No processing */
				if (GET_ID(uearData[idxEntity][entityIter], UearEntityDSP2_Id) == NULL)
					break;
				if (userDpDspUpdDelMap.find(
					GET_ID(uearData[idxEntity][entityIter], UearEntityDSP_Id)) !=
					userDpDspUpdDelMap.end())
				{
					/* Object's DSP already present in User DP. Process the scenarios */
					if (UserEntityAccessRightAccessRightEn::Deny ==
						static_cast<UserEntityAccessRightAccessRightEn>GET_ENUM(uearData[idxUear][uearIter],
							A_UserEntityAccessRight_AccessRightEn))
					{
						/* Negative rules handling will be done later along with RUD to RU/RD */
						break;
					}
					/* If previous rule privilege has Read-Only - then RUD/RU/RD can be added */
					if ( !(userDpDspUpdDelMap[GET_ID(uearData[idxEntity][entityIter],
						 UearEntityDSP_Id)].first) &&
						 !(userDpDspUpdDelMap[GET_ID(uearData[idxEntity][entityIter],
							UearEntityDSP_Id)].second) &&
						(UserEntityAccessRightAccessRightEn::Read != 
							static_cast<UserEntityAccessRightAccessRightEn>GET_ENUM(
							uearData[idxUear][uearIter],A_UserEntityAccessRight_AccessRightEn)) )
					{
						aDataProfCompo = mp.allocDynst(FILEINFO, A_DataProfCompo);
						DBA_buildFineGrainDpCompo(aDataProfCompo, uearData[idxUear][uearIter], applUser);
						SET_ID(aDataProfCompo, A_DataProfCompo_DataSecuProfId,
							GET_ID(uearData[idxEntity][entityIter], UearEntityDSP2_Id));
						fgaRuleAdded = TRUE;
					}
				}
				else
				{
					/* Object's DSP not present in User DP */
					aDataProfCompo = mp.allocDynst(FILEINFO, A_DataProfCompo);
					DBA_buildFineGrainDpCompo(aDataProfCompo, uearData[idxUear][uearIter], applUser);
					SET_ID(aDataProfCompo, A_DataProfCompo_DataSecuProfId, 
							GET_ID(uearData[idxEntity][entityIter], UearEntityDSP2_Id));
					fgaRuleAdded = TRUE;
				}
				break;

			default:
				/* Other business entities are not yet scoped under FGA */
				break;
			}

			if (fgaRuleAdded)
			{
				/* Insert/Update in DB only if required */
				if (DBA_CheckInUserDspAuthFlgCompoMap(aDataProfCompo, userDpDspUpdDelMap))
					dataProfileCompoTab.push_back(aDataProfCompo);
				/* FGA specific dp compo list to use for delete delta scenario */
				fineGrainDataProfileCompoTab.push_back(aDataProfCompo);
			}
		}
	}
	/* FGA - */

	/* Delta computation with existing DB values of an user DP compo to do Delete */
	for (n = 0; n < userDpcNbr; n++)
	{
		pushToDelDpcTab = TRUE;
		for (m = 0; m < dataProfileCompoNbr; m++)
		{
			if (CMP_ID(GET_ID(data[idxdataProfileCompo][m], A_DataProfCompo_DataSecuProfId),
				GET_ID(data[idxUserDpc][n], A_DataProfCompo_DataSecuProfId)) == 0)
			{
				pushToDelDpcTab = FALSE;
				break;
			}
		}
		/* FGA + */
		auto iter = fineGrainDataProfileCompoTab.begin();
		while (iter != fineGrainDataProfileCompoTab.end())
		{
			if (CMP_ID(GET_ID(*iter, A_DataProfCompo_DataSecuProfId),
				GET_ID(data[idxUserDpc][n], A_DataProfCompo_DataSecuProfId)) == 0)
			{
				pushToDelDpcTab = FALSE;
				break;
			}
			++iter;
		}
		/* FGA - */
		if (pushToDelDpcTab)
			delDataProfileCompoTab.push_back(data[idxUserDpc][n]);
	}

	/* PMSTA-47339 - SRIDHARA - 12112021 */
	if (dataProfileCompoTab.size() > 0)
	{
		retCode = DBA_CallExecuteBatch(procedure, requestHelper, dataProfileCompoTab);
	}

	if (delDataProfileCompoTab.size() > 0)
	{
		procedure = DBA_GetStoredProcs(Delete, DataProfCompo, UNUSED, A_DataProfCompo, data[idxUserDpc][0], NullDynSt);
		retCode = DBA_CallExecuteBatch(procedure, requestHelper, delDataProfileCompoTab);
	}

	if (CMP_ID(GET_ID(applUser, A_ApplUser_DataProfileId), currDataProfId) != 0)
	{
		DBA_Update2(ApplUser, UNUSED, A_ApplUser, applUser, dbiConnHelper);
	}


	DBA_MultiFree(data, outputStLst, rows, outputBlkNb);
	DBA_MultiFree(uearData, outputStLst1, uearRows, outputBlkNb);
	FREE_DYNST(aDataProfile, A_DataProf);
	FREE_DYNST(sDataProfile, S_DataProf);
	return retCode;
}

/************************************************************************
*   Function             : DBA_BuildPublicSharedHierDsp()
*
*   Description          : .
*
*   Arguments            :
*
*   Global var. modified : None
*
*   Return               :
*
*   Creation Date        :  PMSTA-48631 - Sathees - 19082022
*
*************************************************************************/
RET_CODE DBA_BuildPublicSharedHierDsp(DBA_DYNFLD_STP aBusinessUnit)
{
	RET_CODE		 retCode = RET_SUCCEED;

	int     busUnitLinkNbr = 0;
	int		idxBusUnitLink = 0;
	int		   outputBlkNb = 1;

	const DBA_DYNST_ENUM *outputStLst[] = { &A_BusinessUnitLink };

	DBA_DYNFLD_STP        *data[] = { NULLDYNSTPTR };
	int                    rows[] = { 0 };

	DbiConnectionHelper		dbiConnHelper;

	if ((retCode = DBA_MultiSelect2(BusinessUnit, UNUSED, A_BusinessUnit, aBusinessUnit,
			outputStLst, data, DBA_SET_CONN | DBA_NO_CLOSE, UNUSED,
			rows, dbiConnHelper, UNUSED)) != RET_SUCCEED)
	{
		MSG_SendMesg(RET_DBA_ERR_NODATA, 0, FILEINFO);
		return retCode;
	}

	busUnitLinkNbr = rows[idxBusUnitLink];

	if (busUnitLinkNbr >= 0)
	{
		retCode = DBA_BuildDataProfileCompo_BulBatchMode(InsUpd);
	}

	DBA_MultiFree(data, outputStLst, rows, outputBlkNb); 

	return retCode;
}


/************************************************************************
*   Function             : DBA_createPublicSharedHierDSPSecuredObj()
*
*   Description          : .
*
*   Arguments            :
*
*   Global var. modified : None
*
*   Return               :
*
*   Creation Date        :  PMSTA- - DBA_createPublicSharedHierDSPSecuredObj - 24102022
*
*************************************************************************/
RET_CODE DBA_createPublicSharedHierDSPSecuredObj(DBA_DYNFLD_STP securedObj, DBA_DYNFLD_STP aBusinessUnit, OBJECT_ENUM entityRef)
{
	RET_CODE		 retCode = RET_SUCCEED;
	CODE_T			 dataSecuProfCode;

	MemoryPool mp;

	DbiConnectionHelper		dbiConnHelper;
	RequestHelper   requestHelper(dbiConnHelper);
	DBA_PROC_STP	procedure = NULL;

	DBA_DYNFLD_STP      aDataSecuProfile = mp.allocDynst(FILEINFO, A_DataSecuProf);
	DBA_DYNFLD_STP      sDataSecuProfile = mp.allocDynst(FILEINFO, S_DataSecuProf);

	DBA_DYNFLD_STP      aDataProfCompo = mp.allocDynst(FILEINFO, A_DataProfCompo);
	DBA_DYNFLD_STP      sDataProfCompo = mp.allocDynst(FILEINFO, S_DataProfCompo);

	DICT_ATTRIB_STP dictAttribStp = NULL;
	ID_T            busUnitId = 0;

	dictAttribStp = DBA_GetAttributeBySqlName(entityRef, "business_unit_id");
	if (dictAttribStp != NULL &&
		!IS_NULLFLD(securedObj, dictAttribStp->progN))
	{
		busUnitId = GET_ID(securedObj, dictAttribStp->progN);
	}

	strcpy(dataSecuProfCode, GET_CODE(aBusinessUnit, A_BusinessUnit_Cd));

	dictAttribStp = DBA_GetAttributeBySqlName(entityRef, "privilege_e");
	if (dictAttribStp != NULL &&
		!IS_NULLFLD(securedObj, dictAttribStp->progN))
	{
		if (DictAttributeTemplatePrivilegeEn::Public == static_cast<DictAttributeTemplatePrivilegeEn> GET_ENUM(securedObj, dictAttribStp->progN))
			strcat(dataSecuProfCode, "_public");
		else if(DictAttributeTemplatePrivilegeEn::Shared == static_cast<DictAttributeTemplatePrivilegeEn> GET_ENUM(securedObj, dictAttribStp->progN))
			strcat(dataSecuProfCode, "_shared");
		else
			strcat(dataSecuProfCode, "_buhierarchy");
	}

	SET_CODE(sDataSecuProfile, S_DataSecuProf_Cd, dataSecuProfCode);
	retCode = DBA_Get2(DataSecuProf, UNUSED, S_DataSecuProf, sDataSecuProfile, A_DataSecuProf, &aDataSecuProfile, UNUSED, UNUSED, UNUSED);

	if (IS_NULLFLD(aDataSecuProfile, A_DataSecuProf_Id) == FALSE && retCode == RET_SUCCEED)
	{
		return retCode;
	}
	else
	{
		SET_CODE(aDataSecuProfile, A_DataSecuProf_Cd, dataSecuProfCode);
		procedure = DBA_GetStoredProcs(Insert, DataSecuProf, UNUSED, A_DataSecuProf, aDataSecuProfile, NullDynSt);  /* PMSTA-47339 - SRIDHARA - 12112021 */
		requestHelper.startProcedureCallForBatch(procedure);
		requestHelper.setNewRecordForBatch(aDataSecuProfile);
		requestHelper.executeBatch();
		if ((retCode = requestHelper.getLastRetCode()) != RET_SUCCEED)
		{
			MSG_SendMesg(RET_DBA_ERR_NODATA, 0, FILEINFO);
			return retCode;
		}
	}

	if ((retCode = DBA_Get2(DataSecuProf, UNUSED, S_DataSecuProf, sDataSecuProfile, A_DataSecuProf, &aDataSecuProfile,
		UNUSED, UNUSED, UNUSED)) != RET_SUCCEED)
	{
		MSG_SendMesg(RET_DBA_ERR_NODATA, 0, FILEINFO);
		return retCode;
	}

	if (DictAttributeTemplatePrivilegeEn::Public == static_cast<DictAttributeTemplatePrivilegeEn> GET_ENUM(securedObj, dictAttribStp->progN))
	{
		SET_ID(aBusinessUnit, A_BusinessUnit_DspPublicDataId, GET_ID(aDataSecuProfile, A_DataSecuProf_Id));
	}
	else if (DictAttributeTemplatePrivilegeEn::Shared == static_cast<DictAttributeTemplatePrivilegeEn> GET_ENUM(securedObj, dictAttribStp->progN))
	{
		SET_ID(aBusinessUnit, A_BusinessUnit_DspSharedDataId, GET_ID(aDataSecuProfile, A_DataSecuProf_Id));
	}
	else
	{
		SET_ID(aBusinessUnit, A_BusinessUnit_DspBuHierDataId, GET_ID(aDataSecuProfile, A_DataSecuProf_Id));
	}

	procedure = DBA_GetStoredProcs(Update, BusinessUnit, UNUSED, A_BusinessUnit, aBusinessUnit, NullDynSt);
	requestHelper.startProcedureCallForBatch(procedure);
	requestHelper.setNewRecordForBatch(aBusinessUnit);
	requestHelper.executeBatch();
	if ((retCode = requestHelper.getLastRetCode()) != RET_SUCCEED)
	{
		MSG_SendMesg(RET_DBA_ERR_NODATA, 0, FILEINFO);
		return retCode;
	}

	SET_ID(sDataProfCompo, S_DataProfCompo_DataProfId,	   GET_ID(aBusinessUnit, A_BusinessUnit_DpId));
	SET_ID(sDataProfCompo, S_DataProfCompo_DataSecuProfId, GET_ID(aBusinessUnit, A_BusinessUnit_DspPrivateDataId));
	if ((retCode = DBA_Get2(DataProfCompo, UNUSED, S_DataProfCompo, sDataProfCompo, A_DataProfCompo, &aDataProfCompo,
		UNUSED, UNUSED, UNUSED)) != RET_SUCCEED)
	{
		MSG_SendMesg(RET_DBA_ERR_NODATA, 0, FILEINFO);
		return retCode;
	}

	SET_ID(aDataProfCompo, A_DataProfCompo_DataProfId, GET_ID(aBusinessUnit, A_BusinessUnit_DpId));
	SET_ID(aDataProfCompo, A_DataProfCompo_DataSecuProfId, GET_ID(aDataSecuProfile, A_DataSecuProf_Id));
	procedure = DBA_GetStoredProcs(InsUpd, DataProfCompo, UNUSED, A_DataProfCompo, aDataProfCompo, NullDynSt);
	requestHelper.startProcedureCallForBatch(procedure);
	requestHelper.setNewRecordForBatch(aDataProfCompo);
	requestHelper.executeBatch();
	if ((retCode = requestHelper.getLastRetCode()) != RET_SUCCEED)
	{
		MSG_SendMesg(RET_DBA_ERR_NODATA, 0, FILEINFO);
		return retCode;
	}
	
	/* PMSTA-46400 - SRIDHARA - 27092021 - Adding created Public/shared DSP into DataProfileNoSubsidiary as well */
	SET_ID(aDataProfCompo, A_DataProfCompo_DataProfId, GET_ID(aBusinessUnit, A_BusinessUnit_DpNoSubId));
	procedure = DBA_GetStoredProcs(InsUpd, DataProfCompo, UNUSED, A_DataProfCompo, aDataProfCompo, NullDynSt);
	requestHelper.startProcedureCallForBatch(procedure);
	requestHelper.setNewRecordForBatch(aDataProfCompo);
	requestHelper.executeBatch();
	if ((retCode = requestHelper.getLastRetCode()) != RET_SUCCEED)
	{
		MSG_SendMesg(RET_DBA_ERR_NODATA, 0, FILEINFO);
		return retCode;
	}
	
	return retCode;
}

/************************************************************************
*   Function             : DBA_BuildDataProfileCompoBusUnitDotLink()
*
*   Description          : deriving the dp composition during business unit dotted link
*
*   Arguments            :
*
*   Global var. modified : None
*
*   Return               :
*
*   Creation Date        :  PMSTA-45362 - Kramadevi - 20072021
*
*************************************************************************/
STATIC RET_CODE DBA_BuildDataProfileCompoBusUnitDotLink(
	DBA_DYNFLD_STP  businessUnitLinkPtr, DBA_DYNFLD_STP **busUnitTab, int busUnitNbr,
	DBA_DYNFLD_STP *busUnitLinkTab, int busUnitLinkNbr, DBA_DYNFLD_STP **interUpwardBUTab,
	DBA_DYNFLD_STP **interDownWardBUTab, int &interUpwardBUNbr, int &interDownWardBUNbr,
	std::map<ID_T, int> busUnitIdIndexMap)
{
	RET_CODE            retCode = RET_SUCCEED;
	int                 i = 0, k = 0, 
						childHierBUCount = 0, childLevelBUCount = 0, childCount = 0,
						childHierIter = 0, grandParentCount = 1;

	ID_T                parentBusinessId = 0,
		childBusinessId = 0,
		dottedChildBusinessId = 0,
		srcBusinessId = 0,
		destBusinessId = 0,
		srcBusUnitHierId = 0,
		destBusUnitHierId = 0;

	MemoryPool mp;

	FLAG_T				srcBusUnitFoundFlg = FALSE;

	DBA_DYNFLD_STP      *childHierBusUnit = NULLDYNSTPTR;
	childHierBusUnit = (DBA_DYNFLD_STP*)CALLOC(busUnitNbr, sizeof(DBA_DYNFLD_STP));
	mp.owner(childHierBusUnit);
		
	/*Destination BU id is considered as firstParent*/
	destBusinessId = GET_ID(businessUnitLinkPtr, A_BusinessUnitLink_BusUnitDestId);
	srcBusinessId = GET_ID(businessUnitLinkPtr, A_BusinessUnitLink_BusUnitSourceId);

	parentBusinessId = GET_ID(businessUnitLinkPtr, A_BusinessUnitLink_BusUnitDestId);
	childBusinessId = GET_ID(businessUnitLinkPtr, A_BusinessUnitLink_BusUnitSourceId);

	interUpwardBUNbr = 0;
	interDownWardBUNbr = 0;

	*interUpwardBUTab = NULLDYNSTPTR;
	*interDownWardBUTab = NULLDYNSTPTR;
	*interUpwardBUTab = (DBA_DYNFLD_STP*)CALLOC(busUnitNbr, sizeof(DBA_DYNFLD_STP));
	*interDownWardBUTab = (DBA_DYNFLD_STP*)CALLOC(busUnitNbr, sizeof(DBA_DYNFLD_STP));

	/* Set the parent business unit as upward direction and proceed further for parental findings */
	k = busUnitIdIndexMap[parentBusinessId];
	(*interUpwardBUTab)[interUpwardBUNbr++] = (*busUnitTab)[k];

	/* Find if there is a parental hierarchy and proceed further */
	/* PMSTA-53150 - Sathees - 230710 */
	while (grandParentCount > 0)
	{
		grandParentCount--;
		for (i = 0; i < busUnitLinkNbr; i++)
		{
			if ((CMP_ID(GET_ID(busUnitLinkTab[i], A_BusinessUnitLink_BusUnitSourceId), parentBusinessId) == 0)
				&& (static_cast<BusinessUnitLinkNatEn>GET_ENUM(busUnitLinkTab[i], A_BusinessUnitLink_NatEn) != BusinessUnitLinkNatEn::DottedLink))
			{
				parentBusinessId = GET_ID(busUnitLinkTab[i], A_BusinessUnitLink_BusUnitDestId);
				grandParentCount++;
				k = busUnitIdIndexMap[parentBusinessId];
				/* Inter-Upward */
				(*interUpwardBUTab)[interUpwardBUNbr++] = (*busUnitTab)[k];
				break;
			}
		}
	}

	/*By Iterating over each BU link records, find out the grand parent and great grand parent and thus find the actual first parent*/
	for (i = 0; i < busUnitLinkNbr; i++)
	{
		/* Find if there is a child hierarchy and proceed further */
		if ((CMP_ID(GET_ID(busUnitLinkTab[i], A_BusinessUnitLink_BusUnitDestId), childBusinessId) == 0)
			&& (static_cast<BusinessUnitLinkNatEn>GET_ENUM(busUnitLinkTab[i], A_BusinessUnitLink_NatEn) != BusinessUnitLinkNatEn::DottedLink))
		{
			dottedChildBusinessId = GET_ID(busUnitLinkTab[i], A_BusinessUnitLink_BusUnitSourceId);
			for (k = 0; k < busUnitNbr; k++)
			{
				if (srcBusUnitFoundFlg == FALSE && CMP_ID(GET_ID((*busUnitTab)[k], A_BusinessUnit_Id), srcBusinessId) == 0)
				{
					/* Inter-Downward */
					srcBusUnitHierId = GET_ID((*busUnitTab)[k], A_BusinessUnit_BusUnitHierId);
					(*interDownWardBUTab)[interDownWardBUNbr++] = (*busUnitTab)[k];
					srcBusUnitFoundFlg = TRUE;
				}
				if ((CMP_ID(GET_ID((*busUnitTab)[k], A_BusinessUnit_Id), dottedChildBusinessId)) == 0)
				{
					/* Inter-Downward */
					(*interDownWardBUTab)[interDownWardBUNbr++] = (*busUnitTab)[k];
					childHierBusUnit[childHierBUCount++] = (*busUnitTab)[k];
				}
			}
		}
		
	}
	/* Downward side child hierarchy processing */
	if (childHierBUCount > 0)
	{
		childLevelBUCount = childHierBUCount;
		while (childLevelBUCount > 0)
		{
			childCount = 0;
			for (childHierIter = 0; childHierIter < childHierBUCount; childHierIter++)
			{
				for (i = 0; i < busUnitLinkNbr; i++)
				{
					if ( (CMP_ID(GET_ID(busUnitLinkTab[i], A_BusinessUnitLink_BusUnitDestId),
							GET_ID(childHierBusUnit[childHierIter], A_BusinessUnit_Id)) == 0)
						&& (static_cast<BusinessUnitLinkNatEn>GET_ENUM(busUnitLinkTab[i], A_BusinessUnitLink_NatEn)
							!= BusinessUnitLinkNatEn::DottedLink))
					{
						dottedChildBusinessId = GET_ID(busUnitLinkTab[i], A_BusinessUnitLink_BusUnitSourceId);
						k = busUnitIdIndexMap[dottedChildBusinessId];
						/* Inter-Downward */
						(*interDownWardBUTab)[interDownWardBUNbr++] = (*busUnitTab)[k];
						childHierBusUnit[childCount++] = (*busUnitTab)[k];
						childLevelBUCount++;
					}
				}
				childLevelBUCount--;
			}
			childHierBUCount = childLevelBUCount;
		}
	}

	/* If Dotted Link source has no child, still the source BU needs to be considered for interDownward linkage */
	if (((interUpwardBUNbr > 0) && (interDownWardBUNbr == 0)) ||
		((interUpwardBUNbr == 0) && (interDownWardBUNbr == 0)))
	{
		k = busUnitIdIndexMap[srcBusinessId];
		/* Inter-Downward */
		srcBusUnitHierId = GET_ID((*busUnitTab)[k], A_BusinessUnit_BusUnitHierId);
		(*interDownWardBUTab)[interDownWardBUNbr++] = (*busUnitTab)[k];
	}

	/* If Dotted Link destination has no child or parent, still the source BU needs to be considered for interUpward linkage */
	if ((interUpwardBUNbr == 0) && (interDownWardBUNbr > 0))
	{
		k = busUnitIdIndexMap[destBusinessId];
		/* Inter-Upward */
		destBusUnitHierId = GET_ID((*busUnitTab)[k], A_BusinessUnit_BusUnitHierId);
		(*interUpwardBUTab)[interUpwardBUNbr++] = (*busUnitTab)[k];
	}

	*interUpwardBUTab = (DBA_DYNFLD_STP*)REALLOC(*interUpwardBUTab, interUpwardBUNbr * sizeof(DBA_DYNFLD_STP));
	*interDownWardBUTab = (DBA_DYNFLD_STP*)REALLOC(*interDownWardBUTab, interDownWardBUNbr * sizeof(DBA_DYNFLD_STP));

	return retCode;
}

/************************************************************************
*   Function             : DBA_CheckInDataProfCompoMap()
*
*   Description          : Returns TRUE if the DP compo is not present
*						   in dataProfCompMap
*
*   Arguments            :
*
*   Global var. modified : None
*
*   Return               :
*
*   Creation Date        :  PMSTA-48626 - Sathees - 260522
*
*************************************************************************/
STATIC FLAG_T DBA_CheckInDataProfCompoMap(ID_T dataProfId, ID_T dataSecProfId, std::map<ID_T, std::set<ID_T>> &dataProfCompoMap)
{
	std::map<ID_T, std::set<ID_T>>::iterator it;
	std::set<ID_T>::iterator itSet;

	it = dataProfCompoMap.find(dataProfId);
	if (it != dataProfCompoMap.end())
	{
		/* dataProfId present in map */
		std::set<ID_T> dataSecProfs = dataProfCompoMap[dataProfId];
		itSet = dataSecProfs.find(dataSecProfId);
		if (itSet != dataSecProfs.end())
		{
			/* dataSecProfId present in map */
			return FALSE;
		}
	}

	/* dataProfCompo not present in map */
	return TRUE;
}

/************************************************************************
*   Function             : DBA_BuildDataProfileCompoBusUnitHierLink()
*
*   Description          : Hierarchy Link Processing Logic
*						   
*
*   Arguments            :
*
*   Global var. modified : None
*
*   Return               :
*
*   Creation Date        :  PMSTA-48626 - Sathees - 190522
*
*************************************************************************/
STATIC RET_CODE DBA_BuildDataProfileCompoBusUnitHierLink(DBA_DYNFLD_STP businessUnitLinkPtr, DBA_DYNFLD_STP *busUnitLinkTab,
	int busUnitLinkNbr, DBA_DYNFLD_STP **locBusUnitTab, int locBusUnitNbr, 
	DBA_DYNFLD_STP &srcBusUnit, std::map<ID_T, int> busUnitIdIndexMap)
{
	RET_CODE            retCode = RET_SUCCEED;
	ID_T                firstParentBUId;
	int					i = 0, k = 0;
	int					grandParentCount = 1;

	/*Iterate over all the resulted Business Units and obtain the Business_Unit_Source_id's corresponding Business Unit record.
	check if shared and public DSP's are defined for that BU. if yes increase the DSP nbr accordingly*/
	for (k = 0; k < locBusUnitNbr; k++)
	{
		if ((CMP_ID(GET_ID((*locBusUnitTab)[k], A_BusinessUnit_Id), GET_ID(businessUnitLinkPtr, A_BusinessUnitLink_BusUnitSourceId)) == 0))
		{
			srcBusUnit = (*locBusUnitTab)[k];
			continue;
		}
		if ((CMP_ID(GET_ID((*locBusUnitTab)[k], A_BusinessUnit_Id), GET_ID(businessUnitLinkPtr, A_BusinessUnitLink_BusUnitDestId)) == 0))
		{
			SET_ENUM((*locBusUnitTab)[k], A_BusinessUnit_UserLnkNatEn, BusinessUnitUserLnkNatEn::Direct);
			continue;
		}
	}

	/*Destination BU id is considered as firstParent*/
	firstParentBUId = GET_ID(businessUnitLinkPtr, A_BusinessUnitLink_BusUnitDestId);

	/*By Iterating over each BU link records, find out the grand parent and great grand parent and thus find the actual first parent*/
	/* PMSTA-53150 - Sathees - 230710 */
	while (grandParentCount)
	{
		grandParentCount--;
		for (i = 0; i < busUnitLinkNbr; i++)
		{
			/*check if the parent has any grand parent, if yes copy the grand parent and this is repeated to find out the first parent*/
			if ((CMP_ID(GET_ID(busUnitLinkTab[i], A_BusinessUnitLink_BusUnitSourceId), firstParentBUId) == 0) &&
				(static_cast<BusinessUnitLinkNatEn>GET_ENUM(busUnitLinkTab[i], A_BusinessUnitLink_NatEn) != BusinessUnitLinkNatEn::DottedLink))
			{
				firstParentBUId = GET_ID(busUnitLinkTab[i], A_BusinessUnitLink_BusUnitDestId);
				grandParentCount++;
				/*finding the grand parents and great grand parents of the destination business unit and updating the UserLnkNatEn,
				so we can assign the Private and shared DSP's of the source business unit to these parents easily*/
				k = busUnitIdIndexMap[firstParentBUId];
				SET_ENUM((*locBusUnitTab)[k], A_BusinessUnit_UserLnkNatEn, BusinessUnitUserLnkNatEn::Direct);
				break;
			}
		}
	}

	return retCode;
}

/************************************************************************
*   Function             : DBA_DeleteDataProfileCompoBusUnit()
*
*   Description          : Deletes some DataProfCompo of Business Unit 
*							post the active link is deleted
*
*   Arguments            :
*
*   Global var. modified : None
*
*   Return               :
*
*   Creation Date        :  PMSTA-51804 - Sathees - 31/01/2023
*
*************************************************************************/
STATIC RET_CODE DBA_DeleteDataProfileCompoBusUnit(RequestHelper &requestHelper, int buLinkDpcNbr,
	DBA_DYNFLD_STP *buLinkDpcTab, std::map<ID_T, std::set<ID_T>> &currentBULinkDpcMap)
{
	RET_CODE            retCode = RET_SUCCEED;
	int					i;
	
	std::vector <DBA_DYNFLD_STP> dataProfileCompoTab;

	for (i = 0; i < buLinkDpcNbr; i++)
	{
		if (DBA_CheckInDataProfCompoMap(GET_ID(buLinkDpcTab[i], A_DataProfCompo_DataProfId),
			GET_ID(buLinkDpcTab[i], A_DataProfCompo_DataSecuProfId), currentBULinkDpcMap))
		{
			MSG_LogSrvMesg(UNUSED, UNUSED, "Adding record in Delete List,DP id: %1", 
				IntType, GET_ID(buLinkDpcTab[i], A_DataProfCompo_DataProfId));
			dataProfileCompoTab.push_back(buLinkDpcTab[i]);
		}
	}

	if (dataProfileCompoTab.size() > 0)
	{
		DBA_PROC_STP procedure = DBA_GetStoredProcs(Delete, DataProfCompo, UNUSED, A_DataProfCompo, buLinkDpcTab[0], NullDynSt);
		retCode = DBA_CallExecuteBatch(procedure, requestHelper, dataProfileCompoTab);
	}

	return retCode;
}

/************************************************************************
*   Function             : DBA_CallExecuteBatch()
*
*   Description          : DB call for Batch commit execution
*
*   Arguments            :
*
*   Global var. modified : None
*
*   Return               :
*
*   Creation Date        :  PMSTA-52818 - Sathees - 041623
*
*************************************************************************/
RET_CODE DBA_CallExecuteBatch(DBA_PROC_STP                 procedure,
                                     RequestHelper&               requestHelper,
                                     const std::vector <DBA_DYNFLD_STP> & dataProfileCompoTab)
{
	RET_CODE            retCode = RET_SUCCEED;

	requestHelper.startProcedureCallForBatch(procedure);

	auto iter = dataProfileCompoTab.cbegin();
	while (iter != dataProfileCompoTab.cend())
	{
		requestHelper.setNewRecordForBatch(*iter);
		++iter;
	}

	requestHelper.executeBatch();
	retCode = requestHelper.getLastRetCode();

	return retCode;
}

/************************************************************************
*   Function             : DBA_CheckInUserDspAuthFlgCompoMap()
*
*   Description          : Returns TRUE if the DSP flag pair compo is not present
*						   in dataProfCompMap
*
*   Arguments            :
*
*   Global var. modified : None
*
*   Return               :
*
*   Creation Date        :  WEALTH - Sathees - 180224
*
*************************************************************************/
STATIC FLAG_T DBA_CheckInUserDspAuthFlgCompoMap(DBA_DYNFLD_STP aDataProfCompo,
	std::map<ID_T, std::pair<FLAG_T, FLAG_T>> &userDspCompoMap)
{
	std::map<ID_T, std::pair<FLAG_T, FLAG_T>>::iterator it;

	it = userDspCompoMap.find(GET_ID(aDataProfCompo, A_DataProfCompo_DataSecuProfId));
	if (it != userDspCompoMap.end())
	{
		/* dspId present in map */
		if ( ( GET_FLAG(aDataProfCompo, A_DataProfCompo_AuthUpdFlg) == 
			userDspCompoMap[GET_ID(aDataProfCompo, A_DataProfCompo_DataSecuProfId)].first ) &&
			 ( GET_FLAG(aDataProfCompo, A_DataProfCompo_AuthDelFlg) == 
			userDspCompoMap[GET_ID(aDataProfCompo, A_DataProfCompo_DataSecuProfId)].second) )
		{
			/* Same UpdDel Flag values present in map */
			return FALSE;
		}
	}

	/* dsp and same flag not present in map */
	return TRUE;
}

/************************************************************************
*   Function             : DBA_buildFineGrainDpCompo()
*
*   Description          : Build FGA DP compo list
*
*   Arguments            :
*
*   Global var. modified : None
*
*   Return               :
*
*   Creation Date        :  WEALTH - Sathees - 190224
*
*************************************************************************/
STATIC RET_CODE DBA_buildFineGrainDpCompo(DBA_DYNFLD_STP &aDataProfCompo,
	DBA_DYNFLD_STP uearData, DBA_DYNFLD_STP applUser)
{
	RET_CODE            retCode = RET_SUCCEED;

	SET_ID(aDataProfCompo, A_DataProfCompo_DataProfId, GET_ID(applUser, A_ApplUser_DataProfileId));
	
	if (UserEntityAccessRightAccessRightEn::ReadUpdate == static_cast<UserEntityAccessRightAccessRightEn>GET_ENUM(uearData, A_UserEntityAccessRight_AccessRightEn))
	{
		SET_FLAG(aDataProfCompo, A_DataProfCompo_AuthUpdFlg, TRUE);
	}
	else if (UserEntityAccessRightAccessRightEn::ReadDelete == static_cast<UserEntityAccessRightAccessRightEn>GET_ENUM(uearData, A_UserEntityAccessRight_AccessRightEn))
	{
		SET_FLAG(aDataProfCompo, A_DataProfCompo_AuthDelFlg, TRUE);
	}
	else if (UserEntityAccessRightAccessRightEn::ReadUpdateDelete == static_cast<UserEntityAccessRightAccessRightEn>GET_ENUM(uearData, A_UserEntityAccessRight_AccessRightEn))
	{
		SET_FLAG(aDataProfCompo, A_DataProfCompo_AuthUpdFlg, TRUE);
		SET_FLAG(aDataProfCompo, A_DataProfCompo_AuthDelFlg, TRUE);
	}

	return retCode;
}

/************************************************************************
*   Function             : DBA_DeleteDspFromDataProfCompo()
*
*   Description          : Deletes DSP from dataProfCompo Vector if exist
*
*   Arguments            :
*
*   Global var. modified : None
*
*   Return               :
*
*   Creation Date        :  WEALTH - Sathees - 270224
*
*************************************************************************/
STATIC RET_CODE DBA_DeleteDspFromDataProfCompo(ID_T dspToBeDenied, 
	std::vector <DBA_DYNFLD_STP>& dataProfileCompoTab)
{
	RET_CODE            retCode = RET_SUCCEED;

	auto iter = dataProfileCompoTab.begin();
	while (iter != dataProfileCompoTab.end())
	{
		if (CMP_ID(GET_ID(*iter, A_DataProfCompo_DataSecuProfId),
			dspToBeDenied) == 0)
		{
			dataProfileCompoTab.erase(iter);
			break;
		}
		++iter;
	}

	return retCode;
}

/************************************************************************
**   END  dbabusec.c                                                    **
*************************************************************************/

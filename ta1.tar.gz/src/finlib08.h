/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef FINLIB08_H
#define FINLIB08_H

/************************************************************************
**      BEGIN : Global variables & external definitions attached to finlib08.c
*************************************************************************/
#ifdef  EXTERN
    #undef  EXTERN
#endif
#ifdef  FINLIB08_C
    #define	EXTERN
#else
    #define EXTERN extern
#endif

EXTERN RET_CODE FIN_StratCreateESERecomList(DBA_HIER_HEAD_STP, int, DBA_DYNFLD_STP);
EXTERN RET_CODE FIN_StratCreateESERisk(DBA_HIER_HEAD_STP, int, DBA_DYNFLD_STP,
									   int, int*); /* PMSTA05345-CHU-080505 */
EXTERN RET_CODE FIN_StratAddESEInHier(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, int,
				                      DBA_DYNFLD_STP, EXTSTRATELTNAT_ENUM);
EXTERN RET_CODE	FIN_InsUpdStratData(DBA_HIER_HEAD_STP,
									DBA_DYNFLD_STP,
									DBA_ACTION_ENUM,
									int,
									int(*)(PTR , DBA_DYNFLD_STP, FLAG_T*),  /* REF7264 - LJE - 020131 */
									PTR,
									FLAG_T*, /*mca ref7216*/
                                    FLAG_T); /* PMSTA-27076 - CHU - 170626 */

#endif /* FINLIB08_H */


/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef DFTTESTICU_H
#define DFTTESTICU_H

/************************************************************************
**
** Independent operating system interfaces for the callstack
**
*************************************************************************/

extern int DFT_TestIcu(void);

#endif	 /* ifndef DFTTESTICU_H */

/************************************************************************
**      END        dfttesticu.h                                    
*************************************************************************/

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines      
*************************************************************************/
#define AAA_TEST_C

#define	 STDIO_H
#define	STDLIB_H
#define	STRING_H
#define	UNISTD_H
#define	TIME_H

#include "opsys.h"      /* PMSTA-12713 - JPP - 20111109 */
#include "os.h"         /* PMSTA-12713 - JPP - 20111109 */

#include "unidef.h"     /* Mandatory */
#include "gen.h"
#include "csrv.h"
#include "dba.h"
#include "fin.h"
#include "fmtlib01.h"
#include "syb.h"
#include "syslib.h"     /* Necessary for FREE  PMO - Rename our sys.h to syslib.h and use it */
#include "date.h"

#include   "scptyl.h"

#include <ctpublic.h>

#ifdef NT
#include "sysnt.h" /* REF7264 - PMO */
static  char    SV_KeywordNT[64];
#endif

SCPT_ARG_ST *EV_ScptArg;

static int SV_ServerInitFlg = TRUE;
int *EV_ServerInitFlg = &SV_ServerInitFlg;
void FMT_ReplaceSubStr(char *dest, char *src, const char* findStr, const char *subStr) {} /* PMSTA-16139 - 020413 - PMO */
int SCPT_yyparse_thread_safe(SCPT_ARG_STP arg){return 0;}
int yyparse(){return 0;}
RET_CODE OPE_LoadOper(OBJECT_ENUM object,DBA_DYNFLD_STP inputSt,DBA_DYNFLD_STP *operation, DbiConnectionHelper& dbiConnHelper){return 0;}
RET_CODE SCPT_CompleteSystemScript(DBA_DYNFLD_STP scriptDefSt, char **scriptDefPtr, FLAG_T *allocScriptFlgPtr, DICT_T fctDictId, FLAG_T freeStrFlg, DICT_T screenDictId, DICT_T compoundScreenDictId, DBA_DYNFLD_STP *attScriptDefTab, int attScriptDefNbr, int guiFlg) {return 0;}
int SCPT_ComputeScreenDV(OBJECT_ENUM    object,
                         DICT_T         functionDictId,     /*  FIH-REF4258-000111  */
                         FLAG_T         *flags,
                         DBA_DYNFLD_STP record,
						 DBA_DYNFLD_STP oldRecord,
                         DBA_DYNFLD_STP domain,
                         DBA_DYNFLD_STP objectModifStat,   /* PMSTA13283 - DDV - 120117 */
                         FLAG_T         mode,
                         FLAG_T         type,
                         EVALTYPE_ENUM  enEvalType,
                         int            fldIdx,
                         int            *connPtr,
                         PTR            filterTab,
                         PTR            hierHead,
                         ID_T                screenId,
                         OBJECT_ENUM         enScriptObject,    /*  FIH-REF9789-040209  */
                         DICT_T              *pdictidScreen,
                         DBA_DYNFLD_STP      *pdbadynOp,
                         SCPT_FMTDATADEF_STP pfmtDataDefTab,
                         DBA_DYNFLD_STP      pdbadynFldTab,
                         DBA_DYNFLD_STP      pdbadynReference,
                         OBJECT_ENUM         enReferenceObject,
                         FLAG_T              flagEOpCase,
                         FLAG_T              flagFlagNoImpact,
                         DICT_T                 compoundScreenDictId) {return 0;}
RET_CODE SCPT_AnalyseEntityDefVal2(SCPT_DFLTVAL_STP    *dvsTab,
								  FLAG_T			  **forcedFlgTabTab,
								  DBA_DYNFLD_STP	   *inputRecTab,
                                  int                   recNbr,
                                  int                   masterIdx,
                                  FLAG_T			    analyseAllFlg,
								  EVALTYPE_ENUM         enEvalType,
                                  SCPT_FMTDATADEF_STP   pfmtDataDefTab,
                                  DBA_DYNFLD_STP        pdbadynFldTab,
                                  FLAG_T                flagFlagNoImpact
								 ){return 0;}
int SCPT_ComputeCompoundScreenDV(OBJECT_ENUM         object,
    DICT_T              functionDictId,
    FLAG_T            **flagsTabTabParam,
    DBA_DYNFLD_STP     *extOpTab,
    DBA_DYNFLD_STP     *oldExtOpTab,
    int                 extOpNbr,
    DBA_DYNFLD_STP      domain,
    FLAG_T              mode,
    FLAG_T              type,
    EVALTYPE_ENUM       enEvalType,
    int                *connPtr,
    PTR                 filterTabParam,
    DBA_HIER_HEAD_STP   hierHead
    ){return 0;}

int SCPT_ComputeScreenIC(OBJECT_ENUM    object,
                         DICT_T         functionDictId,
                         DBA_DYNFLD_STP record,
                         DBA_DYNFLD_STP oldRecordStp,
                         DBA_DYNFLD_STP domain,
                         int            *size,
                         DBA_DYNFLD_STP **message,
                         FLAG_T         type,
                         ID_T           screenId,
                         OBJECT_ENUM    enScriptObject,     /*  FIH-REF9789-040209  */
                         DBA_DYNFLD_STP pdbadynReference,   /*  FIH-REF11144-050607 */
                         OBJECT_ENUM    enReferenceObject,   /*  FIH-REF11144-050607 */
                         DBA_DYNFLD_STP *extPosTab,
        /* PMSTA-66 - DDV - 060609 */
                         int            extPosNbr,
        /* PMSTA-66 - DDV - 060609 */
                        DBA_HIER_HEAD_STP   hierHead,       /*  FPL-PMSTA03122-PMSTA02138-070828   */
                        SCPT_ICACTION_ENUM  actionIC,       /*  FPL-PMSTA03122-PMSTA02138-070828   */
                        int		*connectNo, 	   /* REF11578 - TEB - 051205 */
                        DICT_T                 compoundScreenDictId)
			             {return 0;}
RET_CODE SCPT_EvalCstList(int a, ID_T b, const char *c, OBJECT_ENUM d, ID_T e, DBA_DYNFLD_STP f, int g, FLAG_T *h,
					DBA_DYNFLD_STP **i, int *j, DATETIME_STP k, ID_T l, ID_T m){return 0;}

FLAG_T FIN_IsEmptyPtfSynth(DBA_DYNFLD_STP ptfSynthStp){    return FALSE;}   /*  HFI-PMSTA-18201-140611  */                       

RET_CODE FIN_GetExchRate(DATETIME_T      refDateTime, 
                         ID_T            srcCurrId, 
                         ID_T            trgtCurrId, 
                         ID_T            valRuleId, 
                         DBA_DYNFLD_STP  inputValRulePtr,
						 DBA_DYNFLD_STP  posPtr,			/* PMSTA01649 - TGU - 070413 */
                         FIN_EXCHARG_STP exchArgStp,        /* REF2313 */
                         EXCHANGE_T      *exch){return 0;}
RET_CODE FIN_ExchAmt(DATETIME_T      exchDate, 
                             ID_T            srcCurrId, 
                             ID_T            trgtCurrId, 
                             ID_T            valRuleId,       /* REF2313 */
                             DBA_DYNFLD_STP  inputValRulePtr, /* REF2313 */
							 DBA_DYNFLD_STP  posPtr,		  /* PMSTA01649 - TGU - 070405 */		  
                             FIN_EXCHARG_STP exchArgStp,      /* REF2313 */
                             EXCHANGE_T      *frcdExch, 
                             AMOUNT_T        *exchAmtPtr, 
                             EXCHANGE_T      *exchPtr){return 0;}

EXTERN int      DBA_CmpAmount(double x, double y, ID_T currId){return 0;}

RET_CODE OPE_DictEnumToOperNat(OBJECT_ENUM objectEn, OPNAT_ENUM *operNat){return 0;}
DBA_DYNFLD_STP OPE_ExtPosToExtOp(OPNAT_ENUM opNat,DBA_DYNFLD_STP extPos, FLAG_T *flagTab, ID_T instrId, bool defFlag){return 0;}
DBA_DYNFLD_STP OPE_DynStDup(const DBA_DYNFLD_STP dynfldSrc){return 0;}
RET_CODE FIN_PriceToQuote(PRICECALCRULE_ENUM priceCalcRule, 
			ID_T               instrId,
			DBA_DYNFLD_STP     inputInstrPtr,
			DATETIME_T         priceDate,
			FIN_PRICEARG_STP   priceArgStp,
			PRICE_T            price,
			PRICE_T            *quote,
			DBA_HIER_HEAD_STP  hierHead){return 0;}
RET_CODE FIN_QuoteToPrice(PRICECALCRULE_ENUM priceCalcRule,
                          ID_T               instrId,
                          DBA_DYNFLD_STP     inputInstrPtr,
                          DATETIME_T         priceDate,
                          FIN_PRICEARG_STP   priceArgStp,
                          PRICE_T           quote,
                          PRICE_T           *price,
                          DBA_HIER_HEAD_STP  hierHead){return 0;}
double FIN_Round(ID_T currId, double nbr, CODE_T currCd){return 0;}
RET_CODE OPE_OperNatToDictEnum(OPNAT_ENUM operNat, DBA_DYNST_ENUM *dynStEn, OBJECT_ENUM *objectEn){return 0;}
void OPE_ExtOpChangeSignAmountQuantity(DBA_DYNFLD_STP extOpSt){}
RET_CODE OPE_ExtOpComputeBp10(const DBA_DYNFLD_STP  extOpSt, 
                              const ID_T            sysCurrId,
                              const char *          portfolioCode,
                              DBA_ERRMSG_INFOS_STP  msgStructPtr,
                              FLAG_T *              gotFTFlgPtr,
                              AMOUNT_T *            bp10Amount){return 0;}
RET_CODE OPE_ExtOpToOpExtPos(DBA_DYNFLD_STP         extOpSt, 
                             OPNAT_ENUM             opNature, 
                             ID_T                   refCurrId,
                             FUSDATERULE_ENUM       refFusDateRule,
                             DBA_DYNST_ENUM         ptfEnum,
                             DBA_DYNFLD_STP         ptf, 
                             FLAG_T                 genPpsExtPosFlg,
                             DBA_DYNFLD_STP *       ptfPosSetPtr, 
                             int                    ptfPosSetNb,
                             DBA_DYNST_ENUM         instrEnum,
                             DBA_DYNFLD_STP         instr,
                             DBA_DYNFLD_STP *       operOutput,
                             DBA_DYNFLD_STP **      extPosOutput, 
                             int *                  nbOfExtPos,
                             int                    connectNo,
                             int                    getOptions,
                             DBA_ERRMSG_INFOS_STP   msgStructPtr,
                             FLAG_T *               adjCashFlag,
                             FLAG_T                 allowPartialPosGenFlg){return 0;}

RET_CODE OPE_GetExtOp(OBJECT_ENUM     object,
                      DBA_DYNFLD_STP  inputSt, 
                      DBA_DYNFLD_STP *      extOpStPtr,
                      DbiConnectionHelper& dbiConnHelper
					  ){return 0;}
ID_T OPE_GetOpIdFromExtOp(const DBA_DYNFLD_STP extOp){return 0;}
ID_T OPE_GetOpIdFromExtOpPriorityOperation(const DBA_DYNFLD_STP extOp){return 0;}
OPTABLE_ENUM OPE_GetOpTableFromDynFld(const DBA_DYNFLD_STP pdbadyn, const OBJECT_ENUM enObjectEntity){return OpTable_None;}

RET_CODE    OPE_FillConvOpArray(void){return 0;}

RET_CODE FIN_AccrInter(DATETIME_T              refDateTime, 
		       ID_T                    instrId, 
		       DBA_DYNFLD_STP          inputInstrPtr, 
		       ID_T                    refCurrId, 
		       FIN_AIARG_STP           aiArgStp,
		       NUMBER_T                qty, 
		       DBA_DYNFLD_STP          posPtr, /* DVP125 - RAK - 960620 */
		       FIN_MKTVAL_STP          mktPtr,
                       DBA_HIER_HEAD_STP       hierHead){return 0;}
RET_CODE OPE_ExecutionOperation(DBA_ACTION_ENUM action,
                                DBA_DYNFLD_STP extOpSt,
                                DBA_DYNFLD_STP oldExtOpSt, /* only use for update */
                                DBA_DYNFLD_STP *execExtOp,
                                DBA_DYNFLD_STP *remainingExtOp,
                                DBA_DYNFLD_STP sPtf,
                                DBA_DYNFLD_STP *ppsTab,
                                int ppsNb,
                                DBA_DYNFLD_STP **insertExtOpChild,
                                DBA_DYNFLD_STP **updateExtOpChild,
                                DBA_DYNFLD_STP **remainingExtOpChild,
                                int *insUpdExtOpChildNb,
                                int connectNo,
                                DBA_ERRMSG_INFOS_STP msgStructPtr,
                                struct AutomaticFusionStock *autoFusStock){return 0;}
RET_CODE OPE_OpToExtOp(DBA_DYNFLD_STP   operation, 
                       OPNAT_ENUM       opNature,
                       DBA_DYNFLD_STP   extOpStOutput,
                       FLAG_T           flagFlagNoImpact){return 0;}
RET_CODE OPE_ReverseOperation(DBA_ACTION_ENUM action,
                              DBA_DYNFLD_STP extOpSt,
                              DBA_DYNFLD_STP oldExtOpSt,
                              DBA_DYNFLD_STP *revExtOp,
                              DBA_DYNFLD_STP sPtf,
                              DBA_DYNFLD_STP *ppsTab,
                              int ppsNb,
                              DBA_DYNFLD_STP **insertExtOpChild,
                              DBA_DYNFLD_STP **updateExtOpChild,
                              int *insUpdExtOpChildNb,
                              int connectNo,
                              DBA_ERRMSG_INFOS_STP msgStructPtr,
                              struct AutomaticFusionStock *autoFusStock){return 0;}
FLAG_T OPE_CheckAudit(OBJECT_ENUM object){return 0;}
RET_CODE SCPT_FreeClassifStack(SCPT_CLASSIFSTACK_STP *classifStack){return 0;}
PTR SCPT_GetScriptByUserDefinedScreeen(void){return 0;}
void SCPT_FreeEntityControl(PTR controlStPtr){}
void SCPT_FreeEntityDefVal(PTR dfltValStPtr){}
EXTERN RET_CODE SCPT_SetOldRecordControl(PTR controlStPtr, DBA_DYNFLD_STP oldRecord){return 0;}
EXTERN RET_CODE SCPT_SetOldRecord(PTR dfltValStPtr, DBA_DYNFLD_STP oldRecord){return 0;}
RET_CODE SCPT_EvalTree( SCPT_EVALTYPE_ENUM      evalType,
                        int                     level,
                        SCPT_ARG_STP            generalContext,
                        DATATYPE_ENUM           fldDataType,
                        DBA_DYNFLD_STP          rec,
                        DBA_DYNFLD_STP          *childRecPtr,
                        OBJECT_ENUM             object,
                        SCPT_NODE_STP           node,
                        DBA_HIER_HEAD_STP       hierHead,
                        int                     colIdx,
                        DBA_DATADEF_STP         dataDefTab,
                        DBA_DYNFLD_STP          dataFldTab,
                        DBA_DYNFLD_STP          *sumFmtEltTab,
                        int                     *incrNbPtr,
                        int                     *colNbPtr){return 0;} /* PMSTA-21701 - 151116 - DDV - Remove HierElt arguments */
RET_CODE        FIN_UpdateGridModel(DBA_DYNFLD_STP a, DBA_DYNFLD_STP *b, int c, int d, int *e, DBA_ERRMSG_INFOS_STP f){return 0;}
RET_CODE SCPT_AnalyseEntityDefVal(PTR dfltValStPtr, FLAG_T *forcedFlgTab, DBA_DYNFLD_STP inputRec, FLAG_T analyseAllFlg, EVALTYPE_ENUM evalFilterFlg, SCPT_FMTDATADEF_STP pfmtDataDefTab, DBA_DYNFLD_STP pdbadynFldTab, FLAG_T flagFlagNoImpact){return 0;}
TLS_SORT_STP SCPT_GetSortPtr (){return 0;}
RET_CODE OPE_CheckRefOperCode(const DBA_DYNFLD_STP extOpSt, DBA_ERRMSG_INFOS_STP msgStructPtr){return 0;}
RET_CODE SCPT_AnalyseEntityControl(PTR           controlStPtr,
                                  DBA_DYNFLD_STP inputRec,
                                  DBA_DYNFLD_STP **outputRecTab,
                                  int            *nbRows,
                                  DBA_HIER_HEAD_STP     hierHead,               /*  FPL-PMSTA03122-PMSTA02138-070829   */
                                  SCPT_ICACTION_ENUM    actionIc){return 0;}    /*  FPL-PMSTA03122-PMSTA02138-070829   */

RET_CODE OPE_SelExtOp(DBA_DYNFLD_STP  inputSt,
                      DBA_DYNFLD_STP **     outputData,
                      int *                 rowsNbr,
                      DbiConnectionHelper& dbiConnHelper){return 0;}

RET_CODE OPE_SetBalPosTpRank(const int rank, ID_T * bpTpIdPtr){return 0;}
RET_CODE OPE_SetExtPosBookVal(DBA_HIER_HEAD_STP     hierHead,
                              int                   getOption,
                              int *                 connectNo,
                              DBA_ERRMSG_INFOS_STP  msgStructPtr){return 0;}
RET_CODE OPE_SetSysCurrencyId(const DBA_DYNFLD_STP extOpSt, ID_T * sysCurrencyIdPtr){return 0;}
RET_CODE OPE_CreateExtOpfromExtPos(PTR              hierHeadPtr, 
                                   DBA_DYNFLD_STP   **extOpTab, 
                                   int              *extOpTabNbr,
                                   HIER_FLTFCT      *posFilter,
                                   HIER_CMPFCT      *cmpFct){return 0;}

RET_CODE OPE_ExtOpToOp(DBA_DYNFLD_STP           extOpSt,
                       DBA_DYNFLD_STP           opOutput,
                       int                      getOptions,
                       int                      *connectNo,
                       DBA_ERRMSG_INFOS_STP     msgStructPtr,
                       PTR                      hierHeadPtr,
                       FLAG_T                   flagFlagNoImpact){return 0;}
int FIN_SearchInstrInMktSegt(PTR                    argHierHead,
                             ID_T                   mktSegtId,
                             ID_T                   instrId,
                             DBA_DYNFLD_STP         aInstrSt,
                             ID_T                   lastGridId,
                             FLAG_T                 verifFlg,
                             SCPT_CLASSIFSTACK_STP  classifStack,
                             int                    selOptions,
                             int*                   connectNo,
                             DBA_ERRMSG_INFOS_STP   msgStructPtr,
			     int                    m3SDepthLevel,
                             DBA_DYNFLD_STP         *instrMktSgtPtr){return 0;}
/*  FPL-PMSTA05599-100125   */
RET_CODE FIN_IsInList ( DBA_HIER_HEAD_STP   hierHead,
                        ID_T                objectId,
                        DBA_DYNFLD_STP      record,
                        OBJECT_ENUM         objectEnum,
                        ID_T                listId,
                        DBA_DYNFLD_STP      *listPtr,
                        int                 *connectNoParam,
                        FLAG_T              listHistoFlgParam,
                        DATETIME_STP        dateHisto,
                        FLAG_T              *resultFlg){return 0;}

int SCPT_ComputeDV(OBJECT_ENUM    object,
                   FLAG_T         *flags,
                   DBA_DYNFLD_STP record,
                   FLAG_T         mode,
                   FLAG_T         type,
                   int           *connPtr){return 0;}
SCPT_AUTOCREATE_HEADER_STP SCPT_GetAutocreateHeader(void){return 0;}
RET_CODE SCPT_GetAutocreateElts(SCPT_AUTOCREATE_STP searchKey,
                                SCPT_AUTOCREATE_STP **eltTab,
                                int                 *eltNbr)
{return 0;}
RET_CODE SCPT_FreeAutocreateElts(SCPT_AUTOCREATE_STP searchKey){return 0;}
FLAG_T OPE_IsCashDone(DBA_DYNFLD_STP extOpSt,
                      int *connectNo,
                      DBA_ERRMSG_INFOS_STP msgStructPtr){return 0;}
RET_CODE FIN_InstrPrice(ID_T              instrId, 
			DBA_DYNFLD_STP    inputInstrPtr, 
			DATETIME_T        refDateTime, 
			DBA_DYNFLD_STP    instrPriceArg,
			ID_T	          valRuleId,
			FIN_PRICEARG_STP  priceArgStp,
			DBA_DYNFLD_STP    inputValRulePtr,
			DBA_DYNFLD_STP    extPosPtr,
			DBA_HIER_HEAD_STP hierHead,
			DBA_DYNFLD_STP    pricePtr,
			FLAG_T            excludeAdjustedPriceFlg){return 0;} /* PMSTA14876 - DDV - 120911 - Add a new parameter to exclude ajusted price for theoritical computation (DURA, MDURA, YTM . . .) */
RET_CODE FIN_GetBookValueEltByValRuleHist(DBA_DYNFLD_STP    extPosPtr, 
       			                  DBA_DYNFLD_STP    valRuleHistPtr,
		                          DBA_HIER_HEAD_STP hierHead,
		                          DBA_DYNFLD_STP    valRuleEltPtr,
                                          DATETIME_STP      refDateTime){return 0;}
RET_CODE FIN_BookValueByValRule(DBA_DYNFLD_STP    extPosPtr, 
                                DBA_DYNFLD_STP    lastBVPtr, 
       			        ID_T              valRuleId,
       	       		        DBA_DYNFLD_STP    inputValRulePtr,
       	       	                DATETIME_T        refDateTime, 
                                NUMBER_T          opExch,
                                NUMBER_T          instrExch,
                                NUMBER_T          sysExch,
		                DBA_HIER_HEAD_STP hierHead,
		                DBA_DYNFLD_STP    bookValuePtr){return 0;}
RET_CODE SCPT_InitEntityDefVal(OBJECT_ENUM object,
                               PTR         *dfltValStPtr,
                               int         guiFlg,
                               DICT_T      screenDictId){return 0;}
void SCPT_SetSortPtr(TLS_SORT_STP sortStp){}
RET_CODE SCPT_InitEntityControl(OBJECT_ENUM object,
                                PTR         *controlStPtr,
                                int         guiFlg,
                                DICT_T      screenDictId,
                                DICT_T      functionDictId,
                                OBJECT_ENUM initEntityRef,  /*  FIH-REF11144-050607 */
                                DICT_T      compoundScreenDictId)
                                {return 0;}
void SCE_InitSceMsgPtr (){}

/* PMSTA-22396  - SRIDHARA - 160430 � new argument calendarId */
RET_CODE SCE_AccrPeriod(DATE_T fromDate, DATE_T tillDate, ACCRRULE_ENUM accrRule, DATE_PERIOD_STP periodPtr, ID_T calendarId){ return 0; }
FLAG_T SCE_CheckAccrRule(ACCRRULE_ENUM accrRule){return 0;}

/* PMSTA-22396  - SRIDHARA - 160430 � new argument calendarId */
RET_CODE SCE_CldrDateDiff(DATE_T fromDate, DATE_T tillDate, DATE_UNIT_ENUM dateUnitEn, ACCRRULE_ENUM accrRule, double *diffPeriods, ID_T calendarId){ return 0; }
RET_CODE SCE_CldrDaysBetweenDates(DATE_T fromDate, DATE_T tillDate, ACCRRULE_ENUM accrRule, long *numDays, ID_T calendarId){ return 0; }
RET_CODE SCE_CldrPeriodsBetweenDates(DATE_T fromDate, DATE_T tillDate, DATE_UNIT_ENUM dateUnitEn, ACCRRULE_ENUM accrRule, double *diffPeriods){return 0;}

RET_CODE SCPT_SetDomain(PTR            dfltValStPtr, DBA_DYNFLD_STP domainPtr){return 0;}
RET_CODE OPE_GetBalPosTp(DBA_DYNFLD_STP *outputSt, ID_T balPosTpId){return 0;}
RET_CODE        OPE_LoadPtfPosSetByPtfId(DBA_DYNFLD_STP **ptfPosSet, int *ptfPosSetNb, ID_T ptfId){return 0;}


RET_CODE SCPT_GenerateScptTree( char 		*str, 
				OBJECT_ENUM 	object, 
				SCPT_MODE_ENUM 	mode, 
				DATATYPE_ENUM   fldDataType,
				SCPT_ARG_STP 	*generalContextPtr) {return 0;}
EXTERN FLAG_T SCPT_IsIndexAttributeUsed(DICT_T         progN,
                                        SCPT_NODE_STP  node) {return 0;}
RET_CODE SCPT_FreeScptTree(SCPT_ARG_STP	generalContext, FLAG_T freeContextFlg) {return 0;}
FLAG_T SCPT_IsRemoveWithFilterTree(DBA_HIER_HEAD_STP hierHead, OBJECT_ENUM fmtObject, SCPT_ARG_STP *filterTreePtr, DBA_DYNFLD_STP testRow, DBA_DYNFLD_STP *evalRecPtr, int *incrNbPtr) {return 0;}  /* PMSTA-21701 - 151116 - DDV - Remove HierElt arguments */
RET_CODE SCPT_PrepTreeForFilter(char *scriptDef, DBA_HIER_HEAD_STP hierHead, DBA_DYNFLD_STP aDomain, OBJECT_ENUM fmtObject, SCPT_ARG_STP *filterTreePtr, DICT_T outputEntDictId, DBA_DYNFLD_STP aScriptDefRec) {return 0;}
RET_CODE SCPT_FreeTreeForFilter(SCPT_ARG_STP *filterTreePtr) {return 0;}
EXTERN int SCPT_FreeScriptIC(OBJECT_ENUM object) {return 0;}
EXTERN int SCPT_FreeScriptDV(OBJECT_ENUM object) {return 0;}

RET_CODE SCPT_BuildConstraintScptDef(DICT_T dimConstrDictId, ID_T constrId, ID_T constrTemplateId, DBA_DYNFLD_STP newConstrTemplateScpt, char **scriptDefOut) {return 0;}
RET_CODE OPE_GetPtfPps(DBA_DYNFLD_STP extOpSt,DBA_DYNFLD_STP *sPtf,DBA_DYNFLD_STP **pps, int *ppsNb,
		       int connectNo,DBA_ERRMSG_INFOS_STP msgStructPtr) {return 0;}
RET_CODE OPE_OrderOperation(DBA_ACTION_ENUM action,
			    DBA_DYNFLD_STP extOpSt,
			    DBA_DYNFLD_STP oldExtOp,
			    DBA_DYNFLD_STP sPtf,
			    DBA_DYNFLD_STP *ppsTab,
			    int ppsNb,
			    int connectNo,
			    DBA_ERRMSG_INFOS_STP msgStructPtr,
			    struct AutomaticFusionStock *autoFusStock) {return 0;}

EXTERN RET_CODE SCPT_CheckSubscriptionScript(DBA_DYNFLD_STP         subscriptionPtr,
                                             DBA_DYNFLD_STP         inputRec,
                                             DBA_DYNFLD_STP         oldRec,
                                             FLAG_T                 *resultFlg,
                                             int                    *connectNo, 
                                             DBA_ERRMSG_INFOS_STP   msgStructPtr) {return 0;}
EXTERN RET_CODE SCPT_ExecSubscriptionBusEntityScript(DBA_DYNFLD_STP         subscriptionPtr,
                                                     DBA_DYNFLD_STP         inputRec,
                                                     DBA_DYNFLD_STP         oldRec,
                                                     ID_T                   *businessEntityId,
                                                     int                    *connectNo, 
                                                     DBA_ERRMSG_INFOS_STP   msgStructPtr) {return 0;}

unsigned char FIN_CaseSessionBlockingCheckConfirmedFlag(DBA_DYNFLD* dyn){return 0;}

EXTERN  void    CRYPT_HackMD5(char *inputString, char **outputString) {}

EXTERN RET_CODE FIN_InstrChrono(DBA_DYNFLD_STP     inputArgPtr,
                                DBA_DYNFLD_STP     inputInstrPtr,
                                DBA_DYNFLD_STP     chronoPtr,
                                DBA_HIER_HEAD_STP  hierHead){return 0;}

EXTERN RET_CODE DBA_GetAllCurrencyById(OBJECT_ENUM             entity,
                                      DBA_DYNFLD_STP           sCurr,
                                      DBA_DYNFLD_STP           *aCurr,
                                      int                      *allocConnPtr,
                                      int                      getOptions,
                                      DBA_ERRMSG_INFOS_STP     msgStructPtr) {return 0;}
RET_CODE DBA_GetAllCurrencyByCd(OBJECT_ENUM             entity,
                               DBA_DYNFLD_STP           sCurr,
                               DBA_DYNFLD_STP           *aCurr,
                               DbiConnectionHelper&     dbiConnHelper) {return 0;}
char* FMT_BasicMsgGet(const char* msgCode, MSG_GUI_TYPE_ENUM enMsgGuiType, DICT_T langDictId) {return NULL;}
RET_CODE FMT_DynStpShFldIdx(ENTITY_INFO_STP info) {return 0;}
char* FMT_DynFldToStr(char*                      target,
                      DATATYPE_ENUM              dataType,
                      PTR                        dynStPtr,
                      int                        fld,
                      DATA_STYLE_ENUM            styleEnum,
                      const char*                pszFormat,
                      OBJECT_ENUM                entity,
                      DICT_T                     dictId,
                      TEXT_CONVERSION_TYPE_ENUM  textConversionEn,
                      PAD_ENUM                   *penPad) {return NULL;}
int FMT_StrToFld(const char*                src,
                 DATATYPE_ENUM              dataType,
                 PTR                        dynStPtr,
                 int                        fld,
                 DATA_STYLE_ENUM            styleEnum,
                 char*                      fmt,
                 TEXT_CONVERSION_TYPE_ENUM  textConversionEn) {return 0;}
RET_CODE FMT_InitMsgCash(DICT_T userLangDictId) {return 0;}       /* DLA - PMSTA08801 - 100708 */
ALL_ATTRIB_INFO_STP FMT_AttribFromFldIdx(ALL_ATTRIB_INFO_STP attribTab,
                                         int attribNb,
                                         short fldIdx,
                                         short* attribIdx) {return 0;}
RET_CODE FMT_PermValTabFill(OBJECT_ENUM refNo, int fldIdx, int* permValNbPtr, PERMITED_VALUES_STP* permValTabPtr, ALL_ATTRIB_INFO_STP attribStp, FLAG_T editFlag, ADM_FLD_VAL_STP fldValStp, int iRightMask) {return 0;}
RET_CODE FIN_Classify(DICT_T                    entDictId,
                              ID_T                      objectId,
                              ID_T                      classifId,
                              DBA_DYNFLD_STP            evalRec,
                              DBA_DYNFLD_STP            outputRec,
                              PTR                       classifStackPtr,
                              DBA_HIER_HEAD_STP         hierHead,
                      DATETIME_STP              classifDateTime,
                              DBA_DYNFLD_STP            domainPtrParam,
                      FLAG_T                    buildListFlg,
                      FLAG_T                    useOptimFlg,
                      int                       selOptions,
                      int*                      allocConn,
                      DBA_ERRMSG_INFOS_STP      msgStructPtr) {return 0;}

ID_T OPE_GetOpIdFromDynFld(const DBA_DYNFLD_STP pdbadyn, const OBJECT_ENUM enObjectEntity) {return 0;}

char * SYS_GetCallStack(void) {return 0;}
int SYS_IsCallStackEnable(void) {return 0;}
RET_CODE SCPT_FreeSqlData(SCPT_SQLFLD_ST **arg)  {return 0;} 
double DBA_GetCurrPrecision(DBA_DYNFLD_STP currPtr){return 0.01; }  /* PMSTA08607 - 280909 - PMO */
void MD5Salted_Data(const char *,const char *,char *){}
int FMT_GetRightFunction(DBA_DYNFLD*,int,DBA_DYNFLD*,DBA_HIER_HEAD*,SCPT_FMTDATADEF_ST*,int,long long,DICT_FCT_ST*,SCRIPTDEFACT_ENUM,unsigned char,unsigned char,unsigned char,unsigned char,int(*)(void*,DBA_DYNFLD*,int*),int(*)(void*,DICT_FCT_ST*,DBA_DYNFLD*),void*,DBA_DYNFLD*,DBA_DYNFLD*) { return 0;}
RET_CODE FMT_GetOrderRecord(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP*, ID_T, CODE_T, FLAG_T, FLAG_T) { return 0;}

RET_CODE FMT_CheckDP(OBJECT_ENUM,DBA_DYNFLD_STP,ID_T,DBA_DYNFLD_STP) { return 0;}

RET_CODE DBA_InsFmtById(OBJECT_ENUM          object,
                        DBA_DYNST_ENUM       inputSt,
                     	DBA_DYNFLD_STP       inputData,
                     	int                  connectNo,
                     	DBA_ERRMSG_INFOS_STP msgStructPtr) {return 0;}
RET_CODE DBA_UpdFmt(OBJECT_ENUM          object,
                    DBA_DYNST_ENUM       inputSt,
                    DBA_DYNFLD_STP       inputData,
                    int                  connectNo,
                    DBA_ERRMSG_INFOS_STP msgStructPtr) {return 0;}
RET_CODE DBA_DelFmt(OBJECT_ENUM object,
                    DBA_DYNST_ENUM inputSt,
                    DBA_DYNFLD_STP inputData,
                    DbiConnectionHelper& dbiConnHelper) {return 0;}
RET_CODE DBA_InsFmtEltById(OBJECT_ENUM          object,
                           DBA_DYNST_ENUM       inputSt,
                     	   DBA_DYNFLD_STP       inputData,
                     	   int                  connectNo,
                     	   DBA_ERRMSG_INFOS_STP msgStructPtr) {return 0;}
RET_CODE DBA_UpdFmtElt(OBJECT_ENUM          object,
                       DBA_DYNST_ENUM       inputSt,
                       DBA_DYNFLD_STP       inputData,
                       int                  connectNo,
                       DBA_ERRMSG_INFOS_STP msgStructPtr) {return 0;}
RET_CODE DBA_DelFmtElt(OBJECT_ENUM object,
                       DBA_DYNST_ENUM inputSt,
                       DBA_DYNFLD_STP inputData,
                       DbiConnectionHelper& dbiConnHelper) {return 0;}
RET_CODE DBA_CopyFmtElt(OBJECT_ENUM entity,
                        DBA_DYNFLD_STP admArg,
                        DbiConnectionHelper& dbiConnHelper) {return 0;}

static int SV_ServerMode = FALSE;
static char *SV_User     = NULL;
static char *SV_Password = NULL;

SYSNAME_T *      SV_EntityTab=NULL;     /* DLA - REF8880 - 031024 */
int              SV_EntityTabNb=0; /* DLA - REF8880 - 031024 */

SCPT_ARG_STP *    genContextTab; /* DLA - REF8880 - 031024 */
int               genContextTabNb=0;    /* DLA - REF8880 - 031024 */

SCPT_GENCONTEXTSUB_STP * genContextBusEntityTab;      /* PMSTA-17089 - DDV - 131205 */
int                      genContextBusEntityTabNb=0;  /* PMSTA-17089 - DDV - 131205 */

int *EV_ServerMode = &SV_ServerMode;
int  EV_OptiMemFlg = FALSE;
int  EV_TestNewScpt = 1;
int  EV_GuiActivatedFlg = 0;
int  SV_SimInsFlg=0;
int  SV_SimUpdFlg=0;
int  SV_SimDelFlg=0;

#define AAATIMER 1
static TIMER_ST SV_GeneralTimer;

void ERR_DisplaySyntax()
{
	printf("\nSyntax: aaa SIM -Uuser -Ppassword [ -F[I][U][D] ] < scenario_file > output_file\n");
	printf("\nArguments description :\n");
	printf("	user		Triple'A user\n");
	printf("	password	Triple'A password\n");
	printf("	-F...		Optional argument\n");
	printf("			Default is no execution of insert, update or delete requests\n");
	printf("			If specified it must be followed by I or/and U or/and D\n");
	printf("			followed by I : Force to execute the insert requests\n");
	printf("			followed by U : Force to execute the update requests\n");
	printf("			followed by D : Force to execute the delete requests\n\n");
	exit(1);
}

static int GetOption(int argc, char **argv)
{
    int c;

    /* ROI - 000922 - REF5253 */
	/* while ((c=getopt(argc,argv,"U:P:F:"))!=EOF)	*/
    while ((c=SYS_Getopt(argc,argv,"U:P:F:"))!=EOF)
    {
        switch (c)
        {
            case 'U':
                if (SV_User != NULL)
                    ERR_DisplaySyntax();

                /* ROI - 000922 - REF5253 */
                /* SV_User = optarg; */
				SV_User = SYS_GetoptArg();
                break;

            case 'P':
                if (SV_Password != NULL)
                    ERR_DisplaySyntax();

                /* ROI - 000922 - REF5253 */
                /* SV_Password = optarg; */
                SV_Password = SYS_GetoptArg();
                break;

	    case 'F':
		{
			char *p;
            /* ROI - 000926 - REF5253 */
			/* for(p=optarg ; *p ; p++) */
#ifdef UNIX
			for(p=optarg ; *p ; p++)
			{
				switch(*p)
				{
				case 'I':
				case 'i': SV_SimInsFlg=1; break;
				case 'U':
				case 'u': SV_SimUpdFlg=1; break;
				case 'D':
				case 'd': SV_SimDelFlg=1; break;

				default : ERR_DisplaySyntax();
				}
			}
#endif
#ifdef NT
			for(p=SYS_GetoptArg(); (p != NULL) && *p ; p++)
			{
				switch(*p)
				{
				case 'I':
				case 'i': SV_SimInsFlg=1; break;
				case 'U':
				case 'u': SV_SimUpdFlg=1; break;
				case 'D':
				case 'd': SV_SimDelFlg=1; break;

				default : ERR_DisplaySyntax();
				}
			}
#endif
		}
		break;

            default :
                ERR_DisplaySyntax();
        }
    }

    if (SV_User == NULL || SV_Password == NULL)
        ERR_DisplaySyntax();

    return 0;
}

/* ROI - 000922 - REF5253 */
#ifdef UNIX
void msleep(int x)
{
	struct timeval t;

	if(x)
	{
		t.tv_sec = x/1000;
		t.tv_usec = (x%1000) * 1000;
		select(0, NULL, NULL, NULL, &t);
	}
}
#endif

/* ROI - 000922 - REF5253 */
#ifdef NT
extern void NT_GetTimeOfDay(long *second, long *microsecond);
#endif

/* ROI - 000922 - REF5253 */
#ifdef UNIX
struct timezone SV_Zone;
struct timeval SV_Time;
#endif

void getTime(int *h, int *m, int *s, int *u)
{
/* ROI - 000922 - REF5253 */
#ifdef NT
		TIMER_ST	timer;

		NT_GetTimeOfDay(&timer.timer.tv_sec, &timer.timer.tv_usec);

        *h = 1 + (timer.timer.tv_sec % 86400) / 3600;
        *m = (timer.timer.tv_sec % 3600) / 60;
        *s = timer.timer.tv_sec % 60;
		*u = timer.timer.tv_usec;
#endif

/* ROI - 000922 - REF5253 */
#ifdef UNIX
		gettimeofday(&SV_Time, &SV_Zone);

        *h = 1 + (SV_Time.tv_sec % 86400) / 3600;
        *m = (SV_Time.tv_sec % 3600) / 60;
        *s = SV_Time.tv_sec % 60;
		*u = SV_Time.tv_usec;
#endif

}

int main(int argc, char **argv)
{
    int		         blk, cpt, connectNo, resultType, msgResult, ret, status;
    char	         buffer[10240 +1];
    CS_COMMAND           *csCommand=NULL;
    char	         endFlg = FALSE;
    DBA_SERVER_TYPE_ENUM srv;
    FILE		 *fp;
    char		 *p,key[50], srvType[10], strTime[20];
    double		 guiDelta, generalDelta=0.;
    int			 h,m,s,u;
    CS_INT		 colNb;
    int			 col;
    CS_DATAFMT  	 csDataFmt;
    int			 maxlen, cptBlockRec, maxsize;


    if (GetOption(argc,argv))
    {
        return 1;
    }

#ifdef NT
	NT_Init(GEN_GetApplVersion(), SV_KeywordNT);
#endif

    setvbuf(stdout, NULL, _IOLBF, BUFSIZ);
    setvbuf(stderr, NULL, _IOLBF, BUFSIZ);

    if (GEN_Initial() == RET_SUCCEED)
    {
	/***** Force EV_TimerMask meme si AAATIMERMASK (env var) est initialis�e *****/
	EV_TimerMask=1;

	if (CSRV_Init(false) == RET_SUCCEED)                                           /* PMSTA-18094 - 130514 - PMO */
	{
		if (GEN_AppLogin(SV_User, SV_Password) == RET_SUCCEED)           /* PMSTA-18094 - 130514 - PMO  */
		{

#ifdef NT
			if (DBA_InitDictInfo() != RET_SUCCEED)
			{
				return(1);
			}
#endif
			  
		DATE_StartTimer(&SV_GeneralTimer, TIMER_MASK_GEN);
	    fp = stdin;

	    if (fgets(buffer, 10240, fp) != NULL)
	    {
    	      char   *eol = NULL;

	      do
	      {
		if ((eol = strchr(buffer, '\n')) == NULL)
			break;

		endFlg = FALSE;
		*eol = '\0';

		sscanf(buffer, "%s %s %s",key, strTime, srvType);
		guiDelta = atof(strTime);

		srv = (strcmp(srvType,"SQL")==0)?SqlServer:FinServer;
		p = strstr(buffer, srvType);

		if (p == NULL)
		{
		        endFlg = TRUE;
			continue;
		}

		p += strlen(srvType) +1;

		if (p == NULL || strlen(p) < 4)
		{
		        endFlg = TRUE;
			continue;
		}

		if ( (strncmp(p, "ins_", 4) == 0 && SV_SimInsFlg==0) ||
		     (strncmp(p, "upd_", 4) == 0 && SV_SimUpdFlg==0) ||
		     (strncmp(p, "del_", 4) == 0 && SV_SimDelFlg==0) )
		{
			continue;
		}

                DbiConnection*	dbiConn = nullptr;
         	if ((dbiConn = DBA_GetDbiConnection(SqlServer, ROLE_ADMIN)) == nullptr)
                {
         		return RET_DBA_ERR_CONNOTFOUND;
	        }
		if ((connectNo = DBA_GetConnection(srv, Synchronous)) == DBA_CONN_NOT_FOUND)
		{
			printf(" ### CONNECTION ERROR / SIMULATOR STOPPED ###\n");
			return(1);
		}

		csCommand = (CS_COMMAND *)DBA_GetCommandSt(connectNo);

		/* ROI - 000922 - REF5253 */
#ifdef UNIX
		msleep((int)(guiDelta * 1000));
#endif
#ifdef NT
		SYS_MilliSleep((unsigned) guiDelta);
#endif

		printf("%-10s ", key);

		getTime(&h,&m,&s,&u);
		DATE_StopTimer(&SV_GeneralTimer, TIMER_MASK_GEN);
		printf("FROM: %02d:%02d:%02d.%02d %5d.%06d --- ", 
			   h,
			   m,
			   s,
			   u/10000,
			   SV_GeneralTimer.cumul.tv_sec, 
			   SV_GeneralTimer.cumul.tv_usec );
	        DATE_StartTimer(&SV_GeneralTimer, TIMER_MASK_GEN);

		ret = SYB_SendCommand(srv, Synchronous, p, &connectNo, DBA_SET_CONN);

		DBA_FilterMsgInfos(connectNo, &msgResult); 

		if(ret != RET_SUCCEED) /* REF5010 - SSO - 000828 */
		{
		    printf("ERROR : Can't execute request\n");
		    return 1;
		}
		else
		{
		    blk = 0;
		    cpt = 0;
		    maxsize=0;
		    do 
		    {
			blk++;
			cptBlockRec=0;

			ct_res_info(csCommand, CS_NUMDATA, (CS_INT *)&colNb, CS_UNUSED, NULL);
			maxlen=0;
			for(col=1; col<=colNb ; col++)
			{
				if (ct_describe(csCommand, col, &csDataFmt) == CS_SUCCEED)
				{
					maxlen += csDataFmt.maxlength;
				}
			}

			while (SYB_Fetch(csCommand) == TRUE)
			{
				cpt++;
				cptBlockRec++;
			}

			maxsize += cptBlockRec * maxlen;


			DBA_CtResults(connectNo, &resultType);
			if (resultType != CS_CMD_DONE)
            {
				endFlg = TRUE;
            }
            else    /* DLA "else" added */ 
            {
			    DBA_CtResults(connectNo, &resultType);
			    if (resultType != CS_ROW_RESULT)
				    endFlg = TRUE;
		    } 
            }while (endFlg == FALSE);

		    SYB_ProcessAllResults(connectNo, &status);
		    DBA_EndConnection(connectNo);

		    getTime(&h,&m,&s,&u);
		    DATE_StopTimer(&SV_GeneralTimer, TIMER_MASK_GEN);
		    printf("TO: %02d:%02d:%02d.%02d %5d.%06d --- DELTA:%3d.%06d ", 
			   h,
			   m,
			   s,
			   u/10000,
			   SV_GeneralTimer.cumul.tv_sec, 
			   SV_GeneralTimer.cumul.tv_usec,
		    	   SV_GeneralTimer.timer.tv_sec,
			   SV_GeneralTimer.timer.tv_usec);
		    printf("--- MAXSIZE: %-8d REC: %d \n", maxsize, cpt);
	            DATE_StartTimer(&SV_GeneralTimer, TIMER_MASK_GEN);
		}
	      } while(fgets(buffer, 10240, fp) != NULL);
	    }
          }
	  else
		return 1;
	}
	else
	    return 1;
    }

#ifdef NT
	NT_Done();
#endif
    return 0;
}

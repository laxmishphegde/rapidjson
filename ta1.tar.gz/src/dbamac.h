/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef DBAMAC_H
#define DBAMAC_H

/* #include "dba.h" force to be included first for typedef */
extern DBA_DYNST_STP    EV_DynStPtr;

/************************************************************************
**      Constant & Macro definitions
*************************************************************************/

/*  FIH-REF4029-991109  Constant to manage flgMask in DNA_DYNFLD    */
#define BIT_NOTNULLFLG      0
#define BIT_NOTDEFAULTFLG   1
#define BIT_REFFLG          2
#define BIT_GETFLG          3 /* PMSTA13244 - DDV - 120120 - Trace DynFld usage */
#define BIT_SETFLG          4 /* PMSTA13244 - DDV - 120120 - Trace DynFld usage */
#define BIT_SCPTCSTVAR      5 /* PMSTA13584 - DDV - 120214 - Additional information to know if var is link to a cstNode to avoid storing string pointer on eval stack */
#define BIT_MAXALLOCFLG     6 /* PMSTA-Memory - LJE - 181204 */

/***************************
** Macro SET_UCHAR_BIT
** set one bit in a bit mask
** b = bit mask (long)
** n = bit position in bit mask
** s = source value (FALSE/TRUE)
***************************/
#define SET_UCHAR_BIT(b,n,s) ((b)= static_cast<unsigned char> ((s) ? (b) |(0x01 << (n)): (b) &(~(0x01 << (n)))))

/***************************
** Macro GET_BIT
** return bit value( TRUE or FALSE) in a bitmask
** b = bitmask
** n = bit position in bit mask
***************************/
#define GET_UCHAR_BIT(b,n) (((b>>n)&1)==0?FALSE:TRUE)

/***************************
** Macros SET_NOTNULLFLG_*
** Set notNullFlg in struct DBA_DYNFLD_ST to 1 (TRUE) or 0 (FALSE).
** notNullFlg is TRUE  if data is not a NULL value,
** FALSE if data is a NULL value
** By default notNullFlg is FALSE.
***************************/
#define SET_NOTNULLFLG_T(p,f) {SET_UCHAR_BIT((p)[(f)].flgMask,BIT_NOTNULLFLG,1);SET_SETFLG_T(p,f);}  /* PMSTA13244 - DDV - 120120 - Trace DynFld usage */
#define SET_NOTNULLFLG_F(p,f) {SET_UCHAR_BIT((p)[(f)].flgMask,BIT_NOTNULLFLG,0);SET_SETFLG_T(p,f);}  /* PMSTA13244 - DDV - 120120 - Trace DynFld usage */
#define _SET_NOTNULLFLG_T(p,f) {SET_UCHAR_BIT((p)[(f)].flgMask,BIT_NOTNULLFLG,1);}  /* PMSTA13244 - DDV - 120120 - Trace DynFld usage */
#define _SET_NOTNULLFLG_F(p,f) {SET_UCHAR_BIT((p)[(f)].flgMask,BIT_NOTNULLFLG,0);}  /* PMSTA13244 - DDV - 120120 - Trace DynFld usage */

/***************************
** Macros SET_NOTDEFAULTFLG_*
** Set notDfltFlg in struct DBA_DYNFLD_ST to 1 (TRUE) or 0 (FALSE).
** notDfltFlg is TRUE  if data is not a NULL value,
** FALSE if data is a NULL value
** By default notDfltFlg is FALSE.
***************************/
#define SET_NOTDEFAULTFLG_T(p,f) (SET_UCHAR_BIT((p)[(f)].flgMask,BIT_NOTDEFAULTFLG,1))
#define SET_NOTDEFAULTFLG_F(p,f) (SET_UCHAR_BIT((p)[(f)].flgMask,BIT_NOTDEFAULTFLG,0))

/***************************
** Macros SET_GETFLG_*
** Set getFlg in struct DBA_DYNFLD_ST to 1 (TRUE) or 0 (FALSE).
** getFlg is TRUE if data has been read,
** else its value is FALSE
** By default getFlg is FALSE.
** PMSTA13244 - DDV - 120120 - Trace DynFld usage
***************************/
#define SET_GETFLG_T(p,f) (SET_UCHAR_BIT((p)[(f)].flgMask,BIT_GETFLG,1))
#define SET_GETFLG_F(p,f) (SET_UCHAR_BIT((p)[(f)].flgMask,BIT_GETFLG,0))

/***************************
** Macros SET_SETFLG_*
** Set setFlg in struct DBA_DYNFLD_ST to 1 (TRUE) or 0 (FALSE).
** setFlg is TRUE if data has been updated,
** else its value is FALSE
** By default setFlg is FALSE.
** PMSTA13244 - DDV - 120120 - Trace DynFld usage
*************************/
#define SET_SETFLG_T(p,f) (SET_UCHAR_BIT((p)[(f)].flgMask,BIT_SETFLG,1))
#define SET_SETFLG_F(p,f) (SET_UCHAR_BIT((p)[(f)].flgMask,BIT_SETFLG,0))

/***************************
** Macros SET_MAXLALLOCFLG_*
** Set maxAllocFlg in struct DBA_DYNFLD_ST to 1 (TRUE) or 0 (FALSE).
***************************/
#define SET_MAXALLOCFLG_T(p,f) (SET_UCHAR_BIT((p)[(f)].flgMask,BIT_MAXALLOCFLG,1))
#define SET_MAXALLOCFLG_F(p,f) (SET_UCHAR_BIT((p)[(f)].flgMask,BIT_MAXALLOCFLG,0))

/***************************
** Macros SET_REFFLAG_*
** Set referenced flag in struct DBA_DYNFLD_ST to 1 (TRUE) or 0 (FALSE).
** On dynamic structure means own by the DdlGenDbaAccess
***************************/
#define SET_BIT_REFFLG_T(p) (SET_UCHAR_BIT((p)[0].flgMask,BIT_REFFLG,1))
#define SET_BIT_REFFLG_F(p) (SET_UCHAR_BIT((p)[0].flgMask,BIT_REFFLG,0))

/***************************
** Macro IS_NULLFLD
** Return true if data is NULL, false elsewhere.
** p = pointer on dynamic structure (DBA_DYNFLD_STP)
** f = field number in dynamic structure (S_Curr_Id, A_Codif_Name, 0, ...)
***************************/
#define _IS_NULLFLD(p,f) (((p)[(f)].flgMask&(1<<BIT_NOTNULLFLG))==0) /*BSA - REF11433 - 060223 */
#define IS_NULLFLD(p,f) (DICT_IsNullFld(p,f))  /* PMSTA13244 - DDV - 120120 - Trace DynFld usage */

/***************************
** Macro IS_NOTNULL
** Return true if data is not NULL, false elsewhere.
** p = pointer on dynamic structure (DBA_DYNFLD_STP)
** f = field number in dynamic structure (S_Curr_Id, A_Codif_Name, 0, ...)
***************************/
#define _IS_NOTNULL(p,f) (!_IS_NULLFLD(p,f))
#define IS_NOTNULL(p,f) (!IS_NULLFLD(p,f))

/***************************
** Macro IS_DFLTFLD
** Return TRUE if data is DEFAULT, FALSE elsewhere.
** p = pointer on dynamic structure (DBA_DYNFLD_STP)
** f = field number in dynamic structure (S_Curr_Id, A_Codif_Name, 0, ...)
***************************/
#define IS_DFLTFLD(p,f) ((GET_UCHAR_BIT((p)[(f)].flgMask,BIT_NOTDEFAULTFLG)&1)?FALSE:TRUE)

/***************************
** Macro IS_GETFLD
** Return TRUE if data is GET, FALSE elsewhere.
** p = pointer on dynamic structure (DBA_DYNFLD_STP)
** f = field number in dynamic structure (S_Curr_Id, A_Codif_Name, 0, ...)
** PMSTA13244 - DDV - 120120 - Trace DynFld usage
***************************/
#define IS_GETFLD(p,f) ((GET_UCHAR_BIT((p)[(f)].flgMask,BIT_GETFLG)&1)?TRUE:FALSE)

/***************************
** Macro IS_SETFLD
** Return TRUE if data is SET, FALSE elsewhere.
** p = pointer on dynamic structure (DBA_DYNFLD_STP)
** f = field number in dynamic structure (S_Curr_Id, A_Codif_Name, 0, ...)
** PMSTA13244 - DDV - 120120 - Trace DynFld usage
***************************/
#define IS_SETFLD(p,f) ((GET_UCHAR_BIT((p)[(f)].flgMask,BIT_SETFLG)&1)?TRUE:FALSE)

/***************************
** Macro IS_MAXALLOC
** Return TRUE if data is allocated with the max data length, FALSE elsewhere.
** p = pointer on dynamic structure (DBA_DYNFLD_STP)
** f = field number in dynamic structure (A_Codif_Name, 0, ...)
***************************/
#define IS_MAXALLOC(p,f) ((GET_UCHAR_BIT((p)[(f)].flgMask,BIT_MAXALLOCFLG)&1)?TRUE:FALSE)

/***************************
** Macro IS_REFDYNST
** Return TRUE if data is own by the DdlGenDbaAccess
** p = pointer on dynamic structure (DBA_DYNFLD_STP)
** f = field number in dynamic structure (A_Codif_Name, 0, ...)
***************************/
#define IS_REFDYNST(p) ((GET_UCHAR_BIT((p)[0].flgMask,BIT_REFFLG)&1)?TRUE:FALSE)

/***************************
** Macros GET_*
** Get string pointer or numeric value depending on the
** possible type in DBA_DYNFLDDATA_UN
***************************/
#define GET_DATETIMEST(p,f)      ((p)[(f)].data.datetime64St)
#define GET_DOUBLE(p,f)          ((p)[(f)].data.dbleValue)
#define GET_INT(p,f)             ((p)[(f)].data.intValue)
#define GET_SHORT(p,f)           ((p)[(f)].data.shortValue)
#define GET_STRING(p,f)          ((p)[(f)].data.strData.ptr)
#define GET_UCHAR(p,f)           ((p)[(f)].data.ucharValue)
#define GET_UINT(p,f)            ((p)[(f)].data.uintValue)
#define GET_USHORT(p,f)          ((p)[(f)].data.ushortValue)
#define GET_USTRING(p,f)         ((p)[(f)].data.ustrData.ptr)
#define GET_LONGLONG(p,f)        ((p)[(f)].data.longlongValue) /* DLA - REF9089 - 030508 */  /* PMSTA08801 - DDV - 091126 */
#define GET_POINTER(p,f)         ((p)[(f)].data.ptr)           /* DLA - REF9089 - 030512 */        /*  FIH-REF8712-031009  Define GET_POINTER for AAATRACEDYN GET_PTR moved in dba.h   */

/***************************
** Macro GET_INTERNAL - PMSTA-46681 - LJE - 231110
** Return value of the internalFldIdx field  in dynamic structure.
***************************/
inline INT_T GET_INTERNAL(const DBA_DYNFLD_STP p)
{
    return (GET_FLD_INTERNAL(p->getDynStEn()) != Null_Dynfld ? GET_INT(p, GET_FLD_INTERNAL(p->getDynStEn())) : 0);
}

/***************************
** Macros GET_EXTENSION_*
** Get extension informations
** p = pointer on dynamic structure (DBA_DYNFLD_STP)
** f = field number in dynamic structure (A_Pos_A_Instr_Ext, 0, ...)
**
** GET_EXTENSION_PTR return an pointer (DBA_DYNFLD_STP *) on x elements array
**  we know that extension have only one element (instrPtr is an DBA_DYNFLD_STP)
**     instrPtr = *(GET_EXTENSION_PTR(posTab[i], A_Pos_A_Instr_Ext));
**
**  we know that extension can have several elements
**  (balPosTab is an DBA_DYNFLD_STP *)
**     balPosTab = GET_EXTENSION_PTR(posTab[i], A_Pos_A_BalPos_Ext);
**     for (i=0; i<GET_EXTENSION_NBR(posTab[i], A_Pos_A_BalPos_Ext); i++)
**
** GET_EXTENSION_NBR return the number of elements in extension array
**
** GET_EXTENSION_TP return the type of extension structure (DBA_DYNST_ENUM)
**
***************************/
#define GET_EXTENSION_PTR(p,f)   ((p)[(f)].data.extPtr)
#define GET_EXTENSION_TP(p,f)    ((p)[(f)].dynStEnum > InvalidDynSt ? (p)[GET_INFO_FLD((p), (f))].data.extInfo.dynStTp : NullDynSt)
#define GET_EXTENSION_NBR(p,f)   ((p)[(f)].dynStEnum > InvalidDynSt ? (p)[GET_INFO_FLD((p), (f))].data.extInfo.extNbr : 0)

#define SET_EXTENSION_TP(p,f,tp)    {if ((p)[(f)].dynStEnum > InvalidDynSt) {(p)[GET_INFO_FLD((p), (f))].data.extInfo.dynStTp = tp; }}
#define SET_EXTENSION_NBR(p,f,nbr)  {if ((p)[(f)].dynStEnum > InvalidDynSt) {(p)[GET_INFO_FLD((p), (f))].data.extInfo.extNbr = nbr; }}

/***************************
** Macros GET_ARRAY_*
** Get array informations
** p = pointer on dynamic structure (DBA_DYNFLD_STP)
** f = field number in dynamic structure (A_Pos_A_Instr_Ext, 0, ...)
**
** GET_ARRAY_PTR    return an pointer (PTR) on x elements array
** GET_ARRAY_ELTNBR return the number of elements in array
** GET_ARRAY_ELTSZ  return the size of one element in array
**
***************************/
#define GET_ARRAY_PTR(p,f)     ((p)[(f)].data.arrayPtr)
#define GET_ARRAY_ELTNBR(p,f)  ((p)[(f)].dynStEnum > InvalidDynSt ? (p)[GET_INFO_FLD((p), (f))].data.arrayInfo.eltNbr : 0)
#define GET_ARRAY_ELTSZ(p,f)   ((p)[(f)].dynStEnum > InvalidDynSt ? (p)[GET_INFO_FLD((p), (f))].data.arrayInfo.eltSz : 0)

#define SET_ARRAY_ELTNBR(p,f,nbr)  { if ((p)[(f)].dynStEnum > InvalidDynSt) { (p)[GET_INFO_FLD((p), (f))].data.arrayInfo.eltNbr = nbr; }}
#define SET_ARRAY_ELTSZ(p,f,sz)    { if ((p)[(f)].dynStEnum > InvalidDynSt) { (p)[GET_INFO_FLD((p), (f))].data.arrayInfo.eltSz = sz; }}

/***************************
** Macros GET_MULTIARRAY_*
** Get multi array informations
** p = pointer on dynamic structure (DBA_DYNFLD_STP)
**
** GET_MULTIARRAY_PTR        return an pointer (DBA_ARRAY_DATA_STP) on x elements array
** GET_MULTIARRAY_DATATAB    return an pointer (DBA_ARRAY_DATA_STP) on data tab
** GET_MULTIARRAY_NOTNULLTAB return an pointer (DBA_ARRAY_DATA_STP) on not null flag tab
** GET_MULTIARRAY_DIM1       return the size of the first dimension
** GET_MULTIARRAY_DIM2       return the size of the second dimension
**
***************************/
#define GET_MULTIARRAY_PTR(p,f)        ((p)[(f)].data.multiArrayDataPtr)
#define GET_MULTIARRAY_DATATAB(p,f)    ((p)[(f)].data.multiArrayDataPtr->dataTab)
#define GET_MULTIARRAY_NOTNULLTAB(p,f) ((p)[(f)].data.multiArrayDataPtr->notNullFlgTab)
#define GET_MULTIARRAY_DIM1(p,f)       ((p)[(f)].dynStEnum > InvalidDynSt ? (p)[GET_INFO_FLD((p), (f))].data.multiArrayInfo.dataNbr1 : 0)
#define GET_MULTIARRAY_DIM2(p,f)       ((p)[(f)].dynStEnum > InvalidDynSt ? (p)[GET_INFO_FLD((p), (f))].data.multiArrayInfo.dataNbr2 : 0)

#define SET_MULTIARRAY_DIM1(p,f,nbr)   { if ((p)[(f)].dynStEnum > InvalidDynSt) { (p)[GET_INFO_FLD((p), (f))].data.multiArrayInfo.dataNbr1 = nbr; }}
#define SET_MULTIARRAY_DIM2(p,f,nbr)   { if ((p)[(f)].dynStEnum > InvalidDynSt) { (p)[GET_INFO_FLD((p), (f))].data.multiArrayInfo.dataNbr2 = nbr; }}

/***************************
** Macro TIME_DATETIMEST
** Extract time from datetime structure
** p = pointer on dynamic structure (DBA_DYNFLD_STP)
** f = field number in dynamic structure (A_Instr_BeginDate, 0, ...)
***************************/
#define TIME_DATETIMEST(p,f)     (GET_DATETIMEST(p,f).time())

/***************************
** Macro DATE_DATETIMEST
** Extract date from datetime structure
** p = pointer on dynamic structure (DBA_DYNFLD_STP)
** f = field number in dynamic structure (A_Instr_BeginDate, 0, ...)
***************************/
#define DATE_DATETIMEST(p,f)     (GET_DATETIMEST(p,f).date())


/***************************
** Macros SET_NULL_*
** Set notNullFlg to FALSE,
** numeric fields are set to 0,
** string fields length (strLen) is set to 0 and string init to EOS.
***************************/
#if defined(NT) && defined(AAADEBUGMSG)
#define SET_NULL_DOUBLE(p,f)  {p[f].data.dbleValue=0.0;SET_NOTNULLFLG_F(p,f);}
#define SET_NULL_INT(p,f)    {p[f].data.intValue=0;SET_NOTNULLFLG_F(p,f);}
#define SET_NULL_SHORT(p,f)   {p[f].data.shortValue=0;SET_NOTNULLFLG_F(p,f);}

#define SET_NULL_STRING(p,f)  {if((p)[f].data.strData.ptr)\
                   {\
			           (p)[f].data.strData.ptr[0]=static_cast<char>(0);\
                   }\
			       SET_NOTNULLFLG_F((p),f);}

/* PMSTA13244 - DDV - 120123 - Trace DynFld usage */
#define _SET_NULL_STRING(p,f)  {if(p[f].data.strData.ptr)\
                   {\
			           (p)[f].data.strData.ptr[0]=static_cast<char>(0);\
                   }\
			       _SET_NOTNULLFLG_F(p,f);}

#define SET_NULL_USTRING(p,f)  {if(p[f].data.ustrData.ptr)\
                   {\
			           (p)[f].data.ustrData.ptr[0] =static_cast<UChar>(0);\
                   }\
			       SET_NOTNULLFLG_F(p,f);}

/* PMSTA13244 - DDV - 120123 - Trace DynFld usage */
#define _SET_NULL_USTRING(p,f)  {if(p[f].data.ustrData.ptr)\
                   {\
			           (p)[f].data.ustrData.ptr[0] =static_cast<UChar>(0);\
                   }\
			       _SET_NOTNULLFLG_F(p,f);}
#define SET_NULL_UCHAR(p,f)   {p[f].data.ucharValue=0;SET_NOTNULLFLG_F(p,f);}
#define SET_NULL_USHORT(p,f)  {p[f].data.ushortValue=0;SET_NOTNULLFLG_F(p,f);}
#define SET_NULL_UINT(p,f)    {p[f].data.intValue=0;SET_NOTNULLFLG_F(p,f);}         /* PMSTA-15937 - 150213 - PMO */
#define SET_NULL_DATETIMEST(p,f) {GET_DATETIMEST(p,f).reset();\
				  SET_NOTNULLFLG_F(p,f);}
#define SET_NULL_LONGLONG(p,f)  {p[f].data.longlongValue=0;SET_NOTNULLFLG_F(p,f);} /* DLA - REF9089 - 030508 */ /* PMSTA08801 - DDV - 091126 */
#define SET_NULL_PTR(p,f)  {p[f].data.ptr=nullptr;SET_NOTNULLFLG_F(p,f);}       /*  FIH-REF9089-030513  */
#else
#define SET_NULL_DOUBLE(p,f)  {GET_DOUBLE(p,f)=0.0;SET_NOTNULLFLG_F(p,f);}
#define SET_NULL_INT(p,f)    {GET_INT(p,f)=0;SET_NOTNULLFLG_F(p,f);}
#define SET_NULL_SHORT(p,f)   {GET_SHORT(p,f)=0;SET_NOTNULLFLG_F(p,f);}

#define SET_NULL_STRING(p,f)  {if((p)[f].data.strData.ptr)\
                   {\
    			       (p)[f].data.strData.ptr[0] = static_cast<char>(0);\
                   }\
			       SET_NOTNULLFLG_F(p,f);}

/* PMSTA13244 - DDV - 120123 - Trace DynFld usage */
#define _SET_NULL_STRING(p,f)  {if(p[f].data.strData.ptr)\
                   {\
	    		       (p)[f].data.strData.ptr[0] = static_cast<char>(0);\
                   }\
			       _SET_NOTNULLFLG_F(p,f);}

#define SET_NULL_USTRING(p,f)  {if(p[f].data.ustrData.ptr)\
                   {\
		    	       (p)[f].data.ustrData.ptr[0] = static_cast<UChar>(0);\
                   }\
			       SET_NOTNULLFLG_F(p,f);}

/* PMSTA13244 - DDV - 120123 - Trace DynFld usage */
#define _SET_NULL_USTRING(p,f)  {if(p[f].data.ustrData.ptr)\
                   {\
			           (p)[f].data.ustrData.ptr[0] = static_cast<UChar>(0);\
                   }\
			       _SET_NOTNULLFLG_F(p,f);}

#define SET_NULL_UCHAR(p,f)   {GET_UCHAR(p,f)=0;SET_NOTNULLFLG_F(p,f);}
#define SET_NULL_UINT(p,f)    {GET_UINT(p,f)=0;SET_NOTNULLFLG_F(p,f);}
#define SET_NULL_USHORT(p,f)  {GET_USHORT(p,f)=0;SET_NOTNULLFLG_F(p,f);}
#define SET_NULL_DATETIMEST(p,f) {GET_DATETIMEST(p,f).reset();\
				                  SET_NOTNULLFLG_F(p,f);}
#define SET_NULL_LONGLONG(p,f)  {GET_LONGLONG(p,f)=0;SET_NOTNULLFLG_F(p,f);}   /* DLA - REF9089 - 030508 */ /* PMSTA08801 - DDV - 091126 */
#define SET_NULL_PTR(p,f)  {GET_PTR(p,f)=nullptr;SET_NOTNULLFLG_F(p,f);}       /*  FIH-REF9089-030513  */
#endif

/***************************
** Macros SET_*
** Set string pointer or numeric value depending on the
** possible type in DBA_DYNFLDDATA_UN
** Update notNullFlg to TRUE.
** For set string pointer, compute the length from the string to set,
** if the length is upper than the actual allocated size, realloc
** the space for the copy (+1 for EOS) and update length.
** Than copy the source string + EOS and update string length
***************************/
#define SET_DATETIMEST(p,f,s)    {GET_DATETIMEST(p,f) = s; SET_NOTNULLFLG_T(p,f);}
#define SET_DATEONLY(p,f,s)      {GET_DATETIMEST(p,f).setDate(s);SET_NOTNULLFLG_T(p,f);}    /* PMSTA-15918 - 070213 - PMO */
#define SET_TIMEONLY(p,f,s)      {GET_DATETIMEST(p,f).setTime(s);SET_NOTNULLFLG_T(p,f);}    /* PMSTA-15918 - 070213 - PMO */
#define SET_DOUBLE(p,f,s)        {GET_DOUBLE(p,f)=s;SET_NOTNULLFLG_T(p,f);}
#define SET_INT(p,f,s)           {GET_INT(p,f)=s;SET_NOTNULLFLG_T(p,f);}
#define SET_SHORT(p,f,s)         {GET_SHORT(p,f)=s;SET_NOTNULLFLG_T(p,f);}
#define RESET_DATETIMEST(p,f)    {GET_DATETIMEST(p,f) = 0;}         /* WSC-21553 - 23032021 - DPT */
#define RESET_DATEONLY(p,f)      {GET_DATETIMEST(p,f).setDate(0);}  /* WSC-21553 - 23032021 - DPT */ 
#define RESET_TIMEONLY(p,f)      {GET_DATETIMEST(p,f).setTime(0);}  /* WSC-21553 - 23032021 - DPT */

inline void SET_LONGLONG(const DBA_DYNFLD_STP p, const FIELD_IDX_T & field, const ID_T & value) {GET_LONGLONG(p,field)=value;SET_NOTNULLFLG_T(p,field);}    /* PMSTA-32291 - 130818 - PMO / DLA - REF9089 - 030508 / PMSTA08801 - DDV - 091126 */

/* REF2718 - SSO - 980908 */

inline int fun_SET_STRING(DBA_DYNFLD_STP p, int f, const char* s)                   /* PMSTA-16443 - 230713 - PMO *//* REF7264 - PMO */
{
    unsigned int M_len = (s == NULL ? 0 : static_cast<unsigned int>(strlen(s)));
    unsigned int M_Size = M_len + 1;

    if (p[f].data.strData.ptr == nullptr || IS_MAXALLOC(p, f) == FALSE)
    {
        p[f].data.strData.ptr = static_cast<char *>(REALLOC(p[f].data.strData.ptr, M_Size * sizeof(char)));
    }

    if (p[f].data.strData.ptr)
    {
        if (M_len == 0)
        {
            p[f].data.strData.ptr[0] = static_cast<char>(0);
            SET_NOTNULLFLG_F(p, f);
        }
        else
        {
            memcpy(p[f].data.strData.ptr, s, M_Size * sizeof(char));
            SET_NOTNULLFLG_T(p, f);
        }
    }
    else
    {
        SET_NOTNULLFLG_F(p, f);
        return FALSE;
    }

    return TRUE;                                                                    /* PMSTA-16443 - 230713 - PMO */
}

inline int fun_SET_USTRING(DBA_DYNFLD_STP p, int f, const UChar* s)
{
    unsigned int M_len = (s == NULL ? 0 : u_strlen(s));
    unsigned int M_Size = M_len + 1;

    if (p[f].data.ustrData.ptr == nullptr || IS_MAXALLOC(p, f) == FALSE)
    {
        p[f].data.ustrData.ptr = static_cast<UChar *>(REALLOC(p[f].data.ustrData.ptr, M_Size * sizeof(UChar)));
    }

    if (p[f].data.ustrData.ptr)
    {
        if (M_len == 0)
        {
            p[f].data.ustrData.ptr[0] = static_cast<UChar>(0);
            SET_NOTNULLFLG_F(p, f);
        }
        else
        {

            memcpy(p[f].data.ustrData.ptr, s, M_Size * sizeof(UChar));
            SET_NOTNULLFLG_T(p, f);
        }
    }
    else
    {
        SET_NOTNULLFLG_F(p, f);
        return FALSE;
    }

    return TRUE;                                                                    /* PMSTA-16443 - 230713 - PMO */
}

/* PMSTA13244 - DDV - 120123 - Trace DynFld usage */
inline int _fun_SET_STRING(DBA_DYNFLD_STP p, int f, const char* s)
{
    unsigned int M_len = (s == NULL ? 0 : static_cast<unsigned int>(strlen(s)));
    unsigned int M_Size = M_len + 1;

    if (p[f].data.strData.ptr == nullptr || IS_MAXALLOC(p, f) == FALSE)
    {
        p[f].data.strData.ptr = static_cast<char *>(REALLOC(p[f].data.strData.ptr, M_Size * sizeof(char)));
    }

    if (p[f].data.strData.ptr)
    {
        if (M_len == 0)
        {
            p[f].data.strData.ptr[0] = static_cast<char>(0);
            _SET_NOTNULLFLG_F(p, f);
        }
        else
        {
            memcpy(p[f].data.strData.ptr, s, M_Size * sizeof(char));
            _SET_NOTNULLFLG_T(p, f);
        }
    }
    else
    {
        _SET_NOTNULLFLG_F(p, f);
        return FALSE;
    }

    return TRUE;                                                                    /* PMSTA-16443 - 230713 - PMO */
}

/* PMSTA13244 - DDV - 120123 - Trace DynFld usage */
inline int _fun_SET_USTRING(DBA_DYNFLD_STP p, int f, const UChar* s)
{
    unsigned int M_len = (s == NULL ? 0 : u_strlen(s));
    unsigned int M_Size = M_len + 1;

    if (p[f].data.ustrData.ptr == nullptr || IS_MAXALLOC(p, f) == FALSE)
    {
        p[f].data.ustrData.ptr = static_cast<UChar *>(REALLOC(p[f].data.ustrData.ptr, M_Size * sizeof(UChar)));
    }

    if (p[f].data.ustrData.ptr)
    {
        if (M_len == 0)
        {
            p[f].data.ustrData.ptr[0] = static_cast<UChar>(0);
            _SET_NOTNULLFLG_F(p, f);
        }
        else
        {

            memcpy(p[f].data.ustrData.ptr, s, M_Size * sizeof(UChar));
            _SET_NOTNULLFLG_T(p, f);
        }
    }
    else
    {
        _SET_NOTNULLFLG_F(p, f);
        return FALSE;
    }

    return TRUE;                                                                     /* PMSTA-16443 - 230713 - PMO */
}

#ifdef WIN32
#pragma warning(disable:4710) /* disable warning about no inline substitution */
#endif

/****** DVP172 pen 28/08/96 ********/
/****** REF2165 - GRD - 28/05/98 ********/

#define SET_STRING_MAXLEN(p,f,s,l)	\
	{	\
        STRING_Truncate(s, l, GET_FLD_DTP(p,f)); \
        fun_SET_STRING(p,f,s);\
    }

#define SET_USTRING_MAXLEN(p,f,s,l)	\
	{	\
		unsigned int M_len = (s == NULL ? 0 : u_strlen(s));	\
    \
        if (M_len > l) \
            M_len = l; \
	\
        unsigned int M_Size = M_len + 1; \
	\
        if (p[f].data.ustrData.ptr == nullptr || IS_MAXALLOC(p, f) == FALSE) \
		{	\
            p[f].data.ustrData.ptr = static_cast<UChar *>(REALLOC(p[f].data.ustrData.ptr, M_Size * sizeof(UChar))); \
		}	\
	\
        if (p[f].data.ustrData.ptr) \
        { \
		if(M_len != 0)	\
            { \
			    memcpy(p[f].data.ustrData.ptr, s, M_Size * sizeof(UChar)); \
            } \
	\
            p[f].data.ustrData.ptr[M_len] = static_cast<UChar>(0);	\
	\
		    if (p[f].data.ustrData.ptr[0])	\
		{\
			SET_NOTNULLFLG_T(p,f);	\
		}\
		else	\
		{\
			SET_NOTNULLFLG_F(p,f);	\
		}\
		}\
		else	\
		{\
			SET_NOTNULLFLG_F(p,f);	\
		}\
	}


inline               void SET_UCHAR(const DBA_DYNFLD_STP p, const FIELD_IDX_T & field, const ENUM_T  & value) {GET_UCHAR (p,field)= static_cast<UCHAR_T>(value); SET_NOTNULLFLG_T(p,field);}
template<typename T> void SET_UCHAR(const DBA_DYNFLD_STP p, const FIELD_IDX_T & field, const UCHAR_T & value) {GET_UCHAR (p,field)= value; SET_NOTNULLFLG_T(p,field);}
template<typename T> void SET_UCHAR(const DBA_DYNFLD_STP p, const FIELD_IDX_T & field, const T         value) {GET_UCHAR (p,field)= static_cast<UCHAR_T>(value); SET_NOTNULLFLG_T(p,field);}

#define SET_UINT(p,f,s)          {GET_UINT  (p,f)= static_cast<unsigned long> (s);SET_NOTNULLFLG_T(p,f);}
#define SET_USHORT(p,f,s)        {GET_USHORT(p,f)= static_cast<unsigned short>(s);SET_NOTNULLFLG_T(p,f);}
#define SET_POINTER(p,f,s)       {GET_PTR   (p,f)= static_cast<PTR>           (s);SET_NOTNULLFLG_T(p,f);}         /*  FIH-REF8712-031009  */

/***************************
** Macro SET_INTERNAL - PMSTA-46681 - LJE - 231110
** Return value of the internalFldIdx field  in dynamic structure.
***************************/
inline void SET_INTERNAL(DBA_DYNFLD_STP p, INT_T i)
{
    if (GET_FLD_INTERNAL(p->getDynStEn()) != Null_Dynfld)
    {
        SET_INT(p, GET_FLD_INTERNAL(p->getDynStEn()), i);
    }
}

/***************************
** Macro SET_EXTENSION
** Set extension informations
** p = pointer on dynamic structure (DBA_DYNFLD_STP)
** f = field number in dynamic structure (A_Pos_A_Instr_Ext, 0, ...)
** e = pointer on structure pointer array (DBA_DYNFLD_STP *)
** t = type of extension structure (DBA_DYNST_ENUM)
** n = elements number in the array
***************************/
#define SET_EXTENSION(p,f,e,t,n) {if (e !=nullptr)\
                                  {GET_EXTENSION_PTR(p, f) = e;\
                                   SET_EXTENSION_TP(p, f, t);\
                                   SET_EXTENSION_NBR(p, f, n);\
                                   SET_NOTNULLFLG_T(p,f);}\
                                  else\
                                  {GET_EXTENSION_PTR(p, f) = nullptr;\
                                   SET_EXTENSION_TP(p, f, NullDynSt);\
                                   SET_EXTENSION_NBR(p, f, 0);\
                                   SET_NOTNULLFLG_F(p,f);}}

#define SET_NULL_EXTENSION(p,f) {GET_EXTENSION_PTR(p, f) = nullptr;\
				 SET_EXTENSION_TP(p, f, NullDynSt);\
				 SET_EXTENSION_NBR(p, f, 0)\
				 SET_NOTNULLFLG_F(p,f);}

/* PMSTA13244 - DDV - 120123 - Trace DynFld usage */
#define _SET_NULL_EXTENSION(p,f) {GET_EXTENSION_PTR(p, f) = nullptr;\
				 SET_EXTENSION_TP(p, f, NullDynSt);\
				 SET_EXTENSION_NBR(p, f, 0);\
				 _SET_NOTNULLFLG_F(p,f);}

#define FREE_EXTENSION(p,f)     {FREE(GET_EXTENSION_PTR(p, f));\
                                 SET_EXTENSION_TP(p, f, NullDynSt);\
                                 SET_EXTENSION_NBR(p, f, 0);\
                                 SET_NOTNULLFLG_F(p,f);}                /* REF347 - 971014 - DED */

#define COPY_EXTENSION_INFO(dst, dstFld, src, srcFld) { SET_EXTENSION(dst, dstFld, GET_EXTENSION_PTR(src, srcFld), GET_EXTENSION_TP(src, srcFld), GET_EXTENSION_NBR(src, srcFld));}

inline void SET_EXTENSION_ONE(DBA_DYNFLD_STP record, FIELD_IDX_T extField, DBA_DYNFLD_STP extRecordStp)
{
    DBA_DYNFLD_STP * extensionPtr = static_cast<DBA_DYNFLD_STP*>(CALLOC(1, sizeof(DBA_DYNFLD_STP)));
    extensionPtr[0] = extRecordStp;
    SET_EXTENSION(record, extField, extensionPtr, GET_DYNSTENUM(extRecordStp), 1);
}

inline void SET_FK_RECORD(DBA_DYNFLD_STP recordStp, FIELD_IDX_T fkAttribIdx, DBA_DYNFLD_STP fkRecordStp)
{
    auto fkfld   = GET_FLD_FK(recordStp->getDynStEn());

    if (fkfld != Null_Dynfld)
    {
        if (GET_EXTENSION_PTR(recordStp, fkfld) == nullptr)
        {
            int             subRecordsNbr = static_cast<int>(recordStp->getDictEntityStp()->attr.size());
            DBA_DYNFLD_STP *subRecordsTab = static_cast<DBA_DYNFLD_STP *>(CALLOC(subRecordsNbr, sizeof(DBA_DYNFLD_STP)));
            DBA_DYNST_ENUM  subRecordsDynStEn = Io_Ext;

            SET_EXTENSION(recordStp, fkfld, subRecordsTab, subRecordsDynStEn, subRecordsNbr);
        }

        SET_ID(recordStp, fkAttribIdx, fkRecordStp->getDictEntityStp()->getId(fkRecordStp));

        auto dictAttribStp = recordStp[fkAttribIdx].getDictAttribStp();
        if (dictAttribStp != nullptr &&
            dictAttribStp->linkedAttrDictStp != nullptr &&
            dictAttribStp->linkedAttrDictStp->refDictEntityStp != nullptr &&
            dictAttribStp->linkedAttrDictStp->refDictEntityStp->objectEn == DictEntity)
        {
            SET_DICT(recordStp, dictAttribStp->linkedAttrDictStp->progN, fkRecordStp->getDictEntityStp()->entDictId);
        }

        if (GET_EXTENSION_PTR(recordStp, fkfld) != nullptr)
        {
            GET_EXTENSION_PTR(recordStp, fkfld)[fkAttribIdx] = fkRecordStp;
        }
    }
}

inline DBA_DYNFLD_STP GET_FK_RECORD(DBA_DYNFLD_STP recordStp, FIELD_IDX_T fkAttribIdx)
{
    auto fkfld = GET_FLD_FK(recordStp->getDynStEn());

    if (fkfld != Null_Dynfld &&
        GET_EXTENSION_PTR(recordStp, fkfld) != nullptr &&
        GET_EXTENSION_NBR(recordStp, fkfld) > fkAttribIdx)
    {
        return GET_EXTENSION_PTR(recordStp, fkfld)[fkAttribIdx];
    }

    return nullptr;
}

inline void FREE_FK_RECORD(DBA_DYNFLD_STP recordStp)
{
    auto fkfld = GET_FLD_FK(recordStp->getDynStEn());

    if (fkfld != Null_Dynfld)
    {
        FREE_EXTENSION(recordStp, fkfld);
    }
}

/***************************
** Macro SET_ARRAY
** Set array informations
** p = pointer on dynamic structure (DBA_DYNFLD_STP)
** f = field number in dynamic structure (A_Pos_A_Instr_Ext, 0, ...)
** a = pointer on array
** n = elements number in the array
** s = size of one element in array
***************************/
#define SET_ARRAY(p,f,a,n,s)	{if (a!=nullptr)\
	                         {if (GET_ARRAY_ELTNBR(p,f) != n)\
				  {FREE(GET_ARRAY_PTR(p,f));\
                                   GET_ARRAY_PTR(p,f) = CALLOC(n,s);}\
				  SET_ARRAY_ELTNBR(p,f,n);\
				  SET_ARRAY_ELTSZ(p,f,s);\
			          memcpy(GET_ARRAY_PTR(p,f),\
					 static_cast<void *>(a),(n*s));\
                                  SET_NOTNULLFLG_T(p,f);}\
				 else\
                                 {if (GET_ARRAY_PTR(p,f) != nullptr)\
				   {FREE(GET_ARRAY_PTR(p,f));}\
                                  GET_ARRAY_PTR(p,f) = nullptr;\
                                  SET_ARRAY_ELTNBR(p,f,0);\
                                  SET_ARRAY_ELTSZ(p,f,0);\
                                  SET_NOTNULLFLG_F(p,f);}}\

/* PMSTA13244 - DDV - 120123 - Trace DynFld usage */
#define _SET_ARRAY(p,f,a,n,s)	{if (a!=nullptr)\
	                         {if (GET_ARRAY_ELTNBR(p,f) != n)\
				  {FREE(GET_ARRAY_PTR(p,f));\
                                   GET_ARRAY_PTR(p,f) = CALLOC(n,s);}\
				  SET_ARRAY_ELTNBR(p,f,n);\
				  SET_ARRAY_ELTSZ(p,f,s);\
			          memcpy(GET_ARRAY_PTR(p,f),\
					 static_cast<void *>(a),(n*s));\
                                  _SET_NOTNULLFLG_T(p,f);}\
				 else\
                                 {if (GET_ARRAY_PTR(p,f) != nullptr)\
				   {FREE(GET_ARRAY_PTR(p,f));}\
                                  GET_ARRAY_PTR(p,f) = nullptr;\
                                  SET_ARRAY_ELTNBR(p,f,0);\
                                  SET_ARRAY_ELTSZ(p,f,0);\
                                  _SET_NOTNULLFLG_F(p,f);}}\

#define SET_NULL_ARRAY(p,f) {if (GET_ARRAY_PTR(p,f) != nullptr)\
			       {FREE(GET_ARRAY_PTR(p,f));}\
                             GET_ARRAY_PTR(p,f) = nullptr;\
                             SET_ARRAY_ELTNBR(p,f,0);\
                             SET_ARRAY_ELTSZ(p,f,0);\
                             SET_NOTNULLFLG_F(p,f);}

/* PMSTA13244 - DDV - 120123 - Trace DynFld usage */
#define _SET_NULL_ARRAY(p,f) {if (GET_ARRAY_PTR(p,f) != nullptr)\
			       {FREE(GET_ARRAY_PTR(p,f));}\
                             GET_ARRAY_PTR(p,f) = nullptr;\
                             SET_ARRAY_ELTNBR(p,f,0);\
                             SET_ARRAY_ELTSZ(p,f,0);\
                             _SET_NOTNULLFLG_F(p,f);}

/***************************
** Macro SET_MULTIARRAY
** Set array informations
** p  = pointer on dynamic structure (DBA_DYNFLD_STP)
** f  = field number in dynamic structure (A_Pos_A_Instr_Ext, 0, ...)
** a  = pointer on multi array structure (DBA_ARRAY_DATA_STP)
** d1 = size of the first dimension
** d2 = size of the second dimension
***************************/
#define SET_MULTIARRAY(p,f,a,d1,d2) {GET_MULTIARRAY_PTR(p, f) = a;\
				                     SET_MULTIARRAY_DIM1(p, f, d1);\
				                     SET_MULTIARRAY_DIM2(p, f, d2);\
                                     SET_NOTNULLFLG_T(p,f);}

#define _SET_MULTIARRAY(p,f,a,d1,d2) {GET_MULTIARRAY_PTR(p, f) = a;\
		 		                      SET_MULTIARRAY_DIM1(p, f, d1);\
		 		                      SET_MULTIARRAY_DIM2(p, f, d2);\
                                      _SET_NOTNULLFLG_T(p,f);}

#define SET_NULL_MULTIARRAY(p,f) {if (GET_MULTIARRAY_PTR(p,f) != nullptr)\
			                         {FREE(GET_MULTIARRAY_PTR(p,f));}\
                                  GET_MULTIARRAY_PTR(p,f) = nullptr;\
                                  SET_MULTIARRAY_DIM1(p,f,0);\
                                  SET_MULTIARRAY_DIM2(p,f,0);\
                                  SET_NOTNULLFLG_F(p,f);}

#define _SET_NULL_MULTIARRAY(p,f) {if (GET_MULTIARRAY_PTR(p,f) != nullptr)\
			                          {FREE(GET_MULTIARRAY_PTR(p,f));}\
                                   GET_MULTIARRAY_PTR(p,f) = nullptr;\
                                   SET_MULTIARRAY_DIM1(p,f,0);\
                                   SET_MULTIARRAY_DIM2(p,f,0);\
                                   _SET_NOTNULLFLG_F(p,f);}

/***************************
** Macro GET_STRING_LEN 				ROI - 960308 - DVP010
** Return current size for string data
** WARNING: size expressed in number of char
** p = pointer on dynamic structure (DBA_DYNFLD_STP)
** f = field number in dynamic structure (S_Curr_Id, A_Codif_Name, 0, ...)
***************************/
#define GET_STRING_LEN(p,f) (static_cast<int>(p[f].data.strData.ptr?strlen(p[f].data.strData.ptr):0))

/***************************
** Macro GET_STRING_LEN 				ROI - 960308 - DVP010
** Return current size for string data
** WARNING: size expressed in number of UChar
** p = pointer on dynamic structure (DBA_DYNFLD_STP)
** f = field number in dynamic structure (S_Curr_Id, A_Codif_Name, 0, ...)
***************************/
#define GET_USTRING_LEN(p,f) (static_cast<int>(p[f].data.ustrData.ptr?u_strlen(p[f].data.ustrData.ptr):0))

/***************************
** Macro GET_CUST_REFNO
** Return the customer entity refNo or UNUSED if there isn't a
** customer entity associated to the dynamic structure
** s = DBA_DYNST_ENUM
***************************/
#define GET_CUST_REFNO(s) ((EV_DynStPtr[s].custEntityObj==NullEntity)\
			  ?UNUSED\
			  :(EV_DictEntityPtr[EV_DynStPtr[s].custEntityObj].refNo))

/***************************
** Macro GET_DYNST_ENTITY
** Return the customer entity object enum (OBJECT_ENUM) which is
** NullEntity if there isn't a customer entity associated to the
** dynamic structure
** s = DBA_DYNST_ENUM
***************************/
inline OBJECT_ENUM GET_DYNST_ENTITY(const DBA_DYNST_ENUM s) { return EV_DynStPtr[s].entity; }

/***************************
** Macro GET_CUST_ENTITY
** Return the customer entity object enum (OBJECT_ENUM) which is
** NullEntity if there isn't a customer entity associated to the
** dynamic structure
** s = DBA_DYNST_ENUM
***************************/
inline OBJECT_ENUM GET_CUST_ENTITY(const DBA_DYNST_ENUM s) { return EV_DynStPtr[s].custEntityObj; }


/***************************
** Macro GET_PRECOMP_ENTITY
** Return the customer entity object enum (OBJECT_ENUM) which is
** NullEntity if there isn't a customer entity associated to the
** dynamic structure
** s = DBA_DYNST_ENUM
***************************/
inline OBJECT_ENUM GET_PRECOMP_ENTITY(const DBA_DYNST_ENUM s) { return EV_DynStPtr[s].precompEntityObj; }


/***************************
** Macro IS_VALID_FLD_FK
** 
** p  = pointer on dynamic structure (DBA_DYNFLD_STP)
***************************/
inline bool IS_VALID_FLD_FK(const DBA_DYNFLD_STP p)
{
    return (p != nullptr && GET_FLD_FK(p->getDynStEn()) != Null_Dynfld && IS_NULLFLD(p, GET_FLD_FK(p->getDynStEn())) == FALSE);
}

/***************************
** Macro GET_DYNSTDEFPTR(s)
** Return structure definition
** pointer (DBA_DYNSTDEF_STP)
** s = DBA_DYNST_ENUM
***************************/
#define GET_DYNSTDEFPTR(s) (EV_DynStPtr[s].dynStDefPtr)

/***************************
** Macro ALLOC_STRFLD(f,s)
** one more char allocated for null termination
** f = pointer on field
** s = size to allocate
***************************/
#define ALLOC_STRFLD(f,s)	{ f.data.strData.ptr = (char *)REALLOC(f.data.strData.ptr,  static_cast<size_t>((((s) + 1) * sizeof(char)))); memset(f.data.strData.ptr, 0, (((s) + 1) * sizeof(char))); SET_MAXALLOCFLG_T(&f, 0); }

/***************************
** Macro ALLOC_USTRFLD(f,s)
** Allocate memory for a unicode string
** f = pointer on field
** s = size to allocate
***************************/
#define ALLOC_USTRFLD(f,s)	{ f.data.ustrData.ptr = (UChar *)REALLOC(f.data.ustrData.ptr, static_cast<size_t>((((s) + 1) * sizeof(UChar)))); memset(f.data.ustrData.ptr, 0, (((s) + 1) * sizeof(UChar))); SET_MAXALLOCFLG_T(&f, 0); }

/***************************
** Macro FREE_STRFLD(f,s)
** Free memory for a string
** f = pointer on field
***************************/
#define FREE_STRFLD(f)	{ FREE(f.data.strData.ptr); SET_MAXALLOCFLG_F(&f, 0); }

/***************************
** Macro FREE_USTRFLD(f,s)
** Free memory for a string
** f = pointer on field
***************************/
#define FREE_USTRFLD(f)	{ FREE(f.data.ustrData.ptr); SET_MAXALLOCFLG_T(&f, 0); }


#endif					/* ifndef DBAMAC_H */
/************************************************************************
**      END        dbamac.h
*************************************************************************/

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines      
*************************************************************************/
#define AAAGUI_C

#define	STDIO_H
#define STRING_H
#define STDLIB_H	/* Necessary for date.h sur IBM */
#define TIME_H		/* Necessary for date.h sur IBM */

/************************************************************************
**      Include files
*************************************************************************/
#include <windows.h>
#include "sysnt.h"  /* REF7264 - PMO */
#include "QCoreApplication" /* PMSTA-20235 - CHU - 150421 */

#define ERR_LIB AAAADVANTAGE

#ifdef __cplusplus      /*  FIH-REF7264-020204  */
extern "C"
{
#endif
#include <nd.h>
#ifdef __cplusplus      /*  FIH-REF7264-020204  */

}
#endif

ERR_DECLARE

#include "unidef.h"     /* Mandatory */
#include "main.h"

#include "guigen.h"
#include "csrv.h"
#include "sig.h"

#include "sysnt.h"  /* REF7264 - PMO */

#ifndef CALLSTACK_H
#include "callstack.h"
#endif

extern char    SV_KeywordNT[64];
extern char    SV_Display[50];

extern char    SV_User[MAX_USERINFO_LEN + 1];
extern char    SV_UserPrefix[MAX_USERINFO_LEN + 1];         /* HFI-PMSTA-27422-170531   */


/************************************************************************
*   Function             : initCallback()
*
*   Description          : No special initialization at this level for the GUI
*
*   Arguments            : None
*
*   Functions call       : None
*
*   Return               : None
*
*   Creation Date        : PMSTA-19735 - 020415 - PMO : OpenServer / P1 / Thread handling
*
*   Last Modif.          : PMSTA-24076 - 180716 - PMO : Unstable connections
*
*************************************************************************/
void initCallback()
{
    SYS_SetCallBackThreadDataCtxGeneric(GEN_ThreadDataCtxGenericCreate
                                       ,GEN_ThreadDataCtxGenericAllocate
                                       ,GEN_ThreadDataCtxGenericInit
                                       ,GEN_ThreadDataCtxGenericPrepareApplicationData      /* PMSTA-24076 - 180716 - PMO */
                                       ,GEN_ThreadDataCtxGenericCleaningApplicationData     /* PMSTA-24076 - 180716 - PMO */
                                       ,GEN_ThreadDataCtxGenericDestroy);
}

/************************************************************************
**
**  Function    :   AAA_FreeQCoreApplication()
**
**  Description :   Delete the QCoreApplication after all other global memory object
**                  This avoid to delete QCoreApplication while some threads might still running and might do an HTTP connection that use some internal part of QCoreApplication.
**                  The shutdown order is:
**                  1) The main is left
**                  2) All threads terminated
**                  3) Some global variables are freed
**                  4) Delete the HttpServer and his ressources
**                  5) QCoreApplication is deleted
**  Argument    :
**
**  Return      :   None
**
**  Last modif. :   PMSTA-33076 - 071218 - PMO : Financial server crash when stopping
**
*************************************************************************/
QCoreApplication * SV_App;

void AAA_FreeQCoreApplication()
{
    
    delete SV_App;

    SV_App = nullptr;
}

#pragma warning(disable:4189)

/************************************************************************
**
**  Function    :   mainTripleAProgram
**
**  Description :   application entrypoint
**                  executable accepts parameters
**                  -Uusername or -U username
**                  -Ppassword or -P Password
**                  -Sserver or -S Server
**                  -display DISPLAY
**                  -W
**
**  Arguments   :   argc   arguments number
**                  argv   arguments list
**
**  Return      :   none
**
**  Modif.      :   ROI - 970318 - DVP388
**                  GRD - 971103 - REF1038.
**                  FIH - 980306 - REF064
**                  ROI - 980317 - REF1447
**                  REF9165 - 030610  - PMO : Display the call stack
**                  REF10380 - 041124 - EFE : Stack size problem with HPUX when creating threads
**                                            the new stck size value must be multiple of 8192
**                  PMSTA-9107 -141209 - PMO : Fix visual C++ 2008 issues
**                  PMSTA-16443 - 230713 - PMO : Add confirmation-to-continue messages in case not enough free memory is available for the GUI when loading data from a financial server
**                  PMSTA-18094 - 130514 - PMO : Avoid extracting the user credentials from the GUI running on Windows (via dump, etc.)
**                  PMSTA-18893 - 101114 - PMO : Core dump during precomp on instrument
**                  PMSTA-19736 - 030315 - PMO : OpenServer, Client / P1 / Locking
**                  PMSTA-19735 - 020415 - PMO : OpenServer / P1 / Thread handling
**                  PMSTA-20089 - 120515 - PMO : Unification of code for mono-threaded (static variable context) and multi-threaded (thread local variable).
**                  PMSTA-19737 - 270516 - PMO : OpenServer HTTP & HTTPS server (include POC already done)
**                  PMSTA-24510 - 220816 - PMO : Fusion & Dispatcher in HTTP
**                  PMSTA-25236 - 231116 - PMO : Remove AAACORE environment variable handling
**                  PMSTA-30823 - 050418 - PMO : SCPT_FmtEltAnalyse: Source and destination overlap in mempcpy
**                  PRO-7103 - 280818 - PMO : Provide libraries log4cplus on different platforms
**                  PMSTA-34824 - 210219 - PMO : Regression: several core file generated while running the TaAutomator night batch (HttpConnectionHandler)
**
*************************************************************************/
int mainTripleAProgram(int argc, char *argv[])
{
    RET_CODE    ret;

    extern bool OIT_WarningMessageBox(const char *);
    DBA_SetWarningMessageBox(OIT_WarningMessageBox);
    SCPT_SetCallBack_GUI_BuildNodeTree(GUI_BuildNodeTree);

    /* < PMSTA-20235 - CHU - 150421 */
    /*
    * QT initialization
    */
    int argcOneOnly = 1;
    SV_App = new QCoreApplication(argcOneOnly, argv);                                                   /* PMSTA-33076 - 071218 - PMO */

    SYS_AddCallBackForProgramState(ProgramState::ShutdownQtFree, AAA_FreeQCoreApplication);             /* PMSTA-33076 - 071218 - PMO */

    EV_TimerMask = TIMER_MASK_GEN;

    /* General Initialization */
    ret = GEN_Initial();

#if !defined _WIN64
    HOOK_Install(argv[0], HOOK_SetGUIHook);
#endif

    if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
    {
        /* PMSTA-14360 - 130508 - TGU */
        if (ret == RET_SYS_ERR_REPERTORY)
        {
            /* PMSTA-14360 - 130508 - TGU - To charge and Initialize the necessary library to popup the error msg window */
            if (GUI_Begin(argc, argv) == FALSE)
            {
                return(1);

            }
            /* Build appropriate error messages for "ret" value RET_SYS_ERR_REPERTORY */
            char buffer[1024] = "";
            char     *envVar;
            if (((envVar = SYS_GetEnv("AAAMSG")) != NULL) && SYS_Access(envVar) == FALSE)
            {
                sprintf(buffer, " AAAMSG path not found: %s \n", envVar);                       /* PMSTA-30823 - 050418 - PMO */
            }
            if (((envVar = SYS_GetEnv("AAAOIT")) != NULL) && SYS_Access(envVar) == FALSE)
            {
                char * endBuffer = buffer + strlen(buffer);                                     /* PMSTA-30823 - 050418 - PMO */
                sprintf(endBuffer, " AAAOIT path not found: %s \n", envVar);                    /* PMSTA-30823 - 050418 - PMO */
            }
            if (((envVar = SYS_GetEnv("AAABIN")) != NULL) && SYS_Access(envVar) == FALSE)
            {
                char * endBuffer = buffer + strlen(buffer);                                     /* PMSTA-30823 - 050418 - PMO */
                sprintf(endBuffer, " AAABIN path not found: %s \n", envVar);                    /* PMSTA-30823 - 050418 - PMO */
            }
            if (((envVar = SYS_GetEnv("AAAREP")) != NULL) && SYS_Access(envVar) == FALSE)
            {
                char * endBuffer = buffer + strlen(buffer);                                     /* PMSTA-30823 - 050418 - PMO */
                sprintf(endBuffer, " AAAREP path not found: %s ", envVar);                      /* PMSTA-30823 - 050418 - PMO */
            }
            MSG_DispMsgText(ret, buffer);
            GUI_End();
        }
        return(1);
    }

    /* Client/Server DataBase Access Initialization */
    if ((ret = CSRV_Init(true)) != RET_SUCCEED)
    {
        MSG_RETURN(ret);        /*  FIH-REF3882-990809  Add a message in log    */
    }

    /*
    ** change of current working directory in
    ** GEN_Initial disabled for NT because
    ** SYBASE DLL must be initialized before
    */
    SYS_ChangeDir(GEN_GetPath(BinDir));

    if (*SV_Display)
    {
        SYS_PutEnv("DISPLAY", SV_Display);
    }

    EV_OptiMemFlg = TRUE;

    if (GUI_Begin(argc, argv) == FALSE)		/* ROI - 980317 - REF1447 */
    {
        return(1);
    }

    EV_GuiActivatedFlg = 1;

#ifndef SANITIZER_BUILD
    INSTALL_SIGHUP;
    INSTALL_SIGINT;
    INSTALL_SIGPIPE;
    INSTALL_SIGSEGV;
#endif

    /*  TEST if a variable is set correctly FIH-REF064-980306  */
    char        *xconStr;
    FLAG_T      runFlag = TRUE;

    /*  TEST if a variable is set correctly FIH-REF064-980306  */
	if (((xconStr = SYS_GetEnv("AAAMDI")) != NULL) &&
        (strcmp(xconStr, "TRUE") == 0) &&  // AAAMDI exist && TRUE
        ((xconStr = SYS_GetEnv("ND_NATIVEMENU")) != NULL) &&
        (strcmp(xconStr, "FALSE") == 0))  // ND_NATIVEMENU exist && FALSE
    {
        MSG_DispMsgText(
            RET_SUCCEED, "Turning AAAMDI to FALSE as functionality not compatible with ND_NATIVEMENU set to FALSE");

        SYS_PutEnv("AAAMDI", "FALSE");
        runFlag = FALSE;
    }

    /* Opens About window and start GUI Event Loop */

    char*       pszKeywordNT = NULL;                /*  HFI-PMSTA-26560-171001  transmit NT registry to GUI code    */
    pszKeywordNT = SV_KeywordNT;

    PasswordEncrypted * pE = nullptr;
    GEN_GetUserInfo(UserPasswd, &pE);
    if (GUI_Start(SV_User, *pE, SV_UserPrefix, pszKeywordNT) != RET_SUCCEED)    /* PMSTA-18094 - 130514 - PMO */  /* HFI-PMSTA-27422-170531   Add prefix  */    /*  HFI-PMSTA-26560-171001  NT registry */
    {
        GUI_End();
        return(1);
    }

    /* GUI Termination */
    GUI_End();
    EV_GuiActivatedFlg = 0;

    NT_Done();
 
    return(0);
}

#pragma warning(default:4189)

/************************************************************************
**
**  Function    :   main()
**
**  Description :   Application entry point
**
**  Arguments   :   argc  parameters number
**                  argv  parameters list (first is application)
**
**  Return      :   0 if ok
**                  >0 if error
**
**  Last modif. :   PMSTA-19735 - 020415 - PMO : OpenServer / P1 / Thread handling
**
*************************************************************************/
int main(int argc, char *argv[])
{
    return mainExceptionHandling(argc, argv);
}

/************************************************************************
**
**  Function    :   OIT_Begin
**
**  Description :   Default initialization
**
**  Arguments   :   int argc, char **argv
**
**  Return      :   none
**
**  Modif.      :   ROI - 980317 - REF1447
**
*************************************************************************/
void	OIT_Begin(int argc, char **argv)
{
    /* default initialization */
    ERR_MAININIT;
    ERR_MODULEUSE;
    ND_Init(argc, argv);
}

/************************************************************************
**
**  Function    :   OIT_End()
**
**  Description :   Default termination
**
**  Arguments   :   none
**
**  Return      :   int
**
**  Modif.      :   ROI - 980317 - REF1447
**
*************************************************************************/
int	OIT_End()
{

    /* default termination */
    ND_Exit();

    return EXIT_OK;
}

/************************************************************************
**
**  Function    :   GEN_GetProgramType()
**
**  Description :   Return AAA programm type
**
**  Arguments   :
**
**  Return      :   AAAProgramType
**
**  Creation    :   PMSTA-54990 - DDV - 231201
**  Last modif. :
**
*************************************************************************/
AAAProgramType GEN_GetProgramType()
{
    return(AAAProgramType::Gui);
}

/************************************************************************
**      END	aaagui.c
*************************************************************************/

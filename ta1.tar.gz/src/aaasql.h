/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef AAASQL_H
#define AAASQL_H

#include "rpclib.h"

/************************************************************************
**      Constant & Macro definitions
*************************************************************************/

/************************************************************************
**      Structures & typedef definitions
*************************************************************************/

typedef struct
{
    FILE   *fp;
    char *path;
    int   line;
    CURRENTCHARSETCODE_ENUM CharSet;

} AAASQL_STREAM_ST,
*AAASQL_STREAM_STP;

typedef struct
{
    AAASQL_STREAM_STP streams;
    int               level;
} AAASQL_ISTREAM_ST,
*AAASQL_ISTREAM_STP;

typedef AAASQL_STREAM_ST
AAASQL_OSTREAM_ST,
*AAASQL_OSTREAM_STP;

class AaaSqlContext
{
public:

    AaaSqlContext(DBA_RDBMS_ENUM rdbmsEn)
        : ctx(nullptr)
        , ddlGenContext(rdbmsEn, false)
        , ddlGenVarHelperPtr(nullptr)
        , scriptDdlGenPtr(nullptr)
        , ddlGenPtr(nullptr)
        , finSrvConnHelperPtr(nullptr)
        , sqlConnHelperPtr(nullptr)
        , connHelperPtr(nullptr)
        , bStartUp(false)
        , bFinSrvMode(false)
        , bSetParamDone(false)
        , verboseLevel(VerboseLevel_iSQL)
        , bPrintHeader(true)
        , bPrintAllign(true)
        , bPrintRowCount(true)
        , bPrintEcho(false)
        , bHeaderLowerCase(false)
        , optimLevel(1)
        , maxScale(-1)
        , rowCount(0)
        , colWidth(0)
        , inDateTimeStyleEn(DateStyle_MmmDdYyyy12)
        , dbInDateTimeStyleEn(DateStyle_MmmDdYyyy12)
        , bInDateTimeStyleChange(false)
        , outDateTimeStyleEn(DateStyle_MmmDdYyyy12)
        , bComment(false)
        , bDefWaitGo(false)
        , bWaitGo(false)
        , bWaitEndOfCmd(true)
        , lastRetCode(RET_SUCCEED)
        , inputCharSet(CurrentCharsetCode_UTF8)
        , charSet(CurrentCharsetCode_IsNull)
        , dataIdx(0)
        , bSkipNextBloc(false)
    {
        CURRENTCHARSETCODE_ENUM  charsetCode;

        /* initializing istream */
        this->istream.streams = NULL;
        this->istream.level = 0;

        /* initializing ostream */
        this->ostream.fp = stdout;
        this->ostream.path = NULL;
        this->ostream.line = 0;

        charsetCode = CurrentCharsetCode_IsNull;
        GEN_GetApplInfo(ApplCurrentCharsetOutputEnum, &charsetCode);
        if (charsetCode == CurrentCharsetCode_IsNull)
        {
            GEN_GetApplInfo(ApplCurrentCharsetCodeEnum, &charsetCode);
        }

        this->ostream.CharSet = charsetCode;

        /* initializing estream */
        this->estream.fp = stderr;
        this->estream.path = NULL;
        this->estream.line = 0;
        this->estream.CharSet = charsetCode;

        this->bDefWaitGo = EV_RdbmsVendor == Sybase ? true : false;
        this->bWaitGo = this->bDefWaitGo;

        this->serverName = EV_Server;
    }

    bool isTransactionNeeded()
    {
        switch (EV_RdbmsVendor)
        {
            case Oracle:
                if (this->scriptDdlGenPtr != nullptr &&
                    this->scriptDdlGenPtr->bAutoCommit == false)
                {
                    return false;
                }
                break;

            case Sybase:
            default:
                if (this->scriptDdlGenPtr != nullptr &&
                    this->scriptDdlGenPtr->bAutoCommit == true)
                {
                    return false;
                }
                break;
        }

        return true;
    }

    void convert()
    {
        if (charSet == CurrentCharsetCode_IsNull)
        {
            GEN_GetApplInfo(ApplCurrentCharsetInputEnum, &inputCharSet);
            GEN_GetApplInfo(ApplCurrentCharsetCodeEnum, &charSet);
        }

        if (charSet != CurrentCharsetCode_IsNull && charSet != inputCharSet)
        {
            int    ret;
            UChar *lineUChar;
            int lineLen = static_cast<int>(this->currBlock.str().length() + 1), uCharLen;
            lineUChar = (UChar*)CALLOC(lineLen, sizeof(UChar));

            switch (inputCharSet)
            {
                case CurrentCharsetCode_Iso_1:
                    ret = ICU4AAA_ConvertFromISO1(this->currBlock.str().c_str(), lineLen, lineUChar, lineLen, &uCharLen);
                    break;

                case CurrentCharsetCode_UTF8:
                    ret = ICU4AAA_ConvertFromUTF8(this->currBlock.str().c_str(), lineLen, lineUChar, lineLen, &uCharLen);
                    break;

                case CurrentCharsetCode_Iso_8:
                    ret = ICU4AAA_ConvertFromISO8(this->currBlock.str().c_str(), lineLen, lineUChar, lineLen, &uCharLen);
                    break;

                case CurrentCharsetCode_Ascii_7:
                    ret = ICU4AAA_ConvertFromASCII(this->currBlock.str().c_str(), lineLen, lineUChar, lineLen, &uCharLen);
                    break;

                case CurrentCharsetCode_Cp850:
                case CurrentCharsetCode_Cp437:
                case CurrentCharsetCode_Roman8:
                case CurrentCharsetCode_Mac:
                case CurrentCharsetCode_Iso_5:
                default:
                    ret = ICU4AAA_ConvertFromASCII(this->currBlock.str().c_str(), lineLen, lineUChar, lineLen, &uCharLen);
            }

            if (ret == 0)
            {
                char *line = nullptr;
                int   isoLen = 0;

                ICU4AAA_ConvertToDefaultCharSet(lineUChar, uCharLen, &line, &isoLen);
                FREE(lineUChar);

                this->currBlock.clear();
                currBlock.str(line);
                FREE(line);
            }
        }
    }

    AAASQL_ISTREAM_ST  istream;
    AAASQL_OSTREAM_ST  ostream;
    AAASQL_OSTREAM_ST  estream;
    void			  *ctx;

    std::string        separator;

    std::stringstream  currBlock;
    std::string        lastBlockStr;
    DdlGenString       firstCmd;


    std::string           sqlCmd;
    std::set<std::string> defEndOfCommands;

    DdlGenContext      ddlGenContext;
    DdlGenVarHelper   *ddlGenVarHelperPtr;
    DdlGenFromFile    *scriptDdlGenPtr;
    DdlGen            *ddlGenPtr;

    DbiConnectionHelper	*finSrvConnHelperPtr;
    DbiConnectionHelper	*sqlConnHelperPtr;
    DbiConnectionHelper	*connHelperPtr;

    bool                 bStartUp;
    bool                 bFinSrvMode;
    bool                 bSetParamDone;
    std::string          rpcName;

    RpcProperties        rpcProperties;

    VERBOSE_LEVEL_ENUM   verboseLevel;

    bool                 bPrintHeader;
    bool                 bPrintAllign;
    bool                 bPrintRowCount;
    bool                 bPrintEcho;
    bool                 bHeaderLowerCase;
    int                  optimLevel;
    int                  maxScale;
    int                  rowCount;

    size_t               colWidth;

    std::string          serverName;
    std::string          currServerName;

    DATE_STYLE_ENUM      inDateTimeStyleEn;
    DATE_STYLE_ENUM      dbInDateTimeStyleEn;
    bool                 bInDateTimeStyleChange;
    DATE_STYLE_ENUM      outDateTimeStyleEn;

    bool                 bComment;
    bool                 bDefWaitGo;
    bool                 bWaitGo;
    bool                 bWaitEndOfCmd;

    RET_CODE             lastRetCode;
    std::string          ddlObjSqlName;
    std::string          ddlObjDbSqlName;

    CURRENTCHARSETCODE_ENUM inputCharSet;
    CURRENTCHARSETCODE_ENUM charSet;

    size_t                  dataIdx;

    bool                    bSkipNextBloc;
};

typedef struct AAASQL_OUTPUT_PARAM
{
    short         nullInd;
    SYSNAME_T     colName;
    void         *data;
    DATATYPE_ENUM dataType;
    int           colWith;
    int           dataSize;
    int           precision;
    int           scale;

    char          szAlignPos[2];
} AAASQL_OUTPUT_PARAM_ST, *AAASQL_OUTPUT_PARAM_STP;


/************************************************************************
**      External definitions attached to : aaasql.cpp
*************************************************************************/

#endif	                               /* ifndef AAASQL_H */
/************************************************************************
**      END       aaasql.h                                   Odyssey
*************************************************************************/

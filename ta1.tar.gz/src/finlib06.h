/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef FINLIB06_H
#define FINLIB06_H

/************************************************************************
**      BEGIN : Global variables & external definitions attached to finlib06.c
*************************************************************************/
#ifdef  EXTERN
    #undef  EXTERN
#endif
#ifdef  FINLIB06_C
    #define	EXTERN
#else
    #define EXTERN extern
#endif

EXTERN RET_CODE FIN_StratCreateESEHeader(DBA_HIER_HEAD_STP, int, DBA_DYNFLD_STP, int, int*);
EXTERN RET_CODE FIN_StratCreateESEAlloc(DBA_HIER_HEAD_STP, int, DBA_DYNFLD_STP, FLAG_T);
EXTERN RET_CODE FIN_CreateESEfromGrid(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP); /* PMSTA-20843 - CHU - 150723 */
EXTERN RET_CODE FIN_SelectGridMktSgtCompute(DBA_DYNFLD_STP, PTR); /* PMSTA-20843 - CHU - 150724 */
EXTERN RET_CODE FIN_StratMktSegtFromGridMktSSubSet(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP**, int*);

EXTERN int FIN_FilterMktSSubSetFromGrid(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);   /* REF7420 - RAK - 020703 */

#endif /* FINLIB06_C */

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef DDLGENFK_H
#define DDLGENFK_H

#include      "ddlgen.h"

/************************************************************************
**      Constant & Macro definitions
*************************************************************************/

/************************************************************************
**      Structures & typedef definitions
*************************************************************************/

/************************************************************************
**      External definitions attached to : ddlgenfk.cpp
*************************************************************************/
#ifdef  EXTERN
#undef	EXTERN
#endif
#ifdef  DDLGENFK_CPP
#define	EXTERN
#else
#define EXTERN extern
#endif

class DdlGenFK :public DdlGen {

public:
    // Constructors
    DdlGenFK(OBJECT_ENUM         paramObjectEn,
             DdlGenContext      &paramDdlGenContext,
             DdlGenEntity       *paramDdlGenEntityPtr,
             DdlGenFile         *paramFileHelper,
             TARGET_TABLE_ENUM   paramTargetTableEn);

    DdlGenFK(const DdlGen&);

    DdlGenFK(const DdlGenFK&) = delete;
    // Destructor
    virtual ~DdlGenFK();

    // Methods
    DdlGenFK&         operator = (const DdlGenFK&) = delete;
    RET_CODE          build();
    RET_CODE          createPk();

    RET_CODE dropByRefEntity();
    RET_CODE createByRefEntity();

    static bool isFKOnEntity(DICT_ENTITY_STP dictEntityStp);

protected:
    // Methods
    RET_CODE          printFooter();

    RET_CODE          dropOneFK(DICT_ATTRIB_STP);
    RET_CODE          createOneFK(DICT_ATTRIB_STP, bool);

    bool              isFKAttrib(const DICT_ATTRIB_STP currAttribStp) const;

    RET_CODE          drop();
    RET_CODE          create();
    RET_CODE          grant();

    RET_CODE          setName();
    RET_CODE          setName(DICT_T attribDictId);

    std::string       getPrimaryKey();

    std::map<DdlObjDefKey, DdlObjDef>  m_AllDbForeignKeySet;
    std::string                        m_fkCreationStr;
    std::string                        m_fkValidateStr;
    std::vector<std::string>           m_fkBeginValidateVec;
    std::vector<std::string>           m_fkEndValidateVec;

private:

};

#endif	                               /* ifndef DDLGENFK_H */
/************************************************************************
**      END       ddlgentable.h                                   Odyssey
*************************************************************************/

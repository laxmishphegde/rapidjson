/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define COMPOUND_C

/************************************************************************
**      local functions
**
**
*************************************************************************/

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H
#define MALLOC_H

#include "unidef.h"     /* Mandatory */

#include "dba.h"
#include "tls.h"	    /* Necessary for sorting. */
#include "proc.h"
#include "gen.h"
#include "syslib.h"     /* PMO - Rename our sys.h to syslib.h and use it */
#include "scptyl.h"		/* necessary for SCPT_ComputeScreenDV */
#include "compound.h"
#include "msg.h"
#include "ope.h"

#include <string>

/************************************************************************
**      Static definitions & data
*************************************************************************/
STATIC int	DBA_ExtOpByCompMasIdCompOrdCodeCompSlvEltIdCmp(DBA_DYNFLD_STP*, DBA_DYNFLD_STP*);
STATIC int DBA_SlaveEltTabByCompoundSlaveEltIdCmp(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2);

/************************************************************************
*
*   Function             : FIN_CompoundLockOpCode
*
*   Description          :
*
*   Arguments            : pflagtab        Forced flag tab
*
*   Creation Date        :
*
*************************************************************************/
extern void FIN_CompoundLockOpCodeAccCode(FLAG_T *pflagtab)
{
    FLAG_T  autoCodeGenFlag = TRUE, autoAccCodeGenFlag = TRUE;  /*PMSTA-28686 - Silpakal - 190227*/

    /*PMSTA-28686 - Silpakal - 190227*/
	DBA_GetNewDocIndexCodeFlag(static_cast<ENUM_T>(DocIndexNat_OperationCd), autoCodeGenFlag);
	DBA_GetNewDocIndexCodeFlag(static_cast<ENUM_T>(DocIndexNat_AccountingCd), autoAccCodeGenFlag);

    /* Default value for code and accounting code for operation  */
    if (autoCodeGenFlag == TRUE)
    {
        /* if code is forced, depending fields must be computed */
        if (pflagtab[ExtOp_Cd] != TRUE)
            pflagtab[ExtOp_Cd] = EvalAttr_NoDependency;
    }
    if (autoAccCodeGenFlag == TRUE)
    {
        /* if accounting code is forced, depending fields must be computed */
        if (pflagtab[ExtOp_AcctCd] != TRUE)
            pflagtab[ExtOp_AcctCd] = EvalAttr_NoDependency;
    }
}



/************************************************************************
*
*   Function             : FIN_CreateAllCompoundOperation
*
*   Description          :
*
*   Arguments            : srvProc      Pointer to the Sybase array
*                          entityArg    Pointer to the dynamic structure
*
*   Creation Date        :
*
*************************************************************************/
RET_CODE    FIN_CreateAllCompoundOperation(DBA_DYNFLD_STP mastertOpStp,
                                           FLAG_T         *masterExtOpFlagTab,
										   DBA_DYNFLD_STP **extOpResultTab,
										   int            *extOpResultNbr)
{

	RET_CODE           retCode = RET_SUCCEED;
    DBA_DYNFLD_STP     sMasterEltStp = NULL, aMasterEltStp = NULL,
					   sSlaveEltStp=NULL, *slaveEltTab=(DBA_DYNFLD_STP*)NULL;
	DBA_DYNFLD_STP    *extOpTab= NULL;
	int                slaveEltNbr = 0;
	int                i,j;
    FLAG_T           **allFlagTab = (FLAG_T **)NULL;
    FLAG_T            *tmpFlagTab = (FLAG_T *)NULL;
    DBA_HIER_HEAD_STP  hierHead;

    *extOpResultTab = NULL;
    *extOpResultNbr = 0;

    if ((aMasterEltStp = ALLOC_DYNST(A_CompoundOrderMasterElt)) == NULLDYNST)
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    if (masterExtOpFlagTab[ExtOp_CompoundOrderMasterEltId] == TRUE)
    {
        /* if master is given with null value, it's an error */
        if (IS_NULLFLD(mastertOpStp, ExtOp_CompoundOrderMasterEltId) == TRUE)
        {
            FREE_DYNST(aMasterEltStp, A_CompoundOrderMasterElt);
            return(RET_DBA_ERR_INVDATA);
        }

        if ((sMasterEltStp = ALLOC_DYNST(S_CompoundOrderMasterElt)) == NULLDYNST)
        {
            FREE_DYNST(aMasterEltStp, A_CompoundOrderMasterElt);
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        COPY_DYNFLD(sMasterEltStp, S_CompoundOrderMasterElt, S_CompoundOrderMasterElt_Id, mastertOpStp, ExtOp, ExtOp_CompoundOrderMasterEltId);

        if ((retCode = DBA_Get2(CompoundOrderMasterElt,
                                UNUSED,
                                S_CompoundOrderMasterElt,
                                sMasterEltStp,
                                A_CompoundOrderMasterElt,
                                &aMasterEltStp,
                                UNUSED,
                                UNUSED,
                                UNUSED)) != RET_SUCCEED)

        {
            FREE_DYNST(sMasterEltStp, S_CompoundOrderMasterElt);
            FREE_DYNST(aMasterEltStp, A_CompoundOrderMasterElt);
            MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "compound_order_master_elt");
        }
        FREE_DYNST(sMasterEltStp, S_CompoundOrderMasterElt);

        /* if nature is given, check that it match master operation, else return an error */
        if (masterExtOpFlagTab[ExtOp_NatureEn] == TRUE &&
            CMP_DYNFLD(mastertOpStp, aMasterEltStp, ExtOp_NatureEn, A_CompoundOrderMasterElt_OpNature, EnumType) != 0)
        {
            FREE_DYNST(aMasterEltStp, A_CompoundOrderMasterElt);
            return(RET_DBA_ERR_INVDATA);
        }
        else
        {
            COPY_DYNFLD(mastertOpStp, ExtOp, ExtOp_NatureEn,
                        aMasterEltStp, A_CompoundOrderMasterElt, A_CompoundOrderMasterElt_OpNature);
            masterExtOpFlagTab[ExtOp_NatureEn] = TRUE;
        }


        /* if type is given, check that it match master operation, else return an error */
        if (masterExtOpFlagTab[ExtOp_TpId] == TRUE &&
            CMP_DYNFLD(mastertOpStp, aMasterEltStp, ExtOp_TpId, A_CompoundOrderMasterElt_OpTypeId, IdType) != 0)
        {
            FREE_DYNST(aMasterEltStp, A_CompoundOrderMasterElt);
            return(RET_DBA_ERR_INVDATA);
        }
        else
        {
            COPY_DYNFLD(mastertOpStp, ExtOp, ExtOp_TpId,
                        aMasterEltStp, A_CompoundOrderMasterElt, A_CompoundOrderMasterElt_OpTypeId);
            masterExtOpFlagTab[ExtOp_TpId] = TRUE;
        }

        /* if subtype is given, check that it match master operation, else return an error */
        if (masterExtOpFlagTab[ExtOp_SubTpId] == TRUE &&
            CMP_DYNFLD(mastertOpStp, aMasterEltStp, ExtOp_SubTpId, A_CompoundOrderMasterElt_OpSubTypeId, IdType) != 0)
        {
            FREE_DYNST(aMasterEltStp, A_CompoundOrderMasterElt);
            return(RET_DBA_ERR_INVDATA);
        }
        else
        {
            COPY_DYNFLD(mastertOpStp, ExtOp, ExtOp_SubTpId,
                        aMasterEltStp, A_CompoundOrderMasterElt, A_CompoundOrderMasterElt_OpSubTypeId);
            masterExtOpFlagTab[ExtOp_SubTpId] = TRUE;
        }

        /* if order type is given, check that it match master operation, else return an error */
        if (masterExtOpFlagTab[ExtOp_OrderTypeId] == TRUE &&
            CMP_DYNFLD(mastertOpStp, aMasterEltStp, ExtOp_OrderTypeId, A_CompoundOrderMasterElt_OpOrderTypeId, IdType) != 0)
        {
            FREE_DYNST(aMasterEltStp, A_CompoundOrderMasterElt);
            return(RET_DBA_ERR_INVDATA);
        }
        else
        {
            COPY_DYNFLD(mastertOpStp, ExtOp, ExtOp_OrderTypeId,
                        aMasterEltStp, A_CompoundOrderMasterElt, A_CompoundOrderMasterElt_OpOrderTypeId);
            masterExtOpFlagTab[ExtOp_OrderTypeId] = TRUE;
        }
    }
    else /* master not given, use nature_e, op_type, op_subtype and ordertype to find master */
    {
        /* get the values of opNature,typeId,subtypeId, orderTypeId from extOperation */
        /* Write a query to get the master elt from CompoundOrderMasterElt based on these four fields */
        if ((retCode = DBA_Get2(CompoundOrderMasterElt,
            UNUSED,
            ExtOp,
            mastertOpStp,
            A_CompoundOrderMasterElt,
            &aMasterEltStp,
            UNUSED,
            UNUSED,
            UNUSED)) != RET_SUCCEED)

        {
            MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "compound_order_master_elt");
            FREE_DYNST(aMasterEltStp, A_CompoundOrderMasterElt);
            return(RET_DBA_ERR_NODATA);
        }

        COPY_DYNFLD(mastertOpStp, ExtOp, ExtOp_CompoundOrderMasterEltId,
                    aMasterEltStp, A_CompoundOrderMasterElt, A_CompoundOrderMasterElt_Id);

        /* fix master, nature_e, type, subtype and ordertype fields */
        masterExtOpFlagTab[ExtOp_CompoundOrderMasterEltId] = TRUE;
        masterExtOpFlagTab[ExtOp_NatureEn] = TRUE;
        masterExtOpFlagTab[ExtOp_TpId] = TRUE;
        masterExtOpFlagTab[ExtOp_SubTpId] = TRUE;
        masterExtOpFlagTab[ExtOp_OrderTypeId] = TRUE;
    }

    COPY_DYNFLD(mastertOpStp, ExtOp, ExtOp_CompoundScreenDictId,
        aMasterEltStp, A_CompoundOrderMasterElt, A_CompoundOrderMasterElt_ScreenDictId);

    if ((sSlaveEltStp = ALLOC_DYNST(S_CompoundOrderSlaveElt)) == NULLDYNST)
    {
        FREE_DYNST(aMasterEltStp, A_CompoundOrderMasterElt);
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    /* load the master corresponding slave elements */
    COPY_DYNFLD(sSlaveEltStp, S_CompoundOrderSlaveElt, S_CompoundOrderSlaveElt_CompoundOrderMasterElt,
                aMasterEltStp, A_CompoundOrderMasterElt, A_CompoundOrderMasterElt_Id);

    if ((retCode = DBA_Select2(CompoundOrderSlaveElt, UNUSED,
					           S_CompoundOrderSlaveElt, sSlaveEltStp,
					           A_CompoundOrderSlaveElt, &slaveEltTab,
					           UNUSED, UNUSED,
					           &slaveEltNbr, UNUSED, UNUSED)) != RET_SUCCEED)
    {
        FREE_DYNST(aMasterEltStp, A_CompoundOrderMasterElt);
        FREE_DYNST(sSlaveEltStp, S_CompoundOrderSlaveElt);
        MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "compound_order_slave_elt");
        return(RET_DBA_ERR_NODATA);
    }

    FREE_DYNST(sSlaveEltStp, S_CompoundOrderSlaveElt);

    if (slaveEltNbr == 0)
    {
        FREE_DYNST(aMasterEltStp, A_CompoundOrderMasterElt);
        MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "compound_order_slave_elt");
        return(RET_DBA_ERR_NODATA);
    }

    /* if compound order code is not given, check it, else call DV to fill it (just it) */
    if (masterExtOpFlagTab[ExtOp_CompoundOrderCode] == TRUE)
    {
        /* if compound_order_code is given with null value, it's an error */
        if (IS_NULLFLD(mastertOpStp, ExtOp_CompoundOrderCode) == TRUE)
            return(RET_DBA_ERR_INVDATA);
    }
    else
    {

        if ((tmpFlagTab = (FLAG_T *)CALLOC(GET_FLD_NBR(ExtOp), sizeof(FLAG_T))) == NULL)
        {
            FREE_DYNST(aMasterEltStp, A_CompoundOrderMasterElt);
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        for (i = 0; i < GET_FLD_NBR(ExtOp); i++)
            tmpFlagTab[i] = TRUE;

        tmpFlagTab[ExtOp_CompoundOrderCode] = FALSE;

        SCPT_ComputeScreenDV(EOp,
                              NullDictFct,
                              tmpFlagTab,
                              NULL,         /* HFI-PMSTA-25327-171023  Dedicated flag tab for filter    */
                              mastertOpStp,
                              NULL,
                              NULLDYNST,
                              NULLDYNST,   /* PMSTA13283 - DDV - 120117 */
                              TRUE,				/* analyse type */
                              TRUE,				/* guiFlag */
                              EvalType_DefVal,   /* FPL-REF9507-030929  Only Def val    */
                              0,					/* attribIdx */
                              NULL,              /* connectNo */
                              NULL,				/* filterTab */
                              NULL,	            /* hierHead */
                              0,
                              DictScreen,        /*  FIH-REF9789-040209  */
                              NULL,
                              NULL,
                              NULL,
                              NULL,
                              NULL,
                              NullEntity,
                              FALSE,
                              FALSE,
                              GET_DICT(aMasterEltStp, A_CompoundOrderMasterElt_ScreenDictId));        /*  FPL-REF9215-030811  Flag Impact */

        FREE(tmpFlagTab);

        /* If no compound Code exists, procees is in error */
        if (IS_NULLFLD(mastertOpStp, ExtOp_CompoundOrderCode))
        {
        FREE_DYNST(aMasterEltStp, A_CompoundOrderMasterElt);
            DBA_FreeDynStTab(slaveEltTab, slaveEltNbr, A_CompoundOrderSlaveElt);
            MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "compound_order_slave_elt");
            return(RET_DBA_ERR_NODATA);
        }

        masterExtOpFlagTab[ExtOp_CompoundOrderCode] = TRUE;
    }

    FIN_CompoundLockOpCodeAccCode(masterExtOpFlagTab);
    masterExtOpFlagTab[ExtOp_CompoundOrderCode] = TRUE;

    /* Alloc ExtOpTab and allFlagTab arrays */
    if ((extOpTab = (DBA_DYNFLD_STP*)CALLOC(slaveEltNbr+1, sizeof(DBA_DYNFLD_STP))) == NULL)
	{
        FREE_DYNST(aMasterEltStp, A_CompoundOrderMasterElt);
        DBA_FreeDynStTab(slaveEltTab, slaveEltNbr, A_CompoundOrderSlaveElt);
        MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

    if ((allFlagTab = (FLAG_T **)CALLOC(slaveEltNbr+1, sizeof(FLAG_T *))) == NULL)
    {
        FREE_DYNST(aMasterEltStp, A_CompoundOrderMasterElt);
        DBA_FreeDynStTab(slaveEltTab, slaveEltNbr, A_CompoundOrderSlaveElt);
        FREE(extOpTab);
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

	/* Create all the operation corresponding to the slave elements for the master */
	for(i = 0 ; i < slaveEltNbr ; i++)
	{
        if ((extOpTab[i] = ALLOC_DYNST(ExtOp)) == NULLDYNST)
        {
            FREE_DYNST(aMasterEltStp, A_CompoundOrderMasterElt);
            DBA_FreeDynStTab(slaveEltTab, slaveEltNbr, A_CompoundOrderSlaveElt);
            DBA_FreeDynStTab(extOpTab, i, ExtOp);
            for (j = i; j < 0; j++)
                FREE(allFlagTab[j]);
            FREE(allFlagTab);
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtOp");
            return(RET_MEM_ERR_ALLOC);
        }

        if ((allFlagTab[i] = (FLAG_T *)CALLOC(GET_FLD_NBR(ExtOp), sizeof(FLAG_T))) == NULL)
        {
            FREE_DYNST(aMasterEltStp, A_CompoundOrderMasterElt);
            DBA_FreeDynStTab(slaveEltTab, slaveEltNbr, A_CompoundOrderSlaveElt);
            DBA_FreeDynStTab(extOpTab, i+1, ExtOp);
            for (j = i; j < 0; j++)
                FREE(allFlagTab[j]);
            FREE(allFlagTab);
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, GET_FLD_NBR(ExtOp), sizeof(FLAG_T));
            return(RET_MEM_ERR_ALLOC);
        }

        memset(allFlagTab[i], 0, sizeof(FLAG_T)* GET_FLD_NBR(ExtOp));

        /*  Filled data with metadictionnary def val                            */
        DBA_SetDfltEntityFld(EOp, ExtOp, extOpTab[i]);

        FIN_CompoundLockOpCodeAccCode(allFlagTab[i]);

        COPY_DYNFLD(extOpTab[i], ExtOp, ExtOp_CompoundOrderMasterEltId,
                    mastertOpStp, ExtOp, ExtOp_CompoundOrderMasterEltId);
        allFlagTab[i][ExtOp_CompoundOrderMasterEltId] = TRUE;

        COPY_DYNFLD(extOpTab[i], ExtOp, ExtOp_CompoundOrderSlaveEltId,
                    slaveEltTab[i], A_CompoundOrderSlaveElt, A_CompoundOrderSlaveElt_Id);
        allFlagTab[i][ExtOp_CompoundOrderSlaveEltId] = TRUE;

        COPY_DYNFLD(extOpTab[i], ExtOp, ExtOp_CompoundOrderCode,
                    mastertOpStp, ExtOp, ExtOp_CompoundOrderCode);
        allFlagTab[i][ExtOp_CompoundOrderCode] = TRUE;

        if ((LEGNATSLAVE_ENUM)GET_ENUM(slaveEltTab[i], A_CompoundOrderSlaveElt_LegNature) == LegNat_Multiple)
        {
            SET_INT(extOpTab[i], ExtOp_CompoundOrderSlaveNbr, 1);
            allFlagTab[i][ExtOp_CompoundOrderSlaveNbr] = TRUE;
        }

        COPY_DYNFLD(extOpTab[i], ExtOp, ExtOp_NatureEn,
                    slaveEltTab[i], A_CompoundOrderSlaveElt, A_CompoundOrderSlaveElt_OpNature);
        allFlagTab[i][ExtOp_NatureEn] = TRUE;

        COPY_DYNFLD(extOpTab[i], ExtOp, ExtOp_TpId,
                    slaveEltTab[i], A_CompoundOrderSlaveElt, A_CompoundOrderSlaveElt_OpTypeId);
        allFlagTab[i][ExtOp_TpId] = TRUE;

        COPY_DYNFLD(extOpTab[i], ExtOp, ExtOp_SubTpId,
                    slaveEltTab[i], A_CompoundOrderSlaveElt, A_CompoundOrderSlaveElt_OpSubTypeId);
        allFlagTab[i][ExtOp_SubTpId] = TRUE;

        COPY_DYNFLD(extOpTab[i], ExtOp, ExtOp_OrderTypeId,
                    slaveEltTab[i], A_CompoundOrderSlaveElt, A_CompoundOrderSlaveElt_OpOrderTypeId);
        allFlagTab[i][ExtOp_OrderTypeId] = TRUE;

        /* set not MD attributes */
        COPY_DYNFLD(extOpTab[i], ExtOp, ExtOp_CompoundScreenDictId,
            slaveEltTab[i], A_CompoundOrderSlaveElt, A_CompoundOrderSlaveElt_ScreenDictId);

        COPY_DYNFLD(extOpTab[i], ExtOp, ExtOp_CompoundSlaveCode,
            slaveEltTab[i], A_CompoundOrderSlaveElt, A_CompoundOrderSlaveElt_Cd);


    }

    /* create a hierachy and build links */
    if ((hierHead = DBA_CreateHier()) == NULL)
    {
        FREE_DYNST(aMasterEltStp, A_CompoundOrderMasterElt);
        DBA_FreeDynStTab(slaveEltTab, slaveEltNbr, A_CompoundOrderSlaveElt);
        DBA_FreeDynStTab(extOpTab, slaveEltNbr, ExtOp);
        for (i=0; i < slaveEltNbr; i++)
            FREE(allFlagTab[i]);
        FREE(allFlagTab);
        MSG_SendMesg(RET_DBA_ERR_HIER, 0, FILEINFO);
        return(RET_DBA_ERR_HIER);
    };

    /* Add master in arrays */
    extOpTab[slaveEltNbr] = mastertOpStp;
    allFlagTab[slaveEltNbr] = masterExtOpFlagTab;

    /*DBA_AddHierRecord(hierHead, ExtOp, mastertOpStp, ExtOp, FALSE, HierAddRec_NoLnk);*/
    DBA_AddHierRecordList(hierHead, extOpTab, slaveEltNbr+1, ExtOp, FALSE);
    DBA_SetDoNotDeleteRecFlag(hierHead, ExtOp, TRUE);  /* PMSTA-41612 - DDV - 200903 - Memory leaks */
    DBA_SetHierLnkUsed(hierHead, ExtOp, ExtOp_CompoundOrderMasterElt_Ext);
    DBA_SetHierLnkUsed(hierHead, ExtOp, ExtOp_CompoundOrderSlaveElt_Ext);
    DBA_MakeAllRecLinks(hierHead, ExtOp);

    SCPT_ComputeCompoundScreenDV(EOp,
        NullDictFct,
        allFlagTab,
        extOpTab,
        NULLDYNSTPTR,
        slaveEltNbr + 1,
        NULLDYNST,
        TRUE, /* Full mode */
        TRUE,
        EvalType_DefVal,
        (int *) NULL,
        NULL,
        hierHead);
#if 0
    for (i = 0; i < slaveEltNbr; i++)
    {
        /* Call DV in full mode */
		SCPT_ComputeScreenDV(EOp,
                          NullDictFct,
                          allFlagTab[i],
                          NULL,         /* HFI-PMSTA-25327-171023  Dedicated flag tab for filter    */
                          extOpTab[i],
                          NULL,
                          NULLDYNST,
                          NULLDYNST,   /* PMSTA13283 - DDV - 120117 */
                          TRUE,				/* analyse type */
                          TRUE,				/* guiFlag */
                          EvalType_DefVal,   /* FPL-REF9507-030929  Only Def val    */
                          0,					/* attribIdx */
                          NULL,              /* connectNo */
                          NULL,				/* filterTab */
                          NULL,	            /* hierHead */
                          0,
                          DictScreen,        /*  FIH-REF9789-040209  */
                          NULL,
                          NULL,
                          NULL,
                          NULL,
                          NULL,
                          NullEntity,
                          FALSE,
                          FALSE,
                          GET_DICT(slaveEltTab[i], A_CompoundOrderSlaveElt_ScreenDictId));        /*  FPL-REF9215-030811  Flag Impact */

	}
#endif
    extOpTab[slaveEltNbr] = NULLDYNST;

    FREE_DYNST(aMasterEltStp, A_CompoundOrderMasterElt);

    DBA_FreeDynStTab(slaveEltTab, slaveEltNbr, A_CompoundOrderSlaveElt);
    for (i = 0; i< slaveEltNbr; i++)
        FREE(allFlagTab[i]);
    FREE(allFlagTab);

    DBA_FreeHier(hierHead); /* PMSTA-41612 - DDV - 200903 - Memory leaks */

    *extOpResultTab = extOpTab;
    *extOpResultNbr = slaveEltNbr;

	return retCode;

}

/************************************************************************
**
**  Function        :   DBA_ExtOpByCompMasIdCompOrdCodeCompSlvEltIdCmp()
**
**  Description     :   Sort the ExtOp
**
**
**  Arguments       :   ptr1    first element pointer
**                      prt2    second element pointer
**
**  Return          :   TLS_Sort() comparison function return
**
**
**  Creation date   :   13/102014 - SHR
**
*************************************************************************/
STATIC int DBA_ExtOpByCompMasIdCompOrdCodeCompSlvEltIdCmp(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{

    /* ExtOp_CompoundOrderMasterEltId		ascending,  */
    /* ExtOp_CompoundOrderCode		ascending.  */
    /* ExtOp_CompoundOrderSlaveEltId  ascending sort NULL value first  */
    int diff = CMP_DYNFLD(*ptr1, *ptr2, ExtOp_CompoundOrderMasterEltId, ExtOp_CompoundOrderMasterEltId, IdType);
	if (diff == 0)
		diff = CMP_DYNFLD(*ptr1, *ptr2, ExtOp_CompoundOrderCode, ExtOp_CompoundOrderCode, CodeType);
    if (diff == 0)
        diff = CMP_DYNFLD_SYB(*ptr1, *ptr2, ExtOp_CompoundOrderSlaveEltId, ExtOp_CompoundOrderSlaveEltId, IdType);
	if (diff == 0)
		diff = CMP_DYNFLD_SYB(*ptr1, *ptr2, ExtOp_CompoundOrderSlaveNbr, ExtOp_CompoundOrderSlaveNbr, TinyintType);

    return(diff);
}

/************************************************************************
**
**  Function        :   DBA_SlaveEltTabByCompoundSlaveEltIdCmp()
**
**  Description     :   Sort the SlaveEltTab
**
**
**  Arguments       :   ptr1    first element pointer
**                      prt2    second element pointer
**
**  Return          :   TLS_Sort() comparison function return
**
**
**  Creation date   :   13/102014 - SHR
**
*************************************************************************/
STATIC int DBA_SlaveEltTabByCompoundSlaveEltIdCmp(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{

    int diff = CMP_DYNFLD(*ptr1, *ptr2, A_CompoundOrderSlaveElt_Id, A_CompoundOrderSlaveElt_Id, IdType);
    return(diff);
}

/************************************************************************
*
*   Function             : FIN_isValidCompoundOrder
*
*   Description          :
*
*   Arguments            : srvProc      Pointer to the Sybase array
*                          entityArg    Pointer to the dynamic structure
*
*   Creation Date        : 13/102014 - SHR
*
*************************************************************************/
RET_CODE FIN_CheckValidCompoundOrder	   (DBA_DYNFLD_STP *extOpTab,
										   int            extOpNbr)
{
	RET_CODE        retCode = RET_SUCCEED;
	DBA_DYNFLD_STP  *dbslaveEltTab=(DBA_DYNFLD_STP*)NULL;
	int				i = 0;
	ID_T			currMasterEltId = 0;
	int             dbslaveEltNbr = 0;
	DBA_DYNFLD_STP  sSlaveEltStp=NULL, aMasterEltStp=NULL, sMasterEltStp=NULL;
	char			buffer[256];
	FLAG_T			multiLegFlg = FALSE;


	/* Sorting the collection based on MasterRuleId, CompoundOrderCode, CompoundSlaveEltId */
	if(extOpNbr > 1)
	    TLS_Sort((char *) extOpTab, extOpNbr, sizeof(DBA_DYNFLD_STP), (TLS_CMPFCT *)DBA_ExtOpByCompMasIdCompOrdCodeCompSlvEltIdCmp, (PTR **) NULL, SortRtnTp_None);


    if ((aMasterEltStp = ALLOC_DYNST(A_CompoundOrderMasterElt)) == NULLDYNST)
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

	if ((sMasterEltStp = ALLOC_DYNST(S_CompoundOrderMasterElt)) == NULLDYNST)
    {
        FREE_DYNST(aMasterEltStp, A_CompoundOrderMasterElt);
		MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

	if ((sSlaveEltStp = ALLOC_DYNST(S_CompoundOrderSlaveElt)) == NULLDYNST)
    {
        FREE_DYNST(aMasterEltStp, A_CompoundOrderMasterElt);
		FREE_DYNST(sMasterEltStp, S_CompoundOrderMasterElt);
		MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

	 /* loop for sorted extOpTab */
    for (i=0;  i < extOpNbr; i++)
    {

	    /* if first element is a slave not a master, return an error */
		if (IS_NULLFLD(extOpTab[i], ExtOp_CompoundOrderSlaveEltId) == FALSE)
        {

		    FREE_DYNST(aMasterEltStp, A_CompoundOrderMasterElt);
			FREE_DYNST(sMasterEltStp, S_CompoundOrderMasterElt);
            FREE_DYNST(sSlaveEltStp, S_CompoundOrderSlaveElt);
            if (dbslaveEltNbr > 0)
			DBA_FreeDynStTab(dbslaveEltTab, dbslaveEltNbr, A_CompoundOrderSlaveElt);
            sprintf(buffer, "No operation exist for this Master Element");
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, buffer);
            return(RET_DBA_ERR_INVDATA);
		}
		else
        {
			/* Loading the master element definition */
			SET_ID(sMasterEltStp, S_CompoundOrderMasterElt_Id, GET_ID(extOpTab[i], ExtOp_CompoundOrderMasterEltId));
			if ((retCode = DBA_Get2(CompoundOrderMasterElt,
                                    UNUSED,
                                    S_CompoundOrderMasterElt,
                                    sMasterEltStp,
                                    A_CompoundOrderMasterElt,
                                    &aMasterEltStp,
                                    UNUSED,
                                    UNUSED,
                                    UNUSED)) != RET_SUCCEED)

			{
			    FREE_DYNST(aMasterEltStp, A_CompoundOrderMasterElt);
				FREE_DYNST(sMasterEltStp, S_CompoundOrderMasterElt);
                FREE_DYNST(sSlaveEltStp, S_CompoundOrderSlaveElt);
                if (dbslaveEltNbr > 0)
				DBA_FreeDynStTab(dbslaveEltTab, dbslaveEltNbr, A_CompoundOrderSlaveElt);
                MSG_SendMesg(RET_DBA_ERR_NODATA, 1 , FILEINFO, "compound_order_master_elt", GET_ID(extOpTab[i], ExtOp_CompoundOrderMasterEltId));
                return(RET_DBA_ERR_NODATA);
            }

			/* Check for valid master */
			if((GET_ENUM(aMasterEltStp,A_CompoundOrderMasterElt_OpNature) != GET_ENUM(extOpTab[i],ExtOp_NatureEn) ) ||
               (GET_ID(aMasterEltStp,A_CompoundOrderMasterElt_OpTypeId) != GET_ID(extOpTab[i],ExtOp_TpId) ) ||
               (GET_ID(aMasterEltStp,A_CompoundOrderMasterElt_OpSubTypeId) != GET_ID(extOpTab[i],ExtOp_SubTpId) ) ||
               (GET_ID(aMasterEltStp,A_CompoundOrderMasterElt_OpOrderTypeId) != GET_ID(extOpTab[i],ExtOp_OrderTypeId) ))
            {
                FREE_DYNST(aMasterEltStp, A_CompoundOrderMasterElt);
				FREE_DYNST(sMasterEltStp, S_CompoundOrderMasterElt);
                FREE_DYNST(sSlaveEltStp, S_CompoundOrderSlaveElt);
                if (dbslaveEltNbr > 0)
				DBA_FreeDynStTab(dbslaveEltTab, dbslaveEltNbr, A_CompoundOrderSlaveElt);
				sprintf(buffer, "Master is not valid in this Compound order");
                MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, buffer);
                return(RET_DBA_ERR_INVDATA);
            }

            /* Set compound screen dict_id to avoid additional database access when DV, filter or IC are called */
            COPY_DYNFLD(extOpTab[i], ExtOp, ExtOp_CompoundScreenDictId,
                        aMasterEltStp, A_CompoundOrderMasterElt, A_CompoundOrderMasterElt_ScreenDictId);
            SET_NULL_CODE(extOpTab[i], ExtOp_CompoundSlaveCode);

			if (currMasterEltId != GET_ID(extOpTab[i], ExtOp_CompoundOrderMasterEltId))
            {
                if (currMasterEltId != 0)
                {
                    DBA_FreeDynStTab(dbslaveEltTab, dbslaveEltNbr, A_CompoundOrderSlaveElt);
                }

				/* loading slave based on ExtOp_CompoundOrderMasterEltId */
                currMasterEltId = GET_ID(extOpTab[i], ExtOp_CompoundOrderMasterEltId);
                SET_ID(sSlaveEltStp, S_CompoundOrderSlaveElt_CompoundOrderMasterElt, currMasterEltId);

                retCode = DBA_Select2(CompoundOrderSlaveElt, UNUSED,
                                     S_CompoundOrderSlaveElt, sSlaveEltStp,
                                     A_CompoundOrderSlaveElt, &dbslaveEltTab,
                                     UNUSED, UNUSED,
                                     &dbslaveEltNbr, UNUSED, UNUSED);
                if (dbslaveEltNbr == 0)
                {
					 FREE_DYNST(aMasterEltStp, A_CompoundOrderMasterElt);
                     FREE_DYNST(sMasterEltStp, S_CompoundOrderMasterElt);
                     FREE_DYNST(sSlaveEltStp, S_CompoundOrderSlaveElt);
                     sprintf(buffer, "Slave is not valid in this Compound order");
                     MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, buffer);
                     return(RET_DBA_ERR_NODATA);
                }

				/* sort slave elt by id */
				if(dbslaveEltNbr > 1)
				    TLS_Sort((char *) dbslaveEltTab, dbslaveEltNbr, sizeof(DBA_DYNFLD_STP), (TLS_CMPFCT *)DBA_SlaveEltTabByCompoundSlaveEltIdCmp, (PTR **) NULL, SortRtnTp_None);
			}

            for (int j = 0; j < dbslaveEltNbr; j++)
            {
                i++;
                if (i == extOpNbr)
                {
			        FREE_DYNST(aMasterEltStp, A_CompoundOrderMasterElt);
                    FREE_DYNST(sMasterEltStp, S_CompoundOrderMasterElt);
                    FREE_DYNST(sSlaveEltStp, S_CompoundOrderSlaveElt);
					DBA_FreeDynStTab(dbslaveEltTab, dbslaveEltNbr, A_CompoundOrderSlaveElt);

					/*PMSTA-30129 -NRAO - 180206*/
					if (i > 1)
					{
						/*There is atleast one slave element. Return successful */
						return retCode;
					}
					else
					{
						sprintf(buffer, "Slave element is missing");
						MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, buffer);
						return(RET_DBA_ERR_INVDATA);
					}
                }

				do
                {
				    multiLegFlg = FALSE;
                    if (CMP_DYNFLD(dbslaveEltTab[j], extOpTab[i], A_CompoundOrderSlaveElt_Id, ExtOp_CompoundOrderSlaveEltId, IdType) != 0)
                    {

                        if (i > 0 && CMP_DYNFLD(extOpTab[i - 1], extOpTab[i], ExtOp_CompoundOrderSlaveEltId, ExtOp_CompoundOrderSlaveEltId, IdType) == 0 &&
                            j > 0 && GET_ENUM(dbslaveEltTab[j - 1], A_CompoundOrderSlaveElt_LegNature) == LegNat_Single)
                        {
                            sprintf(buffer, "Single leg Slave cannot have multiple operation");
                            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, buffer);
                        }
                        else
                        {
							/*PMSTA-30129 -NRAO - 180206*/
							if (j+1 < dbslaveEltNbr)
							{
								/*There may be another slave matching the order. Decrement & iterate again*/
								i--;
								continue;
							}
                            sprintf(buffer, "Slave element is missing");
                            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, buffer);
                        }

                        FREE_DYNST(aMasterEltStp, A_CompoundOrderMasterElt);
                        FREE_DYNST(sMasterEltStp, S_CompoundOrderMasterElt);
                        FREE_DYNST(sSlaveEltStp, S_CompoundOrderSlaveElt);
                        DBA_FreeDynStTab(dbslaveEltTab, dbslaveEltNbr, A_CompoundOrderSlaveElt);
                        return(RET_DBA_ERR_INVDATA);
                    }

                    if (i>0 && CMP_DYNFLD(extOpTab[i - 1], extOpTab[i], ExtOp_CompoundOrderCode, ExtOp_CompoundOrderCode, CodeType) != 0)
                    {
                        sprintf(buffer, "Slave element is missing");
                        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, buffer);
                        FREE_DYNST(aMasterEltStp, A_CompoundOrderMasterElt);
                        FREE_DYNST(sMasterEltStp, S_CompoundOrderMasterElt);
                        FREE_DYNST(sSlaveEltStp, S_CompoundOrderSlaveElt);
                        DBA_FreeDynStTab(dbslaveEltTab, dbslaveEltNbr, A_CompoundOrderSlaveElt);
                        return(RET_DBA_ERR_INVDATA);
                    }

                    if((GET_ENUM(dbslaveEltTab[j],A_CompoundOrderSlaveElt_OpNature) != GET_ENUM(extOpTab[i],ExtOp_NatureEn) ) ||
                       (GET_ID(dbslaveEltTab[j],A_CompoundOrderSlaveElt_OpTypeId) != GET_ID(extOpTab[i],ExtOp_TpId) ) ||
                       (GET_ID(dbslaveEltTab[j],A_CompoundOrderSlaveElt_OpSubTypeId) != GET_ID(extOpTab[i],ExtOp_SubTpId) ) ||
                       (GET_ID(dbslaveEltTab[j],A_CompoundOrderSlaveElt_OpOrderTypeId) != GET_ID(extOpTab[i],ExtOp_OrderTypeId)))
                    {
					    FREE_DYNST(aMasterEltStp, A_CompoundOrderMasterElt);
                        FREE_DYNST(sMasterEltStp, S_CompoundOrderMasterElt);
                        FREE_DYNST(sSlaveEltStp, S_CompoundOrderSlaveElt);
                        DBA_FreeDynStTab(dbslaveEltTab, dbslaveEltNbr, A_CompoundOrderSlaveElt);
                        sprintf(buffer, "Slave is not valid in this Compound order");
                        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, buffer);
                        return(RET_DBA_ERR_INVDATA);
                    }

                    /* Set compound screen dict_id to avoid additional database access when DV, filter or IC are called */
                    COPY_DYNFLD(extOpTab[i], ExtOp, ExtOp_CompoundScreenDictId,
                                dbslaveEltTab[j], A_CompoundOrderSlaveElt, A_CompoundOrderSlaveElt_ScreenDictId);
                    COPY_DYNFLD(extOpTab[i], ExtOp, ExtOp_CompoundSlaveCode,
                                dbslaveEltTab[j], A_CompoundOrderSlaveElt, A_CompoundOrderSlaveElt_Cd);

                    if (GET_ENUM(dbslaveEltTab[j], A_CompoundOrderSlaveElt_LegNature) == LegNat_Multiple &&
						i+1 < extOpNbr &&
						CMP_DYNFLD(extOpTab[i], extOpTab[i+1], ExtOp_CompoundOrderCode, ExtOp_CompoundOrderCode, CodeType) == 0 &&
						CMP_DYNFLD(dbslaveEltTab[j], extOpTab[i+1], A_CompoundOrderSlaveElt_Id, ExtOp_CompoundOrderSlaveEltId, IdType) == 0)
						{
							multiLegFlg = TRUE;
							i++;
							if (CMP_DYNFLD(extOpTab[i-1], extOpTab[i], ExtOp_CompoundOrderSlaveNbr, ExtOp_CompoundOrderSlaveNbr, TinyintType) == 0)
							{
                                DBA_FreeDynStTab(dbslaveEltTab, dbslaveEltNbr, A_CompoundOrderSlaveElt);
							    FREE_DYNST(aMasterEltStp, A_CompoundOrderMasterElt);
                                FREE_DYNST(sMasterEltStp, S_CompoundOrderMasterElt);
                                FREE_DYNST(sSlaveEltStp, S_CompoundOrderSlaveElt);
                                sprintf(buffer, "Slave number is not valid in this Compound order");
                                MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, buffer);
                                return(RET_DBA_ERR_INVDATA);
							}
						}
                } while (multiLegFlg == TRUE);
            }
	    }
    }

    if(dbslaveEltNbr > 0)
	    DBA_FreeDynStTab(dbslaveEltTab, dbslaveEltNbr, A_CompoundOrderSlaveElt);
	FREE_DYNST(sMasterEltStp, S_CompoundOrderMasterElt);
	FREE_DYNST(aMasterEltStp, A_CompoundOrderMasterElt);
    FREE_DYNST(sSlaveEltStp, S_CompoundOrderSlaveElt);

	return retCode;
}

/************************************************************************
*
*   Function             : FIN_LoadCompoundOrder
*
*   Description          :
*
*   Arguments            : extOpStp     ext operation with information about compound order to load
*                          extOpTab     array of operations returned
*                          extOpNbr     number of operations returned
*
*   Creation Date        : PMSTA-18601 - DDV - 141104
*
*************************************************************************/
RET_CODE FIN_LoadCompoundOrder(DBA_DYNFLD_STP    extOpStp,
                               DBA_DYNFLD_STP    **extOpTab,
                               int               *extOpNbr,
                               FLAG_T            checkValidityFlg)
{
    RET_CODE          retCode = RET_SUCCEED;
    int				  i = 0, j=0;
    DBA_HIER_HEAD_STP localHierHead;


    (*extOpTab) = NULLDYNSTPTR;
    (*extOpNbr) = 0;

    if (IS_NULLFLD(extOpStp, ExtOp_CompoundOrderCode) == TRUE)
    {
        return(RET_DBA_INFO_NODATA);
    }

    if ((localHierHead = DBA_CreateHier()) == NULL)
    {
        return(RET_DBA_ERR_HIER);
    }

    if (GET_FLAG(extOpStp, ExtOp_InSessionFlg) == FALSE)
    {

        int                  outputBlkNb = 6, extOpBlock = 0, opBlock = 1, posBlock = 2, balPosBlock = 3;
        DBA_DYNFLD_STP       *data[6] = { NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR, NULLDYNSTPTR };
        int                  rows[6] = { 0, 0, 0, 0, 0, 0};
        const DBA_DYNST_ENUM *outputStLst[] = { &ExtOp,
                                                &A_Op,
                                                &ExtPos,
                                                &ExtPos,
                                                &A_Ptf,
                                                &A_Instr };

        if ((retCode = DBA_MultiSelect2(EOp, UNUSED, ExtOp, extOpStp,
                                        outputStLst, data, UNUSED,
                                        UNUSED, rows, NULL, UNUSED)) != RET_SUCCEED)
        {
            MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_MultiSelect failed");
            return(retCode);
        }

        if (rows[opBlock] > 0)
        {
            /* Create all necessary links */
            /*** Instrument ***/
            if (DBA_SetHierLnkUsed(localHierHead, ExtPos, ExtPos_A_Instr_Ext) != RET_SUCCEED)
            {
                MSG_SendMesg(RET_DBA_ERR_HIER, 4, FILEINFO, "FIN_LoadCompoundOrder", ExtPos_A_Instr_Ext, ExtPos);
                DBA_MultiFree(data, outputStLst, rows, outputBlkNb);
                return(RET_DBA_ERR_HIER);
            }

            /*** Open operation ***/
            if (DBA_SetHierLnkUsed(localHierHead, ExtPos, ExtPos_Open_A_Op_Ext) != RET_SUCCEED)
            {
                MSG_SendMesg(RET_DBA_ERR_HIER, 4, FILEINFO, "FIN_LoadCompoundOrder", ExtPos_Open_A_Op_Ext, ExtPos);
                DBA_MultiFree(data, outputStLst, rows, outputBlkNb);
                return(RET_DBA_ERR_HIER);
            }

            /*** Main position ***/
            if (DBA_SetHierLnkUsed(localHierHead, ExtPos, ExtPos_Main_ExtPos_Ext) != RET_SUCCEED)
            {
                MSG_SendMesg(RET_DBA_ERR_HIER, 4, FILEINFO, "FIN_LoadCompoundOrder", ExtPos_Main_ExtPos_Ext, ExtPos);
                DBA_MultiFree(data, outputStLst, rows, outputBlkNb);
                return(RET_DBA_ERR_HIER);
            }

            /*** Locking position ***/                      /* DVP545 - 970724 - DED */
            if (DBA_SetHierLnkUsed(localHierHead, ExtPos, ExtPos_Locking_ExtPos_Ext) != RET_SUCCEED)
            {
                MSG_SendMesg(RET_DBA_ERR_HIER, 4, FILEINFO, "FIN_LoadCompoundOrder", ExtPos_Locking_ExtPos_Ext, ExtPos);
                DBA_MultiFree(data, outputStLst, rows, outputBlkNb);
                return(RET_DBA_ERR_HIER);
            }

            /*** Instrument position ***/
            if (DBA_SetHierLnkUsed(localHierHead, ExtPos, ExtPos_Instr_ExtPos_Ext) != RET_SUCCEED)
            {
                MSG_SendMesg(RET_DBA_ERR_HIER, 4, FILEINFO, "FIN_LoadCompoundOrder", ExtPos_Instr_ExtPos_Ext, ExtPos);
                DBA_MultiFree(data, outputStLst, rows, outputBlkNb);
                return(RET_DBA_ERR_HIER);
            }

            /*** Main Account position ***/
            if (DBA_SetHierLnkUsed(localHierHead, ExtPos, ExtPos_Acct_ExtPos_Ext) != RET_SUCCEED)
            {
                MSG_SendMesg(RET_DBA_ERR_HIER, 4, FILEINFO, "FIN_LoadCompoundOrder", ExtPos_Acct_ExtPos_Ext, ExtPos);
                DBA_MultiFree(data, outputStLst, rows, outputBlkNb);
                return(RET_DBA_ERR_HIER);
            }

            /*** Account 2 position ***/
            if (DBA_SetHierLnkUsed(localHierHead, ExtPos, ExtPos_Acct2_ExtPos_Ext) != RET_SUCCEED)
            {
                MSG_SendMesg(RET_DBA_ERR_HIER, 4, FILEINFO, "FIN_LoadCompoundOrder", ExtPos_Acct2_ExtPos_Ext,
                    ExtPos);
                DBA_FreeHier(localHierHead);
                DBA_MultiFree(data, outputStLst, rows, outputBlkNb);
                return(RET_DBA_ERR_HIER);
            }

            /*** Account 3 position ***/
            if (DBA_SetHierLnkUsed(localHierHead, ExtPos, ExtPos_Acct3_ExtPos_Ext) != RET_SUCCEED)
            {
                MSG_SendMesg(RET_DBA_ERR_HIER, 4, FILEINFO, "FIN_LoadCompoundOrder", ExtPos_Acct3_ExtPos_Ext,
                    ExtPos);
                DBA_FreeHier(localHierHead);
                DBA_MultiFree(data, outputStLst, rows, outputBlkNb);
                return(RET_DBA_ERR_HIER);
            }

            /*** Adjustment position ***/
            if (DBA_SetHierLnkUsed(localHierHead, ExtPos, ExtPos_Adjust_ExtPos_Ext) != RET_SUCCEED)
            {
                MSG_SendMesg(RET_DBA_ERR_HIER, 4, FILEINFO, "FIN_LoadCompoundOrder", ExtPos_Adjust_ExtPos_Ext,
                    ExtPos);
                DBA_FreeHier(localHierHead);
                DBA_MultiFree(data, outputStLst, rows, outputBlkNb);
                return(RET_DBA_ERR_HIER);
            }

            /*** Accrued interest balance position ***/
            if (DBA_SetHierLnkUsed(localHierHead, ExtPos, ExtPos_AccrInter_ExtPos_Ext) != RET_SUCCEED)
            {
                MSG_SendMesg(RET_DBA_ERR_HIER, 4, FILEINFO, "FIN_LoadCompoundOrder", ExtPos_AccrInter_ExtPos_Ext,
                    ExtPos);
                DBA_FreeHier(localHierHead);
                DBA_MultiFree(data, outputStLst, rows, outputBlkNb);
                return(RET_DBA_ERR_HIER);
            }

            /*** Counterparty position ***/
            if (DBA_SetHierLnkUsed(localHierHead, ExtPos, ExtPos_CntPty_ExtPos_Ext) != RET_SUCCEED)
            {
                MSG_SendMesg(RET_DBA_ERR_HIER, 4, FILEINFO, "FIN_LoadCompoundOrder", ExtPos_CntPty_ExtPos_Ext,
                    ExtPos);
                DBA_FreeHier(localHierHead);
                DBA_MultiFree(data, outputStLst, rows, outputBlkNb);
                return(RET_DBA_ERR_HIER);
            }

            /*** Balance positions ***/
            if (DBA_SetHierLnkUsed(localHierHead, ExtPos, ExtPos_BalPos_ExtPos_Ext) != RET_SUCCEED)
            {
                MSG_SendMesg(RET_DBA_ERR_HIER, 4, FILEINFO, "FIN_LoadCompoundOrder", ExtPos_BalPos_ExtPos_Ext,
                    ExtPos);
                DBA_FreeHier(localHierHead);
                DBA_MultiFree(data, outputStLst, rows, outputBlkNb);
                return(RET_DBA_ERR_HIER);
            }

            /*** Book Value Adj. Profit balance position */
            if (DBA_SetHierLnkUsed(localHierHead, ExtPos, ExtPos_BVAdjProfit_ExtPos_Ext) != RET_SUCCEED)
            {
                MSG_SendMesg(RET_DBA_ERR_HIER, 4, FILEINFO, "FIN_LoadCompoundOrder", ExtPos_BVAdjProfit_ExtPos_Ext,
                    ExtPos);
                DBA_FreeHier(localHierHead);
                DBA_MultiFree(data, outputStLst, rows, outputBlkNb);
                return(RET_DBA_ERR_HIER);
            }

            /*** Book Value Adj. Loss balance position */
            if (DBA_SetHierLnkUsed(localHierHead, ExtPos, ExtPos_BVAdjLoss_ExtPos_Ext) != RET_SUCCEED)
            {
                MSG_SendMesg(RET_DBA_ERR_HIER, 4, FILEINFO, "FIN_LoadCompoundOrder", ExtPos_BVAdjLoss_ExtPos_Ext,
                    ExtPos);
                DBA_FreeHier(localHierHead);
                DBA_MultiFree(data, outputStLst, rows, outputBlkNb);
                return(RET_DBA_ERR_HIER);
            }

            /* Portfolio transfer instrument position */
            if (DBA_SetHierLnkUsed(localHierHead, ExtPos, ExtPos_ToInstr_ExtPos_Ext) != RET_SUCCEED)
            {
                MSG_SendMesg(RET_DBA_ERR_HIER, 4, FILEINFO, "FIN_LoadCompoundOrder", ExtPos_ToInstr_ExtPos_Ext,
                    ExtPos);
                DBA_FreeHier(localHierHead);
                DBA_MultiFree(data, outputStLst, rows, outputBlkNb);
                return(RET_DBA_ERR_HIER);
            }

            /* Portfolio transfer balance position */
            if (DBA_SetHierLnkUsed(localHierHead, ExtPos, ExtPos_ToBalPos_ExtPos_Ext) != RET_SUCCEED)
            {
                MSG_SendMesg(RET_DBA_ERR_HIER, 4, FILEINFO, "FIN_LoadCompoundOrder", ExtPos_ToBalPos_ExtPos_Ext,
                    ExtPos);
                DBA_FreeHier(localHierHead);
                DBA_MultiFree(data, outputStLst, rows, outputBlkNb);
                return(RET_DBA_ERR_HIER);
            }


            /* PMSTA-19878 - DDV - 150202 */
            for (i = 0; i < rows[posBlock]; i++)
            {
                SET_ENUM(data[posBlock][i], ExtPos_NatEn, ExtPosNat_Flow);
                SET_DATETIME(data[posBlock][i], ExtPos_ExtPosDate, GET_DATETIME(data[posBlock][i], ExtPos_BegDate));
            }

            /* PMSTA-19878 - DDV - 150202 */
            for (i = 0; i < rows[balPosBlock]; i++)
            {
                SET_ENUM(data[balPosBlock][i], ExtPos_NatEn, ExtPosNat_Flow);
                SET_DATETIME(data[balPosBlock][i], ExtPos_ExtPosDate, GET_DATETIME(data[balPosBlock][i], ExtPos_BegDate));
            }

            /* Distribute data into hierarchy */
            for (i = 0; i < outputBlkNb; i++)
            {
                if (i != extOpBlock)
                {
                    if (DBA_AddHierRecordList(localHierHead,
                        data[i],
                        rows[i],
                        *(outputStLst[i]),
                        TRUE) != RET_SUCCEED)

                    {
                        MSG_SendMesg(RET_DBA_ERR_HIER, 0, FILEINFO);
                        DBA_FreeHier(localHierHead);
                        for (j = 0; j < outputBlkNb; j++)
                        {
                            if (j == extOpBlock || j >= i)
                                DBA_FreeDynStTab(data[j], rows[j], *(outputStLst[j]));
                            else
                                FREE(data[j]);
                        }
                        return(RET_DBA_ERR_HIER);
                    }
                }
            }

            /* PMSTA-19878 - DDV - 150202 */
            DBA_MakeSpecRecLinks(localHierHead, ExtPos, ExtPos_A_Instr_Ext);
            DBA_MakeSpecRecLinks(localHierHead, ExtPos, ExtPos_A_Ptf_Ext);

            /* Create all hierarchy links */
            if (DBA_MakeLinks(localHierHead) != RET_SUCCEED)
            {
                MSG_SendMesg(RET_DBA_ERR_HIER, 0, FILEINFO);
                DBA_FreeHier(localHierHead);
                DBA_FreeDynStTab(data[extOpBlock], rows[extOpBlock], *(outputStLst[extOpBlock]));
                return(RET_DBA_ERR_HIER);
            }

            /* Build ExtOp */
            if ((retCode = OPE_CreateExtOpfromExtPos(localHierHead, extOpTab, extOpNbr, NULL, NULL)) != RET_SUCCEED)
            {
                MSG_SendMesg(RET_DBA_ERR_HIER, 0, FILEINFO);
                DBA_FreeHier(localHierHead);
                DBA_FreeDynStTab(data[extOpBlock], rows[extOpBlock], *(outputStLst[extOpBlock]));
                return(RET_DBA_ERR_INVDATA);
            }
        }
        else
        {
	        for (i = 0; i < outputBlkNb; i++)
            {
                if (i != extOpBlock)
                {
                    DBA_FreeDynStTab(data[i], rows[i], *(outputStLst[i]));
                }
            }
        }

        if (rows[extOpBlock] > 0)
        {
            DBA_DYNFLD_STP    *newTab = NULLDYNSTPTR;

            if ((newTab = (DBA_DYNFLD_STP *)REALLOC((*extOpTab), ((*extOpNbr) + rows[extOpBlock]) * sizeof (DBA_DYNFLD_STP))) == NULL)
            {
                if (rows[opBlock] > 0)
                {
                    DBA_FreeDynStTab(data[extOpBlock], rows[extOpBlock], *(outputStLst[extOpBlock]));
                    DBA_FreeDynStTab((*extOpTab), (*extOpNbr), ExtOp);
                    (*extOpTab) = NULLDYNSTPTR;
                    (*extOpNbr) = 0;
                }
                else
                {
                    DBA_MultiFree(data, outputStLst, rows, outputBlkNb);
                }
                MSG_RETURN(RET_MEM_ERR_ALLOC);
            }

            (*extOpTab) = newTab;

            for (i = 0; i < rows[extOpBlock]; i++)
            {
                (*extOpTab)[(*extOpNbr) + i] = data[extOpBlock][i];
            }
            (*extOpNbr) += rows[extOpBlock];
        }
        else
        {
	        FREE(data[extOpBlock]);
        }
    }
    else
    {
        /* Load ext_operations */
        retCode = DBA_Select2(EOp, DBA_ROLE_ORDER_SESSION, ExtOp, extOpStp,
                              ExtOp, extOpTab, UNUSED, UNUSED,
                              extOpNbr, UNUSED, UNUSED);

        for (i = 0; i < *extOpNbr; i++)
        {
            SET_FLAG((*extOpTab)[i], ExtOp_InSessionFlg, TRUE);
        }
    }

    /* check compound Order validity */
    if (checkValidityFlg == TRUE)
    {
        /* check compound order validity */
        if (FIN_CheckValidCompoundOrder((*extOpTab), (*extOpNbr)) != RET_SUCCEED)
        {
            DBA_FreeDynStTab((*extOpTab), (*extOpNbr), ExtOp);
            (*extOpTab) = NULLDYNSTPTR;
            (*extOpNbr) = 0;
            return(RET_DBA_ERR_INVDATA);
        }
    }
    DBA_FreeHier(localHierHead);

    if ((*extOpNbr) == 0)
        return(RET_DBA_ERR_NODATA);

    return(retCode);
}

/************************************************************************
*
*   Function             : FIN_LoadAndDeleteCompoundOrder
*
*   Description          :
*
*   Arguments            : extOpStp     ext operation with information about compound order to load
*                          extOpTab     array of operations returned
*                          extOpNbr     number of operations returned
*
*   Creation Date        : PMSTA-18601 - DDV - 141208
*
*************************************************************************/
RET_CODE FIN_LoadAndDeleteCompoundOrder(DBA_DYNFLD_STP    extOpStp, int connectNo)
{
    DBA_DYNFLD_STP    *extOpTab = NULLDYNSTPTR;
    int                extOpNbr = 0;

    if (IS_NULLFLD(extOpStp, ExtOp_CompoundOrderCode) == TRUE)
    {
        return(RET_DBA_ERR_INVDATA);
    }

    if ((FIN_LoadCompoundOrder(extOpStp, &extOpTab, &extOpNbr, FALSE)) != RET_SUCCEED)
    {
        if (GET_FLAG(extOpStp, ExtOp_InSessionFlg) == FALSE)
        {
            MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "operation");
        }
        else
        {
            MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "ext_operation");
        }
        return(RET_DBA_ERR_NODATA);
    }

    return(FIN_DeleteCompoundOrder(extOpTab, extOpNbr, connectNo));
}

/************************************************************************
*
*   Function             : FIN_DeleteCompoundOrder
*
*   Description          :
*
*   Arguments            : extOpStp     ext operation with information about compound order to load
*                          extOpTab     array of operations returned
*                          extOpNbr     number of operations returned
*
*   Creation Date        : PMSTA-18601 - DDV - 141208
*
*************************************************************************/
RET_CODE FIN_DeleteCompoundOrder(DBA_DYNFLD_STP    *extOpTab,
                                 int                extOpNbr,
                                 int                connectNoParam)
{
    int				   i = 0, connectNo = NO_VALUE;
    DBA_DYNFLD_STP     sOpSt = NULLDYNSTPTR;
    FLAG_T             localConnFlg;

    if (connectNoParam >= 0)
    {
        localConnFlg = FALSE;
        connectNo = connectNoParam;
    }
    else
    {
        if ((connectNo = DBA_GetConnection(SqlServer)) == DBA_CONN_NOT_FOUND)
        {
            DBA_FreeDynStTab(extOpTab, extOpNbr, ExtOp);
            MSG_RETURN(RET_DBA_ERR_CONNOTFOUND);
        }
        DBA_BeginTransaction(connectNo);
        localConnFlg = TRUE;
    }


    if (GET_FLAG(extOpTab[0], ExtOp_InSessionFlg) == FALSE)
    {
        if ((sOpSt = ALLOC_DYNST(S_Op)) == NULLDYNST)
        {
            DBA_FreeDynStTab(extOpTab, extOpNbr, ExtOp);
            if (localConnFlg == TRUE)
            {
                DBA_EndTransaction(connectNo, FALSE);
                DBA_EndConnection(connectNo);
            }
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        /* Delete all operations in ext_order or operation table */
        for (i = 0; i < extOpNbr; i++)
        {
            if (IS_NULLFLD(extOpTab[i], ExtOp_DbId) == FALSE)
            {
                SET_ID(sOpSt, S_Op_Id, GET_ID(extOpTab[i], ExtOp_DbId));
            }
            else if (IS_NULLFLD(extOpTab[i], ExtOp_OpId) == FALSE)
            {
                SET_ID(sOpSt, S_Op_Id, GET_ID(extOpTab[i], ExtOp_OpId));
            }
            else
            {
                SET_ID(sOpSt, S_Op_Id, GET_ID(extOpTab[i], ExtOp_Id));
            }

            if (DBA_Delete2(EOp, UNUSED, S_Op, sOpSt, DBA_SET_CONN | DBA_NO_CLOSE, &connectNo, UNUSED) != RET_SUCCEED)
            {
                DBA_FreeDynStTab(extOpTab, extOpNbr, ExtOp);
                FREE_DYNST(sOpSt, S_Op);
                if (localConnFlg == TRUE)
                {
                    DBA_EndTransaction(connectNo, FALSE);
                    DBA_EndConnection(connectNo);
                }
                MSG_RETURN(RET_DBA_ERR_DELETE_FAILED);
            }
        }
        FREE_DYNST(sOpSt, S_Op);
    }
    else
    {
        /* Delete ext_operations */
        for (i = 0; i < extOpNbr; i++)
        {
            if (IS_NULLFLD(extOpTab[i], ExtOp_DraftOrderId) == TRUE)
                SET_ID(extOpTab[i], ExtOp_DraftOrderId, GET_ID(extOpTab[i], ExtOp_DbId));

            if (DBA_Delete2(EOp, UNUSED, ExtOp, extOpTab[i], DBA_SET_CONN | DBA_NO_CLOSE, &connectNo, UNUSED) != RET_SUCCEED)
            {
                DBA_FreeDynStTab(extOpTab, extOpNbr, ExtOp);
                if (localConnFlg == TRUE)
                {
                    DBA_EndTransaction(connectNo, FALSE);
                    DBA_EndConnection(connectNo);
                }
                MSG_RETURN(RET_DBA_ERR_DELETE_FAILED);
            }
        }
    }

    if (localConnFlg == TRUE)
    {
        DBA_EndTransaction(connectNo, TRUE);
        DBA_EndConnection(connectNo);
    }
    return(RET_SUCCEED);
}

/************************************************************************
**   END  compound.c                                                   **
*************************************************************************/

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**  Produce a stack trace for Solaris systems. 
**  Copyright (C) 1995-1998 Andrew Gabriel <and...@cucumber.demon.co.uk>
**  Parts derived from Usenet postings of Bart Smaalders and Casper Dik.
************************************************************************/

/************************************************************************
**      Include files
*************************************************************************/

#include <set>
#include <string>

#include <cxxabi.h>

#include <unistd.h> 
#include <string.h>
#include <stdlib.h>
#include <execinfo.h>

#include "syslib.h"

/*******************************************************************************
**      Global variables
*******************************************************************************/

static std::set<std::string> SV_SetBannedFunction;

/************************************************************************
**
**  Function    :   initializationcallstack()
**
**  Description :   This crate a set of function to not display on the callstack to have a "light" stack trace 
**
**  Arguments   :
**
**
**  Return      :
**
**  Last modif. :  Finish, test and integrate the stack trace demangling on Linux
**
*************************************************************************/
void OS_InitializationCallStack()
{
    SV_SetBannedFunction.insert("getcallstackCpp");
    SV_SetBannedFunction.insert("OS_GetCallStack");
    SV_SetBannedFunction.insert("SYS_GetCallStack");
}


/************************************************************************
**
**  Function    :   OS_RemoveCallStack()
**
**  Description :   Memory cleanup
**
**  Arguments   :
**
**
**  Return      :
**
**  Last modif. :   PMSTA-25852 - 110117 - PMO : Integrate getcallstack as a standard TripleA library
**
*************************************************************************/
void OS_RemoveCallStack()
{
    SV_SetBannedFunction.clear();
}


/************************************************************************
**
**  Function    :   getcallstack()
**
**  Description :   function walks up call stack,once for each stack frame
**                 
**  Arguments   :   bool    If the binary is compiled in debug mode
**                          I will provide line number and source line too :-)
**
**  Return      :   NULL    Malloc Failed
**                  Pointer on a buffer that contain the stacktrace and that can be freed with free
**
**  Last modif. :   PMSTA-16416 - 300513 - PMO : Compile then upload ICU Linux libs in CMS
**                  PMSTA-21983 - 181215 - PMO : Finish, test and integrate the stack trace on AIX
**                  PMSTA-26714 - 160317 - PMO : Fixes of some errors founded by AddressSanitizer
**
*************************************************************************/
char * OS_GetCallStack(const bool printAddress)                                              /* PMSTA-25793 - 281216 - PMO / PMSTA-21983 - 181215 - PMO */
{ 
    std::string     stackFrame;                                                         /* Storage of the final stack frame */
    std::string     stackLine;                                                          /* Storage of the final stack frame */
    void *          array[128];                                                         /* Storage of frames                */
    const size_t    size            = backtrace (array, sizeof(array) / sizeof(array[0]));
    char **         strings         = backtrace_symbols (array, int(size));
    bool            bannedFunction  = false;

    for (size_t idx = 0; idx < size; idx++)
    {
        if (nullptr != strings[idx])
        {
            bannedFunction = false;

            if(printAddress)
			{
                stackLine = SYS_ToString(array[idx]);                                        /* PMSTA-21983 - 181215 - PMO */
                stackLine += "  ";
            }
			else
			{
				stackLine = "";
			}
            std::string functionName = strings[idx];

            /* Example of mangled function name
             * Linux/bin64/getcallstack.so(getcallstack+0x41) [0x7f6e2d93cc61]
             * Linux/bin64/aaa_srv(_Z15OS_GetCallStackB5cxx11v+0x14) [0xc5a554]
             * Linux/bin64/aaa_srv(_Z16SYS_GetCallStackB5cxx11v+0x43) [0xb25623]
             * Linux/bin64/aaa_srv() [0x5ffb1f]
             * Linux/bin64/aaa_srv(_Z12MSG_SendMesgiiPKciz+0x80) [0x600260]
             * Linux/bin64/aaa_srv(_Z15MSG_OpenMsgFilePc+0x1c2) [0x6008a2]
             * Linux/bin64/aaa_srv(_Z11GEN_Initialv+0xa21) [0xbccb51]
             * Linux/bin64/aaa_srv(_Z11mainTripleAiPPc+0x25d) [0x5e9c6d]
             * Linux/bin64/aaa_srv(main+0x23) [0x5ea363]
             * /lib64/libc.so.6(__libc_start_main+0xfd) [0x34d041ed5d]
             * Linux/bin64/aaa_srv() [0x5e91a1]
             */

            { // Remove modulename: "Linux/bin64/getcallstack.so(getcallstack+0x41) [0x7f6e2d93cc61]" -> "getcallstack+0x41) [0x7f6e2d93cc61]"
                size_t beginTag = functionName.find("(");

                if (std::string::npos != beginTag)
                {
                    functionName.erase(0, beginTag + 1); /* 1 for ( */
                }
            }
            { // Remove address: "getcallstack+0x41) [0x7f6e2d93cc61]" -> "getcallstack"
                size_t endTag = functionName.rfind("+0x");

                if (std::string::npos != endTag)
                {
                    functionName.erase(endTag, functionName.length() - endTag);
                }
            }

            int status = 0;
            char * functionNameDemangled = abi::__cxa_demangle(functionName.c_str(), nullptr, nullptr, &status);

            if (nullptr != functionNameDemangled)
            {
                std::string functionDemangled = functionNameDemangled;

                free(functionNameDemangled);

                /* Example of demangled function name
                 * OS_GetCallStack[abi:cxx11]()
                 * SYS_GetCallStack[abi:cxx11]()
                 * MSG_SendMesg(int, int, char const*, int, ...)
                 * MSG_OpenMsgFile(char*)
                 * GEN_Initial()
                 * mainTripleA(int, char**)
                 */

                { // Remove [abi:cxx11] if any
                    size_t beginTag = functionDemangled.find("[abi:cxx11]");

                    if (std::string::npos != beginTag)
                    {
                        functionDemangled.erase(beginTag, 11); // 11 is "[abi:cxx11]"
                    }
                }

                functionName = functionDemangled;
                { // Remove argument(s): "MSG_SendMesg(int, int, char const*, int, ...)" -> "MSG_SendMesg"
                    size_t endTag = functionName.rfind("(");

                    if (std::string::npos != endTag)
                    {
                        functionName.erase(endTag, functionName.length() - endTag);
                    }
                }

                // Look for a banned function
                std::set<std::string>::iterator it = SV_SetBannedFunction.find(functionName);
                bannedFunction = it != SV_SetBannedFunction.end();

                if (false == bannedFunction)
                {
                    stackLine  += functionDemangled;
                    stackFrame += stackLine;
                    stackFrame += "\n";
                }
            }
        }
    }

    free(strings);  /* PMSTA-26714 - 160317 - PMO */


    return strdup(stackFrame.c_str());              /* PMSTA-25793 - 281216 - PMO / PMSTA-21983 - 181215 - PMO */
} 


/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DBAPERF_C

/************************************************************************
**      Include files
*************************************************************************/
#ifdef NTWIN
#pragma warning (push)
#endif

#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H
#define MATH_H

#include "unidef.h"        /* Mandatory */
#include "gen.h"
#include "date.h"
#include "dba.h"
#include "dbaperf.h"
#include "fin.h"
#include "finsrv.h"
#include "scptyl.h"
#include "fmtlib01.h"
#include "dbabcp.h"

#ifdef NTWIN
#pragma warning (pop)
#endif

/*  -------------------------------------------------------------------------------------------- **
**  PORTFOLIO STORAGE AND BENCHMARK STORAGE FUNCTIONS
**  -------------------------------------------------
**
**  DBA_InsSecondSynthDataPrep  copy of secondary synth in PerfAttrib and ExtRetAnalysis (or StandardPerf) table for insert in database.
**  DBA_InsInstrFreqDataPrep    copy of portfolio freq data in StandardPerf table for insert in database.
**  DBA_InsStratSynthDataPrep   copy of strategy synth data in PerfAttrib and StandardPerf table for insert in database.
**  DBA_InsInstrFreqDataPrep    copy of instr freq data in StandardPerf table for insert in database.
**  DBA_InsertPaAndExtRaData    insert PerfAttrib, StandardPerf or ExtRetAnalysis data in database (compute new and replace old).
**  DBA_DeletePaAndExtRaData    delete PerfAttrib, StandardPerf or ExtRetAnalysis data in database (delete).
**
**  internal functions:
**
**  DBA_UpdPspDelPaExtRaStdP    prepares insert for update PSP and delete PerfAttrib, StandardPerf and ExtRetAnalysis.
**  DBA_SavePaAndExtRaData      real insert PerfAttrib or ExtRetAnalysis data in database.
**  DBA_SaveExtRetAnalysisBCP   decompose ExtRetAnalysis into StdPerfData, RaGlobal and RaDetailed for insert in BCP mode.
**  DBA_SaveStdPerfDateBCP      decompose StandardPerf into StdPerfData for insert in BCP mode.
**  DBA_SaveStdPerfRaBCP        real insert StdPerfData, RaGlobal, RaDetailed and Ud-tables in database (with BCP mode).
**  DBA_CommonScptFlagTabPa     initialise common parts of flag array for script evalation for PerfAttrib view
**  DBA_CommonScptFlagTabExtRa  initialise common parts of flag array for script evalation for ExtRetAnalysis view
**  DBA_CopyPspToPa             copy values from PerfStorageParam (PSP) table to PerfAttrib view
**  DBA_CopyPspToExtRa          copy values from PerfStorageParam (PSP) table to ExtRetAnalysis view
**  DBA_TestRaGlobalData        tests if ret analysis data is filled
**
**  ------------------------------------------------------------------------------------------ **
**  FILTER FUNCTIONS
**  ----------------
**
**  FIN_FilterValidStratSynth       Extract current strategy synthetics.
**  DBA_FilterInstrFreqPsp          Extract instrument frequency for given instrument.
**  DBA_FilterStdPerfPtfFreq        Extract (in our case Delete) StandardPerf of entity portfolio.
**
**  -------------------------------------------------------------------------------------------- **
**  COMPARISONS FUNCTIONS
**  ---------------------
**
**  DBA_CmpPtfSynthdDate        Synthetics sorted by date.
**  DBA_CmpPtfFreqInitialDate   Portfolio frequncy sorted by initial date and id.
**  DBA_CmpStratSynthInitialDate Strategy synthetics sorted by initial date.
**  DBA_CmpInstrFreqInitialDate Instrument frequncy sorted by initial date.
**  DBA_CmpInsPtfBenchStorage   Comparison function used befor insert or delete with multiaccess.
**
**  -------------------------------------------------------------------------------------------- */

/************************************************************************
**      Static definitions & data
*************************************************************************/

/* REF7421 - YST - 020823 - enum used for filter computed data for insert in database */
typedef enum {
        InsPaExtRaFilter_Instr,
        InsPaExtRaFilter_Grid,
        InsPaExtRaFilter_Global
} INSPAEXTRAFILTER_ENUM;

STATIC RET_CODE DBA_UpdPspDelPaExtRaStdP(DBA_DYNFLD_STP, DBA_DYNFLD_STP, FLAG_T, DATETIME_T, DATETIME_T, FLAG_T, DATETIME_T, DATETIME_T,
                                        FLAG_T, DATETIME_T, DATETIME_T, FLAG_T, DATETIME_T, DATETIME_T, DATETIME_T, DATETIME_T, DBA_INSPAEXTRA_STP),

                DBA_SavePaAndExtRaData(DBA_DYNFLD_STP, OBJECT_ENUM, DBA_DYNST_ENUM,
                                        DBA_DYNFLD_STP *, int, DbiConnectionHelper &),

                DBA_SaveExtRetAnalysisBCP(DBA_DYNFLD_STP, DBA_DYNFLD_STP *,
                                        int, DBA_ACCESS_ST *, int, DbiConnectionHelper &, void *),           /* REF8798 - YST - 030603 */

                DBA_SaveStdPerfDateBCP(DBA_DYNFLD_STP, DBA_DYNFLD_STP *,
                                        int, DBA_ACCESS_ST *, int, DbiConnectionHelper &, void *),           /* REF8798 - YST - 030603 */

				DBA_SavePerfCalcResult(DBA_DYNFLD_STP, DBA_DYNFLD_STP *, int, DbiConnectionHelper &),

                DBA_SaveStdPerfRaBCP(DBA_DYNFLD_STP, OBJECT_ENUM, DBA_DYNST_ENUM, const char *,
                                        DBA_DYNFLD_STP *, int, DBA_ACCESS_ST *, int, int, DbiConnectionHelper &, void *),    /* REF8798 - YST - 030603 */

                DBA_SavePaBCP(DBA_DYNFLD_STP, DBA_DYNFLD_STP *,
                                        int, DBA_ACCESS_ST *, int, DbiConnectionHelper &, void *),

                DBA_CommonScptFlagTabPa(FLAG_T *),
                DBA_CommonScptFlagTabExtRa(FLAG_T *),
                DBA_CommonScptFlagTabStdPerf(FLAG_T *),

                DBA_CopyPspToPa(DBA_DYNFLD_STP, DBA_DYNFLD_STP),
                DBA_CopyPspToExtRa(DBA_DYNFLD_STP, DBA_DYNFLD_STP),
                DBA_CopyPspToStdPerf(DBA_DYNFLD_STP, DBA_DYNFLD_STP),

                DBA_TestRaGlobalData(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP *,
                                    DBA_INSPAEXTRA_STP, int *, FLAG_T *),

                DBA_PrepareSPForAddInHier(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP*, DBA_INSPAEXTRA_STP, int*);

STATIC int		DBA_FilterSecondSynthPSP(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP),
                DBA_FilterSecondSynthPSPwithPtf(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP),
                DBA_FilterSynthPSP(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP),
                DBA_FilterAllGlobalPtfSynth(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP),
                FIN_FilterValidStratSynth(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP),
                DBA_FilterInstrFreqPsp(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP),
                DBA_FilterExtRaNotOk(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP),
                DBA_FilterStdPerfPtfFreq(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP), /* REF7423 - YST - 021104 */
				DBA_FilterPerfCalcResultPSPwithPtf(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP),/*PMSTA-53308 -SENTHIL-060623*/

                DBA_CmpPtfSynthDate(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *),
                DBA_CmpPtfFreqInitialDate(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *),
                DBA_CmpStratSynthInitialDate(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *),
                DBA_CmpInstrFreqInitialDate(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *),
                DBA_CmpInsPtfBenchStorage(DBA_ACCESS_STP, DBA_ACCESS_STP);


STATIC int DBA_CmpObjPtfId(DBA_DYNFLD_STP*, DBA_DYNFLD_STP*);
STATIC int DBA_CmpPSPObjId(DBA_DYNFLD_STP*, DBA_DYNFLD_STP*);

STATIC RET_CODE DBA_UpdPtfPerfLastFinalDateAndEventSched(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DATETIME_T, FLAG_T, DBA_INSPAEXTRA_STP);	/* PMSTA02013 - RAK - 071112 */

STATIC DBA_DYNFLD_STP FIN_CreateESEFromStrategySynth(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP);

STATIC void FIN_CopyPPDAInfoToDomain(DBA_DYNFLD_STP, DBA_DYNFLD_STP);

/************************************************************************
**
**  Function    :   DBA_CmpPerfAttribByDtMktSegt()
**
**  Description :
**
**  Arguments   :   ptr1   pointer on dynamic structure
**                  ptr2   pointer on dynamic structure
**
**  Return      :   a negative value if first element < second element
**                  a zero value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation    :   PMSTA08736 - LJE - 100623
**
*************************************************************************/
STATIC int DBA_CmpPerfAttribByDtMktSegt(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    int ret;

    if ((ret = CMP_DYNFLD((*ptr1), (*ptr2), A_PerfAttrib_InitialDate, A_PerfAttrib_InitialDate, DatetimeType)) != 0)
        return ret;

    if ((ret = CMP_DYNFLD((*ptr1), (*ptr2), A_PerfAttrib_FinalDate, A_PerfAttrib_FinalDate, DatetimeType)) != 0)
        return ret;

    /* MktSegtId is sorted for have NULL in first */
    if ((ret = CMP_ID(GET_ID((*ptr1), A_PerfAttrib_MktSegtId), GET_ID((*ptr2), A_PerfAttrib_MktSegtId))) != 0)
        return ret;

    if (IS_NULLFLD((*ptr1), A_PerfAttrib_InstrId) == TRUE)
        return -1;

    if (IS_NULLFLD((*ptr2), A_PerfAttrib_InstrId) == TRUE)
        return 1;

    ret = CMP_ID(GET_ID((*ptr1), A_PerfAttrib_MktSegtId), GET_ID((*ptr2), A_PerfAttrib_MktSegtId));

    return ret;
}

/************************************************************************
**
**  Function    :   DBA_CmpPerfCalcResultByDt()
**
**  Description :
**
**  Arguments   :   ptr1   pointer on dynamic structure
**                  ptr2   pointer on dynamic structure
**
**  Return      :   a negative value if first element < second element
**                  a zero value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation    :   PMSTA-54527 - senthil - 231011
**
*************************************************************************/
STATIC int DBA_CmpPerfCalcResultByDt(DBA_DYNFLD_STP* ptr1, DBA_DYNFLD_STP* ptr2)
{
    int ret;

    if ((ret = CMP_DYNFLD((*ptr1), (*ptr2), A_PerfCalcResult_InitialDate, A_PerfCalcResult_InitialDate, DatetimeType)) != 0)
        return ret;

    if ((ret = CMP_DYNFLD((*ptr1), (*ptr2), A_PerfCalcResult_FinalDate, A_PerfCalcResult_FinalDate, DatetimeType)) != 0)
        return ret;

    return ret;
}

/************************************************************************
**
**  Function    :   DBA_InsSecondSynthDataPrep()
**
**  Description :   Prepares insert of data in database computed by portfolio storage.
**                  Function is called for each portfolio after computation of data.
**                  The structure pointer DBA_INSPAEXTRA_STP is filled with
**                  the following data:
**
**                  Secondary synthetics data (SynthLevel_Primary = FALSE) with
**                  A_PtfSynth_GridLinkNatEn != ReturnGridLnk_ParStorPtfSynth.
**
**                  paTab:
**                  secondary synthetics data with SynthLevel_PA = TRUE for insert
**
**                  extRaTab:
**                  secondary synthetics data with SynthLevel_Gips = TRUE for insert
**
**                  accessStp:
**                  structure pointer for multiaccess
**                  - PerfAttrib and ExtRetAnalysis for delete between
**                    delFromDate and delTillDate
**                  - PerfStorageParam (PSP) for update
**                  - portfolio with new A_Ptf_PerfLastFinalDate for update
**                  - event scheduler for delete if delEventSchedFlg = TRUE
**
**
**  Arguments   :   input:
**                  domainPtr           domain structure pointer
**                  hierHead            hierarchy header pointer
**                  ptfPtr              pointer on portfolio
**                  delFromDate         date from which data must be deleted
**                  delTillDate         date until which data must be deleted
**                  delEventSchedFlg    flag indicating, if delete of event scheduler
**
**                  output:
**                  insPaExtRaStp       pointer on data to insert, update or delete
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   REF7421 - YST - 020805
**  Modification:   REF7395 - YST - 020906 - if no global then delete ExtRetAnalysis and insert StandardPerf
**  Modification:   REF7395 - YST - 021023 - if perfDataContent != GipsPaRa insert StandardPerf
**  modification:   REF9125 - MCA - 030905
**
*************************************************************************/
RET_CODE DBA_InsSecondSynthDataPrep(DBA_DYNFLD_STP      domainPtr,
									       DBA_HIER_HEAD_STP   hierHead,
										   DBA_DYNFLD_STP      ptfPtr,
										   DBA_DYNFLD_STP      pspPtr, /* REF9125 - MCA - 030905*/
										   DATETIME_T          delFromDate,
										   DATETIME_T          delTillDate,
										   FLAG_T              delEventSchedFlg,
										   DBA_INSPAEXTRA_STP  insPaExtRaStp,
                                           PA_DATEINFO_STP     paDateInfoStp)
{
    RET_CODE                retCd = RET_SUCCEED;
	DBA_DYNFLD_STP          *selDynStTab = NULLDYNSTPTR, *paTab = NULLDYNSTPTR, *fullDynStTab = NULLDYNSTPTR, *pspDynStTab = NULLDYNSTPTR,
        *extRaTab = NULLDYNSTPTR, *stdPerfTab = NULLDYNSTPTR, *globalDynStTab = NULLDYNSTPTR,
        * tmpDynStTab = NULLDYNSTPTR;
    DATETIME_T              paFirstDate, paLastDate, extRaFirstDate, extRaLastDate,
                            firstPerfLastFinalDate, secPerfLastFinalDate, nullDateTime, pcrFirstDate, pcrLastDate;
    DICT_T                  entDictId;
    MASK_T                  synthLevelMask = 0, subPeriodMask=0;
    FLAG_T                  *scptFlagTabExtRa=NULL,
                            tmpStdPerfFlg = FALSE, stdPerfFlg = FALSE, retFlg = FALSE, perfFlg = FALSE, pcrFlg = FALSE, perfcalcresFlg = FALSE;
    INSPAEXTRAFILTER_ENUM   insFilterEn = InsPaExtRaFilter_Instr;
    int                     i = 0, j = 0, k = 0, selDynStNbr = 0, paIdx = 0, fullDynStNbr = 0, pspDynStNbr = 0,
                            globalDynStNbr = 0,
        extRaIdx = 0, stdPerfIdx = 0, gridFirstPaIdx = 0, gridFirstExtRaIdx = 0;
    FREQUNIT_ENUM           freqUnit = FreqUnit_None;
	RA_LICENSEE_ENUM		isRALicenseEn=RALicensee_No;
    FLAG_T                  optimDVFlg=TRUE;
    char                   *envStr;
    PA_DATETIME_STP         paDates = (paDateInfoStp == nullptr) ? nullptr : paDateInfoStp->paDates;
    int                     paDatesNbr = (paDateInfoStp == nullptr) ? UNUSED : paDateInfoStp->paDatesNbr;
    MemoryPool              mp;
    FLAG_T                  computeDuraFlg = FALSE; /* PMSTA08736 - LJE - 100623 */


	GEN_GetApplInfo(ApplRALicense, &isRALicenseEn);

    /* PMSTA-17060- LJE - 131025 - No optimisation for global level only, to allow business day frequency (Freq=Day) */
    if (GET_ENUM(pspPtr, A_PerfStorageParam_FrequencyEn) == FreqUnit_Day &&
        IS_NULLFLD(pspPtr, A_PerfStorageParam_GridId) == TRUE &&
        GET_FLAG(pspPtr, A_PerfStorageParam_InstrLevelFlg) == FALSE)
    {
        optimDVFlg=FALSE;
    }
    else if ((envStr = SYS_GetEnv("AAANOOPTIMPTFSTOREDV")) != NULL &&
        strcmp(envStr,"TRUE") == 0)
    {
        optimDVFlg=FALSE;
    }

	/* REF9125 - RAK - 031010 - we need to receive the pspPtr */
	if (pspPtr == NULLDYNST)
	{
		MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
	                 "DBA_InsSecondSynthDataPrep", "no PSP received");
		return(RET_GEN_ERR_INVARG);
	}

    if (GET_FLAG(pspPtr, A_PerfStorageParam_PerfCalcResultFlg) == TRUE)
    {
        pcrFlg = TRUE;
        retCd = DBA_CreatePerfCalcResultData(domainPtr, hierHead, pspPtr, paDateInfoStp);
    }
    else
    {
        /* PMSTA-52459 - DDV - 230331 - To avoid regression, remove all PtfSynth added to manage NIP */
        if (EV_KeepPtfSynthInPA == 0 || EV_KeepPtfSynthInPA == 1)
        {
            DBA_MergeAndDeleteUselessNIPPtfSynth(hierHead, domainPtr, pspPtr, paDates, paDatesNbr, 0, 0);
        }
    }

    /* memory allocation */
    memset(&paFirstDate,         0, sizeof(DATETIME_T));
    memset(&paLastDate,          0, sizeof(DATETIME_T));
    memset(&extRaFirstDate,      0, sizeof(DATETIME_T));
    memset(&extRaLastDate,       0, sizeof(DATETIME_T));
    memset(&firstPerfLastFinalDate, 0, sizeof(DATETIME_T));
    memset(&secPerfLastFinalDate,   0, sizeof(DATETIME_T));
    memset(&nullDateTime,           0, sizeof(DATETIME_T));
	memset(&pcrFirstDate, 0, sizeof(DATETIME_T));
	memset(&pcrLastDate, 0, sizeof(DATETIME_T));

    FLAG_T *scptFlagTabPa = (FLAG_T *) mp.calloc(GET_FLD_NBR(A_PerfAttrib), sizeof(FLAG_T));

    /* PMSTA08736 - LJE - 100623 */
    FLAG_T *scptFlagTabPaDura = (FLAG_T *) mp.calloc(GET_FLD_NBR(A_PerfAttrib), sizeof(FLAG_T));

    /* REF9832 - RAK - 040303 - Suppress perfDataContent - test will be done only on PSP flags */

	/* REF9125 - RAK - 031014 - System parameter say to store A_ExtRetAnalysis, but PSP could say no */
    if (GET_FLAG(pspPtr, A_PerfStorageParam_RetAnalysisFlg) == TRUE)
	{
		scptFlagTabExtRa = (FLAG_T *) mp.calloc(GET_FLD_NBR(A_ExtRetAnalysis), sizeof(FLAG_T));
    }	/* REF9125 - RAK - 031014 - System parameter say to store A_StandardPerf, but PSP could say no */
    else if (GET_FLAG(pspPtr, A_PerfStorageParam_StandardPerfDataFlg) == TRUE)
	{
		scptFlagTabExtRa = (FLAG_T *) mp.calloc(GET_FLD_NBR(A_StandardPerf), sizeof(FLAG_T));
	}

	/* REF9125 - RAK - 031010 - Suppress get of PSP, it is received (replace aPspPtr[gridIdx] by pspPtr) */

    DBA_GetDictId(Ptf, &entDictId);

	/* REF9125 - RAK - 031014 - Don't use Ptf level ... and any way this flag isn't used ! */
    /* if ((PTFRETDETLVL_ENUM)GET_ENUM(ptfPtr, A_Ptf_PerfDetLevelEn) == PtfRetDetLvl_Instrument)
        instrLevelFlg = 1; */

    /* REF8877 - YST - 030409 - use perfFreq  for the moment */
    if (paDateInfoStp != nullptr && 
        IS_NULLFLD(paDateInfoStp->pspPtr, A_PerfStorageParam_PerfCalcDefProfileId) == FALSE)/*PMSTA-54535 - SENTHIL - 260923*/
    {
        freqUnit = (FREQUNIT_ENUM)(paDateInfoStp->freqUnitEn);
    }
    else
        freqUnit = (FREQUNIT_ENUM)GET_ENUM(ptfPtr, A_Ptf_PerfFreqUnitEn);

    if (freqUnit == FreqUnit_MonthGlobalTWR || freqUnit == FreqUnit_MonthTWR)
        freqUnit = FreqUnit_Month;

	/* REF9125 - RAK - 031014 - PSP is always received, code is set before loop and  aPspPtr[gridIdx] is replaced by pspPtr) */
	if (GET_FLAG(pspPtr, A_PerfStorageParam_InstrLevelFlg) == TRUE)
    {
        insFilterEn = InsPaExtRaFilter_Instr;		/* instrument: insert all port synth */
	}
	else if (IS_NULLFLD(pspPtr, A_PerfStorageParam_GridId) != TRUE)
    {
        insFilterEn = InsPaExtRaFilter_Grid;		/* grid: insert port synth with instrId = NULL*/
    }
    else
    {
        insFilterEn = InsPaExtRaFilter_Global;		/* global: insert port synth with instrId = NULL AND mktSegId = NULL*/
    }

	/* REF9738  - RAK - 040115 - license control */
	/* RA = 0 we can insert only global synthetics */
	if (isRALicenseEn == RALicensee_No)
		insFilterEn = InsPaExtRaFilter_Global;

    /* Extract all secondary synthetics for the given porfolio, sorted by grid id and initial date */
	/* REF9125 - RAK - 030917 - change filter to extract only record with received PSP */
    /*PMSTA-48195 -PerfIPSLevel -Lalby-180722*/
    if ((static_cast<LOADHIERPTF_ENUM> GET_ENUM(domainPtr, A_Domain_LoadHierFlg) == LoadHierPtf_IntermediateHierarchy))
    {
        /* Added portfolio id check also in the filter , synth is having multiple records of different ptfs*/
        if ((retCd = DBA_ExtractHierEltRecWithFilterSt(hierHead, A_PtfSynth, FALSE,
            DBA_FilterSecondSynthPSPwithPtf, pspPtr, DBA_CmpPtfSynthDate,
            &selDynStNbr, &selDynStTab)) != RET_SUCCEED)
        {
            FREE(selDynStTab);
            return(retCd);
        }
    }
    else
    {
        if ((retCd = DBA_ExtractHierEltRecWithFilterSt(hierHead, A_PtfSynth, FALSE,
            DBA_FilterSecondSynthPSP, pspPtr, DBA_CmpPtfSynthDate,
            &selDynStNbr, &selDynStTab)) != RET_SUCCEED)
        {
            FREE(selDynStTab);
            return(retCd);
        }
    }

    mp.ownerPtr(selDynStTab);

    if (selDynStNbr > 0)
    {
        paTab = (DBA_DYNFLD_STP *)mp.calloc(selDynStNbr, sizeof(DBA_DYNFLD_STP));
        extRaTab = (DBA_DYNFLD_STP *)mp.calloc(selDynStNbr, sizeof(DBA_DYNFLD_STP));
        stdPerfTab = (DBA_DYNFLD_STP *)mp.calloc(selDynStNbr, sizeof(DBA_DYNFLD_STP));


        retCd = DBA_ExtractHierEltRecWithFilterSt(hierHead, A_PtfSynth, FALSE,
                                                  DBA_FilterSynthPSP, pspPtr, DBA_CmpPtfSynthDate,
                                                  &pspDynStNbr, &pspDynStTab);

        mp.ownerPtr(pspDynStTab);

        if (retCd != RET_SUCCEED || pspDynStNbr == 0)
        {
            return(retCd);
        }

        /* PMSTA-55377 - Deepthi - 240117 - Extraction of Global port synth records are done before DV call,
                                        so as to save time in RETURN and MEAN_CAP keyword computation */
        if ((retCd = DBA_ExtractHierEltRecWithFilterSt(hierHead, A_PtfSynth, FALSE,
                                                       DBA_FilterAllGlobalPtfSynth, pspPtr, DBA_CmpPtfSynthDate,
                                                       &globalDynStNbr, &globalDynStTab)) != RET_SUCCEED || globalDynStNbr == 0)
        {
            return(retCd);
        }

        mp.ownerPtr(globalDynStTab);

        if (globalDynStNbr > 0) /* if global port synthetic records exists */
        {
            for (int idx = 0; idx < pspDynStNbr; idx++)
            {
                if ((tmpDynStTab = (DBA_DYNFLD_STP*)CALLOC(globalDynStNbr, sizeof(DBA_DYNFLD_STP))) != NULLDYNSTPTR)
                {
                    memcpy(tmpDynStTab, globalDynStTab, (globalDynStNbr * sizeof(DBA_DYNFLD_STP)));
                    /* Set extension pointer to the global port synth records*/
                    SET_EXTENSION(pspDynStTab[idx], A_PtfSynth_GblPtfSynth_Ext, tmpDynStTab, A_PtfSynth, (short)globalDynStNbr);
                }
                else
                {
                    return(RET_MEM_ERR_ALLOC);
                }
            }
            DBA_SetHierLnkUsed(hierHead, A_PtfSynth, A_PtfSynth_GblPtfSynth_Ext);
        }

        if (optimDVFlg == TRUE)
        {
            retCd = DBA_ExtractHierEltRecWithFilterSt(hierHead, A_PtfSynth, FALSE,
                                                      NULL, pspPtr, DBA_CmpPtfSynthDate,
                                                      &fullDynStNbr, &fullDynStTab);
            mp.ownerPtr(fullDynStTab);

            if (retCd != RET_SUCCEED || fullDynStNbr == 0)
            {
                return(retCd);
            }

            DBA_SetDoNotDeleteRecFlag(hierHead, A_PtfSynth, TRUE);
            DBA_FreeHierEltRecord(hierHead, A_PtfSynth);
        }
	}

    ID_T    dictIdForDummyCumulRecord = ID_T(0);
    if (static_cast<PTFCONSRULE_ENUM>GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) == PtfConsRule_MergedTWR_Detail)
    {
        if (GET_DICT(domainPtr, A_Domain_SavedDimEntityDictId) == ListCst ||
            GET_DICT(domainPtr, A_Domain_SavedDimEntityDictId) == QuickSearchCst)
        {
            dictIdForDummyCumulRecord = ListCst;
        }
        else if (GET_DICT(domainPtr, A_Domain_SavedDimPtfDictId) == ThirdCst)
        {
            dictIdForDummyCumulRecord = ThirdCst;
        }
    }

    for (i=0; i<selDynStNbr && retCd == RET_SUCCEED; i++)
    {
		/* REF9353 - LJE - 040211 - Don't insert blank */
		if (GET_ENUM(selDynStTab[i], A_PtfSynth_ToInsertEn) != PtfSynthAction_Insert)
		    continue;

		/* REF9125 - NEW YST - if no PSP is received */
		/* REF9125 - RAK - 031010 - PSP is always received, code is set before loop and aPspPtr[gridIdx] is replaced by pspPtr) */

        /* Insert only if synthetic portfolio corresponds to required detail level */
        if ((insFilterEn == InsPaExtRaFilter_Instr ||
            (insFilterEn == InsPaExtRaFilter_Grid   && IS_NULLFLD(selDynStTab[i], A_PtfSynth_InstrId) == TRUE) ||
            (insFilterEn == InsPaExtRaFilter_Grid   && IS_NULLFLD(selDynStTab[i], A_PtfSynth_Dura) == FALSE) || /* PMSTA08736 - LJE - 100623 */
            (insFilterEn == InsPaExtRaFilter_Global && IS_NULLFLD(selDynStTab[i], A_PtfSynth_InstrId) == TRUE &&
            IS_NULLFLD(selDynStTab[i], A_PtfSynth_MktSegtId) == TRUE)))
        {
            synthLevelMask = (MASK_T)GET_TINYINT(selDynStTab[i], A_PtfSynth_Level);

            /* insert only synthetic portfolio with level field SynthLevel_PA to TRUE and only
               if data is not global and if system parameter allows to insert PerfAttrib data */
			/* REF9125 - RAK - 031010 - Insert only if PSP_PerfAttribFlg is TRUE */
            if (GET_FLAG(pspPtr, A_PerfStorageParam_PerfAttribFlg) == TRUE &&
				GET_BIT(synthLevelMask, SynthLevel_PA) == TRUE &&
                (insFilterEn == InsPaExtRaFilter_Instr || insFilterEn == InsPaExtRaFilter_Grid))
            {
                /* YST - 020823 - possible to add test on first date:
                && DATETIME_CMP(DATETIME_CMP(aPspTab[aPspIdx-1], A_PerfStorageParam_PerfFirstStoredDate),
                            GET_DATETIME(selDynStTab[i], A_PtfSynth_InitialDate)) <= 0*/

                paTab[paIdx] = mp.allocDynst(FILEINFO, A_PerfAttrib);

		    	DBA_CopyPspToPa(pspPtr, paTab[paIdx]);

                if (static_cast<PTFCONSRULE_ENUM>GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) == PtfConsRule_MergedTWR_Detail &&
                GET_ID(paTab[paIdx], A_PerfAttrib_ObjId) < 0) //dummy ptf
                {
                    COPY_DYNFLD(paTab[paIdx], A_PerfAttrib, A_PerfAttrib_ObjId,
                    selDynStTab[i], A_PtfSynth, A_PtfSynth_ListId);
                    SET_DICT(paTab[paIdx], A_PerfAttrib_EntDictId, dictIdForDummyCumulRecord);
                }

                COPY_DYNFLD(paTab[paIdx], A_PerfAttrib, A_PerfAttrib_InitialDate,
                            selDynStTab[i], A_PtfSynth, A_PtfSynth_InitialDate);

                COPY_DYNFLD(paTab[paIdx], A_PerfAttrib, A_PerfAttrib_FinalDate,
                            selDynStTab[i], A_PtfSynth, A_PtfSynth_FinalDate);

                COPY_DYNFLD(paTab[paIdx], A_PerfAttrib, A_PerfAttrib_MktSegtId,
                            selDynStTab[i], A_PtfSynth, A_PtfSynth_MktSegtId);

                COPY_DYNFLD(paTab[paIdx], A_PerfAttrib, A_PerfAttrib_InstrId,
                            selDynStTab[i], A_PtfSynth, A_PtfSynth_InstrId);

				/* REF9125 - RAK - 030917 - Get PSP id */
				COPY_DYNFLD(paTab[paIdx], A_PerfAttrib, A_PerfAttrib_PerfStorParamId,
                            selDynStTab[i], A_PtfSynth, A_PtfSynth_PSPId);

                subPeriodMask = (MASK_T)0;
                if (GET_BIT(synthLevelMask, SynthLevel_BenchRebal) == TRUE)
                    SET_BIT(subPeriodMask, SynthLevel_BenchRebal, TRUE);
                if (GET_BIT(synthLevelMask, SynthLevel_PortBenchStorage) == TRUE)
                    SET_BIT(subPeriodMask, SynthLevel_PortBenchStorage, TRUE);
                SET_MASK(paTab[paIdx], A_PerfAttrib_SubPeriodMask, subPeriodMask);

                /* REF9743 - LJE - 040211 */
                COPY_DYNFLD(paTab[paIdx],   A_PerfAttrib, A_PerfAttrib_InitialMktVal,
                            selDynStTab[i], A_PtfSynth,   A_PtfSynth_InitialMktVal);
                /* REF9743 - LJE - 040211 */
                COPY_DYNFLD(paTab[paIdx],   A_PerfAttrib, A_PerfAttrib_FinalMktVal,
                            selDynStTab[i], A_PtfSynth,   A_PtfSynth_FinalMktVal);

                /* REF9743 - LJE - 040218 */
                COPY_DYNFLD(paTab[paIdx],   A_PerfAttrib, A_PerfAttrib_Adjust,
                            selDynStTab[i], A_PtfSynth,   A_PtfSynth_NetAdj);

                /* REF9743 - LJE - 040211
                    SET_AMOUNT(paTab[paIdx], A_PerfAttrib_InitialMktVal,
                               GET_AMOUNT(selDynStTab[i], A_PtfSynth_InitialMktVal) -
                               GET_AMOUNT(selDynStTab[i], A_PtfSynth_NetAdj));
                 */

                COPY_DYNFLD(paTab[paIdx],   A_PerfAttrib, A_PerfAttrib_PortSynthId,
                            selDynStTab[i], A_PtfSynth,   A_PtfSynth_Id);

                /* PMSTA08736 - LJE - 100623 */
                if (IS_NULLFLD(selDynStTab[i], A_PtfSynth_Dura) == FALSE)
                {
                    computeDuraFlg = TRUE;
                    COPY_DYNFLD(paTab[paIdx],   A_PerfAttrib, A_PerfAttrib_Dura,
                                selDynStTab[i], A_PtfSynth,   A_PtfSynth_Dura);
                }

                paIdx++;
            }

            /* insert only synthetic portfolio with level field SynthLevel_Gips to TRUE */
            if (retCd == RET_SUCCEED &&
                GET_BIT(synthLevelMask, SynthLevel_Gips) == TRUE &&
                (insFilterEn == InsPaExtRaFilter_Instr || IS_NULLFLD(selDynStTab[i], A_PtfSynth_InstrId) == TRUE)) /* PMSTA08736 - LJE - 100623 */
            {
                /* YST - 020823- possible to add test on first date:
                    &&(DATETIME_CMP(DATETIME_CMP(aPspTab[aPspIdx-1], A_PerfStorageParam_StdPerfFirstStoredDate),
                                GET_DATETIME(selDynStTab[i], A_PtfSynth_InitialDate)) <= 0 ||
                     DATETIME_CMP(DATETIME_CMP(aPspTab[aPspIdx-1], A_PerfStorageParam_RetFirstStoredDate),
                                GET_DATETIME(selDynStTab[i], A_PtfSynth_InitialDate)) <= 0)*/

                /* insert data in ExtRetAnalysis table - REF7395 - YST - 021023 */
				/* REF9125 - RAK - 031010 - Insert only if PSP_RetAnalysisFlg is TRUE */
				if (GET_FLAG(pspPtr, A_PerfStorageParam_RetAnalysisFlg) == TRUE)
                {
                    extRaTab[extRaIdx] = mp.allocDynst(FILEINFO,A_ExtRetAnalysis);

                    DBA_CopyPspToExtRa(pspPtr, extRaTab[extRaIdx]);

                    if (static_cast<PTFCONSRULE_ENUM>GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) == PtfConsRule_MergedTWR_Detail &&
                        GET_ID(extRaTab[extRaIdx],A_ExtRetAnalysis_ObjId)< 0 ) //dummy ptf
                    {
                        COPY_DYNFLD(extRaTab[extRaIdx], A_ExtRetAnalysis, A_ExtRetAnalysis_ObjId,
                            selDynStTab[i], A_PtfSynth, A_PtfSynth_ListId); 

                        SET_DICT(extRaTab[extRaIdx], A_ExtRetAnalysis_EntDictId, dictIdForDummyCumulRecord);
                    }


                    COPY_DYNFLD(extRaTab[extRaIdx], A_ExtRetAnalysis, A_ExtRetAnalysis_InitialDate,
                                    selDynStTab[i], A_PtfSynth, A_PtfSynth_InitialDate);

                    COPY_DYNFLD(extRaTab[extRaIdx], A_ExtRetAnalysis, A_ExtRetAnalysis_FinalDate,
                                    selDynStTab[i], A_PtfSynth, A_PtfSynth_FinalDate);

                    COPY_DYNFLD(extRaTab[extRaIdx], A_ExtRetAnalysis, A_ExtRetAnalysis_MktSegtId,
                                    selDynStTab[i], A_PtfSynth, A_PtfSynth_MktSegtId);

                    COPY_DYNFLD(extRaTab[extRaIdx], A_ExtRetAnalysis, A_ExtRetAnalysis_InstrId,
                                    selDynStTab[i], A_PtfSynth, A_PtfSynth_InstrId);

                    COPY_DYNFLD(extRaTab[extRaIdx], A_ExtRetAnalysis, A_ExtRetAnalysis_InitialMktVal,
                                    selDynStTab[i], A_PtfSynth, A_PtfSynth_InitialMktVal);

                    COPY_DYNFLD(extRaTab[extRaIdx], A_ExtRetAnalysis, A_ExtRetAnalysis_FinalMktVal,
                                    selDynStTab[i], A_PtfSynth, A_PtfSynth_FinalMktVal);

                    /* REF9743 - LJE - 040218 */
                    COPY_DYNFLD(extRaTab[extRaIdx], A_ExtRetAnalysis, A_ExtRetAnalysis_Adjust,
                                    selDynStTab[i], A_PtfSynth, A_PtfSynth_NetAdj);

                    /* WEALTH-8023 - DDV - 240701 - Set mktSeg/port in/out ajust counters */
                    COPY_DYNFLD(extRaTab[extRaIdx], A_ExtRetAnalysis, A_ExtRetAnalysis_MktSegInAdjust, 
                                selDynStTab[i], A_PtfSynth, A_PtfSynth_MktSegInAdj);
                    COPY_DYNFLD(extRaTab[extRaIdx], A_ExtRetAnalysis, A_ExtRetAnalysis_MktSegOutAdjust,
                                selDynStTab[i], A_PtfSynth, A_PtfSynth_MktSegOutAdj);
                    COPY_DYNFLD(extRaTab[extRaIdx], A_ExtRetAnalysis, A_ExtRetAnalysis_PtfInAdjust,
                                selDynStTab[i], A_PtfSynth, A_PtfSynth_PtfInAdj);
                    COPY_DYNFLD(extRaTab[extRaIdx], A_ExtRetAnalysis, A_ExtRetAnalysis_PtfOutAdjust,
                                selDynStTab[i], A_PtfSynth, A_PtfSynth_PtfOutAdj);

                    COPY_DYNFLD(extRaTab[extRaIdx], A_ExtRetAnalysis, A_ExtRetAnalysis_Fees,
                                    selDynStTab[i], A_PtfSynth, A_PtfSynth_PtfFees);

                    COPY_DYNFLD(extRaTab[extRaIdx], A_ExtRetAnalysis, A_ExtRetAnalysis_Taxes,
                                    selDynStTab[i], A_PtfSynth, A_PtfSynth_PtfTax);

                    COPY_DYNFLD(extRaTab[extRaIdx], A_ExtRetAnalysis, A_ExtRetAnalysis_TaxCredit,
                                    selDynStTab[i], A_PtfSynth, A_PtfSynth_TaxCred);

                    COPY_DYNFLD(extRaTab[extRaIdx], A_ExtRetAnalysis, A_ExtRetAnalysis_PortSynthId,
                                    selDynStTab[i], A_PtfSynth, A_PtfSynth_Id);

					/* REF9125 - RAK - 030917 - Get PSP id */
					COPY_DYNFLD(extRaTab[extRaIdx], A_ExtRetAnalysis, A_ExtRetAnalysis_PerfStorParamId,
                                    selDynStTab[i], A_PtfSynth, A_PtfSynth_PSPId);
#if 0
                    /* PMSTA-42147 - lalby - 10022021*/
                    COPY_DYNFLD(extRaTab[extRaIdx], A_ExtRetAnalysis, A_ExtRetAnalysis_PerfTimRuleEn,
                                    selDynStTab[i], A_PtfSynth, A_PtfSynth_PerfTimRuleEn);
#endif
                    COPY_DYNFLD(extRaTab[extRaIdx], A_ExtRetAnalysis, A_ExtRetAnalysis_FirstOpNatEn,
                                    selDynStTab[i], A_PtfSynth, A_PtfSynth_FirstOpNatEn);
                    extRaIdx++;
                }
                /* insert data in StandardPerf - REF7395 - YST - 021023 */
				/* REF9125 - RAK - 031010 - Insert only if PSP_StdPerfDataFl is TRUE */
                else if (GET_FLAG(pspPtr, A_PerfStorageParam_StandardPerfDataFlg) == TRUE &&
						 IS_NULLFLD(selDynStTab[i], A_PtfSynth_InstrId) == TRUE &&
                         IS_NULLFLD(selDynStTab[i], A_PtfSynth_MktSegtId) == TRUE)
                {
                    stdPerfTab[extRaIdx] = mp.allocDynst(FILEINFO,A_StandardPerf);

                    DBA_CopyPspToStdPerf(pspPtr, stdPerfTab[extRaIdx]);

                    if (static_cast<PTFCONSRULE_ENUM>GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) == PtfConsRule_MergedTWR_Detail &&
                        GET_ID(stdPerfTab[extRaIdx], A_StandardPerf_ObjId) < 0) //dummy ptf
                    {
                        COPY_DYNFLD(stdPerfTab[extRaIdx], A_StandardPerf, A_StandardPerf_ObjId,
                            selDynStTab[i], A_PtfSynth, A_PtfSynth_ListId);
                        SET_DICT(stdPerfTab[extRaIdx], A_StandardPerf_EntDictId, dictIdForDummyCumulRecord);
                    }

                    COPY_DYNFLD(stdPerfTab[extRaIdx], A_StandardPerf, A_StandardPerf_InitialDate,
                                    selDynStTab[i], A_PtfSynth, A_PtfSynth_InitialDate);

                    COPY_DYNFLD(stdPerfTab[extRaIdx], A_StandardPerf, A_StandardPerf_FinalDate,
                                    selDynStTab[i], A_PtfSynth, A_PtfSynth_FinalDate);

                    COPY_DYNFLD(stdPerfTab[extRaIdx], A_StandardPerf, A_StandardPerf_InitialMktVal,
                                    selDynStTab[i], A_PtfSynth, A_PtfSynth_InitialMktVal);

                    COPY_DYNFLD(stdPerfTab[extRaIdx], A_StandardPerf, A_StandardPerf_FinalMktVal,
                                    selDynStTab[i], A_PtfSynth, A_PtfSynth_FinalMktVal);

                    COPY_DYNFLD(stdPerfTab[extRaIdx], A_StandardPerf, A_StandardPerf_Fees,
                                    selDynStTab[i], A_PtfSynth, A_PtfSynth_PtfFees);

                    COPY_DYNFLD(stdPerfTab[extRaIdx], A_StandardPerf, A_StandardPerf_Taxes,
                                    selDynStTab[i], A_PtfSynth, A_PtfSynth_PtfTax);

                    COPY_DYNFLD(stdPerfTab[extRaIdx], A_StandardPerf, A_StandardPerf_PortSynthId,
                                        selDynStTab[i], A_PtfSynth, A_PtfSynth_Id);

					/* REF9125 - RAK - 090317 - Get PSP id */
					COPY_DYNFLD(stdPerfTab[extRaIdx], A_StandardPerf, A_StandardPerf_PerfStorParamId,
                                        selDynStTab[i], A_PtfSynth, A_PtfSynth_PSPId);

                    extRaIdx++;
                }/* ExtRetAnalysis or StandardPerf data */
            }/* ptf synth data with SynthLevel_Gips */
        }/* ptf synth data to insert */
    }/* for */

    if (retCd == RET_SUCCEED && paIdx > 0)
    {
        /* memory allocation */
        if (paIdx < selDynStNbr)
        {
            paTab = (DBA_DYNFLD_STP *)mp.realloc(paTab, (paIdx)*sizeof(DBA_DYNFLD_STP));
        }

        if ((insPaExtRaStp->paTab) == (DBA_DYNFLD_STP *)NULL)
        {
            insPaExtRaStp->paNbr = 0;
            if (((insPaExtRaStp->paTab) = (DBA_DYNFLD_STP *)CALLOC(paIdx, sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR)
            {
                if (optimDVFlg == TRUE)
                {
                    DBA_FreeHierEltRecord(hierHead, A_PtfSynth);
                    retCd = DBA_AddHierRecordList(hierHead, fullDynStTab, fullDynStNbr, A_PtfSynth, FALSE);
                    DBA_SetDoNotDeleteRecFlag(hierHead, A_PtfSynth, FALSE);
                }
                MSG_RETURN(RET_MEM_ERR_ALLOC);
            }
        }
        else
        {
            if (((insPaExtRaStp->paTab) = (DBA_DYNFLD_STP *)REALLOC((insPaExtRaStp->paTab),
                                (insPaExtRaStp->paNbr+paIdx)*sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR)
            {
                if (optimDVFlg == TRUE)
                {
                    DBA_FreeHierEltRecord(hierHead, A_PtfSynth);
                    retCd = DBA_AddHierRecordList(hierHead, fullDynStTab, fullDynStNbr, A_PtfSynth, FALSE);
                    DBA_SetDoNotDeleteRecFlag(hierHead, A_PtfSynth, FALSE);
                }
                MSG_RETURN(RET_MEM_ERR_REALLOC);
            }
        }

        /* add PerfAttrib records to hierarchy */
        if ((retCd = DBA_AddHierRecordList(hierHead, paTab,
                                           paIdx, A_PerfAttrib, FALSE)) == RET_SUCCEED)
        {
            for (j=0; j<paIdx; j++)
                mp.removeDynStp(paTab[j]);  // remove from mempool

            /* Compute default values for PerfAttrib and copy PerfAttrib to insert structure */
            DBA_DYNFLD_STP mktSegtPAStp=NULL;
            FLAG_T         *scptFlagTab;
            int             synthPos;
            DATETIME_T      initDate, finalDate;

            /* Initialise common parts of flag array for default value evaluation */
            DBA_CommonScptFlagTabPa(scptFlagTabPa);

            scptFlagTabPa[A_PerfAttrib_InitialMktVal] = TRUE;
            scptFlagTabPa[A_PerfAttrib_FinalMktVal]   = TRUE; /* REF9743 - LJE - 040211 */
            scptFlagTabPa[A_PerfAttrib_Dura]          = TRUE; /* PMSTA08736 - LJE - 100623 */

            /* PMSTA08736 - LJE - 100624 - Compute DV only for weight factor */
            for (j=0; j<GET_FLD_NBR(A_PerfAttrib); j++)
                        scptFlagTabPaDura[j] = TRUE;
            scptFlagTabPaDura[A_PerfAttrib_WgtFactor] = FALSE;

            /* PMSTA08736 - LJE - 100623 - Sort perf_attrib to have global line in first by period */
            if (computeDuraFlg == TRUE)
            {
		        TLS_Sort((char *) paTab,
				         paIdx,
				         sizeof(DBA_DYNFLD_STP),
				         (TLS_CMPFCT *)DBA_CmpPerfAttribByDtMktSegt,
				         (PTR **) NULL,
				         SortRtnTp_None);
            }

            synthPos=0;
            initDate.date = 0;
            initDate.time = 0;

            for (i=0; i<paIdx; i++)
            {
                if (optimDVFlg == TRUE &&
                    DATETIME_CMP(initDate, GET_DATETIME(paTab[i], A_PerfAttrib_InitialDate)) != 0)
                {
                    int firstSynth=synthPos, nbrSynth=0;
                    DBA_FreeHierEltRecord(hierHead, A_PtfSynth);

                    initDate = GET_DATETIME(paTab[i], A_PerfAttrib_InitialDate);
                    finalDate = GET_DATETIME(paTab[i], A_PerfAttrib_FinalDate);

                    while (synthPos < pspDynStNbr &&
                           DATETIME_CMP(finalDate, GET_DATETIME(pspDynStTab[synthPos], A_PtfSynth_InitialDate)) > 0) /* WEALTH-12505 - DDV - 240902 - Change condition to get all PtfSynth in the period */
                    {
                        synthPos++;
                        nbrSynth++;
                    }
                    retCd = DBA_AddHierRecordList(hierHead, &(pspDynStTab[firstSynth]), nbrSynth, A_PtfSynth, FALSE);
                }

                scptFlagTab = scptFlagTabPa;

                if (computeDuraFlg == TRUE)
                {
                    if (IS_NULLFLD(paTab[i], A_PerfAttrib_InstrId) == TRUE)
                    {
                        mktSegtPAStp = paTab[i];
                        SET_NULL_NUMBER(mktSegtPAStp, A_PerfAttrib_Dura);
                    }
                    else if (insFilterEn == InsPaExtRaFilter_Grid)
                    {
                        scptFlagTab = scptFlagTabPaDura;
                    }
                }

		        SCPT_ComputeDV(PerfAttrib, scptFlagTab, paTab[i], TRUE, TRUE, NULL);

                if (IS_NULLFLD(paTab[i], A_PerfAttrib_WgtFactor) == TRUE)
                    SET_LONGAMOUNT(paTab[i], A_PerfAttrib_WgtFactor, 0.0); /* WEALTH-4573 - DDV - 240306 - Change to long amount */

				/* PMSTA07331 - LJE - 081031 */
                if (IS_NULLFLD(paTab[i], A_PerfAttrib_Wgt) == TRUE &&
					(IS_NULLFLD(paTab[i], A_PerfAttrib_InstrId)   == FALSE ||
					 IS_NULLFLD(paTab[i], A_PerfAttrib_MktSegtId) == FALSE))
                    SET_NUMBER(paTab[i], A_PerfAttrib_Wgt, 0.0);

                if (IS_NULLFLD(paTab[i], A_PerfAttrib_Rtn) == TRUE)
                    SET_NUMBER(paTab[i], A_PerfAttrib_Rtn, 0.0);

                /* REF9227 - LJE - 030918 */
                if (IS_NULLFLD(paTab[i], A_PerfAttrib_RtnCurr) == TRUE)
                    SET_NUMBER(paTab[i], A_PerfAttrib_RtnCurr, 0.0);

                (insPaExtRaStp->paTab)[insPaExtRaStp->paNbr++] = paTab[i];

                /* PMSTA08736 - LJE - 100623 */
                if (IS_NULLFLD(paTab[i], A_PerfAttrib_Dura) == FALSE)
                {
					/* PMSTA-13656 - LJE - 120207 - Avoid div by 0... */ /* WEALTH-4573 - DDV - 240306 - Change to long amount */
					LONGAMOUNT_T wgtFact        = GET_LONGAMOUNT(paTab[i], A_PerfAttrib_WgtFactor),
							     mktSegtWgtFact = GET_LONGAMOUNT(mktSegtPAStp, A_PerfAttrib_WgtFactor);

					if (CMP_NUMBER(mktSegtWgtFact, 0.0) != 0)
					{
						SET_NUMBER(mktSegtPAStp, A_PerfAttrib_Dura,
							GET_NUMBER(mktSegtPAStp, A_PerfAttrib_Dura) +
							((wgtFact / mktSegtWgtFact) * GET_NUMBER(paTab[i], A_PerfAttrib_Dura)));
					}
					else
					{
						SET_NULL_NUMBER(mktSegtPAStp, A_PerfAttrib_Dura);
					}

                    if (insFilterEn == InsPaExtRaFilter_Grid)
                    {
                        DBA_DelHierEltRec(hierHead, A_PerfAttrib, paTab[i]);
                        insPaExtRaStp->paNbr--;
                    }
                }
            }

            memset(&paFirstDate, 0, sizeof(DATETIME_T));
            memset(&paLastDate, 0, sizeof(DATETIME_T));
            paFirstDate = GET_DATETIME(paTab[gridFirstPaIdx], A_PerfAttrib_InitialDate);
            paLastDate = GET_DATETIME(paTab[paIdx-1], A_PerfAttrib_FinalDate);
            perfFlg = TRUE;
        }
    }

    if (retCd == RET_SUCCEED && extRaIdx > 0)
    {
        /* ExtRetAnalysis data - REF7395 - YST - 021023 */
		/* REF9125 - RAK - 031014  */
		if (GET_FLAG(pspPtr, A_PerfStorageParam_RetAnalysisFlg) == TRUE)
        {
            /* memory allocation */
            if (extRaIdx < selDynStNbr)
            {
                extRaTab = (DBA_DYNFLD_STP *)mp.realloc(extRaTab, (extRaIdx)*sizeof(DBA_DYNFLD_STP));
            }

            if ((insPaExtRaStp->extRaTab) == (DBA_DYNFLD_STP *)NULL)
            {
                insPaExtRaStp->extRaNbr = 0;
                if (((insPaExtRaStp->extRaTab) = (DBA_DYNFLD_STP *)CALLOC(extRaIdx, sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR)
                {
                    if (optimDVFlg == TRUE)
                    {
                        DBA_FreeHierEltRecord(hierHead, A_PtfSynth);
                        retCd = DBA_AddHierRecordList(hierHead, fullDynStTab, fullDynStNbr, A_PtfSynth, FALSE);
                        DBA_SetDoNotDeleteRecFlag(hierHead, A_PtfSynth, FALSE);
                    }
                    MSG_RETURN(RET_MEM_ERR_ALLOC);
                }
            }
            else
            {
                if (((insPaExtRaStp->extRaTab) = (DBA_DYNFLD_STP *)REALLOC((insPaExtRaStp->extRaTab),
                                    (insPaExtRaStp->extRaNbr+extRaIdx)*sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR)
                {                    
                    if (optimDVFlg == TRUE)
                    {
                        DBA_FreeHierEltRecord(hierHead, A_PtfSynth);
                        retCd = DBA_AddHierRecordList(hierHead, fullDynStTab, fullDynStNbr, A_PtfSynth, FALSE);
                        DBA_SetDoNotDeleteRecFlag(hierHead, A_PtfSynth, FALSE);
                    }
                    MSG_RETURN(RET_MEM_ERR_REALLOC);
                }
            }

            /* Add ExtRetAnalysis records to hierarchy */
			/* Compute default values for ExtRetAnalysis and copy ExtRetAnalysis to insert structure */
            if (extRaIdx > 0 &&
				(retCd = DBA_AddHierRecordList(hierHead, extRaTab,
                                                extRaIdx, A_ExtRetAnalysis, FALSE)) == RET_SUCCEED)
            {
                for (j=0; j<extRaIdx; j++)
                    mp.removeDynStp(extRaTab[j]);  // remove from mempool

                int synthPos;
                DATETIME_T initDate, finalDate;

                /* Initialise common parts of flag array for default value evaluation */
                DBA_CommonScptFlagTabExtRa(scptFlagTabExtRa);

                scptFlagTabExtRa[A_ExtRetAnalysis_MktSegtId]        = TRUE;
                scptFlagTabExtRa[A_ExtRetAnalysis_InstrId]          = TRUE;
                scptFlagTabExtRa[A_ExtRetAnalysis_InitialMktVal]    = TRUE;
                scptFlagTabExtRa[A_ExtRetAnalysis_FinalMktVal]      = TRUE;
                scptFlagTabExtRa[A_ExtRetAnalysis_Fees]             = TRUE;
                scptFlagTabExtRa[A_ExtRetAnalysis_Taxes]            = TRUE;
                scptFlagTabExtRa[A_ExtRetAnalysis_TaxCredit]        = TRUE;
                /* scptFlagTabExtRa[A_ExtRetAnalysis_DeltaNetGross]    = TRUE; * PMSTA07761 - LJE - 090511 - Remove hard coding */

                memset(&extRaFirstDate, 0, sizeof(DATETIME_T));
                memset(&extRaLastDate, 0, sizeof(DATETIME_T));
                extRaFirstDate = GET_DATETIME(extRaTab[gridFirstExtRaIdx], A_ExtRetAnalysis_InitialDate);
                extRaLastDate = GET_DATETIME(extRaTab[extRaIdx-1], A_ExtRetAnalysis_FinalDate);

				k = j = synthPos = 0;
                initDate.date = 0;
                initDate.time = 0;

				for (i=0; i<extRaIdx; i++)
				{
                    if (optimDVFlg == TRUE &&
                        DATETIME_CMP(initDate, GET_DATETIME(extRaTab[i], A_ExtRetAnalysis_InitialDate)) != 0)
                    {
                        int firstSynth=synthPos, nbrSynth=0;
                        DBA_FreeHierEltRecord(hierHead, A_PtfSynth);

                        initDate = GET_DATETIME(extRaTab[i], A_ExtRetAnalysis_InitialDate);
                        finalDate = GET_DATETIME(extRaTab[i], A_ExtRetAnalysis_FinalDate);

                        while (synthPos < pspDynStNbr &&
                               DATETIME_CMP(finalDate, GET_DATETIME(pspDynStTab[synthPos], A_PtfSynth_InitialDate)) > 0)/* WEALTH-12505 - DDV - 240902 - Change condition to get all PtfSynth in the period */
                        {
                            synthPos++;
                            nbrSynth++;
                        }
                        retCd = DBA_AddHierRecordList(hierHead, &(pspDynStTab[firstSynth]), nbrSynth, A_PtfSynth, FALSE);
                    }

					SCPT_ComputeDV(ExtRetAnalysis, scptFlagTabExtRa, extRaTab[i], TRUE, TRUE, NULL);

					/* REF9125 - RAK - 031014 - create StandardPerf only if PSP_StdPerfDataFlg asked it */
					if (GET_FLAG(pspPtr, A_PerfStorageParam_StandardPerfDataFlg) == TRUE)
					{
						/* Test if fields of ret analysis global table are different NULL */
						if (insFilterEn == InsPaExtRaFilter_Global)
						{
							if ((retCd = DBA_TestRaGlobalData(hierHead, extRaTab[i], stdPerfTab, insPaExtRaStp,
                                                            &stdPerfIdx, &tmpStdPerfFlg)) != RET_SUCCEED)
							{
								break;
							}
						}

						if (tmpStdPerfFlg != TRUE)
						{
							/* REF9055 - LJE - 030509 */
							DBA_PrepareSPForAddInHier(hierHead, extRaTab[i], stdPerfTab, insPaExtRaStp, &stdPerfIdx);


							(insPaExtRaStp->extRaTab)[insPaExtRaStp->extRaNbr+j] = extRaTab[i];
							j++;
							retFlg = TRUE;
						}
						else
						{
							stdPerfFlg = TRUE;
						}
					}
                }

                if (retCd == RET_SUCCEED)
                {
                    insPaExtRaStp->extRaNbr += j;

                    if (stdPerfIdx > 0) /* REF9055 - LJE - 030509 : (stdPerfFlg == TRUE) */
                    {
                        if((retCd = DBA_AddHierRecordList(hierHead, stdPerfTab,
                                                      stdPerfIdx, A_StandardPerf, FALSE)) == RET_SUCCEED)
                        {
                            for (j=0; j<stdPerfIdx; j++)
                                mp.removeDynStp(stdPerfTab[j]);  // remove from mempool
                        }
                    }
                }
            }
        } /* A_PerfStorageParam_RetAnalysisFlg == TRUE */
		/* REF9125 - RAK - 031014 - supprime une fin d'accolade ... elle �tait mal plac�e suite � une de mes modifs je pense */
        /* StandardPerf data - REF7395 - YST - 021023 */
        else
        {
            stdPerfIdx = extRaIdx;
            /* memory allocation */
            if (stdPerfIdx < selDynStNbr)
            {
                stdPerfTab = (DBA_DYNFLD_STP *)mp.realloc(stdPerfTab, (stdPerfIdx)*sizeof(DBA_DYNFLD_STP));
            }

            if ((insPaExtRaStp->stdPerfTab) == (DBA_DYNFLD_STP *)NULL)
            {
                insPaExtRaStp->stdPerfNbr = 0;
                if (((insPaExtRaStp->stdPerfTab) = (DBA_DYNFLD_STP *)CALLOC(stdPerfIdx, sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR)
                {                    
                    if (optimDVFlg == TRUE)
                    {
                        DBA_FreeHierEltRecord(hierHead, A_PtfSynth);
                        retCd = DBA_AddHierRecordList(hierHead, fullDynStTab, fullDynStNbr, A_PtfSynth, FALSE);
                        DBA_SetDoNotDeleteRecFlag(hierHead, A_PtfSynth, FALSE);
                    }
                    MSG_RETURN(RET_MEM_ERR_ALLOC);
                }
            }
            else
            {
                if (((insPaExtRaStp->stdPerfTab) = (DBA_DYNFLD_STP *)REALLOC((insPaExtRaStp->stdPerfTab),
                                    (insPaExtRaStp->stdPerfNbr+stdPerfIdx)*sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR)
                {                    
                    if (optimDVFlg == TRUE)
                    {
                        DBA_FreeHierEltRecord(hierHead, A_PtfSynth);
                        retCd = DBA_AddHierRecordList(hierHead, fullDynStTab, fullDynStNbr, A_PtfSynth, FALSE);
                        DBA_SetDoNotDeleteRecFlag(hierHead, A_PtfSynth, FALSE);
                    }
                    MSG_RETURN(RET_MEM_ERR_REALLOC);
                }
            }
            /* Add StandardPerf records to hierarchy */
			/* Compute default values for StandardPerf and copy StandardPerf to insert structure */
            if (stdPerfIdx > 0 &&
				(retCd = DBA_AddHierRecordList(hierHead, stdPerfTab,
                                                stdPerfIdx, A_StandardPerf, FALSE)) == RET_SUCCEED)
            {
                for (j=0; j<stdPerfIdx; j++)
                                mp.removeDynStp(stdPerfTab[j]);  // remove from mempool

                int             synthPos;
                DATETIME_T      initDate, finalDate;

                /* Initialise common parts of flag array for default value evaluation */
                DBA_CommonScptFlagTabStdPerf(scptFlagTabExtRa);

                scptFlagTabExtRa[A_StandardPerf_InitialMktVal]    = TRUE;
                scptFlagTabExtRa[A_StandardPerf_FinalMktVal]      = TRUE;
                scptFlagTabExtRa[A_StandardPerf_Fees]             = TRUE;
                scptFlagTabExtRa[A_StandardPerf_Taxes]            = TRUE;

                synthPos=0;
                initDate.date = 0;
                initDate.time = 0;

                for (i=0; i<stdPerfIdx; i++)
                {
                    if (optimDVFlg == TRUE &&
                        DATETIME_CMP(initDate, GET_DATETIME(stdPerfTab[i], A_StandardPerf_InitialDate)) != 0)
                    {
                        int firstSynth=synthPos, nbrSynth=0;
                        DBA_FreeHierEltRecord(hierHead, A_PtfSynth);

                        initDate = GET_DATETIME(stdPerfTab[i], A_StandardPerf_InitialDate);
                        finalDate = GET_DATETIME(stdPerfTab[i], A_StandardPerf_FinalDate);

                        while (synthPos < pspDynStNbr &&
                               DATETIME_CMP(finalDate, GET_DATETIME(pspDynStTab[synthPos], A_PtfSynth_InitialDate)) > 0)/* WEALTH-12505 - DDV - 240902 - Change condition to get all PtfSynth in the period */
                        {
                            synthPos++;
                            nbrSynth++;
                        }
                        retCd = DBA_AddHierRecordList(hierHead, &(pspDynStTab[firstSynth]), nbrSynth, A_PtfSynth, FALSE);
                    }

                    SCPT_ComputeDV(StandardPerf, scptFlagTabExtRa, stdPerfTab[i], TRUE, TRUE, NULL);

                    (insPaExtRaStp->stdPerfTab)[insPaExtRaStp->stdPerfNbr+i] = stdPerfTab[i];
                }
                insPaExtRaStp->stdPerfNbr += stdPerfIdx;

                memset(&extRaFirstDate, 0, sizeof(DATETIME_T));
                memset(&extRaLastDate, 0, sizeof(DATETIME_T));
                extRaFirstDate = GET_DATETIME(stdPerfTab[gridFirstExtRaIdx], A_StandardPerf_InitialDate);
                extRaLastDate = GET_DATETIME(stdPerfTab[stdPerfIdx-1], A_StandardPerf_FinalDate);
                stdPerfFlg = TRUE;
            }
        }
	} /* REF9125 - RAK - 031014 - fin d'accolade d�plac�e ici ! */

    /* REF10276 - LJE - 040512 */
    DBA_HierOneIndexNoUpdate(hierHead,
                             A_PtfSynth,
                             A_PtfSynth_MktSegtId);

    /* REF11193 - LJE - 051201 */
    DBA_HierOneIndexNoUpdate(hierHead,
                             A_PtfSynth,
                             A_PtfSynth_InstrId);
    /* PMSTA-55377 - Deepthi - 240117 */
    for (int idx = 0; idx < pspDynStNbr; idx++)
    {
        FREE_EXTENSION(pspDynStTab[idx], A_PtfSynth_GblPtfSynth_Ext);
    }

    DBA_SetHierLnkUnused(hierHead, A_PtfSynth, A_PtfSynth_GblPtfSynth_Ext);

    if (optimDVFlg == TRUE)
    {
        DBA_FreeHierEltRecord(hierHead, A_PtfSynth);
        retCd = DBA_AddHierRecordList(hierHead, fullDynStTab, fullDynStNbr, A_PtfSynth, FALSE);
        DBA_SetDoNotDeleteRecFlag(hierHead, A_PtfSynth, FALSE);
    }

	int PerfCalcResNbr = 0;
	DBA_DYNFLD_STP *PerfCalcResTab = NULLDYNSTPTR;
	if (DBA_ExtractHierEltRecWithFilterSt(hierHead, A_PerfCalcResult, FALSE,
			DBA_FilterPerfCalcResultPSPwithPtf, pspPtr, NULL,
			&PerfCalcResNbr, &PerfCalcResTab) == RET_SUCCEED)
	{
        mp.ownerPtr(PerfCalcResTab);
        /*PMSTA-54527 - SENTHIL - 231011*/
        TLS_Sort((char*)PerfCalcResTab,
            PerfCalcResNbr,
            sizeof(DBA_DYNFLD_STP),
            (TLS_CMPFCT*)DBA_CmpPerfCalcResultByDt,
            (PTR**)NULL,
            SortRtnTp_None);

		if (insPaExtRaStp != nullptr && PerfCalcResNbr > 0)
		{
			if ((insPaExtRaStp->PerfCalcResTab) == (DBA_DYNFLD_STP *)NULL)
			{
				insPaExtRaStp->PerfCalcResNbr = 0;
				(insPaExtRaStp->PerfCalcResTab) = (DBA_DYNFLD_STP *)CALLOC(PerfCalcResNbr, sizeof(DBA_DYNFLD_STP));
			}
			else
			{
				(insPaExtRaStp->PerfCalcResTab) = (DBA_DYNFLD_STP *)REALLOC((insPaExtRaStp->PerfCalcResTab),
					(insPaExtRaStp->PerfCalcResNbr + PerfCalcResNbr) * sizeof(DBA_DYNFLD_STP));
			}
			for (i = 0; i < PerfCalcResNbr; i++)
			{
				perfcalcresFlg = TRUE;
				(insPaExtRaStp->PerfCalcResTab)[insPaExtRaStp->PerfCalcResNbr + i] = PerfCalcResTab[i];
			}
			insPaExtRaStp->PerfCalcResNbr += PerfCalcResNbr;
			pcrFirstDate = GET_DATETIME(PerfCalcResTab[gridFirstExtRaIdx], A_PerfCalcResult_InitialDate);
			pcrLastDate = GET_DATETIME(PerfCalcResTab[PerfCalcResNbr - 1], A_PerfCalcResult_FinalDate);
		}

	}

    /* Prepare insert structure for update PSP, delete PerfAttrib and ExtRetAnalysis
        delete event scheduler and update portfolio, except for compute online */
    if (retCd == RET_SUCCEED && (COMPDATA_ENUM)GET_ENUM(domainPtr, A_Domain_CompDataEn) != CompData_OnLine) /* REF7758 - YST - 021106 */
    {
        if (stdPerfFlg == FALSE && retFlg == FALSE && perfFlg == FALSE)
        {
            if (GET_FLAG(pspPtr, A_PerfStorageParam_RetAnalysisFlg) == TRUE)
            {
                retFlg = TRUE;
            }
            else if (GET_FLAG(pspPtr, A_PerfStorageParam_StandardPerfDataFlg) == TRUE)
            {
                stdPerfFlg = TRUE;
            }
            if (GET_FLAG(pspPtr, A_PerfStorageParam_PerfAttribFlg) == TRUE)
            {
                perfFlg = TRUE;
            }
        }

		if (stdPerfFlg != TRUE)
        {
            retCd = DBA_UpdPspDelPaExtRaStdP(domainPtr, pspPtr, stdPerfFlg, extRaFirstDate, extRaLastDate,
                                            retFlg, extRaFirstDate, extRaLastDate,
                                            perfFlg, paFirstDate, paLastDate,
				                            perfcalcresFlg, pcrFirstDate, pcrLastDate,
                                            delFromDate, delTillDate, insPaExtRaStp);
        }
        else
        {
            retCd = DBA_UpdPspDelPaExtRaStdP(domainPtr, pspPtr, stdPerfFlg, extRaFirstDate, extRaLastDate,
                                            retFlg, nullDateTime, nullDateTime,
                                            perfFlg, paFirstDate, paLastDate,
				                            perfcalcresFlg, pcrFirstDate, pcrLastDate,
                                            delFromDate, delTillDate, insPaExtRaStp);
        }

        if (retCd == RET_SUCCEED)
        {
			/* PMSTA02013 - RAK - 071112 create a sub-fuction for event scheduler delete and Ptf LastFinalDate */
			if ((retCd = DBA_UpdPtfPerfLastFinalDateAndEventSched(hierHead, ptfPtr, pspPtr,
																  nullDateTime, delEventSchedFlg, insPaExtRaStp)) != RET_SUCCEED)
			{
				return(retCd);
			}

        }
	}

    return(retCd);
}

/************************************************************************
**
**  Function    :   DBA_UpdPtfPerfLastFinalDateAndEventSched()
**
**  Description :

**  Arguments   :   input:
**                  ptfPtr              pointer on portfolio
**                  delFromDate         date from which data must be deleted
**                  delTillDate         date until which data must be deleted
**                  delEventSchedFlg    flag indicating, if delete of event scheduler
**
**                  output:
**                  insPaExtRaStp       pointer on data to insert, update or delete
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   PMSTA02013 - RAK - 071112
**
*************************************************************************/
STATIC RET_CODE DBA_UpdPtfPerfLastFinalDateAndEventSched(DBA_HIER_HEAD_STP	 hierHead,
														 DBA_DYNFLD_STP      ptfPtr,
														 DBA_DYNFLD_STP      pspPtr,
                                                         DATETIME_T			 perfLastFinalDate,
														 FLAG_T              delEventSchedFlg,
														 DBA_INSPAEXTRA_STP  insPaExtRaStp)
{
    RET_CODE retCode     = RET_SUCCEED;
    bool     bPtfUpd     = false;
    int      allocAccess = 0, i;
    DBA_DYNFLD_STP *childrenPtfTab;

    if (pspPtr != NULL)
    {
        if (IS_NULLFLD(pspPtr, A_PerfStorageParam_StdPerfLastStoredDate) == TRUE &&
            IS_NULLFLD(ptfPtr, A_Ptf_PerfLastFinalDate) == FALSE)
        {
            bPtfUpd = true;
            perfLastFinalDate.date = 0;
            perfLastFinalDate.time = 0;
        }
        else if ((IS_NULLFLD(ptfPtr, A_Ptf_PerfLastFinalDate) == TRUE && IS_NULLFLD(pspPtr, A_PerfStorageParam_StdPerfLastStoredDate) == FALSE) ||
                 CMP_DYNFLD(pspPtr, ptfPtr, A_PerfStorageParam_StdPerfLastStoredDate, A_Ptf_PerfLastFinalDate, DatetimeType) > 0)
        {
            bPtfUpd = true;
            perfLastFinalDate = GET_DATETIME(pspPtr, A_PerfStorageParam_StdPerfLastStoredDate);
        }
        else
        {
            perfLastFinalDate = GET_DATETIME(ptfPtr, A_Ptf_PerfLastFinalDate);
        }
    }
    else if ((perfLastFinalDate.date == 0 && IS_NULLFLD(ptfPtr, A_Ptf_PerfLastFinalDate) == FALSE) ||
             perfLastFinalDate.date > GET_DATETIME(ptfPtr, A_Ptf_PerfLastFinalDate).date)
    {
        bPtfUpd = true;
    }

    if (bPtfUpd)
    {
        if (IS_NULLFLD(ptfPtr, A_Ptf_MaxFilterPerfLastStoredDate) == FALSE &&
            GET_DATETIME(ptfPtr, A_Ptf_MaxFilterPerfLastStoredDate).date != MAGIC_END_DATE &&
            GET_DATETIME(ptfPtr, A_Ptf_MaxFilterPerfLastStoredDate).date > perfLastFinalDate.date)
        {
            perfLastFinalDate = GET_DATETIME(ptfPtr, A_Ptf_MaxFilterPerfLastStoredDate);
        }

        if (perfLastFinalDate.date == 0)
        {
            SET_NULL_DATETIME(ptfPtr, A_Ptf_PerfLastFinalDate);
        }
        else
        {
            SET_DATETIME(ptfPtr, A_Ptf_PerfLastFinalDate, perfLastFinalDate);
        }
        allocAccess++;
    }
	if (delEventSchedFlg == TRUE)
	{
        allocAccess++;
	}


    if (allocAccess)
    {
        if ((insPaExtRaStp->accessStp) == (DBA_ACCESS_STP)NULL)
        {
             insPaExtRaStp->accessNbr = 0;
             if (((insPaExtRaStp->accessStp) = (DBA_ACCESS_STP)
                CALLOC(allocAccess, sizeof(DBA_ACCESS_ST))) == (DBA_ACCESS_STP)NULL)
            {
                MSG_RETURN(RET_MEM_ERR_ALLOC);
            }
        }
        else
        {
            if (((insPaExtRaStp->accessStp) = SYS_ReallocInit((insPaExtRaStp->accessStp),
                (size_t) insPaExtRaStp->accessNbr, (size_t) allocAccess)) == NULL)
            {
                MSG_RETURN(RET_MEM_ERR_REALLOC);
            }
        }

        /* If an event scheduler exist, delete it in database */
	    if (delEventSchedFlg == TRUE && pspPtr != NULL)
	    {
            DBA_DYNFLD_STP  aPsp = NULLDYNST;

	  	    if ((aPsp = ALLOC_DYNST(A_PerfStorageParam)) == NULLDYNST)
		    {
                MSG_RETURN(RET_MEM_ERR_ALLOC);
            }
            else
            {
                SET_ID(aPsp, A_PerfStorageParam_Id, GET_ID(pspPtr, A_PerfStorageParam_Id));

	            insPaExtRaStp->accessStp[insPaExtRaStp->accessNbr].action = Delete;
	            insPaExtRaStp->accessStp[insPaExtRaStp->accessNbr].role   = UNUSED;
	            insPaExtRaStp->accessStp[insPaExtRaStp->accessNbr].object = EventSched;

                insPaExtRaStp->accessStp[insPaExtRaStp->accessNbr].entity = A_PerfStorageParam;	/* PMSTA00821 - RAK - 070314 */
	            insPaExtRaStp->accessStp[insPaExtRaStp->accessNbr].data   = aPsp;
	            insPaExtRaStp->accessNbr++;
			}
	    }

        if (bPtfUpd)
            {
	        insPaExtRaStp->accessStp[insPaExtRaStp->accessNbr].action = Update;
	        insPaExtRaStp->accessStp[insPaExtRaStp->accessNbr].role   = DBA_ROLE_PERF_ATTRIB_RA;
	        insPaExtRaStp->accessStp[insPaExtRaStp->accessNbr].object = Ptf;
	        insPaExtRaStp->accessStp[insPaExtRaStp->accessNbr].entity = A_Ptf;

            /* REF10693 - LJE - 041014 */
            insPaExtRaStp->accessStp[insPaExtRaStp->accessNbr].data = ALLOC_DYNST(A_Ptf);
            COPY_DYNST(insPaExtRaStp->accessStp[insPaExtRaStp->accessNbr].data, ptfPtr, A_Ptf);

	        insPaExtRaStp->accessNbr++;
        }
	}

    /* PMSTA02013 - RAK - 071112 - and call it on each children in case of hierarchical PSP*/
    if (pspPtr != NULL &&
        GET_ENUM(pspPtr, A_PerfStorageParam_PerfAttribReturnEn) == PerfAttribRtnEn_Hierarchy &&
        (childrenPtfTab = (DBA_DYNFLD_STP *)GET_EXTENSION_PTR(ptfPtr, A_Ptf_HierChildrenPtf_Ext)) != NULL)
    {
        /* for all children */
        for (i = 0; i < GET_EXTENSION_NBR(ptfPtr, A_Ptf_HierChildrenPtf_Ext); i++)
        {
            if ((retCode = DBA_UpdPtfPerfLastFinalDateAndEventSched(hierHead, childrenPtfTab[i], NULL, perfLastFinalDate, FALSE, insPaExtRaStp)) != RET_SUCCEED)
            {
                return(retCode);
        }
        }
	}

    return(retCode);
}
/************************************************************************
**
**  Function    :   DBA_InsPtfFreqDataPrep()
**
**  Description :   Prepares insert of data in database computed by portfolio storage
**                  with a list of portfolios with consolidation rule merged.
**                  Function is called ones after computation of data.
**                  The structure pointer DBA_INSPAEXTRA_STP is filled with
**                  the following data:
**
**                  stdPerfTab:
**                  portfolio frequencies for insert
**
**                  For each period a portfolio in the list generates one ptf freq.
**                  In stdPerfTab only one entry is stored for a period.
**                  The entry has the business keys entity = list and object id = list id.
**                  In addition A_StandardPerf_PtfFreqId = min(A_PtfFreq_Id) for the given period.
**
**                  accessStp:
**                  structure pointer for multiaccess
**                  - StandardPerf for delete between delFromDate and delTillDate
**                  - PerfStorageParam (PSP) for update
**
**
**  Arguments   :   input:
**                  domainPtr           domain structure pointer
**                  hierHead            hierarchy header pointer
**                  listPtr             pointer on list of portfolios
**                  delFromDate         date from which data must be deleted
**                  delTillDate         date until which data must be deleted
**
**                  output:
**                  insPaExtRaStp       pointer on data to insert, update or delete
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   REF7421 - YST - 021007
**  Modification:   REF7422 - YST - 021115
**  modification:   REF9125 - MCA - 030905
**
*************************************************************************/
RET_CODE DBA_InsPtfFreqDataPrep(DBA_DYNFLD_STP     domainPtr , /* PMSTA-64818 - Deepthi - 20250210 */
                                DBA_HIER_HEAD_STP   hierHead,
                                DBA_DYNFLD_STP      ,
                                DBA_DYNFLD_STP      pspPtr, /*REF9125 - MCA - 030905*/
                                DATETIME_T          delFromDate,
                                DATETIME_T          delTillDate,
                                DBA_INSPAEXTRA_STP  insPaExtRaStp)
{
    RET_CODE            retCd = RET_SUCCEED;
    DBA_DYNFLD_STP      *selDynStTab = NULLDYNSTPTR, *stdPerfTab = NULLDYNSTPTR;
    DATETIME_T          nullDateTime, initialDate, stdPerfFirstDate, stdPerfLastDate;
    DICT_T              entDictId;
    FLAG_T              *scptFlagTabStdPerf;
    int                 i = 0, j = 0, selDynStNbr = 0, stdPerfIdx = 0;

	if (pspPtr == NULLDYNST)
	{
		MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
	                 "DBA_InsPtfFreqDataPrep", "no PSP received");
		return(RET_GEN_ERR_INVARG);
	}

	/* Extract all instrument frequencies for the given instrument, sorted by initial date */
    if ((retCd = DBA_ExtractHierEltRecWithFilterSt(hierHead, A_PtfFreq, FALSE,
                                                   NULLFCT/*DBA_FilterPtfFreq*/, NULLDYNST,  DBA_CmpPtfFreqInitialDate,
									               &selDynStNbr, &selDynStTab)) != RET_SUCCEED || selDynStNbr == 0)
	{
        FREE(selDynStTab);
		return(retCd);
	}

    /* memory allocation */
    memset(&nullDateTime, 0, sizeof(DATETIME_T));
    memset(&initialDate, 0, sizeof(DATETIME_T));
    memset(&stdPerfFirstDate, 0, sizeof(DATETIME_T));
    memset(&stdPerfLastDate, 0, sizeof(DATETIME_T));

    if ((scptFlagTabStdPerf = (FLAG_T *) CALLOC(GET_FLD_NBR(A_StandardPerf), sizeof(FLAG_T))) == NULL)
    {
        FREE(selDynStTab);
		MSG_RETURN(RET_MEM_ERR_ALLOC);
    }
    if ((stdPerfTab = (DBA_DYNFLD_STP *)CALLOC(selDynStNbr, sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR)
    {
        FREE(selDynStTab);
        FREE(scptFlagTabStdPerf);
		MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    DBA_GetDictId(List, &entDictId);

    for (i=0; i<selDynStNbr && retCd == RET_SUCCEED; i++)
    {
        if (DATETIME_CMP(initialDate, GET_DATETIME(selDynStTab[i], A_PtfFreq_InitialDate)) < 0)
        {
            initialDate = GET_DATETIME(selDynStTab[i], A_PtfFreq_InitialDate);

            if ((stdPerfTab[stdPerfIdx] = ALLOC_DYNST(A_StandardPerf)) == NULLDYNST)
            {
                FREE(stdPerfTab);
                FREE(selDynStTab);
                FREE(scptFlagTabStdPerf);
                MSG_RETURN(RET_MEM_ERR_ALLOC);
            }
            else
            {
                DBA_CopyPspToStdPerf(pspPtr, stdPerfTab[stdPerfIdx]);

                COPY_DYNFLD(stdPerfTab[stdPerfIdx], A_StandardPerf, A_StandardPerf_InitialDate,
                                            selDynStTab[i], A_PtfFreq, A_PtfFreq_InitialDate);

                COPY_DYNFLD(stdPerfTab[stdPerfIdx], A_StandardPerf, A_StandardPerf_FinalDate,
                                            selDynStTab[i], A_PtfFreq, A_PtfFreq_FreqDate);

                COPY_DYNFLD(stdPerfTab[stdPerfIdx], A_StandardPerf, A_StandardPerf_PtfFreqId,
                                            selDynStTab[i], A_PtfFreq, A_PtfFreq_Id);

                stdPerfIdx++;
            }
        }
    }
    /* just for security */
    if (stdPerfIdx == 0)
    {
        retCd = RET_GEN_INFO_NODATA;
    }

    if (retCd == RET_SUCCEED)
    {
        /* memory allocation */
        if (stdPerfIdx < selDynStNbr)
        {
            if ((stdPerfTab = (DBA_DYNFLD_STP *)REALLOC(stdPerfTab, (stdPerfIdx)*sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR)
            {
                for (j=0; j<stdPerfIdx; j++)
                    FREE_DYNST(stdPerfTab[j], A_StandardPerf);

                FREE(stdPerfTab);
                FREE(selDynStTab);
                FREE(scptFlagTabStdPerf);
                MSG_RETURN(RET_MEM_ERR_REALLOC);
            }
        }

        insPaExtRaStp->stdPerfNbr = 0;
        if (((insPaExtRaStp->stdPerfTab) = (DBA_DYNFLD_STP *)CALLOC(stdPerfIdx, sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR)
        {
            for (j=0; j<stdPerfIdx; j++)
                FREE_DYNST(stdPerfTab[j], A_StandardPerf);

            FREE(stdPerfTab);
            FREE(selDynStTab);
            FREE(scptFlagTabStdPerf);
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        /* Add StandardPerf records to hierarchy */
        if ((retCd = DBA_AddHierRecordList(hierHead, stdPerfTab,
                                            stdPerfIdx, A_StandardPerf, FALSE)) != RET_SUCCEED)
        {
			MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
	                 "DBA_InsPtfFreqDataPrep", "no StandardPerf added");
        }
        /* Compute default values for StandardPerf and copy StandardPerf to insert structure */
        else
        {
            /* Initialise common parts of flag array for default value evaluation */
            DBA_CommonScptFlagTabStdPerf(scptFlagTabStdPerf);

            for (i=0; i<stdPerfIdx; i++)
            {
	            SCPT_ComputeDV(StandardPerf, scptFlagTabStdPerf, stdPerfTab[i], TRUE, TRUE, NULL);

                (insPaExtRaStp->stdPerfTab)[insPaExtRaStp->stdPerfNbr+i] = stdPerfTab[i];
            }
            insPaExtRaStp->stdPerfNbr += stdPerfIdx;

            /* Delete StandardPerf data of entity ptf only used for default value evaluation - REF7423 - YST - 021104 */
            if ((retCd = DBA_DelAndFreeHierEltRecWithFilter(hierHead,
														    A_StandardPerf,
													        DBA_FilterStdPerfPtfFreq,
															NULLDYNST, NULL)) != RET_SUCCEED)
            {
				MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
	                 "DBA_InsPtfFreqDataPrep", "Delete StandardPerf data ");
            }
            else
            {
                stdPerfFirstDate = GET_DATETIME(stdPerfTab[0], A_StandardPerf_InitialDate);
                stdPerfLastDate = GET_DATETIME(stdPerfTab[stdPerfIdx-1], A_StandardPerf_FinalDate);

                /* Prepare insert structure for update PSP and delete StandardPerf */
                if ((retCd = DBA_UpdPspDelPaExtRaStdP(domainPtr, pspPtr, TRUE, stdPerfFirstDate, stdPerfLastDate,
                                                      FALSE, nullDateTime, nullDateTime,
                                                      FALSE, nullDateTime, nullDateTime,
					                                  FALSE, nullDateTime, nullDateTime,
                                                      delFromDate, delTillDate, insPaExtRaStp)) != RET_SUCCEED)
                {
					MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
								 "DBA_InsPtfFreqDataPrep", "no update PSP ");
				}
            }
        }
    }

    FREE(stdPerfTab);
    FREE(selDynStTab);
    FREE(scptFlagTabStdPerf);

    return(retCd);
}

/************************************************************************
**
**  Function    :   DBA_CheckIfAttributUsedInScpt
**
**  Description :

**  Arguments   :
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :
**
*************************************************************************/
STATIC FLAG_T DBA_CheckIfAttributUsedInScpt(DBA_HIER_HEAD_STP hierHead,
                                            DBA_DYNFLD_STP    domainPtr,
                                            OBJECT_ENUM       object,
                                            const char       *attribName,
                                            FLAG_T            *flags,
                                            int               *connPtr)
{
    FILTER_STP          filterTab=NULL;
   	int		            depCplNb, i;
    SCPT_DFLTVALCPL_STP depCplTab;
    DICT_ATTRIB_STP     dictAttribStp;
    DBA_DYNFLD_STP      record=NULL;
  	int				    fldNbr = GET_FLD_NBR(GET_EDITGUIST(object));

    if ((filterTab = (FILTER_STP)CALLOC(fldNbr,sizeof(FILTER_ST))) == NULL ||
        (record = ALLOC_DYNST(GET_EDITGUIST(object))) == NULL ||
        SCPT_ComputeScreenDV(object,
                            DictFct_0,
                            flags,
                            NULL,              /* HFI-PMSTA-25327-171023  Dedicated flag tab for filter    */
                            record,
                            NULL,
                            domainPtr,
                            NULLDYNST,   /* PMSTA13283 - DDV - 120117 */
                            TRUE,
                            TRUE,
                            EvalType_DefValDependList,
                            -1,
                            connPtr,
                            filterTab,
                            hierHead,
                            0,
                            NullEntity,
                            NULL,
                            NULL,
                            NULL,
                            NULL,
                            NULL,
                            NullEntity,
                            FALSE,
                            FALSE,
                            0) ||
        (dictAttribStp = DBA_GetAttributeBySqlName(object, attribName)) == NULL ||
        dictAttribStp == NULL ||
        filterTab == NULL)
    {
        FREE(filterTab);
        FREE_DYNST(record, GET_EDITGUIST(object));
        return TRUE;
    }
    FREE_DYNST(record, GET_EDITGUIST(object));

    depCplNb  = filterTab[0].depCplNb;
    depCplTab = (SCPT_DFLTVALCPL_STP)filterTab[0].depCplTab;

    for (i=0 ; i<depCplNb ; i++)
    {
        if (depCplTab[i].fldMain == dictAttribStp->progN)
            return TRUE;
    }

	FREE(depCplTab); /* PMSTA14453 - DDV - 120712 - Purify */
    FREE(filterTab);
    return FALSE;
}

/************************************************************************
**
**  Function    :   DBA_InsStratSynthDataPrep()
**
**  Description :   Prepares insert of data in database computed by benchmark storage.
**                  Function is called for each strategy after computation of data.
**                  The structure pointer DBA_INSPAEXTRA_STP is filled with
**                  the following data:
**
**                  paTab:
**                  extended strategy elements with A_StratSynth_Level = 0 for insert
**
**                  extRaTab:
**                  extended strategy elements with A_StratSynth_Level != 0 for insert
**
**                  accessStp:
**                  structure pointer for multiaccess
**                  - PerfAttrib and StandardPerf for delete between
**                    delFromDate and delTillDate
**                  - PSP for update
**
**
**  Arguments   :   input:
**                  domainPtr           domain structure pointer
**                  hierHead            hierarchy header pointer
**                  stratPtr            pointer on strategy
**                  delFromDate         date from which data must be deleted
**                  delTillDate         date until which data must be deleted
**
**                  output:
**                  insPaExtRaStp       pointer on data to insert, update or delete
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   REF7421 - YST - 020719
**  modification:   REF9125 - MCA - 030905
**                  PMSTA08736 - LJE - 100125
**
*************************************************************************/
RET_CODE DBA_InsStratSynthDataPrep(DBA_DYNFLD_STP      domainPtr,
								   DBA_HIER_HEAD_STP   hierHead,
								   DBA_HIER_HEAD_STP   dstHierHead, /* PMSTA08736 - LJE - 100412 */
								   DBA_DYNFLD_STP      ,
								   DBA_DYNFLD_STP      pspPtr, /*REF9125 - MCA - 030905*/
								   DATETIME_T          delFromDate,
								   DATETIME_T          delTillDate,
								   DBA_INSPAEXTRA_STP  insPaExtRaStp)
{
    RET_CODE                retCd = RET_SUCCEED;
    DBA_DYNFLD_STP          *selStratSynthTab = NULLDYNSTPTR, *paTab = NULLDYNSTPTR, *stdPerfTab = NULLDYNSTPTR, eseStp;
    DATETIME_T              paFirstDate, paLastDate, stdPerfFirstDate, stdPerfLastDate, nullDateTime;
    DICT_T                  entDictId;
    MASK_T                  subPeriodMask=0;
    FLAG_T                  *scptFlagTabPa, *scptFlagTabStdPerf, instrLevelFlg = FALSE,
                            stdPerfFlg = FALSE, perfFlg = FALSE,
                            createESEFlg; /* PMSTA-10748 - LJE - 110208 */
    INSPAEXTRAFILTER_ENUM   insFilterEn = InsPaExtRaFilter_Instr;
    int                     i = 0, j = 0, selStratSynthNbr = 0, paIdx = 0, stdPerfIdx = 0;

    PA_LICENSEE_ENUM		paLicenseEn = PALicensee_No; /* REF11584 - LJE - 060306 */

	GEN_GetApplInfo(ApplPALicense, &paLicenseEn);

	/* REF9125 - RAK - 031010 - we need to receive the pspPtr */
	if (pspPtr == NULLDYNST)
	{
		MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
	                 "DBA_InsStratSynthDataPrep", "no PSP received");
		return(RET_GEN_ERR_INVARG);
	}


	/* Extract all extended strategy elements for the given psp, sorted by initial date */
    if ((retCd = DBA_ExtractHierEltRecWithFilterSt(hierHead, A_StratSynth, FALSE,
                                                   FIN_FilterValidStratSynth, NULL,  DBA_CmpStratSynthInitialDate,
									               &selStratSynthNbr, &selStratSynthTab)) != RET_SUCCEED || selStratSynthNbr == 0)
	{
        FREE(selStratSynthTab);
		return(retCd);
	}

    /* memory allocation */
    memset(&paFirstDate, 0, sizeof(DATETIME_T));
    memset(&paLastDate, 0, sizeof(DATETIME_T));
    memset(&stdPerfFirstDate, 0, sizeof(DATETIME_T));
    memset(&stdPerfLastDate, 0, sizeof(DATETIME_T));
    memset(&nullDateTime, 0, sizeof(DATETIME_T));

    if ((scptFlagTabPa = (FLAG_T *) CALLOC(GET_FLD_NBR(A_PerfAttrib), sizeof(FLAG_T))) == NULL)
    {
        FREE(selStratSynthTab);
		MSG_RETURN(RET_MEM_ERR_ALLOC);
    }
    if ((scptFlagTabStdPerf = (FLAG_T *) CALLOC(GET_FLD_NBR(A_StandardPerf), sizeof(FLAG_T))) == NULL)
    {
        FREE(selStratSynthTab);
        FREE(scptFlagTabPa);
		MSG_RETURN(RET_MEM_ERR_ALLOC);
    }
    if ((paTab = (DBA_DYNFLD_STP *)CALLOC(selStratSynthNbr, sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR)
    {
        FREE(selStratSynthTab);
        FREE(scptFlagTabPa);
        FREE(scptFlagTabStdPerf);
		MSG_RETURN(RET_MEM_ERR_ALLOC);
    }
    if ((stdPerfTab = (DBA_DYNFLD_STP *)CALLOC(selStratSynthNbr, sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR)
    {
        FREE(paTab);
        FREE(selStratSynthTab);
        FREE(scptFlagTabPa);
        FREE(scptFlagTabStdPerf);
		MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    /* Initialise common parts of flag array for default value evaluation */
    DBA_CommonScptFlagTabPa(scptFlagTabPa);
    scptFlagTabPa[A_PerfAttrib_Wgt]     = TRUE;
    scptFlagTabPa[A_PerfAttrib_Rtn]     = TRUE;
    scptFlagTabPa[A_PerfAttrib_RtnCurr] = TRUE;  /* REF9227 - LJE - 030918 */

    /* Initialise common parts of flag array for default value evaluation */
    DBA_CommonScptFlagTabStdPerf(scptFlagTabStdPerf);
    scptFlagTabStdPerf[A_StandardPerf_Rtn] = TRUE;

	/* REF9832 - RAK - 040303 - Suppress perfDataContent - test will be done only on PSP flags */

    DBA_GetDictId(Strat, &entDictId);

    if (FIN_GetRetDetLevelInfo(pspPtr) == PtfRetDetLvl_Instrument) /*REF9832 - MCA - 040213*/
        instrLevelFlg = 1;

    if (GET_FLAG(pspPtr, A_PerfStorageParam_InstrLevelFlg) == TRUE)
	{
		insFilterEn = InsPaExtRaFilter_Instr; /* instrument: insert all ESE */
	}
	else if (IS_NULLFLD(pspPtr, A_PerfStorageParam_GridId) != TRUE)
	{
		insFilterEn = InsPaExtRaFilter_Grid; /* grid: insert ESE with instrId = NULL*/
	}
	else
	{
		insFilterEn = InsPaExtRaFilter_Global; /* global: insert ESE with instrId = NULL AND mktSegId = NULL*/
	}

    if (DBA_CheckIfAttributUsedInScpt(hierHead, domainPtr,
                                      PerfAttrib, "ext_strategy_element_id", scptFlagTabPa, NULL) ==  TRUE ||
        DBA_CheckIfAttributUsedInScpt(hierHead, domainPtr,
                                      StandardPerf, "ext_strategy_element_id", scptFlagTabStdPerf, NULL) ==  TRUE)
    {
        createESEFlg = TRUE;
    }
    else
    {
        createESEFlg = FALSE;
    }

    for (i=0; i<selStratSynthNbr && retCd == RET_SUCCEED; i++)
    {
        if (createESEFlg == TRUE)
        {
		    eseStp = FIN_CreateESEFromStrategySynth(hierHead,
												    selStratSynthTab[i],
												    pspPtr);
        }
        else
        {
            eseStp = NULL;
        }


        /* insert only if extended strategy element corresponds to required deta il level */
        if (insFilterEn == InsPaExtRaFilter_Instr ||
            (insFilterEn == InsPaExtRaFilter_Grid   && IS_NULLFLD(selStratSynthTab[i], A_StratSynth_InstrId) == TRUE) ||
            (insFilterEn == InsPaExtRaFilter_Global && IS_NULLFLD(selStratSynthTab[i], A_StratSynth_InstrId) == TRUE &&
            IS_NULLFLD(selStratSynthTab[i], A_StratSynth_MktSegtId) == TRUE))
        {
            /* insert extended strategy element in StandardPerf */
			if (GET_FLAG(pspPtr, A_PerfStorageParam_StandardPerfDataFlg) == TRUE &&
				GET_MASKBIT(selStratSynthTab[i], A_StratSynth_SubPeriodMask, RecInfoBench_StdPerf) == TRUE)
            {
                if ((stdPerfTab[stdPerfIdx] = ALLOC_DYNST(A_StandardPerf)) == NULLDYNST)
                {
                    for (j=0; j<paIdx; j++)
                        FREE_DYNST(paTab[j], A_PerfAttrib);
                    for (j=0; j<stdPerfIdx; j++)
                        FREE_DYNST(stdPerfTab[j], A_StandardPerf);

                    FREE(paTab);
                    FREE(stdPerfTab);
                    FREE(selStratSynthTab);
                    FREE(scptFlagTabPa);
                    FREE(scptFlagTabStdPerf);
                    MSG_RETURN(RET_MEM_ERR_ALLOC);
                }
                else
                {
                    DBA_CopyPspToStdPerf(pspPtr, stdPerfTab[stdPerfIdx]);

                    COPY_DYNFLD(stdPerfTab[stdPerfIdx], A_StandardPerf, A_StandardPerf_InitialDate,
                                    selStratSynthTab[i], A_StratSynth, A_StratSynth_BeginDate);

                    COPY_DYNFLD(stdPerfTab[stdPerfIdx], A_StandardPerf, A_StandardPerf_FinalDate,
                                    selStratSynthTab[i], A_StratSynth, A_StratSynth_EndDate);

                    COPY_DYNFLD(stdPerfTab[stdPerfIdx], A_StandardPerf, A_StandardPerf_StratSynthId,
                                    selStratSynthTab[i], A_StratSynth, A_StratSynth_Id);

                    if (eseStp != NULL)
                    {
                        COPY_DYNFLD(stdPerfTab[stdPerfIdx], A_StandardPerf, A_StandardPerf_ExtStratEltId,
                                    eseStp, ExtStratElt, ExtStratElt_Id);
                    }

                    COPY_DYNFLD(stdPerfTab[stdPerfIdx], A_StandardPerf, A_StandardPerf_Rtn,
                                    selStratSynthTab[i], A_StratSynth, A_StratSynth_Return);

					stdPerfIdx++;
                }
            }
            /* insert extended strategy element in PerfAttrib if level != 0 and
                only if data is not global and if system parameter allows to insert PerfAttrib data */
			/* REF9125 - RAK - 031014 - Test on PSP_PerfAttribFlg */
            /* REF10806 - LJE - 041202 : Change test */
            else if (paLicenseEn != PALicensee_No && /* REF11584 - LJE - 060306 : Take licence in account */
                     (GET_FLAG(pspPtr, A_PerfStorageParam_PerfAttribFlg) == TRUE &&
					 ((insFilterEn == InsPaExtRaFilter_Instr || insFilterEn == InsPaExtRaFilter_Grid)) &&
                      GET_MASKBIT(selStratSynthTab[i], A_StratSynth_SubPeriodMask, RecInfoBench_StdPerf) == FALSE))
            {
                if ((paTab[paIdx] = ALLOC_DYNST(A_PerfAttrib)) == NULLDYNST)
                {
                    for (j=0; j<paIdx; j++)
                        FREE_DYNST(paTab[j], A_PerfAttrib);
                    for (j=0; j<stdPerfIdx; j++)
                        FREE_DYNST(stdPerfTab[j], A_StandardPerf);

                    FREE(paTab);
                    FREE(stdPerfTab);
                    FREE(selStratSynthTab);
                    FREE(scptFlagTabPa);
                    FREE(scptFlagTabStdPerf);
                    MSG_RETURN(RET_MEM_ERR_ALLOC);
                }
                else
                {
                    DBA_CopyPspToPa(pspPtr, paTab[paIdx]);

                    COPY_DYNFLD(paTab[paIdx], A_PerfAttrib, A_PerfAttrib_InitialDate,
                                selStratSynthTab[i], A_StratSynth, A_StratSynth_BeginDate);

                    COPY_DYNFLD(paTab[paIdx], A_PerfAttrib, A_PerfAttrib_FinalDate,
                                selStratSynthTab[i], A_StratSynth, A_StratSynth_EndDate);

                    COPY_DYNFLD(paTab[paIdx], A_PerfAttrib, A_PerfAttrib_MktSegtId,
                                selStratSynthTab[i], A_StratSynth, A_StratSynth_MktSegtId);

                    COPY_DYNFLD(paTab[paIdx], A_PerfAttrib, A_PerfAttrib_InstrId,
                                selStratSynthTab[i], A_StratSynth, A_StratSynth_InstrId);

                    subPeriodMask = (MASK_T)0;

                    if (GET_MASKBIT(selStratSynthTab[i], A_StratSynth_SubPeriodMask, RecInfoBench_BenchRebal) == TRUE)
					{
                        SET_BIT(subPeriodMask, SynthLevel_BenchRebal, TRUE);
					}
                    if (GET_MASKBIT(selStratSynthTab[i], A_StratSynth_SubPeriodMask, RecInfoBench_PortBenchStorage) == TRUE)
					{
                    	SET_BIT(subPeriodMask, SynthLevel_PortBenchStorage, TRUE);
					}

                    SET_MASK(paTab[paIdx], A_PerfAttrib_SubPeriodMask, subPeriodMask);

                    /* REF7422 - YST - 021115 - change computation of PerfAttib weight */
                    COPY_DYNFLD(paTab[paIdx], A_PerfAttrib, A_PerfAttrib_Wgt,
                                selStratSynthTab[i], A_StratSynth, A_StratSynth_Weight);

					COPY_DYNFLD(paTab[paIdx], A_PerfAttrib, A_PerfAttrib_Rtn,
                                selStratSynthTab[i], A_StratSynth, A_StratSynth_Return);

					COPY_DYNFLD(paTab[paIdx], A_PerfAttrib, A_PerfAttrib_Dura,
                                selStratSynthTab[i], A_StratSynth, A_StratSynth_Dura);

                    /* REF9227 - LJE - 030918 */
					COPY_DYNFLD(paTab[paIdx], A_PerfAttrib, A_PerfAttrib_RtnCurr,
                                selStratSynthTab[i], A_StratSynth, A_StratSynth_ReturnCurr);

                    COPY_DYNFLD(paTab[paIdx], A_PerfAttrib, A_PerfAttrib_StratSynthId,
                                selStratSynthTab[i], A_StratSynth, A_StratSynth_Id);

                    if (eseStp != NULL)
                    {
                        COPY_DYNFLD(paTab[paIdx], A_PerfAttrib, A_PerfAttrib_ExtStratEltId,
                                    eseStp, ExtStratElt, ExtStratElt_Id);
                    }

                    COPY_DYNFLD(paTab[paIdx], A_PerfAttrib, A_PerfAttrib_BenchEntDictId,
                                selStratSynthTab[i], A_StratSynth, A_StratSynth_BenchEntDictId);
                    COPY_DYNFLD(paTab[paIdx], A_PerfAttrib, A_PerfAttrib_BenchObjId,
                                selStratSynthTab[i], A_StratSynth, A_StratSynth_BenchObjId);

                    paIdx++;
                }
            }
        }

		/* Data treated */
		SET_MASKBIT(selStratSynthTab[i], A_StratSynth_SubPeriodMask, RecInfoBench_CurrentData, FALSE);
    }

    /* just for security */
    if (paIdx == 0 && stdPerfIdx == 0)
    {
        retCd = RET_GEN_INFO_NODATA;
    }

    if (retCd == RET_SUCCEED && paIdx > 0)
    {
        /* memory allocation */
        if (paIdx < selStratSynthNbr)
        {
            if ((paTab = (DBA_DYNFLD_STP *)REALLOC(paTab, (paIdx)*sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR)
            {
                for (j=0; j<paIdx; j++)
                    FREE_DYNST(paTab[j], A_PerfAttrib);
                for (j=0; j<stdPerfIdx; j++)
                    FREE_DYNST(stdPerfTab[j], A_StandardPerf);

                FREE(paTab);
                FREE(stdPerfTab);
                FREE(selStratSynthTab);
                FREE(scptFlagTabPa);
                FREE(scptFlagTabStdPerf);
                MSG_RETURN(RET_MEM_ERR_REALLOC);
            }
        }
        if ((insPaExtRaStp->paTab) == (DBA_DYNFLD_STP *)NULL)
        {
            insPaExtRaStp->paNbr = 0;
            if (((insPaExtRaStp->paTab) = (DBA_DYNFLD_STP *)CALLOC(paIdx, sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR)
            {
                for (j=0; j<paIdx; j++)
                    FREE_DYNST(paTab[j], A_PerfAttrib);
                for (j=0; j<stdPerfIdx; j++)
                    FREE_DYNST(stdPerfTab[j], A_StandardPerf);

                FREE(paTab);
                FREE(stdPerfTab);
                FREE(selStratSynthTab);
                FREE(scptFlagTabPa);
                FREE(scptFlagTabStdPerf);
                MSG_RETURN(RET_MEM_ERR_ALLOC);
            }
        }
        else
        {
            if (((insPaExtRaStp->paTab) = (DBA_DYNFLD_STP *)REALLOC((insPaExtRaStp->paTab),
                                (insPaExtRaStp->paNbr+paIdx)*sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR)
            {
                for (j=0; j<paIdx; j++)
                    FREE_DYNST(paTab[j], A_PerfAttrib);
                for (j=0; j<stdPerfIdx; j++)
                    FREE_DYNST(stdPerfTab[j], A_StandardPerf);

                FREE(paTab);
                FREE(stdPerfTab);
                FREE(selStratSynthTab);
                FREE(scptFlagTabPa);
                FREE(scptFlagTabStdPerf);
                MSG_RETURN(RET_MEM_ERR_REALLOC);
            }
        }
        /* add PerfAttrib records to hierarchy */
        if ((retCd = DBA_AddHierRecordList(dstHierHead, paTab,
                                            paIdx, A_PerfAttrib, FALSE)) != RET_SUCCEED)
        {
            for (j=0; j<stdPerfIdx; j++)
                FREE_DYNST(stdPerfTab[j], A_StandardPerf);
        }
        /* Compute default values for PerfAttrib and copy PerfAttrib to insert structure */
        else
        {
            for (i=0; i<paIdx; i++)
            {
		        SCPT_ComputeDV(PerfAttrib, scptFlagTabPa, paTab[i], TRUE, TRUE, NULL);

                if (IS_NULLFLD(paTab[i], A_PerfAttrib_WgtFactor) == TRUE)
                    SET_LONGAMOUNT(paTab[i], A_PerfAttrib_WgtFactor, 0.0);  /* WEALTH-4573 - DDV - 240306 - Change to long amount */
                if (IS_NULLFLD(paTab[i], A_PerfAttrib_Wgt) == TRUE)
                    SET_NUMBER(paTab[i], A_PerfAttrib_Wgt, 0.0);
                if (IS_NULLFLD(paTab[i], A_PerfAttrib_Rtn) == TRUE)
                    SET_NUMBER(paTab[i], A_PerfAttrib_Rtn, 0.0);
                /* REF9227 - LJE - 030918 */
                if (IS_NULLFLD(paTab[i], A_PerfAttrib_RtnCurr) == TRUE)
                    SET_NUMBER(paTab[i], A_PerfAttrib_RtnCurr, 0.0);

                (insPaExtRaStp->paTab)[insPaExtRaStp->paNbr+i] = paTab[i];
            }
            insPaExtRaStp->paNbr += paIdx;
            paFirstDate = GET_DATETIME(paTab[0], A_PerfAttrib_InitialDate);
            paLastDate = GET_DATETIME(paTab[paIdx-1], A_PerfAttrib_FinalDate);
            perfFlg = TRUE;
        }
    }

    if (retCd == RET_SUCCEED && stdPerfIdx > 0)
    {
        /* memory allocation */
        if (stdPerfIdx < selStratSynthNbr)
        {
            if ((stdPerfTab = (DBA_DYNFLD_STP *)REALLOC(stdPerfTab, (stdPerfIdx)*sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR)
            {
                for (j=0; j<stdPerfIdx; j++)
                    FREE_DYNST(stdPerfTab[j], A_StandardPerf);

                FREE(paTab);
                FREE(stdPerfTab);
                FREE(selStratSynthTab);
                FREE(scptFlagTabPa);
                FREE(scptFlagTabStdPerf);
                MSG_RETURN(RET_MEM_ERR_REALLOC);
            }
        }
        if ((insPaExtRaStp->stdPerfTab) == (DBA_DYNFLD_STP *)NULL)
        {
            insPaExtRaStp->stdPerfNbr = 0;
            if (((insPaExtRaStp->stdPerfTab) = (DBA_DYNFLD_STP *)CALLOC(stdPerfIdx, sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR)
            {
                for (j=0; j<stdPerfIdx; j++)
                    FREE_DYNST(stdPerfTab[j], A_StandardPerf);
                FREE(paTab);
                FREE(stdPerfTab);
                FREE(selStratSynthTab);
                FREE(scptFlagTabPa);
                FREE(scptFlagTabStdPerf);
                MSG_RETURN(RET_MEM_ERR_ALLOC);
            }
        }
        else
        {
            if (((insPaExtRaStp->stdPerfTab) = (DBA_DYNFLD_STP *)REALLOC((insPaExtRaStp->stdPerfTab),
                                (insPaExtRaStp->stdPerfNbr+stdPerfIdx)*sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR)
            {
                for (j=0; j<stdPerfIdx; j++)
                    FREE_DYNST(stdPerfTab[j], A_StandardPerf);

                FREE(paTab);
                FREE(stdPerfTab);
                FREE(selStratSynthTab);
                FREE(scptFlagTabPa);
                FREE(scptFlagTabStdPerf);
                MSG_RETURN(RET_MEM_ERR_REALLOC);
            }
        }
        /* Add StandardPerf records to hierarchy */
        if ((retCd = DBA_AddHierRecordList(dstHierHead, stdPerfTab,
                                            stdPerfIdx, A_StandardPerf, FALSE)) != RET_SUCCEED)
        {
		MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
	                 "DBA_InsStratSynthDataPrep", "no standardPerf");
        }
        /* Compute default values for StandardPerf and copy StandardPerf to insert structure */
        else
        {
            /* Initialise common parts of flag array for default value evaluation */
            DBA_CommonScptFlagTabStdPerf(scptFlagTabStdPerf);

            scptFlagTabStdPerf[A_StandardPerf_Rtn] = TRUE;

            for (i=0; i<stdPerfIdx; i++)
            {
                SCPT_ComputeDV(StandardPerf, scptFlagTabStdPerf, stdPerfTab[i], TRUE, TRUE, NULL);

                (insPaExtRaStp->stdPerfTab)[insPaExtRaStp->stdPerfNbr+i] = stdPerfTab[i];
            }
            insPaExtRaStp->stdPerfNbr += stdPerfIdx;
            stdPerfFirstDate = GET_DATETIME(stdPerfTab[0], A_StandardPerf_InitialDate);
            stdPerfLastDate = GET_DATETIME(stdPerfTab[stdPerfIdx-1], A_StandardPerf_FinalDate);
            stdPerfFlg = TRUE;
        }
    }

    if ((retCd = DBA_UpdPspDelPaExtRaStdP(domainPtr, pspPtr, stdPerfFlg, stdPerfFirstDate, stdPerfLastDate,
                                          FALSE, nullDateTime, nullDateTime,
                                          perfFlg, paFirstDate, paLastDate,
		                                  FALSE, nullDateTime, nullDateTime,
                                          delFromDate, delTillDate, insPaExtRaStp)) != RET_SUCCEED)
    {
	MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
	                 "DBA_InsStratSynthDataPrep", " no delete of PerfAttrib and ExtRetAnalysis data in database");
	}

    FREE(paTab);
    FREE(stdPerfTab);
    FREE(selStratSynthTab);
    FREE(scptFlagTabPa);
    FREE(scptFlagTabStdPerf);

    return(retCd);
}

/************************************************************************
**
**  Function    :   DBA_InsInstrFreqDataPrep()
**
**  Description :   Prepares insert of data in database computed by benchmark storage.
**                  Function is called for each instrument after computation of data.
**                  The structure pointer DBA_INSPAEXTRA_STP is filled with
**                  the following data:
**
**                  stdPerfTab:
**                  instrument frequencies for insert
**
**                  accessStp:
**                  structure pointer for multiaccess
**                  - StandardPerf for delete between delFromDate and delTillDate
**                  - PSP for update
**
**
**  Arguments   :   input:
**                  domainPtr           domain structure pointer
**                  hierHead            hierarchy header pointer
**                  stratPtr            pointer on instrument
**                  delFromDate         date from which data must be deleted
**                  delTillDate         date until which data must be deleted
**
**                  output:
**                  insPaExtRaStp       pointer on data to insert, update or delete
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   REF7421 - YST - 020719
**  modification:   REF9125 - MCA - 030905
**
*************************************************************************/
RET_CODE DBA_InsInstrFreqDataPrep(DBA_DYNFLD_STP      domainPtr,
									     DBA_HIER_HEAD_STP   hierHead,
	                                     DBA_DYNFLD_STP      ,
			                             DBA_DYNFLD_STP      pspPtr,	/* REF9125 - MCA - 030905 */
					                     DATETIME_T          delFromDate,
							             DATETIME_T          delTillDate,
									     DBA_INSPAEXTRA_STP  insPaExtRaStp)
{
    RET_CODE            retCd = RET_SUCCEED;
    DBA_DYNFLD_STP      *selDynStTab = NULLDYNSTPTR, *stdPerfTab = NULLDYNSTPTR;
    DATETIME_T          nullDateTime, stdPerfFirstDate, stdPerfLastDate;
    FLAG_T              *scptFlagTabStdPerf;
    int                 i = 0, j = 0, selDynStNbr = 0, stdPerfIdx = 0;

	/* REF9125 - RAK - 031016 - new PSP must be received */
	if (pspPtr == NULLDYNST)
	{
		MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
	                 "DBA_InsInstrFreqDataPrep", "no PSP received");
		return(RET_GEN_ERR_INVARG);
	}

    /* Extract all instrument frequencies for the given psp, sorted by initial date */
    if ((retCd = DBA_ExtractHierEltRecWithFilterSt(hierHead, A_InstrFreq, FALSE,
                                                   DBA_FilterInstrFreqPsp, pspPtr,  DBA_CmpInstrFreqInitialDate,
									               &selDynStNbr, &selDynStTab)) != RET_SUCCEED || selDynStNbr == 0)
	{
        FREE(selDynStTab);
		return(retCd);
	}

    /* memory allocation */
    memset(&nullDateTime, 0, sizeof(DATETIME_T));
    memset(&stdPerfFirstDate, 0, sizeof(DATETIME_T));
    memset(&stdPerfLastDate, 0, sizeof(DATETIME_T));

    if ((scptFlagTabStdPerf = (FLAG_T *) CALLOC(GET_FLD_NBR(A_StandardPerf), sizeof(FLAG_T))) == NULL)
    {
        FREE(selDynStTab);
		MSG_RETURN(RET_MEM_ERR_ALLOC);
    }
    if ((stdPerfTab = (DBA_DYNFLD_STP *)CALLOC(selDynStNbr, sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR)
    {
        FREE(selDynStTab);
        FREE(scptFlagTabStdPerf);
		MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    for (i=0; i<selDynStNbr && retCd == RET_SUCCEED; i++)
    {
        if ((stdPerfTab[stdPerfIdx] = ALLOC_DYNST(A_StandardPerf)) == NULLDYNST)
        {
            FREE(stdPerfTab);
            FREE(selDynStTab);
            FREE(scptFlagTabStdPerf);
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }
        else
        {
            DBA_CopyPspToStdPerf(pspPtr, stdPerfTab[stdPerfIdx]);

            /* REF8749 - YST - 030128 rename A_InstrFreq_FinalDate -> A_InstrFreq_InitialDate */
            COPY_DYNFLD(stdPerfTab[stdPerfIdx], A_StandardPerf, A_StandardPerf_InitialDate,
                                        selDynStTab[i], A_InstrFreq, A_InstrFreq_InitialDate /*A_InstrFreq_FreqDate*/);

            COPY_DYNFLD(stdPerfTab[stdPerfIdx], A_StandardPerf, A_StandardPerf_FinalDate,
                                        selDynStTab[i], A_InstrFreq, A_InstrFreq_FreqDate /*A_InstrFreq_FinalDate*/);

            COPY_DYNFLD(stdPerfTab[stdPerfIdx], A_StandardPerf, A_StandardPerf_InstrFreqId,
                                        selDynStTab[i], A_InstrFreq, A_InstrFreq_Id);

            stdPerfIdx++;
        }
    }

    /* just for security */
    if (stdPerfIdx == 0)
    {
        retCd = RET_GEN_INFO_NODATA;
    }

    if (retCd == RET_SUCCEED)
    {
        /* memory allocation */
        if (stdPerfIdx < selDynStNbr)
        {
            if ((stdPerfTab = (DBA_DYNFLD_STP *)REALLOC(stdPerfTab, (stdPerfIdx)*sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR)
            {
                for (j=0; j<stdPerfIdx; j++)
                    FREE_DYNST(stdPerfTab[j], A_StandardPerf);
                FREE(stdPerfTab);
                FREE(selDynStTab);
                FREE(scptFlagTabStdPerf);
                MSG_RETURN(RET_MEM_ERR_REALLOC);
            }
        }
        if ((insPaExtRaStp->stdPerfTab) == (DBA_DYNFLD_STP *)NULL)
        {
            insPaExtRaStp->stdPerfNbr = 0;
            if (((insPaExtRaStp->stdPerfTab) = (DBA_DYNFLD_STP *)CALLOC(stdPerfIdx, sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR)
            {
                for (j=0; j<stdPerfIdx; j++)
                    FREE_DYNST(stdPerfTab[j], A_StandardPerf);
                FREE(stdPerfTab);
                FREE(selDynStTab);
                FREE(scptFlagTabStdPerf);
                MSG_RETURN(RET_MEM_ERR_ALLOC);
            }
        }
        else
        {
            if (((insPaExtRaStp->stdPerfTab) = (DBA_DYNFLD_STP *)REALLOC((insPaExtRaStp->stdPerfTab),
                                (insPaExtRaStp->stdPerfNbr+stdPerfIdx)*sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR)
            {
                for (j=0; j<stdPerfIdx; j++)
                    FREE_DYNST(stdPerfTab[j], A_StandardPerf);
                FREE(stdPerfTab);
                FREE(selDynStTab);
                FREE(scptFlagTabStdPerf);
                MSG_RETURN(RET_MEM_ERR_REALLOC);
            }
        }
        /* Add StandardPerf records to hierarchy */
		/* Compute default values for StandardPerf and copy StandardPerf to insert structure */
        if ((retCd = DBA_AddHierRecordList(hierHead, stdPerfTab,
                                            stdPerfIdx, A_StandardPerf, FALSE)) == RET_SUCCEED)
        {
            /* Initialise common parts of flag array for default value evaluation */
            DBA_CommonScptFlagTabStdPerf(scptFlagTabStdPerf);

            for (i=0; i<stdPerfIdx; i++)
            {
                SCPT_ComputeDV(StandardPerf, scptFlagTabStdPerf, stdPerfTab[i], TRUE, TRUE, NULL);

	            (insPaExtRaStp->stdPerfTab)[insPaExtRaStp->stdPerfNbr+i] = stdPerfTab[i];
            }
            insPaExtRaStp->stdPerfNbr += stdPerfIdx;

            /* Prepare insert structure for update PSP and delete StandardPerf, except for compute online */
            if ((COMPDATA_ENUM)GET_ENUM(domainPtr, A_Domain_CompDataEn) != CompData_OnLine)  /* REF7758 - YST - 021106 */
            {
                stdPerfFirstDate = GET_DATETIME(stdPerfTab[0], A_StandardPerf_InitialDate);
                stdPerfLastDate = GET_DATETIME(stdPerfTab[stdPerfIdx-1], A_StandardPerf_FinalDate);
                retCd = DBA_UpdPspDelPaExtRaStdP(domainPtr, pspPtr, TRUE, stdPerfFirstDate, stdPerfLastDate,
                                                 FALSE, nullDateTime, nullDateTime,
                                                 FALSE, nullDateTime, nullDateTime,
					                             FALSE, nullDateTime, nullDateTime,
                                                 delFromDate, delTillDate, insPaExtRaStp);
            }
        }
    }

    FREE(stdPerfTab);
    FREE(selDynStTab);
    FREE(scptFlagTabStdPerf);

    return(retCd);
}

/************************************************************************
**
**  Function    :   DBA_UpdPspDelPaExtRaStdP()
**
**  Description :   Prepares delete of PerfAttrib and ExtRetAnalysis data
**                  in database (only if compute new and replace old) and
**                  update of performance storage parameter table in database.
**                  If delFromDate < delTillDate PerfAttrib and
**                  ExtRetAnalysis data is prepared for delete.
**                  If at least one of the first and last dates has changed
**                  PSP table needs to be updated
**                  a new record is prepared in structure pointer.
**
**  Arguments   :   input:
**                  aPspPtr             PSP structure pointer
**                  stdPerfFirstDate    first date for insert StandardPerf view
**                  stdPerfLastDate     last date for insert StandardPerf view
**                  retFirstDate        first date for insert ret analysis view
**                  retLastDate         last date for insert ret analysis view
**                  perfFirstDate       first date for insert PerfAttrib view
**                  perfLastDate        last date for insert PerfAttrib view
**                  delFromDate         from date for delete data in database
**                  delTillDate         till date for delete data in database
**
**                  output:
**                  insPaExtRaStp       pointer on insert structure
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   REF7421 - YST - 020808
**
*************************************************************************/
STATIC RET_CODE DBA_UpdPspDelPaExtRaStdP(DBA_DYNFLD_STP     domainPtr, /* PMSTA-64818 - Deepthi - 20250210 */
                                        DBA_DYNFLD_STP      aPspPtr,
                                        FLAG_T              stdPerfFlg,
                                        DATETIME_T          stdPerfFirstDate,
                                        DATETIME_T          stdPerfLastDate,
                                        FLAG_T              retFlg,
                                        DATETIME_T          retFirstDate,
                                        DATETIME_T          retLastDate,
                                        FLAG_T              perfFlg,
                                        DATETIME_T          perfFirstDate,
                                        DATETIME_T          perfLastDate,
	                                    FLAG_T              pcrFlg,
	                                    DATETIME_T          pcrFirstDate,
	                                    DATETIME_T          pcrLastDate,
                                        DATETIME_T          delFromDate,
                                        DATETIME_T          delTillDate,
                                        DBA_INSPAEXTRA_STP  insPaExtRaStp)
{
    RET_CODE        retCd = RET_SUCCEED;
    DBA_DYNFLD_STP  delDataArg = NULLDYNST;
    DATETIME_T      nullDateTime;
    FLAG_T          delFlg = FALSE;
    int             i = 0;

    memset(&nullDateTime, 0, sizeof(DATETIME_T));

    /* If delFromDate < delTillDate (and not 0), delete all data in this period. */
	if (DATETIME_CMP(delFromDate, nullDateTime) > 0 && DATETIME_CMP(delTillDate, nullDateTime) > 0 &&
        DATETIME_CMP(delFromDate, delTillDate) < 0)
    {
        if (stdPerfFlg == TRUE || retFlg == TRUE)
            i = 2;
        if (perfFlg == TRUE)
            i++;
		if (pcrFlg == TRUE)
			i++;
        if (GET_FLAG(aPspPtr, A_PerfStorageParam_StorageInValidFlg) == TRUE)
            i++;

        delFlg = TRUE;
    }

        if (stdPerfFlg == TRUE || retFlg == TRUE)  /* REF7421 - LJE - 020909 : If retFlg stdPerf is TRUE */
        {
            /* update StdPerfFirstStoredDate after insert with stdPerfFirstDate */
            if (IS_NULLFLD(aPspPtr, A_PerfStorageParam_StdPerfFirstStoredDate) == TRUE ||
            DATETIME_CMP(stdPerfFirstDate, GET_DATETIME(aPspPtr, A_PerfStorageParam_StdPerfFirstStoredDate)) < 0 ||
            DATETIME_CMP(stdPerfFirstDate, delFromDate) > 0) /* PMSTA-18006 - LJE - 0140501 */
        {
            if (DATETIME_CMP(stdPerfFirstDate, nullDateTime) == 0)
            {
                if (DATETIME_CMP(delTillDate, GET_DATETIME(aPspPtr, A_PerfStorageParam_StdPerfFirstStoredDate)) > 0 &&
                    DATETIME_CMP(delFromDate, GET_DATETIME(aPspPtr, A_PerfStorageParam_StdPerfLastStoredDate)) < 0)
                {
                    if (DATETIME_CMP(delFromDate, GET_DATETIME(aPspPtr, A_PerfStorageParam_StdPerfFirstStoredDate)) < 0)
                    {
                        SET_NULL_DATETIME(aPspPtr, A_PerfStorageParam_StdPerfFirstStoredDate);
                    }
                    else if (GET_FLAG(domainPtr, A_Domain_PtfHierChangeFlg) != TRUE) /* PMSTA-64818 - Deepthi - 20250210 */
                    {
                        SET_DATETIME(aPspPtr, A_PerfStorageParam_StdPerfFirstStoredDate, delFromDate);
                    }
                }
            }
            else if (GET_FLAG(domainPtr, A_Domain_PtfHierChangeFlg) != TRUE) /* PMSTA-64818 - Deepthi - 20250210 */
            {
                SET_DATETIME(aPspPtr, A_PerfStorageParam_StdPerfFirstStoredDate, stdPerfFirstDate);
            }
        }
            /* update StdPerfLastStoredDate after insert with stdPerfLastDate */
            if (IS_NULLFLD(aPspPtr, A_PerfStorageParam_StdPerfLastStoredDate) == TRUE ||
            DATETIME_CMP(GET_DATETIME(aPspPtr, A_PerfStorageParam_StdPerfLastStoredDate), stdPerfLastDate) < 0 ||
            DATETIME_CMP(stdPerfLastDate, delTillDate) < 0) /* PMSTA-18006 - LJE - 0140501 */
        {
            if (DATETIME_CMP(stdPerfFirstDate, nullDateTime) == 0)
            {
                if (DATETIME_CMP(delTillDate, GET_DATETIME(aPspPtr, A_PerfStorageParam_StdPerfFirstStoredDate)) > 0 &&
                    DATETIME_CMP(delFromDate, GET_DATETIME(aPspPtr, A_PerfStorageParam_StdPerfLastStoredDate)) < 0)
                {
                    if (DATETIME_CMP(delTillDate, GET_DATETIME(aPspPtr, A_PerfStorageParam_StdPerfLastStoredDate)) > 0)
                    {
                        SET_NULL_DATETIME(aPspPtr, A_PerfStorageParam_StdPerfLastStoredDate);
                    }
                    else if (GET_FLAG(domainPtr, A_Domain_PtfHierChangeFlg) != TRUE) /* PMSTA-64818 - Deepthi - 20250210 */
                    {
                        SET_DATETIME(aPspPtr, A_PerfStorageParam_StdPerfLastStoredDate, delTillDate);
                    }
                }
            }
            else if (GET_FLAG(domainPtr, A_Domain_PtfHierChangeFlg) != TRUE) /* PMSTA-64818 - Deepthi - 20250210 */
            {
                SET_DATETIME(aPspPtr, A_PerfStorageParam_StdPerfLastStoredDate, stdPerfLastDate);
            }
        }
    }
        if (retFlg == TRUE)
        {
            /* update RetFirstStoredDate after insert with retFirstDate */
            if (IS_NULLFLD(aPspPtr, A_PerfStorageParam_RetFirstStoredDate) == TRUE ||
            DATETIME_CMP(retFirstDate, GET_DATETIME(aPspPtr, A_PerfStorageParam_RetFirstStoredDate)) < 0 ||
            DATETIME_CMP(retFirstDate, delFromDate) > 0) /* PMSTA-18006 - LJE - 0140501 */
        {
            if (DATETIME_CMP(retFirstDate, nullDateTime) == 0)
            {
                if (DATETIME_CMP(delTillDate, GET_DATETIME(aPspPtr, A_PerfStorageParam_RetFirstStoredDate)) > 0 &&
                    DATETIME_CMP(delFromDate, GET_DATETIME(aPspPtr, A_PerfStorageParam_RetLastStoredDate)) < 0)
                {
                    if (DATETIME_CMP(delFromDate, GET_DATETIME(aPspPtr, A_PerfStorageParam_RetFirstStoredDate)) < 0)
                    {
                        SET_NULL_DATETIME(aPspPtr, A_PerfStorageParam_RetFirstStoredDate);
                    }
                    else if (GET_FLAG(domainPtr, A_Domain_PtfHierChangeFlg) != TRUE) /* PMSTA-64818 - Deepthi - 20250210 */
                    {
                        SET_DATETIME(aPspPtr, A_PerfStorageParam_RetFirstStoredDate, delFromDate);
                    }
                }
            }
            else if (GET_FLAG(domainPtr, A_Domain_PtfHierChangeFlg) != TRUE) /* PMSTA-64818 - Deepthi - 20250210 */
            {
                SET_DATETIME(aPspPtr, A_PerfStorageParam_RetFirstStoredDate, retFirstDate);
            }
        }
            /* update RetLastStoredDate after insert with retLastDate */
            if (IS_NULLFLD(aPspPtr, A_PerfStorageParam_RetLastStoredDate) == TRUE ||
            DATETIME_CMP(GET_DATETIME(aPspPtr, A_PerfStorageParam_RetLastStoredDate), retLastDate) < 0 ||
            DATETIME_CMP(retLastDate, delTillDate) < 0) /* PMSTA-18006 - LJE - 0140501 */
        {
            if (DATETIME_CMP(retLastDate, nullDateTime) == 0)
            {
                if (DATETIME_CMP(delTillDate, GET_DATETIME(aPspPtr, A_PerfStorageParam_RetFirstStoredDate)) > 0 &&
                    DATETIME_CMP(delFromDate, GET_DATETIME(aPspPtr, A_PerfStorageParam_RetLastStoredDate)) < 0)
                {
                    if (DATETIME_CMP(delTillDate, GET_DATETIME(aPspPtr, A_PerfStorageParam_RetLastStoredDate)) > 0)
                    {
                        SET_NULL_DATETIME(aPspPtr, A_PerfStorageParam_RetLastStoredDate);
                    }
                    else if (GET_FLAG(domainPtr, A_Domain_PtfHierChangeFlg) != TRUE) /* PMSTA-64818 - Deepthi - 20250210 */
                    {
                        SET_DATETIME(aPspPtr, A_PerfStorageParam_RetLastStoredDate, delTillDate);
                    }
                }
            }
            else if (GET_FLAG(domainPtr, A_Domain_PtfHierChangeFlg) != TRUE) /* PMSTA-64818 - Deepthi - 20250210 */
            {
                SET_DATETIME(aPspPtr, A_PerfStorageParam_RetLastStoredDate, retLastDate);
            }
        }
    }
        if (perfFlg == TRUE)
        {
            /* update PerfFirstStoredDate after insert with perfFirstDate */
            if (IS_NULLFLD(aPspPtr, A_PerfStorageParam_PerfFirstStoredDate) == TRUE ||
            DATETIME_CMP(perfFirstDate, GET_DATETIME(aPspPtr, A_PerfStorageParam_PerfFirstStoredDate)) < 0 ||
            DATETIME_CMP(perfFirstDate, delFromDate) > 0) /* PMSTA-18006 - LJE - 0140501 */
        {
            if (DATETIME_CMP(perfFirstDate, nullDateTime) == 0)
            {
                if (DATETIME_CMP(delTillDate, GET_DATETIME(aPspPtr, A_PerfStorageParam_PerfFirstStoredDate)) > 0 &&
                    DATETIME_CMP(delFromDate, GET_DATETIME(aPspPtr, A_PerfStorageParam_PerfLastStoredDate)) < 0)
                {
                    if (DATETIME_CMP(delFromDate, GET_DATETIME(aPspPtr, A_PerfStorageParam_PerfFirstStoredDate)) < 0)
                    {
                        SET_NULL_DATETIME(aPspPtr, A_PerfStorageParam_PerfFirstStoredDate);
                    }
                    else if (GET_FLAG(domainPtr, A_Domain_PtfHierChangeFlg) != TRUE) /* PMSTA-64818 - Deepthi - 20250210 */
                    {
                        SET_DATETIME(aPspPtr, A_PerfStorageParam_PerfFirstStoredDate, delFromDate);
                    }
                }
            }
            else if (GET_FLAG(domainPtr, A_Domain_PtfHierChangeFlg) != TRUE) /* PMSTA-64818 - Deepthi - 20250210 */
            {
                SET_DATETIME(aPspPtr, A_PerfStorageParam_PerfFirstStoredDate, perfFirstDate);
            }
        }
            /* update PerfLastStoredDate after insert with perfLastDate */
            if (IS_NULLFLD(aPspPtr, A_PerfStorageParam_PerfLastStoredDate) == TRUE ||
            DATETIME_CMP(GET_DATETIME(aPspPtr, A_PerfStorageParam_PerfLastStoredDate), perfLastDate) < 0 ||
            DATETIME_CMP(perfLastDate, delTillDate) < 0) /* PMSTA-18006 - LJE -0140501 */
        {
            if (DATETIME_CMP(perfLastDate, nullDateTime) == 0)
            {
                if (DATETIME_CMP(delTillDate, GET_DATETIME(aPspPtr, A_PerfStorageParam_PerfFirstStoredDate)) > 0 &&
                    DATETIME_CMP(delFromDate, GET_DATETIME(aPspPtr, A_PerfStorageParam_PerfLastStoredDate)) < 0)
                {
                    if (DATETIME_CMP(delTillDate, GET_DATETIME(aPspPtr, A_PerfStorageParam_PerfLastStoredDate)) > 0)
                    {
                        SET_NULL_DATETIME(aPspPtr, A_PerfStorageParam_PerfLastStoredDate);
                    }
                    else if (GET_FLAG(domainPtr, A_Domain_PtfHierChangeFlg) != TRUE) /* PMSTA-64818 - Deepthi - 20250210 */
                    {
                        SET_DATETIME(aPspPtr, A_PerfStorageParam_PerfLastStoredDate, delTillDate);
                    }
                }
            }
            else if (GET_FLAG(domainPtr, A_Domain_PtfHierChangeFlg) != TRUE) /* PMSTA-64818 - Deepthi - 20250210 */
            {
                SET_DATETIME(aPspPtr, A_PerfStorageParam_PerfLastStoredDate, perfLastDate);
            }
        }
    }

		if (pcrFlg == TRUE)
		{

			if (IS_NULLFLD(aPspPtr, A_PerfStorageParam_PerfCalcFirstStoredDate) == TRUE ||
				DATETIME_CMP(pcrFirstDate, GET_DATETIME(aPspPtr, A_PerfStorageParam_PerfCalcFirstStoredDate)) < 0 ||
				DATETIME_CMP(pcrFirstDate, delFromDate) > 0)
			{
				if (DATETIME_CMP(pcrFirstDate, nullDateTime) == 0)
				{
					if (DATETIME_CMP(delTillDate, GET_DATETIME(aPspPtr, A_PerfStorageParam_PerfCalcFirstStoredDate)) > 0 &&
						DATETIME_CMP(delFromDate, GET_DATETIME(aPspPtr, A_PerfStorageParam_PerfCalcLastStoredDate)) < 0)
					{
						if (DATETIME_CMP(delFromDate, GET_DATETIME(aPspPtr, A_PerfStorageParam_PerfCalcFirstStoredDate)) < 0)
						{
							SET_NULL_DATETIME(aPspPtr, A_PerfStorageParam_PerfCalcFirstStoredDate);
						}
						else if (GET_FLAG(domainPtr, A_Domain_PtfHierChangeFlg) != TRUE) /* PMSTA-64818 - Deepthi - 20250210 */
						{
							SET_DATETIME(aPspPtr, A_PerfStorageParam_PerfCalcFirstStoredDate, delFromDate);
						}
					}
				}
				else if (GET_FLAG(domainPtr, A_Domain_PtfHierChangeFlg) != TRUE) /* PMSTA-64818 - Deepthi - 20250210 */
				{
					SET_DATETIME(aPspPtr, A_PerfStorageParam_PerfCalcFirstStoredDate, pcrFirstDate);
				}
			}

			if (IS_NULLFLD(aPspPtr, A_PerfStorageParam_PerfCalcLastStoredDate) == TRUE ||
				DATETIME_CMP(GET_DATETIME(aPspPtr, A_PerfStorageParam_PerfCalcLastStoredDate), pcrLastDate) < 0 ||
				DATETIME_CMP(pcrLastDate, delTillDate) < 0)
			{
				if (DATETIME_CMP(pcrFirstDate, nullDateTime) == 0)
				{
					if (DATETIME_CMP(delTillDate, GET_DATETIME(aPspPtr, A_PerfStorageParam_PerfCalcFirstStoredDate)) > 0 &&
						DATETIME_CMP(delFromDate, GET_DATETIME(aPspPtr, A_PerfStorageParam_PerfCalcLastStoredDate)) < 0)
					{
						if (DATETIME_CMP(delTillDate, GET_DATETIME(aPspPtr, A_PerfStorageParam_PerfCalcLastStoredDate)) > 0)
						{
							SET_NULL_DATETIME(aPspPtr, A_PerfStorageParam_PerfCalcLastStoredDate);
						}
						else if (GET_FLAG(domainPtr, A_Domain_PtfHierChangeFlg) != TRUE) /* PMSTA-64818 - Deepthi - 20250210 */
						{
							SET_DATETIME(aPspPtr, A_PerfStorageParam_PerfCalcLastStoredDate, delTillDate);
						}
					}
				}
				else if (GET_FLAG(domainPtr, A_Domain_PtfHierChangeFlg) != TRUE) /* PMSTA-64818 - Deepthi - 20250210 */
				{
					SET_DATETIME(aPspPtr, A_PerfStorageParam_PerfCalcLastStoredDate, pcrLastDate);
				}
			}
		}

    /* allocate memory, if delete in database is needed */
    if (retCd == RET_SUCCEED && delFlg == TRUE && i != 0) /* REF8712 - LJE - 031017 : Add "i" test */
    {
        if ((insPaExtRaStp->accessStp) == (DBA_ACCESS_STP)NULL)
        {
            insPaExtRaStp->accessNbr = 0;
            if (((insPaExtRaStp->accessStp) = (DBA_ACCESS_STP)
		                            CALLOC(i, sizeof(DBA_ACCESS_ST))) == (DBA_ACCESS_STP)NULL)
            {
                MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
                retCd = RET_MEM_ERR_ALLOC;
            }
        }
        else
        {
            if (((insPaExtRaStp->accessStp) = SYS_ReallocInit((insPaExtRaStp->accessStp),
                                   (size_t) insPaExtRaStp->accessNbr, (size_t) i))==NULL)
            {
                MSG_SendMesg(RET_MEM_ERR_REALLOC, 0, FILEINFO);
                retCd = RET_MEM_ERR_REALLOC;
            }
        }

        /* delete data in database */
        if (retCd == RET_SUCCEED)
        {
            if ((delDataArg = ALLOC_DYNST(Get_Arg)) == NULLDYNST)
		    {
                MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
                retCd = RET_MEM_ERR_ALLOC;
            }
            else
            {
				/* REF9125 - RAK - 030925 - Delete by PSP */
                /*
				COPY_DYNFLD(delDataArg, Get_Arg, Get_Arg_EntDictId, aPspPtr, A_PerfStorageParam, A_PerfStorageParam_EntityDictId);
                COPY_DYNFLD(delDataArg, Get_Arg, Get_Arg_ObjId, aPspPtr, A_PerfStorageParam, A_PerfStorageParam_ObjId);
				*/
				COPY_DYNFLD(delDataArg, Get_Arg, Get_Arg_ObjId, aPspPtr, A_PerfStorageParam, A_PerfStorageParam_Id);

                SET_DATETIME(delDataArg, Get_Arg_DateTime, delFromDate);
                SET_DATETIME(delDataArg, Get_Arg_DateTime2, delTillDate);

                /* REF10697 - LJE - 041028 */
                SET_FLAG_TRUE(delDataArg, Get_Arg_Flag);

                /* delete of PerfAttrib data - call proc del_perf_attrib_by_psp_d */
                if (perfFlg == TRUE)
                {
                    insPaExtRaStp->accessStp[insPaExtRaStp->accessNbr].action = Delete;
	                insPaExtRaStp->accessStp[insPaExtRaStp->accessNbr].role   = UNUSED;
	                insPaExtRaStp->accessStp[insPaExtRaStp->accessNbr].object = PerfAttrib;
	                insPaExtRaStp->accessStp[insPaExtRaStp->accessNbr].entity = Get_Arg;
	                insPaExtRaStp->accessStp[insPaExtRaStp->accessNbr].data   = delDataArg;
	                insPaExtRaStp->accessNbr++;
                }
                /* delete of global and detailed data - call proc del_ext_ra_det_by_psp_d */
	            if (retFlg == TRUE || stdPerfFlg == TRUE)
                {
                    insPaExtRaStp->accessStp[insPaExtRaStp->accessNbr].action = Delete;
	                insPaExtRaStp->accessStp[insPaExtRaStp->accessNbr].role   = DBA_ROLE_PERF_ATTRIB_RA;
	                insPaExtRaStp->accessStp[insPaExtRaStp->accessNbr].object = ExtRetAnalysis;
	                insPaExtRaStp->accessStp[insPaExtRaStp->accessNbr].entity = Get_Arg;
	                insPaExtRaStp->accessStp[insPaExtRaStp->accessNbr].data   = delDataArg;
	                insPaExtRaStp->accessNbr++;
                }

                /* delete of GIPS data - call proc del_std_perf_by_psp_d  which calls del_ext_ra_gbl_by_psp_d */
                if (stdPerfFlg == TRUE || retFlg == TRUE)
                {
                    insPaExtRaStp->accessStp[insPaExtRaStp->accessNbr].action = Delete;
	                insPaExtRaStp->accessStp[insPaExtRaStp->accessNbr].role   = UNUSED;
	                insPaExtRaStp->accessStp[insPaExtRaStp->accessNbr].object = StandardPerf;
	                insPaExtRaStp->accessStp[insPaExtRaStp->accessNbr].entity = Get_Arg;
	                insPaExtRaStp->accessStp[insPaExtRaStp->accessNbr].data   = delDataArg;
	                insPaExtRaStp->accessNbr++;
                }

				/* delete of PerfCalcResult data - call proc del_perf_calc_res_by_psp_d */
				if (pcrFlg == TRUE)
				{
					insPaExtRaStp->accessStp[insPaExtRaStp->accessNbr].action = Delete;
					insPaExtRaStp->accessStp[insPaExtRaStp->accessNbr].role = UNUSED;
					insPaExtRaStp->accessStp[insPaExtRaStp->accessNbr].object = PerfCalcResult;
					insPaExtRaStp->accessStp[insPaExtRaStp->accessNbr].entity = Get_Arg;
					insPaExtRaStp->accessStp[insPaExtRaStp->accessNbr].data = delDataArg;
					insPaExtRaStp->accessNbr++;
				}

                if (GET_FLAG(aPspPtr, A_PerfStorageParam_StorageInValidFlg) == TRUE)
                {
                    /*delete existing storage data*/
                    insPaExtRaStp->accessStp[insPaExtRaStp->accessNbr].action = Delete;
                    insPaExtRaStp->accessStp[insPaExtRaStp->accessNbr].role = UNUSED;
                    insPaExtRaStp->accessStp[insPaExtRaStp->accessNbr].object = StoragePortfolioCompo;
                    insPaExtRaStp->accessStp[insPaExtRaStp->accessNbr].entity = Get_Arg;
                    insPaExtRaStp->accessStp[insPaExtRaStp->accessNbr].data = delDataArg;
                    insPaExtRaStp->accessNbr++;
                }
            }

        }
    }

    /* update PSP in database with at least one new first and/or last date */
    if (retCd == RET_SUCCEED)
    {
        if ((insPaExtRaStp->accessSecStp) == (DBA_ACCESS_STP)NULL)
        {
            insPaExtRaStp->accessSecNbr = 0;
            if (((insPaExtRaStp->accessSecStp) = (DBA_ACCESS_STP) CALLOC(1, sizeof(DBA_ACCESS_ST))) == (DBA_ACCESS_STP)NULL)
            {
                MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
                retCd = RET_MEM_ERR_ALLOC;
            }
        }
        else
        {
            if (((insPaExtRaStp->accessSecStp) = SYS_ReallocInit((insPaExtRaStp->accessSecStp),
                                   (size_t) insPaExtRaStp->accessSecNbr, (size_t) 1))==NULL)
            {
                MSG_SendMesg(RET_MEM_ERR_REALLOC, 0, FILEINFO);
                retCd = RET_MEM_ERR_REALLOC;
            }
        }
        SET_ENUM(aPspPtr, A_PerfStorageParam_CheckedDataEn, 1);
        insPaExtRaStp->accessSecStp[insPaExtRaStp->accessSecNbr].action = Update;
	    insPaExtRaStp->accessSecStp[insPaExtRaStp->accessSecNbr].role   = DBA_ROLE_PERF_ATTRIB_RA; /* REF10276 - LJE - 040610 */
	    insPaExtRaStp->accessSecStp[insPaExtRaStp->accessSecNbr].object = PerfStorageParam;
	    insPaExtRaStp->accessSecStp[insPaExtRaStp->accessSecNbr].entity = A_PerfStorageParam;
	    insPaExtRaStp->accessSecStp[insPaExtRaStp->accessSecNbr].data   = aPspPtr;
	    insPaExtRaStp->accessSecNbr++;
    }


    return(retCd);
}



/************************************************************************
**
**  Function    :   DBA_InsertPaAndExtRaData()
**
**  Description :   Insert of data in database computed by portfolio storage
**                  or benchmark storage functions.
**                  Function is called after preparation for insert of
**                  performance attribution data or extended return analysis data.
**                  If BCP mode is used insert is done by BCP mode,
**                  otherwise standard insert by block is executed.
**
**  Arguments   :   input:
**                  domainPtr	    domain structure pointer
**                  insPaExtRaStp   pointer on insert structure
**                  maxSize         maximum size for insert
**
**                  output:
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   REF7421 - YST - 020719
**  Modification:   REF8798 - YST - 030627 - BCP
**
*************************************************************************/
RET_CODE DBA_InsertPaAndExtRaData(DBA_DYNFLD_STP       domainPtr,
                                  DBA_INSPAEXTRA_STP   insPaExtRaStp,
                                  int                  maxSize)
{
    RET_CODE       	        retCd = RET_SUCCEED, ret = RET_SUCCEED;
	DBA_ERRMSG_HEADER_ST    msgStructHead;
    FLAG_T                  bcpModeFlg = FALSE;
    void                    *blkdef = (void *)NULL;
    int	       		        size = 0;

    /* Begin multiaccess for delete PerfAttrib and ExtRetAnalysis or StandardPerf,  */
    /* update ptf, strat or instr and delete event scheduler (if exists).           */
    if (insPaExtRaStp->accessNbr < maxSize)
        size = insPaExtRaStp->accessNbr;
    else
        size = maxSize;

    MSG_LogSrvMesg(UNUSED, 0, "Start connection, first multi-access delete/update in database");

    DbiConnectionHelper dbiConnHelper(AAATransactionEnum::Transactionnal);

    /* get connection */
    if (dbiConnHelper.isValidAndInit() == false)
    {
        MSG_SendMesg(RET_DBA_ERR_CONNOTFOUND, 0, FILEINFO);
        retCd = RET_DBA_ERR_CONNOTFOUND;
    }
    else
    {
        DbiConnection  *dbiConn = dbiConnHelper.getConnection();

        /* Sort delete of PerfAttrib, ExtRetAnalysis/StandardPerf, update ptf, strat or instr, delete event scheduler */
        if (insPaExtRaStp->accessNbr > 1)
            TLS_Sort((char*)insPaExtRaStp->accessStp, insPaExtRaStp->accessNbr, sizeof(DBA_ACCESS_ST),
            (TLS_CMPFCT *)DBA_CmpInsPtfBenchStorage, (PTR**)NULL, SortRtnTp_None);

        /* to be sure add test on accessNbr */
        if (insPaExtRaStp->accessNbr > 0)
        {
            DbaMultiAccessHelper       multiAccessHelper(insPaExtRaStp->accessStp, insPaExtRaStp->accessNbr);
            retCd = multiAccessHelper.callMultiAccess(size, DBA_SET_CONN | DBA_NO_CLOSE | DBA_NO_ERROR, *dbiConn, true);

            /* Retry until succeed (3 times max) ... */
            if (retCd == RET_SRV_LIB_ERR_FATAL_DEADLOCK || retCd == RET_SRV_LIB_ERR_DEADLOCK)
            {
                int deadlockCpt = 0;
                do
                {
                    multiAccessHelper.sendAllMultiAccessMsg();

                    /* rollback */
                    dbiConnHelper.rollback();

                    if (ret == RET_SUCCEED)
                    {
                        switch (deadlockCpt)
                        {
                            case 0:
                                /* DBA_SqlExec("waitfor delay \"0:00:01\"", UNUSED, UNUSED); */
                                SYS_MilliSleep(1000); /* PMSTA-20159 - TEB - 150624  */
                                break;

                            case 1:
                                /* DBA_SqlExec("waitfor delay \"0:00:03\"", UNUSED, UNUSED); */
                                SYS_MilliSleep(3000); /* PMSTA-20159 - TEB - 150624  */
                                break;

                            case 2:
                                /* DBA_SqlExec("waitfor delay \"0:00:07\"", UNUSED, UNUSED); */
                                SYS_MilliSleep(7000); /* PMSTA-20159 - TEB - 150624  */
                                break;
                        }

                        /* be in a transaction */
                        dbiConnHelper.beginTransaction();

                        if (ret == RET_SUCCEED)
                        {
                            retCd = multiAccessHelper.callMultiAccess(size, DBA_SET_CONN | DBA_NO_CLOSE | DBA_NO_ERROR, *dbiConn, true);
                        }
                    }
                    ++deadlockCpt;
                } while (retCd != RET_SUCCEED && ret == RET_SUCCEED && deadlockCpt < 3);

                if (retCd != RET_SUCCEED)
                {
                    multiAccessHelper.sendAllMultiAccessMsg();

                    /* rollback */
                    dbiConnHelper.rollback();
                    retCd = RET_DBA_ERR_INSERT_FAILED;
                }
            }
            /* test on msgStructNbr to be sure no error is lost */
            else if ((retCd != RET_SUCCEED) || (dbiConn->emptyMsg() == false))
            {
                /* error: rollback */
                dbiConnHelper.rollback();
                multiAccessHelper.sendAllMultiAccessMsg();
                retCd = RET_DBA_ERR_INSERT_FAILED;
            }
            /* REF10693 - LJE - 041014 : Commit transaction and open a new transaction */
            else if (retCd == RET_SUCCEED)
            {
                /* commit transaction and end connection */
                dbiConnHelper.commit();
                dbiConnHelper.beginTransaction();
            }
        }

        if (retCd == RET_SUCCEED)
        {
            MSG_LogSrvMesg(UNUSED, 0, "Start insert in database");

            /* Determine if the BCP inserting mode can be used */
            /* REF9125 - RAK - 031104 - Use BCP */
            bcpModeFlg = DBA_BcpModePerfStorageFlg(); /* PMSTA15781 - DDV - 130301 - Add a new BCP mode for performance data storage */

            /* commit transaction, because BCP inserts in the same tables delete was done previously */
            if (bcpModeFlg == TRUE)
            {
                dbiConnHelper.commit();
            }

            /* Save ExtRetAnalysis records - insert by BCP or insert by block */
            if (retCd == RET_SUCCEED && insPaExtRaStp->extRaNbr > 0 && insPaExtRaStp->extRaTab != NULLDYNSTPTR)
            {
                if (bcpModeFlg == TRUE)
                {
                    if ((DBA_SaveExtRetAnalysisBCP(domainPtr, insPaExtRaStp->extRaTab, insPaExtRaStp->extRaNbr,
                                                   insPaExtRaStp->accessSecStp, insPaExtRaStp->accessSecNbr,
                                                   dbiConnHelper, blkdef)) != RET_SUCCEED)
                    {
                        bcpModeFlg = FALSE;

                        /* be in a transaction again */
                        if (dbiConnHelper.beginTransaction() != RET_SUCCEED)
                        {
                            retCd = RET_DBA_ERR_CONNOTFOUND;
                        }
                    }
                }

                /* If bcp doesn't work, insert in std mode */
                if (retCd == RET_SUCCEED && bcpModeFlg != TRUE)
                {
                    retCd = DBA_SavePaAndExtRaData(domainPtr, ExtRetAnalysis, A_ExtRetAnalysis,
                                                   insPaExtRaStp->extRaTab, insPaExtRaStp->extRaNbr, dbiConnHelper);
                }
            }

            /* Save StandardPerf records - insert by BCP or insert by block */
            if (retCd == RET_SUCCEED && insPaExtRaStp->stdPerfNbr > 0 && insPaExtRaStp->stdPerfTab != NULLDYNSTPTR)
            {
                if (bcpModeFlg == TRUE)
                {
                    if ((DBA_SaveStdPerfDateBCP(domainPtr, insPaExtRaStp->stdPerfTab, insPaExtRaStp->stdPerfNbr,
                                                insPaExtRaStp->accessSecStp, insPaExtRaStp->accessSecNbr,
                                                dbiConnHelper, blkdef)) != RET_SUCCEED)
                    {
                        bcpModeFlg = FALSE;

                        /* be in a transaction again */
                        if (dbiConnHelper.beginTransaction() != RET_SUCCEED)
                        {
                            retCd = RET_DBA_ERR_CONNOTFOUND;
                        }
                    }
                }

                if (retCd == RET_SUCCEED && bcpModeFlg != TRUE)
                {
                    retCd = DBA_SavePaAndExtRaData(domainPtr, StandardPerf, A_StandardPerf,
                                                   insPaExtRaStp->stdPerfTab, insPaExtRaStp->stdPerfNbr, dbiConnHelper);
                }
            }

            /* Save PerfAttrib records - insert by block (BCP currently not coded) */
            if (retCd == RET_SUCCEED && insPaExtRaStp->paNbr > 0 && insPaExtRaStp->paTab != NULLDYNSTPTR)
            {
                /* REF9924 - LJE - 040213 */
                if (bcpModeFlg == TRUE)
                {
                    if ((DBA_SavePaBCP(domainPtr, insPaExtRaStp->paTab, insPaExtRaStp->paNbr,
                                       insPaExtRaStp->accessSecStp, insPaExtRaStp->accessSecNbr,
                                       dbiConnHelper, blkdef)) != RET_SUCCEED)
                    {
                        bcpModeFlg = FALSE;

                        /* be in a transaction again */
                        if (dbiConnHelper.beginTransaction() != RET_SUCCEED)
                        {
                            retCd = RET_DBA_ERR_CONNOTFOUND;
                        }
                    }
                }

                if (retCd == RET_SUCCEED && bcpModeFlg != TRUE)
                {
                    retCd = DBA_SavePaAndExtRaData(domainPtr, PerfAttrib, A_PerfAttrib,
                                                   insPaExtRaStp->paTab, insPaExtRaStp->paNbr, dbiConnHelper);
                }
            }

			if (retCd == RET_SUCCEED && insPaExtRaStp->PerfCalcResNbr > 0 && insPaExtRaStp->PerfCalcResTab != NULLDYNSTPTR)
			{
                if ((DBA_SavePerfCalcResult(domainPtr,
                                            insPaExtRaStp->PerfCalcResTab,
                                            insPaExtRaStp->PerfCalcResNbr,
                                            dbiConnHelper)) != RET_SUCCEED)
				{
					/* be in a transaction again */
					if (dbiConnHelper.beginTransaction() != RET_SUCCEED)
					{
						retCd = RET_DBA_ERR_CONNOTFOUND;
					}
				}
			}

            if (retCd == RET_SUCCEED && bcpModeFlg == TRUE)
            {
                /* be in a transaction again */
                if (dbiConnHelper.beginTransaction() != RET_SUCCEED)
                {
                    retCd = RET_DBA_ERR_CONNOTFOUND;
                }
            }

            /* update Ptf and PSP: firstStoredDates, lastStoredDates and checkedDataEn = 1 *//* REF8874 - YST - 030612 */
            if (retCd == RET_SUCCEED)
            {
                DbaMultiAccessHelper       multiAccessHelper(insPaExtRaStp->accessSecStp, insPaExtRaStp->accessSecNbr);

                if (insPaExtRaStp->accessSecNbr > 0 &&
                    multiAccessHelper.callMultiAccess(size, DBA_SET_CONN | DBA_NO_CLOSE | DBA_NO_ERROR, *dbiConn, true) != RET_SUCCEED)
                {
                    DICT_FCT_STP		    dictFctInfo;

                    DBA_GetDictFctInfo(GET_ID(domainPtr, A_Domain_InitialFctDictId), DictFctInfo_Stp, &dictFctInfo);  /*  FPL-PMSTA08801-100714 cast  */

                    /* error: rollback */
                    dbiConnHelper.rollback();

                    multiAccessHelper.sendAllMultiAccessMsg();
                    MSG_LogSrvMesg(UNUSED, 0, "%1: errors while updating PerfStorageParam data",
                                   NameType, dictFctInfo->name);

                    retCd = RET_DBA_ERR_INSERT_FAILED;
                }
            }

            if (retCd == RET_SUCCEED)
            {
                /* commit transaction and end connection */
                dbiConnHelper.commit();
            }
        }
    }

    MSG_LogSrvMesg(UNUSED, 0, "End insert in database");

    return(retCd);
}




/************************************************************************
**
**  Function    :   DBA_SavePAandExtRAData()
**
**  Description :   Insert by block of data in database computed by
**                  portfolio storage or benchmark storage functions.
**                  Function is called for insert of PerfAttrib and
**                  ExtRetAnalysis or StandardPerf records if BCP mode
**                  is not setted or insert with BCP mode failed.
**
**  Arguments   :   input:
**                  domainPtr	    domain structure pointer
**                  objEnum         OBJECT_ENUM of recordTab
**                  dynStEnum       DBA_DYNST_ENUM of recordTab
**                  recordTab       pointer on record table
**                  recordNbr       number of records
**
**                  output:
**                  connectNo  connection number
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   REF7421 - YST - 020719
**
*************************************************************************/
STATIC RET_CODE DBA_SavePaAndExtRaData(DBA_DYNFLD_STP    domainPtr,
                                    OBJECT_ENUM          objEnum,
                                    DBA_DYNST_ENUM       dynStEnum,
                                    DBA_DYNFLD_STP      *recordTab,
                                    int                  recordNbr,
                                    DbiConnectionHelper &dbiConnHelper)
{
    RET_CODE       	        retCd = RET_SUCCEED;
    DICT_FCT_STP		    dictFctInfo;
    SYSNAME_T               entSqlName;

    DbiConnection          *dbiConn = dbiConnHelper.getConnection();

    DBA_GetDictFctInfo(GET_DICT(domainPtr, A_Domain_InitialFctDictId), DictFctInfo_Stp, &dictFctInfo);
    strcpy(entSqlName, DBA_GetDictEntitySqlName(objEnum));

    retCd = DBA_InsertByBlock(objEnum,
                              UNUSED,
                              dynStEnum,
                              recordTab,
                              recordNbr,
                              DBA_SET_CONN | DBA_IN_TRAN | DBA_NO_CLOSE,
                              *dbiConn,
                              UNUSED);

	/* Retry until succeed (3 times max) ... */
    if (retCd == RET_SRV_LIB_ERR_FATAL_DEADLOCK || retCd == RET_SRV_LIB_ERR_DEADLOCK)
    {
        int deadlockCpt = 0, ret = RET_SUCCEED;
        do
        {
            /* Last errors */
            dbiConn->sendAllMsgFromMA();

            /* rollback */
            dbiConnHelper.rollback();

            if (ret == RET_SUCCEED)
            {
                switch (deadlockCpt)
				{
				case 0:
					/* DBA_SqlExec("waitfor delay \"0:00:01\"", UNUSED, UNUSED); */
					SYS_MilliSleep(1000); /* PMSTA-20159 - TEB - 150624  */
					break;

				case 1:
					/* DBA_SqlExec("waitfor delay \"0:00:03\"", UNUSED, UNUSED); */
					SYS_MilliSleep(3000); /* PMSTA-20159 - TEB - 150624  */
					break;

				case 2:
					/* DBA_SqlExec("waitfor delay \"0:00:07\"", UNUSED, UNUSED); */
					SYS_MilliSleep(7000); /* PMSTA-20159 - TEB - 150624  */
					break;
				}

                /* be in a transaction */
	            ret = dbiConnHelper.beginTransaction();

	            if (ret == RET_SUCCEED)
	            {
                    retCd = DBA_InsertByBlock(objEnum,
                                              UNUSED,
                                              dynStEnum,
                                              recordTab,
                                              recordNbr,
                                              DBA_SET_CONN | DBA_IN_TRAN | DBA_NO_CLOSE,
                                              *dbiConn,
                                              UNUSED);
                }
            }
            ++deadlockCpt;
        }
        while (retCd != RET_SUCCEED && ret == RET_SUCCEED && deadlockCpt < 3);

        if (retCd != RET_SUCCEED)
        {
            MSG_LogSrvMesg(UNUSED, 0, "%1: errors while saving %2 data (%3 records)",
                        NameType, dictFctInfo->name, SysnameType, entSqlName, IntType, recordNbr);

            dbiConn->sendAllMsgFromMA();

            /* rollback */
            dbiConnHelper.rollback();
            retCd = RET_DBA_ERR_INSERT_FAILED;
        }
        else
        {
            MSG_LogSrvMesg(UNUSED, 0, "%1: saving %2 data (%3 records) succeeded",
		               NameType, dictFctInfo->name, SysnameType, entSqlName, IntType, recordNbr);
        }
    }
	/* test on msgStructNbr to be sure no error is lost */
	else if ( (retCd != RET_SUCCEED) || (dbiConn->emptyMsg() == false))
	{
		/* error: rollback */
        dbiConnHelper.rollback();

        MSG_LogSrvMesg(UNUSED, 0, "%1: errors while saving %2 data (%3 records)",
                        NameType, dictFctInfo->name, SysnameType, entSqlName, IntType, recordNbr);

        dbiConn->sendAllMsgFromMA();

        retCd = RET_DBA_ERR_INSERT_FAILED;
	}
    else
    {
	    MSG_LogSrvMesg(UNUSED, 0, "%1: saving %2 data (%3 records) succeeded",
		               NameType, dictFctInfo->name, SysnameType, entSqlName, IntType, recordNbr);
	}

    return(retCd);
}

/************************************************************************
**
**  Function    :   DBA_SaveExtRetAnalysisBCP()
**
**  Description :   Insert of data in database computed by portfolio storage.
**                  Function is called for insert of ExtRetAnalysis in BCP mode.
**                  1. Insert of RetAnalysisId, get id
**                  2. Copy ExtRetAnalysis and RetAnalysisId to following tables:
**                     - if global data:
**                          copy to StdPerfData and RetAnaGlobal
**                     - if detailed:
**                          copy to RetAnaDetailed
**                     and Ud table fo ExtRetAnalysis
**                  3. Call for each filled table DBA_SaveStdPerfRaBCP()
**                     to do insert by BCP
**
**
**  Arguments   :   input:
**                  domainPtr	    domain structure pointer
**                  objEnum         OBJECT_ENUM of recordTab
**                  dynStEnum       DBA_DYNST_ENUM of recordTab
**                  recordTab       pointer on record table
**                  recordNbr       number of records
**                  objName         dynamic structure name of recordTab
**                  connectNo       connection number for BCP mode
**                  blkdef          pointer on bulk for BCP mode insert
**
**                  output:
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   REF8798 - YST - 030603
**
*************************************************************************/
STATIC RET_CODE DBA_SaveExtRetAnalysisBCP(DBA_DYNFLD_STP     domainPtr,
                                          DBA_DYNFLD_STP      *recordTab,
                                          int                  recordNbr,
                                          DBA_ACCESS_ST       *accessTab,
                                          int                  accessNbr,
                                          DbiConnectionHelper &dbiConnHelper,
                                          void                *blkdef)
{
    RET_CODE                retCd = RET_SUCCEED;
    DBA_DYNFLD_STP          retAnalysisIdStp = NULL, *stdPerfDataTab = NULL, *stdPerfTab = NULL, /* REF10392 - LJE - 040624 */
        *retAnaGlobalTab = NULL, *retAnaDetailedTab = NULL;
    int                     i = 0, raGlobalNbr = 0, raDetailedNbr = 0, firstExtRaUdIx = 0;
    ID_T                    nextId = 0;

    if ((retAnalysisIdStp = ALLOC_DYNST(S_RetAnalysisId)) == NULL)
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    SET_INT(retAnalysisIdStp, S_RetAnalysisId_BlockSize, 0);

    if (retCd == RET_SUCCEED)
    {
        /* REF10392 - LJE - 040624 */
        if ((stdPerfTab = (DBA_DYNFLD_STP *)CALLOC(recordNbr, sizeof(DBA_DYNFLD_STP))) == NULL)
        {
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }
        if ((stdPerfDataTab = (DBA_DYNFLD_STP *)CALLOC(recordNbr, sizeof(DBA_DYNFLD_STP))) == NULL)
        {
            FREE(stdPerfTab);
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }
        if ((retAnaGlobalTab = (DBA_DYNFLD_STP *)CALLOC(recordNbr, sizeof(DBA_DYNFLD_STP))) == NULL)
        {
            FREE(stdPerfTab);
            FREE(stdPerfDataTab);
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }
        if ((retAnaDetailedTab = (DBA_DYNFLD_STP *)CALLOC(recordNbr, sizeof(DBA_DYNFLD_STP))) == NULL)
        {
            FREE(stdPerfTab);
            FREE(stdPerfDataTab);
            FREE(retAnaGlobalTab);
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }
        firstExtRaUdIx = DBA_GetFirstCustFld(ExtRetAnalysis); /* PMSTA-11505 - LJE - 110615 */

        for (i = 0; i < recordNbr; i++)
        {
            if (GET_INT(retAnalysisIdStp, S_RetAnalysisId_BlockSize) == 0)
            {
                SET_INT(retAnalysisIdStp, S_RetAnalysisId_BlockSize, recordNbr - i);
                retCd = dbiConnHelper.dbaGet(RetAnalysisId,
                                             UNUSED,
                                             retAnalysisIdStp,
                                             &retAnalysisIdStp);

                nextId = GET_ID(retAnalysisIdStp, S_RetAnalysisId_Id);
            }

            /* copy id for insert ud-defined fields - table ud_ext_ret_analysis */
            SET_ID(recordTab[i], A_ExtRetAnalysis_Id, nextId);
            nextId++;
            SET_INT(retAnalysisIdStp, S_RetAnalysisId_BlockSize, GET_INT(retAnalysisIdStp, S_RetAnalysisId_BlockSize) - 1);

            COPY_DYNFLD(recordTab[i], A_ExtRetAnalysis, firstExtRaUdIx,
                        recordTab[i], A_ExtRetAnalysis, A_ExtRetAnalysis_Id);

            /* Set Default Values described in MD */
            DBA_SetDfltEntityFld(ExtRetAnalysis, A_ExtRetAnalysis, recordTab[i]);

            /* global data - StandardPerfData and RetAnalysisGlobal */
            if (IS_NULLFLD(recordTab[i], A_ExtRetAnalysis_MktSegtId) == TRUE &&
                IS_NULLFLD(recordTab[i], A_ExtRetAnalysis_InstrId) == TRUE)
            {
                /* REF10392 - LJE - 040624 */
                if ((stdPerfTab[raGlobalNbr] = ALLOC_DYNST(A_StandardPerf)) == NULL)
                {
                    FREE(stdPerfTab);
                    FREE(stdPerfDataTab);
                    FREE(retAnaGlobalTab);
                    FREE(retAnaDetailedTab);
                    MSG_RETURN(RET_MEM_ERR_ALLOC);
                }
                if ((stdPerfDataTab[raGlobalNbr] = ALLOC_DYNST(A_StdPerfData)) == NULL)
                {
                    FREE(stdPerfTab);
                    FREE(stdPerfDataTab);
                    FREE(retAnaGlobalTab);
                    FREE(retAnaDetailedTab);
                    MSG_RETURN(RET_MEM_ERR_ALLOC);
                }
                if ((retAnaGlobalTab[raGlobalNbr] = ALLOC_DYNST(A_RetAnaGlobal)) == NULL)
                {
                    FREE(stdPerfTab);
                    FREE(stdPerfDataTab);
                    FREE(retAnaGlobalTab);
                    FREE(retAnaDetailedTab);
                    MSG_RETURN(RET_MEM_ERR_ALLOC);
                }

                CONVERT_DYNST(retAnaGlobalTab[raGlobalNbr], A_RetAnaGlobal, recordTab[i], A_ExtRetAnalysis);

                CONVERT_DYNST(stdPerfDataTab[raGlobalNbr], A_StdPerfData, recordTab[i], A_ExtRetAnalysis);

                /* REF10392 - LJE - 040624 */
                CONVERT_DYNST(stdPerfTab[raGlobalNbr], A_StandardPerf, recordTab[i], A_ExtRetAnalysis);

                raGlobalNbr++;
            }
            /* detailed data - RetAnalysisDetailed */
            else
            {
                if ((retAnaDetailedTab[raDetailedNbr] = ALLOC_DYNST(A_RetAnaDetailed)) == NULL)
                {
                    FREE(stdPerfDataTab);
                    FREE(retAnaGlobalTab);
                    FREE(retAnaDetailedTab);
                    MSG_RETURN(RET_MEM_ERR_ALLOC);
                }

                CONVERT_DYNST(retAnaDetailedTab[raDetailedNbr], A_RetAnaDetailed, recordTab[i], A_ExtRetAnalysis);

                raDetailedNbr++;
            }
        }

        /* insert global data by BCP */
        if (raGlobalNbr > 0)
        {
            retCd = DBA_SaveStdPerfRaBCP(domainPtr, StdPerfData, A_StdPerfData, "StdPerfData",
                                         stdPerfDataTab, raGlobalNbr, accessTab, accessNbr, DBA_BCP_INS_ID,
                                         dbiConnHelper, blkdef);

            if (retCd == RET_SUCCEED)
            {
                retCd = DBA_SaveStdPerfRaBCP(domainPtr, RetAnaGlobal, A_RetAnaGlobal, "RetAnaGlobal",
                                             retAnaGlobalTab, raGlobalNbr, accessTab, accessNbr, DBA_BCP_INS_ID,
                                             dbiConnHelper, blkdef);
            }
        }

        /* insert detailed data by BCP */
        if (retCd == RET_SUCCEED && raDetailedNbr > 0)
        {
            retCd = DBA_SaveStdPerfRaBCP(domainPtr, RetAnaDetailed, A_RetAnaDetailed, "RetAnaDetailed",
                                         retAnaDetailedTab, raDetailedNbr, accessTab, accessNbr, DBA_BCP_INS_ID,
                                         dbiConnHelper, blkdef);
        }

        /* insert ud-defined fields by BCP (insert in table ud_standard_perf_data) */
        if (retCd == RET_SUCCEED && raGlobalNbr > 0)
        {
            /* REF10392 - LJE - 040624 : Use standard_perf for ud fields */
            retCd = DBA_SaveStdPerfRaBCP(domainPtr, StandardPerf, A_StandardPerf, "Ud_StdPerfData",
                                         stdPerfTab, raGlobalNbr, accessTab, accessNbr, DBA_BCP_INS_UD_FLD,
                                         dbiConnHelper, blkdef);
        }

        /* insert ud-defined fields by BCP (insert in table ud_ext_ret_analysis) */
        if (retCd == RET_SUCCEED)
        {
            retCd = DBA_SaveStdPerfRaBCP(domainPtr, ExtRetAnalysis, A_ExtRetAnalysis, "Ud_ExtRetAnalysis", /* REF???? - LJE - 040303 */
                                         recordTab, recordNbr, accessTab, accessNbr, DBA_BCP_INS_UD_FLD,
                                         dbiConnHelper, blkdef);
        }

        DBA_FreeDynStTab(stdPerfTab, recordNbr, A_StandardPerf);        /* REF10392 - LJE - 040624 */
        DBA_FreeDynStTab(stdPerfDataTab, recordNbr, A_StdPerfData);
        DBA_FreeDynStTab(retAnaGlobalTab, recordNbr, A_RetAnaGlobal);
        DBA_FreeDynStTab(retAnaDetailedTab, recordNbr, A_RetAnaDetailed);
    }

    FREE_DYNST(retAnalysisIdStp, S_RetAnalysisId);

    return(retCd);
}


/************************************************************************
**
**  Function    :   DBA_SaveStdPerfDateBCP()
**
**  Description :   Insert of data in database computed by portfolio storage.
**                  Function is called for insert of StandardPerf in BCP mode.
**                  1. Insert of RetAnalysisId, get id
**                  2. Copy StandardPerf and RetAnalysisId to StdPerfData and
**                     Ud_StdPerfData tables
**                  3. Call for each filled table DBA_SaveStdPerfRaBCP()
**                     to do insert by BCP
**
**  Arguments   :   input:
**                  domainPtr	    domain structure pointer
**                  objEnum         OBJECT_ENUM of recordTab
**                  dynStEnum       DBA_DYNST_ENUM of recordTab
**                  recordTab       pointer on record table
**                  recordNbr       number of records
**                  objName         dynamic structure name of recordTab
**                  connectNo connection number for BCP mode
**                  blkdef          pointer on bulk for BCP mode insert
**
**                  output:
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   REF8798 - YST - 030603
**
*************************************************************************/
STATIC RET_CODE DBA_SaveStdPerfDateBCP(DBA_DYNFLD_STP      domainPtr,
                                       DBA_DYNFLD_STP      *recordTab,
                                       int                 recordNbr,
                                       DBA_ACCESS_ST       *accessTab,
                                       int                 accessNbr,
                                       DbiConnectionHelper &dbiConnHelper,
                                       void                *blkdef)
{
    RET_CODE                retCd = RET_SUCCEED;
    DBA_DYNFLD_STP          retAnalysisIdStp, *stdPerfDataTab;
    int                     i = 0, firstStdPerfUdIx;
    ID_T                    nextId = 0;

    if ((retAnalysisIdStp = ALLOC_DYNST(S_RetAnalysisId)) == NULL)
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    SET_INT(retAnalysisIdStp, S_RetAnalysisId_BlockSize, 0);

    if ((stdPerfDataTab = (DBA_DYNFLD_STP *)CALLOC(recordNbr, sizeof(DBA_DYNFLD_STP))) == NULL)
    {
        FREE_DYNST(retAnalysisIdStp, S_RetAnalysisId);
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    firstStdPerfUdIx = DBA_GetFirstCustFld(StandardPerf); /* REF9924 - LJE - 040213 */ /* PMSTA-11505 - LJE - 110615 */

    for (i = 0; i < recordNbr; i++)
    {
        if ((stdPerfDataTab[i] = ALLOC_DYNST(A_StdPerfData)) == NULL)
        {
            FREE_DYNST(retAnalysisIdStp, S_RetAnalysisId);
            FREE(stdPerfDataTab);
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        if (GET_INT(retAnalysisIdStp, S_RetAnalysisId_BlockSize) == 0)
        {
            SET_INT(retAnalysisIdStp, S_RetAnalysisId_BlockSize, recordNbr - i);
            retCd = dbiConnHelper.dbaGet(RetAnalysisId,
                                         UNUSED,
                                         retAnalysisIdStp,
                                         &retAnalysisIdStp);

            nextId = GET_ID(retAnalysisIdStp, S_RetAnalysisId_Id);
        }

        /* copy id for insert ud-defined fields - table ud_ext_ret_analysis */
        SET_ID(recordTab[i], A_StandardPerf_Id, nextId);
        SET_ID(recordTab[i], firstStdPerfUdIx, nextId);
        nextId++;
        SET_INT(retAnalysisIdStp, S_RetAnalysisId_BlockSize, GET_INT(retAnalysisIdStp, S_RetAnalysisId_BlockSize) - 1);

        /* Set Default Values described in MD */
        DBA_SetDfltEntityFld(StandardPerf, A_StandardPerf, recordTab[i]);

        CONVERT_DYNST(stdPerfDataTab[i], A_StdPerfData, recordTab[i], A_StandardPerf);
    }

    retCd = DBA_SaveStdPerfRaBCP(domainPtr, StdPerfData, A_StdPerfData, "StdPerfData",
                                 stdPerfDataTab, recordNbr, accessTab, accessNbr, DBA_BCP_INS_ID,
                                 dbiConnHelper, blkdef);

    /* insert ud-defined fields by BCP (insert in table ud_std_perf_data) */
    if (retCd == RET_SUCCEED)
    {
        /* REF10392 - LJE - 040624 : Use standard_perf for ud fields */
        retCd = DBA_SaveStdPerfRaBCP(domainPtr, StandardPerf, A_StandardPerf, "Ud_StdPerfData",
                                     recordTab, recordNbr, accessTab, accessNbr, DBA_BCP_INS_UD_FLD,
                                     dbiConnHelper, blkdef);
    }

    DBA_FreeDynStTab(stdPerfDataTab, recordNbr, A_StdPerfData);
    FREE_DYNST(retAnalysisIdStp, S_RetAnalysisId);

    return(retCd);
}

/************************************************************************
**
**  Function    :   DBA_SavePerfCalcResult()
**
**  Description :   Insert of data in database computed by portfolio storage.
**                  Function is called for insert of perf_calc_result in BCP mode.
**
**  Arguments   :   input:
**                  domainPtr	    domain structure pointer
**                  objEnum         OBJECT_ENUM of recordTab
**                  dynStEnum       DBA_DYNST_ENUM of recordTab
**                  recordTab       pointer on record table
**                  recordNbr       number of records
**                  objName         dynamic structure name of recordTab
**                  connectNo connection number for BCP mode
**                  blkdef          pointer on bulk for BCP mode insert
**
**                  output:
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   PMSTA-48078 - SENTHIL KUMAR - 15122022
**
*************************************************************************/
STATIC RET_CODE DBA_SavePerfCalcResult(DBA_DYNFLD_STP      domainPtr,
                                        DBA_DYNFLD_STP* recordTab,
                                        int                 recordNbr,
                                        DbiConnectionHelper& dbiConnHelper)
{
	RequestHelper   requestHelper(dbiConnHelper); // Create RequestHelper by using existing connection

	auto PerfCalcResultEntityStp = DBA_GetDictEntitySt(PerfCalcResult);

	requestHelper.setBatchInfo(PerfCalcResultEntityStp->databaseName, PerfCalcResultEntityStp->dbSqlName, PerfCalcResult);

	for (int i = 0; i < recordNbr; i++)
	{
		SET_NULL_ID(recordTab[i], A_PerfCalcResult_Id);
		requestHelper.setNewRecordForBatch(recordTab[i]);
	}
	requestHelper.executeBatch();

    /* WEALTH-4651 - DDV - 240222 - Add information in server.log */
    DICT_FCT_STP		    dictFctInfo(nullptr);
    DBA_GetDictFctInfo(GET_DICT(domainPtr, A_Domain_InitialFctDictId), DictFctInfo_Stp, &dictFctInfo);

    RET_CODE   ret = requestHelper.getLastRetCode();
    if (ret != RET_SUCCEED)
    {
        MSG_LogSrvMesg(UNUSED, 0, "%1: errors while saving %2 data (%3 records)",
            NameType, dictFctInfo->name, SysnameType, "perf_calc_result", IntType, recordNbr);

        dbiConnHelper.rollback();
        ret = RET_DBA_ERR_INSERT_FAILED;
    }
    else
    {
        MSG_LogSrvMesg(UNUSED, 0, "%1: saving %2 data (%3 records) succeeded",
            NameType, dictFctInfo->name, SysnameType, "perf_calc_result", IntType, recordNbr);
    }
    
    return(ret);
}

/************************************************************************
**
**  Function    :   DBA_SavePaBCP()
**
**  Description :   Insert of data in database computed by portfolio storage
**                  or benchmark storage functions.
**                  Function is called for insert of PerfAttrib
**                  records (already splitted in tables
**                  PerfAttribData, and Ud tables) in BCP mode.
**                  If insert fails delete data already inserted.
**
**  Arguments   :   input:
**                  domainPtr	    domain structure pointer
**                  objEnum         OBJECT_ENUM of recordTab
**                  dynStEnum       DBA_DYNST_ENUM of recordTab
**                  recordTab       pointer on record table
**                  recordNbr       number of records
**                  objName         dynamic structure name of recordTab
**                  connectNo connection number for BCP mode
**                  blkdef          pointer on bulk for BCP mode insert
**
**                  output:
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   REF9924 - LJE - 040213
**
*************************************************************************/
STATIC RET_CODE DBA_SavePaBCP(DBA_DYNFLD_STP      domainPtr,
                              DBA_DYNFLD_STP      *recordTab,
                              int                 recordNbr,
                              DBA_ACCESS_ST       *accessTab,
                              int                 accessNbr,
                              DbiConnectionHelper &dbiConnHelper,
                              void                *blkdef)
{
    RET_CODE                retCd = RET_SUCCEED;
    DBA_DYNFLD_STP          perfAttribIdStp, *perfAttribDataTab;
    int                     i = 0, firstPAUdIx;
    ID_T                    nextId=0;

    if ((perfAttribIdStp = ALLOC_DYNST(S_PerfAttribId)) == NULL)
        {
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

    SET_INT(perfAttribIdStp, S_PerfAttribId_BlockSize, 0);

        if ((perfAttribDataTab = (DBA_DYNFLD_STP *)CALLOC(recordNbr, sizeof(DBA_DYNFLD_STP))) == NULL)
		{
        FREE_DYNST(perfAttribIdStp, S_PerfAttribId);
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        firstPAUdIx = DBA_GetFirstCustFld(PerfAttrib);

        for (i=0; i<recordNbr; i++)
        {
            if ((perfAttribDataTab[i] = ALLOC_DYNST(A_PerfAttribData)) == NULL)
            {
            FREE_DYNST(perfAttribIdStp, S_PerfAttribId);
                FREE(perfAttribDataTab);
                MSG_RETURN(RET_MEM_ERR_ALLOC);
            }

        if (GET_INT(perfAttribIdStp, S_PerfAttribId_BlockSize) == 0)
        {
            SET_INT(perfAttribIdStp, S_PerfAttribId_BlockSize, recordNbr-i);
            retCd = dbiConnHelper.dbaGet(PerfAttribId,
                                         UNUSED,
                                         perfAttribIdStp,
                                         &perfAttribIdStp);
            nextId = GET_ID(perfAttribIdStp, S_PerfAttribId_Id);
        }

        /* copy id for insert ud-defined fields - table ud_ext_ret_analysis */
        SET_ID(recordTab[i], A_PerfAttrib_Id, nextId);
        SET_ID(recordTab[i], firstPAUdIx,  nextId);
        nextId++;
        SET_INT(perfAttribIdStp, S_PerfAttribId_BlockSize, GET_INT(perfAttribIdStp, S_PerfAttribId_BlockSize)-1);

			/* Set Default Values described in MD */
            DBA_SetDfltEntityFld(PerfAttrib, A_PerfAttrib, recordTab[i]);

            CONVERT_DYNST(perfAttribDataTab[i], A_PerfAttribData, recordTab[i], A_PerfAttrib);

	    }

        retCd = DBA_SaveStdPerfRaBCP(domainPtr, PerfAttribData, A_PerfAttribData, "PerfAttribData",
                                     perfAttribDataTab, recordNbr, accessTab, accessNbr, DBA_BCP_INS_ID,
                                     dbiConnHelper, blkdef);

        /* insert ud-defined fields by BCP (insert in table ud_perf_attrib) */
        if (retCd == RET_SUCCEED)
        {
            /* REF10392 - LJE - 040624 : Use perf_attrib for ud fields */
            retCd = DBA_SaveStdPerfRaBCP(domainPtr, PerfAttrib, A_PerfAttrib, "Ud_PerfAttribData",
                                         recordTab, recordNbr, accessTab, accessNbr, DBA_BCP_INS_UD_FLD,
                                         dbiConnHelper, blkdef);
        }

        DBA_FreeDynStTab(perfAttribDataTab, recordNbr, A_PerfAttribData);
    FREE_DYNST(perfAttribIdStp, S_PerfAttribId);

    return(retCd);
}

/************************************************************************
**
**  Function    :   DBA_SaveStdPerfRaBCP()
**
**  Description :   Insert of data in database computed by portfolio storage
**                  or benchmark storage functions.
**                  Function is called for insert of ExtRetAnalysis or
**                  StandardPerf records (already splitted in tables
**                  StdPerfData, RetAnalysisGlobal, RetAnalysisDetailed
**                  and Ud tables) in BCP mode.
**                  If insert fails delete data already inserted.
**
**  Arguments   :   input:
**                  domainPtr	    domain structure pointer
**                  objEnum         OBJECT_ENUM of recordTab
**                  dynStEnum       DBA_DYNST_ENUM of recordTab
**                  recordTab       pointer on record table
**                  recordNbr       number of records
**                  objName         dynamic structure name of recordTab
**                  connectNo connection number for BCP mode
**                  blkdef          pointer on bulk for BCP mode insert
**
**                  output:
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   REF8798 - YST - 030603
**
*************************************************************************/
STATIC RET_CODE DBA_SaveStdPerfRaBCP(DBA_DYNFLD_STP       domainPtr,
                                    OBJECT_ENUM           objEnum,
                                    DBA_DYNST_ENUM        dynStEnum,
                                    const char           *objName,
                                    DBA_DYNFLD_STP       *recordTab,
                                    int                   recordNbr,
                                    DBA_ACCESS_ST        *accessTab,
                                    int                   accessNbr,
                                    int                   insOption,
                                     DbiConnectionHelper &dbiConnHelper,
                                    void                 *blkdef)
{
    RET_CODE       	        retCd = RET_SUCCEED;
    DICT_FCT_STP		    dictFctInfo;
    int	       		        outNbr = 0;

    DBA_GetDictFctInfo(GET_DICT(domainPtr, A_Domain_InitialFctDictId), DictFctInfo_Stp, &dictFctInfo);

    /* Initialise the bulk copy structure */
    if ((retCd = DBA_BcpInitEntity(objEnum, dynStEnum, insOption, *dbiConnHelper.getConnection(), &blkdef)) != RET_SUCCEED)
    {
        MSG_SendMesg(RET_SRV_LIB_ERR_GENERAL, 0, FILEINFO,
			                "REPORTING: Bulk Copy INSERT failed. Insert in SQL block mode will be used.");
    }
    else
    {
        /* For each record, save an occurence in database */
        for (int i=0; i<recordNbr && retCd == RET_SUCCEED; i++)
	    {
		    outNbr=0;
		    retCd = DBA_BcpInsert(recordTab[i], blkdef, &outNbr, objName);
	    }

        /* Insert the last block and free the bcp structure */
        if (retCd == RET_SUCCEED)
        {
	        outNbr=0;
	        retCd = DBA_BcpEnd(blkdef, &outNbr, objName);
        }

		if (retCd != RET_SUCCEED)
        {
            DBA_ACCESS_STP  accessDelStp = NULL;
            int             j = 0, delNbr = 0;

            if (StdPerfData == objEnum)
                delNbr = accessNbr;
            else if (RetAnaGlobal == objEnum)
                delNbr = 2*accessNbr;
            else
                delNbr = 3*accessNbr;

            if ((accessDelStp = (DBA_ACCESS_STP)CALLOC(delNbr, sizeof(DBA_ACCESS_ST))) == (DBA_ACCESS_STP)NULL)
                MSG_RETURN(RET_MEM_ERR_ALLOC);

            for (int i=0; i<accessNbr; i++)
            {
                if (accessTab[i].entity == A_PerfStorageParam)
                {
                    /*YSTtodo if (GET_FLAG(accessTab[i], A_PerfStorageParam_RetAnalysisFlg) == TRUE) */

                    if ((accessDelStp[j].data = ALLOC_DYNST(Get_Arg)) == NULL)
                    {
                        FREE(accessDelStp);
		                MSG_RETURN(RET_MEM_ERR_ALLOC);
                    }

					/* REF9125 - RAK - 090325 */
					/*
                    COPY_DYNFLD(accessDelStp[j].data, Get_Arg, Get_Arg_EntDictId,
                                accessTab[i].data, A_PerfStorageParam, A_PerfStorageParam_EntityDictId);

                    COPY_DYNFLD(accessDelStp[j].data, Get_Arg, Get_Arg_ObjId,
                                accessTab[i].data, A_PerfStorageParam, A_PerfStorageParam_ObjId);
					*/
					COPY_DYNFLD(accessDelStp[j].data, Get_Arg, Get_Arg_ObjId,
                                accessTab[i].data, A_PerfStorageParam, A_PerfStorageParam_Id);

                    COPY_DYNFLD(accessDelStp[j].data, Get_Arg, Get_Arg_DateTime,
                                accessTab[i].data, A_PerfStorageParam, A_PerfStorageParam_StdPerfFirstStoredDate);

                    COPY_DYNFLD(accessDelStp[j].data, Get_Arg, Get_Arg_DateTime2,
                                accessTab[i].data, A_PerfStorageParam, A_PerfStorageParam_StdPerfLastStoredDate);

                    /* delete of GIPS data - call proc del_std_perf_by_psp_d */
                    accessDelStp[j].action = Delete;
	                accessDelStp[j].role   = UNUSED;
	                accessDelStp[j].object = StandardPerf;
	                accessDelStp[j].entity = Get_Arg;
                    j++;

                    /* delete of global data - call proc del_ext_ra_gbl_by_psp_d */
                    if (StdPerfData != objEnum)
                    {
						/* REF9771 - RAK - 040108 */
						/* We have to allocate one Get_Arg by delete because First and Last date can be different */
						if ((accessDelStp[j].data = ALLOC_DYNST(Get_Arg)) == NULL)
						{
							FREE(accessDelStp);
							MSG_RETURN(RET_MEM_ERR_ALLOC);
						}

                        accessDelStp[j].action = Delete;
	                    accessDelStp[j].role   = UNUSED;
	                    accessDelStp[j].object = ExtRetAnalysis;
	                    accessDelStp[j].entity = Get_Arg;

						/* REF9771 - RAK - 040108 */
                        /* accessDelStp[j].data   = accessDelStp[j-1].data; */
                        COPY_DYNFLD(accessDelStp[j].data, Get_Arg, Get_Arg_ObjId,
                                accessTab[i].data, A_PerfStorageParam, A_PerfStorageParam_Id);

						COPY_DYNFLD(accessDelStp[j].data, Get_Arg, Get_Arg_DateTime,
                                accessTab[i].data, A_PerfStorageParam, A_PerfStorageParam_RetFirstStoredDate);

                        COPY_DYNFLD(accessDelStp[j].data, Get_Arg, Get_Arg_DateTime2,
                                accessTab[i].data, A_PerfStorageParam, A_PerfStorageParam_RetLastStoredDate);
                        j++;
                    }

                    /* delete of detailed data - call proc del_ext_ra_det_by_psp_d */
                    if (StdPerfData != objEnum && RetAnaGlobal != objEnum)
                    {
						/* REF9771 - RAK - 040108 */
						/* We have to allocate one Get_Arg by delete because First and Last date can be different */
						if ((accessDelStp[j].data = ALLOC_DYNST(Get_Arg)) == NULL)
						{
							FREE(accessDelStp);
							MSG_RETURN(RET_MEM_ERR_ALLOC);
						}

                        accessDelStp[j].action = Delete;
	                    accessDelStp[j].role   = DBA_ROLE_PERF_ATTRIB_RA;
	                    accessDelStp[j].object = ExtRetAnalysis;
	                    accessDelStp[j].entity = Get_Arg;

						/* REF9771 - RAK - 040108 */
	                    /* accessDelStp[j].data   = accessDelStp[j-2].data; */
						COPY_DYNFLD(accessDelStp[j].data, Get_Arg, Get_Arg_ObjId,
                                accessTab[i].data, A_PerfStorageParam, A_PerfStorageParam_Id);

                        COPY_DYNFLD(accessDelStp[j].data, Get_Arg, Get_Arg_DateTime,
                                accessTab[i].data, A_PerfStorageParam, A_PerfStorageParam_RetFirstStoredDate);

                        COPY_DYNFLD(accessDelStp[j].data, Get_Arg, Get_Arg_DateTime2,
                                accessTab[i].data, A_PerfStorageParam, A_PerfStorageParam_RetLastStoredDate);
                        j++;
                    }
                }
            }

            /* be in a transaction again */
			/* REF9771 - RAK - 030108 - because is tested before call MultiAccess */
			retCd = RET_SUCCEED;

            if (dbiConnHelper.beginTransaction() != RET_SUCCEED)
            {
				/* BCP corrupt the connection, so we have to close it and to get a new one */
				/* (which could be the same because of the logic in DBA_GetConnection()) */
				MSG_SendMesg(RET_SRV_LIB_ERR_FATAL_DEADLOCK, 2, FILEINFO, dbiConnHelper.getConnection()->getId());

                dbiConnHelper.reopen();

				if (dbiConnHelper.beginTransaction() != RET_SUCCEED)
				{
					MSG_SendMesg(RET_DBA_ERR_CONNOTFOUND, 0, FILEINFO);
       				retCd = RET_DBA_ERR_CONNOTFOUND;
				}
            }

            {
                DbaMultiAccessHelper       multiAccessHelper(accessDelStp, j);

                if (retCd == RET_SUCCEED)
                {
                    retCd = multiAccessHelper.callMultiAccess(UNUSED, DBA_SET_CONN|DBA_NO_CLOSE|DBA_NO_ERROR, *dbiConnHelper.getConnection(), true);
                }

                if (retCd == RET_SUCCEED)
                {
                    dbiConnHelper.commit();
                }
                else
                {
                    multiAccessHelper.sendAllMultiAccessMsg();
                    dbiConnHelper.rollback();
                }
            }

			/* REF9125 - RAK - 031105 - use j because it contains the really accessDelStp nbr */
            for (int i=0; i<j; i++)
			{
				FREE_DYNST(accessDelStp[i].data, Get_Arg);
			}

			FREE(accessDelStp);

		    retCd = RET_DBA_ERR_INSERT_FAILED;
	    }
    }

    return(retCd);
}


/************************************************************************
**
**  Function    :   DBA_DeletePaAndExtRaData()
**
**  Description :   Deletes data stored in database for portfolio storage
**                  or benchmark storage. Function is called by block.
**                  Domain from and till date are ajusted to end of month befor
**                  befor deleting in database.
**
**                  For portfolio storage:
**                  Update portfolio with new A_Ptf_PerfLastFinalDate or NULL,
**                  and deletes event scheduler if necessary.
**                  Updates of first and last dates in PerfStorageParam
**                  table is done in stored procedures used for delete.
**
**  Arguments   :   input:
**                  domainPtr       domain structure pointer
**                  inputStTab      pointer on input structure table
**                  inputStEnum     DBA_DYNST_ENUM of inputStTab
**                  firstIdx        first record in inputStTab to be treated
**                  lastIdx         last record in inputStTab to be treated
**
**                  output:
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   REF7421 - YST - 020805
**  Modification:   REF7422 - MCA - 020924 add the parameter Hierarchie
**
*************************************************************************/
RET_CODE DBA_DeletePaAndExtRaData(DBA_DYNFLD_STP      domainPtr,
                                  DBA_DYNFLD_STP      *inputStTab,
                                  OBJECT_ENUM         inputStEnum,
                                  int                 inputStNbr,
							      DBA_HIER_HEAD_STP   hierHead)
{
    RET_CODE                retCd = RET_SUCCEED;
    DBA_DYNFLD_STP          delDataArg = NULLDYNST, *pspTab=NULLDYNST, objPtr=NULLDYNST,
							childPtfPtr=NULLDYNST, parentPtfPtr=NULLDYNST;

    DBA_ACCESS_STP          accessStp;
    DATETIME_T              nullDateTime, delFromDate, delTillDate, magicEndDate, noEndDate;
    DICT_T                  entDictId = 0;
    FLAG_T                  delAllPtfFlg = FALSE, delAllFlg = FALSE, delEventSchedFlg = FALSE,
							updPtfFlg = FALSE;
    int                     j, k, allocAccessNbr=0, pspIdx=0, accessNbr=0, objIdIdx=0, connectNo=0, pspNbr=0;
    COMPDATA_ENUM	        action = (COMPDATA_ENUM)GET_ENUM(domainPtr, A_Domain_CompDataEn);
    PA_LICENSEE_ENUM		paLicenseEn = PALicensee_No;
    int                     size, maxSize = 200; /* REF11193 - LJE - 051201 */
	DBA_DYNFLD_STP         *delDataArgTab;
    int                     ptfAccessNbr = 0; /* PMSTA-10802 - LJE - 101118 */

	GEN_GetApplInfo(ApplPALicense, &paLicenseEn);

	/* REF9832 - RAK - 040303 - Do test on licence */
	if (action == CompData_DeletePerfAttrib && paLicenseEn == PALicensee_No)
	{
		return(RET_SUCCEED);
	}

    memset(&delFromDate, 0, sizeof(DATETIME_T));
    memset(&delTillDate, 0, sizeof(DATETIME_T));

	magicEndDate.date = MAGIC_END_DATE;
    magicEndDate.time = 0;

	noEndDate.date = 0;
	noEndDate.time = 0;

    DBA_GetDictId(inputStEnum, &entDictId);

    switch(GET_OBJECT_CST(inputStEnum)) /* REF8844 - LJE - 030417 */
    {
    case PtfCst:
        objIdIdx = A_Ptf_Id;
        break;

    case ListCst:
        objIdIdx = A_List_Id;
		break;

    case StratCst:
        objIdIdx = A_Strat_Id;
		break;

	case InstrCst:
        objIdIdx = A_Instr_Id;
        break;
    }

	/* research the psp in the hierarchy */
	/* sort on object id (so treate PSP object by object) */
	if ((retCd = DBA_ExtractHierEltRecWithFilterSt(hierHead,
												   A_PerfStorageParam,
												   FALSE,
												   NULLFCT,
												   NULLDYNST,
												   DBA_CmpPSPObjId,
												   &pspNbr,
                                                   &pspTab)) != RET_SUCCEED || pspNbr == 0)
	{
		return(retCd);
	}

	allocAccessNbr = 4 * pspNbr; /* REF7421 - LJE - 020917 : 3 -> 4 for delete */

	/* REF9125 - RAK - 031009 - Add 1 update by portfolio and 1 delete event_sched by PSP */
	if (GET_OBJECT_CST(inputStEnum) == PtfCst)
	{
		allocAccessNbr += inputStNbr;
		allocAccessNbr += pspNbr;
	}

	if ((accessStp = (DBA_ACCESS_STP)CALLOC(allocAccessNbr, sizeof(DBA_ACCESS_ST))) == (DBA_ACCESS_STP)NULL)
	{
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
		return(RET_MEM_ERR_ALLOC);
	}

	/* PMSTA09843 - LJE - 100607 */
	if ((delDataArgTab = (DBA_DYNFLD_STP*)CALLOC(pspNbr, sizeof(DBA_DYNFLD_STP))) == NULL)
	{
		FREE(accessStp);
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
		return(RET_MEM_ERR_ALLOC);
	}


	accessNbr=0;
	for (pspIdx=0; pspIdx<pspNbr; pspIdx++)
	{
		/* REF9832 - RAK - 040303 - Suppress test on perfDataContent and move test on licence before */

		/* REF9125 - RAK - 031009 */
		/* Get current object of the PSP (first object or new object) */
		if (objPtr == NULLDYNST ||
			GET_ID(pspTab[pspIdx], A_PerfStorageParam_ObjId) != GET_ID(objPtr, objIdIdx))
		{
			/* Before to get new portfolio, update A_Ptf_PerfLastFinalDate */
			if (GET_OBJECT_CST(inputStEnum) == PtfCst && objPtr != NULLDYNST && ptfAccessNbr != 0)  /* PMSTA-10802 - LJE - 101118 */
			{
				/* all data in database is deleted, update portfolio with proc upd_portfolio_by_id_perf_d */
				if (delAllPtfFlg == TRUE)
				{
					SET_NULL_DATETIME(objPtr, A_Ptf_PerfLastFinalDate);

					accessStp[accessNbr].action = Update;
					accessStp[accessNbr].role   = DBA_ROLE_PERF_ATTRIB_RA;
					accessStp[accessNbr].object = Ptf;
					accessStp[accessNbr].entity = A_Ptf;
					accessStp[accessNbr].data   = objPtr;
					accessNbr++;
				}
				/* If new final date,  update portfolio with proc upd_portfolio_by_id_perf_d */ /* REF7421 - YST - 021002 */
				else if (updPtfFlg == TRUE)
				{
					/* new date is already set */

					accessStp[accessNbr].action = Update;
					accessStp[accessNbr].role   = DBA_ROLE_PERF_ATTRIB_RA;
					accessStp[accessNbr].object = Ptf;
					accessStp[accessNbr].entity = A_Ptf;
					accessStp[accessNbr].data   = objPtr;
					accessNbr++;
				}
			}

            ptfAccessNbr = 0; /* PMSTA-10802 - LJE - 101118 */

			/* Get new object */
            int i = 0;
			for (objPtr=NULLDYNST; i<inputStNbr && objPtr==NULLDYNST; i++)
			{
				if (GET_ID(inputStTab[i], objIdIdx) == GET_ID(pspTab[pspIdx], A_PerfStorageParam_ObjId))
				{
					objPtr = inputStTab[i];

					/* For ptf, init delAllPtfFlg according to filtered PSP */
					if (GET_OBJECT_CST(inputStEnum) == PtfCst)
					{
						updPtfFlg = FALSE;

						/* If no one PSP are filtered, it's possible to set A_Ptf_PerfLastFinalDate to NULL */
						if (DATETIME_CMP(GET_DATETIME(objPtr, A_Ptf_MaxFilterPerfLastStoredDate), magicEndDate) == 0 ||
							DATETIME_CMP(GET_DATETIME(objPtr, A_Ptf_MaxFilterPerfLastStoredDate), noEndDate) == 0 ||
							IS_NULLFLD(objPtr, A_Ptf_MaxFilterPerfLastStoredDate) == TRUE)
							delAllPtfFlg = TRUE;
						else
							delAllPtfFlg = FALSE;

						/* If no one PSP are filtered, set MaxFilterPerfLastStoredDate to NULL so test will be simplified */
						if (DATETIME_CMP(GET_DATETIME(objPtr, A_Ptf_MaxFilterPerfLastStoredDate), magicEndDate) == 0)
						{ SET_NULL_DATETIME(objPtr, A_Ptf_MaxFilterPerfLastStoredDate); }
					}
				}
			}
		}

		if (objPtr != NULLDYNST)
		{
			/* Get delFromDate, delTillDate delAllFlg and delEventSchedFlg and updates A_Domain_CompDataEn */
			retCd = FIN_GetPeriodPerfAttrib(domainPtr,
	                                        nullptr, /* PMSTA-26435 - LJE - 170316 */
											objPtr,
											inputStEnum,
											pspTab[pspIdx],
											&nullDateTime,
											&nullDateTime,
											&delFromDate,
											&delTillDate,
											&delAllFlg,
											&delEventSchedFlg,
											hierHead);

			if (retCd == RET_SUCCEED)
			{
				/* REF9125 - RAK - 030925 - allocate one delete by PSP (elsewhere only last delete is done) */
				if ((delDataArg = ALLOC_DYNST(Get_Arg)) == NULLDYNST)
				{
					MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
					retCd = RET_MEM_ERR_ALLOC;
				}
				delDataArgTab[pspIdx] = delDataArg; /* PMSTA09843 - LJE - 100607 */
			}

			if (retCd == RET_SUCCEED)
			{
                /* get action, for each record after calling FIN_GetPeriodPerfAttrib() */
				action = (COMPDATA_ENUM)GET_ENUM(domainPtr, A_Domain_CompDataEn);

				SET_ID(delDataArg, Get_Arg_ObjId, GET_ID(pspTab[pspIdx], A_PerfStorageParam_Id));
				SET_DATETIME(delDataArg, Get_Arg_DateTime,  delFromDate);
				SET_DATETIME(delDataArg, Get_Arg_DateTime2, delTillDate);

				/* delete of PerfAttrib data - call proc del_perf_attrib_by_psp_d */
				if ((action == CompData_DeleteAll || action == CompData_DeletePerfAttrib) && /* REF9832 - RAK - 040303 - test on PSP flag */
					GET_FLAG(pspTab[pspIdx], A_PerfStorageParam_PerfAttribFlg) == TRUE)
				{
					accessStp[accessNbr].action = Delete;
					accessStp[accessNbr].role   = UNUSED;
					accessStp[accessNbr].object = PerfAttrib;
					accessStp[accessNbr].entity = Get_Arg;
					accessStp[accessNbr].data   = delDataArg;
					accessNbr++;
                    ptfAccessNbr++; /* PMSTA-10802 - LJE - 101118 */
				}

				/* delete of global data - call proc del_ext_ra_gbl_by_psp_d */
				if (action == CompData_DeleteReturnAnalysis && /* REF9832 - RAK - 040303 - test on PSP flag */
					GET_FLAG(pspTab[pspIdx], A_PerfStorageParam_RetAnalysisFlg) == TRUE)
				{
					accessStp[accessNbr].action = Delete;
					accessStp[accessNbr].role   = UNUSED;
					accessStp[accessNbr].object = ExtRetAnalysis;
					accessStp[accessNbr].entity = Get_Arg;
					accessStp[accessNbr].data   = delDataArg;
					accessNbr++;
                    ptfAccessNbr++; /* PMSTA-10802 - LJE - 101118 */
				}

				/* delete of detailed data - call proc del_ext_ra_det_by_psp_d */
				if ((action == CompData_DeleteAll ||
					action == CompData_DeleteReturnAnalysis ||
					 action == CompData_DeleteGIPS) && /* REF9832 - RAK - 040303 - test on PSP flag */
					 GET_FLAG(pspTab[pspIdx], A_PerfStorageParam_RetAnalysisFlg) == TRUE)
				{
					accessStp[accessNbr].action = Delete;
					accessStp[accessNbr].role   = DBA_ROLE_PERF_ATTRIB_RA;
					accessStp[accessNbr].object = ExtRetAnalysis;
					accessStp[accessNbr].entity = Get_Arg;
					accessStp[accessNbr].data   = delDataArg;
					accessNbr++;
                    ptfAccessNbr++; /* PMSTA-10802 - LJE - 101118 */
				}

				/* delete of GIPS data -  call proc del_std_perf_by_psp_d  which calls del_ext_ra_gbl_by_psp_d */
				if ((action == CompData_DeleteAll || action == CompData_DeleteGIPS) && /* REF9832 - RAK - 040303 - test on PSP flag */
					GET_FLAG(pspTab[pspIdx], A_PerfStorageParam_StandardPerfDataFlg) == TRUE)
				{
					accessStp[accessNbr].action = Delete;
					accessStp[accessNbr].role   = UNUSED;
					accessStp[accessNbr].object = StandardPerf;
					accessStp[accessNbr].entity = Get_Arg;
					accessStp[accessNbr].data   = delDataArg;
					accessNbr++;
                    ptfAccessNbr++; /* PMSTA-10802 - LJE - 101118 */
				}

                /*PMSTA-53328 - SENTHIL - 140823*/
                if (action == CompData_DeleteAll &&
                    GET_FLAG(pspTab[pspIdx], A_PerfStorageParam_PerfCalcResultFlg) == TRUE)
                {
                    accessStp[accessNbr].action = Delete;
                    accessStp[accessNbr].role = UNUSED;
                    accessStp[accessNbr].object = PerfCalcResult;
                    accessStp[accessNbr].entity = Get_Arg;
                    accessStp[accessNbr].data = delDataArg;
                    accessNbr++;
                    ptfAccessNbr++;
                }

				if (inputStEnum == Ptf)
				{
					/* If an event scheduler exist, delete it in database */
					if (delEventSchedFlg == TRUE)
					{
						/* REF9125 - RAK - 031009 - delete EventSched by PSP id */
						accessStp[accessNbr].action = Delete;
						accessStp[accessNbr].role   = UNUSED;
						accessStp[accessNbr].object = EventSched;
						accessStp[accessNbr].entity = A_PerfStorageParam;
						accessStp[accessNbr].data   = pspTab[pspIdx];
						accessNbr++;
                        ptfAccessNbr++; /* PMSTA-10802 - LJE - 101118 */
					}

					/* REF9125 - RAK - 031009 */
					/* Update delAllPtfFlg, avoid to set FLAG to TRUE if it is already to FALSE */
					if (delAllPtfFlg == TRUE)
						delAllPtfFlg = delAllFlg;

					/* If new final date is before the stored A_PerfAttrib_FinalDate,
					   update portfolio with proc upd_portfolio_by_id_perf_d */
						updPtfFlg = TRUE;

						if (DATETIME_CMP(delFromDate, GET_DATETIME(objPtr, A_Ptf_MaxFilterPerfLastStoredDate)) > 0)
						{
							SET_DATETIME(objPtr, A_Ptf_PerfLastFinalDate, delFromDate);
						}
						else
						{
							SET_DATETIME(objPtr, A_Ptf_PerfLastFinalDate, GET_DATETIME(objPtr, A_Ptf_MaxFilterPerfLastStoredDate));
						}
				}/* end if (inputStEnum == Ptf)*/

			}/*end if (retCd == RET_SUCCEED)*/
        }

        retCd = RET_SUCCEED; /* PMSTA-10802 - LJE - 101118 */
    }/*end for*/

    /* REF9125 - RAK - 031009 */
	/* Do update A_Ptf_PerfLastFinalDate on last ptf */
	if (GET_OBJECT_CST(inputStEnum) == PtfCst && objPtr != NULLDYNST && ptfAccessNbr != 0) /* PMSTA-10802 - LJE - 101118 */
	{
		/* all data in database is deleted, update portfolio with proc upd_portfolio_by_id_perf_d */
		if (delAllPtfFlg == TRUE)
		{
			SET_NULL_DATETIME(objPtr, A_Ptf_PerfLastFinalDate);

			accessStp[accessNbr].action = Update;
			accessStp[accessNbr].role   = DBA_ROLE_PERF_ATTRIB_RA;
			accessStp[accessNbr].object = Ptf;
			accessStp[accessNbr].entity = A_Ptf;
			accessStp[accessNbr].data   = objPtr;
			accessNbr++;
		}
		/* If new final date,  update portfolio with proc upd_portfolio_by_id_perf_d */ /* REF7421 - YST - 021002 */
		else if (updPtfFlg == TRUE)
		{
			/* new date is already set */

			accessStp[accessNbr].action = Update;
			accessStp[accessNbr].role   = DBA_ROLE_PERF_ATTRIB_RA;
			accessStp[accessNbr].object = Ptf;
			accessStp[accessNbr].entity = A_Ptf;
			accessStp[accessNbr].data   = objPtr;
			accessNbr++;
		}
	}

	/* PMSTA02013 - RAK - 071112 */
	if (accessNbr != 0 && /* PMSTA-10802 - LJE - 101118 */
        GET_OBJECT_CST(inputStEnum) == PtfCst &&
		GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None &&
		(PTFCONSRULE_ENUM) GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) != PtfConsRule_DetailedChildren &&
        ((static_cast<LOADHIERPTF_ENUM> GET_ENUM(domainPtr, A_Domain_LoadHierFlg) != LoadHierPtf_IntermediateHierarchy) ?    /*PMSTA-53468- IPSLevelGuiChanges */
            true : FIN_IsPtfConsRuleValidForIntermediateHierarchy(domainPtr) == false))
	{
		/* if there is a hierarchical PSP */
		for (int i=0; i<pspNbr; i++)
		{
			if (GET_ENUM(pspTab[i], A_PerfStorageParam_PerfAttribReturnEn) == PerfAttribRtnEn_Hierarchy)
			{
				/* search parent portfolio */
				for (j=0, parentPtfPtr=NULLDYNST; j<inputStNbr && parentPtfPtr==NULLDYNST; j++)
				{
					if (GET_ID(pspTab[i], A_PerfStorageParam_ObjId) ==
						GET_ID(inputStTab[j], A_Ptf_Id) &&
						IS_NULLFLD(inputStTab[j], A_Ptf_HierPortId) == TRUE)
						parentPtfPtr = inputStTab[j];
				}

				if (parentPtfPtr != NULLDYNST)
				{
					/* search children of the parent portfolio */
					for (j=0; j<inputStNbr; j++)
					{
						if (GET_ID(inputStTab[j], A_Ptf_HierPortId) == GET_ID(parentPtfPtr, A_Ptf_Id))
						{
							childPtfPtr = inputStTab[j];

							/* update children without PSP too (elsewhere they keep a wrong PerfLastFinalDate) */
                            for (k = 0; k < pspNbr; k++)
							{
								if (GET_ID(pspTab[k], A_PerfStorageParam_ObjId) == GET_ID(childPtfPtr, A_Ptf_Id))
                                    break;
							}

                            if (k == pspNbr || delDataArgTab[k] == NULL)
							{
								if (accessNbr == allocAccessNbr)
								{
									if ((accessStp = SYS_ReallocInit(accessStp,
											         (size_t) allocAccessNbr, (size_t) 1))==NULL)
									{
										/* PMSTA09843 - LJE - 100607 - Memory leak */
										for (i=0; i<pspIdx; i++)
										{
											if (delDataArgTab[i] != NULL)
											{
												FREE_DYNST(delDataArgTab[i], Get_Arg);
											}
										}
										FREE(delDataArgTab);

										MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
										FREE(pspTab);
										return(RET_MEM_ERR_ALLOC);
									}
                                    allocAccessNbr += 1;
                                }

								COPY_DYNFLD(childPtfPtr,  A_Ptf, A_Ptf_PerfLastFinalDate,
										    parentPtfPtr, A_Ptf, A_Ptf_PerfLastFinalDate);

								accessStp[accessNbr].action = Update;
								accessStp[accessNbr].role   = DBA_ROLE_PERF_ATTRIB_RA;
								accessStp[accessNbr].object = Ptf;
								accessStp[accessNbr].entity = A_Ptf;
								accessStp[accessNbr].data   = childPtfPtr;
								accessNbr++;
							}
						}
					}
				}
			}
		}
	}

	FREE(pspTab); /* PMSTA02013 - LJE - 071112 */
    /* For save memory */
	if (retCd == RET_SUCCEED && accessNbr > 0 && accessNbr < allocAccessNbr)
    {
		if ((accessStp = (DBA_ACCESS_STP) REALLOC(accessStp,
											    accessNbr*sizeof(DBA_ACCESS_ST)))==NULL)
		{
            MSG_SendMesg(RET_MEM_ERR_REALLOC, 0, FILEINFO);
            retCd = RET_MEM_ERR_REALLOC;
        }
    }

    if (accessNbr > 0)
    {
        /* REF11193 - LJE - 051201 */
        if (accessNbr > maxSize)
        {
            size = maxSize;
        }
        else
        {
            size = accessNbr;
        }

        /* Begin multiaccess for delete PerfAttrib and/or ExtRetAnalysis or StandardPerf, */
        /* update ptf and delete event scheduler (ES) (if exists). */

        /* get connection */
        if ((connectNo = DBA_GetConnection(SqlServer)) == DBA_CONN_NOT_FOUND)
	    {
	        MSG_SendMesg(RET_DBA_ERR_CONNOTFOUND, 0, FILEINFO);
       	    retCd = RET_DBA_ERR_CONNOTFOUND;
	    }
	    else
	    {
            DbiConnection   *dbiConn = DBA_GetDbiConnFromConnectNo(connectNo);

	        /* be in a transaction */
	        if (DBA_BeginTransaction(connectNo) != RET_SUCCEED)
	        {
                if (DBA_EndConnection(connectNo) != RET_SUCCEED)
                {
                    MSG_SendMesg(RET_DBA_ERR_DISCONNECTED, 0, FILEINFO);
                }
           	    retCd = RET_DBA_ERR_CONNOTFOUND;
	        }
	        else
	        {
                DbaMultiAccessHelper       multiAccessHelper(accessStp, accessNbr);

                /* Sort delete of PerfAttrib, ExtRetAnalysis/StandardPerf, update ptf, strat or instr, delete ES */
                if (accessNbr > 1)
                    TLS_Sort((char*) accessStp, accessNbr, sizeof(DBA_ACCESS_ST),
		                    (TLS_CMPFCT *)DBA_CmpInsPtfBenchStorage, (PTR**)NULL, SortRtnTp_None);

                retCd = multiAccessHelper.callMultiAccess(size, DBA_SET_CONN|DBA_NO_CLOSE|DBA_NO_ERROR, &connectNo, true); /* REF11193 - LJE - 051201 */

                /* Retry until succeed (3 times max) ... */
                if (retCd == RET_SRV_LIB_ERR_FATAL_DEADLOCK || retCd == RET_SRV_LIB_ERR_DEADLOCK)
                {
                    int deadlockCpt = 0, ret = RET_SUCCEED;
                    do
                    {
                        multiAccessHelper.sendAllMultiAccessMsg();

                        /* rollback */
                        ret = DBA_EndTransaction(connectNo, FALSE);

                        if (ret == RET_SUCCEED)
                        {
                            switch (deadlockCpt)
					        {
						    case 0:
							    /* DBA_SqlExec("waitfor delay \"0:00:01\"", UNUSED, UNUSED); */
								SYS_MilliSleep(1000); /* PMSTA-20159 - TEB - 150624  */
							    break;

						    case 1:
							    /* DBA_SqlExec("waitfor delay \"0:00:03\"", UNUSED, UNUSED); */
								SYS_MilliSleep(3000); /* PMSTA-20159 - TEB - 150624  */
							    break;

						    case 2:
							    /* DBA_SqlExec("waitfor delay \"0:00:07\"", UNUSED, UNUSED); */
								SYS_MilliSleep(7000); /* PMSTA-20159 - TEB - 150624  */
							    break;
					        }

                            /* be in a transaction */
	                        ret = DBA_BeginTransaction(connectNo);

	                        if (ret == RET_SUCCEED)
	                        {
                                retCd = multiAccessHelper.callMultiAccess(size, DBA_SET_CONN|DBA_NO_CLOSE|DBA_NO_ERROR, &connectNo, true); /* REF11193 - LJE - 051201 */
                            }
                        }
                        ++deadlockCpt;
                    }
                    while (retCd != RET_SUCCEED && ret == RET_SUCCEED && deadlockCpt < 3);

                    if (retCd != RET_SUCCEED)
                    {
                        multiAccessHelper.sendAllMultiAccessMsg();

                        /* rollback */
                        retCd = DBA_EndTransaction(connectNo, FALSE);
                        retCd = RET_DBA_ERR_INSERT_FAILED;
                    }
                }
		        /* test on msgStructNbr to be sure no error is lost */
		        else if ( (retCd != RET_SUCCEED) || (dbiConn->emptyMsg() == false))
		        {
		            /* error: rollback */
		            DBA_EndTransaction(connectNo, FALSE);

                    dbiConn->sendAllMsgFromMA();

                    retCd = RET_DBA_ERR_INSERT_FAILED;
		        }
            }
	    }/* end multiaccess */

        if (retCd == RET_SUCCEED)
        {
            /* commit transaction and end connection */
            DBA_EndTransaction(connectNo, TRUE);

	        if (DBA_EndConnection(connectNo) != RET_SUCCEED)
	        {
		        MSG_SendMesg(RET_DBA_ERR_DISCONNECTED, 0, FILEINFO);
	        }
        }
    }

	/* PMSTA09843 - LJE - 100607 - Memory leak */
	for (int i=0; i<pspIdx; i++)
	{
		if (delDataArgTab[i] != NULL)
		{
			FREE_DYNST(delDataArgTab[i], Get_Arg);
		}
	}
	FREE(delDataArgTab);

    FREE(accessStp);
    return(retCd);
}

/************************************************************************
**
**  Function    :   DBA_SelectPSP()
**
**  Description :   Select for all objects (ptf, list, strat, instr)
**                  used in Ptf or Benchmark Storage the PSPs in database.
**                  Check PSP and keep for each object the set of PSP in hierarchy
**                  1. which have following fields equal to sPspPtr
**                  - frequency     (if None for sPspPtr, than keep all freq)
**                  - currency      (if NULL for ...  ???)
**                  - position_data (can be NULL for aPspPtr and sPspPtr)
**
**                  2. and which have at least one active_flag = TRUE
**                  - list and instr: StdPerfDataFlg = TRUE
**                  - strat: StdPerfDataFlg = TRUE or PerfAttribFlg = TRUE
**                  - ptf: StdPerfDataFlg = TRUE or PerfAttribFlg = TRUE or
**                         RetAnalysisFlg = TRUE
**
**
**  Arguments   :   domainPtr 	pointer on domain
**                  argHierHead 	pointer on hierarchy
**                  *objTab       	pointer on objects   (only used for ptf)
**                  objNbr 		number of objects
**                  objEnum		object enum
**                  *selPspTab	pointer on PSP already loaded
**                  selPspNbr 	number of PSP already loaded
**
**  Return      :   TRUE or FALSE
**
**  Creation	:   REF9125 - YST - 030701
**  Modification:   REF9125 - MCA - 030822
**
*************************************************************************/
RET_CODE DBA_SelectPSP(DBA_DYNFLD_STP      domainPtr,
					          int				 *connectNo,
					          DBA_DYNFLD_STP	**selPspTab,
					          int                *selPspNbr)

{
    RET_CODE            retCd = RET_SUCCEED;

    /* le load des psp ce fait ici */
    /* call stored procedure sel_psp_for_perf_analysis, which returns all PSP for all entites in domain */

    SET_ENUM(domainPtr, A_Domain_ReturnAnalysisEn, PAARetAnalysis_All );

    retCd = DBA_Select2(PerfStorageParam,
					    UNUSED,
					    A_Domain,
					    domainPtr,
					    A_PerfStorageParam,
					    selPspTab,
					    DBA_SET_CONN|DBA_NO_CLOSE,
					    UNUSED,
					    selPspNbr,
					    connectNo,
					    UNUSED);

    return(retCd);
}

/************************************************************************
**
**  Function    :   DBA_CheckPSP()
**
**  Description :   Check if the PSP isn't bad
**
**
**  Arguments   :   *objTab     pointer on objects   (only used for ptf)
**                  objNbr 		number of objects
**                  objEnum		object enum
**                  *selPspTab	pointer on PSP already loaded
**                  selPspNbr 	number of PSP already loaded
**
**  Return      :   TRUE or FALSE
**
**  Creation	:   REF10640 - LJE - 041117
**  Modification:
**
*************************************************************************/
STATIC FLAG_T DBA_CheckPSP(DBA_DYNFLD_STP   pspSt)
{

    if (IS_NULLFLD(pspSt, A_PerfStorageParam_StdPerfFirstStoredDate) == TRUE &&
        (IS_NULLFLD(pspSt, A_PerfStorageParam_RetFirstStoredDate)     == FALSE ||
         IS_NULLFLD(pspSt, A_PerfStorageParam_RetFirstStoredDate)     == FALSE))
    {
        return FALSE;
    }

    if ((IS_NULLFLD(pspSt, A_PerfStorageParam_StdPerfFirstStoredDate) == FALSE &&
         IS_NULLFLD(pspSt, A_PerfStorageParam_StdPerfLastStoredDate)  == TRUE) ||
        (IS_NULLFLD(pspSt, A_PerfStorageParam_StdPerfFirstStoredDate) == TRUE  &&
         IS_NULLFLD(pspSt, A_PerfStorageParam_StdPerfLastStoredDate)  == FALSE))
    {
        return FALSE;
    }

    if ((IS_NULLFLD(pspSt, A_PerfStorageParam_RetFirstStoredDate) == FALSE &&
         IS_NULLFLD(pspSt, A_PerfStorageParam_RetLastStoredDate)  == TRUE) ||
        (IS_NULLFLD(pspSt, A_PerfStorageParam_RetFirstStoredDate) == TRUE  &&
         IS_NULLFLD(pspSt, A_PerfStorageParam_RetLastStoredDate)  == FALSE))
    {
        return FALSE;
    }

    if ((IS_NULLFLD(pspSt, A_PerfStorageParam_PerfFirstStoredDate) == FALSE &&
         IS_NULLFLD(pspSt, A_PerfStorageParam_PerfLastStoredDate)  == TRUE) ||
        (IS_NULLFLD(pspSt, A_PerfStorageParam_PerfFirstStoredDate) == TRUE  &&
         IS_NULLFLD(pspSt, A_PerfStorageParam_PerfLastStoredDate)  == FALSE))
    {
        return FALSE;
    }

    if (IS_NULLFLD(pspSt, A_PerfStorageParam_StdPerfFirstStoredDate) == FALSE &&
        IS_NULLFLD(pspSt, A_PerfStorageParam_RetFirstStoredDate)     == FALSE &&
        CMP_DYNFLD(pspSt,
                   pspSt,
                   A_PerfStorageParam_StdPerfFirstStoredDate,
                   A_PerfStorageParam_RetFirstStoredDate,
                   DatetimeType) != 0)
    {
        return FALSE;
    }

    if (IS_NULLFLD(pspSt, A_PerfStorageParam_StdPerfFirstStoredDate) == FALSE &&
        IS_NULLFLD(pspSt, A_PerfStorageParam_PerfFirstStoredDate)    == FALSE &&
        CMP_DYNFLD(pspSt,
                   pspSt,
                   A_PerfStorageParam_StdPerfFirstStoredDate,
                   A_PerfStorageParam_PerfFirstStoredDate,
                   DatetimeType) != 0)
    {
        return FALSE;
    }

    if (IS_NULLFLD(pspSt, A_PerfStorageParam_StdPerfLastStoredDate) == FALSE &&
        IS_NULLFLD(pspSt, A_PerfStorageParam_RetLastStoredDate)     == FALSE &&
        CMP_DYNFLD(pspSt,
                   pspSt,
                   A_PerfStorageParam_StdPerfLastStoredDate,
                   A_PerfStorageParam_RetLastStoredDate,
                   DatetimeType) != 0)
    {
        return FALSE;
    }

    if (IS_NULLFLD(pspSt, A_PerfStorageParam_StdPerfLastStoredDate) == FALSE &&
        IS_NULLFLD(pspSt, A_PerfStorageParam_PerfLastStoredDate)    == FALSE &&
        CMP_DYNFLD(pspSt,
                   pspSt,
                   A_PerfStorageParam_StdPerfLastStoredDate,
                   A_PerfStorageParam_PerfLastStoredDate,
                   DatetimeType) != 0)
    {
        return FALSE;
    }

    if (GET_ENUM(pspSt, A_PerfStorageParam_CheckedDataEn) == 0)
    {
        return FALSE;
    }

    return TRUE;
}

/************************************************************************
**
**  Function    :   DBA_FilterPSP()
**
**  Description :   Select for all objects (ptf, list, strat, instr)
**                  used in Ptf or Benchmark Storage the PSPs in database.
**                  Check PSP and keep for each object the set of PSP in hierarchy
**                  1. which have following fields equal to sPspPtr
**                  - frequency     (if None for sPspPtr, than keep all freq)
**                  - currency      (if NULL for ...  ???)
**                  - position_data (can be NULL for aPspPtr and sPspPtr)
**
**                  2. and which have at least one active_flag = TRUE
**                  - list and instr: StdPerfDataFlg = TRUE
**                  - strat: StdPerfDataFlg = TRUE or PerfAttribFlg = TRUE
**                  - ptf: StdPerfDataFlg = TRUE or PerfAttribFlg = TRUE or
**                         RetAnalysisFlg = TRUE
**
**
**  Arguments   :   domainPtr 	pointer on domain
**					hierHeadPtr pointer on hierarchie
**                  *objTab       	pointer on objects   (only used for ptf)
**                  objNbr 		number of objects
**                  objEnum		object enum
**                  *selPspTab	pointer on PSP already loaded
**                  selPspNbr 	number of PSP already loaded
**
**  Return      :   RET_SUCCEED or not...
**
**  Creation	:   REF9125 - YST - 030701
**  Modification:   REF9125 - MCA - 030822
**                  REF10640 - LJE - 041117
**
*************************************************************************/
RET_CODE DBA_FilterPSP(DBA_DYNFLD_STP    domainPtr,
			           DBA_HIER_HEAD_STP hierHeadPtr,
					   DBA_DYNFLD_STP   *objTab,
					   int               objNbr,
					   OBJECT_ENUM       objEnum,
					   DBA_DYNFLD_STP   *selPspTab,
					   int               selPspNbr)
{
    RET_CODE            retCd = RET_SUCCEED;
	FLAG_T				keepFlg=FALSE;
    DBA_DYNFLD_STP      *aPspTab=NULL;
	DATETIME_T			magicEndDate, maxEndDate;
    int                 i = 0, ptfIdx = 0, /*objIdIdx = 0,*/ aPspIdx=0;

	magicEndDate.date = MAGIC_END_DATE;
    magicEndDate.time = 0;

	maxEndDate.date = 0;
	maxEndDate.time = 0;

    if (selPspNbr == 0)
    {
		MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
	                 "DBA_FilterPSP", "no PSP are selected");
	    return(RET_SUCCEED);
    }

	/* YST si defCurrFlg = TRUE trier ptf and psp par objId,        */
	/* ainsi il suffit d'incrementer ptfIdx  pour tomber sur le prochain */
	/* ptf avec id =PSP.objId et de continuer avec le teste sur currId   */

	/* REF9125 - RAK - 031008 */
	/* if object is portfolio do sort because is used for A_Ptf_MaxFilterPerfLastStoredDate update */
	if (objEnum == Ptf /* && GET_FLAG(domainPtr, A_Domain_DefCurrFlg) == TRUE*/)
	{
		/* trier ptf par id and psp par objId */
		TLS_Sort((char*) objTab, objNbr, sizeof(DBA_DYNFLD_STP),
	             (TLS_CMPFCT *)DBA_CmpObjPtfId, (PTR **) NULL, SortRtnTp_None);

		TLS_Sort((char*) selPspTab, selPspNbr, sizeof(DBA_DYNFLD_STP),
	             (TLS_CMPFCT *)DBA_CmpPSPObjId, (PTR **) NULL, SortRtnTp_None);
	}

    /* REF10640 - LJE - 041117 : Check the validity of PSP, and if necessary, update PSP no upd to date */
    for (aPspIdx=0; aPspIdx<selPspNbr; aPspIdx++)
    {
        /* PMSTA-11083 - LJE - 110114 */
        if (GET_ENUM(selPspTab[aPspIdx], A_PerfStorageParam_CheckedDataEn) == 0)
        {
            retCd = DBA_ValidatePerfData(selPspTab[aPspIdx]);
        }
        else if (objEnum == Ptf)
        {
            /* Search Portfolio */
            for (;ptfIdx<objNbr &&
                  CMP_DYNFLD(objTab[ptfIdx], selPspTab[aPspIdx], A_Ptf_Id, A_PerfStorageParam_ObjId, IdType) != 0
                 ;ptfIdx++);

            /* REF10640 - LJE - 041209 */
            if (IS_NULLFLD(selPspTab[aPspIdx], A_PerfStorageParam_StdPerfLastStoredDate) == FALSE &&
                CMP_DYNFLD(selPspTab[aPspIdx],
                           objTab[ptfIdx],
                           A_PerfStorageParam_StdPerfLastStoredDate,
                           A_Ptf_PerfLastFinalDate,
                           DatetimeType) > 0)
            {
                retCd = DBA_ValidatePerfData(selPspTab[aPspIdx]);

                COPY_DYNFLD(objTab[ptfIdx],
                            A_Ptf,
                            A_Ptf_PerfLastFinalDate,
                            selPspTab[aPspIdx],
                            A_PerfStorageParam,
                            A_PerfStorageParam_StdPerfLastStoredDate);
            }
        }
        else if (DBA_CheckPSP(selPspTab[aPspIdx]) == FALSE)
        {
            retCd = DBA_ValidatePerfData(selPspTab[aPspIdx]);
        }

    }
    aPspIdx = 0;
    ptfIdx  = 0;

	if ((aPspTab = (DBA_DYNFLD_STP *)CALLOC(selPspNbr, sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR)
	{
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, selPspNbr * sizeof(DBA_DYNFLD_STP));
		return(RET_MEM_ERR_ALLOC);
	}

    /* REF9125 - RAK - 031008 - Init first portfolio MaxFilterPerfLastStoredDate, which is MAGIC_END_DATE or max date of filtered PSP */
	if (objEnum == Ptf)
	{
		ptfIdx = 0;
		if (ptfIdx < objNbr)
		{ SET_DATETIME(objTab[ptfIdx], A_Ptf_MaxFilterPerfLastStoredDate, magicEndDate);}
	}

	/* filter PSP on freq, currency and position_data */
    for (i=0; i<selPspNbr; i++)
    {
		keepFlg = FALSE;

		/* REF9125 - RAK - 031009 - Point on current portfolio */
		if (objEnum == Ptf)
		{
			if (GET_ID(objTab[ptfIdx], A_Ptf_Id) != GET_ID(selPspTab[i], A_PerfStorageParam_ObjId))
			{
				++ptfIdx;

				/* REF9125 - RAK - 031008 - Init new portfolio MaxFilterPerfLastStoredDate, which is MAGIC_END_DATE or max date of filtered PSP*/
				if (ptfIdx < objNbr)
				{ SET_DATETIME(objTab[ptfIdx], A_Ptf_MaxFilterPerfLastStoredDate, magicEndDate);}
			}
		}

		/* REF10806 - RAK - 041208 - test active_flag AND freq          */
		/* one flag need to be TRUE and if domain frequency isn't none, */
		/* PSP frequency must be the same as domain frequency           */
		if ((GET_FLAG(selPspTab[i], A_PerfStorageParam_StandardPerfDataFlg) == TRUE ||
			 GET_FLAG(selPspTab[i], A_PerfStorageParam_RetAnalysisFlg) == TRUE ||
			 GET_FLAG(selPspTab[i], A_PerfStorageParam_PerfAttribFlg) == TRUE) &&
			(GET_ENUM(domainPtr, A_Domain_Freq1UnitEn) == FreqUnit_None ||
			 GET_ENUM(selPspTab[i], A_PerfStorageParam_FrequencyEn) == GET_ENUM(domainPtr, A_Domain_Freq1UnitEn)))
		{
			aPspTab[aPspIdx] = selPspTab[i];
			aPspIdx++;
			keepFlg = TRUE;
		}

		/* If record isn't keeped (and won't be add in hier) free it */
		if (keepFlg == FALSE)
		{
			/* REF9125 - RAK - 031008 - MaxFilterPerfLastStoredDate is MAGIC_END_DATE or max date of filtered PSP */
			if (objEnum == Ptf && ptfIdx < objNbr)
			{
				/* compute max of the 3 dates */
				maxEndDate.date = 0;
				maxEndDate.time = 0;

				if (DATETIME_CMP(GET_DATETIME(selPspTab[i], A_PerfStorageParam_StdPerfLastStoredDate),
					             GET_DATETIME(selPspTab[i], A_PerfStorageParam_RetLastStoredDate)) > 0)
				{
					maxEndDate = GET_DATETIME(selPspTab[i], A_PerfStorageParam_StdPerfLastStoredDate);
				}
				else
				{
					maxEndDate = GET_DATETIME(selPspTab[i], A_PerfStorageParam_RetLastStoredDate);
				}

				if (DATETIME_CMP(GET_DATETIME(selPspTab[i], A_PerfStorageParam_PerfLastStoredDate), maxEndDate) > 0)
				{
					maxEndDate = GET_DATETIME(selPspTab[i], A_PerfStorageParam_PerfLastStoredDate);
				}

				/* if max date is bigger or if A_Ptf_MaxFilterPerfLastStoredDate isn't update */
				if (DATETIME_CMP(GET_DATETIME(objTab[ptfIdx], A_Ptf_MaxFilterPerfLastStoredDate), magicEndDate) == 0 ||
					DATETIME_CMP(maxEndDate, GET_DATETIME(objTab[ptfIdx], A_Ptf_MaxFilterPerfLastStoredDate)) > 0)
				{
					SET_DATETIME(objTab[ptfIdx], A_Ptf_MaxFilterPerfLastStoredDate, maxEndDate);
				}
			}

			FREE_DYNST(selPspTab[i], A_PerfStorageParam);
		}
	}

	FREE(selPspTab);

	/* add loaded PSP to hierarchy */
	if (aPspIdx > 0)
	{
		if ((retCd = DBA_AddHierRecordList(hierHeadPtr, aPspTab, aPspIdx, A_PerfStorageParam, TRUE)) != RET_SUCCEED)

		{
			DBA_FreeDynStTab(aPspTab, aPspIdx, A_PerfStorageParam);
			return(retCd);
		}
	}

	FREE(aPspTab);
    return(retCd);
}

/************************************************************************
**
**  Function    :   DBA_UpdDomainWithPSPInfo()
**
**  Description :   Update domaine with PSP informations
**
**
**  Arguments   :   domainPtr 	pointer on domain
**					hierHeadPtr pointer on hierarchie
**                  *objTab       	pointer on objects   (only used for ptf)
**                  objNbr 		number of objects
**                  objEnum		object enum
**                  *selPspTab	pointer on PSP already loaded
**                  selPspNbr 	number of PSP already loaded
**
**  Return      :   TRUE or FALSE
**
**  Creation	:   REF9125 - RAK - 030828
*************************************************************************/
RET_CODE DBA_UpdDomainWithPSPInfo(DBA_HIER_HEAD_STP	hierHeadPtr,
                                  DBA_DYNFLD_STP	domainPtr,
                                  DBA_DYNFLD_STP	pspPtr)
{
	RET_CODE		ret=RET_SUCCEED;

	SET_ID(domainPtr, A_Domain_CurrId, GET_ID(pspPtr, A_PerfStorageParam_CurrId));
	SET_FLAG(domainPtr, A_Domain_DefCurrFlg, FALSE); /* PMSTA-10897 - LJE - 101216 */

    /* PMSTA-54529 - DDV - 231009 */
    COPY_DYNFLD(domainPtr, A_Domain, A_Domain_PerfCalcDefProfId,
                pspPtr, A_PerfStorageParam, A_PerfStorageParam_PerfCalcDefProfileId);

	/* REF9738 - RAK - 040105 */
	/* For PerfAttrib (Portfolio storage)                                       */
	/* grid				compute instr/grid/global synthetics                    */
	/* instr			compute instr/global synthetics                         */
	/* global			compute instr/global synthetics                         */
	/* and according to A_PerfStorageParam_InstrLevelFlg, instrument synthetics */
	/* won't be stored (tested in DBA_InsSecondSynthDataPrep())                 */
	/* Suppress field A_Domain_PerfDetLevelEn
    */
    SET_FLAG_FALSE(domainPtr, A_Domain_SubGridFlg); /* PMSTA-18096 - LJE - 140623 */

	if (IS_NULLFLD(pspPtr, A_PerfStorageParam_GridId) == FALSE)
	{
		SET_ID(domainPtr,   A_Domain_GridId,        GET_ID(pspPtr, A_PerfStorageParam_GridId));

        /* PMSTA-18096 - LJE - 140623 */
        if (GET_FLAG(pspPtr, A_PerfStorageParam_InstrLevelFlg) == FALSE)
        {
            SET_ENUM(domainPtr, A_Domain_RetDetLevelEn, PtfRetDetLvl_Grid);
        }
        else
        {
            SET_FLAG_TRUE(domainPtr, A_Domain_SubGridFlg);
            SET_ENUM(domainPtr, A_Domain_RetDetLevelEn, PtfRetDetLvl_Instrument);
        }
	}
	else
	{
		/* REF9738 - RAK - 040105 */
		/* In case of global storage, we want to compute (but not store) instrument synthetics */
		SET_NULL_ID(domainPtr, A_Domain_GridId);

        /* PMSTA-10818 - LJE - 101119 */
		if (GET_FLAG(pspPtr, A_PerfStorageParam_InstrLevelFlg) == FALSE)
		{
            SET_ENUM(domainPtr, A_Domain_RetDetLevelEn, PtfRetDetLvl_Global);
        }
		else
		{
            SET_ENUM(domainPtr, A_Domain_RetDetLevelEn, PtfRetDetLvl_Instrument);
        }
	}

	/* use PPDA for other arguments of Domain */
	if (IS_NULLFLD(pspPtr, A_PerfStorageParam_PositionDataId) == FALSE)
	{
		DBA_DYNFLD_STP	aPPDAPtr=NULLDYNST;

		/* PMSTA-9378 - RAK - 100705 - Get in hierarchy */
		if ((ret = DBA_GetRecPtrFromHierById(hierHeadPtr, GET_ID(pspPtr, A_PerfStorageParam_PositionDataId),
                                             A_PSPPositionData, &aPPDAPtr)) != RET_SUCCEED || aPPDAPtr==NULLDYNST)
		{
			if (GET_ID(pspPtr, A_PerfStorageParam_PositionDataId) > 0)
			{
				if ((aPPDAPtr = ALLOC_DYNST(A_PSPPositionData)) == NULLDYNST)
		{
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

				SET_ID(aPPDAPtr, A_PSPPositionData_Id, GET_ID(pspPtr, A_PerfStorageParam_PositionDataId));

				if ((ret = DBA_Get2(PSPPositionData, UNUSED, A_PSPPositionData,
	    							aPPDAPtr, A_PSPPositionData, &aPPDAPtr,
									UNUSED, UNUSED, UNUSED)) != RET_SUCCEED)
		{
					FREE_DYNST(aPPDAPtr, A_PSPPositionData);
					return(ret);
		}

				if ((ret = DBA_AddHierRecord(hierHeadPtr, aPPDAPtr, A_PSPPositionData, TRUE,
								  HierAddRec_NoLnk)) != RET_SUCCEED)
		{
					FREE_DYNST(aPPDAPtr, A_PSPPositionData);
					return(ret);
				}
			}
		}

			/* REF9882 - RAK - 040202 - PPS Info */
			/* Update same fields than in FIN_SynthComputePPSPtfSynth() */
			/* SET_ID(domainPtr, A_Domain_CurrId,       GET_ID(PPSTab[j], A_PtfPosSet_CurrId));
			   SET_ID(domainPtr, A_Domain_ConsPtfId,    GET_ID(PPSTab[j], A_PtfPosSet_ConsPtfId));
			   SET_ID(domainPtr, A_Domain_PortPosSetId, GET_ID(PPSTab[j], A_PtfPosSet_TpId));
			   SET_ENUM(domainPtr, A_Domain_PpsLoadEn,  (ENUM_T) Domain_PpsLoadEn_LoadPps); */
		/* PMSTA-9378 - RAK- 100625 */
		if (aPPDAPtr != NULLDYNST) { FIN_CopyPPDAInfoToDomain(domainPtr, aPPDAPtr); }
	}
	/* PMSTA-9378 - RAK- 100625 - Get DEF_PSP_POSITION_DATA information */
	else
	{
		DBA_DYNFLD_STP	defPPDaPtr=NULLDYNST;

		if (FIN_GetDefPPDa(&defPPDaPtr) == RET_SUCCEED && defPPDaPtr != NULLDYNST)
			FIN_CopyPPDAInfoToDomain(domainPtr, defPPDaPtr);

		FREE_DYNST(defPPDaPtr, A_PSPPositionData);
	}

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_CopyPPDAInfoToDomain()
**
**  Description :   Get PSP Position Data information into domain
**
**
**  Arguments   :   domainPtr 	pointer on domain
**					PPDAPtr		pointer on PSP Position Data
**
**  Return      :   TRUE or FALSE
**
**  Creation	:   PMSTA-9378 - RAK - 100635
**
*************************************************************************/
STATIC void FIN_CopyPPDAInfoToDomain(DBA_DYNFLD_STP domainPtr, DBA_DYNFLD_STP PPDAPtr)
{

	COPY_DYNFLD(domainPtr, A_Domain,		  A_Domain_ConsPtfId,
	    PPDAPtr,  A_PSPPositionData, A_PSPPositionData_ConsPtfId);

	COPY_DYNFLD(domainPtr, A_Domain,		  A_Domain_PpsLoadEn,
        PPDAPtr,  A_PSPPositionData, A_PSPPositionData_PPSLoadEn);

	COPY_DYNFLD(domainPtr, A_Domain,          A_Domain_PortPosSetId,
        PPDAPtr,  A_PSPPositionData, A_PSPPositionData_PortPosTypeId);

	/******************************/
	/* Strategy link informations */
	COPY_DYNFLD(domainPtr, A_Domain,		  A_Domain_StratLnkNatEn,
        PPDAPtr,  A_PSPPositionData, A_PSPPositionData_StratLnkNatEn);

	COPY_DYNFLD(domainPtr, A_Domain,		  A_Domain_MinLnkPriority,
        PPDAPtr,  A_PSPPositionData, A_PSPPositionData_MinLnkPriority);

	COPY_DYNFLD(domainPtr, A_Domain,		  A_Domain_MaxLnkPriority,
        PPDAPtr,  A_PSPPositionData, A_PSPPositionData_MaxLnkPriority);	/* REF9125 - LJE - 031016 */

	/*******************************/
	/* Fund splitting informations */
	COPY_DYNFLD(domainPtr, A_Domain,		  A_Domain_FundSplitRuleEn,
        PPDAPtr,  A_PSPPositionData, A_PSPPositionData_FundSplitRuleEn);

	/*********************/
	/* Risk informations */
	COPY_DYNFLD(domainPtr, A_Domain,		  A_Domain_RiskExpoFlg,
        PPDAPtr,  A_PSPPositionData, A_PSPPositionData_RiskExpoFlg);

	COPY_DYNFLD(domainPtr, A_Domain,		  A_Domain_OptRiskRuleEn,
        PPDAPtr,  A_PSPPositionData, A_PSPPositionData_OptRiskRuleEn);

	COPY_DYNFLD(domainPtr, A_Domain,		  A_Domain_DebtFlg,
        PPDAPtr,  A_PSPPositionData, A_PSPPositionData_DebtFlg);

	/*********************/
	/* Load informations */
	COPY_DYNFLD(domainPtr, A_Domain,		  A_Domain_MinStatEn,
        PPDAPtr,  A_PSPPositionData, A_PSPPositionData_MinStatEn);

	COPY_DYNFLD(domainPtr, A_Domain,		  A_Domain_MaxStatEn,
        PPDAPtr,  A_PSPPositionData, A_PSPPositionData_MaxStatEn);

	/***********************/
	/* Fusion informations */
    /* PMSTA09979 - LJE - 100825 - No Fusion information can come from
                                   the PSP position data, only used
                                   in P&L market value case
	COPY_DYNFLD(domainPtr, A_Domain,		  A_Domain_FusRuleEn,
        PPDAPtr,  A_PSPPositionData, A_PSPPositionData_FusRuleEn);

	COPY_DYNFLD(domainPtr, A_Domain,		  A_Domain_FusDateRuleEn,
        PPDAPtr,  A_PSPPositionData, A_PSPPositionData_FusDateRuleEn);

	COPY_DYNFLD(domainPtr, A_Domain,		  A_Domain_PosLogicEn,
        PPDAPtr,  A_PSPPositionData, A_PSPPositionData_PosLogicalEn);
     */

	/*************************/
	/* Valuation informations */
	COPY_DYNFLD(domainPtr, A_Domain,		  A_Domain_QuoteValRuleId,
        PPDAPtr,  A_PSPPositionData, A_PSPPositionData_QuoteValRuleId);

	COPY_DYNFLD(domainPtr, A_Domain,		  A_Domain_ExchValRuleId,
        PPDAPtr,  A_PSPPositionData, A_PSPPositionData_ExchValRuleId);

	COPY_DYNFLD(domainPtr, A_Domain,		  A_Domain_PosValRuleEn,
        PPDAPtr,  A_PSPPositionData, A_PSPPositionData_PosValRuleEn);

	/* ?? */
	COPY_DYNFLD(domainPtr, A_Domain,		  A_Domain_ExtPosListId,
        PPDAPtr,  A_PSPPositionData, A_PSPPositionData_ExtPosListId);
}

/************************************************************************
**
**  Function    :   DBA_PSPInfoOrLogSrvMesg()
**
**  Description :   Send a message in server.log with the information of PSP
**					like following example
** 2003/09/23 15:52:33:AAASERV802     :rak       :  5(cli) : Portfolio Storage / RAK / PSP 93000353 / Day / no grid / CHF / LJE_1 / standard perf attrib
** 2003/09/23 15:52:33:AAASERV802     :rak       :  5(cli) : Portfolio Storage / RAK / PSP 93000351 / Month / no grid / CHF / no position data / standard perf attrib
** 2003/09/23 15:52:33:AAASERV802     :rak       :  5(cli) : Portfolio Storage / RAK / PSP 93000352 / Month / CGR_PM_MKT / CHF / no position data / standard perf attrib
**
**
**  Arguments   :	hierPtr		pointer on currenct hierarchy
**					dictFctInfo	pointer on current fonction informations (is set by DBA_GetDictFctInfo)
**					objCd		code of the current object (ptf, strat, instr)
**					pspId		PSP identifier (is used if pspPtr is NULL)
**					pspPtr		pointer on PSP (could be NULL, if hier and pspId are received, function will get it)
**				    pspInfo		if not NULL (must be allocated with 150) will contain PSP informations :
**							    (PSP 93500354 / Month / CGR_bench_mkt_2d / CHF / no position data / standard perf attrib)
**
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   REF9125 - RAK - 030923
**
**  Last modif. :   PMSTA-15184 - 151012 - PMO : Some warnings during TA build process
**
*************************************************************************/
RET_CODE DBA_PSPInfoOrLogSrvMesg(DBA_HIER_HEAD_STP hierPtr,
                                        DBA_DYNFLD_STP    domainPtr,        /* REF9770 - LJE - 040121 */
						                DICT_FCT_STP	  dictFctInfo,
						                OBJECT_ENUM		  objEn,			/* REF9688 - RAK - 031120 */
						                const char *      objCd,            /* PMSTA-15184 - 151012 - PMO */
						                ID_T			  pspId,
						                DBA_DYNFLD_STP	  pspPtr,
						                char			 *pspInfo)
{
    RET_CODE		ret = RET_SUCCEED;

    try
    {
        DBA_DYNFLD_STP	aPPDAPtr = NULLDYNST, gridPtr = NULLDYNST;
        char			*gridInfo = NULL, *ppdaInfo = NULL, *currCd = NULL, *objSqlName = NULL;
        MemoryPool      mp;

        /* REF9770 - LJE - 040121 */
        char            fromDBuf[32], tillDBuf[32];
        DATE_FORMAT_ST  dateFormat;

        fromDBuf[0] = END_OF_STRING;
        tillDBuf[0] = END_OF_STRING;

        if (pspPtr == NULLDYNST && pspId <= 0)
        {
            MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
                         "DBA_PSPInfoOrLogSrvMesg", "PSP identifier and struct are NULL");
            return(RET_GEN_ERR_INVARG);
        }

        if (pspPtr == NULLDYNST && hierPtr == (DBA_HIER_HEAD_STP)NULL)
        {
            MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
                         "DBA_PSPInfoOrLogSrvMesg", "PSP struct and hierarchy are NULL");
            return(RET_GEN_ERR_INVARG);
        }

        /* get PSP if just id and hierarchy are received */
        if (pspPtr == NULLDYNST)
        {
            if ((ret = DBA_GetRecPtrFromHierById(hierPtr, pspId,
                                                 A_PerfStorageParam, &pspPtr)) != RET_SUCCEED)
            {
                return(ret);
            }
        }

        if (pspPtr == NULLDYNST)
        {
            MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
                         "DBA_PSPInfoOrLogSrvMesg", "PSP not found");
            return(RET_GEN_ERR_INVARG);
        }

        gridInfo = (char *)mp.calloc(FILEINFO, GET_MAXDATALEN(CodeType), sizeof(char)); /* PMSTA-33077 - DLA - 181011 */
        ppdaInfo = (char *)mp.calloc(FILEINFO, (GET_MAXDATALEN(CodeType)) * 4, sizeof(char));
        currCd = (char *)mp.calloc(FILEINFO, GET_MAXDATALEN(CodeType), sizeof(char));
        objSqlName = (char *)mp.calloc(FILEINFO, GET_MAXDATALEN(SysnameType), sizeof(char));
        char *perfCalcDefProfInfo = (char*)mp.calloc(FILEINFO, GET_MAXDATALEN(CodeType), sizeof(char));     /* PMSTA-54529 - DDV - 231009 */

        /* REF9688 - RAK - 031120 */
        strcpy(objSqlName, DBA_GetDictEntitySqlName(objEn));

        /* Get currency pointer (currency identifier is mandatory) */
        if (IS_NULLFLD(pspPtr, A_PerfStorageParam_CurrId) == FALSE)
        {
            FLAG_T         freeFlag = FALSE;
            DBA_DYNFLD_STP currPtr  = NULLDYNST;

            /* PMSTA16847 - DDV - 130924 - Add freeFlag parameter */
            if ((ret = DBA_GetCurrById(GET_ID(pspPtr, A_PerfStorageParam_CurrId), &currPtr, &freeFlag)) != RET_SUCCEED)
            {
                return(ret);
            }

            strcpy(currCd, GET_CODE(currPtr, A_Curr_Cd));
            if (freeFlag == TRUE)
            {
                FREE_DYNST(currPtr, A_Curr);
            }
        }
        else
        {
            strcpy(currCd, "no currency");
        }

        /* If grid exist, get it */
        if (IS_NULLFLD(pspPtr, A_PerfStorageParam_GridId) == FALSE)
        {
            if ((ret = DBA_GetRecPtrFromHierById(hierPtr, GET_ID(pspPtr, A_PerfStorageParam_GridId),
                                                 A_Grid, &gridPtr)) != RET_SUCCEED)
            {
                return(ret);
            }

            if (gridPtr == NULLDYNST)
            {
                DBA_DYNFLD_STP	sGridPtr = mp.allocDynst(FILEINFO, S_Grid);

                gridPtr = mp.allocDynst(FILEINFO, A_Grid);

                SET_ID(sGridPtr, S_Grid_Id, GET_ID(pspPtr, A_PerfStorageParam_GridId));
                if ((ret = DBA_Get2(Grid, UNUSED, S_Grid,
                                    sGridPtr, A_Grid, &gridPtr,
                                    UNUSED, UNUSED, UNUSED)) != RET_SUCCEED)
                {
                    return(ret);
                }
            }

            if (gridPtr != NULLDYNST)
            {
                strcpy(gridInfo, GET_CODE(gridPtr, A_Grid_Cd));
            }
            else
            {
                strcpy(gridInfo, "grid X");
            }
        }
        else
        {
            strcpy(gridInfo, "no grid");
        }

        if (IS_NULLFLD(pspPtr, A_PerfStorageParam_PositionDataId) == FALSE)
        {
            /* PMSTA-9378 - RAK - 100605 */
            if ((ret = DBA_GetRecPtrFromHierById(hierPtr, GET_ID(pspPtr, A_PerfStorageParam_PositionDataId),
                                                 A_PSPPositionData, &aPPDAPtr)) != RET_SUCCEED)
            {
                return(ret);
            }

            if (aPPDAPtr == NULLDYNST && GET_ID(pspPtr, A_PerfStorageParam_PositionDataId) > 0)
            {
                aPPDAPtr = mp.allocDynst(FILEINFO, A_PSPPositionData);

                SET_ID(aPPDAPtr, A_PSPPositionData_Id, GET_ID(pspPtr, A_PerfStorageParam_PositionDataId));
                if ((ret = DBA_Get2(PSPPositionData, UNUSED, A_PSPPositionData,
                                    aPPDAPtr, A_PSPPositionData, &aPPDAPtr,
                                    UNUSED, UNUSED, UNUSED)) != RET_SUCCEED)
                {
                    return(ret);
                }
            }

            if (aPPDAPtr)
            {
                if (IS_NULLFLD(aPPDAPtr, A_PSPPositionData_Code) == FALSE)
                {
                    strcpy(ppdaInfo, GET_CODE(aPPDAPtr, A_PSPPositionData_Code));
                }
                else
                {
                    /* PMSTA-9378 - RAK - 100605 */
                    sprintf(ppdaInfo, "position data %" szFormatId, GET_ID(aPPDAPtr, A_PSPPositionData_Id));
                }
            }
        }
        else
        {
            strcpy(ppdaInfo, "no position data");
        }

        /* PMSTA-54529 - DDV - 231009 */
        if (IS_NULLFLD(pspPtr, A_PerfStorageParam_PerfCalcDefProfileId) == FALSE)
        {
            DBA_DYNFLD_STP	sPerfCalcDefProf = mp.allocDynst(FILEINFO, S_PerfCalcDefProfile);
            DBA_DYNFLD_STP	aPerfCalcDefProf = mp.allocDynst(FILEINFO, A_PerfCalcDefProfile);

            SET_ID(sPerfCalcDefProf, S_PerfCalcDefProfile_Id, GET_ID(pspPtr, A_PerfStorageParam_PerfCalcDefProfileId));

            if ((ret = DBA_Get2(PerfCalcDefProfile, UNUSED, S_PerfCalcDefProfile,
                                sPerfCalcDefProf, A_PerfCalcDefProfile, &aPerfCalcDefProf,
                                UNUSED, UNUSED, UNUSED)) != RET_SUCCEED)
            {
                return(ret);
            }

            if (aPerfCalcDefProf != NULLDYNST)
            {
                strcpy(perfCalcDefProfInfo, GET_CODE(aPerfCalcDefProf, A_PerfCalcDefProfile_Cd));
            }
            else
            {
                strcpy(perfCalcDefProfInfo, "perf_calc_def_prof X");
            }
        }
        else
        {
            strcpy(perfCalcDefProfInfo, "no perf_calc_def_prof");
        }

        /* REF9770 - LJE - 040121 */
        if (domainPtr != NULL)
        {
            dateFormat.ordre = Ymd;
            strcpy(dateFormat.yearSep, "/");
            strcpy(dateFormat.monthSep, "/");
            strcpy(dateFormat.daySep, "/");
            dateFormat.yearFormat = 1;
            dateFormat.monthFormat = 0;

            DATE_FormatToStr(fromDBuf, GET_DATETIME(domainPtr, A_Domain_InterpFromDate).date, &dateFormat);
            DATE_FormatToStr(tillDBuf, GET_DATETIME(domainPtr, A_Domain_InterpTillDate).date, &dateFormat);
        }

        if (pspInfo != NULL)
        {
            sprintf(pspInfo, "PSP %" szFormatId" / %s / %s / %s / %s / %s / %s - %s / %s : objptfid - %" szFormatId" ", /* DLA - PMSTA08801 - 100209 */
                GET_ID(pspPtr, A_PerfStorageParam_Id),
                DBA_GetPermValPtr(PerfStorageParam, A_PerfStorageParam_FrequencyEn, GET_ENUM(pspPtr, A_PerfStorageParam_FrequencyEn)),
                gridInfo,
                currCd,
                ppdaInfo,
                DBA_GetPermValPtr(PerfStorageParam, A_PerfStorageParam_PerfAttribReturnEn, GET_ENUM(pspPtr, A_PerfStorageParam_PerfAttribReturnEn)),
                fromDBuf,
                tillDBuf,
                perfCalcDefProfInfo,
                GET_ID(pspPtr, A_PerfStorageParam_ObjPtfId));
        }
        else
        {
            /* REF9836 - RAK - 040122 - Change mesage for SynthAdmin PSP */
            if (GET_DICT(domainPtr, A_Domain_InitialFctDictId) == (DICT_FCT_ENUM)DictFct_PtfStorage &&
                (COMPDATA_ENUM)GET_ENUM(domainPtr, A_Domain_CompDataEn) != CompData_OnLine &&
                GET_ID(pspPtr, A_PerfStorageParam_Id) < 0)
            {
                MSG_LogSrvMesg(UNUSED, 0, "%1 / %2 %3 / SYNTH ADMIN / %4 / %5 / %6 / %7 - %8 / %9",
                    NameType, dictFctInfo->name,
                    TextType, objSqlName,
                    TextType, objCd,
                    TextType, DBA_GetPermValPtr(PerfStorageParam, A_PerfStorageParam_FrequencyEn, GET_ENUM(pspPtr, A_PerfStorageParam_FrequencyEn)),
                    TextType, gridInfo,
                    TextType, currCd,
                    TextType, fromDBuf,
                    TextType, tillDBuf,
                    TextType, perfCalcDefProfInfo);
            }
            else
            {
                MSG_LogSrvMesg(UNUSED, 0, "%1 / %2 %3 / PSP %4 / %5 / %6 / %7 / %8 / %9 / %10 - %11 / %12",
                               NameType, dictFctInfo->name,
                               TextType, objSqlName,
                               TextType, objCd,
                               IdType, GET_ID(pspPtr, A_PerfStorageParam_Id),
                               TextType, DBA_GetPermValPtr(PerfStorageParam, A_PerfStorageParam_FrequencyEn, GET_ENUM(pspPtr, A_PerfStorageParam_FrequencyEn)),
                               TextType, gridInfo,
                               TextType, currCd,
                               TextType, ppdaInfo,
                               TextType, DBA_GetPermValPtr(PerfStorageParam, A_PerfStorageParam_PerfAttribReturnEn, GET_ENUM(pspPtr, A_PerfStorageParam_PerfAttribReturnEn)),
                               TextType, fromDBuf,
                               TextType, tillDBuf,
                               TextType, perfCalcDefProfInfo);
            }
        }
    }
    catch (std::bad_alloc &e)
    {
        MSG_SendExceptionMesg(FILEINFO, "DBA_PSPInfoOrLogSrvMesg", e.what());
        return RET_MEM_ERR_ALLOC;
    }

	return(ret);
}

/************************************************************************
**
**  Function    :   DBA_CommonScptFlagTabPa()
**
**  Description :   Initialise common parts of flag array for script evalation for
**                  PerfAttrib view. Only the common fields are
**                  initialised.
**                  TRUE:  field is not evaluated by default values
**                  FALSE: field is evaluated by default values
**
**  Arguments   :   input:
**                  scptFlagTabExtRa
**
**                  output:
**                  scptFlagTabExtRa
**
**  Return      :   RET_SUCCEED
**
**  Creation    :   REF7421 - YST - 020827
**
*************************************************************************/
STATIC RET_CODE DBA_CommonScptFlagTabPa(FLAG_T *scptFlagTabPa)
{
    int     i=0;

    for (i=0; i<GET_FLD_NBR(A_PerfAttrib); i++)
        scptFlagTabPa[i] = FALSE;

    scptFlagTabPa[A_PerfAttrib_Id]                  = TRUE; /* NULL */
    scptFlagTabPa[A_PerfAttrib_PerfStorParamId]     = TRUE; /* copied from A_PerfStorageParam */
    scptFlagTabPa[A_PerfAttrib_EntDictId]           = TRUE; /* copied from A_PerfStorageParam */
    scptFlagTabPa[A_PerfAttrib_ObjId]               = TRUE; /* copied from A_PerfStorageParam */
    scptFlagTabPa[A_PerfAttrib_FreqEn]              = TRUE; /* copied from A_PerfStorageParam */
    scptFlagTabPa[A_PerfAttrib_CurrId]              = TRUE; /* copied from A_PerfStorageParam */
    scptFlagTabPa[A_PerfAttrib_PosDataId]           = TRUE; /* copied from A_PerfStorageParam */
    scptFlagTabPa[A_PerfAttrib_GridId]              = TRUE; /* copied from A_PerfStorageParam */
    scptFlagTabPa[A_PerfAttrib_PerfAttribRtnEn]     = TRUE; /* copied from A_PerfStorageParam */
    scptFlagTabPa[A_PerfAttrib_InitialDate]         = TRUE;
    scptFlagTabPa[A_PerfAttrib_FinalDate]           = TRUE;
    scptFlagTabPa[A_PerfAttrib_MktSegtId]           = TRUE;
    scptFlagTabPa[A_PerfAttrib_InstrId]             = TRUE;
    scptFlagTabPa[A_PerfAttrib_SubPeriodMask]       = TRUE;
    scptFlagTabPa[A_PerfAttrib_PortSynthId]         = TRUE; /* no default value */
    scptFlagTabPa[A_PerfAttrib_StratSynthId]        = TRUE; /* no default value */
	scptFlagTabPa[A_PerfAttrib_ExtStratEltId]       = TRUE; /* no default value */
    scptFlagTabPa[A_PerfAttrib_GlobalPerfAttribId]  = TRUE; /* no default value */
    scptFlagTabPa[A_PerfAttrib_Bench1PerfAttribId]  = TRUE; /* no default value */
    scptFlagTabPa[A_PerfAttrib_Bench2PerfAttribId]  = TRUE; /* no default value */
    scptFlagTabPa[A_PerfAttrib_Bench3PerfAttribId]  = TRUE; /* no default value */
    scptFlagTabPa[A_PerfAttrib_RiskFreeStdPerfId]   = TRUE; /* no default value */
    scptFlagTabPa[A_PerfAttrib_PaMktSelection]      = TRUE; /* no default value */
    scptFlagTabPa[A_PerfAttrib_PaStockPicking]      = TRUE; /* no default value */
    scptFlagTabPa[A_PerfAttrib_PaInteraction]       = TRUE; /* no default value */
    scptFlagTabPa[A_PerfAttrib_PaCurrSelection]     = TRUE; /* no default value */
    scptFlagTabPa[A_PerfAttrib_ParentId]            = TRUE; /* no default value */

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   DBA_CommonScptFlagTabExtRa()
**
**  Description :   Initialise common parts of flag array for script evalation for
**                  ExtRetAnalysis view. Only the common fields are
**                  initialised.
**                  TRUE:  field is not evaluated by default values
**                  FALSE: field is evaluated by default values
**
**  Arguments   :   input:
**                  scptFlagTabExtRa
**
**                  output:
**                  scptFlagTabExtRa
**
**  Return      :   RET_SUCCEED
**
**  Creation    :   REF7421 - YST - 020827
**
*************************************************************************/
STATIC RET_CODE DBA_CommonScptFlagTabExtRa(FLAG_T *scptFlagTabExtRa)
{
    int     i=0;

    for (i=0; i<GET_FLD_NBR(A_ExtRetAnalysis); i++)
        scptFlagTabExtRa[i] = FALSE;

    scptFlagTabExtRa[A_ExtRetAnalysis_Id]                   = TRUE; /* NULL */
    scptFlagTabExtRa[A_ExtRetAnalysis_PerfStorParamId]      = TRUE; /* copied from A_PerfStorageParam */
    scptFlagTabExtRa[A_ExtRetAnalysis_EntDictId]            = TRUE;
    scptFlagTabExtRa[A_ExtRetAnalysis_ObjId]                = TRUE; /* copied from A_PerfStorageParam */
    scptFlagTabExtRa[A_ExtRetAnalysis_FreqEn]               = TRUE; /* copied from A_PerfStorageParam */
    scptFlagTabExtRa[A_ExtRetAnalysis_CurrId]               = TRUE; /* copied from A_PerfStorageParam */
    scptFlagTabExtRa[A_ExtRetAnalysis_PosDataId]            = TRUE; /* copied from A_PerfStorageParam */
    scptFlagTabExtRa[A_ExtRetAnalysis_GridId]               = TRUE; /* copied from A_PerfStorageParam */
    scptFlagTabExtRa[A_ExtRetAnalysis_PerfAttribRtnEn]      = TRUE; /* copied from A_PerfStorageParam */
    scptFlagTabExtRa[A_ExtRetAnalysis_InitialDate]          = TRUE;
    scptFlagTabExtRa[A_ExtRetAnalysis_FinalDate]            = TRUE;
    scptFlagTabExtRa[A_ExtRetAnalysis_PortSynthId]          = TRUE; /* no default value */
    scptFlagTabExtRa[A_ExtRetAnalysis_GblExtRetAnalysisId]  = TRUE; /* no default value */
    scptFlagTabExtRa[A_ExtRetAnalysis_ExtStratEltId]        = TRUE; /* no default value */
    scptFlagTabExtRa[A_ExtRetAnalysis_InstrFreqId]          = TRUE; /* no default value */
    scptFlagTabExtRa[A_ExtRetAnalysis_PtfFreqId]	        = TRUE; /* no default value */
    scptFlagTabExtRa[A_ExtRetAnalysis_RiskFreeId]           = TRUE; /* no default value */
    scptFlagTabExtRa[A_ExtRetAnalysis_BenchId]              = TRUE; /* no default value */
    scptFlagTabExtRa[A_ExtRetAnalysis_ParentId]             = TRUE; /* no default value */

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   DBA_CommonScptFlagTabStdPerf()
**
**  Description :   Initialise common parts of flag array for script evalation for
**                  StandardPerf view. Only the common fields are
**                  initialised.
**                  TRUE:  field is not evaluated by default values
**                  FALSE: field is evaluated by default values
**
**  Arguments   :   input:
**                  scptFlagTabStdPerf
**
**                  output:
**                  scptFlagTabStdPerf
**
**  Return      :   RET_SUCCEED
**
**  Creation    :   REF7421 - YST - 020904
**
*************************************************************************/
STATIC RET_CODE DBA_CommonScptFlagTabStdPerf(FLAG_T *scptFlagTabStdPerf)
{
    int     i=0;

    for (i=0; i<GET_FLD_NBR(A_StandardPerf); i++)
        scptFlagTabStdPerf[i] = FALSE;

    scptFlagTabStdPerf[A_StandardPerf_Id]                   = TRUE; /* NULL */
    scptFlagTabStdPerf[A_StandardPerf_PerfStorParamId]      = TRUE; /* copied from A_PerfStorageParam */
    scptFlagTabStdPerf[A_StandardPerf_EntDictId]            = TRUE;
    scptFlagTabStdPerf[A_StandardPerf_ObjId]                = TRUE; /* copied from A_PerfStorageParam */
    scptFlagTabStdPerf[A_StandardPerf_FreqEn]               = TRUE; /* copied from A_PerfStorageParam */
    scptFlagTabStdPerf[A_StandardPerf_CurrId]               = TRUE; /* copied from A_PerfStorageParam */
    scptFlagTabStdPerf[A_StandardPerf_PosDataId]            = TRUE; /* copied from A_PerfStorageParam */
    scptFlagTabStdPerf[A_StandardPerf_GridId]               = TRUE; /* copied from A_PerfStorageParam */
    scptFlagTabStdPerf[A_StandardPerf_PerfAttribRtnEn]      = TRUE; /* copied from A_PerfStorageParam */
    scptFlagTabStdPerf[A_StandardPerf_InitialDate]          = TRUE;
    scptFlagTabStdPerf[A_StandardPerf_FinalDate]            = TRUE;
    scptFlagTabStdPerf[A_StandardPerf_PortSynthId]          = TRUE; /* no default value */
    scptFlagTabStdPerf[A_StandardPerf_StratSynthId]         = TRUE; /* no default value */ /* PMSTA08736 - LJE - 100125 */
	scptFlagTabStdPerf[A_StandardPerf_ExtStratEltId]        = TRUE; /* no default value */
    scptFlagTabStdPerf[A_StandardPerf_InstrFreqId]          = TRUE; /* no default value */
    scptFlagTabStdPerf[A_StandardPerf_PtfFreqId]	        = TRUE; /* no default value */
    scptFlagTabStdPerf[A_StandardPerf_RiskFreeId]           = TRUE; /* no default value */
    scptFlagTabStdPerf[A_StandardPerf_BenchId]              = TRUE; /* no default value */

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   DBA_CopyPspToPa()
**
**  Description :   Copy values from PSP table to PerfAttrib view.
**
**  Arguments   :   input:
**                  aPspPtr         PSP structure pointer
**
**                  output:
**                  perfAttribPtr   PerfAttrib structure pointer
**
**  Return      :   RET_SUCCEED
**
**  Creation    :   REF7421 - YST - 020827
**
*************************************************************************/
STATIC RET_CODE DBA_CopyPspToPa(DBA_DYNFLD_STP aPspPtr, DBA_DYNFLD_STP perfAttribPtr)
{
    /* REF9743 - LJE - 040204 */
    CONVERT_DYNST(perfAttribPtr, A_PerfAttrib, aPspPtr, A_PerfStorageParam);

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   DBA_CopyPspToExtRa()
**
**  Description :   Copy values from PSP table to ExtRetAnalysis view.
**
**  Arguments   :   input:
**                  aPspPtr             PSP structure pointer
**
**                  output:
**                  extRetAnalysisPtr   ExtRetAnalysis structure pointer
**
**  Return      :   RET_SUCCEED
**
**  Creation    :   REF7421 - YST - 020827
**
*************************************************************************/
STATIC RET_CODE DBA_CopyPspToExtRa(DBA_DYNFLD_STP aPspPtr, DBA_DYNFLD_STP extRetAnalysisPtr)
{
    /* REF9743 - LJE - 040204 */
    CONVERT_DYNST(extRetAnalysisPtr,  A_ExtRetAnalysis, aPspPtr, A_PerfStorageParam);

    return(RET_SUCCEED);
}


/************************************************************************
**
**  Function    :   DBA_CopyPspToStdPerf()
**
**  Description :   Copy values from PSP table to StandardPerf view.
**
**  Arguments   :   input:
**                  aPspPtr             PSP structure pointer
**
**                  output:
**                  stdPerfPtr          StandardPerf structure pointer
**
**  Return      :   RET_SUCCEED
**
**  Creation    :   REF7421 - YST - 020905
**
*************************************************************************/
STATIC RET_CODE DBA_CopyPspToStdPerf(DBA_DYNFLD_STP aPspPtr, DBA_DYNFLD_STP stdPerfPtr)
{
    /* REF9743 - LJE - 040203 */
    CONVERT_DYNST(stdPerfPtr, A_StandardPerf, aPspPtr, A_PerfStorageParam);

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   DBA_PrepareSPForAddInHier()
**
**  Description :
**
**  Arguments   :
**
**                  output:
**
**  Return      :   TRUE    if at least one field is filled with value
**                  FALSE   if no field is filled
**
**  Creation    :   REF9055 - LJE - 030430
**
*************************************************************************/
STATIC RET_CODE DBA_PrepareSPForAddInHier(DBA_HIER_HEAD_STP  ,
                                          DBA_DYNFLD_STP     extRaPtr,
                                          DBA_DYNFLD_STP     *stdPerfTab,
                                          DBA_INSPAEXTRA_STP ,
                                          int                *stdPerfNbr)
{
    RET_CODE        retCd = RET_SUCCEED;

    if (IS_NULLFLD(extRaPtr, A_ExtRetAnalysis_MktSegtId) != TRUE ||
        IS_NULLFLD(extRaPtr, A_ExtRetAnalysis_InstrId)   != TRUE)
       return(RET_SUCCEED);


    if ((stdPerfTab[*stdPerfNbr] = ALLOC_DYNST(A_StandardPerf)) == NULLDYNST)
    {
        retCd = RET_MEM_ERR_REALLOC;
    }

    if (retCd == RET_SUCCEED)
    {
        /* copy fields from ExtRetAnalysis to StandardPerf */
        CONVERT_DYNST(stdPerfTab[*stdPerfNbr], A_StandardPerf, extRaPtr, A_ExtRetAnalysis);

		SET_NULL_ID(stdPerfTab[*stdPerfNbr], A_StandardPerf_Id); /* PMSTA08640 - LJE - 090907 */

        (*stdPerfNbr)++;
    }

    return(retCd);
}

/************************************************************************
**
**  Function    :   DBA_TestRaGlobalData()
**
**  Description :
**
**  Arguments   :   input:
**                  extRaPtr   ExtRetAnalysis structure pointer
**
**                  output:
**
**  Return      :   TRUE    if at least one field is filled with value
**                  FALSE   if no field is filled
**
**  Creation    :   REF7421 - YST - 020906 - not finish yet
**
*************************************************************************/
STATIC RET_CODE DBA_TestRaGlobalData(DBA_HIER_HEAD_STP  hierHead,
                                     DBA_DYNFLD_STP     extRaPtr,
                                     DBA_DYNFLD_STP     *stdPerfTab,
                                     DBA_INSPAEXTRA_STP insPaExtRaStp,
                                     int                *stdPerfNbr,
                                     FLAG_T             *stdPerfFlg)
{
    RET_CODE        retCd = RET_SUCCEED;
    /*DBA_DYNFLD_ST   stdPerfPtr = NULDYNST;*/

    if (IS_NULLFLD(extRaPtr, A_ExtRetAnalysis_Dividend) != TRUE)
    {return(RET_SUCCEED);}
    else if (IS_NULLFLD(extRaPtr, A_ExtRetAnalysis_MeanInvestCap) != TRUE)
    {return(RET_SUCCEED);}
    else if (IS_NULLFLD(extRaPtr, A_ExtRetAnalysis_Rtn1) != TRUE)
    {return(RET_SUCCEED);}
    else if (IS_NULLFLD(extRaPtr, A_ExtRetAnalysis_Invest) != TRUE)
    {return(RET_SUCCEED);}
    else if (IS_NULLFLD(extRaPtr, A_ExtRetAnalysis_Withdr) != TRUE)
    {return(RET_SUCCEED);}
    else if (IS_NULLFLD(extRaPtr, A_ExtRetAnalysis_Inc1) != TRUE)
    {return(RET_SUCCEED);}
    else if (IS_NULLFLD(extRaPtr, A_ExtRetAnalysis_Inc2) != TRUE)
    {return(RET_SUCCEED);}
    else if (IS_NULLFLD(extRaPtr, A_ExtRetAnalysis_CapPl1) != TRUE)
    {return(RET_SUCCEED);}
    else if (IS_NULLFLD(extRaPtr, A_ExtRetAnalysis_CapPl2) != TRUE)
    {return(RET_SUCCEED);}
    else if (IS_NULLFLD(extRaPtr, A_ExtRetAnalysis_CurrPl1) != TRUE)
    {return(RET_SUCCEED);}
    else if (IS_NULLFLD(extRaPtr, A_ExtRetAnalysis_CurrPl2) != TRUE)
    {return(RET_SUCCEED);}
    else if (IS_NULLFLD(extRaPtr, A_ExtRetAnalysis_Rtn2) != TRUE)
    {return(RET_SUCCEED);}
    else if (IS_NULLFLD(extRaPtr, A_ExtRetAnalysis_Rtn3) != TRUE)
    {return(RET_SUCCEED);}
    else if (IS_NULLFLD(extRaPtr, A_ExtRetAnalysis_CapEffect) != TRUE)
    {return(RET_SUCCEED);}
    else if (IS_NULLFLD(extRaPtr, A_ExtRetAnalysis_CurrEffect) != TRUE)
    {return(RET_SUCCEED);}
    else if (IS_NULLFLD(extRaPtr, A_ExtRetAnalysis_FeesTaxEffect) != TRUE)
    {return(RET_SUCCEED);}
    else if (IS_NULLFLD(extRaPtr, A_ExtRetAnalysis_IncEffect) != TRUE)
    {return(RET_SUCCEED);}
    else
    {
        *stdPerfFlg = TRUE;

        if ((insPaExtRaStp->stdPerfTab) == (DBA_DYNFLD_STP *)NULL)
        {
            insPaExtRaStp->stdPerfNbr = 0;
            if (((insPaExtRaStp->stdPerfTab) = (DBA_DYNFLD_STP *)CALLOC(1, sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR)
            {
                retCd = RET_MEM_ERR_ALLOC;
            }
        }
        else
        {
            if (((insPaExtRaStp->stdPerfTab) = (DBA_DYNFLD_STP *)REALLOC((insPaExtRaStp->stdPerfTab),
                                (insPaExtRaStp->stdPerfNbr+1)*sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR)
            {
                retCd = RET_MEM_ERR_REALLOC;
            }
        }

        if ((stdPerfTab[*stdPerfNbr] = ALLOC_DYNST(A_StandardPerf)) == NULLDYNST)
        {
            retCd = RET_MEM_ERR_REALLOC;
        }

        if (retCd == RET_SUCCEED)
        {

        /* copy fields from ExtRetAnalysis to StandardPerf */
        CONVERT_DYNST(stdPerfTab[*stdPerfNbr], A_StandardPerf, extRaPtr, A_ExtRetAnalysis);

        (insPaExtRaStp->stdPerfTab)[insPaExtRaStp->stdPerfNbr++] = stdPerfTab[*stdPerfNbr];
        (*stdPerfNbr)++;

        /* delete and free ExtRetAnalysis in hierarchy */
        retCd = DBA_DelAndFreeHierEltRecWithFilter(hierHead, A_ExtRetAnalysis,
                                                    DBA_FilterExtRaNotOk, stdPerfTab[(*stdPerfNbr)-1], NULL);

        }
    }
    return(retCd);
}

/************************************************************************
**
**  Function    :   DBA_FilterSecondSynthPSP()
**
**  Description :   Extract secondary synthetics for a given portfolio.
**                  In addition NO synthetics with return grid link of
**                  nature parallel storage ptf synth should be stored.
**
**  Arguments   :   dynSt       dynamic structure pointer
**                  dynStTp     dynamic structure definition
**		            ptfPtr      parameter dynamic structure pointer
**
**  Return      :   TRUE or FALSE
**
**  Creation	:   REF9125 - RAK - 030917 - Test on PSP id instead of PTF id
**
*************************************************************************/
STATIC int DBA_FilterSecondSynthPSP(DBA_DYNFLD_STP  dynSt,
			                        DBA_DYNST_ENUM  ,
                                    DBA_DYNFLD_STP  pspPtr)
{
    if (GET_ID(dynSt, A_PtfSynth_PSPId) == GET_ID(pspPtr, A_PerfStorageParam_Id) &&
        ((FLAG_T)GET_BIT((MASK_T)GET_TINYINT(dynSt, A_PtfSynth_Level), SynthLevel_Gips) == TRUE ||  /* secondary */
        (FLAG_T)GET_BIT((MASK_T)GET_TINYINT(dynSt, A_PtfSynth_Level), SynthLevel_PA) == TRUE) &&
        (RETURN_GRID_LNK_NAT_ENUM)GET_ENUM(dynSt, A_PtfSynth_GridLinkNatEn) != ReturnGridLnk_ParStorPtfSynth) /* no ParStorPtfSynth */
        return(TRUE);
    else
        return(FALSE);
}

/************************************************************************
**
**  Function    :   DBA_FilterSecondSynthPSPwithPtf()
**
**  Description :   Extract secondary synthetics for a given portfolio with pspid and portfolio id.
**                  In addition NO synthetics with return grid link of
**                  nature parallel storage ptf synth should be stored.
**
**  Arguments   :   dynSt       dynamic structure pointer
**                  dynStTp     dynamic structure definition
**		            ptfPtr      parameter dynamic structure pointer
**
**  Return      :   TRUE or FALSE
**
**  Creation	:   PMSTA-48195 -Performance IPS Level -Lalby-180722
**
*************************************************************************/
STATIC int DBA_FilterSecondSynthPSPwithPtf(DBA_DYNFLD_STP  dynSt,
                                           DBA_DYNST_ENUM,
                                           DBA_DYNFLD_STP  pspPtr)
{
    if (GET_ID(dynSt, A_PtfSynth_PSPId) == GET_ID(pspPtr, A_PerfStorageParam_Id) &&
        GET_ID(dynSt, A_PtfSynth_PtfId) == GET_ID(pspPtr, A_PerfStorageParam_ObjId)) 
    {
        if (((FLAG_T)GET_BIT((MASK_T)GET_TINYINT(dynSt, A_PtfSynth_Level), SynthLevel_Gips) == TRUE ||  /* secondary */
            (FLAG_T)GET_BIT((MASK_T)GET_TINYINT(dynSt, A_PtfSynth_Level), SynthLevel_PA) == TRUE) &&
            (RETURN_GRID_LNK_NAT_ENUM)GET_ENUM(dynSt, A_PtfSynth_GridLinkNatEn) != ReturnGridLnk_ParStorPtfSynth) /* no ParStorPtfSynth */
        {
            return(TRUE);
        }
        else
        {
            return (FALSE);
        }
    }
    else
        return(FALSE);
}

/************************************************************************
**
**  Function    :   DBA_FilterPerfCalcResultPSPwithPtf()
**
**  Description :   Extract perf calc Result for a given portfolio with pspid and portfolio id.
**
**  Arguments   :   dynSt       dynamic structure pointer
**                  dynStTp     dynamic structure definition
**		            ptfPtr      parameter dynamic structure pointer
**
**  Return      :   TRUE or FALSE
**
**  Creation	:   PMSTA-53308 -SENTHIL-060623
**
*************************************************************************/

STATIC int DBA_FilterPerfCalcResultPSPwithPtf(DBA_DYNFLD_STP  dynSt,
                                              DBA_DYNST_ENUM,
                                              DBA_DYNFLD_STP  pspPtr)
{
	if (GET_ID(dynSt, A_PerfCalcResult_PerfStorageParamId) == GET_ID(pspPtr, A_PerfStorageParam_Id) &&
		GET_ID(dynSt, A_PerfCalcResult_ObjId) == GET_ID(pspPtr, A_PerfStorageParam_ObjId))
	{
		return(TRUE);
	}
	else
		return(FALSE);
}

/************************************************************************
**
**  Function    :   DBA_FilterSynthPSP()
**
**  Description :   Extract secondary synthetics for a given portfolio.
**                  In addition NO synthetics with return grid link of
**                  nature parallel storage ptf synth should be stored.
**
**  Arguments   :   dynSt       dynamic structure pointer
**                  dynStTp     dynamic structure definition
**		            ptfPtr      parameter dynamic structure pointer
**
**  Return      :   TRUE or FALSE
**
**  Creation	:   PCC-17390 - LJE - 131001
**
*************************************************************************/
STATIC int DBA_FilterSynthPSP(DBA_DYNFLD_STP  dynSt,
			                  DBA_DYNST_ENUM  ,
                              DBA_DYNFLD_STP  pspPtr)
{

    if (GET_ID(dynSt, A_PtfSynth_PSPId) == GET_ID(pspPtr, A_PerfStorageParam_Id) &&
        (RETURN_GRID_LNK_NAT_ENUM)GET_ENUM(dynSt, A_PtfSynth_GridLinkNatEn) != ReturnGridLnk_ParStorPtfSynth) /* no ParStorPtfSynth */
        return(TRUE);
    else
        return(FALSE);
}

/************************************************************************
**
**  Function    :   DBA_FilterAllGlobalPtfSynth()
**
**  Description :   Extract global Ptf synthetic records.
**                  In addition NO synthetics with return grid link of
**                  nature parallel storage ptf synth should be stored.
**
**  Arguments   :   dynSt       dynamic structure pointer
**                  dynStTp     dynamic structure definition
**		            ptfPtr      parameter dynamic structure pointer
**
**  Return      :   TRUE or FALSE
**
**  Creation	:   PMSTA-55377 - Deepthi - 240117
**
*************************************************************************/
STATIC int DBA_FilterAllGlobalPtfSynth(DBA_DYNFLD_STP dynSt,
    DBA_DYNST_ENUM dynStTp,
    DBA_DYNFLD_STP paramSt)

{
    if (dynStTp != A_PtfSynth)
    {
        return(FALSE);
    }

    /* REF7634 - LJE - 021014 : Dont get the no-primary ptf synth */

    if (IS_NULLFLD(dynSt, A_PtfSynth_Level) == FALSE &&
        GET_TINYINT(dynSt, A_PtfSynth_Level) != 0 &&
        GET_BIT((MASK_T)GET_TINYINT(dynSt, A_PtfSynth_Level), SynthLevel_Primary) == FALSE)
    {
        return(FALSE);
    }

    /* REF9264 - LJE - 031021 : Test perf_storage_param_id too */
    if (CMP_DYNFLD(dynSt, paramSt, A_PtfSynth_PSPId, A_PerfStorageParam_Id, IdType) != 0)
    {
        return (FALSE);
    }

    if (GET_ID(dynSt, A_PtfSynth_PSPId) == GET_ID(paramSt, A_PerfStorageParam_Id) &&
        (RETURN_GRID_LNK_NAT_ENUM)GET_ENUM(dynSt, A_PtfSynth_GridLinkNatEn) != ReturnGridLnk_ParStorPtfSynth &&
        (GET_ID(paramSt, A_PerfStorageParam_EntityDictId) != PtfCst ||
         (GET_ID(paramSt, A_PerfStorageParam_EntityDictId) == PtfCst &&
          GET_ID(dynSt, A_PtfSynth_PtfId) == GET_ID(paramSt, A_PerfStorageParam_ObjId)
         )
        ) &&
        (IS_NULLFLD(dynSt, A_PtfSynth_GridId) == TRUE ||
            GET_ID(dynSt, A_PtfSynth_GridId) == GET_ID(paramSt, A_PerfStorageParam_GridId)) &&
        IS_NULLFLD(dynSt, A_PtfSynth_MktSegtId) == TRUE &&
        IS_NULLFLD(dynSt, A_PtfSynth_InstrId) == TRUE)
    {
        return(TRUE);
    }
    else
    {
        return(FALSE);
    }
}


/************************************************************************
**
**  Function    :   DBA_FilterInstrFreqPsp()
**
**  Description :   Extract instrument frequency for given Psp.
**
**  Arguments   :   dynSt       dynamic structure pointer
**                  dynStTp     dynamic structure definition
**		            instrPtr    parameter dynamic structure pointer
**
**  Return      :   TRUE or FALSE
**
**  Creation	:   REF7421 - YST - 020806
**
*************************************************************************/
STATIC int DBA_FilterInstrFreqPsp(DBA_DYNFLD_STP  dynSt,
								  DBA_DYNST_ENUM  ,
								  DBA_DYNFLD_STP  pspPtr)
{
    if (GET_ID(dynSt, A_InstrFreq_PSPId) == GET_ID(pspPtr, A_PerfStorageParam_Id)
		&&
		GET_ID(dynSt, A_InstrFreq_InstrId) == GET_ID(pspPtr, A_PerfStorageParam_ObjId))

        return(TRUE);
    else
        return(FALSE);
}


/************************************************************************
**
**  Function    :   DBA_FilterExtRaNotOk()
**
**  Description :   Delete ExtRetAnalysis with initial date equal initial date
**                  of StandardPerf.
**
**  Arguments   :   dynSt           dynamic structure pointer
**                  dynStTp         dynamic structure definition
**		            stdPerfPtr      parameter dynamic structure pointer
**
**  Return      :   TRUE or FALSE
**
**  Creation	:   REF7421 - YST - 020906
**
*************************************************************************/
STATIC int DBA_FilterExtRaNotOk(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM , DBA_DYNFLD_STP stdPerfPtr)
{
	if (DATETIME_CMP(GET_DATETIME(dynSt, A_ExtRetAnalysis_InitialDate),
                   GET_DATETIME(stdPerfPtr, A_StandardPerf_InitialDate)) == 0
		/* REF9738 - RAK - 040115 - Don't delete ExtRetAnalysis of the precedent PSP */
		/* elsewhere we will use freed memory in insert struct and crash server !    */
		&& GET_ID(dynSt, A_ExtRetAnalysis_PerfStorParamId) == GET_ID(stdPerfPtr, A_StandardPerf_PerfStorParamId))
    {
		return(TRUE);
    }
    return(FALSE);
}

/************************************************************************
**
**  Function    :   DBA_FilterStdPerfPtfFreq()
**
**  Description :   Extract (in our case Delete) StandardPerf of entity portfolio.
**
**  Arguments   :   dynSt       dynamic structure pointer
**                  dynStTp     dynamic structure definition
**		            unusedPtr    parameter dynamic structure pointer
**
**  Return      :   TRUE or FALSE
**
**  Creation	:   REF7423 - YST - 021104
**
*************************************************************************/
STATIC int DBA_FilterStdPerfPtfFreq(DBA_DYNFLD_STP  dynSt,
                                    DBA_DYNST_ENUM,
                                    DBA_DYNFLD_STP)
{
    DICT_T      entDictId;

    DBA_GetDictId(Ptf, &entDictId);

    if (GET_DICT(dynSt, A_StandardPerf_EntDictId) == entDictId)
        return(TRUE);
    else
        return(FALSE);
}

/************************************************************************
**
**  Function    :   DBA_CmpPtfSynthDate()
**
**  Description :   Synthetics sorted by grid id and date.
**
**  Arguments   :   ptr1   pointer on dynamic structure type A_PtfSynth
**                  ptr2   pointer on dynamic structure type A_PtfSynth
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation  	:   PCC-17390 - LJE - 131001
**
*************************************************************************/
STATIC int DBA_CmpPtfSynthDate(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    int ret;

		/* PMSTA06591 - LJE - 080522 : sort with more criteria... */
	if ((ret = CMP_DYNFLD((*ptr1), (*ptr2), A_PtfSynth_InitialDate, A_PtfSynth_InitialDate, DatetimeType)) != 0)
        return ret;

    if ((ret = CMP_DYNFLD((*ptr1), (*ptr2), A_PtfSynth_FinalDate, A_PtfSynth_FinalDate, DatetimeType)) != 0)
        return ret;

		/* InstrId is sorted for have NULL in last */
	if ((ret = CMP_DYNFLD((*ptr1), (*ptr2), A_PtfSynth_InstrId, A_PtfSynth_InstrId, IdType)) != 0)
        return ret;

		/* MktSegtId is sorted for have NULL in last */
	if ((ret = CMP_DYNFLD((*ptr1), (*ptr2), A_PtfSynth_MktSegtId, A_PtfSynth_MktSegtId, IdType)) != 0)
		return ret;

	return CMP_DYNFLD((*ptr1), (*ptr2), A_PtfSynth_Id, A_PtfSynth_Id, IdType);
}

/************************************************************************
**
**  Function    :   DBA_CmpPtfFreqInitialDate()
**
**  Description :   Portfolio frequency sorted by initial date and id.
**
**  Arguments   :   ptr1   pointer on dynamic structure type A_PtfFreq
**                  ptr2   pointer on dynamic structure type A_PtfFreq
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation  	:   REF7423 - YST - 021017
**
*************************************************************************/
STATIC int DBA_CmpPtfFreqInitialDate(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    /* Date */
	if (DATETIME_CMP(GET_DATETIME((*ptr1), A_PtfFreq_InitialDate),
                     GET_DATETIME((*ptr2), A_PtfFreq_InitialDate)) == 0)
	{
	    /* Id */
	    return(CMP_ID(GET_ID((*ptr2), A_PtfFreq_Id) , GET_ID((*ptr1), A_PtfFreq_Id))); /* DLA - REF9089 - 030508 */
	}
    else
    {
        return(DATETIME_CMP(GET_DATETIME((*ptr1), A_PtfFreq_InitialDate),
                            GET_DATETIME((*ptr2), A_PtfFreq_InitialDate)));
    }
}

/************************************************************************
**
**  Function    :   DBA_CmpStratSynthInitialDate()
**
**  Description :   Strategy synthetics sorted by initial date.
**
**  Arguments   :   ptr1   pointer on dynamic structure type StratSynth
**                  ptr2   pointer on dynamic structure type StratSynth
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation  	:   PMSTA08736 - LJE - 100125
**  Modification:
**
*************************************************************************/
STATIC int DBA_CmpStratSynthInitialDate(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{

	return(DATETIME_CMP(GET_DATETIME((*ptr1), A_StratSynth_BeginDate),
		                GET_DATETIME((*ptr2), A_StratSynth_BeginDate)));
}

/************************************************************************
**
**  Function    :   DBA_CmpInstrFreqInitialDate()
**
**  Description :   Instrument frequency sorted by freq date.
**
**  Arguments   :   ptr1   pointer on dynamic structure type A_InstrFreq
**                  ptr2   pointer on dynamic structure type A_InstrFreq
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation  	:   REF7421 - YST - 020731
**  Modification:   REF8749 - YST - 030128
**
*************************************************************************/
STATIC int DBA_CmpInstrFreqInitialDate(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
	return(DATETIME_CMP(GET_DATETIME((*ptr1), A_InstrFreq_InitialDate /*A_InstrFreq_FreqDate*/),
		                    GET_DATETIME((*ptr2), A_InstrFreq_InitialDate /*A_InstrFreq_FreqDate*/)));
}

/************************************************************************
**  Function    :   DBA_CmpInsPtfBenchStorage()
**
**  Description :   Comparison function used to sort insertion
**                  with multiaccess:
**                  1.  delete PerfAttrib records
**                  2.  delete ExtRetAnalysis records
**                  3.  delete StandardPerf records
**                  3.  delete event scheduler and  update portfolio (only if ptf),
**                  last update PSP
**                  !!!! update PSP must always be last
**
**  Arguments   :   aPtr 	pointer to first access structure
** 			        bPtr    pointer to second access structure
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation    :   REF7421 - YST - 020808
**
*************************************************************************/
STATIC int DBA_CmpInsPtfBenchStorage(DBA_ACCESS_STP aPtr, DBA_ACCESS_STP bPtr)
{
    /* Delete PerfAttrib records */
    if (aPtr->action == Delete && aPtr->object == PerfAttrib)
    {
        if (bPtr->action == Delete && bPtr->object == PerfAttrib)
        {
            return (CMP_ID(GET_ID((aPtr->data), Get_Arg_ObjId) ,
                    GET_ID((bPtr->data), Get_Arg_ObjId))); /* DLA - REF9089 - 030508 */
        }
        else
        {
            return(-1);
        }
    }
    else if (bPtr->action == Delete && bPtr->object == PerfAttrib)
    {
        return(1);
    }
    /* Delete ExtRetAnalysis records */
    else if (aPtr->action == Delete && aPtr->object == ExtRetAnalysis)
    {
        if (bPtr->action == Delete && bPtr->object == ExtRetAnalysis)
        {
            return (CMP_ID(GET_ID((aPtr->data), Get_Arg_ObjId),
                    GET_ID((bPtr->data), Get_Arg_ObjId))); /* DLA - REF9089 - 030508 */
        }
        else
        {
            return(-1);
        }
    }
    else if (bPtr->action == Delete && bPtr->object == ExtRetAnalysis)
    {
        return(1);
    }
    /* Delete StandardPerf records */
    else if (aPtr->action == Delete && aPtr->object == StandardPerf)
    {
        if (bPtr->action == Delete && bPtr->object == StandardPerf)
        {
            return (CMP_ID(GET_ID((aPtr->data), Get_Arg_ObjId) ,
                    GET_ID((bPtr->data), Get_Arg_ObjId))); /* DLA - REF9089 - 030508 */
        }
        else
        {
            return(-1);
        }
    }
    else if (bPtr->action == Delete && bPtr->object == StandardPerf)
    {
        return(1);
    }
    /* Update StandardPerf */ /* REF7422 - LJE - 020911 */
    else if (aPtr->action == Update && aPtr->object == PerfStorageParam)
    {
        if (bPtr->action == Update && bPtr->object == PerfStorageParam)
        {
            return (CMP_ID(GET_ID((aPtr->data), Get_Arg_ObjId) ,
                    GET_ID((bPtr->data), Get_Arg_ObjId))); /* DLA - REF9089 - 030508 */
        }
        else
        {
            return(-1);
        }
    }
    else if (bPtr->action == Update && bPtr->object == PerfStorageParam)
    {
        return(1);
    }
    /* Delete PSP must be the last one */
    else if (aPtr->action == Delete && aPtr->object == PerfStorageParam)
    {
        if (bPtr->action == Delete && bPtr->object == PerfStorageParam)
        {
            return (CMP_ID(GET_ID((aPtr->data), Get_Arg_ObjId) ,
                    GET_ID((bPtr->data), Get_Arg_ObjId))); /* DLA - REF9089 - 030508 */
        }
        else
        {
            return(-1);
        }
    }
    else if (bPtr->action == Delete && bPtr->object == PerfStorageParam)
    {
        return(1);
    }
    else
    {
        return (1);
    }
}


STATIC int DBA_CmpObjPtfId(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    return(CMP_ID(GET_ID((*ptr1), A_Ptf_Id) , GET_ID((*ptr2), A_Ptf_Id)));
}

STATIC int DBA_CmpPSPObjId(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    return(CMP_ID(GET_ID((*ptr1), A_PerfStorageParam_ObjId) , GET_ID((*ptr2), A_PerfStorageParam_ObjId)));
}


/************************************************************************
**
**  Function    :   FIN_CreateESEFromStrategySynth()
**
**  Description :
**
**  Arguments   :   domainPtr     domain structure pointer0
**                  hierHeadPtr   position hierarchy header pointer
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation 	:   PMSTA08737 - LJE - 091112
**  Modification:
**
*************************************************************************/
STATIC DBA_DYNFLD_STP FIN_CreateESEFromStrategySynth(DBA_HIER_HEAD_STP   hierHead,
													 DBA_DYNFLD_STP      stratSynthStp,
													 DBA_DYNFLD_STP      pspPtr)
{
	RET_CODE           ret=RET_SUCCEED;
	DBA_DYNFLD_STP     eseStp=NULL;
	MASK_T             subPeriodMask;

	if ((eseStp = ALLOC_DYNST(ExtStratElt)) == NULL)
	{
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtStratElt");
		return(NULL);
	}

    COPY_DYNFLD(eseStp, ExtStratElt, ExtStratElt_PSPId,
				pspPtr, A_PerfStorageParam, A_PerfStorageParam_Id);

    COPY_DYNFLD(eseStp, ExtStratElt, ExtStratElt_StratId,
				stratSynthStp, A_StratSynth, A_StratSynth_StratId);
    COPY_DYNFLD(eseStp, ExtStratElt, ExtStratElt_GridId,
				stratSynthStp, A_StratSynth, A_StratSynth_GridId);

    COPY_DYNFLD(eseStp, ExtStratElt, ExtStratElt_StratHistId,
				stratSynthStp, A_StratSynth, A_StratSynth_StratHistId);

    COPY_DYNFLD(eseStp, ExtStratElt, ExtStratElt_InitialDate,
				stratSynthStp, A_StratSynth, A_StratSynth_BeginDate);
    COPY_DYNFLD(eseStp, ExtStratElt, ExtStratElt_FinalDate,
				stratSynthStp, A_StratSynth, A_StratSynth_EndDate);
    COPY_DYNFLD(eseStp, ExtStratElt, ExtStratElt_MktSegtId,
				stratSynthStp, A_StratSynth, A_StratSynth_MktSegtId);
    COPY_DYNFLD(eseStp, ExtStratElt, ExtStratElt_InstrId,
				stratSynthStp, A_StratSynth, A_StratSynth_InstrId);

    subPeriodMask = (MASK_T)0;
	if (GET_MASKBIT(stratSynthStp, A_StratSynth_SubPeriodMask, RecInfoBench_PortBenchStorage) == TRUE)
	{
    	SET_BIT(subPeriodMask, SynthLevel_PortBenchStorage, TRUE);
	}
	if (GET_MASKBIT(stratSynthStp, A_StratSynth_SubPeriodMask, RecInfoBench_BenchRebal) == TRUE)
	{
		SET_BIT(subPeriodMask, SynthLevel_BenchRebal, TRUE);
	}
	SET_MASK(eseStp, ExtStratElt_SubPeriodNatMask, subPeriodMask);

	SET_TINYINT(eseStp, ExtStratElt_Level, 1);

    COPY_DYNFLD(eseStp, ExtStratElt, ExtStratElt_ObjWeightContrib,
				stratSynthStp, A_StratSynth, A_StratSynth_Weight);
    COPY_DYNFLD(eseStp, ExtStratElt, ExtStratElt_BenchRtn,
				stratSynthStp, A_StratSynth, A_StratSynth_Return);
    COPY_DYNFLD(eseStp, ExtStratElt, ExtStratElt_BenchRtnCurr,
				stratSynthStp, A_StratSynth, A_StratSynth_ReturnCurr);

	COPY_DYNFLD(eseStp, ExtStratElt, ExtStratElt_BenchEntDictId,
				stratSynthStp, A_StratSynth, A_StratSynth_BenchEntDictId);
	COPY_DYNFLD(eseStp, ExtStratElt, ExtStratElt_BenchObjId,
				stratSynthStp, A_StratSynth, A_StratSynth_BenchObjId);

	if ((ret = DBA_AddHierRecord(hierHead,
								 eseStp,
								 ExtStratElt,
								 FALSE,
								 HierAddRec_NoLnk)) != RET_SUCCEED)
	{
		FREE_DYNST(eseStp, ExtStratElt);
		return(NULL);
	}

	return eseStp;
}

/************************************************************************
**
**  Function    : FIN_FilterValidStratSynth()
**
**  Description : Filter untreated (strat bench object) strategy synthetics
**                return TRUE  -> record must be extract
**                       FALSE -> record musn't be extract
**
**  Arguments   : dynSt         element pointer
**                dynStTp       element description enum
**                searchLnkStp
**
**  Return      : TRUE or FALSE
**
**  Creation    : PMSTA08737 - LJE - 091112
**
*************************************************************************/
STATIC int FIN_FilterValidStratSynth(DBA_DYNFLD_STP dynStp,
					  		         DBA_DYNST_ENUM ,
									 DBA_DYNFLD_STP )
{

	if (IS_NULLFLD(dynStp, A_StratSynth_StratId) == FALSE)
        return(TRUE);
    else
		return(FALSE);
}

/************************************************************************
**
**  Function    :   DBA_CmpPerfAttribInitial()
**
**  Description :   PerfAttrib sorted by initial date.
**
**  Arguments   :   ptr1   pointer on dynamic structure type S_PerfAttrib
**                  ptr2   pointer on dynamic structure type S_PerfAttrib
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation  	:   REF8874 - YST - 030527
**
*************************************************************************/
STATIC int DBA_CmpPerfAttribInitial(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    return(DATETIME_CMP(GET_DATETIME((*ptr1), S_PerfAttrib_InitialDate),
        GET_DATETIME((*ptr2), S_PerfAttrib_InitialDate)));

}

/************************************************************************
**
**  Function    :   DBA_CmpStdPerfInitial()
**
**  Description :   StandardPerf sorted by initial date.
**
**  Arguments   :   ptr1   pointer on dynamic structure type S_StandardPerf
**                  ptr2   pointer on dynamic structure type S_StandardPerf
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation  	:   REF8874 - YST - 030527
**
*************************************************************************/
STATIC int DBA_CmpStdPerfInitial(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    return(DATETIME_CMP(GET_DATETIME((*ptr1), S_StandardPerf_InitialDate),
        GET_DATETIME((*ptr2), S_StandardPerf_InitialDate)));

}

/************************************************************************
**
**  Function    :   DBA_CmpExtRetAnalysisInitial()
**
**  Description :   S_ExtRetAnalysis sorted by initial date.
**
**  Arguments   :   ptr1   pointer on dynamic structure type S_ExtRetAnalysis
**                  ptr2   pointer on dynamic structure type S_ExtRetAnalysis
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation  	:   REF8874 - YST - 030527
**
*************************************************************************/
STATIC int DBA_CmpExtRetAnalysisInitial(DBA_DYNFLD_STP *ptr1,
                                         DBA_DYNFLD_STP *ptr2)
{
    return(DATETIME_CMP(GET_DATETIME((*ptr1), S_ExtRetAnalysis_InitialDate),
        GET_DATETIME((*ptr2), S_ExtRetAnalysis_InitialDate)));

}

/************************************************************************
**
**  Function    :   DBA_CmpPCRByPCDInitial()
**
**  Description :   S_PerfCalcResult sorted by PerfCalcDef and initial date.
**
**  Arguments   :   ptr1   pointer on dynamic structure type S_PerfCalcResult
**                  ptr2   pointer on dynamic structure type S_PerfCalcResult
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation  	:   WEALTH-7170 - DDV - 240430
**
*************************************************************************/
STATIC int DBA_CmpPCRByPCDInitial(DBA_DYNFLD_STP* ptr1,
                                  DBA_DYNFLD_STP* ptr2)
{
    int cmp = 0;
    if ((cmp = CMP_DYNFLD(*ptr1, *ptr2, S_PerfCalcResult_PerfCalcDefId, S_PerfCalcResult_PerfCalcDefId, IdType)) != 0)
    {
        return(cmp);
    }

    return(DATETIME_CMP(GET_DATETIME((*ptr1), S_PerfCalcResult_InitialDate),
                        GET_DATETIME((*ptr2), S_PerfCalcResult_InitialDate)));

}

/************************************************************************
*   Function            : DBA_ValidatePerfData()
*
*   Description         : This functions checks and validates Perf Data
*                         (PerfAttrib, StandardPerf, ExtRetAnalysis) for one PSP.
*
*                         Perf Data out of range (<= PSP.firstStoredDate or
*                         >= PSP.lastStoredDate) are selected from database.
*
*                         For the global lines a check is done on discontinuities.
*                         If there are discontinuities then some data is deleted.
*                         Additional tests on licensee and system parameter
*                         PerfDataContent are done for PerfAttrib and ExtRetAnalysis:
*                         If storage is not allowed then data is deleted.
*
*                         Currently the function is called after import of
*                         Perf Data or if for Ptf Storage or Benchmark Storage
*                         the field PSP.checkedDataEn is 0.
*
*   Arguments           : pspPtr    pointer on PerfStorageParam (PSP)
*
*   Return              : RET_SUCCEED or error code
*
*   Creation date       : REF8874 - YST - 030527
*   Modification        : REF9832 - YST/MCA - 040312 : suppress test on perfDataContent
*
*************************************************************************/
RET_CODE DBA_ValidatePerfData(DBA_DYNFLD_STP pspPtr)
{
    RET_CODE                retCd = RET_SUCCEED, retMsg = RET_SUCCEED;
    DBA_DYNFLD_STP          *outputData[] = { NULL, NULL, NULL, NULL };
    const DBA_DYNST_ENUM    *outputStLst[] = { &S_PerfAttrib, &S_StandardPerf, &S_ExtRetAnalysis, &S_PerfCalcResult };
    int                     dataRows[] = { 0, 0, 0, 0};
    DBA_DYNFLD_STP          delDataArg = NULL;
    DATETIME_T              tmpPerfFirstDate, tmpPerfLastDate, tmpStdPerfFirstDate, tmpStdPerfLastDate,
                            tmpRetFirstDate, tmpRetLastDate, tmpLastFinalDate, tmpPCRFirstDate, tmpPCRLastDate;
    PA_LICENSEE_ENUM        paLicenseEn = PALicensee_No;
    DICT_T                  ptfEntDictId;
    FLAG_T                  stop = FALSE;
    int                     j = 0, connectNo = -1;

    /* get licensee keys PA */
    GEN_GetApplInfo(ApplPALicense, &paLicenseEn);

    DBA_GetDictId(Ptf, &ptfEntDictId);

    /*----------------------------------------------------------------------------------*/
    /*          Get imported PerfData (PerfAttrib, StandardPerf, ExtRetAnalysis)        */
    /*----------------------------------------------------------------------------------*/
    if ((retCd = DBA_MultiSelect2(PerfStorageParam, UNUSED, A_PerfStorageParam, pspPtr,
        outputStLst, outputData, UNUSED, UNUSED, dataRows, UNUSED, UNUSED)) != RET_SUCCEED)
    {
        return(retCd);
    }

    /* allocate memory and initialization */
    memset(&tmpPerfFirstDate, 0, sizeof(DATETIME_T));
    memset(&tmpPerfLastDate, 0, sizeof(DATETIME_T));
    memset(&tmpStdPerfFirstDate, 0, sizeof(DATETIME_T));
    memset(&tmpStdPerfLastDate, 0, sizeof(DATETIME_T));
    memset(&tmpRetFirstDate, 0, sizeof(DATETIME_T));
    memset(&tmpRetLastDate, 0, sizeof(DATETIME_T));
    memset(&tmpLastFinalDate, 0, sizeof(DATETIME_T));
    memset(&tmpPCRFirstDate, 0, sizeof(DATETIME_T));
    memset(&tmpPCRLastDate, 0, sizeof(DATETIME_T));
    tmpPCRFirstDate.date = MAGIC_END_DATE;

    if ((delDataArg = ALLOC_DYNST(Get_Arg)) == NULL)
    {
        for (j = 0; j<3; j++)
            DBA_FreeDynStTab(outputData[j], dataRows[j], (DBA_DYNST_ENUM)(*outputStLst[j])); /* REF8874 - LJE - 031107 */

        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }
    SET_ID(delDataArg, Get_Arg_ObjId, GET_ID(pspPtr, A_PerfStorageParam_Id));

    /* get connection */
    if ((connectNo = DBA_GetConnection(SqlServer)) == DBA_CONN_NOT_FOUND)
    {
        MSG_SendMesg(RET_DBA_ERR_CONNOTFOUND, 0, FILEINFO);
        retCd = RET_DBA_ERR_CONNOTFOUND;
    }
    else
    {
        /* be in a transaction */
        if (DBA_BeginTransaction(connectNo) != RET_SUCCEED)
        {
            if (DBA_EndConnection(connectNo) != RET_SUCCEED)
            {
                MSG_SendMesg(RET_DBA_ERR_DISCONNECTED, 0, FILEINFO);
            }
            retCd = RET_DBA_ERR_CONNOTFOUND;
        }
        else
        {
            /*----------------------------------------------*/
            /*              test PerfAttrib                 */
            /*----------------------------------------------*/
            /* test if data was imported when PALicensee_No */
            if (paLicenseEn == PALicensee_No && (dataRows[0] > 0))
            {
                SET_DATETIME(delDataArg, Get_Arg_DateTime, GET_DATETIME(outputData[0][0], S_PerfAttrib_InitialDate));
                SET_DATETIME(delDataArg, Get_Arg_DateTime2, GET_DATETIME(outputData[0][dataRows[0] - 1], S_PerfAttrib_FinalDate));

                if ((retCd = DBA_Delete2(PerfAttrib, UNUSED, Get_Arg, delDataArg,
                    DBA_SET_CONN | DBA_IN_TRAN | DBA_NO_CLOSE, &connectNo, UNUSED)) == RET_SUCCEED)
                {
                    MSG_SendMesg(RET_GEN_ERR_PERSONAL, 4, FILEINFO,
                                 "All imported perf_attrib data deleted for perf_storage_param_id=",
                                 GET_ID(pspPtr, A_PerfStorageParam_Id));
                    retMsg = RET_GEN_ERR_PERSONAL;
                }
            }
            else
            {
                /* imported data exists, so test if there is a discontinuity */
                if (dataRows[0] > 0)
                {
                    if (dataRows[0] > 1)
                    {
                        TLS_Sort((char*)outputData[0], dataRows[0], sizeof(DBA_DYNFLD_STP),
                                 (TLS_CMPFCT *)DBA_CmpPerfAttribInitial, NULL, SortRtnTp_None);
                    }

                    tmpPerfFirstDate = GET_DATETIME(outputData[0][0], S_PerfAttrib_InitialDate);
                    tmpPerfLastDate = GET_DATETIME(outputData[0][dataRows[0] - 1], S_PerfAttrib_FinalDate);

                    /* if there is a discontinuity, delete some data */
                    for (j = 0, stop = FALSE; j<dataRows[0] - 1 && stop == FALSE; j++)
                    {
                        if (DATETIME_CMP(GET_DATETIME(outputData[0][j], S_PerfAttrib_FinalDate),
                            GET_DATETIME(outputData[0][j + 1], S_PerfAttrib_InitialDate)) != 0)
                        {
                            tmpPerfLastDate = GET_DATETIME(outputData[0][j], S_PerfAttrib_FinalDate); /* PMSTA16197 - DDV - 130415 - Wrong index used to access outputData */

                            SET_DATETIME(delDataArg, Get_Arg_DateTime,
                                            GET_DATETIME(outputData[0][j + 1], S_PerfAttrib_InitialDate));
                            SET_DATETIME(delDataArg, Get_Arg_DateTime2,
                                            GET_DATETIME(outputData[0][dataRows[0] - 1], S_PerfAttrib_FinalDate));

                            if ((retCd = DBA_Delete2(PerfAttrib, UNUSED, Get_Arg, delDataArg,
                                DBA_SET_CONN | DBA_IN_TRAN | DBA_NO_CLOSE, &connectNo, UNUSED)) == RET_SUCCEED)
                            {
                                MSG_SendMesg(RET_GEN_ERR_PERSONAL, 4, FILEINFO,
                                                "Discontinuity in data, imported perf_attrib data deleted for perf_storage_param_id=",
                                                GET_ID(pspPtr, A_PerfStorageParam_Id));
                                retMsg = RET_GEN_ERR_PERSONAL;
                            }

                            stop = TRUE;
                        }
                    }
                }

                if (retCd == RET_SUCCEED && dataRows[0] > 0)
                {
                    tmpLastFinalDate = tmpPerfLastDate;
                }

            }/* end PerfAttrib */


            /*----------------------------------------------*/
            /*              test StandardPerf               */
            /*----------------------------------------------*/
            /* imported data exists, so test if there is a discontinuity */
            if (retCd == RET_SUCCEED && dataRows[1] > 0)
            {
                if (dataRows[1] > 1)
                {
                    TLS_Sort((char*)outputData[1], dataRows[1], sizeof(DBA_DYNFLD_STP),
                             (TLS_CMPFCT *)DBA_CmpStdPerfInitial, NULL, SortRtnTp_None);
                }

                tmpStdPerfFirstDate = GET_DATETIME(outputData[1][0], S_StandardPerf_InitialDate);
                tmpStdPerfLastDate = GET_DATETIME(outputData[1][dataRows[1] - 1], S_StandardPerf_FinalDate);

                /* if there is a discontinuity, delete some data */
                for (j = 0, stop = FALSE; j<dataRows[1] - 1 && stop == FALSE; j++)
                {
                    if (DATETIME_CMP(GET_DATETIME(outputData[1][j], S_StandardPerf_FinalDate),
                        GET_DATETIME(outputData[1][j + 1], S_StandardPerf_InitialDate)) != 0)
                    {
                        tmpStdPerfLastDate = GET_DATETIME(outputData[1][j], S_StandardPerf_FinalDate);

                        SET_DATETIME(delDataArg, Get_Arg_DateTime,
                                        GET_DATETIME(outputData[1][j + 1], S_StandardPerf_InitialDate));
                        SET_DATETIME(delDataArg, Get_Arg_DateTime2,
                                        GET_DATETIME(outputData[1][dataRows[1] - 1], S_StandardPerf_FinalDate));

                        if ((retCd = DBA_Delete2(StandardPerf, UNUSED, Get_Arg, delDataArg,
                            DBA_SET_CONN | DBA_IN_TRAN | DBA_NO_CLOSE, &connectNo, UNUSED)) == RET_SUCCEED)
                        {
                            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 4, FILEINFO,
                                            "Discontinuity in data, imported standard_perf data deleted for perf_storage_param_id=",
                                            GET_ID(pspPtr, A_PerfStorageParam_Id));
                            retMsg = RET_GEN_ERR_PERSONAL;
                        }
                        stop = TRUE;
                    }
                }
            }

            /* check lastStoredDates and update tmpLastFinalDate */
            if (retCd == RET_SUCCEED && dataRows[1] > 0)
            {
                if (dataRows[0] > 0)
                {
                    /* if lastStoredDates are not the same then delete some data */
                    if (DATETIME_CMP(tmpLastFinalDate, tmpStdPerfLastDate) < 0)
                    {
                        SET_DATETIME(delDataArg, Get_Arg_DateTime, tmpLastFinalDate);
                        SET_DATETIME(delDataArg, Get_Arg_DateTime2, tmpStdPerfLastDate);

                        if ((retCd = DBA_Delete2(StandardPerf, UNUSED, Get_Arg, delDataArg,
                            DBA_SET_CONN | DBA_IN_TRAN | DBA_NO_CLOSE, &connectNo, UNUSED)) == RET_SUCCEED)
                        {
                            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 4, FILEINFO,
                                         "Different last stored dates, imported standard_perf data deleted for perf_storage_param_id=",
                                         GET_ID(pspPtr, A_PerfStorageParam_Id));
                            retMsg = RET_GEN_ERR_PERSONAL;
                        }
                        tmpStdPerfLastDate = tmpLastFinalDate;
                    }
                    else if (DATETIME_CMP(tmpLastFinalDate, tmpStdPerfLastDate) > 0)
                    {
                        SET_DATETIME(delDataArg, Get_Arg_DateTime, tmpStdPerfLastDate);
                        SET_DATETIME(delDataArg, Get_Arg_DateTime2, tmpLastFinalDate);

                        if ((retCd = DBA_Delete2(PerfAttrib, UNUSED, Get_Arg, delDataArg,
                            DBA_SET_CONN | DBA_IN_TRAN | DBA_NO_CLOSE, &connectNo, UNUSED)) == RET_SUCCEED)
                        {
                            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 4, FILEINFO,
                                         "Different last stored dates, imported perf_attrib data deleted for perf_storage_param_id=",
                                         GET_ID(pspPtr, A_PerfStorageParam_Id));
                            retMsg = RET_GEN_ERR_PERSONAL;
                        }
                        tmpLastFinalDate = tmpStdPerfLastDate;
                    }
                }
                else
                {
                    tmpLastFinalDate = tmpStdPerfLastDate;
                }
            }/* end StandardPerf */


            /*----------------------------------------------*/
            /*              test ExtRetAnalysis             */
            /*----------------------------------------------*/
            if (retCd == RET_SUCCEED)
            {
                /* imported data exists, so test if there is a discontinuity */
                if (retCd == RET_SUCCEED && dataRows[2] > 0)
                {
                    if (dataRows[2] > 1)
                    {
                        TLS_Sort((char*)outputData[2], dataRows[2], sizeof(DBA_DYNFLD_STP),
                                 (TLS_CMPFCT *)DBA_CmpExtRetAnalysisInitial, NULL, SortRtnTp_None);
                    }

                    tmpRetFirstDate = GET_DATETIME(outputData[2][0], S_ExtRetAnalysis_InitialDate);
                    tmpRetLastDate = GET_DATETIME(outputData[2][dataRows[2] - 1], S_ExtRetAnalysis_FinalDate);

                    /* if there is a discontinuity, delete some data */
                    for (j = 0, stop = FALSE; j<dataRows[2] - 1 && stop == FALSE; j++)
                    {
                        if (DATETIME_CMP(GET_DATETIME(outputData[2][j], S_ExtRetAnalysis_FinalDate),
                            GET_DATETIME(outputData[2][j + 1], S_ExtRetAnalysis_InitialDate)) != 0)
                        {
                            tmpRetLastDate = GET_DATETIME(outputData[2][j], S_ExtRetAnalysis_FinalDate);

                            SET_DATETIME(delDataArg, Get_Arg_DateTime,
                                            GET_DATETIME(outputData[2][j + 1], S_ExtRetAnalysis_InitialDate));
                            SET_DATETIME(delDataArg, Get_Arg_DateTime2,
                                            GET_DATETIME(outputData[2][dataRows[2] - 1], S_ExtRetAnalysis_FinalDate));

                            if ((retCd = DBA_Delete2(ExtRetAnalysis, UNUSED, Get_Arg, delDataArg,
                                DBA_SET_CONN | DBA_IN_TRAN | DBA_NO_CLOSE, &connectNo, UNUSED)) == RET_SUCCEED)
                            {
                                MSG_SendMesg(RET_GEN_ERR_PERSONAL, 4, FILEINFO,
                                                "Discontinuity in data, imported ext_ret_analysis data deleted for perf_storage_param_id=",
                                                GET_ID(pspPtr, A_PerfStorageParam_Id));
                                retMsg = RET_GEN_ERR_PERSONAL;
                            }
                            stop = TRUE;
                        }
                    }
                }

                /* check lastStoredDates and update tmpLastFinalDate */
                if (retCd == RET_SUCCEED && dataRows[2] > 0)
                {
                    if (dataRows[0] > 0 || dataRows[1] > 0)
                    {
                        /* if lastStoredDates are not the same then delete data after min(LastStoredDate) */
                        if (DATETIME_CMP(tmpLastFinalDate, tmpRetLastDate) < 0)
                        {
                            SET_DATETIME(delDataArg, Get_Arg_DateTime, tmpLastFinalDate);
                            SET_DATETIME(delDataArg, Get_Arg_DateTime2, tmpRetLastDate);

                            if ((retCd = DBA_Delete2(ExtRetAnalysis, UNUSED, Get_Arg, delDataArg,
                                DBA_SET_CONN | DBA_IN_TRAN | DBA_NO_CLOSE, &connectNo, UNUSED)) == RET_SUCCEED)
                            {
                                MSG_SendMesg(RET_GEN_ERR_PERSONAL, 4, FILEINFO,
                                             "Different last stored dates, imported ext_ret_analysis data deleted for perf_storage_param_id=",
                                             GET_ID(pspPtr, A_PerfStorageParam_Id));
                                retMsg = RET_GEN_ERR_PERSONAL;
                            }
                            tmpRetLastDate = tmpLastFinalDate;
                        }
                        else if (DATETIME_CMP(tmpLastFinalDate, tmpRetLastDate) > 0)
                        {
                            SET_DATETIME(delDataArg, Get_Arg_DateTime, tmpRetLastDate);
                            SET_DATETIME(delDataArg, Get_Arg_DateTime2, tmpLastFinalDate);

                            if (dataRows[0] > 0)
                            {
                                if ((retCd = DBA_Delete2(PerfAttrib, UNUSED, Get_Arg, delDataArg,
                                    UNUSED, UNUSED, UNUSED)) == RET_SUCCEED)
                                {
                                    MSG_SendMesg(RET_GEN_ERR_PERSONAL, 4, FILEINFO,
                                                 "Different last stored dates, imported perf_attrib data deleted for perf_storage_param_id=",
                                                 GET_ID(pspPtr, A_PerfStorageParam_Id));
                                    retMsg = RET_GEN_ERR_PERSONAL;
                                }
                                tmpPerfLastDate = tmpRetLastDate;
                            }
                            if (dataRows[1] > 0)
                            {
                                if ((retCd = DBA_Delete2(StandardPerf, UNUSED, Get_Arg, delDataArg,
                                    DBA_SET_CONN | DBA_IN_TRAN | DBA_NO_CLOSE, &connectNo, UNUSED)) == RET_SUCCEED)
                                {
                                    MSG_SendMesg(RET_GEN_ERR_PERSONAL, 4, FILEINFO,
                                                 "Different last stored dates, imported standard_perf data deleted for perf_storage_param_id=",
                                                 GET_ID(pspPtr, A_PerfStorageParam_Id));
                                    retMsg = RET_GEN_ERR_PERSONAL;
                                }
                                tmpStdPerfLastDate = tmpRetLastDate;
                            }
                            tmpLastFinalDate = tmpRetLastDate;
                        }
                    }
                    else
                    {
                        tmpLastFinalDate = tmpRetLastDate;
                    }
                }
            }/* end ExtRetAnalysis */

            /*--------------------------------------------------------*/
            /*     test PerfCalcResult     WEALTH-7170 - DDV - 240502 */
            /*--------------------------------------------------------*/
            /* imported data exists, so test if there is a discontinuity */
            if (retCd == RET_SUCCEED && dataRows[3] > 0)
            {
                DBA_DYNFLD_STP* perfCalcResultTab = outputData[3];
                int             perfCalcResultNbr = dataRows[3];
                DATETIME_T      firstDate, lastDate;

                memset(&firstDate, 0, sizeof(DATETIME_T));
                memset(&lastDate, 0, sizeof(DATETIME_T));

                if (perfCalcResultNbr > 1)
                {
                    TLS_Sort((char*)perfCalcResultTab, perfCalcResultNbr, sizeof(DBA_DYNFLD_STP),
                        (TLS_CMPFCT*)DBA_CmpPCRByPCDInitial, NULL, SortRtnTp_None);
                }

                j = 0;
                ID_T   currentPerfCalcDefId;
                int    firstRec = 0, lastRec=0;

                /* For each perf_calc_def keep only valid data that go till tmpLastFinalDate. Data after tmpLastFinalDate are deleted */
                /* discontinuity can exist but they must be correctly define to be keep */
                /* (start with EndOfInvested and end with BeginOfInvested). Incoherent data are deleted */
                while (j < perfCalcResultNbr)
                {
                    currentPerfCalcDefId = GET_ID(perfCalcResultTab[j], S_PerfCalcResult_PerfCalcDefId);
                    firstRec = j;

                    SET_ID(delDataArg, Get_Arg_Id, currentPerfCalcDefId);

                    while (j < perfCalcResultNbr &&
                        GET_ID(perfCalcResultTab[j], S_PerfCalcResult_PerfCalcDefId) == currentPerfCalcDefId)
                    {
                        j++;
                    }

                    lastRec = j-1;

                    firstDate = GET_DATETIME(perfCalcResultTab[firstRec], S_PerfCalcResult_InitialDate);
                    lastDate = GET_DATETIME(perfCalcResultTab[lastRec], S_PerfCalcResult_FinalDate);

                    /* If data don't go till the tmpLastFinalDate, delete them */
                    if (lastDate < tmpLastFinalDate &&
                        GET_S_PerfCalcResult_PeriodNatEn(perfCalcResultTab[lastRec]) != PerfCalcResultPeriodNatEn::EndOfInvestedPeriod &&
                        GET_S_PerfCalcResult_PeriodNatEn(perfCalcResultTab[lastRec]) != PerfCalcResultPeriodNatEn::IsOneInvestedPeriod)
                    {
                        SET_DATETIME(delDataArg, Get_Arg_DateTime, firstDate);
                        SET_DATETIME(delDataArg, Get_Arg_DateTime2, lastDate);
                        if ((retCd = DBA_Delete2(PerfCalcResult, UNUSED, Get_Arg, delDataArg,
                                                 DBA_SET_CONN | DBA_IN_TRAN | DBA_NO_CLOSE, &connectNo, UNUSED)) == RET_SUCCEED)
                        {
                            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 3, FILEINFO,
                                "Discontinuity in data, imported perf_calc_result deleted for perf_storage_param_id=",
                                GET_ID(pspPtr, A_PerfStorageParam_Id),
                                " and perf_calc_def_id=",
                                currentPerfCalcDefId);
                            retMsg = RET_GEN_ERR_PERSONAL;
                        }
                        continue;
                    }

                    /* Delete data after tmpLastFinalDate */
                    if (lastDate > tmpLastFinalDate)
                    {
                        SET_DATETIME(delDataArg, Get_Arg_DateTime, tmpLastFinalDate);
                        SET_DATETIME(delDataArg, Get_Arg_DateTime2, lastDate);
                        if ((retCd = DBA_Delete2(PerfCalcResult, UNUSED, Get_Arg, delDataArg,
                            DBA_SET_CONN | DBA_IN_TRAN | DBA_NO_CLOSE, &connectNo, UNUSED)) == RET_SUCCEED)
                        {
                            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 3, FILEINFO,
                                "perf_calc_result out of range regarding performance data deleted for perf_storage_param_id=",
                                GET_ID(pspPtr, A_PerfStorageParam_Id),
                                " and perf_calc_def_id=",
                                currentPerfCalcDefId);
                            retMsg = RET_GEN_ERR_PERSONAL;
                        }

                        while (lastRec > firstRec && 
                               GET_DATETIME(perfCalcResultTab[lastRec], S_PerfCalcResult_FinalDate) > tmpLastFinalDate)
                        {
                            lastRec--;
                        }
                        lastDate = tmpLastFinalDate;
                    }

                    /* check data discontinuity */
                    for (int k = lastRec; k > firstRec + 1; k--)
                    {
                        if (DATETIME_CMP(GET_DATETIME(perfCalcResultTab[k], S_PerfCalcResult_InitialDate),
                                         GET_DATETIME(perfCalcResultTab[k - 1], S_PerfCalcResult_FinalDate)) != 0 &&
                            ((GET_S_PerfCalcResult_PeriodNatEn(perfCalcResultTab[k]) != PerfCalcResultPeriodNatEn::BeginOfInvestedPeriod &&
                              GET_S_PerfCalcResult_PeriodNatEn(perfCalcResultTab[k]) != PerfCalcResultPeriodNatEn::IsOneInvestedPeriod) ||
                             (GET_S_PerfCalcResult_PeriodNatEn(perfCalcResultTab[k-1]) != PerfCalcResultPeriodNatEn::EndOfInvestedPeriod &&
                              GET_S_PerfCalcResult_PeriodNatEn(perfCalcResultTab[k-1]) != PerfCalcResultPeriodNatEn::IsOneInvestedPeriod)))
                        {
                            SET_DATETIME(delDataArg, Get_Arg_DateTime, firstDate);
                            SET_DATETIME(delDataArg, Get_Arg_DateTime2, GET_DATETIME(perfCalcResultTab[k - 1], S_PerfCalcResult_FinalDate));
                            if ((retCd = DBA_Delete2(PerfCalcResult, UNUSED, Get_Arg, delDataArg,
                                DBA_SET_CONN | DBA_IN_TRAN | DBA_NO_CLOSE, &connectNo, UNUSED)) == RET_SUCCEED)
                            {
                                MSG_SendMesg(RET_GEN_ERR_PERSONAL, 3, FILEINFO,
                                    "Discontinuity in data, imported perf_calc_result deleted for perf_storage_param_id=",
                                    GET_ID(pspPtr, A_PerfStorageParam_Id),
                                    " and perf_calc_def_id=",
                                    currentPerfCalcDefId);
                                retMsg = RET_GEN_ERR_PERSONAL;
                            }
                            firstDate = GET_DATETIME(perfCalcResultTab[k], S_PerfCalcResult_InitialDate);
                        }
                    }

                    if (firstDate < tmpPCRFirstDate)
                    {
                        tmpPCRFirstDate = firstDate;
                    }

                    if (lastDate > tmpPCRLastDate)
                    {
                        tmpPCRLastDate = lastDate;
                    }
                }
                SET_NULL_ID(delDataArg, Get_Arg_Id);
            }

            /*----------------------------------------------*/
            /*          update and validate PSP             */
            /*----------------------------------------------*/

            /* if data was imported set new PSP.firstStoredDates and PSP.lastStoredDates */
            if (retCd == RET_SUCCEED)
            {
                if (dataRows[0] > 0)
                {
                    SET_DATETIME(pspPtr, A_PerfStorageParam_PerfFirstStoredDate, tmpPerfFirstDate);
                    SET_DATETIME(pspPtr, A_PerfStorageParam_PerfLastStoredDate, tmpPerfLastDate);
                }
                else /* PMSTA-11083 - LJE - 110114 */
                {
                    SET_NULL_DATETIME(pspPtr, A_PerfStorageParam_PerfFirstStoredDate);
                    SET_NULL_DATETIME(pspPtr, A_PerfStorageParam_PerfLastStoredDate);
                }

                if (dataRows[1] > 0)
                {
                    SET_DATETIME(pspPtr, A_PerfStorageParam_StdPerfFirstStoredDate, tmpStdPerfFirstDate);
                    SET_DATETIME(pspPtr, A_PerfStorageParam_StdPerfLastStoredDate, tmpStdPerfLastDate);
                }
                else /* PMSTA-11083 - LJE - 110114 */
                {
                    SET_NULL_DATETIME(pspPtr, A_PerfStorageParam_StdPerfFirstStoredDate);
                    SET_NULL_DATETIME(pspPtr, A_PerfStorageParam_StdPerfLastStoredDate);
                }

                if (dataRows[2] > 0)
                {
                    SET_DATETIME(pspPtr, A_PerfStorageParam_RetFirstStoredDate, tmpRetFirstDate);
                    SET_DATETIME(pspPtr, A_PerfStorageParam_RetLastStoredDate, tmpRetLastDate);
                }
                else /* PMSTA-11083 - LJE - 110114 */
                {
                    SET_NULL_DATETIME(pspPtr, A_PerfStorageParam_RetFirstStoredDate);
                    SET_NULL_DATETIME(pspPtr, A_PerfStorageParam_RetLastStoredDate);
                }

                /* WEALTH-7170 - DDV - 240502 */
                if (dataRows[3] > 0 && tmpPCRFirstDate.date < MAGIC_END_DATE  && tmpPCRLastDate.date > 0)
                {
                    SET_DATETIME(pspPtr, A_PerfStorageParam_PerfCalcFirstStoredDate, tmpPCRFirstDate);
                    SET_DATETIME(pspPtr, A_PerfStorageParam_PerfCalcLastStoredDate, tmpPCRLastDate);
                }
                else 
                {
                    SET_NULL_DATETIME(pspPtr, A_PerfStorageParam_PerfCalcFirstStoredDate);
                    SET_NULL_DATETIME(pspPtr, A_PerfStorageParam_PerfCalcLastStoredDate);
                }

                /* validation of PSP, set checkedDataEn = 1 */
                SET_ENUM(pspPtr, A_PerfStorageParam_CheckedDataEn, 1);

                retCd = DBA_Update2(PerfStorageParam, DBA_ROLE_PERF_ATTRIB_RA, A_PerfStorageParam, pspPtr,
                                    DBA_SET_CONN | DBA_IN_TRAN | DBA_NO_CLOSE, &connectNo, UNUSED);

                /*if PSP is for entity portfolio then update A_Ptf_PerfLastFinalDate */
                if (retCd == RET_SUCCEED &&
                    GET_DICT(pspPtr, A_PerfStorageParam_EntityDictId) == ptfEntDictId)
                {
                    DBA_DYNFLD_STP  ptfPtr = NULL;

                    if ((ptfPtr = ALLOC_DYNST(A_Ptf)) == NULL)
                    {
                        retCd = RET_MEM_ERR_ALLOC;
                    }
                    else
                    {
                        SET_ID(ptfPtr, A_Ptf_Id, GET_ID(pspPtr, A_PerfStorageParam_ObjId));
                        SET_NULL_DATETIME(ptfPtr, A_Ptf_PerfLastFinalDate); /* REF10640 - LJE - 041209 */

                        retCd = DBA_Update2(Ptf, DBA_ROLE_PERF_ATTRIB_RA, A_Ptf, ptfPtr,
                                            DBA_SET_CONN | DBA_IN_TRAN | DBA_NO_CLOSE, &connectNo, UNUSED);

                        FREE_DYNST(ptfPtr, A_Ptf);
                    }
                }
            }

            if (retCd == RET_SUCCEED)
                retCd = DBA_EndTransaction(connectNo, TRUE);    /* commit transaction */
            else
                DBA_EndTransaction(connectNo, FALSE);   /* rollback transaction */

            if (DBA_EndConnection(connectNo) != RET_SUCCEED)
            {
                MSG_SendMesg(RET_DBA_ERR_DISCONNECTED, 0, FILEINFO);
            }
        }
    }

    FREE_DYNST(delDataArg, Get_Arg);
    for (j = 0; j<3; j++)
        DBA_FreeDynStTab(outputData[j], dataRows[j], (DBA_DYNST_ENUM)(*outputStLst[j])); /* REF8874 - LJE - 031107 */

    if (retCd == RET_SUCCEED)
        retCd = retMsg;

    return(retCd);
}

/************************************************************************
**      END  dbaperf.c
*************************************************************************/

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define FINLIB07_C

#define STDIO_H
#define STRING_H
#define STDLIB_H

/************************************************************************
**      Includes
*************************************************************************/
#include "unidef.h"        /* Mandatory */
#include "fin.h"
#include "scptyl.h"

/************************************************************************
**
**		FIN_StratCreateESEModel			Create extended strategy elements for model portfolio.
**		FIN_StratCreateESEModelDet		Create model and recommendation list elements.
**      FIN_StratCreateESEModelTot      Create model total (because of no one element for model ...).
**		FIN_StratInsStratElt			Create model and recommendation list element.
**      FIN_StratInsDbStratElt          Insert A_StratElt in database.
*************************************************************************/

/************************************************************************
**      Constants
*************************************************************************/

/************************************************************************
**      Macro Definitions
*************************************************************************/

/************************************************************************
**      Type  Definitions
*************************************************************************/

/************************************************************************
**      Global Functions
**
*************************************************************************/

/************************************************************************
**      Static Functions
**
*************************************************************************/




EXTERN RET_CODE FIN_GetExcludedMarketSegments(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, std::vector<ID_T> &);  /* PMSTA - 39969 - sanand - 05052020 */

/*************************************************************************************
*   Function             : FIN_StratCreateESEModel()
*
*   Description          : Create extended strategy elements for model portfolio.
*
*   Arguments            : stratHierPtr   : strategy hierarchy header
*                          ESLPtr         : extended strategy link pointer
*
*   Return               : RET_SUCCEED or error code
*
*   Creation Date        : 23.06.99 - REF3729
*
**************************************************************************************/
RET_CODE FIN_StratCreateESEModel(DBA_HIER_HEAD_STP       stratHierPtr,
                                int                     ESEFldNbr,
                                DBA_DYNFLD_STP          ESLPtr,
                                int                     selOptions,
                                int                    *connectNo,
                                FLAG_T editAllocConstrFlg)  /*PMSTA -40823*/
{
    RET_CODE	    ret             = RET_SUCCEED;
    DBA_DYNFLD_STP  stratHistPtr    = NULLDYNST;
    DBA_DYNFLD_STP *stratEltTab     = NULLDYNSTPTR;
    DBA_DYNFLD_STP *ESETab          = NULLDYNSTPTR;
    DBA_DYNFLD_STP *ESEExtension    = NULLDYNSTPTR;
    FLAG_T          foundFlg        = FALSE;
    int				stratEltNbr     = 0;
    int             ESENbr          = 0;
    int				i;
    int				j;

    /* Read strategy element */
    if (GET_EXTENSION_PTR(ESLPtr, ExtStratLnk_A_StratHist_Ext) != NULL &&
	   (stratHistPtr = *(GET_EXTENSION_PTR(ESLPtr, ExtStratLnk_A_StratHist_Ext))) != NULLDYNST)
    {
		stratEltTab = GET_EXTENSION_PTR(stratHistPtr, A_StratHist_A_StratElt_Ext);
		stratEltNbr = GET_EXTENSION_NBR(stratHistPtr, A_StratHist_A_StratElt_Ext);
    }

    /*PMSTA -40823 - lalby- ignore excluded for Constraints allocation */
    std::vector<ID_T> excludedMarketSegments;
    if (editAllocConstrFlg == TRUE)
    {
        if (GET_EXTENSION_PTR(ESLPtr, ExtStratLnk_A_StratHist_Ext) != NULL)
        {
            stratHistPtr = *(GET_EXTENSION_PTR(ESLPtr, ExtStratLnk_A_StratHist_Ext));
            if (stratHistPtr)
            {
                ret = FIN_GetExcludedMarketSegments(stratHierPtr, stratHistPtr, excludedMarketSegments);
                if (ret != RET_SUCCEED)
                {
                    MSG_SendMesg(ret, 2, FILEINFO, "Not able to extract the excluded market segments");
                }
            }
        }
    }
    
    if (IS_NULLFLD(ESLPtr, ExtStratLnk_GridId) == FALSE)
    {
        if (stratEltNbr > 0)
	    {
		    ESEExtension = GET_EXTENSION_PTR(ESLPtr, ExtStratLnk_ExtStratElt_Ext);
		    ESENbr = GET_EXTENSION_NBR(ESLPtr, ExtStratLnk_ExtStratElt_Ext);

            if (ESENbr > 0)
            {
                /* Creation of a full copy of extension */
	            if ((ESETab = (DBA_DYNFLD_STP *)CALLOC(ESENbr, sizeof(DBA_DYNFLD_STP))) == NULLDYNSTPTR) /* REF7264 - LJE - 020130 */
	            {
	                MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, ESENbr);
	                return(RET_MEM_ERR_ALLOC);
	            }
                for (i=0 ; i < ESENbr ; i++)
                {
                   ESETab[i] = ESEExtension[i];
                }

			    for (i=0; i<stratEltNbr; i++)
			    {
                    if (IS_NULLFLD(stratEltTab[i], A_StratElt_InstrId) == TRUE)
                    {
                        continue;
                    }

					/* REF11559 - CHU - 051124 : check validity of Strategy element */
					if (GET_ID(stratEltTab[i], A_StratElt_Id) < (ID_T)0 &&
						IS_NULLFLD(stratEltTab[i], A_StratElt_PtfIdForMissingPM) == FALSE &&
						CMP_ID(GET_ID(ESLPtr, ExtStratLnk_PtfId), GET_ID(stratEltTab[i], A_StratElt_PtfIdForMissingPM))!=0)
					{
						continue;
					}

                    /*PMSTA -40823  - lalby - excludemarketsegments for constraints allocation*/
                    if (editAllocConstrFlg == TRUE)
                    {
                        auto it = std::find(excludedMarketSegments.begin(), excludedMarketSegments.end(), GET_ID(stratEltTab[i], A_StratElt_MktSegtId));
                        if (it != excludedMarketSegments.end())
                        {
                            continue;
                        }
                    }

                    for (j=0, foundFlg = FALSE ; j < ESENbr && foundFlg == FALSE ; j++)
                    {
		                if (GET_ID(ESETab[j], ExtStratElt_StratHistId) ==
                            GET_ID(stratHistPtr, A_StratHist_Id) &&
		                    GET_ID(ESETab[j], ExtStratElt_MktSegtId) ==
                            GET_ID(stratEltTab[i], A_StratElt_MktSegtId))
                        {
                            foundFlg = TRUE;
			                if ((ret = FIN_StratCreateESEModelDet(stratHierPtr,
                                                                  ESEFldNbr,
                                                                  ESLPtr,
                                                                  stratEltTab[i],
                                                                  NULLDYNST,
                                                                  ExtStratEltNat_ModelDetail)) != RET_SUCCEED)
			                {
                                FREE(ESETab);
				                return(ret);
			                }
                        }
                    }
                }
                FREE(ESETab);
            }
        }
    }
    else
    {
        if (stratEltNbr > 0)
	    {
		    /* Set total line at the begin ... */
		    TLS_Sort((char*) stratEltTab,
                     stratEltNbr,
                     sizeof(DBA_DYNFLD_STP),
				     (TLS_CMPFCT *)FIN_StratCmpEltNat, /* REF7264 - LJE - 020130 */
                     (PTR**)NULL,
                     SortRtnTp_None);

		    for (i=0; i<stratEltNbr; i++)
		    {
				/* REF11559 - CHU - 051124 : check validity of Strategy element */
				if (GET_ID(stratEltTab[i], A_StratElt_Id) < (ID_T)0 &&
					IS_NULLFLD(stratEltTab[i], A_StratElt_PtfIdForMissingPM) == FALSE &&
					CMP_ID(GET_ID(ESLPtr, ExtStratLnk_PtfId), GET_ID(stratEltTab[i], A_StratElt_PtfIdForMissingPM))!=0)
				{
					continue;
				}
                /*PMSTA -40823  - lalby - excludemarketsegments for constraints allocation*/
                if (editAllocConstrFlg == TRUE)
                {
                    auto it = std::find(excludedMarketSegments.begin(), excludedMarketSegments.end(), GET_ID(stratEltTab[i], A_StratElt_MktSegtId));
                    if (it != excludedMarketSegments.end())
                    {
                        continue;
                    }
                }

			    if ((ret = FIN_StratCreateESEModelDet(stratHierPtr,
                                                      ESEFldNbr,
                                                      ESLPtr,
                                                      stratEltTab[i],
                                                      NULLDYNST,
                                                      ExtStratEltNat_ModelDetail)) != RET_SUCCEED)
			    {
				    return(ret);
			    }
		    }
        }
        else
        {
		    ret = FIN_StratCreateESEModelTot(stratHierPtr, ESEFldNbr, ESLPtr, selOptions, connectNo);
        }
    }

    return(ret);
}




/*************************************************************************************
*   Function             : FIN_StratCreateESEModelDet()
*
*   Description          : Create model and recommendation list elements.
*
*   Arguments            :
*                           eseNatEn        : element nature
*
*   Return               : RET_SUCCEED or error code
*
*   Creation Date        : 15.07.99 - REF3729
*   Modifs               : REF9594 - CHU - 031203 : Do not use logical margins anymore in Edit Strategy Objectives
*                        : PMSTA07121-CHU-081009 - CMC - repercute criticalness from Strat/StratElt
*
**************************************************************************************/
RET_CODE FIN_StratCreateESEModelDet(DBA_HIER_HEAD_STP    stratHierPtr,
                                   int                  ESEFldNbr,
                                   DBA_DYNFLD_STP       ESLPtr,
                                   DBA_DYNFLD_STP       stratEltPtr,
                                   DBA_DYNFLD_STP       ESEArgPtr,
                                   EXTSTRATELTNAT_ENUM  eseNatEn)
{
    RET_CODE            ret         = RET_SUCCEED;
    DBA_DYNFLD_STP      ESEPtr      = NULLDYNST;
    DBA_DYNFLD_STP      parESEPtr   = NULLDYNST;
    DBA_DYNFLD_STP      sMktSgtPtr  = NULLDYNST;
    NUMBER_T	        contrib     = 0.0;
    NUMBER_T	        weight      = 0.0;
    StratSubNatEn       subNatEn    = StratSubNatEn::None; /* REF7264 - LJE - 020130 */


    if (ESEArgPtr == NULLDYNST)
    {
        if (ESEFldNbr > 0)
        {
    	    ESEPtr = ALLOC_DYNST_SUPPLFLD(ExtStratElt, ESEFldNbr);
	        if (ESEPtr == NULLDYNST)
	        {
	            MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtStratElt suppl. fld");
	            return(RET_MEM_ERR_ALLOC);
	        }
        }
        else
        {
	        ESEPtr = ALLOC_DYNST(ExtStratElt);
	        if (ESEPtr == NULLDYNST)
	        {
	            MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtStratElt");
	            return(RET_MEM_ERR_ALLOC);
	        }
        }
    }
    else
    {
        ESEPtr = ESEArgPtr;
    }

    /* REF4047 - 000203 - SKE : Sub Nature management */
    subNatEn = static_cast<StratSubNatEn>(GET_ENUM(ESLPtr, ExtStratLnk_SubNatEn)); /* REF7264 - LJE - 020130 */ /* PMSTA-51103-Deepthi-20221202 */

    SET_ID(ESEPtr, ExtStratElt_InstrId,        GET_ID(stratEltPtr, A_StratElt_InstrId));
    SET_ID(ESEPtr, ExtStratElt_BenchEntDictId, GET_ID(stratEltPtr, A_StratElt_BenchEntDictId));
    SET_ID(ESEPtr, ExtStratElt_BenchObjId,     GET_ID(stratEltPtr, A_StratElt_BenchObjId));
	/* Ana Bench Obj Id */
	COPY_DYNFLD(ESEPtr, ExtStratElt, ExtStratElt_AnaBenchObjId,stratEltPtr, A_StratElt, A_StratElt_AnaBenchObjId);
    /* Ana Bench Ent Dict Id */
	COPY_DYNFLD(ESEPtr, ExtStratElt, ExtStratElt_AnaBenchEntDictId, stratEltPtr, A_StratElt, A_StratElt_AnaBenchEntDictId);

	COPY_DYNFLD(ESEPtr, ExtStratElt, ExtStratElt_BenchRtn,
			    stratEltPtr, A_StratElt,  A_StratElt_AbsoluteReturn); /*REF9075  030520 MCA*/
    SET_NUMBER(ESEPtr, ExtStratElt_BenchRtn, (GET_NUMBER(ESEPtr, ExtStratElt_BenchRtn)* 100.0)); /*REF9431  030827 MCA*/

    /* REF9227 - LJE - 030919 */
    SET_NUMBER(ESEPtr, ExtStratElt_BenchRtnCurr, (GET_NUMBER(stratEltPtr, A_StratElt_AbsoluteReturnCurr)* 100.0));

    SET_SMALLINT(ESEPtr, ExtStratElt_ModelReading, 0);

	/* FIH-REF6989-010911 */
	COPY_DYNFLD(ESEPtr, ExtStratElt, ExtStratElt_Priority, stratEltPtr, A_StratElt, A_StratElt_Priority);

	/* PMSTA07121-RAK-090424 */
	COPY_DYNFLD(ESEPtr, ExtStratElt, ExtStratElt_CriticalnessEn, stratEltPtr, A_StratElt, A_StratElt_CriticalnessEn);

    /* PMSTA14459-JPP-120614 */
    COPY_DYNFLD(ESEPtr, ExtStratElt, ExtStratElt_StratEltId, stratEltPtr, A_StratElt, A_StratElt_Id);

    /*PMSTA-42402 Autocash Vishnu 09122020*/
    if (static_cast<STRATNAT_ENUM>(GET_ENUM(ESLPtr, ExtStratLnk_StratNatEn)) == STRATNAT_ENUM::StratNat_CashMgtStrat)
    {
        COPY_DYNFLD(ESEPtr, ExtStratElt, ExtStratElt_MinThreshold, stratEltPtr, A_StratElt, A_StratElt_MinThreshold);
        COPY_DYNFLD(ESEPtr, ExtStratElt, ExtStratElt_MaxThreshold, stratEltPtr, A_StratElt, A_StratElt_MaxThreshold);
        COPY_DYNFLD(ESEPtr, ExtStratElt, ExtStratElt_MinForecast, stratEltPtr, A_StratElt, A_StratElt_MinCashForecastM);
        COPY_DYNFLD(ESEPtr, ExtStratElt, ExtStratElt_MaxForecast, stratEltPtr, A_StratElt, A_StratElt_MaxCashForecastM);
        COPY_DYNFLD(ESEPtr, ExtStratElt, ExtStratElt_CashForecastM, stratEltPtr, A_StratElt, A_StratElt_CashForecastM);
        COPY_DYNFLD(ESEPtr, ExtStratElt, ExtStratElt_Min, stratEltPtr, A_StratElt, A_StratElt_Min);
        COPY_DYNFLD(ESEPtr, ExtStratElt, ExtStratElt_Max, stratEltPtr, A_StratElt, A_StratElt_Max);
        if(static_cast<STRATELTNAT_ENUM>( GET_ENUM(stratEltPtr, A_StratElt_NatEn)) == STRATELTNAT_ENUM::StratEltNat_Amount)
        {
            if(IS_NULLFLD(stratEltPtr, A_StratElt_MinAmount) == FALSE)
                COPY_DYNFLD(ESEPtr, ExtStratElt, ExtStratElt_Min, stratEltPtr, A_StratElt, A_StratElt_MinAmount);
            
            if(IS_NULLFLD(stratEltPtr, A_StratElt_MaxAmount) == FALSE)
                COPY_DYNFLD(ESEPtr, ExtStratElt, ExtStratElt_Max, stratEltPtr, A_StratElt, A_StratElt_MaxAmount);
            
            if(IS_NULLFLD(stratEltPtr, A_StratElt_MinThresAmount) == FALSE)
                COPY_DYNFLD(ESEPtr, ExtStratElt, ExtStratElt_MinThreshold, stratEltPtr, A_StratElt, A_StratElt_MinThresAmount);
            
            if(IS_NULLFLD(stratEltPtr, A_StratElt_MaxThresAmount) == FALSE)
                COPY_DYNFLD(ESEPtr, ExtStratElt, ExtStratElt_MaxThreshold, stratEltPtr, A_StratElt, A_StratElt_MaxThresAmount);

        }
    }

    /* MARKET SEGMENT */
    if (IS_NULLFLD(stratEltPtr, A_StratElt_MktSegtId) == FALSE)
    {
	    SET_ID(ESEPtr, ExtStratElt_MktSegtId, GET_ID(stratEltPtr, A_StratElt_MktSegtId));

        /* REF4047 - 991207 - SKE : let's find in hierarchy rather
           than in database.
        */
        sMktSgtPtr = DBA_SearchHierRecById(stratHierPtr,
                                           S_MktSegt,
                                           S_MktSegt_Id,
                                           GET_ID(stratEltPtr, A_StratElt_MktSegtId));

        if (sMktSgtPtr == NULLDYNST)
        {
            MSG_SendMesg(RET_DBA_ERR_NODATA, 6, FILEINFO, GET_ID(stratEltPtr, A_StratElt_MktSegtId));
            return(RET_DBA_ERR_NODATA);
        }

	    SET_ID(ESEPtr, ExtStratElt_AbsClassifId, GET_ID(sMktSgtPtr, S_MktSegt_AbcissaClassifId));
	    SET_ID(ESEPtr, ExtStratElt_OrdClassifId, GET_ID(sMktSgtPtr, S_MktSegt_OrdinateClassifId));
	    SET_ID(ESEPtr, ExtStratElt_AbsListId,    GET_ID(sMktSgtPtr, S_MktSegt_AbcissaListId));
	    SET_ID(ESEPtr, ExtStratElt_OrdListId,    GET_ID(sMktSgtPtr, S_MktSegt_OrdinateListId));
    }
    /* LEVEL */
	SET_TINYINT(ESEPtr, ExtStratElt_Level, 2);


    /* TOTAL LINE */
    if (GET_ENUM(stratEltPtr, A_StratElt_NatEn) == (ENUM_T) StratEltNat_Model       ||
        GET_ENUM(stratEltPtr, A_StratElt_NatEn) == (ENUM_T) StratEltNat_ModelConstWeight)
    {
	    SET_TINYINT(ESEPtr, ExtStratElt_Level, 1);
    }

    /* INIT COMMON FIELDS AND ADD EXTENDED STRATEGY ELEMENT IN HIERARCHY */
    if ((ret = FIN_StratAddESEInHier(stratHierPtr,
                                     ESEPtr,
                                     ESEFldNbr,
                                     ESLPtr,
			                         eseNatEn)) != RET_SUCCEED)
    {
	    return(ret);
    }

    /* REF4047 - 000120 - SKE */
    SET_ID(stratEltPtr, A_StratElt_ExtStratElt_Id, GET_ID(ESEPtr, ExtStratElt_Id));

    /* prepare link ExtStratElt_DispPar_ExtStratElt_Ext */
    SET_ID(ESEPtr, ExtStratElt_DispParExtStratEltId, GET_ID(ESEPtr, ExtStratElt_ParExtStratEltId));

    if (GET_ENUM(ESEPtr, ExtStratElt_StratNatEn) == StratNat_RecomList)
    {
    	SET_ENUM(ESEPtr, ExtStratElt_RecomNatEn, GET_ENUM(stratEltPtr, A_StratElt_RecomNatEn));
	    SET_NULL_NUMBER(ESEPtr, ExtStratElt_ObjWeight);
	    SET_NULL_NUMBER(ESEPtr, ExtStratElt_ObjWeightMarg);
	    SET_NULL_NUMBER(ESEPtr, ExtStratElt_ObjWeightContrib);
		SET_NULL_NUMBER(ESEPtr, ExtStratElt_OrigObjWeightContrib); /* PMSTA15213-CHU-121107  */
	    SET_NULL_NUMBER(ESEPtr, ExtStratElt_ObjWeightContribMarg);
    }
    if (GET_ENUM(ESEPtr, ExtStratElt_StratNatEn) == StratNat_SSL)
    {
    	SET_ENUM(ESEPtr, ExtStratElt_RecomNatEn, GET_ENUM(stratEltPtr, A_StratElt_RecomNatEn));
	    SET_NULL_NUMBER(ESEPtr, ExtStratElt_ObjWeight);
	    SET_NULL_NUMBER(ESEPtr, ExtStratElt_ObjWeightMarg);
	    SET_NULL_NUMBER(ESEPtr, ExtStratElt_ObjWeightContrib);
		SET_NULL_NUMBER(ESEPtr, ExtStratElt_OrigObjWeightContrib); /* PMSTA15213-CHU-121107  */
	    SET_NULL_NUMBER(ESEPtr, ExtStratElt_ObjWeightContribMarg);
    }


	/* MARKET SEGMENT PRIORITY */
	/* REF7022 - CHU - 010920 */
    if (IS_NULLFLD(stratEltPtr, A_StratElt_Priority) == TRUE)
	{
	    SET_NULL_SMALLINT(ESEPtr, ExtStratElt_Priority);
	}
	else
	{
	    SET_SMALLINT(ESEPtr, ExtStratElt_Priority, GET_SMALLINT(stratEltPtr, A_StratElt_Priority));
	}

    /* RANK */
    if (IS_NULLFLD(stratEltPtr, A_StratElt_Rank) == TRUE)
	{
	    SET_NULL_SMALLINT(ESEPtr, ExtStratElt_Rank);
	}
	else
	{
	    SET_SMALLINT(ESEPtr, ExtStratElt_Rank, GET_SMALLINT(stratEltPtr, A_StratElt_Rank));
	}

    /* VALUES */
    if (IS_NULLFLD(stratEltPtr, A_StratElt_Value) == FALSE)
    {
		if (GET_ENUM(ESEPtr, ExtStratElt_StratNatEn) == (ENUM_T) StratNat_SSL) /* REF7487 VST 020807 */
	    {
	        SET_NUMBER(ESEPtr, ExtStratElt_MaxWeightContrib, GET_NUMBER(stratEltPtr, A_StratElt_Value));
	    }
		else
		{
			if (GET_ENUM(ESEPtr, ExtStratElt_StratNatEn) == (ENUM_T) StratNat_RecomList)
			{
				SET_NUMBER(ESEPtr, ExtStratElt_MaxWeightContrib, GET_NUMBER(stratEltPtr, A_StratElt_Value));
			}
			else
			{
	            /* REF4047 - 000203 - SKE : Sub Nature management */
                if (subNatEn == StratSubNatEn::ConstantWeight)
			    {
				    SET_NUMBER(ESEPtr, ExtStratElt_ObjWeightContrib, GET_NUMBER(stratEltPtr, A_StratElt_Value));
					SET_NUMBER(ESEPtr, ExtStratElt_OrigObjWeightContrib, GET_NUMBER(ESEPtr, ExtStratElt_ObjWeightContrib)); /* PMSTA15213-CHU-121107 */
				}
				else
				{
					SET_NUMBER(ESEPtr, ExtStratElt_ObjWeight, GET_NUMBER(stratEltPtr, A_StratElt_Value));

					/* REF11457 - RAK - 050928 - Get dynamic weight */
					COPY_DYNFLD(ESEPtr, ExtStratElt, ExtStratElt_DynObjWeight,
								stratEltPtr, A_StratElt, A_StratElt_DynValue);

					COPY_DYNFLD(ESEPtr, ExtStratElt, ExtStratElt_OldObjWeight,
								stratEltPtr, A_StratElt, A_StratElt_DBValue);
	            }
		    }
		}
    }

    if (IS_NULLFLD(stratEltPtr, A_StratElt_FluctMargin) == FALSE)
    {
        /* REF4047 - 000203 - SKE : Sub Nature management */
        if (subNatEn == StratSubNatEn::ConstantWeight)
        {
	        SET_NUMBER(ESEPtr, ExtStratElt_ObjWeightContribMarg, GET_NUMBER(stratEltPtr, A_StratElt_FluctMargin));
        }
        else
        {
            SET_NUMBER(ESEPtr, ExtStratElt_ObjWeightMarg, GET_NUMBER(stratEltPtr, A_StratElt_FluctMargin));
        }
    }

	/* PMSTA-40213-badhri-23072020 */
	if (IS_NULLFLD(stratEltPtr, A_StratElt_LowerMarg) == FALSE || IS_NULLFLD(stratEltPtr, A_StratElt_UpperMarg) == FALSE)
	{
		if (subNatEn == StratSubNatEn::ConstantWeight)
		{
			if (IS_NULLFLD(stratEltPtr, A_StratElt_LowerMarg) == FALSE)
				SET_NUMBER(ESEPtr, ExtStratElt_ObjLowerContribMarg, GET_NUMBER(stratEltPtr, A_StratElt_LowerMarg));
			if (IS_NULLFLD(stratEltPtr, A_StratElt_UpperMarg) == FALSE)
				SET_NUMBER(ESEPtr, ExtStratElt_ObjUpperContribMarg, GET_NUMBER(stratEltPtr, A_StratElt_UpperMarg));
		}
		else
		{
			if (IS_NULLFLD(stratEltPtr, A_StratElt_LowerMarg) == FALSE)
				SET_NUMBER(ESEPtr, ExtStratElt_ObjLowerMarg, GET_NUMBER(stratEltPtr, A_StratElt_LowerMarg));
			if (IS_NULLFLD(stratEltPtr, A_StratElt_UpperMarg) == FALSE)
				SET_NUMBER(ESEPtr, ExtStratElt_ObjUpperMarg, GET_NUMBER(stratEltPtr, A_StratElt_UpperMarg));
		}
	}

	/* REF9594 - CHU - 031203 : Do not use logical margins anymore in Edit Strategy Objectives */ /*
    else if (IS_NULLFLD(ESLPtr, ExtStratLnk_Marg) == FALSE &&
		     GET_TINYINT(ESEPtr, ExtStratElt_Level) != 1)
    {
        if (subNatEn != StratSubNat_ConstWeight) / * REF4047 - 000203 - SKE : Sub Nature management * /
        {
	        SET_NUMBER(ESEPtr, ExtStratElt_ObjWeightMarg, GET_NUMBER(ESLPtr, ExtStratLnk_Marg));
        }
    }
	*/
    /* REF4047 - 000203 - SKE : Sub Nature management */
    if (subNatEn == StratSubNatEn::ConstantWeight)
    {
        if (IS_NULLFLD(ESEPtr, ExtStratElt_ObjWeightContrib) == FALSE  &&
            IS_NULLFLD(ESLPtr, ExtStratLnk_ParStratMktSgtId) == TRUE)
        {
	        SET_NUMBER(ESEPtr, ExtStratElt_ObjWeight, GET_NUMBER(ESEPtr, ExtStratElt_ObjWeightContrib));
	        if (IS_NULLFLD(ESEPtr, ExtStratElt_ObjWeightContribMarg) == FALSE)
	        {
	            SET_NUMBER(ESEPtr, ExtStratElt_ObjWeightMarg, GET_NUMBER(ESEPtr, ExtStratElt_ObjWeightContribMarg));
	        }

			/* PMSTA-40213-badhri-23072020 */
			if (IS_NULLFLD(ESEPtr, ExtStratElt_ObjLowerContribMarg) == FALSE)
				SET_NUMBER(ESEPtr, ExtStratElt_ObjLowerMarg, GET_NUMBER(ESEPtr, ExtStratElt_ObjLowerContribMarg));
			if (IS_NULLFLD(ESEPtr, ExtStratElt_ObjUpperContribMarg) == FALSE)
				SET_NUMBER(ESEPtr, ExtStratElt_ObjUpperMarg, GET_NUMBER(ESEPtr, ExtStratElt_ObjUpperContribMarg));
        } 
        else
        {
	        if ((parESEPtr = FIN_StratGetParESEPtr(ESEPtr)) != NULLDYNST)
	        {
	            if (IS_NULLFLD(parESEPtr, ExtStratElt_ObjWeightContrib) == FALSE &&
                    GET_NUMBER(parESEPtr, ExtStratElt_ObjWeightContrib) != 0.0)
	            {
		            if (IS_NULLFLD(ESEPtr, ExtStratElt_ObjWeightContrib) == FALSE)
		            {
		                weight = GET_NUMBER(ESEPtr, ExtStratElt_ObjWeightContrib) * 100 /
                                 GET_NUMBER(parESEPtr, ExtStratElt_ObjWeightContrib);
		                SET_NUMBER(ESEPtr, ExtStratElt_ObjWeight, CAST_NUMBER(weight));
		            }
		            if (IS_NULLFLD(ESEPtr, ExtStratElt_ObjWeightContribMarg) == FALSE)
		            {

						/* <SKE - 010208 - REF5599 */
					switch(GET_ENUM(ESEPtr, ExtStratElt_ForecastFlg))
					{
						case ExtStratEltForecast_Absolute:
							 weight = GET_NUMBER(ESEPtr, ExtStratElt_ObjWeightContribMarg) * 100.0 /
                                      GET_NUMBER(parESEPtr, ExtStratElt_ObjWeightContrib);
		                     SET_NUMBER(ESEPtr, ExtStratElt_ObjWeightMarg, CAST_NUMBER(weight));
                        	 break;
						case ExtStratEltForecast_Relative:
				             SET_NUMBER(ESEPtr, ExtStratElt_ObjWeightMarg, GET_NUMBER(ESEPtr, ExtStratElt_ObjWeightContribMarg));
                                     				 break;
	 			        case ExtStratEltForecast_AbsoluteContrib: /* REF7319 - 020308 - MCA */
						     weight = GET_NUMBER(ESEPtr, ExtStratElt_ObjWeightContribMarg) * 100.0 /
                                      GET_NUMBER(parESEPtr, ExtStratElt_ObjWeightContrib);
		                     SET_NUMBER(ESEPtr, ExtStratElt_ObjWeightMarg, CAST_NUMBER(weight));
                             break;

                       }
		            }

					/* PMSTA-40213-badhri-23072020 */
					if (IS_NULLFLD(ESEPtr, ExtStratElt_ObjLowerContribMarg) == FALSE || IS_NULLFLD(ESEPtr, ExtStratElt_ObjUpperContribMarg) == FALSE)
					{
						NUMBER_T	        lowerWeight = 0.0;
						NUMBER_T	        upperWeight = 0.0;
						switch (GET_ENUM(ESEPtr, ExtStratElt_ForecastFlg))
						{
						case ExtStratEltForecast_Absolute:
							if (IS_NULLFLD(ESEPtr, ExtStratElt_ObjLowerContribMarg) == FALSE)
							{
								lowerWeight = GET_NUMBER(ESEPtr, ExtStratElt_ObjLowerContribMarg) * 100.0 /
									GET_NUMBER(parESEPtr, ExtStratElt_ObjWeightContrib);
								SET_NUMBER(ESEPtr, ExtStratElt_ObjLowerMarg, CAST_NUMBER(lowerWeight));
							}

							if (IS_NULLFLD(ESEPtr, ExtStratElt_ObjUpperContribMarg) == FALSE)
							{
								upperWeight = GET_NUMBER(ESEPtr, ExtStratElt_ObjUpperContribMarg) * 100.0 /
									GET_NUMBER(parESEPtr, ExtStratElt_ObjWeightContrib);
								SET_NUMBER(ESEPtr, ExtStratElt_ObjUpperMarg, CAST_NUMBER(upperWeight));
							}
							break;
						case ExtStratEltForecast_Relative:
							if (IS_NULLFLD(ESEPtr, ExtStratElt_ObjLowerContribMarg) == FALSE)
								SET_NUMBER(ESEPtr, ExtStratElt_ObjLowerMarg, GET_NUMBER(ESEPtr, ExtStratElt_ObjLowerContribMarg));
							if (IS_NULLFLD(ESEPtr, ExtStratElt_ObjUpperContribMarg) == FALSE)
								SET_NUMBER(ESEPtr, ExtStratElt_ObjUpperMarg, GET_NUMBER(ESEPtr, ExtStratElt_ObjUpperContribMarg));
							break;
						case ExtStratEltForecast_AbsoluteContrib:
							if (IS_NULLFLD(ESEPtr, ExtStratElt_ObjLowerContribMarg) == FALSE)
							{
								lowerWeight = GET_NUMBER(ESEPtr, ExtStratElt_ObjLowerContribMarg) * 100.0 /
									GET_NUMBER(parESEPtr, ExtStratElt_ObjWeightContrib);
								SET_NUMBER(ESEPtr, ExtStratElt_ObjLowerMarg, CAST_NUMBER(lowerWeight));
							}

							if (IS_NULLFLD(ESEPtr, ExtStratElt_ObjUpperContribMarg) == FALSE)
							{
								upperWeight = GET_NUMBER(ESEPtr, ExtStratElt_ObjUpperContribMarg) * 100.0 /
									GET_NUMBER(parESEPtr, ExtStratElt_ObjWeightContrib);
								SET_NUMBER(ESEPtr, ExtStratElt_ObjUpperMarg, CAST_NUMBER(upperWeight));
							}
							break;
						}
					}
	            }
	        }
        }
    }
    else
    {
        if (IS_NULLFLD(ESEPtr, ExtStratElt_ObjWeight) == FALSE  &&
	        /* IS_NULLFLD(ESEPtr, ExtStratElt_ParMktSegtId) == TRUE) */ /* REF4047 - 000202 - SKE */
            IS_NULLFLD(ESLPtr, ExtStratLnk_ParStratMktSgtId) == TRUE)
        {
	        SET_NUMBER(ESEPtr, ExtStratElt_ObjWeightContrib, GET_NUMBER(ESEPtr, ExtStratElt_ObjWeight));
			SET_NUMBER(ESEPtr, ExtStratElt_OrigObjWeightContrib, GET_NUMBER(ESEPtr, ExtStratElt_ObjWeightContrib)); /* PMSTA15213-CHU-121107 */
	        if (IS_NULLFLD(ESEPtr, ExtStratElt_ObjWeightMarg) == FALSE)
	        {
	            SET_NUMBER(ESEPtr, ExtStratElt_ObjWeightContribMarg, GET_NUMBER(ESEPtr, ExtStratElt_ObjWeightMarg));
	        }

			/* PMSTA-40213-badhri-23072020 */
			if (IS_NULLFLD(ESEPtr, ExtStratElt_ObjLowerMarg) == FALSE)
				SET_NUMBER(ESEPtr, ExtStratElt_ObjLowerContribMarg, GET_NUMBER(ESEPtr, ExtStratElt_ObjLowerMarg));
			if (IS_NULLFLD(ESEPtr, ExtStratElt_ObjUpperMarg) == FALSE)
				SET_NUMBER(ESEPtr, ExtStratElt_ObjUpperContribMarg, GET_NUMBER(ESEPtr, ExtStratElt_ObjUpperMarg));
        } 
        else
        {
	        if ((parESEPtr = FIN_StratGetParESEPtr(ESEPtr)) != NULLDYNST)
	        {
	            if (IS_NULLFLD(parESEPtr, ExtStratElt_ObjWeightContrib) == FALSE)
	            {
		            if (IS_NULLFLD(ESEPtr, ExtStratElt_ObjWeight) == FALSE)
		            {
		                contrib = GET_NUMBER(ESEPtr, ExtStratElt_ObjWeight) *
			                      GET_NUMBER(parESEPtr, ExtStratElt_ObjWeightContrib) / 100.0;
		                SET_NUMBER(ESEPtr, ExtStratElt_ObjWeightContrib, CAST_NUMBER(contrib));
						SET_NUMBER(ESEPtr, ExtStratElt_OrigObjWeightContrib, GET_NUMBER(ESEPtr, ExtStratElt_ObjWeightContrib)); /* PMSTA15213-CHU-121107 */
		            }



		            if (IS_NULLFLD(ESEPtr, ExtStratElt_ObjWeightMarg) == FALSE)
		            {

						switch(GET_ENUM(ESEPtr, ExtStratElt_ForecastFlg))/* <SKE - 010208 - REF5599 */
						{
							case ExtStratEltForecast_Absolute:
	 			                 contrib = GET_NUMBER(ESEPtr, ExtStratElt_ObjWeightMarg) *
                                           GET_NUMBER(parESEPtr, ExtStratElt_ObjWeightContrib) / 100.0;
								 SET_NUMBER(ESEPtr, ExtStratElt_ObjWeightContribMarg, CAST_NUMBER(contrib));
								 break;
							case ExtStratEltForecast_Relative:
 	                             SET_NUMBER(ESEPtr, ExtStratElt_ObjWeightContribMarg, GET_NUMBER(ESEPtr, ExtStratElt_ObjWeightMarg));
            					 break;
	 			            case ExtStratEltForecast_AbsoluteContrib: /* REF7319 - 020308 - MCA */
								 SET_NUMBER(ESEPtr, ExtStratElt_ObjWeightContribMarg,
								 GET_NUMBER(ESEPtr, ExtStratElt_ObjWeightMarg));
	 			            	 break;
						}
		            }

					/* PMSTA-40213-badhri-23072020 */
					if (IS_NULLFLD(ESEPtr, ExtStratElt_ObjLowerMarg) == FALSE || IS_NULLFLD(ESEPtr, ExtStratElt_ObjUpperMarg) == FALSE)
					{
						NUMBER_T	        lowerContrib = 0.0;
						NUMBER_T	        upperContrib = 0.0;
						switch (GET_ENUM(ESEPtr, ExtStratElt_ForecastFlg))
						{
						case ExtStratEltForecast_Absolute:
							if (IS_NULLFLD(ESEPtr, ExtStratElt_ObjLowerMarg) == FALSE)
							{
								lowerContrib = GET_NUMBER(ESEPtr, ExtStratElt_ObjLowerMarg) *
									GET_NUMBER(parESEPtr, ExtStratElt_ObjWeightContrib) / 100.0;
								SET_NUMBER(ESEPtr, ExtStratElt_ObjLowerContribMarg, CAST_NUMBER(lowerContrib));
							}

							if (IS_NULLFLD(ESEPtr, ExtStratElt_ObjUpperMarg) == FALSE)
							{
								upperContrib = GET_NUMBER(ESEPtr, ExtStratElt_ObjUpperMarg) *
									GET_NUMBER(parESEPtr, ExtStratElt_ObjWeightContrib) / 100.0;
								SET_NUMBER(ESEPtr, ExtStratElt_ObjUpperContribMarg, CAST_NUMBER(upperContrib));
							}
							break;
						case ExtStratEltForecast_Relative:
							if (IS_NULLFLD(ESEPtr, ExtStratElt_ObjLowerMarg) == FALSE)
								SET_NUMBER(ESEPtr, ExtStratElt_ObjLowerContribMarg, GET_NUMBER(ESEPtr, ExtStratElt_ObjLowerMarg));
							if (IS_NULLFLD(ESEPtr, ExtStratElt_ObjUpperMarg) == FALSE)
								SET_NUMBER(ESEPtr, ExtStratElt_ObjUpperContribMarg, GET_NUMBER(ESEPtr, ExtStratElt_ObjUpperMarg));
							break;
						case ExtStratEltForecast_AbsoluteContrib:
							if (IS_NULLFLD(ESEPtr, ExtStratElt_ObjLowerMarg) == FALSE)
								SET_NUMBER(ESEPtr, ExtStratElt_ObjLowerContribMarg, GET_NUMBER(ESEPtr, ExtStratElt_ObjLowerMarg));
							if (IS_NULLFLD(ESEPtr, ExtStratElt_ObjUpperMarg) == FALSE)
								SET_NUMBER(ESEPtr, ExtStratElt_ObjUpperContribMarg, GET_NUMBER(ESEPtr, ExtStratElt_ObjUpperMarg));
							break;
						}
					}
	            }
	        }
        }
    }

    /* Init to 0 position values */
    SET_NUMBER(ESEPtr,   ExtStratElt_ActualQty,               0.0);
    SET_PRICE(ESEPtr,   ExtStratElt_CostQuote,               0.0);
    SET_PRICE(ESEPtr,   ExtStratElt_CostPrice,               0.0);
    SET_EXCHANGE(ESEPtr, ExtStratElt_CostExchRate,            0.0);
    SET_PRICE(ESEPtr,   ExtStratElt_CrtQuote,                0.0);
    SET_PRICE(ESEPtr,   ExtStratElt_CrtPrice,                0.0);
    SET_EXCHANGE(ESEPtr, ExtStratElt_CrtExchRate,             0.0);
    SET_NUMBER(ESEPtr,   ExtStratElt_CostGrossVal,            0.0);
    SET_NUMBER(ESEPtr,   ExtStratElt_CostNetVal,              0.0);
    SET_NUMBER(ESEPtr,   ExtStratElt_CrtNetVal,               0.0);
    SET_NUMBER(ESEPtr,   ExtStratElt_CrtMktVal,               0.0);
    SET_NUMBER(ESEPtr,   ExtStratElt_ActualWeight,            0.0);
    SET_NUMBER(ESEPtr,   ExtStratElt_ActualWeightContrib,     0.0);
    SET_NUMBER(ESEPtr,   ExtStratElt_ActualWeightContribCalc, 0.0);

    return(RET_SUCCEED);
}

/*************************************************************************************
*   Function             : FIN_StratCreateESEModelTot()
*
*   Description          : Create model total (because of no one element for model ...) .
*
*   Arguments            :
*
*   Return               : RET_SUCCEED or error code
*
*   Creation Date        : 24.09.99 - REF3729
*	Modif.				 : MRA - 991220 - REF4047  Set Default Values described in script
*
**************************************************************************************/
RET_CODE FIN_StratCreateESEModelTot(DBA_HIER_HEAD_STP        stratHierPtr,
					               int                      ESEFldNbr,
					               DBA_DYNFLD_STP           ESLPtr,
                                   int                      selOptions,
                                   int                     *connectNo)
{
    RET_CODE        ret            = RET_SUCCEED;
	DBA_DYNFLD_STP  ESEPtr         = NULLDYNST;
    DBA_DYNFLD_STP  aStratElt      = NULLDYNST;
    DBA_DYNFLD_STP  stratHistStp   = NULLDYNST;
	FLAG_T		   *scptFlagTab;
	int		        code;

	if (ESEFldNbr > 0)
	{
	    ESEPtr = ALLOC_DYNST_SUPPLFLD(ExtStratElt, ESEFldNbr);

	    if (ESEPtr == NULLDYNST)
	    {
		    MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtStratElt suppl. fld");
		    return(RET_MEM_ERR_ALLOC);
	    }
	}
	else
	{
	    ESEPtr = ALLOC_DYNST(ExtStratElt);

	    if (ESEPtr == NULLDYNST)
	    {
		    MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtStratElt");
		    return(RET_MEM_ERR_ALLOC);
	    }
	}

	/* LEVEL */
	SET_TINYINT(ESEPtr, ExtStratElt_Level, 1);

	/* WEIGHTS */
	SET_NUMBER(ESEPtr, ExtStratElt_ObjWeight, 0.0);

	/* INIT COMMON FIELDS AND ADD EXTENDED STRATEGY ELEMENT IN HIERARCHY */

	if ((ret = FIN_StratAddESEInHier(stratHierPtr,
                                     ESEPtr,
                                     ESEFldNbr,
                                     ESLPtr,
				                     ExtStratEltNat_ModelDetail)) != RET_SUCCEED)
	{
		return(ret);
	}

	/* prepare link ExtStratElt_DispPar_ExtStratElt_Ext */
	if (IS_NULLFLD(ESEPtr, ExtStratElt_ParExtStratEltId) == FALSE)
	{
        SET_ID(ESEPtr, ExtStratElt_DispParExtStratEltId, GET_ID(ESEPtr, ExtStratElt_ParExtStratEltId));
    }


	/* Create A_StratElt and add it in hierarchy (and do A_StratHist link if exist) */
	if ((aStratElt = ALLOC_DYNST(A_StratElt)) == NULLDYNST)
	{
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "A_StratElt");
		return(RET_MEM_ERR_ALLOC);
	}

	/* Set Default Values described in MD */
	DBA_SetDfltEntityFld(StratElt, A_StratElt, aStratElt);

    if (static_cast<StratSubNatEn>(GET_ENUM(ESLPtr, ExtStratLnk_SubNatEn)) == StratSubNatEn::ConstantWeight) /* PMSTA-51103-Deepthi-20221202 */
    {
        SET_ENUM(aStratElt, A_StratElt_NatEn, (ENUM_T) StratEltNat_ModelConstWeight);
    }
    else
    {
        SET_ENUM(aStratElt, A_StratElt_NatEn, (ENUM_T) StratEltNat_Model);
    }

	SET_NUMBER(aStratElt, A_StratElt_Value, 0.0);

	/* REF4047 */
	scptFlagTab = (FLAG_T *)CALLOC(GET_FLD_NBR(A_StratElt), sizeof(FLAG_T)); /* REF7264 - LJE - 020130 */
	scptFlagTab[A_StratElt_NatEn] = TRUE;
	scptFlagTab[A_StratElt_Value] = TRUE;

    if ((selOptions & DBA_IN_TRAN) != DBA_IN_TRAN)
    {
	    /* Set Default Values described in script REF4047*/
	    if((code = SCPT_ComputeScreenDV(StratElt,
                                        DictFct_0,
									    scptFlagTab,
                                        NULL,              /* HFI-PMSTA-25327-171023  Dedicated flag tab for filter    */
									    aStratElt,
									    NULL,
									    NULL,
                                        NULLDYNST,   /* PMSTA13283 - DDV - 120117 */
									    TRUE,
									    TRUE,
                                        EvalType_DefValAndFilter,   /* FPL-REF9507-030930 */
									    -1,
									    connectNo,
									    NULL,
									    stratHierPtr,
									    0,
                                        DictScreen,                 /*  FIH-REF9789-040209  */
									    NULL,
                                        NULL,
                                        NULL,
                                        NULL,
                                        NULL,
                                        NullEntity,
                                        FALSE,
                                        FALSE,
                                        0)) != 0)   /*  FPL-REF9215-030811  Flag Impact */
		    return(RET_GEN_ERR_INVARG);
    }

    /* MRA - 040202 - REF9769 */
    /* BIDOUILLE */
    /* in case of a dummy portfolio strategy I use dbLoadedFlag = TRUE beacause */
    /* I know that in this case I can never save a history and this solution let me */
    /* to have a updDbRecFlg to FALSE, so in GUI I put on grey the save button */

    if (static_cast<StratSubNatEn>(GET_ENUM(ESLPtr, ExtStratLnk_SubNatEn)) == StratSubNatEn::DummyPortfolio) /* PMSTA-51103-Deepthi-20221202 */
    {
	    ret = DBA_AddHierRecord(stratHierPtr, aStratElt, A_StratElt, TRUE,
			                    HierAddRec_TestMandatLnk);
    }
    else
    {
        ret = DBA_AddHierRecord(stratHierPtr, aStratElt, A_StratElt, FALSE,
			                HierAddRec_TestMandatLnk);

    }

	if (ret == RET_SUCCEED &&
		GET_EXTENSION_PTR(ESLPtr, ExtStratLnk_A_StratHist_Ext) != NULL &&
		(stratHistStp = *(GET_EXTENSION_PTR(ESLPtr, ExtStratLnk_A_StratHist_Ext))) != NULLDYNST)
	{
		SET_ID(aStratElt, A_StratElt_StratHistId,  GET_ID(stratHistStp, A_StratHist_Id));
		SET_ID(ESEPtr,    ExtStratElt_StratHistId, GET_ID(stratHistStp, A_StratHist_Id));

		/* Link extended strategy link to extended strategy element */
		ret = DBA_ForceLink(stratHierPtr,
			                A_StratHist,
                            A_StratHist_A_StratElt_Ext,
			                stratHistStp, aStratElt);
	}
    SET_ID(aStratElt, A_StratElt_ExtStratElt_Id, GET_ID(ESEPtr, ExtStratElt_Id));

	return(ret);
}

/*************************************************************************************
*   Function             : FIN_StratCreateESERiskDet()
*
*   Description          : Create risk strategy elements.
*
*   Arguments            :
*                           eseNatEn        : element nature
*
*   Return               : RET_SUCCEED or error code
*
*   Creation Date        : PMSTA05345-CHU-080505
*
**************************************************************************************/
RET_CODE FIN_StratCreateESERiskDet(DBA_HIER_HEAD_STP    stratHierPtr,
                                   int                  ESEFldNbr,
                                   DBA_DYNFLD_STP       ESLPtr,
                                   DBA_DYNFLD_STP       stratEltPtr,
                                   DBA_DYNFLD_STP       ESEArgPtr,
                                   EXTSTRATELTNAT_ENUM  eseNatEn)
{
    RET_CODE            ret         = RET_SUCCEED;
    DBA_DYNFLD_STP      ESEPtr      = NULLDYNST;

    if (ESEArgPtr == NULLDYNST)
    {
        if (ESEFldNbr > 0)
        {
    	    ESEPtr = ALLOC_DYNST_SUPPLFLD(ExtStratElt, ESEFldNbr);
	        if (ESEPtr == NULLDYNST)
	        {
	            MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtStratElt suppl. fld");
	            return(RET_MEM_ERR_ALLOC);
	        }
        }
        else
        {
	        ESEPtr = ALLOC_DYNST(ExtStratElt);
	        if (ESEPtr == NULLDYNST)
	        {
	            MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtStratElt");
	            return(RET_MEM_ERR_ALLOC);
	        }
        }
    }
    else
    {
        ESEPtr = ESEArgPtr;
    }

	SET_TINYINT(ESEPtr, ExtStratElt_Level, 1);

    /* INIT COMMON FIELDS AND ADD EXTENDED STRATEGY ELEMENT IN HIERARCHY */
    if ((ret = FIN_StratAddESEInHier(stratHierPtr,
                                     ESEPtr,
                                     ESEFldNbr,
                                     ESLPtr,
			                         eseNatEn)) != RET_SUCCEED)
    {
	    return(ret);
    }

    SET_ID(stratEltPtr, A_StratElt_ExtStratElt_Id, GET_ID(ESEPtr, ExtStratElt_Id));

    /* prepare link ExtStratElt_DispPar_ExtStratElt_Ext */
    SET_ID(ESEPtr, ExtStratElt_DispParExtStratEltId, GET_ID(ESEPtr, ExtStratElt_ParExtStratEltId));

	if (GET_ENUM(ESEPtr, ExtStratElt_StratNatEn) == StratNat_Risk)
    {
		COPY_DYNFLD(ESEPtr, ExtStratElt, ExtStratElt_CompChronoNat,
					stratEltPtr, A_StratElt, A_StratElt_CompChronoNat);
		if (IS_NULLFLD(stratEltPtr, A_StratElt_CompChronoCompNat) == FALSE)
		{
			COPY_DYNFLD(ESEPtr, ExtStratElt, ExtStratElt_CompChronoCompNat,  /* PMSTA-18426 - CHU - 141022 */
						stratEltPtr, A_StratElt, A_StratElt_CompChronoCompNat);
		}
		else
		{
			SET_ENUM(ESEPtr, ExtStratElt_CompChronoCompNat, (ENUM_T)CompChronoCompNat_Measure); /* PMSTA-18426 - CHU - 141022 */
		}
	}

	COPY_DYNFLD(ESEPtr, ExtStratElt, ExtStratElt_Min,
				stratEltPtr, A_StratElt, A_StratElt_Min);

	COPY_DYNFLD(ESEPtr, ExtStratElt, ExtStratElt_Max,
				stratEltPtr, A_StratElt, A_StratElt_Max);

	COPY_DYNFLD(ESEPtr, ExtStratElt, ExtStratElt_ObjTrackErr,
				stratEltPtr, A_StratElt, A_StratElt_ObjTrackErr);

	COPY_DYNFLD(ESEPtr, ExtStratElt, ExtStratElt_ObjTrackErrMarg,
				stratEltPtr, A_StratElt, A_StratElt_ObjTrackErrMarg);

	COPY_DYNFLD(ESEPtr, ExtStratElt, ExtStratElt_ActualTrackErr,
				stratEltPtr, A_StratElt, A_StratElt_ActualTrackErr);

	COPY_DYNFLD(ESEPtr, ExtStratElt, ExtStratElt_EffTrackErr,
				stratEltPtr, A_StratElt, A_StratElt_EffTrackErr);

	COPY_DYNFLD(ESEPtr, ExtStratElt, ExtStratElt_ObjTrackErrCheckEn,
				stratEltPtr, A_StratElt, A_StratElt_ObjTrackErrCheckEn);

	/* PMSTA-18426 / PMSTA-18821 - CHU - 141024 */
	COPY_DYNFLD(ESEPtr, ExtStratElt, ExtStratElt_CriticalnessEn,
				stratEltPtr, A_StratElt, A_StratElt_CriticalnessEn);

    if (IS_NULLFLD(stratEltPtr, A_StratElt_Rank) == TRUE)
	{
	    SET_NULL_SMALLINT(ESEPtr, ExtStratElt_Rank);
	}
	else
	{
	    SET_SMALLINT(ESEPtr, ExtStratElt_Rank, GET_SMALLINT(stratEltPtr, A_StratElt_Rank));
	}

	SET_ID(ESEPtr, ExtStratElt_StratHistId, GET_ID(stratEltPtr, A_StratHist_Id));

    return(RET_SUCCEED);
}


/************************************************************************
**
**  Function    :   FIN_StratInsStratElt
**
**  Description :   Create model and recommendation list element.
**
**  Arguments   :   DBA_HIER_HEAD_STP hierStp
**					DBA_DYNFLD_STP oriExtStratEltStp,
**					ID_T* refIdPtr
**
**  Return      :   RET_CODE
**
**	Cr�ation	:	ROI - 990909 - REF3729
**	Modif.		:	MRA - 991220 - REF4047  Set Default Values described in script
**	Modif.		:	MCA - 011001 - REF7067  Set Null Values to field ExtStratElt_OrdParExtStratEltId
**
*************************************************************************/
RET_CODE FIN_StratInsStratElt(DBA_HIER_HEAD_STP  hierStp,
                             DBA_DYNFLD_STP     oriExtStratEltStp,
                             ID_T              *refIdPtr)
{
    RET_CODE		    	retCode         = RET_SUCCEED;
	DBA_HIER_ELT_STP    	hierEltStp      = (DBA_HIER_ELT_STP)NULL;
	DBA_DYNFLD_STP	    	stratHistStp    = NULLDYNST;
    DBA_DYNFLD_STP	    	stratEltStp     = NULLDYNST;
    DBA_DYNFLD_STP	    	extStratEltStp  = NULLDYNST;
    DBA_DYNFLD_STP	    	oriStratEltStp  = NULLDYNST;
	DBA_DYNFLD_STP         *stratEltTab     = NULLDYNSTPTR;
    DBA_DYNFLD_STP         *stratLnkTab     = NULLDYNSTPTR;
    DBA_DYNFLD_STP         *ESETab          = NULLDYNSTPTR;
    EXTSTRATELTNAT_ENUM     eseNatEn = 	ExtStratEltNat_RecommList;
	STRATNAT_ENUM        seNatEn;
	FLAG_T			       *scptFlagTab     = (FLAG_T*)NULL;
    int					    fldNbr          = 0;
    int				    	stratEltNbr     = 0;
    int					    stratLnkNbr     = 0;
    int					    ESENbr          = 0;
    int					    i;

	if (hierStp == (DBA_HIER_HEAD_STP)NULL)
        MSG_RETURN(RET_GEN_ERR_INVARG);
    if (oriExtStratEltStp == NULLDYNST)
        MSG_RETURN(RET_GEN_ERR_INVARG);
    if (refIdPtr == (ID_T*) NULL)
        MSG_RETURN(RET_GEN_ERR_INVARG);

    hierEltStp = DBA_GetAutoAddHierEltByDynSt(hierStp, ExtStratElt);                /* PMSTA-13295 - JPP - 20120216 */
    if (hierEltStp == (DBA_HIER_ELT_STP) NULL)
        MSG_RETURN(RET_GEN_ERR_INVARG);

    if (GET_ENUM(oriExtStratEltStp, ExtStratElt_StratNatEn) != (ENUM_T) StratNat_ModelPtf  &&
        GET_ENUM(oriExtStratEltStp, ExtStratElt_StratNatEn) != (ENUM_T) StratNat_CashMgtStrat  && /*PMSTA-42402 Autocash Vishnu 23112020*/
        GET_ENUM(oriExtStratEltStp, ExtStratElt_StratNatEn) != (ENUM_T) StratNat_RecomList &&
		GET_ENUM(oriExtStratEltStp, ExtStratElt_StratNatEn) != (ENUM_T) StratNat_Index &&	/* PMSTA01435 - RAK - 070314 */
        GET_ENUM(oriExtStratEltStp, ExtStratElt_StratNatEn) != (ENUM_T) StratNat_SSL)
    {
        return(retCode);
    }


	/* Recherche de A_StratElt correspondant */
    /* Get current ExtStratLnk to get history and all strategy element list */
    retCode = DBA_ExtractHierEltRecWithFilterSt(hierStp,
												ExtStratLnk,
												FALSE,
												FIN_StratFilterCrtESL,
												oriExtStratEltStp,
												NULLFCT,
												&stratLnkNbr,
												&stratLnkTab);

    /* Always 1 ExtStratLnk */
    if (stratLnkNbr != 1 || stratLnkTab == NULLDYNSTPTR)
		return RET_DBA_ERR_HIER;

    /* Get history and element(s) */
    if (GET_EXTENSION_PTR(stratLnkTab[0], ExtStratLnk_A_StratHist_Ext) != NULL &&
		(stratHistStp = *(GET_EXTENSION_PTR(stratLnkTab[0], ExtStratLnk_A_StratHist_Ext))) != NULLDYNST)
    {
		stratEltTab = GET_EXTENSION_PTR(stratHistStp, A_StratHist_A_StratElt_Ext);
		stratEltNbr = GET_EXTENSION_NBR(stratHistStp, A_StratHist_A_StratElt_Ext);
    }

    /* if (stratEltNbr == 0 || stratEltTab == NULLDYNSTPTR)
		return RET_DBA_ERR_HIER; */

	/* Allocations */
	if ((stratEltStp = ALLOC_DYNST(A_StratElt)) == NULLDYNST)
    {
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "A_StratElt");
		return(RET_MEM_ERR_ALLOC);
    }

	if (hierEltStp->recInfoTab[0].totalFldNbr != 0)
	{
		fldNbr = hierEltStp->recInfoTab[0].totalFldNbr;
		if ((extStratEltStp = ALLOC_DYNST_SUPPLFLD(ExtStratElt, fldNbr)) == NULLDYNST)
        {
		    MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtStratElt suppl. fld");
		    return(RET_MEM_ERR_ALLOC);
        }
	}
	else
	{
		fldNbr = GET_FLD_NBR(ExtStratElt);
		if ((extStratEltStp = ALLOC_DYNST(ExtStratElt)) == NULLDYNST)
        {
		    MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "ExtStratElt");
		    return(RET_MEM_ERR_ALLOC);
        }
	}

	/* Recherche du A_StratElt */
	for (i=0; i < stratEltNbr; i++)
	{
		/* REF11559 - CHU - 051124 : check validity of Strategy element */
		if (GET_ID(stratEltTab[i], A_StratElt_Id) < (ID_T)0 &&
			IS_NULLFLD(stratEltTab[i], A_StratElt_PtfIdForMissingPM) == FALSE &&
			CMP_ID(GET_ID(stratLnkTab[0], ExtStratLnk_PtfId), GET_ID(stratEltTab[i], A_StratElt_PtfIdForMissingPM))!=0)
		{
			continue;
		}

        if (GET_ID(oriExtStratEltStp, ExtStratElt_Id) == GET_ID(stratEltTab[i], A_StratElt_ExtStratElt_Id))
        {
			oriStratEltStp = stratEltTab[i];
            break;
        }
	}

	if ((scptFlagTab = (FLAG_T *)CALLOC(GET_FLD_NBR(A_StratElt), sizeof(FLAG_T))) == NULL)	/* REF4047 */ /* REF7264 - LJE - 020130 */
    {
		MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "scptFlagTab");
		return(RET_MEM_ERR_ALLOC);
    }

	/* Copie du record de base */
	if (oriStratEltStp != NULLDYNST)
	{
        COPY_DYNST(stratEltStp, oriStratEltStp, A_StratElt);
        SET_NULL_PTR(stratEltStp, A_StratElt_EditBackupPtr);        /*  HFI-PMSTA-15321-121105  */
    }
	else
	{
		/* Set Default Values described in MD */
		DBA_SetDfltEntityFld(StratElt, A_StratElt, stratEltStp);

		if (stratHistStp != NULLDYNST)
		{
			SET_ID(stratEltStp, A_StratElt_StratHistId, GET_ID(stratHistStp, A_StratHist_Id));
			scptFlagTab[A_StratElt_StratHistId] = TRUE;			/* REF4047 */
		}
	}

	SET_NULL_ID(stratEltStp, A_StratElt_Id);
	SET_NULL_ID(stratEltStp, A_StratElt_InstrId);
	SET_NULL_SMALLINT(stratEltStp, A_StratElt_Rank);
	SET_NULL_NUMBER(stratEltStp, A_StratElt_Value);
	SET_NULL_NUMBER(stratEltStp, A_StratElt_FluctMargin);

	/* REF7487 VST 020807 SSL management*/
	seNatEn = (STRATNAT_ENUM)GET_ENUM(oriExtStratEltStp, ExtStratElt_StratNatEn);
	switch(seNatEn)
	{
		case StratNat_ModelPtf:
		case StratNat_Index:	/* PMSTA01435 - RAK - 070319 */
	        eseNatEn = ExtStratEltNat_ModelDetail;
		    /* REF4047 - 000203 - SKE : Sub Nature management */
            if (static_cast<StratSubNatEn>(GET_ENUM(stratLnkTab[0], ExtStratLnk_SubNatEn)) == StratSubNatEn::ConstantWeight) /* PMSTA-51103-Deepthi-20221202 */
	        {
		        SET_ENUM(stratEltStp, A_StratElt_NatEn, (ENUM_T) StratEltNat_ModelPtfConstWeight);
			}
			else
			{
				SET_ENUM(stratEltStp, A_StratElt_NatEn, (ENUM_T) StratEltNat_ModelPtf);
			}
			break;
		case StratNat_RecomList:
	        SET_ENUM(stratEltStp, A_StratElt_NatEn, (ENUM_T) StratEltNat_RecommList);
		    eseNatEn = ExtStratEltNat_RecommList;
			break;
		case StratNat_SSL:
	        SET_ENUM(stratEltStp, A_StratElt_NatEn, (ENUM_T) StratEltNat_SSL);
		    eseNatEn = ExtStratEltNat_SSL;
			break;
        case StratNat_CashMgtStrat:                                                 /*PMSTA-42402 Autocash Vishnu 23112020*/
            SET_ENUM(stratEltStp, A_StratElt_NatEn, (ENUM_T)StratEltNat_Amount);
            eseNatEn = ExtStratEltNat_ModelDetail;
            break;

		default:
			break;
	}
	scptFlagTab[A_StratElt_NatEn] = TRUE;			/* REF4047 */

    /* Duplicate ExtStratElt fields */
	COPY_DYNST_SUPPLFLD(extStratEltStp, oriExtStratEltStp, fldNbr);

	/* REF4047 - 991229 - SKE : model/recommendation defined with break criterias */
    if (GET_ENUM(extStratEltStp, ExtStratElt_NatEn) == ExtStratEltNat_BreakCriteria)
    {
        SET_TINYINT(extStratEltStp, ExtStratElt_Level, 2);
        SET_ENUM(extStratEltStp, ExtStratElt_NatEn, ExtStratEltNat_ModelDetail);
		SET_ID(extStratEltStp, ExtStratElt_DispParExtStratEltId, GET_ID(extStratEltStp, ExtStratElt_Id));
		SET_ID(extStratEltStp, ExtStratElt_ParExtStratEltId, GET_ID(extStratEltStp, ExtStratElt_Id));
    }
    else
    {
	    if (GET_TINYINT(extStratEltStp, ExtStratElt_Level) == 1)
	    {
		    SET_TINYINT(extStratEltStp, ExtStratElt_Level, 2);
		    SET_ID(extStratEltStp, ExtStratElt_DispParExtStratEltId, GET_ID(extStratEltStp, ExtStratElt_Id));
		    SET_ID(extStratEltStp, ExtStratElt_ParExtStratEltId, GET_ID(extStratEltStp, ExtStratElt_Id));
	    }
    }

	SET_NULL_ID(extStratEltStp, ExtStratElt_Id);
	SET_NULL_ID(extStratEltStp, ExtStratElt_InstrId);
	SET_NULL_SMALLINT(extStratEltStp, ExtStratElt_Rank);
	SET_NULL_SMALLINT(extStratEltStp, ExtStratElt_Priority);
    SET_NULL_NUMBER(extStratEltStp, ExtStratElt_ObjWeight);
	SET_NULL_NUMBER(extStratEltStp, ExtStratElt_ObjWeightMarg);
    SET_NULL_NUMBER(extStratEltStp, ExtStratElt_ObjWeightContrib);
	SET_NULL_NUMBER(extStratEltStp, ExtStratElt_OrigObjWeightContrib); /* PMSTA15213-CHU-121107 */
	SET_NULL_NUMBER(extStratEltStp, ExtStratElt_ObjWeightContribMarg);
    SET_NULL_NUMBER(extStratEltStp, ExtStratElt_MaxWeight);
    SET_NULL_NUMBER(extStratEltStp, ExtStratElt_MaxWeightContrib);
    SET_NULL_NUMBER(extStratEltStp, ExtStratElt_MinWeight);

    SET_NULL_NUMBER(extStratEltStp, ExtStratElt_Weight);
    SET_NULL_ENUM(extStratEltStp, ExtStratElt_WeightNatEn);

	SET_NULL_ID(extStratEltStp, ExtStratElt_OrdParExtStratEltId); /* REF7067 MCA 011001*/
																  /*only for a new inserted instrument*/
	SET_NULL_TINYINT(extStratEltStp, ExtStratElt_MktStructLevel); /* REF8902 CHU 030430 */

	SET_NULL_NUMBER(extStratEltStp, ExtStratElt_DynObjWeight); /* REF11457 - CHU - 051111 */
	SET_NULL_NUMBER(extStratEltStp, ExtStratElt_OldObjWeight); /* REF11457 - CHU - 051111 */

	SET_NULL_ID(extStratEltStp, ExtStratElt_ActRiskESEltId); /* PMSTA-19942 - CHU - 150213 */
	SET_NULL_ID(extStratEltStp, ExtStratElt_EffRiskESEltId); /* PMSTA-19942 - CHU - 150213 */


    /* REF4047 - 000103 - SKE */
    COPY_DYNFLD(stratEltStp, A_StratElt, A_StratElt_MktSegtId, extStratEltStp, ExtStratElt, ExtStratElt_MktSegtId);


	/* Set Default Values described in script */	/* REF4047 */
	if(SCPT_ComputeScreenDV(StratElt,
                            DictFct_0,
							scptFlagTab,
                            NULL,              /* HFI-PMSTA-25327-171023  Dedicated flag tab for filter    */
							stratEltStp,
							NULL,
							NULL,
                            NULLDYNST,   /* PMSTA13283 - DDV - 120117 */
							TRUE,
							TRUE,
                            EvalType_DefValAndFilter,   /* FPL-REF9507-030930 */
							-1,
							(int *)NULL,
							NULL,
							hierStp,
                            0,
                            DictScreen,                 /*  FIH-REF9789-040209  */
							NULL,
                            NULL,
                            NULL,
                            NULL,
                            NULL,
                            NullEntity,
                            FALSE,
                            FALSE,
                            0) != 0)   /* FPL-REF9215-030811  Flag Impact */
        return(RET_GEN_ERR_INVARG);

	retCode = FIN_StratAddESEInHier(hierStp,
									extStratEltStp,
									fldNbr,
									stratLnkTab[0],
									eseNatEn);

    if (retCode != RET_SUCCEED)
        return(retCode);

	*refIdPtr = GET_ID(extStratEltStp, ExtStratElt_Id);

	/* Ajout dans la hi�rarchie */
	retCode = DBA_AddHierRecord(hierStp,
								stratEltStp,
								A_StratElt,
								FALSE,
								HierAddRec_TestMandatLnk);

    if (retCode != RET_SUCCEED)
        return(retCode);

    /* REF4047 - 000105 - SKE */
    SET_ID(stratEltStp, A_StratElt_ExtStratElt_Id, GET_ID(extStratEltStp, ExtStratElt_Id));

	/* REF4047 */
	if(IS_NULLFLD(stratEltStp, A_StratElt_Value) == FALSE)
		SET_NUMBER(extStratEltStp, ExtStratElt_ObjWeight, GET_NUMBER(stratEltStp, A_StratElt_Value));

	if(IS_NULLFLD(stratEltStp, A_StratElt_Rank) == FALSE)
		SET_SMALLINT(extStratEltStp, ExtStratElt_Rank, GET_SMALLINT(stratEltStp, A_StratElt_Rank));			/* RAK 031112 - wrong type used */

	if(IS_NULLFLD(stratEltStp, A_StratElt_RecomNatEn) == FALSE)
		SET_ENUM(extStratEltStp, ExtStratElt_RecomNatEn, GET_ENUM(stratEltStp, A_StratElt_RecomNatEn));		/* RAK 031112 - wrong type used */

	if(IS_NULLFLD(stratEltStp, A_StratElt_FluctMargin) == FALSE)
		SET_NUMBER(extStratEltStp, ExtStratElt_ObjWeightMarg, GET_NUMBER(stratEltStp, A_StratElt_FluctMargin));

	/* REF7022 - CHU - 010920 */
	if(IS_NULLFLD(stratEltStp, A_StratElt_Priority) == FALSE)
		SET_SMALLINT(extStratEltStp, ExtStratElt_Priority, GET_SMALLINT(stratEltStp, A_StratElt_Priority));	/* RAK 031112 - wrong type used */

    /* REF3729 - Because of bidouille (several same parent but only one child ...) */
	if ((retCode = DBA_ExtractHierEltRec(hierStp,
			                             ExtStratElt,
			                             FALSE,
                                         FIN_StratFilterParESE,
                                         NULLFCT,
			                             &ESENbr,
                                         &ESETab)) != RET_SUCCEED)
    {
        return(retCode);
    }

	for (i=0; i<ESENbr; i++)
    {
		SET_NULL_ENUM(ESETab[i], ExtStratElt_CalcEn);
    }

    retCode = DBA_MakeLinks(hierStp);

    return(retCode);
}


/************************************************************************
**
**  Function    :   FIN_StratInsDbStratElt()
**
**  Description :   Insert A_StratElt in database
**
**  Arguments   :   DBA_HIER_HEAD_STP hierStp
**		    DBA_DYNFLD_STP    stratEltPtr
**		    DBA_DYNST_ENUM    dynStTp
**		    OBJECT_ENUM       entity
**
**  Return      :   RET_CODE
**
**  Cr�ation	:   RAK - 990914 - REF3729
**  Modif	:	MDE - 991129 - REF4047 - Svg in a Sybase Transaction
**
*************************************************************************/
RET_CODE FIN_StratInsDbStratElt(PTR                     argHierHeadPtr, /* REF7264 - LJE - 020131 */
                                DBA_DYNFLD_STP          stratEltPtr,
                                DBA_DYNST_ENUM          dynStTp,
                                OBJECT_ENUM             entity,
                                int                     insOptions,		/* MDE - 991129 - REF4047 */
                                int                     *allocConn,
                                DBA_ERRMSG_INFOS_STP)   /* MDE - 991129 - REF4047 */
{
    RET_CODE            retCode = RET_SUCCEED;
	DBA_DYNFLD_STP      ESEPtr  = NULLDYNST;
    DICT_T              stratDictId;

	DBA_HIER_HEAD_STP hierHeadPtr=(DBA_HIER_HEAD_STP)argHierHeadPtr;  /* REF7264 - LJE - 020131 */


	/* Test given arguments */
	if (hierHeadPtr == NULL      || /* REF7264 - LJE - 020130 */
	    stratEltPtr == NULLDYNST ||
	    dynStTp     == NullDynSt ||
	    entity      == NullEntity)
	{
	    MSG_RETURN(RET_GEN_ERR_INVARG);
	}

    /* <SKE 000913 REF5192 */
    DBA_GetDictId(Strat, &stratDictId);

    if (GET_ENUM(stratEltPtr, A_StratElt_NatEn) == StratEltNat_ReferenceWeight) /* REF11518 - TEB - 051026 */
    {
		return(RET_SUCCEED);
    }

/* SKE 001107 REF5192> */


    /*
        In case of a recommendation, don't record the market segment id
        because the instrument market segment is found dynamically during the
        process.
    */
    if (GET_ENUM(stratEltPtr, A_StratElt_NatEn) == (ENUM_T) StratEltNat_RecommList)
    {
        SET_NULL_ID(stratEltPtr, A_StratElt_MktSegtId);
    }

    /* Get the ESE linked to A_StratElt */
    if (IS_NULLFLD(stratEltPtr, A_StratElt_ExtStratElt_Id) == FALSE)
    {
        ESEPtr = DBA_SearchHierRecById(hierHeadPtr,
		                               ExtStratElt,
				                       ExtStratElt_Id,
                                       GET_ID(stratEltPtr, A_StratElt_ExtStratElt_Id));

    }

	/* Insert element */
	retCode = DBA_Insert2(entity,
                          UNUSED,
                          dynStTp,
                          stratEltPtr,
                          insOptions,		/* MDE - 991129 - REF4047 */
                          allocConn);	/* MDE - 991129 - REF4047 */

	if (retCode == RET_SUCCEED)
	{
	    if (ESEPtr != NULLDYNST)
	    {
			SET_ID(ESEPtr, ExtStratElt_StratHistId, GET_ID(stratEltPtr, A_StratElt_StratHistId));	/* for new history ... */
	    }
	}

	return(retCode);
}



/************************************************************************
**      END  finlib07.c
*************************************************************************/

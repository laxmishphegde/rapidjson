/************************************************************************
**
**              Copyright (C) Temenos Software Luxembourg SA 1995-2021.
**                       All Rights Reserved
**
**                   Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define FINPERFNIP_C

/************************************************************************
**      Include files
*************************************************************************/
#include "unidef.h"         /* Mandatory */
#include "gen.h"
#include "dba.h"
#include "hier.h"
#include "fin.h"
#include "finsrv.h"
#include "finperfa.h"


/*  -------------------------------------------------------------------------------------------- **
**
**
**  ------------------------------------------------------------------------------------------- **
**  FILTER FUNCTIONS
**  -----------------
**  -------------------------------------------------------------------------------------------- **
**
**  COMPARISONS FUNCTIONS
**  -----------------
**
**  -------------------------------------------------------------------------------------------- */

/************************************************************************
**      Static definitions & data
*************************************************************************/

STATIC RET_CODE FIN_SetExtPosTimingRule(const DBA_DYNFLD_STP extPosStp, DBA_HIER_HEAD_STP hierHead);

STATIC RET_CODE FIN_AddNIPPeriod(const DBA_DYNFLD_STP extPosStp, DATETIME beginDate, PerfTimingRuleTimingRuleEn beginTimingRule,
                                 DATETIME endDate, PerfTimingRuleTimingRuleEn endTimingRule, PA_DATEINFO_STP paDateInfoStp);

STATIC RET_CODE FIN_CreateInstrNIPPeriod(DBA_DYNFLD_STP domainStp, const DBA_DYNFLD_STP extPosStp, PosFlowInfo firstInstrPosFlowInfoEn,
                                         std::vector<NIP_EVENT_ST> & vInstrNIPEvent, PA_DATEINFO_STP paDateInfoStp);

STATIC int FIN_CmpPosPtfInstrDateNat(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2);

STATIC RET_CODE FIN_AddPtfNIPPeriod(DBA_DYNFLD_STP domainPtr, PA_DATEINFO_STP paDateInfoStp, DATETIME_T **crystalDate, int *crystalNbr, DatePeriodVec &);
STATIC RET_CODE FIN_MergePtfNIPCrystalDates(PA_DATEINFO_STP paDateInfoStp, DATETIME_T **crystalDate, int *crystalNbr);
STATIC bool FIN_NipDateAlreadyExists(DATETIME_T *crystalDate, int &storageFreqNbr, DATETIME_T &givenDate);
STATIC RET_CODE FIN_AddNipDateToCrystalTab(DATETIME_T **crystalDate, int *crystalNbr, DATETIME_T &givenDate);
STATIC ID_T FIN_GetRealInstrIdForFlowInfo(DBA_DYNFLD_STP extPos, ID_T instrIdParam = 0, DBA_HIER_HEAD_STP hierHead = nullptr);
STATIC ID_T FIN_GetRealInstrIdForNIPPeriod(DBA_DYNFLD_STP extPos, ID_T instrIdParam = 0, DBA_HIER_HEAD_STP hierHead = nullptr);

extern bool EV_TracePerf; /*PMSTA-48195 - lalby - enable trace log*/
//extern bool EV_TracePtfAdjustM; /* WEALTH-6363 - Lalby - 13052024 */

/************************************************************************
**
**  Function    :   FIN_FlowInfoToStr()
**
**  Description :   Convert PosFlowInfo enum value to string for loging
**
**
**  Arguments   :
**
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   PMSTA-52459 - DDV - 230703
**
*************************************************************************/
char *FIN_FlowInfoToStr(PosFlowInfo flowInfo)
{
    switch (flowInfo)
    {
        case PosFlowInfo::Undefine:
            return("Undefine");
            break;

        case PosFlowInfo::ZeroPosition:
            return("ZeroPosition");
            break;

        case PosFlowInfo::Open:
            return("Open");
            break;

        case PosFlowInfo::Close:
            return("Close");
            break;

        case PosFlowInfo::ChangeSign:
            return("ChangeSign");
            break;

        case PosFlowInfo::ExistingPosition:
            return("ExistingPosition");
            break;
        default:
            return("Unknow");
            break;
    }
}

/************************************************************************
**
**  Function    :   FIN_FlowInfoToStr()
**
**  Description :   Convert PerfTimingRuleTimingRuleEn enum value to string for loging
**
**
**  Arguments   :
**
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   PMSTA-52459 - DDV - 230703
**
*************************************************************************/
char *FIN_TimingRuleToStr(PerfTimingRuleTimingRuleEn timingRule)
{
    switch (timingRule)
    {
        case PerfTimingRuleTimingRuleEn::BeginningOfTheDay:
            return("BeginningOfTheDay");
            break;

        case PerfTimingRuleTimingRuleEn::EndOfTheDay:
            return("EndOfTheDay");
            break;

        case PerfTimingRuleTimingRuleEn::Undefine:
            return("Undefine");
            break;

        default:
            return("Unknow");
            break;
    }
}

/************************************************************************
**
**  Function    :   FIN_LogFlowInfoMismatch()
**
**  Description :   Add message in log file is case of flow_info_e mismatch
**
**
**  Arguments   :
**
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   PMSTA-52459 - DDV - 230703
**
*************************************************************************/
void FIN_LogFlowInfoMismatch(DBA_DYNFLD_STP extPos, PosFlowInfo simulFlowInfo)
{
    STRING1000_T msg;
    std::string        table;

    table[0] = END_OF_STRING;

    if (IS_NULLFLD(extPos, ExtPos_BalPosTpId))
    {
        table = "position";
    }
    else
    {
        table = "balance position";
    }
    
    sprintf(msg, "Mismatch of flow_info_e for %s having id %" szFormatId " (open_oper_code=%s). flow_info_e set by fusion is %s and simulation expect %s", table.c_str(), GET_ID(extPos, ExtPos_PosObjId), GET_CODE(extPos, ExtPos_OpenOpCd),
            FIN_FlowInfoToStr(static_cast <PosFlowInfo> GET_ENUM(extPos, ExtPos_FlowInfoEn)), FIN_FlowInfoToStr(simulFlowInfo));

    MSG_LogMesg(RET_GEN_ERR_PERSONAL_WARN, 1, FILEINFO, msg); /* WEALTH-2637 - DDV - 231017 - Change error to warning */

}

/************************************************************************
**
**  Function    :   FIN_LogFlowInfoMissing()
**
**  Description :   Add message in log file when flow_info_e is missing
**
**
**  Arguments   :
**
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   PMSTA-52459 - DDV - 230703
**
*************************************************************************/
void FIN_LogFlowInfoMissing(DBA_DYNFLD_STP extPos, PosFlowInfo simulFlowInfo)
{
    STRING1000_T msg;
    std::string        table;

    table[0] = END_OF_STRING;

    if (IS_NULLFLD(extPos, ExtPos_BalPosTpId))
    {
        table = "position";
    }
    else
    {
        table = "balance position";
    }

    sprintf(msg, "Missing flow_info_e for %s having id %" szFormatId " (open_oper_code=%s). Set flow_info_e with value %s", table.c_str(), GET_ID(extPos, ExtPos_PosObjId), GET_CODE(extPos, ExtPos_OpenOpCd), FIN_FlowInfoToStr(simulFlowInfo));

    MSG_LogMesg(RET_GEN_ERR_PERSONAL_WARN, 1, FILEINFO, msg); /* WEALTH-2637 - DDV - 231017 - Change error to warning */

}

/************************************************************************
**
**  Function    :   FIN_LogTimingRuleMissing()
**
**  Description :   Add message in log file when timing_rule is missing
**
**
**  Arguments   :
**
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   PMSTA-52459 - DDV - 230703
**
*************************************************************************/
void FIN_LogTimingRuleMissing(DBA_DYNFLD_STP extPos, PerfTimingRuleTimingRuleEn timingRule)
{
    STRING1000_T msg;
    std::string        table;

    table[0] = END_OF_STRING;

    if (IS_NULLFLD(extPos, ExtPos_BalPosTpId))
    {
        table = "position";
    }
    else
    {
        table = "balance position";
    }

    sprintf(msg, "Missing timing_rule for %s having id %" szFormatId " (open_oper_code=%s). Set timing_rule with value %s", table.c_str(), GET_ID(extPos, ExtPos_PosObjId), GET_CODE(extPos, ExtPos_OpenOpCd), FIN_TimingRuleToStr(timingRule));

    MSG_LogMesg(RET_GEN_ERR_PERSONAL_WARN, 1, FILEINFO, msg); /* WEALTH-2637 - DDV - 231017 - Change error to warning */
}

/************************************************************************
**
**  Function    :   FIN_IsInstrInNIPPeriod()
**
**  Description :   Check if at given date it is a NIP (Not Invested Period) for one insrument.
**
**
**  Arguments   :   
**                  
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   PMSTA-47578 - DDV - 220215
**
*************************************************************************/
bool FIN_IsInstrInNIPPeriod(const ID_T                  instrIdParam,
                            const DATETIME_T &          initialDate,
                            const DATETIME_T &          finalDate,
                            const PA_DATEINFO_ST &      paDateInfoStp,
                            PerfCalcResultPeriodNatEn & periodNatEn,
                            NUMBER_T &                  initialNotInvestedDaysNbr,
                            NUMBER_T &                  finalNotInvestedDaysNbr,
                            FLAG_T &                    intradayNIPFlg,
                            DBA_HIER_HEAD_STP           hierHead)
{
    int           nipIdx=0;
    NUMBER_T      notInvestedDay = 1.0;
    ID_T          instrId = instrIdParam;

    INVESTTIMINGRULE_ENUM investTimingRule;
    GEN_GetApplInfo(ApplRetInvestTimingRule, &investTimingRule);

    if (investTimingRule == InvestTimingRule_Mid)
    {
        notInvestedDay = 0.5;
    }

    intradayNIPFlg = FALSE;

    /* PMSTA-52459 - DDV - 230629 - If id belong to instr risk origin or have negative id, get real instrument id */
    instrId = FIN_GetRealInstrIdForNIPPeriod(NULLDYNST, instrId, hierHead);

    NUMBER_T nbOfDays = DATE_Diff(initialDate.date, finalDate.date, Day, AccrRule_SceActAct, ZERO_ID);

    while (nipIdx < paDateInfoStp.nipPeriodNbr &&
           paDateInfoStp.nipPeriodTab[nipIdx].instrId < instrId)
    {
        nipIdx++;
    }

    while (nipIdx < paDateInfoStp.nipPeriodNbr &&
        paDateInfoStp.nipPeriodTab[nipIdx].instrId == instrId &&
        paDateInfoStp.nipPeriodTab[nipIdx].endDate.date < initialDate.date)
    {
        nipIdx++;
    }

    if (nipIdx == paDateInfoStp.nipPeriodNbr ||
        paDateInfoStp.nipPeriodTab[nipIdx].instrId != instrId ||
        finalDate.date < paDateInfoStp.nipPeriodTab[nipIdx].beginDate.date)
    {
        /* Middle Of Invested Period */
        periodNatEn = PerfCalcResultPeriodNatEn::MiddleOfInvestedPeriod;
        return(false);
    }

    bool     bWasInvested = false, bIsInvested = false, bStillInvested = false;

    if (initialDate.date == paDateInfoStp.nipPeriodTab[nipIdx].endDate.date)
    {
        bWasInvested = true;

        nipIdx++;
        if (nipIdx == paDateInfoStp.nipPeriodNbr ||
            paDateInfoStp.nipPeriodTab[nipIdx].instrId != instrId ||
            finalDate.date < paDateInfoStp.nipPeriodTab[nipIdx].beginDate.date)
        {
            /* Middle Of Invested Period */
            periodNatEn = PerfCalcResultPeriodNatEn::MiddleOfInvestedPeriod;
            return(false);
        }
    }
    else if (initialDate.date < paDateInfoStp.nipPeriodTab[nipIdx].beginDate.date)
    {
        bWasInvested = true;
    }
    else
    {
        bWasInvested = false;
        if (notInvestedDay == 1.0)
        {
            if (finalDate.date == paDateInfoStp.nipPeriodTab[nipIdx].endDate.date &&
                paDateInfoStp.nipPeriodTab[nipIdx].endTimingRule == PerfTimingRuleTimingRuleEn::EndOfTheDay)
            {
                initialNotInvestedDaysNbr = notInvestedDay;
            }
        }
        else /* Middle of the Day */
        {
            if (finalDate.date == paDateInfoStp.nipPeriodTab[nipIdx].endDate.date)
            {
                initialNotInvestedDaysNbr = notInvestedDay;
            }
        }
    }

    bIsInvested = true;
    if (paDateInfoStp.nipPeriodTab[nipIdx].beginDate.date <= initialDate.date)
    {
        /* WEALTH-2954 - DDV - 240112 - Adapt algorithm for bIsInvested to manage special case on one day */
        if (nbOfDays > 1.0 && paDateInfoStp.nipPeriodTab[nipIdx].endDate.date >= finalDate.date)
        {
            bIsInvested = false;
        }

        if (nbOfDays == 1.0)
        {
            if (paDateInfoStp.nipPeriodTab[nipIdx].endDate.date > finalDate.date ||
                (paDateInfoStp.nipPeriodTab[nipIdx].endDate.date == finalDate.date && paDateInfoStp.nipPeriodTab[nipIdx].endTimingRule == PerfTimingRuleTimingRuleEn::EndOfTheDay))
            {
                bIsInvested = false;
            }
        }
    }

    /* WEALTH-6156 - DDV - 240405 - If NIP period finish before current period, go to next NIP */
    if (paDateInfoStp.nipPeriodTab[nipIdx].endDate.date <= finalDate.date &&
        nipIdx +1 < paDateInfoStp.nipPeriodNbr &&
        paDateInfoStp.nipPeriodTab[nipIdx +1].instrId == instrId &&
        finalDate.date <= paDateInfoStp.nipPeriodTab[nipIdx +1].beginDate.date)
    {
        nipIdx++;
    }

    bStillInvested = true;
    if (paDateInfoStp.nipPeriodTab[nipIdx].beginDate.date <= finalDate.date &&
        paDateInfoStp.nipPeriodTab[nipIdx].endDate.date > finalDate.date)
    {
        bStillInvested = false;
        if (notInvestedDay == 1.0)
        {
            if (finalDate.date == paDateInfoStp.nipPeriodTab[nipIdx].beginDate.date &&
                paDateInfoStp.nipPeriodTab[nipIdx].beginTimingRule == PerfTimingRuleTimingRuleEn::BeginningOfTheDay)
            {
                finalNotInvestedDaysNbr = notInvestedDay;
            }
        }
        else /* Middle of the Day */
        {
            if (finalDate.date == paDateInfoStp.nipPeriodTab[nipIdx].beginDate.date)
            {
                finalNotInvestedDaysNbr = notInvestedDay;
            }
        }
    }

    /* WEALTH-2954 - DDV - 231213 - Manage quick Invest */
    bool bQuickInvestBOD = false, bQuickInvestEOD = false;

    if (bIsInvested == false && nbOfDays == 1.0)
    {
        int  quickIdx = 0;

        while (quickIdx < paDateInfoStp.quickInvestNbr &&
            paDateInfoStp.quickInvestTab[quickIdx].instrId < instrId)
        {
            quickIdx++;
        }

        while (quickIdx < paDateInfoStp.quickInvestNbr &&
            paDateInfoStp.quickInvestTab[quickIdx].instrId == instrId &&
            paDateInfoStp.quickInvestTab[quickIdx].endDate.date < finalDate.date)
        {
            quickIdx++;
        }

        /* quick invest found for this day */
        if (quickIdx < paDateInfoStp.quickInvestNbr &&
            paDateInfoStp.quickInvestTab[quickIdx].instrId == instrId &&
            paDateInfoStp.quickInvestTab[quickIdx].endDate.date == finalDate.date)
        {
            if (paDateInfoStp.quickInvestTab[quickIdx].beginDate.date == initialDate.date)
            {
                bWasInvested = true;
            }
        }

        while (quickIdx < paDateInfoStp.quickInvestNbr &&
            paDateInfoStp.quickInvestTab[quickIdx].instrId == instrId &&
            paDateInfoStp.quickInvestTab[quickIdx].beginDate.date <= finalDate.date)
        {
            if (paDateInfoStp.quickInvestTab[quickIdx].beginDate.date == finalDate.date &&
                paDateInfoStp.quickInvestTab[quickIdx].endDate.date == finalDate.date)
            {
                if (paDateInfoStp.quickInvestTab[quickIdx].beginTimingRule == PerfTimingRuleTimingRuleEn::BeginningOfTheDay)
                {
                    bQuickInvestBOD = true;
                }
                else if (paDateInfoStp.quickInvestTab[quickIdx].beginTimingRule == PerfTimingRuleTimingRuleEn::EndOfTheDay)
                {
                    bQuickInvestEOD = true;
                }
            }
            else if (paDateInfoStp.quickInvestTab[quickIdx].beginDate.date == finalDate.date &&
                paDateInfoStp.quickInvestTab[quickIdx].endDate.date != finalDate.date)
            {
                bStillInvested = true;
            }

            quickIdx++;
        }

        /* WEALTH-2954 - DDV - 231213 - Add special cases for quick invest */
        if ((bWasInvested || bQuickInvestBOD) &&
            (bStillInvested || bQuickInvestEOD))
        {
            bIsInvested = true;
        }

        /* WEALTH-2954 - DDV - 231213 - Add special cases for quick invest */
        if (bWasInvested == false && bQuickInvestBOD == false && bIsInvested == false)
        {
            initialNotInvestedDaysNbr = notInvestedDay;
        }
        else if (bIsInvested == false && bQuickInvestEOD == false && bStillInvested == false)
        {
            finalNotInvestedDaysNbr = notInvestedDay;
        }

    }

    if (bWasInvested)
    {
        if (bStillInvested)
        {
            periodNatEn = PerfCalcResultPeriodNatEn::MiddleOfInvestedPeriod;
        }
        else
        {
            periodNatEn = PerfCalcResultPeriodNatEn::EndOfInvestedPeriod;
        }
    }
    else if (bQuickInvestBOD)
    {
        if (bStillInvested)
        {
            periodNatEn = PerfCalcResultPeriodNatEn::BeginOfInvestedPeriod;
        }
        else
        {
            periodNatEn = PerfCalcResultPeriodNatEn::IsOneInvestedPeriod;
        }
    }
    else
    {
        if (bStillInvested)
        {
            periodNatEn = PerfCalcResultPeriodNatEn::BeginOfInvestedPeriod;
        }
        else
        {
            /* WEALTH-2954 - DDV - 231213 - Add special cases for quick invest */
            /* WEALTH-6156 - DDV - 240405 - Add bIsInvested condition for OneInvestedPeriod */
            if (bQuickInvestEOD || bIsInvested)
            {
                periodNatEn = PerfCalcResultPeriodNatEn::IsOneInvestedPeriod;
            }
            else
            {
                periodNatEn = PerfCalcResultPeriodNatEn::NIPPeriod;
                initialNotInvestedDaysNbr = 0;
                finalNotInvestedDaysNbr = 0;
            }
        }
    }

    /* WEALTH-6156 - DDV - 240508 - Manage intraday NIP */
    if (nipIdx < paDateInfoStp.nipPeriodNbr && nbOfDays == 1.0 && periodNatEn != PerfCalcResultPeriodNatEn::NIPPeriod)
    {
        /* WEALTH-6156 - DDV - 240731 - If current NIP period is after final date, go back to previous NIP period */
        if (nipIdx > 0 && paDateInfoStp.nipPeriodTab[nipIdx].beginDate.date > finalDate.date &&
            paDateInfoStp.nipPeriodTab[nipIdx - 1].instrId == instrId)
        {
            --nipIdx;
        }

        if (paDateInfoStp.nipPeriodTab[nipIdx].beginDate.date == finalDate.date &&
            paDateInfoStp.nipPeriodTab[nipIdx].beginTimingRule == PerfTimingRuleTimingRuleEn::BeginningOfTheDay &&
            paDateInfoStp.nipPeriodTab[nipIdx].endDate.date == finalDate.date &&
            paDateInfoStp.nipPeriodTab[nipIdx].endTimingRule == PerfTimingRuleTimingRuleEn::EndOfTheDay)
        {
            intradayNIPFlg = TRUE;
        }

        if (periodNatEn == PerfCalcResultPeriodNatEn::IsOneInvestedPeriod &&
            (paDateInfoStp.nipPeriodTab[nipIdx].beginDate.date <= initialDate.date ||
             (paDateInfoStp.nipPeriodTab[nipIdx].beginDate.date == initialDate.date &&
              paDateInfoStp.nipPeriodTab[nipIdx].beginTimingRule == PerfTimingRuleTimingRuleEn::BeginningOfTheDay
             )
            ) &&
            (paDateInfoStp.nipPeriodTab[nipIdx].endDate.date >= finalDate.date ||
             (paDateInfoStp.nipPeriodTab[nipIdx].endDate.date == finalDate.date &&
              paDateInfoStp.nipPeriodTab[nipIdx].endTimingRule == PerfTimingRuleTimingRuleEn::EndOfTheDay
             )
            )
           )
        {
            intradayNIPFlg = TRUE;
        }
    }

    return (periodNatEn == PerfCalcResultPeriodNatEn::NIPPeriod);

}

/************************************************************************
**
**  Function    :   FIN_GetPeriodNatureString()
**
**  Description :   return Period nature string to Log
**
**
**  Arguments   :  PerfCalcResultPeriodNatEn
**
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   WEALTH-9420- Lalby - 20062024
**
*************************************************************************/
std::string FIN_GetPeriodNatureString(PerfCalcResultPeriodNatEn const &pNatureEn)
{
    switch (pNatureEn)
    {
        case PerfCalcResultPeriodNatEn::NIPPeriod: { return std::string("NIPPeriod"); break; }
        case PerfCalcResultPeriodNatEn::IsOneInvestedPeriod: { return std::string("IsOneInvestedPeriod"); break; }
        case PerfCalcResultPeriodNatEn::BeginOfInvestedPeriod: { return std::string("BeginOfInvestedPeriod"); break; }
        case PerfCalcResultPeriodNatEn::EndOfInvestedPeriod: { return std::string("EndOfInvestedPeriod"); break; }
        case PerfCalcResultPeriodNatEn::MiddleOfInvestedPeriod: { return std::string("MiddleOfInvestedPeriod"); break; }
        default: return std::string("None");
    }
}


/************************************************************************
**
**  Function    :   FIN_GetPADatePeriodNature()
**
**  Description :   Check if at given date it is a NIP (Not Invested Period) for portfolio
                    and identify the ptf period.
**
**
**  Arguments   :  Initail and final dates of ptf and pdateInfo.
**
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   PMSTA -52569- Lalby - 29092023- Manage Ptf in and out using PCP 
**
*************************************************************************/
PerfCalcResultPeriodNatEn FIN_GetPADatePeriodNature(const DATETIME_T& initialDate,
    const DATETIME_T& finalDate,
    const PA_DATEINFO_ST& paDateInfoStp)
{
    if (paDateInfoStp.ptfNipPeriodNbr == 0)
    {
        return(PerfCalcResultPeriodNatEn::MiddleOfInvestedPeriod);
    }

    int           idx = 0;

    INVESTTIMINGRULE_ENUM investTimingRule;
    GEN_GetApplInfo(ApplRetInvestTimingRule, &investTimingRule);

    while (idx < paDateInfoStp.ptfNipPeriodNbr &&
        paDateInfoStp.ptfNipPeriodTab[idx].endDate.date < initialDate.date)
    {
        idx++;
    }

    if (initialDate.date == finalDate.date)
    {
        if (paDateInfoStp.ptfNipPeriodTab[idx].beginDate.date <initialDate.date &&
            paDateInfoStp.ptfNipPeriodTab[idx].endDate.date >initialDate.date)
        {
            return(PerfCalcResultPeriodNatEn::NIPPeriod);
        }
        else
            return(PerfCalcResultPeriodNatEn::MiddleOfInvestedPeriod);
    }

    if (idx == paDateInfoStp.ptfNipPeriodNbr ||
        finalDate.date < paDateInfoStp.ptfNipPeriodTab[idx].beginDate.date)
    {
        /* Middle Of Invested Period */
        return(PerfCalcResultPeriodNatEn::MiddleOfInvestedPeriod);
    }

    bool     bWasInvested = false, bIsInvested = false, bStillInvested = false;

    if (initialDate.date == paDateInfoStp.ptfNipPeriodTab[idx].endDate.date)
    {
        bWasInvested = true;

        if (finalDate.date > paDateInfoStp.ptfNipPeriodTab[idx].beginDate.date)
        {
            /* Begin Invested Period */
            return(PerfCalcResultPeriodNatEn::BeginOfInvestedPeriod);
        }

        idx++;

        if (idx == paDateInfoStp.ptfNipPeriodNbr ||
            finalDate.date < paDateInfoStp.ptfNipPeriodTab[idx].beginDate.date)
        {
            /* Middle Of Invested Period */
            return(PerfCalcResultPeriodNatEn::MiddleOfInvestedPeriod);
        }

        if (idx == paDateInfoStp.ptfNipPeriodNbr ||
            finalDate.date < paDateInfoStp.ptfNipPeriodTab[idx].beginDate.date)
        {
            /* Middle Of Invested Period */
            return(PerfCalcResultPeriodNatEn::MiddleOfInvestedPeriod);
        }
    }
    else if (finalDate.date <= paDateInfoStp.ptfNipPeriodTab[idx].beginDate.date )
    {
        bWasInvested = true;
    }
    else
    {
        bWasInvested = false;
    }

    bIsInvested = true;
    if (paDateInfoStp.ptfNipPeriodTab[idx].beginDate.date <=initialDate.date &&
        paDateInfoStp.ptfNipPeriodTab[idx].endDate.date >= finalDate.date)
    {
        bIsInvested = false;
    }

    bStillInvested = true;
    if (paDateInfoStp.ptfNipPeriodTab[idx].beginDate.date <=finalDate.date &&
        paDateInfoStp.ptfNipPeriodTab[idx].endDate.date >= finalDate.date)
    {
        bStillInvested = false;
    }

    if (bWasInvested)
    {
        if (bIsInvested)
        {
            if (bStillInvested)
            {
                return(PerfCalcResultPeriodNatEn::MiddleOfInvestedPeriod);
            }
            else
            {
                return(PerfCalcResultPeriodNatEn::EndOfInvestedPeriod);
            }
        }
        else
        {
            if (bStillInvested)
            {
                return(PerfCalcResultPeriodNatEn::MiddleOfInvestedPeriod);
            }
            else
            {
                return(PerfCalcResultPeriodNatEn::EndOfInvestedPeriod);
            }
        }
    }
    else /* was not invested */
    {
        if (bIsInvested)
        {
            if (bStillInvested)
            {
                return(PerfCalcResultPeriodNatEn::BeginOfInvestedPeriod);
            }
            else
            {
                return(PerfCalcResultPeriodNatEn::IsOneInvestedPeriod);
            }
        }
        else
        {
            if (bStillInvested)
            {
                return(PerfCalcResultPeriodNatEn::BeginOfInvestedPeriod);
            }
            else
            {
                return(PerfCalcResultPeriodNatEn::NIPPeriod);
            }
        }
    }
}

/************************************************************************
**
**  Function    :   FIN_CmpPosPtfInstrDateNat()
**
**  Description :   Position table is sorted:
**                      - by portfolio id
**                      - by intrument id
**                      - by ascending position begin date.
**                      - by position nature
**
**  Arguments   :   ptr1   pointer on dynamic structure type ExtPos
**                  ptr2   pointer on dynamic structure type ExtPos
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Modif.      :   PMSTA-47578 - DDV - 220121
**
*************************************************************************/
STATIC int FIN_CmpPosPtfInstrDateNat(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    int cmp = 0;
    if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2), ExtPos_PtfId, ExtPos_PtfId, IdType)) != 0)
    {
        return(cmp);
    }

    ID_T instrId1 = FIN_GetRealInstrIdForFlowInfo(*ptr1);
    ID_T instrId2 = FIN_GetRealInstrIdForFlowInfo(*ptr2);

    if (instrId1 != instrId2)
    {
        return(instrId1 > instrId2 ? 1 : -1);
    }

    if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2), ExtPos_BegDate, ExtPos_BegDate, DateType)) != 0)
    {
        return(cmp);
    }

    if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2), ExtPos_TimingRuleEn, ExtPos_TimingRuleEn, EnumType)) != 0)
    {
        return(cmp);
    }

    if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2), ExtPos_OpenOpCd, ExtPos_OpenOpCd, CodeType)) != 0)
    {
        return(cmp);
    }

    /* WEALTH-6792 - DDV - 240405 - Add pos_nat_e as sorting criteria to have open before existing pos */
    if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2), ExtPos_PosNatEn, ExtPos_PosNatEn, EnumType)) != 0)
    {
        return cmp;
    }

    /* PMSTA-62581 - Deepthi - 20250122 - 
        Added quantity condition to sort the positions corrected in Linux */
    if (GET_NUMBER(*ptr1, ExtPos_Qty) != 0)
    {
        return 0;
    }
    else
    {
        return 1;
    }
}

/************************************************************************
**
**  Function    :   FIN_SetExtPosTimingRule()
**
**  Description :   Temporary function used to simulate what fusion will do to set ExtPos_TimingRuleEn.
**
**
**  Arguments   :   
**                  
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   PMSTA-47578 - DDV - 220215
**
*************************************************************************/
STATIC RET_CODE FIN_SetExtPosTimingRule(const DBA_DYNFLD_STP     extPosStp,
                                         DBA_HIER_HEAD_STP        hierHead)
{
    PerfTimingRuleTimingRuleEn perfTimingRule = PerfTimingRuleTimingRuleEn::EndOfTheDay;

    if (IS_NULLFLD(extPosStp, ExtPos_TimingRuleEn) == TRUE || 
        static_cast <PerfTimingRuleTimingRuleEn> GET_ENUM(extPosStp, ExtPos_TimingRuleEn) == PerfTimingRuleTimingRuleEn::Undefine)
    {
        SET_ENUM(extPosStp, ExtPos_TimingRuleEn, perfTimingRule);

        if (FIN_IsPerfTimingRuleSet(hierHead, extPosStp, perfTimingRule))
        {
            SET_ENUM(extPosStp, ExtPos_TimingRuleEn, perfTimingRule);
        }
        FIN_LogTimingRuleMissing(extPosStp, perfTimingRule);
    }

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_AddNIPPeriod()
**
**  Description :   Add a new NIP period in paDateInfo.
**
**
**  Arguments   :
**
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   PMSTA-47578 - DDV - 220215
**
*************************************************************************/
STATIC RET_CODE FIN_AddNIPPeriod(const DBA_DYNFLD_STP        extPosStp,
                                 DATETIME                    beginDate,
                                 PerfTimingRuleTimingRuleEn  beginTimingRule,
                                 DATETIME                    endDate,
                                 PerfTimingRuleTimingRuleEn  endTimingRule,
                                 PA_DATEINFO_STP             paDateInfoStp)
{

    if ((paDateInfoStp->nipPeriodTab = (NIP_PERIOD_STP)REALLOC(paDateInfoStp->nipPeriodTab, (paDateInfoStp->nipPeriodNbr + 1) * sizeof(NIP_PERIOD_ST))) == nullptr)
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    NIP_PERIOD_STP   newNIPPeriod = &(paDateInfoStp->nipPeriodTab[paDateInfoStp->nipPeriodNbr++]);

    newNIPPeriod->instrId = FIN_GetRealInstrIdForFlowInfo(extPosStp);
    newNIPPeriod->beginDate = beginDate;
    newNIPPeriod->beginTimingRule = beginTimingRule;
    newNIPPeriod->endDate = endDate;
    newNIPPeriod->endTimingRule = endTimingRule;

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_AddQuickInvest()
**
**  Description :   Add a new quick invest in paDateInfo.
**
**
**  Arguments   :
**
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   WEALTH-2954 - DDV - 231213
**
*************************************************************************/
STATIC RET_CODE FIN_AddQuickInvest(const DBA_DYNFLD_STP        extPosStp,
                                   DATETIME                    beginDate,
                                   PerfTimingRuleTimingRuleEn  beginTimingRule,
                                   DATETIME                    endDate,
                                   PerfTimingRuleTimingRuleEn  endTimingRule,
                                   PA_DATEINFO_STP             paDateInfoStp)
{

    if ((paDateInfoStp->quickInvestTab = (NIP_PERIOD_STP)REALLOC(paDateInfoStp->quickInvestTab, (paDateInfoStp->quickInvestNbr + 1) * sizeof(NIP_PERIOD_ST))) == nullptr)
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    NIP_PERIOD_STP   newQuickInvest = &(paDateInfoStp->quickInvestTab[paDateInfoStp->quickInvestNbr++]);

    newQuickInvest->instrId = FIN_GetRealInstrIdForFlowInfo(extPosStp);
    newQuickInvest->beginDate = beginDate;
    newQuickInvest->beginTimingRule = beginTimingRule;
    newQuickInvest->endDate = endDate;
    newQuickInvest->endTimingRule = endTimingRule;

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_CreateInstrNIPPeriod()
**
**  Description :   Analyse all NIP event for one instrument 
**                  and build NIP periods for this instrument (stored in PA_DATEINFO_ST).
**
**
**  Arguments   :
**
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   PMSTA-47578 - DDV - 220215
**
*************************************************************************/
STATIC RET_CODE FIN_CreateInstrNIPPeriod(DBA_DYNFLD_STP              domainStp,
                                         const DBA_DYNFLD_STP        extPosStp,
                                         PosFlowInfo                 firstInstrPosFlowInfoEn,
                                         std::vector<NIP_EVENT_ST> & vInstrNIPEvent,
                                         PA_DATEINFO_STP             paDateInfoStp)
{ 
    DATETIME                    beginDate;
    PerfTimingRuleTimingRuleEn  beginTimingRule = PerfTimingRuleTimingRuleEn::BeginningOfTheDay;

    bool                        isInNIPFlg = firstInstrPosFlowInfoEn == PosFlowInfo::ZeroPosition;

    if (isInNIPFlg)
    {
        beginDate = GET_DATETIME(domainStp, A_Domain_InterpFromDate);
    }
    else
    {
        beginDate.date = 0;
        beginDate.time = 0;
    }

    /* check if everything is correct */
    DATETIME                    prevEventDate;
    PosFlowInfo                 flowInfoEn = PosFlowInfo::Undefine;
    bool                        wasInNIPFlg = isInNIPFlg;
    int                         openErrorNbr = 0, closeErrorNbr = 0;

    std::vector<DATETIME_T>     vDateInError;

    std::vector<NIP_EVENT_ST>::iterator eventIter = vInstrNIPEvent.begin();

    while (eventIter < vInstrNIPEvent.end())
    {
        prevEventDate = (*eventIter).date;
        wasInNIPFlg = isInNIPFlg;

        while (eventIter < vInstrNIPEvent.end() &&
               prevEventDate.date == (*eventIter).date.date)
        {
            if ((*eventIter).posFlowInfoEn == PosFlowInfo::Close)
            {
                if (isInNIPFlg)
                {
                    closeErrorNbr++;
                }
                else
                {
                    isInNIPFlg = true;
                }
            }
            else if ((*eventIter).posFlowInfoEn == PosFlowInfo::Open)
            {
                if (!isInNIPFlg)
                {
                    openErrorNbr++;
                }
                else
                {
                    isInNIPFlg = false;
                }
            }

            eventIter++;
        }

        /* when all is fine continue */
        if (openErrorNbr == 0 && closeErrorNbr == 0)
        {
            continue;
        }
        
        flowInfoEn = PosFlowInfo::Undefine;

        /* If diff is bigger than 1, impossible to know when NIP occurs.
           Also when flow is not in phase with NIP period, impossible to set NIP => exit */
        int diff = closeErrorNbr - openErrorNbr; 
        if (abs(diff) > 1.0 ||            /* too many errors */
            wasInNIPFlg && diff > 0 ||    /* Close accours in NIP period, impossible */
            !wasInNIPFlg && diff < 0)     /* Open when is was not NIP period, impossible */
        {
            return(RET_FIN_ERR_INVDATA);
        }

        /* Add date in Error vector */
        vDateInError.push_back(prevEventDate);

        if (diff != 0)
        {
            isInNIPFlg = !wasInNIPFlg;
        }
    }

    /* Date(s) in error, change event for days in error to push all events at End Of the Day */
    eventIter = vInstrNIPEvent.begin();

    for (auto dateInErrorIter = vDateInError.begin(); dateInErrorIter < vDateInError.end(); dateInErrorIter++)
    {
        while (eventIter < vInstrNIPEvent.end() && (*eventIter).date.date < (*dateInErrorIter).date)
        {
            eventIter++;
        }

        while (eventIter < vInstrNIPEvent.end() && (*eventIter).date.date == (*dateInErrorIter).date)
        {
            (*eventIter).timingRuleEn = PerfTimingRuleTimingRuleEn::EndOfTheDay;
            eventIter++;
        }
    }

    PerfTimingRuleTimingRuleEn  prevTimingRule;

    isInNIPFlg = firstInstrPosFlowInfoEn == PosFlowInfo::ZeroPosition;
    wasInNIPFlg = isInNIPFlg;
    eventIter = vInstrNIPEvent.begin();
    bool investFlg;

    int openNbr = 0, closeNbr = 0;
    while (eventIter < vInstrNIPEvent.end())
    {
        prevEventDate = (*eventIter).date;
        prevTimingRule = (*eventIter).timingRuleEn;
        wasInNIPFlg=isInNIPFlg;
        investFlg = false;
        openNbr = 0, closeNbr = 0;

        while (eventIter < vInstrNIPEvent.end() &&
               (*eventIter).date.date  == prevEventDate.date &&
               (*eventIter).timingRuleEn == prevTimingRule)
        {
            if ((*eventIter).posFlowInfoEn == PosFlowInfo::Close)
            {
                closeNbr++;
            }
            else if ((*eventIter).posFlowInfoEn == PosFlowInfo::Open)
            {
                investFlg = true;
                openNbr++;
            }
            eventIter++;
        }

        if (closeNbr != openNbr)
        {
            isInNIPFlg = !wasInNIPFlg;
        }

        /* WEALTH-2954 - DDV - 231213 - Create quick invest record for current day and timing rule */
        if (wasInNIPFlg && isInNIPFlg && investFlg)
        {
            FIN_AddQuickInvest(extPosStp, prevEventDate, prevTimingRule, prevEventDate, prevTimingRule, paDateInfoStp);
            investFlg = false;
        }

        /* At end of the day, consume events occuring at the beginning of the next Day */
        if (prevTimingRule == PerfTimingRuleTimingRuleEn::EndOfTheDay)
        {
            DATETIME_T   tmpDate;
            bool     wasBODInNIPFlg = isInNIPFlg;

            tmpDate.date = DATE_Move(prevEventDate.date, +1, Day);
            tmpDate.time = 0;

            openNbr = 0, closeNbr = 0;

            while (eventIter < vInstrNIPEvent.end() &&
                   (*eventIter).date.date == tmpDate.date &&
                   (*eventIter).timingRuleEn == PerfTimingRuleTimingRuleEn::BeginningOfTheDay)
            {
                if ((*eventIter).posFlowInfoEn == PosFlowInfo::Close)
                {
                    closeNbr++;
                }
                else if ((*eventIter).posFlowInfoEn == PosFlowInfo::Open)
                {
                    investFlg = true;
                    openNbr++;
                }
                eventIter++;
            }

            if (closeNbr != openNbr)
            {
                isInNIPFlg = !wasBODInNIPFlg;
            }

            /* WEALTH-2954 - DDV - 231213 - Create quick invest record from End Of previous Day till Begining Of current Day */
            if (wasInNIPFlg && isInNIPFlg && !wasBODInNIPFlg && investFlg)
            {
                FIN_AddQuickInvest(extPosStp, prevEventDate, PerfTimingRuleTimingRuleEn::EndOfTheDay, tmpDate, PerfTimingRuleTimingRuleEn::BeginningOfTheDay, paDateInfoStp);
            }

            /* WEALTH-2954 - DDV - 231213 - Create quick invest record for current day BOD */
            if (wasBODInNIPFlg && isInNIPFlg && investFlg)
            {
                FIN_AddQuickInvest(extPosStp, tmpDate, PerfTimingRuleTimingRuleEn::BeginningOfTheDay, tmpDate, PerfTimingRuleTimingRuleEn::BeginningOfTheDay, paDateInfoStp);
            }
        }

        /* Close current NIP Period if no more in NIP */
        if (wasInNIPFlg && !isInNIPFlg)
        {
            FIN_AddNIPPeriod(extPosStp, beginDate, beginTimingRule, prevEventDate, prevTimingRule, paDateInfoStp);
        }
    
        /* Open a new NIP Period if was not in NIP */
        if (!wasInNIPFlg && isInNIPFlg)
        {
            beginDate = prevEventDate;
            beginTimingRule = prevTimingRule;
        }
    }

    /* If NIP period is started, close it at domain's till date */
    if (isInNIPFlg)
    {
        DATETIME    endDate;
        endDate.date = MAGIC_END_DATE;
        endDate.time = 0;

        FIN_AddNIPPeriod(extPosStp, beginDate, beginTimingRule, endDate, PerfTimingRuleTimingRuleEn::EndOfTheDay, paDateInfoStp);
    }

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_FilterPtfCurrentList
**  Description :   filter Extpos having same listseqno
**  Argument    :
**  Return      :
**  Creation    :   PMSTA-48195 -Performance IPS Level -Lalby-180722
**  Last modif. :
**
*************************************************************************/

STATIC int FIN_FilterPtfCurrentList(DBA_DYNFLD_STP dynSt,
    DBA_DYNST_ENUM dynStTp,
    DBA_DYNFLD_STP ptfPtr)
{
    DBA_DYNFLD_STP extPtf;
    if ((GET_EXTENSION_PTR(dynSt, ExtPos_A_Ptf_Ext)) != NULL &&
        ((extPtf = *(GET_EXTENSION_PTR(dynSt, ExtPos_A_Ptf_Ext))) != NULLDYNST))
    {
        if (GET_SMALLINT(extPtf, A_Ptf_ListSeqNo) == GET_SMALLINT(ptfPtr, A_Ptf_ListSeqNo))
        {
            return TRUE;
        }
    }
 
    return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_CheckForInstrChrono
**  Description :   filter Extpos having same listseqno
**  Argument    :
**  Return      :
**  Creation    :   PMSTA-61314 - Perfomance Calcuation for Accrued Interest in NIP 
**  Last modif. :
**
*************************************************************************/
static bool FIN_CheckForInstrChrono(DBA_HIER_HEAD_STP      synthHierHead,
                                    const DBA_DYNFLD_STP   extPosStp)
{
    bool ret = false;
    MemoryPool mp;

    if (extPosStp != NULLDYNST &&
        IS_NULLFLD(extPosStp, ExtPos_A_Instr_Ext) == FALSE &&
        GET_EXTENSION_PTR(extPosStp, ExtPos_A_Instr_Ext) != NULL)
    {
        DBA_DYNFLD_STP instrStp = *GET_EXTENSION_PTR(extPosStp, ExtPos_A_Instr_Ext);

        /*instrument should be ptf cash account with some accruval record*/
        if ((IS_NOTNULL(instrStp, A_Instr_PtfId) == TRUE) &&
            InstrNatEn::CashAccount == GET_A_Instr_NatEn(instrStp) &&
            GET_FLAG(instrStp, A_Instr_AccrIntInstrChronoFlg) == TRUE)
        {
            DBA_DYNFLD_STP argInp = mp.allocDynst(FILEINFO, Chrono_Arg);

            SET_DATETIME(argInp, Chrono_Arg_BegDate, GET_DATETIME(extPosStp, ExtPos_BegDate));
            SET_DATETIME(argInp, Chrono_Arg_EndDate, GET_DATETIME(extPosStp, ExtPos_EndDate));

            SET_ID(argInp, Chrono_Arg_InstrId, GET_ID(extPosStp,ExtPos_InstrId));

            DBA_DYNFLD_STP * instrChronoTab = NULL;
            int              chronoNbr = 0;

            /*check if any interest chrono exist for the time period*/
            DBA_Select2(InstrChrono, UNUSED, Chrono_Arg, argInp,
                S_InstrChrono, &instrChronoTab, UNUSED, UNUSED,
                &chronoNbr, UNUSED, UNUSED);

            FREE(instrChronoTab);

            if (chronoNbr > 0)
            {
                ret = true;
            }
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :   FIN_CheckNonZeroPosForNIP
**  Description :   Non-zero instrument positions should not be added in NIP
**  Argument    :
**  Return      :
**  Creation    :   PMSTA-61926 - Mean Capital correction at instrument level
**  Last modif. :   PMSTA-65503 - Instrument mean cap displayed as Zero
**
*************************************************************************/
static bool FIN_CheckNonZeroPosForNIP(DBA_HIER_HEAD_STP   synthHierHead,
                                            const DBA_DYNFLD_STP    inExtPosStp)
{
    bool ret = false;
    DBA_DYNFLD_STP* extPosTab = NULLDYNSTPTR;
    int              extPosNbr = 0;

    /* PMSTA-65503 - Condition to check for particular zero quantity open positions - Deepthi */
    if (PosPrimary_Derived == GET_ENUM(inExtPosStp, ExtPos_PrimaryEn)
        && (PosFlowInfo::Open == static_cast <PosFlowInfo> GET_ENUM(inExtPosStp, ExtPos_FlowInfoEn)
            || PosFlowInfo::ExistingPosition == static_cast <PosFlowInfo> GET_ENUM(inExtPosStp, ExtPos_FlowInfoEn)
            || PosFlowInfo::ChangeSign == static_cast <PosFlowInfo> GET_ENUM(inExtPosStp, ExtPos_FlowInfoEn))
            && PosNat_None == GET_ENUM(inExtPosStp, ExtPos_PosNatEn))
    {
        if (DBA_ExtractHierEltRec(synthHierHead, ExtPos, FALSE,
            NULLFCT, NULLFCT, &extPosNbr, &extPosTab) != RET_SUCCEED || extPosNbr == 0)
        {
            ret = false;
        }

        for (int extpos = 0; extpos < extPosNbr; extpos++)
        {
            /* PMSTA-65503 - Checks if non-zero positions available for the same portfolio-instrument combo.
                             If so, do not add into NIP period - Deepthi */
            if (CMP_DYNFLD(extPosTab[extpos], inExtPosStp, ExtPos_PtfId, ExtPos_PtfId, IdType) == 0
                && CMP_DYNFLD(extPosTab[extpos], inExtPosStp, ExtPos_InstrId, ExtPos_InstrId, IdType) == 0
                && CMP_NUMBER(GET_NUMBER(extPosTab[extpos], ExtPos_Qty), ZERO_NUMBER) != 0)
            {
                ret = true;
                break;
            }
        }

    }

    FREE(extPosTab);

    return ret;
}

/************************************************************************
**
**  Function    :   FIN_CheckNIPExceptionCases
**  Description :   Check NIP Exception Conditions
**  Argument    :
**  Return      :
**  Creation    :   PMSTA-61314 - Perfomance Calcuation for Accrued Interest in NIP
**  Last modif. :   PMSTA-61926 - Mean Capital correction at instrument level
**
*************************************************************************/
static bool FIN_CheckNIPExceptionCases(DBA_HIER_HEAD_STP      synthHierHead,
    const DBA_DYNFLD_STP   extPosStp)
{
    bool ret = false;

    /*Case 1 check if any instrument chrono available for the instrument 
     if available then accrued interest will be calculated later*/
    ret = FIN_CheckForInstrChrono(synthHierHead,extPosStp);

    if (!ret)
    {
        /* PMSTA-62581 - Deepthi - 20250122 - 
        Case 2 - Check if there is any non-zero position available for the instrument
                 with Adjustment deposit nature as P&L or Position Update. 
                 If available, set the PosFlowInfo to Existing position */
        ret = FIN_CheckNonZeroPosForNIP(synthHierHead, extPosStp);
    }

    return ret;
}


/************************************************************************
**
**  Function    :   FIN_AddNIPDates()
**
**  Description :   add PA-dates of Not Ivested Period and update the mask of PA_DATETIME_ST
**
**  Arguments   :   domainPtr           domain structure pointer
**                  synthHierHead       position hierarchy header pointer
**                  ptfPtr              portfolio pointer
**                  paInfoStp           perf attrib info (portfolio, strat, dates, mask)
**                  crystalDates        crystal dates to set using pa dates
**                  crystalNbr          crystal dates number
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   PMSTA-47578 - DDV - 220121
**  Modification
**
*************************************************************************/
RET_CODE    FIN_AddNIPDates(DBA_DYNFLD_STP          domainPtr,
                            DBA_HIER_HEAD_STP       synthHierHead,
                            DBA_DYNFLD_STP          ptfPtr,
                            PA_DATEINFO_STP         paDateInfoStp,
                            DATETIME_ST**           crystalDates,
                            int*                    crystalNbr,
                            bool                    bRecomputeFlowInfo)
{
    RET_CODE         ret = RET_SUCCEED;
    PA_DATETIME_ST   newPADate;               /* REF7395 - CSY - 020409 */
    DBA_DYNFLD_STP  *extPosTab = NULLDYNSTPTR;
    int              extPosNbr = 0, i = 0;
    NUMBER_T         qty;
    ID_T             ptfId=0, instrId=0;
    MemoryPool       mp;

    memset(&newPADate, 0, sizeof(PA_DATETIME_ST));  /* REF7395 - CSY - 020409 */

    /*PMSTA-38195 - Lalby- Extrct Extpos of same list id*/
    if (static_cast<LOADHIERPTF_ENUM> GET_ENUM(domainPtr, A_Domain_LoadHierFlg) == LoadHierPtf_IntermediateHierarchy)
    {
        /*Get positions of same portfolios of a list element */
        if (ptfPtr != NULLDYNST)
        {
            if ((ret = DBA_ExtractHierEltRecWithFilterSt(synthHierHead, ExtPos, FALSE,
                FIN_FilterPtfCurrentList, ptfPtr,
                FIN_CmpPosPtfInstrDateNat,
                &extPosNbr, &extPosTab)) != RET_SUCCEED || extPosNbr == 0 )
            {
                return(ret);
            }
        }
    }
    else
    {
        if ((ret = DBA_ExtractHierEltRec(synthHierHead, ExtPos,
            FALSE, NULLFCT,
            FIN_CmpPosPtfInstrDateNat,
            &extPosNbr, &extPosTab)) != RET_SUCCEED || extPosNbr == 0)
        {
            return(ret);
        }
    }
    mp.owner(static_cast<void*>(extPosTab));

    /* Simulate setting of flow_info_e and timing rule */
    i = 0;
    while(i < extPosNbr)
    {
        ptfId = GET_ID(extPosTab[i], ExtPos_PtfId);
        instrId = FIN_GetRealInstrIdForFlowInfo(extPosTab[i]);
        qty = 0.0;

        while(i<extPosNbr && 
              GET_ID(extPosTab[i], ExtPos_PtfId) == ptfId &&
              FIN_GetRealInstrIdForFlowInfo(extPosTab[i]) == instrId && 
              CMP_DYNFLD(extPosTab[i], domainPtr, ExtPos_BegDate, A_Domain_InterpFromDate, DateType) <= 0)
        {
            if (IS_NULLFLD(extPosTab[i], ExtPos_FlowInfoEn) == TRUE ||
                static_cast <PosFlowInfo> GET_ENUM(extPosTab[i], ExtPos_FlowInfoEn) == PosFlowInfo::Undefine ||
                bRecomputeFlowInfo)
            {
                if (IS_NULLFLD(extPosTab[i], ExtPos_FlowInfoEn) == TRUE ||
                    static_cast <PosFlowInfo> GET_ENUM(extPosTab[i], ExtPos_FlowInfoEn) == PosFlowInfo::Undefine)
                {
                    FIN_LogFlowInfoMissing(extPosTab[i], PosFlowInfo::ExistingPosition);
                }
                SET_ENUM(extPosTab[i], ExtPos_FlowInfoEn, PosFlowInfo::ExistingPosition);
            }

            qty += GET_NUMBER(extPosTab[i], ExtPos_Qty);
            FIN_SetExtPosTimingRule(extPosTab[i], synthHierHead);
            i++;
        }

        while (i < extPosNbr &&
            GET_ID(extPosTab[i], ExtPos_PtfId) == ptfId &&
            FIN_GetRealInstrIdForFlowInfo(extPosTab[i]) == instrId)
        {

            bool bFlowInfoSet = false;

            if (GET_ENUM(extPosTab[i], ExtPos_PrimaryEn) == PosPrimary_Primary &&
                IS_NULLFLD(extPosTab[i], ExtPos_BalPosTpId))
            {
                if (CMP_NUMBER(GET_NUMBER(extPosTab[i], ExtPos_Qty), 0.0) != 0)
                {
                    bool bOpen = false;

                    if (CMP_NUMBER(qty, 0.0) == 0)
                    {
                        bOpen = true;
                        if (IS_NULLFLD(extPosTab[i], ExtPos_FlowInfoEn) == TRUE ||
                            static_cast <PosFlowInfo> GET_ENUM(extPosTab[i], ExtPos_FlowInfoEn) == PosFlowInfo::Undefine ||
                            bRecomputeFlowInfo)
                        {
                            if (IS_NULLFLD(extPosTab[i], ExtPos_FlowInfoEn) == TRUE ||
                                static_cast <PosFlowInfo> GET_ENUM(extPosTab[i], ExtPos_FlowInfoEn) == PosFlowInfo::Undefine)
                            {
                                FIN_LogFlowInfoMissing(extPosTab[i], PosFlowInfo::Open);
                            }
                            SET_ENUM(extPosTab[i], ExtPos_FlowInfoEn, PosFlowInfo::Open);
                            bFlowInfoSet = true;;
                        }
                        else if (static_cast <PosFlowInfo> GET_ENUM(extPosTab[i], ExtPos_FlowInfoEn) != PosFlowInfo::Open)
                        {
                            FIN_LogFlowInfoMismatch(extPosTab[i], PosFlowInfo::Open);
                            SYS_BreakOnDebug(); /* flow_info_e is not the same than simulated one. Analyze to understand why */
                        }
                    }

                    bool bQtyWasPositive = qty > 0.0; /* WEALTH-3197 - DDV - 240111 - Manage Change sign case */

                    qty += GET_NUMBER(extPosTab[i], ExtPos_Qty);

                    bool bQtyIsPositive = qty > 0.0; /* WEALTH-3197 - DDV - 240111 - Manage Change sign case */

                    if (CMP_NUMBER(qty, 0.0) == 0)
                    {
                        if (IS_NULLFLD(extPosTab[i], ExtPos_FlowInfoEn) == TRUE ||
                            static_cast <PosFlowInfo> GET_ENUM(extPosTab[i], ExtPos_FlowInfoEn) == PosFlowInfo::Undefine ||
                            bRecomputeFlowInfo)
                        {
                            if (IS_NULLFLD(extPosTab[i], ExtPos_FlowInfoEn) == TRUE ||
                                static_cast <PosFlowInfo> GET_ENUM(extPosTab[i], ExtPos_FlowInfoEn) == PosFlowInfo::Undefine)
                            {
                                FIN_LogFlowInfoMissing(extPosTab[i], PosFlowInfo::Close);
                            }
                            SET_ENUM(extPosTab[i], ExtPos_FlowInfoEn, PosFlowInfo::Close);
                            bFlowInfoSet = true;;
                        }
                        else if (static_cast <PosFlowInfo> GET_ENUM(extPosTab[i], ExtPos_FlowInfoEn) != PosFlowInfo::Close)
                        {
                            FIN_LogFlowInfoMismatch(extPosTab[i], PosFlowInfo::Close);
                            SYS_BreakOnDebug(); /* flow_info_e is not the same than simulated one. Analyze to understand why */
                        }
                    }
                    else if (bOpen == false) /* WEALTH-2637 - DDV - 231017 - Add message for mismatch of existing pos */
                    {
                        if (IS_NULLFLD(extPosTab[i], ExtPos_FlowInfoEn) == TRUE ||
                            static_cast <PosFlowInfo> GET_ENUM(extPosTab[i], ExtPos_FlowInfoEn) == PosFlowInfo::Undefine ||
                            bRecomputeFlowInfo)
                        {
                            /* WEALTH-3197 - DDV - 240111 - Manage Change sign case */
                            if (bQtyWasPositive == bQtyIsPositive)
                            {
                                if (IS_NULLFLD(extPosTab[i], ExtPos_FlowInfoEn) == TRUE ||
                                    static_cast <PosFlowInfo> GET_ENUM(extPosTab[i], ExtPos_FlowInfoEn) == PosFlowInfo::Undefine)
                                {
                                    FIN_LogFlowInfoMissing(extPosTab[i], PosFlowInfo::ExistingPosition);
                                }
                                SET_ENUM(extPosTab[i], ExtPos_FlowInfoEn, PosFlowInfo::ExistingPosition);
                                bFlowInfoSet = true;
                            }
                            else
                            {
                                if (IS_NULLFLD(extPosTab[i], ExtPos_FlowInfoEn) == TRUE ||
                                    static_cast <PosFlowInfo> GET_ENUM(extPosTab[i], ExtPos_FlowInfoEn) == PosFlowInfo::Undefine)
                                {
                                    FIN_LogFlowInfoMissing(extPosTab[i], PosFlowInfo::ChangeSign);
                                }
                                SET_ENUM(extPosTab[i], ExtPos_FlowInfoEn, PosFlowInfo::ChangeSign);
                                bFlowInfoSet = true;
                            }
                        }
                        else if (bQtyWasPositive == bQtyIsPositive)
                        {
                            if (static_cast <PosFlowInfo> GET_ENUM(extPosTab[i], ExtPos_FlowInfoEn) != PosFlowInfo::ExistingPosition)
                            {
                                FIN_LogFlowInfoMismatch(extPosTab[i], PosFlowInfo::ExistingPosition);
                                SYS_BreakOnDebug(); /* flow_info_e is not the same than simulated one. Analyze to understand why */
                            }
                        }
                        else
                        {
                            if (static_cast <PosFlowInfo> GET_ENUM(extPosTab[i], ExtPos_FlowInfoEn) != PosFlowInfo::ChangeSign)
                            {
                                FIN_LogFlowInfoMismatch(extPosTab[i], PosFlowInfo::ChangeSign);
                                SYS_BreakOnDebug(); /* flow_info_e is not the same than simulated one. Analyze to understand why */
                            }
                        }
                    }
                }
                else
                {
                    if (CMP_NUMBER(qty, 0.0) == 0)
                    {
                        if (IS_NULLFLD(extPosTab[i], ExtPos_FlowInfoEn) == TRUE ||
                            static_cast <PosFlowInfo> GET_ENUM(extPosTab[i], ExtPos_FlowInfoEn) == PosFlowInfo::Undefine ||
                            bRecomputeFlowInfo)
                        {
                            if (IS_NULLFLD(extPosTab[i], ExtPos_FlowInfoEn) == TRUE ||
                                static_cast <PosFlowInfo> GET_ENUM(extPosTab[i], ExtPos_FlowInfoEn) == PosFlowInfo::Undefine)
                            {
                                FIN_LogFlowInfoMissing(extPosTab[i], PosFlowInfo::ZeroPosition);
                            }
                            SET_ENUM(extPosTab[i], ExtPos_FlowInfoEn, PosFlowInfo::ZeroPosition);
                            bFlowInfoSet = true;;
                        }
                        else if (static_cast <PosFlowInfo> GET_ENUM(extPosTab[i], ExtPos_FlowInfoEn) != PosFlowInfo::ZeroPosition)
                        {
                            FIN_LogFlowInfoMismatch(extPosTab[i], PosFlowInfo::ZeroPosition);
                            SYS_BreakOnDebug(); /* flow_info_e is not the same than simulated one. Analyze to understand why */
                        }
                    }
                    else  /* WEALTH-2637 - DDV - 231017 - Add message for mismatch of existing pos */
                    {
                        if (IS_NULLFLD(extPosTab[i], ExtPos_FlowInfoEn) == TRUE ||
                            static_cast <PosFlowInfo> GET_ENUM(extPosTab[i], ExtPos_FlowInfoEn) == PosFlowInfo::Undefine ||
                            bRecomputeFlowInfo)
                        {
                            if (IS_NULLFLD(extPosTab[i], ExtPos_FlowInfoEn) == TRUE ||
                                static_cast <PosFlowInfo> GET_ENUM(extPosTab[i], ExtPos_FlowInfoEn) == PosFlowInfo::Undefine)
                            {
                                FIN_LogFlowInfoMissing(extPosTab[i], PosFlowInfo::ExistingPosition);
                            }
                            SET_ENUM(extPosTab[i], ExtPos_FlowInfoEn, PosFlowInfo::ExistingPosition);
                            bFlowInfoSet = true;;
                        }
                        else if (static_cast <PosFlowInfo> GET_ENUM(extPosTab[i], ExtPos_FlowInfoEn) != PosFlowInfo::ExistingPosition)
                        {
                            FIN_LogFlowInfoMismatch(extPosTab[i], PosFlowInfo::ExistingPosition);
                            SYS_BreakOnDebug(); /* flow_info_e is not the same than simulated one. Analyze to understand why */
                        }
                    }
                }
            }

            if (IS_NULLFLD(extPosTab[i], ExtPos_FlowInfoEn) == TRUE ||
                static_cast <PosFlowInfo> GET_ENUM(extPosTab[i], ExtPos_FlowInfoEn) == PosFlowInfo::Undefine ||
                (bRecomputeFlowInfo && !bFlowInfoSet))
            {
                SET_ENUM(extPosTab[i], ExtPos_FlowInfoEn, PosFlowInfo::ExistingPosition);
            }

            FIN_SetExtPosTimingRule(extPosTab[i], synthHierHead);
            i++;
        }
    }

    instrId = 0;
    ptfId = GET_ID(extPosTab[0], ExtPos_PtfId);

    PosFlowInfo               firstInstrPosFlowInfoEn = PosFlowInfo::Undefine;
    NIP_EVENT_ST              newNIPEvent;
    std::vector<NIP_EVENT_ST> vInstrNIPEvent;

    for (i = 0; i < extPosNbr; i++)
    {
        /* WEALTH-2089 - DDV - 231023 - Add portfolio as break criteria */
        if (FIN_GetRealInstrIdForFlowInfo(extPosTab[i]) != instrId ||
            GET_ID(extPosTab[i], ExtPos_PtfId) != ptfId)
        {
            if (i>0)
            {
                /* WEALTH-2089 - DDV - 231023 - Create NIP periods only for current portfolio */
                if (ptfId == GET_ID(ptfPtr, A_Ptf_Id))
                {
                    FIN_CreateInstrNIPPeriod(domainPtr, extPosTab[i - 1], firstInstrPosFlowInfoEn, vInstrNIPEvent, paDateInfoStp);
                }

                vInstrNIPEvent.clear();
            }

            if (CMP_DYNFLD(extPosTab[i], domainPtr, ExtPos_BegDate, A_Domain_InterpFromDate, DateType) <= 0)
            {   
                if (GET_ENUM(extPosTab[i], ExtPos_PrimaryEn) == PosPrimary_Primary)
                {
                    firstInstrPosFlowInfoEn = static_cast <PosFlowInfo> GET_ENUM(extPosTab[i], ExtPos_FlowInfoEn);
                }
                else
                {
                    if (CMP_NUMBER(GET_NUMBER(extPosTab[i], ExtPos_Qty), 0.0) == 0)
                    {

                        if (!(FIN_CheckNIPExceptionCases(synthHierHead, extPosTab[i])))
                        {

                            firstInstrPosFlowInfoEn = PosFlowInfo::ZeroPosition;
                        }
                        else
                        {
                            firstInstrPosFlowInfoEn = PosFlowInfo::ExistingPosition;
                        }
                    }
                    else
                    {
                        firstInstrPosFlowInfoEn = PosFlowInfo::ExistingPosition;
                    }
                }
            }
            else
            {
                firstInstrPosFlowInfoEn = PosFlowInfo::ZeroPosition;
            }

            instrId = FIN_GetRealInstrIdForFlowInfo(extPosTab[i]);
            ptfId = GET_ID(extPosTab[i], ExtPos_PtfId);
        }
        
        if (GET_ENUM(extPosTab[i], ExtPos_PrimaryEn) == PosPrimary_Primary && IS_NULLFLD(extPosTab[i], ExtPos_BalPosTpId) &&
            CMP_DYNFLD(extPosTab[i], domainPtr, ExtPos_BegDate, A_Domain_InterpFromDate, DateType) > 0 &&
            (static_cast <PosFlowInfo> GET_ENUM(extPosTab[i], ExtPos_FlowInfoEn) == PosFlowInfo::Close ||
             static_cast <PosFlowInfo> GET_ENUM(extPosTab[i], ExtPos_FlowInfoEn) == PosFlowInfo::Open))
        {
            /* Add NIP date */
            SET_BIT(newPADate.level, SynthLevel_InstrNIP, TRUE);

            /* add date before flow date */
            if (CMP_DYNFLD(extPosTab[i], domainPtr, ExtPos_BegDate, A_Domain_InterpFromDate, DateType) > 0)
            {
                newPADate.dateTime.date = DATE_Move((GET_DATETIME(extPosTab[i], ExtPos_BegDate)).date, -1, Day);
                FIN_AddPADate(domainPtr, &newPADate, &(paDateInfoStp->paDates), &(paDateInfoStp->paDatesNbr));
                if (EV_TracePerf) 
                {
                    MSG_LogSrvMesg(UNUSED, 0, "NIP Date added %1  instrId %2",
                        DateType, newPADate.dateTime.date,
                        IdType, GET_ID(extPosTab[i], ExtPos_InstrId));
                }
            }

            /* add date at flow date */
            newPADate.dateTime = GET_DATETIME(extPosTab[i], ExtPos_BegDate);
            FIN_AddPADate(domainPtr, &newPADate, &(paDateInfoStp->paDates), &(paDateInfoStp->paDatesNbr));

            if (EV_TracePerf) {
                MSG_LogSrvMesg(UNUSED, 0, "NIP Date added %1  instrId %2",
                    DateType, newPADate.dateTime.date,
                    IdType, GET_ID(extPosTab[i], ExtPos_InstrId));
            }

            /* Add event in vector */
            newNIPEvent.date = newPADate.dateTime;
            newNIPEvent.timingRuleEn = static_cast <PerfTimingRuleTimingRuleEn> GET_ENUM(extPosTab[i], ExtPos_TimingRuleEn);
            newNIPEvent.posFlowInfoEn = static_cast <PosFlowInfo> GET_ENUM(extPosTab[i], ExtPos_FlowInfoEn);
            vInstrNIPEvent.push_back(newNIPEvent);
        }
    }

    /* WEALTH-2089 - DDV - 231023 - Create NIP periods only for current portfolio */
    if (ptfId == GET_ID(ptfPtr, A_Ptf_Id))
    {
        FIN_CreateInstrNIPPeriod(domainPtr, extPosTab[i - 1], firstInstrPosFlowInfoEn, vInstrNIPEvent, paDateInfoStp);
    }

    /* set new crystal nbr */
    *crystalNbr = paDateInfoStp->paDatesNbr;

    /* set crystal dates with PA dates */
    if (*crystalNbr > 0)
    {
        if ((*crystalDates = (DATETIME_ST*)REALLOC(*crystalDates,
            (*crystalNbr) * sizeof(DATETIME_ST))) == (DATETIME_ST*)NULL)
        {
            FREE(crystalDates);
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        for (i = 0; i < (*crystalNbr); i++)
        {
            (*crystalDates)[i] = paDateInfoStp->paDates[i].dateTime;
        }
    }

    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_AddPtfNIPDates()
**
**  Description :  Identifying the NIP within the crystal date range and capturing these at paDateInfoStp
**
**  Arguments   :   domainPtr
**                  synthHierHead
**                  ptfPtr
**                  paDateInfoStp, crystalDate, crystalNbr
**
**  Return      :   RET_CODE
**
**  Creation    :   PMSTA48803 - HLA - 06022023
**  Modif       :   WEALTH-7550 - JBC - 20240502
**
*************************************************************************/
RET_CODE FIN_AddPtfNIPDates(DBA_DYNFLD_STP domainPtr,
	DBA_HIER_HEAD_STP    synthHierHead,
	DBA_DYNFLD_STP       ptfPtr,
	PA_DATEINFO_STP      paDateInfoStp,
	DATETIME_T           **crystalDate,
	int                  *crystalNbr)
{
	RET_CODE		ret = RET_SUCCEED;

    DatePeriodVec compPeriods;
    ret = FIN_GetPtfCompPeriods(domainPtr,synthHierHead,ptfPtr, GET_DATETIME(domainPtr,A_Domain_InterpFromDate),
                                GET_DATETIME(domainPtr,A_Domain_InterpTillDate),compPeriods);

	if (ret != RET_SUCCEED && ret != RET_DBA_INFO_NODATA)
	{
		return ret;
	}

	if ((ret = FIN_AddPtfNIPPeriod(domainPtr, paDateInfoStp, crystalDate, crystalNbr,compPeriods)) != RET_SUCCEED)
	{
		return ret;
	}

	if (paDateInfoStp->ptfNipPeriodNbr > 0)
	{
		ret = FIN_MergePtfNIPCrystalDates(paDateInfoStp, crystalDate, crystalNbr);
	}
	return (ret);
}

/************************************************************************
**
**  Function    :   FIN_MergeNipDatesToCrystalDates()
**
**  Description :
**
**  Arguments   :   nipDatesPtr    Containing the NIP dates
**                  crystalDates   pointer to crystalDates
**
**  Return      :   RET_CODE
**
**  Creation    :   PMSTA48803 - HLA - 06022023
**
*************************************************************************/
STATIC RET_CODE FIN_MergePtfNIPCrystalDates(PA_DATEINFO_STP paDateInfoStp, DATETIME_T **crystalDate, int *crystalNbr)
{
	RET_CODE ret = RET_SUCCEED;

	*crystalDate = (DATETIME_T *)REALLOC(*crystalDate,
						(*crystalNbr + 2 * paDateInfoStp->ptfNipPeriodNbr) * sizeof(DATETIME_T));

	if ((crystalDate) == nullptr)
	{
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	for (int i = paDateInfoStp->ptfNipPeriodNbr - 1; i >= 0; i--)
	{
		if (!FIN_NipDateAlreadyExists((*crystalDate), *crystalNbr, paDateInfoStp->ptfNipPeriodTab[i].endDate))
		{
			ret = FIN_AddNipDateToCrystalTab(crystalDate, crystalNbr, paDateInfoStp->ptfNipPeriodTab[i].endDate);
		}

		if (!FIN_NipDateAlreadyExists((*crystalDate), *crystalNbr, paDateInfoStp->ptfNipPeriodTab[i].beginDate))
		{
			ret = FIN_AddNipDateToCrystalTab(crystalDate, crystalNbr, paDateInfoStp->ptfNipPeriodTab[i].beginDate);
		}
	}
	return ret;
}

/************************************************************************
**
**  Function    :   FIN_AddPtfNIPPeriod()
**
**  Description :   Function to create NIP array for the portfolio.
**
**
**  Arguments   :
**
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   PMSTA48803 - HLA - 0602202
**
**  Modif       : WEALTH-7550 - JBC - 20240502
**
*************************************************************************/
STATIC RET_CODE FIN_AddPtfNIPPeriod(DBA_DYNFLD_STP          domainPtr,     /* WEALTH-4688 - DDV - 240229 */
                                    PA_DATEINFO_STP         paDateInfoStp,
									DATETIME_T            **crystalDate, 
                                    int                    *crystalNbr,
									DatePeriodVec &         compPeriods)
{
    RET_CODE         ret = RET_SUCCEED;
    PA_DATETIME_ST   newPADate;

    if ((paDateInfoStp->ptfNipPeriodTab = (NIP_PERIOD_STP)CALLOC(compPeriods.size()+1, sizeof(NIP_PERIOD_ST))) == nullptr)
	{
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	paDateInfoStp->ptfNipPeriodNbr = 0;

    // no data - all NIP
    if(compPeriods.empty())
    {
        paDateInfoStp->ptfNipPeriodTab[paDateInfoStp->ptfNipPeriodNbr].instrId = ZERO_ID;
		paDateInfoStp->ptfNipPeriodTab[paDateInfoStp->ptfNipPeriodNbr].beginDate = (*crystalDate)[0];
		paDateInfoStp->ptfNipPeriodTab[paDateInfoStp->ptfNipPeriodNbr].endDate = (*crystalDate)[*crystalNbr-1];
		paDateInfoStp->ptfNipPeriodNbr++;
        return ret;
    }

    // begin boundary check
	if (((*crystalDate)[0]).date < compPeriods[0].getBegin().date)
	{
		paDateInfoStp->ptfNipPeriodTab[paDateInfoStp->ptfNipPeriodNbr].instrId = ZERO_ID;
		paDateInfoStp->ptfNipPeriodTab[paDateInfoStp->ptfNipPeriodNbr].beginDate = (*crystalDate)[0];
		paDateInfoStp->ptfNipPeriodTab[paDateInfoStp->ptfNipPeriodNbr].endDate = compPeriods[0].getBegin();
		paDateInfoStp->ptfNipPeriodNbr++;
	}

    // compPeriod set is ordered and always valid, all gaps are NIPs
	for (size_t i = 0; i < compPeriods.size()-1; i++)
	{    	
	    paDateInfoStp->ptfNipPeriodTab[paDateInfoStp->ptfNipPeriodNbr].instrId = ZERO_ID;
		paDateInfoStp->ptfNipPeriodTab[paDateInfoStp->ptfNipPeriodNbr].beginDate = compPeriods[i].getEnd();
		paDateInfoStp->ptfNipPeriodTab[paDateInfoStp->ptfNipPeriodNbr].endDate = compPeriods[i+1].getBegin();
		paDateInfoStp->ptfNipPeriodNbr++;
	}
    
    // end boundary check
	if (((*crystalDate)[*crystalNbr - 1]).date > compPeriods[compPeriods.size()-1].getEnd().date)
	{
		paDateInfoStp->ptfNipPeriodTab[paDateInfoStp->ptfNipPeriodNbr].instrId = ZERO_ID;
		paDateInfoStp->ptfNipPeriodTab[paDateInfoStp->ptfNipPeriodNbr].beginDate = compPeriods[compPeriods.size()-1].getEnd();
		paDateInfoStp->ptfNipPeriodTab[paDateInfoStp->ptfNipPeriodNbr].endDate = (*crystalDate)[*crystalNbr-1];
		paDateInfoStp->ptfNipPeriodNbr++;
	}

	/* PMSTA48803 - 07052023 - HLA Setting the NIP level for the portfolio */
	memset(&newPADate, 0, sizeof(PA_DATETIME_ST));
	SET_BIT(newPADate.level, SynthLevel_PtfNIP, TRUE);

	for (int i = 0; i < paDateInfoStp->ptfNipPeriodNbr; i++)
	{
		newPADate.dateTime.date = paDateInfoStp->ptfNipPeriodTab[i].beginDate.date;
		FIN_AddPADate(domainPtr, &newPADate, &(paDateInfoStp->paDates), &(paDateInfoStp->paDatesNbr));

		newPADate.dateTime.date = paDateInfoStp->ptfNipPeriodTab[i].endDate.date;
		FIN_AddPADate(domainPtr, &newPADate, &(paDateInfoStp->paDates), &(paDateInfoStp->paDatesNbr));
	}

	return(ret);
}
/************************************************************************
**
**  Function    :   FIN_NipDateAlreadyExists()
**
**  Description :
**
**  Arguments   :   nipDatesPtr       Containing the NIP dates
**                  givenDate         NIP date
**
**  Return      :   bool
**
**  Creation    :   PMSTA48803 - HLA - 06022023
**
*************************************************************************/
STATIC bool FIN_NipDateAlreadyExists(DATETIME_T *crystalDate,
	int &storageFreqNbr,
	DATETIME_T &givenDate)
{
	for (int i = 0; i < storageFreqNbr; i++)
	{
		if (DATETIME_CMP(crystalDate[i],givenDate)==0) {
			return true;
		}
	}
	return false;
}

/************************************************************************
**
**  Function    :   FIN_AddNipDateToCrystalTab()
**
**  Description :
**
**  Arguments   :   nipDatesPtr       Containing the NIP dates
**                  givenDate         NIP date
**
**  Return      :   bool
**
**  Creation    :   PMSTA48803 - HLA - 06022023
**
*************************************************************************/
STATIC RET_CODE FIN_AddNipDateToCrystalTab(DATETIME_T **crystalDate, int *crystalNbr,
																DATETIME_T &givenDate)
{
	RET_CODE ret = RET_SUCCEED;
	int j = 0;
	int nipIndex = 0;

	for (j = *crystalNbr - 1; j >= 0; j--) /* Assuming detection of NIP will be within frequency dates index */
	{
		if ((*crystalDate)[j] < givenDate)
		{
			nipIndex = j + 1;
			break;
		}
		else
		{
			continue;
		}
	}
	for (j = *crystalNbr - 1; j >= nipIndex; j--)
	{
		(*crystalDate)[j + 1] = (*crystalDate)[j];
	}
	(*crystalDate)[nipIndex] = givenDate;
	(*crystalNbr)++;

	return ret;
}

/************************************************************************
**
**  Function    :   FIN_GetRealInstrIdForFlowInfo()
**
**  Description :
**
**  Arguments   :   extPos            position for which the real instrument id must be returned
**
**  Return      :   bool
**
**  Creation    :   DDV - 230620
**
*************************************************************************/
STATIC ID_T FIN_GetRealInstrIdForFlowInfo(DBA_DYNFLD_STP    extPos,
                                          ID_T              instrIdParam,
                                          DBA_HIER_HEAD_STP hierHead)
{
    ID_T                instrId = instrIdParam;
    DBA_DYNFLD_STP      instrPtr = NULLDYNST;

    if (extPos != NULLDYNST)
    {
        instrId = GET_ID(extPos, ExtPos_InstrId);


        if (GET_EXTENSION_PTR(extPos, ExtPos_A_Instr_Ext) != NULL)
        {
            instrPtr = *(GET_EXTENSION_PTR(extPos, ExtPos_A_Instr_Ext));
        }
    }
    
    if (instrPtr == NULLDYNST && instrIdParam != 0 && hierHead != nullptr)
    {
        DBA_GetRecPtrFromHierById(hierHead, instrId, A_Instr, &instrPtr);
    }

    if (instrPtr != NULLDYNST)
    {
        if (instrId < 0 || 
            IS_NULLFLD(instrPtr, A_Instr_RiskOrigInstrId) == FALSE) /* PMSTA-54517 - DDV - 230927 - When computing flow_info_e, risk origin must position must be treated as cash */
        {
            instrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
        }
    }

    return(instrId);
}

/************************************************************************
**
**  Function    :   FIN_GetRealInstrIdForNIPPeriod()
**
**  Description :
**
**  Arguments   :   extPos            position for which the real instrument id must be returned
**
**  Return      :   bool
**
**  Creation    :   DDV - 230620
**
*************************************************************************/
STATIC ID_T FIN_GetRealInstrIdForNIPPeriod(DBA_DYNFLD_STP    extPos,
                                           ID_T              instrIdParam,
                                           DBA_HIER_HEAD_STP hierHead)
{
    ID_T                instrId = instrIdParam;
    DBA_DYNFLD_STP      instrPtr = NULLDYNST;

    if (extPos != NULLDYNST)
    {
        instrId = GET_ID(extPos, ExtPos_InstrId);


        if (GET_EXTENSION_PTR(extPos, ExtPos_A_Instr_Ext) != NULL)
        {
            instrPtr = *(GET_EXTENSION_PTR(extPos, ExtPos_A_Instr_Ext));
        }
    }
    
    if (instrPtr == NULLDYNST && instrIdParam != 0 && hierHead != nullptr)
    {
        DBA_GetRecPtrFromHierById(hierHead, instrId, A_Instr, &instrPtr);
    }

    if (instrPtr != NULLDYNST)
    {
        if (instrId < 0)
        {
            instrId = GET_ID(instrPtr, A_Instr_ParentInstrId);
        }
        else if (IS_NULLFLD(instrPtr, A_Instr_RiskOrigInstrId) == FALSE) /* PMSTA-54517 - DDV - 230927 - When searching NIP period, risk origin must position must be treated as forward */
        {
            instrId = GET_ID(instrPtr, A_Instr_RiskOrigInstrId);
        }
    }

    return(instrId);
}

/************************************************************************
**      END  finperfnip.c
*************************************************************************/

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef DDLGEN_H
#define DDLGEN_H

#include "dba.h"
#include "ddlgencfgfile.h"
#include "ddlgendbi.h"

/************************************************************************
**      Constant & Macro definitions
*************************************************************************/
#define DDLGEN_NO_ALPHA " \t=().,@\n;'+-!/<>*|"
#define DDLGEN_NUMERIC  "0123456789"

/************************************************************************
**      Structures & typedef definitions
*************************************************************************/

class DdlGenFullTable;
class DdlGenFromFile;
class DdlGenFromFileContext;
class DdlGenRequestHelper;
class DdlGenDbaAccess;

/************************************************************************
**      External definitions attached to : ddlgen01.c
*************************************************************************/

/* PMSTA-14086 - LJE - 121012 */
typedef struct DDL_CONTEXT
{
    DDL_CONTEXT()
        : bCheckOnly(false)
        , bCheck(false)
        , bSqlFileOnly(false)
        , bExtractData(false)
        , infoPtr(nullptr)
        , objPtr(nullptr)
        , inputPtr(nullptr)
        , optionPtr(nullptr)
    {

    };

    bool	bCheckOnly;
    bool    bCheck;
    bool    bSqlFileOnly;
    bool    bExtractData;
    char *  infoPtr;
    char *  objPtr;
    char *  inputPtr;
    char *  optionPtr;
} DDL_CONTEXT_ST, *DDL_CONTEXT_STP;

extern DDL_CONTEXT_ST EV_GenDdlContext;

#define DDL_OPTIM_READ_ONLY_CONN_BIT 0
#define DDL_OPTIM_LIGHT_COMPILE_BIT 1

typedef enum {
    DdlObjFromFile_View,
    DdlObjFromFile_SProc,
    DdlObjFromFile_Trigger,
    DdlObjFromFile_Custom,
    DdlObjFromFile_Sql,
    DdlObjFromFile_SystemView,
    DdlObjFromFile_UtilsView
} DDL_OBJ_FROM_FILE_ENUM;

typedef enum
{
    SelList_Select,
    SelList_SelectDistinct,
    SelList_List,
    SelList_SelectCall,
    SelList_SelectInVar,
    SelList_SelectVar,
    SelList_Call,
    SelList_Insert,
    SelList_InsertCall,
    SelList_InsertSelect,
    SelList_InsertSelectDistinct,
    SelList_SelectCursor,
    SelList_SelectDistinctCursor,
    SelList_ForSelect,             /* PMSTA-nuodb - LJE - 190809 */
    SelList_ForSelectDistinct,     /* PMSTA-nuodb - LJE - 190809 */
    SelList_Assign,
    SelList_Update,
    SelList_InsertFull,
    SelList_InsertFullCall
} SEL_LIST_ENUM;

typedef enum
{
    DDlJoinType_None,
    DDlJoinType_TSqlJoin,
    DDlJoinType_InnerJoin,
    DDlJoinType_LeftOuterJoin,
    DDlJoinType_RightOuterJoin,
    DDlJoinType_LogicalFkJoin
} DDL_JOIN_TYPE_ENUM;

typedef enum
{
    MultiEntityLevel_None,
    MultiEntityLevel_NoActive,
    MultiEntityLevel_Active
} MULTI_ENTITY_LEVEL_ENUM;

typedef enum
{
    DdlBuildMode_Standard,
    DdlBuildMode_Admin,
    DdlBuildMode_ViewOnly
} DDL_BUILD_MODE_ENUM;

typedef enum
{
    DdlGenCaller_Unknown,
    DdlGenCaller_DdlGenerator,
    DdlGenCaller_Sql
} DDL_GEN_CALLER_ENUM;

typedef enum
{
    MultiEntityAccess_None,
    MultiEntityAccess_OptionalLocalization,
    MultiEntityAccess_PartialSpecialization

} MULTI_ENTITY_ACCESS_ENUM;

class DdlGenSqlBlock
{
public:

    // Constructors
    DdlGenSqlBlock()
    {
    }

    DdlGenSqlBlock(const DdlGenSqlBlock &ref)
        : DdlGenSqlBlock()
    {
        *this << ref;
    }

    // Destructor
    virtual ~DdlGenSqlBlock()
    {
    }

    // Methods
    DdlGenSqlBlock &operator=(const DdlGenSqlBlock&) = delete;

    DdlGenSqlBlock &operator<<(const DdlGenSqlBlock& ref)
    {
        this->m_buffer.clear();

        this->m_prepareStream << ref.m_prepareStream.str();
        this->m_declareStream << ref.m_declareStream.str();
        this->m_initStream << ref.m_initStream.str();
        this->m_bodyStream << ref.m_bodyStream.str();
        this->m_releaseStream << ref.m_releaseStream.str();

        for (auto it = ref.m_varDeclarePrintedSet.begin(); it != ref.m_varDeclarePrintedSet.end(); ++it)
        {
            this->m_varDeclarePrintedSet.insert(*it);
        }
        return *this;
    }
    DdlGenSqlBlock &operator=(const std::string& newStr)
    {
        this->clear();

        this->m_bodyStream << newStr;
        return *this;
    }
    DdlGenSqlBlock &operator<<(const std::string& ref)
    {
        this->m_buffer.clear();

        if (this->m_indentOffestStr.empty())
        {
            this->m_bodyStream << ref;
        }
        else
        {
            std::string       lineStr;
            std::stringstream refStream(ref);

            while (getline(refStream, lineStr))
            {
                this->m_bodyStream << this->m_indentOffestStr << lineStr << std::endl;
            }
        }
        return *this;
    }
    DdlGenSqlBlock &operator<<(const char *ref)
    {
        this->m_buffer.clear();

        this->m_bodyStream << ref;
        return *this;
    }
    DdlGenSqlBlock &operator <<(std::ostream& (*os)(std::ostream&))
    {
        this->m_buffer.clear();

        this->m_bodyStream << os;
        return *this;
    }
    DdlGenSqlBlock &operator<<(DICT_T ref)
    {
        this->m_buffer.clear();

        this->m_bodyStream << ref;
        return *this;
    }

    void clear()
    {
        this->m_buffer.clear();
        this->m_prepareStream.clear();
        this->m_prepareStream.str(std::string());
        this->m_declareStream.clear();
        this->m_declareStream.str(std::string());
        this->m_initStream.clear();
        this->m_initStream.str(std::string());
        this->m_releaseStream.clear();
        this->m_releaseStream.str(std::string());
        this->m_bodyStream.clear();
        this->m_bodyStream.str(std::string());
        this->m_varDeclarePrintedSet.clear();
        this->m_indentOffestStr.clear();
    }

    const std::string &str()
    {
        if (this->m_buffer.empty())
        {
            this->m_buffer = 
                this->m_prepareStream.str() + 
                this->m_declareStream.str() +
                this->m_initStream.str() + 
                this->m_bodyStream.str() + 
                this->m_releaseStream.str();
        }

        return this->m_buffer;
    }

    std::stringstream& prepareStream()
    {
        this->m_buffer.clear();
        return this->m_prepareStream;
    }

    std::stringstream &declareStream()
    {
        this->m_buffer.clear();
        return this->m_declareStream;
    }

    std::stringstream &initStream()
    {
        this->m_buffer.clear();
        return this->m_initStream;
    }

    std::stringstream& bodyStream()
    {
        this->m_buffer.clear();
        return this->m_bodyStream;
    }

    std::stringstream &releaseStream()
    {
        this->m_buffer.clear();
        return this->m_releaseStream;
    }

    bool empty();
    void setIndentOffset(const std::string &indentOffestStr)
    {
        this->m_indentOffestStr = indentOffestStr;
    }
    void setIndentOffsetNbr(int indentOffestNbr)
    {
        this->m_indentOffestStr.clear();
        for (int i = 0; i < indentOffestNbr; i++)
        {
            this->m_indentOffestStr.append("\t");
        }
    }

    // Members
    std::set<std::string>   m_varDeclarePrintedSet;

private:
    std::stringstream       m_prepareStream;
    std::stringstream       m_declareStream;
    std::stringstream       m_initStream;
    std::stringstream       m_releaseStream;
    std::stringstream       m_bodyStream;
    std::string             m_buffer;
    std::string             m_indentOffestStr;
};

class DdlGenAction : public AAAObject
{
public:
    // Constructors
    DdlGenAction()
        : m_mainDdlObjNatEn(DbObjDdlObjNat_None)
        , m_ddlObjNatEn(DbObjDdlObjNat_None)
        , m_execModeEn(DbObjExecMod_DBBuildWFiles)
        , m_buildRuleEn(DdlGenBuildRule_None)
        , m_bInitEntityOnly(false)
        , m_bSystemFuncOnly(false)
        , m_logLevel(99)
        , m_bSingleEntity(false)
        , m_fromImport(false)
        , m_subRequest(false)
        , m_bOraCreateIdxHint(false)
        , m_bOraNologgingHint(false)
        , m_useMemoryOptizedTempTable(false)
        , m_multiThreadSize(1)
        , m_parallelLoad(0)
        , m_installLevel(0)
        , m_bRestrictUpdate(false)
        , m_bUseNativeQuery(false)
        , m_bExtractData(false)
        , m_srcDictEntityStp(nullptr)
        , m_searchShXdEntityStp(nullptr)
        , m_backupDdlGenActionPtr(nullptr)
        , m_refDdlGenActionPtr(nullptr)
    {
        {
            extern int EV_AAAInstallLevel;      /* Only here ! */
            this->m_installLevel = EV_AAAInstallLevel;
        }
    }

    DdlGenAction(DBA_DYNFLD_STP ddlGenActionStp)
        : DdlGenAction()
    {
        if (IS_NULLFLD(ddlGenActionStp, A_DdlgenAction_EntitySqlName) == FALSE)
        {
            this->m_entitySqlnameStr = GET_SYSNAME(ddlGenActionStp, A_DdlgenAction_EntitySqlName);
        }

        if (IS_NULLFLD(ddlGenActionStp, A_DdlgenAction_TargetSqlName) == FALSE)
        {
            this->m_targetSqlnameStr      = GET_SYSNAME(ddlGenActionStp, A_DdlgenAction_TargetSqlName);
            this->m_shortTargetSqlnameStr = this->m_targetSqlnameStr;
        }

        if (IS_NULLFLD(ddlGenActionStp, A_DdlgenAction_SqlNameOpt) == FALSE)
        {
            this->m_sqlnameOptStr = GET_SYSNAME(ddlGenActionStp, A_DdlgenAction_SqlNameOpt);
        }

        this->m_ddlObjNatEn           = (DBOBJDDLOBJNAT_ENUM)GET_ENUM(ddlGenActionStp, A_DdlgenAction_DdlObjNatEn);
        this->m_mainDdlObjNatEn       = this->m_ddlObjNatEn;
        this->m_execModeEn            = (DBOBJEXECMOD_ENUM)GET_ENUM(ddlGenActionStp, A_DdlgenAction_ExecModeEn);
        this->m_buildRuleEn           = (DDLGEN_BUILD_RULE_ENUM)GET_ENUM(ddlGenActionStp, A_DdlgenAction_BuildRuleEn);
        this->m_paramEntitySqlnameStr = this->m_entitySqlnameStr;

        // this->m_logLevel         = GET_INT(ddlGenActionStp, A_DdlgenAction_LogLevel);
    }

    DdlGenAction(DdlGenAction &ref, bool bBackup)
        : DdlGenAction()
    {
        if (bBackup)
        {
            this->m_backupDdlGenActionPtr = new DdlGenAction(ref, false);
            this->m_mp.ownerObject(this->m_backupDdlGenActionPtr);
            this->m_refDdlGenActionPtr = &ref;
        }
        *this = ref;
    }

    // Destructor
    virtual ~DdlGenAction()
    {
        if (this->m_backupDdlGenActionPtr != nullptr &&
            this->m_refDdlGenActionPtr != nullptr)
        {
            *this->m_refDdlGenActionPtr = *this->m_backupDdlGenActionPtr;
        }
    }

    DdlGenAction& operator=(const DdlGenAction &ref)
    {
        this->m_entitySqlnameStr             = ref.m_entitySqlnameStr;
        this->m_targetSqlnameStr             = ref.m_targetSqlnameStr;
        this->m_shortTargetSqlnameStr        = ref.m_shortTargetSqlnameStr;
        this->m_sqlnameOptStr                = ref.m_sqlnameOptStr;
        this->m_paramEntitySqlnameStr        = ref.m_paramEntitySqlnameStr;
        this->m_ddlObjNatEn                  = ref.m_ddlObjNatEn;
        this->m_mainDdlObjNatEn              = ref.m_mainDdlObjNatEn;
        this->m_execModeEn                   = ref.m_execModeEn;
        this->m_buildRuleEn                  = ref.m_buildRuleEn;
        this->m_bInitEntityOnly              = ref.m_bInitEntityOnly;
        this->m_bSystemFuncOnly              = ref.m_bSystemFuncOnly;
        this->m_logLevel                     = ref.m_logLevel;
        this->m_bSingleEntity                = ref.m_bSingleEntity;
        this->m_fromImport                   = ref.m_fromImport;
        this->m_subRequest                   = ref.m_subRequest;
        this->m_bOraCreateIdxHint            = ref.m_bOraCreateIdxHint;
        this->m_bOraNologgingHint            = ref.m_bOraNologgingHint;
        this->m_useMemoryOptizedTempTable    = ref.m_useMemoryOptizedTempTable;
        this->m_multiThreadSize              = ref.m_multiThreadSize;
        this->m_parallelLoad                 = ref.m_parallelLoad;
        this->m_installLevel                 = ref.m_installLevel;
        this->m_bRestrictUpdate              = ref.m_bRestrictUpdate;
        this->m_bUseNativeQuery              = ref.m_bUseNativeQuery;
        this->m_bExtractData                 = ref.m_bExtractData;
        this->m_srcDictEntityStp             = ref.m_srcDictEntityStp;
        this->m_shXdEntityVector             = ref.m_shXdEntityVector;

        COPY_DYNST(this->m_searchShXdEntityStp, ref.m_searchShXdEntityStp, S_XdEntity);

        return *this;
    }

    std::string getDdlObjNatStr()
    {
        switch (this->m_ddlObjNatEn)
        {
            case DbObjDdlObjNat_StoredProc:
                return "StoredProc";
                break;
            case DbObjDdlObjNat_SpecialStoredProc:
                return "SpecialStoredProc";
                break;
            case DbObjDdlObjNat_View:
                return "View";
                break;
            case DbObjDdlObjNat_Trigger:
                return "Trigger";
                break;
            case DbObjDdlObjNat_Index:
                return "Index";
                break;
            case DbObjDdlObjNat_Table:
                return "Table";
                break;
            case DbObjDdlObjNat_ForeignKey:
                return "ForeignKey";
                break;
            case DbObjDdlObjNat_UserTableDS:
                return "UserTableDS";
                break;
            case DbObjDdlObjNat_UserTable:
                return "UserTable";
                break;
            case DbObjDdlObjNat_AllTable:
                return "AllTable";
                break;
            case DbObjDdlObjNat_Label:
                return "BuildLabelInMetaDict";
                break;
            case DbObjDdlObjNat_OnlineHelpDocument:
                return "BuildHelpDocInMetaDict";
                break;
            case DbObjDdlObjNat_PersistedFmt:
                return "PersistedFmt";
                break;
            case DbObjDdlObjNat_SearchFmt:
                return "SearchFmt";
                break;
            case DbObjDdlObjNat_TempTable:
                return "TempTable";
                break;
            case DbObjDdlObjNat_System:
                return "System";
                break;
            case DbObjDdlObjNat_XDDict:
                return "XDDict";
                break;
            case DbObjDdlObjNat_BuildCDS:
                return "BuildCDS";
                break;
            case DbObjDdlObjNat_BuildStaticDS:
                return "BuildStaticDS";
                break;
            case DbObjDdlObjNat_ReportFmt:
                return "ReportFmt";
                break;
            case DbObjDdlObjNat_Questionnaire:
                return "Questionnaire";
                break;
            case DbObjDdlObjNat_ModelBank:
                return "ModelBank";
                break;
            case DbObjDdlObjNat_SampleImportFile:
                return "SampleImportFile";
                break;
            case DbObjDdlObjNat_TslExtension:
                return "TslExtension";
                break;
            case DbObjDdlObjNat_SystemView:
                return "SystemView";
                break;
            case DbObjDdlObjNat_UtilsView:
                return "UtilsView";
                break;
            case DbObjDdlObjNat_CheckAndFix:
                return "CheckAndFix";
                break;
            case DbObjDdlObjNat_BuildInMemory:
                return "BuildInMemory";
                break;
            case DbObjDdlObjNat_BuildInMetaDict1:
                return "BuildInMetaDict1";
                break;
            case DbObjDdlObjNat_BuildInMetaDict2:
                return "BuildInMetaDict2";
                break;
            case DbObjDdlObjNat_BuildInMetaDict3:
                return "BuildInMetaDict3";
                break;
            case DbObjDdlObjNat_BuildInMetaDict4:
                return "BuildInMetaDict4";
                break;
            case DbObjDdlObjNat_BuildTableInDb:
                return "BuildTableInDb";
                break;
            case DbObjDdlObjNat_BuildIndexInDb:
                return "BuildIndexInDb";
                break;
            case DbObjDdlObjNat_BuildPrimaryKey:
                return "BuildPrimaryKey";
                break;
            case DbObjDdlObjNat_BuildForeignKey:
                return "BuildForeignKey";
                break;
            case DbObjDdlObjNat_SetEntityStatus:
                return "SetEntityStatus";
                break;
            case DbObjDdlObjNat_SaveStoredProcInfo:
                return "SaveStoredProcInfo";
                break;
            case DbObjDdlObjNat_References:
                return "References";
                break;

            case DbObjDdlObjNat_None:
            default:
                return "None";
                break;
        }
    }

    DBA_DYNFLD_STP getSearchShXdEntityStp()
    {
        if (this->m_searchShXdEntityStp == nullptr)
        {
            this->m_searchShXdEntityStp = this->m_mp.allocDynst(FILEINFO, S_XdEntity);
        }
        
        return this->m_searchShXdEntityStp;
    }
    
    /* PMSTA-37374 - LJE - 210408 */
    bool isBootStrapLevel() const
    {
        if (this->m_installLevel == 9 ||
            this->m_installLevel == 19 ||
            this->m_installLevel == 99 ||
            this->m_mainDdlObjNatEn == DbObjDdlObjNat_System)
        {
            return true;
        }
        return false;
    }

    bool isPrintSummary() const
    {
        return ((this->m_mainDdlObjNatEn == DbObjDdlObjNat_TslExtension ||
                 this->m_mainDdlObjNatEn == DbObjDdlObjNat_AllTable ||
                 this->m_mainDdlObjNatEn == DbObjDdlObjNat_Label) &&
               (this->m_bSingleEntity == false || 
                this->m_entitySqlnameStr.empty() ||
                this->m_fromImport));
    }

    std::string                 m_entitySqlnameStr;
    std::string                 m_targetSqlnameStr;
    std::string                 m_shortTargetSqlnameStr;
    std::string                 m_sqlnameOptStr;
    std::string                 m_paramEntitySqlnameStr;
                                
    DBOBJDDLOBJNAT_ENUM         m_mainDdlObjNatEn;
    DBOBJDDLOBJNAT_ENUM         m_ddlObjNatEn;
    DBOBJEXECMOD_ENUM           m_execModeEn;
    DDLGEN_BUILD_RULE_ENUM      m_buildRuleEn;
                                
    bool                        m_bInitEntityOnly;
    bool                        m_bSystemFuncOnly;
                                
    INT_T                       m_logLevel;
                                
    bool                        m_bSingleEntity;
    bool                        m_fromImport;
    bool                        m_subRequest;
                                
    bool                        m_bOraCreateIdxHint;
    bool                        m_bOraNologgingHint;
    
    bool                        m_useMemoryOptizedTempTable;
    unsigned int                m_multiThreadSize;
    unsigned int                m_parallelLoad;
                                
    int                         m_installLevel;
    bool                        m_bRestrictUpdate;
    bool                        m_bUseNativeQuery;
    bool                        m_bExtractData;
                                
    DICT_ENTITY_STP             m_srcDictEntityStp;


    std::vector<DBA_DYNFLD_STP> m_shXdEntityVector;

private:
    DBA_DYNFLD_STP              m_searchShXdEntityStp;

    DdlGenAction               *m_backupDdlGenActionPtr;
    DdlGenAction               *m_refDdlGenActionPtr;
    MemoryPool                  m_mp;
};

class DdlGenMessage
{
public:
    // Constructors
    DdlGenMessage(RET_CODE                  messageNo,
                  DDLGEN_MESSAGE_LEVEL_ENUM messageLevelEn,
                  std::string               messageStr)
        : m_messageNo(messageNo)
        , m_messageLevelEn(messageLevelEn)
        , m_messageStr(messageStr)
        , m_messageStp(nullptr)
    {

    }

    DdlGenMessage(const DdlGenMessage &ref)
        : m_messageNo(ref.m_messageNo)
        , m_messageLevelEn(ref.m_messageLevelEn)
        , m_messageStr(ref.m_messageStr)
        , m_messageStp(nullptr)
    {
    }

    // Destructor
    virtual ~DdlGenMessage()
    {

    }

    DdlGenMessage& operator=(const DdlGenMessage &ref)
    {
        this->m_messageNo      = ref.m_messageNo;
        this->m_messageLevelEn = ref.m_messageLevelEn;
        this->m_messageStr     = ref.m_messageStr;

        return *this;
    }

    DBA_DYNFLD_STP     getDdlgenMessageStp()
    {
        if (this->m_messageStp == nullptr)
        {
            this->m_messageStp = this->m_mp.allocDynst(FILEINFO, A_DdlgenMessage);
        }
        SET_STRING(this->m_messageStp, A_DdlgenMessage_Message, this->m_messageStr.c_str());
        SET_ENUM(this->m_messageStp, A_DdlgenMessage_MessageLevelEn, this->m_messageLevelEn);
        SET_INT(this->m_messageStp, A_DdlgenMessage_MessageNo, this->m_messageNo);

        return this->m_messageStp;
    }

    RET_CODE                  m_messageNo;
    DDLGEN_MESSAGE_LEVEL_ENUM m_messageLevelEn;
    std::string               m_messageStr;

private:
    MemoryPool                m_mp;
    DBA_DYNFLD_STP            m_messageStp;
};

class DdlGenContext:public DdlGenMsg
{
public:
    // Constructors
    DdlGenContext(DBA_RDBMS_ENUM rdbmsEn, bool bLightContext = false);
    DdlGenContext(const DdlGenContext&);

    // Destructor
    virtual ~DdlGenContext();

    // Method
    DdlGenContext&                                     operator=(const DdlGenContext&) = delete;

    void                                               syncContext(const DdlGenContext &ref);
    void                                               setDdlGenActionInfoOnAllEntities();

    RET_CODE                                           manageSegment();

    RET_CODE                                           loadMetaDictData();
    RET_CODE                                           loadExtendedData();
    RET_CODE                                           importAllData();
    bool                                               isMetaDictLoaded();
    bool                                               isExtendedLoaded();

    enum class MigrationMode
    {
        None,
        Data,
        CfgAndData
    };

    enum class MaxDbLenCreationRule
    {
        None = -1,
        AlwaysMaxDbLen,
        AlwaysDataType,
        DataTypeForCreate,
        RemoveUserDataType
    };

    enum class OptimLevel
    {
        None,
        Full
    };

    void                                               setDdlDestDbName(std::string newDdlDestDbName, DdlGenDbi* ddbGenDbi);
    std::string                                        getDdlDestDbName();

    void                                               setDefDdlDestDbName(const std::string &newDdlDestDbName = std::string());
    std::string                                        getDefDdlDestDbName();

    RET_CODE                                           setDdlDestUser(std::string user = std::string());
    std::string                                        getDdlDestUser();

    RET_CODE                                           initConnection(DdlGenFile *paramFileHelper, bool paramBInTran);
    RET_CODE                                           endConnection();
    void                                               cleanDbiConnMsg();

    DdlGenRequestHelper                               *getRequestHelper();
    RET_CODE                                           finishBatchMulti();

    void                                               setExtDbiConn(DbiConnection *);

    bool                                               checkSourceDbConnection();

    bool                                               isInsertIdentityOn();

    RET_CODE                                           commit();
    RET_CODE                                           rollback();

    DdlGenCfgFile                                     &getCfgFileHelper(bool bLoadFile = true);
    DdlGenCfgFile                                     &getPropFileHelper();
    DdlGenCfgFile                                     &getTemplateFileHelper();
    DdlGenCfgFile                                     &getUpgradeFileHelper();

    std::string                                        getMainDbName(bool bForceRealDbName = false);
    std::string                                        getLoginDbName();
    std::string                                        getRepDbName();
    std::string                                        getPermTslDbName();
    std::string                                        getTempTslDbName();

    void                                               setAaaHomePath(const std::string &);
    const std::string                                 &getAaaHomePath();
    const std::string                                 &getDdlGenPath();
    const std::string                                 &getAdminPath();
    const std::string                                 &getCorePath();

    bool                                               getSilentMode();

    bool                                               isEnableMultiTascLogin();
    bool                                               isEnableAdditionalDSP();
    bool                                               isEnableSecuOnFkView(); /* PMSTA-43625 - LJE - 210308 */
    unsigned                                           getTemplateVersion();

    RET_CODE                                           resetContext(std::string newDllObjSqlName);

    std::set<std::string>                             &getAllDbSet();

    /* PMSTA-26250 - LJE - 170327 */
    void                                               setDdlGenMode(DDL_GEN_MODE_ENUM ddlGenMode);
    DDL_GEN_MODE_ENUM                                  getDdlGenMode();
    std::string                                        getDdlGenModeStr();

    MaxDbLenCreationRule                               getMaxDbLenRule();

    /* PMSTA-26108 - LJE - 171007 */
    MULTI_ENTITY_LEVEL_ENUM                            getMultiEntityLevel();
    const std::string                                 &getMasterBusinessEntityCd(DbiConnection *dbiConnPtr = nullptr);
    const std::string                                 &getMasterBusinessEntityId();
    bool                                               isEntityMtmFirstLevel(DICT_T entityDictId);
    void                                               getDependsDictEntityMap(const std::string&, std::map<std::string, DICT_ENTITY_STP>&);

    void                                               resetStoredProcInfo(DICT_T entity_dict_id);
    bool                                               getStoredProcInfo(const std::string &sprocSqlName, DictSprocClass *&dictSprocStp, const std::string &dbSqlName = std::string());
    RET_CODE                                           saveStoredProcInfo(bool = true);
    RET_CODE                                           saveDependenciesInDB();

    DdlGenEntity                                      *getTemplateDdlGenEntityPtr();
    DdlGenEntity                                      *getDdlGenEntityPtr(const char *);
    DdlGenEntity                                      *getDdlGenEntityPtr(const std::string &mdEntitySqlName, std::string dbEntitySqlName = std::string(), bool bLoadData = true, bool bCheckOnly = false);

    void                                               getUniqueIndexMap(const std::string & entitySqlName, std::map<std::string, std::map<std::string, bool>> &uniqueIdxMap);      /* PMSTA-31672 - LJE - 180607 */

    void                                               setXdEntitySqlNameById(ID_T entityId, std::string entitySqlName);
    const std::string                                 &getXdEntitySqlNameById(ID_T entityId);

    void                                               addMessage(RET_CODE retCode, DDLGEN_MESSAGE_LEVEL_ENUM messageLevelEn, const std::string &message);

    void                                               setViewEn(DDL_VIEW_ENUM viewEn);
    DDL_VIEW_ENUM                                      getViewEn();
    void                                               setDictSprocSt(DictSprocClass *dictSprocStp);
    DictSprocClass                                    &getDictSprocSt();

    void                                               getConvertValue(std::string &strToConvert);

    DATETIME_T                                         getBuildDate();

    void                                               fillDictEntityFromXdIdMap();
    void                                               addDictEntityByXdId(ID_T, DICT_ENTITY_STP);
    DICT_ENTITY_STP                                    getDictEntityFromXdId(ID_T);

    void                                               fillForcedSegment();

    void                                               addDictAttribFromXdId(ID_T, DICT_ATTRIB_STP);
    DICT_ATTRIB_STP                                    getDictAttribFromXdId(ID_T);

    void                                               initFromIniFile();
    void                                               initEntityToMigrate();
    bool                                               isEntityToMigrate(DICT_ENTITY_STP, DICT_ENTITY_STP, TARGET_TABLE_ENUM);
    bool                                               isEntityToMigrate(const std::string &);
    std::string                                        getFilterScript(DICT_ENTITY_STP);
    std::map<std::string, std::string>                 getColumnScript(const std::string&);

    void                                               readLock();
    void                                               readUnlock();
    void                                               writeLock();
    void                                               writeUnlock();

    bool                                               isProcToGenerate(const std::string &, const std::string &); /* PMSTA-45560 - LJE - 210622 */

    DdlGenContext                                     *m_parentContext;
    DdlGenFile                                        *m_parentFileHeper;
    bool                                               m_bMultiThreadMode;

    bool                                               m_bLightContext;
    DBA_RDBMS_ENUM                                     m_rdbmsEn;

    int                                                upgDoneCpt;
    int                                                upgToDoCpt;

    ID_T                                               scriptControlXdEntId;

    bool                                               bSendInDb;
    bool                                               bCheck;
    bool                                               bBuildDbi;
    bool                                               bGenFromDbi;
    bool                                               bSimulation;
    bool                                               bForceReBuild;
    bool                                               bIgnoreCheck;
    bool                                               bDisable;
    bool                                               m_bHasUnknownCall;

    MigrationMode                                      migrationMode;
    std::map<std::string, std::map<std::string, std::set<std::string>>> tablesFromSrcSysMap;

    OptimLevel                                         optimLevelEn;
    bool                                               bUniqueOnly;
    bool                                               bWriteFile;
    int                                                optimMask;

    DdlGenAction                                       ddlGenAction;

    bool                                               bLanguage;
    bool                                               bUserId;
    bool                                               bAvoidUserPrint;

    bool                                               bLanguagePrinted;

    bool                                               bAvoidSecured;
    bool                                               bSecurityDone;
    bool                                               bAvoidMultiEntity;
    bool                                               bForceConnEntity;    /* PMSTA-29982 - LJE - 180209 */

    bool                                               bAutonomousTransaction; /* PMSTA-20494 - TEB - 160808 */
    bool                                               bDisableChangeSet;      /* PMSTA-nuodb - LJE - 190513 */
    bool                                               bIfNotExists;           /* PMSTA-46681 - LJE - 231214 */

    bool                                               bMainDLMMax;        /* PMSTA-24026 - DDV - 161122 - Data framework */
    bool                                               bMainDLMMaxPrinted; /* PMSTA-24026 - DDV - 161122 - Data framework */
    bool                                               bAddDLMMax;         /* PMSTA-24026 - DDV - 161122 - Data framework */
    bool                                               bAddDLMMaxPrinted;  /* PMSTA-24026 - DDV - 161122 - Data framework */

    bool                                               bRootEntityManagement;

    int                                                identityCacheSize;  /* PMSTA-28928 - LJE - 180205 */

    bool           			                           bStdIinsObjectModifStat; /* PMSTA-32982 - LJE - 181016 */

    bool                                               bForceNewReturnsDef;       /* PMSTA-37366 - LJE - 200128 */

    std::string                                        ddlObjSqlName;

    DML_EVENT_ENUM                                     dmlEventEn;

    bool                                               m_lastCreateInvalid;
    std::map<DdlObjDefKey, DdlObjDef>                  m_invalidDdlObjMap;
    std::map<DdlObjDefKey, DdlObjDef>                  m_validDdlObjMap;
    std::vector<DdlGenMessage>                         m_messagesVector;
    std::vector<DdlGenMessage>                         m_errorMessagesVector;

    bool                                               m_bCodif;             /* PMSTA-26250 - LJE - 170331 */
    std::map<std::string, DICT_ENTITY_STP>             m_dependsEntityMap;   /* PMSTA-26250 - LJE - 170330 */
    std::set<DdlGenDependKey>                          m_dependsSprocSet;    /* PMSTA-29956 - LJE - 180125 */
    std::set<DdlGenDependKey>                          m_dependsAccessSet;   /* PMSTA-29956 - LJE - 180125 */
    bool                                               m_bOutputMessage;     /* PMSTA-nuodb - LJE - 191002 */
    bool                                               m_bIgnoreDepends;
    std::string                                        m_ddlObjLoaded;
    std::stringstream                                  m_loadedDdlObjStream;
    std::map<std::string, std::string>                 m_loadedDdlObjMap;
    std::vector<std::string>                           m_dropDdlStrTab; /* PMSTA-25371 - LJE - 161130 */
    std::vector<std::vector<std::string>>              m_dropDdlParamTab; /* PMSTA-26000 - LJE - 170130 */

    std::vector<DbiInputParam>                         m_inputVariableVector;   /* PMSTA-45413 - LJE - 220217 */
    std::vector<DbiInputParam>                         m_outputVariableVector;   /* PMSTA-45413 - LJE - 220217 */

    /* PMSTA-26250 - LJE - 170404 */
    std::set<std::string>                              m_tmpTableCreatedMap;
    std::stringstream                                  m_createTmpTableStream;

    DdlGenSqlBlock                                     m_initSqlBlock;

    bool                                               bForceTableName; /* PMSTA-26108 - LJE - 171009 */
    bool                                               bForceUdTable;   /* PMSTA-28591 - LJE - 171009 */

    DDL_BUILD_MODE_ENUM                                ddlBuildModeEn;
    DDL_GEN_CALLER_ENUM                                callerEn;
    bool                                               bPartialSpecialization;    /* PMSTA-32145 - LJE - 180720 */
    bool                                               m_useAlternativeDataServer; /* PMSTA-37366 - LJE - 191122 */
    bool                                               m_bIsInstallFromScratch;
    bool                                               m_bDatAll;
    bool                                               m_bHaveMultiEntityCateg;

    int                                                iNoOpCpt;
    bool                                               bWarning;
    int                                                iCursorCpt;

    int                                                m_lastUnkownObjDefPos;
    bool                                               m_bOnCatch;
    bool                                               m_bBcpMode;

    BuildBindOption*                                   m_buildBindOptionPtr;

    std::string                                        connBusinessEntity;
    std::set<ID_T>                                     allBusinessEntityIdSet;

    std::set<std::string>                              depEntityPscSqlNameSet;
    std::set<std::string>                              depSprocSqlNameSet;
    std::set<std::string>                              toInsertEntitySqlNameSet;

    std::string                                        m_forceTbSeg;
    std::string                                        m_forceTbSegSqlName;
    std::string                                        m_forceTbDbSqlName;
    std::string                                        m_forceIdxSeg;
    std::string                                        m_forceIdxSegSqlName;
    std::string                                        m_forceIdxDbSqlName;

    bool                                               bUseClusterIdx;
    bool                                               bCreatePK;

    std::map<std::string, std::map<std::string, ID_T>> m_pkByBkMap;

    std::string              			               m_genFileName;
    std::vector<std::string> 			               m_additionalGenInfo;

    std::map<DDL_OBJ_ENUM, std::map<DDL_CMD_TYPE_ENUM, size_t>> m_ddlObjStatMap;
    std::vector<std::string>                                    m_migDataStatVector;
    std::set<DDL_OBJ_ENUM>                             m_fileOpenSet;

    DdlGenContext*                                     m_ddlGenContextForConn;
    std::stringstream                                  m_releaseTriggerStream;
    std::map<std::string, std::string>                 m_addDeclareMap;          /* PMSTA-58084 - LJE - 240729 */


    std::ofstream                                     *m_logStreamPtr;

protected:

    friend class DdlGenConnGuard;
    friend class DdlGenDbaAccessGuard;
    friend class DdlGenBatchMultiGuard;

    DdlGenDbaAccess&                      getDdlGenDbaAccess();
    DbiConnection&                        getDbiConn();
    DbiConnection&                        getDbiConnForDdl();
    bool                                  hasDbiConn(bool);
    DbiConnection*                        getDbiConnPtrIfExists(bool);
    void                                  insertSprocDepends(DdlObjDef &ddlObjDef, const DdlObjDef &depSprocDdlObjDef, std::set<DdlObjDefKey> &treatedSProc);

    void                                  startBatchMulti();
    void                                  closeBatchMulti();

    DdlGenCfgFile                         cfgFileHelper;
    DdlGenCfgFile                         propFileHelper;
    DdlGenCfgFile                         templateFileHelper;
    DdlGenCfgFile                         upgradeFileHelper;

    DdlGenEntity                         *templateDdlGenEntity;

    std::map<std::string, DdlGenEntity*>  m_ddlGenEntitiesMap;        /* PMSTA-28916 - LJE - 171223 */
    std::map<ID_T, DICT_ENTITY_STP>       m_entityXdDictIdMap;
    std::map<ID_T, DICT_ATTRIB_STP>       m_attribXdDictIdMap;
    std::map<ID_T, std::string>           m_xdEntitySqlNameByIdMap;            /* PMSTA-28916 - LJE - 171223 */

    DbiConnection                        *m_dbiConn;
    DbiConnection                        *m_dbiConnForDdl;

    DdlGenRequestHelper                  *m_requestHelper;

    DbiConnection                        *m_extDbiConn;

    std::string                           ddlDestDbName;
    std::string                           defDdlDestDbName;
    std::string                           ddlDestUser;

    std::string                           mainDbSqlName;
    std::string                           loginDbSqlName;
    std::string                           repDbSqlName;
    std::string                           permTslDbSqlName;
    std::string                           tempTslDbSqlName;

    std::string                           tascLoginUser;

    DdlGenFile                           *fileHelper;

    DDL_VIEW_ENUM                         m_viewEn;
    MemoryPool                            m_mp;

    RET_CODE                              applyContext(bool bForDdl);
    bool                                  isMultiThreadMode() const;

    DATETIME_T                            buildDate;

    std::string                           m_aaaHomePath;
    std::string                           ddlPath;
    std::string                           corePath;
    std::string                           adminPath;

    int                                   enableMultiTascLoginVal; /* PMSTA-16575 - LJE - 130626 */
    int                                   enableAdditionalDSPVal;
    int                                   enableSecuOnFkView;      /* PMSTA-43625 - LJE - 210308 */
    int                                   templateVersionVal;

    std::string                            currUser;

    bool                                   bInTran;
    unsigned                               manageNullLevel;

    DDL_GEN_MODE_ENUM                      m_ddlGenMode; /* PMSTA-26250 - LJE - 170330 */

    DictSprocClass                         m_dictSprocSt;
    DBA_DYNFLD_STP                         m_shDictSporcStp;

    std::map<std::string, std::string>     m_convertMap;
    std::map<DdlObjDefKey, DictSprocClass> m_dictSprocMap;
    std::set<DICT_T>                       m_entityMtmFirstLevel;

    unsigned                               m_silentMode;
    SYS_LOCKRW_STP                         m_rwLock;

    CURRENTCHARSETCODE_ENUM                                      m_sourceCharSetEn;
    std::set<std::string>                                        m_migSkippedEntities;
    std::map<std::string, std::string>                           m_migFilterMap;
    std::map<std::string, std::string>                           m_migDatabaseMap;
    std::map<std::string, std::string>                           m_migTableMap;
    std::map<std::string, std::map<std::string, std::string>>    m_migColumnMap;

    DdlGenDbaAccess                                             *m_ddlGenDbaAccessPtr;  /* PMSTA-45413 - LJE - 210610 */
    std::set<std::string>                                        m_allDbSet;

    MaxDbLenCreationRule                                         m_maxDbLenRule;
};

typedef std::unique_ptr<DdlGenContext> DdlGenContextPtr;

class DdlGenConnGuard
{
public:
    // Constructors
    DdlGenConnGuard(DdlGenContext &);
    DdlGenConnGuard(const DdlGenConnGuard&) = delete;
    // Destructor
    virtual ~DdlGenConnGuard();

    // Methods
    DdlGenConnGuard& operator=(const DdlGenConnGuard&) = delete;

    DbiConnection&          getDbiConn();
    DbiConnection&          getDbiConnForDdl();

protected:
    DdlGenContext& m_ddlGenContext;
    bool           m_isConnInit;
    bool           m_isConnForDdlInit;

    DbiConnection *m_extDbiConn;
};

class DdlGenDbaAccessGuard
{
public:
    // Constructors
    DdlGenDbaAccessGuard(DdlGenContext&);
    DdlGenDbaAccessGuard(const DdlGenDbaAccessGuard&) = delete;
    // Destructor
    virtual ~DdlGenDbaAccessGuard();

    // Methods
    DdlGenDbaAccessGuard& operator=(const DdlGenDbaAccessGuard&) = delete;

    DdlGenDbaAccess& getDdlGenDbaAccess();

protected:
    DdlGenContext& m_ddlGenContext;
};

class DdlGenBatchMultiGuard
{
public:
    // Constructors
    DdlGenBatchMultiGuard(DdlGenContext&);
    DdlGenBatchMultiGuard(const DdlGenBatchMultiGuard&) = delete;
    // Destructor
    virtual ~DdlGenBatchMultiGuard();

    // Methods
    DdlGenBatchMultiGuard& operator=(const DdlGenConnGuard&) = delete;

protected:

    DdlGenContext& m_ddlGenContext;
};


#include "ddlgendbaccess.h"

class DdlGenJoin
{
public:
    // Constructors
    DdlGenJoin();
    DdlGenJoin(const DdlGenJoin&);
    // Destructor
    virtual ~DdlGenJoin();

    // Methods
    bool operator< (const DdlGenJoin & a) const ;
    DdlGenJoin& operator=(const DdlGenJoin& toCopy);
    // Variables
    DICT_ENTITY_STP				joinDictEntityStp;
    std::string                 joinEntitySqlName;
    std::string					joinSqlName;
    DICT_ATTRIB_STP             dictAttribStp;
    int							firstIdPos;
    bool                        isNullFirstId;
    int							secondIdPos;
    bool						isNullSecondId;
    ENTITY_SECURITY_LEVEL_ENUM	securityLevelEn;
    FLAG_T						codifFlg;
    FLAG_T						mandatoryFlg;
    DICT_T						parentEntDictId;
    OBJECT_ENUM					objectEn;
    int                         sortJoin;
    const DdlGenJoin           *parentJoinStp;
    DDL_JOIN_TYPE_ENUM          joinTypeEn;
    std::string                 addJoinInfoStr;

};

class DdlGen :public DdlGenDbi {

public:
    // Constructors
    DdlGen(OBJECT_ENUM           paramObjectEn,
           DDL_OBJ_ENUM          paramDdlObjEn,
           DdlGenContext        &paramDdlGenContext,
           DdlGenVarHelper      *paramVarHelperPtr,
           DdlGenEntity         *paramDdlGenEntityPtr,
           DdlGenFile           *paramFileHelper,
           TARGET_TABLE_ENUM     paramTargetTableEn);

    DdlGen(OBJECT_ENUM                paramObjectEn,
           DDL_OBJ_ENUM               paramDdlObjEn,
           DBA_DYNTYPE_ENUM           paramOutputDynNatEn,
           FLAG_T                     paramCustFlg,
           FLAG_T                     paramprecompFlg,
           FLAG_T                     paramOnlyPhysicalFlg,
           ENTITY_SECURITY_LEVEL_ENUM paramSecuLevelEn,
           FLAG_T                     paramTranslateFlg,
           DdlGenContext             &paramDdlGenContext,
           DdlGenVarHelper           *paramVarHelperPtr,
           DdlGenEntity              *paramDdlGenEntityPtr,
           DdlGenFile                *paramFileHelper,
           TARGET_TABLE_ENUM          paramTargetTableEn);

    /* PMSTA-26250 - LJE - 170410 */
    DdlGen(OBJECT_ENUM        paramObjectEn,
           const DdlGen      &paramDdlGen);
    /* PMSTA-26250 - LJE - 170410 */
    DdlGen(OBJECT_ENUM        paramObjectEn,
           TARGET_TABLE_ENUM  paramTargetTableEn,
           DdlGenFromFile    &paramDdlGenFromFile);

    DdlGen(const DdlGen&) = delete;
    // Destructor
    virtual ~DdlGen();

    // Methods
    DdlGen& operator=(const DdlGen&) = delete;
    static std::string             getUdIdSqlName();
    static std::string             getXIdSqlName();
    static std::string             getScriptControlSqlName();
    static std::string::size_type  find_first_not_of(const std::string &str, const std::string& delimiters, std::string::size_type startPos = 0);
    static std::string::size_type  find_first_of(const std::string &str, const std::string& delimiters, std::string::size_type startPos = 0, bool bNotOf = false, bool bAvoidInBracket = false);
    static std::string::size_type  find_word(const std::string &str,
                                             const std::string& findStr,
                                             std::string::size_type startPos = 0,
                                             std::string::size_type endPos = std::string::npos,
                                             const std::string &specWordDelimiter = std::string(),
                                             bool bAvoidInBracket = false);

    static std::string             getNextKeyWord(const std::string &str, std::string::size_type &startPos);
    static void                    getBracketPos(const std::string &str, std::string::size_type &endPos, std::string::size_type &startPos, const std::string &openStr = "(", const std::string &closeStr = ")");
    static int                     tokenizeStr(std::vector<std::string>& tokens, std::string tokenStr, const std::string& delimiters = " \t", bool bAppend = false, int bracketOpen = 0, bool bIsInBracket = false, size_t *endPosPtr = nullptr);
    static bool                    isSecuredLevel(ENTITY_SECURITY_LEVEL_ENUM testSecuredLevel);

    ENTITY_SECURITY_LEVEL_ENUM     getDefSecuredLevel();
    bool                           isSecuredWithAddDSP(ENTITY_SECURITY_LEVEL_ENUM testSecuredLevel);

    virtual RET_CODE          build();
    virtual RET_CODE          drop();
    virtual RET_CODE          grant();
    virtual RET_CODE          printHeader();
    virtual RET_CODE          printFooter();
            RET_CODE          flush(const std::string &message = std::string());
    virtual std::string       getEntitySqlName(DICT_ENTITY_STP paramDictEntityStp = nullptr, TARGET_TABLE_ENUM paramTargetTableEn = TargetTable_Undefined, bool bMdSqlName = false);
    virtual std::string       getEntityMdName(DICT_ENTITY_STP paramDictEntityStp = nullptr, TARGET_TABLE_ENUM paramTargetTableEn = TargetTable_Undefined);
    virtual std::string       getEntityFullSqlName(DICT_ENTITY_STP paramDictEntityStp = nullptr, TARGET_TABLE_ENUM paramTargetTableEn = TargetTable_Undefined, bool bTryToSecure = false);
    virtual std::string       getEntityFullSqlName(const std::string &entitySqlName, TARGET_TABLE_ENUM locTargetTableEn = TargetTable_Undefined); /* PMSTA-26250 - LJE - 170331 */

    RET_CODE          initRequest();

    void              init(OBJECT_ENUM				  paramObjectEn,
                           DBA_DYNTYPE_ENUM			  paramOutputDynNatEn,
                           FLAG_T					  paramCustFlg,
                           FLAG_T					  paramprecompFlg,
                           FLAG_T					  paramOnlyPhysicalFlg,
                           ENTITY_SECURITY_LEVEL_ENUM paramSecuLevelEn,
                           FLAG_T					  paramTranslateFlg);
    void            copy(const DdlGen &ref);

    void            setDefaultContext();

    void            printDeclareVar(DdlGenSqlBlock &sqlBlock, const std::string &varName, const std::string &valueStr);  /* PMSTA-26250 - LJE - 170410 */
    bool            isDeclareVarPrinted(DdlGenSqlBlock &sqlBlock, const std::string &varName);

    bool            isDeclareUserPrinted(DdlGenSqlBlock &sqlBlock);

    void			printDeclareUser(DdlGenSqlBlock &sqlBlock, bool bForceDeclare = false);
    void			printDeclareDataProfile(DdlGenSqlBlock &sqlBlock);
    void			printDeclareLanguage(DdlGenSqlBlock &sqlBlock);
    void			printDeclareMainDLMMax(DdlGenSqlBlock &sqlBlockm);         /* PMSTA-24026 - DDV - 161122 - Data framework */
    void			printDeclareAddDLMMax(DdlGenSqlBlock &sqlBlock);           /* PMSTA-24026 - DDV - 161122 - Data framework */
    void            printDeclareChangeSet(DdlGenSqlBlock &sqlBlock);           /* PMSTA-26250 - LJE - 170410 */
    void            printDeclareChangeSetPromotion(DdlGenSqlBlock &sqlBlock);  /* PMSTA-26250 - LJE - 170410 */
    void            printDeclareConnBusinessEntity(DdlGenSqlBlock &sqlBlock);  /* PMSTA-26108 - LJE - 170818 */
    void            printDeclareApplSession(DdlGenSqlBlock &sqlBlock);  /* PMSTA-26108 - LJE - 170818 */

    void            printDeclareVariables(DdlGenSqlBlock &sqlBlock);

    RET_CODE        printSelListRequest(SEL_LIST_ENUM selListEn = SelList_Select);
    RET_CODE        printFromRequest();
    RET_CODE        printWhereRequest();
    void            printNatureAttribClause(DICT_ATTRIB_STP);
    std::string     getWhereOrAnd();
    void            printUserJoin();
    std::string     getCmdUserId(bool bVariable=true);
    std::string     getConnBusinessEntityId();                    /* PMSTA-26108 - LJE - 170818 */

    void            replaceTagAlias(std::stringstream &inOutStream);

    static std::string getApplOwner(std::string&, std::string::size_type, DdlGenContext* currDdlGenContextPtr, DdlGenVarHelper*, DdlGen*);
    static std::string getReplaceUserId(std::string &, std::string::size_type, DdlGenContext *currDdlGenContextPtr, DdlGenVarHelper *varHelperPtr, DdlGen *);
    static std::string getReplaceLanguageDictId(std::string &, std::string::size_type, DdlGenContext *currDdlGenContextPtr, DdlGenVarHelper *varHelperPtr, DdlGen *);
    static std::string getReplaceApplSessionCd(std::string &, std::string::size_type, DdlGenContext *currDdlGenContextPtr, DdlGenVarHelper *varHelperPtr, DdlGen *);
    /* PMSTA-26108 - LJE - 171004 */
    static std::string getMasterBusinessEntityId(std::string &, std::string::size_type, DdlGenContext *currDdlGenContextPtr, DdlGenVarHelper *, DdlGen *);
    static std::string getMasterBusinessEntityCd(std::string &, std::string::size_type, DdlGenContext *currDdlGenContextPtr, DdlGenVarHelper *, DdlGen *);
    static std::string getConnBusinessEntityId(std::string &, std::string::size_type, DdlGenContext *, DdlGenVarHelper *, DdlGen *ddlGen);
    static std::string getDboCmd(std::string &lineToTreat, std::string::size_type replacePos, DdlGenContext *currDdlGenContextPtr, DdlGenVarHelper *, DdlGen *ddlGen);

    /* replaceFunctionByFct functions */
    static std::string getViewName(DdlGenContext*, DdlGenVarHelper*, std::vector<std::vector<std::string>>&);
    static std::string manageUniqueTag(DdlGenContext*, DdlGenVarHelper*, std::vector<std::vector<std::string>>&);
    static std::string getJsonGetId(DdlGenContext *, DdlGenVarHelper *, std::vector<std::vector<std::string>>&); /* PMSTA-45027 - LJE - 210521 */
    static std::string getJsonGetKey(DdlGenContext *, DdlGenVarHelper *, std::vector<std::vector<std::string>>&); /* PMSTA-45027 - LJE - 210521 */
    static std::string manageValueTag(DdlGenContext*, DdlGenVarHelper*, std::vector<std::vector<std::string>>&);
    static std::string manageLastReturnStatusTag(std::string&, std::string::size_type, DdlGenContext* currDdlGenContextPtr, DdlGenVarHelper* varHelperPtr, DdlGen*);
    static std::string getCollate(std::string&, std::string::size_type, DdlGenContext* currDdlGenContextPtr, DdlGenVarHelper* varHelperPtr, DdlGen*);

    std::string   getPkAccessWhere(DICT_ENTITY_STP, DICT_ATTRIB_STP, const std::string &, const std::string &, bool , DICT_ATTRIB_STP = nullptr, DICT_ENTITY_STP = nullptr);

    bool         extractAndFixDependsEntity(std::string &lineStr);

    void         clear();

    void            setObjectEn(OBJECT_ENUM paramObjectEn);
    OBJECT_ENUM     getObjectEn() const;

    void            setDdlObjEn(DDL_OBJ_ENUM  paramDlObjEn);

    DICT_ENTITY_STP getDictEntityStp(bool bSource = false); /* PMSTA-13109 - LJE - 111124 */

    void            setTableNamePatern(const std::string &tablePaternStr);

    void setSecurityLevel(ENTITY_SECURITY_LEVEL_ENUM	newSecurityLevelEn);

    std::string            getJoinAlias(const DdlGenJoin &joinStp, bool bInFrom=false);

    void                   setOnJoin(bool paramOnJoin);   /* PMSTA-26252 - LJE - 170310 */

    static bool            isInsUpdParam(DICT_CRITER_STP dictCriterStp, DBA_DYNTYPE_ENUM  outputDynNatEn);

    std::string::size_type posKey(const std::string& lineStr, const char *keyName);

    void                   printOptimisticLockingClause(DdlGen &locGenDdl, DICT_ENTITY_STP locDictEntityStp, DdlGenFromFile &scriptDdlGen);
    void                   printShadowManagement(DdlGen &locGenDdl, DdlGenFromFile &scriptDdlGen);

    DICT_ATTRIB_STP        getConnBusinessEntAttrStp(DICT_ENTITY_STP   currDictEntityStp = nullptr); /* PMSTA-26108 - LJE - 170829 */

    DICT_CRITER_STP        getDictCriteriaStp(INT_T critProgN);

    void                   disableAllTriggers(const std::string & = std::string());
    void                   enableAllTriggers(const std::string & = std::string());
    bool                   checkAttributeNotNullOnRecords();
    void                   getOrderClause(DICT_ENTITY_STP, std::stringstream &, std::stringstream &, bool = true, int = 0);

    // Variables
    DdlGenFromFile        *scriptDdlGen;

    std::stringstream      ddlGenStream;

    std::stringstream      headerStream;
    std::stringstream      headerDeclareStream;

    std::stringstream      m_mainFromStream;
    std::stringstream      m_fromStream;
    std::stringstream      whereStream;
    std::stringstream      orderStream;
    std::stringstream      groupStream;
    std::stringstream      limitStream;
    std::stringstream      havingStream;
    std::stringstream      cursorStream;
    std::stringstream      footerStream;

    DdlGenSqlBlock         bodySqlBlock;

    std::stringstream      selListStream;
    std::stringstream      initStream;
    std::stringstream      varListStream;

    std::stringstream      overloadStream;

    std::string            pscFromStr;
    std::string            pscWhereStr;

    DdlGenSqlBlock         finSrvCallSqlBlock;

    FLAG_T                 secuMandatoryFlg;

    bool                   bOrderBy;
    bool                   bJoinOnFromTag;
    bool                   bReplaceFromTag;

    std::string            fromAddStr;
    std::string            queryAddStr;

    bool              bManageAuthFlg; /* PMSTA-14607 - LJE - 120712 */
    bool              bUserSecured; /* PMSTA-14607 - LJE - 120712 */
    bool              bForceDPInAppContext; /* OCS-41131 - LJE - 120723 */
    bool              bForceDPInSuserName;  /* PMSTA-14785 - LJE - 120829 */

    FLAG_T            custFlg;
    FLAG_T            precompFlg;
    bool              bHidePrecomp;
    FLAG_T            onlyPhysicalFlg;

    ENTITY_SECURITY_LEVEL_ENUM	securityLevelEn; /* PMSTA-13122 - LJE - 120602 */

    /* OCS-39654 - LJE - 120213 */
    FLAG_T            thirdSecuredFlg;
    FLAG_T            thirdCompoSecuredFlg;

    FLAG_T            translateFlg;

    FLAG_T            denomFlg;
    FLAG_T            labelFlg;

    bool              bShadowAccess;
    MULTI_ENTITY_ACCESS_ENUM mulitEntityAccessEn; /* PMSTA-26108 - LJE - 170905 */

    std::vector<DdlGenJoin> joinTab;
    std::vector<DdlGenJoin> addedJoinTab;

    std::map<INT_T, DictCriterClass*>  *infoCriterMap;

    std::string       fileSpecStr;

    bool              bAppendFile;

    bool              bKeepRealObject;
    OBJECT_ENUM       realObjectEn;
    std::string       realSqlName;
    DICT_ENTITY_STP   realDictEntityStp;

    bool              bNoIndentReset;

    std::list<DdlSelectElt> selectList;
    std::list<DdlSelectElt> insertList;

    DdlGenVar              *rowCountVarPtr;
    DdlGenVar              *errorVarPtr;

    bool                    bPkWhereAccess;
    bool                    bBkWhereAccess;

    std::string             m_authAlias;

    DBA_DYNTYPE_ENUM       outputDynNatEn;
    bool                   m_bAddFieldOnSelect;
    int                    m_joinCpt;


protected:
    RET_CODE          printUserInfoAccess();
    RET_CODE          printSecurityOnFrom(ENTITY_SECURITY_LEVEL_ENUM   paramSecuLevelEn,
                                          bool                         bMainEntity,
                                          bool                         bMandatoryJoin,
                                          const std::string           &entityAlias,
                                          const std::string           &joinAlias,
                                          std::stringstream           &fromStream,
                                          int                         &joinCpt,
                                          std::stringstream           &closeFromStream);
    RET_CODE          printSecurityOnWhere(ENTITY_SECURITY_LEVEL_ENUM  paramSecuLevelEn,
                                           bool                        bSecurityToDo,
                                           const std::string          &entityAlias,
                                           std::stringstream          &outputStream);

    /* PMSTA-26108 - LJE - 170829 */
    size_t            printMultiEntityManagement(DICT_ENTITY_STP       currDictEntityStp,
                                                 const std::string    &entityAlias,
                                                 bool                  bPrintWhere,
                                                 bool                  bWhereRequest,
                                                 std::stringstream    &outputStream);

    std::string       getCriteriaAlias(DICT_CRITER_STP joinCriteriaStp);
    std::string       getDataProfile();
    std::string       getDataProfileUser();
    std::string       getCmdCurUsrDataProfile();
    std::string       getCodif();
    std::string       getLanguage();

    RET_CODE          printSelectList(SEL_LIST_ENUM selListEn);

    DICT_ATTRIB_STP   getDictAttribOnRequest(std::string &paramAttribStr, std::string &alias);

    RET_CODE          executeFlush();

    std::string            ddlObjName;
    std::string            m_ddlObjBaseName;

    std::string            udTableName;

    bool                   m_bWherePrinted;
    bool                   bOnJoin;
    bool                   bSelectPrinted;
    bool                   bUserJoinPrint;

    DdlGenEntity          *ddlGenEntityPtr;
    DdlGenCfgTemplate     *securityTemplate;

    DDL_VIEW_ENUM          m_outputViewEn;

private:
    OBJECT_ENUM       objectEn;
    DICT_ENTITY_STP   m_dictEntityStp;
    DICT_ENTITY_STP   m_srcDictEntityStp;

    DICT_ENTITY_ST    invalidDictEntitySt;

    bool              bSubDdlGenObj;

private:
    bool manageOrderJoin(DictCriterClass &,
                         std::map<std::string, std::stringstream> &,
                         std::map<std::string, int> &,
                         std::map<SMALLINT_T, std::string> &,
                         int &,
                         bool,
                         std::string);
};

class DdlGenString
{
public:

    // Constructors
    DdlGenString()
    {
    }

    DdlGenString(const DdlGenString &ref)
    {
        *this = ref;
    }

    DdlGenString(const std::string &ref): m_string(ref)
    {
    }

    // Destructor
    virtual ~DdlGenString()
    {
    }

    // Methods
    DdlGenString &operator=(const DdlGenString &ref)
    {
        if (&ref != this)
        {
            this->m_string = ref.get();
        }

        return *this;
    }

    const std::string &get() const
    {
        return this->m_string;
    }

    int compare(const std::string &toCompareStr) const
    {
        return this->compare(toCompareStr.c_str());
    }

    int compare(const char *toCompareStr) const
    {
        return strcasecmp(this->m_string.c_str(), toCompareStr);
    }

    bool empty() const
    {
        return this->m_string.empty();
    }

    int length() const
    {
        return static_cast<int>(this->m_string.length());
    }

    void clear()
    {
        this->m_string.clear();
    }

    const char *c_str() const
    {
        return this->m_string.c_str();
    }

    std::string::size_type find_first_not_of(const std::string& delimiters, std::string::size_type startPos = 0) const
    {
        return DdlGen::find_first_not_of(this->m_string, delimiters, startPos);
    }

private:

    std::string m_string;
};

extern RET_CODE DDL_InstallDdlObjectByParam();                          /* PMSTA-11505 - LJE - 110519 */
extern RET_CODE DDL_InstallDdlObject(DdlGenAction &ddlGenAction, DdlGenContext &ddlGenContext); /* PMSTA-28704 - LJE - 180403 */

#endif	                               /* ifndef DDLGEN_H */
/************************************************************************
**      END       ddlgen.h                                        Odyssey
*************************************************************************/

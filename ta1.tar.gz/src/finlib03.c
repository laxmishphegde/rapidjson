/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines      
*************************************************************************/
#define FINLIB03_C

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H
#define MATH_H

#include "unidef.h"         /* Mandatory */
#include "gen.h"
#include "date.h"
#include "dba.h"
#include "hier.h"
#include "fin.h"
#include "scelib.h"

/************************************************************************
**      External entry points
**
** FIN_BondFlows()                  Retrieves all possible future flows of a bond
** FIN_BondNextCoupon()             Get next coupon payment date for received bond
** FIN_GenerateInstrFlows()         Retrieves all possible future flows of an instr
** FIN_GenerateInstrFlowsEvtGen()   Retrieves all possible future flows of an 
**                                  instr for event generation.
** FIN_DebtFlows()                  Retrieves all possible future flows of a debt
** FIN_GetOptionInfo()              Get some option info (underly, exercice price)
** FIN_InsertPosVal()               Special function to insert pos val 
** FIN_InstrFlow()                  Retrieve information about a specific flow 
** FIN_PeriodUnitNbr()              Compute events number in a year (in output unit)
** FIN_TreatCumOption()             Cum option are composed of ex bond and ex option(s).
** FIN_ManageGeneratedOperation()   Manage the interactive action on the operations 
**                                  from the Event Generation interface
** FIN_ManageGeneratedFlow()        Manage the interactive action on the flows 
**                                  from the Event Generation interface
**
*************************************************************************/

/************************************************************************
**      Local functions
**
** FIN_CmpFlows()                   Order no filtered flows by date
** FIN_CashAcctFlows()              Retrieves all possible future flows of an account
** FIN_CreateBondFlow()             Generate a flow for bond depending on redemp event
** FIN_CreateStockFlow()            Generate a flow for stock depending on income event
** FIN_CreateExchangeFlow()         Generate a flow for all exchange event (REF1138 - 980310 - DDV)
** FIN_FilterFlows()                Use input flow nature or flow subnature
** FIN_ForwardFlows()               Retrieves all possible future flows of a forward
** FIN_FundShareFlows()             Retrieves all possible future flows of a fund share
** FIN_FutureFlows()                Retrieves all possible future flows of a future
** FIN_GetIoRFlowSubNat()           Get flow sub-nature (by issue or redemp nature)
** FIN_MoneyMktFlows()              Retrieves all possible future flows of a money mkt
** FIN_OptionFlows()                Retrieves all possible future flows of an option 
** FIN_StockFlows()                 Retrieves all possible future flows of a stock
** FIN_SwapFlows()                  Retrieves all possible future flows of a swap
** FIN_OtherFlows()                 Retrieves all echange flows for intruments of nature Other
** FIN_UpdateGeneratedOperation()   Manage the interactive update action on the 
**                                  operations from the Event Generation interface.
** FIN_UpdateGeneratedFlow()        Manage the interactive update action on the 
**                                  flows from the Event Generation interface.
**
** FIN_FilterPropAttribFlow()       Filter function on linked Flow with sub nature 
**                                  "Proportional Attribution".
**
**
*************************************************************************/

/************************************************************************
**      Static definitions & data
*************************************************************************/
#define FREE_FLOW(p,n) {unsigned char F_i;\
                if (p != NULL)\
                {for (F_i=0; F_i<(unsigned char)n; F_i++)\
                FREE_DYNST(p[F_i], Flow);\
                   FREE(p);} n=0;}

/* REF3990 - SSO - 000406 : do not stop in case on non-critical error in flow generation
    WARNING: for a flow nature, all checks must be done before flow allocation in flowTab, or
    in case of error already allocated flows must be removed  */
/* REF3990 - SSO - 000413: rewrote RET_GENFLOWS + added RET_DBA_ERR_INVDATA */
#define FATAL_FLOWSERROR(ret) (ret != RET_FIN_ERR_INVDATA && ret != RET_DBA_ERR_NODATA && ret != RET_DBA_ERR_INVDATA)
#define RET_GENFLOWS(ret)   if (FATAL_FLOWSERROR(ret) == FALSE) \
                {return(RET_SUCCEED);}\
                else \
                {return(ret);}


STATIC RET_CODE FIN_OptionFlows(DATETIME_T, DATETIME_T, DATETIME_T, 
                DBA_DYNFLD_STP, EVTDATERULE_ENUM, DBA_DYNFLD_STP**, int*, DBA_HIER_HEAD_STP),
                FIN_ForwardFlows(DATETIME_T, DATETIME_T, DBA_DYNFLD_STP, 
                 DBA_DYNFLD_STP**, int*, DBA_HIER_HEAD_STP),
                FIN_FutureFlows(DATETIME_T, DATETIME_T, DATETIME_T,
                DBA_DYNFLD_STP, EVTDATERULE_ENUM, DBA_DYNFLD_STP**, int*, DBA_HIER_HEAD_STP),
                FIN_MoneyMktFlows(DATETIME_T, DATETIME_T, DATETIME_T,
                  DBA_DYNFLD_STP, EVTDATERULE_ENUM, DBA_DYNFLD_STP**, int*, DBA_HIER_HEAD_STP), /* REF4075 - CSY - 991027 */
                FIN_CashAcctFlows(DATETIME_T, DATETIME_T, DATETIME_T,
                  DBA_DYNFLD_STP, EVTDATERULE_ENUM, DBA_DYNFLD_STP**, int*, DBA_HIER_HEAD_STP),
                /*FIN_DebtFlows(DATETIME_T, DATETIME_T, DATETIME_T,  
                  DBA_DYNFLD_STP, DBA_DYNFLD_STP**, int*, DBA_HIER_HEAD_STP),*/ /* REF6004 - AKO - 011116 : become external*/
                FIN_StockFlows(DATETIME_T, DATETIME_T, DATETIME_T,
                   DBA_DYNFLD_STP, EVTDATERULE_ENUM, DBA_DYNFLD_STP**, int*, DBA_HIER_HEAD_STP, int*), /* REF4075 - CSY - 991027 */

                FIN_CreateBondFlow(int*, int, DBA_DYNFLD_STP**, DBA_DYNFLD_STP, 
                   int, PERCENT_T, NUMBER_T, DATETIME_T, DATETIME_T, char*),
                FIN_CreateStockFlow(int*, int, DBA_DYNFLD_STP**, DBA_DYNFLD_STP, DBA_DYNFLD_STP,
                int, char, DATETIME_T, DATETIME_T, DBA_HIER_HEAD_STP),

                FIN_NewStockFlows(DATETIME_T, DATETIME_T, DATETIME_T,
                    DBA_DYNFLD_STP, EVTDATERULE_ENUM, DBA_DYNFLD_STP**, int*, DBA_HIER_HEAD_STP),/*PMSTA-32106 -NRAO 180904*/
                FIN_FundShareFlows(DATETIME_T, DATETIME_T, DATETIME_T,
                    DBA_DYNFLD_STP, EVTDATERULE_ENUM, DBA_DYNFLD_STP**, int*, DBA_HIER_HEAD_STP); /*PMSTA-32106 -NRAO 180904*/

STATIC int FIN_FilterInstrForIncomeFlows(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);
STATIC int FIN_CmpFlowsBydate(void*, void*);

/************************************************************************
**
**  Function    :   FIN_GetOptionInfo()
**
**  Description :   Get some option informations (underly, exercice price)
**
**  Arguments   :   optPtr     option dynamic structure pointer
**                  fromDate   from date
**                  optInfoPtr pointer on option information structrure 
**
**  Return      :   RET_SUCCEED or error code
**
**  Modif.	    :   BUG136 - RAK - 960924
**
*************************************************************************/
EXTERN RET_CODE FIN_GetOptionInfo(DBA_DYNFLD_STP  optPtr,
                           DATE_T          fromDate, 
                          FIN_OPTINFO_STP optInfoPtr)
{
    DBA_DYNFLD_STP termEvt=NULLDYNST;
    RET_CODE       ret;

    MemoryPool mp;

    /* Get event information */
    termEvt = mp.allocDynst(FILEINFO, A_TermEvt);
    
    ret = DBA_GetTermEvt(optPtr, fromDate, termEvt);

    if (ret == RET_SUCCEED)
    {
        optInfoPtr->underId    = GET_ID(termEvt, A_TermEvt_UnderlyInstrId);
        optInfoPtr->exerCurrId = GET_ID(termEvt,     A_TermEvt_CurrId);
	    optInfoPtr->exerPrice  = GET_PRICE(termEvt, A_TermEvt_ExerPrice);
        optInfoPtr->optClassEn = (OPTCLASS_ENUM)GET_ENUM(termEvt, A_TermEvt_OptionClassEn);  /* REF7264 - CSY - 020130 */
        optInfoPtr->endDate    = GET_DATE(termEvt,   A_TermEvt_EndDate);
        optInfoPtr->underQty   = GET_NUMBER(termEvt, A_TermEvt_UnderlyQty);
    }

    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_TreatCumOption()
**
**  Description :   Cum option are composed of ex bond and ex option(s).
**                  This function search the ex bond
**                 
**  Arguments   :   instrPtr : cum option structure pointer
**                  dateTime : reference date
**                  bondPtr  : pointer on ex bond which will be updated.
**
**  Return      :   RET_SUCCEED (and bondPtr is updated), or error code
**
**  Modif.	    :   REF308 - RAK - 971028
**
*************************************************************************/
RET_CODE FIN_TreatCumOption(DBA_DYNFLD_STP      instrPtr, 
                            DATETIME_T          dateTime,
                            DBA_DYNFLD_STP      bondPtr,
                            DBA_HIER_HEAD_STP   hierHead)
{
    RET_CODE       ret;
    DBA_DYNFLD_STP *compoTab=(DBA_DYNFLD_STP*)NULL, compoPtr=NULLDYNST;
    int            compoNbr, i;
    char           found;
    FLAG_T         allocOk = FALSE;

    /* REF308 - If instrument isn't composite, bond information is in cum option */
    if ((VALRULE_ENUM) GET_ENUM(instrPtr, A_Instr_ValRuleEn) != ValRule_Composite)
    {
        DBA_CopyDynSt(bondPtr, instrPtr, A_Instr);
        return(RET_SUCCEED);
    }

    ret = DBA_SelectInstrCompo(GET_ID(instrPtr, A_Instr_Id), 
                               dateTime, &compoTab, &compoNbr);

    if (ret != RET_SUCCEED || compoNbr <= 0)
    {
        MSG_SendMesg(RET_DBA_ERR_NODATA, 3, FILEINFO,
            "FIN_TreatCumOption",
            GET_CODE(instrPtr, A_Instr_Cd), DBA_GetDictEntitySqlName(InstrCompo));
        return(RET_DBA_ERR_NODATA);
    }

    for (i=0, found=FALSE; i<compoNbr && found==FALSE; i++)
    {
        /* REF3913 - DDV - 991006 */
        if ((ret = DBA_GetInstrById(GET_ID(compoTab[i], A_InstrCompo_InstrId), FALSE, 
                                    &allocOk, &compoPtr, hierHead, UNUSED, UNUSED)) != RET_SUCCEED)
        {
            SYSNAME_T entSqlName;
            DBA_FreeDynStTab(compoTab, compoNbr, A_InstrCompo);
            strcpy(entSqlName, DBA_GetDictEntitySqlName(Instr));
                MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, 
                         entSqlName, GET_ID(compoTab[i], A_InstrCompo_InstrId));
            return(RET_DBA_ERR_NODATA);
        }

        if ((INSTRNAT_ENUM) 
            GET_ENUM(compoPtr, A_Instr_NatEn) == InstrNat_Bond)
        {
            found = TRUE;
        }
        else if (allocOk == TRUE) {FREE_DYNST(compoPtr, A_Instr);} /* PMSTA07185 - DDV - 081023 - Purify */
    }

    DBA_FreeDynStTab(compoTab, compoNbr, A_InstrCompo);

    if (found == FALSE)
    {
        MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
                     "FIN_TreatCumOption", 
                     GET_CODE(instrPtr, A_Instr_Cd), "composition");
        return(RET_FIN_ERR_INVDATA);
    }
    else
    {
        DBA_CopyDynSt(bondPtr, compoPtr, A_Instr);
        if (allocOk == TRUE) {FREE_DYNST(compoPtr, A_Instr);}
        return(RET_SUCCEED);
    }
}

/************************************************************************
**
**  Function    :   FIN_PeriodUnitNbr()
**
**  Description :   Compute events number in a year (expressed in received 
**                  output unit) depending on received frequence unit and 
**                  frequence number.
**                 
**  Arguments   :   freqUnit    Frequency unit (enum FREQUNIT_ENUM)
**                              unit Daily, DailyExceptHoliday, Weekly aren't
**                              accept
**                  freqNbr     Frequency number
**                  outUnit     Output frequency unit 
**                  freqPtr     Pointer on frequency to update
**
**  Return      :   RET_SUCCEED        and freqPtr is events number in one year
**                  RET_GEN_ERR_INVARG and freqPtr is 0
** Modification :  PMSTA-45526 - VSW - 080721  - Modifying the Datatype of Rate_freq_n of both Instrument and DatDisp Entities to Smallint from TinyInt
**
*************************************************************************/
RET_CODE FIN_PeriodUnitNbr(FREQUNIT_ENUM freqUnit, 
	                       SMALLINT_T     freqNbr, 
		                   FREQUNIT_ENUM outUnit, 
		                   double        *freqPtr)
{
    if (freqNbr == 0) 
    {
        *freqPtr = 0;
        return(RET_SUCCEED);
    }

    switch(outUnit)
    {
    case FreqUnit_None :
        *freqPtr = 0.0;
        break;

    case FreqUnit_Day :
        switch(freqUnit)
        {
        case FreqUnit_None :
            *freqPtr = 0.0;
            break;
        case FreqUnit_Day :
            *freqPtr = freqNbr;
            break;
        case FreqUnit_BusDay :
            *freqPtr = 0.0;
            break;
        case FreqUnit_Week :
            *freqPtr = freqNbr * 7;
            break;
        case FreqUnit_Month :
            *freqPtr = freqNbr * 30;
            break;
        case FreqUnit_Quarter :
            *freqPtr = freqNbr * 90;
            break;
        case FreqUnit_Semester :
            *freqPtr = freqNbr * 180;
            break;
        case FreqUnit_Year :
            *freqPtr = freqNbr * 360;
            break;
        default :
            MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, 
                         "FIN_PeriodUnitNbr", "frequency unit");
            return(RET_GEN_ERR_INVARG);
        }
        break;

    case FreqUnit_BusDay :
        *freqPtr = 0.0;
        break;

    case FreqUnit_Week :
        *freqPtr = 0.0;
        break;

    case FreqUnit_Month :
        switch(freqUnit)
        {
        case FreqUnit_None :
            *freqPtr = 0.0;
            break;
        case FreqUnit_Day :
            *freqPtr = 0.0;
            break;
        case FreqUnit_BusDay :
            *freqPtr = 0.0;
            break;
        case FreqUnit_Week :
            *freqPtr = 0.0;
            break;
        case FreqUnit_Month :
            *freqPtr = (double) freqNbr;
            break;
        case FreqUnit_Quarter :
            *freqPtr = freqNbr * 3.0;
            break;
        case FreqUnit_Semester :
            *freqPtr = freqNbr * 6.0;
            break;
        case FreqUnit_Year :
            *freqPtr = freqNbr * 12.0;
            break;
        default :
            MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, 
                         "FIN_PeriodUnitNbr", "frequency unit");
            return(RET_GEN_ERR_INVARG);
        }
        break;

    case FreqUnit_Quarter :
        switch(freqUnit)
        {
        case FreqUnit_None :
            *freqPtr = 0.0;
            break;
        case FreqUnit_Day :
            *freqPtr = 0.0;
            break;
        case FreqUnit_BusDay :
            *freqPtr = 0.0;
            break;
        case FreqUnit_Week :
            *freqPtr = 0.0;
            break;
        case FreqUnit_Month :
            *freqPtr = freqNbr / 3.0;
            break;
        case FreqUnit_Quarter :
            *freqPtr = (double) freqNbr;
            break;
        case FreqUnit_Semester :
            *freqPtr = freqNbr * 2.0;
            break;
        case FreqUnit_Year :
            *freqPtr = freqNbr * 4.0;
            break;
        default :
            MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, 
                         "FIN_PeriodUnitNbr", "frequency unit");
            return(RET_GEN_ERR_INVARG);
        }
        break;

    case FreqUnit_Semester :
        switch(freqUnit)
        {
        case FreqUnit_None :
            *freqPtr = 0.0;
            break;
        case FreqUnit_Day :
            *freqPtr = 0.0;
            break;
        case FreqUnit_BusDay :
            *freqPtr = 0.0;
            break;
        case FreqUnit_Week :
            *freqPtr = 0.0;
            break;
        case FreqUnit_Month :
            *freqPtr = freqNbr / 6.0;
            break;
        case FreqUnit_Quarter :
            *freqPtr = freqNbr / 2.0;
            break;
        case FreqUnit_Semester :
            *freqPtr = (double) freqNbr;
            break;
        case FreqUnit_Year :
            *freqPtr = freqNbr * 2.0;
            break;
        default :
            MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, 
                         "FIN_PeriodUnitNbr", "frequency unit");
            return(RET_GEN_ERR_INVARG);
        }
        break;

    case FreqUnit_Year :
        switch(freqUnit)
        {
        case FreqUnit_None :
            *freqPtr = 0.0;
            break;
        case FreqUnit_Day :
            *freqPtr = 0.0;
            break;
        case FreqUnit_BusDay :
            *freqPtr = 0.0;
            break;
        case FreqUnit_Week :
            *freqPtr = 0.0;
            break;
        case FreqUnit_Month :
            *freqPtr = freqNbr / 12.0;
            break;
        case FreqUnit_Quarter :
            *freqPtr = freqNbr / 4.0;
            break;
        case FreqUnit_Semester :
            *freqPtr = freqNbr / 2.0;
            break;
        case FreqUnit_Year :
            *freqPtr = (double) freqNbr;
            break;
        default :
            MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, 
                         "FIN_PeriodUnitNbr", "frequency unit");
            return(RET_GEN_ERR_INVARG);
        }
        break;

    default : 
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, 
                     "FIN_PeriodUnitNbr", "output frequency unit");
        return(RET_GEN_ERR_INVARG);
    }

    return(RET_SUCCEED);
}

/* < PMSTA-34912 - CHU - 190228 */
STATIC void FIN_DumpDomainAndLogOnEndlessLoop(DBA_HIER_HEAD_STP hierHead)
{
    DBA_DYNFLD_STP  objStp;
    FLAG_T          allocFlg;
    DICT_FCT_STP    dictFctInfo;
    CODE_T          ptfCd;
    OBJECT_ENUM		ptfDim;
    DBA_DYNFLD_STP	currDomainPtr = DBA_GetDomainPtr(DBA_GetConnectNoFromHier(hierHead));

    DBA_GetObjectEnum(GET_DICT(currDomainPtr, A_Domain_DimPtfDictId), &ptfDim);
    DBA_GetDictFctInfo((DICT_FCT_ENUM)(signed)GET_ID(currDomainPtr, A_Domain_FctDictId), DictFctInfo_Stp, &dictFctInfo);

    if (ptfDim == List)
    {
        if (DBA_GetListById(GET_ID(currDomainPtr, A_Domain_PtfObjId),
            FALSE,
            &allocFlg,
            &objStp,
            hierHead,
            UNUSED,
            UNUSED,
            UNUSED) == RET_SUCCEED &&
            objStp != NULL)
        {
            strcpy(ptfCd, GET_CODE(objStp, A_List_Cd));
        }
    }
    else
    {
        DBA_GetRecordCdById(Ptf, GET_ID(currDomainPtr, A_Domain_PtfObjId), ptfCd, (PTR)hierHead);
    }
    MSG_LogSrvMesg(UNUSED, UNUSED, "%1 : Aborting endless loop on %2", NameType, dictFctInfo->name, CodeType, ptfCd);
    MSG_DispDynStrDomainToSrvLogFile((PTR)currDomainPtr);

    return;
}
/* > PMSTA-34912 - CHU - 190228 */

/***************************************************************************************************
**
**  Function         : FIN_GenerateInstrFlows()
**
**  Description      : Retrieves all possible future flows of an instrument,
**                     indicating those that are optional and those that are 
**                     mutually exclusive, values them and returns them in
**                     a chronological order.
**                     Additionally it may determine the probabilty of the 
**                     occurence of optional events and determine amongst 
**                     mutually exclusive events which are the most likely.
**                 
**  Arguments        : fromDateTime  from date
**                     tillDateTime  end date
**                     valDateTime   value date
**                     instrId       instrument identifier
**                     inputInstrPtr pointer on instrument struct or NULL
**                     flowSubNatLst list of flow sub nature to generate
**                     genMode       generation mode (Automatic, Event, EventOp)
**                     evtDateRule   enum for event operation date rule in event generation
**                     accrRule      accrual rule given to INSTR_ACCR
**                     flowTab       pointer on flows array which will be 
**                                   allocated and filled up
**                     flowNbr       pointer on flows number which will be
**                                   filled up
**                     position      The current position. Can be null
**
**  Warning          : Call function must deallocated 'flowNbr' dynamic 
**                     structure and the flowTab pointer (macro FREE_FLOW)
**
**  Return           : RET_SUCCEED or error code
**
** Creation Date     : January 96 - XDI
**
** Modification      : DVP455  - RAK - 970505
** Modification      : REF2669 - 980819 - DDV
** Modification      : REF3939 - CSY - 991122: delete flows out of domain 
** Modification	     : REF1055 -  AKO - 991222 : check ADVA Licence and create new Flows 
**                     REF11218 - TEB - 050627
**
****************************************************************************************************/
RET_CODE FIN_GenerateInstrFlows(DATETIME_T              fromDateTime,
                                DATETIME_T              tillDateTime,
                                DATETIME_T              valDateTime,
                                FLAG_T                  noRefDateFlg,    /* PMSTA-9032 - RAK - 091216 */
                                ID_T                    instrId,
                                DBA_DYNFLD_STP          inputInstrPtr,
                                ENUMMASK_T                  flowSubNatLst,
                                EVTGEN_ENUM             genMode,
                                EVTDATERULE_ENUM        evtDateRule, /* REF4075 - 991022 - CSY */
                                FLAG_T                  domainDebtFlg,
                                GENINSTRFLOW_ENUM       genInstrFlowEn, /* REF8866 - YST - 030311 */
                                ACCRRULE_ENUM           accrRule,       /* REF11218 - TEB - 050627 */
                                DBA_DYNFLD_STP **       flowTab,
                                int *                   flowNbr,
                                DBA_HIER_HEAD_STP       hierHead,
                                const DBA_DYNFLD_STP    position)       /* PMSTA-32116 - 200818 - PMO */
{
    DBA_DYNFLD_STP      instrPtr=NULLDYNST;
    INSTRNAT_ENUM       instrNat;
    FLAG_T              allocOk;
    FLAG_T              any, incFxdRate, incFloatRate, incPaidDiv, incProjectDiv,
                        issPartialPaid, issFullyPaid, redmFinal, redmCall,
                        redmPut, redmSinking, redmCapReduc, debtProviPlan,
                        debtAmort, termTerm, exchConv, exchSplit,
                        exchReverseSplit, exchAttribStock, 
                        exchOptConvIss, exchOptConvHold, exchOther, 
                        propAttrib, theoPrice, 
                        confParamInc, confParamIss, confParamRedm, 
                        confParamDebt, confParamTerm, confParamExch,
                        IncCapitalToPayFlg, IncCapitalToRecFlg, /* REF6004 - AKO - 020207 */
                        RedemCapitalToPayFlg, RedemCapitalToRecFlg;
    ADAM_LICENCEE_ENUM  licenseEn=AdamLicencee_No;
    FLOWSUBNAT_ENUM     flowSubNat = FlowSubNat_Any;
    int                 i, j, flowNbrInput = 0, flowNbrTot = 0, lastPeriod = 0;
    RET_CODE            ret=RET_SUCCEED;
    int count           = 0; /* PMSTA-55798 - SRS - 12082024 */
    DATETIME_T          tempOptimalDate; /* PMSTA-55798 - SRS - 12082024 */

    *flowNbr = 0;
    *flowTab = NULL;

    /**** LOAD INSTRUMENT ****/
    /* If instrument structure was load upper, his pointer is given */
    /* in parameters list. So function use it and don't free it.    */
    if (inputInstrPtr != NULLDYNST)
    {
        instrPtr = inputInstrPtr;
        allocOk = FALSE;
    }
    else
    {
        /* REF3913 - 990819 - DDV */
        if (DBA_GetInstrById(instrId, FALSE, &allocOk, 
                             &instrPtr, NULL, UNUSED,UNUSED) != RET_SUCCEED)
        {
            return(RET_GEN_ERR_INVARG); /* ?? */
        }
    }

    flowNbrInput = *flowNbr;

    /* Flows depends on instrument nature */
    instrNat = (INSTRNAT_ENUM)GET_ENUM(instrPtr, A_Instr_NatEn);    /* REF7264 - CSY - 020130 */
    switch (instrNat)
    {
    case InstrNat_Bond :
    case InstrNat_CumOption :
    case InstrNat_ConvertBond : 
    case InstrNat_MoneyMkt :    /* REF9085 - YST - 030520 - new accrual rules */
        /* REF5938 - RAK - 010508 */
        /* Create new function FIN_NewBondFlows() and call it for bond and swap legs */
        /* REF7599 - YST - 020904 - add lastPeriod (not used in this function) */
        ret = FIN_NewBondFlows(fromDateTime, tillDateTime, valDateTime,
                                noRefDateFlg,	 /* PMSTA-9032 - RAK - 091216 */
                                instrPtr, evtDateRule, accrRule,	/* REF11218 - TEB - 050627 */
                                flowTab, flowNbr, &lastPeriod, hierHead, position);
        break;

    case InstrNat_Stock :
        ret = FIN_NewStockFlows(fromDateTime, tillDateTime, valDateTime,
                                instrPtr, evtDateRule, flowTab, flowNbr, hierHead); /*PMSTA-32106 -NRAO 180904*/
        break;

    case InstrNat_FundShare :
        ret = FIN_FundShareFlows(fromDateTime, tillDateTime, valDateTime,
                                 instrPtr, evtDateRule, flowTab, flowNbr, hierHead); /*PMSTA-32106 -NRAO 180904*/
        break;

    case InstrNat_Option :
        ret = FIN_OptionFlows(fromDateTime, tillDateTime, valDateTime,
                              instrPtr, evtDateRule, flowTab, flowNbr, hierHead); /* REF4075 - CSY - 991027 */
        break;

    case InstrNat_Future :			    /* REF1055 - AKO - 000504 : no license key */
            ret = FIN_FutureFlows(fromDateTime, tillDateTime, valDateTime,
                              instrPtr, evtDateRule, flowTab, flowNbr, hierHead);
        break;

    case InstrNat_FRA :
        if ((GEN_GetApplInfo(ApplAALicense, &licenseEn)==TRUE) && 
            (licenseEn>=AdamLicencee_Level2)) /* REF1055 - AKO - 000504 : license key */
        {
            ret = FIN_FutureFlows(fromDateTime, tillDateTime, valDateTime,
                              instrPtr, evtDateRule, flowTab, flowNbr, hierHead);
        }
        break;

    case InstrNat_Forward :
        ret = FIN_ForwardFlows(fromDateTime, tillDateTime,
                               instrPtr, flowTab, flowNbr, hierHead);
        break;

    case InstrNat_Debt :
        if (domainDebtFlg != FALSE)
            ret = FIN_DebtFlows(fromDateTime, tillDateTime, valDateTime, 
                                instrPtr, flowTab, flowNbr, hierHead);
        break;

    /* case InstrNat_MoneyMkt : *//* REF9085 - YST - 030520 - new accrual rules */ 
    case InstrNat_Discount :
        ret = FIN_MoneyMktFlows(fromDateTime, tillDateTime, valDateTime,
                                instrPtr, evtDateRule, flowTab, flowNbr, hierHead); /* REF4075 - CSY - 991027 */
        break;

    case InstrNat_CashAcct :
        /* BUG063 - XDI - 960723 don't generate flows for cash account */
        /* REF848 - DDV - 980318 - Cash account in journal and event generation */
        ret = FIN_CashAcctFlows(fromDateTime, tillDateTime, valDateTime, 
                                instrPtr, evtDateRule, flowTab, flowNbr, hierHead);
        break;

    /* DVP455 - RAK - 970505 */
    case InstrNat_Swap :
        if ((GEN_GetApplInfo(ApplAALicense, &licenseEn)==TRUE) && 
            (licenseEn>=AdamLicencee_Level1)) /* REF1055 - AKO - 991222 */
            ret = FIN_SwapFlows(fromDateTime, tillDateTime, valDateTime, 
                                noRefDateFlg,	 /* PMSTA-9032 - RAK - 091216 */                      
                                instrPtr, evtDateRule, genInstrFlowEn, flowTab, flowNbr, hierHead);
        break;

    /* REF053 - RAK - 980417 */
    case InstrNat_ForexSwaps :
        if ((GEN_GetApplInfo(ApplAALicense, &licenseEn)==TRUE) && 
            (licenseEn>=AdamLicencee_Level1)) /* REF1055 - AKO - 991222 */
            ret = FIN_ForexSwapFlows(fromDateTime, tillDateTime, valDateTime, 
                                     instrPtr, flowTab, flowNbr, hierHead);
        break;

    /* RE3140 - DDV - 000411 */
    case InstrNat_Other :
        ret = FIN_OtherFlows(fromDateTime, tillDateTime, valDateTime, 
                             instrPtr, evtDateRule, flowTab, flowNbr, hierHead);
        break;

    /* Nothing to do for this instrument nature */
    case InstrNat_Commodities :
    case InstrNat_Deliverables :
    case InstrNat_Idx :
    case InstrNat_Rate :
    case InstrNat_YieldCurve :
    case InstrNat_NotionalInstr:
        ret = RET_SUCCEED;
        break;

    /* Exoctics Options flows process : REF1055 - AKO - 991125 */
    case InstrNat_ExoticOptions: 
        ret = FIN_ExoticOptionFlows(fromDateTime, tillDateTime, valDateTime,
                                    instrPtr, evtDateRule, flowTab, flowNbr, hierHead); 
        break;
    /* REF6004 - AKO - 020206 : Generate flows for flow instruments */
    case InstrNat_FlowInstr: 
        ret = SCE_GenrFlowInstrFlowsByIncEvt( NULL, fromDateTime, tillDateTime, valDateTime, 
                                                instrPtr, evtDateRule, genInstrFlowEn, flowTab, flowNbr, hierHead);
        break;

    case InstrNat_None :
    default :
        char pszMsz[250];
        if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);} 
        /*  HFI-PMSTA-30345-180311  Display a message that allows debug facilities  */
        if (IS_NULLFLD(instrPtr, A_Instr_Cd) == FALSE)
            sprintf(&pszMsz[0],"instrument %s nature %d", GET_CODE(instrPtr, A_Instr_Cd), instrNat);
        else
            sprintf(&pszMsz[0],"instrument nature");
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "FIN_GenerateInstrFlows", pszMsz);
        return(RET_GEN_ERR_INVARG); 
    }

    /* < PMSTA-34912 - CHU - 190228 */
    if (RET_DBA_ERR_KRANOTFOUND == ret)
    {
        FIN_DumpDomainAndLogOnEndlessLoop(hierHead);
    }
    /* > PMSTA-34912 - CHU - 190228 */

    /* REF4075 - CSY - 991028 */
    if (evtDateRule == EvtDateRule_Term)
    {
        FIN_MostProbableEvt(instrPtr, flowTab, flowNbr, valDateTime, hierHead);
    }
    
        /* BUG2569 - AKO - 7/30/1998 */
    flowNbrTot = *flowNbr;

    any = (FLAG_T) GET_BIT64(flowSubNatLst, FlowSubNat_Any);

    if (any == FALSE)
    {
        incFxdRate       = (FLAG_T) GET_BIT64(flowSubNatLst, FlowSubNat_FxdRate);
        incFloatRate     = (FLAG_T) GET_BIT64(flowSubNatLst, FlowSubNat_FloatRate);
        incPaidDiv       = (FLAG_T) GET_BIT64(flowSubNatLst, FlowSubNat_PaidDiv);
        incProjectDiv    = (FLAG_T) GET_BIT64(flowSubNatLst, FlowSubNat_ProjectDiv);
        issPartialPaid   = (FLAG_T) GET_BIT64(flowSubNatLst, FlowSubNat_PartialPaidIss);
        issFullyPaid     = (FLAG_T) GET_BIT64(flowSubNatLst, FlowSubNat_FullyPaidIss);
        redmFinal        = (FLAG_T) GET_BIT64(flowSubNatLst, FlowSubNat_FinalRedm);
        redmCall         = (FLAG_T) GET_BIT64(flowSubNatLst, FlowSubNat_CallRedm);
        redmPut          = (FLAG_T) GET_BIT64(flowSubNatLst, FlowSubNat_PutRedm);
        redmSinking      = (FLAG_T) GET_BIT64(flowSubNatLst, FlowSubNat_SinkingRedm);
        redmCapReduc     = (FLAG_T) GET_BIT64(flowSubNatLst, FlowSubNat_CapReduc);
        debtProviPlan    = (FLAG_T) GET_BIT64(flowSubNatLst, FlowSubNat_ProviPlan);
        debtAmort        = (FLAG_T) GET_BIT64(flowSubNatLst, FlowSubNat_DebtAmort);
        termTerm         = (FLAG_T) GET_BIT64(flowSubNatLst, FlowSubNat_Term);
        exchConv         = (FLAG_T) GET_BIT64(flowSubNatLst, FlowSubNat_ConvExch);		/* XDI - DVP287 - 961129 */
        exchSplit        = (FLAG_T) GET_BIT64(flowSubNatLst, FlowSubNat_SplitExch);		/* XDI - DVP287 - 961129 */
        exchReverseSplit = (FLAG_T) GET_BIT64(flowSubNatLst, FlowSubNat_ReverseSplitExch);	/* XDI - DVP287 - 961129 */
        exchAttribStock  = (FLAG_T) GET_BIT64(flowSubNatLst, FlowSubNat_AttribStockExch);	/* XDI - DVP287 - 961129 */
        exchOptConvIss   = (FLAG_T) GET_BIT64(flowSubNatLst, FlowSubNat_OptConvIssExch);	/* XDI - DVP287 - 961129 */
        exchOptConvHold  = (FLAG_T) GET_BIT64(flowSubNatLst, FlowSubNat_OptConvHoldExch);	/* XDI - DVP287 - 961129 */
        exchOther        = (FLAG_T) GET_BIT64(flowSubNatLst, FlowSubNat_OtherExch);		/* XDI - DVP287 - 961129 */
        propAttrib       = (FLAG_T) GET_BIT64(flowSubNatLst, FlowSubNat_PropAttrib);		/* XDI - REF3470 - 990805 */
        theoPrice        = (FLAG_T) GET_BIT64(flowSubNatLst, FlowSubNat_AttribTheoPrice);	/* XDI - REF3470 - 990805 */
        IncCapitalToPayFlg =  (FLAG_T) GET_BIT64(flowSubNatLst, FlowSubNat_IncCapitalToPay);    /* REF6004 - AKO - 020207 */ 
        IncCapitalToRecFlg =  (FLAG_T) GET_BIT64(flowSubNatLst, FlowSubNat_IncCapitalToRec);    /* REF6004 - AKO - 020207 */
        RedemCapitalToPayFlg = (FLAG_T) GET_BIT64(flowSubNatLst, FlowSubNat_RedemCapitalToPay);   /* REF6004 - AKO - 020207 */
        RedemCapitalToRecFlg = (FLAG_T) GET_BIT64(flowSubNatLst, FlowSubNat_RedemCapitalToRec);   /* REF6004 - AKO - 020207 */

        for (i=flowNbrInput; i< *flowNbr; i++)
        {
            flowSubNat = (FLOWSUBNAT_ENUM)GET_FLAG((*flowTab)[i], Flow_SubNatEn);   /* REF7264 - CSY - 020130 */
    
            if (((incFxdRate == FALSE && flowSubNat == FlowSubNat_FxdRate) ||
                (incFloatRate == FALSE && flowSubNat == FlowSubNat_FloatRate) ||
                (incPaidDiv == FALSE && flowSubNat == FlowSubNat_PaidDiv) ||
                (incProjectDiv == FALSE && flowSubNat == FlowSubNat_ProjectDiv) ||
                (issPartialPaid == FALSE && flowSubNat == FlowSubNat_PartialPaidIss) ||
                (issFullyPaid == FALSE && flowSubNat == FlowSubNat_FullyPaidIss) ||
                (redmFinal == FALSE && flowSubNat == FlowSubNat_FinalRedm) ||
                (redmCall == FALSE && flowSubNat == FlowSubNat_CallRedm) ||
                (redmPut == FALSE && flowSubNat == FlowSubNat_PutRedm) ||
                (redmSinking == FALSE && flowSubNat == FlowSubNat_SinkingRedm) ||
                (redmCapReduc == FALSE && flowSubNat == FlowSubNat_CapReduc) ||
                (debtProviPlan == FALSE && flowSubNat == FlowSubNat_ProviPlan) ||
                (debtAmort == FALSE && flowSubNat == FlowSubNat_DebtAmort) ||
                (termTerm == FALSE && flowSubNat == FlowSubNat_Term) ||
                (exchConv == FALSE && flowSubNat == FlowSubNat_ConvExch) ||		     /* XDI - DVP287 - 961129 */
                (exchSplit == FALSE && flowSubNat == FlowSubNat_SplitExch) ||		     /* XDI - DVP287 - 961129 */
                (exchReverseSplit == FALSE && flowSubNat == FlowSubNat_ReverseSplitExch) ||  /* XDI - DVP287 - 961129 */
                (exchAttribStock == FALSE && flowSubNat == FlowSubNat_AttribStockExch) ||    /* XDI - DVP287 - 961129 */
                (exchOptConvIss == FALSE && flowSubNat == FlowSubNat_OptConvIssExch) ||	     /* XDI - DVP287 - 961129 */
                (exchOptConvHold == FALSE && flowSubNat == FlowSubNat_OptConvHoldExch) ||    /* XDI - DVP287 - 961129 */
                (exchOther == FALSE && flowSubNat == FlowSubNat_OtherExch) ||
                (propAttrib == FALSE && flowSubNat == FlowSubNat_PropAttrib) ||              /* REF3470 - DDV - 990805 */
                (theoPrice == FALSE && flowSubNat == FlowSubNat_AttribTheoPrice) ||          /* REF3470 - DDV - 990805 */
                (IncCapitalToPayFlg == FALSE && flowSubNat == FlowSubNat_IncCapitalToPay) ||        /* REF6004 - AKO - 020207 */ 
                (IncCapitalToRecFlg == FALSE && flowSubNat == FlowSubNat_IncCapitalToRec) ||        /* REF6004 - AKO - 020207 */ 
                (RedemCapitalToPayFlg == FALSE && flowSubNat == FlowSubNat_RedemCapitalToPay) ||    /* REF6004 - AKO - 020207 */ 
                (RedemCapitalToRecFlg == FALSE && flowSubNat == FlowSubNat_RedemCapitalToRec)) &&    /* REF6004 - AKO - 020207 */
                !FIN_IsCAExchangeEventFlow(flowSubNat))                                      /* PMSTA-36248 - SGO - 290819 */

            {
                FREE_DYNST((*flowTab)[i], Flow);
                (*flowNbr)--;
                
                for (j=i; j<*flowNbr; j++)
                {(*flowTab)[j] = (*flowTab)[j+1];}
                i--; /* array has been shifted to left */
            }
        }
    }

    /* REF3939 - CSY - 991122: delete flows out of domain */
    for (i = 0; i < *flowNbr; i++)
    {
        flowSubNat = static_cast<FLOWSUBNAT_ENUM>(GET_FLAG((*flowTab)[i], Flow_SubNatEn));
        if ((DATETIME_CMP(GET_DATETIME((*flowTab)[i], Flow_OptimalDate), tillDateTime) > 0 ||
            DATETIME_CMP(GET_DATETIME((*flowTab)[i], Flow_OptimalDate), fromDateTime) < 0) &&
            FlowSubNat_ConvExch != flowSubNat &&    /* PMSTA-37786 - 191112 - sanand */
            !FIN_IsCAExchangeEventFlow(flowSubNat)) /* PMSTA-36248 - SGO - 290819 */
        {
            FREE_DYNST((*flowTab)[i], Flow);
            (*flowNbr)--;

            for (j = i; j < *flowNbr; j++)
            {
                (*flowTab)[j] = (*flowTab)[j + 1];
            }
            i--;
        }
    }

    /* PMSTA-55798 - SRS - 12082024: delete flows out of domain in case of full redemption */
    for (i = 0; i < *flowNbr; i++)
    {
        flowSubNat = static_cast<FLOWSUBNAT_ENUM>(GET_FLAG((*flowTab)[i], Flow_SubNatEn));
        if ((flowSubNat == FlowSubNat_FinalRedm))
        {
            count ++;
            tempOptimalDate = GET_DATETIME((*flowTab)[i], Flow_OptimalDate);

            if ((count > 1) &&
                (DATETIME_CMP(GET_DATETIME((*flowTab)[i], Flow_OptimalDate), tempOptimalDate) == 0))
            {
                FREE_DYNST((*flowTab)[i], Flow);
                (*flowNbr)--;

                for (j = i; j < *flowNbr; j++)
                {
                    (*flowTab)[j] = (*flowTab)[j + 1];
                }
                i--;
            }
        }
    }
    /* default value for confirmed flag is TRUE when a flow is generate */
    /* if generation is not automatic set value with applparam default value */
    if (genMode != EvtGen_Automatic)
    {
        GEN_GetApplInfo(ApplEvtGenIncConfFlag , &confParamInc);
        GEN_GetApplInfo(ApplEvtGenIssConfFlag , &confParamIss);
        GEN_GetApplInfo(ApplEvtGenRedmConfFlag , &confParamRedm);
        GEN_GetApplInfo(ApplEvtGenDebtConfFlag , &confParamDebt);
        GEN_GetApplInfo(ApplEvtGenTermConfFlag , &confParamTerm);
        GEN_GetApplInfo(ApplEvtGenExchConfFlag , &confParamExch);

        for (i=flowNbrInput; i< *flowNbr; i++)
        {
            switch (GET_FLAG((*flowTab)[i], Flow_NatEn))
            {
                case FlowNat_Inc:
                    if (confParamInc == FALSE)
                        SET_FLAG((*flowTab)[i], Flow_ConfirmedFlg, FALSE);
                    break;
                case FlowNat_Iss:
                    if (confParamIss == FALSE)
                        SET_FLAG((*flowTab)[i], Flow_ConfirmedFlg, FALSE);
                    break;
                case FlowNat_Redm:
                    if (confParamRedm == FALSE)
                        SET_FLAG((*flowTab)[i], Flow_ConfirmedFlg, FALSE);
                    break;
                case FlowNat_Debt:
                    if (confParamDebt == FALSE)
                        SET_FLAG((*flowTab)[i], Flow_ConfirmedFlg, FALSE);
                    break;
                case FlowNat_Term:
                    if (confParamTerm == FALSE)
                        SET_FLAG((*flowTab)[i], Flow_ConfirmedFlg, FALSE);
                    break;
                case FlowNat_Exch:
                    if (confParamExch == FALSE)
                        SET_FLAG((*flowTab)[i], Flow_ConfirmedFlg, FALSE);
                    break;
            }
        }
    }

    if (flowNbrTot != 0 && flowNbrTot != *flowNbr)
    {
        if (*flowNbr > 0)
        {
            if (((*flowTab) = (DBA_DYNFLD_STP *) REALLOC(
                     (*flowTab), *flowNbr * sizeof(DBA_DYNFLD_STP))) == 
                     (DBA_DYNFLD_STP *) NULL)
            {
                if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);} 
                MSG_RETURN(RET_MEM_ERR_ALLOC);
            }
        }
        else
        {
            FREE(*flowTab);
        }
    }
    else
    {
        /* REF3990 - SSO - 000406  Free array if no flows (is not done in FIN_JournalProcess)*/
        if (*flowNbr == 0 && *flowTab != NULL)
        {
        FREE(*flowTab);
        }
    }

    if (allocOk == TRUE) {FREE_DYNST(instrPtr, A_Instr);} 
    return(ret);
}

/************************************************************************
* 
*   Function          : FIN_OptionFlows()
*       
*   Description       : Retrieves all possible future flows of an option.
*                       Use term contract events from the begin reference data
*                       to the ende reference date and fill flow structure.
*                  
*   Arguments         : fromDateTime  from date
*                       tillDateTime  end date
*                       valDateTime   
*                       inputInstrPtr pointer on instrument struct or NULL  
*                       evtDateRule   enum used in event generation domain to specify the event operation date rule
*                       flowTab       pointer on flows array which will be 
*                                     allocated and filled up
*                                     (initialised to NULL by FIN_GenerateInstrFlows())
*                       flowNbr       pointer on flows number which will be
*                                     filled up 
*                                     (initialised to 0 by FIN_GenerateInstrFlows())
* 
*   Warning           : Calling function is FIN_GenerateInstrFlows()
* 
*   Return            : RET_SUCCEED or error code
* 
*   Creation Date     : April 95 - RAK
*   Last modification : 03.07.95 - PEC
*   Last modification : 24.08.95 - RAK (begin and end dates)
*
*   modification      : REF2569 - AKO - 980818
*   modification      : REF3542 - AKO - 990415 : purify -> free memory no more used
*   modification      : REF4075 - CSY - 991022 : new argument containing method selected (term,early) to set the operation optimal date 
*   modification      : REF4075 - CSY - 991209 : evt date rule management only if american or bermudan option
*                       REF4075 - CSY - 991215 : case where term event end date is after till but with earliest
                                                 rule specified so that flow comes into domain period.
*			REF3990 - SSO - 000406 : modified ERROR MANAGEMENT !!! be careful if further modification 
*  
*************************************************************************/
STATIC RET_CODE FIN_OptionFlows(DATETIME_T        fromDateTime,  
                DATETIME_T        tillDateTime,
                DATETIME_T        valDateTime,
                DBA_DYNFLD_STP    instrPtr,
                EVTDATERULE_ENUM  evtDateRule,
                DBA_DYNFLD_STP    **flowTab,
                int               *flowNbr,
                DBA_HIER_HEAD_STP hierHead)
{
    DBA_DYNFLD_STP   flowSt=NULLDYNST, termEvt=NULLDYNST;
    RET_CODE         ret;
    DAY_T            svEndD;
    char             endMFlg;
    int              allocSz=0, reallocSz=5, currPeriod; 
    double           freq;
    DATETIME_T       begDate, endDate;
    /* REF4075 - CSY - 991210: not traumatize customers
    set to FALSE to keep the old behaviour (3.40), TRUE = manage the frequency */
    FLAG_T           freqManagement = FALSE;    

    /************** EXCHANGE FLOWS ************/
        /* generate flows for exchange events */
    FIN_CreateExchangeFlows(instrPtr, fromDateTime, &tillDateTime, valDateTime, 
                            evtDateRule, &allocSz, flowNbr, flowTab, hierHead); /* REF4075 - CSY - 991027 */

    /* Read term event */
    if ((termEvt = ALLOC_DYNST(A_TermEvt)) == NULLDYNST)
        MSG_RETURN(RET_MEM_ERR_ALLOC);

    /************** TERM FLOWS (last ones) ************/
    /* REF3990 - SSO - 000406 : if minor error for term evt flows, stop but return succeed */
    if ((ret = DBA_GetTermEvt(instrPtr, valDateTime.date, termEvt)) != RET_SUCCEED)
    {
        FREE_DYNST(termEvt, A_TermEvt);
        RET_GENFLOWS(ret); /* REF3990 - SSO - 000406 */
    }

    begDate.time = 0;
    endDate.time = 0;

    FIN_PeriodUnitNbr((FREQUNIT_ENUM)GET_ENUM(termEvt, A_TermEvt_FreqUnitEn), /* REF7264 - CSY - 020130 */
                      GET_TINYINT(termEvt, A_TermEvt_Freq), 
                      FreqUnit_Month, &freq);

    if (GET_DATE(termEvt, A_TermEvt_EndDate) < fromDateTime.date)
    {
        MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
                     "FIN_OptionFlows", GET_CODE(instrPtr, A_Instr_Cd), "end date");
        FREE_DYNST(termEvt, A_TermEvt);		/* REF3542 - AKO - 990415 */
        return(RET_SUCCEED); /* REF3990 - SSO - 000406 RET_FIN_ERR_INVDATA->minor error */
    }

    begDate.date = GET_DATE(termEvt, A_TermEvt_BeginDate);
    /* end date was set with A_TermEvt_BegDate, */
    /* change to set it with A_TermEvt_EndDate (XDI 960417) */
    /* CSY 991117 : yes but only if freq = 0, otherwise, 
    the periodicity management would never be possible */
    if ((freq == 0)||(freqManagement == FALSE)) /* REF4075 - CSY - 991210: old behaviour*/ 
        endDate.date = GET_DATE(termEvt, A_TermEvt_EndDate);
    else
        endDate.date = GET_DATE(termEvt, A_TermEvt_BeginDate);
       
    /* Short month can corrupt day number */
    endMFlg = (char) DATE_IsLastInMonth(endDate.date);
    DATE_Get(endDate.date, (YEAR_T *) NULL, (MONTH_T *) NULL, &svEndD);

    if (endDate.date == BAD_DATE)
    {
        FREE_DYNST(termEvt, A_TermEvt);
        MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
                 "FIN_OptionFlows", GET_CODE(instrPtr, A_Instr_Cd), "end date");
        return(RET_SUCCEED); /* REF3990 - SSO - 000406 RET_FIN_ERR_INVDATA->minor error */
    }

    /* Advance in repetitive event until journal begin date */
    currPeriod = 1;
    /* CSY 991117: if freq=0, this loop is not executed because the term event 
    end date, at this level would be higher than the from date (otherwise, we would
    have exited above) and endDate would be set to this date.*/
    while (endDate.date < fromDateTime.date)
    {
        begDate = endDate;
        {
        endDate.date = DATE_Move(begDate.date, (int)freq, Month);
        /* Short month can corrupt day number */
        DATE_VerifyEndMonth(&endDate.date, svEndD, endMFlg);
        }
        ++currPeriod;
    }

    /* For each period in current income event */
    /* (one in case of no repetitive event) */
    while (endDate.date <= GET_DATE(termEvt, A_TermEvt_EndDate) &&
           (endDate.date <= tillDateTime.date ||
           /* REF4075 - CSY - 991216 : even if the term event date may be after till date 
           we should see the flow if it comes in domain with earliest rule */
           (begDate.date <= tillDateTime.date && evtDateRule == EvtDateRule_Earliest &&
           (GET_ENUM(termEvt,A_TermEvt_OptStyleEn) == OptStyle_American ||
           GET_ENUM(termEvt,A_TermEvt_OptStyleEn) == OptStyle_Bermudan))) 
           )
    {
        if (allocSz == 0 || *flowNbr >= allocSz-1) /* DVP384 - XDI - 970314 */
        {
            allocSz+=reallocSz;
            if (((*flowTab) = (DBA_DYNFLD_STP *) REALLOC((*flowTab), 
                                                     allocSz * sizeof(DBA_DYNFLD_STP))) 
                      == (DBA_DYNFLD_STP*)NULL)
            {
                FREE_DYNST(termEvt, A_TermEvt); /* REF2569 - AKO - 980818 */
                MSG_RETURN(RET_MEM_ERR_ALLOC);
            }
        }

        if (((*flowTab)[*flowNbr] = ALLOC_DYNST(Flow)) == NULLDYNST)
        {
            FREE_DYNST(termEvt, A_TermEvt); /* REF2569 - AKO - 980818 */
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        flowSt = (*flowTab)[*flowNbr];

        SET_ID(flowSt,       Flow_InstrId,      GET_ID(instrPtr, A_Instr_Id));
        SET_CODE(flowSt,     Flow_EvtCd,        GET_CODE(termEvt, A_TermEvt_Cd));
        SET_INT(flowSt,      Flow_EvtNbr,       currPeriod); /* REF8844 - LJE - 030327 */
        SET_ENUM(flowSt,     Flow_NatEn,        FlowNat_Term);
        SET_FLAG(flowSt,     Flow_ConfirmedFlg, TRUE);
    
        SET_DATETIME(flowSt, Flow_BegPayDate,   begDate);

        SET_PERIOD(flowSt,   Flow_SettlDays,    GET_TINYINT(termEvt, A_TermEvt_SettleDays));
        SET_DATETIME(flowSt, Flow_EndPayDate,   endDate);
        SET_DATETIME(flowSt, Flow_OptimalDate,  endDate);
        
        /* REF4075 - CSY - 991022  */
        /* REF4075 - CSY - 991209: only for american and bermudan options */
        if ((GET_ENUM(termEvt,A_TermEvt_OptStyleEn)== OptStyle_American)||
        (GET_ENUM(termEvt,A_TermEvt_OptStyleEn)== OptStyle_Bermudan))
        {
        switch (evtDateRule)
        {
        case EvtDateRule_Term:  /* present behaviour ("term"): 
                       optimal date = end date found in instrument flow */
            SET_DATETIME(flowSt, Flow_OptimalDate, endDate);
            break;
        case EvtDateRule_Earliest: /* new behaviour ("next date") */
                if (DATETIME_CMP(valDateTime, begDate) <= 0) 
            {
            SET_DATETIME(flowSt, Flow_OptimalDate, begDate);
            }
            else
            {
            SET_DATETIME(flowSt, Flow_OptimalDate, valDateTime);
            }
            break;
        }
        }
        /*end CSY*/

        COPY_DYNFLD(flowSt, Flow, Flow_OptimalValDate, flowSt, Flow, Flow_OptimalDate);

        SET_NULL_PERCENT(flowSt,  Flow_IoRPrct);
	    SET_PRICE(flowSt,        Flow_Quote,     GET_PRICE(termEvt, A_TermEvt_ExerQuote));
        SET_NUMBER(flowSt,        Flow_RefQty,    1);

        /* If end Date of term contract is equal to end date of  */
        /* current period, we are on the last period of the term */
        if (GET_DATE(termEvt, A_TermEvt_EndDate) == endDate.date)
        {	SET_FLAG(flowSt, Flow_ReplaceFlg, TRUE); }
        else
        {	SET_FLAG(flowSt, Flow_ReplaceFlg, FALSE); }

        SET_ID(flowSt, Flow_NewInstrId, GET_ID(termEvt, A_TermEvt_UnderlyInstrId));

        /* REF9805 - RAK - 050106 - GET_ID(termEvt, A_TermEvt_UnderQty) was wrong */
        if (IS_NULLFLD(termEvt, A_TermEvt_UnderlyQty) == TRUE ||
            CMP_NUMBER(GET_NUMBER(termEvt, A_TermEvt_UnderlyQty), 0) == 0)
        {
            SET_NUMBER(flowSt, Flow_QtyUnit, 1);
        }
        else
        {
            SET_NUMBER(flowSt, Flow_QtyUnit,
                GET_NUMBER(termEvt, A_TermEvt_UnderlyQty));
        }

	    SET_PRICE(flowSt, Flow_AmtUnit, 
		GET_PRICE(termEvt, A_TermEvt_ExerPrice));
        SET_ID(flowSt, Flow_AmtCurrId, GET_ID(termEvt, A_TermEvt_CurrId));

        SET_ENUM(flowSt,    Flow_OptClassEn, GET_ENUM(termEvt, A_TermEvt_OptionClassEn));
        SET_ENUM(flowSt,    Flow_OptStyleEn, GET_ENUM(termEvt, A_TermEvt_OptStyleEn));
        SET_PERCENT(flowSt, Flow_Proba,      100.0);

        SET_TINYINT(flowSt,   Flow_Freq,         GET_TINYINT(termEvt, A_TermEvt_Freq));
        SET_ENUM(flowSt,      Flow_FreqUnitEn,   GET_ENUM(termEvt, A_TermEvt_FreqUnitEn));
        SET_EXCHANGE(flowSt,  Flow_FxdExchRate,  GET_EXCHANGE(termEvt, A_TermEvt_FixedExchRate));
        SET_NUMBER(flowSt,    Flow_CtdConvFact,  GET_NUMBER(termEvt, A_TermEvt_CtdConvFact));
        SET_NUMBER(flowSt,    Flow_CtdConvRatio, GET_NUMBER(termEvt, A_TermEvt_CtdConvRatio));
        SET_ID(flowSt,        Flow_CtdInstrId,   GET_ID(termEvt, A_TermEvt_CheapestInstrId));
        SET_FLAG(flowSt,      Flow_PhysicalFlg,  GET_FLAG(termEvt, A_TermEvt_PhysicalFlg));
        SET_ENUM(flowSt,      Flow_SubNatEn,     FlowSubNat_Term);

        SET_NULL_DATE(flowSt,    Flow_ExDate);
        SET_NULL_TINYINT(flowSt, Flow_Priority);
        SET_FLAG(flowSt,         Flow_EffectiveFlg, FALSE);

        (*flowNbr)++;
        currPeriod++;
        begDate = endDate;

        /* Get next period */
        if ((freq == 0.) || /* No repetitive event, stop */
        (freqManagement == FALSE))    /* REF4075 - CSY - 991216 */     
            endDate.date = DATE_Move(endDate.date, 1, Day); 
        else
        {
            endDate.date = DATE_Move(begDate.date, (int)freq, Month);
            /* Short month can corrupt day number */
            DATE_VerifyEndMonth(&endDate.date, svEndD, endMFlg);
        }
    }

    /* Free allocated struct. */
    FREE_DYNST(termEvt, A_TermEvt);

    return(RET_SUCCEED);
}

/************************************************************************
* 
*   Function          : FIN_ForwardFlows()
* 
*   Description       : Retrieves all possible future flows of an forward.
*                       Work on an instument create by a generic instrument
*                       Use term contract events from the begin reference data
*                       to the end reference date and fill flow structure.
*                  
*   Arguments         : fromDateTime  from date
*                       tillDateTime  end date
*                       inputInstrPtr pointer on instrument struct or NULL
*                       flowTab       pointer on flows array which will be 
*                                     allocated and filled up
*                                     (initialised to NULL by FIN_GenerateInstrFlows())
*                       flowNbr       pointer on flows number which will be
*                                     filled up
*                                     (initialised to 0 by FIN_GenerateInstrFlows())
* 
*   Warning           : Calling function is FIN_GenerateInstrFlows()
* 
*   Return            : RET_SUCCEED 
*                       RET_MEM_ERR_ALLOC
*                       RET_GEN_ERR_INVARG
* 
*   Creation date     : April 95 - RAK
*   Last modification : 28.06.95 - PEC
*
*   Modification      : REF2569 - AKO - 980818
*			REF3990 - SSO - 000406 : modified ERROR MANAGEMENT !!! be careful if further modification 
* 
*************************************************************************/
STATIC RET_CODE FIN_ForwardFlows(DATETIME_T        fromDateTime, 
                                 DATETIME_T        tillDateTime,
                         DBA_DYNFLD_STP    instrPtr,
                                 DBA_DYNFLD_STP    **flowTab,
                                 int               *flowNbr,
                                 DBA_HIER_HEAD_STP hierHead)
{
    DBA_DYNFLD_STP	flow=NULLDYNST, underPtr=NULLDYNST;
    DATETIME_T     	date;
    FLAG_T          allocOk = FALSE;

    /************** TERM EVT FLOWS (last ones) ************/
    date.time = 0;

    *flowNbr = 1;
    if (((*flowTab) = (DBA_DYNFLD_STP *)
         CALLOC(*flowNbr,sizeof(DBA_DYNFLD_STP))) == (DBA_DYNFLD_STP*) NULL)
        MSG_RETURN(RET_MEM_ERR_ALLOC);

    if (((*flowTab)[0] = ALLOC_DYNST(Flow)) == NULLDYNST)
        MSG_RETURN(RET_MEM_ERR_ALLOC); /* REF2569 - AKO - 980818 */

    /* If end date isn't specified, it's impossible to generate flow */
    if (IS_NULLFLD(instrPtr, A_Instr_EndDate) == TRUE ||
            GET_DATE(instrPtr, A_Instr_EndDate) == MAGIC_END_DATE)	/* BUG208 */
    {
        MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO,    /* REF2569 - AKO - 980818 */ 
                 "FIN_ForwardFlows", GET_CODE(instrPtr, A_Instr_Cd), "end date");
            /* REF3990 - SSO - 000406 remove last flows */
        FREE_DYNST((*flowTab)[0], Flow);
        *flowNbr = 0;
        return(RET_SUCCEED); /* REF3990 - SSO - 000406 RET_FIN_ERR_INVDATA->minor error */
    }

    if (tillDateTime.date < GET_DATE(instrPtr, A_Instr_EndDate) ||
        fromDateTime.date > GET_DATE(instrPtr, A_Instr_EndDate))
    {
            /* REF3990 - SSO - 000406 remove last flows */
        FREE_DYNST((*flowTab)[0], Flow);
        *flowNbr = 0;
            return(RET_SUCCEED); /* REF2569 - AKO - 980818 */
    }

    flow = (*flowTab)[0];
    SET_ID(flow,             Flow_InstrId,        GET_ID(instrPtr, A_Instr_Id)); 
    SET_NULL_CODE(flow,      Flow_EvtCd);         
    SET_INT(flow,            Flow_EvtNbr,         1);         /* REF8844 - LJE - 030327 */
    SET_ENUM(flow,           Flow_NatEn,          FlowNat_Term);
    SET_FLAG(flow,           Flow_ConfirmedFlg, TRUE);

    date.date = GET_DATE(instrPtr, A_Instr_BeginDate);
    SET_DATETIME(flow,  Flow_BegPayDate,     date);

    SET_PERIOD(flow,         Flow_SettlDays,      GET_PERIOD(instrPtr, A_Instr_SettleDay));

    date.date = GET_DATE(instrPtr, A_Instr_EndDate);
    SET_DATETIME(flow,  Flow_EndPayDate,     date);
    SET_DATETIME(flow,  Flow_OptimalDate,    date);

    /*date.date = DATE_Move(GET_DATE(flow, Flow_OptimalDate), 
                  GET_PERIOD(flow, Flow_SettlDays), Day);*/
    date.date = GET_DATE(flow, Flow_OptimalDate); /* REF1193 - DDV - 980319 */
    SET_DATETIME(flow,  Flow_OptimalValDate, date);

    SET_NULL_PERCENT(flow, Flow_IoRPrct);
    SET_NUMBER(flow,       Flow_RefQty,     1.0);
    SET_FLAG(flow,         Flow_ReplaceFlg, TRUE);
    SET_NULL_ENUM(flow,    Flow_OptClassEn);
    SET_NULL_ENUM(flow,    Flow_OptStyleEn);
    SET_PERCENT(flow,      Flow_Proba,      100.0);
	/*instrAmt = GET_PRICE(instrPtr, A_Instr_RedempPrice);*/

    /* BEGIN MODIF : 15/01/1996 adjustment operation don't exist */
    /* NEW CODE */
    /* REF3913 - DDV - 991006 */
    if (DBA_GetInstrById(GET_ID(instrPtr, A_Instr_UnderlyInstrId), FALSE, 
                                &allocOk, &underPtr, hierHead, UNUSED, UNUSED) != RET_SUCCEED)
    {
        SYSNAME_T entSqlName;
        strcpy(entSqlName, DBA_GetDictEntitySqlName(Instr));
        MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, 
                 entSqlName, GET_ID(instrPtr, A_Instr_UnderlyInstrId));
         /* REF3990 - SSO - 000406 Ok, we keep this case in fatal error... */
        return(RET_DBA_ERR_NODATA); /* ?? */
    }

    /* PMSTA-52091 - DDV - 230208 - Set instr_flow's price and quote with spot exchange rate between both currency of the fwd */
    if (GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_FXFwd_TwoLegsAgainsPtfCurr)
    {
        EXCHANGE_T         fwdSpotExchRate = 0.0;
        FIN_EXCHARG_ST     exchArgSt;
        memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));

        FIN_GetExchRate(GET_DATETIME(flow, Flow_OptimalDate),
                        GET_ID(instrPtr, A_Instr_RefCurrId),
                        GET_ID(underPtr, A_Instr_RefCurrId),
                        (ID_T)0, NULL, NULLDYNST, &exchArgSt, &fwdSpotExchRate);


        SET_PRICE(flow, Flow_AmtUnit, fwdSpotExchRate);
        SET_PRICE(flow, Flow_Quote, fwdSpotExchRate);
        SET_ID(flow, Flow_AmtCurrId, GET_ID(instrPtr, A_Instr_RefCurrId));
        SET_ID(flow, Flow_NewInstrId, GET_ID(instrPtr, A_Instr_UnderlyInstrId));
    }
    else
    {
        SET_PRICE(flow, Flow_AmtUnit, GET_PRICE(instrPtr, A_Instr_RedempPrice));
        SET_PRICE(flow, Flow_Quote, GET_PRICE(instrPtr, A_Instr_RedempQuote));
        SET_ID(flow, Flow_AmtCurrId, GET_ID(instrPtr, A_Instr_ExerCurrId));
        SET_ID(flow, Flow_NewInstrId, GET_ID(instrPtr, A_Instr_UnderlyInstrId));
    }

    SET_NUMBER(flow, Flow_QtyUnit, 1);

    if (allocOk == TRUE) {FREE_DYNST(underPtr, A_Instr);}
    /* END MODIF : 15/01/1996 */

	SET_TINYINT(flow,        Flow_Freq,          GET_TINYINT(instrPtr, A_Instr_PayFreq));
	SET_ENUM(flow,           Flow_FreqUnitEn,    GET_ENUM(instrPtr, A_Instr_PayFreqUnitEn));
	SET_NULL_DATE(flow,      Flow_ExDate);
	SET_NULL_EXCHANGE(flow,  Flow_FxdExchRate);  /* ?? */
	SET_NULL_NUMBER(flow,    Flow_CtdConvFact);  /* ?? */
	SET_NULL_NUMBER(flow,    Flow_CtdConvRatio); /* ?? */
	SET_NULL_ID(flow,        Flow_CtdInstrId);   /* ?? */
    COPY_DYNFLD(flow, Flow, Flow_PhysicalFlg, instrPtr, A_Instr, A_Instr_PhysicalFlg); /* PMSTA-52091 - DDV - 230228 */
    SET_NULL_TINYINT(flow,   Flow_Priority);
	SET_FLAG(flow,           Flow_EffectiveFlg,  FALSE);
	SET_ENUM(flow,           Flow_SubNatEn,      FlowSubNat_Term);

    return(RET_SUCCEED);
}

/************************************************************************
* 
*   Function          : FIN_FutureFlows()
* 
*   Description       : Retrieves all possible future flows of an future.
*                       Work on an instument create by a generic instrument
*                       Use term contract events from the begin reference data
*                       to the end reference date and fill flow structure.
*                  
*   Arguments         : fromDateTime  from date
*                       tillDateTime  end date
*                       valDateTime
*                       inputInstrPtr pointer on instrument struct or NULL
*                       evtDateRule   enum used in event generation domain to 
*				      specify the event operation date rule
*                       flowTab       pointer on flows array which will be 
*                                     allocated and filled up
*                                     (initialised to NULL by FIN_GenerateInstrFlows())
*                       flowNbr       pointer on flows number which will be
*                                     filled up
*                                     (initialised to 0 by FIN_GenerateInstrFlows())
* 
*   Warning           : Calling function is FIN_GenerateInstrFlows()
* 
*   Return            : RET_SUCCEED 
*                       RET_MEM_ERR_ALLOC
*                       RET_GEN_ERR_INVARG
* 
*   Creation date     : April 95 - RAK
*   Last modification : 29.06.95 - PEC
*   Last modification : DVP440 - RAK - 970502
*   Last modification : REF2852 - RAK - 990111
*   Last modification : REF4075 - CSY - 991027
*		      : REF1055 - AKO - 991117     
*			REF3990 - SSO - 000406 : modified ERROR MANAGEMENT !!! be careful if further modification 
* 
*************************************************************************/
STATIC RET_CODE FIN_FutureFlows(DATETIME_T     fromDateTime, 
                    DATETIME_T     tillDateTime,
                    DATETIME_T     valDateTime,
                DBA_DYNFLD_STP instrPtr,
                EVTDATERULE_ENUM   evtDateRule, /* REF4075 - CSY - 991027 */
                    DBA_DYNFLD_STP **flowTab,
                    int            *flowNbr,
                                DBA_HIER_HEAD_STP hierHead)
{
    DBA_DYNFLD_STP      flow=NULLDYNST, pricePtr=NULLDYNST, termEvtPtr=NULLDYNST; 
	PRICE_T             price=0.0, quote=0.0;
    DATETIME_T          date;
    ID_T		        instrId, calendarId=0;
    FUTJRNLRULE_ENUM    ruleForFuture=FutJrnlRule_NotInJrnl;
    RET_CODE            ret=RET_SUCCEED;
    int	                allocSz=0, reallocSz=5;
    FIN_PRICEARG_ST	    priceArgSt;	/* REF2852 */
    DATETIME_T	        expirDate;
    ADAM_LICENCEE_ENUM  licenseEn=AdamLicencee_No;


    /************** EXCHANGE FLOWS ************/
    /* generate flows for exchange events */
    FIN_CreateExchangeFlows(instrPtr, fromDateTime, &tillDateTime, valDateTime, 
                evtDateRule, &allocSz, flowNbr, flowTab, hierHead); /* REF4075 - CSY - 991027 */

    /************** TERM FLOWS (last ones) ************/
    /* Get Future Rule for Journal */
    GEN_GetApplInfo(ApplFutureJrnlRule, &ruleForFuture);
        
    if (ruleForFuture == FutJrnlRule_NotInJrnl)
        return(RET_SUCCEED);

    /* Margin call case */
    if (ruleForFuture == FutJrnlRule_NextDay)
    {
        SET_DATE(instrPtr, A_Instr_EndDate, GET_DATE(instrPtr, A_Instr_BeginDate));
    }

    date.time = 0;

    /* If end date isn't specified, it's impossible to generate flow */
    if (IS_NULLFLD(instrPtr, A_Instr_EndDate) == TRUE ||
            GET_DATE(instrPtr, A_Instr_EndDate) == MAGIC_END_DATE)	/* BUG208 */
    {
        MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
                 "FIN_FutureFlows", GET_CODE(instrPtr, A_Instr_Cd), "end date");
        return(RET_SUCCEED); /* REF3990 - SSO - 000406 RET_FIN_ERR_INVDATA->minor error */ 
    }

    if (tillDateTime.date < GET_DATE(instrPtr, A_Instr_EndDate) ||
        fromDateTime.date > GET_DATE(instrPtr, A_Instr_EndDate))
    {
        return(RET_SUCCEED);
    }

    if (allocSz == 0 || *flowNbr >= allocSz-1)
    {
        allocSz+=reallocSz;
        if (((*flowTab) = (DBA_DYNFLD_STP*) REALLOC((*flowTab), 
                       allocSz * sizeof(DBA_DYNFLD_STP))) 
                              == (DBA_DYNFLD_STP *) NULL)
        {
            MSG_RETURN(RET_MEM_ERR_ALLOC); /* REF2569 - AKO - 980818 */
        }
    }

    if (((*flowTab)[*flowNbr] = ALLOC_DYNST(Flow)) == NULLDYNST)
        MSG_RETURN(RET_MEM_ERR_ALLOC); /* REF2569 - AKO - 980818 */

    flow = (*flowTab)[*flowNbr];
    (*flowNbr) += 1;
    SET_ID(flow,             Flow_InstrId,      GET_ID(instrPtr, A_Instr_Id)); 
    SET_NULL_CODE(flow,      Flow_EvtCd);         
    SET_INT(flow,            Flow_EvtNbr,       1);         /* REF8844 - LJE - 030327 */
    SET_ENUM(flow,           Flow_NatEn,        FlowNat_Term);
    SET_FLAG(flow,           Flow_ConfirmedFlg, TRUE);
    SET_PERIOD(flow,         Flow_SettlDays,    GET_PERIOD(instrPtr, A_Instr_SettleDay));

    date.date = GET_DATE(instrPtr, A_Instr_BeginDate);
    SET_DATETIME(flow,       Flow_BegPayDate,   date);

    date.date = GET_DATE(instrPtr, A_Instr_EndDate);
    SET_DATETIME(flow,       Flow_EndPayDate,   date);
    SET_DATETIME(flow,       Flow_OptimalDate,  date);

    /*date.date = DATE_Move(GET_DATE(flow, Flow_OptimalDate), 
                  GET_PERIOD(flow, Flow_SettlDays), Day);*/
    date.date = GET_DATE(flow, Flow_OptimalDate); /* REF1193 - DDV - 980319 */
    SET_DATETIME(flow, Flow_OptimalValDate, date);

    SET_NULL_PERCENT(flow,   Flow_IoRPrct);
    SET_NUMBER(flow,         Flow_RefQty,     1.0);
    SET_FLAG(flow,           Flow_ReplaceFlg, TRUE);
    SET_PERCENT(flow,        Flow_Proba,      100.0);
    SET_NULL_ENUM(flow,      Flow_OptClassEn);
    SET_NULL_ENUM(flow,      Flow_OptStyleEn);
	/*instrAmt = GET_PRICE(instrPtr, A_Instr_RedempPrice);*/

    /* Compute instrument price, which will be amount per unit */
    if (GET_ID(instrPtr, A_Instr_Id) < 0)						/* DVP440 */
    { instrId = GET_ID(instrPtr, A_Instr_ParentInstrId); }
    else
    { instrId = GET_ID(instrPtr, A_Instr_Id); }

    /* Allocate instrument price structure */ /* REF2569 - AKO - 980818 */
    if ((pricePtr = ALLOC_DYNST(A_InstrPrice)) == NULLDYNST)
       MSG_RETURN(RET_MEM_ERR_ALLOC);   

    if ((INSTRNAT_ENUM) 
        GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_FRA &&
        IS_NULLFLD(instrPtr, A_Instr_EndDate) == FALSE &&		
        GET_DATE(instrPtr, A_Instr_EndDate) != MAGIC_END_DATE)
    {
        memset(&priceArgSt, 0, sizeof(FIN_PRICEARG_ST));
        memset(&expirDate, 0, sizeof(DATETIME_T));

        priceArgSt.discFacDate = valDateTime;
        expirDate.date = GET_DATE(instrPtr, A_Instr_EndDate);

        ret = FIN_InstrPrice(instrId, instrPtr, expirDate,
                 NULLDYNST, (ID_T)0, &priceArgSt, NULLDYNST, 
                 NULLDYNST, hierHead, pricePtr, FALSE); /* PMSTA14876 - DDV - 120911 - Add a new parameter, no impact for this call */
    }
    else
    {
        ret = FIN_InstrPrice(instrId, instrPtr, valDateTime, 
                 NULLDYNST, (ID_T)0, NULL, NULLDYNST, 
                 NULLDYNST, hierHead, pricePtr, FALSE); /* PMSTA14876 - DDV - 120911 - Add a new parameter, no impact for this call */
    }

    if (ret != RET_SUCCEED)
    {
        FREE_DYNST(pricePtr, A_InstrPrice); /* REF2569 - AKO - 980818 */
        /* REF3990 - SSO - 000406 remove last flow */
        (*flowNbr)--;
        FREE_DYNST((*flowTab)[*flowNbr], Flow);
        RET_GENFLOWS(ret);  /* REF3990 - SSO - 000406 */ 
    }

    if ((termEvtPtr = ALLOC_DYNST(A_TermEvt)) == NULLDYNST)
    {
        FREE_DYNST(pricePtr, A_InstrPrice); /* REF2569 - AKO - 980818 */
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    /* DVP440 - RAK - 970502 */  
    if ((ret = DBA_GetTermEvt(instrPtr, valDateTime.date, termEvtPtr)) != RET_SUCCEED)
    {
        FREE_DYNST(pricePtr, A_InstrPrice);
        FREE_DYNST(termEvtPtr, A_TermEvt); /* REF2569 - AKO - 980818 */ 
        /* REF3990 - SSO - 000406 remove last flow */
        (*flowNbr)--;
        FREE_DYNST((*flowTab)[*flowNbr], Flow);
        RET_GENFLOWS(ret); /* REF3990 - SSO - 000406 */ 
    }

    /* ------------------------------------------------------------------ */
    /* REF1055 - AKO - 991118 : Bulding the remaining data flow structure */
    /* ------------------------------------------------------------------ */
    if (IS_NULLFLD(termEvtPtr, A_TermEvt_CtdConvFact) == FALSE) /* REF1055 - move from down to here */
    { SET_NUMBER(flow, Flow_CtdConvFact, GET_NUMBER(termEvtPtr, A_TermEvt_CtdConvFact)); }

    if (IS_NULLFLD(termEvtPtr, A_TermEvt_CheapestInstrId) == FALSE)
    { 
        SET_ID(flow, Flow_NewInstrId, GET_ID(termEvtPtr, A_TermEvt_CheapestInstrId));
        if (IS_NULLFLD(termEvtPtr, A_TermEvt_CtdConvFact) == FALSE &&
        GET_NUMBER(termEvtPtr, A_TermEvt_CtdConvFact) != 0.0)
        {
		price = GET_PRICE(pricePtr, A_InstrPrice_Price) * GET_PRICE(termEvtPtr, A_TermEvt_CtdConvFact);
		SET_PRICE(pricePtr, A_InstrPrice_Price, CAST_PRICE(price)); /* REF3288 - SSO - 990205 */
		quote = GET_PRICE(pricePtr, A_InstrPrice_Quote) * GET_PRICE(termEvtPtr, A_TermEvt_CtdConvFact);
		SET_PRICE(pricePtr, A_InstrPrice_Quote, CAST_PRICE(quote));
        }
        else
        {
        SET_NUMBER(flow, Flow_CtdConvFact, (NUMBER_T)1)
        }
    }
    else
    {  /* Retrieve underLying instr. */ 
       /* Advanced analytics Licence checking */
       if ((GEN_GetApplInfo(ApplAALicense, &licenseEn)==TRUE) && 
            (licenseEn>=AdamLicencee_Level2))
       {
        DBA_DYNFLD_STP	underInstr=NULLDYNST;
        FLAG_T		allocOkFlg=FALSE;

        if ((ret=DBA_GetInstrById(GET_ID(termEvtPtr, A_TermEvt_UnderlyInstrId), FALSE,
            &allocOkFlg, &underInstr, hierHead, UNUSED, UNUSED)) == RET_SUCCEED)
        {
            if ((InstrNat_Bond==(INSTRNAT_ENUM)GET_ENUM(underInstr, A_Instr_NatEn)) ||
            (InstrNat_Deliverables==(INSTRNAT_ENUM)GET_ENUM(underInstr, A_Instr_NatEn)))
            
            {
            DBA_DYNFLD_STP	advArgStp=NULLDYNST, advAStp=NULLDYNST;
            /* underIntr.Nat = bond OR Delivrable */
            /* REF1055 - AKO */
            /* ------------------------------------------- */
            /* REF1055 - 991117 : Create input structure.  */
            /* Call Scecon functions to compute theo price */
            /* ------------------------------------------- */
            if ((advArgStp = ALLOC_DYNST(AdvA_Arg))==NULLDYNST)
            {
                if (TRUE == allocOkFlg) {FREE_DYNST(underInstr, A_Instr);};
                FREE_DYNST(termEvtPtr, A_TermEvt);
                FREE_DYNST(pricePtr, A_InstrPrice);
                MSG_RETURN(RET_MEM_ERR_ALLOC);
            }
            if ((advAStp = ALLOC_DYNST(A_AdvA)) == NULLDYNST)
            {
                if (TRUE == allocOkFlg) {FREE_DYNST(underInstr, A_Instr);};
                FREE_DYNST(advArgStp, AdvA_Arg);
                FREE_DYNST(termEvtPtr, A_TermEvt);
                FREE_DYNST(pricePtr, A_InstrPrice);

                MSG_RETURN(RET_MEM_ERR_ALLOC);
            }

            /* ---------------------- */
            /* build keyword argument */
            /* ---------------------- */

            /* CalendarId from reference currency. */
            if (((ret=DBA_GetCalendarFromInstr(instrPtr, &calendarId))!=RET_SUCCEED) || 
                (calendarId <= 0))
            {
                /* force to find a system param. calendar */
                GEN_GetApplInfo(ApplSysCalendarId, &calendarId);
            }
            SET_ID(advArgStp, AdvA_Arg_CalendarId, calendarId);
            SET_FLAG(advArgStp, AdvA_Arg_CalendarKeyWFlg, FALSE); /* REF5941 - YST - 020109 */
            /* instrument Id */
            SET_ID(advArgStp, AdvA_Arg_InstrId, GET_ID(instrPtr, A_Instr_Id));
            /* Margin */
            SET_FLAG(advArgStp, AdvA_Arg_Margin, (FLAG_T)TRUE);
            /* domestic */
            SET_FLAG(advArgStp, AdvA_Arg_Domestic, (FLAG_T)TRUE);
            /* ref date */
            SET_DATE(advArgStp, AdvA_Arg_Date, fromDateTime.date);
            /* spread */
            SET_NUMBER(advArgStp, AdvA_Arg_Spread, (NUMBER_T)0);
            /* shock */
            SET_NUMBER(advArgStp, AdvA_Arg_Shock, (NUMBER_T)0);
            /* CTD */
            SET_FLAG(advArgStp, AdvA_Arg_MarketCTD, (FLAG_T)TRUE);

            /* set the keyword nature */
            SET_ENUM(advArgStp, AdvA_Arg_KeyWordEn, AdvAKeyWord_DF_Fut);

            if ((ret=SCE_ComputeCurrKeyWord(advArgStp, instrPtr,
                                NULLDYNST, hierHead, advAStp)) == RET_SUCCEED)
            {
                /* computed CTD */
                SET_ID(flow, Flow_NewInstrId, GET_ID(advAStp, A_AdvA_Ctd)); 

                /* conversion factor */
                if ((IS_NULLFLD(advAStp, A_AdvA_Cf) == TRUE) || 
                    (CMP_NUMBER(GET_NUMBER(advAStp, A_AdvA_Cf), 0.0)==0))
                    SET_NUMBER(flow, Flow_CtdConvFact, (NUMBER_T)1) /* the from termEvt one is replaced */
                else
                    SET_NUMBER(flow, Flow_CtdConvFact, GET_NUMBER(advAStp, A_AdvA_Cf));

			    price = GET_PRICE(pricePtr, A_InstrPrice_Price) *  GET_PRICE(flow, Flow_CtdConvFact);
			    SET_PRICE(pricePtr, A_InstrPrice_Price, CAST_PRICE(price)); 

			    quote = GET_PRICE(pricePtr, A_InstrPrice_Quote) * GET_PRICE(flow, Flow_CtdConvFact);
			    SET_PRICE(pricePtr, A_InstrPrice_Quote, CAST_PRICE(quote));
             }
             else
             {
                /* REF3990 - SSO - 000406 remove last flow */
                (*flowNbr)--;
                FREE_DYNST((*flowTab)[*flowNbr], Flow);
             }
             /* free memory localy reserved */
             FREE_DYNST(advAStp, A_AdvA);	
             FREE_DYNST(advArgStp, AdvA_Arg);
            }
            else
            {
            SET_ID(flow, Flow_NewInstrId, GET_ID(termEvtPtr, A_TermEvt_UnderlyInstrId));
            }
        }
        else
        {
            MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, "FIN_FutureFlows", 
                         GET_CODE(instrPtr, A_Instr_Cd), "Underlying not found");
            /* REF3990 - SSO - 000406 remove last flow */
            (*flowNbr)--;
            FREE_DYNST((*flowTab)[*flowNbr], Flow);
        }
        if (TRUE == allocOkFlg) {FREE_DYNST(underInstr, A_Instr);};
        } /* Licence */
        else
        {
        /* Flow NewInstrId */
        SET_ID(flow, Flow_NewInstrId, GET_ID(termEvtPtr, A_TermEvt_UnderlyInstrId));

        if (IS_NULLFLD(termEvtPtr, A_TermEvt_CtdConvFact) == FALSE &&
            GET_NUMBER(termEvtPtr, A_TermEvt_CtdConvFact) != 0.0)
        {
		    price = GET_PRICE(pricePtr, A_InstrPrice_Price) * GET_PRICE(termEvtPtr, A_TermEvt_CtdConvFact);
		    SET_PRICE(pricePtr, A_InstrPrice_Price, CAST_PRICE(price)); /* REF3288 - SSO - 990205 */
		    quote = GET_PRICE(pricePtr, A_InstrPrice_Quote) * GET_PRICE(termEvtPtr, A_TermEvt_CtdConvFact);
		    SET_PRICE(pricePtr, A_InstrPrice_Quote, CAST_PRICE(quote));
        }
        else
        {
            SET_NUMBER(flow, Flow_CtdConvFact, (NUMBER_T)1)
        }
        }
    } /* END of REF1055 - 991118 */

    if (ret == RET_SUCCEED)
    {
    	    SET_PRICE(flow,        Flow_AmtUnit,      GET_PRICE(pricePtr, A_InstrPrice_Price));
	    SET_PRICE(flow,        Flow_Quote,        GET_PRICE(pricePtr, A_InstrPrice_Quote));
            SET_ID(flow,            Flow_AmtCurrId,    GET_ID(pricePtr, A_InstrPrice_CurrId));
        SET_NUMBER(flow,        Flow_QtyUnit,      1);
        SET_TINYINT(flow,       Flow_Freq,         GET_TINYINT(instrPtr, A_Instr_PayFreq));
        SET_ENUM(flow,          Flow_FreqUnitEn,   GET_ENUM(instrPtr, A_Instr_PayFreqUnitEn));
        SET_NULL_DATE(flow,     Flow_ExDate);
        SET_FLAG(flow,          Flow_PhysicalFlg,  GET_FLAG(instrPtr, A_Instr_PhysicalFlg));
        SET_NULL_TINYINT(flow,  Flow_Priority);
        SET_FLAG(flow,          Flow_EffectiveFlg, FALSE);
        SET_ENUM(flow,          Flow_SubNatEn,     FlowSubNat_Term);
        SET_NULL_EXCHANGE(flow, Flow_FxdExchRate); /* ?? */

        if (IS_NULLFLD(termEvtPtr, A_TermEvt_CtdConvRatio) == FALSE)
        { SET_NUMBER(flow, Flow_CtdConvRatio, GET_NUMBER(termEvtPtr, A_TermEvt_CtdConvRatio)); }
    }

    FREE_DYNST(termEvtPtr, A_TermEvt);
    FREE_DYNST(pricePtr, A_InstrPrice);

    RET_GENFLOWS(ret); /* REF3990 - SSO - 000406 */ 
}

/************************************************************************
* 
*   Function          : FIN_CashAcctFlows()
* 
*   Description       : Retrieves all possible future flows of a cash account.
*                       Compute accrued interest
*                  
*   Arguments         : fromDateTime  from date
*                       tillDateTime  end date
*                       valDateTime
*                       inputInstrPtr pointer on instrument struct or NULL
*                       evtDateRule   enum for operation date rule in event generation domain
*                       flowTab       pointer on flows array which will be 
*                                     allocated and filled up
*                                     (initialised to NULL by FIN_GenerateInstrFlows())
*                       flowNbr       pointer on flows number which will be
*                                     filled up
*                                     (initialised to 0 by FIN_GenerateInstrFlows())
* 
*   Warning           : Calling function is FIN_GenerateInstrFlows()
* 
*   Return            : RET_SUCCEED 
*                       RET_MEM_ERR_ALLOC
*                       RET_GEN_ERR_INVARG
* 
*   Creation date     : April 95 - RAK
*   Last modification : 28.06.95 - PEC
*			BUG043 - RAK - 960627 
*			REF2068 - RAK - 980504
*			REF3542 - AKO - 990409 - purify : supress var. dynst unitInter
*			REF4075 - CSY - 991027 
* 
*   BUG482 : For interest : Si la position est n?gative, le taux utilis? peut ?tre diff?rent,
*            mais pour l'instant on n'a pas cette information ? ce niveau. 
*            De plus, on calcule les flux par instrument et non par position.
*            1?re solution : calculer des flux pour les positions et passer l'info du montant
*            2?me solution : calculer dans les flux les deux taux et choisir au moment de la 
*		             generation
*			REF3990 - SSO - 000406 : modified ERROR MANAGEMENT !!! be careful if further modification 
*           REF8827 - TEB - 050318
*************************************************************************/
STATIC RET_CODE FIN_CashAcctFlows(DATETIME_T        fromDateTime, 
                                  DATETIME_T        tillDateTime,
                                  DATETIME_T        valDateTime,
                                  DBA_DYNFLD_STP    instrPtr,
                                  EVTDATERULE_ENUM  evtDateRule, /* REF4075 - CSY - 9910127 */
                                  DBA_DYNFLD_STP    **flowTab,
                                  int               *flowNbr,
                                  DBA_HIER_HEAD_STP hierHead)
{
    DBA_DYNFLD_STP   flowPtr=NULLDYNST, *incTab=(DBA_DYNFLD_STP*)NULL;
    RET_CODE         ret;
    int              incNbr, i, j, currPeriod, allocSz=0, 
                 reallocSz=5;
    double           freq, interFreq;
    char             endMFlg;
    DAY_T            svEndD;
    DATETIME_T       begDate, endDate, date, tmpDateTime;
    NUMBER_T         tmp;
    AMOUNT_T         qty;
    FIN_INTERRATE_ST interRate;
    FLAG_T           found = FALSE;

    /************** EXCHANGE FLOWS ************/
    /* generate flows for exchange events */ /* REF1917 - DDV - 980424 */
    FIN_CreateExchangeFlows(instrPtr, fromDateTime, &tillDateTime, valDateTime, 
                evtDateRule, &allocSz, flowNbr, flowTab, hierHead); /* REF4075 - CSY - 991027 */

    tmpDateTime.time = 0;
    begDate.time = 0;
    endDate.time = 0;
    date.time = 0;

    /************** INCOME FLOWS (last ones) ************/
    if ((ret = DBA_SelectIncEvt(instrPtr, fromDateTime, tillDateTime, 
                                valDateTime, &incTab, &incNbr)) != RET_SUCCEED)
    {
        RET_GENFLOWS(ret); /* REF3990 - SSO - 000406 */
    }

    for (i=0; i<incNbr; i++)
    {
        FIN_PeriodUnitNbr((FREQUNIT_ENUM)GET_ENUM(incTab[i], A_IncEvt_PayFreqUnitEn), /* REF7264 - CSY - 020130 */
                      GET_TINYINT(incTab[i], A_IncEvt_PayFreq), 
                      FreqUnit_Month, &freq);

        /* Income event must be in report period */
        if (GET_DATE(incTab[i], A_IncEvt_LastPayDate) < fromDateTime.date)
            continue;

        begDate.date = GET_DATE(incTab[i], A_IncEvt_BeginDate);

        /* REF2068 - RAK - 980504 */
        /* Use first coupon date if specified */
        /*endDate.date = GET_DATE(incTab[i], A_IncEvt_BeginDate);*/
        if (IS_NULLFLD(incTab[i], A_IncEvt_FirstCoupDate) == FALSE)
            /* REF1833 - DDV - 980422 */
            endDate.date = GET_DATE(incTab[i], A_IncEvt_FirstCoupDate); 
        else
            endDate.date = GET_DATE(incTab[i], A_IncEvt_BeginDate);

        /* Short month can corrupt day number */
        endMFlg = (char) DATE_IsLastInMonth(endDate.date);
        DATE_Get(endDate.date, (YEAR_T*)NULL, (MONTH_T*)NULL, &svEndD);

        if (endDate.date == BAD_DATE)
        {
        DBA_FreeDynStTab(incTab, incNbr, A_IncEvt); /* REF2569 - AKO - 980818 */
        MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
                 "FIN_CashAcctFlows", GET_CODE(instrPtr, A_Instr_Cd), "end date");
        return(RET_SUCCEED); /* REF3990 - SSO - 000406 RET_FIN_ERR_INVDATA->minor error */
        }

        /* Advance in repetitiv event until journal begin date */
        currPeriod = 1;
        while (endDate.date < fromDateTime.date)
        {
        begDate = endDate;
        if (freq == 0.)    /* No repetitive event (one period) */
            endDate.date = GET_DATE(incTab[i], A_IncEvt_LastPayDate);
        else
        {
            endDate.date = DATE_Move(begDate.date, (int)freq, Month);
            /* Short month can corrupt day number */
            DATE_VerifyEndMonth(&endDate.date, svEndD, endMFlg);
        }
        ++currPeriod;
        }
      
        /* BUG043 - RAK - 960627 */
        /* return valid rate in period (and not accrued interest) */
        FIN_PeriodUnitNbr((FREQUNIT_ENUM)GET_ENUM(instrPtr, A_Instr_PayFreqUnitEn), /* REF7264 - CSY - 020130 */
                      GET_TINYINT(instrPtr, A_Instr_PayFreq), 
                      FreqUnit_Month, &interFreq);

        /* REF7475 - YST - 020516 - new argument */
        if ((ret = FIN_SearchInterRate(fromDateTime.date, tillDateTime.date, 
               (PERIOD_T) interFreq, 
               (ACCRRULE_ENUM) GET_ENUM(instrPtr, A_Instr_AccrualRuleEn),
               instrPtr, &interRate, hierHead, (INTERCONDNAT_ENUM)InterCondNat_None, 
               FALSE, /* PMSTA05878 - RAK - 080424 */ NULL)) != RET_SUCCEED)
        {
        DBA_FreeDynStTab(incTab, incNbr, A_IncEvt);
        FREE(interRate.infoPtr); /* REF3542 - AKO - 990412 */
        MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
                 "FIN_CashAcctFlows", GET_CODE(instrPtr, A_Instr_Cd), "interest");
        return(RET_SUCCEED); /* REF3990 - SSO - 000406 RET_FIN_ERR_INVDATA->minor error*/
        }

        /* --------------------------- */
        /* BEGIN BUG043 - RAK - 960627 */
        /* tmp = GET_NUMBER(unitInter, UnitInter_UnitAccrInter); */
        /* tmp = CAST_NUMBER(tmp * 100);  for the moment ??      */
        /* qty = GET_NUMBER(unitInter, UnitInter_UnitAccrInter); */
        if (interRate.interRateNbr >= 1)
        {
        /* REF1926 - DDV - 980427 */
        j=0;
        while (found == FALSE && j<interRate.interRateNbr)
        {
            tmpDateTime.date = interRate.infoPtr[j].fromDate;
            if (DATETIME_CMP(tmpDateTime, fromDateTime) <= 0)
            {
            tmpDateTime.date = interRate.infoPtr[j].tillDate;
            if (DATETIME_CMP(tmpDateTime, fromDateTime) > 0)
            {
                found = TRUE;
            }
            else
                j++;
            }
            else
            j++;
        }

            if(j<interRate.interRateNbr)
        {
           qty = interRate.infoPtr[j].posRate;
               tmp = qty / 100.0;
        }
        else
        {
           qty = 0.0;
           tmp = 0.0;
        }
        }
        else
        {
        qty = 0.0;
        tmp = 0.0;
        }
        FREE(interRate.infoPtr); /* REF3542 - AKO - 990420 */
        /* END   BUG043 - RAK - 960627 */
        /* --------------------------- */
      
        /* For each period in current income event */
        /* (one in case of no repetitive event)    */
        while (endDate.date <= tillDateTime.date &&
           endDate.date <= GET_DATE(incTab[i],A_IncEvt_LastPayDate))
        {
        if (allocSz == 0 || *flowNbr >= allocSz-1) /* DVP384 - XDI - 970314 */
        {
            allocSz+=reallocSz;
            if (((*flowTab) = (DBA_DYNFLD_STP *) REALLOC((*flowTab), 
                      allocSz * sizeof(DBA_DYNFLD_STP))) == (DBA_DYNFLD_STP *) NULL)
            {
            DBA_FreeDynStTab(incTab,incNbr, A_IncEvt);	/* REF2569 - AKO - 980818 */
            MSG_RETURN(RET_MEM_ERR_ALLOC);
            }
        }

        if (((*flowTab)[*flowNbr] = ALLOC_DYNST(Flow)) == NULLDYNST)
        {
            DBA_FreeDynStTab(incTab, incNbr, A_IncEvt); /* REF2569 - AKO - 980818 */
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        flowPtr = (*flowTab)[*flowNbr];
        SET_ID(flowPtr,            Flow_InstrId,        GET_ID(incTab[i], A_IncEvt_InstrId));
        SET_CODE(flowPtr,          Flow_EvtCd,          GET_CODE(incTab[i], A_IncEvt_Cd));
        SET_INT(flowPtr,           Flow_EvtNbr,         currPeriod); /* REF8844 - LJE - 030327 */
        SET_ENUM(flowPtr,          Flow_NatEn,          FlowNat_Inc);
        SET_FLAG(flowPtr,          Flow_ConfirmedFlg,   TRUE);
        SET_DATETIME(flowPtr,      Flow_BegPayDate,     begDate);
        SET_DATETIME(flowPtr,      Flow_EndPayDate,     endDate);
        SET_PERIOD(flowPtr,        Flow_SettlDays,      0);
        SET_DATETIME(flowPtr,      Flow_OptimalDate,    endDate);

        /*date.date = DATE_Move(GET_DATE(flowPtr, Flow_OptimalDate), 
                       GET_PERIOD(flowPtr, Flow_SettlDays), Day);*/
        date.date = GET_DATE(flowPtr, Flow_OptimalDate); /* REF1193 - DDV - 980319 */
            SET_DATETIME(flowPtr, Flow_OptimalValDate, date);

        SET_NULL_PERCENT(flowPtr,  Flow_IoRPrct);
		SET_PRICE(flowPtr,        Flow_Quote,          tmp);
        SET_NUMBER(flowPtr,        Flow_RefQty,         1.0);
        SET_FLAG(flowPtr,          Flow_ReplaceFlg,     FALSE); /* Niet c.f IRM */
		SET_PRICE(flowPtr,        Flow_AmtUnit,        qty);
        COPY_DYNFLD(flowPtr, Flow, Flow_AmtCurrId, incTab[i],  A_IncEvt,  A_IncEvt_CurrId);
        SET_NULL_ID(flowPtr,       Flow_NewInstrId);
        SET_NULL_NUMBER(flowPtr,   Flow_QtyUnit);
        SET_NULL_ENUM(flowPtr,     Flow_OptClassEn);
        SET_NULL_ENUM(flowPtr,     Flow_OptStyleEn);
        SET_PERCENT(flowPtr,       Flow_Proba,          100.0);

        SET_TINYINT(flowPtr,       Flow_Freq, GET_TINYINT(incTab[i], A_IncEvt_PayFreq));
        SET_ENUM(flowPtr,          Flow_FreqUnitEn, GET_ENUM(incTab[i], A_IncEvt_PayFreqUnitEn));
        SET_EXCHANGE(flowPtr,      Flow_FxdExchRate, 
        GET_EXCHANGE(incTab[i],    A_IncEvt_FixedExchRate));
        SET_NULL_DATE(flowPtr,     Flow_ExDate);
        SET_NULL_NUMBER(flowPtr,   Flow_CtdConvFact);
        SET_NULL_NUMBER(flowPtr,   Flow_CtdConvRatio);
        SET_NULL_ID(flowPtr,       Flow_CtdInstrId);
        SET_FLAG(flowPtr,          Flow_PhysicalFlg, FALSE);
        SET_NULL_TINYINT(flowPtr,  Flow_Priority);
        SET_FLAG(flowPtr,          Flow_EffectiveFlg, FALSE);
/*		SET_ENUM(flowPtr,          Flow_SubNatEn, FlowSubNat_FxdRate); */	/* REF8827 - TEB - 050318 */
        SET_ENUM(flowPtr,          Flow_SubNatEn, FlowSubNat_FloatRate);	/* REF8827 - TEB - 050318 */
        /* Go on next period */
        (*flowNbr)++;
        currPeriod++;
        begDate = endDate;

        if (freq == 0.)         /* No repetitive event, stop */
            endDate.date = DATE_Move(endDate.date, 1, Day); 
        else
        {
            endDate.date = DATE_Move(begDate.date, (int)freq, Month);
            /* Short month can corrupt day number */
            DATE_VerifyEndMonth(&endDate.date, svEndD, endMFlg);
        }
        }
    }

    DBA_FreeDynStTab(incTab, incNbr, A_IncEvt);
    return(RET_SUCCEED);
}

/************************************************************************
* 
*   Function          :  FIN_MoneyMktFlows()
* 
*   Description       :  Retrieves all possible future flows of a money market.
*                        Work on an instument created by a generic instrument
*                  
*   Arguments         :  fromDateTime  from date
*                        tillDateTime  end date
*                        valDateTime  end date
*                        inputInstrPtr pointer on instrument struct or NULL
*                        evtDateRule   enum used in event generation to specify the event operation date rule
*                        flowTab       pointer on flows array which will be 
*                                      allocated and filled up
*                                      (initialised to NULL by FIN_GenerateInstrFlows())
*                        flowNbr       pointer on flows number which will be
*                                      filled up
*                                      (initialised to 0 by FIN_GenerateInstrFlows())
* 
*   Warning           :  Calling function is FIN_GenerateInstrFlows()
* 
*   Return            :  RET_SUCCEED 
*                        RET_MEM_ERR_ALLOC
*                        RET_GEN_ERR_INVARG
* 
*   Creation date     : April 95 - RAK
*   Last modification : 28.06.95 - PEC
*                       BUG043 - RAK - 960627
*                       REF1079 - RAK - 971219
*                       REF4075 - CSY - 991027
*
*   Modification      : REF2569 - AKO - 980818
*   Modification      : REF3542 - AKO - 990415 Purify : free memory no more used
*			REF3823 - SSO - 990720
*			REF3990 - SSO - 000406 : modified ERROR MANAGEMENT !!! be careful if further modification 
* 
*************************************************************************/
STATIC RET_CODE FIN_MoneyMktFlows(DATETIME_T        fromDateTime,  
                                  DATETIME_T        tillDateTime,
                                  DATETIME_T        valDateTime,
                                  DBA_DYNFLD_STP    instrPtr,
                                  EVTDATERULE_ENUM  evtDateRule, /* REF4075 - CSY - 991027 */
                                  DBA_DYNFLD_STP    **flowTab,
                                  int               *flowNbr, 
                                  DBA_HIER_HEAD_STP hierHead)
{
    DBA_DYNFLD_STP flow=NULLDYNST;
    AMOUNT_T       unitAccrInter;
    RET_CODE       ret;
    DATETIME_T     date;
    int            i, allocSz=0, reallocSz=5, newFlowNbr = 0;
    FLAG_T	       applUnitAccrIntAllDecFlag=FALSE;	  /* REF3823 - SSO - 990720 */
    int		oldFlows;/* REF3990 - SSO - 000406 */
    FLAG_T         nullInstrEndDateFlg=FALSE; /* REF5969 - DDV - 010611 - don't change end date of instrument */

    /* < PMSTA-34288 - CHU - 190219 */
    ID_T                calendarId = (ID_T)-1;
    PRICE_T	        flowQuote = 1.0;
    NUMBER_T		flowFxdExchRate = 1.0;
    DBA_DYNFLD_STP		*compoTab = NULL, *termEvtTab = NULL, *underInstrTab = NULL, chosenOptionPtr = NULL;
    int					compoNbr = 0, termEvtNbr = 0, underInstrNbr = 0;
    DBA_DYNFLD_STP		currDomainPtr = DBA_GetDomainPtr(DBA_GetConnectNoFromHier(hierHead));
    MemoryPool          mp;
    /* > PMSTA-34288 - CHU - 190219 */

    /************** EXCHANGE FLOWS ************/
    /* generate flows for echange events */
    FIN_CreateExchangeFlows(instrPtr, fromDateTime, &tillDateTime, valDateTime, 
                evtDateRule, &allocSz, flowNbr, flowTab, hierHead);  /* REF4075 - CSY - 991027 */

    oldFlows = *flowNbr;/* REF3990 - SSO - 000406 */

    if ((tillDateTime.date < GET_DATE(instrPtr, A_Instr_EndDate) ||
        fromDateTime.date > GET_DATE(instrPtr, A_Instr_EndDate)) &&
        GET_DATE(instrPtr, A_Instr_EndDate) != MAGIC_END_DATE) /* BUG304 - XDI - 970318 */
            return(RET_SUCCEED);

    date.time = 0;

    DBA_DYNFLD_STP accrInter = mp.allocDynst(FILEINFO, UnitInter);
    
    /* < PMSTA-34288 - CHU - 190219 */
    if (InstrumentNature::isDualCurrencyInvestMoneyMarket(instrPtr) ||
        InstrumentNature::isTripleCurrencyInvestMoneyMarket(instrPtr))
    {
        if ((ret = FIN_STNOptionBasedCompoTermEvtInfo(hierHead, instrPtr, currDomainPtr,
                                                      &compoTab, &compoNbr,
                                                      &termEvtTab, &termEvtNbr,
                                                      &underInstrTab, &underInstrNbr)) != RET_SUCCEED)
        {
            RET_GENFLOWS(ret);
        }

        mp.ownerDynStpTab(compoTab,compoNbr);
        mp.ownerDynStpTab(termEvtTab,termEvtNbr);
        mp.ownerPtr(underInstrTab); // instr from hierarchy

        if (underInstrNbr < 2 /* DCI */ || underInstrNbr > 3 /* TCI */)
        {
            RET_GENFLOWS(ret);
        }

        if ((DBA_GetCalendarFromInstr(instrPtr, &calendarId) != RET_SUCCEED) || (calendarId <= 0))
        {
            GEN_GetApplInfo(ApplSysCalendarId, &calendarId);
        }

        const int nbOption = underInstrNbr - 1;

        if (nbOption == 1) /* DCI - Double Currency Investment */
        {
            flowFxdExchRate = 1.0;
            /* get option instrument in composition */
            for (int j = 0; j < underInstrNbr; j++)
            {
                if (InstrNat_Option == (INSTRNAT_ENUM)GET_ENUM(underInstrTab[j], A_Instr_NatEn))
                {
                    /* Check between Option currency and instrument fixing currency */
                    /* if currencies differ, change Flow_FxdExchRate */
                    if (GET_ENUM(instrPtr, A_Instr_ConvertInterestEn) != InstrConvertInterest_None && /* PMSTA-36345 - CHU - 190624 */
                        IS_NULLFLD(instrPtr, A_Instr_FixingCurrId) == FALSE && /* PMSTA-36345 - CHU - 190624 */
                        CMP_ID(GET_ID(instrPtr, A_Instr_FixingCurrId), GET_ID(instrPtr, A_Instr_RefCurrId)) != 0)
                    {
                        flowFxdExchRate = GET_EXCHANGE(underInstrTab[j], A_Instr_RedempPrice);
                    }
                    chosenOptionPtr = underInstrTab[j];
                    break;
                }
            }
        }
        else if (nbOption == 2) /* TCI - Triple Currency Investment */
        {
            flowFxdExchRate = 1.0;
            /* get option instrument in composition */
            for (int j = 0; j < underInstrNbr; j++)
            {
                if (InstrNat_Option == (INSTRNAT_ENUM)GET_ENUM(underInstrTab[j], A_Instr_NatEn))
                {
                    /* Look for same Option currency than instrument fixing currency amongst 2 available */
                    /* if currencies differ, change Flow_FxdExchRate */
                    if (CMP_ID(GET_ID(instrPtr, A_Instr_FixingCurrId), GET_ID(underInstrTab[j], A_Instr_UnderlyInstrId)) == 0)
                    {
                        if (GET_ENUM(instrPtr, A_Instr_ConvertInterestEn) != InstrConvertInterest_None && /* PMSTA-36345 - CHU - 190624 */
                            IS_NULLFLD(instrPtr, A_Instr_FixingCurrId) == FALSE &&  /* PMSTA-36345 - CHU - 190624 */
                            CMP_ID(GET_ID(instrPtr, A_Instr_FixingCurrId), GET_ID(instrPtr, A_Instr_RefCurrId)) != 0)
                        {
                            flowFxdExchRate = GET_EXCHANGE(underInstrTab[j], A_Instr_RedempPrice);
                        }
                        chosenOptionPtr = underInstrTab[j];
                        break;
                    }
                }
            }
        }
    }
    /* > PMSTA-34288 - CHU - 190219 */

    /* Two flows (redemption + income) for no discounted instrument */
    /* One flow  (redemption)          for discounted instrument    */
    /* if (GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn) != PriceCalcRule_Discounted) - REF3765 - SSO - 990712 */
    if (GET_ENUM(instrPtr, A_Instr_NatEn) != InstrNat_Discount)
        newFlowNbr = 2;
    else
        newFlowNbr = 1;

    if (allocSz == 0 || *flowNbr+newFlowNbr >= allocSz)
    {
        allocSz+=reallocSz;
        if (((*flowTab) = (DBA_DYNFLD_STP *) REALLOC((*flowTab), 
                      allocSz * sizeof(DBA_DYNFLD_STP))) 
                      == (DBA_DYNFLD_STP *) NULL)
        {
            MSG_RETURN(RET_MEM_ERR_ALLOC); /* REF2569 - AKO - 980818 */
        }
    }

    for (i=*flowNbr; i<*flowNbr+newFlowNbr; i++)
    {
        if (((*flowTab)[i] = ALLOC_DYNST(Flow)) == NULLDYNST)
        {
        /* REF2569 - AKO - 980818 */
        *flowNbr = i;  /* actual quantity of memory to free */
            MSG_RETURN(RET_MEM_ERR_ALLOC); 		/* REF2569 - AKO - 980818 */
        }
    }

    /*** REDEMPTION FLOW ON EXPIRATION DATE ***/
    /* If end date isn't specified for a discounted instr., 
       it's impossible to generate flow */
    if ((IS_NULLFLD(instrPtr, A_Instr_EndDate) == TRUE ||		
         GET_DATE(instrPtr, A_Instr_EndDate) == MAGIC_END_DATE) &&  /* BUG208 */
        (GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn) == PriceCalcRule_Discounted ||
         GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn) == PriceCalcRule_InFineYield)) /* REF3765 - SSO - 990712  */
    {
        MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO,  /* REF2569 - AKO - 980818 */ 
                 "FIN_MoneyMktFlows", GET_CODE(instrPtr, A_Instr_Cd), 
                 "discounted instrument end date");

        /* REF3990 - SSO - 000406 remove last flows */
        for (i=oldFlows; i<(*flowNbr); i++)
        {
        FREE_DYNST((*flowTab)[i], Flow);
        }
        (*flowNbr)=oldFlows;
        return(RET_SUCCEED); /* REF3990 - SSO - 000406 RET_FIN_ERR_INVDATA->minor error */ 
    }

    /* If it isn't a discounted instr and End Date is NULL, calculate the End Date
       by adding Notice Days to From Date */
    if ((IS_NULLFLD(instrPtr, A_Instr_EndDate) == TRUE ||		
         GET_DATE(instrPtr, A_Instr_EndDate) == MAGIC_END_DATE) &&  /* BUG208 */
        (GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn) != PriceCalcRule_Discounted &&
         GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn) != PriceCalcRule_InFineYield)) /* REF3765 - SSO - 990712 */
    {
        if (IS_NULLFLD(instrPtr, A_Instr_NoticeDay) == TRUE)
            SET_SMALLINT(instrPtr, A_Instr_NoticeDay, 0);

        date.date = DATE_Move(fromDateTime.date, 
                          GET_SMALLINT(instrPtr, A_Instr_NoticeDay), Day);
        /* REF3730 - Pendant que j'y suis - RAK - 990604 */
        /* SET_DATETIME(instrPtr, A_Instr_EndDate, date); */
        SET_DATE(instrPtr, A_Instr_EndDate, date.date);
        nullInstrEndDateFlg = TRUE; /* REF5969 - DDV - 010611 - don't change end date of instrument */

    }

    flow = (*flowTab)[*flowNbr];
    (*flowNbr) += 1;

    SET_ID(flow,            Flow_InstrId,        GET_ID(instrPtr, A_Instr_Id)); 
    SET_NULL_CODE(flow,     Flow_EvtCd);         
    SET_INT(flow,           Flow_EvtNbr,         1);         /* REF8844 - LJE - 030327 */
    SET_ENUM(flow,          Flow_NatEn,          FlowNat_Redm);
    SET_FLAG(flow,          Flow_ConfirmedFlg,   TRUE);
    /*SET_PERIOD(flow,      Flow_SettlDays,      GET_PERIOD(instrPtr, A_Instr_SettleDay)); */
    SET_PERIOD(flow,        Flow_SettlDays,      GET_SMALLINT(instrPtr, A_Instr_NoticeDay)); /* REF899 - XDI - 971117 */

    date.date = GET_DATE(instrPtr, A_Instr_EndDate);

    SET_DATETIME(flow, Flow_OptimalValDate, date);

    /* DDV - 980319 - REF1193 */
    /*date.date = DATE_Move(GET_DATE(flow, Flow_OptimalValDate), 
                      (-1) * GET_PERIOD(flow, Flow_SettlDays), Day);*/ /* REF899 - XDI - 971117 */

    SET_DATETIME(flow, Flow_BegPayDate,     date);
    SET_DATETIME(flow, Flow_EndPayDate,     date);
    SET_DATETIME(flow, Flow_OptimalDate,    date);

    /* Old Code - REF899- XDI - 971117 
    date.date = DATE_Move(GET_DATE(flow, Flow_OptimalDate), 
                          GET_PERIOD(flow, Flow_SettlDays), Day);
    SET_DATETIME(flow, Flow_OptimalValDate, date);*/
    SET_NULL_PERCENT(flow,  Flow_IoRPrct);

    /*  REF1800 - AKO - 980814
	SET_PRICE(flow,        Flow_Quote,          100.0);
    */
    switch(GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn))
    {
    case PriceCalcRule_Quote:
	    SET_PRICE(flow, Flow_Quote, (PRICE_T)1.0);
        break;

    default:
	    SET_PRICE(flow, Flow_Quote, (PRICE_T)100.0);
        break;
    }

    SET_NUMBER(flow,        Flow_RefQty,          1.0);
    SET_FLAG(flow,          Flow_ReplaceFlg,          TRUE);
	SET_PRICE(flow,        Flow_AmtUnit,        1.0);
    SET_ID(flow,            Flow_AmtCurrId,      GET_ID(instrPtr, A_Instr_RefCurrId));
    SET_NULL_ID(flow,       Flow_NewInstrId);
    SET_NULL_NUMBER(flow,   Flow_QtyUnit);
    SET_NULL_ENUM(flow,     Flow_OptClassEn);
    SET_NULL_ENUM(flow,     Flow_OptStyleEn);
    SET_PERCENT(flow,       Flow_Proba,          100.0);

    SET_NULL_TINYINT(flow,   Flow_Freq);
    SET_NULL_ENUM(flow,      Flow_FreqUnitEn);
    SET_NULL_DATE(flow,      Flow_ExDate);
    SET_NULL_EXCHANGE(flow,  Flow_FxdExchRate);
    SET_NULL_NUMBER(flow,    Flow_CtdConvFact);
    SET_NULL_NUMBER(flow,    Flow_CtdConvRatio);
    SET_NULL_ID(flow,        Flow_CtdInstrId);
    SET_FLAG(flow,           Flow_PhysicalFlg, FALSE);
    SET_NULL_TINYINT(flow,   Flow_Priority);
    SET_FLAG(flow,           Flow_EffectiveFlg, FALSE);
    SET_ENUM(flow,           Flow_SubNatEn, FlowSubNat_FinalRedm);

    /* PMSTA-36025 - RAK - 190528 */
    /* Fixing currency empty or egal to instrument reference currency : */
    /* redemption and income in instrument reference currency */
    /* Fixing currency <> instrument reference currency : */
    /* Principal only : redemption = fixing currency      */
    /*                  income = instrument ref currency  */
    /* P+Interest     : redemption = fixing currency      */
    /*                : income = fixing currency          */

    /* < PMSTA-34288 - CHU - 190219 */
    if (InstrumentNature::isDualCurrencyInvestMoneyMarket(instrPtr) ||
        InstrumentNature::isTripleCurrencyInvestMoneyMarket(instrPtr))
    {
        if (IS_NULLFLD(instrPtr, A_Instr_FixingCurrId) == FALSE)
        {
            /* SET_ID(flow, Flow_NewInstrId, GET_ID(instrPtr, A_Instr_FixingCurrId)); */
            if (CMP_ID(GET_ID(instrPtr, A_Instr_FixingCurrId), GET_ID(instrPtr, A_Instr_RefCurrId)) != 0)
            {
                SET_ID(flow, Flow_AmtCurrId, GET_ID(instrPtr, A_Instr_FixingCurrId));
                SET_PRICE(flow, Flow_AmtUnit, 1.0 / flowFxdExchRate);
            }
        }
        
        SET_EXCHANGE(flow, Flow_FxdExchRate, flowFxdExchRate);
    }
    /* > PMSTA-34288 - CHU - 190219 */

    /*** INCOME FLOW FOR NO DISCOUNTED INSTRUMENT ***/
    /* if (GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn) != PriceCalcRule_Discounted) - REF3765 - SSO - 990712 */
    if (GET_ENUM(instrPtr, A_Instr_NatEn) != InstrNat_Discount)
    {
        flow = (*flowTab)[*flowNbr];
        (*flowNbr) += 1;

        /* BUG043 - RAK - 960627 */
        if ((ret = FIN_PeriodUnitAccrInter(instrPtr, GET_DATE(instrPtr, A_Instr_BeginDate), 
                                           GET_DATE(instrPtr, A_Instr_EndDate), /* REF1079 */
                                           (PERCENT_T*)NULL, NULLDYNST, AccrRule_None,	 /* REF11218 - TEB - 050627 */
                                           accrInter, hierHead, NULL)) == RET_SUCCEED)
        {
            SET_ID(flow,            Flow_InstrId,        GET_ID(instrPtr, A_Instr_Id));
            SET_NULL_CODE(flow,     Flow_EvtCd);         
            SET_INT(flow,           Flow_EvtNbr,        1);         /* REF8844 - LJE - 030327 */
            SET_ENUM(flow,          Flow_NatEn,         FlowNat_Inc);
            SET_FLAG(flow,          Flow_ConfirmedFlg,  TRUE);
            /*SET_PERIOD(flow,      Flow_SettlDays,     GET_PERIOD(instrPtr, A_Instr_SettleDay)); */
            SET_PERIOD(flow,        Flow_SettlDays,     GET_SMALLINT(instrPtr, A_Instr_NoticeDay)); /* REF899 - XDI - 971117 */

            date.date = GET_DATE(instrPtr, A_Instr_EndDate);
            SET_DATETIME(flow, Flow_OptimalValDate, date);
  
            SET_DATETIME(flow,      Flow_BegPayDate,     date);
            SET_DATETIME(flow,      Flow_EndPayDate,     date);
            SET_DATETIME(flow,      Flow_OptimalDate,    date);

            SET_NULL_PERCENT(flow,  Flow_IoRPrct);
		    SET_PRICE(flow,        Flow_Quote,      GET_PERCENT(instrPtr, A_Instr_InterestRateP));
            SET_NUMBER(flow,        Flow_RefQty,     1.0);
            SET_FLAG(flow,          Flow_ReplaceFlg, FALSE);
            
            unitAccrInter = GET_NUMBER(accrInter, UnitInter_UnitAccrInter) + 
                            GET_NUMBER(instrPtr, A_Instr_UnitAccrInter);

            GEN_GetApplInfo(ApplUnitAccrIntAllDecFlag, &applUnitAccrIntAllDecFlag);
            if (applUnitAccrIntAllDecFlag == TRUE)
		    {SET_PRICE(flow, Flow_AmtUnit, unitAccrInter);}
            else
		    {SET_PRICE(flow, Flow_AmtUnit, CAST_PRICE(unitAccrInter)); }
           
            SET_ID(flow,            Flow_AmtCurrId,  GET_ID(instrPtr, A_Instr_RefCurrId));
            SET_NULL_ID(flow,       Flow_NewInstrId);
            SET_NULL_NUMBER(flow,   Flow_QtyUnit);
            SET_NULL_ENUM(flow,     Flow_OptClassEn);
            SET_NULL_ENUM(flow,     Flow_OptStyleEn);
            SET_PERCENT(flow,       Flow_Proba,      100.0);

            SET_NULL_TINYINT(flow,   Flow_Freq);
            SET_NULL_ENUM(flow,      Flow_FreqUnitEn);
            SET_NULL_DATE(flow,      Flow_ExDate);
            SET_NULL_EXCHANGE(flow,  Flow_FxdExchRate);
            SET_NULL_NUMBER(flow,    Flow_CtdConvFact);
            SET_NULL_NUMBER(flow,    Flow_CtdConvRatio);
            SET_NULL_ID(flow,        Flow_CtdInstrId);
            SET_FLAG(flow,           Flow_PhysicalFlg,  FALSE);
            SET_NULL_TINYINT(flow,   Flow_Priority);
            SET_FLAG(flow,           Flow_EffectiveFlg, FALSE);
            SET_ENUM(flow,           Flow_SubNatEn,     FlowSubNat_FxdRate);

            /* < PMSTA-34288 - CHU - 190219 */
            if (InstrumentNature::isDualCurrencyInvestMoneyMarket(instrPtr) ||
                InstrumentNature::isTripleCurrencyInvestMoneyMarket(instrPtr))
            {
                DATE_PERIOD_ST      period;
                ACCRRULE_ENUM       accrRuleEn = AccrRule_SceAct365;

                if (IS_NULLFLD(instrPtr, A_Instr_AccrualRuleEn) == FALSE &&
                    (ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) != AccrRule_None)
                {
                    accrRuleEn = (ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn);
                }
                /* Flow_Quote = interest_rate * (end_d - beg_d +1) / 365 / 100 */
                DATE_AccrPeriod(GET_DATE(instrPtr, A_Instr_BeginDate), GET_DATE(instrPtr, A_Instr_EndDate),
                                accrRuleEn, (PERIOD_T)1.0, &period, calendarId);

                if (IS_NULLFLD(instrPtr, A_Instr_InterestRateP) == FALSE) /* PMSTA-34885 - CHU - 190301 */
                {
                    flowQuote = GET_PERCENT(instrPtr, A_Instr_InterestRateP) * (period.num + 1) / period.denom / 100.0;
                }

                if (IS_NULLFLD(instrPtr, A_Instr_FixingCurrId) == FALSE &&
                    CMP_ID(GET_ID(instrPtr, A_Instr_FixingCurrId), GET_ID(instrPtr, A_Instr_RefCurrId)) != 0)
                {
                    /* PMSTA-36025 - RAK - 190528 - For Principal only, keep income in instrument reference currency */
                    if (GET_ENUM(instrPtr, A_Instr_ConvertInterestEn) == InstrConvertInterest_PrincipalInstrest)
                    {
						SET_PRICE(flow, Flow_Quote,   flowQuote * 1.0 / flowFxdExchRate);
						SET_PRICE(flow, Flow_AmtUnit, flowQuote * 1.0 / flowFxdExchRate);
                        SET_ID(flow, Flow_AmtCurrId, GET_ID(instrPtr, A_Instr_FixingCurrId));
                        SET_EXCHANGE(flow, Flow_FxdExchRate, flowFxdExchRate);
                    }
                    else
                    {
						SET_PRICE(flow, Flow_Quote, flowQuote);
						SET_PRICE(flow, Flow_AmtUnit, flowQuote);
                        SET_EXCHANGE(flow, Flow_FxdExchRate, 1.0);
                    }
                }
            }
            /* > PMSTA-34288 - CHU - 190219 */
        }
        else
        {
            /* REF3990 - SSO - 000406 : remove already added flows*/
            for (i=oldFlows; i<(*flowNbr); i++)
            {
                FREE_DYNST((*flowTab)[i], Flow);
            }
            (*flowNbr)=oldFlows;
            if (nullInstrEndDateFlg == TRUE) /* REF5969 - DDV - 010611 - don't change end date of instrument */
                    SET_DATE(instrPtr, A_Instr_EndDate, MAGIC_END_DATE);
            return(RET_SUCCEED); /* REF3990 - SSO - 000406 RET_FIN_ERR_INVDATA->minor error */
        }

        /* REF2569 - AKO - 980818 */ 	
        /* if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
            {
            FREE_FLOW((*flowTab), *flowNbr); 
        }*/

        if (nullInstrEndDateFlg == TRUE) /* REF5969 - DDV - 010611 - don't change end date of instrument */
                SET_DATE(instrPtr, A_Instr_EndDate, MAGIC_END_DATE);
        return(ret);
    }
    
    if (nullInstrEndDateFlg == TRUE) /* REF5969 - DDV - 010611 - don't change end date of instrument */
            SET_DATE(instrPtr, A_Instr_EndDate, MAGIC_END_DATE);
    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function          : FIN_DebtFlows()
**
**  Description       : Retrieves all possible future flows of a debt.
**                 
**  Arguments         : fromDateTime  from date
**                      tillDateTime  end date
**                      inputInstrPtr pointer on instrument struct or NULL
**                      flowTab       pointer on flows array which will be 
**                                    allocated and filled up
**                                    (initialised to NULL by FIN_GenerateInstrFlows())
**                      flowNbr       pointer on flows number which will be
**                                    filled up
**                                    (initialised to 0 by FIN_GenerateInstrFlows())
**
**  Warning           : Calling function is FIN_GenerateInstrFlows()
**
**  Return            : RET_SUCCEED 
**                      RET_MEM_ERR_ALLOC
**                      RET_GEN_ERR_INVARG
**
**  Creation date     : April 95 - RAK
**
**  Modification      : REF2569 - AKO - 980818
*			REF3990 - SSO - 000406 : modified ERROR MANAGEMENT !!! be careful if further modification 
** 
*************************************************************************/
RET_CODE FIN_DebtFlows( DATETIME_T        fromDateTime,  
                        DATETIME_T        tillDateTime,
                        DATETIME_T        valDateTime,
                        DBA_DYNFLD_STP    instrPtr,
                        DBA_DYNFLD_STP    **flowTab,
                        int               *flowNbr,
                        DBA_HIER_HEAD_STP )
{
    DBA_DYNFLD_STP  flowSt=NULLDYNST, 
                    *ioRTab=(DBA_DYNFLD_STP*) NULL;
    NUMBER_T        qty=1; /* ?? */
    DATETIME_T      date, begDate, endDate;
    DAY_T           svEndD;
    char            endMFlg;
    int             i, ioRNbr, currPeriod, allocSz=0, reallocSz=5; 
    double          freq = 0.0;
    RET_CODE        ret;
    FLAG_T          proviPlanOrAmortFlg = FALSE;
/*	int		oldFlows = *flowNbr;*//* REF3990 - SSO - 000406 */

    date.time = 0;
    begDate.time = 0;
    endDate.time = 0;

    ret = DBA_SelectIOREvt(instrPtr, fromDateTime, tillDateTime, 
                           valDateTime, &ioRTab, &ioRNbr);

    if (ioRNbr == 0 || ret != RET_SUCCEED)
    {
        MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, 
                 "FIN_DebtFlows", GET_CODE(instrPtr, A_Instr_Cd), 
                 "issue or redemption parameters");
        /*return(RET_FIN_ERR_INVDATA);   REF3990 - SSO - 000406 commented out*/
        return(RET_SUCCEED); /* REF3990 - SSO - 000406 RET_FIN_ERR_INVDATA->minor error */
    }


    /* DDV - 990512 - will allocated later if needed */
/*	allocSz = ioRNbr;
    if (((*flowTab) = (DBA_DYNFLD_STP *)
         CALLOC(allocSz, sizeof(DBA_DYNFLD_STP))) == (DBA_DYNFLD_STP*)NULL)
    {
        DBA_FreeDynStTab(ioRTab, ioRNbr, A_IssueEvt);
            MSG_RETURN(RET_MEM_ERR_ALLOC);
    }
*/

    /* REF2435 - DDV - 980831 */
    /* check if provi plan or amortisation event exist */
    for (*flowNbr=0, i=0; i<ioRNbr && proviPlanOrAmortFlg == FALSE; i++)
    {
        if (GET_ENUM(ioRTab[i], A_IssueEvt_NatEn) == IssRedmNat_DebtProvi ||
        GET_ENUM(ioRTab[i], A_IssueEvt_NatEn) == IssRedmNat_DebtAmort)
        proviPlanOrAmortFlg = TRUE;
    }

    /* For each redemption event */
    for (*flowNbr=0, i=0; i<ioRNbr; i++)
    {
        FIN_PeriodUnitNbr((FREQUNIT_ENUM)GET_ENUM(ioRTab[i], A_IssueEvt_FreqUnitEn), /* REF7264 - CSY - 020130 */
                     GET_TINYINT(ioRTab[i], A_IssueEvt_Freq), 
                     FreqUnit_Month, &freq);

        if (GET_DATE(ioRTab[i], A_IssueEvt_EndDate) < fromDateTime.date)
            continue;

        begDate.date = GET_DATE(ioRTab[i], A_IssueEvt_BegDate);
        endDate.date = GET_DATE(ioRTab[i], A_IssueEvt_BegDate);
        /* Short month can corrupt day number */
        endMFlg = (char) DATE_IsLastInMonth(endDate.date);
        DATE_Get(endDate.date, (YEAR_T *) NULL, (MONTH_T *) NULL, &svEndD);

        if (endDate.date == BAD_DATE)
        {
        DBA_FreeDynStTab(ioRTab, ioRNbr, A_IssueEvt);  /* REF2569 - AKO - 980818 */
        MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, "FIN_DebtFlows", 
                 GET_CODE(instrPtr, A_Instr_Cd), "end date");
        return(RET_FIN_ERR_INVDATA); /* REF3990 - SSO - 000406  keep RET_FIN_ERR_INVDATA because only Debt flows generated */
        }

        /* Advance in repetitiv event until journal begin date */
        currPeriod = 1;
        while (endDate.date < fromDateTime.date && freq > 0)
        {
        begDate = endDate;
        endDate.date = DATE_Move(begDate.date, (int)freq, Month);
        /* Short month can corrupt day number */
        DATE_VerifyEndMonth(&endDate.date, svEndD, endMFlg);
        ++currPeriod;
        }

        /* REF2435-1 - DDV - 980827 - Move out from while */
        if (freq == 0.)    /* No repetitive event (one period) */
        endDate.date = GET_DATE(ioRTab[i], A_IssueEvt_EndDate);
        else if (begDate.date == endDate.date) /* REF2435 - 980904 - DDV - No income at begin date */
        {
        endDate.date = DATE_Move(begDate.date, (int)freq, Month);
        /* Short month can corrupt day number */
        DATE_VerifyEndMonth(&endDate.date, svEndD, endMFlg);
        ++currPeriod;
        }

        /* For each period in current income event */
        /* (one in case of no repetitive event)    */
        while (endDate.date <= GET_DATE(ioRTab[i], A_IssueEvt_EndDate) &&
              endDate.date <= tillDateTime.date)
        {
        if (allocSz == 0 || *flowNbr >= allocSz-1) /* DVP384 - XDI - 970314 */
        {
            allocSz+=reallocSz;
            if (((*flowTab) = (DBA_DYNFLD_STP *) REALLOC((*flowTab), 
                          allocSz*sizeof(DBA_DYNFLD_STP))) == (DBA_DYNFLD_STP*)NULL)
            {	
            DBA_FreeDynStTab(ioRTab, ioRNbr, A_IssueEvt); /* REF2569 - AKO - 980818 */
            MSG_RETURN(RET_MEM_ERR_ALLOC);
            }
        }

        if (((*flowTab)[*flowNbr] = ALLOC_DYNST(Flow)) == NULLDYNST)
        {
            DBA_FreeDynStTab(ioRTab, ioRNbr, A_IssueEvt); /* REF2569 - AKO - 980818 */
                MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        flowSt = (*flowTab)[*flowNbr];
        SET_ID(flowSt,       Flow_InstrId,      GET_ID(ioRTab[i], A_IssueEvt_InstrId));
        SET_CODE(flowSt,     Flow_EvtCd,        GET_CODE(ioRTab[i], A_IssueEvt_Cd));
        SET_INT(flowSt,      Flow_EvtNbr,       currPeriod); /* REF8844 - LJE - 030327 */
        SET_ENUM(flowSt,     Flow_NatEn,        FlowNat_Debt);
        SET_FLAG(flowSt,     Flow_ConfirmedFlg, TRUE);
        SET_DATETIME(flowSt, Flow_BegPayDate,   begDate);
        SET_DATETIME(flowSt, Flow_EndPayDate,   endDate);
        SET_PERIOD(flowSt,   Flow_SettlDays,    GET_TINYINT(ioRTab[i], A_IssueEvt_SettlDays));
        SET_DATETIME(flowSt, Flow_OptimalDate,  endDate);

        /*date.date = DATE_Move(GET_DATE(flowSt,    Flow_OptimalDate), 
                                GET_PERIOD(flowSt, Flow_SettlDays), Day);*/
        date.date = GET_DATE(flowSt, Flow_OptimalDate); /* REF1193 - DDV - 980319 */
        SET_DATETIME(flowSt, Flow_OptimalValDate, date);

        SET_PERCENT(flowSt,     Flow_IoRPrct, GET_PERCENT(ioRTab[i], A_IssueEvt_ProporPrct));
		/*SET_PRICE(flowSt,    Flow_Quote,   GET_PRICE(ioRTab[i], A_IssueEvt_Quote));*/
        SET_NULL_NUMBER(flowSt, Flow_RefQty);

        /* SSO- 990208  qty = FIN_Qty(instrPtr, qty);  */
		SET_PRICE(flowSt, Flow_Quote,
            CAST_NUMBER(qty * (GET_PERCENT(ioRTab[i], A_IssueEvt_ProporPrct)/100.0))); /* REF3288 - SSO - 990205 */

        /* REF2435 - DDV - 980831*/
        if (GET_ENUM(ioRTab[i], A_IssueEvt_NatEn) == IssRedmNat_FinalRedm)
        {
            if (proviPlanOrAmortFlg == TRUE)
            {
					SET_PRICE(flowSt, Flow_Quote, 0.0);
			SET_PRICE(flowSt, Flow_AmtUnit, 0.0);
            }
            else
            {
			SET_PRICE(flowSt, Flow_AmtUnit, 1.0);
            }
        }
        else if (GET_ENUM(ioRTab[i], A_IssueEvt_NatEn) == IssRedmNat_DebtAmort)
        {
				SET_PRICE(flowSt, Flow_Quote, 0.0);
		    SET_PRICE(flowSt, Flow_AmtUnit, 0.0);
        }
        else
        {
		    SET_PRICE(flowSt, Flow_AmtUnit,
			CAST_PRICE(qty * (GET_PERCENT(ioRTab[i], A_IssueEvt_ProporPrct)/100.0))); /* REF3288 - SSO - 990205 */
        }

        SET_ID(flowSt,          Flow_AmtCurrId,   GET_ID(ioRTab[i], A_IssueEvt_CurrId));
        SET_NULL_ID(flowSt,     Flow_NewInstrId);
        SET_NULL_NUMBER(flowSt, Flow_QtyUnit);
        SET_NULL_ENUM(flowSt,   Flow_OptClassEn);
        SET_NULL_ENUM(flowSt,   Flow_OptStyleEn);
        SET_PERCENT(flowSt,     Flow_Proba,       100.0);

        SET_TINYINT(flowSt,   Flow_Freq, 
            GET_TINYINT(ioRTab[i], A_IssueEvt_Freq));
        SET_ENUM(flowSt,      Flow_FreqUnitEn, 
            GET_ENUM(ioRTab[i], A_IssueEvt_FreqUnitEn));
        SET_EXCHANGE(flowSt,  Flow_FxdExchRate, 
            GET_EXCHANGE(ioRTab[i], A_IssueEvt_FxdExchRate));
        if (DATETIME_CMP(GET_DATETIME(ioRTab[i], A_IssueEvt_EffectiveDate),
                 fromDateTime) < 0)
        {    SET_FLAG(flowSt, Flow_EffectiveFlg, TRUE);}
        else
        {    SET_FLAG(flowSt, Flow_EffectiveFlg, FALSE);}

        SET_ENUM(flowSt,      Flow_SubNatEn, 
            FIN_GetIoRFlowSubNat((ISSREDMNAT_ENUM) GET_ENUM(ioRTab[i], A_IssueEvt_NatEn)));

        SET_NULL_DATE(flowSt,      Flow_ExDate);
        SET_NULL_NUMBER(flowSt,    Flow_CtdConvFact);
        SET_NULL_NUMBER(flowSt,    Flow_CtdConvRatio);
        SET_NULL_ID(flowSt,        Flow_CtdInstrId);
        SET_FLAG(flowSt,           Flow_PhysicalFlg, FALSE);
        SET_NULL_TINYINT(flowSt,   Flow_Priority);

        /* Go on next period */
        (*flowNbr)++;
        currPeriod++;
        begDate = endDate;

            if (freq == 0.)    /* No repetitive event (one period), stop */
                endDate.date = DATE_Move(endDate.date, 1, Day); 
            else
        {
           endDate.date = DATE_Move(begDate.date, (int)freq, Month);
           /* Short month can corrupt day number */
           DATE_VerifyEndMonth(&endDate.date, svEndD, endMFlg);
        }
        }
    }

    DBA_FreeDynStTab(ioRTab, ioRNbr, A_IssueEvt);

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_NewBondFlows()
**
**  Description :   Retrieves all possible future flows of a bond.
**                  
**                 
**  Arguments   :   fromDateTime  from date
**                  tillDateTime  end date
**                  valDateTime   end date
**                  inputInstrPtr pointer on instrument struct or NULL
**                  evtDateRule   enum used in event generation domain to specify the event operation date rule
**                  accrRule      accrual rule given in ACCR_INTER
**                  flowTab       pointer on flows array which will be 
**                                allocated and filled up
**                                (initialised to NULL by FIN_GenerateInstrFlows())
**                  flowNbr       pointer on flows number which will be
**                                filled up
**                                (initialised to 0 by FIN_GenerateInstrFlows())
**                  position      The current position. Can be null
**
**
**  Return      :   
**
**  Creation    :   REF5938 - RAK - 010508
**  Modification:   REF7599 - YST - 020904
**  Modification:   REF9085 - YST - 030522
**  Modification:   REF11218 - TEB - 050627
**  Modification:   PMSTA-36699  - Silpakal - 191121 - New calculation rules of STN should not call FIN_SCEBondFlows
**
*************************************************************************/
RET_CODE FIN_NewBondFlows(DATETIME_T            fromDateTime,
                          DATETIME_T            tillDateTime,
                          DATETIME_T            valDateTime,
                          FLAG_T                noRefDateFlg,   /* PMSTA-9032 - RAK - 091216 */
                          DBA_DYNFLD_STP        instrPtr,
                          EVTDATERULE_ENUM      evtDateRule,    /* REF4075 - CSY - 991027 */
                          ACCRRULE_ENUM         accrRule,       /* REF11218 - TEB - 050627 */
                          DBA_DYNFLD_STP **     flowTab,
                          int *                 flowNbr,
                          int *                 lastPeriod,     /* REF7599 - YST - 020904 */
                          DBA_HIER_HEAD_STP     hierHead,
                          const DBA_DYNFLD_STP  position)       /* PMSTA-32116 - 200818 - PMO */
{
    INSTRNAT_ENUM       instrNat=(INSTRNAT_ENUM)GET_ENUM(instrPtr, A_Instr_NatEn);
    ADAM_LICENCEE_ENUM  licenseEn=AdamLicencee_No;
    RET_CODE            ret=RET_SUCCEED;
    FLAG_T              newAccrRuleFlg=FALSE, updateAccrRuleFlg=FALSE;

    /* PMSTA - 36699 - Silpakal - 191121 */
    DBA_DYNFLD_STP      inputData = NULLDYNST;
    DBA_DYNFLD_STP      *selInterTab = NULLDYNSTPTR;
    int                 selInterNbr = 0;
    FLAG_T		        interCondRecFlg = FALSE;
    INTERCALCRULE_ENUM  instrCondCalcRuleEn = InterCalcRule_Fixed;
    SUBNAT_ENUM         instrSubNat = (SUBNAT_ENUM)GET_ENUM(instrPtr, A_Instr_SubNatEn);
    MemoryPool          mp;

    /* PMSTA-10443 - RAK - 101022 - set ActualActual to ACTACT */
    FIN_SetSceActActRule(instrPtr, &updateAccrRuleFlg);

    newAccrRuleFlg = SCE_CheckAccrRule((ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn));

    /* PMSTA-36699  - Silpakal - 191121  */
    if (instrNat != InstrNat_CashAcct)
    {
        /* Fetch the benchmark details from interest rate condition table instead of instrument table */
        inputData = mp.allocDynst(FILEINFO, A_InterCond);

        if (GET_ID(instrPtr, A_Instr_Id) < 0)
        {
            SET_ID(inputData, A_InterCond_InstrId, GET_ID(instrPtr, A_Instr_ParentInstrId));
        }
        else
        {
            SET_ID(inputData, A_InterCond_InstrId, GET_ID(instrPtr, A_Instr_Id));
        }

        SET_DATE(inputData, A_InterCond_BeginDate, fromDateTime.date);
        SET_DATE(inputData, A_InterCond_EndDate, valDateTime.date);
        SET_ENUM(inputData, A_InterCond_NatEn, InterCondNat_None);

        /* Special treatment for Fund Shares */
        if (instrPtr != NULLDYNST &&
            (INSTRNAT_ENUM)GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_FundShare &&
            ((SUBNAT_ENUM)GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_MoneyMarketFundShare ||
            (SUBNAT_ENUM)GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_FixedIncomeFundShare))
        {
            SET_DATE(inputData, A_InterCond_ValidDate, fromDateTime.date);
        }

        if ((ret = DBA_SelAllInterCond(InterCond_ByIdDt, hierHead, instrPtr, inputData,
                                       &selInterTab, &selInterNbr, &interCondRecFlg)) != RET_SUCCEED)
        {
            ret = RET_DBA_ERR_NODATA;
            MSG_SendMesg(ret, 3, FILEINFO, "DBA_SelectInterCond", GET_CODE(instrPtr, A_Instr_Cd), "interest condition");
            return ret;
        }

        if (selInterNbr > 0)
            instrCondCalcRuleEn = (INTERCALCRULE_ENUM)GET_ENUM(selInterTab[0], A_InterCond_IntCalcRuleEn);

    }

    /* Bond and MM with sub-nature = FRN (MM only new accrual rule) */
    if (((GEN_GetApplInfo(ApplAALicense, &licenseEn)==TRUE) && 
         (licenseEn>=AdamLicencee_Level1)) && /* REF1055 -  AKO - 991222 */
         (instrNat==InstrNat_Bond || (instrNat == InstrNat_MoneyMkt && newAccrRuleFlg == TRUE)) && 
         (SubNat_FRN==GET_ENUM(instrPtr, A_Instr_SubNatEn) && ((selInterNbr > 0 &&
             static_cast<InstrMktConvMethodEn>GET_ENUM(selInterTab[0], A_InterCond_MktConvMethodEn) != InstrMktConvMethodEn::None)==FALSE)))
    {
            ret = FIN_FloatingRateNoteFlows(fromDateTime, tillDateTime, valDateTime,
                                            instrPtr, evtDateRule, accrRule, /* REF11218 - TEB - 050627 */
                                            flowTab, flowNbr, hierHead);
    }
    /* swap legs */ /* REF5530 - RAK - 010111 */
    else if ((GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_RecSwapFixedLeg ||
              GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_RecSwapFloatLeg ||
              GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_PaidSwapFixedLeg ||
              GET_ENUM(instrPtr, A_Instr_SubNatEn) == SubNat_PaidSwapFloatLeg) &&
             ((GEN_GetApplInfo(ApplAALicense, &licenseEn)==TRUE) && 
              (licenseEn>=AdamLicencee_Level1)) && (static_cast<InstrMktConvMethodEn>GET_ENUM(instrPtr, A_Instr_MktConvMethodEn) == InstrMktConvMethodEn::None && static_cast<InstrMktConvMethodEn>GET_ENUM(instrPtr, A_Instr_PaidMktConvMethodEn) == InstrMktConvMethodEn::None))
    {
        ret = FIN_SwapLegFlows(fromDateTime, tillDateTime, valDateTime, instrPtr,
                               flowTab, flowNbr, lastPeriod, hierHead);
    }
    /* Bond and assimilated and MM with new accrual rule */ /* REF9085 - YST - 030522 *//* PMSTA-36699  - Silpakal - 191121  */
    else if ((newAccrRuleFlg == TRUE) && ((instrCondCalcRuleEn != InterCalcRule_RangeAccrual) &&
                                        (instrCondCalcRuleEn != InterCalcRule_Digital) &&
                                        (instrCondCalcRuleEn != InterCalcRule_Memory) &&
                                        (((selInterNbr > 0 &&
                                            static_cast<InstrMktConvMethodEn>GET_ENUM(selInterTab[0], A_InterCond_MktConvMethodEn) != InstrMktConvMethodEn::None) == FALSE) || instrNat != InstrNat_MoneyMkt) &&
                                        (!(instrCondCalcRuleEn == InterCalcRule_Floating && 
                                          (instrSubNat == SubNat_CapProtectNotesWCoupon || instrSubNat == SubNat_ReverseConvNotesEquity ||
                                                instrSubNat == SubNat_ReverseConvNotesBonds || instrSubNat == SubNat_ReverseConvNotesCredit ||
                                                instrSubNat == SubNat_MemoryCouponNotes || instrSubNat == SubNat_EquityLinkedNotes ||
                                                instrSubNat == SubNat_BondsLinkedNotes || instrSubNat == SubNat_CreditLinkedNotes ||
                                              (instrSubNat == SubNat_FRN && ((selInterNbr > 0 &&
                                                  static_cast<InstrMktConvMethodEn>GET_ENUM(selInterTab[0], A_InterCond_MktConvMethodEn) != InstrMktConvMethodEn::None)==TRUE))))
                                         )))
    {
        ret = FIN_SCEBondFlows(fromDateTime, tillDateTime, valDateTime,
                                instrPtr, evtDateRule, accrRule, /* REF11218 - TEB - 050627 */
                                flowTab, flowNbr, hierHead); 
    }
    /* MM with old accrual rule */ /* REF9085 - YST - 030522 */
    else if (instrNat == InstrNat_MoneyMkt)
    { 
        ret = FIN_MoneyMktFlows(fromDateTime, tillDateTime, valDateTime,
                                instrPtr, evtDateRule, flowTab, flowNbr, hierHead); 
    }
    /* Bond and assimilated with old accrual rule */
    else
    {
        ret = FIN_BondFlows(fromDateTime, tillDateTime, valDateTime,
                            noRefDateFlg,                    /* PMSTA-9032 - RAK - 091216 */
                            instrPtr, evtDateRule, accrRule, /* REF11218 - TEB - 050627 */
                            flowTab, flowNbr, hierHead, position);
    }

    DBA_FreeDynStTab(selInterTab, selInterNbr, A_InterCond);
    /* PMSTA-10443 - RAK - 101022 - reset to ActualActual */
    FIN_ResetSceActActRule(instrPtr, updateAccrRuleFlg);
    return(ret);
}


/*
 * Management of instrument of type structure note
 */
class InstrumentStructureNote
{
    public:
        InstrumentStructureNote(const DBA_DYNFLD_STP);

        InstrumentStructureNote            (const InstrumentStructureNote &) = delete;
        InstrumentStructureNote & operator=(const InstrumentStructureNote &) = delete;

        // Do the payout computation
        RET_CODE computePayout(const DATETIME_T &, DBA_HIER_HEAD_STP, const NUMBER_T &, const DBA_DYNFLD_STP);

        // Retrive the payout computed by computePayout
        AMOUNT_T getPayout() const
        {
            return m_payout;
        }

        // Flag if the instrument has payout computation
        bool isProcessing() const
        {
            return m_processing;
        }


    private:
        bool  isInstrumentProcessing();
   

        bool                    m_processing;   // Flag if the instrument has payout computation
        AMOUNT_T                m_payout;       // Payout computed by computePayout
        const DBA_DYNFLD_STP    m_instrPtr;     // Reference instrument
};


/************************************************************************
**
**  Function    :   InstrumentStructureNote::InstrumentStructureNote()
**
**  Description :   Constructor
**
**  Arguments   :   instrPtr    Current instrument
**
**  Return      :
**
**  Creation:   :   PMSTA-32116 - 200818 - PMO : [KD-1022A] WS - Structured Product - Instrument Financial Processing : Financial functions
**
**  Modif.      :
**
*************************************************************************/
InstrumentStructureNote::InstrumentStructureNote(const DBA_DYNFLD_STP instrPtr) : m_processing(false)
                                                                                , m_payout(ZERO_AMOUNT)
                                                                                , m_instrPtr(instrPtr)
{
    m_processing = isInstrumentProcessing();
   
}


/************************************************************************
**
**  Function    :   InstrumentStructureNote::isInstrumentProcessing()
**
**  Description :   Test if the instrument has payout computation
**
**  Arguments   :   None
**
**  Return      :   true    The instrument has payout computation
**                  false   The instrument don't has payout computation
**
**  Creation:   :   PMSTA-32116 - 200818 - PMO : [KD-1022A] WS - Structured Product - Instrument Financial Processing : Financial functions
**
**  Modif.      :
**
*************************************************************************/
bool InstrumentStructureNote::isInstrumentProcessing()
{
    return InstrumentNature::isCapProtectNotes(m_instrPtr) || InstrumentNature::isReverseConvertibleELN(m_instrPtr);
}


/************************************************************************
**
**  Function    :   InstrumentStructureNote::computePayout()
**
**  Description :   Computation of the payout for some kinds of instrument
**
**  Arguments   :   valDateTime
**                  hierHead    Hierarchy pointer
**                  coupon
**                  position
**
**  Warning     :
**
**  Return      :
**
**  Creation:   :   PMSTA-32116 - 200818 - PMO : [KD-1022A] WS - Structured Product - Instrument Financial Processing : Financial functions
**
**  Modif.      :
**
*************************************************************************/
RET_CODE InstrumentStructureNote::computePayout(const DATETIME_T & valDateTime, DBA_HIER_HEAD_STP hierHead, const NUMBER_T & coupon, const DBA_DYNFLD_STP position)
{
    RET_CODE ret = RET_SUCCEED;
    m_payout = ZERO_AMOUNT;

    if (true == m_processing && nullptr != position)
    {
        MemoryPool      mp;
        DBA_DYNFLD_STP  pricePtr = mp.allocDynst(FILEINFO, A_InstrPrice);

        ret = FIN_InstrPrice(GET_ID(m_instrPtr, A_Instr_Id), m_instrPtr, valDateTime, nullptr, ZERO_ID, nullptr, nullptr, nullptr, hierHead, pricePtr, FALSE);
        if (RET_SUCCEED == ret)
        {
            const PERCENT_T capitalProtectionLevel  = GET_NUMBER(m_instrPtr, A_Instr_CapLevel);                 // Capital Protection level in % terms (default value 100)
            const NUMBER_T  participationLevel      = GET_NUMBER(m_instrPtr, A_Instr_ParticipationLev);         // Participation level in % terms (default value 100)
            const NUMBER_T  rebate                  = GET_NUMBER(m_instrPtr, A_Instr_RebatePayoff);             // Rebate in % terms if applicable (default value 0)
            const PRICE_T  underlyingPriceAtEnd    = GET_PRICE(pricePtr,   A_InstrPrice_Price);               // Underlying price at end of observation period
            const PRICE_T   exercisePrice           = GET_PRICE(m_instrPtr, A_Instr_ExerQuote);                // Exercise Price in absolute term
            const bool      barrierKnockedOut       = FALSE == IS_NULLFLD(m_instrPtr, A_Instr_KnockOutDate) && DATE_Cmp(valDateTime.date, GET_DATE(m_instrPtr, A_Instr_KnockOutDate)) >= 0;
            const bool      exerciseLowerOrEqual    = CMP_NUMBER(underlyingPriceAtEnd, exercisePrice) >= 0;

            if (true == InstrumentNature::isCapProtectNotes(m_instrPtr))
            {
                const NUMBER_T  nominalAmount = GET_NUMBER(position, ExtPos_Qty);                               // Nominal Amount of the note (i.e. Quantity in TAP)

                if (true == barrierKnockedOut)
                {
                    m_payout = nominalAmount * (capitalProtectionLevel + rebate);
                }
                else
                {
                    const NUMBER_T  barrier = GET_NUMBER(m_instrPtr, A_Instr_Barrier);

                    if (true == exerciseLowerOrEqual && CMP_NUMBER(underlyingPriceAtEnd, barrier) < 0)
                    {
                        const NUMBER_T  capitalRate     = GET_NUMBER(m_instrPtr, A_Instr_CapTaxRateP)/100.0;    // Cap rate  (default 100)
                        const NUMBER_T  leverageBooster = GET_NUMBER(m_instrPtr, A_Instr_EffectiveLeverage);    // Leverage/Booster (default 100)

                        m_payout = nominalAmount * (capitalProtectionLevel + std::min(capitalRate, participationLevel * leverageBooster * (FIN_DIV(underlyingPriceAtEnd - exercisePrice, exercisePrice))));
                    }
                    else
                    {
                        m_payout = nominalAmount * rebate;
                    }
                }
            }
            
            if (true == InstrumentNature::isReverseConvertibleELN(m_instrPtr))
            {
                if (true == barrierKnockedOut)
                {
                    m_payout = 100.0 * coupon;
                }
                else
                {
                    if (true == exerciseLowerOrEqual)
                    {
                        m_payout = 100.0 + coupon;
                    }
                    else
                    {
                        m_payout = std::max(capitalProtectionLevel, underlyingPriceAtEnd - exercisePrice) + coupon;
                    }
                }
            }
        }
    }

    return ret;
}


/************************************************************************
**
**  Function    :   FIN_BondFlows()
**
**  Description :   Retrieves all possible future flows of a bond.
**                 
**  Arguments   :   fromDateTime  from date
**                  tillDateTime  end date
**                  valDateTime   end date
**                  inputInstrPtr pointer on instrument struct or NULL
**                  evtDateRule   enum used in event generation domain to specify the event operation date rule
**                  accrRule      accrual rule given to ACCR_INTER
**                  flowTab       pointer on flows array which will be 
**                                allocated and filled up
**                                (initialised to NULL by FIN_GenerateInstrFlows())
**                  flowNbr       pointer on flows number which will be
**                                filled up
**                                (initialised to 0 by FIN_GenerateInstrFlows())
**                  position      The current position. Can be null
**
**  Warning     :   Calling function is FIN_GenerateInstrFlows()
**
**  Return      :   RET_SUCCEED 
**                  RET_MEM_ERR_ALLOC
**                  RET_GEN_ERR_INVARG
**
**  Modif.	:   BUG173 - RAK - 961009 
**  Modif.	:   BUG400 - RAK - 970613 
**  Modif.	:   BUG473 - RAK - 970827 
**  Modif.	:   REF158 - RAK - 971105 
**  Modif.	:   REF358 - RAK - 971210 
**  Modif.	:   REF1079 - RAK - 971219 
**  Modif       :   REF1149 - RAK - 980113
**  Modif       :   REF2580 - SSO - 980727
**  Modif       :   REF2569 - AKO - 980818
**  Modif       :   REF4075 - CSY - 991027
**  Modif       :   REF4075 - CSY - 991111 shift finalD if earliest rule
**  Modif       :                          don't generate income flows if after exchange flow
**  Modif       :             CSY - 992312 delete exchange flows that may occur after redemption flow
**	Modif       :   REF3990 - SSO - 000406 : modified ERROR MANAGEMENT !!! be careful if further modification 
**  Modif       :   REF5937.3503  - AKO - 010606 : Take into account c alendar when compute accint + flows
**  Modif       :   REF7402 - YST - 020305
**  Modif       :   REF10531 - TEB - 040806
**                  REF10752 - TEB - 041122
**                  REF11218 - TEB - 050627
**              :   PMSTA02087 - BSA - 080220 : Accrual Rule "Actual/360" is not working properly computing the Unit Income
**                  PMSTA-32116 - 200818 - PMO : [KD-1022A] WS - Structured Product - Instrument Financial Processing : Financial functions
**
*************************************************************************/
RET_CODE FIN_BondFlows(DATETIME_T           fromDateTime,
                       DATETIME_T           tillDateTime,
                       DATETIME_T           valDateTime,
                       FLAG_T               noRefDateFlg,   /* PMSTA-9032 - RAK - 091216 */
                       DBA_DYNFLD_STP       instrPtr,
                       EVTDATERULE_ENUM     evtDateRule,    /* REF4075 - CSY - 991027 */
                       ACCRRULE_ENUM        accrRule,       /* REF11218 - TEB - 050627 */
                       DBA_DYNFLD_STP **    flowTab,
                       int *                flowNbr, 
                       DBA_HIER_HEAD_STP    hierHead,
                       const DBA_DYNFLD_STP position)       /* PMSTA-32116 - 200818 - PMO */
{
    DBA_DYNFLD_STP  flowPtr = nullptr,
        bondPtr = nullptr,
        * incTab = nullptr,
        domainPtr = nullptr;
    int             i, currPeriod = 0,
        allocSz = 0, reallocSz = 5;
    char            final = FALSE;
    double          freq = 0.;
    DAY_T           svEndD, exDay = 0, day;
    char            endMFlg = 0, exEndMFlg = 0;
    DATETIME_T      begDate, endDate, date, firstCoupDate, tmpFirstDate,
        tmpFromD, validDate, tmpDate;
    DATE_T          finalD = MAGIC_END_DATE;
    NUMBER_T        bestYtm = 0.0;
    MemoryPool      mp;

    /* REF5937.3503 - AKO - 010606 */
    DATETIME_T              tmpEndDate, tmpBegDate;
    FLAG_T                  instrNatSwapBrise = FALSE, complexRateFlg = FALSE;

    tmpEndDate.reset();
    tmpBegDate.reset();

    firstCoupDate.time = 0;
    begDate.time = 0;
    endDate.time = 0;
    date.time = 0;
    tmpDate.time = 0;


    /* DVP384 - XDI - 970314 - Generate Exchange Flow for Bonds */
    /* REF2569 - AKO - 980817 */
    FIN_CreateExchangeFlows(instrPtr, fromDateTime, &tillDateTime, valDateTime,
                            evtDateRule, &allocSz, flowNbr, flowTab, hierHead); /* REF4075 - CSY - 991027 */

    int oldFlows = *flowNbr;/* REF3990 - SSO - 000406 */

    /* REF1939 - DDV - 980429 */
    for (i = 0; i < *flowNbr; i++)
    {
        /* REF2092 - DDV - 980901 - Replace BegPayDate with OptimalDate */
        if (GET_FLAG((*flowTab)[i], Flow_ReplaceFlg) == TRUE &&
            GET_DATETIME((*flowTab)[i], Flow_OptimalDate).date < finalD &&
            /* REF4075 - CSY - 991101 - don't shift finalD. Need to generate flows
               for optional events */
            ((!((GET_ENUM((*flowTab)[i], Flow_SubNatEn) == FlowSubNat_OptConvIssExch) ||
                (GET_ENUM((*flowTab)[i], Flow_SubNatEn) == FlowSubNat_OptConvHoldExch))) ||
             /* REF4075 - CSY - 991111 - if earliest rule, shift finalD */
             (evtDateRule == EvtDateRule_Earliest)))
        {
            finalD = GET_DATETIME((*flowTab)[i], Flow_OptimalDate).date;
            final = TRUE;
        }
    }

    FUSDATERULE_ENUM fusDateRule = FusDateRule_None;
    GEN_GetApplInfo(ApplFusDateRule, &fusDateRule); /* REF1149 */

    /* Replace cum option by ex bond */
    if ((INSTRNAT_ENUM)
        GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_CumOption)
    {
        bondPtr = mp.allocDynst(FILEINFO, A_Instr);

        RET_CODE ret = FIN_TreatCumOption(instrPtr, fromDateTime, bondPtr, hierHead);
        if (ret != RET_SUCCEED)
        {
            return(ret);
        }
        else if ((domainPtr = DBA_GetDomainPtr(DBA_GetConnectNoFromHier(hierHead))) != NULLDYNST) /* REF2580 - SSO - 980727 */
        {
            DBA_DYNFLD_STP testInstrPtr = nullptr;
            DBA_GetRecPtrFromHierById(hierHead, GET_ID(bondPtr, A_Instr_Id), A_Instr, &testInstrPtr); /* PMSTA-41519  - LJE - 201207 - To avoid duplicate insert into hierarchy */

            if (testInstrPtr == nullptr)
            {
                if ((ret = DBA_AddHierRecord(hierHead, bondPtr, A_Instr, FALSE, HierAddRec_TestMandatLnk)) != RET_SUCCEED)
                {
                    return(ret);
                }
                mp.removeDynStp(bondPtr);
            }
        }

        /* REF11218 - TEB - 050627 */
        /* Only treat bonds */
        accrRule = AccrRule_None;
    }
    else
    {
        bondPtr = instrPtr;
    }

    int              ioRNbr = 0;
    DBA_DYNFLD_STP* ioRTab = nullptr;
    RET_CODE         ret = DBA_SelectIOREvt(bondPtr, fromDateTime, tillDateTime, valDateTime, &ioRTab, &ioRNbr);

    if (ret != RET_SUCCEED)
    {
        return(ret);
    }

    /*** SINKING FUND REDEMPTION ***/
    bool sinking = false;
    for (i = 0; i < ioRNbr && sinking == false; i++)
    {
        if (GET_ENUM(ioRTab[i], A_IssueEvt_NatEn) == IssRedmNat_Amort)
            sinking = true;
    }


    /*PMSTA-46814 SENTHILKUMAR - 29102021*/
    FLAG_T mktConvMethodEnblFlg = FALSE;
    if (instrPtr != nullptr)
    {

        DBA_DYNFLD_STP* selInterTab = NULLDYNSTPTR;
        int                 selInterNbr = 0;

        if ((INSTRNAT_ENUM)GET_ENUM(instrPtr, A_Instr_NatEn) != InstrNat_CashAcct)
        {
            DBA_DYNFLD_STP      intRateCondPtr = NULLDYNST;

            FLAG_T		        interCondRecFlg = FALSE;

            RET_CODE            retn;

            intRateCondPtr = mp.allocDynst(FILEINFO, A_InterCond);

            if (GET_ID(instrPtr, A_Instr_Id) < 0)
            {
                SET_ID(intRateCondPtr, A_InterCond_InstrId, GET_ID(instrPtr, A_Instr_ParentInstrId));
            }
            else
            {
                SET_ID(intRateCondPtr, A_InterCond_InstrId, GET_ID(instrPtr, A_Instr_Id));
            }
            COPY_DYNFLD(intRateCondPtr, A_InterCond, A_InterCond_BeginDate, instrPtr, A_Instr, A_Instr_BeginDate);
            COPY_DYNFLD(intRateCondPtr, A_InterCond, A_InterCond_EndDate, instrPtr, A_Instr, A_Instr_EndDate);
            SET_ENUM(intRateCondPtr, A_InterCond_NatEn, InterCondNat_None);

            if (instrPtr != NULLDYNST &&
                (CMP_ENUM((INSTRNAT_ENUM)GET_ENUM(instrPtr, A_Instr_NatEn), InstrNat_FundShare) == 0) &&
                ((CMP_ENUM((SUBNAT_ENUM)GET_ENUM(instrPtr, A_Instr_SubNatEn), SubNat_MoneyMarketFundShare) == 0) ||
                 (CMP_ENUM((SUBNAT_ENUM)GET_ENUM(instrPtr, A_Instr_SubNatEn), SubNat_FixedIncomeFundShare) == 0)))
            {
                COPY_DYNFLD(intRateCondPtr, A_InterCond, A_InterCond_ValidDate, instrPtr, A_Instr, A_Instr_EndDate);
            }

            if ((retn = DBA_SelAllInterCond(InterCond_ByIdDt, hierHead, instrPtr, intRateCondPtr,
                                            &selInterTab, &selInterNbr, &interCondRecFlg)) != RET_SUCCEED)
            {
                retn = RET_DBA_ERR_NODATA;
                MSG_SendMesg(retn, 3, FILEINFO, "DBA_SelectInterCond", GET_CODE(instrPtr, A_Instr_Cd), "interest condition");
                return retn;
            }
        }

        if (selInterNbr > 0 &&
            static_cast<InstrMktConvMethodEn>GET_ENUM(selInterTab[0], A_InterCond_MktConvMethodEn) != InstrMktConvMethodEn::None)
        {
            mktConvMethodEnblFlg = TRUE;
        }
        DBA_FreeDynStTab(selInterTab, selInterNbr, A_InterCond);
    }

    if (sinking == true)
    {
        /* Stop if final redemption event append before report begin */
        for (i = 0; i < ioRNbr; i++)
        {
            if (GET_ENUM(ioRTab[i], A_IssueEvt_NatEn) == IssRedmNat_FinalRedm)
            {
                if (GET_DATE(ioRTab[i], A_IssueEvt_EndDate) < fromDateTime.date)
                {
                    DBA_FreeDynStTab(ioRTab, ioRNbr, A_IssueEvt);
                    return(RET_SUCCEED);
                }
            }
        }

        /* Compute proportion of each redemption */
        PERCENT_T propor = 0.0;

        for (i = 0; i < ioRNbr; i++)
        {
            FIN_PeriodUnitNbr((FREQUNIT_ENUM)GET_ENUM(ioRTab[i], A_IssueEvt_FreqUnitEn), /* REF7264 - CSY - 020130 */
                              GET_TINYINT(ioRTab[i], A_IssueEvt_Freq),
                              FreqUnit_Month, &freq);

            endDate.date = GET_DATE(ioRTab[i], A_IssueEvt_BegDate);

            while (endDate.date <= GET_DATE(ioRTab[i], A_IssueEvt_EndDate))
            {
                /* REF358 - Compute remaining proportion */
                if (endDate.date >= fromDateTime.date)
                    propor += (GET_PERCENT(ioRTab[i], A_IssueEvt_ProporPrct));

                if (freq == 0.)         /* No repetitive event, stop */
                    endDate.date = DATE_Move(endDate.date, 1, Day);
                else
                    endDate.date = DATE_Move(endDate.date, (int)freq, Month);
            }
        }

        /* For each redemption event */
        for (final = FALSE, i = 0; i < ioRNbr; i++)
        {
            FIN_PeriodUnitNbr((FREQUNIT_ENUM)GET_ENUM(ioRTab[i], A_IssueEvt_FreqUnitEn),    /* REF7204 - CSY - 020130 */
                              GET_TINYINT(ioRTab[i], A_IssueEvt_Freq),
                              FreqUnit_Month, &freq);

            /* Skip invalid events */
            if (GET_DATE(ioRTab[i], A_IssueEvt_EndDate) <
                fromDateTime.date)
                continue;

            begDate.date = GET_DATE(ioRTab[i], A_IssueEvt_BegDate);
            endDate.date = GET_DATE(ioRTab[i], A_IssueEvt_BegDate);

            /* Short month can corrupt day number */
            endMFlg = (char)DATE_IsLastInMonth(endDate.date);
            DATE_Get(endDate.date, nullptr, nullptr, &svEndD);

            if (endDate.date == BAD_DATE)
            {
                /* FREE_DYNST(unitInter, UnitInter);    REF2569 - AKO - 980818 - REF3990 - SSO - 000406 */
                DBA_FreeDynStTab(ioRTab, ioRNbr, A_IssueEvt);
                MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, "FIN_BondFlows",
                             GET_CODE(instrPtr, A_Instr_Cd), "end date");

                /* REF3990 - SSO - 000406 remove last flows */
                for (i = oldFlows; i < (*flowNbr); i++)
                {
                    FREE_DYNST((*flowTab)[i], Flow);
                }
                (*flowNbr) = oldFlows;
                /*return(RET_FIN_ERR_INVDATA); REF3990 - SSO - 000406 */
                break; /* end IOR treatment, but continue with Incomes */
            }

            /* Advance in repetitiv event until journal begin date */
            currPeriod = 1;
            while (endDate.date < fromDateTime.date)
            {
                begDate = endDate;
                if (freq == 0.)    /* No repetitive event (one period) */
                    endDate.date = GET_DATE(ioRTab[i], A_IssueEvt_EndDate);
                else
                {
                    endDate.date = DATE_Move(begDate.date, (int)freq, Month);
                    /* Short month can corrupt day number */
                    DATE_VerifyEndMonth(&endDate.date, svEndD, endMFlg);
                }
                ++currPeriod;
            }

            /* For each period in current issue or redemption event */
        /* (one in case of no repetitive event)    */
            while (endDate.date <= GET_DATE(ioRTab[i], A_IssueEvt_EndDate) &&
                   endDate.date <= tillDateTime.date)
            {
                if ((ret = FIN_CreateBondFlow(&allocSz, *flowNbr, flowTab, ioRTab[i],
                                              currPeriod, propor, 0.0,
                                              begDate, endDate, &final)) != RET_SUCCEED)
                {
                    /* FREE_DYNST(unitInter, UnitInter);    REF2569 - AKO - 980818 - REF3990 - SSO - 000406 */
                    DBA_FreeDynStTab(ioRTab, ioRNbr, A_IssueEvt); /* REF2569 - AKO - 980818 */
                    /* REF3990 - SSO - 000406 if fatal error, return */
                    if (FATAL_FLOWSERROR(ret) == TRUE)
                    {
                        return(ret);
                    }
                    else
                    {
                        /* REF3990 - SSO - 000406 remove last flows */
                        for (i = oldFlows; i < (*flowNbr); i++)
                        {
                            FREE_DYNST((*flowTab)[i], Flow);
                        }
                        (*flowNbr) = oldFlows;
                        break; /* end IOR treatment, but continue with Incomes */
                    }
                }

                /*if (final == TRUE && endDate.date < finalD)  REF1939 - DDV - 980428 */
                if (final == TRUE)
                    finalD = endDate.date;

                /* Go on next period */
                (*flowNbr)++;
                currPeriod++;
                begDate = endDate;

                if (freq == 0.)         /* No repetitive event, stop */
                    endDate.date = DATE_Move(endDate.date, 1, Day);
                else
                {
                    endDate.date = DATE_Move(begDate.date, (int)freq, Month);
                    /* Short month can corrupt day number */
                    DATE_VerifyEndMonth(&endDate.date, svEndD, endMFlg);
                }
            }
        }
    }
    else
    {
        int redempEvt = -1;

        if (ioRNbr == 1)
        {
            redempEvt = 0;
            ret = RET_SUCCEED;
        }
        else
        {
            /* REF10531 - TEB - 040806 */
            /* Replacement of Techhackers by Simcorp call */
            ret = SCE_MostProbRedempEvt(ioRTab,
                                        ioRNbr,
                                        instrPtr,
                                        fromDateTime,
                                        &bestYtm,
                                        &redempEvt,
                                        hierHead);
        }

        if (ret == RET_SUCCEED && redempEvt != -1)
        {
            endDate.date = GET_DATE(ioRTab[redempEvt], A_IssueEvt_EndDate);
            /*PMSTA-46814 SENTHILKUMAR - 29102021*/
            if (mktConvMethodEnblFlg == TRUE && IS_NULLFLD(instrPtr, A_Instr_BusDayConvEn) != TRUE && ((CALNEXTBUSDATERULE_ENUM)GET_ENUM(instrPtr, A_Instr_BusDayConvEn) != CalNextBusDateRule_Default))
            {
                ID_T        calendarId = 0;

                CALNEXTBUSDATERULE_ENUM	nextBusDateEnm = (CALNEXTBUSDATERULE_ENUM)GET_ENUM(instrPtr, A_Instr_BusDayConvEn);

                DBA_GetCalendarFromInstr(instrPtr, &calendarId);
                ret = SCE_CldrNextBusinessDate(instrPtr, calendarId, &nextBusDateEnm, endDate, &endDate);
            }
            endDate.time = 0;

            if (endDate.date <= tillDateTime.date)
            {
                begDate.date = GET_DATE(ioRTab[redempEvt], A_IssueEvt_BegDate);
                begDate.time = 0;

                if (begDate.date < finalD) /* REF1939 - DDV - 980428 */
                {
                    if ((ret = FIN_CreateBondFlow(&allocSz, *flowNbr, flowTab, ioRTab[redempEvt],
                                                  1, 100.0, bestYtm,
                                                  begDate, endDate, &final)) != RET_SUCCEED)
                    {
                        /* FREE_DYNST(unitInter, UnitInter);    REF2569 - AKO - 980818 - REF3990 - SSO - 000406 */
                        DBA_FreeDynStTab(ioRTab, ioRNbr, A_IssueEvt); /* REF2569 - AKO - 980818 */
                        /* REF3990 - SSO - 000406 if fatal error, return */
                        if (FATAL_FLOWSERROR(ret) == TRUE)
                        {
                            return(ret);
                        }
                        else
                        {
                            /* REF3990 - SSO - 000406 remove last flows */
                            for (i = oldFlows; i < (*flowNbr); i++)
                            {
                                FREE_DYNST((*flowTab)[i], Flow);
                            }
                            (*flowNbr) = oldFlows;
                        }
                    }
                    else /* else added: REF3990 - SSO - 000406 */
                    {
                        final = TRUE;
                        finalD = GET_DATE(ioRTab[redempEvt], A_IssueEvt_BegDate);

                        (*flowNbr)++; /* DVP384 - XDI - 970314 */

                        /* CSY 991223: delete flows occuring after a call,put or
                        final redemption flow (for ex: exchange flow) */
                        for (i = 0; i < *flowNbr; i++)
                        {
                            if (GET_DATETIME((*flowTab)[i], Flow_OptimalDate).date >= finalD
                                && GET_ENUM((*flowTab)[i], Flow_SubNatEn) != FlowSubNat_FinalRedm
                                && GET_ENUM((*flowTab)[i], Flow_SubNatEn) != FlowSubNat_CallRedm
                                && GET_ENUM((*flowTab)[i], Flow_SubNatEn) != FlowSubNat_PutRedm)
                            {
                                /* we delete the flow from the array */
                                FREE_DYNST((*flowTab)[i], Flow);
                                (*flowNbr)--;
                                for (int j = i; j < *flowNbr; j++)
                                {
                                    (*flowTab)[j] = (*flowTab)[j + 1];
                                }
                                i--; /* array has been shifted to left */
                            }
                        }
                    }
                }
            }
        }
    }

    DBA_FreeDynStTab(ioRTab, ioRNbr, A_IssueEvt);

    /* Update amortisation */
    int redNbr = *flowNbr;

    oldFlows = *flowNbr;/* REF3990 - SSO - 000406 update already OK added flows */

    DATETIME_T tmpTillD;
    tmpTillD.time = 0;
    tmpTillD.date = final == TRUE && finalD < tillDateTime.date ? finalD : tillDateTime.date;

    int incNbr = 0;
    if ((ret = DBA_SelectIncEvt(bondPtr, fromDateTime, tmpTillD,
                                valDateTime, &incTab, &incNbr)) != RET_SUCCEED)
    {
        RET_GENFLOWS(ret); /* REF3990 - SSO - 000406 */
    }
    /* PMSTA-15106  - TGU - 121121 - update event's empty end date to next event's Begain date, to prevent many income event for same day   */
    for (i = 0; i < incNbr; i++)
    {
        if (IS_NULLFLD(incTab[i], A_IncEvt_LastPayDate) == TRUE ||
            GET_DATE(incTab[i], A_IncEvt_LastPayDate) == MAGIC_END_DATE)
        {
            if (i + 1 < incNbr)
            {
                SET_DATE(incTab[i], A_IncEvt_LastPayDate, GET_DATE(incTab[i + 1], A_IncEvt_BeginDate));
            }
            else
            {
                SET_DATE(incTab[i], A_IncEvt_LastPayDate, GET_DATE(instrPtr, A_Instr_EndDate));
            }
        }
    }


    DBA_DYNFLD_STP unitInter = ALLOC_DYNST(UnitInter);
    if (nullptr == unitInter)
    {
        DBA_FreeDynStTab(ioRTab, ioRNbr, A_IssueEvt);
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }


    for (i = 0; i < incNbr; i++)
    {

        FIN_PeriodUnitNbr((FREQUNIT_ENUM)GET_ENUM(incTab[i], A_IncEvt_PayFreqUnitEn), /* REF7264 - CSY - 020130 */
                          GET_TINYINT(incTab[i], A_IncEvt_PayFreq),
                          FreqUnit_Month, &freq);

        /* Income event must be in report period */
        if (GET_DATE(incTab[i], A_IncEvt_LastPayDate) < fromDateTime.date)
            continue;

        begDate.date = GET_DATE(incTab[i], A_IncEvt_BeginDate);
        firstCoupDate = GET_DATETIME(incTab[i], A_IncEvt_FirstCoupDate);
        endDate.date = GET_DATE(incTab[i], A_IncEvt_BeginDate);

        /* Short month can corrupt day number */
        endMFlg = (char)DATE_IsLastInMonth(endDate.date);
        DATE_Get(endDate.date, nullptr, nullptr, &svEndD);

        /* Advance in repetitiv event until journal begin date */
        /* but at least to first coupon date (one frequency)   */	/* BUG473 */
        currPeriod = 0;
        int irregLastPay = 0;

        /* REF486 - XDI - 971008 - compute number of days between first exdate and first coupon date */
        long nbrDays = 0;
        if (IS_NULLFLD(incTab[i], A_IncEvt_FirstExDate) == FALSE)
        {
            tmpFirstDate.time = 0;
            if (IS_NULLFLD(incTab[i], A_IncEvt_FirstCoupDate) == TRUE)
                tmpFirstDate.date = DATE_Move(begDate.date, (int)freq, Month);
            else
                tmpFirstDate.date = firstCoupDate.date;

            if (tmpFirstDate.date < GET_DATE(incTab[i], A_IncEvt_FirstExDate))
            {
                SET_NULL_DATETIME(incTab[i], A_IncEvt_FirstExDate);
            }
            else
            {
                DATE_DaysBetween(GET_DATE(incTab[i], A_IncEvt_FirstExDate),
                                 tmpFirstDate.date /* firstCoupDate.date */, AccrRule_Actual_365, &nbrDays, 0); /* REF10752 - TEB - 041122 */  /* PMSTA-22396  - SRIDHARA ? 160430 */
                exEndMFlg = (char)DATE_IsLastInMonth(GET_DATE(incTab[i], A_IncEvt_FirstExDate));
                DATE_Get(GET_DATE(incTab[i], A_IncEvt_FirstExDate), nullptr, nullptr, &exDay);
            }
        }

        /* REF486 - XDI - 971008 - compute tmpFromDate based on first exdate */
        tmpFromD.date = DATE_Move(fromDateTime.date, nbrDays, Day);

        do
        {
            begDate = endDate;

            /* First coupon date can be 0 */
            if (firstCoupDate.date > begDate.date)
            {
                endDate.date = firstCoupDate.date;
                /* BUG400 - RAK - 970613 */
                endMFlg = (char)DATE_IsLastInMonth(endDate.date);
                DATE_Get(endDate.date, nullptr, nullptr, &svEndD);
            }
            else
            {
                if (freq == 0.)  /* No repetitive event */
                {
                    /* REF7402 - YST - 020305 - return message if instrument bad defined */
                    /* REF10771 - DDV - 041119 - If both date are NULL continue, don't return an error */
                    if (IS_NULLFLD(instrPtr, A_Instr_FirstExDate) == FALSE && IS_NULLFLD(instrPtr, A_Instr_DatedDate) == FALSE &&
                        GET_DATE(instrPtr, A_Instr_FirstExDate) == GET_DATE(instrPtr, A_Instr_DatedDate))
                    {
                        FREE_DYNST(unitInter, UnitInter);
                        DBA_FreeDynStTab(incTab, incNbr, A_IncEvt);
                        for (i = oldFlows; i < (*flowNbr); i++)
                        {
                            FREE_DYNST((*flowTab)[i], Flow);
                        }
                        (*flowNbr) = oldFlows;
                        MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, "FIN_BondFlows",
                                     GET_CODE(instrPtr, A_Instr_Cd), "first ex date = dated date");
                        return(RET_FIN_ERR_INVDATA);
                    }
					/*PMSTA-49035 -FirstCoupon date , Last Coupon date and end date is same case  */
					else if ((firstCoupDate.date != NULL && endDate.date != NULL && IS_NULLFLD(instrPtr, A_Instr_LastCoupDate) == FALSE) && (firstCoupDate.date == GET_DATE(instrPtr, A_Instr_LastCoupDate) && endDate.date == GET_DATE(instrPtr, A_Instr_LastCoupDate)))
					{
						MSG_LogSrvMesg(UNUSED, 0, "For the instrument %1 payment frequency= 0 . First Coupon date , end date  and Last coupon date is Same date needs to be corrected.", CodeType, GET_CODE(instrPtr, A_Instr_Cd));

						return(RET_FIN_ERR_INVDATA);
					}
                    else
                        endDate.date = GET_DATE(incTab[i], A_IncEvt_LastPayDate);
                }
                else
                {
                    endDate.date = DATE_Move(begDate.date, (int)freq, Month);
                    /*PMSTA-46645 SENTHILKUMAR - 18102021*/
                    if (mktConvMethodEnblFlg == TRUE && (DATE_Between(GET_DATE(instrPtr, A_Instr_BeginDate), begDate.date, DATE_Move(begDate.date, (int)freq, Month)) && (IS_NULLFLD(instrPtr, A_Instr_DatedDate) == FALSE && DATE_Cmp(GET_DATE(instrPtr, A_Instr_DatedDate), begDate.date) == 0)))
                        endDate.date = DATE_Move(GET_DATE(instrPtr, A_Instr_BeginDate), (int)freq, Month);
                    /* Short month can corrupt day number */
                    DATE_VerifyEndMonth(&endDate.date, svEndD, endMFlg);
                }
            }

            /* Irregular last period case :   */
            /* 31/01 + 6 months => 31/07      */
            /* 31/07 + 6 months => 31/01      */
            /* but last payment date is 31/12 */
            /* -> force payment date to 31/12 */
            if (IS_NULLFLD(incTab[i], A_IncEvt_LastPayDate) == FALSE &&
                GET_DATE(incTab[i], A_IncEvt_LastPayDate) < endDate.date)
            {
                endDate.date = GET_DATE(incTab[i], A_IncEvt_LastPayDate);
                ++irregLastPay;	/* force ONLY ONE time last payment date */
            }

            ++currPeriod;
        } while (endDate.date < tmpFromD.date && irregLastPay < 2);
        /* while (endDate.date < fromDateTime.date && irregLastPay < 2);*/

        /* For each period in current income event */
        /* (one in case of no repetitive event)    */
        if (IS_NULLFLD(incTab[i], A_IncEvt_LastPayDate) == TRUE)
        {
            SET_DATE(incTab[i], A_IncEvt_LastPayDate, tmpTillD.date);
        }

        /* First income is paid on total value */
        PERCENT_T amort = 1.0;
        int       redPos = 0;

        irregLastPay = 0;

        /* REF486 - XDI - 971008 - compute tmpTillDate based on first exdate */
        tmpTillD.date = DATE_Move(tmpTillD.date, nbrDays, Day);

        /* ---------------------------------------------------------------------------- */
        /* REF5937.3503 - AKO - 010530 Take into account calendar for accrinter + flows */
        /* ---------------------------------------------------------------------------- */
        if (TRUE == FIN_IsBondOfSwap(instrPtr, hierHead))
        {
            instrNatSwapBrise = TRUE;
        }
        tmpBegDate.date = begDate.date; /* REF5937.3503 - AKO - 010614 */

        while ((endDate.date <= GET_DATE(incTab[i], A_IncEvt_LastPayDate))
               &&
               (endDate.date <= tmpTillD.date && irregLastPay < 2)
               )
        {
            /* REF5937.3503 - AKO - 010606 */
            CALNEXTBUSDATERULE_ENUM	nextBusDateEn = CalNextBusDateRule_Next;

            tmpEndDate.date = endDate.date;

            if (IS_NULLFLD(instrPtr, A_Instr_BusDayConvEn) != TRUE)
            {
                nextBusDateEn = (CALNEXTBUSDATERULE_ENUM)GET_ENUM(instrPtr, A_Instr_BusDayConvEn); /* REF7264 - CSY - 020130 */
            }
            DATETIME_T tmpEndDate30360;
            tmpEndDate30360.reset();
            bool tmpEndDate31 = false;
            if (TRUE == instrNatSwapBrise || (mktConvMethodEnblFlg == TRUE && nextBusDateEn != CalNextBusDateRule_Default))
            {
                DATETIME_T busconvtmpEndDate = tmpEndDate;
                SCE_CldrNextBusinessDate(/*NULLDYNST*/         instrPtr,
                                         /*calendarId*/        0,
                                         /*nextBusDateEnPtr*/  &nextBusDateEn,
                                         /*recDate*/           tmpEndDate,
                                         /*&nextBusDate*/      &tmpEndDate);
                /*PMSTA-46783 - SENTHILKUMAR - 28102021*/
                if (mktConvMethodEnblFlg == TRUE && ((ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_30_360 ||
                                                     (ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_30E_360 ||
                                                     (ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_30_360_1 ||
                                                     (ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_30_360_US ||
                                                     (ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_30_360_FebAdj ||
                                                     (ACCRRULE_ENUM)GET_ENUM(instrPtr, A_Instr_AccrualRuleEn) == AccrRule_30_360_Def))
                {
                    DAY_T date_30360 = 0;
                    DATE_Get((DATE_T)tmpEndDate.date, (YEAR_T*)NULL, (MONTH_T*)NULL, (DAY_T*)&date_30360);
                    if (date_30360 == 31)
                    {
                        tmpEndDate31 = true;
                        tmpEndDate30360 = tmpEndDate;
                        tmpEndDate = busconvtmpEndDate;
                    }
                }
            }

            /* REF158 - Move allocation after rate calculation */
            if ((ret = FIN_PeriodUnitAccrInter(bondPtr,
                                               tmpBegDate.date,  /*begDate.date*/ /* REF5937.3503 - AKO - 010614 */
                                               tmpEndDate.date,  /*endDate.date,*/  /* REF5937.3503 - AKO - 010606 */
                                               nullptr, incTab[i],
                                               accrRule,	 /* REF11218 - TEB - 050627 */
                                               unitInter, hierHead, &complexRateFlg)) != RET_SUCCEED)
            {
                DBA_FreeDynStTab(incTab, incNbr, A_IncEvt);
                FREE_DYNST(unitInter, UnitInter);
                MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO,
                             "FIN_BondFlows", GET_CODE(instrPtr, A_Instr_Cd), "interest");
                /* REF3990 - SSO - 000406 remove last flows */
                for (i = oldFlows; i < (*flowNbr); i++)
                {
                    FREE_DYNST((*flowTab)[i], Flow);
                }
                (*flowNbr) = oldFlows;
                return(RET_SUCCEED); /* REF3990 - SSO - 000406 RET_FIN_ERR_INVDATA->minor error */
            }

            /* REF222 - XDI - 971013 */
            tmpDate.date = DATE_Move(begDate.date, (int)freq, Month);
            /* Short month can corrupt day number */
            DATE_VerifyEndMonth(&tmpDate.date, svEndD, endMFlg);

            /* PMSTA-9032 - RAK - 091216 - Don't use the domain refDate for the validity of IRC (for FIN_GetInstrAccrRule() */
            if (noRefDateFlg == FALSE &&
                (domainPtr = DBA_GetDomainPtr(DBA_GetConnectNoFromHier(hierHead))) != NULLDYNST) /* REF2580 - SSO - 980727 */
                validDate = GET_DATETIME(domainPtr, A_Domain_CalcRefDate);
            else
            {
                validDate = begDate;
            }

            /* REF222 - XDI - 971013 - In case of regular period, read rate   */
            /* in database and don't use computed accrued interest because of */
            /* days difference (2 months can be 60, 61, 62, ... days)         */

            NUMBER_T rate = ZERO_NUMBER;

            /* PMSTA-36699 - Silpakal - 191127  Specific rate for each period for this kind of instrument (STN) */
            if (GET_ENUM(unitInter, UnitInter_InterCalcRuleEn) != (ENUM_T)InterCalcRule_Fixed)
            {
                rate = GET_NUMBER(unitInter, UnitInter_UnitAccrInter);
            }
            else
            {
                if ((tmpDate.date == endDate.date) && (!instrNatSwapBrise) && complexRateFlg == FALSE) /* REF5937.3503 - AKO - 010606 */
                {
                    FIN_GetCouponRate(GET_ID(bondPtr, A_Instr_Id), bondPtr,
                                      incTab[i], begDate, validDate, accrRule,	/* REF11218 - TEB - 050627 */
                                      unitInter, hierHead);

                    rate = GET_NUMBER(unitInter, UnitInter_UnitAccrInter) * (freq / 12);
                }
                else
                {
                    rate = GET_NUMBER(unitInter, UnitInter_UnitAccrInter);
                }
            }

            /* BUG159 - 961003 - XDI - BEGIN */
            /* Solution is more complex c.f. IRM */
            /*if (GET_NUMBER(unitInter, UnitInter_NumPeriod) != 0 &&
            GET_NUMBER(unitInter, UnitInter_DenomPeriod) != 0)*/
            /*coupon = CAST_NUMBER(GET_NUMBER(unitInter, UnitInter_UnitAccrInter) * 100); */
            /*else
            coupon = CAST_NUMBER(GET_NUMBER(unitInter, UnitInter_UnitAccrInter) *
            100 *
            (GET_NUMBER(unitInter, UnitInter_DenomPeriod) /
            GET_NUMBER(unitInter, UnitInter_NumPeriod))); */
            /* BUG159 - 961003 - XDI - END */

            /* REF222 - XDI - 971013 */
            NUMBER_T coupon = rate * 100;

            { /* PMSTA-32116 - 200818 - PMO */
                InstrumentStructureNote stn(instrPtr);

                /* PMSTA-35643 - RAK - 190527 - Specific rate for each period for this kind of instrument (STN) */
                if (GET_ENUM(instrPtr, A_Instr_InterestCalculationRuleEn) == (ENUM_T)InstrInterestCalcRule_None)
                {
                    if (true == stn.isProcessing() && RET_SUCCEED == stn.computePayout(valDateTime, hierHead, coupon, position))
                    {
                        coupon = stn.getPayout();
                        rate = coupon * 0.01;
                    }
                }
            }

            /* REF158 - Create flow only in case of significativ rate */
            if (CMP_NUMBER(coupon, 0.0) != 0)
            {
                /* ----------------------------------------------------------------------- */
                /* REF5937 - AKO - 010905 Take into account calendar for to generate flows */
                /* ----------------------------------------------------------------------- */
                /*FIN_GetFisrtBusnessDate(instrPtr, &endDate);*/ /* REF5937.3503 - AKO - 010606 */
                if (allocSz == 0 || *flowNbr >= allocSz - 1) /* DVP384 - XDI - 970314 */
                {
                    allocSz += reallocSz;
                    if (((*flowTab) = static_cast<DBA_DYNFLD_STP*> (REALLOC((*flowTab), allocSz * sizeof(DBA_DYNFLD_STP)))) == nullptr)
                    {
                        DBA_FreeDynStTab(incTab, incNbr, A_IncEvt);
                        FREE_DYNST(unitInter, UnitInter);  /* REF2569 - AKO - 980818 */
                        MSG_RETURN(RET_MEM_ERR_ALLOC);
                    }
                }

                if (((*flowTab)[*flowNbr] = ALLOC_DYNST(Flow)) == NULLDYNST)
                {
                    DBA_FreeDynStTab(incTab, incNbr, A_IncEvt);
                    FREE_DYNST(unitInter, UnitInter);
                    MSG_RETURN(RET_MEM_ERR_ALLOC);
                }

                flowPtr = (*flowTab)[*flowNbr];
                SET_ID(flowPtr, Flow_InstrId, GET_ID(instrPtr, A_Instr_Id));
                SET_CODE(flowPtr, Flow_EvtCd, GET_CODE(incTab[i], A_IncEvt_Cd));
                SET_INT(flowPtr, Flow_EvtNbr, currPeriod); /* REF8844 - LJE - 030327 */
                SET_ENUM(flowPtr, Flow_NatEn, FlowNat_Inc);
                SET_FLAG(flowPtr, Flow_ConfirmedFlg, TRUE);
                SET_DATETIME(flowPtr, Flow_BegPayDate, begDate);
                SET_DATETIME(flowPtr, Flow_EndPayDate, endDate);
                SET_PERIOD(flowPtr, Flow_SettlDays, 0);
                if (tmpEndDate31 == true)
                {
                    SET_DATETIME(flowPtr, Flow_OptimalValDate, tmpEndDate30360);
                }
                else
                    SET_DATETIME(flowPtr, Flow_OptimalValDate, tmpEndDate); /* REF5937.3503 - AKO - 010606 */  /* REF468 - XDI - 971008 */

                if (nbrDays != 0)	/* exDay is set only if nbrDays != 0 */
                {
                    YEAR_T   year = 0;
                    MONTH_T  month = 0;

                    date.date = DATE_Move(tmpEndDate.date, -1 * static_cast<int>(nbrDays), Day); /* REF5937.3503 - AKO - 010606 */
                    DATE_Get(date.date, &year, &month, &day);
                    date.date = DATE_Put(year, month, exDay);

                    if (date.date == BAD_DATE)
                    {
                        date.date = DATE_Put(year, month, day);
                    }

                    DATE_VerifyEndMonth(&date.date, exDay, exEndMFlg);
                    SET_DATETIME(flowPtr, Flow_OptimalDate, date);
                }
                else
                {
                    if (tmpEndDate31 == true)
                    {
                        SET_DATETIME(flowPtr, Flow_OptimalDate, tmpEndDate30360);
                    }
                    else
                        SET_DATETIME(flowPtr, Flow_OptimalDate, tmpEndDate);  /* REF5937.3503 - AKO - 010606 */
                }

                SET_NUMBER(flowPtr, Flow_RefQty, amort);
                SET_NULL_PERCENT(flowPtr, Flow_IoRPrct);
                SET_PRICE(flowPtr,        Flow_Quote,        coupon);
                SET_PRICE(flowPtr,        Flow_AmtUnit,      rate);
                SUBNAT_ENUM	    subNatEn = SubNat_None;
                subNatEn = (SUBNAT_ENUM)GET_ENUM(instrPtr, A_Instr_SubNatEn);
                if ((static_cast<InstrMktConvMethodEn>GET_ENUM(instrPtr, A_Instr_PaidMktConvMethodEn) != InstrMktConvMethodEn::None || static_cast<InstrMktConvMethodEn>GET_ENUM(instrPtr, A_Instr_MktConvMethodEn) != InstrMktConvMethodEn::None) && (subNatEn == SubNat_PaidSwapFixedLeg || subNatEn == SubNat_PaidSwapFloatLeg))
                {
                    SET_PRICE(flowPtr, Flow_PaidAmtUnit, rate);
                }
                else if ((static_cast<InstrMktConvMethodEn>GET_ENUM(instrPtr, A_Instr_PaidMktConvMethodEn) != InstrMktConvMethodEn::None || static_cast<InstrMktConvMethodEn>GET_ENUM(instrPtr, A_Instr_MktConvMethodEn) != InstrMktConvMethodEn::None) && (subNatEn == SubNat_RecSwapFloatLeg || subNatEn == SubNat_RecSwapFixedLeg))
                {
                    SET_PRICE(flowPtr, Flow_ReceivedAmtUnit, rate);
                }
                SET_ID(flowPtr, Flow_AmtCurrId, GET_ID(unitInter, UnitInter_CurrId));
                SET_NULL_ID(flowPtr, Flow_NewInstrId);
                SET_NULL_NUMBER(flowPtr, Flow_QtyUnit);
                SET_NULL_ENUM(flowPtr, Flow_OptClassEn);
                SET_NULL_ENUM(flowPtr, Flow_OptStyleEn);
                SET_PERCENT(flowPtr, Flow_Proba, 100.0);
                SET_TINYINT(flowPtr, Flow_Freq, GET_TINYINT(incTab[i], A_IncEvt_PayFreq));
                SET_ENUM(flowPtr, Flow_FreqUnitEn, GET_ENUM(incTab[i], A_IncEvt_PayFreqUnitEn));
                SET_NULL_DATE(flowPtr, Flow_ExDate); /* ?? */
                SET_EXCHANGE(flowPtr, Flow_FxdExchRate, GET_EXCHANGE(incTab[i], A_IncEvt_FixedExchRate));
                SET_NULL_NUMBER(flowPtr, Flow_CtdConvFact);
                SET_NULL_NUMBER(flowPtr, Flow_CtdConvRatio);
                SET_NULL_ID(flowPtr, Flow_CtdInstrId);
                SET_FLAG(flowPtr, Flow_PhysicalFlg, FALSE);
                SET_NULL_TINYINT(flowPtr, Flow_Priority);
                SET_FLAG(flowPtr, Flow_EffectiveFlg, FALSE);
                SET_ENUM(flowPtr, Flow_SubNatEn, GET_ENUM(unitInter, UnitInter_InterCalcRuleEn));

                /* Go on next period */
                (*flowNbr)++;
                currPeriod++;
            }

            begDate = endDate;
            tmpBegDate = tmpEndDate; /* REF5937.3503 - AKO - 010614 */

            /* Update amortisation for next income */
            for (int j = redPos; j < redNbr; j++)
            {
                if (DATETIME_CMP(endDate, GET_DATETIME((*flowTab)[j], Flow_EndPayDate)) >= 0)
                {
                    amort -= (GET_PERCENT((*flowTab)[j], Flow_IoRPrct) / 100.0);
                    ++redPos;
                }
                else
                {
                    break;
                }
            }

            if (firstCoupDate.date > begDate.date)
            {
                endDate.date = firstCoupDate.date;

                /* BUG400 - RAK - 970613 */
                endMFlg = (char)DATE_IsLastInMonth(endDate.date);
                DATE_Get(endDate.date, nullptr, nullptr, &svEndD);
            }
            else
            {
                if (freq == 0.)     /* No repetitive event, stop */
                {
                    /* endDate.date = DATE_Move(begDate.date, 1, Day); */
                    irregLastPay = 2;	/* REF11839 - RAK - 060713 -> Really stop ! */
                }
                else
                {
                    endDate.date = DATE_Move(begDate.date, (int)freq, Month);
                    /* Short month can corrupt day number */
                    DATE_VerifyEndMonth(&endDate.date, svEndD, endMFlg);
                }
            }

            /* If next payment is last payment, create flow  */
            /* on last payment date and stop after this flow */
            if (IS_NULLFLD(incTab[i], A_IncEvt_LastPayDate) == FALSE &&
                GET_DATE(incTab[i], A_IncEvt_LastPayDate) < endDate.date &&
                GET_DATE(incTab[i], A_IncEvt_LastPayDate) != begDate.date) /* BUG173 */
            {
                endDate.date = GET_DATE(incTab[i], A_IncEvt_LastPayDate);
                ++irregLastPay; /* force ONLY ONE time last payment date */
            }

        } /* while (endDate.date ... */
    }

    DBA_FreeDynStTab(incTab, incNbr, A_IncEvt);

    FREE_DYNST(unitInter, UnitInter);

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_CreateBondFlow()
**
**  Description :   Generate a flow for bond depending on redemption event
**                 
**  Arguments   :   
**
**  Return      :   RET_SUCCEED or error code
**
**  Modif	:   BUG232  - RAK - 961217
**  Modif	:   REF358  - RAK - 980316
**  Modif   :   REF5937 - AKO - 010509 - Take into account calendar for 
**                                       to generate flows
**
*************************************************************************/
STATIC RET_CODE FIN_CreateBondFlow(int               *allocSz, 
                           int               flowNbr, 
                           DBA_DYNFLD_STP    **flowTab, 
                           DBA_DYNFLD_STP    IoR,
                           int               currPeriod,
                           PERCENT_T         propor,
                           NUMBER_T          bestYtm,
                           DATETIME_T        begDate,
                           DATETIME_T        endDate,
                           char              *final)
{
    int            	reallocSz=5;
    DBA_DYNFLD_STP 	flowPtr;
    DATETIME_T     	date;
    NUMBER_T	    amtUnit;


    if (*allocSz == 0 || flowNbr >= (*allocSz)-1) /* DVP384 - XDI - 970314 */
    {
        (*allocSz)+=reallocSz;
        if (((*flowTab) = (DBA_DYNFLD_STP *) 
             REALLOC((*flowTab), (*allocSz)*sizeof(DBA_DYNFLD_STP))) 
             == (DBA_DYNFLD_STP*)NULL)
        {
                MSG_RETURN(RET_MEM_ERR_ALLOC);
        }
    }

    if (((*flowTab)[flowNbr] = ALLOC_DYNST(Flow)) == NULLDYNST)
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    flowPtr = (*flowTab)[flowNbr];

    SET_ID(flowPtr,       Flow_InstrId,      GET_ID(IoR, A_IssueEvt_InstrId));
    SET_CODE(flowPtr,     Flow_EvtCd,        GET_CODE(IoR, A_IssueEvt_Cd));
    SET_INT(flowPtr,      Flow_EvtNbr,       currPeriod); /* REF8844 - LJE - 030327 */
    SET_ENUM(flowPtr,     Flow_NatEn,        FlowNat_Redm);
    SET_FLAG(flowPtr,     Flow_ConfirmedFlg, TRUE);
    SET_DATETIME(flowPtr, Flow_BegPayDate,   begDate);
    SET_DATETIME(flowPtr, Flow_EndPayDate,   endDate);
    SET_PERIOD(flowPtr,   Flow_SettlDays,    GET_TINYINT(IoR, A_IssueEvt_SettlDays));
    SET_DATETIME(flowPtr, Flow_OptimalDate,  endDate);

    /*date.date = DATE_Move(GET_DATE(flowPtr, Flow_OptimalDate), 
                  GET_PERIOD(flowPtr, Flow_SettlDays), Day);*/
    date.date = GET_DATE(flowPtr, Flow_OptimalDate); /* REF1193 - DDV - 980319 */
    date.time = 0;				/* BUG452 - 970807 - XMT */
    SET_DATETIME(flowPtr, Flow_OptimalValDate, date);

    SET_PERCENT(flowPtr,  Flow_IoRPrct, 
                  (GET_PERCENT(IoR, A_IssueEvt_ProporPrct) * 100.0 / propor));
	SET_PRICE(flowPtr,   Flow_Quote,   GET_PRICE(IoR, A_IssueEvt_Quote));

    if (GET_ENUM(IoR, A_IssueEvt_NatEn) == IssRedmNat_FinalRedm)
    {
        SET_NUMBER(flowPtr, Flow_RefQty,  1);
        *final = TRUE;
    }
    else
    {
        if (GET_ENUM(IoR, A_IssueEvt_NatEn) == IssRedmNat_Amort)
        {
        SET_NUMBER(flowPtr, Flow_RefQty, 
               CAST_NUMBER(GET_PERCENT(flowPtr, Flow_IoRPrct) / 100.0)); /* REF3288 - SSO - 990205 */ 

        if (CMP_NUMBER(propor, 100.0) >= 0)     /* REF358 - RAK - 980316 */
            *final = TRUE;
        }
        else
        SET_NUMBER(flowPtr, Flow_RefQty, 0); 
    }

    /* BUG232 */
	/* SET_PRICE(flowPtr, Flow_AmtUnit, GET_PRICE(IoR, A_IssueEvt_Price)); */
	amtUnit =  GET_PRICE(IoR, A_IssueEvt_Price);
    if (IS_NULLFLD(IoR, A_IssueEvt_FxdExchRate) == FALSE && CMP_EXCHANGE(GET_EXCHANGE(IoR, A_IssueEvt_FxdExchRate), 0.0) != 0)
    { 
        amtUnit *= GET_EXCHANGE(IoR, A_IssueEvt_FxdExchRate); 
	    amtUnit = CAST_PRICE(amtUnit); /* REF3288 - SSO - 990205 */
    }
	SET_PRICE(flowPtr, Flow_AmtUnit, amtUnit);

    SET_ID(flowPtr, Flow_AmtCurrId, GET_ID(IoR, A_IssueEvt_CurrId));

    SET_NULL_ID(flowPtr,      Flow_NewInstrId);
    SET_NULL_NUMBER(flowPtr,  Flow_QtyUnit);
    SET_NULL_ENUM(flowPtr,    Flow_OptClassEn);
    SET_NULL_ENUM(flowPtr,    Flow_OptStyleEn);
    SET_NUMBER(flowPtr,       Flow_Yield,       bestYtm);
    SET_PERCENT(flowPtr,      Flow_Proba,       100.0);
    SET_TINYINT(flowPtr,      Flow_Freq,        GET_TINYINT(IoR, A_IssueEvt_Freq));
    SET_ENUM(flowPtr,         Flow_FreqUnitEn,  GET_ENUM(IoR, A_IssueEvt_FreqUnitEn));
    SET_NULL_DATE(flowPtr,    Flow_ExDate);
    SET_EXCHANGE(flowPtr,     Flow_FxdExchRate, GET_EXCHANGE(IoR, A_IssueEvt_FxdExchRate));
    SET_NULL_NUMBER(flowPtr,  Flow_CtdConvFact);
    SET_NULL_NUMBER(flowPtr,  Flow_CtdConvRatio);
    SET_NULL_ID(flowPtr,      Flow_CtdInstrId);
    SET_FLAG(flowPtr,         Flow_PhysicalFlg, FALSE);
    SET_NULL_TINYINT(flowPtr, Flow_Priority);

    /*
    if (DATETIME_CMP(GET_DATETIME(IoR, A_IssueEvt_EffectiveDate), fromDateTime) < 0)
    {    SET_FLAG(flowPtr, Flow_EffectiveFlg, TRUE);}
    else
    {    SET_FLAG(flowPtr, Flow_EffectiveFlg, FALSE);}
    ?? */

    SET_ENUM(flowPtr, Flow_SubNatEn,
             FIN_GetIoRFlowSubNat((ISSREDMNAT_ENUM) GET_ENUM(IoR, A_IssueEvt_NatEn)));
    SET_FLAG(flowPtr, Flow_EffectiveFlg, FALSE);

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function          : FIN_StockFlows()
**
**  Description       : Retrieves all possible future flows of a stock.
**                 
**  Arguments         : fromDateTime   reference date
**                      tillDateTime  end date
**                      valDateTime  
**                      inputInstrPtr pointer on instrument struct or NULL
**                      evtDateRule   enum used in event generation for event operation date rule (set in domain)
**                      flowTab       pointer on flows array which will be 
**                                    allocated and filled up
**                                    (initialised to NULL by FIN_GenerateInstrFlows())
**                      flowNbr       pointer on flows number which will be
**                                    filled up
**                                    (initialised to 0 by FIN_GenerateInstrFlows())
**
**  Warning           : Calling function is FIN_GenerateInstrFlows()
**
**  Return            : RET_SUCCEED 
**                      RET_MEM_ERR_ALLOC
**                      RET_GEN_ERR_INVARG
**
**  Creation date     : April 95 - RAK
**  Last modification : 05.07.95 - PEC 
**  Last modification : BUG2092 - AKO - 19980721 
**  Last modification : REF4075 - CSY - 991027
*			REF3990 - SSO - 000406 : modified ERROR MANAGEMENT !!! be careful if further modification 
**
*************************************************************************/
STATIC RET_CODE FIN_StockFlows(DATETIME_T        fromDateTime,  
                               DATETIME_T        tillDateTime,
                               DATETIME_T        valDateTime,
                               DBA_DYNFLD_STP    instrPtr,
                               EVTDATERULE_ENUM  evtDateRule,    /* REF4075 - CSY - 991027 */
                               DBA_DYNFLD_STP    **flowTab,
                               int               *flowNbr,
                               DBA_HIER_HEAD_STP hierHead,
                               int               *allocSz)      /*PMSTA-32106 -NRAO 180904*/
{
	DBA_DYNFLD_STP  *incTab = (DBA_DYNFLD_STP*)NULL, repetit = NULLDYNST;
	DATETIME_T      begDate, endDate;
	DAY_T           svEndD;
	char            endMFlg;
	int             incNbr, i, currPeriod;
	double          freq;
	RET_CODE        ret;
	int		oldFlows;/* REF3990 - SSO - 000406 */

    begDate.time = 0;
    endDate.time = 0;

    /************** EXCHANGE FLOWS ************/
        /* REF2569 - AKO - 980817 */
    FIN_CreateExchangeFlows(instrPtr, fromDateTime, &tillDateTime, valDateTime, 
                            evtDateRule, allocSz, flowNbr, flowTab, hierHead); /* REF4075 - CSY - 991027 */

    oldFlows = *flowNbr;/* REF3990 - SSO - 000406 */

    /*** DIVIDEND ***/
    if ((ret = DBA_SelectIncEvt(instrPtr, fromDateTime, tillDateTime,
               valDateTime, &incTab, &incNbr)) != RET_SUCCEED)
    {
        /* return(ret);  REF2569 - AKO - 980818 <---  commented out by REF3990 - SSO - 000406*/
        RET_GENFLOWS(ret);  /* REF3990 - SSO - 000406 */ 
    }

    /* Frequency is in instrument */
    FIN_PeriodUnitNbr((FREQUNIT_ENUM)GET_ENUM(instrPtr, A_Instr_PayFreqUnitEn), /* REF7264 - CSY - 010230 */
              GET_TINYINT(instrPtr, A_Instr_PayFreq), 
              FreqUnit_Month, &freq);

	/* PMSTA - 48783 - ankita - 17052022 */
	AppEvtGenOnDivPayDate appEvtGenOnDivPayDate = AppEvtGenOnDivPayDate::addBeginDate;
	AppIncDivAccrualPos applIncludeDivAccrualPos = AppIncDivAccrualPos::includeInCashPos;
	
	GEN_GetApplInfo(AppEvtGenOnDivPayDateEnum, &appEvtGenOnDivPayDate);
	GEN_GetApplInfo(ApplIncludeDivAccrualPosEnum, &applIncludeDivAccrualPos);
	
	DBA_DYNFLD_STP domainPtr;
	DICT_FCT_ENUM funcE = NullDictFct;	

    if (hierHead != (DBA_HIER_HEAD_STP)NULL)
    {
        domainPtr = DBA_GetDomainPtr(DBA_GetConnectNoFromHier(hierHead));
        if (domainPtr != NULLDYNST)
        {
            funcE = (DICT_FCT_ENUM)GET_DICT(domainPtr, A_Domain_FctDictId);
        }
    }	

	for (i=incNbr-1; i>=0; i--)
	{
	    /* Income event must be in report period */
	    if (GET_DATE(incTab[i], A_IncEvt_LastPayDate) < fromDateTime.date)
    		continue;

		/* if the IncudeAccruedDiv flag is on, it will process all the income event else old behavior 
		(only last projectible income event) */
		if (freq != 0 && GET_FLAG(incTab[i], A_IncEvt_DivProjectionFlg) == TRUE)
		{
			if (GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_Stock && 
				(((funcE == DictFct_Return || funcE == DictFct_Valo) && 
					applIncludeDivAccrualPos == AppIncDivAccrualPos::includeInStockPos) ||
				((funcE == DictFct_Journal || funcE == DictFct_EventGeneration) && 
					appEvtGenOnDivPayDate == AppEvtGenOnDivPayDate::addFirstCouponDate)))
				repetit = incTab[i];
			else
			{
				if (repetit == NULLDYNST)
				{
					repetit = incTab[i];
				}
				else
				{
					continue;
				}
			}

			begDate.date = GET_DATE(repetit, A_IncEvt_BeginDate);

			/* PMSTA - 49728 - ankita - 07072022 */
			if (GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_Stock && appEvtGenOnDivPayDate == AppEvtGenOnDivPayDate::addFirstCouponDate
				&& (funcE == DictFct_Journal || funcE == DictFct_EventGeneration))
			{
				endDate.date = GET_DATE(repetit, A_IncEvt_FirstCoupDate);
			}
			else
			{
				endDate.date = GET_DATE(repetit, A_IncEvt_BeginDate);
			}

			/* Short month can corrupt day number */
			endMFlg = (char)DATE_IsLastInMonth(endDate.date);
			DATE_Get(endDate.date, (YEAR_T*)NULL, (MONTH_T*)NULL, &svEndD);

			if (endDate.date == BAD_DATE)
			{
				DBA_FreeDynStTab(incTab, incNbr, A_IncEvt);
				MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO,    /* REF2569 - AKO - 980818 */
					"FIN_StockFlows",
					GET_CODE(instrPtr, A_Instr_Cd), "end date");
				/* REF3990 - SSO - 000406 remove last flows */
				for (i = oldFlows; i < (*flowNbr); i++)
				{
					FREE_DYNST((*flowTab)[i], Flow);
				}
				(*flowNbr) = oldFlows;
				return(RET_SUCCEED); /* REF3990 - SSO - 000406 RET_FIN_ERR_INVDATA->minor error */
			}

			/* Advance in repetitiv event until journal begin date */
			currPeriod = 1;
			while (endDate.date < fromDateTime.date)
			{
				begDate = endDate;
				if (freq == 0.)    /* No repetitive event (one period) */
					endDate.date = GET_DATE(repetit, A_IncEvt_LastPayDate);
				else
				{
					endDate.date = DATE_Move(begDate.date, (int)freq, Month);
					/* Short month can corrupt day number */
					DATE_VerifyEndMonth(&endDate.date, svEndD, endMFlg);
				}
				++currPeriod;
			}

			/* For each period in current income event */
			/* (one in case of no repetitive event)    */
				/* REF2092 - AKO - 980817 */
			while (endDate.date <= GET_DATE(repetit, A_IncEvt_LastPayDate) &&
				endDate.date <= tillDateTime.date)
			{
				if ((ret = FIN_CreateStockFlow(allocSz, *flowNbr,
					flowTab, repetit, instrPtr,
					currPeriod, TRUE, begDate, endDate, hierHead)) != RET_SUCCEED)
				{
					DBA_FreeDynStTab(incTab, incNbr, A_IncEvt); /* REF2569 - AKO - 980818 */
					/* REF3990 - SSO - 000406 remove last flows */
					for (i = oldFlows; i < (*flowNbr); i++)
					{
						FREE_DYNST((*flowTab)[i], Flow);
					}
					(*flowNbr) = oldFlows;
					RET_GENFLOWS(ret);/* REF3990 - SSO - 000406 */
				}

				/* Go on next period */
				(*flowNbr)++;
				currPeriod++;
				begDate = endDate;

				if (freq == 0.)         /* No repetitive event, stop */
					endDate.date = DATE_Move(endDate.date, 1, Day);
				else
				{
					endDate.date = DATE_Move(begDate.date, (int)freq, Month);
					/* Short month can corrupt day number */
					DATE_VerifyEndMonth(&endDate.date, svEndD, endMFlg);
				}
			}
		}
	    else
	    {
			/* PMSTA - 49808 - ankita - 13072022 */
			if ((GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_Stock && appEvtGenOnDivPayDate == AppEvtGenOnDivPayDate::addFirstCouponDate
				&& (funcE == DictFct_Journal || funcE == DictFct_EventGeneration) &&
				GET_DATE(incTab[i], A_IncEvt_BeginDate) <= fromDateTime.date) ||
				GET_DATE(incTab[i], A_IncEvt_BeginDate) >= fromDateTime.date)
		    {
		        begDate.date = GET_DATE(incTab[i], A_IncEvt_BeginDate);

                /* PMSTA - 48783 - ankita - 17052022 */
                if (GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_Stock && appEvtGenOnDivPayDate == AppEvtGenOnDivPayDate::addFirstCouponDate
                    && (funcE == DictFct_Journal || funcE == DictFct_EventGeneration))
                {
                    endDate.date = GET_DATE(incTab[i], A_IncEvt_FirstCoupDate);
                }
                else
                {
                    endDate.date = GET_DATE(incTab[i], A_IncEvt_BeginDate);
                }

                if ((ret = FIN_CreateStockFlow(allocSz, *flowNbr, 
                           flowTab, incTab[i], instrPtr, 
                       1, FALSE, begDate, endDate, hierHead)) != RET_SUCCEED)
                {						
                    DBA_FreeDynStTab(incTab, incNbr, A_IncEvt); /* REF2569 - AKO - 980818 */
                    /* REF3990 - SSO - 000406 remove last flows */
                    for (i=oldFlows; i<(*flowNbr); i++)
                    {
                        FREE_DYNST((*flowTab)[i], Flow);
                    }
                    (*flowNbr)=oldFlows;
                    RET_GENFLOWS(ret);/* REF3990 - SSO - 000406 */	  
                }

                /* Go on next period */
                (*flowNbr)++;
            }
        }
    }

    if (GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_Stock && applIncludeDivAccrualPos == AppIncDivAccrualPos::includeInStockPos  &&
		funcE == DictFct_Valo && ret == RET_SUCCEED && *flowNbr > 1)
	{
		TLS_Sort((char *)(*flowTab), *flowNbr, sizeof(DBA_DYNFLD_STP), FIN_CmpFlowsBydate, (PTR **)NULL, SortRtnTp_None);
		DBA_DYNFLD_STP *tempTab = *flowTab;
		i = 0;
		while (i < *flowNbr -1 )
		{
			if (GET_DATE(tempTab[i], Flow_BegPayDate) == GET_DATE(tempTab[i + 1], Flow_BegPayDate) &&
				GET_DATE(tempTab[i], Flow_OptimalValDate) == GET_DATE(tempTab[i + 1], Flow_OptimalValDate))
			{
				double qty = GET_PRICE(tempTab[i], Flow_Quote) + GET_PRICE(tempTab[i + 1], Flow_Quote);
				SET_PRICE(tempTab[i], Flow_Quote, qty);
				DBA_FreeDynSt(tempTab[i+1], Flow);
				*flowNbr--;
			}
			else
			{
				i++;
			}
		}
	}
	DBA_FreeDynStTab(incTab, incNbr, A_IncEvt);

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_CreateStockFlow()
**
**  Description :   Generate a flow for stock depending on income event
**                 
**  Arguments   :   
**
**  Return      :   RET_SUCCEED or error code
**
*************************************************************************/
STATIC RET_CODE FIN_CreateStockFlow(int               *allocSz, 
                                    int               flowNbr, 
                                    DBA_DYNFLD_STP    **flowTab, 
                                    DBA_DYNFLD_STP    inc,
                                    DBA_DYNFLD_STP    instrPtr,
                                    int               currPeriod,
                                    char              projectFlg,
                                    DATETIME_T        begDate,
                                    DATETIME_T        endDate,
                                    DBA_HIER_HEAD_STP hierHead)
{
    int            reallocSz=5;
    DBA_DYNFLD_STP flowPtr;
    NUMBER_T       qty;
    DATETIME_T     date, date2;
    long           nbrDays;
        YEAR_T         couponYear,beginYear,year;
        MONTH_T        couponMonth,beginMonth,month;
    DAY_T          couponDay,beginDay,tmpDay, day;
    char           endMFlg;
    ID_T		   calendarId = 0;  	/* PMSTA-22396  - SRIDHARA ? 160430 */

    date.date = 0;				/* BUG452 - 970808 - XMT */
    date.time = 0;				/* BUG452 - 970808 - XMT */

    if ((*allocSz) == 0 || flowNbr >= (*allocSz)-1)
    {
        (*allocSz)+=reallocSz;
        if (((*flowTab) = (DBA_DYNFLD_STP *) 
             REALLOC((*flowTab), (*allocSz)*sizeof(DBA_DYNFLD_STP)))
               == (DBA_DYNFLD_STP *)NULL)
        {
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }
    }
    
    if (((*flowTab)[flowNbr] = ALLOC_DYNST(Flow)) == NULLDYNST)
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    flowPtr = (*flowTab)[flowNbr];

    SET_ID(flowPtr,        Flow_InstrId,        GET_ID(inc, A_IncEvt_InstrId));
    SET_CODE(flowPtr,      Flow_EvtCd,          GET_CODE(inc, A_IncEvt_Cd));
    SET_INT(flowPtr,       Flow_EvtNbr,         currPeriod); /* REF8844 - LJE - 030327 */
    SET_ENUM(flowPtr,      Flow_NatEn,          FlowNat_Inc);
    SET_FLAG(flowPtr,      Flow_ConfirmedFlg,   TRUE);
    SET_DATETIME(flowPtr,  Flow_BegPayDate,     begDate);
    SET_DATETIME(flowPtr,  Flow_EndPayDate,     endDate);
    SET_PERIOD(flowPtr,    Flow_SettlDays,      0);
    SET_DATETIME(flowPtr,  Flow_OptimalDate,    endDate);
    SET_ID(flowPtr, Flow_TpId, GET_ID(inc, A_IncEvt_TypeId));

    /* XDI - 971007 - REF486 - OLD Code
    date.date = DATE_Move(GET_DATE(flowPtr, Flow_OptimalDate), 
                  GET_PERIOD(flowPtr, Flow_SettlDays), Day);
    */
    date.date = GET_DATE(flowPtr, Flow_OptimalDate); /* REF1193 - DDV - 980319 */
    SET_DATETIME(flowPtr,  Flow_OptimalValDate, date); 

    /* PMSTA - 48783 - ankita - 17052022 */
    AppEvtGenOnDivPayDate appEvtGenOnDivPayDate = AppEvtGenOnDivPayDate::addBeginDate;

    GEN_GetApplInfo(AppEvtGenOnDivPayDateEnum, &appEvtGenOnDivPayDate);

    DBA_DYNFLD_STP domainPtr;
    DICT_FCT_ENUM funcE = NullDictFct;

    if (hierHead != (DBA_HIER_HEAD_STP)NULL)
    {
        domainPtr = DBA_GetDomainPtr(DBA_GetConnectNoFromHier(hierHead));
        if (domainPtr != NULLDYNST)
        {
            funcE = (DICT_FCT_ENUM) GET_DICT(domainPtr, A_Domain_FctDictId);
        }
    }


    /* PMSTA-15105  - TGU - 121122 - Applying new algorithm when coupon date is an end of the month
    **	IF [first coupon date is an end of month] THEN
    **		IF[ begindate->month == First coupon->month] THEN
    **			DATE_VerifyEndMonth; DONE
    **		IF [ coupondate->month != begindate->month] THEN
    **			Date= EndDate->month+[coupondate->month - begindate->month];
    **			DATE_VerifyEndMonth; DONE
    **	DONE
    **	IF [not end of month] THEN
    **		DATE_Move as standard case ; DONE
    **
    ************************************************/
    /* XDI - 971007 - REF486 - NEW Code */
    if (IS_NULLFLD(inc, A_IncEvt_FirstCoupDate) == TRUE)
        {SET_DATETIME(flowPtr,  Flow_OptimalValDate, endDate);}
    else if (!(GET_ENUM(instrPtr, A_Instr_NatEn) == InstrNat_Stock && appEvtGenOnDivPayDate == AppEvtGenOnDivPayDate::addFirstCouponDate
        && (funcE == DictFct_Journal || funcE == DictFct_EventGeneration)))  /* PMSTA - 49721 - ankita - 07032022 */
    {
        date.date = endDate.date;

        DATE_DaysBetween(GET_DATE(inc, A_IncEvt_BeginDate),
                     GET_DATE(inc, A_IncEvt_FirstCoupDate),
                     AccrRule_Actual_365,
                     &nbrDays, 0); /* PMSTA-22396  - SRIDHARA ? 160430 */

        if (nbrDays != 0)
        {
            /* PMSTA-15105 - TGU - 1201121 */
            endMFlg = (char) DATE_IsLastInMonth(GET_DATE(inc, A_IncEvt_FirstCoupDate));
            DATE_Get(GET_DATE(inc, A_IncEvt_BeginDate), &beginYear, &beginMonth, &beginDay);
            DATE_Get(GET_DATE(inc, A_IncEvt_FirstCoupDate), &couponYear, &couponMonth, &couponDay);	
            if( endMFlg == TRUE )
            {  
                if( beginMonth == couponMonth )
                {
                    DATE_VerifyEndMonth(&date.date, couponDay, endMFlg);
                }
                else if (couponMonth > beginMonth )
                {
                    date.date = DATE_Move(endDate.date,(couponMonth - beginMonth) , Month);
                    DATE_VerifyEndMonth(&date.date, couponDay, endMFlg);
                }
            }
            else	
            {
                date.date = DATE_Move(endDate.date, nbrDays, Day);
                DATE_Get(date.date, &year, &month, &day);
                date.date = DATE_Put(year, month, couponDay);
            }
            if (date.date == BAD_DATE)
            {
                    DATE_Get(endDate.date, &year, &month, &day);
                    date.date = DATE_Put(year, month, day);
            }
        }
        SET_DATETIME(flowPtr,  Flow_OptimalValDate, date);
    }

    SET_NULL_PERCENT(flowPtr, Flow_IoRPrct);
    SET_NUMBER(flowPtr,       Flow_RefQty,      1.0);
    SET_NULL_ID(flowPtr,      Flow_NewInstrId);
    SET_NULL_NUMBER(flowPtr,  Flow_QtyUnit);
    SET_NULL_ENUM(flowPtr,    Flow_OptClassEn);
    SET_NULL_ENUM(flowPtr,    Flow_OptStyleEn);

        /* SSO - 990208 qty = FIN_Qty(instrPtr, GET_NUMBER(inc, A_IncEvt_Dividend));  DVP264 */
	qty = GET_PRICE(inc, A_IncEvt_Dividend);
        SET_PRICE(flowPtr,    Flow_AmtUnit,        qty);
        SET_PRICE(flowPtr,    Flow_Quote,          GET_PRICE(inc, A_IncEvt_Dividend)); /*DVP264*/
    SET_ID(flowPtr,        Flow_AmtCurrId,      GET_ID(inc, A_IncEvt_CurrId));
    SET_PERCENT(flowPtr,   Flow_Proba,          100.0);
    SET_TINYINT(flowPtr,   Flow_Freq,           GET_TINYINT(inc, A_IncEvt_PayFreq));
    SET_ENUM(flowPtr,      Flow_FreqUnitEn,     GET_ENUM(inc, A_IncEvt_PayFreqUnitEn));
    SET_EXCHANGE(flowPtr,  Flow_FxdExchRate,    GET_EXCHANGE(inc, A_IncEvt_FixedExchRate));

    date = GET_DATETIME(flowPtr, Flow_EndPayDate); 
    date2.date = GET_DATE(inc, A_IncEvt_BeginDate);
    date2.time = 0;		/* Compil Baer - 23/12/1996 */
    if (IS_NULLFLD(inc, A_IncEvt_FirstExDate) == TRUE)
    {
        /* SET_NULL_DATE(flowPtr, Flow_ExDate); DLA - PMSTA05836 - 080610 */
        COPY_DYNFLD(flowPtr, Flow, Flow_ExDate, flowPtr, Flow, Flow_OptimalDate);
    }
    else if (DATETIME_CMP(date2, date) == 0)
    {
        SET_DATE(flowPtr, Flow_ExDate, date.date);
    }
    else
    {
        DBA_GetCalendarFromInstr(instrPtr, &calendarId);
        DATE_DaysBetween(GET_DATE(inc, A_IncEvt_BeginDate), 
                         GET_DATE(inc, A_IncEvt_FirstExDate),
                         (ACCRRULE_ENUM)GET_ENUM(instrPtr,A_Instr_AccrualRuleEn), 
                         &nbrDays, calendarId); /* PMSTA-22396  - SRIDHARA ? 160430 */

        /* REF486 - XDI - 971016 */
        if (nbrDays != 0)
        {
            endMFlg = (char) DATE_IsLastInMonth(GET_DATE(inc, A_IncEvt_FirstExDate));
            DATE_Get(GET_DATE(inc, A_IncEvt_FirstExDate), (YEAR_T*)NULL, (MONTH_T*)NULL, &tmpDay);
            date.date = DATE_Move(endDate.date, (-1) * nbrDays, Day);
            DATE_Get(date.date, &year, &month, &day);
            date.date = DATE_Put(year, month, tmpDay);
            if (date.date == BAD_DATE)
                date.date = DATE_Put(year, month, day);
            DATE_VerifyEndMonth(&date.date, tmpDay, endMFlg);
        }

        /*if (nbrDays > 0 )
            date.date = DATE_Move(date.date, (-1)*nbrDays, Day);*/

        SET_DATE(flowPtr, Flow_ExDate, date.date);
    }


    if (projectFlg == TRUE)
    {	SET_ENUM(flowPtr, Flow_SubNatEn, FlowSubNat_ProjectDiv); }
    else
    {	SET_ENUM(flowPtr, Flow_SubNatEn, FlowSubNat_PaidDiv); }

    SET_NULL_NUMBER(flowPtr,  Flow_CtdConvFact);
    SET_NULL_NUMBER(flowPtr,  Flow_CtdConvRatio);
    SET_NULL_ID(flowPtr,      Flow_CtdInstrId);
    SET_FLAG(flowPtr,         Flow_PhysicalFlg, FALSE);
    SET_NULL_TINYINT(flowPtr, Flow_Priority);
    SET_FLAG(flowPtr,         Flow_EffectiveFlg, FALSE);
    SET_FLAG(flowPtr,         Flow_ReplaceFlg, FALSE);

    return(RET_SUCCEED);
}


/************************************************************************
**
**  Function    :   FIN_IsBondOfSwap()
**
**  Description :   Load the parent instr structure and determien the nature
**                  supposed to be a swap and return TRUE
**
**  Arguments   :   instrPtr : current instrument
**              :   hierHead : hierarchiy pointer
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation.   :   REF5937.3503 - AKO - 010606 
**
*************************************************************************/
FLAG_T FIN_IsBondOfSwap (DBA_DYNFLD_STP      instrPtr,
                                DBA_HIER_HEAD_STP   hierHead)
{
    DBA_DYNFLD_STP  parInstr=NULLDYNST;
    FLAG_T          allocOk=FALSE;

    if (GET_ID(instrPtr, /*A_Instr_ParentInstrId*/ A_Instr_RefInstrId) != (ID_T)0 )
    {
        if ((DBA_GetInstrById(GET_ID(instrPtr, /*A_Instr_ParentInstrId*/  A_Instr_RefInstrId), FALSE, &allocOk, 
                                    &parInstr, hierHead, UNUSED, UNUSED)) != RET_SUCCEED)
        {
            if (allocOk == TRUE) {FREE_DYNST(parInstr, A_Instr);}
            return(FALSE); 
        }

        if ( (GET_ENUM(parInstr, A_Instr_NatEn) == InstrNat_Swap)  && 
             (GET_ENUM(parInstr, A_Instr_SubNatEn) == SubNat_None))
        {
            if (allocOk == TRUE) {FREE_DYNST(parInstr, A_Instr);}
            return(TRUE);
        }
        else
        {
            if (allocOk == TRUE) {FREE_DYNST(parInstr, A_Instr);}
            return(FALSE);
        }
    }
    return (FALSE);
}

/************************************************************************
**
**  Function    :   FIN_GenerateIncomeFlows()
**
**  Description :   Generate all income Flows
**                 
**  Arguments   :   domainPtr	  domain pointer
**                  argHierHead   hierarchy pointer
**
**  Return      :   RET_SUCCEED 	or error code
**
**  Creation    :   PMSTA00485 - DDV - 061017
**
*************************************************************************/
RET_CODE FIN_GenerateIncomeFlows(DBA_DYNFLD_STP	domainPtr,
                                 DBA_HIER_HEAD_STP	hierHead)
{
    ENUMMASK_T            mask=0;
    int               i, j, instrNbr, flowNbr=0, incomeFlowsCheckDays=0,
                      applIncomePaymentRange = 0;
    DBA_DYNFLD_STP    *instrTab=NULL, *flowTab=NULL, instrPtr=NULL;
    DATETIME_T        fromDate, minPaymentDate, tillDate;
    RET_CODE          ret = RET_SUCCEED;
    FLAG_T			  returnProcessFlg;

    /* Retrieve system parameter for payment date setting and income flow period */
    GEN_GetApplInfo(ApplIncomePaymentRange, &applIncomePaymentRange);
    GEN_GetApplInfo(ApplIncomeFlowCheckDays, &incomeFlowsCheckDays);

    /* Check if special treatment must be done for return related functions */
    returnProcessFlg = (GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_Return     ||
                        GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_SynthAdmin ||
                        GET_ID(domainPtr, A_Domain_FctDictId) == DictFct_PtfStorage);

    SET_BIT64(mask, FlowSubNat_Any, FALSE);

    SET_BIT64(mask, FlowSubNat_PaidDiv, TRUE);
    SET_BIT64(mask, FlowSubNat_ProjectDiv, TRUE);

    fromDate.time = (TIME_T) 0;
    fromDate.date = DATE_Move(GET_DATETIME(domainPtr, A_Domain_InterpFromDate).date, -1*incomeFlowsCheckDays, Day);

    tillDate.time = (TIME_T) 0;
    if (returnProcessFlg == TRUE)
        tillDate.date = GET_DATETIME(domainPtr, A_Domain_InterpTillDate).date;
    else
        tillDate.date = GET_DATETIME(domainPtr, A_Domain_InterpFromDate).date;

    minPaymentDate.time = (TIME_T) 0;
    minPaymentDate.date = DATE_Move(GET_DATETIME(domainPtr, A_Domain_InterpFromDate).date, -1*applIncomePaymentRange, Day);

    if ((ret = DBA_ExtractHierEltRecWithFilterSt(hierHead,                      /* DLA - REF04851 - 080313 */
                                                 A_Instr,
                                                 FALSE,
                                                 FIN_FilterInstrForIncomeFlows,
                                                 domainPtr,                     /* DLA - REF04851 - 080313 */
                                                 NULL,
                                                 &instrNbr,
                                                 &instrTab)) != RET_SUCCEED)
    {
        return(ret);
    }

    for (i=0; i<instrNbr; i++)
    {

        instrPtr = instrTab[i];
        /* Compute instrument flows */
        ret = FIN_GenerateInstrFlows(fromDate, tillDate,
                                     tillDate,            /* PMSTA14083 - DDV - 120423 - All events must be valid at till_d (for valo, till_d is the valo's from_d) */ 
                                     FALSE,	/* PMSTA-9032 - RAK - 091216 */
                                     GET_ID(instrPtr, A_Instr_Id), 
                                     instrPtr, mask, 
                                     EvtGen_FlowInstr, EvtDateRule_Term,
                                     FALSE,GenInstrFlow_Journal,
                                     AccrRule_None,
                                     &flowTab, &flowNbr, hierHead);

        if (flowNbr > 0)
        {
            /* delete all flows out of the scope (Optimal date smallest than valoDate - IncomeRange) */
            for (j=0; j<flowNbr; j++)
            {
                if (IS_NULLFLD(flowTab[j], Flow_OptimalValDate) == FALSE)
                {
                    if (DATE_Cmp(GET_DATETIME(flowTab[j], Flow_OptimalValDate).date, 
                                 minPaymentDate.date) < 0)
                    {
                        FREE_DYNST(flowTab[j], Flow);
                    }
                }
                else
                if (IS_NULLFLD(flowTab[j], Flow_OptimalDate) == FALSE)
                {
                    if (DATE_Cmp(GET_DATETIME(flowTab[j], Flow_OptimalDate).date,
                                 minPaymentDate.date) < 0)
                    {
                        FREE_DYNST(flowTab[j], Flow);
                    }
                }
            }

            /* insert remaining Flows into hierarchy */
            if (ret == RET_SUCCEED)
            {
                if (DBA_AddHierRecordList(hierHead, flowTab, flowNbr, Flow, FALSE) != RET_SUCCEED)
                {
                    FREE(instrTab);
                    DBA_FreeDynStTab(flowTab, flowNbr, Flow);
                    return(RET_DBA_ERR_HIER);
                }
                FREE(flowTab);
            }
            else
            {
                DBA_FreeDynStTab(flowTab, flowNbr, Flow);
            }
        }
    }

    FREE(instrTab);

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_GenerateVoluntaryCAFlows()
**
**  Description :   Generate flows for voluntary CA
**
**  Arguments   :   domainPtr	  domain pointer
**                  argHierHead   hierarchy pointer
**
**  Return      :   RET_SUCCEED 	or error code
**
**  Creation    :   PMSTA-36248 - SGO - 29082019 - Maintain Portfolio Value
**
*************************************************************************/
RET_CODE FIN_GenerateVoluntaryCAFlows(DBA_DYNFLD_STP domainPtr,
                                       DBA_HIER_HEAD_STP hierHead)
{

    RET_CODE       ret = RET_SUCCEED;
    int            ptfTabNbr = 0, instrTabNbr = 0;
    DBA_DYNFLD_STP	*ptfTab = NULLDYNSTPTR, *ptfIdListTab = NULLDYNSTPTR,
        *instrListTab = NULLDYNSTPTR, *instrIdListTab = NULLDYNSTPTR;
    DATETIME_T     fromDate, tillDate;

    fromDate.time = (TIME_T)0;
    fromDate.date = GET_DATETIME(domainPtr, A_Domain_InterpFromDate).date;

    tillDate.date = GET_DATETIME(domainPtr, A_Domain_InterpTillDate).date;
    MemoryPool mp;
    ret = DBA_ExtractHierEltRec(hierHead,
                                A_Ptf,
                                FALSE,
                                NULLFCT,
                                NULLFCT,
                                &ptfTabNbr,
                                &ptfTab);

    mp.owner(static_cast<void *>(ptfTab));

    if (ret == RET_SUCCEED && ptfTabNbr > 0)
    {
        ptfIdListTab = static_cast<DBA_DYNFLD_STP *>(mp.calloc(FILEINFO, ptfTabNbr, sizeof(DBA_DYNFLD_STP)));
        for (int ptfIndex = 0; ptfIndex < ptfTabNbr; ++ptfIndex)
        {
            ptfIdListTab[ptfIndex] = mp.allocDynst(FILEINFO, Io_Id);
            SET_ID(ptfIdListTab[ptfIndex], Io_Id_Id, GET_ID(ptfTab[ptfIndex], A_Ptf_Id));
        }
    }

    ret = DBA_ExtractHierEltRec(hierHead,
                                A_Instr,
                                FALSE,
                                NULLFCT,
                                NULLFCT,
                                &instrTabNbr,
                                &instrListTab);

    mp.owner(static_cast<void *>(instrListTab));

    if (ret == RET_SUCCEED && instrTabNbr > 0)
    {
        instrIdListTab = static_cast<DBA_DYNFLD_STP *>(mp.calloc(FILEINFO, instrTabNbr, sizeof(DBA_DYNFLD_STP)));
        for (int instrIdx = 0; instrIdx < instrTabNbr; ++instrIdx)
        {
            instrIdListTab[instrIdx] = mp.allocDynst(FILEINFO, Io_Id);
            SET_ID(instrIdListTab[instrIdx], Io_Id_Id, GET_ID(instrListTab[instrIdx], A_Instr_Id));
        }
    }

    /* Get a free connection in the connection list */
    DbiConnection*      dbiConn = nullptr;
    if ((dbiConn = DBA_GetDbiConnection(SqlServer)) == nullptr)
    {
        MSG_SendMesg(RET_DBA_ERR_CONNOTFOUND, 0, FILEINFO);
        return(DBA_CONN_NOT_FOUND);
    }

    ret = DBA_CreateTempTables(*dbiConn, DOM_POSITION_INSTR_PORT); /* PMSTA - 42330 - CHANDRU - 27102020*/

    DbiSqlExecByBlock   sqlExec;
    std::string         executedSql;
    if (ptfIdListTab != NULLDYNSTPTR && ptfTabNbr != 0)
    {
        for (int ptfIndex = 0; ptfIndex < ptfTabNbr; ++ptfIndex)
        {
            std::string sqlCmd = "insert into #dom_port (id, port_pos_set_id, hier_port_id, fusion_date_rule_e, parent_port_id, level_n, nature_e) values(";
            sqlCmd += to_stringSql(GET_ID(ptfIdListTab[ptfIndex], Io_Id_Id));
            sqlCmd += ",NULL, NULL, NULL, NULL, 0, NULL)";
            sqlExec.addSql(sqlCmd);
        }
    }

    if (instrIdListTab != NULLDYNSTPTR && instrTabNbr != 0)
    {
        for (int instrIdx = 0; instrIdx < instrTabNbr; ++instrIdx)
        {
            std::string sqlCmd = "insert into #dom_instr (id) values(";
            sqlCmd += to_stringSql(GET_ID(instrIdListTab[instrIdx], Io_Id_Id));
            sqlCmd += ")";
            sqlExec.addSql(sqlCmd);
        }
    }

    ret = sqlExec.execSqlExecByBloc(dbiConn, &executedSql);

    DBA_DYNFLD_STP  arg = NULLDYNST;

    if ((arg = ALLOC_DYNST(A_PortfolioEvent)) == NULLDYNST)
        MSG_RETURN(RET_MEM_ERR_ALLOC);

    SET_DATE(arg, A_PortfolioEvent_BeginDate, fromDate.date);
    SET_DATE(arg, A_PortfolioEvent_EndDate, tillDate.date);

    DBA_DYNFLD_STP *portEvtTab = NULLDYNSTPTR;
    int portEvtNbr = 0;
    ret = DBA_Select2(PortfolioEvent, UNUSED, A_PortfolioEvent, arg, A_PortfolioEvent, &portEvtTab,
                      DBA_SET_CONN | DBA_NO_CLOSE, UNUSED, &portEvtNbr, *dbiConn, UNUSED);
    if (ret != RET_SUCCEED)
    {
        MSG_LogSrvMesg(UNUSED, UNUSED, "FIN_GenerateVoluntaryCAFlows() : Portfolio Event fetch failed");
        FREE_DYNST(arg, A_PortfolioEvent);
        DBA_EndConnection(&dbiConn);
        return RET_DBA_ERR_NODATA;

    }
    FREE_DYNST(arg, A_PortfolioEvent);

    DBA_EndConnection(&dbiConn);

    /* if there are no evets, don't create flows */
    if (portEvtNbr != 0)
    {
        DBA_DYNFLD_STP   *flowTab = NULLDYNST;
        int numberOfFlows = 0;
        flowTab = static_cast<DBA_DYNFLD_STP *>(mp.calloc(FILEINFO, portEvtNbr, sizeof(DBA_DYNFLD_STP)));
        mp.remove(flowTab);
        DBA_DYNFLD_STP flow = NULLDYNSTPTR;
        for (int eventIdx = 0; eventIdx < portEvtNbr; ++eventIdx)
        {
            flow = mp.allocDynst(FILEINFO, Flow);
            mp.remove(flow);
            flowTab[numberOfFlows] = flow;

            SET_NULL_ID(flow, Flow_Id);
            COPY_DYNFLD(flow, Flow, Flow_InstrId, portEvtTab[eventIdx],
                A_PortfolioEvent, A_PortfolioEvent_InstrId);
            COPY_DYNFLD(flow, Flow, Flow_EvtCd, portEvtTab[eventIdx],
                A_PortfolioEvent, A_PortfolioEvent_Cd);
            COPY_DYNFLD(flow, Flow, Flow_SubNatEn, portEvtTab[eventIdx],
                A_PortfolioEvent, A_PortfolioEvent_NatEn);
            switch (static_cast<PORT_EVENT_NATURE>(GET_ENUM(portEvtTab[eventIdx], A_PortfolioEvent_NatEn)))
            {
            case PORT_EVENT_NATURE::Upfront_Payment:
                SET_ENUM(flow, Flow_SubNatEn, FlowSubNat_UpfrontPayment);
                break;
            case PORT_EVENT_NATURE::Deferred_Security_Credit:
                SET_ENUM(flow, Flow_SubNatEn, FlowSubNat_DeferredSecurityCredit);
                break;
            case PORT_EVENT_NATURE::Deferred_Security_Debit:
                SET_ENUM(flow, Flow_SubNatEn, FlowSubNat_DeferredSecurityDebit);
                break;
            case PORT_EVENT_NATURE::Deferred_Cash_Credit:
                SET_ENUM(flow, Flow_SubNatEn, FlowSubNat_DeferredCashCredit);
                break;
            case PORT_EVENT_NATURE::Deferred_Cash_Debit:
                SET_ENUM(flow, Flow_SubNatEn, FlowSubNat_DeferredCashDebit);
                break;
            }

            COPY_DYNFLD(flow, Flow, Flow_RefQty, portEvtTab[eventIdx],
                A_PortfolioEvent, A_PortfolioEvent_Quantity);

            COPY_DYNFLD(flow, Flow, Flow_BegPayDate, portEvtTab[eventIdx],
                A_PortfolioEvent, A_PortfolioEvent_BeginDate);

            COPY_DYNFLD(flow, Flow, Flow_EndPayDate, portEvtTab[eventIdx],
                A_PortfolioEvent, A_PortfolioEvent_EndDate);

            COPY_DYNFLD(flow, Flow, Flow_LinkedInstrId, portEvtTab[eventIdx],
                A_PortfolioEvent, A_PortfolioEvent_LinkedInstrId);                   /* PMSTA - 42330 - CHANDRU - 23102020*/

            if (IS_NULLFLD(portEvtTab[eventIdx], A_PortfolioEvent_EndDate) == TRUE ||
                GET_DATE(portEvtTab[eventIdx], A_PortfolioEvent_EndDate) == MAGIC_END_DATE)
            {
                COPY_DYNFLD(flow, Flow, Flow_OptimalDate,
                    portEvtTab[eventIdx], A_PortfolioEvent, A_PortfolioEvent_BeginDate);
            }
            else
            {
                COPY_DYNFLD(flow, Flow, Flow_OptimalDate,
                    portEvtTab[eventIdx], A_PortfolioEvent, A_PortfolioEvent_EndDate);
            }
            ++numberOfFlows;
        }

        if (DBA_AddHierRecordList(hierHead, flowTab, numberOfFlows, Flow, FALSE) != RET_SUCCEED)
        {
            ret = RET_DBA_ERR_HIER;
        }

    }

    DBA_FreeDynStTab(portEvtTab, portEvtNbr, A_PortfolioEvent);
    return ret;
}

/************************************************************************
*
*  Function    : FIN_FilterInstrForIncomeFlows()
*
*  Description : return only instrtment with nature = Stock
*
*  Arguments   : dynSt     : pointer on a dynamic structure
*                dynStTp   : dynamic structure type
*
*  Return      : TRUE or FALSE
*
*  Creation    : PMSTA00485 - DDV - 061103
*
*  Last modif. : PMSTA04851 - DLA - 080311
*
*************************************************************************/
STATIC int FIN_FilterInstrForIncomeFlows(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM, DBA_DYNFLD_STP domainPtr)
{
    CASHFLOWMGT_ENUM cashFlowMgtEnum = (CASHFLOWMGT_ENUM)GET_ENUM(domainPtr, A_Domain_CashFlowMgtEn);

    switch (cashFlowMgtEnum)
    {
    case CashFlowMgt_None:
        break;

    case CashFlowMgt_All:
    case CashFlowMgt_Default:
        if (GET_ENUM(dynSt, A_Instr_NatEn) == InstrNat_Stock ||
            GET_ENUM(dynSt, A_Instr_NatEn) == InstrNat_FundShare)
            return(TRUE);
        break;

        break;

    case CashFlowMgt_Stocks:
        if (GET_ENUM(dynSt, A_Instr_NatEn) == InstrNat_Stock)
            return(TRUE);
        break;

    case CashFlowMgt_FundShares:
        if (GET_ENUM(dynSt, A_Instr_NatEn) == InstrNat_FundShare)
            return(TRUE);
        break;

    default:
        break;
    }
    return (FALSE);
}

/************************************************************************
*  Function         : getWeekdayEnumForExecUnit()
*  Description     : execution unit to weekday enum (char)
*  Arguments      : 
*  Creation         : PMSTA-40209 - Lik
*************************************************************************/
STATIC char getWeekdayEnumForExecUnit(StandInstructExecutionUnitEn execUnit)
{

    switch (execUnit) {
    case StandInstructExecutionUnitEn::Sunday:
        return DATE_WEEKDAY_ENUM::Sunday - 1;
    case StandInstructExecutionUnitEn::Monday:
        return DATE_WEEKDAY_ENUM::Monday - 1;
    case StandInstructExecutionUnitEn::Tuesday:
        return DATE_WEEKDAY_ENUM::Tuesday - 1;
    case StandInstructExecutionUnitEn::Wednesday:
        return DATE_WEEKDAY_ENUM::Wednesday - 1;
    case StandInstructExecutionUnitEn::Thursday:
        return DATE_WEEKDAY_ENUM::Thursday - 1;
    case StandInstructExecutionUnitEn::Friday:
        return DATE_WEEKDAY_ENUM::Friday - 1;
    case StandInstructExecutionUnitEn::Saturday:
        return DATE_WEEKDAY_ENUM::Saturday - 1;
    }
    return (DATE_WEEKDAY_ENUM)NULL;
}

/************************************************************************
*  Function         : getNthWeekDayInMonth()
*  Description     : calculate nth weekday of a month. n = execRank
*  Arguments      :
*  Creation         : PMSTA-40209 - Lik
*************************************************************************/
STATIC DATE_T getNthWeekDayInMonth(YEAR_T y, MONTH_T m, StandInstructExecutionUnitRankEn execRank)
{
    DATE_T tempBegDate = NULL;
    if (StandInstructExecutionUnitRankEn::SI_Rank_Last != execRank)
    {
        tempBegDate = DATE_Put(y, m, (DAY_T)1); /*first day of the month */
        char dayIndex = DATE_WhichWeekDay(tempBegDate);
       
        if (dayIndex == 0)  /* if day is sunday, move to nth day*/
        {
            tempBegDate = DATE_Move(tempBegDate, execRank, Day);
        }
        else
        {
            /* all other days 
                Max execRank is 4 (5th will be in else condition)
                if first day in the month m is Wed/Thu/Fri/Sat/Sun, then adding execRank may end up in 
                resulting day as Sat or sunday. in this case, move to weekday by adding 2.
                eg : 1-Oct-2020, execRank = 4, fouth week day.
                1st day = Thu -> 4 (dayIndex)
                4 + 4 - 1 = 7 > 5
                    begDate = 1-Oct-2020 + (4 + 1) Days
                                    06-Oct-2020 => Tue, i.e. fourth week day of Oct,2020

                eg : 1-Oct-2020, execRank = 2, second week day.
                1st day = Thu -> 4 (dayIndex)
                4 + 2 - 1 = 5 > 5 ->false
                    begDate = 1-OCt-2020 + (2-1) Days
                                    2-Oct-2020 => Friday, i.e. second Weekd day of oct 2020
            */

            if (dayIndex + (execRank - 1)  > 5) 
            {
                tempBegDate = DATE_Move(tempBegDate, execRank +1 , Day);    
            }
            else
            {
                tempBegDate = DATE_Move(tempBegDate, execRank - 1, Day);
            }
        }
    }
    else
    {
        DAY_T maxDaysInBegMonth = DATE_DaysInMonth(m, y);
        DATE_T monthEndDate = DATE_Put(y, m, maxDaysInBegMonth);
        /* last week day of the month 
            If last day is sunday, move 2 days back to reach weekday.
            if last day is saturday, move 1 day back to rach weekday.
        */
        switch (DATE_WhichWeekDay(monthEndDate))
        {
        case 0:
            tempBegDate = DATE_Move(monthEndDate, -2, Day);
            break;
        case 6:
            tempBegDate = DATE_Move(monthEndDate, -1, Day);
            break;
        default:
            tempBegDate = monthEndDate;
        }
    }
        
    return tempBegDate;
}

/************************************************************************
*  Function         : getNthWeekEndDayInMonth()
*  Description     : calculate nth weekend of a month. n = execRank, if currDate is Saturday,
*                          this will add 1 to find next day (sunday). if this new date is in same month,
*                          will return the new date, else, find the nth weekend in next month (begDate)      
*  Arguments      :
*  Creation         : PMSTA-40209 - Lik
*************************************************************************/
STATIC DATE_T getNthWeekEndDayInMonth(DATE_T currDate, DATE_T begDate, StandInstructExecutionUnitRankEn execRank)
{
    DATE_T tempBegDate = currDate;
    YEAR_T  y;
    MONTH_T m, nextMonth;
    DAY_T   d;

    DATE_Get(tempBegDate, &y, &m, &d);
    /* if saturday, move to sunday and check if in same month */
    if (DATE_WhichWeekDay(tempBegDate) == 6)
    {
        tempBegDate = DATE_Move(tempBegDate, 1, Day);
        DATE_Get(tempBegDate, NULL, &nextMonth, NULL);
        if (m == nextMonth)
            return tempBegDate;
    }

    DATE_Get(begDate, &y, &m, &d);
    tempBegDate = begDate;

    if (StandInstructExecutionUnitRankEn::SI_Rank_Last != execRank)
    {
        char dayIndex = DATE_WhichWeekDay(tempBegDate);
        /* find first sat/sun of this month */
        if (dayIndex != 0 && dayIndex != 6)
        {
            /* move to saturday */
            tempBegDate = DATE_Move(tempBegDate, (6 - dayIndex), Day);
        }
        /* add freq to the first sat/sun */
        tempBegDate = DATE_Move(tempBegDate, ((int)execRank - 1) * 7, Day);

        /* if sunday and freq >1, move back to reach saturday*/
        if (dayIndex == 0 && ((int)execRank) >1 )
        {
            tempBegDate = DATE_Move(tempBegDate, -1, Day);
        }
    }
    else
    {
        DAY_T maxDaysInBegMonth = DATE_DaysInMonth(m, y);
        tempBegDate = DATE_Put(y, m, maxDaysInBegMonth); /* last day of the month */
        char dayIndex = DATE_WhichWeekDay(tempBegDate);
        /* if last day is not saturday, move back till we reach saturday */
        if (dayIndex != 6)
        {
            /* move to saturday */
            tempBegDate = DATE_Move(tempBegDate, -(dayIndex + 1), Day);
        }
    }
    return tempBegDate;

}

/************************************************************************
*  Function         : moveBackToDate()
*  Description     : calculate last execution day of month
*  Arguments      :
*  Creation         : PMSTA-40209 - Lik
*************************************************************************/
STATIC DATE_T moveBackToDate(StandInstructExecutionUnitEn execUnit, DATE_T refDate)
{
    int NUM_DAYS = 7;
    int diff = getWeekdayEnumForExecUnit(execUnit) - DATE_WhichWeekDay(refDate);
    if (diff > 0)
    {
        return (DATE_Move(refDate, (diff - NUM_DAYS), Day));
    }   
     return (DATE_Move(refDate, diff, Day));  
}

/************************************************************************
*  Function         : moveForwardToDate()
*  Description     : calculate nth but not last execution day of month
*  Arguments      :
*  Creation         : PMSTA-40209 - Lik
*************************************************************************/
STATIC DATE_T moveForwardToDate(StandInstructExecutionUnitEn execUnit, StandInstructExecutionUnitRankEn execRank, DATE_T refDate)
{
    int NUM_DAYS = 7;
    int diff = getWeekdayEnumForExecUnit(execUnit) - DATE_WhichWeekDay(refDate);
    if (diff >= 0)
    {
        refDate = DATE_Move(refDate, diff, Day);
    }
    else
    {
        refDate = DATE_Move(refDate, diff + NUM_DAYS, Day);
    }
    return (DATE_Move(refDate, (execRank - 1) * NUM_DAYS, Day));
}

/************************************************************************
*  Function         : getNextExecDay()
*  Description     : find next execution day based on freq and begDate.
*  Arguments      :
*  Creation         : PMSTA-40209 - Lik
*************************************************************************/
RET_CODE getNextExecDay(
                    DATETIME_T &begDate, DATETIME_T &endDate,
                    FREQUNIT_ENUM freqUnitEn,
                    StandInstructFrequencyChoiceEn choice,
                    bool oldMethod,
                    FLAG_T weekDays[],
                    int &begDay,
                    int &currDay,
                    bool isLastDayOfMonth,
                    TINYINT_T execDay,
                    TINYINT_T execMonth,
                    StandInstructExecutionUnitEn execUnit,
                    StandInstructExecutionUnitRankEn execRank,
                    FLAG_T endMFlg,
                    DAY_T svEndD,
                    DATETIME_T fromDate,
                    int freq
    )
{
    int NUM_DAYS = 7;
    switch (freqUnitEn)
    {
    case FreqUnit_Day:
        

        if (!oldMethod)
        {
            if (StandInstructFrequencyChoiceEn::EveryWeekdayOrCalcDay == choice)
            {
                endDate.date = DATE_Move(begDate.date, 1, Day);
                switch (DATE_WhichWeekDay(endDate.date))
                {
                case 0:
                    endDate.date = DATE_Move(endDate.date, 1, Day);
                    break;
                case 6:
                    endDate.date = DATE_Move(endDate.date, 2, Day);
                    break;
                }
            }
            else
            {
                endDate.date = DATE_Move(begDate.date, freq, Day);
            }
        }
        else
        {
            endDate.date = DATE_Move(begDate.date, freq, Day);
        }
        break;
    case FreqUnit_Week:
    {
        int locDays = 0;
        do
        {
            locDays++;
            currDay = (currDay + 1) % NUM_DAYS;
        } while (weekDays[currDay] != TRUE);

        /* check if we reached beg date */
        if (currDay < begDay)
        {
            endDate.date = DATE_Move(begDate.date, locDays, Day);
            endDate.date = DATE_Move(endDate.date, freq - 1, Week);
            begDay = currDay;
        }
        else if (currDay == begDay)
        {
            endDate.date = DATE_Move(begDate.date, locDays, Day);
            endDate.date = DATE_Move(endDate.date, freq - 1, Week);
        }
        else /* increment n days. means multiple days selected in weekly mode */
        {
            endDate.date = DATE_Move(begDate.date, locDays, Day);
        }
    }
    break;
    case FreqUnit_Month:
        if (oldMethod)
        {
            endDate.date = DATE_Move(begDate.date, freq, Month);
            DATE_VerifyEndMonth(&endDate.date, svEndD, endMFlg);
        }
        else
        {
            YEAR_T  y;
            MONTH_T m;
            DAY_T   d;
            DATE_Get(begDate.date, &y, &m, &d);
            /* Move to next Month */
            int yearsToAdd = (freq - (freq % 12)) / 12; /* if frq is more than 12 months*/
            int sum = m + (MONTH_T)(freq % 12); /* Max sum is 12 + 11*/
            y = (YEAR_T)((sum <= 12 ? y : y + 1) + yearsToAdd);
            m = (MONTH_T)(sum > 12 ? sum - 12 : sum);

            if (StandInstructExecutionUnitEn::None != execUnit
                && StandInstructExecutionUnitRankEn::SI_Rank_None != execRank
                && StandInstructFrequencyChoiceEn::EveryWeekdayOrCalcDay == choice)
            {

                if (StandInstructExecutionUnitEn::Day == execUnit)
                {
                    if (StandInstructExecutionUnitRankEn::SI_Rank_Last != execRank)
                    {
                        endDate.date = DATE_Put(y, m, (DAY_T)execRank);
                    }
                    else
                    {
                        DAY_T locMaxDNextMonth = DATE_DaysInMonth(m, y);
                        endDate.date = DATE_Put(y, m, locMaxDNextMonth);
                    }
                }
                else if (StandInstructExecutionUnitEn::Weekday == execUnit)
                {
                    /* not implemented*/
                    endDate.date = getNthWeekDayInMonth(y,m, execRank);
                }
                else if (StandInstructExecutionUnitEn::WeekendDay == execUnit)
                {
                    /*not implemented */
                    endDate.date = getNthWeekEndDayInMonth(begDate.date, DATE_Put(y,m,1), execRank);
                }
                else
                {
                    DATE_T tempNextMonthBeginDate = DATE_Put(y, m, 1);
                    /* Sunday to Saturday enums. */
                    if (StandInstructExecutionUnitRankEn::SI_Rank_Last != execRank)
                    {
                        endDate.date = moveForwardToDate(execUnit, execRank, tempNextMonthBeginDate);
                    }
                    else
                    {
                        DAY_T tempMaxDaysInNextMonth = DATE_DaysInMonth(m, y);
                        DATE_T tempNextMonthLastDate = DATE_Put(y, m, tempMaxDaysInNextMonth);
                        endDate.date = moveBackToDate(execUnit, tempNextMonthLastDate);
                    }
                }
            }
            else if (execDay > 0
                && StandInstructFrequencyChoiceEn::EveryDayOrSpecificDay == choice)
            {
                /* specific day method */
                DAY_T tempMaxDaysInNextMonth = DATE_DaysInMonth(m, y);
                if (isLastDayOfMonth || execDay > tempMaxDaysInNextMonth)
                {
                    endDate.date = DATE_Put(y, m, tempMaxDaysInNextMonth);
                }
                else
                {
                    endDate.date = DATE_Put(y, m, execDay);
                }
            }
        }
        break;
    case FreqUnit_Year:
        if (oldMethod)
        {
            endDate.date = DATE_Move(begDate.date, freq, Year);
            DATE_VerifyEndMonth(&endDate.date, svEndD, endMFlg);
        }
        else
        {
            YEAR_T  y;
            MONTH_T m;
            DAY_T   d;

            DATE_Get(begDate.date, &y, &m, &d);
            /* add freq to year  */
            y = (YEAR_T)(y + freq);

            DAY_T maxDaysInBegMonth, maxDayInNextMonthNextyear;

            maxDaysInBegMonth = DATE_DaysInMonth((MONTH_T)execMonth, y);
            maxDayInNextMonthNextyear = DATE_DaysInMonth((MONTH_T)execMonth, y);

            if (StandInstructFrequencyChoiceEn::EveryWeekdayOrCalcDay == choice
                && StandInstructExecutionUnitEn::None != execUnit
                && StandInstructExecutionUnitRankEn::SI_Rank_None != execRank)
            {

                if (StandInstructExecutionUnitEn::Day == execUnit)
                {
                    if (StandInstructExecutionUnitRankEn::SI_Rank_Last != execRank)
                    {
                        endDate.date = DATE_Put(y, (MONTH_T)execMonth, (DAY_T)execRank);
                    }
                    else
                    {
                        maxDaysInBegMonth = DATE_DaysInMonth((MONTH_T)execMonth, y);
                        endDate.date = DATE_Put(y, (MONTH_T)execMonth, maxDaysInBegMonth);
                    }
                }
                else if (StandInstructExecutionUnitEn::Weekday == execUnit)
                {
                    endDate.date = getNthWeekDayInMonth(y,m, execRank);
                }
                else if (StandInstructExecutionUnitEn::WeekendDay == execUnit)
                {
                    endDate.date = getNthWeekEndDayInMonth(begDate.date, DATE_Put(y, m, 1), execRank);
                }
                else
                {
                    /* Sunday to Saturday enums. */
                    if (StandInstructExecutionUnitRankEn::SI_Rank_Last != execRank)
                    {
                        endDate.date = moveForwardToDate(execUnit, execRank, (DATE_Put(y, (MONTH_T)execMonth, 1)));
                    }
                    else
                    {
                        endDate.date = moveBackToDate(execUnit, (DATE_Put(y, (MONTH_T)execMonth, maxDaysInBegMonth)));
                    }
                }
            }
            else if (StandInstructFrequencyChoiceEn::EveryDayOrSpecificDay == choice)
            {
                maxDaysInBegMonth = DATE_DaysInMonth((MONTH_T)execMonth, y);
                if (isLastDayOfMonth || execDay > maxDaysInBegMonth)
                {
                    endDate.date = DATE_Put(y, (MONTH_T)execMonth, maxDaysInBegMonth);
                }
                else
                {
                    endDate.date = DATE_Put(y, (MONTH_T)execMonth, (DAY_T)execDay);
                }
            }
        }
        break;
    }
    return RET_SUCCEED;
}

/************************************************************************
*  Function         : getRealSIBegDate()
*  Description     : find the actual begin date of SI after SI creation date.
*  Arguments      :
*  Creation         : PMSTA-40209 - Lik
*************************************************************************/
RET_CODE getRealSIBegDate(
    DATETIME_T &begDate, DATETIME_T &endDate, 
    FREQUNIT_ENUM freqUnitEn,
    StandInstructFrequencyChoiceEn choice, 
    bool oldMethod ,                                               
    FLAG_T weekDays[], 
    int begDay, 
    int &currDay, 
    bool isLastDayOfMonth, 
    TINYINT_T execDay, 
    TINYINT_T execMonth,                                                
    StandInstructExecutionUnitEn execUnit, 
    StandInstructExecutionUnitRankEn execRank, 
    FLAG_T endMFlg, 
    DAY_T svEndD)
{
    int NUM_DAYS = 7;

    /* calculate real begin date */
    if (FreqUnit_Day == freqUnitEn)
    {
        if (StandInstructFrequencyChoiceEn::EveryWeekdayOrCalcDay == choice) 
        {
            switch (DATE_WhichWeekDay(begDate.date))
            {
            case 0: /* Sunday */
                begDate.date = DATE_Move(begDate.date, 1, Day);
                break;
            case 6: /* Saturday */
                begDate.date = DATE_Move(begDate.date, 2, Day);
                break;
            }
        }
        endDate.date = begDate.date;
    }
    else if (FreqUnit_Week == freqUnitEn )
    {
        bool valid = false;
        for (int j = 0; j < NUM_DAYS; ++j)
        {
            if (TRUE == weekDays[begDay])
            {
                valid = true;
                begDate.date = DATE_Move(begDate.date, j, Day);
                break;
            }
            begDay = (begDay + 1) % NUM_DAYS;
        }
        if (!valid)
        {
            /*Invalid configuration.*/
            MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
                "FIN_GenerateStandInstructFlows", "Freq unit and method");
            return(RET_GEN_ERR_INVARG);
        }
        endDate.date = begDate.date;
        currDay = begDay;
    }
    else if (FreqUnit_Month == freqUnitEn && !oldMethod)
    {
        DAY_T begDateD = 0;
        YEAR_T  y;
        MONTH_T m;
        DAY_T   d;

        DATE_Get(begDate.date, &y, &m, &d);
        begDateD = d;

        DAY_T maxDaysInBegMonth = DATE_DaysInMonth(m, y);
        DAY_T maxDaysInNextMonth = DATE_DaysInMonth((m % 12) + 1, m != 12 ? y : y + 1);
        DATE_T monthBegDate = DATE_Put(y, m, 1); /* first day of the month */
        DATE_T monthEndDate = DATE_Put(y, m, maxDaysInBegMonth); /* first day of the month */

        if (StandInstructExecutionUnitEn::None != execUnit
            && StandInstructExecutionUnitRankEn::SI_Rank_None != execRank
            && StandInstructFrequencyChoiceEn::EveryWeekdayOrCalcDay == choice)
        {
            /* calculated method */
            /*
                ExecutionUnit
                    1=> Day, 2=>Weekday, 3=>weekend, 4=>Sunday, 5=>Monday..., 10=>Saturday
                ExecutionUnitRank
                    1=>First, 2=>Second, 3=>Third, 4=>Fourth, 5=>Last
                eg : (1,2) Second Day of month
                        (4,2) Second Sunday of month
                        (2,1) All second weekdays of month
            */

            if (StandInstructExecutionUnitEn::Day == execUnit)
            {
                if (StandInstructExecutionUnitRankEn::SI_Rank_Last != execRank)
                {
                    if (d > execRank)
                    {
                        begDate.date = DATE_Put(m != 12 ? y : y + 1, (m % 12) + 1, (DAY_T)execRank);
                    }
                    else
                    {
                        begDate.date = DATE_Put(y, m, (DAY_T)execRank);
                    }
                }
                else
                {
                    begDate.date = DATE_Put(y, m, maxDaysInBegMonth);
                }
            }
            else if (StandInstructExecutionUnitEn::Weekday == execUnit)
            {
                DATE_T tempBegDate;
                tempBegDate =  getNthWeekDayInMonth(y, m, execRank);
                if (DATE_Cmp(tempBegDate, begDate.date) < 0) /* nth weekday of this monthi less than si creation (beg date) , go and find same in ext month */
                {
                    tempBegDate = getNthWeekDayInMonth(m != 12 ? y : y + 1, (m % 12) + 1, execRank);
                }
                begDate.date = tempBegDate;
            }
            else if (StandInstructExecutionUnitEn::WeekendDay == execUnit)
            {
                
                DATE_T tempBegDate = NULL;
                if (StandInstructExecutionUnitRankEn::SI_Rank_Last != execRank)
                {
                    char dayIndex = DATE_WhichWeekDay(monthBegDate);
                    if (dayIndex != 0 && dayIndex != 6)
                    {
                        /* move to saturday */
                        tempBegDate = DATE_Move(monthBegDate, (6-dayIndex), Day);
                    }
                    tempBegDate = DATE_Move(tempBegDate, ((int)execRank - 1)*7, Day);

                    if (dayIndex == 0 && ((int)execRank) > 1)
                    {
                        tempBegDate = DATE_Move(tempBegDate, -1, Day);
                    }
                    
                    if (DATE_Cmp(tempBegDate, begDate.date) < 0) 
                    {
                        bool got = false;
                        YEAR_T ly; MONTH_T lm,lnm; DAY_T ld;
                        DATE_Get(tempBegDate, &ly, &lm, &ld);
                        if (DATE_WhichWeekDay(tempBegDate) == 6)
                        {
                            tempBegDate = DATE_Move(tempBegDate, 1, Day);
                            DATE_Get(tempBegDate, NULL, &lnm, NULL);
                            got = ((lm == lnm) && (DATE_Cmp(tempBegDate, begDate.date) >= 0));
                        }
                        if (!got)
                        {
                            /* move to next month */
                            tempBegDate = DATE_Put(m != 12 ? y : y + 1, (m % 12) + 1, 1);
                            dayIndex = DATE_WhichWeekDay(tempBegDate);
                            if (dayIndex != 0 && dayIndex != 6)
                            {
                                /* move to saturday */
                                tempBegDate = DATE_Move(tempBegDate, (6 - dayIndex), Day);
                            }
                            tempBegDate = DATE_Move(tempBegDate, ((int)execRank - 1) * 7, Day);
                            if (dayIndex == 0 && ((int)execRank) > 1)
                            {
                                tempBegDate = DATE_Move(tempBegDate, -1, Day);
                            }
                        }
                    }
                    begDate.date = tempBegDate;
                }
                else
                {
                    char dayIndex = DATE_WhichWeekDay(monthEndDate);
                    if (dayIndex != 6)
                    {
                        /* move to saturday */
                        tempBegDate = DATE_Move(monthEndDate, -(dayIndex+1), Day);
                    }

                    if (DATE_Cmp(tempBegDate, begDate.date) < 0)
                    {
                        if (dayIndex != 6)
                        {
                            tempBegDate = DATE_Move(tempBegDate, 1, Day);
                        }
                        if (DATE_Cmp(tempBegDate, begDate.date) < 0)
                        {
                            tempBegDate = DATE_Put(m != 12 ? y : y + 1, (m % 12) + 1, maxDaysInNextMonth);
                            dayIndex = DATE_WhichWeekDay(tempBegDate);
                            if (dayIndex != 6)
                            {
                                /* move to saturday */
                                tempBegDate = DATE_Move(tempBegDate, -(dayIndex + 1), Day);
                            }
                        }
                    }
                    begDate.date = tempBegDate;
                }
            }
            else
            {              
                /* Sunday to Saturday enums. */
                if (StandInstructExecutionUnitRankEn::SI_Rank_Last != execRank)
                {
                    monthBegDate = moveForwardToDate(execUnit, execRank, monthBegDate);

                    if (DATE_Cmp(monthBegDate, begDate.date) < 0)
                    {
                        monthBegDate = DATE_Put(m != 12 ? y : y + 1, (m % 12) + 1, 1);
                        begDate.date = moveForwardToDate(execUnit, execRank, monthBegDate);
                    }
                    else
                    {
                        begDate.date = monthBegDate;
                    }
                }
                else
                {
                    DATE_T tempBeginDate;
                    tempBeginDate = moveBackToDate(execUnit, monthEndDate);

                    if (DATE_Cmp(tempBeginDate, begDate.date) < 0)
                    {
                        monthEndDate = DATE_Put(m != 12 ? y : y + 1, (m % 12) + 1, maxDaysInNextMonth);
                        tempBeginDate = moveBackToDate(execUnit, monthEndDate);
                    }
                    begDate.date = tempBeginDate;
                }
            }
        }
        else if (execDay > 0
            && StandInstructFrequencyChoiceEn::EveryDayOrSpecificDay == choice)
        {
            /* specific day method */

            if (begDateD != execDay)
            {
                /* user set a exec_day_n which is not same as si begin date.
                 *  1. Beg date : 05-Jan-2020, exec_day_n : 10 => add 5 to make beg date to 10-Jan-2020
                 *  2. Beg date : 10-Jan-2020, exec_day_n : 5 => actual beg date here is 05-Feb-2020
                 */
                if (begDateD < execDay)
                {
                    if (isLastDayOfMonth)
                    {
                        begDate.date = DATE_Put(y, m, maxDaysInBegMonth);
                    }
                    else
                    {
                        begDate.date = DATE_Put(y, m, execDay > maxDaysInBegMonth ? maxDaysInBegMonth : execDay); /* ? to handle only feb month! */
                    }
                }
                else
                {
                    if (isLastDayOfMonth)
                    {
                        begDate.date = DATE_Put(m != 12 ? y : y + 1, (m % 12) + 1, maxDaysInNextMonth);
                    }
                    else
                    {
                        begDate.date = DATE_Put(m != 12 ? y : y + 1, (m % 12) + 1, execDay > maxDaysInNextMonth ? maxDaysInNextMonth : execDay); /* ? to handle only feb month! */
                    }
                }
            }
        }
        else
        {
            /*Invalid configuration.*/
            MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
                "FIN_GenerateStandInstructFlows", "Freq unit and method");
            return(RET_GEN_ERR_INVARG);
        }
        endDate.date = begDate.date;
    }
    else if (FreqUnit_Year == freqUnitEn && !oldMethod)
    {


        if (execMonth < 1 || execMonth >12)
        {   
            MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
                "FIN_GenerateStandInstructFlows", "execution month");
            return(RET_GEN_ERR_INVARG);
        }
        DAY_T begDateD = 0;
        MONTH_T begDateM = 0;
        YEAR_T  y;
        MONTH_T m;
        DAY_T   d;

        DATE_Get(begDate.date, &y, &m, &d);

        DAY_T maxDaysInBegMonth, maxDayInNextMonthNextyear;

        DATE_Get(begDate.date, (YEAR_T *)NULL, &begDateM, &begDateD);
        maxDaysInBegMonth = DATE_DaysInMonth((MONTH_T)execMonth, y);
        maxDayInNextMonthNextyear = DATE_DaysInMonth((MONTH_T)execMonth, y + 1);
        DATE_T monthBegDate = DATE_Put(y, (MONTH_T)execMonth, 1); /* first day of the month */
        DATE_T monthEndDate = DATE_Put(y, (MONTH_T)execMonth, maxDaysInBegMonth); /* first day of the month */

        if (StandInstructFrequencyChoiceEn::EveryWeekdayOrCalcDay == choice
            && StandInstructExecutionUnitEn::None != execUnit
            && StandInstructExecutionUnitRankEn::SI_Rank_None != execRank)
        {

            if (StandInstructExecutionUnitEn::Day == execUnit)
            {
                if (StandInstructExecutionUnitRankEn::SI_Rank_Last != execRank)
                {
                    if (begDateM > execMonth || (begDateM == execMonth && d > execRank))
                    {
                        begDate.date = DATE_Put(y + 1, (MONTH_T)execMonth, (DAY_T)execRank);
                    }
                    else
                    {
                        begDate.date = DATE_Put(y, (MONTH_T)execMonth, (DAY_T)execRank);
                    }
                }
                else
                {
                    if (begDateM > execMonth)
                    {
                        maxDaysInBegMonth = DATE_DaysInMonth((MONTH_T)execMonth, y + 1);
                        begDate.date = DATE_Put(y + 1, (MONTH_T)execMonth, maxDaysInBegMonth);
                    }
                    else
                    {
                        begDate.date = DATE_Put(y, (MONTH_T)execMonth, maxDaysInBegMonth);
                    }
                }
            }
            else if (StandInstructExecutionUnitEn::Weekday == execUnit)
            {
               
                DATE_T tempBegDate;
                tempBegDate = getNthWeekDayInMonth(y, (MONTH_T)execMonth, execRank);
                if (DATE_Cmp(tempBegDate, begDate.date) < 0) /* nth weekday of this monthi less than si creation (beg date) , go and find same in ext month */
                {
                    tempBegDate = getNthWeekDayInMonth(y+1, (MONTH_T)execMonth, execRank);
                }
                begDate.date = tempBegDate;
               
            }
            else if (StandInstructExecutionUnitEn::WeekendDay == execUnit)
            {
                DATE_T tempBegDate = NULL;
                if (StandInstructExecutionUnitRankEn::SI_Rank_Last != execRank)
                {
                    char dayIndex = DATE_WhichWeekDay(monthBegDate);
                    if (dayIndex != 0 && dayIndex != 6)
                    {
                        /* move to saturday */
                        tempBegDate = DATE_Move(monthBegDate, (6 - dayIndex), Day);
                    }
                    tempBegDate = DATE_Move(tempBegDate, ((int)execRank - 1) * 7, Day);
                    if (dayIndex == 0 && ((int)execRank) > 1)
                    {
                        tempBegDate = DATE_Move(tempBegDate, -1, Day);
                    }

                    if (DATE_Cmp(tempBegDate, begDate.date) < 0)
                    {
                        bool got = false;
                        YEAR_T ly; MONTH_T lm, lnm; DAY_T ld;
                        DATE_Get(tempBegDate, &ly, &lm, &ld);
                        if (DATE_WhichWeekDay(tempBegDate) == 6)
                        {
                            tempBegDate = DATE_Move(tempBegDate, 1, Day);
                            DATE_Get(tempBegDate, NULL, &lnm, NULL);
                            got = ((lm == lnm) && (DATE_Cmp(tempBegDate, begDate.date) >= 0));
                        }
                        if (!got)
                        {
                            /* move to next month */
                            tempBegDate = DATE_Put(y + 1, m, 1);
                            dayIndex = DATE_WhichWeekDay(tempBegDate);
                            if (dayIndex != 0 && dayIndex != 6)
                            {
                                /* move to saturday */
                                tempBegDate = DATE_Move(tempBegDate, (6 - dayIndex), Day);
                            }
                            tempBegDate = DATE_Move(tempBegDate, ((int)execRank - 1) * 7, Day);
                            if (dayIndex == 0 && ((int)execRank) > 1)
                            {
                                tempBegDate = DATE_Move(tempBegDate, -1, Day);
                            }
                        }
                    }
                    begDate.date = tempBegDate;
                }
                else
                {
                    char dayIndex = DATE_WhichWeekDay(monthEndDate);
                     if (dayIndex != 6)
                    {
                        /* move to saturday */
                        tempBegDate = DATE_Move(monthBegDate, -(dayIndex + 1), Day);
                    }

                    if (DATE_Cmp(tempBegDate, begDate.date) < 0)
                    {
                        if (dayIndex != 6)
                        {
                            tempBegDate = DATE_Move(tempBegDate, 1,  Day);
                        }
                        if (DATE_Cmp(tempBegDate, begDate.date) < 0)
                        {
                            tempBegDate = DATE_Put(y + 1, m, maxDayInNextMonthNextyear);
                            dayIndex = DATE_WhichWeekDay(tempBegDate);
                            if (dayIndex != 6)
                            {
                                /* move to saturday */
                                tempBegDate = DATE_Move(tempBegDate, -(dayIndex + 1), Day);
                            }
                        }
                    }
                    begDate.date = tempBegDate;
                }
            }
            else
            {
                /* sun to sat days with firs to last compo */
                monthBegDate = DATE_Put(y, (MONTH_T)execMonth, 1);
                monthEndDate = DATE_Put(y, (MONTH_T)execMonth, maxDaysInBegMonth);

                /* Sunday to Saturday enums. */
                if (StandInstructExecutionUnitRankEn::SI_Rank_Last != execRank)
                {
                    monthBegDate = moveForwardToDate(execUnit, execRank, monthBegDate);

                    if (DATE_Cmp(monthBegDate, begDate.date) < 0)
                    {
                        monthBegDate = DATE_Put(y + 1, (MONTH_T)execMonth, 1);
                        begDate.date = moveForwardToDate(execUnit, execRank, monthBegDate);
                    }
                    else
                    {
                        begDate.date = monthBegDate;
                    }
                }
                else
                {
                    monthEndDate = moveBackToDate(execUnit, monthEndDate);

                    if (DATE_Cmp(monthEndDate, begDate.date) < 0)
                    {
                        monthEndDate = DATE_Put(y + 1, (MONTH_T)execMonth, maxDayInNextMonthNextyear);
                        begDate.date = moveBackToDate(execUnit, monthEndDate);
                    }
                    else
                    {
                        begDate.date = monthEndDate;
                    }
                }
            }
        }
        else if (StandInstructFrequencyChoiceEn::EveryDayOrSpecificDay == choice)
        {
            if (execDay < 1 || execDay>31)
            {
                MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
                    "FIN_GenerateStandInstructFlows", "execution day");
                return(RET_GEN_ERR_INVARG);
            }
            if (begDateM > execMonth || (begDateM == execMonth && d > execDay))
            {
                y++;
            }
            maxDaysInBegMonth = DATE_DaysInMonth((MONTH_T)execMonth, y);
            if (isLastDayOfMonth || execDay > maxDaysInBegMonth)
            {
                begDate.date = DATE_Put(y, (MONTH_T)execMonth, maxDaysInBegMonth);
            }
            else
            {
                begDate.date = DATE_Put(y, (MONTH_T)execMonth, (DAY_T)execDay);
            }

        }
        endDate.date = begDate.date;
    }
    return RET_SUCCEED;
}

/************************************************************************
**
**  Function    :   FIN_GenerateStandInstructFlows()
**
**  Description :   Generate all Flows
**                 
**  Arguments   :   domainPtr	  domain pointer
**                  argHierHead   hierarchy pointer
**
**  Return      :   RET_SUCCEED 	or error code
**
**  Creation    :   PMSTA06761 - DDV - 080731
**
*************************************************************************/
RET_CODE FIN_GenerateStandInstructFlows(DBA_DYNFLD_STP    domainPtr,
    DATETIME_T        fromDate,
    DATETIME_T        tillDate,
    DBA_HIER_HEAD_STP,
    DBA_DYNFLD_STP    standInstructPtr,
    DBA_DYNFLD_STP    **flowTab,
    int               *flowNbr)
{
    DBA_DYNFLD_STP	flowPtr = NULLDYNST;
    DATETIME_T     	begDate, endDate;
    DAY_T           svEndD;
    int             flowTabSize = 0, freq = 0, currPeriod = 0;
    FLAG_T          endMFlg = FALSE, confirmParam;

    *flowNbr = 0;
    *flowTab = NULLDYNSTPTR;
    GEN_GetApplInfo(ApplEvtGenStandInstructConfFlag, &confirmParam);

    /* check that frequency unit is correct */
    if (GET_ENUM(standInstructPtr, A_StandInstruct_FreqUnitEn) != FreqUnit_Day &&
        GET_ENUM(standInstructPtr, A_StandInstruct_FreqUnitEn) != FreqUnit_Month &&
        GET_ENUM(standInstructPtr, A_StandInstruct_FreqUnitEn) != FreqUnit_Year &&
        GET_ENUM(standInstructPtr, A_StandInstruct_FreqUnitEn) != FreqUnit_Week &&
        GET_ENUM(standInstructPtr, A_StandInstruct_FreqUnitEn) != FreqUnit_Once)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
            "FIN_GenerateStandInstructFlows", "frequency unit");
        return(RET_GEN_ERR_INVARG);
    }

    /* check that frequency is correct */
    if ((freq = (int)GET_TINYINT(standInstructPtr, A_StandInstruct_Freq)) == 0 &&
        GET_ENUM(standInstructPtr, A_StandInstruct_FreqUnitEn) != FreqUnit_Once)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
            "FIN_GenerateStandInstructFlows", "frequency is zero");
        return(RET_GEN_ERR_INVARG);
    }

    /* check that begin date is correct */
    if (GET_DATE(standInstructPtr, A_StandInstruct_BegDate) == MAGIC_END_DATE ||
        GET_DATE(standInstructPtr, A_StandInstruct_BegDate) == BAD_DATE)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
            "FIN_GenerateStandInstructFlows", "begin date");
        return(RET_GEN_ERR_INVARG);
    }

    begDate.time = (TIME_T)0;
    endDate.time = (TIME_T)0;
    begDate.date = endDate.date = GET_DATE(standInstructPtr, A_StandInstruct_BegDate);

    /* Short month can corrupt day number */
    endMFlg = (FLAG_T)DATE_IsLastInMonth(begDate.date);
    DATE_Get(endDate.date, (YEAR_T*)NULL, (MONTH_T*)NULL, &svEndD);

    /*New SI changes*/
    StandInstructFrequencyChoiceEn choice = static_cast<StandInstructFrequencyChoiceEn>(GET_ENUM(standInstructPtr, A_StandInstruct_FreqChoiceEn));
    bool oldMethod = (StandInstructFrequencyChoiceEn::None == choice
        && FreqUnit_Week != GET_ENUM(standInstructPtr, A_StandInstruct_FreqUnitEn)
        && FreqUnit_Once != GET_ENUM(standInstructPtr, A_StandInstruct_FreqUnitEn));

    FLAG_T weekDays[7];
    int begDay = (int)DATE_WhichWeekDay(GET_DATE(standInstructPtr, A_StandInstruct_BegDate));
    int currDay = 0;
    bool isLastDayOfMonth = false;
    TINYINT_T execDay = 0, execMonth = 0;

    StandInstructExecutionUnitEn execUnit = static_cast<StandInstructExecutionUnitEn>(GET_ENUM(standInstructPtr, A_StandInstruct_ExecUnitEn));
    StandInstructExecutionUnitRankEn execRank = static_cast<StandInstructExecutionUnitRankEn>(GET_ENUM(standInstructPtr, A_StandInstruct_ExecUnitRankEn));
    FREQUNIT_ENUM freqUnitEn = static_cast<FREQUNIT_ENUM>(GET_ENUM(standInstructPtr, A_StandInstruct_FreqUnitEn));
    
    isLastDayOfMonth = (31 == (execDay = GET_TINYINT(standInstructPtr, A_StandInstruct_ExecDay)));
    execMonth = GET_TINYINT(standInstructPtr, A_StandInstruct_ExecMonth);
   
    weekDays[0] = GET_FLAG(standInstructPtr, A_StandInstruct_DaySunFlg);
    weekDays[1] = GET_FLAG(standInstructPtr, A_StandInstruct_DayMonFlg);
    weekDays[2] = GET_FLAG(standInstructPtr, A_StandInstruct_DayTueFlg);
    weekDays[3] = GET_FLAG(standInstructPtr, A_StandInstruct_DayWedFlg);
    weekDays[4] = GET_FLAG(standInstructPtr, A_StandInstruct_DayThuFlg);
    weekDays[5] = GET_FLAG(standInstructPtr, A_StandInstruct_DayFriFlg);
    weekDays[6] = GET_FLAG(standInstructPtr, A_StandInstruct_DaySatFlg);

    if (RET_SUCCEED != getRealSIBegDate(
        begDate, endDate,
        freqUnitEn,
        choice,
        oldMethod,
        weekDays,
        begDay,
        currDay,
        isLastDayOfMonth,
        execDay,
        execMonth,
        execUnit,
        execRank,
        endMFlg,
        svEndD))
    {
        return RET_GEN_ERR_INVARG;
     }

    if (FreqUnit_Once != GET_ENUM(standInstructPtr, A_StandInstruct_FreqUnitEn))
    {
        while (begDate.date < fromDate.date ||
            begDate.date == endDate.date)
        {
            begDate.date = endDate.date;

            getNextExecDay(
                begDate, endDate,
                freqUnitEn,
                choice,
                oldMethod,
                weekDays,
                begDay,
                currDay,
                isLastDayOfMonth,
                execDay,
                execMonth,
                execUnit,
                execRank,
                endMFlg,
                svEndD,
                fromDate,
                freq);

            currPeriod++;
            if (DATE_Cmp(begDate.date, endDate.date) == 0)
            {
                /*Something wrong. this will leads to infinte loop. lets break and return error*/
                MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
                    "FIN_GenerateStandInstructFlows", "Invalid Frequency ");
                return(RET_GEN_ERR_INVARG);
            }
        }
    }
    else
    {
        currPeriod = 1; /* only one flow. */
    }

    while (begDate.date < tillDate.date &&
           (IS_NULLFLD(standInstructPtr, A_StandInstruct_EndDate) == TRUE ||
            begDate.date < GET_DATE(standInstructPtr, A_StandInstruct_EndDate)))
    {
        if ((*flowNbr) % 10 == 0)
        {
            flowTabSize += 10;
            if (((*flowTab) = (DBA_DYNFLD_STP *)
                REALLOC((*flowTab), flowTabSize * sizeof(DBA_DYNFLD_STP))) == (DBA_DYNFLD_STP*) NULL)
            {
                MSG_RETURN(RET_MEM_ERR_ALLOC);
            }
        }

        if (((*flowTab)[(*flowNbr)] = ALLOC_DYNST(Flow)) == NULLDYNST)
        {
            DBA_FreeDynStTab((*flowTab), (*flowNbr), Flow);
            (*flowTab) = NULLDYNSTPTR;
            (*flowNbr) = 0;
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        flowPtr = (*flowTab)[(*flowNbr)];

        COPY_DYNFLD(flowPtr, Flow, Flow_StandInstructId, standInstructPtr,A_StandInstruct,A_StandInstruct_Id);
        COPY_DYNFLD(flowPtr, Flow, Flow_EvtCd,     standInstructPtr, A_StandInstruct, A_StandInstruct_Cd);
        if (IS_NULLFLD(standInstructPtr, A_StandInstruct_FlowEvtNbr) == TRUE)
        {
            SET_INT(flowPtr,           Flow_EvtNbr,         currPeriod);
        }
        else
        {
            COPY_DYNFLD(flowPtr, Flow, Flow_EvtNbr, standInstructPtr, A_StandInstruct, A_StandInstruct_FlowEvtNbr);
        }

        COPY_DYNFLD(flowPtr, Flow, Flow_InstrId,   standInstructPtr, A_StandInstruct, A_StandInstruct_InstrId);
        COPY_DYNFLD(flowPtr, Flow, Flow_AmtUnit,   standInstructPtr, A_StandInstruct, A_StandInstruct_OpAmt);
        COPY_DYNFLD(flowPtr, Flow, Flow_AmtCurrId, standInstructPtr, A_StandInstruct, A_StandInstruct_OpAmtCurrId);

        COPY_DYNFLD(flowPtr, Flow, Flow_Freq,   standInstructPtr, A_StandInstruct, A_StandInstruct_Freq);
        COPY_DYNFLD(flowPtr, Flow, Flow_FreqUnitEn,standInstructPtr,A_StandInstruct,A_StandInstruct_FreqUnitEn);


        SET_ENUM(flowPtr,          Flow_NatEn,          FlowNat_StandInstruct);
        if (GET_ENUM(standInstructPtr, A_StandInstruct_OpNatEn) == OpNat_Buy)
        {
            SET_ENUM(flowPtr,          Flow_SubNatEn, FlowSubNat_StandInstructBuy);
        }
        else if (GET_ENUM(standInstructPtr, A_StandInstruct_OpNatEn) == OpNat_Sell)
        {
            SET_ENUM(flowPtr,          Flow_SubNatEn, FlowSubNat_StandInstructSell);
        }
        
        else if (StandInstructOpNatEn::Invest == static_cast<StandInstructOpNatEn>(GET_ENUM(standInstructPtr, A_StandInstruct_OpNatEn)))
        {
            SET_ENUM(flowPtr, Flow_SubNatEn, FlowSubNat_StandInstructionInvest);
        }
        else if (StandInstructOpNatEn::Withdrawal == static_cast<StandInstructOpNatEn>(GET_ENUM(standInstructPtr, A_StandInstruct_OpNatEn)))
        {
            SET_ENUM(flowPtr, Flow_SubNatEn, FlowSubNat_StandInstructionWithdraw);
        }

        if (domainPtr != NULLDYNST &&
            (EVTGEN_ENUM) GET_ENUM(domainPtr, A_Domain_EvtGenNatEn) == EvtGen_Automatic)
        {
            SET_FLAG(flowPtr,          Flow_ConfirmedFlg,   TRUE);
        }
        else
        {
            SET_FLAG(flowPtr,          Flow_ConfirmedFlg,   confirmParam);
        }

        SET_DATETIME(flowPtr,      Flow_BegPayDate,     begDate);
        SET_DATETIME(flowPtr,      Flow_EndPayDate,     begDate);
        SET_DATETIME(flowPtr,      Flow_OptimalDate,    begDate);
        SET_DATETIME(flowPtr,      Flow_OptimalValDate, begDate);

        SET_NULL_PERIOD(flowPtr,   Flow_SettlDays);
        SET_NULL_NUMBER(flowPtr,   Flow_Yield);
        SET_NULL_EXCHANGE(flowPtr, Flow_FxdExchRate);
        SET_NULL_PERCENT(flowPtr,  Flow_IoRPrct);
		SET_PRICE(flowPtr,        Flow_Quote,          1.0);
        SET_NUMBER(flowPtr,        Flow_RefQty,         1.0);
        SET_FLAG(flowPtr,          Flow_ReplaceFlg,     FALSE);
        SET_NULL_ID(flowPtr,       Flow_NewInstrId);
        SET_NULL_NUMBER(flowPtr,   Flow_QtyUnit);
        SET_NULL_ENUM(flowPtr,     Flow_OptClassEn);
        SET_NULL_ENUM(flowPtr,     Flow_OptStyleEn);
        SET_PERCENT(flowPtr,       Flow_Proba,          100.0);
        SET_NULL_EXCHANGE(flowPtr, Flow_FxdExchRate);
        SET_NULL_DATE(flowPtr,     Flow_ExDate);
        SET_NULL_NUMBER(flowPtr,   Flow_CtdConvFact);
        SET_NULL_NUMBER(flowPtr,   Flow_CtdConvRatio);
        SET_NULL_ID(flowPtr,       Flow_CtdInstrId);
        SET_FLAG(flowPtr,          Flow_PhysicalFlg,  FALSE);
        SET_NULL_TINYINT(flowPtr,  Flow_Priority);
        SET_FLAG(flowPtr,          Flow_EffectiveFlg, FALSE);
        SET_ENUM(flowPtr,          Flow_EuroConvRuleEn,   EuroConvRule_None);
        SET_ENUM(flowPtr,          Flow_RoundRuleEn,      RndRule_None);
        SET_NULL_NUMBER(flowPtr,   Flow_NewInstrMinDenom);
        SET_ENUM(flowPtr,          Flow_OddLotCompEn,     OddLotComp_Lost);
        SET_ENUM(flowPtr,          Flow_RoundLevelEn,     RndLevel_None);
        SET_NULL_NUMBER(flowPtr,   Flow_DiscountFactor);
        SET_NULL_PRICE(flowPtr,   Flow_ReceivedAmtUnit);
        SET_NULL_PRICE(flowPtr,   Flow_PaidAmtUnit);
        SET_NULL_ID(flowPtr,       Flow_YieldCurveInstrId);

        /* Go on next period */
        (*flowNbr)++;
        currPeriod++;
        begDate = endDate;
        if (GET_ENUM(standInstructPtr, A_StandInstruct_FreqUnitEn) == FreqUnit_Once)
        {
            begDate.date = MAGIC_END_DATE;
        }
        else
        {
            getNextExecDay(
                begDate, endDate,
                freqUnitEn,
                choice,
                oldMethod,
                weekDays,
                begDay,
                currDay,
                isLastDayOfMonth,
                execDay,
                execMonth,
                execUnit,
                execRank,
                endMFlg,
                svEndD,
                fromDate,
                freq);

            if (DATE_Cmp(begDate.date, endDate.date) == 0)
            {
                /*Something wrong. this will leads to infinte loop. lets break and return error*/
                MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
                    "FIN_GenerateStandInstructFlows", "Invalid Frequency ");
                
                DBA_FreeDynStTab((*flowTab), (*flowNbr), Flow);
                (*flowTab) = NULLDYNSTPTR;
                (*flowNbr) = 0;
                
                return(RET_GEN_ERR_INVARG);
            }
        }
       
    }

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function          : FIN_FundShareFlows()
**
**  Description       : Retrieves all possible flows of a Fund Share.
**
**  Arguments         : fromDateTime   reference date
**                      tillDateTime  end date
**                      valDateTime
**                      inputInstrPtr pointer on instrument struct or NULL
**                      evtDateRule   enum used in event generation for event operation date rule (set in domain)
**                      flowTab       pointer on flows array which will be
**                                    allocated and filled up
**                                    (initialised to NULL by FIN_GenerateInstrFlows())
**                      flowNbr       pointer on flows number which will be
**                                    filled up
**                                    (initialised to 0 by FIN_GenerateInstrFlows())
**
**  Warning           : Calling function is FIN_GenerateInstrFlows()
**
**  Return            : RET_SUCCEED
**                      RET_MEM_ERR_ALLOC
**                      RET_GEN_ERR_INVARG
**
**  Creation date     : Sep 2018 - NRAO
**
*************************************************************************/
STATIC RET_CODE FIN_FundShareFlows(DATETIME_T        fromDateTime,
                                   DATETIME_T        tillDateTime,
                                   DATETIME_T        valDateTime,
                                   DBA_DYNFLD_STP    instrPtr,
                                   EVTDATERULE_ENUM  evtDateRule,
                                   DBA_DYNFLD_STP    **flowTab,
                                   int               *flowNbr,
                                   DBA_HIER_HEAD_STP hierHead)
{
    DBA_DYNFLD_STP  flowSt = NULLDYNST, *ioRTab = (DBA_DYNFLD_STP*)NULL;
    DATETIME_T      date, begDate, endDate;
    DAY_T           svEndD;
    char            endMFlg;
    int             i, ioRNbr, currPeriod, allocSz = 0, reallocSz = 5;
    double          freq = 0.0;
    RET_CODE        ret = RET_SUCCEED;

    date.time = 0;
    begDate.time = 0;
    endDate.time = 0;

    /*create income event flows for fund share instruments*/
    FIN_StockFlows(fromDateTime, tillDateTime, valDateTime,
        instrPtr, evtDateRule, flowTab, flowNbr, hierHead, &allocSz);


    if ((ret = DBA_SelectIOREvtForPEFundShare(instrPtr, fromDateTime, tillDateTime,
                                              valDateTime, &ioRTab, &ioRNbr, hierHead)) != RET_SUCCEED ||
         ioRNbr == 0)
    {
        MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO,
                     "FIN_FundShareFlows", GET_CODE(instrPtr, A_Instr_Cd),
                     "issue or redemption parameters");

        return(RET_SUCCEED);
    }

    const SUBNAT_ENUM  instrSubNatEn = static_cast<SUBNAT_ENUM>(GET_ENUM(instrPtr, A_Instr_SubNatEn));

    /* For each redemption event */
    for (i = 0; i<ioRNbr; i++)
    {
        FIN_PeriodUnitNbr((FREQUNIT_ENUM)GET_ENUM(ioRTab[i], A_IssueEvt_FreqUnitEn),
                          GET_TINYINT(ioRTab[i], A_IssueEvt_Freq),FreqUnit_Month, &freq);

        if (GET_DATE(ioRTab[i], A_IssueEvt_EndDate) < fromDateTime.date)
            continue;

        /*handle similar for all event natures*/
        if ((ISSREDMNAT_ENUM)GET_ENUM(ioRTab[i], A_IssueEvt_NatEn) == IssRedmNat_CapitalToPay &&
            (instrSubNatEn == SUBNAT_ENUM::SubNat_PEInitialCommitment ||
             instrSubNatEn == SUBNAT_ENUM::SubNat_ActualPESecurity ||
             instrSubNatEn == SUBNAT_ENUM::SubNat_PECapitalCall))
            continue;

        if ((ISSREDMNAT_ENUM)GET_ENUM(ioRTab[i], A_IssueEvt_NatEn) == IssRedmNat_TotalIssue &&
            (instrSubNatEn == SUBNAT_ENUM::SubNat_PEInitialCommitment ||
             instrSubNatEn == SUBNAT_ENUM::SubNat_PEDrawdown ||
             instrSubNatEn == SUBNAT_ENUM::SubNat_ActualPESecurity))
            continue;

        if ((ISSREDMNAT_ENUM)GET_ENUM(ioRTab[i], A_IssueEvt_NatEn) == IssRedmNat_CapRed &&
            (instrSubNatEn == SUBNAT_ENUM::SubNat_ActualPESecurity ||
             instrSubNatEn == SUBNAT_ENUM::SubNat_PECapitalCall ||
             instrSubNatEn == SUBNAT_ENUM::SubNat_PEDrawdown))
            continue;

        if ((ISSREDMNAT_ENUM)GET_ENUM(ioRTab[i], A_IssueEvt_NatEn) == IssRedmNat_CapitalReturn &&
            (instrSubNatEn == SUBNAT_ENUM::SubNat_PEInitialCommitment ||
             instrSubNatEn == SUBNAT_ENUM::SubNat_ActualPESecurity ||
             instrSubNatEn == SUBNAT_ENUM::SubNat_PEDrawdown))
            continue;

        if ((ISSREDMNAT_ENUM)GET_ENUM(ioRTab[i], A_IssueEvt_NatEn) == IssRedmNat_CapitalToRec &&
            (instrSubNatEn == SUBNAT_ENUM::SubNat_PEInitialCommitment ||
             instrSubNatEn == SUBNAT_ENUM::SubNat_PEDrawdown ||
             instrSubNatEn == SUBNAT_ENUM::SubNat_PECapitalCall))
            continue;

        begDate.date = GET_DATE(ioRTab[i], A_IssueEvt_BegDate);
        endDate.date = GET_DATE(ioRTab[i], A_IssueEvt_BegDate);
        /* Short month can corrupt day number */
        endMFlg = (char)DATE_IsLastInMonth(endDate.date);
        DATE_Get(endDate.date, (YEAR_T *)NULL, (MONTH_T *)NULL, &svEndD);

        if (endDate.date == BAD_DATE)
        {
            DBA_FreeDynStTab(ioRTab, ioRNbr, A_IssueEvt);
            MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO, "FIN_FundShareFlows",
                GET_CODE(instrPtr, A_Instr_Cd), "end date");

            return(RET_SUCCEED); /*Return Success as there might be valid FIN_StockFlows*/
        }

        /* Advance in repetitiv event until journal begin date */
        currPeriod = 1;
        while (endDate.date < fromDateTime.date && freq > 0)
        {
            begDate = endDate;
            endDate.date = DATE_Move(begDate.date, (int)freq, Month);
            /* Short month can corrupt day number */
            DATE_VerifyEndMonth(&endDate.date, svEndD, endMFlg);
            ++currPeriod;
        }

        if (freq == 0.)    /* No repetitive event (one period) */
            endDate.date = GET_DATE(ioRTab[i], A_IssueEvt_EndDate);
        else if (begDate.date == endDate.date)
        {
            endDate.date = DATE_Move(begDate.date, (int)freq, Month);
            /* Short month can corrupt day number */
            DATE_VerifyEndMonth(&endDate.date, svEndD, endMFlg);
            ++currPeriod;
        }

        /* For each period in current income event */
        /* (one in case of no repetitive event)    */
        while (endDate.date <= GET_DATE(ioRTab[i], A_IssueEvt_EndDate) &&
            endDate.date <= tillDateTime.date)
        {
            if ((allocSz) == 0 || *flowNbr >= (allocSz)-1)
            {
                (allocSz) += reallocSz;
                if (((*flowTab) = (DBA_DYNFLD_STP *)
                    REALLOC((*flowTab), (allocSz)*sizeof(DBA_DYNFLD_STP))) == (DBA_DYNFLD_STP *)NULL)
                {
                    DBA_FreeDynStTab(ioRTab, ioRNbr, A_IssueEvt);
                    MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, "FIN_FundShareFlows",
                                 GET_CODE(instrPtr, A_Instr_Cd), "end date");

                    return(RET_SUCCEED); /*Return Success as there might be valid income FIN_StockFlows*/
                }
            }

            if (((*flowTab)[*flowNbr] = ALLOC_DYNST(Flow)) == NULLDYNST)
            {
                DBA_FreeDynStTab(ioRTab, ioRNbr, A_IssueEvt);
                MSG_SendMesg(RET_MEM_ERR_ALLOC, 1, FILEINFO, "FIN_FundShareFlows",
                             GET_CODE(instrPtr, A_Instr_Cd), "end date");

                return(RET_SUCCEED); /*Return Success as there might be valid income FIN_StockFlows*/
            }

            flowSt = (*flowTab)[*flowNbr];
            SET_ID(flowSt, Flow_InstrId, GET_ID(instrPtr, A_Instr_Id));
            SET_CODE(flowSt, Flow_EvtCd, GET_CODE(ioRTab[i], A_IssueEvt_Cd));
            SET_INT(flowSt, Flow_EvtNbr, currPeriod);
            SET_FLAG(flowSt, Flow_ConfirmedFlg, TRUE);
            SET_DATETIME(flowSt, Flow_BegPayDate, begDate);
            SET_DATETIME(flowSt, Flow_EndPayDate, endDate);
            SET_DATETIME(flowSt, Flow_OptimalDate, endDate);

            date.date = GET_DATE(flowSt, Flow_OptimalDate);
            SET_DATETIME(flowSt, Flow_OptimalValDate, date);

            SET_PERCENT(flowSt, Flow_IoRPrct, GET_PERCENT(ioRTab[i], A_IssueEvt_ProporPrct));

            SET_NULL_NUMBER(flowSt, Flow_RefQty);

            if ((ISSREDMNAT_ENUM)GET_ENUM(ioRTab[i], A_IssueEvt_NatEn) == IssRedmNat_TotalIssue)
            {
                SET_ENUM(flowSt, Flow_NatEn, FlowNat_Iss);
            }
            else if ((ISSREDMNAT_ENUM)GET_ENUM(ioRTab[i], A_IssueEvt_NatEn) == IssRedmNat_FinalRedm)
            {
                SET_ENUM(flowSt, Flow_NatEn, FlowNat_Redm);
                if (instrSubNatEn == SUBNAT_ENUM::SubNat_ActualPESecurity)
                {
					SET_PRICE(flowSt, Flow_Quote, GET_PRICE(ioRTab[i], A_IssueEvt_Quote));
					SET_PRICE(flowSt, Flow_AmtUnit, GET_PRICE(ioRTab[i], A_IssueEvt_Price));
                }

            }
            else if ((ISSREDMNAT_ENUM)(GET_ENUM(ioRTab[i], A_IssueEvt_NatEn) == IssRedmNat_CapitalToPay) ||
                     (ISSREDMNAT_ENUM)(GET_ENUM(ioRTab[i], A_IssueEvt_NatEn) == IssRedmNat_CapRed))
            {
                SET_ENUM(flowSt, Flow_NatEn, FlowNat_Redm);
            }
            else if ((ISSREDMNAT_ENUM)GET_ENUM(ioRTab[i], A_IssueEvt_NatEn) == IssRedmNat_CapitalToRec ||
                     (ISSREDMNAT_ENUM)(GET_ENUM(ioRTab[i], A_IssueEvt_NatEn) == IssRedmNat_CapitalReturn))
            {
                SET_ENUM(flowSt, Flow_NatEn, FlowNat_Redm);

                PERCENT_T lastCapitalCallPct;
                DBA_DYNFLD_STP lastCapitalCallStp = NULLDYNST;
                const PROPORTION_APPL_ENUM proportionApplEn = static_cast<PROPORTION_APPL_ENUM>(GET_ENUM(ioRTab[i], A_IssueEvt_ProporApplEn));
                if (proportionApplEn == ProportionAppl_LastCapitalCall) /*Last capital Call*/
                {
                    DBA_GetLatestIssRedmEvent(GET_ID(ioRTab[i], A_IssueEvt_InstrId), endDate, (ENUM_T)IssRedmNat_CapitalToPay, &lastCapitalCallStp);

                    if (lastCapitalCallStp != NULLDYNST)
                    {
                        lastCapitalCallPct = GET_PERCENT(lastCapitalCallStp, A_IssueEvt_ProporPrct) * 0.01;
                        SET_PERCENT(flowSt,
                            Flow_IoRPrct, GET_PERCENT(ioRTab[i], A_IssueEvt_ProporPrct) * lastCapitalCallPct);
                    }
                }
            }

            SET_ENUM(flowSt, Flow_SubNatEn,
                FIN_GetIoRFlowSubNat((ISSREDMNAT_ENUM)GET_ENUM(ioRTab[i], A_IssueEvt_NatEn)));

            SET_ID(flowSt, Flow_AmtCurrId, GET_ID(ioRTab[i], A_IssueEvt_CurrId));
            SET_NULL_ID(flowSt, Flow_NewInstrId);
            SET_NULL_NUMBER(flowSt, Flow_QtyUnit);
            SET_NULL_ENUM(flowSt, Flow_OptClassEn);
            SET_NULL_ENUM(flowSt, Flow_OptStyleEn);
            SET_PERCENT(flowSt, Flow_Proba, 100.0);

            SET_TINYINT(flowSt, Flow_Freq,
                GET_TINYINT(ioRTab[i], A_IssueEvt_Freq));
            SET_ENUM(flowSt, Flow_FreqUnitEn,
                GET_ENUM(ioRTab[i], A_IssueEvt_FreqUnitEn));
            SET_EXCHANGE(flowSt, Flow_FxdExchRate,
                GET_EXCHANGE(ioRTab[i], A_IssueEvt_FxdExchRate));
            if (DATETIME_CMP(GET_DATETIME(ioRTab[i], A_IssueEvt_EffectiveDate),
                fromDateTime) < 0)
            {
                SET_FLAG(flowSt, Flow_EffectiveFlg, TRUE);
            }
            else
            {
                SET_FLAG(flowSt, Flow_EffectiveFlg, FALSE);
            }


            SET_NULL_DATE(flowSt, Flow_ExDate);
            SET_NULL_NUMBER(flowSt, Flow_CtdConvFact);
            SET_NULL_NUMBER(flowSt, Flow_CtdConvRatio);
            SET_NULL_ID(flowSt, Flow_CtdInstrId);
            SET_FLAG(flowSt, Flow_PhysicalFlg, FALSE);
            SET_NULL_TINYINT(flowSt, Flow_Priority);

            /* Go on next period */
            (*flowNbr)++;
            currPeriod++;
            begDate = endDate;

            if (freq == 0.)    /* No repetitive event (one period), stop */
                endDate.date = DATE_Move(endDate.date, 1, Day);
            else
            {
                endDate.date = DATE_Move(begDate.date, (int)freq, Month);
                /* Short month can corrupt day number */
                DATE_VerifyEndMonth(&endDate.date, svEndD, endMFlg);
            }
        }
    }

    DBA_FreeDynStTab(ioRTab, ioRNbr, A_IssueEvt);

    return(RET_SUCCEED);
}

/************************************************************************
**  Function          : FIN_NewStockFlows()
**
**  Description       : Wrapper function over FIN_StockFlows()
**
**  Creation date     : Sep 2018 - NRAO
**
*************************************************************************/
STATIC RET_CODE FIN_NewStockFlows(DATETIME_T        fromDateTime,
                                  DATETIME_T        tillDateTime,
                                  DATETIME_T        valDateTime,
                                  DBA_DYNFLD_STP    instrPtr,
                                  EVTDATERULE_ENUM  evtDateRule,
                                  DBA_DYNFLD_STP    **flowTab,
                                  int               *flowNbr,
                                  DBA_HIER_HEAD_STP hierHead)
{
    RET_CODE            ret = RET_SUCCEED;
    int                 allocSz = 0;

    ret = FIN_StockFlows(fromDateTime, tillDateTime, valDateTime,
                         instrPtr, evtDateRule, flowTab, flowNbr, hierHead, &allocSz);

    return(ret);
}

/************************************************************************
**
**  Function          : FIN_GenStockInstrFlow()
**
**  Description       : To generate flow of a stock.
**
**  Arguments         : fromDateTime   reference date
**                      tillDateTime  end date
**                      valDateTime
**                      inputInstrPtr pointer on instrument struct or NULL
**                      evtDateRule   enum used in event generation for event operation date rule (set in domain)
**                      flowTab       pointer on flows array which will be
**                                    allocated and filled up
**                                    (initialised to NULL by FIN_GenerateInstrFlows())
**                      flowNbr       pointer on flows number which will be
**                                    filled up
**                                    (initialised to 0 by FIN_GenerateInstrFlows())
**
**  Return            : RET_SUCCEED
**                      RET_MEM_ERR_ALLOC
**                      RET_GEN_ERR_INVARG
**
**
*************************************************************************/
RET_CODE FIN_GenStockInstrFlow( DATETIME_T        fromDateTime,
                                DATETIME_T        tillDateTime,
                                DATETIME_T        valDateTime,
                                DBA_DYNFLD_STP    instrPtr,
                                EVTDATERULE_ENUM  evtDateRule,
                                DBA_DYNFLD_STP    **flowTab,
                                int               *flowNbr,
                                DBA_HIER_HEAD_STP hierHead )
{
	DBA_DYNFLD_STP  *incTab = (DBA_DYNFLD_STP*)NULL;
	DATETIME_T      begDate, endDate;
	DAY_T           svEndD;
	char            endMFlg;
	int             incNbr, i, currPeriod;
	double          freq;
	RET_CODE        ret;
	int		oldFlows;
	int               allocSz = 0;

    begDate.time = 0;
    endDate.time = 0;

    /************** EXCHANGE FLOWS ************/
    FIN_CreateExchangeFlows(instrPtr, fromDateTime, &tillDateTime, valDateTime,
        evtDateRule, &allocSz, flowNbr, flowTab, hierHead); 

    oldFlows = *flowNbr;

    /*** DIVIDEND ***/
    if ((ret = DBA_SelectIncEvt(instrPtr, fromDateTime, tillDateTime,
        valDateTime, &incTab, &incNbr)) != RET_SUCCEED)
    {
        RET_GENFLOWS(ret);
    }

    /* Frequency is in instrument */
    FIN_PeriodUnitNbr((FREQUNIT_ENUM)GET_ENUM(instrPtr, A_Instr_PayFreqUnitEn),
        GET_TINYINT(instrPtr, A_Instr_PayFreq), FreqUnit_Month, &freq);

	for (i = incNbr - 1; i >= 0; i--)
	{
		endDate.date = begDate.date = GET_DATE(incTab[i], A_IncEvt_BeginDate);

		/* Income event must be in report period */
		if (GET_DATE(incTab[i], A_IncEvt_LastPayDate) < fromDateTime.date)
			continue;

		/* Search last projectible income event */
		if (freq != 0 && GET_FLAG(incTab[i], A_IncEvt_DivProjectionFlg) == TRUE)
		{
			/* Short month can corrupt day number */
			endMFlg = (char)DATE_IsLastInMonth(endDate.date);
			DATE_Get(endDate.date, (YEAR_T*)NULL, (MONTH_T*)NULL, &svEndD);

			if (endDate.date == BAD_DATE)
			{
				DBA_FreeDynStTab(incTab, incNbr, A_IncEvt);
				MSG_SendMesg(RET_FIN_ERR_INVDATA, 1, FILEINFO,  
					"FIN_StockFlows",
					GET_CODE(instrPtr, A_Instr_Cd), "end date");

				for (i = oldFlows; i < (*flowNbr); i++)
				{
					FREE_DYNST((*flowTab)[i], Flow);
				}
				(*flowNbr) = oldFlows;
				return(RET_SUCCEED);
			}

			/* Advance in repetitiv event until journal begin date */
			currPeriod = 1;
			if (GET_DATE(incTab[i], A_IncEvt_FirstCoupDate) < fromDateTime.date)
			{
				begDate = endDate;
				if (freq == 0.)    /* No repetitive event (one period) */
					endDate.date = GET_DATE(incTab[i], A_IncEvt_LastPayDate);
				else
				{
					endDate.date = DATE_Move(begDate.date, (int)freq, Month);
					/* Short month can corrupt day number */
					DATE_VerifyEndMonth(&endDate.date, svEndD, endMFlg);
				}
				++currPeriod;
			}

			/* For each period in current income event */
			/* (one in case of no repetitive event)    */
			while (endDate.date <= GET_DATE(incTab[i], A_IncEvt_LastPayDate) &&
				endDate.date <= tillDateTime.date)
			{
				if ((ret = FIN_CreateStockFlow(&allocSz, *flowNbr,
					flowTab, incTab[i], instrPtr,
					currPeriod, TRUE, begDate, endDate, hierHead)) != RET_SUCCEED)
				{
					DBA_FreeDynStTab(incTab, incNbr, A_IncEvt);
					/*remove last flows */
					for (i = oldFlows; i < (*flowNbr); i++)
					{
						FREE_DYNST((*flowTab)[i], Flow);
					}
					(*flowNbr) = oldFlows;
					RET_GENFLOWS(ret);
				}

				/* Go on next period */
				(*flowNbr)++;
				currPeriod++;
				begDate = endDate;

				if (freq == 0.)         /* No repetitive event, stop */
					endDate.date = DATE_Move(endDate.date, 1, Day);
				else
				{
					endDate.date = DATE_Move(begDate.date, (int)freq, Month);
					/* Short month can corrupt day number */
					DATE_VerifyEndMonth(&endDate.date, svEndD, endMFlg);
				}
			}
		}
		else
		{
			if (fromDateTime.date >= GET_DATE(incTab[i], A_IncEvt_BeginDate) &&
				fromDateTime.date <= GET_DATE(incTab[i], A_IncEvt_FirstCoupDate))
			{
				begDate.date = GET_DATE(incTab[i], A_IncEvt_BeginDate);
				endDate.date = GET_DATE(incTab[i], A_IncEvt_BeginDate);

                if ((ret = FIN_CreateStockFlow(&allocSz, *flowNbr,
                    flowTab, incTab[i], instrPtr,
                    1, FALSE, begDate, endDate, hierHead)) != RET_SUCCEED)
                {
                    DBA_FreeDynStTab(incTab, incNbr, A_IncEvt);
                    for (int j = oldFlows; j < (*flowNbr); j++)
                    {
                        FREE_DYNST((*flowTab)[j], Flow);
                    }
                    (*flowNbr) = oldFlows;
                    RET_GENFLOWS(ret);
                }

				/* Go on next period */
				(*flowNbr)++;
			}
		}
	}
	if (ret == RET_SUCCEED && *flowNbr > 1)
	{
		TLS_Sort((char *)*flowTab, *flowNbr, sizeof(DBA_DYNFLD_STP), FIN_CmpFlowsBydate, (PTR **)NULL, SortRtnTp_None);
		DBA_DYNFLD_STP *tempTab = *flowTab;
		i = 0;
		while (i < *flowNbr - 1)
		{
			if (GET_DATE(tempTab[i], Flow_BegPayDate) == GET_DATE(tempTab[i + 1], Flow_BegPayDate) &&
				GET_DATE(tempTab[i], Flow_OptimalValDate) == GET_DATE(tempTab[i + 1], Flow_OptimalValDate))
			{
				double qty = GET_PRICE(tempTab[i], Flow_Quote) + GET_PRICE(tempTab[i + 1], Flow_Quote);
				SET_PRICE(tempTab[i], Flow_Quote, qty);
				DBA_FreeDynSt(tempTab[i + 1], Flow);
				*flowNbr--;
			}
			else
			{
				i++;
			}
		}
	}

    DBA_FreeDynStTab(incTab, incNbr, A_IncEvt);

    return(RET_SUCCEED);
}

STATIC int FIN_CmpFlowsBydate(void* arg1, void* arg2)
{
	DBA_DYNFLD_STP  *flow1 = (DBA_DYNFLD_STP*)arg1;
	DBA_DYNFLD_STP  *flow2 = (DBA_DYNFLD_STP*)arg2;
	int diff;

	if ((diff = DATETIME_CMP(
			GET_DATETIME((*flow1), Flow_BegPayDate),
			GET_DATETIME((*flow2), Flow_BegPayDate))) == 0)
	{
				return(GET_ENUM((*flow1), Flow_SubNatEn) -
					GET_ENUM((*flow2), Flow_SubNatEn));
	}
	else
		return(diff);	
}

/************************************************************************
**      END  finlib03.c
*************************************************************************/

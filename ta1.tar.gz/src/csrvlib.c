/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define CSRVLIB_C

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#include "unidef.h"     /* Mandatory */
#include "dba.h"
#include "gen.h"
#include "conv.h"
#include "csrv.h"
#include "proc.h"
#include "hier.h"
#include "hierdecl.h"
#include "fin.h"        /* REF deoup 001218 */
#include "scelib.h"		/* REF1100 */
#include "dbi.h"
#include "conprovider.h"
#include "conexcept.h"

#if ((defined AAAPURIFY) || (defined AAAQUANTIFY)) && (defined NT)
#ifdef __cplusplus /* REF8728 - DLA */
extern "C" {
#endif
#pragma warning(disable:4390)
#include <pure_api.c>
#ifdef __cplusplus /* REF8728 - DLA */
}
#endif

#endif

extern ApplSessionHelper *EV_AdminApplSessionHelper;

/************************************************************************
**      Static definitions & data
*************************************************************************/

/* REF8844 - LJE - 030327 : For new MD */

FIELD_IDX_T A_ApplUser_FixFldNbr      = 38; /* PMSTA-11505 - LJE - 110614 */
FIELD_IDX_T A_ApplUser_NoMDFldNbr     = 6;
FIELD_IDX_T S_ApplUser_FixFldNbr      = 10; /* PMSTA-14881 - LJE - 120927 */
FIELD_IDX_T S_ApplUser_NoMDFldNbr     = 2;
FIELD_IDX_T S_ServConnect_FixFldNbr   = 11; /* REF11767 - CHU - 060403 */
FIELD_IDX_T S_ServConnect_NoMDFldNbr  = 0;
FIELD_IDX_T A_ServConnect_FixFldNbr   = 12; /* REF11767 - CHU - 060403 */
FIELD_IDX_T A_ServConnect_NoMDFldNbr  = 1;
FIELD_IDX_T Io_Id_FixFldNbr           = 1;
FIELD_IDX_T Io_Id_NoMDFldNbr          = 1;
FIELD_IDX_T Io_Ext_FixFldNbr          = 1;  /* PMSTA-34344 - LJE - 200925 */
FIELD_IDX_T Io_Ext_NoMDFldNbr         = 1;  /* PMSTA-34344 - LJE - 200925 */
FIELD_IDX_T A_DictLang_FixFldNbr      = 9; /* PMSTA-11505 - LJE - 110614 */
FIELD_IDX_T A_DictLang_NoMDFldNbr     = 0;
FIELD_IDX_T S_DictLang_FixFldNbr      = 4;
FIELD_IDX_T S_DictLang_NoMDFldNbr     = 1;
FIELD_IDX_T A_TabModifStat_FixFldNbr  = 3; /* PMSTA10087 - DDV - 100729 - Returns milliseconds from table_modif_stat */
FIELD_IDX_T A_TabModifStat_NoMDFldNbr = 1;
FIELD_IDX_T S_TabModifStat_FixFldNbr  = 1;
FIELD_IDX_T S_TabModifStat_NoMDFldNbr = 0;

FIELD_IDX_T A_ApplMsgTxt_FixFldNbr = 5;      /*  FIH-REF10582-050613 */  /*  HFI-PMSTA-28976-180228  chnage 3 to 5   */
FIELD_IDX_T A_ApplMsgTxt_NoMDFldNbr = 0;      /*  FIH-REF10582-050613 */
FIELD_IDX_T ApplMsg_Arg_FixFldNbr = 3;      /*  FIH-REF10582-050613 */
FIELD_IDX_T ApplMsg_Arg_NoMDFldNbr = 3;      /*  FIH-REF10582-050613 */

/************************************************************************
**      STRUCTURE DEFINITION LIST FOR : APPL_USER   951020
*************************************************************************/
static DBA_DYNSTDEF_ST SV_DynStDef_A_ApplUser[] = {
/*      dataType,       dbFlg,  asciiField */ /* REF9954 - TEB - 040224 */
    {IdType,            TRUE,   0},   /* A_ApplUser_Id                */   /* key */
    {SysnameType,       TRUE,   0},   /* A_ApplUser_Cd                */	/* DLA - PMSTA09887 - 101115 */
    {NameType,          TRUE,   0},   /* A_ApplUser_Name              */
    {VarInfoType,       TRUE,   0},   /* A_ApplUser_Denom             */
    {DictType,          TRUE,   0},   /* A_ApplUser_LangDictId     */
    {IdType,            TRUE,   0},   /* A_ApplUser_FctSecuProfId     */
    {IdType,            TRUE,   0},   /* A_ApplUser_LastDomainId      */
    {IdType,            TRUE,   0},   /* A_ApplUser_FmtProfileId         */
    {IdType,            TRUE,   0},   /* A_ApplUser_ReportProfId      */
    {IdType,            TRUE,   0},   /* A_ApplUser_ScreenProfId      */    /* DVP338 - RAK - 970204 */
    {IdType,            TRUE,   0},   /* A_ApplUser_PrinterProfId     */    /* DVP350 - PEC - 970225 */
    {FlagType,          TRUE,   0},   /* A_ApplUser_ActiveFlg         */
    {NameType,          TRUE,   0},   /* A_ApplUser_OsUser            */
    {FlagType,          TRUE,   0},   /* A_ApplUser_SecurityAdminFlg      */
    {FlagType,          TRUE,   0},   /* A_ApplUser_SuperuserFlg      */
    {FlagType,          TRUE,   0},   /* A_ApplUser_AuditFlg          */    /* DVP182 - RAK - 960826 */
    {DatetimeType,      TRUE,   0},   /* A_ApplUser_ValidityDate      */    /* 3.50 - db modif - RAK - 991117 */
    {FlagType,          TRUE,   0},   /* A_ApplUser_GuiUserFlg        */    /* 3.50 - db modif - RAK - 991117 */
    {IntType,           TRUE,   0},   /* A_ApplUser_MaxRunnGui        */    /* 3.50 - db modif - RAK - 991117 */
    {IdType,            TRUE,   0},   /* A_ApplUser_ParentUserId      */    /* 3.51 REF5562 SKE 010119 */
    {IdType,            TRUE,   0},   /* A_ApplUser_DataProfileId        */    /* 3.51 REF5562 SKE 010119 */
    {IdType,            TRUE,   0},   /* A_ApplUser_DataSecuProfId    */    /* 3.51 REF5562 SKE 010119 */
	{FlagType,		    TRUE,   0},	  /* A_ApplUser_WuiUserFlg		  */    /*REF9446-BRO-030929*/
	{IdType,		    TRUE,   0},	  /* A_ApplUser_QuickSearckProfId */    /*  FIH-REF9789-031223  */
	{IdType,            TRUE,   0},   /* A_ApplUser_ManagerId			  */	/*REF9895-BRO-040202*/
	{TextType,			TRUE,	0},	  /* A_ApplUser_GuiContext		  */	/*REF10391-BRO-040716*/
    {IdType,            TRUE,   0},   /* A_ApplUser_FundDataProfId    */	/*PMSTA7419-EFE-090304*/
    {IdType,            TRUE,   0},   /* A_ApplUser_ThirdId           */	/*PMSTA14283-EFE-120529*/
	{FlagType,		    TRUE,   0},	  /* A_ApplUser_HasDBLoginFlg     */    /*PMSTA14283-EFE-120529*/
	{FlagType,		    TRUE,   0},	  /* A_ApplUser_SystemUserFlg     */    /*PMSTA14283-EFE-120529*/
    {IdType,            TRUE,   0},   /* A_ApplUser_DataSecuProf2Id   */    /* PMSTA-14647 - LJE - 120712 */
    {FlagType,          TRUE,   0},   /* A_ApplUser_TascUserFlg       */    /*OCS41068-BRO-130121*/
    {FlagType,          TRUE,   0},   /* A_ApplUser_RemotingUserFlg   */    /*OCS41068-BRO-130121*/
    {FlagType,          TRUE,   0},   /* A_ApplUser_BatchUserFlg      */    /*OCS41068-BRO-130121*/
    {IdType,            TRUE,   0},   /* A_ApplUser_MainBusEntityId   */    /*OCS41068-BRO-130121*/
    {FlagType,          FALSE,  0},   /* A_ApplUser_UpdateRightFlg    */    /* PMSTA-11505 - LJE - 110614 */
    {FlagType,          FALSE,  0},   /* A_ApplUser_DeleteRightFlg    */    /* PMSTA-11505 - LJE - 110614 */
    {InfoType,          FALSE,  0},   /* A_ApplUser_UserPasswd        */    /* MD */
	{EnumType,			FALSE,  0},	  /* A_ApplUser_RoleEn            */
	{DatetimeType,		TRUE,   0},	  /* A_ApplUser_ResetDate         */
    {IdType,            TRUE,   0},   /* A_ApplUser_ChannelProfileId  */
    {IdType,            TRUE,   0},   /* A_ApplUser_ExtServiceProfId  */
    {NoteType,          TRUE,   0 },  /* A_ApplUser_Alias             */
    {FlagType,          FALSE,  0},   /* A_ApplUser_RightToRunFlg     */
    {NameType,          FALSE,  0},   /* A_ApplUser_LangThousSep      */
    {NameType,          FALSE,  0},   /* A_ApplUser_LangDecimSep      */
    {NameType,          FALSE,  0},   /* A_ApplUser_LangDateFmt       */
    {SysnameType,       FALSE,  0},   /* A_ApplUser_SuperUserLogin    */    /* DVP271 */
    {SysnameType,       FALSE,  0},   /* A_ApplUser_SuperUserPasswd   */
	{FlagType,          FALSE,  0},   /* A_ApplUser_LoginActionEn     */    /*PMSTA14283-EFE-120529*/
   	{FlagType,          FALSE,  0},   /* A_ApplUser_LockActionFlg     */    /*PMSTA23374-PCL-240518*/
   	{FlagType,          FALSE,  0},    /* A_ApplUser_ValidityActionFlg */
	{SysnameType,       FALSE,  0}    /* A_ApplUser_CopiedFromUserCode*/
};

static DBA_DYNSTDEF_ST SV_DynStDef_S_ApplUser[] = {
/*      dataType,       dbFlg,  asciiField */ /* REF9954 - TEB - 040224 */
    {IdType,            TRUE,   0},   /* S_ApplUser_Id        */   /* key */
    {SysnameType,       TRUE,   0},   /* S_ApplUser_Cd        */  /* DLA - PMSTA09887 - 101115 */
    {NameType,          TRUE,   0},   /* S_ApplUser_Name      */
    {DictType,          TRUE,   0},   /* S_ApplUser_LangEntDictId     */
    {IdType,            TRUE,   0},   /* S_ApplUser_ParentUserId */             /* 3.51 REF5562 SKE 010119 */
    {CodeType,          TRUE,   0},   /* S_ApplUser_ParentUserCd */             /* 3.51 REF5562 SKE 010119 */
    {FlagType,          TRUE,   0},   /* S_ApplUser_HasDbLoginFlg */ /* PMSTA-14881 - LJE - 120927 */
    {FlagType,          TRUE,   0},   /* S_ApplUser_ActiveFlg */ /* PMSTA-14881 - LJE - 120927 */
    {FlagType,          TRUE,   0},   /* S_ApplUser_AuthUpdFlg      */          /* 3.51 REF5562 SKE 010119 */
    {FlagType,          TRUE,   0}    /* S_ApplUser_AuthDelFlg      */          /* 3.51 REF5562 SKE 010119 */

};

/************************************************************************
**      PROCEDURES AND PARAMETERS LIST FOR : APPL_USER
*************************************************************************/
static DBA_PROCPARAM_ST SV_ProcParamDef_ApplUser4[] = {         /* get all appl_user by code */
	{&A_ApplUser_Cd,             "@code",   TRUE},
	{UNUSED,                    "",        UNUSED}
};

static DBA_PROC_ST SV_ProcTab_ApplUser[] = {
{SqlServer,    Synchronous, Get,        UNUSED,                 &A_ApplUser, &S_ApplUser, 1      , "get_sh_appl_user_by_cd",    NOFCT, SV_ProcParamDef_ApplUser4, NullOpti, NULL, 0, NULL /* eoparam */},
{SqlServer,    Synchronous, NullAction, UNUSED,                 &NullDynSt,  &NullDynSt ,  UNUSED, ""                      ,    NOFCT, UNUSED                   , NullOpti, NULL, 0, NULL /* eoparam */}
};

/************************************************************************
**    STRUCTURE DEFINITION LIST FOR : IO_ID
*************************************************************************/
static DBA_DYNSTDEF_ST SV_DynStDef_Io_Id[]= {
/*      dataType,          dbFlg,  asciiField */ /* REF9954 - TEB - 040224 */
    {IdType,               TRUE,   0} /* Io_Id_Id        */
};

/************************************************************************
**    STRUCTURE DEFINITION LIST FOR : IO_EXT
*************************************************************************/
static DBA_DYNSTDEF_ST SV_DynStDef_Io_Ext[] = {
    /*      dataType,          dbFlg,  asciiField */
    {ExtensionType,               TRUE,   0} /* Io_Ext_Ext        */
};

/************************************************************************
**    STRUCTURE DEFINITION LIST FOR : IO_INFO
*************************************************************************/
static DBA_DYNSTDEF_ST SV_DynStDef_Io_Info[] = {
	/*      dataType,          dbFlg,  asciiField */
	{InfoType,               TRUE,   0} /* Io_Info_Info        */
};


/************************************************************************
**      PROCEDURES AND PARAMETERS LIST FOR : EVENT_SCHED
*************************************************************************/
static DBA_PROCPARAM_ST SV_ProcParamDef_EventSched3[] = {         /* unlock fusion_stat */
							       /* delete lock fusion_stat */
    {&Io_Id_Id,                 "@server_id",       TRUE},
	{UNUSED,                    "",                 UNUSED}
};

static DBA_PROC_ST SV_ProcTab_EventSched[] = {
{SqlServer, Synchronous, Notif,      UNUSED,                   &Io_Id,        &NullDynSt,    1,      "unlock_event_sched_by_sid",     NOFCT, SV_ProcParamDef_EventSched3,NullOpti, NULL, 0, NULL /* eoparam */ },
{SqlServer, Synchronous, NullAction, UNUSED,                   &NullDynSt,    &NullDynSt,    UNUSED, "",                              NOFCT, UNUSED,                     NullOpti, NULL, 0, NULL /* eoparam */ }
};

/************************************************************************
**      STRUCTURE DEFINITION LIST FOR : DICT_LANGUAGE       951020
*************************************************************************/
static DBA_DYNSTDEF_ST SV_DynStDef_S_DictLang[] = {
/*  dataType,          dbFlg,  asciiField */ /* REF9954 - TEB - 040224 */
    {DictType,         TRUE,   0},    /* S_DictLang_Id      */   /* key */
    {CodeType,         TRUE,   0},    /* S_DictLang_Cd      */
    {NameType,	       TRUE,   0} ,    /* S_DictLang_Name    */ /* REF8844 - LJE - 030327 */ /* DLA - PMSTA09887 - 101116 */
    { SysnameType, TRUE, 0 },    /* S_DictLang_SqlName    */
    { IdType, FALSE, 0 }    /* S_DictLang_CodifId */
};

/************************************************************************
**      PROCEDURES AND PARAMETERS LIST FOR : DICT_LANGUAGE
*************************************************************************/
static DBA_PROCPARAM_ST SV_ProcParamDef_DictLang1[] = {         /* delete lang */
                                                                /* get all lang by id */
	{&S_DictLang_Id,             "@dict_id",         TRUE},
	{UNUSED,                    "",                 UNUSED}
};

static DBA_PROC_ST SV_ProcTab_DictLang[] = {
{SqlServer, Synchronous, Get,        UNUSED, &S_DictLang, &S_DictLang, 1,      "get_sh_dict_lang_by_id",    NOFCT, SV_ProcParamDef_DictLang1,NullOpti, NULL, 0, NULL /* eoparam */}, /* DVP566 */
{SqlServer, Synchronous, NullAction, UNUSED, &NullDynSt,  &NullDynSt,  UNUSED, "",                           NOFCT, UNUSED,                  NullOpti, NULL, 0, NULL /* eoparam */}
};

/************************************************************************
**      STRUCTURE DEFINITION LIST FOR : TABLE_MODIF_STAT        950208
*************************************************************************/
static DBA_DYNSTDEF_ST SV_DynStDef_A_TabModifStat[] = {
/*  dataType,           dbFlg,  asciiField */ /* REF9954 - TEB - 040224 */
    {IdType,            TRUE,   0},    /* A_TabModifStat_DictId         */ /* key */
    {DatetimeType,      TRUE,   0},    /* A_TabModifStat_LastModifDate  */
    {IntType,           TRUE,   0}     /* A_TabModifStat_LastModifDateMs - PMSTA10087 - DDV - 100729 - Returns milliseconds from table_modif_stat */
};

static DBA_DYNSTDEF_ST SV_DynStDef_S_TabModifStat[] = {
/*  dataType,           dbFlg,  asciiField */ /* REF9954 - TEB - 040224 */
    {IdType,            TRUE,   0}     /* S_TabModifStat_DictId     */  /* key */
};

/************************************************************************
**      PROCEDURES AND PARAMETERS LIST FOR : TABLE_MODIF_STAT     950208
*************************************************************************/
static DBA_PROC_ST SV_ProcTab_TabModifStat[] = {
{SqlServer, Synchronous, Select,     UNUSED, &NullDynSt,      &A_TabModifStat, 1,      "sel_all_table_modif_stat",        NOFCT, UNUSED,    NullOpti, NULL, 0, NULL /* eoparam */},
{SqlServer, Synchronous, Select,     UNUSED, &NullDynSt,      &S_TabModifStat, 1,      "sel_sh_table_modif_stat",        NOFCT, UNUSED,     NullOpti, NULL, 0, NULL /* eoparam */},
{SqlServer, Synchronous, NullAction, UNUSED, &NullDynSt,      &NullDynSt,      UNUSED, "",                               NOFCT, UNUSED,     NullOpti, NULL, 0, NULL /* eoparam */}
};

/***********************************************************************************
**      STRUCTURE DEFINITION LIST FOR : APPL_MSG_ARG            FIH-REF10582-050613
************************************************************************************/
static DBA_DYNSTDEF_ST SV_DynStDef_ApplMsg_Arg[] = {
    {CodeType,          FALSE,  0},     /*  ApplMsg_Arg_Cd          */
    {DictType,          FALSE,  0},     /*  ApplMsg_Arg_LangDictId  */
    {EnumType,          FALSE,  0}      /*  ApplMsg_Arg_NatEn       */
};

/***********************************************************************************
**      STRUCTURE DEFINITION LIST FOR : APPL_MSG_TEXT           FIH-REF10582-050613
************************************************************************************/
static DBA_DYNSTDEF_ST SV_DynStDef_A_ApplMsgTxt[] = {
    {IdType,            TRUE,  0},     /*  A_ApplMsgTxt_MsgId       */
    {DictType,          TRUE,  0},     /*  A_ApplMsgTxt_LangDictId  */
	{NoteType,          TRUE,  0},     /*  A_ApplMsgTxt_MsgTxt      */
    {DatetimeType,      TRUE,  0},     /*  A_ApplMsgTxt_LastModifDate   */  /*  HFI-PMSTA-28976-180228  */
    {IdType,            TRUE,  0}      /*  A_ApplMsgTxt_LastUserId      */  /*  HFI-PMSTA-28976-180228  */
};

/***********************************************************************************
**      PROCEDURES AND PARAMETERS LIST FOR : APPL_MSG_TEXT      FIH-REF10582-050613
************************************************************************************/
static DBA_PROCPARAM_ST SV_ProcParamDef_ApplMsgTxt4[] = {       /* get all appl_msg_text */
	{&ApplMsg_Arg_Cd,            "@message_code",      TRUE},
	{&ApplMsg_Arg_NatEn,         "@message_nature_e",  TRUE},
	{&ApplMsg_Arg_LangDictId,    "@language_dict_id",  TRUE},
	{UNUSED,                    "",                   UNUSED}
};

static DBA_PROC_ST SV_ProcTab_ApplMsgTxt[] = {
{SqlServer, Synchronous, Get,        UNUSED, &ApplMsg_Arg,    &A_ApplMsgTxt,   1,      "get_all_appl_msg_text_by_cd_nt", NOFCT, SV_ProcParamDef_ApplMsgTxt4, NullOpti, NULL, 0, NULL /* eoparam */},
{SqlServer, Synchronous, NullAction, UNUSED, &NullDynSt,      &NullDynSt,      UNUSED, "",                               NOFCT, UNUSED,                      NullOpti, NULL, 0, NULL /* eoparam */}
};


const FIELD_IDX_T SqlRequest_FixFldNbr           = 7;
const FIELD_IDX_T SqlRequestParam_FixFldNbr      = 5;
const FIELD_IDX_T SqlRequestResultSet_FixFldNbr  = 3;
const FIELD_IDX_T SqlRequestOutputDef_FixFldNbr  = 2;

static DBA_DYNSTDEF_ST SV_DynStDef_SqlRequest[] = {
    {SysnameType,     TRUE, FALSE, false, false, false, false, 0, 0,  SubFeature::None, 0, nullptr, "proc_sqlname"},         /* SqlRequest_ProcSqlName */
    {TextType,        TRUE, FALSE, false, false, false, false, 0, 0,  SubFeature::None, 0, nullptr, "sql_cmd"},                 /* SqlRequest_SqlCmd */
    {FlagType,        TRUE, FALSE, false, false, false, false, 0, 0,  SubFeature::None, 0, nullptr, "read_only_f"},             /* SqlRequest_ReadOnly */
    {ExtensionType,   TRUE, FALSE, false, false, false, false, 3, 5,  SubFeature::None, 0, nullptr, "parameters"},         /* SqlRequest_Parameters */
    {ExtensionType,   TRUE, FALSE, false, false, false, false, 4, 6,  SubFeature::None, 0, nullptr, "result_set"},         /* SqlRequest_ResultSet */
    {ChainedTypeType, FALSE, FALSE, false, false, false, false, 0, 0, SubFeature::None, 0, nullptr, "info_01"},         /* SqlRequest_Parameters */
    {ChainedTypeType, FALSE, FALSE, false, false, false, false, 0, 0, SubFeature::None, 0, nullptr, "info_02"}          /* SqlRequest_ResultSet */
};
static_assert((SqlRequest_FixFldNbr == sizeof(SV_DynStDef_SqlRequest) / sizeof(DBA_DYNSTDEF_ST)), "Wrong SqlRequest_FixFldNbr definition");

static DBA_DYNSTDEF_ST SV_DynStDef_SqlRequestParam[] = {
    {SysnameType, TRUE, FALSE, false, false, false, false, 0, 0, SubFeature::None, 0, nullptr, "sqlname_c"},  /* SqlRequestParam_SqlName */
    {EnumType,    TRUE, FALSE, false, false, false, false, 0, 0, SubFeature::None, 0, nullptr, "datatype_e"}, /* SqlRequestParam_DataType */
    {TextType,    TRUE, FALSE, false, false, false, false, 0, 0, SubFeature::None, 0, nullptr, "value"},      /* SqlRequestParam_Value */
    {FlagType,    TRUE, FALSE, false, false, false, false, 0, 0, SubFeature::None, 0, nullptr, "input_f"},    /* SqlRequestParam_InputFlg */
    {FlagType,    TRUE, FALSE, false, false, false, false, 0, 0, SubFeature::None, 0, nullptr, "output_f"}    /* SqlRequestParam_OutputFlg */
};
static_assert((SqlRequestParam_FixFldNbr == sizeof(SV_DynStDef_SqlRequestParam) / sizeof(DBA_DYNSTDEF_ST)), "Wrong SqlRequestParam_FixFldNbr definition");

static DBA_DYNSTDEF_ST SV_DynStDef_SqlRequestResultSet[] = {
    {SysnameType ,    TRUE, FALSE, false, false, false, false, 0, 1,  SubFeature::None, 0, nullptr, "dynst"},     /* SqlRequestResultSet_DynSt */
    {ExtensionType,   TRUE, FALSE, false, false, false, false, 1, 2,  SubFeature::None, 0, nullptr, "items"},       /* SqlRequestResultSet_Items */
    {ChainedTypeType, FALSE, FALSE, false, false, false, false, 0, 0, SubFeature::None, 0, nullptr, "info_01"}     /* SqlRequestResultSet_Items */
};
static_assert((SqlRequestResultSet_FixFldNbr == sizeof(SV_DynStDef_SqlRequestResultSet) / sizeof(DBA_DYNSTDEF_ST)), "Wrong SqlRequestResultSet_FixFldNbr definition");

static DBA_DYNSTDEF_ST SV_DynStDef_SqlRequestOutputDef[] = {
    {SysnameType, TRUE, FALSE, false, false, false, false, 0, 0, SubFeature::None, 0, nullptr, "sqlname_c"},  /* SqlRequestOutputDef_SqlName */
    {EnumType,    TRUE, FALSE, false, false, false, false, 0, 0, SubFeature::None, 0, nullptr, "datatype_e"} /* SqlRequestOutputDef_DataType */
};
static_assert((SqlRequestOutputDef_FixFldNbr == sizeof(SV_DynStDef_SqlRequestOutputDef) / sizeof(DBA_DYNSTDEF_ST)), "Wrong SqlRequestOutputDef_FixFldNbr definition");

DBA_DYNDEF_ST SV_DynDefInitStTab[] = {
    {NullEntity                    , SqlRequest                    , "SqlRequest"                    , DynType_Other},
    {NullEntity                    , SqlRequestParam               , "SqlRequestParam"               , DynType_Other},
    {NullEntity                    , SqlRequestResultSet           , "SqlRequestResultSet"           , DynType_Other},
    {NullEntity                    , SqlRequestOutputDef           , "SqlRequestOutputDef"           , DynType_Other},
    {NullEntity                    , SqlRequestOutputParam         , "SqlRequestOutputParam"           , DynType_Other}
};

/* REF8844 - LJE - 030327 */
STATIC void MAIN_CreateLocalDynSt();


/************************************************************************
*   Function             : CSRV_Init()
*
*   Description          : Initialize different pointers and informations
*                          either for GUI process or Server process.
*
*   Arguments            : installMemoryCallBack    If Sybase memory callback must be installed
*
*   Return               :
*
*   Creation date        : Sept. 94 - PEC
*
*   Last Modification    : PMSTA-18094 - 130514 - PMO : Avoid extracting the user credentials from the GUI running on Windows (via dump, etc.)
*
*************************************************************************/
int CSRV_Init(const bool installMemoryCallBack)                     /* PMSTA-18094 - 130514 - PMO */
{
    EV_AdminApplSessionHelper = new ApplSessionHelper(true);    /* PMSTA-34344 - LJE - 210216 - Move here */

    DBA_InitDataTypePtr();
    CONV_InitConvFmtPtr();

    MAIN_CreateLocalDynSt();

	return(DBI_InitializeContext(installMemoryCallBack)); /* DLA - REF8960 - 030917 */
}

/************************************************************************
*   Function             : CSRV_Init2()
*
*   Description          : Initialize different pointers and informations
*                          either for GUI process or Server process.
*                          second phase
*
*   Arguments            : None
*
*   Return               :
*
*   Creation date        : REF8844 - LJE - 030404
*   Last Modification    : PMSTA-15031 - 210912 - PMO : Order Entry : order grouping on one order results in an application fatal error
*
*************************************************************************/
void CSRV_Init2()
{
    FREE(EV_DynStPtr);
    FREE(EV_EntityGuiStPtr);
    EV_EntityGuiStNb  = 0;          /* PMSTA-15031 - 210912 - PMO */
}

/************************************************************************
*   Function             : CSRV_Init3()
*
*   Description          : Initialize different pointers and informations
*                          either for GUI process or Server process.
*                          third phase
*
*   Arguments            : None
*
*   Return               :
*
*   Creation date        : REF8844 - LJE - 030404
*   Last Modification    :
*************************************************************************/
void CSRV_Init3()
{
    DBA_InitProcLstPtr();
    DBA_InitHierDefPtr();
    CONV_InitDefaultMaxPrecision(); /* PMSTA-36302 - DDV - 190624 - Make 6 digits amount optional */
    SCE_InitSceMsgPtr();
}

/************************************************************************
**
**  Function    :   MAIN_CreateLocalDynSt()
**
**  Description :
**
**  Arguments   :
**
**
**  Return      :   RET_SUCCEED or error code
**                  REF8844 - LJE - 030327
**                  PMSTA-15031 - 210912 - PMO : Order Entry : order grouping on one order results in an application fatal error
**
*************************************************************************/
STATIC void MAIN_CreateLocalDynSt()
{
    const int nbrTempDynSt=14, nbrTempObj=5;

    AaaMetaDict::allocObjProcLstPtr(nbrTempObj);

    ApplUser     = 0;
    AaaMetaDict::setObjProcLstStp(ApplUser, SV_ProcTab_ApplUser);
    EventSched   = 1;
    AaaMetaDict::setObjProcLstStp(EventSched, SV_ProcTab_EventSched);
    DictLang     = 2;
    AaaMetaDict::setObjProcLstStp(DictLang, SV_ProcTab_DictLang);
    TabModifStat = 3;
    AaaMetaDict::setObjProcLstStp(TabModifStat, SV_ProcTab_TabModifStat);
    ApplMsgTxt   = 4;
    AaaMetaDict::setObjProcLstStp(ApplMsgTxt, SV_ProcTab_ApplMsgTxt);

    EV_DynStPtr = (DBA_DYNST_STP)CALLOC(nbrTempDynSt, sizeof(DBA_DYNST_ST));

    LASTDYNST                                                      = 0;
    S_ApplUser                                                     = LASTDYNST++;
    EV_DynStPtr[S_ApplUser].fldNbr                                 = S_ApplUser_FixFldNbr;
    EV_DynStPtr[S_ApplUser].noMDFldNbr                             = S_ApplUser_NoMDFldNbr;
    EV_DynStPtr[S_ApplUser].custFldNbr                             = 0;
    EV_DynStPtr[S_ApplUser].entity                                 = ApplUser;
    EV_DynStPtr[S_ApplUser].dynStDefPtr                            = SV_DynStDef_S_ApplUser;

    A_ApplUser                                                     = LASTDYNST++;
    EV_DynStPtr[A_ApplUser].fldNbr                                 = A_ApplUser_FixFldNbr;
    EV_DynStPtr[A_ApplUser].noMDFldNbr                             = A_ApplUser_NoMDFldNbr;
    EV_DynStPtr[A_ApplUser].custFldNbr                             = 0;
    EV_DynStPtr[A_ApplUser].entity                                 = ApplUser;
    EV_DynStPtr[A_ApplUser].dynStDefPtr                            = SV_DynStDef_A_ApplUser;

    EV_DynStPtr[A_ApplUser].dynStDefPtr[A_ApplUser_Denom].dataType = InfoType; /* REF9303 - LJE - 030904 */

    Io_Id                                                          = LASTDYNST++;
    EV_DynStPtr[Io_Id].fldNbr                                      = Io_Id_FixFldNbr;
    EV_DynStPtr[Io_Id].noMDFldNbr                                  = Io_Id_NoMDFldNbr;
    EV_DynStPtr[Io_Id].custFldNbr                                  = 0;
    EV_DynStPtr[Io_Id].entity                                      = NullEntity;
    EV_DynStPtr[Io_Id].dynStDefPtr                                 = SV_DynStDef_Io_Id;


	/* PMSTA12693-EFE-111031 : replaced A_DictLanguage by S_DictLanguage */
	S_DictLang                                                     = LASTDYNST++;
    EV_DynStPtr[S_DictLang].fldNbr                                 = S_DictLang_FixFldNbr;
    EV_DynStPtr[S_DictLang].noMDFldNbr                             = S_DictLang_NoMDFldNbr;
    EV_DynStPtr[S_DictLang].custFldNbr                             = 0;
    EV_DynStPtr[S_DictLang].entity                                 = DictLang;
    EV_DynStPtr[S_DictLang].dynStDefPtr                            = SV_DynStDef_S_DictLang;

    A_TabModifStat                                                 = LASTDYNST++;
    EV_DynStPtr[A_TabModifStat].fldNbr                             = A_TabModifStat_FixFldNbr;
    EV_DynStPtr[A_TabModifStat].noMDFldNbr                         = A_TabModifStat_NoMDFldNbr;
    EV_DynStPtr[A_TabModifStat].custFldNbr                         = 0;
    EV_DynStPtr[A_TabModifStat].entity                             = TabModifStat;
    EV_DynStPtr[A_TabModifStat].dynStDefPtr                        = SV_DynStDef_A_TabModifStat;

    S_TabModifStat                                                 = LASTDYNST++;
    EV_DynStPtr[S_TabModifStat].fldNbr                             = S_TabModifStat_FixFldNbr;
    EV_DynStPtr[S_TabModifStat].noMDFldNbr                         = S_TabModifStat_NoMDFldNbr;
    EV_DynStPtr[S_TabModifStat].custFldNbr                         = 0;
    EV_DynStPtr[S_TabModifStat].entity                             = TabModifStat;
    EV_DynStPtr[S_TabModifStat].dynStDefPtr                        = SV_DynStDef_S_TabModifStat;

    A_ApplMsgTxt                                                   = LASTDYNST++;                                                            /*  FIH-REF10582-050613 */
    EV_DynStPtr[A_ApplMsgTxt].fldNbr                               = A_ApplMsgTxt_FixFldNbr;
    EV_DynStPtr[A_ApplMsgTxt].noMDFldNbr                           = A_ApplMsgTxt_NoMDFldNbr;
    EV_DynStPtr[A_ApplMsgTxt].custFldNbr                           = 0;
    EV_DynStPtr[A_ApplMsgTxt].entity                               = ApplMsgTxt;
    EV_DynStPtr[A_ApplMsgTxt].dynStDefPtr                          = SV_DynStDef_A_ApplMsgTxt;

    ApplMsg_Arg                                                    = LASTDYNST++;                                                             /*  FIH-REF10582-050613 */
    EV_DynStPtr[ApplMsg_Arg].fldNbr                                = ApplMsg_Arg_FixFldNbr;
    EV_DynStPtr[ApplMsg_Arg].noMDFldNbr                            = ApplMsg_Arg_NoMDFldNbr;
    EV_DynStPtr[ApplMsg_Arg].custFldNbr                            = 0;
    EV_DynStPtr[ApplMsg_Arg].entity                                = 0;
    EV_DynStPtr[ApplMsg_Arg].dynStDefPtr                           = SV_DynStDef_ApplMsg_Arg;

    /* PMSTA-34344 - LJE - 200918 */
    Io_Ext                          = LASTDYNST++;
    EV_DynStPtr[Io_Ext].fldNbr      = Io_Ext_FixFldNbr;
    EV_DynStPtr[Io_Ext].noMDFldNbr  = Io_Ext_NoMDFldNbr;
    EV_DynStPtr[Io_Ext].custFldNbr  = 0;
    EV_DynStPtr[Io_Ext].entity      = NullEntity;
    EV_DynStPtr[Io_Ext].dynStDefPtr = SV_DynStDef_Io_Ext;

    SqlRequest                          = LASTDYNST++;
    EV_DynStPtr[SqlRequest].fldNbr      = SqlRequest_FixFldNbr;
    EV_DynStPtr[SqlRequest].noMDFldNbr  = SqlRequest_FixFldNbr;
    EV_DynStPtr[SqlRequest].custFldNbr  = 0;
    EV_DynStPtr[SqlRequest].entity      = 0;
    EV_DynStPtr[SqlRequest].dynStDefPtr = SV_DynStDef_SqlRequest;
    EV_DynStPtr[SqlRequest].dynTypeEnum = DynType_Other;

    EV_DynStPtr[SqlRequest].dynDefPtr   = &(SV_DynDefInitStTab[0]);

    SqlRequestParam                          = LASTDYNST++;
    EV_DynStPtr[SqlRequestParam].fldNbr      = SqlRequestParam_FixFldNbr;
    EV_DynStPtr[SqlRequestParam].noMDFldNbr  = SqlRequestParam_FixFldNbr;
    EV_DynStPtr[SqlRequestParam].custFldNbr  = 0;
    EV_DynStPtr[SqlRequestParam].entity      = 0;
    EV_DynStPtr[SqlRequestParam].dynStDefPtr = SV_DynStDef_SqlRequestParam;
    EV_DynStPtr[SqlRequestParam].dynTypeEnum = DynType_Other;

    EV_DynStPtr[SqlRequestParam].dynDefPtr = &(SV_DynDefInitStTab[1]);

    SqlRequestResultSet = LASTDYNST++;
    EV_DynStPtr[SqlRequestResultSet].fldNbr      = SqlRequestResultSet_FixFldNbr;
    EV_DynStPtr[SqlRequestResultSet].noMDFldNbr  = SqlRequestResultSet_FixFldNbr;
    EV_DynStPtr[SqlRequestResultSet].custFldNbr  = 0;
    EV_DynStPtr[SqlRequestResultSet].entity      = 0;
    EV_DynStPtr[SqlRequestResultSet].dynStDefPtr = SV_DynStDef_SqlRequestResultSet;
    EV_DynStPtr[SqlRequestResultSet].dynTypeEnum = DynType_Other;

    EV_DynStPtr[SqlRequestResultSet].dynDefPtr = &(SV_DynDefInitStTab[2]);

    SqlRequestOutputDef = LASTDYNST++;
    EV_DynStPtr[SqlRequestOutputDef].fldNbr      = SqlRequestOutputDef_FixFldNbr;
    EV_DynStPtr[SqlRequestOutputDef].noMDFldNbr  = SqlRequestOutputDef_FixFldNbr;
    EV_DynStPtr[SqlRequestOutputDef].custFldNbr  = 0;
    EV_DynStPtr[SqlRequestOutputDef].entity      = 0;
    EV_DynStPtr[SqlRequestOutputDef].dynStDefPtr = SV_DynStDef_SqlRequestOutputDef;
    EV_DynStPtr[SqlRequestOutputDef].dynTypeEnum = DynType_Other;

    EV_DynStPtr[SqlRequestOutputDef].dynDefPtr = &(SV_DynDefInitStTab[3]);

    EV_DynStPtr[LASTDYNST].fldNbr      = 0;
    EV_DynStPtr[LASTDYNST].noMDFldNbr  = 0;
    EV_DynStPtr[LASTDYNST].custFldNbr  = 0;
    EV_DynStPtr[LASTDYNST].entity      = 0;
    EV_DynStPtr[LASTDYNST].dynStDefPtr = nullptr;
    EV_DynStPtr[LASTDYNST].dynTypeEnum = DynType_Other;
    EV_DynStPtr[LASTDYNST].dynDefPtr = &(SV_DynDefInitStTab[4]);
    EV_DynStPtr[LASTDYNST].dynDefPtr->dynStPos = LASTDYNST;
    AaaMetaDict::getDynStByNameMap().insert(std::make_pair(EV_DynStPtr[LASTDYNST].dynDefPtr->dynStName, LASTDYNST));
    SqlRequestOutputParam = LASTDYNST++;

    assert(nbrTempDynSt== LASTDYNST);

    for (short j = 0; j < SqlRequest; j++)
    {
        for (short i=0; i<EV_DynStPtr[j].fldNbr; i++)
        {
            EV_DynStPtr[j].dynStDefPtr[i].asciiField     = i;
            EV_DynStPtr[j].dynStDefPtr[i].anonymizeItem  = 0;
            EV_DynStPtr[j].dynStDefPtr[i].anonymizeSubst = NULL;
            EV_DynStPtr[j].dynStDefPtr[i].infoField      = Null_Dynfld; /* PMSTA-Memory - LJE - 181203 */
            EV_DynStPtr[j].dynStDefPtr[i].defLinkDynStEn = NullDynSt;    /* PMSTA-34344 - LJE - 200923 */
        }
    }

    /* PMSTA-34344 - LJE - 200923 */
    EV_DynStPtr[SqlRequest].dynStDefPtr[SqlRequest_Parameters].defLinkDynStEn              = SqlRequestParam;
    EV_DynStPtr[SqlRequest].dynStDefPtr[SqlRequest_ResultSet].defLinkDynStEn               = SqlRequestResultSet;
    EV_DynStPtr[SqlRequestResultSet].dynStDefPtr[SqlRequestResultSet_Items].defLinkDynStEn = SqlRequestOutputDef;


    EV_EntityGuiStPtr = (DBA_GUIDYNST_STP)CALLOC(nbrTempObj, sizeof(DBA_GUIDYNST_ST));
    EV_EntityGuiStNb  = nbrTempObj;                                             /* PMSTA-15031 - 210912 - PMO */

    EV_EntityGuiStPtr[ApplUser].edit      = A_ApplUser;
    EV_EntityGuiStPtr[ApplUser].admin     = S_ApplUser;
    EV_EntityGuiStPtr[EventSched].edit    = A_EventSched;
    EV_EntityGuiStPtr[EventSched].admin   = S_EventSched;
    EV_EntityGuiStPtr[DictLang].edit      = A_DictLang;
    EV_EntityGuiStPtr[DictLang].admin     = S_DictLang;
    EV_EntityGuiStPtr[TabModifStat].edit  = A_TabModifStat;
    EV_EntityGuiStPtr[TabModifStat].admin = S_TabModifStat;
    EV_EntityGuiStPtr[ApplMsgTxt].edit    = A_ApplMsgTxt;                           /*  FIH-REF10582-050613 */
}

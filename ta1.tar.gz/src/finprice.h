/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef FINPRICE_H
#define FINPRICE_H

/************************************************************************
**      BEGIN : Global variables & external definitions attached to finprice.c
*************************************************************************/
#ifdef  EXTERN
#undef  EXTERN
#endif
#ifdef  FINPRICE_C
#define	EXTERN
#else
#define EXTERN extern
#endif

EXTERN RET_CODE FIN_InstrOrUnderlyLife(char, DBA_DYNFLD_STP, DATETIME_T, FIN_LIFE_STP, DBA_HIER_HEAD_STP),
                FIN_InstrPrice(ID_T, DBA_DYNFLD_STP, DATETIME_T,
			       DBA_DYNFLD_STP, ID_T, FIN_PRICEARG_STP, DBA_DYNFLD_STP, 
                               DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, FLAG_T), /* PMSTA14876 - DDV - 120911 - Add a new parameter to exclude ajusted price for theoritical computation (DURA, MDURA, YTM . . .) */
		FIN_ForwardTheoPrice(DBA_DYNFLD_STP, DATETIME_T, FIN_PRICEARG_STP, DBA_DYNFLD_STP,
				 DBA_DYNFLD_STP, DBA_HIER_HEAD_STP),	/* REF495 - RAK - 980519 */
                FIN_PosPrice(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DATETIME_T, 
                             FIN_PRICEARG_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_HIER_HEAD_STP), /* REF3030 */
		FIN_PriceToQuote(PRICECALCRULE_ENUM, ID_T, DBA_DYNFLD_STP, 
				 DATETIME_T, FIN_PRICEARG_STP, PRICE_T, PRICE_T*, 
				 DBA_HIER_HEAD_STP),
		FIN_QuoteToPrice(PRICECALCRULE_ENUM, ID_T, DBA_DYNFLD_STP, 
				 DATETIME_T, FIN_PRICEARG_STP, PRICE_T, PRICE_T*,
				 DBA_HIER_HEAD_STP),
		FIN_RatePrice(ID_T, DATETIME_T, DBA_DYNFLD_STP, DBA_HIER_HEAD_STP),
        FIN_LoadValRuleAndHist(ID_T, DATETIME_T, DBA_DYNFLD_STP, FLAG_T *,
                               DBA_DYNFLD_STP *, DBA_DYNFLD_STP	*),
        FIN_LoadValRuleElt(DBA_DYNFLD_STP, int*, DBA_DYNFLD_STP**),
        FIN_GetValRuleIdInDomPPSPtf(DBA_DYNFLD_STP, DBA_DYNFLD_STP, 
                                    DBA_HIER_HEAD_STP, ID_T*),
		FIN_DefaultInstrPrice(DBA_DYNFLD_STP, DATETIME_T, FLAG_T,		/* PMSTA06487 - RAK - 080529 */
							  DBA_DYNFLD_STP, FIN_PRICEARG_STP, DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, FLAG_T); /* PMSTA14876 - DDV - 120911 - Add a new parameter to exclude ajusted price for theoritical computation (DURA, MDURA, YTM . . .) */

/* REF5586 - RAK - 010207 */
EXTERN void FIN_GetAdAMInfoForInstr(DBA_DYNFLD_STP, ID_T*,FLAG_T*, FLAG_T*);    /* REF5306 - RAK - 010208 */

#endif /* FINPRICE_H */

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef DDLGENCFGFILE_H
#define DDLGENCFGFILE_H

#include <string>
#include <fstream>

#include <map>
#include "unidef.h"     /* Mandatory */
#include "ddlgenmsg.h"

/************************************************************************
**      Constant & Macro definitions
*************************************************************************/

/************************************************************************
**      Structures & typedef definitions
*************************************************************************/

/************************************************************************
**      External definitions attached to : ddlgencfgfile.cpp
*************************************************************************/
typedef enum
{
    CfgTemplate_Unknown = 0,
    CfgTemplate_Security,
    CfgTemplate_Standard,
    CfgTemplate_ChangeSet,
    CfgTemplate_Shadow,
    CfgTemplate_Upgrade,
    CfgTemplate_TempTable
} CFG_TEMPLATE_ENUM;

typedef enum
{
    CfgFileType_NoFile,
    CfgFileType_Properties,
    CfgFileType_InstallCfg,
    CfgFileType_Template,
    CfgFileType_Upgrade,
    CfgFileType_Label,
    CfgFileType_ControlFile
} CFG_FILE_TYPE_ENUM;

typedef struct CFG_DB_SECTION
{
    std::string dbFct;
    std::string dbSqlName;
    DICT_T      dbDictId;

    CFG_DB_SECTION()
        : dbDictId(0)
    { }
} CFG_DB_SECTION_ST, *CFG_DB_SECTION_STP;

typedef struct CFG_SEG_SECTION
{
    DICT_T      segDictId;
    std::string segFct;
    std::string segSqlName;
    std::string dbFct;
    DICT_T      dbDictId;
    std::string dbSqlName;

    CFG_SEG_SECTION()
        : segDictId(0)
        , dbDictId(0)
    { }
} CFG_SEG_SECTION_ST, *CFG_SEG_SECTION_STP;

typedef struct CFG_TSL_SECTION
{
    std::string objectPos;
    std::string dbFct;
    std::string tbSeg;
    std::string idxSeg;
} CFG_TSL_SECTION_ST, *CFG_TSL_SECTION_STP;

typedef struct CFG_USER_SECTION
{
    std::string userName;
    std::string defaultDb;
    std::string cliMachine;
    bool        bApplOwner;
    std::string serverName;
    std::string group;
    bool       bTechnical;

    CFG_USER_SECTION()
        : bApplOwner(false)
        , bTechnical(false)
    { }
} CFG_USER_SECTION_ST, *CFG_USER_SECTION_STP;

typedef struct CFG_OBJECT_SECTION
{
    std::string       objectName;
    std::string       dbFct;
    std::string       tbSeg;
    std::string       idxSeg;
    FEATURE_AUTH_ENUM auditAuthEn;
    int               objectDefPos;

    CFG_OBJECT_SECTION()
        : auditAuthEn(FeatureAuth_Invalid)
        , objectDefPos(-1)
    { }
} CFG_OBJECT_SECTION_ST, *CFG_OBJECT_SECTION_STP;

typedef struct CFG_MESI_SECTION
{
    std::string beCode;
    std::string beShortName;
    ID_T        beId;
    std::string beIdStr;

    CFG_MESI_SECTION()
        : beId(0)
    { }
} CFG_MESI_SECTION_ST, *CFG_MESI_SECTION_STP;

typedef struct CFG_OPTION_SECTION
{
    std::string fileName;
    std::string apply;

    CFG_OPTION_SECTION()
    {
    }
} CFG_OPTION_SECTION_ST, * CFG_OPTION_SECTION_STP;

typedef struct CFG_PROFILE_SECTION
{
    std::string group;
    std::string profile;
    std::string defaultTablespace;
    std::string temporaryTablespace;

    CFG_PROFILE_SECTION()
    {
    }
} CFG_PROFILE_SECTION_ST, * CFG_PROFILE_SECTION_STP;

class DdlGenLabel
{
public:
    DdlGenLabel(DICT_T              languageDictId,
                XdLabelNatEn        natureEn,
                const std::string  &key,
                const std::string  &label);

    DdlGenLabel(const DdlGenLabel &ref)
        : DdlGenLabel(ref.m_languageDictId, ref.m_natureEn, ref.m_key, ref.m_label)
    {
    }

    virtual ~DdlGenLabel();

    DdlGenLabel &operator= (const DdlGenLabel &) = delete;
    bool operator== (const DdlGenLabel &) const = delete;
    bool operator< (const DdlGenLabel &) const = delete;

    DICT_T          m_languageDictId;
    XdLabelNatEn    m_natureEn;
    std::string     m_key;
    std::string     m_label;
    UChar          *m_uniLabel;
    char           *m_isoLabel;
};

class DdlGenObj
{
public:

    DdlGenObj();

    DdlGenObj(const DdlGenObj&);

    DICT_T entityDictId;
    DICT_T objectDictId;

    bool operator== (const DdlGenObj &toTest) const;
    bool operator< (const DdlGenObj &toTest) const;
};

class DdlGenCfgTemplateKey
{
public:
    DdlGenCfgTemplateKey(CFG_TEMPLATE_ENUM          feature,
                         DBA_RDBMS_ENUM             rdbms,
                         int                        version,
                         int                        enableAdditionalDsp,
                         int                        enableMultiTascLogin,
                         ENTITY_SECURITY_LEVEL_ENUM securityLevelEn,
                         DDL_OBJ_ENUM               ddlObjEn,
                         const std::string         &keyStr,
                         DDL_VIEW_ENUM              ddlViewEn = View_None);

    DdlGenCfgTemplateKey(CFG_TEMPLATE_ENUM          feature,
                         int                        version,
                         DDL_OBJ_ENUM               ddlObjEn,
                         const std::string         &keyStr);

    DdlGenCfgTemplateKey(const DdlGenCfgTemplateKey&);

    ~DdlGenCfgTemplateKey();

    DdlGenCfgTemplateKey &operator= (const DdlGenCfgTemplateKey &);
    bool operator== (const DdlGenCfgTemplateKey &) const;
    bool operator< (const DdlGenCfgTemplateKey &) const;

    DBA_RDBMS_ENUM getRdbms() const
    {
        return this->m_rdbms;
    }

    void setRdbms(DBA_RDBMS_ENUM rdbms)
    {
        this->m_rdbms = rdbms;
    }

    CFG_TEMPLATE_ENUM getFeature() const
    {
        return this->m_feature;
    }

    DDL_OBJ_ENUM getDdlObjEn() const
    {
        return this->m_ddlObjEn;
    }

protected:

    CFG_TEMPLATE_ENUM          m_feature;
    DBA_RDBMS_ENUM             m_rdbms;
    int                        m_version;
    int                        m_enableAdditionalDsp;
    int                        m_enableMultiTascLogin;
    ENTITY_SECURITY_LEVEL_ENUM m_securityLevelEn;
    DDL_OBJ_ENUM               m_ddlObjEn;
    std::string                m_keyStr;
    DDL_VIEW_ENUM              m_ddlViewEn;
};

class DdlGenCfgTemplate
{
public:
    DdlGenCfgTemplate()
        : procActionEn(NullAction)
    {
    }

    std::string                        initStr;
    std::map<std::string, std::string> selectMap;
    std::string                        fromStr;
    std::string                        whereStr;
    std::string                        paramStr;
    std::string                        bodyStr;
    std::string                        alterStr;
    std::string                        onNullValueStr;
    std::string                        nameStr;
    DBA_ACTION_ENUM		               procActionEn;
};

class DdlGenCfgFile : public DdlGenMsg
{

public:
    // Constructors
    DdlGenCfgFile(DdlGenContext &paramDdlGenContext, CFG_FILE_TYPE_ENUM paramCfgFileTypeEn);
    DdlGenCfgFile(const DdlGenCfgFile& ) = delete;
    // Destructor
    virtual ~DdlGenCfgFile();

    // Methods
    RET_CODE            loadCfgFile();
    RET_CODE            checkCfgFile();
    bool                isLoaded();
    void                keepFileInMemory()
    {
        this->m_bKeepFileInMemory = true;
    };
    void                setFileName(const std::string fileName)
    {
        this->m_fileName = fileName;
    };
    const std::string &getFileName()
    {
        return this->m_fileName;
    };

    void                syncFiles(DdlGenCfgFile &, bool);
    void                upgradeFile();
    void                modifyFile(const std::string &, const std::string&, const std::string&);
    void                write();

    std::string         getProperty(const std::string &propName, bool bForceCfgFile = false);
    void                setProperty(const std::string& propName, const std::string& propValue, bool bForce);
    unsigned            getPropertyUnsignedOrDefValue(const std::string &propName, const unsigned defValue);
    bool                getPropertyBoolOrDefValue(const std::string &propName, const bool defValue);

    CFG_OBJECT_SECTION *getCfgObjectSectonStp(DICT_ENTITY_STP);
    CFG_OBJECT_SECTION *getCfgObjectSectonStp(const std::string &, DBA_ENTITY_NAT_ENUM);

    DdlGenCfgTemplate *getCfgTemplate(DdlGenCfgTemplateKey &cfgTemplateKey);

    std::map<std::string, CFG_DB_SECTION_ST>                             dbSectionMap;
    std::map<std::string, CFG_SEG_SECTION_ST>                            segSectionMap;
    std::map<std::string, CFG_USER_SECTION>                              usrSectionMap;
    std::map<std::string, CFG_OBJECT_SECTION>                            objSectionMap;
    std::map<std::string, CFG_TSL_SECTION_ST>                            tslSectionMap;
    std::map<std::string, CFG_MESI_SECTION_ST>                           mesiSectionMap;
    std::map<std::string, CFG_PROFILE_SECTION_ST>                        profileSectionMap;

    std::vector<CFG_OPTION_SECTION_ST>                                   optionSectionVector;

    std::map<std::string, std::map<DICT_T, std::vector<DdlGenLabel>>>    m_allLabelsMap;
    std::map<DdlGenCfgTemplateKey, DdlGenCfgTemplate*>                   m_cfgTemplateMap;
    CFG_FILE_TYPE_ENUM                                                   cfgFileTypeEn;

    DICT_ENTITY_STP                                                      m_dictEntitStp;
    std::vector<std::pair<DICT_ATTRIB_STP, std::string>>                 m_tableDescVector;

protected:
    std::vector<std::string>           m_fileContents;
    std::vector<std::string>           m_savedFileContents;
    std::map<std::string, std::string> m_propertiesMap;

    std::string       m_fileName;
    int               m_fileLinePos;

    RET_CODE          loadInitDefPropertiesFile();
    RET_CODE          freeInitDefPropertiesFile();

    RET_CODE          loadInstallCfgFile();
    RET_CODE          checkInstallCfgFile();
    RET_CODE          freeInstallCfgFile();

    RET_CODE          loadTemplateFile();
    RET_CODE          freeTemplateFile();

    RET_CODE          loadLabelsFile(bool);
    RET_CODE          freeLabelsFile();

    RET_CODE          loadControlFile();
    RET_CODE          freeControlFile();

    void              insPropForDbName(GEN_APPLINFO_ENUM, const char *, const char*);

private:

    std::string        getVar(const std::string &token);
    std::string        getData(const std::string &token);

    std::fstream      m_cfgFile;

    bool              m_bFileLoaded;
    bool              m_bKeepFileInMemory;

    DBA_DYNFLD_STP    m_currDictLangStp;

    int               m_cfgFileVersion;
};

#endif	                               /* ifndef DDLGENCFGFILE_H */
/************************************************************************
**      END       ddlgencfgfile.h                                Odyssey
*************************************************************************/

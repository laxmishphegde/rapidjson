﻿/************************************************************************
**
**           Copyright (C) 1995-2024 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DBAJSONLIB_C

/************************************************************************
**      Include files
*************************************************************************/
#ifdef NTWIN
#pragma warning (push)

#pragma warning (push)
#pragma warning( disable: 26495 )   // Variable '' is uninitialized. Always initialize a member variable (type.6).

// Code analysis exception
#pragma warning( disable: 4127 )    // conditional expression is constant
#pragma warning( disable: 33010 )   // Unchecked lower bound for enum type used as index..
#endif

#include "ZipFile.h"
#include "streams/memstream.h"
#include "utils/stream_utils.h"
#include "QDir"
#include "xml2json.hpp"

#ifdef WIN32
#pragma warning (pop)
#endif

#include "unidef.h"
#include "scptyl.h"
#include "dbiconnection.h"
#include "json.h"
#include "ddlgen.h"
#include "ope.h"

#ifdef NTWIN
#pragma warning (pop)
#endif

extern  RET_CODE        DBA_GetDynStpFromJSonString(const std::string&, std::vector<DBA_DYNFLD_STP>&, BuildBindOption&, MemoryPool&, DbiConnection&, bool, subQueryMapType&, ZipArchive::Ptr);
extern  RET_CODE        DBA_FillFullRecords(std::vector<DBA_DYNFLD_STP>&, BuildBindOption&, MemoryPool&, DbiConnectionHelper&, subQueryMapType&);
extern  RET_CODE        DBA_FillFullRecordAndSave(DBA_DYNFLD_STP, BuildBindOption&, MemoryPool&, DbiConnection*, subQueryMapType&, ZipArchive::Ptr);
extern std::string      SYS_ExtractKeyValues(rapidjson::Value&, const std::string&);                                /* PMSTA-46681 - LJE - 240524 */
extern  RET_CODE        DBA_CreateExportFiles(std::vector<DBA_DYNFLD_STP>&, BuildBindOption&, DbiConnection&, ZipArchive::Ptr);

extern  int             EV_AAAInstallLevel;


#define OPTIM_LIMIT_SIZE 10

const std::string MANIFEST("manifest.json");

/************************************************************************
**      Static definitions & data
*************************************************************************/

/************************************************************************
**
**  Function    :   DBA_EvalFilterScript()
**
**  Description :
**
**  Argument    :
**
**  Return      :   RET_SUCCEED.
**
**  Creation    :   PMSTA-46681 - LJE - 211102
**
**  Modif       :
**
*************************************************************************/
RET_CODE DBA_EvalFilterScript(const char* scriptDef,
                              DBA_DYNFLD_STP    recordStp,
                              DICT_T            outputEntDictId,
                              DbiConnection* dbiConnPtr,
                              DBA_DYNFLD_STP** outputTab,
                              int* outputNbr,
                              bool              bSorted)
{
    MemoryPool      mp;

    RET_CODE        ret = RET_SUCCEED;
    DBA_DYNST_ENUM  dynStEn = GET_DYNSTENUM(recordStp);
    OBJECT_ENUM     objectEn = GET_DYNST_ENTITY(dynStEn);
    DBA_DYNFLD_STP  localRec = mp.allocDynst(FILEINFO, GET_EDITGUIST(objectEn));

    SCPT_ARG_STP   localFilterTree = (SCPT_ARG_STP)NULL;
    char* buffer = (char*)NULL;
    DBA_DYNFLD_STP evalRec = (DBA_DYNFLD_STP)NULL;
    OBJECT_ENUM	   object, outputObject;
    int            incrNb = 0, j = 0;

    SCPT_ARG_ST* EV_ScptArgLocal;

    /***** LOCAL filterTree *****/
    localFilterTree = (SCPT_ARG_STP)CALLOC(1, sizeof(SCPT_ARG_ST));

    /***** GET THE SCRIPT DEFINITION *****/
    localFilterTree->script = (char*)CALLOC(1, strlen(scriptDef) + 1);
    strcpy(localFilterTree->script, scriptDef);

    /***** PARSE & GENERATE TREE FROM SCRIPT DEF *****/
    buffer = localFilterTree->script;

    EV_ScptArgLocal = localFilterTree;
    EV_ScptArgLocal->context = (SCPT_VAR_STP)CALLOC(1, sizeof(SCPT_VAR_ST));
    EV_ScptArgLocal->context->type = RecordSType;
    EV_ScptArgLocal->context->object = (short)objectEn;
    EV_ScptArgLocal->context->data.recordValue = (void*)NULL;
    EV_ScptArgLocal->stack = (SCPT_STACK_STP)CALLOC(1, sizeof(SCPT_STACK_ST));
    EV_ScptArgLocal->evalStack = (SCPT_EVALSTACK_STP)CALLOC(1, sizeof(SCPT_EVALSTACK_ST));
    EV_ScptArgLocal->root = (SCPT_NODE_STP)NULL;
    EV_ScptArgLocal->mode = DftValSMode;
    EV_ScptArgLocal->fct = (DICT_FCT_ENUM)NullDictFct;
    EV_ScptArgLocal->screenDictId = 0;
    EV_ScptArgLocal->refAttribDictId = 0;
    EV_ScptArgLocal->refEntityDictId = outputEntDictId;

    if (bSorted)
    {
        EV_ScptArgLocal->evalAttrType = EvalAttr_Sorted;
    }

    if (dbiConnPtr != nullptr)
    {
        SET_INT((&(EV_ScptArgLocal->connectNoFld)), 0, dbiConnPtr->getId());
    }
    else
    {
        SET_INT((&(EV_ScptArgLocal->connectNoFld)), 0, NO_VALUE);
    }

    localFilterTree->sqlData = new ScptSqlData();
    mp.ownerObject(localFilterTree->sqlData);
    localFilterTree->sqlData->cnt = -1;
    localFilterTree->sqlData->where = (char*)CALLOC(1, 1024 * 128);

    /***** PARSING (TREE GENERATION) *****/
    if (SCPT_yyparse_thread_safe(EV_ScptArgLocal) == 1)
    {
        std::string info;
        DBA_GetObjectEnum(outputEntDictId, &outputObject);
        SYS_StringFormat(info, "Filter Value for Entity: '%s' ", DBA_GetDictEntitySqlName(outputObject));

        ret = RET_SCPT_ERR_SYNTAX;

        MSG_SendMesg(ret, 3, FILEINFO, info.c_str(), buffer);
        EV_ScptArgLocal->script = buffer;
        EV_ScptArgLocal->root = (SCPT_NODE_STP)NULL;

    } /***** if(yyparse() == 1) *****/
    else
    {
        EV_ScptArgLocal->script = buffer;

        SCPT_EvalTree(initEvalType,
                      0,
                      localFilterTree,
                      FlagType,
                      (DBA_DYNFLD_STP)NULL,   /* For No Evaluation */
                      &evalRec,
                      objectEn,
                      localFilterTree->root,
                      NULL,
                      0,			/* colIdx */
                      (DBA_DATADEF_STP)NULL,
                      (DBA_DYNFLD_STP)NULL,   /* For No Evaluation */
                      NULL,
                      &incrNb,
                      NULL); /* PMSTA-21701 - 151116 - DDV - Remove HierElt arguments */

        localFilterTree->mode = FilterPhase2SMode;

        DATATYPE_ENUM dataType = GET_FLD_TYPE(GET_EDITGUIST(objectEn), 0);

        SCPT_EvalTree(NormalEvalType,
                      0,
                      localFilterTree,
                      dataType,
                      recordStp,
                      &evalRec,
                      objectEn,
                      localFilterTree->root,
                      nullptr,
                      0,
                      nullptr,
                      nullptr,
                      nullptr,
                      &incrNb,
                      NULL);

        SCPT_ManageTreeJoin(localFilterTree, localFilterTree->root, JoinAct_Keep);

        /***** EVALUATION FINALE *****/
        localFilterTree->mode = ConstrListSMode;

        /***** GET OBJECT_ENUM of refEntityDictId *****/
        DBA_GetObjectEnum(localFilterTree->refEntityDictId, &object);

        localFilterTree->sqlData->clear();

        localFilterTree->sqlData->where = (char*)CALLOC(1, 1024 * 128);
        localFilterTree->sqlData->buildListCompoFlg = TRUE;

        /* Check if there is any NULL valued attribute in the filter script */
        /* if so, do not evaluate further -- DynSqlMode_NullValNode */
        if (localFilterTree->sqlData->dynSqlMode == DynSqlMode_NullValNode)
        {
            localFilterTree->sqlData->where[0] = END_OF_STRING;
        }
        else
        {
            localFilterTree->sqlData->dynSqlMode = DynSqlMode_TotalWithoutIfFct;
            SCPT_EvalTree(initEvalType,
                          0,
                          localFilterTree,
                          GET_FLD_TYPE(GET_EDITGUIST(objectEn), 0),
                          (DBA_DYNFLD_STP)NULL,   /* For No Evaluation */
                          &evalRec,
                          object,	/* refEntityDictId -> Enum */
                          localFilterTree->root,
                          nullptr,
                          0,
                          (DBA_DATADEF_STP)NULL,
                          localRec,
                          NULL,
                          &incrNb,
                          NULL);
        }

        if (localFilterTree->sqlData->where[0] != END_OF_STRING)
        {
            localFilterTree->sqlData->dynSqlMode = DynSqlMode_SelectAllForExportAndFilter;      /*  Filter  */

            ret = SCPT_SelectConstData(CSTLIST_BUILD_EXPORT_DATA, /* command*/
                                       GET_INT((&(EV_ScptArgLocal->connectNoFld)), 0), /* connectNoIn */
                                       object,                    /* entObjEnum */
                                       0, 	                      /* objectId */
                                       NULL,                      /* listRecPtr */
                                       NULL,                      /* aListBuildHistoStp */
                                       localFilterTree,           /* genContext */
                                       outputTab,                 /* outputData */
                                       outputNbr,                 /* rowsNbr */
                                       NULL,                      /* retConnectNo */
                                       NULL,                      /* retBindStPtr */
                                       0,                         /* codifId */
                                       0,                         /* filterCodifId */
                                       0,                         /* rowcount */
                                       Opti_Local,                /* optimisation mode */
                                       nullptr,                   /* hierarchy */
                                       TRUE,                      /* returnRowFlag */
                                       0,
                                       NULLDYNST,
                                       nullptr);

            if (*outputNbr == 0)
            {
                FREE((*outputTab));
            }
        }

        if (localFilterTree->evalStack != NULL)
        {
            for (j = 0; j < localFilterTree->evalStack->count; j++)
            {
                if (localFilterTree->evalStack->evalStack[j].dynStType == NullDynSt)
                {
                    FREE(localFilterTree->evalStack->evalStack[j].ptr);
                }
                else
                {
                    FREE_DYNST_PTR(localFilterTree->evalStack->evalStack[j].ptr,
                                   localFilterTree->evalStack->evalStack[j].dynStType);
                }
            }
            if (localFilterTree->evalStack->count > 0)
                FREE(localFilterTree->evalStack->evalStack);
            localFilterTree->evalStack->count = 0;
        }
    } /***** if(yyparse() == 1) ... else *****/

    if (localFilterTree != nullptr)
    {
        if (localFilterTree->stack != NULL)
        {
            int u = 0;
            for (u = 0; u < localFilterTree->stack->count; u++)
            {
                FREE(localFilterTree->stack->stack[u]);
            }

            FREE(localFilterTree->stack->stack);
            FREE(localFilterTree->stack);
        }

        FREE(localFilterTree->context);
        FREE(localFilterTree->script);
        FREE(localFilterTree->stack);
        FREE(localFilterTree->evalStack);
        FREE(localFilterTree);
    }

    return(ret);
}

/************************************************************************
*   Function             : DBA_EvalCheckScript()
*
*   Description          :
*
*   Arguments            :
*
*   Creation date        : PMSTA-46681 - LJE - 211213
*
*   Last modification    :
*
*************************************************************************/
bool DBA_EvalCheckScript(const char* scriptDef,
                         DBA_DYNFLD_STP    recordStp)
{
    bool            result = false;
    RET_CODE        ret = RET_SUCCEED;
    DBA_DYNST_ENUM  dynStEn = GET_DYNSTENUM(recordStp);
    OBJECT_ENUM     objectEn = GET_DYNST_ENTITY(dynStEn);
    SCPT_ARG_STP 	generalContext = nullptr;

    DBA_DYNFLD_ST	fld;
    memset(&fld, 0, sizeof(DBA_DYNFLD_ST));

    ret = SCPT_GenerateScptTree(scriptDef,
                                objectEn,
                                InternalSMode,
                                FlagType,
                                &generalContext);

    if (ret == RET_SUCCEED)
    {
        ret = SCPT_ExecScptTree(generalContext,
                                nullptr,
                                nullptr,
                                recordStp,
                                FlagType,
                                &fld,
                                NULLDYNST);
    }

    if (GET_FLAG(&fld, 0) == TRUE)
    {
        result = true;
    }

    (void)SCPT_FreeScptTree(generalContext);

    return(result);
}

/************************************************************************
*   Function             : DBA_EvalDVScript()
*
*   Description          :
*
*   Arguments            :
*
*   Creation date        : PMSTA-46681 - LJE - 240822
*
*   Last modification    :
*
*************************************************************************/
std::string DBA_EvalDVScript(const char* scriptDef,
                             DBA_DYNFLD_STP    recordStp)
{
    RET_CODE        ret = RET_SUCCEED;
    DBA_DYNST_ENUM  dynStEn = GET_DYNSTENUM(recordStp);
    OBJECT_ENUM     objectEn = GET_DYNST_ENTITY(dynStEn);
    SCPT_ARG_STP 	generalContext = nullptr;

    DBA_DYNFLD_ST	fld;
    memset(&fld, 0, sizeof(DBA_DYNFLD_ST));

    ret = SCPT_GenerateScptTree(scriptDef,
                                objectEn,
                                InternalSMode,
                                InfoType,
                                &generalContext);

    if (ret == RET_SUCCEED)
    {
        ret = SCPT_ExecScptTree(generalContext,
                                nullptr,
                                nullptr,
                                recordStp,
                                InfoType,
                                &fld,
                                NULLDYNST);
    }

    (void)SCPT_FreeScptTree(generalContext);

    if (ret == RET_SUCCEED &&
        IS_NOTNULL(&fld, 0))
    {
        return(GET_STRING(&fld, 0));
    }

    return std::string();
}

/************************************************************************
**
**  Function    :   DBA_FillRecordExtension()
**
**  Description :
**
**  Argument    :
**
**  Return      :
**
**  Creation  	:  PMSTA-45027 - LJE - 210430
**
**  Last modif. :
**
*************************************************************************/
RET_CODE DBA_FillRecordExtension(DbiConnectionHelper& dbiConnHelper,
                                 BuildBindOption& buildBindOption,
                                 DBA_DYNFLD_STP                                         recordStp,
                                 MemoryPool& mp,
                                 std::vector<DBA_DYNFLD_STP>& allSubRecordsVector,
                                 std::map<OBJECT_ENUM, std::map<ID_T, DBA_DYNFLD_STP>>& allRecordsMap,
                                 subQueryMapType& subQueryMap) /* Map: ObjectEn, AttribDictId, ParentId, Children */
{
    RET_CODE        ret = RET_SUCCEED;
    DBA_DYNST_ENUM  dynStEn = GET_DYNSTENUM(recordStp);
    OBJECT_ENUM     objectEn = GET_DYNST_ENTITY(dynStEn);
    DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(objectEn);
    bool            bIsExport = buildBindOption.isExport();

    if (dictEntityStp != nullptr)
    {
        if (objectEn != PackageComposition &&
            dictEntityStp->isId() &&
            dictEntityStp->primKeyTab != nullptr &&
            (IS_NULLFLD(recordStp, dictEntityStp->primKeyTab[0]->progN) ||
             GET_ID(recordStp, dictEntityStp->primKeyTab[0]->progN) < 0))
        {
            return ret;
        }

        auto ddlGenDbaAccessPtr = dbiConnHelper.getConnection()->getDdlGenDbaAccessPtr();

        if (dictEntityStp->bkAttrNbr > 1)
        {
            for (auto i = 0; i < dictEntityStp->bkAttrNbr; i++)
            {
                if (dictEntityStp->bkAttr[i]->refDictEntityStp != nullptr &&
                    dictEntityStp->bkAttr[i]->refDictEntityStp->objectEn == DictEntity)
                {
                    dbiConnHelper.getConnection()->m_parentDictEntity = GET_DICT(recordStp, dictEntityStp->bkAttr[i]->progN);
                    break;
                }
            }
        }

        for (auto& dictAttribStp : dictEntityStp->attr)
        {
            if (IS_NULLFLD(recordStp, dictAttribStp->progN) ||
                IS_ID_TYPE(dictAttribStp->dataTpProgN) == false ||
                dictAttribStp->logicalFlg == TRUE)
            {
                if (dictAttribStp->logicalFlg == FALSE &&
                    dictEntityStp->primKeyTab != nullptr &&
                    IS_ID_TYPE(dictAttribStp->dataTpProgN))
                {
                    auto fkRecordStp = GET_FK_RECORD(recordStp, dictEntityStp->primKeyTab[0]->progN);

                    if (fkRecordStp != nullptr &&
                        (fkRecordStp->getIdIdx() == Null_Dynfld ||
                         allRecordsMap[fkRecordStp->getObjectEn()].find(GET_ID(fkRecordStp, fkRecordStp->getIdIdx())) == allRecordsMap[fkRecordStp->getObjectEn()].end()))
                    {
                        allSubRecordsVector.push_back(fkRecordStp);
                    }
                }
                continue;
            }

            BuildBindOption::Categ exportCateg = BuildBindOption::Categ::BusinessKeyOnlyShort;
            bool                   bToExportField = buildBindOption.isExportedAttrib(dictAttribStp, recordStp, exportCateg);

            if (bToExportField &&
                (dictAttribStp->refDictEntityStp != nullptr ||
                 (dictAttribStp->linkedAttrDictStp != nullptr && dictAttribStp->linkedAttrDictStp->refDictEntityStp->objectEn == DictEntity)))
            {
                BuildBindOptionGuard buildBindOptionGuard(buildBindOption);
                buildBindOption = exportCateg;

                OBJECT_ENUM  extRecordObjEn = NullEntity;
                if (dictAttribStp->refDictEntityStp != nullptr)
                {
                    extRecordObjEn = dictAttribStp->refDictEntityStp->objectEn;
                }
                else
                {
                    extRecordObjEn = DBA_GetObjectEnum(GET_DICT(recordStp, dictAttribStp->linkedAttrDictStp->progN));
                }

                DBA_DYNST_ENUM         extRecordsEn = GET_EDITGUIST(extRecordObjEn);
                std::vector<DBA_DYNFLD_STP> subRecordsVector;

                if (subQueryMap[dictEntityStp->objectEn].empty() ||
                    subQueryMap[dictEntityStp->objectEn].find(dictAttribStp->attrDictId) == subQueryMap[dictEntityStp->objectEn].end())
                {
                    buildBindOption.setObjectEn(objectEn);
                    buildBindOption.setDynStEn(dynStEn);
                    buildBindOption.setFieldIdx(dictAttribStp->progN);

                    {
                        DBA_DYNFLD_STP subRecordStp = nullptr;
                        if (GET_FK_RECORD(recordStp, dictAttribStp->progN) == nullptr ||
                            IS_NULLFLD(GET_FK_RECORD(recordStp, dictAttribStp->progN), DBA_GetDictEntitySt(extRecordObjEn)->getIdIdx(DynType_All)))
                        {
                            if (ddlGenDbaAccessPtr != nullptr)
                            {
                                subRecordStp = ddlGenDbaAccessPtr->getRecordById(extRecordObjEn, GET_ID(recordStp, dictAttribStp->progN), false);
                            }
                        }
                        else
                        {
                            subRecordStp = GET_FK_RECORD(recordStp, dictAttribStp->progN);
                        }

                        if (subRecordStp == nullptr &&
                            GET_ID(recordStp, dictAttribStp->progN) > 0)
                        {
                            std::stringstream requestCmd;
                            RequestHelper requestHelper(dbiConnHelper);
                            requestHelper.setReadOnly(true);

                            auto refEntityStp = dictAttribStp->refDictEntityStp;
                            if (dictAttribStp->refDictEntityStp == nullptr)
                            {
                                refEntityStp = DBA_GetDictEntityByDictIdSafe(GET_DICT(recordStp, dictAttribStp->linkedAttrDictStp->progN));
                            }

                            requestCmd
                                << std::endl << "#SELECT " << refEntityStp->mdSqlName << " all E"
                                << std::endl << "#FROM"
                                << std::endl << "#WHERE";

                            requestCmd
                                << std::endl << "E." << refEntityStp->primKeyTab[0]->sqlName << " = ? ";
                            requestHelper.addNewParamId(GET_ID(recordStp, dictAttribStp->progN));

                            requestCmd
                                << std::endl << "#END";

                            requestHelper.setCommand(requestCmd.str());

                            requestHelper.setDynStOutputData(extRecordsEn, TargetTable_Undefined);

                            ret = requestHelper.sendCommandForFetch();
                            while (RET_GET_LEVEL(ret) != RET_LEV_ERROR &&
                                   requestHelper.fetch() == RET_SUCCEED)
                            {
                                subRecordStp = mp.allocDynst(FILEINFO, extRecordsEn);

                                requestHelper.readData(subRecordStp);

                                if (ddlGenDbaAccessPtr != nullptr)
                                {
                                    ID_T     recId = 0;
                                    if (ddlGenDbaAccessPtr->insRecord(subRecordStp, recId, false, true) == subRecordStp)
                                    {
                                        mp.removeDynStp(subRecordStp);
                                    }
                                }
                            }
                        }

                        if (subRecordStp != nullptr)
                        {
                            subRecordsVector.push_back(subRecordStp);

                            if (ddlGenDbaAccessPtr != nullptr &&
                                buildBindOption.isExport() &&
                                buildBindOption.isToDelete(subRecordStp))
                            {
                                ddlGenDbaAccessPtr->insUpdDelRecord(Delete, subRecordStp->getObjectEn(), UNUSED, subRecordStp, false);
                            }
                        }
                    }
                }
                else
                {
                    subRecordsVector = subQueryMap[dictEntityStp->objectEn]
                        [dictAttribStp->attrDictId]
                        [DBA_GetDictEntitySt(extRecordObjEn)->entDictId]
                        [GET_ID(recordStp, dictAttribStp->progN)];
                }

                if (subRecordsVector.empty() == false)
                {
                    if (subRecordsVector.size() > 1)
                    {
                        SYS_BreakOnDebug();
                    }

                    if (subRecordsVector[0] != recordStp)
                    {
                        buildBindOption = exportCateg;

                        if (buildBindOption.isImportExport() &&
                            (recordStp->getObjectEn() != CopyArg ||
                             GET_A_CopyArg_CopyLogicalEn(recordStp) != CopyArgCopyLogicalEn::No))
                        {
                            DBA_FillFullRecord(subRecordsVector[0],
                                               buildBindOption,
                                               mp,
                                               dbiConnHelper,
                                               subQueryMap);
                        }

                        SET_FK_RECORD(recordStp, dictAttribStp->progN, subRecordsVector[0]);
                    }
                    else
                    {
                        SET_FK_RECORD(recordStp, dictAttribStp->progN, recordStp);
                    }
                }
            }
        }

        if (bIsExport &&
            dictEntityStp->primKeyTab != nullptr)
        {
            for (auto dictAttribStp : dictEntityStp->logicalTab)
            {
                std::string filter;
                auto        exportCateg = buildBindOption.getExportFullCateg();
                bool        bToExportField = buildBindOption.isExportedLogicalAttrib(dictAttribStp, recordStp, filter, exportCateg);

                if (bToExportField &&
                    dictAttribStp->refDictEntityStp != nullptr &&
                    dictAttribStp->refDictEntityStp->objectEn != Empty &&
                    dictAttribStp->linkedAttrDictStp != nullptr)
                {
                    auto refDictEntityStp = dictAttribStp->linkedAttrDictStp->dictEntityStp;

                    BuildBindOptionGuard buildBindOptionGuard(buildBindOption);
                    buildBindOption = exportCateg;
                    buildBindOption.setObjectEn(objectEn);
                    buildBindOption.setDynStEn(dynStEn);
                    buildBindOption.setFieldIdx(dictAttribStp->progN);

                    DBA_DYNST_ENUM         extRecordsEn = GET_EDITGUIST(dictAttribStp->refDictEntityStp->objectEn);
                    std::vector<DBA_DYNFLD_STP> subRecordsVector;

                    if (subQueryMap[dictEntityStp->objectEn].empty())
                    {
                        std::map<std::string, ID_T> stdRequestMap;

                        if (dictAttribStp->linkedAttrDictStp->linkedAttrDictStp != nullptr &&
                            dictAttribStp->linkedAttrDictStp->linkedAttrDictStp->refDictEntityStp != nullptr)
                        {
                            if (dictAttribStp->linkedAttrDictStp->linkedAttrDictStp->refDictEntityStp->objectEn == DictEntity)
                            {
                                stdRequestMap[dictAttribStp->linkedAttrDictStp->linkedAttrDictStp->sqlName] = dictEntityStp->entDictId;
                            }
                        }

                        if (dictAttribStp->linkedAttrDictStp->refDictEntityStp != nullptr &&
                            dictAttribStp->linkedAttrDictStp->linkedAttrDictStp != nullptr &&
                            dictAttribStp->linkedAttrDictStp->refDictEntityStp->objectEn == DictAttr)
                        {
                            stdRequestMap[dictAttribStp->linkedAttrDictStp->sqlName] = (dictAttribStp->parAttrDictId != 0 ? dictAttribStp->parAttrDictId : dictAttribStp->attrDictId);
                            stdRequestMap[dictAttribStp->linkedAttrDictStp->linkedAttrDictStp->sqlName] = GET_ID(recordStp, dictEntityStp->primKeyTab[0]->progN);
                        }
                        else
                        {
                            stdRequestMap[dictAttribStp->linkedAttrDictStp->sqlName] = GET_ID(recordStp, dictEntityStp->primKeyTab[0]->progN);
                        }

                        if (filter.empty() == false)
                        {
                            std::stringstream requestCmd;

                            DECLARE_PTR(DBA_DYNFLD_STP*, outputTab)
                            int              outputNbr = 0;

                            for (auto it = stdRequestMap.begin(); it != stdRequestMap.end(); ++it)
                            {
                                if (it != stdRequestMap.begin())
                                {
                                    requestCmd << " AND ";
                                }
                                requestCmd << "&" << it->first << " = " << it->second;
                            }

                            if (stdRequestMap.empty() == false)
                            {
                                requestCmd << " AND ";
                            }

                            requestCmd << "("
                                << filter
                                << ")";

                            std::string sqlRequest;
                            if ((ret = DBA_EvalFilterScript(requestCmd.str().c_str(),
                                                            recordStp,
                                                            refDictEntityStp->entDictId,
                                                            dbiConnHelper.getConnection(),
                                                            &outputTab,
                                                            &outputNbr,
                                                            true)) == RET_SUCCEED)
                            {
                                DBA_DYNFLD_STP shDynStp = nullptr;

                                for (int i = 0; i < outputNbr; i++)
                                {
                                    DBA_DYNFLD_STP subRecordStp = outputTab[i];

                                    if (refDictEntityStp->entDictId != dictAttribStp->refEntDictId)
                                    {
                                        if (shDynStp == nullptr)
                                        {
                                            shDynStp = mp.allocDynst(FILEINFO, GET_ADMINGUIST(subRecordStp->getObjectEn()));
                                        }

                                        SET_ID(shDynStp, shDynStp->getIdIdx(), GET_ID(subRecordStp, subRecordStp->getIdIdx()));

                                        DECLARE_PTR(DBA_DYNFLD_STP*, subOutputTab)
                                        int                          subOutputNbr = 0;

                                        FREE_DYNST(subRecordStp, subRecordStp->getDynStEn());
                                        if (dbiConnHelper.dbaSelect(dictAttribStp->refDictEntityStp->objectEn,
                                                                    UNUSED,
                                                                    shDynStp,
                                                                    GET_EDITGUIST(dictAttribStp->refDictEntityStp->objectEn),
                                                                    &subOutputTab,
                                                                    &subOutputNbr) == RET_SUCCEED)
                                        {
                                            subRecordStp = subOutputTab[0];
                                        }
                                        else
                                        {
                                            continue;
                                        }
                                    }

                                    mp.ownerDynStp(subRecordStp);
                                    subRecordsVector.push_back(subRecordStp);
                                }
                            }
                            else
                            {
                                buildBindOption.printMsg(ProcessingMessageNatEn::Error,
                                                         ret,
                                                         SYS_Stringer("Unable to eval the filter script : ", requestCmd.str()));
                            }

                        }
                        else
                        {
                            std::stringstream requestCmd;
                            RequestHelper requestHelper(dbiConnHelper);
                            requestHelper.setReadOnly(true);

                            requestCmd
                                << std::endl << "#SELECT " << refDictEntityStp->mdSqlName << " all E"
                                << std::endl << "#FROM"
                                << std::endl << "#WHERE";


                            for (auto it = stdRequestMap.begin(); it != stdRequestMap.end(); ++it)
                            {
                                auto paramPtr = requestHelper.addNewParamId(it->second);
                                requestCmd
                                    << std::endl << "E." << it->first << " = ?" << paramPtr->m_colPos;
                            }

                            requestCmd
                                << std::endl << "#ORDER"
                                << std::endl << "#END";

                            requestHelper.setCommand(requestCmd.str());

                            requestHelper.setDynStOutputData(extRecordsEn, TargetTable_Undefined);

                            ret = requestHelper.sendCommandForFetch();
                            while (RET_GET_LEVEL(ret) != RET_LEV_ERROR &&
                                   requestHelper.fetch() == RET_SUCCEED)
                            {
                                auto subRecordStp = mp.allocDynst(FILEINFO, extRecordsEn);

                                requestHelper.readData(subRecordStp);
                                subRecordsVector.push_back(subRecordStp);
                            }
                        }
                    }
                    else
                    {
                        subRecordsVector = subQueryMap[dictEntityStp->objectEn]
                            [dictAttribStp->attrDictId]
                            [dictAttribStp->refEntDictId]
                            [GET_ID(recordStp, dictEntityStp->primKeyTab[0]->progN)];
                    }

                    if (subRecordsVector.empty() == false)
                    {
                        if (DBA_isScriptDynSt(extRecordsEn))
                        {
                            DBA_SCRIPT_DYN_ST   scpt_DynStCfg;
                            DBA_SetScriptDynStConfig(GET_OBJ_DYNST(extRecordsEn), &scpt_DynStCfg);

                            if (subRecordsVector.size() > 1)
                            {
                                std::map<DICT_T, std::map<ID_T, std::map<ENUM_T, std::map<SMALLINT_T, DBA_DYNFLD_STP>>>> scriptDefMap;

                                for (auto it = subRecordsVector.begin(); it != subRecordsVector.end(); ++it)
                                {
                                    scriptDefMap[GET_DICT((*it), scpt_DynStCfg.A_ScriptSt_AttrDictId)]
                                        [GET_ID((*it), scpt_DynStCfg.A_ScriptSt_ObjId)]
                                        [GET_ENUM((*it), scpt_DynStCfg.A_ScriptSt_NatEn)]
                                        [GET_SMALLINT((*it), scpt_DynStCfg.A_ScriptSt_Rank)] = (*it);
                                }
                                subRecordsVector.clear();

                                for (auto attribIt = scriptDefMap.begin(); attribIt != scriptDefMap.end(); ++attribIt)
                                {
                                    for (auto objectIt = attribIt->second.begin(); objectIt != attribIt->second.end(); ++objectIt)
                                    {
                                        for (auto natureIt = objectIt->second.begin(); natureIt != objectIt->second.end(); ++natureIt)
                                        {
                                            std::string scptDef;
                                            for (auto rankIt = natureIt->second.begin(); rankIt != natureIt->second.end(); ++rankIt)
                                            {
                                                scptDef += GET_STRING(rankIt->second, scpt_DynStCfg.A_ScriptSt_Def);

                                                if (rankIt == natureIt->second.begin())
                                                {
                                                    subRecordsVector.push_back(mp.duplicate(FILEINFO, rankIt->second));
                                                    SET_NULL_SMALLINT(subRecordsVector.back(), scpt_DynStCfg.A_ScriptSt_Rank);
                                                }

                                                if (ddlGenDbaAccessPtr == nullptr)
                                                {
                                                    mp.freeDynStp(rankIt->second);
                                                }
                                            }

                                            auto subRecordStp = subRecordsVector.back();
                                            SET_STRING(subRecordStp, scpt_DynStCfg.A_ScriptSt_Def, scptDef.c_str());
                                            // SET_NULL_ID(subRecordStp, scpt_DynStCfg.A_ScriptSt_Id);

                                            if (ddlGenDbaAccessPtr != nullptr)
                                            {
                                                ID_T     recId = 0;
                                                (void)ddlGenDbaAccessPtr->insRecord(subRecordStp, recId, true, true);
                                            }
                                        }
                                    }
                                }
                            }
                            else
                            {
                                SET_NULL_SMALLINT((*subRecordsVector.begin()), scpt_DynStCfg.A_ScriptSt_Rank);

                                auto subRecordStp = (*subRecordsVector.begin());
                                if (ddlGenDbaAccessPtr != nullptr)
                                {
                                    ID_T     recId = 0;
                                    (void)ddlGenDbaAccessPtr->insRecord(subRecordStp, recId, true, true);
                                }
                            }
                        }

                        int             extRecordsNbr = 0;
                        DBA_DYNFLD_STP* extRecordsPtr = static_cast<DBA_DYNFLD_STP*>(CALLOC(subRecordsVector.size(), sizeof(DBA_DYNFLD_STP)));

                        for (auto it = subRecordsVector.begin(); it != subRecordsVector.end(); ++it, ++extRecordsNbr)
                        {
                            extRecordsPtr[extRecordsNbr] = (*it);
                            if (((*it)->getIdIdx() == Null_Dynfld ||
                                 allRecordsMap[(*it)->getObjectEn()].find(GET_ID((*it), (*it)->getIdIdx())) == allRecordsMap[(*it)->getObjectEn()].end()))
                            {
                                allSubRecordsVector.push_back((*it));
                            }
                        }

                        FREE_EXTENSION(recordStp, dictAttribStp->progN);
                        SET_EXTENSION(recordStp, dictAttribStp->progN, extRecordsPtr, extRecordsEn, extRecordsNbr);
                    }
                }
            }
        }

        dbiConnHelper.getConnection()->m_parentDictEntity = 0;
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DBA_FillCache()
**
**  Description :
**
**  Argument    :
**
**  Return      :
**
**  Creation  	:  PMSTA-46681 - LJE - 220704
**
**  Last modif. :
**
*************************************************************************/
RET_CODE DBA_FillCache(DbiConnectionHelper& dbiConnHelper,
                       BuildBindOption& buildBindOption,
                       std::vector<DBA_DYNFLD_STP>& recordsVector,
                       MemoryPool& mp,
                       std::map<OBJECT_ENUM, std::vector<DBA_DYNFLD_STP>>& subRecordsMap,
                       subQueryMapType& subQueryMap) /* Map: ObjectEn, ParentId, Children */
{
    RET_CODE        ret = RET_SUCCEED;
    DBA_DYNST_ENUM  dynStEn = GET_DYNSTENUM((*recordsVector.begin()));
    OBJECT_ENUM     objectEn = GET_DYNST_ENTITY(dynStEn);
    DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(objectEn);

    BuildBindOptionGuard buildBindOptionGuard(buildBindOption);
    buildBindOption.setObjectEn(objectEn);
    buildBindOption.setDynStEn(dynStEn);

    if (dictEntityStp != nullptr)
    {
        auto ddlGenDbaAccessPtr = dbiConnHelper.getConnection()->getDdlGenDbaAccessPtr();

        std::set<std::pair<DBA_DYNFLD_STP, FIELD_IDX_T>> newRecordSet;

        for (auto& dictAttribStp : dictEntityStp->attr)
        {
            if (IS_ID_TYPE(dictAttribStp->dataTpProgN))
            {
                buildBindOption.setFieldIdx(dictAttribStp->progN);

                std::map<OBJECT_ENUM, std::map<ID_T, std::vector<std::pair<DBA_DYNFLD_STP, BuildBindOption::Categ>>>> requestMap;

                for (auto& recordStp : recordsVector)
                {
                    BuildBindOption::Categ exportCateg = BuildBindOption::Categ::BusinessKeyOnlyShort;
                    bool                   bToExportField = buildBindOption.isExportedAttrib(dictAttribStp, recordStp, exportCateg);

                    if (bToExportField &&
                        (dictAttribStp->refDictEntityStp != nullptr ||
                         (dictAttribStp->linkedAttrDictStp != nullptr && dictAttribStp->linkedAttrDictStp->refDictEntityStp->objectEn == DictEntity)))
                    {
                        OBJECT_ENUM  extRecordObjEn = NullEntity;
                        if (dictAttribStp->refDictEntityStp != nullptr)
                        {
                            extRecordObjEn = dictAttribStp->refDictEntityStp->objectEn;

                            if (dictAttribStp->refDictEntityStp->objectEn == dictEntityStp->objectEn &&
                                GET_ID(recordStp, dictAttribStp->progN) == GET_ID(recordStp, dictEntityStp->getIdIdx(DynType_All)))
                            {
                                SET_FK_RECORD(recordStp, dictAttribStp->progN, recordStp);
                            }
                        }
                        else
                        {
                            extRecordObjEn = DBA_GetObjectEnum(GET_DICT(recordStp, dictAttribStp->linkedAttrDictStp->progN));
                        }

                        DBA_DYNFLD_STP subRecordStp = nullptr;
                        bool           bIsDbRecord = false;
                        if (GET_FK_RECORD(recordStp, dictAttribStp->progN) == nullptr ||
                            IS_NULLFLD(GET_FK_RECORD(recordStp, dictAttribStp->progN), DBA_GetDictEntitySt(extRecordObjEn)->getIdIdx(DynType_All)) ||
                            (ddlGenDbaAccessPtr != nullptr && (bIsDbRecord = ddlGenDbaAccessPtr->isDbRecord(GET_FK_RECORD(recordStp, dictAttribStp->progN))) == false))
                        {
                            if (GET_ID(recordStp, dictAttribStp->progN) > 0 &&
                                (bIsDbRecord == false ||
                                 ddlGenDbaAccessPtr == nullptr ||
                                 (subRecordStp = ddlGenDbaAccessPtr->getRecordById(extRecordObjEn, GET_ID(recordStp, dictAttribStp->progN), false)) == nullptr))
                            {
                                auto& requestVector = requestMap[extRecordObjEn][GET_ID(recordStp, dictAttribStp->progN)];
                                if (requestVector.empty())
                                {
                                    requestVector.push_back(std::make_pair(recordStp, exportCateg));
                                }
                            }
                        }
                        else
                        {
                            subRecordStp = GET_FK_RECORD(recordStp, dictAttribStp->progN);
                        }

                        if (subRecordStp != nullptr)
                        {
                            if (subRecordStp != recordStp &&
                                exportCateg != BuildBindOption::Categ::BusinessKeyOnly &&
                                exportCateg != BuildBindOption::Categ::BusinessKeyOnlyShort &&
                                exportCateg != BuildBindOption::Categ::FlatBusinessKeyOnly &&
                                exportCateg != BuildBindOption::Categ::OutboxEventBusinessKeyOnly)
                            {
                                subRecordsMap[subRecordStp->getObjectEn()].push_back(subRecordStp);
                            }

                            auto& subQueryVector = subQueryMap[dictEntityStp->objectEn]
                                [dictAttribStp->attrDictId]
                                [DBA_GetDictEntitySt(extRecordObjEn)->entDictId]
                                [GET_ID(recordStp, dictAttribStp->progN)];

                            if (subQueryVector.empty())
                            {
                                subQueryVector.push_back(subRecordStp);
                            }
                        }
                    }
                }

                for (auto requestIt : requestMap)
                {
                    bool         bOptim = (requestIt.second.size() > OPTIM_LIMIT_SIZE);
                    std::stringstream       filter;

                    auto refEntityStp = dictAttribStp->refDictEntityStp;
                    if (dictAttribStp->refDictEntityStp == nullptr)
                    {
                        refEntityStp = DBA_GetDictEntitySt(requestIt.first);
                    }

                    dbiConnHelper.getConnection()->m_parentDictEntity = refEntityStp->entDictId;

                    if (bOptim)
                    {
                        filter
                            << std::endl << "&" << refEntityStp->primKeyTab[0]->sqlName << " IN_ (";
                    }
                    else
                    {
                        filter
                            << std::endl << "E." << refEntityStp->primKeyTab[0]->sqlName << " IN (";
                    }


                    auto& attribSubQueryMap = subQueryMap[dictEntityStp->objectEn][dictAttribStp->attrDictId][refEntityStp->entDictId];
                    bool bFirst = true;
                    for (auto requestEntityIt : requestIt.second)
                    {
                        if (requestEntityIt.first > 0 &&
                            attribSubQueryMap.find(requestEntityIt.first) == attribSubQueryMap.end())
                        {
                            if (bFirst)
                            {
                                bFirst = false;
                            }
                            else
                            {
                                filter << ", ";
                            }
                            filter
                                << requestEntityIt.first;
                        }
                    }
                    filter
                        << ")";

                    if (bFirst == false)
                    {
                        if (bOptim)
                        {
                            DBA_DYNFLD_STP* outputTab = nullptr;
                            int             outputNbr = 0;

                            if ((ret = DBA_EvalFilterScript(filter.str().c_str(),
                                                            (*recordsVector.begin()),
                                                            refEntityStp->entDictId,
                                                            dbiConnHelper.getConnection(),
                                                            &outputTab,
                                                            &outputNbr,
                                                            false)) == RET_SUCCEED)
                            {
                                for (int i = 0; i < outputNbr; i++)
                                {
                                    DBA_DYNFLD_STP subRecordStp = outputTab[i];

                                    bool bGetAll = false;
                                    for (auto recIt : requestIt.second[refEntityStp->getId(subRecordStp)])
                                    {
                                        attribSubQueryMap[GET_ID(recIt.first, dictAttribStp->progN)].push_back(subRecordStp);

                                        if (BuildBindOption::isExportCateg(recIt.second))
                                        {
                                            bGetAll = true;
                                        }
                                    }

                                    if (bGetAll)
                                    {
                                        subRecordsMap[subRecordStp->getObjectEn()].push_back(subRecordStp);
                                        newRecordSet.insert(std::make_pair(subRecordStp, buildBindOption.getFieldIdx()));
                                    }

                                    mp.ownerDynStp(subRecordStp);
                                }
                            }
                            else
                            {
                                buildBindOption.printMsg(ProcessingMessageNatEn::Error,
                                                         ret,
                                                         SYS_Stringer("Unable to eval the filter script : ", filter.str()));
                            }

                            FREE(outputTab);
                            outputNbr = 0;
                        }
                        else
                        {

                            std::stringstream requestCmd;
                            requestCmd
                                << std::endl << "#SELECT " << refEntityStp->mdSqlName << " all E"
                                << std::endl << "#FROM"
                                << std::endl << "#WHERE"
                                << filter.str()
                                << std::endl << "#END";


                            RequestHelper requestHelper(dbiConnHelper);
                            requestHelper.setReadOnly(true);
                            requestHelper.setCommand(requestCmd.str());

                            DBA_DYNST_ENUM         extRecordsEn = GET_EDITGUIST(requestIt.first);

                            requestHelper.setDynStOutputData(extRecordsEn, TargetTable_Undefined);

                            ret = requestHelper.sendCommandForFetch();
                            while (RET_GET_LEVEL(ret) != RET_LEV_ERROR &&
                                   requestHelper.fetch() == RET_SUCCEED)
                            {
                                DBA_DYNFLD_STP subRecordStp = mp.allocDynst(FILEINFO, extRecordsEn);
                                requestHelper.readData(subRecordStp);

                                bool bGetAll = false;
                                for (auto recIt : requestIt.second[refEntityStp->getId(subRecordStp)])
                                {
                                    attribSubQueryMap[GET_ID(recIt.first, dictAttribStp->progN)].push_back(subRecordStp);

                                    if (BuildBindOption::isExportCateg(recIt.second))
                                    {
                                        bGetAll = true;
                                    }
                                }

                                if (bGetAll)
                                {
                                    if ((*recordsVector.begin())->getObjectEn() != CopyArg ||
                                        GET_A_CopyArg_CopyLogicalEn((*recordsVector.begin())) != CopyArgCopyLogicalEn::No)
                                    {
                                        subRecordsMap[subRecordStp->getObjectEn()].push_back(subRecordStp);
                                    }

                                    newRecordSet.insert(std::make_pair(subRecordStp, buildBindOption.getFieldIdx()));
                                }
                            }
                        }
                    }
                }
            }
        }

        if (buildBindOption.isExport() &&
            dictEntityStp->primKeyTab != nullptr)
        {
            for (auto dictAttribStp : dictEntityStp->logicalTab)
            {
                buildBindOption.setFieldIdx(dictAttribStp->progN);

                std::string filter;
                auto        exportCateg = buildBindOption.getExportFullCateg();
                bool        bToExportField = buildBindOption.isExportedLogicalAttrib(dictAttribStp, nullptr, filter, exportCateg);

                bool bOnlyProvided = false;

                if (bToExportField && filter == "provided")
                {
                    if (ddlGenDbaAccessPtr != nullptr &&
                        buildBindOption.isExport())
                    {
                        bOnlyProvided = true;
                    }

                    filter.clear();
                }

                if (bToExportField &&
                    dictAttribStp->refDictEntityStp != nullptr &&
                    dictAttribStp->refDictEntityStp->objectEn != Empty &&
                    dictAttribStp->linkedAttrDictStp != nullptr)
                {
                    auto refDictEntityStp = dictAttribStp->linkedAttrDictStp->dictEntityStp;

                    DBA_DYNST_ENUM         extRecordsEn = GET_EDITGUIST(dictAttribStp->refDictEntityStp->objectEn);
                    FIELD_IDX_T            idProgN = dictAttribStp->linkedAttrDictStp->progN;

                    std::map<std::string, ID_T> stdRequestMap;

                    if (dictAttribStp->linkedAttrDictStp->linkedAttrDictStp != nullptr &&
                        dictAttribStp->linkedAttrDictStp->linkedAttrDictStp->refDictEntityStp != nullptr)
                    {
                        if (dictAttribStp->linkedAttrDictStp->linkedAttrDictStp->refDictEntityStp->objectEn == DictEntity)
                        {
                            stdRequestMap[dictAttribStp->linkedAttrDictStp->linkedAttrDictStp->sqlName] = dictEntityStp->entDictId;
                        }
                    }

                    if (dictAttribStp->linkedAttrDictStp->refDictEntityStp != nullptr &&
                        dictAttribStp->linkedAttrDictStp->linkedAttrDictStp != nullptr &&
                        dictAttribStp->linkedAttrDictStp->refDictEntityStp->objectEn == DictAttr)
                    {
                        stdRequestMap[dictAttribStp->linkedAttrDictStp->sqlName] = (dictAttribStp->parAttrDictId != 0 ? dictAttribStp->parAttrDictId : dictAttribStp->attrDictId);
                        stdRequestMap[dictAttribStp->linkedAttrDictStp->linkedAttrDictStp->sqlName] = 0;

                        idProgN = dictAttribStp->linkedAttrDictStp->linkedAttrDictStp->progN;
                    }
                    else
                    {
                        stdRequestMap[dictAttribStp->linkedAttrDictStp->sqlName] = 0;
                    }

                    auto& attribSubQueryMap = subQueryMap[dictEntityStp->objectEn][dictAttribStp->attrDictId][dictAttribStp->refEntDictId];

                    std::stringstream filterCmd;
                    if (stdRequestMap.empty() == false)
                    {
                        bool bFirst = true;

                        if (filter.empty())
                        {
                            filter = "1=1";
                        }

                        filterCmd << "(";

                        for (auto it = stdRequestMap.begin(); it != stdRequestMap.end(); ++it)
                        {
                            if (it != stdRequestMap.begin())
                            {
                                filterCmd << " AND ";
                            }

                            filterCmd << "&" << it->first;

                            if (it->second == 0)
                            {
                                if (recordsVector.size() > OPTIM_LIMIT_SIZE)
                                {
                                    filterCmd
                                        << " IN_ (";
                                }
                                else
                                {
                                    filterCmd
                                        << " IN (";
                                }

                                for (auto& recordStp : recordsVector)
                                {
                                    if (GET_ID(recordStp, dictEntityStp->primKeyTab[0]->progN) > 0 &&
                                        attribSubQueryMap.find(GET_ID(recordStp, dictEntityStp->primKeyTab[0]->progN)) == attribSubQueryMap.end() &&
                                        buildBindOption.isVisible(recordStp, true))
                                    {
                                        if (bFirst)
                                        {
                                            bFirst = false;
                                        }
                                        else
                                        {
                                            filterCmd << ", ";
                                        }

                                        attribSubQueryMap[GET_ID(recordStp, dictEntityStp->primKeyTab[0]->progN)];
                                        filterCmd
                                            << GET_ID(recordStp, dictEntityStp->primKeyTab[0]->progN);
                                    }
                                }
                                filterCmd
                                    << ")";
                            }
                            else
                            {
                                filterCmd << " = " << it->second;
                            }
                        }

                        filterCmd
                            << ")";

                        if (bFirst)
                        {
                            bToExportField = false;
                        }
                    }

                    if (bToExportField)
                    {
                        if (filter.empty() == false)
                        {
                            std::stringstream requestCmd;

                            DECLARE_PTR(DBA_DYNFLD_STP*, outputTab)
                            int                          outputNbr = 0;

                            if (filterCmd.str().empty() == false)
                            {
                                requestCmd
                                    << filterCmd.str() << " AND ";
                            }

                            requestCmd << "("
                                << filter
                                << ")";

                            if ((ret = DBA_EvalFilterScript(requestCmd.str().c_str(),
                                                            (*recordsVector.begin()),
                                                            refDictEntityStp->entDictId,
                                                            dbiConnHelper.getConnection(),
                                                            &outputTab,
                                                            &outputNbr,
                                                            true)) == RET_SUCCEED)
                            {
                                DBA_DYNFLD_STP shDynStp = nullptr;
                                for (int i = 0; i < outputNbr; i++)
                                {
                                    DBA_DYNFLD_STP subRecordStp = outputTab[i];
                                    ID_T           id = GET_ID(subRecordStp, idProgN);
                                    if (bOnlyProvided)
                                    {
                                        if (ddlGenDbaAccessPtr->isProvidedRecord(subRecordStp) == false)
                                        {
                                            FREE_DYNST(subRecordStp, subRecordStp->getDynStEn());
                                            continue;
                                        }
                                    }

                                    if (refDictEntityStp->entDictId != dictAttribStp->refEntDictId)
                                    {
                                        if (shDynStp == nullptr)
                                        {
                                            shDynStp = mp.allocDynst(FILEINFO, GET_ADMINGUIST(subRecordStp->getObjectEn()));
                                        }

                                        SET_ID(shDynStp, shDynStp->getIdIdx(), GET_ID(subRecordStp, subRecordStp->getIdIdx()));

                                        DECLARE_PTR(DBA_DYNFLD_STP*, subOutputTab)
                                        int                          subOutputNbr = 0;

                                        FREE_DYNST(subRecordStp, subRecordStp->getDynStEn());
                                        if (dbiConnHelper.dbaSelect(dictAttribStp->refDictEntityStp->objectEn,
                                                                    UNUSED,
                                                                    shDynStp,
                                                                    GET_EDITGUIST(dictAttribStp->refDictEntityStp->objectEn),
                                                                    &subOutputTab,
                                                                    &subOutputNbr) == RET_SUCCEED)
                                        {
                                            subRecordStp = subOutputTab[0];
                                        }
                                        else
                                        {
                                            continue;
                                        }
                                    }

                                    newRecordSet.insert(std::make_pair(subRecordStp, buildBindOption.getFieldIdx()));
                                    mp.ownerDynStp(subRecordStp);

                                    attribSubQueryMap[id].push_back(subRecordStp);
                                    subRecordsMap[subRecordStp->getObjectEn()].push_back(subRecordStp);
                                }
                            }
                            else
                            {
                                buildBindOption.printMsg(ProcessingMessageNatEn::Error,
                                                         ret,
                                                         SYS_Stringer("Unable to eval the filter script : ", requestCmd.str()));
                            }
                            outputNbr = 0;
                        }
                        else
                        {
                            std::stringstream requestCmd;
                            RequestHelper requestHelper(dbiConnHelper);
                            requestHelper.setReadOnly(true);

                            requestCmd
                                << std::endl << "#SELECT " << refDictEntityStp->mdSqlName << " all std"
                                << std::endl << "#FROM"
                                << std::endl << "#WHERE"
                                << std::endl << "#ORDER"
                                << std::endl << "#END";

                            requestHelper.setCommand(requestCmd.str());

                            requestHelper.setDynStOutputData(extRecordsEn, TargetTable_Undefined);

                            ret = requestHelper.sendCommandForFetch();
                            while (RET_GET_LEVEL(ret) != RET_LEV_ERROR &&
                                   requestHelper.fetch() == RET_SUCCEED)
                            {
                                auto subRecordStp = mp.allocDynst(FILEINFO, extRecordsEn);
                                requestHelper.readData(subRecordStp);

                                if (bOnlyProvided)
                                {
                                    if (ddlGenDbaAccessPtr->getRecord(subRecordStp->getObjectEn(), subRecordStp, false) == nullptr)
                                    {
                                        continue;
                                    }
                                }
                                newRecordSet.insert(std::make_pair(subRecordStp, buildBindOption.getFieldIdx()));

                                attribSubQueryMap[GET_ID(subRecordStp, dictAttribStp->linkedAttrDictStp->progN)].push_back(subRecordStp);
                                subRecordsMap[subRecordStp->getObjectEn()].push_back(subRecordStp);
                            }
                        }
                    }
                }
            }
        }

        if (ddlGenDbaAccessPtr != nullptr)
        {
            for (auto newRecordIt : newRecordSet)
            {
                ID_T     recId = 0;
                if (ddlGenDbaAccessPtr->insRecord(newRecordIt.first, recId, false, true, true) == newRecordIt.first)
                {
                    mp.removeDynStp(newRecordIt.first);
                }

                buildBindOption.setDynStEn(newRecordIt.first->getDynStEn());
                buildBindOption.setFieldIdx(newRecordIt.second);

                if (buildBindOption == BuildBindOption::Categ::CleanUpFullObject &&
                    buildBindOption.isToDelete(newRecordIt.first))
                {
                    ddlGenDbaAccessPtr->insUpdDelRecord(Delete, newRecordIt.first->getObjectEn(), UNUSED, newRecordIt.first, false);
                }
            }
        }

        dbiConnHelper.getConnection()->m_parentDictEntity = 0;
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DBA_FillRecord()
**
**  Description :
**
**  Argument    :
**
**  Return      :
**
**  Creation  	:  PMSTA-45027 - LJE - 210430
**
**  Last modif. :
**
*************************************************************************/
RET_CODE DBA_FillRecord(DbiConnectionHelper& dbiConnHelper,
                        BuildBindOption& buildBindOption,
                        MemoryPool& mp,
                        DBA_DYNFLD_STP       recordStp,
                        bool& newRecord)
{
    RET_CODE        ret = RET_SUCCEED;
    DBA_DYNST_ENUM  dynStEn = GET_DYNSTENUM(recordStp);

    if (dynStEn == A_EntityProfile &&
        IS_NULLFLD(recordStp, A_EntityProfile_Cd) &&
        IS_NULLFLD(recordStp, A_EntityProfile_Id))
    {
        return ret;
    }

    BuildBindOptionGuard buildBindOptionGuard(buildBindOption);

    RET_CODE        gblRet = RET_SUCCEED;
    OBJECT_ENUM     objectEn = GET_DYNST_ENTITY(dynStEn);
    DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(objectEn);

    buildBindOption.setDynStEn(dynStEn);

    if ((GET_INTERNAL(recordStp) & INTERNAL_BK) == 0)
    {
        SET_INTERNAL(recordStp, (GET_INTERNAL(recordStp) | INTERNAL_FILL));
    }

    if (IS_VALID_FLD_FK(recordStp))
    {
        DBA_DYNFLD_STP* extRecordsPtr = GET_EXTENSION_PTR(recordStp, GET_FLD_FK(dynStEn));
        int             extRecordsNbr = GET_EXTENSION_NBR(recordStp, GET_FLD_FK(dynStEn));
        for (int fkAttribIdx = 0; fkAttribIdx < extRecordsNbr; ++fkAttribIdx)
        {
            auto extRecordStp = extRecordsPtr[fkAttribIdx];
            if (extRecordStp != nullptr &&
                extRecordStp != recordStp)
            {
                if ((GET_INTERNAL(extRecordStp) & INTERNAL_FILL) == 0)
                {
                    bool bToDo = false;

                    if (buildBindOption == BuildBindOption::Categ::ImportFullObject)
                    {
                        BuildBindOption::Categ exportCateg = BuildBindOption::Categ::BusinessKeyOnlyShort;
                        auto                 dictAttribStp = dictEntityStp->getDictAttribByIdx(fkAttribIdx);
                        buildBindOption.isExportedAttrib(dictAttribStp, extRecordStp, exportCateg);

                        if (BuildBindOption::isExportCateg(exportCateg))
                        {
                            bToDo = true;

                            if ((GET_INTERNAL(extRecordStp) & INTERNAL_BK) == INTERNAL_BK)
                            {
                                SET_INTERNAL(extRecordStp, (GET_INTERNAL(extRecordStp) - INTERNAL_BK));
                            }
                        }
                        else if (IS_NULLFLD(recordStp, dictAttribStp->progN) &&
                                 dictAttribStp->refDictEntityStp != nullptr)
                        {
                            bToDo = true;
                        }
                    }
                    else
                    {
                        bToDo = (GET_INTERNAL(extRecordStp) & INTERNAL_BK) == 0;
                    }

                    if (bToDo)
                    {
                        ret = DBA_FillRecord(dbiConnHelper, buildBindOption, mp, extRecordStp, newRecord);

                        if (ret != RET_SUCCEED)
                        {
                            gblRet = ret;
                        }
                        else
                        {
                            SET_FK_RECORD(recordStp, fkAttribIdx, extRecordStp);
                        }
                    }
                }

                if (IS_NULLFLD(recordStp, fkAttribIdx))
                {
                    SET_ID(recordStp, fkAttribIdx, GET_ID(extRecordStp, extRecordStp->getIdIdx()));
                }
            }
        }
    }

    auto            oriRecordStp = recordStp;
    DBA_DYNFLD_STP  getDynStp = nullptr;
    DBA_DYNFLD_STP  inputDynStp = nullptr;
    bool            bOpManagement = false;

    if (dynStEn == ExtOp)
    {
        bOpManagement = true;

        OPNAT_ENUM     nature = static_cast<OPNAT_ENUM>(GET_ENUM(recordStp, ExtOp_NatureEn));
        DBA_DYNST_ENUM discard = NullDynSt;

        inputDynStp = mp.allocDynst(FILEINFO, S_Op);

        if (OPE_OperNatToDictEnum(nature, &discard, &objectEn) != RET_SUCCEED)
        {
            COPY_DYNFLD(inputDynStp,
                        S_Op,
                        S_Op_Cd,
                        recordStp,
                        ExtOp,
                        ExtOp_Cd);


            FLAG_T          execSourceCdFlg = FALSE;
            GEN_GetApplInfo(ApplMatchExecSourceCdFlag, &execSourceCdFlg);

            if (execSourceCdFlg == TRUE)
            {
                COPY_DYNFLD(inputDynStp,
                            S_Op,
                            S_Op_NatEn,
                            recordStp,
                            ExtOp,
                            ExtOp_ExecOpNatEn);
            }


            if (DBA_Get2(Op,
                         UNUSED,
                         S_Op,
                         inputDynStp,
                         S_Op,
                         &inputDynStp,
                         UNUSED, UNUSED, UNUSED) == RET_SUCCEED)
            {
                nature = (OPNAT_ENUM)GET_ENUM(inputDynStp, S_Op_NatEn);
                if (OPE_OperNatToDictEnum(nature, &discard, &objectEn) == RET_SUCCEED)
                {
                    SET_ENUM(recordStp,
                             ExtOp_NatureEn,
                             nature);
                }
            }
        }
        dictEntityStp = DBA_GetDictEntitySt(objectEn);

        recordStp = mp.allocDynst(FILEINFO, GET_EDITGUIST(objectEn));
        OPE_ExtOpToOp(oriRecordStp, recordStp, NULL, TRUE, false, dbiConnHelper.getConnection());
        dynStEn = recordStp->getDynStEn();

        DICT_ATTRIB_STP* attributes = nullptr;
        int              count = 0;

        DBA_GetBusinessAttrib(objectEn, &count, &attributes);

        for (int n = 0; n < count; n++)
        {
            COPY_DYNFLD(
                inputDynStp,
                GET_ADMINGUIST(objectEn),
                attributes[n]->shortIdx,
                recordStp,
                GET_EDITGUIST(objectEn),
                attributes[n]->progN);
        }

        if (dbiConnHelper.dbaGet(objectEn, UNUSED, inputDynStp, &inputDynStp) == RET_SUCCEED &&
            IS_NOTNULL(inputDynStp, inputDynStp->getIdIdx()))
        {
            COPY_DYNFLD(recordStp, recordStp->getDynStEn(), recordStp->getIdIdx(), inputDynStp, inputDynStp->getDynStEn(), inputDynStp->getIdIdx());
        }
        else
        {
            newRecord = true;
        }

        getDynStp = mp.duplicate(FILEINFO, recordStp);
    }
    else
    {
        getDynStp = mp.duplicate(FILEINFO, recordStp);
        inputDynStp = getDynStp;
    }

    buildBindOption.setInitialDVDynStp(recordStp);

    auto initialDVDynStp = buildBindOption.getInitialDVDynStp();
    int role = UNUSED;
    if (dynStEn == A_Notepad &&
        IS_SETFLD(recordStp, A_Notepad_NoteDate) == FALSE)
    {
        role = DBA_ROLE_IMPORT_USR_MD;
    }

    if (dictEntityStp != nullptr)
    {
        bool bDoComputeDVBeforeGet = false;

        if (initialDVDynStp != nullptr)
        {
            for (auto attribSt : dictEntityStp->attr)
            {
                if (attribSt->exportEn != Export_NotExported)
                {
                    if (attribSt->busKeyFlg == FALSE &&
                        attribSt->primFlg == FALSE &&
                        IS_SETFLD(recordStp, attribSt->progN) == FALSE &&
                        IS_TECHFLD(dynStEn, attribSt->progN) == FALSE &&
                        IS_NULLFLD(initialDVDynStp, attribSt->progN) == false &&
                        (attribSt->custFlg == FALSE || strcmp(attribSt->sqlName, "ud_id") != 0))
                    {
                        if (buildBindOption.isExport())
                        {
                            DBA_CopyDynFldNoImpact(getDynStp, attribSt->progN, initialDVDynStp, attribSt->progN);
                        }
                        else
                        {
                            DBA_CopyDynFld(getDynStp, attribSt->progN, initialDVDynStp, attribSt->progN);

                            if (IS_NULLFLD(recordStp, attribSt->progN) &&
                                buildBindOption.getExportMode() == EntityConfigExportModeEn::NotNull)
                            {
                                DBA_CopyDynFld(recordStp, attribSt->progN, initialDVDynStp, attribSt->progN);
                            }
                        }
                    }
                }
                else if (attribSt->busKeyFlg == TRUE)
                {
                    bDoComputeDVBeforeGet = true;
                }
            }

            if (buildBindOption == BuildBindOption::Categ::ImportFullObject)
            {
                for (int fldPos = 0; fldPos < GET_FLD_NBR(dynStEn); ++fldPos)
                {
                    if (IS_SETFLD(initialDVDynStp, fldPos) == TRUE)
                    {
                        SET_SETFLG_T(recordStp, fldPos);
                    }
                }
            }
        }
        else
        {
            for (int i = 0; i < dictEntityStp->bkAttrNbr; ++i)
            {
                if (dictEntityStp->bkAttr[i]->exportEn == Export_NotExported)
                {
                    bDoComputeDVBeforeGet = true;
                    break;
                }
            }
        }

        for (auto attribStp : dictEntityStp->attr)
        {
            if (IS_NULLFLD(recordStp, attribStp->progN) &&
                attribStp->mandatoryFlg == TRUE &&
                attribStp->refDictEntityStp != nullptr)
            {
                auto pathObjectIt = buildBindOption.m_objectPathMap.find(attribStp->refDictEntityStp->objectEn);
                if (pathObjectIt != buildBindOption.m_objectPathMap.end())
                {
                    SET_ID(getDynStp, attribStp->progN, (*pathObjectIt->second.begin()));
                    SET_ID(recordStp, attribStp->progN, (*pathObjectIt->second.begin()));
                }
            }
        }


        if (bDoComputeDVBeforeGet)
        {
            if (dbiConnHelper.isValidAndInit())
            {
                RequestHelper requestHelper(dbiConnHelper);
                MemoryPool    localMp;
                auto recForDvStp = mp.duplicate(FILEINFO, getDynStp);

                for (auto& attribSt : dictEntityStp->attr)
                {
                    if (attribSt->busKeyFlg == FALSE)
                    {
                        SET_SETFLG_T(getDynStp, attribSt->progN);
                    }
                }

                requestHelper.computeDV(recForDvStp);

                for (int i = 0; i < dictEntityStp->bkAttrNbr; ++i)
                {
                    DBA_CopyDynFld(getDynStp, dictEntityStp->bkAttr[i]->progN, recForDvStp, dictEntityStp->bkAttr[i]->progN);
                    DBA_CopyDynFld(recordStp, dictEntityStp->bkAttr[i]->progN, recForDvStp, dictEntityStp->bkAttr[i]->progN);
                }
            }
        }
    }


    if ((buildBindOption == BuildBindOption::Categ::ImportFullObject ||
         buildBindOption == BuildBindOption::Categ::ExportCopyObject) &&
        dbiConnHelper.isValidAndInit())
    {
        if (buildBindOption == BuildBindOption::Categ::ImportFullObject)
        {
            RequestHelper requestHelper(dbiConnHelper);
            requestHelper.computeDV(recordStp);
        }
        else
        {
            auto pflagEvalDV = static_cast<FLAG_T*>(mp.calloc(dictEntityStp->attr.size(), sizeof(FLAG_T)));

            DBA_SetNullAttribWhileCopying(recordStp, dictEntityStp->objectEn, &pflagEvalDV, FALSE);

            SCPT_ComputeScreenDV(dictEntityStp->objectEn,
                                 DictFct_0,
                                 pflagEvalDV,
                                 NULL,
                                 recordStp,
                                 NULL,
                                 nullptr,
                                 NULLDYNST,
                                 TRUE,
                                 TRUE,
                                 EvalType_DefVal,
                                 -1,
                                 &dbiConnHelper.getConnection()->getId(),
                                 NULL,
                                 NULL,
                                 0,
                                 DictScreen,
                                 NULL,
                                 NULL,
                                 NULL,
                                 NULL,
                                 NULL,
                                 NullEntity,
                                 FALSE,
                                 FALSE,
                                 0);
        }
    }

    if (dynStEn != GET_ADMINGUIST(objectEn) && inputDynStp->isShortDynSt() == false)
    {
        inputDynStp = mp.allocDynst(FILEINFO, GET_ADMINGUIST(objectEn));
        CONVERT_DYNST(inputDynStp, GET_DYNSTENUM(inputDynStp), getDynStp, dynStEn);
    }

    DBA_DYNFLD_STP existsRecordStp = nullptr;
    ret = RET_DBA_INFO_NO_MORE_DATA;
    auto ddlGenDbaAccessPtr = dbiConnHelper.getConnection()->getDdlGenDbaAccessPtr();
    if (ddlGenDbaAccessPtr != nullptr)
    {
        existsRecordStp = ddlGenDbaAccessPtr->getRecord(recordStp->getObjectEn(), recordStp);
        if (existsRecordStp != nullptr)
        {
            if ((GET_INTERNAL(recordStp) & INTERNAL_BK) == 0 &&
                (GET_INTERNAL(existsRecordStp) & INTERNAL_BK) != 0)
            {
                SET_INTERNAL(existsRecordStp, GET_INTERNAL(existsRecordStp) - INTERNAL_BK);
            }
            else if ((GET_INTERNAL(recordStp) & INTERNAL_BK) != 0 &&
                     recordStp->getIdIdx() > Null_Dynfld &&
                     IS_NULLFLD(recordStp, recordStp->getIdIdx()))
            {
                SET_ID(recordStp, recordStp->getIdIdx(), GET_ID(existsRecordStp, existsRecordStp->getIdIdx()));
            }

            mp.freeDynStp(getDynStp);
            getDynStp = existsRecordStp;

            ret = RET_SUCCEED;
        }
    }

    if (dynStEn == A_Notepad &&
        role == DBA_ROLE_IMPORT_USR_MD)
    {
        SET_SETFLG_F(recordStp, A_Notepad_NoteDate);
    }

    if (newRecord == false &&
        (dictEntityStp->logicalFlg == FALSE || bOpManagement) &&
        (ret == RET_SUCCEED ||
         dbiConnHelper.dbaGet(objectEn, role, inputDynStp, &getDynStp) == RET_SUCCEED))
    {
        if (ddlGenDbaAccessPtr != nullptr &&
            buildBindOption == BuildBindOption::Categ::CleanUpFullObject &&
            (GET_INTERNAL(getDynStp) & INTERNAL_BK) == 0 &&
            (GET_INTERNAL(recordStp) & INTERNAL_BK) == 0)
        {
            buildBindOption.setFieldIdx(Null_Dynfld);
            if (buildBindOption.isToDelete(getDynStp))
            {
                ddlGenDbaAccessPtr->insUpdDelRecord(Delete, objectEn, UNUSED, getDynStp, false);
            }
        }

        if (recordStp != getDynStp)
        {
            for (int fldPos = 0; fldPos < GET_FLD_NBR(dynStEn); ++fldPos)
            {
                if (IS_SETFLD(recordStp, fldPos) == FALSE &&
                    IS_EXTFLD(recordStp->getDynStEn(), fldPos) == FALSE &&
                    IS_CHAINFLD(recordStp->getDynStEn(), fldPos) == FALSE &&
                    IS_TECHFLD(recordStp->getDynStEn(), fldPos) == FALSE)
                {
                    DBA_CopyDynFldNoImpact(recordStp, fldPos, getDynStp, fldPos);
                }
            }
        }
    }
    else if (dictEntityStp->logicalFlg == FALSE)
    {
        newRecord = true;
    }

    if (initialDVDynStp != nullptr)
    {
        for (int fldPos = 0; fldPos < GET_FLD_NBR(dynStEn); ++fldPos)
        {
            if (IS_SETFLD(recordStp, fldPos) == FALSE &&
                IS_SETFLD(initialDVDynStp, fldPos) == TRUE)
            {
                SET_SETFLG_T(recordStp, fldPos);
            }
        }
    }

    DBA_SetDfltEntityFld(recordStp);

    ret = RET_SUCCEED;

    if (ddlGenDbaAccessPtr != nullptr)
    {
        if (buildBindOption == BuildBindOption::Categ::ImportFullObject &&
            (GET_INTERNAL(recordStp) & INTERNAL_BK) == 0)
        {
            ID_T     recId = 0;

            role = UNUSED;
            if (dynStEn == A_ScriptDef ||
                dynStEn == A_HoldingConstraintScript ||
                dynStEn == A_TradingConstraintScript)
            {
                role = DBA_ROLE_INSERT_SCRIPT;
            }

            bool bToModify = true;
            if (existsRecordStp != nullptr)
            {
                bToModify = buildBindOption.isToModify(existsRecordStp);

                if (bToModify)
                {
                    auto idIdx = existsRecordStp->getIdIdx();
                    if (idIdx > Null_Dynfld &&
                        IS_NULLFLD(recordStp, idIdx))
                    {
                        SET_ID(recordStp, idIdx, GET_ID(existsRecordStp, idIdx));
                    }
                    DBA_CopyDynStWithSetFld(existsRecordStp, recordStp);
                }
            }
            else
            {
                existsRecordStp = recordStp;
            }

            if (bToModify)
            {
                mp.removeDynStp(ddlGenDbaAccessPtr->insUpdRecord(existsRecordStp, recId, role, false));

                if (recId != 0)
                {
                    SET_ID(existsRecordStp, existsRecordStp->getIdIdx(), recId);
                }
            }
        }
        else if (buildBindOption == BuildBindOption::Categ::ImportFullObject &&
                 (GET_INTERNAL(recordStp) & INTERNAL_BK) == INTERNAL_BK &&
                 recordStp->getIdIdx() > Null_Dynfld &&
                 IS_NULLFLD(recordStp, recordStp->getIdIdx()))
        {
            ID_T newId = 0;
            ddlGenDbaAccessPtr->insRecord(recordStp, newId);
        }
    }

    buildBindOption.setRecordStp(recordStp);

    if (buildBindOption.isImportExport() &&
        dictEntityStp != nullptr &&
        dictEntityStp->isId())
    {
        for (auto dictAttribStp : dictEntityStp->logicalTab)
        {
            if (IS_NULLFLD(recordStp, dictAttribStp->progN) == FALSE &&
                GET_EXTENSION_NBR(recordStp, dictAttribStp->progN) > 0 &&
                dictAttribStp != dictEntityStp->logicalTab.back())
            {
                BuildBindOptionGuard attribBuildBindOptionGuard(buildBindOption);
                buildBindOption.setFieldIdx(dictAttribStp->progN);

                DBA_DYNFLD_STP* extRecordsPtr = GET_EXTENSION_PTR(recordStp, dictAttribStp->progN);
                int             extRecordsNbr = GET_EXTENSION_NBR(recordStp, dictAttribStp->progN);
                INT_T           linkedAttribProgN = Null_Dynfld;
                bool            bAuto = buildBindOption.isAuto(dictEntityStp->mdSqlName, dictAttribStp->sqlName);

                if (dictAttribStp->linkedAttrDictStp != nullptr)
                {
                    if (dictAttribStp->linkedAttrDictStp->entDictId == dictAttribStp->refEntDictId)
                    {
                        linkedAttribProgN = dictAttribStp->linkedAttrDictStp->progN;
                    }
                    else
                    {
                        auto refDictAttribStp = DBA_GetDictEntityByDictIdSafe(dictAttribStp->refEntDictId)->getDictAttribBySqlName(dictAttribStp->linkedAttrDictStp->sqlName);
                        if (refDictAttribStp != nullptr)
                        {
                            linkedAttribProgN = refDictAttribStp->progN;
                        }
                    }
                }

                for (int i = 0; i < extRecordsNbr; ++i)
                {
                    if (dictAttribStp->linkedAttrDictStp != nullptr)
                    {
                        if (dictAttribStp->linkedAttrDictStp->linkedAttrDictStp != nullptr &&
                            dictAttribStp->linkedAttrDictStp->refDictEntityStp != nullptr &&
                            dictAttribStp->linkedAttrDictStp->refDictEntityStp->objectEn == DictAttr)
                        {
                            SET_DICT(extRecordsPtr[i], dictAttribStp->linkedAttrDictStp->progN, (dictAttribStp->parAttrDictId != 0 ? dictAttribStp->parAttrDictId : dictAttribStp->attrDictId));
                            SET_ID(extRecordsPtr[i], dictAttribStp->linkedAttrDictStp->linkedAttrDictStp->progN, GET_ID(recordStp, dictEntityStp->primKeyTab[0]->progN));

                            if (dictAttribStp->linkedAttrDictStp->linkedAttrDictStp->linkedAttrDictStp != nullptr &&
                                dictAttribStp->linkedAttrDictStp->linkedAttrDictStp->linkedAttrDictStp->refDictEntityStp->objectEn == DictEntity)
                            {
                                SET_DICT(extRecordsPtr[i], dictAttribStp->linkedAttrDictStp->linkedAttrDictStp->linkedAttrDictStp->progN, dictAttribStp->dictEntityStp->entDictId);
                            }
                        }
                        else
                        {
                            if (dictAttribStp->linkedAttrDictStp->linkedAttrDictStp != nullptr)
                            {
                                if (dictAttribStp->linkedAttrDictStp->linkedAttrDictStp->refDictEntityStp != nullptr &&
                                    dictAttribStp->linkedAttrDictStp->linkedAttrDictStp->refDictEntityStp->objectEn == DictEntity)
                                {
                                    SET_DICT(extRecordsPtr[i], dictAttribStp->linkedAttrDictStp->linkedAttrDictStp->progN, dictAttribStp->dictEntityStp->entDictId);
                                }
                            }

                            if (IS_NULLFLD(recordStp, dictEntityStp->primKeyTab[0]->progN) == FALSE &&
                                GET_ID(extRecordsPtr[i], linkedAttribProgN) != GET_ID(recordStp, dictEntityStp->primKeyTab[0]->progN))
                            {
                                SET_ID(extRecordsPtr[i], linkedAttribProgN, GET_ID(recordStp, dictEntityStp->primKeyTab[0]->progN));
                            }
                        }
                    }

                    ret = DBA_FillRecord(dbiConnHelper, buildBindOption, mp, extRecordsPtr[i], newRecord);
                    if (ret != RET_SUCCEED)
                    {
                        gblRet = ret;
                    }
                    else if (bAuto &&
                             ddlGenDbaAccessPtr != nullptr &&
                             GET_ID(extRecordsPtr[i], extRecordsPtr[i]->getIdIdx()) <= 0)
                    {
                        ddlGenDbaAccessPtr->addAutoRecord(recordStp, extRecordsPtr[i]);
                    }
                }
            }
        }
    }

    return gblRet;
}

#define INIT_LEVEL 10000
/************************************************************************
**
**  Function    :   DBA_SaveRecord()
**
**  Description :
**
**  Argument    :
**
**  Return      :
**
**  Creation  	:  PMSTA-45027 - LJE - 210430
**
**  Last modif. :
**
*************************************************************************/
RET_CODE DBA_SaveRecord(RequestHelper& requestHelper,
                        DBA_DYNFLD_STP               recordStp,
                        DBA_DYNFLD_STP               parentRecordStp = nullptr,
                        DICT_ATTRIB_STP              logAttribStp = nullptr,
                        size_t                       level = INIT_LEVEL)
{
    MemoryPool      mp;
    RET_CODE        ret = RET_SUCCEED;
    DBA_DYNST_ENUM  dynStEn = GET_DYNSTENUM(recordStp);
    OBJECT_ENUM     objectEn = GET_DYNST_ENTITY(dynStEn);
    DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(objectEn);

    DbaTransactionGuard dbaTransactionGuard(requestHelper.getDbiConn(), ret);

    if (level == INIT_LEVEL &&
        requestHelper.getTransactionMode() != RequestHelper::TransactionMode::External)
    {
        requestHelper.setTransactionMode(RequestHelper::TransactionMode::AllOrNothing);
    }

    DBA_ACTION_ENUM action = Insert;
    int             role = UNUSED;

    if ((GET_INTERNAL(recordStp) & 1) == 1)
    {
        action = Update;
    }

    if (dynStEn == A_ScriptDef ||
        dynStEn == A_HoldingConstraintScript ||
        dynStEn == A_TradingConstraintScript)
    {
        role = DBA_ROLE_INSERT_SCRIPT;
    }

    /* treat direct records contained on the script_control extension */
    if (IS_NULLFLD(recordStp, dictEntityStp->logicalTab.back()->progN) == FALSE)
    {
        DBA_DYNFLD_STP* extRecordsPtr = GET_EXTENSION_PTR(recordStp, dictEntityStp->logicalTab.back()->progN);
        int             extRecordsNbr = GET_EXTENSION_NBR(recordStp, dictEntityStp->logicalTab.back()->progN);
        for (int i = 0; i < extRecordsNbr; ++i)
        {
            auto dictAttribStp = dictEntityStp->attr[i];

            if (extRecordsPtr[i] != nullptr)
            {
                ret = DBA_SaveRecord(requestHelper, extRecordsPtr[i], recordStp, dictAttribStp, level - 100);

                requestHelper.setCopyIdForBatchMulti(level,
                                                     recordStp,
                                                     dictAttribStp->progN,
                                                     extRecordsPtr[i],
                                                     dictAttribStp->refDictEntityStp->primKeyTab[0]->progN);
            }
        }
    }

    requestHelper.addProcedureCallForBatchMulti(action, objectEn, role, recordStp, level);

    if (parentRecordStp != nullptr)
    {
        DBA_DYNST_ENUM  parDynStEn = GET_DYNSTENUM(parentRecordStp);
        OBJECT_ENUM     parObjectEn = GET_DYNST_ENTITY(parDynStEn);

        if (logAttribStp != nullptr && logAttribStp->logicalFlg != FALSE)
        {
            if (logAttribStp->linkedAttrDictStp != nullptr)
            {
                if (logAttribStp->linkedAttrDictStp->refDictEntityStp == nullptr ||
                    logAttribStp->linkedAttrDictStp->refDictEntityStp->objectEn == parObjectEn)
                {
                    requestHelper.setCopyIdForBatchMulti(level, recordStp, logAttribStp->linkedAttrDictStp->progN, parentRecordStp, logAttribStp->dictEntityStp->primKeyTab[0]->progN);
                }
                else if (logAttribStp->linkedAttrDictStp->linkedAttrDictStp != nullptr &&
                         (logAttribStp->linkedAttrDictStp->linkedAttrDictStp->refDictEntityStp == nullptr ||
                          logAttribStp->linkedAttrDictStp->linkedAttrDictStp->refDictEntityStp->objectEn == parObjectEn))
                {
                    requestHelper.setCopyIdForBatchMulti(level, recordStp, logAttribStp->linkedAttrDictStp->linkedAttrDictStp->progN, parentRecordStp, logAttribStp->dictEntityStp->primKeyTab[0]->progN);
                }
                else
                {
                    SYS_BreakOnDebug();
                }
            }
        }
    }

    if (dictEntityStp != nullptr && dictEntityStp->isId())
    {
        for (auto dictAttribStp : dictEntityStp->logicalTab)
        {
            if (IS_NULLFLD(recordStp, dictAttribStp->progN) == FALSE &&
                GET_EXTENSION_NBR(recordStp, dictAttribStp->progN) > 0 &&
                dictAttribStp != dictEntityStp->logicalTab.back())
            {
                DBA_DYNFLD_STP* extRecordsPtr = GET_EXTENSION_PTR(recordStp, dictAttribStp->progN);
                int             extRecordsNbr = GET_EXTENSION_NBR(recordStp, dictAttribStp->progN);

                FIELD_IDX_T     refAttribIdx = Null_Dynfld;

                if (dictAttribStp->linkedAttrDictStp != nullptr)
                {
                    if (dictAttribStp->linkedAttrDictStp->linkedAttrDictStp != nullptr)
                    {
                        refAttribIdx = dictAttribStp->linkedAttrDictStp->linkedAttrDictStp->progN;
                    }
                    else
                    {
                        refAttribIdx = dictAttribStp->linkedAttrDictStp->progN;
                    }
                }

                for (int i = 0; i < extRecordsNbr; ++i)
                {
                    if (refAttribIdx != Null_Dynfld &&
                        IS_NULLFLD(extRecordsPtr[i], refAttribIdx) &&
                        IS_NULLFLD(recordStp, dictEntityStp->primKeyTab[0]->progN) == false)
                    {
                        SET_ID(extRecordsPtr[i], refAttribIdx, GET_ID(recordStp, dictEntityStp->primKeyTab[0]->progN));
                    }
                    ret = DBA_SaveRecord(requestHelper, extRecordsPtr[i], recordStp, dictAttribStp, level + 1);

                    if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                    {
                        break;
                    }
                }
            }

            if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
            {
                break;
            }
        }
    }

    if (level == INIT_LEVEL && ret == RET_SUCCEED)
    {
        requestHelper.setApplyDVBatchMulti();
        requestHelper.setApplyICBatchMulti();
        requestHelper.setFlushStatBatchMulti();

        ret = requestHelper.executeBatchMulti();
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DBA_FillOneRecord()
**
**  Description :
**
**  Argument    :
**
**  Return      :
**
**  Creation  	:  PMSTA-46681 - LJE - 230912
**
**  Last modif. :
**
*************************************************************************/
RET_CODE DBA_FillAndSaveOneRecord(DbiConnectionHelper& dbiConnHelper,
                                  RequestHelper& requestHelper,
                                  BuildBindOption& buildBindOption,
                                  MemoryPool& mp,
                                  DBA_DYNFLD_STP       recordStp,
                                  subQueryMapType& subQueryMap)
{
    RET_CODE        ret = RET_SUCCEED;

    if (buildBindOption.getOutputArtefact() == BuildBindOption::OutputArtefact::WriteInDbByBatch ||
        buildBindOption.getOutputArtefact() == BuildBindOption::OutputArtefact::DelayWrite)
    {
        DBA_DYNST_ENUM  dynStEn = GET_DYNSTENUM(recordStp);
        DBA_DYNFLD_STP  oldRecordStp = nullptr;

        if (requestHelper.getDbiConn().getDdlGenDbaAccessPtr() == nullptr)
        {
            DdlGenContext* ddlGenContextPtr = new DdlGenContext(requestHelper.getDbiConn().getDbaRDBMS());
            mp.ownerObject(ddlGenContextPtr);

            ddlGenContextPtr->m_buildBindOptionPtr = &buildBindOption;

            auto ddlGenDbaAccessPtr = new DdlGenDbaAccess(*ddlGenContextPtr);
            mp.ownerObject(ddlGenDbaAccessPtr);

            requestHelper.getDbiConn().setDdlGenDbaAccessPtr(ddlGenDbaAccessPtr);
        }

        auto exportBuildBindOption(buildBindOption);

        exportBuildBindOption = BuildBindOption::Categ::CleanUpFullObject;
        requestHelper.getDbiConn().getDdlGenDbaAccessPtr()->clearProvidedRecord();
        requestHelper.getDbiConn().getDdlGenDbaAccessPtr()->setProvidedRecord(recordStp);

        oldRecordStp = mp.duplicate(FILEINFO, recordStp);

        for (int fldPos = 0; fldPos < GET_FIX_NBR(dynStEn); ++fldPos)
        {
            if (IS_SETFLD(recordStp, fldPos) == TRUE)
            {
                SET_SETFLG_T(oldRecordStp, fldPos);
            }
        }

        if (dynStEn == A_PackageComposition &&
            IS_NULLFLD(recordStp, A_PackageComposition_ObjId) &&
            GET_FK_RECORD(recordStp, A_PackageComposition_ObjId) != nullptr)
        {
            auto fkRecordStp = GET_FK_RECORD(recordStp, A_PackageComposition_ObjId);
            auto oldFkRecordStp = mp.duplicate(FILEINFO, fkRecordStp);
            bool newRecord = false;
            if (DBA_FillRecord(dbiConnHelper, exportBuildBindOption, mp, oldFkRecordStp, newRecord) == RET_SUCCEED)
            {
                SET_FK_RECORD(oldRecordStp, A_PackageComposition_ObjId, oldFkRecordStp);

                COPY_DYNFLD(fkRecordStp, fkRecordStp->getDynStEn(), fkRecordStp->getIdIdx(),
                            oldRecordStp, A_PackageComposition, A_PackageComposition_ObjId);
            }
        }

        ZipArchive::Ptr zipArchivePtr;
        DBA_FillFullRecordAndSave(oldRecordStp,
                                  exportBuildBindOption,
                                  mp,
                                  &requestHelper.getDbiConn(),
                                  subQueryMap,
                                  zipArchivePtr);
    }

    bool bFillRecord = true;
    if (buildBindOption.m_currentExecCtxStp != nullptr &&
        IS_NOTNULL(buildBindOption.m_currentExecCtxStp, ProcessingContext_Cmd))
    {
        if (strcmp(GET_STRING(buildBindOption.m_currentExecCtxStp, ProcessingContext_Cmd), "DELETE") == 0)
        {
            bFillRecord = false;
        }
    }

    if (bFillRecord)
    {
        bool newRecord = false;
        DBA_FillRecord(dbiConnHelper, buildBindOption, mp, recordStp, newRecord);
    }

    if (buildBindOption.getOutputArtefact() == BuildBindOption::OutputArtefact::WriteInDb)
    {
        ret = DBA_SaveRecord(requestHelper, recordStp);
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DBA_FillFullRecord()
**
**  Description :
**
**  Argument    :
**
**  Return      :
**
**  Creation  	:  PMSTA-45027 - LJE - 210430
**
**  Last modif. :
**
*************************************************************************/
RET_CODE DBA_FillFullRecord(DBA_DYNFLD_STP       recordStp,
                            BuildBindOption& buildBindOption,
                            MemoryPool& mp,
                            DbiConnectionHelper& dbiConnHelper,
                            subQueryMapType& subQueryMap)
{
    std::vector<DBA_DYNFLD_STP> recordVector;
    recordVector.push_back(recordStp);

    return DBA_FillFullRecords(recordVector,
                               buildBindOption,
                               mp,
                               dbiConnHelper,
                               subQueryMap);
}

/************************************************************************
**
**  Function    :   DBA_FillFullRecords()
**
**  Description :
**
**  Argument    :
**
**  Return      :
**
**  Creation  	:  PMSTA-45027 - LJE - 210430
**
**  Last modif. :
**
*************************************************************************/
RET_CODE DBA_FillFullRecords(std::vector<DBA_DYNFLD_STP>& recordsVector,
                             BuildBindOption& buildBindOption,
                             MemoryPool& mp,
                             DbiConnectionHelper& dbiConnHelper,
                             subQueryMapType& subQueryMap)
{
    RET_CODE ret = RET_SUCCEED;

    for (auto& recordStp : recordsVector)
    {
        bool newRecord = false;
        if (DBA_FillRecord(dbiConnHelper, buildBindOption, mp, recordStp, newRecord) != RET_SUCCEED)
        {
            ret = RET_DBA_ERR_INVDATA;
        }

        if (newRecord &&
            (buildBindOption == BuildBindOption::Categ::ExportFullObject ||
             buildBindOption == BuildBindOption::Categ::ExportCopyObject) &&
            recordStp->getObjectEn() != ExportQuery &&
            recordStp->getObjectEn() != CopyArg &&
            recordStp->getObjectEn() != PackageDefinition &&
            recordStp->getObjectEn() != PackageComposition)
        {
            BuildBindOption errBuildBindOption(BuildBindOption::Categ::BusinessKeyOnlyShort);
            errBuildBindOption.setDescObject(true);

            std::string                 errString;
            std::vector<DBA_DYNFLD_STP> errDynStpVector;
            errDynStpVector.push_back(recordStp);

            if (DBA_GetJSonStringFromDynStp(errDynStpVector,
                                            errString,
                                            errBuildBindOption,
                                            *dbiConnHelper.getConnection()) == RET_SUCCEED)
            {
                buildBindOption.printMsg(ProcessingMessageNatEn::Error, ret, SYS_Stringer("unknown record: ", errString));
            }

            recordStp = nullptr;
        }
    }

    recordsVector.erase(std::remove(begin(recordsVector), end(recordsVector), nullptr), end(recordsVector));
    if (recordsVector.empty())
    {
        return RET_DBA_ERR_NODATA;
    }

    if (buildBindOption.isImportExport() &&
        recordsVector.back()->getObjectEn() != PackageDefinition)
    {
        std::map<OBJECT_ENUM, std::vector<DBA_DYNFLD_STP>> subRecordsMap;

        DBA_FillCache(dbiConnHelper, buildBindOption, recordsVector, mp, subRecordsMap, subQueryMap);

        while (subRecordsMap.empty() == false)
        {
            std::map<OBJECT_ENUM, std::vector<DBA_DYNFLD_STP>> newSubRecordsMap;
            for (auto& it : subRecordsMap)
            {
                DBA_FillCache(dbiConnHelper, buildBindOption, it.second, mp, newSubRecordsMap, subQueryMap);
            }
            subRecordsMap = newSubRecordsMap;
        }
    }

    std::map<OBJECT_ENUM, std::map<ID_T, DBA_DYNFLD_STP>> allRecordsMap;

    for (auto recordStp : recordsVector)
    {
        if (recordStp->getIdIdx() > Null_Dynfld)
        {
            allRecordsMap[recordStp->getObjectEn()][GET_ID(recordStp, recordStp->getIdIdx())] = recordStp;
        }
    }

    for (auto recordStp : recordsVector)
    {
        std::vector<DBA_DYNFLD_STP> subRecordsVector;
        DBA_FillRecordExtension(dbiConnHelper, buildBindOption, recordStp, mp, subRecordsVector, allRecordsMap, subQueryMap);

        if (subRecordsVector.empty() == false)
        {
            if (recordStp->getObjectEn() == PackageDefinition)
            {
                auto ddlGenDbaAccessPtr = dbiConnHelper.getConnection()->getDdlGenDbaAccessPtr();

                std::vector<DBA_DYNFLD_STP> groupRecordsVector;

                for (auto& pckCompoStp : subRecordsVector)
                {
                    if (groupRecordsVector.empty() == false &&
                        GET_DICT(pckCompoStp, A_PackageComposition_EntityDictId) != GET_DICT(groupRecordsVector.back(), A_PackageComposition_EntityDictId))
                    {
                        ddlGenDbaAccessPtr->setPackageCompositionStp(pckCompoStp);
                        if (DBA_FillFullRecords(groupRecordsVector,
                                                buildBindOption,
                                                mp,
                                                dbiConnHelper,
                                                subQueryMap) != RET_SUCCEED)
                        {
                            ret = RET_DBA_ERR_INVDATA;
                        }
                        ddlGenDbaAccessPtr->setPackageCompositionStp(nullptr);
                        groupRecordsVector.clear();
                    }

                    auto dictEntityStp = DBA_GetDictEntityByDictIdSafe(GET_DICT(pckCompoStp, A_PackageComposition_EntityDictId));
                    buildBindOption.printMsg(ProcessingMessageNatEn::Info,
                                             RET_SUCCEED,
                                             SYS_Stringer("processing entry: { \"", dictEntityStp->mdSqlName, "\" : ", GET_NOTE(pckCompoStp, A_PackageComposition_Key), " }"));

                    groupRecordsVector.push_back(pckCompoStp);
                }

                if (DBA_FillFullRecords(groupRecordsVector,
                                        buildBindOption,
                                        mp,
                                        dbiConnHelper,
                                        subQueryMap) != RET_SUCCEED)
                {
                    ret = RET_DBA_ERR_INVDATA;
                }
            }
            else
            {
                while (subRecordsVector.empty() == false)
                {
                    std::vector<DBA_DYNFLD_STP> newSubRecordsVector;
                    for (auto& it : subRecordsVector)
                    {
                        DBA_FillRecordExtension(dbiConnHelper, buildBindOption, it, mp, newSubRecordsVector, allRecordsMap, subQueryMap);
                    }
                    subRecordsVector = newSubRecordsVector;
                }
            }
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DBA_FillFromPackageDefinition()
**
**  Description :
**
**  Argument    :
**
**  Return      :
**
**  Creation  	:  PMSTA-45027 - LJE - 210430
**
**  Last modif. :
**
*************************************************************************/
RET_CODE DBA_FillFromPackageDefinition(DBA_DYNFLD_STP      pckDefStp,
                                       DBA_DYNFLD_STP      manifestStp,
                                       BuildBindOption& buildBindOption,
                                       MemoryPool& mp,
                                       DbiConnectionHelper& dbiConnHelper,
                                       subQueryMapType& subQueryMap)
{
    RET_CODE gblRet = RET_SUCCEED;

    auto natPtr = DBA_GetPermValPtr(PackageDefinition, A_PackageDefinition_NatEn, GET_ENUM(pckDefStp, A_PackageDefinition_NatEn));
    if (natPtr != nullptr)
    {
        SET_CODE(manifestStp, O_PackageDefinition_Nature, natPtr);
    }
    auto statusPtr = DBA_GetPermValPtr(PackageDefinition, A_PackageDefinition_StatusEn, GET_ENUM(pckDefStp, A_PackageDefinition_StatusEn));
    if (statusPtr != nullptr)
    {
        SET_CODE(manifestStp, O_PackageDefinition_Status, statusPtr);
    }
    COPY_DYNFLD(manifestStp, O_PackageDefinition, O_PackageDefinition_Denomination, pckDefStp, A_PackageDefinition, A_PackageDefinition_Denom);
    COPY_DYNFLD(manifestStp, O_PackageDefinition, O_PackageDefinition_Name, pckDefStp, A_PackageDefinition, A_PackageDefinition_Name);
    COPY_DYNFLD(manifestStp, O_PackageDefinition, O_PackageDefinition_RequiredCoreVersion, pckDefStp, A_PackageDefinition, A_PackageDefinition_ReqCoreVersion);

    DBA_DYNFLD_STP parentDefStp = nullptr;
    if (IS_NOTNULL(pckDefStp, A_PackageDefinition_ParentPackageDefinitionId) &&
        (parentDefStp = GET_FK_RECORD(pckDefStp, A_PackageDefinition_ParentPackageDefinitionId)) != nullptr)
    {
        COPY_DYNFLD(manifestStp, O_PackageDefinition, O_PackageDefinition_ParentPackageCode, parentDefStp, A_PackageDefinition, A_PackageDefinition_Cd);
        COPY_DYNFLD(manifestStp, O_PackageDefinition, O_PackageDefinition_ParentPackageVersion, parentDefStp, A_PackageDefinition, A_PackageDefinition_Version);
    }

    if (IS_NULLFLD(pckDefStp, A_PackageDefinition_PackageCompositionId) == false &&
        GET_EXTENSION_PTR(pckDefStp, A_PackageDefinition_PackageCompositionId) != nullptr)
    {
        auto pckCompoNbr = GET_EXTENSION_NBR(pckDefStp, A_PackageDefinition_PackageCompositionId);
        auto pckCompoTab = GET_EXTENSION_PTR(pckDefStp, A_PackageDefinition_PackageCompositionId);

        for (int i = 0; i < pckCompoNbr; ++i)
        {
            auto pckCompoStp = pckCompoTab[i];

            if (GET_FK_RECORD(pckCompoStp, A_PackageComposition_ObjId) == nullptr)
            {
                auto entDictId = GET_DICT(pckCompoStp, A_PackageComposition_EntityDictId);
                auto dictEntityStp = DBA_GetDictEntityByDictIdSafe(entDictId);

                std::stringstream fullKeyStream;

                fullKeyStream
                    << "{ \"" << dictEntityStp->mdSqlName << "\" : "
                    << GET_NOTE(pckCompoStp, A_PackageComposition_Key)
                    << "}";

                ZipArchive::Ptr zipArchivePtr;
                std::vector<DBA_DYNFLD_STP> outputDynStpVector;
                RET_CODE ret = DBA_GetDynStpFromJSonString(fullKeyStream.str(), outputDynStpVector, buildBindOption, mp, *dbiConnHelper.getConnection(), true, subQueryMap, zipArchivePtr);

                if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                {
                    gblRet = ret;
                }

                if (outputDynStpVector.empty() == false)
                {
                    SET_FK_RECORD(pckCompoStp, A_PackageComposition_ObjId, outputDynStpVector.back());
                }
            }
        }

        COPY_EXTENSION(manifestStp, O_PackageDefinition_PackageComposition, pckDefStp, A_PackageDefinition_PackageCompositionId);
    }

    return gblRet;
}

/************************************************************************
**
**  Function    :   DBA_FlushPckDef()
**
**  Description :
**
**  Argument    :
**
**  Return      :
**
**  Creation  	:  PMSTA-45027 - LJE - 210430
**
**  Last modif. :
**
*************************************************************************/
RET_CODE DBA_FlushPckDef(std::vector<DBA_DYNFLD_STP>& pckDefStpVector,
                         MemoryPool& mp,
                         DbiConnection* dbiConnPtr)
{
    RET_CODE                  ret = RET_SUCCEED;
    DbiConnectionHelper       dbiConnHelper(dbiConnPtr);
    auto ddlGenDbaAccessPtr = dbiConnHelper.getConnection()->getDdlGenDbaAccessPtr();

    DdlGenAction    ddlGenAction;
    ddlGenAction.m_logLevel = 99;
    ddlGenAction.m_fromImport = true;
    ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_AllTable;
    ddlGenAction.m_mainDdlObjNatEn = ddlGenAction.m_ddlObjNatEn;
    ddlGenAction.m_entitySqlnameStr = "to_insert";

    SYS_SetProgramState(ProgramState::InitializationGeneric);
    EV_AAAInstallLevel = 1;

    auto ddlGenRet = DDL_InstallDdlObject(ddlGenAction, ddlGenDbaAccessPtr->getDdlGenContext());

    EV_AAAInstallLevel = 0;
    SYS_SetProgramState(ProgramState::Running);

    if (RET_GET_LEVEL(ddlGenRet) != RET_LEV_ERROR)
    {
        ret = ddlGenDbaAccessPtr->flushData();
    }
    else
    {
        ret = ddlGenRet;
    }

    dbiConnHelper.setFromDbaAccess();
    for (auto& pckDefStp : pckDefStpVector)
    {
        if (RET_GET_LEVEL(ret) == RET_LEV_ERROR &&
            GET_ID(pckDefStp, A_PackageDefinition_Id) < 0)
        {
            dbiConnHelper.dbaInsert(A_PackageDefinition, UNUSED, pckDefStp);
        }

        if (ret == RET_GEN_INFO_NOACTION && ddlGenRet == RET_GEN_INFO_NOACTION)
        {
            auto pckInstStp = mp.allocDynst(FILEINFO, S_PackageInstallation);

            COPY_DYNFLD(pckInstStp, S_PackageInstallation, S_PackageInstallation_Cd, pckDefStp, A_PackageDefinition, A_PackageDefinition_Cd);
            COPY_DYNFLD(pckInstStp, S_PackageInstallation, S_PackageInstallation_Version, pckDefStp, A_PackageDefinition, A_PackageDefinition_Version);
            (void)dbiConnHelper.dbaGet(PackageInstallation, DBA_ROLE_PACKAGE_DEF_INSTALLATION, pckInstStp, &pckInstStp);
            if (IS_NULLFLD(pckInstStp, S_PackageInstallation_Id))
            {
                ret = RET_SUCCEED;
            }
        }

        if ((ret != RET_GEN_INFO_NOACTION || ddlGenRet != RET_GEN_INFO_NOACTION) &&
            GET_ID(pckDefStp, A_PackageDefinition_Id) > 0)
        {
            auto pckInstStp = mp.allocDynst(FILEINFO, A_PackageInstallation);

            COPY_DYNFLD(pckInstStp, A_PackageInstallation, A_PackageInstallation_PackageDefinitionId,
                        pckDefStp, A_PackageDefinition, A_PackageDefinition_Id);
            COPY_DYNFLD(pckInstStp, A_PackageInstallation, A_PackageInstallation_Cd,
                        pckDefStp, A_PackageDefinition, A_PackageDefinition_Cd);
            COPY_DYNFLD(pckInstStp, A_PackageInstallation, A_PackageInstallation_Version,
                        pckDefStp, A_PackageDefinition, A_PackageDefinition_Version);

            if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
            {
                SET_A_PackageInstallation_StatusEn(pckInstStp, PackageInstallationStatusEn::Failed);
            }
            else
            {
                SET_A_PackageInstallation_StatusEn(pckInstStp, PackageInstallationStatusEn::Successful);
            }

            DATETIME_T currDateTime;
            DATE_CurrentDateTime(&currDateTime);
            SET_DATETIME(pckInstStp, A_PackageInstallation_InstallDate, currDateTime);

            dbiConnHelper.dbaInsert(PackageInstallation, UNUSED, pckInstStp);
        }
    }
    dbiConnHelper.resetFromDbaAccess();

    if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
    {
        ret = RET_SUCCEED;
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DBA_FillFullRecordAndSave()
**
**  Description :
**
**  Argument    :
**
**  Return      :
**
**  Creation  	:  PMSTA-45027 - LJE - 210430
**
**  Last modif. :
**
*************************************************************************/
RET_CODE DBA_FillFullRecordAndSave(DBA_DYNFLD_STP   recordStp,
                                   BuildBindOption& buildBindOption,
                                   MemoryPool& mp,
                                   DbiConnection* dbiConnPtr,
                                   subQueryMapType& subQueryMap,
                                   ZipArchive::Ptr  zipArchivePtr)
{
    RET_CODE ret = RET_SUCCEED;

    DbiConnectionHelper   dbiConnHelper(dbiConnPtr);

    if (dbiConnHelper.isValidAndInit())
    {
        DBA_DYNST_ENUM dynStEn = GET_DYNSTENUM(recordStp);
        OBJECT_ENUM    objectEn = GET_DYNST_ENTITY(dynStEn);

        dbiConnHelper.dbaSetOptions(DBA_NO_PROC_ERROR);

        if (buildBindOption.isImportExport() &&
            EV_AAAInstallLevel < 5)
        {
            buildBindOption.fillConfig(recordStp);
        }

        if (dynStEn != NullDynSt)
        {
            if (dynStEn == A_ExportQuery)
            {
                if (buildBindOption == BuildBindOption::Categ::ImportFullObject)
                {
                    if (GET_EXTENSION_NBR(recordStp, A_ExportQuery_ExportObj) > 0)
                    {
                        DBA_DYNFLD_STP* objRecordsTab = GET_EXTENSION_PTR(recordStp, A_ExportQuery_ExportObj);
                        int             objRecordsNbr = GET_EXTENSION_NBR(recordStp, A_ExportQuery_ExportObj);

                        RequestHelper   requestHelper(dbiConnHelper);

                        for (int i = 0; i < objRecordsNbr; ++i)
                        {
                            DBA_FillAndSaveOneRecord(dbiConnHelper,
                                                     requestHelper,
                                                     buildBindOption,
                                                     mp,
                                                     objRecordsTab[i],
                                                     subQueryMap);
                        }

                        if (buildBindOption.getOutputArtefact() == BuildBindOption::OutputArtefact::WriteInDbByBatch)
                        {
                            auto ddlGenDbaAccessPtr = dbiConnHelper.getConnection()->getDdlGenDbaAccessPtr();
                            ret = ddlGenDbaAccessPtr->flushData();
                        }
                    }
                }
                else
                {
                    DBA_FillFullRecord(recordStp,
                                       buildBindOption,
                                       mp,
                                       dbiConnHelper,
                                       subQueryMap);

                    if (IS_NULLFLD(recordStp, A_ExportQuery_ExportQuery) == FALSE)
                    {
                        std::string objFilter = GET_STRING(recordStp, A_ExportQuery_ExportQuery);
                        BuildBindOption::fixJSonString(objFilter);

                        DBA_DYNFLD_STP* outputTab = nullptr;
                        int              outputNbr = 0;

                        if ((ret = DBA_EvalFilterScript(objFilter.c_str(),
                                                        recordStp,
                                                        GET_DICT(recordStp, A_ExportQuery_EntityDictId),
                                                        dbiConnHelper.getConnection(),
                                                        &outputTab,
                                                        &outputNbr,
                                                        true)) == RET_SUCCEED &&
                            outputNbr > 0)
                        {
                            std::vector<DBA_DYNFLD_STP> subRecordVector;

                            for (int i = 0; i < outputNbr; ++i)
                            {
                                mp.ownerDynStp(outputTab[i]);
                                subRecordVector.push_back(outputTab[i]);
                            }

                            DBA_FillFullRecords(subRecordVector,
                                                buildBindOption,
                                                mp,
                                                dbiConnHelper,
                                                subQueryMap);

                            FREE_EXTENSION(recordStp, A_ExportQuery_ExportObj);
                            SET_EXTENSION(recordStp, A_ExportQuery_ExportObj, outputTab, GET_DYNSTENUM(outputTab[0]), outputNbr);
                        }
                        else
                        {
                            buildBindOption.printMsg(ProcessingMessageNatEn::Error,
                                                     ret,
                                                     SYS_Stringer("Unable to eval the filter script : ", objFilter));
                        }

                    }
                    else if (GET_EXTENSION_NBR(recordStp, A_ExportQuery_ExportObj) > 0)
                    {
                        DBA_DYNFLD_STP* objRecordsTab = GET_EXTENSION_PTR(recordStp, A_ExportQuery_ExportObj);
                        int             objRecordsNbr = GET_EXTENSION_NBR(recordStp, A_ExportQuery_ExportObj);

                        std::vector<DBA_DYNFLD_STP> subRecordVector;
                        for (int i = 0; i < objRecordsNbr; ++i)
                        {
                            subRecordVector.push_back(objRecordsTab[i]);
                        }

                        DBA_FillFullRecords(subRecordVector,
                                            buildBindOption,
                                            mp,
                                            dbiConnHelper,
                                            subQueryMap);

                        if (CAST_INT(subRecordVector.size()) != objRecordsNbr)
                        {
                            FREE_EXTENSION(recordStp, A_ExportQuery_ExportObj);

                            if (subRecordVector.empty() == false)
                            {
                                DBA_DYNFLD_STP* outputTab = static_cast<DBA_DYNFLD_STP*>(CALLOC(subRecordVector.size(), sizeof(DBA_DYNFLD_STP)));
                                int              outputNbr = 0;

                                for (auto& subRecordStp : subRecordVector)
                                {
                                    outputTab[outputNbr++] = subRecordStp;
                                }

                                SET_EXTENSION(recordStp, A_ExportQuery_ExportObj, outputTab, GET_DYNSTENUM(outputTab[0]), outputNbr);
                            }
                        }
                    }
                    else
                    {
                        ret = RET_DBA_ERR_INVDATA;
                    }
                }
            }
            else if (dynStEn == O_PackageDefinition)
            {
                buildBindOption.setLogLevel(ProcessingMessageNatEn::Info);

                auto pckDefStp = mp.allocDynst(FILEINFO, A_PackageDefinition);

                COPY_DYNFLD(pckDefStp, A_PackageDefinition, A_PackageDefinition_Cd, recordStp, O_PackageDefinition, O_PackageDefinition_Code);
                COPY_DYNFLD(pckDefStp, A_PackageDefinition, A_PackageDefinition_Version, recordStp, O_PackageDefinition, O_PackageDefinition_Version);

                {
                    auto loadBuildBindOption = buildBindOption;
                    if (buildBindOption == BuildBindOption::Categ::ImportFullObject)
                    {
                        /* Load all the package to be able to clean-up it */
                        loadBuildBindOption = BuildBindOption::Categ::CleanUpFullObject;
                    }

                    loadBuildBindOption.setConfig("package_definition", "parent_package_definition_id", "Business Key", EntityConfigElementRuleEn::Keep);

                    ret = DBA_FillFullRecord(pckDefStp,
                                             loadBuildBindOption,
                                             mp,
                                             dbiConnHelper,
                                             subQueryMap);
                }

                if (ret == RET_SUCCEED)
                {
                    if (buildBindOption.isExport())
                    {
                        ret = DBA_FillFromPackageDefinition(pckDefStp,
                                                            recordStp,
                                                            buildBindOption,
                                                            mp,
                                                            dbiConnHelper,
                                                            subQueryMap);
                    }
                    else if (buildBindOption == BuildBindOption::Categ::ImportFullObject)
                    {
                        std::vector<std::pair<std::string, std::pair<std::string, int>>>  fileToLoadVector;

                        if (buildBindOption.isZipFile())
                        {
                            if (zipArchivePtr == nullptr)
                            {
                                zipArchivePtr = ZipFile::Open(buildBindOption.getFullFileName());
                            }
                            auto            entries = zipArchivePtr->GetEntriesCount();
                            for (size_t i = 0; i < entries; ++i)
                            {
                                auto entry = zipArchivePtr->GetEntry(CAST_INT(i));
                                if (entry->IsDirectory() == false &&
                                    entry->GetName().find(".json") == entry->GetName().size() - 5 &&
                                    entry->GetName() != MANIFEST)
                                {
                                    fileToLoadVector.push_back(std::make_pair(buildBindOption.getFullFileName(), std::make_pair(entry->GetName(), CAST_INT(i))));
                                }
                            }
                        }
                        else
                        {
                            std::vector<SYS_FileInfo> fileList;

                            if (SYS_DIRentryList(buildBindOption.getRootPath(), fileList, true))
                            {
                                for (auto fileIt = fileList.begin(); fileIt != fileList.end(); ++fileIt)
                                {
                                    if (fileIt->isFile &&
                                        fileIt->isReadable &&
                                        fileIt->fileName.find(".json") == fileIt->fileName.size() - 5 &&
                                        fileIt->fileName != MANIFEST)
                                    {
                                        fileToLoadVector.push_back(make_pair(fileIt->dirName, std::make_pair(fileIt->fileName, -1)));
                                    }
                                }
                            }
                        }

                        buildBindOption.printMsg(ProcessingMessageNatEn::Info,
                                                 RET_SUCCEED,
                                                 SYS_Stringer("processing package: ",
                                                              GET_CODE(recordStp, O_PackageDefinition_Code),
                                                              " - ",
                                                              GET_CODE(recordStp, O_PackageDefinition_Version)));

                        auto ddlGenDbaAccessPtr = dbiConnHelper.getConnection()->getDdlGenDbaAccessPtr();
                        ddlGenDbaAccessPtr->insUpdDelRecord(Insert, PackageDefinition, UNUSED, pckDefStp, true);

                        COPY_DYNFLD(pckDefStp, A_PackageDefinition, A_PackageDefinition_Denom, recordStp, O_PackageDefinition, O_PackageDefinition_Denomination);
                        COPY_DYNFLD(pckDefStp, A_PackageDefinition, A_PackageDefinition_Name, recordStp, O_PackageDefinition, O_PackageDefinition_Name);
                        auto enumValue = DBA_GetPermValEnum(PackageDefinition, A_PackageDefinition_NatEn, GET_CODE(recordStp, O_PackageDefinition_Nature));
                        SET_ENUM(pckDefStp, A_PackageDefinition_NatEn, enumValue);

                        DBA_DYNFLD_STP* outputTab = static_cast<DBA_DYNFLD_STP*>(CALLOC(1, sizeof(DBA_DYNFLD_STP)));
                        int             outputNbr = 1;
                        outputTab[0] = pckDefStp;
                        SET_EXTENSION(recordStp, O_PackageDefinition_PackageDefinition, outputTab, A_PackageDefinition, outputNbr);

                        std::vector<DBA_DYNFLD_STP> inputDynStpVector;
                        {
                            BuildBindOptionGuard buildBindOptionGuard(buildBindOption);
                            buildBindOption.setOutputArtefact(BuildBindOption::OutputArtefact::DelayWrite);
                            buildBindOption.setPckDefStp(pckDefStp);

                            for (auto& it : fileToLoadVector)
                            {
                                buildBindOption.setFilePathInfo(it.first, it.second.first, it.second.second);

                                ret = DBA_GetDynStpFromJSonString(std::string(),
                                                                  inputDynStpVector,
                                                                  buildBindOption,
                                                                  mp,
                                                                  *dbiConnHelper.getConnection(),
                                                                  true,
                                                                  subQueryMap,
                                                                  zipArchivePtr);
                            }
                        }

                        if (EV_OptiMemFlg == TRUE &&
                            inputDynStpVector.empty() == false &&
                            buildBindOption.getOutputArtefact() == BuildBindOption::OutputArtefact::WriteInDbByBatch)
                        {
                            std::vector<DBA_DYNFLD_STP> pckDefStpVector;
                            pckDefStpVector.push_back(pckDefStp);

                            ret = DBA_FlushPckDef(pckDefStpVector, mp, dbiConnPtr);
                        }
                    }
                }
            }
            else if (objectEn != NullEntity && objectEn != InvalidEntity)
            {
                if (GET_FLD_NBR(GET_ADMINGUIST(objectEn)) > 0)
                {
                    if (buildBindOption.isExport())
                    {
                        ret = DBA_FillFullRecord(recordStp,
                                                 buildBindOption,
                                                 mp,
                                                 dbiConnHelper,
                                                 subQueryMap);

                        if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                        {
                            buildBindOption.printMsg(ProcessingMessageNatEn::Error, ret, "Unable to export the data");
                        }
                    }
                    else if (buildBindOption == BuildBindOption::Categ::ImportFullObject)
                    {
                        if (dynStEn == A_PackageComposition)
                        {
                            auto ddlGenDbaAccessPtr = dbiConnHelper.getConnection()->getDdlGenDbaAccessPtr();

                            if (IS_NULLFLD(recordStp, A_PackageComposition_PackageDefinitionId) &&
                                buildBindOption.getPckDefStp() != nullptr)
                            {
                                SET_FK_RECORD(recordStp, A_PackageComposition_PackageDefinitionId, buildBindOption.getPckDefStp());
                            }

                            ddlGenDbaAccessPtr->setPackageCompositionStp(recordStp);
                        }

                        RequestHelper   requestHelper(dbiConnHelper);

                        DBA_FillAndSaveOneRecord(dbiConnHelper,
                                                 requestHelper,
                                                 buildBindOption,
                                                 mp,
                                                 recordStp,
                                                 subQueryMap);

                        if (buildBindOption.getOutputArtefact() == BuildBindOption::OutputArtefact::WriteInDbByBatch)
                        {
                            auto ddlGenDbaAccessPtr = dbiConnHelper.getConnection()->getDdlGenDbaAccessPtr();
                            ret = ddlGenDbaAccessPtr->flushData();
                        }

                        if (dynStEn == A_PackageComposition)
                        {
                            auto ddlGenDbaAccessPtr = dbiConnHelper.getConnection()->getDdlGenDbaAccessPtr();
                            ddlGenDbaAccessPtr->setPackageCompositionStp(nullptr);
                        }
                    }
                    else
                    {
                        bool newRecord = false;
                        ret = DBA_FillRecord(dbiConnHelper,
                                             buildBindOption,
                                             mp,
                                             recordStp,
                                             newRecord);
                    }
                }
            }
        }
    }
    else
    {
        ret = RET_DBA_ERR_CONNOTFOUND;
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DBA_GetDynStpFromJSonString()
**
**  Description :
**
**  Argument    :
**
**  Return      :
**
**  Creation  	:  PMSTA-45027 - LJE - 210430
**
**  Last modif. :
**
*************************************************************************/
RET_CODE DBA_GetDynStpFromJSonString(const std::string& inputString,
                                     std::vector<DBA_DYNFLD_STP>& outputDynStpVector,
                                     BuildBindOption& buildBindOption,
                                     MemoryPool& mp,
                                     DbiConnection& dbiConn,
                                     bool                        bTryGetFromDatabase)
{
    subQueryMapType subQueryMap;
    ZipArchive::Ptr zipArchivePtr;

    return DBA_GetDynStpFromJSonString(inputString,
                                       outputDynStpVector,
                                       buildBindOption,
                                       mp,
                                       dbiConn,
                                       bTryGetFromDatabase,
                                       subQueryMap,
                                       zipArchivePtr);
}

/************************************************************************
**
**  Function    :   DBA_GetDynStpFromJSonString()
**
**  Description :
**
**  Argument    :
**
**  Return      :
**
**  Creation  	:  PMSTA-45027 - LJE - 210430
**
**  Last modif. :
**
*************************************************************************/
RET_CODE DBA_GetDynStpFromJSonString(const std::string& inputString,
                                     std::vector<DBA_DYNFLD_STP>& outputDynStpVector,
                                     BuildBindOption& buildBindOption,
                                     MemoryPool& mp,
                                     DbiConnection& dbiConn,
                                     bool                         bTryGetFromDatabase,
                                     subQueryMapType& subQueryMap,
                                     ZipArchive::Ptr              zipArchivePtr)
{
    RET_CODE gblRet = RET_SUCCEED;

    try
    {
        RET_CODE ret = RET_SUCCEED;

        if (buildBindOption.isImportExport() &&
            dbiConn.getDdlGenDbaAccessPtr() == nullptr)
        {
            DdlGenContext* ddlGenContextPtr = new DdlGenContext(dbiConn.getDbaRDBMS());
            mp.ownerObject(ddlGenContextPtr);

            ddlGenContextPtr->m_buildBindOptionPtr = &buildBindOption;

            ddlGenContextPtr->ddlGenAction.m_fromImport = true;
            ddlGenContextPtr->ddlGenAction.m_ddlObjNatEn = DbObjDdlObjNat_AllTable;
            ddlGenContextPtr->ddlGenAction.m_mainDdlObjNatEn = ddlGenContextPtr->ddlGenAction.m_ddlObjNatEn;

            auto ddlGenDbaAccessPtr = new DdlGenDbaAccess(*ddlGenContextPtr);
            mp.ownerObject(ddlGenDbaAccessPtr);

            dbiConn.setDdlGenDbaAccessPtr(ddlGenDbaAccessPtr);
        }

        ZipArchive::Ptr archive = nullptr;

        if (inputString.empty())
        {
            bool                                                bPckDef = false;
            bool                                                bFullDir = false;
            std::vector<std::pair<std::string, int>>            fileVector;
            std::vector<std::pair<std::string, DBA_DYNFLD_STP>> pckDefVector;

            if (buildBindOption.getFileName().empty())
            {
                if (buildBindOption.getZipEntryPos() >= 0)
                {
                    if (zipArchivePtr == nullptr)
                    {
                        zipArchivePtr = ZipFile::Open(buildBindOption.getFullFileName());
                    }

                    fileVector.push_back(std::make_pair(buildBindOption.getFullFileName(), buildBindOption.getZipEntryPos()));
                }
                else
                {
                    std::vector<SYS_FileInfo> fileList;

                    if (SYS_DIRentryList(buildBindOption.getRootPath(), fileList, true))
                    {
                        for (auto fileIt = fileList.begin(); fileIt != fileList.end(); ++fileIt)
                        {
                            if (fileIt->isFile &&
                                fileIt->isReadable &&
                                fileIt->fileName == MANIFEST)
                            {
                                bPckDef = true;
                                fileVector.push_back(std::make_pair(fileIt->fullPath, -1));
                            }
                        }

                        if (fileVector.empty())
                        {
                            buildBindOption.setOutputArtefact(BuildBindOption::OutputArtefact::DelayWrite);

                            for (auto fileIt = fileList.begin(); fileIt != fileList.end(); ++fileIt)
                            {
                                if (fileIt->isFile &&
                                    fileIt->isReadable &&
                                    fileIt->fileName.find(".json") == fileIt->fileName.size() - 5)
                                {
                                    bFullDir = true;
                                    fileVector.push_back(std::make_pair(fileIt->fullPath, -1));
                                }
                            }
                        }
                    }
                }
            }
            else if (buildBindOption.isZipFile())
            {
                if (zipArchivePtr == nullptr)
                {
                    zipArchivePtr = ZipFile::Open(buildBindOption.getFullFileName());
                }
                auto            entries = zipArchivePtr->GetEntriesCount();
                for (size_t i = 0; i < entries; ++i)
                {
                    auto entry = zipArchivePtr->GetEntry(CAST_INT(i));

                    if (entry->IsDirectory() == false &&
                        (entry->GetName() == MANIFEST ||
                         BuildBindOption::isZipFileType(entry->GetName())))
                    {
                        bPckDef = true;
                        fileVector.push_back(std::make_pair(entry->GetFullName(), CAST_INT(i)));
                    }
                }

                if (fileVector.empty())
                {
                    buildBindOption.setOutputArtefact(BuildBindOption::OutputArtefact::DelayWrite);

                    for (size_t i = 0; i < entries; ++i)
                    {
                        auto entry = zipArchivePtr->GetEntry(CAST_INT(i));

                        if (entry->IsDirectory() == false &&
                            entry->GetName().find(".json") == entry->GetName().size() - 5)
                        {
                            bFullDir = true;
                            fileVector.push_back(std::make_pair(entry->GetFullName(), CAST_INT(i)));
                        }
                    }
                }
            }
            else
            {
                fileVector.push_back(std::make_pair(buildBindOption.getFullFileName(), -1));
            }

            for (auto& it : fileVector)
            {
                QFileInfo fileInfo(it.first.c_str());
                std::stringstream inputStream;

                BuildBindOptionGuard buildBindOptionGuard(buildBindOption);
                buildBindOption.setFilePathInfo(fileInfo.path().toStdString(), fileInfo.fileName().toStdString());

                if (it.second < 0)
                {
                    buildBindOption.printMsg(ProcessingMessageNatEn::Info, RET_SUCCEED, SYS_Stringer("processing file: ", it.first));

                    std::ifstream     inputFile;

                    inputFile.open(it.first, std::ifstream::in | std::ifstream::binary);
                    if (inputFile.fail() == false)
                    {
                        std::string lineStr;
                        while (getline(inputFile, lineStr))
                        {
                            inputStream << lineStr << std::endl;
                        }

                        if (it.first.find(".xml") == it.first.length() - 4)
                        {
                            auto json_str = xml2json(inputStream.str().c_str());
                            inputStream.clear();
                            inputStream.str(std::string());
                            inputStream << json_str;
                        }
                    }
                    else
                    {
                        ret = RET_GEN_ERR_INVARG;

                        buildBindOption.printMsg(ProcessingMessageNatEn::Error, ret, SYS_Stringer("unknown file: ", it.first));
                    }
                    inputFile.close();
                }
                else if (zipArchivePtr != nullptr)
                {
                    auto entry = zipArchivePtr->GetEntry(it.second);
                    std::istream* dataStream = entry->GetDecompressionStream();

                    if (BuildBindOption::isZipFileType(entry->GetName()))
                    {
                        std::stringstream subStream;
                        utils::stream::copy(*dataStream, subStream);

                        buildBindOption.printMsg(ProcessingMessageNatEn::Success, RET_SUCCEED, SYS_Stringer("processing ZIP file: ", entry->GetFullName()));

                        ZipArchive::Ptr subZipArchivePtr = ZipArchive::Create(subStream);

                        ret = DBA_GetDynStpFromJSonString(std::string(),
                                                          outputDynStpVector,
                                                          buildBindOption,
                                                          mp,
                                                          dbiConn,
                                                          true,
                                                          subQueryMap,
                                                          subZipArchivePtr);

                        if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                        {
                            gblRet = ret;
                        }
                    }
                    else
                    {
                        buildBindOption.printMsg(ProcessingMessageNatEn::Info, RET_SUCCEED, SYS_Stringer("processing file: ", buildBindOption.getFullFileName(), "::", entry->GetFullName()));
                        utils::stream::copy(*dataStream, inputStream);
                    }
                }

                if (inputStream.str().empty() == false)
                {
                    ret = DBA_GetDynStpFromJSonString(inputStream.str(),
                                                      outputDynStpVector,
                                                      buildBindOption,
                                                      mp,
                                                      dbiConn,
                                                      bPckDef == false,
                                                      subQueryMap,
                                                      zipArchivePtr);

                    if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                    {
                        gblRet = ret;
                        buildBindOption.printMsg(ProcessingMessageNatEn::Error, ret, SYS_Stringer("Processing of file ", it.first, " failed"));
                    }
                    else
                    {
                        buildBindOption.printMsg(ProcessingMessageNatEn::Success, ret, SYS_Stringer("File ", it.first, " has been processed successfully"));
                    }

                    if (bPckDef)
                    {
                        pckDefVector.push_back(std::make_pair(fileInfo.path().toStdString(), outputDynStpVector.back()));
                    }
                }
            }

            if (bTryGetFromDatabase)
            {
                std::map<std::string, std::vector<std::pair<std::string, DBA_DYNFLD_STP>>> pckDefMap;
                std::set<std::string>  pckDefCodeSet;
                for (auto& it : pckDefVector)
                {
                    if (it.second->getDynStEn() == O_PackageDefinition)
                    {
                        std::string pckDefCode = GET_STRING(it.second, O_PackageDefinition_Code);
                        std::string parentPckDefCode = IS_NOTNULL(it.second, O_PackageDefinition_ParentPackageCode) ?
                            GET_STRING(it.second, O_PackageDefinition_ParentPackageCode) :
                            std::string();

                        if (parentPckDefCode.empty() && pckDefCode != "SYS_")
                        {
                            parentPckDefCode = "SYS_";
                        }
                        pckDefMap[parentPckDefCode].push_back(it);
                        pckDefCodeSet.insert(pckDefCode);
                    }
                    else
                    {
                        ret = DBA_FillFullRecordAndSave(it.second, buildBindOption, mp, &dbiConn, subQueryMap, zipArchivePtr);
                        if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                        {
                            gblRet = ret;
                        }
                    }
                }

                if (pckDefMap.empty() == false)
                {
                    DbiConnectionHelper       dbiConnHelper(&dbiConn);

                    auto pckInstStp = mp.allocDynst(FILEINFO, S_PackageInstallation);

                    std::vector<DBA_DYNFLD_STP> pckDefStpVector;
                    std::set<std::string>       pckDefTreatedSet;

                    while (pckDefCodeSet.empty() == false && RET_GET_LEVEL(gblRet) != RET_LEV_ERROR)
                    {
                        for (auto& it : pckDefMap)
                        {
                            if (pckDefCodeSet.find(it.first) == pckDefCodeSet.end())
                            {
                                for (auto& pckDefIt : it.second)
                                {
                                    std::string pckDefCode = GET_STRING(pckDefIt.second, O_PackageDefinition_Code);

                                    if (pckDefTreatedSet.find(pckDefCode) == pckDefTreatedSet.end())
                                    {
                                        COPY_DYNFLD(pckInstStp, S_PackageInstallation, S_PackageInstallation_Cd,
                                                    pckDefIt.second, O_PackageDefinition, O_PackageDefinition_ParentPackageCode);
                                        COPY_DYNFLD(pckInstStp, S_PackageInstallation, S_PackageInstallation_Version,
                                                    pckDefIt.second, O_PackageDefinition, O_PackageDefinition_ParentPackageVersion);

                                        dbiConnHelper.setFromDbaAccess();
                                        if (IS_NULLFLD(pckDefIt.second, O_PackageDefinition_ParentPackageCode) ||
                                            GET_STRING(pckDefIt.second, O_PackageDefinition_ParentPackageCode)[0] == 0 ||
                                            pckDefTreatedSet.find(GET_STRING(pckDefIt.second, O_PackageDefinition_ParentPackageCode)) != pckDefTreatedSet.end() ||
                                            (dbiConnHelper.dbaGet(PackageInstallation, DBA_ROLE_PACKAGE_DEF_INSTALLATION, pckInstStp, &pckInstStp) == RET_SUCCEED &&
                                             IS_NOTNULL(pckInstStp, S_PackageInstallation_Id)))
                                        {
                                            dbiConnHelper.resetFromDbaAccess();

                                            if (buildBindOption.isZipFile() == false)
                                            {
                                                buildBindOption.setFilePathInfo(pckDefIt.first, std::string());
                                            }
                                            pckDefTreatedSet.insert(pckDefCode);

                                            ret = DBA_FillFullRecordAndSave(pckDefIt.second, buildBindOption, mp, &dbiConn, subQueryMap, zipArchivePtr);

                                            if (IS_NOTNULL(pckDefIt.second, O_PackageDefinition_PackageDefinition) &&
                                                GET_EXTENSION_NBR(pckDefIt.second, O_PackageDefinition_PackageDefinition) == 1)
                                            {
                                                pckDefStpVector.push_back(*GET_EXTENSION_PTR(pckDefIt.second, O_PackageDefinition_PackageDefinition));
                                            }

                                            if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                                            {
                                                gblRet = ret;
                                            }
                                        }
                                        else
                                        {
                                            gblRet = RET_DBA_ERR_INVDATA;

                                            buildBindOption.printMsg(ProcessingMessageNatEn::Info, gblRet, SYS_Stringer("requires parent package = "
                                                                                                                        , GET_STRING(pckInstStp, S_PackageInstallation_Cd)
                                                                                                                        , " with version = "
                                                                                                                        , GET_STRING(pckInstStp, S_PackageInstallation_Version)));
                                        }

                                        pckDefCodeSet.erase(pckDefCode);
                                    }

                                    if (RET_GET_LEVEL(gblRet) == RET_LEV_ERROR)
                                    {
                                        break;
                                    }
                                }

                                if (RET_GET_LEVEL(gblRet) == RET_LEV_ERROR)
                                {
                                    break;
                                }
                            }
                        }
                    }

                    if (gblRet == RET_SUCCEED &&
                        buildBindOption == BuildBindOption::Categ::ImportFullObject &&
                        buildBindOption.getOutputArtefact() == BuildBindOption::OutputArtefact::DelayWrite)
                    {
                        ret = DBA_FlushPckDef(pckDefStpVector, mp, &dbiConn);
                    }
                }
                else if (buildBindOption == BuildBindOption::Categ::ImportFullObject &&
                         bFullDir == true &&
                         buildBindOption.getOutputArtefact() == BuildBindOption::OutputArtefact::DelayWrite)
                {
                    DbiConnectionHelper       dbiConnHelper(&dbiConn);
                    auto ddlGenDbaAccessPtr = dbiConnHelper.getConnection()->getDdlGenDbaAccessPtr();
                    gblRet = ddlGenDbaAccessPtr->flushData();
                }
            }
        }
        else
        {
            ReaderParserRapidJson jsonParser(buildBindOption, &mp, &dbiConn);

            jsonParser.setErrorCallback(MSG_SendMesg);
            jsonParser.m_usage = DbiBindDataDef::Usage::ImportExport;

            jsonParser.parse(inputString);
            if (jsonParser.isError() == false)
            {
                if (jsonParser.isPackager())
                {
                    buildBindOption.setPackager();
                }
                if (buildBindOption.isImportExport())
                {
                    if (bTryGetFromDatabase)
                    {
                        if (buildBindOption.getOutputArtefact() != BuildBindOption::OutputArtefact::DelayWrite)
                        {
                            if (EV_OptiMemFlg == TRUE)
                            {
                                buildBindOption.setOutputArtefact(BuildBindOption::OutputArtefact::WriteInDbByBatch);
                            }
                            else
                            {
                                buildBindOption.setOutputArtefact(BuildBindOption::OutputArtefact::WriteInDb);
                            }
                        }
                    }
                }

                while (RET_GET_LEVEL(ret) != RET_LEV_ERROR &&
                       jsonParser.setNextResultSet())
                {
                    DBA_DYNFLD_STP outputDynStp = nullptr;
                    while (RET_GET_LEVEL(ret) != RET_LEV_ERROR &&
                           (outputDynStp = jsonParser.getNextDynStp(ReaderParser::MEMORY_OWNED_BY::Requester)) != nullptr)
                    {
                        mp.ownerDynStp(outputDynStp);

                        if (bTryGetFromDatabase)
                        {
                            ret = DBA_FillFullRecordAndSave(outputDynStp, buildBindOption, mp, &dbiConn, subQueryMap, zipArchivePtr);

                            if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                            {
                                gblRet = ret;
                            }
                        }

                        outputDynStpVector.push_back(outputDynStp);
                    }
                }

                if (RET_GET_LEVEL(gblRet) == RET_LEV_ERROR)
                {
                    return (gblRet);
                }
            }

            gblRet = (jsonParser.isError() ? RET_DBA_ERR_INVDATA : RET_SUCCEED);
        }
    }
    catch (std::exception&)
    {
        gblRet = RET_GEN_ERR_PERSONAL;
        exceptionHandler(FILEINFO, MSG_SendMesg);
    }

    return (gblRet);
}

/************************************************************************
**
**  Function    :   DBA_GetJSonStringFromDynStp()
**
**  Description :
**
**  Argument    :
**
**  Return      :
**
**  Creation  	:  PMSTA-45027 - LJE - 210430
**
**  Last modif. :
**
*************************************************************************/
RET_CODE DBA_GetJSonStringFromDynStp(const std::vector<DBA_DYNFLD_STP>& inputDynStpVector,
                                     std::string& outputString,
                                     BuildBindOption& buildBindOption,
                                     DbiConnection& dbiConnPtr)
{
    RET_CODE ret = RET_SUCCEED;

    try
    {
        FormatFieldsRapidJson formatFields(&dbiConnPtr,
                                           buildBindOption.rootStartByArray(),
                                           buildBindOption.usePrettyWritter());

        formatFields.setCharsetUtf8(true);
        formatFields.setErrorCallback(MSG_SendMesg);

        std::map<DBA_DYNST_ENUM, std::vector<DBA_DYNFLD_STP>> resultDynsStpMap;
        for (auto& it : inputDynStpVector)
        {
            if (it != nullptr)
            {
                resultDynsStpMap[it->getDynStEn()].push_back(it);
            }
        }

        bool            bOnObject = (buildBindOption.isBusinessKeyOnly() == false) || buildBindOption.getDescObject();

        if (resultDynsStpMap.size() > 1)
        {
            formatFields.arrayModeBegin(nullptr);
        }

        for (auto& dynStIt : resultDynsStpMap)
        {
            bool            bMultiple = (buildBindOption.forceArrayFirstObject() || dynStIt.second.size() > 1);

            for (auto& recordStp : dynStIt.second)
            {
                if (recordStp->getObjectEn() == ExportQuery)
                {
                    buildBindOption.clearConfig();

                    buildBindOption.setExportMode(ExportQuery, EntityConfigExportModeEn::NotNull);
                    buildBindOption.setExportMode(EntityProfile, EntityConfigExportModeEn::NotNull);
                    buildBindOption.setExportMode(EntityConfig, EntityConfigExportModeEn::NotNull);
                    buildBindOption.setExportMode(EntityConfigElement, EntityConfigExportModeEn::NotNull);

                    buildBindOption.fillConfig(recordStp);
                }
                else if (recordStp->getObjectEn() == PackageComposition &&
                         buildBindOption.getOutputArtefact() == BuildBindOption::OutputArtefact::File)
                {
                    buildBindOption.setConfig("package_composition", "package_definition_id", "", EntityConfigElementRuleEn::Skip);
                }
                else
                {
                    buildBindOption.fillConfig(recordStp);
                }
                buildBindOption.setRecordStp(recordStp);

                DBA_DYNST_ENUM  dynStEn = dynStIt.first;
                OBJECT_ENUM     objectEn = NullEntity;
                DbiBindDataDef  mapBindDataDef;
                ReaderParser::buildBindMapFromData(std::string(), objectEn, dynStEn, nullptr, mapBindDataDef, buildBindOption);

                if (recordStp == *dynStIt.second.begin())
                {
                    OBJECT_ENUM     parentObjectEn = NullEntity;
                    if (mapBindDataDef.m_dictEntityStp != nullptr)
                    {
                        parentObjectEn = mapBindDataDef.m_dictEntityStp->getParentObjectEn(recordStp);
                    }
                    formatFields.blockModeBegin(objectEn, dynStEn, bOnObject, parentObjectEn);
                }
                formatFields.blockModeAdd(recordStp, mapBindDataDef, buildBindOption, bMultiple);

                if (dynStIt.second.size() == 1)
                {
                    formatFields.blockModeEnd(bOnObject, bMultiple);
                }
                else
                {
                    bMultiple = false;
                }
            }

            if (dynStIt.second.size() > 1)
            {
                formatFields.blockModeEnd(bOnObject, true);
            }
        }

        if (resultDynsStpMap.size() > 1)
        {
            formatFields.arrayModeEnd();
        }

        formatFields.getDataSerialized(outputString, false);
    }
    catch (std::exception&)
    {
        ret = RET_GEN_ERR_PERSONAL;
        exceptionHandler(FILEINFO, MSG_SendMesg);
    }

    return (RET_GET_LEVEL(ret) == RET_LEV_ERROR) ? ret : RET_SUCCEED;
}


/************************************************************************
**
**  Function    :   DBA_CreateExportFiles()
**
**  Description :
**
**  Argument    :
**
**  Return      :
**
**  Creation  	:  PMSTA-46681 - LJE - 231009
**
**  Last modif. :
**
*************************************************************************/
RET_CODE DBA_CreateExportFiles(std::vector<DBA_DYNFLD_STP>& outputDynStpVector,
                               BuildBindOption& outputBindOption,
                               DbiConnection& dbiConn,
                               ZipArchive::Ptr              zipArchivePtr)
{
    RET_CODE ret = RET_GEN_INFO_NOACTION;

    if (outputDynStpVector.back()->getDynStEn() == O_PackageDefinition)
    {
        ret = DBA_ExtractPackageDefinition(outputDynStpVector,
                                           outputBindOption,
                                           dbiConn);
    }
    else
    {
        bool bZipToClose = false;

        if (outputBindOption.getFileName().empty() == false ||
            outputBindOption.getRootPath().empty() == false)
        {
            if (outputBindOption.isZipFile() &&
                zipArchivePtr == nullptr)
            {
                bZipToClose = true;
                zipArchivePtr = ZipFile::Open(outputBindOption.getFullFileName());
            }

            if (bZipToClose &&
                outputDynStpVector.back()->getDynStEn() != A_ExportQuery)
            {
                for (auto& oneDynStp : outputDynStpVector)
                {
                    std::vector<DBA_DYNFLD_STP> oneDynStpVector;
                    oneDynStpVector.push_back(oneDynStp);
                    std::string fileName;

                    if (oneDynStp->getDictEntityStp() != nullptr)
                    {
                        BuildBindOption bkBindOption(BuildBindOption::Categ::BusinessKeyOnlyShort);

                        std::string bkString;
                        outputBindOption.setDescObject(true);
                        (void)DBA_GetJSonStringFromDynStp(oneDynStpVector,
                                                          bkString,
                                                          bkBindOption,
                                                          dbiConn);

                        rapidjson::Document document;
                        document.Parse(bkString);

                        std::string strBusinessKeyValues;
                        if (document.HasParseError() == false)
                        {
                            std::string     strSeparator("_");
                            strBusinessKeyValues = SYS_ExtractKeyValues(document, strSeparator);

                            if (strBusinessKeyValues.empty() == false)
                            {
                                /*      Space characters are removed                        */
                                SYS_RemoveAll(strBusinessKeyValues, SYS_DEFAULT_WHITE_SPACES);
                                /*      Unicode characters are encoded                      */
                                fileName = oneDynStp->getDictEntityStp()->mdSqlName + strSeparator + SYS_urlEncode(strBusinessKeyValues, strSeparator);
                            }
                        }
                    }

                    if (fileName.empty())
                    {
                        auto fileInfo = QFileInfo(outputBindOption.getFileName().c_str());
                        fileName = fileInfo.fileName().toStdString();
                        auto extPos = fileName.find_last_of(".");
                        if (extPos != std::string::npos)
                        {
                            fileName.erase(extPos);
                        }
                    }
                    fileName += ".json";

                    std::string outputString;
                    ret = DBA_GetJSonStringFromDynStp(oneDynStpVector,
                                                      outputString,
                                                      outputBindOption,
                                                      dbiConn);

                    auto entry = zipArchivePtr->CreateEntry(fileName);
                    if (entry == nullptr)
                    {
                        zipArchivePtr->RemoveEntry(fileName);
                        entry = zipArchivePtr->CreateEntry(fileName);
                    }

                    std::stringstream contentStream(outputString);

                    DeflateMethod::Ptr ctx = DeflateMethod::Create();
                    ctx->SetCompressionLevel(DeflateMethod::CompressionLevel::Default);

                    entry->SetCompressionStream(contentStream,
                                                ctx,
                                                ZipArchiveEntry::CompressionMode::Immediate);
                }
            }
            else
            {
                if (outputDynStpVector.back()->getDynStEn() == A_ExportQuery &&
                    (IS_NOTNULL(outputDynStpVector.back(), A_ExportQuery_FilePattern) || outputBindOption.getFileName().empty()))
                {
                    SYS_MkPath(outputBindOption.getRootPath().c_str());

                    std::string kindOfFileStr = zipArchivePtr == nullptr ? "file" : "entry";
                    for (auto& exportQueryStp : outputDynStpVector)
                    {
                        if (GET_EXTENSION_NBR(exportQueryStp, A_ExportQuery_ExportObj) > 0)
                        {
                            DBA_DYNFLD_STP* objRecordsTab = GET_EXTENSION_PTR(exportQueryStp, A_ExportQuery_ExportObj);
                            int             objRecordsNbr = GET_EXTENSION_NBR(exportQueryStp, A_ExportQuery_ExportObj);

                            for (int i = 0; i < objRecordsNbr; ++i)
                            {
                                auto recordStp = objRecordsTab[i];

                                std::string fileName;
                                if (IS_NOTNULL(exportQueryStp, A_ExportQuery_FilePattern))
                                {
                                    fileName = DBA_EvalDVScript(GET_STRING(exportQueryStp, A_ExportQuery_FilePattern), recordStp);

                                    if (fileName.empty())
                                    {
                                        ret = RET_SCPT_ERR_SYNTAX;
                                        outputBindOption.printMsg(ProcessingMessageNatEn::Error, ret, SYS_Stringer("Unable to create file name with pattern: \"", GET_STRING(exportQueryStp, A_ExportQuery_FilePattern), "\""));
                                    }
                                }
                                else
                                {
                                    std::string flatBkStr;
                                    FormatFields::getFlatBkField(recordStp, flatBkStr, &dbiConn, "~");

                                    std::string::size_type pos = 0;
                                    while ((pos = flatBkStr.find_first_of("<>", pos)) != std::string::npos)
                                    {
                                        flatBkStr.erase(pos, 1);
                                    }

                                    fileName += recordStp->getDictEntityStp()->mdSqlName;
                                    fileName += "!";

                                    if (SYS_GetThreadCurrBusinessEntity().empty() == false)
                                    {
                                        fileName = SYS_GetThreadCurrBusinessEntity() + "!";
                                    }
                                    fileName += flatBkStr + ".json";
                                }

                                std::vector<DBA_DYNFLD_STP> recordStpVector;
                                recordStpVector.push_back(recordStp);

                                BuildBindOptionGuard buildBindOptionGuard(outputBindOption);
                                outputBindOption.setFilePathInfo(outputBindOption.getRootPath(), fileName);
                                outputBindOption.printMsg(ProcessingMessageNatEn::Success, RET_SUCCEED, SYS_Stringer("creating ", kindOfFileStr, ": ", outputBindOption.getFullFileName()));

                                ret = DBA_CreateExportFiles(recordStpVector,
                                                            outputBindOption,
                                                            dbiConn,
                                                            zipArchivePtr);
                            }
                        }
                    }
                }
                else
                {
                    std::string outputString;
                    ret = DBA_GetJSonStringFromDynStp(outputDynStpVector,
                                                      outputString,
                                                      outputBindOption,
                                                      dbiConn);

                    if (zipArchivePtr != nullptr)
                    {
                        auto fileName = outputBindOption.getFileName();
                        auto entry = zipArchivePtr->CreateEntry(fileName);

                        if (entry == nullptr)
                        {
                            zipArchivePtr->RemoveEntry(fileName);
                            entry = zipArchivePtr->CreateEntry(fileName);
                        }

                        std::stringstream contentStream(outputString);

                        DeflateMethod::Ptr ctx = DeflateMethod::Create();
                        ctx->SetCompressionLevel(DeflateMethod::CompressionLevel::Default);

                        entry->SetCompressionStream(contentStream,
                                                    ctx,
                                                    ZipArchiveEntry::CompressionMode::Immediate);
                    }
                    else
                    {
                        std::ofstream  outputFile;
                        outputFile.open(outputBindOption.getFullFileName(), std::ifstream::out | std::ifstream::binary);

                        if (outputFile.fail() == false)
                        {
                            outputFile << outputString;
                        }
                        else
                        {
                            outputBindOption.printMsg(ProcessingMessageNatEn::Error, ret, SYS_Stringer("Unable to create file \"", outputBindOption.getFullFileName(), "\""));
                        }
                        outputFile.close();
                    }
                }
            }
        }

        if (bZipToClose)
        {
            outputBindOption.printMsg(ProcessingMessageNatEn::Success, RET_SUCCEED, SYS_Stringer("Flushing ZIP file: ", outputBindOption.getFullFileName()));
            ZipFile::SaveAndClose(zipArchivePtr, outputBindOption.getFullFileName());
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DBA_ExtractPackageDefinition()
**
**  Description :
**
**  Argument    :
**
**  Return      :
**
**  Creation  	:  PMSTA-46681 - LJE - 231009
**
**  Last modif. :
**
*************************************************************************/
RET_CODE DBA_ExtractPackageDefinition(std::vector<DBA_DYNFLD_STP>& inputDynStpVector,
                                      BuildBindOption& buildBindOption,
                                      DbiConnection& dbiConn)
{
    RET_CODE ret = RET_SUCCEED;
    RET_CODE gblRet = RET_SUCCEED;

    ZipArchive::Ptr zipArchivePtr = nullptr;
    std::string     zipFileName;
    if (buildBindOption.isZipFile())
    {
        zipFileName = buildBindOption.getFullFileName();
        zipArchivePtr = ZipFile::Open(zipFileName);
        buildBindOption.setFilePathInfo(std::string(), MANIFEST, -2);
    }

    for (auto& manifestStp : inputDynStpVector)
    {
        if (manifestStp != nullptr)
        {
            BuildBindOptionGuard  buildBindOptionGuard(buildBindOption);

            FormatFieldsRapidJson formatFields(&dbiConn,
                                               buildBindOption.rootStartByArray(),
                                               buildBindOption.usePrettyWritter());

            formatFields.setCharsetUtf8(true);
            formatFields.setErrorCallback(MSG_SendMesg);

            buildBindOption.fillConfig(manifestStp);

            ZipArchive::Ptr subZipArchivePtr = nullptr;

            DBA_DYNST_ENUM  dynStEn = GET_DYNSTENUM(manifestStp);
            OBJECT_ENUM     objectEn = NullEntity;
            bool            bOnObject = (buildBindOption.isBusinessKeyOnly() == false);
            bool            bMultiple = (buildBindOption.forceArrayFirstObject() || inputDynStpVector.size() > 1);
            DbiBindDataDef  mapBindDataDef;
            ReaderParser::buildBindMapFromData(std::string(), objectEn, dynStEn, nullptr, mapBindDataDef, buildBindOption);

            buildBindOption.setPrintNullString(false);
            formatFields.blockModeBegin(objectEn, dynStEn, bOnObject);
            formatFields.blockModeAdd(manifestStp, mapBindDataDef, buildBindOption, bMultiple);
            formatFields.blockModeEnd(bOnObject, bMultiple);
            buildBindOption.setPrintNullString(true);

            std::string manifestString;
            formatFields.getDataSerialized(manifestString, false);

            auto rootPath(buildBindOption.getRootPath());
            auto manifestFileName(buildBindOption.getFullFileName());

            if (buildBindOption.getFileName().empty())
            {
                std::string packageRootDir("unknown");

                auto permValPtr = DBA_GetDictPermValByName(PackageDefinition, A_PackageDefinition_NatEn, GET_CODE(manifestStp, O_PackageDefinition_Nature));
                if (permValPtr != nullptr)
                {
                    switch (static_cast<PackageDefinitionNatEn>(permValPtr->permVal))
                    {
                        case PackageDefinitionNatEn::Custom:
                            packageRootDir = "custo";
                            break;

                        case PackageDefinitionNatEn::Feature:
                            packageRootDir = "feature";
                            break;

                        case PackageDefinitionNatEn::Standard:
                            packageRootDir = "std";
                            break;

                        case PackageDefinitionNatEn::StandardModelBank:
                            packageRootDir = "mb";
                            break;

                    }
                }
                std::string pckDefCode(GET_STRING(manifestStp, O_PackageDefinition_Code));

                if (DdlGen::find_word(rootPath, pckDefCode, 0, std::string::npos, FILE_SEPARATOR) == std::string::npos)
                {
                    if (DdlGen::find_word(rootPath, packageRootDir, 0, std::string::npos, FILE_SEPARATOR) != std::string::npos)
                    {
                        packageRootDir.clear();
                    }
                    else
                    {
                        packageRootDir += FILE_SEPARATOR;
                    }

                    rootPath += SYS_Stringer(packageRootDir, pckDefCode, FILE_SEPARATOR);
                }
                SYS_MkPath(rootPath.c_str());

                manifestFileName = rootPath + MANIFEST;
            }

            std::string rootPackage;
            ZipArchive::Ptr currZipArchivePtr = nullptr;
            if (zipArchivePtr != nullptr)
            {
                if (inputDynStpVector.size() > 1)
                {
                    subZipArchivePtr = ZipArchive::Create();

                    currZipArchivePtr = subZipArchivePtr;

                    rootPackage = SYS_Stringer(GET_CODE(manifestStp, O_PackageDefinition_Code), FILE_SEPARATOR);
                }
                else
                {
                    currZipArchivePtr = zipArchivePtr;
                }

                buildBindOption.printMsg(ProcessingMessageNatEn::Success, RET_SUCCEED, SYS_Stringer("Add ZIP entry: ", rootPackage + manifestFileName));

                auto entry = currZipArchivePtr->CreateEntry(MANIFEST);
                if (entry == nullptr)
                {
                    currZipArchivePtr->RemoveEntry(MANIFEST);
                    entry = currZipArchivePtr->CreateEntry(MANIFEST);
                }

                std::stringstream contentStream(manifestString);

                DeflateMethod::Ptr ctx = DeflateMethod::Create();
                ctx->SetCompressionLevel(DeflateMethod::CompressionLevel::Default);

                entry->SetCompressionStream(contentStream,
                                            ctx,
                                            ZipArchiveEntry::CompressionMode::Immediate);
            }
            else
            {
                std::ofstream  manifestFile;
                buildBindOption.printMsg(ProcessingMessageNatEn::Success, RET_SUCCEED, SYS_Stringer("creating file: ", manifestFileName));

                manifestFile.open(manifestFileName, std::ifstream::out | std::ifstream::binary);
                if (manifestFile.fail() == false)
                {
                    manifestFile << manifestString;
                }
                manifestFile.close();
            }

            if (IS_NULLFLD(manifestStp, O_PackageDefinition_PackageComposition) == false &&
                GET_EXTENSION_PTR(manifestStp, O_PackageDefinition_PackageComposition) != nullptr)
            {
                std::vector<SYS_FileInfo> fileList;
                std::set<std::string>     fileNameSet;

                if (currZipArchivePtr != nullptr)
                {
                    auto            entries = currZipArchivePtr->GetEntriesCount();
                    for (size_t i = 0; i < entries; ++i)
                    {
                        auto entry = currZipArchivePtr->GetEntry(CAST_INT(i));
                        if (entry->IsDirectory() == false &&
                            entry->GetName().find(".json") == entry->GetName().size() - 5)
                        {
                            fileNameSet.insert(entry->GetFullName());
                        }
                    }
                }
                else
                {
                    if (SYS_DIRentryList(rootPath, fileList, true))
                    {
                        for (auto& fileIt : fileList)
                        {
                            if (fileIt.isFile &&
                                fileIt.fileName.find(".json") == fileIt.fileName.size() - 5)
                            {
                                fileNameSet.insert(fileIt.fullPath);
                            }
                        }
                    }
                }

                auto manifestInfo = QFileInfo(manifestFileName.c_str());
                fileNameSet.erase(manifestInfo.filePath().toStdString());

                auto pckCompoNbr = GET_EXTENSION_NBR(manifestStp, O_PackageDefinition_PackageComposition);
                auto pckCompoTab = GET_EXTENSION_PTR(manifestStp, O_PackageDefinition_PackageComposition);

                for (int i = 0; i < pckCompoNbr; ++i)
                {
                    auto pckCompoStp = pckCompoTab[i];

                    if (IS_VALID_FLD_FK(pckCompoStp))
                    {
                        std::vector<DBA_DYNFLD_STP> pckCompoStpVector;
                        pckCompoStpVector.push_back(pckCompoStp);

                        buildBindOption.setOutputArtefact(BuildBindOption::OutputArtefact::File);
                        buildBindOption.setFilePathInfo(rootPath, GET_STRING(pckCompoStp, A_PackageComposition_Filename));

                        auto fileInfo = QFileInfo(buildBindOption.getFullFileName().c_str());
                        auto filePath = fileInfo.filePath().toStdString();
                        if (zipArchivePtr == nullptr)
                        {
                            SYS_MkPath(fileInfo.absolutePath().toStdString().c_str());
                        }
                        else
                        {
                            auto pos = DdlGen::find_word(filePath, GET_CODE(manifestStp, O_PackageDefinition_Code), 0, std::string::npos, "/\\");
                            if (pos != std::string::npos)
                            {
                                filePath.erase(0, pos + strlen(GET_CODE(manifestStp, O_PackageDefinition_Code)) + 1);
                            }
                        }

                        fileNameSet.erase(filePath);

                        std::string outputString;
                        ret = DBA_GetJSonStringFromDynStp(pckCompoStpVector,
                                                          outputString,
                                                          buildBindOption,
                                                          dbiConn);
                        outputString += "\n";

                        if (ret == RET_SUCCEED)
                        {
                            if (currZipArchivePtr == nullptr)
                            {
                                std::stringstream inputStream;
                                std::ifstream  inputFile;
                                inputFile.open(buildBindOption.getFullFileName(), std::ifstream::in | std::ifstream::binary);
                                if (inputFile.fail() == false)
                                {
                                    std::string lineStr;
                                    while (getline(inputFile, lineStr))
                                    {
                                        inputStream << lineStr << std::endl;
                                    }
                                    inputFile.close();

                                    if (inputStream.str() == outputString)
                                    {
                                        ret = RET_GEN_INFO_NOACTION;
                                    }
                                }
                            }
                            else
                            {
                                auto entry = currZipArchivePtr->GetEntry(filePath);
                                if (entry != nullptr)
                                {
                                    std::istream* dataStream = entry->GetDecompressionStream();

                                    std::stringstream inputStream;
                                    utils::stream::copy(*dataStream, inputStream);

                                    if (inputStream.str() == outputString)
                                    {
                                        ret = RET_GEN_INFO_NOACTION;
                                    }
                                    else
                                    {
                                        currZipArchivePtr->RemoveEntry(filePath);
                                    }
                                }
                            }
                        }

                        if (ret == RET_SUCCEED)
                        {
                            if (currZipArchivePtr == nullptr)
                            {
                                buildBindOption.printMsg(ProcessingMessageNatEn::Success, RET_SUCCEED, SYS_Stringer("creating file: ", buildBindOption.getFullFileName()));
                                std::ofstream  outputFile;
                                outputFile.open(buildBindOption.getFullFileName(), std::ifstream::out | std::ifstream::binary);
                                if (outputFile.fail() == false)
                                {
                                    outputFile << outputString;
                                }
                                else
                                {
                                    gblRet = RET_GEN_ERR_INVARG;

                                    std::stringstream msg;
                                    msg << std::endl << "Unable to create file: " << buildBindOption.getFullFileName();

                                    buildBindOption.printMsg(ProcessingMessageNatEn::Error, gblRet, msg.str());
                                }
                                outputFile.close();
                            }
                            else
                            {
                                buildBindOption.printMsg(ProcessingMessageNatEn::Success, RET_SUCCEED, SYS_Stringer("Add ZIP entry: ", rootPackage + filePath));

                                auto entry = currZipArchivePtr->CreateEntry(filePath);

                                std::stringstream contentStream(outputString);

                                DeflateMethod::Ptr ctx = DeflateMethod::Create();
                                ctx->SetCompressionLevel(DeflateMethod::CompressionLevel::Default);

                                entry->SetCompressionStream(contentStream,
                                                            ctx,
                                                            ZipArchiveEntry::CompressionMode::Immediate);
                            }
                        }
                        else if (ret == RET_GEN_INFO_NOACTION)
                        {
                            buildBindOption.printMsg(ProcessingMessageNatEn::Success, RET_SUCCEED, SYS_Stringer("the file: ", buildBindOption.getFullFileName(), " is not modified"));
                        }
                        else if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                        {
                            gblRet = ret;
                        }
                    }
                }

                for (auto& fileName : fileNameSet)
                {
                    if (zipArchivePtr == nullptr)
                    {
                        SYS_DeleteFile(fileName.c_str());
                        buildBindOption.printMsg(ProcessingMessageNatEn::Success, RET_SUCCEED, SYS_Stringer("the file: ", fileName, " is deleted"));
                    }
                    else
                    {
                        zipArchivePtr->RemoveEntry(fileName);
                        buildBindOption.printMsg(ProcessingMessageNatEn::Success, RET_SUCCEED, SYS_Stringer("the file: ", rootPackage + fileName, " has been removed from the ZIP file"));
                    }
                }

                if (subZipArchivePtr != nullptr)
                {
                    buildBindOption.printMsg(ProcessingMessageNatEn::Success, RET_SUCCEED, SYS_Stringer("Add ZIP entry: ", rootPackage + buildBindOption.getFullFileName()));

                    std::string pckName = SYS_Stringer(GET_CODE(manifestStp, O_PackageDefinition_Code), ".zip");
                    auto entry = zipArchivePtr->CreateEntry(pckName);
                    if (entry == nullptr)
                    {
                        zipArchivePtr->RemoveEntry(pckName);
                        entry = zipArchivePtr->CreateEntry(pckName);
                    }

                    std::stringstream contentStream;
                    subZipArchivePtr->WriteToStream(contentStream);


                    DeflateMethod::Ptr ctx = DeflateMethod::Create();
                    ctx->SetCompressionLevel(DeflateMethod::CompressionLevel::Default);

                    entry->SetCompressionStream(contentStream,
                                                ctx,
                                                ZipArchiveEntry::CompressionMode::Immediate);
                }

                if (SYS_IsBatchMode() == TRUE)
                {
                    std::cout << std::endl << "MSG Done (" << GET_CODE(manifestStp, O_PackageDefinition_Code) << ")";
                }
            }
            else
            {
                buildBindOption.printMsg(ProcessingMessageNatEn::Success, RET_SUCCEED, "Empty package");
            }
        }
    }

    if (zipArchivePtr != nullptr)
    {
        ZipFile::SaveAndClose(zipArchivePtr, zipFileName);
    }

    return gblRet;
}

/************************************************************************
**  Function            : DBA_CopyDataJSon()
**
**  Description         :
**
**  Arguments           :
**
**  Functions call      :
**
**  Return              : None
**
**  creation            : PMSTA-55800 - LJE - 240403
**  Modification        :
*
*************************************************************************/
RET_CODE DBA_CopyDataJSon(DbiConnectionHelper    &dbiConnHelper, 
                          std::string             copyArgStr, 
                          ProcessingMessageNatEn  logLevelEn,
                          std::string            &outputString)
{
    RET_CODE retCode = RET_SUCCEED;
    MemoryPool mp;

    if (dbiConnHelper.isValidAndInit())
    {
        auto dbiConnPtr = dbiConnHelper.getConnection();

        std::vector<DBA_DYNFLD_STP> inputDynStpVector;
        BuildBindOption inputBindOption(BuildBindOption::Categ::ExportCopyObject);
        inputBindOption.setOutputArtefact(BuildBindOption::OutputArtefact::DelayWrite);
        inputBindOption.setLogLevel(logLevelEn);

        retCode = DBA_GetDynStpFromJSonString(copyArgStr,
                                              inputDynStpVector,
                                              inputBindOption,
                                              mp,
                                              *dbiConnPtr,
                                              true);

        if (retCode == RET_SUCCEED)
        {
            BuildBindOption copyBindOption = BuildBindOption::Categ::ImportFullObject;
            copyBindOption.sync(inputBindOption);
            copyBindOption.setOutputArtefact(BuildBindOption::OutputArtefact::WriteInDbByBatch);

            copyBindOption.start();

            std::vector<DBA_DYNFLD_STP> copyDynStpVector;

            for (auto& inputDynStp : inputDynStpVector)
            {
                if (inputDynStp->getDynStEn() != A_CopyArg)
                {
                    retCode = RET_GEN_ERR_INVARG;

                    auto dictEntityStp = inputDynStp->getDictEntityStp();
                    std::string inputStr;
                    if (dictEntityStp != nullptr)
                    {
                        inputStr = dictEntityStp->mdSqlName;
                    }
                    else
                    {
                        inputStr = DBA_GetDynStCName(inputDynStp->getDynStEn());
                    }

                    copyBindOption.printMsg(ProcessingMessageNatEn::Error,
                                            retCode,
                                            SYS_Stringer("Wrong input argument, must be \"copy_arg\" instead of \"", inputStr, "\""));
                }

                if (retCode == RET_SUCCEED)
                {
                    switch (GET_A_CopyArg_CopyLogicalEn(inputDynStp))
                    {
                        case CopyArgCopyLogicalEn::No:
                        case CopyArgCopyLogicalEn::Yes:
                            if (GET_ID(inputDynStp, A_CopyArg_ToId) > 0)
                            {
                                retCode = RET_SRV_LIB_ERR_DUPLICATEKEY;
                                copyBindOption.printMsg(ProcessingMessageNatEn::Error, retCode, "Unable to insert record, duplicate key on the business key");
                            }
                            break;

                        case CopyArgCopyLogicalEn::Only:
                        case CopyArgCopyLogicalEn::Override:
                            if (IS_NULLFLD(inputDynStp, A_CopyArg_ToId))
                            {
                                retCode = RET_DBA_ERR_NODATA;
                                copyBindOption.printMsg(ProcessingMessageNatEn::Error, retCode, "Unable to copy logicals on unknown record");
                            }
                            break;

                        default:
                            break;
                    }
                }

                if (retCode == RET_SUCCEED)
                {
                    auto fromCopyRecordStp = GET_FK_RECORD(inputDynStp, A_CopyArg_FromId);
                    if (fromCopyRecordStp != nullptr)
                    {
                        auto dictEntityStp = fromCopyRecordStp->getDictEntityStp();
                        auto toCopyRecordStp = GET_FK_RECORD(inputDynStp, A_CopyArg_ToId);

                        if (toCopyRecordStp != nullptr)
                        {
                            switch (GET_A_CopyArg_CopyLogicalEn(inputDynStp))
                            {
                                case CopyArgCopyLogicalEn::No:
                                case CopyArgCopyLogicalEn::Yes:
                                    for (auto& attribStp : dictEntityStp->attr)
                                    {
                                        if (attribStp->primFlg == FALSE &&
                                            attribStp->logicalFlg == FALSE &&
                                            IS_SETFLD(toCopyRecordStp, attribStp->progN) == TRUE &&
                                            attribStp->calcEn != DictAttr_NoMD)
                                        {
                                            DBA_CopyDynFld(fromCopyRecordStp, attribStp->progN, toCopyRecordStp, attribStp->progN);
                                        }
                                    }
                                    break;

                                case CopyArgCopyLogicalEn::Only:
                                    for (auto& attribStp : dictEntityStp->logicalTab)
                                    {
                                        if (IS_NOTNULL(toCopyRecordStp, attribStp->progN) &&
                                            attribStp->progN != GET_FLD_FK(toCopyRecordStp->getDynStEn()))
                                        {
                                            retCode = RET_SRV_LIB_ERR_DUPLICATEKEY;
                                            copyBindOption.printMsg(ProcessingMessageNatEn::Error,
                                                                    retCode,
                                                                    SYS_Stringer("Unable to update record, duplicate key on the logical attribute: ", attribStp->sqlName));
                                        }
                                    }

                                case CopyArgCopyLogicalEn::Override:
                                    for (auto& attribStp : dictEntityStp->attr)
                                    {
                                        if (attribStp->primFlg == FALSE &&
                                            attribStp->logicalFlg == FALSE &&
                                            attribStp->calcEn != DictAttr_NoMD)
                                        {
                                            DBA_CopyDynFld(fromCopyRecordStp, attribStp->progN, toCopyRecordStp, attribStp->progN);
                                        }
                                    }
                                    break;

                                default:
                                    break;
                            }

                            if (retCode == RET_SUCCEED)
                            {
                                copyDynStpVector.push_back(fromCopyRecordStp);
                            }
                        }
                    }
                }
            }

            BuildBindOption outputBindOption = BuildBindOption::Categ::BusinessKeyOnlyShort;
            outputBindOption.sync(copyBindOption);
            outputBindOption.setDescObject(true);

            if (retCode == RET_SUCCEED)
            {
                std::vector<DBA_DYNFLD_STP> outputDynStpVector;
                if (copyDynStpVector.empty() == false)
                {
                    std::string copyString;
                    retCode = DBA_GetJSonStringFromDynStp(copyDynStpVector,
                                                          copyString,
                                                          inputBindOption,
                                                          *dbiConnPtr);

                    if (retCode == RET_SUCCEED)
                    {
                        retCode = DBA_GetDynStpFromJSonString(copyString,
                                                              outputDynStpVector,
                                                              copyBindOption,
                                                              mp,
                                                              *dbiConnPtr,
                                                              true);
                    }
                }

                for (auto& it : outputDynStpVector)
                {
                    std::vector<DBA_DYNFLD_STP> resultDynStpVector;
                    resultDynStpVector.push_back(it);

                    std::string resultString;
                    DBA_GetJSonStringFromDynStp(resultDynStpVector,
                                                resultString,
                                                outputBindOption,
                                                *dbiConnPtr);

                    ProcessingMessageNatEn importMessageNatEn = (RET_GET_LEVEL(retCode) == RET_LEV_ERROR ? ProcessingMessageNatEn::Error : ProcessingMessageNatEn::Success);
                    copyBindOption.printMsg(importMessageNatEn, retCode, resultString);
                }
            }

            auto importResultStp = copyBindOption.finish(retCode);

            if (retCode == RET_SUCCEED &&
                importResultStp != nullptr &&
                copyDynStpVector.empty() &&
                IS_NOTNULL(inputDynStpVector.back(), A_CopyArg_EntityDictId))
            {
                auto returnedEntityProfileStp = mp.allocDynst(FILEINFO, A_EntityProfile);
                if (inputBindOption.getEntityProfileStp() != nullptr)
                {
                    if (GET_ID(inputBindOption.getEntityProfileStp(), A_EntityProfile_Id) > 0)
                    {
                        SET_ID(returnedEntityProfileStp, A_EntityProfile_ParentProfileId, GET_ID(inputBindOption.getEntityProfileStp(), A_EntityProfile_Id));
                    }
                    else if (IS_NOTNULL(inputBindOption.getEntityProfileStp(), A_EntityProfile_ParentProfileId))
                    {
                        SET_ID(returnedEntityProfileStp, A_EntityProfile_ParentProfileId, GET_ID(inputBindOption.getEntityProfileStp(), A_EntityProfile_ParentProfileId));
                    }
                }

                inputBindOption.generateEntityConfig(GET_DICT(inputDynStpVector.back(), A_CopyArg_EntityDictId), returnedEntityProfileStp);

                SET_FK_RECORD(importResultStp, A_ProcessingResult_EntityProfileId, returnedEntityProfileStp);
                outputBindOption.setConfig("processing_result", "entity_profile_id", "all", EntityConfigElementRuleEn::Keep);
                outputBindOption.setConfig("entity_profile", "parent_profile_id", "", EntityConfigElementRuleEn::Keep);
            }

            std::vector<DBA_DYNFLD_STP> importResultStpVector;
            importResultStpVector.push_back(importResultStp);

            outputBindOption = BuildBindOption::Categ::ExportFullObject;
            DBA_GetJSonStringFromDynStp(importResultStpVector,
                                        outputString,
                                        outputBindOption,
                                        *dbiConnPtr);

        }
        else
        {
            retCode = RET_DBA_ERR_CANNOTCONNECT;
        }
    }
    else
    {
        retCode = RET_SRV_INFO_CLOSING_SUCCEED;
    }

    return retCode;
}


/************************************************************************/
/*  End of File                                                         */
/************************************************************************/

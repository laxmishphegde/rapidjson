/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DDLGENSPROC_CPP

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H

#include           "unidef.h"     /* Mandatory */
#include              "gen.h"
#include             "date.h"
#include              "dba.h"
#include      "ddlgensproc.h"
#include        "ddlgenvar.h"
#include   "ddlgenfromfile.h"
#include             "proc.h"

using namespace std;

/************************************************************************
**      External entry points
**
*************************************************************************/

/************************************************************************
**      Local functions
**
*************************************************************************/

/************************************************************************
**      Static definitions & data
**
*************************************************************************/

/************************************************************************
**      FONCTIONS
**
************************************************************************/

/************************************************************************
**
**  Function    :   DdlGenSProc()
**
**  Description :   Constructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
DdlGenSProc::DdlGenSProc(OBJECT_ENUM        paramObjectEn,
                         DdlGenContext     &paramDdlGenContext,
                         DdlGenVarHelper   *paramVarHelperPtr,
                         DdlGenEntity      *paramDdlGenEntityPtr,
                         DdlGenFile        *paramFileHelper,
                         TARGET_TABLE_ENUM  paramTargetTableEn)
    : DdlGen(paramObjectEn, DdlObj_SProc, paramDdlGenContext, paramVarHelperPtr, paramDdlGenEntityPtr, paramFileHelper, paramTargetTableEn)
    , m_dictSprocStp(nullptr)
    , m_bFromPscFile(false)
    , m_bCustomBody(false)
{
    this->m_dictSprocStp = &(this->ddlGenContextPtr->getDictSprocSt());
    this->init(false);
}

/************************************************************************
**
**  Function    :   ~DdlGenSProc()
**
**  Description :   Destructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
DdlGenSProc::~DdlGenSProc()
{
}

/************************************************************************
**
**  Function    :   DdlGenSProc::init()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
void DdlGenSProc::init(bool bSetName)
{
    DDL_OBJ_ENUM locDdlObjEn = this->getDdlObjEn();

    if (this->m_dictSprocStp->getObjectEn() != NullEntity)
    {
        locDdlObjEn = (this->m_dictSprocStp->functionFlg == TRUE ? DdlObj_Func : DdlObj_SProc);

        DdlGen::init(this->m_dictSprocStp->getObjectEn(),
                     this->m_dictSprocStp->outputDynTypeEn,
                     TRUE,
                     TRUE,
                     FALSE,
                     EntSecuLevel_Secured2ndLevel,
                     this->m_dictSprocStp->translateFlg);

        if (this->m_dictSprocStp->sqlName.empty() && bSetName)
        {
            this->setName();
        }

        this->setDdlObjSqlName(this->m_dictSprocStp->sqlName);
        this->setDdlObjFullSqlName(this->m_dictSprocStp->dbName, this->m_dictSprocStp->sqlName);

        if (this->m_dictSprocStp->procActionEn == Special)
        {
            locDdlObjEn = DdlObj_SpecSProc;
        }

        if (locDdlObjEn == DdlObj_SProc)
        {
            this->ddlObjName = "procedure";

            if (this->m_dictSprocStp->sqlName.empty() == false)
            {
                DBA_GetStoredProcsBySqlName(this->m_dictSprocStp->getObjectEn(), this->m_dictSprocStp->sqlName, this->m_dictSprocStp->m_storedProcAccessVector);

                for (auto it = this->m_dictSprocStp->m_storedProcAccessVector.begin(); it != this->m_dictSprocStp->m_storedProcAccessVector.end(); ++it)
                {
                    DBA_PROC_STP procStp = (*it);

                    if (procStp->action == Select &&
                        ((*procStp->inputDynStPtr) == Adm_Arg || (*procStp->inputDynStPtr) == NullDynSt) && /* PMSTA-30500 - LJE - 180320 */
                        (*procStp->outputDynStPtr) == GET_ADMINGUIST(this->m_dictSprocStp->getObjectEn()))
                    {
                        this->bManageAuthFlg = true;
                    }
                    else if (this->m_dictSprocStp->procActionEn == Custom ||
                             (this->m_dictSprocStp->procActionEn != procStp->action && it == this->m_dictSprocStp->m_storedProcAccessVector.begin()))
                    {
                        this->m_dictSprocStp->procActionEn = procStp->action;
                    }
                    else if (this->m_dictSprocStp->procActionEn != procStp->action)
                    {
                        this->printMsg(RET_DBA_ERR_INVDATA, "Mismatch procedure \"action\" for procedure, check the procedure definition (dbaprocdef.c)");
                    }

                    if (this->m_dictSprocStp->procAccessEn == ProcAccess_None)
                    {
                        if (this->m_dictSprocStp->procActionEn == Update ||
                            this->m_dictSprocStp->procActionEn == Insert)
                        {
                            if (procStp->procParamDefPtr == nullptr)
                            {
                                this->m_dictSprocStp->procAccessEn = ProcAccess_All;
                            }
                            else
                            {
                                for (int i = 0; procStp->procParamDefPtr[i].fldNbrPtr != UNUSED; ++i)
                                {
                                    if (procStp->procParamDefPtr[i].procParamTypeEn != ProcParamType_Output &&
                                        procStp->procParamDefPtr[i].procParamTypeEn != ProcParamType_Output_Indexed)
                                    {
                                        this->m_dictSprocStp->procAccessEn = ProcAccess_CustomKey;
                                        break;
                                    }
                                }

                                if (this->m_dictSprocStp->procAccessEn != ProcAccess_CustomKey)
                                {
                                    this->m_dictSprocStp->procAccessEn = ProcAccess_All;
                                }
                            }
                        }
                    }

                    if (this->m_dictSprocStp->procAccessEn == ProcAccess_All)
                    {
                        if (procStp->inputDynStPtr != nullptr &&
                            (*procStp->inputDynStPtr) != NullDynSt)
                        {
                            if (this->m_dictSprocStp->inputObjectEn == NullEntityCst)
                            {
                                this->m_dictSprocStp->inputObjectEn = GET_OBJ_DYNST(*procStp->inputDynStPtr);
                            }
                            else if (this->m_dictSprocStp->inputObjectEn != GET_OBJ_DYNST(*procStp->inputDynStPtr))
                            {
                                this->printMsg(RET_DBA_ERR_INVDATA, "Mismatch procedure \"input object\" for procedure, check the procedure definition (dbaprocdef.c)");
                            }

                        }
                        if (procStp->outputDynStPtr != nullptr &&
                            (*procStp->outputDynStPtr) != NullDynSt)
                        {
                            if (this->m_dictSprocStp->outputObjectEn == NullEntityCst)
                            {
                                this->m_dictSprocStp->outputObjectEn = GET_OBJ_DYNST(*procStp->outputDynStPtr);
                            }
                            else if (this->m_dictSprocStp->outputObjectEn != GET_OBJ_DYNST(*procStp->outputDynStPtr))
                            {
                                this->printMsg(RET_DBA_ERR_INVDATA, "Mismatch procedure \"output object\" for procedure, check the procedure definition (dbaprocdef.c)");
                            }

                        }
                    }
                }
            }
        }
        else if (locDdlObjEn == DdlObj_SpecSProc)
        {
            this->ddlObjName = "special procedure";
        }
        else if (locDdlObjEn == DdlObj_Func)
        {
            this->ddlObjName = "function";
        }
    }
    this->setDdlObjEn(locDdlObjEn);
}

/************************************************************************
**
**  Function    :   DdlGenSProc::reset()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 151120
**
*************************************************************************/
void DdlGenSProc::reset()
{
    if (this->varHelperPtr != NULL)
    {
        this->varHelperPtr->cleanAllVar();
    }
}

/************************************************************************
**
**  Function    :   DdlGenSProc::drop()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenSProc::drop()
{
    this->clearIndent();
    this->ddlGenContextPtr->m_bIgnoreDepends = true;

    string destDbName = this->m_dictSprocStp->dbName;

    this->ddlGenContextPtr->setDdlDestDbName(destDbName, this);

    if (EV_GenDdlContext.bSqlFileOnly)
    {
        this->bodySqlBlock
            << this->getCmdPrintMsg("Dropping procedure and function " + this->getDdlObjSqlName(), false) << endl
            << this->getCmdGo() << endl;
    }

    /* Before the drop of the real ddl object, to can have the source code to check */
    /* PMSTA-18593 - LJE - 150904 - For the first migration, drop also the function... */
    this->cmdType = DDlCmdType_Drop;

    DdlGenDbaAccessGuard ddlGenDbaAccessGuard(*this->ddlGenContextPtr);
    auto &dbaAccessSt = ddlGenDbaAccessGuard.getDdlGenDbaAccess();

    if (dbaAccessSt.isLoaded(DdlObj_Func) &&
        dbaAccessSt.isLoaded(DdlObj_SProc))
    {
        DDL_OBJ_ENUM removeDdlObjEn = DdlObj_Func;

        if (this->isFunctionEqProc() == false)
        {
            if (this->m_dictSprocStp->functionFlg == TRUE)
            {
                removeDdlObjEn = DdlObj_SProc;
            }
            DdlObjDefKey searchDdlObjDefKey(this->ddlGenContextPtr->m_rdbmsEn,
                                            removeDdlObjEn,
                                            destDbName,
                                            this->getEntitySqlName(),
                                            std::string(),
                                            this->getDdlObjSqlName());

            auto ddlObjPtr = dbaAccessSt.getDdlObjDef(searchDdlObjDefKey);

            if (ddlObjPtr != nullptr)
            {
                this->bodySqlBlock << this->getCmdDrop(destDbName, this->getEntitySqlName(), this->getDdlObjSqlName(), ddlObjPtr->getDdlObjEn());
                if (this->flush() == RET_SUCCEED)
                {
                    dbaAccessSt.eraseDdlObjDef(*ddlObjPtr);
                }
            }
        }

        if (this->isReplaceAllowed(this->getDdlObjEn()) == false)
        {
            if (this->m_dictSprocStp->functionFlg == TRUE)
            {
                removeDdlObjEn = DdlObj_Func;
            }
            else
            {
                removeDdlObjEn = this->m_ddlObjEn;
            }

            DdlObjDefKey newDdlObjDefKey(this->ddlGenContextPtr->m_rdbmsEn,
                                         removeDdlObjEn,
                                         destDbName,
                                         this->getEntitySqlName(),
                                         std::string(),
                                         this->getDdlObjSqlName());
            auto newDdlObjPtr = dbaAccessSt.getDdlObjDef(newDdlObjDefKey);

            if (newDdlObjPtr != nullptr)
            {
                this->cmdType = DDlCmdType_Drop;
                this->bodySqlBlock << this->getCmdDrop(destDbName, this->getEntitySqlName(), newDdlObjPtr->getDbObjName(), newDdlObjPtr->getDdlObjEn());
                if (this->flush() == RET_SUCCEED)
                {
                    dbaAccessSt.eraseDdlObjDef(*newDdlObjPtr);
                }
            }
        }
    }
    else
    {
        if (this->isIfExistsClause(this->getDdlObjEn()))
        {
            if (this->isReplaceAllowed(this->getDdlObjEn()) == false &&
                this->isFunctionEqProc() == false)
            {
                this->bodySqlBlock << this->getCmdDrop(destDbName, this->getEntitySqlName(), this->getDdlObjSqlName(), (this->m_dictSprocStp->functionFlg == FALSE ? DdlObj_Func : DdlObj_SProc));
                this->flush();
            }
        }
        else
        {
            if (this->m_dictSprocStp->functionFlg == FALSE)
            {
                this->bodySqlBlock << this->getCmdIfExsists(this->getCmdSelObjInDb(destDbName, this->getEntitySqlName(), this->getDdlObjSqlName(), DdlObj_Func),
                                                            "\t" + this->getDdlModif(this->getCmdDrop(destDbName, this->getEntitySqlName(), this->getDdlObjSqlName(), DdlObj_Func)),
                                                            string());
            }
            /* PMSTA-18593 - LJE - 150904 - For the first migration, drop also procedure... */
            else
            {
                this->bodySqlBlock << this->getCmdIfExsists(this->getCmdSelObjInDb(destDbName, this->getEntitySqlName(), this->getDdlObjSqlName(), DdlObj_SProc),
                                                            "\t" + this->getDdlModif(this->getCmdDrop(destDbName, this->getEntitySqlName(), this->getDdlObjSqlName(), DdlObj_SProc)),
                                                            string());
            }
            this->flush();
        }
        

        if (this->isReplaceAllowed(this->getDdlObjEn()) == false)
        {
            this->cmdType = DDlCmdType_Drop;
            if (this->isIfExistsClause(this->getDdlObjEn()))
            {
                this->bodySqlBlock << this->getCmdDrop(destDbName, this->getEntitySqlName(), this->getDdlObjSqlName(), this->getDdlObjEn());
            }
            else
            {
                this->bodySqlBlock << this->getCmdIfExsists(this->getCmdSelObjInDb(destDbName, this->getEntitySqlName(), this->getDdlObjSqlName(), this->getDdlObjEn()),
                                                            "\t" + this->getDdlModif(this->getCmdDrop(destDbName, this->getEntitySqlName(), this->getDdlObjSqlName(), this->getDdlObjEn())),
                                                            string());
            }
            this->flush();
        }
    }

    this->ddlGenContextPtr->m_bIgnoreDepends = false;
    return RET_SUCCEED;
}

/************************************************************************
**
**  Function    :   DdlGenSProc::printHeader()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenSProc::printHeader()
{
    RET_CODE          ret=RET_SUCCEED;
    DdlSprocParam    *languageVar;

    this->cmdType = DDlCmdType_Create;

    this->clearIndent();

    if (EV_GenDdlContext.bSqlFileOnly)
    {
        this->headerStream
            << this->getCmdPrintMsg("Creating " + this->ddlObjName + " " + this->getDdlObjFullSqlName(), false) << endl
            << this->getCmdGo() << endl;
    }

    this->ddlGenContextPtr->setDdlDestDbName(this->m_dictSprocStp->dbName, this);

    this->headerStream << this->getCmdCreate(this->m_dictSprocStp->dbName,
                                             this->getEntitySqlName(),
                                             this->getDdlObjSqlName(),
                                             this->getDdlObjEn());

    if ((languageVar = this->varHelperPtr->getParameter("language_dict_id")) != NULL && languageVar->varType == VarType_ExtraParamter)
    {
        if (this->ddlGenContextPtr->bLanguage == false)
        {
            this->ddlGenContextPtr->bLanguage = true;
        }
        this->translateFlg = TRUE;
    }

    /* Print declare variable in header if needed */
    this->printDeclareVariables(this->ddlGenContextPtr->m_initSqlBlock);

    if (this->varHelperPtr->printParamList(this->headerStream) == false)
    {
        stringstream declareStream;
        stringstream cursorParamStream;
        stringstream initParamStream;
        stringstream finalAssignStream;
        stringstream initAssignStream;
        string       cursorName = SYS_Stringer(this->getDdlObjSqlName(), "_cur");

        initParamStream << "\tselect ";
        cursorParamStream << "\tselect ";
        

        bool bCursorFirst = true;
        bool bInitFirst = true;
        auto paramList = this->varHelperPtr->getParamList();
        for (auto it = paramList->begin(); it != paramList->end(); ++it)
        {
            if ((*it)->getAccessNbr() == 0 &&
                this->m_dictSprocStp->procActionEn != Insert &&
                this->m_dictSprocStp->procActionEn != Update &&
                this->m_dictSprocStp->sqlName != "get_fin_analysis_all_domain")
            {
                this->printMsg(RET_DBA_INFO_NODATA, "Unused parameter @" + (*it)->sqlName + ", please remove it!");
            }

            if (bCursorFirst)
            {
                bCursorFirst = false;
            }
            else
            {
                cursorParamStream << ", \n\t       ";
            }

            string sqlName((*it)->sqlName);


            if ((*it)->getDataType() == TimeStampType)
            {
                sqlName = "row_version";
            }
            else if (sqlName == "user")
            {
                sqlName = "user_c";
            }

            cursorParamStream << sqlName << " as " << (*it)->printSqlName(DdlGenVar::KindOfPrint::Name);

            if ((*it)->m_bModify)
            {
                if (bInitFirst)
                {
                    bInitFirst = false;
                }
                else
                {
                    initParamStream << ", \n\t       ";
                }

                this->getCmdAssignOnSelect(*(*it), sqlName, finalAssignStream, initAssignStream, false, false);
                initParamStream << DdlGenDbi::getVarPrefix(this->ddlGenContextPtr->m_rdbmsEn) << cursorName << "." << (*it)->printSqlName(DdlGenVar::KindOfPrint::Name);
            }
        }

        if (bCursorFirst == false)
        {
            string entitySqlName;
            if (this->m_dictSprocStp->inputObjectEn != NullEntity)
            {
                entitySqlName = DBA_GetDictEntitySqlName(this->m_dictSprocStp->inputObjectEn);
            }
            else
            {
                AAAValueGuard<bool> bForceTableName(this->ddlGenContextPtr->bForceTableName, true);
                entitySqlName = this->getEntitySqlName();
            }
            cursorParamStream << "\n\tfrom " << "pp_" << entitySqlName;

            stringstream bodyStr;
            if (bInitFirst == false)
            {
                bodyStr << initParamStream.str() << finalAssignStream.str() << this->endOfCmd() << endl;
            }

            DdlGenVar *batchRowNumVar = this->varHelperPtr->getNewVariable(DictSprocClass::getBatchRowNumName(), IntType);
            batchRowNumVar->strDefault = "0";

            bodyStr << "\t" << batchRowNumVar->printSqlName() << this->getVarAssign() << batchRowNumVar->printSqlName() << " + 1" << this->endOfCmd() << endl;

            bodyStr
                << this->ddlGenContextPtr->m_initSqlBlock.str()
                << this->bodySqlBlock.str();
            this->bodySqlBlock.clear();
            this->ddlGenContextPtr->m_initSqlBlock.clear();

            this->bUnion = true;
            this->bodySqlBlock
                << getCursorRequest(cursorName,
                                    cursorParamStream.str(),
                                    string(),
                                    bodyStr.str());
            this->bUnion = false;
        }
    }

    if (this->ddlGenContextPtr->m_bHasUnknownCall == false)
    {
        ret = this->checkAllSProcParameters();
    }

    string deterministic;
    if (this->m_dictSprocStp->functionFlg == TRUE)
    {
        ret = this->getCmdReturnFunction(this->m_dictSprocStp->retDataType, this->headerStream);

        deterministic = DdlGenDbi::getDeterministic(this->m_dictSprocStp->bDeterministic);
    }
    else
    {
        ret = this->getCmdReturnProcedure(*this->m_dictSprocStp, this->headerStream);
    }

    string executeAs = DdlGenDbi::getExecuteAs(this->m_dictSprocStp->executeAsEn);
    
    if (deterministic.empty() == false || executeAs.empty() == false)
    {
        this->headerStream << "\n" << deterministic << executeAs;
    }

    if (this->m_dictSprocStp->bWithRecomplie)
    {
        this->headerStream << DdlGenDbi::getWithRecomplie();
    }

    this->printBeginProc(this->headerStream, this->varHelperPtr);

    /* PMSTA-26250 - LJE - 170404 */
    this->headerStream << this->ddlGenContextPtr->m_createTmpTableStream.str();
    this->ddlGenContextPtr->m_createTmpTableStream.clear();
    this->ddlGenContextPtr->m_createTmpTableStream.str(string());

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenSProc::printFooter()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
**  Modif       :   PMSTA-12491 - RPO - 110815 - new parameter data profile code to error message 20128
**
*************************************************************************/
RET_CODE DdlGenSProc::printFooter()
{
    RET_CODE          ret=RET_SUCCEED;

    this->setPreIndent(std::string());
    this->clearIndent();
    this->setIndent(1);

    this->setIndent(-1);

    if (this->m_dictSprocStp->functionFlg == TRUE)
    {
        this->footerStream << endl << this->getCmdEndFunc();
    }
    else
    {
        this->footerStream << endl << this->getCmdEndSProc();
    }

    this->headerStream << this->ddlGenContextPtr->m_initSqlBlock.str();

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenSProc::printWhereClause()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenSProc::printWhereClause(FLAG_T locCodifFlg)
{
    RET_CODE ret=RET_SUCCEED;

    for (auto it = this->m_dictSprocStp->m_paramProcAttribVector.begin(); it != this->m_dictSprocStp->m_paramProcAttribVector.end(); it++)
    {
        DdlGenVar *paramVarPtr;
        if (it->deletedFlg == TRUE)
            continue;

        if (it->inputFlg == TRUE &&
            it->codifFlg == locCodifFlg)
        {
            if (it->codifFlg == FALSE)
            {
                paramVarPtr = this->varHelperPtr->getVariable(it->m_sqlName);
            }
            else
            {
                paramVarPtr = this->varHelperPtr->getVariable(it->attrStp->sqlName);
            }

            if (paramVarPtr != NULL)
            {
                this->whereStream << getWhereOrAnd() << this->getWhereComp(getAlias() + it->attrStp->sqlName,
                                                                           it->attrStp,
                                                                           paramVarPtr->printSqlName(),
                                                                           nullptr,
                                                                           "=",
                                                                           false);
            }
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenSProc::printCheckCmd()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-29885 - LJE - 180123
**
*************************************************************************/
RET_CODE DdlGenSProc::printCheckCmd(std::stringstream &outStream,
                                    DICT_ENTITY_STP    chkDictEntityStp,
                                    bool               bForceCurrentBusinessEntity,
                                    bool               bAddCheck)
{
    RET_CODE          ret = RET_SUCCEED;
    bool              bCheckMultiEntity = false;

    stringstream chkStream;

    /* PMSTA-29885 - LJE - 180123 */
    if (bAddCheck == false)
    {
        if (chkDictEntityStp->linkedEntityStp &&
            chkDictEntityStp->dbRuleEn == DbRule_Standard &&
            chkDictEntityStp->linkedEntityStp->dbRuleEn == DbRule_Standard &&
            chkDictEntityStp->linkedEntityStp->isPhysicalEntity(TargetTable_Main) &&    /* PMSTA-46675 - LJE - 211014 */
            chkDictEntityStp->linkedEntityStp->entNatEn == chkDictEntityStp->entNatEn &&
            (chkDictEntityStp->pkRuleEn == PkRule_NoIdentity || chkDictEntityStp->linkedEntityStp->pkRuleEn == PkRule_NoIdentity))
        {
            return ret;
        }


        outStream << newLine() << "#IF @entity_dict_id = " << chkDictEntityStp->entDictId;


        if (chkDictEntityStp->linkEntitiesMap.empty() == false)
        {
            for (auto it = chkDictEntityStp->linkEntitiesMap.begin(); it != chkDictEntityStp->linkEntitiesMap.end(); ++it)
            {
                if (it->second->dbRuleEn == DbRule_Standard &&
                    it->second->entNatEn == chkDictEntityStp->entNatEn &&
                    it->second->logicalFlg == FALSE &&
                    (chkDictEntityStp->pkRuleEn == PkRule_NoIdentity || it->second->pkRuleEn == PkRule_NoIdentity))
                {
                    outStream << newLine() << "or @entity_dict_id = " << it->second->entDictId;
                }
            }
        }

        outStream << newLine() << "#{";
        this->setIndent(1);

        chkStream
            << this->newLine() << "#NO_SECURED"
            << this->newLine() << "#NO_MULTI_ENTITY";
    }

    chkStream
        << this->newLine() << "/* verify that the id exists on this table */";

    if (bAddCheck == false)
    {
        chkStream
            << this->newLine() << "#IF_NOT_EXISTS (";
    }
    else
    {
        chkStream
            << this->newLine() << "#IF_EXISTS (";
    }

    this->setIndent(1);

    chkStream
        << this->newLine() << "#SELECT " << chkDictEntityStp->mdSqlName << " null"
        << this->newLine() << "1"
        << this->newLine() << "#FROM"
        << this->newLine() << "#WHERE"
        << this->newLine() << chkDictEntityStp->primKeyTab[0]->sqlName << " = @" << this->m_dictSprocStp->m_paramProcAttribVector[1].m_sqlName;

    if (bForceCurrentBusinessEntity &&
        chkDictEntityStp->ownerBusinessEntAttrStp &&
        chkDictEntityStp->multiEntityCateg.isAddCheckOnCurrentBe())             /* PMSTA-30152 - LJE - 180509 */
    {
        chkStream
            << this->newLine() << chkDictEntityStp->ownerBusinessEntAttrStp->sqlName << " = " << this->getConnBusinessEntityId();

        bCheckMultiEntity = true;
    }

    chkStream
        << this->newLine() << "#END"
        << this->newLine() << ")";

    this->setIndent(-1);
    chkStream
        << this->newLine() << "#{";
    this->setIndent(1);

    if (bAddCheck == false)
    {
        if (chkDictEntityStp->linkEntitiesMap.empty() == false)
        {
            for (auto it = chkDictEntityStp->linkEntitiesMap.begin(); it != chkDictEntityStp->linkEntitiesMap.end(); ++it)
            {
                if (it->second->dbRuleEn == DbRule_Standard &&
                    it->second->entNatEn == chkDictEntityStp->entNatEn &&
                    it->second->logicalFlg == FALSE &&
                    (chkDictEntityStp->pkRuleEn == PkRule_NoIdentity || it->second->pkRuleEn == PkRule_NoIdentity))
                {
                    this->printCheckCmd(chkStream, it->second, bForceCurrentBusinessEntity, true);
                }
            }
        }
    }
    else
    {
        chkStream
            << this->newLine() << "#RETURN(0)";

        this->setIndent(-1);
        chkStream
            << this->newLine() << "#}";
    }

    if (chkDictEntityStp->ownerBusinessEntAttrStp && bForceCurrentBusinessEntity && bCheckMultiEntity)
    {
        chkStream
            << this->newLine() << "#IF_EXISTS (";

        this->setIndent(1);

        chkStream
            << this->newLine() << "#SELECT " << chkDictEntityStp->mdSqlName << " null"
            << this->newLine() << "1"
            << this->newLine() << "#FROM"
            << this->newLine() << "#WHERE"
            << this->newLine() << chkDictEntityStp->primKeyTab[0]->sqlName << " = @" << this->m_dictSprocStp->m_paramProcAttribVector[1].m_sqlName
            << this->newLine() << "#END"
            << this->newLine() << ")";

        this->setIndent(-1);
        chkStream
            << this->newLine() << "#{";
        this->setIndent(1);

        chkStream
            << this->newLine() << "\t#APPL_RAISERROR 20565, " << this->getDdlObjSqlName()
            << this->newLine() << "\t#ROLLBACK_TRAN"
            << this->newLine() << "\t#RETURN";

        this->setIndent(-1);
        chkStream
            << this->newLine() << "#}";

    }

    if (bAddCheck == false)
    {
        string noteStr = "note";
        chkStream
            << this->newLine() << "#DECLARE @" << noteStr << " note_t"
            << this->newLine() << "#ASSIGN @" << noteStr << " = #CONVERT(note_t, @" << this->m_dictSprocStp->m_paramProcAttribVector[1].m_sqlName << ")"
            << this->newLine() << "#APPL_RAISERROR 20014, #CURR_DDL_OBJECT, '" << chkDictEntityStp->primKeyTab[0]->sqlName << "', @" << noteStr << ", '" << chkDictEntityStp->mdSqlName << "'"
            << this->newLine() << "#RETURN(-1)";

        this->setIndent(-1);
        chkStream
            << this->newLine() << "#}";

        chkStream
            << this->newLine() << "#RETURN(0)";

        chkStream
            << this->newLine() << "#MULTI_ENTITY"
            << this->newLine() << "#SECURED";

        outStream << this->scriptDdlGen->buildScript(chkStream.str(), DdlObj_SProc);

        this->setIndent(-1);
        outStream << newLine() << "#}";
    }
    else
    {
        outStream << chkStream.str();
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenSProc::printSpecialSProc()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenSProc::printSpecialSProc()
{
    RET_CODE          ret = RET_SUCCEED;
    OBJECT_ENUM       genObjectEn = InvalidEntity;
    stringstream      locStream;
    bool              bForceCurrentBusinessEntity = false;

    this->setPreIndent(std::string());
    this->clearIndent();
    this->setIndent(1);

    if (strcasecmp(this->getDdlObjSqlName().c_str(), "chk_dict_entity_object_id") == 0 ||
        strcasecmp(this->getDdlObjSqlName().c_str(), "chk_dict_entity_object_for_upd") == 0)
    {
        if (this->ddlGenContextPtr->ddlGenAction.isBootStrapLevel())
        {
            locStream << newLine() << "#RETURN";
        }
        else
        {
            if (strcasecmp(this->getDdlObjSqlName().c_str(), "chk_dict_entity_object_for_upd") == 0)
            {
                bForceCurrentBusinessEntity = true;
            }

            this->footerStream << this->newLine();

            locStream
                << this->newLine() << "#IF @entity_dict_id is null and @object_id is not null"
                << this->newLine() << "#{";

            this->setIndent(1);
            locStream
                << this->newLine() << "#APPL_RAISERROR 20085, #CURR_DDL_OBJECT, 'entity_dict_id', 'object_id'"
                << this->newLine() << "#RETURN(-1)";

            this->setIndent(-1);

            locStream
                << this->newLine() << "#}" << endl;

            locStream
                << this->newLine() << "#IF @object_id is null"
                << this->newLine() << "#{";

            this->setIndent(1);
            locStream
                << this->newLine() << "#RETURN(0)";

            this->setIndent(-1);

            locStream
                << this->newLine() << "#}" << endl;

            map<DICT_T, DICT_ENTITY_STP> entityStpMap;
            while (genObjectEn < LASTENTITYOBJECT)
            {
                DICT_ENTITY_STP chkDictEntityStp = DBA_GetDictEntitySt(++genObjectEn);

                if (chkDictEntityStp != nullptr)
                {
                    if (chkDictEntityStp != NULL &&
                        (chkDictEntityStp->xdStatusEn == XdStatus_Inserted || chkDictEntityStp->xdStatusEn == XdStatus_Deprecated) &&
                        chkDictEntityStp->objectEn != InvalidEntity &&
                        chkDictEntityStp->entNatEn != EntityNat_All &&
                        chkDictEntityStp->entNatEn != EntityNat_TempTable &&
                        chkDictEntityStp->entNatEn != EntityNat_PersistedFmt &&
                        chkDictEntityStp->entNatEn != EntityNat_ReportFmt &&   /* PMSTA-22072 - LJE - 160108 */
                        chkDictEntityStp->entNatEn != EntityNat_SearchFmt &&
                        chkDictEntityStp->entNatEn != EntityNat_DerivedEntity &&   /* PMSTA-26250 - LJE - 170331 */
                        chkDictEntityStp->isPhysicalEntity(TargetTable_Main) &&
                        chkDictEntityStp->primKeyNbr == 1 &&
                        (chkDictEntityStp->primKeyTab[0]->dataTpProgN == IdType ||
                        chkDictEntityStp->primKeyTab[0]->dataTpProgN == DictType))
                    {
                        entityStpMap.insert(make_pair(chkDictEntityStp->entDictId, chkDictEntityStp));
                    }
                }
            }

            for (auto it = entityStpMap.begin(); it != entityStpMap.end(); ++it)
            {
                this->printCheckCmd(locStream, it->second, bForceCurrentBusinessEntity);
            }

            this->setIndent(-1);

            locStream
                << this->newLine() << "#DECLARE @txt_entity_dict_id	code_t"
                << this->newLine() << "#ASSIGN @txt_entity_dict_id = #CONVERT(note_t, @entity_dict_id)"
                << this->newLine() << "#APPL_RAISERROR 20031, #CURR_DDL_OBJECT, @txt_entity_dict_id"
                << this->newLine() << "#RETURN(-1)";
        }
    }
    else if (strcasecmp(this->getDdlObjSqlName().c_str(), "get_dict_entity_object_id") == 0)
    {
        if (this->ddlGenContextPtr->ddlGenAction.isBootStrapLevel())
        {
            locStream << newLine() << "#RETURN";
        }
        else
        {

            this->footerStream << this->newLine();

            locStream << newLine() << "#ASSIGN @object_id = null";

            map<DICT_T, DICT_ENTITY_STP> entityStpMap;
            while (genObjectEn < LASTENTITYOBJECT)
            {
                DICT_ENTITY_STP chkDictEntityStp = DBA_GetDictEntitySt(genObjectEn);
                genObjectEn++;

                if (chkDictEntityStp != nullptr)
                {
                    if (chkDictEntityStp != NULL &&
                        (chkDictEntityStp->xdStatusEn == XdStatus_Inserted || chkDictEntityStp->xdStatusEn == XdStatus_Deprecated) &&
                        chkDictEntityStp->entNatEn != EntityNat_All &&
                        chkDictEntityStp->entNatEn != EntityNat_TempTable &&
                        chkDictEntityStp->entNatEn != EntityNat_PersistedFmt &&
                        chkDictEntityStp->entNatEn != EntityNat_ReportFmt &&    /* PMSTA-22072 - LJE - 160108 */
                        chkDictEntityStp->entNatEn != EntityNat_SearchFmt &&
                        chkDictEntityStp->entNatEn != EntityNat_DerivedEntity &&   /* PMSTA-26250 - LJE - 170331 */
                        chkDictEntityStp->isPhysicalEntity(TargetTable_Main) &&
                        chkDictEntityStp->bkAttr != NULL &&
                        chkDictEntityStp->primKeyTab != NULL &&
                        (chkDictEntityStp->objectEn == List ||
                        (chkDictEntityStp->primKeyNbr == 1 &&
                        (chkDictEntityStp->primKeyTab[0]->dataTpProgN == IdType ||
                        chkDictEntityStp->primKeyTab[0]->dataTpProgN == DictType) &&
                        chkDictEntityStp->bkAttrNbr == 1 &&
                        (chkDictEntityStp->bkAttr[0]->dataTpProgN == CodeType ||
                        chkDictEntityStp->bkAttr[0]->dataTpProgN == SysnameType))))
                    {
                        entityStpMap.insert(make_pair(chkDictEntityStp->entDictId, chkDictEntityStp));
                    }
                }
            }

            for (auto it = entityStpMap.begin(); it != entityStpMap.end(); ++it)
            {
                DICT_ENTITY_STP chkDictEntityStp = it->second;

                locStream << newLine() << "#IF @entity_dict_id = " << chkDictEntityStp->entDictId;
                locStream << newLine() << "#{";
                this->setIndent(1);

                if (chkDictEntityStp->objectEn == List)
                {
                    locStream
                        << newLine() << "#IF @list_entity_dict_id is NULL"
                        << newLine() << "#{";
                    this->setIndent(1);
                    locStream
                        << newLine() << "#APPL_RAISERROR 20165, get_dict_entity_object_id, 'List', 'list_entity_dict_id'"
                        << newLine() << "#ASSIGN @object_id = 0";
                    this->setIndent(-1);
                    locStream
                        << newLine() << "#}"
                        << newLine() << "#ELSE"
                        << newLine() << "#{";
                    this->setIndent(1);
                    locStream
                        << newLine() << "#SELECT list null"
                        << newLine() << "@object_id = id"
                        << newLine() << "#FROM "
                        << newLine() << "#WHERE "
                        << newLine() << "entity_dict_id = @list_entity_dict_id"   /*DLA - PMSTA-26873 - 170405 */
                        << newLine() << "code = @object_code"                     /*DLA - PMSTA-26873 - 170405 */
                        << newLine() << "#END"
                        << newLine() << "#RETURN(0)";
                    this->setIndent(-1);
                    locStream << newLine() << "#}";
                }
                else
                {
                    locStream
                        << newLine() << "#SELECT " << chkDictEntityStp->mdSqlName << " null"
                        << newLine() << "@object_id = " << chkDictEntityStp->primKeyTab[0]->sqlName
                        << newLine() << "#FROM"
                        << newLine() << "#WHERE"
                        << newLine() << chkDictEntityStp->bkAttr[0]->sqlName << " = @object_code"
                        << newLine() << "#END"
                        << newLine() << "#RETURN(0)";
                }
                this->setIndent(-1);
                locStream << newLine() << "#}";
            }


            locStream
                << newLine() << "#IF @object_id is null"
                << newLine() << "#{"
                << newLine() << "\t#ASSIGN @object_id = 0"
                << newLine() << "#}";

            locStream << newLine() << "#DECLARE @txt_entity_dict_id	code_t";
            locStream << newLine() << "#ASSIGN @txt_entity_dict_id = #CONVERT(note_t, @entity_dict_id)";
            locStream << newLine() << "#APPL_RAISERROR 20031, 'get_dict_entity_object_id', @txt_entity_dict_id";
            locStream << newLine() << this->getReturnInProc("-1");
        }
    }

    this->bodySqlBlock << this->scriptDdlGen->buildScript(locStream.str(), DdlObj_SProc, -1);
    ret = this->scriptDdlGen->lastErrRetCode;

    this->setIndent(-1);
    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenSProc::createIns()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenSProc::createIns()
{
    RET_CODE          ret=RET_SUCCEED;

    string            locBodyStr = this->getTemplateBody(CfgTemplate_Standard, "insert");

    if (locBodyStr.empty())
    {
        stringstream      locBodyStream;
        locBodyStream
            << this->newLine() << "#INSERT " << this->getDictEntityStp()->mdSqlName << " all_db"
            << this->newLine() << "#VALUES";

        if (this->getDictEntityStp()->pkRuleEn == PkRule_Identity && this->getDictEntityStp()->primKeyNbr == 1 && this->getDictEntityStp()->primKeyTab)
        {
            locBodyStream
                << this->newLine() << "#IDENTITY @" << this->getDictEntityStp()->primKeyTab[0]->sqlName;
        }

        locBodyStream
            << this->newLine() << "#ERROR " << this->getReturnStatusName(false)
            << this->newLine() << "#END"
            << this->newLine()
            << this->newLine() << "#CALL_RETURN_STATUS" << endl;

        locBodyStr = locBodyStream.str();
    }

    stringstream bodyStream;

    bodyStream << this->m_dictSprocStp->getSprocStdBeginStr() << endl
        << "#END" << endl
        << locBodyStr << endl
        << "#SPROC_END" << endl;

    this->bodySqlBlock << this->scriptDdlGen->buildScript(bodyStream.str(), DdlObj_SProc);
    ret = this->scriptDdlGen->lastErrRetCode;

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenSProc::createInsByCd()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenSProc::createInsByCd()
{
    RET_CODE          ret=RET_SUCCEED;

    this->cmdType = DDlCmdType_Create;
    this->securityLevelEn = EntSecuLevel_NoSecured;
    /* OCS-39654 - LJE - 120213 */
    this->thirdSecuredFlg = FALSE;
    this->thirdCompoSecuredFlg = FALSE;

    this->custFlg = FALSE;
    this->precompFlg = FALSE;

    if ((ret = this->initRequest()) == RET_SUCCEED && /* PMSTA-14607 - LJE - 120713 */
        (ret = this->setSprocParam()) == RET_SUCCEED &&
        (ret = this->printCallInsertRequest()) == RET_SUCCEED &&
        (ret = this->printHeader()) == RET_SUCCEED &&
        (ret = this->printFooter()) == RET_SUCCEED)
    {
        ret = this->flush();
    }
    this->m_dictSprocStp->m_paramProcAttribVector.clear();

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenSProc::createUpd()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenSProc::createUpd()
{
    RET_CODE          ret=RET_SUCCEED;

    string            key("update");

    if (this->targetTableEn == TargetTable_UserDefinedFields)
    {
        key += "_ud";

        if (this->getDictEntityStp()->meSpecialisationEn == MeSpecialisation_Applied)
        {
            for (auto it = this->getDictEntityStp()->attribMap.begin(); it != this->getDictEntityStp()->attribMap.end(); ++it)
            {
                if (it->second->custFlg == TRUE && it->second->meSpecialisationEn == MeSpecialisation_Applied)
                {
                    key += "_me_spec";
                    break;
                }
            }
        }

        this->ddlGenContextPtr->m_dependsAccessSet.insert(DdlGenDependKey(this->getDictEntityStp()->entDictId, this->getDictEntityStp()->mdSqlName, DictDependsAccessEn::Update, DynType_UdOnly));
    }

    string  locBodyStr = this->getTemplateBody(CfgTemplate_Standard, key);

    if (locBodyStr.empty())
    {
        ret = RET_DBA_ERR_INVDATA;
        this->printMsg(ret, "Unable to create update procedure (" + this->getDdlObjSqlName() + "), the template is missing");
    }
    else /* PMSTA-26250 - LJE - 170501 */
    {
        stringstream bodyStream;

        bodyStream << this->m_dictSprocStp->getSprocStdBeginStr() << endl
            << "#END" << endl
            << locBodyStr << endl
            << "#SPROC_END" << endl;

        this->bodySqlBlock << this->scriptDdlGen->buildScript(bodyStream.str(), DdlObj_SProc);
        ret = this->scriptDdlGen->lastErrRetCode;
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenSProc::createDel()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenSProc::createDel()
{
    RET_CODE          ret = RET_SUCCEED;

    string  locBodyStr = this->getTemplateBody(CfgTemplate_Standard, "delete");

    if (locBodyStr.empty())
    {
        ret = RET_DBA_ERR_INVDATA;
        this->printMsg(ret, "Unable to create delete procedure (" + this->getDdlObjSqlName() + "), the template is missing");
    }
    else /* PMSTA-26250 - LJE - 170501 */
    {
        stringstream bodyStream;

        bodyStream << this->m_dictSprocStp->getSprocStdBeginStr() << endl
            << "#END" << endl
            << locBodyStr << endl
            << "#SPROC_END" << endl;

        this->bodySqlBlock << this->scriptDdlGen->buildScript(bodyStream.str(), DdlObj_SProc);

        ret = this->scriptDdlGen->lastErrRetCode;
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenSProc::createTruncate()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14655 - LJE - 121001
**
*************************************************************************/
RET_CODE DdlGenSProc::createTruncate()
{
    RET_CODE          ret=RET_SUCCEED;

    this->cmdType = DDlCmdType_Create;
    this->securityLevelEn = EntSecuLevel_NoSecured;
    this->thirdSecuredFlg = FALSE;
    this->thirdCompoSecuredFlg = FALSE;

    this->custFlg = FALSE;
    this->precompFlg = FALSE;

    if ((ret = this->initRequest()) == RET_SUCCEED &&
        (ret = this->printTruncateRequest()) == RET_SUCCEED &&
        (ret = this->printHeader()) == RET_SUCCEED &&
        (ret = this->printFooter()) == RET_SUCCEED)
    {
        ret = this->flush();
    }

    this->m_dictSprocStp->m_paramProcAttribVector.clear();

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenSProc::createChk()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenSProc::createChk()
{
    RET_CODE          ret=RET_SUCCEED;

    this->cmdType = DDlCmdType_Create;
    this->securityLevelEn = EntSecuLevel_NoSecured;
    /* OCS-39654 - LJE - 120213 */
    this->thirdSecuredFlg = FALSE;
    this->thirdCompoSecuredFlg = FALSE;

    this->custFlg = FALSE;
    this->precompFlg = FALSE;

    if ((ret = this->initRequest()) == RET_SUCCEED && /* PMSTA-14607 - LJE - 120713 */
        (ret = this->setSprocParam()) == RET_SUCCEED &&
        (ret = this->printCheckRequest(this->bodySqlBlock)) == RET_SUCCEED &&
        (ret = this->printHeader()) == RET_SUCCEED &&
        (ret = this->printFooter()) == RET_SUCCEED)
    {
        ret = this->flush();
    }
    this->m_dictSprocStp->m_paramProcAttribVector.clear();

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenSProc::createGet()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenSProc::createGet()
{
    return this->createSel(false);
}

/************************************************************************
**
**  Function    :   DdlGenSProc::createSel()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenSProc::createSel(bool bOrder)
{
    RET_CODE          ret = RET_SUCCEED;

    stringstream      requestStream;
    DICT_ENTITY_STP   locDictEntityStp = this->getDictEntityStp();

    this->cmdType = DDlCmdType_Create;

    this->setObjectEn(this->m_dictSprocStp->getObjectEn());
    this->outputDynNatEn = this->m_dictSprocStp->outputDynTypeEn;
    this->securityLevelEn = this->getDefSecuredLevel();

    if (this->m_dictSprocStp->outputDynTypeEn == DynType_All)
    {
        this->custFlg    = TRUE;
        this->precompFlg = TRUE;
    }
    else if (this->m_dictSprocStp->outputDynTypeEn == DynType_AllDb ||
             this->m_dictSprocStp->outputDynTypeEn == DynType_Full ||
             this->m_dictSprocStp->outputDynTypeEn == DynType_FullDb)
    {
        this->custFlg    = FALSE;
        this->precompFlg = FALSE;
    }
    else
    {
        this->custFlg    = FALSE;
        this->precompFlg = FALSE;
    }

    /* PMSTA-14688 - LJE - 120723 */
    if (this->bManageAuthFlg || this->m_dictSprocStp->procAccessEn == ProcAccess_PrimaryKey || this->m_dictSprocStp->outputDynTypeEn == DynType_All) /* PMSTA-28059 - LJE - 170811 */
    {
        requestStream << this->newLine() << "#AUTH_FLAG";

        this->bManageAuthFlg = true;
    }

    if ((ret = this->initRequest()) == RET_SUCCEED && /* PMSTA-14607 - LJE - 120713 */
        (ret = this->setSprocParam()) != RET_SUCCEED)
    {
        return ret;
    }

    if (this->bodySqlBlock.str().empty())
    {
        if (this->m_dictSprocStp->synonymFlg == TRUE)
        {
            if (this->m_dictSprocStp->procAccessEn == ProcAccess_BusinessKey)
            {
                if (locDictEntityStp->primKeyNbr == 1 &&
                    locDictEntityStp->bkAttrNbr == 1)
                {
                    string pkSqlName = locDictEntityStp->primKeyTab[0]->sqlName;
                    string bkSqlName = locDictEntityStp->bkAttr[0]->sqlName;
                    requestStream
                        << this->newLine() << "#DECLARE @" << pkSqlName << " id_t"
                        << endl
                        << this->newLine() << "#IF @codif_id is not null"
                        << this->newLine() << "#AND_EXISTS (select 'x'"
                        << this->newLine() << "\tfrom codification co"
                        << this->newLine() << "\twhere co.id = @codif_id"
                        << this->newLine() << "\tand co.internal_codif_f = 0"
                        << this->newLine() << "\tand co.syn_entity_dict_id = " << locDictEntityStp->entDictId << ")"
                        << this->newLine() << "#{";

                    this->setIndent(1);

                    requestStream
                        << this->newLine() << "#SELECT synonym null sy"
                        << this->newLine() << "@" << pkSqlName << " = sy.object_id"
                        << this->newLine() << "#FROM"
                        << this->newLine() << "#WHERE"
                        << this->newLine() << "sy.code = @" << bkSqlName
                        << this->newLine() << "sy.codification_id = @codif_id"
                        << this->newLine() << "sy.entity_dict_id = " << locDictEntityStp->entDictId
                        << this->newLine() << "#END"
                        << this->newLine() << "#}";

                    this->setIndent(-1);

                    requestStream
                        << endl
                        << this->newLine() << "#IF @" << pkSqlName << " is not null"
                        << this->newLine() << "#{";

                    this->setIndent(1);

                    requestStream
                        << this->newLine() << "#SELECT " << locDictEntityStp->mdSqlName << " " << this->m_dictSprocStp->getOutputDynTypeStr()
                        << this->newLine() << bkSqlName << " = @" << bkSqlName
                        << this->newLine() << "#FROM"
                        << this->newLine() << "#WHERE"
                        << this->newLine() << "pk"
                        << this->newLine() << "#END";

                    this->setIndent(-1);
                }
            }
            else
            {
                requestStream
                    << this->newLine() << "#IF @codif_id is not null"
                    << this->newLine() << "#AND_NOT_EXISTS (select 'x'"
                    << this->newLine() << "\tfrom codification co"
                    << this->newLine() << "\twhere co.id = @codif_id"
                    << this->newLine() << "\tand co.internal_codif_f = 1"
                    << this->newLine() << "\tand co.syn_entity_dict_id = " << locDictEntityStp->entDictId << ")"
                    << this->newLine() << "#{";

                this->setIndent(1);

                requestStream
                    << this->newLine() << "#CODIF"
                    << this->newLine() << "#SELECT " << locDictEntityStp->mdSqlName << " " << this->m_dictSprocStp->getOutputDynTypeStr()
                    << this->newLine() << "#FROM"
                    << this->newLine() << "#WHERE"
                    << this->newLine() << this->m_dictSprocStp->getProcAccessStr();

                if (bOrder)
                {
                    requestStream
                        << this->newLine() << "#ORDER";
                }

                requestStream
                    << this->newLine() << "#END"
                    << this->newLine() << "#NO_CODIF";

                this->setIndent(-1);
            }

            requestStream
                << this->newLine() << "#}"
                << this->newLine() << "#ELSE"
                << this->newLine() << "#{";

            this->setIndent(1);
        }

        requestStream
            << this->newLine() << "#SELECT " << locDictEntityStp->mdSqlName << " " << this->m_dictSprocStp->getOutputDynTypeStr()
            << this->newLine() << "#FROM"
            << this->newLine() << "#WHERE"
            << this->newLine() << this->m_dictSprocStp->getProcAccessStr();

        if (bOrder)
        {
            requestStream
                << this->newLine() << "#ORDER";
        }

        requestStream
            << this->newLine() << "#END";

        if (this->m_dictSprocStp->synonymFlg == TRUE)
        {
            this->setIndent(-1);

            requestStream
                << this->newLine() << "#}";
        }

        if (this->m_dictSprocStp->procAccessEn == ProcAccess_PrimaryKey || this->m_dictSprocStp->outputDynTypeEn == DynType_All)
        {
            requestStream << this->newLine() << "#NO_AUTH_FLAG";
        }

        this->bodySqlBlock << this->scriptDdlGen->buildScript(requestStream.str(), DdlObj_SProc);
        if ((ret = this->scriptDdlGen->lastErrRetCode) != RET_SUCCEED)
        {
            return ret;
        }
    }

    if ((ret = this->printHeader()) != RET_SUCCEED ||
        (ret = this->printFooter()) != RET_SUCCEED)
    {
        return ret;
    }

    ret = this->flush();

    if (this->m_dictSprocStp->procAccessEn == ProcAccess_PrimaryKey ||
        this->m_dictSprocStp->procAccessEn == ProcAccess_BusinessKey)
    {
        this->m_dictSprocStp->m_paramProcAttribVector.clear();
    }

    this->bManageAuthFlg = true;

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenSProc::createCpy()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 111202
**
*************************************************************************/
RET_CODE DdlGenSProc::createCopy()
{
    RET_CODE          ret=RET_SUCCEED;

    this->cmdType = DDlCmdType_Create;
    this->setObjectEn(this->m_dictSprocStp->getObjectEn());
    this->outputDynNatEn = DynType_All;

    this->securityLevelEn = this->getDefSecuredLevel();
    this->custFlg = TRUE;
    this->precompFlg = FALSE;

    if ((ret = this->initRequest()) == RET_SUCCEED && /* PMSTA-14607 - LJE - 120713 */
        (ret = this->getParam4Cpy()) != RET_SUCCEED)
    {
        return ret;
    }

    if ((ret = this->printSelListRequest()) == RET_SUCCEED &&
        (ret = this->printFromRequest()) == RET_SUCCEED &&
        (ret = this->printWhereClause()) == RET_SUCCEED &&
        (ret = this->printWhereRequest()) == RET_SUCCEED)
    {
        if ((ret = this->printHeader()) != RET_SUCCEED ||
            (ret = this->printFooter()) != RET_SUCCEED)
        {
            return ret;
        }

        ret = this->flush();
    }

    this->m_dictSprocStp->m_paramProcAttribVector.clear();

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenSProc::createSpecial()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-16729 - LJE - 140205
**
*************************************************************************/
RET_CODE DdlGenSProc::createSpecial()
{
    RET_CODE          ret = RET_SUCCEED;

    this->cmdType                = DDlCmdType_Create;
    this->securityLevelEn        = EntSecuLevel_Secured;
    this->thirdSecuredFlg        = FALSE;
    this->thirdCompoSecuredFlg   = FALSE;
    this->custFlg                = FALSE;
    this->precompFlg             = FALSE;

    if ((ret = this->initRequest()) == RET_SUCCEED && /* PMSTA-14607 - LJE - 120713 */
        (ret = this->setSprocParam()) == RET_SUCCEED &&
        (ret = this->printSpecialSProc()) == RET_SUCCEED &&
        (ret = this->printHeader()) == RET_SUCCEED &&
        (ret = this->printFooter()) == RET_SUCCEED)
    {
        ret = this->flush();
    }
    this->m_dictSprocStp->m_paramProcAttribVector.clear();

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenSProc::getInsUpdParam()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenSProc::getInsUpdParam(DBA_PROC_ACCESS_ENUM procAccessEn)
{
    RET_CODE          ret=RET_SUCCEED;
    bool              bKeep;
    DICT_ENTITY_STP   locDictEntityStp = this->getDictEntityStp();
    bool              bSetNullDV = false;

    this->m_dictSprocStp->m_paramProcAttribVector.clear();

    bool bExternalUsed = false;
    if (this->m_dictSprocStp->m_storedProcAccessVector.empty() == false)
    {
        for (auto it = this->m_dictSprocStp->m_storedProcAccessVector.begin(); it != this->m_dictSprocStp->m_storedProcAccessVector.end(); ++it)
        {
            if ((*it)->subObj == DBA_ROLE_EXTERNAL_USE)
            {
                bExternalUsed = true;
            }
        }
    }

    /* PMSTA-36149 - LJE - 190611 */
    if (procAccessEn == ProcAccess_ChangeSet)
    {
        DictSprocParamClass dictSprocParam("id", IdType);

        dictSprocParam.attrStp    = nullptr;
        dictSprocParam.attrDictId = 0;
        dictSprocParam.inputFlg   = TRUE;
        dictSprocParam.outputFlg  = FALSE;
        dictSprocParam.rank       = 0;

        this->m_dictSprocStp->m_paramProcAttribVector.push_back(dictSprocParam);
    }
    else
    {
        for (auto criterIt = locDictEntityStp->allDictCriteriaMap.begin(); criterIt != locDictEntityStp->allDictCriteriaMap.end(); ++criterIt)
        {
            DICT_CRITER_STP dictCriterStp = criterIt->second;
            DICT_ATTRIB_STP dictAttribStp = dictCriterStp->attrPtr;
            DICT_ENTITY_STP attrDictEntityStp = DBA_GetDictEntitySt(dictCriterStp->attrEntObj);

            if (dictAttribStp == NULL || attrDictEntityStp == NULL)
            {
                return RET_GEN_INFO_NODATA;
            }

            bKeep = true;

            if (this->isInsUpdParam(dictCriterStp, this->outputDynNatEn) == false)
            {
                bKeep = false;
            }

            if (bKeep)
            {
                if (procAccessEn != ProcAccess_None)
                {
                    switch (procAccessEn)
                    {
                        case ProcAccess_BusinessKey:
                            if (dictAttribStp->busKeyFlg == FALSE)
                            {
                                bKeep = false;
                            }
                            break;

                        case ProcAccess_PrimaryKey:
                            if (dictAttribStp->primFlg == FALSE)
                            {
                                bKeep = false;
                            }
                            break;

                        case ProcAccess_ParentKey:
                            if (locDictEntityStp->parIndex != dictAttribStp->progN)
                            {
                                bKeep = false;
                            }
                            break;

                        case ProcAccess_Full:
                        case ProcAccess_All:
                            break;

                        case ProcAccess_AllDb:
                            if (dictAttribStp->isPhysicalAttribute() == false)
                            {
                                bKeep = false;
                            }
                            break;

                        case ProcAccess_ChangeSet: /* PMSTA-26250 - DDV - 170515 */
                            break;

                        default:
                            bKeep = false;
                            break;
                    }
                }
                /* PMSTA-42340 - LJE - 201029 */
                else if (bExternalUsed &&
                         dictAttribStp->featureEn == XdEntityFeatureFeatureEn::MultiBusinessEntityManagement)
                {
                    bKeep = false;
                }
            }

            if (bKeep == false && this->extraParamList.size() > 0)
            {
                size_t pos;
                for (list<string>::iterator it = this->extraParamList.begin(); it != this->extraParamList.end(); it++)
                {
                    if (it->find(dictAttribStp->sqlName) == 0 &&
                        ((pos = it->find_first_of(" \t")) == string::npos ||
                         pos == strlen(dictAttribStp->sqlName)))
                    {
                        bKeep = true;
                        break;
                    }
                }
            }

            if (bKeep == false)
            {
                continue;
            }

            FLAG_T outputFlg = FALSE;

            /* PMSTA-16357 - LJE - 130513 */
            if ((this->m_dictSprocStp->procActionEn == Insert || this->m_dictSprocStp->procActionEn == InsUpd) &&
                (dictAttribStp->primFlg == TRUE &&
                (locDictEntityStp->pkRuleEn == PkRule_Identity ||
                 (locDictEntityStp->pkRuleEn == PkRule_ExternalPk && locDictEntityStp->pkEntityStp && locDictEntityStp->pkEntityStp->pkRuleEn == PkRule_Identity)) || /* PMSTA-30592 - DDV - 180315 - Add External Pk rule */
                 this->getOptimisticLockingRule(dictAttribStp) != OptimisticLocking_None))
            {
                outputFlg = TRUE;
            }
            else if (this->m_dictSprocStp->procActionEn == Update &&
                     this->getOptimisticLockingRule(dictAttribStp) != OptimisticLocking_None)
            {
                outputFlg = TRUE;
            }

            DictSprocParamClass dictSprocParam(dictAttribStp);

            dictSprocParam.inputFlg   = TRUE;
            dictSprocParam.outputFlg  = outputFlg;
            dictSprocParam.rank       = static_cast<SMALLINT_T>(this->m_dictSprocStp->m_paramProcAttribVector.size());

            /* PMSTA-14452 - LJE - 121105 */
            if (this->m_dictSprocStp->role != DBA_ROLE_UPD_UD_FIELDS)
            {
                dictSprocParam.pkAttrFlg = dictAttribStp->primFlg;
            }
            else if (DdlGen::getUdIdSqlName().compare(dictAttribStp->sqlName) == 0)
            {
                dictSprocParam.pkAttrFlg = TRUE;
            }

            /* PMSTA-26108 - LJE - 171007 */
            if (dictAttribStp->featureEn == XdEntityFeatureFeatureEn::MultiBusinessEntityManagement)
            {
                if (dictAttribStp->dfltVal.empty() == false)
                {
                    dictSprocParam.defaultValueC = dictAttribStp->dfltVal[0];
                }
                else
                {
                    dictSprocParam.defaultValueC = "NULL";
                }
                if (this->ddlGenContextPtr->m_rdbmsEn == PostgreSQL)
                {
                    bSetNullDV = true;
                }
            }
            else if (bSetNullDV)
            {
                dictSprocParam.defaultValueC = "NULL";
            }

            this->m_dictSprocStp->m_paramProcAttribVector.push_back(dictSprocParam);
        }
    }
    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenSProc::getInsByCdParam()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenSProc::getInsByCdParam()
{
    RET_CODE          ret=RET_SUCCEED;
    stringstream      checkStream;
    DICT_ATTRIB_STP   outDictAttribStp=NULL;
    DICT_ENTITY_STP   locDictEntityStp = this->getDictEntityStp();

    this->setIndent(1);

    this->m_dictSprocStp->m_paramProcAttribVector.clear();

    for (auto criterIt = locDictEntityStp->allDictCriteriaMap.begin(); criterIt != locDictEntityStp->allDictCriteriaMap.end(); ++criterIt)
    {
        DICT_CRITER_STP dictCriterStp     = criterIt->second;
        DICT_ATTRIB_STP dictAttribStp     = dictCriterStp->attrPtr;
        DICT_ENTITY_STP attrDictEntityStp = DBA_GetDictEntitySt(dictCriterStp->attrEntObj);
        DICT_ENTITY_STP refDictEntityStp;
        OBJECT_ENUM     refObjEn;
        string          locAlias;

        if (dictAttribStp == NULL || attrDictEntityStp == NULL)
        {
            return RET_GEN_INFO_NODATA;
        }

        /* PMSTA-14212 - LJE - 120621 - Don't use denormalized attributes */
        if (dictAttribStp->entDictId != dictCriterStp->entDictId ||
            (dictAttribStp->entDictId == dictCriterStp->entDictId  && strcmp(dictAttribStp->sqlName, dictCriterStp->sqlName) != 0)) /* PMSTA-19243 - DDV - 150505 - Dont' add param for denomalized attribute on same entity */
            continue;

        if (dictAttribStp->refEntDictId != 0)
        {
            DBA_GetObjectEnum(dictAttribStp->refEntDictId, &refObjEn);
            refDictEntityStp = DBA_GetDictEntitySt(refObjEn);
        }
        else
        {
            refObjEn         = NullEntity;
            refDictEntityStp = NULL;
        }

        if (dictAttribStp->setBySpecProcFlg == TRUE || dictAttribStp->calcEn == DictAttr_ExternalSeqNo) /* PMSTA-21938 - LJE - 160125 */
        {
            DdlGenVar varName(*this);
            varName.sqlName = dictAttribStp->sqlName;
            varName.setDataType(dictAttribStp->dataTpProgN);
            varName.strDefault = "NULL";
            this->varHelperPtr->addVariable(varName);
            continue;
        }

        /* Exceptions... */
        if (this->overloadStream.str().empty() == false)
        {
            string lineStr;
            bool   bIgnore = false;

            this->overloadStream.clear();
            this->overloadStream.seekg(0, ios::beg);
            while (getline(this->overloadStream, lineStr))
            {
                if (lineStr.find(dictAttribStp->sqlName) == 0)
                {
                    DdlGenVar *varName = this->varHelperPtr->getNewVariable(dictAttribStp->sqlName, dictAttribStp->dataTpProgN);

                    checkStream << endl << newLine()
                        << this->getVarAssignCmd() << varName->printSqlName() << this->getVarAssign() << "NULL";

                    bIgnore = true;
                }
            }

            if (bIgnore)
                continue;
        }

        if (dictAttribStp->primFlg == TRUE &&
            dictAttribStp->busKeyFlg == FALSE &&
            dictAttribStp->refEntDictId == 0)
        {
            DdlGenVar varName(*this);
            varName.sqlName = dictAttribStp->sqlName;
            varName.setDataType(dictAttribStp->dataTpProgN);
            varName.strDefault = "0";

            this->varHelperPtr->addVariable(varName);

            /* Exceptions... */
            if (this->overloadStream.str().empty() == false)
            {
                string lineStr;
                bool   bIgnore = false;

                this->overloadStream.clear();
                this->overloadStream.seekg(0, ios::beg);
                while (getline(this->overloadStream, lineStr))
                {
                    if (lineStr.find(dictAttribStp->sqlName) == 1 &&
                        lineStr.at(0) == '@' &&
                        lineStr.find_first_of(" \t") == strlen(dictAttribStp->sqlName) + 1)
                    {
                        outDictAttribStp = dictAttribStp;
                        bIgnore = true;
                    }
                }

                if (bIgnore)
                    continue;
            }

            continue;
        }

        if (isInsUpdParam(dictCriterStp, this->outputDynNatEn) == false)
        {
            continue;
        }

        int bkNbr = 0;

        if ((dictAttribStp->dataTpProgN == IdType ||
            dictAttribStp->dataTpProgN == DictType) &&
            refDictEntityStp != NULL &&
            /* PMSTA-13122 - LJE - 120518 */
            refDictEntityStp->primKeyNbr > 0 &&
            refDictEntityStp->bkAttrNbr > 0)
        {
            if (refObjEn == Tp ||
                refObjEn == ApplMsg)
            {
                bkNbr = 1;
            }
            else
            {
                for (auto attribIt = refDictEntityStp->attr.begin(); attribIt != refDictEntityStp->attr.end(); attribIt++)
                {
                    if ((*attribIt)->busKeyFlg == TRUE)
                    {
                        bkNbr++;
                    }
                }
            }
        }

        if (bkNbr == 1)
        {
            for (auto& refDictAttribStp : refDictEntityStp->attr)
            {
                if (refDictAttribStp->busKeyFlg == TRUE)
                {
                    DictSprocParamClass dictSprocParam(refDictAttribStp);

                    dictSprocParam.inputFlg   = TRUE;
                    dictSprocParam.outputFlg  = FALSE;
                    dictSprocParam.rank       = static_cast<SMALLINT_T>(this->m_dictSprocStp->m_paramProcAttribVector.size());

                    if (dictAttribStp->dataTpProgN == DictType)
                    {
                        dictSprocParam.m_sqlName.erase(dictSprocParam.m_sqlName.find("_dict_id"));
                        dictSprocParam.m_sqlName += "_";

                        if (dictSprocParam.m_sqlName.length() +
                            strlen(refDictAttribStp->sqlName) + 1 <= sizeof(SYSNAME_T))
                        {
                            dictSprocParam.m_sqlName += refDictAttribStp->sqlName;
                        }
                        else
                        {
                            dictSprocParam.m_sqlName += "name";
                        }
                    }
                    else
                    {
                        dictSprocParam.m_sqlName.erase(dictSprocParam.m_sqlName.find("_id"));
                        if (dictSprocParam.m_sqlName.length() +
                            strlen(refDictAttribStp->sqlName) + 2 <= sizeof(SYSNAME_T))
                        {
                            dictSprocParam.m_sqlName += "_";
                            dictSprocParam.m_sqlName += refDictAttribStp->sqlName;
                        }
                        else
                        {
                            dictSprocParam.m_sqlName += "_cd";
                        }
                    }

                    /* Special case for type */
                    if (refObjEn == Tp)
                    {
                        locAlias = "E.";
                    }

                    DdlGenVar varName(*this);
                    varName.sqlName = dictAttribStp->sqlName;
                    varName.setDataType(dictAttribStp->dataTpProgN);
                    varName.strDefault = "NULL";
                    this->varHelperPtr->addVariable(varName);

                    DdlSprocParam procVarName(*this->m_dictSprocStp, this->ddlGenContextPtr->m_rdbmsEn);
                    procVarName.sqlName = dictSprocParam.m_sqlName;
                    procVarName.setDataType(dictSprocParam.attrStp->dataTpProgN);
                    this->varHelperPtr->addParameter(procVarName);

                    checkStream << endl
                        << newLine()
                        << "#IF @" << procVarName.sqlName << " is not null" << newLine()
                        << "#{";

                    this->setIndent(1);
                    checkStream << newLine()
                        << "#SELECT " << refDictEntityStp->mdSqlName << " null E" << newLine()
                        << "@" << varName.sqlName << " = " << locAlias << refDictEntityStp->primKeyTab[0]->sqlName << newLine()
                        << "#FROM" << newLine();

                    /* Special case for type */
                    if (refObjEn == Tp)
                    {
                        checkStream << "inner join dict_attribute da on and t.attribute_dict_id = da.dict_id and da.entity_dict_id = "
                            << dictAttribStp->entDictId << "  and da.sqlname_c = '" << dictAttribStp->sqlName << "'" << newLine();
                    }

                    checkStream
                        << "#WHERE" << newLine()
                        << locAlias << refDictAttribStp->sqlName << " = @" << procVarName.sqlName << newLine()
                        << "#END" << newLine();


                    checkStream << newLine()
                        << "#IF @" << varName.sqlName << " is null" << newLine()
                        << "#{";

                    this->setIndent(1);
                    checkStream << newLine()
                        << "#APPL_RAISERROR 20014, #CURR_DDL_OBJECT, "
                        << "'" << refDictAttribStp->sqlName << "',"
                        << procVarName.sqlName << ","
                        << "'" << this->getEntityFullSqlName(refDictEntityStp) << "'" << newLine()
                        << "#RETURN -1";

                    this->setIndent(-1);
                    checkStream << newLine() << "#}";

                    this->setIndent(-1);
                    checkStream << newLine() << "#}";

                    this->m_dictSprocStp->m_paramProcAttribVector.push_back(dictSprocParam);
                    break;
                }
            }
        }
        else
        {
            DictSprocParamClass dictSprocParam(dictAttribStp);

            dictSprocParam.inputFlg   = TRUE;
            dictSprocParam.outputFlg  = FALSE;
            dictSprocParam.rank       = static_cast<SMALLINT_T>(this->m_dictSprocStp->m_paramProcAttribVector.size());

            this->m_dictSprocStp->m_paramProcAttribVector.push_back(dictSprocParam);
        }
    }

    if (outDictAttribStp != NULL)
    {
        DictSprocParamClass dictSprocParam(outDictAttribStp);

        dictSprocParam.inputFlg      = TRUE;
        dictSprocParam.outputFlg     = TRUE;
        dictSprocParam.rank          = static_cast<SMALLINT_T>(this->m_dictSprocStp->m_paramProcAttribVector.size());
        dictSprocParam.defaultValueC = "NULL";

        this->m_dictSprocStp->m_paramProcAttribVector.push_back(dictSprocParam);
    }

    this->bodySqlBlock << this->scriptDdlGen->buildScript(checkStream.str(), DdlObj_SProc) << newLine();
    ret = this->scriptDdlGen->lastErrRetCode;

    if (this->overloadStream.str().empty() == false)
    {
        this->overloadStream.clear();
        this->overloadStream.str(std::string());
    }

    this->setIndent(-1);
    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenSProc::getParam()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenSProc::getParam()
{
    RET_CODE          ret=RET_SUCCEED;
    int               maxParam;
    DICT_ENTITY_STP   locDictEntityStp = this->getDictEntityStp();

    maxParam = (int)locDictEntityStp->allDictCriteriaMap.size();

    if (this->m_dictSprocStp->synonymFlg == TRUE)
    {
        maxParam++;
    }

    this->m_dictSprocStp->m_paramProcAttribVector.clear();

    for (auto criterIt = locDictEntityStp->allDictCriteriaMap.begin(); criterIt != locDictEntityStp->allDictCriteriaMap.end(); ++criterIt)
    {
        DICT_CRITER_STP dictCriterStp     = criterIt->second;
        DICT_ATTRIB_STP dictAttribStp     = dictCriterStp->attrPtr;
        DICT_ENTITY_STP attrDictEntityStp = DBA_GetDictEntitySt(dictCriterStp->attrEntObj);

        if (dictAttribStp == NULL || attrDictEntityStp == NULL)
        {
            continue;
        }

        if (this->m_dictSprocStp->procAccessEn != ProcAccess_NatureKey &&
            /* PMSTA-43367 - LJE - 210427 - Allow parameter on denormalized parent attribute */
            (this->m_dictSprocStp->procAccessEn != ProcAccess_ParentKey ||
             locDictEntityStp->isNullParIndex == true ||
             dictCriterStp->entAttrPtr == nullptr ||
             locDictEntityStp->attr[locDictEntityStp->parIndex]->attrDictId != dictCriterStp->entAttrPtr->attrDictId))
        {
            /* Remove denormalized attributes */
            if (dictCriterStp->entDictId != attrDictEntityStp->entDictId ||
                (dictCriterStp->entDictId == attrDictEntityStp->entDictId  && strcmp(dictAttribStp->sqlName, dictCriterStp->sqlName) != 0)) /* PMSTA-19243 - DDV - 150505 - Don't add param for denomalized attribute on same entity */
            {
                continue;
            }

            /* PMSTA-16775 - LJE - 130903 - Remove non-physical attributes */
            if (dictCriterStp->dynNatEn == DynType_All &&
                dictCriterStp->entAttrPtr != dictAttribStp)
            {
                continue;
            }
        }

        DICT_ATTRIB_STP parentAttribStp = nullptr; /* PMSTA-43367 - LJE - 210427 */

        if ((this->m_dictSprocStp->procAccessEn == ProcAccess_PrimaryKey && dictAttribStp->isNullProgPkN == false && dictAttribStp->featureEn != XdEntityFeatureFeatureEn::MultiBusinessEntityManagement) ||

            (this->m_dictSprocStp->procAccessEn == ProcAccess_BusinessKey && dictAttribStp->busKeyFlg == TRUE) ||

            (this->m_dictSprocStp->procAccessEn == ProcAccess_ChangeSet && dictAttribStp->progN == Adm_Arg_Id) || /* PMSTA-26250 - DDV - 170515 */

            (this->m_dictSprocStp->procAccessEn == ProcAccess_ParentKey &&  /* PMSTA-13109 - LJE - 111223 */
            (parentAttribStp = (locDictEntityStp->isNullParIndex == false ? locDictEntityStp->attr[locDictEntityStp->parIndex] : nullptr)) != nullptr &&
             (parentAttribStp->attrDictId == dictAttribStp->attrDictId ||
             (dictCriterStp->entAttrPtr != nullptr && parentAttribStp->attrDictId == dictCriterStp->entAttrPtr->attrDictId) ||
              (parentAttribStp->refEntDictId == 0 &&
               parentAttribStp->linkedAttrDictStp != NULL &&
               parentAttribStp->linkedAttrDictStp->attrDictId == dictAttribStp->attrDictId) ||
              /* PMSTA-45027 - LJE - 210521 */
              ((locDictEntityStp->tpNatEn == Typing || locDictEntityStp->tpNatEn == SubTyping) &&   /* PMSTA-XXXXX - LJE - 211018 */
               locDictEntityStp->isNullNatIndex == false &&
               dictCriterStp->entAttrPtr != nullptr &&
               locDictEntityStp->natIndex == dictCriterStp->entAttrPtr->progN))) ||
            /* PMSTA-26108 - LJE - 170811 */
               (this->m_dictSprocStp->procAccessEn == ProcAccess_NatureKey &&
                dictCriterStp->entAttrPtr != nullptr &&
                locDictEntityStp->natIndex == dictCriterStp->entAttrPtr->progN))
        {
            DictSprocParamClass dictSprocParam((dictCriterStp->entAttrPtr != nullptr ? dictCriterStp->entAttrPtr : dictAttribStp));

            dictSprocParam.attrDictId = dictSprocParam.attrStp->attrDictId;
            dictSprocParam.inputFlg   = TRUE;
            dictSprocParam.outputFlg  = FALSE;
            dictSprocParam.codifFlg   = FALSE;
            dictSprocParam.rank       = static_cast<SMALLINT_T>(this->m_dictSprocStp->m_paramProcAttribVector.size());

            this->m_dictSprocStp->m_paramProcAttribVector.push_back(dictSprocParam);
        }
    }

    if (this->m_dictSprocStp->m_paramProcAttribVector.empty())
    {
        if (this->m_dictSprocStp->procAccessEn == ProcAccess_ParentKey)
        {
            ret = RET_GEN_INFO_NOACTION;
        }
    }
    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenSProc::getParamSpecial()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-16729 - LJE - 140206
**
*************************************************************************/
RET_CODE DdlGenSProc::getParamSpecial()
{
    RET_CODE          ret = RET_SUCCEED;

    this->m_dictSprocStp->m_paramProcAttribVector.clear();

    if (strcasecmp(this->getDdlObjSqlName().c_str(), "chk_dict_entity_object_id") == 0 ||
        strcasecmp(this->getDdlObjSqlName().c_str(), "chk_dict_entity_object_for_upd") == 0)
    {
        {
            DictSprocParamClass dictSprocParam("entity_dict_id", DictType);
            this->m_dictSprocStp->m_paramProcAttribVector.push_back(dictSprocParam);
        }
        {
            DictSprocParamClass dictSprocParam("object_id", IdType);
            dictSprocParam.pkAttrFlg = TRUE;
            this->m_dictSprocStp->m_paramProcAttribVector.push_back(dictSprocParam);
        }
    }
    else if (strcasecmp(this->getDdlObjSqlName().c_str(), "get_dict_entity_object_id") == 0)
    {
        {
            DictSprocParamClass dictSprocParam("object_id", IdType);
            dictSprocParam.outputFlg = TRUE;
            this->m_dictSprocStp->m_paramProcAttribVector.push_back(dictSprocParam);
        }

        {
            DictSprocParamClass dictSprocParam("entity_dict_id", DictType);
            dictSprocParam.outputFlg = FALSE;
            this->m_dictSprocStp->m_paramProcAttribVector.push_back(dictSprocParam);
        }
        {
            DictSprocParamClass dictSprocParam("object_code", CodeType);
            dictSprocParam.outputFlg = FALSE;
            this->m_dictSprocStp->m_paramProcAttribVector.push_back(dictSprocParam);
        }
        {
            DictSprocParamClass dictSprocParam("list_entity_dict_id", DictType);
            dictSprocParam.defaultValueC = "NULL";
            dictSprocParam.outputFlg = FALSE;
            this->m_dictSprocStp->m_paramProcAttribVector.push_back(dictSprocParam);
        }
    }
    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenSProc::getParam4Cpy()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 111202
**
*************************************************************************/
RET_CODE DdlGenSProc::getParam4Cpy()
{
    RET_CODE          ret=RET_SUCCEED;
    DICT_ENTITY_STP   locDictEntityStp = this->getDictEntityStp();


    this->m_dictSprocStp->m_paramProcAttribVector.clear();

    for (auto criterIt = locDictEntityStp->allDictCriteriaMap.begin(); criterIt != locDictEntityStp->allDictCriteriaMap.end(); ++criterIt)
    {
        DICT_CRITER_STP dictCriterStp     = criterIt->second;
        DICT_ATTRIB_STP dictAttribStp     = dictCriterStp->attrPtr;
        DICT_ENTITY_STP attrDictEntityStp = DBA_GetDictEntitySt(dictCriterStp->attrEntObj);

        if (dictAttribStp == NULL || attrDictEntityStp == NULL)
        {
            return RET_GEN_INFO_NODATA;
        }

        /* Remove denormalized attributes */
        if (dictCriterStp->entDictId != attrDictEntityStp->entDictId ||
            (dictCriterStp->entDictId == attrDictEntityStp->entDictId  && strcmp(dictAttribStp->sqlName, dictCriterStp->sqlName) != 0)) /* PMSTA-19243 - DDV - 150505 - Dont' add param for denomalized attribute on same entity */
            continue;

        /* PMSTA-16775 - LJE - 130903 - Remove non-physical attributes */
        if (dictCriterStp->dynNatEn == DynType_All && dictCriterStp->entAttrPtr != dictAttribStp)
            continue;

        if (dictAttribStp->primFlg == TRUE || dictAttribStp->busKeyFlg == TRUE)
        {
            DictSprocParamClass dictSprocParam(dictAttribStp);

            dictSprocParam.inputFlg   = TRUE;
            dictSprocParam.outputFlg  = FALSE;
            dictSprocParam.codifFlg   = FALSE;
            dictSprocParam.rank       = static_cast<SMALLINT_T>(this->m_dictSprocStp->m_paramProcAttribVector.size());
            dictSprocParam.m_sqlName    = "from_";
            dictSprocParam.m_sqlName += dictAttribStp->sqlName;
            this->m_dictSprocStp->m_paramProcAttribVector.push_back(dictSprocParam);

            dictSprocParam.rank       = static_cast<SMALLINT_T>(this->m_dictSprocStp->m_paramProcAttribVector.size());
            dictSprocParam.m_sqlName    = "to_";
            dictSprocParam.m_sqlName += dictAttribStp->sqlName;
            this->m_dictSprocStp->m_paramProcAttribVector.push_back(dictSprocParam);
    }
    }
    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenSProc::printCallInsertRequest()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenSProc::printCallInsertRequest()
{
    RET_CODE          ret=RET_SUCCEED;
    stringstream      locWhereStream, locBodyStream;
    DdlGenContext     localDdlGenContext(this->ddlGenContextPtr->m_rdbmsEn);

    DictSprocClass   &procSt = localDdlGenContext.getDictSprocSt();

    procSt.setObjectEn(this->getObjectEn());
    procSt.dbName = this->ddlGenContextPtr->getDefDdlDestDbName();
    procSt.inputObjectEn = InvalidEntity;
    procSt.outputObjectEn = NullEntity;
    procSt.outputDynTypeEn = DynType_Null;
    procSt.procAccessEn = ProcAccess_PrimaryKey;
    procSt.procActionEn = Insert;

    if (procSt.getDictEntityStp()->bkAttrNbr > 0)
    {
        FLAG_T            firstFlg = TRUE;

        locBodyStream << newLine() << "#IF_NOT_EXISTS (select ";
        locWhereStream << "              where ";

        for (auto criterIt = procSt.getDictEntityStp()->allDictCriteriaMap.begin(); criterIt != procSt.getDictEntityStp()->allDictCriteriaMap.end(); ++criterIt)
        {
            DICT_CRITER_STP dictCriterStp = criterIt->second;

            DICT_ATTRIB_STP dictAttribStp     = dictCriterStp->attrPtr;
            DICT_ENTITY_STP attrDictEntityStp = DBA_GetDictEntitySt(dictCriterStp->attrEntObj);

            if (dictAttribStp == NULL || attrDictEntityStp == NULL ||
                dictCriterStp->entDictId != dictAttribStp->entDictId || /* PMSTA-13711 - LJE - 120217 */
                (dictCriterStp->entDictId == dictAttribStp->entDictId && strcmp(dictAttribStp->sqlName, dictCriterStp->sqlName) != 0)) /* PMSTA-19243 - DDV - 150505 - Don't add param for denomalized attribute on same entity */
            {
                continue;
            }

            if (dictAttribStp->busKeyFlg == TRUE)
            {
                DdlGenVar* paramName = this->varHelperPtr->getVariable(dictAttribStp->sqlName);

                if (paramName != nullptr)
                {
                    if (firstFlg == FALSE)
                    {
                        locWhereStream << newLine() << "                 and ";
                    }
                    else
                    {
                        locBodyStream << dictAttribStp->sqlName;
                    }

                    locWhereStream << dictAttribStp->sqlName << " = " << paramName->printSqlName();
                    firstFlg = FALSE;
                }
            }
        }
        locBodyStream << newLine() << "               from " << this->getEntityFullSqlName()
            << newLine() << locWhereStream.str()
            << ")" << newLine() << "#{";
    }

    this->setIndent(1);
    {
        DdlGenSProc locDdlGenSProc(procSt.getObjectEn(), localDdlGenContext, this->varHelperPtr, this->ddlGenEntityPtr, this->fileHelper, this->targetTableEn);
        locBodyStream << newLine() << "#CALL " << locDdlGenSProc.getSprocSqlName() << " " << this->getDictEntityStp()->mdSqlName << " all @return_status";
    }

    for (auto& attribStp : this->getDictEntityStp()->attr)
    {
        /* Print the "id" with output */
        if (this->getDictEntityStp()->pkRuleEn == PkRule_Identity && attribStp->primFlg == TRUE)
        {
            locBodyStream << newLine() << attribStp->sqlName << " output";
        }
    }
    locBodyStream << newLine() << "#END";

    if (this->getDictEntityStp()->bkAttrNbr > 0)
    {
        if (procSt.procActionEn == InsUpd)
        {
            procSt.procActionEn = Update;
            DdlGenSProc locDdlGenSProc(procSt.getObjectEn(), localDdlGenContext, this->varHelperPtr, this->ddlGenEntityPtr, this->fileHelper, this->targetTableEn);

            locBodyStream
                << newLine() << "#}"
                << newLine() << "#ELSE"
                << newLine() << "#{";

            this->setIndent(1);
            locBodyStream
                << newLine() << "#CALL " << locDdlGenSProc.getSprocSqlName() << " " << this->getDictEntityStp()->mdSqlName << " all @return_status";
            this->setIndent(-1);
            locBodyStream
                << newLine() << "#}";
        }

        this->setIndent(-1);
        locBodyStream << newLine() << "#}" << newLine();
    }

    locBodyStream << newLine() << this->getReturnInProc(this->getVarPrefix() + "return_status") << endl;

    this->bodySqlBlock << this->scriptDdlGen->buildScript(locBodyStream.str(), DdlObj_SProc);
    ret = this->scriptDdlGen->lastErrRetCode;

    return ret;
}


/************************************************************************
**
**  Function    :   DdlGenSProc::printTruncateFromDeleteRule()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14655 - LJE - 121001
**
*************************************************************************/
RET_CODE DdlGenSProc::printTruncateFromDeleteRule(DICT_ENTITY_STP truncDictEntityStp,
                                                  DICT_ENTITY_STP refDictEntityStp,
                                                  DICT_ATTRIB_STP attribStp)
{
    RET_CODE             ret=RET_SUCCEED;
    REF_DELETE_RULE_ENUM refDelRuleEn=RefDelRule_None;

    /* Parent attribute defined in the entity */
    if (refDictEntityStp->isNullParIndex == false &&
        refDictEntityStp->parIndex == attribStp->progN &&
        attribStp->refEntDictId == truncDictEntityStp->entDictId)
    {
        refDelRuleEn = RefDelRule_CascadeDelete;
    }
    /* Parent attribute defined in the logical attribute */
    else if (truncDictEntityStp->logicalTab.empty() == false)
    {
        for (auto attribIt = truncDictEntityStp->logicalTab.begin(); attribIt != truncDictEntityStp->logicalTab.end(); attribIt++)
        {
            DICT_ATTRIB_STP locAttribStp = *attribIt;

            if (locAttribStp->refEntDictId == refDictEntityStp->entDictId &&
                (locAttribStp->linkedAttrDictId == 0 ||
                 locAttribStp->linkedAttrDictId == locAttribStp->attrDictId))
            {
                refDelRuleEn = locAttribStp->refDeleteRuleEn;

                if (refDelRuleEn == RefDelRule_None)
                {
                    refDelRuleEn = RefDelRule_CascadeDelete;
                }
                break;
            }
        }
    }

    /* Search the delete rule in the xd_attriubte */
    if (attribStp->refEntDictId == truncDictEntityStp->entDictId &&
        refDelRuleEn == RefDelRule_None)
    {
        refDelRuleEn = attribStp->refDeleteRuleEn;
    }

    /* No rule, nothing to do */
    if (refDelRuleEn == RefDelRule_None)
    {
        return RET_GEN_INFO_NOACTION;
    }

    switch(refDelRuleEn)
    {
    case RefDelRule_SetNULL:
        this->bodySqlBlock
            << this->newLine() << "#UPDATE " << this->getEntityFullSqlName(refDictEntityStp)
            << this->newLine() << attribStp->sqlName << " = null"
            << this->newLine() << "#WHERE "
            << this->newLine() << attribStp->sqlName << " is not null"
            << this->newLine() << "#END" << endl;
        break;

    case RefDelRule_Restrict:
    case RefDelRule_NoAction:
        this->bodySqlBlock
            << this->newLine() << "#IF_EXISTS (select 'x'"
            << this->newLine() << "	   from " << this->getEntityFullSqlName(refDictEntityStp) << ")"
            << this->newLine() << "#{"
            << this->newLine() << this->execApplRaisError(20010, this->getEntityMdName(), truncDictEntityStp->mdSqlName, refDictEntityStp->mdSqlName, attribStp->sqlName)
            << this->newLine() << "	#ROLLBACK"
            << this->newLine() << "	#RETURN"
            << this->newLine() << "#}" << endl;
        break;

    case RefDelRule_CascadeDelete:

        if (attribStp->linkedAttrDictStp == NULL)
        {
            this->printCascadeTruncateRef(refDictEntityStp->objectEn);

            this->bodySqlBlock
                << this->newLine() << this->getCmdTruncateTable(refDictEntityStp, true);
        }
        else
        {
            this->bodySqlBlock
                << this->newLine() << "#DELETE " << refDictEntityStp->mdSqlName
                << this->newLine() << "#WHERE"
                << this->newLine() << attribStp->linkedAttrDictStp->sqlName << "=" << truncDictEntityStp->entDictId
                << this->newLine() << "#END";
        }
        break;
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenSProc::printCascadeTruncateRef()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14655 - LJE - 121001
**
*************************************************************************/
RET_CODE DdlGenSProc::printCascadeTruncateRef(OBJECT_ENUM  truncObjEn)
{
    RET_CODE          ret=RET_SUCCEED;

    DICT_ENTITY_STP truncDictEntityStp = DBA_GetDictEntitySt(truncObjEn);

    if (truncDictEntityStp == NULL ||
        truncDictEntityStp->primKeyNbr != 1 ||
        truncDictEntityStp->primKeyTab == NULL)
    {
        return  ret;
    }

    std::map<DICT_T, std::pair< DICT_ENTITY_STP, DICT_ATTRIB_STP>> cascadeRequestMap;

    for (auto &refDictEntityStp : DICT_GetDictEntityVector())
    {
        if (refDictEntityStp != NULL &&
            refDictEntityStp->logicalFlg == FALSE &&
            refDictEntityStp->objectEn != ScriptDef &&
            refDictEntityStp->objectEn != truncObjEn)
        {
            for (auto& attribStp : refDictEntityStp->attr)
            {
                if (attribStp->logicalFlg == TRUE)
                    continue;

                if (attribStp->refEntDictId == truncDictEntityStp->entDictId ||
                    (attribStp->refEntDictId == 0 &&
                     attribStp->linkedAttrDictStp != NULL))
                {
                    cascadeRequestMap[attribStp->attrDictId] = std::make_pair(refDictEntityStp, attribStp);
                }
            }
        }
    }

    for (auto &it : cascadeRequestMap)
    {
        this->printTruncateFromDeleteRule(truncDictEntityStp, it.second.first, it.second.second);
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenSProc::printTruncateRequest()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14655 - LJE - 121001
**  Last modif. :
**
*************************************************************************/
RET_CODE DdlGenSProc::printTruncateRequest()
{
    RET_CODE          ret=RET_SUCCEED;

    if (this->getEntityMdName().find("cdmq_") == 0)
    {
        this->printCascadeTruncateRef(this->getObjectEn());
        this->bodySqlBlock << newLine() << this->getCmdTruncateTable(this->getDictEntityStp(), true);
    }
    else
    {
        this->selListStream << newLine() << this->execApplRaisError(20277, this->getDdlObjSqlName(), this->getEntityFullSqlName(), string(), string());
    }
    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenSProc::printCheckRequest()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenSProc::printCheckRequest(DdlGenSqlBlock &outSqlBlock)
{
    RET_CODE          ret=RET_SUCCEED;
    stringstream      locStream;

    if (this->m_dictSprocStp->m_paramProcAttribVector.empty())
        return RET_GEN_ERR_INVARG;

    locStream << newLine() << "/*"
            << newLine() << "This " + this->ddlObjName + " verifies the existence of a record on the format table"
            << newLine() << "using the primary key (id)."
            << newLine() << "The " + this->ddlObjName + " returns '0' if the record exists and '-1' with"
            << newLine() << "an error message, if it does not."
            << newLine() << "*/" << endl;

    locStream
        << this->newLine() << "/* verify that the id exists on this table */" << endl
        << this->newLine() << "#NO_SECURED";

    if (this->m_dictSprocStp->m_paramProcAttribVector.size() == 1)
    {
        locStream
            << this->newLine() << "#IF @" << this->m_dictSprocStp->m_paramProcAttribVector[0].m_sqlName << " is not null"
            << this->newLine() << "#AND_NOT_EXISTS (";
    }
    else
    {
        locStream
            << this->newLine() << "#IF_NOT_EXISTS (";
    }

    this->setIndent(1);

    locStream
        << this->newLine() << "#SELECT " << this->getDictEntityStp()->mdSqlName << " null"
        << this->newLine() << "1"
        << this->newLine() << "#FROM"
        << this->newLine() << "#WHERE"
        << this->newLine() << this->m_dictSprocStp->getProcAccessStr()
        << this->newLine() << "#END"
        << this->newLine() << ")";

    this->setIndent(-1);
    locStream
        << this->newLine() << "#{";
    this->setIndent(1);

    if (this->m_dictSprocStp->m_paramProcAttribVector.size() == 1)
    {
        string noteStr = "note";

        locStream
            << this->newLine() << "#DECLARE @" << noteStr << " note_t"
            << this->newLine() << "#ASSIGN @" << noteStr << " = #CONVERT(note_t, @" << this->m_dictSprocStp->m_paramProcAttribVector[0].attrStp[0].sqlName << ")"
            << this->newLine() << "#APPL_RAISERROR 20014, #CURR_DDL_OBJECT, @" << this->m_dictSprocStp->m_paramProcAttribVector[0].attrStp[0].sqlName << ", @" << noteStr << ", '" << this->getDictEntityStp()->mdSqlName << "'"
            << this->newLine() << "#RETURN(-1)";
    }
    else
    {
        locStream
            << this->newLine() << "#APPL_RAISERROR 20015, #CURR_DDL_OBJECT, " << this->getEntityFullSqlName()
            << this->newLine() << "#RETURN(-1)";
    }

        this->setIndent(-1);
    locStream
        << this->newLine() << "#}" << endl;

    locStream
        << this->newLine() << "#RETURN(0)"
        << this->newLine() << "#SECURED";

    outSqlBlock << this->scriptDdlGen->buildScript(locStream.str(), DdlObj_SProc);
    ret = this->scriptDdlGen->lastErrRetCode;

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenSProc::setName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenSProc::setName()
{
    RET_CODE          ret=RET_SUCCEED;

    if (this->m_dictSprocStp->getObjectEn() == NullEntity)
        return ret;

    if (this->m_dictSprocStp->sqlName[0] != 0)
    {
        this->setDdlObjSqlName(this->m_dictSprocStp->sqlName);
        return ret;
    }

    string ddlObjSqlName;

    switch (this->m_dictSprocStp->procActionEn)
    {
        case Get:
            ddlObjSqlName = "get_";
            break;
        case Select:
            ddlObjSqlName = "sel_";
            break;
        case Insert:
            ddlObjSqlName = "ins_";
            break;
        case InsUpd:
            ddlObjSqlName = "insupd_";
            break;
        case Update:
            ddlObjSqlName = "upd_";
            break;
        case Delete:
            ddlObjSqlName = "del_";
            break;
        case Check:
            ddlObjSqlName = "chk_";
            break;
        case Copy:
            ddlObjSqlName = "cpy_";
            break;
        case Truncate:
            ddlObjSqlName = "trunc_";
            break;
        case MultiSelect: /* PMSTA-26250 - DDV - 170515 */
            if (this->m_dictSprocStp->role == DBA_ROLE_SEL_SHADOW)
                ddlObjSqlName = "sel_shad_";
            break;
    }

    switch (this->m_dictSprocStp->outputDynTypeEn)
    {
        case DynType_All:
        case DynType_AllDb:
            ddlObjSqlName.append("all_");
            break;
        case DynType_Short:
            ddlObjSqlName.append("sh_");
            break;
    }

    if (this->m_dictSprocStp->role == DBA_ROLE_UPD_UD_FIELDS)
    {
        if (ddlObjSqlName.length() + strlen(this->getDictEntityStp()->custSqlName) > GET_MAXCHARLEN(SysnameType))   /* PMSTA-33077 - DLA - 181011 */
        {
            ddlObjSqlName += "ud_";
            ddlObjSqlName += this->getDictEntityStp()->shortSqlname;
        }
        else
        {
            ddlObjSqlName.append(this->getDictEntityStp()->custSqlName);
        }
    }
    else if (this->getDictEntityStp()->shortSqlname[0] != 0)
    {
        ddlObjSqlName.append(this->getDictEntityStp()->shortSqlname); /* PMSTA-13109 - LJE - 111128 */
    }
    else
    {
        ddlObjSqlName.append(this->getDictEntityStp()->mdSqlName);
    }

    switch (this->m_dictSprocStp->procAccessEn)
    {
        case ProcAccess_PrimaryKey:
            if (this->m_dictSprocStp->procActionEn == Check)
            {
                ddlObjSqlName.append("_pk");
            }
            else if (this->m_dictSprocStp->procActionEn == Insert)
            {
                ddlObjSqlName.append("_by_id");
            }
            else if (this->m_dictSprocStp->procActionEn != Update &&
                     this->m_dictSprocStp->procActionEn != Delete)
            {
                if (this->m_dictSprocStp->synonymFlg == TRUE)
                {
                    ddlObjSqlName.append("_by_cid");
                }
                else
                {
                    ddlObjSqlName.append("_by_pk");
                }
            }
            break;

        case ProcAccess_BusinessKey:

            /* PMSTA-14452 - LJE - 121113 - If insert with code -> ins_..._by_cd */
            if (this->m_dictSprocStp->procActionEn != Insert)
            {
                ddlObjSqlName.append("_by_bk");

                if (this->m_dictSprocStp->synonymFlg == TRUE)
                {
                    ddlObjSqlName.append("_cid");
                }
            }
            else
            {
                ddlObjSqlName.append("_by_cd");
            }
            break;

            /* PMSTA-13109 - LJE - 111223 */
        case ProcAccess_ParentKey:
            ddlObjSqlName.append("_by_pid");
            break;

        case ProcAccess_Full:
            if (this->m_dictSprocStp->synonymFlg == TRUE)
            {
                ddlObjSqlName.append("_by_cid");
            }
            break;

            /* PMSTA-26108 - LJE - 170811 */
        case ProcAccess_NatureKey:
            ddlObjSqlName.append("_by_nat");
            break;

    }

    this->m_dictSprocStp->sqlName = ddlObjSqlName;
    this->ddlGenContextPtr->setMsgSqlName(ddlObjSqlName);

    this->setDdlObjSqlName(ddlObjSqlName);
    this->setDdlObjFullSqlName(this->getDictEntityStp()->databaseName, this->getDdlObjSqlName());

    this->ddlGenContextPtr->ddlObjSqlName = ddlObjSqlName;

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenSProc::create()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenSProc::create()
{
    RET_CODE    ret=RET_SUCCEED;

    this->cmdType = DDlCmdType_Create;

    this->setIndent(1);

    this->m_dictSprocStp->bStdProc = true;

    switch (this->m_dictSprocStp->procActionEn)
    {
    case Get:
        ret = this->createGet();
        break;
    case Select:
        this->bManageAuthFlg = true; /* PMSTA-14607 - LJE - 120713 */
        ret = this->createSel(this->m_dictSprocStp->outputDynTypeEn == DynType_Short); /* PMSTA-30346 - LJE - 180301 */
        break;
    case Insert:
    case InsUpd:
        if (this->m_dictSprocStp->procAccessEn == ProcAccess_PrimaryKey)
            ret = this->createIns();
        else
            ret = this->createInsByCd();
        break;
    case Update:
        ret = this->createUpd();
        break;
    case Check:
        ret = this->createChk();
        break;
    case Delete:
        ret = this->createDel();
        break;
    /* PMSTA-14655 - LJE - 121001 */
    case Truncate:
        ret = this->createTruncate();
        break;
    case Copy:
        ret = this->createCopy();
        break;
    case Special:
        ret = this->createSpecial();
        break;
    }

    this->bManageAuthFlg = false; /* PMSTA-14607 - LJE - 120713 */

    this->varHelperPtr->cleanAllVar();

    this->setIndent(-1);

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenSProc::grant()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenSProc::grant()
{
    RET_CODE            ret = RET_SUCCEED, gblRet = RET_SUCCEED;
    stringstream        grantStream;
    string              currGrant;

    if (this->m_dictSprocStp->executeAsEn == ExecuteAs_Private ||
        this->ddlGenContextPtr->ddlGenAction.isBootStrapLevel()) /* PMSTA-24564 - LJE - 161209 */
    {
        return gblRet;
    }

    this->printGrant(grantStream,
                     this->m_dictSprocStp->dbName,
                     this->getEntitySqlName(),
                     this->getDdlObjSqlName(),
                     this->getDdlObjEn(),
                     this->m_dictSprocStp->executeAsEn);

    while (getline(grantStream, currGrant))
    {
        this->cmdType = DDlCmdType_Grant;

        this->bodySqlBlock << currGrant << endl;
        ret = this->flush();

        if (ret != RET_SUCCEED)
        {
            gblRet = ret;
        }
    }

    return gblRet;
}

/************************************************************************
**
**  Function    :   DdlGenSProc::getDictSprocSt()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-32145 - LJE - 180720
**
*************************************************************************/
DictSprocClass   &DdlGenSProc::getDictSprocSt()
{
    return *this->m_dictSprocStp;
}

/************************************************************************
**
**  Function    :   DdlGenSProc::getSprocSqlName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13122 - LJE - 120418
**
*************************************************************************/
const string &DdlGenSProc::getSprocSqlName()
{
    if (this->check() != RET_SUCCEED)
    {
        return this->emtpyStr;
    }
    return (this->getDdlObjSqlName());
}

/************************************************************************
**
**  Function    :   DdlGenSProc::setSprocParam()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13122 - LJE - 120418
**
*************************************************************************/
RET_CODE DdlGenSProc::setSprocParam()
{
    RET_CODE ret=RET_SUCCEED;

    if (this->m_dictSprocStp->procAccessEn == ProcAccess_PrimaryKey &&
        this->m_dictSprocStp->procActionEn != Insert &&
        this->getDictEntityStp()->primKeyNbr == 0)
    {
        ret = RET_GEN_ERR_INVARG;
        this->printMsg(ret, "Unable to create procedure with primary key access without primary key (" + this->getDdlObjSqlName() + ")");
        return ret;
    }

    /* PMSTA-14452 - LJE - 121105 */
    if (this->m_dictSprocStp->role == DBA_ROLE_UPD_UD_FIELDS)
    {
        this->outputDynNatEn = DynType_UdOnly;
    }

    auto extraParamVec = this->m_dictSprocStp->m_paramProcAttribVector;
    this->m_dictSprocStp->m_paramProcAttribVector.clear();

    if (this->m_dictSprocStp->bStdProc)
    {
        switch (this->m_dictSprocStp->procActionEn)
        {
            case Insert:
            case InsUpd:
                if (this->m_dictSprocStp->procAccessEn == ProcAccess_PrimaryKey)
                    ret = this->getInsUpdParam();
                else
                    ret = this->getInsByCdParam();
                break;

            case Update:
                ret = this->getInsUpdParam();
                break;

            case Copy:
                ret = this->getParam4Cpy();
                break;
            case Special:
                ret = this->getParamSpecial();
                break;
            case Get:
            case Select:
            case Delete:
            case Check:
                ret = this->getParam();
                break;
            case Truncate:
                break;
            case MultiSelect:
                ret = this->getInsUpdParam(this->m_dictSprocStp->procAccessEn);
                break;

            default:
                this->printMsg(ret, "Unsupported procedure action (" + this->getDdlObjSqlName() + ")");
        }
    }
    else
    {
        ret = this->getInsUpdParam(this->m_dictSprocStp->procAccessEn);
    }

    for (auto it = extraParamVec.begin(); it != extraParamVec.end(); ++it)
    {
        it->rank = static_cast<SMALLINT_T>(this->m_dictSprocStp->m_paramProcAttribVector.size());
        this->m_dictSprocStp->m_paramProcAttribVector.push_back(*it);
    }

    this->varHelperPtr->setParamList(*this->m_dictSprocStp);

    if (this->m_dictSprocStp->procActionEn == Insert ||
        this->m_dictSprocStp->procActionEn == InsUpd)
    {
        this->varHelperPtr->addVariable("return_status", IntType);
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenSProc::checkSProcParameters()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:  PMSTA-18593 - LJE - 151025
**
**  Last modif. :
**
*************************************************************************/
RET_CODE DdlGenSProc::checkSProcParameters(DBA_PROC_STP procStp)
{
    RET_CODE ret = RET_SUCCEED;
    DBA_PROCPARAM_STP procParamDefPtr = NULL;

    if (procStp != NULL)
    {
        procParamDefPtr = procStp->procParamDefPtr;
    }

    if (procStp         != nullptr &&
        procStp->subObj != DBA_ROLE_EXTERNAL_USE &&
        procStp->subObj != DBA_ROLE_NESTED_MULTISELECT)
    {
        if (procParamDefPtr != nullptr)
        {
            int idx = 0;
            bool bEndOfProc = false;
            bool bOutputCase = false;

            for (DdlGenParamIter it = this->varHelperPtr->getParamList()->begin(); it != this->varHelperPtr->getParamList()->end(); ++it)
            {
                if ((*it)->varType == VarType_OverParameter &&
                    (*it)->isAlwaysInParam() == false)
                {
                    continue;
                }

                if (bEndOfProc || procParamDefPtr[idx].fldNbrPtr == UNUSED)
                {
                    bEndOfProc = true;
                    ret = RET_GEN_ERR_INVARG;
                    this->printMsg(ret, "Unknown parameters (dbaprocdef.c) defined the stored procedure! (" + this->getDdlObjSqlName() + "." + (*it)->sqlName +
                                   ") (data-type: " + DBA_GetDataTypeSQLNameC((*it)->getDataType()) + ", default value: " + ((*it)->strDefault.empty() ? "null" : (*it)->strDefault) + ")");
                }
                else
                {
                    bool bSqlNameOk = false;

                    /* May be sqlname is truncate due to rdbms limitation, check sqlname based on output of DdlGenVar::printSqlprint */
                    if (procParamDefPtr[idx].paramName[0] != 0)
                    {
                        DdlGenVar procParam(*(DdlGenVar *)(*it));

                        procParam.sqlName = &(procParamDefPtr[idx].paramName[1]);

                        bSqlNameOk = (*it)->printSqlName(DdlGenVar::KindOfPrint::Name).compare(procParam.printSqlName(DdlGenVar::KindOfPrint::Name)) == 0;
                    }

                    if (procParamDefPtr[idx].paramName[0] != 0 && bSqlNameOk == false)
                    {
                        if (procParamDefPtr[idx].procParamTypeEn != ProcParamType_Output &&
                            procParamDefPtr[idx].procParamTypeEn != ProcParamType_Output_Indexed &&
                            procParamDefPtr[idx].procParamTypeEn != ProcParamType_Exclude)            /* PMSTA-29956 - LJE - 180126 */
                        {
                            ret = RET_GEN_ERR_INVARG;
                            this->printMsg(ret,
                                           "The list of parameters defined in the file dbaprocdef.c (" + string(&(procParamDefPtr[idx].paramName[1])) +
                                           ") doesn't match with the stored procedure (" + (*it)->sqlName + ")!");
                        }
                    }
                    else if (procParamDefPtr[idx].fldNbrPtr != NULL &&
                             this->getDataTypeSqlName(GET_FLD_TYPE(*(procStp->inputDynStPtr), *(procParamDefPtr[idx].fldNbrPtr))).compare(this->getDataTypeSqlName((*it)->getDataType())) != 0 &&
                             IS_TECHFLD(*(procStp->inputDynStPtr), *(procParamDefPtr[idx].fldNbrPtr)) == FALSE)     /* PMSTA-37366 - LJE - 191210 - Null value parameter */
                    {
                        ret = RET_GEN_ERR_INVARG;
                        this->printMsg(ret,
                                       "The data-type of parameter (" + string(&(procParamDefPtr[idx].paramName[1])) +
                                       ") defined in the file dbaprocdef.c (" + DBA_GetDataTypeSQLNameC(GET_FLD_TYPE(*(procStp->inputDynStPtr), *(procParamDefPtr[idx].fldNbrPtr))) +
                                       ") doesn't match with the stored procedure (" + DBA_GetDataTypeSQLNameC((*it)->getDataType()) + ")!");

                    }
                    else if (bSqlNameOk)
                    {
                        if (((procParamDefPtr[idx].procParamTypeEn == ProcParamType_Output || procParamDefPtr[idx].procParamTypeEn == ProcParamType_Output_Indexed) && (*it)->isOut() == false) ||
                            (procParamDefPtr[idx].procParamTypeEn != ProcParamType_Output && procParamDefPtr[idx].procParamTypeEn != ProcParamType_Output_Indexed && (*it)->isOut()))
                        {
                            ret = RET_GEN_ERR_INVARG;
                            this->printMsg(ret,
                                           "The output type of parameter (" + string(&(procParamDefPtr[idx].paramName[1])) +
                                           ") defined in the file dbaprocdef.c doesn't match with the stored procedure!");
                        }
                    }
                }

                if (bOutputCase && (*it)->isOut())
                {
                    bool      bFound = false;
                    DdlGenVar procParam(*(DdlGenVar *)(*it));

                    for (int i = 0; procParamDefPtr[i].fldNbrPtr != UNUSED; i++)
                    {
                        /* may be sqlname is truncate due to rdbms limitation, check sqlname based on output of DdlGenVar::printSqlprint */
                        if (procParamDefPtr[i].paramName[0] != 0)
                        {
                            procParam.sqlName = &(procParamDefPtr[i].paramName[1]);

                            if ((*it)->printSqlName().compare(procParam.printSqlName()) == 0)
                            {
                                if (procParamDefPtr[i].procParamTypeEn == ProcParamType_Output || procParamDefPtr[i].procParamTypeEn == ProcParamType_Output_Indexed)
                                {
                                    bFound = true;
                                }
                                break;
                            }
                        }
                    }

                    if (bFound == false)
                    {
                        ret = RET_GEN_ERR_INVARG;
                        this->printMsg(ret,
                                       "The output type of parameter (" + (*it)->sqlName +
                                       ") defined in the file dbaprocdef.c doesn't match with the stored procedure!");
                    }
                }

                ++idx;
            }

            if (bOutputCase == false && bEndOfProc == false)
            {
                while (procParamDefPtr[idx].fldNbrPtr != UNUSED)
                {
                    ret = RET_GEN_ERR_INVARG;
                    this->printMsg(ret, "Unknown parameters (stored procedure) defined the file dbaprocdef.c (" + this->getDdlObjSqlName() + "." + &(procParamDefPtr[idx].paramName[1]) + ")!");
                    idx++;
                }
            }
        }
        else
        {
            /* If store proc has no parameter definition and proc is created with parameter(s), print error(s) */
            for (DdlGenParamIter it = this->varHelperPtr->getParamList()->begin(); it != this->varHelperPtr->getParamList()->end(); ++it)
            {
                if ((*it)->isOut())
                {
                    ret = RET_GEN_ERR_INVARG;
                    this->printMsg(ret, "Unknown output parameter (dbaprocdef.c) defined the stored procedure! (" + this->getDdlObjSqlName() + "." + (*it)->sqlName + ")");
                }
                else
                {
                    ret = RET_GEN_ERR_INVARG;
                    this->printMsg(ret, "Unknown input parameter (dbaprocdef.c) defined the stored procedure! (" + this->getDdlObjSqlName() + "." + (*it)->sqlName + ")");
                }
            }
        }
    }

    if ((*procStp->outputDynStPtr) != NullDynSt)
    {

        if (this->m_dictSprocStp->m_dictSprocReturnsVector.size() > 1)
        {
            stringstream msg;
            msg << "Only one output dynamic structure should be defined on stored procedure";
            ret = RET_DBA_ERR_HIER_WARN;
            this->printMsg(ret, msg.str());
        }

        for (auto it = this->m_dictSprocStp->m_dictSprocReturnsVector.begin(); it != this->m_dictSprocStp->m_dictSprocReturnsVector.end(); ++it)
        {
            if (it->m_dynStEn != (*procStp->outputDynStPtr) &&
                GET_DYNST_TYPE((*procStp->outputDynStPtr)) != DynType_Other &&
                it->m_dynStEn != A_Empty)
            {
                stringstream msg;

                msg << "Wrong output dynamic structure on stored procedure, "
                    << "\"" << DBA_GetDynStCName(it->m_dynStEn) << "\""
                    << " is returned but "
                    << "\"" << DBA_GetDynStCName((*procStp->outputDynStPtr)) << "\""
                    << " is expected (dbaprocdef.c)";

                ret = RET_DBA_ERR_HIER_WARN;
                this->printMsg(ret, msg.str());
            }
        }
    }

    if (procStp->multiOutputDynStPtr != nullptr)
    {
        int i = 0;
        for (auto it = this->m_dictSprocStp->m_dictSprocReturnsVector.begin(); it != this->m_dictSprocStp->m_dictSprocReturnsVector.end(); ++it, ++i)
        {
            if (*(procStp->multiOutputDynStPtr[i]) == InvalidDynSt)
            {
                stringstream msg;

                msg << "Not enough multi-output dynamic structure are defined on stored procedure call definition (dbaprocdef.c)";
                ret = RET_DBA_ERR_HIER_WARN;
                this->printMsg(ret, msg.str());

                break;
            }

            if (it->m_dynStEn != *(procStp->multiOutputDynStPtr[i]) &&
                it->m_dynStEn != A_Empty &&
                it->m_dynStEn != NullDynSt)
            {
                stringstream msg;

                msg << "Wrong output dynamic structure on stored procedure, "
                    << "\"" << DBA_GetDynStCName(it->m_dynStEn) << "\""
                    << " is returned but "
                    << "\"" << DBA_GetDynStCName(*(procStp->multiOutputDynStPtr[i])) << "\""
                    << " is expected (dbaprocdef.c) on position " << (i+1);

                ret = RET_DBA_ERR_HIER_WARN;
                this->printMsg(ret, msg.str());
            }
        }
    }

    if (this->m_dictSprocStp->m_dictSprocReturnsVector.empty() &&
        ((*procStp->outputDynStPtr) != NullDynSt || procStp->multiOutputDynStPtr != nullptr))
    {
        stringstream msg;

        msg << "No output dynamic structure is defined on stored procedure";

        ret = RET_DBA_ERR_HIER_WARN;
        this->printMsg(ret, msg.str());
    }


    DBA_CONNECT_TYPE_ENUM  procDmlAccess = procStp->connection;

    if (procDmlAccess == Synchronous)
    {
        switch (procStp->action)
        {
            case Get:
            case Select:
            case Check:
                procDmlAccess = ReadOnly;
                break;

            case MultiSelect:
            case Notif:
                procDmlAccess = WriteTempTable;
                break;

                /* No check */
            case Truncate:
                procDmlAccess = Synchronous;
                break;

            case Insert:
            case InsUpd:
            case Delete:
            case Update:
            case Copy:
            default:
                procDmlAccess = WriteTable;
                break;
        }
    }

    if (procDmlAccess != this->m_dictSprocStp->dmlAccess)
    {
        if (procDmlAccess == ReadOnly && this->m_dictSprocStp->dmlAccess != ReadOnly)
        {
            stringstream writeAccessStream;
            stringstream msg;

            for (auto it = this->ddlGenContextPtr->m_dependsAccessSet.begin(); it != this->ddlGenContextPtr->m_dependsAccessSet.end(); it++)
            {
                if (it->getAccessEn() == DictDependsAccessEn::Insert ||
                    it->getAccessEn() == DictDependsAccessEn::Update ||
                    it->getAccessEn() == DictDependsAccessEn::Delete ||
                    it->getAccessEn() == DictDependsAccessEn::Truncate)
                {
                    if (writeAccessStream.str().empty() == false)
                    {
                        writeAccessStream << ", ";
                    }
                    writeAccessStream << it->getSqlName() << " " << it->getAccessStr();
                }
            }

            msg << "It's not allowed to do write in database ("
                << writeAccessStream.str() << ") in stored procedure flagged as 'read only' ("
                << DBA_GetActionName(procStp->action) << "), should be '" << DictSprocClass::getDmlAccessStr(this->m_dictSprocStp->dmlAccess) << "' instead of '" << DictSprocClass::getDmlAccessStr(procStp->connection) << "'";

            ret = RET_GEN_ERR_INVARG;
            this->printMsg(ret, msg.str());
        }
        else if (procDmlAccess != Synchronous)
        {
            if (this->ddlGenContextPtr->m_dependsSprocSet.empty())
            {
#ifdef _DEBUG
                if (procStp->subObj != DBA_ROLE_UPD_UD_FIELDS)
                {
                    stringstream msg;
                    msg << "Wrong connection information in DBA procedure structure information, should be '" << DictSprocClass::getDmlAccessStr(this->m_dictSprocStp->dmlAccess) << "' instead of '" << DictSprocClass::getDmlAccessStr(procStp->connection) << "'";
                    ret = RET_DBA_INFO_NODATA;

                    this->printMsg(ret, msg.str());
                }
#endif
            }
            else
            {
                this->m_dictSprocStp->dmlAccess = procDmlAccess;
            }
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenSProc::checkAllSProcParameters()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:  PMSTA-18593 - LJE - 151025
**
*************************************************************************/
RET_CODE DdlGenSProc::checkAllSProcParameters()
{
    RET_CODE ret = RET_SUCCEED;

    DBA_CONNECT_TYPE_ENUM  dmlAccess = ReadOnly;

    for (auto it = this->ddlGenContextPtr->m_dependsAccessSet.begin(); it != this->ddlGenContextPtr->m_dependsAccessSet.end(); it++)
    {
        if (it->getAccessEn() == DictDependsAccessEn::Insert ||
            it->getAccessEn() == DictDependsAccessEn::Update ||
            it->getAccessEn() == DictDependsAccessEn::Delete ||
            it->getAccessEn() == DictDependsAccessEn::Truncate)
        {
            if (dmlAccess == ReadOnly || dmlAccess == WriteTempTable)
            {
                DICT_ENTITY_STP refDictEntityStp = DBA_GetDictEntitySt(it->getObjectEn());

                if (refDictEntityStp && refDictEntityStp->entNatEn == EntityNat_TempTable)
                {
                    dmlAccess = WriteTempTable;
                }
                else
                {
                    dmlAccess = WriteTable;
                }
            }
        }
    }

    this->m_dictSprocStp->dmlAccess = dmlAccess;

    for (auto it = this->m_dictSprocStp->m_storedProcAccessVector.begin(); it != this->m_dictSprocStp->m_storedProcAccessVector.end(); ++it)
    {
        DBA_PROC_STP procStp = (*it);

        if (strcasecmp(this->getDdlObjSqlName().c_str(), procStp->procName) == 0)
        {
            this->checkSProcParameters(procStp);
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenSProc::check()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13122 - LJE - 120418
**
*************************************************************************/
RET_CODE DdlGenSProc::check()
{
    RET_CODE ret=RET_SUCCEED;

    this->setName();

    if (this->m_dictSprocStp->procAccessEn == ProcAccess_PrimaryKey &&
        this->m_dictSprocStp->procActionEn != Insert &&
        this->getDictEntityStp()->primKeyNbr == 0)
    {
        ret = RET_GEN_INFO_NOACTION;
        return ret;
    }

    /* Don't proceed create procedure on business key without business key... */
    if (this->m_dictSprocStp->procAccessEn == ProcAccess_BusinessKey &&
        /* PMSTA-16272 - LJE - 130429 */
        this->m_dictSprocStp->procActionEn != Insert &&
        this->m_dictSprocStp->procActionEn != InsUpd)
    {
        auto attribIt = this->getDictEntityStp()->attr.begin();
        for (; attribIt != this->getDictEntityStp()->attr.end(); attribIt++)
        {
            DICT_ATTRIB_STP dictAttribStp = (*attribIt);
            if (dictAttribStp->busKeyFlg == TRUE)
            {
                break;
            }
        }
        if (attribIt == this->getDictEntityStp()->attr.end())
        {
            ret = RET_GEN_INFO_NOACTION;
        }
    }
    else if (this->m_dictSprocStp->procAccessEn == ProcAccess_ParentKey &&
             this->getDictEntityStp()->isNullParIndex)
    {
        ret = RET_GEN_INFO_NOACTION;
    }
    /* PMSTA-26108 - LJE - 170829 */
    else if (this->m_dictSprocStp->procAccessEn == ProcAccess_NatureKey &&
             (this->getDictEntityStp()->isNullNatIndex || this->getDictEntityStp()->isNullParIndex == false)) /* PMSTA-45027 - LJE - 210521 */
    {
        ret = RET_GEN_INFO_NOACTION;
    }
    /* OCS-43062 - LJE - 130905 */
    else if (this->m_dictSprocStp->procAccessEn == ProcAccess_Full &&
             this->m_dictSprocStp->procActionEn == Select &&
             this->getDictEntityStp()->isNullParIndex == false)
    {
        ret = RET_GEN_INFO_NOACTION;
    }
    /* OCS-43062 - LJE - 130905 */
    else if (this->m_dictSprocStp->procAccessEn == ProcAccess_ParentKey &&
             this->m_dictSprocStp->procActionEn == Get &&
             this->getDictEntityStp()->isNullParIndex == false)
    {
        if (this->getDictEntityStp()->attr[this->getDictEntityStp()->parIndex]->refEntDictId == 0 &&
            this->getDictEntityStp()->attr[this->getDictEntityStp()->parIndex]->linkedAttrDictStp != NULL)
        {
            if (this->getDictEntityStp()->multiEntUKFlg == TRUE)
            {
                ret=RET_SUCCEED;
            }
            else
            {
                ret = RET_GEN_INFO_NOACTION;
            }
        }
        else
        {
            ret = RET_GEN_INFO_NOACTION;
        }
    }

    if (ret != RET_SUCCEED && this->m_bFromPscFile == true)
    {
        this->printMsg(RET_SUCCEED, string("Forced creation: ") + this->getMsgSqlName());
        ret = RET_SUCCEED;
    }

    if (ret == RET_SUCCEED && this->m_dictSprocStp->sqlName.length() > GET_MAXCHARLEN(SysnameType)) /* PMSTA-33077 - DLA - 181011 */
    {
        this->printMsg(RET_GEN_ERR_LENGTH, "The procedure name is too long, (" + this->m_dictSprocStp->sqlName + "), max 30 characters, truncated!");
        this->m_dictSprocStp->sqlName = this->m_dictSprocStp->sqlName.substr(0, GET_MAXCHARLEN(SysnameType)); /* PMSTA-33077 - DLA - 181011 */
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenSProc::build()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenSProc::build()
{
    RET_CODE ret = RET_SUCCEED;

    if (this->m_bCustomBody == false)
    {
        if ((ret = DdlGen::build()) != RET_SUCCEED)
        {
            this->printMsg(ret, "Create " + this->msgObjTypeStr + " on entity(" + this->getDdlObjSqlName() + ") failed");
            return ret;
        }

        if ((ret = this->check()) != RET_SUCCEED)
        {
            return ret;
        }

        this->scriptDdlGen->setMsgEntitySqlName(this->getMsgEntitySqlName());
        this->scriptDdlGen->setMsgSqlName(this->getMsgSqlName());
        this->printMsg(ret, "Creating");

        /* PMSTA-14452 - LJE - 121105 */
        this->lastErrRetCode = ret;
        if (this->m_dictSprocStp->role == DBA_ROLE_UPD_UD_FIELDS)
        {
            this->targetTableEn = TargetTable_UserDefinedFields;

            if (this->getDictEntityStp()->dbRuleEn == DbRule_NotInDatabase ||
                this->getDictEntityStp()->dbRuleEn == DbRule_OnlyMainTable)
            {
                this->lastErrRetCode = RET_GEN_INFO_NOACTION;
            }
        }
        else
        {
            this->targetTableEn = TargetTable_Main;
        }

        if (this->lastErrRetCode == RET_SUCCEED &&
            (RET_GET_LEVEL((ret = this->drop())) == RET_LEV_ERROR ||
            RET_GET_LEVEL((ret = this->create())) == RET_LEV_ERROR))
        {
            if (SERVER_MODE() == FALSE)
            {
                this->printMsg(ret, "Failed");
            }
            return ret;
        }

        if (this->lastErrRetCode == RET_SUCCEED &&
            ret == RET_SUCCEED &&
            RET_GET_LEVEL((ret = this->grant())) == RET_LEV_ERROR)
        {
            if (SERVER_MODE() == FALSE)
            {
                this->printMsg(ret, "Failed");
            }
            return ret;
        }

        this->varHelperPtr->cleanAllVar();

        if (this->lastErrRetCode == RET_GEN_INFO_NOACTION)
        {
            this->printMsg(RET_SRV_INFO_DONE, "Not modified");
        }
        else
        {
            this->printMsg(ret, "Done");
        }
    }
    else
    {
        ret = this->setSprocParam();
    }

    return ret;
}

/*************************************************************************
**   END  ddlgensproc.cpp                                   Odyssey **
*************************************************************************/

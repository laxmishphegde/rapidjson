/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define FINRISK01_C

/************************************************************************
**      Include files
*************************************************************************/
#include "unidef.h"         /* Mandatory */
#include "dba.h"
#include "fin.h"
#include "finsrv.h"


/**  ---------------
**  Risk function for Structured Product Notes
**  --------------
**
**  ------------------------------------------------------------------------------------------ */

/************************************************************************
**      Static definitions & data
*************************************************************************/
STATIC RET_CODE FIN_RiskSTNBasketPos(DBA_HIER_HEAD_STP, FIN_DOMAIN_ARG_STP, FIN_AIARG_STP, FIN_EXCHARG_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP,
	DBA_DYNFLD_STP, FIN_PRICEARG_STP, RISK_QTY_STP, RISK_ANALYSIS_ENUM),
	FIN_RiskSTNBondPos(FLAG_T, FLAG_T, DBA_HIER_HEAD_STP, FIN_DOMAIN_ARG_STP, FIN_AIARG_STP, FIN_EXCHARG_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP,
		DBA_DYNFLD_STP, FIN_PRICEARG_STP, RISK_ANALYSIS_ENUM),
	FIN_RiskSTNCashPos(DBA_HIER_HEAD_STP, FIN_DOMAIN_ARG_STP, FIN_AIARG_STP, FIN_EXCHARG_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP,
		DBA_DYNFLD_STP, FIN_PRICEARG_STP, RISK_ANALYSIS_ENUM),
	FIN_CreateSTNBond(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, FLAG_T, DBA_DYNFLD_STP*),
	FIN_STNBasketMarketPrice(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, PRICE_T*, FIN_PRICEARG_STP,
		DBA_DYNFLD_STP, FIN_DOMAIN_ARG_STP, FIN_EXCHARG_STP, DBA_DYNFLD_STP, PRICE_T*),
	FIN_STNAverageBasketMarketPrice(DBA_HIER_HEAD_STP, FIN_DOMAIN_ARG_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, PRICE_T*, FIN_PRICEARG_STP),
	FIN_STNAverageBasketBarrierPrice(DBA_HIER_HEAD_STP, FIN_DOMAIN_ARG_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, PRICE_T*, FIN_EXCHARG_STP, FIN_PRICEARG_STP);

/************************************************************************
**
**  Function    :   FIN_SetRiskPosNoExposure()
**
**  Description :   According to domain arguments and status, update the risk flag of
**				    position in case of no option/STN risk exposure
**
**  Return      :   RET_SUCCEED or error code
**
** Creation	    :   PMSTA-32112 - RAK - 180820
**
*************************************************************************/
void FIN_SetRiskPosNoExposure(FIN_DOMAIN_ARG_STP domainArgPtr,
	RISK_ANALYSIS_ENUM status,
	DBA_DYNFLD_STP origPos)
{
	if (status == Risk_Father)
	{
		if (domainArgPtr->fundRiskEn != FinFundRisk_FundCompo)
		{
			SET_ENUM(origPos, ExtPos_RiskNatEn, ExtPosRisk_FinRisk);
		}

		if (domainArgPtr->fundRiskEn != FinFundRisk_None)
		{
			SET_ENUM(origPos, ExtPos_FundSplitNatEn, FundSplitNat_Split);
		}
	}
}

/************************************************************************
**
**  Function    :   FIN_RiskPosSetExtPosPosAmountTo()
**
**  Description :   Update destination Net and Gross using ExtPos_PosNetAmt and ExtPos_PosGrossAmt
**					and exchange betweend PosCurrId and destination currency
**
**  Return      :   RET_SUCCEED or error code
**
** Creation	    :   PMSTA-32112 - RAK - 180820
**
*************************************************************************/
RET_CODE FIN_RiskPosSetExtPosPosAmtTo(FIELD_IDX_T		destNetAmt,
									  DBA_HIER_HEAD_STP posHierHead,
									  DBA_DYNFLD_STP	riskPos,
									  FIN_EXCHARG_STP	exchArgStp)
{
	RET_CODE		ret = RET_SUCCEED;
	FIELD_IDX_T		destGrossAmt=0;
	ID_T			destCurrId=ZERO_ID;
	AMOUNT_T		exchAmt;

	if (destNetAmt == ExtPos_InstrNetAmt)
	{
		destGrossAmt = ExtPos_InstrGrossAmt;
		destCurrId = GET_ID(riskPos, ExtPos_InstrCurrId);
	}
	else if (destNetAmt == ExtPos_RefNetAmt)
	{
		destGrossAmt = ExtPos_RefGrossAmt;
		destCurrId = GET_ID(riskPos, ExtPos_RefCurrId);
	}
	else if (destNetAmt == ExtPos_SysNetAmt)
	{
		DBA_DYNFLD_STP	ptfPtr = NULL;
		FLAG_T			allocPtfFlg;

		destGrossAmt = ExtPos_SysGrossAmt;

		if (GET_EXTENSION_PTR(riskPos, ExtPos_A_Ptf_Ext) != NULL &&
			(ptfPtr = *(GET_EXTENSION_PTR(riskPos, ExtPos_A_Ptf_Ext))) != NULL)
		{
			if (IS_NULLFLD(ptfPtr, A_Ptf_SysCurrId) == FALSE)
			{
				destCurrId = GET_ID(ptfPtr, A_Ptf_SysCurrId);
			}
		}
		else
		{
			if (IS_NULLFLD(riskPos, ExtPos_PtfId) == FALSE)
			{
				if ((ret = DBA_GetPtfById(GET_ID(riskPos, ExtPos_PtfId), FALSE, &allocPtfFlg,
					&ptfPtr, posHierHead, UNUSED, UNUSED)) != RET_SUCCEED)
				{
					return (ret);
				}

				if (IS_NULLFLD(ptfPtr, A_Ptf_SysCurrId) == FALSE)
				{
					destCurrId = GET_ID(ptfPtr, A_Ptf_SysCurrId);
				}

				if (allocPtfFlg == TRUE) { FREE_DYNST(ptfPtr, A_Ptf); }
			}
		}

		if (destCurrId == 0)
			GEN_GetApplInfo(ApplSysCurrId, &destCurrId);
	}

	if (GET_ID(riskPos, ExtPos_PosCurrId) == destCurrId)
	{
		SET_AMOUNT(riskPos, destNetAmt, GET_AMOUNT(riskPos, ExtPos_PosNetAmt));
		SET_AMOUNT(riskPos, destGrossAmt, GET_AMOUNT(riskPos, ExtPos_PosGrossAmt));
	}
	else
	{
		exchArgStp->srcAmt = GET_AMOUNT(riskPos, ExtPos_PosNetAmt);
		FIN_ExchAmt(GET_DATETIME(riskPos, ExtPos_BegDate),
				GET_ID(riskPos, ExtPos_PosCurrId),
				destCurrId,
				0, NULL, riskPos, exchArgStp,
				NULL, &exchAmt, NULL);
		SET_AMOUNT(riskPos, destNetAmt, exchAmt);

		exchArgStp->srcAmt = GET_AMOUNT(riskPos, ExtPos_PosGrossAmt);
		FIN_ExchAmt(GET_DATETIME(riskPos, ExtPos_BegDate),
				GET_ID(riskPos, ExtPos_PosCurrId),
				destCurrId,
				0, NULL, riskPos, exchArgStp,
				NULL, &exchAmt, NULL);

		SET_AMOUNT(riskPos, destGrossAmt, exchAmt);
	}

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_TreatInstrCategoryRCN()
**
**  Description :
**
**  Return      :   RET_SUCCEED or error code
**
** Creation	    :   PMSTA-32112 - RAK - 180820
**
*************************************************************************/
RET_CODE FIN_TreatInstrCategoryRCN(DBA_HIER_HEAD_STP  posHierHead,
	DBA_DYNFLD_STP		 domainPtr,
	FIN_DOMAIN_ARG_STP   domainArgPtr,
	FIN_AIARG_STP        aiArgPtr,
	DBA_DYNFLD_STP       origPos,
	DBA_DYNFLD_STP       instrPtr,
	char                 instrHierFlg,
	FIN_PRICEARG_STP     priceArgStp,
	RISK_QTY_STP		 riskQtyStp,	/* PMSTA-34140 - RAK - 190122 - Could be sent to FIN_RiskSTNBasketPos */
	RISK_ANALYSIS_ENUM   status)
{
	RET_CODE             ret;
	FIN_EXCHARG_ST       exchArgSt;
    DBA_DYNFLD_STP       totPosRisk = nullptr;

    MemoryPool mp;

	/* Use domain parameter option_risk_rule_e for structured notes too */
	/* With value = 0, structured notes will not be treated for risk exposure (Risk view = Accounting view). */
	if (domainArgPtr->optDeltaRule == OptDelta_None)
	{
		FIN_SetRiskPosNoExposure(domainArgPtr, status, origPos);
		return(RET_SUCCEED);
	}

	memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));
	DBA_InitConnectNoToExchArg(&exchArgSt, posHierHead);

	/* Init total risk and create zero bond position and underlying position(s) */
	if ((totPosRisk = FIN_CreateRiskAmt(posHierHead, origPos, domainArgPtr->fromDateTime,
		domainArgPtr->refCurrId)) != NULL)
	{
        mp.ownerDynStp(totPosRisk);
		/* Coupon Bond with quantity = STN quantity */
		if ((ret = FIN_RiskSTNBondPos(FALSE, FALSE, posHierHead, domainArgPtr, aiArgPtr, &exchArgSt, origPos, instrPtr,
			totPosRisk, priceArgStp, Risk_Son)) != RET_SUCCEED)
			return(ret);

		/* Underlying basket */
		if ((ret = FIN_RiskSTNBasketPos(posHierHead, domainArgPtr, aiArgPtr, &exchArgSt, origPos, instrPtr,
			totPosRisk, priceArgStp, riskQtyStp, Risk_Son)) != RET_SUCCEED)
			return(ret);

		/* Cash */
		if ((ret = FIN_RiskSTNCashPos(posHierHead, domainArgPtr, aiArgPtr, &exchArgSt, origPos, instrPtr,
			totPosRisk, priceArgStp, Risk_LastSon)) != RET_SUCCEED)
			return(ret);

	}
	else
		ret = RET_GEN_INFO_NOACTION;

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_TreatInstrCategoryCLN()
**
**  Description :
**
**  Return      :   RET_SUCCEED or error code
**
** Creation	    :   PMSTA-32112 - RAK - 180820
**					PMSTA-32504 - SIL - 181211  : Underlying basket Position Calculation
**
*************************************************************************/
RET_CODE FIN_TreatInstrCategoryCLN(DBA_HIER_HEAD_STP  posHierHead,
	DBA_DYNFLD_STP		 domainPtr,
	FIN_DOMAIN_ARG_STP   domainArgPtr,
	FIN_AIARG_STP        aiArgPtr,
	DBA_DYNFLD_STP       origPos,
	DBA_DYNFLD_STP       instrPtr,
	char                 instrHierFlg,
	FIN_PRICEARG_STP     priceArgStp,
	RISK_QTY_STP		 riskQtyStp,	/* PMSTA-34140 - RAK - 190122 - Could be sent to FIN_RiskSTNBasketPos */
	RISK_ANALYSIS_ENUM   status)
{
	RET_CODE             ret;
	FIN_EXCHARG_ST       exchArgSt;
    DBA_DYNFLD_STP       totPosRisk = nullptr;

    MemoryPool mp;
    
	/* Use domain parameter option_risk_rule_e for structured notes too */
	/* With value = 0, structured notes will not be treated for risk exposure (Risk view = Accounting view). */
	if (domainArgPtr->optDeltaRule == OptDelta_None)
	{
		FIN_SetRiskPosNoExposure(domainArgPtr, status, origPos);
		return(RET_SUCCEED);
	}

	memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));
	DBA_InitConnectNoToExchArg(&exchArgSt, posHierHead);

	/* Init total risk and create zero bond position and underlying position(s) */
	if ((totPosRisk = FIN_CreateRiskAmt(posHierHead, origPos, domainArgPtr->fromDateTime,
		domainArgPtr->refCurrId)) != NULL)
	{
        mp.ownerDynStp(totPosRisk);
		/* Coupon Bond with quantity = STN quantity */
		if ((ret = FIN_RiskSTNBondPos(FALSE, FALSE, posHierHead, domainArgPtr, aiArgPtr, &exchArgSt, origPos, instrPtr,
			totPosRisk, priceArgStp, Risk_Son)) != RET_SUCCEED)
			return(ret);

		/* Underlying basket */
		if ((ret = FIN_RiskSTNBasketPos(posHierHead, domainArgPtr, aiArgPtr, &exchArgSt, origPos, instrPtr,
			totPosRisk, priceArgStp, riskQtyStp, Risk_Son)) != RET_SUCCEED)
			return(ret);

		/* Cash */
		if ((ret = FIN_RiskSTNCashPos(posHierHead, domainArgPtr, aiArgPtr, &exchArgSt, origPos, instrPtr,
			totPosRisk, priceArgStp, Risk_LastSon)) != RET_SUCCEED)
			return(ret);

	}
	else
		ret = RET_GEN_INFO_NOACTION;

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_TreatInstrCategoryDiscountC()
**
**  Description :
**
**  Return      :   RET_SUCCEED or error code
**
** Creation	    :   PMSTA-32112 - RAK - 180820
**					PMSTA-32504 - SIL - 181211  : Underlying basket Position Calculation
**
*************************************************************************/
RET_CODE FIN_TreatInstrCategoryDiscountC(DBA_HIER_HEAD_STP  posHierHead,
	DBA_DYNFLD_STP		 domainPtr,
	FIN_DOMAIN_ARG_STP   domainArgPtr,
	FIN_AIARG_STP        aiArgPtr,
	DBA_DYNFLD_STP       origPos,
	DBA_DYNFLD_STP       instrPtr,
	char                 instrHierFlg,
	FIN_PRICEARG_STP     priceArgStp,
	RISK_QTY_STP		 riskQtyStp,	/* PMSTA-34140 - RAK - 190122 - Could be sent to FIN_RiskSTNBasketPos */
	RISK_ANALYSIS_ENUM   status)
{
	RET_CODE             ret;
	FIN_EXCHARG_ST       exchArgSt;
    DBA_DYNFLD_STP       totPosRisk = nullptr;

    MemoryPool mp;

	/* Use domain parameter option_risk_rule_e for structured notes too */
	/* With value = 0, structured notes will not be treated for risk exposure (Risk view = Accounting view). */
	if (domainArgPtr->optDeltaRule == OptDelta_None)
	{
		FIN_SetRiskPosNoExposure(domainArgPtr, status, origPos);
		return(RET_SUCCEED);
	}

	memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));
	DBA_InitConnectNoToExchArg(&exchArgSt, posHierHead);

	/* Init total risk and create zero bond position and underlying position(s) */
	if ((totPosRisk = FIN_CreateRiskAmt(posHierHead, origPos, domainArgPtr->fromDateTime,
		domainArgPtr->refCurrId)) != NULL)
	{
        mp.ownerDynStp(totPosRisk);
		/* Zero Coupon Bond with quantity = STN quantity */
		if ((ret = FIN_RiskSTNBondPos(TRUE, FALSE, posHierHead, domainArgPtr, aiArgPtr, &exchArgSt, origPos, instrPtr,
			totPosRisk, priceArgStp, Risk_Son)) != RET_SUCCEED)
			return(ret);

		/* Underlying basket */
		if ((ret = FIN_RiskSTNBasketPos(posHierHead, domainArgPtr, aiArgPtr, &exchArgSt, origPos, instrPtr,
			totPosRisk, priceArgStp, riskQtyStp, Risk_Son)) != RET_SUCCEED)
			return(ret);

		/* Cash */
		if ((ret = FIN_RiskSTNCashPos(posHierHead, domainArgPtr, aiArgPtr, &exchArgSt, origPos, instrPtr,
			totPosRisk, priceArgStp, Risk_LastSon)) != RET_SUCCEED)
			return(ret);

	}
	else
		ret = RET_GEN_INFO_NOACTION;

	return(ret);
}


/************************************************************************
**
**  Function    :   FIN_TreatInstrCategoryTwinWIn()
**
**  Description :
**
**  Return      :   RET_SUCCEED or error code
**
** Creation	    :   PMSTA-32112 - RAK - 180820
**
*************************************************************************/
RET_CODE FIN_TreatInstrCategoryTwinWin(DBA_HIER_HEAD_STP  posHierHead,
	DBA_DYNFLD_STP		 domainPtr,
	FIN_DOMAIN_ARG_STP   domainArgPtr,
	FIN_AIARG_STP        aiArgPtr,
	DBA_DYNFLD_STP       origPos,
	DBA_DYNFLD_STP       instrPtr,
	char                 instrHierFlg,
	FIN_PRICEARG_STP     priceArgStp,
	RISK_QTY_STP		 riskQtyStp,	/* PMSTA-34140 - RAK - 190122 - Could be sent to FIN_RiskSTNBasketPos */
	RISK_ANALYSIS_ENUM   status)
{
	RET_CODE             ret;
	FIN_EXCHARG_ST       exchArgSt;
    DBA_DYNFLD_STP       totPosRisk = nullptr;

    MemoryPool mp;

	/* Use domain parameter option_risk_rule_e for structured notes too */
	/* With value = 0, structured notes will not be treated for risk exposure (Risk view = Accounting view). */
	if (domainArgPtr->optDeltaRule == OptDelta_None)
	{
		FIN_SetRiskPosNoExposure(domainArgPtr, status, origPos);
		return(RET_SUCCEED);
	}

	memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));
	DBA_InitConnectNoToExchArg(&exchArgSt, posHierHead);

	/* Init total risk and create zero bond position and underlying position(s) */
	if ((totPosRisk = FIN_CreateRiskAmt(posHierHead, origPos, domainArgPtr->fromDateTime,
		domainArgPtr->refCurrId)) != NULL)
	{
        mp.ownerDynStp(totPosRisk);
        /* No Zero Bond Coupon or Interest Rate Bond position */
        /* Basket underlying long call or short put option */
        if ((ret = FIN_RiskSTNBasketPos(posHierHead, domainArgPtr, aiArgPtr, &exchArgSt, origPos, instrPtr,
            totPosRisk, priceArgStp, riskQtyStp, Risk_Son)) != RET_SUCCEED)
            return(ret);

		/* Cash */
		if ((ret = FIN_RiskSTNCashPos(posHierHead, domainArgPtr, aiArgPtr, &exchArgSt, origPos, instrPtr,
			totPosRisk, priceArgStp, Risk_LastSon)) != RET_SUCCEED)
			return(ret);

	}
	else
		ret = RET_GEN_INFO_NOACTION;

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_TreatInstrCategoryBonusNotes()
**
**  Description :
**
**  Return      :   RET_SUCCEED or error code
**
** Creation	    :   PMSTA-32112 - RAK - 180820
**
*************************************************************************/
RET_CODE FIN_TreatInstrCategoryBonusNotes(DBA_HIER_HEAD_STP  posHierHead,
	DBA_DYNFLD_STP		 domainPtr,
	FIN_DOMAIN_ARG_STP   domainArgPtr,
	FIN_AIARG_STP        aiArgPtr,
	DBA_DYNFLD_STP       origPos,
	DBA_DYNFLD_STP       instrPtr,
	char                 instrHierFlg,
	FIN_PRICEARG_STP     priceArgStp,
	RISK_QTY_STP		 riskQtyStp, /* PMSTA-34140 - RAK - 190122 - Could be sent to FIN_RiskSTNBasketPos */
	RISK_ANALYSIS_ENUM   status)
{
	RET_CODE             ret;
	FIN_EXCHARG_ST       exchArgSt;
    DBA_DYNFLD_STP       totPosRisk = nullptr;

    MemoryPool mp;

	/* Use domain parameter option_risk_rule_e for structured notes too */
	/* With value = 0, structured notes will not be treated for risk exposure (Risk view = Accounting view). */
	if (domainArgPtr->optDeltaRule == OptDelta_None)
	{
		FIN_SetRiskPosNoExposure(domainArgPtr, status, origPos);
		return(RET_SUCCEED);
	}

	memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));
	DBA_InitConnectNoToExchArg(&exchArgSt, posHierHead);

	/* Init total risk and create zero bond position and underlying position(s) */
	if ((totPosRisk = FIN_CreateRiskAmt(posHierHead, origPos, domainArgPtr->fromDateTime,
		domainArgPtr->refCurrId)) != NULL)
	{
        mp.ownerDynStp(totPosRisk);
        /* No Zero Bond Coupon or Interest Rate Bond position */
        /* Basket underlying long call or short put option */
        if ((ret = FIN_RiskSTNBasketPos(posHierHead, domainArgPtr, aiArgPtr, &exchArgSt, origPos, instrPtr,
            totPosRisk, priceArgStp, riskQtyStp, Risk_Son)) != RET_SUCCEED)
            return(ret);

		/* Cash */
		if ((ret = FIN_RiskSTNCashPos(posHierHead, domainArgPtr, aiArgPtr, &exchArgSt, origPos, instrPtr,
			totPosRisk, priceArgStp, Risk_LastSon)) != RET_SUCCEED)
			return(ret);

	}
	else
		ret = RET_GEN_INFO_NOACTION;

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_TreatInstrCategoryTurbo()
**
**  Description :
**
**  Return      :   RET_SUCCEED or error code
**
** Creation	    :   PMSTA-32112 - RAK - 180820
**					PMSTA-32504 - SIL - 181211  : Underlying basket Position Calculation
**
*************************************************************************/
RET_CODE FIN_TreatInstrCategoryTurbo(DBA_HIER_HEAD_STP  posHierHead,
	DBA_DYNFLD_STP		 domainPtr,
	FIN_DOMAIN_ARG_STP   domainArgPtr,
	FIN_AIARG_STP        aiArgPtr,
	DBA_DYNFLD_STP       origPos,
	DBA_DYNFLD_STP       instrPtr,
	char                 instrHierFlg,
	FIN_PRICEARG_STP     priceArgStp,
	RISK_QTY_STP		 riskQtyStp, /* PMSTA-34140 - RAK - 190122 - Could be sent to FIN_RiskSTNBasketPos */
	RISK_ANALYSIS_ENUM   status)
{
	RET_CODE             ret;
	FIN_EXCHARG_ST       exchArgSt;
    DBA_DYNFLD_STP       totPosRisk = nullptr;

    MemoryPool mp;

	/* Use domain parameter option_risk_rule_e for structured notes too */
	/* With value = 0, structured notes will not be treated for risk exposure (Risk view = Accounting view). */
	if (domainArgPtr->optDeltaRule == OptDelta_None)
	{
		FIN_SetRiskPosNoExposure(domainArgPtr, status, origPos);
		return(RET_SUCCEED);
	}

	memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));
	DBA_InitConnectNoToExchArg(&exchArgSt, posHierHead);

	/* Init total risk and create zero bond position and underlying position(s) */
	if ((totPosRisk = FIN_CreateRiskAmt(posHierHead, origPos, domainArgPtr->fromDateTime,
		domainArgPtr->refCurrId)) != NULL)
	{
        mp.ownerDynStp(totPosRisk);
		/* No zero bond position & interest paying bond position */
		/* Underlying basket */
		if ((ret = FIN_RiskSTNBasketPos(posHierHead, domainArgPtr, aiArgPtr, &exchArgSt, origPos, instrPtr,
			totPosRisk, priceArgStp, riskQtyStp, Risk_Son)) != RET_SUCCEED)
			return(ret);

		/* Cash */
		if ((ret = FIN_RiskSTNCashPos(posHierHead, domainArgPtr, aiArgPtr, &exchArgSt, origPos, instrPtr,
			totPosRisk, priceArgStp, Risk_LastSon)) != RET_SUCCEED)
			return(ret);

	}
	else
		ret = RET_GEN_INFO_NOACTION;

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_TreatInstrCategoryELN()
**
**  Description :
**
**  Return      :   RET_SUCCEED or error code
**
** Creation	    :   PMSTA-32112 - RAK - 180820
**
*************************************************************************/
RET_CODE FIN_TreatInstrCategoryELN(DBA_HIER_HEAD_STP         posHierHead,
										DBA_DYNFLD_STP		 domainPtr,
										FIN_DOMAIN_ARG_STP   domainArgPtr,
										FIN_AIARG_STP        aiArgPtr,
										DBA_DYNFLD_STP       origPos,
										DBA_DYNFLD_STP       instrPtr,
										char                 instrHierFlg,
										FIN_PRICEARG_STP     priceArgStp,
										RISK_QTY_STP		 riskQtyStp, /* PMSTA-34140 - RAK - 190122 - Could be sent to FIN_RiskSTNBasketPos */
										RISK_ANALYSIS_ENUM   status)
{
	RET_CODE             ret;
	FIN_EXCHARG_ST       exchArgSt;
    DBA_DYNFLD_STP       totPosRisk = nullptr;

    MemoryPool mp;

	/* Use domain parameter option_risk_rule_e for structured notes too */
	/* With value = 0, structured notes will not be treated for risk exposure (Risk view = Accounting view). */
	if (domainArgPtr->optDeltaRule == OptDelta_None)
	{
		FIN_SetRiskPosNoExposure(domainArgPtr, status, origPos);
		return(RET_SUCCEED);
	}

	memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));
	DBA_InitConnectNoToExchArg(&exchArgSt, posHierHead);

	/* Init total risk and create zero bond position and underlying position(s) */
	if ((totPosRisk = FIN_CreateRiskAmt(posHierHead, origPos, domainArgPtr->fromDateTime,
		                                domainArgPtr->refCurrId)) != NULL)
	{
        mp.ownerDynStp(totPosRisk);
		/* Zero Coupon Bond with capital protection  */
		if ((ret = FIN_RiskSTNBondPos(TRUE, TRUE, posHierHead, domainArgPtr, aiArgPtr, &exchArgSt, origPos, instrPtr,
			totPosRisk, priceArgStp, Risk_Son)) != RET_SUCCEED)
			return(ret);

		/* Underlying basket */
		if ((ret = FIN_RiskSTNBasketPos(posHierHead, domainArgPtr, aiArgPtr, &exchArgSt, origPos, instrPtr,
			totPosRisk, priceArgStp, riskQtyStp, Risk_Son)) != RET_SUCCEED)
			return(ret);

		/* Cash */
		if ((ret = FIN_RiskSTNCashPos(posHierHead, domainArgPtr, aiArgPtr, &exchArgSt, origPos, instrPtr,
			totPosRisk, priceArgStp, Risk_LastSon)) != RET_SUCCEED)
			return(ret);

	}
	else
		ret = RET_GEN_INFO_NOACTION;

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_TreatInstrCategoryPPN()
**
**  Description :
**
**  Return      :   RET_SUCCEED or error code
**
** Creation	    :   PMSTA-32112 - RAK - 180820
**
*************************************************************************/
RET_CODE FIN_TreatInstrCategoryPPN(DBA_HIER_HEAD_STP         posHierHead,
	DBA_DYNFLD_STP		 domainPtr,
	FIN_DOMAIN_ARG_STP   domainArgPtr,
	FIN_AIARG_STP        aiArgPtr,
	DBA_DYNFLD_STP       origPos,
	DBA_DYNFLD_STP       instrPtr,
	char                 instrHierFlg,
	FIN_PRICEARG_STP     priceArgStp,
	RISK_QTY_STP		 riskQtyStp, /* PMSTA-34140 - RAK - 190122 - Could be sent to FIN_RiskSTNBasketPos */
	RISK_ANALYSIS_ENUM   status)
{
	RET_CODE             ret;
	FIN_EXCHARG_ST       exchArgSt;
    DBA_DYNFLD_STP       totPosRisk = nullptr;

    MemoryPool mp;

	/* Use domain parameter option_risk_rule_e for structured notes too */
	/* With value = 0, structured notes will not be treated for risk exposure (Risk view = Accounting view). */
	if (domainArgPtr->optDeltaRule == OptDelta_None)
	{
		FIN_SetRiskPosNoExposure(domainArgPtr, status, origPos);
		return(RET_SUCCEED);
	}

	memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));
	DBA_InitConnectNoToExchArg(&exchArgSt, posHierHead);

	/* Init total risk and create zero bond position and underlying position(s) */
	if ((totPosRisk = FIN_CreateRiskAmt(posHierHead, origPos, domainArgPtr->fromDateTime,
		domainArgPtr->refCurrId)) != NULL)
	{
        mp.ownerDynStp(totPosRisk);
		/* Coupon Bond with capital protection  */
		if ((ret = FIN_RiskSTNBondPos(FALSE, TRUE, posHierHead, domainArgPtr, aiArgPtr, &exchArgSt, origPos, instrPtr,
			totPosRisk, priceArgStp, Risk_Son)) != RET_SUCCEED)
			return(ret);

		/* Underlying basket as PPN */
		if ((ret = FIN_RiskSTNBasketPos(posHierHead, domainArgPtr, aiArgPtr, &exchArgSt, origPos, instrPtr,
			totPosRisk, priceArgStp, riskQtyStp, Risk_Son)) != RET_SUCCEED)
			return(ret);

		/* Cash */
		if ((ret = FIN_RiskSTNCashPos(posHierHead, domainArgPtr, aiArgPtr, &exchArgSt, origPos, instrPtr,
			totPosRisk, priceArgStp, Risk_LastSon)) != RET_SUCCEED)
			return(ret);

	}
	else
		ret = RET_GEN_INFO_NOACTION;

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_TreatInstrCategoryAirbag()
**
**  Description :
**
**  Return      :   RET_SUCCEED or error code
**
** Creation	    :   PMSTA-32112 - RAK - 180820
**
*************************************************************************/
RET_CODE FIN_TreatInstrCategoryAirbag(DBA_HIER_HEAD_STP         posHierHead,
	DBA_DYNFLD_STP		 domainPtr,
	FIN_DOMAIN_ARG_STP   domainArgPtr,
	FIN_AIARG_STP        aiArgPtr,
	DBA_DYNFLD_STP       origPos,
	DBA_DYNFLD_STP       instrPtr,
	char                 instrHierFlg,
	FIN_PRICEARG_STP     priceArgStp,
	RISK_QTY_STP		 riskQtyStp, /* PMSTA-34140 - RAK - 190122 - Could be sent to FIN_RiskSTNBasketPos */
	RISK_ANALYSIS_ENUM   status)
{
	RET_CODE             ret;
	FIN_EXCHARG_ST       exchArgSt;
    DBA_DYNFLD_STP       totPosRisk = nullptr;

    MemoryPool mp;

	/* Use domain parameter option_risk_rule_e for structured notes too */
	/* With value = 0, structured notes will not be treated for risk exposure (Risk view = Accounting view). */
	if (domainArgPtr->optDeltaRule == OptDelta_None)
	{
		FIN_SetRiskPosNoExposure(domainArgPtr, status, origPos);
		return(RET_SUCCEED);
	}

	memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));
	DBA_InitConnectNoToExchArg(&exchArgSt, posHierHead);

	/* Init total risk and create zero bond position and underlying position(s) */
	if ((totPosRisk = FIN_CreateRiskAmt(posHierHead, origPos, domainArgPtr->fromDateTime,
		domainArgPtr->refCurrId)) != NULL)
	{
        mp.ownerDynStp(totPosRisk);
		/* Zero Coupon Bond with quantity = STN quantity */
		if ((ret = FIN_RiskSTNBondPos(TRUE, FALSE, posHierHead, domainArgPtr, aiArgPtr, &exchArgSt, origPos, instrPtr,
			totPosRisk, priceArgStp, Risk_Son)) != RET_SUCCEED)
			return(ret);

		/* Basket underlying long call or short put option */
        if ((ret = FIN_RiskSTNBasketPos(posHierHead, domainArgPtr, aiArgPtr, &exchArgSt, origPos, instrPtr,
            totPosRisk, priceArgStp, riskQtyStp, Risk_Son)) != RET_SUCCEED)
            return(ret);

		/* Cash */
		if ((ret = FIN_RiskSTNCashPos(posHierHead, domainArgPtr, aiArgPtr, &exchArgSt, origPos, instrPtr,
			totPosRisk, priceArgStp, Risk_LastSon)) != RET_SUCCEED)
			return(ret);

	}
	else
		ret = RET_GEN_INFO_NOACTION;

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_TreatInstrCategoryMemoryC()
**
**  Description :
**
**  Return      :   RET_SUCCEED or error code
**
** Creation	    :   PMSTA-32112 - RAK - 180820
**
*************************************************************************/
RET_CODE FIN_TreatInstrCategoryMemoryC(DBA_HIER_HEAD_STP         posHierHead,
	DBA_DYNFLD_STP		 domainPtr,
	FIN_DOMAIN_ARG_STP   domainArgPtr,
	FIN_AIARG_STP        aiArgPtr,
	DBA_DYNFLD_STP       origPos,
	DBA_DYNFLD_STP       instrPtr,
	char                 instrHierFlg,
	FIN_PRICEARG_STP     priceArgStp,
	RISK_QTY_STP		 riskQtyStp, /* PMSTA-34140 - RAK - 190122 - Could be sent to FIN_RiskSTNBasketPos */
	RISK_ANALYSIS_ENUM   status)
{
	RET_CODE             ret;
	FIN_EXCHARG_ST       exchArgSt;
    DBA_DYNFLD_STP       totPosRisk = nullptr;

    MemoryPool mp;

	/* Use domain parameter option_risk_rule_e for structured notes too */
	/* With value = 0, structured notes will not be treated for risk exposure (Risk view = Accounting view). */
	if (domainArgPtr->optDeltaRule == OptDelta_None)
	{
		FIN_SetRiskPosNoExposure(domainArgPtr, status, origPos);
		return(RET_SUCCEED);
	}

	memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));
	DBA_InitConnectNoToExchArg(&exchArgSt, posHierHead);

	/* Init total risk and create zero bond position and underlying position(s) */
	if ((totPosRisk = FIN_CreateRiskAmt(posHierHead, origPos, domainArgPtr->fromDateTime,
		domainArgPtr->refCurrId)) != NULL)
	{
        mp.ownerDynStp(totPosRisk);
		/* Coupon Bond with quantity = STN quantity*/
		if ((ret = FIN_RiskSTNBondPos(FALSE, FALSE, posHierHead, domainArgPtr, aiArgPtr, &exchArgSt, origPos, instrPtr,
			totPosRisk, priceArgStp, Risk_Son)) != RET_SUCCEED)
			return(ret);

		/* MemoryC leg treatment for Basket*/
        if ((ret = FIN_RiskSTNBasketPos(posHierHead, domainArgPtr, aiArgPtr, &exchArgSt, origPos, instrPtr,
            totPosRisk, priceArgStp, riskQtyStp, Risk_Son)) != RET_SUCCEED)
            return(ret);

		/* Cash */
		if ((ret = FIN_RiskSTNCashPos(posHierHead, domainArgPtr, aiArgPtr, &exchArgSt, origPos, instrPtr,
			totPosRisk, priceArgStp, Risk_LastSon)) != RET_SUCCEED)
			return(ret);

	}
	else
		ret = RET_GEN_INFO_NOACTION;

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_RiskSTNCashPos()
**
**  Description :
**
**  Return      :   RET_SUCCEED or error code
**
** Creation	    :   PMSTA-32112 - RAK - 180820
**
*************************************************************************/
STATIC RET_CODE FIN_RiskSTNCashPos(DBA_HIER_HEAD_STP   posHierHead,
									FIN_DOMAIN_ARG_STP  domainArgPtr,
									FIN_AIARG_STP	   aiArgPtr,
									FIN_EXCHARG_STP	   exchArgStp,
									DBA_DYNFLD_STP      origPos,
									DBA_DYNFLD_STP      STNPtr,
									DBA_DYNFLD_STP      totPosRisk,
									FIN_PRICEARG_STP    priceArgStp,
									RISK_ANALYSIS_ENUM  status)
{
	DBA_DYNFLD_STP		 cashInstr = NULL, cashPos = NULL, testCashInstr = NULL;
	PRICE_T			 price = 0.0;
	ID_T                 priceCurrId = 0;
	EXCHANGE_T           exch;
	AMOUNT_T             amt;
	NUMBER_T			 qty;
	RET_CODE ret = RET_SUCCEED;

	if ((cashPos = ALLOC_DYNST(ExtPos)) == NULL)
	{
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	COPY_DYNST(cashPos, origPos, ExtPos);

	SET_ENUM(origPos, ExtPos_RiskNatEn, ExtPosRisk_NoRisk);
	SET_FLAG(cashPos, ExtPos_MainFlg, FALSE);

	/* Suppress extension identifier (copied from origin position) */
	SET_NULL_ID(cashPos, ExtPos_MainExtPosId);
	SET_NULL_ID(cashPos, ExtPos_AcctExtPosId);
	SET_NULL_ID(cashPos, ExtPos_AdjustExtPosId);
	SET_NULL_ID(cashPos, ExtPos_PosValId);

	if ((cashInstr = ALLOC_DYNST(A_Instr)) == NULL)
	{
		FREE_DYNST(cashPos, ExtPos);
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	MemoryPool mp;
	DBA_DYNFLD_STP getData = mp.allocDynst(FILEINFO, Get_Arg);

	/* An offsetting cash position would be shown in the currency of the note */
	SET_ID(getData,   Get_Arg_RefCurrId, GET_ID(STNPtr, A_Instr_RefCurrId));
	SET_ENUM(getData, Get_Arg_NatEn, InstrNat_CashAcct);

	if (DBA_Get2(Instr, UNUSED, Get_Arg, getData, A_Instr, &cashInstr, UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
	{
		/* clear error message */
		DBA_DYNFLD_STP	currPtr = NULL;
		FLAG_T          freeFlag = FALSE;

		if (DBA_GetCurrById(GET_ID(getData, Get_Arg_RefCurrId), &currPtr, &freeFlag) == RET_SUCCEED)
		{ MSG_SendMesg(RET_DBA_ERR_NODATA, 10, FILEINFO, GET_CODE(currPtr, A_Curr_Cd));}
		else
		{ MSG_SendMesg(RET_DBA_ERR_NODATA, 11, FILEINFO, GET_ID(getData, Get_Arg_RefCurrId));}

		if (freeFlag == TRUE) { FREE_DYNST(currPtr, A_Curr); }
		FREE_DYNST(cashInstr, A_Instr);
		FREE_DYNST(cashPos, ExtPos);
		return(RET_DBA_ERR_NODATA);
	}

	SET_ID(cashPos, ExtPos_InstrId, GET_ID(cashInstr, A_Instr_Id));
	SET_ID(cashPos, ExtPos_InstrCurrId, GET_ID(cashInstr, A_Instr_RefCurrId));

	price = 1;
	/* PMSTA-34140 - RAK - 190201 - Wrong it will be in cash instrument currency and not main instrument currency */
	/* priceCurrId = GET_ID(STNPtr, A_Instr_RefCurrId); */
	priceCurrId = GET_ID(cashInstr, A_Instr_RefCurrId);

	/* Convert price in position currency */
	FIN_GetExchRate(GET_DATETIME(cashPos, ExtPos_BegDate),
			priceCurrId, GET_ID(cashPos, ExtPos_PosCurrId),
			(ID_T)0, NULL, cashPos, exchArgStp, &exch);
	price *= exch;

	if (GET_ID(cashPos, ExtPos_RefCurrId) != GET_ID(cashPos, ExtPos_PosCurrId))
	{
		FIN_GetExchRate(GET_DATETIME(cashPos, ExtPos_BegDate),
			GET_ID(cashPos, ExtPos_PosCurrId),
			GET_ID(cashPos, ExtPos_RefCurrId),
			(ID_T)0, NULL, cashPos, exchArgStp, &exch);
		SET_EXCHANGE(cashPos, ExtPos_PosExchRate, exch);
	}
	else
	{
		SET_EXCHANGE(cashPos, ExtPos_PosExchRate, 1.0);
	}

	if (GET_ID(cashPos, ExtPos_RefCurrId) != GET_ID(cashPos, ExtPos_InstrCurrId))
	{
		FIN_GetExchRate(GET_DATETIME(cashPos, ExtPos_BegDate),
			GET_ID(cashPos, ExtPos_InstrCurrId),
			GET_ID(cashPos, ExtPos_RefCurrId),
			(ID_T)0, NULL, cashPos, exchArgStp, &exch);	/* PMSTA01649 - TGU - 070405 */
		SET_EXCHANGE(cashPos, ExtPos_InstrExchRate, exch);
	}
	else
	{
		SET_EXCHANGE(cashPos, ExtPos_InstrExchRate, 1.0);
	}

	SET_PRICE(cashPos, ExtPos_Price, price);
	SET_PRICE(cashPos, ExtPos_Quote, price);

	/* Quantity of cash is difference between accounting position and risk position (ZCN and basket) */
	qty = GET_NUMBER(totPosRisk, RiskAmt_PosMktValAmt);

	/* In position currency */
	amt = qty * price;
	SET_NUMBER(cashPos, ExtPos_Qty, CAST_NUMBER(qty)); /* REF3288 - SSO - 990205 */
	SET_AMOUNT(cashPos, ExtPos_PosGrossAmt, amt);
	SET_AMOUNT(cashPos, ExtPos_PosNetAmt, amt);

	/* PMSTA-33207 - RAK - 181009 - Regression - parameters added for fwd, here FALSE as we don't need it */
	/* Convert in instrument currency */
	FIN_RiskPosSetExtPosPosAmtTo(ExtPos_InstrNetAmt, posHierHead, cashPos, exchArgStp);

	/* Convert in reference currency */
	FIN_RiskPosSetExtPosPosAmtTo(ExtPos_RefNetAmt, posHierHead, cashPos, exchArgStp);

	/* Convert in system currency */
	FIN_RiskPosSetExtPosPosAmtTo(ExtPos_SysNetAmt, posHierHead, cashPos, exchArgStp);

	FIN_RiskPosLink(cashPos, origPos, GET_ID(STNPtr, A_Instr_Id));

	testCashInstr = DBA_SearchHierRecById(posHierHead, A_Instr, A_Instr_Id, GET_ID(cashInstr, A_Instr_Id));

	ret = FIN_AddValoRiskPos(posHierHead, domainArgPtr, aiArgPtr, origPos, cashPos,
							cashInstr, ((testCashInstr == NULL) ? (FLAG_T)FALSE : (FLAG_T)TRUE),
							totPosRisk, priceArgStp, status, (FIN_OPTINFO_STP)NULL, NULL, NULL, nullptr);

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_RiskSTNBondPos()
**
**  Description :   According to zeroCouponFlg, create a Zero Coupon Bond position or keep STN interest rate.
**				    According to capProtectionFlg, set to the quantity of the position of the notes or use capital protection %.
**				    Maturity set to the end_d of the notes, and then compute the theoretical price of the bond
**					as of the current_date.
**
**  Return      :   RET_SUCCEED or error code
**
** Creation	    :   PMSTA-32112 - RAK - 180820
**                  PMSTA-32504 - SIL - 181212
**
*************************************************************************/
STATIC RET_CODE FIN_RiskSTNBondPos(FLAG_T			   zeroCouponFlg,
								   FLAG_T			   capProtectionFlg,
								   DBA_HIER_HEAD_STP   posHierHead,
								   FIN_DOMAIN_ARG_STP  domainArgPtr,
								   FIN_AIARG_STP	   aiArgPtr,
								   FIN_EXCHARG_STP	   exchArgStp,
								   DBA_DYNFLD_STP      origPos,
								   DBA_DYNFLD_STP      instrPtr,
								   DBA_DYNFLD_STP      totPosRisk,
								   FIN_PRICEARG_STP    priceArgStp,
								   RISK_ANALYSIS_ENUM  status)
{
	RET_CODE			 ret;
	DBA_DYNFLD_STP		 STNBondPtr = NULL, riskPos = NULL, prPtr = nullptr;
	PRICE_T			 price=0.0, quote;
	ID_T                 priceCurrId=0;
	EXCHANGE_T           exch;
	AMOUNT_T             amt;
	NUMBER_T			 qty;

    /* PMSTA-32504 - SIL - 181212 */
    if (InstrumentNature::isBondsLinkedNotes(instrPtr))
    {
        zeroCouponFlg = FALSE;
        capProtectionFlg = FALSE;
    }

    /* PMSTA-37912 - Silpakal - 200109 */
    if ((InstrumentNature::isEquityLinkedNotes(instrPtr)) && (GET_FLAG(instrPtr, A_Instr_AccruedIntFlg) == TRUE))
    {
        zeroCouponFlg = FALSE;
    }

	/* theoretical zero coupon or interest paying bond, add it in hierarchy */
	if ((ret = FIN_CreateSTNBond(posHierHead, instrPtr, zeroCouponFlg, &STNBondPtr)) != RET_SUCCEED)
		return(ret);

	if ((riskPos = ALLOC_DYNST(ExtPos)) == NULL)
	{
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	if ((prPtr = ALLOC_DYNST(A_InstrPrice)) == NULL)
	{
		FREE_DYNST(riskPos, ExtPos);
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	COPY_DYNST(riskPos, origPos, ExtPos);

	/* Suppress extension identifier (copied from origin position) */
	SET_NULL_ID(riskPos, ExtPos_MainExtPosId);
	SET_NULL_ID(riskPos, ExtPos_AcctExtPosId);
	SET_NULL_ID(riskPos, ExtPos_AdjustExtPosId);
	SET_NULL_ID(riskPos, ExtPos_PosValId);

	SET_ID(riskPos, ExtPos_InstrId, GET_ID(STNBondPtr, A_Instr_Id));
	SET_ID(riskPos, ExtPos_InstrCurrId, GET_ID(STNBondPtr, A_Instr_RefCurrId));

	SET_ENUM(origPos, ExtPos_RiskNatEn, ExtPosRisk_NoRisk);
	SET_FLAG(riskPos, ExtPos_MainFlg, FALSE);

	/* PMSTA-35276 - Silpakal -190325 */
	if (InstrumentNature::isDiscountCertificates(STNBondPtr))
	{
        qty = GET_NUMBER(origPos, ExtPos_Qty);   /* PMSTA-36759 - Silpakal - 200106*/
	}
	else
	{
		if (capProtectionFlg == FALSE)
			qty = GET_NUMBER(origPos, ExtPos_Qty);
		else
			qty = GET_NUMBER(origPos, ExtPos_Qty) * GET_NUMBER(instrPtr, A_Instr_CapProtection);	 /* PMSTA-34870 - Silpakal - 190225 */
	}

	/* Theoretical price at begin date for ExtPos amounts */
	ret = FIN_PosPrice(riskPos, STNBondPtr, GET_DATETIME(riskPos, ExtPos_BegDate),
					   priceArgStp, prPtr, NULL, posHierHead);

	if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
	{
		FREE_DYNST(riskPos, ExtPos);
		FREE_DYNST(prPtr, A_InstrPrice);
		return(ret);
	}

	/* PMSTA-35276 - Silpakal -190325 */
	if (InstrumentNature::isDiscountCertificates(STNBondPtr))
	{
		price = GET_PRICE(prPtr, A_InstrPrice_Price) * 100;
	}
	else
	{
		price = GET_PRICE(prPtr, A_InstrPrice_Price);
	}

	priceCurrId = GET_ID(prPtr, A_InstrPrice_CurrId);

	FREE_DYNST(prPtr, A_InstrPrice);

	/* Convert price in position currency */
	FIN_GetExchRate(GET_DATETIME(riskPos, ExtPos_BegDate),
					priceCurrId, GET_ID(riskPos, ExtPos_PosCurrId),
					(ID_T)0, NULL, riskPos, exchArgStp, &exch);
	price *= exch;

	if (GET_ID(riskPos, ExtPos_RefCurrId) != GET_ID(riskPos, ExtPos_PosCurrId))
	{
		FIN_GetExchRate(GET_DATETIME(riskPos, ExtPos_BegDate),
			GET_ID(riskPos, ExtPos_PosCurrId),
			GET_ID(riskPos, ExtPos_RefCurrId),
			(ID_T)0, NULL, riskPos, exchArgStp, &exch);
		SET_EXCHANGE(riskPos, ExtPos_PosExchRate, exch);
	}
	else
	{
		SET_EXCHANGE(riskPos, ExtPos_PosExchRate, 1.0);
	}

	if (GET_ID(riskPos, ExtPos_RefCurrId) != GET_ID(riskPos, ExtPos_InstrCurrId))
	{
		FIN_GetExchRate(GET_DATETIME(riskPos, ExtPos_BegDate),
			GET_ID(riskPos, ExtPos_InstrCurrId),
			GET_ID(riskPos, ExtPos_RefCurrId),
			(ID_T)0, NULL, riskPos, exchArgStp, &exch);	/* PMSTA01649 - TGU - 070405 */
		SET_EXCHANGE(riskPos, ExtPos_InstrExchRate, exch);
	}
	else
	{
		SET_EXCHANGE(riskPos, ExtPos_InstrExchRate, 1.0);
	}

	FIN_PriceToQuote((PRICECALCRULE_ENUM)GET_ENUM(instrPtr, A_Instr_PriceCalcRuleEn),
					GET_ID(instrPtr, A_Instr_Id), instrPtr,
					GET_DATETIME(riskPos, ExtPos_BegDate), NULL,
					price, &quote, posHierHead);

	SET_PRICE(riskPos, ExtPos_Price, price);
	SET_PRICE(riskPos, ExtPos_Quote, quote);

	/* In position currency */
	amt = qty * price;

	SET_NUMBER(riskPos, ExtPos_Qty, CAST_NUMBER(qty)); /* REF3288 - SSO - 990205 */
	SET_AMOUNT(riskPos, ExtPos_PosNetAmt, amt);
	SET_AMOUNT(riskPos, ExtPos_PosGrossAmt, amt);

	/* PMSTA-33207 - RAK - 181009 - Regression - parameters added for fwd, here FALSE as we don't need it */
	/* Convert in instrument currency */
	FIN_RiskPosSetExtPosPosAmtTo(ExtPos_InstrNetAmt, posHierHead, riskPos, exchArgStp);

	/* Convert in reference currency */
	FIN_RiskPosSetExtPosPosAmtTo(ExtPos_RefNetAmt, posHierHead, riskPos, exchArgStp);

	/* Convert in system currency */
	FIN_RiskPosSetExtPosPosAmtTo(ExtPos_SysNetAmt, posHierHead, riskPos, exchArgStp);

	FIN_RiskPosLink(riskPos, origPos, GET_ID(instrPtr, A_Instr_Id));

	/* With theoretical price at valorisation date and update totPosRisk to know the final cash position value */
	ret = FIN_AddValoRiskPos(posHierHead, domainArgPtr, aiArgPtr, origPos, riskPos,
		                     STNBondPtr, TRUE /* PMSTA-32503 - RAK - 181113 - already in hier */,
							 totPosRisk, priceArgStp, status, (FIN_OPTINFO_STP)NULL,
							 NULL, NULL, nullptr);

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_CreateSTNBond()
**
**  Description :
**
**  Return      :   RET_SUCCEED or error code
**
** Creation	    :   PMSTA-32112 - RAK - 180820
**                  PMSTA-32504 - SIL - 181212
**
*************************************************************************/
STATIC RET_CODE FIN_CreateSTNBond(DBA_HIER_HEAD_STP   hierHead,
								  DBA_DYNFLD_STP      instrPtr,
								  FLAG_T			  zeroCouponFlg,
								  DBA_DYNFLD_STP      *STNBondPtr)
{
	RET_CODE	ret=RET_SUCCEED;

	if ((*STNBondPtr = ALLOC_DYNST(A_Instr)) == NULL)
	{
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	COPY_DYNST((*STNBondPtr), instrPtr, A_Instr);

	SET_NULL_ID((*STNBondPtr), A_Instr_Id);	/* negativ identifier */
	SET_ID((*STNBondPtr), A_Instr_ParentInstrId, GET_ID(instrPtr, A_Instr_Id));

	SET_ENUM((*STNBondPtr), A_Instr_ValRuleEn, (ENUM_T)ValRule_Theo);
	SET_ENUM((*STNBondPtr), A_Instr_UnderlyCatEn, static_cast<INSTR_UNDERLYING_CATEGORY_ENUM> (None));
	SET_FLAG((*STNBondPtr), A_Instr_GenericFlg, FALSE);

	if (zeroCouponFlg == TRUE) /* Zero coupon Bond */
	{
		SET_FLAG((*STNBondPtr), A_Instr_AccruedIntFlg, FALSE);
		SET_NULL_PERCENT((*STNBondPtr), A_Instr_InterestRateP);
	}
    else  /*Interest Rate Bond*/
    {
        SET_FLAG((*STNBondPtr), A_Instr_AccruedIntFlg, TRUE);
        SET_PERCENT((*STNBondPtr), A_Instr_InterestRateP, GET_PERCENT(instrPtr, A_Instr_InterestRateP));
    }

	/* PMSTA-32503 - RAK - 181113 - Add in hierarchy  */
	if ((ret = DBA_AddHierRecord(hierHead, (*STNBondPtr), A_Instr,
			                     TRUE, HierAddRec_NoLnk)) != RET_SUCCEED)
	{
		FREE_DYNST(*STNBondPtr, A_Instr);
		return(ret);
	}

    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_RiskSTNBasketPos()
**
**  Description :   We would be showing the underlying position directly and they can either be a single instrument
**                  or a basket of instruments.The type of underlying would be specified as either :
**                  Single Instrument
**                  Average Basket(the weights in the basket are used)
**                  Worst - of Basket(the worst performing underlying instrument is identified).
**					In case of Delta exposure, multiply quantity by delta.
**
**  Return      :   RET_SUCCEED or error code
**
** Creation	    :   PMSTA-32112 - RAK - 180820
**					PMSTA-32504 - SIL - 181211  - Added subnatures, which are used sys param RISK_STN_COST_RULE for Cost Price calculation
**					PMSTA-34870 - Silpakal - 190225 - Quantity logic change in Airbag, Bonus and TwinWin
**
*************************************************************************/
STATIC RET_CODE FIN_RiskSTNBasketPos(DBA_HIER_HEAD_STP   posHierHead,
									FIN_DOMAIN_ARG_STP   domainArgPtr,
									FIN_AIARG_STP	     aiArgPtr,
									FIN_EXCHARG_STP	     exchArgStp,
									DBA_DYNFLD_STP       origPos,
									DBA_DYNFLD_STP       STNPtr,
									DBA_DYNFLD_STP       totPosRisk,
									FIN_PRICEARG_STP     priceArgStp,
									RISK_QTY_STP		 riskQtyStp,	/* PMSTA-34140 - RAK - 190122 - Could be sent to FIN_RiskSTNBasketPos */
									RISK_ANALYSIS_ENUM   status)
{
	RISKCOSTRULE_ENUM		stnCostRule;
	RET_CODE				ret = RET_SUCCEED;
	DBA_DYNFLD_STP			riskPos = nullptr, underPtr = nullptr, prPtr = nullptr, mktPricePtr = nullptr, *selInstrCompoTab = nullptr;
    ID_T					costPriceCurrId = ZERO_ID;
    PRICE_T					quote, costPrice = 0.0,oldCostPrice = 0.0;
    NUMBER_T				qty = 0.0, delta = 1.0, exch, amt;
	int						i, selInstrCompoNbr = 0,j, optionClassCnt = 1;  /* PMSTA-34870 - Silpakal - 190225 */
	FLAG_T					hierFlg, isWorstUnderFlg=FALSE, optionClassFlg = FALSE;  /* PMSTA-34870 - Silpakal - 190225 */
	NUMBER_T				financialVroum = 0.0;
	int						worstInstrNbr = 0;  /*PMSTA-35265 - Silpakala - 190626*/

	MemoryPool  mp;

	InstrumentSTNComputation computation(posHierHead, origPos, STNPtr, domainArgPtr->fromDateTime);

	/* Price is underlying price at begin date of the position */
	/* or exercise price of the option founded in term event   */
	GEN_GetApplInfo(ApplRiskStnCostRule, &stnCostRule);

	/* Single instrument -> fill a InstrCompo with instrument information */
	/* Worst, average, read InstrCompo */
	mktPricePtr = mp.allocDynst(FILEINFO, A_InstrPrice);

	/* PMSTA-32503 - RAK - 190205 */
	ret = FIN_SelectUnderlyingCompo(posHierHead, domainArgPtr->fromDateTime, STNPtr, &selInstrCompoTab, &selInstrCompoNbr);

	if (ret == RET_SUCCEED)
	{
		mp.owner(selInstrCompoTab, selInstrCompoNbr);

		/* PMSTA-32503 - RAK - 190205 */
		if ((INSTR_UNDERLYING_CATEGORY_ENUM)GET_ENUM(STNPtr, A_Instr_UnderlyCatEn) == INSTR_UNDERLYING_CATEGORY_ENUM::WorstOfBasket)
		{
			ret = computation.computeInstrumentPriceUnderlyingCategory();

			/*PMSTA-35265 - Silpakala - 190626*/
			FIN_WorstInstrumentsFromSTN(&selInstrCompoTab, &selInstrCompoNbr, computation.getInstrumentSTNComputationResult(), &worstInstrNbr);
		}

		if (domainArgPtr->optDeltaRule == OptDelta_Delta)
		{
			DBA_DYNFLD_STP instrChrono = mp.allocDynst(FILEINFO, A_InstrChrono);
			DBA_DYNFLD_STP dimChronoPtr = mp.allocDynst(FILEINFO, Dim_InstrChrono);

			SET_ID(dimChronoPtr,       Dim_InstrChrono_InstrId,    GET_ID(STNPtr, A_Instr_Id));
			SET_DATETIME(dimChronoPtr, Dim_InstrChrono_RefDate,    domainArgPtr->fromDateTime);
			SET_ENUM(dimChronoPtr,     Dim_InstrChrono_NatEn,      ChronoNat_Delta);
			SET_FLAG(dimChronoPtr,     Dim_InstrChrono_ComputeFlg, FALSE);

			if (FIN_InstrChrono(dimChronoPtr, STNPtr, instrChrono, posHierHead) == RET_SUCCEED)
			{
				delta = GET_LONGAMOUNT(instrChrono, A_InstrChrono_Val);
			}
		}

		/* PMSTA-32503 - RAK - 190205 - Could have several worst (with same price) */
		/* received an array from FIN_WorstOfBasket */
		/* price received by FIN_Worst ? */
		prPtr = mp.allocDynst(FILEINFO, A_InstrPrice);

		/* PMSTA-34870 - Silpakal - 190225 */
		if (InstrumentNature::isAirBagCertificates(STNPtr) ||
			InstrumentNature::isTwinWinCertificates(STNPtr) ||
			InstrumentNature::isBonusNotes(STNPtr))
		{
			optionClassCnt = 2;  /* Call and Put */
		}

		/* PMSTA-35081 - RAK - 190606 */
		DBA_DYNFLD_STP turboEvtPtr = mp.allocDynst(FILEINFO, A_TermEvt);
		DBA_DYNFLD_STP getData = mp.allocDynst(FILEINFO, Evt_Arg);
		NUMBER_T	   savedMax = 0.0;
		bool		   savedMaxNull = false;
		DbiConnectionHelper dbiConnHelper;

		if (InstrumentNature::isMiniFuturesTurbo(STNPtr))
		{
			if (GET_ID(STNPtr, A_Instr_Id) < 0)
			{
				SET_ID(getData, Evt_Arg_InstrId, GET_ID(STNPtr, A_Instr_ParentInstrId));
			}
			else
			{
				SET_ID(getData, Evt_Arg_InstrId, GET_ID(STNPtr, A_Instr_Id));
			}
			SET_DATE(getData, Evt_Arg_ValidDate, domainArgPtr->fromDateTime.date);

			if ((ret = dbiConnHelper.dbaGet(TermEvt, UNUSED, getData, &turboEvtPtr)) != RET_SUCCEED)
			{
				return(ret);
			}

			if (!IS_NULLFLD(turboEvtPtr, A_TermEvt_MaxValue))
				savedMax = GET_NUMBER(turboEvtPtr, A_TermEvt_MaxValue);
			else
				savedMaxNull = true;
		}

		for (i = 0; i < selInstrCompoNbr; i++) /* 1 in case of Single Instrument */
		{
			isWorstUnderFlg = FALSE; /* PMSTA-34985 - RAK - 070319 - reinit */
			ret = FIN_GetHierInstr(posHierHead, GET_ID(selInstrCompoTab[i], A_InstrCompo_InstrId), (char*)&hierFlg, &underPtr);
			if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
			{
				return(ret);
			}

			for (j = 0; j < optionClassCnt; j++)  /*Long or Call *//* PMSTA-34870 - Silpakal - 190225  */
			{
				if ((riskPos = ALLOC_DYNST(ExtPos)) == nullptr)
				{
					MSG_RETURN(RET_MEM_ERR_ALLOC);
				}

				COPY_DYNST(riskPos, origPos, ExtPos);

				/* A risk position parent can't be risk */
				SET_ENUM(origPos, ExtPos_RiskNatEn, ExtPosRisk_NoRisk);

				/* REF7661 - YST - 020725 - risk position can't be main position */
				SET_FLAG(riskPos, ExtPos_MainFlg, FALSE);

				/* Suppress extension identifier (copied from origin position) */
				SET_NULL_ID(riskPos, ExtPos_MainExtPosId);
				SET_NULL_ID(riskPos, ExtPos_AcctExtPosId);
				SET_NULL_ID(riskPos, ExtPos_AdjustExtPosId);
				SET_NULL_ID(riskPos, ExtPos_PosValId);

				SET_ID(riskPos, ExtPos_InstrId, GET_ID(underPtr, A_Instr_Id));
				SET_ID(riskPos, ExtPos_InstrCurrId, GET_ID(underPtr, A_Instr_RefCurrId));

				/* **** COST PRICE **** */
				/* Price is underlying price at begin date of the position */
				/* or basket exercise price of the STN    */
				if (InstrumentNature::isEquityLinkedNotes(STNPtr) ||
					InstrumentNature::isBondsLinkedNotes(STNPtr) ||
					InstrumentNature::isCapProtectNotes(STNPtr) ||
					InstrumentNature::isReverseConvertible(STNPtr) ||
					InstrumentNature::isReverseConvertibleELN(STNPtr) ||
					InstrumentNature::isReverseConvertibleBLN(STNPtr) ||					
					InstrumentNature::isMiniFuturesTurbo(STNPtr) ||
					InstrumentNature::isCapProtectNotesWCoupon(STNPtr) ||
					InstrumentNature::isMemoryCoupons(STNPtr) ||
					InstrumentNature::isAirBagCertificates(STNPtr) ||
					InstrumentNature::isTwinWinCertificates(STNPtr) ||
					InstrumentNature::isBonusNotes(STNPtr))
				{
					switch (stnCostRule)
					{
					case RiskCostRule_ClosingPrice:
					{
						/* A_Instr_UnderlyFixingPrice in case of Single Instrument */
						costPrice = GET_PRICE(selInstrCompoTab[i], A_InstrCompo_BasketFixingPrice);
						costPriceCurrId = GET_ID(underPtr, A_Instr_RefCurrId); /* or underlying instrument ref currency */
						break;
					}
					case RiskCostRule_ExercisePrice:
					default:
					{
						/* A_Instr_ExerQuote in case of Single Instrument */
						costPrice = GET_PRICE(selInstrCompoTab[i], A_InstrCompo_BasketExerPrice);
						costPriceCurrId = GET_ID(underPtr, A_Instr_RefCurrId); /* or underlying instrument ref currency */
						break;
					}
					}
				}
                
                /* PMSTA-37912 - Silpakal - 200102 */
                if (InstrumentNature::isReverseConvertibleCLN(STNPtr))
                {
                    costPrice = GET_PRICE(riskPos, ExtPos_Price);
                    costPriceCurrId = GET_ID(riskPos, ExtPos_RefCurrId); 
                }

				if (InstrumentNature::isDiscountCertificates(STNPtr))
				{
					/*A_Instr_ExerQuote in case of Single Instrument */
					costPrice = GET_PRICE(selInstrCompoTab[i], A_InstrCompo_BasketExerPrice);
					costPriceCurrId = GET_ID(underPtr, A_Instr_RefCurrId); /* or underlying instrument ref currency */
				}

				/* PMSTA-35081 - RAK - 190606 - New computation */
				if (InstrumentNature::isMiniFuturesTurbo(STNPtr))
				{
					double turboPrice;

					financialVroum = costPrice;

					/* First calculate the financing level of the instrument : exercicequote  - (exercicequote/leverage) */
					if (!IS_NULLFLD(turboEvtPtr, A_TermEvt_Leverage) &&
						CMP_NUMBER(GET_NUMBER(turboEvtPtr, A_TermEvt_Leverage), 0.0) != 0)
						financialVroum = costPrice - (costPrice / GET_NUMBER(turboEvtPtr, A_TermEvt_Leverage));

					/* Then compute Mini Future Price */
					turboPrice = costPrice - financialVroum;
					costPrice = turboPrice;

					/* to do market price = market price - vroum : keep financial level of instrument in termEvt */
					SET_NUMBER(turboEvtPtr, A_TermEvt_MaxValue, financialVroum);

					/* changed for each instrument composition */
					if ((INSTR_UNDERLYING_CATEGORY_ENUM)GET_ENUM(STNPtr, A_Instr_UnderlyCatEn) != INSTR_UNDERLYING_CATEGORY_ENUM::SingleInstrument)
					{
						SET_NUMBER(turboEvtPtr, A_TermEvt_Barrier, GET_NUMBER(selInstrCompoTab[i], A_InstrCompo_BasketBarrier));
					}
				}

				/* Convert price in position currency */
				FIN_GetExchRate(GET_DATETIME(riskPos, ExtPos_BegDate),
					costPriceCurrId, GET_ID(riskPos, ExtPos_PosCurrId),
					(ID_T)0, NULL, riskPos, exchArgStp, &exch);	/* PMSTA01649 - TGU - 070405 */
				costPrice *= exch;

				if (GET_ID(riskPos, ExtPos_RefCurrId) != GET_ID(riskPos, ExtPos_PosCurrId))
				{
					FIN_GetExchRate(GET_DATETIME(riskPos, ExtPos_BegDate),
						GET_ID(riskPos, ExtPos_PosCurrId),
						GET_ID(riskPos, ExtPos_RefCurrId),
						(ID_T)0, NULL, riskPos, exchArgStp, &exch);	/* PMSTA01649 - TGU - 070405 */
					SET_EXCHANGE(riskPos, ExtPos_PosExchRate, exch);
				}
				else
				{
					SET_EXCHANGE(riskPos, ExtPos_PosExchRate, 1.0);
				}

				if (GET_ID(riskPos, ExtPos_RefCurrId) != GET_ID(riskPos, ExtPos_InstrCurrId))
				{
					FIN_GetExchRate(GET_DATETIME(riskPos, ExtPos_BegDate),
						GET_ID(riskPos, ExtPos_InstrCurrId),
						GET_ID(riskPos, ExtPos_RefCurrId),
						(ID_T)0, NULL, riskPos, exchArgStp, &exch);	/* PMSTA01649 - TGU - 070405 */
					SET_EXCHANGE(riskPos, ExtPos_InstrExchRate, exch);
				}
				else
				{
					SET_EXCHANGE(riskPos, ExtPos_InstrExchRate, 1.0);
				}

				/* **** QUANTITY **** */
				/* strike price */
				/* in case of currencies origPos and underlying are different -> use reference exchange */
				/* PMSTA-34870 - Silpakal - 190225 */
				if (InstrumentNature::isEquityLinkedNotes(STNPtr) ||
					InstrumentNature::isBondsLinkedNotes(STNPtr) ||
					InstrumentNature::isCapProtectNotes(STNPtr) ||
					InstrumentNature::isReverseConvertible(STNPtr) ||
					InstrumentNature::isReverseConvertibleELN(STNPtr) ||
					InstrumentNature::isReverseConvertibleBLN(STNPtr) ||										
					InstrumentNature::isCapProtectNotesWCoupon(STNPtr) ||
					InstrumentNature::isMemoryCoupons(STNPtr) ||
                    InstrumentNature::isDiscountCertificates(STNPtr))   /* PMSTA-36759 - Silpakal - 200106 */
				{
					qty = GET_NUMBER(origPos, ExtPos_RefNetAmt) / costPrice;          /* PMSTA-38541 - Akash - 26052021 */   /* PMSTA-42110 - Akash - 01072021 */
				}

                /* PMSTA-37912 - Silpakal - 200102 */
                if (InstrumentNature::isReverseConvertibleCLN(STNPtr))
                {
                    qty = GET_NUMBER(origPos, ExtPos_Qty);
                }

				/* PMSTA-35081 - RAK - 190606 - PoetPoet simple qty */
				if (InstrumentNature::isMiniFuturesTurbo(STNPtr))
				{
					/* Karthik : Yes, the basket weight I had filled in was based on the weights of the individual */
					/* instruments in the composition table�in our case, it is like 25000 each�so making it equal weights of 50 % ... */
					/* As discussed, we will use the quantity from the composition for Average basket along */
					/* (as logically the contract size would be part of this). */
					const INSTR_UNDERLYING_CATEGORY_ENUM instrUnderlyingCategory = static_cast<INSTR_UNDERLYING_CATEGORY_ENUM>(GET_ENUM(STNPtr, A_Instr_UnderlyCatEn));
					if (instrUnderlyingCategory == INSTR_UNDERLYING_CATEGORY_ENUM::SingleInstrument ||
						instrUnderlyingCategory == INSTR_UNDERLYING_CATEGORY_ENUM::WorstOfBasket)
						qty = GET_NUMBER(origPos, ExtPos_Qty);
					else
						qty = GET_NUMBER(selInstrCompoTab[i], A_InstrCompo_Quantity);
				}
		
				/* PMSTA-34870 - Silpakal - 190225 */
				if (InstrumentNature::isBonusNotes(STNPtr))
				{
					PRICE_T bonusPrice = 0;
					if (optionClassFlg == FALSE)
					{
						SET_ENUM(STNPtr, A_Instr_OptionClassEn, OptClass_Call); /* Long Call */
                        qty = GET_NUMBER(origPos, ExtPos_RefNetAmt) / costPrice * GET_EXCHANGE(riskPos, ExtPos_InstrExchRate); /* PMSTA-35276 - Silpakal -190325 */ /* PMSTA-36759 - Silpakal - 200106 */  /* PMSTA-42110 - Akash - 01072021 */
						optionClassFlg = TRUE;
					}
					else
					{
						SET_ENUM(STNPtr, A_Instr_OptionClassEn, OptClass_Put); /* Long Put */
						bonusPrice = costPrice * GET_NUMBER(STNPtr, A_Instr_BonusLevel);
                        qty = -1 * (GET_NUMBER(origPos, ExtPos_RefNetAmt) / bonusPrice);  /* PMSTA-35276 - Silpakal -190325 */ /* PMSTA-36759 - Silpakal - 200106 */  /* PMSTA-42110 - Akash - 01072021 */
						optionClassFlg = FALSE;
						hierFlg = TRUE;  /* Flag set to true, as the instrument is already exist in the hierarchy */
					}
				}

				if (InstrumentNature::isAirBagCertificates(STNPtr))
				{
					PRICE_T airbagPrice = 0;
					if (optionClassFlg == FALSE)
					{
						SET_ENUM(STNPtr, A_Instr_OptionClassEn, OptClass_Call); /* Long Call */
						qty = GET_NUMBER(origPos, ExtPos_RefNetAmt) / costPrice * GET_EXCHANGE(riskPos, ExtPos_InstrExchRate);     /* PMSTA-42110 - Akash - 01072021 */
						optionClassFlg = TRUE;
					}
					else
					{
						SET_ENUM(STNPtr, A_Instr_OptionClassEn, OptClass_Put); /* Short Put */
						airbagPrice = costPrice * (GET_PERCENT(selInstrCompoTab[i], A_InstrCompo_BasketBarrierP) / 100);
						if (airbagPrice != 0)
						{
							qty = GET_NUMBER(origPos, ExtPos_RefNetAmt) / airbagPrice;         /* PMSTA-42110 - Akash - 01072021 */
						}
						else
						{
							qty = 0.0;
						}
						optionClassFlg = FALSE;
						hierFlg = TRUE;  /* Flag set to true, as the instrument is already exist in the hierarchy */
					}
				}

				if (InstrumentNature::isTwinWinCertificates(STNPtr))
				{
					PRICE_T partPrice = 0;
					if (optionClassFlg == FALSE)
					{
						SET_ENUM(STNPtr, A_Instr_OptionClassEn, OptClass_Call); /* Long Call */
						qty = GET_NUMBER(origPos, ExtPos_RefNetAmt) / costPrice * GET_EXCHANGE(riskPos, ExtPos_InstrExchRate);   /* PMSTA-42110 - Akash - 01072021 */
						optionClassFlg = TRUE;
					}
					else
					{
						SET_ENUM(STNPtr, A_Instr_OptionClassEn, OptClass_Put); /* Long Put */

						/* compute current price */
						ret = FIN_PosPrice(riskPos, underPtr, GET_DATETIME(riskPos, ExtPos_ExtPosDate),
							priceArgStp, mktPricePtr,
							NULL, posHierHead);

						PRICE_T price = GET_PRICE(mktPricePtr, A_InstrPrice_Price);

						if (CMP_NUMBER(price, costPrice) >= 0)
						{
							price = costPrice;
						}
						else
						{
							/* Participation price = Cost price + downside participation level * (cost price - current market price) */
							partPrice = costPrice + GET_NUMBER(STNPtr, A_Instr_ParticipationLevDown) * ((costPrice)-GET_PRICE(mktPricePtr, A_InstrPrice_Price));
							price = partPrice;
						}
						qty = -1 * (GET_NUMBER(origPos, ExtPos_RefNetAmt) / price);    /* PMSTA-42110 - Akash - 01072021 */
						optionClassFlg = FALSE;
						hierFlg = TRUE;  /* Flag set to true, as the instrument is already exist in the hierarchy */
					}
				}

				/* PMSTA-35081 - RAK - 190606 */
				/* not necessary, position qty is negativ if (InstrumentNature::isMiniFuturesTurbo(STNPtr) &&
					(TermEvt_Payoff_Short == static_cast<TERMEVT_PAYOFF_ENUM>GET_ENUM(turboEvtPtr, A_TermEvt_PayOffNatEn)))
					qty = qty * -1; */

				/* PMSTA-32503 - RAK - 190205 - Call to FIN_InstrumentSTNIsWorstFlg */
				/* In case of worst, don't set price of others underlying */
				if ((INSTR_UNDERLYING_CATEGORY_ENUM)GET_ENUM(STNPtr, A_Instr_UnderlyCatEn) != INSTR_UNDERLYING_CATEGORY_ENUM::WorstOfBasket ||
					FIN_InstrumentSTNIsWorstFlg(GET_ID(selInstrCompoTab[i], A_InstrCompo_InstrId), computation.getInstrumentSTNComputationResult()))
				{
					isWorstUnderFlg = TRUE; /* PMSTA-34862 - RAK - GitDM Keep it */
					FIN_PriceToQuote((PRICECALCRULE_ENUM)GET_ENUM(STNPtr, A_Instr_PriceCalcRuleEn),
						GET_ID(STNPtr, A_Instr_Id), STNPtr,
						GET_DATETIME(riskPos, ExtPos_BegDate), NULL,
						costPrice, &quote, posHierHead);

					SET_PRICE(riskPos, ExtPos_Price, costPrice);
					SET_PRICE(riskPos, ExtPos_Quote, quote);
				}
				else
				{
					SET_PRICE(riskPos, ExtPos_Price, 0.0);
					SET_PRICE(riskPos, ExtPos_Quote, 0.0);
				}

				/* PMSTA-35081 - RAK - 190606 - PoetPoet simple qty */
				/* Karthik : Yes, the basket weight I had filled in was based on the weights of the individual */
				/* instruments in the composition table�in our case, it is like 25000 each�so making it equal weights of 50 % ... */
			    /* As discussed, we will use the quantity from the composition for Average basket along */
				/* (as logically the contract size would be part of this). */
				if (!(InstrumentNature::isMiniFuturesTurbo(STNPtr)))
				{
					/* PMSTA-35081 - RAK - 190606 - anyway we talked aboout MiniFuturesTurbo keep same logical for others */
					/* Don't apply percentage in case of worst, in case of single, percentage is 1.0 */
					if ((INSTR_UNDERLYING_CATEGORY_ENUM)GET_ENUM(STNPtr, A_Instr_UnderlyCatEn) != INSTR_UNDERLYING_CATEGORY_ENUM::WorstOfBasket)
						qty = qty * (GET_NUMBER(selInstrCompoTab[i], A_InstrCompo_BasketWeightP) / 100);  /*PMSTA-34836 - Silpakala - 190221*/
					else   /*PMSTA-35265 - Silpakala - 190626*/
					{
						if (((INSTR_UNDERLYING_CATEGORY_ENUM)GET_ENUM(STNPtr, A_Instr_UnderlyCatEn) == INSTR_UNDERLYING_CATEGORY_ENUM::WorstOfBasket) &&
							(FIN_InstrumentSTNIsWorstFlg(GET_ID(selInstrCompoTab[i], A_InstrCompo_InstrId), computation.getInstrumentSTNComputationResult())) &&
							(worstInstrNbr > 0 ))
						{
							qty = qty/worstInstrNbr;
						}
					}
				}

				if (domainArgPtr->optDeltaRule == OptDelta_Delta)
					qty *= delta;	/* chrono data */

				SET_NUMBER(riskPos, ExtPos_Qty, CAST_NUMBER(qty));

				/* Store the extracted costPrice value from Sys Param into new variable for the position price calculation */
				oldCostPrice = costPrice;

				/* PMSTA-32503 - RAK - 190205 - Call to FIN_InstrumentSTNIsWorstFlg */
				if ((INSTR_UNDERLYING_CATEGORY_ENUM)GET_ENUM(STNPtr, A_Instr_UnderlyCatEn) != INSTR_UNDERLYING_CATEGORY_ENUM::WorstOfBasket ||
					isWorstUnderFlg == TRUE)
				{
					amt = qty * costPrice;

					SET_AMOUNT(riskPos, ExtPos_PosGrossAmt, amt);
					SET_AMOUNT(riskPos, ExtPos_PosNetAmt, amt);

					/* Convert in instrument currency */
					FIN_RiskPosSetExtPosPosAmtTo(ExtPos_InstrNetAmt, posHierHead, riskPos, exchArgStp);

					/* Convert in reference currency */
					FIN_RiskPosSetExtPosPosAmtTo(ExtPos_RefNetAmt, posHierHead, riskPos, exchArgStp);

					/* Convert in system currency */
					FIN_RiskPosSetExtPosPosAmtTo(ExtPos_SysNetAmt, posHierHead, riskPos, exchArgStp);

					/* PMSTA-34140 - RAK - 190122 - Add riskQtyStp for STN computation */
					ret = FIN_RiskSonPriceAmt(posHierHead, domainArgPtr, origPos, riskPos, underPtr, totPosRisk, priceArgStp, status, &costPrice, riskQtyStp, TRUE);
				}
				else
				{
					int posBpAmtFld = 0;

					SET_AMOUNT(riskPos, ExtPos_PosGrossAmt, 0.0);
					SET_AMOUNT(riskPos, ExtPos_PosNetAmt, 0.0);
					SET_AMOUNT(riskPos, ExtPos_InstrGrossAmt, 0.0);
					SET_AMOUNT(riskPos, ExtPos_InstrNetAmt, 0.0);
					SET_AMOUNT(riskPos, ExtPos_RefGrossAmt, 0.0);
					SET_AMOUNT(riskPos, ExtPos_RefNetAmt, 0.0);
					SET_AMOUNT(riskPos, ExtPos_SysGrossAmt, 0.0);
					SET_AMOUNT(riskPos, ExtPos_SysNetAmt, 0.0);

					for (posBpAmtFld = ExtPos_Bp1PosAmt;
						posBpAmtFld < (ExtPos_Bp1PosAmt + ExtPos_BpPosAmtNb);
						posBpAmtFld++)
					{
						SET_AMOUNT(riskPos, posBpAmtFld, 0.0);
					}
				}

				FIN_RiskPosLink(riskPos, origPos, GET_ID(origPos, ExtPos_InstrId));

				if ((INSTR_UNDERLYING_CATEGORY_ENUM)GET_ENUM(STNPtr, A_Instr_UnderlyCatEn) != INSTR_UNDERLYING_CATEGORY_ENUM::WorstOfBasket ||
					isWorstUnderFlg == TRUE)
				{
					PRICE_T newCostPrice = oldCostPrice;  /* PMSTA-34870 - Silpakal - 190225 */
					ret = FIN_STNBasketMarketPrice(posHierHead, STNPtr, riskPos, origPos, underPtr, selInstrCompoTab[i], &oldCostPrice,
						                           priceArgStp, mktPricePtr, domainArgPtr, exchArgStp, turboEvtPtr, &newCostPrice);

					if (ret == RET_SUCCEED)
					{
						if (CMP_NUMBER(newCostPrice, oldCostPrice) != 0)
							SET_PRICE(riskPos, ExtPos_Price, newCostPrice);

						ret = FIN_AddValoRiskPos(posHierHead, domainArgPtr, aiArgPtr, origPos, riskPos, underPtr,
							hierFlg, totPosRisk, priceArgStp, status, (FIN_OPTINFO_STP)NULL, NULL, mktPricePtr, nullptr);
					}
				}
				else
				{
					/* ADD VALORISATION EXTENSION ***/
					ret = FIN_UpdRiskPosHier(posHierHead, domainArgPtr, riskPos, underPtr, hierFlg);
					if (ret == RET_SUCCEED)
					{
						/* PMSTA-32503 - RAK - 190205 - 0 in mkt val */
						if ((ret = FIN_PosExtValo(posHierHead, riskPos)) == RET_SUCCEED)
						{
							DBA_DYNFLD_STP posValPtr = nullptr;

							if (GET_EXTENSION_PTR(riskPos, ExtPos_PosVal_Ext) != NULL &&
								(posValPtr = *(GET_EXTENSION_PTR(riskPos, ExtPos_PosVal_Ext))) != NULLDYNST)
							{
								SET_PRICE(posValPtr, PosVal_Quote, 0.0);
								SET_PRICE(posValPtr, PosVal_Price, 0.0);
								SET_AMOUNT(posValPtr, PosVal_PosMktValAmt, 0.0);
								SET_AMOUNT(posValPtr, PosVal_PosAccrInterAmt, 0.0);
								SET_AMOUNT(posValPtr, PosVal_PosNetAmt, 0.0);
								SET_AMOUNT(posValPtr, PosVal_RefMktValAmt, 0.0);
								SET_AMOUNT(posValPtr, PosVal_RefAccrInterAmt, 0.0);
								SET_AMOUNT(posValPtr, PosVal_RefNetAmt, 0.0);
								SET_AMOUNT(posValPtr, PosVal_InstrMktValAmt, 0.0);
								SET_AMOUNT(posValPtr, PosVal_InstrAccrInterAmt, 0.0);
								SET_AMOUNT(posValPtr, PosVal_InstrNetAmt, 0.0);
								/* FIELD_IDX_T PosVal_PriceExchRate = 28;
								FIELD_IDX_T PosVal_PosExchRate = 29;
								FIELD_IDX_T PosVal_InstrExchRate = 30; */
							}

						}
					}
				}
			}
		}

		/* PMSTA-35081 - RAK - 190606 */
		if (InstrumentNature::isMiniFuturesTurbo(STNPtr))
		{
			if (savedMaxNull == true)
			{
				SET_NULL_NUMBER(turboEvtPtr, A_TermEvt_MaxValue);
			}
			else
			{
				SET_NUMBER(turboEvtPtr, A_TermEvt_MaxValue, savedMax);
			}
		}
	}

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_STNBasketMarketPrice()
**
**  Description :   Compute market price of basket position
**					Min(current market price, cap price, participation price) where
**					Cap price** = Cost price * Cap levels
**					participation price*** = Cost price + participation level * (current market price ? cost price)
**
**  Return      :   RET_SUCCEED or error code
**
** Creation	    :   PMSTA-32112 - RAK - 180820
**		`			PMSTA-32504 - SIL - 181211  - Market price calculation for all the subnatures,
**                                                barrierknock in date for BLN & Barrier Discount Certificates
**                  PMSTA-32504 - SIL - 190124  - Calculate the Cost, Market, Barrier, Airbag and Bonus for Average Baskets
**					PMSTA-34836 - Silpakal - 190221 - Add rebate logic for ELN and corrections for knock-in in other notes
**					PMSTA-34870 - Silpakal - 190225 - Quantity logic change in Airbag, Bonus and TwinWin
**
*************************************************************************/
STATIC RET_CODE FIN_STNBasketMarketPrice(DBA_HIER_HEAD_STP     posHierHead,
                                         DBA_DYNFLD_STP        STNPtr,
                                         DBA_DYNFLD_STP        riskPos,
                                         DBA_DYNFLD_STP        origPos,
                                         DBA_DYNFLD_STP        underPtr,
                                         DBA_DYNFLD_STP        instrCompoPtr,
                                         PRICE_T               *costPrice,
                                         FIN_PRICEARG_STP      priceArgStp,
                                         DBA_DYNFLD_STP        mktPricePtr,
                                         FIN_DOMAIN_ARG_STP    domainArgPtr,
                                         FIN_EXCHARG_STP       exchArgStp,
                                         DBA_DYNFLD_STP        turboEvtPtr,
                                         PRICE_T               *newCostPrice
                                        )
{
	RET_CODE	ret = RET_SUCCEED;
	PRICE_T price = 0, quote = 0;
	FLAG_T	changePriceFlg = FALSE;

    /* compute current price */
	ret = FIN_PosPrice(riskPos, underPtr, GET_DATETIME(riskPos, ExtPos_ExtPosDate),
						priceArgStp, mktPricePtr,
						NULL, posHierHead);

	price = GET_PRICE(mktPricePtr, A_InstrPrice_Price);

	if (InstrumentNature::isEquityLinkedNotes(STNPtr) ||
		InstrumentNature::isCapProtectNotes(STNPtr) ||
		InstrumentNature::isCapProtectNotesWCoupon(STNPtr))
	{
		PRICE_T capPrice = 0, partPrice = 0;

		/*PMSTA-34836 - Silpakala - 190221*/
		if ((!IS_NULLFLD(STNPtr, A_Instr_KnockOutDate)) &&
			DATE_Cmp(GET_DATETIME(riskPos, ExtPos_ExtPosDate).date, GET_DATE(STNPtr, A_Instr_KnockOutDate)) >= 0)
		{
			PRICE_T rebatePrice = 0;
			/* PMSTA-35276 - Silpakal -190325 */
			if (IS_NULLFLD(STNPtr, A_Instr_RebatePayoff))
			{
				price = 0;
				*newCostPrice = 0;
				changePriceFlg = TRUE;
			}
			else
			{
				rebatePrice = (*costPrice) * GET_NUMBER(STNPtr, A_Instr_RebatePayoff);
				price = rebatePrice;
				changePriceFlg = TRUE;
			}
		}
        else  
		{
			/* Cap price = Cost price * Cap levels */
			if (!IS_NULLFLD(STNPtr, A_Instr_CapLevel))
				capPrice = (*costPrice) * GET_NUMBER(STNPtr, A_Instr_CapLevel);

			/* Participation price = Cost price + participation level * (current market price ? cost price) */
			if((!IS_NULLFLD(STNPtr, A_Instr_ParticipationLev)) && (price >= *costPrice))  /* PMSTA-34870 - Silpakal - 190225 */
				partPrice = *costPrice + GET_NUMBER(STNPtr, A_Instr_ParticipationLev) * (GET_PRICE(mktPricePtr, A_InstrPrice_Price) - (*costPrice));

			/* Compute Min(current market price, cap price, participation price) where */
			if ((partPrice !=0) && (CMP_NUMBER(partPrice, price) < 0))
			{
				price = partPrice;
				changePriceFlg = TRUE;
			}

			if ((capPrice !=0) && (CMP_NUMBER(capPrice, price) < 0))
			{
				price = capPrice;
				changePriceFlg = TRUE;
			}
		}
	}

	if (InstrumentNature::isBondsLinkedNotes(STNPtr) ||
		InstrumentNature::isReverseConvertible(STNPtr) ||
		InstrumentNature::isReverseConvertibleELN(STNPtr) ||
		InstrumentNature::isReverseConvertibleBLN(STNPtr) ||		
        InstrumentNature::isMemoryCoupons(STNPtr))
	{
		const bool barrierKnockedIn = FALSE == IS_NULLFLD(STNPtr, A_Instr_KnockInDate) && DATE_Cmp(GET_DATETIME(riskPos, ExtPos_ExtPosDate).date, GET_DATE(STNPtr, A_Instr_KnockInDate)) <= 0;

        PRICE_T    categoryMarketPrice = 0, categoryBarrierPrice = 0;

        if ( ((INSTR_UNDERLYING_CATEGORY_ENUM)GET_ENUM(STNPtr, A_Instr_UnderlyCatEn) == INSTR_UNDERLYING_CATEGORY_ENUM::SingleInstrument)||
			((INSTR_UNDERLYING_CATEGORY_ENUM)GET_ENUM(STNPtr, A_Instr_UnderlyCatEn) == INSTR_UNDERLYING_CATEGORY_ENUM::WorstOfBasket))
        {
            categoryMarketPrice = price;
            categoryBarrierPrice = (*costPrice) * (GET_PERCENT(instrCompoPtr, A_InstrCompo_BasketBarrierP)/100);
        }
        else if ((INSTR_UNDERLYING_CATEGORY_ENUM)GET_ENUM(STNPtr, A_Instr_UnderlyCatEn) == INSTR_UNDERLYING_CATEGORY_ENUM::AverageBasket)
        {
            FIN_STNAverageBasketMarketPrice(posHierHead, domainArgPtr, riskPos, STNPtr, &categoryMarketPrice, priceArgStp);
            FIN_STNAverageBasketBarrierPrice(posHierHead, domainArgPtr, riskPos, STNPtr, &categoryBarrierPrice, exchArgStp, priceArgStp);
        }

        if ( (barrierKnockedIn == TRUE) || ( IS_NULLFLD(STNPtr, A_Instr_KnockInDate)))
		{
			/*barrier levels have not been breached, price and CostPrice set to 0 *//*PMSTA-34836 - Silpakala - 190221*/
			price = 0;
			*newCostPrice = 0;
			changePriceFlg = TRUE;
		}
		else
		{
            if (CMP_NUMBER(categoryMarketPrice, categoryBarrierPrice) > 0)   /*PMSTA-32504 - SIL - 190124*/
            {
                if (CMP_NUMBER(price, *costPrice) >= 0)
                {
                    price = *costPrice;
                    changePriceFlg = TRUE;
                }
            }
		}
	}

    /* PMSTA-37912 - Silpakal - 200102 */
    if (InstrumentNature::isReverseConvertibleCLN(STNPtr))
    {
        const bool barrierKnockedIn = FALSE == IS_NULLFLD(STNPtr, A_Instr_KnockInDate) && 
                    DATE_Cmp(GET_DATETIME(riskPos, ExtPos_ExtPosDate).date, GET_DATE(STNPtr, A_Instr_KnockInDate)) >= 0;
        const bool barrierKnockedOut = FALSE == IS_NULLFLD(STNPtr, A_Instr_KnockOutDate) && 
                    DATE_Cmp(GET_DATETIME(riskPos, ExtPos_ExtPosDate).date, GET_DATE(STNPtr, A_Instr_KnockOutDate)) >= 0;

        if ((barrierKnockedIn == TRUE) || (barrierKnockedOut == TRUE))
        {
            price = 0;
        }
        else
        {
            price = GET_AMOUNT(riskPos, ExtPos_PosNetAmt) / GET_NUMBER(riskPos, ExtPos_Qty);         
        }
        changePriceFlg = TRUE;
    }

	if (InstrumentNature::isDiscountCertificates(STNPtr))
	{
		PRICE_T capPrice = 0, strikePrice;

        const bool barrierKnockedIn = FALSE == IS_NULLFLD(STNPtr, A_Instr_KnockInDate) && DATE_Cmp(GET_DATETIME(riskPos, ExtPos_ExtPosDate).date, GET_DATE(STNPtr, A_Instr_KnockInDate)) < 0;
		strikePrice = GET_PRICE(instrCompoPtr, A_InstrCompo_BasketExerPrice);

        if (!IS_NULLFLD(STNPtr, A_Instr_CapLevel))
		{
			capPrice = strikePrice * GET_NUMBER(STNPtr, A_Instr_CapLevel);
		}

		if ((barrierKnockedIn == TRUE) || (IS_NULLFLD(STNPtr, A_Instr_KnockInDate)))
		{
			/*PMSTA-34836 - Silpakala - 190221*/
			price = 0;
			*newCostPrice = 0;
			changePriceFlg = TRUE;
		}
		else /*knockindate is available and knockdate <= valuation date */
		{
			/* Minimum of price and capPrice */  /*PMSTA-35276 - Silpakal - 190325  */
			if (CMP_NUMBER(price, capPrice) > 0)
			{
				price = capPrice;
				changePriceFlg = TRUE;
			}
		}
	}

	/* PMSTA-34870 - Silpakal - 190225 */
	if (InstrumentNature::isAirBagCertificates(STNPtr))
	{
		PRICE_T   partPrice = 0, airbagPrice = 0, marketPrice = price;

		airbagPrice = (*costPrice) * (GET_PERCENT(instrCompoPtr, A_InstrCompo_BasketBarrierP) / 100);

		/* Long Call */
		if (OptClass_Call == static_cast<OPTCLASS_ENUM> GET_ENUM(STNPtr, A_Instr_OptionClassEn))
		{
			if (IS_NULLFLD(STNPtr, A_Instr_KnockOutDate) ||
				(!(IS_NULLFLD(STNPtr, A_Instr_KnockOutDate)) &&
					DATE_Cmp(GET_DATETIME(riskPos, ExtPos_ExtPosDate).date, GET_DATE(STNPtr, A_Instr_KnockOutDate)) < 0))
			{
				/* Participation price = Cost price + participation level * (current market price ? cost price) */
				if ((!IS_NULLFLD(STNPtr, A_Instr_ParticipationLev)) && (price >= *costPrice))
					partPrice = *costPrice + GET_NUMBER(STNPtr, A_Instr_ParticipationLev) * (GET_PRICE(mktPricePtr, A_InstrPrice_Price) - (*costPrice));

				/* Compute Min(current market price,  participation price) where */
				if ((partPrice != 0) && (CMP_NUMBER(partPrice, price) < 0))
				{
					price = partPrice;
					changePriceFlg = TRUE;
				}
			}
			else
			{
				if (airbagPrice != 0)
				{
					price = (*costPrice / airbagPrice)* marketPrice;
				}
				else
				{
					price = 0.0;
				}
				changePriceFlg = TRUE;
			}
		}
		/* Short Put */
		if (OptClass_Put == static_cast<OPTCLASS_ENUM> GET_ENUM(STNPtr, A_Instr_OptionClassEn))
		{
			if (IS_NULLFLD(STNPtr, A_Instr_KnockOutDate) ||
				(!(IS_NULLFLD(STNPtr, A_Instr_KnockOutDate)) &&
					DATE_Cmp(GET_DATETIME(riskPos, ExtPos_ExtPosDate).date, GET_DATE(STNPtr, A_Instr_KnockOutDate)) < 0))
			{
				/* Max of Current market Price and cost price*/
				if ((CMP_NUMBER(*costPrice, price) > 0))
				{
					price = *costPrice;
					changePriceFlg = TRUE;
				}
				*newCostPrice = airbagPrice;
			}
			else
			{
				price = 0;
				*newCostPrice = 0;
				changePriceFlg = TRUE;
			}
		}
	}

	if (InstrumentNature::isTwinWinCertificates(STNPtr))
	{
		PRICE_T capPrice = 0, partPrice = 0;

		/* Long Call */
		if (OptClass_Call == static_cast<OPTCLASS_ENUM> GET_ENUM(STNPtr, A_Instr_OptionClassEn))
		{
			/* Participation price = Cost price + participation level * (current market price ? cost price) */
			if ((!IS_NULLFLD(STNPtr, A_Instr_ParticipationLev)) && (price >= *costPrice))
				partPrice = *costPrice + GET_NUMBER(STNPtr, A_Instr_ParticipationLev) * (GET_PRICE(mktPricePtr, A_InstrPrice_Price) - (*costPrice));

			if (!IS_NULLFLD(STNPtr, A_Instr_CapLevel))
			{
				capPrice = (*costPrice)*GET_NUMBER(STNPtr, A_Instr_CapLevel);
			}

			/* Compute Min(current market price, cap price, participation price) where */
			if ((partPrice != 0) && (CMP_NUMBER(partPrice, price) < 0))
			{
				price = partPrice;
				changePriceFlg = TRUE;
			}

			if ((capPrice != 0) && (CMP_NUMBER(capPrice, price) < 0))
			{
				price = capPrice;
				changePriceFlg = TRUE;
			}
		}

		/* Long Put */
		if (OptClass_Put == static_cast<OPTCLASS_ENUM> GET_ENUM(STNPtr, A_Instr_OptionClassEn))
		{
			if (CMP_NUMBER(price, *costPrice) >= 0)
			{
				price = *costPrice;
				partPrice = price;
			}
			else
			{
				/* Participation price = Cost price + downside participation level * (cost price - current market price) */
				partPrice = *costPrice + GET_NUMBER(STNPtr, A_Instr_ParticipationLevDown) * ((*costPrice) - GET_PRICE(mktPricePtr, A_InstrPrice_Price));
			}

			if (IS_NULLFLD(STNPtr, A_Instr_KnockOutDate) ||
				(!(IS_NULLFLD(STNPtr, A_Instr_KnockOutDate)) &&
					DATE_Cmp(GET_DATETIME(riskPos, ExtPos_ExtPosDate).date, GET_DATE(STNPtr, A_Instr_KnockOutDate)) < 0))
			{
				*newCostPrice = partPrice;
			}
			else
			{
				price = 0;
				*newCostPrice = 0;
				changePriceFlg = TRUE;
			}
		}
	}

	if (InstrumentNature::isBonusNotes(STNPtr))
	{
		PRICE_T bonusPrice = 0, capPrice = 0, partPrice = 0;

		bonusPrice = (*costPrice) * GET_NUMBER(STNPtr, A_Instr_BonusLevel);

		/* Long Call */
		if (OptClass_Call == static_cast<OPTCLASS_ENUM> GET_ENUM(STNPtr, A_Instr_OptionClassEn))
		{
			/* Cap price = Cost price * Cap levels */
			if (!IS_NULLFLD(STNPtr, A_Instr_CapLevel))
				capPrice = (*costPrice) * GET_NUMBER(STNPtr, A_Instr_CapLevel);

			/* Participation price = Cost price + participation level * (current market price ? cost price) */
			if ((!IS_NULLFLD(STNPtr, A_Instr_ParticipationLev)) && (price >= *costPrice))
				partPrice = *costPrice + GET_NUMBER(STNPtr, A_Instr_ParticipationLev) * (GET_PRICE(mktPricePtr, A_InstrPrice_Price) - (*costPrice));

			/* Compute Min(current market price, cap price, participation price) where */
			if ((partPrice != 0) && (CMP_NUMBER(partPrice, price) < 0))
			{
				price = partPrice;
				changePriceFlg = TRUE;
			}

			if ((capPrice != 0) && (CMP_NUMBER(capPrice, price) < 0))
			{
				price = capPrice;
				changePriceFlg = TRUE;
			}
		}

		/* Long Put */
		if (OptClass_Put == static_cast<OPTCLASS_ENUM> GET_ENUM(STNPtr, A_Instr_OptionClassEn))
		{
			if (IS_NULLFLD(STNPtr, A_Instr_KnockOutDate) ||
				(!(IS_NULLFLD(STNPtr, A_Instr_KnockOutDate)) &&
					DATE_Cmp(GET_DATETIME(riskPos, ExtPos_ExtPosDate).date, GET_DATE(STNPtr, A_Instr_KnockOutDate)) < 0))
			{
				*newCostPrice = bonusPrice;
			}
			else
			{
				price = 0;
				*newCostPrice = 0;
				changePriceFlg = TRUE;
			}
		}
	}

	/* PMSTA-35081 - RAK - 190606 */
    if (InstrumentNature::isMiniFuturesTurbo(STNPtr))
    {
        RISKMFTVALRULE_ENUM        mftValRule; 

        GEN_GetApplInfo(ApplRiskMftValRule, &mftValRule); /* WEALTH-101 - JPR - 230609 - Mini future price calulation to be based on the leverage valuation parameter */

        switch (mftValRule)
        {
            case RiskMftValRule_TermEventLeverage:
            
                /* The financial level has already been calculated based on */
                /* the leverage value present in the term event and the value */
                /* of the parameter RISK_STN_COST_RULE. This calculated value */
                /* is stored in the attribute A_TermEvt_MaxValue of turboEvtPtr */
                /* The price is accordingly calculated below */

                /* Knock-out date iA_TermEvt_MaxValues null : market price - financial level */
                if (IS_NULLFLD(STNPtr, A_Instr_KnockOutDate))
                {
                    price = price - GET_NUMBER(turboEvtPtr, A_TermEvt_MaxValue);    /* financial level putted in MaxValue for computation */
                    changePriceFlg = TRUE;
                }
                /* Knock-out date is not null as of current date or current date > knock-out date : lower barrier - financialLevel */
                else if (!(IS_NULLFLD(STNPtr, A_Instr_KnockOutDate)) &&
                    DATE_Cmp(GET_DATETIME(riskPos, ExtPos_ExtPosDate).date, GET_DATE(STNPtr, A_Instr_KnockOutDate)) > 0)
                {
                    price = GET_NUMBER(turboEvtPtr, A_TermEvt_Barrier) - GET_NUMBER(turboEvtPtr, A_TermEvt_MaxValue); /* financial level put in MaxValue for computation */
                    changePriceFlg = TRUE;
                }
                break;

            case RiskMftValRule_CalculatedLeverage:

                PRICE_T leverage = 0.0; /* Taking PRICE_T instead of NUMBER_T as leverage stored in the term event is not used */

                /* The leverage has to be calulated based on the given formula */
                /* Leverage = Underlying Market Price/ Mini Future Market Price */
				leverage = FIN_DIV(price, GET_PRICE(origPos, ExtPos_Price));
                
                /* Price = (Underlying Market Price – Strike Price) * Leverage */ 
                price = (GET_PRICE(mktPricePtr, A_InstrPrice_Price) - GET_PRICE(instrCompoPtr, A_InstrCompo_BasketExerPrice)) * leverage;
                changePriceFlg = TRUE;
                break;
        }
    }

    if (changePriceFlg == TRUE)
    {
        FIN_PriceToQuote((PRICECALCRULE_ENUM)GET_ENUM(underPtr, A_Instr_PriceCalcRuleEn),
            GET_ID(underPtr, A_Instr_Id), underPtr,
            GET_DATETIME(riskPos, ExtPos_ExtPosDate), NULL,
            price, &quote, posHierHead);
        SET_PRICE(mktPricePtr, A_InstrPrice_Price, price);
        SET_PRICE(mktPricePtr, A_InstrPrice_Quote, quote);
    }

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_FxTarkoRiskCompoInfo()
**
**  Description :	New case for option based STN
**
**  Return      :   RET_SUCCEED or error code
**
** Creation	    :   PMSTA-34140 - RAK - 190104
**
*************************************************************************/
STATIC RET_CODE FIN_FxTarkoRiskCompoInfo(DBA_HIER_HEAD_STP	posHierHead,
	DBA_DYNFLD_STP		instrPtr,
	FIN_DOMAIN_ARG_STP	domainArgPtr,
	DBA_DYNFLD_STP		**compoTab,
	int					*compoNbr)
{
	RET_CODE		ret = RET_SUCCEED;
	DBA_DYNFLD_STP	termEvtPtr = nullptr, getData=nullptr, underlyInstrPtr = nullptr, crtCompoPtr = nullptr, *selCompoTab;
	FLAG_T			allocFlg = FALSE;
	int				i, selCompoNbr;
	double			lifeTime, freq = 0.0;
	DATE_T			settlementDate, prevSettlementDate;
	bool			debugFlg = false;
	long			endBeg, endSet;
	int				crt = 0;

	MemoryPool			mp;
	DbiConnectionHelper dbiConnHelper;

	/* PMSTA-34959 - RAK - 190327 - Last minut impact */
	if (GET_DATE(instrPtr, A_Instr_EndDate) < domainArgPtr->fromDateTime.date)
		return(ret);	/* do nothing */

	termEvtPtr = mp.allocDynst(FILEINFO, A_TermEvt);
	getData    = mp.allocDynst(FILEINFO, Evt_Arg);

 	ret = DBA_SelectInstrCompo(GET_ID(instrPtr, A_Instr_Id), domainArgPtr->fromDateTime, &selCompoTab, &selCompoNbr);

	if (selCompoNbr == 0)
		return(ret);

	/* PMSTA-35501 - RAK - 190416 - Each option have his knock-in knock-out (could be different) */
	/* c'est nouveau �a vient de sortir ou c'�tait un d�tail oubli� */
	/* create a new composition will be the simplier */
	mp.owner(selCompoTab, selCompoNbr);

	(*compoTab) = (DBA_DYNFLD_STP*) mp.calloc(FILEINFO, selCompoNbr, sizeof(DBA_DYNFLD_STP));

	for (crt=0, i=0; i < selCompoNbr; i++)
	{
		if ((ret = DBA_GetInstrById(GET_ID(selCompoTab[i], A_InstrCompo_InstrId),
									TRUE, &allocFlg, &underlyInstrPtr, posHierHead,	/* add in hier, no free */
									UNUSED, UNUSED)) != RET_SUCCEED)
		{
			return(ret);
		}

		/* PMSTA-35360 - RAK - 190404 - Force to use stored term_event             */
		if (GET_ID(underlyInstrPtr, A_Instr_Id) < 0)
		{SET_ID(getData, Evt_Arg_InstrId, GET_ID(underlyInstrPtr, A_Instr_ParentInstrId));}
		else
		{SET_ID(getData, Evt_Arg_InstrId, GET_ID(underlyInstrPtr, A_Instr_Id));}
		SET_DATE(getData, Evt_Arg_ValidDate, domainArgPtr->fromDateTime.date);

		if ((ret = dbiConnHelper.dbaGet(TermEvt, UNUSED, getData, &termEvtPtr)) != RET_SUCCEED)
		{
			return(ret);
		}

		/* PMSTA-35500 - RAK - 190426 - Don't test the knock in and knock out for the Vanilla */
		if (((OptClass_Call == GET_ENUM(termEvtPtr, A_TermEvt_OptionClassEn) ||
			 OptClass_Put == GET_ENUM(termEvtPtr, A_TermEvt_OptionClassEn)) &&
			TermEvt_Payoff_Vanilla == GET_ENUM(termEvtPtr, A_TermEvt_PayOffNatEn)) ||

		   (FIN_STNKnockInStarted(domainArgPtr->fromDateTime.date, termEvtPtr, underlyInstrPtr) == TRUE &&
			FIN_STNKnockOutExpired(domainArgPtr->fromDateTime.date, termEvtPtr, underlyInstrPtr) == FALSE &&
			GET_DATE(underlyInstrPtr, A_Instr_EndDate) >= domainArgPtr->fromDateTime.date))
		{
			crtCompoPtr = mp.allocDynst(FILEINFO, A_InstrCompo);

			COPY_DYNST(crtCompoPtr, selCompoTab[i], A_InstrCompo);
			(*compoTab)[crt] = crtCompoPtr;
			crt++;

			/* PMSTA-35133 - RAK - 190509 - Inverse change */
			SET_PRICE(crtCompoPtr, A_InstrCompo_BasketExerPrice, (1.0 / GET_PRICE(underlyInstrPtr, A_Instr_RedempPrice))); /* use A_InstrCompo_BasketExerPrice to keep information ! c'est un d�tournement */

			/* PMSTA-34959 - RAK - 190327 - Last minut impact : new code */
			/* First know the current settlement date and compute settlement current number */
			FIN_PeriodUnitNbr((FREQUNIT_ENUM)GET_ENUM(underlyInstrPtr, A_Instr_PayFreqUnitEn),
							  GET_TINYINT(underlyInstrPtr, A_Instr_PayFreq), FreqUnit_Month, &freq);

			/* Use fixing date  */
			if (!IS_NULLFLD(underlyInstrPtr, A_Instr_FixDate))
				settlementDate = GET_DATE(underlyInstrPtr, A_Instr_FixDate);
			else
				settlementDate = GET_DATE(underlyInstrPtr, A_Instr_BeginDate);

			if (settlementDate == 0 || freq == 0)
			{
				MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
					"FIN_FxTarkoRiskCompoInfo", "first settlement date and payment frequency");
				return(RET_GEN_ERR_INVARG);
			}

			prevSettlementDate = 0;
			lifeTime = 1.0;

			/* PMSTA - 35440 - RAK - 100416 */
			while (settlementDate <= GET_DATE(underlyInstrPtr, A_Instr_EndDate) && settlementDate <= domainArgPtr->fromDateTime.date)
			{
				prevSettlementDate = settlementDate;
				settlementDate = DATE_Move(settlementDate, (int)freq, Month);
			}

			if (prevSettlementDate != 0) /* else keep 1.0 as lifeTime */
			{
				DATE_DaysBetween(GET_DATE(underlyInstrPtr, A_Instr_EndDate), prevSettlementDate, AccrRule_30E_360, &endSet, 0);
				/*endSet -= 1; / * PMSTA-35440 - RAK - 100416 */

				DATE_DaysBetween(GET_DATE(underlyInstrPtr, A_Instr_EndDate), GET_DATE(underlyInstrPtr, A_Instr_BeginDate), AccrRule_30E_360, &endBeg, 0);
				lifeTime = (double)endSet / (double)endBeg;

				if (debugFlg)
				{
					YEAR_T eyear, syear;
					MONTH_T emonth, smonth;
					DAY_T eday, sday;

					DATE_Get(GET_DATE(underlyInstrPtr, A_Instr_EndDate), &eyear, &emonth, &eday);
					DATE_Get(prevSettlementDate, &syear, &smonth, &sday);
					printf("\ndiff %02d/%02d/%04d -  %02d/%02d/%04d numerator %d end-begin %d lifeTime %f TotalQty %f", eday, emonth, eyear, sday, smonth, syear, endSet, endBeg, lifeTime, GET_NUMBER(termEvtPtr, A_TermEvt_TotalQty));
				}
			}

			/* Lifetime_part = (end_d � previous settlement date) / (end_d � begin_d) */
			SET_NUMBER(crtCompoPtr, A_InstrCompo_Quantity, GET_NUMBER(termEvtPtr, A_TermEvt_TotalQty) * lifeTime);

			/* PMSTA-34752 - RAK - 190221 - We buy a call and sell a put */
			if ((OPTCLASS_ENUM)GET_ENUM(underlyInstrPtr, A_Instr_OptionClassEn) == OptClass_Call)
			{
				SET_NUMBER(crtCompoPtr, A_InstrCompo_Quantity, GET_NUMBER(crtCompoPtr, A_InstrCompo_Quantity) * -1.0);
			}

			/* PMSTA-35504 - RAK - 190521 - in case of delta exposure, apply delta */
			if (domainArgPtr->optDeltaRule == OptDelta_Delta)
			{
				/* chrono */
				NUMBER_T delta = 1.0;

				DBA_DYNFLD_STP instrChrono = mp.allocDynst(FILEINFO, A_InstrChrono);
				DBA_DYNFLD_STP dimChronoPtr = mp.allocDynst(FILEINFO, Dim_InstrChrono);

				SET_ID(dimChronoPtr, Dim_InstrChrono_InstrId, GET_ID(underlyInstrPtr, A_Instr_Id));
				SET_DATETIME(dimChronoPtr, Dim_InstrChrono_RefDate, domainArgPtr->fromDateTime);
				SET_ENUM(dimChronoPtr, Dim_InstrChrono_NatEn, ChronoNat_Delta);
				SET_FLAG(dimChronoPtr, Dim_InstrChrono_ComputeFlg, FALSE);

				if (FIN_InstrChrono(dimChronoPtr, underlyInstrPtr, instrChrono, posHierHead) == RET_SUCCEED)
				{
					delta = GET_LONGAMOUNT(instrChrono, A_InstrChrono_Val);
				}

				SET_NUMBER(crtCompoPtr, A_InstrCompo_Quantity, GET_NUMBER(crtCompoPtr, A_InstrCompo_Quantity) * delta);

			}

			mp.remove(crtCompoPtr);

		}
	}

	mp.remove(*compoTab);

	*compoNbr = crt;

	/* PMSTA-35009 - RAK - 190404 - No decomposition in case of not in or already out */
	/* PMSTA-35501 - RAK - 190416 - Wrong */
	/* if (knockNbr < *compoNbr)
	{
		for (i = 0;i < *compoNbr;i++) { FREE_DYNST((*compoTab)[i], A_InstrCompo); }
		FREE(*compoTab);
		*compoNbr = 0;
	} */

	return(ret);
}

STATIC int FIN_CmpOptionsLegs(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
	DBA_DYNFLD_STP instr1Ptr, instr2Ptr;

	if ((GET_EXTENSION_PTR(*ptr1, ExtPos_A_Instr_Ext) != NULL &&
		(instr1Ptr = *(GET_EXTENSION_PTR(*ptr1, ExtPos_A_Instr_Ext))) != NULL) &&
		(GET_EXTENSION_PTR(*ptr2, ExtPos_A_Instr_Ext) != NULL &&
		(instr2Ptr = *(GET_EXTENSION_PTR(*ptr2, ExtPos_A_Instr_Ext))) != NULL))
	{
		int diff = CMP_DYNFLD(instr1Ptr, instr2Ptr, A_Instr_RefCurrId, A_Instr_RefCurrId, IdType);

		if (diff == 0)	/* same reference put first the real currency (positiv identifier) */
			diff = CMP_DYNFLD(instr2Ptr, instr1Ptr, A_Instr_Id, A_Instr_Id, IdType);
		return(diff);
	}
	else
		return(0);
}

STATIC int FIN_FilterOptionsLegs(DBA_DYNFLD_STP dynSt,
								DBA_DYNST_ENUM dynStTp,
								DBA_DYNFLD_STP STNPtr)
{
	if (GET_ID(dynSt, ExtPos_RiskParInstrId) == GET_ID(STNPtr, A_Instr_Id))
		return(TRUE);
	else
		return(FALSE);
}

STATIC void FIN_CumulOptionsLegs(DBA_HIER_HEAD_STP	posHierHead, DBA_DYNFLD_STP leg1Ptr, DBA_DYNFLD_STP leg2Ptr, DBA_DYNFLD_STP totPosRisk, DATETIME_T fromDateTime)
{
	DBA_DYNFLD_STP	posVal1Ptr = nullptr, posVal2Ptr = nullptr;
	int				i;
	FIN_EXCHARG_ST	exchArgSt;
	EXCHANGE_T      tmpExch;
	AMOUNT_T        tmpAmt;
	MemoryPool		mp;


	memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));

	/* PMSTA-35133 - Display currency */
	if (GET_ID(leg1Ptr, A_Instr_Id) < 0)
	{
		DBA_DYNFLD_STP getData = mp.allocDynst(FILEINFO, Get_Arg);
		DBA_DYNFLD_STP cashInstr = nullptr;
		FLAG_T		   freeInstrFlg = FALSE;

		SET_ID(getData, Get_Arg_RefCurrId, GET_ID(leg1Ptr, ExtPos_InstrCurrId));

		if (DBA_GetDfltCashInstrByCurr(posHierHead, getData, TRUE, &freeInstrFlg, &cashInstr) == RET_SUCCEED)
		{
			SET_ID(leg1Ptr, ExtPos_InstrId, GET_ID(cashInstr, A_Instr_Id));
			DBA_ForceLink(posHierHead, ExtPos, ExtPos_A_Instr_Ext, leg1Ptr, cashInstr);
		}
	}

	SET_NUMBER(leg1Ptr, ExtPos_Qty, GET_NUMBER(leg1Ptr, ExtPos_Qty) + GET_NUMBER(leg2Ptr, ExtPos_Qty));
	for (i = ExtPos_SupplAmt; i <= ExtPos_Bp10PosAmt; i++)
	{
		SET_NUMBER(leg1Ptr, i, GET_NUMBER(leg1Ptr, i) + GET_NUMBER(leg2Ptr, i));
	}

	/* recompute valorisation with currency price */
	if ((GET_EXTENSION_PTR(leg1Ptr, ExtPos_PosVal_Ext) != NULL &&
		(posVal1Ptr = *(GET_EXTENSION_PTR(leg1Ptr, ExtPos_PosVal_Ext))) != NULL) &&
		(GET_EXTENSION_PTR(leg2Ptr, ExtPos_PosVal_Ext) != NULL &&
		(posVal2Ptr = *(GET_EXTENSION_PTR(leg2Ptr, ExtPos_PosVal_Ext))) != NULL))
	{
		/* PMSTA-35133 - RAK - 190507 - Inverse */
		SET_AMOUNT(posVal1Ptr, PosVal_PosMktValAmt, GET_NUMBER(leg1Ptr, ExtPos_Qty) * GET_EXCHANGE(posVal1Ptr, PosVal_Price));
		SET_AMOUNT(posVal1Ptr, PosVal_PosNetAmt, GET_AMOUNT(posVal1Ptr, PosVal_PosMktValAmt));

		SET_AMOUNT(posVal1Ptr, PosVal_PosAccrInterAmt, 0);
		SET_AMOUNT(posVal1Ptr, PosVal_RefAccrInterAmt, 0);
		SET_AMOUNT(posVal1Ptr, PosVal_InstrAccrInterAmt, 0);

		if (GET_ID(leg1Ptr, ExtPos_RefCurrId) != GET_ID(leg1Ptr, ExtPos_PosCurrId))
		{
			exchArgSt.srcAmt = GET_AMOUNT(posVal1Ptr, PosVal_PosMktValAmt);

			FIN_ExchAmt(fromDateTime, GET_ID(leg1Ptr, ExtPos_PosCurrId), GET_ID(leg1Ptr, ExtPos_RefCurrId),
						0, NULLDYNST, leg1Ptr, &exchArgSt,
						(EXCHANGE_T*)NULL, &tmpAmt, &tmpExch);
			SET_AMOUNT(posVal1Ptr, PosVal_RefNetAmt, tmpAmt);
			SET_AMOUNT(posVal1Ptr, PosVal_RefMktValAmt, tmpAmt);
			SET_EXCHANGE(leg1Ptr, ExtPos_PosExchRate, tmpExch);
		}
		else
		{
			SET_AMOUNT(posVal1Ptr, PosVal_RefMktValAmt, GET_AMOUNT(posVal1Ptr, PosVal_PosMktValAmt));
			SET_AMOUNT(posVal1Ptr, PosVal_RefNetAmt, GET_AMOUNT(posVal1Ptr, PosVal_PosMktValAmt));
			SET_EXCHANGE(leg1Ptr, ExtPos_PosExchRate, 1.0);
		}

		if (GET_ID(leg1Ptr, ExtPos_InstrCurrId) != GET_ID(leg1Ptr, ExtPos_PosCurrId))
		{
			exchArgSt.srcAmt = GET_AMOUNT(posVal1Ptr, PosVal_PosMktValAmt);
			FIN_ExchAmt(fromDateTime, GET_ID(leg1Ptr, ExtPos_PosCurrId), GET_ID(leg1Ptr, ExtPos_InstrCurrId),
						0, NULLDYNST, leg1Ptr, &exchArgSt,
						(EXCHANGE_T*)NULL, &tmpAmt, &tmpExch);
			SET_AMOUNT(posVal1Ptr, PosVal_InstrNetAmt, tmpAmt);
			SET_AMOUNT(posVal1Ptr, PosVal_InstrMktValAmt, tmpAmt);
			SET_EXCHANGE(leg1Ptr, ExtPos_InstrExchRate, tmpExch);

		}
		else
		{
			SET_AMOUNT(posVal1Ptr, PosVal_InstrMktValAmt, GET_AMOUNT(posVal1Ptr, PosVal_PosMktValAmt));
			SET_AMOUNT(posVal1Ptr, PosVal_InstrNetAmt, GET_AMOUNT(posVal1Ptr, PosVal_PosMktValAmt));
			SET_EXCHANGE(leg1Ptr, ExtPos_InstrExchRate, 1.0);
		}
	}

	/* seems only this fields used  */
	SET_AMOUNT(totPosRisk, RiskAmt_PosMktValAmt, GET_AMOUNT(totPosRisk, RiskAmt_PosMktValAmt) - GET_AMOUNT(posVal1Ptr, PosVal_PosMktValAmt));
	SET_AMOUNT(totPosRisk, RiskAmt_RefMktValAmt, GET_AMOUNT(totPosRisk, RiskAmt_RefMktValAmt) - GET_AMOUNT(posVal1Ptr, PosVal_RefMktValAmt));

}

/************************************************************************
**
**  Function    :   FIN_DCITCICompoInfo()
**
**  Description :	New case for option based STN
**
**  Return      :   RET_SUCCEED or error code
**
** Creation	    :   PMSTA-34140 - RAK - 190104
**
*************************************************************************/
STATIC RET_CODE FIN_DCITCICompoInfo(DBA_HIER_HEAD_STP	posHierHead,
									DBA_DYNFLD_STP		instrPtr,
									FIN_DOMAIN_ARG_STP	domainArgPtr,
									DBA_DYNFLD_STP		**compoTab,
									int					*compoNbr)
{
	RET_CODE		ret = RET_SUCCEED;
	FLAG_T			allocFlg = FALSE;
	DBA_DYNFLD_STP	underlyInstrPtr=nullptr;

	if ((ret = DBA_SelectInstrCompo(GET_ID(instrPtr, A_Instr_Id), domainArgPtr->fromDateTime, compoTab, compoNbr)) == RET_SUCCEED)
	{
		for (int i = 0; i < *compoNbr; i++)
		{
			if ((ret = DBA_GetInstrById(GET_ID((*compoTab)[i], A_InstrCompo_InstrId),
				TRUE, &allocFlg, &underlyInstrPtr, posHierHead,	/* add in hier, no free */
				UNUSED, UNUSED)) != RET_SUCCEED)
			{
				for (i = 0;i < *compoNbr;i++) { FREE_DYNST((*compoTab)[i], A_InstrCompo); }
					FREE(*compoTab);
				*compoNbr = 0;
				return(ret);
			}

			if ((INSTRNAT_ENUM)GET_ENUM(underlyInstrPtr, A_Instr_NatEn) == InstrNat_MoneyMkt)
			{
				SET_NUMBER((*compoTab)[i], A_InstrCompo_Quantity, 1.0);
			}
			else
			{
				SET_NUMBER((*compoTab)[i], A_InstrCompo_Quantity, 1.0 / GET_NUMBER(instrPtr, A_Instr_ContractSize));
			}
		}
	}

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_DCITCIShortPutPos()
**
**  Description :
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation	:   PMSTA-35192 - RAK - 190331
**
*************************************************************************/
STATIC RET_CODE FIN_DCITCIShortPutPos(DBA_HIER_HEAD_STP   posHierHead,
	DBA_DYNFLD_STP		  domainPtr,
	FIN_DOMAIN_ARG_STP    domainArgPtr,
	FIN_AIARG_STP	      aiArgPtr,
	FIN_EXCHARG_STP	      exchArgStp,
	DBA_DYNFLD_STP        origPos,
	DBA_DYNFLD_STP        SPutInstrPtr,
	DBA_DYNFLD_STP        totPosRisk,
	RISK_QTY_STP		  riskQtyStp,
	FIN_PRICEARG_STP      priceArgStp,
	NUMBER_T			  optionQty)
{
	DBA_DYNFLD_STP		 SPutPosPtr = NULL, pricePtr;
	PRICE_T			 price = 0.0;
	ID_T                 priceCurrId = 0;
	EXCHANGE_T           exch;
	AMOUNT_T             amt;
	RET_CODE			 ret = RET_SUCCEED;
	MemoryPool mp;

	pricePtr = mp.allocDynst(FILEINFO, A_InstrPrice);

	if ((SPutPosPtr = ALLOC_DYNST(ExtPos)) == NULL)
	{
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	COPY_DYNST(SPutPosPtr, origPos, ExtPos);

	SET_ENUM(SPutPosPtr, ExtPos_RiskNatEn, ExtPosRisk_NoRisk);
	SET_FLAG(SPutPosPtr, ExtPos_MainFlg, FALSE);

	/* Suppress extension identifier (copied from origin position) */
	SET_NULL_ID(SPutPosPtr, ExtPos_MainExtPosId);
	SET_NULL_ID(SPutPosPtr, ExtPos_AcctExtPosId);
	SET_NULL_ID(SPutPosPtr, ExtPos_AdjustExtPosId);
	SET_NULL_ID(SPutPosPtr, ExtPos_PosValId);

	SET_ID(SPutPosPtr, ExtPos_InstrId, GET_ID(SPutInstrPtr, A_Instr_Id));
	SET_ID(SPutPosPtr, ExtPos_InstrCurrId, GET_ID(SPutInstrPtr, A_Instr_RefCurrId));

	price = 1.0;
	/* PMSTA-34140 - RAK - 190201 - Wrong it will be in cash instrument currency and not main instrument currency */
	/* priceCurrId = GET_ID(STNPtr, A_Instr_RefCurrId); */
	priceCurrId = GET_ID(SPutInstrPtr, A_Instr_RefCurrId);

	/* Convert price in position currency */
	FIN_GetExchRate(GET_DATETIME(SPutPosPtr, ExtPos_BegDate), priceCurrId, GET_ID(SPutPosPtr, ExtPos_PosCurrId),
		(ID_T)0, NULL, SPutPosPtr, exchArgStp, &exch);
	price *= exch;

	if (GET_ID(SPutPosPtr, ExtPos_RefCurrId) != GET_ID(SPutPosPtr, ExtPos_PosCurrId))
	{
		FIN_GetExchRate(GET_DATETIME(SPutPosPtr, ExtPos_BegDate),
			GET_ID(SPutPosPtr, ExtPos_PosCurrId), GET_ID(SPutPosPtr, ExtPos_RefCurrId),
			(ID_T)0, NULL, SPutPosPtr, exchArgStp, &exch);
		SET_EXCHANGE(SPutPosPtr, ExtPos_PosExchRate, exch);
	}
	else
	{
		SET_EXCHANGE(SPutPosPtr, ExtPos_PosExchRate, 1.0);
	}

	if (GET_ID(SPutPosPtr, ExtPos_RefCurrId) != GET_ID(SPutPosPtr, ExtPos_InstrCurrId))
	{
		FIN_GetExchRate(GET_DATETIME(SPutPosPtr, ExtPos_BegDate),
			GET_ID(SPutPosPtr, ExtPos_InstrCurrId), GET_ID(SPutPosPtr, ExtPos_RefCurrId),
			(ID_T)0, NULL, SPutPosPtr, exchArgStp, &exch);	/* PMSTA01649 - TGU - 070405 */
		SET_EXCHANGE(SPutPosPtr, ExtPos_InstrExchRate, exch);
	}
	else
	{
		SET_EXCHANGE(SPutPosPtr, ExtPos_InstrExchRate, 1.0);
	}

	SET_PRICE(SPutPosPtr, ExtPos_Price, price);
	SET_PRICE(SPutPosPtr, ExtPos_Quote, price);

	/* according to A_Instr_ConvertInterestEn value(with or without AI) */
	SET_NUMBER(SPutPosPtr, ExtPos_Qty, optionQty);
	amt = GET_NUMBER(origPos, ExtPos_Qty) * price;
	SET_AMOUNT(SPutPosPtr, ExtPos_PosGrossAmt, amt);

	SET_AMOUNT(SPutPosPtr, ExtPos_PosNetAmt, amt);

	/* PMSTA-33207 - RAK - 181009 - Regression - parameters added for fwd, here FALSE as we don't need it */
	/* Convert in instrument currency */
	FIN_RiskPosSetExtPosPosAmtTo(ExtPos_InstrNetAmt, posHierHead, SPutPosPtr, exchArgStp);

	/* Convert in reference currency */
	FIN_RiskPosSetExtPosPosAmtTo(ExtPos_RefNetAmt, posHierHead, SPutPosPtr, exchArgStp);

	/* Convert in system currency */
	FIN_RiskPosSetExtPosPosAmtTo(ExtPos_SysNetAmt, posHierHead, SPutPosPtr, exchArgStp);

	FIN_RiskPosLink(SPutPosPtr, origPos, GET_ID(origPos, ExtPos_InstrId));

	SET_PRICE(pricePtr, A_InstrPrice_Price, price);

	riskQtyStp->price = GET_PRICE(pricePtr, A_InstrPrice_Price);
	riskQtyStp->priceCurrId = GET_ID(SPutInstrPtr, A_Instr_Id);

	SET_PRICE(pricePtr, A_InstrPrice_Quote, GET_PRICE(pricePtr, A_InstrPrice_Price));
	SET_ID(pricePtr, A_InstrPrice_InstrId, GET_ID(SPutInstrPtr, A_Instr_Id));
	SET_ID(pricePtr, A_InstrPrice_CurrId, GET_ID(SPutInstrPtr, A_Instr_RefCurrId));

	/* Will update totPosRisk for the cash in STEP-4 (as it is a Risk_Son)  */
	ret = FIN_AddValoRiskPos(posHierHead, domainArgPtr, aiArgPtr, origPos, SPutPosPtr,
		                     SPutInstrPtr, TRUE, totPosRisk, priceArgStp, Risk_Son, (FIN_OPTINFO_STP)NULL, NULL, pricePtr, nullptr);

	/* All that for that : risk decomposition of the short put  */
	if (ret == RET_SUCCEED)
	{
		/* Create his own total as will be treated as Risk_Father */
		DBA_DYNFLD_STP optTotPosRisk = nullptr;
		if ((optTotPosRisk = FIN_CreateRiskAmt(posHierHead, SPutPosPtr, domainArgPtr->fromDateTime, domainArgPtr->refCurrId)) != NULL)
		{
			mp.ownerDynStp(optTotPosRisk);

			ret = FIN_PosRiskAnalysis(posHierHead, domainPtr, domainArgPtr, aiArgPtr, SPutPosPtr,
				GET_ID(SPutInstrPtr, A_Instr_Id), SPutInstrPtr, optTotPosRisk, riskQtyStp,
				Risk_Father, TRUE);
		}
	}

	return(ret);
}


/************************************************************************
**
**  Function    :   FIN_DCITCIMoneyMarketPos()
**
**  Description :
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation	:   PMSTA-32112 - RAK - 190214
**
*************************************************************************/
STATIC RET_CODE FIN_DCITCIMoneyMarketPos(DBA_HIER_HEAD_STP   posHierHead,
										 FIN_DOMAIN_ARG_STP  domainArgPtr,
										 FIN_AIARG_STP	     aiArgPtr,
										 FIN_EXCHARG_STP	 exchArgStp,
										 DBA_DYNFLD_STP      origPos,
										 DBA_DYNFLD_STP      MMInstrPtr,
										 DBA_DYNFLD_STP      totPosRisk,
										 FIN_PRICEARG_STP    priceArgStp,
										 RISK_ANALYSIS_ENUM  status)
{
	DBA_DYNFLD_STP		 MMPosPtr = NULL;
	PRICE_T			 price = 0.0;
	ID_T                 priceCurrId = 0;
	EXCHANGE_T           exch;
	AMOUNT_T             amt;
	RET_CODE ret = RET_SUCCEED;

	if ((MMPosPtr = ALLOC_DYNST(ExtPos)) == NULL)
	{
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	COPY_DYNST(MMPosPtr, origPos, ExtPos);

	SET_ENUM(MMPosPtr, ExtPos_RiskNatEn, ExtPosRisk_NoRisk);
	SET_FLAG(MMPosPtr, ExtPos_MainFlg, FALSE);

	/* Suppress extension identifier (copied from origin position) */
	SET_NULL_ID(MMPosPtr, ExtPos_MainExtPosId);
	SET_NULL_ID(MMPosPtr, ExtPos_AcctExtPosId);
	SET_NULL_ID(MMPosPtr, ExtPos_AdjustExtPosId);
	SET_NULL_ID(MMPosPtr, ExtPos_PosValId);

	SET_ID(MMPosPtr, ExtPos_InstrId, GET_ID(MMInstrPtr, A_Instr_Id));
	SET_ID(MMPosPtr, ExtPos_InstrCurrId, GET_ID(MMInstrPtr, A_Instr_RefCurrId));

	price = 1;
	/* PMSTA-34140 - RAK - 190201 - Wrong it will be in cash instrument currency and not main instrument currency */
	/* priceCurrId = GET_ID(STNPtr, A_Instr_RefCurrId); */
	priceCurrId = GET_ID(MMInstrPtr, A_Instr_RefCurrId);

	/* Convert price in position currency */
	FIN_GetExchRate(GET_DATETIME(MMPosPtr, ExtPos_BegDate), priceCurrId, GET_ID(MMPosPtr, ExtPos_PosCurrId),
		            (ID_T)0, NULL, MMPosPtr, exchArgStp, &exch);
	price *= exch;

	if (GET_ID(MMPosPtr, ExtPos_RefCurrId) != GET_ID(MMPosPtr, ExtPos_PosCurrId))
	{
		FIN_GetExchRate(GET_DATETIME(MMPosPtr, ExtPos_BegDate),
						GET_ID(MMPosPtr, ExtPos_PosCurrId), GET_ID(MMPosPtr, ExtPos_RefCurrId),
						(ID_T)0, NULL, MMPosPtr, exchArgStp, &exch);
		SET_EXCHANGE(MMPosPtr, ExtPos_PosExchRate, exch);
	}
	else
	{
		SET_EXCHANGE(MMPosPtr, ExtPos_PosExchRate, 1.0);
	}

	if (GET_ID(MMPosPtr, ExtPos_RefCurrId) != GET_ID(MMPosPtr, ExtPos_InstrCurrId))
	{
		FIN_GetExchRate(GET_DATETIME(MMPosPtr, ExtPos_BegDate),
						GET_ID(MMPosPtr, ExtPos_InstrCurrId), GET_ID(MMPosPtr, ExtPos_RefCurrId),
						(ID_T)0, NULL, MMPosPtr, exchArgStp, &exch);	/* PMSTA01649 - TGU - 070405 */
		SET_EXCHANGE(MMPosPtr, ExtPos_InstrExchRate, exch);
	}
	else
	{
		SET_EXCHANGE(MMPosPtr, ExtPos_InstrExchRate, 1.0);
	}

	SET_PRICE(MMPosPtr, ExtPos_Price, price);
	SET_PRICE(MMPosPtr, ExtPos_Quote, price);

	/* In position currency */
	SET_NUMBER(MMPosPtr, ExtPos_Qty, GET_NUMBER(origPos, ExtPos_Qty));
	amt = GET_NUMBER(origPos, ExtPos_Qty) * price;
	SET_AMOUNT(MMPosPtr, ExtPos_PosGrossAmt, amt);

	SET_AMOUNT(MMPosPtr, ExtPos_PosNetAmt, amt);

	/* PMSTA-33207 - RAK - 181009 - Regression - parameters added for fwd, here FALSE as we don't need it */
	/* Convert in instrument currency */
	FIN_RiskPosSetExtPosPosAmtTo(ExtPos_InstrNetAmt, posHierHead, MMPosPtr, exchArgStp);

	/* Convert in reference currency */
	FIN_RiskPosSetExtPosPosAmtTo(ExtPos_RefNetAmt, posHierHead, MMPosPtr, exchArgStp);

	/* Convert in system currency */
	FIN_RiskPosSetExtPosPosAmtTo(ExtPos_SysNetAmt, posHierHead, MMPosPtr, exchArgStp);

	FIN_RiskPosLink(MMPosPtr, origPos, GET_ID(origPos, ExtPos_InstrId));

	ret = FIN_AddValoRiskPos(posHierHead, domainArgPtr, aiArgPtr, origPos, MMPosPtr,
		MMInstrPtr, TRUE, totPosRisk, priceArgStp, status, (FIN_OPTINFO_STP)NULL, NULL, NULL, nullptr);

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_FxTarkoCashPos()
**
**  Description :
**
**  Return      :   RET_SUCCEED or error code
**
** Creation	    :   PMSTA-32112 - RAK - 180820
**
*************************************************************************/
STATIC RET_CODE FIN_FxTarkoCashPos(DBA_HIER_HEAD_STP   posHierHead,
	FIN_DOMAIN_ARG_STP  domainArgPtr,
	FIN_AIARG_STP	   aiArgPtr,
	FIN_EXCHARG_STP	   exchArgStp,
	DBA_DYNFLD_STP      origPos,
	DBA_DYNFLD_STP      STNPtr,
	DBA_DYNFLD_STP      totPosRisk,
	FIN_PRICEARG_STP    priceArgStp,
	RISK_ANALYSIS_ENUM  status)
{
	DBA_DYNFLD_STP		 cashInstr = NULL, cashPos = NULL, testCashInstr = NULL;
	PRICE_T			 price = 0.0;
	ID_T                 priceCurrId = 0;
	EXCHANGE_T           exch;
	NUMBER_T			 qty;
	RET_CODE ret = RET_SUCCEED;

	if ((cashPos = ALLOC_DYNST(ExtPos)) == NULL)
	{
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	COPY_DYNST(cashPos, origPos, ExtPos);

	SET_ENUM(origPos, ExtPos_RiskNatEn, ExtPosRisk_NoRisk);
	SET_FLAG(cashPos, ExtPos_MainFlg, FALSE);

	/* Suppress extension identifier (copied from origin position) */
	SET_NULL_ID(cashPos, ExtPos_MainExtPosId);
	SET_NULL_ID(cashPos, ExtPos_AcctExtPosId);
	SET_NULL_ID(cashPos, ExtPos_AdjustExtPosId);
	SET_NULL_ID(cashPos, ExtPos_PosValId);

	if ((cashInstr = ALLOC_DYNST(A_Instr)) == NULL)
	{
		FREE_DYNST(cashPos, ExtPos);
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	MemoryPool mp;
	DBA_DYNFLD_STP getData = mp.allocDynst(FILEINFO, Get_Arg);

	/* An offsetting cash position would be shown in the currency of the note */
	SET_ID(getData, Get_Arg_RefCurrId, domainArgPtr->refCurrId);
	SET_ENUM(getData, Get_Arg_NatEn, InstrNat_CashAcct);

	if (DBA_Get2(Instr, UNUSED, Get_Arg, getData, A_Instr, &cashInstr, UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
	{
		/* clear error message */
		DBA_DYNFLD_STP	currPtr = NULL;
		FLAG_T          freeFlag = FALSE;

		if (DBA_GetCurrById(GET_ID(getData, Get_Arg_RefCurrId), &currPtr, &freeFlag) == RET_SUCCEED)
		{
			MSG_SendMesg(RET_DBA_ERR_NODATA, 10, FILEINFO, GET_CODE(currPtr, A_Curr_Cd));
		}
		else
		{
			MSG_SendMesg(RET_DBA_ERR_NODATA, 11, FILEINFO, GET_ID(getData, Get_Arg_RefCurrId));
		}

		if (freeFlag == TRUE) { FREE_DYNST(currPtr, A_Curr); }
		FREE_DYNST(cashInstr, A_Instr);
		FREE_DYNST(cashPos, ExtPos);
		return(RET_DBA_ERR_NODATA);
	}

	price = 1.0;
	priceCurrId = domainArgPtr->refCurrId;

	SET_PRICE(cashPos, ExtPos_Price, price);
	SET_PRICE(cashPos, ExtPos_Quote, price);

	SET_ID(cashPos, ExtPos_InstrId, GET_ID(cashInstr, A_Instr_Id));
	SET_ID(cashPos, ExtPos_InstrCurrId, priceCurrId);
	SET_ID(cashPos, ExtPos_PosCurrId, priceCurrId);

	/* Quantity of cash is difference between accounting position and risk position (ZCN and basket) */
	qty = GET_NUMBER(totPosRisk, RiskAmt_RefMktValAmt); /* the only one common */

	/* In referencee currency */
	SET_NUMBER(cashPos, ExtPos_Qty, CAST_NUMBER(qty));
	SET_AMOUNT(cashPos, ExtPos_RefGrossAmt, CAST_NUMBER(qty));
	SET_AMOUNT(cashPos, ExtPos_RefNetAmt, CAST_NUMBER(qty));

	/* Convert price in position currency */
	FIN_GetExchRate(GET_DATETIME(cashPos, ExtPos_BegDate),
		GET_ID(cashPos, ExtPos_RefCurrId), GET_ID(cashPos, ExtPos_PosCurrId),
		(ID_T)0, NULL, cashPos, exchArgStp, &exch);

	SET_AMOUNT(cashPos, ExtPos_PosGrossAmt, (GET_AMOUNT(cashPos, ExtPos_RefGrossAmt) * exch));
	SET_AMOUNT(cashPos, ExtPos_PosNetAmt, (GET_AMOUNT(cashPos, ExtPos_RefNetAmt) * exch));
	SET_EXCHANGE(cashPos, ExtPos_PosExchRate, (1.0 / exch));

	/* Convert in instrument currency */
	FIN_RiskPosSetExtPosPosAmtTo(ExtPos_InstrNetAmt, posHierHead, cashPos, exchArgStp);

	/* Convert in system currency */
	FIN_RiskPosSetExtPosPosAmtTo(ExtPos_SysNetAmt, posHierHead, cashPos, exchArgStp);

	FIN_RiskPosLink(cashPos, origPos, GET_ID(STNPtr, A_Instr_Id));

	testCashInstr = DBA_SearchHierRecById(posHierHead, A_Instr, A_Instr_Id, GET_ID(cashInstr, A_Instr_Id));

	/* Convert price in position currency */
	FIN_GetExchRate(domainArgPtr->fromDateTime,
		GET_ID(cashPos, ExtPos_RefCurrId), GET_ID(cashPos, ExtPos_PosCurrId),
		(ID_T)0, NULL, cashPos, exchArgStp, &exch);

		SET_AMOUNT(totPosRisk, RiskAmt_PosMktValAmt, GET_AMOUNT(totPosRisk, RiskAmt_RefMktValAmt) * exch);


	ret = FIN_AddValoRiskPos(posHierHead, domainArgPtr, aiArgPtr, origPos, cashPos,
		cashInstr, ((testCashInstr == NULL) ? (FLAG_T)FALSE : (FLAG_T)TRUE),
		totPosRisk, priceArgStp, status, (FIN_OPTINFO_STP)NULL, NULL, NULL, nullptr);

	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_TreatInstrCategorySTNForward()
**
**  Description :	New case for option based STN
**
**  Return      :   RET_SUCCEED or error code
**
** Creation	    :   PMSTA-34140 - RAK - 190104
**
*************************************************************************/
RET_CODE FIN_TreatInstrCategorySTNForward(DBA_HIER_HEAD_STP  posHierHead,
											DBA_DYNFLD_STP		 domainPtr,
											FIN_DOMAIN_ARG_STP   domainArgPtr,
											FIN_AIARG_STP        aiArgPtr,
											DBA_DYNFLD_STP       origPos,
											DBA_DYNFLD_STP       instrPtr,
											char                 instrHierFlg,
											FIN_PRICEARG_STP     priceArgStp,
											RISK_QTY_STP		 riskQtyStp,
											RISK_ANALYSIS_ENUM   status)
{

	FIN_EXCHARG_ST       exchArgSt;
	DBA_DYNFLD_STP       totPosRisk = nullptr, *compoTab = nullptr, *legsTab = nullptr;
	int					 i, compoNbr = 0, legsNbr=0;
	RET_CODE			 ret = RET_SUCCEED;
	DBA_DYNFLD_STP		 optionPtr = nullptr;
	FLAG_T				 hierFlg;
	FIN_OPTINFO_ST		 optInfoSt;
	RISK_QTY_ST			 riskQtySt;

	memset(&optInfoSt, 0, sizeof(FIN_OPTINFO_ST));
	memset(&riskQtySt, 0, sizeof(RISK_QTY_ST));

	MemoryPool mp;

	/* Use domain parameter option_risk_rule_e for structured notes too */
	/* With value = 0, structured notes will not be treated for risk exposure (Risk view = Accounting view). */
	if (domainArgPtr->optDeltaRule == OptDelta_None)
	{
		FIN_SetRiskPosNoExposure(domainArgPtr, status, origPos);
		return(RET_SUCCEED);
	}

	memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));
	DBA_InitConnectNoToExchArg(&exchArgSt, posHierHead);

	/* Decomposition for the two currencies legs and verification of knock dates */
	if ((ret = FIN_FxTarkoRiskCompoInfo(posHierHead, instrPtr, domainArgPtr, &compoTab, &compoNbr)) != RET_SUCCEED)
		return(ret);



	if (compoNbr > 0)
	{
		bool deltaFlg = false;
		if (domainArgPtr->optDeltaRule == OptDelta_Delta)
		{
			deltaFlg = true;
			domainArgPtr->optDeltaRule = OptDelta_Full;
			SET_ENUM(domainPtr, A_Domain_OptRiskRuleEn, OptDelta_Full);
		}

		mp.owner(compoTab, compoNbr);

		for (i = 0; i < compoNbr; i++)
		{
			if ((totPosRisk = FIN_CreateRiskAmt(posHierHead, origPos, domainArgPtr->fromDateTime, domainArgPtr->refCurrId)) != NULL)
			{
				mp.ownerDynStp(totPosRisk);
				/* options added by RiskCompoInfo() */
				ret = FIN_GetHierInstr(posHierHead, GET_ID(compoTab[i], A_InstrCompo_InstrId), (char*)&hierFlg, &optionPtr);
				if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
					return(ret);
				riskQtySt.qty = GET_NUMBER(origPos, ExtPos_Qty)*-1.0;
				riskQtySt.STNEn = StnSpecific_FXTarkoOption;
				riskQtySt.price = GET_PRICE(compoTab[i], A_InstrCompo_BasketExerPrice); /* filled in RiskCompoInfo */
				riskQtySt.priceCurrId = GET_ID(origPos, ExtPos_PosCurrId);

				/* Update UnderlyQty according to lifetime computed in RiskCompoInfo() */
				SET_NUMBER(optionPtr, A_Instr_UnderlyQty, GET_NUMBER(compoTab[i], A_InstrCompo_Quantity));

				/* Send option in std risk treatment as Father because each have is own decomposition in two legs */
				ret = FIN_PosRiskAnalysis(posHierHead, domainPtr, domainArgPtr, aiArgPtr, origPos,
					GET_ID(optionPtr, A_Instr_Id), optionPtr, totPosRisk, &riskQtySt,
					Risk_Father, TRUE);

				mp.freeDynStp(totPosRisk);
			}
		}

		if (deltaFlg)
		{
			domainArgPtr->optDeltaRule = OptDelta_Delta;
			SET_ENUM(domainPtr, A_Domain_OptRiskRuleEn, OptDelta_Delta);
		}

		if ((totPosRisk = FIN_CreateRiskAmt(posHierHead, origPos, domainArgPtr->fromDateTime, domainArgPtr->refCurrId)) != NULL)
		{
			mp.ownerDynStp(totPosRisk);
			/* Cumul two option's positions by currency (2 legs each) */
			/* Extract with sort by currency, do total computation with the cumul of option legs */
			/* contains already main values (thanks CreateRiskAmt) */
			/* note that Karthik said : cash pos is the difference between two legs */
			/* and Krishna the account val + difference between two legs : CHOOOOOSE en put 0 in amount if necessary */
			/* -> account val + difference between two legs */
			if ((DBA_ExtractHierEltRecWithFilterSt(posHierHead, ExtPos, FALSE,
												   FIN_FilterOptionsLegs, instrPtr, FIN_CmpOptionsLegs,
												   &legsNbr, &legsTab) == RET_SUCCEED) && legsNbr %2 == 0) /* pair */
			{
				mp.owner(legsTab);	/* only array, not a copy */

				int currLegCount = 0;
				if (legsNbr > 4) /* Vanilia */
					currLegCount = 3;
				else
					currLegCount = 2;

				if (legsNbr >= 4) /* PMSTA-35440 - RAK - 190426 - Only one leg knockin : do not cumulate */
				{
					for (i = 0; i < legsNbr; i += currLegCount)
					{
						FIN_CumulOptionsLegs(posHierHead, legsTab[i], legsTab[i + 1], totPosRisk, domainArgPtr->fromDateTime);	/* And update total market value (pos and ref) */
						DBA_DelAndFreeHierEltRec(posHierHead, ExtPos, legsTab[i + 1]);

						if (currLegCount == 3)
						{
							FIN_CumulOptionsLegs(posHierHead, legsTab[i], legsTab[i + 2], totPosRisk, domainArgPtr->fromDateTime);	/* And update total market value (pos and ref) */
							DBA_DelAndFreeHierEltRec(posHierHead, ExtPos, legsTab[i + 2]);
						}
					}
				}
			}

			/* Cash leg */
			if ((ret = FIN_FxTarkoCashPos(posHierHead, domainArgPtr, aiArgPtr, &exchArgSt, origPos, instrPtr,
				                          totPosRisk, priceArgStp, Risk_LastSon)) != RET_SUCCEED)
				return(ret);
		}
	}
	return(ret);
}



/************************************************************************
**
**  Function    :   FIN_TreatInstrCategoryDCITCI()
**
**  Description :	New case for option based STN
**
**  Return      :   RET_SUCCEED or error code
**
** Creation	    :   PMSTA-34140 - RAK - 190104
**
*************************************************************************/
RET_CODE FIN_TreatInstrCategoryDCITCI(DBA_HIER_HEAD_STP		 posHierHead,
										DBA_DYNFLD_STP		 domainPtr,
										FIN_DOMAIN_ARG_STP   domainArgPtr,
										FIN_AIARG_STP        aiArgPtr,
										DBA_DYNFLD_STP       origPos,
										DBA_DYNFLD_STP       instrPtr,
										char                 instrHierFlg,
										FIN_PRICEARG_STP     priceArgStp,
										RISK_QTY_STP		 riskQtyStp,
										RISK_ANALYSIS_ENUM   status)
{
	FIN_EXCHARG_ST       exchArgSt;
	DBA_DYNFLD_STP       totPosRisk = nullptr, *compoTab = nullptr;
	int					 i, j, compoNbr = 0;
	RET_CODE			 ret = RET_SUCCEED;
	DBA_DYNFLD_STP		 underPtr = nullptr;
	FLAG_T				 hierFlg;
	FIN_OPTINFO_ST		 optInfoSt;
	RISK_QTY_ST			 riskQtySt;

	memset(&optInfoSt, 0, sizeof(FIN_OPTINFO_ST));
	memset(&riskQtySt, 0, sizeof(RISK_QTY_ST));

	MemoryPool mp;

	/* Use domain parameter option_risk_rule_e for structured notes too */
	/* With value = 0, structured notes will not be treated for risk exposure (Risk view = Accounting view). */
	if (domainArgPtr->optDeltaRule == OptDelta_None)
	{
		FIN_SetRiskPosNoExposure(domainArgPtr, status, origPos);
		return(RET_SUCCEED);
	}

	memset(&exchArgSt, 0, sizeof(FIN_EXCHARG_ST));
	DBA_InitConnectNoToExchArg(&exchArgSt, posHierHead);

	if ((ret = FIN_DCITCICompoInfo(posHierHead, instrPtr, domainArgPtr, &compoTab, &compoNbr)) != RET_SUCCEED)
		return(ret);

	mp.owner(compoTab, compoNbr);

	int orders[3];

	if (compoNbr > 0)
	{
		/* One money market : to treat first, one or two options */
		for (i = 0, j = 1; i < compoNbr && i < 3; i++)
		{
			if ((ret = DBA_GetInstrById(GET_ID(compoTab[i], A_InstrCompo_InstrId),
				TRUE, &hierFlg, &underPtr, posHierHead,	/* add in hier, no free */
				UNUSED, UNUSED)) != RET_SUCCEED)
				return(ret);

			if ((INSTRNAT_ENUM)GET_ENUM(underPtr, A_Instr_NatEn) == InstrNat_MoneyMkt)
				orders[0] = i;
			else
				orders[j++] = i;  /* 1 or 2 */

		}

		/* CumulateTotLeg = FIN_CreateRiskAmt() */
		if ((totPosRisk = FIN_CreateRiskAmt(posHierHead, origPos, domainArgPtr->fromDateTime, domainArgPtr->refCurrId)) != NULL)
		{
			mp.ownerDynStp(totPosRisk);

			/* Compute option qty */
			NUMBER_T optionQty = GET_AMOUNT(totPosRisk, RiskAmt_PosMktValAmt);

			if (GET_ENUM(instrPtr, A_Instr_ConvertInterestEn) == InstrConvertInterest_PrincipalOnly)
			{
				DBA_DYNFLD_STP extValo = nullptr;

				if (GET_EXTENSION_PTR(origPos, ExtPos_PosVal_Ext) != NULL &&
					(extValo = *(GET_EXTENSION_PTR(origPos, ExtPos_PosVal_Ext))) != NULL)
				{
					optionQty = GET_AMOUNT(extValo, PosVal_PosNetAmt);
				}
			}

			/* TCI : divides quantity on the 2 underlying options */
			if (compoNbr == 3)
				optionQty /= 2.0;

			DBA_DYNFLD_STP termEvtPtr = mp.allocDynst(FILEINFO, A_TermEvt);
			DBA_DYNFLD_STP getData = mp.allocDynst(FILEINFO, Evt_Arg);
			DbiConnectionHelper dbiConnHelper;

			for (i = 0; i < compoNbr && i < 3; i++)
			{
				ret = FIN_GetHierInstr(posHierHead, GET_ID(compoTab[orders[i]], A_InstrCompo_InstrId), (char*)&hierFlg, &underPtr);
				if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
					return(ret);

				riskQtySt.STNEn = StnSpecific_Treatment;
				riskQtySt.qty = GET_NUMBER(compoTab[orders[i]], A_InstrCompo_Quantity) * GET_NUMBER(origPos, ExtPos_Qty); /* contract size included */

				/* STEP 1 and risk decomposition */
				/* Update UnderlyQty according to lifetime computed in RiskCompoInfo() */
				/* SET_NUMBER(optionPtr, A_Instr_UnderlyQty, GET_NUMBER(compoTab[i], A_InstrCompo_Quantity)); */
				/* PMSTA-35192 - RAK - 190329 - Father : get his std price */
				if ((INSTRNAT_ENUM)GET_ENUM(underPtr, A_Instr_NatEn) == InstrNat_MoneyMkt) /* which must be first */
				{
					if ((ret = FIN_DCITCIMoneyMarketPos(posHierHead, domainArgPtr, aiArgPtr, &exchArgSt, origPos, underPtr,
						totPosRisk, priceArgStp, Risk_Son)) != RET_SUCCEED)
						return(ret);
				}
				/* STEP 2 and risk decomposition */
				else /* 1 or 2 options */ /* totPosRisk updated with the Main value - underlying MM value */
				{
					/* PMSTA-35192 - RAK - 190329 - First create a short position and then decomposed it */
					/* Send option in std risk treatment as Father because each have is own decomposition in two legs */

					/* PMSTA-35360 - RAK - 190404 - Force to use stored term_event             */
					if (GET_ID(underPtr, A_Instr_Id) < 0)
					{
						SET_ID(getData, Evt_Arg_InstrId, GET_ID(underPtr, A_Instr_ParentInstrId));
					}
					else
					{
						SET_ID(getData, Evt_Arg_InstrId, GET_ID(underPtr, A_Instr_Id));
					}
					SET_DATE(getData, Evt_Arg_ValidDate, domainArgPtr->fromDateTime.date);

					if ((ret = dbiConnHelper.dbaGet(TermEvt, UNUSED, getData, &termEvtPtr)) != RET_SUCCEED)
					{
						return(ret);
					}

					/* PMSTA-36344 - RAK - 190805 */
					if (FIN_STNKnockInStarted(domainArgPtr->fromDateTime.date, termEvtPtr, underPtr) == TRUE &&
						FIN_STNKnockOutExpired(domainArgPtr->fromDateTime.date, termEvtPtr, underPtr) == FALSE)
					{
						if ((ret == FIN_DCITCIShortPutPos(posHierHead, domainPtr, domainArgPtr, aiArgPtr, &exchArgSt, origPos, underPtr,
							                              totPosRisk, &riskQtySt, priceArgStp, optionQty)) != RET_SUCCEED)
							return(ret);
					}
				}
			}

			/* STEP 4 - offsetting cash position */
			if (compoNbr > 0)
			{
				/* Cash */
				if ((ret = FIN_RiskSTNCashPos(posHierHead, domainArgPtr, aiArgPtr, &exchArgSt, origPos, instrPtr,
					totPosRisk, priceArgStp, Risk_LastSon)) != RET_SUCCEED)
					return(ret);
			}
		}
	}
	return(ret);
}

/************************************************************************
**
**  Function    :   FIN_STNAverageBasketMarketPrice()
**
**  Description :   Calculate the average market price of structure note category 'Average Basket'
**
**  Return      :   RET_SUCCEED
**
** Creation	    :   PMSTA-32504 - SIL - 190123
**
*************************************************************************/

STATIC RET_CODE FIN_STNAverageBasketMarketPrice(DBA_HIER_HEAD_STP     posHierHead,
                                                FIN_DOMAIN_ARG_STP    domainArgPtr,
                                                DBA_DYNFLD_STP        origPos,
                                                DBA_DYNFLD_STP	      STNPtr,
                                                PRICE_T              *marketPrice,
                                                FIN_PRICEARG_STP      priceArgStp
    )
{
    DBA_DYNFLD_STP   *selInstrCompoTab, underPtr = nullptr, riskPos = nullptr, prPtr = nullptr;
    int				 i, selInstrCompoNbr = 0;
    FLAG_T			 hierFlg;
    RET_CODE		 ret = RET_SUCCEED;

    MemoryPool  mp;

    ret = FIN_SelectUnderlyingCompo(posHierHead, domainArgPtr->fromDateTime, STNPtr, &selInstrCompoTab, &selInstrCompoNbr);

    if (ret == RET_SUCCEED)
    {
        mp.owner(selInstrCompoTab, selInstrCompoNbr);

        for (i = 0; i < selInstrCompoNbr; i++)
        {
            ret = FIN_GetHierInstr(posHierHead, GET_ID(selInstrCompoTab[i], A_InstrCompo_InstrId), (char*)&hierFlg, &underPtr);

            if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
            {
                return(ret);
            }

            riskPos = mp.allocDynst(FILEINFO,ExtPos);

            COPY_DYNST(riskPos, origPos, ExtPos);

            prPtr = mp.allocDynst(FILEINFO, A_InstrPrice);


            ret = FIN_PosPrice(riskPos, underPtr, GET_DATETIME(riskPos, ExtPos_ExtPosDate),
                priceArgStp, prPtr,
                NULL, posHierHead);

            *marketPrice = *marketPrice + (GET_PRICE(prPtr, A_InstrPrice_Price)* (GET_PERCENT(selInstrCompoTab[i], A_InstrCompo_BasketWeightP)/100));
        }
    }
    return ret;
}



/************************************************************************
**
**  Function    :   FIN_STNAverageBasketBarrierPrice()
**
**  Description :   Calculate the average barrier price of structure note category 'Average Basket'
**                  barrier price = costprice * barrier_levelp
**
**  Return      :   RET_SUCCEED
**
** Creation	    :   PMSTA-32504 - SIL - 190123
**
*************************************************************************/

STATIC RET_CODE FIN_STNAverageBasketBarrierPrice(DBA_HIER_HEAD_STP     posHierHead,
                                           FIN_DOMAIN_ARG_STP    domainArgPtr,
                                           DBA_DYNFLD_STP        origPos,
                                           DBA_DYNFLD_STP	     STNPtr,
                                           PRICE_T              *barrierPrice,
                                           FIN_EXCHARG_STP	     exchArgStp,
                                           FIN_PRICEARG_STP      priceArgStp
    )
{
    DBA_DYNFLD_STP       *selInstrCompoTab, underPtr = nullptr, riskPos = nullptr;
    int				     i, selInstrCompoNbr = 0;
    PRICE_T              costPrice = 0.0;
    NUMBER_T		 exch;
    FLAG_T			     hierFlg;
    RET_CODE		     ret = RET_SUCCEED;
    ID_T				 costPriceCurrId = ZERO_ID;
    RISKCOSTRULE_ENUM	 stnCostRule;


    MemoryPool  mp;

    /* Price is underlying price at begin date of the position */
    /* or exercise price of the option founded in term event   */
    GEN_GetApplInfo(ApplRiskStnCostRule, &stnCostRule);

    ret = FIN_SelectUnderlyingCompo(posHierHead, domainArgPtr->fromDateTime, STNPtr, &selInstrCompoTab, &selInstrCompoNbr);

    if (ret == RET_SUCCEED)
    {
        mp.owner(selInstrCompoTab, selInstrCompoNbr);

        for (i = 0; i < selInstrCompoNbr; i++)
        {
            ret = FIN_GetHierInstr(posHierHead, GET_ID(selInstrCompoTab[i], A_InstrCompo_InstrId), (char*)&hierFlg, &underPtr);

            if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
            {
                return(ret);
            }

            switch (stnCostRule)
            {
            case RiskCostRule_ClosingPrice:
            {
                /* A_Instr_UnderlyFixingPrice in case of Single Instrument */
                costPrice = GET_PRICE(selInstrCompoTab[i], A_InstrCompo_BasketFixingPrice);
                costPriceCurrId = GET_ID(underPtr, A_Instr_RefCurrId); /* or underlying instrument ref currency */
                break;
            }
            case RiskCostRule_ExercisePrice:
            default:
            {
                /* A_Instr_ExerQuote in case of Single Instrument */
                costPrice = GET_PRICE(selInstrCompoTab[i], A_InstrCompo_BasketExerPrice);
                costPriceCurrId = GET_ID(underPtr, A_Instr_RefCurrId); /* or underlying instrument ref currency */
                break;
            }
           }

            /* Convert price in position currency */
            riskPos = mp.allocDynst(FILEINFO,ExtPos);

            COPY_DYNST(riskPos, origPos, ExtPos);

            FIN_GetExchRate(GET_DATETIME(riskPos, ExtPos_BegDate),
                costPriceCurrId, GET_ID(riskPos, ExtPos_PosCurrId),
                (ID_T)0, NULL, riskPos, exchArgStp, &exch);	/* PMSTA01649 - TGU - 070405 */

            costPrice *= exch;

            *barrierPrice = *barrierPrice +
                ((costPrice * (GET_PERCENT(selInstrCompoTab[i], A_InstrCompo_BasketBarrierP)/100))* (GET_PERCENT(selInstrCompoTab[i], A_InstrCompo_BasketWeightP)/100));
        }
    }
    return ret;
}

/************************************************************************
**      END  finrisk01.c                                         UNICIBLE
*************************************************************************/

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      global variables 
*************************************************************************/
static int DFTStatus;

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define STDLIB_H

#include "unidef.h"         /* Mandatory */
#include "gen.h"
#include "dft.h"
#include "syslib.h"


/************************************************************************
**
**  Function    :   DFT_Enable()
**
**  Description :   This function set the STATIC global variable DFTStatus to TRUE
**                 
**  Arguments   :   
**                  
**
**  Return      :   
**
*************************************************************************/
void DFT_Enable()
{

    DFTStatus = TRUE;

}

/************************************************************************
**
**  Function    :   DFT_Disable()
**
**  Description :   This function set the STATIC global variable DFTStatus to FALSE
**                 
**  Arguments   :   
**                  
**
**  Return      :   
**
*************************************************************************/
void DFT_Disable()
{

	DFTStatus = FALSE;

}


/************************************************************************
**
**  Function    :   DFT_WaitToBeUnlocked()
**
**  Description :   This function is for testing purpose only.
**                  It is used to freezes the fusion process and the dispatcher process at each critical step.
**                  If a "lock file"(according to the lock name) exists,a "wait file" is created (according to the lock name).

**                 
**  Arguments   :   lockname : Name of the lock. This name is used to create a wait file and to check for a lock file.
**                  
**
**  Return      :   
**
**  Last modif. : PMSTA-13729 - 040412 - PMO : Full support of 64bit on Unix platforms
**
*************************************************************************/
void DFT_WaitToBeUnlocked(const char *lockname)
{

    if(TRUE == DFTStatus)
    {
    
        char lockFileName[256]; /* Path for .lock file */
        char waitFileName[256]; /* Path for .wait file */
        FILEDES hFile = NULL;   /* PMSTA-13729 - 040412 - PMO */
        int createdFile = FALSE; /* To check the file creation */

        snprintf(lockFileName, sizeof(lockFileName), "%s/%s.lock", GEN_GetPath(MsgDir), lockname);
        snprintf(waitFileName, sizeof(waitFileName), "%s/%s.wait", GEN_GetPath(MsgDir), lockname);
                                                           
        while(SYS_Access(lockFileName) == TRUE) /* while the "lock file" exists */
        {

            if(FALSE == createdFile && RET_SUCCEED == SYS_OpenFile(waitFileName,OPEN_CREATE_FILE|OPEN_READ_MODE,&hFile))
            {
                createdFile = TRUE;
            }


            SYS_MilliSleep(250);            
         }
						
         if (TRUE == createdFile)
         {
             SYS_CloseFile(hFile);
             SYS_DeleteFile(waitFileName);
         }
                                             
    }

}


/************************************************************************
**      END          dft.c                                    ODYSSEY
*************************************************************************/

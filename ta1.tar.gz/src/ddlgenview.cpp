/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DDLGENVIEW_CPP

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H

#include      "unidef.h"     /* Mandatory */
#include         "gen.h"
#include         "dba.h"
#include   "ddlgenview.h"

using namespace std;

/************************************************************************
**      External entry points
**
*************************************************************************/

/************************************************************************
**      Local functions
**
*************************************************************************/

/************************************************************************
**      Static definitions & data
**
*************************************************************************/

/************************************************************************
**      FONCTIONS
**
************************************************************************/

/************************************************************************
**
**  Function    :   DdlGenView::DdlGenView()
**
**  Description :   Constructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
DdlGenView::DdlGenView(OBJECT_ENUM        paramObjectEn,
                       DDL_VIEW_ENUM      paramViewEn,
                       DdlGenContext     &paramDdlGenContext,
                       DdlGenEntity      *paramDdlGenEntityPtr,
                       DdlGenFile        *paramFileHelper,
                       TARGET_TABLE_ENUM  paramTargetTableEn):DdlGen(paramObjectEn, DdlObj_View, paramDdlGenContext, NULL, paramDdlGenEntityPtr, paramFileHelper, paramTargetTableEn)
{
    this->m_viewEn   = paramViewEn;
    this->ddlGenContextPtr->setViewEn(this->m_viewEn);

    init(paramObjectEn,
         DynType_Null,
         FALSE,
         FALSE,
         FALSE,
         EntSecuLevel_NoSecured,
         FALSE);

    this->bNestedRequest = true;

    this->setName();
}

/************************************************************************
**
**  Function    :   DdlGenView::~DdlGenView()
**
**  Description :   Destructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
DdlGenView::~DdlGenView()
{
    this->ddlGenContextPtr->setViewEn(View_None);
}

/************************************************************************
**
**  Function    :   DdlGenView::setViewEn()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenView::setViewEn(DDL_VIEW_ENUM paramViewEn)
{
    this->m_viewEn   = paramViewEn;

    this->ddlGenContextPtr->setViewEn(this->m_viewEn);

    init(this->getObjectEn(),
         DynType_Null,
         FALSE,
         FALSE,
         FALSE,
         EntSecuLevel_NoSecured,
         FALSE);

    this->setName();
    this->setDefaultFromViewEn();

    /* PRO-12675 - LJE - 191204 */
    if (this->m_viewEn == View_ForUpdateByTech)
    {
        this->bForceDPInAppContext = true;
    }

    return RET_SUCCEED;
}

/************************************************************************
**
**  Function    :   DdlGenView::getBaseSqlName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-nuodb - LJE - 190503
**
*************************************************************************/
std::string DdlGenView::getBaseSqlName(DICT_ENTITY_STP dictEntityStp)
{
    if (strlen(dictEntityStp->mdSqlName) > 26 &&
        dictEntityStp->shortSqlname[0] != 0)
    {
        return dictEntityStp->shortSqlname;
    }
    return dictEntityStp->mdSqlName;
}

/************************************************************************
**
**  Function    :   DdlGenView::getVewSep()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26250 - LJE - 170327
**
*************************************************************************/
std::string DdlGenView::getVewSep(DDL_GEN_MODE_ENUM ddlGenMode)
{
    switch (ddlGenMode)
    {
        case DdlGenMode_Shadow:
            return "$";
            break;

        case DdlGenMode_Standard:
        default:
            return "_";
            break;
    }
}

/************************************************************************
**
**  Function    :   DdlGenView::getVewSep()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26250 - LJE - 170327
**
*************************************************************************/
std::string DdlGenView::getVewSep()
{
    return (DdlGenView::getVewSep(this->ddlGenContextPtr->getDdlGenMode()));
}

/************************************************************************
**
**  Function    :   DdlGenView::getName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-nuodb - LJE - 190503
**
*************************************************************************/
std::string DdlGenView::getName(DICT_ENTITY_STP dictEntityStp, DDL_VIEW_ENUM viewEn, DDL_GEN_MODE_ENUM ddlGenMode)
{
    string viewName(DdlGenView::getBaseSqlName(dictEntityStp));

    viewName += DdlGenView::getVewSep(ddlGenMode) + DdlGenView::getViewExtension(viewEn);

    return viewName;
}

/************************************************************************
**
**  Function    :   DdlGenView::getViewExtension()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
std::string DdlGenView::getViewExtension(DDL_VIEW_ENUM viewEn)
{
    string extStr;

    switch (viewEn)
    {
        case View_FullAllSecured:
            extStr = "vw";
            break;
        case View_FullAll:
            extStr = "uvw";
            break;
        case View_LightAll:
            extStr = "lvw";
            break;
        case View_ShortSecured:
            extStr = "svw";
            break;
        case View_Short:
            extStr = "usv";
            break;
        case View_FullAll4ForeignKey:
            extStr = "fkv";
            break;
        case View_AllSecured:
            extStr = "mvw";
            break;
        case View_ForUpdateByTech:
            extStr = "ovw";
            break;
        case View_MultiEntitySpec:
            extStr = "me";
            break;
        case View_Export:
            extStr = "evw";
            break;
        case View_MainTable:
            extStr = "tvw";
            break;
        /* PMSTA-nuodb - LJE - 190617 */
        case View_Tech:
            extStr = "xvw";
            break;

        case View_Shadow:
        default:
            break;
    }

    return extStr;
}

/************************************************************************
**
**  Function    :   DdlGenView::setName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenView::setName()
{
    RET_CODE            ret=RET_SUCCEED;

    if (this->m_viewEn == View_Custom ||
        this->m_viewEn == View_User)
    {
        return ret;
    }

    string ddlObjSqlName = this->getDdlGenContextPtr()->ddlGenAction.m_sqlnameOptStr; /* WEALTH-9627 - LJE - 240625 */

    if (ddlObjSqlName.empty())
    {
        ddlObjSqlName = this->m_ddlObjBaseName + this->getVewSep();

        switch (this->m_viewEn)
        {
            case View_FullAllSecured:
                if (this->ddlGenContextPtr->ddlGenAction.m_execModeEn == DbObjExecMod_BuildFromTemplate)
                {
                    ddlObjSqlName = this->getEntitySqlName();
                    break;
                }

            case View_FullAll:
            case View_LightAll:
            case View_ShortSecured:
            case View_Short:
            case View_FullAll4ForeignKey:
            case View_AllSecured:
            case View_ForUpdateByTech:
            case View_Shadow:
            case View_MultiEntitySpec:
            case View_Export:
            case View_MainTable:
            case View_Tech:
                ddlObjSqlName.append(this->getViewExtension(this->m_viewEn));
                break;

            default:
                ddlObjSqlName = this->getEntitySqlName();
                break;
        }
    }
    
    this->setDdlObjSqlName(ddlObjSqlName);
    this->ddlGenContextPtr->setMsgSqlName(ddlObjSqlName);
    this->ddlGenContextPtr->ddlObjSqlName = ddlObjSqlName;
    this->setDdlObjFullSqlName(this->ddlGenContextPtr->getDdlDestDbName(), ddlObjSqlName);

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenView::setGroupToGrant()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenView::setGroupToGrant()
{
    RET_CODE            ret=RET_SUCCEED;

    switch (this->m_viewEn)
    {
    case View_FullAllSecured:
    case View_ShortSecured:
    case View_User:
    case View_Export: /* PMSTA-29982 - LJE - 180209 */
    case View_LightAll:
        this->bodySqlBlock << " to " << this->getCmdRole("triplea") << ", " << this->getCmdRole("tasc_tech");
        break;

    case View_Short:
    case View_FullAll4ForeignKey: /* OCS-41131 - LJE - 120723 */ /* PMSTA-14452 - LJE - 121219 - Move here... */
    case View_AllSecured:         /* PMSTA-43625 - LJE - 210308 */
    case View_ForUpdateByTech:
    case View_MainTable:          /* PMSTA-30395 - LJE - 180409 */
    case View_FullAll:            /* PMSTA-44452 - LJE -  210322 - OCS need access to this view */
        this->bodySqlBlock << " to " << this->getCmdRole("tasc_tech");
        break;

    default:
         /* No grant */
        ret = RET_GEN_INFO_NOACTION;
        break;
   }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenView::setAccessToGrant()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenView::setAccessToGrant()
{
    RET_CODE            ret=RET_SUCCEED;
    bool                bInsert=false, bGrantSelect=false, bUpdate=false, bDelete=false, bFirst=true;

    if (this->m_viewEn != View_ShortSecured) /* PRO-12675 - LJE - 191204 */
    {
        if (this->getObjectEn() == Audit ||
            this->getObjectEn() == Event )
        {
            bInsert = true;
        }
        else if (this->getDictEntityStp()->securityLevelEn == EntSecuLevel_FullAccessByView ||
                 this->getDictEntityStp()->entNatEn == EntityNat_Tsl)
        {
            bInsert = true;
            bUpdate = true;
            bDelete = true;
        }
    }

    switch (this->m_viewEn)
    {
        case View_FullAllSecured:
        case View_LightAll:
        case View_Short:
        case View_FullAll:
        case View_ShortSecured:
        case View_FullAll4ForeignKey: /* OCS-41131 - LJE - 120723 */
        case View_AllSecured:         /* PMSTA-43625 - LJE - 210308 */
        /* PMSTA-14785 - LJE - 120827 */
        case View_User:
        case View_Export: /* PMSTA-29982 - LJE - 180209 */
        case View_MainTable:
            bGrantSelect = true;
            break;

        case View_ForUpdateByTech:
            bGrantSelect = true;
            bUpdate = true;
            break;

        case View_Tech:                 /* PMSTA-nuodb - LJE - 190617 */
        case View_Shadow:
        case View_MultiEntitySpec:      /* PMSTA-26108 - LJE - 170904 */
        default:
            /* No grant */
            bInsert = false;
            bGrantSelect = false;
            bUpdate = false;
            bDelete = false;
            ret = RET_GEN_INFO_NOACTION;
            break;
    }

    if (bGrantSelect)
    {
        this->bodySqlBlock << "select";
        bFirst = false;
    }
    if (bInsert)
    {
        if (bFirst == false)
        {
            this->bodySqlBlock << ", ";
        }
        this->bodySqlBlock << "insert";
        bFirst = false;
    }
    if (bUpdate)
    {
        if (bFirst == false)
        {
            this->bodySqlBlock << ", ";
        }
        this->bodySqlBlock << "update";
        bFirst = false;
    }
    if (bDelete)
    {
        if (bFirst == false)
        {
            this->bodySqlBlock << ", ";
        }
        this->bodySqlBlock << "delete";
        bFirst = false;
    }

    return ret;
}

/************************************************************************
**
**  Function    :   baGenViewDdl::drop()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenView::drop()
{
    if (this->isReplaceAllowed(DdlObj_View) == false)
    {
        if (EV_GenDdlContext.bSqlFileOnly)
        {
            this->bodySqlBlock
                << this->getCmdPrintMsg("Dropping view " + this->getDdlObjSqlName(), false) << endl
                << this->getCmdGo() << endl;
        }

        this->cmdType = DDlCmdType_Drop;

        this->bodySqlBlock.clear();

        if (this->isIfExistsClause(this->getDdlObjEn()))
        {
            this->bodySqlBlock << this->getCmdDrop(this->ddlGenContextPtr->getDdlDestDbName(), this->getEntitySqlName(), this->getDdlObjSqlName(), DdlObj_View);
        }
        else
        {
            this->bodySqlBlock <<
                this->getCmdIfExsists(this->getCmdSelObjInDb(this->ddlGenContextPtr->getDdlDestDbName(), this->getEntitySqlName(), this->getDdlObjSqlName(), DdlObj_View),
                                      "\t" + this->getDdlModif(this->getCmdDrop(this->ddlGenContextPtr->getDdlDestDbName(), this->getEntitySqlName(), this->getDdlObjSqlName(), DdlObj_View)),
                                      string());
        }
        return this->flush();
    }

    return RET_SUCCEED;
}

/************************************************************************
**
**  Function    :   baGenViewDdl::setUser()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14785 - LJE - 120827
**
*************************************************************************/
RET_CODE DdlGenView::setUser(string user_name)
{
    this->bodySqlBlock.clear();

    this->bodySqlBlock << "setuser";
    if(user_name.empty() == false)
    {
        this->bodySqlBlock << " '" << user_name << "'";
    }
    return this->flush();
}

/************************************************************************
**
**  Function    :   DdlGenView::printHeader()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14452 - EFE - 130208
**
*************************************************************************/
RET_CODE DdlGenView::printHeader()
{
    RET_CODE          ret=RET_SUCCEED;

    ret = DdlGen::printHeader();

    this->headerStream << this->newLine() << this->getCmdCreate(this->ddlGenContextPtr->getDdlDestDbName(),
                                                                this->getEntitySqlName(),
                                                                this->getDdlObjSqlName(),
                                                                DdlObj_View) << " as ";
    return ( ret ) ;
}

/************************************************************************
**
**  Function    :   DdlGenView::setDefaultFromViewEn()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-49487 - LJE - 220721
**
*************************************************************************/
void DdlGenView::setDefaultFromViewEn()
{
    switch (this->m_viewEn)
    {
        case View_Export: /* PMSTA-29982 - LJE - 180209 */
        case View_FullAllSecured:
            this->bManageAuthFlg = true;                          /* PMSTA-14607 - LJE - 120712 */
            this->securityLevelEn = this->getDefSecuredLevel();   /* PMSTA-14607 - LJE - 120710 */
            this->outputDynNatEn = DynType_All;
            this->precompFlg = TRUE;
            this->custFlg = TRUE;
            break;

        case View_FullAll:
            this->outputDynNatEn = DynType_All;
            this->precompFlg = TRUE;
            this->custFlg = TRUE;
            this->ddlGenContextPtr->bAvoidSecured = true;
            break;

        case View_MainTable:
            this->outputDynNatEn = DynType_All;
            break;

        case View_Tech:
            this->outputDynNatEn = DynType_All;
            this->precompFlg = FALSE;
            this->custFlg = TRUE;
            this->securityLevelEn = EntSecuLevel_NoSecured;
            this->mulitEntityAccessEn = MultiEntityAccess_None;
            this->ddlGenContextPtr->bAvoidMultiEntity = true;
            this->ddlGenContextPtr->bForceTableName = true;
            break;

        case View_LightAll:
            this->securityLevelEn = this->getDefSecuredLevel(); /* PMSTA-14607 - LJE - 120710 */ /* PMSTA-26505 - TEB - 170306 */
            this->outputDynNatEn = DynType_All;
            this->bForceDPInAppContext = true;                       /* PMSTA-36919 - LJE - 191209 */
            break;

            /* OCS-41131 - LJE - 120723 */
        case View_FullAll4ForeignKey:
            this->bForceDPInAppContext = true;
            if (this->ddlGenContextPtr->isEnableSecuOnFkView())
            {
                this->securityLevelEn = this->getDefSecuredLevel();
            }
            this->outputDynNatEn = DynType_All;
            this->precompFlg = TRUE;
            this->custFlg = TRUE;
            break;

            /* PMSTA-43625 - LJE - 210308 */
        case View_AllSecured:
            this->bForceDPInAppContext = true;
            this->securityLevelEn = this->getDefSecuredLevel();
            this->outputDynNatEn = DynType_All;
            this->precompFlg = TRUE;
            this->custFlg = TRUE;
            break;

        case View_ShortSecured:
            this->precompFlg = TRUE;
            this->custFlg = TRUE;
            this->securityLevelEn = this->getDefSecuredLevel();
            this->bManageAuthFlg = true;                          /* PMSTA-14607 - LJE - 120712 */
            this->outputDynNatEn = DynType_ShortAllDb;            /* PMSTA-29879 - LJE - 180704 */
            this->translateFlg = TRUE;                          /* PMSTA-29879 - LJE - 180712 */
            break;

        case View_Short: /* PMSTA-13109 - LJE - 111202 */
            this->outputDynNatEn = DynType_Short;
            break;

            /* PMSTA-26250 - LJE - 170327 */
        case View_Shadow:
            this->outputDynNatEn = DynType_AllDb;
            this->bHidePrecomp = true;
            this->bShadowAccess = true;
            this->custFlg = TRUE;

            if (this->getDictEntityStp()->shadowEntityStp)
            {
                this->realDictEntityStp = this->getDictEntityStp()->shadowEntityStp;
                this->realObjectEn = this->realDictEntityStp->objectEn;
                this->realSqlName = this->realDictEntityStp->mdSqlName;
            }
            break;

            /* PMSTA-26108 - LJE - 170904 */
        case View_MultiEntitySpec:
            this->outputDynNatEn = DynType_AllDb;
            if (this->getDictEntityStp()->multiEntityCateg.isPartialSpecialzed())
            {
                this->mulitEntityAccessEn = MultiEntityAccess_PartialSpecialization;
            }
            else
            {
                this->mulitEntityAccessEn = MultiEntityAccess_OptionalLocalization;
            }

            this->bHidePrecomp = true;
            this->custFlg = TRUE;
            break;

    }

    /* PMSTA-29879 - LJE - 180212 */
    if (this->m_viewEn == View_Export)
    {
        this->bManageAuthFlg = false;
        this->ddlGenContextPtr->bForceConnEntity = true;
    }

    if (this->custFlg == TRUE &&
        (this->getDictEntityStp()->custAuthFlg == FALSE || this->udTableName.empty()))
    {
        this->custFlg = FALSE;
    }

    if (this->precompFlg == TRUE &&
        (this->getDictEntityStp()->precompFlg == FALSE ||
         this->getDictEntityStp()->usePrecompFlg == FALSE ||
         this->getDictEntityStp()->precompSqlName[0] == 0))
    {
        this->precompFlg = FALSE;
    }
}

/************************************************************************
**
**  Function    :   DdlGenView::create()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenView::create()
{
    RET_CODE    ret = RET_SUCCEED;

    if (EV_GenDdlContext.bSqlFileOnly)
    {
        this->bodySqlBlock
            << this->getCmdPrintMsg("Creating view " + this->getDdlObjSqlName(), false) << endl
            << this->getCmdGo() << endl;
        ret = this->flush();
    }

    this->cmdType = DDlCmdType_Create;

    this->securityLevelEn      = EntSecuLevel_NoSecured;
    this->thirdCompoSecuredFlg = FALSE;
    this->thirdSecuredFlg      = FALSE;
    this->custFlg              = FALSE;
    this->precompFlg           = FALSE;
    this->bHidePrecomp         = false;
    this->bManageAuthFlg       = false;          /* PMSTA-14607 - LJE - 120712 */
    this->bUserSecured         = false;            /* PMSTA-14607 - LJE - 120712 */
    this->bForceDPInAppContext = false;    /* OCS-41131 - LJE - 120723 */
    this->bForceDPInSuserName  = false;     /* PMSTA-14785 - LJE - 120829 */
    this->bShadowAccess        = false;           /* PMSTA-26250 - LJE - 170327 */

    this->setDefaultFromViewEn();   /* PMSTA-49487 - LJE - 220721 */

    if (this->ddlGenContextPtr->ddlGenAction.m_execModeEn != DbObjExecMod_BuildFromTemplate)
    {
        if ((this->m_viewEn == View_MainTable && this->getDictEntityStp()->isPhysicalEntity(this->targetTableEn) == false) ||     /* PMSTA-33859 - LJE - 181218 */
            (this->outputDynNatEn == DynType_All && this->getDictEntityStp()->allDictCriteriaMap.size() == 0) ||
            (this->outputDynNatEn == DynType_Short && this->getDictEntityStp()->shortDictCriteriaMap.size() == 0))
        {
            return RET_GEN_INFO_NOACTION;
        }
    }

    if ((ret = this->initRequest()) != RET_SUCCEED)
        return ret;

    /* PMSTA-26250 - LJE - 170613 */
    if (this->ddlGenContextPtr->getDdlGenMode() == DdlGenMode_Shadow &&
        this->getDictEntityStp()->changeSetAuthEn == FeatureAuth_Enable &&
        this->getDictEntityStp()->shadowEntityStp)
    {
        this->realDictEntityStp = this->getDictEntityStp()->shadowEntityStp;
        this->realObjectEn      = this->realDictEntityStp->objectEn;
        this->realSqlName       = this->realDictEntityStp->mdSqlName;
    }

    if (this->getEntityFullSqlName() == this->getDdlObjFullSqlName())
    {
        return RET_GEN_INFO_NOACTION;
    }

    if ((ret = this->printHeader()) != RET_SUCCEED) /* PMSTA-14452- EFE-130208*/
    {
        return ret;
    }

    ret = this->printSelListRequest();

    /* PMSTA-26250 - LJE - 170613 */
    if (this->ddlGenContextPtr->getDdlGenMode() == DdlGenMode_Shadow &&
        this->getDictEntityStp()->changeSetAuthEn == FeatureAuth_Enable &&
        this->getDictEntityStp()->shadowEntityStp)
    {
        this->realDictEntityStp = nullptr;
        this->realObjectEn      = InvalidEntity;
        this->realSqlName.clear();
    }


    if (ret == RET_SUCCEED &&
        (ret = this->printFromRequest()) == RET_SUCCEED &&
        (ret = this->printWhereRequest()) == RET_SUCCEED)
    {
        /* OCS-39654 - LJE - 120213 */
        if (this->thirdCompoSecuredFlg == TRUE ||
            (this->mulitEntityAccessEn != MultiEntityAccess_None && this->getDictEntityStp()->multiEntityCateg.isOnlyInMaster() == false)) /* PMSTA-26108 - LJE - 170905 */
        {
            this->bodySqlBlock
                << this->selListStream.str()
                << this->m_mainFromStream.str()
                << this->m_fromStream.str()
                << this->whereStream.str()
                << this->orderStream.str()
                << this->limitStream.str();

            this->selListStream.clear();
            this->selListStream.str(std::string());
            this->m_mainFromStream.clear();
            this->m_mainFromStream.str(std::string());
            this->m_fromStream.clear();
            this->m_fromStream.str(std::string());
            this->addFromStream.clear();
            this->addFromStream.str(std::string());
            this->whereStream.clear();
            this->whereStream.str(std::string());
            this->pscFromStr.clear();
            this->pscWhereStr.clear();
            this->orderStream.clear();
            this->orderStream.str(std::string());
            this->limitStream.clear();
            this->limitStream.str(std::string());

            this->bSelectPrinted = false;
            this->m_bWherePrinted = false;
            this->bUserJoinPrint = false;

            this->thirdCompoSecuredFlg = FALSE;
            this->mulitEntityAccessEn  = MultiEntityAccess_None;

            this->bodySqlBlock << this->newLine() << "union all ";

            if ((ret = this->printSelListRequest()) == RET_SUCCEED &&
                (ret = this->printFromRequest()) == RET_SUCCEED &&
                (ret = this->printWhereRequest()) == RET_SUCCEED)
            {
                this->footerStream << getCmdEndDDLObj();

                ret = this->flush();
            }
        }
        else
        {
            this->footerStream << getCmdEndDDLObj();

            ret = this->flush();
        }
    }

    this->bManageAuthFlg = false;    /* PMSTA-14607 - LJE - 120712 */
    this->bUserSecured = false;    /* PMSTA-14607 - LJE - 120712 */
    this->bForceDPInAppContext = false;    /* OCS-41131 - LJE - 120723 */
    this->bForceDPInSuserName = false;    /* PMSTA-14785 - LJE - 120829 */

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenView::grant()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenView::grant()
{
    RET_CODE            ret=RET_SUCCEED;

    this->cmdType = DDlCmdType_Grant;

    this->bodySqlBlock << "grant ";

    ret = this->setAccessToGrant();

    /* PMSTA-26250 - LJE - 170407 */
    if (ret == RET_SUCCEED)
    {
        this->bodySqlBlock << " on " << this->getDdlObjFullSqlName();
        if ((ret = this->setGroupToGrant()) == RET_SUCCEED)
        {
            this->bodySqlBlock << getCmdEndDDLObj();

            ret = this->flush();
        }
    }
    else if (ret == RET_GEN_INFO_NOACTION)
    {
        /* PMSTA-37366 - LJE - 200210 - Temporary work-around (https://support.nuodb.com/hc/en-us/requests/10952?page=1) */
        if (this->ddlGenContextPtr->m_rdbmsEn == Nuodb)
        {
            this->bodySqlBlock << "select on " << this->getDdlObjFullSqlName()
                << " to " << this->getCmdRole("triplea") << ", " << this->getCmdRole("tasc_tech") << this->getCmdEndDDLObj();
            this->bodySqlBlock << getCmdEndDDLObj();

            ret = this->flush();
        }

        return RET_SUCCEED;
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenView::build()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenView::build()
{
    RET_CODE ret=RET_SUCCEED;

    if (this->m_viewEn == View_Shadow &&
        this->ddlGenContextPtr->getDdlGenMode() == DdlGenMode_Shadow)
    {
        return RET_SUCCEED;
    }

    this->printMsg(RET_SRV_INFO_RUNNING, "Creating");

    if ((ret = DdlGen::build()) != RET_SUCCEED)
    {
        this->printMsg(ret, "Failed");
        return ret;
    }

    if (RET_GET_LEVEL((ret = this->drop())) == RET_LEV_ERROR ||
        RET_GET_LEVEL((ret = this->create())) == RET_LEV_ERROR)
    {
        this->printMsg(ret, "Failed");
        return ret;
    }

    if (ret == RET_SUCCEED &&
        RET_GET_LEVEL((ret = this->grant())) == RET_LEV_ERROR)
    {
        this->printMsg(ret, "Failed");
        return ret;
    }

    this->ddlGenContextPtr->resetContext(this->getDdlObjSqlName());

    this->printMsg(RET_SRV_INFO_DONE, "Done");

    return ret;
}


/************************************************************************
**
**  Function    :   DdlGen::printFooter()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14452 - LJE - 130114
**
**  Modif       :
**
*************************************************************************/
RET_CODE DdlGenView::printFooter()
{
    RET_CODE          ret = RET_SUCCEED;
    this->bodySqlBlock << this->getCmdEndDDLObj();
    return ret;
}

/*************************************************************************
**   END  ddlgenview.cpp                                        Odyssey **
*************************************************************************/


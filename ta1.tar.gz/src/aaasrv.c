/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define AAASRV_C

#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H

/************************************************************************
**      Include files
*************************************************************************/
#ifdef NTWIN
#include <windows.h>        /* REF8728 - 030311 - PMO */
#include "sysnt.h"  /* REF7264 - PMO */
extern char SV_KeywordNT[64];
#endif

#include "unidef.h"     /* Mandatory */
#include "serv.h"
#include "servdisp.h"
#include "ddlgen.h"
#include "httpclient.h"
#include "httpserver.h"     /* PMSTA-19737 - 270516 - PMO */
#include "sig.h"
#include "csrv.h"
#include "cstypes.h"


#ifndef CALLSTACK_H
#include "callstack.h"
#endif

#include "main.h"

#include "twac.h"

/************************************************************************
**      External entry points
**
*************************************************************************/

extern int EV_NewOptiListSize;
extern char SV_FlgLoginPassed; /* PMSTA-CARG - DDV - 130426 - No more static, they can be during cfg file load */
extern char SV_User[MAX_USERINFO_LEN + 1];

extern bool EV_IsProxyServer;

extern char SV_ServerLogFileName[256];
extern int  SV_ServerMode,
            SV_ServerInitFlg;

extern RET_CODE FIN_CallOAuthServiceJWKSEndPoint();

/************************************************************************
**      Static definitions & data
**
*************************************************************************/

static RET_CODE SV_LoginOk = FALSE;

/************************************************************************
*   Function             : initCallback()
*
*   Description          : Free the memory allocated by SERV_AllocateThreadServInfo
*
*   Arguments            : None
*
*   Functions call       : None
*
*   Return               : None
*
*   Creation Date        : PMSTA-19735 - 020415 - PMO : OpenServer / P1 / Thread handling
*
*   Last Modif.          : PMSTA-24076 - 180716 - PMO : Unstable connections
*
*************************************************************************/
void initCallback()
{
    SYS_SetCallBackThreadDataCtxGeneric(GEN_ThreadDataCtxGenericCreate
                                       ,GEN_ThreadDataCtxGenericAllocate
                                       ,GEN_ThreadDataCtxGenericInit
                                       ,GEN_ThreadDataCtxGenericPrepareApplicationData          /* PMSTA-24076 - 180716 - PMO */
                                       ,GEN_ThreadDataCtxGenericCleaningApplicationData         /* PMSTA-24076 - 180716 - PMO */
                                       ,GEN_ThreadDataCtxGenericDestroy);
    SYS_SetCallBackThreadDataCtxServer(SERV_ThreadDataCtxServerCreate
                                      ,SERV_ThreadDataCtxServerAllocate
                                      ,SERV_ThreadDataCtxServerInit
                                      ,SERV_ThreadDataCtxServerPrepareApplicationData          /* PMSTA-24076 - 180716 - PMO */
                                      ,SERV_ThreadDataCtxServerCleaningApplicationData         /* PMSTA-24076 - 180716 - PMO */
                                      ,SERV_ThreadDataCtxServerDestroy);
}

/************************************************************************
**
**  Function    :   AAA_FreeQCoreApplication()
**
**  Description :   Delete the QCoreApplication after all other global memory object
**                  This avoid to delete QCoreApplication while some threads might still running and might do an HTTP connection that use some internal part of QCoreApplication.
**                  The shutdown order is:
**                  1) The main is left
**                  2) All threads terminated
**                  3) Some global variables are freed
**					4) Delete the HttpServer and his resources
**                  5) QCoreApplication is deleted
**  Argument    :
**
**  Return      :   None
**
**  Last modif. :   PMSTA-33076 - 071218 - PMO : Financial server crash when stopping
**
*************************************************************************/
QCoreApplication * SV_App;

void AAA_FreeQCoreApplication()
{
	if (SV_App != nullptr) {
		/*PMSTA-49983 - Jagan - 20220801 - reason to call deleteLater https://doc.qt.io/qt-5/qobject.html#deleteLater */
		SV_App->deleteLater();  
		SV_App = nullptr;
	}
}

#ifdef NTWIN
#pragma warning(disable:4189)
#endif

/************************************************************************
**
**  Function    :   AAA_FreeHttpServer()
**
**  Description :   Delete the HttpServer and his ressources
**                  See the description of AAA_FreeQCoreApplication
**
**  Argument    :
**
**  Return      :   None
**
**  Last modif. :   PMSTA-34824 - 210219 - PMO : Regression: several core file generated while running the TaAutomator night batch (HttpConnectionHandler)
**
*************************************************************************/
static HttpServer * SV_HttpServer;

void AAA_FreeHttpServer()
{
    if (SV_HttpServer != nullptr) {
        delete SV_HttpServer;
        SV_HttpServer = nullptr;
    }
}

/************************************************************************
**
**  Function    :   AAA_StopInProgressHttpServer()
**
**  Description :  Indicate the the server a stop has started
**                 See the description of AAA_FreeQCoreApplication
**
**
*************************************************************************/

void AAA_StopInProgressHttpServer()
{
    if (SV_HttpServer != nullptr) {
        SV_HttpServer->stopInProgress();
    }
}



/************************************************************************
**
**  Function    :   mainTripleAProgram()
**
**  Description :   application entrypoint
**                  executable accepts parameters
**                  -Uusername or -U username
**                  -Ppassword or -P Password
**                  -Sserver or -S Server
**                  -display DISPLAY
**                  -W
**
**  Arguments   :   argc   arguments number
**                  argv   arguments list
**
**  Return      :   none
**
**  Modif.      :   ROI - 970318 - DVP388
**                  GRD - 971103 - REF1038.
**                  FIH - 980306 - REF064
**                  ROI - 980317 - REF1447
**                  REF9165 - 030610  - PMO : Display the call stack
**                  REF10380 - 041124 - EFE : Stack size problem with HPUX when creating threads
**                                            the new stck size value must be multiple of 8192
**                  PMSTA-9107 -141209 - PMO : Fix visual C++ 2008 issues
**                  PMSTA-16443 - 230713 - PMO : Add confirmation-to-continue messages in case not enough free memory is available for the GUI when loading data from a financial server
**                  PMSTA-18094 - 130514 - PMO : Avoid extracting the user credentials from the GUI running on Windows (via dump, etc.)
**                  PMSTA-18893 - 101114 - PMO : Core dump during precomp on instrument
**                  PMSTA-19736 - 030315 - PMO : OpenServer, Client / P1 / Locking
**                  PMSTA-19735 - 020415 - PMO : OpenServer / P1 / Thread handling
**                  PMSTA-20089 - 120515 - PMO : Unification of code for mono-threaded (static variable context) and multi-threaded (thread local variable).
**                  PMSTA-19737 - 270516 - PMO : OpenServer HTTP & HTTPS server (include POC already done)
**                  PMSTA-24510 - 220816 - PMO : Fusion & Dispatcher in HTTP
**                  PMSTA-25236 - 231116 - PMO : Remove AAACORE environment variable handling
**                  PMSTA-30823 - 050418 - PMO : SCPT_FmtEltAnalyse: Source and destination overlap in mempcpy
**                  PRO-7103 - 280818 - PMO : Provide libraries log4cplus on different platforms
**                  PMSTA-34824 - 210219 - PMO : Regression: several core file generated while running the TaAutomator night batch (HttpConnectionHandler)
**                  PMSTA-36212 - 160719 - PMO : Call stack crash while evaluating large input control in the server
**
*************************************************************************/
int mainTripleAProgram(int argc, char *argv[])
{
    int exitValue = EXIT_SUCCESS;

#ifndef NTWIN
    setvbuf(stdout, NULL, _IOLBF, BUFSIZ);
    setvbuf(stderr, NULL, _IOLBF, BUFSIZ);
#endif

    /* PMSTA-18893 - 101114 - PMO */
    SYS_SetCallBackAllocationFailureReport(MSG_AllocationFailureReport);

    /* < PMSTA-20235 - CHU - 150421 */
    /*
    * QT initialization
    */
    int argcOneOnly = 1;
    /* DLA - PMSTA25072 - 161019 */
    SV_App = new AAAQCoreApplication(argcOneOnly, argv);         /* PMSTA-33076 - 071218 - PMO */

    /* > PMSTA-20235 - CHU - 150421 */

    SYS_AddCallBackForProgramState(ProgramState::ShutdownQtFree, AAA_FreeQCoreApplication);             /* PMSTA-33076 - 071218 - PMO */

    /* PMSTA-19737 - 270516 - PMO */

    /* Used has filename for loading the HTTP configuration*/
    SV_App->setApplicationName("aaa_srv");
    SV_App->setOrganizationName("Temenos");

#ifndef SANITIZER_BUILD
    INSTALL_SIGINT;
    INSTALL_SIGTERM;
#endif

    /* General Initialization */
    RET_CODE ret = GEN_Initial();
    if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
    {
        /* PMSTA-11725 - TGU - 130810 - Update the error message @startup */
        char * logFilePath = SYS_GetEnv("AAALOG");
        if (logFilePath != NULL)
        {
            fprintf(stderr, "aaa_srv: initialisation error (see log file: \"%s\")\n", logFilePath);
        }
        else
        {
            fprintf(stderr, "aaa_srv: initialisation error.\n");
        }
        return EXIT_FAILURE;
    }

    std::cout << "\n- Financial Server Start " << AAAVersion::getVersion().getfullVersionInfo() << "\n";

    /* Client/Server DataBase Access Initialization */
    std::cout << "- Server Connections Initialization (" << EV_Server << ")... ";

    if (CSRV_Init(false) != RET_SUCCEED)
    {
        return EXIT_FAILURE;
    }

    {
    std::string path;

    if (SV_ServerLogFileName[0] != END_OF_STRING)
    {
        if (strchr(SV_ServerLogFileName, '/') == NULL)
            SYS_StringFormat(path, "%s/%s", SYS_GetEnv("AAAMSG"), SV_ServerLogFileName);
        else
            path = SV_ServerLogFileName;
    }
    else
    {
        SYS_StringFormat(path, "%s/server.log", SYS_GetEnv("AAAMSG"));
    }

    MSG_OpenSrvLogFile(path.c_str());
    }

    /* PMSTA-36212 - 160719 - PMO */
    SYS_CheckAaaThreadStackSize();

    printf("%s\n- SQL Server Connection & Dialog (%s / %s)... ", Console::ColorizeOk("ok").c_str(), DBI_GetSqlServerName().c_str(), SYS_GetLoginDb().c_str());


    if (EV_Server.length() > 0)  /* PMSTA-24510 - 220816 - PMO */
    {
        GEN_SetApplInfo(ApplServerName, EV_Server);     /* PMSTA-24510 - 220816 - PMO */
    }

    if (SV_FlgLoginPassed == TRUE)
    {
        PasswordEncrypted * pE = nullptr;
        GEN_GetUserInfo(UserPasswd, &pE);

        SV_LoginOk = GEN_AppLogin(SV_User, *pE);        /* PMSTA-18094 - 130514 - PMO   */
    }

    /* Last Login check */
    if (SV_LoginOk != RET_SUCCEED)
    {
        return EXIT_FAILURE;
    }


    /* Read meta-dictionary */
    printf("%s\n- Meta Dictionary Load... ", Console::ColorizeOk("ok").c_str());

    if (DBA_InitDictInfo() != RET_SUCCEED)
    {
        return EXIT_FAILURE;
    }

    /* Load database tables in memory */
    printf("%s\n- Special Tables Load... ", Console::ColorizeOk("ok").c_str());

    DBA_LoadingTabInMemory();

    /* for now calling from here temporarily.
     * TODO - 
        - move this call to the call back thread
        - handle subsequent calls based on when JWK refresh might happen
        - clear expired keys from the cache
        - Add timestamp to the cache?
        */
    FIN_CallOAuthServiceJWKSEndPoint();

    /* Server Initialization */
    if (EV_GenDdlContext.bCheckOnly == false &&  /* PMSTA-14452 - LJE - 121120 */
        SERV_Init() == FALSE)
    {
        SYS_Shutdown(EXIT_FAILURE);
        return EXIT_FAILURE;
    }

    if (SYS_GetEnv("SYB_PRINTVERSION") != NULL) /* DLA - 030724 */
    {
        DBI_PrintVersion();
    }

    /* PMSTA-13109 - LJE - 111207 */
    if ((SYS_GetEnv("AAAUSENATIVEMEMALLOC")) != NULL)
    {
        EV_UseNativeMemAlloc = 1;
    }

    SV_ServerInitFlg = 1;

    if (EV_GenDdlContext.bCheckOnly == false)
    {
        FLAG_T proxyServFlg = FALSE;
        if (SERV_GetServerInfo(A_ServConnect_ProxyServFlg, &proxyServFlg) == RET_SUCCEED &&
            proxyServFlg == TRUE)
        {
            EV_IsProxyServer = true;
            EV_RpcCollection.addSpToRpcProperties();
        }

        DBA_LoadAndCheckDbTimeZone(true); /* PMSTA-30187 - DDV - 180501 */

        /* PMSTA16847 - DDV - 130924 - Create currency array */
        DBA_CurrenciesMapInit();

        int maxConnNbr = SERV_GetMaxAvailConn();
        auto virEntByThread = SYS_GetEnvUnsignedOrDefValue("AAAVIRTUALENTITYBYTHREAD", 10);

        DICT_AllocateVirtualEntity(maxConnNbr * virEntByThread);


        if (GEN_InitPoolConnectionFinal() != RET_SUCCEED)
        {
            printf("- Connection pool startup... %s", Console::ColorizeError("failed").c_str());
            exitValue = EXIT_FAILURE;
        }
        else
        {
            /* DLA - PMSTA-25639 - 170323 */
            int timer = SYS_GetEnvIntOrDefValue("LAST_SEEN_DATE_UPDATE_FREQ", 60);
            SYS_AddCallBackEvent(SERV_CallbackUpdateServRunningLastSeenDate, timer);

#ifndef SANITIZER_BUILD
            SYS_AddCallBackEvent(SERV_CallBackFctForSig, 1);
#endif
            SYS_AddCallBackEvent(SERV_CheckSessionValidity, 5);

            /* PMSTA - 41612 - DDV - 200917 */ /* PMSTA-43328 - DDV - 210125 - By default this feature is no more active. And MEM_OPTI_FREQ=0 disable it */
            timer = SYS_GetEnvIntOrDefValue("MEM_OPTI_FREQ", 0);
            if (timer > 0)
            { 
                SYS_AddCallBackEvent(SERV_MemoryOptimisation, timer);
            }

            SYS_StartThreadGeneralCallback();   /* DLA - PMSTA-25639 - 170328 */

            TWAC_Client::startThread(TWAC_Client::TapCore, EV_Server.c_str()); /* PMSTA-37362 - FME - 20200217 */

            SV_HttpServer = new HttpServer(dynamic_cast<AAAQCoreApplication *>(SV_App), QString(EV_Server.c_str()));   /* PMSTA-33076 - 071218 - PMO */ /* new to avoid crash at the exiting */
            SYS_AddCallBackForProgramState(ProgramState::StartShutdown, AAA_StopInProgressHttpServer);
            SYS_AddCallBackForProgramState(ProgramState::ShutdownHttpServer, AAA_FreeHttpServer);

            if (SV_HttpServer->configure())
            {
                /*
                * Start the HTTP server
                */
                exitValue = SV_HttpServer->start(); // Main Loop
                exitValue = RET_SUCCEED;

            }
            else
            {
                exitValue = EXIT_FAILURE;
                MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "Run Server", "The aaa_srv.ini file cannot be found or is badly configured");
            }

            SYS_StopThreadGeneralCallback(); /* DLA - PMSTA-25639 - 170323 */
        }
    }

    SERV_DispEnd();

#ifdef NTWIN
    NT_Done();
#endif

    /* PMSTA-14452 - LJE - 121120 */
    if (EV_GenDdlContext.bCheckOnly)
    {
        if (EV_CheckErrorLevel == RET_SUCCEED)
        {
            printf("%s\n\nSUCCESSFULLY CHECKED\n", Console::ColorizeOk("ok").c_str());
        }
        else
        {
            exitValue = EXIT_FAILURE;
            printf("%s\n\nCHECK FAILED\n", Console::ColorizeError("failed").c_str());
        }
    }

    return exitValue;
}

#ifdef NTWIN
#pragma warning(default:4189)
#endif

/************************************************************************
**
**  Function    :   GEN_GetProgramType()
**
**  Description :   Return AAA programm type
**
**  Arguments   :
**
**  Return      :   AAAProgramType
**
**  Creation    :   PMSTA-54990 - DDV - 231201
**  Last modif. :
**
*************************************************************************/
AAAProgramType GEN_GetProgramType()
{
    return(AAAProgramType::Server);
}

/*************************************************************************
**   END  aaasrv.c                                              Odyssey **
*************************************************************************/

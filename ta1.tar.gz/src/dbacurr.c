/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DBACURR_C

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H
#define MATH_H

#include "unidef.h"     /* Mandatory */
#include "gen.h"
#include "date.h"
#include "dba.h"
#include "syslib.h"     /* Necessary for FREE  PMO - Rename our sys.h to syslib.h and use it */
#include "tls.h"

#include "eservice.h"
#include "conprovider.h"
#include "conexcept.h"
#include "conlocprovider.h"
#include "password.h"
#include "dbiconnection.h"
#include "dbacurr.hpp"

extern int EV_AAAInstallLevel;

/************************************************************************
**      External entry points
**
**
*************************************************************************/

/************************************************************************
**      Local functions
**
**
*************************************************************************/

/************************************************************************
**      Static definitions & data
*************************************************************************/


/************************************************************************
**
** Function    : DBA_GetCurrencyById
**
** Description : Function C Replace Stored Proc for cache memory improvement
**               (in specific Currency case )
** Arguments   :
** Return      :
** Creation    :    MDE - REF5443 - 001122
**
************************************************************************/
RET_CODE DBA_GetAllCurrencyById(OBJECT_ENUM             entity,
                               DBA_DYNFLD_STP           sCurr,
                               DBA_DYNFLD_STP           *aCurr,
                               DbiConnectionHelper&     dbiConnHelper)
{
    RET_CODE            ret=RET_SUCCEED;
    DBA_DYNFLD_STP      aCurrPTR = NULLDYNST;
    FLAG_T              freeFlag=FALSE;

	/* PMSTA16847 - DDV - 130924 - Add freeFlag parameter */
    if ((ret = DBA_GetCurrById(GET_ID(sCurr,S_Curr_Id), &aCurrPTR, &freeFlag)) == RET_SUCCEED)
       	COPY_DYNST(*aCurr, aCurrPTR, A_Curr);

    if (freeFlag == TRUE) {FREE_DYNST(aCurrPTR, A_Curr);}

    return(ret);
}



/************************************************************************
**
** Function    : DBA_GetCurrencyByCd
**
** Description : Function C Replace Stored Proc for cache memory improvement
**               (in specific Currency case )
** Arguments   :
** Return      :
** Creation    :    MDE - REF5443 - 001122
**
************************************************************************/
RET_CODE DBA_GetAllCurrencyByCd(OBJECT_ENUM             entity,
                               DBA_DYNFLD_STP           sCurr,
                               DBA_DYNFLD_STP           *aCurr,
                               DbiConnectionHelper&     dbiConnHelper)
{
    RET_CODE            ret=RET_SUCCEED;
    DBA_DYNFLD_STP      aCurrPTR = NULLDYNST;
    FLAG_T              freeFlag=FALSE;

    /* REF7264 - RAK - 020124 - suppress ; at the end of if  */
    /* empty controlled statement found; is this the intent? */
	/* PMSTA16847 - DDV - 130924 - Add freeFlag parameter */
    if ((ret = DBA_GetCurrByCd(GET_CODE(sCurr,S_Curr_Cd), &aCurrPTR, &freeFlag)) == RET_SUCCEED)
       	COPY_DYNST(*aCurr, aCurrPTR, A_Curr);

    if (freeFlag == TRUE) {FREE_DYNST(aCurrPTR, A_Curr);}

    return(ret);
}

/************************************************************************
**
** Function    : DBA_GetCurrPrecision()
**
** Description : return precision as double according to RoundUnitEn
**
** Arguments   : currPtr    pointer on currency struct,
**                          if NULL default will be returned
**
** Return      : precision, default 0.01
**
** Creation    : REF5248 - RAK - 001004
**
************************************************************************/
double DBA_GetCurrPrecision(DBA_DYNFLD_STP currPtr)
{
    double  precision=0.01; /* default */

    /* Transform parameter unit in precision */
    if (currPtr != NULLDYNST)
    {
        switch ((RNDUNIT_ENUM) GET_ENUM(currPtr, A_Curr_RoundUnitEn))
        {
        case RndUnit_0_01:
            precision = 0.01;
            break;
        case RndUnit_0_05:
            precision = 0.05;
            break;
        case RndUnit_0_10:
            precision = 0.1;
            break;
        case RndUnit_0_50:
            precision = 0.5;
            break;
        case RndUnit_1_00:
            precision = 1.0;
            break;
        case RndUnit_5_00:
            precision = 5.0;
            break;
        case RndUnit_10_00:
            precision = 10.0;
            break;
        case RndUnit_50_00:
            precision = 50.0;
            break;
        case RndUnit_100_00:
            precision = 100.0;
            break;
        case RndUnit_0_005:
            precision = 0.005;
            break;
        case RndUnit_0_001:
            precision = 0.001;
            break;
        case RndUnit_0_00001:       /* DVP270 - RAK - 980619 */
            precision = 0.00001;
            break;
        case RndUnit_0_0001:        /* REF2313 - RAK - 980619 */
            precision = 0.0001;
            break;
        case RndUnit_0_0000001:     /* REF2313 - DDV - 020412 */
            precision = 0.0000001;
            break;
        case RndUnit_0_000001:    /* PMSTA-31831 - DDV - 180709 */
            precision = 0.000001;
            break;
        default :
            MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
                         "DBA_CurrenciesMapInit", "rounded unit");
        }
    }

    return(precision);
}

/************************************************************************
**
**  Function    :   DBA_CmpAmount()
**
**  Description :   Compare two amounts (use currency rounded parameters)
**
**  Arguments   :   x      first amount
**                  y      second amount
**                  currId currency identifier
**
**  Return      :
**
**  Creation    :   REF5248 - RAK - 001005 - Replace FIN_Cmp_Amount()
**  Last modif. :   REF8014 - 021014 - PMO : BoundsChecker message
**
************************************************************************/
int DBA_CmpAmount(double x, double y, ID_T currId)
{
    DBA_DYNFLD_STP  currPtr;
    double          precision;
    FLAG_T          freeFlag=FALSE;

    /* BUG160 */
    if (currId == 0)
    {
        if (x != 0.0 && y != 0.0)
        {
            MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO,
                 "DBA_CmpAmount", "currency identifier");
        }
        precision = SV_DefaultMaxPrecision; /* PMSTA-36302 - DDV - 190624 - Make 6 digits amount optional */
    }
    else
    {
        /* Test if found REF8014 - PMO - 021014 */
		/* PMSTA16847 - DDV - 130924 - Add freeFlag parameter */
        if (RET_SUCCEED == DBA_GetCurrById(currId, &currPtr, &freeFlag))
        { /* Found */
            precision = DBA_GetCurrPrecision(currPtr);

            if (freeFlag == TRUE) {FREE_DYNST(currPtr, A_Curr);}
        }
        else
        { /* Not Found */
            precision = SV_DefaultMaxPrecision; /* PMSTA-36302 - DDV - 190624 - Make 6 digits amount optional */
        }
    }

    return TLS_Cmp(x, y, precision);

}

/************************************************************************
**
** Function    : DBA_CurrenciesMapAdd, replace DBA_CurrHashTableAdd()
**
** Description :
**
** Arguments   :
**
** Return      :
**
** Creation    : PMSTA-28455 - RAK - 171003 hbp
**
************************************************************************/
RET_CODE DBA_CurrenciesMapAdd(DBA_DYNFLD_STP currPtr, ID_T BEId)
{
	CurrenciesMap::getInstance().add(currPtr, BEId);

	return RET_SUCCEED;
}

/************************************************************************
**
** Function    : DBA_CurrenciesMapInit, replace DBA_CurrHashTableInit()
**
** Description : Load all currencies) in c++ map
**
** Arguments   : None
**
** Return      : RET_CODE
**               RET_SUCCEED on succeed
**
** Creation    : PMSTA-28455 - RAK - 171003 hbp
**               PMSTA-35071 - 080319 - PMO : Fusion - Contention point on DBA_GetCurrById
**
************************************************************************/
RET_CODE DBA_CurrenciesMapInit()
{
    /* PMSTA-14452 - LJE - 130109 - If on install mode, don't load currencies */
    if (EV_AAAInstallLevel || CurrenciesMap::getInstance().isEmpty() == false)
        return RET_SUCCEED;

   
    RET_CODE            ret = RET_SUCCEED;
    DBA_DYNFLD_STP	*   aCurrTab = nullptr;
    int				    aCurrNb = 0;
    
    DICT_ENTITY_STP dictEntityPtr = nullptr;
    bool isSrvAndCurrBENotDependent = false;
    /* PMSTA-50962 - JBC - 221102 master as default if not specialized otherwise populated in initAdminSessionMap */
    if(SYS_IsSrvMode() && (EV_MasterBusinessEntity.empty() 
            || ((dictEntityPtr = DBA_GetDictEntitySt(Curr)) != nullptr && dictEntityPtr->multiEntityCateg.isBusinessEntityDependents() == false)))
    {
        isSrvAndCurrBENotDependent =true;
    }

    if (!SYS_IsSrvMode() /* GUI */ || isSrvAndCurrBENotDependent)
    {
        DbiConnectionHelper dbiConnHelper(AAATransactionEnum::NotTransactionnal, DBA_SERVER_TYPE_ENUM::SqlServer, ROLE_INIT);

        if ((ret = dbiConnHelper.dbaSelect(Curr, DBA_ROLE_SEL_ALL_CURRENCY, nullptr, A_Curr, &aCurrTab, &aCurrNb)) == RET_SUCCEED
            && aCurrNb > 0)
        {
            const ID_T businessEntityId = isSrvAndCurrBENotDependent ? EV_MasterBusinessEntityId : SYS_GetThreadCurrBusinessEntityId();
            CurrenciesMap::getInstance().init(aCurrTab, aCurrNb, businessEntityId);
            FREE(aCurrTab);
        }
    }

    return ret;
}

/************************************************************************
**
** Function    : DBA_GetCurrById(), replace and change FIN_Curr_Hash_Table_Get()
**
** Description : return currency dynamic structure according to received identifier.
**
** Arguments   : currId  currency id
**               currPtr pointer which will contains currency struct pointer
**
** Return      : RET_SUCCEED or error code (currPtr is filled with currency)
**
** WARNING     : currPtr is filled with global pointer (not a copy),
**               so DON'T FREE IT and DON'T MODIFY CONTENTS
**
** Creation    : sme (Monday December 06 1999)
**               REF4184
** Modif       : PMSTA16847 - DDV - 130924 - Add freeFlag parameter
**               PMSTA-35071 - 080319 - PMO : Fusion - Contention point on DBA_GetCurrById
**
************************************************************************/
RET_CODE DBA_GetCurrById(ID_T currId, DBA_DYNFLD_STP *currPtr, FLAG_T *freeFlg)
{       
    DICT_ENTITY_STP dictEntityPtr = nullptr;    
    ID_T businessEntityId = EV_MasterBusinessEntityId;
    /* PMSTA-50962 - JBC - 221102 master as default if not specialized */
    if(!SYS_IsSrvMode() || (GEN_IsMultiEntity() && (dictEntityPtr = DBA_GetDictEntitySt(Curr)) != nullptr && dictEntityPtr->multiEntityCateg.isBusinessEntityDependents()))
    {
       businessEntityId = SYS_GetThreadCurrBusinessEntityId();
    }

	/* PMSTA16847 - DDV - 130923 - to avoid lock usage, currency are loaded during server startup. */

    if (!SYS_IsSrvMode())
	    DBA_CurrenciesMapInit();

	*freeFlg = FALSE;

	*currPtr = CurrenciesMap::getCurrencyByBEIdMap(businessEntityId, currId);

	if (*currPtr != NULLDYNST)
		return(RET_SUCCEED);

	/* NOT FOUND :
	load this currency from database, in case of
	a new currency has been created
	*/    
    DbiConnectionHelper dbiConnHelper;  /* PMSTA-35071 - 080319 - PMO */

	/* for import */
	if (CurrenciesMap::getInstance().findBE(businessEntityId) == false)
	{
        DBA_DYNFLD_STP *    aCurrTab = nullptr;
        int                 aCurrNb  = 0;
        RET_CODE            ret = dbiConnHelper.dbaSelect(Curr, DBA_ROLE_SEL_ALL_CURRENCY, nullptr, A_Curr, &aCurrTab, &aCurrNb);

        if (RET_SUCCEED != ret)
			return ret;

		if (aCurrNb > 0)
		{
			CurrenciesMap::getInstance().init(aCurrTab, aCurrNb, businessEntityId);
			FREE(aCurrTab);
		}

		*currPtr = CurrenciesMap::getCurrencyByBEIdMap(businessEntityId, currId);

		if (*currPtr != NULLDYNST)
			return(RET_SUCCEED);
	}
	else
	{
        DBA_DYNFLD_STP getCurr = ALLOC_DYNST(S_Curr);

		if (nullptr == getCurr)
			MSG_RETURN(RET_MEM_ERR_ALLOC);

        DBA_DYNFLD_STP dbCurr = ALLOC_DYNST(A_Curr);

		if (nullptr == dbCurr)
		{
			FREE_DYNST(getCurr, S_Curr);
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		SET_ID(getCurr, S_Curr_Id, currId);

		if (dbiConnHelper.dbaGet(Curr, DBA_ROLE_GET_ALL_CURR_FROM_DB, getCurr, &dbCurr) != RET_SUCCEED)
		{
			FREE_DYNST(getCurr, S_Curr);
			FREE_DYNST(dbCurr, A_Curr);
			return(RET_DBA_ERR_NODATA);
		}

		*currPtr = dbCurr;
		FREE_DYNST(getCurr, S_Curr);

		/* Add in map */
		/* PMSTA16847 - DDV - 130923 - to avoid lock usage, currency are no more added for server (opti added on proc to avoid performance impact). */
        if (!SYS_IsSrvMode())
        {
            DBA_CurrenciesMapAdd(dbCurr, businessEntityId);
        }
        else
        {
            *freeFlg = TRUE;
        }
	}

	return(RET_SUCCEED);
}

/************************************************************************
**
** Function    : DBA_GetCurrByCd()
**
** Description : return currency dynamic structure according to received code.
**
** Arguments   : currCd  currency code
**               currPtr pointer which will contains currency struct pointer
**
** Return      : RET_SUCCEED or error code (currPtr is filled with currency)
**
** WARNING     : currPtr is filled with global pointer (not a copy),
**               so DON'T FREE IT and DON'T MODIFY CONTENTS
**
** Creation    : REF5248 - RAK - 001004
** Modif       : PMSTA16847 - DDV - 130924 - Add freeFlag parameter
**
************************************************************************/
RET_CODE DBA_GetCurrByCd(CODE_T currCd, DBA_DYNFLD_STP *currPtr, FLAG_T *freeFlg)
{
	DBA_DYNFLD_STP  getCurr = nullptr, dbCurr = nullptr, *aCurrTab = nullptr;
	int aCurrNb = 0;
	RET_CODE ret;

    DICT_ENTITY_STP dictEntityPtr = nullptr;    
    ID_T businessEntityId = EV_MasterBusinessEntityId;
    /* PMSTA-50962 - JBC - 221102 master as default if not specialized */
    if(!SYS_IsSrvMode() || (GEN_IsMultiEntity() && (dictEntityPtr = DBA_GetDictEntitySt(Curr)) != nullptr && dictEntityPtr->multiEntityCateg.isBusinessEntityDependents()))
    {
       businessEntityId = SYS_GetThreadCurrBusinessEntityId();
    }
									
	/* PMSTA16847 - DDV - 130923 - to avoid lock usage, currency are loaded during server startup. */
    if (!SYS_IsSrvMode())
	    DBA_CurrenciesMapInit();

	*freeFlg = FALSE;

	*currPtr = CurrenciesMap::getCurrencyByBECdMap(businessEntityId, currCd);

	if (*currPtr != NULLDYNST)
		return(RET_SUCCEED);

	/* NOT FOUND :
	load this currency from database, because when
	a new currency has been created
	*/
    /* PMSTA-28455 - RAK - 171003 hbp */
    DbiConnectionHelper dbiConnHelper;

	/* for import */
	if (CurrenciesMap::getInstance().findBE(businessEntityId) == false)
	{
		if ((ret = dbiConnHelper.dbaSelect(Curr, DBA_ROLE_SEL_ALL_CURRENCY, nullptr, A_Curr, &aCurrTab, &aCurrNb)) != RET_SUCCEED)
			return ret;

		if (aCurrNb > 0)
		{
			CurrenciesMap::getInstance().init(aCurrTab, aCurrNb, businessEntityId);
			FREE(aCurrTab);
		}

		*currPtr = CurrenciesMap::getCurrencyByBECdMap(businessEntityId, currCd);

		if (*currPtr != NULLDYNST)
			return(RET_SUCCEED);
	}
	else
	{
		if ((getCurr = ALLOC_DYNST(S_Curr)) == NULLDYNST)
			MSG_RETURN(RET_MEM_ERR_ALLOC);

		if ((dbCurr = ALLOC_DYNST(A_Curr)) == NULLDYNST)
		{
			FREE_DYNST(getCurr, S_Curr);
			MSG_RETURN(RET_MEM_ERR_ALLOC);
		}

		SET_CODE(getCurr, S_Curr_Cd, currCd);

		if (dbiConnHelper.dbaGet(Curr, DBA_ROLE_GET_ALL_CURR_BY_CD_FROM_DB, getCurr, &dbCurr) != RET_SUCCEED)
		{
			FREE_DYNST(getCurr, S_Curr);
			FREE_DYNST(dbCurr, A_Curr);
			return(RET_DBA_ERR_NODATA);
		}

		*currPtr = dbCurr;
		FREE_DYNST(getCurr, S_Curr);

		/* PMSTA16847 - DDV - 130923 - to avoid lock usage, currency are no more added for server (opti added on proc to avoid performance impact). */
        if (!SYS_IsSrvMode())
        {
            DBA_CurrenciesMapAdd(dbCurr, businessEntityId);
        }
        else
        {
            *freeFlg = TRUE;
        }
	}

	return(RET_SUCCEED);
}


using namespace std;

CurrenciesMap *CurrenciesMap::m_currenciesInstancePtr(nullptr);
map<ID_T, CurrenciesIdMap>	CurrenciesMap::m_BeCurrenciesIdMap;
map<ID_T, CurrenciesCdMap>	CurrenciesMap::m_BeCurrenciesCdMap;

bool CurrenciesMap::findBE(ID_T BEId)
{
	auto & mapId = this->getBECurrenciesIdMap();
	auto itId = mapId.find(BEId);

	if (itId != mapId.end())
		return true;

	return false;
}

void CurrenciesMap::load()
{
    if (m_currenciesInstancePtr == nullptr)
    {
        m_currenciesInstancePtr = new CurrenciesMap();
    }
}

CurrenciesMap& CurrenciesMap::getInstance()
{
    load();
    return *m_currenciesInstancePtr;
}

void CurrenciesMap::close()
{
    delete m_currenciesInstancePtr;
    m_currenciesInstancePtr = nullptr;
}


/************************************************************************
**
** Function    : DBA_CurrCashMaps replace DBA_CurrHashTableInit
**
** Description : Load all currencies in code and id maps
**
** Arguments   : None
**
** Return      : RET_CODE
**               RET_SUCCEED on succeed
**
** Creation    : PMSTA-28455 - RAK - 171003 hbp
**
************************************************************************/
void CurrenciesMap::add(DBA_DYNFLD_STP aCurrPtr, ID_T BEId)
{
	auto & mapId = this->getBECurrenciesIdMap();
	auto itId = mapId.find(BEId);

	if (itId != mapId.end())
	{
		auto & currenciesIdMap = itId->second;
		auto & mapCurrId = currenciesIdMap.getCurrenciesIdMap();

		mapCurrId.insert(make_pair(GET_ID(aCurrPtr, A_Curr_Id), aCurrPtr));
	}

	/* else ? newBE possible !?  is think no */
	/* yesss for import but it will be filled by a select of all currencies */

	auto & mapCd = this->getBECurrenciesCdMap();
	auto itCd = mapCd.find(BEId);

	if (itCd != mapCd.end())
	{
		string cd;
		auto & currenciesCdMap = itCd->second;
		auto & mapCurrCd = currenciesCdMap.getCurrenciesCdMap();
		cd = GET_CODE(aCurrPtr, A_Curr_Cd);
		mapCurrCd.insert(make_pair(cd, aCurrPtr));
	}

    this->m_mp.owner(aCurrPtr);
}

void CurrenciesMap::init(DBA_DYNFLD_STP *aCurrTab, int aCurrNb, ID_T BEIdFld)
{
	if (aCurrNb > 0)
	{
        CurrenciesIdMap &currIdMap = this->m_BeCurrenciesIdMap[BEIdFld];
        CurrenciesCdMap &currCdMap = this->m_BeCurrenciesCdMap[BEIdFld];

		for (int i = 0; i < aCurrNb; i++)
		{
			currIdMap.insert(GET_ID(aCurrTab[i], A_Curr_Id), aCurrTab[i]);

            string cd = GET_CODE(aCurrTab[i], A_Curr_Cd);
			currCdMap.insert(cd, aCurrTab[i]);

            this->m_mp.owner(aCurrTab[i]);
		}
	}
}

bool CurrenciesMap::isEmpty()
{
    if (m_currenciesInstancePtr == nullptr)
    {
        return true;
    }
	auto & map = this->getInstance().getBECurrenciesIdMap();
	return map.empty();
}

/************************************************************************
**
** Function    : DBA_GetCurrencyByIdMap()
**
** Description : return currency dynamic structure according to received identifier.
**
** Arguments   : currConBEId	current BE identifier
**				 currId			currency identifier
**               currPtr		pointer which will contains currency struct pointer
**
** Return      : RET_SUCCEED (currPtr is filled with currency) or error code
**
** WARNING     : currPtr is filled with global pointer (not a copy),
**               so DON'T FREE IT and DON'T MODIFY CONTENTS
**
** Creation    : PMSTA-28455 - RAK - 171003 hbp
**
************************************************************************/
DBA_DYNFLD_STP CurrenciesMap::getCurrencyByBEIdMap(ID_T currConnBEId, ID_T currId)
{
	return CurrenciesMap::getInstance().findById(currConnBEId, currId);
}

DBA_DYNFLD_STP CurrenciesMap::getCurrencyByBECdMap(ID_T currConnBEId, CODE_T currCd)
{
	return CurrenciesMap::getInstance().findByCd(currConnBEId, currCd);
}

DBA_DYNFLD_STP CurrenciesMap::findById(ID_T currConnBEId, ID_T currId)
{
	auto & map = this->getInstance().getBECurrenciesIdMap();
	auto it = map.find(currConnBEId);

	if (it != map.end())
	{
		auto & currenciesIdMap = it->second;
		auto & mapCur = currenciesIdMap.getCurrenciesIdMap();
		auto it2 = mapCur.find(currId);

		if (it2 != mapCur.end())
		{
			return it2->second;
		}
	}

	return nullptr;
}

DBA_DYNFLD_STP CurrenciesMap::findByCd(ID_T currConnBEId, CODE_T currCd)
{
	auto & map = this->getInstance().getBECurrenciesCdMap();
	auto it = map.find(currConnBEId);

	if (it != map.end())
	{
		auto & currenciesCdMap = it->second;
		auto & mapCur = currenciesCdMap.getCurrenciesCdMap();
		auto it2 = mapCur.find(currCd);

		if (it2 != mapCur.end())
		{
			return it2->second;
		}
	}

	return nullptr;
}

std::map<ID_T, CurrenciesIdMap>	& CurrenciesMap::getBECurrenciesIdMap()
{
	return this->m_BeCurrenciesIdMap;
}

CurrenciesIdMap::CurrenciesIdMap(CurrenciesIdMap const & src)
{
	currenciesIdMap = src.currenciesIdMap;
}

void CurrenciesIdMap::insert(ID_T currId, DBA_DYNFLD_STP currPtr)
{
	currenciesIdMap.insert(make_pair(currId, currPtr));
}

void CurrenciesIdMap::clear()
{
    this->currenciesIdMap.clear();
}

std::map<ID_T, DBA_DYNFLD_STP> &	CurrenciesIdMap::getCurrenciesIdMap()
{
	return currenciesIdMap;
}

std::map<string, DBA_DYNFLD_STP> &	CurrenciesCdMap::getCurrenciesCdMap()
{
	return currenciesCdMap;
}

CurrenciesCdMap::CurrenciesCdMap(CurrenciesCdMap const & src)
{
	currenciesCdMap = src.currenciesCdMap;
}

void CurrenciesCdMap::insert(string currCd, DBA_DYNFLD_STP currPtr)
{
	currenciesCdMap.insert(make_pair(currCd, currPtr));
}

void CurrenciesCdMap::clear()
{
	currenciesCdMap.clear();
}

std::map<ID_T, CurrenciesCdMap>	& CurrenciesMap::getBECurrenciesCdMap()
{
	return this->m_BeCurrenciesCdMap;
}


/*************************************************************************
**   END  dbacurr.c                                          Odyssey    **
*************************************************************************/

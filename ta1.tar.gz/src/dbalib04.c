/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DBALIB04_C

/************************************************************************
*       Local Functions
*
* DBA_InsertByBlock               : Send many INSERT requests to the server and retrieve returned status.
* DBA_UpdateByBlock               : Send many UPDATE requests to the server and retrieve returned status.
* DBA_MultiAccess                 : Send one or many SQL Dynamic requests composed of many action do proceed
*                                   (Insert, Update or Delete).
* DBA_FreeOperTabForBlockHandling : Free allocated arrays of data for block mode handling (Dynamic SQL) on operations
* DBA_HandleOperTab               : This function receives a block of operations (Buy, Sell, ExtOp, ...) and handles it
*                                   according to action (Insert, Update, Delete, InsUpd, Notify).
* DBA_HandleOperTabByBlock        : This function receives an array of operations/Extended operations and must perform actions
*                                   (Insert, Update or Delete) on these operations, using block insertion mode.
* DBA_AddElemToBlockModeSt        : add an element in a bloc mode structure
* void DBA_FlagAllTheBlockToError : Complete the block of error struct when the block is rollback
*************************************************************************/

/************************************************************************
**      Include files
*************************************************************************/
#ifdef NTWIN
#pragma warning (push)
#endif

#include <assert.h>     /* REF9484 - TEB - 030919 */
#include "unidef.h"     /* Mandatory */
#include "dba.h"
#include "date.h"
#include "cmp.h"
#include "conlocprovider.h"
#include "dbiconnection.h"

#ifndef TLS_H
#include "tls.h"
#endif

#include "hier.h"
#include "scptyl.h"
#include "ope.h"

#ifndef SCPT_H
#include "scpt.h"
#endif

#ifdef NTWIN
#pragma warning (pop)
#endif

extern bool           EV_UseMultiAccessByBatch;                 /* PMSTA-37366 - LJE - 191205 */

/************************************************************************
**      Static definitions & data
*************************************************************************/
/* Ref.: DVP061 */
#define GET_DYNST_MAXLEN(s)  DBA_GetDynStMaxLen(s)


void DBA_FlagAllTheBlockToError(DbiConnection& , int );

STATIC RET_CODE DBA_MultiAccessTreatElt(DBA_ACCESS_ST&, int, const int, DBA_PROC_STP *, DBA_PROC_STP *, DBA_DYNFLD_STP *, DBA_DYNFLD_STP *, DBA_DYNFLD_STP *, int, int, int, int *,
                                 char *, int, std::string&, int, bool&, DBA_ACCESS_STP *, int *, int *, int *, int *, DbiConnection&, int, RequestHelper&);


STATIC RET_CODE DBA_MultiAccessLogOverFlow(DBA_ACCESS_ST, int, DBA_PROC_STP, int);
STATIC RET_CODE DBA_MultiAccessSendData(DBA_ACCESS_STP, int, int, const int, int *, std::string&,
                                        bool&, int, int *, int *, FLAG_T *, RET_CODE *, int *, int *, DbiConnection&, int, int*, RequestHelper&, bool, bool);

STATIC RET_CODE DBA_MultiAccessInternal(DBA_ACCESS_STP, const int, int, int, DbiConnection&, bool);
STATIC RET_CODE DBA_MultiAccessInternal(DBA_ACCESS_STP, const int, int, int, int *, bool);

STATIC RET_CODE DBA_UpdateByBlock(OBJECT_ENUM, int, DBA_DYNST_ENUM, DBA_DYNFLD_STP *, int, int, DbiConnection&, RequestHelper&, int);


/************************************************************************
*   Function             : DBA_GetActionName()
*
*   Description          : Return the name of the action given has argument
*
*   Arguments            : action
*
*   Return               : The name
*
*   Creation Date        : PMSTA-25268 - 161116 - PMO : Fusion on portfolio failed
*
*   Last Modification    :
*************************************************************************/
std::string DBA_GetActionName(const DBA_ACTION_ENUM & action)
{
    std::string ret;

    switch (action)
    {
    case NullAction:
        ret = "NullAction";
        break;

    case Get:
        ret = "Get";
        break;

    case Select:
        ret = "Select";
        break;

    case MultiSelect:
        ret = "MultiSelect";
        break;

    case Load:
        ret = "Load";
        break;

    case Insert:
        ret = "Insert";
        break;

    case Update:
        ret = "Update";
        break;

    case Delete:
        ret = "Delete";
        break;

    case Check:
        ret = "Check";
        break;

    case Notif:
        ret = "Notif";
        break;

    case Copy:
        ret = "Copy";
        break;

    case InsUpd:
        ret = "InsUpd";
        break;

    case SelMetaDict:
        ret = "SelMetaDict";
        break;

    case RegisterRpc:
        ret = "RegisterRpc";
        break;

    case Purge:
        ret = "Purge";
        break;

    case Truncate:
        ret = "Truncate";
        break;

    case AllStdProcs:
        ret = "AllStdProcs";
        break;

    case Special:
        ret = "Special";
        break;

    case OptiDef:
        ret = "OptiDef";
        break;

    case Custom:
        ret = "Custom";
        break;

    case Trigger:
        ret = "Trigger";
        break;
    }

    return ret;
}


/************************************************************************
*   Function             : DBA_GetDictEntitySqlOrObjectName()
*
*   Description          : Try to return the SQL name of the object given has argument
*
*   Arguments            : object
*
*   Return               : The SQL name
*
*   Creation Date        : PMSTA-25268 - 161116 - PMO : Fusion on portfolio failed
*
*   Last Modification    :
*************************************************************************/
std::string DBA_GetDictEntitySqlOrObjectName(const OBJECT_ENUM & object, const DBA_DYNST_ENUM & inputSt)
{
    const char * p = DBA_GetDictEntitySqlName(object);

    if (p != nullptr)
    {
        return p;
    }
    else
    {
        p = DBA_GetDynStCName(inputSt);

        if (p != nullptr)
        {
            return p;
        }
        else
        {
            char entityStr[40];

            sprintf(entityStr, "unknown(%d)", inputSt);

            return entityStr;
        }
    }
}


/************************************************************************
*   Function             : DBA_InsertByBlock()
*
*   Description          : Send many INSERT requests to the server and retrieve
*                          returned status
*
*   Arguments            : object       : the request corresponding object
*                          role         : the role to use
*                          inputSt      : the input dynamic struct. format
*                          inputDataTab : the pointer on the input dynamic struct. array
*                          inputRecNbr  : the input records number in inputDataTab
*                          insOptions   : can be DBA_SET_CONN, DBA_NO_CLOSE, DBA_IN_TRAN, DBA_INS_ID, UNUSED
*                          allocConn    : 1. pointer which will contain the connectNo
*                                            used for the request if insOptions is
*                                            DBA_NO_CLOSE.
*                                         2. pointer which contain a connection number
*                                            if insOptions is DBA_SET_CONN or DBA_IN_TRAN.
*                          maxRecInBuf  : the maximum records number in one data block (def : 50)
*                          msgStructPtr : pointer on a structure which will contain
*                                         recieved messages informations.
*
*   Return               : RET_SUCCEED              : if no problem was detected
*                          RET_DBA_ERR_ARGNOMATCH   : if input arg. problem
*                          RET_DBA_ERR_PROCNOTFOUND : if no procedure founded
*                          RET_DBA_ERR_SETPARAM     : if problem while setting proc. parameters
*                          RET_DBA_ERR_CONNOTFOUND  : if no connection founded
*                          RET_DBA_ERR_DBPROBLEM    : if DB/connection problem
*                          RET_DBA_ERR_SYBBIND      : if poblem while binding received fields
*                          RET_MEM_ERR_ALLOC        : if allocation failed
*                          RET_DBA_ERR_READ_DATA    : if problem while reading received data
*                          RET_GEN_ERR_INVARG       : if problem while setting function params.
*                          a RET_CODE               : if a message has been received
*
*   Creation Date        : 20.05.96 - PEC - Ref.: DVP061.
*   Last Modification    : 22.11.96 - PEC - Ref.: DVP263.
*                          27.11.96 - PEC - Ref.: DVP279.
*                          21.03.97 - PEC - Ref.: DVP400.
*                          10.07.97 - RAK - Ref.: DVP460.
*                          20.08.98 - RAK - Ref.: REF2691.
*                          04.10.99 - SSO - Ref.: REF4001.
*                          10.05.00 - SSO - Ref.: REF2697.
*                          04.12.00 - SSO - Ref.: REF5010.
*                          07.02.01 - SSO - Ref.: REF5629.
*                          28.03.01 - GRD - Ref.: REF5877.
*                          REF7264 - 0201225 - PMO : Compilation errors and warnings with C++ compiler
*                          REF8696 - 030114 - PMO : Unable to insert when audit trail is enable
*                          REF9484 - TEB - 030919
*                          REF8500 - 040510 - PMO : Add a draft_order_id in extended operation to distinguish
*                                                   the id from extended orders and the one from extended operation
*                          REF11780 - 100406 - PMO : Implementation of the Sybase timestamp field
*                          PMSTA-21641 - 071115 - PMO : GUI Oracle Fusion fails
*                          PMSTA-25268 - 161116 - PMO : Fusion on portfolio failed
*
*************************************************************************/
RET_CODE DBA_InsertByBlock(OBJECT_ENUM           object,
                           int                   role,
                           DBA_DYNST_ENUM        inputSt,
                           DBA_DYNFLD_STP        *inputDataTab,
                           int                   inputRecNbr,
                           int                   insOptions,
                           int                   maxRecInBuf)
{
    RET_CODE ret = RET_DBA_ERR_CONNOTFOUND;
    DbiConnectionHelper dbiConnHelper(AAATransactionEnum::Transactionnal);
    if (dbiConnHelper.isValidAndInit())
    {
        ret = DBA_InsertByBlock(object,
                                role,
                                inputSt,
                                inputDataTab,
                                inputRecNbr,
                                insOptions,
                                *dbiConnHelper.getConnection(),
                                maxRecInBuf);

        dbiConnHelper.endTransaction(RET_GET_LEVEL(ret) != RET_LEV_ERROR);
    }
    return ret;
}

RET_CODE DBA_InsertByBlock(OBJECT_ENUM           object,
                           int                   role,
                           DBA_DYNST_ENUM        inputSt,
                           DBA_DYNFLD_STP        *inputDataTab,
                           int                   inputRecNbr,
                           int                   insOptions,
                           DbiConnection&        dbiConn,
                           int                   maxRecInBuf)
{
    int             eltPos;
    int             length;
    int             firstFld = 1;
    int             i;
    int             fldNbr;
    RET_CODE        ret;
    RET_CODE        finalResult = RET_SUCCEED;
    char *          p;
    char *          dataStr;
    std::string     recBuffer;
    int             firstRecInList;
    int             errorRecInList = 0;
    int             dataStrLen = 0;
    bool            bFirstInBlock = true;    /* PMSTA-18593 - LJE - 151103 */
    int             posParam = 0;

    if (inputDataTab == NULL || inputRecNbr == 0)               /* DVP460 */
        return(RET_SUCCEED);

    if (maxRecInBuf == UNUSED)
        maxRecInBuf = 150; /* REF9039 - LJE - 030509 */

    if ((insOptions & DBA_IN_TRAN) != DBA_IN_TRAN)
    {
        dbiConn.beginTransaction();
    }
    dbiConn.setMultiAccessLangRequest(true);

    RequestHelper   requestHelper(&dbiConn);

    /* Retrieve a procedure in the object procedures list */
    DBA_PROC_STP procedure = DBA_GetStoredProcs(Insert, object, role, inputSt, inputDataTab[0], NullDynSt, true);

    /* If no procedure */
    if (procedure == NULL || procedure->server == InternalProc)
    {
        char         objString[40];
        const char  *sqlName = DBA_GetDictEntitySqlName(object);
        OBJECT_ENUM  objEn;                  /* REF2697 - SSO - 000510 */

        if (sqlName != NULL)
        {
            strcpy(objString, sqlName);
        }
        else
        {
            sprintf(objString, "unknown(" szFormatObj ")", object);/* REF2697 - SSO - 000510 */
        }

        DBA_GetObjectEnumByDynSt(inputSt, &objEn);  /* REF2697 - SSO - 000510 */
        char * entitySqlNameIn = (char*)DBA_GetDictEntitySqlName(objEn);

        if (entitySqlNameIn == NULL)
        {
            char entityStrIn[13];        /* REF2697 - SSO - 000510 */

            sprintf(entityStrIn, "unknown(%d)", inputSt);
            entitySqlNameIn = entityStrIn;
        }

        DBA_LogMesgProcedureNotFound(Insert, object, role, inputSt, inputDataTab[0], NullDynSt, true, "InsertByBlock", objString, entitySqlNameIn, "none");  /* PMSTA-25268 - 161116 - PMO */

        return(RET_DBA_ERR_PROCNOTFOUND);
    }

    if (EV_UseMultiAccessByBatch == false)
    {
        /* PMSTA08497 - DDV - 090806 - Use a variable to know the size of the buffer,
           and replace all sizeof on dataStr with this variable  */
        dataStrLen = EV_MaxFieldLenWithoutText;
        if ((dataStr = (char *)CALLOC(dataStrLen, sizeof(char))) == NULL)
        {
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        int dbFld = DBA_GetFirstCustFld(object); /* PMSTA-18593 - LJE - 151022 */

        /* If Id field must be inserted */
        if (((insOptions & DBA_INS_ID) == DBA_INS_ID) ||
            (procedure->procParamDefPtr != NULL && procedure->procParamDefPtr->procParamTypeEn >= ProcParamType_Output && *procedure->procParamDefPtr->fldNbrPtr == 0)) /* DLA - PMSTA08801 - 100226 */
        {
            firstFld = 0;
        }

        /* Loop on each record given in input */
        for (i = 0; i < inputRecNbr; i++)
        {
            DBI_PrintSqlReqHeader(recBuffer, i, inputDataTab[i], procedure, object, maxRecInBuf, bFirstInBlock);  /* PMSTA-21641 - 071115 - PMO */
            DBI_PrintSqlReqBodyStart(recBuffer, procedure);

            /* DLA - PMSTA09887 - 110304 */
            DBA_TruncateDynStStringToMDLength(inputDataTab[i]);

            DBA_SetMagicDate(inputDataTab[i], inputSt, object);

            /* Convert each field from inital type to string */
            for (fldNbr = firstFld; fldNbr < dbFld; fldNbr++)
            {
                if (IS_DBFLD(inputSt, fldNbr) != TRUE || DictAttribClass::isPhysicalCalcEn(DBA_GetDictAttribCalcEn(object, fldNbr)) == FALSE) /* PMSTA-18593 - LJE - 150625 */
                {
                    continue;
                }

                *dataStr = END_OF_STRING;

                ret = DBI_FldToDbDataStr(dataStr, dataStrLen, inputDataTab[i], fldNbr, GET_FLD_TYPE(inputSt, fldNbr), &length, false); /* REF8844 - LJE - 030324 */

                if (ret == RET_SRV_LIB_ERR_DB_OVERFLOW)
                {
                    char            *buffer = NULL;
                    char            operationCode[64];  /* REF5629 - SSO - 010207 CODE_T -> char[64] */
                    NAME_T      attrName; /* DLA - PMSTA09887 - 101116 */

                    if ((buffer = (char*)CALLOC(384, sizeof(char))) == NULL) /* REF2691 / REF7264 - PMO */
                    {
                        FREE(dataStr);
                        MSG_RETURN(RET_MEM_ERR_ALLOC);
                    }

                    /* REF8844 - LJE - 030415 */
                    if (object == Pos)
                    {
                        strcpy(operationCode, GET_CODE(inputDataTab[i], A_Pos_OpenOpCd));
                    }
                    else if (object == EPos)
                    {
                        strcpy(operationCode, GET_CODE(inputDataTab[i], ExtPos_OpenOpCd));
                    }
                    else if (object == EOp)
                    {
                        /* DLA-PMO - REF5695 - 011012 */
                        /* REF5629 - SSO - 010207 : if coming fro productivity, codes can be null! */
                        /* we log with ids because in transaction we could locks with a dba_get... */

                        if (IS_NULLFLD(inputDataTab[i], ExtOp_Cd) == FALSE)
                        {
                            strcpy(operationCode, GET_CODE(inputDataTab[i], ExtOp_Cd));
                        }
                        else
                        {
                            sprintf(operationCode, "NULL (PtfId %" szFormatId" InstrId %" szFormatId")", /* DLA - PMSTA08801 - 100209 */
                                    GET_ID(inputDataTab[i], ExtOp_PtfId),
                                    GET_ID(inputDataTab[i], ExtOp_InstrId));
                        }
                    }
                    else if (object == BalPos)
                    {
                        strcpy(operationCode, GET_CODE(inputDataTab[i], A_BalPos_OpenOpCd));
                    }
                    else if (object == Op)
                    {
                        strcpy(operationCode, GET_CODE(inputDataTab[i], A_Op_Cd));
                    }
                    else
                    {
                        strcpy(operationCode, "Unknown");
                    }

                    attrName[0] = 0x00;
                    DICT_GetAttribInfo(object, (short)fldNbr, 0, NULL, A_DictAttr_SqlName, &attrName);

                    sprintf(buffer, "Data overflow detected while inserting %s, field %s with operation code %s",
                            DBA_GetDictEntitySqlName(object),
                            attrName,
                            operationCode);

                    MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, buffer);
                    FREE(buffer);
                }

                /* BEGIN DVP263 */
                /*
                 * Beware of numbers with no decimals!!!!!!
                 * (Do not truncate zeros for them!!!!!)
                 * GRD - 28/03/2001 - REF5877.
                 */

                if (GET_CTYPE(GET_FLD_TYPE(inputSt, fldNbr)) == DoubleCType)
                {
                    if (strchr(dataStr, '.') != NULL)   /* REF5877. */
                    {
                        p = dataStr + length;

                        while (p > dataStr && *(p - 1) == '0')
                        {
                            *(p - 1) = END_OF_STRING;
                            p--;
                            length--;
                        }
                    }
                }
                /* END  DVP263 */
                /* DLA - PMSTA08801 - 100303 */
                std::string dataString(dataStr);
                DBI_PrintSqlReqParam(recBuffer, dataString, i, procedure, fldNbr, GET_FLD_TYPE(inputSt, fldNbr), &posParam, inputDataTab[i], requestHelper);
                recBuffer += ",";
            }

            recBuffer.erase(recBuffer.end() - 1);
            recBuffer += " ";
            DBI_PrintSqlReqBodyEnd(recBuffer);
            /* If the max records are stored in the buffer */
            if ((i + 1) % maxRecInBuf == 0)
            {
                DBI_PrintSqlReqFooter(recBuffer, bFirstInBlock);
                if (dbiConn.sendCommand(recBuffer) != RET_SUCCEED)
                {
                    FREE(dataStr);

                    dbiConn.filterMsgInfos(&finalResult);

                    if (dbiConn.cancelDbRequest(COMMAND_LEVEL, CANCEL_ALL) == FALSE)
                    {
                        if (finalResult == RET_SRV_LIB_ERR_DEADLOCK)
                        {
                            return(RET_SRV_LIB_ERR_FATAL_DEADLOCK);
                        }
                    }

                    /* Close the transaction if opened in the function */
                    if ((finalResult != RET_SRV_LIB_ERR_DEADLOCK) && ((insOptions & DBA_IN_TRAN) != DBA_IN_TRAN))
                        dbiConn.endTransaction(FALSE);


                    if (finalResult != RET_SRV_LIB_ERR_DEADLOCK)
                        return(RET_DBA_ERR_DBPROBLEM);

                    return finalResult;
                }
                posParam = 0;

                firstRecInList = i + 1 - maxRecInBuf + errorRecInList;
                errorRecInList = 0; /* REF11078 - LJE - 051007 : For remove */
                ret = DBI_ProcessAllAccessResults(dbiConn,
                                                  firstRecInList,
                                                  maxRecInBuf,
                                                  insOptions,
                                                  UNUSED,
                                                  &eltPos,
                                                  inputDataTab,
                                                  Insert,
                                                  object,
                                                  UNUSED,
                                                  0,   /* REF11780 - 100406 - PMO */
                                                  procedure); /* DLA - PMSTA08801 - 100325 */


                if (ret != RET_SUCCEED) /* REF4001 - SSO - 991004 */
                {
                    if (ret == RET_SRV_LIB_ERR_FATAL_DEADLOCK)
                    {
                        FREE(dataStr);
                        return(ret);
                    }

                    if (ret == RET_SRV_LIB_ERR_TRIGGER_MSG)
                    {
                        i = firstRecInList + eltPos;
                        errorRecInList = i; /* REF11078 - LJE - 051007 */
                    }

                    finalResult = (ret == RET_SRV_LIB_ERR_DEADLOCK)
                        ? RET_SRV_LIB_ERR_DEADLOCK
                        : RET_SRV_LIB_ERR_ERRORS_OCCURED;

                    /* REF4001 - SSO - 991004: stop if deadlock (transaction has been rollbacked!) */
                    if (finalResult == RET_SRV_LIB_ERR_DEADLOCK && dbiConn.isInTransaction() == true)
                    {
                        FREE(dataStr);
                        return(finalResult);
                    }
                }
                recBuffer.clear();
            }
        }

        /* If all records have been inserted */
        /* Send the request to the server (last block) */
        if (i % maxRecInBuf != 0 && (finalResult == RET_SUCCEED || dbiConn.isInTransaction() == false))  /* REF4001 - SSO - 991004 */ /* REF9039 - LJE - 030509 */
        {
            DBI_PrintSqlReqFooter(recBuffer, bFirstInBlock);
            if (dbiConn.sendCommand(recBuffer) != RET_SUCCEED)
            {
                dbiConn.filterMsgInfos(&finalResult);
                FREE(dataStr);

                if (FALSE == dbiConn.cancelDbRequest(COMMAND_LEVEL, CANCEL_ALL))
                {
                    if (finalResult == RET_SRV_LIB_ERR_DEADLOCK)
                        return(RET_SRV_LIB_ERR_FATAL_DEADLOCK);
                }

                /* Close the transaction if opened in the function */
                if ((finalResult != RET_SRV_LIB_ERR_DEADLOCK) && ((insOptions & DBA_IN_TRAN) != DBA_IN_TRAN))
                    dbiConn.endTransaction(FALSE);

                if (finalResult == RET_SRV_LIB_ERR_DEADLOCK)
                    return finalResult;

                return(RET_DBA_ERR_DBPROBLEM);
            }
            posParam = 0;
            FREE(dataStr);

            firstRecInList = i - (i % maxRecInBuf);
            ret = DBI_ProcessAllAccessResults(dbiConn,
                                              firstRecInList,
                                              maxRecInBuf,
                                              insOptions,
                                              UNUSED,
                                              &eltPos,
                                              inputDataTab,
                                              Insert,
                                              object,
                                              UNUSED,
                                              0,   /* REF11780 - 100406 - PMO */
                                              procedure); /* DLA - PMSTA08801 - 100325 */



            if (ret != RET_SUCCEED) /* REF4001 - SSO - 991004 */
            {
                if (ret == RET_SRV_LIB_ERR_FATAL_DEADLOCK)
                {
                    return(ret);
                }

                finalResult = (ret == RET_SRV_LIB_ERR_DEADLOCK)
                    ? RET_SRV_LIB_ERR_DEADLOCK
                    : RET_SRV_LIB_ERR_ERRORS_OCCURED;

                /* REF4001 - SSO - 991004: stop if deadlock (transaction has been rollbacked!) */
                if (finalResult == RET_SRV_LIB_ERR_DEADLOCK && dbiConn.isInTransaction() == true)
                {
                    return(finalResult);
                }
            }

        }
        else
        {
            FREE(dataStr);
        }
    }
    else
    {
        requestHelper.startProcedureCallForBatch(procedure);
        for (i = 0; i < inputRecNbr; i++)
        {
            requestHelper.setNewRecordForBatch(inputDataTab[i]);
        }
        requestHelper.executeBatch();
    }


    /* REF9039 - LJE - 030509 : Move here */
    if (finalResult == RET_SUCCEED && DBA_GetCustFldNbr(object) > 1)
    {
        int                 udIdIdx;

        /***** ud_id idx in inputSt *****/
        udIdIdx = DBA_GetFirstCustFld(object); /* PMSTA-11505 - LJE - 110615 */

        /**** DVP400 ****/

        for (i = 0; i < inputRecNbr; i++)
        {
            /* REF8500 - 040510 - PMO */
            if (object == EOp)
            { /* Support of remapping of id */
                SET_ID(inputDataTab[i], udIdIdx, OPE_GetOpIdFromExtOp(inputDataTab[i]));
            }
            else
            { /* Standard case */
                SET_ID(inputDataTab[i], udIdIdx, GET_ID(inputDataTab[i], 0));
            }
        }

        finalResult = DBA_UpdateByBlock(object,
                                        DBA_ROLE_UPD_UD_FIELDS,
                                        inputSt,
                                        inputDataTab,
                                        inputRecNbr,
                                        insOptions,
                                        dbiConn,
                                        requestHelper,
                                        maxRecInBuf);    /* REF4993 - SSO - 000710 UNUSED-> msgStructHeader */
    }

    /* Close the transaction if opened in the function */
    if ((insOptions & DBA_IN_TRAN) != DBA_IN_TRAN
        && finalResult != RET_SRV_LIB_ERR_DEADLOCK)   /* REF4001 - SSO - 991004 */
    {
        dbiConn.endTransaction(finalResult == RET_SUCCEED); /* REF4001 - SSO - 991004 */
    }

    return(finalResult);
}

/************************************************************************
*   Function             : DBA_UpdateByBlock()
*
*   Description          : Send many UPDATE requests to the server and retrieve
*                          returned status
*
*   Arguments            : object       : the request corresponding object
*                          role         : the role to use
*                          inputSt      : the input dynamic struct. format
*                          inputDataTab : the pointer on the input dynamic struct. array
*                          inputRecNbr  : the input records number in inputDataTab
*                          updOptions   : can be DBA_SET_CONN, DBA_NO_CLOSE, DBA_IN_TRAN, UNUSED
*                          allocConn    : 1. pointer which will contain the connectNo
*                                            used for the request if updOptions is
*                                            DBA_NO_CLOSE.
*                                         2. pointer which contain a connection number
*                                            if updOptions is DBA_SET_CONN or DBA_IN_TRAN.
*                          maxRecInBuf  : the maximum records number in one data block (def : 50)
*                          msgStructPtr : pointer on a structure which will contain
*                                         recieved messages informations.
*
*   Return               : RET_SUCCEED              : if no problem was detected
*                          RET_DBA_ERR_ARGNOMATCH   : if input arg. problem
*                          RET_DBA_ERR_PROCNOTFOUND : if no procedure founded
*                          RET_DBA_ERR_SETPARAM     : if problem while setting proc. parameters
*                          RET_DBA_ERR_CONNOTFOUND  : if no connection founded
*                          RET_DBA_ERR_DBPROBLEM    : if DB/connection problem
*                          RET_DBA_ERR_SYBBIND      : if poblem while binding received fields
*                          RET_MEM_ERR_ALLOC        : if allocation failed
*                          RET_DBA_ERR_READ_DATA    : if problem while reading received data
*                          RET_GEN_ERR_INVARG       : if problem while setting function params.
*                          a RET_CODE               : if a message has been received
*
*   Creation Date        : 22.05.96 - PEC - Ref.: DVP061.
*   Last Modification    : 22.11.96 - PEC - Ref.: DVP263.
*                          04.10.99 - SSO - Ref.: REF4001.
*                          10.05.00 - SSO - Ref.: REF2697.
*                          04.12.00 - SSO - Ref.: REF5010.
*                          07.02.01 - SSO - Ref.: REF5629.
*                          28.03.01 - GRD - Ref.: REF5877.
*                          REF7264 - 0201225 - PMO : Compilation errors and warnings with C++ compiler
*                          REF9484 - TEB - 030919
*                          REF11780 - 100406 - PMO : Implementation of the Sybase timestamp field
*                          PMSTA-21641 - 071115 - PMO : GUI Oracle Fusion fails
*                          PMSTA-25268 - 161116 - PMO : Fusion on portfolio failed
*
*************************************************************************/
RET_CODE DBA_UpdateByBlock(OBJECT_ENUM           object,
                           int                   role,
                           DBA_DYNST_ENUM        inputSt,
                           DBA_DYNFLD_STP        *inputDataTab,
                           int                   inputRecNbr,
                           int                   updOptions,
                           DbiConnection&        dbiConn,
                           RequestHelper&        requestHelper,
                           int                   maxRecInBuf)
{
    int             firstFld = 0;
    int             length;
    int             dbFld;
    int             i;
    int             fldNbr;
    RET_CODE        finalResult = RET_SUCCEED;
    RET_CODE        ret;
    char *          p;
    char *          dataStr;
    std::string     recBuffer;
    int             eltPos;
    int             firstRecInList;
    bool            bFirstInBlock = true;        /* PMSTA-18593 - LJE - 151103 */
    int             posParam = 0;

    /* Retrieve a procedure in the object procedures list */
    DBA_PROC_STP procedure = DBA_GetStoredProcs(Update, object, role, inputSt, inputDataTab[0], NullDynSt, true);

    /* If no procedure */
    if (procedure == NULL)
    {
        char    objString[40];
        const char *sqlName = DBA_GetDictEntitySqlName(object);
        OBJECT_ENUM objEn;                  /* REF2697 - SSO - 000510 */

        if (sqlName != NULL)
        {
            strcpy(objString, sqlName);
        }
        else
        {
            sprintf(objString, "unknown(" szFormatObj ")", object);/* REF2697 - SSO - 000510 */
        }

        DBA_GetObjectEnumByDynSt(inputSt, &objEn);  /* REF2697 - SSO - 000510 */
        char * entitySqlNameIn = (char*)DBA_GetDictEntitySqlName(objEn);

        if (entitySqlNameIn == NULL)
        {
            char entityStrIn[13];        /* REF2697 - SSO - 000510 */

            sprintf(entityStrIn, "unknown(%d)", inputSt);
            entitySqlNameIn = entityStrIn;
        }

        DBA_LogMesgProcedureNotFound(Update, object, role, inputSt, inputDataTab[0], NullDynSt, true, "UpdateByBlock", objString, entitySqlNameIn, "none");  /* PMSTA-25268 - 161116 - PMO */

        return(RET_DBA_ERR_PROCNOTFOUND);
    }

    if (EV_UseMultiAccessByBatch == false)
    {
        /* PMSTA08497 - DDV - 090806 - Use a variable to know the size of the buffer,
           and replace all sizeof on dataStr with this variable  */
        int dataStrLen = EV_MaxFieldLenWithoutText;
        if ((dataStr = (char *)CALLOC(dataStrLen, sizeof(char))) == NULL)
        {
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        if (role == DBA_ROLE_UPD_UD_FIELDS)
        {
            firstFld = DBA_GetFirstCustFld(object); /* PMSTA-11505 - LJE - 110615 */
            dbFld = firstFld + DBA_GetCustFldNbr(object);
        }
        else
        {
            dbFld = DBA_GetFirstCustFld(object); /* PMSTA-18593 - LJE - 151022 */
        }

        /* Loop on each record given in input */
        for (i = 0; i < inputRecNbr; i++)
        {
            /* PMSTA-28305 - RAK - 170905 - put the Header each time before the start */
            DBI_PrintSqlReqHeader(recBuffer, 0, inputDataTab[0], procedure, object, maxRecInBuf, bFirstInBlock);  /* PMSTA-21641 - 071115 - PMO */
            DBI_PrintSqlReqBodyStart(recBuffer, procedure);

            /* DLA - PMSTA09887 - 110304 */
            DBA_TruncateDynStStringToMDLength(inputDataTab[i]);

            DBA_SetMagicDate(inputDataTab[i], inputSt, object);

            /* Convert each field from inital type to string */
            for (fldNbr = firstFld; fldNbr < dbFld; fldNbr++)
            {
                if (IS_DBFLD(inputSt, fldNbr) != TRUE || DictAttribClass::isPhysicalCalcEn(DBA_GetDictAttribCalcEn(object, fldNbr)) == FALSE)
                {
                    continue;
                }

                *dataStr = END_OF_STRING;

                ret = DBI_FldToDbDataStr(dataStr, dataStrLen, inputDataTab[i], fldNbr, GET_FLD_TYPE(inputSt, fldNbr), &length, false); /* REF8844 - LJE - 030324 */

                if (ret == RET_SRV_LIB_ERR_DB_OVERFLOW)
                {
                    char            *buffer = (char*)CALLOC(384, sizeof(char)); /* REF7264 - PMO */
                    char            operationCode[64];  /* REF5629 - SSO - 010207 CODE_T -> char[64] */
                    NAME_T      attrName; /* DLA - PMSTA09887 - 101116 */

                    /* REF8844 - LJE - 030415 */
                    if (object == Pos)
                    {
                        strcpy(operationCode, GET_CODE(inputDataTab[i], A_Pos_OpenOpCd));
                    }
                    else if (object == EPos)
                    {
                        strcpy(operationCode, GET_CODE(inputDataTab[i], ExtPos_OpenOpCd));
                    }
                    else if (object == EOp)
                    {
                        /* DLA-PMO - REF5695 - 011012 */
                        /* REF5629 - SSO - 010207 : if coming fro productivity, codes can be null! */
                        /* we log with ids because in transaction we could locks with a dba_get... */

                        if (IS_NULLFLD(inputDataTab[i], ExtOp_Cd) == FALSE)
                        {
                            strcpy(operationCode, GET_CODE(inputDataTab[i], ExtOp_Cd));
                        }
                        else
                        {
                            sprintf(operationCode, "NULL (PtfId %" szFormatId" InstrId %" szFormatId")",/* DLA - PMSTA08801 - 100209 */
                                    GET_ID(inputDataTab[i], ExtOp_PtfId),
                                    GET_ID(inputDataTab[i], ExtOp_InstrId));
                        }

                    }
                    else if (object == BalPos)
                    {
                        strcpy(operationCode, GET_CODE(inputDataTab[i], A_BalPos_OpenOpCd));
                    }
                    else if (object == Op)
                    {
                        strcpy(operationCode, GET_CODE(inputDataTab[i], A_Op_Cd));
                    }
                    else
                    {
                        strcpy(operationCode, "Unknown");
                    }

                    attrName[0] = 0x00;
                    DICT_GetAttribInfo(object, (short)fldNbr, 0, NULL, A_DictAttr_SqlName, &attrName);

                    sprintf(buffer, "Data overflow detected while updating %s, field %s with operation code %s",
                            DBA_GetDictEntitySqlName(object),
                            attrName,
                            operationCode);

                    MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, buffer);
                    FREE(buffer);
                }

                /* BEGIN DVP263 */
                /*
                 * Beware of numbers with no decimals!!!!!!
                 * (Do not truncate zeros for them!!!!!)
                 * GRD - 28/03/2001 - REF5877.
                 */

                if (GET_CTYPE(GET_FLD_TYPE(inputSt, fldNbr)) == DoubleCType)
                {
                    if (strchr(dataStr, '.') != NULL)   /* REF5877. */
                    {
                        p = dataStr + length;

                        while (p > dataStr && *(p - 1) == '0')
                        {
                            *(p - 1) = END_OF_STRING;
                            p--;
                            length--;
                        }
                    }
                }
                /* END  DVP263 */
                std::string dataString(dataStr);
                DBI_PrintSqlReqParam(recBuffer, dataString, i, procedure, fldNbr, GET_FLD_TYPE(inputSt, fldNbr), &posParam, inputDataTab[i], requestHelper);
                recBuffer += ",";
            }

            recBuffer.erase(recBuffer.end() - 1);

            recBuffer += " ";
            DBI_PrintSqlReqBodyEnd(recBuffer);
            /* If the max records are stored in the buffer */
            if ((i + 1) % maxRecInBuf == 0)
            {
                DBI_PrintSqlReqFooter(recBuffer, bFirstInBlock);
                if (dbiConn.sendCommand(recBuffer) != RET_SUCCEED)
                {
                    dbiConn.filterMsgInfos(&finalResult);
                    FREE(dataStr);

                    if (FALSE == dbiConn.cancelDbRequest(COMMAND_LEVEL, CANCEL_ALL))
                    {
                        if (finalResult == RET_SRV_LIB_ERR_DEADLOCK)
                            return(RET_SRV_LIB_ERR_FATAL_DEADLOCK);
                    }

                    /* Close the transaction if opened in the function */
                    if ((finalResult != RET_SRV_LIB_ERR_DEADLOCK) && ((updOptions & DBA_IN_TRAN) != DBA_IN_TRAN))
                    {
                        dbiConn.endTransaction(false);
                    }

                    if (finalResult == RET_SRV_LIB_ERR_DEADLOCK)
                        return finalResult;

                    return(RET_DBA_ERR_DBPROBLEM);
                }
                posParam = 0;

                firstRecInList = i + 1 - maxRecInBuf;
                ret = DBI_ProcessAllAccessResults(dbiConn,
                                                  firstRecInList,
                                                  maxRecInBuf,
                                                  updOptions,
                                                  UNUSED,
                                                  &eltPos,
                                                  inputDataTab,
                                                  Update,
                                                  object,
                                                  UNUSED,
                                                  0,   /* REF11780 - 100406 - PMO */
                                                  procedure); /* DLA - PMSTA08801 - 100325 */



                if (ret != RET_SUCCEED) /* REF4001 - SSO - 991004 */
                {
                    if (ret == RET_SRV_LIB_ERR_FATAL_DEADLOCK)
                    {
                        FREE(dataStr);
                        /* No rollback to do */
                        return(ret);
                    }

                    if (ret == RET_SRV_LIB_ERR_TRIGGER_MSG)
                    {
                        i = firstRecInList + eltPos;
                    }

                    finalResult = (ret == RET_SRV_LIB_ERR_DEADLOCK)
                        ? RET_SRV_LIB_ERR_DEADLOCK
                        : RET_SRV_LIB_ERR_ERRORS_OCCURED;

                    /* REF4001 - SSO - 991004: stop if deadlock (transaction has been rollbacked!) */
                    if (finalResult == RET_SRV_LIB_ERR_DEADLOCK && dbiConn.isInTransaction() == true)
                    {
                        FREE(dataStr);
                        /* No rollback to do */
                        return(finalResult);
                    }
                }
                recBuffer.clear();
            }
        }

        /* If all records have been inserted */
        if (i % maxRecInBuf == 0)
        {
            /* Close the transaction if opened in the function */
            if ((updOptions & DBA_IN_TRAN) != DBA_IN_TRAN)
            {
                dbiConn.endTransaction(finalResult == RET_SUCCEED);  /* REF4001 - SSO - 991004 rollback if error */
            }

            FREE(dataStr);
            return(finalResult);
        }

        /* Send the request to the server */
        if (finalResult == RET_SUCCEED || dbiConn.isInTransaction() == false)  /* REF4001 - SSO - 991004 */
        {
            DBI_PrintSqlReqFooter(recBuffer, bFirstInBlock);

            const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
            if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
            {
                auto &sqlTrace = dbiConn.getSqlTrace();
                sqlTrace.m_procedure = "DynSql.UpdateByBlock.";
                sqlTrace.m_procedure.append(procedure->procName);
            }

            if (dbiConn.sendCommand(recBuffer) != RET_SUCCEED)       /*PMSTA-49161 - AIS - 220526*/
            {
                dbiConn.filterMsgInfos(&finalResult);
                FREE(dataStr);
                if (FALSE == dbiConn.cancelDbRequest(COMMAND_LEVEL, CANCEL_ALL))
                {
                    if (finalResult == RET_SRV_LIB_ERR_DEADLOCK)
                        return(RET_SRV_LIB_ERR_FATAL_DEADLOCK);
                }

                /* Close the transaction if opened in the function */
                if ((finalResult != RET_SRV_LIB_ERR_DEADLOCK) && ((updOptions & DBA_IN_TRAN) != DBA_IN_TRAN))
                {
                    dbiConn.endTransaction(false);
                }

                if (finalResult == RET_SRV_LIB_ERR_DEADLOCK)
                    return finalResult;

                return(RET_DBA_ERR_DBPROBLEM);
            }
            posParam = 0;

            firstRecInList = i - (i % maxRecInBuf);
            ret = DBI_ProcessAllAccessResults(dbiConn,
                                              firstRecInList,
                                              maxRecInBuf,
                                              updOptions,
                                              UNUSED,
                                              &eltPos,
                                              inputDataTab,
                                              Update,
                                              object,
                                              UNUSED,
                                              0,   /* REF11780 - 100406 - PMO */
                                              procedure); /* DLA - PMSTA08801 - 100325 */

            if (ret != RET_SUCCEED) /* REF4001 - SSO - 991004 */
            {
                if (ret == RET_SRV_LIB_ERR_FATAL_DEADLOCK)
                {
                    FREE(dataStr);
                    /* No rollback to do */
                    return(ret);
                }

                finalResult = (ret == RET_SRV_LIB_ERR_DEADLOCK)
                    ? RET_SRV_LIB_ERR_DEADLOCK
                    : RET_SRV_LIB_ERR_ERRORS_OCCURED;

                /* REF4001 - SSO - 991004: stop if deadlock (transaction has been rollbacked!) */
                if (finalResult == RET_SRV_LIB_ERR_DEADLOCK && dbiConn.isInTransaction() == true)
                {
                    FREE(dataStr);
                    /* No rollback to do */
                    return(finalResult);
                }
            }
        }

        FREE(dataStr);

        /* Close the transaction if opened in the function */
        if ((updOptions & DBA_IN_TRAN) != DBA_IN_TRAN
            && finalResult != RET_SRV_LIB_ERR_DEADLOCK)       /* REF4001 - SSO - 991004 */
        {
            dbiConn.endTransaction(finalResult == RET_SUCCEED); /* REF4001 - SSO - 991004 */
        }
    }
    else
    {
        requestHelper.startProcedureCallForBatch(procedure);
        for (i = 0; i < inputRecNbr; i++)
        {
            requestHelper.setNewRecordForBatch(inputDataTab[i]);
        }
        requestHelper.executeBatch();
    }
    return(finalResult);
}

/************************************************************************
*   Function             : DBA_FreeSubscriptionBlock()
*
*   Description          : Free Subscription buffer
*
*   Arguments            : dbiConn
*
*   Return               : RET_CODE
*
*   Creation Date        :  PMSTA-52258 - JBC - 230308
*
*   Last Modification    :
*
*************************************************************************/
void DBA_FreeSubscriptionBlock(DbiConnection & dbiConn)
{
    for (int i = 0; i < dbiConn.getConnStructPtr()->subscriptionElem.accessNbr; i++)
    {
        FREE_DYNST(dbiConn.getConnStructPtr()->subscriptionElem.accessStp[i].data, dbiConn.getConnStructPtr()->subscriptionElem.accessStp[i].entity);

    }

    dbiConn.getConnStructPtr()->subscriptionElem.accessNbr = 0;
    FREE(dbiConn.getConnStructPtr()->subscriptionElem.accessStp);
}


/************************************************************************
*   Function             : DBA_SendSubscriptionMulti()
*
*   Description          : Send Subscription buffer. Must call DBA_FreeSubscriptionBlock
*                          after processing.
*
*   Arguments            : Too much
*
*   Return               : RET_CODE
*
*   Creation Date        : PMSTA-52258 - JBC - 230308
*
*   Last Modification    :
*
*************************************************************************/
RET_CODE DBA_SendSubscriptionMulti( const int       maxRecInBuf,
                                    DbiConnection & dbiConn,
                                    const int       options)
{

    RET_CODE retCode = RET_SUCCEED;

    if(dbiConn.getConnStructPtr()->subscriptionElem.accessNbr > 0)
    {
        const int saveNoDeleteInfo = dbiConn.getConnStructPtr()->noDeleteMessageInfo;                                                          /* DLA - PMSTA05995 - 080408 */
        dbiConn.getConnStructPtr()->noDeleteMessageInfo = 1;                                                                                   /* DLA - PMSTA05995 - 080408 */
        {
            DbaMultiAccessHelper       multiAccessHelper(dbiConn.getConnStructPtr()->subscriptionElem.accessStp, dbiConn.getConnStructPtr()->subscriptionElem.accessNbr);
            retCode = multiAccessHelper.callMultiAccess(maxRecInBuf,
                                                        ((options & DBA_NO_ERROR) == DBA_NO_ERROR)
                                                        ? DBA_SET_CONN | DBA_NO_CLOSE | DBA_CHECK_UD_AUDIT | DBA_NO_ERROR
                                                        : DBA_SET_CONN | DBA_NO_CLOSE | DBA_CHECK_UD_AUDIT,
                                                        dbiConn, true);

            dbiConn.getConnStructPtr()->noDeleteMessageInfo=saveNoDeleteInfo;                                                                      /* DLA - PMSTA05995 - 080408 */

            if (retCode != RET_SUCCEED)
            {
                multiAccessHelper.sendAllMultiAccessMsg();
            }
        }
    }

    return retCode;
}

/************************************************************************
*   Function             : DBA_SendSubscription()
*
*   Description          : Send Subscription buffer
*
*   Arguments            : Too much
*
*   Return               : RET_CODE
*
*   Creation Date        : PMSTA-18552 - 150814 - PMO : After installing HF GUI 7.0.05, no event is stored when an order is input
*
*   Last Modification    :
*
*************************************************************************/
STATIC RET_CODE DBA_SendSubscription( int &                 subsRec             ,
                                int &                 eltPos              ,
                                int * &               errStatusTab        ,
                                FLAG_T &              localTranCountFlg   ,
                                const bool            loopTest            ,
                                const int             maxRecInBuf         ,
                                const int             i                   ,
                                const int             eltNbr              ,
                                DbiConnection&        dbiConn             ,
                                const int             firstRecInList      ,
                                const int             options             ,
                                DBA_ACCESS_STP        accessPtr           )
{
    const bool processing = true == loopTest
                          ? ((subsRec % maxRecInBuf == 0) || (i+1) == eltNbr) && (subsRec > 0)  /* If the max records are stored in the buffer or the buffer must be sent to SQL Server */
                          : subsRec > 0;                                                        /* Subscription buffer processing */
    RET_CODE retCode = RET_SUCCEED;


    if (processing)
    {
        if ((retCode = DBA_SendSubscriptionMulti(maxRecInBuf,dbiConn,options))!= RET_SUCCEED)
        {
            DBI_ProcessAllAccessResults(dbiConn,                                                                                                  /* DLA - PMSTA05995 - 080409 */
                                       firstRecInList,
                                       maxRecInBuf,
                                       options,
                                       accessPtr,
                                       &eltPos,
                                       NULL,
                                       Get,
                                       ApplParam,
                                       errStatusTab,
                                       eltNbr,
							           UNUSED);                                                                                                     /* DLA - PMSTA08801 - 100325 */

            if (localTranCountFlg == TRUE)                                                                                                          /* REF5699 */
            {
                dbiConn.endTransaction(FALSE);
                localTranCountFlg = FALSE;
            }

            /* All record must be flagged as errors*/ /* DLA - PCC-14920 - 101111 */
            DBA_FlagAllTheBlockToError(dbiConn, eltNbr);
        }
        else
        {
            /* DLA - REF10247 - 060320 - Supress EventUpdate */
            subsRec = 0;
        }

        DBA_FreeSubscriptionBlock(dbiConn);
    }
    return retCode;
}

/************************************************************************
*   Function             : DBA_MultiAccess()
*
*   Description          : Send one or many SQL Dynamic requests composed of many
*                          action do proceed (Insert, Update or Delete).
*
*   Arguments            : accessPtr          : data array containing for each element :
*                                                - action (Insert, Update, Delete, Notif)
*                                                - role
*                                                - object
*                                                - entity
*                                                - data
*
*                          eltNbr             : the number of elements in accessPtr.
*                          maxRecInBuf        : the max number of elements in a SQL Dynamic buffer.
*                          options            : can be DBA_SET_CONN, DBA_NO_CLOSE, DBA_INS_ID.
*                          allocConn          : pointer on a connection number.
*                          msgStructPtrHeader : pointer on a header of message structure.
*
*   Return               : RET_SUCCEED                     : if no problem was detected.
*                          RET_DBA_ERR_ARGNOMATCH          : if input arg. problem.
*                          RET_DBA_ERR_PROCNOTFOUND        : if no procedure founded.
*                          RET_DBA_ERR_SETPARAM            : if problem while setting proc. parameters.
*                          RET_DBA_ERR_CONNOTFOUND         : if no connection founded.
*                          RET_DBA_ERR_DBPROBLEM           : if DB/connection problem.
*                          RET_MEM_ERR_ALLOC               : if allocation failed.
*                          RET_SRV_LIB_ERR_ERRORS_OCCURED  : if one or many errors occurred .
*
*   Creation Date        : 07.11.96 - PEC - Ref.: DVP244.
*   Last Modification    : 24.12.96 - PEC - Ref.: BUG244.
*                          13.03.97 - PEC - Ref.: BUG300.
*                          27.05.97 - PEC - Ref.: BUG379.
*                          02.07.97 - PEC - Ref.: BUG416.
*                          20.10.97 - GRD - Ref.: REF494.
*                          07.07.98 - GRD - Ref.: REF2220.
*                          12.05.99 - GRD - Ref.: REF3685.
*                          08.06.99 - SSO - Ref.: REF3736.
*                          04.10.99 - SSO - Ref.: REF4001.
*                          25.03.00 - GRD - Ref.: REF4204.
*                          09.05.00 - GRD - Ref.: REF4714.
*                          28.07.00 - GRD - Ref.: REF5038.
*                          06.10.00 - GRD - Ref.: REF5278.
*                          01.02.01 - GRD - Ref.: REF5644.
*                          06.02.01 - GRD - Ref.: REF5616.
*                          07.02.01 - SSO - Ref.: REF5629.
*                          19.02.01 - GRD - Ref.: REF5699.
*                          28.03.01 - GRD - Ref.: REF5877.
*                          09.04.01 - GRD - Ref.: REF5037.
*                          REF7264 - 0201225 - PMO : Compilation errors and warnings with C++ compiler
*                          REF8116 - 021023 - PMO : Regression on accounting operations :  the ext_order_id is lost
*                          REF8696 - 030114 - PMO : Unable to insert when audit trail is enable
*                          REF9484 - TEB - 030919 :
*                          REF8712 - 031114 - PMO : Purify, corrections of memory leaks, ...
*                          REF10243 - 040713 - PMO : aaaauditdb..aud_ud_ext_operation.ud_aud_modif_d not updated when using aaa_imp in optimised mode
*                          REF11503 - 051018 - EFE : modify currency doesn't work
*                          REF11780 - 100406 - PMO : Implementation of the Sybase timestamp field
*                          PMSTA-17621 - 140214 - PMO : Communication records of an order cannot be displayed in the GUI
*                          PMSTA-18365 - 100714 - PMO : Fusion fails for an investment operation with quote = 0
"                          PMSTA-18552 - 150814 - PMO : After installing HF GUI 7.0.05, no event is stored when an order is input
*                          PMSTA-21641 - 071115 - PMO : GUI Oracle Fusion fails
*                          PMSTA-25268 - 161116 - PMO : Fusion on portfolio failed
*                          PMSTA-32016 - 290618 - PMO : Out of bound access in MultiAccess
*
*************************************************************************/
RET_CODE DBA_MultiAccess(DBA_ACCESS_STP        accessPtr,
    const int             eltNbr,          /* PMSTA-18552 - 150814 - PMO */
    int                   maxRecInBuf,
    int                   options,
    int *                 allocConn)
{
    return(DBA_MultiAccessInternal(accessPtr, eltNbr, maxRecInBuf, options, allocConn, false));
}

RET_CODE DBA_MultiAccessInternal(DBA_ACCESS_STP        accessPtr,
                                 const int             eltNbr,          /* PMSTA-18552 - 150814 - PMO */
                                 int                   maxRecInBuf,
                                 int                   options,
                                 int *                 allocConn,
                                 bool                  bStoreErrMsgInElt)
{
    RET_CODE ret = RET_SUCCEED;
    DbiConnection * dbiConn = nullptr;

    /* If no connection number is given */
    if ((options & DBA_SET_CONN) != DBA_SET_CONN)
    {
        /* Get a free connection */
        if ((dbiConn = DBA_GetDbiConnection(SqlServer)) == nullptr)
        {
            if (allocConn != UNUSED)
            {
                *allocConn = DBA_CONN_NOT_FOUND;
            }

            MSG_RETURN(RET_DBA_ERR_CONNOTFOUND);
        }
        else
        {
            /* Initialize the block mode (set the blockMode */
            dbiConn->getConnStructPtr()->blockMode = 1;
        }

    }
    else
    {
        /* If a connection number is given */
        if (allocConn != UNUSED)
        {
            dbiConn = DBA_GetDbiConnFromConnectNo(*allocConn);
            if (dbiConn == nullptr) {
                return RET_DBA_ERR_CONNOTFOUND;
            }
        }
        else
        {
            MSG_RETURN(RET_DBA_ERR_ARGNOMATCH);
        }
    }

    ret = DBA_MultiAccessInternal(accessPtr,
                                  eltNbr,          /* PMSTA-18552 - 150814 - PMO */
                                  maxRecInBuf,
                                  options,
                                  *dbiConn,
                                  bStoreErrMsgInElt);

    if ((options & DBA_NO_CLOSE) != DBA_NO_CLOSE)
    {
        dbiConn->sendAllMsgFromMA();
        DBA_EndConnection(&dbiConn);
    }

    return ret;
}

RET_CODE DBA_MultiAccess(DBA_ACCESS_STP        accessPtr,
    const int             eltNbr,          /* PMSTA-18552 - 150814 - PMO */
    int                   maxRecInBuf,
    int                   options,
    DbiConnection&        dbiConn)
{
    return(DBA_MultiAccessInternal(accessPtr, eltNbr, maxRecInBuf, options, dbiConn, false));
}

STATIC RET_CODE DBA_MultiAccessInternal(DBA_ACCESS_STP        accessPtr,
                                        const int             eltNbr,          /* PMSTA-18552 - 150814 - PMO */
                                        int                   maxRecInBuf,
                                        int                   options,
                                        DbiConnection&        dbiConn,
                                        bool                  bStoreErrMsgInElt)
{
    int                 x                     = 0;
    int                 dbFld                 = 0;
    int                 firstFld              = 1;
    int                 i                     = 0;
    int                 sqlRec                = 0;
    int                 subsRec               = 0;
    int                 eltPos                = 0;
    int                 operEltNbr            = 0;
    int                 firstRecInList        = 0;
    int                 lastRecInList         = 0;
    int                 errStatusIdx          = 0;
    int                 opIdx                 = 0;
    int                 udActionsNbr          = 0;
    int                 blockOptions          = 0;
    int                 outInsSubscriptionNbr = 0;
    int                 outUpdSubscriptionNbr = 0;
    int                 outDelSubscriptionNbr = 0;                /* REF4204 */
    int                 errCpt                = 0;
    int *               errStatusTab          = 0;
    char *              text                  = NULL;
    char *              dataStr               = NULL;             /* PMSTA07121 - DDV - 090304 - Adaptation for new long strings datatypes */
    RET_CODE            retCode               = RET_SUCCEED;
    RET_CODE            returnedRet           = RET_SUCCEED;      /* returned code REF4001 - SSO - 991004  */
    FLAG_T              triggerErrorFlg       = FALSE;
    FLAG_T              mustSendSqlBuf        = FALSE;
    FLAG_T              sendForFirstRec       = FALSE; /* PMSTA-41309 - DDV - 200810 */
    std::string         recBuffer;
    DBA_ACCESS_STP      udAccessPtr           = NULL;             /* BUG244 */
    DBA_DYNFLD_STP    * outInsSubscriptionTab = NULL;
    DBA_DYNFLD_STP *    outUpdSubscriptionTab = NULL;
    DBA_DYNFLD_STP *    outDelSubscriptionTab = NULL;
    DBA_DYNFLD_STP      inSubscriptionSt      = NULL;             /* REF4204 */
    FLAG_T              localTranCountFlg     = FALSE;            /* REF5699 */
    bool                bFirstInBlock         = true;             /* PMSTA-18593 - LJE - 151103 */
    int                 posParam              = 0;
    int                 dataStrLen            = EV_MaxFieldLenWithoutText; /* PMSTA08497 - DDV - 090806 - Use a variable to know the size of the buffer, and replace all sizeof on dataStr with this variable  */
    bool                bForceRowByRow        = false;

    /* PMSTA-33082 - DDV - 210315 */
    if (EV_UseMultiAccessByBatch)
    {
        if (dbiConn.isInTransaction() == false)
        {
            dbiConn.beginTransaction();
            localTranCountFlg = TRUE;
        }
    }

    RequestHelper       requestHelper(&dbiConn);
    requestHelper.setBatchMode(DbiConnection::BatchMode::ExecuteOnce);

    if (eltNbr <= 0 || accessPtr == NULL)
    {
        return(RET_DBA_ERR_ARGNOMATCH);
    }

    /* REF494. */
    if ((options & DBA_NO_ERROR) == DBA_NO_ERROR)
    {
        blockOptions = DBA_NO_ERROR;
    }

    /* DBA_NO_ERROR is accepted only if a transaction is already opened. REF4714. */
    if (((options & DBA_NO_ERROR) == DBA_NO_ERROR) && (dbiConn.isInTransaction() == false))
    {
        SYS_BreakOnDebug();
        return(RET_GEN_ERR_NOACTION);
    }

    if (maxRecInBuf == UNUSED)
    {
        maxRecInBuf = 50;
    }

    /* Fix ext_operation id for update, now proc upd_ext_operation use draft_order_id */
    for (i = 0; i < eltNbr; i++)
    {
        if (accessPtr[i].object == EOp && 
            accessPtr[i].action == Update && 
            accessPtr[i].role == DBA_ROLE_RECONCILE_STRATEGY &&
            IS_NULLFLD(accessPtr[i].data, ExtOp_DraftOrderId) == TRUE)
        { 
            SET_ID(accessPtr[i].data, ExtOp_DraftOrderId, GET_EXTOP_DATABASE_ID(accessPtr[i].data));
        }
    }

    dbiConn.setMultiAccessLangRequest(true);

    /* PMSTA-27116 - CHU - 170501 : Sometimes EV_MaxFieldLenWithoutText (20000) is not enough for Audit */
    if (accessPtr[0].object == Audit)
        dataStrLen = EV_MaxFieldLen; /* Then set it to 65534 */

    if ((dataStr = (char *)CALLOC(dataStrLen + 1, sizeof(char))) == NULL)
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    if ((errStatusTab = (int *)CALLOC(eltNbr, sizeof(int))) == NULL)
    {
        FREE(dataStr);
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    RequestHelper requestParamHelp(&dbiConn); /* PMSTA-26000 - LJE - 170130 */

    DBA_PROC_STP procedure = DBA_GetStoredProcs(accessPtr[0].action,
                                                accessPtr[0].object,
                                                accessPtr[0].role,
                                                accessPtr[0].entity,
                                                accessPtr[0].data,
                                                NullDynSt,
                                                true);

    DBA_PROC_STP initialProcedure = NULL; /* PMSTA-34753 - DDV - 190219 */

    /* PMSTA-25268 - 161116 - PMO */
    if (nullptr == procedure && nullptr != dbiConn.getConnStructPtr()->msgOptions && true == dbiConn.getConnStructPtr()->msgOptions->strictErrorHandling)
    { // For the fusion, log with problem
        DBA_LogMesgProcedureNotFound(accessPtr[0].action,
                                     accessPtr[0].object,
                                     accessPtr[0].role,
                                     accessPtr[0].entity,
                                     accessPtr[0].data,
                                     NullDynSt,
                                     true,
                                     DBA_GetActionName(accessPtr[0].action).c_str(),
                                     DBA_GetDictEntitySqlOrObjectName(accessPtr[0].object, accessPtr[0].entity).c_str(),
                                     DBA_GetDictEntitySqlOrObjectName(accessPtr[0].object, accessPtr[0].entity).c_str(),
                                     "none");
    }

    /* DLA - PMSTA09887 - 110304 */
    DBA_TruncateDynStStringToMDLength(accessPtr[0].data);

    /* Subscription. */
    if (((procedure == NULL || (procedure->procMask & PROCMASK_DISABLE_SUBSCRIPTION) != PROCMASK_DISABLE_SUBSCRIPTION)) &&  /* DLA - REF10507 - 041012 */ /* DLA - REF10711 - 041020 / REF10845 - 050118 - PMO */
        ((accessPtr[0].role == DBA_ROLE_SUBSCRIPTION) ||
        (!(DBA_IsAnOperationObject(accessPtr[0].object) || accessPtr[0].object == EOp || accessPtr[0].object == Op || accessPtr[0].object == ConstraintBreach)) &&
         ((options & DBA_CHECK_UD_AUDIT) != DBA_CHECK_UD_AUDIT))) /* REF5644 */
    {
        if ((inSubscriptionSt = ALLOC_DYNST(A_Subscription)) == NULL)
        {
            FREE(dataStr);
            FREE(errStatusTab);
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        SET_DICT(inSubscriptionSt, A_Subscription_EntityDictId,
            (DBA_GetDictEntityStSafe(accessPtr[0].object))->entDictId);
        SET_ENUM(inSubscriptionSt, A_Subscription_ActionEn, Subscription_Action_Insert);
        SET_ENUM(inSubscriptionSt, A_Subscription_ModuleEn, dbiConn.getSubscriptionModuleEn());

        DBA_Select2(Subscription,
                    DBA_ROLE_SEL_SUBSCRIPTIONS,
                    A_Subscription,
                    inSubscriptionSt,
                    A_Subscription,
                    &outInsSubscriptionTab,
                    DBA_SET_CONN | DBA_NO_CLOSE,
                    UNUSED,
                    &outInsSubscriptionNbr,
                    dbiConn);

        SET_DICT(inSubscriptionSt, A_Subscription_EntityDictId,
            (DBA_GetDictEntityStSafe(accessPtr[0].object))->entDictId);
        SET_ENUM(inSubscriptionSt, A_Subscription_ActionEn, Subscription_Action_Update);
        SET_ENUM(inSubscriptionSt, A_Subscription_ModuleEn, dbiConn.getSubscriptionModuleEn());

        DBA_Select2(Subscription,
                    DBA_ROLE_SEL_SUBSCRIPTIONS,
                    A_Subscription,
                    inSubscriptionSt,
                    A_Subscription,
                    &outUpdSubscriptionTab,
                    DBA_SET_CONN | DBA_NO_CLOSE,
                    UNUSED,
                    &outUpdSubscriptionNbr,
                    dbiConn);

        SET_DICT(inSubscriptionSt, A_Subscription_EntityDictId,
            (DBA_GetDictEntityStSafe(accessPtr[0].object))->entDictId);
        SET_ENUM(inSubscriptionSt, A_Subscription_ActionEn, Subscription_Action_Delete);
        SET_ENUM(inSubscriptionSt, A_Subscription_ModuleEn, dbiConn.getSubscriptionModuleEn());

        DBA_Select2(Subscription,
                    DBA_ROLE_SEL_SUBSCRIPTIONS,
                    A_Subscription,
                    inSubscriptionSt,
                    A_Subscription,
                    &outDelSubscriptionTab,
                    DBA_SET_CONN | DBA_NO_CLOSE,
                    UNUSED,
                    &outDelSubscriptionNbr,
                    dbiConn);

        FREE_DYNST(inSubscriptionSt, A_Subscription);

        /*
         * In the case the interface uses the subscription but tolerates errors, events
         * could be inserted into table 'event' or 'audit' even though NO RECORD has been treated in DB.
         * We MUST open a transaction before managing blocks.
         * GRD - 19/02/01 - REF5699
         */

        if ((dbiConn.isInTransaction() == false) && (SYS_IsBatchMode() == TRUE))
        {
            dbiConn.beginTransaction();
            localTranCountFlg = TRUE;
        }
    }

    /*
     * If current record is an operation and operations are already handled by C treatment and
     * the procedure is an internal proc OR If procedure is NULL.
     */

     /* EOp was EPos - BUG379 */
    if (((DBA_IsAnOperationObject(accessPtr[0].object) || accessPtr[0].object == EOp || accessPtr[0].object == Op) &&
        (options & DBA_OP_BLOCK) == DBA_OP_BLOCK && procedure != NULL && procedure->server == InternalProc) ||
        procedure == NULL && accessPtr[0].role != DBA_ROLE_SUBSCRIPTION)
    {
        DBA_ERRMSG_INFOS_STP errMsgInfoStp=nullptr;

        if (bStoreErrMsgInElt)
        {

            if (accessPtr[0].msgStructHeaderStp == nullptr)
            {
                accessPtr[0].msgStructHeaderStp = new DbaErrmsgHeaderClass();
            }
            errMsgInfoStp = &(accessPtr[0].msgStructHeaderStp->getNewErrMsgInfoSt(FILEINFO));
        }
        else
        {
            errMsgInfoStp = &(dbiConn.m_msgStructHeaderSt.getNewErrMsgInfoSt(FILEINFO));
        }

        errStatusTab[0] = TRUE;
        errCpt++;
        returnedRet = RET_SRV_LIB_ERR_ERRORS_OCCURED;


        text = MSG_BuildMesg(UNUSED, UNUSED, "Procedure not found in internal "
                             "list (action=%1, object=%2, inputSt=%3, "
                             "outputSt=%4)",
                             IntType, accessPtr[0].action,
                             IntType, accessPtr[0].object,
                             IntType, accessPtr[0].entity,
                             IntType, NullDynSt);

        MSG_FillMsgStruct(errMsgInfoStp,
                          RET_DBA_ERR_PROCNOTFOUND,
                          text,
                          NullHandler,
                          RET_LEV_TECH_C_ERROR,
                          TRUE,
                          NULL,
                          NULL,
                          0);

        errMsgInfoStp->firstInList = 0;
        errMsgInfoStp->lastInList = 0;
        FREE(text);

        /* REF494 971020. GRD */
        if ((options & DBA_NO_ERROR) == DBA_NO_ERROR)
        {
            if (localTranCountFlg == TRUE)              /* REF5699 */
            {
                dbiConn.endTransaction(FALSE);   /* Rollback. */
                localTranCountFlg = FALSE;
                /* All record must be flagged as errors*/ /* DLA - PCC-14920 - 101111 */
                DBA_FlagAllTheBlockToError(dbiConn, eltNbr);
            }

            FREE(udAccessPtr);
            FREE(dataStr);
            FREE(errStatusTab);
            return(RET_DBA_ERR_PROCNOTFOUND);
        }
    }
    else
    {
        /* Handle first element : check if it's an operation or extended operation */
        /* EOp was EPos - BUG379 */
        if ((DBA_IsAnOperationObject(accessPtr[0].object) || accessPtr[0].object == EOp || accessPtr[0].object == Op) &&
            (options & DBA_OP_BLOCK) != DBA_OP_BLOCK && accessPtr[0].role != DBA_ROLE_SUBSCRIPTION &&
            (accessPtr[0].role != DBA_ROLE_RECONCILE_STRATEGY)) /* DLA-REF11171-050601 / REF11503-EFE-051018*/
        {
            operEltNbr++;
        }
        else
        {
            retCode = DBA_MultiAccessTreatElt(accessPtr[0],           /*  accessElt,             */
                                              0,                      /*  eltIdx,                */
                                              eltNbr,                 /*  eltNbr,                */
                                              &procedure,             /* *procedure,             */
                                              &initialProcedure,      /* *initialProcedure,      */
                                              outInsSubscriptionTab,  /* *outInsSubscriptionTab, */
                                              outUpdSubscriptionTab,  /* *outUpdSubscriptionTab, */
                                              outDelSubscriptionTab,  /* *outDelSubscriptionTab, */
                                              outInsSubscriptionNbr,  /*  outInsSubscriptionNbr, */
                                              outUpdSubscriptionNbr,  /*  outUpdSubscriptionNbr, */
                                              outDelSubscriptionNbr,  /*  outDelSubscriptionNbr, */
                                              &subsRec,               /* *subsRec,               */
                                              dataStr,                /* *dataStr,               */
                                              dataStrLen,             /*  dataStrLen,            */
                                              recBuffer,              /*  recBuffer,             */
                                              maxRecInBuf,            /*  maxRecInBuf,           */
                                              bFirstInBlock,          /*  bFirstInBlock,         */
                                              &udAccessPtr,           /* *udAccessPtr,           */
                                              &udActionsNbr,          /* *udActionsNbr,          */
                                              &dbFld,                 /* *dbFld,                 */
                                              &sqlRec,                /* *sqlRec,                */
                                              &posParam,              /* *posParam,              */
                                              dbiConn,                /*  dbiConn,               */
                                              options,                /*  options,               */
                                              requestHelper);         /*  requestHelper          */

            /* PMSTA-33082 - DDV - 210511 - When error occurs, force row by row and continue */
            if (retCode != RET_SUCCEED)
            {
                errCpt++;
                bForceRowByRow = true;
                retCode = RET_SUCCEED;
				requestHelper.clearMsg(); /* PMSTA-53403 - LJE - 230622 */
            }
        }
    }

    if (sqlRec == maxRecInBuf)
    {
        mustSendSqlBuf = TRUE;
        sendForFirstRec = TRUE; /* PMSTA-41309 - DDV - 200810 */
    }

    errStatusIdx = 1;

    /* Processing Subscription when we do not enter in the following loop    PMSTA-18552 - 150814 - PMO */
    const bool sendSubscription = eltNbr <= 1;

    for (i = 1; i < eltNbr; i++)
    {
        /* DLA - PMSTA-10877 - 110103 , if NullAction we jump the record (in error before) */
        if (accessPtr[i].action != NullAction)
        {

            /* REF4001 - SSO - 991004: stop if deadlock (transaction has been rollbacked!) */
            if (dbiConn.isInTransaction() == true && returnedRet == RET_SRV_LIB_ERR_DEADLOCK)
            {
                break;
            }

            /* DLA - PMSTA09887 - 110304 */
            DBA_TruncateDynStStringToMDLength(accessPtr[i].data);

            /*
             * In the case the interface uses the subscription but tolerates errors, events
             * could be inserted into table 'event' or 'audit' even though NO RECORD has been treated in DB.
             * We MUST open a transaction before managing blocks.
             * GRD - 19/02/01 - REF5699
             */

            if (((outInsSubscriptionNbr > 0) || (outUpdSubscriptionNbr > 0) || (outDelSubscriptionNbr > 0)) &&
                (dbiConn.isInTransaction() == false) && (SYS_IsBatchMode() == TRUE))
            {
                dbiConn.beginTransaction();
                localTranCountFlg = TRUE;
            }

            /* BEGIN BUG399 */
            if (accessPtr[i].data == NULL)
            {
                errStatusIdx++;
                continue;
            }
            /* END BUG399 */

            firstFld = 1;

            /*
             * If current element is an operation or extended operation and different actions must be
             * performed on it before send to database.
             */

             /* EOp was EPos - BUG379 */
            if ((DBA_IsAnOperationObject(accessPtr[i].object) || accessPtr[i].object == EOp || accessPtr[i].object == Op) &&
                (options & DBA_OP_BLOCK) != DBA_OP_BLOCK &&
                (accessPtr[i].role != DBA_ROLE_RECONCILE_STRATEGY)) /* DLA-REF11171-050601 / REF11503-EFE-051018*/ /* DLA - PMSTA08801 - 100323 (i instead 0)*/
            {
                ++operEltNbr;

                if (operEltNbr % maxRecInBuf == 0)
                {
                    if (sqlRec == 0)
                    {
                        /* Call C Function which will handle operation block */
                        firstRecInList = i - operEltNbr + 1;

                        retCode = DBA_HandleOperTabByBlock(dbiConn,
                                                           accessPtr,
                                                           firstRecInList,
                                                           maxRecInBuf,
                                                           operEltNbr,
                                                           blockOptions,
                                                           bStoreErrMsgInElt);

                        /* REF494 - 971020 - GRD. */
                        if (retCode != RET_SUCCEED)
                        {
                            if ((options & DBA_NO_ERROR) == DBA_NO_ERROR)
                            {
                                if (localTranCountFlg == TRUE)              /* REF5699 */
                                {
                                    dbiConn.endTransaction(FALSE);
                                    localTranCountFlg = FALSE;
                                    /* All record must be flagged as errors*/ /* DLA - PCC-14920 - 101111 */
                                    DBA_FlagAllTheBlockToError(dbiConn, eltNbr);
                                }

                                FREE(udAccessPtr);
                                FREE(dataStr);
                                FREE(errStatusTab);

                                if ((retCode == RET_SRV_LIB_ERR_DEADLOCK) ||        /* REF3685 - SSO */
                                    (retCode == RET_SRV_LIB_ERR_FATAL_DEADLOCK))
                                {
                                    return(retCode);
                                }
                                else
                                {
                                    return(RET_SRV_LIB_ERR_ERRORS_OCCURED);
                                }
                            }

                            /*
                             * Even if DBA_NO_ERROR is not set, we must exit if RET_SRV_LIB_ERR_FATAL_DEADLOCK occurred.
                             */

                            if (retCode == RET_SRV_LIB_ERR_FATAL_DEADLOCK)  /* REF3685 - SSO */
                            {
                                if (localTranCountFlg == TRUE)              /* REF5699 */
                                {
                                    dbiConn.endTransaction(FALSE);
                                    localTranCountFlg = FALSE;

                                    /* All record must be flagged as errors*/ /* DLA - PCC-14920 - 101111 */
                                    DBA_FlagAllTheBlockToError(dbiConn, eltNbr);
                                }

                                FREE(udAccessPtr);
                                FREE(dataStr);
                                FREE(errStatusTab);
                                return(retCode);
                            }
                            else
                            {
                                returnedRet = (retCode == RET_SRV_LIB_ERR_DEADLOCK)
                                    ? RET_SRV_LIB_ERR_DEADLOCK
                                    : RET_SRV_LIB_ERR_ERRORS_OCCURED;
                            }
                        }

                        operEltNbr = opIdx = 0;
                        continue;
                    }
                    else
                    {
                        mustSendSqlBuf = TRUE;
                        opIdx = 1;
                    }
                }
                else
                    continue;
            }
            else
            {
                /* If operations were found in accessPtr */
                if (operEltNbr != 0)
                {
                    /* If the SQL buffer is flushed */
                    if (sqlRec == 0)
                    {
                        /* Call C Function which will handle operation block */
                        firstRecInList = i - operEltNbr + opIdx;

                        retCode = DBA_HandleOperTabByBlock(dbiConn,
                                                           accessPtr,
                                                           firstRecInList,
                                                           maxRecInBuf,
                                                           operEltNbr,
                                                           blockOptions,
                                                           bStoreErrMsgInElt);

                        /* REF494 - 971020 - GRD. */
                        if (retCode != RET_SUCCEED)
                        {
                            returnedRet = RET_SRV_LIB_ERR_ERRORS_OCCURED;

                            if ((options & DBA_NO_ERROR) == DBA_NO_ERROR)
                            {
                                if (localTranCountFlg == TRUE)              /* REF5699 */
                                {
                                    dbiConn.endTransaction(FALSE);
                                    localTranCountFlg = FALSE;

                                    /* All record must be flagged as errors*/ /* DLA - PCC-14920 - 101111 */
                                    DBA_FlagAllTheBlockToError(dbiConn, eltNbr);
                                }

                                FREE(udAccessPtr);
                                FREE(dataStr);
                                FREE(errStatusTab);
                                if ((retCode == RET_SRV_LIB_ERR_DEADLOCK) ||        /* REF3685 */
                                    (retCode == RET_SRV_LIB_ERR_FATAL_DEADLOCK))
                                {
                                    return(retCode);
                                }
                                else
                                {
                                    return(RET_SRV_LIB_ERR_ERRORS_OCCURED);
                                }
                            }
                            /*
                             * Even if DBA_NO_ERROR is not set, we must exit if RET_SRV_LIB_ERR_FATAL_DEADLOCK occurred.
                             */
                            if (retCode == RET_SRV_LIB_ERR_FATAL_DEADLOCK)
                            {
                                if (localTranCountFlg == TRUE)              /* REF5699 */
                                {
                                    dbiConn.endTransaction(FALSE);
                                    localTranCountFlg = FALSE;

                                    /* All record must be flagged as errors*/ /* DLA - PCC-14920 - 101111 */
                                    DBA_FlagAllTheBlockToError(dbiConn, eltNbr);
                                }

                                FREE(udAccessPtr);
                                FREE(dataStr);
                                FREE(errStatusTab);
                                return(retCode);
                            }
                            else
                            {
                                returnedRet = (retCode == RET_SRV_LIB_ERR_DEADLOCK)
                                    ? RET_SRV_LIB_ERR_DEADLOCK
                                    : RET_SRV_LIB_ERR_ERRORS_OCCURED;
                            }
                        }

                        operEltNbr = opIdx = 0;
                        i--;
                        continue;
                    }
                    else
                        mustSendSqlBuf = TRUE;
                }
            }

            if (mustSendSqlBuf == FALSE)
            {
                /*
                 * If current element is different from previous or an error is returned by a trigger,
                 * search for a new procedure.
                 */
                const bool bPreviousAccessChanged = i > 0 &&                                                                   /* PMSTA-32016 - 290618 - PMO */
                    (accessPtr[i].action != accessPtr[i - 1].action ||
                     accessPtr[i].object != accessPtr[i - 1].object ||
                     accessPtr[i].role != accessPtr[i - 1].role ||
                     accessPtr[i].entity != accessPtr[i - 1].entity
                     );

                if (true == bPreviousAccessChanged || TRUE == triggerErrorFlg)
                {
                    procedure = DBA_GetStoredProcs(accessPtr[i].action,
                                                   accessPtr[i].object,
                                                   accessPtr[i].role,
                                                   accessPtr[i].entity,
                                                   accessPtr[i].data,
                                                   NullDynSt, 
                                                   true);

                    initialProcedure = NULL; /* PMSTA-34753 - DDV - 190219 */

                    /* PMSTA-25268 - 161116 - PMO */
                    if (nullptr == procedure && nullptr != dbiConn.getConnStructPtr()->msgOptions && true == dbiConn.getConnStructPtr()->msgOptions->strictErrorHandling)
                    { // For the fusion, log with problem
                        DBA_LogMesgProcedureNotFound(accessPtr[i].action,
                                                     accessPtr[i].object,
                                                     accessPtr[i].role,
                                                     accessPtr[i].entity,
                                                     accessPtr[i].data,
                                                     NullDynSt,
                                                     true,
                                                     DBA_GetActionName(accessPtr[i].action).c_str(),
                                                     DBA_GetDictEntitySqlOrObjectName(accessPtr[i].object, accessPtr[i].entity).c_str(),
                                                     DBA_GetDictEntitySqlOrObjectName(accessPtr[i].object, accessPtr[i].entity).c_str(),
                                                     "none");
                    }

                    triggerErrorFlg = FALSE; /* BUG405 */
                    dbFld = GET_FLD_NBR(accessPtr[i].entity) - GET_NOMD_NBR(accessPtr[i].entity);

                    /* REF9484 - TEB - 030919 */
                    if (dbFld <= 0)
                    {
                        dbFld = GET_FLD_NBR(accessPtr[i].entity);
                    }


                    /*
                     * If the object has changed, we must verify if there are subscriptions on it.
                     */

                    if ((procedure == NULL || ((procedure->procMask & PROCMASK_DISABLE_SUBSCRIPTION) != PROCMASK_DISABLE_SUBSCRIPTION)) &&  /* DLA - REF10507 - 041013 */  /* DLA - REF10711 - 041020 / REF10845 - 050118 - PMO */
                        (accessPtr[i].role != DBA_ROLE_UPD_UD_FIELDS) &&                                                                   /* DLA - REF9764 - 040406  pas de raison pour les UD de rechercher un souscription*/
                        (i > 0 && accessPtr[i].object != accessPtr[i - 1].object) &&                                                          /* PMSTA-32016 - 290618 - PMO */
                        (DBA_GetDictEntitySt(accessPtr[i].object) != nullptr))
                    {
                        if ((inSubscriptionSt = ALLOC_DYNST(A_Subscription)) == NULL)
                        {
                            if (localTranCountFlg == TRUE)              /* REF5699 */
                            {
                                dbiConn.endTransaction(FALSE);
                                localTranCountFlg = FALSE;

                                /* All record must be flagged as errors*/ /* DLA - PCC-14920 - 101111 */
                                DBA_FlagAllTheBlockToError(dbiConn, eltNbr);
                            }

                            MSG_RETURN(RET_MEM_ERR_ALLOC);
                        }

                        SET_DICT(inSubscriptionSt, A_Subscription_EntityDictId, (DBA_GetDictEntityStSafe(accessPtr[i].object))->entDictId);
                        SET_ENUM(inSubscriptionSt, A_Subscription_ActionEn, Subscription_Action_Insert);
                        SET_ENUM(inSubscriptionSt, A_Subscription_ModuleEn, dbiConn.getSubscriptionModuleEn());

                        /* REF8712 - 031114 - PMO */
                        (void)DBA_FreeDynStTab(outInsSubscriptionTab, outInsSubscriptionNbr, A_Subscription);
                        outInsSubscriptionTab = NULL;
                        outInsSubscriptionNbr = 0;

                        DBA_Select2(Subscription,
                                    DBA_ROLE_SEL_SUBSCRIPTIONS,
                                    A_Subscription,
                                    inSubscriptionSt,
                                    A_Subscription,
                                    &outInsSubscriptionTab,
                                    DBA_SET_CONN | DBA_NO_CLOSE,
                                    UNUSED,
                                    &outInsSubscriptionNbr,
                                    dbiConn);

                        SET_DICT(inSubscriptionSt, A_Subscription_EntityDictId, (DBA_GetDictEntityStSafe(accessPtr[i].object))->entDictId);
                        SET_ENUM(inSubscriptionSt, A_Subscription_ActionEn, Subscription_Action_Update);
                        SET_ENUM(inSubscriptionSt, A_Subscription_ModuleEn, dbiConn.getSubscriptionModuleEn());

                        /* REF8712 - 031114 - PMO */
                        (void)DBA_FreeDynStTab(outUpdSubscriptionTab, outUpdSubscriptionNbr, A_Subscription);
                        outUpdSubscriptionTab = NULL;
                        outUpdSubscriptionNbr = 0;

                        DBA_Select2(Subscription,
                                    DBA_ROLE_SEL_SUBSCRIPTIONS,
                                    A_Subscription,
                                    inSubscriptionSt,
                                    A_Subscription,
                                    &outUpdSubscriptionTab,
                                    DBA_SET_CONN | DBA_NO_CLOSE,
                                    UNUSED,
                                    &outUpdSubscriptionNbr,
                                    dbiConn);

                        SET_DICT(inSubscriptionSt, A_Subscription_EntityDictId, (DBA_GetDictEntityStSafe(accessPtr[i].object))->entDictId);
                        SET_ENUM(inSubscriptionSt, A_Subscription_ActionEn, Subscription_Action_Delete);
                        SET_ENUM(inSubscriptionSt, A_Subscription_ModuleEn, dbiConn.getSubscriptionModuleEn());

                        /* REF8712 - 031114 - PMO */
                        (void)DBA_FreeDynStTab(outDelSubscriptionTab, outDelSubscriptionNbr, A_Subscription);
                        outDelSubscriptionTab = NULL;
                        outDelSubscriptionNbr = 0;

                        DBA_Select2(Subscription,
                                    DBA_ROLE_SEL_SUBSCRIPTIONS,
                                    A_Subscription,
                                    inSubscriptionSt,
                                    A_Subscription,
                                    &outDelSubscriptionTab,
                                    DBA_SET_CONN | DBA_NO_CLOSE,
                                    UNUSED,
                                    &outDelSubscriptionNbr,
                                    dbiConn);

                        FREE_DYNST(inSubscriptionSt, A_Subscription);
                    }
                }

                if ((procedure == NULL && accessPtr[i].role != DBA_ROLE_SUBSCRIPTION) ||
                    (procedure != NULL && procedure->server == InternalProc))
                {
                    DBA_ERRMSG_INFOS_STP errMsgInfoStp = nullptr;

                    if (bStoreErrMsgInElt)
                    {
                        if (accessPtr[0].msgStructHeaderStp == nullptr)
                        {
                            accessPtr[0].msgStructHeaderStp = new DbaErrmsgHeaderClass();
                        }
                        errMsgInfoStp = &accessPtr[0].msgStructHeaderStp->getNewErrMsgInfoSt(FILEINFO);
                    }
                    else
                    {
                        errMsgInfoStp = &dbiConn.m_msgStructHeaderSt.getNewErrMsgInfoSt(FILEINFO);
                    }

                    errStatusTab[errStatusIdx] = TRUE;
                    ++errCpt;
                    returnedRet = RET_SRV_LIB_ERR_ERRORS_OCCURED; /* REF4001 - SSO - 991004 */

                    text = MSG_BuildMesg(UNUSED, UNUSED, "Procedure not found in internal "
                                         "list (action=%1, object=%2, inputSt=%3, "
                                         "outputSt=%4)",
                                         IntType, accessPtr[i].action,
                                         IntType, accessPtr[i].object,
                                         IntType, accessPtr[i].entity,
                                         IntType, NullDynSt);

                    MSG_FillMsgStruct(errMsgInfoStp,
                                      RET_DBA_ERR_PROCNOTFOUND,
                                      text,
                                      NullHandler,
                                      RET_LEV_TECH_C_ERROR,
                                      TRUE,
                                      NULL,
                                      NULL,
                                      0);

                    errMsgInfoStp->firstInList = i;
                    errMsgInfoStp->lastInList = i;
                    FREE(text);

                    /* REF494 - 971020 - GRD. */
                    if ((options & DBA_NO_ERROR) == DBA_NO_ERROR)
                    {
                        if (localTranCountFlg == TRUE)              /* REF5699 */
                        {
                            dbiConn.endTransaction(FALSE);
                            localTranCountFlg = FALSE;

                            /* All record must be flagged as errors*/ /* DLA - PCC-14920 - 101111 */
                            DBA_FlagAllTheBlockToError(dbiConn, eltNbr);
                        }

                        FREE(udAccessPtr);
                        FREE(dataStr);
                        FREE(errStatusTab);
                        DBA_FreeDynStTab(outInsSubscriptionTab, outInsSubscriptionNbr, A_Subscription);
                        DBA_FreeDynStTab(outUpdSubscriptionTab, outUpdSubscriptionNbr, A_Subscription);
                        DBA_FreeDynStTab(outDelSubscriptionTab, outDelSubscriptionNbr, A_Subscription);
                        return(RET_DBA_ERR_PROCNOTFOUND);
                    }

                    ++errStatusIdx;
                    continue;
                }

                /*
                 * Subscription.
                 */

                retCode = DBA_MultiAccessTreatElt(accessPtr[i],           /*  accessElt,             */
                                                  i,                      /*  eltIdx,                */
                                                  eltNbr,                 /*  eltNbr,                */
                                                  &procedure,             /* *procedure,             */
                                                  &initialProcedure,      /* *initialProcedure,      */
                                                  outInsSubscriptionTab,  /* *outInsSubscriptionTab, */
                                                  outUpdSubscriptionTab,  /* *outUpdSubscriptionTab, */
                                                  outDelSubscriptionTab,  /* *outDelSubscriptionTab, */
                                                  outInsSubscriptionNbr,  /*  outInsSubscriptionNbr, */
                                                  outUpdSubscriptionNbr,  /*  outUpdSubscriptionNbr, */
                                                  outDelSubscriptionNbr,  /*  outDelSubscriptionNbr, */
                                                  &subsRec,               /* *subsRec,               */
                                                  dataStr,                /* *dataStr,               */
                                                  dataStrLen,             /*  dataStrLen,            */
                                                  recBuffer,              /*  recBuffer,             */
                                                  maxRecInBuf,            /*  maxRecInBuf,           */
                                                  bFirstInBlock,          /*  bFirstInBlock,         */
                                                  &udAccessPtr,           /* *udAccessPtr,           */
                                                  &udActionsNbr,          /* *udActionsNbr,          */
                                                  &dbFld,                 /* *dbFld,                 */
                                                  &sqlRec,                /* *sqlRec,                */
                                                  &posParam,              /* *posParam,              */
                                                  dbiConn,                /*  dbiConn,               */
                                                  options,                /*  options,               */
                                                  requestHelper);         /*  requestHelper          */

                /* PMSTA-33082 - DDV - 210511 - When error occurs, force row by row and continue */
                if (retCode != RET_SUCCEED)
                {
                    errCpt++;
                    bForceRowByRow = true;
                    retCode=RET_SUCCEED;

                    requestHelper.clearMsg(); /* PMSTA-53403 - LJE - 230622 */
                }
            }
        }

        /* If the max records are stored in the buffer or the buffer must be sent to SQL Server */
        if (((sqlRec % maxRecInBuf == 0) || mustSendSqlBuf || i + 1 == eltNbr || bForceRowByRow) && ((sqlRec + errCpt) != 0))
        {
            if (mustSendSqlBuf && i + 1 != eltNbr || sendForFirstRec)
            {
                i--;
            }
            sendForFirstRec = FALSE; /* PMSTA-41309 - DDV - 200810 */

            firstRecInList = i - operEltNbr - (sqlRec - 1) - errCpt + opIdx;
            lastRecInList = i;
            errStatusIdx = errCpt = 0;

            if ((retCode = DBA_MultiAccessSendData(accessPtr,                  /*  accessPtr,               */
                                                   firstRecInList,             /*  firstRecInList,          */
                                                   lastRecInList,              /*  lastRecInList,           */
                                                   eltNbr,                     /*  eltNbr,                  */
                                                   &errCpt,                     /* *errCpt,                  */
                                                   recBuffer,                  /*  recBuffer,               */
                                                   bFirstInBlock,              /*  bFirstInBlock,           */
                                                   maxRecInBuf,                /*  maxRecInBuf,             */
                                                   &posParam,                   /* *posParam,                */
                                                   errStatusTab,               /* *errStatusTab,            */
                                                   &mustSendSqlBuf,             /* *mustSendSqlBuf,          */
                                                   &returnedRet,                /* *returnedRet,             */
                                                   &eltPos,                     /* *eltPos,                  */
                                                   &sqlRec,                     /* *sqlRec,                  */
                                                   dbiConn,                    /*  dbiConn,                 */
                                                   options,                    /*  options,                 */
                                                   &subsRec,                    /* *subsRec                  */
                                                   requestHelper,
                                                   bStoreErrMsgInElt,
                                                   bForceRowByRow)) != RET_SUCCEED)
            {
                if (localTranCountFlg == TRUE)              /* REF5699 */
                {
                    dbiConn.endTransaction(FALSE);
                    localTranCountFlg = FALSE;

                    /* All record must be flagged as errors*/ /* DLA - PCC-14920 - 101111 */
                    DBA_FlagAllTheBlockToError(dbiConn, eltNbr);
                }

                FREE(udAccessPtr);
                FREE(dataStr);
                FREE(errStatusTab);
                DBA_FreeDynStTab(outInsSubscriptionTab, outInsSubscriptionNbr, A_Subscription);
                DBA_FreeDynStTab(outUpdSubscriptionTab, outUpdSubscriptionNbr, A_Subscription);
                DBA_FreeDynStTab(outDelSubscriptionTab, outDelSubscriptionNbr, A_Subscription);

                return(retCode);
            }
            bForceRowByRow = false; /* PMSTA-33082 - DDV - 210311 - Reset it for next block */
        }
        else
        {
            ++errStatusIdx;
        }

        /* PMSTA-18110 - LJE - 140509 - Move send here to avoid huge sql command */
        /* PMSTA-18552 - 150814 - PMO
         * Send Subscription buffer.
         */
        retCode = DBA_SendSubscription(subsRec,
                                       eltPos,
                                       errStatusTab,
                                       localTranCountFlg,
                                       true,
                                       maxRecInBuf,
                                       i,
                                       eltNbr,
                                       dbiConn,
                                       firstRecInList,
                                       options,
                                       accessPtr);
        if (RET_SUCCEED != retCode)
        {
            FREE(udAccessPtr);
            FREE(dataStr);
            FREE(errStatusTab);
            DBA_FreeDynStTab(outInsSubscriptionTab, outInsSubscriptionNbr, A_Subscription);
            DBA_FreeDynStTab(outUpdSubscriptionTab, outUpdSubscriptionNbr, A_Subscription);
            DBA_FreeDynStTab(outDelSubscriptionTab, outDelSubscriptionNbr, A_Subscription);
            return(retCode);
        }
    } /* End for */

    if (true == sendSubscription)
    {
        /* PMSTA-18552 - 150814 - PMO
         * Send Subscription buffer.
         */
        retCode = DBA_SendSubscription(subsRec,
                                       eltPos,
                                       errStatusTab,
                                       localTranCountFlg,
                                       false,
                                       maxRecInBuf,
                                       i,
                                       eltNbr,
                                       dbiConn,
                                       firstRecInList,
                                       options,
                                       accessPtr);
        if (RET_SUCCEED != retCode)
        {
            FREE(udAccessPtr);
            FREE(dataStr);
            FREE(errStatusTab);
            DBA_FreeDynStTab(outInsSubscriptionTab, outInsSubscriptionNbr, A_Subscription);
            DBA_FreeDynStTab(outUpdSubscriptionTab, outUpdSubscriptionNbr, A_Subscription);
            DBA_FreeDynStTab(outDelSubscriptionTab, outDelSubscriptionNbr, A_Subscription);
            return(retCode);
        }
    }

    /* REF4714 - GRD - 000509: Beware of trancount. */
    /* If all records have been inserted */
    if ((sqlRec == 0) && (operEltNbr == 0) && ((dbiConn.isInTransaction() == true) && (returnedRet == RET_SUCCEED) ||
        (dbiConn.isInTransaction() == false))) /* REF4001 - SSO - 991004: stop if deadlock */
    {
        /* If custom entity must be handled */
        if (udActionsNbr > 0)
        {
            retCode = DBA_MultiAccessInternal(udAccessPtr,
                                      udActionsNbr,
                                      maxRecInBuf,
                                      ((options & DBA_NO_ERROR) == DBA_NO_ERROR) /* REF4555- SSO - 000419 */
                                      ? DBA_SET_CONN | DBA_NO_CLOSE | DBA_CHECK_UD_AUDIT | DBA_NO_ERROR
                                      : DBA_SET_CONN | DBA_NO_CLOSE | DBA_CHECK_UD_AUDIT,
                                      dbiConn, bStoreErrMsgInElt); /* REF4001 - SSO - 991004 UNUSED -> msgStructHeader */

            /* REF4246 - SSO - 000105: below code moved here */
            /* REF4001 - SSO - 991004 */
            if (retCode != RET_SUCCEED)
            {
                returnedRet = retCode;
            }
        }

        FREE(udAccessPtr);
        FREE(dataStr);
        FREE(errStatusTab);

        if (localTranCountFlg == TRUE)              /* REF5699 */
        {
            dbiConn.endTransaction(returnedRet == RET_SUCCEED ? TRUE : FALSE);
            localTranCountFlg = FALSE;

            if (returnedRet != RET_SUCCEED)
                /* All record must be flagged as errors*/ /* DLA - PCC-14920 - 101111 */
                DBA_FlagAllTheBlockToError(dbiConn, eltNbr);
        }

        DBA_FreeDynStTab(outInsSubscriptionTab, outInsSubscriptionNbr, A_Subscription);
        DBA_FreeDynStTab(outUpdSubscriptionTab, outUpdSubscriptionNbr, A_Subscription);
        DBA_FreeDynStTab(outDelSubscriptionTab, outDelSubscriptionNbr, A_Subscription);
        return(returnedRet);
    }

    /* REF4714 - GRD - 000509: Beware of trancount. */
    if ((sqlRec != 0) && ((dbiConn.isInTransaction() == true) && (returnedRet == RET_SUCCEED) ||
        (dbiConn.isInTransaction() == false))) /* REF4001 - SSO - 991004: stop if deadlock */
    {
        firstRecInList = (i - 1) - operEltNbr - (sqlRec - 1);
        lastRecInList = eltNbr - 1;

        if ((retCode = DBA_MultiAccessSendData(accessPtr,                   /* accessPtr,                 */
                                               firstRecInList,              /*  firstRecInList,           */
                                               lastRecInList,               /*  lastRecInList,            */
                                               eltNbr,                      /*  eltNbr,                   */
                                               &errCpt,                      /* *errCpt,                   */
                                               recBuffer,                   /*  recBuffer,                */
                                               bFirstInBlock,               /*  bFirstInBlock,            */
                                               maxRecInBuf,                 /*  maxRecInBuf,              */
                                               &posParam,                    /* *posParam,                 */
                                               errStatusTab,                /* *errStatusTab,             */
                                               &mustSendSqlBuf,              /* *mustSendSqlBuf,           */
                                               &returnedRet,                 /* *returnedRet,              */
                                               &eltPos,                      /* *eltPos,                   */
                                               &sqlRec,                      /* *sqlRec,                   */
                                               dbiConn,                     /*  dbiConn,                  */
                                               options,                     /*  options,                  */
                                               &subsRec,                     /* *subsRec                   */
                                               requestHelper,
                                               bStoreErrMsgInElt,
                                               bForceRowByRow)) != RET_SUCCEED)
        {
            if (localTranCountFlg == TRUE)              /* REF5699 */
            {
                dbiConn.endTransaction(FALSE);
                localTranCountFlg = FALSE;

                /* All record must be flagged as errors*/ /* DLA - PCC-14920 - 101111 */
                DBA_FlagAllTheBlockToError(dbiConn, eltNbr);
            }

            FREE(udAccessPtr);
            FREE(dataStr);
            FREE(errStatusTab);
            DBA_FreeDynStTab(outInsSubscriptionTab, outInsSubscriptionNbr, A_Subscription);
            DBA_FreeDynStTab(outUpdSubscriptionTab, outUpdSubscriptionNbr, A_Subscription);
            DBA_FreeDynStTab(outDelSubscriptionTab, outDelSubscriptionNbr, A_Subscription);

            return(retCode);
        }

        bForceRowByRow = false; /* PMSTA-33082 - DDV - 210311 - Reset it for next block */
    }


    /* REF4714 - GRD - 000509: Beware of trancount. */
    if ((operEltNbr > 0) && ((dbiConn.isInTransaction() == true) && (returnedRet == RET_SUCCEED) ||
        (dbiConn.isInTransaction() == false))) /* REF4001 - SSO - 991004: stop if deadlock */
    {
        firstRecInList = i - operEltNbr;

        retCode = DBA_HandleOperTabByBlock(dbiConn,
                                           accessPtr,
                                           firstRecInList,
                                           maxRecInBuf,
                                           operEltNbr,
                                           blockOptions,
                                           bStoreErrMsgInElt);

        /*
         * If an error message is sent by a trigger, function must re-send records placed
         * after which one caused the error.
         */

        if (retCode == RET_SRV_LIB_ERR_TRIGGER_MSG)
        {
            /* BEGIN BUG399 : read the ud_fields array, find corresponding ud element and re-adjust udActionsNbr */
            for (x = 0; x < udActionsNbr; x++)
                if (udAccessPtr[x].data == accessPtr[eltPos].data)
                    break;

            /* if one element found in array of ud_elements */
            {
                udAccessPtr[x].data = NULL;
                udAccessPtr[x].action = NullAction;
                udActionsNbr = x + 1;
            }
            /* END BUG399 */
        }
        else    /* REF494 - 971013 - GRD */
        {
            if (retCode != RET_SUCCEED)
            {
                if ((options & DBA_NO_ERROR) == DBA_NO_ERROR)
                {
                    if (localTranCountFlg == TRUE)              /* REF5699 */
                    {
                        dbiConn.endTransaction(FALSE);
                        localTranCountFlg = FALSE;

                        /* All record must be flagged as errors*/ /* DLA - PCC-14920 - 101111 */
                        DBA_FlagAllTheBlockToError(dbiConn, eltNbr);
                    }

                    FREE(udAccessPtr);
                    FREE(dataStr);
                    FREE(errStatusTab);
                    DBA_FreeDynStTab(outInsSubscriptionTab, outInsSubscriptionNbr, A_Subscription);
                    DBA_FreeDynStTab(outUpdSubscriptionTab, outUpdSubscriptionNbr, A_Subscription);
                    DBA_FreeDynStTab(outDelSubscriptionTab, outDelSubscriptionNbr, A_Subscription);
                    if ((retCode == RET_SRV_LIB_ERR_DEADLOCK) ||        /* REF3685 */
                        (retCode == RET_SRV_LIB_ERR_FATAL_DEADLOCK))
                    {
                        return(retCode);
                    }
                    else
                    {
                        return(RET_SRV_LIB_ERR_ERRORS_OCCURED);
                    }
                }

                /*
                 * Even if DBA_NO_ERROR is not set, we must exit if RET_SRV_LIB_ERR_FATAL_DEADLOCK occurred.
                 */

                if (retCode == RET_SRV_LIB_ERR_FATAL_DEADLOCK)
                {
                    if (localTranCountFlg == TRUE)              /* REF5699 */
                    {
                        dbiConn.endTransaction(FALSE);
                        localTranCountFlg = FALSE;

                        /* All record must be flagged as errors*/ /* DLA - PCC-14920 - 101111 */
                        DBA_FlagAllTheBlockToError(dbiConn, eltNbr);
                    }

                    FREE(udAccessPtr);
                    FREE(dataStr);
                    FREE(errStatusTab);
                    DBA_FreeDynStTab(outInsSubscriptionTab, outInsSubscriptionNbr, A_Subscription);
                    DBA_FreeDynStTab(outUpdSubscriptionTab, outUpdSubscriptionNbr, A_Subscription);
                    DBA_FreeDynStTab(outDelSubscriptionTab, outDelSubscriptionNbr, A_Subscription);
                    return(retCode);
                }
                else
                {
                    returnedRet = (retCode == RET_SRV_LIB_ERR_DEADLOCK)
                        ? RET_SRV_LIB_ERR_DEADLOCK
                        : RET_SRV_LIB_ERR_ERRORS_OCCURED;
                }
            }
        }
    }

    /* If custom entity must be handled */
    /* REF4714 - GRD - 000509: Beware of trancount. */
    if ((udActionsNbr > 0) && ((dbiConn.isInTransaction() == true) && (returnedRet == RET_SUCCEED) ||
        (dbiConn.isInTransaction() == false))) /* REF4001 - SSO - 991004: stop if deadlock */
    {
        retCode = DBA_MultiAccessInternal(udAccessPtr,
                                  udActionsNbr,
                                  maxRecInBuf,
                                  ((options & DBA_NO_ERROR) == DBA_NO_ERROR) /* REF4555- SSO - 000419 */
                                  ? DBA_SET_CONN | DBA_NO_CLOSE | DBA_CHECK_UD_AUDIT | DBA_NO_ERROR
                                  : DBA_SET_CONN | DBA_NO_CLOSE | DBA_CHECK_UD_AUDIT,
                                  dbiConn, bStoreErrMsgInElt); /* REF4001 - SSO - 991004 UNUSED -> msgStructHeader */

        /* REF4001 - SSO - 991004 */
        if (retCode != RET_SUCCEED)
        {
            returnedRet = retCode;
        }
    }

    if (localTranCountFlg == TRUE)              /* REF5699 */
    {
        dbiConn.endTransaction(returnedRet == RET_SUCCEED ? TRUE : FALSE);
        localTranCountFlg = FALSE;

        if (returnedRet != RET_SUCCEED)
            /* All record must be flagged as errors*/ /* DLA - PCC-14920 - 101111 */
            DBA_FlagAllTheBlockToError(dbiConn, eltNbr);
    }

    FREE(udAccessPtr);
    FREE(dataStr);
    FREE(errStatusTab);
    DBA_FreeDynStTab(outInsSubscriptionTab, outInsSubscriptionNbr, A_Subscription);
    DBA_FreeDynStTab(outUpdSubscriptionTab, outUpdSubscriptionNbr, A_Subscription);
    DBA_FreeDynStTab(outDelSubscriptionTab, outDelSubscriptionNbr, A_Subscription);
    return(returnedRet);
}

/************************************************************************
*   Function             : DBA_MultiAccessTreatElt()
*
*   Description          : Treat one multi access element.
*
*   Arguments            :
*
*   Return               : RET_SUCCEED if no problem was detected else an error.
*
*   Creation Date        : DDV - 190919 - PMSTA-36208
*   Last Modification    :
*
*************************************************************************/
RET_CODE DBA_MultiAccessTreatElt(DBA_ACCESS_ST&        accessElt,
                                 int                   eltIdx,
                                 const int             eltNbr,
                                 DBA_PROC_STP         *procedure,
                                 DBA_PROC_STP         *initialProcedure,
                                 DBA_DYNFLD_STP       *outInsSubscriptionTab,
                                 DBA_DYNFLD_STP       *outUpdSubscriptionTab,
                                 DBA_DYNFLD_STP       *outDelSubscriptionTab,
                                 int                   outInsSubscriptionNbr,
                                 int                   outUpdSubscriptionNbr,
                                 int                   outDelSubscriptionNbr,
                                 int                  *subsRec,
                                 char                 *dataStr,
                                 int                   dataStrLen,
                                 std::string&          recBuffer,
                                 int                   maxRecInBuf,
                                 bool&                 bFirstInBlock,
                                 DBA_ACCESS_STP       *udAccessPtr,
                                 int                  *udActionsNbr,
                                 int                  *dbFld,
                                 int                  *sqlRec,
                                 int                  *posParam,
                                 DbiConnection&        dbiConn,
                                 int                   options,
                                 RequestHelper&        requestHelper)
{
    RET_CODE            retCode = RET_SUCCEED;
    DBA_PROCPARAM_STP   procParam = NULL;
    int                 firstFld = 1;
    int                 paramIndex = 0;
    FLAG_T              found = FALSE;
    int                 fldNbr = 0;
    char *              p = NULL;
    int                 dataLength = 0;

    if (accessElt.role == DBA_ROLE_SUBSCRIPTION)
    {
        switch (accessElt.action)
        {
            case Insert:
                if (outInsSubscriptionNbr > 0)
                {
                    if ((retCode = DBA_LogSubscriptionEvents(accessElt.object,  /* DLA - 021007 */
                                                             Subscription_Action_Insert,
                                                             accessElt.entity,
                                                             accessElt.data,
                                                             NULL,
                                                             dbiConn,
                                                             outInsSubscriptionTab,
                                                             outInsSubscriptionNbr)) != RET_SUCCEED)
                    {                   /* REF5037 */
                        return(retCode);
                    }
                    (*subsRec)++;
                }
                break;

            case Update:    /* Update is also considered as a Delete AND an Insert. */
                if (outUpdSubscriptionNbr > 0)
                {
                    if ((retCode = DBA_LogSubscriptionEvents(accessElt.object, /* DLA - 021007 */
                                                             Subscription_Action_Update,
                                                             accessElt.entity,
                                                             (accessElt.newData != NULL)
                                                             ? accessElt.newData
                                                             : accessElt.data,            /* REF5644 */
                                                             accessElt.data,
                                                             dbiConn,
                                                             outUpdSubscriptionTab,
                                                             outUpdSubscriptionNbr)) != RET_SUCCEED)
                    {               /* REF5037 */
                        return(retCode);
                    }

                    (*subsRec)++;
                }

                break;

            case Delete:
                if (outDelSubscriptionNbr > 0)
                {
                    if ((retCode = DBA_LogSubscriptionEvents(accessElt.object,
                                                             Subscription_Action_Delete,
                                                             accessElt.entity,
                                                             accessElt.data,
                                                             accessElt.data,        /* Old data value. */
                                                             dbiConn,
                                                             outDelSubscriptionTab,
                                                             outDelSubscriptionNbr)) != RET_SUCCEED)
                    {               /* REF5037 */
                        return(retCode);
                    }

                    (*subsRec)++;
                }

                break;
        }
    }
    else
    {
        /* BEGIN BUG399 */
        if (accessElt.data != NULL)
        {
            if ((accessElt.object == ExecutionEnt || accessElt.object == GlExecFeeEnt) &&
                ((*procedure)->server == InternalProc || (initialProcedure != NULL && (*initialProcedure) != NULL && (*initialProcedure)->server == InternalProc))) /* DLA - REF7560 - 020822 */ /* PMSTA-34753 - DDV - 190219 */
            {
				/* PMSTA-50859 - DDV - 221208 - Initialize the block mode to avoid insertion or update by internal proc. */
				int       blockModeBck = dbiConn.getConnStructPtr()->blockMode;

				dbiConn.getConnStructPtr()->blockMode = 1;

                if (accessElt.action == Insert)
                {
                    retCode = DBA_Insert2(accessElt.object,
                                          accessElt.role,
                                          accessElt.entity,
                                          accessElt.data,
                                          DBA_SET_CONN | DBA_NO_CLOSE,
                                          dbiConn);
                }
                else if (accessElt.action == Update)
                {
                    retCode = DBA_Update2(accessElt.object,
                                          accessElt.role,
                                          accessElt.entity,
                                          accessElt.data,
                                          DBA_SET_CONN | DBA_NO_CLOSE,
                                          dbiConn);
                }

                if ((*initialProcedure) == NULL) /* PMSTA-34753 - DDV - 190219 */
                {
                    (*initialProcedure) = (*procedure);
                }

				/* PMSTA-50859 - DDV - 221208 - restore block mode */
				dbiConn.getConnStructPtr()->blockMode = blockModeBck;

                (*procedure) = DBA_GetStoredProcs(accessElt.action,
                                                  accessElt.object,
                                                  DBA_ROLE_EXECUTIONS,
                                                  accessElt.entity,
                                                  accessElt.data,
                                                  NullDynSt, 
                                                  true);

            }

            if (EV_UseMultiAccessByBatch)
            {
                requestHelper.startProcedureCallForBatch(*procedure);

                /* PMSTA-33082 - DDV - 210311 - If procedure has changed, previous block has been send. Check retCode and return it to force Row by Row in case of error */
                if (requestHelper.getLastRetCode() != RET_SUCCEED)  /* PMSTA-53403 - LJE - 230622 */
                {
                    return(requestHelper.getLastRetCode());  /* PMSTA-53403 - LJE - 230622 */
                }
            }
            else
            {
                DBI_PrintSqlReqHeader(recBuffer, eltIdx, accessElt.data, (*procedure), accessElt.object, maxRecInBuf, bFirstInBlock);   /* PMSTA-21641 - 071115 - PMO */
                DBI_PrintSqlReqBodyStart(recBuffer, (*procedure));
            }

            switch (accessElt.action)
            {
                case Insert:
                case InsUpd:
                case Update:
                    procParam = (*procedure)->procParamDefPtr;        /* REF5616 */

                            /* Subscription. */
                    if ((procedure == NULL || (*procedure) == NULL || (((*procedure)->procMask & PROCMASK_DISABLE_SUBSCRIPTION) != PROCMASK_DISABLE_SUBSCRIPTION)) &&  /* DLA - REF10507 - 041013 */  /* DLA - REF10711 - 041020 / REF10845 - 050118 - PMO */
                        (accessElt.action == Insert) &&
                        (accessElt.object != EOp) && (outInsSubscriptionNbr > 0))
                    {
                        if ((retCode = DBA_LogSubscriptionEvents(accessElt.object,               /* REF5037 */
                                                                 Subscription_Action_Insert,
                                                                 accessElt.entity,
                                                                 accessElt.data,
                                                                 NULL,
                                                                 dbiConn,
                                                                 outInsSubscriptionTab,
                                                                 outInsSubscriptionNbr)) != RET_SUCCEED)
                        {
                            return(retCode);
                        }

                        (*subsRec)++;
                    }

                    if ((accessElt.action == Update) && (accessElt.object != EOp) && (outUpdSubscriptionNbr > 0))
                    {
                        /*
                         * Get the current value for the given entity.
                         * REF4204 - GRD - 000323. (Audit purpose).
                         */

                        if ((retCode = DBA_GetOldDataForAudit(accessElt.object,
                                                              accessElt.entity,
                                                              accessElt.data,
                                                              dbiConn,
                                                              TRUE)) != RET_SUCCEED)
                        {
                            return(retCode);
                        }

                        if ((retCode = DBA_LogSubscriptionEvents(accessElt.object,
                                                                 Subscription_Action_Update,
                                                                 accessElt.entity,
                                                                 accessElt.data,
                                                                 dbiConn.getConnStructPtr()->subscriptionElem.auditRecStp, /* REF5644 */
                                                                 dbiConn,
                                                                 outUpdSubscriptionTab,
                                                                 outUpdSubscriptionNbr)) != RET_SUCCEED)
                        {
                            return(retCode);
                        }

                        FREE_DYNST(dbiConn.getConnStructPtr()->subscriptionElem.auditRecStp, GET_EDITGUIST(accessElt.object)); /* REF5644 */ /* DLA - REF9764 - 040309 */
                        (*subsRec)++;
                    }

                    
                    /* PMSTA-55976 - JPR - 20240528 - The action InsUpd was not handled. Therefore, the
                     * outbox records were not created for risk_value_element and risk_value_element_compo
                     */
                    if ((accessElt.action == InsUpd) && (accessElt.object != EOp) && (outUpdSubscriptionNbr > 0))
                    {
                        FLAG_T              auditDataFound = TRUE;

                        /*
                         * Get the current value for the given entity.
                         * REF4204 - GRD - 000323. (Audit purpose).
                         */

                        if ((retCode = DBA_GetOldDataForAudit(accessElt.object,
                            accessElt.entity,
                            accessElt.data,
                            dbiConn,
                            TRUE)) != RET_SUCCEED)
                        {
                            if (retCode == RET_GEN_INFO_NODATA)
                                auditDataFound = FALSE;
                            else
                                return(retCode);
                        }

                        if ((retCode = DBA_LogSubscriptionEvents(accessElt.object,
                            Subscription_Action_Update,
                            accessElt.entity,
                            accessElt.data,
                            (auditDataFound == TRUE) ? dbiConn.getConnStructPtr()->subscriptionElem.auditRecStp:NULL, /* REF5644 */
                            dbiConn,
                            outUpdSubscriptionTab,
                            outUpdSubscriptionNbr)) != RET_SUCCEED)
                        {
                            return(retCode);
                        }

                        FREE_DYNST(dbiConn.getConnStructPtr()->subscriptionElem.auditRecStp, GET_EDITGUIST(accessElt.object)); /* REF5644 */ /* DLA - REF9764 - 040309 */
                        (*subsRec)++;
                    }

                    /**** BUG244 ****/
                    /* Check if the object has custom fields or if it's a EOp insertion with a role AUDIT */
                    if ((options & DBA_CHECK_UD_AUDIT) != DBA_CHECK_UD_AUDIT &&
                        accessElt.role != DBA_ROLE_EXECUTIONS_SKIP_UPD_UD_FIELDS && /* REF8116 - PMO - 021023 */
                        (accessElt.role != DBA_ROLE_PTFSYNTH_ALL) && /* REF9359 - DDV - 030917 */
                        (accessElt.role != DBA_ROLE_PERF_ATTRIB_RA) && /* REF9359 - DDV - 030917 */
                        (accessElt.role != DBA_ROLE_FUSION && accessElt.object != Communication) &&       /* PMSTA-17621 - 140214 - PMO */
                        /* PMSTA-37366 - LJE - 191204 */
                        DBA_GetCustFldNbr(accessElt.object) > 1 &&
                        accessElt.role != DBA_ROLE_UPD_UD_FIELDS)
                    {
                        if ((*udAccessPtr) == NULL) /* REF7264 - PMO */
                        {
                            (*udAccessPtr) = (DBA_ACCESS_STP)CALLOC(eltNbr, sizeof(DBA_ACCESS_ST)); /* REF7264 - PMO */
                        }

                        (*udAccessPtr)[(*udActionsNbr)].action = Update;
                        (*udAccessPtr)[(*udActionsNbr)].role = DBA_ROLE_UPD_UD_FIELDS;
                        (*udAccessPtr)[(*udActionsNbr)].object = accessElt.object;
                        (*udAccessPtr)[(*udActionsNbr)].entity = accessElt.entity;
                        (*udAccessPtr)[(*udActionsNbr)].data = accessElt.data;
                        (*udActionsNbr)++;
                    }

                    /*
                     * If custom fields must be updated or if entity is ExtOp for a role audit or update ud fields
                     * and options specified ud_fields only. / REF7560 - PMO
                     */
                    if (accessElt.action == Update &&
                        accessElt.role == DBA_ROLE_UPD_UD_FIELDS)
                    {
                        firstFld = DBA_GetFirstCustFld(accessElt.object); /* PMSTA-11505 - LJE - 110615 */

                        int idxId;  /* Index of the id REF8500 - 040510 - PMO */

                        /* REF8500 - 040510 - PMO */
                        if (accessElt.object == EOp && NULL != (*procedure)->remapIdIdxPtr)
                        { /* Remapping of id */
                            idxId = *((*procedure)->remapIdIdxPtr);
                        }
                        else
                        { /* Standard case */
                            idxId = 0;
                        }
                        /*PMSTA-22128 - SHR - 161401*/
                        if (accessElt.object == EOp && IS_NULLFLD(accessElt.data, idxId) == TRUE && NULL == (*procedure)->remapIdIdxPtr)
                        {
                            SET_ID(accessElt.data, idxId, OPE_GetOpIdFromExtOp(accessElt.data))
                                SET_ID(accessElt.data, firstFld, OPE_GetOpIdFromExtOp(accessElt.data));
                        }
                        else
                        {
                            SET_ID(accessElt.data, firstFld, GET_ID(accessElt.data, idxId));
                        }

                        (*dbFld) = firstFld + DBA_GetCustFldNbr(accessElt.object);
                    }
                    else
                    {
                        DBA_SetMagicDate(accessElt.data, accessElt.entity, accessElt.object);

                        /* If object isn't a main entity (without auto-generation of the primary key)
                           or if action is Update, the first field to provide is the field 0 */
                        if (((options & DBA_INS_ID) == DBA_INS_ID || DBA_GetPkRuleEn(accessElt.object) == PkRule_NoIdentity || DBA_GetPkRuleEn(accessElt.object) == PkRule_ExternalPk) || /* PMSTA-18593 - LJE - 151027 */ /* PMSTA-42847 - sriharshabv - 210107*/
                            (accessElt.action == Update) ||
                            ((*procedure)->procParamDefPtr != NULL && 
                             (*procedure)->procParamDefPtr->procParamTypeEn >= ProcParamType_Output && 
                             (*(*procedure)->procParamDefPtr->fldNbrPtr == 0 || (*procedure)->procParamDefPtr->fldNbrPtr == (*procedure)->remapIdIdxPtr))) /* DLA - PMSTA08801 - 100226 */
                        {
                            firstFld = 0;
                        }

                        (*dbFld) = DBA_GetFirstCustFld(accessElt.object); /* PMSTA-18593 - LJE - 151022 */
                    }

                    if (EV_UseMultiAccessByBatch) 
                    {
                        requestHelper.setNewRecordForBatch(accessElt.data);
                    }
                    else
                    {
                        /* Convert each field from inital type to string */
                        for (fldNbr = firstFld; fldNbr < (*dbFld); fldNbr++)
                        {
                            /*
                             * Sometimes, updates does not need to use the complete 'All' structure,
                             * only few fields are required. This is why the 'Multi-Access' takes care
                             * of using such stored procedures in order to behave like the DBA_Update.
                             * GRD - 06/02/01 - REF5616.
                             */

                            if ((accessElt.action == Update) && (procParam != UNUSED) && DBA_IsInOutStoredProc((*procedure)) == false) /* DLA - PMSTA-24434 - 161025 */
                            {
                                paramIndex = 0;
                                found = FALSE;

                                /* Set all necessary arguments */
                                while (procParam[paramIndex].paramName != NULL &&
                                       procParam[paramIndex].paramName[0] != END_OF_STRING &&
                                       found == FALSE)
                                {
                                    if (*(procParam[paramIndex].fldNbrPtr) == fldNbr)
                                    {
                                        found = TRUE;
                                    }

                                    paramIndex++;
                                }

                                if (found == FALSE && fldNbr == 0 && procParam[0].fldNbrPtr == (*procedure)->remapIdIdxPtr)
                                {
                                    found = TRUE;
                                }

                                if (found == FALSE)
                                {
                                    continue;
                                }
                            }

                            if (IS_DBFLD(accessElt.entity, fldNbr) != TRUE ||
                                DictAttribClass::isPhysicalCalcEn(DBA_GetDictAttribCalcEn(accessElt.object, fldNbr)) == FALSE) /* PMSTA-18593 - LJE - 150625 */
                            {
                                continue;
                            }

                            *dataStr = END_OF_STRING;

                            /* REF8500 - 040510 - PMO */
                            if (accessElt.object == EOp &&
                                NULL != (*procedure)->remapIdIdxPtr &&
                                0 == fldNbr &&
                                IS_NULLFLD(accessElt.data, *((*procedure)->remapIdIdxPtr)) == FALSE   /* REF10243 - 040713 - PMO */
                                )
                            { /* Remapping of id */
                                /* Beware of arithmetic overflows REF2220. */
                                retCode = DBI_FldToDbDataStr(dataStr,
                                                             dataStrLen,
                                                             accessElt.data,
                                                             *((*procedure)->remapIdIdxPtr),
                                                             GET_FLD_TYPE(accessElt.entity, *((*procedure)->remapIdIdxPtr)),
                                                             &dataLength, false);
                            }
                            else
                            { /* Standard case */

                                /* Beware of arithmetic overflows REF2220. */
                                retCode = DBI_FldToDbDataStr(dataStr,
                                                             dataStrLen,
                                                             accessElt.data,
                                                             fldNbr,  /* REF8844 - LJE - 030324 */
                                                             GET_FLD_TYPE(accessElt.entity, fldNbr),
                                                             &dataLength, false);
                            }

                            if (retCode == RET_SRV_LIB_ERR_DB_OVERFLOW)
                            {
                                if (DBA_MultiAccessLogOverFlow(accessElt, fldNbr, (*procedure), options) != RET_SUCCEED)
                                {
                                    return(RET_SRV_LIB_ERR_ERRORS_OCCURED);
                                }

								/* PMSTA-49982 - JBC - 220825 */
								FLAG_T applRoundOverflowOnInsUpdBatch = FALSE;
								GEN_GetApplInfo(ApplRoundOverflowOnInsUpdBatch, &applRoundOverflowOnInsUpdBatch);

								if (requestHelper.getTransactionMode() != RequestHelper::TransactionMode::MostAsPossible
									&& applRoundOverflowOnInsUpdBatch == FALSE)
                                {
                                    return(RET_SRV_LIB_ERR_DB_OVERFLOW);
                                }
                            }

                            /* BEGIN DVP263 */
                            /*
                             * Beware of numbers with no decimals!!!!!!
                             * (Do not truncate zeros for them!!!!!)
                             * GRD - 28/03/2001 - REF5877.
                             */

                            if (GET_CTYPE(GET_FLD_TYPE(accessElt.entity, fldNbr)) == DoubleCType)
                            {
                                if (strchr(dataStr, '.') != NULL)   /* REF5877. */
                                {
                                    p = dataStr + dataLength;

                                    while (p > dataStr && *(p - 1) == '0')
                                    {
                                        *(p - 1) = END_OF_STRING;
                                        p--;
                                    }
                                }
                            }
                            else
                            {
                                /* Test to check if the string contains double-quoted characters */
                                if (accessElt.object == ScriptDef &&
                                    (GET_CTYPE(GET_FLD_TYPE(accessElt.entity, fldNbr)) == CharPtrCType
                                     || GET_CTYPE(GET_FLD_TYPE(accessElt.entity, fldNbr)) == TextPtrCType))    /* REF4204 - SSO - 000211 */
                                {
                                    dataStr[dataLength - 1] = '\'';

                                    if (strchr(dataStr + 1, '"') != NULL)
                                        dataStr[0] = '\'';
                                    else
                                        dataStr[dataLength - 1] = '"';
                                }
                            }

                            /* END  DVP263 */
                            /* DLA - PMSTA08801 - 100303 */
                            std::string dataString(dataStr);
                            DBI_PrintSqlReqParam(recBuffer, dataString, eltIdx, (*procedure), fldNbr, GET_FLD_TYPE(accessElt.entity, fldNbr), posParam, accessElt.data, requestHelper);

                            recBuffer += ",";
                        }

                        //currLen--;
                        recBuffer.erase(recBuffer.end() - 1);
                    }
                    break;

                case Delete:
                case Notif:
                    procParam = (*procedure)->procParamDefPtr;
                    paramIndex = 0;

                    /* Subscription. */
                    if ((accessElt.action == Delete) && (accessElt.object != EOp) &&
                        (outDelSubscriptionNbr > 0) && (procedure == NULL || (*procedure) == NULL || (((*procedure)->procMask & PROCMASK_DISABLE_SUBSCRIPTION) != PROCMASK_DISABLE_SUBSCRIPTION)))
                    {
                        /*
                         * Get the current value for the given entity.
                         * REF4204 - GRD - 000323. (Audit purpose).
                         */

                        if ((retCode = DBA_GetOldDataForAudit(accessElt.object,
                                                              accessElt.entity,
                                                              accessElt.data,
                                                              dbiConn,
                                                              TRUE)) != RET_SUCCEED)
                        {                                                               /* REF5037 */
                            return(retCode);
                        }

                        if ((retCode = DBA_LogSubscriptionEvents(accessElt.object,
                                                                 Subscription_Action_Delete,
                                                                 accessElt.entity,
                                                                 dbiConn.getConnStructPtr()->subscriptionElem.auditRecStp, /* REF5644 */
                                                                 dbiConn.getConnStructPtr()->subscriptionElem.auditRecStp, /* REF5644 */
                                                                 dbiConn,
                                                                 outDelSubscriptionTab,
                                                                 outDelSubscriptionNbr)) != RET_SUCCEED)
                        {                                               /* REF5037 */
                            return(retCode);
                        }

                        FREE_DYNST(dbiConn.getConnStructPtr()->subscriptionElem.auditRecStp, GET_EDITGUIST(accessElt.object)); /* REF5644 */ /* DLA - REF9764 - 040305 */
                        (*subsRec)++;
                    }

                    if (EV_UseMultiAccessByBatch) /* NUODB-TODO */
                    {
                        requestHelper.setNewRecordForBatch(accessElt.data);
                    }
                    else
                    {
                        do
                        {
                            *dataStr = END_OF_STRING;

                            /* Beware of arithmetic overflows REF2220. */
                            retCode = DBI_FldToDbDataStr(dataStr, dataStrLen, accessElt.data, *(procParam[paramIndex].fldNbrPtr),  /* REF8844 - LJE - 030324 */
                                                         GET_FLD_TYPE(accessElt.entity, *(procParam[paramIndex].fldNbrPtr)),
                                                         &dataLength, false);

                            if (retCode == RET_SRV_LIB_ERR_DB_OVERFLOW)
                            {
                                if (DBA_MultiAccessLogOverFlow(accessElt, *(procParam[paramIndex].fldNbrPtr), (*procedure), options) != RET_SUCCEED)
                                {
                                    return(RET_SRV_LIB_ERR_ERRORS_OCCURED);
                                }
                            }

                            /* BEGIN DVP263 */
                            /*
                             * Beware of numbers with no decimals!!!!!!
                             * (Do not truncate zeros for them!!!!!)
                             * GRD - 28/03/2001 - REF5877.
                             */

                            if (GET_CTYPE(GET_FLD_TYPE(accessElt.entity, *(procParam[paramIndex].fldNbrPtr))) == DoubleCType)
                            {
                                if (strchr(dataStr, '.') != NULL)   /* REF5877. */
                                {
                                    p = dataStr + dataLength;

                                    while (p > dataStr && *(p - 1) == '0')
                                    {
                                        *(p - 1) = END_OF_STRING;
                                        p--;
                                    }
                                }
                            }

                            recBuffer += DBI_PrintSqlReqParamEqualValue(procParam[paramIndex].paramName, dataStr);
                            ++paramIndex;

                            if (procParam[paramIndex].paramName[0] != END_OF_STRING)
                                recBuffer += ",";
                        } while (procParam[paramIndex].paramName != NULL &&
                                 procParam[paramIndex].paramName[0] != END_OF_STRING);
                    }
                    break;
            }

            if (EV_UseMultiAccessByBatch == false) /* NUODB-TODO */
            {
                recBuffer += " ";
                DBI_PrintSqlReqBodyEnd(recBuffer);
            }
            (*sqlRec)++;
        }
    }

    return(RET_SUCCEED);
}

/************************************************************************
*   Function             : DBA_MultiAccessLogOverFlow()
*
*   Description          : Display message reporting overflow error.
*
*   Arguments            :
*
*   Return               : RET_SUCCEED if no problem was detected else an error.
*
*   Creation Date        : DDV - 190917 - PMSTA-36208
*   Last Modification    :
*
*************************************************************************/
STATIC RET_CODE DBA_MultiAccessLogOverFlow(DBA_ACCESS_ST        accessElt,
    int                  fldIdx,
    DBA_PROC_STP         procedure,
    int                  options)
{
    char            *buffer = (char *)CALLOC(384, sizeof(char));   /* REF7264 - PMO */
    char            operationCode[64];  /* REF5629 - SSO - 010207 CODE_T -> char[64] */
    NAME_T      attrName; /* DLA - PMSTA09887 - 101116 */

    /* REF8844 - LJE - 030415 */
    if (accessElt.object == Pos)
    {

        strcpy(operationCode, GET_CODE(accessElt.data, A_Pos_OpenOpCd));

    }
    else if (accessElt.object == EPos)
    {

        strcpy(operationCode, GET_CODE(accessElt.data, ExtPos_OpenOpCd));

    }
    else if (accessElt.object == EOp)
    {

        /* REF5629 - SSO - 010207 : if coming fro productivity, codes can be null! */
        /* we log with ids because in transaction we could locks with a dba_get... */

        if (IS_NULLFLD(accessElt.data, ExtOp_Cd) == FALSE)
        {
            strcpy(operationCode, GET_CODE(accessElt.data, ExtOp_Cd));
        }
        else
        {
            sprintf(operationCode, "NULL (PtfId %" szFormatId" InstrId %" szFormatId")", /* DLA - PMSTA08801 - 100209 */
                GET_ID(accessElt.data, ExtOp_PtfId),
                GET_ID(accessElt.data, ExtOp_InstrId));
        }

    }
    else if (accessElt.object == BalPos)
    {

        strcpy(operationCode, GET_CODE(accessElt.data, A_BalPos_OpenOpCd));

    }
    else if (accessElt.object == Op)
    {

        strcpy(operationCode, GET_CODE(accessElt.data, A_Op_Cd));

    }
    else
    {
        strcpy(operationCode, "Unknown");
    }

    attrName[0] = 0x00;
    DICT_GetAttribInfo(accessElt.object, fldIdx, 0, NULL, A_DictAttr_SqlName, &attrName);


    /* PMSTA-18365 - 100714 - PMO */
    try
    {
        /* Prepare the error message */
        std::string sqlCmd = "Error while executing SQL (Data overflow detected for attribut ";

        { /* Add the status value */
            char szName[256];
            (void)snprintf(szName, sizeof(szName) / sizeof(szName[0]), "%s", attrName);
            sqlCmd += szName;
            sqlCmd += ") ";

            /* Append the SQL command into sqlCmd */
            DBA_CreateSQLCall(sqlCmd, szName, sizeof(szName), &accessElt, procedure);
        }

        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, sqlCmd.c_str());
    }
    catch (std::exception errorMem)
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "Creating SQL parameter error message");
        return RET_SRV_LIB_ERR_COMMAND_ABORTED;
    }

    sprintf(buffer,
        "Data overflow detected while %s %s, field %s with operation code %s",
        (accessElt.action == Update) ? "Updating" :
        (accessElt.action == Insert) ? "Inserting" :
        (accessElt.action == InsUpd) ? "Inserting/Updating" :
        (accessElt.action == Delete) ? "Deleting" :
        "Action unknown",
        DBA_GetDictEntitySqlName(accessElt.object),
        attrName,
        operationCode);

    MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, buffer);
    FREE(buffer);

    /* REF3736 - SSO - 990608: part. case for ptf synth */
    if ((accessElt.object == PtfSynth) && ((options & DBA_NO_ERROR) == DBA_NO_ERROR))
    {
        return(RET_SRV_LIB_ERR_ERRORS_OCCURED);
    }

    return(RET_SUCCEED);
}

/************************************************************************
*   Function             : DBA_MultiAccessSendData()
*
*   Description          : Send multi access data to database.
*
*   Arguments            :
*
*   Return               : RET_SUCCEED if no problem was detected else an error.
*
*   Creation Date        : DDV - 190923 - PMSTA-36208
*   Last Modification    :
*
*************************************************************************/
STATIC RET_CODE DBA_MultiAccessSendData(DBA_ACCESS_STP        accessPtr,
                                        int                   firstRecInList,
                                        int                   lastRecInList,
                                        const int             eltNbr,
                                        int                  *errCpt,
                                        std::string&          recBuffer,
                                        bool&                 bFirstInBlock,
                                        int                   maxRecInBuf,
                                        int                  *posParam,
                                        int                  *errStatusTab,
                                        FLAG_T               *mustSendSqlBuf,
                                        RET_CODE             *returnedRet,
                                        int                  *eltPos,
                                        int                  *sqlRec,
                                        DbiConnection&        dbiConn,
                                        int                   options,
                                        int                  *subsRec,
                                        RequestHelper        &requestHelper,
                                        bool                  bStoreErrMsgInElt,
                                        bool                  bForceRowByRow)
{
    RET_CODE            retCode = RET_SUCCEED;
    bool                startInTransaction = dbiConn.isInTransaction();

    (*errCpt) = 0;

    if (EV_UseMultiAccessByBatch)
    {
        retCode = requestHelper.executeBatch();
    }
    else if (bForceRowByRow == false)
    {
        int fatalError = FALSE;

        DBI_PrintSqlReqFooter(recBuffer, bFirstInBlock);

        if (dbiConn.sendCommand(recBuffer) != RET_SUCCEED)
        {
            dbiConn.filterMsgInfos(&retCode);

            if (FALSE == dbiConn.cancelDbRequest(COMMAND_LEVEL, CANCEL_ALL))
            {
                if (retCode == RET_SRV_LIB_ERR_DEADLOCK)
                {
                    return(RET_SRV_LIB_ERR_FATAL_DEADLOCK);
                }
            }

            if (retCode == RET_SRV_LIB_ERR_DEADLOCK)
            {
                return(retCode);
            }
            return(RET_DBA_ERR_DBPROBLEM);
        }
        (*posParam) = 0;

        /* Check if the insert has returned a block of datas (id and timestamp field) */


        /*** Temporary allow a resultType equal to CS_CMD_SUCCEED / REF11780 - 100406 - PMO */
        switch (dbiConn.m_lastResultType)
        {
            case DBI_STATUS_RESULT:
            case DBI_CMD_SUCCEED:
            case DBI_ROW_RESULT:
            case DBI_PARAM_RESULT: /* DLA - PMSTA08801 - 100301 */
            case DBI_ORA_FAILCMD:
                fatalError = FALSE;
                break;

            default:
                fatalError = TRUE;
                break;
        }

        if (TRUE == fatalError)  /* REF11780 - 100406 - PMO */
        {
            if ((retCode = DBI_ProcessAllAccessResults(dbiConn,
                                                       firstRecInList,
                                                       maxRecInBuf,
                                                       options,
                                                       accessPtr,
                                                       eltPos,
                                                       NULL,                /* REF7264 - PMO */
                                                       Get,                 /* REF7264 - PMO */
                                                       ApplParam,           /* REF7264 - PMO */
                                                       errStatusTab,
                                                       eltNbr, /* REF11780 - 100406 - PMO */
                                                       UNUSED)) != RET_SUCCEED)   /* DLA - PMSTA08801 - 100325 */
            {       /* REF494 - 971013 - GRD */
                if ((options & DBA_NO_ERROR) == DBA_NO_ERROR)
                {
                    if ((retCode == RET_SRV_LIB_ERR_DEADLOCK) ||    /* REF3685 */
                        (retCode == RET_SRV_LIB_ERR_FATAL_DEADLOCK))
                    {
                        return(retCode);
                    }
                    else
                    {
                        return(RET_SRV_LIB_ERR_ERRORS_OCCURED);
                    }
                }

                /*
                 * Even if DBA_NO_ERROR is not set, we must exit if RET_SRV_LIB_ERR_FATAL_DEADLOCK occurred.
                 */

                if (retCode == RET_SRV_LIB_ERR_FATAL_DEADLOCK)
                {
                    return(retCode);
                }
                else
                {
                    (*returnedRet) = (retCode == RET_SRV_LIB_ERR_DEADLOCK)
                        ? RET_SRV_LIB_ERR_DEADLOCK
                        : RET_SRV_LIB_ERR_ERRORS_OCCURED;
                }
            }

            memset(errStatusTab, 0, sizeof(int)*eltNbr);
            (*sqlRec) = 0;
            (*mustSendSqlBuf) = FALSE;
            recBuffer.clear();
            return(RET_GEN_INFO_RESTART);
        }

        retCode = DBI_ProcessAllAccessResults(dbiConn,
                                              firstRecInList,
                                              maxRecInBuf,
                                              options,
                                              accessPtr,
                                              eltPos,
                                              NULL,         /* REF7264 - PMO */
                                              Get,          /* REF7264 - PMO */
                                              ApplParam,    /* REF7264 - PMO */
                                              errStatusTab,
                                              eltNbr,      /* REF11780 - 100406 - PMO */
                                              UNUSED);     /* DLA - PMSTA08801 - 100325 */

                                          /*
                                           * If an error message is sent by a trigger, function must re-send records placed after
                                           * which one caused the error.
                                           */
    }

    /* REF494 - 971020 - GRD */
    if (bForceRowByRow ||
        (retCode != RET_SUCCEED &&
         /* PMSTA-20887 - LJE - 150915 */
         (retCode != RET_DBA_INFO_EXTERNAL_SEQ || dbiConn.getConnStructPtr()->subscriptionElem.accessNbr != 0 || dbiConn.m_lastResultType == DBI_ORA_FAILCMD)
        ))
    {
        if ((options & DBA_NO_ERROR) == DBA_NO_ERROR)
        {
            if ((retCode == RET_SRV_LIB_ERR_DEADLOCK) ||    /* REF3685 */
                (retCode == RET_SRV_LIB_ERR_FATAL_DEADLOCK))
            {
                return(retCode);
            }
            else
            {
                return(RET_SRV_LIB_ERR_ERRORS_OCCURED);
            }
        }
        /*
            * Even if DBA_NO_ERROR is not set, we must exit if RET_SRV_LIB_ERR_FATAL_DEADLOCK occurred.
            */

        if (retCode == RET_SRV_LIB_ERR_FATAL_DEADLOCK)
        {
            return(retCode);
        }
        else
        {
            (*returnedRet) = (retCode == RET_SRV_LIB_ERR_DEADLOCK)
                ? RET_SRV_LIB_ERR_DEADLOCK
                : RET_SRV_LIB_ERR_ERRORS_OCCURED;


            /*
                * In the case the interface uses the subscription but tolerates errors, events
                * could be inserted into table 'event' or 'audit' even though NO RECORD has been treated in DB.
                * We MUST open a transaction before managing blocks.
                * GRD - 19/02/01 - REF5699
                */
                /* DLA - REF9468 - 030915
                * This rule seem not correct because we try another time to insert Eop -> DUPLICATE KEY errors generated
                */
            if (startInTransaction && (SYS_IsBatchMode() == TRUE) &&
                accessPtr[0].object != Op && accessPtr[0].object != EPos && accessPtr[0].object != EOp)/* DLA-PMO - REF5695 - 011012 */ /* DLA - PMSTA10877 - 110112 */
            {
                if (dbiConn.isInTransaction())
                {
                    dbiConn.endTransaction(FALSE);
                }
				/* (*localTranCountFlg) = FALSE; PMSTA-46714 - 211029 - Transaction is reopen below, don't modify localTranCountFlg */
                *(subsRec) = 0; /* DLA - REF7202 - 020502 */

                if (&dbiConn.getConnStructPtr()->subscriptionElem != NULL)
                {
                    DBA_FreeSubscriptionBlock(dbiConn);
                }

                dbiConn.m_lastResultRetCode = RET_SUCCEED;
                dbiConn.clearMsg();
                dbiConn.getConnStructPtr()->blockMode = FALSE; /* DLA - REF7202 - 020502 */

                
                DBA_ERRMSG_HEADER_ST  msgStructHeaderSt;

                for (int siWk1 = firstRecInList; siWk1 <= lastRecInList; siWk1++)
                {
                    switch (accessPtr[siWk1].action)
                    {
                        case Insert:
                            retCode = DBA_Insert2(accessPtr[siWk1].object,
                                                    accessPtr[siWk1].role,
                                                    accessPtr[siWk1].entity,
                                                    accessPtr[siWk1].data,
                                                    DBA_SET_CONN | DBA_NO_CLOSE,
                                                    dbiConn);

                            break;

                        case InsUpd:
                            retCode = DBA_InsUpd(accessPtr[siWk1].object,
                                                    accessPtr[siWk1].role,
                                                    accessPtr[siWk1].entity,
                                                    accessPtr[siWk1].data,
                                                    DBA_SET_CONN | DBA_NO_CLOSE,
                                                    dbiConn);
                            break;

                        case Update:
                            retCode = DBA_Update2(accessPtr[siWk1].object,
                                                    accessPtr[siWk1].role,
                                                    accessPtr[siWk1].entity,
                                                    accessPtr[siWk1].data,
                                                    DBA_SET_CONN | DBA_NO_CLOSE,
                                                    dbiConn);
                            break;

                        case Delete:
                            retCode = DBA_Delete2(accessPtr[siWk1].object,
                                                  accessPtr[siWk1].role,
                                                  accessPtr[siWk1].entity,
                                                  accessPtr[siWk1].data,
                                                  DBA_SET_CONN | DBA_NO_CLOSE,
                                                  dbiConn);
                            break;
                    }

                    if (retCode != RET_SUCCEED)
                    {
                        for (auto msgErrIt = dbiConn.m_msgStructHeaderSt.msgStructTab.begin(); msgErrIt != dbiConn.m_msgStructHeaderSt.msgStructTab.end(); ++msgErrIt)
                        {
                            DbaErrmsgInfosClass &dbaErrMsgInfo = msgStructHeaderSt.getNewErrMsgInfoSt(FILEINFO);
                            dbaErrMsgInfo = dbiConn.m_msgStructHeaderSt.getMostGravityErrMsgInfoSt(FILEINFO);
                            dbaErrMsgInfo.lastInList = siWk1;
                            dbaErrMsgInfo.firstInList = siWk1;
                        }
                        if (bStoreErrMsgInElt)
                        {
                            if (dbiConn.m_msgStructHeaderSt.msgStructTab.size() > 0)
                            {
                                if (accessPtr[siWk1].msgStructHeaderStp == nullptr)
                                {
                                    accessPtr[siWk1].msgStructHeaderStp = new DbaErrmsgHeaderClass(dbiConn.m_msgStructHeaderSt);
                                }
                                else
                                {
                                    for (auto msgStructIt = dbiConn.m_msgStructHeaderSt.msgStructTab.begin(); msgStructIt != dbiConn.m_msgStructHeaderSt.msgStructTab.end(); ++msgStructIt)
                                    {
                                        accessPtr[siWk1].msgStructHeaderStp->msgStructTab.push_back((*msgStructIt));
                                    }
                                }
                                dbiConn.m_msgStructHeaderSt.msgStructTab.clear();
                            }
                        }
                    }

                    /* DLA-PMO - REF5695 - 011012
                        * For each record, we are testing the retCode
                        */
                    if (dbiConn.getDescription().getModel() == DBA_RDBMS_ENUM::Sybase)
                    {
                        int bTrouve = 0;
                        for (size_t no_error = 0; no_error < dbiConn.m_msgStructHeaderSt.msgStructTab.size(); no_error++)
                        {
                            if (dbiConn.m_msgStructHeaderSt.msgStructTab[no_error].firstInList <= siWk1 &&
                                dbiConn.m_msgStructHeaderSt.msgStructTab[no_error].lastInList >= siWk1
                                )
                            {
                                bTrouve = 1;
                                if (dbiConn.m_msgStructHeaderSt.msgStructTab[no_error].result == retCode
                                    || retCode == RET_SUCCEED) /*DLA - REF7202 - 020502 */
                                {
                                    /* DLA - REF11051 - 050502  same error or no error, it's normal*/
                                    dbiConn.m_msgStructHeaderSt.msgStructTab[no_error].firstInList = siWk1;
                                    dbiConn.m_msgStructHeaderSt.msgStructTab[no_error].lastInList = siWk1;
                                    break;
                                }
                                else
                                {
                                    /* Error but not the same, print the diff in the log file*/
                                    MSG_SendMsgInfos(dbiConn.m_msgStructHeaderSt.msgStructTab[no_error].firstInList,
                                        &dbiConn.m_msgStructHeaderSt.msgStructTab[no_error]);

                                    MSG_LogMesg(RET_GEN_ERR_PERSONAL,
                                        1,
                                        FILEINFO,
                                        "A new error occurred while a second tentative to ins/upd/delete the record. There is maybe a concurrent access to db (above, old and new messages");
                                    break;
                                }
                            }
                        }

                        if (bTrouve == 0 && retCode != RET_SUCCEED && retCode != RET_SRV_LIB_ERR_TRIGGER_MSG) /* DLA - REF11051 - 050502 */
                        {
                            dbiConn.sendAllMsg();

                            MSG_LogMesg(RET_GEN_ERR_PERSONAL,
                                1,
                                FILEINFO,
                                "An error occurred while a second tentative to ins/upd/delete the record. First time before the rollback it was accepted, there is maybe a concurrent access to db ");
                        }
                    }
                }
                dbiConn.m_msgStructHeaderSt = msgStructHeaderSt;

                dbiConn.getConnStructPtr()->blockMode = TRUE; /* Was Unactivated upper to do a subscription if needed DLA - REF7202 - 020502 */
                dbiConn.beginTransaction(); /* PMSTA-33082 - DDV - 210315 - Start a new transaction for next block */
            }

            retCode = (*returnedRet);
        }
    }

    memset(errStatusTab, 0, sizeof(int)*eltNbr);
    (*sqlRec) = (*posParam) = 0;
    (*mustSendSqlBuf) = FALSE;
    recBuffer.clear();

    return(retCode);
}

/************************************************************************
*   Function             : DBA_FlagAllTheBlockToError()
*
*   Description          : In case of error in a block when a transaction is open we must create an entry for each record in errorTab
*
*   Arguments            : msgStructHeader : The error structure header
*                          eltNbr          : The nuber of elements in the block
*
*   Return               : None
*
*   Creation Date        : DLA - PCC-19420 - 101111
*   Last Modification    :
*
*************************************************************************/
void DBA_FlagAllTheBlockToError(DbiConnection&  dbiConn, int eltNbr)
{
    auto msgStructHeader = &dbiConn.m_msgStructHeaderSt;

    for (int i = 0; i < eltNbr; i++)
    {
        DBA_ERRMSG_INFOS_STP msgStructPtr = &msgStructHeader->getNewErrMsgInfoSt(FILEINFO);

        MSG_FillMsgStruct(msgStructPtr,
                          RET_SRV_LIB_ERR_TRIGGER_MSG,
                          NULL,
                          ServerHandler,
                          RET_LEV_TECH_C_ERROR,
                          TRUE,
                          NULL,
                          NULL,
                          0);

        msgStructPtr->firstInList = i;
        msgStructPtr->lastInList  = i;
    }
}

/************************************************************************
*   Function             : DBA_FreeOperTabForBlockHandling()
*
*   Description          : Free allocated arrays of data for block mode handling (Dynamic SQL) on operations
*
*   Arguments            : connectNo       : the connection number used to dialog with Sql Server
*                          accessPtr       : the operation array
*                          firstRec        : the number of first operation in the array
*                          opNbr           : the number of operations in the array
*
*   Return               : RET_SUCCEED     : if no problem was detected
*
*   Creation Date        : 04.12.96 - PEC - Ref.: DVP291
*   Last Modification    : 27.03.00 - GRD - Ref.: REF4204. Subscription.
*                          01.02.01 - GRD - Ref.: REF5644.
*************************************************************************/
RET_CODE DBA_FreeOperTabForBlockHandling(DbiConnection& dbiConn,
                                         DBA_ACCESS_STP accessPtr,
                                         int            firstRec,
                                         int            opNbr,
                                         int ret)
{
    int                  i = 0, j = 0, k = 0;
    DBA_ACTION_STEP_STP  dataPtr;
	unsigned char		 uCharBit;
	DBA_CONNECT_INFO_STP connInfoPtr;

	connInfoPtr = dbiConn.getConnStructPtr();
	dataPtr     = connInfoPtr->blockModeExt.recTab;

    /* Free all allocated structures */
    for (i=0 ; i<opNbr ; i++)
    {
        /* For each step generated by operation */
        for (j=0 ; j<=dataPtr[i].stepNbr ; j++)
        {
            if (dataPtr[i].stepData != NULL)
            {
                if (dataPtr[i].stepData[j].insOp.data != NULL &&
                    dataPtr[i].stepData[j].insOp.data != accessPtr[i+firstRec].data)
                {
                    FREE_DYNST(dataPtr[i].stepData[j].insOp.data, dataPtr[i].stepData[j].insOp.entity);
                }

                if (dataPtr[i].stepData[j].delOp.data != NULL &&
                    dataPtr[i].stepData[j].delOp.data != accessPtr[i+firstRec].data)
                {
                    FREE_DYNST(dataPtr[i].stepData[j].delOp.data, dataPtr[i].stepData[j].delOp.entity);
                }

                /*
                 * Subscription.                            REF4204.
                 */

                if (dataPtr[i].stepData[j].auditOp.data != NULL &&
                    dataPtr[i].stepData[j].auditOp.data != accessPtr[i+firstRec].data)
                {
                    FREE_DYNST(dataPtr[i].stepData[j].auditOp.data,    dataPtr[i].stepData[j].auditOp.entity);
                    FREE_DYNST(dataPtr[i].stepData[j].auditOp.newData, dataPtr[i].stepData[j].auditOp.entity); /* REF5644 */
                }

                for (k=0 ; k<dataPtr[i].stepData[j].extDataNbr ; k++)
                {
                    if (dataPtr[i].stepData[j].extDataTab[k].data != NULL &&
                        dataPtr[i].stepData[j].extDataTab[k].data != accessPtr[i+firstRec].data)
                    {
                        FREE_DYNST(dataPtr[i].stepData[j].extDataTab[k].data,
                                   dataPtr[i].stepData[j].extDataTab[k].entity);
                    }
                }

                FREE(dataPtr[i].stepData[j].extDataTab);
            }
        }

        if (dataPtr[i].stepData != NULL)
        {
            FREE(dataPtr[i].stepData);
        }
    }

    /* REF6915 SME */

	if ((ret != RET_SUCCEED) && (dbiConn.m_transactCpt > 0))
    {
        k = firstRec + opNbr;
        for (i = firstRec; i < k; i++)
        {
            if ( accessPtr[i].action == Insert)
            {
                /* REF8844 - LJE - 030415 */
                if (accessPtr[i].object == EOp)
                {

                    if (GET_UCHAR_BIT(GET_UCHAR(accessPtr[i].data,ExtOp_AutoIndex),AUTOINDEXCODE))
                    {
                        SET_NULL_CODE(accessPtr[i].data,ExtOp_Cd);
						uCharBit = GET_UCHAR(accessPtr[i].data,ExtOp_AutoIndex);
                        SET_UCHAR_BIT(uCharBit,AUTOINDEXCODE,FALSE);
                    }
                    if (GET_UCHAR_BIT(GET_UCHAR(accessPtr[i].data,ExtOp_AutoIndex),AUTOINDEXACCODE))
                    {
                        SET_NULL_CODE(accessPtr[i].data,ExtOp_AcctCd);
						uCharBit = GET_UCHAR(accessPtr[i].data,ExtOp_AutoIndex);
                        SET_UCHAR_BIT(uCharBit,AUTOINDEXACCODE,FALSE);
                    }

                }
                else if (accessPtr[i].object == BuyOpEnt)
                {

                    if (GET_UCHAR_BIT(GET_UCHAR(accessPtr[i].data,BuyOp_AutoIndex),AUTOINDEXCODE))
                    {
                        SET_NULL_CODE(accessPtr[i].data,BuyOp_Cd);
						uCharBit = GET_UCHAR(accessPtr[i].data,BuyOp_AutoIndex);
                        SET_UCHAR_BIT(uCharBit,AUTOINDEXCODE,FALSE);
                    }
                    if (GET_UCHAR_BIT(GET_UCHAR(accessPtr[i].data,BuyOp_AutoIndex),AUTOINDEXACCODE))
                    {
                        SET_NULL_CODE(accessPtr[i].data,BuyOp_AcctCd);
						uCharBit = GET_UCHAR(accessPtr[i].data,BuyOp_AutoIndex);
                        SET_UCHAR_BIT(uCharBit,AUTOINDEXACCODE,FALSE);
                    }

                }
                else if (accessPtr[i].object == SellOpEnt)
                {

                    if (GET_UCHAR_BIT(GET_UCHAR(accessPtr[i].data,SellOp_AutoIndex),AUTOINDEXCODE))
                    {
                        SET_NULL_CODE(accessPtr[i].data,SellOp_Cd);
						uCharBit = GET_UCHAR(accessPtr[i].data,SellOp_AutoIndex);
                        SET_UCHAR_BIT(uCharBit,AUTOINDEXCODE,FALSE);
                    }
                    if (GET_UCHAR_BIT(GET_UCHAR(accessPtr[i].data,SellOp_AutoIndex),AUTOINDEXACCODE))
                    {
                        SET_NULL_CODE(accessPtr[i].data,SellOp_AcctCd);
						uCharBit = GET_UCHAR(accessPtr[i].data,SellOp_AutoIndex);
                        SET_UCHAR_BIT(uCharBit,AUTOINDEXACCODE,FALSE);
                    }

                }
                else if (accessPtr[i].object == IncOpEnt)
                {

                    if (GET_UCHAR_BIT(GET_UCHAR(accessPtr[i].data,IncOp_AutoIndex),AUTOINDEXCODE))
                    {
                        SET_NULL_CODE(accessPtr[i].data,IncOp_Cd);
						uCharBit = GET_UCHAR(accessPtr[i].data,IncOp_AutoIndex);
                        SET_UCHAR_BIT(uCharBit,AUTOINDEXCODE,FALSE);
                    }
                    if (GET_UCHAR_BIT(GET_UCHAR(accessPtr[i].data,IncOp_AutoIndex),AUTOINDEXACCODE))
                    {
                        SET_NULL_CODE(accessPtr[i].data,IncOp_AcctCd);
						uCharBit = GET_UCHAR(accessPtr[i].data,IncOp_AutoIndex);
                        SET_UCHAR_BIT(uCharBit,AUTOINDEXACCODE,FALSE);
                    }

                }
                else if (accessPtr[i].object == InvestOpEnt)
                {

                    if (GET_UCHAR_BIT(GET_UCHAR(accessPtr[i].data,InvestOp_AutoIndex),AUTOINDEXCODE))
                    {
                        SET_NULL_CODE(accessPtr[i].data,InvestOp_Cd);
						uCharBit = GET_UCHAR(accessPtr[i].data,InvestOp_AutoIndex);
                        SET_UCHAR_BIT(uCharBit,AUTOINDEXCODE,FALSE);
                    }
                    if (GET_UCHAR_BIT(GET_UCHAR(accessPtr[i].data,InvestOp_AutoIndex),AUTOINDEXACCODE))
                    {
                        SET_NULL_CODE(accessPtr[i].data,InvestOp_AcctCd);
						uCharBit = GET_UCHAR(accessPtr[i].data,InvestOp_AutoIndex);
                        SET_UCHAR_BIT(uCharBit,AUTOINDEXACCODE,FALSE);
                    }

                }
                else if (accessPtr[i].object == WithdrOpEnt)
                {

                    if (GET_UCHAR_BIT(GET_UCHAR(accessPtr[i].data,WithdrOp_AutoIndex),AUTOINDEXCODE))
                    {
                        SET_NULL_CODE(accessPtr[i].data,WithdrOp_Cd);
						uCharBit = GET_UCHAR(accessPtr[i].data,WithdrOp_AutoIndex);
                        SET_UCHAR_BIT(uCharBit,AUTOINDEXCODE,FALSE);
                    }
                    if (GET_UCHAR_BIT(GET_UCHAR(accessPtr[i].data,WithdrOp_AutoIndex),AUTOINDEXACCODE))
                    {
                        SET_NULL_CODE(accessPtr[i].data,WithdrOp_AcctCd);
						uCharBit = GET_UCHAR(accessPtr[i].data,WithdrOp_AutoIndex);
                        SET_UCHAR_BIT(uCharBit,AUTOINDEXACCODE,FALSE);
                    }

                }
                else if (accessPtr[i].object == FtOpEnt)
                {

                    if (GET_UCHAR_BIT(GET_UCHAR(accessPtr[i].data,FtOp_AutoIndex),AUTOINDEXCODE))
                    {
                        SET_NULL_CODE(accessPtr[i].data,FtOp_Cd);
						uCharBit = GET_UCHAR(accessPtr[i].data,FtOp_AutoIndex);
                        SET_UCHAR_BIT(uCharBit,AUTOINDEXCODE,FALSE);
                    }
                    if (GET_UCHAR_BIT(GET_UCHAR(accessPtr[i].data,FtOp_AutoIndex),AUTOINDEXACCODE))
                    {
                        SET_NULL_CODE(accessPtr[i].data,FtOp_AcctCd);
						uCharBit = GET_UCHAR(accessPtr[i].data,FtOp_AutoIndex);
                        SET_UCHAR_BIT(uCharBit,AUTOINDEXACCODE,FALSE);
                    }

                }
                else if (accessPtr[i].object == AdjustOpEnt)
                {

                    if (GET_UCHAR_BIT(GET_UCHAR(accessPtr[i].data,AdjustOp_AutoIndex),AUTOINDEXCODE))
                    {
                        SET_NULL_CODE(accessPtr[i].data,AdjustOp_Cd);
						uCharBit = GET_UCHAR(accessPtr[i].data,AdjustOp_AutoIndex);
                        SET_UCHAR_BIT(uCharBit,AUTOINDEXCODE,FALSE);
                    }
                    if (GET_UCHAR_BIT(GET_UCHAR(accessPtr[i].data,AdjustOp_AutoIndex),AUTOINDEXACCODE))
                    {
                        SET_NULL_CODE(accessPtr[i].data,AdjustOp_AcctCd);
						uCharBit = GET_UCHAR(accessPtr[i].data,AdjustOp_AutoIndex);
                        SET_UCHAR_BIT(uCharBit,AUTOINDEXACCODE,FALSE);
                    }

                }
                else if (accessPtr[i].object == ShareIssOpEnt)
                {

                    if (GET_UCHAR_BIT(GET_UCHAR(accessPtr[i].data,ShareIssOp_AutoIndex),AUTOINDEXCODE))
                    {
                        SET_NULL_CODE(accessPtr[i].data,ShareIssOp_Cd);
						uCharBit = GET_UCHAR(accessPtr[i].data,ShareIssOp_AutoIndex);
                        SET_UCHAR_BIT(uCharBit,AUTOINDEXCODE,FALSE);
                    }
                    if (GET_UCHAR_BIT(GET_UCHAR(accessPtr[i].data,ShareIssOp_AutoIndex),AUTOINDEXACCODE))
                    {
                        SET_NULL_CODE(accessPtr[i].data,ShareIssOp_AcctCd);
						uCharBit = GET_UCHAR(accessPtr[i].data,ShareIssOp_AutoIndex);
                        SET_UCHAR_BIT(uCharBit,AUTOINDEXACCODE,FALSE);
                    }

                }
                else if (accessPtr[i].object == ShareRedmOpEnt)
                {

                    if (GET_UCHAR_BIT(GET_UCHAR(accessPtr[i].data,ShareRedmOp_AutoIndex),AUTOINDEXCODE))
                    {
                        SET_NULL_CODE(accessPtr[i].data,ShareRedmOp_Cd);
						uCharBit = GET_UCHAR(accessPtr[i].data,ShareRedmOp_AutoIndex);
                        SET_UCHAR_BIT(uCharBit,AUTOINDEXCODE,FALSE);
                    }
                    if (GET_UCHAR_BIT(GET_UCHAR(accessPtr[i].data,ShareRedmOp_AutoIndex),AUTOINDEXACCODE))
                    {
                        SET_NULL_CODE(accessPtr[i].data,ShareRedmOp_AcctCd);
						uCharBit = GET_UCHAR(accessPtr[i].data,ShareRedmOp_AutoIndex);
                        SET_UCHAR_BIT(uCharBit,AUTOINDEXACCODE,FALSE);
                    }

                }
                else if (accessPtr[i].object == TransfOpEnt)
                {

                    if (GET_UCHAR_BIT(GET_UCHAR(accessPtr[i].data,TransfOp_AutoIndex),AUTOINDEXCODE))
                    {
                        SET_NULL_CODE(accessPtr[i].data,TransfOp_Cd);
						uCharBit = GET_UCHAR(accessPtr[i].data,TransfOp_AutoIndex);
                        SET_UCHAR_BIT(uCharBit,AUTOINDEXCODE,FALSE);
                    }
                    if (GET_UCHAR_BIT(GET_UCHAR(accessPtr[i].data,TransfOp_AutoIndex),AUTOINDEXACCODE))
                    {
                        SET_NULL_CODE(accessPtr[i].data,TransfOp_AcctCd);
						uCharBit = GET_UCHAR(accessPtr[i].data,TransfOp_AutoIndex);
                        SET_UCHAR_BIT(uCharBit,AUTOINDEXACCODE,FALSE);
                    }

                }
                else if (accessPtr[i].object == BpTransfOpEnt)
                {

                    if (GET_UCHAR_BIT(GET_UCHAR(accessPtr[i].data,BpTransfOp_AutoIndex),AUTOINDEXCODE))
                    {
                        SET_NULL_CODE(accessPtr[i].data,BpTransfOp_Cd);
						uCharBit = GET_UCHAR(accessPtr[i].data,BpTransfOp_AutoIndex);
                        SET_UCHAR_BIT(uCharBit,AUTOINDEXCODE,FALSE);
                    }
                    if (GET_UCHAR_BIT(GET_UCHAR(accessPtr[i].data,BpTransfOp_AutoIndex),AUTOINDEXACCODE))
                    {
                        SET_NULL_CODE(accessPtr[i].data,BpTransfOp_AcctCd);
						uCharBit = GET_UCHAR(accessPtr[i].data,BpTransfOp_AutoIndex);
                        SET_UCHAR_BIT(uCharBit,AUTOINDEXACCODE,FALSE);
                    }

                }
                else if (accessPtr[i].object == LockOpEnt)
                {

                    if (GET_UCHAR_BIT(GET_UCHAR(accessPtr[i].data,LockOp_AutoIndex),AUTOINDEXCODE))
                    {
                        SET_NULL_CODE(accessPtr[i].data,LockOp_Cd);
						uCharBit = GET_UCHAR(accessPtr[i].data,LockOp_AutoIndex);
                        SET_UCHAR_BIT(uCharBit,AUTOINDEXCODE,FALSE);
                    }
                    if (GET_UCHAR_BIT(GET_UCHAR(accessPtr[i].data,LockOp_AutoIndex),AUTOINDEXACCODE))
                    {
                        SET_NULL_CODE(accessPtr[i].data,LockOp_AcctCd);
						uCharBit = GET_UCHAR(accessPtr[i].data,LockOp_AutoIndex);
                        SET_UCHAR_BIT(uCharBit,AUTOINDEXACCODE,FALSE);
                    }

                }
                else if (accessPtr[i].object == BookAdjOpEnt )
                {

                    if (GET_UCHAR_BIT(GET_UCHAR(accessPtr[i].data,BookAdjOp_AutoIndex),AUTOINDEXCODE))
                    {
                        SET_NULL_CODE(accessPtr[i].data,BookAdjOp_Cd);
						uCharBit = GET_UCHAR(accessPtr[i].data,BookAdjOp_AutoIndex);
                        SET_UCHAR_BIT(uCharBit,AUTOINDEXCODE,FALSE);
                    }
                    if (GET_UCHAR_BIT(GET_UCHAR(accessPtr[i].data,BookAdjOp_AutoIndex),AUTOINDEXACCODE))
                    {
                        SET_NULL_CODE(accessPtr[i].data,BookAdjOp_AcctCd);
						uCharBit = GET_UCHAR(accessPtr[i].data,BookAdjOp_AutoIndex);
                        SET_UCHAR_BIT(uCharBit,AUTOINDEXACCODE,FALSE);
                    }

                }
                else if (accessPtr[i].object == PtfTransfOpEnt)
                {

                    if (GET_UCHAR_BIT(GET_UCHAR(accessPtr[i].data,PtfTransfOp_AutoIndex),AUTOINDEXCODE))
                    {
                        SET_NULL_CODE(accessPtr[i].data,PtfTransfOp_Cd);
						uCharBit = GET_UCHAR(accessPtr[i].data,PtfTransfOp_AutoIndex);
                        SET_UCHAR_BIT(uCharBit,AUTOINDEXCODE,FALSE);
                    }
                    if (GET_UCHAR_BIT(GET_UCHAR(accessPtr[i].data,PtfTransfOp_AutoIndex),AUTOINDEXACCODE))
                    {
                        SET_NULL_CODE(accessPtr[i].data,PtfTransfOp_AcctCd);
						uCharBit = GET_UCHAR(accessPtr[i].data,PtfTransfOp_AutoIndex);
                        SET_UCHAR_BIT(uCharBit,AUTOINDEXACCODE,FALSE);
                    }

                }
                else if (accessPtr[i].object == InitOpEnt)
                {

                    if (GET_UCHAR_BIT(GET_UCHAR(accessPtr[i].data,InitOp_AutoIndex),AUTOINDEXCODE))
                    {
                        SET_NULL_CODE(accessPtr[i].data,InitOp_Cd);
						uCharBit = GET_UCHAR(accessPtr[i].data,InitOp_AutoIndex);
                        SET_UCHAR_BIT(uCharBit,AUTOINDEXCODE,FALSE);
                    }
                    if (GET_UCHAR_BIT(GET_UCHAR(accessPtr[i].data,InitOp_AutoIndex),AUTOINDEXACCODE))
                    {
                        SET_NULL_CODE(accessPtr[i].data,InitOp_AcctCd);
                        uCharBit = GET_UCHAR(accessPtr[i].data,InitOp_AutoIndex);
						SET_UCHAR_BIT(uCharBit,AUTOINDEXACCODE,FALSE);
                    }

                }
            }
        }
    }

	connInfoPtr->blockModeExt.curRec = 0;
	connInfoPtr->blockModeExt.curRecStep = 0;
	memset(&(connInfoPtr->blockModeExt.creation_d), 0, sizeof(DATETIME_T)); /* DLA - REF8880 - 030318 */
	FREE(connInfoPtr->blockModeExt.recTab);

    return(RET_SUCCEED);
}

/************************************************************************
*   Function             : DBA_HandleOperTab()
*
*   Description          : This function receive a block of operations (Buy, Sell, ExtOp, ...) and
*                          handle the block of operation according to action (Insert, Update, Delete,
*                          InsUpd, Notify).
*
*   Arguments            : connectNo       : the connection number used to dialog with Sql Server
*                          accessPtr       : the operation array
*                          processesOpTab  : an int array containing informations on which operations
*                                            cause problems. Can be passed as NULL if unused
*                          firstRec        : the number of first operation in the array
*                          opNbr           : the number of operations in the array
*                          msgStructHeader : header on a message structure list
*
*   Return               : RET_SUCCEED     : if no problem was detected
*
*   Creation Date        : 04.12.96 - PEC - Ref.: DVP291
*   Last Modification    : REF7264 - 0201225 - PMO : Compilation errors and warnings with C++ compiler
*
*************************************************************************/
RET_CODE DBA_HandleOperTab(DbiConnection&		 dbiConn,
                           DBA_ACCESS_STP        accessPtr,
                           int                   *processedOpTab,
                           int                   firstRec,
                           int                   opNbr,
                           bool                  bStoreErrMsgInElt)
{
    int                  i, limit;
    RET_CODE             retCode=RET_SUCCEED, ret = RET_SUCCEED;

    limit = firstRec+opNbr;

	dbiConn.getConnStructPtr()->blockMode = 0;

    for (i = firstRec; i<limit ; i++)
    {
        if (processedOpTab != NULL && processedOpTab[i-firstRec] == TRUE)
            continue;

        dbiConn.m_msgStructHeaderSt.clear();

        switch(accessPtr[i].action)
        {
        case Insert:
            if ((accessPtr[i].object == EOp) &&
                ((accessPtr[i].role == UNUSED) || (accessPtr[i].role == DBA_ROLE_EXTOP_IS_COPY)))
            {
                ret = DBA_InsExtOpByIdAndFuse2(accessPtr[i].entity,
                                               accessPtr[i].data,
											   dbiConn,
                                               (FLAG_T)((accessPtr[i].role == DBA_ROLE_EXTOP_IS_COPY) ?TRUE:FALSE));
            }
            else
            {
                ret = DBA_Insert2(accessPtr[i].object,
                                  accessPtr[i].role,
                                  accessPtr[i].entity,
                                  accessPtr[i].data,
                                  DBA_SET_CONN|DBA_NO_CLOSE, dbiConn);
            }

            break;

        case Update:
            ret = DBA_Update2(accessPtr[i].object,
                              accessPtr[i].role,
                              accessPtr[i].entity,
                              accessPtr[i].data,
							  DBA_SET_CONN | DBA_NO_CLOSE, dbiConn);

            break;

        case Delete:
            ret = DBA_Delete2(accessPtr[i].object,
                              accessPtr[i].role,
                              accessPtr[i].entity,
                              accessPtr[i].data,
							  DBA_SET_CONN | DBA_NO_CLOSE, dbiConn);

            break;

        case NullAction:
            ret = RET_SUCCEED;
            break;

        }

        if (ret != RET_SUCCEED)
        {
            if (bStoreErrMsgInElt)
            {
                if (dbiConn.m_msgStructHeaderSt.msgStructTab.size() > 0)
                {
                    if (accessPtr[i].msgStructHeaderStp == nullptr)
                    {
                        accessPtr[i].msgStructHeaderStp = new DbaErrmsgHeaderClass(dbiConn.m_msgStructHeaderSt);
                    }
                    else
                    {
                        for (auto msgStructIt = dbiConn.m_msgStructHeaderSt.msgStructTab.begin(); msgStructIt != dbiConn.m_msgStructHeaderSt.msgStructTab.end(); ++msgStructIt)
                        {
                            accessPtr[i].msgStructHeaderStp->msgStructTab.push_back((*msgStructIt));
                        }
                    }
                    dbiConn.m_msgStructHeaderSt.msgStructTab.clear();
                }
            }

            retCode = RET_SRV_LIB_ERR_ERRORS_OCCURED;

			if (ret == RET_SRV_LIB_ERR_CONNFAILED || !dbiConn.isConnected() ) /* REF4001 - SSO - 991004 */
            {
                if (!bStoreErrMsgInElt)
                {
                    limit=i+1;
                }

                /* not a connected connexion (has been killed by Sybase, not re-connected yet after DBA_ReviveAllDeadConn) */
                /* Build a message */
                DBA_ERRMSG_INFOS_STP errMsgInfoStp = nullptr;
                for (int j = firstRec; j < limit; j++)
                {
                    if (bStoreErrMsgInElt)
                    {
                        errMsgInfoStp = &accessPtr[j].msgStructHeaderStp->getNewErrMsgInfoSt(FILEINFO);
                    }
                    else
                    {
                        errMsgInfoStp = &dbiConn.m_msgStructHeaderSt.getNewErrMsgInfoSt(FILEINFO);
                    }

                    errMsgInfoStp->msgOrigin        = ServerHandler;
                    errMsgInfoStp->rdbmsMsgNb       = -1;
                    errMsgInfoStp->retCode          = RET_DBA_ERR_DBPROBLEM;
				    errMsgInfoStp->serverName       = dbiConn.getSpecification().getServerName();
                    errMsgInfoStp->msgString        = "Problem with Server Connection or Database (Connection lost)";
                    errMsgInfoStp->rdbmsMsgString   = errMsgInfoStp->msgString;

                    if (!bStoreErrMsgInElt)
                    {
                        errMsgInfoStp->firstInList = i;
                        errMsgInfoStp->lastInList  = limit;
                    }
                }
                break; /* stop because conn. ist kaputt! */
            }
        }
    }

    return(retCode);
}


/************************************************************************
*   Function             : DBA_GetFieldIdxTimeStamp()
*
*   Description          : Return the index field of the timestamp
*
*   Arguments            : fld          Where to read the timestamp. Can be ExtOp or Adm_Arg structure
*
*   Return               : >= 0 if ok
*                          -1   if error
*
*   Creation Date        : PMSTA-24207 - 020816 - PMO : Regression: cannot update operation + fusion failure while running automator basic entry test
*
*   Last Modification    : PMSTA-57346 - JBC - 20240709 : remove pointless error message
*
*************************************************************************/
STATIC FIELD_IDX_T DBA_GetFieldIdxTimeStamp(const DBA_DYNFLD_STP fld)
{
    const DBA_DYNST_ENUM dynFld = GET_DYNSTENUM(fld);

    FIELD_IDX_T ret = -1;

    if (ExtOp == dynFld)
    {
        ret = ExtOp_TimeStampNew;
    }
    else if (Adm_Arg == dynFld)
    {
        ret = Adm_Arg_TimeStamp;
    }

    return ret;
}


/************************************************************************
*   Function             : DBA_CopyTimeStamp()
*
*   Description          : Copy the timestamp
*
*   Arguments            : dest         Where to copy the timestamp. Can be ExtOp or Adm_Arg structure
*                          src          Where to read the timestamp. Can be ExtOp or Adm_Arg structure
*
*   Return               : None
*
*   Creation Date        : PMSTA-24207 - 020816 - PMO : Regression: cannot update operation + fusion failure while running automator basic entry test
*
*   Last Modification    :
*
*************************************************************************/
STATIC void DBA_CopyTimeStamp(DBA_DYNFLD_STP dest, const DBA_DYNFLD_STP src)
{
    FIELD_IDX_T idxDest = DBA_GetFieldIdxTimeStamp(dest);
    FIELD_IDX_T idxSrc  = DBA_GetFieldIdxTimeStamp(src);

    if (idxDest >= 0 && idxSrc >= 0)
    {
        SET_TIMESTAMP(dest, idxDest, GET_TIMESTAMP(src, idxSrc));
    }
}


/************************************************************************
*   Function             : DBA_HandleOperTabByBlock()
*
*   Description          : This function receive an array of operations/Extended operations
*                          and must perform actions (Insert, Update or Delete) on these
*                          operations, using block insertion mode.
*
*   Arguments            : connectNo          : the connection number used to dialog with Sql Server
*                          accessPtr          : the operation array
*                          firstRec           : the number of first operation in the array
*                          opNbr              : the number of operations in the array
*                          msgStructHeaderArg : pointer on a msg struct header which will contain
*                                               received messages informations.
*
*   Data organization
*   for block              ________________
*   mode handling        : | connection   | (DBA_CONNECT_INFO_ST)
*                          ----------------
*                          | ....         |
*                          | blockMode    |   ______________
*       (DBA_BLOCK_MODE_ST)| blockModeExt |-->| curRec     |   : refers to an index in argument "accessPtr"
*                          | ....         |   | curRecStep |   : refers to the current step in the treatment
*                          ----------------   | recTab     | (DBA_ACTION_STEP_STP)
*                                             -----|--------
*                                                  |   ________________
*                                                  --> | stepNbr      | : the number of steps used for treatment
*                                                      | stepDataSize | : the allocated size of array "stepData"
*                                                      | stepData     | (DBA_OPER_STEP_STP)
*                                                      -----|----------
*                                                           |   __________________
*                                                           --> | delOp          | (DBA_ACCESS_ST) : if action is a Delete or Update
*                                                               | insOp          | (DBA_ACCESS_ST) : if action is an Update or Insert
*                                                               | auditOp        | (DBA_ACCESS_ST) : if subscription is audit.
*                                                               | extDataNbr     |                 : nbr of ext. data (ExtOp, Notepad, ...)
*                                                               | extDataTabSize |                 : size, in elements, of extDataTab
*                                                               | extDataTab     | (DBA_ACCESS_STP): the ext. data array
*                                                               -----|------------
*                                                                    |
*                                                                    --> 0, one or many records
*                                                                        composed of ExtPos, Notepad,
*                                                                        EventSched,... attached to "insOp"
*
*
*   Return               : RET_SUCCEED              : if no problem was detected.
*                          RET_DBA_ERR_ARGNOMATCH   : if input arg. problem.
*                          RET_DBA_ERR_PROCNOTFOUND : if no procedure founded.
*                          RET_DBA_ERR_SETPARAM     : if problem while setting proc. parameters.
*                          RET_DBA_ERR_CONNOTFOUND  : if no connection found.
*                          RET_DBA_ERR_DBPROBLEM    : if DB/connection problem.
*                          RET_DBA_ERR_SYBBIND      : if problem while binding received fields.
*                          RET_MEM_ERR_ALLOC        : if allocation failed.
*                          RET_DBA_ERR_READ_DATA    : if problem while reading received data.
*                          RET_GEN_ERR_INVARG       : if problem while setting function params.
*                          a RET_CODE               : if a message has been received.
*
*   Creation Date        : 03.12.96 - PEC - Ref.: DVP291.
*   Last Modification    : 29.01.97 - PEC - Ref.: DVP337.
*                          03.07.97 - PEC - Ref.: DVP534.
*                          23.09.97 - DED - Ref.: REF187 : OPE_IsCloseExtOp is being replaced (No ExtOp structure available).
*                          09.10.97 - DED - Ref.: REF401 : Close records are orderlimitdate or begin date.
*                          20.10.97 - GRD - Ref.: REF494 : Beware of transactions when dealing with blocks of operations.
*                          06.11.98 - GRD - Ref.: REF2956: Transaction integrity problem in mode block.
*                          ROI - 990805 - REDF3742
*                          29.10.99 - GRD - Ref.: REF4083 : Order entry transaction integrity problems.
*                          26.03.00 - GRD - Ref.: REF4204 : Subscription.
*                          26.07.00 - GRD - Ref.: REF5037 : Take into account return codes from DBA_MultiAccess for subscription.
*                          01.02.00 - GRD - Ref.: REF5644 : Subscription does not send 'old:new' for audit, only 'old:old'.
*                          REF7264 - 0201225 - PMO : Compilation errors and warnings with C++ compiler
*                          REF8706 - TEB - 030815 : No error message when you try to save an order after a restart of the data server
*                          REF8500 - 040510 - PMO : Add a draft_order_id in extended operation to distinguish the id from extended
*                                                   orders and the one from extended operation
*                          REF10496 - 041014 - PMO : Problem when modifying a treated child operation
*                          REF11780 - 100406 - PMO : Implementation of the Sybase timestamp field
*                          PMSTA-14364 - 7.1.0 - Update SQL procedure required by the insert of fusion event when insert/update/delete operation
*                          PMSTA-24207 - 020816 - PMO : Regression: cannot update operation + fusion failure while running automator basic entry test
*
*************************************************************************/
RET_CODE DBA_HandleOperTabByBlock(DbiConnection&		dbiConn,
                                  DBA_ACCESS_STP        accessPtr,
                                  int                   firstRec,
                                  int                   maxRecInBuf,
                                  int                   opNbr,
                                  int                   options,
                                  bool                  bStoreErrMsgInElt)
{
    int                   eltNbr = 0, idx = 0, limit = 0, j = 0, k = 0,
        *processedOpTab = NULL, localTran = FALSE, fldNbr = 0;
    DBA_ACTION_STEP_STP   dataPtr;
    DBA_ACCESS_STP        accessTab,
                          subsAccessTab;                            /* REF4204 */
    RET_CODE              ret = RET_SUCCEED;
    DATETIME_T            closeDate;
    char                  *msg = NULL;
    OPSTAT_ENUM           acctStatEn = OpStat_Cancelled;  /* REF187 - 970923 - DED */
    int                   subsElmNbr = 0;                               /* REF4204 - GRD - 000407 */
	FLAG_T                accessTabFound = FALSE, checkForDuplicateOrder = FALSE;

	memset(&closeDate, 0, sizeof(DATETIME_T));

    /* limit is the index on the last operation record in accessPtr */
    limit = firstRec+opNbr;

    /* Initialize the block mode (set the blockMode, allocate all necessary arrays */
    dbiConn.getConnStructPtr()->blockMode               = 1;
    dbiConn.getConnStructPtr()->blockModeExt.curRecStep = 0;
    dbiConn.getConnStructPtr()->blockModeExt.recTab     = (DBA_ACTION_STEP_STP) CALLOC(opNbr, sizeof(DBA_ACTION_STEP_ST)); /* REF7264 - PMO */

    if ((SYS_GetRpcName().empty() == false) &&
        ((SYS_GetRpcName().compare("eval_entity_with_collection") == 0)) || (SYS_GetRpcName().compare("detach_order") == 0)) {
        checkForDuplicateOrder = TRUE;
    }

    /*
     * Allocate an array which will indicate which operations are refused by financial checkings (made in C).
     */

    processedOpTab = (int *) CALLOC(opNbr, sizeof(int));    /* REF7264 - PMO */
	size_t preOpMsgStructSize = 0, postOpMsgStructSize = 0;	/* PMSTA-46897 241121 SSN*/

    for (int i = firstRec; i < limit; i++)
    {
        /*
         * BEWARE: In case of recursive calls to DBA_InsExtOpById or DBA_UpdExtOpById, the curStepForOp
         *         will be added 1. We MUST reset it to 0 in case of errors or when stepping to new op.
         *
         * GRD - 04/11/1998 - REF2956.
         */

        dbiConn.getConnStructPtr()->blockModeExt.curRecStep = 0;   /* REF2956 */

        /* Allocate necessary arrays for each operation to handle */
        dbiConn.getConnStructPtr()->blockModeExt.recTab[i-firstRec].stepData = (DBA_OPER_STEP_STP)
            CALLOC(DBA_ALLOC_STEPBLOC, sizeof(DBA_OPER_STEP_ST));   /* REF7264 - PMO */

        dbiConn.getConnStructPtr()->blockModeExt.recTab[i-firstRec].stepNbr       = 0;
        dbiConn.getConnStructPtr()->blockModeExt.recTab[i-firstRec].stepDataSize  = DBA_ALLOC_STEPBLOC;
        dbiConn.getConnStructPtr()->blockModeExt.curRec                           = i-firstRec;

		preOpMsgStructSize = dbiConn.m_msgStructHeaderSt.msgStructTab.size();	/* PMSTA-46897 241121 SSN*/

        switch(accessPtr[i].action)
        {
        case Insert:
            if (accessPtr[i].object == EOp && accessPtr[i].role == UNUSED)
            {
                ret = DBA_InsExtOpByIdAndFuse2(accessPtr[i].entity,
                                               accessPtr[i].data,
                                               dbiConn,
                                               FALSE);
            }
            else
            {
                ret = DBA_Insert2(accessPtr[i].object,
                                  accessPtr[i].role,
                                  accessPtr[i].entity,
                                  accessPtr[i].data,
                                  DBA_SET_CONN|DBA_NO_CLOSE, dbiConn);
            }

            break;

        case Update:
            ret = DBA_Update2(accessPtr[i].object,
                              accessPtr[i].role,
                              accessPtr[i].entity,
                              accessPtr[i].data,
							  DBA_SET_CONN | DBA_NO_CLOSE, dbiConn);

            break;

        case Delete:
            ret = DBA_Delete2(accessPtr[i].object,
                              accessPtr[i].role,
                              accessPtr[i].entity,
                              accessPtr[i].data,
							  DBA_SET_CONN | DBA_NO_CLOSE, dbiConn);

            break;

        case NullAction:
            continue;
            break;

        default:
            /* Set the operation as "refused" */
            processedOpTab[i-firstRec] = TRUE;

            DBA_ERRMSG_INFOS_ST &errMsgInfoSt = dbiConn.m_msgStructHeaderSt.getNewErrMsgInfoSt(FILEINFO);

            /* Save the message structure in the message stack */
            msg = MSG_BuildMesg(UNUSED, UNUSED, "Invalid Action");
            MSG_FillMsgStruct(&errMsgInfoSt,
                              RET_SRV_LIB_ERR_TRIGGER_MSG,
                              msg,
                              ServerHandler,    /* REF7264 - PMO */
                              RET_LEV_TECH_C_ERROR,
                              TRUE,
                              NULL,
                              NULL,
                              0);
            FREE(msg);
            errMsgInfoSt.firstInList = i;
            errMsgInfoSt.lastInList = i;
            break;
        }

		postOpMsgStructSize = dbiConn.m_msgStructHeaderSt.msgStructTab.size();	/* PMSTA-46897 241121 SSN*/

        /* If an error is encountered */
        if (ret != RET_SUCCEED)
        {
            /* Set the operation as "refused" */
            processedOpTab[i-firstRec] = TRUE;

			int firstInList = i, lastInList = i;	/* PMSTA-46897 241121 SSN*/

            if (ret == RET_SRV_LIB_ERR_FATAL_DEADLOCK) /* REF6092 */
            {
                /* the connection is dead */
                MSG_SendMesg(RET_SRV_LIB_ERR_FATAL_DEADLOCK, 1, FILEINFO, dbiConn.getId());
				firstInList = firstRec;
				lastInList = limit;
                DBA_FreeOperTabForBlockHandling(dbiConn, accessPtr, firstRec, opNbr,ret);
                dbiConn.getConnStructPtr()->blockMode   = 0;
                FREE(processedOpTab);
            }

            if (ret == RET_SRV_LIB_ERR_DEADLOCK && dbiConn.isInTransaction() == true)
            {
                /* transaction has been rollbacked: update range + stop */
				firstInList = firstRec;
				lastInList = limit;
                DBA_FreeOperTabForBlockHandling(dbiConn, accessPtr, firstRec, opNbr,ret);
                dbiConn.getConnStructPtr()->blockMode   = 0;
                FREE(processedOpTab);
            }

			/* PMSTA-46897 241121 SSN*/
			DBA_ERRMSG_INFOS_ST errMsgInfoSt(FILEINFO);
			if (postOpMsgStructSize > preOpMsgStructSize)
			{
				for (size_t m = preOpMsgStructSize; m < postOpMsgStructSize; m++)
				{
					errMsgInfoSt = dbiConn.m_msgStructHeaderSt.msgStructTab.at(m);
					errMsgInfoSt.firstInList = firstInList;
					errMsgInfoSt.lastInList = lastInList;
				}
			}

			/* PMSTA-46714 - 211029 - Copy error messages in access element */
			if (bStoreErrMsgInElt)
			{
				if (dbiConn.m_msgStructHeaderSt.msgStructTab.size() > 0)
				{
					if (accessPtr[i].msgStructHeaderStp == nullptr)
					{
						accessPtr[i].msgStructHeaderStp = new DbaErrmsgHeaderClass(dbiConn.m_msgStructHeaderSt);
					}
					else
					{
						for (auto msgStructIt = dbiConn.m_msgStructHeaderSt.msgStructTab.begin(); msgStructIt != dbiConn.m_msgStructHeaderSt.msgStructTab.end(); ++msgStructIt)
						{
							accessPtr[i].msgStructHeaderStp->msgStructTab.push_back((*msgStructIt));
						}
					}
					dbiConn.m_msgStructHeaderSt.msgStructTab.clear();
				}
			}

			if ((ret == RET_SRV_LIB_ERR_FATAL_DEADLOCK) ||
				(ret == RET_SRV_LIB_ERR_DEADLOCK && dbiConn.isInTransaction() == true))
			{
				return ret;
			}

            /*
             * Do we stand any error?
             * BEWARE: The use of DBA_NO_ERROR flag must be combined with a transaction.
             * REF494 - 971013 - GRD.
             */

            if ((options & DBA_NO_ERROR) == DBA_NO_ERROR)
            {
                DBA_FreeOperTabForBlockHandling(dbiConn, accessPtr, firstRec, opNbr,ret);
                dbiConn.getConnStructPtr()->blockMode   = 0;
                FREE(processedOpTab);

                /* REF8706 - 030815 - TEB
                 * ret can be
                 *   - RET_DBA_ERR_CONNLOST           -> Error message
                 *   - RET_SRV_LIB_ERR_ERRORS_OCCURED -> No message
                 */
                if (ret != RET_DBA_ERR_CONNLOST)
                {
                    ret = RET_SRV_LIB_ERR_ERRORS_OCCURED;

					/* PMSTA-44907-Badhri-05132021: add error message to the msg Struct */
					msg = MSG_BuildMesg(UNUSED, UNUSED, "Save session failed");
					MSG_FillMsgStruct(&errMsgInfoSt,
									RET_SRV_LIB_ERR_ERRORS_OCCURED,
									msg,
									ServerHandler,
									RET_LEV_TECH_C_ERROR,
									TRUE,
									NULL,
									NULL,
									0);
					FREE(msg);
                }

				FREE(processedOpTab); /* PMSTA-17717 - CHU - 140312 : Purify */
                return(ret);
            }
        }
    }

    /*
     * Little loop to evaluate the number of structure to allocate, according to number of elements
     * to pass to DBA_MultiAccess.
     */

    eltNbr    = 0;
    dataPtr   = dbiConn.getConnStructPtr()->blockModeExt.recTab;

    for (int i=0 ; i<opNbr ; i++)
    {
        if (processedOpTab[i] == TRUE)
            continue;

        for (j=0 ; j<=dataPtr[i].stepNbr ; j++)
        {
            if (processedOpTab[i] == TRUE)
                continue;

            /**** BEGIN DVP337 ****/
            /* Check all extended data for invalid amounts */
            for (k=0 ; k<dataPtr[i].stepData[j].extDataNbr ; k++)
            {
                                /* Call the function which will filter an error in the record
                                   for a wrong double value (an amount) */
                if (processedOpTab[i] == TRUE)
                    continue;

                if (DBA_CheckDynStNumbers(dataPtr[i].stepData[j].extDataTab[k].entity,
                                          dataPtr[i].stepData[j].extDataTab[k].data,
                                          &fldNbr) == RET_DBA_ERR_INVDATA)
                {
                    /* Set the operation to "refused" */
                    processedOpTab[i] = TRUE;

                    DBA_ERRMSG_INFOS_ST &errMsgInfoSt = dbiConn.m_msgStructHeaderSt.getNewErrMsgInfoSt(FILEINFO);

                    /* Save the message structure in the message stack */
                    errMsgInfoSt.status       = 0;
                    errMsgInfoSt.gravity      = 0;
                    errMsgInfoSt.techMsg      = 0;
                    errMsgInfoSt.msgOrigin    = ServerHandler;
                    errMsgInfoSt.rdbmsMsgNb   = -1;
                    errMsgInfoSt.retCode      = RET_SRV_LIB_ERR_ERRORS_OCCURED;
                    errMsgInfoSt.affectedRows = 0;
                    errMsgInfoSt.procedure.clear();
                    errMsgInfoSt.serverName   =   dbiConn.getSpecification().getServerName();

                    SYS_StringFormat(errMsgInfoSt.msgString, "Wrong value in '%s', field '%s'. Action failed",
                                     DBA_GetDictEntitySqlName(dataPtr[i].stepData[j].extDataTab[k].object),
                                     DBA_GetDictAttribSqlName(dataPtr[i].stepData[j].extDataTab[k].object,
                                                              fldNbr));
                    errMsgInfoSt.rdbmsMsgString = errMsgInfoSt.msgString;

                    errMsgInfoSt.firstInList = i+firstRec;
                    errMsgInfoSt.lastInList = i+firstRec;

                    continue;
                }
            }
            /**** END   DVP337 ****/

            /* If operation isn't refused */
            if (processedOpTab[i] == FALSE)
            {
                {
                    eltNbr += 2 + dataPtr[i].stepData[j].extDataNbr;
                }
            }
        }
    }

    /* If no operation of if all operations has been marked as "refused" */
    if (eltNbr == 0)
    {
        DBA_FreeOperTabForBlockHandling(dbiConn, accessPtr, firstRec, opNbr,ret);
        dbiConn.getConnStructPtr()->blockMode   = 0;
        FREE(processedOpTab);
        return(RET_SRV_LIB_ERR_ERRORS_OCCURED);
    }

    accessTab = (DBA_ACCESS_STP) CALLOC(eltNbr, sizeof(DBA_ACCESS_ST)); /* REF7264 - PMO */
    idx       = 0;

    /* For each operation to handle, extract the addresses of the records (operations) to send to DB (Delete and Insert) */
    for (int i = 0; i < opNbr; i++)
    {
        if (processedOpTab[i] == TRUE)
            continue;

        for (j=0 ; j<=dataPtr[i].stepNbr ; j++)
        {
            if (processedOpTab[i] == TRUE)
                continue;

            /*
             * Subscription.
             * GRD - REF4204 - 000326.
             */

            if (dataPtr[i].stepData[j].auditOp.data != NULL)
            {
                subsElmNbr++;                                   /* Count the number of subscription events. */
            }

            /*
             * If Action was an "Update" or a "Delete", the field delOp contains the pointer on the operation to
             * delete.
             */

            if (dataPtr[i].stepData[j].delOp.data != NULL)
            {
                                /**** BEGIN DVP337 ****/
                                /* Call the function which will filter an error in the record for a wrong double value (an amount) */
                if (DBA_CheckDynStNumbers(dataPtr[i].stepData[j].delOp.entity,
                                          dataPtr[i].stepData[j].delOp.data,
                                          &fldNbr) == RET_DBA_ERR_INVDATA)
                {
                    /* Set the operation to "refused" */
                    processedOpTab[i] = TRUE;

                    DBA_ERRMSG_INFOS_ST &errMsgInfoSt = dbiConn.m_msgStructHeaderSt.getNewErrMsgInfoSt(FILEINFO);

                    /* Save the message structure in the message stack */
                    errMsgInfoSt.msgOrigin    = ServerHandler;
                    errMsgInfoSt.rdbmsMsgNb   = -1;
                    errMsgInfoSt.retCode      = RET_SRV_LIB_ERR_ERRORS_OCCURED;
                    errMsgInfoSt.serverName   =  dbiConn.getSpecification().getServerName();

                    SYS_StringFormat(errMsgInfoSt.msgString,  "Wrong value in 'short_operation', field '%d'. Action failed", fldNbr);

                    errMsgInfoSt.rdbmsMsgString = errMsgInfoSt.msgString;

                    errMsgInfoSt.firstInList = i+firstRec;
                    errMsgInfoSt.lastInList = i+firstRec;

                    continue;
                }
                                /**** END  DVP337 ****/

                accessTab[idx].action  = Delete;
                accessTab[idx].role    = dataPtr[i].stepData[j].delOp.role;
                accessTab[idx].object  = dataPtr[i].stepData[j].delOp.object;
                accessTab[idx].entity  = dataPtr[i].stepData[j].delOp.entity;
                accessTab[idx].data    = dataPtr[i].stepData[j].delOp.data;
                idx++;
            }

            /* If Action was an "Update" or a "Insert", the field insOp contains the pointer on the operation to
               insert */
            if (dataPtr[i].stepData[j].insOp.data != NULL)
            {
                                /**** BEGIN DVP337 ****/
                                /* Call the function which will filter an error in the record for a wrong double value */
                if (DBA_CheckDynStNumbers(dataPtr[i].stepData[j].insOp.entity,
                                          dataPtr[i].stepData[j].insOp.data,
                                          &fldNbr) == RET_DBA_ERR_INVDATA)
                {
                    /* Set the operation to "refused" */
                    processedOpTab[i] = TRUE;

                    DBA_ERRMSG_INFOS_ST &errMsgInfoSt = dbiConn.m_msgStructHeaderSt.getNewErrMsgInfoSt(FILEINFO);

                    /* Save the message structure in the message stack */
                    errMsgInfoSt.msgOrigin    = ServerHandler;
                    errMsgInfoSt.rdbmsMsgNb   = -1;
                    errMsgInfoSt.retCode      = RET_SRV_LIB_ERR_ERRORS_OCCURED;
                    errMsgInfoSt.serverName   =  dbiConn.getSpecification().getServerName();

                    SYS_StringFormat(errMsgInfoSt.msgString,  "Wrong value in '%s', field '%s'. Action failed",
                            DBA_GetDictEntitySqlName(dataPtr[i].stepData[j].insOp.object),
                            DBA_GetDictAttribSqlName(dataPtr[i].stepData[j].insOp.object,
                                                     fldNbr));
                    errMsgInfoSt.rdbmsMsgString = errMsgInfoSt.msgString;

                    errMsgInfoSt.firstInList = i+firstRec;
                    errMsgInfoSt.lastInList = i+firstRec;
                    continue;
                }
                                /**** END  DVP337 ****/
				/*PMSTA-35865 - sriharbv - 09-27-2019 - WUI Cancel a block order - status order accepted makes financial server to crash
				Details :When Cancel of Block order , the record which needs to be updated(cancelled) are entered twice in accessTab  and
				query formed in DBA_MultiEntity updation has same time_stamp(row_version)
				This leads to DB error of non-Updating of records.Code changes is to filter the Duplicate record.*/
				accessTabFound = FALSE;
				if (checkForDuplicateOrder == TRUE)  {
					if ((dataPtr[i].stepData[j].insOp.object == EOp || dataPtr[i].stepData[j].insOp.object == ExtOrder ) && dataPtr[i].stepData[j].insOp.entity == ExtOp) {
                            for (int extOpNbr = 0; extOpNbr < idx; extOpNbr++) {
								if ((accessTab[extOpNbr].object == EOp || accessTab[extOpNbr].object == ExtOrder) && (CMP_ID(GET_ID(dataPtr[i].stepData[j].insOp.data, ExtOp_DbId), GET_ID(accessTab[extOpNbr].data, ExtOp_DbId)) == 0)) {
									accessTabFound = TRUE;
									break;
								}
							}
					}
				}

				if (accessTabFound == FALSE) {
					accessTab[idx].action = dataPtr[i].stepData[j].insOp.action; /* DLA - REF7560 - 020806 */
					accessTab[idx].role   = dataPtr[i].stepData[j].insOp.role;
					accessTab[idx].object = dataPtr[i].stepData[j].insOp.object;
					accessTab[idx].entity = dataPtr[i].stepData[j].insOp.entity;
					accessTab[idx].data   = dataPtr[i].stepData[j].insOp.data;
					idx++;
				}
            }
        }
    }

    if (dbiConn.m_transactCpt <= 0)
        /* "<" replaced by "<=" REF4001 - SSO - 991004 (case of deadlock) */
    {
        localTran = TRUE;
        dbiConn.beginTransaction();
    }

    /* Send the block of Operation (actions can be "Insert" or "Delete" (no "Update") */
    ret = DBA_MultiAccess(accessTab,
                          idx,
                          maxRecInBuf,
                          DBA_SET_CONN|DBA_NO_CLOSE|DBA_OP_BLOCK|DBA_NO_ERROR,
						  dbiConn);

    switch (ret)
    {
    case RET_SUCCEED:
        break;

    default:      /* If an error occurs (Technical error, Business, Deadlock,...), operations are handled
                     using normal mode (single mode) */

        /* Free all memory allocated specially for block mode */
        DBA_FreeOperTabForBlockHandling(dbiConn, accessPtr, firstRec, opNbr,ret);/* REF6915 move C code */
        FREE(accessTab);

        /* Rollback the transaction */ /* REF4001 - SSO - 991004 : if deadlock, it has been done by dataserver */
		/* PMSTA-46714 - 211029 - Rollback transaction in all cases (local and external tarnsaction */
		if (dbiConn.isInTransaction()
            && ret != RET_SRV_LIB_ERR_DEADLOCK
            && ret != RET_SRV_LIB_ERR_FATAL_DEADLOCK)
        {
            dbiConn.endTransaction(FALSE);
            dbiConn.m_transactCpt = 0;
        }

        /* Call the function which will handle each operation */
        /* BEWARE: The use of DBA_NO_ERROR flag must be combined with a transaction. */
		if ((options & DBA_NO_ERROR) != DBA_NO_ERROR
            && ret != RET_SRV_LIB_ERR_FATAL_DEADLOCK) /* REF4001 - SSO - 991004 don't use dead connexion */
        {
            dbiConn.m_lastResultRetCode = RET_SUCCEED;
            dbiConn.m_msgStructHeaderSt.clear();
			dbiConn.endTransaction(FALSE);  /* PMSTA-51293 - SRS - 27022023 */
			dbiConn.m_transactCpt = 0;  /* PMSTA-51293 - SRS - 27022023 */
            ret = DBA_HandleOperTab(dbiConn, accessPtr, processedOpTab, firstRec, opNbr, bStoreErrMsgInElt);
        }
        else
        {
            /* REF4001 - SSO - 991004 don't loose messages -> copy them! */
            /* REF4001 - SSO - 991011: if deadlock, build a single message for the whole block */
            if (ret == RET_SRV_LIB_ERR_FATAL_DEADLOCK)
            {
                DBA_ERRMSG_INFOS_ST &errMsgInfoSt = dbiConn.m_msgStructHeaderSt.getNewErrMsgInfoSt(FILEINFO);

                errMsgInfoSt.msgOrigin        = ServerHandler;
                errMsgInfoSt.rdbmsMsgNb       = -1;
                errMsgInfoSt.retCode          = RET_SRV_LIB_ERR_FATAL_DEADLOCK;
                errMsgInfoSt.serverName       = dbiConn.getSpecification().getServerName();
                SYS_StringFormat(errMsgInfoSt.msgString,  "Fatal Deadlock occurred in database, connection %d is dead", dbiConn.getId());
                errMsgInfoSt.rdbmsMsgString   = errMsgInfoSt.msgString;
                errMsgInfoSt.firstInList      = firstRec;
                errMsgInfoSt.lastInList       = opNbr;
            }
        }

		/* PMSTA-46714 - 211029 - In case of external transaction, begin a new transaction as it was rollbacked */
		if (localTran == FALSE)
		{
			dbiConn.beginTransaction();
		}

        dbiConn.getConnStructPtr()->blockMode   = 0;/* REF3792 - SSO - 991207 */
		FREE(accessTab);  /* PMSTA-17717 - CHU - 140312 : Purify */
		FREE(processedOpTab); /* PMSTA-17717 - CHU - 140312 : Purify */
        return(ret);
    }

    /*
     * Now handles all subscriptions on ExtOp. maxRecInBuf
     */

    if (subsElmNbr > 0)
    {
        subsAccessTab = (DBA_ACCESS_STP) CALLOC(subsElmNbr, sizeof(DBA_ACCESS_ST)); /* REF7264 - PMO */
        idx           = 0;

        /* For each operation to handle, extract the addresses of the records (operations) to send to DB (Delete and Insert) */
        for (int i=0; i<opNbr; i++)
        {
            if (processedOpTab[i] == TRUE || accessTab[i].action == NullAction ) /* DLA - PMSTA-10877 - 110111 */
                continue;                                           /* Marked as refused. */

            for (j=0 ; j<=dataPtr[i].stepNbr ; j++)
            {
                if (processedOpTab[i] == TRUE)
                    continue;                                       /* Marked as refused. */

				if (dataPtr[i].stepData[j].auditOp.data != NULL )
                {
                    subsAccessTab[idx].action       = dataPtr[i].stepData[j].auditOp.action;
                    subsAccessTab[idx].role         = dataPtr[i].stepData[j].auditOp.role;
                    subsAccessTab[idx].object       = dataPtr[i].stepData[j].auditOp.object;
                    subsAccessTab[idx].entity       = dataPtr[i].stepData[j].auditOp.entity;
                    subsAccessTab[idx].newData      = dataPtr[i].stepData[j].auditOp.newData;   /* REF5644 - GRD - 010202 */
                    subsAccessTab[idx].data         = dataPtr[i].stepData[j].auditOp.data;      /* REF5644 - GRD - 010202 */
                    DBA_CopyTimeStamp(subsAccessTab[idx].data, dataPtr[i].stepData[j].auditOp.data);            /* PMSTA-24207 - 020816 - PMO */
                    idx++;
                }
            }
        }

        if (idx > 0)
        {
			/*	PMSTA-52562 - 040523 - SRN	*/
			if(!SYS_IsGuiMode())
			{
				INFO_T src, dest;
				UChar * targetinfo = NULL;
				UChar * targetnote = NULL;
				int     Ulen = UNUSED, fd;
				
				for (fd = 0; fd < GET_FLD_NBR(subsAccessTab->data->dynStEnum); fd++)
				{
					if ((InfoType == (DATATYPE_ENUM)subsAccessTab[0].data[fd].dataType) ||
						(NoteType == (DATATYPE_ENUM)subsAccessTab[0].data[fd].dataType))
					{
						*src = END_OF_STRING;
						*dest = END_OF_STRING;
						if (targetinfo == NULL) { targetinfo = static_cast<UChar*>(CALLOC(1, sizeof(INFO_T))); }
						if (targetnote == NULL) { targetnote = static_cast<UChar*>(CALLOC(1, sizeof(NOTE_T))); }

						if ((subsAccessTab->action == Update) &&
							((subsAccessTab[0].newData) != NULLDYNST) &&
							(!IS_NULLFLD((subsAccessTab[0].newData), fd) == TRUE))
						{
							if ((subsAccessTab->newData[fd].data.strData.ptr) != NULL)
							{
								switch ((DATATYPE_ENUM)subsAccessTab[0].data[fd].dataType)
								{
								case InfoType:
									strncpy(src, GET_INFO(subsAccessTab[0].newData, fd), sizeof(INFO_T));
									ICU4AAA_ConvertFromUTF8(static_cast<const char *>(src), SYS_StrLen(src), targetinfo, SYS_StrLen(src), &Ulen);
									ICU4AAA_ConvertFromUChars(targetinfo, SYS_StrLen(src), static_cast<char*>(dest), INFO_T_LEN, &Ulen, TextConversion_Iso1);
									SET_INFO((subsAccessTab[0].newData), fd, static_cast<const char *>(dest));
									break;
								case NoteType:
									strncpy(src, GET_NOTE(subsAccessTab[0].newData, fd), sizeof(NOTE_T));
									ICU4AAA_ConvertFromUTF8(static_cast<const char *>(src), SYS_StrLen(src), targetnote, SYS_StrLen(src), &Ulen);
									ICU4AAA_ConvertFromUChars(targetnote, SYS_StrLen(src), static_cast<char*>(dest), INFO_T_LEN, &Ulen, TextConversion_Iso1);
									SET_NOTE((subsAccessTab[0].newData), fd, static_cast<const char *>(dest));
									break;
								}
							}
						}

						if ((subsAccessTab->action == Insert) &&
							((subsAccessTab[0].data) != NULLDYNST) &&
							(!IS_NULLFLD((subsAccessTab[0].data), fd) == TRUE))
						{
							if ((subsAccessTab->data[fd].data.strData.ptr) != NULL)
							{
								switch ((DATATYPE_ENUM)subsAccessTab[0].data[fd].dataType)
								{
								case InfoType:
									strncpy(src, GET_INFO(subsAccessTab[0].data, fd), sizeof(INFO_T));
									ICU4AAA_ConvertFromUTF8(static_cast<const char *>(src), SYS_StrLen(src), targetinfo, SYS_StrLen(src), &Ulen);
									ICU4AAA_ConvertFromUChars(targetinfo, SYS_StrLen(src), static_cast<char*>(dest), INFO_T_LEN, &Ulen, TextConversion_Iso1);
									SET_INFO((subsAccessTab[0].data), fd, static_cast<const char *>(dest));
									break;
								case NoteType:
									strncpy(src, GET_NOTE(subsAccessTab[0].data, fd), sizeof(NOTE_T));
									ICU4AAA_ConvertFromUTF8(static_cast<const char *>(src), SYS_StrLen(src), targetnote, SYS_StrLen(src), &Ulen);
									ICU4AAA_ConvertFromUChars(targetnote, SYS_StrLen(src), static_cast<char*>(dest), INFO_T_LEN, &Ulen, TextConversion_Iso1);
									SET_NOTE((subsAccessTab[0].data), fd, static_cast<const char *>(dest));
									break;
								}
							}
						}
					}
				}
				if(targetinfo != NULL) FREE(targetinfo);
				if(targetnote != NULL) FREE(targetnote)
			}
			/*	PMSTA-52562 - 040523 - SRN	*/

            DbaMultiAccessHelper       multiAccessHelper(subsAccessTab, idx);
            /* Send the block of subscription events. */
            ret = multiAccessHelper.callMultiAccess(maxRecInBuf, DBA_SET_CONN|DBA_NO_CLOSE|DBA_OP_BLOCK|DBA_NO_ERROR, dbiConn, true);

            switch (ret)
            {
            case RET_SUCCEED:
                break;

            default:   /* If an error occurred, then a rollback MUST be done. REM: In case of deadlock,
                          Sybase did it already. */

                /* Rollback the transaction */ /* REF4001 - SSO - 991004 : if deadlock,
                   it has been done by dataserver */

                multiAccessHelper.sendAllMultiAccessMsg();

                /* Free all memory allocated specially for block mode */
                DBA_FreeOperTabForBlockHandling(dbiConn, accessPtr, firstRec, opNbr,ret); /* SME Move C code */
                FREE(accessTab);

                if (localTran
                    && ret != RET_SRV_LIB_ERR_DEADLOCK
                    && ret != RET_SRV_LIB_ERR_FATAL_DEADLOCK)
                {
                    dbiConn.endTransaction(FALSE);
                    dbiConn.m_transactCpt = 0;
                }

                /* REF4001 - SSO - 991004 don't loose messages -> copy them! */
                /* REF4001 - SSO - 991011: if deadlock, build a single message for the whole block */
                if (ret == RET_SRV_LIB_ERR_FATAL_DEADLOCK)
                {
                    DBA_ERRMSG_INFOS_ST &errMsgInfoSt = dbiConn.m_msgStructHeaderSt.getNewErrMsgInfoSt(FILEINFO);

                    errMsgInfoSt.msgOrigin      = ServerHandler;
                    errMsgInfoSt.rdbmsMsgNb     = -1;
                    errMsgInfoSt.retCode        = RET_SRV_LIB_ERR_FATAL_DEADLOCK;
                    errMsgInfoSt.serverName     = dbiConn.getSpecification().getServerName();
                    SYS_StringFormat(errMsgInfoSt.msgString,  "Fatal Deadlock occurred in database, connection %d is dead", dbiConn.getId());
                    errMsgInfoSt.rdbmsMsgString = errMsgInfoSt.msgString;

                    errMsgInfoSt.firstInList = firstRec;
                    errMsgInfoSt.lastInList = opNbr;
                }

                dbiConn.getConnStructPtr()->blockMode   = 0; /* REF3792 - SSO - 991207 */
				FREE(subsAccessTab); /* DLA - PMSTA09304 - 100208 */
				FREE(accessTab);  /* PMSTA-17717 - CHU - 140312 : Purify */
				FREE(processedOpTab); /* PMSTA-17717 - CHU - 140312 : Purify */
                return(ret);
            }
        }
		FREE(subsAccessTab); /* DLA - PMSTA09304 - 100208 */
    }

    idx = 0;

    /* Get system parameter Accounting Status */            /* REF187 - 970923 - DED */
    GEN_GetApplInfo(ApplAccountingStatus, &acctStatEn);

    /* Update all Extended Operation / Extended positions / Notepad / Fusion Stat with the id's of corresponding operations */
    for (int i=0 ; i<opNbr ; i++)
    {
        if (processedOpTab[i] == TRUE || accessTab[i].action == NullAction ) /* DLA - PMSTA-10877 - 110111 */
            continue;

        for (j=0 ; j<=dataPtr[i].stepNbr ; j++)
        {
            if (dataPtr[i].stepData[j].insOp.data != NULL ||
                dataPtr[i].stepData[j].insOp.role == DBA_ROLE_PORT_POS_SET) /* DVP534 */
            {
                for (k=0 ; k<dataPtr[i].stepData[j].extDataNbr ; k++)
                {
                    /* REF8844 - LJE - 030415 */
                    if (dataPtr[i].stepData[j].extDataTab[k].entity == ExtOp)
                    {


                        if (dataPtr[i].stepData[j].insOp.role == DBA_ROLE_PORT_POS_SET)
                            continue;

                        COPY_DYNFLD(dataPtr[i].stepData[j].extDataTab[k].data,
                                    ExtOp,
                                    ExtOp_OpId,
                                    dataPtr[i].stepData[j].insOp.data,
                                    ExtOp,       /* DLA - REF7560 - 020610 */
                                    ExtOp_OpId); /* DLA - REF7560 - 020610 */

                                /* BEGIN DVP534 */
                        COPY_DYNFLD(dataPtr[i].stepData[j].extDataTab[k].data,
                                    ExtOp,
                                    ExtOp_DbId,
                                    dataPtr[i].stepData[j].insOp.data,
                                    ExtOp,
                                    ExtOp_DbId); /* DLA - REF7560 - 020930 */
                                /* END DVP534 */
                        /* REF8500 - 040510 - PMO */
                        COPY_DYNFLD(dataPtr[i].stepData[j].extDataTab[k].data,
                                    ExtOp,
                                    ExtOp_DraftOrderId,
                                    dataPtr[i].stepData[j].insOp.data,
                                    ExtOp,
                                    ExtOp_DraftOrderId);

                        /*  TimeStamp field must also be copied         */  /*  HFI-PMSTA-46035-210908  */
                        COPY_DYNFLD(dataPtr[i].stepData[j].extDataTab[k].data,
                                    ExtOp,
                                    ExtOp_TimeStampNew,
                                    dataPtr[i].stepData[j].insOp.data,
                                    ExtOp,
                                    ExtOp_TimeStampNew);
                    }
                    else

                    /* Code removed DLA - REF7560 - 020610 */

                    if (dataPtr[i].stepData[j].extDataTab[k].entity == A_EventSched)
                    {

                        if (dataPtr[i].stepData[j].insOp.role == DBA_ROLE_PORT_POS_SET) /* DVP534 */
                            continue;

                        /* REF10496 - 040728 - PMO */
                        SET_ID(dataPtr[i].stepData[j].extDataTab[k].data,
                               A_EventSched_OperId,
                               OPE_GetOpIdFromExtOpPriorityOperation(dataPtr[i].stepData[j].insOp.data));
                        COPY_DYNFLD(dataPtr[i].stepData[j].extDataTab[k].data, A_EventSched, A_EventSched_ExtOrderTimestamp, dataPtr[i].stepData[j].insOp.data, ExtOp, ExtOp_TimeStampNew);   /* PMSTA-14364 - 230813 - PMO */
                    }
                    else if (dataPtr[i].stepData[j].extDataTab[k].entity == A_Notepad)
                    {


                        if (dataPtr[i].stepData[j].insOp.role == DBA_ROLE_PORT_POS_SET) /* DVP534 */
                            continue;

                        /* REF8500 - 040510 - PMO */
                        SET_ID(dataPtr[i].stepData[j].extDataTab[k].data,
                               A_Notepad_ObjId,
                               OPE_GetOpIdFromExtOpPriorityOperation(dataPtr[i].stepData[j].insOp.data));
                    }

                    accessTab[idx].action = dataPtr[i].stepData[j].extDataTab[k].action;
                    accessTab[idx].role   = dataPtr[i].stepData[j].extDataTab[k].role;
                    accessTab[idx].object = dataPtr[i].stepData[j].extDataTab[k].object;
                    accessTab[idx].entity = dataPtr[i].stepData[j].extDataTab[k].entity;
                    accessTab[idx].data   = dataPtr[i].stepData[j].extDataTab[k].data;
                    idx++;
                }
            }
        }

        /* If action was "Insert" or "Update", save operation Id in operation record */
        if (dataPtr[i].stepData[0].insOp.data != NULL)
        {
            if (accessPtr[i+firstRec].object == EOp)
            {
                COPY_DYNFLD(accessPtr[i+firstRec].data,
                            accessPtr[i+firstRec].entity,
                            ExtOp_OpId,
                            dataPtr[i].stepData[0].insOp.data,
                            ExtOp,
                            ExtOp_OpId);  /*DLA - REF7560- 021001 */
                COPY_DYNFLD(accessPtr[i+firstRec].data,
                            accessPtr[i+firstRec].entity,
                            ExtOp_DbId, /*DLA - REF7560- 021001 */
                            dataPtr[i].stepData[0].insOp.data,
                            ExtOp,
                            ExtOp_DbId); /*DLA - REF7560- 021001 */

                /* REF8500 - 040510 - PMO */
                COPY_DYNFLD(accessPtr[i+firstRec].data,
                            accessPtr[i+firstRec].entity,
                            ExtOp_DraftOrderId,
                            dataPtr[i].stepData[0].insOp.data,
                            ExtOp,
                            ExtOp_DraftOrderId);

                /*  TimeStamp field must also be copied         */  /*  HFI-PMSTA-46035-210908  */
                COPY_DYNFLD(accessPtr[i+firstRec].data,
                            accessPtr[i+firstRec].entity,
                            ExtOp_TimeStampNew,
                            dataPtr[i].stepData[0].insOp.data,
                            ExtOp,
                            ExtOp_TimeStampNew);            }
        }
    }

    /* If No extended data (ExtOp, ExtPos, A_Notepad, A_EventSched) to insert */
    if (idx == 0)
    {

        DBA_FreeOperTabForBlockHandling(dbiConn, accessPtr, firstRec, opNbr,ret); /* SME move C code */
        dbiConn.getConnStructPtr()->blockMode   = 0;

        if (localTran)
        {
            dbiConn.endTransaction(TRUE);
            dbiConn.m_transactCpt = 0;
        }


        FREE(accessTab);
        FREE(processedOpTab);

        return(RET_SUCCEED);
    }

    /* Send the block of data (ExtOp, ExtPos, A_Notepad, A_EventSched) */
    ret = DBA_MultiAccess(accessTab,
                          idx,
                          maxRecInBuf,
                          DBA_SET_CONN|DBA_NO_CLOSE|DBA_OP_BLOCK|DBA_NO_ERROR,
						  dbiConn);

    switch (ret)
    {
    case RET_SUCCEED:

        if (localTran) /* DVP485 */
        {
            dbiConn.endTransaction(TRUE);
            dbiConn.m_transactCpt = 0;
        }

        break;

    default:      /* If an error occurs (Technical error, Business, Deadlock,...), operations are handled
                     using normal mode (single mode) */

        /* Rollback the transaction */   /* REF4001 - SSO - 991004 : if deadlock, it has been done by dataserver */
        DBA_FreeOperTabForBlockHandling(dbiConn, accessPtr, firstRec, opNbr,ret); /* SME Move C code */
        FREE(accessTab);
        FREE(processedOpTab);


        if (localTran
            && ret != RET_SRV_LIB_ERR_DEADLOCK
            && ret != RET_SRV_LIB_ERR_FATAL_DEADLOCK)
        {
            dbiConn.endTransaction(FALSE);
            dbiConn.m_transactCpt = 0;
        }

        /* BEWARE: The use of DBA_NO_ERROR flag must be combined with a transaction. */
        if ((localTran) && ((options & DBA_NO_ERROR) != DBA_NO_ERROR)
            && ret != RET_SRV_LIB_ERR_FATAL_DEADLOCK) /* REF4001 - SSO - 991004 don't use dead connexion */
        {
            dbiConn.m_lastResultRetCode = RET_SUCCEED;
            dbiConn.m_msgStructHeaderSt.clear();
            ret = DBA_HandleOperTab(dbiConn, accessPtr, processedOpTab, firstRec, opNbr, bStoreErrMsgInElt);
        }
        else
        {
            /* REF4001 - SSO - 991004 don't loose messages -> copy them! */
            /* REF4001 - SSO - 991011: if deadlock, build a single message for the whole block */
            if (ret == RET_SRV_LIB_ERR_FATAL_DEADLOCK)
            {
                DBA_ERRMSG_INFOS_ST &errMsgInfoSt = dbiConn.m_msgStructHeaderSt.getNewErrMsgInfoSt(FILEINFO);

                errMsgInfoSt.msgOrigin      = ServerHandler;
                errMsgInfoSt.rdbmsMsgNb     = -1;
                errMsgInfoSt.retCode        = RET_SRV_LIB_ERR_FATAL_DEADLOCK;
                errMsgInfoSt.serverName     = dbiConn.getSpecification().getServerName();
                SYS_StringFormat(errMsgInfoSt.msgString,  "Fatal Deadlock occurred in database, connection %d is dead", dbiConn.getId());
                errMsgInfoSt.rdbmsMsgString = errMsgInfoSt.msgString;

                errMsgInfoSt.firstInList = firstRec;
                errMsgInfoSt.lastInList = opNbr;
            }
        }

        dbiConn.getConnStructPtr()->blockMode = 0;/* REF3792 - SSO - 991207 */
        return(ret);
    }

    DBA_FreeOperTabForBlockHandling(dbiConn, accessPtr, firstRec, opNbr,ret);

    FREE(accessTab);
    FREE(processedOpTab);

    dbiConn.getConnStructPtr()->blockMode = 0;  /* REF3792 - SSO - 991207 */
    return(ret);
}




/************************************************************************
**
**  Function    :   DBA_AddElemToBlockModeSt()
**
**  Description :   add an element in a bloc mode structure
**
**  Arguments   :   action
                    role
                    object
                    dynSt
                    dynFldPtr
**
**
**  Return      :   RET_SUCCEED                 if ok
**
**  Creation    : REF11159-EFE-050509
**
*************************************************************************/
RET_CODE DBA_AddElemToBlockModeSt(DBA_ACTION_ENUM  action,
                                  int              role,
                                  OBJECT_ENUM      object,
                                  DBA_DYNST_ENUM   dynSt,
                                  DBA_DYNFLD_STP   dynFldPtr,
                                  DbiConnection&   dbiConn)
{

    RET_CODE ret_code = RET_SUCCEED;

    int curRec,curStep,extDataTabSize,extDataNbr;
    DBA_ACCESS_STP extDataTab;

	curRec  = dbiConn.getConnStructPtr()->blockModeExt.curRec;
    curStep =dbiConn.getConnStructPtr()->blockModeExt.curRecStep;

    extDataTab     =dbiConn.getConnStructPtr()->blockModeExt.recTab[curRec].stepData[curStep].extDataTab;
    extDataTabSize =dbiConn.getConnStructPtr()->blockModeExt.recTab[curRec].stepData[curStep].extDataTabSize;
    extDataNbr     =dbiConn.getConnStructPtr()->blockModeExt.recTab[curRec].stepData[curStep].extDataNbr;

    if (extDataTabSize == 0 || extDataNbr % extDataTabSize == 0)
    {
        extDataTab = SYS_ReallocInit(dbiConn.getConnStructPtr()->blockModeExt.recTab[curRec].stepData[curStep].extDataTab,
                                                     (size_t) extDataTabSize, (size_t) 10);
        extDataTabSize += 10;
        dbiConn.getConnStructPtr()->blockModeExt.recTab[curRec].stepData[curStep].extDataTabSize = extDataTabSize;

        if ( extDataTab == NULL )
        {
            ret_code = RET_MEM_ERR_ALLOC;
            MSG_SendMesg(RET_MEM_ERR_ALLOC, 2, FILEINFO, "DBA_ACCESS_STP");
        }
        else
        {
           dbiConn.getConnStructPtr()->blockModeExt.recTab[curRec].stepData[curStep].extDataTab = extDataTab;
        }
    }

    if ( ret_code == RET_SUCCEED )
    {
        extDataTab[extDataNbr].action = action;
        extDataTab[extDataNbr].role   = role;
        extDataTab[extDataNbr].object = object;
        extDataTab[extDataNbr].entity = dynSt;
        extDataTab[extDataNbr].data   = ALLOC_DYNST(dynSt);
        COPY_DYNST( extDataTab[extDataNbr].data, dynFldPtr, dynSt);

        extDataNbr++;
       dbiConn.getConnStructPtr()->blockModeExt.recTab[curRec].stepData[curStep].extDataNbr     = extDataNbr;
    }

    return ret_code ;

}

/************************************************************************
*   Function             : DbaMultiAccessHelper::callMultiAccess()
*
*   Description          : Call internal MultiAccess.
*
*   Arguments            : 
*                          
*
*   Return               : none
*
*   Creation Date        : DDV - 200317
*   Last Modification    :
*
*************************************************************************/
RET_CODE DbaMultiAccessHelper::callMultiAccess(int                   maxRecInBuf,
                                               int                   options,
                                               int *                 allocConn,
                                               bool                  bStoreErrMsgInElt)
{
    return(DBA_MultiAccessInternal(m_accessVector[0], m_accessTabSize, maxRecInBuf, options, allocConn, bStoreErrMsgInElt));
}

/************************************************************************
*   Function             : DbaMultiAccessHelper::callMultiAccess()
*
*   Description          : Call internal MultiAccess.
*
*   Arguments            :
*
*
*   Return               : none
*
*   Creation Date        : DDV - 200317
*   Last Modification    :
*
*************************************************************************/
RET_CODE DbaMultiAccessHelper::callMultiAccess(int                   maxRecInBuf,
                                               int                   options,
                                               DbiConnection&        dbiConn,
                                               bool                  bStoreErrMsgInElt)
{
    return(DBA_MultiAccessInternal(m_accessVector[0], m_accessTabSize, maxRecInBuf, options, dbiConn, bStoreErrMsgInElt));
}

/************************************************************************
 **   END  dbalib04.c                                                  **
 ************************************************************************/

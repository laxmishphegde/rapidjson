/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef DDLGENTRIGGER_H
#define DDLGENTRIGGER_H

/************************************************************************
**      Constant & Macro definitions
*************************************************************************/

/************************************************************************
**      Structures & typedef definitions
*************************************************************************/

/************************************************************************
**      External definitions attached to : ddlgentrigger.cpp
*************************************************************************/
class DdlGenFromFile;

class DdlGenTrigger:public DdlGen
{

public:
    // Constructors
    DdlGenTrigger(OBJECT_ENUM        paramObjectEn,
                  DDL_OBJ_ENUM       paramDdlObjEn,
                  DdlGenContext     &paramDdlGenContext,
                  DdlGenVarHelper   *paramVarHelperPtr,
                  DdlGenEntity      *paramDdlGenEntityPtr,
                  DdlGenFile        *paramFileHelper,
                  TARGET_TABLE_ENUM  paramTargetTableEn);

    DdlGenTrigger(DdlGenTrigger&) = delete;

    // Destructor
    virtual ~DdlGenTrigger();

    // Methods
    virtual RET_CODE          build();
    virtual RET_CODE          printHeader();
    virtual RET_CODE          printFooter();
    virtual RET_CODE          drop();
    virtual RET_CODE          grant();

    RET_CODE                  init(DML_EVENT_ENUM, EVENT_POS_ENUM, TRIGGER_POS_ENUM);

    RET_CODE                  pushBeforeStatement(std::string script, TRIGGER_POS_ENUM trgPosEn, DML_EVENT_ENUM dmlEventEn);
    RET_CODE                  pushBeforeEachRowStatement(std::string script, TRIGGER_POS_ENUM trgPosEn, DML_EVENT_ENUM dmlEventEn);
    RET_CODE                  pushAfterStatement(std::string script, TRIGGER_POS_ENUM trgPosEn, DML_EVENT_ENUM dmlEventEn);
    RET_CODE                  pushAfterEachRowStatement(std::string script, TRIGGER_POS_ENUM trgPosEn, DML_EVENT_ENUM dmlEventEn);

    DdlGenTrigger& operator = (const DdlGenTrigger&) = delete;

    DML_EVENT_ENUM            getCurrDmlEvent()
    {
        return this->currDmlEvent;
    }

    TRIGGER_POS_ENUM          getCurrTriggerPos()
    {
        return this->currTriggerPos;
    }

    std::map<DdlObjDefKey, DdlObjDef> &getAllDbTrigger();

protected:

    // Methods
    RET_CODE printBody();

    RET_CODE fillDdlGenSqlBlock(DdlGenSqlBlock &inputDdlGenSqlBlock, DdlGenSqlBlock &outputDdlGenSqlBlock, bool bNotBody = false);

    RET_CODE printForEachRowStatement(std::stringstream &eachRowBeforeStream,
                                      std::stringstream &eachRowAfterStream,
                                      std::stringstream &outStream,
                                      TRIGGER_POS_ENUM  triggerPos);
    RET_CODE treatNewOldVariable(TRIGGER_POS_ENUM  triggerPos,
                                 std::string &stringToTreat,
                                 std::stringstream &selectStream,
                                 std::stringstream &assignStream,
                                 std::set<std::string> &cursorDelcareSet,
                                 bool &bFirst,
                                 bool &bNew,
                                 bool &bOld);

    RET_CODE printBeforeStatement();
    RET_CODE printBeforeEachRowStatement();
    RET_CODE printAfterEachRowStatement();
    RET_CODE printAfterStatement();

    RET_CODE printDeclareVariables();

    RET_CODE initCheckSecurityAndFk();

    RET_CODE printObjectModifStat();
    RET_CODE initTableModifStat(); /* PMSTA-15962 - LJE - 130225 */
    RET_CODE initUdFieldsManagment();      /* PMSTA-14452 - LJE - 121102 */
    RET_CODE initChangeSetManagement();     /* PMSTA-26250 - LJE - 170424 */
    RET_CODE initRootManagment();          /* PMSTA-21197 - LJE - 160415 */
    RET_CODE releaseRootManagment();       /* PMSTA-21197 - LJE - 160415 */
    RET_CODE initCascadeDelRef();
    RET_CODE initDeleteRule(DICT_ENTITY_STP entityStp, DICT_ATTRIB_STP attribStp, bool bForceCascadeOnTrigger);

    void     setRootEntityManagementNeeded();

    RET_CODE create();

    RET_CODE setName();

    std::string                                   getCurrModifDate(DdlGenVarHelper  *targetVarHelperPtr);
    std::string                                   getCurrUser(DdlGenVarHelper  *targetVarHelperPtr);
	DICT_T                                        getTableModifStatEntityDictId();   /* PMSTA-23300 - TEB - 160622 */

    DML_EVENT_ENUM                                currDmlEvent;
    EVENT_POS_ENUM                                currEventPos;
    TRIGGER_POS_ENUM                              currTriggerPos;
    bool                                          bUdTableTrig;

    DdlGenSqlBlock                                beforeStreamTab[TriggerPos_Last][DmlEvent_Last];
    DdlGenVarHelper*                              beforeVarTab[TriggerPos_Last][DmlEvent_Last];
                                                  
    std::stringstream                             beforeEachRowStreamTab[TriggerPos_Last][DmlEvent_Last];
    DdlGenVarHelper*                              beforeEachRowVarTab[TriggerPos_Last][DmlEvent_Last];
                                                  
    std::stringstream                             afterEachRowStreamTab[TriggerPos_Last][DmlEvent_Last];
    DdlGenVarHelper*                              afterEachRowVarTab[TriggerPos_Last][DmlEvent_Last];
                                                  
    DdlGenSqlBlock                                afterStreamTab[TriggerPos_Last][DmlEvent_Last];
    DdlGenVarHelper*                              afterVarTab[TriggerPos_Last][DmlEvent_Last];

    std::stringstream                             discardTriggerTab[TriggerPos_Last][DmlEvent_Last];

    DdlGenSqlBlock                                initVarSqlBlock;

    DdlGenSqlBlock                                m_beforeStream;
    DdlGenSqlBlock                                m_afterEachRowStream;
    DdlGenSqlBlock                                m_beforeEachRowStream;
    DdlGenSqlBlock                                m_afterStream;

    bool                                          bTblModifStat;
    bool                                          bObjModifStatPrinted;

    DICT_T                                        entityDictId;
    DICT_T                                        emptyDictId;

    std::map<DdlObjDefKey, DdlObjDef>             m_allDbTriggerMap;
    std::set<DDL_OBJ_ENUM>                        m_dbTriggerLoadSet;

private:

    bool                                          attribToCheck(DICT_ATTRIB_STP attribStp);

    bool                                          m_bIsInitPrinted; /* PMSTA-26250 - LJE - 170530 */
    DDL_OBJ_ENUM                                  m_scptDllObjEn;
};

typedef std::unique_ptr<DdlGenTrigger> DdlGenTriggerPtr;

#endif	                               /* ifndef DDLGENTRIGGER_H */
/************************************************************************
**      END       ddlgentrigger.h                                   Odyssey
*************************************************************************/

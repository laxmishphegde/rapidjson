/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DICTFILE_C

/************************************************************************
**      Include files
*************************************************************************/
#define STRING_H	/* Necessary for memcpy & strcpy */
#include "unidef.h"     /* Mandatory */

#ifdef NT
#include <windows.h>
#include <winbase.h>
#include <stdlib.h>
#else
#include <sys/stat.h> /* DLA - REF11241 - 050719 */
#endif

#include "syslib.h"     /* Necessary for FREE  PMO - Rename our sys.h to syslib.h and use it */
#include "gen.h"
#include "dba.h"
#include "tls.h"

#ifdef __alpha
#define META_ARCH 'A'
#else
#define META_ARCH 'I'
#endif

struct MetaHeaderFile {
    unsigned char md5sum[16];
    SYSNAME_T dbName;
    unsigned char arch;
    DATETIME_T date;
    int offset[6];
    int number[6];
};

/* PMSTA-9107 - 141209 - PMO */
#if (defined UNIX || defined INCGNU /* PMSTA-10061 - 090610 - PMO */ )

#ifndef _MAX_PATH
#define _MAX_PATH   260 /* max. length of full pathname */
#endif

#ifndef _MAX_FNAME
#define _MAX_FNAME  256 /* max. length of file name component */
#endif

#endif


/************************************************************************
**
**  Function    :  DBA_MDLoadFile
**
**  Description :  Load Metat Dict from a file in one memory buffer
**                 and verify if checksum is good
**
**  Arguments   :  szFileName: name of the Meta. Dict. file
**                 buffMD : Meta Dict. buffer returned by this function
**                          (buffer allocated by this function)
**
**  Remark      :  buffMD: Must be free by the caller
**
**  Return      :  RET_DBA_ERR_MD_CHECKSUM_FAILED
**                 RET_FILE_ERR_NOTEXIST (file doesn't exist)
**                 RET_DBA_ERR_MD_READ_FILE_FAILED
**                 RET_MEM_ERR_ALLOC
**                 RET_SUCCEED
**
**  Creation    :  SME 05/01/1999
**  Last modif. :  REF7264 - 011212 - PMO : Compilation errors and warnings with C++ compiler
**                 PMSTA-13729 - 040412 - PMO : Full support of 64bit on Unix platforms
**
*************************************************************************/
RET_CODE DBA_MDLoadFile(char *szFileName,unsigned char **buffMD)
{
    struct MD5Context md5ctx;
    struct MetaHeaderFile *metaHead;
    int sizeFile;
    FILEDES hFile;       /* PMSTA-13729 - 040412 - PMO */
    unsigned char md5sum[16];
    RET_CODE ret;

    *buffMD = NULL;

    do
    {
	ret = SYS_OpenFile(szFileName,
			   OPEN_READ_MODE|
			   OPEN_EXISTING_FILE|
			   OPEN_SHARE_READ,
			   &hFile);

    } while (ret == RET_SYS_OPEN_SHARING_VIOLATION);

    if (ret != RET_SUCCEED)
    {
	/* error in open file */
	return(RET_FILE_ERR_NOTEXIST);
    }

    SYS_GetFileSize(hFile,&sizeFile);

    if (sizeFile == 0)
    {
	/* error in open file */
	SYS_CloseFile(hFile);
	return(RET_FILE_ERR_NOTEXIST);
    }

    if ((*buffMD = (unsigned char*) CALLOC(sizeFile, sizeof(char))) == NULL)    /* REF7264 - PMO */
    {
	SYS_CloseFile(hFile);
	return(RET_MEM_ERR_ALLOC);
    }

    if (RET_SUCCEED != SYS_ReadFile(hFile,*buffMD,sizeFile))
    {
	SYS_CloseFile(hFile);
	FREE(*buffMD);
	return(RET_DBA_ERR_MD_READ_FILE_FAILED);
    }

    SYS_CloseFile(hFile);

    metaHead = (struct MetaHeaderFile *)*buffMD;

    if ( metaHead->arch != META_ARCH)
    {
	FREE(*buffMD);
	return(RET_DBA_ERR_MD_CHECKSUM_FAILED);
    }

    /* CALCULATE CHEKCSUM */

    TLS_MD5Init(&md5ctx,0);
    TLS_MD5Update(&md5ctx,*buffMD + 16,sizeFile - 16); /* skip checksum key */
    TLS_MD5Final(md5sum,&md5ctx);

    if (memcmp(md5sum,metaHead->md5sum,16))
    {
	/* checksum error, file is corrupted  */

	FREE(*buffMD);
	return(RET_DBA_ERR_MD_CHECKSUM_FAILED);
    }

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :  DBA_MDCheckDate
**
**  Description :  Verify if file meta.  dict. is older than data base
**
**  Arguments   : buffMD : Meta Dict. buffer
**
**  Return      :  RET_DBA_INFO_MD_FILE_TOO_OLD
**                 RET_SUCCEED
**
**  Creation    :  SME 05/01/1999
**
*************************************************************************/
RET_CODE DBA_MDCheckDate(unsigned char *buffMD)
{
    DBA_DYNFLD_STP *tabModifStatPtr;
    int tabModifStatNbr,i;
    RET_CODE ret;
    struct MetaHeaderFile *metaHead;
    std::string      dbName;

    metaHead = (struct MetaHeaderFile *)buffMD;

    GEN_GetApplInfo(ApplSqlDbName, dbName);
    if (strcmp(dbName.c_str(), metaHead->dbName) != 0)
        return(RET_DBA_ERR_MD_WRONG_DB);

    ret = DBA_Select2(TabModifStat, UNUSED, NullDynSt, NULL,
		      A_TabModifStat, &tabModifStatPtr,
		      UNUSED, UNUSED, &tabModifStatNbr, UNUSED, UNUSED);

    if (ret != RET_SUCCEED)
    {
	return(ret);
    }

    for (i=0; i < tabModifStatNbr;i++)
    {
	/* test in hard , because SV_DictAttribTab no initialise  */
	switch(GET_DICT(tabModifStatPtr[i],A_TabModifStat_DictId))
	{
	case 1101: /* DictEntity */
	case 1103: /* DictAttr */
	case 1102: /* DictCriter */
	case 1105: /* DictPermVal */
	case 1106: /* DictLang */
	case 1100: /* DictDataTp */
	case 1104: /* DictLabel */
	    if (DATETIME_CMP(GET_DATETIME(tabModifStatPtr[i],A_TabModifStat_LastModifDate),
		metaHead->date) > 0)
	    {
		/* meta. file is older than Database */
		DBA_FreeDynStTab(tabModifStatPtr, tabModifStatNbr, A_TabModifStat);
		return(RET_DBA_INFO_MD_FILE_TOO_OLD);
	    }
	}
    }

    DBA_FreeDynStTab(tabModifStatPtr, tabModifStatNbr, A_TabModifStat);

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :  DBA_MDReadSize
**
**  Description :  Read rows number of each table (from Meta Dict. buffer)
**
**  Arguments   : buffMD : Meta Dict. buffer
**                dictEntityRows: dict. entity number
**	          dictAttribRows: dict. attrib number
**	          dictCriterRows  dict. criteria number
**	          dictPermValRows: dict. permited values number
**	          dictLangRows: dict. lang number
**	          dictDataTpRows: dict. data tp number
**	          dictFctRows: dict. function number
**
**  Return      : RET_SUCCEED
**
**  Creation    :  SME 05/01/1999
**
*************************************************************************/
RET_CODE DBA_MDReadSize(unsigned char *buffMD,
                        int *dictEntityRows,
                        int *dictAttribRows,
                        int *dictCriterRows,
                        int *dictPermValRows,
                        int *dictLangRows,
                        int *dictDataTpRows)
{
    struct MetaHeaderFile *metaHead;

    metaHead = (struct MetaHeaderFile *)buffMD;

    *dictEntityRows = metaHead->number[0];
    *dictAttribRows = metaHead->number[1];
    *dictCriterRows = metaHead->number[2];
    *dictPermValRows = metaHead->number[3];
    *dictLangRows = metaHead->number[4];
    *dictDataTpRows = metaHead->number[5];

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :  DBA_MDReadBlock
**
**  Description :  Split Meta File in different buffer
**
**  Arguments   : buffMD : Meta Dict. buffer
**
**                dictEntityTab
**		  dictAttribTab
**		  dictCriterTab
**		  dictPermValTab
**		  dictLangTab
**		  dictDataTpTab
**  Return      : RET_SUCCEED
**
**  Creation    :  SME 05/01/1999
**
*************************************************************************/
RET_CODE DBA_MDReadBlock(unsigned char *buffMD,
                         DICT_LANG_STP dictLangTab,
                         DICT_DATATP_STP dictDataTpTab)
{
    struct MetaHeaderFile *metaHead;

    metaHead = (struct MetaHeaderFile *)buffMD;
    /*
    memcpy(dictEntityTab,buffMD+metaHead->offset[0],metaHead->number[0] * sizeof(DICT_ENTITY_ST));
    memcpy(dictPermValTab,buffMD+metaHead->offset[3],metaHead->number[3] * sizeof(DICT_PERM_VAL_ST));
    */
    memcpy(dictLangTab,buffMD+metaHead->offset[4],metaHead->number[4] * sizeof(DICT_LANG_ST));
    memcpy(dictDataTpTab,buffMD+metaHead->offset[5],metaHead->number[5] * sizeof(DICT_DATATP_ST));
    return(RET_SUCCEED);
}


/************************************************************************
**
**  Function    :  DBA_MDOpenWriteFile
**
**  Description :  Open meta. dict. file in writing mode
**
**  Arguments   : szFileName: file name of meta. dict. (8 chars for the name and 3 for extension)
**
**  Return      : RET_DBA_ERR_MD_WRITE_BY_ANOTHER_PROC
**                RET_DBA_ERR_MD_READ_BY_ANOTHER_PROC
**                RET_DBA_ERR_MD_CREATE_FILE_FAILED
**                RET_SUCCEED
**
**  Creation    :  SME 05/01/1999
**
**  Last modif. : PMSTA-13729 - 040412 - PMO : Full support of 64bit on Unix platforms
**                PMSTA-16124 - 250413 - PMO : Ensure coherence of printf / scanf formats with 32bits / 64 bits datatypes
**
*************************************************************************/

RET_CODE DBA_MDOpenWriteFile(char *szFileName,FILEDES *hFile)     /* PMSTA-13729 - 040412 - PMO */
{
/* #ifdef NT  DLA - REF11241 - 050622 */
    char szFileNameLck[_MAX_PATH+_MAX_FNAME];
    FILEDES hFileLck;          /* PMSTA-13729 - 040412 - PMO */
    RET_CODE ret,ret2;

    /* replace extension */
    sprintf(szFileNameLck,"%.*slck",SYS_StrLen(szFileName) - 2,szFileName);         /* PMSTA-16124 - 250413 - PMO */

    do
    {
	ret = SYS_OpenFile(szFileName,
			   OPEN_WRITE_MODE|
			   OPEN_CREATE_FILE|
			   OPEN_EXCLUSIVE_WRITE,
			   hFile);

	if (ret == RET_SYS_OPEN_SHARING_VIOLATION)
	{
	    ret2 = SYS_OpenFile(szFileNameLck,
				OPEN_READ_MODE|
				OPEN_EXISTING_FILE,
				&hFileLck);
	    if (ret2 == RET_SUCCEED)
	    {
		/* file open in write mode by another GUI */
		SYS_CloseFile(hFileLck);
		return(RET_DBA_INFO_MD_UPD_IN_PROGRESS);
	    }
	    /* File does not exist => another gui has opened meta file in read mode */
	    /* retry open file in write mode */
	}
    }while(ret == RET_SYS_OPEN_SHARING_VIOLATION);

    if (ret != RET_SUCCEED)
    {
	/* error in open file */
	return(RET_DBA_ERR_MD_WRITE_FILE_FAILED);
    }

    ret = SYS_OpenFile(szFileNameLck,
		       OPEN_WRITE_MODE|
		       OPEN_CREATE_FILE,
		       &hFileLck);

    if (ret != RET_SUCCEED)
	return(ret);

    SYS_CloseFile(hFileLck);

/* #endif  DLA - REF11241 - 050622 */

    return(RET_SUCCEED);
}


/************************************************************************
**
**  Function    :  DBA_MDCloseWriteFile
**
**  Description :  Close file in writing mode (close handle and delete file name for locking)
**
**  Arguments   : None
**
**  Return      : None
**
**  Creation    :  SME 05/01/1999
**
**  Last modif. : PMSTA-13729 - 040412 - PMO : Full support of 64bit on Unix platforms
**                PMSTA-16124 - 250413 - PMO : Ensure coherence of printf / scanf formats with 32bits / 64 bits datatypes*
*
*************************************************************************/
void DBA_MDCloseWriteFile(char *szFileName,FILEDES hFile)
{
/* #ifdef NT  DLA - REF11241 - 050622 */
    char szFileNameLck[_MAX_PATH+_MAX_FNAME];
    /* replace extension */
    sprintf(szFileNameLck,"%.*slck", SYS_StrLen(szFileName) - 2,szFileName);                /* PMSTA-16124 - 250413 - PMO */
    SYS_CloseFile(hFile);
    SYS_DeleteFile(szFileNameLck);
#ifdef UNIX /* DLA - REF11241 - 050719 */
    chmod(szFileName, S_IROTH | S_IWOTH | S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP);
#endif
/* #endif  DLA - REF11241 - 050622 */
}

/************************************************************************
**
**  Function    :  DBA_MDWriteFile
**
**  Description :  Dump Meta dict in file
**
**  Arguments   : None
**
**  Return      : RET_SUCCEED
**                RET_MEM_ERR_ALLOC
**                RET_DBA_ERR_MD_WRITE_FILE_FAILED
**
**  Creation    :  SME 05/01/1999
**  Last modif. : REF7264 - 011212 - PMO : Compilation errors and warnings with C++ compiler
**                PMSTA-13729 - 040412 - PMO : Full support of 64bit on Unix platforms
**
*************************************************************************/
RET_CODE DBA_MDWriteFile(
			 DICT_LANG_STP dictLangTab,
			 DICT_DATATP_STP dictDataTpTab,
			 int dictLangRows,
			 int dictDataTpRows,
			 FILEDES hFile)

{
/* #ifdef NT  DLA - REF11241 - 050622 */
    int sizeFile;
    unsigned char *buffer;
    struct MD5Context md5ctx;
    struct MetaHeaderFile *metaHead;
    std::string      dbName;

    /* allocate memory for checksum */
    sizeFile =
	(dictLangRows * sizeof(DICT_LANG_ST)) +
	(dictDataTpRows * sizeof(DICT_DATATP_ST));

    sizeFile += sizeof(struct MetaHeaderFile);


    if (NULL == (buffer = (unsigned char *) CALLOC(sizeFile, sizeof(char))))/* REF7264 - PMO */
    {
        return(RET_MEM_ERR_ALLOC);
    }

    metaHead = (struct MetaHeaderFile *)buffer;

    GEN_GetApplInfo(ApplSqlDbName, dbName);

    metaHead->arch = META_ARCH;
    strcpy(metaHead->dbName, dbName.c_str());
    metaHead->offset[0] = sizeof(struct MetaHeaderFile);
    /*
    metaHead->number[0] = dictEntityRows ;
    metaHead->offset[1] = metaHead->offset[0] + (dictEntityRows * sizeof(DICT_ENTITY_ST));
    metaHead->number[1] = dictAttribRows;
    metaHead->offset[2] = metaHead->offset[1] + (dictAttribRows * sizeof(DICT_ATTRIB_ST));
    metaHead->number[2] = dictCriterRows;
    metaHead->offset[3] = metaHead->offset[2] + (dictCriterRows * sizeof(DICT_CRITER_ST));
    metaHead->number[3] = dictPermValRows;
    metaHead->offset[4] = metaHead->offset[3] + (dictPermValRows * sizeof(DICT_PERM_VAL_ST));
    */
    metaHead->number[4] = dictLangRows;
    metaHead->offset[5] = metaHead->offset[4] + (dictLangRows * sizeof(DICT_LANG_ST));
    metaHead->number[5] = dictDataTpRows;

    /* get date the from data base */
    DBA_GetDbDate(&(metaHead->date));

    /*
    memcpy(buffer+metaHead->offset[0],dictEntityTab,metaHead->number[0] * sizeof(DICT_ENTITY_ST));
    memcpy(buffer+metaHead->offset[1],dictAttribTab,metaHead->number[1] * sizeof(DICT_ATTRIB_ST));
    memcpy(buffer+metaHead->offset[2],dictCriterTab,metaHead->number[2] * sizeof(DICT_CRITER_ST));
    memcpy(buffer+metaHead->offset[3],dictPermValTab,metaHead->number[3] * sizeof(DICT_PERM_VAL_ST));
    */
    memcpy(buffer + metaHead->offset[4], dictLangTab, metaHead->number[4] * sizeof(DICT_LANG_ST));
    memcpy(buffer+metaHead->offset[5],dictDataTpTab,metaHead->number[5] * sizeof(DICT_DATATP_ST));

    /* CALCULATE CHEKCSUM */

    TLS_MD5Init(&md5ctx,0);
    TLS_MD5Update(&md5ctx,buffer+16,sizeFile - 16);
    TLS_MD5Final(metaHead->md5sum,&md5ctx);

    if (RET_SUCCEED != SYS_WriteFile(hFile,buffer,sizeFile))
    {
	FREE(buffer);
	return(RET_DBA_ERR_MD_WRITE_FILE_FAILED);
    }

    FREE(buffer);
/* #endif  DLA - REF11241 - 050622 */
    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    : DBA_GetMDFileName
**
**  Description : Get the name of file to use for the user
**
**  Arguments   : None
**
**  Return      : RET_SUCCEED
**
**  Creation    : DDV - REF2744 - 990209
**
*************************************************************************/
RET_CODE DBA_GetMDFileName(char *fileName)
{
    /*  HFI-PMSTA-22481-160216  AAAMDPATH Functionnality deactivated (short term)   */
	return(RET_ENV_ERR_VARUNDEF);
#ifdef PMSTA22481   /*  HFI-PMSTA-22481-160216  */
	DICT_T	       langDictId = (DICT_T) 0;
	DBA_DYNFLD_STP sDictLang = NULLDYNST;
	RET_CODE       ret;
	char           *envMDPath, *filePath;

	/* Load from file only for GUI and Import module */
	if (SYS_IsGuiMode() == FALSE && SYS_IsBatchMode() == FALSE) /* DLA - REF12241 - 050610 */
		return(RET_ENV_ERR_VARUNDEF);

	/* if ((homePath = SYS_GetEnv("AAAHOME")) == NULLSTR)
		return(RET_ENV_ERR_VARUNDEF); DDV - 990224 - file path is no more relative to AAAHOME */

	if ((envMDPath = SYS_GetEnv("AAAMDPATH")) == NULLSTR)
		return(RET_ENV_ERR_VARUNDEF);

	if (strlen(envMDPath) < 3 || strncasecmp(envMDPath, "yes,",3) != 0)
		return(RET_ENV_ERR_VARUNDEF);

	if ((sDictLang = ALLOC_DYNST(S_DictLang)) == NULLDYNST)
	{
		MSG_RETURN(RET_MEM_ERR_ALLOC);
	}

	GEN_GetUserInfo(UserLanguage, &langDictId);
	SET_DICT(sDictLang, S_DictLang_Id, langDictId);

	if ((ret = DBA_Get2(DictLang, UNUSED, S_DictLang, sDictLang,
                            S_DictLang, &sDictLang, UNUSED, UNUSED, UNUSED)) != RET_SUCCEED)
	{
		FREE_DYNST(sDictLang, S_DictLang);
		return(ret);
	}

	/* supress spaces before path */
	filePath = envMDPath+4;
	while (*filePath != END_OF_STRING && *filePath == ' ')
		filePath++;

	/*strcpy(fileName, homePath);
	strcat(fileName, "\\"); DDV - 990224 - file path is no more relative to AAAHOME */
	strcat(fileName, filePath);
#ifdef NT /* DLA - REF11241 - 050622 */
	strcat(fileName, "\\");
#else
	strcat(fileName, "/");
#endif
	strcat(fileName, GET_CODE(sDictLang, S_DictLang_Cd));
	strcat(fileName, ".MD");

	FREE_DYNST(sDictLang, S_DictLang);
	return(RET_SUCCEED);
#endif          /*  HFI-PMSTA-22481-160216  */
}

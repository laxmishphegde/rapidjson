/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef DbiSqlExecByBlock_H_
#define DbiSqlExecByBlock_H_

#include "unidef.h"
#include "gen.h"
#include "dba.h"

/* PMSTA-20159 - TEB - 151110 */
class DbiSqlExecByBlock
{
public:
	DbiSqlExecByBlock();
	DbiSqlExecByBlock(int blockSize);
	virtual ~DbiSqlExecByBlock();

    DbiSqlExecByBlock(const DbiSqlExecByBlock &) = delete;
    DbiSqlExecByBlock & operator=(const DbiSqlExecByBlock &) = delete;

	void addSql(const std::string & vSqlCmd);

	std::string getNextSqlBlock(int blockSize);

	int getSize();

	int getBlockSize(void);

	void setBlockSize(int bs);

	RET_CODE execSqlExecByBloc(void);

	RET_CODE execSqlExecByBloc(int noConnect);

	RET_CODE execSqlExecByBloc(DbiConnection* dbiCon);

	RET_CODE execSqlExecByBloc(DbiConnection* dbiCon, std::string* executedString);

private:
	std::queue<std::string>   sqlCmdList;

	int blockSize;

	DbiConnection* getConnection(void);

	DbiConnection* getConnection(int noConnect);
};


#endif

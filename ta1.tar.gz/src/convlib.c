/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines      
*************************************************************************/
#define CONVLIB_C


/************************************************************************
**      Include files
*************************************************************************/
#ifdef AIX
#include <math.h>
#else
#include <cmath>
#endif

#define STDIO_H
#define CTYPE_H
#define TIME_H
#define STDLIB_H
#define STRING_H
#define MATH_H
#define LIMITS_H
#include "unicode/ucnv.h"
#include "unidef.h"     /* Mandatory */
#include "conv.h"     
#include "date.h"
#include "syslib.h"     /* Necessary for FREE  PMO - Rename our sys.h to syslib.h and use it */
#include "dba.h"
#include "tls.h"
#include "gen.h"
#include "icu4aaa.h"
#include "icu4aaadate.h"
#include "ddlgenmsg.h"

/************************************************************************
**      External entry points
**
**  CONV_InitConvFmtPtr() Initialize EV_ConvFmtPtr on table SV_ConvFmtTab 
*************************************************************************/

/************************************************************************
**      Local functions
**
*************************************************************************/

/************************************************************************
**      Static definitions & data
*************************************************************************/

#define THOUSAND_SEP ','
#define DECIMAL_SEP  '.'
#define MAND_SIGNE   '+'
#define NBR_STR      "0123456789-"
#define NBR_SIGNIF   "123456789"
#define NBR_DATETIME "0123456789"

#define GET_NULL_STRING()   SV_NullString
static char SV_NullString[] ="n/a";

/* PMSTA-42593 - DPT - 210218 - Begin*/

extern bool EV_EnableMicrosecTime;

static RET_CODE convGenToDateTimeDelimFmt(char *, char *);
static RET_CODE convDateTimeDelimToGenFmt(FLAG_T *, char *);

RET_CODE fetchMicrosecsFromDatetimeStr(const char*, MICROSECOND_T *);
RET_CODE populateMicrosecondsIntoDateTimeStr(DATETIME_ST, char*, char*);

/* PMSTA-42593 - DPT - 210218 - End*/



CONVFMT_ST SV_ConvFmtTab[] =
{
/*****************************************************************************
** src,             dest,         padType,   maskPtr,   special,    SYS_StrLen 
**                                                       separator  : # space . , '
**                                                       comma      : # . ,
**                                                       mand_sign_flag : 0 1
** special not use
******************************************************************************/

 /* AmountFmt */
 { DoubleCType,     CharPtrCType, RightPad,  "99,999,999,999,999,999,999.99", ".,0",  UNUSED},

 /* AmountEFmt */
 { DoubleCType,     CharPtrCType, LeftPad,   "99999999999999999999.00",     "#.0",  UNUSED},

 /* CodeFmt */
 { CharPtrCType,    CharPtrCType, LeftPad,   "",                  UNUSED, CODE_T_LEN}, 

 /* DateFmt */
 { DateTimeStCType,      CharPtrCType, LeftPad,   "DD/MM/YYYY",            "/",    UNUSED},         /*  FPL-PMSTA11054-101202 replace UIntCType to be syncr with SV_DataTypeTab    */

 /* DateTimeFmt */
 { DateTimeStCType, CharPtrCType, LeftPad,   "DD/MM/YYYY",            "/",    UNUSED},

 /* DictFmt */
 { LongLongCType,      CharPtrCType, RightPad,  "999999999",             UNUSED, UNUSED},           /*  FPL-PMSTA11054-101202 replace ShortCType to be syncr with SV_DataTypeTab    */

 /* EnumFmt */
 { UCharCType,      CharPtrCType, RightPad,  "999",                   UNUSED,  UNUSED}, /* REF9789 - LJE - 031230 */

 /* ExchangeFmt */
 { DoubleCType,     CharPtrCType, RightPad,  "999999999.00000000000000",   ".,0",  UNUSED},

 /* ExchangeEFmt */
 { DoubleCType,     CharPtrCType, LeftPad,   "999999999.00000000000000",   "#.0",  UNUSED},

 /* FlagFmt */
 { UCharCType,      CharPtrCType, LeftPad,   "9",                     UNUSED,  UNUSED},

 /* IdFmt */
 { LongLongCType,   CharPtrCType, RightPad,  "99999999999999999999",  UNUSED, UNUSED},

 /* InfoFmt */
 { CharPtrCType,    CharPtrCType, LeftPad,   "",                  UNUSED, INFO_T_LEN},

/* IntFmt */
 { IntCType,       CharPtrCType, RightPad,  "9999999999",            "##0",  UNUSED},

 /* LongAmountFmt */	/* DVP041 - 960429 - DED */
 { DoubleCType,     CharPtrCType, RightPad,  "99,999,999,999,999,999,999.990000000", ".,0",  UNUSED}, /* DLA - PMSTA08236 - 090515 - change LONGAMOUNT_T from 21.7 to 23.9 as database definition */

 /* LongAmountEFmt */	/* DVP041 - 960429 - DED */
 { DoubleCType,     CharPtrCType, LeftPad,   "99999999999999999999.000000000",     "#.0",  UNUSED}, /* DLA - PMSTA08236 - 090515 - change LONGAMOUNT_T from 21.7 to 23.9 as database definition */

 /* LongnameFmt */
 { CharPtrCType,    CharPtrCType, LeftPad,   "",                  UNUSED, LONGNAME_T_LEN}, 

 /* MaskFmt */
 { IntCType,       CharPtrCType, RightPad,  "9999999999",            "##0",  UNUSED}, /* REF4644 - DDV  - 000502 */
 
  /* MethodFmt */
 { UCharCType,      CharPtrCType, LeftPad,   "999",                   "##0",  UNUSED}, 

 /* NameFmt */
 { CharPtrCType,    CharPtrCType, LeftPad,   "",                  UNUSED, NAME_T_LEN},  

 /* NoteFmt */
 { CharPtrCType,    CharPtrCType, LeftPad,   "",                  UNUSED, NOTE_T_LEN},  

 /* NumberFmt */
 { DoubleCType,     CharPtrCType, RightPad,  "99,999,999,999,999,999,999.000000000", ".,0", UNUSED}, /* EFE-PMSTA-30850-20180405 */

 /* NumberEFmt */
 { DoubleCType,     CharPtrCType, LeftPad,   "99999999999999999999.000000000",    "#.0", UNUSED}, /* EFE-PMSTA-30850-20180405 */

 /* PercentFmt */
 { DoubleCType,     CharPtrCType, RightPad,  "9999.00000",            "#,0",  UNUSED},

 /* PercentEFmt */
 { DoubleCType,     CharPtrCType, LeftPad,   "9999.00000",            "#.0",  UNUSED},

 /* PeriodFmt */
 { ShortCType,      CharPtrCType, RightPad,  "99999",                 "##0",   UNUSED},

 /* PhoneFmt */
 { CharPtrCType,    CharPtrCType, LeftPad,   "",                  UNUSED, PHONE_T_LEN},
 
 /* PriceFmt */
 { DoubleCType,     CharPtrCType, RightPad,  "999,999,999.0000000000000", ".,0", UNUSED}, /* PMSTA-41768 - JPR - 201006 */

 /* PriceEFmt */
 { DoubleCType,     CharPtrCType, LeftPad,   "999999999.0000000000000",    "#.0", UNUSED}, /* PMSTA-41768 - JPR - 201006 */

 /* ShortinfoFmt */
 { CharPtrCType,    CharPtrCType, LeftPad,   "",                  UNUSED, SHORTINFO_T_LEN},

 /* SmallintFmt */
 { ShortCType,      CharPtrCType, RightPad,  "99999",                 "##0",  UNUSED},

 /* SmallintEFmt */
 { ShortCType,      CharPtrCType, LeftPad,   "99999",                 "##0",  UNUSED},

 /* SysnameFmt */
 { CharPtrCType,    CharPtrCType, LeftPad,   "",                  UNUSED, SYSNAME_T_LEN},

 /* TextFmt */
 { TextPtrCType,    CharPtrCType, LeftPad,   "",                  UNUSED, TEXT_T_LEN},	/* REF4204 */

 /* TimeFmt */
 { UIntCType,      CharPtrCType, LeftPad,   "HH:II:SS",              ":",    UNUSED},

 /* TinyintFmt */
 { UCharCType,      CharPtrCType, LeftPad,   "999",                   "##0",  UNUSED},

 /* YearFmt */
 { UShortCType,     CharPtrCType, LeftPad,   "YYYY",                  UNUSED, UNUSED} ,

 /* LongStringFmt */
 { CharPtrCType,    CharPtrCType, DfltPad,   "",                  UNUSED, LONGSTRING_T_LEN}, /* REF1229 / REF7264 - PMO */

 /* BlobFmt */
 { IntCType,       CharPtrCType, RightPad,  "",                  UNUSED, 10},              /*  FIH-REF8832-030310  */

 /* LongintFmt */
 { IntCType, CharPtrCType, RightPad,        "999999999",              UNUSED, UNUSED},              /*  FIH-REF8832-030310  */

 /* UrlFmt */
 { CharPtrCType,    CharPtrCType, LeftPad,   "",                  UNUSED, URL_T_LEN},      /*  FIH-REF8832-030310  */

 /* PtrFmt */
 { PtrCType,        PtrCType,     LeftPad,   "",                  UNUSED, TEXT_T_LEN},      /*  FIH-REF9089-030513  */

 /* UniCodeFmt          */  /*  PCL-REF9303-030724  */
 { UniCharPtrCType, CharPtrCType, LeftPad,   "",                  UNUSED, CODE_T_LEN},

 /* UniInfoFmt          */  /*  PCL-REF9303-030724  */
 { UniCharPtrCType, CharPtrCType, LeftPad,   "",                  UNUSED, INFO_T_LEN},

 /* UniLongnameFmt      */  /*  PCL-REF9303-030724  */
 { UniCharPtrCType, CharPtrCType, LeftPad,   "",                  UNUSED, LONGNAME_T_LEN},

 /* UniNameFmt          */  /*  PCL-REF9303-030724  */
 { UniCharPtrCType, CharPtrCType, LeftPad,   "",                  UNUSED, NAME_T_LEN},

 /* UniNoteFmt          */  /*  PCL-REF9303-030724  */
 { UniCharPtrCType, CharPtrCType, LeftPad,   "",                  UNUSED, NOTE_T_LEN},

 /* UniPhoneFmt         */  /*  PCL-REF9303-030724  */
 { UniCharPtrCType, CharPtrCType, LeftPad,   "",                  UNUSED, PHONE_T_LEN},

 /* UniShortinfoFmt     */  /*  PCL-REF9303-030724  */
 { UniCharPtrCType, CharPtrCType, LeftPad,   "",                  UNUSED, SHORTINFO_T_LEN},

 /* UniSysnameFmt       */  /*  PCL-REF9303-030724  */
 { UniCharPtrCType, CharPtrCType, LeftPad,   "",                  UNUSED, SYSNAME_T_LEN},

 /* UniTextFmt          */  /*  PCL-REF9303-030724  */
 { UniTextPtrCType, CharPtrCType, LeftPad,   "",                  UNUSED, TEXT_T_LEN},

 /* UniUrlFmt           */  /*  PCL-REF9303-030724  */
 { UniTextPtrCType, CharPtrCType, LeftPad,   "",                  UNUSED, URL_T_LEN},

 /* TimeStampFmt */
 { TimeStampCType,  CharPtrCType, RightPad,  "9999999999999999999",   UNUSED, UNUSED},              /* REF11780 - 100406 - PMO */

  /* BinaryFmt */
 { BinaryCType,     CharPtrCType, RightPad,  "9999999999999999999",   UNUSED, UNUSED}, /* DLA - PMSTA05995 - 080410 */

 /* String1000Fmt */
 { CharPtrCType, CharPtrCType, LeftPad,   "",                  UNUSED, STRING1000_T_LEN}, /*  DLA - PMSTA07121 - 081212 */

 /* String2000Fmt */
 { CharPtrCType, CharPtrCType, LeftPad,   "",                  UNUSED, STRING2000_T_LEN}, /*  DLA - PMSTA07121 - 081212 */

 /* String3000Fmt */
 { CharPtrCType, CharPtrCType, LeftPad,   "",                  UNUSED, STRING3000_T_LEN}, /*  DLA - PMSTA07121 - 081212 */

 /* String4000Fmt */
 { CharPtrCType, CharPtrCType, LeftPad,   "",                  UNUSED, STRING4000_T_LEN}, /*  DLA - PMSTA07121 - 081212 */

 /* UniString1000Fmt */         /*  HFI-PMSTA-15681-130117  Moved to be in phase with CONVFMT_ENUM  */
 { UniCharPtrCType, CharPtrCType, LeftPad,   "",                  UNUSED, STRING1000_T_LEN}, /*  DLA - PMSTA07121 - 081212 */

 /* UniString2000Fmt */         /*  HFI-PMSTA-15681-130117  Moved to be in phase with CONVFMT_ENUM  */
 { UniCharPtrCType, CharPtrCType, LeftPad,   "",                  UNUSED, STRING2000_T_LEN}, /*  DLA - PMSTA07121 - 081212 */

 /* String7000Fmt */
 { CharPtrCType, CharPtrCType, LeftPad,   "",                  UNUSED, STRING7000_T_LEN}, /*  DLA - PMSTA07121 - 081212 */

 /* String15000Fmt */
 { CharPtrCType, CharPtrCType, LeftPad,   "",                  UNUSED, STRING15000_T_LEN},/*  DLA - PMSTA07121 - 081212 */

 /* UniString3000Fmt */
 { UniCharPtrCType, CharPtrCType, LeftPad,   "",                  UNUSED, STRING3000_T_LEN}, /*  DLA - PMSTA07121 - 081212 */

 /* UniString4000Fmt */
 { UniCharPtrCType, CharPtrCType, LeftPad,   "",                  UNUSED, STRING4000_T_LEN}, /*  DLA - PMSTA07121 - 081212 */

 /* UniString7000Fmt */
 { UniCharPtrCType, CharPtrCType, LeftPad,   "",                  UNUSED, STRING7000_T_LEN}, /*  DLA - PMSTA07121 - 081212 */

 /* UniString15000Fmt */
 { UniCharPtrCType, CharPtrCType, LeftPad,   "",                  UNUSED, STRING15000_T_LEN}, /*  DLA - PMSTA07121 - 081212 */

 /* EnumMaskFmt */ /* PMSTA-13460 - DDV - 120514 - New datatype EnumMaskType default format definition */
 { LongLongCType,   CharPtrCType, RightPad,  "99999999999999999999",  UNUSED, UNUSED},

 /* LongSysnameFmt */       /*  HFI-PMSTA-14086-130117  */
 { CharPtrCType,    CharPtrCType, LeftPad,   "",                  UNUSED, LONGSYSNAME_T_LEN},

 /* TzOffsetFmt */       /* PMSTA-30818 - DLA - 180403 */
 { ShortCType,      ShortCType,   LeftPad,   " HH:II",                "+-:",  UNUSED},

 /* CutOfTimeFmt */      /*  HFI-PMSTA-30817-180503 */
 { ShortCType,      ShortCType,   LeftPad,   "HH:II",                 ":",    UNUSED}

};


const CODE_T SV_MonthGuiCodeTab[] = 
{
  "SMONTH_JANUARY",
  "SMONTH_FEBRUARY",
  "SMONTH_MARCH",
  "SMONTH_APRIL",
  "SMONTH_MAY",
  "SMONTH_JUNE",
  "SMONTH_JULY",
  "SMONTH_AUGUST",
  "SMONTH_SEPTEMBER",
  "SMONTH_OCTOBER",
  "SMONTH_NOVEMBER",
  "SMONTH_DECEMBER",

  "LMONTH_JANUARY",
  "LMONTH_FEBRUARY",
  "LMONTH_MARCH",
  "LMONTH_APRIL",
  "LMONTH_MAY",
  "LMONTH_JUNE",
  "LMONTH_JULY",
  "LMONTH_AUGUST",
  "LMONTH_SEPTEMBER",		/* BUG489 - RAK - 970902 */
  "LMONTH_OCTOBER",
  "LMONTH_NOVEMBER",
  "LMONTH_DECEMBER"
};

const CODE_T SV_DayGuiCodeTab[] = 
{

  "SDAY_SUNDAY",
  "SDAY_MONDAY",
  "SDAY_TUESDAY",
  "SDAY_WEDNESDAY",
  "SDAY_THURSDAY",
  "SDAY_FRIDAY",
  "SDAY_SATURDAY",

  "LDAY_SUNDAY",
  "LDAY_MONDAY",
  "LDAY_TUESDAY",
  "LDAY_WEDNESDAY",
  "LDAY_THURSDAY",
  "LDAY_FRIDAY",
  "LDAY_SATURDAY"

};


STATIC RET_CODE CONV_GetDfltMask(DATATYPE_ENUM, char *);


/************************************************************************
**      Functions
*************************************************************************/

/************************************************************************
**
**  Function    :   CONV_InitConvFmtPtr()
**
**  Description :   Initialize EV_ConvFmtPtr on table SV_ConvFmtTab.
**
**  Arguments   :   none
**
**  Return      :   none
**
*************************************************************************/
void CONV_InitConvFmtPtr()
{
	EV_ConvFmtPtr = SV_ConvFmtTab;
}

/************************************************************************
**
**  Function    :   CONV_InitDefaultMaxPrecision()
**
**  Description :   Initialize CONV_InitDefaultMaxPrecision
**
**  Arguments   :   none
**
**  Return      :   none
**
**  Creation    :   PMSTA-36302 - DDV - 190624 - Make 6 digits amount optional
**
*************************************************************************/
void CONV_InitDefaultMaxPrecision()
{
    size_t       pos = 0;
    int          maxLen = 0, decimals = 0;
    DICT_DATATP_STP     amountDataTpStp = DBA_GetDictDataTpStp(AmountType);

	SV_DefaultMaxPrecision = 0.01;
    SV_AmountPrecision = AMOUNT_T_PREC;

    if (amountDataTpStp != NULL &&
        amountDataTpStp->equivType != NULL)
    {
        std::string      equivTypeStr(amountDataTpStp->equivType);

        pos = equivTypeStr.find_first_of("0123456789");

        if (pos != std::string::npos)
        {
            maxLen = atoi(&(equivTypeStr.c_str())[pos]);
            std:: string temp = &equivTypeStr[pos];
            size_t pos1 = temp.find_first_not_of("0123456789");
            pos = pos + pos1;
            if (pos != std::string::npos &&
                (pos = equivTypeStr.find_first_of(',', pos)) != std::string::npos &&
                (pos = equivTypeStr.find_first_of("0123456789", pos)) != std::string::npos &&
                (decimals = atoi(&(equivTypeStr.c_str())[pos])) > 2)
            {
                SV_DefaultMaxPrecision = SV_AmountPrecision = pow(10.0, (-1) * decimals);
                EV_DataTypePtr[AmountType].maxLen = maxLen;
                EV_DataTypePtr[AmountType].decimal = (unsigned char) decimals;

                for (int i=2; i < decimals; i++)
                {
                    strcat(SV_ConvFmtTab[EV_DataTypePtr[AmountType].dfltConvFmt].maskPtr, "0");
                    strcat(SV_ConvFmtTab[EV_DataTypePtr[AmountType].editConvFmt].maskPtr, "0");
                }
            }
        }
    }
}

/************************************************************************
**
**  Function    :   CONV_DataToStr
**
**  Description :   Convert data to string depending on received format
**                  and data C type.
**                  Function suppose that received format is an coherent format.
**                  There isn't check (it's done at insertion)
**
**  Arguments   :   destStr     Already allocated pointer
**                  sizeDestStr Size of destStr
**                  dataType    Datatype (DATATYPE_ENUM)
**                  maskPtr     mask (see details below)
**                  dataPtr     pointer on values or NULL
**                  converter_e enum to know which converter we have to use (REF9303)
**
**    STRING FORMAT
**    ----------
**
**      N        in first position, print null string if no date
**
**
**    NUMBER FORMAT
**    ----------
**      ,   ->   thousand separator position 
**               printed character depending on language
**
**      .   ->   decimal separator position 
**               printed character depending on language
**
**      9   ->   number in decimal or integer part (sign including)
**
**      0   ->   optional 0 in decimal part and end of integer part
**               0 fill to the left in begin of integer part 
**               Ex :     value  10.00  mask 999.00  ->     10
**                                      mask 999.99  ->     10.00
**                        value   0.25  mask 990.00  ->       .25
**                                      mask 999.00  ->      0.25
**                        value   0.00  mask 990.00  ->  (blank)
**                                      mask 999.90  ->      0.0
**			  value 123.00  mask 09999   ->  00123
**
**               00000 is an unavailable format
**
**      N   ->   parameter string if value is NULL
**
**      C   ->   put color for negativ numbers
**
**      +   ->   force positive sign
**
**      ()   ->  put parentheses around negativ numbers
**               fixed if one space just after open parentheses
**
**      %   ->   print floating percent sign
**
**
**    DATE FORMAT
**    ----------
**      N        in first position, print null string if no date
**
**      DD       print days
**      MM       print month in numeric format
**      MON      print month name in short version (depending on language)
**      MONTH    print month name in long version (depending on language)
**      YY       print year in short version
**      YYYY     print year in long version
**      HH       print hour
**      II       print minutes
**      SS       print seconds
**      others characters are separators
**
**  Return      :   ptr or NULL
**
**  Warning     :  
**
**  Modif.	:   ROI - 961106 - BUG194 
**                  PEC - 970408
**  Modif.	:   ROI - 970603 - BUG390
**  Modif.	:   AKO - 990210 - REF3305 
**              GRD - 000204 - REF4204
**				REF4590 - SSO - 000426
**              REF5635 - GRD - 010205 : Do not use user specific format for subscription. (use of the defaultFmt flag).
**              REF9303 - 030915 - PMO : Implementation of Unicode
**              PMSTA-15918 - 070213 - PMO : Fusion on portfolio [T_AI_PE_ST] failed ; upd_exd_position : Attempt to insert NULL value into column 'end_d', table position
**              PMSTA-25173 - 021116 - PMO : Linux: Importing specific number in quantity of operation raise NAN
**
*************************************************************************/
char    *CONV_DataToStr ( char                          *destStr
                        , const size_t                  sizeDestStr
                        , DATATYPE_ENUM                 dataType
                        , const char                    *maskPtr
                        , PTR                           dataPtr
                        , FLAG_T                        defaultFmt
                        , TEXT_CONVERSION_TYPE_ENUM     converter_e         /* DLA - REF8728 */ 
                        , const char                   *dispTimeZoneCd      /* PMSTA-30817 - DDV - 180427 */
                        , const char                    dateTimeEscapeChar) /* PMSTA-30817 - DDV - 180427 */
{
	char            *outRet     = destStr,      /*  FPL-PMSTA11054-101202 out->outRet   */
                    thousSep    = THOUSAND_SEP,
                    decimSep    = DECIMAL_SEP;
	double          dbData;
	int	            after = 0;		/* BUG310 */
	int	            before = 0;		/* BUG310 */
	int	            decPrec = 0;	/* BUG310 */
    int	            maxPrec = 21;	/* BUG310 */    /*  HFI-PMSTA-52182-2023-02-15  15 --> 21   */
	char            nullBuf[2];
    char            *out ;                      /*  FPL-PMSTA11054-101202   */
    size_t          iSize ;                     /*  FPL-PMSTA11054-101202   */
    int             rv = 0;                     /* PMSTA-42593 - DPT - 210218 */
	MemoryPool		mp; 						/* PMSTA-49331 */

	
    /* WEALTH-2625 - JPR - 20231017 - maxPrec to be governed by environemnt. 
       Temporary code - to be removed when proper solution is available */
    if (SYS_GetEnv("AAA_ENABLE_BIGNUMBER") == NULL)
    {
        maxPrec = 15;
    }
        
    /* PEC - 970408 */
	if (maskPtr == NULL)
	{
		nullBuf[0] = END_OF_STRING;
		maskPtr = nullBuf;
	}
	/* PEC - 970408 */

    if ((sizeDestStr == INT_MAX) && (SYS_StrLen(maskPtr) > 0))
    {
        iSize = SYS_StrLen(maskPtr);
    }
    else if (sizeDestStr == INT_MAX)
    {
		iSize = GET_CONV_MAXLEN(GET_DFLTCONVFMT(dataType));
    }
    else
    {
        iSize = (int)sizeDestStr;
    }

    if ((out = mp.allocChar(FILEINFO, ((iSize * 10) + 1))) == nullptr) /* PMSTA-49331 */
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
        return out;
    }

    CTYPE_ENUM cType = GET_CTYPE(dataType);       /* PMSTA-15918 - 070213 - PMO */
		
	/***** TREAT NULL VALUE *****/
	if (dataPtr == NULL)
	{
		/* If specific code N is found in mask */
		/* return parameter string.            */
		if (cType != ExtPtrCType)
		{
            if(cType == CharPtrCType)
                cType = cType;
			if ((cType == CharPtrCType) || (cType == TextPtrCType))		/* REF4204 */
			{
				if (maskPtr == NULL || *maskPtr == END_OF_STRING)
				{
					*out = END_OF_STRING;
				}
				else
				{
				    if (maskPtr[0] == 'N')
					strcpy(out, GET_NULL_STRING());
				    else
					*out = END_OF_STRING;
				}
			}
			else if (cType == DateTimeStCType)
			{
				if (maskPtr == NULL || *maskPtr == END_OF_STRING)
				{
				  CODE_T	dfltMask;
				  char		*p, *mask, *pDay, *pMonth,
				  		*pYear, *pHour, *pMin, *pSec;
				  short		i, dayLen=0, monthLen=0, yearLen=0,
				  		hourLen=0, minLen=0, secLen=0;
                  RET_CODE ret;

                  /*
                   * The subscription needs not to use the user specific format.
                   * A generic format must be used instead. (defaultFmt set to TRUE).
                   * GRD - 06/02/01 - REF5635.
                   */

                  if (defaultFmt == FALSE)
                  {
                    CONV_GetDfltDateFmt(dataType, dfltMask, NULL);
                  }
                  else
                  {
                    if ((ret = CONV_GetDfltMask(dataType, dfltMask)) != RET_SUCCEED)      /* REF5635 */
                    {
                        strcpy(dfltMask, "DD/MM/YYYY");
                    }
                  }

				  mask = dfltMask;

				  /* Suppress 'N' on begin of mask */
				  if (*mask == 'N')
				    mask = mask+1;

				  /* Keep SEPARATORS ***/
				  /*** DAY ***/
				  pDay = strchr(mask, 'D');
				  if (pDay != NULL)
				  {
				    if (!strncmp(pDay, "DAY", 3))
				      dayLen = 3;
				    else if (!strncmp(pDay, "DD", 2))
				      dayLen = 2;
				    else pDay = NULL;
				  }

				  /*** MONTH ***/
				  pMonth = strchr(mask, 'M');
				  if (pMonth != NULL)
				  {
				    if (!strncmp(pMonth, "MM", 2))
				      monthLen = 2;
				    else if (!strncmp(pMonth, "MONTH", 5))
				      monthLen = 5;
				    else if (!strncmp(pMonth, "MON", 3))
				      monthLen = 3;
				    else pMonth = NULL;
				  }

				  /*** YEAR ***/
				  pYear = strstr(mask, "YY");
				  if (pYear != NULL)
				  {
				    if (!strncmp(pYear, "YYYY", 4))
				      yearLen = 4;
				    else if (!strncmp(pYear, "YY", 2))
				      yearLen = 2;
				    else pYear = NULL;
				  }

				  /*** HOUR ***/
				  pHour = strchr(mask, 'H');
				  if (pHour != NULL)
				  {
				    if (!strncmp(pHour, "HH", 2))
				      hourLen = 2;
				    else
				      pHour = NULL;
				  }

				  /*** MINUTE ***/
				  pMin = strchr(mask, 'I');
				  if (pMin != NULL)
				  {
				    if (!strncmp(pMin, "II", 2))
				      minLen = 2;
				    else
				      pMin = NULL;
				  }

				  /*** SECOND ***/
				  pSec = strchr(mask, 'S');
				  if (pSec != NULL)
				  {
				    if (!strncmp(pSec, "SS", 2))
				      secLen = 2;
				    else
				      pSec = NULL;
				  }

				  p = mask;
				  i = 0;
				  while (*p != END_OF_STRING) 
				  {
				    if (p == pDay)
				    {
				      strncpy(&out[i], "     ", dayLen);
				      i = (short)(i + dayLen);
				      p += dayLen;
				    }
				    else if (p == pMonth)
				    {
				      strncpy(&out[i], "     ", monthLen);
				      i = (short)(i + monthLen);
				      p += monthLen;
				    }
				    else if (p == pYear)
				    {
				      strncpy(&out[i], "     ", yearLen);
				      i = (short)(i + yearLen);
				      p += yearLen;
				    }
				    else if (p == pHour)
				    {
				      strncpy(&out[i], "     ", hourLen);
				      i = (short)(i + hourLen);
				      p += hourLen;
				    }
				    else if (p == pMin)
				    {
				      strncpy(&out[i], "     ", minLen);
				      i = (short)(i + minLen);
				      p += minLen;
				    }
				    else if (p == pSec)
				    {
				      strncpy(&out[i], "     ", secLen);
				      i = (short)(i + secLen);
				      p += secLen;
				    }
				    else
				    {
				      out[i++] = *p;
				      p++;
				    }
				    out[i] = END_OF_STRING;
				  }
				}
				else
				{
				    if (maskPtr[0] == 'N')
					strcpy(out, GET_NULL_STRING());
				    else
					*out = END_OF_STRING;
				}
			}
			else /* numeric */
			{
				if (maskPtr == NULL || *maskPtr == END_OF_STRING)
				{
					*out = END_OF_STRING;
				}
				else
				{
				    if (strchr(maskPtr, 'N') != NULL)
					strcpy(out, GET_NULL_STRING());
				    else
					*out = END_OF_STRING;
				}
			}
		}
		else
			*out = END_OF_STRING;
        snprintf(outRet, sizeDestStr, "%s", out);   /*  FPL-PMSTA11054-101202               */
		return(outRet);                             /*  FPL-PMSTA11054-101202 out -> outRet */
	}

	switch(cType)
	{
	/* DoubleCType will be treated below */
	case DoubleCType :
		break;

	case PtrCType :             /*  FIH-REF9089-030513  */
        break;

	case CharPtrCType :
	case TextPtrCType :				/* REF4204 */
		strcpy(outRet, (char *)dataPtr);        /*  HFI-PMSTA-12314-110708  Back to previous code   */
#ifdef NOTUSED      /*  HFI-PMSTA-12314-110708  */
		strcpy(out, (char *)dataPtr);
        snprintf(outRet, sizeDestStr, "%s", out);   /*  FPL-PMSTA11054-101202               */
#endif                                                  /*  FPL-PMSTA12582-110818 we need to do the free    */
/*#endif*/              /*  HFI-PMSTA-12314-110708  */  /*  FPL-PMSTA12582-110818 we need to do the free    */
		return(outRet);                             /*  FPL-PMSTA11054-101202 out -> outRet */

    /* MRA - 030829 - REF9303 */
    case UniCharPtrCType :
    case UniTextPtrCType :
        /* REF9303 - 030915 - PMO */
        ICU4AAA_ConvertFromUChars((UChar *)dataPtr, -1, out, (int)sizeDestStr, NULL, converter_e);            
        snprintf(outRet, sizeDestStr, "%s", out);   /*  FPL-PMSTA11054-101202               */
		return(outRet);                             /*  FPL-PMSTA11054-101202 out -> outRet */
        
        break;

	case DateTimeStCType :
	{
        const char *mask;
		DATETIME_ST dt;
		CODE_T      dfltMask;
        RET_CODE    ret;
        FLAG_T      dispNullStrFlg = FALSE;
        FLAG_T      taFmtFlg = FALSE;
        char       *maskICU = NULL;

		/* Use default mask if necessary */
		if (maskPtr == NULL || *maskPtr == END_OF_STRING)
		{
          /*
           * The subscription needs not to use the user specific format.
           * A generic format must be used instead. (defaultFmt set to TRUE).
           * GRD - 06/02/01 - REF5635.
           */

          if (defaultFmt == FALSE)
          {
            CONV_GetDfltDateFmt(dataType, dfltMask, NULL);
          }
          else
          {
            if ((ret = CONV_GetDfltMask(dataType, dfltMask)) != RET_SUCCEED)      /* REF5635 */
            {
                strcpy(dfltMask, "DD/MM/YYYY");
            }
          }

			mask = dfltMask;
		}
		else
		{
			mask = maskPtr;
		}

		/* Read date data depending on dataType */
		dt.date=0;  dt.time = 0;                            /* REF3305 - AKO - 990210 */ 
		if (dataType == DateType)
		{
			/* Save date in DATETIME_ST structure */
			dt.date = (*((DATETIME64_ST *)dataPtr)).date();     /* PMSTA-15918 - 070213 - PMO */
		}
		

		if (dataType == DatetimeType)
		{
			/* Save date and time in DATETIME_ST structure */
			dt = (*((DATETIME64_ST *)dataPtr)).dateTime();
		}

		/* Date is 0 or magic end date */
		if (dt.date == BAD_DATE || dt.date == MAGIC_END_DATE)
		{
			*out = END_OF_STRING;
            snprintf(outRet, sizeDestStr, "%s", out);   /*  FPL-PMSTA11054-101202               */
		    return(outRet);                             /*  FPL-PMSTA11054-101202 out -> outRet */
		}

        char *tmpMask = const_cast<char*>(mask);    /* PMSTA-42593 - DPT - 210218 */
        FLAG_T convFlg = FALSE;                  /* PMSTA-42593 - DPT - 210218 */

        /* PMSTA-42593 - DPT - 210218 - Replace T in the mask format(YYYY-MM-DDTHH:II:SS:DDDDDZ) with space for ICU4AAA_DateTimeStr to fetch proper time value*/
        rv = convDateTimeDelimToGenFmt(&convFlg, tmpMask);

        CONV_TADatetimeMaskToICU(tmpMask, &maskICU, &dispNullStrFlg, &taFmtFlg, dateTimeEscapeChar);  /* PMSTA-42593 - DPT - 210218 */

        if (ICU4AAA_DateTimeStr(dt, maskICU, dispTimeZoneCd, &out) != RET_SUCCEED)
        {
            FREE(maskICU);
			outRet[0] = END_OF_STRING;
		    return(outRet);
        }
		
		mp.ownerPtr(static_cast<void *> (out)); //PMSTA-49331

        /* PMSTA-42593 - DPT - 210218 - Change the replaced space back to character T so that output string contains the T character*/
        if (convFlg == TRUE)
        {
            rv = convGenToDateTimeDelimFmt(out, tmpMask);
        }

        /* PMSTA-42593 - DPT - 210218 - Appends microseconds to the output string if the mask contains the microsecond format*/
        rv = populateMicrosecondsIntoDateTimeStr(dt, maskICU, out);


        if (taFmtFlg == TRUE)
        {
		    char	    *pDayW,dayC[12], dayW[12], monthC[10], yearC[5], 
					    hourC[3], minC[3], secC[3];
		    int         i, lenDay=0, lenDayW=0, lenMonth=0, lenYear=0, 
					    lenHour=0, lenMin=0, lenSec=0;
            const char  *p,*pDay,*pMonth, *pYear, *pHour, *pMin, *pSec; /* DLA - REF8728 */
	 	    YEAR_T      year;
	 	    MONTH_T     mon;
	 	    DAY_T       day;
		    HOUR_T      hour;
		    MINUTE_T    min;
		    SECOND_T    sec;
            char        *newMask;
              
		    dayC[0]=END_OF_STRING; 
		    dayW[0]=END_OF_STRING;
		    monthC[0]=END_OF_STRING;
		    yearC[0]=END_OF_STRING; 
		    hourC[0]=END_OF_STRING; 
		    minC[0]=END_OF_STRING; 
		    secC[0]=END_OF_STRING;	

            newMask = out;

	    	if ((out = mp.allocChar(FILEINFO, ((iSize * 10) + 1))) == nullptr) /* PMSTA-49331 */
            {
                CODE_T tmp;

			    tmp[0] = END_OF_STRING;
                snprintf(outRet, sizeDestStr, "%s", tmp);   
                MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
                FREE(maskICU);
				return(outRet);                            
            }

#if 0 /* PMSTA-30817 - DDV - 180427 - Already removed by convertion of mask to ICU */
		    /* Suppress 'N' on begin of mask */
		    if (*mask == 'N')
			    mask = mask+1;
#endif

		DATE_Get(dt.date,&year,&mon,&day);
		TIME_Get(dt.time,&hour, &min, &sec); 

		/*** DAY ***/

		    p = strchr(newMask, 'D');
            
		pDay  = NULL;		/* BUG452 - 970807 - XMT: init. before testing */
		pDayW = NULL;

		if (p != NULL)
		{
		  while ( p )
		  { 
		    if ( !strncmp ( p, "DAY", 3 ))
		    {
		      int    dayWeek;
		      
		      DATE_T tmpDate = DATE_Put (year,mon,day);
		      
              pDayW = (char *)p; /* DLA - REF8728 */
		      
		      dayWeek = (int) DATE_WhichWeekDay ( tmpDate );
		      
		      CONV_GetDayName (dayWeek, FALSE, dayW );
		      
		      lenDayW = SYS_StrLen(dayW);
		      
		      p += 3; 
		    }
		    else
		    {
		      int nbD = SYS_StrSpn (p, "D");
		      if (( nbD ==  1 ) || ( nbD ==  2 ))  /* XSH - 11072000 - LN4954 Add test == 1 */
		      {
		        pDay = p;
		        sprintf(dayC, "%02d", day);
		        lenDay = 2;
		       /* p += 2; */			   /* XSH - 11072000 - LN4954 */
			p += nbD;  		 	   /* XSH - 11072000 - LN4954 */
		      }
		      else
		        p += nbD;  		      
		    }
		    p  = strchr(p, 'D');  
                  }
		}

		/*** MONTH ***/
		    pMonth = strchr(newMask, 'M'); 
		if (pMonth != NULL)
		{
			/* MMM : month in letter */	  /* XSH - 12072000 - LN4954 -S */
			if (!strncmp(pMonth, "MMM", 3))
			{
				CONV_GetMonthName ( mon, TRUE, monthC );
				lenMonth = 3;
			}				  /* XSH - 12072000 - LN4954 -E */

			/* MM : month in number */
			else if (!strncmp(pMonth, "MM", 2))
			{
				sprintf(monthC, "%02d", mon);
				lenMonth = 2;
			}
			/* MON : month name (short version) */
			/* MONTH : month name (long version) */
			else if (!strncmp(pMonth, "MONTH", 5))
			{
			   CONV_GetMonthName ( mon, FALSE, monthC );
			   lenMonth = SYS_StrLen(monthC);
			}
			else if (!strncmp(pMonth, "MON", 3))
			{
			   CONV_GetMonthName ( mon, TRUE, monthC );
			   lenMonth = SYS_StrLen(monthC);
			}
			else if (!strncmp(pMonth, "M", 1))  /* XSH - 11072000 - LN4954 -S */
			{
			   sprintf(monthC, "%02d", mon);
			   lenMonth = 2;
			}  				    /* XSH - 11072000 - LN4954 -E */ 
			else
			{
			  pMonth = NULL;
			}
		}
		
		/*** YEAR ***/
		    /* pYear = strstr(newMask, "YY"); */	    /* XSH - 11072000 - LN4954 */
		    pYear = strstr(newMask, "Y");      	    /* XSH - 11072000 - LN4954 */
		if (pYear != NULL)
		{
		    /* XSH - 11072000 - LN4954 -S */
		    int nbY = SYS_StrSpn (pYear, "Y");

		    if ((nbY == 1) || (nbY == 2)) 
		    {
			sprintf(yearC, "%02d", ((int) year)%100);
			lenYear = 2;
		    }
		    else
		    {
                        sprintf(yearC, "%04d", year);
                        lenYear = 4;
		    }
		    /* XSH - 11072000 - LN4954 -E */

			/* YY is year like 95 */
	/*		if (strncmp(pYear, "YYYY", 4))
			{
				sprintf(yearC, "%02d", ((int) year)%100);
				lenYear = 2;
			}	*/				/* XSH - 11072000 - LN4954 */
			/* YYYY is year like 1995 */
        /*		else
			{
				sprintf(yearC, "%04d", year);
				lenYear = 4;
			}	*/				/* XSH - 11072000 - LN4954 */
		}

		/*** HOUR ***/
		    pHour = strchr(newMask, 'H');
		if (pHour != NULL)
		{
            nsnprintf(hourC, sizeof(hourC), "%02d", hour);
			lenHour = 2;
		}

		/*** MINUTE ***/   
		    pMin = strchr(newMask, 'I');
		if (pMin != NULL)
		{
			sprintf(minC, "%02d", min);
			lenMin = 2;
		}

		/*** SECOND ***/
		    pSec = strchr(newMask, 'S');
		if (pSec != NULL)
		{
			sprintf(secC, "%02d", sec);
			lenSec = 2;
		}

		    /*** READ newMask ***/
		*out = END_OF_STRING;
		    p = newMask;
		i = 0;
		while (*p != END_OF_STRING)
		{
			/*** SEPARATORS ***/
			while(*p != END_OF_STRING && p != pDayW && 
			       p != pDay && p != pMonth && p != pYear &&
			       p != pHour && p != pMin && p != pSec)
			{
				out[i++] = *p;
				out[i] = END_OF_STRING;
				p++;
			}

			/*** DAY NUMBER ***/
			if (p == pDay)
			{
				int nbD = SYS_StrSpn (pDay, "D");         /* XSH - 11072000 - LN4954 */

				strcpy(out+i, dayC);
				i+=lenDay;  /* move in output string */
				    /* p+=2; */      /* move in newMask */   /* XSH - 11072000 - LN4954 */
				p += nbD;                             /* XSH - 11072000 - LN4954 */
			}

			/*** DAY WEEK ***/
			if (p == pDayW)
			{
				strcpy(out+i, dayW);
				i+=lenDayW;  /* move in output string */
				    p+=3;       /* move in newMask */
			}

			/*** MONTH ***/
			if (p == pMonth)
			{
				strcpy(out+i, monthC);
				i+=lenMonth; /* move in output string */

				    /* move in newMask */
				if (!strncmp(pMonth, "MMM", 3))	      /* XSH - 12072000 - LN4954 */
					p+=3;			      /* XSH - 12072000 - LN4954 */
				else if (!strncmp(pMonth, "MM", 2)) 
					p+=2;
				else if (!strncmp(pMonth, "MONTH", 5))
				        p+=5;
				else if (!strncmp(pMonth, "MON", 3))  /* XSH - 11072000 - LN4954 */
					p+=3;
                                else
					p+=1;                         /* XSH - 11072000 - LN4954 */
			}

			/*** YEAR ***/
			if (p == pYear)
			{
				strcpy(out+i, yearC);
				i+=lenYear;  /* move in output string */

				    /* move in newMask */
		/*		if (strncmp(pYear, "YYYY", 4)) 
					p+=2;
				else
					p+=4;     */		     /* XSH - 11072000 - LN4954 */

                                /* XSH - 11072000 - LN4954 -S */
                                if (!strncmp(pYear, "YYYY", 4))
                                        p+=4;
				else if (!strncmp(pYear, "YY", 2))
                                        p+=2;
				else
                                        p+=1;
				/* XSH - 11072000 - LN4954 -E */
			}

			/*** HOUR ***/
			if (p == pHour)
			{
				strcpy(out+i, hourC);
				i+=lenHour;
				p+=2;
			}

			/*** MINUTE ***/
			if (p == pMin)
			{
				strcpy(out+i, minC);
				i+=lenMin;
				p+=2;
			}

			/*** SECOND ***/
			if (p == pSec)
			{
				strcpy(out+i, secC);
				i+=lenSec;
				p+=2;
			}
		}
	    
        }

        snprintf(outRet, sizeDestStr, "%s", out);   /*  FPL-PMSTA11054-101202               */
        FREE(maskICU);
		return(outRet);                             /*  FPL-PMSTA11054-101202 out -> outRet */
	}

	/* All number types are treated like DoubleCType */
	case UCharCType :
		dbData = (double)*((unsigned char *)dataPtr);
		break;

	case IntCType : 
		dbData = (double)*((int *)dataPtr);
		break;

    case LongLongCType :            /*  FPL-PMSTA08801-091204   */
        {
            /* The value is stored into a ID_T instead of double to avoid lost of data.
               The default display mask is no more used. */
            ID_T id; 

            id = (ID_T)* (ID_T *)dataPtr;
            sprintf(out, "%" szFormatId, id); /* DLA - PMSTA08801 - 100209 */
            snprintf(outRet, sizeDestStr, "%s", out);   /*  FPL-PMSTA11054-101202               */
		    return(outRet);                             /*  FPL-PMSTA11054-101202 out -> outRet */
        }
        break ;

    case TimeStampCType :           /*  FIH-PMSTA01437-PMSTA-1439-070314    */
        {
            TIMESTAMP_T timeStamp; 

            /* PMSTA08457 - DDV - 090729 - New treatment for timestamp. 
               The value is stored into a T�MESTAMP_T instead of double to avoid lost of data.
               The default display mask is no more used. */

            timeStamp = (TIMESTAMP_T)* (TIMESTAMP_T *)dataPtr;
            sprintf(out,szFormatTimeStampSScanf, timeStamp);
            snprintf(outRet, sizeDestStr, "%s", out);   /*  FPL-PMSTA11054-101202               */
		    return(outRet);                             /*  FPL-PMSTA11054-101202 out -> outRet */
        }
		break;

    case BinaryCType :           /* DLA - PMSTA05995 - 080410 */
		dbData = (double)*((INT64_T *)dataPtr);
		break;

	/* for dataType DateType, ctype modified in DateTimeStCType upper */
	case UIntCType : 
		dbData = (double)*((unsigned int *)dataPtr);
		break;

	case ShortCType : 
        if (dataType == TzOffsetType)
        {
            char   mask[80];
            *mask = END_OF_STRING;
            if (maskPtr == NULL || *maskPtr == END_OF_STRING)
            {
                CONV_GetDfltMask(dataType, mask);
            }
            else
		    {
			    strcpy(mask, maskPtr);
		    }

            snprintf(outRet, sizeDestStr, "%s", CONV_TzOffsetTypeToString((int)*((short *)dataPtr),mask).c_str());
            return(outRet);      
        }
        else
        {
            dbData = (double)*((short *)dataPtr);
        }
		break;

	case UShortCType : 
		dbData = (double)*((unsigned short *)dataPtr);
		break;

	case ExtPtrCType :
	default :
		/* MSG_SendMsg(); */
		out = NULL;
        snprintf(outRet, sizeDestStr, "%s", out);   /*  FPL-PMSTA11054-101202               */
		return(outRet);                             /*  FPL-PMSTA11054-101202 out -> outRet */
	}

	{       /* Specific declaration for numbers treatment */
		/***** BUG212 961126 PEN *****/
		char   mask[80], buf[350], tempo[80], printMask[20], 
		       *maskDec, *p, *bufInt, 
		       *bufDec, parFlg, parFxdFlg, 
		       leftZero, decSignifFlg, checkSignifNbr, intSignifFlg,
		       markOk;
		double *dbPtr;
		int    i=0, j, k, strSz, bufSz, intLen=0, decLen=0, 
		       decPrintLen, percentLen;

		*out = END_OF_STRING;
        *mask = END_OF_STRING;
		*buf = END_OF_STRING;

		/* Value to format, double or elsewhere */
		if (cType == DoubleCType)
		{
			dbPtr = (double *)dataPtr;

			/***** PEN UNICIBLE 97/04/09 ??? *******/
			/***** SURTOUT, NE PAS S'AFFOLLER ******/
			/***** C'EST PARCE QUE SUR 'SUN' , *****/
			/***** LE -0.0 EXISTE SANS VRAIMENT ****/
			/***** EXISTER PUISQU'IL VAUT BIEN 0.0 */
			if( *dbPtr == (double)0.0 )
			    *dbPtr = (double)0.0;
			/***************************************/
		}
		else
			dbPtr = &dbData;

        if (*dbPtr < 0.0)
            maxPrec++;

		/* No mask */
		if (maskPtr == NULL || *maskPtr == END_OF_STRING)
		{
			/* Get default mask */
			if (CONV_GetDfltMask(dataType, mask) != RET_SUCCEED)
			{
			    if (cType == DoubleCType)
				sprintf(out, "%lf", *dbPtr);
			    else
				sprintf(out, "%d", (int)*dbPtr);
                snprintf(outRet, sizeDestStr, "%s", out);   /*  FPL-PMSTA11054-101202               */
		        return(outRet);                             /*  FPL-PMSTA11054-101202 out -> outRet */
			}
		}
		else
		{
			strcpy(mask, maskPtr);
		}

          /*
           * The subscription needs not to use the user specific separators.
           * A generic separator must be used instead. (defaultFmt set to TRUE).
           * GRD - 06/02/01 - REF5635.
           */

            if (defaultFmt == FALSE)
            {
                /* Get separators depending on user language */
                if (CONV_GetDecimSep(&decimSep) != RET_SUCCEED)
                {
                    snprintf(outRet, sizeDestStr, "%s", out);   /*  FPL-PMSTA11054-101202               */
	     	    	return(outRet);                             /*  FPL-PMSTA11054-101202 out -> outRet */
                }

                if (CONV_GetThousSep(&thousSep) != RET_SUCCEED)
                {
                    snprintf(outRet, sizeDestStr, "%s", out);   /*  FPL-PMSTA11054-101202               */
		            return(outRet);                             /*  FPL-PMSTA11054-101202 out -> outRet */
                }
            }

		char * maskInt = mask;

		/*** SEPARATE DECIMAL PART ***/
		if ((p = strchr(maskInt, DECIMAL_SEP)) != NULL)
		{
			maskDec = p+1;
			*p=END_OF_STRING;
		}
		else
			 maskDec = NULL;

		/*** SEARCH FIRST '0' or '9' IN MASK ***/
		char mandSignFlg = parFlg = parFxdFlg = FALSE;
		for (p=maskInt; *p!= END_OF_STRING && 
				*p!='0' && *p!='9'; p++) 
		{
			/* remember if sign '+' is found */
			if (*p == MAND_SIGNE)
				mandSignFlg = TRUE;

			/* remember if parenthese is found */
			if (*p == '(')
			{
				parFlg = TRUE;     /* test fixed parentheses */
				if (*(p+1) == ' ') 
					parFxdFlg = TRUE;
			}
		}
		maskInt = p;              /* store first '0' or '9' position */

		/*** 0 FILL to left ***/
		if (*maskInt == '0')
			leftZero = TRUE;
		else
			leftZero = FALSE;

		/*** COUNT MAX LENGTH OF INTEGER PART ***/
		/* p is on first '0' or '9'             */
		/* count integer part length (without separators) */
		for(; *p!=END_OF_STRING ; p++)
		{   
		    if (*p=='0' || *p=='9')
			intLen++;
		}
		/* REF4590 - SSO - 000426 don't move backwards if mask is empty! */
		if (*maskInt != END_OF_STRING)
		{
		    /*** VERIFY MASK LIKE xxxx0.xxx ***/
		    /* p is on END_OF_STRING */
		    /* 00000 is an unavailable format, in that case */
		    /* don't check unsignificant 0 for delete       */
		    if (*(p-1) == '0' && leftZero == FALSE)
			    checkSignifNbr = TRUE; 
		    else
			    checkSignifNbr = FALSE;
		}
		else
		{
		    checkSignifNbr = FALSE;
		}

		/*** COUNT MAX LENGTH OF DECIMAL PART ***/
		if (maskDec != NULL)
			for(p=maskDec; *p!=END_OF_STRING; p++)
		    		if (*p=='0' || *p=='9')
					decLen++;

		/*** PRINT "BRUT" NUMBER ***/ 
		i=0;
		printMask[i++] = '%';

		if (leftZero == TRUE)
			printMask[i++] = '0';     /* force 0 on left */

		if (mandSignFlg == TRUE)
			printMask[i++] = '+';     /* force positiv sign */

		printMask[i] = END_OF_STRING;
		strcpy(printMask+i, "*.*lf");         

		/* in sprintf 10.4        max : 12345.1234 or -1234.1234   */
		/* if format 999999.9999  max : 123456.1234 or -12345.1234 */
		/* so sprintf with size intlen + 1 (decimal point)         */
		/* in integer part when decimal part isn't 0               */
		if (decLen != 0)
			strSz = intLen+1+decLen;
		else
			strSz = intLen;                 /* decLen is 0 */

        /* PMSTA-25173 - 021116 - PMO */
        bool badFloating = false;

        if (DoubleCType == cType)
		{
#ifdef AIX
            switch (fpclassify(*dbPtr))
#else
            switch (std::fpclassify(*dbPtr))
#endif
            {
                // Bad floating point value
                case FP_INFINITE:
                case FP_NAN:
                    badFloating = true;
                    break;

                case FP_NORMAL:
                case FP_SUBNORMAL:
                case FP_ZERO:
                default:
                    break;
            }
        }


		if(true == badFloating)
        { // Bad floating point value
			bufSz = strSz +1;  /* Force l'erreur du if(bufSz == strSz) qui suit */
        }
		else
		{
		    /***** BUG310 *****/
		    if(decLen == 0 || strSz <= (maxPrec+1))
		    	bufSz = sprintf(buf, printMask, strSz, decLen, *dbPtr);
		    else
		    {
			char	s[40], *q;

			sprintf(s,"%lf",*dbPtr);
			for(q=s ; *q!='.' ; q++);

			if((decPrec = maxPrec - ((int)(q-s))) > decLen)
			{
			    decPrec = decLen;
			    after = 0;
			    before = strSz - maxPrec - 1;
			}
			else
			{
                            if(decPrec<0)
                                decPrec = 0;
			    after = decLen - decPrec;
			    before = strSz - maxPrec - 1 - after;
			}

			if (after>0)
                           
			    bufSz = sprintf(buf, 
					    "%*s%*.*lf%s%0*d",
					    before,
					    "",
					    maxPrec + 1,
					    decPrec,
					    *dbPtr,
                                            (decPrec>0)?"":".",
					    after,
					    0);
			else
			    bufSz = sprintf(buf, 
					    "%*s%*.*lf",
					    before,
					    "",
					    maxPrec + 1,
					    decPrec,
					    *dbPtr);
		    }
		}

		/*** TREAT "BRUT" NUMBER ***/
		/* bufSz contains characters printed     */
		/* verify if data is too long for format */
		i=0;
		if (bufSz == strSz)
		{
		    /*** DECIMAL PART ***/
		    /* . is printed by sprintf,     */
		    /* if decLen isn't egal to 0 */
		    if ((p = strchr(buf, '.')) != NULL)
		    {
			bufDec = p+1;      /* init decimal part */
			*p=END_OF_STRING;  /* stop integer part */
		    }
		    else
			bufDec = NULL;     /* no decimal part */

		    /*** INTEGER PART ***/
		    bufInt = buf;          /* integer part */

		    /*** SEPARATOR ***/
		    for (intSignifFlg=FALSE, j=0, k=0; j<intLen; j++, k++)
		    {
			/* print separator in output string */
			/* and pass separator in mask       */
			if (maskInt[k] == THOUSAND_SEP) 
			{
				/* separator only print between two numbers */
				if (j == 0) /* begin */
				{ 
				    if (bufInt[j] != '-' &&
					bufInt[j] != '+' &&
					bufInt[j] != ' ')
					out[i++] = thousSep;
				    else
					out[i++] = ' ';
				}
				else 
				{
				    /* separator only print between two nbr */
				    if (bufInt[j] != '-' && 
				        bufInt[j] != '+' &&
				        bufInt[j] != ' ')
				    {	
					if (bufInt[j-1] != '-' &&
				            bufInt[j-1] != '+' &&
				            bufInt[j-1] != ' ')
						out[i++] = thousSep;
				        else
					{
						/* advance sign */
						out[i] = out[i-1];
						out[i-1] = ' ';
						i++;
					}
				    }
				    else
					out[i++] = ' ';
				}
				k++;    /* skip separator in mask */
			}

			/* print number in output string */
			out[i++] = bufInt[j];

			/* Verify if integer part is significant */
			if (checkSignifNbr == TRUE && intSignifFlg == FALSE) 
			{
			    if (strchr(NBR_SIGNIF, bufInt[j]) != NULL)
				intSignifFlg = TRUE;
			}
		    }

		    /* Mask like xxxx0.xxx and number like 0.xxx */
		    if (checkSignifNbr == TRUE && intSignifFlg == FALSE)
		    {
				out[i-1] = ' ';  /* Don't print 0 */

				if (i-1 != 0)    /* Don't print forced sign */
					if (out[i-2] == '+')
						out[i-2] = ' ';
				markOk = FALSE;  /* No mark on unsignificant number */
		    }
		    else
				markOk = TRUE;

		    /*** DECIMAL PART ***/
		    decSignifFlg = FALSE;
		    if (bufDec != NULL)
		    {
				for (j=0; j<decLen ; j++)
		    			if (bufDec[j] != '0') decSignifFlg = TRUE;
		    }

		    /* Remember decimal part printing begin */
		    decPrintLen = i;

		    if (maskDec != NULL)
		    {
			/* If decimal part significant or printing forced */
			if (maskDec[0] == '9' || decSignifFlg == TRUE)
			{
		    		out[i++] = decimSep;

	    			memcpy(out+i, bufDec, decLen);
	    			i+=decLen;
	
				/* Suppress 0 while mask is 0 */
	    			for(k=i, j=decLen-1; 
				    j>=0 && bufDec[j]=='0' && 
					    maskDec[j]=='0'; j--)
					i--;

				markOk = TRUE;     /* Mark, integer part */
			}                          /* significant or not */
		    }

		    /*** TREAT MARKS (PERCENT, PARENTHESES) ***/
	    	    percentLen = 0;
		    if (markOk == TRUE)
		    {
		    	/*** PERCENT ***/
			if ((p = (char *)strchr(maskPtr, '%')) != NULL)
		    	{
			    /* Go back unil first number mark */
			    for (; *p!='0' && *p!='9'; p--);

			    /* Copy all mask characters until percent sign */
			    for (p=p+1; *p!= END_OF_STRING && *p != '%'; p++)
			    {
					percentLen++;
					out[i++] = *p;
			    }	
			    percentLen++;
			    out[i++] = '%';
			}

		    	/*** PARANTHESES ***/
			if (parFlg == TRUE)
			{
			    /* Close current number display */
			    out[i] = END_OF_STRING;

			    /* Fixed parantheses, add place for paranthese */
			    if (parFxdFlg == TRUE)
			    {
				tempo[0] = ' ';
				tempo[1] = END_OF_STRING;
				i++;
				memcpy(tempo+1, out, i-1);
				memcpy(out, tempo, i);
			    }

			    /* Negativ number */
			    if ((p = strchr(out, '-')) != NULL)
			    {
			    	/* Fixed parantheses */
		    	    	if (parFxdFlg == TRUE)
		    	    	{
				    /* suppress negativ sign */
				    if (leftZero == TRUE)
				    	*p = '0';
				    else
				    	*p = ' ';
				    /* open paranthese position on begin */
				    p = out;
		   	        }

				/* p is on begin (fixed) or   */
				/* on negativ sign (floating) */
				*p = '(';     

				/* Add space for alignment */
				if (parFxdFlg == TRUE)
				{
				    for(k = i-decPrintLen;
					k <= decLen+percentLen+1; k++)
					out[i++] = ' ';
				}

				out[i++]=')';      /* at end */
			    }	
			    else  
				out[i++] = ' ';    /* at end, for alignement */
		    	}
		    }

		    /* Alignement */
            /* REF7738 - DDV - 020801 - Aligne number only if there is a decimal part */
            if (decLen > 0)
            {
		        for(k = i-decPrintLen; k <= decLen+percentLen+(parFlg==TRUE?1:0); k++)
			        out[i++] = ' ';
            }
		}
		else
		{
			out[i++] = '*';            /* Unconsistant format */
			out[i++] = '*';
			out[i++] = '*';
		}

		/*** END_OF_STRING ***/
		out[i] = END_OF_STRING;
	}
    snprintf(outRet, sizeDestStr, "%s", out);   /*  FPL-PMSTA11054-101202               */
	return(outRet);                             /*  FPL-PMSTA11054-101202 out -> outRet */
}

/************************************************************************
**
**  Function    :   CONV_StrToData()
**
**  Description :   Convert string to data depending on data C type and
**                  format for date and time.
**
**  Arguments   :   srcStr     Source string to convert
**                  cType      Datatype (DATATYPE_ENUM)
**                  maskPtr    mask (usefull for date and time conversion)
**                  dataPtr    pointer on values which will be returned
**
**  Return      :   dataPtr
**
**  Last Modif  :   30.01.96 - DED
**          SSO - 980803 - REF2600
**		    REF2819 - SSO - 980925
**          GRD - 000204 - REF4204.
**          REF7264 - 011212 - PMO : Compilation errors and warnings with C++ compiler
**          PMSTA-15918 - 070213 - PMO : Fusion on portfolio [T_AI_PE_ST] failed ; upd_exd_position : Attempt to insert NULL value into column 'end_d', table position
**			PMSTA-47385 - KOR - 05012022 : New widgets was introduced with DDDDD for MS, added a condition to fix this case.
**
*************************************************************************/
PTR CONV_StrToData(const char          *srcStr, 
                   DATATYPE_ENUM dataType, 
                   const char    *maskPtr, /* DLA - REF8728 */
                   PTR           dataPtr,
				   FLAG_T		defaulFmt)		/* ROI - 010225 - REF5635 */
{
    return CONV_StrToDataEx(
                srcStr, dataType, maskPtr, dataPtr, defaulFmt, EOF, DictAttrib_WgtTypeDefault);
}

PTR CONV_StrToDataEx(const char          *srcStr, 
                   DATATYPE_ENUM        dataType, 
                   const char           *maskPtr,       /* DLA - REF8728 */
                   PTR                  dataPtr,
				   FLAG_T		        defaulFmt,		/* ROI - 010225 - REF5635 */
                   char                 separator,
                   DICTATTRIBWGT_ENUM   widget_e)       /* PMSTA-31062 - DLA - 180430 */    
{
   char       decimSep=0;

/* SSO - 980803 - REF2600
    if (CONV_GetDecimSep(&decimSep) != RET_SUCCEED)
        return dataPtr = (PTR) NULL;
*/

    if (srcStr == NULL)
        return dataPtr = NULL;

    const CTYPE_ENUM cType = GET_CTYPE(dataType);   /* PMSTA-15918 - 070213 - PMO */

    switch(cType)
    {
    case DoubleCType :
    case UCharCType :
    case IntCType : 
    case UIntCType : 
    case ShortCType : 
    case UShortCType : 
    case TimeStampCType :           /*  FIH-PMSTA01437-PMSTA01439-070314    */
    case BinaryCType :				/* DLA - PMSTA05995 - 080410 */
	case LongLongCType:				/* DLA - PMSTA08801 - 100618 */
        {
            const char *p;
	        char *r;
            char tmp[50];
            int  intData;

            if (dataType == TzOffsetType)
            {
                int value=0;
        
                if (CONV_StringToTzOffsetType(srcStr, &value) == true)
                {
                    *(short *)dataPtr = (short)value;
                }
                else
                {
                    dataPtr = NULL;
                }
                return dataPtr;
            }

	        if (cType == DoubleCType)	       /* SSO - 980803 - REF2600 */
	        {
			    /* Manage default separator */
			    /* ROI - 010225 - REF5635 */
			    if (defaulFmt == TRUE)
				    decimSep = DECIMAL_SEP;
			    else
                if (separator != EOF)
                    decimSep = (char)separator;
                else
			    if (CONV_GetDecimSep(&decimSep) != RET_SUCCEED)
                    decimSep = DECIMAL_SEP; /* PMSTA-38841 - DDV - 200214 */
            }

            /* Suppress format marks */
            tmp[0] = END_OF_STRING;
            for (r=tmp, p=srcStr; *p!= END_OF_STRING; p++) 
            {
                /* Keep all numbers (+ negativ sign) */
                if (strchr(NBR_STR, *p))
                    *(r++) = *p;

		        if (cType == DoubleCType)	       /* SSO - 980803 - REF2600 */
		        {
		            /* Keep decimal separator */
		            if (*p == decimSep)
			        *(r++) = DECIMAL_SEP;
		        }

                /* Keep negativ sign when represent by parentheses */
                if (*p == '(')
                    *(r++) = '-';

                *r = END_OF_STRING;
            }

            /* Convert string in data C type */
            switch (cType)
            {
            case DoubleCType :
                *(double *)dataPtr = atof(tmp);
                /***** Begin REF875 pen 14/11/97 *****/
                if(GET_DECIMAL(dataType) > 0)
                {
                    *(double *)dataPtr = TLS_Round(*(double *)dataPtr,
                                                   TLS_GetNumericPrec(*(double *)dataPtr,
                                                                      GET_DECIMAL(dataType),
                                                                      NULL),
                                                   RndRule_Nearest);
                }
                /***** End   REF875 pen 14/11/97 *****/
                break;

            case UCharCType :
                intData = atoi(tmp);
                if(intData >= 0 && intData <= UCHAR_MAX)
                    *(unsigned char *)dataPtr = (unsigned char) atoi(tmp);
                else
                    dataPtr = NULL;
                break;

            case IntCType : 
                *(int *)dataPtr = (int) atol(tmp);
                break;

            case TimeStampCType :           /*  FIH-PMSTA01437-PMSTA01439-070314    */
	                sscanf(tmp, szFormatTimeStampSScanf, (TIMESTAMP_T *) dataPtr); /* PMSTA04720 - DDV - Change conversion function to avoid bad conversion */
                break;

            case BinaryCType :           /* DLA - PMSTA05995 - 080410 */
	                sscanf(tmp, szFormatTimeStampSScanf, (BINARY_T *) dataPtr); /* DLA - PMSTA05995 - 080410 */
                break;

            case UIntCType : 
                *(unsigned int *)dataPtr = (unsigned int) atol(tmp);
                break;

            case ShortCType : 
                *(short *)dataPtr = (short) atoi(tmp);
                break;

            case UShortCType : 
                *(unsigned short *)dataPtr = (unsigned short) atoi(tmp);
                break;

			case LongLongCType :	   /* DLA - PMSTA08801 - 100618 */
				sscanf(tmp, szFormatIdSScanf, (ID_T *) dataPtr); 
                break;
					
            }
        }
        break;

    case CharPtrCType :
    case TextPtrCType :			/* REF4204 */
        strcpy((char*)dataPtr, srcStr); /* REF7264 - PMO */
        break;

    case DateTimeStCType :
        {
            DATETIME_ST dt;
            DATE_T      date;

            YEAR_T      year  = 0;
            MONTH_T     month = 0;
            DAY_T       day   = 0;
            HOUR_T      hour  = 0;
            MINUTE_T    min   = 0;
            SECOND_T    sec   = 0;
            MICROSECOND_T msec = 0;

            const char *p,*s,*scan;  /* DLA - REF8728 */

            const char *list = "JAN:FEB:MAR:APR:MAY:JUN:JUL:AUG:SEP:OCT:NOV:DEC:";
    
            char hourC[3],   minC[3],  secC[3]; 
            char  dayC[3], monthC[4], yearC[5];
            NOTE_T dflt;                            /* PMSTA-31062 - DLA - 180430 */
            int    rv = 0;

            dt.date = BAD_DATE;
            dt.time = BAD_TIME;

            /* Search in format, which number is */
            /*     hour, minute, second,         */
            /*     days, months, years           */

            /* PMSTA-31062 - DLA - 180430 */
            if(widget_e == DictAttrib_WgtTypeTimeOnly)
            {
                dflt[0] = END_OF_STRING;
                if (CONV_GetDfltMask(TimeType, dflt) != RET_SUCCEED)
                {
                    p = "HH:II:SS";
                }
                else
                {
                    p = dflt;
                }
            }
            else
            {
                p = maskPtr;           /* begin of format string */
            }
            s =  srcStr;           /* begin of source string */
    

            /* V3 format */

            if (*p == 'N')
                p++;
             
            /* Manage new TimeStamp display (date + time) */
			/* MRA - 000201 - REF4115 */
			/* if (SYS_StrLen(s) >= SYS_StrLen(p)) */
                while ((*p != END_OF_STRING) && (*s != END_OF_STRING))
                {
                    switch(*p)
                    {
                    /*** SECOND ***/
                    case 'S' :
                        if (!strncmp(p, "SS", 2))
                        {
                            strncpy(secC, s, 2);
                            secC[2] = END_OF_STRING;
    
                            if (SYS_StrSpn(secC,
                                NBR_DATETIME) != 2)
                                sec = 0;
                            else
                                sec = (SECOND_T) atoi(secC);
    
                            p+=2;    /* move on format string */
                            s+=2;    /* move on source string */
                        }
                        else
                        {
                            ++p;    /* move on format string */
                            ++s;    /* move on source string */
                        }
                        break;
    
                    /*** MINUTE ***/
                    case 'I' :
                        if (!strncmp(p, "II", 2))
                        {
                            strncpy(minC, s, 2);
                            minC[2] = END_OF_STRING;
    
                            if (SYS_StrSpn(minC,
                                NBR_DATETIME) != 2)
                                min = 0;
                            else
                                min = (MINUTE_T) atoi(minC);
    
                            p+=2;    /* move on format string */
                            s+=2;    /* move on source string */
                        }
                        else
                        {
                            ++p;    /* move on format string */
                            ++s;    /* move on source string */
                        }
                        break;
    
                    /*** HOUR ***/
                    case 'H' :
                        if (!strncmp(p, "HH", 2))
                        {
                            strncpy(hourC, s, 2);
                            hourC[2] = END_OF_STRING;
    
                            if (SYS_StrSpn(hourC,
                                NBR_DATETIME) != 2)
                                hour = 0;
                            else
                                hour = (HOUR_T) atoi(hourC);
    
                            s+=2;    /* move on format string */
                            p+=2;    /* move on source string */
                        }
                        else
                        {
                            ++p;    /* move on format string */
                            ++s;    /* move on source string */
                        }
                        break;
    
                    /*** DAY ***/
                    case 'D' :
						if (strncmp(p, "DDDDD", 5))
						{
							if (!strncmp(p, "DD", 2))
							{
								strncpy(dayC, s, 2);
								dayC[2] = END_OF_STRING;

								if (SYS_StrSpn(dayC,
									NBR_DATETIME) != 2)
									day = 0;
								else
									day = (DAY_T) atoi(dayC);

								p+=2;    /* move on format string */
								s+=2;    /* move on source string */
							}
							else
							{
								++p;    /* move on format string */
								++s;    /* move on source string */
							}
						}
						else
						{
							p+=5;
							s+=5;
						}
                        break;
    
                    /*** MONTH ***/
                    case 'M' :
                        if (!strncmp(p, "MON", 3) ||
                            !strncmp(p, "MMM", 3))
                        {
			    if (islower(s[0]))          /* REF4853 - XSH - 05062000 */
                                monthC[0] = (char) _toupper(s[0]);
			else
				monthC[0] = s[0];	    /* REF4853 - XSH - 05062000 */

                            if (islower(s[1]))          /* REF4853 - XSH - 05062000 */
                                monthC[1] = (char) _toupper(s[1]);
			else
				monthC[1] = s[1];	    /* REF4853 - XSH - 05062000 */

                            if (islower(s[2]))          /* REF4853 - XSH - 05062000 */
                                monthC[2] = (char) _toupper(s[2]);
			else
				monthC[2] = s[2];	    /* REF4853 - XSH - 05062000 */
                            monthC[3] = END_OF_STRING;
    
                            if ((scan = strstr(list,
                                    monthC)) == NULL ||
                                strchr(monthC, ':') != NULL)
                                month = 0;
                            else
                                if  (strchr(monthC, ':') != NULL)
                                    month = 0;
                                else
                                    month = (MONTH_T)((scan - list) / 4 + 1);
    
                            p+=3;    /* move on format string */
                            s+=3;    /* move on source string */
                        }
                        else
                        if (!strncmp(p, "MM", 2))
                        {
                            strncpy(monthC, s, 2);
                            monthC[2] = END_OF_STRING;
    
                            if (SYS_StrSpn(monthC,
                                NBR_DATETIME) != 2)
                                month = 0;
                            else
                                month = (MONTH_T) atoi(monthC);
    
                            p+=2;    /* move on format string */
                            s+=2;    /* move on source string */
                        }
                        else
                        {
                            ++p;    /* move on format string */
                            ++s;    /* move on source string */
                        }
                        break;
    
                    /*** YEAR ***/
                    case 'Y' :
                        if (!strncmp(p, "YYYY", 4))
                        {
                            strncpy(yearC, s, 4);
                            yearC[4] = END_OF_STRING;
    
                            if (SYS_StrSpn(yearC,
                                NBR_DATETIME) != 4)
                                year = 0;
                            else
                                year = (YEAR_T) atoi(yearC);
    
                            p+=4;    /* move on format string */
                            s+=4;    /* move on source string */
                        }        
                        else
                        if (!strncmp(p, "YY", 2))
                        {
			/* REF2819 - SSO - 980925 year may be on YYYY in s, but YY in mask: take 2 last digits */
			if (SYS_StrLen(s) == SYS_StrLen(p) +2 )
				s+=2;
			strncpy(yearC, s, 2);
			yearC[2] = END_OF_STRING;
    
                            if (SYS_StrSpn(yearC,
                                NBR_DATETIME) != 2)
                                year = 0;
                            else
                            {
                                year = (YEAR_T) atoi(yearC);
                                if (year>=50 && year<100) 
                                    year += 1900; 
                                else
                                    if (year<50) year+=2000;
                            }
    
                            p+=2;    /* move on format string */
                            s+=2;    /* move on source string */
                        }
                        else
                        {
                            ++p;    /* move on format string */
                            ++s;    /* move on source string */
                        }
                        break;
    
                    /*** GO ON NEXT (skip format marks) ***/
                    default :
                        ++p;    /* move on format string */
                        ++s;    /* move on source string */
                        break;
                    }
                }

                /* PMSTA-42593 - DPT - 210218 - Gets the microseconds value from the obtained datetime string*/
                if (EV_EnableMicrosecTime)
                {
                    char *maskBuf1 = const_cast<char *>(maskPtr);

                    maskBuf1 = strstr(maskBuf1, HOUR_SEP_CHECK);
                    if (maskBuf1 == nullptr)
                    {
                        rv = fetchMicrosecsFromDatetimeStr(srcStr, &msec);
                    }
                }

            if (dataType == DateType)
            {
                /* REF2819 - SSO - 981007 changed tests order because NULL date wasn't accepted any more.. */
                /* accept NULL date */
                if (year == 0 && month == 0 && day == 0)
                {
                    date = BAD_DATE;
                    *(DATE_T *)dataPtr = date;
                }
                else
                {
		            /* Cannot enter magic end date and 
                       a date inferior to the earliest Sybase date */
                    if ( (DATE_Check(year, month, day) == FALSE) ||
                         (DATE_IsMagicEnd(year, month, day) == TRUE) ||
                         (DATE_IsDbBegin(year, month, day) == TRUE))
                    {
                        dataPtr = NULL;
                    }
                    else
                    {       
                        date = DATE_Put(year, month, day);
                        *(DATE_T *)dataPtr = date;
                    }
                }
		        /* REF2819 - SSO - 980925 check validity BEFORE DATE_IsDbBegin, because in the latest, BAD_DATE is not tested */
            }
            else
            {
                if (widget_e == DictAttrib_WgtTypeTimeOnly) /* PMSTA-31062 - DLA - 180430 */ /* HFI-PMSTA-32496-180809  Code moved before MAGIC_DATE test   */
                {
                    year  = SYB_BEGIN_YEAR;
                    month = SYB_BEGIN_MONTH;
                    day   = SYB_BEGIN_DAY;
                }

		        /* REF2819 - SSO - 981007 changed tests order because NULL date wasn't accepted any more.. */
                /* Accept NULL date if time is NULL */
                if (year == 0 && month == 0 && day == 0 &&
		            hour == 0 && min == 0 && sec == 0)
                {
                    date = BAD_DATE;
                    *(DATE_T *)dataPtr = date;
                }
                else
		        {
		            /* Cannot enter magic end date and a date inferior to the earliest Sybase date */
		            /* REF2819 - SSO - 980925 check validity BEFORE DATE_IsDbBegin, because in the latest, BAD_DATE is not tested */
                    if ( (DATE_Check(year, month, day) == FALSE)     ||
                         (TIME_Check(hour, min, sec) == FALSE)       ||
                         (DATE_IsMagicEnd(year, month, day) == TRUE) ||
                         (DATE_IsDbBegin(year, month, day) == TRUE))
                    {
                        dataPtr = NULL;
                    }
                    else
                    {       
                        if (msec != 0)
                        {
                            dt.time = TIME_Put(hour, min, sec, msec); /* PMSTA-42593 - DPT - 210218 */
                        }
                        else
                        {
                            dt.time = TIME_Put(hour, min, sec);
                        }
                        dt.date = DATE_Put(year, month, day);
                        *(DATETIME_STP)dataPtr = dt;
                    }
                }
            }
        }
        break;
    case ExtPtrCType :
    default :
        /* MSG_SendMsg(); */
        dataPtr = NULL;
        break;
    }

    return(dataPtr);
}

/************************************************************************
**
**  Function    :   CONV_GetDecPartLen()
**
**  Description :   Read a mask and determine decimal part length
**
**  Arguments   :   maskStr    mask string to read
**
**  Return      :   decimal part length
**
*************************************************************************/
int CONV_GetDecPartLen(char *maskStr)
{
	char *p;
	int  i=0;

	/* Search begin of decimal part */
	if ((p = strchr(maskStr, DECIMAL_SEP)) != NULL)
	{
		/* Count decimal part length */
		while(*p != END_OF_STRING)
		{
			if (*p == '9' || *p == '0')
				i++;
			p++;
		}
	}
	return(i);
}

/************************************************************************
**
**  Function    :   CONV_GetDecimSep()
**
**  Description :   Read decimal separator depending on user language
**
**  Arguments   :   decimSep pointer on decimal separator character
**
**  Return      :   RET_SUCCEED or error code
**
**  Modif	:   DVP338 - RAK - 970203
**
*************************************************************************/
RET_CODE CONV_GetDecimSep(char *decimSep)
{
	RET_CODE      ret=RET_SUCCEED;
	NAME_T        decimStr;

	*decimSep = DECIMAL_SEP;

	if (SYS_IsDdlGenMode() == FALSE &&
        (ret = DBA_GetUserInfo2(A_ApplUser_LangDecimSep, decimStr, TRUE)) == RET_SUCCEED) /* PMSTA12810 - DDV - 110928 - Use WUI user instead of connection's user */
	{
		*decimSep = decimStr[0];
	}

    return(ret);
}

/************************************************************************
**
**  Function    :   CONV_GetThousSep()
**
**  Description :   Read thousand separator depending on user language
**
**  Arguments   :   thousSep pointer on thousand separator character
**
**  Return      :   RET_SUCCEED or error code
**
**  Modif	:   DVP338 - RAK - 970203
**
*************************************************************************/
RET_CODE CONV_GetThousSep(char *thousSep)
{
	RET_CODE      ret=RET_SUCCEED;
	NAME_T        thousStr;

	*thousSep = THOUSAND_SEP;

	if (SYS_IsDdlGenMode() == FALSE &&
        (ret = DBA_GetUserInfo2(A_ApplUser_LangThousSep, thousStr, TRUE)) == RET_SUCCEED) /* PMSTA12810 - DDV - 110928 - Use WUI user instead of connection's user */
	{
		*thousSep = thousStr[0];
	}

    return(ret);
}

/************************************************************************
**
**  Function    :   CONV_GetDfltDateFmt()
**
**  Description :   Read date format depending on user language
**
**  Arguments   :   pointer on default format
**
**  Return      :   RET_SUCCEED or error code
**
**	Modif.		:	MRA - 000131 - REF4115
**
*************************************************************************/
RET_CODE CONV_GetDfltDateFmt(DATATYPE_ENUM dataType, char *dateFmt, char *timeFmt)
{
	RET_CODE      ret=RET_SUCCEED;

	if ((ret = DBA_GetUserInfo2(A_ApplUser_LangDateFmt, 
				   dateFmt, TRUE)) != RET_SUCCEED) /* PMSTA12810 - DDV - 110928 - Use WUI user instead of connection's user */
	{
	    if ((ret = CONV_GetDfltMask(dataType, dateFmt)) != RET_SUCCEED)
		strcpy(dateFmt, "DD/MM/YYYY");
	}

	if(timeFmt != NULL)
	/*if ((ret = DBA_GetUserInfo(A_ApplUser_LangTimeFmt, 
				   timeFmt)) != RET_SUCCEED)*/

	    if ((ret = CONV_GetDfltMask(TimeType, timeFmt)) != RET_SUCCEED)
			strcpy(timeFmt, "HH:II:SS");

	return(ret);
}

/************************************************************************
**
**  Function    :   CONV_GetDfltMask()
**
**  Description :   Return default mask according to received datatype
**
**  Arguments   :   dataType  datatype
**                  mask      pointer on mask
**
**  Return      :   RET_SUCCEED or error code
**
**	Modif.		:	ROI - 990120 - REFxxx => bug survenu lors du DVP041
**
*************************************************************************/
STATIC RET_CODE	CONV_GetDfltMask(DATATYPE_ENUM dataType, char *mask)
{
	RET_CODE ret;
    const char    *defaultMask; /* DLA - REF8728 */

	if (dataType < CodeType || dataType > TzOffsetType)	/* REFxxx => bug survenu lors du DVP041 */
	{
		ret = RET_GEN_ERR_INVARG;
	    	MSG_SendMesg(ret, 1, FILEINFO, "CONV_GetDfltMask", "dataType");
	}
	else
	{
		ret = RET_SUCCEED;
        defaultMask = GET_CONV_MASK(GET_DFLTCONVFMT(dataType));
        if  (defaultMask!=NULL)
		    strcpy(mask, defaultMask);
	}

	return(ret);
}

/************************************************************************
**
**  Function    :   CONV_SetMaskPrec()
**
**  Description :   Return default mask with updated precision
**
**  Arguments   :   dataType  datatype
**		    decNb     Decimal number ( 0 <= decNb <= 9 )
**                  mask      pointer on a pre-Allocated buffer for return (at least 30 char))
**
**  Return      :   RET_SUCCEED or error code
**
*************************************************************************/
RET_CODE	CONV_SetMaskPrec(DATATYPE_ENUM dataType, int decNb, char *mask)
{
	RET_CODE 	ret = RET_SUCCEED;
	char		*p = NULL;
	int		i,l;
	char		c;

	if(mask == NULL)
	{
	    	MSG_SendMesg(ret, 1, FILEINFO, "CONV_SetMaskPrec", "NULL buffer for return");
		ret = RET_GEN_ERR_INVARG;
		return(ret);
	}

	if(GET_CTYPE(dataType) == DoubleCType)
	{
		strcpy(mask, GET_CONV_MASK(GET_DFLTCONVFMT(dataType)));
		if ((p = strchr(mask, DECIMAL_SEP)) == NULL)
			return(ret);

		if(decNb > 0 && (l = SYS_StrLen(p)) > 0)
		{
			p++;
			c = p[0];

			for(i = 0; i<decNb ; i++)
			{
				p[i] = c;
			}
			p[i] = END_OF_STRING;
		}
		else
		{
			*p = END_OF_STRING;
		}
	}
	else
	{
		ret = RET_GEN_ERR_INVARG;
	    	MSG_SendMesg(ret, 1, FILEINFO, "CONV_SetMaskPrec", "dataType");
	}

	return(ret);
}

/************************************************************************
**
**  Function      :   CONV_HexaStringToShort
**
**  Description   :   Convert the given string to a short.
**
**  Arguments     :   A string representing an hexdecimal value. (16 bits only).
**                    A short that will handle converted value.
**
**  Return        :   RET_SUCCEED or RET_GEN_ERR_INVARG
**
**  Creation Date : 03.04.1997: GRD DVP404.
**
*************************************************************************/
RET_CODE	CONV_HexaStringToShort(char *convString, unsigned short *convData)
{
         char		charsetLower[]="abcdef";
         char		charsetUpper[]="ABCDEF";
         char *		convCursor;
	 char		tmpCursor[2];
	 unsigned short	wrkData = 0;
         int		i = 0, j = 0;


	/* Convert only 16 bits. */
	if (SYS_StrLen(convString) > 4)
	{
		return (RET_GEN_ERR_INVARG);
	}

	*convData = 0;

	for (convCursor = convString + (SYS_StrLen(convString) - 1), i = 0; i < (int)SYS_StrLen(convString); convCursor--, i++)
	{
		if ((*convCursor >= '0') && (*convCursor <= '9'))
		{
			tmpCursor[0] = *convCursor;
			tmpCursor[1] = '\0';
			wrkData = (short) atoi (tmpCursor);
		}
		else
		{
			if (((*convCursor >= 'a') && (*convCursor <= 'f')) ||
			    ((*convCursor >= 'A') && (*convCursor <= 'F')))
			{
				for (j = 0; j < 6; j++)
				{
					if ((*convCursor == charsetLower[j]) ||
					    (*convCursor == charsetUpper[j]))
					{
						wrkData = (short) (10 + j);
					}
				}
			}
			else
			{
				return (RET_GEN_ERR_INVARG);
			}
		}

		if (i == 0)
		{
			*convData = (unsigned short)(*convData + wrkData);
		}
		else
		{
			*convData = (unsigned short)(*convData + wrkData * (unsigned short) pow(16., i)); /* PMO Change the first argument type */
		}
	}

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function      :   CONV_ShortToHexaString
**
**  Description   :   Convert the given short to a string.
**                    (Only 16 bits values).
**
**  Arguments     :   A string that will handle the converted data.
**                    A short that will be converted.
**
**  Return        :   RET_SUCCEED or RET_GEN_ERR_INVARG
**
**  Creation Date : 03.04.1997: GRD DVP404.
**
*************************************************************************/
RET_CODE	CONV_ShortToHexaString(char * convString, unsigned short convShort)
{
         char		finalCharset[]="0123456789ABCDEF";
         char *		dataCursor;
unsigned short		factor[4];
unsigned short		modulus[4];
         int		i = 0;


	/* Convert only 16 bits value. */
	if (convShort > 65535)
	{
		return (RET_GEN_ERR_INVARG);
	}

	*convString = '\0';

	factor[0] = (unsigned short) (convShort / 16);
	modulus[0] = (unsigned short) (convShort % 16);

	for (i = 1; i < 4; i++)
	{
		factor[i] = (unsigned short) (factor[i - 1] / 16);
		modulus[i] = (unsigned short) (factor[i - 1] % 16);
	}

	/* Transform each of those 4 factors to characters. */
	for (i = 0, dataCursor = convString; i < 4; i++)
	{
		*dataCursor = finalCharset[modulus[3 - i]];
		dataCursor++;
	}

	*dataCursor = '\0';

	return(RET_SUCCEED);
}

/************************************************************************
**
**  Function      :   CONV_GetMonthName
**
**  Description   :   Get month name from the system message.
**
**  Arguments     :   monthNo   - Month Number between 1 to 12
**                    shortName - Flag for the name type ( short or long )
**		      buffer    - Buffer to receive the data
**
**  Return        :   RET_SUCCEED
**                    RET_GEN_ERR_INVARG
**                    RET_GEN_INFO_NODATA
**
**  Creation Date : 07.05.1997: XPE
**
*************************************************************************/

RET_CODE CONV_GetMonthName ( int monthNo, FLAG_T shortName, char* buffer )
{

   int            idx;
   RET_CODE       retCode;
   DICT_T         langDictId;
   DBA_DYNFLD_STP field;
  
   if ( monthNo < 1 || monthNo > 12 || buffer == NULL )  
      return ( RET_GEN_ERR_INVARG );
     
   buffer[0] = END_OF_STRING;
  

   /* INITIALIZE THE PARAMETERS TO EXTRACT THE TEXT MESSAGE */
   
   DBA_GetUserInfo2 (A_ApplUser_LangDictId, &langDictId, TRUE ); /* PMSTA12810 - DDV - 110928 - Use WUI user instead of connection's user */
   field = ALLOC_DYNST(A_ApplMsgTxt);
  
   idx = monthNo - 1;  
   if ( shortName == FALSE )
      idx += 12;
  
  
   retCode = DBA_GetApplMsgText ( SV_MonthGuiCodeTab[idx], 
                                  langDictId,
                                  ApplMsgNat_System,
                                  field
                                );

   /* GET MONTH NAME WITH THE SYSTEM LANGUAGE IF NEEDED (ENGLISH)*/
   
   if ( retCode != RET_SUCCEED )
      retCode = DBA_GetApplMsgText ( SV_MonthGuiCodeTab[idx], 
                                     1,
                                     ApplMsgNat_System,
                                     field
                                   );
   
   
   if ( retCode == RET_SUCCEED )
      strcpy ( buffer, GET_NOTE( field, A_ApplMsgTxt_MsgTxt ));

   FREE_DYNST(field, A_ApplMsgTxt);  

   return ( retCode );
       
}


/************************************************************************
**
**  Function      :   CONV_GetDayName
**
**  Description   :   Get day name from the system message.
**
**  Arguments     :   dayNo     - Day Number between 0(Sun) to 6(Sat)
**		      buffer    - Buffer to receive the data
**
**  Return        :   RET_SUCCEED
**                    RET_GEN_ERR_INVARG
**                    RET_GEN_INFO_NODATA
**
**  Creation Date : 07.05.1997: XPE
**
*************************************************************************/

RET_CODE CONV_GetDayName ( int dayNo, FLAG_T shortName, char* buffer )
{

   RET_CODE       retCode;
   DICT_T         langDictId;
   DBA_DYNFLD_STP field;
  
   if ( dayNo < 0 || dayNo > 6 || buffer == NULL )  
      return ( RET_GEN_ERR_INVARG );
     
   buffer[0] = END_OF_STRING;
   if ( shortName == FALSE )
      dayNo += 7;

   /* INITIALIZE THE PARAMETERS TO EXTRACT THE TEXT MESSAGE */
   
   DBA_GetUserInfo2(A_ApplUser_LangDictId, &langDictId, TRUE); /* PMSTA12810 - DDV - 110928 - Use WUI user instead of connection's user */
   field = ALLOC_DYNST(A_ApplMsgTxt);
    
   retCode = DBA_GetApplMsgText ( SV_DayGuiCodeTab[dayNo], 
                                  langDictId,
                                  ApplMsgNat_System,
                                  field
                                );
   /* GET DAY NAME WHITH THE SYSTEM LANGUAGE IF NEEDED (ENGLISH)*/
   
   if ( retCode != RET_SUCCEED )
     retCode = DBA_GetApplMsgText ( SV_DayGuiCodeTab[dayNo], 
                                    1,
                                    ApplMsgNat_System,
                                    field
                                  );  

   if ( retCode == RET_SUCCEED )
      strcpy ( buffer, GET_NOTE( field, A_ApplMsgTxt_MsgTxt ));

   FREE_DYNST(field, A_ApplMsgTxt);  

   return ( retCode );
       
}


/************************************************************************
**
**  Function    :   CONV_Int64toInt
**
**  Description :   Cast int 64 bits to int
**
**  Arguments   :   char    pszPass     : 
**
**  Return      :   int                 : 0 if overflow and message error log
**
**  Creation    :   DLA - REF9089 - 030516
**
*************************************************************************/
int CONV_Int64toInt(int64_t i64 )
{
    if( i64 > INT_MAX || i64 < INT_MIN)
    {
	    MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "ERROR Cast int64_t to int overflow, 0 returned");
        return 0;
    }
    else
        return (int)i64;
}


/************************************************************************
**
**  Function    :   CONV_DoubleToNumericString
**
**  Description :   Convert double tu numeric string with rounding
**                  taking DBL_DIG into account
**
**  Arguments   :   double number     :
**                  int precision     :
**                  int scale         :
**                  char *target      :
**                  int *count        :
**
**  Return      :   int                 : 0 on success, -1 if overflow
**
**  Creation    :   PCL - PMSTA-24626-20170717
**
*************************************************************************/
int CONV_DoubleToNumericString(double number, int precision, int scale, char *target, int *count)
{
    int cf = 0; // carry flag

    /* fix the zero isssue */
    if (number == -0.0)
        number = 0.0;

    /* intialize count */

    if (count != NULL)
        *count = 0;

    /* intialize target */

    *target = 0;

    /* get formated string */

    char source[32];
    sprintf(
        source, "%.*e\n", DBL_DIG - 1, number);

    /* get magnitude */

    int magnitude = atoi((strchr(source, 'e') + 1));

    /* PMSTA-45665 - LJE - 210719 - Adaptation for aaa_sql call */
    if (precision == 0)
    {
        precision = magnitude + 1;
        scale     = 0;

        char *pos = strchr(source, '.') + magnitude + 1;

        int zeroCpt = 1;
        while (*pos != 'e')
        {
            if (*pos != '0')
            {
                scale += zeroCpt;
                zeroCpt = 1;
            }
            else
            {
                zeroCpt++;
            }
            pos++;
        }
        precision += scale;
    }

    /* compute header length */

    int hl = std::min(
            precision,
                precision - scale - 
                    magnitude - 1);

    /* handle overflow */

    if (hl < 0)
        return -1;

    /* compute significant length */
 
    int sl = std::min(DBL_DIG, precision - hl);

    /* get formated string (rounded) */

    if (sl != DBL_DIG && (magnitude >= 0 || scale + magnitude + 1 >= 0))
    {
        char *mark = strchr(source, '.');
        char *scan = mark;
        
        if (sl == 0)
        {
            scan--;

            if (*scan >= '5')
                cf = 1;
        }
        else
        {
            scan = mark + sl;

            if (*scan >= '5')
            {
                cf = 1;

                scan--;

                do
                {
                    if (*scan == '.')
                        scan--;

                    if (*scan < '9' || !cf )
                    {
                        *scan += (char)cf;
                        cf = 0;
                    }
                    else
                    {
                        *scan = '0';
                        cf = 1;
                    }
                }
                while (scan-- != mark -1);
            }
        }
    }

    if (hl == 0 && cf)
        return -1;
 
    /* generate string */

    char *pSource = source;
    char *pTarget = target;

    if (sl > 0 || cf)
        if (*pSource == '-')
            *pTarget++ = *pSource++;

    for (int n = 1; n <= precision; n++)
    {
        if (n <= hl)
        {
            if (n == hl && cf)
                *pTarget++= '1';
            else
            if (n >= precision - scale)
                *pTarget++= '0';
        }
        else
        if (n <= hl + sl)
        {
             *pTarget++ = *pSource++;

             if (n ==  hl + 1)
                 pSource++;
        }
        else
            *pTarget++= '0';

        if (scale && n == precision - scale)
            *pTarget++ = '.';
    }

    if (count != NULL)
        *count = (int)(pTarget - target);

    *pTarget++ = 0;

    return 0;
}

std::string CONV_DoubleToNumericString(double number, int precision, int scale)
{
    if (precision < 50)
    {
        char buffer[64];

        if (CONV_DoubleToNumericString(number, precision, scale, buffer) == 0)
            return std::string(buffer);
    }

    return std::string();
}

/************************************************************************
**
**  Function    :   CONV_GetMaxNumericAsString
**
**  Description :   Get maximum positive or negative number for a given
**                  precision and scale as a string
**
**  Arguments   :   int precision     :
**                  int scale         :
**                  bool negative     :
**                  char *target      :
**                  int *count        :
**
*************************************************************************/
void CONV_GetMaxNumericAsString(int precision, int scale, bool negative, char *target, int *count)
{
    char *pTarget = target;

    if (negative)
        *pTarget++ = '-';

    for (int n = 1; n <= precision; n++)
    {
        if (n <= precision - scale)
        {
            *pTarget++ = '9';

            if (scale && n == precision - scale)
                *pTarget++ = '.';
        }
        else
            *pTarget++ = '9';
    }

    if (count != NULL)
        *count = (int)(pTarget - target);

    *pTarget++ = 0;
}

/************************************************************************
**
**  Function     :  CONV_StringToTzOffsetType
**
**  Description  :  Get positive or negative number for a given
**                  tz_offset string
**
**  Arguments    :  tz_offset string    : accpeted format: +[-]HH:II +[-]HH 
**                  output short *value :
**
**  Return value : false if conversion error (value = 0)
**
*************************************************************************/
bool CONV_StringToTzOffsetType(const std::string &tzOffsetStr, int * value)
{
    if (tzOffsetStr.length() > 0)
    {
        std::string buff = tzOffsetStr;
        buff.erase(std::remove( buff.begin(), buff.end(), ':' ), buff.end() );  
        int sign    = 1;
        int tmp     = 0;
        int retVal  = 0;
        
        if (buff[0] == '+'){}
        else if (buff[0] == '-')
        {
            sign = -1;
        }
        else
        {
            /* PMSTA-31693 - DLA - 180613 */
            trim(buff);
            if(buff.empty() || buff.compare("0") == 0)  /* string received = "  :  " or "0" */
            {
                *value = 0;
                return true;
            }
            return false;
        }

        buff.erase(buff.begin());
        
        if(buff.length() != 2 && buff.length() != 4)
        {
            return false;
        }
        
        for(auto it = buff.begin(); it!= buff.end() ; ++it )
        {
            if( isdigit((*it)) == false)
            {
                return false;
            }
        }

        tmp = atoi(buff.substr(0,2).c_str());
        /* min max check*/
        if (sign * tmp < -12 || sign * tmp  > 14)
        {
            return false;
        }
 
        retVal = tmp*60;

        if(buff.length() > 2 )
        {
            tmp =  atoi(buff.substr(2,2).c_str());
            if(tmp>59)
            {
                return false;
            }
             retVal += tmp;
        }

        if(sign * retVal < -720 || sign * retVal > 840)
        {
            return false;
        }

        *value = sign * retVal;
    }
    else
    {
        *value = 0;
    }

    return true;
}

/************************************************************************
**
**  Function     :  CONV_TzOffsetTypeToString
**
**  Description  :  retrun the string for a tz_offset_type value and mask
**
**  Arguments    :  tz_offset value
**                  std::string mask, default used if empty (+-hh:mm)
**
**  Return value : false if conversion error (value = 0)
**
**  Modif        : HFI-PMSTA-30817-180515   Remove test on value 0 to allow the display of +00:00
**
*************************************************************************/
std::string CONV_TzOffsetTypeToString(const int value, const std::string & pMask)
{
    std::string         retStr;
    std::stringstream   sstm;
    std::string         mask = pMask;
    char                tmp[3];
    int                 hh = 0;
    int                 ii = 0;
    if (mask.length() == 0)
    {
        NOTE_T dfltMask;
        dfltMask[0] = END_OF_STRING;
        CONV_GetDfltMask(TzOffsetType, dfltMask);
        mask = dfltMask;
    }

    hh = abs(value)/60;
    ii = abs(value)%60;

    if (hh < 24 && ii < 60)
    {
        sstm << (value < 0 ? "-" : "+");
        sprintf(tmp, "%02d", hh);
        sstm << tmp;

        if (mask.length()>3)
        {
            if (mask.find(":") != std::string::npos)
            {
                sstm << ":";
            }
            sprintf(tmp, "%02d", ii);
            sstm << tmp;
        }

        retStr = sstm.str();
    }
    return retStr;
}

/************************************************************************
**
**  Function     :  CONV_TADatetimeMaskToICU
**
**  Description  :  retrun the string for a tz_offset_type value and mask
**
**  Arguments    :  tz_offset value
**                  std::string mask, default used if empty (+-hh:mm)
**
**  Return value : false if conversion error (value = 0)
**
*************************************************************************/
void CONV_TADatetimeMaskToICU(const char *maskTA, char** maskICU, FLAG_T *dispNullFlg, FLAG_T *taFmtFlg, const char escapeChar)
{

    if (maskICU == NULL)
        return;

    *dispNullFlg = FALSE;
    *taFmtFlg = FALSE;

    if (maskTA == NULL || maskTA[0] == END_OF_STRING)
        return;

    typedef struct 
    {
	    const char * fmtTA;  
        const char * fmtICU; 
        FLAG_T       isTAFmtFlg;
    } CONV_ELT_ST;

    CONV_ELT_ST convTab[] = {{"MONTH"  , "'MONTH'" , TRUE},
                             {"MON"    , "'MON'"   , TRUE},
                             {"DAY"    , "'DAY'"   , TRUE},
                             {"YYYY"   , "yyyy"    , FALSE},
                             {"YY"     , "yy"      , FALSE},
                             {"MM"     , nullptr   , FALSE},
                             {"DD"     , "dd"      , FALSE},
                             {"HH"     , nullptr   , FALSE},
                             {"H"      , nullptr   , FALSE},
                             {"II"     , "mm"      , FALSE},
                             {"I"      , "mm"      , FALSE},
                             {"SS"     , "ss"      , FALSE},
                             {"S"      , "ss"      , FALSE},
                             {"XXXXX"  , nullptr   , FALSE},
                             {"XXXX"   , nullptr   , FALSE},
                             {"XXX"    , nullptr   , FALSE},
                             {"XX"     , nullptr   , FALSE},
                             {"X"      , nullptr   , FALSE},
                             {"xxxxx"  , nullptr   , FALSE},
                             {"xxxx"   , nullptr   , FALSE},
                             {"xxx"    , nullptr   , FALSE},
                             {"xx"     , nullptr   , FALSE},
                             {"x"      , nullptr   , FALSE},
                             {"ZZZZZ"  , nullptr   , FALSE},
                             {"ZZZZ"   , nullptr   , FALSE},
                             {"ZZZ"    , nullptr   , FALSE},
                             {"ZZ"     , nullptr   , FALSE},
                             {"Z"      , nullptr   , FALSE},
                             {"VVVV"   , nullptr   , FALSE},
                             {"VVV"    , nullptr   , FALSE},
                             {"VV"     , nullptr   , FALSE},
                             {"V"      , nullptr   , FALSE},
                             {""       , ""        , FALSE}};

    std::string            icuFmtString;

    size_t pos = 0;
    char alphaStr[]= "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";

    if (maskTA[pos] == 'N')
    {
        *dispNullFlg = TRUE;
        pos++;
    }

    while (pos < strlen(maskTA))
    {
        if (strchr(alphaStr, maskTA[pos]) != NULL)
        {
            FLAG_T replaceFlg = FALSE;
            int    convIdx = 0;

            do
            {
                if (strncmp(&(maskTA[pos]), convTab[convIdx].fmtTA, strlen(convTab[convIdx].fmtTA)) == 0)
                {
                    if (convTab[convIdx].fmtICU != nullptr)
                    {
                        icuFmtString += convTab[convIdx].fmtICU;
                    }
                    else
                    {
                        icuFmtString += convTab[convIdx].fmtTA;
                    }

                    if (convTab[convIdx].isTAFmtFlg == TRUE)
                    {
                        *taFmtFlg = TRUE;
                    }

                    pos += strlen(convTab[convIdx].fmtTA);
                    replaceFlg = TRUE;
                }
            }
            while (convTab[++convIdx].fmtTA[0] != END_OF_STRING && replaceFlg == FALSE);

            if (replaceFlg == FALSE)
            {
                if (escapeChar == END_OF_STRING)
                    icuFmtString += '\'';

                do
                {
                    icuFmtString += maskTA[pos++];
                }
                while (maskTA[pos] != END_OF_STRING && strchr(alphaStr, maskTA[pos]) != NULL);

                if (escapeChar == END_OF_STRING)
                    icuFmtString += '\'';
            }
        }
        else if (maskTA[pos] == escapeChar)
        {
                icuFmtString += '\'';
                pos++;

                while (maskTA[pos] != END_OF_STRING && maskTA[pos] != escapeChar)
                {
                    icuFmtString += maskTA[pos++];
                }

                if (maskTA[pos] != END_OF_STRING)
                {
                    icuFmtString += '\'';
                    pos++;
                }
        }
        else
        {
            icuFmtString += maskTA[pos++];
        }
    }

    if ((*maskICU = (char *) CALLOC(icuFmtString.length() + 1, sizeof(char))) !=  NULL)
    {
        strncpy(*maskICU, icuFmtString.c_str(), icuFmtString.length());
    }

}


/************************************************************************
**
**  Function     :  fetchMicrosecsFromDatetimeStr
**
**  Description  :  Gets the microseconds from the datetime string passed
**
**  Arguments    :  const char* string, MICROSECOND_T * microsecond
**
**  Return value :  SUCCESS
**
**  Creation Date  :  18.02.2021 - DPT - PMSTA-42593
**
*************************************************************************/
RET_CODE fetchMicrosecsFromDatetimeStr(const char* srcStr, MICROSECOND_T *msec)
{
    char *datetimeStr = const_cast<char *>(srcStr);

    datetimeStr = strstr(datetimeStr, FRACTIONAL_SEP);
    if (datetimeStr != nullptr)
    {
        *msec = (MICROSECOND_T)atoi(++datetimeStr);
    }
    return RET_SUCCEED;

}

/************************************************************************
**
**  Function     :  populateMicrosecondsIntoDateTimeStr
**
**  Description  :  Appends the microseconds into the datetime string
**                  if the mask has the microsecond format
**
**  Arguments    :  DATETIME_ST datetimeStr,char* mask,
**                  char** outputStr
**
**  Return value :  SUCCESS
**
**  Creation Date  :  18.02.2021 - DPT - PMSTA-42593
**
*************************************************************************/

RET_CODE populateMicrosecondsIntoDateTimeStr(DATETIME_ST dt, char* maskICU, char* out)
{

    int count = 0;
    char *maskBuf = maskICU;
    char *maskBuf1 = maskICU;

    maskBuf1 = strstr(maskBuf1, ":HH");
    if (maskBuf1 != nullptr)
        return RET_SUCCEED;


    for (int i = 0;i < 3;i++)
    {
        maskBuf = strstr(maskBuf, TIME_SEP);
        if (maskBuf != nullptr )
            count++;
        else
        {
            return RET_SUCCEED;
        }
        if (count == 3)
        {
            maskBuf++;
            break;
        }
        maskBuf = maskBuf + 3;
    }
    if (count == 3)
    {
        if (maskBuf != nullptr)
        {
            count = 0;
            char *dataBuf = out;

            for (int i = 0;i < 3;i++)
            {
                dataBuf = strstr(dataBuf, TIME_SEP);
                if (dataBuf != nullptr)
                    count++;
                else
                {
                    return RET_SUCCEED;
                }
                if (count == 3)
                {
                    dataBuf++;
                    break;
                }
                dataBuf = dataBuf + 3;
            }
            if (count == 3)
            {
                if (dataBuf != nullptr)
                {
                    size_t size = strlen(out);
                    for (size_t j = 1;j <= 6; j++)
                        out[size - j] = '\0';
                }
            }

            HOUR_T                     h = 0;
            MINUTE_T                   m = 0;
            SECOND_T                   s = 0;
            MICROSECOND_T              ms = 0;
            TIME_Get(dt.time, &h, &m, &s, &ms);
            if (ms != 0)
            {
                char msBuf[7] = { 0 };
                sprintf(msBuf, "%d", ms);
                msBuf[5] = '\0';
                if (EV_EnableMicrosecTime)
                {
                    strcat(out, msBuf);
                    strcat(out, ZERO_OFFSET_IND);
                }
                else
                {
                    strcat(out, DFLT_MICROSECS);
                    strcat(out, ZERO_OFFSET_IND);
                }
            }
            else
            {
                strcat(out, DFLT_MICROSECS);
                strcat(out, ZERO_OFFSET_IND);
            }
        }
    }
    return RET_SUCCEED;
}

/************************************************************************
**
**  Function     :  convDateTimeDelimToGenFmt
**
**  Description  :  Replaces the mask format having T with space
**                  to derive the correct calendar value in subsequent function.
**
**  Arguments    :  int *format, char *mask
**
**  Return value :  SUCCESS
**
** Creation Date  :  18.02.2021 - DPT - PMSTA-42593
**
*************************************************************************/

static RET_CODE convDateTimeDelimToGenFmt(FLAG_T *convFlg, char *tmpMask)
{
    size_t tMaskLen = strlen(tmpMask);
    char *maskBuf = TIME_SEP_CHECK;

    maskBuf = strstr(tmpMask, maskBuf);
    if (maskBuf != nullptr)
    {
        for (size_t j = 0; j < tMaskLen;j++)
        {
            if (tmpMask[j] == DATETIME_CHAR_SEP)
            {
                tmpMask[j] = SPACE_CHAR_SEP;
                *convFlg = TRUE;
                break;
            }
        }
    }
    return RET_SUCCEED;
}

/************************************************************************
**
**  Function     :  convGenToDateTimeDelimFmt
**
**  Description  :  Reverts the replaced space back to character T
**                  so that output string contains the T separator.
**
**  Arguments    :  int *format, char *mask
**
**  Return value :  SUCCESS
**
** Creation Date  :  18.02.2021 - DPT - PMSTA-42593
**
*************************************************************************/

static RET_CODE convGenToDateTimeDelimFmt(char *out, char *tmpMask)
{
    size_t outLen = strlen(out);
    for (size_t j = 0; j < outLen; j++)
    {
        if (out[j] == SPACE_CHAR_SEP)
        {
            out[j] = DATETIME_CHAR_SEP;
            break;
        }
    }

    size_t maskLen = strlen(tmpMask);
    for (size_t j = 0; j < maskLen; j++)
    {
        if (tmpMask[j] == SPACE_CHAR_SEP)
        {
            tmpMask[j] = DATETIME_CHAR_SEP;
            break;
        }
    }
    return RET_SUCCEED;
}

/************************************************************************
**      END  convlib.c
*************************************************************************/

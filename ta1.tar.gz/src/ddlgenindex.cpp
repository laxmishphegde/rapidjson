/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DDLGENINDEX_CPP

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H

#include      "unidef.h"     /* Mandatory */
#include         "gen.h"
#include   "ddlgenindex.h"
#include   "ddlgenfromfile.h"

using namespace std;

/************************************************************************
**      External entry points
**
*************************************************************************/

/************************************************************************
**      Local functions
**
*************************************************************************/

/************************************************************************
**      Static definitions & data
**
*************************************************************************/

/************************************************************************
**      FONCTIONS
**
************************************************************************/

/************************************************************************
**
**  Function    :   DdlGenIndex::DdlGenIndex()
**
**  Description :   Constructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 110311
**
*************************************************************************/
DdlGenIndex::DdlGenIndex(OBJECT_ENUM          paramObjectEn,
                         string               paramIdxSqlNameOnly,
                         DdlGenContext       &paramDdlGenContext,
                         DdlGenEntity        *paramDdlGenEntityPtr,
                         DdlGenFile          *paramFileHelper,
                         TARGET_TABLE_ENUM    paramTargetTableEn)
    : DdlGen(paramObjectEn, DdlObj_Index, paramDdlGenContext, nullptr, paramDdlGenEntityPtr, paramFileHelper, paramTargetTableEn)
    , m_duplicateManagment(DuplicateManagment::None)
    , indexFunctionEn(IdxFunction_None)
    , bUniqueOnly(false)
    , bClusteredOnly(false)
    , idxSqlNameOnly(paramIdxSqlNameOnly)
    , currXdIndexStp(nullptr)
    , currSysXdIndexStp(nullptr)
    , bIdxByExternalInfo(false)
{
    init(paramObjectEn,
         DynType_All,
         TRUE,
         FALSE,
         FALSE,
         EntSecuLevel_NoSecured,
         FALSE);

    this->shDictSegmentStp = ALLOC_DYNST(S_DictSegment);
}

/************************************************************************
**
**  Function    :   DdlGenIndex::DdlGenIndex()
**
**  Description :   Constructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 110311
**
*************************************************************************/
DdlGenIndex::DdlGenIndex(OBJECT_ENUM       paramObjectEn,
                         DdlGenContext    &paramDdlGenContext,
                         DdlGenEntity     *paramDdlGenEntityPtr,
                         TARGET_TABLE_ENUM paramTargetTableEn)
    : DdlGen(paramObjectEn, DdlObj_Index, paramDdlGenContext, nullptr, paramDdlGenEntityPtr, nullptr, paramTargetTableEn)
    , m_duplicateManagment(DuplicateManagment::None)
    , indexFunctionEn(IdxFunction_None)
    , bUniqueOnly(false)
    , bClusteredOnly(false)
    , currXdIndexStp(nullptr)
    , currSysXdIndexStp(nullptr)
    , bIdxByExternalInfo(true)
{
    init(paramObjectEn,
         DynType_All,
         TRUE,
         FALSE,
         FALSE,
         EntSecuLevel_NoSecured,
         FALSE);

    this->shDictSegmentStp = nullptr;
}


/************************************************************************
**
**  Function    :   DdlGenIndex::~DdlGenIndex()
**
**  Description :   Destructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 110311
**
*************************************************************************/
DdlGenIndex::~DdlGenIndex()
{
    if (this->bIdxByExternalInfo == false)
    {
        FREE_DYNST(this->shDictSegmentStp, S_DictSegment);
    }
}

/************************************************************************
**
**  Function    :   DdlGenIndex::setSpecificIdx()
**
**  Description :   Constructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14086 - LJE - 121004
**
*************************************************************************/
RET_CODE DdlGenIndex::setSpecificIdx(DBA_IDX_FUNCTION_ENUM paramIndexFunctionEn,
                                     bool                  paramUniqueOnly,
                                     bool                  paramClusteredOnly)
{
    RET_CODE            ret = RET_SUCCEED;

    this->indexFunctionEn = paramIndexFunctionEn;
    this->bUniqueOnly = paramUniqueOnly;
    this->bClusteredOnly = paramClusteredOnly;

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenIndex::setName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenIndex::setName()
{
    RET_CODE            ret = RET_SUCCEED;

    if (GET_ENUM(this->currXdIndexStp, A_XdIndex_IdxFctEn) == IdxFunction_PrimaryKeyUDF ||
        GET_ENUM(this->currXdIndexStp, A_XdIndex_IdxFctEn) == IdxFunction_UserDefinedFields)
    {
        this->targetTableEn = TargetTable_UserDefinedFields;
    }
    else if (GET_ENUM(this->currXdIndexStp, A_XdIndex_IdxFctEn) == IdxFunction_PrimaryKeyPrecomp ||
             GET_ENUM(this->currXdIndexStp, A_XdIndex_IdxFctEn) == IdxFunction_PrecompIdx)
    {
        this->targetTableEn = TargetTable_Precomp;
    }
    else
    {
        this->targetTableEn = TargetTable_Main;
    }

    this->setDefaultContext();

    this->setDdlObjSqlName(GET_SYSNAME(this->currXdIndexStp, A_XdIndex_SqlName));
    this->setDdlObjFullSqlName(this->getTargetDBName(), this->getDdlObjSqlName());
    this->ddlGenContextPtr->ddlObjSqlName = this->getDdlObjSqlName();

    return ret;
}


/************************************************************************
**
**  Function    :   DdlGenIndex::getCurrSegmentSqlName()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14086 - LJE - 121005
**
*************************************************************************/
string DdlGenIndex::getCurrSegmentSqlName()
{
    string segmentName;

    if (EV_GenDdlContext.bSqlFileOnly)
    {
        if (GET_ENUM(this->currXdIndexStp, A_XdIndex_ClusteredFlg) == TRUE)
        {
            return "$SEGMENT";
        }
        else
        {
            return "$IDX_SEGMENT";
        }

    }
    else if (this->ddlGenContextPtr->m_forceIdxSeg.empty() == false)
    {
        if (this->ddlGenContextPtr->m_forceIdxSegSqlName.empty() ||
            this->ddlGenContextPtr->m_forceIdxDbSqlName.empty())
        {
            this->ddlGenContextPtr->fillForcedSegment();
        }

        this->getDdlGenContextPtr()->setDdlDestDbName(this->ddlGenContextPtr->m_forceIdxDbSqlName, this);
        return this->ddlGenContextPtr->m_forceIdxSegSqlName;
    }
    else if (this->getDdlObjEn() == DdlObj_Index)
    {
        DICT_T indexSegmentDictId = 0;

        if (IS_NULLFLD(this->currXdIndexStp, A_XdIndex_SegmentDictId) == FALSE)
        {
            indexSegmentDictId = GET_DICT(this->currXdIndexStp, A_XdIndex_SegmentDictId);
        }
        else if (GET_ENUM(this->currXdIndexStp, A_XdIndex_ClusteredFlg) == TRUE)
        {
            if (IS_NULLFLD(this->ddlGenEntityPtr->getXdEntityStp(), A_XdEntity_Segment) == FALSE)
            {
                segmentName = GET_SYSNAME(this->ddlGenEntityPtr->getXdEntityStp(), A_XdEntity_Segment);
            }
            indexSegmentDictId = GET_DICT(this->ddlGenEntityPtr->getXdEntityStp(), A_XdEntity_SegmentDictId);
        }
        else
        {
            if (this->targetTableEn == TargetTable_Precomp)
            {
                if (IS_NULLFLD(this->ddlGenEntityPtr->getXdEntityStp(), A_XdEntity_PrecompSegment) == FALSE)
                {
                    segmentName = GET_SYSNAME(this->ddlGenEntityPtr->getXdEntityStp(), A_XdEntity_PrecompSegment);
                }
                indexSegmentDictId = GET_DICT(this->ddlGenEntityPtr->getXdEntityStp(), A_XdEntity_PrecompSegmentDictId);
            }
            else
            {
                indexSegmentDictId = GET_DICT(this->ddlGenEntityPtr->getXdEntityStp(), A_XdEntity_IdxSegmentDictId);
            }
        }

        if (indexSegmentDictId != 0)
        {
            SET_ID(this->currXdIndexStp, A_XdIndex_SegmentDictId, indexSegmentDictId);
        }

        if (indexSegmentDictId != 0 &&
            segmentName.empty() &&
            this->shDictSegmentStp != nullptr)
        {
            if (indexSegmentDictId != GET_DICT(this->shDictSegmentStp, S_DictSegment_DictId))
            {
                DBA_DYNFLD_STP admArgStp = this->m_mp.allocDynst(FILEINFO, Adm_Arg);
                DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);

                SET_NULL_DYNST(admArgStp, Adm_Arg);
                SET_ID(admArgStp, Adm_Arg_Id, indexSegmentDictId);

                if (DBA_Get2(DictSegment,
                             UNUSED,
                             Adm_Arg,
                             admArgStp,
                             S_DictSegment,
                             &this->shDictSegmentStp,
                             DBA_SET_CONN | DBA_NO_CLOSE,
                             ddlGenConnGuard.getDbiConn()) != RET_SUCCEED)
                {
                    ddlGenConnGuard.getDbiConn().sendAllMsg();

                    MSG_SendMesg(RET_DBA_ERR_NODATA, 1, FILEINFO, "dict_segment", GET_DICT(this->currXdIndexStp, A_XdIndex_SegmentDictId));
                }
            }

            if (IS_NULLFLD(this->shDictSegmentStp, S_DictSegment_SqlName) == FALSE)
            {
                return string(GET_SYSNAME(this->shDictSegmentStp, S_DictSegment_SqlName));
            }
        }

    }

    return segmentName;
}

/************************************************************************
**
**  Function    :   DdlGenIndex::checkAndFixData()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:  PMSTA-14086 - LJE - 121005
**
*************************************************************************/
RET_CODE DdlGenIndex::checkAndFixData(DdlGenRequestHelper& requestHelper)
{
    RET_CODE    ret = RET_SUCCEED;

    auto &currIndexAttribMap = this->ddlGenEntityPtr->getXdIndexAttribByRankMap(this->currXdIndexStp);

    if (DdlGenDbi::isClusteredIdxAllowed() == false &&
        GET_ENUM(this->currXdIndexStp, A_XdIndex_ClusteredFlg) == TRUE)
    {
        SET_ENUM(this->currXdIndexStp, A_XdIndex_ClusteredFlg, FALSE);
    }

    /* Force the table segment for clustered index */
    if (GET_ENUM(this->currXdIndexStp, A_XdIndex_ClusteredFlg) == TRUE &&
        IS_NULLFLD(this->currXdIndexStp, A_XdIndex_SegmentDictId) == FALSE)
    {
        SET_NULL_ID(this->currXdIndexStp, A_XdIndex_SegmentDictId);
    }

    /* PMSTA- - LJE - 190821 - Remove deleted index attributes */
    for (auto it = currIndexAttribMap.begin(); it != currIndexAttribMap.end(); ++it)
    {
        if (GET_ENUM(it->second, A_XdIndexAttrib_XdActionEn) == XdAction_None &&
            GET_ENUM(it->second, A_XdIndexAttrib_XdStatusEn) == XdStatus_PhysicallyDeleted)
        {
            it = currIndexAttribMap.erase(it);
            if (it == currIndexAttribMap.end())
            {
                break;
            }
        }
    }

    if (GET_ENUM(this->currXdIndexStp, A_XdIndex_XdActionEn) == XdAction_None &&
        GET_ENUM(this->currXdIndexStp, A_XdIndex_XdStatusEn) == XdStatus_Inserted)
    {
        SET_ENUM(this->currXdIndexStp, A_XdIndex_XdActionEn, XdAction_ToInsert);
    }

    for (auto it = currIndexAttribMap.begin(); it != currIndexAttribMap.end(); ++it)
    {
        if (GET_ENUM(it->second, A_XdIndexAttrib_XdActionEn) != XdAction_ToInsert)
        {
            if (GET_ENUM(this->currXdIndexStp, A_XdIndex_XdActionEn) == XdAction_ToDelete ||
                GET_ENUM(this->currXdIndexStp, A_XdIndex_XdActionEn) == XdAction_ToPhysicallyDelete ||
                GET_ENUM(this->currXdIndexStp, A_XdIndex_XdActionEn) == XdAction_ToDeprecate ||
                GET_ENUM(this->currXdIndexStp, A_XdIndex_XdStatusEn) == XdStatus_Deprecated ||
                GET_ENUM(this->currXdIndexStp, A_XdIndex_XdStatusEn) == XdStatus_PhysicallyDeleted ||
                GET_ENUM(this->currXdIndexStp, A_XdIndex_XdStatusEn) == XdStatus_Deleted ||
                GET_ENUM(it->second, A_XdIndexAttrib_XdActionEn) == XdAction_ToDelete ||
                GET_ENUM(it->second, A_XdIndexAttrib_XdActionEn) == XdAction_ToPhysicallyDelete ||
                GET_ENUM(it->second, A_XdIndexAttrib_XdActionEn) == XdAction_ToDeprecate ||
                GET_ENUM(it->second, A_XdIndexAttrib_XdStatusEn) == XdStatus_Deprecated ||
                GET_ENUM(it->second, A_XdIndexAttrib_XdStatusEn) == XdStatus_PhysicallyDeleted ||
                GET_ENUM(it->second, A_XdIndexAttrib_XdStatusEn) == XdStatus_Deleted)
            {
                SET_ENUM(it->second, A_XdIndexAttrib_XdStatusEn, XdStatus_PhysicallyDeleted);
                SET_ENUM(it->second, A_XdIndexAttrib_XdActionEn, XdAction_None);

                if (this->ddlGenContextPtr->ddlGenAction.m_buildRuleEn != DdlGenBuildRule_DdlOnly)
                {
                    (void)requestHelper.dbaCall(Update,
                                                XdIndexAttrib,
                                                DBA_ROLE_STATUS,
                                                it->second);
                }
            }
            else
            {
                SET_ENUM(it->second, A_XdIndexAttrib_XdActionEn, XdAction_ToInsert);
            }
        }

        if (IS_NULLFLD(it->second, A_XdIndexAttrib_ColumnExpression) == FALSE)
        {
            string colExpr = this->scriptDdlGen->buildScript(GET_STRING(it->second, A_XdIndexAttrib_ColumnExpression), DdlObj_Sql);

            SET_STRING(it->second,
                       A_XdIndexAttrib_BuiltColumnExpression,
                       colExpr.substr(0, colExpr.find_last_not_of("\n") + 1).c_str());
        }
    }

    map<SMALLINT_T, DBA_DYNFLD_STP> rankTstMap;
    for (auto it = currIndexAttribMap.begin(); it != currIndexAttribMap.end(); ++it)
    {
        if (GET_ENUM(it->second, A_XdIndexAttrib_XdActionEn) == XdAction_ToInsert)
        {
            auto xdIndexAttribIt = rankTstMap.find(GET_SMALLINT(it->second, A_XdIndexAttrib_Rank));

            if (xdIndexAttribIt != rankTstMap.end())
            {
                stringstream msg;

                msg << "Duplicate key (rank_n=" << GET_SMALLINT(it->second, A_XdIndexAttrib_Rank)
                    << ") on index attributes " << GET_SYSNAME(this->currXdIndexStp, A_XdIndex_SqlName) << "." << GET_SYSNAME(it->second, A_XdIndexAttrib_XdAttribSqlName)
                    << " and " << GET_SYSNAME(this->currXdIndexStp, A_XdIndex_SqlName) << "." << GET_SYSNAME(xdIndexAttribIt->second, A_XdIndexAttrib_XdAttribSqlName);

                ret = RET_DBA_ERR_INVDATA;

                this->printMsg(ret, msg.str());
            }
            else
            {
                rankTstMap.insert(make_pair(GET_SMALLINT(it->second, A_XdIndexAttrib_Rank), it->second));
            }
        }
    }

    this->currSysXdIndexStp = nullptr;
    auto& sysXdIndexVector = this->ddlGenEntityPtr->getSysXdIndexVector();
    for (auto &it : sysXdIndexVector)
    {
        if (strcasecmp(GET_SYSNAME(this->currXdIndexStp, A_XdIndex_SqlName), GET_SYSNAME(it, A_XdIndex_SqlName)) == 0 ||
            (this->isAutoIndexOnPK() == false &&
            ((GET_ENUM(this->currXdIndexStp, A_XdIndex_IdxFctEn) == IdxFunction_PrimaryKey && GET_ENUM(it, A_XdIndex_IdxFctEn) == IdxFunction_PrimaryKey) ||
             (GET_ENUM(this->currXdIndexStp, A_XdIndex_IdxFctEn) == IdxFunction_PrimaryKeyUDF && GET_ENUM(it, A_XdIndex_IdxFctEn) == IdxFunction_PrimaryKeyUDF))))
        {
            this->currSysXdIndexStp = it;
            break;
        }
    }

    bool bAttribChecked = true;
    if (this->currSysXdIndexStp != nullptr)
    {
        SET_ENUM(this->currXdIndexStp, A_XdIndex_XdStatusEn, XdStatus_Inserted);

        if (GET_ENUM(this->currXdIndexStp, A_XdIndex_XdActionEn) != XdAction_ToDeprecate &&
            GET_ENUM(this->currXdIndexStp, A_XdIndex_XdActionEn) != XdAction_ToDelete &&
            GET_ENUM(this->currXdIndexStp, A_XdIndex_XdActionEn) != XdAction_ToPhysicallyDelete)
        {
            SET_ENUM(this->currXdIndexStp, A_XdIndex_XdActionEn, XdAction_ToInsert);

            auto &sysXdIdxAttbByRankMap = this->ddlGenEntityPtr->getSysXdIndexAttribByRankMap(this->currSysXdIndexStp);
            auto &currIndexAttribByRankMap = this->ddlGenEntityPtr->getXdIndexAttribByRankMap(this->currXdIndexStp);

            if (sysXdIdxAttbByRankMap.size() > 0 && currIndexAttribByRankMap.size() > 0)
            {
                if (sysXdIdxAttbByRankMap.size() == currIndexAttribByRankMap.size())
                {
                    for (auto it = sysXdIdxAttbByRankMap.begin(), it2 = currIndexAttribByRankMap.begin(); it != sysXdIdxAttbByRankMap.end() && it2 != currIndexAttribByRankMap.end(); ++it, ++it2)
                    {
                        string sysColExpression;

                        if (IS_NULLFLD(it->second, A_XdIndexAttrib_ColumnExpression) == FALSE)
                        {
                            sysColExpression = GET_STRING(it->second, A_XdIndexAttrib_ColumnExpression);
                            sysColExpression.erase(std::remove(sysColExpression.begin(), sysColExpression.end(), '"'), sysColExpression.end());
                        }

                        if ((IS_NULLFLD(it2->second, A_XdIndexAttrib_ColumnExpression) == TRUE &&
                             strcasecmp(GET_SYSNAME(it2->second, A_XdIndexAttrib_XdAttribSqlName), GET_SYSNAME(it->second, A_XdIndexAttrib_XdAttribSqlName)) != 0) ||
                             (IS_NULLFLD(it2->second, A_XdIndexAttrib_ColumnExpression) == FALSE &&
                              strcasecmp(GET_STRING(it2->second, A_XdIndexAttrib_BuiltColumnExpression), sysColExpression.c_str()) != 0))
                        {
                            if (IS_NULLFLD(it2->second, A_XdIndexAttrib_ColumnExpression) == FALSE)
                            {
                                string colExpression = GET_STRING(it2->second, A_XdIndexAttrib_BuiltColumnExpression);
                                string charToRemove(" \t\n");

                                for (auto toRemoveIt = charToRemove.begin(); toRemoveIt != charToRemove.end(); ++toRemoveIt)
                                {
                                    sysColExpression.erase(std::remove(sysColExpression.begin(), sysColExpression.end(), (*toRemoveIt)), sysColExpression.end());
                                    colExpression.erase(std::remove(colExpression.begin(), colExpression.end(), (*toRemoveIt)), colExpression.end());
                                }

                                if (this->ddlGenContextPtr->m_rdbmsEn == PostgreSQL)
                                {
                                    auto castPos = sysColExpression.find("::");
                                    if (castPos != string::npos)
                                    {
                                        sysColExpression.erase(castPos, sysColExpression.find_first_of(" \t\n)", castPos) - castPos);
                                    }
                                }

                                if (upper(sysColExpression) == upper(colExpression))
                                {
                                    continue;
                                }
                            }
                            bAttribChecked = false;
                            break;
                        }
                    }
                }
                else
                {
                    bAttribChecked = false;
                }
            }

            /* PMSTA-55968 - LJE - 240716 */
            if (bAttribChecked &&
                GET_ENUM(this->currSysXdIndexStp, A_XdIndex_XdStatusEn) == XdStatus_Deprecated)
            {
                SET_ENUM(this->currXdIndexStp, A_XdIndex_XdActionEn, XdAction_ToRefresh);
            }
        }
        else if (this->isAutoIndexOnPK() ||
                 GET_ENUM(this->currXdIndexStp, A_XdIndex_XdActionEn) != XdAction_ToDeprecate ||
                 (GET_ENUM(this->currXdIndexStp, A_XdIndex_IdxFctEn) != IdxFunction_PrecompIdx &&
                  GET_ENUM(this->currXdIndexStp, A_XdIndex_IdxFctEn) != IdxFunction_PrimaryKeyPrecomp))
        {
            SET_ENUM(this->currXdIndexStp, A_XdIndex_XdActionEn, XdAction_ToPhysicallyDelete);
        }
        else
        {
            this->setIndexStatus(requestHelper, XdStatus_Inserted, true);
        }
    }
    else
    {
        if (GET_ENUM(this->currXdIndexStp, A_XdIndex_XdActionEn) == XdAction_ToDelete ||
            GET_ENUM(this->currXdIndexStp, A_XdIndex_XdActionEn) == XdAction_ToPhysicallyDelete ||
            GET_ENUM(this->currXdIndexStp, A_XdIndex_XdActionEn) == XdAction_ToDeprecate ||
            (GET_ENUM(this->currXdIndexStp, A_XdIndex_XdActionEn) != XdAction_ToInsert &&
            (GET_ENUM(this->currXdIndexStp, A_XdIndex_XdStatusEn) == XdStatus_Deprecated ||
             GET_ENUM(this->currXdIndexStp, A_XdIndex_XdStatusEn) == XdStatus_PhysicallyDeleted ||
             GET_ENUM(this->currXdIndexStp, A_XdIndex_XdStatusEn) == XdStatus_Deleted)))
        {
            this->setIndexStatus(requestHelper, XdStatus_PhysicallyDeleted, true);
        }
        else
        {
            this->setIndexStatus(requestHelper, XdStatus_Untreated, false);
        }
    }

    bool bCheckScope = true;

    /* PMSTA-24007 - LJE - 170721 */
    if (this->currSysXdIndexStp &&
        GET_ENUM(this->currXdIndexStp, A_XdIndex_ScopeEn) != IdxScope_Normal &&
        GET_ENUM(this->currXdIndexStp, A_XdIndex_ScopeEn) != IdxScope_GlobalIndex &&
        GET_ENUM(this->currXdIndexStp, A_XdIndex_ScopeEn) != GET_ENUM(this->currSysXdIndexStp, A_XdIndex_ScopeEn))
    {
        bCheckScope = false;
    }
    else if ((GET_ENUM(this->ddlGenEntityPtr->getXdEntityStp(), A_XdEntity_PartAuthEn) == FeatureAuth_Enable && GET_ENUM(this->currXdIndexStp, A_XdIndex_ScopeEn) == IdxScope_GlobalOnlyIndex) ||
        (GET_ENUM(this->ddlGenEntityPtr->getXdEntityStp(), A_XdEntity_PartAuthEn) != FeatureAuth_Enable && GET_ENUM(this->currXdIndexStp, A_XdIndex_ScopeEn) == IdxScope_LocalOnlyIndex))
    {
        bCheckScope = false;
    }

    /* Check if the index in database is valid */
    if (GET_ENUM(this->currXdIndexStp, A_XdIndex_XdActionEn) == XdAction_ToInsert &&
        (this->ddlGenContextPtr->bForceReBuild == false || this->ddlGenContextPtr->ddlGenAction.m_mainDdlObjNatEn != DbObjDdlObjNat_Index) &&
        this->currSysXdIndexStp != nullptr &&
        bCheckScope && /* PMSTA-24007 - LJE - 170721 */
        bAttribChecked &&
        (CMP_DYNFLD(this->currXdIndexStp,
                   this->currSysXdIndexStp,
                   A_XdIndex_UniqueFlg, A_XdIndex_UniqueFlg, FlagType) == 0 || 
         /* PMSTA-48908 - LJE - 220420 */
          (this->isIndexDefinedOnPK() &&
          (GET_ENUM(this->currXdIndexStp, A_XdIndex_IdxFctEn) == IdxFunction_PrimaryKey ||
          GET_ENUM(this->currXdIndexStp, A_XdIndex_IdxFctEn) == IdxFunction_PrimaryKeyUDF ||
          GET_ENUM(this->currXdIndexStp, A_XdIndex_IdxFctEn) == IdxFunction_PrimaryKeyPrecomp))) &&
        this->checkXdIndexStp(this->currXdIndexStp, this->currSysXdIndexStp))
    {
        this->setIndexStatus(requestHelper, XdStatus_Inserted, true);
    }
    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenIndex::drop()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:  PMSTA-13109 - LJE - 111116
**
*************************************************************************/
RET_CODE DdlGenIndex::drop(DdlGenRequestHelper& requestHelper)
{
    RET_CODE ret = RET_SUCCEED;

    if (this->getDdlGenContextPtr()->bGenFromDbi)
    {
        return ret;
    }

    if (EV_GenDdlContext.bSqlFileOnly)
    {
        if (this->isAutoIndexOnPK() == false ||
            (GET_ENUM(this->currXdIndexStp, A_XdIndex_IdxFctEn) != IdxFunction_PrimaryKey &&
             GET_ENUM(this->currXdIndexStp, A_XdIndex_IdxFctEn) != IdxFunction_PrimaryKeyUDF &&
             GET_ENUM(this->currXdIndexStp, A_XdIndex_IdxFctEn) != IdxFunction_PrimaryKeyPrecomp))
        {
            this->bodySqlBlock
                << DdlGenDbi::getCmdPrintMsg("Dropping index " + this->getDdlObjSqlName(), false) << endl;

            this->clearIndent();
            this->bodySqlBlock << this->getCmdIfExsists(this->getCmdSelObjInDb(this->ddlGenContextPtr->getDdlDestDbName(), this->getEntitySqlName(), this->getDdlObjSqlName(), this->getDdlObjEn()),
                                                        "\t" + this->getDdlModif(DdlGenDbi::getCmdDrop(this->ddlGenContextPtr->getDdlDestDbName(), this->getEntitySqlName(), this->getDdlObjSqlName(), this->getDdlObjEn())),
                                                        string());
            this->cmdType = DDlCmdType_Drop;
            ret = this->flush();
        }
    }
    else if (GET_ENUM(this->currXdIndexStp, A_XdIndex_XdStatusEn) == XdStatus_Inserted &&
             (GET_ENUM(this->currXdIndexStp, A_XdIndex_XdActionEn) == XdAction_ToInsert ||
              GET_ENUM(this->currXdIndexStp, A_XdIndex_XdActionEn) == XdAction_ToDeprecate ||
              GET_ENUM(this->currXdIndexStp, A_XdIndex_XdActionEn) == XdAction_ToPhysicallyDelete))
    {
        this->clear();

        if (this->isAutoIndexOnPK() == true ||
            (GET_ENUM(this->currXdIndexStp, A_XdIndex_IdxFctEn) != IdxFunction_PrimaryKey &&
             GET_ENUM(this->currXdIndexStp, A_XdIndex_IdxFctEn) != IdxFunction_PrimaryKeyUDF &&
             GET_ENUM(this->currXdIndexStp, A_XdIndex_IdxFctEn) != IdxFunction_PrimaryKeyPrecomp))
        {
            DdlObjDef *primaryKeyPtr = nullptr;

            if (this->ddlGenContextPtr->m_rdbmsEn == Oracle &&
                this->getDictEntityStp()->pkRuleEn == PkRule_Identity)
            {
                auto sysIdxAttribMap = this->ddlGenEntityPtr->getSysXdIndexAttribByRankMap(this->currSysXdIndexStp);
                if (sysIdxAttribMap.size() > 1)
                {
                    auto sysIdxAttribIt = sysIdxAttribMap.find(1);
                    if (sysIdxAttribIt != sysIdxAttribMap.end() &&
                        strcasecmp(GET_SYSNAME(sysIdxAttribIt->second, A_XdIndexAttrib_XdAttribSqlName), this->getDictEntityStp()->primKeyTab[0]->sqlName) == 0)
                    {
                        DdlObjDefKey searchDdlObjDefKey(this->ddlGenContextPtr->m_rdbmsEn,
                                                        DdlObj_PrimaryKey,
                                                        this->ddlGenContextPtr->getDdlDestDbName(),
                                                        this->getEntitySqlName(),
                                                        this->getEntitySqlName(),
                                                        this->getEntitySqlName());

                        DdlGenDbaAccessGuard ddlGenDbaAccessGuard(*this->ddlGenContextPtr);
                        primaryKeyPtr = ddlGenDbaAccessGuard.getDdlGenDbaAccess().getDdlObjDef(searchDdlObjDefKey);

                        if (primaryKeyPtr != nullptr)
                        {
                            /* Disable the primary key of the current entity */
                            this->bodySqlBlock << this->getCmdChangeState(this->ddlGenContextPtr->getDdlDestDbName(), this->getEntitySqlName(), string(), DdlObj_PrimaryKey, true);
                            this->cmdType = DDlCmdType_DbProcess;
                            ret = this->flush("Disable primary key");
                        }
                    }
                }
            }

            this->bodySqlBlock << this->getCmdDrop(this->ddlGenContextPtr->getDdlDestDbName(), this->getEntitySqlName(), this->getDdlObjSqlName(), DdlObj_Index);

            this->cmdType = DDlCmdType_Drop;
            ret = this->flush("Dropping index");

            if (ret == RET_SUCCEED)
            {
                this->setIndexStatus(requestHelper, XdStatus_PhysicallyDeleted, (GET_ENUM(this->currXdIndexStp, A_XdIndex_XdActionEn) != XdAction_ToInsert));
            }

            if (primaryKeyPtr != nullptr)
            {
                if (primaryKeyPtr->check())
                {
                    /* Enable the primary key of the current entity */
                    this->bodySqlBlock << this->getCmdChangeState(this->ddlGenContextPtr->getDdlDestDbName(), this->getEntitySqlName(), string(), DdlObj_PrimaryKey, false);
                    this->cmdType = DDlCmdType_DbProcess;
                    ret = this->flush("Enable primary key");

                    std::map<DdlObjDefKey, DdlObjDef>  foreignKeyDefMap;
                    this->getAllDdlObjListFromDb(foreignKeyDefMap,
                                                 this->ddlGenContextPtr->getDdlDestDbName(),
                                                 this->getEntitySqlName(),
                                                 this->getEntitySqlName(),
                                                 DdlObj_ReversedForeignKey);

                    for (auto fkIt = foreignKeyDefMap.begin(); fkIt != foreignKeyDefMap.end(); ++fkIt)
                    {
                        /* Enable all the foreign keys on current entity */
                        this->bodySqlBlock << this->getCmdChangeState(this->ddlGenContextPtr->getDdlDestDbName(),
                                                                      fkIt->second.m_refEntity,
                                                                      fkIt->second.getDbObjName(),
                                                                      DdlObj_ReversedForeignKey,
                                                                      false);
                        this->cmdType = DDlCmdType_DbProcess;
                        ret = this->flush("Enable foreign key from entity " + fkIt->second.m_refEntity);
                    }
                }
            }
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenIndex::create()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenIndex::create(DdlGenRequestHelper* requestHelperPtr)
{
    RET_CODE    ret = RET_SUCCEED;
    bool        bFirst = true;
    bool        bPkIdx = false;

    auto           &currIndexAttribByRankMap = this->ddlGenEntityPtr->getXdIndexAttribByRankMap(this->currXdIndexStp);

    if (this->getDictEntityStp()->entNatEn == EntityNat_TempTable &&
        SYS_IsDdlGenMode() == TRUE &&
        DdlGenDbi::getTempTableSpec(this->ddlGenContextPtr->m_rdbmsEn, this->getDictEntityStp()) == DdlGenDbi::TempTableSpec::Session)
    {
        return RET_GEN_INFO_NOACTION;
    }

    if (GET_ENUM(this->currXdIndexStp, A_XdIndex_XdActionEn) == XdAction_ToRefresh)
    {
        if (this->ddlGenContextPtr->bDisable == false)
        {
            this->bodySqlBlock << this->getCmdChangeState(this->ddlGenContextPtr->getDdlDestDbName(),
                                                          this->getDictEntityStp()->dbSqlName,
                                                          GET_SYSNAME(this->currXdIndexStp, A_XdIndex_SqlName),
                                                          DdlObj_Index,
                                                          false);
            this->cmdType = DDlCmdType_DbProcess;
            ret = this->flush(SYS_Stringer("Enable index ", GET_SYSNAME(this->currXdIndexStp, A_XdIndex_SqlName)));

            if (ret == RET_SRV_LIB_ERR_DUPLICATEKEY)
            {
                auto dupRet = this->removeDuplicates();

                if (dupRet == RET_SUCCEED)
                {
                    this->bodySqlBlock << this->getCmdChangeState(this->ddlGenContextPtr->getDdlDestDbName(),
                                                                  this->getDictEntityStp()->dbSqlName,
                                                                  GET_SYSNAME(this->currXdIndexStp, A_XdIndex_SqlName),
                                                                  DdlObj_Index,
                                                                  false);
                    this->cmdType = DDlCmdType_DbProcess;
                    ret = this->flush(SYS_Stringer("Enable index ", GET_SYSNAME(this->currXdIndexStp, A_XdIndex_SqlName)));
                }
            }

            return RET_DBA_INFO_CONNECTED;
        }

        return RET_GEN_INFO_NOACTION;
    }

    if (GET_ENUM(this->currXdIndexStp, A_XdIndex_XdActionEn) != XdAction_ToInsert)
    {
        if (this->ddlGenContextPtr->bDisable)
        {
            auto& sysXdIndexVector = this->ddlGenEntityPtr->getSysXdIndexVector();
            for (auto &it : sysXdIndexVector)
            {
                if (strcasecmp(GET_SYSNAME(this->currXdIndexStp, A_XdIndex_SqlName), GET_SYSNAME(it, A_XdIndex_SqlName)) == 0)
                {
                    this->bodySqlBlock << this->getCmdChangeState(this->ddlGenContextPtr->getDdlDestDbName(),
                                                                  this->getDictEntityStp()->dbSqlName,
                                                                  GET_SYSNAME(this->currXdIndexStp, A_XdIndex_SqlName),
                                                                  DdlObj_Index,
                                                                  true);
                    this->cmdType = DDlCmdType_DbProcess;
                    ret = this->flush(SYS_Stringer("Disable index ", GET_SYSNAME(this->currXdIndexStp, A_XdIndex_SqlName)));

                    return RET_DBA_INFO_DISCONNECTED;
                }
            }
        }

        return RET_GEN_INFO_NOACTION;
    }
    else if (this->ddlGenContextPtr->bDisable)
    {
        return RET_DBA_INFO_DISCONNECTED;
    }

    if (EV_GenDdlContext.bSqlFileOnly)
    {
        this->headerStream
            << DdlGenDbi::getCmdPrintMsg("Creating index " + this->getDdlObjFullSqlName(), false) << endl;
    }

    DdlObjDef                         *primaryKeyPtr = nullptr;
    std::map<DdlObjDefKey, DdlObjDef>  foreignKeyDefMap;

    if (GET_ENUM(this->currXdIndexStp, A_XdIndex_IdxFctEn) == IdxFunction_PrimaryKey ||
        GET_ENUM(this->currXdIndexStp, A_XdIndex_IdxFctEn) == IdxFunction_PrimaryKeyUDF ||
        GET_ENUM(this->currXdIndexStp, A_XdIndex_IdxFctEn) == IdxFunction_PrimaryKeyPrecomp)
    {
        bool bDropCurrIndex = false;

        bPkIdx = true;

        this->ddlGenContextPtr->writeLock();

        DdlObjDefKey searchDdlObjDefKey(this->ddlGenContextPtr->m_rdbmsEn,
                                        DdlObj_PrimaryKey,
                                        this->ddlGenContextPtr->getDdlDestDbName(),
                                        this->getEntitySqlName(nullptr, TargetTable_Undefined, true),
                                        this->getEntitySqlName(),
                                        std::string());

        DdlGenDbaAccessGuard ddlGenDbaAccessGuard(*this->ddlGenContextPtr);
        primaryKeyPtr = ddlGenDbaAccessGuard.getDdlGenDbaAccess().getDdlObjDef(searchDdlObjDefKey);

        if (primaryKeyPtr != nullptr)
        {
            this->getAllDdlObjListFromDb(foreignKeyDefMap,
                                         this->ddlGenContextPtr->getDdlDestDbName(),
                                         this->getEntitySqlName(),
                                         this->getEntitySqlName(),
                                         DdlObj_ReversedForeignKey);

            for (auto fkIt = foreignKeyDefMap.begin(); fkIt != foreignKeyDefMap.end(); ++fkIt)
            {
                /* Disable all the foreign keys on current entity */
                this->bodySqlBlock << this->getCmdChangeState(this->ddlGenContextPtr->getDdlDestDbName(),
                                                              fkIt->second.m_refEntity,
                                                              fkIt->second.getDbObjName(),
                                                              DdlObj_ReversedForeignKey,
                                                              true);
                this->cmdType = DDlCmdType_DbProcess;
                ret = this->flush("Disable foreign key from entity " + fkIt->second.m_refEntity);
            }

            /* Disable the primary key of the current entity */
            this->bodySqlBlock << this->getCmdChangeState(this->ddlGenContextPtr->getDdlDestDbName(), this->getEntitySqlName(), string(), DdlObj_PrimaryKey, true);
            this->cmdType = DDlCmdType_DbProcess;
            ret = this->flush("Disable primary key");

            this->ddlGenEntityPtr->loadExdIndexFromSysInfo(true);

            bDropCurrIndex = true;
        }
        else if (this->currXdIndexStp != nullptr &&
                 GET_ENUM(this->currXdIndexStp, A_XdIndex_XdStatusEn) == XdStatus_Inserted)
        {
            bDropCurrIndex = true;
        }

        if (bDropCurrIndex)
        {
            auto &sysXdIndexVector = this->ddlGenEntityPtr->getSysXdIndexVector();

            this->currSysXdIndexStp = nullptr;
            for (auto it = sysXdIndexVector.begin(); it != sysXdIndexVector.end(); ++it)
            {
                if (strcasecmp(GET_SYSNAME(this->currXdIndexStp, A_XdIndex_SqlName), GET_SYSNAME(*it, A_XdIndex_SqlName)) == 0)
                {
                    this->currSysXdIndexStp = *it;
                    break;
                }

                if (GET_FLAG(*it, A_XdIndex_UniqueFlg) == TRUE)
                {
                    auto idxAttribMap = this->ddlGenEntityPtr->getSysXdIndexAttribByRankMap(*it);
                    if (idxAttribMap.size() == currIndexAttribByRankMap.size())
                    {
                        auto sysIt = idxAttribMap.begin();
                        auto currIt = currIndexAttribByRankMap.begin();
                        for (; sysIt != idxAttribMap.end(); ++sysIt, ++currIt)
                        {
                            if (strcasecmp(GET_SYSNAME(sysIt->second, A_XdIndexAttrib_XdAttribSqlName), GET_SYSNAME(currIt->second, A_XdIndexAttrib_XdAttribSqlName)) != 0)
                            {
                                break;
                            }
                        }
                        if (sysIt == idxAttribMap.end())
                        {
                            this->currSysXdIndexStp = *it;
                            break;
                        }
                    }
                }
            }

            if (this->currSysXdIndexStp)
            {
                this->bodySqlBlock << this->getCmdDrop(this->ddlGenContextPtr->getDdlDestDbName(), this->getEntitySqlName(), GET_SYSNAME(this->currSysXdIndexStp, A_XdIndex_SqlName), DdlObj_Index);

                this->cmdType = DDlCmdType_Drop;
                ret = this->flush("Dropping index");
                if (ret == RET_SUCCEED &&
                    requestHelperPtr != nullptr)
                {
                    this->setIndexStatus(*requestHelperPtr, XdStatus_PhysicallyDeleted, false);
                }
            }
            else if (requestHelperPtr != nullptr)
            {
                this->setIndexStatus(*requestHelperPtr, XdStatus_PhysicallyDeleted, false);
            }
        }

        this->ddlGenContextPtr->writeUnlock();
    }

    this->securityLevelEn = EntSecuLevel_NoSecured;
    this->custFlg         = FALSE;
    this->precompFlg      = FALSE;

    string idxSegName = this->getCurrSegmentSqlName();

    this->bodySqlBlock << this->getCmdCreateIndex(this->ddlGenContextPtr->getDdlDestDbName(),
                                                  this->getEntitySqlName(),
                                                  this->getDdlObjSqlName(),
                                                  (GET_FLAG(this->currXdIndexStp, A_XdIndex_UniqueFlg) == TRUE),
                                                  this->getDdlObjEn() != DdlObj_TempTableIndex && (GET_FLAG(this->currXdIndexStp, A_XdIndex_ClusteredFlg) == TRUE)) << "(";

    for (auto it = currIndexAttribByRankMap.begin(); it != currIndexAttribByRankMap.end(); ++it)
    {
        if (GET_ENUM(it->second, A_XdIndexAttrib_XdActionEn) == XdAction_ToInsert ||
            (this->ddlGenContextPtr->bSendInDb == false && GET_ENUM(it->second, A_XdIndexAttrib_XdStatusEn) == XdStatus_Inserted))
        {
            if (bFirst == false)
            {
                this->bodySqlBlock << ", ";
            }

            if (IS_NULLFLD(it->second, A_XdIndexAttrib_ColumnExpression) == TRUE)
            {
                this->bodySqlBlock << GET_SYSNAME(it->second, A_XdIndexAttrib_XdAttribSqlName);
            }
            else
            {
                if (this->ddlGenContextPtr->m_rdbmsEn == MSSql)     /* Temporary Workaround. SKIP Function based Index. */
                {
                    string msg;
                    
                    if (requestHelperPtr != nullptr)
                    {
                        this->setIndexStatus(*requestHelperPtr, XdStatus_PhysicallyDeleted, true);
                    }

                    msg = "Function Based Index " + string(GET_SYSNAME(this->currXdIndexStp, A_XdIndex_SqlName));
                    this->printMsg(RET_GEN_INFO_NOACTION, msg);
                    bFirst = true;
                    break;
                }

                if (IS_NULLFLD(it->second, A_XdIndexAttrib_BuiltColumnExpression) == FALSE)
                {
                    this->bodySqlBlock << GET_STRING(it->second, A_XdIndexAttrib_BuiltColumnExpression);
                }
                else
                {
                    this->bodySqlBlock << GET_STRING(it->second, A_XdIndexAttrib_ColumnExpression);
                }
            }


            if (GET_ENUM(it->second, A_XdIndexAttrib_SortRuleEn) == SortRule_Descending)
            {
                this->bodySqlBlock << " desc";
            }

            bFirst = false;
        }
    }

    if (bFirst)
    {
        ret = RET_GEN_INFO_NOACTION;
    }

    if (ret == RET_SUCCEED)
    {
        this->bodySqlBlock << this->getCmdCreateIndexFinal(this->currXdIndexStp, this->ddlGenEntityPtr);

        this->bodySqlBlock << DdlGenDbi::getCmdCreatePhysicalProperties(idxSegName, this->currXdIndexStp, &currIndexAttribByRankMap, *this->ddlGenEntityPtr, this->getDdlGenContextPtr()->bGenFromDbi);
        if (this->getDdlGenContextPtr()->bGenFromDbi == false)
        {
            this->bodySqlBlock << this->getCmdEndDDLObj();
        }

        this->ddlGenContextPtr->readLock();
        if ((ret = this->printFooter()) == RET_SUCCEED)
        {
            if (this->getDdlGenContextPtr()->bGenFromDbi)
            {
                string createStr = this->bodySqlBlock.str();

                string::size_type endlPos;
                while ((endlPos = createStr.find("\n")) != string::npos)
                {
                    createStr.replace(endlPos, 1, " ");
                }

                this->bodySqlBlock.clear();
                this->clearIndent();

                this->bodySqlBlock << this->getCmdIfExsists(this->getCmdSelObjInDb(this->ddlGenContextPtr->getDdlDestDbName(), this->getEntitySqlName(), this->getDdlObjSqlName(), this->getDdlObjEn()),
                                                            "\t" + this->getDdlModif(createStr),
                                                            string(),
                                                            true);
                if (bPkIdx &&
                    this->isIndexDefinedOnPK())
                {
                    string createIdx = this->bodySqlBlock.str();
                    this->bodySqlBlock.clear();
                    this->bodySqlBlock << this->getCmdIfExsists(this->getCmdSelObjInDb(this->ddlGenContextPtr->getDdlDestDbName(), this->getEntitySqlName(), string(), DdlObj_PrimaryKey),
                                                                "\t" + createIdx,
                                                                string(),
                                                                true);
                }
            }

            this->cmdType = DDlCmdType_Create;
            if (this->bIdxByExternalInfo == false)
            {
                ret = this->flush("Building index");
            }
            else
            {
                ret = this->flush();
            }
        }
        this->ddlGenContextPtr->readUnlock();

        /* PMSTA-34200 - LJE - 190115 */
        if (this->isIndexDefinedOnPK() && primaryKeyPtr != nullptr)
        {
            this->ddlGenContextPtr->writeLock();

            if (primaryKeyPtr->check() &&
                currIndexAttribByRankMap.size() == primaryKeyPtr->m_refAttributeTab.size())
            {
                /* modify the primary key to use the just created index */
                this->bodySqlBlock << this->getCmdModify(this->ddlGenContextPtr->getDdlDestDbName(), this->getEntitySqlName(), GET_SYSNAME(this->currXdIndexStp, A_XdIndex_SqlName), DdlObj_PrimaryKey);
                this->cmdType = DDlCmdType_DbProcess;
                ret = this->flush("Modify primary key");

                /* Enable the primary key of the current entity */
                this->bodySqlBlock << this->getCmdChangeState(this->ddlGenContextPtr->getDdlDestDbName(), this->getEntitySqlName(), string(), DdlObj_PrimaryKey, false);
                this->cmdType = DDlCmdType_DbProcess;
                ret = this->flush("Enable primary key");

                for (auto fkIt = foreignKeyDefMap.begin(); fkIt != foreignKeyDefMap.end(); ++fkIt)
                {
                    /* Enable all the foreign keys on current entity */
                    this->bodySqlBlock << this->getCmdChangeState(this->ddlGenContextPtr->getDdlDestDbName(),
                                                                  fkIt->second.m_refEntity,
                                                                  fkIt->second.getDbObjName(),
                                                                  DdlObj_ReversedForeignKey,
                                                                  false);
                    this->cmdType = DDlCmdType_DbProcess;
                    ret = this->flush("Enable foreign key from entity " + fkIt->second.m_refEntity);
                }
            }

            this->ddlGenContextPtr->writeUnlock();
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenIndex::grant()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenIndex::grant()
{
    RET_CODE            ret = RET_SUCCEED;

    this->cmdType = DDlCmdType_Grant;

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenIndex::removeDuplicates()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-55968 - LJE - 240731
**
*************************************************************************/
RET_CODE DdlGenIndex::removeDuplicates()
{
    RET_CODE            ret = RET_GEN_INFO_NOACTION;

    if (this->m_duplicateManagment != DuplicateManagment::None)
    {
        auto& currIndexAttribByRankMap = this->ddlGenEntityPtr->getXdIndexAttribByRankMap(this->currXdIndexStp);

        DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);
        RequestHelper       requestHelper(&ddlGenConnGuard.getDbiConnForDdl());
        MemoryPool          mp;
        DBA_DYNST_ENUM      recDynSt = GET_EDITGUIST(this->getDictEntityStp()->objectEn);

        std::stringstream duplicateQueryStream;

        duplicateQueryStream
            << "#SELECT " << this->getDictEntityStp()->mdSqlName << " null std" << std::endl;

        std::map<FIELD_IDX_T, DbiInOutData*> bindMap;
        for (auto& it : currIndexAttribByRankMap)
        {
            duplicateQueryStream << GET_SYSNAME(it.second, A_XdIndexAttrib_XdAttribSqlName) << std::endl;

            auto dictAttribStp = this->getDictEntityStp()->getDictAttribBySqlName(GET_SYSNAME(it.second, A_XdIndexAttrib_XdAttribSqlName));
            if (dictAttribStp != nullptr)
            {
                bindMap[dictAttribStp->progN] = requestHelper.addNewOutputData(dictAttribStp->dataTpProgN, dictAttribStp->sqlName);
            }
        }

        duplicateQueryStream
            << "#FROM" << std::endl
            << "#WHERE" << std::endl;

        duplicateQueryStream
            << "#GROUP" << std::endl;

        for (auto& it : currIndexAttribByRankMap)
        {
            duplicateQueryStream << GET_SYSNAME(it.second, A_XdIndexAttrib_XdAttribSqlName) << std::endl;
        }

        duplicateQueryStream
            << "#HAVING" << std::endl
            << "count(*) > 1" << std::endl
            << "#END" << std::endl;

        std::vector<DBA_DYNFLD_STP> dupRecordVector;

        requestHelper.setCommand(duplicateQueryStream.str());
        auto queryRet = requestHelper.sendCommandForFetch();
        if (RET_GET_LEVEL(queryRet) != RET_LEV_ERROR)
        {
            while (requestHelper.fetch() == RET_SUCCEED)
            {
                auto subRecordStp = mp.allocDynst(FILEINFO, recDynSt);

                for (auto& it : bindMap)
                {
                    if (it.second->isNull() == false)
                    {
                        DBA_CopyDynFld(subRecordStp, it.first, it.second->getDynFldStp(), 0);
                    }
                }
                dupRecordVector.push_back(subRecordStp);
            }
        }
        requestHelper.finishRequest();

        stringstream getDupFullRecordStream;
        getDupFullRecordStream
            << "#SELECT " << this->getDictEntityStp()->mdSqlName << " all std" << std::endl
            << "#FROM" << std::endl
            << "#WHERE" << std::endl;

        for (auto& it : currIndexAttribByRankMap)
        {
            getDupFullRecordStream << GET_SYSNAME(it.second, A_XdIndexAttrib_XdAttribSqlName) << " = ?" << std::endl;
        }
        getDupFullRecordStream << "#END";

        stringstream delDupFullRecordStream;
        delDupFullRecordStream
            << "#DELETE " << this->getDictEntityStp()->mdSqlName << " std" << std::endl
            << "#FROM" << std::endl
            << "#WHERE" << std::endl;

        for (auto& it : currIndexAttribByRankMap)
        {
            delDupFullRecordStream << GET_SYSNAME(it.second, A_XdIndexAttrib_XdAttribSqlName) << " = ?" << std::endl;
        }
        delDupFullRecordStream << "#END";


        const AAALogger& logger = AAALogger::get(AAALogger::Logger::Message);
        auto dupRecordStp = mp.allocDynst(FILEINFO, recDynSt);
        for (auto dupIt : dupRecordVector)
        {
            for (auto& it : bindMap)
            {
                requestHelper.addNewParam(&dupIt[it.first], false);
            }
            requestHelper.setCommand(getDupFullRecordStream.str());
            requestHelper.setDynStOutputData(recDynSt, TargetTable_Undefined);
            queryRet = requestHelper.sendCommandForFetch();
            if (RET_GET_LEVEL(queryRet) != RET_LEV_ERROR)
            {
                while (requestHelper.fetch() == RET_SUCCEED)
                {
                    requestHelper.readData(dupRecordStp);
                    bool bSep = false;
                    std::stringstream recordStrem;
                    for (auto& attribIt : this->getDictEntityStp()->attr)
                    {
                        if (attribIt->isPhysicalAttribute())
                        {
                            std::stringstream   recStream;
                            DBI_FldToDbDataStr(recStream, dupRecordStp, attribIt->progN, attribIt->dataTpProgN, true, this->ddlGenContextPtr->m_rdbmsEn, nullptr);
                            if (bSep)
                            {
                                recordStrem << ddlGenConnGuard.getDbiConnForDdl().getDelimiter();
                            }
                            else
                            {
                                bSep = true;
                            }

                            recordStrem << recStream.str();
                        }
                    }

                    if (this->m_duplicateManagment == DuplicateManagment::External)
                    {
                        this->m_onErrorRequests.push_back(recordStrem.str());
                    }
                    else
                    {
                        logger.error(recordStrem.str());
                    }
                }
            }
            requestHelper.finishRequest();

            if (this->m_duplicateManagment == DuplicateManagment::Delete)
            {
                for (auto& it : bindMap)
                {
                    requestHelper.addNewParam(&dupIt[it.first], false);
                }
                requestHelper.setCommand(delDupFullRecordStream.str());
                requestHelper.setDynStOutputData(recDynSt, TargetTable_Undefined);
                queryRet = requestHelper.sendAndGetCommand();
                if (RET_GET_LEVEL(queryRet) == RET_LEV_ERROR)
                {
                    break;
                }
                requestHelper.finishRequest();
            }
            else
            {
                ret = RET_DBA_INFO_EXIST;
            }
        }

        if (RET_GET_LEVEL(queryRet) != RET_LEV_ERROR &&
            this->m_duplicateManagment == DuplicateManagment::Delete)
        {
            this->printMsg(queryRet, SYS_Stringer("Duplicate keys of the index ",
                                                  GET_SYSNAME(this->currXdIndexStp, A_XdIndex_SqlName),
                                                  " deleted, duplicates elements on $AAAHOME/msg/error.log"));

            ret = RET_SUCCEED;
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenIndex::setIndexStatus()
**
**  Description :   Update on xd_index update also the action/status information of the entity xd_index_attrib
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 120106
**
*************************************************************************/
RET_CODE DdlGenIndex::setIndexStatus(DdlGenRequestHelper& requestHelper, XD_STATUS_ENUM xdStatusEn, bool bResetAction)
{
    RET_CODE ret = RET_SUCCEED;

    if (this->ddlGenContextPtr->ddlGenAction.m_buildRuleEn == DdlGenBuildRule_ForceBuild)
    {
        return ret;
    }

    RET_CODE        gblRet = RET_SUCCEED;
    auto           &currIndexAttribMap = this->ddlGenEntityPtr->getXdIndexAttribVector(this->currXdIndexStp);

    requestHelper.useDb(this->ddlGenContextPtr->getMainDbName());

    /* PMSTA-45413 - LJE - 210708 */
    if (GET_ENUM(this->currXdIndexStp, A_XdIndex_XdActionEn) != XdAction_None)
    {
        if (GET_ENUM(this->currXdIndexStp, A_XdIndex_XdActionEn) != XdAction_ToInsert)
        {
            xdStatusEn = XdStatus_PhysicallyDeleted;
        }

        if (bResetAction)
        {
            SET_ENUM(this->currXdIndexStp, A_XdIndex_XdActionEn, XdAction_None);
        }

        if (GET_ENUM(this->currXdIndexStp, A_XdIndex_XdStatusEn) != xdStatusEn)
        {
            SET_ENUM(this->currXdIndexStp, A_XdIndex_XdStatusEn, xdStatusEn);

            SET_DATETIME(this->currXdIndexStp, A_XdIndex_BuildDate, this->ddlGenContextPtr->getBuildDate());

            if (this->ddlGenContextPtr->ddlGenAction.m_targetSqlnameStr.empty())
            {
                if (this->ddlGenContextPtr->ddlGenAction.m_buildRuleEn != DdlGenBuildRule_DdlOnly)
                {
                    (void)requestHelper.dbaCall(Update,
                                                XdIndex,
                                                DBA_ROLE_STATUS,
                                                this->currXdIndexStp);
                }
            }

            for (auto it = currIndexAttribMap.begin(); it != currIndexAttribMap.end(); ++it)
            {
                if (GET_ENUM((*it), A_XdIndexAttrib_XdActionEn) != XdAction_None)
                {
                    if (GET_ENUM((*it), A_XdIndexAttrib_XdActionEn) == XdAction_ToInsert)
                    {
                        SET_ENUM((*it), A_XdIndexAttrib_XdStatusEn, xdStatusEn);
                    }
                    else
                    {
                        SET_ENUM((*it), A_XdIndexAttrib_XdStatusEn, XdStatus_PhysicallyDeleted);
                    }

                    if (bResetAction)
                    {
                        SET_ENUM((*it), A_XdIndexAttrib_XdActionEn, XdAction_None);
                    }
                    SET_DATETIME((*it), A_XdIndexAttrib_BuildDate, this->ddlGenContextPtr->getBuildDate());

                    if (this->ddlGenContextPtr->ddlGenAction.m_targetSqlnameStr.empty())
                    {
                        if (this->ddlGenContextPtr->ddlGenAction.m_buildRuleEn != DdlGenBuildRule_DdlOnly)
                        {
                            (void)requestHelper.dbaCall(Update,
                                                        XdIndexAttrib,
                                                        DBA_ROLE_STATUS,
                                                        (*it));
                        }
                    }
                }
            }
        }
        else if (bResetAction && 
                 this->ddlGenContextPtr->ddlGenAction.m_targetSqlnameStr.empty())
        {
            if (this->ddlGenContextPtr->ddlGenAction.m_buildRuleEn != DdlGenBuildRule_DdlOnly)
            {
                (void)requestHelper.dbaCall(Update,
                                            XdIndex,
                                            DBA_ROLE_STATUS,
                                            this->currXdIndexStp);
            }

            for (auto &it : currIndexAttribMap)
            {
                SET_ENUM(it, A_XdIndexAttrib_XdActionEn, XdAction_None);

                if (this->ddlGenContextPtr->ddlGenAction.m_buildRuleEn != DdlGenBuildRule_DdlOnly)
                {
                    (void)requestHelper.dbaCall(Update,
                                                XdIndexAttrib,
                                                DBA_ROLE_STATUS,
                                                it);
                }
            }
        }
    }
    else if (bResetAction &&
          this->ddlGenContextPtr->ddlGenAction.m_targetSqlnameStr.empty())
    {
        SET_ENUM(this->currXdIndexStp, A_XdIndex_XdStatusEn, xdStatusEn);

        if (this->ddlGenContextPtr->ddlGenAction.m_buildRuleEn != DdlGenBuildRule_DdlOnly)
        {
            (void)requestHelper.dbaCall(Update,
                                        XdIndex,
                                        DBA_ROLE_STATUS,
                                        this->currXdIndexStp);
        }

        for (auto &it : currIndexAttribMap)
        {
            SET_ENUM(it, A_XdIndexAttrib_XdActionEn, XdAction_None);
            SET_ENUM(it, A_XdIndexAttrib_XdStatusEn, xdStatusEn);

            if (this->ddlGenContextPtr->ddlGenAction.m_buildRuleEn != DdlGenBuildRule_DdlOnly)
            {
                (void)requestHelper.dbaCall(Update,
                                            XdIndexAttrib,
                                            DBA_ROLE_STATUS,
                                            it);
            }
        }
    }
    return gblRet;
}

/************************************************************************
**
**  Function    :   DdlGenIndex::build()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenIndex::build()
{
    RET_CODE ret = RET_SUCCEED, gblRet = RET_SUCCEED;
    string   msg;

	if (IS_NULLFLD(this->ddlGenEntityPtr->getXdEntityStp(), A_XdEntity_Id) == TRUE &&
        this->ddlGenContextPtr->ddlGenAction.m_buildRuleEn != DdlGenBuildRule_ForceBuild)
	{
		return RET_GEN_INFO_NOACTION;
	}

    msg = "The build of all indexes begins...";
    this->printMsg(RET_SRV_INFO_RUNNING, msg);

    if ((ret = DdlGen::build()) != RET_SUCCEED)
    {
        msg = "Create " + this->msgObjTypeStr + " on entity (" + this->getEntityMdName() + ") failed";
        this->printMsg(ret, msg);
        return ret;
    }

    MemoryPool          mp;
    DdlGenEntity       *targetDdlGenEntityPtr = this->ddlGenEntityPtr;
    DdlGenConnGuard     ddlGenConnGuard(*this->ddlGenContextPtr);
    DdlGenRequestHelper requestHelper(&ddlGenConnGuard.getDbiConn(), *this->ddlGenContextPtr);

    auto xdIndexVector = targetDdlGenEntityPtr->getXdIndexVector(); /* Don't use reference to avoid to corrupt the original indexes vector */

    if (this->ddlGenContextPtr->bGenFromDbi == false)
    {
        if (this->ddlGenContextPtr->ddlGenAction.m_targetSqlnameStr.empty() == false)
        {
            targetDdlGenEntityPtr = this->ddlGenContextPtr->getDdlGenEntityPtr(this->getDictEntityStp()->mdSqlName,
                                                                               this->ddlGenContextPtr->ddlGenAction.m_targetSqlnameStr,
                                                                               true);
            auto &targetXdIndexVector = targetDdlGenEntityPtr->getXdIndexVector();

            /* Make copy to avoid to corrupt the original indexes */
            xdIndexVector.clear();
            for (auto it = targetXdIndexVector.begin(); it != targetXdIndexVector.end(); ++it)
            {
                xdIndexVector.push_back(mp.duplicate(FILEINFO, (*it)));

                auto& xdIndexAttribMap = targetDdlGenEntityPtr->getXdIndexAttribByRankMap((*it));

                for (auto& indexAttribIt : xdIndexAttribMap)
                {
                    if (GET_A_XdIndexAttrib_XdStatusEn(indexAttribIt.second) == XdEntityXdStatusEn::Inserted)
                    {
                        SET_A_XdIndexAttrib_XdActionEn(indexAttribIt.second, XdEntityXdActionEn::ToInsert);
                    }
                }

                targetDdlGenEntityPtr->getXdIndexAttribByRankMap(xdIndexVector.back()) = xdIndexAttribMap;
            }

            string entityStr = SYS_Stringer(this->getDictEntityStp()->entDictId);
            vector<string> searchVector;
            searchVector.push_back(this->getDictEntityStp()->mdSqlName);
            searchVector.push_back(this->getDictEntityStp()->shortSqlname);
            searchVector.push_back(entityStr);

            /* Patch the sqlname of the indexes */
            for (auto it = xdIndexVector.begin(); it != xdIndexVector.end(); ++it)
            {
                this->currXdIndexStp = *it;

                SET_ENUM(this->currXdIndexStp, A_XdIndex_IdxFctEn, IdxFunction_FromTemplate);
                if (GET_A_XdIndex_XdStatusEn(this->currXdIndexStp) == XdEntityXdStatusEn::Inserted)
                {
                    SET_A_XdIndex_XdActionEn(this->currXdIndexStp, XdEntityXdActionEn::ToInsert);
                }

                string idxSqlName = GET_SYSNAME(this->currXdIndexStp, A_XdIndex_SqlName);

                for (auto searchIt = searchVector.begin(); searchIt != searchVector.end(); ++searchIt)
                {
                    string::size_type pos = idxSqlName.find(*searchIt);
                    if (pos != string::npos)
                    {
                        idxSqlName.replace(pos, searchIt->length(), this->ddlGenContextPtr->ddlGenAction.m_targetSqlnameStr);
                        if (idxSqlName.length() > this->getMaxDDLObjLength())
                        {
                            idxSqlName = GET_SYSNAME(this->currXdIndexStp, A_XdIndex_SqlName);
                            idxSqlName.replace(pos, searchIt->length(), this->ddlGenContextPtr->ddlGenAction.m_shortTargetSqlnameStr);
                        }
                        SET_SYSNAME(this->currXdIndexStp, A_XdIndex_SqlName, idxSqlName.c_str());
                        break;
                    }
                }
            }
        }

        if (this->ddlGenContextPtr->ddlGenAction.m_buildRuleEn != DdlGenBuildRule_ForceBuild)
        {
            targetDdlGenEntityPtr->loadExdIndexFromSysInfo(true);

            /* Drop not described existing indexes */
            auto& sysXdIndexVector = targetDdlGenEntityPtr->getSysXdIndexVector();

            bool bIdxDeleted = false;
            for (auto it = sysXdIndexVector.begin(); it != sysXdIndexVector.end(); ++it)
            {
                DBA_DYNFLD_STP sysXdIndexStp = *it;

                if (GET_ENUM(sysXdIndexStp, A_XdIndex_IdxFctEn) == IdxFunction_PrimaryKey ||
                    GET_ENUM(sysXdIndexStp, A_XdIndex_IdxFctEn) == IdxFunction_UserDefinedFields ||
                    GET_ENUM(sysXdIndexStp, A_XdIndex_IdxFctEn) == IdxFunction_PrimaryKeyUDF ||
                    strcasecmp(targetDdlGenEntityPtr->getPkSqlName(this->targetTableEn).c_str(), GET_SYSNAME(sysXdIndexStp, A_XdIndex_SqlName)) == 0)
                {
                    continue;
                }

                bool bFindIdx = false;
                bool bPrimaryKey = false;       /* PMSTA-45420 - LJE - 210621 */

                for (auto it2 = xdIndexVector.begin(); it2 != xdIndexVector.end(); ++it2)
                {
                    DBA_DYNFLD_STP xdIndexStp = *it2;

                    if (strcasecmp(GET_SYSNAME(sysXdIndexStp, A_XdIndex_SqlName), GET_SYSNAME(xdIndexStp, A_XdIndex_SqlName)) == 0)
                    {
                        if (GET_ENUM(xdIndexStp, A_XdIndex_XdActionEn) == XdAction_ToInsert ||
                            GET_ENUM(xdIndexStp, A_XdIndex_XdActionEn) == XdAction_ToRefresh ||
                            GET_ENUM(xdIndexStp, A_XdIndex_XdActionEn) == XdAction_None ||
                            (this->ddlGenContextPtr->ddlGenAction.m_execModeEn == DbObjExecMod_BuildFromTemplate &&
                             GET_ENUM(xdIndexStp, A_XdIndex_XdStatusEn) == XdStatus_Inserted))
                        {
                            bFindIdx = true;
                            break;
                        }

                        /* PMSTA-49178 - LJE - 221012 */
                        if (this->ddlGenContextPtr->ddlGenAction.m_mainDdlObjNatEn == DbObjDdlObjNat_TslExtension &&
                            GET_ENUM(xdIndexStp, A_XdIndex_IdxFctEn) != IdxFunction_PrecompIdx &&
                            GET_ENUM(xdIndexStp, A_XdIndex_IdxFctEn) != IdxFunction_PrimaryKeyPrecomp)
                        {
                            bFindIdx = true;
                            break;
                        }

                        /* PMSTA-45420 - LJE - 210621 */
                        if (GET_ENUM(xdIndexStp, A_XdIndex_IdxFctEn) == IdxFunction_PrimaryKey)
                        {
                            bPrimaryKey = true;
                        }
                    }
                }

                if (bFindIdx == false)
                {
                    this->currXdIndexStp = sysXdIndexStp;

                    /* PMSTA-45420 - LJE - 210621 */
                    if (bPrimaryKey)
                    {
                        DdlObjDefKey searchDdlObjDefKey(this->ddlGenContextPtr->m_rdbmsEn,
                                                        DdlObj_PrimaryKey,
                                                        this->ddlGenContextPtr->getDdlDestDbName(),
                                                        this->getEntitySqlName(nullptr, TargetTable_Undefined, true),
                                                        this->getEntitySqlName(),
                                                        std::string());

                        DdlGenDbaAccessGuard ddlGenDbaAccessGuard(*this->ddlGenContextPtr);
                        auto primaryKey = ddlGenDbaAccessGuard.getDdlGenDbaAccess().getDdlObjDef(searchDdlObjDefKey);

                        if (primaryKey != nullptr)
                        {
                            this->bodySqlBlock << this->getCmdDrop(this->ddlGenContextPtr->getDdlDestDbName(), this->getEntitySqlName(), this->ddlGenEntityPtr->getPkSqlName(this->targetTableEn), DdlObj_PrimaryKey);
                            this->cmdType = DDlCmdType_Drop;
                            ret = this->flush("Drop primary key");

                            ddlGenDbaAccessGuard.getDdlGenDbaAccess().eraseDdlObjDef(*primaryKey);
                        }
                    }

                    this->clearIndent();
                    this->setName();

                    this->bodySqlBlock << this->getCmdDrop(this->ddlGenContextPtr->getDdlDestDbName(),
                                                           this->getEntitySqlName(),
                                                           this->getDdlObjSqlName(),
                                                           this->getDdlObjEn());

                    this->cmdType = DDlCmdType_Drop;
                    ret = this->flush();

                    if (ret == RET_SUCCEED)
                    {
                        bIdxDeleted = true;
                    }
                    else
                    {
                        this->printMsg(ret, "Unable to drop the index '" + this->getDdlObjSqlName() + "' (see log file)");
                    }
                }
            }

            if (bIdxDeleted)
            {
                targetDdlGenEntityPtr->loadExdIndexFromSysInfo(true);
            }
        }
    }

    if (this->ddlGenContextPtr->ddlGenAction.m_buildRuleEn != DdlGenBuildRule_ForceBuild)
    {
        /* Drop all the indexes if needed */
        for (auto &it : xdIndexVector)
        {
            this->currXdIndexStp = it;

            if (this->ddlGenContextPtr->bGenFromDbi == true)
            {
                if (this->isAutoIndexOnPK() &&
                    (GET_ENUM(this->currXdIndexStp, A_XdIndex_IdxFctEn) == IdxFunction_PrimaryKey ||
                     GET_ENUM(this->currXdIndexStp, A_XdIndex_IdxFctEn) == IdxFunction_PrimaryKeyUDF))
                {
                    continue;
                }

                if (GET_ENUM(this->currXdIndexStp, A_XdIndex_IdxFctEn) == IdxFunction_UserDefinedFields ||
                    GET_ENUM(this->currXdIndexStp, A_XdIndex_IdxFctEn) == IdxFunction_PrimaryKeyPrecomp ||
                    GET_ENUM(this->currXdIndexStp, A_XdIndex_IdxFctEn) == IdxFunction_PrecompIdx ||
                    GET_ENUM(this->currXdIndexStp, A_XdIndex_IdxFctEn) == IdxFunction_CustomKey)            /* PMSTA-45027 - LJE - 210526 */
                {
                    continue;
                }
            }

            if (this->idxSqlNameOnly.empty() == false &&
                strcasecmp(GET_SYSNAME(this->currXdIndexStp, A_XdIndex_SqlName), this->idxSqlNameOnly.c_str()) != 0)
                continue;

            if ((ret = this->initRequest()) == RET_SUCCEED &&
                (ret = this->setName()) == RET_SUCCEED &&
                (ret = this->checkAndFixData(requestHelper)) == RET_SUCCEED)
            {
                this->drop(requestHelper);
            }
        }
    }
	
    int passNbr = 0;
    while (passNbr < 2)
    {
        /* Create all needed indexes */
        for (auto &it : xdIndexVector)
        {
            this->currXdIndexStp = it;

            if (this->ddlGenContextPtr->bGenFromDbi == true)
            {
                if (this->isAutoIndexOnPK() &&
                    (GET_ENUM(this->currXdIndexStp, A_XdIndex_IdxFctEn) == IdxFunction_PrimaryKey ||
                     GET_ENUM(this->currXdIndexStp, A_XdIndex_IdxFctEn) == IdxFunction_PrimaryKeyUDF))
                {
                    continue;
                }

                if (GET_ENUM(this->currXdIndexStp, A_XdIndex_IdxFctEn) == IdxFunction_UserDefinedFields ||
                    GET_ENUM(this->currXdIndexStp, A_XdIndex_IdxFctEn) == IdxFunction_PrimaryKeyPrecomp ||
                    GET_ENUM(this->currXdIndexStp, A_XdIndex_IdxFctEn) == IdxFunction_PrecompIdx)
                {
                    continue;
                }
            }

            if (this->idxSqlNameOnly.empty() == false &&
                strcasecmp(GET_SYSNAME(this->currXdIndexStp, A_XdIndex_SqlName), this->idxSqlNameOnly.c_str()) != 0)
                continue;

            if (passNbr == 0 &&
                GET_FLAG(this->currXdIndexStp, A_XdIndex_ClusteredFlg) == FALSE)
                continue;

            if (passNbr == 1 &&
                GET_FLAG(this->currXdIndexStp, A_XdIndex_ClusteredFlg) == TRUE)
                continue;

            if ((ret = this->initRequest()) != RET_SUCCEED ||
                (ret = this->setName()) != RET_SUCCEED ||
                (ret = this->create(&requestHelper)) != RET_SUCCEED ||
                (ret = this->grant()) != RET_SUCCEED)
            {
                if (ret == RET_GEN_INFO_NOACTION)
                {
                    if (GET_ENUM(this->currXdIndexStp, A_XdIndex_XdStatusEn) == XdStatus_PhysicallyDeleted)
                    {
                        msg = "The index " + string(GET_SYSNAME(this->currXdIndexStp, A_XdIndex_SqlName)) + " is skipped";
                    }
                    else if (GET_ENUM(this->currXdIndexStp, A_XdIndex_XdActionEn) == XdAction_ToDeprecate ||
                             GET_ENUM(this->currXdIndexStp, A_XdIndex_XdActionEn) == XdAction_ToPhysicallyDelete ||
                             GET_ENUM(this->currXdIndexStp, A_XdIndex_XdActionEn) == XdAction_ToDelete)
                    {
                        msg = "The index " + string(GET_SYSNAME(this->currXdIndexStp, A_XdIndex_SqlName)) + " is dropped";
                        this->setIndexStatus(requestHelper, XdStatus_PhysicallyDeleted, true);
                    }
                    else
                    {
                        msg = "The index " + string(GET_SYSNAME(this->currXdIndexStp, A_XdIndex_SqlName)) + " is not rebuilt";

                        if (GET_ENUM(this->currXdIndexStp, A_XdIndex_XdActionEn) != XdAction_ToRefresh)
                        {
                            this->setIndexStatus(requestHelper, XdStatus_Inserted, true);
                        }
                    }
                    this->printMsg(ret, msg);
                }
                else if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                {
                    this->setIndexStatus(requestHelper, XdStatus_Failed, true);
                    gblRet = ret;
                }
                else
                {
                    this->setIndexStatus(requestHelper, XdStatus_Inserted, true);
                }
            }
            else
            {
                this->setIndexStatus(requestHelper, XdStatus_Inserted, true);
            }

            this->targetTableEn = TargetTable_Main;
        }

        passNbr++;
    }

    this->setMsgSqlName(string());

    if (gblRet == RET_SUCCEED)
    {
        msg = "All indexes created successfully";
        this->printMsg(gblRet, msg);
    }
    else
    {
        msg = "Creating of indexes failed";
        this->printMsg(gblRet, msg);
    }

    return RET_SUCCEED; // For NuoDb 3.4.1 limitation...
    // return gblRet;
}

/************************************************************************
**
**  Function    :   DdlGenIndex::printFooter()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 111116
**
*************************************************************************/
RET_CODE DdlGenIndex::printFooter()
{
    RET_CODE ret = RET_SUCCEED;

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenIndex::getCreateCmd()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 141016
**
*************************************************************************/
string DdlGenIndex::getCreateCmd(bool bOneLine)
{
    string createCmd;

    if (this->ddlGenEntityPtr->getXdIndexVector().size() == 0)
    {
        return string();
    }

    bool bSaveSimulation = this->ddlGenContextPtr->bSimulation;
    bool bSaveSendInDb = this->ddlGenContextPtr->bSendInDb;

    this->ddlGenContextPtr->bSimulation = false;
    this->ddlGenContextPtr->bSendInDb = false;

    for (auto it = this->ddlGenEntityPtr->getXdIndexVector().begin(); it != this->ddlGenEntityPtr->getXdIndexVector().end(); ++it)
    {
        this->currXdIndexStp = *it;

        /* PMSTA-34344 - LJE - 201022 */
        if (bOneLine &&
            GET_ENUM(this->currXdIndexStp, A_XdIndex_XdStatusEn) == XdStatus_Inserted)
        {
            SET_ENUM(this->currXdIndexStp, A_XdIndex_XdActionEn, XdAction_ToInsert);
        }

        this->setName();
        this->create(nullptr);

        createCmd += this->ddlGenStream.str() + this->endOfCmd();
    }

    if (bOneLine)
    {
        std::replace(createCmd.begin(), createCmd.end(), '\n', ' ');
    }

    this->ddlGenContextPtr->bSendInDb = bSaveSendInDb;
    this->ddlGenContextPtr->bSimulation = bSaveSimulation;
    return createCmd;
}

/*************************************************************************
**   END  ddlgenindex.cpp                                        Odyssey **
*************************************************************************/


/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DBADYN_C

/************************************************************************
**      Include files
*************************************************************************/
#ifdef NTWIN
#pragma warning (push)
#endif

#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H

#include "unidef.h"     /* Mandatory */
#include "dba.h"
#include "gen.h"
#include "conv.h"
#include "date.h"
#include "ope.h"
#include "proc.h"
#include "ddlgensproc.h"

#include "dbiconnection.h"
#include "str.h"
#include "ddlgentable.h"

#include <iomanip>
#include <assert.h>
#include <limits.h>

extern RET_CODE DBA_CopyDynByHierarchy(OBJECT_ENUM, DBA_DYNFLD_STP, DbiConnectionHelper&);
extern RET_CODE DBA_SelStratLnkFct(OBJECT_ENUM, DBA_DYNFLD_STP, DBA_DYNFLD_STP**, int*, DbiConnectionHelper&); /* DVP529 */


#include "dbaprocdef.c"
#include "dbadyndef.c"
#include "dbaconvdef.c"         /* PMSTA-19123 - 081214 - PMO */
#include "descdyn.c"

#ifdef NTWIN
#pragma warning (pop)
#endif

using namespace std;

/************************************************************************
**      External entry points
**
*************************************************************************/

/************************************************************************
**      external function for dbaprocdef
*************************************************************************/
extern int EV_AAAInstallLevel;

extern std::map<std::string, std::string> EV_MaxArgSProTableMap;

extern DBA_OBJDEF_ST     SV_ObjDefGenStTab[];
extern DBA_DYNDEF_DEF_ST SV_DynDefGenStTab[];
extern DBA_CFIELDDEF_ST  SV_ManFieldDef_A_DictAttributeTemplate[];
extern DBA_CFIELDDEF_ST  SV_ManFieldDef_S_DictAttributeTemplate[];
RET_CODE DBA_CheckCopyRights (void);

/************************************************************************
**      STRUCTURE DATATYPE DEFINITION
*************************************************************************/
/* REF8844 - LJE - 030502 */
typedef struct
{
    FIELD_IDX_T          *fldNbrPtr;
    const char           *paramName;
    int                   mandatFlg;
    PROC_PARAM_TYPE_ENUM procParamTypeEn;   /* PMSTA-13109 - LJE - 111128 */
}TEMPLATE_PROCPARAM_ST, *TEMPLATE_PROCPARAM_STP;

typedef struct
{
    DBA_SERVER_TYPE_ENUM   server;
    DBA_CONNECT_TYPE_ENUM  connection;
    DBA_ACTION_ENUM        action;
    int                    subObj;
    DBA_DYNST_ENUM         *inputDynStPtr;
    DBA_DYNST_ENUM         *outputDynStPtr;
    char                   priority;
    const char             *procName;
    TEMPLATE_PROCPARAM_STP procParamDefPtr;
    DBA_OPTI_ENUM          optiIdx;
}TEMPLATE_PROC_ST;

/************************************************************************
**      Static definitions & data
*************************************************************************/
/* PMSTA-17582 - LJE - 140303 - Move here */
DBA_GUIDYNST_STP EV_EntityGuiStPtr = nullptr;
OBJECT_ENUM      EV_EntityGuiStNb = 0;
DBA_OPTI_STP     EV_OptiPtr = nullptr;

static std::map<OBJECT_ENUM, std::set<int>> SV_AutonaticSprocMap;

/************************************************************************
**      STRUCTURE DATATYPE DEFINITION  940901
*************************************************************************/
/* table referenced by DATATYPE_ENUM in header file unidef.h
 * Updated at runtime by calling DBA_UpdateDataType
 */
static DATATYPE_ST SV_DataTypeTab[] = {
    /* REF11704 - TEB - 060502 - Add the SQL name of the Sybase datatype */
    /* sqlName, cType,           maxLen,              decimal,        dfltConvFmt,      editConvFmt */

    /* CodeType */
    { "code_t", CharPtrCType, CODE_T_LEN, sizeof(CODE_T), UNUSED, CodeFmt, CodeFmt },

    /* DateType */
    { "date_t", DateTimeStCType, DATETIME_T_LEN, sizeof(DATETIME_T),UNUSED, DateFmt, DateFmt },

    /* DatetimeType */
    { "datetime_t", DateTimeStCType, DATETIME_T_LEN, sizeof(DATETIME_T),UNUSED, DateTimeFmt, DateTimeFmt },

    /* DictType */
    { "dict_t", LongLongCType, DICT_T_LEN, sizeof(DICT_T),UNUSED, DictFmt, DictFmt }, /* DLA - REF9089 - 030728 */ /* PMSTA08801 - DDV - 091126 */

    /* EnumType */
    { "enum_t", UCharCType, ENUM_T_LEN, sizeof(ENUM_T),UNUSED, EnumFmt, EnumFmt },

    /* ExchangeType */
    { "exchange_t", DoubleCType, EXCHANGE_T_LEN, sizeof(EXCHANGE_T),EXCHANGE_T_DEC, ExchangeFmt, ExchangeEFmt },

    /* FlagType */
    { "flag_t", UCharCType, FLAG_T_LEN, sizeof(FLAG_T),UNUSED, FlagFmt, FlagFmt },

    /* IdType */
    { "id_t", LongLongCType, ID_T_LEN, sizeof(ID_T),UNUSED, IdFmt, IdFmt }, /* DLA - REF9089 - 030728 */ /* PMSTA08801 - DDV - 091126 */

    /* InfoType */
    { "info_t", CharPtrCType, INFO_T_LEN, sizeof(INFO_T),UNUSED, InfoFmt, InfoFmt },

    /* IntType */
    { "int_t", IntCType, INT_T_LEN, sizeof(INT_T),UNUSED, IntFmt, IntFmt },

    /* LongnameType */
    { "longname_t", CharPtrCType, LONGNAME_T_LEN, sizeof(LONGNAME_T), UNUSED, LongnameFmt, LongnameFmt },

    /* MaskType */
    { "mask_t", IntCType, MASK_T_LEN, sizeof(MASK_T),UNUSED, MaskFmt, MaskFmt },

    /* MethodType */
    { "method_t", UCharCType, METHOD_T_LEN, sizeof(METHOD_T),UNUSED, MethodFmt, MethodFmt },

    /* NameType */
    { "name_t", CharPtrCType, NAME_T_LEN, sizeof(NAME_T),UNUSED, NameFmt, NameFmt },

    /* NoteType */
    { "note_t", CharPtrCType, NOTE_T_LEN, sizeof(NOTE_T),UNUSED, NoteFmt, NoteFmt },

    /* NumberType */
    { "number_t", DoubleCType, NUMBER_T_LEN, sizeof(NUMBER_T),NUMBER_T_DEC, NumberFmt, NumberEFmt },

    /* PercentType */
    { "percent_t", DoubleCType, PERCENT_T_LEN, sizeof(PERCENT_T),PERCENT_T_DEC, PercentFmt, PercentEFmt },

    /* PeriodType */
    { "period_t", ShortCType, PERIOD_T_LEN, sizeof(PERIOD_T),UNUSED, PeriodFmt, PeriodFmt },

    /* PhoneType */
    { "phone_t", CharPtrCType, PHONE_T_LEN, sizeof(PHONE_T),UNUSED, PhoneFmt, PhoneFmt },

    /* SmallintType */
    { "smallint_t", ShortCType, SMALLINT_T_LEN, sizeof(SMALLINT_T),UNUSED, SmallintFmt, SmallintEFmt },

    /* SysnameType */
    { "sysname_t", CharPtrCType, SYSNAME_T_LEN, sizeof(SYSNAME_T),UNUSED, SysnameFmt, SysnameFmt },

    /* TextType */
    { "text_t", TextPtrCType, TEXT_T_LEN, sizeof(TEXT_T),UNUSED, TextFmt, TextFmt },

    /* TimeType */
    { "time_t", UIntCType, TIME_T_LEN, sizeof(TIME_T),TIME_T_DEC, TimeFmt, TimeFmt },

    /* TinyintType */
    { "tinyint_t", UCharCType, TINYINT_T_LEN, sizeof(TINYINT_T),UNUSED, TinyintFmt, TinyintFmt },

    /* YearType */
    { "year_t", UShortCType, YEAR_T_LEN, sizeof(YEAR_T),UNUSED, YearFmt, YearFmt },

    /* AmountType */
    { "amount_t", DoubleCType, AMOUNT_T_LEN, sizeof(AMOUNT_T),AMOUNT_T_DEC, AmountFmt, AmountEFmt },

    /* ShortinfoType */
    { "shortinfo_t", CharPtrCType, SHORTINFO_T_LEN, sizeof(SHORTINFO_T),UNUSED, ShortinfoFmt, ShortinfoFmt },

    /* LongamountType */  /* DVP041 - 960429 - DED */
    { "longamount_t", DoubleCType, LONGAMOUNT_T_LEN, sizeof(LONGAMOUNT_T),LONGAMOUNT_T_DEC, LongamountFmt, LongamountEFmt },

    /* BlobType         */    /*  FIH-REF8832-030307  */
    { "blob_t", IntCType, LONGINT_T_LEN, sizeof(LONGINT_T),UNUSED, IntFmt, IntFmt },

    /* LongintType      */    /*  FIH-REF8832-030307  */
    { "longint_t", LongLongCType, LONGINT_T_LEN, sizeof(LONGINT_T),UNUSED, LongintFmt, LongintFmt },

    /* UrlType       */    /*  FIH-REF8832-030218  */
    { "url_t", CharPtrCType, URL_T_LEN, sizeof(URL_T),UNUSED, UrlFmt, UrlFmt },

    /*    UniCodeType         */    /*  PCL-REF9303-030724  */
    { "uni_code_t", UniCharPtrCType, CODE_T_LEN, sizeof(CODE_T),UNUSED, UniCodeFmt, UniCodeFmt },

    /*    UniInfoType         */    /*  PCL-REF9303-030724  */
    { "uni_info_t", UniCharPtrCType, INFO_T_LEN, sizeof(INFO_T),UNUSED, UniInfoFmt, UniInfoFmt },

    /*    UniLongnameType     */    /*  PCL-REF9303-030724  */
    { "uni_longname_t", UniCharPtrCType, LONGNAME_T_LEN, sizeof(LONGNAME_T),UNUSED, UniLongnameFmt, UniLongnameFmt },

    /*    UniNameType         */    /*  PCL-REF9303-030724  */
    { "uni_name_t", UniCharPtrCType, NAME_T_LEN, sizeof(UNI_NAME_T),UNUSED, UniNameFmt, UniNameFmt },

    /*    UniNoteType         */    /*  PCL-REF9303-030724  */
    { "uni_note_t", UniCharPtrCType, NOTE_T_LEN, sizeof(UNI_NOTE_T),UNUSED, UniNoteFmt, UniNoteFmt },

    /*    UniPhoneType        */    /*  PCL-REF9303-030724  */
    { "uni_phone_t", UniCharPtrCType, PHONE_T_LEN, sizeof(UNI_PHONE_T),UNUSED, UniPhoneFmt, UniPhoneFmt },

    /*    UniShortinfoType    */    /*  PCL-REF9303-030724  */
    { "uni_shortinfo_t", UniCharPtrCType, SHORTINFO_T_LEN, sizeof(UNI_SHORTINFO_T),UNUSED, UniShortinfoFmt, UniShortinfoFmt },

    /*    UniSysnameType      */    /*  PCL-REF9303-030724  */
    { "uni_sysname_t", UniCharPtrCType, SYSNAME_T_LEN, sizeof(UNI_SYSNAME_T),UNUSED, UniSysnameFmt, UniSysnameFmt },

    /*    UniTextType         */    /*  PCL-REF9303-030724  */
    { "uni_text_t", UniTextPtrCType, TEXT_T_LEN, sizeof(UNI_TEXT_T),UNUSED, UniTextFmt, UniTextFmt },

    /*    UniUrlType          */    /*  PCL-REF9303-030724  */
    { "uni_url_t", UniCharPtrCType, URL_T_LEN, sizeof(UNI_URL_T),UNUSED, UniUrlFmt, UniUrlFmt }, /* PMSTA-13109 - LJE - 111207 */

    /*    TimeStampType           */ /* REF11780 - 100406 - PMO */
    { "timestamp", TimeStampCType, TIMESTAMP_T_LEN, sizeof(TIMESTAMP_T),UNUSED, TimeStampFmt, TimeStampFmt },   /* REF11780 - 100406 - PMO */

    /*    BinaryType           */ /* DLA- PMSTA05995 - 080410 */
    { "binary_t", BinaryCType, BINARY_T_LEN, sizeof(BINARY_T),UNUSED, BinaryFmt, BinaryFmt },   /* DLA- PMSTA05995 - 080410 */

    /* String1000Type       */ /*  DLA - PMSTA07121 - 081212 */
    { "string1000_t", CharPtrCType, STRING1000_T_LEN, sizeof(STRING1000_T),UNUSED, String1000Fmt, String1000Fmt }, /*  DLA - PMSTA07121 - 081212 */

    /* String2000Type       */ /*  DLA - PMSTA07121 - 081212 */
    { "string2000_t", CharPtrCType, STRING2000_T_LEN, sizeof(STRING2000_T),UNUSED, String2000Fmt, String2000Fmt }, /*  DLA - PMSTA07121 - 081212 */

    /* String3000Type       */ /*  DLA - PMSTA07121 - 081212 */
    { "string3000_t", CharPtrCType, STRING3000_T_LEN, sizeof(STRING3000_T),UNUSED, String3000Fmt, String3000Fmt }, /*  DLA - PMSTA07121 - 081212 */

    /* String4000Type       */ /*  DLA - PMSTA07121 - 081212 */
    { "string4000_t", CharPtrCType, STRING4000_T_LEN, sizeof(STRING4000_T),UNUSED, String4000Fmt, String4000Fmt }, /*  DLA - PMSTA07121 - 081212 */

    /* UniString1000Type       */ /*  DLA - PMSTA07121 - 081212 */
    { "uni_string1000_t", UniCharPtrCType, STRING1000_T_LEN, sizeof(UNI_STRING1000_T),UNUSED, UniString1000Fmt, UniString1000Fmt }, /*  DLA - PMSTA07121 - 081212 */

    /* UniString2000Type       */ /*  DLA - PMSTA07121 - 081212 */
    { "uni_string2000_t", UniCharPtrCType, STRING2000_T_LEN, sizeof(UNI_STRING2000_T),UNUSED, UniString2000Fmt, UniString2000Fmt }, /*  DLA - PMSTA07121 - 081212 */

    /* EnumMaskType */
    { "enummask_t", LongLongCType, ENUMMASK_T_LEN, sizeof(ENUMMASK_T),UNUSED, EnumMaskFmt, EnumMaskFmt }, /* PMSTA13460 - TGU - 120420 */

    /* LongSysnameType */ /* PMSTA-14086 - LJE - 121008 */
    { "longsysname_t", CharPtrCType, LONGSYSNAME_T_LEN, sizeof(LONGSYSNAME_T),UNUSED, LongSysnameFmt, LongSysnameFmt },

    /* String7000Type       */ /*  DLA - PMSTA07121 - 081212 */
    { "string7000_t", CharPtrCType, STRING7000_T_LEN, sizeof(STRING7000_T),UNUSED, String7000Fmt, String7000Fmt }, /*  DLA - PMSTA07121 - 081212 */

    /* String15000Type       */ /*  DLA - PMSTA07121 - 081212 */
    { "string15000_t", CharPtrCType, STRING15000_T_LEN, sizeof(STRING15000_T),UNUSED, String15000Fmt, String15000Fmt }, /*  DLA - PMSTA07121 - 081212 */

    /* TimeStampTType       */ /* PMSTA-20883 - TEB - 150608 */
    { "timestamp_t", TimeStampCType, TIMESTAMP_T_LEN, sizeof(TIMESTAMP_T),UNUSED, TimeStampFmt, TimeStampFmt },

    /* TzOffsetType           */ /* PMSTA-30818 - DLA - 180403 */
    { "tz_offset_t", ShortCType, SMALLINT_T_LEN, sizeof(SMALLINT_T),UNUSED, TzOffsetFmt, TzOffsetFmt },
	
	/* PriceType              */ /* PMSTA-41768 - JPR - 201006 */
    { "price_t", DoubleCType, PRICE_T_LEN, sizeof(PRICE_T),PRICE_T_DEC, PriceFmt, PriceEFmt },

    /* UniString3000Type       */ /*  DLA - PMSTA07121 - 081212 */
    { "uni_string3000_t", UniCharPtrCType, STRING3000_T_LEN, sizeof(UNI_STRING3000_T),UNUSED, UniString3000Fmt, UniString3000Fmt }, /*  DLA - PMSTA07121 - 081212 */

    /* UniString4000Type       */ /*  DLA - PMSTA07121 - 081212 */
    { "uni_string4000_t", UniCharPtrCType, STRING4000_T_LEN, sizeof(UNI_STRING4000_T),UNUSED, UniString4000Fmt, UniString4000Fmt }, /*  DLA - PMSTA07121 - 081212 */

    /* UniString7000Type       */ /*  DLA - PMSTA07121 - 081212 */
    { "uni_string7000_t", UniCharPtrCType, STRING7000_T_LEN, sizeof(UNI_STRING7000_T),UNUSED, UniString7000Fmt, UniString7000Fmt }, /*  DLA - PMSTA07121 - 081212 */

    /* UniString15000Type       */ /*  DLA - PMSTA07121 - 081212 */
    { "uni_string15000_t", UniCharPtrCType, STRING15000_T_LEN, sizeof(UNI_STRING15000_T),UNUSED, UniString15000Fmt, UniString15000Fmt }, /*  DLA - PMSTA07121 - 081212 */

    /* ExtensionType */
    { "ExtensionType", ExtPtrCType, UNUSED, UNUSED,UNUSED, AmountFmt, AmountFmt }, /* REF7264 - PMO */

    /* ArrayType */
    { "ArrayType", ArrayPtrCType, UNUSED, UNUSED,UNUSED, AmountFmt, AmountFmt }, /* REF7264 - PMO */

    /* MultiArrayType */
    { "MultiArrayType", MultiArrayPtrCType, UNUSED, UNUSED,UNUSED, AmountFmt, AmountFmt }, /* REF7264 - PMO */

    /* LongStringType */
    { "LongStringType", CharPtrCType, LONGSTRING_T_LEN, sizeof(LONGSTRING_T),UNUSED, LongStringFmt, LongStringFmt },  /* REF1229 */

    /* PtrType */
    { "PtrType", PtrCType, UNUSED, UNUSED,UNUSED, IntFmt, IntFmt },        /*  FIH-REF9089-030513  */

    /*    VarInfoType         */ /* REF9303 - LJE - 030903 */
    { "VarInfoType", VarCharPtrCType, INFO_T_LEN, sizeof(INFO_T),UNUSED, InfoFmt, InfoFmt },

    /*    VarNoteType         */ /* REF9303 - LJE - 030903 */
    { "VarNoteType", VarCharPtrCType, INFO_T_LEN,sizeof(INFO_T), UNUSED, NoteFmt, NoteFmt },

    /*    VarNameType         */ /* REF9303 - LJE - 030903 */
    { "VarNameType", VarCharPtrCType, INFO_T_LEN, sizeof(INFO_T),UNUSED, NameFmt, NameFmt },

    /*    VarLongNameType     */ /* REF9303 - LJE - 030903 */
    { "VarLongNameType", VarCharPtrCType, INFO_T_LEN,sizeof(INFO_T), UNUSED, LongnameFmt, LongnameFmt },

    /*    VarStringType         */ /* REF9303 - LJE - 030903 */
    { "VarStringType", VarCharPtrCType, INFO_T_LEN, sizeof(INFO_T),UNUSED, InfoFmt, InfoFmt },

    /*    VarTextType           */ /* FIH-REF9303-030923  */
    { "VarTextType", VarTextPtrCType, TEXT_T_LEN, sizeof(TEXT_T),UNUSED, TextFmt, TextFmt },         /*  FIH-REF9303-030923  */

    /* VarString1000Type       */ /*  DLA - PMSTA07121 - 081212 */
    { "VarString1000Type", VarCharPtrCType, STRING1000_T_LEN,sizeof(STRING1000_T), UNUSED, String1000Fmt, String1000Fmt }, /*  DLA - PMSTA07121 - 081212 */

    /* VarString2000Type       */ /*  DLA - PMSTA07121 - 081212 */
    { "VarString2000Type", VarCharPtrCType, STRING2000_T_LEN, sizeof(STRING2000_T),UNUSED, String2000Fmt, String2000Fmt }, /*  DLA - PMSTA07121 - 081212 */

    /* VarString3000Type       */ /*  DLA - PMSTA07121 - 081212 */
    { "VarString3000Type", VarCharPtrCType, STRING3000_T_LEN, sizeof(STRING3000_T),UNUSED, String3000Fmt, String3000Fmt }, /*  DLA - PMSTA07121 - 081212 */

    /* VarString4000Type       */ /*  DLA - PMSTA07121 - 081212 */
    { "VarString4000Type", VarCharPtrCType, STRING4000_T_LEN, sizeof(STRING4000_T),UNUSED, String4000Fmt, String4000Fmt }, /*  DLA - PMSTA07121 - 081212 */

    /* VarString7000Type       */ /*  DLA - PMSTA07121 - 081212 */
    { "VarString7000Type", VarCharPtrCType, STRING7000_T_LEN, sizeof(STRING7000_T),UNUSED, String7000Fmt, String7000Fmt }, /*  DLA - PMSTA07121 - 081212 */

    /* VarString15000Type       */ /*  DLA - PMSTA07121 - 081212 */
    { "VarString15000Type", VarCharPtrCType, STRING15000_T_LEN, sizeof(STRING15000_T),UNUSED, String15000Fmt, String15000Fmt }, /*  DLA - PMSTA07121 - 081212 */

    /* SysRefCursorType       */ /* ORACLE - LJE - 140701 */
    { "SysRefCursorType", PtrCType, UNUSED, UNUSED ,UNUSED, IntFmt, IntFmt },

    /* ChainedTypeType,  */  /* PMSTA-33980 - LJE - 181206 */
    { "ChainedTypeType", PtrCType, UNUSED, UNUSED, UNUSED, IntFmt, IntFmt },

    /* RecordType       */ /* PMSTA-49178 - LJE - 220909 */
    { "RecordType", PtrCType, UNUSED, UNUSED, UNUSED, IntFmt, IntFmt },

    /* TriggerType       */ /* PMSTA-49178 - LJE - 220909 */
    { "TriggerType", PtrCType, UNUSED, UNUSED, UNUSED, IntFmt, IntFmt }

};

static_assert((sizeof(SV_DataTypeTab) / sizeof(DATATYPE_ST) == LastType), "Wrong SV_DataTypeTab definition");

OBJECT_ENUM SV_EntityGuiStTabSize;

static std::map<std::string, DBA_OBJDEF_STP> SV_ObjDefMap;
static std::map<std::string, DBA_OBJDEF_STP> SV_ObjDefByCNameMap;
static std::list<DBA_OBJDEF_STP> SV_CObjDefList;

static map<OBJECT_ENUM, DBA_DYNDEF_DEF_STP> SV_AllDynDefMap;
static map<OBJECT_ENUM, DBA_DYNDEF_DEF_STP> SV_ShortDynDefMap;
static map<DBA_DYNST_ENUM, DBA_DYNDEF_DEF_STP> SV_OtherDynDefMap;

STATIC RET_CODE DBA_AllocateVirtualObject(int); /* REF11818 - LJE - 060524 */

/************************************************************************
**
**  Function    :   DBA_ResizeMaxLenDataType()
**
**  Description :   For Sybase only resize the maxDataLen (not al32utf8)
**
**  Creation    :   PMSTA-33077 - DLA - 181005
**
*************************************************************************/
void DBA_ResizeMaxLenDataType()
{
    if (EV_RdbmsVendor == Sybase || EV_RdbmsVendor == MSSql)
    {
        for (size_t idx = 0; idx < sizeof(SV_DataTypeTab) / sizeof(SV_DataTypeTab[0]); idx++)
        {
            DATATYPE_ST& dataType = SV_DataTypeTab[idx];

            if (ICU4AAA_SQLServerUTF8 == 0 ||
                idx == SysnameType ||
                idx == LongSysnameType ||
                (EV_RdbmsVendor != MSSql && idx == String1000Type) ||
                idx == String2000Type ||
                idx == String3000Type ||
                idx == String4000Type)
            {
                if (dataType.cTypeEn == CharPtrCType || dataType.cTypeEn == TextPtrCType || dataType.cTypeEn == UniCharPtrCType)
                {
                    dataType.maxDataLen = dataType.maxLen + 1;
                }
            }
        }
    }

    if (SYS_IsDdlGenMode() == TRUE && EV_RdbmsVendor == Nuodb)
    {
        SV_DataTypeTab[TextType].maxDataLen *= 6;
    }

    for (size_t idx = 0; idx < sizeof(SV_DataTypeTab) / sizeof(SV_DataTypeTab[0]); idx++)
    {
        DATATYPE_ST & dataType = SV_DataTypeTab[idx];
        if (dataType.cTypeEn == DoubleCType)
        {
            std::stringstream ss;

            /* PMSTA-49982 - JBC - 220907 */ /* PMSTA-53341 - JBC - 230622 large scale datatype support */
            const unsigned int maxInt = dataType.maxLen - dataType.decimal <= 14 ? dataType.maxLen - dataType.decimal : 14;
            const unsigned int padInt = dataType.maxLen - dataType.decimal > 14 ? dataType.maxLen - 14 : 0;
            const unsigned int maxDec = 14 - maxInt < dataType.decimal ? 14 - maxInt : dataType.decimal;

            ss << std::setw(maxInt) << std::setfill('9') << "";
            if (padInt > 0)
            {
                ss << std::setw(padInt) << std::setfill('0') << "";
            }
            ss << "." << std::setw(maxDec) << std::setfill('9') << "";
            dataType.doubleMax = atof(ss.str().c_str());
        }
        else
        {
            dataType.doubleMax = 0.0;
        }
    }
}


/************************************************************************
**
**  Function    :   DBA_UpdateDataType()
**
**  Description :   Allow the update the length of a given datatype
**
**  Arguments   :   sqlName
**                  maxlength   New length
**
**
**  Return      :
**
**  Last Modif  :
**
**  Modif.      :   PMSTA-31145 - 260418 - PMO : SYBASE & AIX: Weird results retrieved by the financial server on basic functions
**
*************************************************************************/
void DBA_UpdateDataType(const char* sqlName, const int maxlength)
{
    for (size_t idx = 0; idx < sizeof(SV_DataTypeTab) / sizeof(SV_DataTypeTab[0]); idx++)
    {
        DATATYPE_ST & dataType = SV_DataTypeTab[idx];

        if (0 == strcmp(sqlName, dataType.sqlName))
        {
            dataType.maxLen = maxlength;
            break;
        }
    }
}


/************************************************************************
**
**  Function    :   DBA_GetObjDefStp()
**
**  Description :
**
**  Arguments   :
**
**
**  Return      :
**
**  Last Modif  :
**  Modif.      :
**
*************************************************************************/
STATIC DBA_OBJDEF_STP DBA_GetObjDefStp(OBJECT_ENUM objectEn)
{
    int objDef;
    for (objDef = 0; *(SV_ObjDefManStTab[objDef].objPosPtr) != objectEn && *(SV_ObjDefManStTab[objDef].objPosPtr) != NullEntity; objDef++);
    if (*(SV_ObjDefManStTab[objDef].objPosPtr) != objectEn)
    {
        for (objDef = 0; *(SV_ObjDefGenStTab[objDef].objPosPtr) != objectEn && *(SV_ObjDefGenStTab[objDef].objPosPtr) != NullEntity; objDef++);
        return &(SV_ObjDefGenStTab[objDef]);
    }
    return &(SV_ObjDefManStTab[objDef]);
}

/************************************************************************
**
**  Function    :   DBA_GetDynDefStp()
**
**  Description :
**
**  Arguments   :
**
**
**  Return      :
**
**  Last Modif  :
**  Modif.      :
**
*************************************************************************/
STATIC DBA_DYNDEF_STP DBA_GetDynDefStp(DBA_DYNST_ENUM dynStEnum)
{
    return EV_DynStPtr[dynStEnum].dynDefPtr;
}

/************************************************************************
**
**  Function    :   DBA_TestMDDef()
**
**  Description :
**
**  Arguments   :
**
**
**  Return      :
**
**  Last Modif  :
**  Modif.      :
**
*************************************************************************/
int DBA_TestMDDef()
{
    if (AAACHECKDYNFLD)
    {
        string           msg;
        DdlGenContext    ddlgenContext(EV_RdbmsVendor);
        DdlGenMsg        stdMsg(&ddlgenContext);

        /* PMSTA-14452 - LJE - 130109 - No test if install or generating mode */
        if (EV_AAAInstallLevel || SYS_IsSqlMode())
        {
            return RET_SUCCEED;
        }

        for (DBA_DYNST_ENUM dynStEnum = 0; dynStEnum <= LASTDYNST; dynStEnum++)
        {
            DBA_DYNDEF_STP dynDefStp = DBA_GetDynDefStp(dynStEnum);
            DBA_DYNST_STP  dynStStp = &(EV_DynStPtr[dynStEnum]);

            if (dynDefStp == nullptr)
            {
                SYS_StringFormat(msg,
                        "Empty dynamic structure definition (DynStEnum=%d)", dynStEnum);
                stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg);
            }
            else
            {
                if (dynDefStp->dynStPos != dynStEnum)
                {
                    SYS_StringFormat(msg,
                            "Invalid dynamic structure definition (DynStEnum=%d)", dynStEnum);
                    stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg);
                }

                if (dynDefStp->cFieldTab == nullptr)
                {
                    SYS_StringFormat(msg,
                            "Invalid dynamic structure \"C\" definition (DynStEnum=%d)", dynStEnum);
                    stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg);
                }
            }

            if (dynDefStp == nullptr || dynDefStp->dynStPos != dynStEnum || dynDefStp->cFieldTab == nullptr)
            {
                continue;
            }

            set<string> cNameSet;

            /* Check if the "C" definition is according the dynamic structure */
            for (int fieldPos = 0; dynDefStp->cFieldTab[fieldPos].dataTypeEnum != NullDataType; fieldPos++)
            {
                DBA_CFIELDDEF_STP cFieldStp = &(dynDefStp->cFieldTab[fieldPos]);

                if (cFieldStp != nullptr)
                {
                    if (cFieldStp->sqlName != nullptr)
                    {
                        auto insRes = cNameSet.insert(cFieldStp->sqlName);

                        if (insRes.second == false)
                        {
                            SYS_StringFormat(msg,
                                    "Duplicate 'C' name (%s) for dynst %s", cFieldStp->sqlName, dynDefStp->dynStName);
                            stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg);
                        }
                    }

                    if (cFieldStp->fieldPosPtr != NULL)
                    {
                        if ((*cFieldStp->fieldPosPtr) > dynStStp->fldNbr)
                        {
                            SYS_StringFormat(msg,
                                    "Invalid field position dynst %s field %d (%s)", dynDefStp->dynStName, fieldPos, cFieldStp->sqlName);
                            stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg);
                        }
                        else
                        {
                            if (cFieldStp->treatedFlg == FALSE)
                            {
                                SYS_StringFormat(msg,
                                        "Untreated attribute for dynst %s field %d (%s)", dynDefStp->dynStName, fieldPos, cFieldStp->sqlName);
                                stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg);
                            }

                            DBA_DYNSTDEF_STP dynStDefStp = &(dynStStp->dynStDefPtr[*cFieldStp->fieldPosPtr]);

                            if (dynStDefStp->dataType != DBA_ConvUniDataTypeToDataType(cFieldStp->dataTypeEnum) &&
                                (dynStDefStp->dataType != ExtensionType || 
                                 cFieldStp->dataTypeEnum != IdType || 
                                 dynStDefStp->dictAttribStp == nullptr || 
                                 dynStDefStp->dictAttribStp->logicalFlg == FALSE))
                            {
                                SYS_StringFormat(msg,
                                                 "Data-type different for dynst %s field %s (%s vs %s)",
                                                 dynDefStp->dynStName,
                                                 cFieldStp->sqlName,
                                                 DBA_GetDataTypeSQLNameC(dynStDefStp->dataType),
                                                 DBA_GetDataTypeSQLNameC(DBA_ConvUniDataTypeToDataType(cFieldStp->dataTypeEnum)));
                               stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg);
                            }

                            if (dynStDefStp->dbFlg != cFieldStp->dbFlg)
                            {
                                SYS_StringFormat(msg,
                                        "dbFlg different for dynst %s field %d (%s)", dynDefStp->dynStName, fieldPos, cFieldStp->sqlName);
                                stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg);
                            }

                            if (strcmp(dynStDefStp->sqlName, cFieldStp->sqlName) != 0)
                            {
                                SYS_StringFormat(msg,
                                        "Sqlname different for dynst %s field %d (%s -> %s)", dynDefStp->dynStName, fieldPos, cFieldStp->sqlName, dynStDefStp->sqlName);
                                stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg);
                            }
                        }
                    }
                }

            }

            if (dynStStp->codifIdIdx != Null_Dynfld)
            {
                if (dynStStp->fldNbr - 1 != dynStStp->codifIdIdx)
                {
                    SYS_StringFormat(msg,
                            "The codification must be in the end for dynst %s", dynDefStp->dynStName);
                    stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg);
                }
            }

            DICT_ENTITY_STP dictEntityStp = nullptr;

            if (dynStStp->entity != NullEntity && dynStStp->entity != InvalidEntity)
            {
                dictEntityStp = DBA_GetDictEntitySt(dynStStp->entity);
            }

            if (dictEntityStp)
            {
                if (dynStStp->dynTypeEnum == DynType_All)
                {
                    for (auto allCriteria = dictEntityStp->allDictCriteriaMap.begin(); allCriteria != dictEntityStp->allDictCriteriaMap.end(); ++allCriteria)
                    {
                        DICT_CRITER_STP  criterStp = allCriteria->second;

                        if (criterStp->entAttrPtr == nullptr || criterStp->attrPtr == nullptr)
                        {
                            SYS_StringFormat(msg,
                                    "Invalid \"all\" criteria, entity %s attribute %s", dictEntityStp->mdSqlName, criterStp->sqlName);
                            stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg);
                        }
                        else
                        {
                            DBA_DYNSTDEF_STP dynStDefStp = &(dynStStp->dynStDefPtr[criterStp->entAttrPtr->progN]);

                            if (dynStDefStp == nullptr)
                            {
                                SYS_StringFormat(msg,
                                        "DynStDef missing for criteria, entity %s attribute %s", dictEntityStp->mdSqlName, criterStp->sqlName);
                                stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg);
                            }
                            else if (dynStDefStp->mdFlg == TRUE &&
                                     dynStDefStp->dbFlg == TRUE &&
                                     criterStp->attrPtr->custFlg == FALSE &&
                                     criterStp->attrPtr->precompFlg == FALSE)
                            {
                                if (dynStDefStp->dataType != criterStp->attrPtr->dataTpProgN)
                                {
                                    SYS_StringFormat(msg,
                                            "Criteria Data-type different for entity %s attribute %s", dictEntityStp->mdSqlName, criterStp->sqlName);
                                    stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg);
                                }
                            }
                        }
                    }

                    int progNCheck = 0;
                    for (auto attribIt = dictEntityStp->attr.begin(); attribIt != dictEntityStp->attr.end(); ++attribIt, ++progNCheck)
                    {
                        DICT_ATTRIB_STP dictAttribStp = (*attribIt);
                        FIELD_IDX_T     progN = dictAttribStp->progN;

                        if (progNCheck != progN)
                        {
                            SYS_StringFormat(msg,
                                    "ProgN mismatch for dynst %s field %d != %d (%s) ", dynDefStp->dynStName, progNCheck, progN, dictAttribStp->sqlName);
                            stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg);
                        }
                        if (dictAttribStp->progN != progN)
                        {
                            SYS_StringFormat(msg,
                                    "ProgN mismatch for dynst %s field %d != %d (%s) ", dynDefStp->dynStName, progNCheck, progN, dictAttribStp->sqlName);
                            stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg);
                        }

                        DBA_DYNSTDEF_STP dynStDefStp = &(dynStStp->dynStDefPtr[progN]);

                        if (dynStDefStp->dataType != dictAttribStp->dataTpProgN &&
                            (dictAttribStp->logicalFlg == FALSE || dynStDefStp->dataType != ExtensionType))
                        {
                            SYS_StringFormat(msg,
                                    "Data-type different for dynst %s field %s", dynDefStp->dynStName, dynStDefStp->sqlName);
                            stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg);
                        }

                        if (strcmp(dynStDefStp->sqlName, dictAttribStp->sqlName) != 0 &&
                            dictAttribStp->featureEn != XdEntityFeatureFeatureEn::ScriptControl)
                        {
                            SYS_StringFormat(msg,
                                    "Sqlname different for dynst %s field %d (%s -> %s)", dynDefStp->dynStName, progN, dictAttribStp->sqlName, dynStDefStp->sqlName);
                            stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg);
                        }

                        if (dynStDefStp->mdFlg == TRUE && dictAttribStp->calcEn == DictAttr_NoMD)
                        {
                            SYS_StringFormat(msg,
                                    "Invalid dynst %s field %d", dynDefStp->dynStName, progN);
                            stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg);
                        }
                    }

                    for (int fieldIdx = 0; fieldIdx < dynStStp->fldNbr; fieldIdx++)
                    {
                        DBA_DYNSTDEF_STP dynStDefStp = &(dynStStp->dynStDefPtr[fieldIdx]);

                        if (fieldIdx > static_cast<INT_T>(dictEntityStp->attr.size()))
                        {
                            SYS_StringFormat(msg,
                                             "Invalid dynst %s field %d", dynDefStp->dynStName, fieldIdx);
                            stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg);
                        }

                        DICT_ATTRIB_STP dictAttribStp = dictEntityStp->attr[fieldIdx];
                        FIELD_IDX_T     progN         = dictAttribStp->progN;

                        if (strcmp(dynStDefStp->sqlName, dictAttribStp->sqlName) != 0 &&
                            dictAttribStp->featureEn != XdEntityFeatureFeatureEn::ScriptControl)
                        {
                            SYS_StringFormat(msg,
                                    "Sqlname different for dynst %s field %d (%s -> %s)", dynDefStp->dynStName, progN, dictAttribStp->sqlName, dynStDefStp->sqlName);
                            stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg);
                        }
                    }
                }
                else if (dynStStp->dynTypeEnum == DynType_Short)
                {
                    int progNCheck = 0;
                    for (auto criterIt = dictEntityStp->shortDictCriteriaMap.begin(); criterIt != dictEntityStp->shortDictCriteriaMap.end(); ++criterIt)
                    {
                        FIELD_IDX_T     progN = criterIt->first;
                        DICT_CRITER_STP dictCriterStp = criterIt->second;

                        if (dictCriterStp->index < 0)
                        {
                            continue;
                        }

                        if (progNCheck != progN)
                        {
                            SYS_StringFormat(msg,
                                    "ProgN mismatch for dynst %s field %d != %d (%s) ", dynDefStp->dynStName, progNCheck, progN, dictCriterStp->sqlName);
                            stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg);
                        }
                        if (dictCriterStp->progN != progN)
                        {
                            SYS_StringFormat(msg,
                                    "ProgN mismatch for dynst %s field %d != %d (%s) ", dynDefStp->dynStName, progNCheck, progN, dictCriterStp->sqlName);
                            stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg);
                        }

                        DBA_DYNSTDEF_STP dynStDefStp = &(dynStStp->dynStDefPtr[progN]);

                        if (dictCriterStp->attrPtr == nullptr)
                        {
                            SYS_StringFormat(msg,
                                    "Invalid dynst %s field %d", dynDefStp->dynStName, progNCheck);
                            stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg);
                        }
                        else if (dynStDefStp->dataType != dictCriterStp->attrPtr->dataTpProgN)
                        {
                            SYS_StringFormat(msg,
                                    "Data-type different for dynst %s field %s", dynDefStp->dynStName, dynStDefStp->sqlName);
                            stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg);
                        }

                        if (strcmp(dynStDefStp->sqlName, dictCriterStp->sqlName) != 0)
                        {
                            SYS_StringFormat(msg,
                                    "Sqlname different for dynst %s field %d (%s -> %s)", dynDefStp->dynStName, progN, dictCriterStp->sqlName, dynStDefStp->sqlName);
                            stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg);
                        }

                        ++progNCheck;
                    }

                    for (int fieldIdx = 0; fieldIdx < dynStStp->fldNbr; fieldIdx++)
                    {
                        DBA_DYNSTDEF_STP dynStDefStp = &(dynStStp->dynStDefPtr[fieldIdx]);
                        DICT_CRITER_STP  criterStp = nullptr;

                        if (dynStDefStp->mdFlg == TRUE &&
                            dynStDefStp->dbFlg == TRUE &&
                            (criterStp = dictEntityStp->getDictCriteria(DynType_Short, fieldIdx)) != NULL &&
                            criterStp->attrPtr &&
                            criterStp->attrPtr->custFlg == FALSE &&
                            criterStp->attrPtr->precompFlg == FALSE)
                        {
                            if (dynStStp->dynStDefPtr[criterStp->progN].dataType != criterStp->attrPtr->dataTpProgN)
                            {
                                SYS_StringFormat(msg,
                                        "Data-type different for dynst %s field %d (%s)", dynDefStp->dynStName, fieldIdx, criterStp->attrPtr->sqlName);
                                stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg);
                            }
                        }
                    }
                }
            }
        }
    }

    return RET_SUCCEED;
}

/************************************************************************
**
**  Function    :   DBA_InitDataTypePtr()
**
**  Description :   Initialize EV_DataTypePtr on table SV_DataTypeTab.
**
**  Arguments   :   none
**
**  Return      :   none
**
**  Last modif. :   REF11780 - 100406 - PMO : Implementation of the Sybase timestamp field
**
*************************************************************************/
void DBA_InitDataTypePtr()
{
    EV_DataTypePtr = SV_DataTypeTab;

    /* Check if SV_DataTypeTab is aligned with DATATYPE_ENUM in unidef.h */
    assert(LastType == (sizeof(SV_DataTypeTab) / sizeof(SV_DataTypeTab[0])));
}

/************************************************************************
**
**  Function    :   DBA_AddInMemoryProc()
**
**  Description :
**
**  Arguments   :   none
**
**  Return      :   none
**
**  Creation    :   PMSTA-45413 - LJE - 211129
**
*************************************************************************/
void DBA_AddInMemoryProc(DICT_ENTITY_STP dictEntityStp, int *currProc, DBA_PROC_STP objProcLstStp, DBA_PROC_ST &currProcSt)
{
    /* PMSTA-45413 - LJE - 211102 */
    if (SYS_IsDdlGenMode() == TRUE &&
        dictEntityStp != nullptr &&
        (currProcSt.subObj == UNUSED ||
         currProcSt.subObj == DBA_ROLE_SCPT_DEF_VAL_INIT ||
         currProcSt.subObj == DBA_ROLE_SCPT_CTRL_INIT ||
         currProcSt.subObj == DBA_ROLE_UPD_ENTITY ||
         currProcSt.subObj == DBA_ROLE_NO_SUBSCRIPTION) &&
        currProcSt.server == SqlServer)
    {
        bool bToCreate = false;

        if (dictEntityStp->bIsInitEntity ||
            dictEntityStp->objectEn == ApplParam ||
            dictEntityStp->objectEn == ApplMsg ||
            dictEntityStp->objectEn == ApplMsgTxt ||
            dictEntityStp->objectEn == DictFct ||
            dictEntityStp->objectEn == DictLang ||
            dictEntityStp->objectEn == DictErrMsg ||
            dictEntityStp->objectEn == DictAttribComment ||
            dictEntityStp->objectEn == XdAttribComment ||
            dictEntityStp->objectEn == QuestDef)
        {
            switch (currProcSt.action)
            {
                case Get:
                case Select:
                case Update:
                case Insert:
                case Delete:
                    bToCreate = true;
                    break;
            }
        }

        if (bToCreate)
        {
            (*currProc)++;
            DBA_PROC_ST& memObjProcSt = objProcLstStp[(*currProc)];

            memObjProcSt = currProcSt;

            if (currProcSt.subObj == UNUSED)
            {
                currProcSt.subObj = DBA_ROLE_DB_ACCESS;
            }
            else
            {
                currProcSt.subObj += DBA_ROLE_DB_ACCESS_FACTOR;
            }

            memObjProcSt.server = InternalProc;

            switch (currProcSt.action)
            {
                case Get:
                    memObjProcSt.procName = GetXdObjectConst;
                    memObjProcSt.fctDefSt = GETFCT(DBA_GetXdObject);
                    break;

                case Select:
                    memObjProcSt.procName = SelXdObjectConst;
                    memObjProcSt.fctDefSt = SELFCT(DBA_SelXdObject);
                    break;

                case Update:
                    memObjProcSt.procName = UpdXdObjectConst;
                    memObjProcSt.fctDefSt = UPDFCT(DBA_UpdXdObject);
                    break;

                case Insert:
                    memObjProcSt.procName = InsXdObjectConst;
                    memObjProcSt.fctDefSt = INSFCT(DBA_InsXdObject);
                    break;

                case Delete:
                    memObjProcSt.procName = DelXdObjectConst;
                    memObjProcSt.fctDefSt = DELFCT(DBA_DelXdObject);
                    break;
            }

            memObjProcSt.optiIdx = NullOpti;
        }
    }
}

/************************************************************************
**
**  Function    :   DBA_InitProcLstByTemplate()
**
**  Description :   Create SProc Tab based on template (AllStd or feature)
**
**  Arguments   :   none
**
**  Return      :   none
**
**  Creation    :   PMSTA-26250 - DDV - 170515
**
*************************************************************************/
int DBA_InitProcLstByTemplate(int                   *currProc,
                              DICT_ENTITY_STP       dictEntityStp,
                              DdlGenSProcPtr       &genDdl,
                              DBA_PROC_STP          procDefStp,
                              DDL_STD_SPROC_DEF_STP templateSProcDefTab)
{
    int              i, j;

    DictSprocClass  &dictSprocSt = genDdl->getDictSprocSt();
    DBA_PROC_STP   objProcLstStp = AaaMetaDict::getObjProcLstStp(dictEntityStp->objectEn);

    for (int k = 0; templateSProcDefTab[k].procActionEn != NullAction; k++)
    {
        bool bValidProc = true;

        if (templateSProcDefTab[k].applAccess == FALSE)
        {
            continue;
        }

        /* PMSTA-14452 - LJE - 121031 */
        if (templateSProcDefTab[k].role == DBA_ROLE_UPD_UD_FIELDS &&
            dictEntityStp->custAuthFlg == FALSE)
        {
            continue;
        }

        if (templateSProcDefTab[k].outputDynTypeEn == DynType_All &&
            EV_EntityGuiStPtr[dictEntityStp->objectEn].editDynDefTabPtr->dynStPos == EV_EntityGuiStPtr[dictEntityStp->objectEn].adminDynDefTabPtr->dynStPos)
        {
            continue;
        }

        dictSprocSt.procActionEn = templateSProcDefTab[k].procActionEn;
        dictSprocSt.procAccessEn = templateSProcDefTab[k].procAccessEn;
        dictSprocSt.role         = templateSProcDefTab[k].role; /* PMSTA-14452 - LJE - 121102 */
        dictSprocSt.priority     = templateSProcDefTab[k].priority; /* PMSTA-18593 - LJE - 160302 */
        dictSprocSt.bStdProc     = true;

        if (templateSProcDefTab[k].inputObjectEn == InvalidEntity)
            dictSprocSt.inputObjectEn = dictEntityStp->objectEn;
        else
            dictSprocSt.inputObjectEn = templateSProcDefTab[k].inputObjectEn;

        if (templateSProcDefTab[k].outputObjectEn == InvalidEntity)
            dictSprocSt.outputObjectEn = dictEntityStp->objectEn;
        else
            dictSprocSt.outputObjectEn = templateSProcDefTab[k].outputObjectEn;

        dictSprocSt.outputDynTypeEn = templateSProcDefTab[k].outputDynTypeEn;

        dictSprocSt.sqlName.clear();
        dictSprocSt.m_paramProcAttribVector.clear();
        genDdl->reset();
        genDdl->init(false);
        dictSprocSt.sqlName = genDdl->getSprocSqlName(); /* PMSTA-26011 - DDV - 170125 - Use lower Sqlname to match dbaprocdef definition */

        genDdl->initRequest();
        if (dictSprocSt.sqlName.empty() == false && genDdl->setSprocParam() == RET_SUCCEED)
        {
            FLAG_T outputAttribOnly;
            size_t paramProcAttribNbr;
            bool bProcNameUsed = false;
            char *procName = AaaMetaDict::getMemoryPool().allocChar(FILEINFO, dictSprocSt.sqlName.length() + 1);

            strcpy(procName, dictSprocSt.sqlName.c_str());

            if (templateSProcDefTab[k].procActionEn == Insert ||
                templateSProcDefTab[k].procActionEn == Update)
            {
                outputAttribOnly = TRUE;
            }
            else
            {
                outputAttribOnly = FALSE;
            }

            i = 0;

            do
            {
                list<char*>       paramNameList;

                DBA_PROC_ST &objProcSt = objProcLstStp[(*currProc)];

                objProcSt.procName = procName;
                objProcSt.server   = SqlServer;

                /* PMSTA-34200 - LJE - 190114 */
                if (dictSprocSt.role == DBA_ROLE_SEL_SHADOW)
                {
                    objProcSt.connection = ReadOnly;
                }
                else
                {
                    objProcSt.connection = Synchronous;
                }
                objProcSt.action   = dictSprocSt.procActionEn;
                objProcSt.subObj   = dictSprocSt.role;
                objProcSt.optiIdx  = NullOpti;
                objProcSt.priority = dictSprocSt.priority; /* PMSTA-18593 - LJE - 160302 */

                if (templateSProcDefTab[k].inputDynTypeEnTab[i] == DynType_Null)
                {
                    objProcSt.inputDynStPtr = &NullDynSt;
                }
                else if (templateSProcDefTab[k].inputDynTypeEnTab[i] == DynType_All)
                {
                    objProcSt.inputDynStPtr = &(EV_EntityGuiStPtr[dictEntityStp->objectEn].editDynDefTabPtr->dynStPos);
                }
                else if (templateSProcDefTab[k].inputDynTypeEnTab[i] == DynType_Short)
                {
                    objProcSt.inputDynStPtr = &(EV_EntityGuiStPtr[dictEntityStp->objectEn].adminDynDefTabPtr->dynStPos);
                }
                else if (templateSProcDefTab[k].inputDynTypeEnTab[i] == DynType_AdmArg)
                {
                    objProcSt.inputDynStPtr = &(EV_DynStPtr[Adm_Arg].dynDefPtr->dynStPos);
                }

                if (templateSProcDefTab[k].outputDynTypeEn == DynType_Null)
                {
                    objProcSt.outputDynStPtr = &NullDynSt;
                }
                else if (templateSProcDefTab[k].outputDynTypeEn == DynType_All)
                {
                    objProcSt.outputDynStPtr = &(EV_EntityGuiStPtr[dictEntityStp->objectEn].editDynDefTabPtr->dynStPos);
                }
                else if (templateSProcDefTab[k].outputDynTypeEn == DynType_Short)
                {
                    objProcSt.outputDynStPtr = &(EV_EntityGuiStPtr[dictEntityStp->objectEn].adminDynDefTabPtr->dynStPos);
                }
                else if (templateSProcDefTab[k].outputDynTypeEn == DynType_AdmArg)
                {
                    objProcSt.outputDynStPtr = &(EV_DynStPtr[Adm_Arg].dynDefPtr->dynStPos);
                }

                /* Create parameters */
                if (outputAttribOnly == FALSE)
                {
                    paramProcAttribNbr = dictSprocSt.m_paramProcAttribVector.size();

                    if (dictSprocSt.procAccessEn == ProcAccess_BusinessKey)
                    {
                        bool bPkEqBk = true;

                        for (auto it = dictSprocSt.m_paramProcAttribVector.begin(); it != dictSprocSt.m_paramProcAttribVector.end(); ++it)
                        {
                            if (it->attrStp && it->attrStp->primFlg == FALSE)
                            {
                                bPkEqBk = false;
                                break;
                            }
                        }

                        if (bPkEqBk)
                        {
                            bValidProc = false;
                            paramProcAttribNbr = 0;
                        }
                    }
                }
                else
                {
                    paramProcAttribNbr = 0;
                    for (auto it = dictSprocSt.m_paramProcAttribVector.begin(); it != dictSprocSt.m_paramProcAttribVector.end(); ++it)
                    {
                        if (it->outputFlg == TRUE)
                        {
                            paramProcAttribNbr++;
                        }
                    }
                }

                DBA_PROCPARAM_STP procParamDefPtr = nullptr;

                if (paramProcAttribNbr != 0)
                {
                    char *paramName;
                    int   defParamPos = 0;
                    DBA_CFIELDDEF_STP cFieldPtr = nullptr;

                    procParamDefPtr = (DBA_PROCPARAM_STP)AaaMetaDict::getMemoryPool().calloc(FILEINFO, paramProcAttribNbr + 1, sizeof(DBA_PROCPARAM_ST));

                    for (auto it = dictSprocSt.m_paramProcAttribVector.begin(); it != dictSprocSt.m_paramProcAttribVector.end(); ++it)
                    {
                        if (outputAttribOnly == TRUE &&
                            it->outputFlg == FALSE)
                        {
                            continue;
                        }

                        paramName = AaaMetaDict::getMemoryPool().allocChar(FILEINFO, it->m_sqlName.length() + 2);
                        sprintf(paramName, "@%s", it->m_sqlName.substr(0, genDdl->getMaxDDLObjLength() - 2).c_str());
                        procParamDefPtr[defParamPos].paramName = paramName;
                        paramNameList.push_back(paramName);

                        if (it->defaultValueC.empty() == false ||
                            (it->attrStp && it->attrStp->mandatoryFlg == FALSE))
                        {
                            procParamDefPtr[defParamPos].mandatFlg = FALSE;
                        }
                        else
                        {
                            procParamDefPtr[defParamPos].mandatFlg = TRUE;
                        }

                        if (it->outputFlg == TRUE)
                        {
                            if (templateSProcDefTab[k].procActionEn == Insert)
                            {
                                procParamDefPtr[defParamPos].mandatFlg = FALSE;
                            }
                            procParamDefPtr[defParamPos].procParamTypeEn = ProcParamType_Output;
                        }
                        else
                        {
                            procParamDefPtr[defParamPos].procParamTypeEn = ProcParamType_Input;
                        }
                        procParamDefPtr[defParamPos].outputFldNbrPtr = &Null_Dynfld;

                        /* PMSTA-26108 - LJE - 170811 */
                        if (templateSProcDefTab[k].inputDynTypeEnTab[i] == DynType_AdmArg &&
                            dictSprocSt.procAccessEn == ProcAccess_NatureKey)
                        {
                            cFieldPtr = DBA_GetCFieldDef(Adm_Arg, Adm_Arg_NatEn, NULL);
                        }
                        /* PMSTA-36149 - LJE - 190612 */
                        else if (templateSProcDefTab[k].inputDynTypeEnTab[i] == DynType_AdmArg &&
                                 dictSprocSt.procAccessEn == ProcAccess_ChangeSet)
                        {
                            cFieldPtr = DBA_GetCFieldDef(Adm_Arg, Adm_Arg_Id, NULL);
                        }
                        else if (templateSProcDefTab[k].inputDynTypeEnTab[i] == DynType_AdmArg &&
                            (dictEntityStp->isNullParIndex || dictEntityStp->parIndex == it->attrStp->progN))
                        {
                            /* PMSTA-30500 - LJE - 180320 */
                            if ((dictEntityStp->isNullParIndex && dictEntityStp->primKeyNbr == 1 &&
                                (dictEntityStp->primKeyTab[0]->dataTpProgN == IdType || dictEntityStp->primKeyTab[0]->dataTpProgN == DictType)) ||
                                dictEntityStp->parIndex == it->attrStp->progN)
                            {
                                cFieldPtr = DBA_GetCFieldDef(Adm_Arg, Adm_Arg_Id, NULL);
                            }
                        }
                        else
                        {
                            cFieldPtr = DBA_GetCFielBySqlName(*(objProcSt.inputDynStPtr),
                                                              it->attrStp->sqlName,
                                                              NULL);
                        }

                        if (cFieldPtr == NULL &&
                            templateSProcDefTab[k].inputDynTypeEnTab[i] == DynType_AdmArg)
                        {
                            bValidProc = false;
                        }
                        else if (cFieldPtr == NULL)
                        {
                            string           msg;

                            bValidProc = false;

                            SYS_StringFormat(msg,
                                             "Unknown field stored proc param \"%s\" for procedure \"%s\", entity \"%s\"."
                                             "\nThe attribute is missing in the \"%s\" structure in the meta-dictionary",
                                             it->m_sqlName.c_str(),
                                             dictSprocSt.sqlName.c_str(),
                                             dictEntityStp->mdSqlName,
                                             templateSProcDefTab[k].inputDynTypeEnTab[i] == DynType_All ? "All" : "Short");

                            if (EV_GenDdlContext.bCheck == true)
                            {
                                DdlGenContext    ddlgenContext(EV_RdbmsVendor);
                                DdlGenMsg        stdMsg(&ddlgenContext);

                                stdMsg.printMsg(RET_DBA_ERR_INVDATA, msg);
                            }
                            else if (EV_AAAInstallLevel != 99)
                            {
                                MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, msg.c_str());
                            }
                        }
                        else
                        {
                            procParamDefPtr[defParamPos].fldNbrPtr = cFieldPtr->fieldPosPtr;
                        }
                        defParamPos++;
                    }

                    procParamDefPtr[defParamPos].fldNbrPtr = UNUSED;
                    paramName = AaaMetaDict::getMemoryPool().allocChar(FILEINFO, 1);
                    procParamDefPtr[defParamPos].paramName = paramName;
                    procParamDefPtr[defParamPos].mandatFlg = UNUSED;
                    paramNameList.push_back(paramName);
                }
                /* PMSTA-26108 - LJE - 170811 */
                else if (templateSProcDefTab[k].inputDynTypeEnTab[i] == DynType_AdmArg)
                {
                    bValidProc = false;
                }


                if (bValidProc)
                {
                    size_t newParamNbr = paramNameList.size() ? paramNameList.size() - 1 : 0;

                    /* Check if the stored proc entry is already on the hard-coded list */
                    for (j = 0; procDefStp[j].action != NullAction; j++)
                    {
                        if (procDefStp[j].action != AllStdProcs &&
                            /*procDefStp[j].server          == objProcSt.server && - PMSTA-17266 - DDV - 140129 - It is not part of matching criteria in function DBA_GetStoredProcs */
                            procDefStp[j].action            == objProcSt.action &&
                            procDefStp[j].connection        == objProcSt.connection &&
                            procDefStp[j].subObj            == objProcSt.subObj &&
                            *(procDefStp[j].inputDynStPtr)  == *(objProcSt.inputDynStPtr) &&
                            *(procDefStp[j].outputDynStPtr) == *(objProcSt.outputDynStPtr))
                        {

                            size_t h = 0;
                            bool   bSame = true;

                            if (procDefStp[j].procParamDefPtr != NULL)
                            {
                                while (procDefStp[j].procParamDefPtr[h].fldNbrPtr != UNUSED)
                                {
                                    if (h >= newParamNbr ||
                                        strcmp(procParamDefPtr[h].paramName, procDefStp[j].procParamDefPtr[h].paramName) != 0)
                                    {
                                        bSame = false;
                                        break;
                                    }
                                    h++;
                                }
                            }
                            else if (procDefStp[j].procParamDefPtr != NULL)
                            {
                                bSame = false;
                            }

                            if (bSame)
                            {
                                break;
                            }

                            /* PMSTA-43367 - LJE - 210423 */
                            if (dictSprocSt.sqlName == procDefStp[j].procName)
                            {
                                for (; procDefStp[j].action != NullAction; j++) /* To avoid message */
                                {
                                }
                                bValidProc = false;
                                break;
                            }

                            if (AAACHECKDYNFLD)
                            {
                                if (procDefStp[j].priority > 1 && procDefStp[j].priority < 10)
                                {
                                    int tstProc;

                                    for (tstProc = 0; procDefStp[tstProc].action != NullAction; tstProc++)
                                    {
                                        if (tstProc != (*currProc) &&
                                            procDefStp[tstProc].action == objProcSt.action &&
                                            procDefStp[tstProc].connection == objProcSt.connection &&
                                            procDefStp[tstProc].subObj == objProcSt.subObj &&
                                            procDefStp[tstProc].priority == 1 &&
                                            *(procDefStp[tstProc].inputDynStPtr) == *(objProcSt.inputDynStPtr) &&
                                            *(procDefStp[tstProc].outputDynStPtr) == *(objProcSt.outputDynStPtr))
                                        {
                                            break;
                                        }
                                    }

                                    if (procDefStp[tstProc].action == NullAction)
                                    {
                                        string           msg;
                                        DdlGenContext    ddlgenContext(EV_RdbmsVendor);
                                        DdlGenMsg        stdMsg(&ddlgenContext);

                                        SYS_StringFormat(msg,
                                                         "Entity: %s - Stored procedure having priority > 1 defined (%s) without priority = 1 (10 = Parent, 20 = Primary Key, 30 = Business Key)",
                                                         dictEntityStp->mdSqlName,
                                                         procDefStp[j].procName);

                                        stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg);
                                    }
                                }
                            }
                        }
                    }

                    if (procDefStp[j].action != NullAction)
                    {
                        if (AAACHECKDYNFLD)
                        {
                            if (strcmp(procDefStp[j].procName, objProcSt.procName) == 0 &&
                                procDefStp[j].optiIdx == NullOpti)
                            {
                                string           msg;
                                DdlGenContext    ddlgenContext(EV_RdbmsVendor);
                                DdlGenMsg        stdMsg(&ddlgenContext);

                                SYS_StringFormat(msg,
                                                 "The overloaded stored procedure have the same name than the standard one (%s), without optimization",
                                                 procDefStp[j].procName);

                                stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg);
                            }
                            else if (procDefStp[j].optiIdx == NullOpti)
                            {
                                if (procDefStp[j].server != InternalProc)
                                {
                                    string           msg;
                                    DdlGenContext    ddlgenContext(EV_RdbmsVendor);
                                    DdlGenMsg        stdMsg(&ddlgenContext);

                                    SYS_StringFormat(msg,
                                                     "Overloaded stored procedure (%s(%d) -> %s(%d))",
                                                     objProcSt.procName,
                                                     objProcSt.priority,
                                                     procDefStp[j].procName,
                                                     procDefStp[j].priority);

                                    stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg);
                                }
                            }

                            /* PMSTA-26250 - LJE - 170403 */
                            if ((*procDefStp[j].inputDynStPtr) != NullDynSt &&
                                procDefStp[j].procParamDefPtr == nullptr &&
                                (procDefStp[j].action == Get ||
                                 procDefStp[j].action == Select))
                            {
                                string           msg;
                                DdlGenContext    ddlgenContext(EV_RdbmsVendor);
                                DdlGenMsg        stdMsg(&ddlgenContext);

                                SYS_StringFormat(msg,
                                                 "Procedure \"%s\" define in dbaprocdef haven't parameters but input dynamic structure",
                                                 procDefStp[j].procName);

                                stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg);
                            }
                        }
                        for (list<char*>::iterator it = paramNameList.begin(); it != paramNameList.end(); ++it)
                        {
                            AaaMetaDict::getMemoryPool().freeChar(*it);
                        }
                        AaaMetaDict::getMemoryPool().freePtr(procParamDefPtr);
                        continue;
                    }
                    objProcSt.procParamDefPtr = procParamDefPtr;

                    if (objProcSt.action == MultiSelect &&
                        templateSProcDefTab[k].procAccessEn == ProcAccess_ChangeSet)
                    {
                        objProcSt.multiOutputDynStPtr = static_cast<const DBA_DYNST_ENUM **>(AaaMetaDict::getMemoryPool().calloc(FILEINFO, 3, sizeof(DBA_DYNST_ENUM *)));
                        objProcSt.multiOutputDynStPtr[0] = &(EV_EntityGuiStPtr[dictEntityStp->objectEn].editDynDefTabPtr->dynStPos);
                        objProcSt.multiOutputDynStPtr[1] = &(EV_EntityGuiStPtr[dictEntityStp->objectEn].editDynDefTabPtr->dynStPos);
                        objProcSt.multiOutputDynStPtr[2] = &InvalidDynSt;
                    }
                }

                if (bValidProc)
                {
                    bProcNameUsed = true;

                    DBA_AddInMemoryProc(dictEntityStp, currProc, objProcLstStp, objProcSt);

                    (*currProc)++;
                }
            } while (templateSProcDefTab[k].inputDynTypeEnTab[++i] != DynType_Unknown);

            if (bProcNameUsed == false)
            {
                AaaMetaDict::getMemoryPool().freeChar(procName);
            }
        }
    }

    return(TRUE);
}

/************************************************************************
**
**  Function    :   DBA_InitProcLstPtr()
**
**  Description :   Initialize EV_DataTypePtr on table SV_DataTypeTab.
**
**  Arguments   :   none
**
**  Return      :   none
**
*************************************************************************/
int DBA_InitProcLstPtr(OBJECT_ENUM paramObjectEn)
{
    LockGuard lockGuard(AaaMetaDict::getLock());

    int               maxProc, currProc, stdProc;
    DdlGenContextPtr  ddlGenContextPtr(new DdlGenContext(EV_RdbmsVendor, true));
    DictSprocClass   &dictSprocSt = ddlGenContextPtr->getDictSprocSt();
    DdlGenSProcPtr    genDdlPtr(new DdlGenSProc(dictSprocSt.getObjectEn(), *ddlGenContextPtr, nullptr, nullptr, nullptr, TargetTable_Main));
    string::size_type maxParamLength = genDdlPtr->getMaxDDLObjLength() - genDdlPtr->getParamPrefix().length();

    bool              bSystemOnly = (SYS_IsDdlGenMode() == TRUE && paramObjectEn == NullEntity);

    if (bSystemOnly &&
        EV_AAAInstallLevel < 6 &&
        DBA_GetDictEntitySt(Fmt) != nullptr)
    {
        bSystemOnly = false;
    }

    if (paramObjectEn == NullEntity || paramObjectEn == InvalidEntity)
    {
        (void)AaaMetaDict::allocObjProcLstPtr((size_t)(LASTOBJECT + 1));
    }

    for (maxProc = 0, currProc = 0; SV_DddStdSProcDefTab[currProc].procActionEn != NullAction; currProc++)
    {
        int k = 0;
        while (SV_DddStdSProcDefTab[currProc].inputDynTypeEnTab[k] != DynType_Unknown)
        {
            k++;
            maxProc++;
        }
        if (k == 0)
        {
            maxProc++;
        }
    }

    /* PMSTA-45413 - LJE - 211102 - To support in memory access */
    if (SYS_IsDdlGenMode() == TRUE)
    {
        maxProc *= 2;
    }

    for (currProc = 0; SV_DdlChangeSetSProcDefTab[currProc].procActionEn != NullAction; currProc++)
    {
        int k = 0;
        while (SV_DdlChangeSetSProcDefTab[currProc].inputDynTypeEnTab[k] != DynType_Unknown)
        {
            k++;
            maxProc++;
        }
        if (k == 0)
        {
            maxProc++;
        }
    }

    OBJECT_ENUM      startObjectEn = 0, endObjectEn = LASTOBJECT;

    if (paramObjectEn != NullEntity && paramObjectEn != InvalidEntity)
    {
        startObjectEn = paramObjectEn;
        endObjectEn = paramObjectEn;
    }

    for (OBJECT_ENUM objectEn = startObjectEn; objectEn <= endObjectEn; objectEn++)
    {
        bool bStandardProcs = false;
        int  hardCodedProcNbr = 0;

        auto dictEntityStp = DBA_GetDictEntitySt(objectEn);

        /* PMSTA-13122 - LJE - 120516 */
        if (dictEntityStp != NULL)
        {
            if (dictEntityStp->xdStatusEn == XdStatus_Deleted ||
                dictEntityStp->xdStatusEn == XdStatus_Failed)
            {
                continue;
            }

            if (bSystemOnly &&
                dictEntityStp->entNatEn != EntityNat_System)
            {
                continue;
            }
        }

        DBA_OBJDEF_STP objDefStp = DBA_GetObjDefStp(objectEn);
        auto &autmaticSprocSet = SV_AutonaticSprocMap[objectEn];

        /* PMSTA-14086 - LJE - 121009 */
        if (dictEntityStp != NULL &&
            GET_BIT(dictEntityStp->automaticMask, Automatic_SProc) == TRUE &&
            objDefStp->procDefStp != NULL)
        {
            for (currProc = 0; objDefStp->procDefStp[currProc].action != NullAction; currProc++)
            {
                if (objDefStp->procDefStp[currProc].action == AllStdProcs)
                {
                    bStandardProcs = true;
                }
                else
                {
                    hardCodedProcNbr++;
                }
            }
        }

        /* PMSTA-45413 - LJE - 211102 - To support in memory access */
        if (SYS_IsDdlGenMode() == TRUE)
        {
            hardCodedProcNbr *= 2;
        }

        DBA_PROC_STP objProcLstStp = nullptr;

        if ((SYS_IsDdlGenMode() == FALSE || objectEn == FinAnalysis) && /* PMSTA-37366 - LJE - 200204 */
            bStandardProcs == false &&
            *(objDefStp->objPosPtr) != NullEntity &&
            objDefStp->procDefStp != UNUSED && /*PMSTA-18634 - SHR - 140911 */
            objDefStp->procDefStp != SV_ProcTab_StdSProcDefTab && /* PMSTA-14086 - LJE - 121008 */
            (dictEntityStp == NULL || dictEntityStp->changeSetAuthEn != FeatureAuth_Enable))  /* PMSTA-26250 - DDV - 170516 */
        {
            /* Hard coded stored procedure definition */
            objProcLstStp = objDefStp->procDefStp;

            AaaMetaDict::setObjProcLstStp(objectEn, objProcLstStp);
        }
        else if (dictEntityStp != NULL &&
                 GET_BIT(dictEntityStp->automaticMask, Automatic_SProc) == TRUE &&
                 dictEntityStp->entNatEn != EntityNat_Technical)
        {
            DBA_PROC_STP procDefStp = objDefStp->procDefStp;

            dictSprocSt.setObjectEn(objectEn);
            dictSprocSt.sqlName.clear();
            dictSprocSt.translateFlg = FALSE;
            dictSprocSt.executeAsEn  = ExecuteAs_None;
            dictSprocSt.functionFlg  = FALSE;
            dictSprocSt.m_paramProcAttribVector.clear();
            dictSprocSt.synonymFlg   = FALSE;

            if (procDefStp == NULL)
            {
                procDefStp = SV_ProcTab_StdSProcDefTab;
            }

            /* Compute a new one */
            AaaMetaDict::setObjProcLstStp(objectEn, maxProc + 1 + hardCodedProcNbr);

            objProcLstStp = AaaMetaDict::getObjProcLstStp(objectEn);

            currProc = 0;

            for (stdProc = 0; procDefStp[stdProc].action != NullAction; stdProc++)
            {
                if (procDefStp[stdProc].action != AllStdProcs)
                {
                    if (procDefStp[stdProc].action != OptiDef)
                    {
                        objProcLstStp[currProc] = procDefStp[stdProc];

                        DBA_AddInMemoryProc(dictEntityStp, &currProc, objProcLstStp, objProcLstStp[currProc]);
                        currProc++;
                    }
                    else
                    {
                        /* PMSTA-18426 - DDV - 141126 - Copy Opti idx in new proc tab */
                        if (procDefStp[stdProc].procName != NULL && procDefStp[stdProc].procName[0] != END_OF_STRING)
                        {
                            FLAG_T      procFoundFlg = FALSE;
                            LONGSYSNAME_T procName, procName2;
                            snprintf(procName, sizeof(procName), procDefStp[stdProc].procName, (dictEntityStp ? dictEntityStp->shortSqlname : ""));
                            snprintf(procName2, sizeof(procName2), procDefStp[stdProc].procName, (dictEntityStp ? dictEntityStp->mdSqlName : ""));

                            for (int k = 0; k < currProc; k++)
                            {
                                if (strcmp(procName, objProcLstStp[k].procName) == 0 ||
                                    strcmp(procName2, objProcLstStp[k].procName) == 0)
                                {
                                    procFoundFlg = TRUE;
                                    objProcLstStp[k].optiIdx = procDefStp[stdProc].optiIdx;
                                }
                            }

                            /* PMSTA-26011 - DDV - 170125 - If optimized proc not found, log a message */
                            if (procFoundFlg == FALSE)
                            {
                                string           msg;
                                DdlGenContext    ddlgenContext(EV_RdbmsVendor);
                                DdlGenMsg        stdMsg(&ddlgenContext);

                                SYS_StringFormat(msg,
                                                 "Procedure \"%s\" define in dbaprocdef not found at runtime. Default optimisation can't be used.",
                                                 procDefStp[stdProc].procName);

                                stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg);
                            }
                        }
                    }
                }
                else
                {
                    DBA_InitProcLstByTemplate(&currProc, dictEntityStp, genDdlPtr, procDefStp, SV_DddStdSProcDefTab);
                }
            }

            if (dictEntityStp->changeSetAuthEn == FeatureAuth_Enable)
            {
                DBA_InitProcLstByTemplate(&currProc, dictEntityStp, genDdlPtr, procDefStp, SV_DdlChangeSetSProcDefTab);
            }

            /* Set the last stored procedure definition to "NullAcction" */
            objProcLstStp[currProc].server          = SqlServer;
            objProcLstStp[currProc].connection      = Synchronous;
            objProcLstStp[currProc].action          = NullAction;
            objProcLstStp[currProc].subObj          = UNUSED;
            objProcLstStp[currProc].inputDynStPtr   = &NullDynSt;
            objProcLstStp[currProc].outputDynStPtr  = &NullDynSt;
            objProcLstStp[currProc].priority        = 1;
            objProcLstStp[currProc].procName        = "";
            objProcLstStp[currProc].procParamDefPtr = nullptr;
            objProcLstStp[currProc].optiIdx         = NullOpti;
        }

        /* PMSTA-26252 - LJE - 170301 - Check/Create input and output parameters */
        if (objProcLstStp != nullptr && dictEntityStp != nullptr)
        {
            for (currProc = 0; objProcLstStp[currProc].action != NullAction; currProc++)
            {
                if ((objProcLstStp[currProc].server == SqlServer ||
                     objProcLstStp[currProc].server == InternalProc) &&
                     (objProcLstStp[currProc].action == Update ||
                      objProcLstStp[currProc].action == Insert ||
                      objProcLstStp[currProc].action == InsUpd ||
                      (objProcLstStp[currProc].action == Delete && objProcLstStp[currProc].procParamDefPtr != nullptr) ||           /* PMSTA-37366 - LJE - 191210 */
                      (objProcLstStp[currProc].inputDynStPtr != &NullDynSt && objProcLstStp[currProc].procParamDefPtr == NULL)))
                {
                    bool              bSkip = false;
                    int               paramIdx = 0;
                    DBA_PROCPARAM_STP finalProcParamDefPtr = nullptr;

                    /* when parameter definition contains input argument, parameters definition is use as it is */
                    if (objProcLstStp[currProc].procParamDefPtr != nullptr && 
                        autmaticSprocSet.find(currProc)         == autmaticSprocSet.end())
                    {
                        for (int i = 0; bSkip == false && objProcLstStp[currProc].procParamDefPtr[i].fldNbrPtr != nullptr; i++)
                        {
                            bSkip = objProcLstStp[currProc].procParamDefPtr[i].procParamTypeEn == ProcParamType_Input ||
                                objProcLstStp[currProc].procParamDefPtr[i].procParamTypeEn == ProcParamType_Input_NoCheck;
                        }
                    }

                    if (bSkip == false &&
                        *(objProcLstStp[currProc].inputDynStPtr) == GET_EDITGUIST(objectEn)) /* If not A_ structure liked to entity, skip it */
                    {
                        autmaticSprocSet.insert(currProc);

                        // Build and add the input parameters to procParam
                        list<DICT_ATTRIB_STP> inputAttribList;
                        bool                  isUdProc = false;

                        // For the non UD fields
                        if (objProcLstStp[currProc].subObj != DBA_ROLE_UPD_UD_FIELDS)
                        {
                            for (auto& dictAttribStp : dictEntityStp->attr)
                            {
                                if (dictAttribStp->custFlg == FALSE &&
                                    dictAttribStp->precompFlg == FALSE &&
                                    (dictAttribStp->isPhysicalAttribute() == TRUE ||
                                     (objProcLstStp[currProc].server == InternalProc &&
                                      dictAttribStp->calcEn == DictAttr_NoMD &&
                                      dictAttribStp->subFeatureEn != SubFeature::Tech &&
                                      dictAttribStp->subFeatureEn != SubFeature::TechInternal)))
                                {
                                    inputAttribList.push_back(dictAttribStp);
                                }
                            }
                        }
                        else
                        {
                            /* For the UD fields */
                            if ((objProcLstStp[currProc].procParamDefPtr != nullptr ||
                                 objProcLstStp[currProc].action != Update ||
                                 objProcLstStp[currProc].server != SqlServer) &&
                                autmaticSprocSet.find(currProc) == autmaticSprocSet.end())
                            {
                                /* Savety check : proc param should not be defined */
                                assert(1 == 2);
                            }

                            isUdProc = true;

                            /* For all the ud attributes */
                            for (auto& dictAttribStp : dictEntityStp->attr)
                            {
                                if (dictAttribStp->custFlg == TRUE)
                                {
                                    // Add only physical attributes
                                    if (dictAttribStp->isPhysicalAttribute() == TRUE)
                                    {
                                        inputAttribList.push_back(dictAttribStp);
                                    }
                                }
                            }
                        }

                        /* Handle the input attributes, add them to the proc params */
                        if (inputAttribList.empty() == false)
                        {
                            bool bOnlyOutput = false;

                            if (CAST_INT(inputAttribList.size()) > EV_MaxNumberArgument &&
                                objProcLstStp[currProc].server == SqlServer)
                            {
                                bOnlyOutput = true;

                                if (SYS_IsSqlMode()    == FALSE &&
                                    SYS_IsDdlGenMode() == FALSE)
                                {
                                    objProcLstStp[currProc].procMask |= PROCMASK_USE_TEMP_TABLE_PARAM;

                                    auto tmpDictEntityStp = DBA_GetDictEntitySt(GET_OBJ_DYNST((*objProcLstStp[currProc].inputDynStPtr)));
                                    if (tmpDictEntityStp != nullptr)
                                    {
                                        string tableSqlName("pp_");
                                        tableSqlName += tmpDictEntityStp->mdSqlName;
                                        DBA_AddCreateTempTables(tmpDictEntityStp, EV_RdbmsDdlGen, tableSqlName);
                                        EV_MaxArgSProTableMap[objProcLstStp[currProc].procName] = tmpDictEntityStp->mdSqlName;
                                    }
                                }
                            }

                            /* Final proc params = output + input attributes */
                            finalProcParamDefPtr = (DBA_PROCPARAM_STP)AaaMetaDict::getMemoryPool().calloc(FILEINFO, inputAttribList.size() + 2, sizeof(DBA_PROCPARAM_ST));
                            /* Add the input attributes to the final proc params */
                            for (auto it = inputAttribList.begin(); it != inputAttribList.end(); ++it)
                            {
                                size_t paramLength = strlen((*it)->sqlName);
                                char *paramName = AaaMetaDict::getMemoryPool().allocChar(FILEINFO, paramLength + 2);
                                sprintf(paramName, "@%s", (*it)->sqlName);
                                if (paramLength > maxParamLength)
                                {
                                    paramName[maxParamLength + 1] = END_OF_STRING;
                                }
                                finalProcParamDefPtr[paramIdx].paramName = paramName;
                                finalProcParamDefPtr[paramIdx].mandatFlg = FALSE;
                                finalProcParamDefPtr[paramIdx].procParamTypeEn = ProcParamType_Input;

                                if (isUdProc)
                                {
                                    finalProcParamDefPtr[paramIdx].fldNbrPtr = (FIELD_IDX_T*)AaaMetaDict::getMemoryPool().calloc(FILEINFO, 1, sizeof(FIELD_IDX_T));
                                    *finalProcParamDefPtr[paramIdx].fldNbrPtr = (*it)->progN;
                                }
                                else
                                {
                                    DBA_CFIELDDEF_STP cFieldPtr = DBA_GetCFielBySqlName(*(objProcLstStp[currProc].inputDynStPtr),
                                                                                        (*it)->sqlName,
                                                                                        NULL);

                                    if (cFieldPtr != nullptr)
                                    {
                                        if (paramIdx == 0 && objProcLstStp[currProc].remapIdIdxPtr != NULL)
                                        {
                                            finalProcParamDefPtr[paramIdx].fldNbrPtr = objProcLstStp[currProc].remapIdIdxPtr;
                                        }
                                        else
                                        {
                                            finalProcParamDefPtr[paramIdx].fldNbrPtr = cFieldPtr->fieldPosPtr;
                                        }

                                        if (objProcLstStp[currProc].action == Insert ||
                                            objProcLstStp[currProc].action == Update ||
                                            objProcLstStp[currProc].action == InsUpd)
                                        {
                                            /* define identity field as output */
                                            if ((objProcLstStp[currProc].action == Insert ||
                                                 objProcLstStp[currProc].action == InsUpd) &&
                                                (dictEntityStp->pkRuleEn == PkRule_Identity || 
                                                 (dictEntityStp->pkEntityStp != nullptr && dictEntityStp->pkEntityStp->pkRuleEn == PkRule_Identity) ||
                                                 objProcLstStp[currProc].subObj == DBA_ROLE_INSUPD_DICTFCT_BY_IMP) &&
                                                (*it)->primFlg == TRUE)
                                            {
                                                finalProcParamDefPtr[paramIdx].procParamTypeEn = ProcParamType_Output;
                                            }

                                            /* define physical time_stamp field as output */
                                            if ((*it)->dataTpProgN == TimeStampType && (*it)->isPhysicalAttribute())
                                            {
                                                finalProcParamDefPtr[paramIdx].procParamTypeEn = ProcParamType_Output;
                                            }

                                            if (objProcLstStp[currProc].procParamDefPtr != nullptr)
                                            {
                                                int i = 0;
                                                for (; objProcLstStp[currProc].procParamDefPtr[i].fldNbrPtr != nullptr &&
                                                     strcmp(objProcLstStp[currProc].procParamDefPtr[i].paramName, finalProcParamDefPtr[paramIdx].paramName) != 0; i++);

                                                if (objProcLstStp[currProc].procParamDefPtr[i].fldNbrPtr != nullptr)
                                                {
                                                    switch (objProcLstStp[currProc].procParamDefPtr[i].procParamTypeEn)
                                                    {
                                                        case ProcParamType_Exclude:
                                                            continue;

                                                        case ProcParamType_Output:
                                                            finalProcParamDefPtr[paramIdx].procParamTypeEn = ProcParamType_Output;
                                                            break;

                                                        case ProcParamType_Output_Indexed:
                                                            finalProcParamDefPtr[paramIdx].procParamTypeEn = ProcParamType_Output_Indexed;
                                                            finalProcParamDefPtr[paramIdx].outputFldNbrPtr = objProcLstStp[currProc].procParamDefPtr[i].outputFldNbrPtr;
                                                            break;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else if (EV_AAAInstallLevel != 9)
                                    {
                                        SYS_BreakOnDebug();
                                    }
                                }

                                if (bOnlyOutput == false || 
                                    finalProcParamDefPtr[paramIdx].procParamTypeEn != ProcParamType_Input ||
                                    (paramIdx == 0 && objProcLstStp[currProc].remapIdIdxPtr != nullptr))
                                {
                                    paramIdx++;
                                }
                            }
                        }
                    }
                    else if (objProcLstStp[currProc].procParamDefPtr != nullptr)
                    {
                        int paramNbr = 0;
                        while (objProcLstStp[currProc].procParamDefPtr[paramNbr].fldNbrPtr != UNUSED)
                        {
                            paramNbr++;
                        }
                        finalProcParamDefPtr = (DBA_PROCPARAM_STP)AaaMetaDict::getMemoryPool().calloc(FILEINFO, paramNbr + 2, sizeof(DBA_PROCPARAM_ST));

                        while (objProcLstStp[currProc].procParamDefPtr[paramIdx].fldNbrPtr != UNUSED)
                        {
                            finalProcParamDefPtr[paramIdx] = objProcLstStp[currProc].procParamDefPtr[paramIdx];
                            paramIdx++;
                        }
                    }

                    if (finalProcParamDefPtr != nullptr)
                    {
                        /* PMSTA-37366 - LJE - 191213 */
                        if (DictSprocClass::isRdbmsBatchAllowed(EV_RdbmsVendor) &&
                            objProcLstStp[currProc].server == SqlServer &&
                            DictSprocClass::isActionBatchAllowed(objProcLstStp[currProc].action) &&
                            DictSprocClass::isRoleBatchAllowed(objProcLstStp[currProc].subObj))
                        {
                            if (EV_AAAInstallLevel == 0 ||
                                strcmp(&finalProcParamDefPtr[paramIdx - 1].paramName[1], DictSprocClass::getBatchRowNumName().c_str()) != 0)
                            {
                                size_t paramLength = DictSprocClass::getBatchRowNumName().length();
                                char *paramName = AaaMetaDict::getMemoryPool().allocChar(FILEINFO, paramLength + 2);
                                sprintf(paramName, "@%s", DictSprocClass::
                                        getBatchRowNumName().c_str());
                                if (paramLength > maxParamLength)
                                {
                                    paramName[maxParamLength + 1] = END_OF_STRING;
                                }

                                finalProcParamDefPtr[paramIdx].fldNbrPtr = &Null_Dynfld;
                                finalProcParamDefPtr[paramIdx].paramName = paramName;
                                finalProcParamDefPtr[paramIdx].mandatFlg = FALSE;

                                paramIdx++;
                            }
                            else
                            {
                                finalProcParamDefPtr[paramIdx-1].fldNbrPtr = &Null_Dynfld;
                            }
                        }

                        finalProcParamDefPtr[paramIdx].fldNbrPtr = UNUSED;
                        finalProcParamDefPtr[paramIdx].paramName = AaaMetaDict::getMemoryPool().allocChar(FILEINFO, 1);
                        finalProcParamDefPtr[paramIdx].mandatFlg = UNUSED;
                        /* Set the final proc param */
                        objProcLstStp[currProc].procParamDefPtr = finalProcParamDefPtr;
                    }
                }

                /* PMSTA-37366 - LJE - 191209 */
                if (objProcLstStp[currProc].server == SqlServer &&
                    objProcLstStp[currProc].procParamDefPtr != nullptr &&
                    *(objProcLstStp[currProc].inputDynStPtr) != NullDynSt &&
                    EV_DynStPtr[*(objProcLstStp[currProc].inputDynStPtr)].internalFldIdx != Null_Dynfld)
                {
                    int currParamPos = 0;
                    while (objProcLstStp[currProc].procParamDefPtr[currParamPos].fldNbrPtr != UNUSED)
                    {
                        if (objProcLstStp[currProc].procParamDefPtr[currParamPos].fldNbrPtr == &Null_Dynfld &&
                            EV_DynStPtr[*(objProcLstStp[currProc].inputDynStPtr)].internalFldIdx != Null_Dynfld)
                        {
                            objProcLstStp[currProc].procParamDefPtr[currParamPos].fldNbrPtr = (FIELD_IDX_T *)AaaMetaDict::getMemoryPool().calloc(FILEINFO, 1, sizeof(FIELD_IDX_T));
                            *objProcLstStp[currProc].procParamDefPtr[currParamPos].fldNbrPtr = EV_DynStPtr[*(objProcLstStp[currProc].inputDynStPtr)].internalFldIdx;
                        }
                        currParamPos++;
                    }
                }
            }

            if (AAACHECKDYNFLD)
            {
                for (currProc = 0; objProcLstStp[currProc].action != NullAction; currProc++)
                {
                    for (int tstProc = 0; objProcLstStp[tstProc].action != NullAction; tstProc++)
                    {
                        if (objProcLstStp[currProc].procParamDefPtr != nullptr)
                        {
                            int currParamPos = 0;
                            while (objProcLstStp[currProc].procParamDefPtr[currParamPos].fldNbrPtr != UNUSED)
                            {
                                if (objProcLstStp[currProc].procParamDefPtr[currParamPos].fldNbrPtr == &Null_Dynfld)
                                {
                                    string           msg;
                                    DdlGenContext    ddlgenContext(EV_RdbmsVendor);
                                    DdlGenMsg        stdMsg(&ddlgenContext);

                                    SYS_StringFormat(msg,
                                                     "Invalid stored procedure parameter %s.%s",
                                                     objProcLstStp[currProc].procName,
                                                     objProcLstStp[currProc].procParamDefPtr[currParamPos].paramName);

                                    stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg);
                                }
                                currParamPos++;
                            }
                        }

                        if (tstProc != currProc &&
                            objProcLstStp[tstProc].action == objProcLstStp[currProc].action &&
                            objProcLstStp[tstProc].connection == objProcLstStp[currProc].connection &&
                            objProcLstStp[tstProc].subObj == objProcLstStp[currProc].subObj &&
                            *(objProcLstStp[tstProc].inputDynStPtr) == *(objProcLstStp[currProc].inputDynStPtr) &&
                            *(objProcLstStp[tstProc].outputDynStPtr) == *(objProcLstStp[currProc].outputDynStPtr))
                        {
                            if (objProcLstStp[tstProc].priority <= objProcLstStp[currProc].priority)
                            {
                                if (objProcLstStp[currProc].procParamDefPtr)
                                {
                                    int currParamPos = 0;
                                    while (objProcLstStp[currProc].procParamDefPtr[currParamPos].fldNbrPtr != UNUSED)
                                    {
                                        if (objProcLstStp[tstProc].procParamDefPtr)
                                        {
                                            int tstParamPos = 0;
                                            while (objProcLstStp[tstProc].procParamDefPtr[tstParamPos].fldNbrPtr != UNUSED)
                                            {
                                                if (objProcLstStp[currProc].procParamDefPtr[currParamPos].fldNbrPtr != objProcLstStp[tstProc].procParamDefPtr[tstParamPos].fldNbrPtr)
                                                {
                                                    break;
                                                }
                                                tstParamPos++;
                                            }

                                            if (objProcLstStp[tstProc].procParamDefPtr[tstParamPos].fldNbrPtr == UNUSED)
                                            {
                                                string           msg;
                                                DdlGenContext    ddlgenContext(EV_RdbmsVendor);
                                                DdlGenMsg        stdMsg(&ddlgenContext);

                                                SYS_StringFormat(msg,
                                                                 "The stored procedure %s hides the %s (%s - %s priority %d)",
                                                                 objProcLstStp[tstProc].procName,
                                                                 objProcLstStp[currProc].procName,
                                                                 DBA_GetDynStCName(*(objProcLstStp[currProc].inputDynStPtr)),
                                                                 DBA_GetDynStCName(*(objProcLstStp[currProc].outputDynStPtr)),
                                                                 objProcLstStp[currProc].priority);

                                                stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg);
                                                break;
                                            }
                                        }

                                        currParamPos++;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (EV_GenDdlContext.bCheck == true && SYS_IsDdlGenMode() == FALSE) /* PMSTA-14452 - LJE - 121113 - No check when generating */
    {
        const RET_CODE chkProcRet = DBA_CheckProcLst();

        if (RET_GET_LEVEL(chkProcRet) == RET_LEV_ERROR)
        {
            EV_CheckErrorLevel = chkProcRet;
        }
    }

    return (TRUE);
}


/************************************************************************
**
**  Function    :   DBA_CheckCopyRightsOneEntity
**
**  Description :   Check that the copy process can be applied ... without problem
**
**  Arguments   :   DICT_ENTITY_STP     pdictent        : parent entity
**                  DBA_DYNFLD_STP      pdbadynCopyArg  : dynamic copy structure
**
**  Return      :   RET_CODE
**
**  Creation    :   HFI-PMSTA-51611-2023-01-24
**
*************************************************************************/
STATIC RET_CODE DBA_CheckCopyRightsOneEntity (DICT_ENTITY_STP pdictent, DBA_DYNFLD_STP pdbadynCopyArg)
{
    RET_CODE        retCode = RET_SUCCEED;

    if (pdictent->copyRightEn != DictAttrCopyNat_Denied)
    {
        for (auto& pdictattr : pdictent->attr)
        {
            DICT_ENTITY_STP pdictentLogical = DBA_GetDictEntityByDictId(pdictattr->refEntDictId);
            if ((pdictattr->logicalFlg == TRUE) &&
                (CHECK_BITMASK(pdictattr->subTypeMask, 0) == TRUE) &&
                (pdictentLogical != nullptr) &&
                (pdictentLogical->copyRightEn != DictAttrCopyNat_Denied) &&
                (pdictattr->copyRightEn != DictAttrCopyNat_Denied))
            {
                /*  Init copy stucture                      */
                SET_DICT(pdbadynCopyArg, A_CopyArg_EntityDictId, pdictent->entDictId);     
                SET_DICT(pdbadynCopyArg, A_CopyArg_ToEntityDictId, pdictent->entDictId);
                SET_DICT(pdbadynCopyArg, A_CopyArg_AttribDictId, pdictattr->attrDictId);
                SET_DICT(pdbadynCopyArg, A_CopyArg_ToAttribDictId, pdictattr->attrDictId); 

	            int     role = UNUSED;
                if ((pdictent->objectEn == Strat) &&
                    (pdictentLogical->objectEn == ComplianceChrono))
                {
                    role = DBA_ROLE_COPY_COMPL_CHRONO_BY_STRAT;
                }
                /*  New role to manage the copy of business data compo while coming from business entity    */  /*  HFI-PMSTA-17559-140206  */
                else if ((pdictent->objectEn == BusEntity) &&
                         ((pdictentLogical->objectEn == BusEntityPtfCompo) ||
                          (pdictentLogical->objectEn == BusEntityInstrCompo) ||
                          (pdictentLogical->objectEn == BusEntityThirdCompo) ||
                          (pdictentLogical->objectEn == BusEntityUserCompo)))
                {
                    role = DBA_ROLE_BY_BUS_ENTITY;
                }

                /*  if the copy procedure does not exist then the cascade copy procedure is applied         */
                DBA_PROC_STP procedure =  DBA_GetStoredProcs(Copy, pdictentLogical->objectEn, role, A_CopyArg, pdbadynCopyArg, NullDynSt);
                if (procedure == nullptr)
                {
                    if ((pdictentLogical->dbPKTab == nullptr) ||
                        (pdictentLogical->parentAttrStp == nullptr))
                    {
                        retCode = RET_DBA_ERR_PROCNOTFOUND;
                        DdlGenContext   ddlgenContext(EV_RdbmsVendor);
                        DdlGenMsg       stdMsg(&ddlgenContext);
                        std::string     strMsg = SYS_Stringer("for attribute ", pdictattr->sqlName, " of entity ", pdictent->dbSqlName);
                        stdMsg.setMsgObjType("Missing copy procedure");
                        stdMsg.printMsg(retCode, strMsg.c_str());

                        std::string     strMsgLog = SYS_Stringer("Missing copy procedure for attribute ", pdictattr->sqlName, " (entity:",  pdictentLogical->dbSqlName,") of table ", pdictent->dbSqlName, ". Or indicate that entity ", pdictentLogical->dbSqlName, " cannot be copied in meta dictionary or create a dedicated copy procedure.");
                        MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, strMsgLog.c_str());
                    }
                    else
                    {
                        RET_CODE    ret = DBA_CheckCopyRightsOneEntity(pdictentLogical, pdbadynCopyArg);
                        if (retCode == RET_SUCCEED)
                        {
                            retCode = ret;
                        }
                    }
                }
            }
        }
    }
    return retCode;
}


/************************************************************************
**
**  Function    :   DBA_CheckCopyRights
**
**  Description :   Check that the copy process can be applied ... without problem
**
**  Arguments   :   DICT_ENTITY_STP         pdictent    : parent entity
**
**  Return      :   RET_CODE
**
**  Creation    :   HFI-PMSTA-51611-2023-01-24
**
*************************************************************************/
RET_CODE DBA_CheckCopyRights (void)
{
    RET_CODE        retCode = RET_SUCCEED;
    MemoryPool      mp;

    if ((EV_GenDdlContext.bCheck == true) && (SYS_IsDdlGenMode() == FALSE))
    {
        DBA_DYNFLD_STP  pdbadynCopyArg = mp.allocDynst(FILEINFO, A_CopyArg);
        if (pdbadynCopyArg == nullptr)
        {
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }
        /*  Init copy stucture                      */
        ID_T    id = 1;
        SET_ID(pdbadynCopyArg, A_CopyArg_FromId, id);
        SET_ID(pdbadynCopyArg, A_CopyArg_ToId, id);     

        for (auto it = DICT_GetDictEntityVector().begin(); it != DICT_GetDictEntityVector().end(); ++it)
        {
            DICT_ENTITY_STP dictEntityStp = *it;
            RET_CODE ret = DBA_CheckCopyRightsOneEntity(dictEntityStp, pdbadynCopyArg);
            if (ret != RET_SUCCEED)
            {
                retCode = ret;
            }
        }
        
        if (RET_GET_LEVEL(retCode) == RET_LEV_ERROR)
        {
            EV_CheckErrorLevel = retCode;
        }
    }
    return retCode;
}


/************************************************************************
**
**  Function    :   DBA_CheckProcLst()
**
**  Description :   Check if all the stored procedures set into the file
**                  dbaprocdef.c are present into the database.
**
**  Arguments   :   none
**
**  Return      :   none
**
*************************************************************************/
RET_CODE DBA_CheckProcLst(OBJECT_ENUM paramObjectEn)
{
    RET_CODE         ret = RET_SUCCEED;
    int              shProcFromSybNbr, currProc;
    DBA_DYNFLD_STP  *shProcFromSybTab;

    if (SERVER_MODE())
    {
        printf("\n- Checks for database stored procedures... ");
    }

    DbiConnectionHelper dbiConnHelper(AAATransactionEnum::NotTransactionnal, SqlServer, ROLE_ADMIN);
    if (!dbiConnHelper.isValidAndInit())
    {
        MSG_RETURN(RET_DBA_ERR_PROCNOTFOUND);
    }


    if ((ret = DBA_Select2(DictSproc,
                           DBA_ROLE_UDT,
                           NullDynSt,
                           NULL,
                           S_DictSproc,
                           &shProcFromSybTab,
                           UNUSED,
                           UNUSED,
                           &shProcFromSybNbr,
                           *dbiConnHelper.getConnection(),
                           NULL)) != RET_SUCCEED ||
        shProcFromSybNbr == 0)
    {
        MSG_RETURN(RET_GEN_ERR_INVARG);
    }

    std::set<DdlObjDefKey> sprocSet;
    for (int i = 0; i < shProcFromSybNbr; i++)
    {
        auto dictEntityStp = DBA_GetDictEntityByDictId(GET_DICT(shProcFromSybTab[i], S_DictSproc_EntityDictId));

        if (dictEntityStp != nullptr)
        {
            sprocSet.insert(DdlObjDefKey(EV_RdbmsVendor,
                                         DdlObj_SProc,
                                         GET_SYSNAME(shProcFromSybTab[i], S_DictSproc_Database),
                                         dictEntityStp->mdSqlName,
                                         dictEntityStp->dbSqlName,
                                         GET_SYSNAME(shProcFromSybTab[i], S_DictSproc_SqlName)));
        }
    }

    DdlGenContext ddlgenContext(EV_RdbmsVendor);
    DdlGenMsg     stdMsg(&ddlgenContext);
    std::string   mainDbName;
    std::string   loginDbName = SYS_GetLoginDb();

    GEN_GetApplInfo(ApplSqlDbName, mainDbName);

    for (OBJECT_ENUM objectEn = (paramObjectEn != NullEntity ? paramObjectEn : 0); objectEn <= (paramObjectEn != NullEntity ? paramObjectEn : LASTOBJECT); objectEn++)
    {
        DICT_ENTITY_STP  dictEntityStp = DBA_GetDictEntitySt(objectEn);
        DBA_PROC_STP objProcLstStp = AaaMetaDict::getObjProcLstStp(objectEn);

        for (currProc = 0; objProcLstStp != NULL &&
             objProcLstStp[currProc].action != NullAction; currProc++)
        {
            if (objProcLstStp[currProc].server == SqlServer &&
                objProcLstStp[currProc].action != RegisterRpc &&
                (EV_GenDdlContext.bCheck == true ||
                 objProcLstStp[currProc].subObj != DBA_ROLE_EXTERNAL_USE ||
                 objProcLstStp[currProc].subObj != DBA_ROLE_LOGIN_DB) &&
                objectEn != Test)
            {
                DdlObjDefKey updSproc(EV_RdbmsVendor,
                                      DdlObj_SProc,
                                      (objProcLstStp[currProc].subObj == DBA_ROLE_LOGIN_DB ? loginDbName : mainDbName),
                                      (dictEntityStp != nullptr ? dictEntityStp->mdSqlName : string()),
                                      (dictEntityStp != nullptr ? dictEntityStp->dbSqlName : string()),
                                      objProcLstStp[currProc].procName);

                if (sprocSet.find(updSproc) == sprocSet.end())
                {
                    ret = RET_DBA_ERR_PROCNOTFOUND;
                    if (dictEntityStp != nullptr)
                    {
                        stdMsg.setMsgEntitySqlName(dictEntityStp->mdSqlName);
                    }
                    else
                    {
                        stdMsg.setMsgEntitySqlName("Unknown");
                    }
                    stdMsg.setMsgObjType("Stored procedure");
                    stdMsg.setMsgSqlName(updSproc.getDbDbName() + DdlGenDbi::getCmdDbAccess(EV_RdbmsVendor) + updSproc.getDbObjName());
                    stdMsg.printMsg(ret, "is missing");

                    ret = RET_DBA_ERR_PROCNOTFOUND;
                }
            }
        }
    }

    if (SERVER_MODE())
    {
        if (ret == RET_SUCCEED)
        {
            printf("ok\n");
        }
        else
        {
            printf("\n- Checks for database stored procedures failed (see $AAAHOME/msg/log file)\n");
        }
        printf("- Meta Dictionary Load (continue)... ");
    }

    DBA_FreeDynStTab(shProcFromSybTab, shProcFromSybNbr, S_DictSproc);

    return ret;
}

/************************************************************************
**
**  Function    :   DBA_GetNbrCFieldDynSt()
**
**  Description :   Return the number of C filed for one dynst
**
**  Arguments   :   none
**
**  Return      :   none
**
**  REF8844 - LJE - 030303
**
*************************************************************************/
static short DBA_GetNbrCFieldDynSt(DBA_DYNST_ENUM dynStEnum)
{
    short nbr = 0;
    int   j;

    if (EV_DynStPtr[dynStEnum].dynDefPtr != NULL &&
        EV_DynStPtr[dynStEnum].dynDefPtr->cFieldTab != NULL)
    {
        if (EV_DynStPtr[dynStEnum].dynDefPtr->cFieldTab != NULL)
        {
            for (j = 0; EV_DynStPtr[dynStEnum].dynDefPtr->cFieldTab[j].fieldPosPtr != NULL; j++)
            {
                if (EV_DynStPtr[dynStEnum].dynDefPtr->cFieldTab[j].metaDictFlg == FALSE ||
                    EV_DynStPtr[dynStEnum].entity == NullEntity)
                {
                    nbr++;
                }
            }
        }
    }
    else
    {
        DBA_DYNDEF_STP dynDefStp = DBA_GetDynDefStp(dynStEnum);

        if (dynDefStp &&
            dynDefStp->dynStPos == dynStEnum)
        {
            if (dynDefStp->cFieldTab != NULL)
            {
                for (j = 0; dynDefStp->cFieldTab[j].fieldPosPtr != NULL; j++)
                {
                    if (dynDefStp->cFieldTab[j].metaDictFlg == FALSE ||
                        EV_DynStPtr[dynStEnum].entity == NullEntity)
                    {
                        nbr++;
                    }
                }
            }
        }
    }

    return nbr;
}

/************************************************************************
**
**  Function    :   DBA_InitObjectAndDynSt()
**
**  Description :   Allocation of EV_DynStPtr and init all object and dynSt
**                  variables
**
**  Arguments   :   none
**
**  Return      :   none
**
*************************************************************************/
void DBA_InitObjectAndDynSt()
{
    int             nbrObjMDAndC = 0, nbrObjOnlyC = 0;
    OBJECT_ENUM     entityPos, objDefPos, dynDefPos;

    SV_ObjDefMap.clear();
    SV_ObjDefByCNameMap.clear();
    SV_CObjDefList.clear();

    for (objDefPos = 0; SV_ObjDefManStTab[objDefPos].objPosPtr != &NullEntity; ++objDefPos)
    {
        if (SV_ObjDefManStTab[objDefPos].sqlName[0])
        {
            SV_ObjDefMap.insert(std::make_pair(SV_ObjDefManStTab[objDefPos].sqlName, &(SV_ObjDefManStTab[objDefPos])));
        }
        else
        {
            SV_CObjDefList.push_back(&(SV_ObjDefManStTab[objDefPos]));
        }

        SV_ObjDefManStTab[objDefPos].initOk = FALSE;
    }
    for (objDefPos = 0; SV_ObjDefGenStTab[objDefPos].objPosPtr != &NullEntity; ++objDefPos)
    {
        SV_ObjDefMap.insert(std::make_pair(SV_ObjDefGenStTab[objDefPos].sqlName, &(SV_ObjDefGenStTab[objDefPos])));
        SV_ObjDefGenStTab[objDefPos].initOk = FALSE;
    }
    for (dynDefPos = 0; SV_DynDefManStTab[dynDefPos].dynStPosPtr != &NullDynSt; ++dynDefPos)
    {
        *(SV_DynDefManStTab[dynDefPos].dynStPosPtr) = InvalidDynSt;
    }

    entityPos = 0;
    for (auto &dictEntityStp : DICT_GetDictEntityVector())
    {
        entityPos++;

        auto objDefIt = SV_ObjDefMap.find(dictEntityStp->mdSqlName);

        if (objDefIt != SV_ObjDefMap.end())
        {
            DBA_OBJDEF_STP objDefStp = objDefIt->second;
            objDefStp->initOk = TRUE;
            (*objDefStp->objPosPtr) = dictEntityStp->objectEn;
            dictEntityStp->entDefInCFlg = TRUE;
            nbrObjMDAndC++;
        }

        /* PMSTA-13122 - LJE - 120603 */
        if ((dictEntityStp->entNatEn == EntityNat_CustomDS ||
             dictEntityStp->entNatEn == EntityNat_Custom ||
             dictEntityStp->entNatEn == EntityNat_ModelBank ||    /* PMSTA-27352 - LJE - 170606 */
             dictEntityStp->entNatEn == EntityNat_PersistedFmt ||
             dictEntityStp->entNatEn == EntityNat_ReportFmt ||    /* PMSTA-22072 - LJE - 160108 */
             dictEntityStp->entNatEn == EntityNat_SearchFmt ||
             dictEntityStp->entNatEn == EntityNat_Questionnaire) &&   /* PMSTA-16528 - DDV - 140625 - Add new format and entity nature for search table */
            entityPos > LASTUDTOBJECT)
        {
            LASTUDTOBJECT = entityPos;
        }
    }
    LASTENTITYOBJECT = entityPos;

    for (auto it = SV_ObjDefMap.begin(); it != SV_ObjDefMap.end(); ++it)
    {
        SV_ObjDefByCNameMap.insert(make_pair(it->second->objName, it->second));

        if (it->second->initOk == FALSE)
        {
            *(it->second->objPosPtr) = entityPos;
            auto &dictEntitySt = DICT_AddNewDictEntity(it->second->objCst, entityPos, it->second->sqlName, it->second->objName);
            it->second->initOk = TRUE;

            if (EV_AAAInstallLevel > 8 &&
                it->second->objCst == EmptyCst)
            {
                dictEntitySt.entNatEn = EntityNat_Standard;
            }

            nbrObjOnlyC++;
            entityPos++;
        }
    }
    for (auto it = SV_CObjDefList.begin(); it != SV_CObjDefList.end(); ++it)
    {
        if ((*it)->initOk == FALSE)
        {
            *((*it)->objPosPtr) = entityPos;
            DICT_AddNewDictEntity((*it)->objCst, entityPos, (*it)->sqlName, (*it)->objName);
            (*it)->initOk = TRUE;
            nbrObjOnlyC++;
            entityPos++;
        }
    }
    LASTOBJECT = entityPos - 1;
    LASTLOGENTITYOBJECT = LASTOBJECT;

    LASTDYNST = -1;

    SV_OtherDynDefMap.clear();
    SV_AllDynDefMap.clear();
    SV_ShortDynDefMap.clear();

    for (dynDefPos = 0; SV_DynDefManStTab[dynDefPos].dynStPosPtr != &NullDynSt; dynDefPos++)
    {
        bool bNewDynSt = false;

        SV_DynDefManStTab[dynDefPos].cFieldManTab = nullptr;

        if (*(SV_DynDefManStTab[dynDefPos].dynStPosPtr) == InvalidDynSt)
        {
            bNewDynSt = true;
            *(SV_DynDefManStTab[dynDefPos].dynStPosPtr) = ++LASTDYNST;
        }

        if (*(SV_DynDefManStTab[dynDefPos].objPosPtr) == NullEntity ||
            SV_DynDefManStTab[dynDefPos].dynTypeEnum == DynType_Other)
        {
            if (bNewDynSt)
            {
                SV_OtherDynDefMap.insert(make_pair(*(SV_DynDefManStTab[dynDefPos].dynStPosPtr), &SV_DynDefManStTab[dynDefPos]));
            }
        }
        else if (SV_DynDefManStTab[dynDefPos].dynTypeEnum == DynType_All)
        {
            SV_AllDynDefMap.insert(make_pair(*(SV_DynDefManStTab[dynDefPos].objPosPtr), &SV_DynDefManStTab[dynDefPos]));
        }
        else if (SV_DynDefManStTab[dynDefPos].dynTypeEnum == DynType_Short)
        {
            if (SV_ShortDynDefMap.insert(make_pair(*(SV_DynDefManStTab[dynDefPos].objPosPtr), &SV_DynDefManStTab[dynDefPos])).second == false)
            {
                SYS_BreakOnDebug();
            }
        }
        else
        {
            DdlGenContext    ddlgenContext(EV_RdbmsVendor);
            DdlGenMsg        stdMsg(&ddlgenContext);
            string msg = string("Unsupported Dyn Type Enum for structure ") + SV_DynDefManStTab[dynDefPos].dynStName;
            stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg);
        }
    }

    for (dynDefPos = 0; SV_DynDefGenStTab[dynDefPos].dynStPosPtr != &NullDynSt; dynDefPos++)
    {
        if (*(SV_DynDefGenStTab[dynDefPos].objPosPtr) != InvalidEntity)
        {
            *(SV_DynDefGenStTab[dynDefPos].dynStPosPtr) = ++LASTDYNST;

            if (SV_DynDefGenStTab[dynDefPos].dynTypeEnum == DynType_All)
            {
                SV_AllDynDefMap.insert(make_pair(*(SV_DynDefGenStTab[dynDefPos].objPosPtr), &SV_DynDefGenStTab[dynDefPos]));
            }
            else if (SV_DynDefGenStTab[dynDefPos].dynTypeEnum == DynType_Short)
            {
                if (SV_ShortDynDefMap.insert(make_pair(*(SV_DynDefGenStTab[dynDefPos].objPosPtr), &SV_DynDefGenStTab[dynDefPos])).second == false)
                {
                    SYS_BreakOnDebug();
                }
            }
            else
            {
                DdlGenContext    ddlgenContext(EV_RdbmsVendor);
                DdlGenMsg        stdMsg(&ddlgenContext);
                string msg = string("Unsupported Dyn Type Enum for structure ") + SV_DynDefGenStTab[dynDefPos].dynStName;
                stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg);
            }
        }
    }
}

/************************************************************************
**
**  Function    :   DBA_InitDynDefTabPtr()
**
**  Description :
**
**  Arguments   :   none
**
**  Return      :   none
**
*************************************************************************/
STATIC DBA_DYNDEF_STP DBA_InitDynDefTabPtr(DICT_ENTITY_STP dictEntityStp, DBA_DYNDEF_DEF_STP dynDefDefStp)
{
    /* PMSTA-34600 - LJE - 190402 - Case of S_Op shared with many entities */
    if (EV_DynStPtr != nullptr &&
        dynDefDefStp->dynStPosPtr != nullptr &&
        *(dynDefDefStp->dynStPosPtr) != 0 &&
        EV_DynStPtr[*(dynDefDefStp->dynStPosPtr)].dynDefPtr != nullptr &&
        EV_DynStPtr[*(dynDefDefStp->dynStPosPtr)].newVerDynStEn != NullDynSt)
    {
        return (EV_DynStPtr[*(dynDefDefStp->dynStPosPtr)].dynDefPtr);
    }

    int               cFieldMdNbr = 0, cFieldManNbr = 0, cFieldTemplNbr = 0;
    DBA_DYNTYPE_ENUM  dynTypeEnum = dynDefDefStp->dynTypeEnum;
    DBA_DYNDEF_STP    dynDefStp = (DBA_DYNDEF_STP)AaaMetaDict::getMemoryPool().calloc(1, sizeof(DBA_DYNDEF_ST));
    DBA_CFIELDDEF_STP cFieldTemplTab = NULL;
    DBA_CFIELDDEF_STP cFieldTab = NULL;

    std::map<INT_T, DictCriterClass*> *infoCriterMap = nullptr;

    if (dictEntityStp != nullptr && dictEntityStp->isMetaDict())
    {
        if (dynTypeEnum == DynType_Short)
        {
            infoCriterMap = &dictEntityStp->shortDictCriteriaMap;
        }
        else if (dynTypeEnum == DynType_All)
        {
            infoCriterMap = &dictEntityStp->allDictCriteriaMap;
        }
    }

    if (dynDefDefStp->cFieldMdTab != nullptr)
    {
        if (infoCriterMap != nullptr)
        {
            for (auto criterIt = infoCriterMap->begin(); criterIt != infoCriterMap->end(); ++criterIt)
            {
                DICT_CRITER_STP criterStp = criterIt->second;
                DICT_ATTRIB_STP   attrPtr = criterStp->attrPtr;

                if (criterStp->index >= 0 &&
                    (attrPtr == nullptr || (attrPtr->custFlg == FALSE && attrPtr->precompFlg == FALSE)))
                {
                    cFieldMdNbr++;
                }
            }

            for (int k = 0; dynDefDefStp->cFieldMdTab[k].dataTypeEnum != NullDataType; k++)
            {
                if (dynDefDefStp->cFieldMdTab[k].metaDictFlg == FALSE)
                {
                    cFieldMdNbr++;
                }
                dynDefDefStp->cFieldMdTab[k].treatedFlg   = FALSE;
                dynDefDefStp->cFieldMdTab[k].techFlg      = FALSE;    /* PMSTA-43741 - LJE - 210406 */
                dynDefDefStp->cFieldMdTab[k].bRealCField = true; /* PMSTA-53383 - LJE - 240109 */
            }
        }
        else
        {
            for (int k = 0; dynDefDefStp->cFieldMdTab[k].dataTypeEnum != NullDataType; k++)
            {
                dynDefDefStp->cFieldMdTab[k].treatedFlg   = FALSE;
                dynDefDefStp->cFieldMdTab[k].techFlg      = FALSE;    /* PMSTA-43741 - LJE - 210406 */
                dynDefDefStp->cFieldMdTab[k].bRealCField = true; /* PMSTA-53383 - LJE - 240109 */
                cFieldMdNbr++;
            }
        }
    }

    if (dynDefDefStp->cFieldManTab != nullptr)
    {
        for (int k = 0; dynDefDefStp->cFieldManTab[k].dataTypeEnum != NullDataType; k++)
        {
            dynDefDefStp->cFieldManTab[k].treatedFlg  = FALSE;
            dynDefDefStp->cFieldManTab[k].techFlg     = FALSE;    /* PMSTA-43741 - LJE - 210406 */
            dynDefDefStp->cFieldManTab[k].bRealCField = true; /* PMSTA-53383 - LJE - 240109 */
            cFieldManNbr++;
        }
    }

    /* PMSTA26250 - DDV - 170331 - Get attribute templates to add to dynSt (All or Short) */
    if (EV_AAAInstallLevel == 0)
    {
        if (dynDefDefStp->cFieldManTab != SV_ManFieldDef_A_DictAttributeTemplate &&
            dynDefDefStp->cFieldManTab != SV_ManFieldDef_S_DictAttributeTemplate)
        {
            if (dynTypeEnum == DynType_All || dynTypeEnum == DynType_Other)
            {
                cFieldTemplTab = SV_ManFieldDef_A_DictAttributeTemplate;
            }

            if (dynTypeEnum == DynType_Short)
            {
                cFieldTemplTab = SV_ManFieldDef_S_DictAttributeTemplate;
            }

            if (cFieldTemplTab != NULL)
            {
                for (int i = 0; cFieldTemplTab[i].fieldPosPtr != NULL; i++)
                {
                    cFieldTemplNbr++;
                }
            }
        }
    }

    dynDefStp->objPos = (*dynDefDefStp->objPosPtr);

    if (dynDefDefStp->dynStPosPtr == nullptr)
    {
        dynDefStp->dynStPos = ++LASTDYNST;
    }
    else
    {
        dynDefStp->dynStPos = *(dynDefDefStp->dynStPosPtr);
    }

    if (dynDefDefStp->dynStName)
    {
        dynDefStp->dynStName = dynDefDefStp->dynStName;
    }
    dynDefStp->dynTypeEnum = dynDefDefStp->dynTypeEnum;

    int j = 0;

    if (cFieldMdNbr > 0 || cFieldManNbr > 0)
    {
        cFieldTab = (DBA_CFIELDDEF_STP)AaaMetaDict::getMemoryPool().calloc(cFieldMdNbr + cFieldManNbr + cFieldTemplNbr + 1, sizeof(DBA_CFIELDDEF_ST));

        if (infoCriterMap != nullptr)
        {
            int  i = 0;

            for (auto criterIt = infoCriterMap->begin(); criterIt != infoCriterMap->end(); ++criterIt)
            {
                DICT_CRITER_STP criterStp = criterIt->second;
                DICT_ATTRIB_STP   attrPtr = criterStp->attrPtr;

                if (attrPtr == nullptr)
                {
                    attrPtr = criterStp->entAttrPtr;
                }
                if (criterStp->index >= 0 &&
                    (attrPtr == nullptr || (attrPtr->custFlg == FALSE && attrPtr->precompFlg == FALSE)))
                {
                    bool bFromBegin = false;
                    do
                    {
                        if (dynDefDefStp->cFieldMdTab[i].dataTypeEnum == NullDataType)
                        {
                            bFromBegin = true;
                            i = 0;
                        }

                        for (; dynDefDefStp->cFieldMdTab[i].dataTypeEnum != NullDataType; i++)
                        {
                            if (strcmp(dynDefDefStp->cFieldMdTab[i].sqlName, criterStp->sqlName) == 0)
                            {
                                break;
                            }
                        }

                    } while (dynDefDefStp->cFieldMdTab[i].dataTypeEnum == NullDataType && bFromBegin == false);


                    if (dynDefDefStp->cFieldMdTab[i].dataTypeEnum == NullDataType)
                    {
                        char *sqlName = AaaMetaDict::getMemoryPool().allocChar(FILEINFO, strlen(criterStp->sqlName) + 1);

                        sprintf(sqlName, "%s", criterStp->sqlName);
                        cFieldTab[j].dataTypeEnum = attrPtr ? attrPtr->dataTpProgN : NullDataType;
                        cFieldTab[j].dbFlg        = (attrPtr && attrPtr->calcEn != DictAttr_Virtual ? TRUE : FALSE);
                        cFieldTab[j].metaDictFlg  = TRUE;
                        cFieldTab[j].sqlName      = sqlName;
                        cFieldTab[j].treatedFlg   = FALSE;
                        cFieldTab[j].bRealCField  = false; /* PMSTA-53383 - LJE - 240109 */

                        cFieldTab[j].fieldPosPtr = (FIELD_IDX_T*)AaaMetaDict::getMemoryPool().calloc(1, sizeof(FIELD_IDX_T));
                        *(cFieldTab[j].fieldPosPtr) = j;
                    }
                    else
                    {
                        cFieldTab[j] = dynDefDefStp->cFieldMdTab[i];
                        dynDefDefStp->cFieldMdTab[i].treatedFlg = TRUE;
                    }

                    cFieldTab[j].subFeatureEn = SubFeature::None;    /* PMSTA-46259 - LJE - 211007 */
                    ++j;
                }
            }

            for (int cFiledPos = 0; dynDefDefStp->cFieldMdTab[cFiledPos].dataTypeEnum != NullDataType; cFiledPos++)
            {
                if (AAACHECKDYNFLD)
                {
                    if (dictEntityStp->isMetaDict() &&
                        dynDefDefStp->cFieldMdTab[cFiledPos].treatedFlg == FALSE &&
                        ((dynTypeEnum == DynType_All && dynDefDefStp->cFieldMdTab[cFiledPos].metaDictFlg == TRUE) ||
                        (dynTypeEnum == DynType_Short &&
                         dynDefDefStp->cFieldMdTab[cFiledPos].dbFlg == TRUE &&
                         dynDefDefStp->cFieldMdTab[cFiledPos].metaDictFlg == TRUE)) &&
                        EV_AAAInstallLevel == 0)
                    {
                        DdlGenContext    ddlgenContext(EV_RdbmsVendor);
                        DdlGenMsg        stdMsg(&ddlgenContext);

                        stringstream msg;
                        msg << "Unknown attribute defined in meta-dictionary dynamic structure: " << dictEntityStp->mdSqlName << "." << dynDefStp->dynStName << "." << dynDefDefStp->cFieldMdTab[cFiledPos].sqlName;

                        stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg.str());
                    }
                }
                if (dynDefDefStp->cFieldMdTab[cFiledPos].treatedFlg == FALSE &&
                    dynDefDefStp->cFieldMdTab[cFiledPos].metaDictFlg == FALSE)
                {
                    cFieldTab[j] = dynDefDefStp->cFieldMdTab[cFiledPos];
                    j++;
                    dynDefDefStp->cFieldMdTab[cFiledPos].treatedFlg = TRUE;
                }
            }
        }
        else
        {
            for (int cFiledPos = 0; cFiledPos < cFieldMdNbr; j++, cFiledPos++)
            {
                cFieldTab[j] = dynDefDefStp->cFieldMdTab[cFiledPos];
                dynDefDefStp->cFieldMdTab[cFiledPos].treatedFlg = TRUE;
                cFieldTab[j].subFeatureEn = SubFeature::None;    /* PMSTA-46259 - LJE - 211007 */
            }
        }

        for (int cFiledPos = 0; cFiledPos < cFieldManNbr; j++, cFiledPos++)
        {
            cFieldTab[j] = dynDefDefStp->cFieldManTab[cFiledPos];
            dynDefDefStp->cFieldManTab[cFiledPos].treatedFlg = TRUE;
            cFieldTab[j].subFeatureEn = SubFeature::None;    /* PMSTA-46259 - LJE - 211007 */
        }

        /* PMSTA26250 - DDV - 170331 - Add template fields */
        for (int cFiledPos = 0; cFiledPos < cFieldTemplNbr; j++, cFiledPos++)
        {
            cFieldTab[j] = cFieldTemplTab[cFiledPos];

            char *sqlName = AaaMetaDict::getMemoryPool().allocChar(FILEINFO, strlen(cFieldTemplTab[cFiledPos].sqlName) + 1);

            sprintf(sqlName, "%s", cFieldTemplTab[cFiledPos].sqlName);
            cFieldTab[j].sqlName = sqlName;

            cFieldTab[j].treatedFlg  = FALSE;
            cFieldTab[j].techFlg     = TRUE;       /* PMSTA-43741 - LJE - 210406 */
            cFieldTab[j].bRealCField = false; /* PMSTA-53383 - LJE - 240109 */

            cFieldTab[j].fieldPosPtr = (FIELD_IDX_T*)AaaMetaDict::getMemoryPool().calloc(1, sizeof(FIELD_IDX_T));

            *(cFieldTab[j].fieldPosPtr) = j;
        }
    }
    else if (infoCriterMap != nullptr)
    {
        if (dynDefDefStp->dynStName == nullptr)
        {
            string entityCName;
            STRING_Capitalize(dictEntityStp->mdSqlName, entityCName);

            char *name = AaaMetaDict::getMemoryPool().allocChar(FILEINFO, entityCName.length() + 3);

            if (dynTypeEnum == DynType_All)
            {
                sprintf(name, "A_%s", entityCName.c_str());
            }
            else
            {
                sprintf(name, "S_%s", entityCName.c_str());
            }
            dynDefStp->dynStName = name;
        }

        if (infoCriterMap->size() > 0)
        {
            j = 0;
            cFieldTab = (DBA_CFIELDDEF_STP)AaaMetaDict::getMemoryPool().calloc(infoCriterMap->size() + 1, sizeof(DBA_CFIELDDEF_ST));

            for (auto criterIt = infoCriterMap->begin(); criterIt != infoCriterMap->end(); ++criterIt, j++)
            {
                DICT_CRITER_STP criterStp = criterIt->second;
                DICT_ATTRIB_STP   attrPtr = criterStp->attrPtr;

                if (attrPtr == nullptr)
                {
                    attrPtr = criterStp->entAttrPtr;
                }

                if (criterStp->index >= 0 &&
                    (attrPtr == nullptr || (attrPtr->custFlg == FALSE && attrPtr->precompFlg == FALSE)))
                {
                    char *sqlName = AaaMetaDict::getMemoryPool().allocChar(FILEINFO, strlen(criterStp->sqlName) + 1);

                    sprintf(sqlName, "%s", criterStp->sqlName);
                    cFieldTab[j].dataTypeEnum = attrPtr != nullptr ? attrPtr->dataTpProgN : NullDataType;
                    cFieldTab[j].dbFlg        = (attrPtr != nullptr && attrPtr->calcEn != DictAttr_Virtual ? TRUE : FALSE);
                    cFieldTab[j].metaDictFlg  = TRUE;
                    cFieldTab[j].sqlName      = sqlName;
                    cFieldTab[j].treatedFlg   = FALSE;
                    cFieldTab[j].techFlg      = FALSE;       /* PMSTA-43741 - LJE - 210406 */
                    cFieldTab[j].bRealCField  = false; /* PMSTA-53383 - LJE - 240109 */
                    cFieldTab[j].fieldPosPtr  = (FIELD_IDX_T*)AaaMetaDict::getMemoryPool().calloc(1, sizeof(FIELD_IDX_T));

                    *(cFieldTab[j].fieldPosPtr) = j;
                }
            }
        }
    }

    if (cFieldTab == nullptr)
    {
        cFieldTab = (DBA_CFIELDDEF_STP)AaaMetaDict::getMemoryPool().calloc(1, sizeof(DBA_CFIELDDEF_ST));
    }

    char *sqlName = (char*)AaaMetaDict::getMemoryPool().calloc(1, sizeof(char));

    cFieldTab[j].dataTypeEnum = NullDataType;
    cFieldTab[j].dbFlg        = FALSE;
    cFieldTab[j].metaDictFlg  = FALSE;
    cFieldTab[j].sqlName      = sqlName;
    cFieldTab[j].treatedFlg   = FALSE;
    cFieldTab[j].bRealCField  = false; /* PMSTA-53383 - LJE - 240109 */
    cFieldTab[j].techFlg      = FALSE;       /* PMSTA-43741 - LJE - 210406 */
    cFieldTab[j].fieldPosPtr  = NULL;

    dynDefStp->cFieldTab = cFieldTab;

    return dynDefStp;
}

/************************************************************************
**
**  Function    :   DBA_InitDynStPtr()
**
**  Description :   Init some fields of EV_DynStPtr
**                  Old : Initialize EV_DynStPtr on table SV_DynStTab.
**
**  Arguments   :   none
**
**  Return      :   none
**
*************************************************************************/
void DBA_InitDynStPtr()
{
    OBJECT_ENUM    objEn;
    DBA_DYNST_ENUM dynStEn;

    DBA_DYNDEF_DEF_ST allGenDynDefSt, shortGenDynDefSt;

    SYS_Bzero(&allGenDynDefSt, sizeof(DBA_DYNDEF_DEF_ST));
    SYS_Bzero(&shortGenDynDefSt, sizeof(DBA_DYNDEF_DEF_ST));
    allGenDynDefSt.objPosPtr     = &objEn;
    allGenDynDefSt.dynTypeEnum   = DynType_All;
    shortGenDynDefSt.objPosPtr   = &objEn;
    shortGenDynDefSt.dynTypeEnum = DynType_Short;

    EV_EntityGuiStNb = LASTOBJECT + 1;                   /* PMSTA-15031 - 210912 - PMO */
    EV_EntityGuiStPtr = (DBA_GUIDYNST_STP)AaaMetaDict::getMemoryPool().calloc(static_cast<size_t>(EV_EntityGuiStNb), sizeof(DBA_GUIDYNST_ST));
    EV_DynStPtr = (DBA_DYNST_STP)AaaMetaDict::getMemoryPool().calloc((2 * static_cast<size_t>(EV_EntityGuiStNb)) + SV_OtherDynDefMap.size() + 1, sizeof(DBA_DYNST_ST));
    SV_EntityGuiStTabSize = EV_EntityGuiStNb;

    for (objEn = 0; objEn <= LASTOBJECT; objEn++)
    {
        DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(objEn);

        EV_EntityGuiStPtr[objEn].objectCst         = NullEntityCst;
        EV_EntityGuiStPtr[objEn].objDefTabPtr      = nullptr;
        EV_EntityGuiStPtr[objEn].editDynDefTabPtr  = nullptr;  /* PMSTA-13122 - LJE - 120418 */
        EV_EntityGuiStPtr[objEn].adminDynDefTabPtr = nullptr;  /* PMSTA-13122 - LJE - 120418 */
        EV_EntityGuiStPtr[objEn].allDynDefStp      = nullptr;  /* PMSTA-nuodb - LJE - 190515 */
        EV_EntityGuiStPtr[objEn].shortDynDefStp    = nullptr;  /* PMSTA-nuodb - LJE - 190515 */
        EV_EntityGuiStPtr[objEn].objAllocateFlg    = TRUE;  /* REF9789 - LJE - 031230 */

        DBA_OBJDEF_STP objDefStp = DBA_GetObjDefStp(objEn);

        if (*(objDefStp->objPosPtr) == objEn)
        {
            EV_EntityGuiStPtr[objEn].objectCst = objDefStp->objCst;
            EV_EntityGuiStPtr[objEn].objDefTabPtr = objDefStp; /* PMSTA-13122 - LJE - 120418 */

            if (dictEntityStp != nullptr &&
                dictEntityStp->entDictId != EV_EntityGuiStPtr[objEn].objectCst)
            {
                string           msg;
                DdlGenContext    ddlgenContext(EV_RdbmsVendor);
                DdlGenMsg        stdMsg(&ddlgenContext);

                SYS_StringFormat(msg, "Wrong Entity Constant value for entity %s, is %d but should be %d", dictEntityStp->mdSqlName, EV_EntityGuiStPtr[objEn].objectCst, dictEntityStp->entDictId);

                stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg);
            }
        }

        /* PMSTA-13122 - LJE - 120418 */
        if (*(objDefStp->objPosPtr) == NullEntity)
        {
            EV_EntityGuiStPtr[objEn].objDefTabPtr = (DBA_OBJDEF_STP)AaaMetaDict::getMemoryPool().calloc(1, sizeof(DBA_OBJDEF_ST));

            EV_EntityGuiStPtr[objEn].objDefTabPtr->objCst = NullEntityCst;
            EV_EntityGuiStPtr[objEn].objDefTabPtr->objPosPtr = (OBJECT_ENUM*)AaaMetaDict::getMemoryPool().calloc(1, sizeof(OBJECT_ENUM));

            *(EV_EntityGuiStPtr[objEn].objDefTabPtr->objPosPtr) = objEn;

            if (dictEntityStp != nullptr)
            {
                string entityCName;
                STRING_Capitalize(dictEntityStp->mdSqlName, entityCName);

                char *name = (char*)AaaMetaDict::getMemoryPool().calloc(entityCName.length() + 1, sizeof(char));

                strcpy(name, entityCName.c_str());
                EV_EntityGuiStPtr[objEn].objDefTabPtr->objName = name;

                name = (char*)AaaMetaDict::getMemoryPool().calloc(strlen(dictEntityStp->mdSqlName) + 1, sizeof(char));

                strcpy(name, dictEntityStp->mdSqlName);
                EV_EntityGuiStPtr[objEn].objDefTabPtr->sqlName = name;
            }
            EV_EntityGuiStPtr[objEn].objDefTabPtr->procDefStp = NULL;
        }

        /* Search the all */
        DBA_DYNDEF_DEF_STP allDynDefStp;
        auto allDynDef = SV_AllDynDefMap.find(objEn);
        if (allDynDef != SV_AllDynDefMap.end())
        {
            allDynDefStp = allDynDef->second;
            EV_EntityGuiStPtr[objEn].allDynDefStp = allDynDefStp;
        }
        else
        {
            allDynDefStp = &allGenDynDefSt;
        }
        EV_EntityGuiStPtr[objEn].editDynDefTabPtr = DBA_InitDynDefTabPtr(dictEntityStp, allDynDefStp);
        EV_EntityGuiStPtr[objEn].edit = EV_EntityGuiStPtr[objEn].editDynDefTabPtr->dynStPos;

        /* Search the short */
        DBA_DYNDEF_DEF_STP shortDynDefStp;
        auto shortDynDef = SV_ShortDynDefMap.find(objEn);
        if (shortDynDef != SV_ShortDynDefMap.end())
        {
            shortDynDefStp = shortDynDef->second;
            EV_EntityGuiStPtr[objEn].shortDynDefStp = shortDynDefStp;
        }
        else
        {
            shortDynDefStp = &shortGenDynDefSt;
        }

        if (shortDynDefStp->dynStPosPtr != nullptr || 
            (dictEntityStp != nullptr && 
             (dictEntityStp->shortDictCriteriaMap.empty() == false || dictEntityStp->entNatEn == EntityNat_All)))
        {
            EV_EntityGuiStPtr[objEn].adminDynDefTabPtr = DBA_InitDynDefTabPtr(dictEntityStp, shortDynDefStp);
        }
        else
        {
            EV_EntityGuiStPtr[objEn].adminDynDefTabPtr = EV_EntityGuiStPtr[objEn].editDynDefTabPtr;
        }
        EV_EntityGuiStPtr[objEn].admin = EV_EntityGuiStPtr[objEn].adminDynDefTabPtr->dynStPos;

        if (EV_EntityGuiStPtr[objEn].edit == NullDynSt)
        {
            string           msg;
            DdlGenContext    ddlgenContext(EV_RdbmsVendor);
            DdlGenMsg        stdMsg(&ddlgenContext);

            SYS_StringFormat(msg, "Problem with entity %s", OBJ_V2N(objEn));

            stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg);
        }

        dynStEn = EV_EntityGuiStPtr[objEn].edit;
        EV_DynStPtr[dynStEn].noMDFldNbr = 0;
        EV_DynStPtr[dynStEn].fldNbr = 0;
        if (EV_DynStPtr[dynStEn].entity == 0)
        {
            EV_DynStPtr[dynStEn].entity = objEn;

            assert(objEn == *(EV_EntityGuiStPtr[objEn].objDefTabPtr->objPosPtr));
        }
        EV_DynStPtr[dynStEn].dynStDefPtr      = NULL;
        EV_DynStPtr[dynStEn].custEntityObj    = NullEntity;
        EV_DynStPtr[dynStEn].precompEntityObj = NullEntity; /* PMSTA-11505 - LJE - 110622 */
        EV_DynStPtr[dynStEn].dynDefPtr        = EV_EntityGuiStPtr[objEn].editDynDefTabPtr; /* PMSTA-13122 - LJE - 120419 */

        if (EV_EntityGuiStPtr[objEn].admin != EV_EntityGuiStPtr[objEn].edit)
        {
            dynStEn = EV_EntityGuiStPtr[objEn].admin;
            EV_DynStPtr[dynStEn].noMDFldNbr = 0;
            EV_DynStPtr[dynStEn].fldNbr = 0;
            if (EV_DynStPtr[dynStEn].entity == 0)
            {
                EV_DynStPtr[dynStEn].entity = objEn;

                assert(objEn == *(EV_EntityGuiStPtr[objEn].objDefTabPtr->objPosPtr));
            }
            EV_DynStPtr[dynStEn].dynStDefPtr      = NULL;
            EV_DynStPtr[dynStEn].custEntityObj    = NullEntity;
            EV_DynStPtr[dynStEn].precompEntityObj = NullEntity;
            EV_DynStPtr[dynStEn].dynDefPtr        = EV_EntityGuiStPtr[objEn].adminDynDefTabPtr; /* PMSTA-13122 - LJE - 120419 */
        }
    }

    AaaMetaDict::getDynStByNameMap().clear();

    for (dynStEn = 0; dynStEn <= LASTDYNST; dynStEn++)
    {
        if (EV_DynStPtr[dynStEn].dynDefPtr == nullptr)
        {
            auto dynStOther = SV_OtherDynDefMap.find(dynStEn);
            if (dynStOther != SV_OtherDynDefMap.end())
            {
                EV_DynStPtr[dynStEn].noMDFldNbr       = 0;
                EV_DynStPtr[dynStEn].fldNbr           = 0;
                EV_DynStPtr[dynStEn].entity           = *(dynStOther->second->objPosPtr);
                EV_DynStPtr[dynStEn].dynStDefPtr      = NULL;
                EV_DynStPtr[dynStEn].custEntityObj    = NullEntity;
                EV_DynStPtr[dynStEn].precompEntityObj = NullEntity; /* PMSTA-11505 - LJE - 110622 */
                EV_DynStPtr[dynStEn].dynDefPtr        = DBA_InitDynDefTabPtr(nullptr, dynStOther->second);
                if (EV_DynStPtr[dynStEn].dynDefPtr != nullptr)
                {
                    EV_DynStPtr[dynStEn].dynTypeEnum = EV_DynStPtr[dynStEn].dynDefPtr->dynTypeEnum;
                }
            }
            else
            {
                string           msg;
                DdlGenContext    ddlgenContext(EV_RdbmsVendor);
                DdlGenMsg        stdMsg(&ddlgenContext);

                SYS_StringFormat(msg, "Problem with dynamic structure %d", dynStEn);

                stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg);
            }
        }

        if (EV_DynStPtr[dynStEn].dynDefPtr != nullptr &&
            EV_DynStPtr[dynStEn].dynDefPtr->dynStName != nullptr)
        {
            string upDynStName = EV_DynStPtr[dynStEn].dynDefPtr->dynStName;
            upper(upDynStName);
            AaaMetaDict::getDynStByNameMap().insert(std::make_pair(upDynStName, dynStEn));
        }
    }
}


/************************************************************************
**
**  Function    :   DBA_GetDynStCName()
**
**  Description : Return the "C" name of dynamic structure enum
**
**  Arguments   : dynStEn
**
**  Return      :
**
*************************************************************************/
const char *DBA_GetDynStCName(DBA_DYNST_ENUM dynStEn)
{
    if (dynStEn == NullDynSt)
        return("NullDynSt");

    if (dynStEn > LASTDYNST || dynStEn < 0)
        return ("Value not found");

    if (EV_DynStPtr[dynStEn].dynDefPtr == NULL)
    {
        DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(EV_DynStPtr[dynStEn].entity);
        if (dictEntityStp == NULL)
        {
            return ("Value not found");
        }
        else
        {
            return (dictEntityStp->mdSqlName);
        }
    }

    return (EV_DynStPtr[dynStEn].dynDefPtr->dynStName); /* PMSTA-13122 - LJE - 120419 */
}

/************************************************************************
**
**  Function    :   DBA_GetObjectCName()
**
**  Description : Return the "C" name of object enum
**
**  Arguments   : objEn
**
**  Return      :
**
*************************************************************************/
const char *DBA_GetObjectCName(OBJECT_ENUM objEn)
{
    if (objEn == NullEntity)
        return ("NullEntity");

    if (objEn > LASTOBJECT || objEn < 0)
        return ("Value not found");

    if (EV_EntityGuiStPtr[objEn].objDefTabPtr == NULL)
    {
        DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(objEn);
        if (dictEntityStp == NULL)
        {
            return ("Value not found");
        }
        else
        {
            return (dictEntityStp->mdSqlName);
        }
    }

    return (EV_EntityGuiStPtr[objEn].objDefTabPtr->objName);
}

/************************************************************************
**
**  Function    :   DBA_GetCFieldDef()
**
**  Description : Return the "C" field definition
**
**  Arguments   :
**
**  Return      :
**
*************************************************************************/
DBA_CFIELDDEF_STP DBA_GetCFieldDef(DBA_DYNST_ENUM    dynStEn,
                                   int               field,
                                   FLAG_T            *allocFlg
)
{
    int               j = 0;
    DBA_CFIELDDEF_STP locCFieldDefStp = NULL;
    DBA_DYNDEF_STP    dynDefStp = NULL;
    DBA_DYNST_STP     dynStStp = NULL;

    if (allocFlg != NULL)
        *allocFlg = FALSE;

    dynStStp = &(EV_DynStPtr[dynStEn]);
    dynDefStp = dynStStp->dynDefPtr;

    if (dynDefStp != NULL)
    {
        if (dynDefStp->cFieldTab)
        {
            for (j = 0; dynDefStp->cFieldTab[j].fieldPosPtr != NULL &&
                 *(dynDefStp->cFieldTab[j].fieldPosPtr) != field; j++)
            {
            }

            if (dynDefStp->cFieldTab[j].fieldPosPtr)
            {
                locCFieldDefStp = &(dynDefStp->cFieldTab[j]);
            }
        }
    }

    if (locCFieldDefStp == NULL)
    {
        if (dynStStp->dynTypeEnum == DynType_All && field < GET_FLD_NBR(dynStEn))
        {
            DICT_ATTRIB_STP   attribStp(nullptr);

            /* Search in ud field */
            if (allocFlg != NULL &&
                (attribStp = DBA_GetDictAttribSt(dynStStp->entity, field)) != NULL)
            {
                locCFieldDefStp = (DBA_CFIELDDEF_STP)CALLOC(1, sizeof(DBA_CFIELDDEF_ST));

                *allocFlg = TRUE;

                locCFieldDefStp->sqlName = (const char*)attribStp->sqlName;
                locCFieldDefStp->dbFlg = IS_DBFLD(dynStEn, field);
                locCFieldDefStp->fieldPosPtr = (FIELD_IDX_T*)&(attribStp->progN);
                locCFieldDefStp->dataTypeEnum = GET_FLD_TYPE(dynStEn, field);
                locCFieldDefStp->metaDictFlg = TRUE;

                return (locCFieldDefStp);
            }
        }
        else if (dynStStp->dynTypeEnum == DynType_Other && field < GET_FLD_NBR(dynStEn))
        {
            if (allocFlg != NULL)
            {
                locCFieldDefStp = (DBA_CFIELDDEF_STP)CALLOC(1, sizeof(DBA_CFIELDDEF_ST));

                *allocFlg = TRUE;

                locCFieldDefStp->sqlName      = (const char*)dynStStp->dynStDefPtr[field].sqlName;
                locCFieldDefStp->dbFlg        = IS_DBFLD(dynStEn, field);
                locCFieldDefStp->fieldPosPtr  = nullptr;
                locCFieldDefStp->dataTypeEnum = GET_FLD_TYPE(dynStEn, field);
                locCFieldDefStp->metaDictFlg  = TRUE;

                return (locCFieldDefStp);
            }
        }
        return (NULL);
    }

    return (locCFieldDefStp);
}


/************************************************************************
**
**  Function    :   DBA_GetCFielBySqlName()
**
**  Description : Return the "C" field definition
**
**  Arguments   :
**
**  Return      :
**
*************************************************************************/
DBA_CFIELDDEF_STP DBA_GetCFielBySqlName(DBA_DYNST_ENUM    dynStEn,
                                        const char *      sqlName,
                                        FLAG_T            *allocFlg)
{
    int               j;
    DICT_ATTRIB_STP   attribStp;
    DBA_CFIELDDEF_STP locCFieldDefStp = NULL;
    DBA_DYNDEF_STP    dynDefStp = NULL;

    /* PMSTA-26108 - LJE - 170811 */
    if (dynStEn == NullDynSt)
    {
        return (NULL);
    }

    if (allocFlg != NULL)
        *allocFlg = FALSE;

    dynDefStp = EV_DynStPtr[dynStEn].dynDefPtr;

    if (dynDefStp == NULL || sqlName == NULL || sqlName[0] == 0 || dynDefStp->cFieldTab == NULL)
    {
        return (NULL);
    }

    if (dynDefStp != NULL)
    {
        if (dynDefStp->cFieldTab)
        {
            for (j = 0; dynDefStp->cFieldTab[j].fieldPosPtr != NULL &&
                 strcmp(dynDefStp->cFieldTab[j].sqlName, sqlName); j++)
            {
            }

            if (dynDefStp->cFieldTab[j].fieldPosPtr)
            {
                locCFieldDefStp = &(dynDefStp->cFieldTab[j]);
            }
        }
    }

    if (locCFieldDefStp == NULL)
    {
        if (dynDefStp->dynTypeEnum == DynType_All)
        {
            /* Search in ud field */
            if (allocFlg != NULL &&
                (attribStp = DBA_GetAttributeBySqlName(dynDefStp->objPos, sqlName, TRUE)) != NULL)
            {
                locCFieldDefStp = (DBA_CFIELDDEF_STP)CALLOC(1, sizeof(DBA_CFIELDDEF_ST));

                *allocFlg = TRUE;

                locCFieldDefStp->sqlName = (const char*)attribStp->sqlName;
                locCFieldDefStp->dbFlg = attribStp->calcEn != DictAttr_Virtual;
                locCFieldDefStp->fieldPosPtr = (FIELD_IDX_T*)&(attribStp->progN);
                locCFieldDefStp->dataTypeEnum = attribStp->dataTpProgN;
                locCFieldDefStp->metaDictFlg = TRUE;

                return (locCFieldDefStp);
            }

        }
        return (NULL);
    }

    return (locCFieldDefStp);
}

/************************************************************************
**
**  Function    :   DBA_GetDynStByCName()
**
**  Description : Return dynamic structure enum by the "C" name
**
**  Arguments   :
**
**  Return      :
**
*************************************************************************/
DBA_DYNST_ENUM DBA_GetDynStByCName(const char *cName)
{
    DBA_DYNDEF_STP dynDefStp = DBA_GetDynDefStTab(cName);

    if (dynDefStp)
    {
        return dynDefStp->dynStPos;
    }
    return NullDynSt;
}

/************************************************************************
**
**  Function    :   DBA_GetObjectByCName()
**
**  Description : Return object enum by the "C" name
**
**  Arguments   :
**
**  Return      :
**
*************************************************************************/
OBJECT_ENUM DBA_GetObjectByCName(const char *cName)
{
    auto it = SV_ObjDefByCNameMap.find(cName);

    if (it != SV_ObjDefByCNameMap.end())
    {
        return (*(it->second->objPosPtr));
    }

    for (it = SV_ObjDefByCNameMap.begin(); it != SV_ObjDefByCNameMap.end(); ++it)
    {
        if (strcasecmp(cName, it->second->objName) == 0)
        {
            return (*(it->second->objPosPtr));
        }
    }
    return NullEntity;
}


/************************************************************************
**
**  Function    :   DBA_GetObjectBySqlName()
**
**  Description : Return object enum by the SQL name
**
**  Arguments   :
**
**  Return      :
**
*************************************************************************/
OBJECT_ENUM DBA_GetObjectBySqlName(const char *sqlName)
{
    DBA_OBJDEF_STP objDefStp = DBA_GetObjDefBySqlName(sqlName);

    if (objDefStp != nullptr)
    {
        return (*(objDefStp->objPosPtr));
    }
    return NullEntity;
}

/************************************************************************
**
**  Function    :   DBA_GetObjDefBySqlName()
**
**  Description : Return object definition by the SQL name
**                Be careful, it's the hard-coded definition, not the run-time definition !!!!!
**
**  Arguments   :
**
**  Return      :
**
*************************************************************************/
DBA_OBJDEF_STP DBA_GetObjDefBySqlName(const char *sqlName)
{
    auto it = SV_ObjDefMap.find(sqlName);

    if (it != SV_ObjDefMap.end())
    {
        return it->second;
    }

    return nullptr;
}

/************************************************************************
**
**  Function    :   DBA_GetDynStDefBySqlName()
**
**  Description : Return object definition by the SQL name
**                Be careful, it's the hard-coded definition, not the run-time definition !!!!!
**
**  Arguments   :
**
**  Return      :
**
*************************************************************************/
DBA_DYNDEF_DEF_STP DBA_GetDynStDefBySqlName(const char *sqlName, DBA_DYNTYPE_ENUM  dynTypeEnum)
{
    DBA_OBJDEF_STP objDefStp = DBA_GetObjDefBySqlName(sqlName);

    if (objDefStp)
    {
        if (dynTypeEnum == DynType_All)
        {
            auto it = SV_AllDynDefMap.find(*(objDefStp->objPosPtr));

            if (it != SV_AllDynDefMap.end())
            {
                return it->second;
            }
        }
        else if (dynTypeEnum == DynType_Short)
        {
            auto it = SV_ShortDynDefMap.find(*(objDefStp->objPosPtr));

            if (it != SV_ShortDynDefMap.end())
            {
                return it->second;
            }
        }
    }

    return nullptr;
}

/************************************************************************
**
**  Function    :   DBA_GetCObjDefList()
**
**  Description : Return object definition by the SQL name
**                Be careful, it's the hard-coded definition, not the run-time definition !!!!!
**
**  Arguments   :
**
**  Return      :
**
**  Modif.      : PMSTA-26250 - LJE - 170327
**
*************************************************************************/
std::list<DBA_OBJDEF_STP> &DBA_GetCObjDefList()
{
    return SV_CObjDefList;
}

/************************************************************************
**
**  Function    :   DBA_GetNewIndexAttrib()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
*************************************************************************/
STATIC DBA_CFIELDDEF_STP DBA_GetNewIndexAttrib(DBA_DYNDEF_STP dynDefPtr, const char *sqlName)
{
    /* PMSTA-24564 - LJE - 161215 */
    if (dynDefPtr->dynStPos != NullDynSt)
    {
        /* Search in c definition */
        if (dynDefPtr->cFieldTab != nullptr)
        {
            for (FIELD_IDX_T i = 0; dynDefPtr->cFieldTab[i].fieldPosPtr; i++)
            {
                if (strcmp(dynDefPtr->cFieldTab[i].sqlName, sqlName) == 0)
                {
                    dynDefPtr->cFieldTab[i].treatedFlg = TRUE;
                    return &(dynDefPtr->cFieldTab[i]);
                }
            }
        }
    }
    return nullptr;
}

/************************************************************************
**
**  Function    :   DBA_CreateDynStDef()
**
**  Description :
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED or error code
**
*************************************************************************/
RET_CODE DBA_CreateDynStDef(OBJECT_ENUM restrictObjectEn, bool bFromImport)
{
    string           msg;
    DdlGenContext    ddlgenContext(EV_RdbmsVendor);
    DdlGenMsg        stdMsg(&ddlgenContext);

    if (restrictObjectEn != NullEntity)
    {
        if (EV_DynStPtr[EV_EntityGuiStPtr[restrictObjectEn].edit].entity != restrictObjectEn)
        {
            return RET_SUCCEED;
        }

        if (EV_DynStPtr[EV_EntityGuiStPtr[restrictObjectEn].admin].allocCpt != 0 && bFromImport == false)
        {
            return RET_GEN_INFO_NOACTION;
        }

        if (EV_DynStPtr[EV_EntityGuiStPtr[restrictObjectEn].edit].allocCpt != 0 ||
            EV_DynStPtr[EV_EntityGuiStPtr[restrictObjectEn].admin].allocCpt != 0)
        {
            if (bFromImport == false)
            {
                auto dictEntityStp = DBA_GetDictEntitySt(restrictObjectEn);
                if (dictEntityStp != nullptr &&
                    dictEntityStp->bIsInitEntity)
                {
                    return RET_GEN_INFO_NOACTION;
                }
            }

            DBA_DYNST_ENUM oldVerDynStEn = EV_EntityGuiStPtr[restrictObjectEn].edit;

            EV_DynStPtr[oldVerDynStEn].newVerDynStEn = ++LASTDYNST;

            EV_EntityGuiStPtr[restrictObjectEn].edit = LASTDYNST;
            EV_DynStPtr = (DBA_DYNST_STP)AaaMetaDict::getMemoryPool().realloc(EV_DynStPtr, (LASTDYNST + 1) * sizeof(DBA_DYNST_ST));

            auto newDynStPtr = &EV_DynStPtr[EV_EntityGuiStPtr[restrictObjectEn].edit];

            memset(newDynStPtr, 0, sizeof(DBA_DYNST_ST));
            newDynStPtr->init(restrictObjectEn);

            EV_DynStPtr[LASTDYNST].dynTypeEnum = EV_DynStPtr[oldVerDynStEn].dynTypeEnum;

            (*EV_EntityGuiStPtr[restrictObjectEn].allDynDefStp->dynStPosPtr) = LASTDYNST;
        }

        if (EV_DynStPtr[EV_EntityGuiStPtr[restrictObjectEn].edit].dynDefPtr ==
            EV_DynStPtr[EV_EntityGuiStPtr[restrictObjectEn].admin].dynDefPtr)
        {
            EV_DynStPtr[EV_EntityGuiStPtr[restrictObjectEn].admin].dynDefPtr = nullptr;
        }

        EV_EntityGuiStPtr[restrictObjectEn].editDynDefTabPtr = nullptr;
        EV_EntityGuiStPtr[restrictObjectEn].adminDynDefTabPtr = nullptr;

        if (EV_EntityGuiStPtr[restrictObjectEn].edit == EV_EntityGuiStPtr[restrictObjectEn].admin)
        {
            auto dictEntityStp = DBA_GetDictEntitySt(restrictObjectEn);
            if (dictEntityStp->shortDictCriteriaMap.empty() == false)
            {
                EV_EntityGuiStPtr[restrictObjectEn].admin = ++LASTDYNST;
                EV_DynStPtr = (DBA_DYNST_STP)AaaMetaDict::getMemoryPool().realloc(EV_DynStPtr, (LASTDYNST + 1) * sizeof(DBA_DYNST_ST));

                auto newDynStPtr = &EV_DynStPtr[EV_EntityGuiStPtr[restrictObjectEn].admin];

                memset(newDynStPtr, 0, sizeof(DBA_DYNST_ST));
                newDynStPtr->init(restrictObjectEn);

                newDynStPtr->dynTypeEnum = DynType_Short;
            }
        }
    }

    for (DBA_DYNST_ENUM dynStEnum = 0; dynStEnum <= LASTDYNST; dynStEnum++)
    {
        OBJECT_ENUM objectEn = EV_DynStPtr[dynStEnum].entity;

        if (restrictObjectEn != NullEntity)
        {
            if (restrictObjectEn != objectEn || 
                EV_DynStPtr[dynStEnum].dynTypeEnum == DynType_Other ||
                EV_DynStPtr[dynStEnum].newVerDynStEn != NullDynSt)
            {
                continue;
            }
            AaaMetaDict::getMemoryPool().freePtr(EV_DynStPtr[dynStEnum].dynDefPtr);
        }

        FIELD_IDX_T nbrAttrMDC      = 0;
        FIELD_IDX_T nbrAttrMDNotC   = 0;
        FIELD_IDX_T nbrAttrCSqlName = 0;
        FIELD_IDX_T nbrAttrCOnly    = 0;
        FIELD_IDX_T nbrAttrLogC     = 0;

        EV_DynStPtr[dynStEnum].init(objectEn);

        DICT_ENTITY_STP dictEntityStp = nullptr;
        if (objectEn != NullEntity)
        {
            dictEntityStp = DBA_GetDictEntitySt(objectEn);

            if (dictEntityStp != nullptr &&
                dictEntityStp->isMetaDict() == false &&
                (restrictObjectEn == NullEntity || dictEntityStp->entNatEn != EntityNat_Internal))  /* PMSTA-48744 - LJE - 220414 */
            {
                dictEntityStp = nullptr;
            }
        }

        /* Search current dynSt */
        DBA_DYNDEF_STP dynDefPtr = EV_DynStPtr[dynStEnum].dynDefPtr;

        if (dynDefPtr == nullptr && dictEntityStp != nullptr)
        {
            DBA_DYNDEF_DEF_ST genDynDefSt;
            SYS_Bzero(&genDynDefSt, sizeof(DBA_DYNDEF_DEF_ST));

            auto dynTypeEnum = EV_DynStPtr[dynStEnum].dynTypeEnum;

            if (dynTypeEnum == DynType_All)
            {
                if (EV_EntityGuiStPtr[objectEn].allDynDefStp)
                {
                    genDynDefSt = *EV_EntityGuiStPtr[objectEn].allDynDefStp;
                }
                else
                {
                    genDynDefSt.dynTypeEnum = DynType_All;
                    genDynDefSt.objPosPtr = &EV_DynStPtr[dynStEnum].entity;
                    genDynDefSt.dynStPosPtr = &dynStEnum;
                }

                EV_EntityGuiStPtr[objectEn].editDynDefTabPtr = DBA_InitDynDefTabPtr(dictEntityStp, &genDynDefSt);
                EV_DynStPtr[dynStEnum].dynDefPtr = EV_EntityGuiStPtr[objectEn].editDynDefTabPtr;

                if (EV_EntityGuiStPtr[objectEn].admin == EV_EntityGuiStPtr[objectEn].edit)
                {
                    EV_EntityGuiStPtr[objectEn].adminDynDefTabPtr = EV_EntityGuiStPtr[objectEn].editDynDefTabPtr;
                }
            }
            else if (dynTypeEnum == DynType_Short)
            {
                if (EV_EntityGuiStPtr[objectEn].shortDynDefStp)
                {
                    genDynDefSt = *EV_EntityGuiStPtr[objectEn].shortDynDefStp;
                }
                else
                {
                    genDynDefSt.dynTypeEnum = DynType_Short;
                    genDynDefSt.objPosPtr = &EV_DynStPtr[dynStEnum].entity;
                    genDynDefSt.dynStPosPtr = &dynStEnum;
                }
                EV_EntityGuiStPtr[objectEn].adminDynDefTabPtr = DBA_InitDynDefTabPtr(dictEntityStp, &genDynDefSt);
                EV_DynStPtr[dynStEnum].dynDefPtr = EV_EntityGuiStPtr[objectEn].adminDynDefTabPtr;
            }
            dynDefPtr = EV_DynStPtr[dynStEnum].dynDefPtr;
        }

        if (dynDefPtr == NULL || dynDefPtr->dynStPos == NullDynSt)
        {
            if (dictEntityStp != NULL)
            {
                SYS_StringFormat(msg, "Meta-dictionary entity %s error in dynamic structure!!!", dictEntityStp->mdSqlName);
            }
            else
            {
                SYS_StringFormat(msg, "Meta-dictionary error in dynamic structure (%d)!!!", dynStEnum);
            }

            stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg);
            continue;
        }

        DBA_DYNTYPE_ENUM dynTypeEnum = dynDefPtr->dynTypeEnum;
        EV_DynStPtr[dynStEnum].dynTypeEnum = dynTypeEnum;

        /* PMSTA-36919 - LJE - 191004 - Reset treat flag on DdlGen case */
        if (objectEn != NullEntity)
        {
            for (int i = 0; dynDefPtr->cFieldTab[i].fieldPosPtr != NULL; i++)
            {
                dynDefPtr->cFieldTab[i].treatedFlg = FALSE;
            }
        }

        /* 1) Search number of MD field present in C description */
        /* 2) Search number of MD field not present in C description */
        /* 3) Search number of C field with sql name <> "" */
        /* 3) Search number of C field with sql name = "" */

        /* Search number of field */
        if (dictEntityStp != NULL)
        {
            if (dynTypeEnum == DynType_All)
            {
                for (auto& dictAttribStp : dictEntityStp->attr)
                {
                    if (dictAttribStp->attrDictId > 0)
                    {
                        if (dictAttribStp->custFlg == FALSE &&
                            dictAttribStp->precompFlg == FALSE &&
                            dictAttribStp->logicalFlg == FALSE &&       /* PMSTA-42814 - LJE - 210922 */
                            DBA_GetNewIndexAttrib(dynDefPtr, dictAttribStp->sqlName) != nullptr)
                        {
                            nbrAttrMDC++;
                        }
                        else
                        {
                            if (dictAttribStp->custFlg == TRUE)
                            {
                                EV_DynStPtr[dynStEnum].custFldNbr++;
                            }
                            else if (dictAttribStp->precompFlg == TRUE)
                            {
                                EV_DynStPtr[dynStEnum].precompFldNbr++;
                            }
                            else if (dictAttribStp->logicalFlg == TRUE)
                            {
                                EV_DynStPtr[dynStEnum].logicalFldNbr++;

                                if (DBA_GetNewIndexAttrib(dynDefPtr, dictAttribStp->sqlName) != nullptr)
                                {
                                    nbrAttrLogC++;
                                }
                            }
                            nbrAttrMDNotC++;
                        }
                    }
                }

                if (dictEntityStp->custAuthFlg || dictEntityStp->custNbr > 0)
                {
                    EV_DynStPtr[dynStEnum].custEntityObj = objectEn;

                    if (EV_DynStPtr[dynStEnum].custFldNbr != dictEntityStp->custNbr)
                    {
                        SYS_BreakOnDebug();
                    }
                }
                if (dictEntityStp->usePrecompFlg || dictEntityStp->precompNbr > 0)
                {
                    EV_DynStPtr[dynStEnum].precompEntityObj = objectEn;

                    if (EV_DynStPtr[dynStEnum].precompFldNbr != dictEntityStp->precompNbr)
                    {
                        SYS_BreakOnDebug();
                    }
                }
            }
            else if (dynTypeEnum == DynType_Short)
            {
                for (auto criterIt = dictEntityStp->shortDictCriteriaMap.begin(); criterIt != dictEntityStp->shortDictCriteriaMap.end(); ++criterIt)
                {
                    DICT_CRITER_STP dictCriterStp = criterIt->second;

                    if (dictCriterStp->index >= 0)
                    {
                        if (DBA_GetNewIndexAttrib(dynDefPtr, dictCriterStp->sqlName) != nullptr)
                        {
                            nbrAttrMDC++;
                        }
                        else
                        {
                            nbrAttrMDNotC++;
                        }
                    }
                }
            }

        }

        nbrAttrCOnly = DBA_GetNbrCFieldDynSt(dynStEnum) - nbrAttrLogC;

        nbrAttrCSqlName = 0;
        if (dynDefPtr->dynStPos != NullDynSt)
        {
            if (dynDefPtr->cFieldTab != nullptr)
            {
                map<FIELD_IDX_T*, string> fieldTabCheckMap;

                for (int i = 0; dynDefPtr->cFieldTab[i].fieldPosPtr != NULL; i++)
                {
                    if (AAACHECKDYNFLD && EV_AAAInstallLevel < 6)
                    {
                        auto it = fieldTabCheckMap.find(dynDefPtr->cFieldTab[i].fieldPosPtr);
                        if (it == fieldTabCheckMap.end())
                        {
                            fieldTabCheckMap.insert(make_pair(dynDefPtr->cFieldTab[i].fieldPosPtr, dynDefPtr->cFieldTab[i].sqlName));
                        }
                        else
                        {
                            SYS_StringFormat(msg,
                                             "Duplicate uses of field pointer for structure %s, fields %s and %s",
                                             dynDefPtr->dynStName,
                                             dynDefPtr->cFieldTab[i].sqlName,
                                             it->second.c_str());

                            stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg);
                        }
                    }
                    nbrAttrCSqlName++;
                }
            }
        }

        nbrAttrCSqlName = (short)(nbrAttrCSqlName - nbrAttrMDC - nbrAttrCOnly - nbrAttrLogC);

        if (AAACHECKDYNFLD)
        {
            if (nbrAttrCSqlName != 0 && EV_AAAInstallLevel == 0 && SYS_IsSqlMode() == FALSE)
            {
                SYS_StringFormat(msg,
                        "Dynamic structure %s has %d %s defined in C but not in meta-dict definition",
                        dynDefPtr->dynStName,
                        nbrAttrCSqlName,
                        (nbrAttrCSqlName > 1) ? "attributes" : "attribute");

                stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg);

                /* PMSTA08736 - LJE - 100120 - print failed attribute(s) */
                if (dynDefPtr->dynStPos != NullDynSt)
                {
                    if (dynDefPtr->cFieldTab != nullptr)
                    {
                        for (int i = 0; dynDefPtr->cFieldTab[i].fieldPosPtr != NULL; i++)
                        {
                            if (dynDefPtr->cFieldTab[i].metaDictFlg == TRUE &&
                                dynDefPtr->cFieldTab[i].treatedFlg == FALSE)
                            {
                                SYS_StringFormat(msg,
                                                 "Attribute %s.%s is defined in C but not in meta-dict definition",
                                                 dynDefPtr->dynStName,
                                                 dynDefPtr->cFieldTab[i].sqlName);

                                stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg);
                            }

                            if (dynDefPtr->cFieldTab[i].metaDictFlg == FALSE &&
                                dynDefPtr->cFieldTab[i].dbFlg == TRUE)
                            {
                                SYS_StringFormat(msg,
                                                 "Attribute %s.%s is return by the procedures but not in meta-dict definition",
                                                 dynDefPtr->dynStName,
                                                 dynDefPtr->cFieldTab[i].sqlName);

                                stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg);
                            }
                        }
                    }
                }
            }
        }

        /* REF9303 - LJE - 030903 : Prepare generation of new fields for ASCII when VarString exists */
        EV_DynStPtr[dynStEnum].techFldNbr = 0;

        if (ICU4AAA_SQLServerUTF8 != 0 &&
            dynDefPtr->dynStPos != NullDynSt)
        {
            if (dynDefPtr->cFieldTab != nullptr)
            {
                for (FIELD_IDX_T fieldPos = 0; dynDefPtr->cFieldTab[fieldPos].fieldPosPtr != NULL; fieldPos++)
                {
                    if (GET_CTYPE(dynDefPtr->cFieldTab[fieldPos].dataTypeEnum) == VarCharPtrCType ||
                        GET_CTYPE(dynDefPtr->cFieldTab[fieldPos].dataTypeEnum) == VarTextPtrCType ||

                        GET_CTYPE(dynDefPtr->cFieldTab[fieldPos].dataTypeEnum) == UniCharPtrCType ||
                        GET_CTYPE(dynDefPtr->cFieldTab[fieldPos].dataTypeEnum) == UniTextPtrCType)
                    {
                        EV_DynStPtr[dynStEnum].techFldNbr++;
                    }
                }
            }
        }

        /* PMSTA-Memory - LJE - 181203 */
        if (dynDefPtr->dynStPos != NullDynSt)
        {
            if (dynDefPtr->cFieldTab != nullptr)
            {
                for (FIELD_IDX_T fieldPos = 0; dynDefPtr->cFieldTab[fieldPos].fieldPosPtr != NULL; fieldPos++)
                {
                    dynDefPtr->cFieldTab[fieldPos].dataTypeEnum = DBA_ConvUniDataTypeToDataType(dynDefPtr->cFieldTab[fieldPos].dataTypeEnum);

                    if (dynDefPtr->cFieldTab[fieldPos].dataTypeEnum == ArrayType ||
                        dynDefPtr->cFieldTab[fieldPos].dataTypeEnum == MultiArrayType ||
                        dynDefPtr->cFieldTab[fieldPos].dataTypeEnum == ExtensionType)
                    {
                        EV_DynStPtr[dynStEnum].techFldNbr++;
                    }
                }
            }
        }
        EV_DynStPtr[dynStEnum].techFldNbr += EV_DynStPtr[dynStEnum].logicalFldNbr;

        EV_DynStPtr[dynStEnum].fldNbr = (short)(nbrAttrMDC + nbrAttrMDNotC + nbrAttrCOnly + nbrAttrCSqlName + EV_DynStPtr[dynStEnum].techFldNbr);

        /* PMSTA-37366 - LJE - 191209 */
        if (EV_DynStPtr[dynStEnum].fldNbr > 0)
        {
            EV_DynStPtr[dynStEnum].internalFldIdx = 0;
            EV_DynStPtr[dynStEnum].fldNbr++;
            EV_DynStPtr[dynStEnum].techFldNbr++;
        }

        EV_DynStPtr[dynStEnum].noMDFldNbr = (short)(nbrAttrCSqlName + nbrAttrCOnly + EV_DynStPtr[dynStEnum].techFldNbr);
        EV_DynStPtr[dynStEnum].nbEntry = 0;
        EV_DynStPtr[dynStEnum].fixFldNbr = (short)(EV_DynStPtr[dynStEnum].fldNbr -
                                                   EV_DynStPtr[dynStEnum].custFldNbr -
                                                   EV_DynStPtr[dynStEnum].precompFldNbr -
                                                   EV_DynStPtr[dynStEnum].logicalFldNbr -       /* PMSTA-42814 - LJE - 210922 */
                                                   EV_DynStPtr[dynStEnum].techFldNbr);

        /* PMSTA-42814 - LJE - 210922 */
        EV_DynStPtr[dynStEnum].firstTechFldPos = EV_DynStPtr[dynStEnum].fldNbr;
        if (EV_DynStPtr[dynStEnum].techFldNbr > 0)
        {
            EV_DynStPtr[dynStEnum].firstTechFldPos -= EV_DynStPtr[dynStEnum].techFldNbr;
        }

        /* REF8844 - LJE - 031001 */
        if (EV_DynStPtr[dynStEnum].fldNbr == 0)
        {
            if (AAACHECKDYNFLD)
            {
                if (dictEntityStp != NULL &&
                    EV_AAAInstallLevel == 0 &&
                    SYS_IsSqlMode() == FALSE &&
                    dictEntityStp->logicalFlg == FALSE &&
                    dictEntityStp->entNatEn != EntityNat_ReportFmt &&
                    dictEntityStp->entNatEn != EntityNat_TempTable &&
                    dynStEnum != InvalidDynSt)
                {
                    SYS_StringFormat(msg,
                                     "Entity (only meta-dict) %s must have at least a short attribute !",
                                     dictEntityStp->mdSqlName);

                    stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg);
                }
            }
            continue;
        }

        AaaMetaDict::getMemoryPool().freePtr(EV_DynStPtr[dynStEnum].dynStDefPtr); /* PMSTA-26108 - LJE - 170913 */
        EV_DynStPtr[dynStEnum].dynStDefPtr = (DBA_DYNSTDEF_STP)AaaMetaDict::getMemoryPool().calloc(FILEINFO, EV_DynStPtr[dynStEnum].fldNbr, sizeof(DBA_DYNSTDEF_ST));

        for (FIELD_IDX_T attrIdx = 0; attrIdx < EV_DynStPtr[dynStEnum].fldNbr; attrIdx++)
        {
            EV_DynStPtr[dynStEnum].dynStDefPtr[attrIdx].dataType       = NullDataType;
            EV_DynStPtr[dynStEnum].dynStDefPtr[attrIdx].asciiField     = attrIdx;
            EV_DynStPtr[dynStEnum].dynStDefPtr[attrIdx].infoField      = Null_Dynfld; /* PMSTA-Memory - LJE - 181203 */
            EV_DynStPtr[dynStEnum].dynStDefPtr[attrIdx].anonymizeItem  = 0;
            EV_DynStPtr[dynStEnum].dynStDefPtr[attrIdx].anonymizeSubst = nullptr;
            EV_DynStPtr[dynStEnum].dynStDefPtr[attrIdx].defLinkDynStEn = NullDynSt;    /* PMSTA-34344 - LJE - 200923 */
            EV_DynStPtr[dynStEnum].dynStDefPtr[attrIdx].cFieldDefStp   = nullptr;
            EV_DynStPtr[dynStEnum].dynStDefPtr[attrIdx].dictAttribStp  = nullptr;   /* PMSTA-29879 - LJE - 180710 */
        }

        /* Put data type and dbFlg */
        if (dictEntityStp != nullptr)
        {
            if (dynTypeEnum == DynType_All)
            {
                /* Reset metaDictFlg and dbFlg */
                if (dynDefPtr->dynStPos != NullDynSt)
                {
                    if (dynDefPtr->cFieldTab != nullptr)
                    {
                        for (FIELD_IDX_T fieldPos = 0; dynDefPtr->cFieldTab[fieldPos].fieldPosPtr != NULL; fieldPos++)
                        {
                            dynDefPtr->cFieldTab[fieldPos].metaDictFlg = FALSE;
                            dynDefPtr->cFieldTab[fieldPos].dbFlg       = FALSE;
                        }
                    }
                }

                bool bFixAttrib = true;
                FIELD_IDX_T attrIdx = 0;
                for (auto attribIt = dictEntityStp->attr.begin(); attribIt != dictEntityStp->attr.end(); ++attribIt, ++attrIdx)
                {
                    DICT_ATTRIB_STP dictAttribStp = (*attribIt);

                    if (dictAttribStp->subFeatureEn == SubFeature::Tech)
                    {
                        dictAttribStp->progN = attrIdx;
                        continue;
                    }

                    if (bFixAttrib &&
                        (dictAttribStp->custFlg == TRUE || dictAttribStp->precompFlg == TRUE || dictAttribStp->logicalFlg == TRUE))
                    {
                        bFixAttrib = false;
                        attrIdx += EV_DynStPtr[dynStEnum].noMDFldNbr - EV_DynStPtr[dynStEnum].techFldNbr;
                    }

                    dictAttribStp->progN = attrIdx;

                    EV_DynStPtr[dynStEnum].nbEntry++;

                    strcpy(EV_DynStPtr[dynStEnum].dynStDefPtr[attrIdx].sqlName, dictAttribStp->sqlName);
                    EV_DynStPtr[dynStEnum].dynStDefPtr[attrIdx].dataType      = dictAttribStp->dataTpProgN;
                    EV_DynStPtr[dynStEnum].dynStDefPtr[attrIdx].mdFlg         = TRUE;
                    EV_DynStPtr[dynStEnum].dynStDefPtr[attrIdx].dictAttribStp = dictAttribStp;

                    if (dictAttribStp->calcEn == DictAttr_Virtual ||
                        dictAttribStp->calcEn == DictAttr_NoMD)
                    {
                        EV_DynStPtr[dynStEnum].dynStDefPtr[attrIdx].dbFlg = FALSE;
                    }
                    else if (dictAttribStp->logicalFlg == TRUE)         /* PMSTA-42814 - LJE - 210922 */
                    {
                        EV_DynStPtr[dynStEnum].dynStDefPtr[attrIdx].dataType = ExtensionType;
                        EV_DynStPtr[dynStEnum].dynStDefPtr[attrIdx].dbFlg    = FALSE;
                    }
                    else
                    {
                        EV_DynStPtr[dynStEnum].dynStDefPtr[attrIdx].dbFlg = TRUE;

                        if (dictAttribStp->custFlg == TRUE)
                        {
                            EV_DynStPtr[dynStEnum].dynStDefPtr[attrIdx].bCustom = true;
                        }
                        else if (dictAttribStp->precompFlg == TRUE)
                        {
                            EV_DynStPtr[dynStEnum].dynStDefPtr[attrIdx].bPrecomp = true;
                        }
                        else
                        {
                            EV_DynStPtr[dynStEnum].dynStDefPtr[attrIdx].bMain = true;
                        }
                    }
                    EV_DynStPtr[dynStEnum].dynStDefPtr[attrIdx].subFeatureEn = SubFeature::None;    /* PMSTA-46259 - LJE - 211007 */

                    DBA_CFIELDDEF_STP cFieldStp = DBA_GetNewIndexAttrib(dynDefPtr, dictAttribStp->sqlName);
                    if (cFieldStp != nullptr)
                    {
                        if (dictAttribStp->logicalFlg == FALSE)
                        {
                            cFieldStp->metaDictFlg = TRUE;
                            cFieldStp->dbFlg = EV_DynStPtr[dynStEnum].dynStDefPtr[attrIdx].dbFlg; /* REF8844 - LJE - 030611 */
                        }

                        *(cFieldStp->fieldPosPtr) = attrIdx;
                        EV_DynStPtr[dynStEnum].dynStDefPtr[attrIdx].cFieldDefStp = cFieldStp;

                        if (dictAttribStp->dataTpProgN != cFieldStp->dataTypeEnum &&
                            EV_AAAInstallLevel == 0)
                        {
                            SYSNAME_T mdDatatype;
                            SYSNAME_T cDatatype;

                            DBA_GetDataTypeEnumToStr(mdDatatype, dictAttribStp->dataTpProgN);
                            DBA_GetDataTypeEnumToStr(cDatatype, cFieldStp->dataTypeEnum);

                            SYS_StringFormat(msg,
                                             "Data-type mismatch for attribute %s.%s (MD: %s, C definition: %s)",
                                             dynDefPtr->dynStName,
                                             dictAttribStp->sqlName,
                                             mdDatatype,
                                             cDatatype);

                            stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg);
                        }
                    }
                }

            }
            else if (dynTypeEnum == DynType_Short)
            {
                FIELD_IDX_T attrIdx = 0;
                for (auto criterIt = dictEntityStp->shortDictCriteriaMap.begin(); criterIt != dictEntityStp->shortDictCriteriaMap.end(); ++criterIt)
                {
                    DICT_CRITER_STP dictCriterStp = criterIt->second;

                    if (dictCriterStp->index >= 0)
                    {
                        dictCriterStp->shortProgN = attrIdx;

                        EV_DynStPtr[dynStEnum].nbEntry++;

                        if (attrIdx < EV_DynStPtr[dynStEnum].fldNbr)
                        {
                            strcpy(EV_DynStPtr[dynStEnum].dynStDefPtr[attrIdx].sqlName, dictCriterStp->sqlName);
                            EV_DynStPtr[dynStEnum].dynStDefPtr[attrIdx].mdFlg = TRUE;

                            EV_DynStPtr[dynStEnum].dynStDefPtr[attrIdx].subFeatureEn = SubFeature::None;    /* PMSTA-46259 - LJE - 211007 */

                            DBA_CFIELDDEF_STP cFieldStp;
                            if ((cFieldStp = DBA_GetNewIndexAttrib(dynDefPtr, dictCriterStp->sqlName)) != nullptr)
                            {
                                if (dictCriterStp->attrPtr)
                                {
                                    EV_DynStPtr[dynStEnum].dynStDefPtr[attrIdx].dataType = dictCriterStp->attrPtr->dataTpProgN;
                                }
                                else
                                {
                                    EV_DynStPtr[dynStEnum].dynStDefPtr[attrIdx].dataType = cFieldStp->dataTypeEnum;
                                }
                                cFieldStp->metaDictFlg = TRUE;

                                /* db flag get in C definition */
                                EV_DynStPtr[dynStEnum].dynStDefPtr[attrIdx].dbFlg = cFieldStp->dbFlg;
                                EV_DynStPtr[dynStEnum].dynStDefPtr[attrIdx].mdFlg = cFieldStp->metaDictFlg;

                                *(cFieldStp->fieldPosPtr) = attrIdx;
                                EV_DynStPtr[dynStEnum].dynStDefPtr[attrIdx].cFieldDefStp = cFieldStp;
                            }
                            else if (dictCriterStp->attrPtr)
                            {
                                EV_DynStPtr[dynStEnum].dynStDefPtr[attrIdx].dataType = dictCriterStp->attrPtr->dataTpProgN;

                                if (dictCriterStp->attrPtr->calcEn == DictAttr_Virtual ||
                                    dictCriterStp->attrPtr->calcEn == DictAttr_NoMD)
                                {
                                    EV_DynStPtr[dynStEnum].dynStDefPtr[attrIdx].dbFlg = FALSE;
                                }
                                else
                                {
                                    EV_DynStPtr[dynStEnum].dynStDefPtr[attrIdx].dbFlg = TRUE;
                                }
                            }

                            /* PMSTA-29879 - LJE - 180710 */
                            EV_DynStPtr[dynStEnum].dynStDefPtr[attrIdx].dictAttribStp = dictCriterStp->entAttrPtr;

                        }
                        else if (EV_AAAInstallLevel == 0 && SYS_IsSqlMode() == FALSE) /* REF9789 - LJE - 040105 */
                        {
                            SYS_StringFormat(msg,
                                             "Bad short index in entity %s and attribute %s !",
                                             dictEntityStp->mdSqlName,
                                             dictCriterStp->sqlName);

                            stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg);
                        }

                        ++attrIdx;
                    }
                }

                /* REF8844 - LJE - 030611 : Modify meta dict flag for fields add in C and not in MD */
                if (nbrAttrCSqlName > 0)
                {
                    for (FIELD_IDX_T fieldPos = 0; dynDefPtr->cFieldTab[fieldPos].fieldPosPtr != NULL; fieldPos++)
                    {
                        DICT_ATTRIB_STP attribStp = nullptr;

                        /* PMSTA-17216 - LJE - 131210 */
                        if (dynDefPtr->cFieldTab[fieldPos].dataTypeEnum == NullDataType)
                            break;

                        if (dynDefPtr->cFieldTab[fieldPos].metaDictFlg == TRUE &&
                            EV_DynStPtr[dynStEnum].fldNbr != EV_DynStPtr[dynStEnum].noMDFldNbr && /* PMSTA-26108 - LJE - 171109 */
                            dynDefPtr->cFieldTab[fieldPos].sqlName[0] != 0 &&
                            dynDefPtr->cFieldTab[fieldPos].sqlName[0] != '_' &&  /* REF9743 - LJE - 040205 */
                            ((attribStp = DBA_GetAttributeBySqlName(objectEn, dynDefPtr->cFieldTab[fieldPos].sqlName, TRUE)) == NULL ||
                             attribStp->isNullShortIdx == true))
                        {
                            dynDefPtr->cFieldTab[fieldPos].metaDictFlg = FALSE;

                            if (attribStp == nullptr)
                            {
                                dynDefPtr->cFieldTab[fieldPos].dbFlg = FALSE;
                            }
                        }

                    }
                }

                /* REF9303 - LJE - 030912 */
                if (dictEntityStp->synonFlg == TRUE)
                {
                    EV_DynStPtr[dynStEnum].codifIdIdx = (short)(EV_DynStPtr[dynStEnum].fldNbr - 1);
                }
            }
        }
        else
        {
            if (dynDefPtr->cFieldTab != nullptr)
            {
                for (FIELD_IDX_T fieldPos = 0; dynDefPtr->cFieldTab[fieldPos].fieldPosPtr != NULL; fieldPos++)
                {
                    dynDefPtr->cFieldTab[fieldPos].metaDictFlg = FALSE;
                }
            }
        }
    }

    /* Init No MD fields */
    /* For each DYNST */
    for (DBA_DYNST_ENUM dynStEnum = 0; dynStEnum <= LASTDYNST; dynStEnum++)
    {
        OBJECT_ENUM objectEn = EV_DynStPtr[dynStEnum].entity;
        if (restrictObjectEn != NullEntity)
        {
            if (restrictObjectEn != objectEn || 
                EV_DynStPtr[dynStEnum].dynTypeEnum == DynType_Other ||
                EV_DynStPtr[dynStEnum].newVerDynStEn != NullDynSt)
            {
                continue;
            }
        }

        auto dynDefPtr   = EV_DynStPtr[dynStEnum].dynDefPtr;
        auto dynStDefPtr = EV_DynStPtr[dynStEnum].dynStDefPtr;

        if (dynDefPtr == nullptr || dynDefPtr->dynStPos == NullDynSt)
        {
            continue;
        }

        FIELD_IDX_T cFieldPos = EV_DynStPtr[dynStEnum].nbEntry -
            EV_DynStPtr[dynStEnum].custFldNbr -
            EV_DynStPtr[dynStEnum].precompFldNbr -
            EV_DynStPtr[dynStEnum].logicalFldNbr;

        if (EV_DynStPtr[dynStEnum].nbEntry != EV_DynStPtr[dynStEnum].fldNbr)
        {
            for (FIELD_IDX_T fieldPos = 0; dynDefPtr->cFieldTab[fieldPos].fieldPosPtr != NULL; fieldPos++)
            {
                if (dynDefPtr->cFieldTab[fieldPos].treatedFlg == FALSE)
                {
                    /* PMSTA-36919 - LJE - 191004 */
                    if (dynDefPtr->cFieldTab[fieldPos].metaDictFlg == TRUE)
                    {
                        if (EV_AAAInstallLevel == 0 && SYS_IsSqlMode() == FALSE)
                        {
                            SYS_StringFormat(msg,
                                    "Wrong meta-dict definition in C description for attribute %s.%s",
                                    dynDefPtr->dynStName,
                                    dynDefPtr->cFieldTab[fieldPos].sqlName);

                            stdMsg.printMsg(RET_GEN_ERR_PERSONAL, msg);
                        }
                        dynDefPtr->cFieldTab[fieldPos].metaDictFlg = FALSE;
                    }


                    if (cFieldPos < EV_DynStPtr[dynStEnum].fldNbr)
                    {
                        strcpy(EV_DynStPtr[dynStEnum].dynStDefPtr[cFieldPos].sqlName, dynDefPtr->cFieldTab[fieldPos].sqlName);
                        EV_DynStPtr[dynStEnum].dynStDefPtr[cFieldPos].dataType = dynDefPtr->cFieldTab[fieldPos].dataTypeEnum;

                        EV_DynStPtr[dynStEnum].dynStDefPtr[cFieldPos].dbFlg = dynDefPtr->cFieldTab[fieldPos].dbFlg;
                        EV_DynStPtr[dynStEnum].dynStDefPtr[cFieldPos].mdFlg = dynDefPtr->cFieldTab[fieldPos].metaDictFlg;
                        EV_DynStPtr[dynStEnum].dynStDefPtr[cFieldPos].subFeatureEn = SubFeature::None;    /* PMSTA-46259 - LJE - 211007 */

                        /* REF8844 - LJE - 030512 */
                        if (dynDefPtr->dynTypeEnum == DynType_All &&
                            dynDefPtr->cFieldTab[fieldPos].dbFlg == TRUE &&
                            EV_DynStPtr[dynStEnum].fldNbr != EV_DynStPtr[dynStEnum].noMDFldNbr && /* PMSTA-26108 - LJE - 171109 */
                            dynDefPtr->cFieldTab[fieldPos].sqlName[0] != 0 &&
                            dynDefPtr->cFieldTab[fieldPos].sqlName[0] != '_') /* REF9743 - LJE - 040205 */
                        {
                            EV_DynStPtr[dynStEnum].dynStDefPtr[cFieldPos].dbFlg = FALSE;
                        }

                        dynDefPtr->cFieldTab[fieldPos].treatedFlg = TRUE;

                        EV_DynStPtr[dynStEnum].dynStDefPtr[cFieldPos].cFieldDefStp = &(dynDefPtr->cFieldTab[fieldPos]);
                        *(dynDefPtr->cFieldTab[fieldPos].fieldPosPtr) = cFieldPos;

                        EV_DynStPtr[dynStEnum].nbEntry++;
                        cFieldPos++;
                    }
                    else if (EV_AAAInstallLevel == 0)
                    {
                        assert(FALSE);
                    }
                }

                if (EV_DynStPtr[dynStEnum].nbEntry == EV_DynStPtr[dynStEnum].fldNbr)
                {
                    break;
                }
            }

            if (EV_DynStPtr[dynStEnum].codifIdIdx != Null_Dynfld)
            {
                if (EV_DynStPtr[dynStEnum].fldNbr != EV_DynStPtr[dynStEnum].nbEntry)
                {
                    DBA_DYNSTDEF_STP codifDynStDefStp = &(EV_DynStPtr[dynStEnum].dynStDefPtr[EV_DynStPtr[dynStEnum].codifIdIdx]);
                    (*codifDynStDefStp) = EV_DynStPtr[dynStEnum].dynStDefPtr[EV_DynStPtr[dynStEnum].nbEntry - 1];
                    codifDynStDefStp->asciiField = EV_DynStPtr[dynStEnum].codifIdIdx;
                    if (codifDynStDefStp->cFieldDefStp)
                    {
                        (*codifDynStDefStp->cFieldDefStp->fieldPosPtr) = EV_DynStPtr[dynStEnum].codifIdIdx;
                    }

                    memset(&(EV_DynStPtr[dynStEnum].dynStDefPtr[EV_DynStPtr[dynStEnum].nbEntry - 1]), 0, sizeof(DBA_DYNSTDEF_ST));
                    EV_DynStPtr[dynStEnum].firstTechFldPos--;
                }
            }
        }

        /* REF9303 - LJE - 030903 : Generate new fields for ASCII when VarString exists */
        if (EV_DynStPtr[dynStEnum].fldNbr > EV_DynStPtr[dynStEnum].firstTechFldPos)
        {
            FIELD_IDX_T techFieldPos = EV_DynStPtr[dynStEnum].firstTechFldPos;

            for (FIELD_IDX_T attrIdx = 0; attrIdx <= EV_DynStPtr[dynStEnum].firstTechFldPos; attrIdx++)
            {
                if (dynStDefPtr[attrIdx].dictAttribStp != nullptr &&
                    (dynStDefPtr[attrIdx].dictAttribStp->custFlg == TRUE ||
                     dynStDefPtr[attrIdx].dictAttribStp->precompFlg == TRUE))
                {
                    continue;
                }

                if (GET_CTYPE(dynStDefPtr[attrIdx].dataType) == VarCharPtrCType ||
                    GET_CTYPE(dynStDefPtr[attrIdx].dataType) == VarTextPtrCType ||

                    GET_CTYPE(dynStDefPtr[attrIdx].dataType) == UniCharPtrCType ||
                    GET_CTYPE(dynStDefPtr[attrIdx].dataType) == UniTextPtrCType)
                {
                    if (ICU4AAA_SQLServerUTF8)
                    {
                        EV_DynStPtr[dynStEnum].dynStDefPtr[attrIdx].asciiField = (short)(techFieldPos);

                        switch (dynStDefPtr[attrIdx].dataType)
                        {
                            case UniCodeType:
                                EV_DynStPtr[dynStEnum].dynStDefPtr[techFieldPos].dataType = CodeType;
                                break;
                            case UniPhoneType:
                                EV_DynStPtr[dynStEnum].dynStDefPtr[techFieldPos].dataType = PhoneType;
                                break;
                            case UniShortinfoType:
                                EV_DynStPtr[dynStEnum].dynStDefPtr[techFieldPos].dataType = ShortinfoType;
                                break;
                            case UniSysnameType:
                                EV_DynStPtr[dynStEnum].dynStDefPtr[techFieldPos].dataType = SysnameType;
                                break;
                            case VarInfoType:
                            case UniInfoType:
                                EV_DynStPtr[dynStEnum].dynStDefPtr[techFieldPos].dataType = InfoType;
                                break;
                            case VarNoteType:
                            case UniNoteType:
                                EV_DynStPtr[dynStEnum].dynStDefPtr[techFieldPos].dataType = NoteType;
                                break;
                            case VarNameType:
                            case UniNameType:
                                EV_DynStPtr[dynStEnum].dynStDefPtr[techFieldPos].dataType = NameType;
                                break;
                            case VarTextType:
                            case UniTextType:
                                EV_DynStPtr[dynStEnum].dynStDefPtr[techFieldPos].dataType = TextType;
                                break;
                            case VarLongnameType:
                            case UniLongnameType:
                                EV_DynStPtr[dynStEnum].dynStDefPtr[techFieldPos].dataType = LongnameType;
                                break;
                            case VarString1000Type:
                            case UniString1000Type:
                                EV_DynStPtr[dynStEnum].dynStDefPtr[techFieldPos].dataType = String1000Type;
                                break;
                            case VarString2000Type:
                            case UniString2000Type:
                                EV_DynStPtr[dynStEnum].dynStDefPtr[techFieldPos].dataType = String2000Type;
                                break;
                            case VarString3000Type:
                            case UniString3000Type:
                                EV_DynStPtr[dynStEnum].dynStDefPtr[techFieldPos].dataType = String3000Type;
                                break;
                            case VarString4000Type:
                            case UniString4000Type:
                                EV_DynStPtr[dynStEnum].dynStDefPtr[techFieldPos].dataType = String4000Type;
                                break;
                            case VarString7000Type:
                            case UniString7000Type:
                                EV_DynStPtr[dynStEnum].dynStDefPtr[techFieldPos].dataType = String7000Type;
                                break;
                            case VarString15000Type:
                            case UniString15000Type:
                                EV_DynStPtr[dynStEnum].dynStDefPtr[techFieldPos].dataType = String15000Type;
                                break;
                            default:
                                SYS_BreakOnDebug();
                                EV_DynStPtr[dynStEnum].dynStDefPtr[techFieldPos].dataType = NullDataType;
                                break;
                        }

                        sprintf(EV_DynStPtr[dynStEnum].dynStDefPtr[techFieldPos].sqlName, "ascii_%04d", attrIdx);

                        EV_DynStPtr[dynStEnum].dynStDefPtr[techFieldPos].subFeatureEn = SubFeature::TechInternal;    /* PMSTA-46259 - LJE - 211007 */
                        EV_DynStPtr[dynStEnum].nbEntry++;
                        techFieldPos++;
                    }

                    if (EV_DynStPtr[dynStEnum].dynStDefPtr[attrIdx].dataType != NullDataType)
                    {
                        if (dynStDefPtr[attrIdx].cFieldDefStp != nullptr)
                        {
                            dynStDefPtr[attrIdx].cFieldDefStp->dataTypeEnum = dynStDefPtr[attrIdx].dataType;
                        }
                    }
                    else
                    {
                        SYS_BreakOnDebug();
                    }

                }
                else if (dynStDefPtr[attrIdx].dataType == ArrayType ||
                         dynStDefPtr[attrIdx].dataType == MultiArrayType ||
                         dynStDefPtr[attrIdx].dataType == ExtensionType)
                {
                    sprintf(EV_DynStPtr[dynStEnum].dynStDefPtr[techFieldPos].sqlName, "info_%04d", attrIdx);

                    EV_DynStPtr[dynStEnum].dynStDefPtr[techFieldPos].dataType = ChainedTypeType;
                    EV_DynStPtr[dynStEnum].dynStDefPtr[techFieldPos].subFeatureEn = SubFeature::TechInternal;    /* PMSTA-46259 - LJE - 211007 */

                    EV_DynStPtr[dynStEnum].dynStDefPtr[attrIdx].infoField = (short)(techFieldPos);

                    EV_DynStPtr[dynStEnum].nbEntry++;
                    techFieldPos++;
                }
            }

            /* PMSTA-37366 - LJE - 191210 */
            if (EV_DynStPtr[dynStEnum].internalFldIdx != Null_Dynfld)
            {
                sprintf(EV_DynStPtr[dynStEnum].dynStDefPtr[techFieldPos].sqlName, "_internal_fld");

                EV_DynStPtr[dynStEnum].dynStDefPtr[techFieldPos].dataType = IntType;
                EV_DynStPtr[dynStEnum].dynStDefPtr[techFieldPos].subFeatureEn = SubFeature::TechInternal;    /* PMSTA-46259 - LJE - 211007 */
                EV_DynStPtr[dynStEnum].internalFldIdx = techFieldPos;
                EV_DynStPtr[dynStEnum].nbEntry++;
                techFieldPos++;
            }
        }

        /* PMSTA-36919 - LJE - 191128 */
        for (FIELD_IDX_T attrIdx = 0; attrIdx < EV_DynStPtr[dynStEnum].fldNbr; attrIdx++)
        {
            DICT_ATTRIB_STP dictAttribStp = EV_DynStPtr[dynStEnum].dynStDefPtr[attrIdx].dictAttribStp;
            if (dictAttribStp != nullptr)
            {
                if (dictAttribStp->subFeatureEn != SubFeature::None &&
                    EV_DynStPtr[dynStEnum].dynStDefPtr[attrIdx].subFeatureEn == SubFeature::None)
                {
                    EV_DynStPtr[dynStEnum].dynStDefPtr[attrIdx].subFeatureEn = dictAttribStp->subFeatureEn;
                }

                if (dictAttribStp->featureEn == XdEntityFeatureFeatureEn::AccessRightManagement)
                {
                    if (dictAttribStp->subFeatureEn == SubFeature::UpdateRight)
                    {
                        EV_DynStPtr[dynStEnum].authUpdFlgIdx = attrIdx;
                    }
                    else if (dictAttribStp->subFeatureEn == SubFeature::DeleteRight)
                    {
                        EV_DynStPtr[dynStEnum].authDelFlgIdx = attrIdx;
                    }
                    else if (dictAttribStp->subFeatureEn == SubFeature::RightReason)
                    {
                        EV_DynStPtr[dynStEnum].authReasonIdx = attrIdx;
                    }
                    else if (dictAttribStp->subFeatureEn == SubFeature::UpdateSecuRight)
                    {
                        EV_DynStPtr[dynStEnum].authUpdSecuIdx = attrIdx;
                    }
                    else if (dictAttribStp->subFeatureEn == SubFeature::DeleteSecuRight)
                    {
                        EV_DynStPtr[dynStEnum].authDelSecuIdx = attrIdx;
                    }
                }
                else if (dictAttribStp->featureEn == XdEntityFeatureFeatureEn::MultiBusinessEntityManagement)
                {
                    if (dictAttribStp->subFeatureEn == SubFeature::MeRecordLocation)
                    {
                        EV_DynStPtr[dynStEnum].meRecLocFldIdx = attrIdx;
                    }
                }
            }
        }

        if (EV_AAAInstallLevel == 0)
        {
            assert(EV_DynStPtr[dynStEnum].nbEntry == EV_DynStPtr[dynStEnum].fldNbr);
        }

        /* PMSTA-46681 - LJE - 220825 */
        if (EV_DynStPtr[dynStEnum].logicalFldNbr > 0)
        {
            EV_DynStPtr[dynStEnum].foreignKeyFldIdx = EV_DynStPtr[dynStEnum].firstTechFldPos - 1;
            sprintf(EV_DynStPtr[dynStEnum].dynStDefPtr[EV_DynStPtr[dynStEnum].foreignKeyFldIdx].sqlName, "_foreign_keys");
        }
    }

    if (restrictObjectEn == NullEntity)
    {
        EV_DynStPtr[S_Op].entity = Op;

        /* PMSTA-34344 - LJE - 200923 */
        EV_DynStPtr[SqlRequest].dynStDefPtr[SqlRequest_Parameters].defLinkDynStEn              = SqlRequestParam;
        EV_DynStPtr[SqlRequest].dynStDefPtr[SqlRequest_ResultSet].defLinkDynStEn               = SqlRequestResultSet;
        EV_DynStPtr[SqlRequestResultSet].dynStDefPtr[SqlRequestResultSet_Items].defLinkDynStEn = SqlRequestOutputDef;
    }

    return (RET_SUCCEED);
}


/************************************************************************
**
**  Function    :   DBA_UpdateDynStMaxLength()
**
**  Description :   Compute maximum length for each dynamic structures
**                  Two length are computed (with text fields and without text fields).
**
**  Arguments   :
**
**  Return      :   RET_SUCCEED or error code
**
**  Creation    :   DDV - PMSTA07121 - 090306
**
*************************************************************************/
EXTERN RET_CODE DBA_UpdateDynStMaxLength()
{
    DBA_DYNDEF_STP   dynDefPtr;
    short            dynStEnum;
    int              length, textLength, i, fldNbr;
    int              dataType = 0;
    FIELD_IDX_T      hierFldIdx, changeSetOldExtIdx, changeSetNewExtIdx;
    SYSNAME_T        *sqlName = NULL, *hierIdxSqlName = NULL, *oldRecExtSqlName = NULL, *newRecExtSqlName = NULL;

    if (EV_AAAInstallLevel == 0)
    {
        hierIdxSqlName = GET_FLD_SQLNAME(A_DictAttributeTemplate, A_DictAttributeTemplate_HierIdxFld);
        oldRecExtSqlName = GET_FLD_SQLNAME(A_DictAttributeTemplate, A_DictAttributeTemplate_ChangeSetOldRec_Ext);
        newRecExtSqlName = GET_FLD_SQLNAME(A_DictAttributeTemplate, A_DictAttributeTemplate_ChangeSetNewRec_Ext);
    }

    for (dynStEnum = 0; dynStEnum <= LASTDYNST; dynStEnum++)
    {
        dynDefPtr = EV_DynStPtr[dynStEnum].dynDefPtr;

        fldNbr = GET_FLD_NBR(dynStEnum);

        length = 0;
        textLength = 0;
        hierFldIdx = changeSetOldExtIdx = changeSetNewExtIdx = Null_Dynfld;
        for (i = 0; i < fldNbr; i++)
        {
            if (EV_AAAInstallLevel == 0)
            {
                if ((sqlName = GET_FLD_SQLNAME(dynStEnum, i)) != NULL &&
                    (*sqlName)[0] != END_OF_STRING)
                {
                    if (hierIdxSqlName != NULL &&
                        *hierIdxSqlName != NULL &&
                        strcmp(*sqlName, *hierIdxSqlName) == 0)
                    {
                        hierFldIdx = i;
                    }
                    else if (oldRecExtSqlName != NULL &&
                             *oldRecExtSqlName != NULL &&
                             strcmp(*sqlName, *oldRecExtSqlName) == 0)
                    {
                        changeSetOldExtIdx = i;
                    }
                    else if (newRecExtSqlName != NULL &&
                             *newRecExtSqlName != NULL &&
                             strcmp(*sqlName, *newRecExtSqlName) == 0)
                    {
                        changeSetNewExtIdx = i;
                    }
                }
            }

            if (GET_FLD_TYPE(dynStEnum, i) != TextType &&
                GET_FLD_TYPE(dynStEnum, i) != VarTextType &&
                GET_FLD_TYPE(dynStEnum, i) != UniTextType)
            {
                DICT_ATTRIB_STP attribute = DBA_GetDictAttribSt(GET_OBJ_DYNST(dynStEnum), i);

                OBJECT_ENUM object;

                DBA_GetObjectEnumByDynSt(dynStEnum, &object);

                if (attribute == NULL || object == Synon || attribute->maxDbLenN == 0)
                {
                    length += GET_MAXLEN(GET_FLD_TYPE(dynStEnum, i));
                }
                else
                {
                    length += attribute->maxDbLenN;
                }
            }
            else
                textLength += GET_MAXLEN(GET_FLD_TYPE(dynStEnum, i));
        }

        EV_DynStPtr[dynStEnum].maxLenWithoutTextFld     = length;
        EV_DynStPtr[dynStEnum].maxLenWithTextFld        = length + textLength;
        EV_DynStPtr[dynStEnum].hierEltIdxFldIdx         = hierFldIdx;
        EV_DynStPtr[dynStEnum].changeSetOldRecExtFldIdx = changeSetOldExtIdx;
        EV_DynStPtr[dynStEnum].changeSetNewRecExtFldIdx = changeSetNewExtIdx;

        if (EV_MaxDynStLenWithTextFld < (length + textLength))
            EV_MaxDynStLenWithTextFld = length + textLength;

        if (EV_MaxDynStLenWithoutTextFld < length)
            EV_MaxDynStLenWithoutTextFld = length;

        if (dynDefPtr != NULL &&
            dynDefPtr->objPos != NullEntity)
        {
            if (EV_MaxMDDynStLenWithTextFld < (length + textLength))
                EV_MaxMDDynStLenWithTextFld = length + textLength;

            if (EV_MaxMDDynStLenWithoutTextFld < length)
                EV_MaxMDDynStLenWithoutTextFld = length;
        }

    }

    /* Update the maximum Field length */
    for (dataType = 0; dataType < LastType; dataType++)
    {
        if (EV_MaxFieldLen < GET_MAXLEN((DATATYPE_ENUM)dataType))
            EV_MaxFieldLen = GET_MAXLEN((DATATYPE_ENUM)dataType);

        if (dataType != TextType && dataType != UniTextType && dataType != VarTextType)
            if (EV_MaxFieldLenWithoutText < GET_MAXLEN((DATATYPE_ENUM)dataType))
                EV_MaxFieldLenWithoutText = GET_MAXLEN((DATATYPE_ENUM)dataType);

    }

    return (RET_SUCCEED);
}

/************************************************************************
**
**  Function    : DBA_AllocateVirtualObject
**
**  Description : Allocate virtual object spaces in memory, only before
**                start server
**
**  Arguments   :
**
**  Return      : The new object
**
**                REF11818 - LJE - 060524
**
**  Last modif. : PMSTA-15031 - 210912 - PMO : Order Entry : order grouping on one order results in an application fatal error
**
*************************************************************************/
STATIC RET_CODE DBA_AllocateVirtualObject(int nbrNewAlloc)
{
    DBA_DYNST_ENUM  newDynSt;

    if (LASTOBJECT >= SV_EntityGuiStTabSize)
    {
        SV_EntityGuiStTabSize = LASTOBJECT + 1;
    }

    /* Alloc the new object */
    SV_EntityGuiStTabSize = (OBJECT_ENUM)(SV_EntityGuiStTabSize + nbrNewAlloc);
    LASTOBJECT = (OBJECT_ENUM)(LASTOBJECT + nbrNewAlloc);
    EV_EntityGuiStPtr = (DBA_GUIDYNST_STP)AaaMetaDict::getMemoryPool().realloc(EV_EntityGuiStPtr, (size_t)(SV_EntityGuiStTabSize * sizeof(DBA_GUIDYNST_ST)));

    (void)AaaMetaDict::reallocObjProcLstPtr((size_t)(SV_EntityGuiStTabSize));
    EV_EntityGuiStNb = SV_EntityGuiStTabSize;                   /* PMSTA-15031 - 210912 - PMO */

    for (OBJECT_ENUM i = SV_EntityGuiStTabSize - 1; i > SV_EntityGuiStTabSize - nbrNewAlloc - 1; i--)
    {
        /* Init EV_EntityGuiStPtr */
        EV_EntityGuiStPtr[i].edit              = ++LASTDYNST;
        EV_EntityGuiStPtr[i].admin             = ++LASTDYNST;
        EV_EntityGuiStPtr[i].objectCst         = NullEntityCst;
        EV_EntityGuiStPtr[i].objDefTabPtr      = nullptr;
        EV_EntityGuiStPtr[i].editDynDefTabPtr  = nullptr;
        EV_EntityGuiStPtr[i].adminDynDefTabPtr = nullptr;
        EV_EntityGuiStPtr[i].allDynDefStp      = nullptr;
        EV_EntityGuiStPtr[i].shortDynDefStp    = nullptr;
        EV_EntityGuiStPtr[i].objAllocateFlg    = FALSE;

        EV_DynStPtr = (DBA_DYNST_STP)AaaMetaDict::getMemoryPool().realloc(EV_DynStPtr, (LASTDYNST + 1) * sizeof(DBA_DYNST_ST));

        newDynSt                               = EV_EntityGuiStPtr[i].edit;
        memset(&EV_DynStPtr[newDynSt], 0, sizeof(DBA_DYNST_ST));
        EV_DynStPtr[newDynSt].init(i);
        EV_DynStPtr[newDynSt].dynTypeEnum      = DynType_All; /* REF9743 - LJE - 040202 */

        newDynSt                               = EV_EntityGuiStPtr[i].admin;
        memset(&EV_DynStPtr[newDynSt], 0, sizeof(DBA_DYNST_ST));
        EV_DynStPtr[newDynSt].init(i);
        EV_DynStPtr[newDynSt].dynTypeEnum      = DynType_Short; /* REF9743 - LJE - 040202 */
    }

    EV_EntityGuiStNb = SV_EntityGuiStTabSize;                   /* PMSTA-15031 - 210912 - PMO */

    return RET_SUCCEED;
}


/************************************************************************
**
**  Function    : DBA_CreateVirtualObject
**
**  Description : Create virtual object with dynamique structures and
**                meta-dictionary entry.
**
**  Arguments   :
**
**  Return      : The new object
**
**                REF9789 - LJE - 031230
**
*************************************************************************/
RET_CODE DBA_CreateVirtualObject(OBJECT_ENUM *newObjectPtr)
{
    if (DBA_LockIfServer(DbaServLock_CreateVirtualEntity, FILEINFO) == FALSE)
    {
        MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "ServLock_CreateVirtualEntity FAILED");
        return (RET_GEN_ERR_INVARG);
    }

    /* Create new object enum */
    if ((*newObjectPtr) == NullEntity)
    {
        /* Search the first empty position */
        for ((*newObjectPtr) = LASTLOGENTITYOBJECT + 1; (*newObjectPtr) <= LASTOBJECT; (*newObjectPtr)++)
        {
            if (EV_EntityGuiStPtr[(*newObjectPtr)].objAllocateFlg == FALSE)
            {
                break;
            }
        }
    }
    else
    {
        if ((*newObjectPtr) < 0 ||
            (*newObjectPtr) > LASTOBJECT + 1 ||
            ((*newObjectPtr) <= LASTOBJECT &&
             EV_EntityGuiStPtr[(*newObjectPtr)].objAllocateFlg == FALSE))
        {
            DBA_UnlockIfServer(DbaServLock_CreateVirtualEntity, FILEINFO); /* REF9954 - TEB - 040224 */
            MSG_RETURN(RET_GEN_ERR_INVARG);
        }
    }

    if ((*newObjectPtr) > LASTOBJECT)
    {
        if (DBA_AllocateVirtualObject(1) != RET_SUCCEED)
        {
            DBA_UnlockIfServer(DbaServLock_CreateVirtualEntity, FILEINFO);
            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "DBA_CreateVirtualObject FAILED, increase system parameter AAAVIRTUALENTITYBYTHREAD");
            return (RET_GEN_ERR_INVARG);
        }
    }

    EV_EntityGuiStPtr[(*newObjectPtr)].objAllocateFlg = TRUE;

    DBA_UnlockIfServer(DbaServLock_CreateVirtualEntity, FILEINFO);

    return RET_SUCCEED;
}

/************************************************************************
**
**  Function    : DBA_FreeVirtualObject
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**                 REF9789 - LJE - 031230
**
*************************************************************************/
void DBA_FreeVirtualObject(OBJECT_ENUM objectEn)
{
    DBA_DYNST_ENUM dynSt;

    if (objectEn <  0 ||
        objectEn >  LASTOBJECT ||
        EV_EntityGuiStPtr[objectEn].objAllocateFlg == FALSE)
    {
        return;
    }

    if (DBA_LockIfServer(DbaServLock_CreateVirtualEntity, FILEINFO) == FALSE)
    {
        MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, "ServLock_CreateVirtualEntity FAILED");
        return;   /* REF10304 - 040707 - PMO */
    }

    if (EV_DynStPtr[EV_EntityGuiStPtr[objectEn].edit].allocCpt != 0 ||
        EV_DynStPtr[EV_EntityGuiStPtr[objectEn].admin].allocCpt != 0)
    {
        MSG_SendMesg(RET_GEN_ERR_PERSONAL, 6, FILEINFO,
                     "All the structures were not free for virtual object :",
                     DBA_GetDictEntitySqlName(objectEn));
    }

    EV_EntityGuiStPtr[objectEn].objAllocateFlg = FALSE;

    dynSt = EV_EntityGuiStPtr[objectEn].edit;
    if (dynSt != NullDynSt)
    {
        EV_DynStPtr[dynSt].fldNbr          = 0;
        EV_DynStPtr[dynSt].noMDFldNbr      = 0;
        EV_DynStPtr[dynSt].custFldNbr      = 0;
        EV_DynStPtr[dynSt].precompFldNbr   = 0; /* PMSTA-11505 - LJE - 110615 */
        EV_DynStPtr[dynSt].logicalFldNbr   = 0; /* PMSTA-42814 - LJE - 210922 */
        EV_DynStPtr[dynSt].techFldNbr      = 0; /* PMSTA-15655 - LJE - 130130 */
        EV_DynStPtr[dynSt].fixFldNbr       = 0; /* PMSTA-15655 - LJE - 130130 */
        EV_DynStPtr[dynSt].firstTechFldPos = 0; /* PMSTA-42814 - LJE - 210922 */
        EV_DynStPtr[dynSt].dictEntityStp   = nullptr;
        AaaMetaDict::getMemoryPool().freePtr(EV_DynStPtr[dynSt].dynStDefPtr);
        EV_DynStPtr[dynSt].nbEntry         = 0;
        EV_DynStPtr[dynSt].dynDefPtr       = NULL;
        EV_DynStPtr[dynSt].codifIdIdx      = Null_Dynfld;
        EV_DynStPtr[dynSt].allocCpt        = 0;
        EV_DynStPtr[dynSt].dynTypeEnum     = DynType_All; /* REF9743 - LJE - 040202 */
    }

    dynSt = EV_EntityGuiStPtr[objectEn].admin;
    if (dynSt != NullDynSt)
    {
        EV_DynStPtr[dynSt].fldNbr          = 0;
        EV_DynStPtr[dynSt].noMDFldNbr      = 0;
        EV_DynStPtr[dynSt].custFldNbr      = 0;
        EV_DynStPtr[dynSt].precompFldNbr   = 0; /* PMSTA-11505 - LJE - 110615 */
        EV_DynStPtr[dynSt].logicalFldNbr   = 0; /* PMSTA-42814 - LJE - 210922 */
        EV_DynStPtr[dynSt].techFldNbr      = 0; /* PMSTA-15655 - LJE - 130130 */
        EV_DynStPtr[dynSt].fixFldNbr       = 0; /* PMSTA-15655 - LJE - 130130 */
        EV_DynStPtr[dynSt].firstTechFldPos = 0; /* PMSTA-42814 - LJE - 210922 */
        EV_DynStPtr[dynSt].dictEntityStp   = nullptr;
        AaaMetaDict::getMemoryPool().freePtr(EV_DynStPtr[dynSt].dynStDefPtr);
        EV_DynStPtr[dynSt].nbEntry         = 0;
        EV_DynStPtr[dynSt].dynDefPtr       = NULL;
        EV_DynStPtr[dynSt].codifIdIdx      = Null_Dynfld;
        EV_DynStPtr[dynSt].allocCpt        = 0;
        EV_DynStPtr[dynSt].dynTypeEnum     = DynType_Short;
    }

    DBA_UnlockIfServer(DbaServLock_CreateVirtualEntity, FILEINFO);

    return;
}

/************************************************************************
**
**  Function    : DBA_AddFieldToVirtualObject
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**                 REF9789 - LJE - 031230
**
*************************************************************************/
RET_CODE    DBA_AddFieldToVirtualObject(OBJECT_ENUM    objectEn,
                                        FIELD_IDX_T   *progN,
                                        DATATYPE_ENUM  dataType,
                                        FLAG_T         allFlg,
                                        FLAG_T         precompFlg,
                                        const char    *sqlName)
{
    DBA_DYNST_ENUM    dynSt;
    DBA_CFIELDDEF_STP cFieldDef = NULL;
    FIELD_IDX_T       fieldPos;

    /* Test params */
    if (objectEn <  0 ||
        objectEn >  LASTOBJECT ||
        EV_EntityGuiStPtr[objectEn].objAllocateFlg == FALSE)
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    if (allFlg == TRUE)
    {
        dynSt = EV_EntityGuiStPtr[objectEn].edit;
    }
    else
    {
        dynSt = EV_EntityGuiStPtr[objectEn].admin;
    }

    if (EV_DynStPtr[dynSt].allocCpt != 0)
    {
        if (precompFlg == FALSE)
        {
            stringstream msg;
            msg << "Cannot add field in virtual entity : "
                << DBA_GetDictEntitySqlName(objectEn) << "." << sqlName
                << " (" << EV_DynStPtr[dynSt].allocCpt << " dynamic structures allocated)";

            MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, msg.str().c_str());
            return RET_GEN_ERR_PERSONAL;
        }
        else
        {
            *progN = SHRT_MAX - 500;
            return RET_SUCCEED;
        }
    }

    if (sqlName != NULL)
    {
        cFieldDef = DBA_GetCFielBySqlName(GET_EDITGUIST(objectEn), sqlName, NULL);
    }

    if (cFieldDef == NULL ||
        cFieldDef->dataTypeEnum != dataType)
    {
        EV_DynStPtr[dynSt].fldNbr++;
        EV_DynStPtr[dynSt].noMDFldNbr++;
        EV_DynStPtr[dynSt].nbEntry++;
        EV_DynStPtr[dynSt].fixFldNbr++; /* PMSTA-15655 - LJE - 130130 */

        EV_DynStPtr[dynSt].dynStDefPtr = (DBA_DYNSTDEF_STP)AaaMetaDict::getMemoryPool().realloc(EV_DynStPtr[dynSt].dynStDefPtr, EV_DynStPtr[dynSt].fldNbr * sizeof(DBA_DYNSTDEF_ST));

        fieldPos = EV_DynStPtr[dynSt].fldNbr;
        fieldPos--;

        SYS_Bzero(&EV_DynStPtr[dynSt].dynStDefPtr[fieldPos], sizeof(DBA_DYNSTDEF_ST));

        EV_DynStPtr[dynSt].dynStDefPtr[fieldPos].dataType       = dataType;
        EV_DynStPtr[dynSt].dynStDefPtr[fieldPos].dbFlg          = FALSE;
        EV_DynStPtr[dynSt].dynStDefPtr[fieldPos].asciiField     = fieldPos;
        EV_DynStPtr[dynSt].dynStDefPtr[fieldPos].infoField      = Null_Dynfld; /* PMSTA-Memory - LJE - 181203 */
        EV_DynStPtr[dynSt].dynStDefPtr[fieldPos].anonymizeItem  = 0; /* PCC-17009 - LJE - 130318 */
        EV_DynStPtr[dynSt].dynStDefPtr[fieldPos].anonymizeSubst = NULL; /* PCC-17009 - LJE - 130318 */
        EV_DynStPtr[dynSt].dynStDefPtr[fieldPos].subFeatureEn   = SubFeature::None;    /* PMSTA-46259 - LJE - 211007 */
        EV_DynStPtr[dynSt].dynStDefPtr[fieldPos].bMain          = false;
        EV_DynStPtr[dynSt].dynStDefPtr[fieldPos].bCustom        = false;
        EV_DynStPtr[dynSt].dynStDefPtr[fieldPos].bPrecomp       = false;
        EV_DynStPtr[dynSt].dynStDefPtr[fieldPos].bMEPartial     = false;
        EV_DynStPtr[dynSt].dynStDefPtr[fieldPos].defLinkDynStEn = NullDynSt;    /* PMSTA-34344 - LJE - 200923 */
    }
    else
    {
        fieldPos = *(cFieldDef->fieldPosPtr);

        EV_DynStPtr[dynSt].dynStDefPtr[fieldPos].dbFlg = cFieldDef->dbFlg;
    }

    if (progN != NULL)
    {
        (*progN) = (fieldPos);
    }

    return RET_SUCCEED;
}

/************************************************************************
**
**  Function    : DBA_TestVirtualObjects
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**                 REF9789 - LJE - 031230
**
*************************************************************************/
void DBA_TestVirtualObjects()
{
    char        *buff;

    if (EV_AAAInstallLevel == 0)
    {
        if ((buff = (char *)CALLOC(255, sizeof(char))) != NULL)
        {
            for (OBJECT_ENUM i = LASTLOGENTITYOBJECT + 1; i <= LASTOBJECT; i++)
            {
                if (EV_EntityGuiStPtr[i].objAllocateFlg == TRUE)
                {
                    DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(i);

                    if (dictEntityStp != NULL &&
                        dictEntityStp->entNatEn != EntityNat_Technical)
                    {
                        sprintf(buff,
                                "Virtual entity \"%s\" (" szFormatObj ") is still active !!!",
                                dictEntityStp->mdSqlName,
                                i);

                        MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, buff);
                    }
                }

            }

            FREE(buff);
        }
    }

    return;
}


/************************************************************************
**
**  Function    :   DBA_GetDynDefStTab()
**
**  Description :   Search for a dynamic structure
**
**  Argument    :   dynStName   Dynamic structure to search
**
**  Return      :   Return the array if found
**                  NULL if not found
**
**  Last modif. :   PMSTA-7003 - 080808 - PMO : Fusion test like TDDJ
**
*************************************************************************/
DBA_DYNDEF_STP DBA_GetDynDefStTab(const char * dynStName)
{
    string upDynStName = dynStName;

    auto it = AaaMetaDict::getDynStByNameMap().find(upDynStName);
    if (it != AaaMetaDict::getDynStByNameMap().end())
    {
        return EV_DynStPtr[it->second].dynDefPtr;
    }

    return nullptr;
}


/************************************************************************
**
**  Function    :   DBA_GetIdxFieldName()
**
**  Description :   Search for a C field name and return the index
**
**  Argument    :   cFieldTab       C field tab where to search
**                  szFieldName     Name of the C field to search
**                  fldNbr          Used when iClue > 0 to avoid out of bounds access if iClue is too big
**                  iClue           Optimization usefull when the processing order is the same. 0 For no optimization
**
**  Return      :   Return the entry number
**                  -1 if not found
**
**  Last modif. :   PMSTA-7003 - 080808 - PMO : Fusion test like TDDJ
**
*************************************************************************/
FIELD_IDX_T DBA_GetIdxFieldName(const DBA_CFIELDDEF_STP cFieldTab, const char * szFieldName, const FIELD_IDX_T fldNbr, const FIELD_IDX_T iClue)
{
    FIELD_IDX_T iRet = -1;

    for (FIELD_IDX_T idx = iClue < fldNbr ? iClue : 0; NULL != cFieldTab[idx].fieldPosPtr; idx++)
    {
        if (0 == strcmp(szFieldName, cFieldTab[idx].sqlName))
        { /* Found */
            iRet = *(cFieldTab[idx].fieldPosPtr);
            break;
        }
    }

    if (-1 == iRet && iClue > 0)
    { /* Dont search with a clue */
        iRet = DBA_GetIdxFieldName(cFieldTab, szFieldName, fldNbr, 0);
    }

    return iRet;
}

/************************************************************************
**
**  Function    :   DBA_GetFieldIdxBySqlName()
**
**  Description :   Search the index of a field by the sqlName
**
**  Argument    :   dynName       dynamic structure C name
**                  fieldName     Name of the  field to search
**                  objEn         Obj Enum for which the field is searched
**
**  Return      :   Return the entry number
**                  -1 if not found
**
**  Last modif. :   PCC-12748 - 091105 - SRU : test framework
**
*************************************************************************/
FIELD_IDX_T DBA_GetFieldIdxBySqlName(char *dynName, char* fieldName)
{
    DBA_DYNDEF_STP  dynDefStp = NULL;
    FIELD_IDX_T fldIdx = -1;
    DICT_ATTRIB_STP attribStp = NULL;

    dynDefStp = DBA_GetDynDefStTab(dynName);

    if (dynDefStp == NULL)
        return (-1);
    fldIdx = DBA_GetIdxFieldName(dynDefStp->cFieldTab, fieldName, 0, 0);
    if (fldIdx >= 0)
        return fldIdx;

    attribStp = DBA_GetAttributeBySqlName(dynDefStp->objPos, fieldName, TRUE);

    if (attribStp == NULL)
        return (-1);

    return (attribStp->progN);

}

/************************************************************************
*   Function             : DBA_GetCTypeSize()
*
*   Description          : Return the length of a C type
*
*   Arguments            : type   : a CTYPE_ENUM member
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : TRUE
*                          FALSE if problem in sending request
*
*   Last modif.          : REF11780 - 100406 - PMO : Implementation of the Sybase timestamp field
*************************************************************************/
int DBA_GetCTypeSize(CTYPE_ENUM type)
{
    switch (type)
    {
        case DoubleCType:
            return(sizeof(double));

        case CharPtrCType:
        case TextPtrCType:         /* REF4204 */
            return(sizeof(char *));

        case IntCType:
        case UIntCType:
            return(sizeof(int));

        case ShortCType:
        case UShortCType:
            return(sizeof(short));

        case UCharCType:
            return(sizeof(char));

        case DateTimeStCType:
            return(sizeof(DATETIME_ST));

        case UniCharPtrCType:
        case UniTextPtrCType:          /* REF4204 */
            return(sizeof(UChar *));

        case LongLongCType: /* PMSTA08801 - DDV - 091126 */
            return(sizeof(ID_T));

        case TimeStampCType:   /* REF11780 - 100406 - PMO */
            return(sizeof(TIMESTAMP_T));

        case BinaryCType:   /* DLA - PMSTA05995 - 080410 */
            return(sizeof(BINARY_T));

        default:
            break;
    }

    return(0);
}

/************************************************************************
**      END          dbadyn.c
*************************************************************************/

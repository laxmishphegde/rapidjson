/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef DDLGENSPROC_H
#define DDLGENSPROC_H

/************************************************************************
**      Constant & Macro definitions
*************************************************************************/

/************************************************************************
**      Structures & typedef definitions
*************************************************************************/

/************************************************************************
**      External definitions attached to : ddlgensproc.cpp
*************************************************************************/
#ifdef  EXTERN
#undef	EXTERN
#endif
#ifdef  DDLGENSPROC_CPP
#define	EXTERN
#else
#define EXTERN extern
#endif

#include "ddlgen.h"

typedef struct {
    DBA_ACTION_ENUM		  procActionEn;
    DBA_PROC_ACCESS_ENUM  procAccessEn;
    OBJECT_ENUM           inputObjectEn;
    DBA_DYNTYPE_ENUM      inputDynTypeEnTab[5];
    OBJECT_ENUM           outputObjectEn;
    DBA_DYNTYPE_ENUM      outputDynTypeEn;
    int                   role;

    FLAG_T                synonymFlg;
    FLAG_T                translateFlg;
    FLAG_T                applAccess;

    char                  priority;

} DDL_STD_SPROC_DEF_ST, *DDL_STD_SPROC_DEF_STP;

class DdlGenSProc :public DdlGen {

public:

    // Constructors
    DdlGenSProc(OBJECT_ENUM        paramObjectEn,
                DdlGenContext     &paramDdlGenContext,
                DdlGenVarHelper   *paramVarHelperPtr,
                DdlGenEntity      *paramDdlGenEntityPtr,
                DdlGenFile        *paramFileHelper,
                TARGET_TABLE_ENUM  paramTargetTableEn);
    DdlGenSProc(const DdlGenSProc&) = delete;

    // Destructor
    virtual ~DdlGenSProc();

    // Methods
    DdlGenSProc& operator = (const DdlGenSProc&) = delete;
    virtual RET_CODE          build();

    void              init(bool bSetName);
    void              reset();

    DictSprocClass   &getDictSprocSt();

    const std::string &getSprocSqlName();
    RET_CODE          setSprocParam();

    RET_CODE getInsUpdParam(DBA_PROC_ACCESS_ENUM procAccessEn=ProcAccess_None);
    RET_CODE drop();
    RET_CODE grant();

    virtual RET_CODE printHeader();
    virtual RET_CODE printFooter();

    std::list<std::string> extraParamList;

    bool                      m_bFromPscFile;
    bool                      m_bCustomBody;

protected:

    RET_CODE check();
    RET_CODE create();

    RET_CODE setName();

    RET_CODE createGet();
    RET_CODE createSel(bool bOrder = true);
    RET_CODE createIns();
    RET_CODE createInsByCd();
    RET_CODE createUpd();
    RET_CODE createDel();
    RET_CODE createTruncate(); /* PMSTA-14655 - LJE - 121001 */
    RET_CODE createChk();
    RET_CODE createCopy();   /* PMSTA-13109 - LJE - 111202 */
    RET_CODE createSpecial(); /* PMSTA-16729 - LJE - 140205 */

    RET_CODE getInsByCdParam();
    RET_CODE getParam();
    RET_CODE getParam4Cpy(); /* PMSTA-13109 - LJE - 111202 */
    RET_CODE getParamSpecial();

    RET_CODE printCallInsertRequest();
    RET_CODE printTruncateRequest(); /* PMSTA-14655 - LJE - 121001 */
    RET_CODE printCascadeTruncateRef(OBJECT_ENUM  truncObjEn); /* PMSTA-14655 - LJE - 121001 */
    RET_CODE printTruncateFromDeleteRule(DICT_ENTITY_STP truncDictEntityStp, DICT_ENTITY_STP refDictEntityStp, DICT_ATTRIB_STP attribStp); /* PMSTA-14655 - LJE - 121001 */
    RET_CODE printCheckRequest(DdlGenSqlBlock &outSqlBlock);
    RET_CODE printCheckCmd(std::stringstream &outStream, DICT_ENTITY_STP    chkDictEntityStp, bool bForceCurrentBusinessEntity, bool bAddCheck = false);
    RET_CODE printSpecialSProc();

    RET_CODE printWhereClause(FLAG_T codifFlg=FALSE);

    RET_CODE checkSProcParameters(DBA_PROC_STP procStp);
    RET_CODE checkAllSProcParameters();

private:
    DictSprocClass      *m_dictSprocStp;
};

typedef std::unique_ptr<DdlGenSProc> DdlGenSProcPtr;

static DDL_STD_SPROC_DEF_ST SV_DddStdSProcDefTab[] =
{
    {Insert,     ProcAccess_PrimaryKey,  InvalidEntity, {DynType_All, DynType_Unknown},
                                                                                       NullEntity,    DynType_Null,   UNUSED, FALSE, FALSE, TRUE, 20},
    {Update,     ProcAccess_PrimaryKey,  InvalidEntity, {DynType_All, DynType_Unknown},
                                                                                       NullEntity,    DynType_Null,   UNUSED, FALSE, FALSE, TRUE, 20},
    {Update,     ProcAccess_PrimaryKey,  InvalidEntity, {DynType_All, DynType_Unknown},
                                                                                       NullEntity,    DynType_Null,   DBA_ROLE_UPD_UD_FIELDS, FALSE, FALSE, TRUE, 20},
    {Delete,     ProcAccess_PrimaryKey,  InvalidEntity, {DynType_Short, DynType_Unknown},
                                                                                       NullEntity,    DynType_Null,   UNUSED, FALSE, FALSE, TRUE, 20},
    {Get,        ProcAccess_PrimaryKey,  InvalidEntity, {DynType_Short, DynType_Unknown},
                                                                                       InvalidEntity, DynType_All,    UNUSED, FALSE, FALSE, TRUE, 20},
    {Get,        ProcAccess_BusinessKey, InvalidEntity, {DynType_All, DynType_Short, DynType_Unknown},
                                                                                       InvalidEntity, DynType_All,    UNUSED, FALSE, FALSE, TRUE, 30},
    /* OCS-43062 - LJE - 130905 */
    {Get,        ProcAccess_ParentKey,   InvalidEntity, {DynType_Short, DynType_AdmArg, DynType_Unknown},
                                                                                       InvalidEntity, DynType_Short,  UNUSED, FALSE, FALSE, TRUE, 10},
    {Get,        ProcAccess_PrimaryKey,  InvalidEntity, {DynType_Short, DynType_AdmArg, DynType_Unknown},
                                                                                       InvalidEntity, DynType_Short,  UNUSED, FALSE, FALSE, TRUE, 20},
    {Get,        ProcAccess_BusinessKey, InvalidEntity, {DynType_Short, DynType_Unknown},
                                                                                       InvalidEntity, DynType_Short,  UNUSED, FALSE, FALSE, TRUE, 30},
    {Select,     ProcAccess_Full,        NullEntity,    {DynType_Null, DynType_Unknown},
                                                                                       InvalidEntity, DynType_Short,  UNUSED, FALSE, FALSE, TRUE, 20},
    {Select,     ProcAccess_NatureKey,   NullEntity,    {DynType_AdmArg, DynType_Unknown},
                                                                                       InvalidEntity, DynType_Short,  UNUSED, FALSE, FALSE, TRUE, 20},
    {Select,     ProcAccess_ParentKey,   NullEntity,    {DynType_AdmArg, DynType_Unknown},
                                                                                       InvalidEntity,DynType_Short,  UNUSED, FALSE, FALSE, TRUE, 10},
    {Truncate,   ProcAccess_None,        NullEntity,    {DynType_Null, DynType_Unknown},
                                                                                       NullEntity,    DynType_Null,   UNUSED, FALSE, FALSE, TRUE, 20}, /* PMSTA-14655 - LJE - 121001 */ /* PMSTA-16334 - LJE - 130510 - Fix */

    /* Last sproc */
    {NullAction, ProcAccess_None, NullEntity, {DynType_Unknown}, NullEntity, DynType_Null, UNUSED, FALSE, FALSE, FALSE, 0}
};

static DDL_STD_SPROC_DEF_ST SV_DdlChangeSetSProcDefTab[] =
{
    {MultiSelect,ProcAccess_ChangeSet, NullEntity,  {DynType_AdmArg, DynType_Unknown}, NullEntity,    DynType_Null, DBA_ROLE_SEL_SHADOW, FALSE, FALSE, TRUE, 20}, /* PMSTA-26250 - DDV - 170515 */

    /* Last sproc */
    {NullAction, ProcAccess_None, NullEntity, {DynType_Unknown}, NullEntity, DynType_Null, UNUSED, FALSE, FALSE, FALSE, 0}
};

#endif	                               /* ifndef DDLGENSPROC_H */
/************************************************************************
**      END       ddlgensproc.h                               Odyssey
*************************************************************************/

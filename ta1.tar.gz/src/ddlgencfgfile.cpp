/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DDLGENCFGFILE_CPP

/************************************************************************
**      Include files
*************************************************************************/
#include      <string.h>

#include      "unidef.h"     /* Mandatory */
#include      "syslib.h"
#include      "gen.h"
#include      "dba.h"

#include      "ddlgenview.h"
#include      "ddlgencfgfile.h"
#include      "ddlgenfromfile.h"
#include      "str.h"

using namespace std;

/************************************************************************
**      External entry points
**
*************************************************************************/

/************************************************************************
**      Local functions
**
*************************************************************************/

/************************************************************************
**      Static definitions & data
**
*************************************************************************/
static const string CFG_SEPARATOR("###############################################################");

/************************************************************************
**      FONCTIONS
**
************************************************************************/

/************************************************************************
**
**  Function    :   DdlGenLabel::DdlGenLabel()
**
**  Description :   Constructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210830
**
*************************************************************************/
DdlGenLabel::DdlGenLabel(DICT_T              languageDictId,
                         XdLabelNatEn        natureEn,
                         const std::string  &key,
                         const std::string  &label)
    : m_languageDictId(languageDictId)
    , m_natureEn(natureEn)
    , m_key(key)
    , m_label(label)
    , m_uniLabel(nullptr)
    , m_isoLabel(nullptr)
{
    CURRENTCHARSETCODE_ENUM charSet = CurrentCharsetCode_UTF8;
    GEN_GetApplInfo(ApplCurrentCharsetCodeEnum, &charSet);

    if (this->m_label[this->m_label.length() - 1] == '"')
    {
        this->m_label.erase(this->m_label.length() - 1);
    }

    int    labelSize = static_cast<int>(this->m_label.size());
    this->m_uniLabel = static_cast<UChar *>(CALLOC(labelSize + 1, sizeof(UChar)));

    if (ICU4AAA_ConvertFromUTF8Unichar(this->m_label.c_str(), -1, this->m_uniLabel, labelSize, nullptr) == 0)
    {
        if (charSet != CurrentCharsetCode_UTF8)
        {
            this->m_isoLabel = static_cast<char *>(CALLOC(this->m_label.size() + 1, sizeof(char)));

            ICU4AAA_ConvertToDefaultCharSet(this->m_uniLabel, -1, &this->m_isoLabel, nullptr, charSet);
        }
    }
}


/************************************************************************
**
**  Function    :   ~DdlGenLabel::DdlGenLabel()
**
**  Description :   Destructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-45413 - LJE - 210830
**
*************************************************************************/
DdlGenLabel::~DdlGenLabel()
{
    FREE(this->m_uniLabel);
    FREE(this->m_isoLabel);
}

/************************************************************************
**
**  Function    :   DdlGenCfgFile()
**
**  Description :   Constructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-ORACLE - LJE - 140910
**
*************************************************************************/
DdlGenCfgFile::DdlGenCfgFile(DdlGenContext &paramDdlGenContext, CFG_FILE_TYPE_ENUM paramCfgFileTypeEn)
    : DdlGenMsg(&paramDdlGenContext)
    , cfgFileTypeEn(paramCfgFileTypeEn)
    , m_dictEntitStp(nullptr)
    , m_fileLinePos(0)
    , m_bFileLoaded(false)
    , m_bKeepFileInMemory(false)
    , m_currDictLangStp(nullptr)
    , m_cfgFileVersion(0)
{
}

/************************************************************************
**
**  Function    :   ~DdlGenCfgFile()
**
**  Description :   Destructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-ORACLE - LJE - 140910
**
*************************************************************************/
DdlGenCfgFile::~DdlGenCfgFile()
{
    this->freeInitDefPropertiesFile();
    this->freeInstallCfgFile();
    this->freeTemplateFile();
    this->freeLabelsFile();
}

/************************************************************************
**
**  Function    :  DdlGenCfgFile::isLoaded()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-32672 - LJE - 180828
**
*************************************************************************/
bool DdlGenCfgFile::isLoaded()
{
    return this->m_bFileLoaded;
}

/************************************************************************
**
**  Function    :  DdlGenCfgFile::synFiles()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-36556 - LJE - 200918
**
*************************************************************************/
void DdlGenCfgFile::syncFiles(DdlGenCfgFile &sourceCfgFile, bool bRefOnSource)
{
    if (this->cfgFileTypeEn == CfgFileType_InstallCfg && 
        this->m_fileContents.empty()         == false &&
        sourceCfgFile.m_fileContents.empty() == false)
    {
        std::vector<std::string>  searchTab;
        std::set<std::string>     variableToSynSet;

        searchTab.push_back("M");

        if (bRefOnSource == false)
        {
            searchTab.push_back("V");
            searchTab.push_back("O");
            searchTab.push_back("Z");
        }
        else
        {
            variableToSynSet.insert("<MASTER_BUSINESS_ENTITY>");
        }

        for (auto searchIt = searchTab.begin(); searchIt != searchTab.end(); ++searchIt)
        {
            std::vector<std::vector<std::string>> srcContentsVector;
            std::map<std::string, std::string>    dstContentsMap;
            std::vector<std::string>              newFileContents;
            bool                   bFullFile = (bRefOnSource == false);

            if ((*searchIt) == "V")
            {
                bFullFile = false;
            }

            auto lastIt = sourceCfgFile.m_fileContents.begin();

            for (auto srcOptMdIt = sourceCfgFile.m_fileContents.begin(); srcOptMdIt != sourceCfgFile.m_fileContents.end(); ++srcOptMdIt)
            {
                if ((*srcOptMdIt).find((*searchIt)) == 0 ||
                    (bFullFile && lastIt != sourceCfgFile.m_fileContents.begin()))
                {
                    if ((*srcOptMdIt).find("##") == 0)
                    {
                        lastIt = sourceCfgFile.m_fileContents.begin();
                        continue;
                    }

                    if (bFullFile && srcContentsVector.empty())
                    {
                        auto commentIt = srcOptMdIt;
                        while (commentIt != sourceCfgFile.m_fileContents.begin() &&
                            (*commentIt).find("##") != 0)
                        {
                            --commentIt;
                        }

                        while (commentIt != srcOptMdIt)
                        {
                            vector<string>  keyStrVector;

                            keyStrVector.push_back("#");
                            keyStrVector.push_back((*commentIt));

                            srcContentsVector.push_back(keyStrVector);

                            ++commentIt;
                        }
                    }

                    vector<string>  tokensStr;
                    DdlGen::tokenizeStr(tokensStr, (*srcOptMdIt));
 
                    vector<string>  keyStrVector;

                    if (tokensStr.size() > 1)
                    {
                        keyStrVector.push_back(tokensStr[1]);
                    }
                    else
                    {
                        keyStrVector.push_back("#");
                    }

                    keyStrVector.push_back((*srcOptMdIt));
                    srcContentsVector.push_back(keyStrVector);

                    lastIt = srcOptMdIt;
                }
            }

            if (srcContentsVector.empty() == false)
            {
                size_t firstPos   = 0;
                auto   firstPosIt = this->m_fileContents.begin();
                bool   bFirst     = true;

                for (auto dstOptMdIt = this->m_fileContents.begin(); dstOptMdIt != this->m_fileContents.end();)
                {
                    if ((*dstOptMdIt).find((*searchIt)) == 0)
                    {
                        if (bFullFile && bFirst)
                        {
                            firstPosIt = dstOptMdIt;
                            while (firstPosIt != this->m_fileContents.begin() && (*firstPosIt).find("##") != 0)
                            {
                                --firstPosIt;
                                --firstPos;
                            }
                        }

                        vector<string>  tokensStr;
                        DdlGen::tokenizeStr(tokensStr, (*dstOptMdIt));

                        if (tokensStr.size() > 1)
                        {
                            dstContentsMap[tokensStr[1]] = (*dstOptMdIt);
                            dstOptMdIt = this->m_fileContents.erase(dstOptMdIt);
                        }
                        bFirst = false;
                    }
                    else
                    {
                        ++dstOptMdIt;
                    }

                    if (bFirst)
                    {
                        firstPos++;
                    }
                }

                if (bFullFile)
                {
                    do
                    {
                        firstPosIt = this->m_fileContents.erase(firstPosIt);
                    } while ((*firstPosIt).find("##") != 0);
                }

                size_t i = 0;
                for (; i < firstPos; ++i)
                {
                    newFileContents.push_back(this->m_fileContents[i]);
                }

                if (bRefOnSource && (*searchIt) != "V") /* PMSTA-45665 - LJE - 210730 */
                {
                    for (auto it = srcContentsVector.begin(); it != srcContentsVector.end(); ++it)
                    {
                        dstContentsMap.erase((*it)[0]);
                        newFileContents.push_back((*it)[1]);
                    }
                }
                else
                {
                    for (auto it = srcContentsVector.begin(); it != srcContentsVector.end(); ++it)
                    {
                        auto existsIt = dstContentsMap.find((*it)[0]);
                        if (existsIt != dstContentsMap.end())
                        {
                            newFileContents.push_back(existsIt->second);
                            dstContentsMap.erase((*it)[0]);
                        }
                        else
                        {
                            newFileContents.push_back((*it)[1]);
                        }
                    }
                }

                for (auto it = dstContentsMap.begin(); it != dstContentsMap.end(); ++it)
                {
                    newFileContents.push_back(it->second);
                }

                for (; i < this->m_fileContents.size(); ++i)
                {
                    newFileContents.push_back(this->m_fileContents[i]);
                }

                this->m_fileContents = newFileContents;
            }
        }

        if (bRefOnSource == false)
        {
            vector<string>  removeSectionTab;
            removeSectionTab.push_back("TRIPLE_A_STORED_PROCEDURE_SECTION");
            removeSectionTab.push_back("TSL_A_OBJECTS_SECTION");

            for (auto removeIt = removeSectionTab.begin(); removeIt != removeSectionTab.end(); ++removeIt)
            {
                for (auto it = this->m_fileContents.begin(); it != this->m_fileContents.end(); ++it)
                {
                    if ((*it).find((*removeIt)) != string::npos)
                    {
                        while (it != this->m_fileContents.end() && it->find(CFG_SEPARATOR) != 0)
                        {
                            --it;
                        }
                        do
                        {
                            it = this->m_fileContents.erase(it);
                        } while (it != this->m_fileContents.end() && it->find(CFG_SEPARATOR) != 0);
                    }

                    if (it == this->m_fileContents.end())
                    {
                        break;
                    }
                }
            }
        }
        else
        {
            for (auto &srcOptMdIt : sourceCfgFile.m_fileContents)
            {
                if (srcOptMdIt.find(("V")) == 0)
                {
                    vector<string>  tokensStr;
                    DdlGen::tokenizeStr(tokensStr, srcOptMdIt);

                    if (variableToSynSet.empty() ||
                        variableToSynSet.find(tokensStr[1]) != variableToSynSet.end())
                    {
                        for (auto &dstOptMdIt : this->m_fileContents)
                        {
                            if (dstOptMdIt.find((tokensStr[0])) == 0)
                            {
                                vector<string>  dstTokensStr;
                                DdlGen::tokenizeStr(dstTokensStr, dstOptMdIt);

                                if (dstTokensStr[1] == tokensStr[1])
                                {
                                    dstOptMdIt = srcOptMdIt;
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/************************************************************************
**
**  Function    :  DdlGenCfgFile::upgradeFile()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-43367 - LJE - 210427
**
*************************************************************************/
void DdlGenCfgFile::upgradeFile()
{
    if (this->cfgFileTypeEn == CfgFileType_InstallCfg)
    {
        this->m_savedFileContents = this->m_fileContents;

        DdlGenCfgFile rdbmsCfgFile(*this->ddlGenContextPtr, CfgFileType_InstallCfg);
        stringstream  fileName;
        fileName << this->ddlGenContextPtr->getAaaHomePath() << "/install/aaa_install." << DdlGenDbi::getRdbmsShortName(this->ddlGenContextPtr->m_rdbmsEn) << ".cfg";
        rdbmsCfgFile.setFileName(fileName.str());
        rdbmsCfgFile.keepFileInMemory();
        cout << "Loading file :" << fileName.str() << std::endl;
        rdbmsCfgFile.loadCfgFile();

        fileName.clear();
        fileName.str(string());

        DdlGenCfgFile objCfgFile(*this->ddlGenContextPtr, CfgFileType_InstallCfg);
        fileName << this->ddlGenContextPtr->getAaaHomePath() << "/install/aaa_install_obj.cfg";
        objCfgFile.setFileName(fileName.str());
        objCfgFile.keepFileInMemory();
        cout << "Loading file :" << fileName.str() << std::endl;
        objCfgFile.loadCfgFile();

        cout << "Synchronize aaa_install.cfg files... ";
        this->syncFiles(objCfgFile, false);
        this->syncFiles(rdbmsCfgFile, false);
        cout << "Done" << std::endl;

        if (this->m_savedFileContents != this->m_fileContents)
        {
            cout << "Saving new aaa_install.cfg file";
            this->write();
            cout << "Done" << std::endl;
        }
        this->m_savedFileContents.clear();
    }
}

/************************************************************************
**
**  Function    :  DdlGenCfgFile::modifyFile()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-43367 - LJE - 210427
**
*************************************************************************/
void DdlGenCfgFile::modifyFile(const std::string& section, const std::string& key, const std::string& value)
{
    string fullKey;

    if (section == "V")
    {
        fullKey = "<" + key + ">";
    }
    else
    {
        fullKey = key;
    }

    string keyMatch      = "^[\\t\\s]*" + section + "[\\t\\s]*" + fullKey + "[\\t\\s]*";
    string matchPatern   = "(^" + section +"[\\t\\s]*" + fullKey + "[\\t\\s] *).*[\\t\\s]([\\t\\s].*)";
    string replacePatern = "\\1" + value + " \\2";

    auto lastSectionIt = this->m_fileContents.begin();
    bool bSectionFound = false;
    bool bkeyFound     = false;

    for (auto &fileLineIt : this->m_fileContents)
    {
        if (fileLineIt.find(section) == 0)
        {
            bSectionFound = true;

            if (STRING_RegExpMatch(fileLineIt.c_str(), keyMatch.c_str()))
            {
                bkeyFound = true;
                fileLineIt = STRING_RegExpReplace(fileLineIt.c_str(), matchPatern.c_str(), replacePatern.c_str());

                break;
            }
            ++lastSectionIt;
        }
        else if (bSectionFound == false)
        {
            ++lastSectionIt;
        }
    }

    if (bkeyFound == false)
    {
        this->m_fileContents.insert(lastSectionIt, section + " " + fullKey + " " + value);
    }
}

/************************************************************************
**
**  Function    :  DdlGenCfgFile::write()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-36556 - LJE - 200918
**
*************************************************************************/
void DdlGenCfgFile::write()
{
    if (this->m_bKeepFileInMemory &&
        this->m_fileContents.empty() == false &&
        this->m_fileName.empty() == false)
    {
        std::ofstream  cfgFile;

        if (this->m_savedFileContents.empty() == false)
        {
            string     dateStr;
            DATETIME_T dateTime;

            DATE_CurrentDateTime(&dateTime);
            DATETIME_ToSqlStr(dateStr,
                              dateTime,
                              DateStyle_IsoCompact,
                              TimeStyle_24);

            string backupFileName = this->m_fileName + "." + dateStr;

            this->msgFileName = backupFileName;

            cfgFile.open(backupFileName.c_str(), ifstream::out | ifstream::binary);

            if (cfgFile.fail() == false)
            {
                for (auto it = this->m_savedFileContents.begin(); it != this->m_savedFileContents.end(); ++it)
                {
                    cfgFile << (*it) << "\n";
                }
            }

            cfgFile.close();
        }

        this->msgFileName = this->m_fileName;
        cfgFile.open(this->m_fileName.c_str(), ifstream::out | ifstream::trunc | ifstream::binary);

        if (cfgFile.fail() == false)
        {
            for (auto it = this->m_fileContents.begin(); it != this->m_fileContents.end(); ++it)
            {
                cfgFile << (*it) << "\n";
            }
        }

        cfgFile.close();
    }
}

/************************************************************************
**
**  Function    :  DdlGenCfgFile::loadCfgFile()
**
**  Description :  Load and analyze a configuration file.
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-11505 - LJE - 110404
**
*************************************************************************/
RET_CODE DdlGenCfgFile::loadCfgFile()
{
    RET_CODE   ret = RET_SUCCEED;

    if (this->m_bFileLoaded == false)
    {
        this->m_bFileLoaded = true;

        if (this->ddlGenContextPtr != nullptr)
        {
            vector<string>                dirVector;
            map<string, vector<string>>   fileNameMap;

            this->setMsgObjType("Config File");

            switch (this->cfgFileTypeEn)
            {
                case CfgFileType_Properties:
                    dirVector.push_back(this->ddlGenContextPtr->getDdlGenPath() + "/bin");
                    fileNameMap[dirVector.back()].push_back( "init_def.properties");
                    break;

                case CfgFileType_InstallCfg:
                {
                    if (this->m_fileName.empty())
                    {
                        this->m_fileName = SYS_GetEnvStringOrDefValue("AAA_INSTALL_CFG");
                        if (this->m_fileName.empty() == false)
                        {
                            dirVector.push_back("");
                            fileNameMap[dirVector.back()].push_back(this->m_fileName);
                        }
                        else
                        {
                            dirVector.push_back(this->ddlGenContextPtr->getAaaHomePath() + "/install");
                            fileNameMap[dirVector.back()].push_back("aaa_install.cfg");
                        }
                    }
                    else
                    {
                        dirVector.push_back(string());
                        fileNameMap[dirVector.back()].push_back(this->m_fileName);
                    }
                    break;
                }

                case CfgFileType_Template:
                    dirVector.push_back(this->ddlGenContextPtr->getDdlGenPath() + "/src");
                    fileNameMap[dirVector.back()].push_back("ddlgen_template_0000.cfg");
                    break;

                case CfgFileType_Upgrade:
                    dirVector.push_back(this->ddlGenContextPtr->getDdlGenPath() + "/src");
                    fileNameMap[dirVector.back()].push_back("ddlgen_upgrade_0000.cfg");
                    fileNameMap[dirVector.back()].push_back("ddlgen_upgrade_9999.cfg");
                    break;

                case CfgFileType_Label:
                {
                    this->setMsgObjType("Labels File");
                    this->setMsgSqlName(string());
                    this->setMsgEntitySqlName(string());

                    dirVector.push_back(this->ddlGenContextPtr->getDdlGenPath() + "/src");
                    dirVector.push_back(this->ddlGenContextPtr->getAaaHomePath() + "/ddl/md/mb");
                    dirVector.push_back(this->ddlGenContextPtr->getAaaHomePath() + "/ddl/md/custo");

                    for (auto& dirIt : dirVector)
                    {
                        std::vector<SYS_FileInfo> fileList;

                        if (SYS_DIRentryList(dirIt, fileList))
                        {
                            for (auto fileIt = fileList.begin(); fileIt != fileList.end(); ++fileIt)
                            {
                                if (fileIt->isFile &&
                                    fileIt->isReadable &&
                                    fileIt->fileName.find("labels_") == 0 &&
                                    fileIt->fileName.find(".csv") != string::npos)
                                {
                                    fileNameMap[dirIt].push_back(fileIt->fileName);
                                }
                            }
                        }
                    }
                    break;
                }

                case CfgFileType_ControlFile:
                    dirVector.push_back(string());
                    fileNameMap[dirVector.back()].push_back(this->m_fileName);
                    break;
            }

            if (dirVector.empty() == false)
            {
                for (auto &dirIt : dirVector)
                {
                    auto fileNameVector = fileNameMap[dirIt];

                    for (auto fileNameIt = fileNameVector.begin(); fileNameIt != fileNameVector.end(); ++fileNameIt)
                    {
                        if (dirIt.empty())
                        {
                            this->setFileName((*fileNameIt));
                        }
                        else
                        {
                            this->setFileName(dirIt + "/" + (*fileNameIt));
                        }
                        
                        this->msgFileName = this->m_fileName;
                        this->m_cfgFile.open(this->m_fileName.c_str(), ifstream::in);

                        if (this->m_cfgFile.fail() == false)
                        {
                            switch (cfgFileTypeEn)
                            {
                                case CfgFileType_Properties:
                                    this->loadInitDefPropertiesFile();
                                    break;

                                case CfgFileType_InstallCfg:
                                    this->loadInstallCfgFile();
                                    break;

                                case CfgFileType_Template:
                                case CfgFileType_Upgrade:
                                    this->loadTemplateFile();
                                    break;

                                case CfgFileType_Label:
                                {
                                    bool bCusto = false;

                                    if (dirIt.find("custo") != string::npos || 
                                        fileNameIt->find(".usr.") != string::npos)
                                    {
                                        bCusto = true;
                                    }
                                    this->loadLabelsFile(bCusto);
                                    break;
                                }

                                case CfgFileType_ControlFile:
                                    this->loadControlFile();
                                    break;
                            }
                            this->m_cfgFile.close();
                        }
                        else
                        {
                            ret = RET_FILE_ERR_OPEN;

                            if ((this->ddlGenContextPtr->ddlGenAction.m_installLevel != 0) || (this->m_cfgFile.fail() == true))
                            {
                                this->printMsg(ret, "Unable to open the file: " + this->m_fileName);
                            }
                        }
                    }
                }
            }
        }
    }

    return(ret);
}

/************************************************************************
**
**  Function    :  DdlGenCfgFile::checkCfgFile()
**
**  Description :  Check a configuration file.
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-32673 - LJE - 180831
**
*************************************************************************/
RET_CODE DdlGenCfgFile::checkCfgFile()
{
    RET_CODE   ret = RET_SUCCEED;

    this->loadCfgFile();
    switch (cfgFileTypeEn)
    {
        case CfgFileType_Properties:
            break;

        case CfgFileType_InstallCfg:
            ret = this->checkInstallCfgFile();
            break;

        case CfgFileType_Template:
            break;

        case CfgFileType_Upgrade:
            break;

        case CfgFileType_Label:
            break;
    }

    return(ret);
}

/************************************************************************
**
**  Function    :  DdlGenCfgFile::insPropForDbNAme()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :
**
*************************************************************************/
void DdlGenCfgFile::insPropForDbName(GEN_APPLINFO_ENUM dbEnum, const char *dbName, const char* dbAlias)
{
    std::string realDbSqlName;

    if (dbEnum == ApplLast)
    {
        realDbSqlName = SYS_GetEnvStringOrDefValue(dbName, "");
    }
    else
    {
        GEN_GetApplInfo(dbEnum, realDbSqlName);

        if (realDbSqlName.empty())
        {
            realDbSqlName = SYS_GetEnvStringOrDefValue(dbName, "");
        }
    }

    if (realDbSqlName.empty() == false)
    {
        DdlGenDbi::standardize(realDbSqlName, this->ddlGenContextPtr);
        this->m_propertiesMap.insert(pair<string, string>(dbName, realDbSqlName));
        if (dbAlias != nullptr)
        {
            this->m_propertiesMap.insert(pair<string, string>(dbAlias, realDbSqlName));
        }
    }
}

/************************************************************************
**
**  Function    :  DdlGenCfgFile::getVar()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :
**
*************************************************************************/
std::string DdlGenCfgFile::getVar(const std::string &token)
{
    if (token.at(0) == '<' &&
        token.at(token.length() - 1) == '>')
    {
        return token.substr(1, token.length() - 2);
    }
    else
    {
        this->printMsg(RET_DBA_ERR_INVDATA, "Invalid token: '" + token + "', should be surrounded by '<>' ", true, this->m_fileLinePos);
    }
    return string();
}


/************************************************************************
**
**  Function    :  DdlGenCfgFile::getData()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :
**
*************************************************************************/
std::string DdlGenCfgFile::getData(const std::string &token)
{
    if (token.at(0) == '[' &&
        token.at(token.length() - 1) == ']')
    {
        return token.substr(1, token.length() - 2);
    }
    else
    {
        this->printMsg(RET_DBA_ERR_INVDATA, "Invalid token: " + token + ", should be surrounded by '[]' ", true, this->m_fileLinePos);
    }
    return string();
}



/************************************************************************
**
**  Function    :  DdlGenCfgFile::loadInitDefPropertiesFile()
**
**  Description :  Load init_def.properties file
**
**  Arguments   :
**
**  Return      :  TRUE if the properties file can be open,
**                 FALSE elsewhere.
**
** Creation     :  PMSTA-11505 - LJE - 110404
**
*************************************************************************/
RET_CODE DdlGenCfgFile::loadInitDefPropertiesFile()
{
    RET_CODE         ret = RET_SUCCEED;

    string         propertyLine;
    vector<string> tokens;

    while (getline(this->m_cfgFile, propertyLine))
    {
        DdlGen::tokenizeStr(tokens, propertyLine, "=");

        if (tokens.size() == 2)
        {
            DdlGenDbi::treatProperty(tokens[1], this->ddlGenContextPtr->m_rdbmsEn);
            this->m_propertiesMap.insert(pair<string, string>(tokens[0], tokens[1]));
        }
        else
        {
            ret = RET_GEN_ERR_INVARG;
            this->printMsg(ret, "Unknown properties line: \"" + propertyLine + "\", in file: " + this->m_fileName);
        }

        tokens.clear();
    }

    if (SYS_IsSqlMode() == FALSE)
    {
        int i, sizeVar;

        struct VAR_TAB
        {
            string varTag;
            string noUniType;
            string uniType;
        };

        const struct VAR_TAB tabVar[] =
        { { "VAR_INFO_T", "info_t", "uni_info_t" },
        { "VAR_NOTE_T", "note_t", "uni_note_t" },
        { "VAR_NAME_T", "name_t", "uni_name_t" },
        { "VAR_TEXT_T", "text_t", "uni_name_t" },
        { "VAR_LONGNAME_T", "longname_t", "uni_longname_t" },
        { "VAR_VARCHAR_T", "varchar(60)", "univarchar(60)" },
        { "", "", "" } };

        sizeVar = 0;
        while (tabVar[sizeVar].varTag[0] != 0)
        {
            sizeVar++;
        }

        for (i = 0; i < sizeVar; i++)
        {
            string realType, defaultValueStr("1");

            /* PMSTA-20231 - LJE - 150521 */
            if (tabVar[i].uniType[0] == 0 && tabVar[i].noUniType[0] == 0)
            {
                char *envVal = SYS_GetEnv(tabVar[i].varTag.c_str());
                if (envVal != NULL)
                {
                    realType = envVal;
                }
                if (realType.empty())
                {
                    realType = defaultValueStr;
                }
            }
            else if (ICU4AAA_SQLServerUTF8)
            {
                realType = tabVar[i].uniType;
            }
            else
            {
                realType = tabVar[i].noUniType;
            }

            this->m_propertiesMap.insert(pair<string, string>(tabVar[i].varTag, realType));
        }
    }
    /* Add database definition */
    if (this->ddlGenContextPtr->bGenFromDbi)
    {
        this->m_propertiesMap.insert(pair<string, string>("AAALOGINDB", "$AAALOGINDB"));
        this->m_propertiesMap.insert(pair<string, string>("AAALOGIN_DB", "$AAALOGINDB"));
        this->m_propertiesMap.insert(pair<string, string>("AAAMAINDB", "$AAAMAINDB"));
        this->m_propertiesMap.insert(pair<string, string>("AAAMAIN_DB", "$AAAMAINDB"));
        this->m_propertiesMap.insert(pair<string, string>("AAAREPDB", "$AAAREPDB"));
        this->m_propertiesMap.insert(pair<string, string>("AAAREP_DB", "$AAAREPDB"));
        this->m_propertiesMap.insert(pair<string, string>("TSLTEMPDB", "$TSLTEMPDB"));
        this->m_propertiesMap.insert(pair<string, string>("TSLTEMP_DB", "$TSLTEMPDB"));
        this->m_propertiesMap.insert(pair<string, string>("TSLPERMDB", "$TSLPERMDB"));
        this->m_propertiesMap.insert(pair<string, string>("TSLPERM_DB", "$TSLPERMDB"));
    }
    else
    {
        this->insPropForDbName(ApplLast, "AAALOGINDB", "AAALOGIN_DB");
        this->insPropForDbName(ApplSqlDbName, "AAAMAINDB", "AAAMAIN_DB");
        this->insPropForDbName(ApplSqrDbName, "AAAREPDB", "AAAREP_DB");
        this->insPropForDbName(ApplTempTslDbName, "TSLTEMPDB", "TSLTEMP_DB");
        this->insPropForDbName(ApplPermTslDbName, "TSLPERMDB", "TSLPERM_DB");
    }

    /* PMSTA-48357 - LJE - 220510 - Add some properties */
    if (this->ddlGenContextPtr->m_rdbmsEn == MSSql)
    {
        this->m_propertiesMap.insert(pair<string, string>("COLLATION", "Latin1_General_100_BIN2_UTF8"));
    }

    return(ret);
}

/************************************************************************
**
**  Function    :  DdlGenCfgFile::freeInitDefPropertiesFile()
**
**  Description :  Free init_def.properties file
**
**  Arguments   :
**
**  Return      :
**
**  Creation    :  PMSTA-11505 - LJE - 110404
**
*************************************************************************/
RET_CODE DdlGenCfgFile::freeInitDefPropertiesFile()
{
    RET_CODE   ret = RET_SUCCEED;
    return ret;
}

/************************************************************************
**
**  Function    :  DdlGenCfgFile::setProperty()
**
**  Description :  Set properties
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-45413 - LJE - 211207
**
*************************************************************************/
void DdlGenCfgFile::setProperty(const std::string& propName, const std::string& propValue, bool bForce)
{
    if (bForce)
    {
        this->m_propertiesMap[propName] = propValue;
    }
    else
    {
        this->m_propertiesMap.insert(make_pair(propName, propValue));
    }
}

/************************************************************************
**
**  Function    :  DdlGenCfgFile::getProperty()
**
**  Description :  Get properties from init_def.properties file
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-11505 - LJE - 110404
**
*************************************************************************/
string DdlGenCfgFile::getProperty(const string &propName, bool bForceCfgFile)
{
    string propTranslate;

    if (propName.empty())
    {
        return propTranslate;
    }

    if (this->cfgFileTypeEn != CfgFileType_NoFile)
    {
        this->loadCfgFile();
    }

    if (propName[0] == '$')
    {
        if (propName[1] == '{')
        {
            string::size_type endPropPos = propName.find("}");

            return this->getProperty(propName.substr(2, endPropPos - 2));
        }
        else
        {
            return this->getProperty(propName.substr(1));
        }
    }

    map<string, string>::iterator propIter = this->m_propertiesMap.find(propName);

    if (propIter != this->m_propertiesMap.end())
    {
        propTranslate = propIter->second;
    }
    else if (bForceCfgFile == false)
    {
        /* Try to find on environment variables */
        char *envVar = SYS_GetEnv(propName.c_str());

        if (envVar != NULL)
        {
            propTranslate = envVar;
            this->setProperty(propName, propTranslate, true);
        }
        else
        {
            propTranslate = "$" + propName;
        }
    }

    return propTranslate;
}

/************************************************************************
**
**  Function    :  DdlGenCfgFile::getPropertyUnsignedOrDefValue()
**
**  Description :  Get properties from init_def.properties file
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-11505 - LJE - 110404
**
*************************************************************************/
unsigned DdlGenCfgFile::getPropertyUnsignedOrDefValue(const std::string &propName, const unsigned defValue)
{
    string proValue = this->getProperty(propName);

    if (proValue.empty() || proValue[0] == '$')
    {
        return defValue;
    }
    return atoi(proValue.c_str());
}

/************************************************************************
**
**  Function    :  DdlGenCfgFile::getPropertyBoolOrDefValue()
**
**  Description :  Get properties from init_def.properties file
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-34200 - LJE - 190114
**
*************************************************************************/
bool DdlGenCfgFile::getPropertyBoolOrDefValue(const std::string &propName, const bool defValue)
{
    string proValue = this->getProperty(propName);

    if (proValue.empty() || proValue[0] == '$')
    {
        return defValue;
    }

    if (proValue.compare("1") == 0 || strcasecmp(proValue.c_str(), "true") == 0 || strcasecmp(proValue.c_str(), "yes") == 0)
    {
        return true;
    }

    return false;
}

/************************************************************************
**
**  Function    :  DdlGenCfgFile::getCfgObjectSectonStp()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-37366 - LJE - 200417
**
*************************************************************************/
CFG_OBJECT_SECTION *DdlGenCfgFile::getCfgObjectSectonStp(DICT_ENTITY_STP dictEntityStp)
{
    auto objPtr = getCfgObjectSectonStp(dictEntityStp->mdSqlName, dictEntityStp->entNatEn);
    if (objPtr == nullptr &&
        dictEntityStp->linkedEntityStp != nullptr)
    { 
        objPtr = getCfgObjectSectonStp(dictEntityStp->linkedEntityStp->mdSqlName, dictEntityStp->linkedEntityStp->entNatEn);
    }

    return objPtr;
}

/************************************************************************
**
**  Function    :  DdlGenCfgFile::getCfgObjectSectonStp()
**
**  Description :  
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-37366 - LJE - 200417
**
*************************************************************************/
CFG_OBJECT_SECTION *DdlGenCfgFile::getCfgObjectSectonStp(const std::string &sqlName, DBA_ENTITY_NAT_ENUM entNatEn)
{
    auto objIter = this->ddlGenContextPtr->getCfgFileHelper().objSectionMap.find(sqlName);

    if (objIter == this->ddlGenContextPtr->getCfgFileHelper().objSectionMap.end())
    {
        if (entNatEn == EntityNat_ReportFmt)
        {
            objIter = this->ddlGenContextPtr->getCfgFileHelper().objSectionMap.find("report_trace");
        }
        else if (entNatEn == EntityNat_SearchFmt)
        {
            objIter = this->ddlGenContextPtr->getCfgFileHelper().objSectionMap.find("tasc_search_recomp_obj");
        }
        else if (entNatEn != EntityNat_All)
        {
            objIter = this->ddlGenContextPtr->getCfgFileHelper().objSectionMap.find("ud_table");
        }
    }

    if (objIter != this->ddlGenContextPtr->getCfgFileHelper().objSectionMap.end())
    {
        return &objIter->second;
    }

    return nullptr;
}

/************************************************************************
**
**  Function    :  DdlGenCfgFile::loadInstallCfgFile()
**
**  Description :  Load aaa_install.cfg file
**
**  Arguments   :
**
**  Return      :  TRUE if the properties file can be open,
**                 FALSE elsewhere.
**
** Creation     :  PMSTA-11505 - LJE - 110404
**
*************************************************************************/
RET_CODE DdlGenCfgFile::loadInstallCfgFile()
{
    RET_CODE         ret = RET_SUCCEED;

    string           propertyLine;
    int              objectDefPos = 0;

    this->m_fileLinePos = 0;
    while (getline(this->m_cfgFile, propertyLine))
    {
        this->m_fileLinePos++;

        if (this->m_bKeepFileInMemory)
        {
            this->m_fileContents.push_back(propertyLine);
        }

        if (propertyLine.empty())
        {
            continue;
        }

        vector<string> tokens;
        DdlGen::tokenizeStr(tokens, propertyLine);

        if (this->m_cfgFileVersion == 0 &&
            tokens.at(0) == "#" &&
            tokens.size() > 1 &&
            tokens.at(1).find("@(#)aaa_install.cfg") == 0)
        {
            vector<string> versionTokens;
            string         version;

            DdlGen::tokenizeStr(versionTokens, tokens.at(1), ":");

            if (versionTokens.size() > 1)
            {
                version = versionTokens.at(1);
            }
            else
            {
                version = "v1";
            }

            this->m_cfgFileVersion = atoi(version.substr(1).c_str());
            continue;
        }

        if (tokens.size() > 1 &&
            tokens.at(0).find("#") != 0 &&
            tokens.at(0).length() == 1)
        {
            switch (tokens.at(0).at(0))
            {
                case 'V': /* TRIPLE_A_VARIABLES_SECTION */
                    if (tokens.size() > 2)
                    {
                        string varName = this->getVar(tokens.at(1));
                        string varValue = tokens.at(2);
                        this->m_propertiesMap.insert(pair<string, string>(varName, varValue));

                        /* PMSTA-48357 - LJE - 220510 */
                        if (this->ddlGenContextPtr->m_rdbmsEn == MSSql && varName == "USER_MODEL")
                        {
                            int USE_TRADITIONAL_USER_MODEL = 0;
                            int CHECK_PSWD_POLICY = 1;

                            if (varValue == "TRADITIONAL" || varValue == "TRADITIONAL_NO_COMPLEX_PSWD")
                            {
                                USE_TRADITIONAL_USER_MODEL = 1;

                                if (varValue == "TRADITIONAL_NO_COMPLEX_PSWD")
                                {
                                    CHECK_PSWD_POLICY = 0;
                                }
                            }

                            this->m_propertiesMap.insert(pair<string, string>("USE_TRADITIONAL_USER_MODEL", to_string(USE_TRADITIONAL_USER_MODEL)));
                            this->m_propertiesMap.insert(pair<string, string>("CHECK_PSWD_POLICY", to_string(CHECK_PSWD_POLICY)));
                        }
                    }
                    break;

                case 'B':
                    /* TRIPLE_A_DB_SECTION */ /* Sybase */
                    if (tokens.size() >= 9)
                    {
                        CFG_DB_SECTION_ST dbSectionSt;

                        dbSectionSt.dbFct = this->getVar(tokens.at((this->m_cfgFileVersion == 1 ? 8 : 7)));
                        dbSectionSt.dbSqlName = tokens.at(1);

                        this->dbSectionMap.insert(pair<string, CFG_DB_SECTION_ST>(dbSectionSt.dbFct, dbSectionSt));
                    }
                    /* TRIPLE_A_SCHEMA_SECTION */ /* Oracle */
                    else if (tokens.size() >= 5)
                    {
                        CFG_DB_SECTION_ST dbSectionSt;

                        dbSectionSt.dbFct = this->getVar(tokens.at(4));
                        dbSectionSt.dbSqlName = tokens.at(1);

                        this->dbSectionMap.insert(pair<string, CFG_DB_SECTION_ST>(dbSectionSt.dbFct, dbSectionSt));
                    }
                    /* TRIPLE_A_SCHEMA_SECTION */ /* NuoDB */ /* MSSQL */
                    else if (tokens.size() >= 3)
                    {
                        CFG_DB_SECTION_ST dbSectionSt;

                        dbSectionSt.dbFct = this->getVar(tokens.at(2));
                        dbSectionSt.dbSqlName = tokens.at(1);

                        this->dbSectionMap.insert(pair<string, CFG_DB_SECTION_ST>(dbSectionSt.dbFct, dbSectionSt));
                    }
                    break;

                case 'E':
                    /* ORACLE_SERVER_TRIPLEA_TABLESPACE_SECTION */
                    /* SQL_SERVER_SEGMENTS_SECTION */
                    /* MSSQL_SERVER_FILE_GROUP_SECTION */
                    if (tokens.size() >= 5)
                    {
                        CFG_SEG_SECTION_ST segSectionSt;

                        segSectionSt.segDictId = 0;
                        segSectionSt.dbDictId = 0;

                        segSectionSt.segFct = this->getVar(tokens.at((this->m_cfgFileVersion == 1 ? 5 : 4)));
                        segSectionSt.segSqlName = tokens.at(1);

                        segSectionSt.dbFct = this->getVar(tokens.at((this->m_cfgFileVersion == 1 ? 3 : 2)));

                        if (tokens.size() < 6 ||
                            tokens.at(5).compare("CREATION") == 0 ||
                            tokens.at(5).compare("<PHYSICAL>") == 0)
                        {
                            this->segSectionMap.insert(pair<string, CFG_SEG_SECTION_ST>(segSectionSt.segFct, segSectionSt));
                        }
                    }
                    break;

                case 'U': /* TRIPLE_A_USERS_SECTION */
                    if (tokens.size() >= 8)
                    {
                        CFG_USER_SECTION_ST usrSectionSt;
                        size_t infoPos = this->m_cfgFileVersion == 1 ? 4 : 3;

                        usrSectionSt.userName   = tokens.at(1);
                        usrSectionSt.defaultDb  = tokens.at(2);
                        usrSectionSt.cliMachine = tokens.at(infoPos++);
                        usrSectionSt.bApplOwner = tokens.at(infoPos++).compare("<YES>") == 0;
                        usrSectionSt.serverName = tokens.at(infoPos++);
                        usrSectionSt.group      = tokens.at(infoPos++);
                        usrSectionSt.bTechnical = tokens.at(infoPos++).compare("<YES>") == 0;

                        this->usrSectionMap.insert(pair<string, CFG_USER_SECTION_ST>(usrSectionSt.userName, usrSectionSt));
                    }
                    break;

                case 'O': /* TRIPLE_A_OBJECTS_SECTION */
                    if (tokens.size() >= 6)
                    {
                        CFG_OBJECT_SECTION_ST objSectionSt;
                        string audit;

                        objSectionSt.objectName       = this->getVar(tokens.at(1));
                        objSectionSt.dbFct            = this->getVar(tokens.at(2));
                        objSectionSt.tbSeg            = this->getData(tokens.at(3));
                        objSectionSt.idxSeg           = this->getData(tokens.at(4));
                        audit                         = this->getVar(tokens.at(5));
                        if (audit.compare("NO_AUDIT") == 0)
                        {
                            objSectionSt.auditAuthEn = FeatureAuth_Disable;
                        }
                        else if (audit.compare("AUDIT") == 0)
                        {
                            objSectionSt.auditAuthEn = FeatureAuth_Enable;
                        }
                        else if(audit.compare("NONE") == 0)
                        {
                            objSectionSt.auditAuthEn = FeatureAuth_Forbidden;
                        }
                        else
                        {
                            objSectionSt.auditAuthEn = FeatureAuth_Invalid;
                        }
                        objSectionSt.objectDefPos = objectDefPos++;

                        this->objSectionMap.insert(pair<string, CFG_OBJECT_SECTION_ST>(objSectionSt.objectName, objSectionSt));
                    }
                    break;

                case 'L': /* TSL_DATABASE_PROPERTIES */
                    if (tokens.size() >= 5)
                    {
                        CFG_TSL_SECTION_ST tslSectionSt;

                        tslSectionSt.objectPos = this->getVar(tokens.at(1));
                        tslSectionSt.dbFct     = this->getVar(tokens.at(2));
                        tslSectionSt.tbSeg     = this->getData(tokens.at(3));
                        tslSectionSt.idxSeg    = this->getData(tokens.at(4));

                        this->tslSectionMap.insert(pair<string, CFG_TSL_SECTION_ST>(tslSectionSt.objectPos, tslSectionSt));
                    }
                    break;

                case 'Z': /* BUSINESS_ENTITY_SINGLE_INSTANCE_CONFIG */
                    if (tokens.size() >= 2)
                    {
                        CFG_MESI_SECTION_ST mesiSectionSt;

                        mesiSectionSt.beId        = 0;
                        mesiSectionSt.beCode      = tokens.at(1);
                        mesiSectionSt.beShortName = tokens.at(2);

                        this->mesiSectionMap.insert(pair<string, CFG_MESI_SECTION_ST>(mesiSectionSt.beCode, mesiSectionSt));
                    }
                    break;

                case 'M': /* TRIPLE_A_META_DICTIONARY_CONFIG */
                    if (tokens.size() >= 3)
                    {
                        CFG_OPTION_SECTION_ST optionSectionSt;

                        optionSectionSt.fileName = tokens.at(1);
                        optionSectionSt.apply    = tokens.at(2);

                        this->optionSectionVector.push_back(optionSectionSt);
                    }
                    break;

                case 'P': /* TRIPLE_A_ORACLE_PROFILE */
                    if (tokens.size() >= 5)
                    {
                        CFG_PROFILE_SECTION_ST profileSectionSt;

                        profileSectionSt.group               = tokens.at(1);
                        profileSectionSt.profile             = tokens.at(2);
                        profileSectionSt.defaultTablespace   = tokens.at(3);
                        profileSectionSt.temporaryTablespace = tokens.at(4);

                        this->profileSectionMap.insert(pair<string, CFG_PROFILE_SECTION_ST>(profileSectionSt.group, profileSectionSt));
                    }
                    break;
            }
        }
    }

    if (this->ddlGenContextPtr->m_rdbmsEn == MSSql)
    {
        /*PMSTA-56937 - VPR - 240712*/
        /*For enabling external pk rule in MSSQL for entities using RESERVE_IDENTITY keyword. */
        CFG_OPTION_SECTION_ST optionSectionSt;

        optionSectionSt.fileName = "9999_enable_reserve_identity.imp";
        optionSectionSt.apply = "<YES>";

        this->optionSectionVector.push_back(optionSectionSt);
    }
    for (auto it = this->segSectionMap.begin(); it != this->segSectionMap.end(); ++it)
    {
        auto dbCfgIt = this->dbSectionMap.find(it->second.dbFct);
        if (dbCfgIt != this->dbSectionMap.end())
        {
            it->second.dbSqlName = dbCfgIt->second.dbSqlName;
        }
    }

    /* PMSTA-45413 - LJE - 211207 - Some default values... */
    this->setProperty("AAAMANAGENULLLEVEL", "0", false);
    this->setProperty("AAATEMPLATEVERSION", "1", false);

    return(ret);
}

/************************************************************************
**
**  Function    :  DdlGenCfgFile::checkInstallCfgFile()
**
**  Description :  Check aaa_install.cfg file
**
**  Arguments   :
**
**  Return      :  TRUE if the properties file can be open,
**                 FALSE elsewhere.
**
** Creation     :  PMSTA-32673 - LJE - 180831
**
*************************************************************************/
RET_CODE DdlGenCfgFile::checkInstallCfgFile()
{
    RET_CODE         ret = RET_SUCCEED;
    string           segmentStr, databaseStr;

    switch (EV_RdbmsVendor)
    {
        case Oracle:
            databaseStr = "schema";
            segmentStr  = "table space";
            break;

        default:
            databaseStr = "database";
            segmentStr  = "segment";
    }

    for (auto segSectionIt = this->segSectionMap.begin(); segSectionIt != this->segSectionMap.end(); ++segSectionIt)
    {
        if (this->dbSectionMap.find(segSectionIt->second.dbFct) == this->dbSectionMap.end())
        {
            ret = RET_DBA_ERR_INVDATA;
            this->printMsg(ret, "Unknown " + databaseStr + " (" + segSectionIt->second.dbFct + ") for " + segmentStr + " " + segSectionIt->second.segFct);
        }
    }

    for (auto objSectionIt = this->objSectionMap.begin(); objSectionIt != this->objSectionMap.end(); ++objSectionIt)
    {
        if (objSectionIt->second.auditAuthEn == FeatureAuth_Invalid)
        {
            ret = RET_DBA_ERR_INVDATA;
            this->printMsg(ret, "Invalid audit/subscription value for entity " + objSectionIt->second.objectName);
        }

        if (this->dbSectionMap.find(objSectionIt->second.dbFct) == this->dbSectionMap.end())
        {
            ret = RET_DBA_ERR_INVDATA;
            this->printMsg(ret, "Unknown " + databaseStr + " (" + objSectionIt->second.dbFct + ") for entity " + objSectionIt->second.objectName);
        }

        if (this->segSectionMap.empty() == false) /* PMSTA-nuodb - LJE - 190918 */
        {
            if (this->segSectionMap.find(objSectionIt->second.tbSeg) == this->segSectionMap.end())
            {
                ret = RET_DBA_ERR_INVDATA;
                this->printMsg(ret, "Unknown table " + segmentStr + " (" + objSectionIt->second.dbFct + ") for entity " + objSectionIt->second.objectName);
            }
            if (this->segSectionMap.find(objSectionIt->second.idxSeg) == this->segSectionMap.end())
            {
                ret = RET_DBA_ERR_INVDATA;
                this->printMsg(ret, "Unknown index " + segmentStr + " (" + objSectionIt->second.dbFct + ") for entity " + objSectionIt->second.objectName);
            }
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :  DdlGenCfgFile::freeInstallCfgFile()
**
**  Description :  Free aaa_install.cfg file
**
**  Arguments   :
**
**  Return      :
**
**  Creation    :  PMSTA-11505 - LJE - 110404
**
*************************************************************************/
RET_CODE DdlGenCfgFile::freeInstallCfgFile()
{
    RET_CODE   ret = RET_SUCCEED;
    return ret;
}

/************************************************************************
**
**  Function    :  DdlGenCfgFile::loadTemplateFile()
**
**  Description :  Load template file
**
**  Arguments   :
**
**  Return      :  TRUE if the properties file can be open,
**                 FALSE elsewhere.
**
** Creation     :  PMSTA-24007 - LJE - 161227
**
*************************************************************************/
RET_CODE DdlGenCfgFile::loadTemplateFile()
{
    RET_CODE         ret = RET_SUCCEED;

    string           templateLine;
    string           nameStr, selAttrStr;
    DBA_ACTION_ENUM  procActionEn = NullAction;

    CFG_TEMPLATE_ENUM          feature = CfgTemplate_Unknown;
    stringstream               paramStream;
    stringstream               initStream;
    stringstream               selectStream;
    stringstream               fromStream;
    stringstream               whereStream;
    stringstream               bodyStream;
    stringstream               alterStream;
    stringstream               keyStream;
    stringstream               onNullValueStream;
    stringstream              *outStream = nullptr;
    DdlGenCfgTemplate         *cfgTemplate = new DdlGenCfgTemplate();

    while (getline(this->m_cfgFile, templateLine))
    {
        vector<string> tokens;
        DdlGen::tokenizeStr(tokens, templateLine);

        if (tokens.size())
        {
            if (tokens.at(0).compare("_FEATURE_BEGIN") == 0)
            {
                outStream = nullptr;
                if (tokens.size() > 1)
                {
                    if (tokens.at(1).compare("security") == 0)
                    {
                        feature = CfgTemplate_Security;
                    }
                    else if (tokens.at(1).compare("standard") == 0)
                    {
                        feature = CfgTemplate_Standard;
                    }
                    else if (tokens.at(1).compare("change_set") == 0)
                    {
                        feature = CfgTemplate_ChangeSet;
                    }
                    else if (tokens.at(1).compare("temp_table") == 0)
                    {
                        feature = CfgTemplate_TempTable;
                    }
                    else if (tokens.at(1).compare("shadow") == 0)
                    {
                        feature = CfgTemplate_Shadow;
                    }
                    else if (tokens.at(1).compare("upgrade") == 0)
                    {
                        feature = CfgTemplate_Upgrade;
                    }
                }
            }
            else if (tokens.at(0).compare("_KEY") == 0)
            {
                outStream = &keyStream;
                continue;
            }
            else if (tokens.at(0).compare("_NAME") == 0)
            {
                if (tokens.size() > 0)
                {
                    nameStr = tokens.at(1);
                }
                else
                {
                    ret = RET_DBA_ERR_INVALID_FORMAT;
                    this->printMsg(ret, "Invalid '_NAME' argument in template file: " + this->m_fileName);
                }
                continue;
            }
            else if (tokens.at(0).compare("_ACTION") == 0)
            {
                if (tokens.size() > 0)
                {
                    procActionEn = DictSprocClass::getProcAction(tokens.at(1));
                }

                if (procActionEn == NullAction)
                {
                    ret = RET_DBA_ERR_INVALID_FORMAT;
                    this->printMsg(ret, "Invalid '_ACTION' argument (" + (tokens.size() > 0 ? tokens.at(1) : "") + ") in template file: " + this->m_fileName);
                }
                continue;
            }
            else if (tokens.at(0).compare("_PARAM") == 0)
            {
                outStream = &paramStream;
                continue;
            }
            else if (tokens.at(0).compare("_BODY") == 0)
            {
                outStream = &bodyStream;
                continue;
            }
            else if (tokens.at(0).compare("_ALTER") == 0)
            {
                outStream = &alterStream;
                continue;
            }
            else if (tokens.at(0).compare("_ON_NULL_VALUE") == 0)
            {
                outStream = &onNullValueStream;
                continue;
            }
            else if (tokens.at(0).compare("_INIT") == 0)
            {
                outStream = &initStream;
                continue;
            }
            else if (tokens.at(0).compare("_SELECT") == 0)
            {
                if (selAttrStr.empty() == false)
                {
                    cfgTemplate->selectMap.insert(make_pair(selAttrStr, selectStream.str()));

                    selectStream.clear();
                    selectStream.str(string());
                }

                if (tokens.size() > 0)
                {
                    selAttrStr = tokens.at(1);
                }
                else
                {
                    ret = RET_DBA_ERR_INVALID_FORMAT;
                    this->printMsg(ret, "Invalid '_SELECT' argument in template file: " + this->m_fileName);
                }
                outStream = &selectStream;
                continue;
            }
            else if (tokens.at(0).compare("_FROM") == 0)
            {
                outStream = &fromStream;
                continue;
            }
            else if (tokens.at(0).compare("_WHERE") == 0)
            {
                outStream = &whereStream;
                continue;
            }
            else if (tokens.at(0).compare("_FEATURE_END") == 0)
            {
                DDL_OBJ_ENUM               locDdlObjEn = DdlObj_None;
                string                     keyStr;
                DDL_VIEW_ENUM              ddlViewEn = View_None;
                DBA_RDBMS_ENUM             rdbms = UnknownRdbms;
                int                        version = 0;
                int                        enableAdditionalDsp = -1;
                int                        enableMultiTascLogin = -1;
                ENTITY_SECURITY_LEVEL_ENUM securityLevelEn = EntSecuLevel_NoSecured;
                string                     line;

                outStream = nullptr;

                keyStream.clear();
                while (getline(keyStream, line))
                {
                    vector<string>             keyTokens;
                    stringstream               target;
                    bool                       inComment = false;

                    this->checkComments(line, inComment, target, true);

                    string lineTrim = target.str();
                    DdlGen::tokenizeStr(keyTokens, trim(lineTrim), "=");

                    if (keyTokens.size() >= 2)
                    {
                        if (keyTokens.at(0).compare("rdbms") == 0)
                        {
                            if (keyTokens.at(1).compare("all") == 0)
                            {
                                rdbms = UnknownRdbms;
                            }
                            else if (keyTokens.at(1).compare("sybase") == 0)
                            {
                                rdbms = Sybase;
                            }
                            else if (keyTokens.at(1).compare("oracle") == 0)
                            {
                                rdbms = Oracle;
                            }
                            else if (keyTokens.at(1).compare("mssql") == 0)
                            {
                                rdbms = MSSql;
                            }
                        }
                        else if (keyTokens.at(0).compare("version") == 0)
                        {
                            version = atoi(keyTokens.at(1).c_str());
                        }
                        else if (keyTokens.at(0).compare("enable_additional_dsp") == 0)
                        {
                            enableAdditionalDsp = atoi(keyTokens.at(1).c_str());
                        }
                        else if (keyTokens.at(0).compare("enable_multi_tasc_login") == 0)
                        {
                            enableMultiTascLogin = atoi(keyTokens.at(1).c_str());
                        }
                        else if (keyTokens.at(0).compare("security_level_e") == 0)
                        {
                            securityLevelEn = (ENTITY_SECURITY_LEVEL_ENUM)atoi(keyTokens.at(1).c_str());
                        }
                        else if (keyTokens.at(0).compare("ddl_object_type") == 0)
                        {
                            locDdlObjEn = this->getDdlObjEnFromStr(keyTokens.at(1));
                            if (locDdlObjEn == DdlObj_View)
                            {
                                ddlViewEn = this->getViewEnFromStr(keyTokens.at(1));
                            }
                        }
                        else if (keyTokens.at(0).compare("key") == 0)
                        {
                            keyStr = keyTokens.at(1);
                        }
                    }
                }

                DdlGenCfgTemplateKey templateKey = DdlGenCfgTemplateKey(feature,
                                                                        rdbms,
                                                                        version,
                                                                        enableAdditionalDsp,
                                                                        enableMultiTascLogin,
                                                                        securityLevelEn,
                                                                        locDdlObjEn,
                                                                        keyStr,
                                                                        ddlViewEn);

                if (selAttrStr.empty() == false)
                {
                    cfgTemplate->selectMap.insert(make_pair(selAttrStr, selectStream.str()));
                }

                cfgTemplate->initStr        = initStream.str();
                cfgTemplate->whereStr       = whereStream.str();
                cfgTemplate->fromStr        = fromStream.str();
                cfgTemplate->paramStr       = paramStream.str();
                cfgTemplate->bodyStr        = bodyStream.str();
                cfgTemplate->alterStr       = alterStream.str();
                cfgTemplate->onNullValueStr = onNullValueStream.str();
                cfgTemplate->nameStr        = nameStr;
                cfgTemplate->procActionEn   = procActionEn;

                if (this->m_cfgTemplateMap.find(templateKey) == this->m_cfgTemplateMap.end())
                {
                    this->m_cfgTemplateMap.insert(make_pair(templateKey, cfgTemplate));
                }
                else
                {
                    ret = RET_DBA_ERR_INVALID_FORMAT;
                    this->printMsg(ret, "Duplicate configuration template key: '" + keyStr + "' in template file: " + this->m_fileName);
                }

                paramStream.clear();
                paramStream.str(string());
                initStream.clear();
                initStream.str(string());
                selectStream.clear();
                selectStream.str(string());
                fromStream.clear();
                fromStream.str(string());
                whereStream.clear();
                whereStream.str(string());
                bodyStream.clear();
                bodyStream.str(string());
                alterStream.clear();
                alterStream.str(string());
                onNullValueStream.clear();
                onNullValueStream.str(string());
                keyStream.clear();
                keyStream.str(string());
                selAttrStr.clear();
                nameStr.clear();

                cfgTemplate = new DdlGenCfgTemplate();
            }

            if (outStream)
            {
                if (outStream->str().empty() == false)
                {
                    (*outStream) << endl;
                }
                (*outStream) << templateLine;
            }
        }
    }

    delete cfgTemplate;
    return(ret);
}

/************************************************************************
**
**  Function    :  DdlGenCfgFile::freeTemplateFile()
**
**  Description :  Free template file
**
**  Arguments   :
**
**  Return      :
**
**  Creation    :  PMSTA-24007 - LJE - 161227
**
*************************************************************************/
RET_CODE DdlGenCfgFile::freeTemplateFile()
{
    RET_CODE   ret = RET_SUCCEED;

    for (auto it = this->m_cfgTemplateMap.begin(); it != this->m_cfgTemplateMap.end(); it++)
    {
        delete it->second;
    }

    return ret;
}

/************************************************************************
**
**  Function    :  DdlGenCfgFile::loadLabelsFile()
**
**  Description :  Load labels file
**
**  Arguments   :
**
**  Return      :  TRUE if the properties file can be open,
**                 FALSE elsewhere.
**
** Creation     :  PMSTA-45413 - LJE - 210804
**
*************************************************************************/
RET_CODE DdlGenCfgFile::loadLabelsFile(bool bCusto)
{
    RET_CODE             ret = RET_SUCCEED;
    string               labelLine;
    vector<string>       tokens;
    vector<DdlGenLabel> *currLabelsPtr = nullptr;
    string               currTargetStr;

    string               processStr("Loading file: " + this->m_fileName);
    this->printMsg(RET_SRV_INFO_RUNNING, processStr);

    this->m_fileLinePos = 0;
    while (getline(this->m_cfgFile, labelLine))
    {
        this->m_fileLinePos++;

        if (labelLine.empty() || labelLine[labelLine.find_first_not_of(" \t")] == '#')
        {
            continue;
        }

        if (labelLine[0] == '[')
        {
            currTargetStr = labelLine.substr(1, labelLine.find_last_of("]") - 1);
            this->m_allLabelsMap.insert(make_pair(currTargetStr, map<DICT_T, vector<DdlGenLabel>>()));
            currLabelsPtr = &this->m_allLabelsMap[currTargetStr][GET_DICT(this->m_currDictLangStp, A_DictLang_Id)];
        }
        else if (labelLine.find("{LANGUAGE") == 0)
        {
            size_t langPos = labelLine.find("'") + 1;
            string langCode = labelLine.substr(langPos, labelLine.find("'", langPos) - langPos);

            DdlGenDbaAccessGuard ddlGenDbaAccessGuard(*this->ddlGenContextPtr);
            this->m_currDictLangStp = ddlGenDbaAccessGuard.getDdlGenDbaAccess().getRecordByCode(DictLang, langCode);

            if (this->m_currDictLangStp == nullptr)
            {
                this->printMsg(RET_DBA_INFO_EXIST, "Unknown language: " + langCode);
                break;
            }
        }
        else if (currLabelsPtr != nullptr)
        {
            size_t pos = 0;
            while ((pos = labelLine.find("\\n", pos)) != string::npos)
            {
                labelLine.replace(pos, 2, "\n");
            }

            size_t endKey = labelLine.find("\"");

            if (endKey == string::npos &&
                labelLine.find(";") != string::npos)
            {
                endKey = labelLine.size() - 1;
                if (labelLine[endKey] == ';')
                {
                    endKey--;
                }
                while (labelLine[endKey] != ';' && endKey > 0)
                {
                    endKey--;
                }
                endKey++;
            }

            if (endKey == string::npos || endKey == 0)
            {
                this->printMsg(RET_DBA_ERR_INVDATA, "invalid label line: \"" + labelLine + "\"", true, this->m_fileLinePos);
            }
            else
            {
                size_t begLabel = endKey;
                size_t lenght = labelLine.size() - endKey;

                if (labelLine[labelLine.size() - 1] == ';')
                {
                    lenght--;
                }
                if (labelLine[labelLine.size() - 2] == '"')
                {
                    lenght--;
                }
                if (labelLine[begLabel] == '"')
                {
                    begLabel++;
                    lenght--;
                }

                endKey--;

                if (lenght == 0 || begLabel == string::npos)
                {
                    this->printMsg(RET_DBA_ERR_INVDATA, "invalid label line: " + labelLine);
                }
                else
                {
                    currLabelsPtr->push_back(DdlGenLabel(GET_DICT(this->m_currDictLangStp, A_DictLang_Id),
                                                         bCusto ? XdLabelNatEn::UserDefined : XdLabelNatEn::Application,
                                                         labelLine.substr(0, endKey),
                                                         labelLine.substr(begLabel, lenght)));
                }
            }
        }
        else if (this->m_currDictLangStp == nullptr)
        {
            ret = RET_DBA_ERR_INVDATA;
            this->printMsg(RET_DBA_ERR_INVDATA, "Unknown language, the labels file must be start with the line \"{LANGUAGE='language code'}");
            break;
        }
    }

    if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
    {
        this->printMsg(ret, processStr.append(" done!"));
    }
    else
    {
        this->printMsg(ret, processStr.append(" failed!"));
    }

    return ret;
}

/************************************************************************
**
**  Function    :  DdlGenCfgFile::freeLabelsFile()
**
**  Description :  Free labels file
**
**  Arguments   :
**
**  Return      :
**
**  Creation    :  PMSTA-nuodb - LJE - 190919
**
*************************************************************************/
RET_CODE DdlGenCfgFile::freeLabelsFile()
{
    RET_CODE   ret = RET_SUCCEED;
    return ret;
}

/************************************************************************
**
**  Function    :  DdlGenCfgFile::loadControlFile()
**
**  Description :  Load Control file
**
**  Arguments   :
**
**  Return      :  TRUE if the properties file can be open,
**                 FALSE elsewhere.
**
** Creation     :  PMSTA-55968 - LJE - 240711
**
*************************************************************************/
RET_CODE DdlGenCfgFile::loadControlFile()
{
    RET_CODE             ret = RET_SUCCEED;

    string               processStr("Loading file: " + this->m_fileName);
    this->printMsg(RET_SRV_INFO_RUNNING, processStr);

    string               line;
    bool                 bAttribDef = false;

    this->m_fileLinePos = 0;
    while (getline(this->m_cfgFile, line))
    {
        this->m_fileLinePos++;

        vector<string> tokens;
        DdlGen::tokenizeStr(tokens, line);

        if (tokens.empty() ||
            tokens[0].empty() ||
            tokens[0].find("#") == 0)
        {
            continue;
        }

        if (tokens[0] == "<TABLE_DESC>")
        {
            bAttribDef = !bAttribDef;
        }
        else if (bAttribDef && this->m_dictEntitStp != nullptr)
        {
            auto dictAttribStp = this->m_dictEntitStp->getDictAttribBySqlName(tokens[0]);

            std::string option;
            if (tokens.size() > 1)
            {
                option = tokens[tokens.size() - 1];
            }

            this->m_tableDescVector.push_back(std::make_pair(dictAttribStp, option));
        }
        else
        {
            switch (tokens[0][0])
            {
                case 'V': /* VARIABLES_SECTION */
                    if (tokens.size() > 2)
                    {
                        string varName = this->getVar(tokens[1]);
                        string varValue = tokens[2];
                        this->m_propertiesMap.insert(pair<string, string>(varName, varValue));

                        if (varName == "TABLE_NAME")
                        {
                            this->m_dictEntitStp = DBA_GetEntityBySqlName(varValue);
                        }
                    }
                    break;
            }
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :  DdlGenCfgFile::freeControlFile()
**
**  Description :  Free Control file
**
**  Arguments   :
**
**  Return      :
**
**  Creation    :  PMSTA-55968 - LJE - 240711
**
*************************************************************************/
RET_CODE DdlGenCfgFile::freeControlFile()
{
    RET_CODE   ret = RET_SUCCEED;
    return ret;
}


/************************************************************************
**
**  Function    :  DdlGenCfgFile::getProperty()
**
**  Description :  Get properties from init_def.properties file
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-11505 - LJE - 110404
**
*************************************************************************/
DdlGenCfgTemplate *DdlGenCfgFile::getCfgTemplate(DdlGenCfgTemplateKey &cfgTemplateKey)
{
    this->loadCfgFile();

    auto templateFeatureIt = this->m_cfgTemplateMap.find(cfgTemplateKey);

    if (templateFeatureIt == this->m_cfgTemplateMap.end() &&
        cfgTemplateKey.getRdbms() != UnknownRdbms)
    {
        cfgTemplateKey.setRdbms(UnknownRdbms);
        templateFeatureIt = this->m_cfgTemplateMap.find(cfgTemplateKey);
    }

    if (templateFeatureIt != this->m_cfgTemplateMap.end())
    {
        return templateFeatureIt->second;
    }

    return nullptr;
}

/************************************************************************
**
**  Function    :  DdlGenCfgTemplateKey::DdlGenCfgTemplateKey()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation    :  PMSTA-24007 - LJE - 161227
**
*************************************************************************/
DdlGenCfgTemplateKey::DdlGenCfgTemplateKey(CFG_TEMPLATE_ENUM           feature,
                                           DBA_RDBMS_ENUM              rdbms,
                                           int                         version,
                                           int                         enableAdditionalDsp,
                                           int                         enableMultiTascLogin,
                                           ENTITY_SECURITY_LEVEL_ENUM  securityLevelEn,
                                           DDL_OBJ_ENUM                ddlObjEn,
                                           const std::string          &keyStr,
                                           DDL_VIEW_ENUM               ddlViewEn):
                                           m_feature(feature),
                                           m_rdbms(rdbms),
                                           m_version(version),
                                           m_enableAdditionalDsp(enableAdditionalDsp),
                                           m_enableMultiTascLogin(enableMultiTascLogin),
                                           m_securityLevelEn(securityLevelEn),
                                           m_ddlObjEn(ddlObjEn),
                                           m_keyStr(keyStr),
                                           m_ddlViewEn(ddlViewEn)

{
}

/************************************************************************
**
**  Function    :  DdlGenCfgTemplateKey::DdlGenCfgTemplateKey()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation    :  PMSTA-26250 - LJE - 170410
**
*************************************************************************/
DdlGenCfgTemplateKey::DdlGenCfgTemplateKey(CFG_TEMPLATE_ENUM          feature,
                                           int                        version,
                                           DDL_OBJ_ENUM               ddlObjEn,
                                           const std::string         &keyStr):DdlGenCfgTemplateKey(feature,
                                                                                                   EV_RdbmsDdlGen,
                                                                                                   version,
                                                                                                   NO_VALUE,
                                                                                                   NO_VALUE,
                                                                                                   EntSecuLevel_NoSecured,
                                                                                                   ddlObjEn,
                                                                                                   keyStr,
                                                                                                   View_None)
{
}

DdlGenCfgTemplateKey::DdlGenCfgTemplateKey(const DdlGenCfgTemplateKey& toCopy)
{
    this->m_feature              = toCopy.m_feature;
    this->m_rdbms                = toCopy.m_rdbms;
    this->m_version              = toCopy.m_version;
    this->m_enableAdditionalDsp  = toCopy.m_enableAdditionalDsp;
    this->m_enableMultiTascLogin = toCopy.m_enableMultiTascLogin;
    this->m_securityLevelEn      = toCopy.m_securityLevelEn;
    this->m_ddlObjEn             = toCopy.m_ddlObjEn;
    this->m_keyStr               = toCopy.m_keyStr;
    this->m_ddlViewEn            = toCopy.m_ddlViewEn;
}

DdlGenCfgTemplateKey::~DdlGenCfgTemplateKey()
{
}

DdlGenCfgTemplateKey &DdlGenCfgTemplateKey::operator= (const DdlGenCfgTemplateKey &toCopy)
{
    this->m_feature              = toCopy.m_feature;
    this->m_rdbms                = toCopy.m_rdbms;
    this->m_version              = toCopy.m_version;
    this->m_enableAdditionalDsp  = toCopy.m_enableAdditionalDsp;
    this->m_enableMultiTascLogin = toCopy.m_enableMultiTascLogin;
    this->m_securityLevelEn      = toCopy.m_securityLevelEn;
    this->m_ddlObjEn             = toCopy.m_ddlObjEn;
    this->m_keyStr               = toCopy.m_keyStr;
    this->m_ddlViewEn            = toCopy.m_ddlViewEn;

    return *this;
}

bool DdlGenCfgTemplateKey::operator== (const DdlGenCfgTemplateKey &toTest) const
{
    return this->m_feature                      == toTest.m_feature &&
        this->m_rdbms                           == toTest.m_rdbms &&
        this->m_version                         == toTest.m_version &&
        this->m_enableAdditionalDsp             == toTest.m_enableAdditionalDsp &&
        this->m_enableMultiTascLogin            == toTest.m_enableMultiTascLogin &&
        this->m_securityLevelEn                 == toTest.m_securityLevelEn &&
        this->m_ddlObjEn                        == toTest.m_ddlObjEn &&
        this->m_keyStr.compare(toTest.m_keyStr) == 0 &&
        this->m_ddlViewEn                       == toTest.m_ddlViewEn;
}

bool DdlGenCfgTemplateKey::operator< (const DdlGenCfgTemplateKey &toTest) const
{
    if (this->m_feature < toTest.m_feature)
        return true;
    else if (this->m_feature > toTest.m_feature)
        return false;

    if (this->m_rdbms < toTest.m_rdbms)
        return true;
    else if (this->m_rdbms > toTest.m_rdbms)
        return false;

    if (this->m_version < toTest.m_version)
        return true;
    else if (this->m_version > toTest.m_version)
        return false;

    if (this->m_enableAdditionalDsp < toTest.m_enableAdditionalDsp)
        return true;
    else if (this->m_enableAdditionalDsp > toTest.m_enableAdditionalDsp)
        return false;

    if (this->m_enableMultiTascLogin < toTest.m_enableMultiTascLogin)
        return true;
    else if (this->m_enableMultiTascLogin > toTest.m_enableMultiTascLogin)
        return false;

    if (this->m_securityLevelEn < toTest.m_securityLevelEn)
        return true;
    else if (this->m_securityLevelEn > toTest.m_securityLevelEn)
        return false;

    if (this->m_ddlObjEn < toTest.m_ddlObjEn)
        return true;
    else if (this->m_ddlObjEn > toTest.m_ddlObjEn)
        return false;

    if (this->m_keyStr.compare(toTest.m_keyStr) < 0)
        return true;
    else if (this->m_keyStr.compare(toTest.m_keyStr) > 0)
        return false;

    if (this->m_ddlViewEn < toTest.m_ddlViewEn)
        return true;
    else if (this->m_ddlViewEn > toTest.m_ddlViewEn)
        return false;

    return false;
}

/*************************************************************************
**   END  ddlgencfgfile.cpp                                        Odyssey **
*************************************************************************/

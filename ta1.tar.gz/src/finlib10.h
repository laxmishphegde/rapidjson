/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef FINLIB10_H
#define FINLIB10_H

/************************************************************************
**      BEGIN : Global variables & external definitions attached to finlib10.c
*************************************************************************/
#ifdef  EXTERN
    #undef  EXTERN
#endif
#ifdef  FINLIB10_C
    #define	EXTERN
#else
    #define EXTERN extern
#endif

EXTERN  int FIN_StratCmpESLLevel(DBA_DYNFLD_STP*, DBA_DYNFLD_STP*);
EXTERN  int FIN_StratCmpStrat(DBA_DYNFLD_STP*, DBA_DYNFLD_STP*);
EXTERN  int FIN_StratFilterSMS(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);
EXTERN  DBA_DYNFLD_STP FIN_StratGetParESEPtr(DBA_DYNFLD_STP);
EXTERN  int FIN_StratCmpEltNat(DBA_DYNFLD_STP*, DBA_DYNFLD_STP*);
EXTERN  int FIN_StratFilterChildrenESE(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);
EXTERN  RET_CODE FIN_FieldStratUpdRecAndParent(DBA_HIER_HEAD_STP,
											   DBA_DYNFLD_STP,
											   DBA_DYNFLD_STP,
											   DBA_ACTION_ENUM,
											   int,
											   int,
											   int* ,
											   int (*)(PTR , DBA_DYNFLD_STP, FLAG_T*),  /* REF7264 - LJE - 020130 */
											   PTR,
											   FLAG_T*,
                                               FLAG_T); /* PMSTA-27076 - CHU - 170626 */

EXTERN  int FIN_CmpParGridLevelInverse(DBA_DYNFLD_STP *, DBA_DYNFLD_STP*); /* PMSTA06840-CHU-080718 */

#endif /* FINLIB10_H */


/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef FINLIB03_H
#define FINLIB03_H

/************************************************************************
**      BEGIN : Global variables & external definitions attached to finlib03.c
*************************************************************************/

extern RET_CODE FIN_BondFlows(DATETIME_T, DATETIME_T, DATETIME_T, FLAG_T,        /* PMSTA-9032 - RAK - 091216 */
                              DBA_DYNFLD_STP, EVTDATERULE_ENUM, ACCRRULE_ENUM,   /* REF11218 - TEB - 050627 */
                              DBA_DYNFLD_STP**, int*, DBA_HIER_HEAD_STP,
                                const DBA_DYNFLD_STP = nullptr);

extern RET_CODE FIN_NewBondFlows(DATETIME_T, DATETIME_T, DATETIME_T, FLAG_T,                        /* PMSTA-9032 - RAK - 091216 */
                                DBA_DYNFLD_STP, EVTDATERULE_ENUM, ACCRRULE_ENUM, DBA_DYNFLD_STP**,  /* REF11218 - TEB - 050627 */
                                int*, int *, DBA_HIER_HEAD_STP,                                     /* REF5938 - RAK - 010508 */
                                const DBA_DYNFLD_STP = nullptr);

extern RET_CODE FIN_GenerateIncomeFlows(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP), /* PMSTA00485 - DDV - 061017 */
                FIN_GetOptionInfo(DBA_DYNFLD_STP, DATE_T, FIN_OPTINFO_STP), 
                FIN_TreatCumOption(DBA_DYNFLD_STP, DATETIME_T, DBA_DYNFLD_STP, DBA_HIER_HEAD_STP),
                FIN_PeriodUnitNbr(FREQUNIT_ENUM, SMALLINT_T, FREQUNIT_ENUM, double*), /* PMSTA-45526 - VSW - 080721 */
                FIN_DebtFlows(  DATETIME_T, DATETIME_T, DATETIME_T,  /* REF6004 - AKO - 011116 : become external*/
                                DBA_DYNFLD_STP, DBA_DYNFLD_STP**, int*, DBA_HIER_HEAD_STP),
                FIN_GenerateStandInstructFlows(DBA_DYNFLD_STP, DATETIME_T, DATETIME_T, DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP **, int *); /* PMSTA06761 - DDV - 080731 */

extern RET_CODE FIN_GenerateInstrFlows( DATETIME_T, DATETIME_T, DATETIME_T,
                                        FLAG_T, /* PMSTA-9032 - RAK - 091216 */
                                        ID_T, DBA_DYNFLD_STP, ENUMMASK_T, 
                                        EVTGEN_ENUM, EVTDATERULE_ENUM, FLAG_T, GENINSTRFLOW_ENUM, ACCRRULE_ENUM,/* REF11218 - TEB - 050627 */
                                        DBA_DYNFLD_STP**, int*, DBA_HIER_HEAD_STP,
                                        const DBA_DYNFLD_STP = nullptr);

extern FLAG_T FIN_IsBondOfSwap (DBA_DYNFLD_STP, DBA_HIER_HEAD_STP); /* REF5937.3503 - AKO - 010606 */

extern bool   FIN_IsCAExchangeEventFlow(FLOWSUBNAT_ENUM subNat); 	/* PMSTA-36248 - SGO - 290819 */
extern RET_CODE FIN_GenerateVoluntaryCAFlows(DBA_DYNFLD_STP domainPtr, DBA_HIER_HEAD_STP hierHead);
extern RET_CODE getRealSIBegDate(DATETIME_T &, DATETIME_T &, FREQUNIT_ENUM, StandInstructFrequencyChoiceEn, bool, FLAG_T[], int, int&, bool, TINYINT_T, TINYINT_T,
    StandInstructExecutionUnitEn, StandInstructExecutionUnitRankEn, FLAG_T, DAY_T);
extern RET_CODE getNextExecDay(DATETIME_T &, DATETIME_T &, FREQUNIT_ENUM, StandInstructFrequencyChoiceEn, bool, FLAG_T[], int&, int &, bool, TINYINT_T, TINYINT_T,
    StandInstructExecutionUnitEn, StandInstructExecutionUnitRankEn, FLAG_T, DAY_T, DATETIME_T, int);

EXTERN RET_CODE FIN_GenStockInstrFlow(DATETIME_T, DATETIME_T, DATETIME_T, DBA_DYNFLD_STP, EVTDATERULE_ENUM,
	                                  DBA_DYNFLD_STP**, int*, DBA_HIER_HEAD_STP);

#endif /* FINLIB03_H */

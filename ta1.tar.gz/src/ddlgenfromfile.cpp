/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DDLGENFROMFILE_CPP

/************************************************************************
**      Include files
*************************************************************************/
#ifdef NTWIN
#pragma warning (push)
#endif

#include           "unidef.h"     /* Mandatory */
#include              "gen.h"
#include              "dba.h"
#include   "ddlgenfromfile.h"
#include      "ddlgentable.h"
#include        "ddlgenvar.h"
#include       "rpccontext.h"

#ifdef NTWIN
#pragma warning (pop)
#endif


using namespace std;

/************************************************************************
**      External entry points
**
*************************************************************************/
extern int EV_TableAndObjectModifFlag;

/************************************************************************
**      Local functions
**
*************************************************************************/

/************************************************************************
**      Static definitions & data
**
*************************************************************************/
#define TAG_SHORT_SQLNAME     "SHORT_SQLNAME"

#define TAG_SPROC_STD                 "SPROC_STD"
#define TAG_SPROC_ALL_STD             "SPROC_ALL_STD" /* PMSTA-13109 - LJE - 111124 */
#define TAG_SPROC_STD_BEGIN           "SPROC_STD_BEGIN"
#define TAG_SPROC_BEGIN               "SPROC_BEGIN"
#define TAG_SPROC_END                 "SPROC_END"
#define TAG_EXECUTE_AS_OWNER          "EXECUTE_AS_OWNER"  /* PMSTA-18096 - LJE - 140623 */
#define TAG_EXECUTE_AS_CALLER         "EXECUTE_AS_CALLER" /* PMSTA-18096 - LJE - 140623 */
#define TAG_WITH_RECOMPILE            "WITH_RECOMPILE"    /* PMSTA-38987 - LJE - 200214 */
#define TAG_EXECUTE_AS_LOGIN_MANAGER  "EXECUTE_AS_LOGIN_MANAGER" /* PMSTA-36209 - DDV - 191112 */
#define TAG_EXECUTE_AS_WM_TECH        "EXECUTE_AS_WM_TECH"             /* PMSTA-36209 - DDV - 191112 */
#define TAG_DETERMINISTIC             "DETERMINISTIC"
#define TAG_NO_DETERMINISTIC          "NO_DETERMINISTIC"
#define TAG_ON_EACH_DATABASE          "ON_EACH_DATABASE" /* PMSTA-34200 - LJE - 190109 */
#define TAG_PRIVATE                   "PRIVATE"
#define TAG_NOT_EXISTS                "NOT_EXISTS"
#define TAG_USE                       "USE"

#define TAG_DISABLE_CHANGE_SET        "DISABLE_CHANGE_SET"

#define TAG_EXTERNAL_ENTITY           "EXTERNAL_ENTITY"   /* PMSTA-26108 - LJE - 171101 */

#define TAG_AUTONOMOUS_TRANSACTION    "AUTONOMOUS_TRANSACTION" /* PMSTA-20494 - TEB - 160808 */

#define TAG_FUNC_BEGIN                "FUNC_BEGIN"
#define TAG_FUNC_END                  "FUNC_END"
#define TAG_RETURNS                   "RETURNS"

#define TAG_EXEC_BEGIN                "EXEC_BEGIN"
#define TAG_EXEC_END                  "EXEC_END"

/* PMSTA-16194 - LJE - 130521 */
#define TAG_VIEW_BEGIN              "VIEW_BEGIN"
#define TAG_VIEW_END                "VIEW_END"

#define TAG_SELECT                  "SELECT"
#define TAG_SELECT_DISTINCT         "SELECT_DISTINCT"
#define TAG_FROM                    "FROM"
#define TAG_WHERE                   "WHERE"
#define TAG_END                     "END"
#define TAG_ORDER                   "ORDER"
#define TAG_ISOLATION               "ISOLATION"
#define TAG_GROUP                   "GROUP"
#define TAG_HAVING                  "HAVING"
#define TAG_UNION                   "UNION"
#define TAG_UNION_ALL               "UNION_ALL"
#define TAG_VALUES                  "VALUES"
#define TAG_SELECT_VIEW             "SELECT_VIEW"
#define TAG_SELECT_LIST             "SELECT_LIST"
#define TAG_SELECT_CALL             "SELECT_CALL"
#define TAG_SELECT_IN_VAR           "SELECT_IN_VAR"
#define TAG_SELECT_VAR              "SELECT_VAR"
#define TAG_SELECT_CHECK            "SELECT_CHECK"
#define TAG_ACTION                  "ACTION"
#define TAG_NO_LANGUAGE             "NO_LANGUAGE"
#define TAG_LANGUAGE                "LANGUAGE"
#define TAG_LANGUAGE_DICT_ID        "LANGUAGE_DICT_ID"
#define TAG_NO_CODIF                "NO_CODIF"
#define TAG_CODIF                   "CODIF"
#define TAG_DATA_PROFILE            "DATA_PROFILE"
#define TAG_USER                    "USER"
#define TAG_USER_ID                 "USER_ID"
#define TAG_APPL_SESSION_CD         "APPL_SESSION_CD"
#define TAG_NO_SECURED              "NO_SECURED"
#define TAG_SECURED                 "SECURED"
#define TAG_CALL                    "CALL"
#define TAG_EXEC                    "EXEC"
#define TAG_EXEC_SQL                "EXEC_SQL"
#define TAG_SELECT_CURSOR           "SELECT_CURSOR"
#define TAG_SELECT_DISTINCT_CURSOR  "SELECT_DISTINCT_CURSOR"
#define TAG_FETCH_CURSOR            "FETCH_CURSOR"
#define TAG_END_CURSOR              "END_CURSOR"

#define TAG_FORCE_NEW_RESULTSET "FORCE_NEW_RESULTSET"   /* PMSTA-37366 - LJE - 200128 */

/* PMSTA - 40978 - JJN - 201011 - Application Context Handling */
#define TAG_SET_APPCONTEXT    "SET_APPCONTEXT"
#define TAG_GET_APPCONTEXT    "GET_APPCONTEXT"
#define TAG_RM_APPCONTEXT     "RM_APPCONTEXT"

/* PMSTA-24026 - DDV - 161114 - New tags to handle data lifecycle check */
#define TAG_MAIN_DLM_CHECK    "MAIN_DLM_CHECK"
#define TAG_ADD_DLM_CHECK     "ADD_DLM_CHECK"

#define TAG_INSERT            "INSERT"
#define TAG_UPDATE            "UPDATE"
#define TAG_UPDATE_NEW        "UPDATE_NEW" /* For trigger management */
#define TAG_DELETE            "DELETE"
#define TAG_TRUNCATE          "TRUNCATE"
#define TAG_FORCE_TRUNCATE    "FORCE_TRUNCATE"  /* PMSTA-29014 - LJE - 180122 */
#define TAG_RENAME            "RENAME"

#define TAG_CREATE            "CREATE"
#define TAG_DROP              "DROP"

/* PMSTA-14607 - LJE - 120713 */
#define TAG_AUTH_FLAG         "AUTH_FLAG"
#define TAG_NO_AUTH_FLAG      "NO_AUTH_FLAG"

#define TAG_DECLARE           "DECLARE"
#define TAG_ASSIGN            "ASSIGN"
#define TAG_ASSIGN_SELECT     "ASSIGN_SELECT"
#define TAG_IF_EXISTS         "IF_EXISTS"
#define TAG_IF_NOT_EXISTS     "IF_NOT_EXISTS"
#define TAG_OR_EXISTS         "OR_EXISTS"
#define TAG_AND_EXISTS        "AND_EXISTS"
#define TAG_OR_NOT_EXISTS     "OR_NOT_EXISTS"
#define TAG_AND_NOT_EXISTS    "AND_NOT_EXISTS"
#define TAG_IF                "IF"
#define TAG_THEN              "THEN"
#define TAG_ELSE              "ELSE"
#define TAG_ELSE_IF           "ELSE_IF"
#define TAG_ENDIF             "ENDIF"
#define TAG_BEGIN             "BEGIN"
#define TAG_BEGIN_BLK         "{"
#define TAG_END_BLK           "}"
#define TAG_WHILE             "WHILE"

#define TAG_GET               "GET"
#define TAG_SET               "SET"

#define TAG_SET_ROWCOUNT      "SET_ROWCOUNT"
#define TAG_SET_DATEFIRST     "SET_DATEFIRST"
#define TAG_SET_FORCEPLAN     "SET_FORCEPLAN"

#define TAG_GET_UPDATE_COUNT  "GET_UPDATE_COUNT"

#define TAG_APPL_RAISERROR    "APPL_RAISERROR"
#define TAG_RETURN            "RETURN"
#define TAG_PRINT             "PRINT"

#define TAG_ERROR             "ERROR"
#define TAG_ON_DUPLICATE_KEY  "ON_DUPLICATE_KEY"
#define TAG_IDENTITY          "IDENTITY"
#define TAG_UPDATE_COUNT      "UPDATE_COUNT"
#define TAG_SUSER_NAME        "SUSER_NAME"
#define TAG_MODIFSTAT_MASK    "MODIFSTAT_MASK"
#define TAG_BOOTTIME          "BOOTTIME"
#define TAG_COUNT_BIG         "COUNT_BIG"
#define TAG_TRANCOUNT         "TRANCOUNT"
#define TAG_TRANSTATE         "TRANSTATE"
#define TAG_SPID              "SPID"
#define TAG_HOST_NAME         "HOST_NAME"
#define TAG_CHARINDEX         "CHARINDEX"
#define TAG_TIME_STAMP        "TIME_STAMP"

#define TAG_LIKE              "LIKE"

#define TAG_IDENTITY_INCREMENT "IDENTITY_INCREMENT"
#define TAG_RESERVE_IDENTITY   "RESERVE_IDENTITY"

#define TAG_INDEX             "INDEX"
#define TAG_HINT              "HINT"
#define TAG_VIEW_NAME         "VIEW_NAME"

#define TAG_APPEND            "APPEND"
#define TAG_APPENDING         "APPENDING"
#define TAG_DB_ACCESS         "DB_ACCESS"

#define TAG_UNIQUE            "UNIQUE"

#define TAG_DBO               "DBO"
#define TAG_APPL_OWNER        "APPL_OWNER"
#define TAG_AAAMAIN_DB        "AAAMAIN_DB"
#define TAG_AAALOGIN_DB       "AAALOGIN_DB"
#define TAG_AAAREP_DB         "AAAREP_DB"
#define TAG_TSLPERM_DB        "TSLPERM_DB"
#define TAG_TSLTEMP_DB        "TSLTEMP_DB"

/* String management */
#define TAG_LENGTH            "LENGTH"
#define TAG_SUBSTRING         "SUBSTRING"
#define TAG_STR_REPLACE       "STR_REPLACE"
#define TAG_STR_REPLACE_CMD   "STR_REPLACE_CMD"
#define TAG_LEFT              "LEFT"
#define TAG_RIGHT             "RIGHT"
#define TAG_CHAR              "CHAR"
#define TAG_ASCII             "ASCII"

/* Functions */
#define TAG_BITAND            "BITAND"
#define TAG_BITOR             "BITOR"

#define TAG_ISNULL            "ISNULL"

/* Date functions */
#define TAG_GETDATE           "GETDATE"
#define TAG_GETDATETIME       "GETDATETIME"         /* PMSTA-33057 - LJE - 190430 */
#define TAG_DATEADD           "DATEADD"
#define TAG_DATEPART          "DATEPART"
#define TAG_DATEDIFF          "DATEDIFF"

#define TAG_TO_DATE           "TO_DATE"
#define TAG_MAGIC_BEGIN_DATE  "MAGIC_BEGIN_DATE"
#define TAG_MAGIC_END_DATE    "MAGIC_END_DATE"

#define TAG_MOD               "MOD"

#define TAG_END_CMD           "END_CMD"

#define TAG_CHECK             "CHECK"

#define TAG_BEGIN_TRAN        "BEGIN_TRAN"
#define TAG_COMMIT_TRAN       "COMMIT_TRAN"
#define TAG_ROLLBACK_TRAN     "ROLLBACK_TRAN"
#define TAG_COMMIT            "COMMIT"
#define TAG_ROLLBACK          "ROLLBACK"

#define TAG_CALL_RETURN_STATUS "CALL_RETURN_STATUS"

#define TAG_GET_ATTRIB_DICT_ID "GET_ATTRIB_DICT_ID"

/* Triggers special keywords */
#define TAG_TRIGGER_BEGIN      "TRIGGER_BEGIN"
#define TAG_TRIGGER_END        "TRIGGER_END"
#define TAG_INIT               "INIT"
#define TAG_BEFORE             "BEFORE"
#define TAG_AFTER              "AFTER"
#define TAG_BEFORE_EACH_ROW    "BEFORE_EACH_ROW"
#define TAG_AFTER_EACH_ROW     "AFTER_EACH_ROW"
#define TAG_BEFORE_STD         "BEFORE_STD"
#define TAG_AFTER_STD          "AFTER_STD"

#define TAG_DISCARD_TRIGGER    "DISCARD_TRIGGER"
#define TAG_UPDATING           "UPDATING"
#define TAG_RELEASE_TRIGGER    "RELEASE_TRIGGER"

#define TAG_INS_OBJECT_MODIF_STAT "INS_OBJECT_MODIF_STAT"

#define TAG_ROOT_ENTITY        "ROOT_ENTITY"
#define TAG_SET_ROOT_ENTITY    "SET_ROOT_ENTITY"
#define TAG_GET_ROOT_ENTITY    "GET_ROOT_ENTITY"
#define TAG_RM_ROOT_ENTITY     "RM_ROOT_ENTITY"
#define TAG_IS_ROOT_LEVEL      "IS_ROOT_LEVEL"

/* External calls */
#define TAG_EXCLUDE_BEGIN      "EXCLUDE_BEGIN"
#define TAG_EXCLUDE_END        "EXCLUDE_END"

#define TAG_NOT_BOOTSTRAP_BEGIN  "NOT_BOOTSTRAP_BEGIN"
#define TAG_NOT_BOOTSTRAP_END    "NOT_BOOTSTRAP_END"
#define TAG_NOT_INSTALL_BEGIN    "NOT_INSTALL_BEGIN"
#define TAG_NOT_INSTALL_END      "NOT_INSTALL_END"
#define TAG_INSTALL_ONLY_BEGIN   "INSTALL_ONLY_BEGIN"
#define TAG_INSTALL_ONLY_END     "INSTALL_ONLY_END"
#define TAG_RESTRICT_UPD_BEGIN   "RESTRICT_UPD_BEGIN"
#define TAG_RESTRICT_UPD_END     "RESTRICT_UPD_END"

/* Special case database dependent */
#define TAG_IF_SYBASE         "IF_SYBASE"
#define TAG_END_IF_SYBASE     "END_IF_SYBASE"
#define TAG_IF_ORACLE         "IF_ORACLE"
#define TAG_END_IF_ORACLE     "END_IF_ORACLE"
#define TAG_IF_NUODB          "IF_NUODB"
#define TAG_END_IF_NUODB      "END_IF_NUODB"
#define TAG_IF_MSSQL          "IF_MSSQL"
#define TAG_END_IF_MSSQL      "END_IF_MSSQL"
#define TAG_IF_POSTGRESQL     "IF_POSTGRESQL"
#define TAG_END_IF_POSTGRESQL "END_IF_POSTGRESQL"

#define TAG_IF_RDBMS          "IF_RDBMS"
#define TAG_END_IF_RDBMS      "END_IF_RDBMS"

#define TAG_COLLATE           "COLLATE"

/* Multi-Entity management */
#define TAG_IF_MULTI_ENTITY              "IF_MULTI_ENTITY"
#define TAG_END_IF_MULTI_ENTITY          "END_IF_MULTI_ENTITY"
#define TAG_IF_OWNER_BUSINESS_ENTITY     "IF_OWNER_BUSINESS_ENTITY"
#define TAG_END_IF_OWNER_BUSINESS_ENTITY "END_IF_OWNER_BUSINESS_ENTITY"
#define TAG_MASTER_BUSINESS_ENTITY       "MASTER_BUSINESS_ENTITY"
#define TAG_MASTER_BUSINESS_ENTITY_ID    "MASTER_BUSINESS_ENTITY_ID"
#define TAG_CONNECT_BUSINESS_ENTITY_ID   "CONNECT_BUSINESS_ENTITY_ID"

#define TAG_NO_MULTI_ENTITY            "NO_MULTI_ENTITY"
#define TAG_FORCE_CONN_ENTITY          "FORCE_CONN_ENTITY"
#define TAG_MULTI_ENTITY               "MULTI_ENTITY"

/* Standard procedure description */
#define STDP_ACTION 1
#define STDP_IN_STRUCT 2
#define STDP_OUT_STRUCT 3
#define STDP_ACCESS 4
#define STDP_NAME 5

/* Four eyes management */
#define TAG_CHANGE_SET_PROMOTION       "CHANGE_SET_PROMOTION"
#define TAG_CHANGE_SET                 "CHANGE_SET"
#define TAG_VALIDATE_SHADOW            "VALIDATE_SHADOW"
#define TAG_CURR_SHADOW_SQLNAME        "CURR_SHADOW_SQLNAME"
#define TAG_CURR_PK_ENTITY_SQLNAME     "CURR_PK_ENTITY_SQLNAME"

/* From template generation */
#define TAG_CURR_ENTITY_SQLNAME        "CURR_ENTITY_SQLNAME"
#define TAG_CURR_ENTITY_UD_SQLNAME     "CURR_ENTITY_UD_SQLNAME"
#define TAG_CURR_ENTITY_SH_SQLNAME     "CURR_ENTITY_SH_SQLNAME"
#define TAG_CURR_ENTITY_DICT_ID        "CURR_ENTITY_DICT_ID"
#define TAG_CURR_DDL_OBJECT            "CURR_DDL_OBJECT"
#define TAG_CURR_DML_ALIAS             "CURR_DML_ALIAS"
#define TAG_CURR_DML_FROM              "CURR_DML_FROM"
#define TAG_CURR_DML_WHERE             "CURR_DML_WHERE"
#define TAG_CURR_DML_BODY              "CURR_DML_BODY"

/* Automatic generation */
#define TAG_GEN_LOOP_BEGIN             "GEN_LOOP_BEGIN"
#define TAG_GEN_LOOP_END               "GEN_LOOP_END"
#define TAG_GEN_IF_BEGIN               "GEN_IF_BEGIN"
#define TAG_GEN_IF_END                 "GEN_IF_END"
#define TAG_HAS_FEATURE_ENABLE         "HAS_FEATURE_ENABLE"

#define TAG_GEN_SET_OUTPUT             "GEN_SET_OUTPUT"

/* Result set management */ /* PMSTA-28698 - LJE - 180601 */
#define TAG_GET_RESULT_SET_NUMBER      "GET_RESULT_SET_NUMBER"
#define TAG_GET_RESULT_SET_DATA        "GET_RESULT_SET_DATA"
#define TAG_GET_FIRST_DATA             "GET_FIRST_DATA"
#define TAG_GET_DATA                   "GET_DATA"
#define TAG_VALUE                      "VALUE"
#define TAG_LAST_RETURN_STATUS         "LAST_RETURN_STATUS"

/* From test and migration purpose */
#define TAG_CHECK_DB_OBJECT            "CHECK_DB_OBJECT"
#define TAG_DROP_DB_OBJECT             "DROP_DB_OBJECT"

#define TAG_ALL_TRIGGERS               "ALL_TRIGGERS"
#define TAG_DISABLE_ALL_TRIGGERS       "DISABLE_ALL_TRIGGERS"
#define TAG_ENABLE_ALL_TRIGGERS        "ENABLE_ALL_TRIGGERS"

/* PMSTA-45027 - LJE - 210521 */
#define TAG_JSON_GET_ID                "JSON_GET_ID"
#define TAG_JSON_GET_KEY               "JSON_GET_KEY"

#define TAG_DEBUG                      "DEBUG"

/************************************************************************
**      FONCTIONS
**
************************************************************************/

class InitContextClass
{
public:
    InitContextClass(DdlGenFromFileContext *contextPtr)
    {
        this->m_contextPtr = contextPtr;
    }

    ~InitContextClass()
    {
        this->m_contextPtr->currDdlGen = nullptr;
    }

private:
    DdlGenFromFileContext *m_contextPtr;
};


void DdlGenData::addResultSetData(size_t            resultSetIdx,
                                  size_t            recordIdx,
                                  DBA_DYNFLD_STP    recordStp,
                                  FIELD_IDX_T       recordStpSize)
{
    DBA_DYNFLD_STP dataStp = nullptr;

    if (recordStpSize > 0)
    {
        dataStp = mp.allocDynstWithOutDef(FILEINFO, recordStpSize);
        COPY_DYNST_SUPPLFLD(dataStp, recordStp, recordStpSize);
    }
    else
    {
        dataStp = mp.allocDynst(FILEINFO, GET_DYNSTENUM(recordStp));
        COPY_DYNST(dataStp, recordStp, GET_DYNSTENUM(recordStp));
    }

    this->m_resultSetDataVec.resize(resultSetIdx + 1);
    this->m_resultSetDataVec[resultSetIdx].resize(recordIdx + 1);

    this->m_resultSetDataVec[resultSetIdx][recordIdx] = dataStp;
}

void DdlGenData::addResultSetData(size_t resultSetIdx, size_t recordIdx, std::vector<DdlGenDataField> &ddlGenDataFieldVector)
{
    this->m_ddlGenDataFieldVector.resize(resultSetIdx + 1);

    this->m_ddlGenDataFieldVector[resultSetIdx].resize(recordIdx + 1);
    this->m_ddlGenDataFieldVector[resultSetIdx][recordIdx] = ddlGenDataFieldVector;
}

/************************************************************************
**
**  Function    :   DdlGenFromFileContext()
**
**  Description :   Constructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 140708
**
*************************************************************************/
DdlGenFromFileContext::DdlGenFromFileContext()
{
    this->reset();
}

/************************************************************************
**
**  Function    :   DdlGenFromFileContext()
**
**  Description :   Constructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 140708
**
*************************************************************************/
DdlGenFromFileContext::DdlGenFromFileContext(const DdlGenFromFileContext& context)
    : DdlGenFromFileContext()
{
    this->bUpdateIndent             = context.bUpdateIndent;
    this->lineNb                    = context.lineNb;
    this->blockLineBeginNb          = context.blockLineBeginNb;
    this->currTagNat                = context.currTagNat;
    this->currTag                   = context.currTag;
    this->currDdlGen                = context.currDdlGen;
    this->parentTagNat              = context.parentTagNat;
    this->parentPreIndent           = context.parentPreIndent;
    this->bIfIgnored                = context.bIfIgnored;
    this->forcedViewEn              = context.forcedViewEn;
    this->bForceOwnerBusinessEntity = context.bForceOwnerBusinessEntity;
    this->m_paramVectorVector       = context.m_paramVectorVector;
    this->m_parentDictEntity        = context.m_parentDictEntity;
    this->m_bForceSingleCmd         = context.m_bForceSingleCmd;
}

/************************************************************************
**
**  Function    :   ~DdlGenFromFileContext()
**
**  Description :   Destructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 140708
**
*************************************************************************/
DdlGenFromFileContext::~DdlGenFromFileContext()
{
}

/************************************************************************
**
**  Function    :   DdlGenFromFileContext::reset()
**
**  Description :   Destructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   ORACLE - LJE - 140708
**
*************************************************************************/
void DdlGenFromFileContext::reset()
{
    this->bInitCurrLineIt             = false;
    this->bUpdateIndent               = true;
    this->lineNb                      = 0;
    this->blockLineBeginNb            = 0;
    this->parentTagNat                = TagSql_Body;
    this->bIfIgnored                  = false;
    this->currTagNat                  = TagSql_None;
    this->outDdlGenPtr                = nullptr;
    this->parentContextPtr            = nullptr;
    this->currDdlGen                  = nullptr;
    this->forcedViewEn                = View_None;
    this->bForceOwnerBusinessEntity   = false;
    this->m_position                  = Position::None;
    this->m_elseResultsSetPos         = 0;
    this->m_parentDictEntity          = 0;
    this->m_bInBlock                  = false;
    this->m_singleCmd                 = false;
    this->m_bForceSingleCmd           = false;

    this->m_ifResultsSetVector.clear();
}

/************************************************************************
**
**  Function    :   DdlGenFromFile()
**
**  Description :   Constructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
DdlGenFromFile::DdlGenFromFile(DdlGenContext &paramDdlGenContext)
    : DdlGenFromFile(DdlObjFromFile_Custom, NullEntity, paramDdlGenContext, nullptr, nullptr, true, nullptr, nullptr)
{
}

/************************************************************************
**
**  Function    :   DdlGenFromFile()
**
**  Description :   Constructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
**  Last modif. :   PMSTA-24061 - 150716 - PMO : Financial server crash
**
*************************************************************************/
DdlGenFromFile::DdlGenFromFile(const DDL_OBJ_FROM_FILE_ENUM  paramDdlObjEn,
                               OBJECT_ENUM                   paramObjectEn,
                               DdlGenContext                &paramDdlGenContext,
                               DdlGenEntity                 *paramDdlGenEntityPtr,
                               DdlGen                       *paramParentDdlGen,
                               bool                          paramBAppendFile,
                               DdlGenVarHelper              *paramDdlGenVarHelperPtr,
                               DdlGenFile                   *paramFileHelperPtr)
    : DdlGenMsg(&paramDdlGenContext)
    , bPrintRowCount(true)
    , bServerOutput(true)
    , bAutoCommit(true)
    , bEndTransaction(false)
    , bKeepConnection(false)
    , bKeepData(false)
    , bKeepResultSetData(false)
    , optimLevel(0)
    , maxScale(-1)
    , rowCount(0)
    , m_dataIdx(0)
    , m_bSkipNextBloc(false)
    , onErrorRuleEn(OnErrorRuleEn::Log)
    , bPrintUserAssgn(true)
    , varHelperPtr(nullptr)
    , inDateTimeStyleEn(DateStyle_MmmDdYyyy12)
    , outDateTimeStyleEn(DateStyle_MmmDdYyyy12)
    , parentScriptTagNat(TagSql_Body)
    , context(new DdlGenFromFileContext())
    , dictEntityDictId(NullEntity)
    , m_bSendRequestWithProc(false)
    , trgPosEn(TriggerPos_None)
    , dmlEventEn(DmlEvent_None)
    , resultSetData(nullptr)
    , outDdlGenSprocPtr(nullptr)
    , outDdlGenViewPtr(nullptr)
    , outDdlGenTriggerPtr(nullptr)
    , outDdlGenPtr(nullptr)

{
    DBA_GetDictId(DictEntity, &dictEntityDictId);

    this->ddlGenEntityPtr  = paramDdlGenEntityPtr;
    this->ddlObjFromFileEn = paramDdlObjEn;
    this->allStdProcToDo   = false;
    this->bAppendFile      = paramBAppendFile;
    this->bAllowEmptyBlock = false;
    this->bInManualTrg     = false;
    this->bApplRaiseError  = false;
    this->m_bNewLine       = false;

    this->setInBlock(false);
    this->setObjectEn(paramObjectEn);

    switch (this->ddlObjFromFileEn)
    {
        case DdlObjFromFile_View:
        case DdlObjFromFile_SystemView:
        case DdlObjFromFile_UtilsView:
            this->outDdlObjEn = DdlObj_View;
            this->fileExtStr = ".vsc";
            break;

        case DdlObjFromFile_SProc:
            this->outDdlObjEn = DdlObj_SProc;
            this->fileExtStr = ".psc";
            break;

        case DdlObjFromFile_Trigger:
            this->outDdlObjEn = DdlObj_Trigger;
            this->fileExtStr = ".tsc";
            break;

        case DdlObjFromFile_Custom:
            this->outDdlObjEn = DdlObj_None;
            this->fileExtStr = string();
            break;

        case DdlObjFromFile_Sql:                /* PMSTA-24061 - 150716 - PMO */
            this->outDdlObjEn = DdlObj_Sql;
            this->fileExtStr = string();
            break;
    }

    this->init(paramObjectEn);

    if (paramDdlGenVarHelperPtr != NULL)
    {
        this->bLocalVarHelper = false;
        this->varHelperPtr = paramDdlGenVarHelperPtr;
    }
    else
    {
        this->bLocalVarHelper = true;
        this->varHelperPtr = new DdlGenVarHelper(nullptr, this);
    }

    this->fileHelperPtr = paramFileHelperPtr;
    this->m_parentDdlGenPtr = paramParentDdlGen;

    if (this->ddlObjFromFileEn == DdlObjFromFile_SProc)
    {
        this->initAllStdSProc();
    }

    this->clearTriggerInfo();
}

/************************************************************************
**
**  Function    :   DdlGenFromFile::~DdlGenFromFile()
**
**  Description :   Destructor
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
DdlGenFromFile::~DdlGenFromFile()
{
    this->deleteOutDdlGen();

    if (this->bLocalVarHelper)
    {
        delete this->varHelperPtr;
    }

    delete this->context;
    this->freeResultSetData();            /* PMSTA-28698 - LJE - 180601 */
}

/************************************************************************
*   Function             : DdlGenFromFile::tokenize()
*
*   Description          : strtok for C++
*
*   Arguments            :
*
*   Functions call       :
*
*   Return               :
*
*   Creation Date        : PMSTA-11505 - LJE - 110413
*   Last Modif.          :
*
*************************************************************************/
int  DdlGenFromFile::tokenize(vector<string>& tokens,
                              const string& delimiters = " \t",
                              bool          bAppend,
                              int           bracketOpen,
                              bool          bIsInBracket)
{
    stringstream      lineToTokenize;
    bool              bInComment = false;

    if (bAppend == false)
    {
        tokens.clear();
    }

    /* PMSTA-16194 - LJE - 130521 - Remove comments */ /* PMSTA-26108 - LJE - 171124 : use function */
    this->checkComments(this->context->currLineStrLTrim, bInComment, lineToTokenize, true);

    return DdlGen::tokenizeStr(tokens, lineToTokenize.str(), delimiters, bAppend, bracketOpen, bIsInBracket);
}

/************************************************************************
**
**  Function    :   DdlGenFromFile::getObjectEn()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
OBJECT_ENUM DdlGenFromFile::getObjectEn() const
{
    return this->objectEn;
}

/************************************************************************
**
**  Function    :   DdlGenFromFile::getObjectEn()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
void DdlGenFromFile::setObjectEn(OBJECT_ENUM locObjectEnum)
{
    this->objectEn = locObjectEnum;
}

/************************************************************************
**
**  Function    :   DdlGenFromFile::setAvoidSecurity()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 150908
**
*************************************************************************/
void DdlGenFromFile::setAvoidSecurity(bool bAvoidSecurity)
{
    this->ddlGenContextPtr->bAvoidSecured = bAvoidSecurity;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::getGenSqlLine()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-11505 - LJE - 110404
**
*************************************************************************/
bool DdlGenFromFile::getGenSqlLine(bool bFromFile, bool bRemoveComment, int *readCptPtr)
{
    bool result = false;

    if (bFromFile == false)
    {
        if (this->context->bInitCurrLineIt)
        {
            if (this->context->currBlockVector.size() == 0 ||
                this->context->currLineIt == this->context->currBlockVector.end())
            {
                this->context->currLineStrLTrim.clear();
                this->context->currLineStr.clear();
                return false;
            }

            this->context->currLineIt++;
            if (readCptPtr)
            {
                (*readCptPtr)++;
            }
            this->context->lineNb++;
        }
        else
        {
            this->context->currLineIt = this->context->currBlockVector.begin();
            this->context->bInitCurrLineIt = true;
            this->context->lineNb = 0;
        }
        if (this->context->currLineIt != this->context->currBlockVector.end())
        {
            this->context->currLineStr = *(context->currLineIt);
            if (bRemoveComment)
            {
                stringstream currLineStream;
                bool bInComment = false;

                do
                {
                    this->checkComments(this->context->currLineStr, bInComment, currLineStream, true);
                    if (bInComment)
                    {
                        this->context->currLineIt++;
                        if (readCptPtr)
                        {
                            (*readCptPtr)++;
                        }

                        this->context->lineNb++;
                        this->context->currLineStr = *(context->currLineIt);
                    }
                } while (bInComment && this->context->currLineIt != this->context->currBlockVector.end());
                this->context->currLineStr = currLineStream.str();
                this->context->currLineStrLTrim = this->context->currLineStr;
            }
            result = this->treatGenSqlLine() && this->getIndentGenSqlLine();
        }
    }
    else
    {
        this->readLineNb++;
        if (getline(*this->genSqlFile, this->context->currLineStr))
        {
            result = this->getIndentGenSqlLine();
        }
    }
    return result;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::readNextCurrBlock()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  ORACLE - LJE - 140917
**
*************************************************************************/
bool DdlGenFromFile::readNextCurrBlock()
{
    bool result = false;

    if (this->context->bInitCurrLineIt)
    {
        if (this->context->currLineIt == this->context->currBlockVector.end())
        {
            return false;
        }
        this->context->currLineIt++;
        this->context->lineNb++;
    }
    else
    {
        this->context->lineNb = 0;
        this->context->currLineIt = this->context->currBlockVector.begin();
        this->context->bInitCurrLineIt = true;
    }

    if (this->context->currLineIt != this->context->currBlockVector.end())
    {
        this->context->currLineStr = *(context->currLineIt);
        result = this->getIndentGenSqlLine();
    }
    return result;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::resetNextCurrBlock()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  ORACLE - LJE - 140917
**
*************************************************************************/
void DdlGenFromFile::resetNextCurrBlock(int prevLineNbr)
{
    if (prevLineNbr > 0)
    {
        for (int i = 0; i < prevLineNbr; i++)
        {
            this->context->currLineIt--;
            this->context->lineNb--;
        }

        this->context->currLineStr = *(context->currLineIt);
        this->getIndentGenSqlLine();
    }
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::treatGenSqlLine()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-11505 - LJE - 110404
**
*************************************************************************/
bool DdlGenFromFile::treatGenSqlLine(std::string *paramCurrLineStr)
{
    bool result = false;

    string::size_type pos, lastPos = string::npos, propPos;

    string &treatCurrLine = paramCurrLineStr == nullptr ? this->context->currLineStr : *paramCurrLineStr;

    result = true;

    /* convert Unix variable from init_def.properties */
    pos = 0;
    while ((pos = treatCurrLine.find("$", pos)) != string::npos &&
           pos != lastPos)
    {
        propPos = pos + 1;
        if ((propPos < treatCurrLine.size() && 
             treatCurrLine[propPos] != '\'' && 
             treatCurrLine[propPos] != ' ' &&
             treatCurrLine[propPos] != '$') &&   /* PMSTA-43367 - LJE - 210422 */
            (pos == 0 ||
            (isalpha(treatCurrLine[pos - 1]) == 0 &&
             (treatCurrLine[pos - 1] != '_' || treatCurrLine[propPos] == '{') &&    /* PMSTA-43914 - LJE - 210315 */
            (treatCurrLine[pos - 1] != '\\' ||
             (pos - 1 != 0 && treatCurrLine[pos - 2] == '\\' && (pos - 2 == 0 || treatCurrLine[pos - 3] != '\\')))))) /* PMSTA-43367 - LJE - 210422 */
        {
            string::size_type endPropPos = treatCurrLine.find_first_not_of("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_0123456789", propPos);
            string            propStr;
            string            propTranslate;
            bool              bInComment = false;

            if (endPropPos != string::npos &&
                endPropPos < treatCurrLine.size() &&
                treatCurrLine[endPropPos] == '$' &&
                ((endPropPos + 1) == treatCurrLine.size() ||
                 treatCurrLine[(endPropPos + 1)] == ' ' ||
                 treatCurrLine[(endPropPos + 1)] == '\t' ||
                 treatCurrLine[(endPropPos + 1)] == '\n'))
            {
                if ((endPropPos + 1) < treatCurrLine.size())
                {
                    pos = endPropPos + 1;
                }
                else
                {
                    break;
                }
            }
            else
            {
                if (endPropPos != string::npos)
                {
                    endPropPos -= propPos;
                }

                if (endPropPos == 0 && treatCurrLine.at(propPos) == '{')
                {
                    endPropPos = treatCurrLine.find("}", propPos) - propPos;
                    propStr = treatCurrLine.substr(propPos + 1, endPropPos - 1);
                    endPropPos++;
                }
                else
                {
                    propStr = treatCurrLine.substr(propPos, endPropPos);
                }

                propTranslate = this->ddlGenContextPtr->getPropFileHelper().getProperty(propStr);

                if (propTranslate[0] == '$')
                {
                    propTranslate = this->ddlGenContextPtr->getCfgFileHelper().getProperty(propStr);
                }

                if (treatCurrLine.find("--") == 0 ||
                    (treatCurrLine.find("/*") < pos &&
                     (treatCurrLine.find("*/") > pos || treatCurrLine.find("*/") == string::npos)))
                {
                    bInComment = true;
                }

                /* PMSTA-13122 - LJE - 120427 */
                if (bInComment == false && propTranslate.empty())
                {
                    char msg[256];
                    sprintf(msg, "Unknown properties \"%s\"", propStr.c_str());
                    this->printMsg(RET_GEN_ERR_INVARG, msg);

                    propTranslate = propStr;
                }
                if (endPropPos == string::npos)
                {
                    endPropPos = propStr.size();
                }
                treatCurrLine.replace(pos, endPropPos + 1, propTranslate);
                lastPos = pos;
            }
        }
        else if (pos != 0 && treatCurrLine[pos - 1] == '\\')
        {
            treatCurrLine.erase(pos - 1, 1);
        }
        else
        {
            if (propPos < treatCurrLine.size() && treatCurrLine[propPos] == '$')
            {
                pos++;
            }
            pos++;
        }
    }

    this->replaceTag(treatCurrLine, TAG_END_CMD, this->context->outDdlGenPtr->endOfCmd());
    this->replaceTag(treatCurrLine, TAG_GETDATE, this->context->outDdlGenPtr->getCmdGetDate());
    this->replaceTag(treatCurrLine, TAG_GETDATETIME, this->context->outDdlGenPtr->getCmdGetDateTime());               /* PMSTA-33057 - LJE - 190430 */
    this->replaceTag(treatCurrLine, TAG_SUSER_NAME, this->context->outDdlGenPtr->getCmdUserName());
    this->replaceTag(treatCurrLine, TAG_MAGIC_BEGIN_DATE, this->context->outDdlGenPtr->getCmdMagicBeginDate());
    this->replaceTag(treatCurrLine, TAG_MAGIC_END_DATE, this->context->outDdlGenPtr->getCmdMagicEndDate());
    this->replaceTag(treatCurrLine, TAG_MODIFSTAT_MASK, this->context->outDdlGenPtr->getCmdModifStatMask());
    this->replaceTag(treatCurrLine, TAG_DB_ACCESS, this->context->outDdlGenPtr->getCmdDbAccess());
    this->replaceTag(treatCurrLine, TAG_BOOTTIME, this->context->outDdlGenPtr->getCmdBootTime());
    this->replaceTag(treatCurrLine, TAG_COUNT_BIG, this->context->outDdlGenPtr->getCmdCountBig());
    this->replaceTag(treatCurrLine, TAG_TRANCOUNT, this->context->outDdlGenPtr->getCmdTranscount());
    this->replaceTag(treatCurrLine, TAG_TRANSTATE, this->context->outDdlGenPtr->getCmdTranstate());
    this->replaceTag(treatCurrLine, TAG_SPID, this->    context->outDdlGenPtr->getCmdSpid());
    this->replaceTag(treatCurrLine, TAG_HOST_NAME, this->context->outDdlGenPtr->getCmdHostName());
    this->replaceTag(treatCurrLine, TAG_CHAR, this->context->outDdlGenPtr->getCmdChar());
    this->replaceTag(treatCurrLine, TAG_ASCII, this->context->outDdlGenPtr->getCmdAscii());
    this->replaceTag(treatCurrLine, TAG_ALL_TRIGGERS, this->context->outDdlGenPtr->getAllTriggers());

    this->replaceTag(treatCurrLine, TAG_SET_APPCONTEXT, this->context->outDdlGenPtr->getCmdAppContext("set"));
    this->replaceTag(treatCurrLine, TAG_GET_APPCONTEXT, this->context->outDdlGenPtr->getCmdAppContext("get"));
    this->replaceTag(treatCurrLine, TAG_RM_APPCONTEXT , this->context->outDdlGenPtr->getCmdAppContext("rm"));

    this->replaceStrTag(treatCurrLine, TAG_APPEND, (" " + this->context->outDdlGenPtr->appendCharter()));
    this->replaceStrTag(treatCurrLine, TAG_LENGTH, this->context->outDdlGenPtr->length());
    this->replaceStrTag(treatCurrLine, TAG_SUBSTRING, this->context->outDdlGenPtr->substring());
    this->replaceStrTag(treatCurrLine, TAG_STR_REPLACE_CMD, this->context->outDdlGenPtr->getCmdStrReplace());

    this->replaceTag(treatCurrLine, TAG_ISNULL, this->context->outDdlGenPtr->getCmdIsNull());

    this->replaceTagByFct(treatCurrLine, TAG_DBO, &DdlGen::getDboCmd);

    /* PMSTA-26250 - LJE - 170407 */
    if (this->m_parentDdlGenPtr != nullptr && this->m_parentDdlGenPtr->getObjectEn() != NullEntity)
    {
        DICT_ENTITY_STP currDictEntityStp = this->m_parentDdlGenPtr->getDictEntityStp();
        if (currDictEntityStp->dbRuleEn == DbRule_ShadowTable)
        {
            currDictEntityStp = currDictEntityStp->linkedEntityStp;
        }
        stringstream entityDictIdStream;
        entityDictIdStream << currDictEntityStp->entDictId;

        this->replaceTag(treatCurrLine, TAG_CURR_ENTITY_SQLNAME, currDictEntityStp->mdSqlName);
        this->replaceTag(treatCurrLine, TAG_CURR_ENTITY_UD_SQLNAME, currDictEntityStp->custSqlName);
        this->replaceTag(treatCurrLine, TAG_CURR_ENTITY_SH_SQLNAME, currDictEntityStp->shortSqlname);
        this->replaceTag(treatCurrLine, TAG_CURR_ENTITY_DICT_ID, entityDictIdStream.str());

        if (currDictEntityStp->shadowEntityStp != nullptr)
        {
            this->replaceTag(treatCurrLine, TAG_CURR_SHADOW_SQLNAME, currDictEntityStp->shadowEntityStp->mdSqlName);
        }

        if (currDictEntityStp->pkEntityStp != nullptr)
        {
            this->replaceTag(treatCurrLine, TAG_CURR_PK_ENTITY_SQLNAME, currDictEntityStp->pkEntityStp->mdSqlName);
        }
        else if (currDictEntityStp->dbRuleEn == DbRule_PartialSpecialization &&
                 currDictEntityStp->linkedEntityStp->pkEntityStp != nullptr)
        {
            this->replaceTag(treatCurrLine, TAG_CURR_PK_ENTITY_SQLNAME, currDictEntityStp->linkedEntityStp->pkEntityStp->mdSqlName);
        }
    }

    if (this->ddlGenContextPtr->m_bLightContext == false)
    {
        this->replaceTagByFct(treatCurrLine, TAG_APPL_OWNER, &DdlGen::getApplOwner);

        if (this->ddlGenContextPtr->ddlGenAction.m_installLevel < 10)
        {
            this->replaceTagByFct(treatCurrLine, TAG_MASTER_BUSINESS_ENTITY_ID, &DdlGen::getMasterBusinessEntityId);
            this->replaceTagByFct(treatCurrLine, TAG_MASTER_BUSINESS_ENTITY, &DdlGen::getMasterBusinessEntityCd);
            this->replaceTagByFct(treatCurrLine, TAG_CONNECT_BUSINESS_ENTITY_ID, &DdlGen::getConnBusinessEntityId);
        }
    }

    if (this->ddlGenContextPtr->msgSqlName.empty() == false && this->context->outDdlGenPtr->getDdlObjEn() != DdlObj_Trigger)
    {
        this->replaceTag(treatCurrLine, TAG_CURR_DDL_OBJECT, "'" + this->ddlGenContextPtr->msgSqlName + "'");
    }

    if (this->context->outDdlGenPtr->getDdlObjEn() == DdlObj_View)
    {
        this->replaceTag(treatCurrLine, TAG_USER_ID, this->context->outDdlGenPtr->getCmdApplUserId());
        this->replaceTag(treatCurrLine, TAG_APPL_SESSION_CD, this->context->outDdlGenPtr->getCmdApplSessionCd());
        this->replaceTag(treatCurrLine, TAG_LANGUAGE_DICT_ID, this->context->outDdlGenPtr->getCmdLanguageDictId());
    }
    else
    {
        if (this->context->outDdlGenPtr->getDdlObjEn() != DdlObj_Trigger)
        {
            this->replaceTagByFct(treatCurrLine, TAG_USER_ID, &DdlGen::getReplaceUserId);
            this->replaceTagByFct(treatCurrLine, TAG_APPL_SESSION_CD, &DdlGen::getReplaceApplSessionCd);
            this->replaceTagByFct(treatCurrLine, TAG_LANGUAGE_DICT_ID, &DdlGen::getReplaceLanguageDictId);
        }
        this->replaceTagByFct(treatCurrLine, TAG_RELEASE_TRIGGER, &DdlGenDbi::getReleaseTrigger);

        if (this->context->outDdlGenPtr->getDdlObjEn() == DdlObj_TriggerBody &&
            this->trgPosEn != TriggerPos_None)
        {
            this->replaceTag(treatCurrLine, TAG_SET_ROOT_ENTITY, this->context->outDdlGenPtr->setRootEntity(this->context->outDdlGenPtr->getDictEntityStp()->entDictId));
            this->replaceTagByFct(treatCurrLine, TAG_GET_ROOT_ENTITY, &this->context->outDdlGenPtr->getRootEntity);
            this->replaceTagByFct(treatCurrLine, TAG_IS_ROOT_LEVEL, &this->context->outDdlGenPtr->isRootLevel);
            this->replaceTag(treatCurrLine, TAG_RM_ROOT_ENTITY, this->context->outDdlGenPtr->rmRootEntity());

            this->replaceTagByFct(treatCurrLine, TAG_DISCARD_TRIGGER, &DdlGenDbi::getDiscardTrigger);
        }

    }

    if (this->getOutDdlObjEn() == DdlObj_Sql)
    {
        this->replaceTagByFct(treatCurrLine, TAG_LAST_RETURN_STATUS, &DdlGen::manageLastReturnStatusTag);
    }
    this->replaceTagByFct(treatCurrLine, TAG_COLLATE, &DdlGen::getCollate);         

    this->replaceDbTag(treatCurrLine, TAG_AAALOGIN_DB, this->ddlGenContextPtr->getLoginDbName());
    this->replaceDbTag(treatCurrLine, TAG_AAAMAIN_DB, this->ddlGenContextPtr->getMainDbName());

    std::string locDbName;
    GEN_GetApplInfo(ApplSqrDbName, locDbName);
    this->replaceDbTag(treatCurrLine, TAG_AAAREP_DB, locDbName);

    GEN_GetApplInfo(ApplPermTslDbName, locDbName);
    this->replaceDbTag(treatCurrLine, TAG_TSLPERM_DB, locDbName);

    GEN_GetApplInfo(ApplTempTslDbName, locDbName);
    this->replaceDbTag(treatCurrLine, TAG_TSLTEMP_DB, locDbName);

    return result;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::getOutDdlObjEn()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-26108 - LJE - 171102
**
*************************************************************************/
DDL_OBJ_ENUM DdlGenFromFile::getOutDdlObjEn()
{
    if ((this->outDdlObjEn == DdlObj_SubDdlObj || this->outDdlObjEn == DdlObj_SubSql) && 
        this->m_parentDdlGenPtr)
    {
        return this->m_parentDdlGenPtr->getDdlObjEn();
    }
    return this->outDdlObjEn;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::getIndentGenSqlLine()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-11505 - LJE - 110404
**
*************************************************************************/
bool DdlGenFromFile::getIndentGenSqlLine()
{
    bool result = true;

    string::size_type pos;

    if (this->context->currLineStr.empty() == false &&
        this->context->currLineStr[this->context->currLineStr.length() - 1] == '\r')
    {
        this->context->currLineStr.erase(this->context->currLineStr.length() - 1);
    }

    if ((pos = this->context->currLineStr.find_first_not_of(" \t")) != 0 && pos != string::npos)
    {
        this->context->currLineStrLTrim = this->context->currLineStr.substr(pos);
        if (this->context->bUpdateIndent)
        {
            this->context->outDdlGenPtr->setPreIndent(this->context->currLineStr.substr(0, pos) + this->context->parentPreIndent);
        }
        return result;
    }

    if (this->context->bUpdateIndent)
    {
        this->context->outDdlGenPtr->setPreIndent(this->context->parentPreIndent);
    }

    if (pos == string::npos)
    {
        this->context->currLineStrLTrim = string();
    }
    else
    {
        this->context->currLineStrLTrim = this->context->currLineStr;
    }

    return result;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::replaceTag()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  ORACLE - LJE - 140711
**
*************************************************************************/
void DdlGenFromFile::replaceTag(string & lineToTreat, const char *tagToReplace, const std::string &replaceStr)
{
    string::size_type replacePos;

    if (tagToReplace != NULL)
    {
        while ((replacePos = this->posTag(lineToTreat, tagToReplace)) != string::npos)
        {
            lineToTreat.replace(replacePos, strlen(tagToReplace) + 1, replaceStr);
        }
    }
}


/************************************************************************
**
**  Function    :  DdlGenFromFile::replaceTag()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-49375 - LJE - 220721
**
*************************************************************************/
void DdlGenFromFile::replaceTag(string& lineToTreat, const char* tagToReplace, DdlGen_ConvertSimpleFuncPtr* replaceFct)
{
    if (tagToReplace != NULL && tagToReplace[0] != 0)
    {
        string            replaceStr;
        string::size_type replacePos;

        while ((replacePos = this->posTag(lineToTreat, tagToReplace)) != string::npos)
        {
            if (replaceStr.empty())
            {
                replaceStr = (*replaceFct)(this->ddlGenContextPtr);
            }
            lineToTreat.replace(replacePos, strlen(tagToReplace) + 1, replaceStr);
        }
    }
}


/************************************************************************
**
**  Function    :  DdlGenFromFile::setDefaultIfNull()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-40763 - LJE - 201123
**
*************************************************************************/
void DdlGenFromFile::setDefaultIfNull(std::string &lineStr, const std::string &defaultValue)
{
    string::size_type startPos = lineStr.find_first_not_of(" \t");

    if (startPos != string::npos && lineStr[startPos] != '\'')
    {
        lineStr = " #ISNULL(" + trim(lineStr) + ", " + defaultValue + ") ";
    }
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::replaceStrTag()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-40763 - LJE - 201123
**
*************************************************************************/
void DdlGenFromFile::replaceStrTag(string & lineToTreat, const char *tagToReplace, const std::string &replaceStr)
{
    string::size_type replacePos = 0;
    string::size_type tagSize = strlen(tagToReplace) + 1;

    if (tagToReplace != NULL)
    {
        string::size_type lastReplacePos = string::npos;

        while ((replacePos = this->posTag(lineToTreat, tagToReplace)) != string::npos)
        {
            if (DdlGenDbi::isCascadeNullOnString(this->ddlGenContextPtr->m_rdbmsEn) &&
                DdlGen::find_word(lineToTreat, string("#") + tagToReplace) == replacePos)           /* To avoid to manage in-string keyword*/
            {
                size_t endOfTagPos = replacePos + tagSize;
                size_t endParam = 0;

                if (strcmp(tagToReplace, TAG_APPEND) == 0)
                {
                    if (lastReplacePos == string::npos && replacePos > 0)
                    {
                        /* Search the first value to append */
                        string::size_type firstPos     = replacePos - 1;
                        bool              bContinue    = true;

                        while (firstPos != 0 &&
                            (lineToTreat[firstPos] == ' ' ||
                             lineToTreat[firstPos] == '\t'))
                        {
                            firstPos--;
                        }

                        while (bContinue && firstPos != 0)
                        {
                            if (lineToTreat[firstPos] == ')')
                            {
                                int bracketNbr = 0;

                                while (--firstPos != 1)
                                {
                                    if (lineToTreat[firstPos] == ')')
                                    {
                                        bracketNbr++;
                                    }
                                    else if (lineToTreat[firstPos] == '(')
                                    {
                                        if (bracketNbr == 0)
                                        {
                                            break;
                                        }
                                        bracketNbr--;
                                    }
                                }

                                firstPos--;
                                while (firstPos != 0 &&
                                    (lineToTreat[firstPos] == ' ' ||
                                     lineToTreat[firstPos] == '\t'))
                                {
                                    firstPos--;
                                }

                                continue;
                            }
                            else if (lineToTreat[firstPos] == '\'')
                            {
                                while (--firstPos != 1)
                                {
                                    if (lineToTreat[firstPos] == '\'')
                                    {
                                        if (lineToTreat[firstPos - 1] != '\'')
                                        {
                                            firstPos++;
                                            bContinue = false;
                                            break;
                                        }
                                        else
                                        {
                                            --firstPos;
                                        }
                                    }
                                }
                            }
                            else if (lineToTreat[firstPos] == '=' ||
                                     lineToTreat[firstPos] == ',' ||
                                     lineToTreat[firstPos] == '(')
                            {
                                firstPos++;
                                bContinue = false;
                                break;
                            }
                            else if (lineToTreat[firstPos] == ' ' ||
                                     lineToTreat[firstPos] == '\t')
                            {
                                bContinue = false;
                                break;
                            }

                            firstPos--;
                        }

                        string firstString = lineToTreat.substr(firstPos, replacePos - firstPos);

                        if (firstString.find_first_not_of(" \t") == string::npos)
                        {
                            this->printMsg(RET_GEN_ERR_INVARG, SYS_Stringer("Unsupported multi-lines #APPEND keyword"));
                        }

                        this->setDefaultIfNull(firstString);

                        lineToTreat.replace(firstPos, replacePos - firstPos, firstString);

                        replacePos = this->posTag(lineToTreat, tagToReplace);
                        endOfTagPos = replacePos + tagSize;
                    }
                    else if (replacePos == 0)
                    {
                        this->printMsg(RET_GEN_ERR_INVARG, SYS_Stringer("Unsupported multi-lines #APPEND keyword"));
                    }

                    while (endOfTagPos < lineToTreat.length() &&
                        (lineToTreat[endOfTagPos] == ' ' ||
                         lineToTreat[endOfTagPos] == '\t'))
                    {
                        endOfTagPos++;
                    }

                    size_t endOfNextPart = endOfTagPos;
                    while (endOfNextPart < lineToTreat.length())
                    {
                        if (lineToTreat[endOfNextPart] == '(')
                        {
                            int bracketNbr = 0;

                            while (++endOfNextPart < lineToTreat.length())
                            {
                                if (lineToTreat[endOfNextPart] == '(')
                                {
                                    bracketNbr++;
                                }
                                else if (lineToTreat[endOfNextPart] == ')')
                                {
                                    if (bracketNbr == 0)
                                    {
                                        break;
                                    }
                                    bracketNbr--;
                                }
                            }

                            endOfNextPart++;
                            while (endOfNextPart < lineToTreat.length() &&
                                (lineToTreat[endOfNextPart] == ' ' ||
                                 lineToTreat[endOfNextPart] == '\t'))
                            {
                                endOfNextPart++;
                            }

                            break;
                        }
                        else if (lineToTreat[endOfNextPart] == '\'')
                        {
                            while (++endOfNextPart < lineToTreat.length() - 1)
                            {
                                if (lineToTreat[endOfNextPart] == '\'')
                                {
                                    if (lineToTreat[endOfNextPart + 1] != '\'')
                                    {
                                        break;
                                    }
                                    else
                                    {
                                        endOfNextPart++;
                                    }
                                }
                            }
                            endOfNextPart++;
                            break;
                        }
                        else if (lineToTreat[endOfNextPart] == '=' ||
                                 lineToTreat[endOfNextPart] == ',')
                        {
                            break;
                        }
                        else if (lineToTreat[endOfNextPart] == ' ' ||
                                 lineToTreat[endOfNextPart] == '\t')
                        {
                            size_t nextPart = endOfNextPart + 1;

                            while (nextPart < lineToTreat.length() &&
                                (lineToTreat[nextPart] == ' ' ||
                                 lineToTreat[nextPart] == '\t'))
                            {
                                nextPart++;
                            }
                            if (lineToTreat[nextPart] != '(')
                            {
                                break;
                            }
                            endOfNextPart = nextPart - 1;
                        }

                        endOfNextPart++;
                    }

                    size_t sizeToReplace = endOfNextPart - endOfTagPos;
                    string appendString = lineToTreat.substr(endOfTagPos, sizeToReplace);

                    this->setDefaultIfNull(appendString);

                    lineToTreat.replace(endOfTagPos, sizeToReplace, appendString);

                    replacePos = this->posTag(lineToTreat, tagToReplace);
                    endOfTagPos = replacePos + tagSize;
                }
                else
                {
                    vector<string> tokens;

                    DdlGen::tokenizeStr(tokens, lineToTreat.substr(endOfTagPos), ",", false, 0, true, &endParam);

                    if (strcmp(tagToReplace, TAG_LENGTH) == 0)
                    {
                        this->setDefaultIfNull(tokens[0]);
                    }
                    else if (strcmp(tagToReplace, TAG_SUBSTRING) == 0)
                    {
                        this->setDefaultIfNull(tokens[0]);
                    }
                    else if(strcmp(tagToReplace, TAG_STR_REPLACE) == 0)
                    {
                        this->setDefaultIfNull(tokens[0]);
                        this->setDefaultIfNull(tokens[1]);
                    }
                    else
                    {
                        this->printMsg(RET_GEN_ERR_INVARG, SYS_Stringer("Unknown string tag keyword: ", tagToReplace));
                    }

                    string paramStr("(");
                    for (auto it = tokens.begin(); it != tokens.end(); ++it)
                    {
                        if (it != tokens.begin())
                        {
                            paramStr += ", ";
                        }
                        paramStr += *it;
                    }
                    paramStr += ")";
                    lineToTreat.replace(endOfTagPos, endParam + 1, paramStr);
                }
                lineToTreat.replace(replacePos, tagSize, replaceStr);
            }
            else
            {
                lineToTreat.replace(replacePos, tagSize, replaceStr);
            }

            lastReplacePos = replacePos;
        }
    }
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::replaceDbTag()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-37374 - LJE - 201117
**
*************************************************************************/
void DdlGenFromFile::replaceDbTag(string & lineToTreat, const char *tagToReplace, const std::string &replaceStr)
{
    string::size_type replacePos;

    if (tagToReplace != NULL)
    {
        while ((replacePos = this->posTag(lineToTreat, tagToReplace)) != string::npos)
        {
            size_t endOfTagPos = replacePos + strlen(tagToReplace) + 1;
            if (lineToTreat[endOfTagPos] == '.')
            {
                size_t replaceSize = 1;
                string dbAccess = DdlGenDbi::getCmdDbAccess(this->ddlGenContextPtr->m_rdbmsEn);

                if (lineToTreat[endOfTagPos + 1] == '.')
                {
                    replaceSize++;
                }
                if (dbAccess.length() != replaceSize)
                {
                    lineToTreat.replace(endOfTagPos, replaceSize, dbAccess);
                }
            }

            lineToTreat.replace(replacePos, strlen(tagToReplace) + 1, replaceStr);
        }
    }
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::replaceTagByFct()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  ORACLE - LJE - 140711
**
*************************************************************************/
void DdlGenFromFile::replaceTagByFct(string &lineToTreat, const char *tagToReplace, DdlGen_ConvertFuncPtr *replaceFct)
{
    string::size_type replacePos;

    if (tagToReplace != NULL)
    {
        while ((replacePos = this->posTag(lineToTreat, tagToReplace)) != string::npos)
        {
            string replaceStr = (*replaceFct)(lineToTreat, replacePos, this->ddlGenContextPtr, this->varHelperPtr, this->context->outDdlGenPtr);

            lineToTreat.replace(replacePos, strlen(tagToReplace) + 1, replaceStr);
        }
    }
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::replaceFunctions()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-18593 - LJE - 150121
**
*************************************************************************/
void DdlGenFromFile::replaceFunctions(string & lineToTreat)
{
    this->replaceFunction(lineToTreat, TAG_BITAND);
    this->replaceFunction(lineToTreat, TAG_BITOR);
    this->replaceFunction(lineToTreat, TAG_LEFT);
    this->replaceFunction(lineToTreat, TAG_RIGHT);
    this->replaceFunction(lineToTreat, TAG_DATEADD);
    this->replaceFunction(lineToTreat, TAG_DATEPART);
    this->replaceFunction(lineToTreat, TAG_DATEDIFF);
    this->replaceFunction(lineToTreat, TAG_TO_DATE);
    this->replaceFunction(lineToTreat, TAG_MOD);
    this->replaceFunction(lineToTreat, TAG_LIKE);
    this->replaceFunction(lineToTreat, TAG_CHARINDEX); /* PMSTA-23162 - LJE - 160426 */
    this->replaceFunction(lineToTreat, TAG_MAIN_DLM_CHECK); /* PMSTA-24026 - DDV - 161122 - Data framework */
    this->replaceFunction(lineToTreat, TAG_ADD_DLM_CHECK);  /* PMSTA-24026 - DDV - 161122 - Data framework */

    if (this->getOutDdlObjEn() != DdlObj_RuntimeSql)
    {
        this->replaceFunction(lineToTreat, TAG_GET_ATTRIB_DICT_ID);
        this->replaceFunction(lineToTreat, TAG_CHECK_DB_OBJECT);
        this->replaceFunction(lineToTreat, TAG_DROP_DB_OBJECT);
    }

    if (this->getOutDdlObjEn() == DdlObj_TriggerBody ||
        this->getOutDdlObjEn() == DdlObj_TriggerUdFieldBody)
    {
        this->replaceFunction(lineToTreat, TAG_UPDATING);
    }

    this->replaceFunctionByFct(lineToTreat, TAG_INDEX, DdlGenDbi::manageHintIndexTag);
    this->replaceFunctionByFct(lineToTreat, TAG_VIEW_NAME, DdlGen::getViewName);
    this->replaceFunctionByFct(lineToTreat, TAG_UNIQUE, DdlGen::manageUniqueTag);
    this->replaceFunctionByFct(lineToTreat, TAG_JSON_GET_ID, DdlGen::getJsonGetId);
    this->replaceFunctionByFct(lineToTreat, TAG_JSON_GET_KEY, DdlGen::getJsonGetKey);
    this->replaceFunctionByFct(lineToTreat, TAG_STR_REPLACE, DdlGenDbi::manageStrReplace);

    this->replaceFunctionByFct(lineToTreat, TAG_APPENDING, DdlGenDbi::manageAppendingReplace);

    if (this->getOutDdlObjEn() == DdlObj_Sql &&
        this->varHelperPtr != nullptr &&
        this->varHelperPtr->getVariableList()->empty() == false)
    {
        this->replaceFunctionByFct(lineToTreat, TAG_VALUE, DdlGen::manageValueTag);
    }
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::replaceFunctionByFct()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-26250 - LJE - 170614
**
*************************************************************************/
void DdlGenFromFile::replaceFunctionByFct(string & lineToTreat, const string& tagFunction, DdlGen_ReplaceFuncPtr *replaceFct)
{
    string::size_type replacePos = 0, currPos = 0;

    while ((replacePos = DdlGen::find_first_of(lineToTreat, "#", currPos)) != string::npos)
    {
        if (lineToTreat.substr(replacePos + 1, tagFunction.length()).compare(tagFunction) == 0)
        {
            string::size_type pos = replacePos + 1 + tagFunction.length(), replaceSize = 0;
            int bracketNbr = 1;

            while (lineToTreat[pos] != 0 &&
                   lineToTreat[pos] != '(' &&
                   (lineToTreat[pos] == ' ' ||
                    lineToTreat[pos] == '\t'))
            {
                pos++;
            }

            if (lineToTreat[pos] == '(')
            {
                lineToTreat[pos] = ' ';
                pos++;
                while (lineToTreat[pos] != 0 && bracketNbr != 0)
                {
                    if (lineToTreat[pos] == ')')
                    {
                        bracketNbr--;
                    }
                    else if (lineToTreat[pos] == '(')
                    {
                        bracketNbr++;
                    }
                    pos++;
                }

                if (bracketNbr == 0)
                {
                    lineToTreat[pos - 1] = ' ';
                }

                replaceSize = pos - replacePos;
            }
            else
            {
                currPos = replacePos + 1;
            }

            if (bracketNbr == 0 && replaceSize != 0)
            {
                string saveStr = this->context->currLineStrLTrim;
                vector<vector<string>> keywordParamList;

                this->context->currLineStrLTrim = lineToTreat.substr(replacePos, replaceSize);
                this->extractKeywordParam(tagFunction, 0, keywordParamList, false, true, ",");
                this->context->currLineStrLTrim = saveStr;

                string toReplace = (*replaceFct)(this->ddlGenContextPtr, this->varHelperPtr, keywordParamList);
                lineToTreat.replace(replacePos, replaceSize, toReplace);
            }
            else
            {
                this->printMsg(RET_GEN_ERR_INVARG, "Syntax error in function #" + tagFunction);
            }
        }
        else
        {
            currPos = replacePos + 1;
        }
    }

}

/************************************************************************
**
**  Function    :  DdlGenFromFile::replaceFunction()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-18593 - LJE - 150121
**
*************************************************************************/
void DdlGenFromFile::replaceFunction(string & lineToTreat, const string &tagFunction)
{
    string::size_type replacePos, currPos = 0;

    while ((replacePos = DdlGen::find_first_of(lineToTreat, "#", currPos)) != string::npos)
    {
        if (lineToTreat.substr(replacePos + 1, tagFunction.length()).compare(tagFunction) == 0)
        {
            string::size_type pos = replacePos + 1 + tagFunction.length(), replaceSize = 0;
            int bracketNbr = 1;

            DICT_ATTRIB_STP currAttribStp = NULL;

            while (lineToTreat[pos] != 0 &&
                   lineToTreat[pos] != '(' &&
                   (lineToTreat[pos] == ' ' ||
                    lineToTreat[pos] == '\t'))
            {
                pos++;
            }

            if (lineToTreat[pos] == '(')
            {
                lineToTreat[pos] = ' ';
                pos++;
                while (lineToTreat[pos] != 0 && bracketNbr != 0)
                {
                    if (lineToTreat[pos] == ')')
                    {
                        bracketNbr--;
                    }
                    else if (lineToTreat[pos] == '(')
                    {
                        bracketNbr++;
                    }
                    pos++;
                }

                if (bracketNbr == 0)
                {
                    lineToTreat[pos - 1] = ' ';
                }

                replaceSize = pos - replacePos;
            }
            else
            {
                currPos = replacePos + 1;
            }

            if (bracketNbr == 0 && replaceSize != 0)
            {
                string saveStr = this->context->currLineStrLTrim;
                stringstream replaceStream;
                vector<vector<string>> keywordParamList;

                this->context->currLineStrLTrim = lineToTreat.substr(replacePos, replaceSize);
                this->extractKeywordParam(tagFunction, 0, keywordParamList, false, true);
                this->context->currLineStrLTrim = saveStr;

                if (tagFunction.compare(TAG_CHARINDEX) == 0)
                {
                    replaceStream << this->context->outDdlGenPtr->getCmdCharindex() << "(";
                }

                switch (this->ddlGenContextPtr->m_rdbmsEn)
                {
                    case Sybase:
                    case MSSql:
                        if (tagFunction.compare(TAG_LEFT) == 0)
                        {
                            replaceStream << "left(";
                        }
                        else if (tagFunction.compare(TAG_RIGHT) == 0)
                        {
                            replaceStream << "right(";
                        }
                        else if (tagFunction.compare(TAG_DATEADD) == 0)
                        {
                            replaceStream << "dateadd(";
                        }
                        else if (tagFunction.compare(TAG_DATEPART) == 0)
                        {
                            replaceStream << "datepart(";
                        }
                        else if (tagFunction.compare(TAG_DATEDIFF) == 0)
                        {
                            replaceStream << "datediff(";
                        }
                        else if (tagFunction.compare(TAG_LIKE) == 0)
                        {
                            replaceStream << "like ";
                        }
                        break;

                    case Oracle:
                        if (tagFunction.compare(TAG_BITAND) == 0)
                        {
                            replaceStream << "bitand(";
                        }
                        else if (tagFunction.compare(TAG_BITOR) == 0)
                        {
                            if (keywordParamList.size() == 2)
                            {
                                replaceStream << keywordParamList[0][0] << " + " << keywordParamList.at(1)[0] << " - bitand(";
                            }
                            else
                            {
                                replaceStream << "bitor(";
                            }
                        }
                        else if (tagFunction.compare(TAG_LEFT) == 0 ||
                                 tagFunction.compare(TAG_RIGHT) == 0)
                        {
                            replaceStream << "substr(";
                        }
                        else if (tagFunction.compare(TAG_DATEDIFF) == 0)
                        {
                            if (keywordParamList.size() == 3)
                            {
                                if (keywordParamList[0][0].compare("day") == 0)
                                {
                                    replaceStream << "(select extract(day from subdiff)  from(select cast(" << keywordParamList.at(2)[0] << " as timestamp) - cast(" << keywordParamList.at(1)[0] << " as timestamp) subdiff from dual))";  /* PMSTA-30862 - TEB - 20171018 */
                                }
                                /* PMSTA-23385 - LJE - 160705 */
                                else if (keywordParamList[0][0].compare("ss") == 0)
                                {
                                    replaceStream << "(select extract( day from subdiff )*86400 + extract( hour from subdiff )*3600 + extract( minute from subdiff )*60 + round(extract( second from subdiff )) from (select cast ( " << keywordParamList.at(2)[0] << " as timestamp) - cast(" << keywordParamList.at(1)[0] << " as timestamp) subdiff from dual))";  /* PMSTA-30862 - TEB - 20171018 */
                                }
                                else if (keywordParamList[0][0].compare("month") == 0)
                                {
                                    replaceStream << "round(months_between(" << keywordParamList.at(2)[0] << "," << keywordParamList.at(1)[0] << "),0)";
                                }
                                else
                                {
                                    this->printMsg(RET_GEN_ERR_INVARG, "Unsupported frequency for " TAG_DATEDIFF ": " + keywordParamList[0][0]);
                                }
                            }
                            else
                            {
                                this->printMsg(RET_GEN_ERR_INVARG, "The function " TAG_DATEDIFF " have 3 parameters!");
                            }
                        }
                        else if (tagFunction.compare(TAG_MOD) == 0)
                        {
                            replaceStream << "mod(";
                        }
                        else if (tagFunction.compare(TAG_LIKE) == 0)
                        {
                            replaceStream << "like ";
                        }

                        break;

                    case Nuodb:
                        if (tagFunction.compare(TAG_LEFT) == 0)
                        {
                            replaceStream << "left(ifnull(";
                        }
                        else if (tagFunction.compare(TAG_RIGHT) == 0)
                        {
                            replaceStream << "right(ifnull(";
                        }
                        else if (tagFunction.compare(TAG_DATEADD) == 0)
                        {
                            replaceStream << "date_add(";
                        }
                        else if (tagFunction.compare(TAG_DATEPART) == 0)
                        {
                            replaceStream << "extract(";
                        }
                        else if (tagFunction.compare(TAG_DATEDIFF) == 0)
                        {
                            replaceStream << "datediff(";
                        }
                        else if (tagFunction.compare(TAG_LIKE) == 0)
                        {
                            replaceStream << "like ";
                        }
                        break;

                    case PostgreSQL:
                        if (tagFunction.compare(TAG_LEFT) == 0)
                        {
                            replaceStream << "left(";
                        }
                        else if (tagFunction.compare(TAG_RIGHT) == 0)
                        {
                            replaceStream << "right(";
                        }
                        else if (tagFunction.compare(TAG_DATEPART) == 0)
                        {
                            replaceStream << "extract(";
                        }
                        else if (tagFunction.compare(TAG_LIKE) == 0)
                        {
                            replaceStream << "like ";
                        }
                        break;

                    case Sqlite:
                        if (tagFunction.compare(TAG_LIKE) == 0)
                        {
                            replaceStream << "like ";
                        }
                        break;
                }

                string endCmdStr;
                vector<vector<string>>::iterator lastIt = keywordParamList.end() - 1;
                for (vector<vector<string>>::iterator it = keywordParamList.begin(); it != keywordParamList.end(); it++)
                {
                    string currParamStr = it->at(0), newParamStr;

                    if (tagFunction.compare(TAG_LIKE) == 0 &&
                        currParamStr.empty() == false)
                    {
                        if (currParamStr[0] != '\'')
                        {
                            if (endCmdStr.empty())
                            {
                                switch (this->ddlGenContextPtr->m_rdbmsEn)
                                {
                                    case Sybase:
                                    case MSSql:
                                        break;

                                    case Oracle:
                                    case Nuodb:
                                    case PostgreSQL:
                                    case Sqlite:
                                        endCmdStr = " escape '\\'";
                                        break;
                                }
                            }
                        }
                        else
                        {
                            for (string::iterator it2 = currParamStr.begin(); it2 != currParamStr.end(); it2++)
                            {
                                if (*it2 == '_')
                                {
                                    switch (this->ddlGenContextPtr->m_rdbmsEn)
                                    {
                                        case Sybase:
                                        case MSSql:
                                            newParamStr += "[_]";
                                            break;

                                        case Oracle:
                                        case Nuodb:
                                        case PostgreSQL:
                                        case Sqlite:
                                            newParamStr += "\\_";

                                            if (endCmdStr.empty())
                                            {
                                                endCmdStr = " escape '\\'";
                                            }
                                            break;
                                    }
                                }
                                else
                                {
                                    newParamStr += *it2;
                                }
                            }
                            currParamStr = newParamStr;
                        }
                    }

                    /* For each parameter... */
                    switch (this->ddlGenContextPtr->m_rdbmsEn)
                    {
                        case Sybase:
                        case MSSql: 
                            if (tagFunction.compare(TAG_MOD) != 0 &&
                                tagFunction.compare(TAG_TO_DATE) != 0 &&
                                tagFunction.compare(TAG_GET_ATTRIB_DICT_ID) != 0 &&
                                tagFunction.compare(TAG_CHECK_DB_OBJECT) != 0 &&
                                tagFunction.compare(TAG_DROP_DB_OBJECT) != 0 &&
                                tagFunction.compare(TAG_UPDATING) != 0 &&
                                tagFunction.compare(TAG_MAIN_DLM_CHECK) != 0 &&
                                tagFunction.compare(TAG_ADD_DLM_CHECK) != 0)
                            {
                                replaceStream << currParamStr;
                            }
                            break;

                        case Oracle:
                            if (tagFunction.compare(TAG_DATEADD) != 0 &&
                                tagFunction.compare(TAG_LEFT) != 0 &&
                                tagFunction.compare(TAG_RIGHT) != 0 &&
                                tagFunction.compare(TAG_DATEPART) != 0 &&
                                tagFunction.compare(TAG_DATEDIFF) != 0 &&
                                tagFunction.compare(TAG_TO_DATE) != 0 &&
                                tagFunction.compare(TAG_GET_ATTRIB_DICT_ID) != 0 &&
                                tagFunction.compare(TAG_CHECK_DB_OBJECT) != 0 &&
                                tagFunction.compare(TAG_DROP_DB_OBJECT) != 0 &&
                                tagFunction.compare(TAG_UPDATING) != 0 &&
                                tagFunction.compare(TAG_CHARINDEX) != 0 &&
                                tagFunction.compare(TAG_MAIN_DLM_CHECK) != 0 &&
                                tagFunction.compare(TAG_ADD_DLM_CHECK) != 0)
                            {
                                replaceStream << currParamStr;
                            }
                            break;

                        case Nuodb:
                            if (tagFunction.compare(TAG_DATEADD) != 0 &&
                                tagFunction.compare(TAG_DATEPART) != 0 &&
                                tagFunction.compare(TAG_DATEDIFF) != 0 &&
                                tagFunction.compare(TAG_MOD) != 0 &&
                                tagFunction.compare(TAG_TO_DATE) != 0 &&
                                tagFunction.compare(TAG_GET_ATTRIB_DICT_ID) != 0 &&
                                tagFunction.compare(TAG_CHECK_DB_OBJECT) != 0 &&
                                tagFunction.compare(TAG_DROP_DB_OBJECT) != 0 &&
                                tagFunction.compare(TAG_UPDATING) != 0 &&
                                tagFunction.compare(TAG_MAIN_DLM_CHECK) != 0 &&
                                tagFunction.compare(TAG_ADD_DLM_CHECK) != 0)
                            {
                                replaceStream << currParamStr;
                            }
                            break;

                        case PostgreSQL:
                            if (tagFunction.compare(TAG_MOD) != 0 &&
                                tagFunction.compare(TAG_DATEADD) != 0 &&
                                tagFunction.compare(TAG_TO_DATE) != 0 &&
                                tagFunction.compare(TAG_DATEPART) != 0 &&
                                tagFunction.compare(TAG_DATEDIFF) != 0 &&
                                tagFunction.compare(TAG_CHARINDEX) != 0 && 
                                tagFunction.compare(TAG_GET_ATTRIB_DICT_ID) != 0 &&
                                tagFunction.compare(TAG_CHECK_DB_OBJECT) != 0 &&
                                tagFunction.compare(TAG_DROP_DB_OBJECT) != 0 &&
                                tagFunction.compare(TAG_UPDATING) != 0 &&
                                tagFunction.compare(TAG_MAIN_DLM_CHECK) != 0 &&
                                tagFunction.compare(TAG_ADD_DLM_CHECK) != 0)
                            {
                                replaceStream << currParamStr;
                            }
                            break;

                        case Sqlite:
                            if (tagFunction.compare(TAG_DATEADD) != 0 &&
                                tagFunction.compare(TAG_LEFT) != 0 &&
                                tagFunction.compare(TAG_RIGHT) != 0 &&
                                tagFunction.compare(TAG_DATEPART) != 0 &&
                                tagFunction.compare(TAG_DATEDIFF) != 0 &&
                                tagFunction.compare(TAG_TO_DATE) != 0 &&
                                tagFunction.compare(TAG_GET_ATTRIB_DICT_ID) != 0 &&
                                tagFunction.compare(TAG_CHECK_DB_OBJECT) != 0 &&
                                tagFunction.compare(TAG_DROP_DB_OBJECT) != 0 &&
                                tagFunction.compare(TAG_UPDATING) != 0 &&
                                tagFunction.compare(TAG_CHARINDEX) != 0 &&
                                tagFunction.compare(TAG_MAIN_DLM_CHECK) != 0 &&
                                tagFunction.compare(TAG_ADD_DLM_CHECK) != 0)
                            {
                                replaceStream << currParamStr;
                            }
                            break;
                    }

                    if (it != lastIt)
                    {
                        /* Until parameter before the last */
                        switch (this->ddlGenContextPtr->m_rdbmsEn)
                        {
                            case Sybase:
                            case MSSql:
                                if (tagFunction.compare(TAG_BITAND) == 0)
                                {
                                    replaceStream << " & ";
                                }
                                else if (tagFunction.compare(TAG_BITOR) == 0)
                                {
                                    replaceStream << " | ";
                                }
                                else if (tagFunction.compare(TAG_MOD) != 0 &&
                                         tagFunction.compare(TAG_GET_ATTRIB_DICT_ID) != 0 &&
                                         tagFunction.compare(TAG_CHECK_DB_OBJECT) != 0 &&
                                         tagFunction.compare(TAG_DROP_DB_OBJECT) != 0 &&
                                         tagFunction.compare(TAG_MAIN_DLM_CHECK) != 0 &&
                                         tagFunction.compare(TAG_ADD_DLM_CHECK) != 0)
                                {
                                    replaceStream << ", ";
                                }
                                break;

                            case Oracle:
                                if (tagFunction.compare(TAG_LEFT) != 0 &&
                                    tagFunction.compare(TAG_RIGHT) != 0 &&
                                    tagFunction.compare(TAG_DATEADD) != 0 &&
                                    tagFunction.compare(TAG_DATEPART) != 0 &&
                                    tagFunction.compare(TAG_DATEDIFF) != 0 &&
                                    tagFunction.compare(TAG_CHARINDEX) != 0 &&
                                    tagFunction.compare(TAG_GET_ATTRIB_DICT_ID) != 0 &&
                                    tagFunction.compare(TAG_CHECK_DB_OBJECT) != 0 &&
                                    tagFunction.compare(TAG_DROP_DB_OBJECT) != 0 &&
                                    tagFunction.compare(TAG_MAIN_DLM_CHECK) != 0 &&
                                    tagFunction.compare(TAG_ADD_DLM_CHECK) != 0)
                                {
                                    replaceStream << ", ";
                                }
                                break;

                            case Nuodb:
                                if (tagFunction.compare(TAG_RIGHT) == 0 ||
                                    tagFunction.compare(TAG_LEFT) == 0)
                                {
                                    replaceStream << ", '')";
                                }

                                if (tagFunction.compare(TAG_BITAND) == 0)
                                {
                                    replaceStream << " & ";
                                }
                                else if (tagFunction.compare(TAG_BITOR) == 0)
                                {
                                    replaceStream << " | ";
                                }
                                else if (tagFunction.compare(TAG_DATEADD) != 0 &&
                                         tagFunction.compare(TAG_DATEPART) != 0 &&
                                         tagFunction.compare(TAG_DATEDIFF) != 0 &&
                                         tagFunction.compare(TAG_MOD) != 0 &&
                                         tagFunction.compare(TAG_GET_ATTRIB_DICT_ID) != 0 &&
                                         tagFunction.compare(TAG_CHECK_DB_OBJECT) != 0 &&
                                         tagFunction.compare(TAG_DROP_DB_OBJECT) != 0 &&
                                         tagFunction.compare(TAG_MAIN_DLM_CHECK) != 0 &&
                                         tagFunction.compare(TAG_ADD_DLM_CHECK) != 0)
                                {
                                    replaceStream << ", ";
                                }
                                break;

                            case PostgreSQL:
                                if (tagFunction.compare(TAG_BITAND) == 0)
                                {
                                    replaceStream << " & ";
                                }
                                else if (tagFunction.compare(TAG_BITOR) == 0)
                                {
                                    replaceStream << " | ";
                                }
                                else if (tagFunction.compare(TAG_MOD) != 0 &&
                                         tagFunction.compare(TAG_DATEADD) != 0 &&
                                         tagFunction.compare(TAG_DATEPART) != 0 &&
                                         tagFunction.compare(TAG_DATEDIFF) != 0 &&
                                         tagFunction.compare(TAG_CHARINDEX) != 0 &&
                                         tagFunction.compare(TAG_GET_ATTRIB_DICT_ID) != 0 &&
                                         tagFunction.compare(TAG_CHECK_DB_OBJECT) != 0 &&
                                         tagFunction.compare(TAG_DROP_DB_OBJECT) != 0 &&
                                         tagFunction.compare(TAG_MAIN_DLM_CHECK) != 0 &&
                                         tagFunction.compare(TAG_ADD_DLM_CHECK) != 0)
                                {
                                    replaceStream << ", ";
                                }
                                break;

                        }
                    }
                    else /* Last */
                    {
                        if (tagFunction.compare(TAG_UPDATING) == 0)
                        {
                            currAttribStp = DBA_GetAttributeBySqlName(this->objectEn, currParamStr.c_str());
                        }
                        else if (tagFunction.compare(TAG_TO_DATE) == 0)
                        {
                            switch (this->ddlGenContextPtr->m_rdbmsEn)
                            {
                                case Sybase:
                                case MSSql:
                                    replaceStream << "convert(datetime, " << currParamStr << ", 103)";
                                    break;

                                case Oracle:
                                    replaceStream << "TO_DATE(" << currParamStr << ", 'dd/mm/yyyy')";
                                    break;

                                case Nuodb:
                                {
                                    string::size_type firstPos = currParamStr.find("/");
                                    string::size_type secondPos = currParamStr.find("/", firstPos + 1);
                                    replaceStream
                                        << "'" << currParamStr.substr(secondPos + 1, currParamStr.size() - secondPos - 2)
                                        << "/" << currParamStr.substr(firstPos + 1, secondPos - firstPos - 1)
                                        << "/" << currParamStr.substr(1, firstPos - 1)
                                        << "'";
                                }
                                break;

                                case PostgreSQL:
                                    replaceStream << "TO_DATE(" << currParamStr << ", 'dd/mm/yyyy')";
                                    break;

                            }
                        }
                        else
                        {
                            /* At the end */
                            switch (this->ddlGenContextPtr->m_rdbmsEn)
                            {
                                case Sybase:
                                case MSSql:
                                    if (tagFunction.compare(TAG_MOD) == 0)
                                    {
                                        if (keywordParamList.size() == 2)
                                        {
                                            replaceStream << "(" << keywordParamList[0][0] << " % " << keywordParamList.at(1)[0] << ")";
                                        }
                                        else
                                        {
                                            this->printMsg(RET_GEN_ERR_INVARG, "The function " TAG_MOD " have 2 parameters!");
                                        }
                                    }
                                    break;

                                case Oracle:
                                    if (tagFunction.compare(TAG_DATEADD) == 0)
                                    {
                                        if (keywordParamList.size() == 3)
                                        {
                                            string frequency = keywordParamList[0][0];
                                            string interval = keywordParamList.at(1)[0];

                                            if (frequency.compare("dayofyear") == 0 ||
                                                frequency.compare("dy") == 0 ||
                                                frequency.compare("weekday") == 0 ||
                                                frequency.compare("dw") == 0 ||
                                                frequency.compare("dd") == 0)
                                            {
                                                frequency = "day";
                                            }
                                            else if (frequency.compare("quarter") == 0 ||
                                                     frequency.compare("qq") == 0)
                                            {
                                                frequency = "month";
                                                interval = "3 * (" + interval + ")";
                                            }

                                            replaceStream << keywordParamList.at(2)[0] << " + "
                                                << interval
                                                << " * interval '1' " << frequency;
                                        }
                                        else
                                        {
                                            this->printMsg(RET_GEN_ERR_INVARG, "The function " TAG_DATEADD " have 3 parameters!");
                                        }
                                    }
                                    else if (tagFunction.compare(TAG_DATEPART) == 0)
                                    {
                                        if (keywordParamList.size() == 2)
                                        {
                                            if (keywordParamList[0][0].compare("ms") == 0)
                                            {
                                                replaceStream << "to_number(to_char(cast(" << keywordParamList.at(1)[0] << " as timestamp), 'FF3'))";
                                            }
                                            else if (keywordParamList[0][0].compare("hour") == 0)
                                            {
                                                replaceStream << "to_number(to_char(cast(" << keywordParamList.at(1)[0] << " as timestamp), 'HH24'))";
                                            }
                                            else if (keywordParamList[0][0].compare("minute") == 0)
                                            {
                                                replaceStream << "to_number(to_char(cast(" << keywordParamList.at(1)[0] << " as timestamp), 'MI'))";
                                            }
                                            else if (keywordParamList[0][0].compare("quarter") == 0)
                                            {
                                                replaceStream << "to_number(to_char(" << keywordParamList.at(1)[0] << ", 'Q'))";
                                            }
                                            else if (keywordParamList[0][0].compare("week") == 0)
                                            {
                                                replaceStream << "to_number(to_char(" << keywordParamList.at(1)[0] << ", 'WW'))";
                                            }
                                            else if (keywordParamList[0][0].compare("weekday") == 0)
                                            {
                                                replaceStream << "to_number(to_char(" << keywordParamList.at(1)[0] << ", 'd'))";
                                            }
                                            else if (keywordParamList[0][0].compare("dayofyear") == 0)
                                            {
                                                replaceStream << "to_number(to_char(" << keywordParamList.at(1)[0] << ", 'DDD'))";
                                            }
                                            else
                                            {
                                                replaceStream << "extract(" << keywordParamList[0][0] << " from " << keywordParamList.at(1)[0] << ")";
                                            }
                                        }
                                        else
                                        {
                                            this->printMsg(RET_GEN_ERR_INVARG, "The function " TAG_DATEPART " have 2 parameters!");
                                        }
                                    }
                                    else if (tagFunction.compare(TAG_LEFT) == 0)
                                    {
                                        if (keywordParamList.size() == 2)
                                        {
                                            replaceStream << keywordParamList[0][0] << ", 1, " << keywordParamList.at(1)[0];
                                        }
                                        else
                                        {
                                            this->printMsg(RET_GEN_ERR_INVARG, "The function " TAG_LEFT " have 2 parameters!");
                                        }
                                    }
                                    else if (tagFunction.compare(TAG_RIGHT) == 0)
                                    {
                                        if (keywordParamList.size() == 2)
                                        {
                                            replaceStream << keywordParamList[0][0] << ", length(" << keywordParamList[0][0] << ")+1 - " << keywordParamList.at(1)[0];
                                        }
                                        else
                                        {
                                            this->printMsg(RET_GEN_ERR_INVARG, "The function " TAG_RIGHT " have 2 parameters!");
                                        }
                                    }
                                    else if (tagFunction.compare(TAG_CHARINDEX) == 0)
                                    {
                                        if (keywordParamList.size() == 2)
                                        {
                                            replaceStream << keywordParamList.at(1)[0] << ", " << keywordParamList[0][0];
                                        }
                                        else
                                        {
                                            this->printMsg(RET_GEN_ERR_INVARG, "The function " TAG_CHARINDEX " have 2 parameters!");
                                        }
                                    }
                                    break;

                                case Nuodb:
                                    if (tagFunction.compare(TAG_DATEADD) == 0 ||
                                        tagFunction.compare(TAG_DATEPART) == 0 ||
                                        tagFunction.compare(TAG_DATEDIFF) == 0)
                                    {
                                        string frequency;
                                        string interval;

                                        if (tagFunction.compare(TAG_DATEADD) == 0)
                                        {
                                            if (keywordParamList.size() == 3)
                                            {
                                                frequency = keywordParamList[0][0];
                                                interval = keywordParamList.at(1)[0];
                                            }
                                            else
                                            {
                                                this->printMsg(RET_GEN_ERR_INVARG, "The function " + tagFunction + " must have 3 parameters!");
                                            }
                                        }
                                        else if (tagFunction.compare(TAG_DATEDIFF) == 0)
                                        {
                                            if (keywordParamList.size() == 3)
                                            {
                                                frequency = keywordParamList[0][0];
                                            }
                                            else
                                            {
                                                this->printMsg(RET_GEN_ERR_INVARG, "The function " + tagFunction + " must have 3 parameters!");
                                            }
                                        }
                                        else if (tagFunction.compare(TAG_DATEPART) == 0)
                                        {
                                            if (keywordParamList.size() == 2)
                                            {
                                                frequency = keywordParamList[0][0];
                                            }
                                            else
                                            {
                                                this->printMsg(RET_GEN_ERR_INVARG, "The function " + tagFunction + " must have 2 parameters!");
                                            }
                                        }

                                        if (frequency.empty() == false)
                                        {
                                            if (frequency.compare("dy") == 0 ||
                                                frequency.compare("dw") == 0 ||
                                                frequency.compare("dd") == 0)
                                            {
                                                frequency = "day";
                                            }
                                            if (frequency.compare("weekday") == 0)
                                            {
                                                frequency = "dayofweek";
                                            }
                                            else if (frequency.compare("ss") == 0)
                                            {
                                                frequency = "second";
                                            }
                                            else if (frequency.compare("ms") == 0)
                                            {
                                                frequency = "microsecond";
                                            }
                                            else if ((frequency.compare("quarter") == 0 && tagFunction.compare(TAG_DATEPART) != 0) ||
                                                     frequency.compare("qq") == 0)
                                            {
                                                frequency = "month";
                                                interval = "3 * (" + interval + ")";
                                            }
                                            else if (frequency.compare("week") == 0)
                                            {
                                                frequency = "weekofyear";
                                            }

                                            if (tagFunction.compare(TAG_DATEADD) == 0)
                                            {
                                                replaceStream << keywordParamList.at(2)[0] << ", interval " << interval << " " << frequency;
                                            }
                                            else if (tagFunction.compare(TAG_DATEPART) == 0)
                                            {
                                                replaceStream << frequency << " from " << keywordParamList.at(1)[0];
                                            }
                                            else if (tagFunction.compare(TAG_DATEDIFF) == 0)
                                            {
                                                replaceStream << frequency << ", " << keywordParamList.at(1)[0] << ", " << keywordParamList.at(2)[0];
                                            }
                                        }
                                    }
                                    else if (tagFunction.compare(TAG_MOD) == 0)
                                    {
                                        if (keywordParamList.size() == 2)
                                        {
                                            replaceStream << "(" << keywordParamList[0][0] << " % " << keywordParamList.at(1)[0] << ")";
                                        }
                                        else
                                        {
                                            this->printMsg(RET_GEN_ERR_INVARG, "The function " TAG_MOD " have 2 parameters!");
                                        }
                                    }
                                    break;

                                    case PostgreSQL:
                                        if (tagFunction.compare(TAG_DATEADD) == 0 ||
                                            tagFunction.compare(TAG_DATEPART) == 0 ||
                                            tagFunction.compare(TAG_DATEDIFF) == 0)
                                        {
                                            string frequency;
                                            string interval;

                                            if (tagFunction.compare(TAG_DATEADD) == 0)
                                            {
                                                if (keywordParamList.size() == 3)
                                                {
                                                    frequency = keywordParamList[0][0];
                                                    interval = keywordParamList.at(1)[0];
                                                }
                                                else
                                                {
                                                    this->printMsg(RET_GEN_ERR_INVARG, "The function " + tagFunction + " must have 3 parameters!");
                                                }
                                            }
                                            else if (tagFunction.compare(TAG_DATEDIFF) == 0)
                                            {
                                                if (keywordParamList.size() == 3)
                                                {
                                                    frequency = keywordParamList[0][0];
                                                }
                                                else
                                                {
                                                    this->printMsg(RET_GEN_ERR_INVARG, "The function " + tagFunction + " must have 3 parameters!");
                                                }
                                            }
                                            else if (tagFunction.compare(TAG_DATEPART) == 0)
                                            {
                                                if (keywordParamList.size() == 2)
                                                {
                                                    frequency = keywordParamList[0][0];
                                                }
                                                else
                                                {
                                                    this->printMsg(RET_GEN_ERR_INVARG, "The function " + tagFunction + " must have 2 parameters!");
                                                }
                                            }

                                            if (frequency.empty() == false)
                                            {
                                                if (frequency.compare("dy") == 0 ||
                                                    frequency.compare("dw") == 0 ||
                                                    frequency.compare("dd") == 0)
                                                {
                                                    frequency = "day";
                                                }
                                                if (frequency.compare("weekday") == 0)
                                                {
                                                    frequency = "dayofweek";
                                                }
                                                else if (frequency.compare("ss") == 0)
                                                {
                                                    frequency = "second";
                                                }
                                                else if (frequency.compare("ms") == 0)
                                                {
                                                    frequency = "microsecond";
                                                }
                                                else if ((frequency.compare("quarter") == 0 && tagFunction.compare(TAG_DATEPART) != 0) ||
                                                         frequency.compare("qq") == 0)
                                                {
                                                    frequency = "month";
                                                    interval = "3 * (" + interval + ")";
                                                }
                                                else if (frequency.compare("week") == 0)
                                                {
                                                    frequency = "weekofyear";
                                                }

                                                if (tagFunction.compare(TAG_DATEADD) == 0)
                                                {
                                                    replaceStream << keywordParamList.at(2)[0] << " + (" << interval << " * interval '1 " << frequency << "')";
                                                }
                                                else if (tagFunction.compare(TAG_DATEPART) == 0)
                                                {
                                                    replaceStream << frequency << " from " << keywordParamList.at(1)[0];
                                                }
                                                else if (tagFunction.compare(TAG_DATEDIFF) == 0)
                                                {
                                                    if (frequency == "day")
                                                    {
                                                        replaceStream << "extract(" << frequency << " from (" << keywordParamList.at(2)[0] << " - " << keywordParamList.at(1)[0] << "))";
                                                    }
                                                    else if (frequency == "second")
                                                    {
                                                        replaceStream << "extract(epoch from (" << keywordParamList.at(2)[0] << " - " << keywordParamList.at(1)[0] << "))::int";
                                                    }
                                                    else if (frequency == "microsecond")
                                                    {
                                                        replaceStream << "(extract(epoch from (" << keywordParamList.at(2)[0] << " - " << keywordParamList.at(1)[0] << ")) * 1000)::bigint";
                                                    }
                                                }
                                            }
                                        }
                                        else if (tagFunction.compare(TAG_CHARINDEX) == 0)
                                        {
                                            if (keywordParamList.size() == 2)
                                            {
                                                replaceStream << keywordParamList.at(0)[0] << " in " << keywordParamList[1][0];
                                            }
                                            else
                                            {
                                                this->printMsg(RET_GEN_ERR_INVARG, "The function " TAG_CHARINDEX " have 2 parameters!");
                                            }
                                        }
                                        else if (tagFunction.compare(TAG_MOD) == 0)
                                        {
                                            if (keywordParamList.size() == 2)
                                            {
                                                replaceStream << "(" << keywordParamList[0][0] << " % " << keywordParamList.at(1)[0] << ")";
                                            }
                                            else
                                            {
                                                this->printMsg(RET_GEN_ERR_INVARG, "The function " TAG_MOD " have 2 parameters!");
                                            }
                                        }
                                        break;
                            }

                            if (tagFunction.compare(TAG_GET_ATTRIB_DICT_ID) == 0)
                            {
                                if (keywordParamList.size() == 2)
                                {
                                    OBJECT_ENUM attObjEnt = NullEntity;
                                    if (keywordParamList[0][0].find_first_of("0123456789") == 0)
                                    {
                                        DBA_GetObjectEnum(atoi(keywordParamList[0][0].c_str()), &attObjEnt);
                                    }
                                    else
                                    {
                                        DICT_ENTITY_STP dictEntityStp = DBA_GetEntityBySqlName(keywordParamList[0][0]);
                                        if (dictEntityStp)
                                        {
                                            attObjEnt = dictEntityStp->objectEn;
                                        }
                                    }
                                    DICT_ATTRIB_STP attribStp = DBA_GetAttributeBySqlName(attObjEnt,
                                                                                          keywordParamList.at(1)[0].c_str(),
                                                                                          true);

                                    if (attribStp == NULL)
                                    {
                                        this->printMsg(RET_GEN_ERR_INVARG,
                                                       "Function " TAG_GET_ATTRIB_DICT_ID ": Unknown attribute (" +
                                                       keywordParamList[0][0] + "," + keywordParamList.at(1)[0] + ")");
                                    }
                                    else
                                    {
                                        replaceStream << attribStp->attrDictId;
                                    }
                                }
                                else
                                {
                                    this->printMsg(RET_GEN_ERR_INVARG, "The function " TAG_GET_ATTRIB_DICT_ID " have 2 parameters!");
                                }
                            }
                            else if (tagFunction.compare(TAG_CHECK_DB_OBJECT) == 0 ||
                                     tagFunction.compare(TAG_DROP_DB_OBJECT) == 0)
                            {
                                if (keywordParamList.size() >= 2)
                                {
                                    DDL_OBJ_ENUM ddlObjType = this->getDdlObjEnFromStr(keywordParamList[0][0]);
                                    if (ddlObjType != DdlObj_None)
                                    {
                                        string fullTableName = keywordParamList.at(1)[0];

                                        if (fullTableName[0] == '@')
                                        {
                                            DdlGenVar *tableVar = this->varHelperPtr->getVariable(fullTableName, false);
                                            if (tableVar != nullptr &&
                                                tableVar->getValue().empty() == false)
                                            {
                                                fullTableName = tableVar->getValue();
                                            }
                                        }

                                        vector<string>  tokens;
                                        DdlGen::tokenizeStr(tokens, fullTableName, ".");

                                        string      entitySqlName;
                                        string      database;
                                        string      ddlObjSqlName;
                                        string      userName;

                                        if (tokens.size() == 1)
                                        {
                                            database = this->getDdlGenContextPtr()->getMainDbName();
                                        }
                                        else
                                        {
                                            if (tokens.size() == 3)
                                            {
                                                userName = tokens.at(1);
                                            }
                                            database = tokens[0];
                                        }
                                        entitySqlName = tokens.at(tokens.size() - 1);

                                        if (keywordParamList.size() > 2)
                                        {
                                            ddlObjSqlName = keywordParamList.at(2)[0];
                                        }
                                        else
                                        {
                                            ddlObjSqlName = entitySqlName;
                                        }

                                        if (tagFunction.compare(TAG_CHECK_DB_OBJECT) == 0)
                                        {
                                            replaceStream << this->context->outDdlGenPtr->getCmdSelObjInDb(database,
                                                                                                           entitySqlName,
                                                                                                           ddlObjSqlName,
                                                                                                           ddlObjType,
                                                                                                           userName);
                                        }
                                        else
                                        {
                                            this->setInBlock(true);

                                            stringstream dropFkStream;

                                            if (ddlObjType == DdlObj_Trigger ||
                                                ddlObjType == DdlObj_Index ||
                                                ddlObjType == DdlObj_Constraint)
                                            {
                                                this->getDdlGenContextPtr()->setDdlDestDbName(database, nullptr);

                                                map<DdlObjDefKey, DdlObjDef> ddlObjDefMap;

                                                this->context->outDdlGenPtr->getAllDdlObjListFromDb(ddlObjDefMap,
                                                                                                    database,
                                                                                                    entitySqlName,
                                                                                                    entitySqlName,
                                                                                                    ddlObjType);

                                                for (auto trgIt = ddlObjDefMap.begin(); trgIt != ddlObjDefMap.end(); ++trgIt)
                                                {
                                                    replaceStream <<
                                                        this->context->outDdlGenPtr->getDdlModif(
                                                            this->context->outDdlGenPtr->getCmdDrop(database,
                                                                                                    entitySqlName,
                                                                                                    trgIt->second.getDbObjName(),
                                                                                                    ddlObjType,
                                                                                                    &trgIt->second)) << endl;
                                                }
                                            }
                                            else
                                            {
                                                if (ddlObjType == DdlObj_Column)
                                                {
                                                    map<DdlObjDefKey, DdlObjDef> foreignKeyDefMap;

                                                    this->context->outDdlGenPtr->getAllDdlObjListFromDb(foreignKeyDefMap,
                                                                                                        database,
                                                                                                        entitySqlName,
                                                                                                        entitySqlName,
                                                                                                        DdlObj_ForeignKey);

                                                    for (auto fkIt = foreignKeyDefMap.begin(); fkIt != foreignKeyDefMap.end(); ++fkIt)
                                                    {
                                                        for (auto fkAttIt = fkIt->second.m_refAttributeTab.begin(); fkAttIt != fkIt->second.m_refAttributeTab.end(); ++fkAttIt)
                                                        {
                                                            if (*fkAttIt == ddlObjSqlName)
                                                            {
                                                                dropFkStream << this->context->outDdlGenPtr->getDdlModif(
                                                                    this->context->outDdlGenPtr->getCmdDrop(database,
                                                                                                            entitySqlName,
                                                                                                            fkIt->second.getDbObjName(),
                                                                                                            DdlObj_ForeignKey,
                                                                                                            &fkIt->second,
                                                                                                            fkIt->second.getDbObjName())) << endl;
                                                            }
                                                        }
                                                    }
                                                }

                                                string checkCmd = this->context->outDdlGenPtr->getCmdSelObjInDb(database,
                                                                                                                entitySqlName,
                                                                                                                ddlObjSqlName,
                                                                                                                ddlObjType,
                                                                                                                userName);

                                                replaceStream << this->context->outDdlGenPtr->getCmdIfExsists(checkCmd,
                                                                                                              dropFkStream.str() +
                                                                                                              this->context->outDdlGenPtr->getDdlModif(
                                                                                                                  this->context->outDdlGenPtr->getCmdDrop(database,
                                                                                                                                                          entitySqlName,
                                                                                                                                                          ddlObjSqlName,
                                                                                                                                                          ddlObjType,
                                                                                                                                                          nullptr,
                                                                                                                                                          userName)));
                                            }
                                        }
                                    }
                                    else
                                    {
                                        this->printMsg(RET_GEN_ERR_INVARG, "Unsupported Object Type (" + keywordParamList[0][0] + ") in the function " + tagFunction + " [table|column] !");
                                    }
                                }
                                else
                                {
                                    this->printMsg(RET_GEN_ERR_INVARG, "The function " + tagFunction + " have at least 2 parameters <object type> <object name> [ <sub-object name> ] !");
                                }
                            }
                        }
                    }
                }

                if (tagFunction.compare(TAG_UPDATING) == 0 && currAttribStp != NULL)
                {
                    if (this->dmlEventEn == DmlEvent_Update &&
                        (this->trgPosEn == TriggerPos_AfterEachRow ||
                         this->trgPosEn == TriggerPos_BeforeEachRow))
                    {
                        replaceStream << "(";
                    }

                    bool bUpdating = true;
                    switch (this->ddlGenContextPtr->m_rdbmsEn)
                    {
                        case Sybase:
                        case MSSql:
                            replaceStream << "update(" << currAttribStp->sqlName << ")";
                            break;

                        case Oracle:
                            replaceStream << "updating('" << currAttribStp->sqlName << "')";
                            break;

                        case PostgreSQL:
                            replaceStream << "OLD." << currAttribStp->sqlName << " is distinct from NEW." << currAttribStp->sqlName;
                            break;

                        case Nuodb:
                            bUpdating = false;
                            if (replaceStream.str().empty())
                            {
                                replaceStream << "(";
                            }
                            break;
                    }

                    if (this->dmlEventEn == DmlEvent_Update &&
                        (this->trgPosEn == TriggerPos_AfterEachRow ||
                         this->trgPosEn == TriggerPos_BeforeEachRow ||
                         bUpdating == false))
                    {
                        if (this->dmlEventEn == DmlEvent_Update)
                        {
                            if (bUpdating)
                            {
                                replaceStream << " and ";
                            }
                            replaceStream
                                << "(#NEW." << currAttribStp->sqlName << " != #OLD." << currAttribStp->sqlName;

                            if (currAttribStp->dbMandatoryFlg == FALSE)
                            {
                                replaceStream
                                    << " or (#NEW." << currAttribStp->sqlName << " is not null and #OLD." << currAttribStp->sqlName << " is null)"
                                    << " or (#NEW." << currAttribStp->sqlName << " is null and #OLD." << currAttribStp->sqlName << " is not null)";
                            }
                            replaceStream << ")";
                        }
                        replaceStream << ")";
                    }
                }
                else if (tagFunction.compare(TAG_MAIN_DLM_CHECK) == 0 || tagFunction.compare(TAG_ADD_DLM_CHECK) == 0)
                {
                    if (keywordParamList.size() == 2)
                    {
                        DICT_ENTITY_STP entityStp = DBA_GetEntityBySqlName(keywordParamList.at(1)[0]);

                        if (entityStp != NULL && entityStp->dlmAuthEn == FeatureAuth_Enable)
                        {
                            replaceStream << keywordParamList[0][0] << ".dlm_e <= ";

                            if (this->getOutDdlObjEn() == DdlObj_SProc)
                            {
                                DdlGenVar      *maxVar;

                                if (tagFunction.compare(TAG_MAIN_DLM_CHECK) == 0)
                                    maxVar = this->varHelperPtr->getNewVariable("main_dlm_e_max", EnumType);
                                else
                                    maxVar = this->varHelperPtr->getNewVariable("add_dlm_e_max", EnumType);

                                replaceStream << maxVar->printSqlName();
                            }
                            else
                            {
                                DLM_ENUM dlmEn;

                                if (tagFunction.compare(TAG_MAIN_DLM_CHECK) == 0)
                                {
                                    dlmEn = DBA_GetConnProviderSessionProperties().getMainDlmEnMax();
                                }
                                else
                                {
                                    dlmEn = DBA_GetConnProviderSessionProperties().getAddDlmEnMax();
                                }
                                replaceStream << (int)dlmEn;
                            }
                        }
                        else
                        {
                            replaceStream << " 1=1 ";
                        }
                    }
                    else
                    {
                        this->printMsg(RET_GEN_ERR_INVARG, "The function " TAG_MAIN_DLM_CHECK " have 2 parameters!");
                        replaceStream << " 1=1 ";
                    }
                }
                else
                {
                    switch (this->ddlGenContextPtr->m_rdbmsEn)
                    {
                        case Sybase:
                        case MSSql:
                            if (tagFunction.compare(TAG_LEFT) == 0 ||
                                tagFunction.compare(TAG_RIGHT) == 0 ||
                                tagFunction.compare(TAG_DATEADD) == 0 ||
                                tagFunction.compare(TAG_DATEPART) == 0 ||
                                tagFunction.compare(TAG_DATEDIFF) == 0 ||
                                tagFunction.compare(TAG_CHARINDEX) == 0)
                            {
                                replaceStream << ")";
                            }
                            break;

                        case Oracle:
                            if (tagFunction.compare(TAG_LEFT) == 0 ||
                                tagFunction.compare(TAG_RIGHT) == 0 ||
                                tagFunction.compare(TAG_BITAND) == 0 ||
                                tagFunction.compare(TAG_BITOR) == 0 ||
                                tagFunction.compare(TAG_MOD) == 0 ||
                                tagFunction.compare(TAG_CHARINDEX) == 0)
                            {
                                replaceStream << ")";
                            }
                            break;

                        case Nuodb:
                            if (tagFunction.compare(TAG_LEFT) == 0 ||
                                tagFunction.compare(TAG_RIGHT) == 0 ||
                                tagFunction.compare(TAG_DATEADD) == 0 ||
                                tagFunction.compare(TAG_DATEPART) == 0 ||
                                tagFunction.compare(TAG_DATEDIFF) == 0 ||
                                tagFunction.compare(TAG_CHARINDEX) == 0)
                            {
                                replaceStream << ")";
                            }
                            break;

                        case PostgreSQL:
                            if (tagFunction.compare(TAG_LEFT) == 0 ||
                                tagFunction.compare(TAG_RIGHT) == 0 ||
                                tagFunction.compare(TAG_DATEPART) == 0 ||
                                tagFunction.compare(TAG_CHARINDEX) == 0)
                            {
                                replaceStream << ")";
                            }
                            break;

                    }
                }

                replaceStream << endCmdStr;
                lineToTreat.replace(replacePos, replaceSize, replaceStream.str());
            }
            else
            {
                this->printMsg(RET_GEN_ERR_INVARG, "Syntax error in function #" + tagFunction);
            }
        }
        else
        {
            currPos = replacePos + 1;
        }
    }
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::createSProcHeader()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-11505 - LJE - 110404
**
*************************************************************************/
RET_CODE DdlGenFromFile::createSProcHeader()
{
    /* PMSTA-37374 - LJE - 210416 - Manage stored proc creation through aaa_sql */
    if (SYS_IsSqlMode())
    {
        if (this->context->currTagNat == TagSql_FuncBegin)
        {
            this->outDdlObjEn = DdlObj_Func;
            this->setDdlObjEn(DdlObj_Func);
        }
        else
        {
            this->outDdlObjEn = DdlObj_SProc;
            this->setDdlObjEn(DdlObj_SProc);
        }
        this->newOutDdlGen();
    }

    DictSprocClass &dictSprocSt = this->ddlGenContextPtr->getDictSprocSt();
    vector<string> tokens;
    this->tokenize(tokens);

    if (this->ddlGenContextPtr->getDdlGenMode() == DdlGenMode_Standard)
    {
        bool bTriggerSProc = (dictSprocSt.procActionEn == Trigger);

        if (this->outDdlObjEn == DdlObj_None)
        {
            this->printMsg(RET_GEN_ERR_INVARG, "Unexpected error : " + this->context->currLineStrLTrim);
            return RET_GEN_ERR_INVARG;
        }

        if (tokens.size() <= 1)
        {
            this->printMsg(RET_GEN_ERR_INVARG, "Missing stored procedure name");
            return RET_GEN_ERR_INVARG;
        }
        this->setStdProc();

        this->context->outDdlGenPtr->bManageAuthFlg = false; /* PMSTA-14688 - LJE - 120723 */
        if (tokens.at(1).length() > GET_MAXCHARLEN(LongSysnameType))    /* PMSTA-33077 - DLA - 181011 */
        {
            this->printMsg(RET_GEN_ERR_LENGTH, "The procedure/function name is too long, (" + tokens.at(1) + "), max 30 characters!");
            return RET_GEN_ERR_INVARG;
        }

        /* PMSTA-45413 - LJE - 210806 */
        if (tokens.size() > 1 && tokens.back() == "DEBUG")
        {
            SYS_BreakOnDebug();
            tokens.erase(tokens.end() - 1);
        }

        dictSprocSt.setObjectEn(this->getObjectEn());
        dictSprocSt.sqlName         = tokens.at(1).substr(0, GET_MAXCHARLEN(LongSysnameType));    /* PMSTA-33077 - DLA - 181011 */
        dictSprocSt.dbName          = this->ddlGenContextPtr->getDefDdlDestDbName().substr(0, GET_MAXCHARLEN(SysnameType));    /* PMSTA-33077 - DLA - 181011 */
        if (dictSprocSt.dbName.empty())
        {
            dictSprocSt.dbName = this->ddlGenContextPtr->getMainDbName(true);
        }
        dictSprocSt.executeAsEn     = ExecuteAs_None;
        dictSprocSt.procActionEn    = Custom;
        dictSprocSt.functionFlg     = (this->context->currTagNat == TagSql_FuncBegin ? TRUE : FALSE);

        /* PMSTA-37366 - LJE - 200210 */
        if (bTriggerSProc == false &&
            this->getDictEntityStp() != nullptr && 
            this->ddlGenContextPtr->isProcToGenerate(dictSprocSt.sqlName, this->getDictEntityStp()->mdSqlName) == false)
        {
            return RET_DBA_INFO_EXIST;
        }

        this->outDdlGenSprocPtr->init(false);
        this->outDdlGenSprocPtr->m_bFromPscFile = true;
        this->outDdlGenSprocPtr->m_bCustomBody = true;

        this->removeFromStdProcs(dictSprocSt.sqlName);

        this->setMsgSqlName(dictSprocSt.sqlName);
        this->ddlGenContextPtr->setMsgSqlName(dictSprocSt.sqlName);

        this->setDdlObjEn(DdlObj_SProc);

        this->replaceUsrHint();

        this->setSProcExtraParam(dictSprocSt, tokens);

        if (tokens.size() >= 3 && tokens.at(2) != TAG_END)
        {
            dictSprocSt.procAccessEn = DictSprocClass::getProcAccess(tokens.at(2));
            dictSprocSt.outputDynTypeEn = DynType_Null;
            dictSprocSt.translateFlg = FALSE;

            this->outDdlGenSprocPtr->setSprocParam();

            DBA_DYNTYPE_ENUM paramDynTyp = DynType_Null;
            if (dictSprocSt.procAccessEn == ProcAccess_All)
            {
                paramDynTyp = DynType_All;
            }
            else if (dictSprocSt.procAccessEn == ProcAccess_AllDb)
            {
                paramDynTyp = DynType_AllDb;
            }
            else if (dictSprocSt.procAccessEn == ProcAccess_Short)
            {
                paramDynTyp = DynType_Short;
            }

            if (paramDynTyp != DynType_Null)
            {
                this->ddlGenContextPtr->m_dependsAccessSet.insert(DdlGenDependKey(dictSprocSt.getDictEntityStp()->entDictId, 
                                                                                  dictSprocSt.getDictEntityStp()->mdSqlName, 
                                                                                  DictDependsAccessEn::Parameter, 
                                                                                  paramDynTyp));
            }
        }

        if (this->getSProcExtraParam(dictSprocSt) != RET_SUCCEED ||
            this->setSProcTechParam(dictSprocSt) != RET_SUCCEED)
        {
            return RET_GEN_ERR_INVARG;
        }

        this->ddlGenContextPtr->setDdlDestDbName(dictSprocSt.dbName, this->outDdlGenSprocPtr);
        this->outDdlGenSprocPtr->setDdlObjFullSqlName(dictSprocSt.dbName, dictSprocSt.sqlName);
        this->outDdlGenSprocPtr->drop();
    }
    else
    {
        this->setSProcExtraParam(dictSprocSt, tokens);
    }

    return RET_SUCCEED;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::createSProcStdHeader()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-18593 - LJE - 150422
**
*************************************************************************/
RET_CODE DdlGenFromFile::createSProcStdHeader()
{
    RET_CODE ret = RET_SUCCEED;

    ret = this->createStdSProc();

    if (ret == RET_SUCCEED &&
        this->ddlGenContextPtr->getDdlGenMode() == DdlGenMode_Standard)
    {
        this->ddlGenContextPtr->setDdlDestDbName(this->ddlGenContextPtr->getDictSprocSt().dbName, this->outDdlGenSprocPtr);

        if (this->m_parentDdlGenPtr == nullptr)
        {
            this->outDdlGenSprocPtr->drop();
        }
    }

    return ret;
}
/************************************************************************
**
**  Function    :  DdlGenFromFile::createViewHeader()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-16194 - LJE - 130522
**
*************************************************************************/
RET_CODE DdlGenFromFile::createViewHeader()
{
    vector<string> tokens;

    this->tokenize(tokens);

    if (this->outDdlObjEn == DdlObj_None)
    {
        this->printMsg(RET_GEN_ERR_INVARG, "Unexpected error : " + this->context->currLineStrLTrim);
        return RET_GEN_ERR_INVARG;
    }

    if (tokens.size() <= 3)
    {
        this->printMsg(RET_GEN_ERR_INVARG, "Tag VIEW_BEGIN error: #VIEW_BEGIN <entity_sqlname_c> <view type(vw, uvw, lvw, fkv, mvw, sh, lsv, bvw, null, user)> [END]");
        return RET_GEN_ERR_INVARG;
    }
    this->newOutDdlGen();

    this->context->outDdlGenPtr->setDdlObjSqlName(tokens.at(1));
    this->ddlGenContextPtr->setMsgSqlName(this->context->outDdlGenPtr->getDdlObjSqlName());

    DDL_VIEW_ENUM viewEn = this->context->forcedViewEn == View_None ? this->outDdlGenViewPtr->getViewEnFromStr(tokens.at(2)) : this->context->forcedViewEn;

    switch (viewEn)
    {
        case View_Custom:
            if (this->ddlGenContextPtr->getDdlGenMode() == DdlGenMode_Shadow || this->ddlObjFromFileEn != DdlObjFromFile_SystemView)
            {
                return RET_GEN_INFO_NOACTION;
            }
            break;

        case View_Tech:
            if (this->ddlObjFromFileEn != DdlObjFromFile_SystemView)
            {
                return RET_GEN_INFO_NOACTION;
            }
            break;

        case View_LightAll:
            if (this->ddlObjFromFileEn != DdlObjFromFile_UtilsView)
            {
                return RET_GEN_INFO_NOACTION;
            }
            break;

        case View_Shadow:
            if (this->ddlObjFromFileEn != DdlObjFromFile_UtilsView)
            {
                return RET_GEN_INFO_NOACTION;
            }
            break;

        case View_FullAllSecured:
            if (this->ddlObjFromFileEn == DdlObjFromFile_UtilsView ||
                this->ddlObjFromFileEn == DdlObjFromFile_SystemView)
            {
                return RET_GEN_INFO_NOACTION;
            }
            break;

        case View_None:
            this->printMsg(RET_GEN_ERR_INVARG, "Wrong view type: " + tokens.at(2));
            return RET_GEN_ERR_INVARG;

        default:
            if (this->ddlObjFromFileEn == DdlObjFromFile_SystemView || 
                this->ddlObjFromFileEn == DdlObjFromFile_UtilsView)
            {
                return RET_GEN_INFO_NOACTION;
            }
    }

    if (viewEn == View_Custom &&
        (this->ddlGenContextPtr->getDdlGenMode() == DdlGenMode_Shadow ||
         this->ddlObjFromFileEn != DdlObjFromFile_SystemView))
    {
        return RET_DBA_INFO_EXIST;
    }
    else if (viewEn != View_Custom &&
             this->ddlObjFromFileEn == DdlObjFromFile_SystemView)
    {
        return RET_DBA_INFO_EXIST;
    }

    this->outDdlGenViewPtr->setViewEn(viewEn);
    this->stdViewMap[this->context->outDdlGenPtr->getDdlObjSqlName()] = true;

    if (viewEn == View_Custom &&
        (this->context->outDdlGenPtr->getDdlObjSqlName().compare(this->context->outDdlGenPtr->getDictEntityStp()->mdSqlName)) == 0 &&
        this->context->outDdlGenPtr->getDictEntityStp()->dbRuleEn != DbRule_TableBasedOnView)
    {
        this->printMsg(RET_DBA_INFO_NODATA, "A table based on view must have the entity.db_rule_e set to 7 (Table Based On View)"); // RET_DBA_ERR_INVDATA
    }

    this->context->outDdlGenPtr->bManageAuthFlg = false;

    if (tokens.at(tokens.size() - 1) != TAG_END)
    {
        this->printMsg(RET_GEN_ERR_INVARG, "Missing #END token");
        return RET_GEN_ERR_INVARG;
    }

    this->context->outDdlGenPtr->drop();
    this->context->outDdlGenPtr->printHeader();

    return RET_SUCCEED;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::errorStdSProc()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-11505 - LJE - 110404
**
*************************************************************************/
RET_CODE DdlGenFromFile::errorStdSProc(RET_CODE ret)
{
    if (ret == RET_GEN_ERR_INVARG)
    {
        this->printMsg(RET_GEN_ERR_INVARG, "Tag SPROC_STD error: #SPROC_STD <entity_sqlname_c> <action> <in(all/short/null)> <out(all/short/null)> <access> [<name>] END");
    }
    return ret;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::getDynType()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation    :  PMSTA-11505 - LJE - 110404
**
*************************************************************************/
DBA_DYNTYPE_ENUM DdlGenFromFile::getDynType(const string& dynType)
{
    DBA_DYNTYPE_ENUM dynTypeEn = DynType_Unknown;

    if (this->context == NULL ||
        this->context->outDdlGenPtr == NULL ||
        this->context->outDdlGenPtr->targetTableEn == TargetTable_Main)
    {
        if (dynType.compare("all") == 0)
        {
            dynTypeEn = DynType_All;
        }
        /* PMSTA-26108 - LJE - 170909 */
        else if (dynType.compare("all_db") == 0)
        {
            dynTypeEn = DynType_AllDb;
        }
        else if (dynType.compare("short") == 0)
        {
            dynTypeEn = DynType_Short;
        }
        else if (dynType.compare("other") == 0)
        {
            dynTypeEn = DynType_Other;
        }
        else if (dynType.compare("field_list") == 0)
        {
            dynTypeEn = DynType_FieldList;
        }
        else if (dynType.compare("null") == 0)
        {
            dynTypeEn = DynType_Null;
        }
        else if (dynType.compare("udf") == 0)
        {
            dynTypeEn = DynType_UdOnly;
        }
        else if (dynType.compare("me_spec") == 0)
        {
            dynTypeEn = DynType_MeSpecOnly;
        }
        else if (dynType.compare("ud_me_spec") == 0)
        {
            dynTypeEn = DynType_UdMeSpecOnly;
        }
        else if (dynType.compare("all_db_with_ud") == 0)
        {
            dynTypeEn = DynType_AllDbWithUd;
        }
        /* PMSTA-nuodb - LJE - 190528 */
        else if (dynType.compare("full") == 0)
        {
            dynTypeEn = DynType_Full;
        }
        else if (dynType.compare("full_db") == 0)
        {
            dynTypeEn = DynType_FullDb;
        }
        else if (dynType.compare("short_all_db") == 0)
        {
            dynTypeEn = DynType_ShortAllDb;
        }
        else if (dynType.compare("std") == 0 &&
                 this->getOutDdlObjEn() == DdlObj_View)
        {
            switch (this->ddlGenContextPtr->getViewEn())
            {
                case View_ShortSecured:
                    dynTypeEn = DynType_ShortAllDb;
                    break;

                case View_FullAllSecured:
                case View_FullAll:
                case View_FullAll4ForeignKey:
                case View_AllSecured:
                case View_Export:
                case View_LightAll:
                    dynTypeEn = DynType_All;
                    break;

                default:
                    this->printMsg(RET_GEN_ERR_INVARG, "Keyword #" + (this->context ? this->context->currTag : "N/A") + ": Unknown structure definition (" + dynType + ")");
                    break;
            }
        }
        else
        {
            this->printMsg(RET_GEN_ERR_INVARG, "Keyword #" + (this->context ? this->context->currTag : "N/A") + ": Unknown structure definition (" + dynType + ")");
        }
    }
    else if (this->context->outDdlGenPtr->targetTableEn == TargetTable_UserDefinedFields)
    {
        if (dynType.compare("all") == 0 ||
            dynType.compare("all_db") == 0)
        {
            dynTypeEn = DynType_UdOnly;
        }
        else if (dynType.compare("null") == 0)
        {
            dynTypeEn = DynType_Null;
        }
        /* PMSTA-nuodb - LJE - 190528 */
        else if (dynType.compare("full") == 0)
        {
            dynTypeEn = DynType_Full;
        }
        else if (dynType.compare("full_db") == 0)
        {
            dynTypeEn = DynType_FullDb;
        }
        else
        {
            this->printMsg(RET_GEN_ERR_INVARG, "Keyword #" + this->context->currTag + ": Unknown structure definition (" + dynType + ") (user defined fields)");
        }
    }
    else if (this->context->outDdlGenPtr->targetTableEn == TargetTable_Precomp)
    {
        if (dynType.compare("all") == 0 ||
            dynType.compare("all_db") == 0)
        {
            dynTypeEn = DynType_PrecompOnly;
        }
        else if (dynType.compare("null") == 0)
        {
            dynTypeEn = DynType_Null;
        }
        /* PMSTA-nuodb - LJE - 190528 */
        else if (dynType.compare("full") == 0)
        {
            dynTypeEn = DynType_Full;
        }
        else if (dynType.compare("full_db") == 0)
        {
            dynTypeEn = DynType_FullDb;
        }
        else
        {
            this->printMsg(RET_GEN_ERR_INVARG, "Keyword #" + this->context->currTag + ": Unknown structure definition (" + dynType + ") (precomputed fields)");
        }
    }

    return dynTypeEn;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::getSProcExtraParam()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-11505 - LJE - 110404
**
*************************************************************************/
RET_CODE DdlGenFromFile::getSProcExtraParam(DictSprocClass &dictSprocSt)
{
    list<DdlSprocParam> extraParamList;

    bool bOneDefault = false;
    for (list<string>::iterator it = this->outDdlGenSprocPtr->extraParamList.begin(); it != this->outDdlGenSprocPtr->extraParamList.end(); it++)
    {
        string           paramName, paramType, paramDefVal;
        vector<string>   tokens;
        bool             bOutput = false, bNot = false, bNull = true, bRemove = false;
        DdlSprocParam   *sprocParam;

        this->context->currLineStrLTrim = *it;
        this->context->currLineStr = *it;

        this->tokenize(tokens, " \t=");

        for (auto info = tokens.begin(); info != tokens.end(); info++)
        {
            if (info->at(0) == '@')
            {
                paramName = info->substr(1);
            }
            else if (info->at(0) == '-')
            {
                paramName = info->substr(1);
                bRemove = true;
            }
            else if (info->compare("output") == 0)
            {
                bOutput = true;
            }
            else if (info->compare("not") == 0)
            {
                bNot = true;
            }
            else if (info->compare("null") == 0 && bNot)
            {
                bNull = false;
            }
            else if (info->compare("default") == 0)
            {
                continue;
            }
            else if (paramName.empty())
            {
                paramName = *info;
            }
            else if (paramName.compare("all") == 0)
            {
                if (paramDefVal.empty())
                {
                    paramDefVal = *info;
                }
                else
                {
                    /* Unknown info */
                    this->printMsg(RET_GEN_ERR_INVARG, "Unknown line in parameters: " + this->context->currLineStrLTrim);
                }
            }
            else if (paramType.empty())
            {
                paramType = *info;
            }
            else if (paramDefVal.empty())
            {
                bOneDefault = true;
                paramDefVal = *info;
            }
            else
            {
                /* Unknown info */
                this->printMsg(RET_GEN_ERR_INVARG, "Unknown line in parameters: " + this->context->currLineStrLTrim);
            }
        }

        if (bOneDefault && paramDefVal.empty() && bOutput == false)
        {
            this->printMsg(RET_GEN_ERR_INVARG, "Input parameters after one with a default value must also have defaults");
        }

        if (bRemove)
        {
            this->varHelperPtr->removeParameter(paramName);

            SMALLINT_T newRank = 0;
            for (auto paramIt = dictSprocSt.m_paramProcAttribVector.begin(); paramIt != dictSprocSt.m_paramProcAttribVector.end(); ++paramIt, ++newRank)
            {
                if (paramIt->m_sqlName.compare(paramName) == 0)
                {
                    paramIt = dictSprocSt.m_paramProcAttribVector.erase(paramIt);

                    if (paramIt == dictSprocSt.m_paramProcAttribVector.end())
                    {
                        break;
                    }
                }
                paramIt->rank = newRank;
            }
            continue;
        }

        DICT_ATTRIB_STP paramAttribStp = DBA_GetAttributeBySqlName(this->getObjectEn(), paramName.c_str(), TRUE);

        if (paramName.compare("all") == 0)
        {
            for (DdlGenParamIter it2 = this->varHelperPtr->getParamList()->begin(); it2 != this->varHelperPtr->getParamList()->end(); it2++)
            {
                (*it2)->strDefault = paramDefVal;
            }
        }
        else
        {
            if (paramType.empty())
            {
                if (paramAttribStp == NULL)
                {
                    this->printMsg(RET_GEN_ERR_INVARG, "Unknown line in parameters: " + this->context->currLineStrLTrim);
                    continue;
                }
                paramType = DBA_GetDictDataTpStp(paramAttribStp->dataTpProgN)->sqlName;
            }

            if (paramName.length() > GET_MAXCHARLEN(SysnameType))
            {
                this->printMsg(RET_GEN_ERR_LENGTH, "The parameter name is too long, (" + paramName + "), max 30 characters!");
                return RET_GEN_ERR_INVARG;
            }

            if ((sprocParam = this->varHelperPtr->getParameter(paramName)) == NULL)
            {
                DdlSprocParam extraParam(dictSprocSt, this->ddlGenContextPtr->m_rdbmsEn);

                if ((paramAttribStp != nullptr && paramAttribStp->dbMandatoryFlg == TRUE) || bNull == false)
                {
                    extraParam.bNullable = false;
                }
                else
                {
                    extraParam.bNullable = true;
                }

                extraParam.setOut(bOutput);

                if (paramType.empty() == false)
                {
                    extraParam.setDataTypeSqlName(paramType);
                    if (extraParam.getDataType() == NullDataType)
                    {
                        this->printMsg(RET_GEN_ERR_INVARG, "Unknown data-type '" + paramType + "' in parameters line:" + this->context->currLineStrLTrim);
                        continue;
                    }
                }

                extraParam.sqlName    = paramName;
                extraParam.strDefault = paramDefVal;
                extraParam.varType    = VarType_ExtraParamter;

                extraParamList.push_back(extraParam);
            }
            else
            {
                sprocParam->setIn(true);
                sprocParam->setOut(bOutput);

                if (sprocParam->bNullable && bNull == false)
                {
                    sprocParam->bNullable = bNull;
                }

                if (paramDefVal.empty() == false)
                {
                    sprocParam->strDefault = paramDefVal;
                }

                for (auto paramIt = dictSprocSt.m_paramProcAttribVector.begin(); paramIt != dictSprocSt.m_paramProcAttribVector.end(); ++paramIt)
                {
                    if (paramIt->m_sqlName == sprocParam->sqlName)
                    {
                        paramIt->outputFlg = bOutput;
                        break;
                    }
                }
            }

            if (paramName.compare("codif_id") == 0 && this->ddlGenContextPtr->ddlGenAction.m_installLevel <= 5)
            {
                dictSprocSt.synonymFlg = TRUE;
            }

            if (paramName.compare("language_dict_id") == 0)
            {
                dictSprocSt.translateFlg = TRUE;
            }
        }
    }

    if (dictSprocSt.isBatchAllowed(this->ddlGenContextPtr->m_rdbmsEn))
    {
        DdlSprocParam  extraParam(dictSprocSt, this->ddlGenContextPtr->m_rdbmsEn);

        extraParam.setDataType(IntType);
        extraParam.strDefault = "null";
        extraParam.sqlName = DictSprocClass::getBatchRowNumName();
        extraParam.setOut(false);
        extraParam.setIn(true);

        extraParamList.push_back(extraParam);
    }

    /* PMSTA-43367 - LJE - 210423 */
    if (dictSprocSt.m_storedProcAccessVector.empty() == false &&
        extraParamList.empty() == false)
    {
        vector<bool> mandatoryParamVector;
        
        for (auto storedAccessIt = dictSprocSt.m_storedProcAccessVector.begin(); storedAccessIt != dictSprocSt.m_storedProcAccessVector.end(); ++storedAccessIt)
        {
            if ((*storedAccessIt)->procParamDefPtr != nullptr && (*storedAccessIt)->subObj != DBA_ROLE_EXTERNAL_USE)
            {
                for (size_t i = 0; (*storedAccessIt)->procParamDefPtr[i].fldNbrPtr != nullptr; ++i)
                {
                    if (mandatoryParamVector.size() <= i)
                    {
                        mandatoryParamVector.push_back(true);
                    }

                    if (mandatoryParamVector[i] && (*storedAccessIt)->procParamDefPtr[i].mandatFlg == FALSE)
                    {
                        mandatoryParamVector[i] = false;
                    }
                }
            }
        }

        if (extraParamList.size() == mandatoryParamVector.size())
        {
            int i = 0;
            for (list<DdlSprocParam>::iterator paramIt = extraParamList.begin(); paramIt != extraParamList.end(); ++paramIt, ++i)
            {
                if (paramIt->bNullable)
                {
                    paramIt->bNullable = (mandatoryParamVector[i] == false);
                }
            }
        }
    }

    this->varHelperPtr->setExtraParam(extraParamList);

    SMALLINT_T paramRank = static_cast<SMALLINT_T>(dictSprocSt.m_paramProcAttribVector.size());
    for (list<DdlSprocParam>::iterator paramIt = extraParamList.begin(); paramIt != extraParamList.end(); ++paramIt)
    {
        DictSprocParamClass procParam(paramIt->sqlName, paramIt->getDataType());

        procParam.rank = paramRank++;
        procParam.outputFlg = paramIt->isOut() ? TRUE : FALSE;
        procParam.inputFlg = paramIt->isIn() ? TRUE : FALSE;
        procParam.defaultValueC = paramIt->strDefault;

        dictSprocSt.m_paramProcAttribVector.push_back(procParam);
    }

    return RET_SUCCEED;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::setSProcTechParam()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-37366 - LJE - 200214
**
*************************************************************************/
RET_CODE DdlGenFromFile::setSProcTechParam(DictSprocClass &dictSprocSt)
{
    if (dictSprocSt.isBatchAllowed(this->ddlGenContextPtr->m_rdbmsEn) ||
        this->varHelperPtr->isAllParamKept() == false)
    {
        string       idStr("null"), rowVersionStr("null");
        stringstream batchModeStream;
        bool         bBatchMode = false;

        auto    paramList = this->varHelperPtr->getParamList();
        string  cursorName = SYS_Stringer(dictSprocSt.sqlName, "_cur");

        for (auto paramIt = paramList->begin(); paramIt != paramList->end(); ++paramIt)
        {
            if (this->varHelperPtr->isAllParamKept() == false)
            {
                (*paramIt)->varType = VarType_OverParameter;
                (*paramIt)->setCursorName(cursorName);

                if ((*paramIt)->isOut())
                {
                    (*paramIt)->m_bModify = true;
                }
            }

            if ((*paramIt)->isOut())
            {
                if ((*paramIt)->getDataType() == IdType ||
                    (*paramIt)->getDataType() == DictType)
                {
                    idStr = "@" + (*paramIt)->sqlName;
                }
                else if ((*paramIt)->getDataType() == TimeStampType)
                {
                    rowVersionStr = "@" + (*paramIt)->sqlName;
                }

                bBatchMode = true;
            }
        }

        if (bBatchMode)
        {
            if (this->varHelperPtr->isAllParamKept())
            {
                batchModeStream << endl
                    << "#IF @" << DictSprocClass::getBatchRowNumName() << " is not null" << endl
                    << "#{" << endl
                    << "\tinsert into #batch_output (row_num_n, id, row_version) values (@" 
                    << DictSprocClass::getBatchRowNumName() << ", " 
                    << idStr << ", " 
                    << rowVersionStr << ")" << this->context->outDdlGenPtr->endOfCmd() << endl
                    << "#}";
            }
            else
            {
                batchModeStream << endl
                    << "insert into #batch_output (row_num_n, id, row_version) values (@" 
                    << DictSprocClass::getBatchRowNumName() << ", " 
                    << idStr << ", " 
                    << rowVersionStr << ")" << this->context->outDdlGenPtr->endOfCmd() << endl;
            }
            this->m_atReturnStream << this->buildScript(batchModeStream.str());
        }
    }

    return RET_SUCCEED;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::setSProcExtraParam()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-11505 - LJE - 110404
**
*************************************************************************/
RET_CODE DdlGenFromFile::setSProcExtraParam(DictSprocClass &dictSprocSt, const vector<string>&  tokens)
{
    bool              bTagEnd;
    string            paramName, paramType, paramDefVal;
    string::size_type begType, endType;
    list<DdlSprocParam> extraParamList;
    bool                bOnInit = false;

    if (tokens.at(tokens.size() - 1).compare(TAG_END) != 0)
    {
        bTagEnd = false;
        while (bTagEnd == false && this->getGenSqlLine())
        {
            if (this->context->currLineStrLTrim.size() == 0)
                continue;

            if (this->isTag(TAG_SPROC_END) || this->isTag(TAG_END))
            {
                bTagEnd = true;
                continue;
            }

            if (this->ddlGenContextPtr->getDdlGenMode() != DdlGenMode_Standard)
                continue;

            if (this->isTag(TAG_EXECUTE_AS_OWNER))
            {
                dictSprocSt.executeAsEn = ExecuteAs_Owner;
                continue;
            }
            if (this->isTag(TAG_EXECUTE_AS_CALLER))
            {
                dictSprocSt.executeAsEn = ExecuteAs_Caller;
                continue;
            }
            if (this->isTag(TAG_EXECUTE_AS_LOGIN_MANAGER))
            {
                dictSprocSt.executeAsEn = ExecuteAs_LoginManager;
                continue;
            }
            if (this->isTag(TAG_EXECUTE_AS_WM_TECH))
            {
                dictSprocSt.executeAsEn = ExecuteAs_WmTech;
                continue;
            }
            if (this->isTag(TAG_DETERMINISTIC))
            {
                dictSprocSt.bDeterministic = true;
                continue;
            }
            if (this->isTag(TAG_NO_DETERMINISTIC))
            {
                dictSprocSt.bDeterministic = false;
                continue;
            }
            /* PMSTA-38987 - LJE - 200214 */
            if (this->isTag(TAG_WITH_RECOMPILE))
            {
                if (this->ddlGenContextPtr->getCfgFileHelper().getPropertyBoolOrDefValue("STORED_PROC_WITH_RECOMPILE", false) == true)
                {
                    dictSprocSt.bWithRecomplie = true;
                }
                continue;
            }
            if (this->isTag(TAG_PRIVATE))
            {
                dictSprocSt.executeAsEn = ExecuteAs_Private;
                continue;
            }
            if (this->isTag(TAG_ON_EACH_DATABASE))
            {
                /* PMSTA-45027 - LJE - 210527 */
                if (this->ddlGenContextPtr->bGenFromDbi == false &&
                    this->ddlGenContextPtr->ddlGenAction.m_installLevel < 99)
                {
                    dictSprocSt.bOnEachDatabase = true;
                }
                continue;
            }
            if (this->isTag(TAG_USE))
            {
                vector<string>  locTokens;
                this->tokenize(locTokens);
                if (locTokens.size() > 1)
                {
                    dictSprocSt.dbName = locTokens.at(1).substr(0, GET_MAXCHARLEN(SysnameType));  /* PMSTA-33077 - DLA - 181011 */
                }
                else
                {
                    this->printMsg(RET_GEN_ERR_INVARG, "Syntax error in script: keyword #USE");
                }
                continue;
            }
            if (this->isTag(TAG_RETURNS))
            {
                begType = this->context->currLineStrLTrim.find_first_not_of(" \t", strlen(TAG_RETURNS) + 1);
                if (begType == string::npos)
                    continue;
                endType = this->context->currLineStrLTrim.find_first_of(" \t=", begType);
                paramType = this->context->currLineStrLTrim.substr(begType, endType - begType);
                dictSprocSt.retDataType = DBA_GetDatatypeEnumByCode(paramType.c_str());
                continue;
            }
            if (this->isTag(TAG_AUTONOMOUS_TRANSACTION))  /* PMSTA-20494 - TEB - 160808 */
            {
                this->ddlGenContextPtr->bAutonomousTransaction = true;
                continue;
            }
            if (this->isTag(TAG_DISABLE_CHANGE_SET))
            {
                this->ddlGenContextPtr->bDisableChangeSet = true;
                continue;
            }
            if (this->isTag(TAG_INIT))
            {
                this->ddlGenContextPtr->m_initSqlBlock.declareStream() << endl;

                bOnInit = true;
                continue;
            }
            if (this->isTag(TAG_NOT_EXISTS))
            {
                this->ddlGenContextPtr->bIfNotExists = true;
                continue;
            }

            /* Remove comments */
            if (this->context->currLineStrLTrim.find("/*") == 0 ||
                this->context->currLineStrLTrim.find("--") == 0)
            {
                continue;
            }

            if (bOnInit)
            {
                this->ddlGenContextPtr->m_initSqlBlock.initStream() << this->context->currLineStr << endl;
            }
            else
            {
                this->outDdlGenSprocPtr->extraParamList.push_back(this->context->currLineStrLTrim);
            }
        }

        if (bOnInit)
        {
            this->ddlGenContextPtr->m_initSqlBlock.initStream() << endl;
        }

        if (bTagEnd == false)
        {
            string msg = "Missing end tag (#END)";
            this->printMsg(RET_GEN_ERR_INVARG, msg);

            return RET_GEN_ERR_INVARG;
        }
    }

    return RET_SUCCEED;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::createSProcGet()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-18593 - LJE - 151114
**
*************************************************************************/
RET_CODE DdlGenFromFile::createSProcGet()
{
    RET_CODE        ret = RET_SUCCEED;
    int             fixedParam = 0;
    stringstream    sqlCmdStream;

    vector<vector<string>> keywordParamList;
    this->extractKeywordParam(this->context->currTag, fixedParam, keywordParamList, true, true);

    sqlCmdStream << "select '++VAR++' as \"get_variable\"";

    for (vector<vector<string>>::iterator paramIt = keywordParamList.begin(); paramIt != keywordParamList.end(); paramIt++)
    {
        vector<string> keywordParam = *paramIt;
        DdlGenVar *currVar = this->varHelperPtr->getVariable(keywordParam[0].substr(1));

        if (currVar != NULL)
        {
            int rank = 0;
            DdlGenVar *concatVar = currVar;

            while (concatVar != NULL)
            {
                stringstream concatStr;
                concatStr << "$" << rank++;
                concatVar = this->varHelperPtr->getVariable(currVar->sqlName + concatStr.str(), false);
                if (concatVar != NULL)
                {
                    sqlCmdStream << ", " << concatVar->printSqlName(DdlGenVar::KindOfPrint::Name, true) << " as \"" << concatVar->sqlName << "\"";
                }
            }
            sqlCmdStream << ", " << currVar->printSqlName(DdlGenVar::KindOfPrint::Name, true) << " as \"" << currVar->sqlName << "\"";
        }
    }

    sqlCmdStream << " " << this->context->outDdlGenPtr->getEmptyFrom() << this->context->outDdlGenPtr->getCmdEndOfCmd();

    this->context->outDdlGenPtr->bodySqlBlock << this->context->outDdlGenPtr->prepareResultSet(sqlCmdStream, *this->context->outDdlGenPtr);
    this->context->outDdlGenPtr->bodySqlBlock << sqlCmdStream.str();

    return ret;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::createSProcSet()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-18593 - LJE - 151114
**
*************************************************************************/
RET_CODE DdlGenFromFile::createSProcSet()
{
    RET_CODE        ret = RET_SUCCEED;
    vector<string>  tokens;

    this->tokenize(tokens);

    if (tokens.size() == 3)
    {
        DdlGenString command = lower(tokens.at(1));
        DdlGenString firstArg = lower(tokens.at(2));

        if (command.compare("dateformat") == 0)
        {
            if (firstArg.compare("dmy") == 0)
            {
                this->inDateTimeStyleEn = DateStyle_DdMmYyyy;
            }
            else if (firstArg.compare("mdy") == 0)
            {
                this->inDateTimeStyleEn = DateStyle_MmDdYyyy;
            }
            else if (firstArg.compare("ymd") == 0)
            {
                this->inDateTimeStyleEn = DateStyle_YyyyMmDd24;
            }
            else if (firstArg.compare("ydm") == 0)
            {
                this->inDateTimeStyleEn = DateStyle_YyyyDdMm24;
            }
            else if (firstArg.compare("myd") == 0)
            {
                this->inDateTimeStyleEn = DateStyle_MmYyyyDd24;
            }
            else if (firstArg.compare("dym") == 0)
            {
                this->inDateTimeStyleEn = DateStyle_DdYyyyMm24;
            }
            else if (firstArg.compare("iso") == 0)
            {
                this->inDateTimeStyleEn = DateStyle_YyyyMmDd24;
            }
            else
            {
                ret = RET_DBA_ERR_INVDATA;
            }
        }
        else if (command.compare("datestyle") == 0)
        {
            if (firstArg.compare("mdy") == 0 ||
                firstArg.compare("1") == 0)
            {
                this->outDateTimeStyleEn = DateStyle_MmDdYyyy;
            }
            else if (firstArg.compare("dmy") == 0 ||
                     firstArg.compare("3") == 0)
            {
                this->outDateTimeStyleEn = DateStyle_DdMmYyyy;
            }
            else if (firstArg.compare("101") == 0)
            {
                this->outDateTimeStyleEn = DateStyle_MmDdYy;
            }
            else if (firstArg.compare("103") == 0)
            {
                this->outDateTimeStyleEn = DateStyle_DdMmYy;
            }
            else if (firstArg.compare("40") == 0)
            {
                this->outDateTimeStyleEn = DateStyle_YyyyMmDd24;
            }
            else if (firstArg.compare("iso") == 0)
            {
                this->outDateTimeStyleEn = DateStyle_Iso;
            }
            else
            {
                ret = RET_DBA_ERR_INVDATA;
            }
        }
        else if (command.compare("nocount") == 0)
        {
            if (firstArg.compare("on") == 0)
            {
                this->bPrintRowCount = false;
            }
            else if (firstArg.compare("off") == 0)
            {
                this->bPrintRowCount = true;
            }
            else
            {
                ret = RET_DBA_ERR_INVDATA;
            }
        }
        else if (command.compare("serveroutput") == 0)
        {
            if (firstArg.compare("on") == 0)
            {
                this->bServerOutput = true;
            }
            else if (firstArg.compare("off") == 0)
            {
                this->bServerOutput = false;
            }
            else
            {
                ret = RET_DBA_ERR_INVDATA;
            }
        }
        else if (command.compare("autocommit") == 0)
        {
            if (firstArg.compare("on") == 0)
            {
                this->bAutoCommit = true;
            }
            else if (firstArg.compare("off") == 0)
            {
                this->bAutoCommit = false;
            }
            else
            {
                ret = RET_DBA_ERR_INVDATA;
            }
        }
        else if (command.compare("keepconnection") == 0)
        {
            if (firstArg.compare("on") == 0)
            {
                this->bKeepConnection = true;
            }
            else if (firstArg.compare("off") == 0)
            {
                this->bKeepConnection = false;
            }
            else
            {
                ret = RET_DBA_ERR_INVDATA;
            }
        }
        else if (command.compare("optimisationlevel") == 0 ||
                 command.compare("optimizationlevel") == 0)
        {
            if (firstArg.empty() == false &&
                firstArg.find_first_not_of(DDLGEN_NUMERIC) == string::npos)
            {
                this->optimLevel = atoi(firstArg.c_str());
            }
            else
            {
                ret = RET_DBA_ERR_INVDATA;
            }
        }
        else if (command.compare("keepdata") == 0)
        {
            if (firstArg.compare("on") == 0)
            {
                this->bKeepData = true;
            }
            else if (firstArg.compare("off") == 0)
            {
                this->bKeepData = false;
            }
            else
            {
                ret = RET_DBA_ERR_INVDATA;
            }
        }
        else if (command.compare("keepresultsetdata") == 0)
        {
            if (firstArg.compare("on") == 0)
            {
                this->bKeepResultSetData = true;
            }
            else if (firstArg.compare("off") == 0)
            {
                this->bKeepResultSetData = false;
            }
            else
            {
                ret = RET_DBA_ERR_INVDATA;
            }
        }
        else if (command.compare("business_entity") == 0)
        {
            this->ddlGenContextPtr->connBusinessEntity = tokens.at(2);
        }
        else if (command.compare("maxscale") == 0)
        {
            this->maxScale = atoi(tokens.at(2).c_str());
        }
        else if (command.compare("rowcount") == 0)
        {
            this->rowCount = atoi(tokens.at(2).c_str());
        }
        else if (command.compare("onerror") == 0)
        {
            if (firstArg.compare("exit") == 0)
            {
                this->onErrorRuleEn = OnErrorRuleEn::Exit;
            }
            else if (firstArg.compare("log") == 0)
            {
                this->onErrorRuleEn = OnErrorRuleEn::Log;
            }
            else if (firstArg.compare("hide") == 0)
            {
                this->onErrorRuleEn = OnErrorRuleEn::Hide;
            }
            else
            {
                ret = RET_DBA_ERR_INVDATA;
            }
        }
        else if (command.compare("modif_stat_mask") == 0)
            {
                if (firstArg.empty() == false &&
                    firstArg.find_first_not_of(DDLGEN_NUMERIC) == string::npos)
                {
                    EV_TableAndObjectModifFlag = atoi(firstArg.c_str());
                }
                else
                {
                    ret = RET_DBA_ERR_INVDATA;
                }
                }
        else
        {
            ret = RET_GEN_INFO_NOACTION;
        }
    }
    else
    {
        ret = RET_GEN_INFO_NOACTION;
    }

    if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
    {
        this->printMsg(ret, "Unsupported 'set' parameters : " + this->context->currLineStrLTrim);
    }
    else if (ret != RET_SUCCEED)
    {
        this->context->outDdlGenPtr->bodySqlBlock << this->context->currLineStrLTrim.substr(1) << endl;
    }

    return ret;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::createStdSProc()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-11505 - LJE - 110404
**
*************************************************************************/
RET_CODE DdlGenFromFile::createStdSProc()
{
    RET_CODE        ret = RET_SUCCEED;
    vector<string>  tokens;

    if (this->getDdlGenContextPtr()->ddlGenAction.m_bSystemFuncOnly == true)
    {
        return RET_SUCCEED;
    }

    this->setStdProc();

    this->tokenize(tokens);

    this->context->pscStream.clear();
    this->context->pscStream.str(string());

    /* Format: <action> <dyn nature> <access> */
    if (tokens.size() < STDP_ACCESS)
    {
        return this->errorStdSProc(RET_GEN_ERR_INVARG);
    }

    DictSprocClass &dictSprocSt = this->ddlGenContextPtr->getDictSprocSt();

    /* PMSTA-29956 - LJE - 180125 */
    if (this->context->currTagNat == TagSql_SProcStdBegin)
    {
        this->outDdlGenSprocPtr->m_bCustomBody = true;
    }
    this->outDdlGenSprocPtr->m_bFromPscFile = true;

    dictSprocSt.dbName       = this->ddlGenContextPtr->getDefDdlDestDbName().substr(0, GET_MAXCHARLEN(SysnameType));  /* PMSTA-33077 - DLA - 181011 */
    dictSprocSt.translateFlg = FALSE;
    dictSprocSt.synonymFlg   = FALSE;
    dictSprocSt.executeAsEn  = ExecuteAs_None;
    dictSprocSt.functionFlg  = FALSE;
    dictSprocSt.bStdProc     = true;

    if (tokens.at(tokens.size() - 1).compare(TAG_END) != 0)
    {
        this->setSProcExtraParam(dictSprocSt, tokens);
    }

    if (tokens.size() > STDP_NAME &&
        tokens.at(STDP_NAME).compare(TAG_END) != 0)
    {
        dictSprocSt.sqlName = tokens.at(STDP_NAME);
    }
    else
    {
        dictSprocSt.sqlName.clear();
    }

    this->ddlGenContextPtr->setMsgSqlName(dictSprocSt.sqlName);

    /* PMSTA-37366 - LJE - 200210 */
    if (this->ddlGenContextPtr->isProcToGenerate(dictSprocSt.sqlName, this->getDictEntityStp()->mdSqlName) == false)
    {
        return RET_DBA_INFO_EXIST;
    }

    dictSprocSt.setObjectEn(this->getObjectEn());
    dictSprocSt.outputObjectEn  = NullEntity;
    dictSprocSt.inputObjectEn   = NullEntity;
    dictSprocSt.outputDynTypeEn = this->getDynType(tokens.at(STDP_OUT_STRUCT));
    dictSprocSt.procAccessEn    = DictSprocClass::getProcAccess(tokens.at(STDP_ACCESS));
    dictSprocSt.procActionEn    = DictSprocClass::getProcAction(tokens.at(STDP_ACTION));
    dictSprocSt.role            = UNUSED; /* PMSTA-14452 - LJE - 121102 */

    if (dictSprocSt.procAccessEn == ProcAccess_UdField)
    {
        dictSprocSt.procAccessEn = ProcAccess_PrimaryKey;
        dictSprocSt.role = DBA_ROLE_UPD_UD_FIELDS;
    }

    if (dictSprocSt.procActionEn == NullAction)
    {
        return this->errorStdSProc(RET_GEN_ERR_INVARG);
    }

    this->outDdlGenSprocPtr->init(true);
    this->outDdlGenSprocPtr->setDdlObjEn(DdlObj_SProc);

    this->getSProcExtraParam(dictSprocSt);

    ret = this->outDdlGenSprocPtr->build();

    this->setSProcTechParam(dictSprocSt);

    this->removeFromStdProcs(dictSprocSt.sqlName);

    this->context->pscStream.clear();
    this->context->pscStream.str(string());
    return ret;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::createSprocExternalEntity()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-26108 - LJE - 171101
**
*************************************************************************/
RET_CODE DdlGenFromFile::createSprocExternalEntity()
{
    RET_CODE ret = RET_SUCCEED;

    vector<string>  tokens;

    this->treatGenSqlLine();
    this->context->currLineStrLTrim = this->context->currLineStr;
    this->tokenize(tokens);

    if (tokens.size() < 2)
    {
        this->printMsg(RET_GEN_ERR_INVARG, "Keyword #" + this->context->currTag + ": Invalid argument");
        return RET_GEN_ERR_INVARG;
    }

    string entitySqlName = tokens.at(1);
    string dbSqlName;

    if (tokens.size() > 2)
    {
        dbSqlName = "." + tokens.at(2);
    }

    this->createVirtualEntity(dbSqlName + entitySqlName);

    return ret;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::createVirtualEntity()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-37366 - LJE - 200619
**
*************************************************************************/
DICT_ENTITY_STP DdlGenFromFile::createVirtualEntity(const std::string &fullSqlName)
{
    vector<string>  tokens;
    DdlGen::tokenizeStr(tokens, fullSqlName, ".");

    OBJECT_ENUM locObjectEn = NullEntity;
    string      entitySqlName;
    string      dbName;

    if (tokens.size() == 1)
    {
        dbName = this->getDdlGenContextPtr()->getMainDbName();
        entitySqlName = tokens[0];
    }
    else
    {
        dbName = tokens[0];
        entitySqlName = tokens.at(tokens.size() - 1);
    }

    DICT_ENTITY_STP dictEntityStp = DBA_GetEntityBySqlName(entitySqlName);
    if (dictEntityStp == nullptr)
    {
        DICT_CreateVirtualEntity(&locObjectEn,
                                 entitySqlName.c_str(),
                                 entitySqlName.c_str(),
                                 this->context->outDdlGenPtr->getEntityDbSqlName(nullptr, entitySqlName.c_str()).c_str(),
                                 nullptr);

        dictEntityStp = DBA_GetDictEntitySt(locObjectEn);
        dictEntityStp->databaseName = dbName;
        dictEntityStp->entNatEn = EntityNat_Internal;
    }

    return dictEntityStp;
}

/************************************************************************
**
**  Function    :   DdlGenFromFile::createSProcGenLoop()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26250 - LJE - 170418
**
*************************************************************************/
RET_CODE DdlGenFromFile::createSProcGenLoop()
{
    RET_CODE               ret = RET_SUCCEED;

    vector<string>         tokens;
    vector<vector<string>> keywordParamList;
    stringstream           loopScptStream;

    this->tokenize(tokens);

    if (tokens.size() < 2)
    {
        this->printMsg(RET_GEN_ERR_INVARG, "Keyword #" + this->context->currTag + ": Syntax error, need at least 1 parameter");
    }

    if (tokens.size() > 2)
    {
        this->context->currLineStrLTrim = tokens.at(2);
        if (this->context->currLineStrLTrim.find(TAG_HAS_FEATURE_ENABLE) == 1)
        {
            this->extractKeywordParam(TAG_HAS_FEATURE_ENABLE, 0, keywordParamList, true);
        }
    }

    /* Extract loop */
    while (this->getGenSqlLine() && this->isTag(TAG_GEN_LOOP_END) == false)
    {
        loopScptStream << this->context->currLineStr << endl;
    }

    DICT_ENTITY_STP selDictEntityStp = DBA_GetEntityBySqlName(tokens.at(1));
    string          scptStr;

    if (selDictEntityStp &&
        selDictEntityStp->objectEn == DictEntity)
    {
        if (keywordParamList.size() &&
            static_cast<XdEntityFeatureFeatureEn>(atoi(keywordParamList.at(0).at(0).c_str())) == XdEntityFeatureFeatureEn::ChangeSet)
        {
            map<DICT_T, OBJECT_ENUM> loopEntitiesMap;

            for (OBJECT_ENUM loopObjEn = 0; loopObjEn != LASTENTITYOBJECT; loopObjEn++)
            {
                DICT_ENTITY_STP loopDictEntityStp = DBA_GetDictEntitySt(loopObjEn);
                if (loopDictEntityStp != nullptr &&
                    loopDictEntityStp->changeSetAuthEn == FeatureAuth_Enable &&
                    loopDictEntityStp->entNatEn        != EntityNat_DerivedEntity)
                {
                    loopEntitiesMap[loopDictEntityStp->entDictId] = loopObjEn;
                }
            }

            for (auto it = loopEntitiesMap.begin(); it != loopEntitiesMap.end(); ++it)
            {
                DdlGen loopDdlGen(it->second, this->context->outDdlGenPtr->targetTableEn, *this);
                this->context->outDdlGenPtr->bodySqlBlock << loopDdlGen.scriptDdlGen->buildScript(loopScptStream.str()) << endl;
                this->ddlGenContextPtr->m_dependsEntityMap.clear();
            }
        }
    }
    else
    {
        this->printMsg(RET_GEN_ERR_INVARG, "Keyword #" + this->context->currTag + ": Unsupported or unknown entity loop (" + tokens.at(2) + ")");
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenFromFile::createSProcGenIf()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-26250 - LJE - 170602
**
*************************************************************************/
RET_CODE DdlGenFromFile::createSProcGenIf()
{
    RET_CODE               ret = RET_SUCCEED;

    vector<string>         tokens;
    stringstream           execScptStream;
    bool                   bScriptToDo = false;

    this->tokenize(tokens);

    if (tokens.size() < 2)
    {
        ret = RET_GEN_ERR_INVARG;
        this->printMsg(ret, "Keyword #" + this->context->currTag + " : Syntax error, need at least 1 parameter");
        return ret;
    }

    auto ddlGenPtr = this->context->outDdlGenPtr;

    AAAValueGuard<DdlGen *> parentDdlGenGuard(ddlGenPtr->scriptDdlGen->m_parentDdlGenPtr);
    ddlGenPtr->scriptDdlGen->m_parentDdlGenPtr = this->m_parentDdlGenPtr;

    if (tokens.at(1).compare("bk") == 0)
    {
        if (ddlGenPtr->getDictEntityStp()->bkAttrNbr)
        {
            bScriptToDo = true;
        }
    }
    else if (tokens.at(1).compare("ud") == 0)
    {
        if (ddlGenPtr->getDictEntityStp()->custAuthFlg == TRUE)
        {
            bScriptToDo = true;
        }
    }
    else if (tokens.at(1).compare("entity") == 0 && tokens.size() > 2)
    {
        if (tokens.at(2).compare(ddlGenPtr->getDictEntityStp()->mdSqlName) == 0)
        {
            bScriptToDo = true;
        }
    }
    else if (tokens[1] == "exists" ||
             tokens[1] == "not_exists")
    {
        stringstream           ifScptStream;
        while (this->getGenSqlLine() && this->isTag(TAG_END) == false)
        {
            ifScptStream << this->context->currLineStr << endl;
        }

        string requestStr = ddlGenPtr->scriptDdlGen->buildScript(ifScptStream.str(), DdlObj_SubQuery);

        DbiConnectionHelper dbiConnHelper;
        RequestHelper requestHelper(dbiConnHelper);

        requestHelper.setReadOnly(true);
        requestHelper.setCommand(requestStr);
        requestHelper.addNewOutputData(IntType);
        requestHelper.sendCommandForFetch();
        auto bExists = (requestHelper.fetch() == RET_SUCCEED);

        if (tokens[1] == "not_exists")
        {
            bExists = !bExists;
        }

        if (bExists)
        {
            bScriptToDo = true;
        }
        else
        {
            this->m_bSkipNextBloc = true;
        }
    }
    else
    {
        ret = RET_GEN_ERR_INVARG;
        this->printMsg(ret, "Keyword #" + this->context->currTag + " : Unsupported or unknown condition (" + tokens.at(1) + ")");
        return ret;
    }

    /* Extract loop */
    while (this->getGenSqlLine() && this->isTag(TAG_GEN_IF_END) == false)
    {
        execScptStream << this->context->currLineStr << endl;
    }

    if (bScriptToDo)
    {
        ddlGenPtr->bodySqlBlock
            << ddlGenPtr->scriptDdlGen->buildScript(execScptStream.str(),
                                                    (this->getDdlObjEn() == DdlObj_Sql ? DdlObj_SubSql : DdlObj_SubDdlObj))
            << endl;
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenFromFile::createGetResultSetData()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-28698 - LJE - 180601
**
*************************************************************************/
RET_CODE DdlGenFromFile::createGetResultSetData()
{
    RET_CODE               ret = RET_SUCCEED;

    vector<vector<string>> orderParamList;
    this->extractKeywordParam(this->context->currTag, 0, orderParamList, false);

    size_t paramExpected = 2;
    size_t dataIdx = 0;

    if (this->context->currTag.compare(TAG_GET_FIRST_DATA) == 0)
    {
        paramExpected = 2;
    }
    else if (this->context->currTag.compare(TAG_GET_DATA) == 0)
    {
        paramExpected = 2;
        dataIdx = this->m_dataIdx;
    }
    else if (this->context->currTag.compare(TAG_GET_RESULT_SET_NUMBER) == 0)
    {
        paramExpected = 1;
    }
    else
    {
        paramExpected = 4;
        dataIdx = stoi(orderParamList.at(paramExpected - 2)[0]);
    }

    if (orderParamList.size() < paramExpected)
    {
        stringstream msg;
        ret = RET_GEN_ERR_INVARG;
        msg << "Keyword #" << this->context->currTag << ": Syntax error, need at least " << paramExpected << " parameters";
        this->printMsg(ret, msg.str());
        return ret;
    }

    string          varStr = orderParamList[0][0];

    if (this->resultSetData != nullptr)
    {
        if (this->context->currTag.compare(TAG_GET_RESULT_SET_NUMBER) == 0)
        {
            DdlGenVar *varPtr     = this->varHelperPtr->getNewVariable(varStr, IntType);
            varPtr->setValue(SYS_Stringer(this->resultSetData->getResultSetNbr()));
            varPtr->bRuntimeValue = true;
        }
        else
        {
            size_t                       resultSetIdx = paramExpected == 2 ? 0 : atoi(orderParamList.at(paramExpected - 3)[0].c_str());
            string                       attStr = orderParamList.at(paramExpected - 1)[0].c_str();
            DBA_DYNFLD_STP               dataStp = nullptr;
            std::vector<DdlGenDataField> ddlGenDataFieldVector;

            if (this->resultSetData->getResultSetData(dataStp, resultSetIdx, dataIdx))
            {
                DBA_DYNST_ENUM  dynStEn = GET_DYNSTENUM(dataStp);
                OBJECT_ENUM     objEn   = GET_OBJ_DYNST(dynStEn);

                if (objEn != NullEntity)
                {
                    DICT_ATTRIB_STP dictAttributeStp = DBA_GetAttributeBySqlName(objEn, attStr.c_str(), true);

                    if (dictAttributeStp != nullptr)
                    {
                        stringstream  varValue;
                        DdlGenVar    *varPtr = this->varHelperPtr->getNewVariable(varStr, dictAttributeStp->dataTpProgN);

                        DBA_DispFieldValue(varValue, dataStp, dictAttributeStp->progN, std::string());
                        varPtr->setValue(varValue.str());

                        if (_IS_NULLFLD(dataStp, dictAttributeStp->progN) == TRUE)
                        {
                            varPtr->bNullValue = true;
                        }
                        else
                        {
                            varPtr->bNullValue = false;
                        }
                        varPtr->bRuntimeValue = true;
                    }
                    else
                    {
                        DICT_ENTITY_STP dictEntityStp = DBA_GetDictEntitySt(objEn);

                        ret = RET_GEN_ERR_INVARG;
                        this->printMsg(ret, "Keyword #" + this->context->currTag + ": Syntax error, unknown attribute " + dictEntityStp->mdSqlName + "." + attStr);
                    }
                }
                else if (dynStEn != NullDynSt)
                {
                    auto cFieldStp = DBA_GetCFielBySqlName(dynStEn, attStr.c_str(), nullptr);
                    if (cFieldStp != nullptr)
                    {
                        stringstream  varValue;
                        DdlGenVar* varPtr = this->varHelperPtr->getNewVariable(varStr, cFieldStp->dataTypeEnum);

                        DBA_DispFieldValue(varValue, dataStp, (*cFieldStp->fieldPosPtr), std::string());
                        varPtr->setValue(varValue.str());

                        if (_IS_NULLFLD(dataStp, (*cFieldStp->fieldPosPtr)) == TRUE)
                        {
                            varPtr->bNullValue = true;
                        }
                        else
                        {
                            varPtr->bNullValue = false;
                        }
                        varPtr->bRuntimeValue = true;
                    }
                }
            }
            else if (this->resultSetData->getResultSetData(ddlGenDataFieldVector, resultSetIdx, dataIdx))
            {
                auto it = ddlGenDataFieldVector.begin();

                for (; it != ddlGenDataFieldVector.end(); ++it)
                {
                    if ((*it) == attStr)
                    {
                        DdlGenVar    *varPtr = this->varHelperPtr->getNewVariable(varStr, it->dataType);
                        varPtr->setValue(it->value);
                        varPtr->bNullValue = it->bNullValue;
                        varPtr->bRuntimeValue = true;
                        break;
                    }
                }

                if (it == ddlGenDataFieldVector.end())
                {
                    ret = RET_GEN_ERR_INVARG;
                    this->printMsg(ret, "Keyword #" + this->context->currTag + ": Syntax error, unknown attribute " + attStr);
                }
            }
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenFromFile::setStdProc()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
void DdlGenFromFile::setStdProc()
{
    this->ddlGenContextPtr->getDictSprocSt().reset();
    this->context->m_elseResultsSetPos = 0;
    this->context->m_ifResultsSetVector.clear();

    this->ddlGenContextPtr->getDictSprocSt().setObjectEn(this->getObjectEn());
    this->newOutDdlGen();

    if (this->ddlGenContextPtr->getDdlGenMode() == DdlGenMode_Standard)
    {
        this->varHelperPtr->cleanAllVar();
    }
}

/************************************************************************
**
**  Function    :   DdlGenFromFile::getDictEntityStp()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-37366 - LJE - 200326
**
*************************************************************************/
DICT_ENTITY_STP DdlGenFromFile::getDictEntityStp()
{
    if (this->ddlGenEntityPtr != nullptr)
    {
        return this->ddlGenEntityPtr->getDictEntityStp();
    }
    else if (this->getObjectEn() != NullEntity)
    {
        return DBA_GetDictEntitySt(this->getObjectEn());
    }
    return DBA_GetDictEntitySt(InvalidEntity);
}


/************************************************************************
**
**  Function    :   DdlGenFromFile::printSubQuery()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-49178 - LJE - 221027
**
*************************************************************************/
std::string DdlGenFromFile::printSubQuery(std::stringstream& inputStream)
{
    if (inputStream.str().empty() == false &&
        this->context != nullptr &&
        this->context->outDdlGenPtr != nullptr)
    {
        stringstream outputStream;
        std::string line;

        inputStream.clear();
        inputStream.seekg(0, ios::beg);
        while (std::getline(inputStream, line))
        {
            if (line.empty() == false)
            {
                outputStream << this->context->outDdlGenPtr->getIndent();
            }
            outputStream << line << endl;
        }

        return outputStream.str();
    }

    return inputStream.str();
}


/************************************************************************
**
**  Function    :  DdlGenFromFile::initAllStdSProc()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-14452 - LJE - 130116
**
*************************************************************************/
RET_CODE DdlGenFromFile::initAllStdSProc()
{
    RET_CODE         ret = RET_SUCCEED;
    DdlGenContextPtr localDdlGenContextPtr(new DdlGenContext(this->ddlGenContextPtr->m_rdbmsEn));
    DdlGenSProcPtr   genDdlPtr(new DdlGenSProc(this->getObjectEn(), *localDdlGenContextPtr, this->varHelperPtr, this->ddlGenEntityPtr, this->fileHelperPtr, TargetTable_Main));
    DictSprocClass  &dictSprocSt = localDdlGenContextPtr->getDictSprocSt();

    DICT_ENTITY_STP locDictEntityStp = DBA_GetDictEntitySt(this->getObjectEn());

    this->allStdProcToDo = false;

    if (GET_BIT(locDictEntityStp->automaticMask, Automatic_SProc) == FALSE ||
        GET_BIT(locDictEntityStp->automaticMask, Automatic_OppositeBehavior) == TRUE)
    {
        return ret;
    }

    dictSprocSt.setObjectEn(this->getObjectEn());
    dictSprocSt.sqlName.clear();

    dictSprocSt.translateFlg = FALSE;
    dictSprocSt.synonymFlg   = FALSE;
    dictSprocSt.role         = 0; /* PMSTA-14452 - LJE - 121102 */
    dictSprocSt.executeAsEn  = ExecuteAs_None; /* PMSTA-18096 - LJE - 140623 */
    dictSprocSt.functionFlg  = FALSE;

    for (int i = 0; SV_DddStdSProcDefTab[i].procActionEn != NullAction; i++)
    {
        /* PMSTA-14452 - LJE - 121031 */
        if (SV_DddStdSProcDefTab[i].role == DBA_ROLE_UPD_UD_FIELDS &&
            (dictSprocSt.getDictEntityStp()->dbRuleEn == DbRule_NotInDatabase ||
             dictSprocSt.getDictEntityStp()->custAuthFlg == FALSE))
        {
            continue;
        }

        if (SV_DddStdSProcDefTab[i].outputDynTypeEn == DynType_Short &&
            dictSprocSt.getDictEntityStp()->shortDictCriteriaMap.size() == 0)
        {
            continue;
        }

        dictSprocSt.procActionEn = SV_DddStdSProcDefTab[i].procActionEn;
        dictSprocSt.procAccessEn = SV_DddStdSProcDefTab[i].procAccessEn;
        dictSprocSt.role = SV_DddStdSProcDefTab[i].role; /* PMSTA-14452 - LJE - 121102 */
        dictSprocSt.bStdProc = true;

        if (SV_DddStdSProcDefTab[i].inputObjectEn != InvalidEntity)
        {
            dictSprocSt.inputObjectEn = SV_DddStdSProcDefTab[i].inputObjectEn;
        }

        if (SV_DddStdSProcDefTab[i].outputObjectEn != InvalidEntity)
        {
            dictSprocSt.outputObjectEn = SV_DddStdSProcDefTab[i].outputObjectEn;
        }
        dictSprocSt.outputDynTypeEn = SV_DddStdSProcDefTab[i].outputDynTypeEn;

        dictSprocSt.sqlName.clear();
        genDdlPtr->init(true);

        dictSprocSt.sqlName = genDdlPtr->getSprocSqlName();

        /* PMSTA-37366 - LJE - 200210 */
        if (this->ddlGenContextPtr->isProcToGenerate(dictSprocSt.sqlName, this->getDictEntityStp()->mdSqlName) == false)
        {
            continue;
        }

        if (dictSprocSt.sqlName.empty() == false) /* OCS-43062 - LJE - 130923 */
        {
            dictSprocSt.dbName = this->ddlGenContextPtr->getDefDdlDestDbName();

            this->stdDictSprocList.push_back(dictSprocSt);
        }
    }

    return ret;
}
/************************************************************************
**
**  Function    :   DdlGenFromFile::createStandardView()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-13109 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenFromFile::createStandardView()
{
    RET_CODE        ret = RET_SUCCEED;
    bool            bVwAppendFile = this->ddlGenContextPtr->m_fileOpenSet.find(DdlObj_View) != this->ddlGenContextPtr->m_fileOpenSet.end();
    MemoryPool      mp;

    this->outDdlObjEn = DdlObj_View;

    DdlGenView* genDdl = new DdlGenView(this->objectEn, View_FullAllSecured, *this->ddlGenContextPtr, this->ddlGenEntityPtr, this->fileHelperPtr, TargetTable_Main);
    mp.ownerObject(genDdl);

    MASK_T automaticMask = genDdl->getDictEntityStp()->automaticMask;
    if (this->ddlGenContextPtr->ddlGenAction.m_execModeEn == DbObjExecMod_BuildFromTemplate)
    {
        auto xdSentityStp = this->ddlGenEntityPtr->getXdEntityStp();
        automaticMask = GET_MASK(xdSentityStp, A_XdEntity_AutomaticMask);
    }

    if (genDdl->getDictEntityStp()->dbRuleEn == DbRule_NotMainTable ||
        genDdl->getDictEntityStp()->dbRuleEn == DbRule_NotInDatabase)
    {
        return ret;
    }

    if (this->ddlGenContextPtr->ddlGenAction.m_targetSqlnameStr.empty() == false)
    {
        genDdl->setTableNamePatern(this->ddlGenContextPtr->ddlGenAction.m_targetSqlnameStr);
        genDdl->bKeepRealObject = true;

        /* PMSTA-37366 - LJE - 200311 */
        if (this->ddlGenContextPtr->m_forceTbDbSqlName.empty() == false)
        {
            genDdl->realDbName = this->ddlGenContextPtr->m_forceTbDbSqlName;
        }
    }

    if (this->ddlObjFromFileEn == DdlObjFromFile_SystemView)
    {
        if (RET_GET_LEVEL(ret) != RET_LEV_ERROR &&
            genDdl->getDictEntityStp()->multiEntityCateg.isUseMeViewAsTable())
        {
            genDdl->setViewEn(View_MultiEntitySpec);
            genDdl->bAppendFile = bVwAppendFile;
            if (this->stdViewMap[genDdl->getDdlObjSqlName()] == false)
            {
                this->ddlGenContextPtr->setDdlGenMode(DdlGenMode_MultiEntity);
                ret = genDdl->build();
                this->ddlGenContextPtr->setDdlGenMode(DdlGenMode_Standard);
                bVwAppendFile = true;
            }
        }

        if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
        {
            if (GET_BIT(automaticMask, Automatic_ViewFullAll) == TRUE)
            {
                genDdl->setViewEn(View_Tech);
                genDdl->bAppendFile = bVwAppendFile;
                if (this->stdViewMap[genDdl->getDdlObjSqlName()] == false)
                {
                    ret = genDdl->build();
                    bVwAppendFile = true;
                }
            }
        }
    }
    else if (this->ddlObjFromFileEn == DdlObjFromFile_UtilsView)
    {
        if (RET_GET_LEVEL(ret) != RET_LEV_ERROR &&
            this->ddlGenEntityPtr->getFeatureAuth(XdEntityFeatureFeatureEn::ChangeSet) == FeatureAuth_Enable)
        {
            genDdl->setViewEn(View_Shadow);
            genDdl->bAppendFile = bVwAppendFile;
            if (this->stdViewMap[genDdl->getDdlObjSqlName()] == false)
            {
                ret = genDdl->build();
                bVwAppendFile = true;
            }
        }

        /* PMSTA-36919 - LJE - 191210 */
        if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
        {
            if (GET_BIT(genDdl->getDictEntityStp()->automaticMask, Automatic_ViewLightAll) == TRUE)
            {
                genDdl->setViewEn(View_LightAll);
                genDdl->bAppendFile = bVwAppendFile;
                if (this->stdViewMap[genDdl->getDdlObjSqlName()] == false)
                {
                    ret = genDdl->build();
                    bVwAppendFile = true;
                }
            }
        }
    }
    else
    {
        if (this->ddlGenContextPtr->ddlGenAction.m_execModeEn != DbObjExecMod_BuildFromTemplate)
        {
            if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
            {
                if (GET_BIT(automaticMask, Automatic_ViewShortSecured) == TRUE)
                {
                    genDdl->setViewEn(View_ShortSecured);
                    genDdl->bAppendFile = bVwAppendFile;
                    if (this->stdViewMap[genDdl->getDdlObjSqlName()] == false)
                    {
                        ret = genDdl->build();
                        bVwAppendFile = true;
                    }
                }
            }
        }

        if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
        {
            if (GET_BIT(automaticMask, Automatic_ViewFullAllSecured) == TRUE)
            {
                genDdl->setViewEn(View_FullAllSecured);
                genDdl->bAppendFile = bVwAppendFile;
                if (this->stdViewMap[genDdl->getDdlObjSqlName()] == false)
                {
                    ret = genDdl->build();
                    bVwAppendFile = true;
                }

                if (this->ddlGenContextPtr->ddlGenAction.m_execModeEn != DbObjExecMod_BuildFromTemplate)
                {
                    /* PMSTA-29982 - LJE - 180209 */
                    genDdl->setViewEn(View_Export);
                    genDdl->bAppendFile = bVwAppendFile;
                    if (this->stdViewMap[genDdl->getDdlObjSqlName()] == false)
                    {
                        ret = genDdl->build();
                        bVwAppendFile = true;
                    }

                    genDdl->setViewEn(View_MainTable);
                    genDdl->bAppendFile = bVwAppendFile;
                    if (this->stdViewMap[genDdl->getDdlObjSqlName()] == false)
                    {
                        ret = genDdl->build();
                        bVwAppendFile = true;
                    }
                }
            }
        }

        if (this->ddlGenContextPtr->ddlGenAction.m_execModeEn != DbObjExecMod_BuildFromTemplate)
        {
            if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
            {
                if (GET_BIT(automaticMask, Automatic_ViewFullAll) == TRUE)
                {
                    genDdl->setViewEn(View_FullAll);
                    genDdl->bAppendFile = bVwAppendFile;
                    if (this->stdViewMap[genDdl->getDdlObjSqlName()] == false)
                    {
                        ret = genDdl->build();
                        bVwAppendFile = true;
                    }
                }
            }

            /* OCS-41131 - LJE - 120723 */
            if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
            {
                if (GET_BIT(automaticMask, Automatic_ViewFullAll4ForeignKey) == TRUE)
                {
                    genDdl->setViewEn(View_FullAll4ForeignKey);
                    genDdl->bAppendFile = bVwAppendFile;
                    if (this->stdViewMap[genDdl->getDdlObjSqlName()] == false)
                    {
                        ret = genDdl->build();
                        bVwAppendFile = true;
                    }

                    genDdl->setViewEn(View_AllSecured);
                    genDdl->bAppendFile = bVwAppendFile;
                    if (this->stdViewMap[genDdl->getDdlObjSqlName()] == false)
                    {
                        ret = genDdl->build();
                        bVwAppendFile = true;
                    }
                }
            }
        }
    }

    if (bVwAppendFile)
    {
        this->ddlGenContextPtr->m_fileOpenSet.insert(DdlObj_View);
    }

    return ret;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::createAllStdSProc()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-13109 - LJE - 111124
**
*************************************************************************/
RET_CODE DdlGenFromFile::createAllStdSProc()
{
    RET_CODE        ret = RET_SUCCEED, gblRet = RET_SUCCEED;

    if (this->allStdProcToDo == false &&
        this->getDictEntityStp()->custAuthFlg == FALSE)
    {
        return ret;
    }

    this->outDdlObjEn = DdlObj_SProc;
    this->ddlGenContextPtr->setDdlObjEn(DdlObj_SProc);

    this->setStdProc();

    for (auto it = this->stdDictSprocList.begin(); it != this->stdDictSprocList.end(); ++it)
    {
        this->ddlGenContextPtr->resetContext(it->sqlName);
        this->varHelperPtr->cleanAllVar();

        /* If only upd_ud_... to do */
        if (this->allStdProcToDo == false &&
            it->role != DBA_ROLE_UPD_UD_FIELDS)
        {
            continue;
        }

        if (it->procActionEn == NullAction)
        {
            continue;
        }

        DictSprocClass &dictSrpocSt = this->ddlGenContextPtr->getDictSprocSt();
        dictSrpocSt = *it;

        DdlGenSProc ddlGenSProc(it->getObjectEn(), *this->ddlGenContextPtr, this->varHelperPtr, this->ddlGenEntityPtr, this->fileHelperPtr, TargetTable_Main);

        ddlGenSProc.bAppendFile = this->outDdlGenSprocPtr->bAppendFile;
        ret = ddlGenSProc.build();

        this->outDdlGenSprocPtr->bAppendFile = true;

        if (ret != RET_SUCCEED &&
            ret != RET_GEN_INFO_NOACTION)
        {
            gblRet = ret;
        }
    }

    this->context->outDdlGenPtr->bAppendFile = true;

    return gblRet;
}

/************************************************************************
**
**  Function    :   DdlGenFromFile::manageFromFileTriggers()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-18593 - LJE - 141217
**
*************************************************************************/
RET_CODE DdlGenFromFile::manageFromFileTriggers()
{
    RET_CODE        ret = RET_SUCCEED;
    string          savedCurrLineStr, savedCurrLineStrLTrim;
    vector<string>  triggerTokens;
    stringstream    triggerStream;
    TRIGGER_POS_ENUM triggerPosEn = TriggerPos_AfterStandard;

    this->lastErrRetCode = RET_SUCCEED;

    if (this->context->currBlockVector.size() == 0)
        return ret;

    savedCurrLineStr = this->context->currLineStr;
    savedCurrLineStrLTrim = this->context->currLineStrLTrim;

    this->context->lineNb = 0;
    this->context->bInitCurrLineIt = false;
    this->context->bUpdateIndent = true;

    if (this->getGenSqlLine())
    {
        this->context->currTagNat = TagSql_Body;

        if (this->isTag(TAG_TRIGGER_BEGIN))
        {
            this->tokenize(triggerTokens);

            if (triggerTokens.size() < 3)
            {
                ret = RET_GEN_ERR_INVARG;
                this->printMsg(ret, "Syntax error: #TRIGGER_BEGIN <DDL statement> <DML event> [<DML event>]... ");
                return ret;
            }

            while (this->getGenSqlLine() &&
                   this->isTag(TAG_TRIGGER_END) == false)
            {
                triggerStream << "\t" << this->context->currLineStr << endl;
            }

            if (this->isTag(TAG_TRIGGER_END) == false)
            {
                ret = RET_GEN_ERR_INVARG;
                this->printMsg(ret, "Syntax error: missing #TRIGGER_END");
                return ret;
            }

            for (vector<string>::iterator currDmlEvent = triggerTokens.begin() + 2; currDmlEvent != triggerTokens.end(); currDmlEvent++)
            {
                if (currDmlEvent->compare(TAG_BEFORE_STD) == 0 ||
                    currDmlEvent->compare(TAG_BEFORE) == 0)
                {
                    triggerPosEn = TriggerPos_BeforeStandard;
                    triggerTokens.erase(currDmlEvent);
                    break;
                }
                else if (currDmlEvent->compare(TAG_AFTER_STD) == 0 ||
                         currDmlEvent->compare(TAG_AFTER) == 0)
                {
                    triggerPosEn = TriggerPos_AfterStandard;
                    triggerTokens.erase(currDmlEvent);
                    break;
                }
            }

            for (vector<string>::size_type dmlEventPos = 2; dmlEventPos < triggerTokens.size(); dmlEventPos++)
            {
                DML_EVENT_ENUM dmlEvent = DmlEvent_None;
                if (triggerTokens.at(dmlEventPos).compare(TAG_INSERT) == 0)
                {
                    dmlEvent = DmlEvent_Insert;
                }
                else if (triggerTokens.at(dmlEventPos).compare(TAG_UPDATE) == 0)
                {
                    dmlEvent = DmlEvent_Update;
                }
                else if (triggerTokens.at(dmlEventPos).compare(TAG_DELETE) == 0)
                {
                    dmlEvent = DmlEvent_Delete;
                }

                if (dmlEvent != DmlEvent_None)
                {
                    if (triggerTokens.at(1).compare(TAG_BEFORE) == 0)
                    {
                        this->outDdlGenTriggerPtr->pushBeforeStatement(triggerStream.str(), triggerPosEn, dmlEvent);
                    }
                    else if (triggerTokens.at(1).compare(TAG_BEFORE_EACH_ROW) == 0)
                    {
                        this->outDdlGenTriggerPtr->pushBeforeEachRowStatement(triggerStream.str(), triggerPosEn, dmlEvent);
                    }
                    else if (triggerTokens.at(1).compare(TAG_AFTER_EACH_ROW) == 0)
                    {
                        this->outDdlGenTriggerPtr->pushAfterEachRowStatement(triggerStream.str(), triggerPosEn, dmlEvent);
                    }
                    else if (triggerTokens.at(1).compare(TAG_AFTER) == 0)
                    {
                        this->outDdlGenTriggerPtr->pushAfterStatement(triggerStream.str(), triggerPosEn, dmlEvent);
                    }
                    else if (triggerTokens.at(1).compare(TAG_INIT) == 0)
                    {
                        this->outDdlGenTriggerPtr->pushBeforeStatement(triggerStream.str(), TriggerPos_Init, dmlEvent);
                    }
                }
                else
                {
                    ret = RET_GEN_ERR_INVARG;
                    this->printMsg(ret, "Syntax error: wrong DML Event (" + triggerTokens.at(dmlEventPos) + "on keyword #TRIGGER_BEGIN");
                    return ret;
                }
            }
        }
    }

    this->context->currBlockVector.clear();
    this->context->pscStream.clear();
    this->context->pscStream.str(string());
    this->context->currLineStr = savedCurrLineStr;
    this->context->currLineStrLTrim = savedCurrLineStrLTrim;

    return ret;
}

/************************************************************************
**
**  Function    :   DdlGenFromFile::createStandardTriggers()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-16194 - LJE - 110311
**
*************************************************************************/
RET_CODE DdlGenFromFile::createStandardTriggers()
{
    RET_CODE        ret = RET_SUCCEED, gblRet = RET_SUCCEED;

    this->outDdlGenTriggerPtr->scriptDdlGen->varHelperPtr->cleanAllVar();

    /* PMSTA-46681 - LJE - 230214 */
    set<DML_EVENT_ENUM>   dmlEventSet;
    set<TRIGGER_POS_ENUM> triggerPosSet;
    set<EVENT_POS_ENUM>   eventPosSet;

    dmlEventSet.insert(DmlEvent_Insert);
    dmlEventSet.insert(DmlEvent_Update);
    dmlEventSet.insert(DmlEvent_Delete);

    if (this->ddlGenContextPtr->m_rdbmsEn == PostgreSQL)
    {
        triggerPosSet.insert(TriggerPos_BeforeEachRow);
        triggerPosSet.insert(TriggerPos_AfterEachRow);
        triggerPosSet.insert(TriggerPos_After);

        eventPosSet.insert(EventPos_All);
    }
    else
    {
        if (this->ddlGenContextPtr->m_rdbmsEn == Nuodb)
        {
            eventPosSet.insert(EventPos_Before);
            eventPosSet.insert(EventPos_After);
        }
        else
        {
            eventPosSet.insert(EventPos_All);
        }

        triggerPosSet.insert(TriggerPos_None);
    }

    string  database = this->ddlGenContextPtr->getDdlDestDbName();

    set<DDL_OBJ_ENUM> ddlObjToDoSet;
    ddlObjToDoSet.insert(DdlObj_Trigger);
    ddlObjToDoSet.insert(DdlObj_TriggerUdField);

    for (auto ddlObjIt = ddlObjToDoSet.begin(); ddlObjIt != ddlObjToDoSet.end(); ++ddlObjIt)
    {
        bool bToDo = false;

        if ((*ddlObjIt) == DdlObj_Trigger &&
            this->outDdlGenTriggerPtr->getDictEntityStp()->isPhysicalEntity(TargetTable_Main))
        {
            bToDo = true;
        }

        if ((*ddlObjIt) == DdlObj_TriggerUdField &&
            this->outDdlGenTriggerPtr->getDictEntityStp()->custAuthFlg == TRUE &&
            this->outDdlGenTriggerPtr->getDictEntityStp()->isPhysicalEntity(TargetTable_UserDefinedFields))
        {
            bToDo = true;
        }

        if (bToDo)
        {
            this->ddlGenContextPtr->bUserId = false;

            this->outDdlObjEn = (*ddlObjIt);

            if (ddlObjIt != ddlObjToDoSet.begin())
            {
                this->newOutDdlGen();
            }

            std::map<DdlObjDefKey, DdlObjDef>  allDbTriggerSet = this->outDdlGenTriggerPtr->getAllDbTrigger();

            for (auto dmlEvent = dmlEventSet.begin(); dmlEvent != dmlEventSet.end(); ++dmlEvent)
            {
                for (auto eventPos = eventPosSet.begin(); eventPos != eventPosSet.end(); ++eventPos)
                {
                    for (auto triggerPos = triggerPosSet.begin(); triggerPos != triggerPosSet.end(); ++triggerPos)
                    {
                        this->outDdlGenTriggerPtr->init((*dmlEvent), (*eventPos), (*triggerPos));
                        ret = this->outDdlGenTriggerPtr->build();
                        if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                        {
                            gblRet = ret;
                        }
                        else if (ret != RET_GEN_INFO_NODATA ||
                                 (this->outDdlGenTriggerPtr->isReplaceAllowed(this->outDdlGenTriggerPtr->getDdlObjEn()) == false &&
                                  this->ddlGenContextPtr->m_dropDdlStrTab.empty()))
                        {
                            allDbTriggerSet.erase(DdlObjDefKey(this->ddlGenContextPtr->m_rdbmsEn,
                                                               this->outDdlObjEn,
                                                               database,
                                                               this->outDdlGenTriggerPtr->getEntitySqlName(nullptr, TargetTable_Undefined, true),
                                                               this->outDdlGenTriggerPtr->getEntitySqlName(),
                                                               this->outDdlGenTriggerPtr->getDdlObjSqlName()));
                        }
                    }
                }
            }

            this->outDdlGenTriggerPtr->clear();
            for (auto it = allDbTriggerSet.begin(); it != allDbTriggerSet.end(); ++it)
            {
                this->ddlGenContextPtr->setDdlDestDbName(database, this->outDdlGenTriggerPtr);
                this->outDdlGenTriggerPtr->bodySqlBlock << this->outDdlGenTriggerPtr->getCmdDrop(database,
                                                                                                 it->second.getEntitySqlName(),
                                                                                                 it->second.getObjName(),
                                                                                                 it->second.getDdlObjEn());
                this->context->outDdlGenPtr->cmdType = DDlCmdType_DropAll;
                this->outDdlGenTriggerPtr->flush();
            }
        }
    }

    this->deleteOutDdlGen();

    return gblRet;
}

/************************************************************************
**
**  Function    :   DdlGenFromFile::removeFromStdProcs()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14452 - LJE - 130116
**
*************************************************************************/
void DdlGenFromFile::removeFromStdProcs(const string &sprocSqlName)
{
    if (sprocSqlName.empty())
    {
        this->printMsg(RET_DBA_ERR_NODATA, "Unable to remove from stored proc table with sql name !");
    }
    else
    {
        for (auto it = this->stdDictSprocList.begin(); it != this->stdDictSprocList.end(); it++)
        {
            if (it->procActionEn != NullAction &&
                strcasecmp(sprocSqlName.c_str(), it->sqlName.c_str()) == 0)
            {
                it->procActionEn = NullAction;
                break;
            }
        }
    }
}

/************************************************************************
**
**  Function    :   DdlGenFromFile::extractFromPart()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14452 - LJE - 130116
**
*************************************************************************/
void DdlGenFromFile::extractFromPart(DdlGen *ddlGenPtr, ENTITY_SECURITY_LEVEL_ENUM locSecuLevelEn)
{
    bool bTagEnd = false;
    string            fromLineStr;
    string::size_type pos;
    TARGET_TABLE_ENUM saveTargetTableEn = ddlGenPtr->targetTableEn;

    ddlGenPtr->targetTableEn = TargetTable_Main;

    this->context->pscStream.clear();
    this->context->pscStream.str(string());

    if (this->isTag(TAG_FROM))
    {
        if (this->context->currLineStrLTrim.size() > strlen(TAG_FROM) + 1)
        {
            ddlGenPtr->fromAddStr = this->context->currLineStrLTrim.substr(strlen(TAG_FROM) + 2);
            trim(ddlGenPtr->fromAddStr);

             /* PMSTA-37366 - LJE - 200130 */
            if ((pos = ddlGenPtr->find_word(ddlGenPtr->fromAddStr, "replace")) != string::npos)
            {
                ddlGenPtr->fromAddStr.erase(pos);
                ddlGenPtr->bReplaceFromTag = true;
            }
            else 
            {
                if (ddlGenPtr->fromAddStr.empty() == false)
                {
                    if ((pos = ddlGenPtr->find_word(ddlGenPtr->fromAddStr, "inner")) != string::npos ||
                        (pos = ddlGenPtr->find_word(ddlGenPtr->fromAddStr, "left")) != string::npos ||
                        (pos = ddlGenPtr->find_word(ddlGenPtr->fromAddStr, "right")) != string::npos ||
                        (pos = ddlGenPtr->find_word(ddlGenPtr->fromAddStr, "full")) != string::npos)
                    {
                        fromLineStr = ddlGenPtr->fromAddStr.substr(pos); /* PMSTA-26250 - LJE - 170331 */
                        ddlGenPtr->fromAddStr.erase(pos);
                            ddlGenPtr->bJoinOnFromTag = true;
                    }
                   
                }
            }
        }
    }

    this->context->pscStream << "#FROM ";

    while (bTagEnd == false && (fromLineStr.empty() == false || this->getGenSqlLine()))
    {
        vector<string>          fromTokens;
        size_t                  entityTokenPos = 0;
        DdlGenJoin             *joinTabPtr;
        DDL_JOIN_TYPE_ENUM      joinTypeEn;

        if (fromLineStr.empty() == false)
        {
            this->context->currLineStrLTrim = fromLineStr;
        }
        else
        {
            this->context->pscStream << endl;
        }

        if (this->context->currLineStrLTrim.size() == 0)
        {
            continue;
        }
        if (this->isTag(TAG_ORDER, false, false))
        {
            this->context->outDdlGenPtr->bOrderBy = true;
            continue;
        }
        if (this->isTag(TAG_END, false, false) ||
            this->isTag(TAG_WHERE, false, false) ||
            this->isTag(TAG_ISOLATION, false, false) ||
            this->isTag(TAG_GROUP, false, false))
        {
            bTagEnd = true;
            continue;
        }

        this->context->pscStream << this->context->currLineStrLTrim << endl;

        if (fromLineStr.empty())
        {
            string            lineStr;
            int               iOpen  = 0;
            int               iClose = 0;

            do
            {
                string getLineStr(this->context->currLineStrLTrim);

                if (getLineStr.empty() ||
                    (pos = ddlGenPtr->find_first_not_of(getLineStr, " \t")) == string::npos)
                {
                    if (this->getGenSqlLine() == false)
                    {
                        break;
                    }
                    continue;
                }

                lineStr += getLineStr;

                string::size_type bracePos = 0;
                while ((bracePos = ddlGenPtr->find_first_of(getLineStr, "(", bracePos)) != string::npos)
                {
                    ddlGenPtr->setIndent(1);
                    iOpen++;
                    bracePos++;
                }
                bracePos = 0;
                while ((bracePos = ddlGenPtr->find_first_of(getLineStr, ")", bracePos)) != string::npos)
                {
                    ddlGenPtr->setIndent(-1);
                    iClose++;
                    bracePos++;
                }

                if (iOpen != iClose)
                {
                    stringstream    nestedSelectStream;
                    vector<string>  nestedTokens;

                    if (this->getGenSqlLine() == false)
                    {
                        break;
                    }

                    if (this->manageNestedTag(nestedSelectStream) &&
                        nestedSelectStream.str().empty() == false)
                    {
                        if (this->getGenSqlLine())
                        {
                            this->tokenize(nestedTokens);

                            if (nestedTokens.size() > 1)
                            {
                                pos = nestedSelectStream.str().find_first_not_of(" \t");
                                lineStr += nestedSelectStream.str().substr(pos);
                            }
                        }
                    }

                    lineStr += ddlGenPtr->newLine();
                }
                
            } while (iOpen != iClose);

            if (iOpen > 0)
            {
                ddlGenPtr->extractAndFixDependsEntity(lineStr);
                this->context->currLineStrLTrim = lineStr;
            }
        }

        this->tokenize(fromTokens);

        if (fromTokens.size() < 1)
        {
            continue;
        }

        /* PMSTA-14311 - LJE - 120619 */
        joinTypeEn = DDlJoinType_TSqlJoin;
        if (strcasecmp(fromTokens[0].c_str(), "inner") == 0)
        {
            joinTypeEn = DDlJoinType_InnerJoin;
            entityTokenPos = 2;
        }
        else if (strcasecmp(fromTokens[0].c_str(), "left") == 0)
        {
            joinTypeEn = DDlJoinType_LeftOuterJoin;
            if (strcasecmp(fromTokens.at(1).c_str(), "outer") == 0)
            {
                entityTokenPos = 3;
            }
            else
            {
                entityTokenPos = 2;
            }
        }
        else if (strcasecmp(fromTokens[0].c_str(), "right") == 0)
        {
            joinTypeEn = DDlJoinType_RightOuterJoin;
            if (strcasecmp(fromTokens.at(1).c_str(), "outer") == 0)
            {
                entityTokenPos = 3;
            }
            else
            {
                entityTokenPos = 2;
            }
        }
        else if (strcasecmp(fromTokens[0].c_str(), "cross") == 0)
        {
            ddlGenPtr->addedJoinTab.push_back(DdlGenJoin());
            joinTabPtr = &(ddlGenPtr->addedJoinTab.at(ddlGenPtr->addedJoinTab.size() - 1));
            joinTabPtr->joinTypeEn = DDlJoinType_None;
            joinTabPtr->securityLevelEn = EntSecuLevel_NoSecured;
            joinTabPtr->addJoinInfoStr += this->context->currLineStrLTrim;
            continue;
        }

        if (entityTokenPos == 0 &&
            ddlGenPtr->addedJoinTab.size() > 0)
        {
            joinTabPtr = &(ddlGenPtr->addedJoinTab.at(ddlGenPtr->addedJoinTab.size() - 1));
            if (joinTabPtr->addJoinInfoStr.empty() == false)
            {
                joinTabPtr->addJoinInfoStr += " ";
            }
            joinTabPtr->addJoinInfoStr += this->context->currLineStrLTrim;
            continue;
        }

        if (fromTokens.size() < 2)
        {
            this->printMsg(RET_GEN_ERR_INVARG, "Invalid #FROM clause (Format: [inner join]/[left outer join] <entity> <alias> [<index>])");
            continue;
        }

        if (fromLineStr.empty())
        {
            ddlGenPtr->addedJoinTab.push_back(DdlGenJoin());
            joinTabPtr = &(ddlGenPtr->addedJoinTab.at(ddlGenPtr->addedJoinTab.size() - 1));
        }
        else
        {
            ddlGenPtr->joinTab.push_back(DdlGenJoin());
            joinTabPtr = &(ddlGenPtr->joinTab.at(ddlGenPtr->joinTab.size() - 1));
        }
        joinTabPtr->joinTypeEn = joinTypeEn;
        joinTabPtr->securityLevelEn = EntSecuLevel_NoSecured;

        if (fromTokens[entityTokenPos] == "(")
        {
            stringstream    nestedSelectStream;
            vector<string>  nestedTokens;

            if (this->getGenSqlLine() &&
                this->manageNestedTag(nestedSelectStream) &&
                nestedSelectStream.str().empty() == false)
            {
                if (this->getGenSqlLine())
                {
                    this->tokenize(nestedTokens);

                    if (nestedTokens.size() > 1)
                    {
                        pos = nestedSelectStream.str().find_first_not_of(" \t");
                        joinTabPtr->joinEntitySqlName = "(" + nestedSelectStream.str().substr(pos) + ")";
                    }
                }
            }
            entityTokenPos = 0;
            this->tokenize(fromTokens);
        }
        else
        {
            string            entitySqlName = fromTokens.at(entityTokenPos);
            string::size_type sufPos;
            TARGET_TABLE_ENUM locTargetTableEnum = this->ddlGenContextPtr->ddlBuildModeEn == DdlBuildMode_ViewOnly ? TargetTable_View : TargetTable_Main;

            joinTabPtr->joinEntitySqlName = entitySqlName;

            if (entitySqlName.length() > 3 &&
                (sufPos = entitySqlName.find("_vw")) == entitySqlName.length() - 3)
            {
                entitySqlName.replace(sufPos, 3, "");
            }
            else if (entitySqlName.length() > 3 && entitySqlName.find("ud_") == 0)
            {
                if (locTargetTableEnum == TargetTable_Main)
                {
                    locTargetTableEnum = TargetTable_UserDefinedFields;
                }
                entitySqlName.erase(0, 3);
            }

            DICT_ENTITY_STP         locDictEntityStp;
            if ((locDictEntityStp = DBA_GetEntityBySqlName(entitySqlName)) != NULL)
            {
                joinTabPtr->objectEn = locDictEntityStp->objectEn;
                joinTabPtr->joinDictEntityStp = locDictEntityStp;
                if (ddlGenPtr->isSecuredLevel(locSecuLevelEn))
                {
                    joinTabPtr->securityLevelEn = locDictEntityStp->securityLevelEn;
                }

                joinTabPtr->joinEntitySqlName = ddlGenPtr->getEntityFullSqlName(locDictEntityStp, locTargetTableEnum);
            }
            else
            {
                ddlGenPtr->extractAndFixDependsEntity(joinTabPtr->joinEntitySqlName);
            }

            if (locDictEntityStp == NULL)
            {
                if (this->context->outDdlGenPtr->isSystemTable(entitySqlName) == false)
                {
                    ddlGenPtr->lastErrRetCode = RET_GEN_INFO_NOACTION;
                    this->printMsg(RET_GEN_ERR_INVARG, "Invalid entity: " + joinTabPtr->joinEntitySqlName);
                }
                else
                {
                    ddlGenPtr->fromAddStr += fromLineStr;
                }
            }
        }

        if (fromTokens.size() > entityTokenPos + 1)
        {
            joinTabPtr->joinSqlName = fromTokens.at(entityTokenPos + 1) + ".";

            if (fromTokens.size() > entityTokenPos + 1)
            {
                size_t tokPos;
                bool   bJoinManagement = false;

                for (tokPos = entityTokenPos + 2; tokPos < fromTokens.size(); tokPos++)
                {
                    string addJoinInfo = fromTokens.at(tokPos);

                    if (bJoinManagement)
                    {
                        string             entitySqlName = addJoinInfo;

                        string::size_type sufPos;
                        if (entitySqlName.length() > 3 &&
                            (sufPos = entitySqlName.find("_vw")) == entitySqlName.length() - 3)
                        {
                            entitySqlName.replace(sufPos, 3, "");
                        }

                        DICT_ENTITY_STP         locDictEntityStp;
                        if ((locDictEntityStp = DBA_GetEntityBySqlName(entitySqlName)) != NULL)
                        {
                            addJoinInfo = ddlGenPtr->getEntityFullSqlName(locDictEntityStp);
                        }
                        else if (entitySqlName.find("ud_") == 0 &&
                            (locDictEntityStp = DBA_GetEntityBySqlName(entitySqlName.substr(3))) != NULL)
                        {
                            addJoinInfo = ddlGenPtr->getEntityFullSqlName(locDictEntityStp, TargetTable_UserDefinedFields);
                        }
                        else
                        {
                            ddlGenPtr->extractAndFixDependsEntity(addJoinInfo);
                        }

                        if (locDictEntityStp == NULL && this->context->outDdlGenPtr->isSystemTable(entitySqlName) == false)
                        {
                            ddlGenPtr->lastErrRetCode = RET_GEN_INFO_NOACTION;
                            this->printMsg(RET_GEN_ERR_INVARG, "Invalid entity: " + entitySqlName);
                        }
                        bJoinManagement = false;
                    }
                    else if (strcasecmp(addJoinInfo.c_str(), "join") == 0)
                    {
                        bJoinManagement = true;
                    }

                    joinTabPtr->addJoinInfoStr += addJoinInfo;
                    joinTabPtr->addJoinInfoStr += " ";
                }
            }
        }
        else
        {
            this->printMsg(RET_GEN_ERR_INVARG, "Invalid join information: " + this->context->currLineStrLTrim);
        }

        fromLineStr.clear();
    }

    if (bTagEnd == false)
    {
        this->printMsg(RET_GEN_ERR_INVARG, "Missing end tag (#END)");
    }

    ddlGenPtr->targetTableEn = saveTargetTableEn;

    ddlGenPtr->pscFromStr = this->context->pscStream.str();
    this->context->pscStream.clear();
    this->context->pscStream.str(string());
}

/************************************************************************
**
**  Function    :   DdlGenFromFile::extractWherePart()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-14452 - LJE - 130116
**
*************************************************************************/
void DdlGenFromFile::extractWherePart(DdlGen* ddlGenPtr, bool& bTagEnd, string& unionStr)
{
    bool bOrder      = (ddlGenPtr->orderStream.str().empty() == false),
        bOrderBlock  = false,
        bGroup       = false,
        bGroupBlock  = false,
        bHaving      = false,
        bHavingBlock = false;

    bTagEnd = false;
    this->context->pscStream.clear();
    this->context->pscStream.str(string());
    this->context->pscStream << "#WHERE" << endl;

    while (bTagEnd == false && this->getGenSqlLine())
    {
        if (this->manageNestedTag(ddlGenPtr->overloadStream) == false)
        {
            if (this->context->currLineStrLTrim.size() == 0)
                continue;

            if (this->isTag(TAG_ORDER))
            {
                bOrderBlock = true;
                this->context->outDdlGenPtr->bOrderBy = true;
                continue;
            }
            else if (this->isTag(TAG_ISOLATION))
            {
                if (this->ddlGenContextPtr->m_rdbmsEn == Sybase)
                {
                    ddlGenPtr->queryAddStr = " at isolation " + this->context->currLineStrLTrim.substr(strlen(TAG_ISOLATION) + 2);
                }
                continue;
            }
            else if (this->isTag(TAG_GROUP))
            {
                bOrderBlock = false;
                bGroupBlock = true;
                continue;
            }
            else if (this->isTag(TAG_HAVING))
            {
                bOrderBlock = false;
                bGroupBlock = false;
                bHavingBlock = true;
                continue;
            }
            else if (this->isTag(TAG_ERROR))
            {
                string errorVar;

                vector<string>   tokens;
                this->tokenize(tokens);

                if (tokens.size() > 1)
                {
                    errorVar = tokens.at(1);
                }
                else
                {
                    errorVar = "@error_code";
                }

                ddlGenPtr->errorVarPtr = this->context->outDdlGenPtr->varHelperPtr->getNewVariable(errorVar, IntType);
                ddlGenPtr->errorVarPtr->strDefault = "0";

                continue;
            }
            else if (this->isTag(TAG_UPDATE_COUNT))
            {
                string rowCountVar;

                vector<string>   tokens;
                this->tokenize(tokens);

                if (tokens.size() > 1)
                {
                    rowCountVar = tokens.at(1);
                }
                else
                {
                    rowCountVar = "@row_count";
                }

                ddlGenPtr->rowCountVarPtr = this->context->outDdlGenPtr->varHelperPtr->getNewVariable(rowCountVar, IntType);
                continue;
            }
            else if (this->isTag(TAG_MAIN_DLM_CHECK) || this->isTag(TAG_ADD_DLM_CHECK)) /* PMSTA24026 - DDV - 161114 */
            {
                this->createSProcDlmCheck(ddlGenPtr);
            }
            else if (this->isTag(TAG_IF_OWNER_BUSINESS_ENTITY))
            {
                bool bHaveOwnerBusinessEntity = false;

                auto dictEntityStp = ddlGenPtr->getDictEntityStp();

                if (dictEntityStp != nullptr &&
                    dictEntityStp->ownerBusinessEntAttrStp != nullptr)
                {
                    bHaveOwnerBusinessEntity = true;
                }

                if (bHaveOwnerBusinessEntity == false)
                {
                    while (this->readNextCurrBlock() && this->isTag(TAG_END_IF_OWNER_BUSINESS_ENTITY) == false)
                    {
                    }
                }
                continue;
            }
            else if (this->isTag(TAG_END_IF_OWNER_BUSINESS_ENTITY))
            {
                continue;
            }

            if (this->isTag(TAG_END) || this->isTag(TAG_UNION) || this->isTag(TAG_UNION_ALL) || this->isTag(TAG_FETCH_CURSOR))
            {
                if (this->isTag(TAG_UNION))
                {
                    this->context->outDdlGenPtr->bUnion = true;
                    unionStr = "union";
                }
                else if (this->isTag(TAG_UNION_ALL))
                {
                    this->context->outDdlGenPtr->bUnion = true;
                    unionStr = "union all";
                }

                bTagEnd = true;
                continue;
            }

            if (bOrderBlock)
            {
                if (bOrder)
                {
                    ddlGenPtr->orderStream.clear();
                    ddlGenPtr->orderStream.str(string());
                    bOrder = false;
                }
                if (ddlGenPtr->orderStream.str().empty())
                {
                    ddlGenPtr->orderStream << ddlGenPtr->newLine() << "order by ";
                }
                else
                {
                    ddlGenPtr->orderStream << ", ";
                }

                /* PMSTA-30450 - LJE - 180305 */
                vector<vector<string>> orderParamList;
                this->extractKeywordParam(string(), 0, orderParamList, false);

                for (auto it = orderParamList.begin(); it != orderParamList.end(); ++it)
                {
                    if (it->empty() == false)
                    {
                        if (it != orderParamList.begin())
                        {
                            ddlGenPtr->orderStream << ", ";
                        }

                        ddlGenPtr->orderStream << it->at(0) << this->context->outDdlGenPtr->getOrderSortRule(it->size() > 1 ? it->at(1) : string());
                    }
                }
            }
            else if (bGroupBlock)
            {
                if (bGroup)
                {
                    ddlGenPtr->groupStream.clear();
                    ddlGenPtr->groupStream.str(string());
                    bGroup = false;
                }
                if (ddlGenPtr->groupStream.str().empty())
                {
                    ddlGenPtr->groupStream << ddlGenPtr->newLine() << "group by " << ddlGenPtr->newLine() << "  ";
                }
                else
                {
                    ddlGenPtr->groupStream << ddlGenPtr->newLine() << ", ";
                }
                ddlGenPtr->groupStream << this->context->currLineStrLTrim;
            }
            else if (bHavingBlock)
            {
                if (bHaving)
                {
                    ddlGenPtr->havingStream.clear();
                    ddlGenPtr->havingStream.str(string());
                    bHaving = false;
                }
                if (ddlGenPtr->havingStream.str().empty())
                {
                    ddlGenPtr->havingStream << ddlGenPtr->newLine() << "having ";
                }
                ddlGenPtr->havingStream << ddlGenPtr->newLine() << this->context->currLineStr;
            }
            else
            {
                ddlGenPtr->overloadStream << this->context->currLineStrLTrim << endl;

                this->context->pscStream << this->context->currLineStrLTrim << endl;
            }
        }
    }

    ddlGenPtr->pscWhereStr = this->context->pscStream.str();
    this->context->pscStream.clear();
    this->context->pscStream.str(string());
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::createSProcSelect()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-11505 - LJE - 110404
**
*************************************************************************/
RET_CODE DdlGenFromFile::createSProcSelect()
{
    RET_CODE         ret = RET_SUCCEED;
    vector<string>   tokens;
    OBJECT_ENUM      locObjectEn = NullEntity;
    DICT_ENTITY_STP  locDictEntityStp = nullptr;
    SEL_LIST_ENUM    selListEn = SelList_Select;
    DBA_DYNTYPE_ENUM locOutDynNatEn = DynType_Null;

    FLAG_T           locCustFlg = FALSE,
        locprecompFlg = FALSE,
        locOnlyPhysicalFlg = FALSE;

    ENTITY_SECURITY_LEVEL_ENUM locSecuLevelEn = EntSecuLevel_NoSecured;

    bool            bTagFrom = false;
    bool            bTagWhere = false;
    bool            bTagEnd = false;
    bool            bLocalShadowAccess = false; /* PMSTA-27463 - LJE - 170606 */
    string          unionStr, physicalTable;
    stringstream    selStream;

    this->tokenize(tokens);

    bool bSimple = (tokens.at(tokens.size() - 1) == TAG_END);

    if (tokens.size() <= 2)
    {
        this->printMsg(RET_GEN_ERR_INVARG, "Tag SELECT error: #SELECT entity_sqlname_c dyn_nat_e(all/all_db/short/null) [alias] [physical entity]");
        return RET_GEN_ERR_INVARG;
    }

    if ((locOutDynNatEn = this->getDynType(tokens.at(2))) == DynType_Unknown)
    {
        this->printMsg(RET_GEN_ERR_INVARG, "Unknown DynType: " + tokens.at(2));
        return RET_GEN_ERR_INVARG;
    }

    physicalTable = tokens.at(1);
    if (RET_GET_LEVEL((ret = this->getEntityInfo(physicalTable, locDictEntityStp, locObjectEn, locOutDynNatEn, Select))) == RET_LEV_ERROR)
    {
        return ret;
    }

    if (locDictEntityStp == NULL)
    {
        while (this->isTag(TAG_END) == false && this->getGenSqlLine())
        {
        }
        this->context->outDdlGenPtr->bodySqlBlock << this->context->outDdlGenPtr->getIndent() << this->context->outDdlGenPtr->getCmdNoOp(this) << " - unknown entity: " << physicalTable;

        if (this->ddlGenContextPtr->ddlGenAction.isBootStrapLevel())
        {
            return RET_GEN_INFO_NOACTION;
        }
        return RET_GEN_ERR_INVARG;
    }

    InitContextClass initContext(this->context);
    DdlGen locGenDdl(locObjectEn, this->context->outDdlGenPtr->targetTableEn, *this);
    this->context->currDdlGen = &locGenDdl;

    if (this->context->forcedViewEn == View_MainTable)
    {
        locCustFlg    = FALSE;
        locprecompFlg = FALSE;
    }
    else if (tokens.at(2).compare("all") == 0)
    {
        locCustFlg    = TRUE;
        locprecompFlg = TRUE;
    }
    else if (tokens.at(2).compare("all_db") == 0)
    {
        locCustFlg         = FALSE;
        locprecompFlg      = FALSE;
        locOnlyPhysicalFlg = TRUE;
    }

    switch (this->context->currTagNat)
    {
        case TagSql_SelectList:
            selListEn = SelList_List;
            locSecuLevelEn = EntSecuLevel_NoSecured;
            locCustFlg = FALSE;
            locprecompFlg = FALSE;
            break;

        case TagSql_SelectCall:
            selListEn = SelList_SelectCall;
            locSecuLevelEn = EntSecuLevel_NoSecured;
            locCustFlg = FALSE;
            locprecompFlg = FALSE;
            break;

        case TagSql_SelectDistinct:
            if (this->context->parentTagNat == TagSql_Insert && locOnlyPhysicalFlg == TRUE)
            {
                selListEn = SelList_InsertSelectDistinct;
            }
            else
            {
                selListEn = SelList_SelectDistinct;
            }
            locSecuLevelEn = this->context->outDdlGenPtr->getDefSecuredLevel();
            break;

        case TagSql_SelectInVar:
            selListEn = SelList_SelectInVar;
            locSecuLevelEn = EntSecuLevel_NoSecured;
            locCustFlg = FALSE;
            locprecompFlg = FALSE;
            break;

        case TagSql_SelectVar:
            selListEn = SelList_SelectVar;
            locSecuLevelEn = EntSecuLevel_NoSecured;
            break;

        default:
            if (this->context->parentTagNat == TagSql_Insert && locOnlyPhysicalFlg == TRUE)
            {
                selListEn = SelList_InsertSelect;
            }
            else
            {
                selListEn = SelList_Select;
            }

            locSecuLevelEn = this->context->outDdlGenPtr->getDefSecuredLevel();
    }

    if (this->ddlGenContextPtr->bAvoidSecured)
    {
        locSecuLevelEn = EntSecuLevel_NoSecured;
    }

    locGenDdl.init(locObjectEn,
                   locOutDynNatEn,
                   locCustFlg,
                   locprecompFlg,
                   locOnlyPhysicalFlg,
                   locSecuLevelEn,
                   this->context->outDdlGenPtr->translateFlg);

    locGenDdl.copy(*this->context->outDdlGenPtr);   /* PMSTA-29879 - LJE - 180712 */

    /* PMSTA-49487 - LJE - 220721 */
    if (tokens.at(2).compare("std") == 0)
    {
        locGenDdl.custFlg         = this->context->outDdlGenPtr->custFlg;
        locGenDdl.precompFlg      = this->context->outDdlGenPtr->precompFlg;
        locGenDdl.onlyPhysicalFlg = this->context->outDdlGenPtr->onlyPhysicalFlg;
    }

    if (tokens.size() > 3 &&
        tokens.at(3) != TAG_END)
    {
        if (tokens.at(3).compare("null") == 0)
        {
            locGenDdl.setAlias(std::string());

            /* Don't print "variable = " in this case */
            if (selListEn == SelList_SelectCall)
            {
                selListEn = SelList_InsertCall;
            }
        }
        else if (tokens.at(3).compare("std") != 0)
        {
            locGenDdl.setAlias(tokens.at(3));
        }
        else
        {
            locGenDdl.setAlias(locGenDdl.getDictEntityStp()->aliasSqlname);
        }
    }
    else
    {
        locGenDdl.setAlias(locGenDdl.getDictEntityStp()->aliasSqlname);
    }

    if (selListEn == SelList_SelectCall || selListEn == SelList_SelectVar)
    {
        locGenDdl.setAlias(std::string());
    }

    string savAlias = this->context->outDdlGenPtr->getAlias(true);
    this->context->outDdlGenPtr->setAlias(locGenDdl.getAlias(true));

    /* Get the real entity */
    if (tokens.size() > 4 &&
        tokens.at(4) != TAG_END)
    {
        locGenDdl.realSqlName = tokens.at(4); /* PMSTA-16194 - LJE - 130521 */
        this->getEntityInfo(locGenDdl.realSqlName, locGenDdl.realDictEntityStp, locGenDdl.realObjectEn, locOutDynNatEn, Select, false);
        if (locGenDdl.realDictEntityStp != nullptr)
        {
            locGenDdl.setSecurityLevel(locSecuLevelEn);
        }
        else
        {
            locGenDdl.realDictEntityStp = locGenDdl.getDictEntityStp();
        }
    }
    /* PMSTA-37374 - LJE - 210414 */
    else if (this->ddlGenContextPtr->m_useAlternativeDataServer)
    {
        locGenDdl.realDictEntityStp = locGenDdl.getDictEntityStp(true);
        locGenDdl.realObjectEn      = locGenDdl.realDictEntityStp->objectEn;
    }

    /* PMSTA-27463 - LJE - 170606 */
    if (this->ddlGenContextPtr->getDdlGenMode() == DdlGenMode_ValidateShadow &&
        locGenDdl.realDictEntityStp != nullptr &&
        locGenDdl.realDictEntityStp->dbRuleEn == DbRule_ShadowTable)
    {
        this->ddlGenContextPtr->setDdlGenMode(DdlGenMode_Shadow);
        this->ddlGenContextPtr->bForceUdTable = true;
        bLocalShadowAccess = true;
    }

    if (!bSimple)
    {
        while (bTagEnd == false && this->getGenSqlLine())
        {
            if (this->manageNestedTag(locGenDdl.overloadStream) == false)
            {
                if (this->context->currLineStrLTrim.size() == 0)
                {
                    continue;
                }

                if (this->isTag(TAG_ORDER))
                {
                    this->context->outDdlGenPtr->bOrderBy = true;
                    continue;
                }

                if (this->isTag(TAG_END))
                {
                    bTagEnd = true;
                    continue;
                }

                if (this->isTag(TAG_FROM))
                {
                    bTagFrom = true;
                    bTagEnd = true;
                    continue;
                }

                if (this->isTag(TAG_IF_OWNER_BUSINESS_ENTITY))
                {
                    bool bHaveOwnerBusinessEntity = false;

                    auto dictEntityStp = locGenDdl.getDictEntityStp();

                    if (dictEntityStp != nullptr &&
                        dictEntityStp->ownerBusinessEntAttrStp != nullptr)
                    {
                        bHaveOwnerBusinessEntity = true;
                    }

                    if (bHaveOwnerBusinessEntity == false)
                    {
                        while (this->readNextCurrBlock() && this->isTag(TAG_END_IF_OWNER_BUSINESS_ENTITY) == false)
                        {
                        }
                    }
                    continue;
                }
                if (this->isTag(TAG_IF_OWNER_BUSINESS_ENTITY))
                {
                    continue;
                }

                locGenDdl.overloadStream << this->context->currLineStrLTrim << endl;
            }
        }

        if (bTagEnd == false)
        {
            this->printMsg(RET_GEN_ERR_INVARG, "Missing end tag (#END)");
            return RET_GEN_ERR_INVARG;
        }
    }

    if (bTagFrom)
    {
        this->extractFromPart(&locGenDdl, locSecuLevelEn);

        if (locGenDdl.lastErrRetCode != RET_SUCCEED)
        {
            while (this->isTag(TAG_END) == false && this->getGenSqlLine())
            {
            }

            if (this->ddlGenContextPtr->ddlGenAction.isBootStrapLevel())
            {
                return RET_GEN_INFO_NOACTION;
            }
            return RET_GEN_ERR_INVARG;
        }

        if (this->isTag(TAG_WHERE))
        {
            bTagWhere = true;
        }
    }

    locGenDdl.setPreIndent(this->context->outDdlGenPtr->getPreIndent());
    locGenDdl.setIndent(this->context->outDdlGenPtr->getIndentNbr());

    /* PMSTA-26250 - LJE - 170405 */
    if (this->context->parentContextPtr &&
        this->context->parentContextPtr->currTagNat == TagSql_Insert &&
        this->ddlGenContextPtr->getDdlGenMode() == DdlGenMode_Shadow &&
        this->context->parentContextPtr->currDdlGen &&
        this->context->parentContextPtr->currDdlGen->getDictEntityStp()->changeSetAuthEn == FeatureAuth_Enable)
    {
        this->varHelperPtr->addVariable("change_set_id", "id_t");

        locGenDdl.overloadStream
            << endl << "change_set_id = @change_set_id"
            << endl << "change_set_promotion_id = @change_set_id"
            << endl << "sh_action_e = " << (int)ShadActionEnum_ToCreate << " /* ToCreate */";
    }

    /* PMSTA-36919 - LJE - 191112 */
    if (locOutDynNatEn == DynType_Null &&
        this->context->parentContextPtr != nullptr &&
        this->context->parentContextPtr->bForceOwnerBusinessEntity)
    {
        DICT_ATTRIB_STP connBusinessEntAttrStp = locGenDdl.getConnBusinessEntAttrStp(locDictEntityStp);
        if (connBusinessEntAttrStp != nullptr)
        {
            locGenDdl.overloadStream << connBusinessEntAttrStp->sqlName << " = " << locGenDdl.getConnBusinessEntityId() << endl;
        }
        this->context->bForceOwnerBusinessEntity = false;
    }

    if (this->insertList.empty() == false)
    {
        locGenDdl.insertList = this->insertList;
    }

    if ((ret = locGenDdl.printSelListRequest(selListEn)) != RET_SUCCEED)
    {
        return ret;
    }
    this->context->outDdlGenPtr->bUnion = locGenDdl.bUnion;

    if ((ret = this->checkInsertSelectList(&locGenDdl)) != RET_SUCCEED)
    {
        return ret;
    }

    bool bEmptySelect = locGenDdl.selListStream.str().empty();

    selStream << locGenDdl.selListStream.str();

    /* SELECT_LIST print only the attributes */
    if (this->context->currTagNat == TagSql_SelectList)
    {
        this->context->outDdlGenPtr->bodySqlBlock << selStream.str();
        return ret;
    }

    if (bTagFrom)
    {
        locGenDdl.setIndent(this->context->outDdlGenPtr->getIndentNbr());
        if ((ret = locGenDdl.printFromRequest()) != RET_SUCCEED)
        {
            return ret;
        }

        locGenDdl.overloadStream.clear();
        locGenDdl.overloadStream.str(std::string());

        if (bTagWhere)
        {
            this->extractWherePart(&locGenDdl, bTagEnd, unionStr);

            if (bTagEnd == false)
            {
                this->printMsg(RET_GEN_ERR_INVARG, "Missing end tag (#END)");
                return RET_GEN_ERR_INVARG;
            }
        }

        if ((ret = locGenDdl.printWhereRequest()) != RET_SUCCEED)
        {
            return ret;
        }

        locGenDdl.replaceTagAlias(locGenDdl.whereStream);   /* PRO-14029 - LJE - 210310 */

        selStream << locGenDdl.m_mainFromStream.str();
        selStream << locGenDdl.addFromStream.str();

        if (this->context->outDdlGenPtr->bOrderBy &&
            locOutDynNatEn != DynType_Short &&
            locGenDdl.orderStream.str().empty())
        {
            if (locOutDynNatEn == DynType_All && this->getOutDdlObjEn() == DdlObj_RuntimeSql)
            {
                locGenDdl.getOrderClause(locDictEntityStp, locGenDdl.m_fromStream, locGenDdl.orderStream);
            }
            else
            {
                ret = RET_DBA_ERR_INVDATA;
                this->printMsg(ret, "#ORDER used without order clause, only authorized for short structure output");
            }
        }

        selStream << locGenDdl.m_fromStream.str();
        selStream << locGenDdl.whereStream.str();
        selStream << locGenDdl.groupStream.str();

        if (this->context->outDdlGenPtr->bOrderBy)
        {
            selStream << locGenDdl.orderStream.str();
            this->context->outDdlGenPtr->bOrderBy = false;
        }

        selStream << locGenDdl.queryAddStr;
        if (unionStr.empty())
        {
            selStream << locGenDdl.limitStream.str();
        }
        selStream << locGenDdl.havingStream.str();

        if (unionStr.empty() == false)
        {
            selStream << this->context->outDdlGenPtr->newLine() << unionStr;
        }

        if (this->context->outDdlGenPtr->bNestedRequest == false)
        {
            selStream << endl;
        }
    }
    else
    {
        selStream << " " << this->context->outDdlGenPtr->getEmptyFrom();
    }

    if (bEmptySelect)
    {
        this->context->outDdlGenPtr->bodySqlBlock << this->context->outDdlGenPtr->getIndent() << DdlGenDbi::getCmdNoOp(this);
    }
    else if (selStream.str().empty() == false && (this->lastErrRetCode == RET_SUCCEED || this->ddlGenContextPtr->ddlGenAction.m_installLevel <= 5))
    {
        string selStr = selStream.str();

        if (locDictEntityStp->optimisticLockingAttrStp != NULL)
        {
            this->replaceTag(selStr, TAG_TIME_STAMP, this->context->outDdlGenPtr->getOptimisticLockingSqlName(locDictEntityStp));
        }

        if (this->outDdlObjEn == DdlObj_View ||
            this->context->outDdlGenPtr->bNestedRequest == true ||
            ((this->m_ddlObjEn == DdlObj_Sql || this->m_ddlObjEn == DdlObj_RuntimeSql) && 
             this->isInBlock() == false && 
             this-varHelperPtr->getVariableNbr() == 0))
        {
            this->context->outDdlGenPtr->bodySqlBlock << selStr;
        }
        else
        {
            this->context->outDdlGenPtr->bodySqlBlock << this->context->outDdlGenPtr->getCmdSelect(selStr, locGenDdl.cursorStream.str(), locGenDdl.initStream.str());
        }
    }

    /* PMSTA-27463 - LJE - 170606 */
    if (bLocalShadowAccess)
    {
        this->ddlGenContextPtr->bForceUdTable = false;
        this->ddlGenContextPtr->setDdlGenMode(DdlGenMode_ValidateShadow);
    }

    this->context->outDdlGenPtr->setAlias(savAlias);

    /* Install from scratch special case */
    if (this->ddlGenContextPtr->ddlGenAction.m_installLevel <= 5)
    {
        if (locGenDdl.lastErrRetCode != RET_SUCCEED)
        {
            this->lastErrRetCode = locGenDdl.lastErrRetCode;
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::createSProcSelectCheck()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-18593 - LJE - 150519
**
*************************************************************************/
RET_CODE DdlGenFromFile::createSProcSelectCheck()
{
    RET_CODE         ret = RET_SUCCEED;
    vector<string>   tokens;
    OBJECT_ENUM      locObjectEn;
    DICT_ENTITY_STP  locDictEntityStp;

    stringstream    locStream, selectStream, fromStream, whereStream, orderStream, actionStream, *currStream;

    string          alias;

    this->tokenize(tokens);

    if (tokens.size() <= 2)
    {
        this->printMsg(RET_GEN_ERR_INVARG, "Tag SELECT error: #SELECT_CHECK entity_sqlname_c dyn_nat_e(all/all_db/short/null) [alias]");
        return RET_GEN_ERR_INVARG;
    }

    string dynNat(tokens.at(2));

    DBA_DYNTYPE_ENUM locOutDynNatEn = this->getDynType(dynNat);
    if (locOutDynNatEn == DynType_Unknown)
    {
        this->printMsg(RET_GEN_ERR_INVARG, "Unknown DynType: " + dynNat);
        return RET_GEN_ERR_INVARG;
    }

    if (RET_GET_LEVEL((ret = this->getEntityInfo(tokens.at(1), locDictEntityStp, locObjectEn, locOutDynNatEn, Select))) == RET_LEV_ERROR)
    {
        return ret;
    }

    if (tokens.size() > 3)
    {
        if (tokens.at(3).compare("null") == 0)
        {
            alias.clear();
        }
        else if (tokens.at(3).compare("std") != 0)
        {
            alias = tokens.at(3);
        }
        else
        {
            alias = locDictEntityStp->aliasSqlname;
        }
    }

    currStream = &selectStream;

    while (this->getGenSqlLine())
    {
        if (this->isTag(TAG_END))
        {
            break;
        }
        else if (this->isTag(TAG_FROM))
        {
            currStream = &fromStream;
            continue;
        }
        else if (this->isTag(TAG_WHERE))
        {
            currStream = &whereStream;
            continue;
        }
        else if (this->isTag(TAG_ORDER))
        {
            currStream = &orderStream;
            continue;
        }
        else if (this->isTag(TAG_ACTION))
        {
            currStream = &actionStream;
            continue;
        }

        (*currStream) << endl << this->context->currLineStr;
    }

    /* DLA - PMSTA-28852 - 171026 - Split the too much << to run Sanitizer */
    locStream
        << this->context->outDdlGenPtr->newLine() << "#IF_EXISTS ("
        << this->context->outDdlGenPtr->newLine() << "\t\t#SELECT " << this->context->outDdlGenPtr->getEntitySqlName(locDictEntityStp) << " null " << alias;
    locStream
        << this->context->outDdlGenPtr->newLine() << "\t\t1"
        << this->context->outDdlGenPtr->newLine() << "\t\t#FROM"
        << fromStream.str()
        << this->context->outDdlGenPtr->newLine() << "\t\t#WHERE";
    locStream
        << whereStream.str()
        << this->context->outDdlGenPtr->newLine() << "\t\t#END"
        << this->context->outDdlGenPtr->newLine() << "\t\t)";
    locStream
        << this->context->outDdlGenPtr->newLine() << "#{"
        << actionStream.str()
        << this->context->outDdlGenPtr->newLine() << "\t#SELECT " << this->context->outDdlGenPtr->getEntitySqlName(locDictEntityStp) << " " << dynNat << " " << alias;
    locStream
        << selectStream.str()
        << this->context->outDdlGenPtr->newLine() << "\t#FROM"
        << fromStream.str();
    locStream
        << this->context->outDdlGenPtr->newLine() << "\t#WHERE"
        << whereStream.str();
    if (orderStream.str().empty() == false)
    {
        locStream
            << this->context->outDdlGenPtr->newLine() << "\t#ORDER"
            << orderStream.str();
    }

    locStream
        << this->context->outDdlGenPtr->newLine() << "\t#END"
        << this->context->outDdlGenPtr->newLine() << "\t#PRINT ' '"
        << this->context->outDdlGenPtr->newLine() << "#}";

    this->ddlGenContextPtr->bForceNewReturnsDef = true;
    string selCheckStr = this->context->outDdlGenPtr->scriptDdlGen->buildScript(locStream.str(), DdlObj_SProc);
    ret = this->context->outDdlGenPtr->scriptDdlGen->lastErrRetCode;

    if (selCheckStr.empty() == false)
    {
        this->context->outDdlGenPtr->bodySqlBlock << selCheckStr;
    }

    return ret;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::createSProcInsert()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-11505 - LJE - 110404
**
*************************************************************************/
RET_CODE DdlGenFromFile::createSProcInsert()
{
    RET_CODE         ret = RET_SUCCEED;
    vector<string>   tokens;
    OBJECT_ENUM      locObjectEn;
    DICT_ENTITY_STP  locDictEntityStp, pkDictEntityStp = nullptr;
    SEL_LIST_ENUM    selListEn;
    string           inInsertStr, afterInsertStr, onDuplicateKeyStr, defInsStr;
    stringstream     insertStream, pkStream;
    bool             bPrintValues = false;

    FLAG_T
        locCustFlg = FALSE,
        locprecompFlg = FALSE,
        locOnlyPhysicalFlg = TRUE;

    string newLine, newLineIndent;
    if (this->getDdlObjEn() != DdlObj_RuntimeSql)
    {
        newLine = "\n";
        newLineIndent = this->context->outDdlGenPtr->newLine();
    }

    ENTITY_SECURITY_LEVEL_ENUM locSecuLevelEn = EntSecuLevel_NoSecured;

    this->tokenize(tokens);

    if (tokens.size() < 2)
    {
        this->printMsg(RET_GEN_ERR_INVARG, "Keyword #" + this->context->currTag + ": Invalid argument");
        return RET_GEN_ERR_INVARG;
    }

    DBA_DYNTYPE_ENUM locOutDynNatEn = DynType_All;
    if (tokens.size() > 2)
    {
        locOutDynNatEn = this->getDynType(tokens.at(2));

        if (locOutDynNatEn == DynType_Unknown)
        {
            return RET_GEN_ERR_INVARG;
        }
    }

    string physicalTable = tokens.at(1);
    this->ddlGenContextPtr->bForceTableName = true;
    if ((ret = this->getEntityInfo(physicalTable, locDictEntityStp, locObjectEn, locOutDynNatEn, Insert)) != RET_SUCCEED)
    {
        this->ddlGenContextPtr->bForceTableName = false;
        return ret;
    }
    this->ddlGenContextPtr->bForceTableName = false;

    /* PMSTA-26250 - LJE - 170405 */
    if (this->ddlGenContextPtr->getDdlGenMode() == DdlGenMode_Shadow &&
        locDictEntityStp->changeSetAuthEn == FeatureAuth_Enable &&
        locDictEntityStp->dbRuleEn != DbRule_ShadowTable &&
        locDictEntityStp->shadowEntityStp != nullptr)
    {
        physicalTable = locDictEntityStp->shadowEntityStp->mdSqlName;

        if ((ret = this->getEntityInfo(physicalTable, locDictEntityStp, locObjectEn, locOutDynNatEn, Insert)) != RET_SUCCEED)
        {
            return ret;
        }
    }

    InitContextClass initContext(this->context);
    DdlGen  locGenDdl(locObjectEn, this->context->outDdlGenPtr->targetTableEn, *this);
    this->context->currDdlGen = &locGenDdl;

    this->context->outDdlGenPtr->setAlias(std::string());

    locGenDdl.init(locObjectEn,
                   locOutDynNatEn,
                   locCustFlg,
                   locprecompFlg,
                   locOnlyPhysicalFlg,
                   locSecuLevelEn,
                   FALSE);

    locGenDdl.copy(*this->context->outDdlGenPtr); /* PMSTA-29879 - LJE - 180712 */

    this->context->outDdlGenPtr->bodySqlBlock << locGenDdl.bodySqlBlock;

    if (tokens.size() > 4)
    {
        locGenDdl.realSqlName = tokens.at(4);
        physicalTable = locGenDdl.realSqlName;
    }

    while (this->getGenSqlLine() &&
           this->isTag(TAG_VALUES) == false &&
           this->isTag(TAG_END) == false &&
           this->isTag(TAG_SELECT) == false &&
           this->isTag(TAG_SELECT_DISTINCT) == false)
    {
        if (this->manageNestedTag(locGenDdl.overloadStream) == false)
        {
            locGenDdl.overloadStream << this->context->currLineStrLTrim << endl;
        }
    }

    if (this->isTag(TAG_END))
    {
        this->printMsg(RET_GEN_ERR_INVARG, "Keyword #" + this->context->currTag + ": Unexpected keyword #END");
        return RET_GEN_ERR_INVARG;
    }

    /* PMSTA-26108 - LJE - 170823 */
    if (locOutDynNatEn == DynType_Null)
    {
        DICT_ATTRIB_STP connBusinessEntAttrStp = locGenDdl.getConnBusinessEntAttrStp(locDictEntityStp);

        if (connBusinessEntAttrStp)
        {
            locGenDdl.overloadStream << connBusinessEntAttrStp->sqlName << endl;
            this->context->bForceOwnerBusinessEntity = true;
        }
    }

    /* PMSTA-nuodb - LJE - 190528 */
    if (locOutDynNatEn == DynType_Full || locOutDynNatEn == DynType_FullDb)
    {
        selListEn = SelList_InsertFull;
    }
    else
    {
        selListEn = SelList_Insert;
    }

    if ((ret = locGenDdl.printSelListRequest(selListEn)) != RET_SUCCEED)
    {
        return ret;
    }

    insertStream << this->context->outDdlGenPtr->getIndent()
        << "insert ";

    if (this->ddlGenContextPtr->m_rdbmsEn == Oracle &&
        this->ddlGenContextPtr->ddlGenAction.m_bOraNologgingHint &&
        (this->ddlGenContextPtr->getDdlObjEn() == DdlObj_Sql ||
         this->ddlGenContextPtr->getDdlObjEn() == DdlObj_RuntimeSql))
    {
        insertStream
            << "/*+ append */ ";
    }

    insertStream 
        << "into " << physicalTable;

    if (locGenDdl.selListStream.str().empty() == false)
    {
        insertStream << " (" << newLine
            << locGenDdl.selListStream.str()
            << newLineIndent << ")";
    }

    locGenDdl.clear();
    locGenDdl.bManageAuthFlg = this->context->outDdlGenPtr->bManageAuthFlg;
    locGenDdl.setAlias(std::string());
    locGenDdl.setPreIndent(this->context->outDdlGenPtr->getPreIndent());
    locGenDdl.setIndent(this->context->outDdlGenPtr->getIndentNbr());
    this->insertList = locGenDdl.selectList;

    if (this->isTag(TAG_SELECT) || this->isTag(TAG_SELECT_DISTINCT))
    {
        if (this->getDdlObjEn() != DdlObj_Sql &&
            this->getDdlObjEn() != DdlObj_RuntimeSql &&
            this->ddlGenContextPtr->ddlGenAction.m_installLevel < 6)
        {
            auto locDdlGenEntityPtr = this->ddlGenContextPtr->getDdlGenEntityPtr(locDictEntityStp->mdSqlName, locDictEntityStp->dbSqlName);

            if (locDdlGenEntityPtr != nullptr &&
                locDdlGenEntityPtr->getFeatureAuth(XdEntityFeatureFeatureEn::ChangeSet) != FeatureAuth_Forbidden)
            {
                this->printMsg(RET_DBA_INFO_NODATA, SYS_Stringer("Unsupported #INSERT ... #SELECT on entity having change set option (",
                                                                 locDictEntityStp->mdSqlName,
                                                                 "), please use #SELECT_CURSOR instead of !"));
            }
        }
        insertStream << newLine;
        this->manageNestedTag(insertStream);
    }
    else if (this->isTag(TAG_VALUES))
    {
        this->tokenize(tokens);

        if (tokens.size() > 1)
        {
            locOutDynNatEn = this->getDynType(tokens.at(1));

            locGenDdl.init(locObjectEn,
                           locOutDynNatEn,
                           locCustFlg,
                           locprecompFlg,
                           locOnlyPhysicalFlg,
                           locSecuLevelEn,
                           FALSE);

            locGenDdl.copy(*this->context->outDdlGenPtr); /* PMSTA-29879 - LJE - 180712 */
        }

        while (this->getGenSqlLine() &&
               this->isTag(TAG_END) == false &&
               this->isTag(TAG_IDENTITY) == false &&
               /* PMSTA-26252 - LJE - 170227 */
               this->isTag(TAG_ERROR) == false &&
               this->isTag(TAG_UPDATE_COUNT) == false &&
               this->isTag(TAG_ON_DUPLICATE_KEY) == false)
        {
            if (this->manageNestedTag(locGenDdl.overloadStream, TAG_END, "\t") == false)
            {
                locGenDdl.overloadStream << this->context->currLineStrLTrim << endl;
            }
        }

        /* PMSTA-26108 - LJE - 170818 */
        DICT_ATTRIB_STP connBusinessEntAttrStp = locGenDdl.getConnBusinessEntAttrStp(locDictEntityStp);
        if (connBusinessEntAttrStp && this->ddlGenContextPtr->bAvoidMultiEntity == false)
        {
            locGenDdl.overloadStream << connBusinessEntAttrStp->sqlName << " = " << locGenDdl.getConnBusinessEntityId() << endl;
        }

        bPrintValues = true;
    }

    string           identityLineStr;
    vector<string>   identityTokens;

    while (this->context->currLineStrLTrim[0] == '#')
    {
        if (this->isTag(TAG_IDENTITY))
        {
            this->tokenize(identityTokens);
            identityLineStr = this->context->currLineStrLTrim;

            this->getGenSqlLine();
        }
        else if (this->isTag(TAG_ON_DUPLICATE_KEY))
        {
            stringstream onDuplicateKeyStream;
            while (this->getGenSqlLine() &&
                   this->isTag(TAG_END) == false &&
                   this->isTag(TAG_IDENTITY) == false &&
                   /* PMSTA-26252 - LJE - 170227 */
                   this->isTag(TAG_ERROR) == false &&
                   this->isTag(TAG_UPDATE_COUNT) == false)
            {
                if (this->manageNestedTag(onDuplicateKeyStream, TAG_END, "\t") == false)
                {
                    onDuplicateKeyStream << this->context->currLineStrLTrim << endl;
                }
            }

            this->ddlGenContextPtr->m_bOnCatch = true;
            onDuplicateKeyStr = this->buildScript(onDuplicateKeyStream.str());
            this->ddlGenContextPtr->m_bOnCatch = false;

            ret = this->lastErrRetCode;
        }
        else if (this->isTag(TAG_ERROR))
        {
            string errorVar;

            vector<string>   errorTokens;
            this->tokenize(errorTokens);

            if (errorTokens.size() > 1)
            {
                errorVar = errorTokens.at(1);
            }
            else
            {
                errorVar = "@error_code";
            }

            locGenDdl.errorVarPtr = this->context->outDdlGenPtr->varHelperPtr->getNewVariable(errorVar, IntType);
            locGenDdl.errorVarPtr->strDefault = "0";

            this->getGenSqlLine();
        }
        else if (this->isTag(TAG_UPDATE_COUNT))
        {
            string rowCountVar;

            vector<string>   rowCountTokens;
            this->tokenize(rowCountTokens);

            if (rowCountTokens.size() > 1)
            {
                rowCountVar = rowCountTokens.at(1);
            }
            else
            {
                rowCountVar = "@row_count";
            }

            locGenDdl.rowCountVarPtr = this->context->outDdlGenPtr->varHelperPtr->getNewVariable(rowCountVar, IntType);
            this->getGenSqlLine();
        }
        else
        {
            break;
        }
    }

    string           identityVarStr;

    if (identityTokens.empty() &&
        locGenDdl.getDictEntityStp()->pkRuleEn == PkRule_ExternalPk &&
        locGenDdl.getDictEntityStp()->pkEntityStp != nullptr &&
        locGenDdl.getDictEntityStp()->dbRuleEn != DbRule_ShadowTable &&
        locGenDdl.getDictEntityStp()->dbRuleEn != DbRule_PartialSpecialization &&   /* PMSTA-32145 - LJE - 180719 */
        locGenDdl.targetTableEn != TargetTable_UserDefinedFields &&
        this->ddlGenContextPtr->getDdlGenMode() != DdlGenMode_ValidateShadow &&
        this->getDdlObjEn() != DdlObj_Sql &&
        this->getDdlObjEn() != DdlObj_RuntimeSql)
    {
        identityLineStr = "#IDENTITY";
        identityTokens.push_back(identityLineStr);

        identityVarStr = "@";
        identityVarStr += locGenDdl.getDictEntityStp()->shortSqlname;
        identityVarStr += "_";
        identityVarStr += locGenDdl.getDictEntityStp()->primKeyTab[0]->sqlName;
        identityTokens.push_back(identityVarStr);
        identityLineStr += " " + identityVarStr;

        (void)this->varHelperPtr->addVariable(identityVarStr, IdType);
    }

    if (identityTokens.empty() == false)
    {
        if (locDictEntityStp->pkRuleEn == PkRule_ExternalPk)
        {
            pkStream << newLineIndent << identityLineStr;

            if (identityTokens.size() > 1 &&
                locGenDdl.getDictEntityStp()->pkRuleEn == PkRule_ExternalPk &&
                locGenDdl.getDictEntityStp()->primKeyNbr > 0)
            {
                identityVarStr = identityTokens.at(1);
                locGenDdl.overloadStream
                    << endl << locGenDdl.getDictEntityStp()->primKeyTab[0]->sqlName << " = " << identityTokens.at(1);
            }
        }
        else
        {
            if ((locGenDdl.getDictEntityStp()->pkRuleEn == PkRule_Identity &&
                 locGenDdl.getDictEntityStp()->primKeyNbr > 0) ||
                (pkDictEntityStp &&
                 pkDictEntityStp->pkRuleEn == PkRule_Identity &&
                 pkDictEntityStp->primKeyNbr > 0)) /* PMSTA-27179 - LJE - 170520 */
            {
                if (identityTokens.size() == 1)
                {
                    if (pkDictEntityStp)
                    {
                        identityVarStr = pkDictEntityStp->primKeyTab[0]->sqlName;
                    }
                    else
                    {
                        identityVarStr = locGenDdl.getDictEntityStp()->primKeyTab[0]->sqlName;
                    }
                }
                else
                {
                    identityVarStr = identityTokens.at(1);
                }
                DdlGenVar* variable = this->varHelperPtr->getVariable(identityVarStr);
                locGenDdl.getCmdReturnIdentityValue(locGenDdl.getDictEntityStp()->primKeyTab[0], variable, inInsertStr, afterInsertStr);
                if (variable != nullptr)
                {
                    variable->setOut(true);
                }
                else
                {
                    this->ddlGenContextPtr->m_outputVariableVector.push_back(DbiInputParam(locGenDdl.getDictEntityStp()->primKeyTab[0]->sqlName,
                                                                                           locGenDdl.getDictEntityStp()->primKeyTab[0]->dataTpProgN));
                }
            }
            else if (identityTokens.size() != 1)
            {
                this->printMsg(RET_GEN_ERR_INVARG, "Keyword #" + this->context->currTag + ": Invalid keyword #" + TAG_IDENTITY);
                ret = RET_GEN_ERR_INVARG;
            }
        }
    }

    /* PMSTA-26250 - LJE - 170421 */
    if (bPrintValues)
    {
        defInsStr = insertStream.str();     /* Copy insertStream to Use for MSQL. */
        insertStream
            << newLineIndent << " values"
            << newLineIndent << "(";

        /* PMSTA-26250 - LJE - 170405 */
        if (this->ddlGenContextPtr->getDdlGenMode() == DdlGenMode_Shadow &&
            locDictEntityStp->changeSetAuthEn == FeatureAuth_Enable)
        {
            this->varHelperPtr->addVariable("change_set_id", "id_t");

            locGenDdl.overloadStream
                << endl << "change_set_promotion_id = @change_set_id"
                << endl << "sh_action_e = " << (int)ShadActionEnum_ToCreate << " /* ToCreate */";
        }

        if (locOutDynNatEn == DynType_Null)
        {
            selListEn = SelList_Insert;
            insertStream << newLine;
        }
        else if (locOutDynNatEn == DynType_Full || locOutDynNatEn == DynType_FullDb)
        {
            selListEn = SelList_InsertFullCall;
        }
        else
        {
            selListEn = SelList_InsertCall;
        }

        if ((ret = locGenDdl.printSelListRequest(selListEn)) != RET_SUCCEED)
        {
            return ret;
        }

        if (this->getDdlObjEn() == DdlObj_RuntimeSql &&
            locOutDynNatEn == DynType_Null &&
            locGenDdl.selectList.empty() &&
            this->insertList.empty() == false)
        {
            for (auto it = this->insertList.begin(); it != this->insertList.end(); ++it)
            {
                this->ddlGenContextPtr->m_inputVariableVector.push_back(DbiInputParam((it->sqlName.empty() ? it->value : it->sqlName), it->datatype));

                if (it != this->insertList.begin())
                {
                    locGenDdl.selListStream << ", ";
                }
                locGenDdl.selListStream << "?";
            }
        }
        else if ((ret = this->checkInsertSelectList(&locGenDdl)) != RET_SUCCEED)
        {
            return ret;
        }

        if (locGenDdl.selListStream.str().empty() == false)
        {
            insertStream << locGenDdl.selListStream.str();
            insertStream << newLineIndent << ")";
        }
        else
        {
            switch (this->ddlGenContextPtr->m_rdbmsEn)
            {
            case Oracle:
                insertStream << "NULL";
                insertStream << newLineIndent << ")";
                break;

            case MSSql:
                insertStream.clear();
                insertStream.str(std::string());
                insertStream << defInsStr << " default values";
                break;

            case PostgreSQL:
                insertStream << "default";
                insertStream << newLineIndent << ")";
                break;

            case Sybase:
            case Nuodb:
            default:
                insertStream << locGenDdl.selListStream.str();
                insertStream << newLineIndent << ")";
                break;
            }
        }
    }

    this->insertList.clear();

    if (locDictEntityStp->pkRuleEn == PkRule_ExternalPk &&
        locGenDdl.targetTableEn != TargetTable_UserDefinedFields &&
        this->ddlGenContextPtr->getDdlGenMode() != DdlGenMode_ValidateShadow &&
        locDictEntityStp->pkEntityStp &&
        (this->parentScriptTagNat == TagSql_Body || this->parentScriptTagNat == TagSql_Insert) &&
        this->getDdlObjEn() != DdlObj_Sql &&
        this->getDdlObjEn() != DdlObj_RuntimeSql)                                                          /* PMSTA-nuodb - LJE - 190531 */
    {
        stringstream    insPkStream;

        insPkStream
            << this->context->outDdlGenPtr->newLine() << "#INSERT " << locDictEntityStp->pkEntityStp->mdSqlName << " all_db"
            << this->context->outDdlGenPtr->newLine() << "#VALUES";

        if (locGenDdl.getDictEntityStp()->changeSetAuthEn == FeatureAuth_Enable)
        {
            if (this->ddlGenContextPtr->getDdlGenMode() == DdlGenMode_Shadow)
            {
                insPkStream
                    << this->context->outDdlGenPtr->newLine() << "obj_status_e = " << (int)ObjStatus_Working << " /* Working */";
            }
            else
            {
                insPkStream
                    << this->context->outDdlGenPtr->newLine() << "obj_status_e = " << (int)ObjStatus_Validated << " /* Validated */";
            }
        }

        if (pkStream.str().empty() == false)
        {
            insPkStream << pkStream.str();
        }

        insPkStream
            << this->context->outDdlGenPtr->newLine() << "#END";

        locGenDdl.bodySqlBlock << this->buildScript(insPkStream.str(), this->outDdlObjEn, -1);
    }

    insertStream << inInsertStr << newLineIndent << this->context->outDdlGenPtr->getCmdEndOfCmd();

    if (afterInsertStr.empty() == false)
    {
        insertStream
            << newLineIndent << afterInsertStr << this->context->outDdlGenPtr->getCmdEndOfCmd();
    }

    if (this->getDdlObjEn() != DdlObj_RuntimeSql)
    {
        this->ddlGenContextPtr->m_dependsAccessSet.insert(DdlGenDependKey(locDictEntityStp->entDictId,
                                                          locDictEntityStp->mdSqlName,
                                                          DictDependsAccessEn::Insert,
                                                          locOutDynNatEn)); /* PMSTA-29956 - LJE - 180125 */
    }

    locGenDdl.bodySqlBlock
        << this->context->outDdlGenPtr->getCmdInsert(insertStream.str(), onDuplicateKeyStr);

    this->context->outDdlGenPtr->printOptimisticLockingClause(locGenDdl, locDictEntityStp, *this);
    locGenDdl.bodySqlBlock << locGenDdl.footerStream.str();

    this->context->outDdlGenPtr->printShadowManagement(locGenDdl, *this); /* PMSTA-26250 - LJE - 170403 */

    this->context->outDdlGenPtr->bodySqlBlock << locGenDdl.bodySqlBlock.str();

    this->context->bForceOwnerBusinessEntity = false;

    if (this->isTag(TAG_END) == false)
    {
        this->printMsg(RET_GEN_ERR_INVARG, "Keyword #" + this->context->currTag + ": Missing keyword #END");
        return RET_GEN_ERR_INVARG;
    }

    return ret;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::createSProcUpdate()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-11505 - LJE - 110404
**
*************************************************************************/
RET_CODE DdlGenFromFile::createSProcUpdate()
{
    RET_CODE         ret = RET_SUCCEED;
    vector<string>   tokens;
    OBJECT_ENUM      locObjectEn      = NullEntity;
    DICT_ENTITY_STP  locDictEntityStp = nullptr;
    SEL_LIST_ENUM    selListEn        = SelList_Select;
    bool             bUpdateNew = false, bAssignOnNew = false, bEmptyUpdate = false;
    FLAG_T
        locCustFlg = FALSE,
        locprecompFlg = FALSE,
        locOnlyPhysicalFlg = TRUE;

    ENTITY_SECURITY_LEVEL_ENUM locSecuLevelEn = EntSecuLevel_NoSecured;

    this->tokenize(tokens);

    if (tokens.size() < 3)
    {
        this->printMsg(RET_GEN_ERR_INVARG, "Keyword #" + this->context->currTag + ": Invalid argument (#UPDATE <entity> <access>)");
        return RET_GEN_ERR_INVARG;
    }

    if (this->context->currTag.compare(TAG_UPDATE_NEW) == 0)
    {
        if (this->trgPosEn == TriggerPos_AfterEachRow ||
            this->trgPosEn == TriggerPos_After ||
            this->trgPosEn == TriggerPos_Before)
        {
            this->printMsg(RET_GEN_ERR_INVARG, "Keyword #" + this->context->currTag + " is only available on \"Before Each Row\" section!");
            return RET_GEN_ERR_INVARG;
        }

        bUpdateNew = true;
    }

    DBA_DYNTYPE_ENUM locOutDynNatEn = this->getDynType(tokens.at(2));
    if (locOutDynNatEn == DynType_Unknown)
    {
        return RET_GEN_ERR_INVARG;
    }

    string physicalTable = tokens.at(1);
    this->ddlGenContextPtr->bForceTableName = true;
    if ((ret = this->getEntityInfo(physicalTable, locDictEntityStp, locObjectEn, locOutDynNatEn, Update)) != RET_SUCCEED)
    {
        this->ddlGenContextPtr->bForceTableName = false;
        return ret;
    }
    this->ddlGenContextPtr->bForceTableName = false;

    /* PMSTA-26250 - LJE - 170405 */
    if (this->ddlGenContextPtr->getDdlGenMode() == DdlGenMode_Shadow &&
        locDictEntityStp->changeSetAuthEn == FeatureAuth_Enable &&
        locDictEntityStp->dbRuleEn != DbRule_ShadowTable &&
        locDictEntityStp->shadowEntityStp != nullptr)
    {
        physicalTable = locDictEntityStp->shadowEntityStp->mdSqlName;

        if ((ret = this->getEntityInfo(physicalTable, locDictEntityStp, locObjectEn, locOutDynNatEn, Update)) != RET_SUCCEED)
        {
            return ret;
        }
    }

    InitContextClass initContext(this->context);
    DdlGen locGenDdl(locObjectEn, this->context->outDdlGenPtr->targetTableEn, *this);
    this->context->currDdlGen = &locGenDdl;

    locGenDdl.init(locObjectEn,
                   locOutDynNatEn,
                   locCustFlg,
                   locprecompFlg,
                   locOnlyPhysicalFlg,
                   locSecuLevelEn,
                   FALSE);

    locGenDdl.copy(*this->context->outDdlGenPtr);   /* PMSTA-29879 - LJE - 180712 */

    if (bUpdateNew == true &&
        locGenDdl.isUpdateOnTriggerByAssign() == true)
    {
        bAssignOnNew = true;
    }

    locGenDdl.setAlias(std::string());
    if (tokens.size() > 3)
    {
        if (tokens.at(3).compare("null") == 0)
        {
            locGenDdl.setAlias(std::string());
        }
        else if (tokens.at(3).compare("std") != 0)
        {
            locGenDdl.setAlias(tokens.at(3));
        }
    }

    if (tokens.size() > 4)
    {
        locGenDdl.realSqlName = tokens.at(4);
        physicalTable = locGenDdl.realSqlName;
    }

    while (this->getGenSqlLine() && this->isTag(TAG_FROM) == false && this->isTag(TAG_WHERE) == false && this->isTag(TAG_END) == false)
    {
        if (this->manageNestedTag(locGenDdl.overloadStream) == false)
        {
            locGenDdl.overloadStream << this->context->currLineStrLTrim << endl;
        }
    }

    if (bAssignOnNew)
    {
        selListEn = SelList_Assign;
        locGenDdl.setAlias(locGenDdl.getNewAlias());
    }
    else
    {
        selListEn = SelList_Update;
    }

    /* PMSTA-26250 - LJE - 170405 */
    if (this->ddlGenContextPtr->getDdlGenMode() == DdlGenMode_Shadow &&
        locGenDdl.getDictEntityStp()->dbRuleEn == DbRule_ShadowTable &&
        locOutDynNatEn != DynType_Null)
    {
        locGenDdl.overloadStream
            << endl << "-change_set_id"
            << endl << "-change_set_promotion_id"
            << endl << "-sh_action_e";
    }

    if ((ret = locGenDdl.printSelListRequest(selListEn)) != RET_SUCCEED)
    {
        if (ret == RET_DBA_INFO_NODATA)
        {
            bEmptyUpdate = true;
        }
        else
        {
            this->printMsg(ret, "Keyword #" + this->context->currTag + ": Unexpected error");
            return ret;
        }
    }

    if (this->isTag(TAG_FROM))
    {
        this->extractFromPart(&locGenDdl, locSecuLevelEn);
        if (locGenDdl.addedJoinTab.size() > 0 &&
            (ret = locGenDdl.printFromRequest()) != RET_SUCCEED)
        {
            return ret;
        }
        if (locGenDdl.addFromStream.str().empty() == false)
        {
            locGenDdl.addFromStream << locGenDdl.newLine();
        }
    }

    locGenDdl.overloadStream.clear();
    locGenDdl.overloadStream.str(std::string());

    if (this->isTag(TAG_WHERE))
    {
        if (bUpdateNew)
        {
            locGenDdl.overloadStream << locGenDdl.getPkAccessWhere(NULL, NULL, "", "#NEW", true);
        }

        bool bTagEnd = false;
        string unionStr;

        this->extractWherePart(&locGenDdl, bTagEnd, unionStr);
    }

    /* PMSTA-26250 - LJE - 170405 */
    if (this->ddlGenContextPtr->getDdlGenMode() == DdlGenMode_Shadow &&
        locGenDdl.getDictEntityStp()->dbRuleEn == DbRule_ShadowTable &&
        this->context->outDdlGenPtr->targetTableEn == TargetTable_Main)
    {
        this->varHelperPtr->addVariable("change_set_id", "id_t");

        locGenDdl.overloadStream
            << endl << "change_set_id = @change_set_id"
            << endl << "change_set_id = change_set_promotion_id";
    }

    if (bAssignOnNew == false)  /* PMSTA-26108 - LJE - 170819 */
    {
        if ((ret = locGenDdl.printWhereRequest()) != RET_SUCCEED)
        {
            return ret;
        }
    }

    if (bEmptyUpdate)
    {
        this->context->outDdlGenPtr->bodySqlBlock << this->context->outDdlGenPtr->getIndent() << DdlGenDbi::getCmdNoOp(this);
    }
    else
    {
        this->context->outDdlGenPtr->printOptimisticLockingClause(locGenDdl, locDictEntityStp, *this);

        if (bAssignOnNew)
        {
            locGenDdl.bodySqlBlock << locGenDdl.selListStream.str() << endl;
        }
        else
        {
            /* Check trigger consistency data */
            if (this->getOutDdlObjEn() == DdlObj_TriggerBody &&
                this->bInManualTrg &&
                this->ddlGenContextPtr->dmlEventEn == DmlEvent_Delete)
            {
                if (locGenDdl.whereDepList.size())
                {
                    for (list<DdlGenWhereDep>::iterator it = locGenDdl.whereDepList.begin(); it != locGenDdl.whereDepList.end(); it++)
                    {
                        if (it->mainObjAttribStp != NULL)
                        {
                            DICT_ATTRIB_STP refDelAttribStp = NULL;

                            if (it->leftAttribStp != NULL &&
                                locGenDdl.getAlias(true).compare(it->leftAliasStr) == 0)
                            {
                                refDelAttribStp = it->leftAttribStp;
                            }
                            else if (it->rightAttribStp != NULL &&
                                     locGenDdl.getAlias(true).compare(it->rightAliasStr) == 0)
                            {
                                refDelAttribStp = it->rightAttribStp;
                            }

                            DICT_ATTRIB_STP linkedAttribStp = DBA_GetLinkAttribStp(refDelAttribStp);
                            if (linkedAttribStp != NULL &&
                                linkedAttribStp->refDeleteRuleEn != RefDelRule_None &&
                                linkedAttribStp->refDeleteRuleEn != RefDelRule_NoAction)
                            {
                                for (list<DdlSelectElt>::iterator itSet = locGenDdl.selectList.begin(); itSet != locGenDdl.selectList.end(); itSet++)
                                {
                                    if (itSet->sqlName.compare(refDelAttribStp->sqlName) == 0)
                                    {
                                        ret = RET_DBA_ERR_INVDATA;
                                        this->context->outDdlGenPtr->printMsg(ret,
                                                                              "It's not allowed to customize the trigger (UPDATE) on attribute (" +
                                                                              physicalTable + "." + refDelAttribStp->sqlName + ") having reference delete rule defined!");
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
            }

            this->ddlGenContextPtr->m_dependsAccessSet.insert(DdlGenDependKey(locDictEntityStp->entDictId, 
                                                                              locDictEntityStp->mdSqlName, 
                                                                              DictDependsAccessEn::Update, 
                                                                              locOutDynNatEn)); /* PMSTA-29956 - LJE - 180125 */

            locGenDdl.replaceTagAlias(locGenDdl.whereStream);   /* PRO-14029 - LJE - 210310 */

            locGenDdl.bodySqlBlock << locGenDdl.getUpdateRequest(physicalTable,
                                                                 locGenDdl.selListStream.str(),
                                                                 locGenDdl.m_mainFromStream.str(),
                                                                 locGenDdl.addFromStream.str(),
                                                                 locGenDdl.m_fromStream.str(),
                                                                 locGenDdl.whereStream.str());
            locGenDdl.bodySqlBlock << locGenDdl.endOfCmd();

            locGenDdl.bodySqlBlock << locGenDdl.footerStream.str(); /* PMSTA-23385 - LJE - 160712 */
        }

        /* PMSTA-26250 - LJE - 170403 */
        this->context->outDdlGenPtr->printShadowManagement(locGenDdl, *this);

        if (locDictEntityStp->multiEntityCateg.isInsUpdOnLocalBe() &&
            (locGenDdl.bPkWhereAccess || locGenDdl.bBkWhereAccess) &&
            locDictEntityStp->ownerBusinessEntAttrStp != nullptr &&
            (locOutDynNatEn == DynType_All || locOutDynNatEn == DynType_AllDb))
        {
            stringstream insertStream;

            bool bConnBEVarAvailable = this->varHelperPtr->getVariable(locDictEntityStp->ownerBusinessEntAttrStp->sqlName, false) != nullptr;

            if (bConnBEVarAvailable == false && locGenDdl.bBkWhereAccess)
            {
                DdlGenVar*  connBEVar = this->varHelperPtr->getNewVariable(locDictEntityStp->ownerBusinessEntAttrStp->sqlName, locDictEntityStp->ownerBusinessEntAttrStp->dataTpProgN);
                insertStream
                    << this->context->outDdlGenPtr->newLine() << "#SELECT " << locDictEntityStp->mdSqlName << " null "
                    << this->context->outDdlGenPtr->newLine() << "@" << connBEVar->sqlName << " = " << locDictEntityStp->ownerBusinessEntAttrStp->sqlName
                    << this->context->outDdlGenPtr->newLine() << "#FROM"
                    << this->context->outDdlGenPtr->newLine() << "#WHERE"
                    << this->context->outDdlGenPtr->newLine() << "bk"
                    << this->context->outDdlGenPtr->newLine() << "#END";

                bConnBEVarAvailable = true;
            }

            if (bConnBEVarAvailable)
            {
                insertStream
                    << this->context->outDdlGenPtr->newLine() << "#IF @" << locDictEntityStp->ownerBusinessEntAttrStp->sqlName << " <> " << this->context->outDdlGenPtr->getConnBusinessEntityId()
                    << this->context->outDdlGenPtr->newLine() << "#{";
                this->context->outDdlGenPtr->setIndent(1);
                insertStream
                    << this->context->outDdlGenPtr->newLine() << "#INSERT " << locDictEntityStp->mdSqlName << " all_db "
                    << this->context->outDdlGenPtr->newLine() << "#VALUES"
                    << this->context->outDdlGenPtr->newLine() << "#END";
                this->context->outDdlGenPtr->setIndent(-1);
                insertStream
                    << this->context->outDdlGenPtr->newLine() << "#}"
                    << this->context->outDdlGenPtr->newLine() << "#ELSE"
                    << this->context->outDdlGenPtr->newLine() << "#{"
                    << this->context->outDdlGenPtr->newLine() << locGenDdl.bodySqlBlock.str()
                    << this->context->outDdlGenPtr->newLine() << "#}";

                this->context->outDdlGenPtr->bodySqlBlock << this->buildScript(insertStream.str());
            }
            else
            {
                this->context->outDdlGenPtr->bodySqlBlock << locGenDdl.bodySqlBlock.str();
            }
        }
        else
        {
            this->context->outDdlGenPtr->bodySqlBlock << locGenDdl.bodySqlBlock.str();
        }

        if (locDictEntityStp->beEntityStp != nullptr)
        {
            if (locGenDdl.bPkWhereAccess &&
                (locOutDynNatEn == DynType_All || locOutDynNatEn == DynType_AllDb || locOutDynNatEn == DynType_UdOnly))
            {
                this->ddlGenContextPtr->bPartialSpecialization = true;
            }
            else if (locOutDynNatEn != DynType_MeSpecOnly &&
                     locOutDynNatEn != DynType_UdMeSpecOnly)
            {
                /* Check if update is authorized according the partial specialization */
                for (auto updIt = locGenDdl.selectList.begin(); updIt != locGenDdl.selectList.end(); ++updIt)
                {
                    if (updIt->attribStp != nullptr && updIt->attribStp->meSpecialisationEn != MeSpecialisation_NotApplicable)
                    {
                        ret = RET_DBA_ERR_INVDATA;
                        this->printMsg(ret, "Is not allowed to update (#UPDATE <sqlname> null) an attribute having partial specialization behavior (" + updIt->sqlName + ")");
                    }
                }
            }
        }
    }

    if (this->isTag(TAG_END) == false)
    {
        ret = RET_GEN_ERR_INVARG;
        this->printMsg(ret, "Keyword #" + this->context->currTag + ": Missing keyword #END");
    }

    return ret;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::createSProcDelete()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  ORACLE - LJE - 141016
**
*************************************************************************/
RET_CODE DdlGenFromFile::createSProcDelete()
{
    RET_CODE         ret                = RET_SUCCEED;
    vector<string>   tokens;
    OBJECT_ENUM      locObjectEn        = NullEntity;
    DICT_ENTITY_STP  locDictEntityStp   = nullptr;
    FLAG_T           locCustFlg         = FALSE,
                     locprecompFlg      = FALSE,
                     locOnlyPhysicalFlg = TRUE;
    vector<string>   pkList;
    string           locAlias;

    DDL_GEN_MODE_ENUM oriDdlGenMode = this->ddlGenContextPtr->getDdlGenMode();

    ENTITY_SECURITY_LEVEL_ENUM locSecuLevelEn = EntSecuLevel_NoSecured;

    this->tokenize(tokens);

    if (tokens.size() < 2)
    {
        this->printMsg(RET_GEN_ERR_INVARG, "Keyword #" + this->context->currTag + ": Invalid argument (#DELETE <entity>)");
        return RET_GEN_ERR_INVARG;
    }

    DBA_DYNTYPE_ENUM locOutDynNatEn = DynType_Null;

    string physicalTable = tokens.at(1);
    this->ddlGenContextPtr->bForceTableName = true;
    this->ddlGenContextPtr->setDdlGenMode(DdlGenMode_Standard);
    if ((ret = this->getEntityInfo(physicalTable, locDictEntityStp, locObjectEn, locOutDynNatEn, Delete)) != RET_SUCCEED)
    {
        this->ddlGenContextPtr->bForceTableName = false;
        return ret;
    }
    this->ddlGenContextPtr->setDdlGenMode(oriDdlGenMode);
    this->ddlGenContextPtr->bForceTableName = false;

    /* PMSTA-26250 - LJE - 170405 */
    if (this->ddlGenContextPtr->getDdlGenMode() == DdlGenMode_Shadow &&
        locDictEntityStp->changeSetAuthEn == FeatureAuth_Enable &&
        locDictEntityStp->dbRuleEn != DbRule_ShadowTable &&
        locDictEntityStp->shadowEntityStp != nullptr)
    {
        physicalTable = locDictEntityStp->shadowEntityStp->mdSqlName;

        if ((ret = this->getEntityInfo(physicalTable, locDictEntityStp, locObjectEn, locOutDynNatEn, Delete)) != RET_SUCCEED)
        {
            return ret;
        }
    }

    InitContextClass initContext(this->context);
    DdlGen locGenDdl(locObjectEn, this->context->outDdlGenPtr->targetTableEn, *this);
    this->context->currDdlGen = &locGenDdl;

    locGenDdl.init(locObjectEn,
                   locOutDynNatEn,
                   locCustFlg,
                   locprecompFlg,
                   locOnlyPhysicalFlg,
                   locSecuLevelEn,
                   FALSE);

    locGenDdl.copy(*this->context->outDdlGenPtr);   /* PMSTA-29879 - LJE - 180712 */

    locGenDdl.setAlias(std::string());
    if (tokens.size() > 2)
    {
        if (tokens.at(2).compare("null") == 0)
        {
            locGenDdl.setAlias(std::string());
        }
        else if (tokens.at(2).compare("std") != 0)
        {
            locGenDdl.setAlias(tokens.at(2));
        }
    }

    while (this->getGenSqlLine() && this->isTag(TAG_FROM) == false && this->isTag(TAG_WHERE) == false && this->isTag(TAG_END) == false)
    {
    }

    if (this->isTag(TAG_FROM))
    {
        this->extractFromPart(&locGenDdl, locSecuLevelEn);
        if ((ret = locGenDdl.printFromRequest()) != RET_SUCCEED)
        {
            return ret;
        }
    }

    locGenDdl.overloadStream.clear();
    locGenDdl.overloadStream.str(std::string());

    if (this->isTag(TAG_WHERE))
    {
        bool bTagEnd = false;
        string unionStr;

        this->extractWherePart(&locGenDdl, bTagEnd, unionStr);
    }

    /* PMSTA-26250 - LJE - 170405 */
    if (this->ddlGenContextPtr->getDdlGenMode() == DdlGenMode_Shadow &&
        locGenDdl.getDictEntityStp()->dbRuleEn == DbRule_ShadowTable)
    {
        this->varHelperPtr->addVariable("change_set_id", "id_t");

        locGenDdl.overloadStream
            << endl << "change_set_id = @change_set_id"
            << endl << "change_set_id = change_set_promotion_id";
    }

    if ((ret = locGenDdl.printWhereRequest()) != RET_SUCCEED)
    {
        return ret;
    }

    this->context->outDdlGenPtr->printOptimisticLockingClause(locGenDdl, locDictEntityStp, *this);

    if (locDictEntityStp->dbPKNbr)
    {
        for (int i = 0; i < locDictEntityStp->dbPKNbr; i++)
        {
            pkList.push_back(locDictEntityStp->dbPKTab[i]->sqlName);
        }
    }
    else
    {
        for (int i = 0; i < locDictEntityStp->bkAttrNbr; i++)
        {
            pkList.push_back(locDictEntityStp->bkAttr[i]->sqlName);
        }
    }

    locAlias = locGenDdl.getAlias(true);

    /* Check trigger consistency data */
    if (this->getOutDdlObjEn() == DdlObj_TriggerBody &&
        this->bInManualTrg &&
        this->ddlGenContextPtr->dmlEventEn == DmlEvent_Delete)
    {
        if (locGenDdl.whereDepList.size())
        {
            for (auto it = locGenDdl.whereDepList.begin(); it != locGenDdl.whereDepList.end(); ++it)
            {
                if (it->mainObjAttribStp != NULL)
                {
                    DICT_ATTRIB_STP refDelAttribStp = NULL;
                    DICT_ATTRIB_STP currAttribStp = NULL;

                    if (it->leftAttribStp != NULL &&
                        locAlias.compare(it->leftAliasStr) == 0)
                    {
                        refDelAttribStp = it->leftAttribStp;
                        currAttribStp = it->rightAttribStp;
                    }
                    else if (it->rightAttribStp != NULL &&
                             locAlias.compare(it->rightAliasStr) == 0)
                    {
                        refDelAttribStp = it->rightAttribStp;
                        currAttribStp = it->leftAttribStp;
                    }

                    DICT_ATTRIB_STP checkAttribStp = refDelAttribStp;

                    if (checkAttribStp != NULL)
                    {
                        if (currAttribStp == NULL ||
                            currAttribStp->entDictId == refDelAttribStp->refEntDictId)
                        {
                            if (checkAttribStp->refDeleteRuleEn == RefDelRule_Inherited)
                            {
                                checkAttribStp = DBA_GetLinkAttribStp(refDelAttribStp);
                            }

                            if (checkAttribStp != NULL &&
                                checkAttribStp->refDeleteRuleEn != RefDelRule_None &&
                                checkAttribStp->refDeleteRuleEn != RefDelRule_NoAction)
                            {
                                ret = RET_DBA_ERR_INVDATA;
                                this->context->outDdlGenPtr->printMsg(ret,
                                                                      "It's not allowed to customize the trigger (DELETE) on attribute (" +
                                                                      physicalTable + "." + refDelAttribStp->sqlName + ") having reference delete rule defined!");
                                break;
                            }
                        }
                    }
                }
            }
        }
    }

    this->ddlGenContextPtr->m_dependsAccessSet.insert(DdlGenDependKey(locDictEntityStp->entDictId, 
                                                                      locDictEntityStp->mdSqlName, 
                                                                      DictDependsAccessEn::Delete, 
                                                                      DynType_Null)); /* PMSTA-29956 - LJE - 180125 */

    if (locDictEntityStp->pkEntityStp != nullptr &&
        this->context->outDdlGenPtr->targetTableEn == TargetTable_Main &&
        locDictEntityStp->dbRuleEn != DbRule_ShadowTable &&
        this->ddlGenContextPtr->getDdlGenMode() != DdlGenMode_Shadow)
    {
        bool bPk = false;

        for (auto it = locGenDdl.whereDepList.begin(); it != locGenDdl.whereDepList.end(); ++it)
        {
            if (it->rightAttribStp != nullptr &&
                it->rightAttribStp->entDictId == locDictEntityStp->entDictId &&
                it->rightAttribStp->primFlg == TRUE)
            {
                bPk = true;
            }
            else if (it->leftAttribStp != nullptr &&
                it->leftAttribStp->entDictId == locDictEntityStp->entDictId &&
                it->leftAttribStp->primFlg == TRUE)
            {
                bPk = true;
            }
        }

        if (static_cast<INT_T>(locGenDdl.whereDepList.size()) != locDictEntityStp->primKeyNbr ||
            bPk == false)
        {
            locGenDdl.m_mainFromStream.clear();
            locGenDdl.m_mainFromStream.str(string());

            if (locAlias.empty())
            {
                locAlias = "E";

                locGenDdl.setAlias(locAlias);
            }
            locGenDdl.m_mainFromStream << "from ";

            if (locGenDdl.m_joinCpt > 0)
            {
                for (int i = 0; i < locGenDdl.m_joinCpt; ++i)
                {
                    locGenDdl.m_mainFromStream << "(";
                }

            }
            locGenDdl.m_mainFromStream << physicalTable << " pkE";

            stringstream locFromStream;

            locFromStream << " inner join " << locGenDdl.getEntityFullSqlName(locDictEntityStp) << " " << locAlias << " on ";
            for (int i = 0; i < locDictEntityStp->primKeyNbr; ++i)
            {
                locFromStream << "pkE." << locDictEntityStp->primKeyTab[i]->sqlName << " = " << locAlias << "." << locDictEntityStp->primKeyTab[i]->sqlName;
            }
            locFromStream << " " << locGenDdl.m_fromStream.str();

            locGenDdl.m_fromStream.clear();
            locGenDdl.m_fromStream.str(string());
            locGenDdl.m_fromStream << locFromStream.str();
        }
    }

    locGenDdl.replaceTagAlias(locGenDdl.whereStream);   /* PRO-14029 - LJE - 210310 */

    locGenDdl.bodySqlBlock << locGenDdl.getDeleteRequest(physicalTable,
                                                         locAlias,
                                                         locGenDdl.m_mainFromStream.str(),
                                                         locGenDdl.addFromStream.str(),
                                                         locGenDdl.m_fromStream.str(),
                                                         locGenDdl.whereStream.str(),
                                                         pkList);

    locGenDdl.bodySqlBlock << locGenDdl.footerStream.str(); /* PMSTA-23385 - LJE - 160712 */

    /* PMSTA-26250 - LJE - 170403 */
    this->context->outDdlGenPtr->printShadowManagement(locGenDdl, *this);
    this->context->outDdlGenPtr->bodySqlBlock << locGenDdl.bodySqlBlock.str();

    /* PMSTA-32145 - LJE - 180720 */
    if (locDictEntityStp->beEntityStp != nullptr && locGenDdl.bPkWhereAccess)
    {
        this->ddlGenContextPtr->bPartialSpecialization = true;
    }

    if (this->isTag(TAG_END) == false)
    {
        this->printMsg(RET_GEN_ERR_INVARG, "Keyword #" + this->context->currTag + ": Missing keyword #END");
        return RET_GEN_ERR_INVARG;
    }

    return ret;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::createSProcTruncate()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  ORACLE - LJE - 141016
**
*************************************************************************/
RET_CODE DdlGenFromFile::createSProcTruncate(bool bForce)
{
    RET_CODE         ret = RET_SUCCEED;
    vector<string>   tokens;
    DICT_ENTITY_STP  locDictEntityStp;
    OBJECT_ENUM      locObjectEn;

    this->tokenize(tokens);

    if (tokens.size() < 2)
    {
        this->printMsg(RET_GEN_ERR_INVARG, "Keyword #" + this->context->currTag + ": Invalid argument");
        return RET_GEN_ERR_INVARG;
    }

    string           physicalTable = tokens.at(1);
    DBA_DYNTYPE_ENUM locOutDynNatEn = DynType_Null;

    if ((ret = this->getEntityInfo(physicalTable, locDictEntityStp, locObjectEn, locOutDynNatEn, Truncate)) != RET_SUCCEED)
    {
        return ret;
    }

    this->ddlGenContextPtr->m_dependsAccessSet.insert(DdlGenDependKey(locDictEntityStp->entDictId, 
                                                                      locDictEntityStp->mdSqlName, 
                                                                      DictDependsAccessEn::Truncate, 
                                                                      DynType_Null)); /* PMSTA-29956 - LJE - 180125 */

    this->context->outDdlGenPtr->bodySqlBlock << this->context->outDdlGenPtr->getIndent() << this->context->outDdlGenPtr->getCmdTruncateTable(locDictEntityStp, bForce) << endl;

    return ret;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::getEntityInfo()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-18593 - LJE - 150319
**
*************************************************************************/
RET_CODE DdlGenFromFile::getEntityInfo(string           &paramPhysicalTable,
                                       DICT_ENTITY_STP  &paramDictEntityStp,
                                       OBJECT_ENUM      &paramObjectEn,
                                       DBA_DYNTYPE_ENUM &paramOutDynNatEn,
                                       DBA_ACTION_ENUM   dbaActionEn,
                                       bool              bCheck)
{
    RET_CODE ret = RET_SUCCEED;

    paramDictEntityStp = DBA_GetEntityBySqlName(paramPhysicalTable);

    if (paramOutDynNatEn == DynType_UdOnly)
    {
        this->context->outDdlGenPtr->targetTableEn = TargetTable_UserDefinedFields;
    }
    else if (paramOutDynNatEn == DynType_UdMeSpecOnly || paramOutDynNatEn == DynType_MeSpecOnly)
    {
        this->context->outDdlGenPtr->targetTableEn = TargetTable_LocalBusinessEntity;
    }
    else
    {
        this->context->outDdlGenPtr->targetTableEn = TargetTable_Main;
    }

    if (paramDictEntityStp == nullptr && paramPhysicalTable.find("ud_") == 0)
    {
        paramDictEntityStp = DBA_GetEntityBySqlName(paramPhysicalTable.substr(3));
        this->context->outDdlGenPtr->targetTableEn = TargetTable_UserDefinedFields;

        if (paramOutDynNatEn == DynType_All || paramOutDynNatEn == DynType_AllDb || paramOutDynNatEn == DynType_Full || paramOutDynNatEn == DynType_FullDb)
        {
            paramOutDynNatEn = DynType_UdOnly;
        }
    }
    else if (paramDictEntityStp == nullptr && paramPhysicalTable.find("x_") == 0)
    {
        paramDictEntityStp = DBA_GetEntityBySqlName(paramPhysicalTable.substr(2).c_str());
        this->context->outDdlGenPtr->targetTableEn = TargetTable_Precomp;
    }
    /* PMSTA-36158 - LJE - 190613 */
    else if (paramDictEntityStp == nullptr && paramPhysicalTable.find("_vw") == paramPhysicalTable.length() - 3)
    {
        paramDictEntityStp = DBA_GetEntityBySqlName(paramPhysicalTable.substr(0, paramPhysicalTable.length() - 3).c_str());
        this->context->outDdlGenPtr->targetTableEn = TargetTable_View;
    }
    /* PMSTA-36158 - LJE - 190613 */
    else if (paramDictEntityStp == nullptr && paramPhysicalTable.find("_uvw") == paramPhysicalTable.length() - 4)
    {
        paramDictEntityStp = DBA_GetEntityBySqlName(paramPhysicalTable.substr(0, paramPhysicalTable.length() - 4).c_str());
        this->context->outDdlGenPtr->targetTableEn = TargetTable_TechView;
    }
    else if (paramDictEntityStp)
    {
        if (this->context->outDdlGenPtr->targetTableEn == TargetTable_UserDefinedFields)
        {
            paramPhysicalTable = paramDictEntityStp->custSqlName;
        }
        else if (this->context->outDdlGenPtr->targetTableEn == TargetTable_Precomp)
        {
            paramPhysicalTable = paramDictEntityStp->precompSqlName;
        }
    }

    /* PMSTA-37366 - LJE - 200619 */
    if (paramDictEntityStp == nullptr && SYS_IsSqlMode() == TRUE && paramPhysicalTable.empty() == false)
    {
        if (paramPhysicalTable[0] == '@')
        {
            DdlGenVar *tableVar = this->varHelperPtr->getVariable(paramPhysicalTable);
            if (tableVar != nullptr &&
                tableVar->getValue().empty() == false)
            {
                paramPhysicalTable = tableVar->getValue();
            }
            else
            {
                this->printMsg(RET_GEN_ERR_INVARG, "Keyword #" + this->context->currTag + ": Unknown entity (" + paramPhysicalTable + "), please use the keyword #GET before");
                return RET_GEN_ERR_INVARG;
            }
        }
        paramDictEntityStp = this->createVirtualEntity(paramPhysicalTable);
    }

    if (paramDictEntityStp == nullptr ||
        (this->ddlGenContextPtr->ddlGenAction.isBootStrapLevel() &&
         ((this->ddlGenContextPtr->ddlGenAction.m_mainDdlObjNatEn == DbObjDdlObjNat_System && paramDictEntityStp->entNatEn != EntityNat_System) ||
          (this->ddlGenContextPtr->ddlGenAction.m_mainDdlObjNatEn != DbObjDdlObjNat_System && paramDictEntityStp->bIsInitEntity == false)) &&
         this->ddlGenContextPtr->migrationMode == DdlGenContext::MigrationMode::None &&
         this->ddlGenContextPtr->m_bLightContext == false))
    {
        paramDictEntityStp = nullptr;

        if (bCheck &&
            this->ddlGenContextPtr->ddlGenAction.m_installLevel <= 6 &&
            this->context->outDdlGenPtr->isSystemTable(paramPhysicalTable) == false)
        {
            this->printMsg(RET_GEN_ERR_INVARG, "Keyword #" + this->context->currTag + ": Unknown entity (" + paramPhysicalTable + ")");
            return RET_GEN_ERR_INVARG;
        }
        else
        {
            return RET_GEN_INFO_NOACTION;
        }
    }
    else if (paramPhysicalTable.empty())
    {
        this->printMsg(RET_GEN_ERR_INVARG, "Keyword #" + this->context->currTag + ": Unknown physical entity (" + paramDictEntityStp->mdSqlName + ")");
        return RET_GEN_ERR_INVARG;
    }

    paramObjectEn = paramDictEntityStp->objectEn;

    /* PMSTA-43103 - LJE - 210111 */
    if (dbaActionEn == Delete &&
        paramDictEntityStp->pkEntityStp != nullptr &&
        paramDictEntityStp->entNatEn != EntityNat_DerivedEntity &&
        paramDictEntityStp->pkEntityStp->objectEn != this->getObjectEn())
    {
        paramPhysicalTable = this->context->outDdlGenPtr->getEntityFullSqlName(paramDictEntityStp->pkEntityStp);
    }
    else
    {
        paramPhysicalTable = this->context->outDdlGenPtr->getEntityFullSqlName(paramDictEntityStp, 
                                                                               (dbaActionEn == Insert ? this->context->outDdlGenPtr->targetTableEn : TargetTable_Undefined));
    }
    this->m_lastPhysicalTable = paramPhysicalTable;

    return ret;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::createSProcCreate()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  ORACLE - LJE - 141016
**
*************************************************************************/
RET_CODE DdlGenFromFile::createSProcCreate()
{
    RET_CODE         ret = RET_SUCCEED;
    vector<string>   tokens;
    
    this->tokenize(tokens);

    if (tokens.size() < 2)
    {
        this->printMsg(RET_GEN_ERR_INVARG, "Keyword #" + this->context->currTag + ": Invalid argument");
        return RET_GEN_ERR_INVARG;
    }

    DICT_ENTITY_STP locDictEntityStp = DBA_GetEntityBySqlName(tokens.at(1));

    if (locDictEntityStp == nullptr &&
        tokens.at(1).find(DdlGenDbi::getTempTablePrefix(this->ddlGenContextPtr->m_rdbmsEn, locDictEntityStp)) == 0)
    {
        locDictEntityStp = DBA_GetEntityBySqlName(tokens.at(1).substr(DdlGenDbi::getTempTablePrefix(this->ddlGenContextPtr->m_rdbmsEn, locDictEntityStp).length()));
    }

    if (locDictEntityStp == nullptr)
    {
        this->printMsg(RET_GEN_ERR_INVARG, "Keyword #" + this->context->currTag + ": Unknown entity (" + tokens.at(1).c_str() + ")");
        return RET_GEN_ERR_INVARG;
    }

    if (locDictEntityStp->mainFlg == TRUE)
    {
        this->printMsg(RET_GEN_ERR_INVARG,
                       "Keyword #" + this->context->currTag +
                       ": It's not allowed use this keyword with entity (" + tokens.at(1).c_str() + ") having main flag = 1");
        return RET_GEN_ERR_INVARG;
    }

    if (this->ddlGenContextPtr->m_tmpTableCreatedMap.find(locDictEntityStp->mdSqlName) == this->ddlGenContextPtr->m_tmpTableCreatedMap.end())
    {
        this->ddlGenContextPtr->m_createTmpTableStream
            << this->context->outDdlGenPtr->newLine() << this->context->outDdlGenPtr->getCmdCreateTempTable(locDictEntityStp) << endl;

        if (DdlGenDbi::isTempTableLocalStoredProc(this->ddlGenContextPtr->m_rdbmsEn, locDictEntityStp) == false &&
            DdlGenDbi::getTempTableSpec(this->ddlGenContextPtr->m_rdbmsEn, locDictEntityStp) == DdlGenDbi::TempTableSpec::Session)
        {
            this->m_atReturnStream
                << this->context->outDdlGenPtr->newLine()
                << this->context->outDdlGenPtr->getCmdTruncateTable(locDictEntityStp, false, true) << endl;
        }

        this->ddlGenContextPtr->m_tmpTableCreatedMap.insert(locDictEntityStp->mdSqlName);
    }

    this->ddlGenContextPtr->m_dependsAccessSet.insert(DdlGenDependKey(locDictEntityStp->entDictId,
                                                                      locDictEntityStp->mdSqlName,
                                                                      DictDependsAccessEn::Create,
                                                                      DynType_Null));

    return ret;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::createSProcDrop()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-55968 - LJE - 240828
**
*************************************************************************/
RET_CODE DdlGenFromFile::createSProcDrop()
{
    RET_CODE         ret = RET_SUCCEED;
    vector<string>   tokens;

    this->tokenize(tokens);

    if (tokens.size() < 2)
    {
        this->printMsg(RET_GEN_ERR_INVARG, "Keyword #" + this->context->currTag + ": Invalid argument");
        return RET_GEN_ERR_INVARG;
    }

    DICT_ENTITY_STP locDictEntityStp = DBA_GetEntityBySqlName(tokens.at(1));

    if (locDictEntityStp == nullptr &&
        tokens.at(1).find(DdlGenDbi::getTempTablePrefix(this->ddlGenContextPtr->m_rdbmsEn, locDictEntityStp)) == 0)
    {
        locDictEntityStp = DBA_GetEntityBySqlName(tokens.at(1).substr(DdlGenDbi::getTempTablePrefix(this->ddlGenContextPtr->m_rdbmsEn, locDictEntityStp).length()));
    }

    if (locDictEntityStp == nullptr)
    {
        this->printMsg(RET_GEN_ERR_INVARG, "Keyword #" + this->context->currTag + ": Unknown entity (" + tokens.at(1).c_str() + ")");
        return RET_GEN_ERR_INVARG;
    }

    if (locDictEntityStp->mainFlg == TRUE)
    {
        this->printMsg(RET_GEN_ERR_INVARG,
                       "Keyword #" + this->context->currTag +
                       ": It's not allowed use this keyword with entity (" + tokens.at(1).c_str() + ") having main flag = 1");
        return RET_GEN_ERR_INVARG;
    }

    if (DdlGenDbi::getTempTableSpec(this->ddlGenContextPtr->m_rdbmsEn, locDictEntityStp) == DdlGenDbi::TempTableSpec::Session)
    {
        this->context->outDdlGenPtr->bodySqlBlock
            << this->context->outDdlGenPtr->newLine()
            << this->context->outDdlGenPtr->getCmdDrop(locDictEntityStp->databaseName,
                                                       locDictEntityStp->mdSqlName,
                                                       locDictEntityStp->dbSqlName,
                                                       DdlObj_TempTable) 
            << this->context->outDdlGenPtr->endOfCmd()
            << this->context->outDdlGenPtr->newLine();
    }

    return ret;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::createSProcCursor()
**
**  Description :  Create a cursor on entity, syntax:
**                 #CURSOR_OPEN <cursor name>
**                 [#SELECT]
**                 [#FROM]
**                 [#WHERE]
**                 #END
**                 <cursor body>
**                 #CURSOR_CLOSE <cursor name>
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-13109 - LJE - 111205
**
*************************************************************************/
RET_CODE DdlGenFromFile::createSProcCursor()
{
    RET_CODE         ret = RET_SUCCEED, cursorRet = RET_SUCCEED;
    vector<string>   tokens;
    OBJECT_ENUM      locObjectEn;
    DICT_ENTITY_STP  locDictEntityStp;
    SEL_LIST_ENUM    selListEn;
    DBA_DYNTYPE_ENUM locOutDynNatEn = DynType_All;
    FLAG_T
        locCustFlg = FALSE,
        locprecompFlg = FALSE,
        locOnlyPhysicalFlg = TRUE;

    string           cursorSelectStr, cursorBodyStr, cursorVarStr, cursorNameStr;

    ENTITY_SECURITY_LEVEL_ENUM locSecuLevelEn = EntSecuLevel_NoSecured;

    this->tokenize(tokens);

    if (tokens.size() < 3)
    {
        this->printMsg(RET_GEN_ERR_INVARG, "Keyword #" + this->context->currTag + ": Invalid argument");
        return RET_GEN_ERR_INVARG;
    }

    string physicalTable = tokens.at(1);
    if (RET_GET_LEVEL((ret = this->getEntityInfo(physicalTable, locDictEntityStp, locObjectEn, locOutDynNatEn, Select))) == RET_LEV_ERROR)
    {
        return ret;
    }

    DBA_GetObjectEnum(locDictEntityStp->entDictId, &locObjectEn);

    InitContextClass initContext(this->context);
    DdlGen locGenDdl(locObjectEn, this->context->outDdlGenPtr->targetTableEn, *this);
    this->context->currDdlGen = &locGenDdl;

    if ((locOutDynNatEn = this->getDynType(tokens.at(2))) == DynType_Unknown)
    {
        return RET_GEN_ERR_INVARG;
    }

    if (this->ddlGenContextPtr->m_rdbmsEn == Sybase)
    {
        this->m_bSendRequestWithProc = true;
    }

    /* PMSTA-36158 - LJE - 190627 */
    if (locOutDynNatEn == DynType_AllDbWithUd ||
        locOutDynNatEn == DynType_UdOnly)
    {
        locCustFlg = TRUE;
    }

    locGenDdl.init(locObjectEn,
                   locOutDynNatEn,
                   locCustFlg,
                   locprecompFlg,
                   locOnlyPhysicalFlg,
                   locSecuLevelEn,
                   FALSE);

    locGenDdl.copy(*this->context->outDdlGenPtr);   /* PMSTA-29879 - LJE - 180712 */

    if (tokens.size() > 3)
    {
        if (tokens.at(3).compare("null") == 0)
        {
            locGenDdl.setAlias(std::string());
        }
        else if (tokens.at(3).compare("std") != 0)
        {
            locGenDdl.setAlias(tokens.at(3));
        }
    }

    if (tokens.size() > 4)
    {
        cursorNameStr = tokens[4];
    }
    else
    {
        cursorNameStr = locDictEntityStp->mdSqlName;
        cursorNameStr += "_cur";

        if (cursorNameStr.length() > 30)
        {
            cursorNameStr = locDictEntityStp->shortSqlname;
            cursorNameStr += "_cur";
        }
    }

    this->varHelperPtr->setInCursorName(cursorNameStr);

    if (this->isTag(TAG_SELECT_DISTINCT_CURSOR))
    {
        selListEn = SelList_SelectDistinctCursor;
    }
    else
    {
        selListEn = SelList_SelectCursor;
    }

    while (this->getGenSqlLine() && this->isTag(TAG_FROM) == false && this->isTag(TAG_WHERE) == false && this->isTag(TAG_FETCH_CURSOR) == false)
    {
        if (this->manageNestedTag(locGenDdl.overloadStream) == false)
        {
            locGenDdl.overloadStream << this->context->currLineStrLTrim << endl;
        }
    }

    if ((ret = locGenDdl.printSelListRequest(selListEn)) != RET_SUCCEED)
    {
        return ret;
    }

    this->varHelperPtr->setInCursorName(string());

    if (this->isTag(TAG_FROM))
    {
        this->extractFromPart(&locGenDdl, locSecuLevelEn);
        if ((ret = locGenDdl.printFromRequest()) != RET_SUCCEED)
        {
            return ret;
        }
        if (locGenDdl.m_fromStream.str().empty() == false)
        {
            locGenDdl.addFromStream << locGenDdl.newLine();
        }
    }

    if (RET_GET_LEVEL(this->lastErrRetCode) == RET_LEV_ERROR)
    {
        cursorRet = this->lastErrRetCode;
    }

    locGenDdl.setIndent(this->context->outDdlGenPtr->getIndentNbr());

    locGenDdl.overloadStream.clear();
    locGenDdl.overloadStream.str(std::string());

    if (this->isTag(TAG_WHERE))
    {
        bool bTagEnd = false;
        string unionStr;

        this->extractWherePart(&locGenDdl, bTagEnd, unionStr);
    }

    if ((ret = locGenDdl.printWhereRequest()) != RET_SUCCEED)
    {
        return ret;
    }

    this->getDdlGenContextPtr()->iCursorCpt--;
    this->varHelperPtr->setInCursorName(cursorNameStr);
    this->varHelperPtr->releaseAddInCursor();

    if (RET_GET_LEVEL(this->lastErrRetCode) == RET_LEV_ERROR)
    {
        cursorRet = this->lastErrRetCode;
    }

    locGenDdl.replaceTagAlias(locGenDdl.whereStream);   /* PRO-14029 - LJE - 210310 */

    cursorSelectStr = locGenDdl.selListStream.str()
        + locGenDdl.m_mainFromStream.str()
        + locGenDdl.addFromStream.str()
        + locGenDdl.m_fromStream.str()
        + locGenDdl.whereStream.str();

    if (this->context->outDdlGenPtr->bOrderBy)
    {
        if (locOutDynNatEn != DynType_Short && locGenDdl.orderStream.str().empty())
        {
            ret = RET_DBA_ERR_INVDATA;
            this->printMsg(ret, "#ORDER used without order clause, only authorized for short structure output");
        }

        cursorSelectStr += locGenDdl.orderStream.str();

        this->context->outDdlGenPtr->bOrderBy = false;
    }

    cursorSelectStr += locGenDdl.limitStream.str()
        + locGenDdl.groupStream.str()
        + locGenDdl.queryAddStr
        + locGenDdl.havingStream.str();

    cursorVarStr = locGenDdl.varListStream.str();

    if (this->isTag(TAG_FETCH_CURSOR))
    {
        DdlGenFromFileContext *savedContext = this->context;
        stringstream nestedStream;
        MemoryPool mp;
        DdlGenFromFileContext* localContext(new DdlGenFromFileContext());
        mp.ownerObject(localContext);

        localContext->blockLineBeginNb = this->context->blockLineBeginNb;
        localContext->lineNb = this->context->lineNb;
        localContext->bInitCurrLineIt = false;
        localContext->parentTagNat = this->context->currTagNat;

        this->context->bUpdateIndent = false;
        while (this->getGenSqlLine() && this->isTag(TAG_END_CURSOR) == false)
        {
            if (this->manageNestedTag(nestedStream, TAG_END_CURSOR) == true)
            {
                while (getline(nestedStream, this->context->currLineStr))
                {
                    localContext->currBlockVector.push_back(this->context->currLineStr);
                }
                nestedStream.clear();
                nestedStream.str(string());
            }
            else
            {
                localContext->currBlockVector.push_back(this->context->currLineStr);
            }
        }

        if (RET_GET_LEVEL(this->lastErrRetCode) == RET_LEV_ERROR)
        {
            cursorRet = this->lastErrRetCode;
        }

        if (this->isTag(TAG_END_CURSOR) == false)
        {
            this->printMsg(RET_GEN_ERR_INVARG, "Keyword #" + this->context->currTag + ": Missing keyword #END_CURSOR");
            return RET_GEN_ERR_INVARG;
        }

        this->context->bUpdateIndent = true;

        localContext->blockLineBeginNb = savedContext->blockLineBeginNb + this->context->lineNb - 1;
        this->context = localContext;
        this->context->bUpdateIndent = true;
        this->context->bInitCurrLineIt = false;
        this->newOutDdlGen();
        this->context->parentPreIndent = "\t";

        this->buildBlock();

        cursorBodyStr = this->context->outDdlGenPtr->bodySqlBlock.str();

        this->deleteOutDdlGen();
        this->context = savedContext;
    }

    if (RET_GET_LEVEL(this->lastErrRetCode) == RET_LEV_ERROR)
    {
        cursorRet = this->lastErrRetCode;
    }

    if (cursorRet == RET_SUCCEED || this->ddlGenContextPtr->ddlGenAction.m_installLevel <= 5)
    {
        this->context->outDdlGenPtr->bodySqlBlock << this->context->outDdlGenPtr->getCursorRequest(cursorNameStr, cursorSelectStr, cursorVarStr, cursorBodyStr);
    }

    this->varHelperPtr->setInCursorName(string());
    return cursorRet;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::createSProcForSelect()
**
**  Description :  Create a cursor on entity, using "for select", syntax:
**                 #CURSOR_OPEN <cursor name>
**                 [#SELECT]
**                 [#FROM]
**                 [#WHERE]
**                 #END
**                 <cursor body>
**                 #CURSOR_CLOSE <cursor name>
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-nuodb - LJE - 190809
**
*************************************************************************/
RET_CODE DdlGenFromFile::createSProcForSelect()
{
    RET_CODE         ret = RET_SUCCEED;
    RET_CODE         cursorRet = RET_SUCCEED;
    vector<string>   tokens;
    OBJECT_ENUM      locObjectEn;
    DICT_ENTITY_STP  locDictEntityStp;
    SEL_LIST_ENUM    selListEn;
    DBA_DYNTYPE_ENUM locOutDynNatEn = DynType_All;
    FLAG_T           locCustFlg = FALSE;
    FLAG_T           locprecompFlg = FALSE;
    FLAG_T           locOnlyPhysicalFlg = TRUE;

    string           cursorSelectStr, cursorBodyStr, cursorVarStr, cursorNameStr;

    ENTITY_SECURITY_LEVEL_ENUM locSecuLevelEn = EntSecuLevel_NoSecured;

    this->tokenize(tokens);

    if (tokens.size() < 3)
    {
        this->printMsg(RET_GEN_ERR_INVARG, "Keyword #" + this->context->currTag + ": Invalid argument");
        return RET_GEN_ERR_INVARG;
    }

    string physicalTable = tokens.at(1);
    if (RET_GET_LEVEL((ret = this->getEntityInfo(physicalTable, locDictEntityStp, locObjectEn, locOutDynNatEn, Select))) == RET_LEV_ERROR)
    {
        return ret;
    }

    DBA_GetObjectEnum(locDictEntityStp->entDictId, &locObjectEn);

    InitContextClass initContext(this->context);
    DdlGen locGenDdl(locObjectEn, this->context->outDdlGenPtr->targetTableEn, *this);
    this->context->currDdlGen = &locGenDdl;

    if ((locOutDynNatEn = this->getDynType(tokens.at(2))) == DynType_Unknown)
    {
        return RET_GEN_ERR_INVARG;
    }

    /* PMSTA-36158 - LJE - 190627 */
    if (locOutDynNatEn == DynType_AllDbWithUd ||
        locOutDynNatEn == DynType_UdOnly)
    {
        locCustFlg = TRUE;
    }

    locGenDdl.init(locObjectEn,
                   locOutDynNatEn,
                   locCustFlg,
                   locprecompFlg,
                   locOnlyPhysicalFlg,
                   locSecuLevelEn,
                   FALSE);

    locGenDdl.copy(*this->context->outDdlGenPtr);   /* PMSTA-29879 - LJE - 180712 */

    if (tokens.size() > 3)
    {
        if (tokens.at(3).compare("null") == 0)
        {
            locGenDdl.setAlias(std::string());
        }
        else if (tokens.at(3).compare("std") != 0)
        {
            locGenDdl.setAlias(tokens.at(3));
        }
    }

    if (tokens.size() > 4)
    {
        cursorNameStr = tokens[4];
    }
    else
    {
        cursorNameStr = locDictEntityStp->mdSqlName;
        cursorNameStr += "_cur";

        if (cursorNameStr.length() > 30)
        {
            cursorNameStr = locDictEntityStp->shortSqlname;
            cursorNameStr += "_cur";
        }
    }

    this->varHelperPtr->setInCursorName(cursorNameStr);

    if (this->isTag(TAG_SELECT_DISTINCT_CURSOR))
    {
        selListEn = SelList_ForSelectDistinct;
    }
    else
    {
        selListEn = SelList_ForSelect;
    }

    while (this->getGenSqlLine() && this->isTag(TAG_FROM) == false && this->isTag(TAG_WHERE) == false && this->isTag(TAG_FETCH_CURSOR) == false)
    {
        if (this->manageNestedTag(locGenDdl.overloadStream) == false)
        {
            locGenDdl.overloadStream << this->context->currLineStrLTrim << endl;
        }
    }

    if ((ret = locGenDdl.printSelListRequest(selListEn)) != RET_SUCCEED)
    {
        return ret;
    }

    this->varHelperPtr->setInCursorName(string());

    if (this->isTag(TAG_FROM))
    {
        this->extractFromPart(&locGenDdl, locSecuLevelEn);
        if ((ret = locGenDdl.printFromRequest()) != RET_SUCCEED)
        {
            return ret;
        }
        if (locGenDdl.m_fromStream.str().empty() == false)
        {
            locGenDdl.addFromStream << locGenDdl.newLine();
        }
    }

    if (RET_GET_LEVEL(this->lastErrRetCode) == RET_LEV_ERROR)
    {
        cursorRet = this->lastErrRetCode;
    }

    locGenDdl.setIndent(this->context->outDdlGenPtr->getIndentNbr());

    locGenDdl.overloadStream.clear();
    locGenDdl.overloadStream.str(std::string());

    if (this->isTag(TAG_WHERE))
    {
        bool bTagEnd = false;
        string unionStr;

        this->extractWherePart(&locGenDdl, bTagEnd, unionStr);
    }

    if ((ret = locGenDdl.printWhereRequest()) != RET_SUCCEED)
    {
        return ret;
    }

    this->getDdlGenContextPtr()->iCursorCpt--;
    this->varHelperPtr->setInCursorName(cursorNameStr);
    this->varHelperPtr->releaseAddInCursor();

    if (RET_GET_LEVEL(this->lastErrRetCode) == RET_LEV_ERROR)
    {
        cursorRet = this->lastErrRetCode;
    }

    locGenDdl.replaceTagAlias(locGenDdl.whereStream);   /* PRO-14029 - LJE - 210310 */

    cursorSelectStr = locGenDdl.selListStream.str()
        + locGenDdl.m_mainFromStream.str()
        + locGenDdl.addFromStream.str()
        + locGenDdl.m_fromStream.str()
        + locGenDdl.whereStream.str();

    if (this->context->outDdlGenPtr->bOrderBy)
    {
        if (locOutDynNatEn != DynType_Short && locGenDdl.orderStream.str().empty())
        {
            ret = RET_DBA_ERR_INVDATA;
            this->printMsg(ret, "#ORDER used without order clause, only authorized for short structure output");
        }

        cursorSelectStr += locGenDdl.orderStream.str();

        this->context->outDdlGenPtr->bOrderBy = false;
    }

    cursorSelectStr += locGenDdl.limitStream.str()
        + locGenDdl.groupStream.str()
        + locGenDdl.queryAddStr
        + locGenDdl.havingStream.str();

    cursorVarStr = locGenDdl.varListStream.str();

    if (this->isTag(TAG_FETCH_CURSOR))
    {
        DdlGenFromFileContext *savedContext = this->context;
        stringstream nestedStream;

        MemoryPool mp;
        DdlGenFromFileContext *localContext = new DdlGenFromFileContext();
        mp.ownerObject(localContext);

        localContext->blockLineBeginNb = this->context->blockLineBeginNb;
        localContext->lineNb = this->context->lineNb;
        localContext->bInitCurrLineIt = false;
        localContext->parentTagNat = this->context->currTagNat;

        this->context->bUpdateIndent = false;
        while (this->getGenSqlLine() && this->isTag(TAG_END_CURSOR) == false)
        {
            if (this->manageNestedTag(nestedStream, TAG_END_CURSOR) == true)
            {
                while (getline(nestedStream, this->context->currLineStr))
                {
                    localContext->currBlockVector.push_back(this->context->currLineStr);
                }
                nestedStream.clear();
                nestedStream.str(string());
            }
            else
            {
                localContext->currBlockVector.push_back(this->context->currLineStr);
            }
        }

        if (RET_GET_LEVEL(this->lastErrRetCode) == RET_LEV_ERROR)
        {
            cursorRet = this->lastErrRetCode;
        }

        if (this->isTag(TAG_END_CURSOR) == false)
        {
            this->varHelperPtr->setInCursorName(string());
            this->printMsg(RET_GEN_ERR_INVARG, "Keyword #" + this->context->currTag + ": Missing keyword #END_CURSOR");
            return RET_GEN_ERR_INVARG;
        }

        this->context->bUpdateIndent = true;

        localContext->blockLineBeginNb = savedContext->blockLineBeginNb + this->context->lineNb - 1;
        this->context = localContext;
        this->context->bUpdateIndent = true;
        this->context->bInitCurrLineIt = false;
        this->newOutDdlGen();
        this->context->parentPreIndent = "\t";

        this->buildBlock();

        cursorBodyStr = this->context->outDdlGenPtr->bodySqlBlock.str();

        this->deleteOutDdlGen();
        this->context = savedContext;
    }

    if (RET_GET_LEVEL(this->lastErrRetCode) == RET_LEV_ERROR)
    {
        cursorRet = this->lastErrRetCode;
    }

    if (cursorRet == RET_SUCCEED || this->ddlGenContextPtr->ddlGenAction.m_installLevel <= 5)
    {
        this->context->outDdlGenPtr->bodySqlBlock << this->context->outDdlGenPtr->getCursorRequest(cursorNameStr, cursorSelectStr, cursorVarStr, cursorBodyStr);
    }

    this->varHelperPtr->setInCursorName(string());

    return cursorRet;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::createSProcCall()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-11505 - LJE - 110404
**
*************************************************************************/
RET_CODE DdlGenFromFile::createSProcCall()
{
    RET_CODE        ret = RET_SUCCEED;
    vector<string>  tokens;
    OBJECT_ENUM     locObjectEn;
    DICT_ENTITY_STP locDictEntityStp;
    DBA_DYNTYPE_ENUM locOutDynNatEn = DynType_Null;
    FLAG_T           locOnlyPhysicalFlg = FALSE;
    SEL_LIST_ENUM    selListEn;
    string           returnVar;

    bool            bTagEnd = false;

    this->tokenize(tokens);

    if (tokens.size() < 4 ||
        tokens.size() > 6 ||
        (tokens.size() == 6 && tokens.at(tokens.size() - 1) != TAG_END))
    {
        this->printMsg(RET_GEN_ERR_INVARG, "Tag CALL error: #CALL <stored proc name> <entity name> <in> [<result variable>] END");
        return RET_GEN_ERR_INVARG;
    }

    locDictEntityStp = DBA_GetEntityBySqlName(tokens.at(2));

    if (locDictEntityStp == NULL)
    {
        this->printMsg(RET_GEN_ERR_INVARG, "Tag CALL error: #CALL <stored proc name> <entity name> <in> END");
        return RET_GEN_ERR_INVARG;
    }
    DBA_GetObjectEnum(locDictEntityStp->entDictId, &locObjectEn);

    InitContextClass initContext(this->context);
    DdlGen locGenDdl(locObjectEn, this->context->outDdlGenPtr->targetTableEn, *this);
    this->context->currDdlGen = &locGenDdl;

    if ((locOutDynNatEn = this->getDynType(tokens.at(3))) == DynType_Unknown)
    {
        return RET_GEN_ERR_INVARG;
    }

    if (tokens.at(3).compare("all_db") == 0)
    {
        locOnlyPhysicalFlg = TRUE;
    }

    locGenDdl.init(locObjectEn,
                   locOutDynNatEn,
                   FALSE,
                   FALSE,
                   locOnlyPhysicalFlg,
                   EntSecuLevel_NoSecured,
                   this->context->outDdlGenPtr->translateFlg);

    locGenDdl.copy(*this->context->outDdlGenPtr);   /* PMSTA-29879 - LJE - 180712 */

    if (tokens.at(tokens.size() - 1) != TAG_END)
    {
        while (bTagEnd == false && this->getGenSqlLine())
        {
            if (this->context->currLineStrLTrim.size() == 0)
                continue;
            if (this->isTag(TAG_END))
            {
                bTagEnd = true;
                continue;
            }
            locGenDdl.overloadStream << this->context->currLineStrLTrim << endl;
        }

        if (bTagEnd == false)
        {
            this->printMsg(RET_GEN_ERR_INVARG, "Missing end tag (#END)");
            return RET_GEN_ERR_INVARG;
        }
    }

    locGenDdl.setPreIndent(this->context->outDdlGenPtr->getPreIndent());
    locGenDdl.setIndent(this->context->outDdlGenPtr->getIndentNbr());

    if (tokens.size() >= 5 && tokens.at(4) != TAG_END)
    {
        returnVar = tokens.at(4);
    }
    locGenDdl.setAlias(std::string());

    selListEn = SelList_Call;

    locGenDdl.setIndent(2);
    if ((ret = locGenDdl.printSelListRequest(selListEn)) != RET_SUCCEED)
    {
        return ret;
    }

    stringstream execCmdStream;

    execCmdStream
        << this->context->outDdlGenPtr->getIndent() << "#EXEC ";

    if (returnVar.empty() == false)
    {
        execCmdStream
            << returnVar << " = ";
    }
    execCmdStream
        << tokens.at(1) << " " << locGenDdl.selListStream.str();

    this->context->outDdlGenPtr->bodySqlBlock
        << this->buildScript(execCmdStream.str());

    if (locOutDynNatEn != DynType_Null)
    {
        this->ddlGenContextPtr->m_dependsAccessSet.insert(DdlGenDependKey(locDictEntityStp->entDictId,
                                                                          locDictEntityStp->mdSqlName, 
                                                                          DictDependsAccessEn::CallParameter,
                                                                          locOutDynNatEn));
    }

    return ret;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::extractKeywordParam()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  ORACLE - LJE - 140707
**
*************************************************************************/
void DdlGenFromFile::extractKeywordParam(const string &tagStr, 
                                         unsigned fixedParam,
                                         vector<vector<string>> &keywordParamList, 
                                         bool bWithBraket, 
                                         bool bOneLevel, 
                                         std::string nextRecordDelimiter)
{
    vector<string>  tokens, paramTokens;
    bool            bContinue = true;
    int             bracketNbr = 0, readNext = 0;

    vector<string>         keywordParam;
    string                 localDelimiter = ",";

    stringstream currLineStream;
    bool bInComment = false;

    do
    {
        this->checkComments(this->context->currLineStrLTrim, bInComment, currLineStream, true);
    } while (bInComment && this->getGenSqlLine() == true);

    this->context->currLineStrLTrim = currLineStream.str();

    if (tagStr.empty() == false &&
        this->context->currLineStrLTrim.find(tagStr) == 1)
    {
        this->context->currLineStrLTrim.erase(0, tagStr.length() + 1);
    }

    this->context->bUpdateIndent = false;

    bracketNbr = this->tokenize(tokens, localDelimiter);

    while (bracketNbr)
    {
        this->getGenSqlLine(false, true);
        bracketNbr = this->tokenize(tokens, localDelimiter, true, bracketNbr);
    }

    while (bContinue)
    {
        bContinue = false;

        for (vector<string>::iterator it = tokens.begin(); it != tokens.end(); ++it)
        {
            if (it->length() == 0 ||
                it->find_first_not_of(" \t") == string::npos)
            {
                bContinue = true;
            }
            else
            {
                DdlGen::tokenizeStr(paramTokens, *it, " \t=");

                for (vector<string>::iterator parmIt = paramTokens.begin(); parmIt != paramTokens.end(); ++parmIt)
                {
                    keywordParam.push_back(*parmIt);
                }

                if (keywordParam.size())
                {
                    keywordParamList.push_back(keywordParam);
                    keywordParam.clear();
                    paramTokens.clear();
                }
            }
        }

        tokens.clear();

        if (this->getGenSqlLine(false, true, &readNext) &&
            (bContinue ||
             this->context->currLineStrLTrim.empty() ||
             this->context->currLineStrLTrim.find_first_of(nextRecordDelimiter) == 0 ||
             this->context->currLineStrLTrim.find("NEW.") == 0 ||
             this->context->currLineStrLTrim.find("OLD.") == 0))
        {
            bContinue = true;

            bracketNbr = this->tokenize(tokens, localDelimiter);

            if (tokens.size())
            {
                readNext = 0;
            }

            while (bracketNbr)
            {
                this->getGenSqlLine(false, true, &readNext);
                bracketNbr = this->tokenize(tokens, localDelimiter, true, bracketNbr);
            }
        }
    }

    if (readNext)
    {
        this->resetNextCurrBlock(readNext);
    }

    if (fixedParam > 0 && keywordParamList.size() > 0 && keywordParamList[0].size() >= fixedParam)
    {
        vector<string> firstParam;
        for (vector<string>::iterator it = keywordParamList[0].begin() + fixedParam; it != keywordParamList[0].end(); ++it)
        {
            firstParam.push_back(*it);
        }
        if (firstParam.size())
        {
            keywordParamList[0] = firstParam;
        }
        else
        {
            keywordParamList.erase(keywordParamList.begin());
        }
    }

    if (bWithBraket && keywordParamList.size() > 0)
    {
        keywordParam = keywordParamList[0];

        string::size_type
            pos = keywordParam[0].find_first_of("("),
            firstPos = keywordParam[0].find_first_not_of(" \t");

        if (pos != string::npos && firstPos == pos)
        {
            keywordParam[0].replace(0, pos + 1, "");
            keywordParamList[0] = keywordParam;

            keywordParam = keywordParamList.at(keywordParamList.size() - 1);
            pos = keywordParam[0].find_last_of(")");
            if (pos != string::npos)
            {
                keywordParam[0].replace(pos, string::npos, "");
            }
            keywordParamList.at(keywordParamList.size() - 1) = keywordParam;
        }
    }

    if (bOneLevel)
    {
        for (vector<vector<string>>::iterator it = keywordParamList.begin(); it != keywordParamList.end(); ++it)
        {
            if (it->size() > 1)
            {
                string concat = it->at(0);
                for (vector<string>::iterator it2 = it->begin() + 1; it2 != it->end(); it2++)
                {
                    concat += " " + *it2;
                }

                it->clear();
                it->push_back(concat);
            }
        }
    }

    this->context->bUpdateIndent = true;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::createSProcDeclare()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  ORACLE - LJE - 140707
**
*************************************************************************/
RET_CODE DdlGenFromFile::createSProcDeclare()
{
    RET_CODE        ret = RET_SUCCEED;
    vector<vector<string>> keywordParamList;

    this->extractKeywordParam(TAG_DECLARE, 0, keywordParamList, false);

    for (vector<vector<string>>::iterator paramIt = keywordParamList.begin(); paramIt != keywordParamList.end(); ++paramIt)
    {
        vector<string>   keywordParam = *paramIt;

        bool             bNot = false;
        DdlGenVar        newVar(*this->context->outDdlGenPtr);

        for (auto info = keywordParam.begin(); info != keywordParam.end(); info++)
        {
            if (info->at(0) == '@')
            {
                newVar.sqlName = info->substr(1);
            }
            else if (info->compare("not") == 0)
            {
                bNot = true;
            }
            else if (info->compare("null") == 0 && bNot)
            {
                newVar.bNullable = false;
            }
            else if (newVar.sqlName.empty())
            {
                newVar.sqlName = *info;
            }
            else if (newVar.getDataType() == NullDataType)
            {
                newVar.setDataTypeSqlName(*info);
            }
            else
            {
                newVar.strDefault = *info;
            }
        }

        this->varHelperPtr->addVariable(newVar);
    }
    if (this->context->outDdlGenPtr->lastErrRetCode != RET_SUCCEED)
    {
        ret = this->context->outDdlGenPtr->lastErrRetCode;
    }
    return ret;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::createSProcAssignSelect()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  ORACLE - LJE - 140707
**
*************************************************************************/
RET_CODE DdlGenFromFile::createSProcAssignSelect()
{
    RET_CODE                          ret = RET_SUCCEED;
    string                            varName, assignValue;
    stringstream                      finalAssignStream, emptyStream;
    vector<vector<string>>::size_type itPos = 0;
    vector<vector<string>> keywordParamList;

    this->extractKeywordParam(this->context->currTag, 0, keywordParamList, false);

    this->context->outDdlGenPtr->bodySqlBlock << this->context->outDdlGenPtr->getIndent() << "select ";

    for (vector<vector<string>>::iterator paramIt = keywordParamList.begin(); paramIt != keywordParamList.end(); ++paramIt, itPos++)
    {
        vector<string> keywordParam = *paramIt;

        assignValue.clear();

        if (keywordParam.size() > 0)
        {
            varName = keywordParam[0];
        }
        if (keywordParam.size() > 1)
        {
            for (vector<string>::iterator it = keywordParam.begin() + 1; it != keywordParam.end(); it++)
            {
                if ((*it) == this->context->outDdlGenPtr->appendCharter())
                {
                    assignValue += " " + (*it) + " ";
                }
                else
                {
                    assignValue += *it;
                }
            }
        }

        if (itPos != 0)
        {
            this->context->outDdlGenPtr->bodySqlBlock << ", " << this->context->outDdlGenPtr->newLine() << "       ";
        }
        DdlGenVar *variable = this->varHelperPtr->getVariable(varName);
        if (variable != nullptr)
        {
            variable->setValue(std::string());

            int rank = 0;

            this->context->outDdlGenPtr->replaceTagConvert(assignValue, variable->getDataType(), this->inDateTimeStyleEn);

            while (assignValue.size() > this->context->outDdlGenPtr->stringLiteralMaxValue(this->ddlGenContextPtr->m_rdbmsEn) &&
                   assignValue.at(0) == '\'')
            {
                stringstream concatStr;
                concatStr << "$" << rank++;

                DdlGenVar *concatVariable = this->varHelperPtr->getNewVariable(varName + concatStr.str(), variable->getDataType());

                this->context->outDdlGenPtr->bodySqlBlock
                    << this->context->outDdlGenPtr->getCmdAssignOnSelect(*concatVariable,
                                                                         assignValue.substr(0, this->context->outDdlGenPtr->stringLiteralMaxValue(this->ddlGenContextPtr->m_rdbmsEn)) + "'",
                                                                         finalAssignStream,
                                                                         emptyStream, 
                                                                         false);
                assignValue.erase(0, this->context->outDdlGenPtr->stringLiteralMaxValue(this->ddlGenContextPtr->m_rdbmsEn) - 1);
                assignValue.replace(0, 1, "'");
                this->context->outDdlGenPtr->bodySqlBlock << ", " << this->context->outDdlGenPtr->newLine() << "       ";
            }

            this->context->outDdlGenPtr->bodySqlBlock
                << this->context->outDdlGenPtr->getCmdAssignOnSelect(*variable, assignValue, finalAssignStream, emptyStream, keywordParamList.size() - 1 == itPos);
        }
    }
    this->context->outDdlGenPtr->bodySqlBlock << finalAssignStream.str() << this->context->outDdlGenPtr->endOfCmd() << endl;

    if (this->context->outDdlGenPtr->lastErrRetCode != RET_SUCCEED)
    {
        ret = this->context->outDdlGenPtr->lastErrRetCode;
    }
    return ret;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::createSProcAssign()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  ORACLE - LJE - 140707
**
*************************************************************************/
RET_CODE DdlGenFromFile::createSProcAssign()
{
    RET_CODE   ret = RET_SUCCEED;

    if (this->ddlGenContextPtr->m_rdbmsEn != Nuodb &&
        (this->context->outDdlGenPtr->isAssingBySelect() || this->getOutDdlObjEn() == DdlObj_Sql || this->getOutDdlObjEn() == DdlObj_RuntimeSql))
    {
        ret = this->createSProcAssignSelect();
    }
    else
    {
        string                 varName, assignValue;
        vector<vector<string>> keywordParamList;

        this->extractKeywordParam(TAG_ASSIGN, 0, keywordParamList, false);

        for (vector<vector<string>>::iterator paramIt = keywordParamList.begin(); paramIt != keywordParamList.end(); ++paramIt)
        {
            vector<string> keywordParam = *paramIt;

            assignValue.clear();

            if (keywordParam.size() > 0)
            {
                varName = keywordParam[0];
            }
            if (keywordParam.size() > 1)
            {
                for (vector<string>::iterator it = keywordParam.begin() + 1; it != keywordParam.end(); ++it)
                {
                    if (it != keywordParam.begin() + 1)
                    {
                        assignValue += " ";
                    }
                    assignValue += *it;
                }
            }

            DdlGenVar *variable = this->varHelperPtr->getVariable(varName);
            if (variable != nullptr)
            {
                variable->setValue(std::string());

                this->context->outDdlGenPtr->bodySqlBlock << this->context->outDdlGenPtr->getIndent();
                this->context->outDdlGenPtr->replaceTagConvert(assignValue, variable->getDataType(), this->inDateTimeStyleEn);
                this->context->outDdlGenPtr->bodySqlBlock << this->context->outDdlGenPtr->getCmdAssignByValue(*variable, assignValue);
                this->context->outDdlGenPtr->bodySqlBlock << endl;
            }
        }

        if (this->context->outDdlGenPtr->lastErrRetCode != RET_SUCCEED)
        {
            ret = this->context->outDdlGenPtr->lastErrRetCode;
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::createSProcExecSql()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  ORACLE - LJE - 140707
**
*************************************************************************/
RET_CODE DdlGenFromFile::createSProcExecSql()
{
    RET_CODE        ret = RET_SUCCEED;
    int             fixedParam = 0;
    string          sqlToDo;

    vector<vector<string>> keywordParamList;
    this->extractKeywordParam(this->context->currTag, fixedParam, keywordParamList, true, true);

    for (vector<vector<string>>::iterator paramIt = keywordParamList.begin(); paramIt != keywordParamList.end(); ++paramIt)
    {
        vector<string> keywordParam = *paramIt;
        sqlToDo += keywordParam[0];
    }

    this->context->outDdlGenPtr->bodySqlBlock
        << this->context->outDdlGenPtr->newLine() << this->context->outDdlGenPtr->getCmdExecSql(sqlToDo, "");

    return ret;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::createSProcExec()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  ORACLE - LJE - 140707
**
*************************************************************************/
RET_CODE DdlGenFromFile::createSProcExec()
{
    RET_CODE        ret = RET_SUCCEED;
    RET_CODE        gblRet = RET_SUCCEED;
    vector<string>  tokens;
    string          funcName, resultVar, outputStr, databaseName;
    int             fixedParam = 1;
    stringstream    sprocParam;
    DdlGenSqlBlock *outSqlBlockPtr = &(this->context->outDdlGenPtr->bodySqlBlock);

    DBA_RDBMS_ENUM  savedRdbms = this->ddlGenContextPtr->m_rdbmsEn;
    DBA_RDBMS_ENUM  savedRdbmsDdlGen = EV_RdbmsDdlGen;
    bool            bFinSrvCal = false;

    set<string>    paramUsedSet;
    string          newLine = (this->getOutDdlObjEn() == DdlObj_RuntimeSql ? "" : this->context->outDdlGenPtr->newLine());

    vector<vector<string>> keywordParamList;
    this->tokenize(tokens, " \t=;");

    if (tokens.size() < 2)
    {
        this->printMsg(RET_GEN_ERR_INVARG, "Keyword #" + this->context->currTag + ": Invalid argument");
        return RET_GEN_ERR_INVARG;
    }

    if (tokens.at(1)[0] == '@')
    {
        fixedParam++;
        resultVar = tokens.at(1);
        funcName = tokens.at(2);
    }
    else
    {
        funcName = tokens.at(1);
    }

    if (funcName.find(".") != string::npos)
    {
        databaseName = funcName.substr(0, funcName.find("."));
        funcName = funcName.substr(funcName.find_last_of(".") + 1);
    }

    string        reportServerName;
    if (this->getOutDdlObjEn() == DdlObj_Sql && this->optimLevel < 2 && EV_DictInitFlg == TRUE)
    {
        RpcProperties rpcProperties;

        if (DBI_GetRpcParamInfoStp(funcName.c_str(), rpcProperties))
        {
            bFinSrvCal = true;
            EV_RdbmsDdlGen = Sybase;
            this->ddlGenContextPtr->m_rdbmsEn = Sybase;
            outSqlBlockPtr = &(this->context->outDdlGenPtr->finSrvCallSqlBlock);

            if (rpcProperties.m_reportServerPos != Null_Dynfld)
            {
                DBA_DYNSTDEF_STP reportDynStDefStp = &(EV_DynStPtr[rpcProperties.getArgDynStEnum()].dynStDefPtr[rpcProperties.m_reportServerPos]);
                reportServerName = string(reportDynStDefStp->sqlName);
            }
        }
    }

    DictSprocClass *dictSprocStp = nullptr;
    bool            bKnownSproc = false;
    bool            bNeedToKnowSproc = false;

    if (bFinSrvCal == false &&
        (this->getOutDdlObjEn() == DdlObj_SProc ||
         this->getOutDdlObjEn() == DdlObj_Func ||
         this->getOutDdlObjEn() == DdlObj_SubDdlObj ||
         this->getOutDdlObjEn() == DdlObj_Trigger ||
         this->getOutDdlObjEn() == DdlObj_TriggerBody ||
         ((this->getOutDdlObjEn() == DdlObj_Sql || this->getOutDdlObjEn() == DdlObj_SubSql) &&
          (EV_RdbmsVendor == Nuodb || EV_RdbmsVendor == PostgreSQL) && this->ddlGenContextPtr->ddlGenAction.m_installLevel <= 2)))
    {
        bNeedToKnowSproc = true;
        bKnownSproc = this->ddlGenContextPtr->getStoredProcInfo(funcName, dictSprocStp, databaseName);
        if (bKnownSproc == false &&
            funcName.compare(this->ddlGenContextPtr->getDictSprocSt().sqlName) == 0)
        {
            dictSprocStp = &this->ddlGenContextPtr->getDictSprocSt();
            bKnownSproc = true;
        }

        /* PMSTA-42424 - LJE - 201106 */
        if (EV_RdbmsVendor != PostgreSQL && dictSprocStp != nullptr)
        {
            auto fromFileContextPtr = this->context;
            if (fromFileContextPtr != nullptr &&
                fromFileContextPtr->m_position == DdlGenFromFileContext::Position::Then)
            {
                fromFileContextPtr->m_ifResultsSetVector = dictSprocStp->m_dictSprocReturnsVector;
            }
        }
    }

    if (funcName.compare("appl_raiserror") == 0)
    {
        this->printMsg(RET_GEN_ERR_INVARG, "Please use #APPL_RAISERROR keyword instead of '#EXEC appl_raiserror'");
        gblRet = RET_GEN_ERR_INVARG;
    }

    this->extractKeywordParam(this->context->currTag, fixedParam, keywordParamList, false);

    this->context->outDdlGenPtr->setIndent(1);

    std::vector<std::string> paramLineVector;
    if (bKnownSproc && dictSprocStp->m_paramProcAttribVector.size() > 0)
    {
        if (keywordParamList.size() > dictSprocStp->m_paramProcAttribVector.size())
        {
            this->printMsg(RET_GEN_ERR_INVARG, "Too many parameters are defined on call of execute of the stored procedure " + funcName);
            gblRet = RET_GEN_ERR_INVARG;

            bKnownSproc = false;
        }
        else
        {
            paramLineVector.resize(dictSprocStp->m_paramProcAttribVector.size());
        }
    }
    else
    {
        paramLineVector.resize(keywordParamList.size());
    }

    size_t         posParam = 0;
    bool           bByPosParam = false;
    vector<string> outputVariables;
    vector<string> outputParams;

    for (auto paramIt = keywordParamList.begin(); paramIt != keywordParamList.end(); ++paramIt)
    {
        string         paramName, paramValue;
        vector<string> keywordParam = *paramIt;
        bool bOutput = false;

        if (keywordParam.size() > 1 &&
            (keywordParam.at(keywordParam.size() - 1).compare("output") == 0 ||
             keywordParam.at(keywordParam.size() - 1).compare("out") == 0))
        {
            bOutput = true;
            outputStr = this->context->outDdlGenPtr->getCallOutput();
            keywordParam.pop_back();
        }
        else
        {
            outputStr = string();
        }

        if (keywordParam.size() > 1)
        {
            if (keywordParam.size() > 0)
            {
                paramName = keywordParam[0];
            }
            paramValue = keywordParam[1];
        }
        else if (keywordParam.size() > 0)
        {
            paramValue = keywordParam[0];
        }

        DdlGenVar*            variablePtr  = nullptr;
        DictSprocParamClass*  paramDescPtr = nullptr;

        if (dictSprocStp != nullptr)
        {
            if (paramName.empty())
            {
                paramDescPtr = &dictSprocStp->m_paramProcAttribVector[posParam];
            }
            else
            {
                string chkParamName;
                if (paramName[0] == '@')
                {
                    chkParamName = paramName.substr(1);;
                }
                else
                {
                    chkParamName = paramName;
                }

                auto sprocParamIt = dictSprocStp->m_paramProcAttribVector.begin();
                for (; sprocParamIt != dictSprocStp->m_paramProcAttribVector.end(); ++sprocParamIt)
                {
                    if (sprocParamIt->m_sqlName.compare(chkParamName) == 0)
                    {
                        paramDescPtr = &(*sprocParamIt);
                        break;
                    }
                }
            }
        }

        if (paramValue[0] == '@' &&
            (paramValue.size() == 1 || paramValue.at(1) != '@'))
        {
            variablePtr = this->varHelperPtr->getVariable(paramValue);

            paramUsedSet.insert(paramValue);

            if (variablePtr != nullptr)
            {
                if (bOutput || variablePtr->isOut())
                {
                    if (bKnownSproc && 
                        paramDescPtr != nullptr &&
                        paramDescPtr->outputFlg == TRUE)
                    {
                        outputVariables.push_back(variablePtr->printSqlName());
                        outputParams.push_back(this->context->outDdlGenPtr->getParamPrefix() + paramDescPtr->m_sqlName);
                    }
                    this->varHelperPtr->setModify(*variablePtr);
                }

                if (variablePtr->getValue().empty() == false &&
                    variablePtr->bRuntimeValue == false)
                {
                    paramUsedSet.erase(paramValue);
                    paramValue = variablePtr->getValue();
                }
                else if (bFinSrvCal == false)
                {
                    paramValue = variablePtr->printSqlName();
                }
            }
        }

        if (paramName.empty())
        {
            if (bByPosParam == false && posParam > 0)
            {
                this->printMsg(RET_GEN_ERR_INVARG, "It's not allowed to mix parameters by name and by position on call of execute of the stored procedure " + funcName);
                gblRet = RET_GEN_ERR_INVARG;
            }

            if (paramLineVector.size() > posParam)
            {
                paramLineVector[posParam] = paramValue + outputStr;
            }
            bByPosParam = true;
        }
        else if (bByPosParam)
        {
            this->printMsg(RET_GEN_ERR_INVARG, "It's not allowed to mix parameters by name and by position on call of execute of the stored procedure " + funcName);
            gblRet = RET_GEN_ERR_INVARG;
        }
        else
        {
            if (paramName[0] == '@' &&
                (paramName.size() == 1 || paramName.at(1) != '@'))
            {
                paramName.erase(0, 1);
            }

            if (bKnownSproc)
            {
                if (posParam < dictSprocStp->m_paramProcAttribVector.size() &&
                    dictSprocStp->m_paramProcAttribVector[posParam].m_sqlName.compare(paramName) == 0)
                {
                    if (paramLineVector.size() > posParam)
                    {
                        paramLineVector[posParam] = paramValue + outputStr;
                    }
                }
                else
                {
                    if (paramDescPtr == nullptr)
                    {
                        this->printMsg(RET_GEN_ERR_INVARG, "Unknown parameter (" + paramName + ") on call of the stored procedure " + funcName);
                        gblRet = RET_GEN_ERR_INVARG;

                        stringstream availableStream;

                        availableStream << "Available: " << funcName << " ";
                        for (auto sprocParamIt = dictSprocStp->m_paramProcAttribVector.begin(); sprocParamIt != dictSprocStp->m_paramProcAttribVector.end(); ++sprocParamIt)
                        {
                            if (sprocParamIt != dictSprocStp->m_paramProcAttribVector.begin())
                            {
                                availableStream << ", ";
                            }
                            availableStream << "@" << sprocParamIt->m_sqlName;
                        }

                        this->printMsg(RET_GEN_INFO_NODATA, availableStream.str());
                    }
                    else
                    {
                        paramLineVector[paramDescPtr->rank] = paramValue + outputStr;
                    }
                }
            }
            else if (paramLineVector.empty() == false)
            {
                paramLineVector[posParam] = this->context->outDdlGenPtr->getParamAssign(paramName) + paramValue + outputStr;
            }

            if (bFinSrvCal &&
                reportServerName.empty() == false &&
                paramName.compare(reportServerName) == 0)
            {
                DdlSprocParam newParam(this->ddlGenContextPtr->getDictSprocSt(), this->ddlGenContextPtr->m_rdbmsEn);
                newParam.sqlName = paramName;
                newParam.setDataType(SysnameType);
                newParam.setValue(paramValue.substr(1, paramValue.length() - 2));
                this->varHelperPtr->addParameter(newParam);
                reportServerName.clear();
            }
        }
        posParam++;
    }

    if (bByPosParam &&
        bNeedToKnowSproc &&
        dictSprocStp != nullptr &&
        dictSprocStp->procActionEn != Custom &&
        dictSprocStp->procActionEn != Special &&
        dictSprocStp->inputObjectEn != NullEntity &&
        dictSprocStp->inputObjectEn != InvalidEntity)
    {
        stringstream availableStream;

        availableStream << "#EXEC " << dictSprocStp->sqlName << " : The parameters of a standard stored procedure should be named (";

        for (auto sprocParamIt = dictSprocStp->m_paramProcAttribVector.begin(); sprocParamIt != dictSprocStp->m_paramProcAttribVector.end(); ++sprocParamIt)
        {
            if (sprocParamIt != dictSprocStp->m_paramProcAttribVector.begin())
            {
                availableStream << ", ";
            }
            availableStream << sprocParamIt->m_sqlName << " = ";
        }
        availableStream << ") or use #CALL (" << dictSprocStp->getDictEntityStp()->mdSqlName << ") keyword";

        this->printMsg(RET_GEN_INFO_NODATA, availableStream.str());
    }

    posParam = 0;
    for (auto paramLineIt = paramLineVector.begin(); paramLineIt != paramLineVector.end(); ++paramLineIt)
    {
        if (dictSprocStp != nullptr &&
            dictSprocStp->m_paramProcAttribVector.empty() == false)
        {
            DictSprocParamClass& dictSprocParamSt = dictSprocStp->m_paramProcAttribVector[posParam];

            if (paramLineIt->empty() == true)
            {
                if (dictSprocParamSt.defaultValueC.empty())
                {
                    (*paramLineIt) = "null";
                }
                else
                {
                    (*paramLineIt) = dictSprocParamSt.defaultValueC;
                }
            }

            if (this->ddlGenContextPtr->m_rdbmsEn == PostgreSQL &&
                ((*paramLineIt).find_first_not_of(DDLGEN_NUMERIC) == string::npos ||
                 strcasecmp((*paramLineIt).c_str(), "null") == 0) &&
                dictSprocParamSt.getDataTypeEn() != NullDataType &&
                GET_CTYPE(dictSprocParamSt.getDataTypeEn()) != IntCType &&
                GET_CTYPE(dictSprocParamSt.getDataTypeEn()) != UIntCType &&
                GET_CTYPE(dictSprocParamSt.getDataTypeEn()) != LongLongCType)
            {
                (*paramLineIt) = this->context->outDdlGenPtr->convert(dictSprocParamSt.getDataTypeEn(), (*paramLineIt), false);
            }
        }

        sprocParam << newLine;
        if (paramLineIt != paramLineVector.begin())
        {
            sprocParam << ", ";
        }
        else
        {
            sprocParam << "  ";
        }

        sprocParam << (*paramLineIt);
        posParam++;
    }

    this->context->outDdlGenPtr->setIndent(-1);

    if (bFinSrvCal)
    {
        if (paramUsedSet.size())
        {
            this->context->outDdlGenPtr->bodySqlBlock << this->context->outDdlGenPtr->getIndent() << "#" << TAG_GET << " ";
            for (auto it = paramUsedSet.begin(); it != paramUsedSet.end(); it++)
            {
                if (it != paramUsedSet.begin())
                {
                    this->context->outDdlGenPtr->bodySqlBlock << ", ";
                }
                this->context->outDdlGenPtr->bodySqlBlock << *it;
            }
        }

        *(outSqlBlockPtr) << this->context->outDdlGenPtr->getIndent() << funcName << " " << sprocParam.str();
    }
    else if (bNeedToKnowSproc == true &&
             bKnownSproc == false &&
             funcName[0] != '@' &&
             funcName[0] != '(')
    {
        *(outSqlBlockPtr) << this->context->outDdlGenPtr->getIndent() << this->context->outDdlGenPtr->getCmdNoOp(this) << " - unknown stored procedure: " << funcName;
        if (this->ddlGenContextPtr->ddlGenAction.m_installLevel < 5)
        {
            ret = RET_DBA_ERR_PROCNOTFOUND;
        }
    }
    else
    {
        if (CAST_INT(paramLineVector.size()) > EV_MaxNumberArgument)
        {
            this->printMsg(RET_GEN_ERR_INVARG, SYS_Stringer("It's not allowed to have more than ", 
                                                            EV_MaxNumberArgument, 
                                                            " parameters on call to execute the stored procedure ",
                                                            funcName));
            gblRet = RET_GEN_ERR_INVARG;
        }

        *(outSqlBlockPtr) << this->context->outDdlGenPtr->getIndent()
            << this->context->outDdlGenPtr->getCmdExecSProc(databaseName, funcName, sprocParam.str(), resultVar, outputVariables, outputParams, dictSprocStp);
    }
    this->m_bNewLine = true;

    if (this->getOutDdlObjEn() != DdlObj_RuntimeSql)
    {
        this->ddlGenContextPtr->m_dependsSprocSet.insert(DdlGenDependKey(0, funcName, DictDependsAccessEn::Call, DynType_Null)); /* PMSTA-29956 - LJE - 180125 */
    }

    if (this->context->outDdlGenPtr->lastErrRetCode != RET_SUCCEED)
    {
        ret = this->context->outDdlGenPtr->lastErrRetCode;
    }

    this->ddlGenContextPtr->m_rdbmsEn = savedRdbms;
    EV_RdbmsDdlGen = savedRdbmsDdlGen;

    if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
    {
        gblRet = ret;
    }

    return gblRet;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::createSProcRename()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-18593 - LJE - 160315
**
*************************************************************************/
RET_CODE DdlGenFromFile::createSProcRename()
{
    vector<vector<string>> keywordParamList;
    this->extractKeywordParam(this->context->currTag, 0, keywordParamList, false);

    std::string renameCmd;

    if (keywordParamList.size() == 2 || 
        keywordParamList.size() == 3)
    {
        DDL_OBJ_ENUM ddlObjType = (keywordParamList.size() == 2 ? DdlObj_Table : this->getDdlObjEnFromStr(keywordParamList[2][0]));

        if (ddlObjType == DdlObj_Table ||
            ddlObjType == DdlObj_Column)
        {
            renameCmd = this->context->outDdlGenPtr->getCmdRename(keywordParamList[0][0], keywordParamList[1][0], ddlObjType);
        }
    }

    if (renameCmd.empty())
    {
        this->printMsg(RET_GEN_ERR_INVARG, "Keyword #" + this->context->currTag + ": Invalid argument");
        return RET_GEN_ERR_INVARG;
    }
    else
    {
        this->context->outDdlGenPtr->bodySqlBlock << renameCmd;
    }

    return RET_SUCCEED;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::createSProcUse()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-18593 - LJE - 150619
**
*************************************************************************/
RET_CODE DdlGenFromFile::createSProcUse()
{
    RET_CODE        ret = RET_SUCCEED;
    vector<string>  tokens;

    this->tokenize(tokens, " \t=");

    if (tokens.size() < 2)
    {
        this->printMsg(RET_GEN_ERR_INVARG, "Keyword #" + this->context->currTag + ": Invalid argument");
        return RET_GEN_ERR_INVARG;
    }

    this->ddlGenContextPtr->setDdlDestDbName(tokens.at(1), this->context->outDdlGenPtr);
    this->ddlGenContextPtr->setDefDdlDestDbName(this->ddlGenContextPtr->getDdlDestDbName());

    this->bKeepConnection = true;

    if (this->ddlGenContextPtr->bGenFromDbi)
    {
        this->context->outDdlGenPtr->cmdType = DDlCmdType_DbProcess;

        this->context->outDdlGenPtr->bodySqlBlock
            << this->context->outDdlGenPtr->newLine()
            << this->context->outDdlGenPtr->getCmdUseDb(this->ddlGenContextPtr->getDdlDestDbName(), this->ddlGenContextPtr->m_rdbmsEn)
            << endl;
        this->context->outDdlGenPtr->flush();
    }
    else if (this->ddlGenContextPtr->ddlGenAction.m_installLevel == 20) /* PMSTA-43914 - LJE - 210315 */
    {
        this->setInBlock(false);
        this->context->outDdlGenPtr->bodySqlBlock
            << this->context->outDdlGenPtr->newLine()
            << this->context->outDdlGenPtr->getCmdUseDb(this->ddlGenContextPtr->getDdlDestDbName(), this->ddlGenContextPtr->m_rdbmsEn)
            << endl;
    }
    else
    {
        this->context->outDdlGenPtr->bodySqlBlock
            << this->context->outDdlGenPtr->newLine()
            << DdlGenDbi::getCmdNoOp(this)
            << endl;
    }
    return ret;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::createSProcIfExists()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  ORACLE - LJE - 140707
**
*************************************************************************/
RET_CODE DdlGenFromFile::createSProcIfExists()
{
    RET_CODE        ret = RET_SUCCEED;
    ret = this->createSProcIf();
    return ret;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::createSProcWhile()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  ORACLE - LJE - 140707
**
*************************************************************************/
RET_CODE DdlGenFromFile::createSProcWhile()
{
    RET_CODE        ret = RET_SUCCEED;
    ret = this->createSProcIf();
    return ret;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::createSProcSetRowcount()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  ORACLE - LJE - 140707
**
** Last modif.  : 
**
*************************************************************************/
RET_CODE DdlGenFromFile::createSProcSetRowcount()
{
    RET_CODE        ret = RET_SUCCEED;
    vector<string>  tokens;
    this->tokenize(tokens);

    if (tokens.size() != 2)
    {
        ret = RET_GEN_ERR_INVARG;
        this->printMsg(ret, "Syntax error on keyword #" + this->context->currTag);
        return ret;
    }

    this->varHelperPtr->rowCount = tokens.at(1);

    if (this->varHelperPtr->rowCount.find("@") == 0)
    {
        DdlGenVar* countVar = this->varHelperPtr->getVariable(this->varHelperPtr->rowCount.substr(1));

        if (countVar != nullptr)
        {
            if (countVar->getDataType() != IntType)
            {
                ret = RET_DBA_ERR_INVDATA;
                this->printMsg(ret, "Invalid data-type for #" + this->context->currTag + " variable '" + this->varHelperPtr->rowCount.substr(1) + "', must be int_t");
            }

            if (this->ddlGenContextPtr->m_rdbmsEn == MSSql)
            {
                this->context->outDdlGenPtr->bodySqlBlock
                    << this->context->outDdlGenPtr->getCmdIfThenElse(this->varHelperPtr->rowCount + " = 0",
                                                                     this->context->outDdlGenPtr->getIndent() + "\tset " + this->varHelperPtr->rowCount + this->context->outDdlGenPtr->getVarAssign() + "99999999999999" + this->context->outDdlGenPtr->endOfCmd(),
                                                                     string(), false, false);
            }
            else if (this->ddlGenContextPtr->m_rdbmsEn == Oracle ||
                     this->ddlGenContextPtr->m_rdbmsEn == Nuodb ||
                     this->ddlGenContextPtr->m_rdbmsEn == PostgreSQL)
            {
                this->context->outDdlGenPtr->bodySqlBlock
                    << this->context->outDdlGenPtr->getCmdIfThenElse(this->varHelperPtr->rowCount + " = 0",
                                                                     this->context->outDdlGenPtr->getIndent() + "\t" + this->varHelperPtr->rowCount + this->context->outDdlGenPtr->getVarAssign() + "2147483648" + this->context->outDdlGenPtr->endOfCmd(),
                                                                     string(), false, false);
            }
        }
        else
        {
            ret = RET_DBA_ERR_INVDATA;
            this->printMsg(ret, "Unknown #" + this->context->currTag + " variable '" + this->varHelperPtr->rowCount.substr(1) + "'");
        }
    }

    this->context->outDdlGenPtr->bodySqlBlock << this->context->outDdlGenPtr->getSetRowcount();

    return ret;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::createSProcSetForcePlan()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  
**
** Last modif.  :
**
*************************************************************************/
RET_CODE DdlGenFromFile::createSProcSetForcePlan()
{
    RET_CODE        ret = RET_SUCCEED;

    vector<string>  tokens;
    this->tokenize(tokens);

    if (this->ddlGenContextPtr->m_rdbmsEn == MSSql ||
        this->ddlGenContextPtr->m_rdbmsEn == Sybase)
    {
        if (tokens.size() != 2 || 
            (tokens[1] != "on" && tokens[1] != "off"))
        {
            ret = RET_GEN_ERR_INVARG;
            this->printMsg(ret, "Syntax error on keyword #" + this->context->currTag);
            return ret;
        }

        this->context->outDdlGenPtr->bodySqlBlock 
            << this->context->outDdlGenPtr->newLine() 
            << "set forceplan " << tokens[1];
    }
    else
    {
        this->context->outDdlGenPtr->bodySqlBlock
            << this->context->outDdlGenPtr->newLine()
            << DdlGenDbi::getCmdNoOp(this) << " set forceplan " << tokens[1];
    }

    return ret;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::createSProcGetUpdateCount()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     : PMSTA-49178 - LJE - 220922
**
** Last modif.  : 
**
*************************************************************************/
RET_CODE DdlGenFromFile::createSProcGetUpdateCount()
{
    RET_CODE        ret = RET_SUCCEED;
    vector<string>  tokens;
    this->tokenize(tokens);

    if (tokens.size() != 2)
    {
        ret = RET_GEN_ERR_INVARG;
        this->printMsg(ret, "Syntax error on keyword #" + this->context->currTag);
        return ret;
    }

    this->context->outDdlGenPtr->bodySqlBlock
        << this->context->outDdlGenPtr->newLine() << this->buildScript(this->context->outDdlGenPtr->getCmdAssignUpdateCount(tokens[1]));

    return ret;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::createSProcSetDatefirst()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-18593 - LJE - 150430
**
*************************************************************************/
RET_CODE DdlGenFromFile::createSProcSetDatefirst()
{
    RET_CODE        ret = RET_SUCCEED;
    vector<string>  tokens;
    this->tokenize(tokens);

    if (tokens.size() != 2)
    {
        ret = RET_GEN_ERR_INVARG;
        this->printMsg(ret, "Syntax error on keyword #" + this->context->currTag);
        return ret;
    }

    this->varHelperPtr->dateFirstEn = (CALCONVWEEKDAY_ENUM)atoi(tokens[1].c_str());

    this->context->outDdlGenPtr->bodySqlBlock << this->context->outDdlGenPtr->getSetDateFirst();

    return ret;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::createSProcCheck()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-18593 - LJE - 141218
**
*************************************************************************/
RET_CODE DdlGenFromFile::createSProcCheck()
{
    RET_CODE        ret = RET_SUCCEED;
    vector<string>  tokens;

    this->tokenize(tokens);

    if (tokens.size() != 3 && tokens.size() != 2)
    {
        ret = RET_GEN_ERR_INVARG;
        this->printMsg(ret, "Syntax error on keyword #" + this->context->currTag);
        return ret;
    }

    string currAttribStr, currVarStr, attribAccessStr = tokens.at(1);

    if (attribAccessStr[0] == '@')
    {
        currAttribStr = attribAccessStr.substr(3);
        currVarStr = attribAccessStr.substr(1);
    }
    else if (attribAccessStr.find(this->context->outDdlGenPtr->getNewPrefix()) == 0 ||
             attribAccessStr.find(this->context->outDdlGenPtr->getOldPrefix()) == 0)
    {
        currAttribStr = attribAccessStr.substr(this->context->outDdlGenPtr->getNewPrefix().length());
    }
    else
    {
        currAttribStr = attribAccessStr;
    }
    DICT_ATTRIB_STP currAttribStp = DBA_GetAttributeBySqlName(this->context->outDdlGenPtr->getDictEntityStp()->objectEn, currAttribStr.c_str());

    if (currAttribStp != NULL)
    {
        stringstream    outStream;
        OBJECT_ENUM     fkObjEn = NullEntity;

        if (tokens.size() >= 3)
        {
            DICT_ENTITY_STP locDictEntityStp = DBA_GetEntityBySqlName(tokens.at(2));
            if (locDictEntityStp != NULL)
            {
                fkObjEn = locDictEntityStp->objectEn;
            }
        }
        else
        {
            DBA_GetObjectEnum(currAttribStp->refEntDictId, &fkObjEn);
        }

        if (fkObjEn == FctResult)
        {
            fkObjEn = Domain;
        }

        outStream
            << this->context->outDdlGenPtr->newLine() << "#IF ";

        if ((this->getOutDdlObjEn() == DdlObj_TriggerBody || this->getOutDdlObjEn() == DdlObj_TriggerUdFieldBody) &&
            this->dmlEventEn == DmlEvent_Update &&
            (this->context->outDdlGenPtr->getDictEntityStp()->primKeyNbr > 0 ||
             this->context->outDdlGenPtr->getDictEntityStp()->bkAttrNbr > 0))
        {
            outStream
                << "#UPDATING(" << currAttribStr << ") and ";
        }

        outStream
            << attribAccessStr << " is not null";

        if (currAttribStp->dataTpProgN == DictType ||
            currAttribStp->refCheckRuleEn == RefChkRule_CheckedZeroAllowed)
        {
            outStream
                << " and " << attribAccessStr << " > 0";
        }

        DICT_ENTITY_STP fkDictEntityStp = DBA_GetDictEntitySt(fkObjEn);

        /* PMSTA-37366 - LJE - 191105 */
        if (fkDictEntityStp != NULL &&
            (this->getOutDdlObjEn() == DdlObj_TriggerBody || this->getOutDdlObjEn() == DdlObj_TriggerUdFieldBody) &&
            fkDictEntityStp->entDictId == this->context->outDdlGenPtr->getDictEntityStp()->entDictId &&
            this->context->outDdlGenPtr->getDictEntityStp()->primKeyNbr > 0)
        {
            outStream
                << " and " << attribAccessStr << " <> #NEW.";

            if (this->outDdlObjEn == DdlObj_TriggerUdFieldBody)
            {
                outStream << DdlGen::getUdIdSqlName();
            }
            else
            {
                outStream << this->context->outDdlGenPtr->getDictEntityStp()->primKeyTab[0]->sqlName;
            }
        }

        outStream
            << this->context->outDdlGenPtr->newLine() << "#{";
        this->context->outDdlGenPtr->setIndent(1);

        if (fkDictEntityStp != NULL)
        {
            /* PMSTA-26250 - LJE - 170504 */
            if (fkDictEntityStp->pkEntityStp)
            {
                fkDictEntityStp = fkDictEntityStp->pkEntityStp;
            }

            if (fkDictEntityStp->objectEn == Tp)
            {
                string typeAttDictIdStr, attDictIdStr;

                attDictIdStr = SYS_ToString(currAttribStp->attrDictId);

                if (currAttribStp->linkedAttrDictStp == NULL)
                {
                    /* PMSTA-36158 - LJE - 190627 */
                    if (currAttribStp->parAttrDictId == 0)
                    {
                        typeAttDictIdStr = attDictIdStr;
                    }
                    else
                    {
                        typeAttDictIdStr = SYS_ToString(currAttribStp->parAttrDictId);
                    }
                }
                else
                {
                    typeAttDictIdStr = "#NEW.";
                    typeAttDictIdStr.append(currAttribStp->linkedAttrDictStp->sqlName);
                }

                if (currVarStr.empty() == false)
                {
                    this->varHelperPtr->addVariable(currVarStr, currAttribStp->dataTpProgN);
                }

                this->varHelperPtr->addVariable("return_status", IntType);

                outStream
                    << this->context->outDdlGenPtr->newLine()
                    << "#EXEC @return_status = chk_type_id_dict_id " << attribAccessStr << ", " << attDictIdStr << ", " << typeAttDictIdStr
                    << this->context->outDdlGenPtr->newLine()
                    << "#IF @return_status = -1"
                    << this->context->outDdlGenPtr->newLine()
                    << "#{";
                this->context->outDdlGenPtr->setIndent(1);
                outStream
                    << this->context->outDdlGenPtr->newLine() << "#ROLLBACK_TRAN"
                    << this->context->outDdlGenPtr->newLine() << "#RETURN";
                this->context->outDdlGenPtr->setIndent(-1);
                outStream
                    << this->context->outDdlGenPtr->newLine() << "#}";
            }
            else if (fkDictEntityStp->primKeyNbr == 1)
            {
                this->varHelperPtr->addVariable("note", NoteType);
                if (currVarStr.empty() == false)
                {
                    this->varHelperPtr->addVariable(currVarStr, currAttribStp->dataTpProgN);
                }

                if (this->context->outDdlGenPtr->getDictEntityStp()->multiEntityCateg.isForceOnConnectedBusinessEntity())
                {
                    outStream
                        << this->context->outDdlGenPtr->newLine() << "#FORCE_CONN_ENTITY";
                }

                outStream
                    << this->context->outDdlGenPtr->newLine() << "#IF_NOT_EXISTS (select 'x' from "
                    << this->context->outDdlGenPtr->getEntityFullSqlName(fkDictEntityStp)
                    << " where " << fkDictEntityStp->primKeyTab[0]->sqlName << " = " << attribAccessStr << ")"
                    << this->context->outDdlGenPtr->newLine() << "#{";

                this->context->outDdlGenPtr->setIndent(1);
                outStream
                    << this->context->outDdlGenPtr->newLine() << "#ASSIGN @note=#CONVERT(note_t, " << attribAccessStr << ")"
                    << this->context->outDdlGenPtr->newLine() << "#APPL_RAISERROR 20014, #CURR_DDL_OBJECT";

                outStream
                    << ", '" << currAttribStr
                    << "', @note, '" << this->context->outDdlGenPtr->getDictEntityStp()->mdSqlName << "'"
                    << this->context->outDdlGenPtr->newLine() << "#ROLLBACK_TRAN"
                    << this->context->outDdlGenPtr->newLine() << "#RETURN";

                this->context->outDdlGenPtr->setIndent(-1);
                outStream
                    << this->context->outDdlGenPtr->newLine() << "#}";
            }
        }
        else if (currAttribStp->linkedAttrDictStp &&
                 currAttribStp->linkedAttrDictStp->refEntDictId == this->dictEntityDictId)
        {
            const string chkProcStr = (currAttribStp->primFlg == TRUE &&
                                       /* PMSTA-30124 - LJE - 180209 */
                                       this->context->outDdlGenPtr->getDictEntityStp()->multiEntityCateg.isCheckBeOnParent()
                                       ? "chk_dict_entity_object_for_upd" : "chk_dict_entity_object_id");

            this->varHelperPtr->addVariable("return_status", IntType);

            outStream
                << this->context->outDdlGenPtr->newLine()
                << "#EXEC @return_status = #AAAMAIN_DB." << chkProcStr << " #NEW." << currAttribStp->linkedAttrDictStp->sqlName << ", #NEW." << currAttribStp->sqlName
                << this->context->outDdlGenPtr->newLine()
                << "#IF @return_status = -1"
                << this->context->outDdlGenPtr->newLine()
                << "#{";
            this->context->outDdlGenPtr->setIndent(1);
            outStream
                << this->context->outDdlGenPtr->newLine() << "#ROLLBACK_TRAN"
                << this->context->outDdlGenPtr->newLine() << "#RETURN";
            this->context->outDdlGenPtr->setIndent(-1);
            outStream
                << this->context->outDdlGenPtr->newLine() << "#}";
        }
        else
        {
            ret = RET_DBA_ERR_INVDATA;
            this->printMsg(ret, "Unable to manage check foreign key on complex primary key, attribute " + currAttribStr);
        }

        this->context->outDdlGenPtr->setIndent(-1);
        outStream
            << this->context->outDdlGenPtr->newLine() << "#}";

        this->context->outDdlGenPtr->bodySqlBlock << outStream.str();
    }
    else
    {
        ret = RET_DBA_ERR_INVDATA;
        this->context->outDdlGenPtr->bodySqlBlock << this->context->currLineStr;
        this->printMsg(ret, "Unknown attribute " + currAttribStr + " on keyword #" + this->context->currTag);
    }

    return ret;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::createSProcIf()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  ORACLE - LJE - 140707
**
*************************************************************************/
RET_CODE DdlGenFromFile::createSProcIf()
{
    RET_CODE        ret = RET_SUCCEED, gblRet = RET_SUCCEED;
    string          ifStr, thenStr, elseStr, parentPreIndent, currPreIndent;
    bool            bElseIf = false, bToContinue = false,
        bIgnore = false, bIf = false, bThen = false, bIgnoreIf = false;

    bool            bExistsClause = false;

    DdlGenTagInfo     currTagInfo, nextTagInfo;

    DdlGenFromFileContext *savedContext = this->context;

    MemoryPool mp;
    DdlGenFromFileContext* localContext(new DdlGenFromFileContext());
    mp.ownerObject(localContext);

    localContext->blockLineBeginNb     = this->context->blockLineBeginNb;
    localContext->lineNb               = this->context->lineNb;
    localContext->bInitCurrLineIt      = false;
    localContext->bUpdateIndent        = true;
    localContext->parentTagNat         = this->context->currTagNat;
    localContext->m_position           = DdlGenFromFileContext::Position::If;

    parentPreIndent = this->context->outDdlGenPtr->getPreIndent();
    this->context->parentPreIndent = "";

    currTagInfo = this->getTag();
    nextTagInfo = this->getNextTag(currTagInfo);
    if (nextTagInfo.name.empty())
    {
        stringstream msg;
        ret = RET_SRV_LIB_ERR_SYNTAX;
        msg << "Syntax error after keyword " << currTagInfo.name + " at line " << currTagInfo.lineNbr + this->context->blockLineBeginNb;
        this->printMsg(ret, msg.str());
        return ret;
    }

    if (this->isTag(TAG_ELSE_IF) &&
        this->context->bIfIgnored == false)
    {
        bElseIf = true;
    }
    this->context->bIfIgnored = false;

    if (savedContext->m_position != DdlGenFromFileContext::Position::None ||
        bElseIf)
    {
        localContext->m_ifResultsSetVector = savedContext->m_ifResultsSetVector;
    }
    else
    {
        this->context->m_ifResultsSetVector.clear();
    }

    bool    bNot = false;
    string  closeCmd;

    if (this->isTag(TAG_IF_EXISTS))
    {
        bNot = false;
        bExistsClause = true;
        this->context->currLineStrLTrim.replace(0, savedContext->currTag.length() + 1, this->context->outDdlGenPtr->getCmdExists(bNot, closeCmd));
    }
    else if (this->isTag(TAG_IF_NOT_EXISTS))
    {
        bNot = true;
        bExistsClause = true;
        this->context->currLineStrLTrim.replace(0, savedContext->currTag.length() + 1, this->context->outDdlGenPtr->getCmdExists(bNot, closeCmd));
    }
    else
    {
        this->context->currLineStrLTrim.replace(0, savedContext->currTag.length() + 1, "");
    }

    if (this->context->currLineStrLTrim.find_first_not_of(" \t") != string::npos)
    {
        this->context->currLineStr = this->context->currLineStrLTrim;
    }
    else
    {
        this->getGenSqlLine();
    }

    /* Search end of clause if */
    this->context->bUpdateIndent = false;
    while (elseStr.empty() && nextTagInfo.tagNatEn != TagSql_EndIf && nextTagInfo.tagNatEn != TagSql_ElseIf && nextTagInfo.nextTagNatEn != TagSql_ElseIf)
    {
        if (bIf)
        {
            currTagInfo = nextTagInfo;
            nextTagInfo = this->getNextTag(currTagInfo);

            while (this->context->lineNb < currTagInfo.readLinePos && this->getGenSqlLine());

            if (nextTagInfo.tagNatEn == currTagInfo.tagNatEn || nextTagInfo.name.empty())
            {
                break;
            }

            if (nextTagInfo.tagNatEn == TagSql_ElseIf || nextTagInfo.nextTagNatEn == TagSql_ElseIf)
            {
                bToContinue = true;
            }
        }

        do
        {
            if (bIf == false &&
                (this->isTag(TAG_OR_EXISTS) || this->isTag(TAG_AND_EXISTS) || this->isTag(TAG_OR_NOT_EXISTS) || this->isTag(TAG_AND_NOT_EXISTS)))
            {
                bExistsClause = true;
                currPreIndent = this->context->currLineStr.substr(0, this->context->currLineStr.find_first_not_of(" \t"));

                if (closeCmd.empty() == false)
                {
                    localContext->currBlockVector.push_back(closeCmd);
                    closeCmd.clear();
                }

                if (this->isTag(TAG_OR_EXISTS))
                {
                    bNot = false;
                    savedContext->currTagNat = TagSql_IfExists;
                    this->context->currLineStrLTrim.replace(0, strlen(TAG_OR_EXISTS) + 2, "or " + this->context->outDdlGenPtr->getCmdExists(bNot, closeCmd) + " ");
                    if (this->context->currLineStrLTrim.empty())
                    {
                        continue;
                    }
                    this->context->currLineStr = currPreIndent + this->context->outDdlGenPtr->getIndent() + this->context->currLineStrLTrim;
                }
                else if (this->isTag(TAG_AND_EXISTS))
                {
                    bNot = false;
                    savedContext->currTagNat = TagSql_IfExists;
                    this->context->currLineStrLTrim.replace(0, strlen(TAG_AND_EXISTS) + 2, "and " + this->context->outDdlGenPtr->getCmdExists(bNot, closeCmd) + " ");
                    if (this->context->currLineStrLTrim.empty())
                    {
                        continue;
                    }
                    this->context->currLineStr = currPreIndent + this->context->outDdlGenPtr->getIndent() + this->context->currLineStrLTrim;
                }
                else if (this->isTag(TAG_OR_NOT_EXISTS))
                {
                    bNot = true;
                    savedContext->currTagNat = TagSql_IfExists;
                    this->context->currLineStrLTrim.replace(0, strlen(TAG_OR_NOT_EXISTS) + 2, "or " + this->context->outDdlGenPtr->getCmdExists(bNot, closeCmd) + " ");
                    if (this->context->currLineStrLTrim.empty())
                    {
                        continue;
                    }
                    this->context->currLineStr = currPreIndent + this->context->outDdlGenPtr->getIndent() + this->context->currLineStrLTrim;
                }
                else if (this->isTag(TAG_AND_NOT_EXISTS))
                {
                    bNot = true;
                    savedContext->currTagNat = TagSql_IfExists;
                    this->context->currLineStrLTrim.replace(0, strlen(TAG_AND_NOT_EXISTS) + 2, "and " + this->context->outDdlGenPtr->getCmdExists(bNot, closeCmd) + " ");
                    if (this->context->currLineStrLTrim.empty())
                    {
                        continue;
                    }
                    this->context->currLineStr = currPreIndent + this->context->outDdlGenPtr->getIndent() + this->context->currLineStrLTrim;
                }
            }

            localContext->currBlockVector.push_back(this->context->currLineStr);
        } while (this->context->lineNb < nextTagInfo.readLinePos && this->getGenSqlLine());

        if (closeCmd.empty() == false)
        {
            localContext->currBlockVector.push_back(closeCmd);
            closeCmd.clear();
        }

        /* PMSTA-26250 - LJE - 170403 */
        if (bExistsClause)
        {
            string   tmpStr;
            for (auto it = localContext->currBlockVector.begin(); it != localContext->currBlockVector.end(); it++)
            {
                tmpStr += *it + "\n";
            }

            if (this->context->outDdlGenPtr->extractAndFixDependsEntity(tmpStr))
            {
                if (tmpStr.empty() &&
                    this->ddlGenContextPtr->ddlGenAction.isBootStrapLevel())
                {
                    this->context->outDdlGenPtr->bodySqlBlock.clear();
                    ret = RET_GEN_INFO_NOACTION;
                }

                string tmpLineStr;
                stringstream tmpStream;

                localContext->currBlockVector.clear();
                tmpStream << tmpStr;
                tmpStr.clear();
                tmpStream.clear();
                tmpStream.seekg(0, ios::beg);
                while (getline(tmpStream, tmpLineStr))
                {
                    localContext->currBlockVector.push_back(tmpLineStr);
                }
            }
        }

        localContext->blockLineBeginNb              = savedContext->blockLineBeginNb + this->context->lineNb - 1;
        this->context                               = localContext;
        this->context->bInitCurrLineIt              = false;
        this->context->bUpdateIndent                = true;
        this->newOutDdlGen();
        this->context->outDdlGenPtr->clearIndent();
        this->context->outDdlGenPtr->setIndent(savedContext->outDdlGenPtr->recurseEndCpt);
        this->context->parentPreIndent              = this->context->outDdlGenPtr->getIndent();
        this->context->outDdlGenPtr->setPreIndent(parentPreIndent);
        this->context->outDdlGenPtr->bNestedRequest = ifStr.empty();
        this->context->outDdlGenPtr->bManageAuthFlg = savedContext->outDdlGenPtr->bManageAuthFlg;
        this->context->outDdlGenPtr->translateFlg   = savedContext->outDdlGenPtr->translateFlg;
        this->context->outDdlGenPtr->setMsgObjType(this->getMsgObjType());
        this->context->outDdlGenPtr->setMsgEntitySqlName(this->getMsgEntitySqlName());
        this->context->outDdlGenPtr->setMsgSqlName(this->getMsgSqlName());

        if (bIf)
        {
            this->context->m_elseResultsSetPos = 0;

            if (bElseIf)
            {
                this->context->m_position = DdlGenFromFileContext::Position::ElseIf;
            }
            else if (bThen)
            {
                this->context->m_position = DdlGenFromFileContext::Position::Else;
            }
            else
            {
                if (savedContext->m_position == DdlGenFromFileContext::Position::None ||
                    savedContext->m_ifResultsSetVector.empty())
                {
                    this->context->m_position = DdlGenFromFileContext::Position::Then;
                }
                else
                {
                    this->context->m_position = DdlGenFromFileContext::Position::Else;
                }
            }
        }

        if ((ret = this->buildBlock()) != RET_SUCCEED)
        {
            if (this->ddlGenContextPtr->ddlGenAction.isBootStrapLevel())
            {
                this->context->outDdlGenPtr->bodySqlBlock.clear();
                ret = RET_GEN_INFO_NOACTION;
            }
            else
            {
                gblRet = ret;
            }
        }
        this->context->bIfIgnored = false;

        bIgnore = false;
        if (this->context->outDdlGenPtr->bodySqlBlock.str().empty() ||
            this->context->outDdlGenPtr->bodySqlBlock.str().find_first_not_of("\n") == string::npos)
        {
            if (this->bAllowEmptyBlock == false && this->ddlGenContextPtr->ddlGenAction.m_installLevel <= 5)
            {
                stringstream msg;
                ret = RET_SRV_LIB_ERR_SYNTAX;
                msg << "Syntax error after keyword " << currTagInfo.name + " at line " << currTagInfo.lineNbr + this->context->blockLineBeginNb;
                this->printMsg(ret, msg.str());
            }

            bIgnore = true;
        }

        if (bIf == false)
        {
            bIf = true;
            if (bIgnore)
            {
                bIgnoreIf = true;
            }
            else
            {
                ifStr = this->context->outDdlGenPtr->bodySqlBlock.str();
            }
        }
        else if (bThen == false)
        {
            bThen = true;
            if (bIgnore)
            {
                bIgnoreIf = true;
            }
            else
            {
                thenStr = this->context->outDdlGenPtr->bodySqlBlock.str();
                if (thenStr.at(thenStr.length() - 1) != '\n')
                {
                    thenStr += '\n';
                }
            }
        }
        else
        {
            if (bIgnore == false)
            {
                elseStr = this->context->outDdlGenPtr->bodySqlBlock.str();
                if (elseStr.at(elseStr.length() - 1) != '\n')
                {
                    elseStr += '\n';
                }
            }
        }

        bExistsClause = false;
        this->deleteOutDdlGen();

        savedContext->m_ifResultsSetVector = this->context->m_ifResultsSetVector;

        this->context = savedContext;

        while (this->context->lineNb < nextTagInfo.lineNbr && this->getGenSqlLine());
    }
    this->context->bUpdateIndent = true;

    if (currTagInfo.tagNatEn == TagSql_Then && nextTagInfo.tagNatEn == TagSql_ElseIf)
    {
        this->resetNextCurrBlock(1);
    }

    savedContext->outDdlGenPtr->setPreIndent(parentPreIndent);
    this->context->outDdlGenPtr->setIndent(this->context->outDdlGenPtr->recurseEndCpt);

    if (bIgnoreIf == false)
    {
        if (savedContext->currTagNat == TagSql_IfExists)
        {
            this->context->outDdlGenPtr->bodySqlBlock << savedContext->outDdlGenPtr->getCmdIfExsists(ifStr, string(), thenStr, elseStr, false, bToContinue);
        }
        else if (savedContext->currTagNat == TagSql_If)
        {
            this->context->outDdlGenPtr->bodySqlBlock << savedContext->outDdlGenPtr->getCmdIfThenElse(ifStr, thenStr, elseStr, bElseIf, bToContinue);

            if (bElseIf)
            {
                this->context->outDdlGenPtr->bodySqlBlock << endl;
            }
        }
        else if (savedContext->currTagNat == TagSql_While)
        {
            this->context->outDdlGenPtr->bodySqlBlock << savedContext->outDdlGenPtr->getCmdWhile(ifStr, thenStr);
        }
    }
    else
    {
        if (bToContinue == false && bElseIf && this->context->outDdlGenPtr->bodySqlBlock.str().empty() == false)
        {
            if (savedContext->currTagNat == TagSql_IfExists)
            {
                this->context->outDdlGenPtr->bodySqlBlock << savedContext->outDdlGenPtr->getEndIfExists();
            }
            else if (savedContext->currTagNat == TagSql_If)
            {
                this->context->outDdlGenPtr->bodySqlBlock << savedContext->outDdlGenPtr->getEndIf();
            }
        }

        if (bElseIf == false)
        {
            this->context->bIfIgnored = true;
        }
    }

    if (bToContinue == false)
    {
        for (int i = 0; i < this->context->outDdlGenPtr->recurseEndCpt; i++)
        {
            this->context->outDdlGenPtr->setIndent(-1);
            this->context->outDdlGenPtr->bodySqlBlock
                << this->context->outDdlGenPtr->newLine() << this->context->outDdlGenPtr->getEndIf(true) << endl;
        }
        this->context->outDdlGenPtr->recurseEndCpt = 0;
    }

    return gblRet;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::createSProcReturn()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  ORACLE - LJE - 140707
**
*************************************************************************/
RET_CODE DdlGenFromFile::createSProcReturn()
{
    RET_CODE        ret = RET_SUCCEED;

    if (this->getOutDdlObjEn() == DdlObj_TriggerBody ||
        this->getOutDdlObjEn() == DdlObj_TriggerUdFieldBody ||
        this->getOutDdlObjEn() == DdlObj_Trigger)
    {
        if (this->context->outDdlGenPtr->isReturnOnTriggerNeeded())
        {
            this->context->outDdlGenPtr->bodySqlBlock.setIndentOffsetNbr((int)this->context->outDdlGenPtr->getIndent().length() - 1);
            this->context->outDdlGenPtr->bodySqlBlock << this->printSubQuery(this->m_atReturnStream) << endl;
            this->context->outDdlGenPtr->bodySqlBlock.setIndentOffsetNbr(0);
            this->context->outDdlGenPtr->bodySqlBlock << "#RELEASE_TRIGGER" << endl;
        }
        else
        {
            return ret;
        }
    }

    if (this->varHelperPtr->getInCursorName().empty() == false)
    {
        this->context->outDdlGenPtr->bodySqlBlock << this->context->outDdlGenPtr->getCloseCursor(this->varHelperPtr->getInCursorName()) << endl;
    }

    vector<vector<string>> keywordParamList;
    this->extractKeywordParam(TAG_RETURN, 0, keywordParamList, true);

    this->context->outDdlGenPtr->bodySqlBlock
        << this->printSubQuery(this->m_atReturnStream)
        << this->context->outDdlGenPtr->getIndent() << (this->varHelperPtr->isAllParamKept() ? "return" : "continue");

    if (keywordParamList.size() > 1)
    {
        ret = RET_GEN_ERR_INVARG;
        this->printMsg(ret, "Unsupported parameter on keyword #RETURN");
    }

    if (keywordParamList.size() == 1 &&
        keywordParamList[0].size() == 1)
    {
        if (this->getOutDdlObjEn() != DdlObj_TriggerBody &&                                 /* PMSTA-28704 - LJE - 180411 */
            this->getOutDdlObjEn() != DdlObj_TriggerUdFieldBody &&
            this->getOutDdlObjEn() != DdlObj_Trigger &&                                 /* PMSTA-28704 - LJE - 180411 */
            this->getOutDdlObjEn() != DdlObj_RuntimeSql &&
            (this->context->outDdlGenPtr->returnInSProcAvailable() || this->getOutDdlObjEn() == DdlObj_Func))
        {
            this->context->outDdlGenPtr->bodySqlBlock << "(" << keywordParamList[0][0] << ")";
        }
        else if (this->ddlGenContextPtr->bCheck &&      /* PMSTA-36471 - LJE - 190705 */
                 this->bApplRaiseError == false &&
                 keywordParamList[0][0].compare("0") != 0)
        {
            this->printMsg(RET_DBA_INFO_NODATA, "Unsupported parameter (" + keywordParamList[0][0] + ") on keyword #RETURN, return value must be preceded by #APPL_RAISERROR !");
        }
    }
    else if (this->ddlGenContextPtr->bCheck &&          /* PMSTA-36471 - LJE - 190705 */
             this->bApplRaiseError &&
             this->getOutDdlObjEn() != DdlObj_TriggerBody &&
             this->getOutDdlObjEn() != DdlObj_TriggerUdFieldBody &&
             this->getOutDdlObjEn() != DdlObj_Trigger)
    {
        this->printMsg(RET_DBA_INFO_NODATA, "Unsupported parameter on keyword #RETURN, after #APPL_RAISERROR, a return value must be defined !");
    }
    else if (this->ddlGenContextPtr->getDictSprocSt().retDataType == TriggerType ||
             (this->ddlGenContextPtr->m_rdbmsEn == PostgreSQL &&
              (this->getOutDdlObjEn() == DdlObj_TriggerBody ||
               this->getOutDdlObjEn() == DdlObj_TriggerUdFieldBody ||
               this->getOutDdlObjEn() == DdlObj_Trigger)))
    {
        if (this->m_parentDdlGenPtr != nullptr)
        {
            auto ddlGenTriggerPtr = dynamic_cast<DdlGenTrigger*>(this->m_parentDdlGenPtr);

            if (ddlGenTriggerPtr->getCurrTriggerPos() == TriggerPos_After ||
                ddlGenTriggerPtr->getCurrTriggerPos() == TriggerPos_Before)
            {
                this->context->outDdlGenPtr->bodySqlBlock << " NULL";
            }
            else if (ddlGenTriggerPtr->getCurrDmlEvent() == DmlEvent_Delete)
            {
                this->context->outDdlGenPtr->bodySqlBlock << " OLD";
            }
            else
            {
                this->context->outDdlGenPtr->bodySqlBlock << " NEW";
            }
        }
    }

    this->context->outDdlGenPtr->bodySqlBlock << this->context->outDdlGenPtr->getCmdEndOfCmd() << endl;

    return ret;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::createSProcBeginTran()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-18593 - LJE - 141219
**
*************************************************************************/
RET_CODE DdlGenFromFile::createSProcBeginTran()
{
    RET_CODE        ret = RET_SUCCEED;

    if (this->context->outDdlGenPtr->beginTranInSProcAvailable())
    {
        vector<string> tokens;
        this->tokenize(tokens);

        this->context->outDdlGenPtr->bodySqlBlock << this->context->outDdlGenPtr->newLine() << "begin tran";
        if (tokens.size() > 1)
        {
            this->context->outDdlGenPtr->bodySqlBlock << " " << tokens.at(1);
        }

        this->context->outDdlGenPtr->bodySqlBlock << this->context->outDdlGenPtr->endOfCmd();
    }
    else
    {
        this->context->outDdlGenPtr->bodySqlBlock << DdlGenDbi::getCmdNoOp(this);
    }

    this->bAutoCommit = false;
    return ret;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::createSProcCommit()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-18593 - LJE - 141219
**
*************************************************************************/
RET_CODE DdlGenFromFile::createSProcCommit()
{
    RET_CODE        ret = RET_SUCCEED;

    if (this->context->outDdlGenPtr->beginTranInSProcAvailable())
    {
        this->context->outDdlGenPtr->bodySqlBlock << this->context->outDdlGenPtr->newLine() << "commit";

        vector<string> tokens;
        this->tokenize(tokens);

        if (tokens.size() > 1)
        {
            this->context->outDdlGenPtr->bodySqlBlock << " tran " << tokens.at(1);
        }

        this->context->outDdlGenPtr->bodySqlBlock << this->context->outDdlGenPtr->endOfCmd();
    }
    /* PMSTA-45273 - LJE - 210607 */
    else if (this->ddlGenContextPtr->bAutonomousTransaction == true &&
             this->ddlGenContextPtr->m_rdbmsEn != PostgreSQL)
    {
        this->context->outDdlGenPtr->bodySqlBlock << this->context->outDdlGenPtr->newLine() << "commit" << this->context->outDdlGenPtr->endOfCmd();
    }
    else
    {
        this->context->outDdlGenPtr->bodySqlBlock << DdlGenDbi::getCmdNoOp(this);
    }

    this->bEndTransaction = true;
    return ret;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::createSProcRollback()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-18593 - LJE - 141219
**
*************************************************************************/
RET_CODE DdlGenFromFile::createSProcRollback()
{
    RET_CODE        ret = RET_SUCCEED;

    if (this->context->outDdlGenPtr->isRollbackOnTriggerAllowed() == false &&
        (this->getOutDdlObjEn() == DdlObj_TriggerBody ||
         this->getOutDdlObjEn() == DdlObj_TriggerUdFieldBody))
    {
        this->bAllowEmptyBlock = true;
        return ret;
    }

    if (this->context->outDdlGenPtr->beginTranInSProcAvailable())
    {
        this->context->outDdlGenPtr->bodySqlBlock << this->context->outDdlGenPtr->newLine() << "rollback";

        vector<string> tokens;
        this->tokenize(tokens);

        if (tokens.size() > 1)
        {
            this->context->outDdlGenPtr->bodySqlBlock << " tran " << tokens.at(1);
        }

        this->context->outDdlGenPtr->bodySqlBlock << this->context->outDdlGenPtr->endOfCmd();
    }
    else
    {
        this->context->outDdlGenPtr->bodySqlBlock << DdlGenDbi::getCmdNoOp(this);
    }

    this->bEndTransaction = true;
    return ret;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::createSProcApplRaisError()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  ORACLE - LJE - 140707
**
*************************************************************************/
RET_CODE DdlGenFromFile::createSProcApplRaisError()
{
    RET_CODE                ret = RET_SUCCEED;
    vector<string>          callParam;
    vector<vector<string>>  keywordParamList;
    string                  funcName = "appl_raiserror";
    DictSprocClass         *dictSprocStp = nullptr;

    this->extractKeywordParam(TAG_APPL_RAISERROR, 0, keywordParamList, false);

    this->context->bUpdateIndent = false;
    for (vector<vector<string>>::iterator paramIt = keywordParamList.begin(); paramIt != keywordParamList.end(); ++paramIt)
    {
        if (paramIt->size() > 0 && paramIt->at(0).empty() == false)
        {
            string paramStr;
            for (vector<string>::iterator it = paramIt->begin(); it != paramIt->end(); ++it)
            {
                if (it != paramIt->begin())
                {
                    paramStr += " ";
                }
                paramStr += *it;
            }

            if (callParam.size() > 0 &&
                paramStr[0] != '\'' &&
                paramStr.find('@') == string::npos &&
                paramStr.find("NEW.") == string::npos &&
                paramStr.find("OLD.") == string::npos &&
                paramStr.find(this->context->outDdlGenPtr->getVarPrefix()) != 0 &&
                paramStr.find(this->context->outDdlGenPtr->getParamPrefix()) != 0)
            {
                callParam.push_back("'" + paramStr + "'");
            }
            else
            {
                callParam.push_back(paramStr);
            }
        }
    }

    if (this->context->outDdlGenPtr->isOptionalParamAllowed() == false)
    {
        bool            bKnownSproc = false;
        if (this->getOutDdlObjEn() == DdlObj_SProc ||
            this->getOutDdlObjEn() == DdlObj_SubDdlObj ||
            this->getOutDdlObjEn() == DdlObj_TriggerBody)
        {
            bKnownSproc = this->ddlGenContextPtr->getStoredProcInfo(funcName, dictSprocStp);
        }

        if (bKnownSproc)
        {
            size_t paramPos = 0;
            size_t paramStart = callParam.size();
            for (auto it = dictSprocStp->m_paramProcAttribVector.begin(); it != dictSprocStp->m_paramProcAttribVector.end(); ++it, ++paramPos)
            {
                if (paramPos >= paramStart)
                {
                    callParam.push_back(it->defaultValueC);
                }
            }
        }
        else
        {
            for (size_t i = 15 - keywordParamList.size(); i > 0; i--)
            {
                callParam.push_back("null");
            }
        }
    }

    this->context->bUpdateIndent = true;

    string databaseName;
    if (strcasecmp(this->ddlGenContextPtr->getMainDbName().c_str(), this->ddlGenContextPtr->getDdlDestDbName().c_str()) != 0)
    {
        databaseName = this->ddlGenContextPtr->getMainDbName();
    }

    this->context->outDdlGenPtr->bodySqlBlock
        << this->context->outDdlGenPtr->newLine()
        << this->context->outDdlGenPtr->getCmdExecSProc(databaseName, funcName, callParam, dictSprocStp)
        << endl;

    this->bApplRaiseError = true;

    return ret;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::createSProcPrint()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  ORACLE - LJE - 140707
**
*************************************************************************/
RET_CODE DdlGenFromFile::createSProcPrint()
{
    RET_CODE               ret = RET_SUCCEED;
    vector<vector<string>> keywordParamList;
    vector<string>         printParamList;

    this->extractKeywordParam(TAG_PRINT, 0, keywordParamList, false);

    for (vector<vector<string>>::iterator it = keywordParamList.begin(); it != keywordParamList.end(); it++)
    {
        for (vector<string>::iterator paramIt = it->begin(); paramIt != it->end(); ++paramIt)
        {
            printParamList.push_back(*paramIt);
        }
    }

    this->context->outDdlGenPtr->bodySqlBlock
        << this->context->outDdlGenPtr->newLine()
        << this->context->outDdlGenPtr->getCmdPrintMsg(printParamList)
        << endl;

    return ret;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::createSProcCallReturnStatus()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  ORACLE - LJE - 140707
**
*************************************************************************/
RET_CODE DdlGenFromFile::createSProcCallReturnStatus()
{
    RET_CODE        ret = RET_SUCCEED;
    vector<string>  tokens;

    this->context->currLineStrLTrim.replace(0, strlen(TAG_CALL_RETURN_STATUS) + 2, "");

    this->tokenize(tokens);

    if (tokens.size() > 0)
    {
        this->context->bUpdateIndent = false;

        auto it = tokens.begin();

        stringstream execCmdStream;

        execCmdStream
            << this->context->outDdlGenPtr->getIndent() << "#EXEC "
            << this->context->outDdlGenPtr->getReturnStatusName(false) << " = " << *it;

        bool bFirst = true;
        for (++it; it != tokens.end(); ++it)
        {
            if (bFirst == false)
            {
                execCmdStream << ",";
            }
            execCmdStream << " " << *it;
        }

        this->context->outDdlGenPtr->bodySqlBlock
            << this->buildScript(execCmdStream.str())
            << endl
            << this->context->outDdlGenPtr->getReturnStatusOnError()
            << endl;

        this->context->bUpdateIndent = true;
    }
    else
    {
        this->context->outDdlGenPtr->bodySqlBlock
            << this->context->outDdlGenPtr->getReturnReturnStatus();
    }
    return ret;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::createSProcIdentityIncrement()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-18593 - LJE - 150630
**
*************************************************************************/
RET_CODE DdlGenFromFile::createSProcIdentityIncrement()
{
    RET_CODE        ret = RET_SUCCEED;
    vector<string>  tokens;

    this->context->currLineStrLTrim.replace(0, strlen(TAG_IDENTITY_INCREMENT) + 2, "");

    this->tokenize(tokens);

    if (tokens.size() > 1)
    {
        DICT_ENTITY_STP locDictEntityStp = DBA_GetEntityBySqlName(tokens[0]);

        if (locDictEntityStp == NULL)
        {
            ret = RET_GEN_ERR_INVARG;
            this->printMsg(ret, "Unknown entity " + tokens[0] + " on the keyword #" TAG_IDENTITY_INCREMENT);
        }
        else if (locDictEntityStp->pkRuleEn == PkRule_ExternalPk && locDictEntityStp->pkEntityStp != NULL)
        {
            locDictEntityStp = locDictEntityStp->pkEntityStp;
        }

        if (tokens.at(1)[0] != '@')
        {
            ret = RET_GEN_ERR_INVARG;
            this->printMsg(ret, "The second parameter of the keyword #" TAG_IDENTITY_INCREMENT " must be a variable");
        }

        DdlGenVar *idIncVar = this->varHelperPtr->getVariable(tokens.at(1));

        if (ret == RET_SUCCEED && idIncVar != nullptr)
        {
            this->context->outDdlGenPtr->bodySqlBlock
                << this->context->outDdlGenPtr->getCmdIdentityIncrement(idIncVar, locDictEntityStp->databaseName, this->context->outDdlGenPtr->getEntitySqlName(locDictEntityStp)) << endl;
        }
    }
    else
    {
        ret = RET_GEN_ERR_INVARG;
        this->printMsg(ret, "Syntax error on keyword #" TAG_IDENTITY_INCREMENT);
    }
    return ret;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::createSProcDlmCheck()
**
**  Description :  Generate query to check dlm_e if it is active on the entity
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-24026 - DDV - 161114
**
*************************************************************************/
RET_CODE DdlGenFromFile::createSProcDlmCheck(DdlGen* ddlGenPtr)
{
    RET_CODE           ret = RET_SUCCEED;
    vector<string>     tokens;
    std::string        aliasString;
    std::string        tagStr;
    std::string        paramAlias;
    std::string        paramEntity;
    const std::string  ignoreChars = " \t\n";
    DICT_ENTITY_STP    locDictEntityStp = NULL;
    bool               bDefaultEntity = true;
    int                bracketNbr = 0;
    string::size_type  pos;

    if (this->isTag(TAG_MAIN_DLM_CHECK))
        tagStr = TAG_MAIN_DLM_CHECK;
    else if (this->isTag(TAG_ADD_DLM_CHECK))
        tagStr = TAG_ADD_DLM_CHECK;

    bracketNbr = this->tokenize(tokens, ",", false, 0, true);

    if (bracketNbr > 0)
    {
        ret = RET_GEN_ERR_INVARG;
        this->printMsg(ret, "Syntax error on keyword #" + tagStr + "(closing bracket is missing)");
    }

    if (tokens.size() > 2)
    {
        ret = RET_GEN_ERR_INVARG;
        this->printMsg(ret, "Syntax error on keyword #" + tagStr + "(too many arguments)");
    }

    if (ret == RET_SUCCEED && tokens.size() >= 1)
    {
        if (tokens[0].size() > 0)
        {
            for (pos = 0; pos < tokens[0].size(); pos++)
            {
                if (ignoreChars.find(tokens[0][pos]) == string::npos)
                    paramAlias += tokens[0][pos];
            }
        }

        if (tokens.size() >= 2 && tokens.at(1).size() > 0)
        {
            for (pos = 0; pos < tokens.at(1).size(); pos++)
            {
                if (ignoreChars.find(tokens.at(1)[pos]) == string::npos)
                    paramEntity += tokens.at(1)[pos];
            }
        }

        if (paramAlias.size() > 0)
        {
            if (ddlGenPtr->getAlias().compare(paramAlias + ".") != 0)
            {
                bDefaultEntity = false;

                size_t joinPos;
                for (joinPos = 0; joinPos < ddlGenPtr->addedJoinTab.size(); joinPos++)
                {
                    const DdlGenJoin &el = ddlGenPtr->addedJoinTab.at(joinPos);
                    if (paramAlias.compare(ddlGenPtr->getJoinAlias(el, true)) == 0)
                    {
                        aliasString = paramAlias;
                        locDictEntityStp = el.joinDictEntityStp;
                        break;
                    }
                }
            }
        }
        else
        {
            if (tokens.size() > 1)
            {
                ret = RET_GEN_ERR_INVARG;
                this->printMsg(ret, "Syntax error on keyword #" + tagStr + "(first argument is missing)");
            }
        }
    }

    if (ret == RET_SUCCEED)
    {
        if (bDefaultEntity == true)
        {
            aliasString = ddlGenPtr->getAlias();
            aliasString.resize(aliasString.size() - 1);
            if (ddlGenPtr->realDictEntityStp != NULL)
                locDictEntityStp = ddlGenPtr->realDictEntityStp;
            else
                locDictEntityStp = ddlGenPtr->getDictEntityStp();
        }

        if (aliasString.empty() == false && locDictEntityStp)
        {
            if (paramEntity.empty() == false && paramEntity.compare(this->context->outDdlGenPtr->getEntitySqlName(locDictEntityStp)) != 0)
            {
                ret = RET_GEN_ERR_INVARG;
                this->printMsg(ret, "Syntax error on keyword #" + tagStr + " (entity mismatch)");
            }
            else
            {
                if (this->getOutDdlObjEn() == DdlObj_SProc)
                {
                    if (tagStr.compare(TAG_MAIN_DLM_CHECK) == 0)
                        this->ddlGenContextPtr->bMainDLMMax = true;
                    else
                        this->ddlGenContextPtr->bAddDLMMax = true;
                }

                this->context->currLineStrLTrim = "#" + tagStr + "(" + aliasString + "," + this->context->outDdlGenPtr->getEntitySqlName(locDictEntityStp) + ")";
            }
        }
        else
        {
            ret = RET_GEN_ERR_INVARG;
            this->printMsg(ret, "Syntax error on keyword #" + tagStr);
        }
    }
    else
    {
        ret = RET_GEN_ERR_INVARG;
        this->printMsg(ret, "Syntax error on keyword #" + tagStr);
    }

    return ret;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::createSProcReserveIdentity()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-18593 - LJE - 150630
**
*************************************************************************/
RET_CODE DdlGenFromFile::createSProcReserveIdentity()
{
    RET_CODE        ret = RET_SUCCEED;
    vector<string>  tokens;

    this->context->currLineStrLTrim.replace(0, strlen(TAG_RESERVE_IDENTITY) + 2, "");

    this->tokenize(tokens);

    if (tokens.size() > 2)
    {
        DICT_ENTITY_STP locDictEntityStp = DBA_GetEntityBySqlName(tokens[0]);

        if (locDictEntityStp == NULL)
        {
            ret = RET_GEN_ERR_INVARG;
            this->printMsg(ret, "Unknown entity " + tokens[0] + " on the keyword #" TAG_RESERVE_IDENTITY);
        }
        else if (locDictEntityStp->pkRuleEn == PkRule_ExternalPk && locDictEntityStp->pkEntityStp != NULL)
        {
            locDictEntityStp = locDictEntityStp->pkEntityStp;
        }
        else if (this->ddlGenContextPtr->m_rdbmsEn == MSSql)
        {
            /* PMSTA-55474 vpr 20240719 */
            ret = RET_GEN_ERR_INVARG;
            this->printMsg(ret, "In MSSQL PK Rule should be enabled for the entity " + tokens[0] + " to use the keyword #" TAG_RESERVE_IDENTITY " By adding entry in md/opt/9999_enable_reserve_identity.imp file");
        }

        if (tokens.at(1)[0] != '@')
        {
            ret = RET_GEN_ERR_INVARG;
            this->printMsg(ret, "The second parameter of the keyword #" TAG_RESERVE_IDENTITY " must be a variable");
        }

        DdlGenVar *idIncVar = this->varHelperPtr->getVariable(tokens.at(1));

        if (ret == RET_SUCCEED)
        {
            this->ddlGenContextPtr->bForceTableName = true;
            this->context->outDdlGenPtr->bodySqlBlock
                << this->context->outDdlGenPtr->getCmdReserveIdentity(idIncVar, locDictEntityStp, this->context->outDdlGenPtr->getEntitySqlName(locDictEntityStp), tokens.at(2), this) << endl;
            this->ddlGenContextPtr->bForceTableName = false;

            this->ddlGenContextPtr->m_dependsAccessSet.insert(DdlGenDependKey(locDictEntityStp->entDictId, 
                                                                              locDictEntityStp->mdSqlName, 
                                                                              DictDependsAccessEn::Insert,
                                                                              DynType_Null)); /* PMSTA-29956 - LJE - 180125 */
        }
    }
    else
    {
        ret = RET_GEN_ERR_INVARG;
        this->printMsg(ret, "Syntax error on keyword #" TAG_RESERVE_IDENTITY);
    }
    return ret;
}

/************************************************************************
**
**  Function    :   init()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
**  Creation  	:   PMSTA-11505 - LJE - 110311
**
*************************************************************************/
void DdlGenFromFile::init(OBJECT_ENUM      locObjectEn)
{
    this->setObjectEn(locObjectEn);
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::posTag()
**
**  Description :  Check if the tag in parameter is the current one
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-11505 - LJE - 110404
**
*************************************************************************/
string::size_type DdlGenFromFile::posTag(const string& lineStr, const char *tagName)
{
    string::size_type pos = lineStr.find(tagName);

    if (pos == string::npos ||
        pos == 0)
    {
        return string::npos;
    }
    
    if (lineStr[pos - 1] != '#')
    {
        while (pos != string::npos && lineStr[pos - 1] != '#')
        {
            size_t nextPos = lineStr.find(tagName, ++pos);

            if (nextPos == string::npos)
            {
                return string::npos;
            }
            pos = nextPos;
        }
    }


    string currTag = lineStr.substr(pos);
    string::size_type endPos = currTag.find_first_of(DDLGEN_NO_ALPHA);
    string::size_type tagLen = strlen(tagName);

    if (endPos == tagLen ||
        (endPos == string::npos && currTag.size() == tagLen))
        return pos - 1;

    return string::npos;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::isTag()
**
**  Description :  Check if the tag in parameter is the current one
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-11505 - LJE - 110404
**
*************************************************************************/
bool DdlGenFromFile::isTag(const char *tagName, bool bUpdCurTag, bool bCheckTag)
{
    bool bCheck;
    string::size_type pos = this->posTag(this->context->currLineStrLTrim, tagName);

    bCheck = pos == 0;
    if (bCheck && bUpdCurTag)
    {
        this->context->currTag = tagName;
    }

    if (bCheck && bCheckTag)
    {
        if (strcmp(tagName, TAG_WHERE) == 0 ||
            strcmp(tagName, TAG_ORDER) == 0 ||
            strcmp(tagName, TAG_HAVING) == 0 ||
            strcmp(tagName, TAG_GROUP) == 0)
        {
            string            whereAddStr;
            if (this->context->currLineStrLTrim.length() > strlen(TAG_WHERE) + 2)
            {
                whereAddStr = this->context->currLineStrLTrim.substr(strlen(TAG_WHERE) + 2);
                whereAddStr.erase(std::remove(whereAddStr.begin(), whereAddStr.end(), ' '), whereAddStr.end());
                whereAddStr.erase(std::remove(whereAddStr.begin(), whereAddStr.end(), '\t'), whereAddStr.end());
            }
            if (whereAddStr.empty() == false)
            {
                this->lastErrRetCode = RET_GEN_ERR_INVARG;
                this->printMsg(this->lastErrRetCode, "No parameter is allowed, in the same line, after the tag #" + string(tagName) + "!");
            }
        }
    }

    return bCheck;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::isNewBlockTag()
**
**  Description :  Check if the current tag is the begin of a new block
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  ORACLE - LJE - 141016
**
*************************************************************************/
bool DdlGenFromFile::isNewBlockTag(const string &endBlock)
{
    vector<string>   tokens;
    if (endBlock.compare(TAG_END) == 0 &&
        (this->isTag(TAG_SELECT) || this->isTag(TAG_SELECT_DISTINCT) || this->isTag(TAG_UPDATE) || this->isTag(TAG_DELETE)))
    {
        this->tokenize(tokens);
        if (tokens[tokens.size() - 1] != TAG_END)
        {
            return true;
        }
    }
    else if (endBlock.compare(TAG_END_CURSOR) == 0 &&
             this->isTag(TAG_SELECT_CURSOR))
    {
        return true;
    }

    return false;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::manageNestedTag()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  ORACLE - LJE - 141016
**
*************************************************************************/
bool DdlGenFromFile::manageNestedTag(stringstream  & outStream, const string& endBlock, const string& parIndentStr)
{
    bool bNestedBlk = false;

    if (this->isNewBlockTag(endBlock))
    {
        DdlGenFromFileContext *savedContext = this->context;
        MemoryPool mp;
        DdlGenFromFileContext* localContext(new DdlGenFromFileContext());
        mp.ownerObject(localContext);

        localContext->parentContextPtr = this->context;

        localContext->blockLineBeginNb = this->context->blockLineBeginNb;
        localContext->lineNb = this->context->lineNb;
        localContext->bInitCurrLineIt = false;
        localContext->parentTagNat = this->context->currTagNat;

        this->context->bUpdateIndent = false;
        do
        {
            if (endBlock.compare(TAG_END) == 0 &&
                /* PMSTA-26252 - LJE - 170227 */
                (this->isTag(TAG_IDENTITY) ||
                 this->isTag(TAG_ERROR) ||
                 this->isTag(TAG_ON_DUPLICATE_KEY) ||
                 this->isTag(TAG_UPDATE_COUNT)))
            {
                localContext->currBlockVector.push_back("#" TAG_END);

                this->context->pscStream << "#" << TAG_END << endl;
                break;
            }
            localContext->currBlockVector.push_back(this->context->currLineStr);

            this->context->pscStream << this->context->currLineStrLTrim << endl;
        } while (this->isTag(endBlock.c_str()) == false && this->getGenSqlLine());
        this->context->bUpdateIndent = true;

        localContext->blockLineBeginNb = savedContext->blockLineBeginNb + this->context->lineNb - 1;
        this->context = localContext;
        this->context->bUpdateIndent = true;
        this->context->bInitCurrLineIt = false;
        this->newOutDdlGen();
        this->context->parentPreIndent = parIndentStr;

        if (endBlock.compare(TAG_END_CURSOR))
        {
            this->context->outDdlGenPtr->bNestedRequest = true;
        }

        bool bAvoidMultiEntity = this->ddlGenContextPtr->bAvoidMultiEntity;

        if (this->context->parentTagNat != TagSql_Insert)
        {
            this->ddlGenContextPtr->bAvoidMultiEntity = true;
        }

        this->buildBlock();

        this->ddlGenContextPtr->bAvoidMultiEntity = bAvoidMultiEntity;

        if (this->context->outDdlGenPtr->lastErrRetCode != RET_SUCCEED && this->lastErrRetCode == RET_SUCCEED)
        {
            this->lastErrRetCode = this->context->outDdlGenPtr->lastErrRetCode;
        }

        if (this->lastErrRetCode == RET_SUCCEED || this->ddlGenContextPtr->ddlGenAction.m_installLevel <= 5)
        {
            outStream << this->context->outDdlGenPtr->bodySqlBlock.str();
        }

        this->deleteOutDdlGen();
        this->context = savedContext;
        bNestedBlk = true;
    }
    else if (this->context->currLineStrLTrim.find("--") == 0)
    {
        bNestedBlk = true;
    }
    else if (this->context->currLineStrLTrim.find("#") == 0)
    {
        this->replaceFunctionByFct(this->context->currLineStrLTrim, TAG_HINT, DdlGenDbi::manageHintTag);
    }
    return bNestedBlk;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::getNextTag()
**
**  Description :  Check if the next tag is correct.
**
**  Arguments   :
**
**  Return      : The next tag, empty if error
**
** Creation     :  ORACLE - LJE - 140917
**
*************************************************************************/
DdlGenTagInfo DdlGenFromFile::getNextTag(DdlGenTagInfo &tagInfo, int level)
{
    DdlGenTagInfo nextTagInfo;
    bool bTreatRecurse = false;
    int savedLineNbr = this->context->lineNb;

    tagInfo.readLinePos = tagInfo.lineNbr;

    while (nextTagInfo.name.empty() && this->readNextCurrBlock())
    {
        nextTagInfo = this->getTag();

        if (nextTagInfo.name.empty() == false)
        {
            switch (tagInfo.tagNatEn)
            {
                case TagSql_If:
                case TagSql_ElseIf:
                case TagSql_While:
                    if (nextTagInfo.name.compare(TAG_BEGIN) == 0 ||
                        nextTagInfo.name.compare(TAG_BEGIN_BLK) == 0)
                    {
                        nextTagInfo.tagNatEn = TagSql_BeginIf;
                        nextTagInfo.name = TAG_BEGIN_BLK;
                        nextTagInfo.readLinePos--;
                    }
                    else if (nextTagInfo.name.compare(TAG_THEN) == 0)
                    {
                        nextTagInfo.tagNatEn = TagSql_Then;
                        nextTagInfo.readLinePos--;
                    }
                    else
                    {
                        nextTagInfo.name.clear();
                    }
                    break;

                case TagSql_Else:
                    if (nextTagInfo.name.compare(TAG_BEGIN) == 0 ||
                        nextTagInfo.name.compare(TAG_BEGIN_BLK) == 0)
                    {
                        tagInfo = nextTagInfo;
                        tagInfo.tagNatEn = TagSql_BeginElse;
                        nextTagInfo.name.clear();
                    }
                    else
                    {
                        nextTagInfo.name.clear();
                    }
                    break;

                case TagSql_BeginIf:
                case TagSql_BeginElse:
                case TagSql_BeginBlk:
                    if (nextTagInfo.name.compare(TAG_END_BLK) != 0 &&
                        nextTagInfo.name.compare(TAG_ENDIF) != 0 &&
                        nextTagInfo.name.compare(TAG_ELSE) != 0)
                    {
                        bTreatRecurse = true;
                    }
                    break;

                case TagSql_EndBlk:
                    if (nextTagInfo.name.compare(TAG_ELSE) == 0)
                    {
                        tagInfo = nextTagInfo;
                        tagInfo.tagNatEn = TagSql_Else;
                        nextTagInfo.name.clear();
                    }
                    else if (nextTagInfo.name.compare(TAG_ELSE_IF) == 0)
                    {
                        tagInfo = nextTagInfo;
                        tagInfo.tagNatEn = TagSql_ElseIf;
                        nextTagInfo.name.clear();
                    }
                    else
                    {
                        nextTagInfo = tagInfo;
                    }
                    break;

                case TagSql_Then:
                    if (nextTagInfo.name.compare(TAG_ELSE) != 0 &&
                        nextTagInfo.name.compare(TAG_ELSE_IF) != 0 &&
                        nextTagInfo.name.compare(TAG_ENDIF) != 0)
                    {
                        bTreatRecurse = true;
                    }
                    break;

                case TagSql_ElseThen:
                    if (nextTagInfo.name.compare(TAG_ENDIF) != 0)
                    {
                        bTreatRecurse = true;
                    }
                    break;

                default:
                    nextTagInfo.name.clear();
                    break;
            }

            if (bTreatRecurse)
            {
                if (nextTagInfo.name.compare(TAG_IF) == 0 ||
                    nextTagInfo.name.compare(TAG_ELSE_IF) == 0 ||
                    nextTagInfo.name.compare(TAG_IF_EXISTS) == 0 ||
                    nextTagInfo.name.compare(TAG_IF_NOT_EXISTS) == 0 ||
                    nextTagInfo.name.compare(TAG_WHILE) == 0
                    )
                {
                    DdlGenTagInfo ifTagInfo, thenTagInfo, elseTagInfo;
                    thenTagInfo = nextTagInfo;
                    do
                    {
                        ifTagInfo = this->getNextTag(thenTagInfo, level + 1);
                        thenTagInfo = ifTagInfo;
                        thenTagInfo = this->getNextTag(thenTagInfo, level + 1);
                    } while (thenTagInfo.tagNatEn == TagSql_ElseIf ||
                             thenTagInfo.nextTagNatEn == TagSql_ElseIf);

                    if (thenTagInfo.tagNatEn == TagSql_Else ||
                        thenTagInfo.tagNatEn == TagSql_ElseThen ||
                        thenTagInfo.nextTagNatEn == TagSql_BeginElse)
                    {
                        elseTagInfo = this->getNextTag(thenTagInfo, level + 1);
                    }
                }
                nextTagInfo.name.clear();
                bTreatRecurse = false;
            }
        }
    }

    if (nextTagInfo.tagNatEn == TagSql_Else)
    {
        nextTagInfo.tagNatEn = TagSql_ElseThen;
    }
    else if (nextTagInfo.tagNatEn == TagSql_EndBlk && level >= 0)
    {
        DdlGenTagInfo afterTagInfo, beforeTagInfo = nextTagInfo;
        afterTagInfo = this->getNextTag(beforeTagInfo, -1);
        nextTagInfo.nextTagNatEn = beforeTagInfo.tagNatEn;
    }

    if (level == 0)
    {
        if (tagInfo.name.compare(TAG_THEN) == 0 ||
            tagInfo.name.compare(TAG_BEGIN) == 0 ||
            tagInfo.name.compare(TAG_ELSE) == 0 ||
            tagInfo.name.compare(TAG_BEGIN_BLK) == 0)
        {
            tagInfo.readLinePos++;
        }
        if (nextTagInfo.name.compare(TAG_ENDIF) == 0 ||
            nextTagInfo.name.compare(TAG_ELSE) == 0 ||
            nextTagInfo.name.compare(TAG_ELSE_IF) == 0 ||
            nextTagInfo.name.compare(TAG_END_BLK) == 0)

        {
            nextTagInfo.readLinePos--;
        }

        this->resetNextCurrBlock(this->context->lineNb - tagInfo.lineNbr);
    }
    else if (level < 0)
    {
        this->resetNextCurrBlock(this->context->lineNb - savedLineNbr);
    }

    return nextTagInfo;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::getTag()
**
**  Description :  Check if the tag in parameter is the current one
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-11505 - LJE - 110404
**
*************************************************************************/
DdlGenTagInfo DdlGenFromFile::getTag()
{
    DdlGenTagInfo currTagInfo;
    string tagName;

    if (this->context->currLineStrLTrim[0] != '#')
        return currTagInfo;

    string::size_type endPos = this->context->currLineStrLTrim.find_first_of(" \t(");
    tagName = this->context->currLineStrLTrim.substr(1, endPos - 1);
    currTagInfo.name = tagName;
    if (tagName.compare(TAG_IF) == 0 ||
        tagName.compare(TAG_IF_EXISTS) == 0 ||
        tagName.compare(TAG_IF_NOT_EXISTS) == 0)
    {
        currTagInfo.tagNatEn = TagSql_If;
    }
    else if (tagName.compare(TAG_ELSE) == 0)
    {
        currTagInfo.tagNatEn = TagSql_Else;
    }
    else if (tagName.compare(TAG_ELSE_IF) == 0)
    {
        currTagInfo.tagNatEn = TagSql_ElseIf;
    }
    else if (tagName.compare(TAG_BEGIN) == 0 ||
             tagName.compare(TAG_BEGIN_BLK) == 0)
    {
        currTagInfo.tagNatEn = TagSql_BeginBlk;
    }
    else if (tagName.compare(TAG_THEN) == 0)
    {
        currTagInfo.tagNatEn = TagSql_Then;
    }
    else if (tagName.compare(TAG_END) == 0 ||
             tagName.compare(TAG_END_BLK) == 0)
    {
        currTagInfo.tagNatEn = TagSql_EndBlk;
    }
    else if (tagName.compare(TAG_ENDIF) == 0)
    {
        currTagInfo.tagNatEn = TagSql_EndIf;
    }
    else if (tagName.compare(TAG_WHILE) == 0)
    {
        currTagInfo.tagNatEn = TagSql_While;
    }
    currTagInfo.nextTagNatEn = TagSql_None;

    currTagInfo.lineNbr = this->context->lineNb;
    currTagInfo.readLinePos = this->context->lineNb;

    return currTagInfo;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::contains()
**
**  Description :  Check if the tag in parameter is the current one
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-11505 - LJE - 110404
**
*************************************************************************/
bool DdlGenFromFile::contains(const string& findStr)
{
    string::size_type pos = this->context->currLineStrLTrim.find(findStr);

    if (pos == string::npos)
        return false;

    if (pos > 0 &&
        this->context->currLineStrLTrim.at(pos - 1) != ' ' &&
        this->context->currLineStrLTrim.at(pos - 1) != '\t' &&
        this->context->currLineStrLTrim.at(pos - 1) != '\n')
    {
        return false;
    }

    string currStr = this->context->currLineStrLTrim.substr(pos);
    string::size_type endPos = currStr.find_first_of(" \t\n");

    if (endPos == findStr.size() ||
        (endPos == string::npos && findStr.size() == currStr.size()))
        return true;

    return false;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::isRdbmsScript()
**
**  Description :  Check if current rdbms is in IF_RDBMS list
**                 and if isEndTag then Validates Tag Usage
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-40978 - JJN - 051020
**
*************************************************************************/
bool DdlGenFromFile::isRdbmsScript(const string &lineStr, vector<string> &allRdbmsInScope, bool isEndTag)
{
    static string rdbmsStr;
    bool isRdbmsInList = false;

    if (rdbmsStr.empty() && isEndTag == false)
    {
        rdbmsStr = upper(DdlGenDbi::getRdbmsName(this->ddlGenContextPtr->m_rdbmsEn));
    }

    if (isEndTag == false)
    {
        /* verify if rdbms is in list */

        size_t pos = lineStr.find_first_of('(');
        size_t endpos = lineStr.find_first_of(')') - 1;

        string rdbmsListStr = upper(lineStr.substr(pos + 1, endpos - pos));

        vector<string>  tokens;
        DdlGen::tokenizeStr(tokens, rdbmsListStr, " ,");

        for (size_t i = 0; i < tokens.size(); i++)
        {
            isRdbmsInList = isRdbmsInList ? true : tokens.at(i).compare(rdbmsStr) == 0;
            allRdbmsInScope.push_back(tokens.at(i));
        }
        return isRdbmsInList;
    }
    else
    {
        /* validate tag usage when isEndTag = true */

        bool incorrectSyntax = false;
        std::sort(allRdbmsInScope.begin(), allRdbmsInScope.end());
        auto it = std::adjacent_find(allRdbmsInScope.begin(), allRdbmsInScope.end());

        if (it != allRdbmsInScope.end())
        {
            /*Incorrect syntax*/
            this->printMsg(RET_GEN_ERR_INVARG, "Ambiguous usage of rdbms names in keyword #IF_RDBMS");
            incorrectSyntax = true;
        }

        if (allRdbmsInScope.size() > (static_cast<INT_T>(UnknownRdbms) - 1))
        {
            this->printMsg(RET_GEN_ERR_INVARG, "Unknown rdbms name in keyword #IF_RDBMS");
        }

        if (allRdbmsInScope.size() < (static_cast<INT_T>(UnknownRdbms) - 2))
        {
            bool bError = false;
            if (this->ddlGenEntityPtr != nullptr &&
                this->ddlGenEntityPtr->getDictEntityStp() != nullptr &&
                this->ddlGenEntityPtr->getDictEntityStp()->entNatEn == EntityNat_System)
            {
                bError = true;
            }

            this->printMsg((bError ? RET_GEN_ERR_INVARG : RET_DBA_INFO_NODATA), "Missing script for one or many databases in keyword #IF_RDBMS");
        }
        allRdbmsInScope.clear();
        return incorrectSyntax;
    }

}

/************************************************************************
**
**  Function    :  DdlGenFromFile::newOutDdlGen()
**
**  Description :  Create a new working object
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-14452 - LJE - 130115
**
*************************************************************************/
void DdlGenFromFile::newOutDdlGen()
{
    this->ddlGenContextPtr->m_bIgnoreDepends = true;
    this->deleteOutDdlGen();

    if (this->outDdlObjEn != DdlObj_SProc &&
        this->outDdlObjEn != DdlObj_Func &&
        (this->ddlObjFromFileEn == DdlObjFromFile_Custom || this->outDdlObjEn == DdlObj_None))
    {
        this->outDdlGenPtr = new DdlGen(this->getObjectEn(),
                                        this->outDdlObjEn,
                                        *this->ddlGenContextPtr,
                                        this->varHelperPtr,
                                        this->ddlGenEntityPtr,
                                        this->fileHelperPtr,
                                        TargetTable_Main);

        this->context->outDdlGenPtr = this->outDdlGenPtr;
        this->outDdlGenSprocPtr     = NULL;
        this->outDdlGenViewPtr      = NULL;
        this->outDdlGenTriggerPtr   = NULL;
    }
    else
    {
        switch (this->outDdlObjEn)
        {
            case DdlObj_View:
                this->outDdlGenViewPtr = new DdlGenView(this->getObjectEn(),
                                                        View_None,
                                                        *this->ddlGenContextPtr,
                                                        this->ddlGenEntityPtr,
                                                        this->fileHelperPtr,
                                                        TargetTable_Main);

                this->context->outDdlGenPtr = this->outDdlGenViewPtr;
                this->outDdlGenSprocPtr     = NULL;
                this->outDdlGenTriggerPtr   = NULL;
                break;

            case DdlObj_SProc:
            case DdlObj_Func:
                this->outDdlGenSprocPtr = new DdlGenSProc(this->getObjectEn(),
                                                          *this->ddlGenContextPtr,
                                                          this->varHelperPtr,
                                                          this->ddlGenEntityPtr,
                                                          this->fileHelperPtr,
                                                          TargetTable_Main);

                this->context->outDdlGenPtr = this->outDdlGenSprocPtr;
                this->outDdlGenViewPtr      = NULL;
                this->outDdlGenTriggerPtr   = NULL;
                break;

            case DdlObj_Trigger:
            case DdlObj_TriggerUdField:
                this->outDdlGenTriggerPtr = new DdlGenTrigger(this->getObjectEn(),
                                                              this->outDdlObjEn,
                                                              *this->ddlGenContextPtr,
                                                              this->varHelperPtr,
                                                              this->ddlGenEntityPtr,
                                                              this->fileHelperPtr,
                                                              this->outDdlObjEn == DdlObj_Trigger ? TargetTable_Main : TargetTable_UserDefinedFields);

                this->context->outDdlGenPtr = this->outDdlGenTriggerPtr;
                this->outDdlGenSprocPtr     = NULL;
                this->outDdlGenViewPtr      = NULL;
                break;

            case DdlObj_None:
                break;

            default:
                this->printMsg(RET_GEN_ERR_INVARG, "Unsupported DDL object: " + to_string(this->outDdlObjEn));
                /* Nothing to do */
                break;
        }
    }

    this->context->outDdlGenPtr->setDdlObjEn(this->outDdlObjEn);
    this->context->outDdlGenPtr->setDdlGenFromFileContextPtr(this->context);    /* PMSTA-37366 - LJE - 191118 */

    this->context->outDdlGenPtr->bAppendFile = this->bAppendFile;
    this->bAppendFile = true;
    this->ddlGenContextPtr->m_bIgnoreDepends = false;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::deleteOutDdlGen()
**
**  Description :  Create a new working object
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-14452 - LJE - 130115
**
*************************************************************************/
void DdlGenFromFile::deleteOutDdlGen()
{
    delete this->context->outDdlGenPtr;
    this->context->outDdlGenPtr = NULL;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::loadHintUsrFile()
**
**  Description :  Load the Hint user file if exists
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-43500 - LJE - 210316
**
*************************************************************************/
void DdlGenFromFile::loadHintUsrFile()
{
    string savedGenSqlFileStr = this->genSqlFileStr;
    this->genSqlFileStr = this->ddlGenContextPtr->getDdlGenPath() +
        "/src/" +
        this->context->outDdlGenPtr->getDictEntityStp()->mdSqlName + ".usr.hint";

    ifstream     hintUsrFile(this->genSqlFileStr.c_str(), ios_base::in);

    if (hintUsrFile.is_open() && hintUsrFile.fail() == false)
    {
        string currLineStr;
        while (getline(hintUsrFile, currLineStr))
        {
            {
                stringstream currLineStream;
                bool bInComment = false;
                do
                {
                    this->checkComments(currLineStr, bInComment, currLineStream, true);

                } while (bInComment && getline(hintUsrFile, currLineStr));

                if (currLineStr.empty() || currLineStream.str().empty())
                {
                    continue;
                }
            }

            if (currLineStr.find("#HINT_BEGIN") == 0)
            {
                stringstream currLineStream;
                bool bInComment = false;

                this->checkComments(currLineStr, bInComment, currLineStream, true);

                vector<string> tokens;
                DdlGen::tokenizeStr(tokens, currLineStream.str());

                if (tokens.size() != 3)
                {
                    this->printMsg(RET_GEN_ERR_INVARG, "The keyword #HINT_BEGIN should have 2 arguments!");
                    break;
                }

                DDL_OBJ_ENUM hintDdlObjEn = DdlGenMsg::getDdlObjEnFromStr(tokens[1]);
                string       hintSprocSqlName = tokens[2];

                if (hintDdlObjEn != DdlObj_SProc)
                {
                    this->printMsg(RET_GEN_ERR_INVARG, "Only 'proc' is currently supported by the keyword #HINT_BEGIN (" + tokens[1] + ")");
                    break;
                }

                auto &hintVector = this->m_hintInfoMap[hintSprocSqlName];
                hintVector.push_back(DdlGenHintInfo(hintDdlObjEn, hintSprocSqlName, this->genSqlFileStr));

                DdlGenHintInfo &ddlGenHintInfo = hintVector.back();

                while (getline(hintUsrFile, currLineStr) &&
                       currLineStr.find("#HINT_END") != 0)
                {
                    if (currLineStr.find("#HINT_REPLACE") == 0)
                    {
                        ddlGenHintInfo.setHintStrreamPos(DdlGenHintInfo::HintAction::Replacement);
                        continue;
                    }
                    if (currLineStr.find("#HINT_ADD") == 0)
                    {
                        tokens.clear();

                        DdlGen::tokenizeStr(tokens, currLineStr);

                        if (tokens.size() != 2)
                        {
                            this->printMsg(RET_GEN_ERR_INVARG, "The keyword #HINT_ADD should have 1 argument!");
                            break;
                        }

                        if (tokens[1] == "before")
                        {
                            ddlGenHintInfo.setHintStrreamPos(DdlGenHintInfo::HintAction::Before);
                        }
                        else if (tokens[1] == "after")
                        {
                            ddlGenHintInfo.setHintStrreamPos(DdlGenHintInfo::HintAction::After);
                        }
                        else
                        {
                            this->printMsg(RET_GEN_ERR_INVARG, "The argument of the keyword #HINT_ADD should be before or after, not : " + tokens[1]);
                        }
                        continue;
                    }
                    ddlGenHintInfo << currLineStr;
                }

                if (currLineStr.find("#HINT_END") != 0)
                {
                    this->printMsg(RET_GEN_ERR_INVARG, "Unexpected end of file!");
                }
            }
            else
            {
                this->printMsg(RET_GEN_ERR_INVARG, "Syntax error in line: " + currLineStr);
            }
        }
    }

    this->genSqlFileStr = savedGenSqlFileStr;
}


/************************************************************************
**
**  Function    :  DdlGenHintInfo::replace()
**
**  Description :  Replace user Hints
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-43500 - LJE - 210316
**
*************************************************************************/
bool DdlGenHintInfo::replace(const std::string &currLine, size_t &matchPos, size_t &startPos, std::vector<std::string> &blockVector)
{
    blockVector.push_back(currLine);

    std::stringstream currLineStream;
    DdlGenMsg::checkComments(currLine, this->m_bInComment, currLineStream, true, true);

    if (this->m_bInComment == false &&
        currLineStream.str().empty() == false)
    {
        if (this->m_searchVector[matchPos] == currLineStream.str())
        {
            if (matchPos == 0)
            {
                startPos = blockVector.size() - 1;
            }
            matchPos++;

            if (this->m_searchVector.size() == matchPos)
            {
                if (this->m_beforeVector.empty() == false)
                {
                    std::vector<std::string> tmp(blockVector.begin() + startPos, blockVector.end());
                    blockVector.erase(blockVector.begin() + startPos, blockVector.end());

                    blockVector.push_back("\t/* Begin Hint file (before): " + this->m_hintFileName + " */");
                    for (auto it = this->m_beforeVector.begin(); it != this->m_beforeVector.end(); ++it)
                    {
                        blockVector.push_back(*it);
                    }
                    blockVector.push_back("\t/* End Hint file (before): " + this->m_hintFileName + " */");

                    if (this->m_replacementVector.empty())
                    {
                        for (auto it = tmp.begin(); it != tmp.end(); ++it)
                        {
                            blockVector.push_back(*it);
                        }
                    }
                }

                if (this->m_replacementVector.empty() == false)
                {
                    if (this->m_beforeVector.empty())
                    {
                        blockVector.erase(blockVector.begin() + startPos, blockVector.end());
                    }
                    blockVector.push_back("\t/* Begin Hint file (replacement): " + this->m_hintFileName + " */");
                    for (auto it = this->m_replacementVector.begin(); it != this->m_replacementVector.end(); ++it)
                    {
                        blockVector.push_back(*it);
                    }
                    blockVector.push_back("\t/* End Hint file (replacement): " + this->m_hintFileName + " */");
                }

                if (this->m_afterVector.empty() == false)
                {
                    blockVector.push_back("\t/* Begin Hint file (after): " + this->m_hintFileName + " */");
                    for (auto it = this->m_afterVector.begin(); it != this->m_afterVector.end(); ++it)
                    {
                        blockVector.push_back(*it);
                    }
                    blockVector.push_back("\t/* End Hint file (after): " + this->m_hintFileName + " */");
                }

                matchPos = 0;

                return true;
            }
        }
        else
        {
            matchPos = 0;
        }
    }

    return false;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::replaceUsrHint()
**
**  Description :  Replace user Hints if exists
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-43500 - LJE - 210316
**
*************************************************************************/
void DdlGenFromFile::replaceUsrHint()
{
    if (this->m_hintInfoMap.empty() == false)
    {
        auto hintVector = this->m_hintInfoMap.find(this->outDdlGenSprocPtr->getDictSprocSt().sqlName);

        if (hintVector != this->m_hintInfoMap.end())
        {
            this->printMsg(RET_DBA_INFO_EXIST, "Hint modification applied");
            set<string> hintFilesSet;

            for (auto hintIt = hintVector->second.begin(); hintIt != hintVector->second.end(); ++hintIt)
            {
                std::vector<std::string>           currBlockVector;
                bool                               bFound = false;
                size_t                             matchPos = 0;
                size_t                             startPos = 0;

                if (hintFilesSet.insert(hintIt->getFileName()).second)
                {
                    this->ddlGenContextPtr->m_additionalGenInfo.push_back("Hint file               : " + hintIt->getFileName());
                }

                for (auto blkIt = this->context->currLineIt + 1; blkIt != this->context->currBlockVector.end(); ++blkIt)
                {
                    if (hintIt->replace(*blkIt, matchPos, startPos, currBlockVector))
                    {
                        bFound = true;
                    }
                }

                if (bFound)
                {
                    this->context->currBlockVector.erase(this->context->currLineIt + 1, this->context->currBlockVector.end());

                    for (auto it = currBlockVector.begin(); it != currBlockVector.end(); ++it)
                    {
                        this->context->currBlockVector.push_back(*it);
                    }
                }
                else
                {
                    stringstream msg;

                    msg
                        << "Hint modification failed, unable to find the following pattern:" << endl
                        << hintIt->getSearchPattern();

                    MSG_SendMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, msg.str().c_str());
                    this->printMsg(RET_GEN_ERR_INVARG, "Hint modification failed, please see log file");
                }
            }
        }
    }
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::build()
**
**  Description :  Load file for generate SQL stored procs.
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-11505 - LJE - 110404
**
*************************************************************************/
RET_CODE DdlGenFromFile::build()
{
    RET_CODE               ret = RET_SUCCEED, gblRet = RET_SUCCEED;
    string                 path = this->ddlGenContextPtr->getDdlGenPath();
    bool                   bSameLine = false, bFirstComment = true;
    bool                   bOnEachDataBase = false;

    this->context->lineNb = 0;
    this->readLineNb = 0;
    this->bInManualTrg = false;
    this->setInBlock(false);

    this->ddlGenContextPtr->getDictSprocSt().reset();
    this->ddlGenContextPtr->getDictSprocSt().setObjectEn(this->getObjectEn());
    this->ddlGenContextPtr->resetContext(string());
    this->ddlGenContextPtr->msgFileName.clear();
    this->varHelperPtr->cleanAllVar();

    this->newOutDdlGen();

    this->outDdlObjEn = DdlObj_None;
    this->context->currTagNat = TagSql_None;

    vector<string> fileOptTypes;

    if (this->ddlGenContextPtr->bBuildDbi)
    {
        fileOptTypes.push_back(".dbi");
    }
    else
    {
        fileOptTypes.push_back("");
        fileOptTypes.push_back(".usr");
    }

    for (auto fileOptTypeIt = fileOptTypes.begin(); fileOptTypeIt != fileOptTypes.end(); ++fileOptTypeIt)
    {
        this->genSqlFileStr = path + "/src/";
        this->genSqlFileStr.append(this->context->outDdlGenPtr->getDictEntityStp()->mdSqlName);
        this->genSqlFileStr.append(*fileOptTypeIt);
        this->genSqlFileStr.append(this->fileExtStr);

        this->genSqlFile = new ifstream(this->genSqlFileStr.c_str(), ios_base::in);

        if (this->genSqlFile->is_open() == false || this->genSqlFile->fail() == true)
        {
            if (fileOptTypeIt->empty() == true)
            {
                switch (this->ddlObjFromFileEn)
                {
                    case DdlObjFromFile_SProc:
                        this->allStdProcToDo = true;
                        break;

                    case DdlObjFromFile_View:
                    case DdlObjFromFile_Trigger:
                        break;
                }
            }
            delete (this->genSqlFile);
            continue;
        }

        std::vector<string> rdbmsTagVector;
        this->loadHintUsrFile();    /* PMSTA-43500 - LJE - 210316 */
        this->ddlGenContextPtr->m_genFileName = this->genSqlFileStr;

        while (bSameLine || this->getGenSqlLine(true))
        {
            bSameLine = false;

            if (this->context->currLineStrLTrim.size() == 0 ||
                this->context->currLineStrLTrim.find("--") == 0)
            {
                this->context->currBlockVector.push_back(this->context->currLineStr);
                continue;
            }

            if (this->context->currLineStrLTrim.find("/*") == 0)
            {
                string::size_type pos = string::npos, endCommentPos;
                do
                {
                    if ((endCommentPos = this->context->currLineStrLTrim.find("*/")) != string::npos)
                    {
                        break;
                    }

                    if (bFirstComment == false)
                    {
                        this->context->currBlockVector.push_back(this->context->currLineStr);
                    }
                } while (this->getGenSqlLine(true));

                if (endCommentPos != string::npos &&
                    (pos = this->context->currLineStrLTrim.find_first_not_of(" \t", endCommentPos + 2)) == string::npos)
                {
                    if (bFirstComment == false)
                    {
                        this->context->currBlockVector.push_back(this->context->currLineStr);
                    }
                    bFirstComment = false;
                    continue;
                }
                bFirstComment = false;

                this->context->currBlockVector.push_back(this->context->currLineStrLTrim.substr(0, pos));
                this->context->currLineStrLTrim = this->context->currLineStrLTrim.substr(pos);
                this->context->currLineStr = this->context->currLineStrLTrim;

                bSameLine = true;
                continue;
            }
            else if (this->context->currLineStrLTrim[0] == '#')
            {
                const char* keywordInTab[] = { TAG_IF_SYBASE , TAG_IF_ORACLE , TAG_IF_NUODB, TAG_IF_MSSQL, TAG_IF_POSTGRESQL, nullptr };
                const char* keywordOutTab[] = { TAG_END_IF_SYBASE , TAG_END_IF_ORACLE , TAG_END_IF_NUODB, TAG_END_IF_MSSQL, TAG_END_IF_POSTGRESQL, nullptr };
                DBA_RDBMS_ENUM rdbmsTab[] = { Sybase, Oracle, Nuodb, MSSql, PostgreSQL, UnknownRdbms };

                if (this->outDdlObjEn == DdlObj_None)
                {
                    bool bContinue = false;
                    bool includeRdbmsScript = true;

                    /* PMSTA-40978 - JJN - 111020 */
                    if (this->isTag(TAG_IF_RDBMS))
                    {
                        includeRdbmsScript = isRdbmsScript(this->context->currLineStrLTrim, rdbmsTagVector);

                        if (includeRdbmsScript == false)
                        {
                            while (this->getGenSqlLine(true))
                            {
                                if (this->context->currLineStrLTrim[0] == '#')
                                {
                                    if (this->isTag(TAG_IF_RDBMS))
                                    {
                                        bSameLine = true;
                                        bContinue = true;
                                        break;
                                    }
                                    else if (this->isTag(TAG_END_IF_RDBMS))
                                    {
                                        if (isRdbmsScript(this->context->currLineStrLTrim, rdbmsTagVector, true))
                                        {
                                            ret = RET_GEN_ERR_INVARG;
                                        }
                                        bContinue = true;
                                        break;
                                    }
                                }
                            }
                        }
                        else
                        {
                            bContinue = true;
                        }
                    }
                    else if (this->isTag(TAG_END_IF_RDBMS))
                    {
                        if (isRdbmsScript(this->context->currLineStrLTrim, rdbmsTagVector, true))
                        {
                            ret = RET_GEN_ERR_INVARG;
                        }
                        bContinue = true;
                    }

                    if (!bContinue)
                    {
                        for (int i = 0; keywordInTab[i] != nullptr; i++)
                        {
                            if (this->isTag(keywordInTab[i]) && this->ddlGenContextPtr->m_rdbmsEn != rdbmsTab[i])
                            {
                                while (this->getGenSqlLine(true))
                                {
                                    if (this->context->currLineStrLTrim[0] == '#' && this->isTag(keywordOutTab[i]))
                                    {
                                        break;
                                    }
                                }
                            }

                            if (this->isTag(keywordInTab[i]) || this->isTag(keywordOutTab[i]))
                            {
                                bContinue = true;
                                break;
                            }
                        }
                    }

                    if (bContinue)
                    {
                        continue;
                    }
                }
                /* PMSTA-26108 - LJE - 170816 */
                if (this->isTag(TAG_IF_MULTI_ENTITY))
                {
                    if (this->ddlGenContextPtr->getMultiEntityLevel() != MultiEntityLevel_Active)
                    {
                        while (this->getGenSqlLine(true))
                        {
                            if (this->context->currLineStrLTrim[0] == '#' && this->isTag(TAG_END_IF_MULTI_ENTITY))
                            {
                                break;
                            }
                        }
                    }
                    continue;
                }
                if (this->isTag(TAG_END_IF_MULTI_ENTITY))
                {
                    continue;
                }

                if (this->isTag(TAG_EXCLUDE_BEGIN))
                {
                    while (this->getGenSqlLine(true))
                    {
                        if (this->isTag(TAG_EXCLUDE_END))
                        {
                            break;
                        }
                    }
                    continue;
                }

                if (this->isTag(TAG_NOT_BOOTSTRAP_BEGIN))
                {
                    if (this->ddlGenContextPtr->ddlGenAction.m_installLevel == 99 ||
                        this->ddlGenContextPtr->bGenFromDbi == true)
                    {
                        while (this->getGenSqlLine(true))
                        {
                            if (this->isTag(TAG_NOT_BOOTSTRAP_END))
                            {
                                break;
                            }
                        }
                    }
                    continue;
                }

                if (this->isTag(TAG_NOT_BOOTSTRAP_END))
                {
                    continue;
                }

                if (this->isTag(TAG_NOT_INSTALL_BEGIN))
                {
                    if (this->ddlGenContextPtr->ddlGenAction.m_installLevel > 5 ||
                        this->ddlGenContextPtr->ddlGenAction.m_mainDdlObjNatEn == DbObjDdlObjNat_System ||
                        this->ddlGenContextPtr->bGenFromDbi == true)
                    {
                        while (this->getGenSqlLine(true))
                        {
                            if (this->isTag(TAG_NOT_INSTALL_END))
                            {
                                break;
                            }
                        }
                    }
                    continue;
                }

                if (this->isTag(TAG_NOT_INSTALL_END))
                {
                    continue;
                }

                if (this->isTag(TAG_INSTALL_ONLY_BEGIN))
                {
                    if (this->ddlGenContextPtr->ddlGenAction.m_installLevel <= 5 && 
                        this->ddlGenContextPtr->ddlGenAction.m_mainDdlObjNatEn != DbObjDdlObjNat_System &&
                        this->ddlGenContextPtr->bGenFromDbi == false)
                    {
                        while (this->getGenSqlLine(true))
                        {
                            if (this->isTag(TAG_INSTALL_ONLY_END))
                            {
                                break;
                            }
                        }
                    }
                    continue;
                }

                if (this->isTag(TAG_INSTALL_ONLY_END))
                {
                    continue;
                }

                if (this->isTag(TAG_RESTRICT_UPD_BEGIN))
                {
                    if (this->ddlGenContextPtr->ddlGenAction.m_installLevel > 5 ||
                        this->ddlGenContextPtr->ddlGenAction.m_bRestrictUpdate == false ||
                        this->ddlGenContextPtr->bGenFromDbi == true)
                    {
                        while (this->getGenSqlLine(true))
                        {
                            if (this->isTag(TAG_RESTRICT_UPD_END))
                            {
                                break;
                            }
                        }
                    }
                    continue;
                }

                if (this->isTag(TAG_RESTRICT_UPD_END))
                {
                    continue;
                }

                if (this->context->currTagNat == TagSql_None)
                {
                    /* PMSTA-13109 - LJE - 111201 - Apply SQL between proc creation i.e. temp tables */
                    this->buildBlock();

                    this->ddlGenContextPtr->setDdlDestDbName("", this->context->outDdlGenPtr);

                    this->varHelperPtr->rowCount.clear();
                }

                this->context->blockLineBeginNb = this->readLineNb - 1;
                if (this->isTag(TAG_SPROC_BEGIN, true))
                {
                    this->context->currTagNat = TagSql_SProcBegin;
                    this->outDdlObjEn = DdlObj_SProc;
                    this->newOutDdlGen();
                }
                else if (this->isTag(TAG_SPROC_STD_BEGIN, true))
                {
                    this->context->currTagNat = TagSql_SProcStdBegin;
                    this->outDdlObjEn = DdlObj_SProc;
                    this->newOutDdlGen();
                }
                else if (this->isTag(TAG_FUNC_BEGIN, true))
                {
                    this->context->currTagNat = TagSql_FuncBegin;
                    this->outDdlObjEn = DdlObj_Func;
                    this->newOutDdlGen();
                }
                else if (this->isTag(TAG_VIEW_BEGIN, true))
                {
                    this->context->currTagNat = TagSql_ViewBegin;
                    this->outDdlObjEn = DdlObj_View;
                    this->newOutDdlGen();
                }
                else if (this->isTag(TAG_TRIGGER_BEGIN, true))
                {
                    this->context->currTagNat = TagSql_TriggerBegin;
                    this->outDdlObjEn = DdlObj_Trigger;
                    if (this->outDdlGenTriggerPtr == nullptr)
                    {
                        this->newOutDdlGen();
                    }
                }
                else if (this->isTag(TAG_EXEC_BEGIN, true))
                {
                    this->context->currTagNat = TagSql_ExecBegin;
                    this->outDdlObjEn = DdlObj_None;
                    this->newOutDdlGen();
                }
                else if (this->isTag(TAG_SHORT_SQLNAME, true))
                {
                    this->printMsg(RET_GEN_ERR_INVARG, "The keyword #" TAG_SHORT_SQLNAME " is no more supported!");
                    continue;
                }
                else if (this->isTag(TAG_SPROC_ALL_STD, true))
                {
                    this->allStdProcToDo = true;
                    continue;
                }
                else if (this->isTag(TAG_SPROC_STD, true))
                {
                    this->context->currTagNat = TagSql_StdProc;
                    this->outDdlObjEn = DdlObj_SProc;
                }
                /* PMSTA-26108 - LJE - 171101 */
                else if (this->isTag(TAG_EXTERNAL_ENTITY, true))
                {
                    if ((ret = this->createSprocExternalEntity()) != RET_SUCCEED)
                    {
                        gblRet = ret;
                    }
                    continue;
                }
                else if (this->isTag(TAG_SPROC_END, true))
                {
                    if (this->context->currTagNat != TagSql_SProcBegin &&
                        this->context->currTagNat != TagSql_SProcStdBegin)
                    {
                        ret = RET_GEN_ERR_INVARG;
                        this->printMsg(ret, "Unexpected keyword #" TAG_SPROC_END " !");
                    }
                    else
                    {
                        this->context->currTagNat = TagSql_SProcEnd;
                    }
                }
                else if (this->isTag(TAG_FUNC_END, true))
                {
                    if (this->context->currTagNat != TagSql_FuncBegin)
                    {
                        ret = RET_GEN_ERR_INVARG;
                        this->printMsg(ret, "Unexpected keyword #" TAG_FUNC_END " !");
                    }
                    else
                    {
                        this->context->currTagNat = TagSql_FuncEnd;
                    }
                }
                else if (this->isTag(TAG_EXEC_END, true))
                {
                    if (this->context->currTagNat != TagSql_ExecBegin)
                    {
                        ret = RET_GEN_ERR_INVARG;
                        this->printMsg(ret, "Unexpected keyword #" TAG_EXEC_END " !");
                    }
                    else
                    {
                        this->context->currTagNat = TagSql_ExecEnd;
                    }
                }
                else if (this->isTag(TAG_VIEW_END, true))
                {
                    if (this->context->currTagNat != TagSql_ViewBegin)
                    {
                        ret = RET_GEN_ERR_INVARG;
                        this->printMsg(ret, "Unexpected keyword #" TAG_VIEW_END " !");
                    }
                    else
                    {
                        this->context->currTagNat = TagSql_ViewEnd;
                    }
                }
                else if (this->isTag(TAG_TRIGGER_END, true))
                {
                    if (this->context->currTagNat != TagSql_TriggerBegin)
                    {
                        ret = RET_GEN_ERR_INVARG;
                        this->printMsg(ret, "Unexpected keyword #" TAG_TRIGGER_END " !");
                    }
                    else
                    {
                        this->context->currTagNat = TagSql_TriggerEnd;
                    }
                }
                else if (this->isTag(TAG_ON_EACH_DATABASE, true))
                {
                    /* PMSTA-45027 - LJE - 210527 */
                    if (this->ddlGenContextPtr->bGenFromDbi == false && 
                        this->ddlGenContextPtr->ddlGenAction.m_installLevel < 99)
                    {
                        bOnEachDataBase = true;
                    }
                    continue;
                }
            }

            this->context->currBlockVector.push_back(this->context->currLineStr);

            /* PMSTA-29748 - LJE - 180125 */
            if (this->context->currTagNat == TagSql_StdProc &&
                DdlGen::find_word(this->context->currLineStr, "END") == string::npos)
            {
                while (DdlGen::find_word(this->context->currLineStrLTrim, "#SPROC_END") == string::npos)
                {
                    if (this->getGenSqlLine(true) == false)
                    {
                        break;
                    }

                    if (this->context->currLineStrLTrim.find("#SPROC_") == 0 &&
                        DdlGen::find_word(this->context->currLineStrLTrim, "#SPROC_END") == string::npos)
                    {
                        ret = RET_GEN_ERR_INVARG;
                        this->printMsg(ret, "Unexpected Line :" + this->context->currLineStrLTrim);
                    }

                    this->context->currBlockVector.push_back(this->context->currLineStr);
                }
            }

            if (this->context->currTagNat == TagSql_SProcEnd ||
                this->context->currTagNat == TagSql_FuncEnd ||
                this->context->currTagNat == TagSql_ExecEnd ||
                this->context->currTagNat == TagSql_ViewEnd ||
                this->context->currTagNat == TagSql_StdProc)
            {
                /* PMSTA-37366 - LJE - 200305 - To process only function */
                if ((this->ddlGenContextPtr->ddlGenAction.m_bSystemFuncOnly == false || this->context->currTagNat == TagSql_FuncEnd) &&
                    (this->ddlGenContextPtr->ddlGenAction.m_bSystemFuncOnly == true || this->context->currTagNat != TagSql_FuncEnd || this->getDictEntityStp()->bIsInitEntity == false))
                {
                    this->ddlGenContextPtr->resetContext(string());
                    this->ddlGenContextPtr->getDictSprocSt().reset();

                    this->context->m_elseResultsSetPos = 0;
                    this->context->m_position          = DdlGenFromFileContext::Position::None;
                    this->context->parentTagNat        = TagSql_Body;
                    this->context->m_ifResultsSetVector.clear();

                    this->ddlGenContextPtr->getDictSprocSt().setObjectEn(this->getObjectEn());
                    this->m_atReturnStream.clear();
                    this->m_atReturnStream.str(string());

                    if (bOnEachDataBase)
                    {
                        auto &allDbSet = this->ddlGenContextPtr->getAllDbSet();

                        vector<string> bodyVec = this->context->currBlockVector;

                        for (auto it = allDbSet.begin(); it != allDbSet.end(); ++it)
                        {
                            this->ddlGenContextPtr->setDefDdlDestDbName(*it);
                            ret = this->buildBlock();
                            this->context->currBlockVector = bodyVec;
                        }
                        this->context->currBlockVector.clear();
                    }
                    else
                    {
                        ret = this->buildBlock();
                    }

                    this->outDdlObjEn = DdlObj_None;
                    this->context->currTagNat = TagSql_None;

                    this->ddlGenContextPtr->setDefDdlDestDbName();
                    this->newOutDdlGen();

                    if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                    {
                        gblRet = ret;
                    }
                }
                else
                {
                    this->context->currBlockVector.clear();
                }

                bOnEachDataBase = false;
            }
            else if (this->context->currTagNat == TagSql_TriggerEnd)
            {
                this->manageFromFileTriggers();
                this->context->currTagNat = TagSql_None;
            }
        }

        this->genSqlFile->close();
        delete (this->genSqlFile);
    }

    /* PMSTA-37366 - LJE - 200305 - To process only function */
    if (this->ddlGenContextPtr->ddlGenAction.m_bSystemFuncOnly == false)
    {
        if (this->ddlObjFromFileEn == DdlObjFromFile_Trigger)
        {
            ret = this->createStandardTriggers();
        }
        else
        {
            this->ddlGenContextPtr->resetContext(string());
            this->buildBlock();
            this->deleteOutDdlGen();

            switch (this->ddlObjFromFileEn)
            {
                case DdlObjFromFile_View:
                case DdlObjFromFile_SystemView:
                case DdlObjFromFile_UtilsView:
                    this->outDdlObjEn = DdlObj_View;

                    ret = this->createStandardView();
                    break;

                case DdlObjFromFile_SProc:
                    this->outDdlObjEn = DdlObj_SProc;
                    this->context->currTagNat = TagSql_StdProc;

                    ret = this->createAllStdSProc();
                    break;
            }
        }
    }

    if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
    {
        gblRet = ret;
    }

    if (this->ddlGenContextPtr->ddlGenAction.m_installLevel > 6 && this->ddlGenContextPtr->ddlGenAction.m_installLevel < 10)
    {
        gblRet = RET_SUCCEED;
        this->lastErrRetCode = RET_SUCCEED;

        if (this->context->outDdlGenPtr != NULL)
        {
            this->context->outDdlGenPtr->lastErrRetCode = RET_SUCCEED;
        }
    }
    this->ddlGenContextPtr->msgFileName.clear(); /* PMSTA-43500 - LJE - 210318 */

    return(gblRet);
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::setTriggerInfo()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-21197 - LJE - 160413
**
*************************************************************************/
void DdlGenFromFile::setTriggerInfo(TRIGGER_POS_ENUM paramTrgPosEn, DML_EVENT_ENUM paramDmlEventEn, const std::string &atReturnStr)
{
    this->trgPosEn = paramTrgPosEn;
    this->dmlEventEn = paramDmlEventEn;
    this->m_atReturnStream << atReturnStr;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::clearTriggerInfo()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-21197 - LJE - 160413
**
*************************************************************************/
void DdlGenFromFile::clearTriggerInfo()
{
    this->setTriggerInfo(TriggerPos_None, DmlEvent_None, string());
    this->m_atReturnStream.clear();
    this->m_atReturnStream.str(std::string());
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::buildScript()
**
**  Description :  Build a SQL part from an external source code
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-18593 - LJE - 141215
**
*************************************************************************/
string DdlGenFromFile::buildScript(const string &scriptStr, DDL_OBJ_ENUM paramOutDdlObjEn, int level)
{
    string       lineStr, newBlockStr;
    stringstream finSrvCallStream, scriptStream;

    DdlGenFromFileContext *savedContext          = this->context;
    DDL_OBJ_FROM_FILE_ENUM savedDdlObjFromFileEn = this->ddlObjFromFileEn;
    DDL_OBJ_ENUM           savedOutDdlObjEn      = this->outDdlObjEn;
    DDL_OBJ_ENUM           savedDdlObjEn         = this->getDdlObjEn();
    DDL_OBJ_ENUM           savedCtxDdlObjEn      = this->ddlGenContextPtr->getDdlObjEn();
    bool                   bShadowManagement     = ((paramOutDdlObjEn == DdlObj_SProc) || (this->ddlGenContextPtr->getDdlGenMode() == DdlGenMode_Shadow));

    /* PMSTA-26250 - LJE - 170331 */
    if (level == -1)
    {
        bShadowManagement = false;
        level = 0;
    }
    else if (this->parentScriptTagNat != TagSql_Body)
    {
        bShadowManagement = false;
    }

    this->bInManualTrg = false;
    this->lastErrRetCode = RET_SUCCEED;
    this->m_bNewLine = false;

    if (level == 0)
    {
        this->context = new DdlGenFromFileContext(*this->context);

        if (paramOutDdlObjEn == DdlObj_Sql || paramOutDdlObjEn == DdlObj_RuntimeSql)
        {
            if (SYS_IsDdlGenMode() == FALSE && 
                this->optimLevel == 0 &&
                this->ddlGenContextPtr->ddlGenAction.m_fromImport == false &&
                this->ddlGenContextPtr->ddlGenAction.m_installLevel < 6 &&
                (SYS_IsSqlMode() == FALSE || EV_DictInitFlg == FALSE || DBA_IsDboUser(SYS_GetThreadUser()) == FALSE))
            {
                this->ddlGenContextPtr->ddlBuildModeEn = DdlBuildMode_ViewOnly;
            }
            else
            {
                this->ddlGenContextPtr->ddlBuildModeEn = DdlBuildMode_Standard;
            }

            if (this->bKeepData == false)
            {
                this->varHelperPtr->cleanAllVar();
            }

            this->ddlGenContextPtr->getDictSprocSt().m_dictSprocReturnsVector.clear();
            this->setInBlock(false);
        }

        if (paramOutDdlObjEn != DdlObj_SubDdlObj &&
            paramOutDdlObjEn != DdlObj_Sql &&
            paramOutDdlObjEn != DdlObj_SubSql &&
            paramOutDdlObjEn != DdlObj_SubQuery &&      /* PMSTA-45413 - LJE - 220120 */
            paramOutDdlObjEn != DdlObj_RuntimeSql)
        {
            this->ddlGenContextPtr->setDdlDestDbName(this->ddlGenContextPtr->getDefDdlDestDbName(), this->context->outDdlGenPtr);
        }
    }
    else
    {
        bShadowManagement = false;
    }

    if (this->getDdlObjEn() == DdlObj_None)
    {
        this->setDdlObjEn(paramOutDdlObjEn);
    }

    if (this->ddlGenContextPtr->getDdlObjEn() == DdlObj_None)
    {
        this->ddlGenContextPtr->setDdlObjEn(paramOutDdlObjEn);
    }

    this->ddlObjFromFileEn      = DdlObjFromFile_Custom;
    this->outDdlObjEn           = paramOutDdlObjEn;
    this->context->parentTagNat = TagSql_Custom;

    this->newOutDdlGen();

    if (savedContext->outDdlGenPtr != nullptr)
    {
        this->context->outDdlGenPtr->setPreIndent(savedContext->outDdlGenPtr->getPreIndent());
        this->context->outDdlGenPtr->setIndent(savedContext->outDdlGenPtr->getIndentNbr());
    }

    if (bShadowManagement)
    {
        this->context->currBlockVector.push_back("\t-- DDL Generator mode: " + this->ddlGenContextPtr->getDdlGenModeStr());
    }

    /* PMSTA-28916 - LJE - 171219 */
    if (this->m_parentDdlGenPtr != nullptr)
    {
        string currScriptStr(scriptStr);

        this->replaceTag(currScriptStr, TAG_CURR_DML_ALIAS, this->m_parentDdlGenPtr->getAlias(true));
        this->replaceTag(currScriptStr, TAG_CURR_DML_FROM, this->m_parentDdlGenPtr->pscFromStr.empty() ? "#FROM" : this->m_parentDdlGenPtr->pscFromStr);
        this->replaceTag(currScriptStr, TAG_CURR_DML_WHERE, this->m_parentDdlGenPtr->pscWhereStr.empty() ? "#WHERE" : this->m_parentDdlGenPtr->pscWhereStr);
        this->replaceTag(currScriptStr, TAG_CURR_DML_BODY, this->m_parentDdlGenPtr->bodySqlBlock.str());

        scriptStream << currScriptStr;
    }
    else
    {
        scriptStream << scriptStr;
    }

    int tagNbr = 0;
    if (this->m_ddlObjEn == DdlObj_Sql)
    {
        this->context->m_singleCmd = true;
    }
    else
    {
        tagNbr = 99;
    }

    while (getline(scriptStream, lineStr))
    {
        if (tagNbr < 2)
        {
            auto firstCharPos = DdlGen::find_first_not_of(lineStr, " \t");
            if (firstCharPos != string::npos && lineStr[firstCharPos] == '#')
            {
                tagNbr++;
            }
        }
        
        this->context->currBlockVector.push_back(lineStr);
    }

    if (tagNbr > 1)
    {
        this->context->m_singleCmd = false;
    }

    if (this->context->currBlockVector.empty() == false)
    {
        if (RET_GET_LEVEL(this->buildBlock()) != RET_LEV_ERROR &&
            RET_GET_LEVEL(this->context->outDdlGenPtr->lastErrRetCode) != RET_LEV_ERROR &&
            RET_GET_LEVEL(this->lastErrRetCode) != RET_LEV_ERROR)
        {
            if (DdlGen::find_first_not_of(this->context->outDdlGenPtr->bodySqlBlock.str(), " \t\n") == string::npos &&
                this->ddlGenContextPtr->m_createTmpTableStream.str().empty())
            {
                this->context->outDdlGenPtr->bodySqlBlock.clear();
            }
            else if ((paramOutDdlObjEn == DdlObj_Sql || 
                      paramOutDdlObjEn == DdlObj_RuntimeSql) && 
                     level == 0 &&
                     this->context->m_bForceSingleCmd == false)
            {
                this->context->outDdlGenPtr->printDeclareVariables(this->context->outDdlGenPtr->bodySqlBlock);
                this->varHelperPtr->printVarList(*this->context->outDdlGenPtr, this->context->outDdlGenPtr->bodySqlBlock.declareStream(), this->context->outDdlGenPtr->bodySqlBlock.initStream(), false);

                this->context->outDdlGenPtr->bodySqlBlock.initStream() << this->ddlGenContextPtr->m_createTmpTableStream.str();
                this->ddlGenContextPtr->m_createTmpTableStream.clear();
                this->ddlGenContextPtr->m_createTmpTableStream.str(string());

                if (this->context->outDdlGenPtr->bodySqlBlock.declareStream().str().empty() == false ||
                    this->context->outDdlGenPtr->bodySqlBlock.initStream().str().empty() == false)
                {
                    this->setInBlock(true);
                }

                if (this->isInBlock())
                {
                    this->context->outDdlGenPtr->finishSqlBlock(this->context->outDdlGenPtr->bodySqlBlock, this->ddlGenContextPtr->m_rdbmsEn, this->getDdlObjEn());
                }
            }

            newBlockStr = this->context->outDdlGenPtr->bodySqlBlock.str();
        }
    }

    if (level == 0 && this->context->outDdlGenPtr != nullptr)
    {
        this->finSrvCallSqlBlock.clear();
        this->finSrvCallSqlBlock << this->context->outDdlGenPtr->finSrvCallSqlBlock.str();
    }

    if ((this->ddlGenContextPtr->ddlGenAction.m_installLevel == 0 ||
        (paramOutDdlObjEn != DdlObj_Sql && paramOutDdlObjEn != DdlObj_RuntimeSql)) &&
        DdlGen::find_first_of(newBlockStr, "#") != string::npos &&
        newBlockStr.compare(scriptStream.str()) != 0)
    {
        newBlockStr = this->buildScript(newBlockStr, this->outDdlObjEn, level + 1);
    }

    if (level == 0)
    {
        this->context->outDdlGenPtr->treateAllVariable(newBlockStr, (this->outDdlObjEn != DdlObj_SubQuery));

        if (this->outDdlObjEn != DdlObj_RuntimeSql)
        {
            this->manageTempTable(newBlockStr, false);
        }

        if (bShadowManagement == true && this->ddlGenContextPtr->getDdlGenMode() == DdlGenMode_Standard && this->ddlGenContextPtr->bDisableChangeSet == false)
        {
            for (auto it = this->ddlGenContextPtr->m_dependsEntityMap.begin(); it != this->ddlGenContextPtr->m_dependsEntityMap.end(); it++)
            {
                if (it->second->changeSetAuthEn == FeatureAuth_Enable)
                {
                    this->ddlGenContextPtr->setDdlGenMode(DdlGenMode_Shadow);
                    this->ddlGenContextPtr->getDictSprocSt().m_dictSprocReturnsVector.clear();
                    this->context->m_elseResultsSetPos = 0;
                    this->context->m_ifResultsSetVector.clear();
                    string shadowBlkStr = this->buildScript(scriptStr, paramOutDdlObjEn);
                    this->ddlGenContextPtr->setDdlGenMode(DdlGenMode_Standard);

                    if (shadowBlkStr.empty() == false)
                    {
                        newBlockStr = "\n" + this->context->outDdlGenPtr->newLine() + "-- Change Set management\n"
                            + this->context->outDdlGenPtr->getCmdIfThenElse(this->context->outDdlGenPtr->getChangeSetId(false) + " is null", newBlockStr, shadowBlkStr)
                            + "\n" + this->context->outDdlGenPtr->newLine() + "-- End Change Set management\n";
                    }
                    break;
                }
            }
        }

        delete this->context->outDdlGenPtr;
        delete this->context;

        this->context = savedContext;
        this->ddlObjFromFileEn = savedDdlObjFromFileEn;
        this->outDdlObjEn = savedOutDdlObjEn;
        this->setDdlObjEn(savedDdlObjEn);
        this->ddlGenContextPtr->setDdlObjEn(savedCtxDdlObjEn);

        switch (this->outDdlObjEn)
        {
            case DdlObj_View:
                this->outDdlGenViewPtr = (DdlGenView*)this->context->outDdlGenPtr;
                this->outDdlGenSprocPtr = NULL;
                this->outDdlGenTriggerPtr = NULL;
                break;

            case DdlObj_SProc:
            case DdlObj_Func:
                this->outDdlGenSprocPtr = (DdlGenSProc*)this->context->outDdlGenPtr;
                this->outDdlGenViewPtr = NULL;
                this->outDdlGenTriggerPtr = NULL;
                break;

            case DdlObj_Trigger:
            case DdlObj_TriggerUdField:
            case DdlObj_TriggerBody:
            case DdlObj_TriggerUdFieldBody:
                this->outDdlGenTriggerPtr = (DdlGenTrigger*)this->context->outDdlGenPtr;
                this->outDdlGenSprocPtr = NULL;
                this->outDdlGenViewPtr = NULL;
                break;

            case DdlObj_None:
                break;

            default:
                /* Nothing to do */
                break;
        }
    }

    if (this->ddlGenContextPtr->ddlGenAction.m_installLevel >= 5 &&
        RET_GET_LEVEL(this->lastErrRetCode) == RET_LEV_ERROR)
    {
        this->lastErrRetCode = RET_SUCCEED;
    }

    return newBlockStr;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::buildScript()
**
**  Description :  Build a SQL part from an external source code
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-18593 - LJE - 141215
**
*************************************************************************/
void DdlGenFromFile::manageTempTable(string& scriptStr, bool bAll)
{
    string::size_type curPos, lastPos = 0;

    /* Replace the temporary table name # (no other # than table name should exist anymore) by the correct prefix according to the DB */
    while (bAll ? 
           (curPos = scriptStr.find("#", lastPos)) != string::npos :
           (curPos = DdlGen::find_first_of(scriptStr, "#", lastPos)) != string::npos)/* PMSTA-26322 - LJE - 170215 - Use DdlGen::find_first_of */
    {
        if (scriptStr.find("#NEW", curPos) != curPos &&
            scriptStr.find("#OLD", curPos) != curPos &&
            scriptStr.find("#RELEASE_TRIGGER", curPos) != curPos &&
            scriptStr.find("##", curPos) != curPos &&
            scriptStr.find_first_not_of(DDLGEN_NO_ALPHA, curPos + 1) != (curPos + 2) &&
            (curPos == lastPos || scriptStr.find_first_not_of(DDLGEN_NO_ALPHA, curPos - 1) == curPos))
        {
            auto entitSqlName = scriptStr.substr(curPos + 1, scriptStr.find_first_of(" \t()=';\n", curPos) - curPos - 1);
            auto dictEntityStp = DBA_GetEntityBySqlName(entitSqlName);
            if (dictEntityStp != nullptr)
            {
                scriptStr.replace(curPos, entitSqlName.size() + 1, this->context->outDdlGenPtr->getDdlFullName(dictEntityStp->databaseName, dictEntityStp->dbSqlName));
            }
            curPos++;
        }
        else if (scriptStr.find("##", curPos) == curPos)
        {
            while (scriptStr.at(curPos) == '#')
            {
                curPos++;
            }
        }
        lastPos = curPos + 1;
    }
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::getFinSrvCall()
**
**  Description :  Build a SQL part from an external source code
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-18593 - LJE - 151114
**
*************************************************************************/
string DdlGenFromFile::getFinSrvCall()
{
    return this->finSrvCallSqlBlock.str();
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::isInBlock()
**
**  Description :  Build a SQL part from an external source code
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-18593 - LJE - 151114
**
*************************************************************************/
bool DdlGenFromFile::isInBlock()
{
    return this->context->m_bInBlock;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::setInBlock()
**
**  Description :  Build a SQL part from an external source code
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-27457 - LJE - 170708
**
*************************************************************************/
void DdlGenFromFile::setInBlock(bool bNewInBlock)
{
    this->context->m_bInBlock = bNewInBlock;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::buildBlock()
**
**  Description :  Build a SQL part from a vector of source code
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  ORACLE - LJE - 140708
**
*************************************************************************/
RET_CODE DdlGenFromFile::buildBlock(DDL_OBJ_ENUM paramOutDdlObjEn)
{
    RET_CODE          ret = RET_SUCCEED;

    if (this->context->currBlockVector.size() == 0)
    {
        return ret;
    }

    RET_CODE          gblRet = RET_SUCCEED;
    string            savedCurrLineStr, savedCurrLineStrLTrim;
    int               noEmptyLine = 0;

    this->lastErrRetCode = RET_SUCCEED;
    this->bAllowEmptyBlock = false;
    this->bApplRaiseError = false;

    if (paramOutDdlObjEn != DdlObj_None)
    {
        this->setDdlObjEn(paramOutDdlObjEn);
        this->outDdlObjEn = paramOutDdlObjEn;

        if (this->context->outDdlGenPtr == nullptr)
        {
            this->newOutDdlGen();
        }
    }
    else
    {
        this->ddlGenContextPtr->setDdlObjEn(this->outDdlObjEn);
    }

    if (this->outDdlObjEn != DdlObj_RuntimeSql &&
        this->outDdlObjEn != DdlObj_Sql &&
        this->outDdlObjEn != DdlObj_SubSql &&
        this->outDdlObjEn != DdlObj_SubQuery)
    {
        this->setInBlock(true);
    }

    savedCurrLineStr = this->context->currLineStr;
    savedCurrLineStrLTrim = this->context->currLineStrLTrim;

    std::vector<string> rdbmsTagVector;

    auto lineStr = this->context->currBlockVector.begin();
    while (lineStr != this->context->currBlockVector.end())
    {
        if (ret != RET_SUCCEED)
        {
            gblRet = RET_DBA_INFO_EXIST;
            break;
        }

        this->context->currLineStrLTrim = (*lineStr);
        if (this->isTag(TAG_SPROC_BEGIN, true))
        {
            vector<string> tokens;
            this->tokenize(tokens);

            if (tokens.size() > 1)
            {
                this->setMsgSqlName(tokens[1]);

                if (this->context->outDdlGenPtr != nullptr)
                {
                    this->context->outDdlGenPtr->setMsgSqlName(tokens[1]);
                }
            }
        }

        size_t pos = lineStr->find_first_not_of(" \t");

        if (pos != string::npos && lineStr->at(pos) == '#')
        {
            size_t endPos = lineStr->find_first_of(" \t(", pos);
            if (endPos != string::npos)
            {
                endPos -= pos + 1;
            }
            string tagStr = lineStr->substr(pos + 1, endPos);

            if (tagStr.compare(TAG_IF_SYBASE) == 0 ||
                tagStr.compare(TAG_IF_ORACLE) == 0 ||
                tagStr.compare(TAG_IF_NUODB) == 0 ||
                tagStr.compare(TAG_IF_MSSQL) == 0 ||
                tagStr.compare(TAG_IF_POSTGRESQL) == 0 ||
                tagStr.compare(TAG_END_IF_SYBASE) == 0 ||
                tagStr.compare(TAG_END_IF_ORACLE) == 0 ||
                tagStr.compare(TAG_END_IF_NUODB) == 0  ||
                tagStr.compare(TAG_END_IF_MSSQL) == 0  ||
                tagStr.compare(TAG_END_IF_POSTGRESQL) == 0 ||
                tagStr.compare(TAG_IF_RDBMS) == 0 ||
                tagStr.compare(TAG_END_IF_RDBMS) == 0)
            {
                bool includeRdbmsScript = true;

                if (tagStr.compare(TAG_IF_RDBMS) == 0)
                {
                    includeRdbmsScript = this->isRdbmsScript(*lineStr, rdbmsTagVector);
                }
                else if (tagStr.compare(TAG_END_IF_RDBMS) == 0)
                {
                    if (this->isRdbmsScript(*lineStr, rdbmsTagVector, true))
                    {
                        ret = RET_GEN_ERR_INVARG;
                        continue;
                    }
                }

                lineStr = this->context->currBlockVector.erase(lineStr);

                if (includeRdbmsScript == false ||
                    (this->ddlGenContextPtr->m_rdbmsEn != Oracle && tagStr.compare(TAG_IF_ORACLE) == 0) ||
                    (this->ddlGenContextPtr->m_rdbmsEn != Sybase && tagStr.compare(TAG_IF_SYBASE) == 0) ||
                    (this->ddlGenContextPtr->m_rdbmsEn != Nuodb && tagStr.compare(TAG_IF_NUODB) == 0) ||
                    (this->ddlGenContextPtr->m_rdbmsEn != MSSql && tagStr.compare(TAG_IF_MSSQL) == 0) ||
                    (this->ddlGenContextPtr->m_rdbmsEn != PostgreSQL && tagStr.compare(TAG_IF_POSTGRESQL) == 0))
                {
                    while (lineStr != this->context->currBlockVector.end())
                    {
                        pos = lineStr->find_first_not_of(" \t");
                        if (pos != string::npos && lineStr->at(pos) == '#')
                        {
                            endPos = lineStr->find_first_of(" \t(", pos);
                            if (endPos != string::npos)
                            {
                                endPos -= pos + 1;
                            }
                            tagStr = lineStr->substr(pos + 1, endPos);

                            if (tagStr.compare(TAG_END_IF_ORACLE) == 0 ||
                                tagStr.compare(TAG_END_IF_SYBASE) == 0 ||
                                tagStr.compare(TAG_END_IF_NUODB) == 0 ||
                                tagStr.compare(TAG_END_IF_MSSQL) == 0 ||
                                tagStr.compare(TAG_END_IF_POSTGRESQL) == 0 ||
                                tagStr.compare(TAG_END_IF_RDBMS) == 0)
                            {
                                lineStr = this->context->currBlockVector.erase(lineStr);

                                if (tagStr.compare(TAG_END_IF_RDBMS) == 0)
                                {
                                    if (this->isRdbmsScript(*lineStr, rdbmsTagVector, true))
                                    {
                                        ret = RET_GEN_ERR_INVARG;
                                        break;
                                    }
                                }
                                break;
                            }
                            else if (tagStr.compare(TAG_IF_RDBMS) == 0)
                            {
                                break;
                            }
                        }
                        lineStr = this->context->currBlockVector.erase(lineStr);
                    }
                }
                continue;
            }
        }

        ++lineStr;
    }

    this->context->lineNb = 0;
    this->context->bInitCurrLineIt = false;
    this->context->bUpdateIndent = true;

    this->context->outDdlGenPtr->m_authAlias.clear();    /* PMSTA-29879 - LJE - 180709 */

    while (this->getGenSqlLine())
    {
        if (gblRet == RET_DBA_INFO_EXIST ||
            gblRet == RET_GEN_INFO_NOACTION)
        {
            while (this->getGenSqlLine())
            {
                if (this->isTag(TAG_SPROC_END, true) ||
                    this->isTag(TAG_FUNC_END, true) ||
                    this->isTag(TAG_VIEW_END, true))
                {
                    break;
                }
            }
            break;
        }
        else if (RET_GET_LEVEL(gblRet) == RET_LEV_ERROR &&
                 this->ddlGenContextPtr->ddlGenAction.m_installLevel > 5)
        {
            break;
        }

        if (this->m_bNewLine)
        {
            this->context->outDdlGenPtr->bodySqlBlock << endl;
            this->m_bNewLine = false;
        }

        this->context->currTagNat = TagSql_Body;

        if (this->context->currLineStrLTrim.size() == 0)
        {
            if (this->ddlObjFromFileEn != DdlObjFromFile_View &&
                this->ddlObjFromFileEn != DdlObjFromFile_SystemView &&
                this->ddlObjFromFileEn != DdlObjFromFile_UtilsView)
            {
                this->context->outDdlGenPtr->bodySqlBlock << endl;
            }
            continue;
        }
        noEmptyLine++;

        if (this->context->currLineStrLTrim.find("/*") == 0)
        {
            string::size_type pos = string::npos;
            do
            {
                this->context->outDdlGenPtr->bodySqlBlock << this->context->currLineStr << endl;

                if ((pos = this->context->currLineStrLTrim.find("*/")) != string::npos)
                {
                    break;
                }
            } while (this->getGenSqlLine());

            continue;
        }

        if (this->context->currLineStrLTrim[0] == '#')
        {
            bool bSaveInBlock = this->isInBlock();
            this->setInBlock(true);

            if (this->isTag(TAG_GET, true))
            {
                this->context->currTagNat = TagSql_Custom;
                if ((ret = this->createSProcGet()) != RET_SUCCEED)
                {
                    gblRet = ret;
                    continue;
                }
            }
            else if (this->isTag(TAG_SET, true))
            {
                this->context->currTagNat = TagSql_Custom;
                ret = this->createSProcSet();

                if (RET_GET_LEVEL(ret) == RET_LEV_ERROR)
                {
                    gblRet = ret;
                    continue;
                }
            }
            else if (this->isTag(TAG_SPROC_STD, true))
            {
                this->context->currTagNat = TagSql_StdProc;

                if ((ret = this->createStdSProc()) != RET_SUCCEED)
                {
                    gblRet = ret; /* PMSTA-13109 - LJE - 111124 */
                    continue;
                }
            }
            else if (this->isTag(TAG_SPROC_BEGIN, true))
            {
                this->context->currTagNat = TagSql_SProcBegin;

                if ((ret = this->createSProcHeader()) != RET_SUCCEED)
                {
                    gblRet = ret; /* PMSTA-13109 - LJE - 111124 */
                    continue;
                }
            }
            else if (this->isTag(TAG_SPROC_STD_BEGIN, true))
            {
                this->context->currTagNat = TagSql_SProcStdBegin;

                if ((ret = this->createSProcStdHeader()) != RET_SUCCEED)
                {
                    gblRet = ret; /* PMSTA-13109 - LJE - 111124 */
                    continue;
                }
            }
            else if (this->isTag(TAG_FUNC_BEGIN, true))
            {
                this->context->currTagNat = TagSql_FuncBegin;

                if ((ret = this->createSProcHeader()) != RET_SUCCEED)
                {
                    gblRet = ret; /* PMSTA-13109 - LJE - 111124 */
                    continue;
                }
            }
            /* PMSTA-14452 - LJE - 130110 */
            else if (this->isTag(TAG_EXEC_BEGIN, true))
            {
                if (this->context->parentTagNat == TagSql_Custom)
                {
                    this->setInBlock(true);
                }
                continue;
            }
            else if (this->isTag(TAG_CREATE, true))
            {
                this->context->currTagNat = TagSql_Create;
                if ((ret = this->createSProcCreate()) != RET_SUCCEED)
                {
                    gblRet = ret;
                    continue;
                }
            }
            else if (this->isTag(TAG_VIEW_BEGIN, true))
            {
                this->context->currTagNat = TagSql_ViewBegin;
                if ((ret = this->createViewHeader()) != RET_SUCCEED)
                {
                    gblRet = ret; /* PMSTA-13109 - LJE - 111124 */
                    continue;
                }
            }
            else if (this->isTag(TAG_SELECT_LIST, true))
            {
                this->context->currTagNat = TagSql_SelectList;
                if ((ret = this->createSProcSelect()) != RET_SUCCEED)
                {
                    gblRet = ret;
                    continue;
                }
            }
            else if (this->isTag(TAG_SELECT_IN_VAR, true))
            {
                this->context->currTagNat = TagSql_SelectInVar;
                if ((ret = this->createSProcSelect()) != RET_SUCCEED)
                {
                    gblRet = ret;
                    continue;
                }
            }
            else if (this->isTag(TAG_SELECT_VAR, true))
            {
                this->context->currTagNat = TagSql_SelectVar;
                if ((ret = this->createSProcSelect()) != RET_SUCCEED)
                {
                    gblRet = ret;
                    continue;
                }
            }
            else if (this->isTag(TAG_SELECT_CALL, true))
            {
                this->context->currTagNat = TagSql_SelectCall;
                if ((ret = this->createSProcSelect()) != RET_SUCCEED)
                {
                    gblRet = ret;
                    continue;
                }
            }
            else if (this->isTag(TAG_SELECT_CHECK, true))
            {
                this->context->currTagNat = TagSql_SelectCheck;
                if ((ret = this->createSProcSelectCheck()) != RET_SUCCEED)
                {
                    gblRet = ret;
                    continue;
                }
            }
            else if (this->isTag(TAG_CALL, true))
            {
                this->context->currTagNat = TagSql_Call;
                if ((ret = this->createSProcCall()) != RET_SUCCEED)
                {
                    gblRet = ret;
                    continue;
                }
            }
            else if (this->isTag(TAG_SELECT_DISTINCT, true))
            {
                if (this->getDdlObjEn() == DdlObj_RuntimeSql)
                {
                    this->setInBlock(bSaveInBlock);
                }
                
                this->context->currTagNat = TagSql_SelectDistinct;
                if ((ret = this->createSProcSelect()) != RET_SUCCEED)
                {
                    gblRet = ret;
                    continue;
                }
            }
            else if (this->isTag(TAG_SELECT, true))
            {
                if (this->getDdlObjEn() == DdlObj_RuntimeSql)
                {
                    this->setInBlock(bSaveInBlock);
                }

                this->context->currTagNat = TagSql_Select;
                if ((ret = this->createSProcSelect()) != RET_SUCCEED)
                {
                    gblRet = ret;
                    continue;
                }
            }
            else if (this->isTag(TAG_INSERT, true))
            {
                this->context->currTagNat = TagSql_Insert;
                if ((ret = this->createSProcInsert()) != RET_SUCCEED)
                {
                    gblRet = ret;
                    continue;
                }
            }
            else if (this->isTag(TAG_UPDATE, true))
            {
                this->context->currTagNat = TagSql_Update;
                if ((ret = this->createSProcUpdate()) != RET_SUCCEED)
                {
                    gblRet = ret;
                    continue;
                }
            }
            else if (this->isTag(TAG_UPDATE_NEW, true))
            {
                this->context->currTagNat = TagSql_UpdateNew;
                if ((ret = this->createSProcUpdate()) != RET_SUCCEED)
                {
                    gblRet = ret;
                    continue;
                }
            }
            else if (this->isTag(TAG_DELETE, true))
            {
                this->context->currTagNat = TagSql_Delete;
                if ((ret = this->createSProcDelete()) != RET_SUCCEED)
                {
                    gblRet = ret;
                    continue;
                }
            }
            else if (this->isTag(TAG_TRUNCATE, true))
            {
                this->context->currTagNat = TagSql_Truncate;
                if ((ret = this->createSProcTruncate(false)) != RET_SUCCEED)
                {
                    gblRet = ret;
                    continue;
                }
            }
            /* PMSTA-29014 - LJE - 180122 */
            else if (this->isTag(TAG_FORCE_TRUNCATE, true))
            {
                this->context->currTagNat = TagSql_Truncate;
                if ((ret = this->createSProcTruncate(true)) != RET_SUCCEED)
                {
                    gblRet = ret;
                    continue;
                }
            }
            else if (this->isTag(TAG_DROP, true))
            {
                this->context->currTagNat = TagSql_Drop;
                if ((ret = this->createSProcDrop()) != RET_SUCCEED)
                {
                    gblRet = ret;
                    continue;
                }
                }
            else if (this->isTag(TAG_RENAME, true))
            {
                this->context->currTagNat = TagSql_Rename;
                if ((ret = this->createSProcRename()) != RET_SUCCEED)
                {
                    gblRet = ret;
                    continue;
                }
            }
            else if (this->isTag(TAG_NO_SECURED, true))
            {
                this->setInBlock(bSaveInBlock);

                this->context->currTagNat = TagSql_Secured;
                this->setAvoidSecurity(true);
                if (this->getDdlObjEn() != DdlObj_RuntimeSql)
                {
                    this->context->outDdlGenPtr->bodySqlBlock << this->context->outDdlGenPtr->getIndent() << "/* Disabling security */" << endl;
                }
            }
            else if (this->isTag(TAG_SECURED, true))
            {
                this->setInBlock(bSaveInBlock);

                this->context->currTagNat = TagSql_Secured;
                this->setAvoidSecurity(false);
                if (this->getDdlObjEn() != DdlObj_RuntimeSql)
                {
                    this->context->outDdlGenPtr->bodySqlBlock << this->context->outDdlGenPtr->getIndent() << "/* Enabling security */" << endl;
                }
            }
            /* PMSTA-14607 - LJE - 120713 */
            else if (this->isTag(TAG_AUTH_FLAG, true))
            {
                this->context->currTagNat = TagSql_Secured;
                this->context->outDdlGenPtr->bManageAuthFlg = true;

                vector<vector<string>> keywordParamList;
                this->extractKeywordParam(this->context->currTag, 0, keywordParamList, false);
                if (keywordParamList.size() > 0 && keywordParamList[0].empty() == false)
                {
                    this->context->outDdlGenPtr->m_authAlias = keywordParamList[0][0];
                }
                else
                {
                    this->context->outDdlGenPtr->m_authAlias.clear();
                }
            }
            else if (this->isTag(TAG_NO_AUTH_FLAG, true))
            {
                this->context->currTagNat = TagSql_Secured;
                this->context->outDdlGenPtr->bManageAuthFlg = false;
                this->context->outDdlGenPtr->m_authAlias.clear();
            }
            /* PMSTA-26250 - LJE - 170331 */
            else if (this->isTag(TAG_CODIF, true))
            {
                this->context->currTagNat = TagSql_None;
                this->ddlGenContextPtr->m_bCodif = true;
            }
            /* PMSTA-26250 - LJE - 170331 */
            else if (this->isTag(TAG_NO_CODIF, true))
            {
                this->context->currTagNat = TagSql_None;
                this->ddlGenContextPtr->m_bCodif = false;
            }
            else if (this->isTag(TAG_DATA_PROFILE, true))
            {
                this->context->currTagNat = TagSql_SetVar;
                (void)this->varHelperPtr->getNewVariable("data_profile_id", "id_t");
                this->context->outDdlGenPtr->securityLevelEn = this->context->outDdlGenPtr->getDefSecuredLevel();
            }
            else if (this->isTag(TAG_CHANGE_SET_PROMOTION, true))
            {
                this->context->currTagNat = TagSql_SetVar;
                this->context->outDdlGenPtr->printDeclareChangeSetPromotion(this->context->outDdlGenPtr->bodySqlBlock);
            }
            else if (this->isTag(TAG_CHANGE_SET, true))
            {
                this->context->currTagNat = TagSql_SetVar;
                this->context->outDdlGenPtr->printDeclareChangeSet(this->context->outDdlGenPtr->bodySqlBlock);
            }
            else if (this->isTag(TAG_VALIDATE_SHADOW, true))
            {
                this->ddlGenContextPtr->setDdlGenMode(DdlGenMode_ValidateShadow);
                continue;
            }
            else if (this->isTag(TAG_USER, true))
            {
                this->context->currTagNat = TagSql_None;
                this->context->outDdlGenPtr->printDeclareUser(this->ddlGenContextPtr->m_initSqlBlock, true);
            }
            else if (this->isTag(TAG_USE, true))
            {
                this->context->currTagNat = TagSql_None;
                this->context->currTag = TAG_USE;
                if ((ret = this->createSProcUse()) != RET_SUCCEED)
                {
                    gblRet = ret;
                }
                continue;
            }
            else if (this->isTag(TAG_NO_LANGUAGE, true))
            {
                this->context->currTagNat = TagSql_Language;
                this->context->outDdlGenPtr->translateFlg = FALSE;
            }
            else if (this->isTag(TAG_LANGUAGE, true))
            {
                this->context->currTagNat = TagSql_Language;
                if (this->ddlGenContextPtr->bLanguage == false)
                {
                    this->ddlGenContextPtr->bLanguage = true;
                    this->context->outDdlGenPtr->printDeclareLanguage(this->context->outDdlGenPtr->bodySqlBlock);
                }
                this->context->outDdlGenPtr->translateFlg = TRUE;
            }
            else if (this->isTag(TAG_SELECT_CURSOR, true) || this->isTag(TAG_SELECT_DISTINCT_CURSOR, true))
            {
                /* PMSTA-nuodb - LJE - 190809 */
                if (this->context->outDdlGenPtr->isUseForSelectInsteadOfCursor())
                {
                    this->context->currTagNat = TagSql_ForSelect;
                    if ((ret = this->createSProcForSelect()) != RET_SUCCEED)
                    {
                        gblRet = ret;
                        continue;
                    }
                }
                else
                {
                    this->context->currTagNat = TagSql_Cursor;
                    if ((ret = this->createSProcCursor()) != RET_SUCCEED)
                    {
                        gblRet = ret;
                        continue;
                    }
                }
            }
            else if (this->isTag(TAG_DECLARE, true))
            {
                this->context->currTagNat = TagSql_SetVar;
                if ((ret = this->createSProcDeclare()) != RET_SUCCEED)
                {
                    gblRet = ret;
                    continue;
                }
            }
            else if (this->isTag(TAG_ASSIGN, true))
            {
                this->context->currTagNat = TagSql_SetVar;
                if ((ret = this->createSProcAssign()) != RET_SUCCEED)
                {
                    gblRet = ret;
                    continue;
                }
            }
            else if (this->isTag(TAG_ASSIGN_SELECT, true))
            {
                this->context->currTagNat = TagSql_Select;
                if ((ret = this->createSProcAssignSelect()) != RET_SUCCEED)
                {
                    gblRet = ret;
                    continue;
                }
            }
            else if (this->isTag(TAG_EXEC, true))
            {
                this->context->currTagNat = TagSql_Exec;

                if ((ret = this->createSProcExec()) != RET_SUCCEED)
                {
                    gblRet = ret;
                    continue;
                }
            }
            else if (this->isTag(TAG_EXEC_SQL, true))
            {
                this->context->currTagNat = TagSql_None;
                if ((ret = this->createSProcExecSql()) != RET_SUCCEED)
                {
                    gblRet = ret;
                    continue;
                }
            }
            else if (this->isTag(TAG_IF_EXISTS, true))
            {
                this->context->currTagNat = TagSql_IfExists;
                if ((ret = this->createSProcIfExists()) != RET_SUCCEED)
                {
                    gblRet = ret;
                    continue;
                }
            }
            else if (this->isTag(TAG_IF_NOT_EXISTS, true))
            {
                this->context->currTagNat = TagSql_IfExists;
                if ((ret = this->createSProcIfExists()) != RET_SUCCEED)
                {
                    gblRet = ret;
                    continue;
                }
            }
            else if (this->isTag(TAG_IF, true))
            {
                this->context->currTagNat = TagSql_If;
                if ((ret = this->createSProcIf()) != RET_SUCCEED)
                {
                    gblRet = ret;
                    continue;
                }
                this->context->outDdlGenPtr->bodySqlBlock << endl;
            }
            else if (this->isTag(TAG_ELSE_IF, true))
            {
                this->context->currTagNat = TagSql_If;
                if ((ret = this->createSProcIf()) != RET_SUCCEED)
                {
                    gblRet = ret;
                    continue;
                }
            }
            else if (this->isTag(TAG_WHILE, true))
            {
                this->context->currTagNat = TagSql_While;
                if ((ret = this->createSProcWhile()) != RET_SUCCEED)
                {
                    gblRet = ret;
                    continue;
                }
                this->context->outDdlGenPtr->bodySqlBlock << endl;
            }
            else if (this->isTag(TAG_SET_ROWCOUNT, true))
            {
                this->context->currTagNat = TagSql_SetRowcount;
                if ((ret = this->createSProcSetRowcount()) != RET_SUCCEED)
                {
                    gblRet = ret;
                    continue;
                }
                this->context->outDdlGenPtr->bodySqlBlock << endl;
            }
            else if (this->isTag(TAG_SET_DATEFIRST))
            {
                this->context->currTagNat = TagSql_None;
                if ((ret = this->createSProcSetDatefirst()) != RET_SUCCEED)
                {
                    gblRet = ret;
                    continue;
                }
                this->context->outDdlGenPtr->bodySqlBlock << endl;
            }
            else if (this->isTag(TAG_SET_FORCEPLAN, true))
            {
                this->context->currTagNat = TagSql_SetForcePlan;
                if ((ret = this->createSProcSetForcePlan()) != RET_SUCCEED)
                {
                    gblRet = ret;
                    continue;
                }
                this->context->outDdlGenPtr->bodySqlBlock << endl;
            }
            else if (this->isTag(TAG_CHECK, true))
            {
                this->context->currTagNat = TagSql_Check;
                if ((ret = this->createSProcCheck()) != RET_SUCCEED)
                {
                    gblRet = ret;
                    continue;
                }
                this->context->outDdlGenPtr->bodySqlBlock << endl;
            }
            else if (this->isTag(TAG_BEGIN_TRAN, true))
            {
                this->context->currTagNat = TagSql_BeginTran;
                if ((ret = this->createSProcBeginTran()) != RET_SUCCEED)
                {
                    gblRet = ret;
                    continue;
                }
                this->context->outDdlGenPtr->bodySqlBlock << endl;
            }
            else if (this->isTag(TAG_COMMIT, true) || this->isTag(TAG_COMMIT_TRAN, true))
            {
                this->context->currTagNat = TagSql_Commit;
                if ((ret = this->createSProcCommit()) != RET_SUCCEED)
                {
                    gblRet = ret;
                    continue;
                }
                this->context->outDdlGenPtr->bodySqlBlock << endl;
            }
            else if (this->isTag(TAG_ROLLBACK, true) || this->isTag(TAG_ROLLBACK_TRAN, true))
            {
                this->context->currTagNat = TagSql_Rollback;
                this->context->currTag = TAG_ROLLBACK;
                if ((ret = this->createSProcRollback()) != RET_SUCCEED)
                {
                    gblRet = ret;
                    continue;
                }
                this->context->outDdlGenPtr->bodySqlBlock << endl;
            }
            else if (this->isTag(TAG_RETURN, true))
            {
                this->context->currTagNat = TagSql_None;
                if ((ret = this->createSProcReturn()) != RET_SUCCEED)
                {
                    gblRet = ret;
                    continue;
                }
            }
            else if (this->isTag(TAG_APPL_RAISERROR, true))
            {
                this->context->currTagNat = TagSql_Print;
                if ((ret = this->createSProcApplRaisError()) != RET_SUCCEED)
                {
                    gblRet = ret;
                    continue;
                }
            }
            else if (this->isTag(TAG_PRINT, true))
            {
                this->context->currTagNat = TagSql_Print;
                if ((ret = this->createSProcPrint()) != RET_SUCCEED)
                {
                    gblRet = ret;
                    continue;
                }
            }
            else if (this->isTag(TAG_CALL_RETURN_STATUS, true))
            {
                this->context->currTagNat = TagSql_None;
                if ((ret = this->createSProcCallReturnStatus()) != RET_SUCCEED)
                {
                    gblRet = ret;
                    continue;
                }
            }
            else if (this->isTag(TAG_GET_UPDATE_COUNT, true))
            {
                this->context->currTagNat = TagSql_GetUpdateCount;
                if ((ret = this->createSProcGetUpdateCount()) != RET_SUCCEED)
                {
                    gblRet = ret;
                    continue;
                }
                this->context->outDdlGenPtr->bodySqlBlock << endl;
            }
            else if (this->isTag(TAG_RESERVE_IDENTITY, true))
            {
                this->context->currTagNat = TagSql_None;
                if ((ret = this->createSProcReserveIdentity()) != RET_SUCCEED)
                {
                    gblRet = ret;
                    continue;
                }
            }
            else if (this->isTag(TAG_IDENTITY_INCREMENT, true))
            {
                this->context->currTagNat = TagSql_None;
                if ((ret = this->createSProcIdentityIncrement()) != RET_SUCCEED)
                {
                    gblRet = ret;
                    continue;
                }
            }
            else if (this->isTag(TAG_TRIGGER_BEGIN, true))
            {
                this->bInManualTrg = true;
                continue;
            }
            else if (this->isTag(TAG_TRIGGER_END, true))
            {
                this->bInManualTrg = false;
                continue;
            }
            else if (this->isTag(TAG_GEN_LOOP_BEGIN, true))
            {
                this->context->currTagNat = TagSql_None;
                if ((ret = this->createSProcGenLoop()) != RET_SUCCEED)
                {
                    gblRet = ret;
                    continue;
                }
            }
            else if (this->isTag(TAG_GEN_IF_BEGIN, true))
            {
                this->context->currTagNat = TagSql_GenIf;
                if ((ret = this->createSProcGenIf()) != RET_SUCCEED)
                {
                    gblRet = ret;
                    continue;
                }
            }
            else if (this->isTag(TAG_GEN_IF_END, true))
            {
                continue;
            }
            else if (this->isTag(TAG_NO_MULTI_ENTITY, true))
            {
                this->setInBlock(bSaveInBlock);

                this->context->currTagNat = TagSql_None;
                this->ddlGenContextPtr->bAvoidMultiEntity = true;
                this->ddlGenContextPtr->bForceConnEntity = false;
                if (this->getDdlObjEn() != DdlObj_RuntimeSql)
                {
                    this->context->outDdlGenPtr->bodySqlBlock << this->context->outDdlGenPtr->getIndent() << "/* Disabling multi-entity management */" << endl;
                }
            }
            /* PMSTA-29980 - LJE - 180209 */
            else if (this->isTag(TAG_FORCE_CONN_ENTITY, true))
            {
                this->context->currTagNat = TagSql_None;
                this->ddlGenContextPtr->bForceConnEntity = true;
                this->context->outDdlGenPtr->bodySqlBlock << this->context->outDdlGenPtr->getIndent() << "/* Force connected entity */" << endl;
            }
            else if (this->isTag(TAG_MULTI_ENTITY, true))
            {
                this->context->currTagNat = TagSql_None;
                this->ddlGenContextPtr->bAvoidMultiEntity = false;
                this->ddlGenContextPtr->bForceConnEntity = false;
                if (this->getDdlObjEn() != DdlObj_RuntimeSql)
                {
                    this->context->outDdlGenPtr->bodySqlBlock << this->context->outDdlGenPtr->getIndent() << "/* Enabling multi-entity management */" << endl;
                }
            }
            else if (this->isTag(TAG_DISABLE_CHANGE_SET))
            {
                this->setInBlock(bSaveInBlock);

                this->ddlGenContextPtr->bDisableChangeSet = true;
                this->context->outDdlGenPtr->bodySqlBlock << this->context->outDdlGenPtr->getIndent() << "/* Disable change set */" << endl;
                continue;
            }
            else if (this->isTag(TAG_FORCE_NEW_RESULTSET, true))
            {
                this->context->currTagNat = TagSql_None;
                this->ddlGenContextPtr->bForceNewReturnsDef = true;
                this->context->outDdlGenPtr->bodySqlBlock << this->context->outDdlGenPtr->getIndent() << "/* Force new result-set */" << endl;
                continue;
            }
            else if (this->isTag(TAG_DISABLE_ALL_TRIGGERS, true))
            {
                vector<string>  tokens;
                this->tokenize(tokens);
                this->context->currTagNat = TagSql_None;

                if (this->outDdlObjEn == DdlObj_Sql &&
                    this->context->outDdlGenPtr != nullptr &&
                    tokens.size() > 1)
                {
                    this->context->outDdlGenPtr->disableAllTriggers(tokens.at(1));
                }
                else
                {
                    this->printMsg(ret, "Syntax error on keyword #" + this->context->currTag + "( must be the only command)");
                }
                continue;
            }
            else if (this->isTag(TAG_ENABLE_ALL_TRIGGERS, true))
            {
                vector<string>  tokens;
                this->tokenize(tokens);
                this->context->currTagNat = TagSql_None;

                if (this->outDdlObjEn == DdlObj_Sql &&
                    this->context->outDdlGenPtr != nullptr &&
                    tokens.size() > 1)
                {
                    this->context->outDdlGenPtr->enableAllTriggers(tokens.at(1));
                }
                else
                {
                    this->printMsg(ret, "Syntax error on keyword #" + this->context->currTag + "( must be the only command)");
                }
                continue;
            }
            else if (this->isTag(TAG_ROOT_ENTITY, true))
            {
                ddlGenContextPtr->bRootEntityManagement = true;
            }
            else if (this->isTag(TAG_GEN_SET_OUTPUT, true))
            {
                vector<string>  tokens;
                this->tokenize(tokens);

                this->context->currTagNat = TagSql_None;

                if (tokens.size() >= 2)
                {
                    DICT_ENTITY_STP outDictEntityStp = DBA_GetEntityBySqlName(tokens.at(1));
                    DBA_DYNTYPE_ENUM outDynNatEn = this->getDynType(tokens.at(2));

                    if (outDictEntityStp && outDynNatEn != DynType_Unknown)
                    {
                        this->ddlGenContextPtr->m_dependsAccessSet.insert(
                            DdlGenDependKey(outDictEntityStp->entDictId,
                                            outDictEntityStp->mdSqlName,
                                            DictDependsAccessEn::Returns,
                                            outDynNatEn));
                    }
                    else
                    {
                        ret = RET_GEN_ERR_INVARG;
                        this->printMsg(ret, "Syntax error on keyword #" + this->context->currTag);
                    }
                }
                else
                {
                    ret = RET_GEN_ERR_INVARG;
                    this->printMsg(ret, "Syntax error on keyword #" + this->context->currTag);
                }
            }
            else if (this->isTag(TAG_GET_RESULT_SET_DATA, true) ||
                     this->isTag(TAG_GET_FIRST_DATA, true) ||
                     this->isTag(TAG_GET_DATA, true) ||
                     this->isTag(TAG_GET_RESULT_SET_NUMBER, true))
            {
                this->context->currTagNat = TagSql_None;
                if ((ret = this->createGetResultSetData()) != RET_SUCCEED)
                {
                    gblRet = ret;
                    continue;
                }
            }
            else if (this->isTag(TAG_INS_OBJECT_MODIF_STAT, true))
            {
                this->ddlGenContextPtr->bStdIinsObjectModifStat = true;
                continue;
            }
            else if (this->isTag(TAG_UNION))
            {
                this->context->outDdlGenPtr->bUnion = true;
                this->context->outDdlGenPtr->bodySqlBlock << "\tunion" << endl;
                continue;
            }
            else if (this->isTag(TAG_UNION_ALL))
            {
                this->context->outDdlGenPtr->bUnion = true;
                this->context->outDdlGenPtr->bodySqlBlock << "\tunion all" << endl;
                continue;
            }
            else if (this->isTag(TAG_DEBUG))
            {
                SYS_BreakOnDebug();
                continue;
            }
            else
            {
                this->setInBlock(bSaveInBlock);
            }

            /* PMSTA-49178 - LJE - 220928 */
            if (this->context->outDdlGenPtr->isTagInBlock(this->context->currTagNat) == false)
            {
                this->setInBlock(bSaveInBlock);
            }
        }

        /* PMSTA-24026 - DDV - 161122 - Data framework */
        if (this->context->currLineStrLTrim.find(TAG_MAIN_DLM_CHECK) != string::npos)
        {
            if (this->getOutDdlObjEn() == DdlObj_SProc)
                this->ddlGenContextPtr->bMainDLMMax = true;
        }

        /* PMSTA-24026 - DDV - 161122 - Data framework */
        if (this->context->currLineStrLTrim.find(TAG_ADD_DLM_CHECK) != string::npos)
        {
            if (this->getOutDdlObjEn() == DdlObj_SProc)
                this->ddlGenContextPtr->bAddDLMMax = true;
        }

        /* Install from scratch special case */
        if (this->ddlGenContextPtr->ddlGenAction.m_installLevel <= 5)
        {
            if (RET_GET_LEVEL(this->lastErrRetCode) == RET_LEV_ERROR)
            {
                gblRet = this->lastErrRetCode;
            }
        }

        if (this->isTag(TAG_SPROC_END) == false &&
            this->isTag(TAG_FUNC_END) == false &&
            this->isTag(TAG_EXEC_END) == false &&
            this->isTag(TAG_VIEW_END) == false &&
            this->context->currTagNat == TagSql_Body)
        {
            this->context->outDdlGenPtr->bodySqlBlock << this->context->currLineStr << endl;
        }

        if ((this->m_parentDdlGenPtr == nullptr || paramOutDdlObjEn == DdlObj_SProc) &&
            this->ddlGenContextPtr->getDdlGenMode() == DdlGenMode_Standard)
        {
            if (this->context->currTagNat == TagSql_SProcStdBegin ||
                this->context->currTagNat == TagSql_SProcBegin ||
                this->context->currTagNat == TagSql_FuncBegin)
            {
                this->printMsg(RET_SRV_INFO_RUNNING, "Creating");
            }
        }
    }

    this->context->outDdlGenPtr->lastErrRetCode = gblRet;

    if (gblRet == RET_DBA_INFO_EXIST)
    {
        gblRet = RET_SUCCEED;
    }
    else
    {
        this->treatBody();

        if (RET_GET_LEVEL(this->lastErrRetCode) == RET_LEV_ERROR)
        {
            this->context->outDdlGenPtr->lastErrRetCode = this->lastErrRetCode;
        }

        if (this->isTag(TAG_SPROC_END, true))
        {
            if (this->context->outDdlGenPtr->lastErrRetCode != RET_GEN_INFO_NOACTION)
            {
                if (RET_GET_LEVEL(gblRet) != RET_LEV_ERROR &&
                    RET_GET_LEVEL((ret = this->managePartialSpecialization())) == RET_LEV_ERROR)
                {
                    gblRet = ret;
                }

                if (RET_GET_LEVEL(gblRet) != RET_LEV_ERROR &&
                    this->ddlGenContextPtr->getDdlGenMode() != DdlGenMode_Shadow)
                {
                    if (this->ddlGenContextPtr->getDdlGenMode() == DdlGenMode_Standard &&
                        this->ddlGenContextPtr->bDisableChangeSet == false &&
                        SYS_IsSqlMode() == false)
                    {
                        for (auto it = this->ddlGenContextPtr->m_dependsEntityMap.begin(); it != this->ddlGenContextPtr->m_dependsEntityMap.end(); it++)
                        {
                            if (it->second->changeSetAuthEn == FeatureAuth_Enable)
                            {
                                string oriBody = "\t-- DDL Generator mode: " + this->ddlGenContextPtr->getDdlGenModeStr() + "\n" + this->context->outDdlGenPtr->bodySqlBlock.str();
                                string shadowBody;
                                this->context->outDdlGenPtr->bodySqlBlock.clear();

                                this->ddlGenContextPtr->setDdlGenMode(DdlGenMode_Shadow);
                                this->ddlGenContextPtr->getDictSprocSt().m_dictSprocReturnsVector.clear();
                                this->context->m_elseResultsSetPos = 0;
                                this->context->m_ifResultsSetVector.clear();

                                this->buildBlock();
                                shadowBody = "\t-- DDL Generator mode: " + this->ddlGenContextPtr->getDdlGenModeStr() + "\n" + this->context->outDdlGenPtr->bodySqlBlock.str();
                                this->ddlGenContextPtr->setDdlGenMode(DdlGenMode_Standard);

                                this->context->outDdlGenPtr->bodySqlBlock.clear();

                                this->context->outDdlGenPtr->setIndent(1);
                                this->context->outDdlGenPtr->bodySqlBlock << endl
                                    << this->context->outDdlGenPtr->newLine() << "-- Change Set management" << endl
                                    << this->context->outDdlGenPtr->getCmdIfThenElse(this->context->outDdlGenPtr->getChangeSetId(false) + " is null", oriBody, shadowBody)
                                    << this->context->outDdlGenPtr->newLine() << "-- End Change Set management";
                                break;
                            }
                        }
                    }

                    this->context->currTagNat = TagSql_SProcEnd;

                    this->context->outDdlGenPtr->bodySqlBlock << this->printSubQuery(this->m_atReturnStream);

                    ret = gblRet;
                    if (RET_GET_LEVEL(ret) != RET_LEV_ERROR &&
                        RET_GET_LEVEL((ret = this->context->outDdlGenPtr->printHeader())) != RET_LEV_ERROR &&
                        RET_GET_LEVEL((ret = this->context->outDdlGenPtr->printFooter())) != RET_LEV_ERROR)
                    {
                        ret = this->context->outDdlGenPtr->flush();
                    }

                    if (this->m_parentDdlGenPtr == nullptr || paramOutDdlObjEn == DdlObj_SProc)
                    {
                        if (RET_GET_LEVEL(ret) != RET_LEV_ERROR &&
                            ret != RET_GEN_INFO_NODATA &&
                            ret != RET_DBA_INFO_EXIST &&
                            SYS_IsSqlMode() == FALSE)
                        {
                            ret = this->context->outDdlGenPtr->grant();
                        }

                        if (RET_GET_LEVEL(gblRet) == RET_LEV_ERROR ||
                            RET_GET_LEVEL(ret) == RET_LEV_ERROR ||
                            RET_GET_LEVEL((ret = this->context->outDdlGenPtr->lastErrRetCode)) == RET_LEV_ERROR ||
                            (this->ddlGenContextPtr->m_bHasUnknownCall == true && this->ddlGenContextPtr->ddlGenAction.m_installLevel < 5))
                        {
                            if (RET_GET_LEVEL(ret) != RET_LEV_ERROR)
                            {
                                ret = RET_DBA_ERR_INVDATA;
                            }

                            this->printMsg(ret, "of stored procedure failed");
                            gblRet = ret;
                        }
                        else if (this->context->outDdlGenPtr->lastErrRetCode == RET_GEN_INFO_NOACTION)
                        {
                            this->printMsg(RET_SRV_INFO_DONE, "Not modified");
                        }
                        else
                        {
                            string msgDone("Done");

                            if (this->ddlGenContextPtr->m_bHasUnknownCall)
                            {
                                msgDone += "***";
                            }
                            else if (ret == RET_GEN_INFO_NODATA)
                            {
                                msgDone += "**";
                            }
                            else if (this->ddlGenContextPtr->bWarning)
                            {
                                msgDone += "*";
                            }
                            this->printMsg(RET_SRV_INFO_DONE, msgDone);
                        }
                    }
                    else
                    {
                        this->lastErrRetCode = ret;
                    }

                    /* PMSTA-37374 - LJE - 210416 - Manage stored proc creation through aaa_sql */
                    if (SYS_IsSqlMode())
                    {
                        this->outDdlObjEn = DdlObj_Sql;
                    }

                    this->ddlGenContextPtr->setDdlGenMode(DdlGenMode_Standard);
                    this->context->currTagNat = TagSql_SProcEnd;
                    this->newOutDdlGen();
                    this->ddlGenContextPtr->m_bHasUnknownCall = false;
                }
            }
            else
            {
                this->context->outDdlGenPtr->printMsg(RET_SRV_INFO_NO_POSITIONS, "Create stored procedure " + this->ddlGenContextPtr->getDictSprocSt().sqlName + " skipped");
                this->context->currTagNat = TagSql_SProcEnd;
                this->newOutDdlGen();
                this->ddlGenContextPtr->m_bHasUnknownCall = false;
            }
        }
        else if (this->isTag(TAG_FUNC_END, true))
        {
            this->context->currTagNat = TagSql_FuncEnd;

            ret = gblRet;
            if (RET_GET_LEVEL((ret = this->context->outDdlGenPtr->printHeader())) != RET_LEV_ERROR &&
                RET_GET_LEVEL((ret = this->context->outDdlGenPtr->printFooter())) != RET_LEV_ERROR)
            {
                ret = this->context->outDdlGenPtr->flush();
            }

            if (RET_GET_LEVEL(ret) == RET_LEV_ERROR ||
                (ret != RET_DBA_INFO_EXIST && RET_GET_LEVEL((ret = this->context->outDdlGenPtr->grant())) == RET_LEV_ERROR) ||
                RET_GET_LEVEL((ret = this->context->outDdlGenPtr->lastErrRetCode)) == RET_LEV_ERROR)
            {
                this->printMsg(ret, "of function failed");
                gblRet = ret;
            }
            else if (this->context->outDdlGenPtr->lastErrRetCode == RET_GEN_INFO_NOACTION)
            {
                this->printMsg(RET_SRV_INFO_DONE, "Not modified");
            }
            else
            {
                this->printMsg(RET_SRV_INFO_DONE, "Done");
            }

            this->newOutDdlGen();
            this->ddlGenContextPtr->m_bHasUnknownCall = false;
        }
        else if (this->isTag(TAG_VIEW_END, true))
        {
            this->context->currTagNat = TagSql_ViewEnd;

            if (gblRet == RET_GEN_INFO_NOACTION)
            {
                if (this->ddlGenContextPtr->getDdlGenMode() != DdlGenMode_Shadow &&
                    this->ddlObjFromFileEn != DdlObjFromFile_SystemView &&
                    this->ddlObjFromFileEn != DdlObjFromFile_UtilsView)
                {
                    this->printMsg(RET_SRV_INFO_NO_POSITIONS, "Creation of the view: " + this->context->outDdlGenPtr->getDdlObjSqlName());
                }
                this->newOutDdlGen();
            }
            else
            {
                this->printMsg(RET_SRV_INFO_RUNNING, "Creating");

                this->context->outDdlGenPtr->cmdType = DDlCmdType_Create; /* PMSTA-39842 - LJE - 200417 */

                if (RET_GET_LEVEL((ret = this->context->outDdlGenPtr->printFooter())) == RET_LEV_ERROR ||
                    RET_GET_LEVEL((ret = this->context->outDdlGenPtr->flush())) == RET_LEV_ERROR ||
                    (ret != RET_DBA_INFO_EXIST && RET_GET_LEVEL((ret = this->context->outDdlGenPtr->grant())) == RET_LEV_ERROR) ||
                    RET_GET_LEVEL((ret = this->context->outDdlGenPtr->lastErrRetCode)) == RET_LEV_ERROR)
                {
                    this->printMsg(ret, "of view failed");
                    gblRet = ret;
                }
                else
                {
                    this->printMsg(RET_SRV_INFO_DONE, "Done");
                }

                DDL_VIEW_ENUM viewEn = this->ddlGenContextPtr->getViewEn();

                this->newOutDdlGen();
                this->ddlGenContextPtr->m_bHasUnknownCall = false;

                /* PMSTA-29879 - LJE - 180212 */
                if (viewEn == View_FullAllSecured)
                {
                    this->context->forcedViewEn = View_Export;
                    this->ddlGenContextPtr->bForceConnEntity = true; /* PMSTA-47053 - VSW - 23112021 */
                    this->buildBlock();
                    this->context->forcedViewEn = View_None;
                }
            }
        }
        else if (this->isTag(TAG_EXEC_END, true) &&
                 this->context->parentTagNat == TagSql_Body)
        {
            this->context->currTagNat = TagSql_ExecEnd;

            /* PMSTA-45413 - LJE - 211206 */
            if (this->ddlGenContextPtr->m_createTmpTableStream.str().empty() == false)
            {
                this->context->outDdlGenPtr->bodySqlBlock.initStream() << this->ddlGenContextPtr->m_createTmpTableStream.str();
            }

            if (this->context->outDdlGenPtr->bodySqlBlock.empty() == false)
            {
                this->context->outDdlGenPtr->cmdType = DDlCmdType_Exec;

                DdlGen::finishSqlBlock(this->context->outDdlGenPtr->bodySqlBlock, this->ddlGenContextPtr->m_rdbmsEn, this->getDdlObjEn());
                gblRet = this->context->outDdlGenPtr->flush();
            }
            this->ddlGenContextPtr->m_initSqlBlock << this->ddlGenContextPtr->m_createTmpTableStream.str();
            this->newOutDdlGen();
            this->ddlGenContextPtr->m_bHasUnknownCall = false;
        }
        else if (noEmptyLine &&
                 this->context->currTagNat != TagSql_StdProc &&
                 (this->context->parentTagNat == TagSql_Body || this->context->parentTagNat == TagSql_None))
        {
            if (this->ddlGenContextPtr->bGenFromDbi == false)
            {
                /* PMSTA-13109 - LJE - 111201 - Apply SQL between proc creation i.e. temp tables, grant, ... */
                this->context->outDdlGenPtr->cmdType = DDlCmdType_Init;
                gblRet = this->context->outDdlGenPtr->flush();
            }
            if (this->outDdlObjEn != DdlObj_Trigger)
            {
                this->newOutDdlGen();
            }
            this->ddlGenContextPtr->m_bHasUnknownCall = false;
        }
    }

    this->context->currBlockVector.clear();
    this->context->pscStream.clear();
    this->context->pscStream.str(string());
    this->context->currLineStr      = savedCurrLineStr;
    this->context->currLineStrLTrim = savedCurrLineStrLTrim;

    if (RET_GET_LEVEL(gblRet) == RET_LEV_ERROR)
    {
        this->lastErrRetCode = gblRet;
    }

    return(gblRet);
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::treatBody()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-18593 - LJE - 150121
**
*************************************************************************/
void DdlGenFromFile::treatBody()
{
    string bodyStr = this->context->outDdlGenPtr->bodySqlBlock.str();

    this->manageTempTable(bodyStr, true);
    
    this->replaceTag(bodyStr, TAG_ERROR, &DdlGenDbi::getDbError);
    this->replaceTag(bodyStr, TAG_UPDATE_COUNT, &DdlGenDbi::getCmdUpdateCount);

    this->context->outDdlGenPtr->replaceTagConvert(bodyStr);

    this->replaceFunctions(bodyStr);

    this->context->outDdlGenPtr->bodySqlBlock.clear();
    this->context->outDdlGenPtr->bodySqlBlock << bodyStr;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::managePartialSpecialization()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-32145 - LJE - 180721
**
*************************************************************************/
RET_CODE DdlGenFromFile::managePartialSpecialization()
{
    RET_CODE ret = RET_SUCCEED;

    /* PMSTA-32145 - LJE - 180720 */
    if (this->outDdlObjEn == DdlObj_SProc &&
        this->getDictEntityStp() != nullptr &&
        this->getDictEntityStp()->beEntityStp != nullptr &&
        this->ddlGenContextPtr->getDictSprocSt().role != DBA_ROLE_UPD_UD_FIELDS)
    {
        if (this->ddlGenContextPtr->getDictSprocSt().procActionEn == Update &&
            (this->ddlGenContextPtr->getDictSprocSt().procAccessEn == ProcAccess_All ||
             this->ddlGenContextPtr->getDictSprocSt().procAccessEn == ProcAccess_PrimaryKey))
        {
            stringstream insertStream;

            if (this->context->outDdlGenPtr->getConnBusinessEntAttrStp() != nullptr)
            {
                if (this->varHelperPtr->getVariable(this->context->outDdlGenPtr->getConnBusinessEntAttrStp()->sqlName, false) == nullptr)
                {
                    insertStream
                        << this->context->outDdlGenPtr->newLine() << "#IF " << this->context->outDdlGenPtr->getConnBusinessEntityId() << " != " << this->ddlGenContextPtr->getMasterBusinessEntityId();
                    insertStream
                        << this->context->outDdlGenPtr->newLine() << "#{";
                    this->context->outDdlGenPtr->setIndent(1);

                    insertStream
                        << this->context->outDdlGenPtr->newLine() << "#DECLARE @" << this->context->outDdlGenPtr->getConnBusinessEntAttrStp()->sqlName << " id_t"
                        << this->context->outDdlGenPtr->newLine() << "#NO_SECURED"
                        << this->context->outDdlGenPtr->newLine() << "#NO_MULTI_ENTITY"
                        << this->context->outDdlGenPtr->newLine() << "#SELECT " << this->getDictEntityStp()->mdSqlName << " null "
                        << this->context->outDdlGenPtr->newLine() << "@" << this->context->outDdlGenPtr->getConnBusinessEntAttrStp()->sqlName << " = " << this->getDictEntityStp()->ownerBusinessEntAttrStp->sqlName
                        << this->context->outDdlGenPtr->newLine() << "#FROM"
                        << this->context->outDdlGenPtr->newLine() << "#WHERE"
                        << this->context->outDdlGenPtr->newLine() << "unique"
                        << this->context->outDdlGenPtr->newLine() << "#END"
                        << this->context->outDdlGenPtr->newLine() << "#SECURED"
                        << this->context->outDdlGenPtr->newLine() << "#MULTI_ENTITY";

                    this->context->outDdlGenPtr->setIndent(-1);
                    insertStream
                        << this->context->outDdlGenPtr->newLine() << "#}";
                }
            }

            insertStream
                << this->context->outDdlGenPtr->newLine() << "#IF " << this->context->outDdlGenPtr->getConnBusinessEntityId() << " != " << this->ddlGenContextPtr->getMasterBusinessEntityId();

            if (this->context->outDdlGenPtr->getConnBusinessEntAttrStp() != nullptr)
            {
                insertStream
                    << " and @" << this->context->outDdlGenPtr->getConnBusinessEntAttrStp()->sqlName << " = " << this->ddlGenContextPtr->getMasterBusinessEntityId();
            }

            insertStream
                << this->context->outDdlGenPtr->newLine() << "#{";
            this->context->outDdlGenPtr->setIndent(1);

            if (this->getDictEntityStp()->changeSetAuthEn == FeatureAuth_Enable &&
                this->ddlGenContextPtr->getDdlGenMode() == DdlGenMode_Shadow)
            {
                insertStream
                    << this->context->outDdlGenPtr->newLine() << "#CHANGE_SET";
            }

            if (this->context->outDdlGenPtr->targetTableEn == TargetTable_UserDefinedFields)
            {
                insertStream
                    << this->context->outDdlGenPtr->newLine() << "#UPDATE " << this->getDictEntityStp()->mdSqlName << " ud_me_spec"
                    << this->context->outDdlGenPtr->newLine() << "#WHERE"
                    << this->context->outDdlGenPtr->newLine() << "unique"
                    << this->context->outDdlGenPtr->newLine() << this->getDictEntityStp()->ownerBusinessEntAttrStp->sqlName << " = #CONNECT_BUSINESS_ENTITY_ID";

                if (this->getDictEntityStp()->changeSetAuthEn == FeatureAuth_Enable &&
                    this->ddlGenContextPtr->getDdlGenMode() == DdlGenMode_Shadow)
                {
                    insertStream
                        << this->context->outDdlGenPtr->newLine() << "change_set_id = @change_set_id";
                }

                insertStream
                    << this->context->outDdlGenPtr->newLine() << "#END";
            }
            else
            {
                insertStream
                    << this->context->outDdlGenPtr->newLine() << "#UPDATE " << this->getDictEntityStp()->mdSqlName << " me_spec"
                    << this->context->outDdlGenPtr->newLine() << "#WHERE"
                    << this->context->outDdlGenPtr->newLine() << "unique"
                    << this->context->outDdlGenPtr->newLine() << this->getDictEntityStp()->ownerBusinessEntAttrStp->sqlName << " = #CONNECT_BUSINESS_ENTITY_ID";

                if (this->getDictEntityStp()->changeSetAuthEn == FeatureAuth_Enable &&
                    this->ddlGenContextPtr->getDdlGenMode() == DdlGenMode_Shadow)
                {
                    insertStream
                        << this->context->outDdlGenPtr->newLine() << "change_set_id = @change_set_id";
                }

                insertStream
                    << this->context->outDdlGenPtr->newLine() << "#UPDATE_COUNT"
                    << this->context->outDdlGenPtr->newLine() << "#END"
                    << this->context->outDdlGenPtr->newLine() << "#IF @row_count = 0"
                    << this->context->outDdlGenPtr->newLine() << "#{"
                    << this->context->outDdlGenPtr->newLine() << "\t#INSERT " << this->getDictEntityStp()->beEntityStp->mdSqlName << " all_db"
                    << this->context->outDdlGenPtr->newLine() << "\t#VALUES";

                if (this->getDictEntityStp()->changeSetAuthEn == FeatureAuth_Enable &&
                    this->ddlGenContextPtr->getDdlGenMode() == DdlGenMode_Shadow)
                {
                    insertStream
                        << this->context->outDdlGenPtr->newLine() << "change_set_id = @change_set_id"
                        << this->context->outDdlGenPtr->newLine() << "change_set_promotion_id = @change_set_id"
                        << this->context->outDdlGenPtr->newLine() << "sh_action_e = $SHAD_ACTION_TO_UPDATE /* ToUpdate */";
                }

                insertStream
                    << this->context->outDdlGenPtr->newLine() << "\t#END"
                    << this->context->outDdlGenPtr->newLine() << "#}";
            }

            if (this->getDictEntityStp()->changeSetAuthEn == FeatureAuth_Enable &&
                this->ddlGenContextPtr->getDdlGenMode() == DdlGenMode_Shadow)
            {
                insertStream
                    << this->context->outDdlGenPtr->newLine() << "#IF_NOT_EXISTS(select 1 from change_set_compo where change_set_id = @change_set_id and entity_dict_id = " << this->getDictEntityStp()->beEntityStp->entDictId << ")"
                    << this->context->outDdlGenPtr->newLine() << "#{"
                    << this->context->outDdlGenPtr->newLine() << "#INSERT change_set_compo all_db"
                    << this->context->outDdlGenPtr->newLine() << "#VALUES"
                    << this->context->outDdlGenPtr->newLine() << "entity_dict_id = " << this->getDictEntityStp()->beEntityStp->entDictId
                    << this->context->outDdlGenPtr->newLine() << "change_set_promotion_id = @change_set_id"
                    << this->context->outDdlGenPtr->newLine() << "#END"
                    << this->context->outDdlGenPtr->newLine() << "#}";
            }

            this->context->outDdlGenPtr->setIndent(-1);
            insertStream
                << this->context->outDdlGenPtr->newLine() << "#}"
                << this->context->outDdlGenPtr->newLine() << "#ELSE"
                << this->context->outDdlGenPtr->newLine() << "#{"
                << this->context->outDdlGenPtr->newLine() << this->context->outDdlGenPtr->bodySqlBlock.str()
                << this->context->outDdlGenPtr->newLine() << "#}";

            this->context->outDdlGenPtr->bodySqlBlock.clear();
            this->context->outDdlGenPtr->bodySqlBlock.setIndentOffsetNbr(1);
            this->context->outDdlGenPtr->bodySqlBlock << this->buildScript(insertStream.str());
        }
        else if (this->ddlGenContextPtr->getDictSprocSt().procActionEn == Delete &&
                 this->context->outDdlGenPtr->targetTableEn != TargetTable_UserDefinedFields &&
                 this->ddlGenContextPtr->getDictSprocSt().procAccessEn == ProcAccess_PrimaryKey)
        {
            stringstream insertStream;

            if (this->context->outDdlGenPtr->getConnBusinessEntAttrStp() != nullptr)
            {
                if (this->varHelperPtr->getVariable(this->context->outDdlGenPtr->getConnBusinessEntAttrStp()->sqlName, false) == nullptr)
                {
                    insertStream
                        << this->context->outDdlGenPtr->newLine() << "#IF " << this->context->outDdlGenPtr->getConnBusinessEntityId() << " != " << this->ddlGenContextPtr->getMasterBusinessEntityId();
                    insertStream
                        << this->context->outDdlGenPtr->newLine() << "#{";
                    this->context->outDdlGenPtr->setIndent(1);

                    insertStream
                        << this->context->outDdlGenPtr->newLine() << "#DECLARE @" << this->context->outDdlGenPtr->getConnBusinessEntAttrStp()->sqlName << " id_t"
                        << this->context->outDdlGenPtr->newLine() << "#NO_SECURED"
                        << this->context->outDdlGenPtr->newLine() << "#NO_MULTI_ENTITY"
                        << this->context->outDdlGenPtr->newLine() << "#SELECT " << this->getDictEntityStp()->mdSqlName << " null "
                        << this->context->outDdlGenPtr->newLine() << "@" << this->context->outDdlGenPtr->getConnBusinessEntAttrStp()->sqlName << " = " << this->getDictEntityStp()->ownerBusinessEntAttrStp->sqlName
                        << this->context->outDdlGenPtr->newLine() << "#FROM"
                        << this->context->outDdlGenPtr->newLine() << "#WHERE"
                        << this->context->outDdlGenPtr->newLine() << "unique"
                        << this->context->outDdlGenPtr->newLine() << "#END"
                        << this->context->outDdlGenPtr->newLine() << "#SECURED"
                        << this->context->outDdlGenPtr->newLine() << "#MULTI_ENTITY";

                    this->context->outDdlGenPtr->setIndent(-1);
                    insertStream
                        << this->context->outDdlGenPtr->newLine() << "#}";
                }
            }

            insertStream
                << this->context->outDdlGenPtr->newLine() << "#IF " << this->context->outDdlGenPtr->getConnBusinessEntityId() << " != " << this->ddlGenContextPtr->getMasterBusinessEntityId();

            if (this->context->outDdlGenPtr->getConnBusinessEntAttrStp() != nullptr)
            {
                insertStream
                    << " and @" << this->context->outDdlGenPtr->getConnBusinessEntAttrStp()->sqlName << " = " << this->ddlGenContextPtr->getMasterBusinessEntityId();
            }

            insertStream
                << this->context->outDdlGenPtr->newLine() << "#{";
            this->context->outDdlGenPtr->setIndent(1);

            insertStream
                << this->context->outDdlGenPtr->newLine() << "#DELETE " << this->getDictEntityStp()->beEntityStp->mdSqlName
                << this->context->outDdlGenPtr->newLine() << "#WHERE";

            if (this->getDictEntityStp()->primKeyNbr)
            {
                for (int i = 0; i < this->getDictEntityStp()->primKeyNbr; ++i)
                {
                    insertStream
                        << this->context->outDdlGenPtr->newLine() << this->getDictEntityStp()->primKeyTab[i]->sqlName << " = @" << this->getDictEntityStp()->primKeyTab[i]->sqlName;
                }
            }
            else
            {
                ret = RET_DBA_ERR_INVDATA;
                this->printMsg(ret, "Unsupported entity (without primary key) for partial specialized attribute");
            }

            insertStream
                << this->context->outDdlGenPtr->newLine() << "#UPDATE_COUNT"
                << this->context->outDdlGenPtr->newLine() << "#END";

            insertStream
                << this->context->outDdlGenPtr->newLine() << "#IF @row_count = 0"
                << this->context->outDdlGenPtr->newLine() << "#{";
            this->context->outDdlGenPtr->setIndent(1);

            insertStream
                << this->context->outDdlGenPtr->newLine() << "#APPL_RAISERROR 20571, 'delete', " << this->getDictEntityStp()->mdSqlName
                << this->context->outDdlGenPtr->newLine() << "#RETURN (-1)";

            this->context->outDdlGenPtr->setIndent(-1);
            insertStream
                << this->context->outDdlGenPtr->newLine() << "#}";

            this->context->outDdlGenPtr->setIndent(-1);
            insertStream
                << this->context->outDdlGenPtr->newLine() << "#}"
                << this->context->outDdlGenPtr->newLine() << "#ELSE"
                << this->context->outDdlGenPtr->newLine() << "#{"
                << this->context->outDdlGenPtr->newLine() << this->context->outDdlGenPtr->bodySqlBlock.str()
                << this->context->outDdlGenPtr->newLine() << "#}";

            this->context->outDdlGenPtr->bodySqlBlock.clear();
            this->context->outDdlGenPtr->bodySqlBlock.setIndentOffsetNbr(1);
            this->context->outDdlGenPtr->bodySqlBlock << this->buildScript(insertStream.str());
        }
        else if (this->ddlGenContextPtr->bPartialSpecialization &&
                 this->ddlGenContextPtr->getDictSprocSt().procActionEn == Custom && 
                 this->ddlGenContextPtr->getDdlGenMode() == DdlGenMode_ValidateShadow)
        {

        }
        else if (this->ddlGenContextPtr->bPartialSpecialization)
        {
            ret = RET_DBA_ERR_INVDATA;
            this->printMsg(ret, "Unsupported stored procedure that contains partial specialized attribute");
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::checkInsertSelectList()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-21197 - LJE - 160419
**
*************************************************************************/
RET_CODE DdlGenFromFile::checkInsertSelectList(DdlGen *locDdlGenPtr)
{
    RET_CODE ret = RET_SUCCEED;

    /* PMSTA-18593 - LJE - 160418 - Check */
    if (this->insertList.empty() == false)
    {
        list<DdlSelectElt>::iterator itSel = locDdlGenPtr->selectList.begin();
        list<DdlSelectElt>::iterator itIns;

        for (itIns = this->insertList.begin();
             itIns != this->insertList.end() && itSel != locDdlGenPtr->selectList.end();
             itIns++, itSel++)
        {
            string insSqlName = itIns->mdSqlName.empty() ? itIns->sqlName : itIns->mdSqlName;
            string selSqlName = itSel->mdSqlName.empty() ? itSel->sqlName : itSel->mdSqlName;

            if (insSqlName.empty())
            {
                string alias = itIns->colAlias;
                size_t pos = itIns->value.find(alias + ".");
                if (pos == 0)
                {
                    pos = alias.length() + 1;
                }
                else if (itIns->value[0] == '@')
                {
                    pos = 1;
                }
                else
                {
                    pos = 0;
                }
                insSqlName = itIns->value.substr(pos, itIns->value.find_first_of(" \t") - pos);
            }
            if (selSqlName.empty())
            {
                string alias = itSel->colAlias;
                size_t pos = itSel->value.find(alias + ".");
                if (pos == 0)
                {
                    pos = alias.length() + 1;
                }
                else if (itSel->value[0] == '@')
                {
                    pos = 1;
                }
                else
                {
                    pos = 0;
                }
                selSqlName = itSel->value.substr(pos, itSel->value.find_first_of(" \t") - pos);
            }

            if (insSqlName.compare(selSqlName) != 0)
            {
                ret = RET_DBA_ERR_INVDATA;
                this->printMsg(ret, "Wrong argument name on the #INSERT command (" + insSqlName + " vs " + selSqlName + ")");
            }
        }

        if (itIns != this->insertList.end() || itSel != locDdlGenPtr->selectList.end())
        {
            ret = RET_DBA_ERR_INVDATA;
            this->printMsg(RET_DBA_ERR_INVDATA, "Wrong number of argument on the #INSERT command");
        }
    }

    return ret;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::printMsg()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  ORACLE - LJE - 141014
**
*************************************************************************/
void DdlGenFromFile::printMsg(RET_CODE retCode, const std::string &paramMsg, bool isNewLine, int sprocLine)
{
    if (this->genSqlFileStr.empty() == false)
    {
        if (sprocLine < 0)
        {
            if (this->context != NULL)
            {
                sprocLine = this->context->blockLineBeginNb + this->context->lineNb + 1;
            }
            else
            {
                sprocLine = this->readLineNb;
            }
        }

        this->msgFileName = this->genSqlFileStr;
    }

    if (this->context != nullptr &&
        this->context->outDdlGenPtr != nullptr)
    {
        this->context->outDdlGenPtr->printMsg(retCode, paramMsg, isNewLine, sprocLine);
    }
    else
    {
        DdlGenMsg::printMsg(retCode, paramMsg, isNewLine, sprocLine);
    }
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::getResultSetDataPtr()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-37366 - LJE - 200427
*************************************************************************/
void DdlGenFromFile::setResultSetDataPtr(DdlGenData *newResultSetData)
{
    if (this->resultSetData == nullptr ||
        newResultSetData != this->resultSetData)
    {
        delete this->resultSetData;
        this->resultSetData = new DdlGenData();

        *this->resultSetData = *newResultSetData;
    }
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::getResultSetDataPtr()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-37366 - LJE - 200427
*************************************************************************/
DdlGenData  *DdlGenFromFile::getResultSetDataPtr()
{
    return this->resultSetData;
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::addResultSetData()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-28698 - LJE - 180601
**
*************************************************************************/
void  DdlGenFromFile::addResultSetData(size_t resultSetIdx, size_t recordIdx, DBA_DYNFLD_STP recordStp, FIELD_IDX_T recordStpSize)
{
    if (this->resultSetData == nullptr)
    {
        this->resultSetData = new DdlGenData();
    }

    this->resultSetData->addResultSetData(resultSetIdx, recordIdx, recordStp, recordStpSize);
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::addResultSetData()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-28698 - LJE - 180601
**
*************************************************************************/
void  DdlGenFromFile::addResultSetData(size_t resultSetIdx, size_t recordIdx, std::vector<DdlGenDataField> &ddlGenDataFieldVector)
{
    if (this->resultSetData == nullptr)
    {
        this->resultSetData = new DdlGenData();
    }

    this->resultSetData->addResultSetData(resultSetIdx, recordIdx, ddlGenDataFieldVector);
}

/************************************************************************
**
**  Function    :  DdlGenFromFile::freeResultSetData()
**
**  Description :
**
**  Arguments   :
**
**  Return      :
**
** Creation     :  PMSTA-28698 - LJE - 180601
**
*************************************************************************/
void  DdlGenFromFile::freeResultSetData()
{
    delete this->resultSetData;
    this->resultSetData = nullptr;
}

/*************************************************************************
**   END  ddlgenfromfile.cpp                                        Odyssey **
*************************************************************************/

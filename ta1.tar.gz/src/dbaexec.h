/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef DBAEXEC_H
#define DBAEXEC_H

/************************************************************************
**      External Structure definitions
*************************************************************************/

/************************************************************************
**      Constant & Macro definitions
*************************************************************************/

/***********************************************************************
**      BEGIN External definitions attached to : dbaexec.c
*************************************************************************/
#ifdef EXTERN
#undef EXTERN
#endif
#ifdef  DBAEXEC_C
#define EXTERN
#else
#define EXTERN extern
#endif
extern RET_CODE DBA_LoadOrderExecAndFeeByPtf(DBA_DYNFLD_STP, DBA_DYNFLD_STP **, int *, int *, DBA_HIER_HEAD_STP);
extern RET_CODE DBA_SplitCollectedExtOp(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, FLAG_T, FLAG_T, FLAG_T, FLAG_T, FLAG_T, DBA_DYNFLD_STP*, int);	/* PMSTA00954 - RAK - 070214 */
extern RET_CODE DBA_SplitExternalPos(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, FLAG_T, FLAG_T, FLAG_T, FLAG_T, FLAG_T, DBA_DYNFLD_STP*, int);	/* PMSTA00954 - RAK - 070214 */
extern RET_CODE DBA_SplitExtOpBlock(DBA_DYNST_ENUM, DBA_DYNFLD_STP, DBA_HIER_HEAD_STP,
                                    int, DBA_DYNFLD_STP **, int *, const DBA_DYNST_ENUM**, /* REF8844 - LJE - 030415 */
                                    FLAG_T, FLAG_T, FLAG_T, FLAG_T, FLAG_T, FLAG_T,
                                    DBA_DYNFLD_STP **, int *, DBA_DYNFLD_STP **, int *, DBA_DYNFLD_STP *, int, int *, bool);
extern RET_CODE DBA_LoadPPSForPtf(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP **, int *);
extern FLAG_T DBA_CheckPPSDim(DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP *, int),
              DBA_CheckPtfDim(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, ID_T, DBA_DYNFLD_STP, 
                              DBA_DYNFLD_STP *, FLAG_T, DATETIME_STP, DBA_DYNFLD_STP *, int),
              DBA_CheckInstrDim(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP, ID_T, DBA_DYNFLD_STP,
                                DBA_DYNFLD_STP *, int *, FLAG_T, DATETIME_STP, FLAG_T),
              DBA_CheckQuantity(DBA_DYNFLD_STP, DBA_DYNFLD_STP, const FLAG_T);

extern RET_CODE DBA_CheckPositions(DBA_DYNFLD_STP, DBA_HIER_HEAD_STP);	/* PMSTA05219 - RAK - 080812 */
extern CASHFLOWMGT_ENUM DBA_GetCashFlowMgtEnum(DBA_DYNFLD_STP, DBA_DYNFLD_STP); /* DLA - PMSTA04851 - 080312 */
extern FLAG_T   DBA_CheckPositionToRemove(const DBA_DYNFLD_STP, const DBA_DYNFLD_STP); /* Function renamed PMSTA-6924 - 280109 - PMO / PMSTA-5595 - 190808 - PMO */
extern FLAG_T   DBA_CheckMarginCallPositionToRemove(const DBA_DYNFLD_STP, const DBA_DYNFLD_STP);    /* PMSTA08594 - 140909 - PMO */
extern bool     DBA_IsTechnicalPosition(const DBA_DYNFLD_STP);                                      /* PMSTA-20838 - 160715 - PMO */
extern bool     DBA_IsTechnicalCashPosition(const DBA_DYNFLD_STP);                                  /* PMSTA-20838 - 160715 - PMO */

#endif	 /* ifndef DBAEXEC_H */

/************************************************************************
**      END        dbaexec.h
*************************************************************************/

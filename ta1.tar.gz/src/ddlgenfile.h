/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef DDLGENFILE_H
#define DDLGENFILE_H

#include <fstream>

/************************************************************************
**      Constant & Macro definitions
*************************************************************************/

/************************************************************************
**      Structures & typedef definitions
*************************************************************************/

/************************************************************************
**      External definitions attached to : ddlgencfgfile.cpp
*************************************************************************/
class DdlGenFile : public DdlGenMsg
{

public:
    // Constructors
    DdlGenFile(DdlGenContext &paramDdlGenContext,
               OBJECT_ENUM	  paramObjectEn,
               DDL_OBJ_ENUM   paramDdlObjEn,
               bool           bAppendFile,
               bool           bOpenCheckFile);
    DdlGenFile(const DdlGenFile&) = delete;
    // Destructor
    virtual ~DdlGenFile();

    // Methods
    DdlGenFile&       operator = (const DdlGenFile&) = delete;

    DdlGenFile &operator<<(const std::string&);
    DdlGenFile &operator<<(std::stringstream&);
    DdlGenFile &operator<<(int);

    void              flush();
    static void       getFileHeader(std::stringstream &, unsigned &);


    std::string       outputFileStr;
    unsigned          outFileLinePos;
    unsigned          fixedOutFileLineNbr;
    DDL_OBJ_ENUM      ddlObjEn;

    std::string            chk1Str;
    std::string            chk2Str;
    std::string            toChkStr;

    std::ofstream          chkFile1;
    std::ofstream          chkFile2;
    std::fstream           procDiffFile;

protected:
    RET_CODE          createOutputDdlFile(bool bAppendFile = false, bool bOpenCheckFile = false);
    void              closeAllFiles();

    std::ofstream     outputFile;
    std::string       entitySqlName;
    OBJECT_ENUM	      objectEn;
    DICT_ENTITY_STP   dictEntityStp;

private:


};

#endif	                               /* ifndef DDLGENFILE_H */
/************************************************************************
**      END       ddlgenfile.h                                Odyssey
*************************************************************************/

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/
#ifdef NTWIN
#pragma warning (push)
#endif

#include <QString>

#include "unidef.h"     /* Mandatory */
#include "gen.h"
#include "dba.h"
#include "proc.h"
#include "syb.h"
#include "dbi.h"
#include "str.h"

#include "oralib.h"

#ifdef NUODB_ENABLE
#include "nuodblib.h"
#endif
#ifdef MSDB_ENABLE
#include "msdblib.h"
#endif
#ifdef POSTGRESQL_ENABLE
#include "pgslib.h"
#endif

#include "httplib.h"
#include "sqlitelib.h"

#include "date.h"
#include "crypt.h"
#include "dbiconnection.h"
#include "sybconnection.h"
#include "oraconnection.h"
#include <stdarg.h>

/* PMSTA-18593 - LJE - 151114 */
#include "ddlgenfromfile.h"
#include "ddlgenvar.h"
#include "aaasql.h"
#include "json.h"
#include "httpclient.h"
#include "fussync.h"

#ifdef NTWIN
#pragma warning (pop)
#endif

#define ITER_NBR_FOR_DEADLOCK       4    /* Ref.: DVP251 */

extern DBA_RDBMS_ENUM EV_RdbmsVendor;
extern int EV_AAAInstallLevel;

using namespace std;

extern size_t(*DBA_GetDataSegmentSize)(void);
extern bool(*DBA_WarningMessageBox)(const char *);

/************************************************************************
*   Function             :  DBI_GenericManagedSqlExec
* 
*   Description          :  Send a character string representing a SQL Dynamic request.
*
*   Arguments            :
*
*   Return               :
*
*   Creation             :  PMSTA-49178 - LJE - 220901
*
*   Last Modification    :
*************************************************************************/
RET_CODE DBI_GenericManagedSqlExec(AAASQL_CONTEXT_STP sqlContextStp)
{
    DbiConnection* dbiConnPtr = sqlContextStp->connHelperPtr->getConnection();
    bool                 bAssignVars = false;
    RET_CODE             retCode = RET_SUCCEED;
    MemoryPool           mp;
    bool                 bISqlBehavior = (sqlContextStp->verboseLevel == VerboseLevel_iSQL ||
                                          sqlContextStp->verboseLevel == VerboseLevel_HideEmptyResultSet ||
                                          sqlContextStp->verboseLevel == VerboseLevel_Align);

    const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
    if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
    {
        auto& sqlTrace = sqlContextStp->connHelperPtr->getConnection()->getSqlTrace();
        sqlTrace.m_procedure = "DynSql.DBI_GenericManagedSqlExec";
        sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
    }

    bool bIsAddDataResultSet = (sqlContextStp->scriptDdlGenPtr != nullptr &&
                                sqlContextStp->scriptDdlGenPtr->bKeepData == true &&
                                sqlContextStp->scriptDdlGenPtr->bKeepResultSetData == false);

    if (bIsAddDataResultSet)
    {
        sqlContextStp->scriptDdlGenPtr->freeResultSetData();
    }

    dbiConnPtr->initMessageBehavior();

    RequestHelper requestHelper(dbiConnPtr);
    requestHelper.setExternalMsgManagement(true);

    string sqlCmd(sqlContextStp->sqlCmd);

    do
    {
        requestHelper.setCommand(sqlCmd);
        retCode = requestHelper.sendCommandForFetch();

        if (RET_GET_LEVEL(retCode) != RET_LEV_ERROR)
        {
            bool             bRowResPrinted = false;
            size_t           resultSetIdx = 0;
            bool             bContinue = true;

            dbiConnPtr->getPrintAndClearMessages(cout);

            do
            {
                int colCountNbr = requestHelper.getColumnCount();

                if (colCountNbr > 0)
                {
                    AAASQL_OUTPUT_PARAM_STP outParamTab = (AAASQL_OUTPUT_PARAM_STP)mp.calloc(colCountNbr, sizeof(AAASQL_OUTPUT_PARAM_ST));

                    vector<DdlGenDataField> ddlGenDataFieldVector;

                    if (bIsAddDataResultSet)
                    {
                        ddlGenDataFieldVector.resize(colCountNbr);
                    }

                    for (int i = 0; i < colCountNbr; i++)
                    {
                        int colNum = i + 1;

                        string colName;
                        requestHelper.getColumnName(colNum, colName);
                        strcpy(outParamTab[i].colName, colName.c_str());

                        CTYPE_ENUM cType = LastCtype;
                        requestHelper.getColumnType(colNum, cType);

                        outParamTab[i].precision = requestHelper.getPrecision(colNum);
                        outParamTab[i].scale = requestHelper.getScale(colNum);
                        outParamTab[i].dataSize = requestHelper.getColumnMaxLength(colNum);
                        outParamTab[i].colWith = requestHelper.getColumnMaxLength(colNum); /* Alignment issue Fix */

                        outParamTab[i].dataType = dbiConnPtr->getDatatypeFromDesc(cType, outParamTab[i].dataSize, outParamTab[i].precision, outParamTab[i].scale);

                        if (outParamTab[i].dataType == TextType ||
                            outParamTab[i].dataType == UniTextType)
                        {
                            outParamTab[i].dataSize = GET_MAXLEN(TextType);
                        }

                        if (outParamTab[i].dataType == NullDataType)
                        {
                            outParamTab[i].dataType = String1000Type;
                        }

                        requestHelper.addNewOutputData(outParamTab[i].dataType);
                    }
                    FLAG_T        done      = 0;
                    int           rowNumber = 0;
                    size_t        alignNbr  = 0;
                    stringstream  headStream;
                    stringstream  sepStream;

                    if (bISqlBehavior &&
                        sqlContextStp->bPrintHeader)
                    {
                        headStream << sqlContextStp->separator;
                        sepStream << sqlContextStp->separator;
                    }

                    for (int i = 0; i < colCountNbr; i++)
                    {
                        alignNbr = DBA_GetDataTypeAlignSize(outParamTab[i].dataType, strlen(outParamTab[i].colName), outParamTab[i].colWith, false, outParamTab[i].szAlignPos);
                        sepStream << STRING_FillPatern(string(), alignNbr, '-') << sqlContextStp->separator;

                        outParamTab[i].colWith = static_cast<int>(alignNbr);

                        if (bISqlBehavior &&
                            sqlContextStp->bPrintHeader)
                        {
                            char szFmt[128];
                            string headStr;
                            sprintf(szFmt, "%s%ds%s", "%-", (int)alignNbr, sqlContextStp->separator.c_str());
                            if (sqlContextStp->bHeaderLowerCase)
                            {
                                SYS_StringFormat(headStr, szFmt, lower(outParamTab[i].colName).c_str());
                            }
                            else
                            {
                                SYS_StringFormat(headStr, szFmt, outParamTab[i].colName);
                            }
                            headStream << headStr;
                        }

                        if (i == 0 && strcmp(outParamTab[i].colName, "get_variable") == 0)
                        {
                            bAssignVars = true;
                        }

                        if (ddlGenDataFieldVector.empty() == false)
                        {
                            ddlGenDataFieldVector[i].setSqlName(outParamTab[i].colName);
                            ddlGenDataFieldVector[i].dataType = outParamTab[i].dataType;
                        }
                    }

                    if (bAssignVars == false &&
                        sqlContextStp->verboseLevel == VerboseLevel_iSQL &&
                        sqlContextStp->bPrintHeader)
                    {
                        cout << headStream.str() << endl
                            << sepStream.str() << endl;
                    }

                    bool bConcat   = false;
                    int  rank      = 0;

                    while (requestHelper.fetch() == RET_SUCCEED)
                    {
                        if (sqlContextStp->rowCount != 0 && rowNumber == sqlContextStp->rowCount)
                        {
                            bContinue = false;
                            break;
                        }

                        if (rowNumber == 0 &&
                            sqlContextStp->verboseLevel == VerboseLevel_HideEmptyResultSet &&
                            bAssignVars == false &&
                            sqlContextStp->bPrintHeader)
                        {
                            cout << headStream.str() << endl
                                << sepStream.str() << endl;
                        }

                        stringstream currValueStream;

                        if (bAssignVars == false &&
                            bISqlBehavior &&
                            sqlContextStp->bPrintHeader)
                        {
                            cout << sqlContextStp->separator;
                        }
                        for (int i = 0; i < colCountNbr; i++)
                        {

                            if (bConcat == false)
                            {
                                currValueStream.clear();
                                currValueStream.str(string());
                            }

                            if (bAssignVars && i == 0)
                            {
                                if (outParamTab[i].dataType != String1000Type && strcmp(requestHelper.getCharPtrValue(i), "++VAR++") != 0)
                                {
                                    if (bISqlBehavior &&
                                        sqlContextStp->bPrintHeader)
                                    {
                                        cout << headStream.str() << endl;
                                        cout << sepStream.str() << endl;
                                    }
                                    bAssignVars = false;
                                }
                                else
                                {
                                    continue;
                                }
                            }

                            if (requestHelper.isNullValue(i))
                            {
                                outParamTab[i].nullInd = -1;

                                currValueStream << "NULL";
                            }
                            else
                            {
                                outParamTab[i].nullInd = 0;

                                switch (GET_CTYPE(outParamTab[i].dataType))
                                {
                                    case LongLongCType:
                                    case TimeStampCType:
                                    case BinaryCType:
                                        currValueStream << requestHelper.getLongLongValue(i);
                                        break;

                                    case CharPtrCType:
                                    case TextPtrCType:
                                    {
                                        currValueStream << requestHelper.getCharPtrValue(i);

                                        if (bAssignVars)
                                        {
                                            size_t lenght = strlen(outParamTab[i].colName);

                                            stringstream concatStr;
                                            concatStr << "$" << rank++;

                                            if (lenght > 2 && strcmp(&(outParamTab[i].colName[lenght - 2]), concatStr.str().c_str()) == 0)
                                            {
                                                bConcat = true;
                                            }
                                            else
                                            {
                                                rank = 0;
                                                bConcat = false;
                                            }
                                        }
                                        break;
                                    }

                                    case UniCharPtrCType:
                                    case UniTextPtrCType:
                                    {
                                        /* each uchar can be upto 4 bytes + terminal null */
                                        int capacity = ((u_strlen(requestHelper.getUCharPtrValue(i)))) * 4 + 1;
                                        char* utf8String = (char*)CALLOC(capacity, sizeof(char));
                                        if (utf8String != nullptr && !ICU4AAA_ConvertToUTF8(requestHelper.getUCharPtrValue(i), -1, utf8String, capacity, NULL))
                                        {
                                            currValueStream << utf8String;
                                        }
                                        else
                                        {
                                            currValueStream << "N/A";
                                        }
                                        FREE(utf8String);

                                    }
                                    break;

                                    case DoubleCType:
                                        currValueStream << CONV_DoubleToNumericString(
                                            requestHelper.getDoubleValue(i), outParamTab[i].precision, outParamTab[i].scale);
                                        break;

                                    case IntCType:
                                        currValueStream << requestHelper.getIntValue(i);
                                        break;

                                    case UIntCType:
                                        currValueStream << requestHelper.getUIntValue(i);
                                        break;

                                    case ShortCType:
                                    {
                                        std::string strOut;
                                        SYS_StringFormat(strOut, "%d", int(requestHelper.getShortValue(i)));
                                        currValueStream << strOut;
                                    }
                                    break;

                                    case UShortCType:
                                    {
                                        std::string strOut;
                                        SYS_StringFormat(strOut, "%d", int(requestHelper.getUShortValue(i)));
                                        currValueStream << strOut;
                                    }
                                    break;

                                    case UCharCType:
                                    {
                                        std::string strOut;
                                        SYS_StringFormat(strOut, "%d", int(requestHelper.getUCharValue(i)));
                                        currValueStream << strOut;
                                    }
                                    break;

                                    case DateTimeStCType:
                                    {
                                        string dateStr;
                                        DATETIME_ToSqlStr(dateStr,
                                                          requestHelper.getDateTimeValue(i),
                                                          bAssignVars ? sqlContextStp->inDateTimeStyleEn : sqlContextStp->outDateTimeStyleEn,
                                                          outParamTab[i].dataType == DateType ? TimeStyle_None : TimeStyle_24);
                                        currValueStream << dateStr;

                                        if (bAssignVars)
                                        {
                                            DdlGenVar* currVar = sqlContextStp->ddlGenVarHelperPtr->getVariable(outParamTab[i].colName);

                                            if (currVar)
                                            {
                                                currVar->dateTimeValue = requestHelper.getDateTimeValue(i);
                                            }
                                        }
                                        break;
                                    }

                                    default:
                                        currValueStream << "N/A";
                                        break;
                                }
                            }

                            if (bAssignVars)
                            {
                                if (bConcat == false)
                                {
                                    DdlGenVar* currVar = sqlContextStp->ddlGenVarHelperPtr->getVariable(outParamTab[i].colName);
                                    if (currVar)
                                    {
                                        currVar->setValue(currValueStream.str());
                                        currVar->bNullValue = requestHelper.isNullValue(i);
                                        currVar->bRuntimeValue = true;
                                    }
                                }
                            }
                            else
                            {
                                if (bISqlBehavior &&
                                    (sqlContextStp->bPrintHeader || sqlContextStp->bPrintAllign) &&
                                    outParamTab[i].szAlignPos[0] != 0)
                                {
                                    cout << STRING_FillPatern(currValueStream.str(), outParamTab[i].colWith, ' ');
                                }

                                cout << currValueStream.str();

                                if (bISqlBehavior &&
                                    (sqlContextStp->bPrintHeader || sqlContextStp->bPrintAllign) &&
                                    outParamTab[i].szAlignPos[0] == 0)
                                {
                                    cout << STRING_FillPatern(currValueStream.str(), outParamTab[i].colWith, ' ');
                                }

                                cout << sqlContextStp->separator;
                            }

                            if (ddlGenDataFieldVector.empty() == false)
                            {
                                if (requestHelper.isNullValue(i))
                                {
                                    ddlGenDataFieldVector[i].bNullValue = true;
                                }
                                else
                                {
                                    ddlGenDataFieldVector[i].value = currValueStream.str();
                                    ddlGenDataFieldVector[i].bNullValue = false;
                                }
                            }
                        }

                        if (bIsAddDataResultSet)
                        {
                            sqlContextStp->scriptDdlGenPtr->addResultSetData(resultSetIdx, rowNumber, ddlGenDataFieldVector);
                        }

                        cout << endl;

                        rowNumber++;
                        if (bAssignVars)
                        {
                            done = 1;
                        }
                    }
                    bRowResPrinted = true;

                    if (sqlContextStp->verboseLevel != VerboseLevel_None &&
                        sqlContextStp->verboseLevel != VerboseLevel_Align &&
                        sqlContextStp->bPrintRowCount &&
                        (sqlContextStp->verboseLevel != VerboseLevel_HideEmptyResultSet || rowNumber > 0))
                    {
                        if (rowNumber > 0)
                        {
                            cout << endl;
                        }
                        cout << "(" << rowNumber << (rowNumber == 1 ? " row " : " rows ") << "affected)" << endl;
                    }

                    resultSetIdx++;
                }

                dbiConnPtr->getPrintAndClearMessages(cout);

            } while (requestHelper.getLastResultType() == DBI_ROW_RESULT && bContinue);

            sqlCmd = dbiConnPtr->getNextAction();
        }
        else
        {
            sqlCmd.clear();
        }
    }
    while (sqlCmd.empty() == false);

    if (RET_GET_LEVEL(retCode) == RET_LEV_ERROR)
    {
        dbiConnPtr->endTransaction(FALSE);
    }
    else
    {
        if (retCode == RET_DBA_INFO_NO_MORE_DATA)
        {
            retCode = RET_SUCCEED;
        }

        if (dbiConnPtr->isAutoCommit() == false)
        {
            dbiConnPtr->endTransaction(TRUE);
        }
    }

    if (sqlContextStp->verboseLevel != VerboseLevel_None &&
        sqlContextStp->verboseLevel != VerboseLevel_Align) /* return status */
    {
        cout << "(return status = " << (retCode == RET_SUCCEED ? 0 : retCode) << ")" << endl;
    }

    dbiConnPtr->releaseCommand();
    dbiConnPtr->closeMessageBehavior();

    return(retCode);
}

/************************************************************************
*   Function             : DBI_ManageSqlExec()
*
*   Description          : Send a character string representing a SQL Dynamic
*                          request.
*
*   Arguments            : sqlBuff         : the dynamic SQL request
*                          forcedConnectNo : a connection number
*                          option          : DBA_SET_CONN or UNUSED
*
*   Functions call       :
*
*   Return               : RET_SUCCEED : if ok
*
*   Last modif.          : PMSTA-37366 - LJE - 191118
*
*************************************************************************/
RET_CODE DBI_ManagedSqlExec(AAASQL_CONTEXT_STP sqlContextStp, int* status)
{
    RET_CODE ret = RET_SUCCEED;
    int      locStatus = -1;

    sqlContextStp->bSetParamDone = false;
    sqlContextStp->rpcName.clear();

    if (sqlContextStp->bFinSrvMode)
    {
        bool bSetProcByPos = false;

        size_t firstEqPos = sqlContextStp->sqlCmd.find("=");
        size_t firstAtPos = sqlContextStp->sqlCmd.find("@");

        if (firstEqPos == string::npos || firstAtPos == string::npos || firstEqPos < firstAtPos)
        {
            bSetProcByPos = true;
        }
        size_t pos = sqlContextStp->sqlCmd.find_first_not_of(" \t\n");
        bool bReplace = bSetProcByPos;
        sqlContextStp->rpcName = sqlContextStp->sqlCmd.substr(pos, sqlContextStp->sqlCmd.find_first_of(" \t\n", pos) - pos);

        if (DBI_GetRpcParamInfoStp(sqlContextStp->rpcName.c_str(), sqlContextStp->rpcProperties) &&
            sqlContextStp->rpcProperties.getProcInfo() != NULL)
        {
            map<string, string> paramMap;
            DbiBindDataDef mapBindDataDef = sqlContextStp->rpcProperties.getMapBindDataDef(NullDynSt);
            string paramName, tmpStr;

            DBA_PROCPARAM_STP procParamDefPtr = sqlContextStp->rpcProperties.getProcInfo()->procParamDefPtr;

            pos += sqlContextStp->rpcName.length();

            while ((pos = sqlContextStp->sqlCmd.find_first_not_of(" \t\n,", pos)) != string::npos)
            {
                size_t endPos = pos;
                while (sqlContextStp->sqlCmd.at(endPos) == '\'')
                {
                    endPos = sqlContextStp->sqlCmd.find_first_of("'", endPos + 1) + 1;

                    if (endPos == sqlContextStp->sqlCmd.size())
                    {
                        endPos--;
                        break;
                    }
                }
                endPos = sqlContextStp->sqlCmd.find_first_of(" \t\n,", endPos);

                if (pos == endPos)
                {
                    break;
                }

                if (endPos == string::npos)
                {
                    tmpStr = sqlContextStp->sqlCmd.substr(pos);
                }
                else
                {
                    tmpStr = sqlContextStp->sqlCmd.substr(pos, endPos - pos);
                }

                if (bReplace)
                {
                    if (paramName.empty() && procParamDefPtr != nullptr)
                    {
                        paramName = procParamDefPtr[paramMap.size()].paramName;
                    }

                    if (tmpStr.at(0) == '@')
                    {
                        DdlGenVar *currVar = sqlContextStp->ddlGenVarHelperPtr->getVariable(tmpStr);

                        if (currVar)
                        {
                            string valueStr = currVar->getValue().empty() ? "NULL" : currVar->getValue();

                            paramMap.insert(pair<string, string>(paramName, valueStr));
                        }
                        pos++;
                    }
                    else
                    {
                        if (tmpStr.at(0) == '\'')
                        {
                            tmpStr = tmpStr.substr(1, tmpStr.length() - 2);
                        }
                        paramMap.insert(pair<string, string>(paramName, tmpStr));
                    }
                    bReplace = bSetProcByPos;

                    if (bReplace)
                    {
                        paramName.clear();
                        pos = endPos;
                    }
                    else
                    {
                        pos = sqlContextStp->sqlCmd.find("@", pos);
                    }
                }
                else
                {
                    paramName = tmpStr;
                    pos = sqlContextStp->sqlCmd.find_first_not_of("= \t", pos + paramName.length());
                    bReplace = true;
                }
            }

            if (paramMap.empty() == false || sqlContextStp->rpcProperties.m_applSessionCdPos != Null_Dynfld)
            {
                DBA_DYNST_ENUM inputEn;
                OBJECT_ENUM objEn;
                DBA_DYNFLD_STP inputDataStp;

                sqlContextStp->rpcProperties.getRequestEntity(inputEn, objEn, inputDataStp);
                
                sqlContextStp->sqlCmd = sqlContextStp->rpcName;

                for (auto bindDataIt = mapBindDataDef.bindData.begin(); bindDataIt != mapBindDataDef.bindData.end(); ++bindDataIt)
                {
                    auto paramIt = paramMap.find("@" + bindDataIt->second.m_columnName);

                    if (paramIt != paramMap.end())
                    {
                        if ((ret = DBA_SetDynFldFromString(sqlContextStp->inDateTimeStyleEn,
                                                           paramIt->second,
                                                           inputDataStp,
                                                           mapBindDataDef.getDynStPos(inputDataStp, bindDataIt->second))) != RET_SUCCEED)
                        {
                            DbaErrmsgInfosClass &msgStructSt = sqlContextStp->connHelperPtr->getConnection()->m_msgStructHeaderSt.getNewErrMsgInfoSt(FILEINFO);
                            msgStructSt.retCode              = ret;
                            msgStructSt.rdbmsMsgNb           = -1;
                            msgStructSt.msgString            = "Invalid conversion error for parameter " + paramIt->first; /* DLA - PMSTA-28017 - 180116 */
                            FREE_DYNST(inputDataStp, inputEn);
                            return ret;
                        }
                    }
                }

                sqlContextStp->bSetParamDone = true;
                DBI_SetProcParameters(*sqlContextStp->connHelperPtr->getConnection(),
                                      inputEn,
                                      inputDataStp,
                                      sqlContextStp->rpcProperties.getProcInfo(),
                                      objEn);

                FREE_DYNST(inputDataStp, inputEn);
            }
            else
            {
                if (bSetProcByPos == false && procParamDefPtr != nullptr)
                {
                    sqlContextStp->sqlCmd = sqlContextStp->rpcName + " ";
                    for (auto bindDataIt = mapBindDataDef.bindData.begin(); bindDataIt != mapBindDataDef.bindData.end(); ++bindDataIt)
                    {
                        map<string, string>::iterator paramIt;
                        paramIt = paramMap.find(bindDataIt->second.m_columnName);

                        if (bindDataIt != mapBindDataDef.bindData.begin())
                        {
                            sqlContextStp->sqlCmd += ", ";
                        }
                        if (paramIt != paramMap.end())
                        {
                            sqlContextStp->sqlCmd += paramIt->second;
                        }
                        else
                        {
                            sqlContextStp->sqlCmd += "NULL";
                        }
                    }

                    sqlContextStp->rpcName.clear();
                }
            }
        }
    }

    if (sqlContextStp->bFinSrvMode == false && 
        sqlContextStp->isTransactionNeeded() == true &&
        sqlContextStp->connHelperPtr->getConnection()->isInTransaction() == false)  /* PMSTA-31471 - LJE - 180525 */
    {
        sqlContextStp->connHelperPtr->beginTransaction();
    }

    switch (sqlContextStp->connHelperPtr->getConnection()->m_connectToRDBMS)
    {
        case Sybase:
            ret = SYB_ManagedSqlExec(sqlContextStp);
            break;

        case Oracle:
            ret = ORA_ManagedSqlExec(sqlContextStp);
            break;

        case QtHttp:
            ret = HTTP_ManagedSqlExec(sqlContextStp);
            break;

#ifdef NUODB_ENABLE
        case Nuodb:
            ret = NUODB_ManagedSqlExec(sqlContextStp);
            break;
#endif
        default:
            ret = DBI_GenericManagedSqlExec(sqlContextStp);
    }
    sqlContextStp->ddlGenContext.lastErrRetCode = (ret == RET_SUCCEED ? 0 : ret);

    if (status != NULL)
    {
        *status = locStatus;
    }

    sqlContextStp->connHelperPtr->getConnection()->setValidConnection(ret != RET_DBA_ERR_DBPROBLEM);

    if (sqlContextStp->bFinSrvMode == false &&
        sqlContextStp->isTransactionNeeded() == true &&
        sqlContextStp->scriptDdlGenPtr->bAutoCommit == true)
    {
        sqlContextStp->connHelperPtr->endTransaction(ret == RET_SUCCEED ? TRUE : FALSE);
    }
    
    /* PMSTA-42859 - JBC - 201207 : DB-Only Syncrho */
    if(ret == RET_SUCCEED && GEN_UseDispatcher() == false && sqlContextStp->sqlCmd.find("start_active_fusion_by") != string::npos)
    {
        const ID_T syncServerId = FUS_GetSyncServOrRequestId();
        FusionSynchronization fusionSynchro;
        fusionSynchro.waitUntilJobFinished(syncServerId);
    }

    return ret;
}

/************************************************************************
*   Function             : DBI_GetRpcInfoStp()
*
*   Description          :
*
*   Arguments            :
*   Functions call       :
*
*   Return               :
*
*************************************************************************/
bool DBI_GetRpcParamInfoStp(const std::string & rpcName, RpcProperties &rpcProperties)
{
    if (EV_AAAInstallLevel > 1)
    {
        return false;
    }

    rpcProperties = EV_RpcCollection.getRpcProperties(rpcName);

    return rpcProperties.getRpcName().empty() == false;
}

/************************************************************************
*   Function             : DBI_IsRpcProc()
*
*   Description          :
*
*   Arguments            :
*   Functions call       :
*
*   Return               :
*
*************************************************************************/
bool DBI_IsRpcProc(const std::string & rpcName)
{
    if (rpcName.empty() == false && rpcName[0] != '#')
    {
        RpcProperties rpcProperties;
        return DBI_GetRpcParamInfoStp(rpcName, rpcProperties);
    }

    return false;
}

/************************************************************************
*   Function             : DBI_SetProcParameters()
*
*   Description          : Set the necessary parameters for the request
*                          in the COMMAND structure
*
*   Arguments            : connectNo : the connection number
*                          inputSt   : the object request
*                          inputData : the input parameter structure
*                          procedure : a pointer on the chosen procedure
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : RET_SUCCEED            : if ok
*                          RET_DBA_ERR_ARGNOMATCH : if argument problem
*                          RET_DBA_ERR_SETPARAM   : if problem while
*                                                   binding fields
*
*   Last modif.          : PMSTA-26764 - 230317 - PMO : Core file generated
*
*************************************************************************/
RET_CODE DBI_SetProcParameters(DbiConnection &dbiConn, DBA_DYNST_ENUM inputSt, DBA_DYNFLD_STP inputData, DBA_PROC_STP procedure, OBJECT_ENUM  object, char udFlg)
{
    RET_CODE ret = RET_SUCCEED;

    if (procedure->server == FinServer)
    {
        RpcProperties rpcProperties;

        if (DBI_GetRpcParamInfoStp(procedure->procName, rpcProperties) &&
            rpcProperties.m_applSessionCdPos != Null_Dynfld &&
            IS_NULLFLD(inputData, rpcProperties.m_applSessionCdPos) == TRUE)
        {
            std::string applSessionCd = SYS_GetThreadApplSessionCd();

            if (applSessionCd.empty() == false)
            {
                SET_CODE(inputData, rpcProperties.m_applSessionCdPos, applSessionCd.c_str());
            }
            else
            {
                DbiConnectionHelper connHelper;
                if (connHelper.isValidAndInit()) /* Create needed appl_session */
                {
                    applSessionCd = SYS_GetThreadApplSessionCd();
                    SET_CODE(inputData, rpcProperties.m_applSessionCdPos, applSessionCd.c_str());
                }
                else
                {
                    return(RET_DBA_ERR_CONNOTFOUND);
                }
            }
        }
    }

    switch (dbiConn.m_connectToRDBMS)
    {
    case Sybase:
        if (object == NullEntity || procedure->server == FinServer)
        {
            ret = SYB_SetProcParameters(dynamic_cast<SybConnection&>(dbiConn), inputSt, inputData, procedure);
        }
        else
        {
            ret = SYB_SetInsUpdParameters(dynamic_cast<SybConnection&>(dbiConn), object, inputSt, inputData, procedure, udFlg);
        }
        break;

    case Oracle:
        if (object == NullEntity)
        {
            ret = ORA_SetProcParameters(dynamic_cast<OraConnection&>(dbiConn), inputSt, inputData, procedure);
        }
        else
        {
            ret = ORA_SetInsUpdProcParameters(dynamic_cast<OraConnection&>(dbiConn), object, inputSt, inputData, procedure, udFlg);
        }
        break;

    case QtHttp:
        ret = HTTP_SetProcParameters(dbiConn, inputSt, inputData, procedure);
        break;

    default:    // Avoid unexpected processing when the connection was freed
        MSG_SendMesg(FILEINFO, "Unexpected RDBMS");
        ret = RET_MEM_ERR_FREE;
        break;

    }

    dbiConn.getOutboxManager().addRecord(inputData, procedure); /* PMSTA-55668 - LJE - 240322 */

    return ret;
}

/************************************************************************
*   Function             : DBI_CopyNullFlagsAndLengthDynSt()
*
*   Description          : For each field, copy the null flag and string
*                          length informations in the bind structure.
*
*   Arguments            : connectNo : the connection number
*                          bindData  : the structure array used for binding
*                          dynStEnum : the dynamic structure enum
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : RET_SUCCEED            : if ok
*
*************************************************************************/
RET_CODE DBI_CopyNullFlagsAndLengthDynSt(DbiConnection& dbiCon, DBA_DYNFLD_STP bindData, DBA_DYNST_ENUM dynStEnum)
{
    RET_CODE ret = RET_SUCCEED;
    switch (dbiCon.m_connectToRDBMS)
    {
    case Sybase:
        ret =  SYB_CopyNullFlagsAndLengthDynSt(dbiCon, bindData, dynStEnum);
        break;
    case Oracle:
        /* normally no more used, directly assigned in binding and fetching functions */
        int      i;
        int      colNumber = GET_FLD_NBR(dynStEnum);

        for (i = 0; i<colNumber; i++)
        {
            if (IS_NULLFLD(bindData, i))
            {
                SET_NULL_FLD(bindData, i);
            }
        }
        break;
    }
    return ret;
}

/************************************************************************
*   Function             : DBI_CopyNullFlagsAndLength()
*
*   Description          : For specified field, copy the null flag and string
*                          length informations in the bind structure.
*
*   Arguments            : connectNo : the connection number
*                          bindData  : the structure array used for binding
*                          column : the index of the field
*                          type: the datatype of the field
*
*   Functions call       : None
*
*   Global var. modified : None
*
*   Return               : RET_SUCCEED            : if ok
*
*************************************************************************/
RET_CODE DBI_CopyNullFlagsAndLength(DbiConnection& dbiConn, DBA_DYNFLD_STP bindData, int column, DATATYPE_ENUM type)
{
    RET_CODE ret = RET_SUCCEED;
    switch (dbiConn.m_connectToRDBMS)
    {
        case Sybase:
            ret = SYB_CopyNullFlagsAndLength(dbiConn, bindData, column, type);
            break;
    }
    return(ret);
}

/************************************************************************
*   Function             : DBI_GetServerConnect()
*
*   Description          : Get ServerConnect depending of ApplServerName Appl Param
*
*   Arguments            :
*
*
*   Return               :
*
*
*************************************************************************/
RET_CODE DBI_GetServerConnect(DbiConnection& dbiConn,
                              ID_T       * pServId,
                              char       * pServName,
                              char       * pServDataBase,
                              FLAG_T     * pServFusFlg,
                              FLAG_T     * pServFinFlg,
                              FLAG_T     * pServDispFlg,
                              FLAG_T     * pServRepFlg,
                              SMALLINT_T * pConnTemp,
                              SMALLINT_T * pMaxFusion,
                              TINYINT_T  * pServStatEn,
                              ID_T       * pOpti_profile,
                              SMALLINT_T * pMin_connection,
                              INT_T      * pThreadCleanupInterval,
                              INT_T      * pReadTimeout,
                              INT_T      * pNmbServers)
{
    RET_CODE    ret = RET_SUCCEED;

    std::string serverName;
    ID_T        *servId                = nullptr;
    char        *servName              = nullptr;
    char        *servDataBase          = nullptr;
    FLAG_T      *servFusFlg            = nullptr;
    FLAG_T      *servFinFlg            = nullptr;
    FLAG_T      *servDispFlg           = nullptr;
    FLAG_T      *servRepFlg            = nullptr;
    SMALLINT_T  *connTemp              = nullptr;
    SMALLINT_T  *maxFusion             = nullptr;
    TINYINT_T   *servStatEn            = nullptr;
    ID_T        *opti_profile          = nullptr;
    SMALLINT_T  *min_connection        = nullptr;
    INT_T       *threadCleanupInterval = nullptr;
    INT_T       *readTimeout           = nullptr;
    INT_T       *nmbServers            = nullptr;

    GEN_GetApplInfo(ApplServerName, serverName);
    *pNmbServers = 0;

    RequestHelper requestHelper(&dbiConn);

    const AAALogger& sqlTraceLog = AAALogger::get(AAALogger::Logger::SqlTrace);
    if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
    {
        auto &sqlTrace = dbiConn.getSqlTrace();
        sqlTrace.m_procedure = "DynSql.GetServerConnect";
        sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
    }

    requestHelper.addNewParamCharPtr(serverName, String1000Type);
    requestHelper.setCommand("#EXEC get_all_server_connect_by_nm ?");

    requestHelper.addNewOutputData(IdType);
    requestHelper.getBindVariablePtr(servId);

    requestHelper.addNewOutputData(NameType);
    requestHelper.getBindVariablePtr(servName);

    requestHelper.addNewOutputData(SysnameType);
    requestHelper.getBindVariablePtr(servDataBase);

    requestHelper.addNewOutputData(FlagType);
    requestHelper.getBindVariablePtr(servFusFlg);

    requestHelper.addNewOutputData(FlagType);
    requestHelper.getBindVariablePtr(servFinFlg);

    requestHelper.addNewOutputData(FlagType);
    requestHelper.getBindVariablePtr(servDispFlg);

    requestHelper.addNewOutputData(FlagType);
    requestHelper.getBindVariablePtr(servRepFlg);

    requestHelper.addNewOutputData(SmallintType);
    requestHelper.getBindVariablePtr(connTemp);

    requestHelper.addNewOutputData(SmallintType);
    requestHelper.getBindVariablePtr(maxFusion);

    requestHelper.addNewOutputData(EnumType);
    requestHelper.getBindVariablePtr(servStatEn);

    requestHelper.addNewOutputData(IdType);
    requestHelper.getBindVariablePtr(opti_profile);

    requestHelper.addNewOutputData(SmallintType);
    requestHelper.getBindVariablePtr(min_connection);

    requestHelper.addNewOutputData(IntType);
    requestHelper.getBindVariablePtr(threadCleanupInterval);

    requestHelper.addNewOutputData(IntType);
    requestHelper.getBindVariablePtr(readTimeout);

    if ((ret = requestHelper.sendAndGetCommand()) == RET_SUCCEED)
    {
        *pServId                = *servId;
        strncpy(pServName, servName, SYSNAME_T_LEN);
        strncpy(pServDataBase, servDataBase, SYSNAME_T_LEN);
        *pServFusFlg            = *servFusFlg;
        *pServFinFlg            = *servFinFlg;
        *pServDispFlg           = *servDispFlg;
        *pServRepFlg            = *servRepFlg;
        *pConnTemp              = *connTemp;
        *pMaxFusion             = *maxFusion;
        *pServStatEn            = *servStatEn;
        *pOpti_profile          = *opti_profile;
        *pMin_connection        = *min_connection;
        *pThreadCleanupInterval = *threadCleanupInterval;
        *pReadTimeout           = *readTimeout;

        requestHelper.finishRequest();

        if (*pServDispFlg == 1)
        {
            string   sqlStr;

            requestHelper.addNewParamCharPtr(pServDataBase, String1000Type);

            if (EV_sqlFile != NULL || sqlTraceLog.isWarnEnabled())
            {
                auto &sqlTrace = dbiConn.getSqlTrace();
                sqlTrace.m_procedure = "DynSql.CountFusServer";
                sqlTrace.m_mode = DbiSqlTrace::Mode::Lang;
            }

            sqlStr = "select count(*) from server_connect_vw where database_c = ? and fusion_f = 1";

            requestHelper.setCommand(sqlStr);
            requestHelper.addNewOutputData(IntType);
            requestHelper.getBindVariablePtr(nmbServers);

            if ((ret = requestHelper.sendAndGetCommand()) == RET_SUCCEED)
            {
                *pNmbServers = *nmbServers;
                requestHelper.finishRequest();
            }
        }
    }

    return(ret);
}

/************************************************************************
*   Function             : DBI_ConfigureClientLibrary
*
*   Description          : Configure The database client libraries after first initialisation connection
*
*   Return               : RET_SUCCEED        : if no problem was detected
*
*   Creation Date        : PMSTA-51666 - FME - 2024-01-24
*   Last Modification    :
*
*************************************************************************/
RET_CODE DBI_ConfigureClientLibrary(int maxConnNbr)
{
    switch (EV_RdbmsVendor)
    {
    case Sybase:
        return SYB_ConfigureClientLibrary(maxConnNbr);

    default:
        break;
    }
    return RET_SUCCEED;
}

/************************************************************************
*   Function             : DBI_SetServerConnectApplInfo
*
*   Description          : 
*
*   Return               : RET_SUCCEED        : if no problem was detected
*
*   Last Modification    :
*
*************************************************************************/
RET_CODE DBI_SetServerConnectApplInfo(DbiConnection& dbiConn,
                                      int           *nmbServers,
                                      FLAG_T        *servDispFlg,
                                      FLAG_T        *servFusFlg)
{
    RET_CODE   ret = RET_SUCCEED;
    int        connZero = 0, connInt = 0;
    SMALLINT_T connTemp = 0, maxFusion = 0, min_connection = 0;
    NAME_T     servName;
    SYSNAME_T  servDataBase;
    FLAG_T     servFinFlg = 0, servRepFlg = 0, servStatEn = 0;
    ID_T       servId = 0, opti_profile = 0;
    INT_T      readTimeout = 0, threadCleanupInterval = 0;

    if (SYS_IsSrvMode() == TRUE) /* REF11026 - LJE - 050217 */
    {
        ret = DBI_GetServerConnect(dbiConn,
                                   &servId,
                                   servName,
                                   servDataBase,
                                   servFusFlg,
                                   &servFinFlg,
                                   servDispFlg,
                                   &servRepFlg,
                                   &connTemp,
                                   &maxFusion,
                                   &servStatEn,
                                   &opti_profile,
                                   &min_connection,
                                   &threadCleanupInterval,
                                   &readTimeout,
                                   nmbServers);

        connZero = 0;

        /*
         * BEGIN DVP138 - Allows two times more connections for
         * "clients->financial server" than for "financial server->Sybase server".
         */

        connInt = (int)connTemp * 2;
        /**** END DVP138 ***/
    }
    else
    {
        connInt = 200; /* PMSTA07393 - LJE - 090112 */
        connZero = 0;
    }
    
    DBI_ConfigureClientLibrary(connInt); /* PMSTA-51666 - FME - 2024-01-24 */

    if (ret == RET_SUCCEED)
    {
        if (GEN_SetApplInfo(ApplSqlSync, &connInt) != TRUE ||
            GEN_SetApplInfo(ApplFinSync, &connZero) != TRUE ||
            GEN_SetApplInfo(ApplSqlAsync, &connZero) != TRUE ||
            GEN_SetApplInfo(ApplFinAsync, &connZero) != TRUE ||
            GEN_SetApplInfo(ApplConnPoolReapTime, &threadCleanupInterval) != TRUE)
        {
            /* Free the established connection */
            dbiConn.setValidConnection(false);
            ret = RET_GEN_ERR_NOACTION;
        }
    }

    return ret;

}
/************************************************************************
*   Function             : DBI_ProcessAllAccessResults
*
*   Description          :
*
*   Last Modification    :
*
*************************************************************************/
RET_CODE DBI_ProcessAllAccessResults(DbiConnection&         dbiConn,
                                     int                    eltIndex,
                                     int                    maxRecInBuf,
                                     int                    ,
                                     DBA_ACCESS_STP         accessPtr,
                                     int *                  eltPos,
                                     DBA_DYNFLD_STP *       dataTab,
                                     DBA_ACTION_ENUM        actionArg,
                                     OBJECT_ENUM            objectArg,
                                     int *                  errStatusTab,
                                     const int              eltNbr,
                                     DBA_PROC_STP           procedureForDataTab)
{
    RET_CODE ret = RET_SUCCEED;

    switch (dbiConn.m_connectToRDBMS)
    {
    case Sybase:
        ret = SYB_ProcessAllAccessResults(dynamic_cast<SybConnection&>(dbiConn),
                                          eltIndex,
                                          maxRecInBuf,
                                          accessPtr,
                                          eltPos,
                                          dataTab,
                                          actionArg,
                                          objectArg,
                                          errStatusTab,
                                          eltNbr,
                                          procedureForDataTab);
        break;

    case Oracle:
        ret = ORA_ProcessAllAccessResults(dbiConn,
            eltIndex,
            maxRecInBuf,
            accessPtr,
            eltPos,
            dataTab,
            actionArg,
            objectArg,
            errStatusTab,
            eltNbr,
            procedureForDataTab);
        dbiConn.releaseCommand();
        break;
    }

    /* PMSTA-30586 - DLA - 180404 */
    dbiConn.setMultiAccessLangRequest(false);

    return ret;
}

/************************************************************************
*   Function             : DBI_PrintSqlReqParamEqualValue
*
*   Description          :
*
*
*   Last Modification    :
*
*************************************************************************/
std::string DBI_PrintSqlReqParamEqualValue(const std::string & paramName, const std::string & paramValue)
{
    std::string ret;
    switch (EV_RdbmsVendor)
    {
        case Sybase:
            ret = paramName + "=" + paramValue;
            break;
        case Oracle:
            ret = paramValue;
            break;
    }
    return ret;
}


/************************************************************************
*   Function             : DBI_PrintSqlReqHeader()
*
*   Description          :
*
*   Arguments            :
*
*   Global var. modified : None
*
*   Return               :
*
*   Last modif.          :
*
*************************************************************************/
void DBI_PrintSqlReqHeader( std::string &   recBuffer,
                            int             seq,
                            DBA_DYNFLD_STP  data,
                            DBA_PROC_STP    procedure,
                            OBJECT_ENUM     object,
                            int             maxRecInBuff,
                            bool &          bFirst)
{
    DICT_ATTRIB_STP attribute = nullptr;
    std::string     szTemp, assignPart;
    int             j = 0;
    bool            sqlVariableDeclared = false;    /* For Oracle, after a DECLARE a BEGIN is expected */

    while (procedure->procParamDefPtr != NULL &&
           procedure->procParamDefPtr[j].fldNbrPtr != UNUSED)
    {
        /* PMSTA-34344 - LJE - 190524 */
        if (procedure->procParamDefPtr[j].procParamTypeEn >= ProcParamType_Output)
        {
            for (int i = 0; i < maxRecInBuff; i++)
            {
                attribute = DBA_GetDictAttribSt(object, *procedure->procParamDefPtr[j].fldNbrPtr);
                switch (EV_RdbmsVendor)
                {
                    case Sybase:
                        if (i == 0)
                        {
                            SYS_StringFormat(szTemp, "\ndeclare %s%d%d %s \n",
                                             procedure->procParamDefPtr[j].paramName,
                                             seq,
                                             *procedure->procParamDefPtr[j].fldNbrPtr,
                                             DBA_GetDictDataTpStp(attribute->dataTpProgN)->sqlName);
                            recBuffer += szTemp;


                            // Actually just done for time_stamp but it's possible to remove the test and add cases for all fields (to check)
                            if (strcmp(procedure->procParamDefPtr[j].paramName, "@time_stamp") == 0 && !IS_NULLFLD(data, *procedure->procParamDefPtr[j].fldNbrPtr))
                            {
                                SYS_StringFormat(szTemp, "select %s%d%d = " szFormatTimeStamp" \n",
                                                 procedure->procParamDefPtr[j].paramName,
                                                 seq,
                                                 *procedure->procParamDefPtr[j].fldNbrPtr,
                                                 GET_TIMESTAMP(data, *procedure->procParamDefPtr[j].fldNbrPtr));
                                recBuffer += szTemp;
                            }
                        }
                        break;

                    case Oracle:
                        break;
                }
            }
        }
        j++;
    }

    switch (EV_RdbmsVendor)
    {
        case Sybase:
            break;
        case Oracle:
            if (bFirst || true == sqlVariableDeclared)                                  /* PMSTA-21641 - 071115 - PMO */
            {
                recBuffer += DBI_GetSqlStatementBegin() + assignPart;
            }
            break;
    }

    if (bFirst)
    {
        bFirst = false;
    }
}
/************************************************************************
*   Function             : DBI_PrintSqlReqBodyStart
*
*   Description          :
*
*
*   Last Modification    :
*
*************************************************************************/
void DBI_PrintSqlReqBodyStart(std::string& recBuffer, DBA_PROC_STP procedure)
{
    std::string szTemp;

    switch (EV_RdbmsVendor)
    {
    case Sybase:
        SYS_StringFormat(szTemp, "exec %s ", procedure->procName);
        recBuffer += szTemp;
        break;
    case Oracle:
        SYS_StringFormat(szTemp, "%s(", procedure->procName);
        recBuffer += szTemp;
        break;
    }
}

/************************************************************************
*   Function             : DBI_GetSqlStatementSeparator()
*
*   Description          : Return if any, the character used for separing each SQL statement
*
*   Arguments            : None
*
*   Global var. modified : None
*
*   Return               :
*
*   Last modif.          : PMSTA-21641 - 071115 - PMO : GUI Oracle Fusion fails
*
*   Last modif.          :
*
*************************************************************************/
std::string DBI_GetSqlStatementSeparator()
{
    return DdlGenDbi::endOfCmd(EV_RdbmsVendor);
}


/************************************************************************
*   Function             : DBI_GetSqlStatementBegin()
*
*   Description          : Return if any, the SQL keyword for starting a block
*
*   Arguments            : None
*
*   Global var. modified : None
*
*   Return               : If any, the SQL keyword for starting a block
*
*   Last modif.          : PMSTA-21641 - 071115 - PMO : GUI Oracle Fusion fails
*
*   Last modif.          :
*
*************************************************************************/
std::string DBI_GetSqlStatementBegin()
{
    std::string ret;

    switch (EV_RdbmsVendor)
    {
        case Sybase:
        case MSSql:
        case PostgreSQL:
        case Nuodb:
            break;

        case Oracle:
            ret = "begin\n";
            break;

        default:
            SYS_BreakOnDebug();
    }

    return ret;
}


/************************************************************************
*   Function             : DBI_GetSqlStatementEnd()
*
*   Description          : Return if any, the SQL keyword for terminating a block
*
*   Arguments            : None
*
*   Global var. modified : None
*
*   Return               : If any, the SQL keyword for terminating a block
*
*   Last modif.          : PMSTA-21641 - 071115 - PMO : GUI Oracle Fusion fails
*
*   Last modif.          :
*
*************************************************************************/
std::string DBI_GetSqlStatementEnd()
{
    std::string ret;

    switch (EV_RdbmsVendor)
    {
        case Sybase:
        case MSSql:
        case Nuodb:
            break;

        case Oracle:
            ret = "end;\n";
            break;

        case PostgreSQL:
            ret = ";";
            break;

        default:
            SYS_BreakOnDebug();

    }

    return ret;
}

/************************************************************************
*   Function             : to_stringSql()
*
*   Description          : Format an bool for using into a SQL statement
*
*   Arguments            : b   bool to convert
*
*   Global var. modified : None
*
*   Return               : bool formatted
*
*   Last modif.          : PMSTA-20159 - TEB - 151110
*
*   Last modif.          :
*
*************************************************************************/
std::string to_stringSql(const bool b)
{
    std::string ret;

    SYS_StringFormat(ret, "%d", int(b));

    return ret;
}

/************************************************************************
*   Function             : to_stringSql()
*
*   Description          : Format an ID for using into a SQL statement
*
*   Arguments            : id   ID to convert
*
*   Global var. modified : None
*
*   Return               : ID formatted
*
*   Last modif.          : PMSTA-21641 - 071115 - PMO : GUI Oracle Fusion fails
*
*   Last modif.          :
*
*************************************************************************/
std::string to_stringSql(const ID_T id)
{
    std::string ret;

    SYS_StringFormat(ret, "%" szFormatId, id);

    return ret;
}


void DBI_PrintSqlReqBodyEnd(std::string& recBuffer)
{
    switch (EV_RdbmsVendor)
    {
    case Sybase:
        break;
    case Oracle:
        recBuffer += ");\n";
        break;
    }
}


void DBI_PrintSqlReqFooter(std::string& recBuffer, bool &bFirst)
{
    switch (EV_RdbmsVendor)
    {
    case Sybase:
        break;
    case Oracle:
        bFirst = true;
        recBuffer += DBI_GetSqlStatementEnd();
        break;
    }
}

void DBI_PrintSqlReqParam(std::string&  recBuffer, std::string&  strData, int seq, DBA_PROC_STP procedure, int fldNbr, DATATYPE_ENUM dataType, int* posParam, DBA_DYNFLD_STP rec, RequestHelper &requestHelper)
{
    bool        bFound = false;
    std::string szTemp;

    if (strData.empty() == false &&
        (GET_CTYPE(dataType) == CharPtrCType || GET_CTYPE(dataType) == TextPtrCType ||
        GET_CTYPE(dataType) == UniCharPtrCType || GET_CTYPE(dataType) == UniTextPtrCType))
    {
        size_t start_pos = 1;
        while ((start_pos = strData.find("'", start_pos)) != std::string::npos && start_pos != strData.length() - 1)
        {
            strData.replace(start_pos, 1, "''");
            start_pos += 2;
        }
    }

    int         j = 0;

    /* PMSTA-34344 - LJE - 190524 */
    while (procedure->procParamDefPtr != nullptr &&
        procedure->procParamDefPtr[j].fldNbrPtr != nullptr &&
        bFound == false)
    {
        if ((fldNbr == *procedure->procParamDefPtr[j].fldNbrPtr) ||
            ((procedure->inputDynStPtr != nullptr) &&                       /*  HFI-PMSTA-47459-221012  Specific code when remapIdIdxPtr is defined: operation seems to be the only existing case   */
             (*procedure->inputDynStPtr == ExtOp) &&
             (procedure->remapIdIdxPtr != nullptr) &&
             (0 == fldNbr) &&
             (*procedure->remapIdIdxPtr == *procedure->procParamDefPtr[j].fldNbrPtr)))
        {
            if (procedure->procParamDefPtr[j].procParamTypeEn >= ProcParamType_Output)
            {
                switch (EV_RdbmsVendor)
                {
                    case Sybase:
                        SYS_StringFormat(szTemp, "%s%d%d output", procedure->procParamDefPtr[j].paramName, seq, *procedure->procParamDefPtr[j].fldNbrPtr);
                        break;
                    case Oracle:
                        (*posParam)++;
                        SYS_StringFormat(szTemp, "?");
                        if (procedure->procParamDefPtr[j].procParamTypeEn == ProcParamType_Output)
                        {
                            auto dbiInOutData = requestHelper.addNewParam(&(rec[*procedure->procParamDefPtr[j].fldNbrPtr]), false);
                            dbiInOutData->m_bOutput = true;
                        }
                        else /* indexed */
                        {
                            COPY_DYNFLD(rec, GET_DYNSTENUM(rec), *procedure->procParamDefPtr[j].outputFldNbrPtr, rec, GET_DYNSTENUM(rec), *procedure->procParamDefPtr[j].fldNbrPtr);
                            auto dbiInOutData = requestHelper.addNewParam(&(rec[*procedure->procParamDefPtr[j].outputFldNbrPtr]), false);
                            dbiInOutData->m_bOutput = true;
                        }
                        break;
                }
                recBuffer += szTemp;
            }
            bFound = true;
        }
        j++;
    }
    if (szTemp.empty())
    {
        recBuffer += strData;
    }
}

/******************************************************************************************
*   Function             : DBI_ReadFinFctResults()
*
*   Description          : Retrieve format element information, data descrip-
*                          tion and data rows returned by Open Server after a
*                          call to Financial Function (Valorisation, ...).
*
*   Description of retrieved data :
*
*''First block'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
*
*                  int             int              int
*           --------------------------------------------------
*           | Nb of Fmt Elt | Nb of Data Set | Fct Result Id |
*           --------------------------------------------------
*
*''Second block : format elements''''''''''''''''''''''''''''''''''''''''''''''
*
*           --------------------------------------------------------
*    x      | Format Id | Fmt Elt Rank | Data Set Idx | Column Idx |   --> dyn. struct FmtEltDef
*  rows     --------------------------------------------------------
*           |    ...    |      ...     |     ...      |     ...    |
*           --------------------------------------------------------
*
*''First block of first data set'''''''''''''''''''''''''''''''''''''''''''''''
*
*           -----------------------
*           | Column Nb | Rows Nb |
*           -----------------------
*
*''Second block of first data set : columns description''''''''''''''''''''''''
*
*           --------------------------------------------------------------------------------
*           | Column Nb | Data type | Ref. Key Idx | Ref. Key Nb | Ref. Key Entity dict_id | --> dyn. struct DataDef
*           --------------------------------------------------------------------------------
*           |    ...    |     ...   |      ...     |      ...    |           ...           |
*           --------------------------------------------------------------------------------
*
*''Third block of first data set : data''''''''''''''''''''''''''''''''''''''''
*
*           -----------------------------------------------------------------------..................
*           |    ...    |      ...     |      ...     |     ...   |  ...  |        ..................
*           -----------------------------------------------------------------------..................
*           |    ...    |      ...     |      ...     |     ...   |  ...  |        ..................
*           -----------------------------------------------------------------------..................
*           |    ...    |      ...     |      ...     |     ...   |  ...  |        ..................
*           -----------------------------------------------------------------------..................
*           |    ...    |      ...     |      ...     |     ...   |  ...  |        ..................
*           -----------------------------------------------------------------------..................
*           |    ...    |      ...     |      ...     |     ...   |  ...  |        ..................
*           -----------------------------------------------------------------------..................
*
*''First block of second data set if any'''''''''''''''''''''''''''''''''''''''
*
*   cf "First block of first data set"
*
*   ....
*   ....
*   ....
*   ....
*   ....
*
****************************************************************************************************************
*
*   Arguments            : connectNo  : a connection number in the connection list
*                          dataStruct : pointer addres on a DBA_DATARESULT_ST
*                                       structure (NOT ALLOCATED).
*
*
*   Return               : RET_SUCCEED                       : if ok
*                          RET_GEN_INFO_NODATA               : if no available data
*                          RET_DBA_ERR_DIALOG                : if disconnection or problem while
*                                                              reading data set
*                          RET_MEM_ERR_ALLOC                 : if memory allocation failed
*                          RET_DBA_ERR_SYBBIND               : if problem while binding data
*                          RET_ERR_DBA_NO_FORMAT_FOR_FIN_FCT : if no formats found for financial function
*
*   Creation Date        : Oct.  94 - PEC
*   Last Modification    : 29.05.96 - PEC - Ref.: DVP056+.
*                          16.10.96 - PEC - Ref.: DVP172 - Portage NT (cf #ifdef NT).
*                        : ROI - 970312 - DVP375
*                          27.05.98 - GRD - Ref.: REF2165. Allow 64Ko size scripts.
*                          04.02.00 - GRD - Ref.: REF4204.
*                          15.01.01 - GRD - Ref.: REF4336.
*                          REF7264 - 0201225 - PMO : Compilation errors and warnings with C++ compiler
*                          REF11780 - 100406 - PMO : Implementation of the Sybase timestamp field
*                          PMSTA-15145 - 171012 - PMO : NQA : display of technical messages in GUI error log when running Order List
*                          PMSTA-16443 - 230713 - PMO : Add confirmation-to-continue messages in case not enough free memory is available for the GUI when loading data from a financial server
*                          PMSTA-17133 - 051113 - PMO : Many compilation warnings in C code especially " Converting a 64-bit type value to "int" causes truncation."
*                          PMSTA-30419 - 050318 - PMO : Order list/operation list function ends with �server dialogue error� in GUI
*
*******************************************************************************************/
RET_CODE _DBI_ReadFinFctResults(DbiConnection& dbiConn, DBA_DATARESULT_STP & dataResult)
{
    MemoryPool          mp;                     /* PMSTA-30419 - 050318 - PMO */
    DBA_DYNFLD_STP      ptr             = nullptr;
    DBA_DYNFLD_STP      ptrDef          = nullptr;
    int                 totColumns      = 0;
    int                 fmtDescrIndex   = 0;
    int                 currDataSet     = 0;
    int                 i               = 0;
    DATATYPE_ENUM       fieldType;

    /* Allocation of structure DBA_DATARESULT_ST (data head) */
    dataResult = (DBA_DATARESULT_STP) mp.calloc(FILEINFO, 1, sizeof(DBA_DATARESULT_ST));

    /* prepare received data */
    if (dbiConn.prepareReceivedData() == false)
    {
        return(RET_DBA_ERR_NO_FORMAT_FOR_FIN_FCT);
    }

    /* Prepare the read of format_element number and data set number informations */

    dbiConn.colBind(1, IntType, "data_set_nb", &dataResult->dataSetNb, 0, nullptr, nullptr, false, nullptr, nullptr);
    dbiConn.colBind(2, IntType, "fmt_elt_nb", &dataResult->fmtEltNb, 0, nullptr, nullptr, false, nullptr, nullptr);
    dbiConn.colBind(3, IdType, "fct_res_id", &dataResult->fctResId, 0, nullptr, nullptr, false, nullptr, nullptr);

    /* Fetch informations */
    while (dbiConn.fetch() == RET_SUCCEED);

    /* If no format_element if given by Open Server */
    if (dataResult->fmtEltNb <= 0)
    {
        return(RET_DBA_ERR_NO_FORMAT_FOR_FIN_FCT);
    }

    /* Check the presence of next result set (format_elements data) */
    if (dbiConn.getNextResultSet() != RET_SUCCEED)
    {
        return(RET_DBA_ERR_DIALOG);
    }

    /* Allocate FmtEltDef structures to store format_elements informations */
    dataResult->fmtEltDef = ALLOC_DYNSTTAB(FmtEltDef, dataResult->fmtEltNb);

    /* Test memory allocation */
    if (dataResult->fmtEltDef == NULL)
    {
        return(RET_MEM_ERR_ALLOC);
    }

    mp.owner(static_cast<void *>(dataResult->fmtEltDef));   // Do a normal free / PMSTA-30419 - 050318 - PMO

    /* Allocate data set structures DBA_DATASET_ST (1 structure per set) */
    dataResult->dataSetStTab = (DBA_DATASET_STP)CALLOC(dataResult->dataSetNb, sizeof(DBA_DATASET_ST));

    /* Test memory allocation */
    if (dataResult->dataSetStTab == NULL)
    {
        return(RET_MEM_ERR_ALLOC);
    }
    else /* PMSTA-16443 - 230713 - PMO */
    {
        mp.owner(static_cast<void *>(dataResult->dataSetStTab));   // Do a normal free / PMSTA-30419 - 050318 - PMO

        for (i = 0; i < dataResult->dataSetNb; i++)
            dataResult->dataSetStTab[i].entity = NullEntity;	/* DVP375 */
    }

    /**** READ SECOND DATA RESULT : FORMAT ELEMENTS ****/

    { /* Allocate the bind structure used to read format_elements data */
        MemoryPool          mp2;                                                    /* PMSTA-30419 - 050318 - PMO */
        DBA_DYNFLD_STP      bindFmtEltDef = mp2.allocDynst(FILEINFO, FmtEltDef);    /* PMSTA-30419 - 050318 - PMO */

        /* Prepare the read of format_elements */
        if (dbiConn.bindRecvDynSt(FmtEltDef, bindFmtEltDef) != RET_SUCCEED)
        {
            return(RET_DBA_ERR_SYBBIND);
        }

        /* Read format_elements and fill dataResult->fmtEltDef array */
        for (i = 0; i<dataResult->fmtEltNb; i++)
        {
            ptr = &dataResult->fmtEltDef[GET_FLD_NBR(FmtEltDef) * i];

            bool memoryOk = dbiConn.fetch() == RET_SUCCEED;

            if (memoryOk)                                                           /* PMSTA-16443 - 230713 - PMO */
            {
                dbiConn.copyNullFlagsAndLengthDynSt(bindFmtEltDef, FmtEltDef);
                memoryOk = COPY_DYNST(ptr, bindFmtEltDef, FmtEltDef) == TRUE;       /* PMSTA-16443 - 230713 - PMO */
            }

            if (memoryOk == false)                                                  /* PMSTA-16443 - 230713 - PMO */
            {
                DBA_FreeNullFlagsAndLength(dbiConn);
                return(RET_DBA_ERR_DIALOG);
            }
        }

        while (dbiConn.fetch() == RET_SUCCEED);

        DBA_FreeNullFlagsAndLength(dbiConn);
    }

    /* For each data set */
    for (int cpt = 0; cpt<dataResult->dataSetNb; cpt++)
    {
        /* Check the presence of next result set (column number and rows number for data) */
        if (dbiConn.getNextResultSet() != RET_SUCCEED)
        {
            return(RET_DBA_ERR_DIALOG);
        }

        { /* Prepare the read of column number and rows number informations */
            int bindEntity     = 0;
            int addedEntityFlg = FALSE;
            DICT_T entityDictId = 0;

            dbiConn.colBind(1, IntType, string(), &addedEntityFlg, 0, nullptr, nullptr, false, nullptr, nullptr);
            dbiConn.colBind(2, IntType, string(), &(dataResult->dataSetStTab[cpt].colNb), 0, nullptr, nullptr, false, nullptr, nullptr);
            dbiConn.colBind(3, IntType, string(), &bindEntity, 0, nullptr, nullptr, false, nullptr, nullptr); /* PMSTA08801 - DDV - 091126 */
            dbiConn.colBind(4, IntType, string(), &(dataResult->dataSetStTab[cpt].rowNb), 0, nullptr, nullptr, false, nullptr, nullptr);
            dbiConn.colBind(5, DictType, string(), &entityDictId, 0, nullptr, nullptr, false, nullptr, nullptr);

            /* Read the data */
            while (dbiConn.fetch() == RET_SUCCEED);

            dataResult->dataSetStTab[cpt].entity = bindEntity;
            dataResult->dataSetStTab[cpt].addedEntityFlg = (FLAG_T)addedEntityFlg;
        }

        /* Check the presence of next result set (data description) */
        if (dbiConn.getNextResultSet() != RET_SUCCEED)
        {
            return(RET_DBA_ERR_DIALOG);
        }

        /* Allocate data description structures array */
        dataResult->dataSetStTab[cpt].dataDef = ALLOC_DYNSTTAB(DataDef, dataResult->dataSetStTab[cpt].colNb);

        /* Verify memory allocation */
        if (dataResult->dataSetStTab[cpt].dataDef == NULL)
        {
            dbiConn.cancelDbRequest(COMMAND_LEVEL, CANCEL_ALL);
            return(RET_MEM_ERR_ALLOC);
        }

        int newColNb = 0;
        { /* For allocate data description array if columns will be added to initial data columns */
            MemoryPool          mp2;                                                    /* PMSTA-30419 - 050318 - PMO */
            DBA_DYNFLD_STP *    newDataDef  = nullptr;                                  /* PMSTA-30419 - 050318 - PMO */

            { /* Allocate the bind structure used to read format_elements data */
                MemoryPool          mp3;                                                    /* PMSTA-30419 - 050318 - PMO */
                DBA_DYNFLD_STP      bindDataDef = mp3.allocDynst(FILEINFO, DataDef);        /* PMSTA-30419 - 050318 - PMO */

                /* Prepare the read of format_elements */
                if (dbiConn.bindRecvDynSt(DataDef, bindDataDef) != RET_SUCCEED)
                {
                    return(RET_MEM_ERR_ALLOC);
                }

                /* Allocate data description array if columns will be added to initial data columns */
                newDataDef = (DBA_DYNFLD_STP*)mp2.calloc(FILEINFO, dataResult->dataSetStTab[cpt].colNb, sizeof(DBA_DYNFLD_STP));


                /* For each row of data columns description */
                for (i = 0; i<dataResult->dataSetStTab[cpt].colNb; i++)
                {
                    ptr = &dataResult->dataSetStTab[cpt].dataDef[GET_FLD_NBR(DataDef) * i];

                    if (dbiConn.fetch() != RET_SUCCEED)
                    {
                        return(RET_DBA_ERR_DIALOG);
                    }

                    dbiConn.copyNullFlagsAndLengthDynSt(bindDataDef, DataDef);          /*  HFI-PMSTA-24154-160831  flagMask no more initialised    */
                    COPY_DYNST(ptr, bindDataDef, DataDef);

                    /* If we are on a data column concerning by a classif (list_id) */
                    if (EV_TestNewScpt == FALSE && GET_ID(bindDataDef, DataDef_ClassifId) != 0 && GET_INT(bindDataDef, DataDef_Datatype) == IdType)
                    {
                        if ((newDataDef[newColNb] = ALLOC_DYNST(DataDef)) == NULL)
                        {
                            return(RET_MEM_ERR_ALLOC);
                        }

                        /* Set all necessary informations for the new column */
                        SET_INT(newDataDef[newColNb], DataDef_ColNum, dataResult->dataSetStTab[cpt].colNb + newColNb + 1);
                        SET_INT(newDataDef[newColNb], DataDef_Datatype, CodeType);
                        SET_INT(newDataDef[newColNb], DataDef_RefKeyIndex, i + 1);
                        SET_INT(newDataDef[newColNb], DataDef_RefKeyNbr, 1);

                        DICT_T listDictId = 0;
                        DBA_GetDictId(List, &listDictId);
                        SET_DICT(newDataDef[newColNb], DataDef_RefKeyEntDictId, listDictId); /* DLA - REF9089 - 030508 */

                        SET_DICT(newDataDef[newColNb], DataDef_ClassifId, GET_ID(bindDataDef, DataDef_ClassifId)); /* DLA - REF9089 - 030508 */
                        SET_INT(newDataDef[newColNb], DataDef_SortCol, GET_INT(bindDataDef, DataDef_SortCol));

                        SET_NULL_ID(ptr, DataDef_ClassifId);
                        SET_NULL_INT(ptr, DataDef_SortCol);

                        /* Replace ColIndex field in Formats Descr. with the new colNum for list_name */
                        currDataSet = TRUE;
                        fmtDescrIndex = 0;

                        while (currDataSet == TRUE)
                        {
                            ptr = &dataResult->fmtEltDef[GET_FLD_NBR(FmtEltDef) * fmtDescrIndex];

                            /* If the format element is not in the current data set */
                            if (GET_INT(ptr, FmtEltDef_DataSetIndex) != cpt + 1 || fmtDescrIndex > dataResult->fmtEltNb)
                            {
                                currDataSet = FALSE;
                                continue;
                            }

                            /* If the current Fmt Elt refers to the column (list_id) to replace */
                            if (GET_INT(ptr, FmtEltDef_ColIndex) == i + 1)
                                SET_INT(ptr, FmtEltDef_ColIndex, dataResult->dataSetStTab[cpt].colNb + newColNb + 1);

                            ++fmtDescrIndex;
                        }

                        ++newColNb;
                        continue;
                    }

                    /***** TEMPORARY REMOVED ***** (PEN) ****/
                    /* If we are on a data column representing an Enum Value */
#ifdef AAADEBUG
                    if (TLS_Return(0) && dataDefDatatype == EnumType)/*  || dataDefDatatype == FlagType) */
                    {
                        if ((newDataDef[newColNb] = ALLOC_DYNST(DataDef)) == NULL)
                        {
                            return(RET_MEM_ERR_ALLOC);
                        }

                        SET_INT(newDataDef[newColNb], DataDef_ColNum, dataResult->dataSetStTab[cpt].colNb + newColNb + 1);
                        SET_INT(newDataDef[newColNb], DataDef_Datatype, CodeType);
                        SET_INT(newDataDef[newColNb], DataDef_SortCol, i + 1);

                        SET_NULL_INT(ptr, DataDef_SortCol);

                        /* Replace ColIndex field in Formats Descr. with the new colNum for the Enum or Flag */
                        currDataSet = TRUE;
                        fmtDescrIndex = 0;

                        while (currDataSet == TRUE)
                        {
                            ptr = &dataResult->fmtEltDef[GET_FLD_NBR(FmtEltDef) * fmtDescrIndex];

                            /* If the format element is not in the current data set */
                            if (GET_INT(ptr, FmtEltDef_DataSetIndex) != cpt + 1 || fmtDescrIndex > dataResult->fmtEltNb)
                            {
                                currDataSet = FALSE;
                                continue;
                            }

                            /* If the current Fmt Elt refers to the column (enum) to replace */
                            if (GET_INT(ptr, FmtEltDef_ColIndex) == i + 1)
                                SET_INT(ptr, FmtEltDef_ColIndex, dataResult->dataSetStTab[cpt].colNb + newColNb + 1);

                            ++fmtDescrIndex;
                        }

                        ++newColNb;
                        continue;
                    }
#endif
                }

                while (dbiConn.fetch() == RET_SUCCEED);
            }

            if (newColNb > 0)
            {
                /* REALLOCATE colNb + newColNb dynamic structures DataDef and add new columns */

                dataResult->dataSetStTab[cpt].dataDef = REALLOC_DYNSTTAB(dataResult->dataSetStTab[cpt].dataDef,  /* REF8844 - LJE - 030402 */
                                                                         DataDef,
                                                                         (dataResult->dataSetStTab[cpt].colNb + newColNb));

                /* Avoid crash PMSTA-16443 - 230713 - PMO */
                if (NULL == dataResult->dataSetStTab[cpt].dataDef)
                {
                    return RET_MEM_ERR_ALLOC;
                }

                for (int idx = 0; idx < newColNb; idx++)
                {
                    ptrDef = &dataResult->dataSetStTab[cpt].dataDef[GET_FLD_NBR(DataDef) *
                        (dataResult->dataSetStTab[cpt].colNb + idx)];

                    /* PMSTA-16443 - 230713 - PMO */
                    if (FALSE == COPY_DYNST(ptrDef, newDataDef[idx], DataDef))
                    {
                        FREE(dataResult->dataSetStTab[cpt].dataDef);
                        FREE_DYNST(newDataDef[idx], DataDef);
                        return RET_MEM_ERR_ALLOC;
                    }

                    FREE_DYNST(newDataDef[idx], DataDef);
                }
            }
        }

        /* Check the presence of next result set (data) */
        if (dbiConn.getNextResultSet() != RET_SUCCEED)
        {
            /* SQL dump processing handling of empty data block PMSTA-15145 - 171012 - PMO */
            if (dataResult->dataSetStTab[cpt].rowNb == 0 && dataResult->dataSetNb == cpt + 1)
            {
                continue;
            }

            FREE(dataResult->dataSetStTab[cpt].dataDef);
            return(RET_DBA_ERR_DIALOG);
        }

        /* If no data are available for the current data set */
        if (dataResult->dataSetStTab[cpt].rowNb == 0)
        {
            while (dbiConn.fetch() == RET_SUCCEED);
            continue;
        }

        /* totColumns = fields sent by Open Server + newly created fields (list_name, Permitted Values string) */
        totColumns = dataResult->dataSetStTab[cpt].colNb + newColNb;

        /* Allocate current data set array for data */


        /* PMSTA-16443 - 230713 - PMO
        * Handling of the memory threshold
        */
        bool            bContinue = true;
        size_t          memoryThreshold = SYS_ComputeNextMemoryThreshold(1);
        const size_t    memoryMaxK = SYS_GetEnvSizeOrDefValue("AAAMEMMAXALLOC", OS_GetLimitMemory());

        if (memoryThreshold > 0 && memoryMaxK > 0)
        {
            size_t currentMemoryAllocation = DBA_GetDataSegmentSize();
            size_t nextMemoryAllocation = DICT_GetAllocKbSizeDynStWithoutDefTabAlloc(totColumns, dataResult->dataSetStTab[cpt].rowNb);

            if (memoryThreshold > 0 && currentMemoryAllocation + nextMemoryAllocation > memoryThreshold)
            {
                char szMsg[192];    /* Buffer for an error message */

                /* Format and log an error message */
                sprintf(szMsg,
                        "Memory will be nearly full (%dK) and %d records will be loaded. Instability or crash may occur.",
                        int(nextMemoryAllocation + DBA_GetDataSegmentSize()),
                        dataResult->dataSetStTab[cpt].rowNb);

                MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, szMsg);

                if (NULL != DBA_WarningMessageBox)
                {
                    sprintf(szMsg,
                            "Memory will be nearly full (%d%%) and %d records will be loaded. Instability or crash may occur. Do you want to continue?",
                            int((100.0 * (double(nextMemoryAllocation + DBA_GetDataSegmentSize()) / double(memoryMaxK)))),
                            dataResult->dataSetStTab[cpt].rowNb);

                    bContinue = DBA_WarningMessageBox(szMsg);
                }

                memoryThreshold = SYS_ComputeNextMemoryThreshold(memoryThreshold);
            }
        }

        if (true == bContinue)
        {
            /* REF8844 - LJE - 030331 */
            dataResult->dataSetStTab[cpt].data = ALLOC_DYNSTTAB_WITHOUTDEF(totColumns, dataResult->dataSetStTab[cpt].rowNb);
        }

        /* Verify memory allocation */
        if (dataResult->dataSetStTab[cpt].data == NULL)
        {
            FREE(dataResult->dataSetStTab[cpt].dataDef);
            return(RET_MEM_ERR_ALLOC);
        }

        /* Allocate fields used for binding results */
        MemoryPool mp4;                                                     /* PMSTA-30419 - 050318 - PMO */

        /* REF8844 - LJE - 030331 */
        DBA_DYNFLD_STP  bindFld    = ALLOC_DYNST_WITHOUTDEF(dataResult->dataSetStTab[cpt].colNb);                         /* REF8844 - LJE - 030331 */
        DBI_SMALLINT *  nullData   = (DBI_SMALLINT *)CALLOC(dataResult->dataSetStTab[cpt].colNb, sizeof(DBI_SMALLINT));   /* REF7264 - PMO */
        DBI_INT *       dataLength = (DBI_INT *)     CALLOC(dataResult->dataSetStTab[cpt].colNb, sizeof(DBI_INT));        /* REF7264 - PMO */

        /* PMSTA-30419 - 050318 - PMO */
        mp4.owner(static_cast<void *>(bindFld));
        mp4.owner(nullData);
        mp4.owner(dataLength);

        if (bindFld == NULL || nullData == NULL || dataLength == NULL)
        {
            FREE(dataResult->dataSetStTab[cpt].dataDef);
            FREE(dataResult->dataSetStTab[cpt].data);
            return(RET_MEM_ERR_ALLOC);
        }

        if (SYS_GetEnv("AAANEWRESULTS") != NULL)
        {
            for (i = 0; i<dataResult->dataSetStTab[cpt].colNb; i++)
            {
                ptrDef = &dataResult->dataSetStTab[cpt].dataDef[GET_FLD_NBR(DataDef) * i];
                fieldType = (DATATYPE_ENUM)GET_INT(ptrDef, DataDef_Datatype);  /* REF7264 - PMO */

                if ((GET_CTYPE(fieldType) == CharPtrCType) ||
                    (GET_CTYPE(fieldType) == TextPtrCType))     /* REF4204 */
                {
                    size_t  allocSize= GET_MAXDATALEN(fieldType);
                    ALLOC_STRFLD(bindFld[i], allocSize);
                    dbiConn.colBind(i + 1,
                                    fieldType,
                                    string(),
                                    bindFld[i].data.strData.ptr,
                                    allocSize,
                                    &dataLength[i],
                                    &nullData[i],
                                    false,
                                    nullptr,
                                    nullptr);
                }
                else
                    if (GET_CTYPE(fieldType) == UniCharPtrCType)
                    {
                        size_t allocSize = GET_MAXLEN(fieldType);
                        ALLOC_USTRFLD(bindFld[i], allocSize);
                        dbiConn.colBind(i + 1,
                                        fieldType,
                                        string(),
                                        bindFld[i].data.ustrData.ptr,
                                        allocSize,
                                        &dataLength[i],
                                        &nullData[i],
                                        false,
                                        nullptr,
                                        nullptr);
                    }
                    else
                    {
                        if (fieldType == DateType ||
                            fieldType == DatetimeType)
                            dbiConn.colBind(i + 1,
                                            fieldType,
                                            string(),
                                            &bindFld[i].data.datetime64St,
                                            0,
                                            &dataLength[i],
                                            &nullData[i],
                                            false,
                                            nullptr,
                                            nullptr);
                        else
                        {
                            if (fieldType == IdType || fieldType == DictType)
                            {
                                dbiConn.colBind(i + 1,
                                                fieldType,
                                                string(),
                                                &bindFld[i].data.longlongValue,  /* PMSTA08801 - DDV - 091126 */
                                                0,
                                                &dataLength[i],
                                                &nullData[i],
                                                false,
                                                nullptr,
                                                nullptr);
                            }
                            else
                            {
                                dbiConn.colBind(i + 1,
                                                fieldType,
                                                string(),
                                                &bindFld[i].data.dbleValue,
                                                0,
                                                &dataLength[i],
                                                &nullData[i],
                                                false,
                                                nullptr,
                                                nullptr);
                            }
                        }
                    }
            }
        }
        else
            /* Prepare the read of data (Bind each data column) */
            for (i = 0; i < dataResult->dataSetStTab[cpt].colNb; i++)
            {
                ptrDef = &dataResult->dataSetStTab[cpt].dataDef[GET_FLD_NBR(DataDef) * i];
                fieldType = (DATATYPE_ENUM)GET_INT(ptrDef, DataDef_Datatype);  /* REF7264 - PMO */

                if ((GET_CTYPE(fieldType) == CharPtrCType) ||
                    (GET_CTYPE(fieldType) == TextPtrCType))     /* REF4204 */
                {
                    size_t allocSize = GET_MAXDATALEN(fieldType);
                    ALLOC_STRFLD(bindFld[i], allocSize);
                    dbiConn.colBind(i + 1,
                                    fieldType,
                                    string(),
                                    bindFld[i].data.strData.ptr,
                                    allocSize,
                                    &dataLength[i],
                                    &nullData[i],
                                    false,
                                    nullptr,
                                    nullptr);
                }
                else
                    if (GET_CTYPE(fieldType) == UniCharPtrCType)
                    {
                        size_t allocSize = GET_MAXLEN(fieldType);
                        ALLOC_USTRFLD(bindFld[i], allocSize);
                        dbiConn.colBind(i + 1,
                                        fieldType,
                                        string(),
                                        bindFld[i].data.ustrData.ptr,
                                        allocSize,
                                        &dataLength[i],
                                        &nullData[i],
                                        false,
                                        nullptr,
                                        nullptr);
                    }
                    else
                    {
                        if (fieldType == ExtensionType || fieldType == ChainedTypeType)   /* PMSTA-34537 - LJE - 190129 */
                        {
                            dbiConn.colBind(i + 1,
                                            AmountType,
                                            string(),
                                            &bindFld[i].data.dbleValue,
                                            0,
                                            &dataLength[i],
                                            &nullData[i],
                                            false,
                                            nullptr,
                                            nullptr);
                        }
                        else
                            if (fieldType == DateType || fieldType == DatetimeType)
                                dbiConn.colBind(i + 1,
                                                fieldType,
                                                string(),
                                                &bindFld[i].data.datetime64St,
                                                0,
                                                &dataLength[i],
                                                &nullData[i],
                                                false,
                                                nullptr,
                                                nullptr);
                            else
                                if (fieldType == IdType || fieldType == DictType) /* DLA - PMSTA08801 - 091215 */
                                    dbiConn.colBind(i + 1,
                                                    fieldType,
                                                    string(),
                                                    &bindFld[i].data.longlongValue,
                                                    0,
                                                    &dataLength[i],
                                                    &nullData[i],
                                                    false,
                                                    nullptr,
                                                    nullptr);
                                else
                                    dbiConn.colBind(i + 1,
                                                    fieldType,
                                                    string(),
                                                    &bindFld[i].data.dbleValue,
                                                    0,
                                                    &dataLength[i],
                                                    &nullData[i],
                                                    false,
                                                    nullptr,
                                                    nullptr);
                    }
            }

        /* For each row of the current data set */
        bContinue = true;                                               /* PMSTA-16443 - 230713 - PMO */
        for (i = 0; i<dataResult->dataSetStTab[cpt].rowNb; i++)
        {
            /* PMSTA-16443 - 230713 - PMO
            * Handling of the memory threshold
            * memoryThreshold = 0
            */
            if (memoryThreshold > 0 && memoryMaxK > 0 && 0 == i % 8192)
            {
                if (DBA_GetDataSegmentSize() > memoryThreshold)
                {
                    char szMsg[192];

                    sprintf(szMsg,
                            "Memory is nearly full (" szFormatSizeof "K) and %d%% of records are loaded (total records=%d). Instability or crash may occur.",      /* PMSTA-17133 - 051113 - PMO */
                            DBA_GetDataSegmentSize(),
                            int(100.0 * (double(i) / double(dataResult->dataSetStTab[cpt].rowNb))),
                            dataResult->dataSetStTab[cpt].rowNb);

                    MSG_LogMesg(RET_GEN_ERR_PERSONAL, 1, FILEINFO, szMsg);

                    if (NULL != DBA_WarningMessageBox)
                    {
                        sprintf(szMsg,
                                "Memory is nearly full (%d%%) and %d%% of records are loaded (total records=%d). Instability or crash may occur. Do you want to continue?",
                                int((100.0 * (double(DBA_GetDataSegmentSize()) / double(memoryMaxK)))),
                                int(100.0 * (double(i) / double(dataResult->dataSetStTab[cpt].rowNb))),
                                dataResult->dataSetStTab[cpt].rowNb);

                        bContinue = DBA_WarningMessageBox(szMsg);
                    }

                    memoryThreshold = SYS_ComputeNextMemoryThreshold(memoryThreshold);
                }
            }

            {
                RET_CODE retFetch = RET_SUCCEED;

                if (false == bContinue || (retFetch = dbiConn.fetch()) != RET_SUCCEED) /* PMSTA-16443 - 230713 - PMO */
                {
                    if (RET_DBA_INFO_NO_MORE_DATA == retFetch && dataResult->dataSetStTab[cpt].rowNb > i)
                    {
                        retFetch = RET_FIN_ERR_INCOMPLETE_RESULT;
                    }
                    else
                    {
                        retFetch = RET_DBA_ERR_DIALOG;
                    }

                    FREE(dataResult->dataSetStTab[cpt].data);
                    FREE(dataResult->dataSetStTab[cpt].dataDef);

                    return retFetch;
                }
            }

            /* For each column of the current data set */
            DBA_DYNFLD_STP ptrData = &dataResult->dataSetStTab[cpt].data[totColumns*i];
            for (int j = 0; j<totColumns; j++)
            {
                ptrDef = &dataResult->dataSetStTab[cpt].dataDef[GET_FLD_NBR(DataDef) * j];

                fieldType = (DATATYPE_ENUM)GET_INT(ptrDef, DataDef_Datatype);  /* REF7264 - PMO */

                switch (GET_CTYPE(fieldType))
                {
                    case DoubleCType:

                        if (nullData[j] == -1) /* -1 means that the recieved data is NULL */
                        {
                            SET_NULL_DOUBLE(ptrData, j);
                        }
                        else
                        {
                            SET_DOUBLE(ptrData, j, GET_DOUBLE(bindFld, j));
                        }
                        break;

                    case IntCType:
                    case UIntCType:

                        if (nullData[j] == -1) /* -1 means that the recieved data is NULL */
                        {
                            SET_NULL_INT(ptrData, j);
                        }
                        else
                        {
                            SET_INT(ptrData, j, GET_INT(bindFld, j));
                        }
                        break;

                    case ShortCType:
                    case UShortCType:

                        if (nullData[j] == -1) /* -1 means that the recieved data is NULL */
                        {
                            SET_NULL_SHORT(ptrData, j);
                        }
                        else
                        {
                            SET_SHORT(ptrData, j, GET_SHORT(bindFld, j));
                        }
                        break;

                    case LongLongCType:  /* DLA  - REF9089 - 030815 */  /* PMSTA08801 - DDV - 091126 */
                        if (nullData[j] == -1) /* -1 means that the recieved data is NULL */
                        {
                            SET_NULL_LONGLONG(ptrData, j);
                        }
                        else
                        {
                            SET_LONGLONG(ptrData, j, GET_LONGLONG(bindFld, j));  /* PMSTA08801 - DDV - 091126 */
                        }
                        break;

                    case TimeStampCType:  /* REF11780 - 100406 - PMO */
                        if (nullData[j] == -1) /* -1 means that the recieved data is NULL */
                        {
                            SET_NULL_TIMESTAMP(ptrData, j);
                        }
                        else
                        {
                            SET_TIMESTAMP(ptrData, j, GET_TIMESTAMP(bindFld, j));
                        }
                        break;

                    case BinaryCType:  /* DLA - PMSTA05995 - 080410 */
                        if (nullData[j] == -1) /* -1 means that the recieved data is NULL */
                        {
                            SET_NULL_BINARY(ptrData, j);
                        }
                        else
                        {
                            SET_BINARY(ptrData, j, GET_BINARY(bindFld, j));
                        }
                        break;

                    case UCharCType:

                        if (nullData[j] == -1) /* -1 means that the recieved data is NULL */
                        {
                            SET_NULL_UCHAR(ptrData, j);
                        }
                        else
                        {
                            SET_UCHAR(ptrData, j, GET_UCHAR(bindFld, j));
                        }
                        break;

                    case DateTimeStCType:

                        if (nullData[j] == -1) /* -1 means that the recieved data is NULL */
                        {
                            SET_NULL_DATETIMEST(ptrData, j);
                        }
                        else
                        {
                            SET_DATETIMEST(ptrData, j, GET_DATETIMEST(bindFld, j))
                        }
                        break;

                    case CharPtrCType:
                    case TextPtrCType:                  /* REF4204 */
                        if (j >= dataResult->dataSetStTab[cpt].colNb)
                        {
                            /* If the column is a list name */
                            if (EV_TestNewScpt == FALSE && IS_NULLFLD(ptrDef, DataDef_ClassifId) != TRUE)
                            {
                                DBA_DYNFLD_STP admArg  = mp4.allocDynst(FILEINFO, Adm_Arg);
                                DBA_DYNFLD_STP sListSt = mp4.allocDynst(FILEINFO, S_List);

                                SET_ID(admArg, Adm_Arg_Id, GET_ID(ptrData, GET_INT(ptrDef, DataDef_RefKeyIndex) - 1));

                                if (DBA_Get2(List, UNUSED, Adm_Arg, admArg, S_List,
                                    &sListSt, UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
                                {
                                    FREE(dataResult->dataSetStTab[cpt].dataDef);
                                    FREE(dataResult->dataSetStTab[cpt].data);
                                    return(RET_DBA_ERR_NODATA);
                                }

                                SET_CODE(ptrData, j, GET_CODE(sListSt, S_List_Cd));
                            }

                            continue;
                        }
                        else
                        {
                            if (nullData[j] == -1) /* -1 means that the received data is NULL */
                            {
                                SET_NULL_STRING(ptrData, j);
                            }
                            else
                            {
                                SET_STRING(ptrData, j, GET_STRING(bindFld, j));
                            }
                        }
                        break;

                    case UniCharPtrCType:

                        if (nullData[j] == -1) /* -1 means that the recieved data is NULL */
                        {
                            SET_NULL_USTRING(ptrData, j);
                        }
                        else
                        {
                            SET_USTRING(ptrData, j, GET_USTRING(bindFld, j));
                        }
                        break;
                }
            }
        }

        while (dbiConn.fetch() == RET_SUCCEED);

        /* Free allocated strings for bind structure */
        for (i = 0; i<dataResult->dataSetStTab[cpt].colNb; i++)
        {
            ptrDef = &dataResult->dataSetStTab[cpt].dataDef[GET_FLD_NBR(DataDef) * i];
            fieldType = (DATATYPE_ENUM)GET_INT(ptrDef, DataDef_Datatype);  /* REF7264 - PMO */

            if ((GET_CTYPE(fieldType) == CharPtrCType) || (GET_CTYPE(fieldType) == TextPtrCType))
            {
                FREE_STRFLD(bindFld[i]);
            }
            else if (GET_CTYPE(fieldType) == UniCharPtrCType || GET_CTYPE(fieldType) == UniTextPtrCType)
            {
                FREE_USTRFLD(bindFld[i]);
            }
        }

        /* Modify the columns number in the data set if columns where added */
        dataResult->dataSetStTab[cpt].colNb = totColumns;
    }

    DBI_INT resultType = 0;
    dbiConn.processAllResults(&resultType);

    mp.remove(static_cast<void *>(dataResult->dataSetStTab));   // It is a normal free / PMSTA-30419 - 050318 - PMO
    mp.remove(static_cast<void *>(dataResult->fmtEltDef));      // It is a normal free / PMSTA-30419 - 050318 - PMO
    mp.remove(dataResult);

    return RET_SUCCEED;
}


RET_CODE DBI_ReadFinFctResults(DbiConnection& dbiConn, DBA_DATARESULT_STP *dataStruct)
{
    RET_CODE ret = RET_SUCCEED;   /* Return value */

    try
    {
        ret = _DBI_ReadFinFctResults(dbiConn, *dataStruct);
    }
    catch(std::exception const& e)
    {
        MSG_SendMesg(FILEINFO,e.what());
        dbiConn.cancelDbRequest(COMMAND_LEVEL, CANCEL_ALL);

        ret = RET_MEM_ERR_ALLOC;
    }

    if (RET_SUCCEED != ret)
    {
        *dataStruct = nullptr;
    }

    return ret;
}



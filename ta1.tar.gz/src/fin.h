/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef FIN_H
#define FIN_H

#ifndef HIER_H
#include "hier.h"
#endif

#ifndef DATE_H
#include "date.h"
#endif

#ifndef SCPT_H
#include "scpt.h"
#endif

#ifndef DBA_H
#include "dba.h"
#endif

/************************************************************************
**      Constant & Macro definitions 
*************************************************************************/

 /* REF8844 - LJE - 030319 : Move here from descdyn.h */
#define A_BalPos_BpPosAmtNb                 10 /* F&T fields nb */
#define ExtPos_BpPosAmtNb                   10 /* number of fees & taxes */
#define A_Pos_BpPosAmtNb                    10 /* F&T fields nb */

/************************************************************************
**      Structure definitions & typedef
*************************************************************************/

typedef enum {
	InstrConvertInterest_None,
	InstrConvertInterest_PrincipalOnly,
	InstrConvertInterest_PrincipalInstrest
} INSTR_CONVERT_INTEREST_ENUM;

typedef struct {				/* REF1384 - RAK - 980313 */
	NUMBER_T	incTax;
	FLAG_T		cleanPriceFlg;
	FLAG_T		divProjFlg;
} FIN_CRTYIELD_ST, *FIN_CRTYIELD_STP;

typedef struct {				/* DVP561 - RAK - 970826 */
	DATE_T		begDate;
	DATE_T		endDate;
	NUMBER_T	life;
	SUBNAT_ENUM	subNatEn;
	ACCRRULE_ENUM	accrRuleEn;		/* REF3477 - RAK - 990325 */
						/* New argument for Euro future contract */
} FIN_LIFE_ST, *FIN_LIFE_STP;


typedef struct {
	PRICE_T price,
	         quote,
	         unpaidPrct, 
	         nomValue,
	         actuYield,
	         addOnRate,
	         accrInter,
	         otherInstrQuote,
	         contractSz,
	         annualQuote,
		 life;
} FIN_PRICE_QUOTE_ST, *FIN_PRICE_QUOTE_STP;

typedef struct {
	PRICE_T  price;
	ID_T     currId;
} FIN_PRICE_ST, *FIN_PRICE_STP; 

struct FIN_AIARG_STRUCT
{                                               /* REF1457 - RAK - 980324 */
	PTR 	            scptAIStp;
	FLAG_T		        fullCoupFlg;
	FUSDATERULE_ENUM    fusDateRule;
	char		        calcAccrInterFlg; 
	char		        txdInterFlg;
    ACCRINTERMETHOD_ENUM    accrInterMethod;
    DATETIME_T          accrValFromDate;
    DATETIME_T          domainRefDateTime;  /*  FPL-PMSTA12114-110601   */
	ACCRRULE_ENUM       accrRule;			/* REF11218 - TEB - 050627 */
	FLAG_T		        useDefinedDateFlg;  /* PMSTA08308 - 090609 - PMO */
    bool                    fusionProcessing;   /* Financial functions update some position fields (date, set to primary) while the fusion use has his. PMSTA-23996 - 080716 - PMO */

    FIN_AIARG_STRUCT()
    {
	    scptAIStp               = NULL;
	    fullCoupFlg             = FALSE;
	    fusDateRule             = FusDateRule_None;
	    calcAccrInterFlg        = 0; 
	    txdInterFlg             = 0;
        accrInterMethod         = AccrInterMethod_Default;
        accrValFromDate.date    = 0;
        accrValFromDate.time    = 0;
        domainRefDateTime.date  = 0;
        domainRefDateTime.time  = 0;
	    accrRule                = AccrRule_None;
        useDefinedDateFlg       = FALSE;
        fusionProcessing        = false;
    }

};

typedef FIN_AIARG_STRUCT   FIN_AIARG_ST;
typedef FIN_AIARG_STRUCT * FIN_AIARG_STP;


/*  DEV1055 - CSA - 991122 */ /* PMSTA-32112 - RAK - 180816 - Moved from permval.h */
typedef enum {
	InstrCategory_BondFutures,
	InstrCategory_BondForwards,
	InstrCategory_EquityFutures,
	InstrCategory_EquityForwards,
	InstrCategory_CurrencyFutures,
	InstrCategory_CurrencyForwards,
	InstrCategory_Swap,
	InstrCategory_ForexSwap,
	InstrCategory_Options,
	InstrCategory_ExoticOptions,
	InstrCategory_FRA,				/* REF4763 - RAK - 000622 */
	InstrCategory_ConvertibleBond,  /* REF5049 - CSA/AKO - 06112000 */
	InstrCategory_StructuredNotes,	/* PMSTA-32112 - RAK - 180816 */
	InstrCategory_ACDC,				/* PMSTA-34140 - RAK - 190204 */
	InstrCategory_Others
} INSTRCATEGORY_ENUM;

typedef struct { /* REFXZ - RAK - 980609 */
    ID_T                  tpId;                 /* type identifier (optional)           */
    ID_T                  marketId;             /* market identifier (optional)         */
    ID_T                  providerId;           /* provider identifier (optional)       */
    char                  directFlg;            /* direct exchange rate required or not */
    char                  tpMandFlg;            /* type mandatory flag                  */
    char                  mktMandFlg;           /* market mandatory flag                */
    char                  provMandFlg;          /* provider mandatory flag              */
    int                   exchRetMet;           /* exchange retrieval method            */
    AMOUNT_T              srcAmt;               /* source amount (rounded problem)      */
    int	                  threadConnNbrPlusOne;	/* thread connexion number for optim REF2580 - SSO - 980727 */	
                                                /* !!! the REAL # for calling SERV_GetThreadDomainByConnectNo is threadConnNbrPlusOne-1 !!! */
                                                /* thus, the existing memset(NULL) don't use the optimization for DBA_GetDomainPtr*/
    FLAG_T                busEntityFlg;         /* business entity flag */ /* PMSTA-32142 CMILOS 130918 */
    BUS_ENTITY_RULE_ENUM  busEntityRule;        /* business entity rule */ /* PMSTA-32142 CMILOS 130918 */
} FIN_EXCHARG_ST, *FIN_EXCHARG_STP;

typedef struct {
	NUMBER_T       mktValAmt;         /* in reference currency */
	NUMBER_T       netAmt;            /* in reference currency */
	NUMBER_T       accrInterRefCurr;  /* in reference currency */
	NUMBER_T       accrInter;         /* in accrued interest currency */
	ID_T           accrInterCurrId;   /* accrued interest currency */
	DATE_PERIOD_ST accrInterPeriod;   /* accr. interest days (num, denom) */
	EXCHANGE_T     accrInterRefExch;  /* exchange rate between accrued interest */
					  /* currency and reference currency */
} FIN_MKTVAL_ST, *FIN_MKTVAL_STP;

typedef struct {
	PRICE_T       exerPrice;
	ID_T          exerCurrId;
	ID_T          underId;
	OPTCLASS_ENUM optClassEn;
	DATE_T        endDate;
	NUMBER_T      underQty;		/* BUG136 */
} FIN_OPTINFO_ST, *FIN_OPTINFO_STP;

/**** INTEREST RATE CONDITION INFORMATIONS ****/
typedef struct {
        DATE_T    fromDate;             /* interest rate condition begin     */
        DATE_T    tillDate;             /* interest rate condition end       */
        PERCENT_T posRate;              /* rate to apply in case of pos amt  */
        PERCENT_T negRate;              /* rate to apply in case of neg amt  */
} FIN_RATE_INFO_ST, *FIN_RATE_INFO_STP;

typedef struct {
        int                interRateNbr;    /* number of rate conditions */
	INTERCALCRULE_ENUM interCalcRuleEn; /* last interest calculation rule */
        FIN_RATE_INFO_STP  infoPtr;         /* rate conditions array     */
} FIN_INTERRATE_ST, *FIN_INTERRATE_STP;

/* DVP186 */
typedef struct {
	AMOUNT_T netTot;
	AMOUNT_T grossTot;
	AMOUNT_T netCap;
	AMOUNT_T grossCap;
	AMOUNT_T netCurr;
	AMOUNT_T grossCurr;
} FIN_PL_ST, *FIN_PL_STP; 

typedef enum {
	PL_NetCap,
	PL_GrossCap,
	PL_NetCurr,
	PL_GrossCurr 
} PLTP_ENUM; 

/* DVP440 - RAK - 970425 */
typedef struct {
	PRICE_T 	costQuote;		/* FIN_InstrPrice() arg */
	DATETIME_T	expirDate;		/* FIN_InstrPrice() arg */	/* REF053 */
	char		riskFlg;		/* FIN_PosPrice() arg   */	/* REF3030 */
	DATETIME_T	discFacDate;		/* FIN_InstrPrice() arg */	/* REF2852 */
} FIN_PRICEARG_ST, *FIN_PRICEARG_STP;

typedef struct {
	DBA_DYNFLD_STP *exchRateTabSrcIn;
	DBA_DYNFLD_STP *exchRateTabDestIn;
	int            exchRateNbrSrcIn;
	int            exchRateNbrDestIn;
} FIN_EXCHTABARG_ST, *FIN_EXCHTABARG_STP;

/*
    DEV1055 - CSA/RAK - 23121999

  typedef struct {	
	PRICE_T		posPrice;
	PRICE_T		spotPrice;
	char		valDiffFlg;
} FIN_FWDPRICEARG_ST, *FIN_FWDPRICEARG_STP;*/

typedef enum {
	SrcDest_Src,
	SrcDest_Dest 
} FIN_SRCDEST_ENUM;

typedef struct {
	DBA_DYNFLD_STP	 exchRateDest;
	DBA_DYNFLD_STP	 exchRateSrc;
	DBA_DYNFLD_STP   *exchRateTabSrc;
	DBA_DYNFLD_STP   *exchRateTabDest;
	int              exchRateNbrSrc;
	int              exchRateNbrDest;
	char		 allocTabSrc;
	char		 allocTabDest;
	FIN_SRCDEST_ENUM srcDestEn;
	char             defaultFlg;
} FIN_EXCHOUT_ST, *FIN_EXCHOUT_STP;

typedef struct {                                /* REF1402 */
        int     beg;
        int     end;
} FIN_RET_CRYSTPER_ST, *FIN_RET_CRYSTPER_STP;

/* DVP261 - Store crystallised dates and frequency */
typedef struct {
        DATETIME_T              *crystDates;
        int                     crystDatesNbr;
        SMALLINT_T              freq;
        FREQUNIT_ENUM           freqUnit;
        char                    endPeriodFlg;
        DATETIME_T              endPeriodDate;		/* REF1402 */
		DATETIME_T				replaceDate;		/* REF1402 */
		char					eventSchedFlg;		/* REF1402 */
        DATETIME_T              *periodCrystDates;      /* REF1402 */
        int                     periodCrystDatesNbr;    /* REF1402 */
        FIN_RET_CRYSTPER_STP    period;                 /* REF1402 */
        int                     periodNbr;              /* REF1402 */
        char                    deleteFlg;				/* REF5244 - CSY - 001004 */
        ID_T					parallelStorPSPId;		/* REF9836 - RAK - 040126 - change flg in PSPId */
} FIN_RET_FREQ_ST, *FIN_RET_FREQ_STP;

/* REF1055 - AKO - 991130 */
typedef struct {
		AMOUNT_T    payOffRebate;
		char	    payOffStatus;
}PAYOFFREBATE_ST, *PAYOFFREBATE_STP;

/* REF8537 - YST - 030721 */
typedef struct {	
	ID_T		    stratId;
    DATETIME_T	    fromDate;
	DATETIME_T	    tillDate;
} STRAT_DATE_ST, *STRAT_DATE_STP; 

/* REF7395 - CSY - 020409:  PA = performance attribution */
typedef struct {
	DATETIME_T  dateTime;
    MASK_T      level;    
	ID_T		objId;			/* REF30895 - MCA - 030716 */
    DATETIME_T  lastRebalDate;  /* PMSTA08737 - LJE - 100927 */
} PA_DATETIME_ST, *PA_DATETIME_STP;

/* PMSTA-47578 - DDV - 220215 */
typedef struct {
    ID_T                        instrId;
    DATETIME_T                  beginDate;
    PerfTimingRuleTimingRuleEn  beginTimingRule;
    DATETIME_T                  endDate;
    PerfTimingRuleTimingRuleEn  endTimingRule;
} NIP_PERIOD_ST, *NIP_PERIOD_STP;

/* PMSTA-47578 - DDV - 220215 */
typedef struct {
    DATETIME_T                  date;
    PerfTimingRuleTimingRuleEn  timingRuleEn;
    PosFlowInfo                 posFlowInfoEn;
} NIP_EVENT_ST, *NIP_DATE_EVENT_ST;

typedef struct {
    ID_T				ptfId;
    ID_T                listId;     /* PMSTA-53952 - Lalby - 14112023  */
	ID_T				pspId;		/* REF9125 - YST - 030721 */
	DBA_DYNFLD_STP		pspPtr;		/* REF9125 - RAK - 030917 */
	/*ID_T				stratId;*/	/* REF8537 - YST - 030721 */
	FREQUNIT_ENUM		freqUnitEn;	/* REF9125 - YST - 030723 */
    PA_DATETIME_STP     paDates;
    int                 paDatesNbr;
    DATETIME_T          delFromDate;
    DATETIME_T          delTillDate;
    DATETIME_T          calcFromDate;	/* REF9834 - TEB - 040617 */
    DATETIME_T          calcTillDate;	/* REF9834 - TEB - 040617 */
    FLAG_T              eventSchedFlg; /* TRUE if event scheduler must be deleted, FALSE otherwise */ /* REF7421 - YST - 020802 */
    FLAG_T              computeDuraFlg; /* PMSTA08736 - LJE - 100623 */
    NIP_PERIOD_STP      nipPeriodTab;   /* PMSTA-47578 - DDV - 220215 */
    int                 nipPeriodNbr;   /* PMSTA-47578 - DDV - 220215 */
	NIP_PERIOD_STP      quickInvestTab; /* WEALTH-2954 - DDV - 231213 */
	int                 quickInvestNbr; /* WEALTH-2954 - DDV - 231213 */
	NIP_PERIOD_STP      ptfNipPeriodTab; /* PMSTA-48803 - HLA - 060223 */
    int                 ptfNipPeriodNbr; /* PMSTA-48803 - HLA - 060223 */
    DBA_DYNFLD_STP      headPspPtr;     /*PMSTA-48195 -Performance IPS Level -Lalby-310123*/
    FREQUNIT_ENUM       ptFfreqUnitEn;	/*PMSTA-48195 - freqUnitEn :to store headpspfreq , ptFfreqUnitEn -ptffrequency for new method only*/
}   PA_DATEINFO_ST, *PA_DATEINFO_STP;

typedef struct {
    PA_DATEINFO_STP     paDateInfoTab;
    int                 paDateInfoNbr;
    FLAG_T              synthAdminFlg; 
	FLAG_T              mergedTWRFlg;	 /* PMSTA06916 - LJE - 081105 */
	DBA_DYNFLD_STP      mergedTWRObjStp; /* PMSTA06916 - LJE - 081105 */
	/* PMSTA-10775 - LJE - 101104 */
	COMPDATA_ENUM       computeDataEn;

	/* PMSTA-19118 - LJE - 141201 */
	FLAG_T              allowOptimFlg;

	/* PMSTA08391 - LJE - 090713 */
	DBA_DYNFLD_STP     *synthInstrTab;
	int                 synthInstrNbr;

}   PA_INFO_ST, *PA_INFO_STP;



/* REF7395 - CSY - 020409:  PA = performance attribution */
/************************************************************************
**      Structure definitions
*************************************************************************/
typedef enum
{
    SynthLevel_PortBenchStorage,
    SynthLevel_BenchRebal,
    SynthLevel_Primary,
    SynthLevel_Gips,
    SynthLevel_PA,
    SynthLevel_PS,
    SynthLevel_InstrNIP, /* PMSTA-47578 - DDV - 220121 */
    SynthLevel_OpDate,   /* PMSTA-47578 - DDV - 220121 */
	SynthLevel_PtfNIP,
	SynthLevel_GlobalFreqDate, /* WEALTH-4492 - DDV - 240119 */
	SynthLevel_GlobalOpDate    /* WEALTH-3330 - DDV - 240307 */
} SYNTH_LEVEL_ENUM;

/* < REF9658 - CHU - 040209 : NEW MODE FOR REPERCUTION (UP OR DOWN) */
#define REPERCUTION_MODE_NORMAL      0 /* use standard weight repercution */
#define REPERCUTION_MODE_BENCH       1 /* use benchmark oriented weight repercution */
#define REPERCUTION_MODE_DERIVATION  2 /* use derivation oriented weight repercution */
/* REF9658 - CHU - 040209 > */

#define PERP_BOND_TENURE             500

#include "finai.h"
#include "finprice.h"
#include "finlib01.h"
#include "finexch.h"
#include "fininstr.h"
#include "finlib02.h"
#include "finlib03.h"
#include "finlib04.h"
#include "finlib06.h"
#include "finlib07.h"
#include "finlib08.h"
#include "finlib09.h"
#include "finlib10.h"
#include "finlib11.h"
#include "finlib12.h"
#include "finlib13.h"
#include "stratadm.h"

#endif         /*  #ifndef FIN_H */
/************************************************************************
*       END           fin.h                                     UNICIBLE	
*************************************************************************/

/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines
*************************************************************************/
#define DBALOADPAA_C

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H

#include   "unidef.h"     /* Mandatory */
#include      "gen.h"
#include      "dba.h"
#include      "fin.h"
#include     "date.h"
#include      "cmp.h"
#include      "tls.h"
#include     "hier.h"
#include "finperfa.h" /* REF8712 - LJE - 031020 */
#include "dbaperfa.h" /* PMSTA07331 - LJE - 081030 */
#include "srvperfa.h"
#include "srvperf3.h"
#include "dbaperf.h"
#include "dbiconnection.h"
#include "srvperf4.h"

/************************************************************************
**      External entry points
**
**
*************************************************************************/

/************************************************************************
**      Local functions
**
*************************************************************************/

/************************************************************************
**      Static definitions & data
*************************************************************************/
#define INIT_BUFF_SIZE 10240

#define PERF_ATTRIB_IDX 0
#define EXT_RET_IDX 1
#define STD_PERF_IDX 2
#define PERF_CALC_RES_IDX 3

#define PASS_STORED_HIER_PSP 0
#define PASS_PARENT_STD_PSP 1
#define PASS_CHILD_STD_PSP 2
#define PASS_PARENT_HIER_PSP 3
#define PASS_PARENT_HIER_PSP_BEGIN 4
#define PASS_NBR 5

typedef struct {
    FLAG_T              insertFlg;
    FIELD_IDX_T        *fromDIdxPtr;
    FIELD_IDX_T        *tillDIdxPtr;
    FIELD_IDX_T        *domFromDIdxPtr;
    FIELD_IDX_T        *domTillDIdxPtr;
    FIELD_IDX_T        *outEntFlgIdxPtr;
    OBJECT_ENUM        *outObjEnPtr;
    DICT_T              outEntDictId;
    OBJECTLNK_NAT_ENUM  objLnkNat; /* REF9340 - DDV - 030820 */
    FLAG_T              irregBenchFlg;  /* PMSTA09979 - LJE - 100825 */
    /* PMSTA-17115 - LJE - 131025 */
    DICT_T              ptfEntDictId;
    DICT_T              stratEntDictId;
    DICT_T              instrEntDictId;
    DICT_T              pspEntDictId;
    DICT_T              gridEntDictId;

    RETURNINPARENTPTFRULE_ENUM	returnInParPtfRuleEn; /* PMSTA-17234 - LJE - 131118 */
} COMPUTE_PAA_ST, *COMPUTE_PAA_STP;


/* REF9770 - LJE - 040119 */
typedef struct {
    ID_T           id;
    DATETIME_T     date;
    DBA_DYNFLD_STP gridLnk;
    DBA_DYNFLD_STP *benchObjLnkTab;
    int            benchObjLnkNbr;
    int            mainObjPos;
} DBA_REF_GRID_ST, *DBA_REF_GRID_STP;

/* PMSTA-17234 - LJE - 131115 */
typedef struct DBA_MAIN_OBJ DBA_MAIN_OBJ_ST, *DBA_MAIN_OBJ_STP;

struct DBA_MAIN_OBJ {
    OBJECT_ENUM     objEn;
    DBA_DYNFLD_STP  mainObjStp;
    DBA_DYNFLD_STP  hierPtfStp;
    ID_T            currId;
    int             passNbr;
    FLAG_T          forceHierPSPFlg;
    DATETIME_T      firstHierPSPDate;
    DATETIME_T      firstStoredPSPDate; /* PMSTA-24511 - LJE - 161206 */
    DATETIME_T      lastStoredPSPDate;
    DBA_MAIN_OBJ_STP parMainObjInfoStp;

    DBA_DYNFLD_STP   lastPspRAObjLnkStp;
    DBA_DYNFLD_STP   lastGridRAObjLnkStp;
    DBA_DYNFLD_STP   lastPspPAObjLnkStp;
    DBA_DYNFLD_STP   lastGridPAObjLnkStp;
    DBA_DYNFLD_STP   lastPspStdPerfObjLnkStp;
    DBA_DYNFLD_STP   lastPspPerfCalcResObjLnkStp;

    DBA_DYNFLD_STP  *hierObjLnksTab;
    int              hierObjLnksNbr;
};

/* PMSTA-9378 - RAK - 100507 */
STATIC RET_CODE FIN_CreateDomPPDa(DBA_DYNFLD_STP, DBA_DYNFLD_STP*);
STATIC int FIN_CmpPPDa(COMPUTE_PAA_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP);

STATIC int FIN_CmpPspByEntIdObjIdDt(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *);

/* REF8556 - LJE - 030109 */
STATIC int DBA_FilterObjectLnkGridPAA(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP), /* REF9187 - LJE - 040206 */
DBA_FilterObjectLnkCopyGridPAA(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP), /* REF10334 - LJE - 040604 */
DBA_FilterObjectLnkPSPPAA(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP),  /* REF9770 - LJE - 040317 */
DBA_FilterAllBenchObjLnkForCurrent(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);

/* REF9264 - LJE - 030924 */
STATIC int DBA_FilterMainObjectLnkPAA(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP),
DBA_FilterMainOrBenchObjectLnkPAA(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP), /* PMSTA-13058 - LJE - 111103 */
DBA_CmpObjectLnkPAA(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *),
DBA_CmpObjectLnkGridPAA(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *);

STATIC int FIN_FilterPSPObjectLnk(DBA_DYNFLD_STP, DBA_DYNST_ENUM, DBA_DYNFLD_STP);
STATIC int FIN_CmpPSPId(DBA_DYNFLD_STP *, DBA_DYNFLD_STP *);

/* PMSTA-12966 - LJE - 120320 */
STATIC RET_CODE DBA_InsertAllDomPSP(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, COMPUTE_PAA_STP);
STATIC RET_CODE DBA_InsertObjLnkIntoDomPSP(COMPUTE_PAA_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, RequestHelper&);

/* PMSTA09843 - LJE - 100519 */
STATIC RET_CODE DBA_LoadPspFromDB(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DbiConnectionHelper&, RETURNINPARENTPTFRULE_ENUM);
STATIC RET_CODE DBA_LoadDomPspTableFromExistingPSP(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, DbiConnectionHelper&, COMPUTE_PAA_STP);
STATIC RET_CODE DBA_CreateValidPSP(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, COMPUTE_PAA_STP, DBA_MAIN_OBJ_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, DBA_DYNFLD_STP, int*, DBA_DYNFLD_STP**);
STATIC FLAG_T   FIN_GetIrregBenchFlg(DBA_HIER_HEAD_STP, DBA_DYNFLD_STP, COMPUTE_PAA_STP);

/************************************************************************
**  Function             : DBA_LoadDomPspTable()
**
**  Description          : Create and fill #dom_psp table for operation search load
**
**  Arguments            :
**
**  Return               : RET_SUCCEED or error code
**
**  Creation             : REF7758 - LJE - 020919
**
*************************************************************************/
RET_CODE DBA_LoadDomPspTable(DBA_HIER_HEAD_STP *hierHeadPtr,
                             DBA_DYNFLD_STP       domainPtr,
                             DbiConnectionHelper& dbiConnHelper)
{

    RET_CODE        ret = RET_SUCCEED;
    DBA_DYNFLD_STP *pspTab;
    int             pspNbr;

    int             i, j;

    /* REF8556 - LJE - 030109 */
    DATETIME_T     tmpDate;

    /* REF9770 - LJE - 031210 */
    DATETIME_T        minDate;

    COMPUTE_PAA_ST    computeTab[] = {
        { FALSE, &A_PerfStorageParam_PerfFirstStoredDate, &A_PerfStorageParam_PerfLastStoredDate,
        &A_Domain_InterpFromDate, &A_Domain_InterpTillDate,
        &A_PerfStorageParam_PerfAttribFlg,
        &PerfAttrib, 0, ObjectLnkNat_PSPPA }
        , { FALSE, &A_PerfStorageParam_RetFirstStoredDate, &A_PerfStorageParam_RetLastStoredDate,
        &A_Domain_InterpFromDate, &A_Domain_InterpTillDate,
        &A_PerfStorageParam_RetAnalysisFlg,
        &ExtRetAnalysis, 0, ObjectLnkNat_PSPExtRA }
        , { FALSE, &A_PerfStorageParam_StdPerfFirstStoredDate, &A_PerfStorageParam_StdPerfLastStoredDate,
        &A_Domain_CalcRefDate, &A_Domain_InterpTillDate,
        &A_PerfStorageParam_StandardPerfDataFlg,
        &StandardPerf, 0, ObjectLnkNat_PSPSP } /* REF7758 - LJE - 020930 */
        , { FALSE, &A_PerfStorageParam_PerfCalcFirstStoredDate, &A_PerfStorageParam_PerfCalcLastStoredDate,
        &A_Domain_CalcRefDate, &A_Domain_InterpTillDate,
        &A_PerfStorageParam_PerfCalcResultFlg,
        &PerfCalcResult, 0, ObjectLnkNat_PSPPCR }/*PMSTA-53328 - SENTHIL - 140823*/
    };

    RETURNINPARENTPTFRULE_ENUM	returnInParPtfRuleEn = ReturnInParentPtfRule_Children;	 /* PMSTA02013 - RAK - 071112 */
 
    if (static_cast<LOADHIERPTF_ENUM> GET_ENUM(domainPtr, A_Domain_LoadHierFlg) == LoadHierPtf_IntermediateHierarchy)
    {
        returnInParPtfRuleEn = ReturnInParentPtfRule_Parent; /*always*/
    }
    else
    {
        GEN_GetApplInfo(ApplReturnInParentPtfRule, &returnInParPtfRuleEn);
    }

    /* PMSTA09979 - LJE - 100720 */
    PSPSELECTIONRULE_ENUM pspSelectionRule = PSPSelectionRule_AllPSP;
    GEN_GetApplInfo(ApplPSPSelectionRule, &pspSelectionRule);

    for (i = 0; i < 4; i++)
    {
        DBA_GetDictId(PerfStorageParam, &(computeTab[i].pspEntDictId));
        DBA_GetDictId(Grid, &(computeTab[i].gridEntDictId));
        DBA_GetDictId(Strat, &(computeTab[i].stratEntDictId));
        DBA_GetDictId(Instr, &(computeTab[i].instrEntDictId));
        DBA_GetDictId(Ptf, &(computeTab[i].ptfEntDictId));

        DBA_GetDictId(*(computeTab[i].outObjEnPtr), &(computeTab[i].outEntDictId));

        computeTab[i].returnInParPtfRuleEn = returnInParPtfRuleEn;
    }

    tmpDate.date = SYB_BEGIN_DATE;
    tmpDate.time = 0;

    minDate.date = SYB_BEGIN_DATE;
    minDate.time = 0;

    /* PMSTA09843 - LJE - 100527 - If too big (15 years in monthly), set auth online period to infini */
    if (IS_NULLFLD(domainPtr, A_Domain_AuthOnlinePeriods) == FALSE &&
        GET_INT(domainPtr, A_Domain_AuthOnlinePeriods) > 5000)
    {
        SET_NULL_INT(domainPtr, A_Domain_AuthOnlinePeriods);
    }

    DBA_LoadPspFromDB((*hierHeadPtr), domainPtr, dbiConnHelper, returnInParPtfRuleEn); /* PMSTA09843 - LJE - 100519 */

    /* ------------------------------------------------------------------ */
    /* Set and make links used by function and update some position infos */
    /* ------------------------------------------------------------------ */
    if ((ret = DBA_LoadPosHierLnkAndUpd(*hierHeadPtr, domainPtr, FALSE)) != RET_SUCCEED)
    {
        return(ret);
    }

    if (dbiConnHelper.isValidAndInit() == false)
    {
        return(RET_DBA_ERR_CANNOTCONNECT);
    }

    if ((ret = DBA_CreateTempTables(*dbiConnHelper.getConnection(), DOM_PSP)) != RET_SUCCEED)
    {
        return(ret);
    }

    switch (GET_ENUM(domainPtr, A_Domain_ReturnAnalysisEn))
    {
        case PAARetAnalysis_All: /* all */
            computeTab[3].insertFlg = TRUE;
            computeTab[2].insertFlg = TRUE;
            computeTab[1].insertFlg = TRUE;
            computeTab[0].insertFlg = TRUE;
            break;
        case PAARetAnalysis_RA: /* RA */
            computeTab[3].insertFlg = TRUE;
            computeTab[2].insertFlg = TRUE;
            computeTab[1].insertFlg = TRUE;
            /* REF11474 - LJE - 060214 : Force sub-grid flag to TRUE if grid isn't NULL */
            if (IS_NULLFLD(domainPtr, A_Domain_GridId) == FALSE)
            {
                SET_FLAG_TRUE(domainPtr, A_Domain_SubGridFlg);
            }
            break;
        case PAARetAnalysis_PA: /* PA */
            computeTab[3].insertFlg = TRUE;
            computeTab[2].insertFlg = TRUE;
            computeTab[0].insertFlg = TRUE;
            break;
        case PAARetAnalysis_StdPerf: /* Standard Perf */ /* PMSTA00821 - RAK - 070314 */
            computeTab[3].insertFlg = TRUE;
            computeTab[2].insertFlg = TRUE;
            break;
        default:
            MSG_SendMesg(RET_GEN_ERR_INVARG, 5, FILEINFO, "DBA_LoadDomPspTable", "domain", "return_analysis_e");
            return(RET_GEN_ERR_INVARG);
    }

    /* Extract all PSP */
    if ((ret = DBA_HierEltRecExtract(*hierHeadPtr,
        A_PerfStorageParam,
        FALSE,
        NULL,
        NULL,
        FIN_CmpPspByEntIdObjIdDt,  /* PMSTA-13946 - LJE - 120328 */
        FALSE,
        FALSE,
        &pspNbr,
        &pspTab)) != RET_SUCCEED)
    {
        return(ret);
    }

    /* PMSTA-11083 - LJE - 110114 - Check all PSP */
    for (i = 0; i < pspNbr; i++)
    {
        if (GET_ENUM(pspTab[i], A_PerfStorageParam_CheckedDataEn) == 0 &&
            (ret = DBA_ValidatePerfData(pspTab[i])) == RET_SUCCEED)
        {
            MSG_LogSrvMesg(UNUSED, 0, "Validation of data for perf_storage_param (id=%1) succeeded",
                           IdType, GET_ID(pspTab[i], A_PerfStorageParam_Id));
        }
    }

    /* PMSTA09843 - LJE - 100519 - New behavior with PtfRetDetLvl_UsePSP */
    if (GET_DICT(domainPtr, A_Domain_InitialFctDictId) == DictFct_PerformanceAnalysis)
    {
        FREE(pspTab);
        pspNbr = 0;

        ret = DBA_LoadDomPspTableFromExistingPSP(*hierHeadPtr, domainPtr, dbiConnHelper, computeTab);
    }
    else
    {
        RequestHelper requestHelper(dbiConnHelper);

        for (j = 0; j < 4; j++)
        {
            for (i = 0; i < pspNbr; i++)
            {
                /* Test dates of PSP */
                if (IS_NULLFLD(pspTab[i], *(computeTab[j].fromDIdxPtr)) == FALSE &&
                    IS_NULLFLD(pspTab[i], *(computeTab[j].tillDIdxPtr)) == FALSE &&
                    DATETIME_CMP(GET_DATETIME(pspTab[i], *(computeTab[j].fromDIdxPtr)),
                    GET_DATETIME(domainPtr, *(computeTab[j].domTillDIdxPtr))) <= 0 &&
                    DATETIME_CMP(GET_DATETIME(pspTab[i], *(computeTab[j].tillDIdxPtr)),
                    GET_DATETIME(domainPtr, *(computeTab[j].domFromDIdxPtr))) >= 0)
                {
                    DBA_DYNFLD_STP domPspStp = requestHelper.getNewRecordForBatch(A_DomPsp);
                    SET_ID(domPspStp, A_DomPsp_Id, GET_ID(pspTab[i], A_PerfStorageParam_Id));

                    /* If the date is out of range, modify the PSP */
                    if (DATETIME_CMP(GET_DATETIME(pspTab[i], *(computeTab[j].fromDIdxPtr)),
                        GET_DATETIME(domainPtr, *(computeTab[j].domFromDIdxPtr))) < 0)
                    {
                        SET_DATETIME(domPspStp, A_DomPsp_FromDate, GET_DATETIME(domainPtr, *(computeTab[j].domFromDIdxPtr)));
                    }
                    else
                    {
                        SET_DATETIME(domPspStp, A_DomPsp_FromDate, GET_DATETIME(pspTab[i], *(computeTab[j].fromDIdxPtr)));
                    }

                    if (DATETIME_CMP(GET_DATETIME(pspTab[i], *(computeTab[j].tillDIdxPtr)),
                        GET_DATETIME(domainPtr, *(computeTab[j].domTillDIdxPtr))) > 0)
                    {
                        SET_DATETIME(domPspStp, A_DomPsp_TillDate, GET_DATETIME(domainPtr, *(computeTab[j].domTillDIdxPtr)));
                    }
                    else
                    {
                        SET_DATETIME(domPspStp, A_DomPsp_TillDate, GET_DATETIME(pspTab[i], *(computeTab[j].tillDIdxPtr)));
                    }
                    SET_DICT(domPspStp, A_DomPsp_OutputEntityDictId, computeTab[j].outEntDictId);
                }
            }
        }

        ret = requestHelper.executeBatch();
        FREE(pspTab);
        pspNbr = 0;
    }

    return(ret);
}

/************************************************************************
**
**  Function    :   FIN_FilterParentPtf
**
**  Description :   FIN_FilterParentPtf - get Parent portfolios
**
**  Argument    :   ptf
**
**  Return      :   true/false
**
**  Creation    :   WEALTH-5266 - KOR - 20240325 - Performance IPS Level
**
**  Last modif. :
**
*************************************************************************/
STATIC int FIN_FilterParentPtf(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP notUsed)
{
    if (GET_EXTENSION_PTR(dynSt, A_Ptf_ChildrenPtf_Ext) != NULLDYNSTPTR)
    {
        return(TRUE);
    }
    return(FALSE);
}

/************************************************************************
**  Function             : DBA_LoadPspFromDB()
**
**  Description          : Load and put in hierarchy all PSP according
**                         #vector_id table
**
**  Arguments   :
**
**  Return               : RET_SUCCEED or error code
**
**  Creation             : PMSTA09843 - LJE - 100519
**
*************************************************************************/
STATIC RET_CODE DBA_LoadPspFromDB(DBA_HIER_HEAD_STP				hierHead,
                                  DBA_DYNFLD_STP			    domainPtr,
                                  DbiConnectionHelper&          dbiConnHelper,
                                  RETURNINPARENTPTFRULE_ENUM	returnInParPtfRuleEn)
{
    RET_CODE         ret = RET_SUCCEED;
    DBA_DYNFLD_STP  *pspTab = NULLDYNSTPTR;
    int              pspNbr = 0, i;
    MemoryPool       mp;

    if (static_cast<LOADHIERPTF_ENUM> GET_ENUM(domainPtr, A_Domain_LoadHierFlg) == LoadHierPtf_IntermediateHierarchy)
    {
        DBA_SetHierLnkUsed(hierHead, A_Ptf, A_Ptf_HierChildrenPtf_Ext);
        DBA_SetHierLnkUsed(hierHead, A_Ptf, A_Ptf_ChildrenPtf_Ext);
        DBA_MakeLinks(hierHead);
    }

    /* For intermediate hierachy and Merged TWR w/ Detail, stored PSP is not considered */
    if (static_cast<LOADHIERPTF_ENUM> GET_ENUM(domainPtr, A_Domain_LoadHierFlg) == LoadHierPtf_IntermediateHierarchy &&
        static_cast<PTFCONSRULE_ENUM>GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) == PtfConsRule_MergedTWR_Detail)
    {
        return(RET_SUCCEED);
    }

    /* Select Perf Storage Param in DB, based on temporary table #vector_id */
    if (DBA_Select2(PerfStorageParam,
                    UNUSED,
                    A_Domain,
                    domainPtr,
                    A_PerfStorageParam,
                    &pspTab,
                    UNUSED,
                    &pspNbr,
                    dbiConnHelper) != RET_SUCCEED)
    {
        MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "perf storage param");
        return(RET_DBA_ERR_NODATA);
    }

    if (pspNbr == 0)
    {
        return (ret);
    }

    /* PMSTA-17025 - LJE - 131025 */
    if (GET_DICT(domainPtr, A_Domain_InitialFctDictId) == DictFct_PerformanceAnalysis)
    {
        /* PMSTA-10775 - LJE - 101105 - If non-discretionary case,
                                        remove stored dates on hierarchical PSP to force online */
        if (GET_FLAG(domainPtr, A_Domain_LoadNonDiscretFlg) == TRUE)
        {
            for (i = 0; i < pspNbr; i++)
            {
                if (GET_ENUM(pspTab[i], A_PerfStorageParam_PerfAttribReturnEn) == PerfAttribRtnEn_Hierarchy)
                {
                    SET_NULL_DATETIME(pspTab[i], A_PerfStorageParam_StdPerfFirstStoredDate);
                    SET_NULL_DATETIME(pspTab[i], A_PerfStorageParam_StdPerfLastStoredDate);
                    SET_NULL_DATETIME(pspTab[i], A_PerfStorageParam_RetFirstStoredDate);
                    SET_NULL_DATETIME(pspTab[i], A_PerfStorageParam_RetLastStoredDate);
                    SET_NULL_DATETIME(pspTab[i], A_PerfStorageParam_PerfFirstStoredDate);
                    SET_NULL_DATETIME(pspTab[i], A_PerfStorageParam_PerfLastStoredDate);
                }
            }
        }

        /* Remove "hierarchy" PSP if no hier need -(not for Intermediate- PMSTA-48195 -Performance IPS Level -Lalby-310123 */
        if ((static_cast<LOADHIERPTF_ENUM> GET_ENUM(domainPtr, A_Domain_LoadHierFlg) != LoadHierPtf_IntermediateHierarchy) && (
             GET_ENUM(domainPtr, A_Domain_LoadHierFlg) == LoadHierPtf_None ||
            (PTFCONSRULE_ENUM)GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) == PtfConsRule_DetailedChildren ||
            returnInParPtfRuleEn == ReturnInParentPtfRule_Children))
        {
            for (i = 0; i < pspNbr; i++)
            {
                if (GET_ENUM(pspTab[i], A_PerfStorageParam_PerfAttribReturnEn) == PerfAttribRtnEn_Hierarchy)
                {
                    FREE_DYNST(pspTab[i], A_PerfStorageParam);	/* DBA_AddHierRecordList() accept NULLDYNST in is array */
                }
            }
        }
        /* WEALTH-5266 - KOR - 20240226 */
        else if (static_cast<LOADHIERPTF_ENUM> GET_ENUM(domainPtr, A_Domain_LoadHierFlg) == LoadHierPtf_IntermediateHierarchy)
        {
            DBA_DYNFLD_STP* parPtfTab = NULLDYNSTPTR;
            int parPtfNbr = 0;
            std::map <ID_T, DBA_DYNFLD_STP> parPtfMap;

            /* Extract all the parent portfolio */
            if ((ret = DBA_ExtractHierEltRecWithFilterSt(hierHead, A_Ptf, FALSE,
                                                         FIN_FilterParentPtf, NULL, NULLFCT,
                                                         &parPtfNbr, &parPtfTab)) == RET_SUCCEED &&
                                                         parPtfNbr > 0)
            {
                mp.ownerPtr(parPtfTab);

                for (i = 0; i < parPtfNbr; i++)
                {
                    parPtfMap[GET_ID(parPtfTab[i], A_Ptf_Id)] = parPtfTab[i];
                }

                for (i = 0; i < pspNbr; i++)
                {
                    /* WEALTH-19051 -Lalby - 14032025 - Parent standard PSP is not required for intermediate hierachy - online computation */
                    if (parPtfMap.find(GET_ID(pspTab[i], A_PerfStorageParam_ObjId)) != parPtfMap.end() &&
                        static_cast<PAA_RETURN_ENUM>GET_ENUM(pspTab[i], A_PerfStorageParam_PerfAttribReturnEn) == PerfAttribRtnEn_Standard)
                    {
                        FREE_DYNST(pspTab[i], A_PerfStorageParam);
                    }

                    else if ((PAA_RETURN_ENUM)GET_ENUM(pspTab[i], A_PerfStorageParam_PerfAttribReturnEn) == PerfAttribRtnEn_Hierarchy)
                    {
                        parPtfMap.erase(GET_ID(pspTab[i], A_PerfStorageParam_ObjId));
                    }
                }

                /* For portfolio hierarchy, when one parent portfolio don't have hierarchical stored PSP, free all hierarchical PSP of its hierarchy */
                for (auto& it: parPtfMap )
                {
                    DBA_DYNFLD_STP   parPtfStp = it.second;

                    if (parPtfStp != NULLDYNST)
                    {
                        DBA_DYNFLD_STP* hierParentPtfTab = NULLDYNSTPTR;
                        int             hierParentPtfNbr = 0;

                        FIN_FindHierParentPortfolio(domainPtr, UNUSED, parPtfStp, hierHead, &hierParentPtfTab, &hierParentPtfNbr);
                        mp.ownerPtr(hierParentPtfTab);

                        for (int hierParentPtfIdx = 0; hierParentPtfIdx < hierParentPtfNbr; ++hierParentPtfIdx)
                        {
                            DBA_DYNFLD_STP* hierChildrenTab = GET_EXTENSION_PTR(hierParentPtfTab[hierParentPtfIdx], A_Ptf_HierChildrenPtf_Ext);
                            int             hierChildrenNbr = GET_EXTENSION_NBR(hierParentPtfTab[hierParentPtfIdx], A_Ptf_HierChildrenPtf_Ext);

                            for (i = 0; i < pspNbr; i++)
                            {
                                if (pspTab[i] != NULLDYNST &&
                                    GET_ID(hierParentPtfTab[hierParentPtfIdx], A_Ptf_Id) == GET_ID(pspTab[i], A_PerfStorageParam_ObjId) &&
                                    (PAA_RETURN_ENUM)GET_ENUM(pspTab[i], A_PerfStorageParam_PerfAttribReturnEn) == PerfAttribRtnEn_Hierarchy)
                                {
                                    parPtfMap.erase(GET_ID(pspTab[i], A_PerfStorageParam_ObjId));
                                    FREE_DYNST(pspTab[i], A_PerfStorageParam);
                                }
                            }

                            for (int childIdx = 0; childIdx < hierChildrenNbr; ++childIdx)
                            {
                                for (i = 0; i < pspNbr; i++)
                                {
                                    if (pspTab[i] != NULLDYNST &&
                                        GET_ID(hierChildrenTab[childIdx], A_Ptf_Id) == GET_ID(pspTab[i], A_PerfStorageParam_ObjId) &&
                                        (PAA_RETURN_ENUM)GET_ENUM(pspTab[i], A_PerfStorageParam_PerfAttribReturnEn) == PerfAttribRtnEn_Hierarchy)
                                    {
                                        parPtfMap.erase(GET_ID(pspTab[i], A_PerfStorageParam_ObjId));
                                        FREE_DYNST(pspTab[i], A_PerfStorageParam);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if ((ret = DBA_AddHierRecordList(hierHead,
        pspTab,
        pspNbr,
        A_PerfStorageParam,
        TRUE)) != RET_SUCCEED)
    {
        return(ret);
    }

    FREE(pspTab);

    return (ret);
}

/************************************************************************
**  Function             : DBA_ConsolidObjectLinks()
**
**  Description          :
**
**  Arguments            :
**
**  Return               :
**
**  Creation             : REF9770 - LJE - 040317
**
*************************************************************************/
RET_CODE DBA_ConsolidObjectLinks(DBA_HIER_HEAD_STP  hierHead,
                                 DBA_DYNFLD_STP     domainPtr)
{

    DBA_DYNFLD_STP *allObjLnkTab, *pspObjLnkTab, *gridObjLnkTab, *copyGridObjLnkTab;
    int             allObjLnkNbr, pspObjLnkNbr, gridObjLnkNbr, copyGridObjLnkNbr;
    int             i;

    /* REF10591 - LJE - 040906 */
    DBA_HierEltRecExtract(hierHead,
                          A_ObjectLnk,
                          FALSE,
                          NULL,
                          NULL,
                          DBA_CmpObjectLnkGridPAA,
                          FALSE,
                          FALSE,
                          &allObjLnkNbr,
                          &allObjLnkTab);

    for (i = 1; i < allObjLnkNbr; i++)
    {
        if (GET_ENUM(allObjLnkTab[i], A_ObjectLnk_Nature) == (ENUM_T)ObjectLnkNat_Grid &&
            GET_ID(allObjLnkTab[i], A_ObjectLnk_ToObjectId) < 0)
        {
            SET_NULL_ID(allObjLnkTab[i], A_ObjectLnk_ToObjectId);
        }
    }
    FREE(allObjLnkTab);

    DBA_HierEltRecExtract(hierHead,
                          A_ObjectLnk,
                          FALSE,
                          NULL,
                          NULL,
                          DBA_CmpObjectLnkGridPAA,
                          FALSE,
                          FALSE,
                          &allObjLnkNbr,
                          &allObjLnkTab);

    if (allObjLnkNbr > 1)
    {
        for (i = 1; i < allObjLnkNbr; i++)
        {

            /* REF9770 - LJE - 040316 */
            if (CMP_DYNFLD(allObjLnkTab[i], allObjLnkTab[i - 1], A_ObjectLnk_Rank, A_ObjectLnk_Rank, IntType) == 0 && /* PMSTA50244 - MKK - 230123 */
                CMP_DYNFLD(allObjLnkTab[i], allObjLnkTab[i - 1], A_ObjectLnk_Nature, A_ObjectLnk_Nature, EnumType) == 0 &&

                CMP_DYNFLD(allObjLnkTab[i], allObjLnkTab[i - 1], A_ObjectLnk_FromEntDictId, A_ObjectLnk_FromEntDictId, DictType) == 0 &&
                CMP_DYNFLD(allObjLnkTab[i], allObjLnkTab[i - 1], A_ObjectLnk_FromObjectId, A_ObjectLnk_FromObjectId, IdType) == 0 &&
                CMP_DYNFLD(allObjLnkTab[i], allObjLnkTab[i - 1], A_ObjectLnk_ToEntDictId, A_ObjectLnk_ToEntDictId, DictType) == 0 &&
                CMP_DYNFLD(allObjLnkTab[i], allObjLnkTab[i - 1], A_ObjectLnk_ToObjectId, A_ObjectLnk_ToObjectId, IdType) == 0 &&

                CMP_DYNFLD(allObjLnkTab[i], allObjLnkTab[i - 1], A_ObjectLnk_BeginDate, A_ObjectLnk_BeginDate, DatetimeType) == 0 && /* PMSTA-12966 - LJE - 120322 */
                CMP_DYNFLD(allObjLnkTab[i], allObjLnkTab[i - 1], A_ObjectLnk_EndDate, A_ObjectLnk_EndDate, DatetimeType) == 0)
            {
                DBA_DelAndFreeHierEltRec(hierHead, A_ObjectLnk, allObjLnkTab[i - 1]);
            }
        }

    }

    FREE(allObjLnkTab);

    DBA_HierEltRecExtract(hierHead,
                          A_ObjectLnk,
                          FALSE,
                          NULL,
                          NULL,
                          DBA_CmpObjectLnkGridPAA,
                          FALSE,
                          FALSE,
                          &allObjLnkNbr,
                          &allObjLnkTab);

    if (allObjLnkNbr > 1)
    {
        for (i = 1; i < allObjLnkNbr; i++)
        {
            /* REF9770 - LJE - 040316 */ /* WEALTH-6313 - DDV - 240328 - Chnage condition to allow merge of ObjectLnkNat_PSPPA ObjectLnkNat_PSPSP and ObjectLnkNat_PSPExtRA*/
            if (
                CMP_DYNFLD(allObjLnkTab[i], allObjLnkTab[i - 1], A_ObjectLnk_Rank, A_ObjectLnk_Rank, IntType) == 0 && /* PMSTA50244 - MKK - 230123 */
                CMP_DYNFLD(allObjLnkTab[i], allObjLnkTab[i - 1], A_ObjectLnk_Nature, A_ObjectLnk_Nature, EnumType) == 0 &&

                CMP_DYNFLD(allObjLnkTab[i], allObjLnkTab[i - 1], A_ObjectLnk_FromEntDictId, A_ObjectLnk_FromEntDictId, DictType) == 0 &&
                CMP_DYNFLD(allObjLnkTab[i], allObjLnkTab[i - 1], A_ObjectLnk_FromObjectId, A_ObjectLnk_FromObjectId, IdType) == 0 &&
                CMP_DYNFLD(allObjLnkTab[i], allObjLnkTab[i - 1], A_ObjectLnk_ToEntDictId, A_ObjectLnk_ToEntDictId, DictType) == 0 &&
                CMP_DYNFLD(allObjLnkTab[i], allObjLnkTab[i - 1], A_ObjectLnk_ToObjectId, A_ObjectLnk_ToObjectId, IdType) == 0 &&

                CMP_DYNFLD(allObjLnkTab[i], allObjLnkTab[i - 1], A_ObjectLnk_EndDate, A_ObjectLnk_BeginDate, DatetimeType) >= 0 &&
                CMP_DYNFLD(allObjLnkTab[i], allObjLnkTab[i - 1], A_ObjectLnk_EndDate, A_ObjectLnk_EndDate, DatetimeType) <= 0)
            {
                if (CMP_DYNFLD(allObjLnkTab[i - 1], allObjLnkTab[i], A_ObjectLnk_EndDate, A_ObjectLnk_EndDate, DatetimeType) > 0)
                {
                    COPY_DYNFLD(allObjLnkTab[i], A_ObjectLnk, A_ObjectLnk_EndDate, allObjLnkTab[i - 1], A_ObjectLnk, A_ObjectLnk_EndDate);
                }
                if (CMP_DYNFLD(allObjLnkTab[i - 1], allObjLnkTab[i], A_ObjectLnk_BeginDate, A_ObjectLnk_BeginDate, DatetimeType) < 0)
                {
                    COPY_DYNFLD(allObjLnkTab[i], A_ObjectLnk, A_ObjectLnk_BeginDate, allObjLnkTab[i - 1], A_ObjectLnk, A_ObjectLnk_BeginDate);
                }

                DBA_DelAndFreeHierEltRec(hierHead, A_ObjectLnk, allObjLnkTab[i - 1]);
            }
        }
    }

    FREE(allObjLnkTab);

    /* REF9770 - LJE - 040317 : Put correct begin and end date into PSP objects links */
    DBA_HierEltRecExtract(hierHead,
                          A_ObjectLnk,
                          FALSE,
                          DBA_FilterObjectLnkPSPPAA,
                          NULL,
                          DBA_CmpObjectLnkPAA, /* REF11474 - LJE - 060301 */
                          FALSE,
                          FALSE,
                          &pspObjLnkNbr,
                          &pspObjLnkTab);

    DBA_HierEltRecExtract(hierHead,
                          A_ObjectLnk,
                          FALSE,
                          DBA_FilterObjectLnkGridPAA,
                          NULL,
                          DBA_CmpObjectLnkGridPAA,
                          FALSE,
                          FALSE,
                          &gridObjLnkNbr,
                          &gridObjLnkTab);

    DBA_HierEltRecExtract(hierHead,
                          A_ObjectLnk,
                          FALSE,
                          DBA_FilterObjectLnkCopyGridPAA,
                          NULL,
                          DBA_CmpObjectLnkGridPAA,
                          FALSE,
                          FALSE,
                          &copyGridObjLnkNbr,
                          &copyGridObjLnkTab);

    if (pspObjLnkNbr > 0 && gridObjLnkNbr > 0)
    {
#if 0  /* WEALTH-6313 - DDV - 240328 - Remove useless code */
        /* PMSTA05979 - LJE - 080404 : Change logic */
        int maxPosPSP, minPosPSP;
        for (computePaaPos = 0; computePaaPos < 4; computePaaPos++)
        {
            if (computeTab[computePaaPos].insertFlg)
            {
                /* Browse GridLnk */
                for (gridPos = 0; gridPos < gridObjLnkNbr; gridPos++)
                {
                    maxPosPSP = -1;
                    minPosPSP = -1;

                    /* Search min and max PSP */
                    for (i = 0; i < pspObjLnkNbr; i++)
                    {
                        if (GET_ENUM(pspObjLnkTab[i], A_ObjectLnk_Nature) != computeTab[computePaaPos].objLnkNat)
                            continue;

                        /* PMSTA06912 - LJE - 080708 */
                        if (IS_NULLFLD(pspObjLnkTab[i], A_ObjectLnk_BeginDate) == TRUE ||
                            IS_NULLFLD(pspObjLnkTab[i], A_ObjectLnk_EndDate) == TRUE)
                            continue;
                    }

                    if (minPosPSP >= 0 && maxPosPSP >= 0)
                    {
                        /* Change begin date */
                        if (CMP_DYNFLD(pspObjLnkTab[minPosPSP], gridObjLnkTab[gridPos],
                            A_ObjectLnk_BeginDate, A_ObjectLnk_BeginDate, DatetimeType) > 0)
                        {
                            COPY_DYNFLD(pspObjLnkTab[minPosPSP], A_ObjectLnk, A_ObjectLnk_BeginDate,
                                        gridObjLnkTab[gridPos], A_ObjectLnk, A_ObjectLnk_BeginDate);
                        }

                        if (CMP_DYNFLD(pspObjLnkTab[minPosPSP], domainPtr,
                            A_ObjectLnk_BeginDate, *(computeTab[computePaaPos].domFromDIdxPtr), DatetimeType) < 0)
                        {
                            COPY_DYNFLD(pspObjLnkTab[minPosPSP], A_ObjectLnk, A_ObjectLnk_BeginDate,
                                        domainPtr, A_Domain, *(computeTab[computePaaPos].domFromDIdxPtr));
                        }

                        /* Change end date */
                        if (CMP_DYNFLD(pspObjLnkTab[maxPosPSP], gridObjLnkTab[gridPos],
                            A_ObjectLnk_EndDate, A_ObjectLnk_EndDate, DatetimeType) < 0)
                        {
                            COPY_DYNFLD(pspObjLnkTab[maxPosPSP], A_ObjectLnk, A_ObjectLnk_EndDate,
                                        gridObjLnkTab[gridPos], A_ObjectLnk, A_ObjectLnk_EndDate);
                        }

                        if (CMP_DYNFLD(pspObjLnkTab[maxPosPSP], domainPtr,
                            A_ObjectLnk_EndDate, *(computeTab[computePaaPos].domTillDIdxPtr), DatetimeType) > 0)
                        {
                            COPY_DYNFLD(pspObjLnkTab[maxPosPSP], A_ObjectLnk, A_ObjectLnk_EndDate,
                                        domainPtr, A_Domain, *(computeTab[computePaaPos].domTillDIdxPtr));
                        }

                        /* REF10334 - LJE - 040604 : Search "copy grid" to change begin date */ /* REF10540 - LJE - 040823 */
                        for (copyGridPos = 0; copyGridPos < copyGridObjLnkNbr; copyGridPos++)
                        {
                            if (CMP_DYNFLD(copyGridObjLnkTab[copyGridPos], pspObjLnkTab[minPosPSP],
                                A_ObjectLnk_FromEntDictId, A_ObjectLnk_ToEntDictId, DictType) == 0 &&
                                CMP_DYNFLD(copyGridObjLnkTab[copyGridPos], pspObjLnkTab[minPosPSP],
                                A_ObjectLnk_FromObjectId, A_ObjectLnk_ToObjectId, IdType) == 0 &&
                                CMP_DYNFLD(copyGridObjLnkTab[copyGridPos], gridObjLnkTab[gridPos],
                                A_ObjectLnk_ToObjectId, A_ObjectLnk_ToObjectId, IdType) != 0 &&
                                CMP_DYNFLD(pspObjLnkTab[minPosPSP], copyGridObjLnkTab[copyGridPos],
                                A_ObjectLnk_BeginDate, A_ObjectLnk_BeginDate, DatetimeType) < 0)
                            {

                                COPY_DYNFLD(copyGridObjLnkTab[copyGridPos], A_ObjectLnk, A_ObjectLnk_BeginDate,
                                            pspObjLnkTab[minPosPSP], A_ObjectLnk, A_ObjectLnk_BeginDate);
                                break;
                            }
                        }
                    }
                }
            }
        }
#endif

        /* REF10236 - LJE - 040422 */
        for (i = 0; i < pspObjLnkNbr; i++)
        {
            if (IS_NULLFLD(pspObjLnkTab[i], A_ObjectLnk_BeginDate) == FALSE &&/* PMSTA06912 - LJE - 080708 */
                IS_NULLFLD(pspObjLnkTab[i], A_ObjectLnk_EndDate) == FALSE &&
                CMP_DYNFLD(pspObjLnkTab[i], pspObjLnkTab[i], A_ObjectLnk_EndDate, A_ObjectLnk_BeginDate, DatetimeType) == 0)
            {
                DBA_DelAndFreeHierEltRec(hierHead, A_ObjectLnk, pspObjLnkTab[i]);
            }

        }
    }

    FREE(pspObjLnkTab);
    FREE(gridObjLnkTab);
    FREE(copyGridObjLnkTab); /* REF10334 - LJE - 040604 */

    return (RET_SUCCEED);
}

/************************************************************************
**  Function             : DBA_InsertAllDomPSP()
**
**  Description          :
**
**  Arguments            :
**
**  Return               :
**
**  Creation             : PMSTA-12966 - LJE - 120320
**
*************************************************************************/
STATIC RET_CODE DBA_InsertAllDomPSP(DBA_HIER_HEAD_STP    hierHead,
                                    DBA_DYNFLD_STP       domainPtr,
                                    DbiConnectionHelper& dbiConnHelper,
                                    COMPUTE_PAA_STP      computeTab)
{
    RET_CODE            ret = RET_SUCCEED;
    DBA_DYNFLD_STP	   *pspObjLnkTab, validPspStp;
    int					pspObjLnkNbr;
    int					i, k;
    RequestHelper       requestHelper(dbiConnHelper);

    /* REF10591 - LJE - 040906 */
    DBA_HierEltRecExtract(hierHead,
                          A_ObjectLnk,
                          FALSE,
                          FIN_FilterPSPObjectLnk,
                          NULL,
                          DBA_CmpObjectLnkGridPAA,
                          FALSE,
                          FALSE,
                          &pspObjLnkNbr,
                          &pspObjLnkTab);

    for (i = 0; i < pspObjLnkNbr; i++)
    {
        switch ((OBJECTLNK_NAT_ENUM)GET_ENUM(pspObjLnkTab[i], A_ObjectLnk_Nature))
        {
            case ObjectLnkNat_PSPPA:
                k = 0;
                break;
            case ObjectLnkNat_PSPExtRA:
                k = 1;
                break;
            case ObjectLnkNat_PSPSP:
                k = 2;
                break;
            case ObjectLnkNat_PSPPCR:
                k = 3;
                break;
            default:
                /* Not valid */
                k = -1;
                break;
        }

        if (k >= 0)
        {
            /* Get the PSP */
            DBA_GetRecPtrFromHierById(hierHead,
                                      GET_ID(pspObjLnkTab[i], A_ObjectLnk_ToObjectId),
                                      A_PerfStorageParam,
                                      &validPspStp);

            DBA_InsertObjLnkIntoDomPSP(&(computeTab[k]), pspObjLnkTab[i], validPspStp, domainPtr, requestHelper);
        }
    }

    ret = requestHelper.executeBatch();

    FREE(pspObjLnkTab);

    return ret;
}

/************************************************************************
**
**  Function    :   DBA_CmpObjLnkByRkDtPAA()
**
**  Description :
**
**  Arguments   :   ptr1   pointer on dynamic structure
**                  ptr2   pointer on dynamic structure
**
**  Return      :   a negative value if first element < second element
**                  a zero value     if first element = second element
**                  a positive value if first element > second element
**
*************************************************************************/
STATIC int DBA_CmpObjLnkByRkDtPAA(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    int cmp = 0;

    if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2), A_ObjectLnk_FromEntDictId, A_ObjectLnk_FromEntDictId, DictType)) != 0)
        return cmp;

    if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2), A_ObjectLnk_FromObjectId, A_ObjectLnk_FromObjectId, IdType)) != 0)
        return cmp;

    if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2), A_ObjectLnk_Nature, A_ObjectLnk_Nature, EnumType)) != 0)
        return cmp;

    if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2), A_ObjectLnk_Rank, A_ObjectLnk_Rank, IntType)) != 0) /* PMSTA50244 - MKK - 230123 */
        return cmp;

    if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2), A_ObjectLnk_BeginDate, A_ObjectLnk_BeginDate, DatetimeType)) != 0)
        return cmp;
        
    if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2), A_ObjectLnk_EndDate, A_ObjectLnk_EndDate, DatetimeType)) != 0)
        return cmp;

    if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2), A_ObjectLnk_ToEntDictId, A_ObjectLnk_ToEntDictId, DictType)) != 0)
        return cmp;

    if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2), A_ObjectLnk_ToObjectId, A_ObjectLnk_ToObjectId, IdType)) != 0)
        return cmp;

    return cmp;
}

/************************************************************************
**
**  Function    :   DBA_FilterBenchObjLnkPAA()
**
**  Description :
**
**  Arguments   :   dynSt    element pointer
**                  dynStTp  element description enum
**
**  Return      : TRUE or FALSE
**
**  Creation Date : PMSTA-12261 - LJE - 110708
**
*************************************************************************/
STATIC int DBA_FilterBenchObjLnkPAA(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP notUse)
{
    if (GET_ENUM(dynSt, A_ObjectLnk_Nature) == (ENUM_T)ObjectLnkNat_Bench)
        return (TRUE);

    return(FALSE);
}

/************************************************************************
**  Function             : DBA_ManageMergedObjects()
**
**  Description          :
**
**  Arguments            :
**
**  Return               :
**
**  Creation             : PMSTA-12261 - LJE - 110708
**
*************************************************************************/
STATIC RET_CODE DBA_ManageMergedObjects(DBA_HIER_HEAD_STP  hierHead,
                                        DBA_DYNFLD_STP      domainPtr,
                                        COMPUTE_PAA_STP     computeTab)
{

    DBA_DYNFLD_STP *gridObjLnkTab = NULL, *pspObjLnkTab = NULL, *benchObjLnkTab = NULL,
        pspEltStp;
    int             gridObjLnkNbr = 0, pspObjLnkNbr, benchObjLnkNbr;
    FLAG_T          setToNullGridFlg = FALSE, removeBenchFlg = FALSE;

    if (GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) == PtfConsRule_Merged )
    {
        DBA_HierEltRecExtract(hierHead,
                              A_ObjectLnk,
                              FALSE,
                              DBA_FilterObjectLnkGridPAA,
                              NULL,
                              DBA_CmpObjLnkByRkDtPAA,
                              FALSE,
                              FALSE,
                              &gridObjLnkNbr,
                              &gridObjLnkTab);

        if (gridObjLnkNbr > 0)
        {
            /* WEALTH-7310 -JBC - 20240520 - redo grid logic for sub-periods */
            std::set<ID_T> uniqueGrids;
            DatePeriodSet  uniquePeriods;
            for (int i = 0; i < gridObjLnkNbr; i++)
            {
                if(GET_ID(gridObjLnkTab[i],A_ObjectLnk_ToObjectId) > ZERO_ID)
                {
                    uniqueGrids.insert(GET_ID(gridObjLnkTab[i],A_ObjectLnk_ToObjectId));
                    uniquePeriods.insert(GET_DATETIME(gridObjLnkTab[i], A_ObjectLnk_BeginDate),GET_DATETIME(gridObjLnkTab[i], A_ObjectLnk_EndDate));
                }
            }

            if(uniqueGrids.size() > 1)
            {
                for(auto it = uniquePeriods.begin(); it != uniquePeriods.end() &&  setToNullGridFlg == FALSE;++it)
                {
                    DatePeriod compPeriod = *it;
                    std::set<ID_T> periodGridSet;
                    for (int i = 0; i < gridObjLnkNbr; i++)
                    {   
                        if(GET_ID(gridObjLnkTab[i],A_ObjectLnk_ToObjectId) == ZERO_ID
                            || compPeriod.cmpBegin(GET_DATETIME(gridObjLnkTab[i], A_ObjectLnk_EndDate)) >= 0 || compPeriod.cmpEnd(GET_DATETIME(gridObjLnkTab[i], A_ObjectLnk_BeginDate)) <= 0)  
                        {   // skip if out of range
                            continue;
                        }

                        if(periodGridSet.count(GET_ID(gridObjLnkTab[i],A_ObjectLnk_ToObjectId)) == 0
                            && periodGridSet.empty() == false)
                        {   // too many grids
                            setToNullGridFlg = TRUE;
                            break;
                        }

                        periodGridSet.insert(GET_ID(gridObjLnkTab[i],A_ObjectLnk_ToObjectId));
                    }
                }
            }
        }

        DBA_HierEltRecExtract(hierHead,
                              A_ObjectLnk,
                              FALSE,
                              DBA_FilterBenchObjLnkPAA,
                              NULL,
                              DBA_CmpObjLnkByRkDtPAA,
                              FALSE,
                              FALSE,
                              &benchObjLnkNbr,
                              &benchObjLnkTab);

        if (benchObjLnkNbr > 0)
        {
            for (int i = 1; i < benchObjLnkNbr && removeBenchFlg == FALSE; i++)
            {
                if (CMP_DYNFLD(benchObjLnkTab[i], benchObjLnkTab[i - 1],
                    A_ObjectLnk_BeginDate, A_ObjectLnk_BeginDate, DatetimeType) == 0 &&
                    CMP_DYNFLD(benchObjLnkTab[i], benchObjLnkTab[i - 1],
                    A_ObjectLnk_ToObjectId, A_ObjectLnk_ToObjectId, IdType) != 0 &&
                    CMP_DYNFLD(benchObjLnkTab[i], benchObjLnkTab[i - 1],
                    A_ObjectLnk_Rank, A_ObjectLnk_Rank, IntType) == 0) /* PMSTA50244 - MKK - 230123 */
                {
                    removeBenchFlg = TRUE;
                }
            }

            if (removeBenchFlg == TRUE)
            {
                for (int i = 0; i < benchObjLnkNbr; i++)
                {
                    SET_NULL_ENUM(benchObjLnkTab[i], A_ObjectLnk_Nature);
                    SET_NULL_DICT(benchObjLnkTab[i], A_ObjectLnk_ToEntDictId);
                    SET_NULL_ID(benchObjLnkTab[i], A_ObjectLnk_ToObjectId);
                }
            }

            FREE(benchObjLnkTab);
        }
    }

    if (setToNullGridFlg == TRUE)
    {
        int eltNbr;

        /* Reset grid needed */
        for (int i = 1; i < gridObjLnkNbr; i++)
        {
            SET_NULL_ID(gridObjLnkTab[i], A_ObjectLnk_ToObjectId);
        }

        /* Remove all "copy grid" */
        DBA_DelHierEltRecWithFilter(hierHead,
                                    A_ObjectLnk,
                                    DBA_FilterObjectLnkCopyGridPAA,
                                    NULL,
                                    &eltNbr);

        DBA_HierEltRecExtract(hierHead,
                              A_ObjectLnk,
                              FALSE,
                              FIN_FilterPSPObjectLnk,
                              NULL,
                              DBA_CmpObjectLnkGridPAA,
                              FALSE,
                              FALSE,
                              &pspObjLnkNbr,
                              &pspObjLnkTab);

        for (int i = 0; i < pspObjLnkNbr; i++)
        {
            /* Remove all object link on perf attrib */
            if (GET_ENUM(pspObjLnkTab[i], A_ObjectLnk_Nature) == (ENUM_T)ObjectLnkNat_PSPPA)
            {
                DBA_DelAndFreeHierEltRec(hierHead, A_ObjectLnk, pspObjLnkTab[i]);
            }
            else
            {
                FREE(gridObjLnkTab);
                gridObjLnkNbr = 0;
                DBA_HierEltRecExtract(hierHead,
                                      A_ObjectLnk,
                                      FALSE,
                                      DBA_FilterObjectLnkGridPAA,
                                      pspObjLnkTab[i],
                                      DBA_CmpObjLnkByRkDtPAA,
                                      FALSE,
                                      FALSE,
                                      &gridObjLnkNbr,
                                      &gridObjLnkTab);

                /* Get the PSP */
                DBA_GetRecPtrFromHierById(hierHead,
                                          GET_ID(pspObjLnkTab[i], A_ObjectLnk_ToObjectId),
                                          A_PerfStorageParam,
                                          &pspEltStp);

                if (pspEltStp != NULL && gridObjLnkNbr != 0)
                {
                    if (GET_ID(pspEltStp, A_PerfStorageParam_Id) < 0)
                    {
                        SET_NULL_ID(pspEltStp, A_PerfStorageParam_GridId);

                        /* PMSTA-16754 - LJE - 140106 */
                        for (int j = 0; j < gridObjLnkNbr; j++)
                        {
                            SET_NULL_ID(gridObjLnkTab[j], A_ObjectLnk_ToObjectId);
                        }
                    }
                    else
                    {
                        /* Create a copy grid */

                        DBA_DYNFLD_STP  copyGridObjLnkStp;

                        /* Build a "copy grid" object link */
                        if ((copyGridObjLnkStp = ALLOC_DYNST(A_ObjectLnk)) == NULLDYNST)
                        {
                            FREE(pspObjLnkTab);
                            FREE(gridObjLnkTab);
                            MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
                            return RET_MEM_ERR_ALLOC;
                        }

                        SET_ENUM(copyGridObjLnkStp, A_ObjectLnk_Nature, ObjectLnkNat_SPCopyGrid);
                        SET_INT(copyGridObjLnkStp, A_ObjectLnk_Rank, 0); /* PMSTA50244 - MKK - 230123 */

                        SET_DICT(copyGridObjLnkStp, A_ObjectLnk_FromEntDictId, computeTab->pspEntDictId);
                        COPY_DYNFLD(copyGridObjLnkStp, A_ObjectLnk, A_ObjectLnk_FromObjectId,
                                    pspEltStp, A_PerfStorageParam, A_PerfStorageParam_Id);

                        COPY_DYNFLD(copyGridObjLnkStp, A_ObjectLnk, A_ObjectLnk_BeginDate,
                                    pspObjLnkTab[i], A_ObjectLnk, A_ObjectLnk_BeginDate);

                        COPY_DYNFLD(copyGridObjLnkStp, A_ObjectLnk, A_ObjectLnk_EndDate,
                                    pspObjLnkTab[i], A_ObjectLnk, A_ObjectLnk_EndDate);

                        SET_DICT(copyGridObjLnkStp, A_ObjectLnk_ToEntDictId, computeTab->gridEntDictId);

                        DBA_AddHierRecord(hierHead,
                                          copyGridObjLnkStp,
                                          A_ObjectLnk,
                                          FALSE,
                                          HierAddRec_NoLnk);
                    }
                }
                else if (removeBenchFlg == TRUE)
                {
                    if (pspEltStp != NULL)
                    {
                        DBA_DelAndFreeHierEltRec(hierHead, A_PerfStorageParam, pspEltStp);
                    }
                    DBA_DelAndFreeHierEltRec(hierHead, A_ObjectLnk, pspObjLnkTab[i]);
                }
            }
        }
        FREE(pspObjLnkTab);
    }

    FREE(gridObjLnkTab);

    return (RET_SUCCEED);
}

/************************************************************************
**  Function             : DBA_RemoveUnusedPSPFromHier()
**
**  Description          : Delete from hierarchy all PSP without an object link
**
**  Arguments            :
**
**  Return               : RET_SUCCEED or error code
**
**  Creation             : REF9340 - DDV - 031007
**
*************************************************************************/
RET_CODE DBA_RemoveUnusedPSPFromHier(DBA_HIER_HEAD_STP hierHead)
{
    int                pspNbr = 0, objLnkNbr = 0, pspIdx = 0, objLnkIdx = 0;
    DBA_DYNFLD_STP     *pspTab = NULLDYNSTPTR, *objLnkTab = NULLDYNSTPTR;
    RET_CODE           ret = RET_SUCCEED;

    if ((ret = DBA_ExtractHierEltRec(hierHead, A_PerfStorageParam, FALSE,
        NULLFCT, FIN_CmpPSPId,
        &pspNbr, &pspTab)) != RET_SUCCEED)
    {
        return(ret);
    }

    if ((ret = DBA_ExtractHierEltRec(hierHead, A_ObjectLnk, FALSE,
        FIN_FilterPSPObjectLnk, FIN_CmpObjectLnkToObjectId,
        &objLnkNbr, &objLnkTab)) != RET_SUCCEED)
    {
        FREE(pspTab);
        return(ret);
    }

    for (pspIdx = 0, objLnkIdx = 0; pspIdx < pspNbr; pspIdx++)
    {
        while (objLnkIdx < objLnkNbr &&
               CMP_DYNFLD(objLnkTab[objLnkIdx], pspTab[pspIdx], A_ObjectLnk_ToObjectId, A_PerfStorageParam_Id, IdType) < 0)
               objLnkIdx++;

        if (objLnkIdx == objLnkNbr ||
            CMP_DYNFLD(objLnkTab[objLnkIdx], pspTab[pspIdx], A_ObjectLnk_ToObjectId, A_PerfStorageParam_Id, IdType) > 0)
        {
            DBA_DelAndFreeHierEltRec(hierHead, A_PerfStorageParam, pspTab[pspIdx]);
        }
    }

    FREE(pspTab);
    FREE(objLnkTab);

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_FilterPSPObjectLnk()
**
**  Description :
**
**  Arguments   :   dynSt    element pointer
**                  dynStTp  element description enum
**
**  Return      : TRUE or FALSE
**
**  Creation Date : REF7758 - DDV - 021104
**
*************************************************************************/
STATIC int FIN_FilterPSPObjectLnk(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP unUsed)
{
    if (IS_NULLFLD(dynSt, A_ObjectLnk_Nature) == FALSE &&
        (GET_ENUM(dynSt, A_ObjectLnk_Nature) == (ENUM_T)ObjectLnkNat_PSPSP ||
        GET_ENUM(dynSt, A_ObjectLnk_Nature) == (ENUM_T)ObjectLnkNat_PSPPA ||
        GET_ENUM(dynSt, A_ObjectLnk_Nature) == (ENUM_T)ObjectLnkNat_PSPExtRA||
        GET_ENUM(dynSt, A_ObjectLnk_Nature) == (ENUM_T)ObjectLnkNat_PSPPCR))/*PMSTA-54344 - SENTHIL - 230823*/
        return(TRUE);

    return(FALSE);
}

/************************************************************************
**
**  Function    :   FIN_CmpPSPEntityObjectId()
**
**  Description :   PerfStorageParam are sorted by A_PerfStorageParam_Id and
**
**  Arguments   :   ptr1   pointer on dynamic structure type A_PerfStorageParam
**                  ptr2   pointer on dynamic structure type A_PerfStorageParam
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation D. : REF7758 - DDV - 021113
**  Last modif. :
**
*************************************************************************/
STATIC int FIN_CmpPSPId(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    return(CMP_DYNFLD(*ptr1, *ptr2, A_PerfStorageParam_Id, A_PerfStorageParam_Id, IdType));
}

/************************************************************************
**
**  Function    :   DBA_FilterObjectLnkGridPAA()
**
**  Description :
**
**  Arguments   :   dynSt    element pointer
**                  dynStTp  element description enum
**
**  Return      : TRUE or FALSE
**
**  Creation Date : REF9187 - LJE - 040206
**
*************************************************************************/
STATIC int DBA_FilterObjectLnkGridPAA(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP testDynSt)
{
    if (IS_NULLFLD(dynSt, A_ObjectLnk_Nature) == FALSE                         &&
        GET_ENUM(dynSt, A_ObjectLnk_Nature) == (ENUM_T)ObjectLnkNat_Grid)
    {
        /* PMSTA09843 - LJE - 100525 */
        if (testDynSt != NULL &&
            (CMP_DYNFLD(dynSt, testDynSt,
            A_ObjectLnk_FromEntDictId, A_ObjectLnk_FromEntDictId, DictType) != 0 ||
            CMP_DYNFLD(dynSt, testDynSt,
            A_ObjectLnk_FromObjectId, A_ObjectLnk_FromObjectId, IdType) != 0 ||
            CMP_DYNFLD(dynSt, testDynSt, A_ObjectLnk_BeginDate,
            A_ObjectLnk_EndDate, DatetimeType) >= 0 ||
            CMP_DYNFLD(dynSt, testDynSt, A_ObjectLnk_EndDate,
            A_ObjectLnk_BeginDate, DatetimeType) <= 0))
        {
            return(FALSE);
        }
        return(TRUE);
    }
    return(FALSE);
}

/************************************************************************
**
**  Function    :   DBA_FilterObjectLnkFromObj()
**
**  Description :
**
**  Arguments   :   dynSt    element pointer
**                  dynStTp  element description enum
**
**  Return      : TRUE or FALSE
**
**  Creation Date :
**
*************************************************************************/
STATIC int DBA_FilterObjectLnkFromObj(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP testDynSt)
{
    if (CMP_DYNFLD(dynSt, testDynSt,
        A_ObjectLnk_FromEntDictId, A_ObjectLnk_FromEntDictId, DictType) != 0 ||
        CMP_DYNFLD(dynSt, testDynSt,
        A_ObjectLnk_FromObjectId, A_ObjectLnk_FromObjectId, IdType) != 0 ||
        CMP_DYNFLD(dynSt, testDynSt,
        A_ObjectLnk_BeginDate, A_ObjectLnk_BeginDate, DatetimeType) < 0 ||
        CMP_DYNFLD(dynSt, testDynSt,
        A_ObjectLnk_EndDate, A_ObjectLnk_EndDate, DatetimeType) > 0)
    {
        return(FALSE);
    }
    return(TRUE);
}

/************************************************************************
**
**  Function    :   DBA_FilterObjectLnkCopyGridPAA()
**
**  Description :
**
**  Arguments   :   dynSt    element pointer
**                  dynStTp  element description enum
**
**  Return      : TRUE or FALSE
**
**  Creation Date : REF10334 - LJE - 040604
**
*************************************************************************/
STATIC int DBA_FilterObjectLnkCopyGridPAA(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP testDynSt)
{
    if (IS_NULLFLD(dynSt, A_ObjectLnk_Nature) == FALSE &&
        (OBJECTLNK_NAT_ENUM)GET_ENUM(dynSt, A_ObjectLnk_Nature) == ObjectLnkNat_SPCopyGrid)
    {
        /* REF10540 - LJE - 040813 */
        if (testDynSt != NULL &&
            (CMP_DYNFLD(dynSt, testDynSt,
            A_ObjectLnk_FromEntDictId, A_ObjectLnk_FromEntDictId, DictType) != 0 ||
            CMP_DYNFLD(dynSt, testDynSt,
            A_ObjectLnk_FromObjectId, A_ObjectLnk_FromObjectId, IdType) != 0))
        {
            return(FALSE);
        }
        return(TRUE);
    }
    return(FALSE);
}

/************************************************************************
**
**  Function    :   DBA_FilterObjectLnkPSPPAA()
**
**  Description :
**
**  Arguments   :   dynSt    element pointer
**                  dynStTp  element description enum
**
**  Return      : TRUE or FALSE
**
**  Creation Date : REF9770 - LJE - 040317
**
*************************************************************************/
STATIC int DBA_FilterObjectLnkPSPPAA(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP notUse)
{
    if (IS_NULLFLD(dynSt, A_ObjectLnk_Nature) == FALSE                         &&
        GET_ENUM(dynSt, A_ObjectLnk_Nature) == (ENUM_T)ObjectLnkNat_PSPSP ||
        GET_ENUM(dynSt, A_ObjectLnk_Nature) == (ENUM_T)ObjectLnkNat_PSPPA ||
        GET_ENUM(dynSt, A_ObjectLnk_Nature) == (ENUM_T)ObjectLnkNat_PSPExtRA ||
        GET_ENUM(dynSt, A_ObjectLnk_Nature) == (ENUM_T)ObjectLnkNat_PSPPCR)/*PMSTA-54344 - SENTHIL - 230823*/
        return(TRUE);
    return(FALSE);
}

/************************************************************************
**
**  Function    :   DBA_FilterMainOrBenchObjectLnkPAA()
**
**  Description :
**
**  Arguments   :   dynSt    element pointer
**                  dynStTp  element description enum
**
**  Return      : TRUE or FALSE
**
**  Creation Date : PMSTA-13058 - LJE - 111103
**
*************************************************************************/
STATIC int DBA_FilterMainOrBenchObjectLnkPAA(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP testDynSt)
{
    /* WEALTH-8340 - DDV - 240919 - Also load std main object link to split short and long term */
    if (GET_ENUM(dynSt, A_ObjectLnk_Nature) != (ENUM_T)ObjectLnkNat_Bench &&
        GET_ENUM(dynSt, A_ObjectLnk_Nature) != (ENUM_T)ObjectLnkNat_None)
    {
        return (FALSE);
    }

    if (CMP_DYNFLD(dynSt, testDynSt, A_ObjectLnk_BeginDate, A_Domain_InterpFromDate, DatetimeType) < 0 &&
        CMP_DYNFLD(dynSt, testDynSt, A_ObjectLnk_EndDate, A_Domain_InterpFromDate, DatetimeType) > 0)
    {
        return(TRUE);
    }

    return(FALSE);
}

/************************************************************************
**
**  Function    :   DBA_FilterMainObjectLnkPAA()
**
**  Description :
**
**  Arguments   :   dynSt    element pointer
**                  dynStTp  element description enum
**
**  Return      : TRUE or FALSE
**
**  Creation Date : REF9264 - LJE - 030924
**
*************************************************************************/
STATIC int DBA_FilterMainObjectLnkPAA(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP notUse)
{
    if (IS_NULLFLD(dynSt, A_ObjectLnk_Nature) == FALSE                       &&
        GET_ENUM(dynSt, A_ObjectLnk_Nature) != (ENUM_T)ObjectLnkNat_Bench)
        return (FALSE);

    if (GET_INT(dynSt, A_ObjectLnk_Rank) > 1) /* PMSTA50244 - MKK - 230123 */
        return (FALSE);

    return(TRUE);
}

/************************************************************************
**
**  Function    :   DBA_CmpObjectLnkPAA()
**
**  Description :
**
**  Arguments   :   ptr1   pointer on dynamic structure
**                  ptr2   pointer on dynamic structure
**
**  Return      :   a negative value if first element < second element
**                  a zero value     if first element = second element
**                  a positive value if first element > second element
**
*************************************************************************/
STATIC int DBA_CmpObjectLnkPAA(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    int cmp = 0;

    if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2), A_ObjectLnk_FromEntDictId, A_ObjectLnk_FromEntDictId, DictType)) != 0)
        return cmp;

    if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2), A_ObjectLnk_FromObjectId, A_ObjectLnk_FromObjectId, IdType)) != 0)
        return cmp;

    /* REF9770 - LJE - 031209 : Sort with end date descending */
    if ((cmp = CMP_DYNFLD((*ptr2), (*ptr1), A_ObjectLnk_EndDate, A_ObjectLnk_EndDate, DatetimeType)) != 0)
        return cmp;

    /* PMSTA09979 - LJE - 100827 - add rank criteria */
    if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2), A_ObjectLnk_Rank, A_ObjectLnk_Rank, IntType)) != 0) /* PMSTA50244 - MKK - 230123 */
        return cmp;
    return cmp;
}

/************************************************************************
**
**  Function    :   DBA_CmpObjectLnkGridPAA()
**
**  Description :
**
**  Arguments   :   ptr1   pointer on dynamic structure
**                  ptr2   pointer on dynamic structure
**
**  Return      :   a negative value if first element < second element
**                  a zero value     if first element = second element
**                  a positive value if first element > second element
**
*************************************************************************/
STATIC int DBA_CmpObjectLnkGridPAA(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    int cmp = 0;

    /* REF9770 - LJE - 040316 */
    if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2), A_ObjectLnk_Nature, A_ObjectLnk_Nature, EnumType)) != 0)
        return cmp;

    /* REF9770 - LJE - 040316 */
    if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2), A_ObjectLnk_Rank, A_ObjectLnk_Rank, IntType)) != 0) /* PMSTA50244 - MKK - 230123 */
        return cmp;

    if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2), A_ObjectLnk_FromEntDictId, A_ObjectLnk_FromEntDictId, DictType)) != 0)
        return cmp;

    if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2), A_ObjectLnk_FromObjectId, A_ObjectLnk_FromObjectId, IdType)) != 0)
        return cmp;

    if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2), A_ObjectLnk_ToEntDictId, A_ObjectLnk_ToEntDictId, DictType)) != 0)
        return cmp;

    if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2), A_ObjectLnk_ToObjectId, A_ObjectLnk_ToObjectId, IdType)) != 0)
        return cmp;

    if ((cmp = CMP_DYNFLD((*ptr2), (*ptr1), A_ObjectLnk_EndDate, A_ObjectLnk_EndDate, DatetimeType)) != 0)
        return cmp;

    /* PMSTA-12966 - LJE - 120322 */
    if ((cmp = CMP_DYNFLD((*ptr1), (*ptr2), A_ObjectLnk_BeginDate, A_ObjectLnk_BeginDate, DatetimeType)) != 0)
        return cmp;

    return cmp;
}

/************************************************************************
**
**  Function    :   FIN_CmpPspByEntIdObjIdDt()
**
**  Description :   Perf_storage_param are sort by entity_dict_id/object_id
**
**  Arguments   :   ptr1   pointer on dynamic structure type psp
**                  ptr2   pointer on dynamic structure type psp
**
**  Return      :   a negative value if first element < second element
**                  a null value     if first element = second element
**                  a positive value if first element > second element
**
**  Creation D. : PMSTA-13946 - LJE - 120328
**  Last modif. :
**
*************************************************************************/
STATIC int FIN_CmpPspByEntIdObjIdDt(DBA_DYNFLD_STP *ptr1, DBA_DYNFLD_STP *ptr2)
{
    int ret;

    ret = CMP_DYNFLD((*ptr1), (*ptr2), A_PerfStorageParam_EntityDictId, A_PerfStorageParam_EntityDictId, DictType);

    if (ret == 0)
        ret = CMP_DYNFLD((*ptr1), (*ptr2), A_PerfStorageParam_ObjId, A_PerfStorageParam_ObjId, IdType);

    if (ret == 0)
        ret = CMP_DYNFLD((*ptr2), (*ptr1), A_PerfStorageParam_StdPerfLastStoredDate, A_PerfStorageParam_StdPerfLastStoredDate, DatetimeType);

    if (ret == 0)
        ret = CMP_DYNFLD((*ptr2), (*ptr1), A_PerfStorageParam_StdPerfFirstStoredDate, A_PerfStorageParam_StdPerfFirstStoredDate, DatetimeType);

    if (ret == 0)
        ret = CMP_DYNFLD((*ptr1), (*ptr2), A_PerfStorageParam_Id, A_PerfStorageParam_Id, IdType);

    return ret;
}

/************************************************************************
**
**  Function    :   FIN_GetDefPPDa()
**
**  Description :   Get default PSP Position Data, could return NULL when
**					there isn't default PSP Position Data.
**
**  Arguments   :   defPPDaPtr			pointer on default PSP Position Data.
**
**  Return      :   RET_SUCCEED
**
**  Creation    :   PMSTA-9378 - RAK - 100507
**
*************************************************************************/
RET_CODE FIN_GetDefPPDa(DBA_DYNFLD_STP *defPPDaPtr)
{
    ID_T	defPPDaId;

    if (defPPDaPtr == NULLDYNSTPTR)
    {
        MSG_LogSrvMesg(UNUSED, UNUSED, "FIN_GetDefPPDa() : Invalid argument");
        return(RET_GEN_ERR_INVARG);
    }

    GEN_GetApplInfo(ApplDefPSPPositionData, &defPPDaId);

    if (defPPDaId > 0)
    {
        if ((*defPPDaPtr = ALLOC_DYNST(A_PSPPositionData)) == NULLDYNST)
        {
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        SET_ID((*defPPDaPtr), A_PSPPositionData_Id, defPPDaId);

        if (DBA_Get2(PSPPositionData, UNUSED, A_PSPPositionData,
            (*defPPDaPtr), A_PSPPositionData, defPPDaPtr,
            UNUSED, UNUSED, UNUSED) != RET_SUCCEED)
        {
            FREE_DYNST((*defPPDaPtr), A_PSPPositionData);
            return(RET_DBA_ERR_NODATA);
        }
    }

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_CreateDomPPDa()
**
**  Description :   According to received domain create a PSP Position Data (PPDa).
**
**  Arguments   :   domainPtr		domain pointer
**					PPDaPtr			pointer on created PSP Position Data.
**
**  Return      :   RET_SUCCEED
**
**  Creation    :   PMSTA-9378 - RAK - 100504
**
*************************************************************************/
STATIC RET_CODE FIN_CreateDomPPDa(DBA_DYNFLD_STP domainPtr, DBA_DYNFLD_STP* PPDaPtr)
{
    if (domainPtr == NULLDYNST || PPDaPtr == NULLDYNSTPTR)
    {
        MSG_LogSrvMesg(UNUSED, UNUSED, "FIN_CreateDomPPDa() : Invalid argument");
        return(RET_GEN_ERR_INVARG);
    }

    if ((*PPDaPtr = ALLOC_DYNST(A_PSPPositionData)) == NULLDYNST)
    {
        MSG_RETURN(RET_MEM_ERR_ALLOC);
    }

    COPY_DYNFLD((*PPDaPtr), A_PSPPositionData, A_PSPPositionData_ConsPtfId,
                domainPtr, A_Domain, A_Domain_ConsPtfId);
    COPY_DYNFLD((*PPDaPtr), A_PSPPositionData, A_PSPPositionData_PPSLoadEn,
                domainPtr, A_Domain, A_Domain_PpsLoadEn);
    COPY_DYNFLD((*PPDaPtr), A_PSPPositionData, A_PSPPositionData_PortPosTypeId,
                domainPtr, A_Domain, A_Domain_PortPosSetId);

    /* Strategy link informations */
    COPY_DYNFLD((*PPDaPtr), A_PSPPositionData, A_PSPPositionData_StratLnkNatEn,
                domainPtr, A_Domain, A_Domain_StratLnkNatEn);
    COPY_DYNFLD((*PPDaPtr), A_PSPPositionData, A_PSPPositionData_MinLnkPriority,
                domainPtr, A_Domain, A_Domain_MinLnkPriority);
    COPY_DYNFLD((*PPDaPtr), A_PSPPositionData, A_PSPPositionData_MaxLnkPriority,
                domainPtr, A_Domain, A_Domain_MaxLnkPriority);

    /* Fund splitting informations */
    COPY_DYNFLD((*PPDaPtr), A_PSPPositionData, A_PSPPositionData_FundSplitRuleEn,
                domainPtr, A_Domain, A_Domain_FundSplitRuleEn);

    /* Risk informations */
    COPY_DYNFLD((*PPDaPtr), A_PSPPositionData, A_PSPPositionData_RiskExpoFlg,
                domainPtr, A_Domain, A_Domain_RiskExpoFlg);
    COPY_DYNFLD((*PPDaPtr), A_PSPPositionData, A_PSPPositionData_OptRiskRuleEn,
                domainPtr, A_Domain, A_Domain_OptRiskRuleEn);
    COPY_DYNFLD((*PPDaPtr), A_PSPPositionData, A_PSPPositionData_DebtFlg,
                domainPtr, A_Domain, A_Domain_DebtFlg);

    /* Load informations */
    COPY_DYNFLD((*PPDaPtr), A_PSPPositionData, A_PSPPositionData_MinStatEn,
                domainPtr, A_Domain, A_Domain_MinStatEn);
    COPY_DYNFLD((*PPDaPtr), A_PSPPositionData, A_PSPPositionData_MaxStatEn,
                domainPtr, A_Domain, A_Domain_MaxStatEn);

    /* Fusion informations */
    /* PMSTA09979 - LJE - 100825 - No Fusion information can come from
                                   the PSP position data, only used
                                   in P&L market value case

                                   COPY_DYNFLD((*PPDaPtr), A_PSPPositionData, A_PSPPositionData_FusRuleEn,
                                   domainPtr,  A_Domain,		   A_Domain_FusRuleEn);
                                   COPY_DYNFLD((*PPDaPtr), A_PSPPositionData, A_PSPPositionData_FusDateRuleEn,
                                   domainPtr,  A_Domain,		   A_Domain_FusDateRuleEn);
                                   COPY_DYNFLD((*PPDaPtr), A_PSPPositionData, A_PSPPositionData_PosLogicalEn,
                                   domainPtr,  A_Domain,		   A_Domain_PosLogicEn);
                                   */

    /* Valuation informations */
    COPY_DYNFLD((*PPDaPtr), A_PSPPositionData, A_PSPPositionData_QuoteValRuleId,
                domainPtr, A_Domain, A_Domain_QuoteValRuleId);
    COPY_DYNFLD((*PPDaPtr), A_PSPPositionData, A_PSPPositionData_ExchValRuleId,
                domainPtr, A_Domain, A_Domain_ExchValRuleId);
    COPY_DYNFLD((*PPDaPtr), A_PSPPositionData, A_PSPPositionData_PosValRuleEn,
                domainPtr, A_Domain, A_Domain_PosValRuleEn);

    COPY_DYNFLD((*PPDaPtr), A_PSPPositionData, A_PSPPositionData_ExtPosListId,
                domainPtr, A_Domain, A_Domain_ExtPosListId);

    return(RET_SUCCEED);
}

/************************************************************************
**
**  Function    :   FIN_CmpPPDa()
**
**  Description :   Compare the two received PSP Position Data (PPDa).
**
**  Arguments   :   PPDa1			first PSP Position Data.
**					PPDa2			second PSP Position Data.
**
**  Return      :   RET_SUCCEED
**
**  Creation    :   PMSTA-9378 - RAK - 100504
**
*************************************************************************/
STATIC int FIN_CmpPPDa(COMPUTE_PAA_STP computeStp, DBA_DYNFLD_STP PPDa1, DBA_DYNFLD_STP PPDa2)
{
    if (CMP_DYNFLD(PPDa1, PPDa2,
        A_PSPPositionData_ConsPtfId, A_PSPPositionData_ConsPtfId,
        GET_FLD_TYPE(A_PSPPositionData, A_PSPPositionData_ConsPtfId)) != 0)
    {
        return(FALSE);
    }

    if (CMP_DYNFLD(PPDa1, PPDa2,
        A_PSPPositionData_PPSLoadEn, A_PSPPositionData_PPSLoadEn,
        GET_FLD_TYPE(A_PSPPositionData, A_PSPPositionData_PPSLoadEn)) != 0)
    {
        return(FALSE);
    }

    if (CMP_DYNFLD(PPDa1, PPDa2,
        A_PSPPositionData_PortPosTypeId, A_PSPPositionData_PortPosTypeId,
        GET_FLD_TYPE(A_PSPPositionData, A_PSPPositionData_PortPosTypeId)) != 0)
    {
        return(FALSE);
    }

    /* Strategy link informations */
    /* PMSTA09979 - LJE - 100830 - effect on data only in perf attrib case */
    if (*(computeStp->outObjEnPtr) == PerfAttrib)
    {
        if (CMP_DYNFLD(PPDa1, PPDa2,
            A_PSPPositionData_StratLnkNatEn, A_PSPPositionData_StratLnkNatEn,
            GET_FLD_TYPE(A_PSPPositionData, A_PSPPositionData_StratLnkNatEn)) != 0)
        {
            return(FALSE);
        }

        if (CMP_DYNFLD(PPDa1, PPDa2,
            A_PSPPositionData_MinLnkPriority, A_PSPPositionData_MinLnkPriority,
            GET_FLD_TYPE(A_PSPPositionData, A_PSPPositionData_MinLnkPriority)) != 0)
        {
            return(FALSE);
        }

        if (CMP_DYNFLD(PPDa1, PPDa2,
            A_PSPPositionData_MaxLnkPriority, A_PSPPositionData_MaxLnkPriority,
            GET_FLD_TYPE(A_PSPPositionData, A_PSPPositionData_MaxLnkPriority)) != 0)
        {
            return(FALSE);
        }
    }

    /* Fund splitting informations */
    if (CMP_DYNFLD(PPDa1, PPDa2,
        A_PSPPositionData_FundSplitRuleEn, A_PSPPositionData_FundSplitRuleEn,
        GET_FLD_TYPE(A_PSPPositionData, A_PSPPositionData_FundSplitRuleEn)) != 0)
    {
        return(FALSE);
    }

    /* Risk informations */
    if (CMP_DYNFLD(PPDa1, PPDa2,
        A_PSPPositionData_RiskExpoFlg, A_PSPPositionData_RiskExpoFlg,
        GET_FLD_TYPE(A_PSPPositionData, A_PSPPositionData_RiskExpoFlg)) != 0)
    {
        return(FALSE);
    }

    if (CMP_DYNFLD(PPDa1, PPDa2,
        A_PSPPositionData_OptRiskRuleEn, A_PSPPositionData_OptRiskRuleEn,
        GET_FLD_TYPE(A_PSPPositionData, A_PSPPositionData_OptRiskRuleEn)) != 0)
    {
        return(FALSE);
    }

    if (CMP_DYNFLD(PPDa1, PPDa2,
        A_PSPPositionData_DebtFlg, A_PSPPositionData_DebtFlg,
        GET_FLD_TYPE(A_PSPPositionData, A_PSPPositionData_DebtFlg)) != 0)
    {
        return(FALSE);
    }

    /* Load informations */
    if (CMP_DYNFLD(PPDa1, PPDa2,
        A_PSPPositionData_MinStatEn, A_PSPPositionData_MinStatEn,
        GET_FLD_TYPE(A_PSPPositionData, A_PSPPositionData_MinStatEn)) != 0)
    {
        return(FALSE);
    }

    if (CMP_DYNFLD(PPDa1, PPDa2,
        A_PSPPositionData_MaxStatEn, A_PSPPositionData_MaxStatEn,
        GET_FLD_TYPE(A_PSPPositionData, A_PSPPositionData_MaxStatEn)) != 0)
    {
        return(FALSE);
    }

    /* Fusion informations */
    /* PMSTA09979 - LJE - 100825 - No Fusion information can come from
                                   the PSP position data, only used
                                   in P&L market value case

                                   if (CMP_DYNFLD(PPDa1, PPDa2,
                                   A_PSPPositionData_FusRuleEn, A_PSPPositionData_FusRuleEn,
                                   GET_FLD_TYPE(A_PSPPositionData, A_PSPPositionData_FusRuleEn)) != 0)
                                   { return(FALSE); }

                                   if (CMP_DYNFLD(PPDa1, PPDa2,
                                   A_PSPPositionData_FusDateRuleEn, A_PSPPositionData_FusDateRuleEn,
                                   GET_FLD_TYPE(A_PSPPositionData, A_PSPPositionData_FusDateRuleEn)) != 0)
                                   { return(FALSE); }

                                   if (CMP_DYNFLD(PPDa1, PPDa2,
                                   A_PSPPositionData_PosLogicalEn, A_PSPPositionData_PosLogicalEn,
                                   GET_FLD_TYPE(A_PSPPositionData, A_PSPPositionData_PosLogicalEn)) != 0)
                                   { return(FALSE); }
                                   */

    /* Valuation informations */
    if (CMP_DYNFLD(PPDa1, PPDa2,
        A_PSPPositionData_QuoteValRuleId, A_PSPPositionData_QuoteValRuleId,
        GET_FLD_TYPE(A_PSPPositionData, A_PSPPositionData_QuoteValRuleId)) != 0)
    {
        return(FALSE);
    }

    if (CMP_DYNFLD(PPDa1, PPDa2,
        A_PSPPositionData_ExchValRuleId, A_PSPPositionData_ExchValRuleId,
        GET_FLD_TYPE(A_PSPPositionData, A_PSPPositionData_ExchValRuleId)) != 0)
    {
        return(FALSE);
    }

    if (CMP_DYNFLD(PPDa1, PPDa2,
        A_PSPPositionData_PosValRuleEn, A_PSPPositionData_PosValRuleEn,
        GET_FLD_TYPE(A_PSPPositionData, A_PSPPositionData_PosValRuleEn)) != 0)
    {
        return(FALSE);
    }

    if (CMP_DYNFLD(PPDa1, PPDa2,
        A_PSPPositionData_ExtPosListId, A_PSPPositionData_ExtPosListId,
        GET_FLD_TYPE(A_PSPPositionData, A_PSPPositionData_ExtPosListId)) != 0)
    {
        return(FALSE);
    }

    return(TRUE);
}

/************************************************************************
**
**  Function    :   FIN_GetAllPPDa()
**
**  Description :   Get default PSP Position Data, could return NULL when
**					there isn't default PSP Position Data.
**
**  Arguments   :   defPPDaPtr			pointer on default PSP Position Data.
**
**  Return      :   RET_SUCCEED
**
**  Creation    :   PMSTA09979 - LJE - 100818
**
*************************************************************************/
STATIC RET_CODE FIN_GetAllPPDa(DBA_HIER_HEAD_STP  hierHead,
                               DBA_DYNFLD_STP     domainPtr,
                               COMPUTE_PAA_STP    computeTab,
                               DBA_DYNFLD_STP    *defPPDaStpPtr,
                               DBA_DYNFLD_STP    *domPPDaStpPtr,
                               FLAG_T            *irregBenchFlgPtr)
{
    RET_CODE        ret = RET_SUCCEED;
    COMPUTE_PAA_STP computeStp;

    /* PMSTA-9378 - RAK - 100615 - get default PPDa (PSP Position Data) according to DEF_PSP_POSITION_DATA */
    if (FIN_GetDefPPDa(defPPDaStpPtr) == RET_SUCCEED &&
        *defPPDaStpPtr != NULLDYNST)
    {
        *domPPDaStpPtr = NULLDYNST;
        if (IS_NULLFLD(domainPtr, A_Domain_PSPPositionDataId) == TRUE)
        {
            /* Allocate and fill a PPDa with domain information */
            FIN_CreateDomPPDa(domainPtr, domPPDaStpPtr);
        }
        else
        {
            if ((*domPPDaStpPtr = ALLOC_DYNST(A_PSPPositionData)) == NULLDYNST)
            {
                FREE_DYNST((*defPPDaStpPtr), A_PSPPositionData);
                MSG_RETURN(RET_MEM_ERR_ALLOC);
            }

            SET_ID((*domPPDaStpPtr), A_PSPPositionData_Id, GET_ID(domainPtr, A_Domain_PSPPositionDataId));

            if ((ret = DBA_Get2(PSPPositionData,
                UNUSED,
                A_PSPPositionData,
                *domPPDaStpPtr,
                A_PSPPositionData,
                domPPDaStpPtr,
                UNUSED, UNUSED, UNUSED)) != RET_SUCCEED)
            {
                FREE_DYNST((*domPPDaStpPtr), A_PSPPositionData);
                FREE_DYNST((*defPPDaStpPtr), A_PSPPositionData);
                return(ret);
            }
        }

        *irregBenchFlgPtr = FIN_GetIrregBenchFlg(hierHead, domainPtr, computeTab);

        /* Use default strat link access */
        if ((*defPPDaStpPtr) != NULL &&
            GET_FLAG(domainPtr, A_Domain_ForceLnkFlg) == TRUE)
        {
            COPY_DYNFLD((*domPPDaStpPtr), A_PSPPositionData, A_PSPPositionData_StratLnkNatEn,
                        (*defPPDaStpPtr), A_PSPPositionData, A_PSPPositionData_StratLnkNatEn);
            COPY_DYNFLD((*domPPDaStpPtr), A_PSPPositionData, A_PSPPositionData_MinLnkPriority,
                        (*defPPDaStpPtr), A_PSPPositionData, A_PSPPositionData_MinLnkPriority);
            COPY_DYNFLD((*domPPDaStpPtr), A_PSPPositionData, A_PSPPositionData_MaxLnkPriority,
                        (*defPPDaStpPtr), A_PSPPositionData, A_PSPPositionData_MaxLnkPriority);
        }

        if (*irregBenchFlgPtr == TRUE)
        {
            SET_ENUM((*domPPDaStpPtr), A_PSPPositionData_StratLnkNatEn, DomStratLnkNat_ForcedLink);
        }

        if (GET_ENUM(domainPtr, A_Domain_ReturnAnalysisEn) == PAARetAnalysis_PA ||
            GET_ENUM(domainPtr, A_Domain_ReturnAnalysisEn) == PAARetAnalysis_All)
        {
            computeStp = &(computeTab[PERF_ATTRIB_IDX]);
        }
        else
        {
            computeStp = &(computeTab[EXT_RET_IDX]);
        }

        if (IS_NULLFLD(domainPtr, A_Domain_PSPPositionDataId) == FALSE ||   /* PMSTA-32177 - LJE - 180910 - Keep the PSP Position data if set */
            FIN_CmpPPDa(computeStp, *domPPDaStpPtr, *defPPDaStpPtr) == FALSE)
        {
            /* Add domain PPDA in hierarchy (loaded or not) */
            if (DBA_AddHierRecord(hierHead,
                (*domPPDaStpPtr),
                A_PSPPositionData,
                ((IS_NULLFLD((*domPPDaStpPtr), A_PSPPositionData_Id) == TRUE) ? FALSE : TRUE),
                HierAddRec_NoLnk) != RET_SUCCEED)
            {
                FREE_DYNST((*domPPDaStpPtr), A_PSPPositionData);
                FREE_DYNST((*defPPDaStpPtr), A_PSPPositionData);
                return(ret);
            }
        }
        else
        {
            FREE_DYNST((*domPPDaStpPtr), A_PSPPositionData);
            (*domPPDaStpPtr) = (*defPPDaStpPtr);
        }

    }

    return (ret);
}

/************************************************************************
**
**  Function    :   FIN_GetPPDa()
**
**  Description :   Get the PSP Position Data define in the current PSP.
**                  If it's NULL, return the default PSP position data (if exists)
**
**  Arguments   :   defPPDaPtr			pointer on default PSP Position Data.
**
**  Return      :   RET_SUCCEED
**
**  Creation    :   PMSTA09979 - LJE - 100825
**
*************************************************************************/
STATIC RET_CODE FIN_GetPPDa(DBA_HIER_HEAD_STP  hierHead,
                            COMPUTE_PAA_STP    computeStp,
                            DBA_DYNFLD_STP     pspStp,
                            DBA_DYNFLD_STP    *defPPDaStpPtr,
                            DBA_DYNFLD_STP    *pPDaStpPtr)
{
    RET_CODE ret = RET_SUCCEED;

    if (defPPDaStpPtr == NULL || *defPPDaStpPtr == NULL || GET_DICT(pspStp, A_PerfStorageParam_EntityDictId) != computeStp->ptfEntDictId) /* - LJE - 170410 */
    {
        *pPDaStpPtr = NULL;
        return ret;
    }

    if (IS_NULLFLD(pspStp, A_PerfStorageParam_PositionDataId) == TRUE)
    {
        *pPDaStpPtr = *defPPDaStpPtr;
        return ret;
    }

    if (((*pPDaStpPtr) = DBA_SearchHierRecById(hierHead,
        A_PSPPositionData,
        A_PSPPositionData_Id,
        GET_ID(pspStp, A_PerfStorageParam_PositionDataId))) == NULL)
    {
        if ((*pPDaStpPtr = ALLOC_DYNST(A_PSPPositionData)) == NULLDYNST)
        {
            MSG_RETURN(RET_MEM_ERR_ALLOC);
        }

        SET_ID((*pPDaStpPtr), A_PSPPositionData_Id, GET_ID(pspStp, A_PerfStorageParam_PositionDataId));

        if ((ret = DBA_Get2(PSPPositionData,
            UNUSED,
            A_PSPPositionData,
            *pPDaStpPtr,
            A_PSPPositionData,
            pPDaStpPtr,
            UNUSED, UNUSED, UNUSED)) != RET_SUCCEED)
        {
            FREE_DYNST((*pPDaStpPtr), A_PSPPositionData);
            return(ret);
        }

        /* Add domain PPDA in hierarchy (loaded or not) */
        if (DBA_AddHierRecord(hierHead,
            (*pPDaStpPtr),
            A_PSPPositionData,
            TRUE,
            HierAddRec_NoLnk) != RET_SUCCEED)
        {
            FREE_DYNST((*pPDaStpPtr), A_PSPPositionData);
            return(ret);
        }
    }

    return (ret);
}

/************************************************************************
**
**  Function    :   DBA_FilterPSPforCurrent()
**
**  Description :
**
**  Arguments   :   dynSt    element pointer
**                  dynStTp  element description enum
**
**  Return      : TRUE or FALSE
**
**  Creation Date : PMSTA09843 - LJE - 100519
**
*************************************************************************/
STATIC int DBA_FilterPSPforCurrent(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP testSt)
{
    if (CMP_DYNFLD(dynSt, testSt, A_PerfStorageParam_EntityDictId, A_ObjectLnk_FromEntDictId, DictType) == 0 &&
        CMP_DYNFLD(dynSt, testSt, A_PerfStorageParam_ObjId, A_ObjectLnk_FromObjectId, IdType) == 0)
    {
        switch (GET_ENUM(testSt, A_ObjectLnk_Nature))
        {
            case ObjectLnkNat_PSPExtRA:
                return (GET_FLAG(dynSt, A_PerfStorageParam_RetAnalysisFlg) == TRUE ||
                        IS_NULLFLD(dynSt, A_PerfStorageParam_RetLastStoredDate) == FALSE);
                break;

            case ObjectLnkNat_PSPPA:
                return (GET_FLAG(dynSt, A_PerfStorageParam_PerfAttribFlg) == TRUE ||
                        IS_NULLFLD(dynSt, A_PerfStorageParam_PerfLastStoredDate) == FALSE);
                break;

            case ObjectLnkNat_PSPSP:
                return (GET_FLAG(dynSt, A_PerfStorageParam_StandardPerfDataFlg) == TRUE ||
                        IS_NULLFLD(dynSt, A_PerfStorageParam_StdPerfLastStoredDate) == FALSE);
                break;

            case ObjectLnkNat_PSPPCR:
                return (GET_FLAG(dynSt, A_PerfStorageParam_PerfCalcResultFlg) == TRUE ||
                    IS_NULLFLD(dynSt, A_PerfStorageParam_PerfCalcLastStoredDate) == FALSE);
                break;

            default:
                /* Nothing to do */
                break;

        }
        return (TRUE);
    }

    return (FALSE);
}

/************************************************************************
**  Function             : DBA_InsertObjLnkIntoDomPSP()
**
**  Description          : Insert an object link into #dom_psp table
**
**  Arguments            :
**
**  Return               : RET_SUCCEED or error code
**
**  Creation             : PMSTA09843 - LJE - 100520
**
*************************************************************************/
STATIC RET_CODE DBA_InsertObjLnkIntoDomPSP(COMPUTE_PAA_STP      computeStp,
                                           DBA_DYNFLD_STP       objLnkStp,
                                           DBA_DYNFLD_STP       pspStp,
                                           DBA_DYNFLD_STP       domainPtr,
                                           RequestHelper       &requestHelper)
{
    RET_CODE        ret = RET_SUCCEED;
    DATETIME_T      beginDate, endDate;

    /* PMSTA-13946 - LJE - 120328 - Check PSP to avoid crash */
    if (pspStp == NULL ||
        GET_ID(pspStp, A_PerfStorageParam_Id) < 0 ||
        ((IS_NULLFLD(pspStp, *(computeStp->fromDIdxPtr)) == TRUE &&
        IS_NULLFLD(pspStp, *(computeStp->tillDIdxPtr)) == TRUE)))
    {
        return (ret);
    }

    if (IS_NULLFLD(pspStp, *(computeStp->fromDIdxPtr)) == FALSE &&
        CMP_DYNFLD(objLnkStp, pspStp, A_ObjectLnk_BeginDate, *(computeStp->fromDIdxPtr), DatetimeType) < 0)
    {
        beginDate = GET_DATETIME(pspStp, *(computeStp->fromDIdxPtr));
    }
    else
    {
        beginDate = GET_DATETIME(objLnkStp, A_ObjectLnk_BeginDate);
    }

    if (IS_NULLFLD(pspStp, *(computeStp->tillDIdxPtr)) == FALSE &&
        CMP_DYNFLD(objLnkStp, pspStp, A_ObjectLnk_EndDate, *(computeStp->tillDIdxPtr), DatetimeType) > 0)
    {
        endDate = GET_DATETIME(pspStp, *(computeStp->tillDIdxPtr));
    }
    else
    {
        endDate = GET_DATETIME(objLnkStp, A_ObjectLnk_EndDate);
    }

    /* WEALTH-4784 - DDV - 240415 - For PSP linked to portfolios or list, don't load stored data when Market Value P&L or Reprocess is use */
    if ((GET_DICT(objLnkStp, A_ObjectLnk_FromEntDictId) == PtfCst || GET_DICT(objLnkStp, A_ObjectLnk_FromEntDictId) == ListCst) &&
        GET_DICT(objLnkStp, A_ObjectLnk_ToEntDictId) == PerfStorageParamCst && 
        (PLMETHOD_ENUM)GET_ENUM(domainPtr, A_Domain_PLMethodEn) != PLMethod_Standard)
    {
        return (ret);
    }

    DBA_DYNFLD_STP domPspStp = requestHelper.getNewRecordForBatch(A_DomPsp);
    
    SET_ID(domPspStp, A_DomPsp_Id, GET_ID(objLnkStp, A_ObjectLnk_ToObjectId));
    SET_DATETIME(domPspStp, A_DomPsp_FromDate, beginDate);
    SET_DATETIME(domPspStp, A_DomPsp_TillDate, endDate);
    SET_DICT(domPspStp, A_DomPsp_OutputEntityDictId, computeStp->outEntDictId);

    return (ret);
}

/************************************************************************
**  Function             : DBA_InsertCopyGridObjLnk()
**
**  Description          :
**
**  Arguments            :
**
**  Return               : RET_SUCCEED or error code
**
**  Creation             : PMSTA09843 - LJE - 100520
**
*************************************************************************/
STATIC RET_CODE DBA_InsertCopyGridObjLnk(DBA_HIER_HEAD_STP    hierHead,
                                         DBA_DYNFLD_STP       domainPtr,
                                         COMPUTE_PAA_STP      computeTab,
                                         DBA_DYNFLD_STP       currPSPObjLnkStp,
                                         DBA_DYNFLD_STP       lastGridObjLnkStp,
                                         DBA_DYNFLD_STP       bestSPPspStp)
{
    DBA_DYNFLD_STP  copyGridObjLnkStp;

    /* Build a "copy grid" object link */
    if ((copyGridObjLnkStp = ALLOC_DYNST(A_ObjectLnk)) == NULLDYNST)
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
        return FALSE;
    }

    SET_ENUM(copyGridObjLnkStp, A_ObjectLnk_Nature, ObjectLnkNat_SPCopyGrid);
    SET_INT(copyGridObjLnkStp, A_ObjectLnk_Rank, 0); /* PMSTA50244 - MKK - 230123 */

    SET_DICT(copyGridObjLnkStp, A_ObjectLnk_FromEntDictId, computeTab->pspEntDictId);
    COPY_DYNFLD(copyGridObjLnkStp, A_ObjectLnk, A_ObjectLnk_FromObjectId,
                bestSPPspStp, A_PerfStorageParam, A_PerfStorageParam_Id);

    COPY_DYNFLD(copyGridObjLnkStp, A_ObjectLnk, A_ObjectLnk_BeginDate,
                currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_BeginDate);

    COPY_DYNFLD(copyGridObjLnkStp, A_ObjectLnk, A_ObjectLnk_EndDate,
                currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_EndDate);

    SET_DICT(copyGridObjLnkStp, A_ObjectLnk_ToEntDictId, computeTab->gridEntDictId);
    if (lastGridObjLnkStp != NULL)
    {
        COPY_DYNFLD(copyGridObjLnkStp, A_ObjectLnk, A_ObjectLnk_ToObjectId,
                    lastGridObjLnkStp, A_ObjectLnk, A_ObjectLnk_ToObjectId);
    }

    if (CMP_DYNFLD(copyGridObjLnkStp, copyGridObjLnkStp, A_ObjectLnk_BeginDate, A_ObjectLnk_EndDate, DatetimeType) != 0)
    {
        DBA_AddHierRecord(hierHead,
                          copyGridObjLnkStp,
                          A_ObjectLnk,
                          FALSE,
                          HierAddRec_NoLnk);
    }
    else
    {
        FREE_DYNST(copyGridObjLnkStp, A_ObjectLnk);
    }

    return (RET_SUCCEED);
}

/************************************************************************
**  Function             : DBA_InsertGridObjLnk()
**
**  Description          :
**
**  Arguments            :
**
**  Return               : RET_SUCCEED or error code
**
**  Creation             : PMSTA09843 - LJE - 100520
**
*************************************************************************/
STATIC RET_CODE DBA_InsertGridObjLnk(DBA_HIER_HEAD_STP    hierHead,
                                     DBA_DYNFLD_STP       domainPtr,
                                     DBA_DYNFLD_STP       validObjLnkStp,
                                     DBA_DYNFLD_STP       validPspStp,
                                     COMPUTE_PAA_STP      computeStp,
									 DBA_DYNFLD_STP      *lastGridObjLnkStpPtr,
									 DBA_MAIN_OBJ_STP     mainObjInfoStp)
{
    DATETIME_T      tmpDate;
    DBA_DYNFLD_STP  gridObjLnkStp;

    tmpDate.date = 0;
    tmpDate.time = 0;

    /* Insert grid information in the object link structure */
    gridObjLnkStp = ALLOC_DYNST(A_ObjectLnk);
    if (gridObjLnkStp == NULL)
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
        return(RET_MEM_ERR_ALLOC);
    }

    SET_ENUM(gridObjLnkStp, A_ObjectLnk_Nature, ObjectLnkNat_Grid);
    SET_INT(gridObjLnkStp, A_ObjectLnk_Rank, 1); /* PMSTA50244 - MKK - 230123 */

    COPY_DYNFLD(gridObjLnkStp, A_ObjectLnk, A_ObjectLnk_FromEntDictId,
                validObjLnkStp, A_ObjectLnk, A_ObjectLnk_FromEntDictId);
    COPY_DYNFLD(gridObjLnkStp, A_ObjectLnk, A_ObjectLnk_FromObjectId,
                validObjLnkStp, A_ObjectLnk, A_ObjectLnk_FromObjectId);

    COPY_DYNFLD(gridObjLnkStp, A_ObjectLnk, A_ObjectLnk_BeginDate,
                validObjLnkStp, A_ObjectLnk, A_ObjectLnk_BeginDate);

    if (lastGridObjLnkStpPtr != NULL &&
        *lastGridObjLnkStpPtr != NULL)
    {
        COPY_DYNFLD((*lastGridObjLnkStpPtr), A_ObjectLnk, A_ObjectLnk_BeginDate,
                    validObjLnkStp, A_ObjectLnk, A_ObjectLnk_EndDate);
    }

    COPY_DYNFLD(gridObjLnkStp, A_ObjectLnk, A_ObjectLnk_EndDate,
                validObjLnkStp, A_ObjectLnk, A_ObjectLnk_EndDate);

    SET_DICT(gridObjLnkStp, A_ObjectLnk_ToEntDictId, computeStp->gridEntDictId);

    if (GET_ENUM(domainPtr, A_Domain_RetDetLevelEn) != PtfRetDetLvl_Global) /* No grid in global mode */
    {
        if (validPspStp != NULL)
        {
            COPY_DYNFLD(gridObjLnkStp, A_ObjectLnk, A_ObjectLnk_ToObjectId, validPspStp, A_PerfStorageParam, A_PerfStorageParam_GridId);
        }
        else if (lastGridObjLnkStpPtr != NULL &&
                 *lastGridObjLnkStpPtr != NULL)
        {
            COPY_DYNFLD(gridObjLnkStp, A_ObjectLnk, A_ObjectLnk_ToObjectId, (*lastGridObjLnkStpPtr), A_ObjectLnk, A_ObjectLnk_ToObjectId);
        }
    }

    DBA_AddHierRecord(hierHead,
                      gridObjLnkStp,
                      A_ObjectLnk,
                      FALSE,
                      HierAddRec_NoLnk);

	/* PMSTA-18812 - LJE - 141008 - Copy the Grid object link to the parent */
	if (mainObjInfoStp != NULL &&
		mainObjInfoStp->hierPtfStp != NULL &&
		IS_NULLFLD(mainObjInfoStp->hierPtfStp, A_Ptf_HierPortId) == FALSE &&
		computeStp->returnInParPtfRuleEn == ReturnInParentPtfRule_ParentUsingHierPSP &&
		GET_ENUM(validPspStp, A_PerfStorageParam_PerfAttribReturnEn) == PerfAttribRtnEn_Standard)
	{
		DBA_DYNFLD_STP  parentGridObjLnkStp = ALLOC_DYNST(A_ObjectLnk);
		if (parentGridObjLnkStp == NULL)
		{
			MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
			return(RET_MEM_ERR_ALLOC);
		}

		COPY_DYNST(parentGridObjLnkStp, gridObjLnkStp, A_ObjectLnk);
		SET_NULL_ID(parentGridObjLnkStp, A_ObjectLnk_Id);

		COPY_DYNFLD(parentGridObjLnkStp,        A_ObjectLnk, A_ObjectLnk_FromObjectId, 
					mainObjInfoStp->hierPtfStp, A_Ptf,		 A_Ptf_HierPortId);

		DBA_AddHierRecord(hierHead,
						  parentGridObjLnkStp,
						  A_ObjectLnk,
						  FALSE,
						  HierAddRec_NoLnk);
	}

    /* RAK - 100813 - crash */
    if (lastGridObjLnkStpPtr != NULL)
        *lastGridObjLnkStpPtr = gridObjLnkStp;

    return (RET_SUCCEED);

}

/************************************************************************
**  Function             : DBA_InsertValidPSP()
**
**  Description          :
**
**  Arguments            :
**
**  Return               : RET_SUCCEED or error code
**
**  Creation             : PMSTA09843 - LJE - 100520
**
*************************************************************************/
STATIC RET_CODE DBA_InsertValidPSP(DBA_HIER_HEAD_STP    hierHead,
                                   DBA_DYNFLD_STP       domainPtr,
                                   DBA_DYNFLD_STP       validObjLnkStp,
                                   DBA_DYNFLD_STP       validPspStp,
                                   DbiConnectionHelper& dbiConnHelper,
                                   COMPUTE_PAA_STP      computeStp,
                                   DBA_DYNFLD_STP      *lastPspObjLnkStpPtr)
{
    DATETIME_T      tmpDate;
    DBA_DYNFLD_STP  pspObjLnkStp;

    if ((pspObjLnkStp = ALLOC_DYNST(A_ObjectLnk)) == NULL)
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
        return(RET_MEM_ERR_ALLOC);
    }

    COPY_DYNST(pspObjLnkStp, validObjLnkStp, A_ObjectLnk);
    SET_ENUM(pspObjLnkStp, A_ObjectLnk_Nature, computeStp->objLnkNat); /* PMSTA-13058 - LJE - 111103 */

    tmpDate.date = 0;
    tmpDate.time = 0;

    /* Update the begin date of the last psp object link */
    if (lastPspObjLnkStpPtr != NULL &&
        *lastPspObjLnkStpPtr != NULL)
    {
        COPY_DYNFLD((*lastPspObjLnkStpPtr), A_ObjectLnk, A_ObjectLnk_BeginDate,
                    validObjLnkStp, A_ObjectLnk, A_ObjectLnk_EndDate);
    }

    SET_DICT(pspObjLnkStp, A_ObjectLnk_ToEntDictId, computeStp->pspEntDictId);
    COPY_DYNFLD(pspObjLnkStp, A_ObjectLnk, A_ObjectLnk_ToObjectId,
                validPspStp, A_PerfStorageParam, A_PerfStorageParam_Id);

    if (IS_NULLFLD(domainPtr, A_Domain_AuthOnlinePeriods) == TRUE)
    {
        tmpDate.date = SYB_BEGIN_DATE;
    }
    else if (GET_INT(domainPtr, A_Domain_AuthOnlinePeriods) > 0)
    {
        DATE_T date;

        if (IS_NULLFLD(validPspStp, *(computeStp->fromDIdxPtr)) == FALSE)
        {
            date = GET_DATETIME(validPspStp, *(computeStp->fromDIdxPtr)).date;
        }
        else
        {
            date = GET_DATETIME(validObjLnkStp, A_ObjectLnk_EndDate).date;
        }

        tmpDate.date = DATE_Move(date,
                                 (-1) * GET_INT(domainPtr, A_Domain_AuthOnlinePeriods),
                                 DATE_FreqUnit2DateUnit((FREQUNIT_ENUM)GET_ENUM(validPspStp, A_PerfStorageParam_FrequencyEn)));
    }
    else
    {
        tmpDate.date = GET_DATETIME(validPspStp, *(computeStp->fromDIdxPtr)).date;
    }
    tmpDate.date = DATE_MovePosi(tmpDate.date, BeginOf, Month);
    tmpDate.date = DATE_Move(tmpDate.date, -1, Day);
    SET_DATETIME(pspObjLnkStp, A_ObjectLnk_MinOnLineDate, tmpDate);

    if (IS_NULLFLD(domainPtr, A_Domain_AuthOnlinePeriods) == TRUE)
    {
        tmpDate.date = MAGIC_END_DATE;
    }
    else if (GET_INT(domainPtr, A_Domain_AuthOnlinePeriods) > 0)
    {
        DATE_T date;

        if (IS_NULLFLD(validPspStp, *(computeStp->tillDIdxPtr)) == FALSE)
        {
            date = GET_DATETIME(validPspStp, *(computeStp->tillDIdxPtr)).date;
        }
        else
        {
            date = GET_DATETIME(validObjLnkStp, A_ObjectLnk_EndDate).date;
        }

        tmpDate.date = DATE_Move(date,
                                 GET_INT(domainPtr, A_Domain_AuthOnlinePeriods),
                                 DATE_FreqUnit2DateUnit((FREQUNIT_ENUM)GET_ENUM(validPspStp, A_PerfStorageParam_FrequencyEn)));
    }
    else
    {
        tmpDate.date = GET_DATETIME(validPspStp, *(computeStp->tillDIdxPtr)).date;
    }
    tmpDate.date = DATE_MovePosi(tmpDate.date, EndOf, Month);
    SET_DATETIME(pspObjLnkStp, A_ObjectLnk_MaxOnLineDate, tmpDate);

    DBA_AddHierRecord(hierHead,
                      pspObjLnkStp,
                      A_ObjectLnk,
                      FALSE,
                      HierAddRec_NoLnk);

    if (lastPspObjLnkStpPtr != NULL)
    {
        (*lastPspObjLnkStpPtr) = pspObjLnkStp;
    }

    return (RET_SUCCEED);

}

/************************************************************************
**
**  Function        :   DBA_CmpPerfCalcDefProfCompoByPerfCalDefId()
**
**  Description     :   Sort the perf_calc_def_profile compo by perf_calc_def_id
**
**
**  Arguments       :   ptr1    first element pointer
**                      prt2    second element pointer
**
**  Return          :   TLS_Sort() comparison function return
**
**
**  Creation date   :   PMSTA-54529 - DDV - 231005
**
*************************************************************************/
STATIC int DBA_CmpPerfCalcDefProfCompoByPerfCalDefId(DBA_DYNFLD_STP* ptr1, DBA_DYNFLD_STP* ptr2)
{
    return(CMP_DYNFLD(*ptr1, *ptr2, A_PerfCalcDefProfileCompo_PerfCalcDefId, A_PerfCalcDefProfileCompo_PerfCalcDefId, IdType));
}

/************************************************************************
**
**  Function        :   DBA_CmpPerfCalcDefById()
**
**  Description     :   Sort the perf_calc_def by id
**
**
**  Arguments       :   ptr1    first element pointer
**                      prt2    second element pointer
**
**  Return          :   TLS_Sort() comparison function return
**
**
**  Creation date   :   PMSTA-54529 - DDV - 231010
**
*************************************************************************/
STATIC int DBA_CmpPerfCalcDefById(DBA_DYNFLD_STP* ptr1, DBA_DYNFLD_STP* ptr2)
{
    return(CMP_DYNFLD(*ptr1, *ptr2, A_PerfCalcDef_Id, A_PerfCalcDef_Id, IdType));
}

/************************************************************************
**  Function             : DBA_SearchBestPSPOnDate()
**
**  Description          : Search the best PSP on till date
**
**  Arguments            :
**
**  Return               : RET_SUCCEED or error code
**
**  Creation             : PMSTA09843 - LJE - 100520
**  Modification		 : PMSTA-44256 - VSW - 230621 - Removing the Date Range Condition to ensure the PSP is considered even when the Domain date range is partly within the PSP Date range.
**
*************************************************************************/
STATIC RET_CODE DBA_SearchBestPSPOnDate(DBA_HIER_HEAD_STP    hierHead,
                                        DBA_DYNFLD_STP       domainPtr,
                                        COMPUTE_PAA_STP      computeStp,
                                        DBA_MAIN_OBJ_STP     mainObjInfoStp,
                                        DBA_DYNFLD_STP      *pspTab,
                                        int                  pspNbr,
                                        DATETIME_T           beginDate,
                                        DATETIME_T           currDate,
                                        DBA_DYNFLD_STP       mainObjObjLnkStp,
                                        DBA_DYNFLD_STP       currPSPObjLnkStp,
                                        FLAG_T               forceDateFlg,
                                        DBA_DYNFLD_STP       defPPDaStp,
                                        DBA_DYNFLD_STP       domPPDaStp,
                                        DBA_DYNFLD_STP      *bestPspStpPtr)
{
    RET_CODE        ret = RET_SUCCEED;
    INT_T          *usableRankTab;
    int             pspPos, i, rankToFind = -1;
    int             bestPspNbr = 0, bestPspPos = -1, maxRank = 0;
    int             pspPosRankTab[10];
    int             pspNbrRankTab[10];
    DBA_DYNFLD_STP  lastBestPspStp = *bestPspStpPtr;
    DBA_DYNFLD_STP  pPDaStp;
    FREQUNIT_ENUM   freqNeededEn;
    MemoryPool      mp;

    PSPSELECTIONRULE_ENUM pspSelectionRule = PSPSelectionRule_AllPSP;
    GEN_GetApplInfo(ApplPSPSelectionRule, &pspSelectionRule);

    *bestPspStpPtr = NULL;

    if (GET_DICT(currPSPObjLnkStp, A_ObjectLnk_FromEntDictId) != computeStp->ptfEntDictId)
    {
        defPPDaStp = NULL;
        domPPDaStp = NULL;
    }

    if (mainObjObjLnkStp != NULL)
    {
        switch (GET_ENUM(mainObjObjLnkStp, A_ObjectLnk_Nature))
        {
            case ObjectLnkNat_PSPExtRA:
                freqNeededEn = FIN_GetDomainFreqEnForPAA(domainPtr, ExtRetAnalysis);
                break;

            case ObjectLnkNat_PSPPA:
                freqNeededEn = FIN_GetDomainFreqEnForPAA(domainPtr, PerfAttrib);
                break;

            case ObjectLnkNat_PSPSP:
            default:
                freqNeededEn = FIN_GetDomainFreqEnForPAA(domainPtr, StandardPerf);
                break;
        }
    }
    else
    {
        freqNeededEn = FIN_GetDomainFreqEnForPAA(domainPtr, *(computeStp->outObjEnPtr));
    }

    if ((usableRankTab = (INT_T*)CALLOC(pspNbr, sizeof(INT_T))) == NULL)
        return (RET_MEM_ERR_ALLOC);

    memset(pspPosRankTab, -1, 10 * sizeof(int));
    memset(pspNbrRankTab, 0, 10 * sizeof(int));

    DBA_DYNFLD_STP   *domainPerfCalcDefTab = NULLDYNSTPTR;
    int               domainPerfCalcDefNbr = 0;

    if (IS_NULLFLD(domainPtr, A_Domain_PerfCalcDefProfId) == FALSE)
    {
        DBA_LoadPerfCalcDefByProfileId(hierHead, GET_ID(domainPtr, A_Domain_PerfCalcDefProfId), &domainPerfCalcDefTab, &domainPerfCalcDefNbr, NULLDYNSTPTR);
        mp.ownerPtr(domainPerfCalcDefTab);
    }

    if (domainPerfCalcDefNbr > 1)
    {
        TLS_Sort((char*)domainPerfCalcDefTab, domainPerfCalcDefNbr, sizeof(DBA_DYNFLD_STP), (TLS_CMPFCT*)DBA_CmpPerfCalcDefById, (PTR**)NULL, SortRtnTp_None);
    }

    /* First pass */
    for (pspPos = 0; pspPos < pspNbr; pspPos++)
    {
        usableRankTab[pspPos] = 9;

        if (pspTab[pspPos] == NULL)
            continue;

        /* PMSTA-54529 - DDV - 231005 - Filter PSP not matching domain's perf_calc_def_profile */
        if (domainPerfCalcDefNbr > 0 && domainPerfCalcDefTab != NULLDYNSTPTR && 
            GET_DICT(pspTab[pspPos], A_PerfStorageParam_EntityDictId) == PtfCst) /* WEALTH-3704 - DDV - 231204 - Filtering based on pef_cal_def has sense only for portfolios, 
                                                                                                                 no perf_calc_result stored for benchmarks and instruments */
        {
            bool              bRemovePSP = true;

            if (IS_NULLFLD(pspTab[pspPos], A_PerfStorageParam_PerfCalcDefProfileId) == FALSE)
            {
                DBA_DYNFLD_STP   *pspPerfCalcDefProfCompoTab = NULLDYNSTPTR;
                int               pspPerfCalcDefProfCompoNbr = 0;

                if (DBA_SelPerfCalcDefCompoByProfileId(hierHead, GET_ID(pspTab[pspPos], A_PerfStorageParam_PerfCalcDefProfileId),
                                                       &pspPerfCalcDefProfCompoTab, &pspPerfCalcDefProfCompoNbr, mp) == RET_SUCCEED &&
                    pspPerfCalcDefProfCompoNbr >= domainPerfCalcDefNbr)
                {
                    if (pspPerfCalcDefProfCompoNbr > 1)
                    {
                        TLS_Sort((char*)pspPerfCalcDefProfCompoTab, pspPerfCalcDefProfCompoNbr, sizeof(DBA_DYNFLD_STP), (TLS_CMPFCT*)DBA_CmpPerfCalcDefProfCompoByPerfCalDefId, (PTR**)NULL, SortRtnTp_None);
                    }

                    bRemovePSP = false;
                    int  pspIdx = 0;
                    for (i = 0; i < domainPerfCalcDefNbr && bRemovePSP == false; ++i)
                    {
                        while (pspIdx < pspPerfCalcDefProfCompoNbr &&
                               CMP_DYNFLD(pspPerfCalcDefProfCompoTab[pspIdx], domainPerfCalcDefTab[i],
                                          A_PerfCalcDefProfileCompo_PerfCalcDefId, A_PerfCalcDef_Id, IdType) < 0)
                        {
                            ++pspIdx;
                        }

                        bRemovePSP = (pspIdx == pspPerfCalcDefProfCompoNbr ||
                                      CMP_DYNFLD(pspPerfCalcDefProfCompoTab[pspIdx], domainPerfCalcDefTab[i],
                                                 A_PerfCalcDefProfileCompo_PerfCalcDefId, A_PerfCalcDef_Id, IdType) != 0);
                    }
                }
            }

            if (bRemovePSP)
            {
                pspTab[pspPos] = NULL; 
                continue;
            }
        }

        if ((static_cast<LOADHIERPTF_ENUM> GET_ENUM(domainPtr, A_Domain_LoadHierFlg) != LoadHierPtf_IntermediateHierarchy) &&
            ((GET_ENUM(domainPtr, A_Domain_LoadHierFlg) == LoadHierPtf_None ||
            (PTFCONSRULE_ENUM)GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) == PtfConsRule_DetailedChildren) &&
              GET_ENUM(pspTab[pspPos], A_PerfStorageParam_PerfAttribReturnEn) == PerfAttribRtnEn_Hierarchy))
        {
            continue;
        }

        if (mainObjInfoStp != NULL)
        {
            if (mainObjInfoStp->passNbr == PASS_STORED_HIER_PSP)
            {
                if (GET_ENUM(pspTab[pspPos], A_PerfStorageParam_PerfAttribReturnEn) == PerfAttribRtnEn_Hierarchy)
                {
                    if (IS_NULLFLD(pspTab[pspPos], *(computeStp->fromDIdxPtr)) == FALSE &&
                        DATETIME_CMP(mainObjInfoStp->firstHierPSPDate, GET_DATETIME(pspTab[pspPos], *(computeStp->fromDIdxPtr))) > 0)
                    {
                        mainObjInfoStp->firstHierPSPDate = GET_DATETIME(pspTab[pspPos], *(computeStp->fromDIdxPtr));
                    }

                    if (IS_NULLFLD(pspTab[pspPos], *(computeStp->fromDIdxPtr)) == TRUE ||
                CMP_DYNFLD(pspTab[pspPos], currPSPObjLnkStp, *(computeStp->fromDIdxPtr), A_ObjectLnk_EndDate, DatetimeType) >= 0 ||
                        CMP_DYNFLD(pspTab[pspPos], currPSPObjLnkStp, *(computeStp->tillDIdxPtr), A_ObjectLnk_BeginDate, DatetimeType) <= 0)
            {
                continue;
            }
                }
                else
            {
                continue;
            }
            }

            if (computeStp->returnInParPtfRuleEn == ReturnInParentPtfRule_ParentUsingHierPSP &&
                (static_cast<LOADHIERPTF_ENUM> GET_ENUM(domainPtr, A_Domain_LoadHierFlg) != LoadHierPtf_IntermediateHierarchy))
            {
                if (((mainObjInfoStp->passNbr == PASS_PARENT_STD_PSP || mainObjInfoStp->passNbr == PASS_CHILD_STD_PSP) &&
                    GET_ENUM(pspTab[pspPos], A_PerfStorageParam_PerfAttribReturnEn) == PerfAttribRtnEn_Hierarchy) ||
                    (mainObjInfoStp->passNbr >= PASS_PARENT_HIER_PSP &&
                    GET_ENUM(pspTab[pspPos], A_PerfStorageParam_PerfAttribReturnEn) == PerfAttribRtnEn_Standard))
                {
                    continue;
                }
            }

            if (mainObjInfoStp->forceHierPSPFlg == TRUE &&
                GET_ENUM(pspTab[pspPos], A_PerfStorageParam_PerfAttribReturnEn) == PerfAttribRtnEn_Standard)
            {
                continue;
            }

            /* PMSTA-55400 - DDV - 250220 - Don't keep logical PSP with grid when no grid present in domain */
            if (IS_NULLFLD(domainPtr, A_Domain_GridId) == true &&
                IS_NULLFLD(pspTab[pspPos], A_PerfStorageParam_GridId) == false &&
                GET_ID(pspTab[pspPos], A_PerfStorageParam_Id) < 0)
            {
                continue;
            }

            if (static_cast<LOADHIERPTF_ENUM> GET_ENUM(domainPtr, A_Domain_LoadHierFlg) == LoadHierPtf_IntermediateHierarchy)
            {
                /* PMSTA-18812 - LJE - 141010 - Keep only psp having the needed grid */
                if (mainObjInfoStp->passNbr == PASS_CHILD_STD_PSP &&
                    GET_ENUM(domainPtr, A_Domain_LoadHierFlg) != LoadHierPtf_None &&
                    FIN_IsPtfConsRuleValidForIntermediateHierarchy(domainPtr) == FALSE &&
                     GET_ENUM(pspTab[pspPos], A_PerfStorageParam_PerfAttribReturnEn) == PerfAttribRtnEn_Standard &&
                    GET_ENUM(domainPtr, A_Domain_RetDetLevelEn) == PtfRetDetLvl_UsePSP &&
                    IS_NULLFLD(domainPtr, A_Domain_GridId) == FALSE &&
                    CMP_DYNFLD(pspTab[pspPos], domainPtr, A_PerfStorageParam_GridId, A_Domain_GridId, IdType) != 0)
                {
                    continue;
                }
            }
            else
            {
                /* PMSTA-18812 - LJE - 141010 - Keep only psp having the needed grid */
                if (mainObjInfoStp->passNbr == PASS_CHILD_STD_PSP &&
                    GET_ENUM(domainPtr, A_Domain_LoadHierFlg) != LoadHierPtf_None &&
                    (PTFCONSRULE_ENUM)GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) != PtfConsRule_DetailedChildren &&
                    GET_ENUM(pspTab[pspPos], A_PerfStorageParam_PerfAttribReturnEn) == PerfAttribRtnEn_Standard &&
                    GET_ENUM(domainPtr, A_Domain_RetDetLevelEn) == PtfRetDetLvl_UsePSP &&
                    IS_NULLFLD(domainPtr, A_Domain_GridId) == FALSE &&
                    CMP_DYNFLD(pspTab[pspPos], domainPtr, A_PerfStorageParam_GridId, A_Domain_GridId, IdType) != 0)
                {
                    continue;
                }
            }
        }

        /* PMSTA-11283 - LJE - 110125 - if we want to force the date, but the date is null,
                                        try to find a stored "no longer active" PSP */
		 /* If the last PSP found haven't dates, try to find a stored PSP on the period */
        if (forceDateFlg == TRUE &&
            currDate.date == 0 &&           
			DATETIME_CMP(beginDate, GET_DATETIME(pspTab[pspPos], *(computeStp->tillDIdxPtr))) < 0)
        {
			/* First rank */
            usableRankTab[pspPos] = 0;
        }
        else if (GET_FLAG(pspTab[pspPos], *(computeStp->outEntFlgIdxPtr)) == TRUE &&
                 (IS_NULLFLD(pspTab[pspPos], *(computeStp->fromDIdxPtr)) == TRUE ||
                 IS_NULLFLD(pspTab[pspPos], *(computeStp->tillDIdxPtr)) == TRUE))
        {
            usableRankTab[pspPos] = 1;
        }        
        else if (DATETIME_CMP(currDate, GET_DATETIME(pspTab[pspPos], *(computeStp->tillDIdxPtr))) <= 0 &&
                 DATETIME_CMP(currDate, GET_DATETIME(pspTab[pspPos], *(computeStp->fromDIdxPtr))) > 0)
        {
            /* First rank */
            usableRankTab[pspPos] = 0;
        }
        /* If PSP is still active, it's the same prio than no dates */
        else if (GET_FLAG(pspTab[pspPos], *(computeStp->outEntFlgIdxPtr)) == TRUE)
        {
            usableRankTab[pspPos] = 1;
        }
        /* PSP was used but is no more now */
        else if (IS_NULLFLD(pspTab[pspPos], *(computeStp->tillDIdxPtr)) == FALSE)
        {
            usableRankTab[pspPos] = 2;
        }
        if ((GET_ENUM(domainPtr, A_Domain_RetDetLevelEn) == PtfRetDetLvl_Grid ||
            GET_FLAG(domainPtr, A_Domain_SubGridFlg) == TRUE) && /* PMSTA-12078 - LJE - 110625 */
            IS_NULLFLD(domainPtr, A_Domain_GridId) == FALSE &&
            CMP_DYNFLD(domainPtr, pspTab[pspPos], A_Domain_GridId, A_PerfStorageParam_GridId, IdType) != 0)
        {
            /* If not the same grid, reject the PSP */
            usableRankTab[pspPos] = 9;
        }
        /* PMSTA-12020 - LJE - 110708 */
        else if (GET_DICT(pspTab[pspPos], A_PerfStorageParam_EntityDictId) == computeStp->ptfEntDictId && /* PMSTA- - LJE - 170410 */
                 GET_ENUM(domainPtr, A_Domain_RetDetLevelEn) != PtfRetDetLvl_UsePSP &&
                 IS_NULLFLD(domainPtr, A_Domain_PSPPositionDataId) == FALSE &&
                 CMP_DYNFLD(pspTab[pspPos], domainPtr,
                 A_PerfStorageParam_PositionDataId, A_Domain_PSPPositionDataId, IdType) != 0)
        {
            /* If PSP position data needed but the same than the current, reject the PSP */
            usableRankTab[pspPos] = 9;
        }
        else if (GET_ENUM(domainPtr, A_Domain_RetDetLevelEn) != PtfRetDetLvl_UsePSP &&
                 GET_ENUM(pspTab[pspPos], A_PerfStorageParam_FrequencyEn) > freqNeededEn)
        {
            /* If frequency is bigger, reject the PSP */
            usableRankTab[pspPos] = 9;
        }
        else if (usableRankTab[pspPos] < 3 &&
                 GET_ENUM(currPSPObjLnkStp, A_ObjectLnk_Nature) != ObjectLnkNat_PSPSP &&
                 GET_ENUM(domainPtr, A_Domain_RetDetLevelEn) == PtfRetDetLvl_Instrument &&
                 GET_FLAG(pspTab[pspPos], A_PerfStorageParam_InstrLevelFlg) == FALSE)
        {
            /* We need instrument flag! */
            usableRankTab[pspPos] = 9; /* PMSTA-12865 - LJE - 120123 */
        }
        else if (usableRankTab[pspPos] != 0 &&
                 GET_ENUM(domainPtr, A_Domain_RetDetLevelEn) == PtfRetDetLvl_UsePSP && /* PMSTA-10640 - LJE - 101020 */
                 IS_NULLFLD(pspTab[pspPos], A_PerfStorageParam_GridId) == FALSE &&
                 GET_ENUM(domainPtr, A_Domain_RetDetLevelEn) == PtfRetDetLvl_Global)
        {
            /* No only on grid */
            usableRankTab[pspPos] = 9;
        }

        pPDaStp = NULL;
        if (GET_ENUM(domainPtr, A_Domain_RetDetLevelEn) != PtfRetDetLvl_UsePSP &&
            usableRankTab[pspPos] < 3 &&
            defPPDaStp != NULL &&
            FIN_GetPPDa(hierHead,
            computeStp,
            pspTab[pspPos],
            &defPPDaStp,
            &pPDaStp) == RET_SUCCEED &&
            pPDaStp != NULL &&
            FIN_CmpPPDa(computeStp, domPPDaStp, pPDaStp) == FALSE)
        {
            /* Rejected by the PSP position data */
            usableRankTab[pspPos] = 9;
        }

        if (usableRankTab[pspPos] < 3)
        {
            bestPspNbr++;
            bestPspPos = pspPos;
        }

        pspPosRankTab[usableRankTab[pspPos]] = pspPos;
        pspNbrRankTab[usableRankTab[pspPos]]++;
    }

    if (forceDateFlg == TRUE)
    {
        maxRank = 1;
    }
    else
    {
        maxRank = 3;
    }

    /* The 3 first rank is considers as the best (if only one) */
    for (i = 0; i < maxRank; i++)
    {
        /* If use PSP, choose the first case that we have only one PSP */
        if (GET_ENUM(domainPtr, A_Domain_RetDetLevelEn) == PtfRetDetLvl_UsePSP &&
            pspNbrRankTab[i] == 1)
        {
            *bestPspStpPtr = pspTab[pspPosRankTab[i]];
            pspTab[pspPosRankTab[i]] = NULL;
            FREE(usableRankTab);
            return (ret);
        }
        else if (pspNbrRankTab[i] >= 1)
        {
            rankToFind = i;
            break;
        }
    }

    if (rankToFind >= 0)
    {
        /* Second pass */
        /* Search by Old PSP */
        for (pspPos = 0; pspPos < pspNbr; pspPos++)
        {
            if (pspTab[pspPos] == NULL)
                continue;

            if (lastBestPspStp != NULL &&
                IS_NULLFLD(lastBestPspStp, A_PerfStorageParam_OldPerfStorageParamId) == FALSE &&
                CMP_DYNFLD(lastBestPspStp, pspTab[pspPos],
                A_PerfStorageParam_OldPerfStorageParamId, A_PerfStorageParam_Id, IdType) == 0)
            {
                *bestPspStpPtr = pspTab[pspPos];
                pspTab[pspPos] = NULL;
                FREE(usableRankTab);
                return (ret);
            }
        }

        /* if hierarchy needed, prefer hierarchy PSP */
        if (GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None &&
            (static_cast<LOADHIERPTF_ENUM> GET_ENUM(domainPtr, A_Domain_LoadHierFlg) != LoadHierPtf_IntermediateHierarchy))
        {
            FLAG_T hierPSPFlg = FALSE;

            for (pspPos = 0; pspPos < pspNbr && hierPSPFlg == FALSE; pspPos++)
            {
                if (pspTab[pspPos] == NULL ||
                    usableRankTab[pspPos] != rankToFind)
                    continue;

                if (GET_ENUM(pspTab[pspPos], A_PerfStorageParam_PerfAttribReturnEn) == PerfAttribRtnEn_Hierarchy)
                {
                    hierPSPFlg = TRUE;
                }
            }

            if (hierPSPFlg == TRUE)
            {
                pspNbrRankTab[rankToFind] = 0;
                /* PMSTA-12966 - LJE - 120323 - Fix load non-discretionary case */
                for (pspPos = 0; pspPos < pspNbr; pspPos++)
                {
                    if (pspTab[pspPos] == NULL ||
                        usableRankTab[pspPos] != rankToFind)
                        continue;

                    if (GET_ENUM(pspTab[pspPos], A_PerfStorageParam_PerfAttribReturnEn) == PerfAttribRtnEn_Hierarchy)
                    {
                        pspPosRankTab[usableRankTab[pspPos]] = pspPos;
                        pspNbrRankTab[usableRankTab[pspPos]]++;
                    }
                    else
                    {
                        /* Exclude this PSP */
                        usableRankTab[pspPos] = 9;
                    }
                }
            }
        }

        /* Search by PSP position data */
        if (pspNbrRankTab[rankToFind] > 0)
        {
            if (IS_NULLFLD(domainPtr, A_Domain_PSPPositionDataId) == FALSE && (mainObjObjLnkStp != NULL) &&
                GET_DICT(mainObjObjLnkStp, A_ObjectLnk_FromEntDictId) == computeStp->ptfEntDictId) /* PMSTA- - LJE - 170410 */
            {
                pspNbrRankTab[rankToFind] = 0;
                for (pspPos = 0; pspPos < pspNbr; pspPos++)
                {
                    if (pspTab[pspPos] == NULL ||
                        usableRankTab[pspPos] != rankToFind)
                        continue;

                    if (CMP_DYNFLD(pspTab[pspPos], domainPtr,
                        A_PerfStorageParam_PositionDataId, A_Domain_PSPPositionDataId, IdType) == 0)
                    {
                        pspPosRankTab[usableRankTab[pspPos]] = pspPos;
                        pspNbrRankTab[usableRankTab[pspPos]]++;
                    }
                    else
                    {
                        /* Exclude this PSP */
                        usableRankTab[pspPos] = 99;
                    }
                }

                if (pspNbrRankTab[rankToFind] == 0)
                {
                    for (pspPos = 0; pspPos < pspNbr; pspPos++)
                    {
                        if (pspTab[pspPos] != NULL &&
                            usableRankTab[pspPos] == 99)
                        {
                            usableRankTab[pspPos] = rankToFind;
                        }
                    }
                }
                else
                {
                    for (pspPos = 0; pspPos < pspNbr; pspPos++)
                    {
                        if (pspTab[pspPos] != NULL &&
                            usableRankTab[pspPos] == 99)
                        {
                            usableRankTab[pspPos] = 9;
                        }
                    }
                }
            }
        }

        /* Search by grid */
        if (pspNbrRankTab[rankToFind] > 0)
        {
            if (IS_NULLFLD(domainPtr, A_Domain_GridId) == FALSE)
            {
                pspNbrRankTab[rankToFind] = 0;
                for (pspPos = 0; pspPos < pspNbr; pspPos++)
                {
                    if (pspTab[pspPos] == NULL ||
                        usableRankTab[pspPos] != rankToFind)
                        continue;

                    if (CMP_DYNFLD(pspTab[pspPos], domainPtr,
                        A_PerfStorageParam_GridId, A_Domain_GridId, IdType) == 0)
                    {
                        pspPosRankTab[usableRankTab[pspPos]] = pspPos;
                        pspNbrRankTab[usableRankTab[pspPos]]++;
                    }
                    else
                    {
                        /* Exclude this PSP */
                        usableRankTab[pspPos] = 9;
                    }
                }
            }
        }

        /* Search by the frequency */
        if (pspNbrRankTab[rankToFind] > 1)
        {
            if (GET_ENUM(domainPtr, A_Domain_Freq1UnitEn) != FreqUnit_None)
            {
                pspNbrRankTab[rankToFind] = 0;
                for (pspPos = 0; pspPos < pspNbr; pspPos++)
                {
                    if (pspTab[pspPos] == NULL ||
                        usableRankTab[pspPos] != rankToFind)
                        continue;

                    if (GET_ENUM(pspTab[pspPos], A_PerfStorageParam_FrequencyEn) == freqNeededEn)
                    {
                        pspPosRankTab[usableRankTab[pspPos]] = pspPos;
                        pspNbrRankTab[usableRankTab[pspPos]]++;
                    }
                    else
                    {
                        /* Exclude this PSP */
                        usableRankTab[pspPos] = 99;
                    }
                }

                if (pspNbrRankTab[rankToFind] == 0)
                {
                    for (pspPos = 0; pspPos < pspNbr; pspPos++)
                    {
                        if (pspTab[pspPos] != NULL &&
                            usableRankTab[pspPos] == 99)
                        {
                            usableRankTab[pspPos] = rankToFind;
                        }
                    }
                }
                else
                {
                    for (pspPos = 0; pspPos < pspNbr; pspPos++)
                    {
                        if (pspTab[pspPos] != NULL &&
                            usableRankTab[pspPos] == 99)
                        {
                            usableRankTab[pspPos] = 9;
                        }
                    }
                }
            }
        }

        /* Search by currency */
        if (pspNbrRankTab[rankToFind] > 1)
        {
            ID_T defCurrId = 0;

            pspNbrRankTab[rankToFind] = 0;
            for (pspPos = 0; pspPos < pspNbr; pspPos++)
            {
                if (pspTab[pspPos] == NULL ||
                    usableRankTab[pspPos] != rankToFind)
                    continue;

                if (defCurrId == 0)
                {
                    OBJECT_ENUM objEn;

                    DBA_GetObjectEnum(GET_DICT(pspTab[pspPos], A_PerfStorageParam_EntityDictId), &objEn);
                    FIN_GetDefaultCurrencyId(domainPtr,
                                             hierHead,
                                             objEn,
                                             GET_ID(pspTab[pspPos], A_PerfStorageParam_ObjId),
                                             &defCurrId);
                }

                if (CMP_ID(GET_ID(pspTab[pspPos], A_PerfStorageParam_CurrId), defCurrId) == 0)
                {
                    pspPosRankTab[usableRankTab[pspPos]] = pspPos;
                    pspNbrRankTab[usableRankTab[pspPos]]++;
                }
                else
                {
                    /* Exclude this PSP */
                    usableRankTab[pspPos] = 9;
                }
            }

            if (pspNbrRankTab[rankToFind] == 0)
            {
                for (pspPos = 0; pspPos < pspNbr; pspPos++)
                {
                    if (pspTab[pspPos] != NULL &&
                        usableRankTab[pspPos] == 99)
                    {
                        usableRankTab[pspPos] = rankToFind;
                    }
                }
            }
            else
            {
                for (pspPos = 0; pspPos < pspNbr; pspPos++)
                {
                    if (pspTab[pspPos] != NULL &&
                        usableRankTab[pspPos] == 99)
                    {
                        usableRankTab[pspPos] = 9;
                    }
                }
            }
        }

        /* PMSTA-11283 - LJE - 110125 - Take the last stored... */
        if (pspNbrRankTab[rankToFind] != 1)
        {
            DATE_T lastDate = 0;

            for (pspPos = 0; pspPos < pspNbr; pspPos++)
            {
                if (pspTab[pspPos] == NULL ||
                    usableRankTab[pspPos] != rankToFind)
                    continue;

                if (lastDate < GET_DATETIME(pspTab[pspPos], *(computeStp->tillDIdxPtr)).date)
                {
                    lastDate = GET_DATETIME(pspTab[pspPos], *(computeStp->tillDIdxPtr)).date;
                }
            }

            pspNbrRankTab[rankToFind] = 0;
            for (pspPos = 0; pspPos < pspNbr; pspPos++)
            {
                if (pspTab[pspPos] == NULL ||
                    usableRankTab[pspPos] != rankToFind)
                    continue;

                if (lastDate == GET_DATETIME(pspTab[pspPos], *(computeStp->tillDIdxPtr)).date)
                {
                    pspPosRankTab[usableRankTab[pspPos]] = pspPos;
                    pspNbrRankTab[usableRankTab[pspPos]]++;
                }
                else
                {
                    /* Exclude this PSP */
                    usableRankTab[pspPos] = 9;
                }
            }
        }

        *bestPspStpPtr = pspTab[pspPosRankTab[rankToFind]];
        pspTab[pspPosRankTab[rankToFind]] = NULL;
        FREE(usableRankTab);
        return (ret);
    }
    else if (forceDateFlg == FALSE &&
             (mainObjInfoStp == NULL || mainObjInfoStp->passNbr != PASS_STORED_HIER_PSP) &&
             GET_ENUM(domainPtr, A_Domain_RetDetLevelEn) != PtfRetDetLvl_UsePSP)
    {
        DBA_DYNFLD_STP *newPspTab = NULL;
        int             newPspNbr = 0;

        if (DBA_CreateValidPSP(hierHead, domainPtr, computeStp, mainObjInfoStp, mainObjObjLnkStp, currPSPObjLnkStp, domPPDaStp, &newPspNbr, &newPspTab) == RET_SUCCEED &&
            newPspTab != NULL)
        {
            /* PMSTA-17234 - LJE - 131118 */
            if (mainObjInfoStp != NULL)
            {
                if (mainObjInfoStp->passNbr >= PASS_PARENT_HIER_PSP ||
                    newPspNbr == 1 ||
                    DATETIME_CMP(currDate, mainObjInfoStp->firstHierPSPDate) > 0)
                {
                    *bestPspStpPtr = newPspTab[0];
                }
                else
                {
                    *bestPspStpPtr = newPspTab[1];
                }
            }

        }
        FREE(newPspTab);
    }

    FREE(usableRankTab);
    return (ret);
}


/************************************************************************
**  Function             : DBA_LoadStandardPerfPSP()
**
**  Description          : Search and put in #dom_psp for standard perf
**
**  Arguments            :
**
**  Return               : RET_SUCCEED or error code
**
**  Creation             : PMSTA09843 - LJE - 100520
**
*************************************************************************/
STATIC RET_CODE DBA_LoadStandardPerfPSP(DBA_HIER_HEAD_STP    hierHead,
                                        DBA_DYNFLD_STP       domainPtr,
                                        DbiConnectionHelper& dbiConnHelper,
                                        COMPUTE_PAA_STP      computeTab,
                                        DBA_DYNFLD_STP       mainObjObjLnkStp,
                                        DBA_DYNFLD_STP       currPSPObjLnkStp,
                                        DBA_DYNFLD_STP       lastGridObjLnkStp,
                                        DBA_DYNFLD_STP       defPPDaStp,
                                        DBA_DYNFLD_STP       domPPDaStp,
                                        FLAG_T               forceDateFlg,
                                        FLAG_T               allowOnlineFlg)
{
    RET_CODE       ret = RET_SUCCEED;
    DBA_DYNFLD_STP *pspTab, bestPspStp = NULL;
    int            pspNbr;
    FLAG_T         endFlg = FALSE;
    DBA_DYNFLD_STP lastPspObjLnkStp = NULL;
    ID_T           savedGridId = GET_ID(domainPtr, A_Domain_GridId);

    SET_NULL_ID(domainPtr, A_Domain_GridId);

    /* Extract all current PSP */
    if ((ret = DBA_HierEltRecExtract(hierHead,
        A_PerfStorageParam,
        FALSE,
        DBA_FilterPSPforCurrent,
        currPSPObjLnkStp,
        FIN_CmpPspByEntIdObjIdDt,  /* PMSTA-13946 - LJE - 120328 */
        FALSE,
        FALSE,
        &pspNbr,
        &pspTab)) != RET_SUCCEED)
    {
        SET_ID(domainPtr, A_Domain_GridId, savedGridId);
        return(ret);
    }

    if (pspNbr == 0)
    {
        if (allowOnlineFlg == FALSE ||
            DBA_CreateValidPSP(hierHead, domainPtr, computeTab, NULL, mainObjObjLnkStp, currPSPObjLnkStp, domPPDaStp, &pspNbr, &pspTab) != RET_SUCCEED ||
            pspNbr == 0)
        {
            SET_ID(domainPtr, A_Domain_GridId, savedGridId);
            return ret;
        }
    }

    while (endFlg == FALSE)
    {
        if (DBA_SearchBestPSPOnDate(hierHead,
            domainPtr,
            &computeTab[STD_PERF_IDX],
            NULL,
            pspTab,
            pspNbr,
            GET_DATETIME(currPSPObjLnkStp, A_ObjectLnk_BeginDate),
            GET_DATETIME(currPSPObjLnkStp, A_ObjectLnk_EndDate),
            mainObjObjLnkStp,
            currPSPObjLnkStp,
            forceDateFlg,
            defPPDaStp,
            domPPDaStp,
            &bestPspStp) == RET_SUCCEED &&
            bestPspStp != NULL)
        {
            /* PMSTA-11283 - LJE - 110125 */
            if (IS_NULLFLD(currPSPObjLnkStp, A_ObjectLnk_EndDate) == TRUE)
            {
                if (CMP_DYNFLD(domainPtr, bestPspStp,
                    *(computeTab[STD_PERF_IDX].domTillDIdxPtr), *(computeTab[STD_PERF_IDX].tillDIdxPtr), DatetimeType) < 0)
                {
                    COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_EndDate,
                                domainPtr, A_Domain, *(computeTab[STD_PERF_IDX].domTillDIdxPtr));
                }
                else
                {
                    COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_EndDate,
                                bestPspStp, A_PerfStorageParam, *(computeTab[STD_PERF_IDX].tillDIdxPtr));
                }
            }
            if (CMP_DYNFLD(currPSPObjLnkStp, domainPtr,
                A_ObjectLnk_EndDate, A_Domain_InterpFromDate, DatetimeType) >= 0)
            {
                if (GET_ENUM(bestPspStp, A_PerfStorageParam_FrequencyEn) > GET_ENUM(domainPtr, A_Domain_Freq2UnitEn))
                {
                    SET_ENUM(domainPtr, A_Domain_Freq2UnitEn, GET_ENUM(bestPspStp, A_PerfStorageParam_FrequencyEn));
                }
            }
            else if (GET_ENUM(bestPspStp, A_PerfStorageParam_FrequencyEn) > GET_ENUM(domainPtr, A_Domain_Freq1UnitEn))
            {
                SET_ENUM(domainPtr, A_Domain_Freq1UnitEn, GET_ENUM(bestPspStp, A_PerfStorageParam_FrequencyEn));
            }

            if ((ret = DBA_InsertValidPSP(hierHead,
                domainPtr,
                currPSPObjLnkStp,
                bestPspStp,
                dbiConnHelper,
                &computeTab[STD_PERF_IDX],
                &lastPspObjLnkStp)) != RET_SUCCEED)
            {
                SET_ID(domainPtr, A_Domain_GridId, savedGridId);
                FREE(pspTab);
                return (ret);
            }

            if (lastGridObjLnkStp == NULL ||
                CMP_DYNFLD(bestPspStp, lastGridObjLnkStp, A_PerfStorageParam_GridId, A_ObjectLnk_ToObjectId, IdType) != 0)
            {
                DBA_InsertCopyGridObjLnk(hierHead,
                                         domainPtr,
                                         computeTab,
                                         currPSPObjLnkStp,
                                         lastGridObjLnkStp,
                                         bestPspStp);
            }

            COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_EndDate,
                        bestPspStp, A_PerfStorageParam, *(computeTab[STD_PERF_IDX].fromDIdxPtr));

        }

        if (bestPspStp == NULL ||
            IS_NULLFLD(bestPspStp, *(computeTab[STD_PERF_IDX].fromDIdxPtr)) == TRUE ||
            CMP_DYNFLD(currPSPObjLnkStp, bestPspStp,
            A_ObjectLnk_BeginDate, *(computeTab[STD_PERF_IDX].fromDIdxPtr), DatetimeType) >= 0)
        {
            endFlg = TRUE;
        }

        forceDateFlg = TRUE;
    }

    SET_ID(domainPtr, A_Domain_GridId, savedGridId);
    FREE(pspTab);
    return (ret);
}

/************************************************************************
**  Function             : DBA_LoadPerfCalcResultPSP()
**
**  Description          : Search and put in #dom_psp for Perf Calc Result
**
**  Arguments            :
**
**  Return               : RET_SUCCEED or error code
**
**  Creation             : WEALTH-4012 - SENTHIL - 240507
**
*************************************************************************/
STATIC RET_CODE DBA_LoadPerfCalcResultPSP(DBA_HIER_HEAD_STP    hierHead,
    DBA_DYNFLD_STP       domainPtr,
    DbiConnectionHelper& dbiConnHelper,
    COMPUTE_PAA_STP      computeTab,
    DBA_DYNFLD_STP       mainObjObjLnkStp,
    DBA_DYNFLD_STP       currPSPObjLnkStp,
    DBA_DYNFLD_STP       lastGridObjLnkStp,
    DBA_DYNFLD_STP       defPPDaStp,
    DBA_DYNFLD_STP       domPPDaStp,
    FLAG_T               forceDateFlg,
    FLAG_T               allowOnlineFlg)
{
    RET_CODE       ret = RET_SUCCEED;
    DBA_DYNFLD_STP* pspTab, bestPspStp = NULL;
    int            pspNbr;
    FLAG_T         endFlg = FALSE;
    DBA_DYNFLD_STP lastPspObjLnkStp = NULL;
    ID_T           savedGridId = GET_ID(domainPtr, A_Domain_GridId);

    SET_NULL_ID(domainPtr, A_Domain_GridId);

    /* Extract all current PSP */
    if ((ret = DBA_HierEltRecExtract(hierHead,
        A_PerfStorageParam,
        FALSE,
        DBA_FilterPSPforCurrent,
        currPSPObjLnkStp,
        FIN_CmpPspByEntIdObjIdDt,  
        FALSE,
        FALSE,
        &pspNbr,
        &pspTab)) != RET_SUCCEED)
    {
        SET_ID(domainPtr, A_Domain_GridId, savedGridId);
        return(ret);
    }

    if (pspNbr == 0)
    {
        if (allowOnlineFlg == FALSE ||
            DBA_CreateValidPSP(hierHead, domainPtr, computeTab, NULL, mainObjObjLnkStp, currPSPObjLnkStp, domPPDaStp, &pspNbr, &pspTab) != RET_SUCCEED ||
            pspNbr == 0)
        {
            SET_ID(domainPtr, A_Domain_GridId, savedGridId);
            return ret;
        }
    }
    while (endFlg == FALSE)
    {
        if (DBA_SearchBestPSPOnDate(hierHead,
            domainPtr,
            &computeTab[PERF_CALC_RES_IDX],
            NULL,
            pspTab,
            pspNbr,
            GET_DATETIME(currPSPObjLnkStp, A_ObjectLnk_BeginDate),
            GET_DATETIME(currPSPObjLnkStp, A_ObjectLnk_EndDate),
            mainObjObjLnkStp,
            currPSPObjLnkStp,
            forceDateFlg,
            defPPDaStp,
            domPPDaStp,
            &bestPspStp) == RET_SUCCEED &&
            bestPspStp != NULL)
        {
            /* PMSTA-11283 - LJE - 110125 */
            if (IS_NULLFLD(currPSPObjLnkStp, A_ObjectLnk_EndDate) == TRUE)
            {
                if (CMP_DYNFLD(domainPtr, bestPspStp,
                    *(computeTab[PERF_CALC_RES_IDX].domTillDIdxPtr), *(computeTab[PERF_CALC_RES_IDX].tillDIdxPtr), DatetimeType) < 0)
                {
                    COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_EndDate,
                        domainPtr, A_Domain, *(computeTab[PERF_CALC_RES_IDX].domTillDIdxPtr));
                }
                else
                {
                    COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_EndDate,
                        bestPspStp, A_PerfStorageParam, *(computeTab[PERF_CALC_RES_IDX].tillDIdxPtr));
                }
            }
            if (CMP_DYNFLD(currPSPObjLnkStp, domainPtr,
                A_ObjectLnk_EndDate, A_Domain_InterpFromDate, DatetimeType) >= 0)
            {
                if (GET_ENUM(bestPspStp, A_PerfStorageParam_FrequencyEn) > GET_ENUM(domainPtr, A_Domain_Freq2UnitEn))
                {
                    SET_ENUM(domainPtr, A_Domain_Freq2UnitEn, GET_ENUM(bestPspStp, A_PerfStorageParam_FrequencyEn));
                }
            }
            else if (GET_ENUM(bestPspStp, A_PerfStorageParam_FrequencyEn) > GET_ENUM(domainPtr, A_Domain_Freq1UnitEn))
            {
                SET_ENUM(domainPtr, A_Domain_Freq1UnitEn, GET_ENUM(bestPspStp, A_PerfStorageParam_FrequencyEn));
            }

            if ((ret = DBA_InsertValidPSP(hierHead,
                domainPtr,
                currPSPObjLnkStp,
                bestPspStp,
                dbiConnHelper,
                &computeTab[PERF_CALC_RES_IDX],
                &lastPspObjLnkStp)) != RET_SUCCEED)
            {
                FREE(pspTab);
                return (ret);
            }

                    }

        if (bestPspStp == NULL ||
            IS_NULLFLD(bestPspStp, *(computeTab[PERF_CALC_RES_IDX].fromDIdxPtr)) == TRUE ||
            CMP_DYNFLD(currPSPObjLnkStp, bestPspStp,
                A_ObjectLnk_BeginDate, *(computeTab[PERF_CALC_RES_IDX].fromDIdxPtr), DatetimeType) >= 0)
        {
            endFlg = TRUE;
        }

        forceDateFlg = TRUE;
    }

    FREE(pspTab);
    return (ret);
}

/************************************************************************
**  Function             : DBA_LoadRiskFreePSP()
**
**  Description          : Search and put in #dom_psp risk free instrument
**
**  Arguments            :
**
**  Return               : RET_SUCCEED or error code
**
**  Creation             : PMSTA09843 - LJE - 100520
**
*************************************************************************/
STATIC RET_CODE DBA_LoadRiskFreePSP(DBA_HIER_HEAD_STP    hierHead,
                                    DBA_DYNFLD_STP       domainPtr,
                                    DbiConnectionHelper& dbiConnHelper,
                                    COMPUTE_PAA_STP      computeTab)
{
    RET_CODE       ret = RET_SUCCEED;
    DBA_DYNFLD_STP currPSPObjLnkStp;

    /* Check if risk free exists */
    if (IS_NULLFLD(domainPtr, A_Domain_RiskFreeInstrId) == TRUE)
        return (ret);

    if ((currPSPObjLnkStp = ALLOC_DYNST(A_ObjectLnk)) == NULL)
    {
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
        return(RET_MEM_ERR_ALLOC);
    }

    SET_DICT(currPSPObjLnkStp, A_ObjectLnk_FromEntDictId, computeTab->instrEntDictId);

    COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_FromObjectId,
                domainPtr, A_Domain, A_Domain_RiskFreeInstrId);

    SET_ENUM(currPSPObjLnkStp, A_ObjectLnk_Nature, ObjectLnkNat_PSPSP);

    COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_BeginDate,
                domainPtr, A_Domain, A_Domain_CalcRefDate);
    COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_EndDate,
                domainPtr, A_Domain, A_Domain_InterpTillDate);

    SET_INT(currPSPObjLnkStp, A_ObjectLnk_Rank, 0); /* PMSTA50244 - MKK - 230123 */

    DBA_LoadStandardPerfPSP(hierHead,
                            domainPtr,
                            dbiConnHelper,
                            computeTab,
                            NULL,
                            currPSPObjLnkStp,
                            NULL,
                            NULL,
                            NULL,
                            FALSE,
                            FALSE);

    FREE_DYNST(currPSPObjLnkStp, A_ObjectLnk);

    return (ret);
}

/************************************************************************
**  Function             : DBA_LoadPerfAttribPSP()
**
**  Description          : Search and put in #dom_psp for standard perf
**
**  Arguments            :
**
**  Return               : RET_SUCCEED or error code
**
**  Creation             : PMSTA09979 - LJE - 100722
**
*************************************************************************/
STATIC RET_CODE DBA_LoadPerfAttribPSP(DBA_HIER_HEAD_STP    hierHead,
                                      DBA_DYNFLD_STP       domainPtr,
                                      DbiConnectionHelper& dbiConnHelper,
                                      COMPUTE_PAA_STP      computeTab,
                                      DBA_DYNFLD_STP       mainObjObjLnkStp,
                                      DBA_DYNFLD_STP       currPSPObjLnkStp,
                                      DBA_DYNFLD_STP       gridObjLnkStp,
                                      DBA_DYNFLD_STP       defPPDaStp,
                                      DBA_DYNFLD_STP       domPPDaStp,
                                      DBA_DYNFLD_STP       benchObjLnkStp)
{
    RET_CODE       ret = RET_SUCCEED;
    DBA_DYNFLD_STP *pspTab, bestPspStp = NULL;
    int            pspNbr;
    FLAG_T         endFlg = FALSE;
    FLAG_T         forceDateFlg = FALSE;
    DBA_DYNFLD_STP lastPspObjLnkStp = NULL, lastStdPerfPspObjLnkStp = NULL;
    int            currComputeIdx = PERF_ATTRIB_IDX;
    ID_T           savedGridId = GET_ID(domainPtr, A_Domain_GridId);
    FLAG_T         stratWithGrid = TRUE;    /* WEALTH-3200 - KOR - 20240405 */
    MemoryPool     mp;

    COPY_DYNFLD(domainPtr, A_Domain, A_Domain_GridId,
                gridObjLnkStp, A_ObjectLnk, A_ObjectLnk_ToObjectId);

    if (GET_DICT(currPSPObjLnkStp, A_ObjectLnk_FromEntDictId) == computeTab->instrEntDictId)
    {
        /* Check validity of the benchmark link -> instrument on rank 2 and 3 is not allowed */
        if (GET_INT(benchObjLnkStp, A_ObjectLnk_Rank) > 1) /* PMSTA50244 - MKK - 230123 */
        {
            return RET_GEN_INFO_NOACTION;
        }

        SET_ENUM(currPSPObjLnkStp, A_ObjectLnk_Nature, ObjectLnkNat_PSPSP);
        SET_NULL_ID(domainPtr, A_Domain_GridId);
        currComputeIdx = STD_PERF_IDX;
    }

    /* Extract all current PSP */
    if ((ret = DBA_HierEltRecExtract(hierHead,
        A_PerfStorageParam,
        FALSE,
        DBA_FilterPSPforCurrent,
        currPSPObjLnkStp,
        FIN_CmpPspByEntIdObjIdDt,  /* PMSTA-13946 - LJE - 120328 */
        FALSE,
        FALSE,
        &pspNbr,
        &pspTab)) != RET_SUCCEED)
    {
        FREE(pspTab);
        SET_ID(domainPtr, A_Domain_GridId, savedGridId);
        return(ret);
    }
    if (pspTab != nullptr)
        mp.ownerPtr(pspTab);

    /* Check validity of the benchmark link -> strategy without grid is not allowed */
    if (GET_DICT(currPSPObjLnkStp, A_ObjectLnk_FromEntDictId) == computeTab->stratEntDictId)
    {
        FLAG_T gridFoundFlg = FALSE;
        int    i;
       stratWithGrid = FALSE;

        /* PMSTA-10640 - LJE - 101025 - Check if the strat is on the good grid */
        if (IS_NULLFLD(domainPtr, A_Domain_GridId) == FALSE)
        {
            stratWithGrid = TRUE;
            for (i = 0; i < pspNbr && gridFoundFlg == FALSE; i++)
            {
                if (CMP_DYNFLD(domainPtr, pspTab[i], A_Domain_GridId, A_PerfStorageParam_GridId, IdType) == FALSE)
                {
                    gridFoundFlg = TRUE;
                }
            }
        }

        if (gridFoundFlg == FALSE && GET_ENUM(domainPtr, A_Domain_RetDetLevelEn) != PtfRetDetLvl_Instrument)
        {
            DBA_DYNFLD_STP stratPtr;
            if ((stratPtr = DBA_SearchHierRecById(hierHead,
                A_Strat,
                A_Strat_Id,
                GET_ID(currPSPObjLnkStp, A_ObjectLnk_FromObjectId))) == NULL)
            {
                SET_ID(domainPtr, A_Domain_GridId, savedGridId);
                return RET_GEN_INFO_NOACTION;
            }
            /* PMSTA-11206 - LJE - 110120 */
            else if ((IS_NULLFLD(stratPtr, A_Strat_GridObjId) == FALSE ||
                GET_ENUM(stratPtr, A_Strat_NatEn) != StratNat_Index) &&  /* PMSTA-11960 - LJE - 110625 - Index strat can be computed on anther grid */
                CMP_DYNFLD(domainPtr, stratPtr, A_Domain_GridId, A_Strat_GridObjId, IdType) != 0)
            {
                /* Check validity of the benchmark link -> instrument on rank 2 and 3 is not allowed */
                if (GET_INT(benchObjLnkStp, A_ObjectLnk_Rank) > 1) /* PMSTA50244 - MKK - 230123 */
                {
                    SET_ID(domainPtr, A_Domain_GridId, savedGridId);
                    return RET_GEN_INFO_NOACTION;
                }

                SET_ENUM(currPSPObjLnkStp, A_ObjectLnk_Nature, ObjectLnkNat_PSPSP);
                SET_NULL_ID(domainPtr, A_Domain_GridId);
                currComputeIdx = STD_PERF_IDX;
            }
        }
    }

    if (pspNbr == 0 && stratWithGrid == TRUE)    /* WEALTH-3200 - KOR - 20240405 - No PSP should be created for the strategy without grid */
    {
        if (DBA_CreateValidPSP(hierHead, domainPtr, computeTab, NULL, mainObjObjLnkStp, currPSPObjLnkStp, domPPDaStp, &pspNbr, &pspTab) != RET_SUCCEED ||
            pspNbr == 0)
        {
            mp.ownerPtr(pspTab);
            SET_ID(domainPtr, A_Domain_GridId, savedGridId);
            return RET_GEN_INFO_NOACTION;
        }
        mp.ownerPtr(pspTab);
    }

    while (endFlg == FALSE && pspNbr>0)
    {
        if (DBA_SearchBestPSPOnDate(hierHead,
            domainPtr,
            &computeTab[currComputeIdx],
            NULL,
            pspTab,
            pspNbr,
            GET_DATETIME(currPSPObjLnkStp, A_ObjectLnk_BeginDate),
            GET_DATETIME(currPSPObjLnkStp, A_ObjectLnk_EndDate),
            mainObjObjLnkStp,
            currPSPObjLnkStp,
            forceDateFlg,
            defPPDaStp,
            domPPDaStp,
            &bestPspStp) == RET_SUCCEED &&
            bestPspStp != NULL)
        {
            /* PMSTA-11283 - LJE - 110125 */
            if (IS_NULLFLD(currPSPObjLnkStp, A_ObjectLnk_EndDate) == TRUE)
            {
                if (CMP_DYNFLD(domainPtr, bestPspStp,
                    *(computeTab[currComputeIdx].domTillDIdxPtr), *(computeTab[currComputeIdx].tillDIdxPtr), DatetimeType) < 0)
                {
                    COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_EndDate,
                                domainPtr, A_Domain, *(computeTab[currComputeIdx].domTillDIdxPtr));
                }
                else
                {
                    COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_EndDate,
                                bestPspStp, A_PerfStorageParam, *(computeTab[currComputeIdx].tillDIdxPtr));
                }
            }

            if (CMP_DYNFLD(currPSPObjLnkStp, domainPtr,
                A_ObjectLnk_EndDate, A_Domain_InterpFromDate, DatetimeType) >= 0)
            {
                if (GET_ENUM(bestPspStp, A_PerfStorageParam_FrequencyEn) > GET_ENUM(domainPtr, A_Domain_Freq2UnitEn))
                {
                    SET_ENUM(domainPtr, A_Domain_Freq2UnitEn, GET_ENUM(bestPspStp, A_PerfStorageParam_FrequencyEn));
                }
            }
            else if (GET_ENUM(bestPspStp, A_PerfStorageParam_FrequencyEn) > FIN_GetDomainFreqEnForPAA(domainPtr, PerfAttrib))
            {
                SET_ENUM(domainPtr, A_Domain_Freq1UnitEn, GET_ENUM(bestPspStp, A_PerfStorageParam_FrequencyEn));
            }

            if ((ret = DBA_InsertValidPSP(hierHead,
                domainPtr,
                currPSPObjLnkStp,
                bestPspStp,
                dbiConnHelper,
                &computeTab[currComputeIdx],
                &lastPspObjLnkStp)) != RET_SUCCEED)
            {
                SET_ID(domainPtr, A_Domain_GridId, savedGridId);
                return (ret);
            }

            /* PMSTA-11206 - LJE - 110120 */
            if (gridObjLnkStp == NULL ||
                CMP_DYNFLD(bestPspStp, gridObjLnkStp, A_PerfStorageParam_GridId, A_ObjectLnk_ToObjectId, IdType) != 0)
            {
                DBA_InsertCopyGridObjLnk(hierHead,
                                         domainPtr,
                                         computeTab,
                                         currPSPObjLnkStp,
                                         gridObjLnkStp,
                                         bestPspStp);
            }

            if (currComputeIdx != STD_PERF_IDX) /* PMSTA-11206 - LJE - 110120 */
            {
                SET_ENUM(currPSPObjLnkStp, A_ObjectLnk_Nature, computeTab[STD_PERF_IDX].objLnkNat);
                if ((ret = DBA_InsertValidPSP(hierHead,
                    domainPtr,
                    currPSPObjLnkStp,
                    bestPspStp,
                    dbiConnHelper,
                    &computeTab[STD_PERF_IDX],
                    &lastStdPerfPspObjLnkStp)) != RET_SUCCEED)
                {
                    return (ret);
                }
                SET_ENUM(currPSPObjLnkStp, A_ObjectLnk_Nature, computeTab[currComputeIdx].objLnkNat);
            }

            COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_EndDate,
                        bestPspStp, A_PerfStorageParam, *(computeTab[PERF_ATTRIB_IDX].fromDIdxPtr));
        }

        if (bestPspStp == NULL ||
            IS_NULLFLD(bestPspStp, *(computeTab[PERF_ATTRIB_IDX].fromDIdxPtr)) == TRUE ||
            CMP_DYNFLD(currPSPObjLnkStp, bestPspStp,
            A_ObjectLnk_BeginDate, *(computeTab[PERF_ATTRIB_IDX].fromDIdxPtr), DatetimeType) >= 0)
        {
            endFlg = TRUE;
        }

        forceDateFlg = TRUE;
    }

    SET_ID(domainPtr, A_Domain_GridId, savedGridId);
    return (ret);
}

/************************************************************************
**  Function             : DBA_LoadBenchPSPForPerfAttrib()
**
**  Description          : Search and put in #dom_psp all benchmarks
**                         needed.
**                         Only one bench per main object, and onl standard perf.
**
**  Arguments            :
**
**  Return               : RET_SUCCEED or error code
**
**  Creation             : PMSTA09979 - LJE - 100722
**
*************************************************************************/
STATIC RET_CODE DBA_LoadBenchPSPForPerfAttrib(DBA_HIER_HEAD_STP    hierHead,
                                              DBA_DYNFLD_STP       domainPtr,
                                              DbiConnectionHelper& dbiConnHelper,
                                              COMPUTE_PAA_STP      computeTab,
                                              DBA_DYNFLD_STP       mainObjObjLnkStp,
                                              DBA_DYNFLD_STP       defPPDaStp,
                                              DBA_DYNFLD_STP       domPPDaStp)
{
    RET_CODE       ret = RET_SUCCEED;
    DBA_DYNFLD_STP *benchObjLnkTab, *gridObjLnkTab;
    int            benchObjLnkNbr, gridObjLnkNbr;
    MemoryPool     mp;

    ret = DBA_HierEltRecExtract(hierHead,
        A_ObjectLnk,
        FALSE,
        DBA_FilterAllBenchObjLnkForCurrent,
        mainObjObjLnkStp,
        DBA_CmpObjectLnkPAA,
        FALSE,
        FALSE,
        &benchObjLnkNbr,
        &benchObjLnkTab);
    
    mp.ownerPtr(benchObjLnkTab);

    if(ret != RET_SUCCEED ||
        benchObjLnkNbr == 0)
    {
        return (ret);
    }

    ret = DBA_HierEltRecExtract(hierHead,
        A_ObjectLnk,
        FALSE,
        DBA_FilterObjectLnkGridPAA,
        mainObjObjLnkStp,
        DBA_CmpObjectLnkPAA,
        FALSE,
        FALSE,
        &gridObjLnkNbr,
        &gridObjLnkTab);

    mp.ownerPtr(gridObjLnkTab);
        
    if(ret != RET_SUCCEED ||
        gridObjLnkNbr == 0)
    {
        return (ret);
    }

    DBA_DYNFLD_STP currPSPObjLnkStp = mp.allocDynst(FILEINFO, A_ObjectLnk);

    for (int j = 0; j < gridObjLnkNbr; j++)
    {
        COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_BeginDate,
                    gridObjLnkTab[j], A_ObjectLnk, A_ObjectLnk_BeginDate);
        COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_EndDate,
                    gridObjLnkTab[j], A_ObjectLnk, A_ObjectLnk_EndDate);

        for (int i = 0; i<benchObjLnkNbr; i++)
        {
            /* Check if the benchmark link is valid for the current main object */
            if (benchObjLnkTab[i] == NULL ||
                CMP_DYNFLD(benchObjLnkTab[i], currPSPObjLnkStp,
                A_ObjectLnk_BeginDate, A_ObjectLnk_EndDate, DatetimeType) > 0 ||
                CMP_DYNFLD(benchObjLnkTab[i], currPSPObjLnkStp,
                A_ObjectLnk_EndDate, A_ObjectLnk_BeginDate, DatetimeType) < 0)
            {
                continue;
            }

            COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_FromEntDictId,
                        benchObjLnkTab[i], A_ObjectLnk, A_ObjectLnk_ToEntDictId);
            COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_FromObjectId,
                        benchObjLnkTab[i], A_ObjectLnk, A_ObjectLnk_ToObjectId);

            SET_ENUM(currPSPObjLnkStp, A_ObjectLnk_Nature, ObjectLnkNat_PSPPA);

            COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_BeginDate,
                        benchObjLnkTab[i], A_ObjectLnk, A_ObjectLnk_BeginDate);
            COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_EndDate,
                        benchObjLnkTab[i], A_ObjectLnk, A_ObjectLnk_EndDate);

            SET_INT(currPSPObjLnkStp, A_ObjectLnk_Rank, 0); /* PMSTA50244 - MKK - 230123 */

            if (DBA_LoadPerfAttribPSP(hierHead,
                domainPtr,
                dbiConnHelper,
                computeTab,
                mainObjObjLnkStp,
                currPSPObjLnkStp,
                gridObjLnkTab[j],
                defPPDaStp,
                domPPDaStp,
                benchObjLnkTab[i]) == RET_GEN_INFO_NOACTION)
            {
                if (GET_INT(benchObjLnkTab[i], A_ObjectLnk_Rank) == 1) /* PMSTA50244 - MKK - 230123 */
                {
                    SET_NULL_ENUM(benchObjLnkTab[i], A_ObjectLnk_Nature);
                    SET_NULL_DICT(benchObjLnkTab[i], A_ObjectLnk_ToEntDictId);
                    SET_NULL_ID(benchObjLnkTab[i], A_ObjectLnk_ToObjectId);
                }
                else
                {
                    DBA_DelHierEltRec(hierHead, A_ObjectLnk, benchObjLnkTab[i]);
                }
                benchObjLnkTab[i] = NULL;
            }
        }
    }

    return (ret);
}

/************************************************************************
**
**  Function    :   DBA_FilterAllBenchObjLnkForCurrent()
**
**  Description :
**
**  Arguments   :   dynSt    element pointer
**                  dynStTp  element description enum
**
**  Return      : TRUE or FALSE
**
**  Creation Date : PMSTA09843 - LJE - 100525
**
*************************************************************************/
STATIC int DBA_FilterAllBenchObjLnkForCurrent(DBA_DYNFLD_STP dynSt, DBA_DYNST_ENUM dynStTp, DBA_DYNFLD_STP testSt)
{
    if (GET_ENUM(testSt, A_ObjectLnk_Nature) != ObjectLnkNat_PSPPA &&
        GET_INT(dynSt, A_ObjectLnk_Rank) != 1) /* PMSTA50244 - MKK - 230123 */
        return FALSE;

    if (IS_NULLFLD(dynSt, A_ObjectLnk_Nature) == FALSE                                                 &&
        GET_ENUM(dynSt, A_ObjectLnk_Nature) == (ENUM_T)ObjectLnkNat_Bench                             &&
        CMP_DYNFLD(dynSt, testSt, A_ObjectLnk_FromEntDictId, A_ObjectLnk_FromEntDictId, DictType) == 0 &&
        CMP_DYNFLD(dynSt, testSt, A_ObjectLnk_FromObjectId, A_ObjectLnk_FromObjectId, IdType) == 0 &&
        CMP_DYNFLD(dynSt, testSt, A_ObjectLnk_BeginDate, A_ObjectLnk_EndDate, DatetimeType) < 0 &&
        CMP_DYNFLD(dynSt, testSt, A_ObjectLnk_EndDate, A_ObjectLnk_BeginDate, DatetimeType) > 0 &&
        IS_NULLFLD(dynSt, A_ObjectLnk_ToEntDictId) == FALSE                                        &&
        IS_NULLFLD(dynSt, A_ObjectLnk_ToObjectId) == FALSE)
        return(TRUE);

    return(FALSE);
}

/************************************************************************
**  Function             : DBA_LoadBenchPSPForRetAnalysis()
**
**  Description          : Search and put in #dom_psp all benchmarks
**                         needed.
**                         Only one bench per main object, and onl standard perf.
**
**  Arguments            :
**
**  Return               : RET_SUCCEED or error code
**
**  Creation             : PMSTA09843 - LJE - 100520
**
*************************************************************************/
STATIC RET_CODE DBA_LoadBenchPSPForRetAnalysis(DBA_HIER_HEAD_STP    hierHead,
                                               DBA_DYNFLD_STP       domainPtr,
                                               DbiConnectionHelper& dbiConnHelper,
                                               COMPUTE_PAA_STP      computeTab,
                                               DBA_DYNFLD_STP       mainObjObjLnkStp,
                                               DBA_DYNFLD_STP       defPPDaStp,
                                               DBA_DYNFLD_STP       domPPDaStp)
{
    RET_CODE       ret = RET_SUCCEED;
    DBA_DYNFLD_STP currPSPObjLnkStp, pspStp;
    DBA_DYNFLD_STP *benchObjLnkTab, *gridObjLnkTab;
    int            benchObjLnkNbr, gridObjLnkNbr, i, j;

    if ((ret = DBA_HierEltRecExtract(hierHead,
        A_ObjectLnk,
        FALSE,
        DBA_FilterAllBenchObjLnkForCurrent,
        mainObjObjLnkStp,
        DBA_CmpObjectLnkPAA,
        FALSE,
        FALSE,
        &benchObjLnkNbr,
        &benchObjLnkTab)) != RET_SUCCEED ||
        benchObjLnkNbr == 0)
    {
        return (ret);
    }

    if ((ret = DBA_HierEltRecExtract(hierHead,
        A_ObjectLnk,
        FALSE,
        DBA_FilterObjectLnkGridPAA,
        mainObjObjLnkStp,
        DBA_CmpObjectLnkPAA,
        FALSE,
        FALSE,
        &gridObjLnkNbr,
        &gridObjLnkTab)) != RET_SUCCEED ||
        gridObjLnkNbr == 0)
    {
        return (ret);
    }

    if ((currPSPObjLnkStp = ALLOC_DYNST(A_ObjectLnk)) == NULL)
    {
        FREE(gridObjLnkTab);
        FREE(benchObjLnkTab);
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
        return(RET_MEM_ERR_ALLOC);
    }

    if ((pspStp = ALLOC_DYNST(A_PerfStorageParam)) == NULL)
    {
        FREE_DYNST(currPSPObjLnkStp, A_ObjectLnk);
        FREE(gridObjLnkTab);
        FREE(benchObjLnkTab);
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
        return(RET_MEM_ERR_ALLOC);
    }


    for (j = 0; j < gridObjLnkNbr; j++)
    {
        COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_BeginDate,
                    gridObjLnkTab[j], A_ObjectLnk, A_ObjectLnk_BeginDate);
        COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_EndDate,
                    gridObjLnkTab[j], A_ObjectLnk, A_ObjectLnk_EndDate);

        COPY_DYNFLD(pspStp, A_PerfStorageParam, A_PerfStorageParam_GridId,
                    gridObjLnkTab[j], A_ObjectLnk, A_ObjectLnk_ToObjectId);


        for (i = 0; i<benchObjLnkNbr; i++)
        {
            /* Check if the benchmark link is valid for the current main object */
            if (CMP_DYNFLD(benchObjLnkTab[i], currPSPObjLnkStp,
                A_ObjectLnk_BeginDate, A_ObjectLnk_EndDate, DatetimeType) > 0 ||
                CMP_DYNFLD(benchObjLnkTab[i], currPSPObjLnkStp,
                A_ObjectLnk_EndDate, A_ObjectLnk_BeginDate, DatetimeType) < 0)
            {
                continue;
            }

            COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_FromEntDictId,
                        benchObjLnkTab[i], A_ObjectLnk, A_ObjectLnk_ToEntDictId);
            COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_FromObjectId,
                        benchObjLnkTab[i], A_ObjectLnk, A_ObjectLnk_ToObjectId);

            SET_ENUM(currPSPObjLnkStp, A_ObjectLnk_Nature, ObjectLnkNat_PSPSP);

            COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_BeginDate,
                        benchObjLnkTab[i], A_ObjectLnk, A_ObjectLnk_BeginDate);
            COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_EndDate,
                        benchObjLnkTab[i], A_ObjectLnk, A_ObjectLnk_EndDate);

            SET_INT(currPSPObjLnkStp, A_ObjectLnk_Rank, 0); /* PMSTA50244 - MKK - 230123 */

            DBA_LoadStandardPerfPSP(hierHead,
                                    domainPtr,
                                    dbiConnHelper,
                                    computeTab,
                                    mainObjObjLnkStp,
                                    currPSPObjLnkStp,
                                    NULL, /* PMSTA-10640 - LJE - 101020 */
                                    defPPDaStp,
                                    domPPDaStp,
                                    FALSE,
                                    TRUE);
        }
    }

    FREE_DYNST(currPSPObjLnkStp, A_ObjectLnk);
    FREE_DYNST(pspStp, A_PerfStorageParam);
    FREE(gridObjLnkTab);
    FREE(benchObjLnkTab);

    return (ret);
}

/************************************************************************
**  Function             : DBA_CreateValidPSP()
**
**  Description          : The function create the best PSP that the process
**                         can dream
**
**  Arguments            :
**
**  Return               : RET_SUCCEED or error code
**
**  Creation             : PMSTA09979 - LJE - 100720
**
*************************************************************************/
STATIC RET_CODE DBA_CreateValidPSP(DBA_HIER_HEAD_STP    hierHead,
                                   DBA_DYNFLD_STP       domainPtr,
                                   COMPUTE_PAA_STP      computeTab,
                                   DBA_MAIN_OBJ_STP     mainObjInfoStp,
                                   DBA_DYNFLD_STP       mainObjObjLnkStp,
                                   DBA_DYNFLD_STP       currPSPObjLnkStp,
                                   DBA_DYNFLD_STP       domPPDaStp,
                                   int                 *pspNbrPtr,
                                   DBA_DYNFLD_STP     **pspTabPtr)
{
    RET_CODE                    ret = RET_SUCCEED;
    DBA_DYNFLD_STP              bestPspStp, bestHierPspStp = NULL;
    int                         pspNbr = 1;

    if ((bestPspStp = ALLOC_DYNST(A_PerfStorageParam)) == NULL)
    {
        return RET_MEM_ERR_ALLOC;
    }

    COPY_DYNFLD(bestPspStp, A_PerfStorageParam, A_PerfStorageParam_EntityDictId,
                currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_FromEntDictId);
    COPY_DYNFLD(bestPspStp, A_PerfStorageParam, A_PerfStorageParam_ObjId,
                currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_FromObjectId);

    switch (GET_ENUM(currPSPObjLnkStp, A_ObjectLnk_Nature))
    {
        case ObjectLnkNat_PSPExtRA:
            SET_FLAG(bestPspStp, A_PerfStorageParam_StandardPerfDataFlg, TRUE);
            SET_FLAG(bestPspStp, A_PerfStorageParam_RetAnalysisFlg, TRUE);
            SET_FLAG(bestPspStp, A_PerfStorageParam_PerfAttribFlg, FALSE);
			SET_FLAG(bestPspStp, A_PerfStorageParam_PerfCalcResultFlg, TRUE);
            break;

        case ObjectLnkNat_PSPPA:
            SET_FLAG(bestPspStp, A_PerfStorageParam_StandardPerfDataFlg, TRUE);
            SET_FLAG(bestPspStp, A_PerfStorageParam_RetAnalysisFlg, FALSE);
            SET_FLAG(bestPspStp, A_PerfStorageParam_PerfAttribFlg, TRUE);
			SET_FLAG(bestPspStp, A_PerfStorageParam_PerfCalcResultFlg, TRUE);
            break;

        case ObjectLnkNat_PSPSP:
            SET_FLAG(bestPspStp, A_PerfStorageParam_StandardPerfDataFlg, TRUE);
            SET_FLAG(bestPspStp, A_PerfStorageParam_RetAnalysisFlg, FALSE);
            SET_FLAG(bestPspStp, A_PerfStorageParam_PerfAttribFlg, FALSE);
			SET_FLAG(bestPspStp, A_PerfStorageParam_PerfCalcResultFlg, TRUE);
            break;
    }

    switch (GET_ENUM(mainObjObjLnkStp, A_ObjectLnk_Nature))
    {
        case ObjectLnkNat_PSPExtRA:
            SET_ENUM(bestPspStp, A_PerfStorageParam_FrequencyEn, FIN_GetDomainFreqEnForPAA(domainPtr, ExtRetAnalysis));
            break;

        case ObjectLnkNat_PSPPA:
            SET_ENUM(bestPspStp, A_PerfStorageParam_FrequencyEn, FIN_GetDomainFreqEnForPAA(domainPtr, PerfAttrib));
            break;

        case ObjectLnkNat_PSPSP:
            SET_ENUM(bestPspStp, A_PerfStorageParam_FrequencyEn, FIN_GetDomainFreqEnForPAA(domainPtr, StandardPerf));
            break;
    }

    COPY_DYNFLD(bestPspStp, A_PerfStorageParam, A_PerfStorageParam_GridId,
                domainPtr, A_Domain, A_Domain_GridId);
    COPY_DYNFLD(bestPspStp, A_PerfStorageParam, A_PerfStorageParam_CurrId,
                domainPtr, A_Domain, A_Domain_CurrId);

    /* PMSTA-54529 - DDV - 231009 */
    COPY_DYNFLD(bestPspStp, A_PerfStorageParam, A_PerfStorageParam_PerfCalcDefProfileId,
                domainPtr, A_Domain, A_Domain_PerfCalcDefProfId);

    if (GET_DICT(currPSPObjLnkStp, A_ObjectLnk_FromEntDictId) == computeTab->ptfEntDictId  ||/* PMSTA- - LJE - 170410 */
        (static_cast<PTFCONSRULE_ENUM>GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) == PtfConsRule_MergedTWR_Detail &&
         (GET_DICT(currPSPObjLnkStp, A_ObjectLnk_FromEntDictId) == ListCst) ||
         (GET_DICT(currPSPObjLnkStp, A_ObjectLnk_FromEntDictId) == ThirdCst) ||
          GET_ID(currPSPObjLnkStp, A_ObjectLnk_FromObjectId) < 0)) /* WEALTH-5178-MergedTWRDetail -Lalby -06032024 */
    {
    if (domPPDaStp == NULL)
    {
        COPY_DYNFLD(bestPspStp, A_PerfStorageParam, A_PerfStorageParam_PositionDataId,
                    domainPtr, A_Domain, A_Domain_PSPPositionDataId);
    }
    else
    {
        COPY_DYNFLD(bestPspStp, A_PerfStorageParam, A_PerfStorageParam_PositionDataId,
                    domPPDaStp, A_PSPPositionData, A_PSPPositionData_Id);
    }
    }

    if (GET_DICT(currPSPObjLnkStp, A_ObjectLnk_FromEntDictId) == computeTab->ptfEntDictId &&
        computeTab->returnInParPtfRuleEn == ReturnInParentPtfRule_Parent &&
        GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None &&
        (PTFCONSRULE_ENUM)GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) != PtfConsRule_DetailedChildren &&
        ((static_cast<LOADHIERPTF_ENUM> GET_ENUM(domainPtr, A_Domain_LoadHierFlg) != LoadHierPtf_IntermediateHierarchy) ?
            true : FIN_IsPtfConsRuleValidForIntermediateHierarchy(domainPtr)) &&
        mainObjInfoStp != NULL &&
        mainObjInfoStp->passNbr >= PASS_PARENT_HIER_PSP)
    {
        SET_ENUM(bestPspStp, A_PerfStorageParam_PerfAttribReturnEn, PerfAttribRtnEn_Hierarchy);
    }
    else if ((GET_DICT(currPSPObjLnkStp, A_ObjectLnk_FromEntDictId) == ListCst ||
              GET_DICT(currPSPObjLnkStp, A_ObjectLnk_FromEntDictId) == ThirdCst ||
              GET_ID(currPSPObjLnkStp, A_ObjectLnk_FromObjectId) < 0) &&
              (PTFCONSRULE_ENUM)GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) == PtfConsRule_MergedTWR_Detail &&
              mainObjInfoStp != NULL) /*WEALTH- 5069 - Lalby - 26022024 - head list PSP must be hierarchical */
    {
        SET_ENUM(bestPspStp, A_PerfStorageParam_PerfAttribReturnEn, PerfAttribRtnEn_Hierarchy);
    }
    else
    {
        SET_ENUM(bestPspStp, A_PerfStorageParam_PerfAttribReturnEn, PerfAttribRtnEn_Standard);
    }

    if (GET_ENUM(currPSPObjLnkStp, A_ObjectLnk_Nature) != ObjectLnkNat_PSPSP &&
        GET_ENUM(domainPtr, A_Domain_RetDetLevelEn) == PtfRetDetLvl_Instrument)
    {
        SET_FLAG(bestPspStp, A_PerfStorageParam_InstrLevelFlg, TRUE);
    }
    else
    {
        SET_FLAG(bestPspStp, A_PerfStorageParam_InstrLevelFlg, FALSE);
    }

    SET_ENUM(bestPspStp, A_PerfStorageParam_CheckedDataEn, 1);

    DBA_AddHierRecord(hierHead,
                      bestPspStp,
                      A_PerfStorageParam,
                      TRUE,
                      HierAddRec_NoLnk);

    if (computeTab->returnInParPtfRuleEn == ReturnInParentPtfRule_ParentUsingHierPSP &&
        GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None &&
        (PTFCONSRULE_ENUM)GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) != PtfConsRule_DetailedChildren &&
        ((static_cast<LOADHIERPTF_ENUM> GET_ENUM(domainPtr, A_Domain_LoadHierFlg) != LoadHierPtf_IntermediateHierarchy) ?
            true : FIN_IsPtfConsRuleValidForIntermediateHierarchy(domainPtr) == false) &&
        GET_DICT(currPSPObjLnkStp, A_ObjectLnk_FromEntDictId) == computeTab->ptfEntDictId &&
        mainObjInfoStp != NULL &&
        mainObjInfoStp->passNbr >= PASS_PARENT_HIER_PSP)
    {
        if ((bestHierPspStp = ALLOC_DYNST(A_PerfStorageParam)) == NULL)
        {
            return RET_MEM_ERR_ALLOC;
        }

        COPY_DYNST(bestHierPspStp, bestPspStp, A_PerfStorageParam);

        SET_NULL_ID(bestHierPspStp, A_PerfStorageParam_Id);
        SET_ENUM(bestPspStp, A_PerfStorageParam_PerfAttribReturnEn, PerfAttribRtnEn_Hierarchy);

        pspNbr++;

        DBA_AddHierRecord(hierHead,
                          bestHierPspStp,
                          A_PerfStorageParam,
                          TRUE,
                          HierAddRec_NoLnk);

    }


    if ((*pspTabPtr = (DBA_DYNFLD_STP*)CALLOC(pspNbr, sizeof(DBA_DYNFLD_STP))) != NULL)
    {
        *pspNbrPtr = pspNbr;
        (*pspTabPtr)[0] = bestPspStp;

        if (bestHierPspStp != NULL)
        {
            (*pspTabPtr)[1] = bestHierPspStp;
        }
    }
    else
    {
        *pspNbrPtr = 0;
    }

    return ret;
}

/************************************************************************
**  Function             : DBA_SetBestGridInDomain()
**
**  Description          : Search and set in the domain
**                         the best grid according the follwing rules :
**                          1) Grid of the first stragegy link
**                          2) The grid set on the domain
**                          3) Use the "UsePSP" rules
**
**  Arguments            :
**
**  Return               : RET_SUCCEED or error code
**
**  Creation             : PMSTA09843 - LJE - 100520
**
*************************************************************************/
STATIC RET_CODE DBA_SetBestGridInDomain(DBA_HIER_HEAD_STP    hierHead,
                                        DBA_DYNFLD_STP       domainPtr,
                                        COMPUTE_PAA_STP      computeTab,
                                        DBA_DYNFLD_STP       mainObjStp,
                                        DBA_DYNFLD_STP       hierPtfStp,
                                        DBA_DYNFLD_STP      *pspTab,
                                        int                  pspNbr,
                                        OBJECT_ENUM          outObjEn, /* PMSTA-16306 - LJE - 130506 */
                                        DBA_DYNFLD_STP       mainObjObjLnkStp,
                                        DBA_DYNFLD_STP       lastMainObjLnkStp)  /* PMSTA-55400 - DDV - 250220 */
{
    RET_CODE       ret = RET_SUCCEED;
    DBA_DYNFLD_STP *benchObjLnkTab;
    int            benchObjLnkNbr, i;
    DBA_DYNFLD_STP stratPtr = NULL;
    FLAG_T         gridSettedFlg = FALSE;

    if (GET_ENUM(domainPtr, A_Domain_RetDetLevelEn) == PtfRetDetLvl_Global ||
        (GET_ENUM(domainPtr, A_Domain_RetDetLevelEn) == PtfRetDetLvl_Instrument &&
        GET_FLAG(domainPtr, A_Domain_SubGridFlg) == FALSE))
    {
        SET_NULL_ID(domainPtr, A_Domain_GridId);
        return ret;
    }

    if (GET_DICT(mainObjObjLnkStp, A_ObjectLnk_FromEntDictId) == computeTab->stratEntDictId)
    {
        if (mainObjStp != NULL &&
            IS_NULLFLD(mainObjStp, A_Strat_GridObjId) == FALSE)
        {
            gridSettedFlg = TRUE;
            SET_ID(domainPtr, A_Domain_GridId, GET_ID(mainObjStp, A_Strat_GridObjId));
        }

        return (ret);
    }
    else if (hierPtfStp != NULL && IS_NULLFLD(hierPtfStp, A_Ptf_HierPortId) == FALSE &&
             static_cast<LOADHIERPTF_ENUM> GET_ENUM(domainPtr, A_Domain_LoadHierFlg) != LoadHierPtf_IntermediateHierarchy) /* WEALTH-19051 - Lalby - 13032025 -Use from Benchmark */
    {
        int             gridObjLnkNbr;
        DBA_DYNFLD_STP *gridObjLnkTab;

        COPY_DYNFLD(mainObjObjLnkStp, A_ObjectLnk, A_ObjectLnk_FromObjectId,
                    hierPtfStp, A_Ptf, A_Ptf_HierPortId);

        if ((ret = DBA_HierEltRecExtract(hierHead,
            A_ObjectLnk,
            FALSE,
            DBA_FilterObjectLnkGridPAA,
            mainObjObjLnkStp,
            DBA_CmpObjectLnkPAA,
            FALSE,
            FALSE,
            &gridObjLnkNbr,
            &gridObjLnkTab)) != RET_SUCCEED ||
            gridObjLnkNbr == 0)
        {
            COPY_DYNFLD(mainObjObjLnkStp, A_ObjectLnk, A_ObjectLnk_FromObjectId,
                        mainObjStp, A_Ptf, A_Ptf_Id);
            return (ret);
        }

        for (i = 0; i < gridObjLnkNbr; i++)
        {
            if (CMP_DYNFLD(mainObjObjLnkStp, gridObjLnkTab[i],
                A_ObjectLnk_BeginDate, A_ObjectLnk_BeginDate, DatetimeType) >= 0 &&
                CMP_DYNFLD(mainObjObjLnkStp, gridObjLnkTab[i],
                A_ObjectLnk_BeginDate, A_ObjectLnk_EndDate, DatetimeType) < 0)
            {
                gridSettedFlg = TRUE;
                SET_ID(domainPtr, A_Domain_GridId, GET_ID(gridObjLnkTab[i], A_ObjectLnk_ToObjectId));
                break;
            }
        }

        COPY_DYNFLD(mainObjObjLnkStp, A_ObjectLnk, A_ObjectLnk_FromObjectId,
                    mainObjStp, A_Ptf, A_Ptf_Id);
        FREE(gridObjLnkTab);
    }

    if (GET_DICT(mainObjObjLnkStp, A_ObjectLnk_ToEntDictId) == computeTab->instrEntDictId)
    {
        return (ret);
    }

    if (gridSettedFlg == FALSE &&
        (IS_NULLFLD(domainPtr, A_Domain_GridId) == TRUE || 
         GET_ENUM(domainPtr, A_Domain_ReturnAnalysisEn) != PAARetAnalysis_RA)) /* PMSTA-21198 - LJE - 150909 */
    {
        if ((ret = DBA_HierEltRecExtract(hierHead,
            A_ObjectLnk,
            FALSE,
            DBA_FilterAllBenchObjLnkForCurrent,
            mainObjObjLnkStp,
            DBA_CmpObjectLnkPAA,
            FALSE,
            FALSE,
            &benchObjLnkNbr,
            &benchObjLnkTab)) != RET_SUCCEED)
        {
            return (ret);
        }

        for (i = 0; i < benchObjLnkNbr; i++)
        {
            if (CMP_DYNFLD(mainObjObjLnkStp, benchObjLnkTab[i],
                A_ObjectLnk_BeginDate, A_ObjectLnk_BeginDate, DatetimeType) >= 0 &&
                CMP_DYNFLD(mainObjObjLnkStp, benchObjLnkTab[i],
                A_ObjectLnk_BeginDate, A_ObjectLnk_EndDate, DatetimeType) < 0)
            {
                if (GET_DICT(benchObjLnkTab[i], A_ObjectLnk_ToEntDictId) == computeTab->stratEntDictId)
                {
                    if ((stratPtr = DBA_SearchHierRecById(hierHead,
                        A_Strat,
                        A_Strat_Id,
                        GET_ID(benchObjLnkTab[i], A_ObjectLnk_ToObjectId))) != NULL &&
                        IS_NULLFLD(stratPtr, A_Strat_GridObjId) == FALSE)
                    {
                        gridSettedFlg = TRUE;
                        SET_ID(domainPtr, A_Domain_GridId, GET_ID(stratPtr, A_Strat_GridObjId));
                        break;
                    }
                }
            }
        }

        FREE(benchObjLnkTab);
    }

    if (gridSettedFlg == FALSE &&
        (GET_ENUM(domainPtr, A_Domain_RetDetLevelEn) == PtfRetDetLvl_Grid ||
        GET_FLAG(domainPtr, A_Domain_SubGridFlg) == TRUE) &&
        (GET_ENUM(domainPtr, A_Domain_RetDetLevelEn) == PtfRetDetLvl_UsePSP ||
        IS_NULLFLD(domainPtr, A_Domain_GridId) == TRUE)) /* PMSTA-11505 - LJE - 110823 - prefer to use domain grid */
    {
        int bestPspPos = -1;
        FIELD_IDX_T lastStoredDateFld, firstStoredDateFld, analyisFlgFld;

        if (GET_ENUM(domainPtr, A_Domain_ReturnAnalysisEn) == PAARetAnalysis_RA)
        {
            firstStoredDateFld = A_PerfStorageParam_RetFirstStoredDate;
            lastStoredDateFld = A_PerfStorageParam_RetLastStoredDate;
            analyisFlgFld = A_PerfStorageParam_RetAnalysisFlg;
        }
        else
        {
            firstStoredDateFld = A_PerfStorageParam_PerfFirstStoredDate;
            lastStoredDateFld = A_PerfStorageParam_PerfLastStoredDate;
            analyisFlgFld = A_PerfStorageParam_PerfAttribFlg;
        }

        for (i = 0; i < pspNbr; i++)
        {
            if (pspTab[i] == NULL)
                continue;

            /* PMSTA-55400 - DDV - 250220 - Accpept PSP without grid for object link with nature none */
            if (IS_NULLFLD(pspTab[i], A_PerfStorageParam_GridId) == true)
            {
                if (GET_ENUM(lastMainObjLnkStp, A_ObjectLnk_Nature) == ObjectLnkNat_None &&
                    bestPspPos == -1)
                {
                    bestPspPos = i;
                }
            }
            else
            {
                /* PMSTA-55400 - DDV - 250220 - Use PSP with grid only if it is physical PSP or object link nature is not none */
                if (IS_NULLFLD(pspTab[i], A_PerfStorageParam_GridId) == false && 
                    (GET_ID(pspTab[i], A_PerfStorageParam_Id) > 0 ||
                     GET_ENUM(lastMainObjLnkStp, A_ObjectLnk_Nature) != ObjectLnkNat_None))
                {
                    if (bestPspPos == -1)
                    {
                        bestPspPos = i;
                    }
                    /* Check frequency */
                    else if (GET_ENUM(pspTab[bestPspPos], A_PerfStorageParam_FrequencyEn) !=
                             FIN_GetDomainFreqEnForPAA(domainPtr, outObjEn) &&
                             GET_ENUM(pspTab[i], A_PerfStorageParam_FrequencyEn) ==
                             FIN_GetDomainFreqEnForPAA(domainPtr, outObjEn))
                    {
                        bestPspPos = i;
                    }
                    else if (GET_ENUM(pspTab[bestPspPos], A_PerfStorageParam_FrequencyEn) ==
                             FIN_GetDomainFreqEnForPAA(domainPtr, outObjEn) &&
                             GET_ENUM(pspTab[i], A_PerfStorageParam_FrequencyEn) !=
                             FIN_GetDomainFreqEnForPAA(domainPtr, outObjEn))
                    {
                        continue;
                    }
                    /* Check if the current valid PSP is really valid! */
                    else if (CMP_DYNFLD(pspTab[bestPspPos], mainObjObjLnkStp,
                        firstStoredDateFld, A_ObjectLnk_EndDate, DatetimeType) >= 0)
                    {
                        bestPspPos = i;
                    }
                    else if (CMP_DYNFLD(pspTab[i], pspTab[bestPspPos],
                        lastStoredDateFld, lastStoredDateFld, DatetimeType) > 0 ||
                        (GET_FLAG(pspTab[i], analyisFlgFld) == TRUE &&
                        GET_FLAG(pspTab[bestPspPos], analyisFlgFld) == FALSE))
                    {
                        bestPspPos = i;
                    }
                }
            }
        }

        if (bestPspPos >= 0)
        {
            COPY_DYNFLD(domainPtr, A_Domain, A_Domain_GridId,
                        pspTab[bestPspPos], A_PerfStorageParam, A_PerfStorageParam_GridId);
            gridSettedFlg = TRUE;
        }

        /* PMSTA-16306 - LJE - 130506 - Search the grid into unflag PSP */
        if (gridSettedFlg == FALSE)
        {
            DBA_DYNFLD_STP     *ptfPspTab = NULL;
            int                 ptfPspNbr = 0;
            OBJECTLNK_NAT_ENUM  saveObjLnkNat = (OBJECTLNK_NAT_ENUM)GET_ENUM(mainObjObjLnkStp, A_ObjectLnk_Nature);
            SET_ENUM(mainObjObjLnkStp, A_ObjectLnk_Nature, ObjectLnkNat_PSPSP);

            /* Extract all current PSP */
            if ((ret = DBA_HierEltRecExtract(hierHead,
                A_PerfStorageParam,
                FALSE,
                DBA_FilterPSPforCurrent,
                mainObjObjLnkStp,
                FIN_CmpPspByEntIdObjIdDt,
                FALSE,
                FALSE,
                &ptfPspNbr,
                &ptfPspTab)) != RET_SUCCEED)
            {
                return(ret);
            }

            SET_ENUM(mainObjObjLnkStp, A_ObjectLnk_Nature, saveObjLnkNat);

            for (i = 0; i < ptfPspNbr; i++)
            {
                /* PMSTA-55400 - DDV - 250220 - Accept PSP without grid for object link with nature none */
                if (IS_NULLFLD(ptfPspTab[i], A_PerfStorageParam_GridId) == true)
                {
                    if (bestPspPos == -1 &&
                        GET_ENUM(lastMainObjLnkStp, A_ObjectLnk_Nature) == ObjectLnkNat_None)
                    {
                        bestPspPos = i;
                    }
                }
                else
                {
                    /* PMSTA-55400 - DDV - 250220 - Use PSP with grid only if it is physical PSP or object link nature is not none */
                    if (IS_NULLFLD(ptfPspTab[i], A_PerfStorageParam_GridId) == false &&
                        (GET_ID(ptfPspTab[i], A_PerfStorageParam_Id) > 0 ||
                            GET_ENUM(lastMainObjLnkStp, A_ObjectLnk_Nature) != ObjectLnkNat_None))
                    {
                        if (bestPspPos == -1)
                        {
                            bestPspPos = i;
                        }
                        /* Check frequency */
                        else if (GET_ENUM(ptfPspTab[bestPspPos], A_PerfStorageParam_FrequencyEn) !=
                                 FIN_GetDomainFreqEnForPAA(domainPtr, outObjEn) &&
                                 GET_ENUM(ptfPspTab[i], A_PerfStorageParam_FrequencyEn) ==
                                 FIN_GetDomainFreqEnForPAA(domainPtr, outObjEn))
                        {
                            bestPspPos = i;
                        }
                        else if (GET_ENUM(ptfPspTab[bestPspPos], A_PerfStorageParam_FrequencyEn) ==
                                 FIN_GetDomainFreqEnForPAA(domainPtr, outObjEn) &&
                                 GET_ENUM(ptfPspTab[i], A_PerfStorageParam_FrequencyEn) !=
                                 FIN_GetDomainFreqEnForPAA(domainPtr, outObjEn))
                        {
                            continue;
                        }
                        /* Check if the current valid PSP is really valid! */
                        else if (CMP_DYNFLD(ptfPspTab[bestPspPos], mainObjObjLnkStp,
                            A_PerfStorageParam_StdPerfFirstStoredDate, A_ObjectLnk_EndDate, DatetimeType) >= 0)
                        {
                            bestPspPos = i;
                        }
                        else if (CMP_DYNFLD(ptfPspTab[i], ptfPspTab[bestPspPos],
                            A_PerfStorageParam_StdPerfLastStoredDate,
                            A_PerfStorageParam_StdPerfLastStoredDate, DatetimeType) > 0 ||
                            (GET_FLAG(ptfPspTab[i], A_PerfStorageParam_StandardPerfDataFlg) == TRUE &&
                            GET_FLAG(ptfPspTab[bestPspPos], A_PerfStorageParam_StandardPerfDataFlg) == FALSE))
                        {
                            bestPspPos = i;
                        }
                    }
                }
            }

            if (bestPspPos >= 0)
            {
                COPY_DYNFLD(domainPtr, A_Domain, A_Domain_GridId,
                            ptfPspTab[bestPspPos], A_PerfStorageParam, A_PerfStorageParam_GridId);
                gridSettedFlg = TRUE;
            }

            FREE(ptfPspTab);
        }
    }

    return ret;
}

/************************************************************************
**  Function             : DBA_LoadDomPspForCurrPSPObjLnk()
**
**  Description          :
**
**  Arguments            :
**
**  Return               : RET_SUCCEED or error code
**
**  Creation             : PMSTA09979 - LJE - 100722
**
*************************************************************************/
STATIC RET_CODE DBA_LoadDomPspForCurrPSPObjLnk(DBA_HIER_HEAD_STP    hierHead,
                                               DBA_DYNFLD_STP       domainPtr,
                                               DbiConnectionHelper& dbiConnHelper,
                                               COMPUTE_PAA_STP      computeTab,
                                               int                  currComputeIdx,
                                               DBA_MAIN_OBJ_STP     mainObjInfoStp,
                                               DBA_DYNFLD_STP       currPSPObjLnkStp,
                                               DBA_DYNFLD_STP       firstMainObjLnkStp,
                                               DBA_DYNFLD_STP       lastMainObjLnkStp,
                                               DBA_DYNFLD_STP       defPPDaStp,
                                               DBA_DYNFLD_STP       domPPDaStp,
                                               DBA_DYNFLD_STP      *lastGridObjLnkStpPtr,
                                               DBA_DYNFLD_STP      *lastPspObjLnkStpPtr,
                                               DBA_DYNFLD_STP      *lastPspStdPerfObjLnkStpPtr,
                                               DBA_DYNFLD_STP      *lastPspPerfCalcResObjLnkStpPtr)
{
    RET_CODE        ret = RET_SUCCEED;
    DBA_DYNFLD_STP *pspTab = NULL;
    int             pspNbr = 0;
    FLAG_T          endFlg = FALSE, firstFlg = TRUE;
    DBA_DYNFLD_STP  bestPspStp = NULL;
    DBA_DYNFLD_STP  lastRABestPspStp = NULL; /* PMSTA-11283 - LJE - 110127 */
    ID_T            savedGridId = GET_ID(domainPtr, A_Domain_GridId); /* PMSTA-13140 - LJE - 120316 */
    FLAG_T          parentPtfFlg = FALSE, childPtfFlg = FALSE;

    COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_EndDate,
                firstMainObjLnkStp, A_ObjectLnk, A_ObjectLnk_EndDate);

    if (computeTab->returnInParPtfRuleEn == ReturnInParentPtfRule_ParentUsingHierPSP && mainObjInfoStp != NULL)
    {
        if (mainObjInfoStp->hierPtfStp != NULL &&
            IS_NULLFLD(mainObjInfoStp->hierPtfStp, A_Ptf_HierPortId) == FALSE)
        {
            if ((static_cast<LOADHIERPTF_ENUM> GET_ENUM(domainPtr, A_Domain_LoadHierFlg) != LoadHierPtf_IntermediateHierarchy) &&  /*PMSTA-48195 -Performance IPS Level -Lalby-310123 */
                mainObjInfoStp->passNbr > PASS_STORED_HIER_PSP &&
                DATETIME_CMP(mainObjInfoStp->parMainObjInfoStp->firstHierPSPDate, GET_DATETIME(lastMainObjLnkStp, A_ObjectLnk_BeginDate)) <= 0)
            {
                return (ret);
            }
            childPtfFlg = TRUE;
        }
        else
        {
            parentPtfFlg = TRUE;
        }
    }

    /* Extract all current PSP */
    if ((ret = DBA_HierEltRecExtract(hierHead,
        A_PerfStorageParam,
        FALSE,
        DBA_FilterPSPforCurrent,
        currPSPObjLnkStp,
        FIN_CmpPspByEntIdObjIdDt,  /* PMSTA-13946 - LJE - 120328 */
        FALSE,
        FALSE,
        &pspNbr,
        &pspTab)) != RET_SUCCEED)
    {
        return(ret);
    }

    while (endFlg == FALSE)
    {
        if (CMP_DYNFLD(lastMainObjLnkStp, domainPtr, A_ObjectLnk_BeginDate, A_Domain_InterpFromDate, DatetimeType) < 0)
        {
            COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_BeginDate,
                        domainPtr, A_Domain, A_Domain_InterpFromDate);
        }
        else
        {
            COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_BeginDate,
                        lastMainObjLnkStp, A_ObjectLnk, A_ObjectLnk_BeginDate);
        }

        if ((static_cast<LOADHIERPTF_ENUM> GET_ENUM(domainPtr, A_Domain_LoadHierFlg) != LoadHierPtf_IntermediateHierarchy)&&
            computeTab->returnInParPtfRuleEn == ReturnInParentPtfRule_ParentUsingHierPSP &&
            mainObjInfoStp != NULL)
        {
            if (mainObjInfoStp->passNbr == PASS_PARENT_STD_PSP &&
                DATETIME_CMP(mainObjInfoStp->firstHierPSPDate, GET_DATETIME(currPSPObjLnkStp, A_ObjectLnk_EndDate)) < 0 &&
                DATETIME_CMP(mainObjInfoStp->firstHierPSPDate, GET_DATETIME(currPSPObjLnkStp, A_ObjectLnk_BeginDate)) >= 0)
            {
                SET_DATETIME(currPSPObjLnkStp, A_ObjectLnk_EndDate, mainObjInfoStp->firstHierPSPDate);
            }
            else if (mainObjInfoStp->passNbr == PASS_CHILD_STD_PSP &&
                mainObjInfoStp->parMainObjInfoStp != NULL &&
                     DATETIME_CMP(mainObjInfoStp->parMainObjInfoStp->firstHierPSPDate, GET_DATETIME(currPSPObjLnkStp, A_ObjectLnk_EndDate)) < 0 &&
                     DATETIME_CMP(mainObjInfoStp->parMainObjInfoStp->firstHierPSPDate, GET_DATETIME(currPSPObjLnkStp, A_ObjectLnk_BeginDate)) >= 0)
            {
                SET_DATETIME(currPSPObjLnkStp, A_ObjectLnk_EndDate, mainObjInfoStp->parMainObjInfoStp->firstHierPSPDate);
            }
            else if (mainObjInfoStp->passNbr == PASS_PARENT_HIER_PSP &&
                     DATETIME_CMP(mainObjInfoStp->lastStoredPSPDate, GET_DATETIME(currPSPObjLnkStp, A_ObjectLnk_BeginDate)) > 0 &&
                     DATETIME_CMP(mainObjInfoStp->firstStoredPSPDate, GET_DATETIME(currPSPObjLnkStp, A_ObjectLnk_EndDate)) < 0)
            {
                SET_DATETIME(currPSPObjLnkStp, A_ObjectLnk_BeginDate, mainObjInfoStp->lastStoredPSPDate);
            }
            else if (mainObjInfoStp->passNbr == PASS_PARENT_HIER_PSP_BEGIN &&
                     DATETIME_CMP(mainObjInfoStp->firstHierPSPDate, GET_DATETIME(currPSPObjLnkStp, A_ObjectLnk_BeginDate)) > 0 &&
                     DATETIME_CMP(mainObjInfoStp->firstHierPSPDate, GET_DATETIME(currPSPObjLnkStp, A_ObjectLnk_EndDate)) < 0)
            {
                SET_DATETIME(currPSPObjLnkStp, A_ObjectLnk_EndDate, mainObjInfoStp->firstHierPSPDate);
            }
        }

        if (CMP_DYNFLD(currPSPObjLnkStp, currPSPObjLnkStp, A_ObjectLnk_EndDate, A_ObjectLnk_BeginDate, DatetimeType) > 0)
        {
            if ((mainObjInfoStp->hierPtfStp != NULL && GET_ENUM(domainPtr, A_Domain_RetDetLevelEn) == PtfRetDetLvl_UsePSP) ||
                GET_ENUM(domainPtr, A_Domain_RetDetLevelEn) == PtfRetDetLvl_Grid ||
                GET_FLAG(domainPtr, A_Domain_SubGridFlg) == TRUE || /* PMSTA-12078 - LJE - 110625 */
                GET_ENUM(domainPtr, A_Domain_RetDetLevelEn) == PtfRetDetLvl_Instrument)
            {
                /* Search the best grid according the following rules :
                    1) Grid of the first strategy link
                    2) The grid set on the domain
                    3) Use the "UsePSP" rules
                    */
                SET_ID(domainPtr, A_Domain_GridId, savedGridId);
                DBA_SetBestGridInDomain(hierHead,
                                        domainPtr,
                                        computeTab,
                                        mainObjInfoStp->mainObjStp,
                                        mainObjInfoStp->hierPtfStp,
                                        pspTab,
                                        pspNbr,
                                        *(computeTab[currComputeIdx].outObjEnPtr),
                                        currPSPObjLnkStp,
                                        lastMainObjLnkStp);
            }

            if (pspNbr == 0)
            {
                /* Create a PSP with needed information */
                if (GET_ENUM(domainPtr, A_Domain_RetDetLevelEn) == PtfRetDetLvl_UsePSP ||
                    (mainObjInfoStp != NULL && mainObjInfoStp->passNbr == PASS_STORED_HIER_PSP) || /* Don't create PSP in the first pass (parent of hierarchy) */
                    DBA_CreateValidPSP(hierHead, domainPtr, computeTab, mainObjInfoStp, currPSPObjLnkStp, currPSPObjLnkStp, domPPDaStp, &pspNbr, &pspTab) != RET_SUCCEED ||
                    pspNbr == 0)
                {
                    /* Nothing to do, no on-line to be call */
                    return (RET_SUCCEED);
                }
            }

            if (DBA_SearchBestPSPOnDate(hierHead,
                domainPtr,
                &computeTab[currComputeIdx],
                mainObjInfoStp,
                pspTab,
                pspNbr,
                GET_DATETIME(currPSPObjLnkStp, A_ObjectLnk_BeginDate),
                GET_DATETIME(currPSPObjLnkStp, A_ObjectLnk_EndDate),
                currPSPObjLnkStp,
                currPSPObjLnkStp,
                firstFlg == FALSE,
                defPPDaStp,
                domPPDaStp,
                &bestPspStp) == RET_SUCCEED &&
                bestPspStp != NULL)
            {
                lastRABestPspStp = bestPspStp; /* PMSTA-11283 - LJE - 110127 */

                if (mainObjInfoStp != NULL &&
                    mainObjInfoStp->passNbr >= PASS_PARENT_HIER_PSP &&
                    mainObjInfoStp->lastStoredPSPDate.date == SYB_BEGIN_DATE &&
                    mainObjInfoStp->hierObjLnksNbr > 0)
                {
                    /* Remove all object links on no hierarchical PSP */
                    int i;
                    for (i = 0; i < mainObjInfoStp->hierObjLnksNbr; i++)
                    {
                        DBA_DelHierEltRec(hierHead, A_ObjectLnk, mainObjInfoStp->hierObjLnksTab[i]);
                    }

                    mainObjInfoStp->hierObjLnksNbr = 0;
                    FREE(mainObjInfoStp->hierObjLnksTab);
                }

                if (mainObjInfoStp->passNbr == PASS_STORED_HIER_PSP)
                {
                    if (CMP_DYNFLD(domainPtr, bestPspStp,
                        *(computeTab[currComputeIdx].domFromDIdxPtr), *(computeTab[currComputeIdx].fromDIdxPtr), DatetimeType) > 0)
                    {
                        COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_BeginDate,
                                    domainPtr, A_Domain, *(computeTab[currComputeIdx].domFromDIdxPtr));
                    }
                    else
                    {
                        COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_BeginDate,
                                    bestPspStp, A_PerfStorageParam, *(computeTab[currComputeIdx].fromDIdxPtr));
                    }
                }

                if (IS_NULLFLD(currPSPObjLnkStp, A_ObjectLnk_EndDate) == TRUE)
                {
                    if (CMP_DYNFLD(domainPtr, bestPspStp,
                        *(computeTab[currComputeIdx].domTillDIdxPtr), *(computeTab[currComputeIdx].tillDIdxPtr), DatetimeType) < 0)
                    {
                        COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_EndDate,
                                    domainPtr, A_Domain, *(computeTab[currComputeIdx].domTillDIdxPtr));
                    }
                    else
                    {
                        COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_EndDate,
                                    bestPspStp, A_PerfStorageParam, *(computeTab[currComputeIdx].tillDIdxPtr));
                    }
                }

                if (GET_ENUM(bestPspStp, A_PerfStorageParam_FrequencyEn) >
                    FIN_GetDomainFreqEnForPAA(domainPtr, *(computeTab[currComputeIdx].outObjEnPtr)))
                {
                    SET_ENUM(domainPtr, A_Domain_Freq1UnitEn, GET_ENUM(bestPspStp, A_PerfStorageParam_FrequencyEn));
                }

                /* PMSTA-24511 - LJE - 161206 */
                if (CMP_DYNFLD(currPSPObjLnkStp, firstMainObjLnkStp,
                    A_ObjectLnk_EndDate, A_ObjectLnk_EndDate, DatetimeType) > 0)
                {
                    COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_EndDate,
                                firstMainObjLnkStp, A_ObjectLnk, A_ObjectLnk_EndDate);
                }
                if (CMP_DYNFLD(currPSPObjLnkStp, lastMainObjLnkStp,
                    A_ObjectLnk_BeginDate, A_ObjectLnk_BeginDate, DatetimeType) < 0)
                {
                    COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_BeginDate,
                                lastMainObjLnkStp, A_ObjectLnk, A_ObjectLnk_BeginDate);
                }
                
                if (lastPspObjLnkStpPtr != NULL &&
                    (ret = DBA_InsertValidPSP(hierHead,
                    domainPtr,
                    currPSPObjLnkStp,
                    bestPspStp,
                    dbiConnHelper,
                    &computeTab[currComputeIdx],
                    lastPspObjLnkStpPtr)) != RET_SUCCEED)
                {
                    return (ret);
                }

                if (lastGridObjLnkStpPtr != NULL &&
                    (ret = DBA_InsertGridObjLnk(hierHead,
                    domainPtr,
                    currPSPObjLnkStp,
                    bestPspStp,
                    &computeTab[currComputeIdx],
											lastGridObjLnkStpPtr,
											mainObjInfoStp)) != RET_SUCCEED)
                {
                    return (ret);
                }

                /* PMSTA-10640 - LJE - 101025 - Copy the current PSP to all children */
                if ((computeTab[currComputeIdx].returnInParPtfRuleEn == ReturnInParentPtfRule_Children ||
                    (computeTab[currComputeIdx].returnInParPtfRuleEn == ReturnInParentPtfRule_ParentUsingHierPSP &&
                    GET_ENUM(domainPtr, A_Domain_RetDetLevelEn) != PtfRetDetLvl_UsePSP)) && /* PMSTA-18812 - LJE -0141008 */
                    mainObjInfoStp->hierPtfStp != NULL &&
                    GET_EXTENSION_PTR(mainObjInfoStp->hierPtfStp, A_Ptf_HierChildrenPtf_Ext) != NULL &&
                    GET_ENUM(bestPspStp, A_PerfStorageParam_PerfAttribReturnEn) == PerfAttribRtnEn_Standard)
                {
                    int i;
                    DBA_DYNFLD_STP childBestPspStp, *childPtfTab;

                    if ((childPtfTab = GET_EXTENSION_PTR(mainObjInfoStp->hierPtfStp, A_Ptf_HierChildrenPtf_Ext)) != NULL)
                    {
                        for (i = 0; i < GET_EXTENSION_NBR(mainObjInfoStp->hierPtfStp, A_Ptf_HierChildrenPtf_Ext); i++)
                        {
                            if ((childBestPspStp = ALLOC_DYNST(A_PerfStorageParam)) == NULL)
                            {
                                return RET_MEM_ERR_ALLOC;
                            }

                            COPY_DYNST(childBestPspStp, bestPspStp, A_PerfStorageParam);

                            SET_NULL_ID(childBestPspStp, A_PerfStorageParam_Id);
                            COPY_DYNFLD(childBestPspStp, A_PerfStorageParam, A_PerfStorageParam_ObjId,
                                        childPtfTab[i], A_Ptf, A_Ptf_Id);
                            SET_NULL_DATETIME(childBestPspStp, A_PerfStorageParam_StdPerfFirstStoredDate);
                            SET_NULL_DATETIME(childBestPspStp, A_PerfStorageParam_StdPerfLastStoredDate);
                            SET_NULL_DATETIME(childBestPspStp, A_PerfStorageParam_RetFirstStoredDate);
                            SET_NULL_DATETIME(childBestPspStp, A_PerfStorageParam_RetLastStoredDate);
                            SET_NULL_DATETIME(childBestPspStp, A_PerfStorageParam_PerfFirstStoredDate);
                            SET_NULL_DATETIME(childBestPspStp, A_PerfStorageParam_PerfLastStoredDate);

                            DBA_AddHierRecord(hierHead,
                                              childBestPspStp,
                                              A_PerfStorageParam,
                                              FALSE,
                                              HierAddRec_NoLnk);
                        }
                    }
                }

                if (childPtfFlg == TRUE)
                {
                    if (IS_NULLFLD(bestPspStp, A_PerfStorageParam_StdPerfLastStoredDate) == FALSE &&
                        mainObjInfoStp->parMainObjInfoStp != NULL)
                    {
                        if (DATETIME_CMP(mainObjInfoStp->parMainObjInfoStp->lastStoredPSPDate, GET_DATETIME(bestPspStp, A_PerfStorageParam_StdPerfLastStoredDate)) < 0)
                        {
                            mainObjInfoStp->parMainObjInfoStp->lastStoredPSPDate = GET_DATETIME(bestPspStp, A_PerfStorageParam_StdPerfLastStoredDate);
                        }
                    }

                    /* PMSTA-24511 - LJE - 161206 */
                    if (IS_NULLFLD(bestPspStp, A_PerfStorageParam_StdPerfFirstStoredDate) == FALSE &&
                        mainObjInfoStp->parMainObjInfoStp != NULL &&
                        DATETIME_CMP(mainObjInfoStp->parMainObjInfoStp->firstStoredPSPDate, GET_DATETIME(bestPspStp, A_PerfStorageParam_StdPerfFirstStoredDate)) > 0)
                    {
                        mainObjInfoStp->parMainObjInfoStp->firstStoredPSPDate = GET_DATETIME(bestPspStp, A_PerfStorageParam_StdPerfFirstStoredDate);
                    }
                }
                else if (parentPtfFlg == TRUE)
                {
                    if (IS_NULLFLD(bestPspStp, A_PerfStorageParam_StdPerfLastStoredDate) == FALSE &&
                        GET_ENUM(bestPspStp, A_PerfStorageParam_PerfAttribReturnEn) == PerfAttribRtnEn_Hierarchy &&
                        DATETIME_CMP(mainObjInfoStp->firstHierPSPDate, GET_DATETIME(bestPspStp, A_PerfStorageParam_StdPerfFirstStoredDate)) > 0)
                    {
                        mainObjInfoStp->firstHierPSPDate = GET_DATETIME(bestPspStp, A_PerfStorageParam_StdPerfFirstStoredDate);
                    }

                    /* PMSTA-24511 - LJE - 161206 */
                    if (IS_NULLFLD(bestPspStp, A_PerfStorageParam_StdPerfFirstStoredDate) == FALSE &&
                        DATETIME_CMP(mainObjInfoStp->firstStoredPSPDate, GET_DATETIME(bestPspStp, A_PerfStorageParam_StdPerfFirstStoredDate)) > 0)
                    {
                        mainObjInfoStp->firstStoredPSPDate = GET_DATETIME(bestPspStp, A_PerfStorageParam_StdPerfFirstStoredDate);
                    }

                    if (DATETIME_CMP(mainObjInfoStp->lastStoredPSPDate, GET_DATETIME(bestPspStp, A_PerfStorageParam_StdPerfLastStoredDate)) < 0)
                    {
                        mainObjInfoStp->lastStoredPSPDate = GET_DATETIME(bestPspStp, A_PerfStorageParam_StdPerfLastStoredDate);
                    }
                }

                /* PMSTA-10640 - LJE - 101020 */
                if (lastGridObjLnkStpPtr != NULL &&
                    *lastGridObjLnkStpPtr != NULL &&
                    CMP_DYNFLD(bestPspStp, (*lastGridObjLnkStpPtr), A_PerfStorageParam_GridId, A_ObjectLnk_ToObjectId, IdType) != 0)
                {
                    DBA_InsertCopyGridObjLnk(hierHead,
                                             domainPtr,
                                             computeTab,
                                             currPSPObjLnkStp,
                                             (*lastGridObjLnkStpPtr),
                                             bestPspStp);
                }

                /* Insert ExtRet info */
                if (currComputeIdx == PERF_ATTRIB_IDX &&
                    GET_ENUM(domainPtr, A_Domain_ReturnAnalysisEn) == PAARetAnalysis_All)
                {
                    SET_FLAG(bestPspStp, A_PerfStorageParam_RetAnalysisFlg, TRUE);

                    if ((ret = DBA_InsertValidPSP(hierHead,
                        domainPtr,
                        currPSPObjLnkStp,
                        bestPspStp,
                        dbiConnHelper,
                        &computeTab[EXT_RET_IDX],
                        NULL)) != RET_SUCCEED)
                    {
                        return (ret);
                    }
                }

                if (currComputeIdx != STD_PERF_IDX &&
                    lastPspStdPerfObjLnkStpPtr != NULL)
                {
                    SET_ENUM(currPSPObjLnkStp, A_ObjectLnk_Nature, computeTab[STD_PERF_IDX].objLnkNat);

                    if ((ret = DBA_InsertValidPSP(hierHead,
                        domainPtr,
                        currPSPObjLnkStp,
                        bestPspStp,
                        dbiConnHelper,
                        &computeTab[STD_PERF_IDX],
                        lastPspStdPerfObjLnkStpPtr)) != RET_SUCCEED)
                    {
                        return (ret);
                    }

                    SET_ENUM(currPSPObjLnkStp, A_ObjectLnk_Nature, computeTab[currComputeIdx].objLnkNat);
                }
                /*PMSTA-54344 - SENTHIL - 230823*/

                if (currComputeIdx != PERF_CALC_RES_IDX &&
                    lastPspPerfCalcResObjLnkStpPtr != NULL)
                {
                    SET_ENUM(currPSPObjLnkStp, A_ObjectLnk_Nature, computeTab[PERF_CALC_RES_IDX].objLnkNat);

                    if ((ret = DBA_InsertValidPSP(hierHead,
                        domainPtr,
                        currPSPObjLnkStp,
                        bestPspStp,
                        dbiConnHelper,
                        &computeTab[PERF_CALC_RES_IDX],
                        lastPspPerfCalcResObjLnkStpPtr)) != RET_SUCCEED)
                    {
                        return (ret);
                    }

                    SET_ENUM(currPSPObjLnkStp, A_ObjectLnk_Nature, computeTab[currComputeIdx].objLnkNat);
                }

                COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_EndDate,
                            bestPspStp, A_PerfStorageParam, *(computeTab[currComputeIdx].fromDIdxPtr));
            }
            else
            {
                bestPspStp = NULL;
            }

            /* PMSTA-17234 - LJE - 131119 */
            if (computeTab->returnInParPtfRuleEn == ReturnInParentPtfRule_Parent &&
                mainObjInfoStp->passNbr != PASS_STORED_HIER_PSP &&
                bestPspStp == NULL &&
                firstFlg == TRUE &&
                mainObjInfoStp->forceHierPSPFlg == TRUE)
            {
                FREE(pspTab);
                pspNbr = 0;
                if (GET_ENUM(domainPtr, A_Domain_RetDetLevelEn) == PtfRetDetLvl_UsePSP ||
                    (ret = DBA_CreateValidPSP(hierHead, domainPtr, computeTab, mainObjInfoStp, currPSPObjLnkStp, currPSPObjLnkStp, domPPDaStp, &pspNbr, &pspTab)) != RET_SUCCEED ||
                    pspNbr == 0)
                {
                    SET_ID(domainPtr, A_Domain_GridId, savedGridId);
                    return ret;
                }
            }

            if (bestPspStp == NULL ||
                (IS_NULLFLD(bestPspStp, *(computeTab[currComputeIdx].fromDIdxPtr)) == FALSE && /* PMSTA-11283 - LJE - 110127 */
                CMP_DYNFLD(currPSPObjLnkStp, bestPspStp,
                A_ObjectLnk_BeginDate, *(computeTab[currComputeIdx].fromDIdxPtr), DatetimeType) >= 0))
            {
                endFlg = TRUE;
            }

            firstFlg = FALSE;
        }
        else
        {
            endFlg = TRUE;
        }
    }

    /* Long term analysis */
    if (lastPspStdPerfObjLnkStpPtr != NULL &&
        CMP_DYNFLD(lastMainObjLnkStp, domainPtr, A_ObjectLnk_BeginDate, A_Domain_InterpFromDate, DatetimeType) < 0)
    {
        OBJECTLNK_NAT_ENUM  savedObjLnkNat = (OBJECTLNK_NAT_ENUM)GET_ENUM(currPSPObjLnkStp, A_ObjectLnk_Nature); /* PMSTA-13058 - LJE - 111103 */
        SET_ENUM(currPSPObjLnkStp, A_ObjectLnk_Nature, computeTab[STD_PERF_IDX].objLnkNat);

        COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_BeginDate,
                    lastMainObjLnkStp, A_ObjectLnk, A_ObjectLnk_BeginDate);

        if (CMP_DYNFLD(firstMainObjLnkStp, domainPtr, A_ObjectLnk_EndDate, A_Domain_InterpFromDate, DatetimeType) < 0)
        {
            COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_EndDate,
                        firstMainObjLnkStp, A_ObjectLnk, A_ObjectLnk_EndDate);
        }
        else
        {
            COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_EndDate,
                        domainPtr, A_Domain, A_Domain_InterpFromDate);
        }

        DBA_InsertGridObjLnk(hierHead,
                             domainPtr,
                             currPSPObjLnkStp,
                             lastRABestPspStp,
                             &computeTab[STD_PERF_IDX],
							 lastGridObjLnkStpPtr,
							 mainObjInfoStp);

        endFlg = FALSE;

        /* If possible, use the Ext Ret Analysis PSP */
        if (lastRABestPspStp != NULL &&
            CMP_DYNFLD(lastRABestPspStp, domainPtr, *(computeTab[STD_PERF_IDX].fromDIdxPtr), A_Domain_InterpFromDate, DatetimeType) < 0)
        {
            if ((ret = DBA_InsertValidPSP(hierHead,
                domainPtr,
                currPSPObjLnkStp,
                lastRABestPspStp,
                dbiConnHelper,
                &computeTab[STD_PERF_IDX],
                lastPspStdPerfObjLnkStpPtr)) != RET_SUCCEED)
            {
                return (ret);
            }

            COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_EndDate,
                        lastRABestPspStp, A_PerfStorageParam, *(computeTab[STD_PERF_IDX].fromDIdxPtr));

            if (CMP_DYNFLD(lastRABestPspStp, currPSPObjLnkStp, *(computeTab[STD_PERF_IDX].fromDIdxPtr), A_ObjectLnk_BeginDate, DatetimeType) <= 0) /* LJE - 131214 - use begin date instead of the end date */
            {
                endFlg = TRUE;
            }
        }

        if (endFlg == FALSE)
        {
            SET_ENUM(currPSPObjLnkStp, A_ObjectLnk_Nature, computeTab[PERF_CALC_RES_IDX].objLnkNat);

            if ((ret = DBA_LoadPerfCalcResultPSP(hierHead,
                domainPtr,
                dbiConnHelper,
                computeTab,
                currPSPObjLnkStp,
                currPSPObjLnkStp,
                *lastGridObjLnkStpPtr,
                defPPDaStp,
                domPPDaStp,
                TRUE,
                TRUE)) != RET_SUCCEED)
            {
                return(ret);
            }

            SET_ENUM(currPSPObjLnkStp, A_ObjectLnk_Nature, computeTab[STD_PERF_IDX].objLnkNat);
            if ((ret = DBA_LoadStandardPerfPSP(hierHead,
                domainPtr,
                dbiConnHelper,
                computeTab,
                currPSPObjLnkStp,
                currPSPObjLnkStp,
                *lastGridObjLnkStpPtr,
                defPPDaStp,
                domPPDaStp,
                TRUE,
                TRUE)) != RET_SUCCEED)
            {
                return(ret);
            }

        }

        /* WEALTH-8340 - DDV - 240919 - PerfCalcResult must also been loaded for long term */
        SET_ENUM(currPSPObjLnkStp, A_ObjectLnk_Nature, computeTab[PERF_CALC_RES_IDX].objLnkNat);

        COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_BeginDate,
            lastMainObjLnkStp, A_ObjectLnk, A_ObjectLnk_BeginDate);

        if (CMP_DYNFLD(firstMainObjLnkStp, domainPtr, A_ObjectLnk_EndDate, A_Domain_InterpFromDate, DatetimeType) < 0)
        {
            COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_EndDate,
                firstMainObjLnkStp, A_ObjectLnk, A_ObjectLnk_EndDate);
        }
        else
        {
            COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_EndDate,
                domainPtr, A_Domain, A_Domain_InterpFromDate);
        }

        endFlg = FALSE;

        /* If possible, use the Ext Ret Analysis PSP */
        if (lastRABestPspStp != NULL &&
            CMP_DYNFLD(lastRABestPspStp, domainPtr, *(computeTab[PERF_CALC_RES_IDX].fromDIdxPtr), A_Domain_InterpFromDate, DatetimeType) < 0)
        {
            if ((ret = DBA_InsertValidPSP(hierHead,
                                            domainPtr,
                                            currPSPObjLnkStp,
                                            lastRABestPspStp,
                                            dbiConnHelper,
                                            &computeTab[PERF_CALC_RES_IDX],
                                            lastPspStdPerfObjLnkStpPtr)) != RET_SUCCEED)
            {
                return (ret);
            }

            COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_EndDate,
                lastRABestPspStp, A_PerfStorageParam, *(computeTab[PERF_CALC_RES_IDX].fromDIdxPtr));

            if (CMP_DYNFLD(lastRABestPspStp, currPSPObjLnkStp, *(computeTab[PERF_CALC_RES_IDX].fromDIdxPtr), A_ObjectLnk_BeginDate, DatetimeType) <= 0)
            {
                endFlg = TRUE;
            }
        }

        if (endFlg == FALSE)
        {
            SET_ENUM(currPSPObjLnkStp, A_ObjectLnk_Nature, computeTab[PERF_CALC_RES_IDX].objLnkNat);

            if ((ret = DBA_LoadPerfCalcResultPSP(hierHead,
                                                    domainPtr,
                                                    dbiConnHelper,
                                                    computeTab,
                                                    currPSPObjLnkStp,
                                                    currPSPObjLnkStp,
                                                    *lastGridObjLnkStpPtr,
                                                    defPPDaStp,
                                                    domPPDaStp,
                                                    TRUE,
                                                    TRUE)) != RET_SUCCEED)
            {
                return(ret);
            }

            SET_ENUM(currPSPObjLnkStp, A_ObjectLnk_Nature, computeTab[PERF_CALC_RES_IDX].objLnkNat);
            if ((ret = DBA_LoadStandardPerfPSP(hierHead,
                                                domainPtr,
                                                dbiConnHelper,
                                                computeTab,
                                                currPSPObjLnkStp,
                                                currPSPObjLnkStp,
                                                *lastGridObjLnkStpPtr,
                                                defPPDaStp,
                                                domPPDaStp,
                                                TRUE,
                                                TRUE)) != RET_SUCCEED)
            {
                return(ret);
            }
        }
        SET_ENUM(currPSPObjLnkStp, A_ObjectLnk_Nature, savedObjLnkNat);
    }

    /* Load benchmarks */
    COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_BeginDate,
                lastMainObjLnkStp, A_ObjectLnk, A_ObjectLnk_BeginDate);
    COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_EndDate,
                firstMainObjLnkStp, A_ObjectLnk, A_ObjectLnk_EndDate);

    if (currComputeIdx == PERF_ATTRIB_IDX)
    {
        DBA_LoadBenchPSPForPerfAttrib(hierHead,
                                      domainPtr,
                                      dbiConnHelper,
                                      computeTab,
                                      currPSPObjLnkStp,
                                      defPPDaStp,
                                      domPPDaStp);
    }
    else
    {
        DBA_LoadBenchPSPForRetAnalysis(hierHead,
                                       domainPtr,
                                       dbiConnHelper,
                                       computeTab,
                                       currPSPObjLnkStp,
                                       defPPDaStp,
                                       domPPDaStp);
    }

    FREE(pspTab);
    return ret;
}

/************************************************************************
**  Function             : FIN_GetIrregBenchFlg()
**
**  Description          : Check if the forced benchmark is irregular
**                         Only if PerfAttrib needed.
**
**  Arguments            :
**
**  Return               : RET_SUCCEED or error code
**
**  Creation             : PMSTA09979 - LJE - 100825
**
*************************************************************************/
STATIC FLAG_T   FIN_GetIrregBenchFlg(DBA_HIER_HEAD_STP    hierHead,
                                     DBA_DYNFLD_STP       domainPtr,
                                     COMPUTE_PAA_STP      computeTab)
{
    FLAG_T irregBenchFlg = FALSE;

    if (GET_FLAG(domainPtr, A_Domain_ForceLnkFlg) == TRUE &&
        (GET_ENUM(domainPtr, A_Domain_ReturnAnalysisEn) == PAARetAnalysis_All ||
        GET_ENUM(domainPtr, A_Domain_ReturnAnalysisEn) == PAARetAnalysis_PA))
    {
        int    i, k;
        PA_DATETIME_STP     paDateTab;
        int                 paDateNbr;

        k = 0;
        while (k < 3)
        {
            if (GET_DICT(domainPtr, A_Domain_Bench1EntityDictId + k) == computeTab->stratEntDictId &&
                IS_NULLFLD(domainPtr, A_Domain_Bench1ObjectId + k) == FALSE)
            {
                DBA_DYNFLD_STP stratPtr = DBA_SearchHierRecById(hierHead,
                                                                A_Strat,
                                                                A_Strat_Id,
                                                                GET_ID(domainPtr, A_Domain_Bench1ObjectId + k));

                if (FIN_StoreBenchmarkDates(hierHead,
                    NULL,
                    DictFct_PtfStorage,
                    GET_DATETIME(domainPtr, A_Domain_InterpFromDate),
                    GET_DATETIME(domainPtr, A_Domain_InterpTillDate),
                    (TINYINT_T)1,
                    FreqUnit_Month,
                    stratPtr,
                    FALSE,	/* stratCompoFlg FALSE anytime, TRUE in case of recursiv call for sub-strategies*/
                    FALSE,    /* PMSTA-10869 - LJE - 110104 - Keep the first history as begin */
                    &paDateTab,
                    &paDateNbr) != RET_SUCCEED)
                {
                    return(FALSE);
                }

                for (i = 0; i < paDateNbr; i++)
                {
                    if (GET_BIT(paDateTab[i].level, SynthLevel_BenchRebal) == TRUE &&
                        GET_BIT(paDateTab[i].level, SynthLevel_PortBenchStorage) == FALSE)
                    {
                        irregBenchFlg = TRUE;
                        break;
                    }
                }

                FREE(paDateTab);
                break;
            }
            k += 2;
        }
    }
    return irregBenchFlg;
}

/************************************************************************
**  Function             : DBA_LoadPspForOneMainObj()
**
**  Description          :
**
**  Arguments            :
**
**  Return               : RET_SUCCEED or error code
**
**  Creation             : PMSTA-10640 - LJE - 101022
**
*************************************************************************/
STATIC RET_CODE DBA_LoadPspForOneMainObj(DBA_HIER_HEAD_STP    hierHead,
                                         DBA_DYNFLD_STP       domainPtr,
                                         DbiConnectionHelper& dbiConnHelper,
                                         COMPUTE_PAA_STP      computeTab,
                                         DBA_DYNFLD_STP       defPPDaStp,
                                         DBA_DYNFLD_STP       domPPDaStp,
                                         FLAG_T               irregBenchFlg,
                                         DBA_MAIN_OBJ_STP     mainObjInfoStp,
                                         DBA_DYNFLD_STP      *lastGridRAObjLnkStpPtr,
                                         DBA_DYNFLD_STP      *lastPspRAObjLnkStpPtr,
                                         DBA_DYNFLD_STP      *lastGridPAObjLnkStpPtr,
                                         DBA_DYNFLD_STP      *lastPspPAObjLnkStpPtr,
                                         DBA_DYNFLD_STP      *lastPspStdPerfObjLnkStpPtr,
                                         DBA_DYNFLD_STP      *lastPspPerfCalcResObjLnkStpPtr,
                                         DBA_DYNFLD_STP       firstMainObjLnkStp,
                                         DBA_DYNFLD_STP       lastMainObjLnkStp,
                                         DBA_DYNFLD_STP       currPSPObjLnkStp)
{
    RET_CODE        ret = RET_SUCCEED;

    /* Search PSP only for the first access of each portfolio */
    if (CMP_DYNFLD(firstMainObjLnkStp, currPSPObjLnkStp,
        A_ObjectLnk_FromEntDictId, A_ObjectLnk_FromEntDictId, DictType) != 0 ||
        CMP_DYNFLD(firstMainObjLnkStp, currPSPObjLnkStp,
        A_ObjectLnk_FromObjectId, A_ObjectLnk_FromObjectId, IdType) != 0)
    {
        (*lastGridRAObjLnkStpPtr) = NULL;
        (*lastPspRAObjLnkStpPtr) = NULL;
        (*lastGridPAObjLnkStpPtr) = NULL;
        (*lastPspPAObjLnkStpPtr) = NULL;
        (*lastPspStdPerfObjLnkStpPtr) = NULL;
    }

    COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_FromEntDictId,
                firstMainObjLnkStp, A_ObjectLnk, A_ObjectLnk_FromEntDictId);
    COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_FromObjectId,
                firstMainObjLnkStp, A_ObjectLnk, A_ObjectLnk_FromObjectId);

    /* PMSTA-16306 - LJE - 130506 - Special case when Use PSP */
    if (GET_ENUM(domainPtr, A_Domain_RetDetLevelEn) == PtfRetDetLvl_UsePSP &&
        GET_ENUM(domainPtr, A_Domain_ReturnAnalysisEn) == PAARetAnalysis_All)
    {
        SET_ENUM(domainPtr, A_Domain_ReturnAnalysisEn, PAARetAnalysis_PA);
        computeTab[PERF_ATTRIB_IDX].irregBenchFlg = irregBenchFlg;
        SET_ENUM(currPSPObjLnkStp, A_ObjectLnk_Nature, computeTab[PERF_ATTRIB_IDX].objLnkNat);
        SET_INT(currPSPObjLnkStp, A_ObjectLnk_Rank, 0); /* PMSTA50244 - MKK - 230123 */

        if ((ret = DBA_LoadDomPspForCurrPSPObjLnk(hierHead,
            domainPtr,
            dbiConnHelper,
            computeTab,
            PERF_ATTRIB_IDX,
            mainObjInfoStp,
            currPSPObjLnkStp,
            firstMainObjLnkStp,
            lastMainObjLnkStp,
            defPPDaStp,
            domPPDaStp,
            lastGridPAObjLnkStpPtr,
            lastPspPAObjLnkStpPtr,
            lastPspStdPerfObjLnkStpPtr,
            lastPspPerfCalcResObjLnkStpPtr)) != RET_SUCCEED)
        {
            return (ret);
        }

        (*lastGridRAObjLnkStpPtr) = NULL;
        (*lastPspRAObjLnkStpPtr) = NULL;
        (*lastGridPAObjLnkStpPtr) = NULL;
        (*lastPspPAObjLnkStpPtr) = NULL;
        (*lastPspStdPerfObjLnkStpPtr) = NULL;
        SET_ENUM(domainPtr, A_Domain_ReturnAnalysisEn, PAARetAnalysis_RA);
        SET_ENUM(currPSPObjLnkStp, A_ObjectLnk_Nature, computeTab[EXT_RET_IDX].objLnkNat);
        SET_INT(currPSPObjLnkStp, A_ObjectLnk_Rank, 0); /* PMSTA50244 - MKK - 230123 */

        if ((ret = DBA_LoadDomPspForCurrPSPObjLnk(hierHead,
            domainPtr,
            dbiConnHelper,
            computeTab,
            EXT_RET_IDX,
            mainObjInfoStp,
            currPSPObjLnkStp,
            firstMainObjLnkStp,
            lastMainObjLnkStp,
            defPPDaStp,
            domPPDaStp,
            lastGridPAObjLnkStpPtr,
            lastPspPAObjLnkStpPtr,
            lastPspStdPerfObjLnkStpPtr,
            lastPspPerfCalcResObjLnkStpPtr)) != RET_SUCCEED)
        {
            return (ret);
        }
        SET_ENUM(domainPtr, A_Domain_ReturnAnalysisEn, PAARetAnalysis_All);
    }
    else if (GET_ENUM(domainPtr, A_Domain_ReturnAnalysisEn) == PAARetAnalysis_All ||
             GET_ENUM(domainPtr, A_Domain_ReturnAnalysisEn) == PAARetAnalysis_PA)
    {
        computeTab[PERF_ATTRIB_IDX].irregBenchFlg = irregBenchFlg;

        SET_ENUM(currPSPObjLnkStp, A_ObjectLnk_Nature, computeTab[PERF_ATTRIB_IDX].objLnkNat);

        SET_INT(currPSPObjLnkStp, A_ObjectLnk_Rank, 0); /* PMSTA50244 - MKK - 230123 */

        if ((ret = DBA_LoadDomPspForCurrPSPObjLnk(hierHead,
            domainPtr,
            dbiConnHelper,
            computeTab,
            PERF_ATTRIB_IDX,
            mainObjInfoStp,
            currPSPObjLnkStp,
            firstMainObjLnkStp,
            lastMainObjLnkStp,
            defPPDaStp,
            domPPDaStp,
            lastGridPAObjLnkStpPtr,
            lastPspPAObjLnkStpPtr,
            lastPspStdPerfObjLnkStpPtr,
            lastPspPerfCalcResObjLnkStpPtr)) != RET_SUCCEED)
        {
            return (ret);
        }
    }
    else if (GET_ENUM(domainPtr, A_Domain_ReturnAnalysisEn) == PAARetAnalysis_RA)
    {
        SET_ENUM(currPSPObjLnkStp, A_ObjectLnk_Nature, computeTab[EXT_RET_IDX].objLnkNat);

        SET_INT(currPSPObjLnkStp, A_ObjectLnk_Rank, 0); /* PMSTA50244 - MKK - 230123 */

        if ((ret = DBA_LoadDomPspForCurrPSPObjLnk(hierHead,
            domainPtr,
            dbiConnHelper,
            computeTab,
            EXT_RET_IDX,
            mainObjInfoStp,
            currPSPObjLnkStp,
            firstMainObjLnkStp,
            lastMainObjLnkStp,
            defPPDaStp,
            domPPDaStp,
            lastGridRAObjLnkStpPtr,
            lastPspRAObjLnkStpPtr,
            lastPspStdPerfObjLnkStpPtr,
            lastPspPerfCalcResObjLnkStpPtr)) != RET_SUCCEED)
        {
            return (ret);
        }
    }
    else if (GET_ENUM(domainPtr, A_Domain_ReturnAnalysisEn) == PAARetAnalysis_StdPerf)
    {
        SET_ENUM(currPSPObjLnkStp, A_ObjectLnk_Nature, computeTab[STD_PERF_IDX].objLnkNat);

        SET_INT(currPSPObjLnkStp, A_ObjectLnk_Rank, 0); /* PMSTA50244 - MKK - 230123 */

        if ((ret = DBA_LoadDomPspForCurrPSPObjLnk(hierHead,
            domainPtr,
            dbiConnHelper,
            computeTab,
            STD_PERF_IDX,
            mainObjInfoStp,
            currPSPObjLnkStp,
            firstMainObjLnkStp,
            lastMainObjLnkStp,
            defPPDaStp,
            domPPDaStp,
            lastGridRAObjLnkStpPtr,
            lastPspStdPerfObjLnkStpPtr,
            lastPspStdPerfObjLnkStpPtr,
            lastPspPerfCalcResObjLnkStpPtr)) != RET_SUCCEED)
        {
            return (ret);
        }
    }

    return (ret);
}

/************************************************************************
**  Function             : DBA_LoadDomPspTableFromExistingPSP()
**
**  Description          : Create and fill #dom_psp table for operation search load
**                         This function is only used for Return Anaylsis search.
**
**  Arguments            :
**
**  Return               : RET_SUCCEED or error code
**
**  Creation             : PMSTA09843 - LJE - 100520
**
*************************************************************************/
STATIC RET_CODE DBA_LoadDomPspTableFromExistingPSP(DBA_HIER_HEAD_STP    hierHead,
                                                   DBA_DYNFLD_STP       domainPtr,
                                                   DbiConnectionHelper& dbiConnHelper,
                                                   COMPUTE_PAA_STP      computeTab)
{
    RET_CODE        ret = RET_SUCCEED;
    DBA_DYNFLD_STP *mainObjLnkTab;
    int             mainObjLnkNbr, i, j, firstMainObjPos, passNbr;
    DBA_DYNFLD_STP  currPSPObjLnkStp = NULL;
    DBA_DYNFLD_STP  domPPDaStp = NULL, defPPDaStp = NULL;
    ID_T            savedGridId;
    FLAG_T          irregBenchFlg;
    OBJECT_ENUM     objEn;
    DBA_DYNFLD_STP  mainObjStp, hierPtfStp;
    DBA_MAIN_OBJ_STP mainObjInfoTab;
    MemoryPool mp;

    FIN_GetAllPPDa(hierHead,
                   domainPtr,
                   computeTab,
                   &defPPDaStp,
                   &domPPDaStp,
                   &irregBenchFlg);

    if (GET_ENUM(domainPtr, A_Domain_ReturnAnalysisEn) != PAARetAnalysis_StdPerf)
    {
        if (IS_NULLFLD(domainPtr, A_Domain_GridId) == FALSE)
        {
            SET_FLAG_TRUE(domainPtr, A_Domain_SubGridFlg);
        }
    }
    else
    {
        SET_NULL_ID(domainPtr, A_Domain_GridId);
        SET_FLAG_FALSE(domainPtr, A_Domain_SubGridFlg);
        SET_ENUM(domainPtr, A_Domain_RetDetLevelEn, PtfRetDetLvl_Global);
    }

    if (GET_ENUM(domainPtr, A_Domain_ReturnAnalysisEn) == PAARetAnalysis_PA ||
        GET_ENUM(domainPtr, A_Domain_ReturnAnalysisEn) == PAARetAnalysis_All)
    {
        if (GET_ENUM(domainPtr, A_Domain_RetDetLevelEn) == PtfRetDetLvl_Global)
        {
            SET_ENUM(domainPtr, A_Domain_RetDetLevelEn, PtfRetDetLvl_Grid);
        }
        SET_FLAG_TRUE(domainPtr, A_Domain_SubGridFlg);
    }

	/* PMSTA-18812 - LJE - 141010 - No grid is allowed at this level */
	if (GET_ENUM(domainPtr, A_Domain_RetDetLevelEn) == PtfRetDetLvl_UsePSP)
	{
		SET_NULL_ID(domainPtr, A_Domain_GridId);
	}

    if (CMP_DYNFLD(domainPtr, domainPtr, A_Domain_CalcRefDate, A_Domain_InterpFromDate, DatetimeType) < 0)
    {
        /* PMSTA-13058 - LJE - 111103 - Split objects in long term and short term period */
        if ((ret = DBA_HierEltRecExtract(hierHead,
            A_ObjectLnk,
            FALSE,
            DBA_FilterMainOrBenchObjectLnkPAA,
            domainPtr,
            DBA_CmpObjectLnkPAA,
            FALSE,
            FALSE,
            &mainObjLnkNbr,
            &mainObjLnkTab)) != RET_SUCCEED)
        {
            FREE_DYNST(defPPDaStp, A_PSPPositionData);
            MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "DBA_LoadDomPspTableFromExistingPSP");
            return(RET_DBA_ERR_NODATA);
        }

        for (i = 0; i < mainObjLnkNbr; i++)
        {
            DBA_DYNFLD_STP objLnkStp;

            if ((objLnkStp = ALLOC_DYNST(A_ObjectLnk)) == NULL)
            {
                FREE_DYNST(defPPDaStp, A_PSPPositionData);
                FREE(mainObjLnkTab);
                MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
                return(RET_MEM_ERR_ALLOC);
            }
            COPY_DYNST(objLnkStp, mainObjLnkTab[i], A_ObjectLnk);
            SET_NULL_ID(objLnkStp, A_ObjectLnk_Id);

            COPY_DYNFLD(mainObjLnkTab[i], A_ObjectLnk, A_ObjectLnk_BeginDate, domainPtr, A_Domain, A_Domain_InterpFromDate);
            COPY_DYNFLD(objLnkStp, A_ObjectLnk, A_ObjectLnk_EndDate, domainPtr, A_Domain, A_Domain_InterpFromDate);

            DBA_AddHierRecord(hierHead,
                              objLnkStp,
                              A_ObjectLnk,
                              FALSE,
                              HierAddRec_NoLnk);
        }

        mainObjLnkNbr = 0;
        FREE(mainObjLnkTab);
    }

    /* Extract main objects */
    if ((ret = DBA_HierEltRecExtract(hierHead,
        A_ObjectLnk,
        FALSE,
        DBA_FilterMainObjectLnkPAA,
        NULL,
        DBA_CmpObjectLnkPAA,
        FALSE,
        FALSE,
        &mainObjLnkNbr,
        &mainObjLnkTab)) != RET_SUCCEED ||
        mainObjLnkNbr == 0)
    {
        FREE_DYNST(defPPDaStp, A_PSPPositionData);
        MSG_SendMesg(RET_DBA_ERR_NODATA, 2, FILEINFO, "DBA_LoadDomPspTableFromExistingPSP");
        return(RET_DBA_ERR_NODATA);
    }

    if ((currPSPObjLnkStp = ALLOC_DYNST(A_ObjectLnk)) == NULL)
    {
        FREE_DYNST(defPPDaStp, A_PSPPositionData);
        FREE(mainObjLnkTab);
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
        return(RET_MEM_ERR_ALLOC);
    }

    /* PMSTA-17234 - LJE - 131115 */
    if ((mainObjInfoTab = (DBA_MAIN_OBJ_STP)CALLOC(mainObjLnkNbr, sizeof(DBA_MAIN_OBJ_ST))) == NULL)
    {
        FREE_DYNST(currPSPObjLnkStp, A_ObjectLnk);
        FREE_DYNST(defPPDaStp, A_PSPPositionData);
        FREE(mainObjLnkTab);
        MSG_SendMesg(RET_MEM_ERR_ALLOC, 0, FILEINFO);
    }

    savedGridId = GET_ID(domainPtr, A_Domain_GridId);

    /* For each main object, try to find valid PSP */
    for (i = 0; i < mainObjLnkNbr; i++)
    {
        ID_T currId = GET_ID(domainPtr, A_Domain_CurrId);

        mainObjInfoTab[i].passNbr = PASS_CHILD_STD_PSP;
        mainObjInfoTab[i].forceHierPSPFlg = FALSE;
        mainObjInfoTab[i].hierObjLnksTab = NULL;
        mainObjInfoTab[i].hierObjLnksNbr = 0;

        mainObjStp = NULL;
        hierPtfStp = NULL;
        DBA_GetObjectEnum(GET_DICT(mainObjLnkTab[i], A_ObjectLnk_FromEntDictId), &objEn);
        if (objEn == Ptf)
        {
            DBA_GetRecPtrFromHierById(hierHead,
                                      GET_ID(mainObjLnkTab[i], A_ObjectLnk_FromObjectId),
                                      A_Ptf,
                                      &mainObjStp);
            if (mainObjStp != NULL &&
                GET_FLAG(domainPtr, A_Domain_DefCurrFlg) == TRUE)
            {
                currId = GET_ID(mainObjStp, A_Ptf_CurrId);
            }

            /* In case of hierarchical portfolios compute the parent in first */
            if ((static_cast<LOADHIERPTF_ENUM> GET_ENUM(domainPtr, A_Domain_LoadHierFlg) != LoadHierPtf_IntermediateHierarchy) &&
                mainObjStp != NULL &&
                GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None &&
                (PTFCONSRULE_ENUM)GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) != PtfConsRule_DetailedChildren)
            {
                hierPtfStp = mainObjStp;

                if (GET_EXTENSION_NBR(mainObjStp, A_Ptf_HierChildrenPtf_Ext) > 0)
                {
                    if (computeTab->returnInParPtfRuleEn != ReturnInParentPtfRule_Children)
                    {
                        mainObjInfoTab[i].passNbr = PASS_STORED_HIER_PSP;
                    }
                    else
                    {
                        mainObjInfoTab[i].passNbr = PASS_PARENT_STD_PSP;
                    }
                }
            }

            /*PMSTA-48195 -Performance IPS Level -Lalby-310123*/
            if ((static_cast<LOADHIERPTF_ENUM> GET_ENUM(domainPtr, A_Domain_LoadHierFlg) == LoadHierPtf_IntermediateHierarchy) && mainObjStp != NULL &&
                FIN_IsPtfConsRuleValidForIntermediateHierarchy(domainPtr) == true)
            {
                hierPtfStp = mainObjStp;

                if ((GET_EXTENSION_NBR(mainObjStp, A_Ptf_HierChildrenPtf_Ext) > 0)
                    ||
                    GET_EXTENSION_NBR(mainObjStp, A_Ptf_ChildrenPtf_Ext) > 0)
                {
                    if (computeTab->returnInParPtfRuleEn != ReturnInParentPtfRule_Children)
                    {
                        mainObjInfoTab[i].passNbr = PASS_STORED_HIER_PSP;
                    }
                    else
                    {
                        mainObjInfoTab[i].passNbr = PASS_PARENT_STD_PSP;
                    }
                }

            }

        }
        else if (objEn == Strat)
        {
            DBA_GetRecPtrFromHierById(hierHead,
                                      GET_ID(mainObjLnkTab[i], A_ObjectLnk_FromObjectId),
                                      A_Strat,
                                      &mainObjStp);
            if (mainObjStp != NULL &&
                GET_FLAG(domainPtr, A_Domain_DefCurrFlg) == TRUE)
            {
                currId = GET_ID(mainObjStp, A_Strat_CurrId);
            }
        }
        else if (objEn == Instr)
        {
            DBA_GetRecPtrFromHierById(hierHead,
                                      GET_ID(mainObjLnkTab[i], A_ObjectLnk_FromObjectId),
                                      A_Instr,
                                      &mainObjStp);
            if (mainObjStp != NULL &&
                GET_FLAG(domainPtr, A_Domain_DefCurrFlg) == TRUE)
            {
                currId = GET_ID(mainObjStp, A_Instr_RefCurrId);
            }
        }
        else if (objEn == List) /* WEALTH-19051 - Lalby - 13032025 */
        {
            DBA_DYNFLD_STP aList = mp.allocDynst(FILEINFO, A_List);
            SET_ID(aList, A_List_Id, GET_ID(mainObjLnkTab[i], A_ObjectLnk_FromObjectId));
            DBA_Get2(List, DBA_ROLE_NO_OPTI, A_List, aList, A_List, &aList, UNUSED, UNUSED, UNUSED);
            if (aList != nullptr ) 
            {
                mainObjStp = aList;
                if(GET_FLAG(domainPtr, A_Domain_DefCurrFlg) == TRUE)
                currId = GET_ID(mainObjStp, A_Instr_RefCurrId);
            }
        }

        mainObjInfoTab[i].objEn = objEn;
        mainObjInfoTab[i].mainObjStp = mainObjStp;
        mainObjInfoTab[i].hierPtfStp = hierPtfStp;
        mainObjInfoTab[i].currId = currId;

        mainObjInfoTab[i].firstHierPSPDate.date = MAGIC_END_DATE;
        mainObjInfoTab[i].firstHierPSPDate.time = 0;

        mainObjInfoTab[i].firstStoredPSPDate.date = MAGIC_END_DATE;
        mainObjInfoTab[i].firstStoredPSPDate.time = 0;

        mainObjInfoTab[i].lastStoredPSPDate.date = SYB_BEGIN_DATE;
        mainObjInfoTab[i].lastStoredPSPDate.time = 0;

        if (computeTab->returnInParPtfRuleEn == ReturnInParentPtfRule_Parent &&
            mainObjInfoTab[i].passNbr == PASS_STORED_HIER_PSP)
        {
            mainObjInfoTab[i].passNbr = PASS_PARENT_HIER_PSP;
        }
    }

    /* PMSTA-17234 - LJE - 131115 - Try to remove all children in load hierarchy case */
    if ((static_cast<LOADHIERPTF_ENUM> GET_ENUM(domainPtr, A_Domain_LoadHierFlg) != LoadHierPtf_IntermediateHierarchy) &&
        GET_ENUM(domainPtr, A_Domain_LoadHierFlg) > LoadHierPtf_None &&
        (PTFCONSRULE_ENUM)GET_ENUM(domainPtr, A_Domain_PtfConsRuleEn) != PtfConsRule_DetailedChildren)
    {
        if (computeTab->returnInParPtfRuleEn == ReturnInParentPtfRule_Parent)
        {
            for (i = 0; i<mainObjLnkNbr; i++)
            {
                if (mainObjInfoTab[i].hierPtfStp != NULL &&
                    GET_EXTENSION_NBR(mainObjInfoTab[i].hierPtfStp, A_Ptf_HierChildrenPtf_Ext) > 0)
                {
                    mainObjInfoTab[i].forceHierPSPFlg = TRUE;
                }
            }
        }
        else if (computeTab->returnInParPtfRuleEn == ReturnInParentPtfRule_ParentUsingHierPSP)
        {
            DBA_MAIN_OBJ_STP parMainObjInfoStp = NULL;

            for (i = 0; i < mainObjLnkNbr; i++)
            {
                if (mainObjInfoTab[i].hierPtfStp != NULL &&
                    IS_NULLFLD(mainObjInfoTab[i].hierPtfStp, A_Ptf_HierPortId) == FALSE)
                {
                    if (parMainObjInfoStp == NULL ||
                        CMP_DYNFLD(parMainObjInfoStp->hierPtfStp, mainObjInfoTab[i].hierPtfStp, A_Ptf_Id, A_Ptf_HierPortId, IdType) != 0)
                    {
                        parMainObjInfoStp = NULL;

                        for (j = 0; j < mainObjLnkNbr && parMainObjInfoStp == NULL; j++)
                        {
                            if (mainObjLnkTab[j] == NULL ||
                                mainObjInfoTab[j].hierPtfStp == NULL ||
                                mainObjInfoTab[j].objEn != Ptf)
                                continue;

                            if (CMP_DYNFLD(mainObjInfoTab[i].hierPtfStp, mainObjInfoTab[j].mainObjStp, A_Ptf_HierPortId, A_Ptf_Id, IdType) == 0)
                            {
                                parMainObjInfoStp = &(mainObjInfoTab[j]);
                                break;
                            }
                        }
                    }
                    mainObjInfoTab[i].parMainObjInfoStp = parMainObjInfoStp;
                }
            }
        }
    }

    /*PMSTA-48195 -Performance IPS Level -Lalby-310123*/
    if ((static_cast<LOADHIERPTF_ENUM> GET_ENUM(domainPtr, A_Domain_LoadHierFlg) == LoadHierPtf_IntermediateHierarchy) && 
                                FIN_IsPtfConsRuleValidForIntermediateHierarchy(domainPtr) == true)
    {
        if (computeTab->returnInParPtfRuleEn == ReturnInParentPtfRule_Parent)
        {
            for (i = 0; i < mainObjLnkNbr; i++)
            {
                if (mainObjInfoTab[i].hierPtfStp != NULL &&
                    GET_EXTENSION_NBR(mainObjInfoTab[i].hierPtfStp, A_Ptf_HierChildrenPtf_Ext) > 0)
                {
                    mainObjInfoTab[i].forceHierPSPFlg = TRUE;
                }
            }
        }
        else if (computeTab->returnInParPtfRuleEn == ReturnInParentPtfRule_ParentUsingHierPSP)
        {
            DBA_MAIN_OBJ_STP parMainObjInfoStp = NULL;

            for (i = 0; i < mainObjLnkNbr; i++)
            {
                if (mainObjInfoTab[i].hierPtfStp != NULL &&
                    IS_NULLFLD(mainObjInfoTab[i].hierPtfStp, A_Ptf_HierPortId) == FALSE)
                {
                    if (parMainObjInfoStp == NULL ||
                        CMP_DYNFLD(parMainObjInfoStp->hierPtfStp, mainObjInfoTab[i].hierPtfStp, A_Ptf_Id, A_Ptf_HierPortId, IdType) != 0)
                        parMainObjInfoStp = NULL;

                    for (j = 0; j < mainObjLnkNbr && parMainObjInfoStp == NULL; j++)
                    {
                        if (mainObjLnkTab[j] == NULL ||
                            mainObjInfoTab[j].hierPtfStp == NULL ||
                            mainObjInfoTab[j].objEn != Ptf)
                            continue;

                        if (CMP_DYNFLD(mainObjInfoTab[i].hierPtfStp, mainObjInfoTab[j].mainObjStp, A_Ptf_HierPortId, A_Ptf_Id, IdType) == 0)
                        {
                            parMainObjInfoStp = &(mainObjInfoTab[j]);
                            break;
                        }
                    }
                    mainObjInfoTab[i].parMainObjInfoStp = parMainObjInfoStp;
                }
            }
        }
    }

    for (passNbr = PASS_STORED_HIER_PSP; passNbr < PASS_NBR; passNbr++)
    {
        /* For each main object, try to find valid PSP */
        for (firstMainObjPos = 0, i = 0; i < mainObjLnkNbr; i++)
        {
            SET_NULL_DYNST(currPSPObjLnkStp, A_ObjectLnk);

            /* In case of hierarchical portfolios compute the parent in first */
            if (passNbr != mainObjInfoTab[i].passNbr  || mainObjInfoTab[i].mainObjStp == nullptr)
               continue;

            /*PMSTA-48195 -Performance IPS Level -Lalby-310123*/
            /*skip -standard PSP if hiearchical already found for -parent portfolios */
            if (GET_DICT(domainPtr, A_Domain_InitialFctDictId) == DictFct_PtfStorage &&
                static_cast<LOADHIERPTF_ENUM> GET_ENUM(domainPtr, A_Domain_LoadHierFlg) == LoadHierPtf_IntermediateHierarchy)
            {
                DBA_GetObjectEnum(GET_DICT(mainObjLnkTab[i], A_ObjectLnk_FromEntDictId), &objEn);
                if (objEn == Ptf)
                {
                    if ( GET_EXTENSION_PTR(mainObjInfoTab[i].mainObjStp, A_Ptf_ChildrenPtf_Ext) != NULLDYNSTPTR &&
                        (passNbr > PASS_STORED_HIER_PSP &&
                            DATETIME_CMP(mainObjInfoTab[i].firstHierPSPDate, GET_DATETIME(mainObjLnkTab[i], A_ObjectLnk_BeginDate)) <= 0))
                    {
                        mainObjInfoTab[i].passNbr++;
                        continue;
                    }
                }
            }

            /* PMSTA-24511 - LJE - 161209 - Skip standard PSP process if hierarchy PSP was found */
            if ((static_cast<LOADHIERPTF_ENUM> GET_ENUM(domainPtr, A_Domain_LoadHierFlg) != LoadHierPtf_IntermediateHierarchy) && passNbr > PASS_STORED_HIER_PSP &&
                passNbr != PASS_PARENT_HIER_PSP &&
                passNbr != PASS_PARENT_HIER_PSP_BEGIN &&
                mainObjInfoTab[i].firstHierPSPDate.date != MAGIC_END_DATE &&
                DATETIME_CMP(mainObjInfoTab[i].firstHierPSPDate, GET_DATETIME(mainObjLnkTab[i], A_ObjectLnk_BeginDate)) <= 0)
            {
                mainObjInfoTab[i].passNbr++;
                continue;
            }

            /* PMSTA-24511 - LJE - 161209 - Skip hierarchy PSP process if standard PSP is on the future */
            if (passNbr >= PASS_PARENT_HIER_PSP &&
                DATETIME_CMP(mainObjInfoTab[i].firstHierPSPDate, mainObjInfoTab[i].firstStoredPSPDate) != 0 &&
                mainObjInfoTab[i].firstStoredPSPDate.date != MAGIC_END_DATE &&
                (mainObjInfoTab[i].firstHierPSPDate.date == MAGIC_END_DATE ||
                DATETIME_CMP(mainObjInfoTab[i].firstHierPSPDate, GET_DATETIME(mainObjLnkTab[i], A_ObjectLnk_EndDate)) > 0) &&
                DATETIME_CMP(mainObjInfoTab[i].lastStoredPSPDate, GET_DATETIME(mainObjLnkTab[i], A_ObjectLnk_EndDate)) >= 0)
            {
                j = i;
                while (j < mainObjLnkNbr &&
                       CMP_DYNFLD(mainObjLnkTab[i], mainObjLnkTab[j],
                       A_ObjectLnk_FromEntDictId, A_ObjectLnk_FromEntDictId, DictType) == 0 &&
                       CMP_DYNFLD(mainObjLnkTab[i], mainObjLnkTab[j],
                       A_ObjectLnk_FromObjectId, A_ObjectLnk_FromObjectId, IdType) == 0)
                {
                    mainObjInfoTab[j].passNbr++;
                    j++;
                }
                continue;
            }
            

            /* PMSTA-24511 - LJE - 161209 */
            if (passNbr == PASS_PARENT_HIER_PSP_BEGIN &&
                DATETIME_CMP(mainObjInfoTab[i].firstHierPSPDate, mainObjInfoTab[i].firstStoredPSPDate) != 0)
            {
                mainObjInfoTab[i].passNbr++;
                continue;
            }

            /* PMSTA-24511 - LJE - 161206 - If children are used, don't process this pass (and the next one) for all the next main objects */
            if (passNbr == PASS_PARENT_HIER_PSP &&
                DATETIME_CMP(mainObjInfoTab[i].firstHierPSPDate, mainObjInfoTab[i].firstStoredPSPDate) != 0)
            {
                if (DATETIME_CMP(mainObjInfoTab[i].lastStoredPSPDate, GET_DATETIME(mainObjLnkTab[i], A_ObjectLnk_BeginDate)) > 0 &&
                    DATETIME_CMP(mainObjInfoTab[i].lastStoredPSPDate, GET_DATETIME(mainObjLnkTab[i], A_ObjectLnk_EndDate)) >= 0)
                {
                    j = i;
                    while (j < mainObjLnkNbr &&
                           CMP_DYNFLD(mainObjLnkTab[i], mainObjLnkTab[j],
                           A_ObjectLnk_FromEntDictId, A_ObjectLnk_FromEntDictId, DictType) == 0 &&
                           CMP_DYNFLD(mainObjLnkTab[i], mainObjLnkTab[j],
                           A_ObjectLnk_FromObjectId, A_ObjectLnk_FromObjectId, IdType) == 0)
                    {
                        mainObjInfoTab[j].passNbr += 2;
                        j++;
                    }
                    continue;
                }
                else if (DATETIME_CMP(mainObjInfoTab[i].firstHierPSPDate, mainObjInfoTab[i].firstStoredPSPDate) > 0)
                {
                    j = i + 1;
                    while (j < mainObjLnkNbr &&
                           CMP_DYNFLD(mainObjLnkTab[i], mainObjLnkTab[j],
                           A_ObjectLnk_FromEntDictId, A_ObjectLnk_FromEntDictId, DictType) == 0 &&
                           CMP_DYNFLD(mainObjLnkTab[i], mainObjLnkTab[j],
                           A_ObjectLnk_FromObjectId, A_ObjectLnk_FromObjectId, IdType) == 0)
                    {
                        mainObjInfoTab[j].passNbr += 2;
                        j++;
                    }
                }
                else
                {
                    j = i + 1;
                    while (j < mainObjLnkNbr &&
                           CMP_DYNFLD(mainObjLnkTab[i], mainObjLnkTab[j],
                           A_ObjectLnk_FromEntDictId, A_ObjectLnk_FromEntDictId, DictType) == 0 &&
                           CMP_DYNFLD(mainObjLnkTab[i], mainObjLnkTab[j],
                           A_ObjectLnk_FromObjectId, A_ObjectLnk_FromObjectId, IdType) == 0)
                    {
                        if (mainObjInfoTab[j].firstHierPSPDate.date == MAGIC_END_DATE)
                        {
                            mainObjInfoTab[j].firstHierPSPDate = mainObjInfoTab[j - 1].firstHierPSPDate;
                        }
                        j++;
                    }
                }
            }

            SET_ID(domainPtr, A_Domain_GridId, savedGridId);
            SET_ID(domainPtr, A_Domain_CurrId, mainObjInfoTab[i].currId);

            if (computeTab->returnInParPtfRuleEn == ReturnInParentPtfRule_ParentUsingHierPSP &&
                mainObjInfoTab[i].parMainObjInfoStp == NULL &&
                passNbr == PASS_PARENT_HIER_PSP &&
                (DATETIME_CMP(mainObjInfoTab[i].firstStoredPSPDate, GET_DATETIME(mainObjLnkTab[i], A_ObjectLnk_EndDate)) >= 0 ||
                 DATETIME_CMP(mainObjInfoTab[i].firstHierPSPDate, mainObjInfoTab[i].firstStoredPSPDate) == 0 ||
                 DATETIME_CMP(mainObjInfoTab[i].lastStoredPSPDate, GET_DATETIME(mainObjLnkTab[i], A_ObjectLnk_EndDate)) < 0)) /* PMSTA-24511 - LJE - 161209 */
            {
                for (j = 0; j < mainObjLnkNbr; j++)
                {
                    /* Retrieve all the hierarchy of the current main object */
                    if (j == i ||
                        (mainObjInfoTab[j].parMainObjInfoStp != NULL &&
                        mainObjInfoTab[j].parMainObjInfoStp->mainObjStp != NULL &&
                        CMP_DYNFLD(mainObjInfoTab[i].mainObjStp, mainObjInfoTab[j].parMainObjInfoStp->mainObjStp, A_Ptf_Id, A_Ptf_Id, IdType) == 0))
                    {
                        DBA_DYNFLD_STP *objLnkTab;
                        int             objLnkNbr;
                        int             k;

                        COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_FromEntDictId,
                                    mainObjLnkTab[i], A_ObjectLnk, A_ObjectLnk_FromEntDictId);
                        COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_FromObjectId,
                                    mainObjInfoTab[j].mainObjStp, A_Ptf, A_Ptf_Id);
                        /* PMSTA-24511 - LJE - 161206 */
                        COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_BeginDate,
                                    mainObjLnkTab[i], A_ObjectLnk, A_ObjectLnk_BeginDate);
                        COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_EndDate,
                                    mainObjLnkTab[i], A_ObjectLnk, A_ObjectLnk_EndDate);

                        DBA_HierEltRecExtract(hierHead,
                                              A_ObjectLnk,
                                              FALSE,
                                              DBA_FilterObjectLnkFromObj,
                                              currPSPObjLnkStp,
                                              NULL,
                                              FALSE,
                                              FALSE,
                                              &objLnkNbr,
                                              &objLnkTab);

                        if (GET_ENUM(domainPtr, A_Domain_RetDetLevelEn) == PtfRetDetLvl_UsePSP &&
                            objLnkNbr > 0)
                        {
                            mainObjInfoTab[i].hierObjLnksTab = (DBA_DYNFLD_STP*)REALLOC(mainObjInfoTab[i].hierObjLnksTab,
                                                                                        (mainObjInfoTab[i].hierObjLnksNbr + objLnkNbr) * sizeof(DBA_DYNFLD_STP));
                        }

                        for (k = 0; k < objLnkNbr; k++)
                        {
                            switch (GET_ENUM(objLnkTab[k], A_ObjectLnk_Nature))
                            {
                                case ObjectLnkNat_PSPSP:
                                case ObjectLnkNat_PSPPA:
                                case ObjectLnkNat_PSPExtRA:
                                case ObjectLnkNat_Grid:
                                case ObjectLnkNat_SPCopyGrid:
                                    if (mainObjInfoTab[i].lastStoredPSPDate.date == SYB_BEGIN_DATE &&
                                        GET_ENUM(domainPtr, A_Domain_RetDetLevelEn) == PtfRetDetLvl_UsePSP)
                                        {
                                            mainObjInfoTab[i].hierObjLnksTab[mainObjInfoTab[i].hierObjLnksNbr] = objLnkTab[k];
                                            mainObjInfoTab[i].hierObjLnksNbr++;
                                        }
                                    /* PMSTA-24511 - LJE - 161206 */
                                    else if (GET_ENUM(objLnkTab[k], A_ObjectLnk_Nature) != ObjectLnkNat_Grid)
                                    {
                                        if (DATETIME_CMP(GET_DATETIME(objLnkTab[k], A_ObjectLnk_EndDate), mainObjInfoTab[i].lastStoredPSPDate) > 0 &&
                                            DATETIME_CMP(GET_DATETIME(objLnkTab[k], A_ObjectLnk_BeginDate), mainObjInfoTab[i].lastStoredPSPDate) <= 0)
                                        {
                                            SET_DATETIME(objLnkTab[k], A_ObjectLnk_EndDate, mainObjInfoTab[i].lastStoredPSPDate);
                                    }
                                        else if (DATETIME_CMP(GET_DATETIME(objLnkTab[k], A_ObjectLnk_EndDate), mainObjInfoTab[i].firstStoredPSPDate) <= 0 ||
                                                 DATETIME_CMP(GET_DATETIME(objLnkTab[k], A_ObjectLnk_BeginDate), mainObjInfoTab[i].lastStoredPSPDate) >= 0)
                                    {
                                            DBA_DelHierEltRec(hierHead, A_ObjectLnk, objLnkTab[k]);
                                        }
                                    }
                                    break;

                                default:
                                    /* Nothing to do */
                                    break;
                            }
                        }

                        FREE(objLnkTab);
                    }
                }
            }

            firstMainObjPos = i;

            /* If we are in the Use PSP mode, it's the PSP that drive the periods,
            * else, it's the object links.
            */
            if (GET_ENUM(domainPtr, A_Domain_RetDetLevelEn) == PtfRetDetLvl_UsePSP)
            {
                /* Search the end of the object */
                while (i < mainObjLnkNbr &&
                       CMP_DYNFLD(mainObjLnkTab[firstMainObjPos], mainObjLnkTab[i],
                       A_ObjectLnk_FromEntDictId, A_ObjectLnk_FromEntDictId, DictType) == 0 &&
                       CMP_DYNFLD(mainObjLnkTab[firstMainObjPos], mainObjLnkTab[i],
                       A_ObjectLnk_FromObjectId, A_ObjectLnk_FromObjectId, IdType) == 0)
                {
                    i++;
                }
                i--;
            }
            else if (i > 0 &&
                     CMP_DYNFLD(mainObjLnkTab[i - 1], mainObjLnkTab[i],
                     A_ObjectLnk_FromEntDictId, A_ObjectLnk_FromEntDictId, DictType) == 0 &&
                     CMP_DYNFLD(mainObjLnkTab[i - 1], mainObjLnkTab[i],
                     A_ObjectLnk_FromObjectId, A_ObjectLnk_FromObjectId, IdType) == 0)
            {
                COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_FromEntDictId,
                            mainObjLnkTab[i], A_ObjectLnk, A_ObjectLnk_FromEntDictId);
                COPY_DYNFLD(currPSPObjLnkStp, A_ObjectLnk, A_ObjectLnk_FromObjectId,
                            mainObjLnkTab[i], A_ObjectLnk, A_ObjectLnk_FromObjectId);
            }

            ret = DBA_LoadPspForOneMainObj(hierHead,
                                           domainPtr,
                                           dbiConnHelper,
                                           computeTab,
                                           defPPDaStp,
                                           domPPDaStp,
                                           irregBenchFlg,
                                           &(mainObjInfoTab[i]),
                                           &(mainObjInfoTab[i].lastGridRAObjLnkStp),
                                           &(mainObjInfoTab[i].lastPspRAObjLnkStp),
                                           &(mainObjInfoTab[i].lastGridPAObjLnkStp),
                                           &(mainObjInfoTab[i].lastPspPAObjLnkStp),
                                           &(mainObjInfoTab[i].lastPspStdPerfObjLnkStp),
                                           &(mainObjInfoTab[i].lastPspPerfCalcResObjLnkStp),
                                           mainObjLnkTab[firstMainObjPos],
                                           mainObjLnkTab[i],
                                           currPSPObjLnkStp);
            if (ret != RET_SUCCEED)
            {
                FREE_DYNST(defPPDaStp, A_PSPPositionData);
                FREE(mainObjLnkTab);
                FREE_DYNST(currPSPObjLnkStp, A_ObjectLnk);
                FREE(mainObjInfoTab);
                return (ret);
            }

            if (passNbr != PASS_CHILD_STD_PSP &&
                mainObjInfoTab[i].parMainObjInfoStp == NULL)
            {
                if (computeTab->returnInParPtfRuleEn == ReturnInParentPtfRule_ParentUsingHierPSP)
                {
                    if (passNbr == PASS_PARENT_STD_PSP)
                    {
                        mainObjInfoTab[i].passNbr = PASS_PARENT_HIER_PSP;
                    }
                    else
                    {
                        mainObjInfoTab[i].passNbr++;
                    }
                }
                else if (computeTab->returnInParPtfRuleEn == ReturnInParentPtfRule_Parent)
                {
                    if (passNbr == PASS_STORED_HIER_PSP)
                    {
                        if (static_cast<LOADHIERPTF_ENUM> GET_ENUM(domainPtr, A_Domain_LoadHierFlg) != LoadHierPtf_IntermediateHierarchy)
                        {
                            mainObjInfoTab[i].passNbr = PASS_PARENT_HIER_PSP;
                        }
                        /* WEALTH-5266 - KOR - 20240226 - The value of passNbr.for the least child cannot be PASS_PARENT_HIER_PSP */
                        else if (static_cast<LOADHIERPTF_ENUM> GET_ENUM(domainPtr, A_Domain_LoadHierFlg) == LoadHierPtf_IntermediateHierarchy &&
                            (mainObjInfoTab[i].mainObjStp == NULLDYNST ||
                             (GET_EXTENSION_PTR(mainObjInfoTab[i].mainObjStp, A_Ptf_ChildrenPtf_Ext) != NULL ||
                              GET_EXTENSION_PTR(mainObjInfoTab[i].mainObjStp, A_Ptf_HierChildrenPtf_Ext) != NULL ))) /* WEALTH-8345 - lalby - 06062024 - Historical Group Perf*/
                        {
                            mainObjInfoTab[i].passNbr = PASS_PARENT_HIER_PSP;
                        }
                    }
                }
            }
        }
    }

    for (i = 0; i < mainObjLnkNbr; i++)
    {
        mainObjInfoTab[i].hierObjLnksNbr = 0;
        FREE(mainObjInfoTab[i].hierObjLnksTab);
    }

    SET_ID(domainPtr, A_Domain_GridId, savedGridId);
    DBA_LoadRiskFreePSP(hierHead,
                        domainPtr,
                        dbiConnHelper,
                        computeTab);

    FREE(mainObjLnkTab);
    FREE_DYNST(currPSPObjLnkStp, A_ObjectLnk);

    DBA_ConsolidObjectLinks(hierHead, domainPtr);

    DBA_ManageMergedObjects(hierHead, domainPtr, computeTab); /* PMSTA-12261 - LJE - 110708 */

    /* PMSTA-13109 - LJE - 120320 */
    DBA_InsertAllDomPSP(hierHead,
                        domainPtr,
                        dbiConnHelper,
                        computeTab);

    FREE_DYNST(defPPDaStp, A_PSPPositionData);
    FREE(mainObjLnkTab);
    FREE(mainObjInfoTab);
    return (ret);
}

/************************************************************************
**   END  dbapos.c                                                     **
*************************************************************************/


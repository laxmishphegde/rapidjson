/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

/************************************************************************
**      Defines      
*************************************************************************/
#define DBADICT2_C

/************************************************************************
**      Include files
*************************************************************************/
#define STDIO_H
#define STRING_H
#define TIME_H
#define STDLIB_H
#define MATH_H

#include "unidef.h"     /* Mandatory */
#include "gen.h"
#include "dba.h"
#include "fmtlib01.h"

/************************************************************************
**      External entry points
**
**  
**
*************************************************************************/

/************************************************************************
**      Static definitions & data
*************************************************************************/

/**** INTERNAL STRUCTURES ****/
typedef struct {
	int connectNo;
	int dbaOptions;
} CONNECT_INFO_ST, *CONNECT_INFO_STP;

static const char* SV_SynonymStr = "SYNONYM";
static const char* SV_DenomStr   = "DENOM";


/************************************************************************
**      Local functions
**
**
** 
*************************************************************************/
STATIC RET_CODE DICT_CreateEvalDataEntity(OBJECT_ENUM, EVAL_DATA_ENTITY_STP, EVAL_DATA_TYPE_ENUM);
STATIC RET_CODE DICT_CreateEvalDataEntityFromDef(OBJECT_ENUM, EVAL_DATA_ENTITY_STP, DEF_DATA_ENTITY_STP, EVAL_DATA_TYPE_ENUM);
STATIC RET_CODE DICT_FillEvalDataEntity(CONTEXT_ENTITY_STP, DBA_DYNFLD_STP, EVAL_DATA_ENTITY_STP, CONNECT_INFO_STP);
STATIC RET_CODE DICT_FillRecordFromDef(EVAL_DATA_ENTITY_STP, DBA_DYNFLD_STP, EVAL_DATA_TYPE_ENUM);
STATIC RET_CODE DICT_ConvToStrEvalDataEntity(EVAL_DATA_ENTITY_STP);
STATIC RET_CODE DICT_CountSizeEvalDataEntity(EVAL_DATA_ENTITY_STP, const int, const int, FLAG_T, int *);
STATIC RET_CODE DICT_CountSizeEvalDataEntityWithoutDef(EVAL_DATA_ENTITY_STP, const int, int *);
STATIC RET_CODE DICT_PrintEvalDataEntity(EVAL_DATA_ENTITY_STP, const char *, char**);
STATIC RET_CODE DICT_GetFullPathNameEvalDataFld(EVAL_DATA_FLD_STP, char**, int*);
STATIC RET_CODE DICT_PrintEvalDataEntityWithoutDef(EVAL_DATA_ENTITY_STP, char **);
STATIC RET_CODE DICT_CreateDefTableEvalData(const char *, DEF_DATA_ENTITY_STP);

/************************************************************************
**      Functions
*************************************************************************/


/************************************************************************
*   Function            : DICT_ExportRecord
*   
*   Description         : 
*
*   Arguments           : 
*
*   Creation Date       : PMSTA07964 - LJE - 090310
*   Modif.	            : 
*                         
*
*************************************************************************/
RET_CODE  DICT_ExportRecord(CONTEXT_ENTITY_STP	   contextStp,
							DBA_DYNFLD_STP	       recordStp, 
							const char			  *defOutputString, 
							char				 **exportString,
							EVAL_DATA_ENTITY_STP  *evalDataEntityStpPtr,
							DEF_DATA_ENTITY_STP   *defDataEntityStpPtr,
							int                   *connectNoPtr,
							FLAG_T                 withSqlnameFlg,
							EVAL_DATA_TYPE_ENUM    evalDataTypeEn)
{
	EVAL_DATA_ENTITY_STP  evalDataEntityStp;
	char                 *buffer=NULL;
	DEF_DATA_ENTITY_STP   defDataEntityStp;
	CONNECT_INFO_ST       connectInfoSt;

	if (recordStp == NULL ||
		exportString == NULL)
		return RET_GEN_ERR_INVARG;

	if ((connectNoPtr != NULL) &&
        (*connectNoPtr != NO_VALUE))
	{
		connectInfoSt.connectNo  = *connectNoPtr;
		connectInfoSt.dbaOptions = DBA_SET_CONN | DBA_NO_CLOSE;
	}
	else
	{
		connectInfoSt.connectNo  = UNUSED;
		connectInfoSt.dbaOptions = UNUSED;
	}

	if (evalDataEntityStpPtr != NULL &&
		*evalDataEntityStpPtr != NULL)
	{
		evalDataEntityStp = *evalDataEntityStpPtr;
	}
	else
	{	
		evalDataEntityStp = (EVAL_DATA_ENTITY_STP)CALLOC(1, sizeof(EVAL_DATA_ENTITY_ST));
	}

	if (defDataEntityStpPtr != NULL &&
		*defDataEntityStpPtr != NULL)
	{
		defDataEntityStp = *defDataEntityStpPtr;
	}
	else
	{
		defDataEntityStp = (DEF_DATA_ENTITY_STP)CALLOC(1, sizeof(DEF_DATA_ENTITY_ST));
	}

	if (defOutputString != NULL)
	{
		DICT_CreateDefTableEvalData(defOutputString, defDataEntityStp);
		DICT_CreateEvalDataEntityFromDef(GET_OBJ_DYNST(GET_DYNSTENUM(recordStp)), 
										 evalDataEntityStp, 
										 defDataEntityStp, 
										 evalDataTypeEn);
	}
	else
	{
		DICT_CreateEvalDataEntity(GET_OBJ_DYNST(GET_DYNSTENUM(recordStp)), evalDataEntityStp, evalDataTypeEn);
	}

	DICT_FillEvalDataEntity(contextStp, recordStp, evalDataEntityStp, &connectInfoSt);

	DICT_ConvToStrEvalDataEntity(evalDataEntityStp);

	if (withSqlnameFlg == TRUE)
	{
		DICT_PrintEvalDataEntity(evalDataEntityStp, "", &buffer);
	}
	else
	{
		DICT_PrintEvalDataEntityWithoutDef(evalDataEntityStp, &buffer);
	}

	if (evalDataEntityStpPtr != NULL)
	{
		*evalDataEntityStpPtr = evalDataEntityStp;
	}
	else
	{	
		DICT_FreeEvalDataEntity(&evalDataEntityStp);
	}

	if (defDataEntityStpPtr != NULL)
	{
		*defDataEntityStpPtr = defDataEntityStp;
	}
	else
	{
		DICT_FreeDefDataEntity(&defDataEntityStp);
	}

	*exportString = buffer;

	return RET_SUCCEED;
}


/************************************************************************
*   Function            : DICT_GetFmt
*   
*   Description         : 
*
*   Arguments           : 
*
*   Creation Date       : PMSTA07964 - LJE - 090310
*   Modif.	            : HFI-PMSTA-30519-190816    Rewrite function to use it in eval_entity
*                         
*
*************************************************************************/
const char * DICT_GetFieldFormat (DATATYPE_ENUM enDataType)
{
    const char *pszFormat = NULL;
    switch (enDataType)
    {
        case DatetimeType : pszFormat = "YYYYMMDDHHIISS";   break;
        case DateType :     pszFormat = "YYYYMMDD";         break;
        case TimeType :     pszFormat = "HHIISS";           break;
    }
    return pszFormat;
}


/************************************************************************
*   Function            : DICT_GetProgN
*   
*   Description         : 
*
*   Arguments           : 
*
*   Creation Date       : PMSTA07964 - LJE - 090310
*   Modif.	            : 
*                         
*
*************************************************************************/
STATIC RET_CODE DICT_GetProgN(EVAL_DATA_ENTITY_STP  evalDataEntityStp, EVAL_DATA_FLD_STP  evalDataFldStp)
{
	if (evalDataEntityStp->evalDataTypeEn == EvalDataType_AllStruct)
	{
		return (evalDataFldStp->attribStp->progN);
	}
	else
	{
		return (evalDataFldStp->attribStp->shortIdx);
	}
}

/************************************************************************
*   Function            : DICT_CreateEvalDataTab
*   
*   Description         : 
*
*   Arguments           : 
*
*   Creation Date       : PMSTA07964 - LJE - 090310
*   Modif.	            : 
*                         
*
*************************************************************************/
STATIC RET_CODE DICT_CreateEvalDataEntity(OBJECT_ENUM           objEn, 
										  EVAL_DATA_ENTITY_STP  evalDataEntityStp, 
										  EVAL_DATA_TYPE_ENUM   evalDataTypeEn)
{

    EVAL_DATA_FLD_STP   evalDataFldStp;
    FIELD_IDX_T         evalDataPos;
    OBJECT_ENUM         fkObjEn;
    DICT_ENTITY_STP     exportEntityStp = DBA_GetDictEntitySt(objEn);

	evalDataEntityStp->entityStp = exportEntityStp;

	evalDataEntityStp->evalDataFldStTab = (EVAL_DATA_FLD_STP)CALLOC(exportEntityStp->attr.size(), sizeof(EVAL_DATA_FLD_ST));
	evalDataEntityStp->evalDataTypeEn = evalDataTypeEn;
	evalDataEntityStp->objEn          = objEn;

    evalDataPos = 0;
	for (auto& attribStp : exportEntityStp->attr)
    {
		if (attribStp->logicalFlg == TRUE)
			continue;

		if ((evalDataTypeEn == EvalDataType_AllStruct)   ||
			(evalDataTypeEn == EvalDataType_UserDefined) ||
			(evalDataTypeEn == EvalDataType_ShortStruct && attribStp->isNullShortIdx == false) ||
			(evalDataTypeEn == EvalDataType_BusinessKey && attribStp->busKeyFlg    == TRUE))
		{
			evalDataFldStp = &(evalDataEntityStp->evalDataFldStTab[evalDataPos]);

			evalDataFldStp->attribStp      = attribStp;

			evalDataFldStp->fixedSize      = SYS_StrLen(evalDataFldStp->defDataFldStp->sqlName);

			if (attribStp->refEntDictId > 0)
			{
				evalDataFldStp->fkFlg   = TRUE;
				evalDataFldStp->fkProgN = 0;

				DBA_GetObjectEnum(attribStp->refEntDictId, &fkObjEn);

				evalDataFldStp->fkEvalDataEntityStp = (EVAL_DATA_ENTITY_STP)CALLOC(1, sizeof(EVAL_DATA_ENTITY_ST));

				DICT_CreateEvalDataEntity(fkObjEn, evalDataFldStp->fkEvalDataEntityStp, EvalDataType_BusinessKey);
			}
			else if (attribStp->dataTpProgN == IdType && attribStp->primFlg == FALSE)
			{
				evalDataFldStp->fkFlg   = TRUE;
				evalDataFldStp->fkProgN = 1;
			}

			evalDataPos++;
		}
	}

	evalDataEntityStp->evalDataFldNbr = evalDataPos;

    if (evalDataPos != (FIELD_IDX_T)exportEntityStp->attr.size())
	{
		evalDataEntityStp->evalDataFldStTab = (EVAL_DATA_FLD_STP)REALLOC(evalDataEntityStp->evalDataFldStTab, evalDataPos * sizeof(EVAL_DATA_FLD_ST));
	}
	return RET_SUCCEED;
}

/************************************************************************
*   Function            : DICT_CreateEvalDataTabFromDef
*   
*   Description         : 
*
*   Arguments           : 
*
*   Creation Date       : PMSTA07964 - LJE - 090310
*   Modif.	            : 
*                         
*
*************************************************************************/
STATIC RET_CODE DICT_CreateEvalDataEntityFromDef(OBJECT_ENUM           objEn, 
										         EVAL_DATA_ENTITY_STP  evalDataEntityStp,
												 DEF_DATA_ENTITY_STP   defDataEntityStp,
										         EVAL_DATA_TYPE_ENUM   evalDataTypeEn)
{

	DICT_ATTRIB_STP      attribStp;
	EVAL_DATA_FLD_STP    evalDataFldStp;
	DEF_DATA_FLD_STP     defDataFldStp;
    FIELD_IDX_T          attribPos, evalDataPos;
	OBJECT_ENUM          fkObjEn=NullEntity;
	FLAG_T               synonymFlg=FALSE, denomFlg=FALSE;
	EVAL_DATA_TYPE_ENUM  fkEvalDataTypeEn=EvalDataType_ShortStruct;

	if (evalDataEntityStp->defDataEntityStp == defDataEntityStp &&
		evalDataEntityStp->objEn == objEn &&
		evalDataEntityStp->evalDataTypeEn == evalDataTypeEn)
	{
		return RET_SUCCEED; /* Already done */
	}

    DICT_ENTITY_STP exportEntityStp = DBA_GetDictEntitySt(objEn);

	evalDataEntityStp->entityStp = exportEntityStp;

	/* SYNONYM and DENOM cases */
	if (defDataEntityStp == NULL)
	{
		evalDataEntityStp->evalDataTypeEn   = evalDataTypeEn;
		evalDataEntityStp->objEn            = objEn;
		defDataFldStp                       = evalDataEntityStp->parentEvalDataFldStp->defDataFldStp;

		if ((attribStp = DBA_GetAttributeBySqlName(objEn, evalDataEntityStp->parentEvalDataFldStp->attribStp->sqlName)) != NULL)
		{
			evalDataEntityStp->evalDataFldNbr   = 1;
			evalDataEntityStp->evalDataFldStTab = (EVAL_DATA_FLD_STP)CALLOC(evalDataEntityStp->evalDataFldNbr, sizeof(EVAL_DATA_FLD_ST));

			evalDataFldStp = &(evalDataEntityStp->evalDataFldStTab[0]);
			evalDataFldStp->attribStp               = attribStp;
			evalDataFldStp->fixedSize               = SYS_StrLen(defDataFldStp->sqlName);
			evalDataFldStp->parentEvalDataEntityStp = evalDataEntityStp;
			evalDataFldStp->defDataFldStp           = defDataFldStp;
		}

		return RET_SUCCEED;
	}

	evalDataEntityStp->evalDataFldStTab = (EVAL_DATA_FLD_STP)CALLOC(defDataEntityStp->defDataFldNbr, sizeof(EVAL_DATA_FLD_ST));
	evalDataEntityStp->evalDataTypeEn   = evalDataTypeEn;
	evalDataEntityStp->objEn            = objEn;
	evalDataEntityStp->defDataEntityStp = defDataEntityStp;

	for (attribPos=0, evalDataPos=0; attribPos<defDataEntityStp->defDataFldNbr; attribPos++)
	{
		synonymFlg=FALSE;
		denomFlg=FALSE;

		defDataFldStp = &(defDataEntityStp->defDataFldStTab[attribPos]);

		if ((attribStp = DBA_GetAttributeBySqlName(objEn, defDataFldStp->sqlName)) == NULL)
		{
			if (strcmp(SV_SynonymStr, defDataFldStp->sqlName) == 0)
			{
				synonymFlg = TRUE;
				attribStp = DBA_GetAttributeBySqlName(objEn, "code");
			} 
			else if (strcmp(SV_DenomStr, defDataFldStp->sqlName) == 0)
			{
				denomFlg = TRUE;
				attribStp = DBA_GetAttributeBySqlName(objEn, "denom");
			}

			if (attribStp == NULL)
			{
				EVAL_DATA_FLD_ST  evalDataFldSt;
				DICT_ATTRIB_ST    attributeSt;

				memset(&evalDataFldSt, 0, sizeof(EVAL_DATA_FLD_ST));

				strcpy(attributeSt.sqlName, defDataFldStp->sqlName);

				evalDataFldSt.attribStp = &attributeSt;
				evalDataFldSt.parentEvalDataEntityStp = evalDataEntityStp;
				evalDataFldSt.defDataFldStp           = defDataFldStp;

				DICT_CreateOutputMsgFromEvalDataFld(&evalDataFldSt, 
													MsgNat_Warning, 
													0, 
													"Unknown attribute");

				MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "GetAttributeBySqlName", defDataFldStp->sqlName);
				continue;
			}
		}

		if (attribStp->logicalFlg == TRUE)
			continue;

		if ((evalDataTypeEn == EvalDataType_AllStruct) ||
			((evalDataTypeEn == EvalDataType_BusinessKey || 
			  evalDataTypeEn == EvalDataType_ShortStruct) && attribStp->isNullShortIdx == false))
		{
			evalDataFldStp = &(evalDataEntityStp->evalDataFldStTab[evalDataPos]);
			evalDataFldStp->attribStp               = attribStp;
			evalDataFldStp->fixedSize               = SYS_StrLen(defDataFldStp->sqlName);
			evalDataFldStp->parentEvalDataEntityStp = evalDataEntityStp;
			evalDataFldStp->defDataFldStp           = defDataFldStp;

			if (defDataFldStp->fkDefDataEntityStp != NULL && attribStp->refEntDictId > 0)
			{
				evalDataFldStp->fkFlg        = TRUE;
				DBA_GetObjectEnum(attribStp->refEntDictId, &fkObjEn);
				fkEvalDataTypeEn             = EvalDataType_ShortStruct;
			}
			else if (synonymFlg == TRUE)
			{
				evalDataFldStp->fkFlg        = TRUE;
				evalDataFldStp->synonymFlg   = TRUE;
				fkObjEn                      = Synon;
				synonymFlg                   = FALSE;
				fkEvalDataTypeEn             = EvalDataType_AllStruct;
			}
			else if (denomFlg == TRUE)
			{
				evalDataFldStp->fkFlg        = TRUE;
				evalDataFldStp->denomFlg     = TRUE;
				fkObjEn                      = Denom;
				denomFlg                     = FALSE;
				fkEvalDataTypeEn             = EvalDataType_AllStruct;
			}

			if (evalDataFldStp->fkFlg == TRUE)
			{
				evalDataFldStp->hideFieldFlg = TRUE;
				evalDataFldStp->fkProgN      = 0;

				evalDataFldStp->fkEvalDataEntityStp = (EVAL_DATA_ENTITY_STP)CALLOC(1, sizeof(EVAL_DATA_ENTITY_ST));

				evalDataFldStp->fkEvalDataEntityStp->parentEvalDataFldStp = evalDataFldStp;

				DICT_CreateEvalDataEntityFromDef(fkObjEn, 
												 evalDataFldStp->fkEvalDataEntityStp, 
												 defDataFldStp->fkDefDataEntityStp, 
												 fkEvalDataTypeEn);
			}

			evalDataPos++;
		}
		else if (evalDataTypeEn == EvalDataType_ShortStruct && attribStp->isNullShortIdx)
		{
			EVAL_DATA_FLD_ST  evalDataFldSt;

			memset(&evalDataFldSt, 0, sizeof(EVAL_DATA_FLD_ST));
			evalDataFldSt.attribStp = attribStp;
			evalDataFldSt.parentEvalDataEntityStp = evalDataEntityStp;
			evalDataFldSt.defDataFldStp           = defDataFldStp;

			DICT_CreateOutputMsgFromEvalDataFld(&evalDataFldSt, 
											    MsgNat_Warning, 
											    0, 
											    "Not a valid attribute (the attribute must be in the short structure)");
		}
	}

	evalDataEntityStp->evalDataFldNbr = evalDataPos;

	if (defDataEntityStp->defDataFldNbr > evalDataPos)
	{
		evalDataEntityStp->evalDataFldStTab = (EVAL_DATA_FLD_STP)REALLOC(evalDataEntityStp->evalDataFldStTab, evalDataPos * sizeof(EVAL_DATA_FLD_ST));
	}
	return RET_SUCCEED;
}

/************************************************************************
*   Function            : DICT_CreateOutputMsgFromEvalDataFld
*   
*   Description         : Add a message (OutputMsg) to an eval data entity.
*
*   Arguments           : 
*
*   Creation Date       : PCC13654 - LJE - 090630
*   Modif.	            : 
*                         
*
*************************************************************************/
RET_CODE DICT_CreateOutputMsgFromEvalDataFld(EVAL_DATA_FLD_STP     evalDataFldStp,
											 MSGNAT_ENUM           msgNatEn,
											 SMALLINT_T            rank,
											 const char           *msg)
{
	EVAL_DATA_ENTITY_STP  evalDataEntityStp=evalDataFldStp->parentEvalDataEntityStp;
	DBA_DYNFLD_STP        msgStp;
	char                 *fullName=NULL;
	int                   fullNameLen=0;

	evalDataEntityStp->msgNbr++;
	evalDataEntityStp->msgTab = (DBA_DYNFLD_STP*)REALLOC(evalDataEntityStp->msgTab, 
						                                 evalDataEntityStp->msgNbr * sizeof(DBA_DYNFLD_STP));

	msgStp = ALLOC_DYNST(A_OutputMsg);
	SET_ENUM(msgStp, A_OutputMsg_NatEn, msgNatEn);
	SET_STRING(msgStp, A_OutputMsg_Message, msg);
	SET_SMALLINT(msgStp, A_OutputMsg_Rank, rank);

	DICT_GetFullPathNameEvalDataFld(evalDataFldStp, &fullName, &fullNameLen);
	SET_NOTE(msgStp, A_OutputMsg_FullName, fullName);

	evalDataEntityStp->msgTab[evalDataEntityStp->msgNbr-1] = msgStp;

	FREE(fullName);

	return RET_SUCCEED;
}


/************************************************************************
*   Function            : DICT_GetUserSynonymCodif
*   
*   Description         : Add a message (OutputMsg) to an eval data entity.
*
*   Arguments           : 
*
*   Creation Date       : PCC13654 - LJE - 090630
*
*   Modif.	            : PMSTA-15184 - 151012 - PMO : Some warnings during TA build process
*
*************************************************************************/
STATIC RET_CODE DICT_GetCurrentSynonymCodif(EVAL_DATA_ENTITY_STP  evalDataEntityStp,
								            CONTEXT_ENTITY_STP    contextStp,
											DBA_DYNFLD_STP       *codifStpPtr)
{
	DBA_DYNFLD_STP *codifInfoTab;
	int             codifInfoNbr;
	DICT_T			synDictId;
	DBA_DYNFLD_STP  sApplParam = NULL;
	DBA_DYNFLD_STP  aApplParam = NULL;
	DICT_T          entDictId;
	OBJECT_ENUM     objEn;

	if (codifStpPtr                  == NULL || 
		evalDataEntityStp            == NULL ||
		evalDataEntityStp->entityStp == NULL)
		return RET_GEN_ERR_INVARG;

	if (*codifStpPtr!=NULL)
		return RET_SUCCEED;

	if ((aApplParam = ALLOC_DYNST(A_ApplParam)) == NULL)
		return RET_MEM_ERR_ALLOC;

	entDictId = evalDataEntityStp->entityStp->entDictId;
	objEn     = evalDataEntityStp->objEn;

	if (IS_NULLFLD(contextStp->inputEntityStp, A_InputEntity_Codifications) == FALSE)
	{
		char   *entitySqlName = evalDataEntityStp->entityStp->mdSqlName;
		char   *defCodif = NULL;
		CODE_T  codifCd;
		int     entitySqlNameLen;

		/* Format : "|<<entity>>|:=|<<codif>>|; */
		if ((defCodif = strstr(GET_STRING(contextStp->inputEntityStp, A_InputEntity_Codifications), entitySqlName)) != NULL)
		{
			char *pos;

			entitySqlNameLen = SYS_StrLen(entitySqlName);

			for (pos=(defCodif + entitySqlNameLen) + 1; *pos != 0 && *pos != ';' && *pos != '|'; pos++);

			if (*pos == '|')
				pos++;

			unsigned int i;
			for (i=0; i < GET_MAXDATALEN(CodeType) && *pos != 0 && *pos != ';' && *pos != '|'; pos++, i++)  /* PMSTA-33077 - DLA - 181010 */
			{
				codifCd[i] = *pos;
			}
			codifCd[i] = 0;

			SET_INFO(aApplParam, A_ApplParam_Value, codifCd);
		}
	}

	if (IS_NULLFLD(aApplParam, A_ApplParam_Value) == TRUE)
	{
		const char * pszApplName = NULL;    /* PMSTA-15184 - 151012 - PMO */

		if (objEn == Curr)
		{
            pszApplName = "CURRENCY_CODIF";
		}
		else if (objEn == Instr)
		{
			pszApplName = "INSTRUMENT_CODIF";
		}
		else if (objEn == Ptf)
		{
			pszApplName = "PORTFOLIO_CODIF";
		}
		else if (objEn == Third)
		{
			pszApplName = "THIRD_PARTY_CODIF";
		}
		else if (objEn == Tp)
		{
			pszApplName = "TYPE_CODIF";
		}
		else if (objEn == InstrDeposit)
		{
            pszApplName = "DEPOSIT_CODIF";
		}
		else if (objEn == Geo)
		{
            pszApplName = "GEOGRAPHIC_CODIF";
		}
		else if (objEn == Mgr)
		{
            pszApplName = "MANAGER_CODIF";
		}
		else if (objEn == Rating)
		{
            pszApplName = "RATING_CODIF";
		}
		else if (objEn == Sect)
		{
            pszApplName = "SECTOR_CODIF";
		}
		else if (objEn == BusEntity)            /*  HFI-PMSTA-17655-140218  */
		{
            pszApplName = "BUSINESS_ENTITY_CODIF";
		}

        if (pszApplName != NULL)
        {
            /* Check arguments validity and search id if not provided */
            sApplParam = ALLOC_DYNST(S_ApplParam);

            SET_NAME(sApplParam, S_ApplParam_ParamName, pszApplName);	/* DLA - PMSTA09887 - 101115 */
            SET_ID(sApplParam, S_ApplParam_UserId, contextStp->userId);

            if (DBA_Get2(ApplParam,
                         UNUSED,
                         S_ApplParam,
                         sApplParam,
                         A_ApplParam,
                         &aApplParam,
                         UNUSED,
                         UNUSED,
                         UNUSED) != RET_SUCCEED &&
                contextStp->userId != 0)
            {
                /*
                 * There was maybe no APPL_PARAM for the given user,
                 * so use the general one.
                 */
                SET_NULL_ID(sApplParam, S_ApplParam_UserId);

                DBA_Get2(ApplParam,
                         UNUSED,
                         S_ApplParam,
                         sApplParam,
                         A_ApplParam,
                         &aApplParam,
                         UNUSED, UNUSED, UNUSED);
            }

            FREE_DYNST(sApplParam, S_ApplParam);
        }
    }

	if (IS_NULLFLD(aApplParam, A_ApplParam_Value) == FALSE)
	{
		if (DBA_GetDictId(Synon, &synDictId) == FALSE)
				return(FALSE);

		DBA_GetCurrCodifInfoTab(&codifInfoTab, &codifInfoNbr);

        int i;
		for (i=0; i<codifInfoNbr; i++)
		{
            if (GET_DICT(codifInfoTab[i], A_Codif_EntityDictId)     == synDictId    &&
	            GET_DICT(codifInfoTab[i], A_Codif_SynEntityDictId) == entDictId &&
				CMP_DYNFLD(codifInfoTab[i], aApplParam, A_Codif_Cd, A_ApplParam_Value, NameType) == 0)
            {
				break;
			}
		}

		if (i<codifInfoNbr)
		{
			*codifStpPtr = codifInfoTab[i];
		}
	}

	FREE_DYNST(aApplParam, A_ApplParam);

	return RET_SUCCEED;
}

/************************************************************************
*   Function            : DICT_FillEvalDataEntity
*   
*   Description         : 
*
*   Arguments           : 
*
*   Creation Date       : PMSTA07964 - LJE - 090310
*   Modif               : PMSTA-17133 - 051113 - PMO : Many compilation warnings in C code especially " Converting a 64-bit type value to "int" causes truncation."
*                         
*
*************************************************************************/
STATIC RET_CODE DICT_FillEvalDataEntity(CONTEXT_ENTITY_STP	  contextStp,
										DBA_DYNFLD_STP        recordStp, 
										EVAL_DATA_ENTITY_STP  evalDataEntityStp,
										CONNECT_INFO_STP      connectInfoStp)
{
	int               evalDataFldPos;
	EVAL_DATA_FLD_STP evalDataFldStp;
	DBA_DYNFLD_STP    admArgStp=NULL;
	int               progN;

	if (recordStp == NULL)
		return RET_GEN_INFO_NODATA;

	if (evalDataEntityStp->dataStp != NULL)
	{
		/* On the first level, the caller have to free the record */
		if (evalDataEntityStp->parentEvalDataFldStp != NULL)
		{
			FREE_DYNST(evalDataEntityStp->dataStp, GET_DYNSTENUM(evalDataEntityStp->dataStp));
		}
		else
		{
			evalDataEntityStp->dataStp = NULL;
		}
	}

	evalDataEntityStp->dataStp = recordStp;

	for(evalDataFldPos=0; evalDataFldPos<evalDataEntityStp->evalDataFldNbr; evalDataFldPos++)
	{
		evalDataFldStp = &(evalDataEntityStp->evalDataFldStTab[evalDataFldPos]);

		if (evalDataFldStp->synonymFlg == TRUE)
		{
			DBA_DYNFLD_STP sSynonymStp=NULL;
			DBA_DYNFLD_STP aSynonymStp=NULL;
			ID_T           codifId=ZERO_ID;
			DICT_T         entDictId;

			DBA_GetDictId(evalDataEntityStp->objEn, &entDictId);

			if (evalDataFldStp->codifStp == NULL)
			{
				DICT_GetCurrentSynonymCodif(evalDataEntityStp,
								            contextStp,
											&evalDataFldStp->codifStp);
			}
			if (evalDataFldStp->codifStp != NULL)
			{
				codifId = GET_ID(evalDataFldStp->codifStp, A_Codif_Id);
			}

			if ((sSynonymStp = ALLOC_DYNST(S_Synon)) == NULLDYNST)
			{
				return(RET_SUCCEED);
			}

			SET_DICT(sSynonymStp,     S_Synon_EntityDictId, entDictId);
			SET_ID(sSynonymStp,       S_Synon_ObjId,     GET_ID(recordStp, 0));
			SET_ID(sSynonymStp,       S_Synon_CodificationId,   codifId);

			if ((aSynonymStp = ALLOC_DYNST(A_Synon)) == NULLDYNST)
			{
				return(RET_SUCCEED);
			}

			if (codifId == ZERO_ID ||
				DBA_Get2(Synon, 
						 UNUSED, 
						 S_Synon, 
						 sSynonymStp, 
						 A_Synon, 
						 &aSynonymStp, 
						 connectInfoStp->dbaOptions,
						 &(connectInfoStp->connectNo),
						 UNUSED) != RET_SUCCEED)
			{
				FREE_DYNST(sSynonymStp, S_Synon);

				progN = DICT_GetProgN(evalDataEntityStp, evalDataFldStp);
				SET_CODE(aSynonymStp, A_Synon_Cd, GET_CODE(recordStp, progN));
			}

			DICT_FillEvalDataEntity(contextStp, aSynonymStp, evalDataFldStp->fkEvalDataEntityStp, connectInfoStp);

			FREE_DYNST(sSynonymStp, S_Synon);
		}
		else if (evalDataFldStp->denomFlg == TRUE)
		{
			DBA_DYNFLD_STP sDenomStp=NULL;
			DBA_DYNFLD_STP aDenomStp=NULL;
			DICT_T         entDictId;

			DBA_GetDictId(evalDataEntityStp->objEn, &entDictId);

			if ((sDenomStp = ALLOC_DYNST(S_Denom)) == NULLDYNST)
			{
				return(RET_SUCCEED);
			}

			SET_DICT(sDenomStp, S_Denom_EntDictId,     entDictId);
			SET_ID(sDenomStp,   S_Denom_ObjId,         GET_ID(recordStp, 0));
			SET_DICT(sDenomStp, S_Denom_LangEntDictId, contextStp->languageDictId);

			if ((aDenomStp = ALLOC_DYNST(A_Denom)) == NULLDYNST)
			{
				return(RET_SUCCEED);
			}

			if (contextStp->languageDictId == 0 ||
				DBA_Get2(Denom, 
						 UNUSED, 
						 S_Denom, 
						 sDenomStp, 
						 A_Denom, 
						 &aDenomStp, 
						 connectInfoStp->dbaOptions,
						 &(connectInfoStp->connectNo),
						 UNUSED) != RET_SUCCEED)
			{
				FREE_DYNST(sDenomStp, S_Denom);

				progN = DICT_GetProgN(evalDataEntityStp, evalDataFldStp);
				SET_VINFO_ASCII(aDenomStp, A_Denom_Denom, GET_VINFO_ASCII(recordStp, progN));
			}

			DICT_FillEvalDataEntity(contextStp, aDenomStp, evalDataFldStp->fkEvalDataEntityStp, connectInfoStp);

			FREE_DYNST(sDenomStp, S_Denom);
		}
		else
		{
			progN = DICT_GetProgN(evalDataEntityStp, evalDataFldStp);

			if (IS_NULLFLD(recordStp, progN) == FALSE)
			{
				if (evalDataFldStp->fkFlg == TRUE)
				{
					if (evalDataFldStp->fkEvalDataEntityStp != NULL)
					{
						DBA_DYNFLD_STP fkRecordStp=NULL;
						DBA_DYNST_ENUM fkStEnum = GET_ADMINGUIST(evalDataFldStp->fkEvalDataEntityStp->objEn);

						if (admArgStp == NULL &&
							(admArgStp = ALLOC_DYNST(Adm_Arg)) == NULL)
							return RET_MEM_ERR_ALLOC;

						if ((fkRecordStp = ALLOC_DYNST(fkStEnum)) == NULL)
						{
							FREE_DYNST(admArgStp, Adm_Arg);
							return RET_MEM_ERR_ALLOC;
						}

						/* Get short by id */
						SET_ID(admArgStp, Adm_Arg_Id, GET_ID(recordStp, progN));

						if (evalDataFldStp->fkEvalDataEntityStp->entityStp->synonFlg)
						{
	                        ID_T codifId=ZERO_ID;   /* PMSTA-17133 - 051113 - PMO */
							GEN_CodifGetDfltDsp(evalDataFldStp->fkEvalDataEntityStp->objEn, &codifId);
							SET_ID(admArgStp, Adm_Arg_CodifId, codifId);
						}

						if (DBA_Get2(evalDataFldStp->fkEvalDataEntityStp->objEn, 
									 UNUSED, 
									 Adm_Arg, 
									 admArgStp, 
									 fkStEnum,
									 &fkRecordStp,
									 connectInfoStp->dbaOptions,
									 &(connectInfoStp->connectNo), 
									 UNUSED) != RET_SUCCEED)
						{
							FREE_DYNST(fkRecordStp, fkStEnum);
							FREE_DYNST(admArgStp, Adm_Arg);
							return(RET_DBA_ERR_NODATA);
						}

						DICT_FillEvalDataEntity(contextStp, fkRecordStp, evalDataFldStp->fkEvalDataEntityStp, connectInfoStp);
					}
				}
			}
		}
	}

	FREE_DYNST(admArgStp, Adm_Arg);

	return RET_SUCCEED;
}

/************************************************************************
*   Function            : DICT_GetScptFlgFromEvalDataEntity
*   
*   Description         : Generate a script flag tab from informations
*                         come from the eval data entity structure.
*                         This function is used to analysis only known 
*                         attributes.
*
*   Arguments           : EVAL_DATA_ENTITY_STP   evalDataEntityStp
*	  				      FLAG_T		       **scptFlagTabPtr
*
*   Creation Date       : PCC13654 - LJE - 090629
*   Modif.	            : 
*                         
*
*************************************************************************/
RET_CODE DICT_GetScptFlgFromEvalDataEntity(EVAL_DATA_ENTITY_STP   evalDataEntityStp,
  										   FLAG_T		        **scptFlagTabPtr)
{
	int               evalDataFldPos;
	EVAL_DATA_FLD_STP evalDataFldStp;
	int               progN;
	FLAG_T		     *scptFlagTab;
	int               fldNbr = GET_FLD_NBR(GET_EDITGUIST(evalDataEntityStp->objEn));

	if (evalDataEntityStp == NULL ||
		scptFlagTabPtr    == NULL)
		return RET_GEN_ERR_INVARG;

    scptFlagTab = (FLAG_T *) CALLOC(fldNbr,sizeof(FLAG_T));

	for(evalDataFldPos=0; evalDataFldPos<evalDataEntityStp->evalDataFldNbr; evalDataFldPos++)
	{
		evalDataFldStp = &(evalDataEntityStp->evalDataFldStTab[evalDataFldPos]);

		progN = DICT_GetProgN(evalDataEntityStp, evalDataFldStp);

		scptFlagTab[progN] = TRUE;
	}

	*scptFlagTabPtr = scptFlagTab;

	return RET_SUCCEED;
}

/************************************************************************
*   Function            : DICT_FillFkEvalDataEntityFromFilter
*   
*   Description         : 
*
*   Arguments           : 
*   Creation Date       : PCC13654 - LJE - 090629
*   Modif.	            : 
*                         
*
*************************************************************************/
RET_CODE DICT_FillFkEvalDataEntityFromFilter(EVAL_DATA_ENTITY_STP  evalDataEntityStp,
											 PTR                   filterTabArg)
{
	int                   evalDataFldPos;
	EVAL_DATA_FLD_STP     evalDataFldStp;
	int                   progN, i;
	FILTER_STP		      filterTab=(FILTER_STP)filterTabArg;

	if (evalDataEntityStp == NULL ||
		filterTab         == NULL)
		return RET_GEN_ERR_INVARG;

	for(evalDataFldPos=0; evalDataFldPos<evalDataEntityStp->evalDataFldNbr; evalDataFldPos++)
	{
		evalDataFldStp = &(evalDataEntityStp->evalDataFldStTab[evalDataFldPos]);
		progN = DICT_GetProgN(evalDataEntityStp, evalDataFldStp);

		if (evalDataFldStp->fkFlg      == FALSE &&
			filterTab[progN].dynFldTab != NULL)
			continue;

		if (filterTab[progN].enUseFilter != UseFilter::No &&
			filterTab[progN].dataNb     > 0)
		{
			if (filterTab[progN].dynFldTab != NULL)
			{
				evalDataFldStp->fkPermValDynStpTab   = filterTab[progN].dynFldTab;
				filterTab[progN].dynFldTab = NULL;
				evalDataFldStp->fkPermValDynStpNbr = filterTab[progN].dataNb;
				filterTab[progN].dataNb    = 0;
			}
			else if (filterTab[progN].enumTab != NULL)
			{
				evalDataFldStp->fkPermValDynStpNbr = filterTab[progN].dataNb;
				evalDataFldStp->fkPermValDynStpTab = (DBA_DYNFLD_STP*)CALLOC(filterTab[progN].dataNb, sizeof(DBA_DYNFLD_STP));

				for (i=0; i<filterTab[progN].dataNb; i++)
				{
					evalDataFldStp->fkPermValDynStpTab[i] = ALLOC_DYNST(A_DictPermVal);

					SET_ENUM(evalDataFldStp->fkPermValDynStpTab[i], 
							 A_DictPermVal_PermValNatEn,
							 filterTab[progN].enumTab[i]);
					SET_DICT(evalDataFldStp->fkPermValDynStpTab[i], 
							 A_DictPermVal_AttribDictId,
							 evalDataFldStp->attribStp->attrDictId);
				}
			}
		}
	}

	return RET_SUCCEED;
}



/************************************************************************
*   Function            : DICT_ConvToStrEvalDataEntity
*   
*   Description         : 
*
*   Arguments           : 
*
*   Creation Date       : PMSTA07964 - LJE - 090310
*   Modif.	            : 
*                         
*
*************************************************************************/
STATIC RET_CODE DICT_ConvToStrEvalDataEntity(EVAL_DATA_ENTITY_STP  evalDataEntityStp)
{
	int               evalDataFldPos;
	EVAL_DATA_FLD_STP evalDataFldStp;
	DBA_DYNFLD_STP    recordStp;
	int               progN, i, j;

	if (evalDataEntityStp == NULL)
		return RET_GEN_ERR_INVARG;

	recordStp = evalDataEntityStp->dataStp;

	if (recordStp == NULL)
		return RET_GEN_INFO_NODATA;

	for(evalDataFldPos=0; evalDataFldPos<evalDataEntityStp->evalDataFldNbr; evalDataFldPos++)
	{
		evalDataFldStp = &(evalDataEntityStp->evalDataFldStTab[evalDataFldPos]);

		progN = DICT_GetProgN(evalDataEntityStp, evalDataFldStp);

		if (IS_NULLFLD(recordStp, progN) == FALSE)
		{
			if (evalDataFldStp->hideFieldFlg == FALSE)
			{
				evalDataFldStp->valueStr =  FMT_DynFldToStr(evalDataFldStp->valueStr,
															evalDataFldStp->attribStp->dataTpProgN,
															recordStp,
															progN,
															EditDataStyle,
															DICT_GetFieldFormat(evalDataFldStp->attribStp->dataTpProgN),
															evalDataEntityStp->objEn,
															evalDataFldStp->attribStp->attrDictId,
															ICU4AAA_SQLServerUTF8 == TRUE ? TextConversion_Utf8 : TextConversion_Xml, /* PMSTA-12761 - LJE - 110920 */ /* DLA - PMSTA-13053 - 111101 */
															NULL);

				if (evalDataFldStp->valueStr != NULL)
                {
                    evalDataFldStp->size = SYS_StrLen(evalDataFldStp->valueStr);

                    for (i=0, j=0; evalDataFldStp->valueStr[i] != 0; i++)
                    {
                        /* PMSTA-12761 - LJE - 110914 */
                        if (strchr("|;\\", evalDataFldStp->valueStr[i]) != NULL)
                        {
                            j++;
                        }
                    }
                    if (j>0)
                    {
                        evalDataFldStp->size += j;

                        char *tmpStr=(char*)CALLOC(evalDataFldStp->size+j, sizeof(char));
                        for (i=0, j=0; evalDataFldStp->valueStr[i] != 0; i++)
                        {
                            /* PMSTA-12761 - LJE - 110914 */
                            if (strchr("|;\\", evalDataFldStp->valueStr[i]) != NULL)
                            {
                                tmpStr[j++] = '\\';
                            }
                            tmpStr[j++] = evalDataFldStp->valueStr[i];
                        }
                        FREE(evalDataFldStp->valueStr);
                        evalDataFldStp->valueStr = tmpStr;
                    }
                }
			}

			if (evalDataFldStp->fkFlg == TRUE)
			{
				DICT_ConvToStrEvalDataEntity(evalDataFldStp->fkEvalDataEntityStp);
			}
		}
	}

	return RET_SUCCEED;
}

/************************************************************************
*   Function            : DICT_CountSizeEvalDataEntity
*   
*   Description         : 
*
*   Arguments           : 
*
*   Creation Date       : PMSTA07964 - LJE - 090310
*   Modif.	            : 
*                         
*
*************************************************************************/
STATIC RET_CODE DICT_CountSizeEvalDataEntity(EVAL_DATA_ENTITY_STP  evalDataEntityStp, 
											 const int             addEachField, 
											 const int             parentSize, 
											 FLAG_T                defOnly,
											 int                  *totSizePtr)
{
	int               evalDataFldPos;
	EVAL_DATA_FLD_STP evalDataFldStp;

	if (evalDataEntityStp == NULL)
		return RET_SUCCEED;

	for(evalDataFldPos=0; evalDataFldPos<evalDataEntityStp->evalDataFldNbr; evalDataFldPos++)
	{
		evalDataFldStp = &(evalDataEntityStp->evalDataFldStTab[evalDataFldPos]);

		if (evalDataFldStp->hideFieldFlg == FALSE)
			(*totSizePtr) += (defOnly==FALSE?evalDataFldStp->size:0) + addEachField + evalDataFldStp->fixedSize + 1 + parentSize;

		if (evalDataFldStp->fkFlg == TRUE)
		{
			(*totSizePtr)++;
			DICT_CountSizeEvalDataEntity(evalDataFldStp->fkEvalDataEntityStp, 
										 addEachField, 
										 parentSize + evalDataFldStp->fixedSize + 1, 
										 defOnly,
										 totSizePtr);
		}
	}

	return RET_SUCCEED;
}

/************************************************************************
*   Function            : DICT_GetFullPathNameEvalDataFld
*   
*   Description         : 
*
*   Arguments           : 
*
*   Creation Date       : PCC13654 - LJE - 090630
*   Modif.	            : PMSTA-30415 - 090318 - PMO : MESI - TaAutomator test blocked - start import issue
*                         
*
*************************************************************************/
STATIC RET_CODE DICT_GetFullPathNameEvalDataFld(EVAL_DATA_FLD_STP evalDataFldStp, char **fullNamePtr, int *fullNameLenPtr)
{
	if (evalDataFldStp == NULL)
		return RET_SUCCEED;

	if ((*fullNameLenPtr) == 0)
		(*fullNameLenPtr) = 1;

	(*fullNameLenPtr) += SYS_StrLen(evalDataFldStp->defDataFldStp->sqlName) + 1;

	if ((*fullNamePtr) == NULL)
	{
		(*fullNamePtr) = (char*)CALLOC((*fullNameLenPtr), sizeof(char));
	}
	else
	{
		(*fullNamePtr) = (char*)REALLOC((*fullNamePtr), (*fullNameLenPtr) * sizeof(char));
	}

	if (evalDataFldStp->parentEvalDataEntityStp != NULL &&
		evalDataFldStp->parentEvalDataEntityStp->parentEvalDataFldStp != NULL)
	{
		DICT_GetFullPathNameEvalDataFld(evalDataFldStp->parentEvalDataEntityStp->parentEvalDataFldStp, fullNamePtr, fullNameLenPtr);
	}


    if ((*fullNamePtr)[0] == 0)
    {
        strcpy(*fullNamePtr, evalDataFldStp->defDataFldStp->sqlName);
    }
    else
    {
        char * endBuffer = *fullNamePtr + strlen(*fullNamePtr);                                   /* PMSTA-30415 - 090318 - PMO */

        sprintf(endBuffer, ".%s", evalDataFldStp->defDataFldStp->sqlName);
    }

    return RET_SUCCEED;
}

/************************************************************************
*   Function            : DICT_PrintEvalDataEntity
*   
*   Description         : 
*
*   Arguments           : 
*
*   Creation Date       : PMSTA07964 - LJE - 090310
*   Modif.	            : PMSTA-30415 - 090318 - PMO : MESI - TaAutomator test blocked - start import issue
*
*
*************************************************************************/
STATIC RET_CODE DICT_PrintEvalDataEntity(EVAL_DATA_ENTITY_STP  evalDataEntityStp, const char *parentStr, char **buffer)
{
    if (nullptr != evalDataEntityStp)
    {
        if (*buffer == NULL)
        {
            int               totSize=1;
            DICT_CountSizeEvalDataEntity(evalDataEntityStp, 6, 0, FALSE, &totSize);
            (*buffer) = (char*)CALLOC(totSize, sizeof(char));
        }

        for(int evalDataFldPos=0; evalDataFldPos<evalDataEntityStp->evalDataFldNbr; evalDataFldPos++)
        {
            EVAL_DATA_FLD_STP evalDataFldStp = &(evalDataEntityStp->evalDataFldStTab[evalDataFldPos]);

            if (evalDataFldStp->hideFieldFlg == FALSE)
            {
                char * endBuffer = *buffer + strlen(*buffer);                                   /* PMSTA-30415 - 090318 - PMO */
                sprintf(endBuffer, "|%s%s|:=|%s|;", 
                        parentStr,
                        evalDataFldStp->defDataFldStp->sqlName, 
                        (*evalDataFldStp).valueStr!=NULL?(*evalDataFldStp).valueStr:"");
            }

            if (evalDataFldStp->fkFlg == TRUE)
            {
                if (evalDataFldStp->synonymFlg == FALSE && evalDataFldStp->denomFlg == FALSE)
                {
                    char * locParentStr = (char*)CALLOC(strlen(parentStr)+evalDataFldStp->fixedSize+2, sizeof(char));
                    sprintf(locParentStr, "%s%s.", parentStr, evalDataFldStp->defDataFldStp->sqlName);
                    DICT_PrintEvalDataEntity(evalDataFldStp->fkEvalDataEntityStp, locParentStr, buffer);
                    FREE(locParentStr);
                }
                else
                {
                    DICT_PrintEvalDataEntity(evalDataFldStp->fkEvalDataEntityStp, parentStr, buffer);
                }
            }
        }
    }

    return RET_SUCCEED;
}

/************************************************************************
*   Function            : DICT_BuildDefStringFromEvalDataEntity
*   
*   Description         : 
*
*   Arguments           : 
*
*   Creation Date       : PMSTA07964 - LJE - 090310
*   Modif.	            : PMSTA-30415 - 090318 - PMO : MESI - TaAutomator test blocked - start import issue
*                         
*
*************************************************************************/
RET_CODE DICT_BuildDefStringFromEvalDataEntity(EVAL_DATA_ENTITY_STP  evalDataEntityStp, const char *parentStr, char **buffer)
{
    if (nullptr != evalDataEntityStp)
    {
        if (*buffer == NULL)
        {
            int               totSize=1;
            DICT_CountSizeEvalDataEntity(evalDataEntityStp, 2, 0, TRUE, &totSize);
            (*buffer) = (char*)CALLOC(totSize, sizeof(char));

            /* create primary key and business key */
            for (auto it = evalDataEntityStp->entityStp->attr.begin(); it != evalDataEntityStp->entityStp->attr.end(); it++)
            {
                if ((*it)->primFlg   == TRUE ||
					(*it)->busKeyFlg == TRUE)
                {
                    totSize += SYS_StrLen((*it)->sqlName) + 3;
                    (*buffer) = (char*)REALLOC((*buffer), totSize * sizeof(char));

                    char * endBuffer = *buffer + strlen(*buffer);                                   /* PMSTA-30415 - 090318 - PMO */
                    sprintf(endBuffer, "|%s|;", (*it)->sqlName);
                }
            }
        }

        for(int evalDataFldPos=0; evalDataFldPos<evalDataEntityStp->evalDataFldNbr; evalDataFldPos++)
        {
            EVAL_DATA_FLD_STP evalDataFldStp = &(evalDataEntityStp->evalDataFldStTab[evalDataFldPos]);

            if (evalDataFldStp->hideFieldFlg         == FALSE &&
                evalDataFldStp->attribStp->primFlg   == FALSE &&
                evalDataFldStp->attribStp->busKeyFlg == FALSE)
            {
                char * endBuffer = *buffer + strlen(*buffer);                                       /* PMSTA-30415 - 090318 - PMO */
                sprintf(endBuffer, "|%s%s|;",  parentStr, evalDataFldStp->defDataFldStp->sqlName);
            }

            if (evalDataFldStp->fkFlg == TRUE)
            {
                if (evalDataFldStp->synonymFlg == FALSE && evalDataFldStp->denomFlg == FALSE)
                {
                    char * locParentStr = (char*)CALLOC(strlen(parentStr)+evalDataFldStp->fixedSize+2, sizeof(char));
                    sprintf(locParentStr, "%s%s.", parentStr, evalDataFldStp->defDataFldStp->sqlName);
                    DICT_BuildDefStringFromEvalDataEntity(evalDataFldStp->fkEvalDataEntityStp, locParentStr, buffer);
                    FREE(locParentStr);
                }
                else
                {
                    DICT_BuildDefStringFromEvalDataEntity(evalDataFldStp->fkEvalDataEntityStp, parentStr, buffer);
                }
            }
        }
    }

    return RET_SUCCEED;
}

/************************************************************************
*   Function            : DICT_CountSizeEvalDataEntityWithoutDef
*   
*   Description         : 
*
*   Arguments           : 
*
*   Creation Date       : PMSTA07964 - LJE - 090310
*   Modif.	            : 
*                         
*
*************************************************************************/
STATIC RET_CODE DICT_CountSizeEvalDataEntityWithoutDef(EVAL_DATA_ENTITY_STP  evalDataEntityStp, 
													   const int addEachField, 
													   int *totSizePtr)
{
	int               evalDataFldPos;
	EVAL_DATA_FLD_STP evalDataFldStp;

	if (evalDataEntityStp == NULL)
		return RET_SUCCEED;

	for(evalDataFldPos=0; evalDataFldPos<evalDataEntityStp->evalDataFldNbr; evalDataFldPos++)
	{
		evalDataFldStp = &(evalDataEntityStp->evalDataFldStTab[evalDataFldPos]);

		if (evalDataFldStp->hideFieldFlg == FALSE)
			(*totSizePtr) += evalDataFldStp->size + addEachField + 1;

		if (evalDataFldStp->fkFlg == TRUE)
		{
			(*totSizePtr)++;
			DICT_CountSizeEvalDataEntityWithoutDef(evalDataFldStp->fkEvalDataEntityStp, 
											 	   addEachField, 
												   totSizePtr);
		}
	}

	return RET_SUCCEED;
}

/************************************************************************
*   Function            : DICT_PrintEvalDataEntityWithoutDef
*   
*   Description         : 
*
*   Arguments           : 
*
*   Creation Date       : PMSTA07964 - LJE - 090310
*   Modif.	            : PMSTA-30415 - 090318 - PMO : MESI - TaAutomator test blocked - start import issue
*                         
*
*************************************************************************/
STATIC RET_CODE DICT_PrintEvalDataEntityWithoutDef(EVAL_DATA_ENTITY_STP  evalDataEntityStp, char **buffer)
{
    if (NULL != evalDataEntityStp)
    {
        if (*buffer == NULL)
        {
            int               totSize=1;
            DICT_CountSizeEvalDataEntityWithoutDef(evalDataEntityStp, 3, &totSize);
            (*buffer) = (char*)CALLOC(totSize, sizeof(char));
        }

        for(int evalDataFldPos=0; evalDataFldPos<evalDataEntityStp->evalDataFldNbr; evalDataFldPos++)
        {
            EVAL_DATA_FLD_STP evalDataFldStp = &(evalDataEntityStp->evalDataFldStTab[evalDataFldPos]);

            if (evalDataFldStp->hideFieldFlg == FALSE)
            {
                char * endBuffer = *buffer + strlen(*buffer);                                   /* PMSTA-30415 - 090318 - PMO */
                sprintf(endBuffer, "|%s|;", (*evalDataFldStp).valueStr!=NULL?(*evalDataFldStp).valueStr:"");
            }

            if (evalDataFldStp->fkFlg == TRUE)
            {
                DICT_PrintEvalDataEntityWithoutDef(evalDataFldStp->fkEvalDataEntityStp, buffer);
            }
        }
    }

    return RET_SUCCEED;
}

/************************************************************************
*   Function            : DICT_GetAllMessageFromEvalDataEntity
*   
*   Description         : 
*
*   Arguments           : 
*
*   Creation Date       : PCC13654 - LJE - 090630
*   Modif.	            : 
*                         
*
*************************************************************************/
RET_CODE DICT_GetAllMessageFromEvalDataEntity(EVAL_DATA_ENTITY_STP  evalDataEntityStp, 
 											  int                  *msgNbrPtr,
											  DBA_DYNFLD_STP      **msgTabPtr)
{
	int               evalDataFldPos;
	EVAL_DATA_FLD_STP evalDataFldStp;
	int               i;

	if (evalDataEntityStp == NULL)
		return RET_SUCCEED;

	if (evalDataEntityStp->msgTab != NULL &&
		evalDataEntityStp->msgNbr > 0)
	{
		(*msgTabPtr) = (DBA_DYNFLD_STP *)REALLOC((*msgTabPtr), ((*msgNbrPtr)+evalDataEntityStp->msgNbr) * sizeof(DBA_DYNFLD_STP));

		for (i=0; i<evalDataEntityStp->msgNbr; i++)
		{
			(*msgTabPtr)[(*msgNbrPtr)+i] = evalDataEntityStp->msgTab[i];
		}

		(*msgNbrPtr) += evalDataEntityStp->msgNbr;
	}

	for(evalDataFldPos=0; evalDataFldPos<evalDataEntityStp->evalDataFldNbr; evalDataFldPos++)
	{
		evalDataFldStp = &(evalDataEntityStp->evalDataFldStTab[evalDataFldPos]);

		if (evalDataFldStp->fkFlg == TRUE)
		{
			DICT_GetAllMessageFromEvalDataEntity(evalDataFldStp->fkEvalDataEntityStp, msgNbrPtr, msgTabPtr);
		}
	}

	return RET_SUCCEED;
}

/************************************************************************
*   Function            : DICT_FreeEvalDataEntity
*   
*   Description         : 
*
*   Arguments           : 
*
*   Creation Date       : PMSTA07964 - LJE - 090310
*   Modif.	            : 
*                         
*
*************************************************************************/
RET_CODE DICT_FreeEvalDataEntity(EVAL_DATA_ENTITY_STP  *evalDataEntityStpPtr)
{
	int               evalDataFldPos;
	EVAL_DATA_FLD_STP evalDataFldStp;

	if (evalDataEntityStpPtr == NULL ||
		*evalDataEntityStpPtr == NULL)
		return RET_SUCCEED;

	for(evalDataFldPos=0; evalDataFldPos<(*evalDataEntityStpPtr)->evalDataFldNbr; evalDataFldPos++)
	{
		evalDataFldStp = &((*evalDataEntityStpPtr)->evalDataFldStTab[evalDataFldPos]);

		if (evalDataFldStp->fkFlg == TRUE)
		{
			DICT_FreeEvalDataEntity(&(evalDataFldStp->fkEvalDataEntityStp));
		}

		if (evalDataFldStp->fkPermValDynStpNbr > 0)
		{
			DBA_FreeDynStTab(evalDataFldStp->fkPermValDynStpTab, 
							 evalDataFldStp->fkPermValDynStpNbr, 
							 GET_DYNSTENUM(evalDataFldStp->fkPermValDynStpTab[0]));

			evalDataFldStp->fkPermValDynStpTab = NULL;
			evalDataFldStp->fkPermValDynStpNbr = 0;
		}
		FREE(evalDataFldStp->fullSqlName);
		FREE(evalDataFldStp->valueStr);
	}

	DBA_FreeDynStTab((*evalDataEntityStpPtr)->msgTab, (*evalDataEntityStpPtr)->msgNbr, A_OutputMsg);
	FREE((*evalDataEntityStpPtr)->evalDataFldStTab);

	if ((*evalDataEntityStpPtr)->parentEvalDataFldStp != NULL)
	{
		FREE_DYNST((*evalDataEntityStpPtr)->dataStp, GET_DYNSTENUM((*evalDataEntityStpPtr)->dataStp));
	}

	FREE(*evalDataEntityStpPtr);
	return RET_SUCCEED;
}

/************************************************************************
*   Function            : DICT_FreeDefDataEntity
*   
*   Description         : 
*
*   Arguments           : 
*
*   Creation Date       : PMSTA07964 - LJE - 090310
*   Modif.	            : 
*                         
*
*************************************************************************/
RET_CODE DICT_FreeDefDataEntity(DEF_DATA_ENTITY_STP  *defDataEntityStpPtr)
{
	int               defDataFldPos;
	DEF_DATA_FLD_STP  defDataFldStp;

	if (defDataEntityStpPtr == NULL ||
		*defDataEntityStpPtr == NULL)
		return RET_SUCCEED;

	for(defDataFldPos=0; defDataFldPos<(*defDataEntityStpPtr)->defDataFldNbr; defDataFldPos++)
	{
		defDataFldStp = &((*defDataEntityStpPtr)->defDataFldStTab[defDataFldPos]);

		if (defDataFldStp->fkDefDataEntityStp != NULL)
		{
			DICT_FreeDefDataEntity(&(defDataFldStp->fkDefDataEntityStp));
		}
	}

	FREE((*defDataEntityStpPtr)->defDataFldStTab);

	FREE(*defDataEntityStpPtr);
	return RET_SUCCEED;
}

/************************************************************************
*   Function            : DICT_AddParamInDefTable
*
*   Description         :
*
*   Arguments           :
*
*   Creation Date       : DDV - 210219 - PMSTA-36104 - refactoring to add recursivity
*   Modif.	            :
*
*************************************************************************/
STATIC RET_CODE DICT_AddParamInDefTable(DEF_DATA_ENTITY_STP defDataEntityStp,
                                        const char          *defString,
                                        int                 defSize,
                                        const char          *dataString,
                                        int                 dataSize,
                                        FLAG_T              forcedFlg,
                                        int                 *joinLevel)
{
    DEF_DATA_FLD_STP  defDataFldStp = NULL;

    if (defString == NULL)
        return RET_GEN_ERR_INVARG;

    for (int i = 0; i <= defSize; i++)
    {
        if (i == defSize || defString[i] == '.')
        {
            for (int j = 0; j < defDataEntityStp->defDataFldNbr && defDataFldStp == NULL; j++)
            {
                if (defDataEntityStp->defDataFldStTab[j].fkDefDataEntityStp)
                {
                    if (strncmp(defDataEntityStp->defDataFldStTab[j].sqlName, defString, i) == 0)
                    {
                        if (strlen(defDataEntityStp->defDataFldStTab[j].sqlName) == (size_t)(i))
                        {
                            defDataFldStp = &defDataEntityStp->defDataFldStTab[j];
                        }
                    }
                }
            }

            if (defDataFldStp == NULL)
            {
                if (defDataEntityStp->defDataFldAllocSize <= defDataEntityStp->defDataFldNbr)
                {
                    (defDataEntityStp->defDataFldAllocSize) += 100;
                    defDataEntityStp->defDataFldStTab = (DEF_DATA_FLD_STP) REALLOC(defDataEntityStp->defDataFldStTab,
                                                                                   defDataEntityStp->defDataFldAllocSize * sizeof(DEF_DATA_FLD_ST));
                }

                defDataFldStp = &defDataEntityStp->defDataFldStTab[defDataEntityStp->defDataFldNbr];
                (defDataEntityStp->defDataFldNbr)++;

                memset(defDataFldStp, -1, sizeof(DEF_DATA_FLD_ST));

                defDataFldStp->fkDefDataEntityStp = NULL;

                if ((*joinLevel) == 0)
                {
                    defDataFldStp->forcedFlg = forcedFlg;
                }
                else
                {
                    defDataFldStp->forcedFlg = FALSE;
                }

                strncpy(defDataFldStp->sqlName, defString, i);
                defDataFldStp->sqlName[i] = 0;
            }

            if (i == defSize)
            {
                defDataFldStp->dataStr = dataString;
                defDataFldStp->dataSize = dataSize;
            }
            else if (defString[i] == '.')
            {
                /* Add next level */
                defDataFldStp->useTypeEn = UseType_ForeignKey;

                if (defDataFldStp->fkDefDataEntityStp == NULL)
                {
                    defDataFldStp->fkDefDataEntityStp = (DEF_DATA_ENTITY_STP)CALLOC(1, sizeof(DEF_DATA_ENTITY_ST));
                }

                i++;
                (*joinLevel)++;
                return(DICT_AddParamInDefTable(defDataFldStp->fkDefDataEntityStp, &(defString[i]), defSize - i, dataString, dataSize, forcedFlg, joinLevel));
            }
        }
    }
    return RET_SUCCEED;
}

/************************************************************************
*   Function            : DICT_CreateDefTableEvalData
*
*   Description         :
*
*   Arguments           :
*
*   Creation Date       : PMSTA07964 - LJE - 090310
*   Modif.              : DDV - 210219 - PMSTA-36104 - refactoring to add recursivity in AddParam function
*
*************************************************************************/
STATIC RET_CODE DICT_CreateDefTableEvalData(const char          *defString,
                                            DEF_DATA_ENTITY_STP defDataEntityStp)
{
    int			      i = 0,
                      defPos = -1,
                      defSize = -1,
                      dataPos = -1,
                      dataSize = -1, 
                      joinLevel = 0;
    FLAG_T            forcedFlg = FALSE;
    bool              escChar = false;

    if (defString == NULL)
        return RET_GEN_ERR_INVARG;

    if (defDataEntityStp->defString == defString)
        return RET_SUCCEED; /* already done */

    defDataEntityStp->defString = defString;

    defDataEntityStp->defDataFldNbr = 0;
    defDataEntityStp->defDataFldStTab = NULL;

    while (defString[i] != 0)
    {
        /* PMSTA-12761 - LJE - 110914 */
        if (escChar == false)
        {
            if (defString[i] == '\\')
            {
                escChar = true;
                i++;
            }
        }
        else
        {
            escChar = false;
        }

        if (escChar == false && defString[i] == '|') /* PMSTA-12761 - LJE - 110914 */
        {
            if (defPos == -1)
            {
                defPos = i + 1;
            }
            else if (defSize == -1)
            {
                defSize = i - defPos;
            }
            else if (dataPos == -1)
            {
                dataPos = i + 1;
            }
            else
            {
                dataSize = i - dataPos;
            }
        }
        else if (escChar == false && defString[i] == ';') /* PMSTA-12761 - LJE - 110914 */
        {
            DICT_AddParamInDefTable(defDataEntityStp, &(defDataEntityStp->defString[defPos]), defSize, &(defDataEntityStp->defString[dataPos]), dataSize, forcedFlg, &joinLevel);
            forcedFlg = FALSE;
            defPos = -1;
            defSize = -1;
            dataPos = -1;
            dataSize = -1;
        }
        else if (defSize != -1 && dataPos == -1)
        {
            if (defString[i] == ':')
            {
                forcedFlg = TRUE;
            }
        }

        i++;
    }

    return RET_SUCCEED;
}

/************************************************************************
*   Function            : DICT_ImportRecord
*   
*   Description         : 
*
*   Arguments           : 
*
*   Creation Date       : PMSTA07964 - LJE - 090310
*   Modif.	            : 
*                         
*
*************************************************************************/
RET_CODE  DICT_ImportRecord(const char           *importString, 
							const char           *entitySqlName, 
							DBA_DYNFLD_STP       *recordPtr, 
							EVAL_DATA_TYPE_ENUM   evalDataTypeEn,
							EVAL_DATA_ENTITY_STP *evalDataEntityStpPtr,
							DEF_DATA_ENTITY_STP  *defDataEntityStpPtr,
							int                  *)
{
	DICT_ENTITY_STP       entityStp;
	OBJECT_ENUM           objEn;

	if (recordPtr       == NULL ||
		entitySqlName   == NULL ||
		importString    == NULL ||
		importString[0] == 0)
		return RET_GEN_ERR_INVARG;

	if ((entityStp = DBA_GetEntityBySqlName(entitySqlName)) == NULL)
    {
        MSG_SendMesg(RET_GEN_ERR_INVARG, 1, FILEINFO, "DICT_ImportRecord/DBA_GetEntityBySqlName", entitySqlName);
		return RET_GEN_ERR_INVARG;
    }

	DBA_GetObjectEnum(entityStp->entDictId, &objEn);

	if (evalDataTypeEn == EvalDataType_BusinessKey ||
		evalDataTypeEn == EvalDataType_ShortStruct)
	{
		if ((*recordPtr = ALLOC_DYNST(GET_ADMINGUIST(objEn))) == NULL)
			return RET_MEM_ERR_ALLOC;
	}
	else
	{
		if ((*recordPtr = ALLOC_DYNST(GET_EDITGUIST(objEn))) == NULL)
			return RET_MEM_ERR_ALLOC;
	}

	EVAL_DATA_ENTITY_STP evalDataEntityStp = (EVAL_DATA_ENTITY_STP)CALLOC(1, sizeof(EVAL_DATA_ENTITY_ST));
	DEF_DATA_ENTITY_STP  defDataEntityStp  = (DEF_DATA_ENTITY_STP)CALLOC(1,  sizeof(DEF_DATA_ENTITY_ST));

	DICT_CreateDefTableEvalData(importString, defDataEntityStp);
	DICT_CreateEvalDataEntityFromDef(objEn, 
				                     evalDataEntityStp, 
									 defDataEntityStp, 
									 evalDataTypeEn);

	DICT_FillRecordFromDef(evalDataEntityStp, *recordPtr, evalDataTypeEn);

	if (evalDataEntityStpPtr != NULL)
	{
		*evalDataEntityStpPtr = evalDataEntityStp;
	}
	else
	{	
		DICT_FreeEvalDataEntity(&evalDataEntityStp);
	}

	if (defDataEntityStpPtr != NULL)
	{
		*defDataEntityStpPtr = defDataEntityStp;
	}
	else
	{
		DICT_FreeDefDataEntity(&defDataEntityStp);
	}
	return RET_SUCCEED;
}

/************************************************************************
*   Function            : DICT_FillRecordFromDef
*   
*   Description         : Fill the eval data entity structure with informations
*                         contains in the definition set with the function
*                         DICT_CreateEvalDataEntityFromDef
*
*   Arguments           : 
*
*   Creation Date       : PMSTA07964 - LJE - 090310
*   Modif.              : PMSTA-17133 - 051113 - PMO : Many compilation warnings in C code especially " Converting a 64-bit type value to "int" causes truncation."
*                         
*
*************************************************************************/
STATIC RET_CODE DICT_FillRecordFromDef(EVAL_DATA_ENTITY_STP  evalDataEntityStp, 
									   DBA_DYNFLD_STP        recordStp,
									   EVAL_DATA_TYPE_ENUM   evalDataTypeEn)
{
	int               evalDataFldPos;
	EVAL_DATA_FLD_STP evalDataFldStp;
	DEF_DATA_FLD_STP  defDataFldStp;
	ID_T              codifId=ZERO_ID;       /* PMSTA-17133 - 051113 - PMO */
	FIELD_IDX_T       progN;
	char             *dataStr;
	int               allocDataStrNbr=100;
    int               rc = RET_GEN_INFO_NODATA;
    int               i, j;

	if (recordStp == NULL)
		return RET_SUCCEED;

	if ((dataStr = (char*)CALLOC(allocDataStrNbr, sizeof(char))) == NULL)
		return RET_MEM_ERR_ALLOC;

	evalDataEntityStp->dataStp = recordStp;

	for(evalDataFldPos=0; evalDataFldPos<evalDataEntityStp->evalDataFldNbr; evalDataFldPos++)
	{
		evalDataFldStp = &(evalDataEntityStp->evalDataFldStTab[evalDataFldPos]);
		defDataFldStp  = evalDataFldStp->defDataFldStp;

		if ((evalDataTypeEn == EvalDataType_BusinessKey ||
			 evalDataTypeEn == EvalDataType_ShortStruct) &&
			evalDataFldStp->attribStp->isNullShortIdx)
		{
			continue;
		}

		if (evalDataTypeEn == EvalDataType_BusinessKey || 
                evalDataTypeEn == EvalDataType_ShortStruct)
			progN = evalDataFldStp->attribStp->shortIdx;
		else
            progN = evalDataFldStp->attribStp->progN;

		if (defDataFldStp->dataSize > 0)
		{
			if (allocDataStrNbr <= defDataFldStp->dataSize)
			{
				allocDataStrNbr = defDataFldStp->dataSize+1;
				if ((dataStr = (char*)REALLOC(dataStr, allocDataStrNbr * sizeof(char))) == NULL)
					return RET_MEM_ERR_ALLOC;
			}

            /* PMSTA-12761 - LJE - 110914 */
            for (i=0, j=0; i<defDataFldStp->dataSize; i++)
            {
                if (defDataFldStp->dataStr[i] != '\\')
                {
                    dataStr[j++] = defDataFldStp->dataStr[i];
                }
            }
			dataStr[j] = 0;

			FMT_StrToFld(dataStr,
                         GET_FLD_DTP(recordStp, progN),
                         recordStp,
                         progN,
                         EditDataStyle,
                         DICT_GetFieldFormat(evalDataFldStp->attribStp->dataTpProgN),
                         ICU4AAA_SQLServerUTF8 == TRUE ? TextConversion_Utf8 : TextConversion_Xml,  /* PMSTA-12761 - LJE - 110920 */ /* DLA - PMSTA-13053 - 111101 */
                         DictAttrib_WgtTypeDefault);                                                /*  HFI-PMSTA-30817-180503  Add widgetEn for cut of time    */

            rc = RET_SUCCEED;
        }
        else if (evalDataFldStp->fkFlg == TRUE)
		{
			if (evalDataFldStp->fkEvalDataEntityStp != NULL)
			{
				DBA_DYNFLD_STP fkRecordStp=NULL;
				DBA_DYNST_ENUM fkStEnum = GET_ADMINGUIST(evalDataFldStp->fkEvalDataEntityStp->objEn);

				if ((fkRecordStp = ALLOC_DYNST(fkStEnum)) == NULL)
					return RET_MEM_ERR_ALLOC;


                if (DICT_FillRecordFromDef(evalDataFldStp->fkEvalDataEntityStp,
										fkRecordStp,
										EvalDataType_BusinessKey) == RET_SUCCEED)
                {
			        if (evalDataFldStp->fkEvalDataEntityStp->entityStp->synonFlg)
			        {
				        GEN_CodifGetDfltDsp(
                            evalDataFldStp->fkEvalDataEntityStp->objEn, &codifId);

                        /* TODO: set codification id in short */
			        }

                    /* PMSTA-36123 - DDV - 190606 - Quick fix, continue loop even if DBA_Get2 return an error */
                    if (DBA_Get2(evalDataFldStp->fkEvalDataEntityStp->objEn,
                        UNUSED,
                        fkStEnum,
                        fkRecordStp,
                        fkStEnum,
                        &fkRecordStp,
                        UNUSED,
                        UNUSED,
                        UNUSED) == RET_SUCCEED)
                    {

                        COPY_DYNFLD(
                            recordStp,
                            GET_DYNSTENUM(recordStp),
                            progN,
                            fkRecordStp,
                            GET_DYNSTENUM(fkRecordStp),
                            evalDataFldStp->fkProgN);
                    }

                    rc = RET_SUCCEED;
                }
            }
		}
	}

	FREE(dataStr);

	return rc;
}

/************************************************************************
 **   END  dbadict2.c
 *************************************************************************/


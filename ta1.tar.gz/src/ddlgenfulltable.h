/************************************************************************
**
**           Copyright (C) 1995-2023 Temenos Headquarters SA
**                         All Rights Reserved
**
**                     Portfolio Management System
**
*************************************************************************/

#ifndef DDLGENFULLTABLE_H
#define DDLGENFULLTABLE_H

/************************************************************************
**      Constant & Macro definitions
*************************************************************************/

/************************************************************************
**      Structures & typedef definitions
*************************************************************************/

/************************************************************************
**      External definitions attached to : ddlgenfulltable.cpp
*************************************************************************/
#include <fstream>
#include <algorithm>
#include <iomanip>

#include "dba.h"
#include "ddlgenmsg.h"
#include "ddlgenvar.h"
#include "ddlgencfgfile.h"
#include "ddlgendbaccess.h"

class DdlGen;

class DdlGenFullTable:public DdlGenMsg
{

public:
    // Constructors
    DdlGenFullTable(DdlGenAction     &paramDdlgenAction,
                    DdlGenContext    &paramDdlGenContext,
                    DICT_ENTITY_STP   paramDictEntityStp = nullptr);

    DdlGenFullTable(const DdlGenFullTable&) = delete;

    // Destructor
    virtual ~DdlGenFullTable();

    enum class MigrationStep
    {
        MultiEntityFirst,
        MultiEntitySecond,
        UserDefinedFields
    };

    // Methods
    DdlGenFullTable& operator = (const DdlGenFullTable&) = delete;
    RET_CODE               pushEntityToInsert(DBA_DYNFLD_STP);
    RET_CODE               checkAndFix();
    RET_CODE               memoryDeleteEntity();
    RET_CODE               buildInMemory();
    RET_CODE               manageDependencies(DictEntityClass *refDictEntityStp = nullptr);      /* PMSTA-26108 - LJE - 170916 */
    RET_CODE               updateCrossLinks();        /* PMSTA-26108 - LJE - 171027 */
    RET_CODE               updateCrossProgN();        
    RET_CODE               buildInMetaDict1();
    RET_CODE               buildInMetaDict2();
    RET_CODE               buildInMetaDict3();
    RET_CODE               buildInMetaDict4();
    RET_CODE               buildInMetaDict5();
    RET_CODE               checkMetaDict();
    RET_CODE               buildLabelsInMetaDict();
    RET_CODE               processHelpDocument();
    RET_CODE               buildCommentsInMetaDict(); /* PMSTA-10243 - DDV - 150512 */
    RET_CODE               buildTablesInDB(TARGET_TABLE_ENUM);
    RET_CODE               setTablesStatistics(TARGET_TABLE_ENUM);
    RET_CODE               buildVerticalTablesInDB();
    RET_CODE               deleteTablesInDB();
    RET_CODE               buildIndexesInDB(const std::string &idxSqlNameOnly = std::string());
    RET_CODE               buildPrimaryKeyInDB();
    RET_CODE               manageMigration(DdlGenFullTable::MigrationStep migrationStep);
    RET_CODE               buildForeignKeysInDB();
    RET_CODE               buildViewsInDB();
    RET_CODE               buildSysViewsInDB();
    RET_CODE               buildUtilsViewsInDB();
    RET_CODE               buildStoredProceduresInDB();
    RET_CODE               buildSpecialSProcsInDB();
    RET_CODE               buildTriggersInDB();

    RET_CODE               buildStdXdIndexes(DdlGenRequestHelper& requestHelper);

    RET_CODE               checkIdentityValues();

    RET_CODE               saveReferencesInDb();

    RET_CODE               manageDerivedMultiEntityCategory();
    RET_CODE               manageMultiEntityCategory(bool bFirstPass);

	RET_CODE			   buildXDCNameInMetaDict();	 /* PMSTA-16395 - TGU - 150720*/
	RET_CODE			   buildCDynSTfromMD();		/* PMSTA-16395 - TGU - 150720*/
    RET_CODE               setEntityStatus(XD_STATUS_ENUM xdStatusEn);

    RET_CODE               genSampleImportFile();

    RET_CODE               questionnairePostUpdate(); /* PMSTA-19243 - DDV - 150506 */
    DBA_DYNFLD_STP         getXdEntityStp();
    OBJECT_ENUM            getObjectEn() const;

    DdlGenAction          &getDdlGenAction();

    DICT_ENTITY_STP        getDictEntityStp();
    DdlGenEntity          *getDdlGenEntityPtr();

    std::vector<DBA_DYNFLD_STP> m_packageInstallationCompoVector;

protected:

    // Methods
    RET_CODE            createDictCriteria(DdlGenRequestHelper &requestHelper);
    RET_CODE            init();
    RET_CODE            insertAllAttrib(DdlGenRequestHelper &requestHelper);
    RET_CODE            addMandatoryAttributes(DdlGenRequestHelper &requestHelper);
    RET_CODE            addAttributesFromFeature(DdlGenRequestHelper &requestHelper, DBA_DYNFLD_STP featureStp);
    RET_CODE            manageExtAttributes(DdlGenRequestHelper &requestHelper);
    RET_CODE            managePartitions(DdlGenRequestHelper &requestHelper);                                         /* PMSTA-24007 - LJE - 170717 */
    RET_CODE            insertAllPartition(DdlGenRequestHelper &requestHelper);                                       /* PMSTA-24007 - LJE - 170717 */
    RET_CODE            checkAllAttributes();
    RET_CODE            checkShortIndex(bool bUpdShortIdx);
    RET_CODE            computeProgN();

    RET_CODE            setAttribStatus(DdlGenRequestHelper &requestHelper, DBA_DYNFLD_STP paramXdAttribStp, DBA_DYNFLD_STP paramDictAttribStp, XD_STATUS_ENUM xdStatusEn);
    RET_CODE            setStatusToAllAttrib(DdlGenRequestHelper &requestHelper, XD_STATUS_ENUM xdStatusEn);

    bool                isAllDictCriteria(int attrPos);
    bool                isShortDictCriteria(int attrPos);
    bool                isSecuDictCriteria(int attrPos);

    const std::string   getDynDefFullFileName(const std::string &fileName, bool bGenFile = true, bool bMacFile = false);
    void                extractDynDefFile(std::string, std::set<std::string> &, std::set<std::string> &, std::set<std::string> &, std::set<std::string> &);
    void                extractDbaDynDefFile(const std::string &, const std::string &, std::map<std::string, std::string> &, std::map<std::string, std::string> &);
    void                createDynDefFile(const std::string &, const std::string&, const std::set<std::string> &incTab, const std::set<std::string> &macTab, const std::set<std::string> &dynDefTab, const std::set<std::string> &objDefTab);
    void                createObjDefFile(const std::string &, const std::stringstream &);

    void                getAttribCName(DICT_ENTITY_STP dictEntityStp, std::string &attribCName, DBA_DYNFLD_STP currXdAttribStp, std::map<std::string, std::string> &convertMap);
    void                getShortAttribSqlName(std::string &, DICT_ATTRIB_STP);

    void                addBkDictCriteria(DBA_DYNFLD_STP currXdAttribStp, DICT_CRITER_ST &parentCriteriaSt, SMALLINT_T &criterPos, SMALLINT_T &shRank, SMALLINT_T &index);

    DdlGenDbi           ddlGenDbi;
    DBA_ENTITY_NAT_ENUM entNatureEn;
    DICT_ENTITY_STP     m_dictEntityStp;
    OBJECT_ENUM         objectEn;

    std::string         shortPrefixStr;

    bool                bIdxToDo;
    bool                bStdIdxToDo;
    bool                bTrgToDo;
    bool                bTableToDo;
    bool                bUdTableToDo;
    bool                bExtTableToDo;
    bool                bSProcToDo;
    bool                bViewToDo;
    bool                bShortToDo;
    bool                bVerticalSearchToDo;
    bool                bVerticalPatternToDo;
    bool                bCheckAndFixDone;
    bool                bbuildInMetaDict1Done;
    bool                bbuildInMetaDict2Done;

    DdlGenEntity       *ddlGenEntityPtr;

private:

    DBA_DYNFLD_STP    shXdAttribStp;
    DBA_DYNFLD_STP    shDictEntityStp;

    DBA_DYNFLD_STP    shDictSegmentStp;
    bool              bHasShortDefined;
    bool              bNoShortOnEntity;

    bool              bPkChanged;
    bool              m_sProcAppendFile;

    MemoryPool        m_mp;

    std::map<std::string, DBA_DYNFLD_STP> aDictAttribMap;
    std::list<DdlGenFullTable*>           derivedEntityList;
    std::vector<DICT_ATTRIB_STP>          m_migrateAttribVector;
    bool                                  m_bTriggersDeleted;

    std::string                           m_currProcessStr;

    /* PMSTA-14086 - LJE - 121004 */
    RET_CODE          buildXdIndexes(DdlGenRequestHelper &requestHelper, DBA_IDX_FUNCTION_ENUM idxFctEn);
    RET_CODE          copyXdIndexesFromLinkedEntity(DdlGenRequestHelper &requestHelper);                   /* PMSTA-26250 - LJE - 170428 */

    RET_CODE          initConnection(DdlGenFile* localFileHeperPtr = nullptr, bool paramBInTran = true);
    void              finishConnection(RET_CODE retStatus);

    RET_CODE          deleteDictEntity();
    RET_CODE          deleteRefRecord(DICT_T delEntDictId, ID_T delRefId, DdlGen& delDdlGen);

};


#endif	                               /* ifndef DDLGENFULLTABLE_H */
/************************************************************************
**      END       ddlgenfulltable.h                                   Odyssey
*************************************************************************/
